<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
}

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {		
		$fileData = '$union_credits_isok=\''.dhtmlspecialchars($_GET['union_credits_isok'])."';\n";
		$fileData .= '$union_credits_name=\''.dhtmlspecialchars($_GET['union_credits_name'])."';\n";
		$fileData .= '$union_credits_money=\''.floatval($_GET['union_credits_money'])."';\n";
		$fileData .= '$union_credits_tcbl1=\''.floatval($_GET['union_credits_tcbl1'])."';\n";
		$fileData .= '$union_credits_tcbl2=\''.floatval($_GET['union_credits_tcbl2'])."';\n";

		$fileData .= '$union_video_isok=\''.dhtmlspecialchars($_GET['union_video_isok'])."';\n";
		$fileData .= '$union_video_name=\''.dhtmlspecialchars($_GET['union_video_name'])."';\n";
		$fileData .= '$union_video_money=\''.floatval($_GET['union_video_money'])."';\n";
		$fileData .= '$union_video_tcbl1=\''.floatval($_GET['union_video_tcbl1'])."';\n";
		$fileData .= '$union_video_tcbl2=\''.floatval($_GET['union_video_tcbl2'])."';\n";
		
		$fileData .= '$union_exam_isok=\''.dhtmlspecialchars($_GET['union_exam_isok'])."';\n";
		$fileData .= '$union_exam_name=\''.dhtmlspecialchars($_GET['union_exam_name'])."';\n";
		$fileData .= '$union_exam_money=\''.floatval($_GET['union_exam_money'])."';\n";
		$fileData .= '$union_exam_tcbl1=\''.floatval($_GET['union_exam_tcbl1'])."';\n";
		$fileData .= '$union_exam_tcbl2=\''.floatval($_GET['union_exam_tcbl2'])."';\n";
		
		$fileData .= '$union_group_isok=\''.dhtmlspecialchars($_GET['union_group_isok'])."';\n";
		$fileData .= '$union_group_name=\''.dhtmlspecialchars($_GET['union_group_name'])."';\n";
		$fileData .= '$union_group_money=\''.floatval($_GET['union_group_money'])."';\n";
		$fileData .= '$union_group_tcbl1=\''.floatval($_GET['union_group_tcbl1'])."';\n";
		$fileData .= '$union_group_tcbl2=\''.floatval($_GET['union_group_tcbl2'])."';\n";
		
		$fileData .= '$union_brand_isok=\''.dhtmlspecialchars($_GET['union_brand_isok'])."';\n";
		$fileData .= '$union_brand_name=\''.dhtmlspecialchars($_GET['union_brand_name'])."';\n";
		$fileData .= '$union_brand_money=\''.floatval($_GET['union_brand_money'])."';\n";
		$fileData .= '$union_brand_tcbl1=\''.floatval($_GET['union_brand_tcbl1'])."';\n";
		$fileData .= '$union_brand_tcbl2=\''.floatval($_GET['union_brand_tcbl2'])."';\n";
		
		$fileData .= '$union_tuan_isok=\''.dhtmlspecialchars($_GET['union_tuan_isok'])."';\n";
		$fileData .= '$union_tuan_name=\''.dhtmlspecialchars($_GET['union_tuan_name'])."';\n";
		$fileData .= '$union_tuan_money=\''.floatval($_GET['union_tuan_money'])."';\n";
		$fileData .= '$union_tuan_tcbl1=\''.floatval($_GET['union_tuan_tcbl1'])."';\n";
		$fileData .= '$union_tuan_tcbl2=\''.floatval($_GET['union_tuan_tcbl2'])."';\n";
		
		$fileData .= '$union_waimai_isok=\''.dhtmlspecialchars($_GET['union_waimai_isok'])."';\n";
		$fileData .= '$union_waimai_name=\''.dhtmlspecialchars($_GET['union_waimai_name'])."';\n";
		$fileData .= '$union_waimai_money=\''.floatval($_GET['union_waimai_money'])."';\n";
		$fileData .= '$union_waimai_tcbl1=\''.floatval($_GET['union_waimai_tcbl1'])."';\n";
		$fileData .= '$union_waimai_tcbl2=\''.floatval($_GET['union_waimai_tcbl2'])."';\n";
		
		$fileData .= '$union_sale_isok=\''.dhtmlspecialchars($_GET['union_sale_isok'])."';\n";
		$fileData .= '$union_sale_name=\''.dhtmlspecialchars($_GET['union_sale_name'])."';\n";
		$fileData .= '$union_sale_money=\''.floatval($_GET['union_sale_money'])."';\n";
		$fileData .= '$union_sale_tcbl1=\''.floatval($_GET['union_sale_tcbl1'])."';\n";
		$fileData .= '$union_sale_tcbl2=\''.floatval($_GET['union_sale_tcbl2'])."';\n";
		
		$fileData .= '$union_paotui_isok=\''.dhtmlspecialchars($_GET['union_paotui_isok'])."';\n";
		$fileData .= '$union_paotui_name=\''.dhtmlspecialchars($_GET['union_paotui_name'])."';\n";
		$fileData .= '$union_paotui_money=\''.floatval($_GET['union_paotui_money'])."';\n";
		$fileData .= '$union_paotui_tcbl1=\''.floatval($_GET['union_paotui_tcbl1'])."';\n";
		$fileData .= '$union_paotui_tcbl2=\''.floatval($_GET['union_paotui_tcbl2'])."';\n";
		
		$fileData .= '$union_witkey_isok=\''.dhtmlspecialchars($_GET['union_witkey_isok'])."';\n";
		$fileData .= '$union_witkey_name=\''.dhtmlspecialchars($_GET['union_witkey_name'])."';\n";
		$fileData .= '$union_witkey_post_money=\''.intval($_GET['union_witkey_post_money'])."';\n";
		$fileData .= '$union_witkey_post=\''.floatval($_GET['union_witkey_post'])."';\n";
		$fileData .= '$union_witkey_post1=\''.floatval($_GET['union_witkey_post1'])."';\n";
		$fileData .= '$union_witkey_get_money=\''.intval($_GET['union_witkey_get_money'])."';\n";
		$fileData .= '$union_witkey_get=\''.floatval($_GET['union_witkey_get'])."';\n";
		$fileData .= '$union_witkey_get1=\''.floatval($_GET['union_witkey_get1'])."';\n";
		
		$fileData .= '$union_wike_isok=\''.dhtmlspecialchars($_GET['union_wike_isok'])."';\n";
		$fileData .= '$union_wike_name=\''.dhtmlspecialchars($_GET['union_wike_name'])."';\n";
		$fileData .= '$union_wike_post_money=\''.intval($_GET['union_wike_post_money'])."';\n";
		$fileData .= '$union_wike_post=\''.floatval($_GET['union_wike_post'])."';\n";
		$fileData .= '$union_wike_post1=\''.floatval($_GET['union_wike_post1'])."';\n";
		$fileData .= '$union_wike_get_money=\''.intval($_GET['union_wike_get_money'])."';\n";
		$fileData .= '$union_wike_get=\''.floatval($_GET['union_wike_get'])."';\n";
		$fileData .= '$union_wike_get1=\''.floatval($_GET['union_wike_get1'])."';\n";
		
		$fileData .= '$union_scoremall_isok=\''.dhtmlspecialchars($_GET['union_scoremall_isok'])."';\n";
		$fileData .= '$union_scoremall_name=\''.dhtmlspecialchars($_GET['union_scoremall_name'])."';\n";
		$fileData .= '$union_scoremall_money=\''.intval($_GET['union_scoremall_money'])."';\n";
		$fileData .= '$union_scoremall=\''.floatval($_GET['union_scoremall'])."';\n";
		$fileData .= '$union_scoremall1=\''.floatval($_GET['union_scoremall1'])."';\n";

		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_union_lang['s97'], "action=plugins&identifier=$identifier&cp=admin_saleset&pmod=admin_saleset&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_saleset&pmod=admin_saleset&operation=$operation&do=$do");
showtableheaders($it618_union_lang['s13'],'it618_union_set');

if($union_credits_isok==1)$union_credits_isok_checked='checked="checked"';else $union_credits_isok_checked="";
if($union_video_isok==1)$union_video_isok_checked='checked="checked"';else $union_video_isok_checked="";
if($union_exam_isok==1)$union_exam_isok_checked='checked="checked"';else $union_exam_isok_checked="";
if($union_group_isok==1)$union_group_isok_checked='checked="checked"';else $union_group_isok_checked="";
if($union_brand_isok==1)$union_brand_isok_checked='checked="checked"';else $union_brand_isok_checked="";
if($union_tuan_isok==1)$union_tuan_isok_checked='checked="checked"';else $union_tuan_isok_checked="";
if($union_waimai_isok==1)$union_waimai_isok_checked='checked="checked"';else $union_waimai_isok_checked="";
if($union_sale_isok==1)$union_sale_isok_checked='checked="checked"';else $union_sale_isok_checked="";
if($union_paotui_isok==1)$union_paotui_isok_checked='checked="checked"';else $union_paotui_isok_checked="";
if($union_witkey_isok==1)$union_witkey_isok_checked='checked="checked"';else $union_witkey_isok_checked="";
if($union_wike_isok==1)$union_wike_isok_checked='checked="checked"';else $union_wike_isok_checked="";
if($union_scoremall_isok==1)$union_scoremall_isok_checked='checked="checked"';else $union_scoremall_isok_checked="";

if(trim($union_credits_name)=='')$union_credits_name=$it618_union_lang['s469'];
if(trim($union_video_name)=='')$union_video_name=$it618_union_lang['s471'];
if(trim($union_exam_name)=='')$union_exam_name=$it618_union_lang['s877'];
if(trim($union_group_name)=='')$union_group_name=$it618_union_lang['s766'];
if(trim($union_brand_name)=='')$union_brand_name=$it618_union_lang['s470'];
if(trim($union_tuan_name)=='')$union_tuan_name=$it618_union_lang['s472'];
if(trim($union_waimai_name)=='')$union_waimai_name=$it618_union_lang['s473'];
if(trim($union_sale_name)=='')$union_sale_name=$it618_union_lang['s488'];
if(trim($union_paotui_name)=='')$union_paotui_name=$it618_union_lang['s474'];
if(trim($union_witkey_name)=='')$union_witkey_name=$it618_union_lang['s770'];
if(trim($union_wike_name)=='')$union_wike_name=$it618_union_lang['s639'];
if(trim($union_scoremall_name)=='')$union_scoremall_name=$it618_union_lang['s646'];


$union_credits_str='<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_credits_tcbl1" value="'.$union_credits_tcbl1.'">% ';
$union_credits_str1='<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_credits_tcbl2" value="'.$union_credits_tcbl2.'">% ';

$union_video_str.='<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_video_tcbl1" value="'.$union_video_tcbl1.'">% ';
$union_video_str1.='<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_video_tcbl2" value="'.$union_video_tcbl2.'">% ';

$union_exam_str.='<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_exam_tcbl1" value="'.$union_exam_tcbl1.'">% ';
$union_exam_str1.='<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_exam_tcbl2" value="'.$union_exam_tcbl2.'">% ';

$union_group_str.='<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_group_tcbl1" value="'.$union_group_tcbl1.'">% ';
$union_group_str1.='<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_group_tcbl2" value="'.$union_group_tcbl2.'">% ';

$union_brand_str.='<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_brand_tcbl1" value="'.$union_brand_tcbl1.'">% ';
$union_brand_str1.='<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_brand_tcbl2" value="'.$union_brand_tcbl2.'">% ';

$union_tuan_str.='<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_tuan_tcbl1" value="'.$union_tuan_tcbl1.'">% ';
$union_tuan_str1.='<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_tuan_tcbl2" value="'.$union_tuan_tcbl2.'">% ';

$union_waimai_str.='<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_waimai_tcbl1" value="'.$union_waimai_tcbl1.'">% ';
$union_waimai_str1.='<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_waimai_tcbl2" value="'.$union_waimai_tcbl2.'">% ';

$union_sale_str.='<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_sale_tcbl1" value="'.$union_sale_tcbl1.'">% ';
$union_sale_str1.='<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_sale_tcbl2" value="'.$union_sale_tcbl2.'">% ';

$union_paotui_str.='<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_paotui_tcbl1" value="'.$union_paotui_tcbl1.'">% ';
$union_paotui_str1.='<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_paotui_tcbl2" value="'.$union_paotui_tcbl2.'">% ';

echo '
<tr><td colspan=2>'.$it618_union_lang['s98'].'<br><br><hr></td></tr>

<tr><td><input type="checkbox" id="union_credits_isok" name="union_credits_isok" value="1" style="vertical-align:middle" '.$union_credits_isok_checked.'><label for="union_credits_isok">'.$it618_union_lang['s625'].$it618_union_lang['s500'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_credits_name" value="'.$union_credits_name.'"> '.$it618_union_lang['s468'].' '.$it618_union_lang['s633'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_credits_money" value="'.$union_credits_money.'">'.$it618_union_lang['s634'].'
'.$it618_union_lang['s627'].$union_credits_str.' '.$it618_union_lang['s628'].$union_credits_str1.'<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_video_isok" name="union_video_isok" value="1" style="vertical-align:middle" '.$union_video_isok_checked.'><label for="union_video_isok">'.$it618_union_lang['s629'].$it618_union_lang['s500'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_video_name" value="'.$union_video_name.'"> '.$it618_union_lang['s468'].' '.$it618_union_lang['s633'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_video_money" value="'.$union_video_money.'">'.$it618_union_lang['s634'].'
'.$it618_union_lang['s627'].$union_video_str.' '.$it618_union_lang['s628'].$union_video_str1.'<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_exam_isok" name="union_exam_isok" value="1" style="vertical-align:middle" '.$union_exam_isok_checked.'><label for="union_exam_isok">'.$it618_union_lang['s878'].$it618_union_lang['s500'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_exam_name" value="'.$union_exam_name.'"> '.$it618_union_lang['s468'].' '.$it618_union_lang['s633'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_exam_money" value="'.$union_exam_money.'">'.$it618_union_lang['s634'].'
'.$it618_union_lang['s627'].$union_exam_str.' '.$it618_union_lang['s628'].$union_exam_str1.'<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_group_isok" name="union_group_isok" value="1" style="vertical-align:middle" '.$union_group_isok_checked.'><label for="union_group_isok">'.$it618_union_lang['s767'].$it618_union_lang['s500'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_group_name" value="'.$union_group_name.'"> '.$it618_union_lang['s468'].' '.$it618_union_lang['s633'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_group_money" value="'.$union_group_money.'">'.$it618_union_lang['s634'].'
'.$it618_union_lang['s627'].$union_group_str.' '.$it618_union_lang['s628'].$union_group_str1.'<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_brand_isok" name="union_brand_isok" value="1" style="vertical-align:middle" '.$union_brand_isok_checked.'><label for="union_brand_isok">'.$it618_union_lang['s626'].$it618_union_lang['s500'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_brand_name" value="'.$union_brand_name.'"> '.$it618_union_lang['s468'].' '.$it618_union_lang['s633'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_brand_money" value="'.$union_brand_money.'">'.$it618_union_lang['s634'].'
'.$it618_union_lang['s627'].$union_brand_str.' '.$it618_union_lang['s628'].$union_brand_str1.'<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_tuan_isok" name="union_tuan_isok" value="1" style="vertical-align:middle" '.$union_tuan_isok_checked.'><label for="union_tuan_isok">'.$it618_union_lang['s631'].$it618_union_lang['s500'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_tuan_name" value="'.$union_tuan_name.'"> '.$it618_union_lang['s468'].' '.$it618_union_lang['s633'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_tuan_money" value="'.$union_tuan_money.'">'.$it618_union_lang['s634'].'
'.$it618_union_lang['s627'].$union_tuan_str.' '.$it618_union_lang['s628'].$union_tuan_str1.'<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_waimai_isok" name="union_waimai_isok" value="1" style="vertical-align:middle" '.$union_waimai_isok_checked.'><label for="union_waimai_isok">'.$it618_union_lang['s630'].$it618_union_lang['s500'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_waimai_name" value="'.$union_waimai_name.'"> '.$it618_union_lang['s468'].' '.$it618_union_lang['s633'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_waimai_money" value="'.$union_waimai_money.'">'.$it618_union_lang['s634'].'
'.$it618_union_lang['s627'].$union_waimai_str.' '.$it618_union_lang['s628'].$union_waimai_str1.'<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_sale_isok" name="union_sale_isok" value="1" style="vertical-align:middle" '.$union_sale_isok_checked.'><label for="union_sale_isok">'.$it618_union_lang['s996'].$it618_union_lang['s997'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_sale_name" value="'.$union_sale_name.'"> '.$it618_union_lang['s468'].' '.$it618_union_lang['s998'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_sale_money" value="'.$union_sale_money.'">'.$it618_union_lang['s634'].'
'.$it618_union_lang['s627'].$union_sale_str.' '.$it618_union_lang['s628'].$union_sale_str1.'<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_paotui_isok" name="union_paotui_isok" value="1" style="vertical-align:middle" '.$union_paotui_isok_checked.'><label for="union_paotui_isok">'.$it618_union_lang['s632'].$it618_union_lang['s500'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_paotui_name" value="'.$union_paotui_name.'"> '.$it618_union_lang['s468'].' '.$it618_union_lang['s633'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_paotui_money" value="'.$union_paotui_money.'">'.$it618_union_lang['s634'].'
'.$it618_union_lang['s627'].$union_paotui_str.' '.$it618_union_lang['s628'].$union_paotui_str1.'<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_witkey_isok" name="union_witkey_isok" value="1" style="vertical-align:middle" '.$union_witkey_isok_checked.'><label for="union_witkey_isok">'.$it618_union_lang['s769'].$it618_union_lang['s500'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_witkey_name" value="'.$union_witkey_name.'"> '.$it618_union_lang['s468'].'
<br>
'.$it618_union_lang['s641'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_witkey_post_money" value="'.$union_witkey_post_money.'">'.$it618_union_lang['s643'].'
'.$it618_union_lang['s627'].'<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_witkey_post" value="'.$union_witkey_post.'">% '.$it618_union_lang['s628'].'<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_witkey_post1" value="'.$union_witkey_post1.'">%
<br>
'.$it618_union_lang['s642'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_witkey_get_money" value="'.$union_witkey_get_money.'">'.$it618_union_lang['s643'].'
'.$it618_union_lang['s627'].'<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_witkey_get" value="'.$union_witkey_get.'">% '.$it618_union_lang['s628'].'<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_witkey_get1" value="'.$union_witkey_get1.'">%<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_wike_isok" name="union_wike_isok" value="1" style="vertical-align:middle" '.$union_wike_isok_checked.'><label for="union_wike_isok">'.$it618_union_lang['s640'].$it618_union_lang['s645'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_wike_name" value="'.$union_wike_name.'"> '.$it618_union_lang['s468'].'
<br>
'.$it618_union_lang['s641'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_wike_post_money" value="'.$union_wike_post_money.'">'.$it618_union_lang['s643'].'
'.$it618_union_lang['s627'].'<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_wike_post" value="'.$union_wike_post.'">% '.$it618_union_lang['s628'].'<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_wike_post1" value="'.$union_wike_post1.'">%
<br>
'.$it618_union_lang['s642'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_wike_get_money" value="'.$union_wike_get_money.'">'.$it618_union_lang['s643'].'
'.$it618_union_lang['s627'].'<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_wike_get" value="'.$union_wike_get.'">% '.$it618_union_lang['s628'].'<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_wike_get1" value="'.$union_wike_get1.'">%<br><br><hr>
</td></tr>

<tr><td><input type="checkbox" id="union_scoremall_isok" name="union_scoremall_isok" value="1" style="vertical-align:middle" '.$union_scoremall_isok_checked.'><label for="union_scoremall_isok">'.$it618_union_lang['s647'].$it618_union_lang['s645'].'</label></td>
<tr></tr><td style="line-height:26px">
'.$it618_union_lang['s467'].'<input type="text" class="txt" style="width:180px;margin-right:3px" name="union_scoremall_name" value="'.$union_scoremall_name.'"> '.$it618_union_lang['s468'].'
<br>
'.$it618_union_lang['s644'].'<input type="text" class="txt" style="width:50px;color:blue;margin-right:3px" name="union_scoremall_money" value="'.$union_scoremall_money.'">'.$it618_union_lang['s643'].'
'.$it618_union_lang['s627'].'<input type="text" class="txt" style="width:50px;color:red;margin-right:3px" name="union_scoremall" value="'.$union_scoremall.'">% '.$it618_union_lang['s628'].'<input type="text" class="txt" style="width:50px;color:#f0f;margin-right:3px" name="union_scoremall1" value="'.$union_scoremall1.'">%<br><br><hr>
</td></tr>


';

showsubmit('it618submit', $it618_union_lang['s19']);

if(count($reabc)!=11)return;
showtablefooter();

?>