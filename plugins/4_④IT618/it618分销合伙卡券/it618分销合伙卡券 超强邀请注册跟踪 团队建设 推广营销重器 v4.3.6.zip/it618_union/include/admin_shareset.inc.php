<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php';
}

if(submitcheck('it618submit_share')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {		
		$fileData = '$share_name=\''.dhtmlspecialchars($_GET['share_name'])."';\n";
		$fileData .= '$share_img=\''.dhtmlspecialchars($_GET['share_img'])."';\n";
		$fileData .= '$share_des=\''.dhtmlspecialchars($_GET['share_des'])."';\n";
		$fileData .= '$share_about=\''.$_GET['share_about']."';\n";
		$fileData .= '$share_pcabout=\''.$_GET['share_pcabout']."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_union_lang['s446'], "action=plugins&identifier=$identifier&cp=admin_shareset&pmod=admin_shareset&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_shareset&pmod=admin_shareset&operation=$operation&do=$do");
showtableheaders($it618_union_lang['s445'],'it618_union_set');

echo '
<tr><td width=100>'.$it618_union_lang['s448'].'</td><td><input type="text" class="txt" style="width:680px;color:green" name="share_name" value="'.$share_name.'"></td></tr>
<tr><td>'.$it618_union_lang['s449'].'</td><td><img src="'.$share_img.'" id="img" width="118" height="80" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url" name="share_img" readonly="readonly" value="'.$share_img.'" style="width:200px" /> <input type="button" id="image" value="'.$it618_union_lang['s450'].'" /> '.$it618_union_lang['s451'].'</td></tr>
<tr><td>'.$it618_union_lang['s454'].'</td><td><textarea class="txt" style="width:680px;color:green;height:90px" name="share_des">'.$share_des.'</textarea></td></tr>
<tr><td>'.$it618_union_lang['s456'].'</td><td>'.$it618_union_lang['s457'].'</td></tr>
<tr><td>'.$it618_union_lang['s452'].'</td><td>'.$it618_union_lang['s453'].'</td></tr>
<tr><td>'.$it618_union_lang['s459'].'</td><td><textarea class="txt" style="width:680px;color:green;height:60px" name="share_pcabout">'.$share_pcabout.'</textarea></td></tr>
<tr><td>'.$it618_union_lang['s455'].'</td><td><textarea class="txt" style="width:680px;color:green;height:60px" name="share_about">'.$share_about.'</textarea></td></tr>
';

echo '
<link rel="stylesheet" href="source/plugin/it618_union/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_union/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_union/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				K(\'#image\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url\').val(url);
								K(\'#img\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});
			});
</script>';

showsubmit('it618submit_share', $it618_union_lang['s19']);

if(count($reabc)!=11)return;
showtablefooter();

?>