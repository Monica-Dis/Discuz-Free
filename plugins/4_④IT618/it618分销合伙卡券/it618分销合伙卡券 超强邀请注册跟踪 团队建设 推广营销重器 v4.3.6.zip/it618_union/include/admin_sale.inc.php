<?php
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$urlsql='&uid='.$_GET['uid'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];
if($reabc[6]!='u')return;

if(submitcheck('it618sercsubmit')){
	$ppp = $it618_union['pagecount'];
	$page = 1;
	$startlimit = 0;
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($it618_union_lang['s14'],'it618_union_saletc');
	showsubmit('it618sercsubmit', $it618_union_lang['s89'], $it618_union_lang['s90'].' <input name="uid" style="width:50px" value="'.$_GET['uid'].'" class="txt" /> '.$it618_union_lang['s91'].' <input id="it618_time1" name="it618_time1" class="txt" style="width:80px;margin-right:0" readonly="readonly" value="'.$_GET['it618_time1'].'" /> - <input id="it618_time2" name="it618_time2" class="txt" style="width:80px;" readonly="readonly" value="'.$_GET['it618_time2'].'"/>');
	if($reabc[8]!='i')return;
	$count=C::t('#it618_union#it618_union_saletc')->count_by_search($it618sql,'',$_GET['uid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=8>'.$it618_union_lang['s92'].$count.'</td></tr>';
	showsubtitle(array($it618_union_lang['s605'], $it618_union_lang['s595'], $it618_union_lang['s596'], $it618_union_lang['s597'],$it618_union_lang['s296'],$it618_union_lang['s598'],$it618_union_lang['s91']));
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
	}
	
	foreach(C::t('#it618_union#it618_union_saletc')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['uid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_saletc) {
		
		if($it618_union_saletc['it618_saletype']=='it618_brand'){
			if($it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_brand',$it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_brand','shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_brand_goods['it618_name'].'</a>';
				
				if($it618_brand_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_brand_sale['it618_count'];
				
				$saletime=$it618_brand_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_video'){
			if($it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_video',$it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_video','video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a>';
				
				if($it618_video_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_video#it618_video_goods_type')->fetch_it618_name_by_id($it618_video_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_video_sale['it618_count'];
				
				$saletime=$it618_video_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_exam'){
			if($it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_exam',$it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_exam','exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a>';
				
				if($it618_exam_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_exam_sale['it618_count'];
				
				$saletime=$it618_exam_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_group'){
			
			if($it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
				$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
				$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
				$it618_unit=it618_union_getvipgoodsunit($it618_group_goods);
	
				//$goodspic=it618_union_getgoodspic_plugin('it618_group',0,$it618_group_goods['id'],$it618_group_goods['it618_picbig']);
				$goodspic=$it618_group_group['it618_ico'];
				$goodsname=$grouptitle.' '.$it618_unit;
				$goodsurl=it618_union_getrewrite_plugin('it618_group','group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
				
				if($it618_group_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_group#it618_group_goods_type')->fetch_it618_name_by_id($it618_group_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_group_sale['it618_count'];
				
				$saletime=$it618_group_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_tuan'){
			if($it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_tuan',$it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_tuan','tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_tuan_goods['it618_name'].'</a>';
				
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_tuan_sale['it618_count'];
				
				$saletime=$it618_tuan_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_credits_cz'){
			$it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/credits.png';
			$goodsname=$it618_union_lang['s992'].$it618_credits_sale['it618_jfcount'].$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
			$gtypename='';
			$goodcount='';
			$saletime=$it618_credits_sale['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_credits_buygroup'){
			$it618_credits_buygroup_sale=C::t('#it618_credits#it618_credits_buygroup_sale')->fetch_by_id($it618_union_saletc['it618_saleid']);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_credits_buygroup_sale['it618_groupid']);
			
			if($it618_credits_buygroup_sale['it618_unit']==1)$it618_unit=$it618_union_lang['s1021'];
			if($it618_credits_buygroup_sale['it618_unit']==2)$it618_unit=$it618_union_lang['s1022'];
			if($it618_credits_buygroup_sale['it618_unit']==3)$it618_unit=$it618_union_lang['s1023'];
			
			$goodspic='source/plugin/it618_union/images/credits.png';
			$goodsname=$it618_union_lang['s993'].$it618_credits_buygroup_sale['it618_days'].$it618_unit.$grouptitle;
			$gtypename='';
			$goodcount='';
			$saletime=$it618_credits_buygroup_sale['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_waimai'){
			$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($it618_union_saletc['it618_saleid']);
			$goodsnametmp=str_replace("{name}",$union_waimai_name,$it618_union_lang['s994']);
			
			$goodspic='source/plugin/it618_union/images/waimai.png';
			$goodsname=$goodsnametmp;
			$gtypename='';
			$goodcount='';
			$saletime=$it618_waimai_gwcsale_main['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_sale_fl'){
			$it618_sale_money=C::t('#it618_sale#it618_sale_money')->fetch_by_id($it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_sale/images/logo.png';
			$goodsname=$it618_sale_money['it618_pname'];
			$gtypename=$it618_sale_money['it618_saleid'];
			$goodcount=$it618_sale_money['it618_count'];
			$saletime=$it618_sale_money['it618_time1'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_paotui'){
			$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($it618_union_saletc['it618_saleid']);
			$goodsnametmp=str_replace("{name}",$union_paotui_name,$it618_union_lang['s994']);
			
			$goodspic='source/plugin/it618_union/images/paotui.png';
			$goodsname=$goodsnametmp;
			$gtypename='';
			$goodcount='';
			$saletime=$it618_paotui_sale['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_witkey_post'){
			$it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE id=".$it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/witkey.png';
			$goodsname=it618_union_witkey_rewriteurl('<a href="forum.php?mod=viewthread&tid='.$it618_witkey_main['it618_tid'].'" target="_blank">'.$it618_witkey_main['it618_title'].'</a>');
			$gtypename='';
			$goodcount='';
			$saletime=$it618_union_saletc['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_witkey_get'){
			$it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE id=".$it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/witkey.png';
			$goodsname=it618_union_witkey_rewriteurl('<a href="forum.php?mod=viewthread&tid='.$it618_witkey_main['it618_tid'].'" target="_blank">'.$it618_witkey_main['it618_title'].'</a>');
			$gtypename='';
			$goodcount='';
			$saletime=$it618_union_saletc['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_wike_post'){
			$it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE id=".$it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/wike.png';
			$goodsname=it618_union_wike_rewriteurl('<a href="forum.php?mod=viewthread&tid='.$it618_wike_main['it618_tid'].'" target="_blank">'.$it618_wike_main['it618_title'].'</a>');
			$gtypename='';
			$goodcount='';
			$saletime=$it618_union_saletc['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_wike_get'){
			$it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE id=".$it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/wike.png';
			$goodsname=it618_union_wike_rewriteurl('<a href="forum.php?mod=viewthread&tid='.$it618_wike_main['it618_tid'].'" target="_blank">'.$it618_wike_main['it618_title'].'</a>');
			$gtypename='';
			$goodcount='';
			$saletime=$it618_union_saletc['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_scoremall'){
			$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$it618_union_saletc['it618_saleid']);
			$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
			
			$goodsurl=it618_union_getrewrite_plugin('it618_scoremall','product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
			
			$goodspic=it618_union_getgoodspic_plugin('it618_scoremall',$it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']);
			$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a>';
			$gtypename='';
			$goodcount='';
			$saletime=$it618_brand_sale['it618_time'];
		}
		
		$salemoneystr='';
		if($it618_union_saletc['it618_salemoney']>0){
			$salemoneystr=$it618_union_saletc['it618_salemoney'].' '.$it618_union_lang['s195'];
		}else{
			for($i=1;$i<=8;$i++){
				if($it618_union_saletc['it618_salecredit'.$i]>0)$salemoneystr.=$it618_union_saletc['it618_salecredit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].' ';
			}
		}
		
		$tcmoneystr='';
		if($it618_union_saletc['it618_tcmoney']>0){
			$tcmoneystr=$it618_union_saletc['it618_tcmoney'].' '.$it618_union_lang['s195'];
		}else{
			for($i=1;$i<=8;$i++){
				if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_saletc['it618_credit'.$i]>0){
					if($_GET['wap']==1){
						$tcmoneystr.=$it618_union_saletc['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
					}else{
						$tcmoneystr.=$it618_union_saletc['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
					}
				}
			}
			if($tcmoneystr!=''){
				$tcmoneystr=$tcmoneystr.'@';
				$tcmoneystr=str_replace(', @','',$tcmoneystr);
			}
		}
		
		if($it618_union_saletc['it618_type']==1){
			$tmpuser=$it618_union_lang['s990'].it618_union_getusername($it618_union_saletc['it618_saleuid']);
		}else{
			$tmpuser=$it618_union_lang['s991'].it618_union_getusername($it618_union_saletc['it618_tuiuidfind']);
		}
		
		showtablerow('', array('', '', '', '', ''), array(
			$it618_union_saletc['id'],
			'<div style="width:480px">
			<img src="'.$goodspic.'" width="38" height="38" style="float:left;margin-right:6px" align="absmiddle"/>
			<div style="width:410px;float:left;line-height:20px;text-align:left">'.$goodsname.'<br><font color=#999>'.$gtypename.' '.$goodcount.'</font> <font color=#390>'.$tmpuser.'</font>
			</div>',
			'<font color=#f60>'.$salemoneystr.'</font>',
			'<font color=#f60>'.$tcmoneystr.'</font>',
			'<a href="'.it618_union_rewriteurl($it618_union_saletc['it618_uid']).'" target="_blank">'.it618_union_getusername($it618_union_saletc['it618_uid']).'</a>',
			'<font color=#999>'.date('Y-m-d H:i:s', $saletime).'</font>',
			'<font color=#999>'.date('Y-m-d H:i:s', $it618_union_saletc['it618_time']).'</font>'
		));
	}

echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=11)return;
	showtablefooter();
	echo '<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>
	<script>
	laydate.render({
	  elem: "#it618_time1"
	});
	laydate.render({
	  elem: "#it618_time2"
	});
	</script>';
?>