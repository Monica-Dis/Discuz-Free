<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/templateset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/templateset.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/templateset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$union_template_set[\'pcname\']=\''.trim($_GET['template_pcname'])."';\n";
		$fileData .= '$union_template_set[\'wapname\']=\''.trim($_GET['template_wapname'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_union_lang['s1243'], "action=plugins&identifier=$identifier&cp=admin_template&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

$pcnameoption='<option value="default">'.$it618_union_lang['s1236'].'</option><option value="default_dz">'.$it618_union_lang['s1242'].'</option>';
$pcnameoption=str_replace('<option value="'.$union_template_set['pcname'].'"','<option value="'.$union_template_set['pcname'].'" selected="selected"',$pcnameoption);

$wapnameoption='<option value="default_wap">'.$it618_union_lang['s1236'].'</option>';
$wapnameoption=str_replace('<option value="'.$union_template_set['wapname'].'"','<option value="'.$union_template_set['wapname'].'" selected="selected"',$wapnameoption);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_template&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_union_lang['s1234'].'</th></tr>
<tr class="header"><th width=180>'.$it618_union_lang['s1237'].'</th><th>'.$it618_union_lang['s1238'].'</th><th>'.$it618_union_lang['s1239'].'</th></tr>

<tr class="hover">
<td>'.$it618_union_lang['s1241'].'</td><td class="longtxt">
<select name="template_pcname">
	'.$pcnameoption.'
</select></td>
<td>'.$it618_union_lang['s1240'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_union_lang['s1235'].'</td><td class="longtxt">
<select name="template_wapname">
	'.$wapnameoption.'
</select></td>
<td>'.$it618_union_lang['s1240'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_union_lang['s19']);

if(count($reabc)!=11)return;
showtablefooter();

?>