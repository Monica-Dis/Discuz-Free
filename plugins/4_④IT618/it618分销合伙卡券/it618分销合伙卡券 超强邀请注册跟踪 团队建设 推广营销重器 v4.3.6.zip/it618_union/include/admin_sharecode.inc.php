<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_union_sharecode_class=C::t('#it618_union#it618_union_sharecode_class')->fetch_by_id($_GET['cid']);

$it618sql='1=1';
$urlsql.='&cid='.intval($_GET['cid']);

if($_GET['class']=='yqreg'){$classname=$it618_union_lang['s355'];$it618sql.=" and it618_class='yqreg'";$urlsql.='&class=yqreg';}
if($_GET['class']=='shop'){$classname=$it618_union_lang['s356'];$it618sql.=" and it618_class='shop'";$urlsql.='&class=shop';}
if($_GET['class']=='product'){$classname=$it618_union_lang['s357'];$it618sql.=" and it618_class='product'";$urlsql.='&class=product';}
if($_GET['class']=='tui'){$classname=$it618_union_lang['s358'];$it618sql.=" and it618_class='tui'";$urlsql.='&class=tui';}
if($classname!='')$classname=' -> '.$classname;

if($_GET['type']=='txt'){
	$typename=$it618_union_lang['s352'];$aboutstr=$it618_union_lang['s386'];$it618sql.=" and it618_type='txt'";$urlsql.='&type=txt';
	if($_GET['class']=='yqreg')$bqstr=$it618_union_lang['s394'].$it618_union_lang['s396'];
	if($_GET['class']=='shop')$bqstr=$it618_union_lang['s398'].$it618_union_lang['s396'];
	if($_GET['class']=='product')$bqstr=$it618_union_lang['s400'].$it618_union_lang['s396'];
	if($_GET['class']=='tui')$bqstr=$it618_union_lang['s402'].$it618_union_lang['s396'];
}
if($_GET['type']=='img'){
	$typename=$it618_union_lang['s353'];$aboutstr=$it618_union_lang['s387'];$it618sql.=" and it618_type='img'";$urlsql.='&type=img';
	if($_GET['class']=='yqreg')$bqstr=$it618_union_lang['s395'].$it618_union_lang['s397'];
	if($_GET['class']=='shop')$bqstr=$it618_union_lang['s399'].$it618_union_lang['s397'];
	if($_GET['class']=='product')$bqstr=$it618_union_lang['s401'].$it618_union_lang['s397'];
	if($_GET['class']=='tui')$bqstr=$it618_union_lang['s403'].$it618_union_lang['s397'];
	
}
if($_GET['type']=='bgimg'){$typename=$it618_union_lang['s354'];$aboutstr=$it618_union_lang['s388'];$it618sql.=" and it618_type='bgimg'";$urlsql.='&type=bgimg';}
if($typename!='')$typename=' -> '.$typename;



if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;

	if($reabc[8]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_union#it618_union_sharecode')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_about'])) {

		foreach($_GET['it618_about'] as $id => $val) {
			
			$it618_width=intval($_GET['it618_width'][$id]/2);
			$it618_height=intval($_GET['it618_height'][$id]/2);
			$it618_radius=trim($_GET['it618_radius'][$id]);
			if($it618_radius>$it618_width)$it618_radius=$it618_width;
			if($it618_radius>$it618_height)$it618_radius=$it618_height;
			
			$tmparr=explode("{codeimgsrc}",trim($_GET['it618_img'][$id]));
			if(count($tmparr)>1){
				$it618_radius=0;
			}

			C::t('#it618_union#it618_union_sharecode')->update($id,array(
				'it618_content' => trim($_GET['it618_content'][$id]),
				'it618_length' => trim($_GET['it618_length'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_left' => trim($_GET['it618_left'][$id]),
				'it618_top' => trim($_GET['it618_top'][$id]),
				'it618_width' => trim($_GET['it618_width'][$id]),
				'it618_height' => trim($_GET['it618_height'][$id]),
				'it618_radius' => $it618_radius,
				'it618_opacity' => trim($_GET['it618_opacity'][$id]),
				'it618_fontid' => trim($_GET['it618_fontid'][$id]),
				'it618_fontsize' => trim($_GET['it618_fontsize'][$id]),
				'it618_fontcolor' => trim($_GET['it618_fontcolor'][$id]),
				'it618_about' => trim($_GET['it618_about'][$id]),
				'it618_isok' => trim($_GET['it618_isok'][$id])
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_content_array = !empty($_GET['newit618_content']) ? $_GET['newit618_content'] : array();
	$newit618_img_array = !empty($_GET['newit618_img']) ? $_GET['newit618_img'] : array();
	$newit618_left_array = !empty($_GET['newit618_left']) ? $_GET['newit618_left'] : array();
	$newit618_top_array = !empty($_GET['newit618_top']) ? $_GET['newit618_top'] : array();
	$newit618_width_array = !empty($_GET['newit618_width']) ? $_GET['newit618_width'] : array();
	$newit618_height_array = !empty($_GET['newit618_height']) ? $_GET['newit618_height'] : array();
	$newit618_radius_array = !empty($_GET['newit618_radius']) ? $_GET['newit618_radius'] : array();
	$newit618_fontsize_array = !empty($_GET['newit618_fontsize']) ? $_GET['newit618_fontsize'] : array();
	$newit618_fontcolor_array = !empty($_GET['newit618_fontcolor']) ? $_GET['newit618_fontcolor'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	
	foreach($newit618_about_array as $key => $value) {
		
		$it618_width=intval(trim($newit618_width_array[$key])/2);
		$it618_height=intval(trim($newit618_height_array[$key])/2);
		$it618_radius=trim($_GET['it618_radius'][$id]);
		if($it618_radius>$it618_width)$it618_radius=$it618_width;
		if($it618_radius>$it618_height)$it618_radius=$it618_height;
		
		$tmparr=explode("{codeimgsrc}",trim($newit618_img_array[$key]));
		if(count($tmparr)>1){
			$it618_radius=0;
		}
		
		C::t('#it618_union#it618_union_sharecode')->insert(array(
			'it618_cid' => $_GET['cid'],
			'it618_class' => $_GET['class'],
			'it618_type' => $_GET['type'],
			'it618_content' => trim($newit618_content_array[$key]),
			'it618_img' => trim($newit618_img_array[$key]),
			'it618_left' => trim($newit618_left_array[$key]),
			'it618_top' => trim($newit618_top_array[$key]),
			'it618_width' => trim($newit618_width_array[$key]),
			'it618_height' => trim($newit618_height_array[$key]),
			'it618_radius' => $it618_radius,
			'it618_fontsize' => trim($newit618_fontsize_array[$key]),
			'it618_fontcolor' => trim($newit618_fontcolor_array[$key]),
			'it618_about' => trim($newit618_about_array[$key]),
		), true);
		$ok2=$ok2+1;
	}
	
	cpmsg($it618_union_lang['s7'].$ok1.' '.$it618_union_lang['s8'].$ok2.' '.$it618_union_lang['s9'].$del, "action=plugins&identifier=$identifier&cp=admin_sharecode&pmod=admin_sharecode&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=11)return;

$preurl=ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_sharecode_class&pmod=admin_sharecode&operation=$operation&do=$do";

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_sharecode&pmod=admin_sharecode&operation=$operation&do=$do".$urlsql);
showtableheaders('<a href="'.$preurl.'">'.$it618_union_lang['s405'].'</a> -> '.$it618_union_sharecode_class['it618_name'].$classname.$typename,'it618_union_sharecode');
	$count = C::t('#it618_union#it618_union_sharecode')->count_all_by_search($it618sql,'',$_GET['cid']);
	
	if($bqstr!='')echo '<tr><td colspan=9 style="color:green">'.$bqstr.'</span></td></tr>';
	echo '<tr><td colspan=9>'.$it618_union_lang['s385'].$count.'<span style="float:right;color:red">'.$aboutstr.'</span></td></tr>';
	
	if($_GET['type']=='txt'){
		showsubtitle(array('', $it618_union_lang['s376'].'/'.$it618_union_lang['s390'], $it618_union_lang['s359'], $it618_union_lang['s377'].'/'.$it618_union_lang['s378'], $it618_union_lang['s391'], $it618_union_lang['s379'],$it618_union_lang['s380'],$it618_union_lang['s381'],$it618_union_lang['s384']));
	}
	
	if($_GET['type']=='img'){
		showsubtitle(array('', $it618_union_lang['s383'], $it618_union_lang['s390'], $it618_union_lang['s379'],$it618_union_lang['s380'],$it618_union_lang['s381'],$it618_union_lang['s382'],$it618_union_lang['s831'],$it618_union_lang['s832'],$it618_union_lang['s384']));
	}
	
	if($_GET['type']=='bgimg'){
		showsubtitle(array('', $it618_union_lang['s383'], $it618_union_lang['s390'], $it618_union_lang['s384']));
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_union_sharecode_font')." ORDER BY it618_order");
	while($it618_union_sharecode_font =	DB::fetch($query)) {
		$fontselectstr.='<option value="'.$it618_union_sharecode_font['id'].'">'.$it618_union_sharecode_font['it618_name'].'</font>';
	}
	
	foreach(C::t('#it618_union#it618_union_sharecode')->fetch_all_by_search(
		$it618sql,'it618_isok desc',$_GET['cid'],0,1000
	) as $it618_union_sharecode) {
		
		if($it618_union_sharecode['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		if($it618_union_sharecode['it618_fontcolor']=='')$it618_fontcolor='#000';else $it618_fontcolor=$it618_union_sharecode['it618_fontcolor'];
		
		$fontselectstr1=str_replace('value="'.$it618_union_sharecode['it618_fontid'].'">','value="'.$it618_union_sharecode['it618_fontid'].'" selected="selected">',$fontselectstr);
		
		if($_GET['type']=='txt'){
			showtablerow('', array('class="td25"', '', '', ''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_union_sharecode[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_union_sharecode[id]]\" value=\"$it618_union_sharecode[id]\">",
				'<textarea class="txt" style="width:300px;height:40px" name="it618_content['.$it618_union_sharecode['id'].']">'.$it618_union_sharecode['it618_content'].'</textarea><br><input type="text" class="txt" style="width:300px;margin-top:3px" name="it618_about['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_about'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_length['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_length'].'">',
				'<select name="it618_fontid['.$it618_union_sharecode['id'].']">'.$fontselectstr1.'</select><br>'."<div style=\"margin-top:3px\"><input id=\"c".$it618_union_sharecode['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_fontcolor[$it618_union_sharecode[id]]\" value=\"$it618_fontcolor\" onchange=\"updatecolorpreview('c".$it618_union_sharecode['id']."')\"><input id=\"c".$it618_union_sharecode['id']."\" onclick=\"c".$it618_union_sharecode['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_union_sharecode['id']."|c".$it618_union_sharecode['id']."_v';showMenu({'ctrlid':'c".$it618_union_sharecode['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_union_sharecode['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_union_sharecode['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span></div>",
				'<input type="text" class="txt" style="width:50px;" name="it618_fontsize['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_fontsize'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_left['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_left'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_top['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_top'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_width['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_width'].'">',
				'<input class="checkbox" type="checkbox" name="it618_isok['.$it618_union_sharecode['id'].']" '.$it618_isok_checked.' value="1">'
			));
			
			$tmpcolorjs.="updatecolorpreview('c".$it618_union_sharecode['id']."');";
		}
		
		if($_GET['type']=='img'){
			showtablerow('', array('class="td25"', '', '', ''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_union_sharecode[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_union_sharecode[id]]\" value=\"$it618_union_sharecode[id]\">",
				'<img src="'.$it618_union_sharecode['it618_img'].'" id="img'.$it618_union_sharecode['id'].'" height="60" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" style="width:150px" id="url'.$it618_union_sharecode['id'].'" name="it618_img['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_img'].'" /> <input type="button" id="image'.$it618_union_sharecode['id'].'" value="'.$it618_union_lang['s67'].'" />',
				'<input type="text" class="txt" style="width:190px;" name="it618_about['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_about'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_left['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_left'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_top['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_top'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_width['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_width'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_height['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_height'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_radius['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_radius'].'">',
				'<input type="text" class="txt" style="width:50px;" name="it618_opacity['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_opacity'].'">',
				'<input class="checkbox" type="checkbox" name="it618_isok['.$it618_union_sharecode['id'].']" '.$it618_isok_checked.' value="1">'
			));
			
			$editorjs.='K(\'#image'.$it618_union_sharecode['id'].'\').click(function() {
				  editor.loadPlugin(\'image\', function() {
					  editor.plugin.imageDialog({
						  imageUrl : K(\'#url'.$it618_union_sharecode['id'].'\').val(),
						  clickFn : function(url, title, width, height, border, align) {
							  K(\'#url'.$it618_union_sharecode['id'].'\').val(url);
							  K(\'#img'.$it618_union_sharecode['id'].'\').attr(\'src\',url);
							  editor.hideDialog();
						  }
					  });
				  });
			  });
			  ';
		}
		
		if($_GET['type']=='bgimg'){
			showtablerow('', array('class="td25"', '', '', ''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_union_sharecode[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_union_sharecode[id]]\" value=\"$it618_union_sharecode[id]\">",
				'<img src="'.$it618_union_sharecode['it618_img'].'" id="img'.$it618_union_sharecode['id'].'" height="60" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" style="width:300px" id="url'.$it618_union_sharecode['id'].'" name="it618_img['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_img'].'" /> <input type="button" id="image'.$it618_union_sharecode['id'].'" value="'.$it618_union_lang['s67'].'" />',
				'<input type="text" class="txt" style="width:190px;" name="it618_about['.$it618_union_sharecode['id'].']" value="'.$it618_union_sharecode['it618_about'].'">',
				'<input class="checkbox" type="checkbox" name="it618_isok['.$it618_union_sharecode['id'].']" '.$it618_isok_checked.' value="1">'
			));
			
			$editorjs.='K(\'#image'.$it618_union_sharecode['id'].'\').click(function() {
				  editor.loadPlugin(\'image\', function() {
					  editor.plugin.imageDialog({
						  imageUrl : K(\'#url'.$it618_union_sharecode['id'].'\').val(),
						  clickFn : function(url, title, width, height, border, align) {
							  K(\'#url'.$it618_union_sharecode['id'].'\').val(url);
							  K(\'#img'.$it618_union_sharecode['id'].'\').attr(\'src\',url);
							  editor.hideDialog();
						  }
					  });
				  });
			  });
			  ';
		}
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo '
<link rel="stylesheet" href="source/plugin/it618_union/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_union/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_union/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
	$it618_union_lang184=$it618_union_lang['s389'];
	
	if($_GET['type']=='txt'){
		echo <<<EOT
			<script type="text/JavaScript">
			var rowtypedata;
			function rundata(){
				var n=document.getElementsByName("newit618_content[]").length;
			
				return [
				[[1,''], [1,'<textarea class="txt" style=\"width:300px;height:40px\" name="newit618_content[]"></textarea><br><input type="text" class="txt" style=\"width:300px;margin-bottom:3px\" name="newit618_about[]">'], [1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_length[]" value=\"0\">'], [1,'$it618_union_lang184<br><div style="margin-top:3px"><input id="c_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_fontcolor[]" value=\"#000\" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background:#000"><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span></div>'], [1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_fontsize[]">'], [1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_left[]">'], [1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_top[]">'], [1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_width[]">'], [1, '$it618_union_lang184']]
				];
			}
			rowtypedata=rundata();
			$tmpcolorjs
			</script>
EOT;
	}
	
	if($_GET['type']=='img'){
		echo <<<EOT
			<script type="text/JavaScript">
			var rowtypedata;
			function rundata(){
				return [
				[[1,''], [1, '$it618_union_lang184'], [1,'<input type="text" class="txt" style=\"width:190px\" name="newit618_about[]">'], [1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_left[]">'], [1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_top[]">'], [1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_width[]">'], [1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_height[]">'],[1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_radius[]">'],[1,'<input type="text" class="txt" style=\"width:50px\" name="newit618_opacity[]">'], [1, '$it618_union_lang184']]
				];
			}
			rowtypedata=rundata();
			</script>
EOT;
	}
	
	if($_GET['type']=='bgimg'){
		echo <<<EOT
			<script type="text/JavaScript">
			var rowtypedata;
			function rundata(){
				return [
				[[1,''], [1, '$it618_union_lang184'], [1,'<input type="text" class="txt" style=\"width:190px\" name="newit618_about[]">'], [1, '$it618_union_lang184']]
				];
			}
			rowtypedata=rundata();
			</script>
EOT;
	}
	
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=11)return;
showtablefooter();
?>