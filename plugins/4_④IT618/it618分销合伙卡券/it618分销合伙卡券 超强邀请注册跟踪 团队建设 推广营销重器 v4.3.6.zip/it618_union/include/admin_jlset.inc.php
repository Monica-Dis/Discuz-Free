<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php';
}

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {		
		$jl_times=intval($_GET['jl_times']);
		if($jl_times==0)$jl_times=3;
		$fileData = '$jl_times=\''.$jl_times."';\n";
		$fileData .= '$jl_group_isok1=\''.dhtmlspecialchars($_GET['jl_group_isok1'])."';\n";
		$fileData .= '$jl_group1=\''.intval($_GET['jl_group1'])."';\n";
		$fileData .= '$jl_tuicount_isok1=\''.dhtmlspecialchars($_GET['jl_tuicount_isok1'])."';\n";
		$fileData .= '$jl_tuicount1=\''.intval($_GET['jl_tuicount1'])."';\n";
		$fileData .= '$jl_do_isok1=\''.dhtmlspecialchars($_GET['jl_do_isok1'])."';\n";
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$fileData .= '$jl_credit11['.$i.']=\''.intval($_GET['jl_credit11'.$i])."';\n";
				$fileData .= '$jl_credit12['.$i.']=\''.intval($_GET['jl_credit12'.$i])."';\n";
			}
		}
		
		$fileData .= '$jl_group_isok2=\''.dhtmlspecialchars($_GET['jl_group_isok2'])."';\n";
		$fileData .= '$jl_group2=\''.intval($_GET['jl_group2'])."';\n";
		$fileData .= '$jl_tuicount_isok2=\''.dhtmlspecialchars($_GET['jl_tuicount_isok2'])."';\n";
		$fileData .= '$jl_tuicount2=\''.intval($_GET['jl_tuicount2'])."';\n";
		$fileData .= '$jl_do_isok2=\''.dhtmlspecialchars($_GET['jl_do_isok2'])."';\n";
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$fileData .= '$jl_credit21['.$i.']=\''.intval($_GET['jl_credit21'.$i])."';\n";
				$fileData .= '$jl_credit22['.$i.']=\''.intval($_GET['jl_credit22'.$i])."';\n";
			}
		}
		
		$fileData .= '$jl_group_isok3=\''.dhtmlspecialchars($_GET['jl_group_isok3'])."';\n";
		$fileData .= '$jl_group3=\''.intval($_GET['jl_group3'])."';\n";
		$fileData .= '$jl_tuicount_isok3=\''.dhtmlspecialchars($_GET['jl_tuicount_isok3'])."';\n";
		$fileData .= '$jl_tuicount3=\''.intval($_GET['jl_tuicount3'])."';\n";
		$fileData .= '$jl_do_isok3=\''.dhtmlspecialchars($_GET['jl_do_isok3'])."';\n";
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$fileData .= '$jl_credit31['.$i.']=\''.intval($_GET['jl_credit31'.$i])."';\n";
				$fileData .= '$jl_credit32['.$i.']=\''.intval($_GET['jl_credit32'.$i])."';\n";
			}
		}
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_union_lang['s20'], "action=plugins&identifier=$identifier&cp=admin_jlset&pmod=admin_jlset&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_jlset&pmod=admin_jlset&operation=$operation&do=$do");
showtableheaders($it618_union_lang['s11'],'it618_union_set');

if($jl_group_isok1==1)$jl_group_isok1_checked='checked="checked"';else $jl_group_isok1_checked="";
if($jl_tuicount_isok1==1)$jl_tuicount_isok1_checked='checked="checked"';else $jl_tuicount_isok1_checked="";
if($jl_do_isok1==1)$jl_do_isok1_checked='checked="checked"';else $jl_do_isok1_checked="";

if($jl_group_isok2==1)$jl_group_isok2_checked='checked="checked"';else $jl_group_isok2_checked="";
if($jl_tuicount_isok2==1)$jl_tuicount_isok2_checked='checked="checked"';else $jl_tuicount_isok2_checked="";
if($jl_do_isok2==1)$jl_do_isok2_checked='checked="checked"';else $jl_do_isok2_checked="";

if($jl_group_isok3==1)$jl_group_isok3_checked='checked="checked"';else $jl_group_isok3_checked="";
if($jl_tuicount_isok3==1)$jl_tuicount_isok3_checked='checked="checked"';else $jl_tuicount_isok3_checked="";
if($jl_do_isok3==1)$jl_do_isok3_checked='checked="checked"';else $jl_do_isok3_checked="";

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$it618_credit11.=$_G['setting']['extcredits'][$i]['title'].'=<input type="text" class="txt" style="width:50px;color:red" name="jl_credit11'.$i.'" value="'.$jl_credit11[$i].'"> ';
		$it618_credit12.=$_G['setting']['extcredits'][$i]['title'].'=<input type="text" class="txt" style="width:50px;color:#f0f" name="jl_credit12'.$i.'" value="'.$jl_credit12[$i].'"> ';
		
		$it618_credit21.=$_G['setting']['extcredits'][$i]['title'].'=<input type="text" class="txt" style="width:50px;color:red" name="jl_credit21'.$i.'" value="'.$jl_credit21[$i].'"> ';
		$it618_credit22.=$_G['setting']['extcredits'][$i]['title'].'=<input type="text" class="txt" style="width:50px;color:#f0f" name="jl_credit22'.$i.'" value="'.$jl_credit22[$i].'"> ';
		
		$it618_credit31.=$_G['setting']['extcredits'][$i]['title'].'=<input type="text" class="txt" style="width:50px;color:red" name="jl_credit31'.$i.'" value="'.$jl_credit31[$i].'"> ';
		$it618_credit32.=$_G['setting']['extcredits'][$i]['title'].'=<input type="text" class="txt" style="width:50px;color:#f0f" name="jl_credit32'.$i.'" value="'.$jl_credit32[$i].'"> ';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('common_usergroup'));
while($common_usergroup = DB::fetch($query)) {
	$tmpgroup1.='<option value="'.$common_usergroup['groupid'].'">'.$common_usergroup[grouptitle].'</option>';
	$tmpgroup2.='<option value="'.$common_usergroup['groupid'].'">'.$common_usergroup[grouptitle].'</option>';
	$tmpgroup3.='<option value="'.$common_usergroup['groupid'].'">'.$common_usergroup[grouptitle].'</option>';
}
$tmpgroup1=str_replace('<option value="'.$jl_group1.'">','<option value="'.$jl_group1.'" selected="selected">',$tmpgroup1);
$tmpgroup2=str_replace('<option value="'.$jl_group2.'">','<option value="'.$jl_group2.'" selected="selected">',$tmpgroup2);
$tmpgroup3=str_replace('<option value="'.$jl_group3.'">','<option value="'.$jl_group3.'" selected="selected">',$tmpgroup3);

echo '
<tr><td>'.$it618_union_lang['s21'].'<input type="text" class="txt" style="width:50px;color:blue" name="jl_times" value="'.$jl_times.'">'.$it618_union_lang['s36'].'</td></tr>
<tr><td><font color=red>'.$it618_union_lang['s22'].'</font></td></tr>
<tr><td style="background-color:#f1f1f1"><span style="float:right"><input type="checkbox" id="jl_do_isok1" name="jl_do_isok1" value="1" style="vertical-align:middle" '.$jl_do_isok1_checked.'><label for="jl_do_isok1" style="color:green">'.$it618_union_lang['s23'].'</label></span><b>'.$it618_union_lang['s664'].'</b></td></tr>
<tr><td><input type="checkbox" id="jl_tuicount_isok1" name="jl_tuicount_isok1" value="1" style="vertical-align:middle" '.$jl_tuicount_isok1_checked.'><label for="jl_tuicount_isok1" style="color:blue">'.$it618_union_lang['s26'].'</label> <input type="text" class="txt" style="width:50px;color:blue" name="jl_tuicount1" value="'.$jl_tuicount1.'">'.$it618_union_lang['s28'].' <input type="checkbox" id="jl_group_isok1" name="jl_group_isok1" value="1" style="vertical-align:middle" '.$jl_group_isok1_checked.'><label for="jl_group_isok1" style="color:blue">'.$it618_union_lang['s24'].'</label> <select name="jl_group1">'.$tmpgroup1.'</select> </td></tr>
<tr><td>'.$it618_union_lang['s27'].'</td></tr>
<tr><td>'.$it618_union_lang['s157'].' '.$it618_credit11.'</td></tr>
<tr><td>'.$it618_union_lang['s159'].' '.$it618_credit12.'</td></tr>

<tr><td style="background-color:#f1f1f1"><span style="float:right"><input type="checkbox" id="jl_do_isok2" name="jl_do_isok2" value="1" style="vertical-align:middle" '.$jl_do_isok2_checked.'><label for="jl_do_isok2" style="color:green">'.$it618_union_lang['s23'].'</label></span><b>'.$it618_union_lang['s665'].'</b></td></tr>
<tr><td><input type="checkbox" id="jl_tuicount_isok2" name="jl_tuicount_isok2" value="1" style="vertical-align:middle" '.$jl_tuicount_isok2_checked.'><label for="jl_tuicount_isok2" style="color:blue">'.$it618_union_lang['s26'].'</label> <input type="text" class="txt" style="width:50px;color:blue" name="jl_tuicount2" value="'.$jl_tuicount2.'">'.$it618_union_lang['s28'].' <input type="checkbox" id="jl_group_isok2" name="jl_group_isok2" value="1" style="vertical-align:middle" '.$jl_group_isok2_checked.'><label for="jl_group_isok2" style="color:blue">'.$it618_union_lang['s24'].'</label> <select name="jl_group2">'.$tmpgroup2.'</select> </td></tr>
<tr><td>'.$it618_union_lang['s27'].'</td></tr>
<tr><td>'.$it618_union_lang['s157'].' '.$it618_credit21.'</td></tr>
<tr><td>'.$it618_union_lang['s159'].' '.$it618_credit22.'</td></tr>

<tr><td style="background-color:#f1f1f1"><span style="float:right"><input type="checkbox" id="jl_do_isok3" name="jl_do_isok3" value="1" style="vertical-align:middle" '.$jl_do_isok3_checked.'><label for="jl_do_isok3" style="color:green">'.$it618_union_lang['s23'].'</label></span><b>'.$it618_union_lang['s666'].'</b></td></tr>
<tr><td><input type="checkbox" id="jl_tuicount_isok3" name="jl_tuicount_isok3" value="1" style="vertical-align:middle" '.$jl_tuicount_isok3_checked.'><label for="jl_tuicount_isok3" style="color:blue">'.$it618_union_lang['s26'].'</label> <input type="text" class="txt" style="width:50px;color:blue" name="jl_tuicount3" value="'.$jl_tuicount3.'">'.$it618_union_lang['s28'].' <input type="checkbox" id="jl_group_isok3" name="jl_group_isok3" value="1" style="vertical-align:middle" '.$jl_group_isok3_checked.'><label for="jl_group_isok3" style="color:blue">'.$it618_union_lang['s24'].'</label> <select name="jl_group3">'.$tmpgroup3.'</select> </td></tr>
<tr><td>'.$it618_union_lang['s27'].'</td></tr>
<tr><td>'.$it618_union_lang['s157'].' '.$it618_credit31.'</td></tr>
<tr><td>'.$it618_union_lang['s159'].' '.$it618_credit32.'</td></tr>
';

showsubmit('it618submit', $it618_union_lang['s19']);

if(count($reabc)!=11)return;
showtablefooter();

?>