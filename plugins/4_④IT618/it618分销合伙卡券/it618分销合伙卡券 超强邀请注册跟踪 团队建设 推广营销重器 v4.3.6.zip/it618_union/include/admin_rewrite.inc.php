<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$union_home=\''.'union'."';\n";
		$fileData .= '$union_wap=\''.'union_wap'."';\n";
		$fileData .= '$union_yq=\''.'reg'."';\n";
		$fileData .= '$union_uc=\''.'union_uc'."';\n";
		$fileData .= '$union_quans=\''.'union_quans'."';\n";
		$fileData .= '$union_quan=\''.'union_quan'."';\n";
		$fileData .= '$union_tuis=\''.'union_tuis'."';\n";
		$fileData .= '$union_tui=\''.'union_tui'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$union_home1=\''.$urltype."';\n";
		$fileData .= '$union_wap1=\'-{pagetype}-{cid}'.$urltype."';\n";
		$fileData .= '$union_yq1=\'-{tuiuid}'.$urltype."';\n";
		$fileData .= '$union_uc1=\'-{pagetype}'.$urltype."';\n";
		$fileData .= '$union_quans1=\''.$urltype."';\n";
		$fileData .= '$union_quan1=\'-{qid}'.$urltype."';\n";
		$fileData .= '$union_tuis1=\''.$urltype."';\n";
		$fileData .= '$union_tui1=\'-{tid}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$union_home=\''.str_replace("-","",dhtmlspecialchars($_GET['union_home']))."';\n";
		$fileData .= '$union_wap=\''.str_replace("-","",dhtmlspecialchars($_GET['union_wap']))."';\n";
		$fileData .= '$union_yq=\''.str_replace("-","",dhtmlspecialchars($_GET['union_yq']))."';\n";
		$fileData .= '$union_uc=\''.str_replace("-","",dhtmlspecialchars($_GET['union_uc']))."';\n";
		$fileData .= '$union_quans=\''.str_replace("-","",dhtmlspecialchars($_GET['union_quans']))."';\n";
		$fileData .= '$union_quan=\''.str_replace("-","",dhtmlspecialchars($_GET['union_quan']))."';\n";
		$fileData .= '$union_tuis=\''.str_replace("-","",dhtmlspecialchars($_GET['union_tuis']))."';\n";
		$fileData .= '$union_tui=\''.str_replace("-","",dhtmlspecialchars($_GET['union_tui']))."';\n";
		
		$urltype=str_replace("-","",dhtmlspecialchars($_GET['urltype']));
		$urltype=str_replace("?","",$urltype);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$union_home1=\''.$urltype."';\n";
		$fileData .= '$union_wap1=\'-{pagetype}-{cid}'.$urltype."';\n";
		$fileData .= '$union_yq1=\'-{tuiuid}'.$urltype."';\n";
		$fileData .= '$union_uc1=\'-{pagetype}'.$urltype."';\n";
		$fileData .= '$union_quans1=\''.$urltype."';\n";
		$fileData .= '$union_quan1=\'-{qid}'.$urltype."';\n";
		$fileData .= '$union_tuis1=\''.$urltype."';\n";
		$fileData .= '$union_tui1=\'-{tid}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_union_lang['s18'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_union_lang['s136'].'</font></td></tr>
<tr><td colspan="3">'.$it618_union_lang['s137'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_union_lang['s138'].'</th><th>'.$it618_union_lang['s139'].'</th><th>'.$it618_union_lang['s140'].'</th></tr>
<tr class="hover">
<td>'.$it618_union_lang['s141'].'</td><td></td><td class="longtxt"><input name="union_home" value="'.$union_home.'"/>'.$union_home.$union_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_union_lang['s147'].'</td><td>{pagetype}, {cid}</td><td class="longtxt"><input name="union_wap" value="'.$union_wap.'"/>'.$union_wap.$union_wap1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_union_lang['s158'].'</td><td>{tuiuid}</td><td class="longtxt"><input name="union_yq" value="'.$union_yq.'"/>'.$union_yq.$union_yq1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_union_lang['s291'].'</td><td>{pagetype}</td><td class="longtxt"><input name="union_uc" value="'.$union_uc.'"/>'.$union_uc.$union_uc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_union_lang['s287'].'</td><td></td><td class="longtxt"><input name="union_quans" value="'.$union_quans.'"/>'.$union_quans.$union_quans1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_union_lang['s288'].'</td><td>{qid}</td><td class="longtxt"><input name="union_quan" value="'.$union_quan.'"/>'.$union_quan.$union_quan1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_union_lang['s289'].'</td><td></td><td class="longtxt"><input name="union_tuis" value="'.$union_tuis.'"/>'.$union_tuis.$union_tuis1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_union_lang['s290'].'</td><td>{tid}</td><td class="longtxt"><input name="union_tui" value="'.$union_tui.'"/>'.$union_tui.$union_tui1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_union_lang['s19']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_union_lang['s148'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_home.$urltype.'$ $1/plugin.php?id=it618_union:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_wap.$urltype.'$ $1/plugin.php?id=it618_union:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_union:wap&pagetype=$2&cid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_union:wap&pagetype=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_yq.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_union:union&tuiuid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_uc.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_union:union_uc&pagetype=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_quans.$urltype.'$ $1/plugin.php?id=it618_union:union_quans&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_quan.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_union:union_quan&qid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_tuis.$urltype.'$ $1/plugin.php?id=it618_union:union_tuis&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$union_tui.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_union:union_tui&tid=$2&%1
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_union_lang['s149'].'</h1>
<pre class="colorbox">
'.$it618_union_lang['s150'].'
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_home.$urltype.'$ plugin.php?id=it618_union:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_wap.$urltype.'$ plugin.php?id=it618_union:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_union:wap&pagetype=$1&cid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_union:wap&pagetype=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_yq.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_union:union&tuiuid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_uc.'-(.+)'.$urltype.'$ plugin.php?id=it618_union:union_uc&pagetype=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_quans.$urltype.'$ plugin.php?id=it618_union:union_quans&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_quan.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_union:union_quan&qid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_tuis.$urltype.'$ plugin.php?id=it618_union:union_tuis&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$union_tui.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_union:union_tui&tid=$1&%1

</pre>

<h1>'.$it618_union_lang['s151'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
RewriteRule ^(.*)/'.$union_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:index&$3
RewriteRule ^(.*)/'.$union_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:wap&$3
RewriteRule ^(.*)/'.$union_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:wap&pagetype=$2&cid=$3&$5
RewriteRule ^(.*)/'.$union_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:wap&pagetype=$2&$4
RewriteRule ^(.*)/'.$union_yq.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:union&tuiuid=$2&$4
RewriteRule ^(.*)/'.$union_uc.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:union_uc&pagetype=$2&$4
RewriteRule ^(.*)/'.$union_quans.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:union_quans&$3
RewriteRule ^(.*)/'.$union_quan.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:union_quan&qid=$2&$4
RewriteRule ^(.*)/'.$union_tuis.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:union_tuis&$3
RewriteRule ^(.*)/'.$union_tui.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_union:union_tui&tid=$2&$4

</pre>

<h1>'.$it618_union_lang['s152'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		&lt;rule name="union_home"&gt;
			&lt;match url="^(.*/)*'.$union_home.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="union_wap"&gt;
			&lt;match url="^(.*/)*'.$union_wap.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="union_wap2"&gt;
			&lt;match url="^(.*/)*'.$union_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="union_wap1"&gt;
			&lt;match url="^(.*/)*'.$union_wap.'-(.+)'.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="union"&gt;
			&lt;match url="^(.*/)*'.$union_yq.'-([0-9]+)'.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:union&amp;amp;tuiuid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="union_uc"&gt;
			&lt;match url="^(.*/)*'.$union_uc.'-(.+)'.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:union_uc&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="union_quans"&gt;
			&lt;match url="^(.*/)*'.$union_quans.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:union_quans&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="union_quan"&gt;
			&lt;match url="^(.*/)*'.$union_quan.'-([0-9]+)'.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:union_quan&amp;amp;qid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="union_tuis"&gt;
			&lt;match url="^(.*/)*'.$union_tuis.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:union_tuis&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="union_tui"&gt;
			&lt;match url="^(.*/)*'.$union_tui.'-([0-9]+)'.$urltype.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_union:union_tui&amp;amp;tid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
match URL into $ with ^(.*)/'.$union_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:index&$2
endif
match URL into $ with ^(.*)/'.$union_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:wap&$2
endif
match URL into $ with ^(.*)/'.$union_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:wap&pagetype=$2&cid=$3&$4
endif
match URL into $ with ^(.*)/'.$union_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:wap&pagetype=$2&$3
endif
match URL into $ with ^(.*)/'.$union_yq.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:union&tuiuid=$2&$3
endif
match URL into $ with ^(.*)/'.$union_uc.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:union_uc&pagetype=$2&$3
endif
match URL into $ with ^(.*)/'.$union_quans.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:union_quans&$2
endif
match URL into $ with ^(.*)/'.$union_quan.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:union_quan&qid=$2&$3
endif
match URL into $ with ^(.*)/'.$union_tuis.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:union_tuis&$2
endif
match URL into $ with ^(.*)/'.$union_tui.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_union:union_tui&tid=$2&$3
endif


</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
rewrite ^([^\.]*)/'.$union_home.$urltype.'$ $1/plugin.php?id=it618_union:index&$2 last;
rewrite ^([^\.]*)/'.$union_wap.$urltype.'$ $1/plugin.php?id=it618_union:wap&$2 last;
rewrite ^([^\.]*)/'.$union_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_union:wap&pagetype=$2&cid=$3&$4 last;
rewrite ^([^\.]*)/'.$union_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_union:wap&pagetype=$2&$3 last;
rewrite ^([^\.]*)/'.$union_yq.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_union:union&tuiuid=$2&$3 last;
rewrite ^([^\.]*)/'.$union_uc.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_union:union_uc&pagetype=$2&$3 last;
rewrite ^([^\.]*)/'.$union_quans.$urltype.'$ $1/plugin.php?id=it618_union:union_quans&$2 last;
rewrite ^([^\.]*)/'.$union_quan.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_union:union_quan&qid=$2&$3 last;
rewrite ^([^\.]*)/'.$union_tuis.$urltype.'$ $1/plugin.php?id=it618_union:union_tuis&$2 last;
rewrite ^([^\.]*)/'.$union_tui.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_union:union_tui&tid=$2&$3 last;
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=10)return;
showtablefooter();

?>