<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_font')." where it618_font!=''");
if($count==0){
	cpmsg($it618_union_lang['s487'], "action=plugins&identifier=$identifier&cp=admin_sharecode_font&pmod=admin_sharecode&operation=$operation&do=$do&page=$page", 'error');
}

if(submitcheck('it618submit_edit')){
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_union#it618_union_sharecode_class')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_isyqreg' => trim($_GET['it618_isyqreg'][$id]),
				'it618_isshop' => trim($_GET['it618_isshop'][$id]),
				'it618_isproduct' => trim($_GET['it618_isproduct'][$id]),
				'it618_istui' => trim($_GET['it618_istui'][$id])
			));
		}
	}

	cpmsg($it618_union_lang['s372'], "action=plugins&identifier=$identifier&cp=admin_sharecode_class&pmod=admin_sharecode&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_ok')){
	$ok=0;
	
	if($reabc[8]!='i')return;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		$it618_union_sharecode_class=C::t('#it618_union#it618_union_sharecode_class')->fetch_by_id($delid);
		if(it618_union_getpluginstate($it618_union_sharecode_class['it618_plugin'])){
			$it618_state=1;
			$ok=$ok+1;
		}else{
			$it618_state=0;
		}
			
		C::t('#it618_union#it618_union_sharecode_class')->update($delid,array(
			'it618_state' => $it618_state,
		));
	}

	cpmsg($it618_union_lang['s373'].$ok, "action=plugins&identifier=$identifier&cp=admin_sharecode_class&pmod=admin_sharecode&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_no')){
	$ok=0;
	
	if($reabc[8]!='i')return;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
			
		C::t('#it618_union#it618_union_sharecode_class')->update($delid,array(
			'it618_state' => 0,
		));
		$ok=$ok+1;
	}

	cpmsg($it618_union_lang['s374'].$ok, "action=plugins&identifier=$identifier&cp=admin_sharecode_class&pmod=admin_sharecode&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_clear')){
	
	DB::query("delete FROM ".DB::table('it618_union_sharecode'));

	cpmsg($it618_union_lang['s1231'], "action=plugins&identifier=$identifier&cp=admin_sharecode_class&pmod=admin_sharecode&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_sharecode_class&pmod=admin_sharecode&operation=$operation&do=$do");
showtableheaders($it618_union_lang['s347'],'it618_union_sharecode_class');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." w WHERE 1 $extrasql");
	
	echo '<tr><td colspan=10 style="line-height:18px">'.$it618_union_lang['s361'].'</td></tr>';
	echo '<tr><td colspan=10>'.$it618_union_lang['s348'].$count.'<span style="float:right;"></span></td></tr>';
	showsubtitle(array('',$it618_union_lang['s349'],$it618_union_lang['s350'],$it618_union_lang['s351']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_union_sharecode_class')." WHERE 1 $extrasql ORDER BY id");
	while($it618_union_sharecode_class =	DB::fetch($query)) {
		$isok=1;
		if($it618_union_sharecode_class['it618_state']==0){
			if(it618_union_getpluginstate($it618_union_sharecode_class['it618_plugin'])){
				$it618_state='<font color=red>'.$it618_union_lang['s366'].'</font>';
			}else{
				$it618_state='<font color=#999>'.$it618_union_lang['s365'].'</font>';
				$isok=0;
			}
		}else{
			$it618_state='<font color=green>'.$it618_union_lang['s364'].'</font>';
		}
		
		$dostr='';
		if($isok==1){
			if($it618_union_sharecode_class['it618_plugin']=='it618_union'){
				
				if($it618_union_sharecode_class['it618_isyqreg']==1)$it618_isyqreg_checked='checked="checked"';else $it618_isyqreg_checked="";
				
				$count_txt = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='yqreg' and it618_type='txt' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_img = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='yqreg' and it618_type='img' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_bgimg = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='yqreg' and it618_type='bgimg' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				
				$dostr='<input class="checkbox" type="checkbox" id="yqreg'.$it618_union_sharecode_class['id'].'" name="it618_isyqreg['.$it618_union_sharecode_class['id'].']" '.$it618_isyqreg_checked.' value="1"><label for="yqreg'.$it618_union_sharecode_class['id'].'">'.$it618_union_lang['s355'].'</label>
				<a href="plugin.php?id=it618_union:sharecode&cid='.$it618_union_sharecode_class['id'].'&class=yqreg" target="_blank">['.$it618_union_lang['s375'].']</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=yqreg&type=txt">'.$it618_union_lang['s352'].'(<font color=red>'.$count_txt.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=yqreg&type=img">'.$it618_union_lang['s353'].'(<font color=red>'.$count_img.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=yqreg&type=bgimg">'.$it618_union_lang['s354'].'(<font color=red>'.$count_bgimg.'</font>)</a>';
				
			}else if($it618_union_sharecode_class['it618_plugin']=='it618_waimai'){
				
				if($it618_union_sharecode_class['it618_isshop']==1)$it618_isshop_checked='checked="checked"';else $it618_isshop_checked="";
				
				$count_txt = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='shop' and it618_type='txt' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_img = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='shop' and it618_type='img' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_bgimg = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='shop' and it618_type='bgimg' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				
				$dostr='<input class="checkbox" type="checkbox" id="shop'.$it618_union_sharecode_class['id'].'" name="it618_isshop['.$it618_union_sharecode_class['id'].']" '.$it618_isshop_checked.' value="1"><label for="shop'.$it618_union_sharecode_class['id'].'">'.$it618_union_lang['s356'].'</label>
				<a href="plugin.php?id=it618_union:sharecode&cid='.$it618_union_sharecode_class['id'].'&class=shop" target="_blank">['.$it618_union_lang['s375'].']</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=shop&type=txt">'.$it618_union_lang['s352'].'(<font color=red>'.$count_txt.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=shop&type=img">'.$it618_union_lang['s353'].'(<font color=red>'.$count_img.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=shop&type=bgimg">'.$it618_union_lang['s354'].'(<font color=red>'.$count_bgimg.'</font>)</a>';
				
			}else if($it618_union_sharecode_class['it618_plugin']=='it618_sale'){
				
				if($it618_union_sharecode_class['it618_isproduct']==1)$it618_isproduct_checked='checked="checked"';else $it618_isproduct_checked="";
				
				$count_txt = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='product' and it618_type='txt' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_img = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='product' and it618_type='img' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_bgimg = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='product' and it618_type='bgimg' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				
				$dostr.='<input class="checkbox" type="checkbox" id="product'.$it618_union_sharecode_class['id'].'" name="it618_isproduct['.$it618_union_sharecode_class['id'].']" '.$it618_isproduct_checked.' value="1"><label for="product'.$it618_union_sharecode_class['id'].'">'.$it618_union_lang['s357'].'</label>
				<a href="plugin.php?id=it618_union:sharecode&cid='.$it618_union_sharecode_class['id'].'&class=product" target="_blank">['.$it618_union_lang['s375'].']</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=product&type=txt">'.$it618_union_lang['s352'].'(<font color=red>'.$count_txt.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=product&type=img">'.$it618_union_lang['s353'].'(<font color=red>'.$count_img.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=product&type=bgimg">'.$it618_union_lang['s354'].'(<font color=red>'.$count_bgimg.'</font>)</a>';
				
			}else if($it618_union_sharecode_class['it618_plugin']=='it618_group'){
				
				if($it618_union_sharecode_class['it618_isproduct']==1)$it618_isproduct_checked='checked="checked"';else $it618_isproduct_checked="";
				if($it618_union_sharecode_class['it618_istui']==1)$it618_istui_checked='checked="checked"';else $it618_istui_checked="";
				
				$count_txt = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='product' and it618_type='txt' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_img = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='product' and it618_type='img' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_bgimg = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='product' and it618_type='bgimg' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				
				$dostr.='<input class="checkbox" type="checkbox" id="product'.$it618_union_sharecode_class['id'].'" name="it618_isproduct['.$it618_union_sharecode_class['id'].']" '.$it618_isproduct_checked.' value="1"><label for="product'.$it618_union_sharecode_class['id'].'">'.$it618_union_lang['s357'].'</label>
				<a href="plugin.php?id=it618_union:sharecode&cid='.$it618_union_sharecode_class['id'].'&class=product" target="_blank">['.$it618_union_lang['s375'].']</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=product&type=txt">'.$it618_union_lang['s352'].'(<font color=red>'.$count_txt.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=product&type=img">'.$it618_union_lang['s353'].'(<font color=red>'.$count_img.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=product&type=bgimg">'.$it618_union_lang['s354'].'(<font color=red>'.$count_bgimg.'</font>)</a> | ';
				
				$count_txt = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='tui' and it618_type='txt' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_img = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='tui' and it618_type='img' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_bgimg = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='tui' and it618_type='bgimg' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				
				$dostr.='<input class="checkbox" type="checkbox" id="tui'.$it618_union_sharecode_class['id'].'" name="it618_istui['.$it618_union_sharecode_class['id'].']" '.$it618_istui_checked.' value="1"><label for="tui'.$it618_union_sharecode_class['id'].'">'.$it618_union_lang['s358'].'</label>
				<a href="plugin.php?id=it618_union:sharecode&cid='.$it618_union_sharecode_class['id'].'&class=tui" target="_blank">['.$it618_union_lang['s375'].']</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=tui&type=txt">'.$it618_union_lang['s352'].'(<font color=red>'.$count_txt.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=tui&type=img">'.$it618_union_lang['s353'].'(<font color=red>'.$count_img.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=tui&type=bgimg">'.$it618_union_lang['s354'].'(<font color=red>'.$count_bgimg.'</font>)</a>';
				
			}else{
				
				if($it618_union_sharecode_class['it618_isshop']==1)$it618_isshop_checked='checked="checked"';else $it618_isshop_checked="";
				if($it618_union_sharecode_class['it618_isproduct']==1)$it618_isproduct_checked='checked="checked"';else $it618_isproduct_checked="";
				if($it618_union_sharecode_class['it618_istui']==1)$it618_istui_checked='checked="checked"';else $it618_istui_checked="";
				
				$count_txt = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='shop' and it618_type='txt' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_img = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='shop' and it618_type='img' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_bgimg = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='shop' and it618_type='bgimg' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				
				$dostr='<input class="checkbox" type="checkbox" id="shop'.$it618_union_sharecode_class['id'].'" name="it618_isshop['.$it618_union_sharecode_class['id'].']" '.$it618_isshop_checked.' value="1"><label for="shop'.$it618_union_sharecode_class['id'].'">'.$it618_union_lang['s356'].'</label>
				<a href="plugin.php?id=it618_union:sharecode&cid='.$it618_union_sharecode_class['id'].'&class=shop" target="_blank">['.$it618_union_lang['s375'].']</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=shop&type=txt">'.$it618_union_lang['s352'].'(<font color=red>'.$count_txt.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=shop&type=img">'.$it618_union_lang['s353'].'(<font color=red>'.$count_img.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=shop&type=bgimg">'.$it618_union_lang['s354'].'(<font color=red>'.$count_bgimg.'</font>)</a> | ';
				
				$count_txt = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='product' and it618_type='txt' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_img = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='product' and it618_type='img' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_bgimg = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='product' and it618_type='bgimg' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				
				$dostr.='<input class="checkbox" type="checkbox" id="product'.$it618_union_sharecode_class['id'].'" name="it618_isproduct['.$it618_union_sharecode_class['id'].']" '.$it618_isproduct_checked.' value="1"><label for="product'.$it618_union_sharecode_class['id'].'">'.$it618_union_lang['s357'].'</label>
				<a href="plugin.php?id=it618_union:sharecode&cid='.$it618_union_sharecode_class['id'].'&class=product" target="_blank">['.$it618_union_lang['s375'].']</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=product&type=txt">'.$it618_union_lang['s352'].'(<font color=red>'.$count_txt.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=product&type=img">'.$it618_union_lang['s353'].'(<font color=red>'.$count_img.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=product&type=bgimg">'.$it618_union_lang['s354'].'(<font color=red>'.$count_bgimg.'</font>)</a> | ';
				
				$count_txt = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='tui' and it618_type='txt' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_img = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='tui' and it618_type='img' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				$count_bgimg = C::t('#it618_union#it618_union_sharecode')->count_all_by_search("it618_class='tui' and it618_type='bgimg' and it618_isok=1",'',$it618_union_sharecode_class['id']);
				
				$dostr.='<input class="checkbox" type="checkbox" id="tui'.$it618_union_sharecode_class['id'].'" name="it618_istui['.$it618_union_sharecode_class['id'].']" '.$it618_istui_checked.' value="1"><label for="tui'.$it618_union_sharecode_class['id'].'">'.$it618_union_lang['s358'].'</label>
				<a href="plugin.php?id=it618_union:sharecode&cid='.$it618_union_sharecode_class['id'].'&class=tui" target="_blank">['.$it618_union_lang['s375'].']</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=tui&type=txt">'.$it618_union_lang['s352'].'(<font color=red>'.$count_txt.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=tui&type=img">'.$it618_union_lang['s353'].'(<font color=red>'.$count_img.'</font>)</a>
				<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_sharecode&cp=admin_sharecode&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_union_sharecode_class['id'].'&class=tui&type=bgimg">'.$it618_union_lang['s354'].'(<font color=red>'.$count_bgimg.'</font>)</a>';
			}
		}
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id$it618_union_sharecode_class[id]\" name=\"delete[]\" value=\"$it618_union_sharecode_class[id]\">",
			'<input class="txt" type="text" style="width:110px" name="it618_name['.$it618_union_sharecode_class['id'].']" value="'.$it618_union_sharecode_class['it618_name'].'">'.$it618_union_sharecode_class['it618_plugin'],
			$dostr,
			$it618_state
		));
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_union_lang['s360'].'</label></td><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit_edit" value="'.$it618_union_lang['s367'].'"/> <input type="submit" class="btn" name="it618submit_ok" value="'.$it618_union_lang['s368'].'" onclick="return confirm(\''.$it618_union_lang['s370'].'\')" /> <input type="submit" class="btn" name="it618submit_no" value="'.$it618_union_lang['s369'].'" onclick="return confirm(\''.$it618_union_lang['s371'].'\')"/> <input type="submit" class="btn" name="it618submit_clear" value="'.$it618_union_lang['s1229'].'" onclick="return confirm(\''.$it618_union_lang['s1230'].'\')"/></div></td></tr>';

	if(count($reabc)!=11)return;
showtablefooter();
?>