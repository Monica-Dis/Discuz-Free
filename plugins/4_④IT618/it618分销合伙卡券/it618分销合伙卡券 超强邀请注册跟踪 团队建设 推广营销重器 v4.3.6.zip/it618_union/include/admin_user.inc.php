<?php
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php';
}

$urlsql='&uid='.$_GET['uid'].'&tuiuid='.$_GET['tuiuid'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

if(submitcheck('it618submit_jl1')){
	$edit=0;
	foreach($_GET['reguserid'] as $key => $id) {
		$id=intval($id);
		if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where id=".$id." and it618_isjl1=0")) {
			it618_union_yqjl('G1',$jl_credit11,$jl_credit12,$it618_union_reguser,'admin');
			$edit=$edit+1;
		}
	}
	
	cpmsg($it618_union_lang['s662'].'1'.$it618_union_lang['s663'].$edit, "action=plugins&identifier=$identifier&cp=admin_user&pmod=admin_user&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_jl2')){
	$edit=0;
	foreach($_GET['reguserid'] as $key => $id) {
		$id=intval($id);
		if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where id=".$id." and it618_isjl2=0")) {
			it618_union_yqjl('G2',$jl_credit21,$jl_credit22,$it618_union_reguser,'admin');
			$edit=$edit+1;
		}
	}
	
	cpmsg($it618_union_lang['s662'].'2'.$it618_union_lang['s663'].$edit, "action=plugins&identifier=$identifier&cp=admin_user&pmod=admin_user&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_jl3')){
	$edit=0;
	foreach($_GET['reguserid'] as $key => $id) {
		$id=intval($id);
		if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where id=".$id." and it618_isjl3=0")) {
			it618_union_yqjl('G3',$jl_credit31,$jl_credit32,$it618_union_reguser,'admin');
			$edit=$edit+1;
		}
	}
	
	cpmsg($it618_union_lang['s662'].'2'.$it618_union_lang['s663'].$edit, "action=plugins&identifier=$identifier&cp=admin_user&pmod=admin_user&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618sercsubmit')){
	$ppp = $it618_union['pagecount'];
	$page = 1;
	$startlimit = 0;
}

$jltype1=0;$jltype2=0;$jltype3=0;
$tmparr = !empty($_GET['jltype']) ? $_GET['jltype'] : array();

if(in_array('G1', $tmparr)){
	$it618sql.=' and it618_isjl1=1';
	$jltype1=1;
}
if(in_array('G2', $tmparr)){
	$it618sql.=' and it618_isjl2=1';
	$jltype2=1;
}
if(in_array('G3', $tmparr)){
	$it618sql.=' and it618_isjl3=1';
	$jltype3=1;
}

if($it618sql!=''){
	$it618sql='1=1'.$it618sql;
}

$jltypearr=explode("it618_split",it618_union_getjltype($jltype1,$jltype2,$jltype3));

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_user&pmod=admin_user&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($it618_union_lang['s105'],'it618_union_reguser');
	showsubmit('it618sercsubmit', $it618_union_lang['s89'], $it618_union_lang['s90'].' <input name="uid" style="width:50px" value="'.$_GET['uid'].'" class="txt" /> '.$it618_union_lang['s106'].' <input name="tuiuid" style="width:50px" value="'.$_GET['tuiuid'].'" class="txt" /> '.$it618_union_lang['t36'].''.$jltypearr[0].' '.$it618_union_lang['s107'].' <input id="it618_time1" name="it618_time1" class="txt" style="width:80px;margin-right:0" readonly="readonly" value="'.$_GET['it618_time1'].'" /> - <input id="it618_time2" name="it618_time2" class="txt" style="width:80px;" readonly="readonly" value="'.$_GET['it618_time2'].'"/>');
	if($reabc[8]!='i')return;
	$count=C::t('#it618_union#it618_union_reguser')->count_by_search($it618sql,'',$_GET['uid'],$_GET['tuiuid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_user&pmod=admin_user&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=15>'.$it618_union_lang['s108'].$count.'<span style="color:red;float:right">'.$it618_union_lang['s661'].'</span></td></tr>';
	showsubtitle(array('',$it618_union_lang['s109'], $it618_union_lang['s110'],$it618_union_lang['s113'],$it618_union_lang['s107'],$it618_union_lang['s114'], $it618_union_lang['s111'],$it618_union_lang['s113'],$it618_union_lang['s115']));
	
	foreach(C::t('#it618_union#it618_union_reguser')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['uid'],$_GET['tuiuid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_reguser) {
		
		$username1=it618_union_getusername($it618_union_reguser['it618_uid']);
		$userurl1=it618_union_rewriteurl($it618_union_reguser['it618_uid']);
		$username2=it618_union_getusername($it618_union_reguser['it618_tuiuid']);
		$userurl2=it618_union_rewriteurl($it618_union_reguser['it618_tuiuid']);
		
		$grouptitle='';$grouptitles='';
		if($it618_union_reguser['it618_groupid']>0){
			$grouptitle='<font color=#f60>'.DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$it618_union_reguser['it618_groupid']).'</font>';
		}else{
			$groupid=DB::result_first("SELECT groupid FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_uid']);
			if($groupid>0)$grouptitle='<font color=#f60>'.DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$groupid).'</font>';
		}
		
		if($it618_union_reguser['it618_groups']!=''){
			$tmparr=explode(",",$it618_union_reguser['it618_groups']);
			for($i=0;$i<count($tmparr);$i++){
				if($tmparr[$i]>0){
					$grouptitles.=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$tmparr[$i]).', ';
				}
			}
			
			if($grouptitles!=''){
				$grouptitles=$grouptitles.'@';
				$grouptitles=str_replace(', @','',$grouptitles);
				
				$grouptitle.=', '.$grouptitles;
			}
		}
		
		$groupid=DB::result_first("SELECT groupid FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_tuiuid']);
		if($groupid>0)$grouptitle2=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$groupid);
		
		$tuicount1=DB::result_first("select count(1) from ".DB::table('it618_union_reguser')." where it618_tuiuid=".$it618_union_reguser['it618_uid']);
		
		$tuicount2=DB::result_first("select count(1) from ".DB::table('it618_union_reguser')." where it618_tuiuid=".$it618_union_reguser['it618_tuiuid']);
		
		$jlstr='';
		if($it618_union_reguser['it618_isjl1']==1){
			$jlstr.='<font color=#390>G1</font>, ';
		}
		if($it618_union_reguser['it618_isjl2']==1){
			$jlstr.='<font color=#390>G2</font>, ';
		}
		if($it618_union_reguser['it618_isjl3']==1){
			$jlstr.='<font color=#390>G3</font>, ';
		}
		if($jlstr!=''){
			$jlstr=$jlstr.'@';
			$jlstr=str_replace(', @','',$jlstr);
		}
		
		showtablerow('', array('', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_union_reguser['id'].'" name="reguserid[]" value="'.$it618_union_reguser['id'].'"><label for="chk_del'.$it618_union_reguser['id'].'">'.$it618_union_reguser['id'].'</label>',
			'<a href="'.$userurl1.'" target="_blank">'.$username1.'</a>',
			'<div style="width:580px">'.$grouptitle.'</div>',
			$tuicount1,
			date('Y-m-d H:i:s', $it618_union_reguser['it618_time']),
			'<a href="'.$userurl2.'" target="_blank">'.$username2.'</a>',
			$grouptitle2,
			$tuicount2,
			$jlstr
		));
	}
	
	if($jl_group_isok1==1||$jl_tuicount_isok1==1){
		$tmpbtn.='<input type="submit" class="btn" name="it618submit_jl1" value="'.$it618_union_lang['s658'].'1" onclick="return confirm(\''.$it618_union_lang['s659'].'\')" /> ';
	}
	
	if($jl_group_isok2==1||$jl_tuicount_isok2==1){
		$tmpbtn.='<input type="submit" class="btn" name="it618submit_jl2" value="'.$it618_union_lang['s658'].'2" onclick="return confirm(\''.$it618_union_lang['s659'].'\')" /> ';
	}
	
	if($jl_group_isok3==1||$jl_tuicount_isok3==1){
		$tmpbtn.='<input type="submit" class="btn" name="it618submit_jl3" value="'.$it618_union_lang['s658'].'3" onclick="return confirm(\''.$it618_union_lang['s659'].'\')" /> ';
	}
	
	echo '<tr><td width=58><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'reguserid\')" /><label for="chkallDx4b">'.$it618_union_lang['s660'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel">'.$tmpbtn.'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=11)return;
	showtablefooter();
	echo '<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>
	<script>
	laydate.render({
	  elem: "#it618_time1"
	});
	laydate.render({
	  elem: "#it618_time2"
	});
	</script>';
?>