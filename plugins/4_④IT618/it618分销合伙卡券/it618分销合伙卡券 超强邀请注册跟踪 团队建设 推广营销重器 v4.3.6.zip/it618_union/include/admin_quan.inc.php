<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/quanset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/quanset.php';
}

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/quanset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/config/quanset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {		
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$fileData .= '$union_video_credits['.$i.']=\''.dhtmlspecialchars($_GET['union_video_credits'.$i])."';\n";
				$fileData .= '$union_exam_credits['.$i.']=\''.dhtmlspecialchars($_GET['union_exam_credits'.$i])."';\n";
				$fileData .= '$union_brand_credits['.$i.']=\''.dhtmlspecialchars($_GET['union_brand_credits'.$i])."';\n";
				$fileData .= '$union_tuan_credits['.$i.']=\''.dhtmlspecialchars($_GET['union_tuan_credits'.$i])."';\n";
			}
		}

		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_union_lang['s496'], "action=plugins&identifier=$identifier&cp=admin_quan&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_quan&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_union_set');

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		
		if($union_video_credits[$i]==1)$union_video_credits_checked='checked="checked"';else $union_video_credits_checked="";
		if($union_exam_credits[$i]==1)$union_exam_credits_checked='checked="checked"';else $union_exam_credits_checked="";
		if($union_brand_credits[$i]==1)$union_brand_credits_checked='checked="checked"';else $union_brand_credits_checked="";
		if($union_tuan_credits[$i]==1)$union_tuan_credits_checked='checked="checked"';else $union_tuan_credits_checked="";
		
		$union_video_str.='<input type="checkbox" id="union_video_credits'.$i.'" name="union_video_credits'.$i.'" value="1" style="vertical-align:middle" '.$union_video_credits_checked.'><label for="union_video_credits'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</label> ';
		
		$union_exam_str.='<input type="checkbox" id="union_exam_credits'.$i.'" name="union_exam_credits'.$i.'" value="1" style="vertical-align:middle" '.$union_exam_credits_checked.'><label for="union_exam_credits'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</label> ';
		
		$union_brand_str.='<input type="checkbox" id="union_brand_credits'.$i.'" name="union_brand_credits'.$i.'" value="1" style="vertical-align:middle" '.$union_brand_credits_checked.'><label for="union_brand_credits'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</label> ';
		
		$union_tuan_str.='<input type="checkbox" id="union_tuan_credits'.$i.'" name="union_tuan_credits'.$i.'" value="1" style="vertical-align:middle" '.$union_tuan_credits_checked.'><label for="union_tuan_credits'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</label> ';
		
	}
}

echo '
<tr><td colspan=2>'.$it618_union_lang['s495'].'</td></tr>

<tr><td>'.$it618_union_lang['s629'].$it618_union_lang['s497'].'</td>
<tr></tr><td style="line-height:26px">'.$union_video_str.'</td></tr>

<tr><td>'.$it618_union_lang['s878'].$it618_union_lang['s497'].'</td>
<tr></tr><td style="line-height:26px">'.$union_exam_str.'</td></tr>

<tr><td>'.$it618_union_lang['s626'].$it618_union_lang['s497'].'</td>
<tr></tr><td style="line-height:26px">'.$union_brand_str.'</td></tr>

<tr><td>'.$it618_union_lang['s631'].$it618_union_lang['s497'].'</td>
<tr></tr><td style="line-height:26px">'.$union_tuan_str.'</td></tr>
';

showsubmit('it618submit', $it618_union_lang['s19']);

if(count($reabc)!=11)return;
showtablefooter();

?>