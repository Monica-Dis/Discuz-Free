<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!union_is_mobile()){ 
	$tmpurl=it618_union_getrewrite('union_home','','plugin.php?id=it618_union:index');
	dheader("location:$tmpurl");
}

foreach(C::t('#it618_union#it618_union_focus')->fetch_all_by_type_order(11) as $it618_union_focus) {
	if($it618_union_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_union_focus['it618_url'].'" target="_blank"><img class="img" src="'.it618_union_getwapppic($it618_union_focus['id'],$it618_union_focus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_union_getwapppic($it618_union_focus['id'],$it618_union_focus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_union_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_union_gonggao = DB::fetch($query)) {
	$it618_title=$it618_union_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_union_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_union_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_union_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_union_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

if($it618_union['waphomeico']=='')$it618_union['waphomeico']='2|5|11|#888|6';
$waphomeico=explode("|",$it618_union['waphomeico']);
$tmpn=$waphomeico[0];
$pppn=$waphomeico[1];
$tmpsize=$waphomeico[2];
$tmpcolor=$waphomeico[3];
$tmpw=$waphomeico[4];
$pppw=100/$pppn;
$tmpn=$tmpn*$pppn;

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_union_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_union_iconav = DB::fetch($query)) {
	$it618_title=$it618_union_iconav['it618_title'];
	
	if($it618_union_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_union_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_union_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_union_iconav['it618_color'].'">'.$it618_title.'</font>';
	}

	$str_iconav.='<td width="'.$pppw.'%"><a href="'.$it618_union_iconav['it618_url'].'"'.$it618_target.'><img src="'.$it618_union_iconav['it618_img'].'" /><br>'.$it618_title.'</a></td>';
	
	if($n%$pppn==0)$str_iconav.='</tr><tr>';
	if($n%$tmpn==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';

	$n=$n+1;
}

if($n>1)$n=$n-1;

if($n%$pppn>0){
	for($i=1;$i<=($pppn-$n%$pppn);$i++){
		$str_iconav.='<td width="'.$pppw.'%"></td>';
	}
}

$str_iconav.='</tr>';
$str_iconav=str_replace('<tr></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"></table></div>','',$str_iconav);
$str_iconav=str_replace('<tr><td','<tr><td width='.$tmpw.'></td><td',$str_iconav);
$str_iconav=str_replace('</td></tr>','</td><td width='.$tmpw.'></td></tr>',$str_iconav);
$str_iconav.='<style>.swiper-slide .iconav{table-layout:fixed;}.swiper-slide .iconav tr td a{color:'.$tmpcolor.';font-size:'.$tmpsize.'px}</style>';

$isiconav=count(explode('<img src',$str_iconav))-1;

if($it618_union['union_isquantui']==1){
	$homes_arr=array("newquan"=>4,"hotquan"=>3,"newtui"=>2,"hottui"=>1);
	asort($homes_arr);
	
	$n=1;
	foreach($homes_arr as $key=>$homes){
		if($n==1)$current=' class="current" ';else $current=' ';
		
		if($homejsstr==''){
			$homejsstr="get_homes('$key');";
		}
	
		if($key=='newquan'){
			$tab_homes.='<li'.$current.'onclick="it618_union_tabChange(this,\'searchli_bd\');get_homes(\''.$key.'\');">'.$it618_union_lang['s581'].'</li>';
		}
		
		if($key=='hotquan'){
			$tab_homes.='<li'.$current.'onclick="it618_union_tabChange(this,\'searchli_bd\');get_homes(\''.$key.'\');">'.$it618_union_lang['s582'].'</li>';
		}
		
		if($key=='newtui'){
			$tab_homes.='<li'.$current.'onclick="it618_union_tabChange(this,\'searchli_bd\');get_homes(\''.$key.'\');">'.$it618_union_lang['s583'].'</li>';
		}
		
		if($key=='hottui'){
			$tab_homes.='<li'.$current.'onclick="it618_union_tabChange(this,\'searchli_bd\');get_homes(\''.$key.'\');">'.$it618_union_lang['s584'].'</li>';
		}
		
		if($n==1)$bdstyle=' ;display:';else $bdstyle=' ;display:none';
		$dl_homes.='<dl class="list" id="searchli_bd'.($n-1).'" style="border:none; margin:0;'.$bdstyle.'">
						  <dd><dl style="padding:0">
							  <table width="100%" class="tablelist1" id="home_table_'.$key.'">
							  </table>
						  </dl></dd>
					  </dl>';
		
		$n=$n+1;
	}
	
	$homes_str='<div class="divsearchli"><ul>'.$tab_homes.'</ul></div><div id="home_goods">'.$dl_homes.'</div>';
}

$_G['mobiletpl'][2]='/';
include template('it618_union:'.$union_templatename_wap.'/wap_union');
?>