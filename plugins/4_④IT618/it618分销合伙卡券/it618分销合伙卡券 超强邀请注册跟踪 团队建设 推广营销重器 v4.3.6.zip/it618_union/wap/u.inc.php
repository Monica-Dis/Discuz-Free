<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!union_is_mobile()){
	dheader("location:$union_home");
}

$navtitle=it618_union_getlang('t106').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_union:'.$union_templatename_wap.'/wap_union');
	return;
}

$menuusername=$_G['username'];
$u_avatarimg=it618_union_discuz_uc_avatar($_G['uid'],'middle');

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_buygroup=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$tmpurl_myvip=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$viplogo='source/plugin/it618_credits/images/group.png';
}

if($IsGroup==1){
	$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	$viplogo='source/plugin/it618_group/images/group.png';
}

$myusercount=C::t('#it618_union#it618_union_reguser')->count_by_search('','',0,$_G['uid']);

$yqjlcount=C::t('#it618_union#it618_union_jl')->count_by_search('','',$_G['uid']);

$saletccount=C::t('#it618_union#it618_union_saletc')->count_by_search('','',$_G['uid']);

if($it618_union['union_isquantui']==1){
	$quanscount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('',0,'it618_ison=1');
	
	$myquancount=C::t('#it618_union#it618_union_quansale')->count_by_shoptype_shopid('',0,'it618_uid='.$_G['uid']);
	
	$tuiscount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('',0,'it618_ison=1');
	
	$mytuicount=C::t('#it618_union#it618_union_tuijoin')->count_by_shoptype_shopid('',0,'it618_uid='.$_G['uid']);
	
	$tuitccount=C::t('#it618_union#it618_union_tuitc')->count_by_shoptype_shopid('',0,'it618_uid='.$_G['uid']);
}

$_G['mobiletpl'][2]='/';
include template('it618_union:'.$union_templatename_wap.'/wap_union');
?>