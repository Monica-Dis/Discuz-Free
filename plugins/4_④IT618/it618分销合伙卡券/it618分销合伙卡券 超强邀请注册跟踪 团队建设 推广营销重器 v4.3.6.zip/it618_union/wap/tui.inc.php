<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tid=intval($_GET['cid']);

if(!$it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_ison_id($tid)){
	dheader("location:$url_tuis");
}

if(!union_is_mobile()){
	$tmpurl=it618_union_getrewrite('union_quan',$it618_union_tui['id'],'plugin.php?id=it618_union:union_tui&tid='.$it618_union_tui['id']);
	dheader("location:$tmpurl");
}

$navtitle=$it618_union_tui['it618_name'].' - '.$sitetitle;
$current_tui='class="current"';

if($_G['uid']>0)$joincount=C::t('#it618_union#it618_union_tuijoin')->count_by_tid_uid($tid,$_G['uid']);

$timetmp=explode(" ",$it618_union_tui['it618_etime']);
$timetmp1=explode("-",$timetmp[0]);
$timetmp2=explode(":",$timetmp[1]);

$etime=mktime($timetmp2[0], $timetmp2[1], 0, $timetmp1[1], $timetmp1[2], $timetmp1[0]);

$timecss='green';
if($etime<$_G['timestamp']){
	C::t('#it618_union#it618_union_tui')->update($tid,array(
		'it618_ison' => 0
	), true);
}

if($it618_union_tui['it618_shoptype']=='video'){
	$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_union_tui['it618_shopid']);
	$shopname=$it618_video_shop['it618_name'];
	$shoppic=$it618_video_shop['it618_logo'];
	$shopurl=it618_union_getrewrite_plugin('it618_video','video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop['id']);
}

if($it618_union_tui['it618_shoptype']=='exam'){
	$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_union_tui['it618_shopid']);
	$shopname=$it618_exam_shop['it618_name'];
	$shoppic=$it618_exam_shop['it618_logo'];
	$shopurl=it618_union_getrewrite_plugin('it618_exam','exam_teacher',$it618_exam_shop['id'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_shop['id']);
}

if($it618_union_tui['it618_shoptype']=='group'){
	$shopname=$it618_union_lang['s765'];
	$it618_group = $_G['cache']['plugin']['it618_group'];
	$shoppic=$it618_group['group_unionlogo'];
	$shopurl=it618_union_getrewrite_plugin('it618_group','group_class','','plugin.php?id=it618_group:class');
}

if($it618_union_tui['it618_shoptype']=='brand'){
	$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_union_tui['it618_shopid']);
	$shopname=$it618_brand_brand['it618_name'];
	$shoppic=$it618_brand_brand['it618_logo'];
	$shopurl=it618_union_getrewrite_plugin('it618_brand','shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
}

if($it618_union_tui['it618_shoptype']=='tuan'){
	$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_union_tui['it618_shopid']);
	$shopname=$it618_tuan_shop['it618_name'];
	$shoppic=$it618_tuan_shop['it618_logo'];
	$shopurl=it618_union_getrewrite_plugin('it618_tuan','tuan_shop',$it618_tuan_shop['id'],'plugin.php?id=it618_tuan:shop&sid='.$it618_tuan_shop['id']);
}

$count=count(explode(",",$it618_union_tui['it618_pids']));
$it618_pids='<a href="javascript:" onclick="showgoods(\'tui\','.$it618_union_tui['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';

$_G['mobiletpl'][2]='/';
include template('it618_union:'.$union_templatename_wap.'/wap_union');
?>