<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$qid=intval($_GET['cid']);

if(!$it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_ison_id($qid)){
	$tmpurl=it618_union_getrewrite('union_wap','quans','plugin.php?id=it618_union:wap&pagetype=quans');
	dheader("location:$tmpurl");
}

if(!union_is_mobile()){
	$tmpurl=it618_union_getrewrite('union_quan',$it618_union_quan['id'],'plugin.php?id=it618_union:union_quan&qid='.$it618_union_quan['id']);
	dheader("location:$tmpurl");
}

$navtitle=$it618_union_quan['it618_name'].' - '.$sitetitle;
$current_quan='class="current"';

$timetmp1=explode(" ",$it618_union_quan['it618_oktime1']);
$timetmp2=explode(" ",$it618_union_quan['it618_oktime2']);
$timetmp11=explode("-",$timetmp1[0]);
$timetmp12=explode(":",$timetmp1[1]);
$timetmp21=explode("-",$timetmp2[0]);
$timetmp22=explode(":",$timetmp2[1]);

$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);

$timecss='green';
if($etime<$_G['timestamp']){
	$timecss='#999';
	C::t('#it618_union#it618_union_quan')->update($qid,array(
		'it618_ison' => 0
	), true);
}else{
	if($btime>$_G['timestamp']){
		$timecss='blue';
	}
}

$pricestr='';
for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_quan['it618_credit'.$i]>0){
		$pricestr.='<font color=#f60>'.$it618_union_quan['it618_credit'.$i].'</font>'.$_G['setting']['extcredits'][$i]['title'].'+';
	}
}

if($pricestr!=''){
	$pricestr=$pricestr.'@';
	$pricestr=str_replace('+@','',$pricestr);
	$confirmabout=$it618_union_lang['t312'];
}else{
	$pricestr=$it618_union_lang['s256'];
	$confirmabout=$it618_union_lang['t82'];	
}

if($it618_union_quan['it618_xgtime']==0&&$it618_union_quan['it618_xgcount']==0){
	$xgstrcount=$it618_union_lang['s244'];
}else{
	$xgstrcount=$it618_union_lang['s247'];
	$xgstrcount=str_replace("{time}",$it618_union_quan['it618_xgtime'],$xgstrcount);
	$xgstrcount=str_replace("{count}",$it618_union_quan['it618_xgcount'],$xgstrcount);
}

$timeflag=0;$isxgok=0;
$timestr=$it618_union_lang['s244'];
if($it618_union_quan['it618_xgtype']==0)$isxgok=1;

if($it618_union_quan['it618_xgtype']==1){
	$timestr=$it618_union_quan['it618_xgtime1'].' - '.$it618_union_quan['it618_xgtime2'];
	
	$timetmp1=explode(" ",$it618_union_quan['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_union_quan['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_union_getlang('s952');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_union_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_union_quan['it618_xgtime1'];
		}else{
			$timetip=it618_union_getlang('s954');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_union_quan['it618_xgtime2'];
			$isxgok=1;
		}
	}
	
	$isxg=1;
}

if($it618_union_quan['it618_xgtype']==2){
	$timetmp1=explode(" ",$it618_union_quan['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_union_quan['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_union_getlang('s955').' '.$timetmp1[1].' - '.$timetmp2[1];
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_union_getlang('s952');
		
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_union_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_union_quan['it618_xgtime1'];
		}else{
			$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
			$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
			$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
			
			if($btimecur>$_G['timestamp']){
				$timetip=it618_union_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur);
			}
			
			if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
				$timetip=it618_union_getlang('s954');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $etimecur);
				$isxgok=1;
			}
			
			if($etimecur<$_G['timestamp']){
				$timetip=it618_union_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur1);
			}
		}
	}
	
	$isxg=1;
}

if($it618_union_quan['it618_type']==1){
	$it618_type=$it618_union_lang['s240'].$it618_union_quan['it618_mjmoney1'].$it618_union_lang['s195'].$it618_union_lang['s241'].$it618_union_quan['it618_mjmoney2'].$it618_union_lang['s195'];
}else{
	$it618_type=$it618_union_quan['it618_money'].$it618_union_lang['s195'];
}

if($it618_union_quan['it618_shoptype']=='video'){
	$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_union_quan['it618_shopid']);
	$shopname=$it618_video_shop['it618_name'];
	$shoppic=$it618_video_shop['it618_logo'];
	$shopurl=it618_union_getrewrite_plugin('it618_video','video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop['id']);
}

if($it618_union_quan['it618_shoptype']=='exam'){
	$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_union_quan['it618_shopid']);
	$shopname=$it618_exam_shop['it618_name'];
	$shoppic=$it618_exam_shop['it618_logo'];
	$shopurl=it618_union_getrewrite_plugin('it618_exam','exam_teacher',$it618_exam_shop['id'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_shop['id']);
}

if($it618_union_quan['it618_shoptype']=='group'){
	$shopname=$it618_union_lang['s765'];
	$it618_group = $_G['cache']['plugin']['it618_group'];
	$shoppic=$it618_group['group_unionlogo'];
	$shopurl=it618_union_getrewrite_plugin('it618_group','group_class','','plugin.php?id=it618_group:class');
}

if($it618_union_quan['it618_shoptype']=='brand'){
	$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_union_quan['it618_shopid']);
	$shopname=$it618_brand_brand['it618_name'];
	$shoppic=$it618_brand_brand['it618_logo'];
	$shopurl=it618_union_getrewrite_plugin('it618_brand','shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
}

if($it618_union_quan['it618_shoptype']=='tuan'){
	$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_union_quan['it618_shopid']);
	$shopname=$it618_tuan_shop['it618_name'];
	$shoppic=$it618_tuan_shop['it618_logo'];
	$shopurl=it618_union_getrewrite_plugin('it618_tuan','tuan_shop',$it618_tuan_shop['id'],'plugin.php?id=it618_tuan:shop&sid='.$it618_tuan_shop['id']);
}

if($it618_union_quan['it618_pids']==''){
	$it618_pids=$it618_union_lang['s547'];
}else{
	$count=count(explode(",",$it618_union_quan['it618_pids']));
	$it618_pids='<a href="javascript:" onclick="showgoods(\'quan\','.$it618_union_quan['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
}

$_G['mobiletpl'][2]='/';
include template('it618_union:'.$union_templatename_wap.'/wap_union');
?>