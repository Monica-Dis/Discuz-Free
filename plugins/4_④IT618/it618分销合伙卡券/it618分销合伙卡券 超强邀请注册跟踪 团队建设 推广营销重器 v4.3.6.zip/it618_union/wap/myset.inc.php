<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!union_is_mobile()){ 
	$tmpurl=it618_union_getrewrite('union_home','','plugin.php?id=it618_union:index');
	dheader("location:$tmpurl");
}

$navtitle=$it618_union_lang['s87'].' - '.$sitetitle;

if($_G['uid']>0){
	$it618_union_userset=C::t('#it618_union#it618_union_userset')->fetch_by_uid($_G['uid']);
	if($it618_union_userset['it618_tel_isopen']==1)$it618_tel_isopen='checked="checked"';
	if($it618_union_userset['it618_ismsgok_reg']==1)$it618_ismsgok_reg='checked="checked"';
	if($it618_union_userset['it618_ismsgok_jl']==1)$it618_ismsgok_jl='checked="checked"';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/message.php';
}

$_G['mobiletpl'][2]='/';
include template('it618_union:'.$union_templatename_wap.'/wap_union');
?>