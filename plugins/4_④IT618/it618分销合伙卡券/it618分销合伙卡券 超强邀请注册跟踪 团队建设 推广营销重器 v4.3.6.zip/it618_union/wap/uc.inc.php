<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!union_is_mobile()){
	$tmpurl=it618_union_getrewrite('union_uc',$pagetype,'plugin.php?id=it618_union:union_uc&pagetype=$pagetype');
	dheader("location:$tmpurl");
}

if($_G['uid']<=0&&$pagetype!='yqreg'){
	$error=1;
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_union:'.$union_templatename_wap.'/wap_union');
	return;
}

if($pagetype=='myuser'){
	$jltypearr=explode("it618_split",it618_union_getjltype());
	
	$jftmparr1=C::t('#it618_union#it618_union_jl')->fetch_sumjf_by_tuiuid($_G['uid'],1);
	$jftmparr2=C::t('#it618_union#it618_union_jl')->fetch_sumjf_by_tuiuid($_G['uid'],2);
	
	for($i=1;$i<=8;$i++){
		if($_G['setting']['extcredits'][$i]['title']!=''&&$jftmparr1['jf'.$i]>0){
			$jf1str.=$jftmparr1['jf'.$i].$_G['setting']['extcredits'][$i]['title'].' ';
		}
		if($_G['setting']['extcredits'][$i]['title']!=''&&$jftmparr2['jf'.$i]>0){
			$jf2str.=$jftmparr2['jf'.$i].$_G['setting']['extcredits'][$i]['title'].' ';
		}
	}
	
	if($IsCredits==1){
		$money1=DB::result_first("SELECT sum(it618_money1) FROM ".DB::table('it618_credits_money')." where it618_zytype='it618_union_yqmoney1' and it618_uid=".$_G['uid']);
		$money2=DB::result_first("SELECT sum(it618_money1) FROM ".DB::table('it618_credits_money')." where it618_zytype='it618_union_yqmoney2' and it618_uid=".$_G['uid']);
		if($money1=='')$money1=0;
		if($money2=='')$money2=0;
	}
	
	if($money1>0||$money2>0){
		if($jf1str!=''||$money1>0)$jf1str=$it618_union_lang['s1026'].$money1.$it618_union_lang['s195'].' '.$jf1str;
		if($jf2str!=''||$money2>0)$jf2str=$it618_union_lang['s1027'].$money2.$it618_union_lang['s195'].' '.$jf2str;
	}else{
		if($jf1str!='')$jf1str=$it618_union_lang['s1026'].$jf1str;
		if($jf2str!='')$jf2str=$it618_union_lang['s1027'].$jf2str;
	}
}

if($pagetype=='yqreg'){
	if($_G['uid']>0){
		$tuipower=1;
		if($it618_union['union_yqpowermode']==1||$it618_union['union_yqpowermode']==3){
			$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
			if($union_tuigroup[0]!=''){
				$tmpgrouparr=it618_union_getisvipuser($union_tuigroup);
				if(count($tmpgrouparr[0])==0){
					$tuipower=0;
					$tuipowerabout=$it618_union['union_tuipowerabout2'];
				}
			}
		}
		if($it618_union['union_yqpowermode']==2||$it618_union['union_yqpowermode']==3){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
				$tuipower=0;
				$tuipowerabout=$it618_union['union_tuipowerabout3'];
			}
		}
		
		$tuiurl=$_G['siteurl'].it618_union_getrewrite('union_yq',$_G['uid'],'plugin.php?id=it618_union:union&tuiuid='.$_G['uid']);
		
		$myshareurl=$_G['siteurl'].it618_union_getrewrite('union_wap','myshare@'.$_G['uid'],'plugin.php?id=it618_union:wap&pagetype=myshare&cid='.$_G['uid']);
	}else{
		$tuipower=0;	
		$tuipowerabout=$it618_union['union_tuipowerabout1'];
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php';
	}
	
	$clipboarddata=$share_name."\n".$tuiurl;
	
	$yqjlmoney=explode("@",$it618_union['union_yqjlmoney']);
	if($yqjlmoney[0]>0||$yqjlmoney[1]>0){
		$yqjlmoneystr=$it618_union_lang['s834'];
		if($yqjlmoney[0]>0){
			$it618_union_lang['s835']=str_replace("{money}",$yqjlmoney[0],$it618_union_lang['s835']);
			$yqjlmoneystr.=$it618_union_lang['s835'];
		}
		if($yqjlmoney[1]>0){
			$it618_union_lang['s836']=str_replace("{money}",$yqjlmoney[1],$it618_union_lang['s836']);
			$yqjlmoneystr.=$it618_union_lang['s836'];
		}
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php';
	}
	
	if($jl_group_isok1==1||$jl_tuicount_isok1==1){
		$jlstrtmp='';$jfstr='';$jfstr1='';
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit11[$i]>0){
				$jfstr.='<span>'.$jl_credit11[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit12[$i]>0){
				$jfstr1.='<span>'.$jl_credit12[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
		}
		
		if($jl_tuicount_isok1==1&&$jl_tuicount1>0){
			$jlstrtmp=$it618_union_lang['s653'].'<font color=red>'.$jl_tuicount1.'</font><br>';
			
		}
		
		if($jl_group_isok1==1){
			$grouptitle=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$jl_group1);
			$jlstrtmp.=$it618_union_lang['s654'].'<font color=red>'.$grouptitle.'</font>'.$it618_union_lang['s655'].' ';
		}
		
		if($jl_do_isok1==1){
			$jlstrtmp.='<span style="float:right"><font color=#999>'.$it618_union_lang['s667'].'</font></span>';
		}else{
			$jlstrtmp.='<span style="float:right"><font color=#999>'.$it618_union_lang['s668'].'</font></span>';
		}
		
		$jlstr.='<tr><td colspan=2 class=tdname>[G1] '.$jlstrtmp.'</td></tr>';
		$jlstr.='<tr><td>'.$it618_union_lang['t64'].'</td><td class="tdsaletc">'.gettmpstr($jfstr).'</td></tr>';
		if($jfstr1!='')$jlstr.='<tr><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc">'.gettmpstr($jfstr1).'</td></tr>';
	}
	
	if($jl_group_isok2==1||$jl_tuicount_isok2==1){
		$jlstrtmp='';$jfstr='';$jfstr1='';
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit21[$i]>0){
				$jfstr.='<span>'.$jl_credit21[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit22[$i]>0){
				$jfstr1.='<span>'.$jl_credit22[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
		}
		
		if($jl_tuicount_isok2==1&&$jl_tuicount2>0){
			$jlstrtmp=$it618_union_lang['s653'].'<font color=red>'.$jl_tuicount2.'</font><br>';
			
		}
		
		if($jl_group_isok2==1){
			$grouptitle=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$jl_group2);
			$jlstrtmp.=$it618_union_lang['s654'].'<font color=red>'.$grouptitle.'</font>'.$it618_union_lang['s655'].' ';
		}
		
		if($jl_do_isok2==1){
			$jlstrtmp.='<span style="float:right"><font color=#999>'.$it618_union_lang['s667'].'</font></span>';
		}else{
			$jlstrtmp.='<span style="float:right"><font color=#999>'.$it618_union_lang['s668'].'</font></span>';
		}
		
		$jlstr.='<tr><td colspan=2 class=tdname>[G2] '.$jlstrtmp.'</td></tr>';
		$jlstr.='<tr><td>'.$it618_union_lang['t64'].'</td><td class="tdsaletc">'.gettmpstr($jfstr).'</td></tr>';
		if($jfstr1!='')$jlstr.='<tr><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc">'.gettmpstr($jfstr1).'</td></tr>';
	}
	
	if($jl_group_isok3==1||$jl_tuicount_isok3==1){
		$jlstrtmp='';$jfstr='';$jfstr1='';
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit31[$i]>0){
				$jfstr.='<span>'.$jl_credit31[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit32[$i]>0){
				$jfstr1.='<span>'.$jl_credit32[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
		}
		
		if($jl_tuicount_isok3==1&&$jl_tuicount3>0){
			$jlstrtmp=$it618_union_lang['s653'].'<font color=red>'.$jl_tuicount3.'</font><br>';
			
		}
		
		if($jl_group_isok3==1){
			$grouptitle=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$jl_group3);
			$jlstrtmp.=$it618_union_lang['s654'].'<font color=red>'.$grouptitle.'</font>'.$it618_union_lang['s655'].' ';
		}
		
		if($jl_do_isok3==1){
			$jlstrtmp.='<span style="float:right"><font color=#999>'.$it618_union_lang['s667'].'</font></span>';
		}else{
			$jlstrtmp.='<span style="float:right"><font color=#999>'.$it618_union_lang['s668'].'</font></span>';
		}
		
		$jlstr.='<tr><td colspan=2 class=tdname>[G3] '.$jlstrtmp.'</td></tr>';
		$jlstr.='<tr><td>'.$it618_union_lang['t64'].'</td><td class="tdsaletc">'.gettmpstr($jfstr).'</td></tr>';
		if($jfstr1!='')$jlstr.='<tr><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc">'.gettmpstr($jfstr1).'</td></tr>';
	}
	
	if($jlstr!='')$jlstr='<table width="100%" class="salecss"><tr><th>'.$it618_union_lang['t134'].'</th><th>'.$it618_union_lang['t135'].'</th></tr>'.$jlstr.'</table>';

	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
	}
	
	if($union_credits_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename>'.$union_credits_name.'</span><div class="saleabout">'.$it618_union_lang['s267'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_credits_money.'</font>'.$it618_union_lang['s482'].'</div></td></tr>';
		
		if($union_credits_tcbl2>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_credits_tcbl1.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_credits_tcbl2.'%</span></td></tr>';
	}
	
	if($union_video_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename>'.$union_video_name.'</span><div class="saleabout">'.$it618_union_lang['s700'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_video_money.'</font>'.$it618_union_lang['s482'].'</div></td></tr>';
		
		if($union_video_tcbl2>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_video_tcbl1.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_video_tcbl2.'%</span></td></tr>';
	}
	
	if($union_exam_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename>'.$union_exam_name.'</span><div class="saleabout">'.$it618_union_lang['s700'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_exam_money.'</font>'.$it618_union_lang['s482'].'</div></td></tr>';
		
		if($union_exam_tcbl2>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_exam_tcbl1.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_exam_tcbl2.'%</span></td></tr>';
	}
	
	if($union_group_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename>'.$union_group_name.'</span><div class="saleabout">'.$it618_union_lang['s700'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_group_money.'</font>'.$it618_union_lang['s482'].'</div></td></tr>';
		
		if($union_group_tcbl2>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_group_tcbl1.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_group_tcbl2.'%</span></td></tr>';
	}
	
	if($union_brand_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename>'.$union_brand_name.'</span><div class="saleabout">'.$it618_union_lang['s268'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_brand_money.'</font>'.$it618_union_lang['s482'].' '.$it618_union_lang['s465'].'</div></td></tr>';
		
		if($union_brand_tcbl2>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_brand_tcbl1.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_brand_tcbl2.'%</span></td></tr>';
	}
	
	if($union_tuan_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename>'.$union_tuan_name.'</span><div class="saleabout">'.$it618_union_lang['s268'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_tuan_money.'</font>'.$it618_union_lang['s482'].' '.$it618_union_lang['s465'].'</div></td></tr>';
		
		if($union_tuan_tcbl2>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_tuan_tcbl1.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_tuan_tcbl2.'%</span></td></tr>';
	}
	
	if($union_waimai_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename>'.$union_waimai_name.'</span><div class="saleabout">'.$it618_union_lang['s481'].'<font color=red>'.$union_waimai_money.'</font>'.$it618_union_lang['s482'].' '.$it618_union_lang['s465'].'</div></td></tr>';
		
		if($union_waimai_tcbl2>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_waimai_tcbl1.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_waimai_tcbl2.'%</span></td></tr>';
	}
	
	if($union_sale_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename>'.$union_sale_name.'</span><div class="saleabout">'.$it618_union_lang['s999'].' '.$it618_union_lang['s1000'].'<font color=red>'.$union_sale_money.'</font>'.$it618_union_lang['s482'].'</div></td></tr>';
		
		if($union_sale_tcbl2>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_sale_tcbl1.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_sale_tcbl2.'%</span></td></tr>';
	}
	
	if($union_paotui_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename>'.$union_paotui_name.'</span><div class="saleabout">'.$it618_union_lang['s481'].'<font color=red>'.$union_paotui_money.'</font>'.$it618_union_lang['s482'].' '.$it618_union_lang['s465'].'</div></td></tr>';
		
		if($union_paotui_tcbl2>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_paotui_tcbl1.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_paotui_tcbl2.'%</span></td></tr>';
	}
	
	if($union_witkey_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename1>'.$union_witkey_name.'</span><div class="saleabout">'.$it618_union_lang['s648'].'<font color=red>'.$union_witkey_post_money.'</font></div></td></tr>';
		
		if($union_witkey_post1>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_witkey_post.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_witkey_post1.'%</span></td></tr>';
		
		$salestr.='<tr><td colspan=2 class=tdname><div class="saleabout">'.$it618_union_lang['s649'].'<font color=red>'.$union_witkey_get_money.'</font></div></td></tr>';
		
		if($union_witkey_get1>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_witkey_get.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_witkey_get1.'%</span></td></tr>';
	}
	
	if($union_wike_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename1>'.$union_wike_name.'</span><div class="saleabout">'.$it618_union_lang['s648'].'<font color=red>'.$union_wike_post_money.'</font></div></td></tr>';
		
		if($union_wike_post1>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_wike_post.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_wike_post1.'%</span></td></tr>';
		
		$salestr.='<tr><td colspan=2 class=tdname><div class="saleabout">'.$it618_union_lang['s649'].'<font color=red>'.$union_wike_get_money.'</font></div></td></tr>';
		
		if($union_wike_get1>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_wike_get.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_wike_get1.'%</span></td></tr>';
	}
	
	if($union_scoremall_isok==1){
		$salestr.='<tr><td colspan=2 class=tdname><span class=salename1>'.$union_scoremall_name.'</span><div class="saleabout">'.$it618_union_lang['s651'].'<font color=red>'.$union_scoremall_money.'</font> '.$it618_union_lang['s465'].'</div></td></tr>';
		
		if($union_scoremall1>0)$tmpcss='';else $tmpcss='style="display:none"';
		$salestr.='<tr><td width=50%>'.$it618_union_lang['t64'].'</td><td class="tdsaletc"><span>'.$union_scoremall.'%</span></td></tr><tr '.$tmpcss.'><td>'.$it618_union_lang['t65'].'</td><td class="tdsaletc"><span>'.$union_scoremall1.'%</span></td></tr>';
	}
	
	$salestr='<table width="100%" class="salecss"><tr><th colspan=2>'.$it618_union_lang['s476'].' / '.$it618_union_lang['s477'].'</th>'.$salestr.'</table>';
}

if($pagetype=='mytui'){
	$jqueryname='IT618_UNION';
	
	$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
	$_G['mobiletpl'][2]='/';
	include template('it618_union:tui');
	$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
}

function gettmpstr($tmpstr){
	if($tmpstr!=''){
		$tmpstr=$tmpstr.'@';
		$tmpstr=str_replace('+ @','',$tmpstr);
	}
	
	return $tmpstr;
}

$_G['mobiletpl'][2]='/';
include template('it618_union:'.$union_templatename_wap.'/wap_union');
?>