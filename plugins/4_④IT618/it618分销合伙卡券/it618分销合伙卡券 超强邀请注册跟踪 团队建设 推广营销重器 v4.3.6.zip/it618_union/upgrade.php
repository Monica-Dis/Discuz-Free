<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_union/message.php',DISCUZ_ROOT.'./source/plugin/it618_union/config/message.php');
}

DB::query("update ".DB::table('common_plugin')." set name='".lang('plugin/it618_union', 'it618_name')."' where identifier='it618_union'");

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_union_tui` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(1000) NOT NULL,
  `it618_pic` varchar(300) NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_etime` varchar(20) NOT NULL,
  `it618_pids` varchar(300) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_joincount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_union_tuijoin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_code` varchar(50) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_union_tuitc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tc_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_saleuid` int(10) unsigned NOT NULL,
  `it618_saletime` int(10) unsigned NOT NULL,
  `it618_tctime` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_union_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_union_sharecode_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_plugin` varchar(50) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_isyqreg` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isshop` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isproduct` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istui` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_union_sharecode_font` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(50) NOT NULL,
  `it618_font` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_union_sharecode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cid` varchar(50) NOT NULL,
  `it618_class` varchar(50) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_content` varchar(1000) NOT NULL,
  `it618_length` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_left` int(10) unsigned NOT NULL,
  `it618_top` int(10) unsigned NOT NULL,
  `it618_width` int(10) unsigned NOT NULL,
  `it618_height` int(10) unsigned NOT NULL,
  `it618_fontsize` int(10) unsigned NOT NULL,
  `it618_fontid` int(10) unsigned NOT NULL,
  `it618_fontcolor` varchar(50) NOT NULL,
  `it618_about` varchar(255) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_reguser'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field'];
}
if(!in_array('it618_isjl1', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_isjl1` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_isjl2` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_isjl3` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_groupid', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_groupid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_groups', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_groups` varchar(255) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_money1', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_money1` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_money2', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_money2` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_saletc'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_tcmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_saletc')." add `it618_tcmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_pid', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_saletc')." add `it618_pid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_union_saletc'));
	while($it618_union_saletc = DB::fetch($query)) {
		$it618_pid=0;
		if($it618_union_saletc['it618_saletype']=='it618_video'){
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_video_sale')." where id=".$it618_union_saletc['it618_saleid']);
		}
		if($it618_union_saletc['it618_saletype']=='it618_exam'){
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_exam_sale')." where id=".$it618_union_saletc['it618_saleid']);
		}
		if($it618_union_saletc['it618_saletype']=='it618_group'){
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_group_sale')." where id=".$it618_union_saletc['it618_saleid']);
		}
		if($it618_union_saletc['it618_saletype']=='it618_brand'){
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_brand_sale')." where id=".$it618_union_saletc['it618_saleid']);
		}
		if($it618_union_saletc['it618_saletype']=='it618_tuan'){
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_tuan_sale')." where id=".$it618_union_saletc['it618_saleid']);
		}
		if($it618_pid=='')$it618_pid=0;
		$sql = "update ".DB::table('it618_union_saletc')." set it618_pid=".$it618_pid." where id=".$it618_union_saletc['id'];
		DB::query($sql);
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_jl'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_jltype', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_jl')." add `it618_jltype` varchar(50) NOT NULL;"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_quansale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_name', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_quansale')." add `it618_name` varchar(1000) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_pic', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_quansale')." add `it618_pic` varchar(300) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_saleid', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_quansale')." add `it618_saleid` int(10) unsigned NOT NULL;"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_tui'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_uids', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_tui')." add `it618_uids` varchar(1000) NOT NULL;"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_union_tui')." modify column `it618_pids` varchar(8000) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_bottomnav'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_curimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_bottomnav')." add `it618_curimg` varchar(255) NOT NULL;"; 
	DB::query($sql);  
}

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_sharecode'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field'];
}
if(!in_array('it618_radius', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_sharecode')." add `it618_radius` int(10) unsigned NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_opacity', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_sharecode')." add `it618_opacity` int(10) unsigned NOT NULL DEFAULT '100';"; 
	DB::query($sql);  
}

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_sharecode_font'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field'];
}
if(!in_array('it618_font', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_sharecode_font')." add `it618_font` varchar(255) NOT NULL;"; 
	DB::query($sql);  
	$sql = "delete from ".DB::table('it618_union_sharecode_font').";"; 
	DB::query($sql); 
}

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_reguser'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field'];
}
if(!in_array('it618_isjl11', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_isjl11` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_isjl12` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_isjl21` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_isjl22` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_isjl31` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_isjl32` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	for($i=1;$i<=8;$i++){
		$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_credit".$i."1` int(10) unsigned NOT NULL;"; 
		DB::query($sql);
		$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_credit".$i."2` int(10) unsigned NOT NULL;"; 
		DB::query($sql);
	}
}

if(!in_array('it618_yqcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_reguser')." add `it618_yqcount` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	
	$sql = "update ".DB::table('it618_union_jl')." set it618_jltype='G11' where it618_jltype='GA1';"; 
	DB::query($sql);
	$sql = "update ".DB::table('it618_union_jl')." set it618_jltype='G12' where it618_jltype='GA2';"; 
	DB::query($sql);
	$sql = "update ".DB::table('it618_union_jl')." set it618_jltype='G21' where it618_jltype='GB1';"; 
	DB::query($sql);
	$sql = "update ".DB::table('it618_union_jl')." set it618_jltype='G22' where it618_jltype='GB2';"; 
	DB::query($sql);
	$sql = "update ".DB::table('it618_union_jl')." set it618_jltype='G31' where it618_jltype='GC1';"; 
	DB::query($sql);
	$sql = "update ".DB::table('it618_union_jl')." set it618_jltype='G32' where it618_jltype='GC2';"; 
	DB::query($sql);
	
	for($i=1;$i<=8;$i++){
		$sql = "update ".DB::table('it618_union_reguser')." set it618_credit".$i."1=0;"; 
		DB::query($sql);
		$sql = "update ".DB::table('it618_union_reguser')." set it618_credit".$i."2=0;"; 
		DB::query($sql);
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_union_reguser'));
	while($it618_union_reguser = DB::fetch($query)) {
		$tuicount=DB::result_first("select count(1) from ".DB::table('it618_union_reguser')." where it618_tuiuid=".$it618_union_reguser['it618_uid']);
		$sql = "update ".DB::table('it618_union_reguser')." set it618_yqcount=".$tuicount." where id=".$it618_union_reguser['id'];
		DB::query($sql);
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_union_jl'));
	while($it618_union_jl = DB::fetch($query)) {
		$tmpisjl=str_replace("G","",$it618_union_jl['it618_jltype']);
		
		if($it618_union_jl['it618_jltype']=='G11'||$it618_union_jl['it618_jltype']=='G21'||$it618_union_jl['it618_jltype']=='G31'){ 
			for($i=1;$i<=8;$i++){
				if($it618_union_jl['it618_credit'.$i]>0){
					if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_uid=".$it618_union_jl['it618_uid'])) {
						$sql = "update ".DB::table('it618_union_reguser')." set it618_isjl".$tmpisjl."=1,it618_credit".$i."1=it618_credit".$i."1+".$it618_union_jl['it618_credit'.$i]." where id=".$it618_union_reguser['id']; 
						DB::query($sql);
					}
				}
			}
		}else{
			for($i=1;$i<=8;$i++){
				if($it618_union_jl['it618_credit'.$i]>0){
					if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_uid=".$it618_union_jl['it618_uid'])) {
						$sql = "update ".DB::table('it618_union_reguser')." set it618_isjl".$tmpisjl."=1,it618_credit".$i."2=it618_credit".$i."2+".$it618_union_jl['it618_credit'.$i]." where id=".$it618_union_reguser['id']; 
						DB::query($sql);
					}
				}
			}
		}
		
	} 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_union_userset'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_yqjlmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_userset')." add `it618_yqjlmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_money', $col_field)){
	$sql = "Alter table ".DB::table('it618_union_userset')." add `it618_money` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb24ueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb25fU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb25fU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb25fVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb25fVENfQklHNS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2luc3RhbGwucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL3VwZ3JhZGUucGhw'));
?>