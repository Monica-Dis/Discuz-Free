<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsCredits,$it618_union;

require_once DISCUZ_ROOT.'./source/plugin/it618_union/union_function.func.php';

if($_G['uid']>0){
	$u_username=$_G['username'];
	$u_avatarimg=it618_union_discuz_uc_avatar($_G['uid'],'middle');
	
	if($it618_union['rewriteurl']==0){
		$u_imgurl='home.php?mod=space&uid='.$_G['uid'];
	}else{
		$u_imgurl='space-uid-'.$_G['uid'].'.html';
	}
	
	$usercount=C::t('#it618_union#it618_union_reguser')->count_by_search('','',0,$_G['uid']);
}else{
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if($it618_members['members_isok']==1){
		$usermenu='<li class="ahref">
					<a class="it618_members_login" href="javascript:">'.$it618_union_lang['s561'].'</a>
				</li>
                <li class="ahref">
					<a class="it618_members_reg" href="javascript:">'.$it618_union_lang['s562'].'</a>
				</li>';
	}else{
		$usermenu='<li class="ahref">
					<a href="member.php?mod=logging&action=login">'.$it618_union_lang['s561'].'</a>
				</li>
                <li class="ahref">
					<a href="member.php?mod='.$RegName.'">'.$it618_union_lang['s562'].'</a>
				</li>';
	}	
}

$url_home=it618_union_getrewrite('union_home','','plugin.php?id=it618_union:index');

$pctopnav=C::t('#it618_union#it618_union_set')->getsetvalue_by_setname('pctopnav');
$pcbottom=C::t('#it618_union#it618_union_set')->getsetvalue_by_setname('pcbottom');

$url_yqreg=it618_union_getrewrite('union_uc','yqreg','plugin.php?id=it618_union:union_uc&pagetype=yqreg');
$url_myuser=it618_union_getrewrite('union_uc','myuser','plugin.php?id=it618_union:union_uc&pagetype=myuser');
$url_yqjl=it618_union_getrewrite('union_uc','yqjl','plugin.php?id=it618_union:union_uc&pagetype=yqjl');
$url_saletc=it618_union_getrewrite('union_uc','saletc','plugin.php?id=it618_union:union_uc&pagetype=saletc');

if($pagetype=='yqreg'){
	$mainnav2='class="on"';$leftnav11='on';
	$navtitle=$it618_union_lang['s162'];
}

if($pagetype=='myuser'){
	$mainnav2='class="on"';$leftnav12='on';
	$navtitle=$it618_union_lang['s163'];
}

if($pagetype=='yqjl'){
	$mainnav2='class="on"';$leftnav13='on';
	$navtitle=$it618_union_lang['s164'];
}

if($pagetype=='saletc'){
	$mainnav2='class="on"';$leftnav14='on';
	$navtitle=$it618_union_lang['s166'];
}

$url_quans=it618_union_getrewrite('union_quans','','plugin.php?id=it618_union:union_quans');
$url_myquan=it618_union_getrewrite('union_uc','myquan','plugin.php?id=it618_union:union_uc&pagetype=myquan');

if($pagetype=='quans'||$pagetype=='quan'){
	$mainnav3='class="on"';
	$navtitle=$it618_union_lang['t91'];
}

if($pagetype=='myquan'){
	$mainnav3='class="on"';$leftnav21='on';
	$navtitle=$it618_union_lang['s169'];
}

$url_tuis=it618_union_getrewrite('union_tuis','','plugin.php?id=it618_union:union_tuis');
$url_mytui=it618_union_getrewrite('union_uc','mytui','plugin.php?id=it618_union:union_uc&pagetype=mytui');
$url_tuitc=it618_union_getrewrite('union_uc','tuitc','plugin.php?id=it618_union:union_uc&pagetype=tuitc');

if($pagetype=='tuis'||$pagetype=='tui'){
	$mainnav4='class="on"';
	$navtitle=$it618_union_lang['s282'];
}


if($pagetype=='mytui'){
	$mainnav4='class="on"';$leftnav31='on';
	$navtitle=$it618_union_lang['s172'];
}

if($pagetype=='tuitc'){
	$mainnav4='class="on"';$leftnav32='on';
	$navtitle=$it618_union_lang['s173'];
}

$query = DB::query("SELECT * FROM ".DB::table('it618_union_nav')." where it618_order<>0 ORDER BY it618_order");
while($it618_union_nav = DB::fetch($query)) {
	$it618_name=$it618_union_nav['it618_name'];
	
	if($it618_union_nav['it618_color']!=''){
		$it618_name='<font color="'.$it618_union_nav['it618_color'].'">'.$it618_name.'</font>';
	}
	
	if($it618_union_nav['it618_target']==1)$it618_target=' target="_blank"';else $it618_target='';
	
	$it618_url=$it618_union_nav['it618_url'];
	
	$it618_url=str_replace("{home}",$url_home,$it618_url);
	$it618_url=str_replace("{yqreg}",$url_yqreg,$it618_url);
	$it618_url=str_replace("{quans}",$url_quans,$it618_url);
	$it618_url=str_replace("{tuis}",$url_tuis,$it618_url);
	
	$navstr.='<li><a href="'.$it618_url.'" '.$it618_target.'>'.$it618_name.'</a></li>';
}

$jqueryname='IT618_UNION';
$tuiheight='680';

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members');
}

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$it618_credits_index=it618_credits_getcredits($_GET['id'],'.it618_credits');
	$it618_credits_buygroup=it618_credits_getcredits($_GET['id'],'#grouppaybtn','plugin.php?id=it618_credits:do&dotype=buygroup');
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_uc=it618_group_getgroup($_GET['id'],'#it618_group');
	$it618_group_ad=it618_group_getad($_GET['id'],2);
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/it618_api.func.php';

$_G['mobiletpl'][2]='/';
include template('it618_union:tui');

?>