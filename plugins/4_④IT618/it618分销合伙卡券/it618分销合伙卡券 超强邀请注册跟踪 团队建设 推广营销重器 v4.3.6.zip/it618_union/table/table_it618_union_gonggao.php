<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_union_gonggao extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_union_gonggao';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_order() {
		return DB::fetch_first("SELECT * FROM %t ORDER BY it618_order", array($this->_table));
	}
	
	public function fetch_all_by_search() {
		return DB::fetch_all("SELECT * FROM %t ORDER BY it618_order", array($this->_table));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}

?>