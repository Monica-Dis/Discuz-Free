<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_union_tuitc extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_union_tuitc';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_saleid($saleid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_saleid=%d", array($this->_table, $saleid));
	}
	
	public function fetch_by_shoptype_saleid($shoptype,$saleid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_shoptype=%s and it618_saleid=%d", array($this->_table, $shoptype, $saleid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_shoptype_shopid($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby='', $it618_name = '', $it618_saletime1 = '', $it618_saletime2 = '', $it618_tctime1 = '', $it618_tctime2 = '') {
		$condition = $this->make_query_condition($it618_shoptype, $it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_saletime1, $it618_saletime2, $it618_tctime1, $it618_tctime2);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function sum_by_shoptype_shopid($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby='', $it618_name = '', $it618_saletime1 = '', $it618_saletime2 = '', $it618_tctime1 = '', $it618_tctime2 = '') {
		$condition = $this->make_query_condition($it618_shoptype, $it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_saletime1, $it618_saletime2, $it618_tctime1, $it618_tctime2);
		return DB::fetch_first("SELECT sum(it618_tc_credit1) as jf1,sum(it618_tc_credit2) as jf2,sum(it618_tc_credit3) as jf3,sum(it618_tc_credit4) as jf4,sum(it618_tc_credit5) as jf5,sum(it618_tc_credit6) as jf6,sum(it618_tc_credit7) as jf7,sum(it618_tc_credit8) as jf8,sum(it618_tc_money) as tcmoney FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_shoptype_shopid($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_saletime1 = '', $it618_saletime2 = '', $it618_tctime1 = '', $it618_tctime2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shoptype, $it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_saletime1, $it618_saletime2, $it618_tctime1, $it618_tctime2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_saletime1 = '', $it618_saletime2 = '', $it618_tctime1 = '', $it618_tctime2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618_shoptype)) {
			$parameter[] = $it618_shoptype;
			$wherearr[] = 'it618_shoptype=%s';
		}
		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = 'it618_name LIKE %s';
		}
		if(!empty($it618_saletime1)) {
			$parameter[] = $it618_saletime1;
			$wherearr[] = 'it618_saletime>=unix_timestamp(%s)';
		}
		if(!empty($it618_saletime2)) {
			$parameter[] = $it618_saletime2.' 23:59:59';
			$wherearr[] = 'it618_saletime<=unix_timestamp(%s)';
		}
		if(!empty($it618_tctime1)) {
			$parameter[] = $it618_tctime1;
			$wherearr[] = 'it618_tctime>=unix_timestamp(%s)';
		}
		if(!empty($it618_tctime2)) {
			$parameter[] = $it618_tctime2.' 23:59:59';
			$wherearr[] = 'it618_tctime<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}

?>