<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$oss,$ShopType,$ShopId,$adminsid;

require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

if($_GET['shoptype']=='video'){
	$ShopType='video';
	require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_default.func.php';
}

if($_GET['shoptype']=='exam'){
	$ShopType='exam';
	require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_default.func.php';
}

if($_GET['shoptype']=='group'){
	$ShopType='group';
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_default.func.php';
}

if($_GET['shoptype']=='brand'){
	$ShopType='brand';
	require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_default.func.php';
}

if($_GET['shoptype']=='tuan'){
	$ShopType='tuan';
	require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_default.func.php';
}

if($ShopType=='')exit;
$adminsid.='&shoptype='.$ShopType;

$oss='';
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/php/aliyunossconfig.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/php/aliyunossconfig.php';
	if($it618_isok==1){
		$oss='&oss';
	}
}
?>