<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_header.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/quanset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/quanset.php';
}

$qid=intval($_GET['qid']);
if($it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_id($qid)){
	if($ShopType!='group'){
		if($it618_union_quan['it618_shoptype']!=$ShopType||$it618_union_quan['it618_shopid']!=$ShopId){
			it618_cpmsg(it618_union_getlang('s254'), "", 'error');
		}	
	}
}else{
	it618_cpmsg(it618_union_getlang('s253'), "", 'error');
}

if(submitcheck('it618submit')){	
	if($it618_union_quan['it618_pic']!=$_GET['it618_pic']){
		$tmparr=explode("source",$it618_union_quan['it618_pic']);
		$tmparr1=explode("://",$it618_union_quan['it618_pic']);
		$it618_pic=DISCUZ_ROOT.'./source'.$tmparr[1];
		
		if(file_exists($it618_pic)&&count($tmparr1)==1){
			$result=unlink($it618_pic);
		}
	}
	
	$it618_ismoney=0;
	for($i=1;$i<=8;$i++){
		if($_GET['it618_credit'.$i]>0){
			$it618_ismoney=1;
			break;
		}
	}
	
	if($_GET['pidstype']==1){
		$pids='';
	}else{
		$pids_array = !empty($_GET['it618_pids']) ? $_GET['it618_pids'] : array();
		foreach($pids_array as $key => $value) {
			$pids.=intval($value).',';
		}
		if($pids!='')$pids=str_replace(",,","",$pids.',');
	}

	C::t('#it618_union#it618_union_quan')->update($qid,array(
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_mjmoney1' => $_GET['it618_mjmoney1'],
		'it618_mjmoney2' => $_GET['it618_mjmoney2'],
		'it618_money' => $_GET['it618_money'],
		'it618_credit1' => $_GET['it618_credit1'],
		'it618_credit2' => $_GET['it618_credit2'],
		'it618_credit3' => $_GET['it618_credit3'],
		'it618_credit4' => $_GET['it618_credit4'],
		'it618_credit5' => $_GET['it618_credit5'],
		'it618_credit6' => $_GET['it618_credit6'],
		'it618_credit7' => $_GET['it618_credit7'],
		'it618_credit8' => $_GET['it618_credit8'],
		'it618_ismoney' => $it618_ismoney,
		'it618_count' => $_GET['it618_count'],
		'it618_xgtime' => $_GET['it618_xgtime'],
		'it618_xgcount' => $_GET['it618_xgcount'],
		'it618_xgtype' => $_GET['it618_xgtype'],
		'it618_xgtime1' => dhtmlspecialchars($_GET['it618_xgtime1']),
		'it618_xgtime2' => dhtmlspecialchars($_GET['it618_xgtime2']),
		'it618_oktime1' => dhtmlspecialchars($_GET['it618_oktime1']),
		'it618_oktime2' => dhtmlspecialchars($_GET['it618_oktime2']),
		'it618_seokeywords' => dhtmlspecialchars($_GET['it618_seokeywords']),
		'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription']),
		'it618_pic' => dhtmlspecialchars($_GET['it618_pic']),
		'it618_pids' => $pids,
		'it618_message' => $_GET['it618_message']
	), true);

	$preurl=str_replace("@","&",$_GET['preurl']);
	it618_cpmsg(it618_union_getlang('s255'), $preurl, 'succeed');
}

it618_showformheader("plugin.php?id=it618_union:sc_quan_edit$adminsid&qid=$qid&preurl=".$_GET['preurl']);
showtableheaders(it618_union_getlang('s175'),'it618_union_quan');


if($it618_union_quan['it618_pids']==''){
	$pidscss1='selected="selected"';
	$pidscss2='';
	$pidscss='none';
}else{
	$pidscss1='';
	$pidscss2='selected="selected"';
	$pidscss='';
}

if($ShopType=='video'){
	$union_credits=$union_video_credits;
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods')." where it618_state=1 and it618_shopid=$ShopId");
}
if($ShopType=='exam'){
	$union_credits=$union_exam_credits;
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods')." where it618_gtype=1 and it618_state=1 and it618_shopid=$ShopId");
}
if($ShopType=='group'){
	$union_credits=$union_group_credits;
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_goods')." where it618_state=1");
}
if($ShopType=='brand'){
	$union_credits=$union_brand_credits;
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods')." where it618_ison=1 and it618_shopid=$ShopId");
}
if($ShopType=='tuan'){
	$union_credits=$union_tuan_credits;
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods')." where it618_state=1 and it618_shopid=$ShopId");
}

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		if($union_credits[$i]==1){
			$quanpricestr.=$_G['setting']['extcredits'][$i]['title'].'=<input type="text" class="txt" style="width:50px;color:red" name="it618_credit'.$i.'" value="'.$it618_union_quan['it618_credit'.$i].'"> ';
		}else{
			if($it618_union_quan['it618_credit'.$i]>0){
				$quanpricestr.='<input type="hidden" class="txt" style="width:50px;color:red" name="it618_credit'.$i.'" value="0"> ';
			}
		}
	}
}

$tmparr=explode(",",$it618_union_quan['it618_pids']);
while($tmpgoods = DB::fetch($query)) {
	$tmpchecked='';
	if(in_array($tmpgoods['id'],$tmparr))$tmpchecked='checked="checked"';
	
	if($ShopType=='group'){
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($tmpgoods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$tmpgoods['it618_groupid']);
		$it618_unit=it618_union_getvipgoodsunit($tmpgoods);
		$tmpgoods['it618_name']=$grouptitle.' '.$it618_unit;
	}
	
	$it618_pids_str.='<li><input type="checkbox" id="it618_pids'.$tmpgoods['id'].'" name="it618_pids[]" value="'.$tmpgoods['id'].'" style="vertical-align:middle" '.$tmpchecked.'><label for="it618_pids'.$tmpgoods['id'].'">['.$tmpgoods['id'].'] '.$tmpgoods['it618_name'].'</label></li>';
}

if($it618_union_quan['it618_xgtype']==0)$it618_xgtype0='selected="selected"';
if($it618_union_quan['it618_xgtype']==1)$it618_xgtype1='selected="selected"';
if($it618_union_quan['it618_xgtype']==2)$it618_xgtype2='selected="selected"';

echo '
<link rel="stylesheet" href="source/plugin/it618_union/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_union/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/plugins/code/prettify.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_union/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_union/kindeditor/php/upload_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'&imgwidth=930'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_union/kindeditor/php/file_manager_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false
		});
		
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_union/kindeditor/php/upload_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'&imgwidth=260'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_union/kindeditor/php/file_manager_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'\',
			allowFileManager : true
		});
		
		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#it618_pic\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#it618_pic\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
		
	});
	
	function gettype(index){
		document.getElementById("spantype1").style.display="none";
		document.getElementById("spantype2").style.display="none";
		document.getElementById("spantype"+index).style.display="";
	}
	
	function checkvalue(){
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_union_getlang('s210').'");
			document.getElementById("it618_name").focus();
			return false;
		}

		if(document.getElementById("it618_pic").value==""){
			alert("'.it618_union_getlang('s211').'");
			return false;
		}
		
		if(document.getElementById("it618_type").value==1){
			if(parseFloat(document.getElementById("it618_mjmoney2").value)<=0||parseFloat(document.getElementById("it618_mjmoney2").value)>parseFloat(document.getElementById("it618_mjmoney1").value)){
				alert("'.it618_union_getlang('s213').'");
				document.getElementById("it618_mjmoney2").focus();
				return false;
			}
		}else{
			if(parseFloat(document.getElementById("it618_money").value)<=0){
				alert("'.it618_union_getlang('s212').'");
				document.getElementById("it618_money").focus();
				return false;
			}
		}
		
		if(document.getElementById("it618_oktime1").value==""||document.getElementById("it618_oktime2").value==""){
			alert("'.it618_union_getlang('s214').'");
			return false;
		}
		
		if(document.getElementById("it618_xgtype").value>0){
			if(document.getElementById("it618_xgtime1").value==""||document.getElementById("it618_xgtime2").value==""){
				alert("'.it618_union_getlang('s248').'");
				return false;
			}
		}

		if(document.getElementById("pidstype").value==2){
			var checkbox = document.getElementsByName("it618_pids[]");
			var checked_counts = 0;
			for(var i=0;i<checkbox.length;i++){
				
				if(checkbox[i].checked){
					checked_counts++;
				}
			}
			
			if(checked_counts>30){
				alert("'.it618_union_getlang('s637').'");
				return false;
			}
		}
	}
	
	function getpids(objvalue){
		if(objvalue==1){
			document.getElementById("spangoods").style.display="none";
		}else{
			document.getElementById("spangoods").style.display="";
		}
	}
</script>

<style>
.goodsul{float:left;background-color:#f1f1f1;padding:10px}
.goodsul li{float:left;width:530px}
</style>

<tr><td colspan=2><font color=red>'.it618_union_getlang('s215').'</font></td></tr>
<tr><td width=80>'.it618_union_getlang('s181').'</td><td><input type="hidden" id="it618_type" value="'.$it618_union_quan['it618_type'].'"><input type="text" class="txt" style="width:400px;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_union_quan['it618_name'].'"></td></tr>
<tr><td>'.it618_union_getlang('s190').'</td><td><img id="img1" width="80" height="80" align="absmiddle" src="'.$it618_union_quan['it618_pic'].'"/> <input type="text" id="it618_pic" name="it618_pic" readonly="readonly" value="'.$it618_union_quan['it618_pic'].'"/> <input type="button" id="image1" value="'.it618_union_getlang('s191').'" /></td></tr>
<tr><td>'.it618_union_getlang('s192').'</td><td>
<span id="spantype1">'.$it618_union_lang['s193'].' <input type="text" class="txt" style="width:80px;margin-right:3px;color:red" id="it618_mjmoney1" name="it618_mjmoney1" value="'.$it618_union_quan['it618_mjmoney1'].'">'.$it618_union_lang['s194'].' <input type="text" class="txt" style="width:80px;margin-right:3px;color:red" id="it618_mjmoney2" name="it618_mjmoney2" value="'.$it618_union_quan['it618_mjmoney2'].'">'.$it618_union_lang['s195'].'</span>
<span id="spantype2" style="display:none">'.$it618_union_lang['s196'].' <input type="text" class="txt" style="width:80px;margin-right:3px;color:red" id="it618_money" name="it618_money" value="'.$it618_union_quan['it618_money'].'">'.$it618_union_lang['s195'].'</span></td></tr>
<tr><td>'.it618_union_getlang('s186').'</td><td><input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_oktime1" name="it618_oktime1" readonly="readonly" value="'.$it618_union_quan['it618_oktime1'].'">- <input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_oktime2" name="it618_oktime2" readonly="readonly" value="'.$it618_union_quan['it618_oktime2'].'"> <font color=#999>'.$it618_union_lang['s187'].'</font></td></tr>
<tr><td>'.it618_union_getlang('s182').'</td><td style="line-height:26px">'.$quanpricestr.'<br><font color=#999>'.$it618_union_lang['s183'].'</font></td></tr>
<tr><td>'.it618_union_getlang('s208').'</td><td><input type="text" class="txt" style="width:80px;margin-right:0" name="it618_count" value="'.$it618_union_quan['it618_count'].'"> <font color=#999>'.$it618_union_lang['s209'].'</font></td></tr>
<tr><td>'.it618_union_getlang('s184').'</td><td style="line-height:26px"><select id="pidstype" name="pidstype" onchange="getpids(this.value)" style="margin-bottom:3px"><option value="1" '.$pidscss1.'>'.$it618_union_lang['s635'].'</option><option value="2" '.$pidscss2.'>'.$it618_union_lang['s636'].'</option></select><span id="spangoods" style="display: '.$pidscss.'"><ul class="goodsul">'.$it618_pids_str.'</ul><div style="float:left;width:100%"><font color=#999>'.$it618_union_lang['s185'].'</font></div></span></td></tr>
<tr><td>'.it618_union_getlang('s188').'</td><td>'.it618_union_getlang('s197').' <input type="text" class="txt" style="width:40px;margin-right:3px" name="it618_xgtime" value="'.$it618_union_quan['it618_xgtime'].'">'.it618_union_getlang('s198').'<input type="text" class="txt" style="width:40px;margin-right:3px" name="it618_xgcount" value="'.$it618_union_quan['it618_xgcount'].'">'.it618_union_getlang('s199').'</td></tr>
<tr><td>'.it618_union_getlang('s189').'</td><td><input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_xgtime1" name="it618_xgtime1" readonly="readonly" value="'.$it618_union_quan['it618_xgtime1'].'">- <input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_xgtime2" name="it618_xgtime2" readonly="readonly" value="'.$it618_union_quan['it618_xgtime2'].'"><select id="it618_xgtype" name="it618_xgtype"><option value="0" '.$it618_xgtype0.'>'.it618_union_getlang('s200').'</option><option value="1" '.$it618_xgtype1.'>'.it618_union_getlang('s201').'</option><option value="2" '.$it618_xgtype2.'>'.it618_union_getlang('s202').'</option></select></td></tr>
<tr><td>'.it618_union_getlang('s203').'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_union_quan['it618_message'].'</textarea></td></tr>
<tr><td>'.it618_union_getlang('s204').'</td><td><input type="text" class="txt" style="width:695px;margin-right:0" name="it618_seokeywords" value="'.$it618_union_quan['it618_seokeywords'].'"></td></tr>
<tr><td>'.it618_union_getlang('s205').'</td><td><textarea name="it618_seodescription" style="width:695px;height:50px;">'.$it618_union_quan['it618_seodescription'].'</textarea></td></tr>
<script>
gettype('.$it618_union_quan['it618_type'].');
</script>
<style>.laydate-btns-time{float:left}</style>
<script>
  laydate.render({
	elem: "#it618_oktime1"
	,type: "datetime"
	,format: "yyyy-MM-dd HH:mm"
  });
  laydate.render({
	elem: "#it618_oktime2"
	,type: "datetime"
	,format: "yyyy-MM-dd HH:mm"
  });
  laydate.render({
	elem: "#it618_xgtime1"
	,type: "datetime"
	,format: "yyyy-MM-dd HH:mm"
  });
  laydate.render({
	elem: "#it618_xgtime2"
	,type: "datetime"
	,format: "yyyy-MM-dd HH:mm"
  });
</script>
';

echo '<tr><td colspan=2><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_union_getlang('s206').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_footer.func.php';
?>