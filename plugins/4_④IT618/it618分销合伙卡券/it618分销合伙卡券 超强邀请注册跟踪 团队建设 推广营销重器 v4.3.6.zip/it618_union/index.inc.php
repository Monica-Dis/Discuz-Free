<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$pagemod='index';
$pagetype='index';
require_once DISCUZ_ROOT.'./source/plugin/it618_union/union_default.func.php';

if(union_is_mobile()){
	$tmpurl=it618_union_getrewrite('union_wap','','plugin.php?id=it618_union:wap');
	dheader("location:$tmpurl");
}

foreach(C::t('#it618_union#it618_union_focus')->fetch_all_by_type_order(0) as $it618_union_focus) {
	if($it618_union_focus['it618_url']!=''){
		$str_focus.='<li><a href="'.$it618_union_focus['it618_url'].'" target="_blank"><img src="'.$it618_union_focus['it618_img'].'"/></a></li>';
	}else{
		$str_focus.='<li><img src="'.$it618_union_focus['it618_img'].'"/></li>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_union_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_union_gonggao = DB::fetch($query)) {
	$it618_title=$it618_union_gonggao['it618_title'];
	
	if($it618_union_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_union_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_union_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_union_gonggao['it618_url'].'" target="_blank" title="'.$it618_union_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

$il1i1l=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$il1i1l[]=substr($_GET['id'],$i,1);}
if(count($il1i1l)!=11)return;
if($il1i1l[6]!='u')return;

$query = DB::query("SELECT * FROM ".DB::table('it618_union_reguser')." ORDER BY it618_time desc LIMIT 0,15");

$n=1;
while($getphlist_tmp = DB::fetch($query)) {
	$username1=it618_union_getusername($getphlist_tmp['it618_uid']);
	$userurl1=it618_union_rewriteurl($getphlist_tmp['it618_uid']);
	$username2=it618_union_getusername($getphlist_tmp['it618_tuiuid']);
	$userurl2=it618_union_rewriteurl($getphlist_tmp['it618_tuiuid']);

	$conphstr.='<li><font color=red>'.it618_union_gettime($getphlist_tmp['it618_time']).'</font> <a href="'.$userurl2.'" target="_blank">'.$username2.'</a> '.$it618_union_lang['s121'].' <a href="'.$userurl1.'" target="_blank">'.$username1.'</a> '.$it618_union_lang['s122'].'</li>';
}

if($it618_union['union_isquantui']==1){
	$homequanstr1=gethomequan('it618_ison=1');
	$homequanstr2=gethomequan('it618_ison=1 and it618_type=1');
	$homequanstr3=gethomequan('it618_ison=1 and it618_type=2');
	
	$hometuistr1=gethometui('it618_ison=1');
	$hometuistr2=gethometui('it618_ison=1 and it618_tcbl<'.$it618_union['union_tuibigtcbl']);
	$hometuistr3=gethometui('it618_ison=1 and it618_tcbl>='.$it618_union['union_tuibigtcbl']);
	
	$tomonth = date('n'); 
	$todate = date('j'); 
	$toyear = date('Y');
	
	$time=mktime(0, 0, 0, $tomonth, $todate-7, $toyear);
	$homequanhotstr1=gethomequanhot($time);
	$hometuihotstr1=gethometuihot($time);
	
	$time=mktime(0, 0, 0, $tomonth, 1, $toyear);
	$homequanhotstr2=gethomequanhot($time);
	$hometuihotstr2=gethometuihot($time);
	
	$homequanhotstr3=gethomequanhot(0);
	$hometuihotstr3=gethometuihot(0);
	
	$query = DB::query("SELECT it618_qid,it618_uid,it618_time FROM ".DB::table('it618_union_quansale')." ORDER BY id desc limit 0,30");
	while($it618_homequan = DB::fetch($query)) {
		if(!($it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_ison_id($it618_homequan['it618_qid']))){
			continue;
		}
		
		$tmpurl=it618_union_getrewrite('union_quan',$it618_union_quan['id'],'plugin.php?id=it618_union:union_quan&qid='.$it618_union_quan['id']);
	
		$homequansalestr.='<li class="clearfix">
						  <div class="scrollL">
							  <p class="scrollName"><em>'.it618_union_getusername($it618_homequan['it618_uid']).'</em> <span>'.it618_union_gettime($it618_homequan['it618_time']).'</span></p>
							  <p class="scrollDesc">'.$it618_union_quan['it618_name'].'</p>
						  </div>
						  <a class="scrollR" href="'.$tmpurl.'" target="_blank"><span>'.$it618_union_lang['s270'].'</span></a>
						  </li>';
	}
	
	$query = DB::query("SELECT it618_tid,it618_uid,it618_time FROM ".DB::table('it618_union_tuijoin')." ORDER BY id desc limit 0,30");
	while($it618_hometui = DB::fetch($query)) {
		if(!($it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_ison_id($it618_hometui['it618_tid']))){
			continue;
		}
		
		$tmpurl=it618_union_getrewrite('union_tui',$it618_union_tui['id'],'plugin.php?id=it618_union:union_tui&tid='.$it618_union_tui['id']);
	
		$hometuijoinstr.='<li class="clearfix">
						  <div class="scrollL">
							  <p class="scrollName"><em>'.it618_union_getusername($it618_hometui['it618_uid']).'</em> <span>'.it618_union_gettime($it618_hometui['it618_time']).'</span></p>
							  <p class="scrollDesc">'.$it618_union_tui['it618_name'].'</p>
						  </div>
						  <a class="scrollR" href="'.$tmpurl.'" target="_blank"><span>'.$it618_union_lang['s580'].'</span></a>
						  </li>';
	}
	
}

function gethomequan($sql){
	global $_G,$it618_union_lang;
	
	foreach(C::t('#it618_union#it618_union_quan')->fetch_all_by_shoptype_shopid(
		'',0,$sql,'id desc','',0,0,10
	) as $it618_union_quan) {
		if($it618_union_quan['it618_type']==1){
			$it618_type=$it618_union_lang['s240'].$it618_union_quan['it618_mjmoney1'].$it618_union_lang['s195'].$it618_union_lang['s241'].$it618_union_quan['it618_mjmoney2'].$it618_union_lang['s195'];
		}else{
			$it618_type=$it618_union_quan['it618_money'].$it618_union_lang['s195'];
		}
		
		if($it618_union_quan['it618_pids']==''){
			$it618_pids='<p>'.$it618_union_lang['s547'].'</p>';
		}else{
			$it618_pids='<p onclick="showgoods(\'quan\','.$it618_union_quan['id'].')" style="cursor:pointer;color:#39F">'.$it618_union_lang['s545'].'</p>';
		}
		
		$tmpurl=it618_union_getrewrite('union_quan',$it618_union_quan['id'],'plugin.php?id=it618_union:union_quan&qid='.$it618_union_quan['id']);
	
		$homequanstr.='<div class="tabQuanItem clearfix">
						  <div class="indexItemImg">
							  <img src="'.$it618_union_quan['it618_pic'].'"/>
						  </div>
						  <div class="indexItemInfo">
					  
							  <h4 style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'.$it618_union_quan['it618_name'].'</h4>
							  <p style="color:#f60">'.$it618_type.'</p>
							  '.$it618_pids.'
							  <div class="indexItemAction">
								  <a href="'.$tmpurl.'" target="_blank" class="androidGet clearfix"><i></i><span>'.$it618_union_lang['s269'].'</span></a>
							  </div>
						  </div>
					  </div>';
	}
	
	return $homequanstr;
}

function gethomequanhot($time){
	global $_G,$it618_union_lang;
	
	$n=1;
	$query = DB::query("SELECT it618_qid,count(1) as salecount FROM ".DB::table('it618_union_quansale')." where it618_time>=$time GROUP BY it618_qid ORDER BY salecount desc limit 0,5");
	while($it618_homequan = DB::fetch($query)) {
		if(!($it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_ison_id($it618_homequan['it618_qid']))){
			continue;
		}
	
		if($it618_union_quan['it618_type']==1){
			$it618_type=$it618_union_lang['s240'].$it618_union_quan['it618_mjmoney1'].$it618_union_lang['s195'].$it618_union_lang['s241'].$it618_union_quan['it618_mjmoney2'].$it618_union_lang['s195'];
		}else{
			$it618_type=$it618_union_quan['it618_money'].$it618_union_lang['s195'];
		}
		
		$tmpurl=it618_union_getrewrite('union_quan',$it618_union_quan['id'],'plugin.php?id=it618_union:union_quan&qid='.$it618_union_quan['id']);
		
		$tmpcss1='';$tmpcss2='hide';
		if($homequanhotstr==''){$tmpcss1='hide';$tmpcss2='';}
	
		$homequanhotstr.='<div class="rankLine">	
					  <div class="rankItemBox1 rankItemBox11 '.$tmpcss1.'">
						  <div class="rankItem1 clearfix">
						  <i>'.$n.'</i>
						  <p style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'.$it618_union_quan['it618_name'].'</p>
						  <span>'.$it618_union_quan['it618_salecount'].'</span>
						  </div>
					  </div>
					  
					  <div class="rankItemBox2 rankItemBox21 '.$tmpcss2.'">
						  <a href="'.$tmpurl.'" target="_blank" class="rankImg"><img src="'.$it618_union_quan['it618_pic'].'" height="60" width="60" alt="" /></a>
						  <div class="rankInfo">
							  <a href="'.$tmpurl.'" target="_blank" class="rankTitle" ><p style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'.$it618_union_quan['it618_name'].'</p></a>
							  <p>'.$it618_type.'</p>
						  </div>
					  </div>
				  </div>';
		$n=$n+1;
	}
	
	return $homequanhotstr;
}

function gethometui($sql){
	global $_G,$it618_union_lang;
	
	foreach(C::t('#it618_union#it618_union_tui')->fetch_all_by_shoptype_shopid(
		'',0,$sql.' and UNIX_TIMESTAMP(it618_etime)>'.$_G['timestamp'],'id desc','',0,0,10
	) as $it618_union_tui) {
		
		$it618_pids='<p onclick="showgoods(\'tui\','.$it618_union_tui['id'].')" style="cursor:pointer;color:#39F">'.$it618_union_lang['s545'].'</p>';
		
		$tmpurl=it618_union_getrewrite('union_tui',$it618_union_tui['id'],'plugin.php?id=it618_union:union_tui&tid='.$it618_union_tui['id']);
	
		$hometuistr.='<div class="tabQuanItem clearfix">
						  <div class="indexItemImg">
							  <img src="'.$it618_union_tui['it618_pic'].'"/>
						  </div>
						  <div class="indexItemInfo">
					  
							  <h4 style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'.$it618_union_tui['it618_name'].'</h4>
							  <p>'.$it618_union_lang['s515'].'<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font></p> 
							  '.$it618_pids.'
							  <div class="itemAction">
								  <a href="'.$tmpurl.'" target="_blank" class="androidGet clearfix"><i></i><span>'.$it618_union_lang['s558'].'</span></a>
							  </div>
						  </div>
					  </div>';
	}
	
	return $hometuistr;
}

function gethometuihot($time){
	global $_G,$it618_union_lang;
	
	$n=1;
	$query = DB::query("SELECT it618_tid,count(1) as joincount FROM ".DB::table('it618_union_tuijoin')." where it618_time>=$time GROUP BY it618_tid ORDER BY joincount desc limit 0,5");
	while($it618_hometui = DB::fetch($query)) {
		if(!($it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_ison_id($it618_hometui['it618_tid']))){
			continue;
		}
		
		$tmpurl=it618_union_getrewrite('union_tui',$it618_union_tui['id'],'plugin.php?id=it618_union:union_tui&tid='.$it618_union_tui['id']);
		
		$tmpcss1='';$tmpcss2='hide';
		if($hometuihotstr==''){$tmpcss1='hide';$tmpcss2='';}
	
		$hometuihotstr.='<div class="rankLine">	
					  <div class="rankItemBox1 rankItemBox12 '.$tmpcss1.'">
						  <div class="rankItem1 clearfix">
						  <i>'.$n.'</i>
						  <p style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'.$it618_union_tui['it618_name'].'</p>
						  <span>'.$it618_union_tui['it618_joincount'].'</span>
						  </div>
					  </div>
					  
					  <div class="rankItemBox2 rankItemBox22 '.$tmpcss2.'">
						  <a href="'.$tmpurl.'" target="_blank" class="rankImg"><img src="'.$it618_union_tui['it618_pic'].'" height="60" width="60" alt="" /></a>
						  <div class="rankInfo">
							  <a href="'.$tmpurl.'" target="_blank" class="rankTitle" ><p style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'.$it618_union_tui['it618_name'].'</p></a>
							  <p>'.$it618_union_lang['s515'].'<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font></p>
						  </div>
					  </div>
				  </div>';
		$n=$n+1;
	}
	
	return $hometuihotstr;
}

$navtitle=$it618_union_lang['t3'].' - '.$it618_union['seotitle'];

$_G['mobiletpl'][2]='/';
include template('it618_union:'.$union_templatename.'/union_default');
?>