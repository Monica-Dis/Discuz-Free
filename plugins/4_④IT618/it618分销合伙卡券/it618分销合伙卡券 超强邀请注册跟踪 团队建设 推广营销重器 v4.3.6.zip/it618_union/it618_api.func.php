<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsCredits,$IsChat,$it618_union,$it618_hongbao_lang;

if(union_is_mobile())$wap=1;

if($IsChat==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/function.func.php';
	
	$chatplugin='it618_union';
	$chatsid=0;
	
	$it618_chat_kefu = it618_chat_getkefu($chatplugin,$chatsid,$wap);
}
?>