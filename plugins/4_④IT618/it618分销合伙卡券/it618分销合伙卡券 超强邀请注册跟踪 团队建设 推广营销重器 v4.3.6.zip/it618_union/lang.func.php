<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsMembers,$IsCredits,$IsGroup,$IsChat,$IsWxMini,$RegName,$union_templatename,$union_templatename_wap,$union_template_set;
$RegName=$_G['setting']['regname'];

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/templateset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/templateset.php';
}

if($union_template_set['pcname']=='')$template_pcname='default';else $template_pcname=$union_template_set['pcname'];
if($union_template_set['wapname']=='')$template_wapname='default_wap';else $template_wapname=$union_template_set['wapname'];

$union_templatename=$template_pcname;
$union_templatename_wap=$template_wapname;

$it618_members = $_G['cache']['plugin']['it618_members'];
if($it618_members['members_isok']==1){
	$IsMembers=1;
}

$it618_credits = $_G['cache']['plugin']['it618_credits'];
if($it618_credits['seotitle']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/plugins/autoheight/it618.png')){
	$IsCredits=1;
}

$it618_group = $_G['cache']['plugin']['it618_group'];
if($it618_group['pagecount']!=''){
	$IsGroup=1;
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php')){
	$IsChat=1;
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/lang.func.php';
}

$it618_wxmini = $_G['cache']['plugin']['it618_wxmini'];
if($it618_wxmini['pagecount']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_wxmini/kindeditor/plugins/autoheight/it618.png')){
	$IsWxMini=1;
}

$langpluginname='it618_union';
if($_SERVER['HTTP_HOST']=='localhost'||strpos($_SERVER['HTTP_HOST'],'localhost'))$language = 'language.php';else$language = 'language.'.currentlang().'.php';
if(!file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language))$language = 'language.php';
require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language;$language_edit = 'language.'.currentlang().'_edit.php';
if(file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit)){
$lang_version=$it618_union_lang['version'];	$lang_it618=$it618_union_lang['it618'];	require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit;$it618_union_lang['version']=$lang_version;$it618_union_lang['it618']=$lang_it618;
}
?>