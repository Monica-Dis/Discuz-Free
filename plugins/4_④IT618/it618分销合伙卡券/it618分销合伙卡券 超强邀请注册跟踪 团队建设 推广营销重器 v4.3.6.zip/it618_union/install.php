<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_union_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_userset`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_userset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(50) NOT NULL,
  `it618_qq` varchar(50) NOT NULL,
  `it618_wx` varchar(50) NOT NULL,
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_tel_isopen` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ismsgok_reg` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ismsgok_jl` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_reguser`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_reguser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuiuid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_groupid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_groups` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_yqcount` int(10) unsigned NOT NULL,
  `it618_money1` float(9,2) NOT NULL DEFAULT '0',
  `it618_money2` float(9,2) NOT NULL DEFAULT '0',
  `it618_isjl11` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isjl21` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isjl31` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isjl12` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isjl22` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isjl32` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit11` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit21` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit31` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit41` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit51` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit61` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit71` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit81` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit12` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit22` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit32` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit42` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit52` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit62` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit72` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit82` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_jl`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_jl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuiuidfind` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuiuid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jltype` varchar(50) NOT NULL,
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_saletc`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_saletc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuiuidfind` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` varchar(50) NOT NULL,
  `it618_salecredit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salemoney` float(9,2) NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saleid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saleuid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tcmoney` float(9,2) NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_quan`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_quan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(1000) NOT NULL,
  `it618_pic` varchar(300) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mjmoney1` float(9,2) NOT NULL DEFAULT '0',
  `it618_mjmoney2` float(9,2) NOT NULL DEFAULT '0',
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ismoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtime1` varchar(20) NOT NULL,
  `it618_xgtime2` varchar(20) NOT NULL,
  `it618_oktime1` varchar(20) NOT NULL,
  `it618_oktime2` varchar(20) NOT NULL,
  `it618_pids` varchar(300) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_quansale`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_quansale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(1000) NOT NULL,
  `it618_pic` varchar(300) NOT NULL,
  `it618_qid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_mjmoney1` float(9,2) NOT NULL DEFAULT '0',
  `it618_mjmoney2` float(9,2) NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ismoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pids` varchar(300) NOT NULL,
  `it618_oktime1` varchar(20) NOT NULL,
  `it618_oktime2` varchar(20) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_gwcid` int(10) unsigned NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_usetime` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_tui`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_tui` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(1000) NOT NULL,
  `it618_pic` varchar(300) NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_etime` varchar(20) NOT NULL,
  `it618_uids` varchar(1000) NOT NULL,
  `it618_pids` varchar(8000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_joincount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_tuijoin`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_tuijoin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_code` varchar(50) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_tuitc`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_tuitc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tc_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_saleuid` int(10) unsigned NOT NULL,
  `it618_saletime` int(10) unsigned NOT NULL,
  `it618_tctime` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_nav`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_sharecode_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_sharecode_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_plugin` varchar(50) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_isyqreg` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isshop` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isproduct` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istui` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_sharecode_font`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_sharecode_font` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(50) NOT NULL,
  `it618_font` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_sharecode`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_sharecode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cid` varchar(50) NOT NULL,
  `it618_class` varchar(50) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_content` varchar(1000) NOT NULL,
  `it618_length` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_left` int(10) unsigned NOT NULL,
  `it618_top` int(10) unsigned NOT NULL,
  `it618_width` int(10) unsigned NOT NULL,
  `it618_height` int(10) unsigned NOT NULL,
  `it618_radius` int(10) unsigned NOT NULL,
  `it618_opacity` int(10) unsigned NOT NULL DEFAULT '100',
  `it618_fontsize` int(10) unsigned NOT NULL,
  `it618_fontid` int(10) unsigned NOT NULL,
  `it618_fontcolor` varchar(50) NOT NULL,
  `it618_about` varchar(255) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_union_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_union_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

INSERT INTO `pre_it618_union_wapstyle` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#fd9e2d', '#e8922b', 0),
(2, '#fc4646', '#f43131', 1),
(3, '#5ebe00', '#56aa04', 0),
(4, '#23b8ff', '#12a8ff', 0),
(5, '#fb23cb', '#ea11ba', 0),
(6, '#2dbeae', '#00a795', 0),
(8, '#fe5400', '#d04906', 0),
(7, '#999a9b', '#8d8f90', 0);

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb24ueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb25fU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb25fU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb25fVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2Rpc2N1el9wbHVnaW5faXQ2MThfdW5pb25fVENfQklHNS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL3VwZ3JhZGUucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3VuaW9uL2luc3RhbGwucGhw'));
?>