<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function Union_SaleTC($saletype,$salemoney,$saleid,$saleuid){
	global $_G,$it618_union_lang;
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';
	
	if($it618_union_reguser=C::t('#it618_union#it618_union_reguser')->fetch_by_uid($saleuid)){

		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
		}
		
		if($saletype=='it618_credits_cz'||$saletype=='it618_credits_buygroup'){
			$tcbl1=$union_credits_tcbl1;$tcbl2=$union_credits_tcbl2;
		}
		
		if($saletype=='it618_video'){
			$tcbl1=$union_video_tcbl1;$tcbl2=$union_video_tcbl2;
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_video_sale')." where id=".$saleid);
		}
		
		if($saletype=='it618_exam'){
			$tcbl1=$union_exam_tcbl1;$tcbl2=$union_exam_tcbl2;
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_exam_sale')." where id=".$saleid);
		}
		
		if($saletype=='it618_group'){
			$tcbl1=$union_group_tcbl1;$tcbl2=$union_group_tcbl2;
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_group_sale')." where id=".$saleid);
		}
		
		if($saletype=='it618_brand'){
			$tcbl1=$union_brand_tcbl1;$tcbl2=$union_brand_tcbl2;
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_brand_sale')." where id=".$saleid);
		}
		
		if($saletype=='it618_tuan'){
			$tcbl1=$union_tuan_tcbl1;$tcbl2=$union_tuan_tcbl2;
			$it618_pid=DB::result_first("select it618_pid from ".DB::table('it618_tuan_sale')." where id=".$saleid);
		}
		
		if($saletype=='it618_waimai'){
			$tcbl1=$union_waimai_tcbl1;$tcbl2=$union_waimai_tcbl2;
		}
		
		if($saletype=='it618_sale_fl'){
			$tcbl1=$union_sale_tcbl1;$tcbl2=$union_sale_tcbl2;
		}
		
		if($saletype=='it618_paotui'){
			$tcbl1=$union_paotui_tcbl1;$tcbl2=$union_paotui_tcbl2;
		}
		
		if($saletype=='it618_witkey_post'){
			$tcbl1=$union_witkey_post;$tcbl2=$union_witkey_post1;
		}
		
		if($saletype=='it618_witkey_get'){
			$tcbl1=$union_witkey_get;$tcbl2=$union_witkey_get1;
		}
		
		$tmptime=$_G['timestamp'];

		$tcmoney=$salemoney*$tcbl1/100;
		
		$id = C::t('#it618_union#it618_union_saletc')->insert(array(
			'it618_type' => 1,
			'it618_uid' => $it618_union_reguser['it618_tuiuid'],
			'it618_tuiuidfind' => 0,
			'it618_saletype' => $saletype,
			'it618_salemoney' => $salemoney,
			'it618_saleid' => $saleid,
			'it618_pid' => $it618_pid,
			'it618_saleuid' => $saleuid,
			'it618_tcmoney' => $tcmoney,
			'it618_time' => $tmptime
		), true);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		
		$it618_bz=$it618_union_lang['s701'];
		$it618_bz=str_replace("{money}",$tcmoney,$it618_bz);
		$it618_bz=str_replace("{saletcid}",$id,$it618_bz);
		
		savemoney(array(
			'it618_uid' => $it618_union_reguser['it618_tuiuid'],
			'it618_type' => 'zy',
			'it618_money1' => $tcmoney,
			'it618_bz' => $it618_bz,
			'it618_zytype' => 'it618_union_saletc1',
			'it618_zyid' => $id,
			'it618_time' => $tmptime
		));
		
		if($it618_union_reguser1 = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_uid=".$it618_union_reguser['it618_tuiuid'])) {

			$tcmoney=$salemoney*$tcbl2/100;
			
			$id = C::t('#it618_union#it618_union_saletc')->insert(array(
				'it618_type' => 2,
				'it618_uid' => $it618_union_reguser1['it618_tuiuid'],
				'it618_tuiuidfind' => $it618_union_reguser['it618_tuiuid'],
				'it618_saletype' => $saletype,
				'it618_salemoney' => $salemoney,
				'it618_saleid' => $saleid,
				'it618_pid' => $it618_pid,
				'it618_saleuid' => $saleuid,
				'it618_tcmoney' => $tcmoney,
				'it618_time' => $_G['timestamp']
			), true);
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
			
			$it618_bz=$it618_union_lang['s702'];
			$it618_bz=str_replace("{money}",$tcmoney,$it618_bz);
			$it618_bz=str_replace("{saletcid}",$id,$it618_bz);
			
			savemoney(array(
				'it618_uid' => $it618_union_reguser1['it618_tuiuid'],
				'it618_type' => 'zy',
				'it618_money1' => $tcmoney,
				'it618_bz' => $it618_bz,
				'it618_zytype' => 'it618_union_saletc2',
				'it618_zyid' => $id,
				'it618_time' => $tmptime
			));
		}
	}
}

function Union_SaleCreditsTC($saletype,$salecredit,$saleid,$saleuid){
	global $_G;
	
	if($it618_union_reguser=C::t('#it618_union#it618_union_reguser')->fetch_by_uid($saleuid)){

		$id = C::t('#it618_union#it618_union_saletc')->insert(array(
			'it618_type' => 1,
			'it618_uid' => $it618_union_reguser['it618_tuiuid'],
			'it618_tuiuidfind' => $it618_union_reguser['it618_uid'],
			'it618_saletype' => $saletype,
			'it618_saleid' => $saleid,
			'it618_saleuid' => $saleuid,
			'it618_time' => $_G['timestamp']
		), true);
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
		}
		
		if($saletype=='it618_wike_post'){
			$tmpbl=$union_wike_post;$tmpbl1=$union_wike_post1;
		}
		
		if($saletype=='it618_wike_get'){
			$tmpbl=$union_wike_get;$tmpbl1=$union_wike_get1;
		}
		
		if($saletype=='it618_scoremall'){
			$tmpbl=$union_scoremall;$tmpbl1=$union_scoremall1;
		}
		
		for($i=1;$i<=8;$i++){

			if($_G['setting']['extcredits'][$i]['title']!=''&&$salecredit[$i]>0){
				$tmpjfcount=intval($salecredit[$i]*$tmpbl/100);
				if($tmpjfcount==0)$tmpjfcount=1;
				
				C::t('#it618_union#it618_union_saletc')->update($id,array(
					'it618_salecredit'.$i => $salecredit[$i],
					'it618_credit'.$i => $tmpjfcount
				));
				
				C::t('common_member_count')->increase($it618_union_reguser['it618_tuiuid'], array(
					'extcredits'.$i => $tmpjfcount)
				);
			}
		}
		
		if($it618_union_reguser1 = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_uid=".$it618_union_reguser['it618_tuiuid'])) {
			
			$id = C::t('#it618_union#it618_union_saletc')->insert(array(
				'it618_type' => 2,
				'it618_uid' => $it618_union_reguser1['it618_tuiuid'],
				'it618_tuiuidfind' => $it618_union_reguser['it618_tuiuid'],
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_saleuid' => $saleuid,
				'it618_time' => $_G['timestamp']
			), true);
			
			for($i=1;$i<=8;$i++){
				if($_G['setting']['extcredits'][$i]['title']!=''&&$salecredit[$i]>0){
					$tmpjfcount=intval($salecredit[$i]*$tmpbl1/100);
					if($tmpjfcount==0)$tmpjfcount=1;
					
					C::t('#it618_union#it618_union_saletc')->update($id,array(
						'it618_salecredit'.$i => $salecredit[$i],
						'it618_credit'.$i => $tmpjfcount
					));
					
					C::t('common_member_count')->increase($it618_union_reguser1['it618_tuiuid'], array(
						'extcredits'.$i => $tmpjfcount)
					);
				}
			}
		}
	}
}

function Union_IsTuiJoin($shoptype,$pid,$tuijcode){
	global $_G;
	
	if($it618_union_tuijoin=C::t('#it618_union#it618_union_tuijoin')->fetch_by_code($tuijcode)){
		if($it618_union_tuijoin['it618_shoptype']==$shoptype){
			$it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_id($it618_union_tuijoin['it618_tid']);
			$pidsarr=explode(",",$it618_union_tui['it618_pids']);
			if(in_array($pid, $pidsarr)){
				$it618_etime=strtotime($it618_union_tui['it618_etime'].':00');
				if($_G['timestamp']<$it618_etime){
					return $it618_union_tuijoin['id'];
				}
			}
		}
	}
	
	return 0;
}

function Union_TuiTC_Add($tuijid,$saleid){
	global $_G;
	
	if($it618_union_tuijoin=C::t('#it618_union#it618_union_tuijoin')->fetch_by_id($tuijid)){
		
		$it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_id($it618_union_tuijoin['it618_tid']);
		$it618_tcbl=$it618_union_tui['it618_tcbl'];
		$it618_shoptype=$it618_union_tui['it618_shoptype'];
		$it618_shopid=$it618_union_tui['it618_shopid'];

		$id = C::t('#it618_union#it618_union_tuitc')->insert(array(
			'it618_uid' => $it618_union_tuijoin['it618_uid'],
			'it618_shoptype' => $it618_shoptype,
			'it618_shopid' => $it618_shopid,
			'it618_jid' => $tuijid,
			'it618_tcbl' => $it618_tcbl,
			'it618_saleid' => $saleid,
			'it618_saleuid' => $saleuid,
			'it618_state' => 0,
			'it618_saletime' => $_G['timestamp']
		), true);
		
		if($it618_shoptype=='video'){
			$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($saleid);
			
			$salemoney=$it618_video_sale['it618_sfmoney'];
			
			if($it618_video_sale['it618_score']>0){
				$salejfid=$it618_video_sale['it618_jfid'];
				$salejfcount=$it618_video_sale['it618_sfscore'];
			}
		}
		
		if($it618_shoptype=='exam'){
			$it618_exam_sale=C::t('#it618_exam#it618_exam_sale')->fetch_by_id($saleid);
			
			$salemoney=$it618_exam_sale['it618_sfmoney'];
			
			if($it618_exam_sale['it618_score']>0){
				$salejfid=$it618_exam_sale['it618_jfid'];
				$salejfcount=$it618_exam_sale['it618_sfscore'];
			}
		}
		
		if($it618_shoptype=='group'){
			$it618_group_sale=C::t('#it618_group#it618_group_sale')->fetch_by_id($saleid);
			
			$salemoney=$it618_group_sale['it618_sfmoney'];
			
			if($it618_group_sale['it618_score']>0){
				$salejfid=$it618_group_sale['it618_jfid'];
				$salejfcount=$it618_group_sale['it618_sfscore'];
			}
		}
		
		if($it618_shoptype=='brand'){
			$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($saleid);
			
			if($it618_brand_sale['it618_type']==1){
				$it618_brand = $_G['cache']['plugin']['it618_brand'];
				$salejfid=$it618_brand['brand_credit'];
				$salejfcount=$it618_brand_sale['it618_sfscore']-$it618_brand_sale['it618_yunfei'];
			}else{
				$salemoney=$it618_brand_sale['it618_sfmoney']-$it618_brand_sale['it618_yunfei'];
			}
		}
		
		if($it618_shoptype=='tuan'){
			$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($saleid);
			
			$salemoney=$it618_tuan_sale['it618_sfmoney']-$it618_tuan_sale['it618_yunfei'];
			
			if($it618_tuan_sale['it618_score']>0){
				$salejfid=$it618_tuan_sale['it618_jfid'];
				$salejfcount=$it618_tuan_sale['it618_sfscore'];
			}
		}
		
		if($salemoney>0){
			$tcmoney=round((($it618_tcbl*$salemoney)/100), 2);
			
			C::t('#it618_union#it618_union_tuitc')->update($id,array(
				'it618_tc_money' => $tcmoney
			));
		}
		
		if($salejfcount>0){
			$tcjfcount=intval($salejfcount*$it618_tcbl/100);
			
			C::t('#it618_union#it618_union_tuitc')->update($id,array(
				'it618_tc_credit'.$salejfid => $tcjfcount
			));
		}
		
	}
}

function Union_TuiTC_OK($shoptype,$saleid,$shopuid){
	global $_G,$it618_union_lang;
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';
	
	if($it618_union_tuitc=C::t('#it618_union#it618_union_tuitc')->fetch_by_shoptype_saleid($shoptype,$saleid)){
		
		$tmptime=$_G['timestamp'];
		C::t('#it618_union#it618_union_tuitc')->update($it618_union_tuitc['id'],array(
			'it618_state' => 2,
			'it618_tctime' => $tmptime
		));
		
		$it618_shoptype=$it618_union_tuitc['it618_shoptype'];
		$it618_shopid=$it618_union_tuitc['it618_shopid'];
		$it618_tcbl=$it618_union_tuitc['it618_tcbl'];
		$tcmoney=$it618_union_tuitc['it618_tc_money'];
		
		for($i=1;$i<=8;$i++){
			if($it618_union_tuitc['it618_tc_credit'.$i]>0){
				$salejfid=$i;
				$tcjfcount=$it618_union_tuitc['it618_tc_credit'.$i];
				break;
			}
		}
		
		if($it618_shoptype=='video'){
			DB::query("update ".DB::table('it618_video_sale')." set it618_tuitcbl=".$it618_tcbl.",it618_tuitc=".$tcmoney." where id=".$saleid);
		}
		
		if($it618_shoptype=='exam'){
			DB::query("update ".DB::table('it618_exam_sale')." set it618_tuitcbl=".$it618_tcbl.",it618_tuitc=".$tcmoney." where id=".$saleid);
		}
		
		if($it618_shoptype=='group'){
			DB::query("update ".DB::table('it618_group_sale')." set it618_tuitcbl=".$it618_tcbl.",it618_tuitc=".$tcmoney." where id=".$saleid);
		}
		
		if($it618_shoptype=='brand'){
			DB::query("update ".DB::table('it618_brand_sale')." set it618_tuitcbl=".$it618_tcbl.",it618_tuitc=".$tcmoney." where id=".$saleid);
		}
		
		if($it618_shoptype=='tuan'){
			DB::query("update ".DB::table('it618_tuan_sale')." set it618_tuitcbl=".$it618_tcbl.",it618_tuitc=".$tcmoney." where id=".$saleid);
		}

		if($tcmoney>0){
			
			if($it618_shoptype=='brand'){
				$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($saleid);
				
				if($it618_brand_sale['it618_txtype']==2){
					$txjfcount=intval($tcmoney*$it618_brand['brand_txbl']/100);
					
					DB::query("UPDATE ".DB::table('it618_brand_sale')." SET it618_txjfcount=it618_txjfcount-".$txjfcount." WHERE id=".$saleid);
			
					C::t('common_member_count')->increase($shopuid, array(
						'extcredits'.$it618_brand_sale['it618_txjfid'] => (0-$txjfcount))
					);
				}
			}
			
			if($it618_shoptype=='video'){
				DB::query("update ".DB::table('it618_video_shop')." set it618_money=it618_money-".$tcmoney." where id=".$it618_shopid);
			}
			
			if($it618_shoptype=='exam'){
				DB::query("update ".DB::table('it618_exam_shop')." set it618_money=it618_money-".$tcmoney." where id=".$it618_shopid);
			}
			
			if($it618_shoptype=='tuan'){
				DB::query("update ".DB::table('it618_tuan_shop')." set it618_money=it618_money-".$tcmoney." where id=".$it618_shopid);
			}
			
			$it618_bz=$it618_union_lang['s604'];
			$it618_bz=str_replace("{money}",$tcmoney,$it618_bz);
			$it618_bz=str_replace("{tuitcid}",$it618_union_tuitc['id'],$it618_bz);
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
			savemoney(array(
				'it618_uid' => $it618_union_tuitc['it618_uid'],
				'it618_type' => 'zy',
				'it618_money1' => $tcmoney,
				'it618_bz' => $it618_bz,
				'it618_zytype' => 'it618_union_tuitc',
				'it618_zyid' => $it618_union_tuitc['id'],
				'it618_time' => $tmptime
			));
		}
		
		if($tcjfcount>0){
			
			C::t('common_member_count')->increase($it618_union_tuitc['it618_uid'], array(
				'extcredits'.$salejfid => $tcjfcount)
			);
			
			C::t('common_member_count')->increase($shopuid, array(
				'extcredits'.$salejfid => (0-$tcjfcount))
			);
		}
		
	}
}
?>