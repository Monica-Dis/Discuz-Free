<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pagemod='uc';
$pagetype=$_GET['pagetype'];

if($_G['uid']<=0&&$pagetype!='yqreg'){
	dheader("location:member.php?mod=logging&action=login");
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/union_default.func.php';

if(union_is_mobile()){
	$tmpurl=it618_union_getrewrite('union_wap',$pagetype,'plugin.php?id=it618_union:wap&pagetype='.$pagetype);
	dheader("location:$tmpurl");
}

if($pagetype=='myuser'){
	$jltypearr=explode("it618_split",it618_union_getjltype());
	
	$jftmparr1=C::t('#it618_union#it618_union_jl')->fetch_sumjf_by_tuiuid($_G['uid'],1);
	$jftmparr2=C::t('#it618_union#it618_union_jl')->fetch_sumjf_by_tuiuid($_G['uid'],2);
	
	for($i=1;$i<=8;$i++){
		if($_G['setting']['extcredits'][$i]['title']!=''&&$jftmparr1['jf'.$i]>0){
			$jf1str.=$jftmparr1['jf'.$i].$_G['setting']['extcredits'][$i]['title'].' ';
		}
		if($_G['setting']['extcredits'][$i]['title']!=''&&$jftmparr2['jf'.$i]>0){
			$jf2str.=$jftmparr2['jf'.$i].$_G['setting']['extcredits'][$i]['title'].' ';
		}
	}
	
	if($IsCredits==1){
		$money1=DB::result_first("SELECT sum(it618_money1) FROM ".DB::table('it618_credits_money')." where it618_zytype='it618_union_yqmoney1' and it618_uid=".$_G['uid']);
		$money2=DB::result_first("SELECT sum(it618_money1) FROM ".DB::table('it618_credits_money')." where it618_zytype='it618_union_yqmoney2' and it618_uid=".$_G['uid']);
		if($money1=='')$money1=0;
		if($money2=='')$money2=0;
	}
	
	if($money1>0||$money2>0){
		if($jf1str!=''||$money1>0)$jf1str=$it618_union_lang['s1026'].$money1.$it618_union_lang['s195'].' '.$jf1str;
		if($jf2str!=''||$money2>0)$jf2str=$it618_union_lang['s1027'].$money2.$it618_union_lang['s195'].' '.$jf2str;
	}else{
		if($jf1str!='')$jf1str=$it618_union_lang['s1026'].$jf1str;
		if($jf2str!='')$jf2str=$it618_union_lang['s1027'].$jf2str;
	}
}

$laydate='<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>';

$_G['mobiletpl'][2]='/';
include template('it618_union:'.$union_templatename.'/union_default');
?>