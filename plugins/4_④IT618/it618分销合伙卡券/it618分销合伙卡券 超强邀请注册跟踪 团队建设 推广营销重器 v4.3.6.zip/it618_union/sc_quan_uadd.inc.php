<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_header.func.php';

if($ShopType=='video'){
	$tcbl=$it618_video_shop['it618_tcbl'];
	$shopuid=$it618_video_shop['it618_uid'];
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods')." where it618_state=1 and it618_shopid=$ShopId");
}
if($ShopType=='exam'){
	$tcbl=$it618_exam_shop['it618_tcbl'];
	$shopuid=$it618_exam_shop['it618_uid'];
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods')." where it618_state=1 and it618_shopid=$ShopId");
}
if($ShopType=='group'){
	$tcbl=0;
	$shopuid=$_G['uid'];
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_goods')." where it618_state=1");
}
if($ShopType=='brand'){
	$tcbl=$it618_brand_brand['it618_tcbl'];
	$shopuid=$it618_brand_brand['it618_uid'];
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods')." where it618_ison=1 and it618_shopid=$ShopId");
}
if($ShopType=='tuan'){
	$tcbl=$it618_tuan_shop['it618_tcbl'];
	$shopuid=$it618_tuan_shop['it618_uid'];
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods')." where it618_state=1 and it618_shopid=$ShopId");
}

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($shopuid);
}else{
	echo $it618_union_lang['s687'];exit;
}

if(submitcheck('it618submit')){	

	if($_GET['pidstype']==1){
		$pids='';
	}else{
		$pids_array = !empty($_GET['it618_pids']) ? $_GET['it618_pids'] : array();
		foreach($pids_array as $key => $value) {
			$pids.=intval($value).',';
		}
		if($pids!='')$pids=str_replace(",,","",$pids.',');
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_credits_delmoneywork();
		}
	}
	C::t('#it618_credits#it618_credits_moneywork')->insert(array(
		'it618_iswork' => 1
	), true);
	
	$ucount=0;
	$tmparr=explode(",",$_GET['it618_uids']);
	for($i=0;$i<count($tmparr);$i++){
		if($tmparr[$i]>0){
			$username=it618_union_getusername($tmparr[$i]);
			if($username!=''){
				$uidarr[]=$tmparr[$i];
				$ucount=$ucount+1;
			}
		}
	}
	
	$count=intval($_GET['it618_count']);
	if($_GET['it618_type']==1){
		$money=floatval($_GET['it618_mjmoney2']);
	}else{
		$money=floatval($_GET['it618_money']);
	}
	$tcmoney=$ucount*$count*$money*$tcbl/100;
	
	$it618_money2=$tcmoney;
	
	$it618_money=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($shopuid);
	DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_money." where it618_uid=".$shopuid);
	if($it618_money2>$it618_money){
		it618_credits_delmoneywork();
		it618_cpmsg(it618_union_getlang('s691'), "plugin.php?id=it618_union:sc_quan_uadd$adminsid", 'error');
	}
	
	$it618_bz=it618_union_getlang('s692');
	$it618_bz=str_replace("{money}",$ucount*$count*$money,$it618_bz);
	$it618_bz=str_replace("{ucount}",$ucount,$it618_bz);
	$it618_bz=str_replace("{count}",$count,$it618_bz);
	
	$id=savemoney(array(
		'it618_uid' => $shopuid,
		'it618_type' => 'pay',
		'it618_money2' => $it618_money2,
		'it618_bz' => $it618_bz,
		'it618_zftype' => 'quantc',
		'it618_zfid' => 0
	));
	
	for($i=0;$i<$ucount;$i++){
		for($n=1;$n<=$count;$n++){
			$id = C::t('#it618_union#it618_union_quansale')->insert(array(
				'it618_shoptype' => $ShopType,
				'it618_shopid' => $ShopId,
				'it618_name' => dhtmlspecialchars($_GET['it618_name']),
				'it618_type' => $_GET['it618_type'],
				'it618_mjmoney1' => $_GET['it618_mjmoney1'],
				'it618_mjmoney2' => $_GET['it618_mjmoney2'],
				'it618_money' => $_GET['it618_money'],
				'it618_uid' => $uidarr[$i],
				'it618_qid' => 0,
				'it618_count' => 1,
				'it618_ismoney' => 0,
				'it618_pic' => dhtmlspecialchars($_GET['it618_pic']),
				'it618_pids' => $pids,
				'it618_oktime1' => dhtmlspecialchars($_GET['it618_oktime1']),
				'it618_oktime2' => dhtmlspecialchars($_GET['it618_oktime2']),
				'it618_time' => $_G['timestamp']
			), true);
		}
	}

	it618_credits_delmoneywork();
	it618_cpmsg(it618_union_getlang('s693'), "plugin.php?id=it618_union:sc_quan_uadd$adminsid", 'succeed');
}

while($tmpgoods = DB::fetch($query)) {
	if($ShopType=='group'){
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($tmpgoods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$tmpgoods['it618_groupid']);
		$it618_unit=it618_union_getvipgoodsunit($tmpgoods);
		$tmpgoods['it618_name']=$grouptitle.' '.$it618_unit;
	}
	
	$it618_pids_str.='<li><input type="checkbox" id="it618_pids'.$tmpgoods['id'].'" name="it618_pids[]" value="'.$tmpgoods['id'].'" style="vertical-align:middle"><label for="it618_pids'.$tmpgoods['id'].'">['.$tmpgoods['id'].'] '.$tmpgoods['it618_name'].'</label></li>';
}

it618_showformheader("plugin.php?id=it618_union:sc_quan_uadd$adminsid");
showtableheaders(it618_union_getlang('s670'),'it618_union_quan');

echo '
<link rel="stylesheet" href="source/plugin/it618_union/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_union/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_union/js/jquery.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/plugins/code/prettify.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>
<script>
	KindEditor.ready(function(K) {
		
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_union/kindeditor/php/upload_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'&imgwidth=260'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_union/kindeditor/php/file_manager_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'\',
			allowFileManager : true
		});
		
		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#it618_pic\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
		
	});
	
	function gettype(index){
		document.getElementById("spantype1").style.display="none";
		document.getElementById("spantype2").style.display="none";
		document.getElementById("spantype"+index).style.display="";
	}
	
	function checkvalue(){
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_union_getlang('s210').'");
			document.getElementById("it618_name").focus();
			return false;
		}
		
		if(document.getElementById("it618_pic").value==""){
			alert("'.it618_union_getlang('s211').'");
			return false;
		}
		
		if(document.getElementById("it618_type").value==1){
			if(isNaN(document.getElementById("it618_mjmoney1").value)||document.getElementById("it618_mjmoney1").value==""){
				alert("'.it618_union_getlang('s213').'");
				document.getElementById("it618_mjmoney1").focus();
				return false;
			}
			if(isNaN(document.getElementById("it618_mjmoney2").value)||document.getElementById("it618_mjmoney2").value==""){
				alert("'.it618_union_getlang('s213').'");
				document.getElementById("it618_mjmoney2").focus();
				return false;
			}
			
			if(parseFloat(document.getElementById("it618_mjmoney2").value)<=0||parseFloat(document.getElementById("it618_mjmoney2").value)>parseFloat(document.getElementById("it618_mjmoney1").value)){
				alert("'.it618_union_getlang('s213').'");
				document.getElementById("it618_mjmoney2").focus();
				return false;
			}
		}else{
			if(isNaN(document.getElementById("it618_money").value)||document.getElementById("it618_money").value==""){
				alert("'.it618_union_getlang('s212').'");
				document.getElementById("it618_money").focus();
				return false;
			}
			
			if(parseFloat(document.getElementById("it618_money").value)<=0){
				alert("'.it618_union_getlang('s212').'");
				document.getElementById("it618_money").focus();
				return false;
			}
		}
		
		if(document.getElementById("it618_oktime1").value==""||document.getElementById("it618_oktime2").value==""){
			alert("'.it618_union_getlang('s214').'");
			return false;
		}
		
		if(document.getElementById("pidstype").value==2){
			var checkbox = document.getElementsByName("it618_pids[]");
			var checked_counts = 0;
			for(var i=0;i<checkbox.length;i++){
				
				if(checkbox[i].checked){
					checked_counts++;
				}
			}
			
			if(checked_counts==0){
				alert("'.it618_union_getlang('s528').'");
				return false;
			}
		}
		
		if(document.getElementById("it618_uids").value==""){
			alert("'.it618_union_getlang('s688').'");
			document.getElementById("it618_uids").focus();
			return false;
		}
		
		if(parseInt(document.getElementById("it618_count").value)<=0){
			alert("'.it618_union_getlang('s689').'");
			document.getElementById("it618_count").focus();
			return false;
		}
		
		var money=parseFloat(document.getElementById("money").innerHTML);
		var tcmoney=parseFloat(document.getElementById("tcmoney").innerHTML);
		
		if(tcmoney>money){
			alert("'.it618_union_getlang('s691').'");
			return false;
		}
		
		if(!confirm("'.$it618_union_lang['s685'].'")){
			return false;
		}
	}
	
	function getcheckuid(){
		var uids=document.getElementById("it618_uids").value;
		if(uids==""){
			alert("'.it618_union_getlang('s688').'");
			document.getElementById("it618_uids").focus();
			return false;
		}
		uids=uids.replace(/,/g,"@");
		
		IT618_UNION.get("'.$_G['siteurl'].'plugin.php?id=it618_union:ajax&uids="+uids+"&formhash='.FORMHASH.'", {ac:"checkuid"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		document.getElementById("it618_uids").value=tmparr[0];
		IT618_UNION("#username").html("<br>"+tmparr[1]);
		}, "html");		
	}
	
	function gettcmoney(){
		var uids=document.getElementById("it618_uids").value;
		var count=document.getElementById("it618_count").value;
		if(document.getElementById("it618_type").value==1){
			var money=parseFloat(document.getElementById("it618_mjmoney2").value);
		}else{
			var money=parseFloat(document.getElementById("it618_money").value);
		}
		var tcbl=parseFloat(document.getElementById("it618_tcbl").innerHTML);
		
		var ucount=uids.split(",").length;
		var tcmoney=ucount*count*money*tcbl/100;
		
		IT618_UNION("#tcmoney").html(tcmoney.toFixed(2));
	}
	
	function getpids(objvalue){
		if(objvalue==1){
			document.getElementById("spangoods").style.display="none";
		}else{
			document.getElementById("spangoods").style.display="";
		}
	}
	
	function check_all(obj)
	{
		var checkbox = document.getElementsByName("it618_pids[]");
		var checked_counts = 0;
		for(var i=0;i<checkbox.length;i++){
			
			checkbox[i].checked=obj.checked;
		}
	}
</script>

<style>
.goodsul{float:left;background-color:#f1f1f1;padding:10px}
.goodsul li{float:left;width:530px}
</style>

<tr><td width=80>'.it618_union_getlang('s181').'</td><td><input type="text" class="txt" style="width:400px;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_union_lang['s684'].'"> <font color=#888>'.$it618_union_lang['s673'].'</font></td></tr>
<tr><td>'.it618_union_getlang('s190').'</td><td><img id="img1" width="50" height="50" src="source/plugin/it618_union/images/quan.png" align="absmiddle"/> <input type="text" id="it618_pic" name="it618_pic" value="source/plugin/it618_union/images/quan.png" readonly="readonly"/> <input type="button" id="image1" value="'.it618_union_getlang('s191').'" /></td></tr>
<tr><td>'.it618_union_getlang('s177').'</td><td><select id="it618_type" name="it618_type" onchange="gettype(this.value)"><option value="1">'.it618_union_getlang('s178').'</option><option value="2" selected="selected">'.it618_union_getlang('s179').'</option></select> 
<span id="spantype1" style="display:none">'.$it618_union_lang['s193'].' <input type="text" class="txt" style="width:80px;margin-right:3px;" id="it618_mjmoney1" name="it618_mjmoney1">'.$it618_union_lang['s194'].' <input type="text" class="txt" style="width:80px;margin-right:3px;color:red" id="it618_mjmoney2" name="it618_mjmoney2" onchange="gettcmoney()">'.$it618_union_lang['s195'].'</span>
<span id="spantype2">'.$it618_union_lang['s196'].' <input type="text" class="txt" style="width:80px;margin-right:3px;color:red" id="it618_money" name="it618_money" onchange="gettcmoney()">'.$it618_union_lang['s195'].'</span></td></tr>
<tr><td>'.it618_union_getlang('s186').'</td><td><input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_oktime1" name="it618_oktime1" readonly="readonly" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')">- <input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_oktime2" name="it618_oktime2" readonly="readonly" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"> <font color=blue>'.$it618_union_lang['s672'].'</font></td></tr>
<tr><td>'.it618_union_getlang('s184').'</td><td style="line-height:26px">
<div style="float:left;width:100%"><select id="pidstype" name="pidstype" onchange="getpids(this.value)" style="margin-bottom:3px"><option value="1">'.$it618_union_lang['s635'].'</option><option value="2">'.$it618_union_lang['s636'].'</option></select></div>
<span id="spangoods" style="display:none">
<ul class="goodsul">
'.$it618_pids_str.'
<li><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="check_all(this)" /><label for="chkallDx4b">'.it618_union_getlang('s238').'</label></li>
</ul>
</td></tr>
<tr><td>'.it618_union_getlang('s674').'</td><td><input type="text" class="txt" style="width:800px;margin-right:0;margin-bottom:3px;color:red" id="it618_uids" name="it618_uids" onchange="gettcmoney()"> <input type="button" value="'.$it618_union_lang['s681'].'" class="btn" onclick="getcheckuid()"><span id="username" style="color:green"></span><br><font color=#888>'.$it618_union_lang['s675'].'</font></td></tr>
<tr><td>'.it618_union_getlang('s676').'</td><td><select id="it618_count" name="it618_count" onchange="gettcmoney()"><option value=1>1</option><option value=2>2</option><option value=3>3</option></select> <font color=#888>'.$it618_union_lang['s677'].'</font></td></tr>
<tr><td colspan=2><font color=#888>'.it618_union_getlang('s679').'<span id="it618_tcbl" style="color:red">'.$tcbl.'%</span>'.it618_union_getlang('s680').'</font></td></tr>
<tr><td colspan=2><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_union_getlang('s682').'"/> '.$it618_union_lang['s690'].'<span id="tcmoney" style="font-size:15px;color:blue">0</span> '.$it618_union_lang['s195'].' '.$it618_union_lang['s686'].'<span id="money" style="font-size:15px;color:red">'.$it618_money.'</span> '.$it618_union_lang['s195'].'</div></td></tr>
<tr><td colspan=2 style="line-height:23px"><font color=green>'.$it618_union_lang['s671'].'</font></td></tr>
<style>.laydate-btns-time{float:left}</style>
<script>
  laydate.render({
	elem: "#it618_oktime1"
	,type: "datetime"
	,format: "yyyy-MM-dd HH:mm"
  });
  laydate.render({
	elem: "#it618_oktime2"
	,type: "datetime"
	,format: "yyyy-MM-dd HH:mm"
  });
</script>
';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_footer.func.php';
?>