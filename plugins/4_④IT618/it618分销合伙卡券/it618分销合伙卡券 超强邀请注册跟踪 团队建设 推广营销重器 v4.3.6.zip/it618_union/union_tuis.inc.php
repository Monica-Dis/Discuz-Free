<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pagemod='tuis';
$pagetype='tuis';

require_once DISCUZ_ROOT.'./source/plugin/it618_union/union_default.func.php';

if(union_is_mobile()){
	$tmpurl=it618_union_getrewrite('union_wap',$pagetype,'plugin.php?id=it618_union:wap&pagetype='.$pagetype);
	dheader("location:$tmpurl");
}

$tuisstrarr=explode("it618_split",it618_union_gettuis());

$_G['mobiletpl'][2]='/';
include template('it618_union:'.$union_templatename.'/union_default');
?>