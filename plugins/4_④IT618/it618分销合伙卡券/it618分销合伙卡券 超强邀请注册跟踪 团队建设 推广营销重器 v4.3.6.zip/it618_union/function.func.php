<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsCredits,$it618_union;

$it618_union = $_G['cache']['plugin']['it618_union'];
$metatitle = $it618_union['seotitle'];
$metakeywords = $it618_union['seokeywords'];
$metadescription = $it618_union['seodescription'];

require_once DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';

function it618_union_yqjl($jltype,$jl_credit1,$jl_credit2,$it618_union_reguser,$type=''){
	global $_G,$it618_union_lang;
	
	$id=C::t('#it618_union#it618_union_jl')->insert(array(
		'it618_type' => 1,
		'it618_jltype' => $jltype.'1',
		'it618_uid' => $it618_union_reguser['it618_uid'],
		'it618_tuiuidfind' => 0,
		'it618_tuiuid' => $it618_union_reguser['it618_tuiuid'],
		'it618_time' => $_G['timestamp']
	), true);
	
	for($i=1;$i<=8;$i++){
		if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit1[$i]>0){
			C::t('#it618_union#it618_union_jl')->update($id,array(
				'it618_credit'.$i => $jl_credit1[$i]
			));
			
			C::t('#it618_union#it618_union_reguser')->update($it618_union_reguser['id'],array(
				'it618_credit'.$i.'1' => $jl_credit2[$i]
			));
			
			C::t('common_member_count')->increase($it618_union_reguser['it618_tuiuid'], array(
				'extcredits'.$i => $jl_credit1[$i])
			);
		}
	}
	
	if($jltype=='G1')$tmpjl=11;
	if($jltype=='G2')$tmpjl=21;
	if($jltype=='G3')$tmpjl=31;
	
	C::t('#it618_union#it618_union_reguser')->update($it618_union_reguser['id'],array(
		'it618_isjl'.$tmpjl => 1
	));
	
	it618_union_sendmessage('jl_user',$it618_union_reguser['id']);
	
	if($it618_union_reguser1 = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_uid=".$it618_union_reguser['it618_tuiuid'])) {
		$id=C::t('#it618_union#it618_union_jl')->insert(array(
			'it618_type' => 2,
			'it618_jltype' => $jltype.'2',
			'it618_uid' => $it618_union_reguser['it618_uid'],
			'it618_tuiuidfind' => $it618_union_reguser['it618_tuiuid'],
			'it618_tuiuid' => $it618_union_reguser1['it618_tuiuid'],
			'it618_time' => $_G['timestamp']
		), true);
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit2[$i]>0){
				C::t('#it618_union#it618_union_jl')->update($id,array(
					'it618_credit'.$i => $jl_credit2[$i]
				));
				
				C::t('#it618_union#it618_union_reguser')->update($it618_union_reguser['id'],array(
					'it618_credit'.$i.'2' => $jl_credit2[$i]
				));
				
				C::t('common_member_count')->increase($it618_union_reguser1['it618_tuiuid'], array(
					'extcredits'.$i => $jl_credit2[$i])
				);
			}
		}
		
		if($jltype=='G1')$tmpjl=12;
		if($jltype=='G2')$tmpjl=22;
		if($jltype=='G3')$tmpjl=32;
		
		C::t('#it618_union#it618_union_reguser')->update($it618_union_reguser['id'],array(
			'it618_isjl'.$tmpjl => 1
		));
		
		it618_union_sendmessage('jl_user',$it618_union_reguser1['id']);
	}

	if($type=='')it618_union_sendmessage('jl_admin',$it618_union_reguser['id']);
}

function it618_union_getisvipuser($vipgroupids){
	global $_G,$it618_union,$it618_union_lang;
	
	$okvipgroupids = array(array(),array());
	
	if(count($vipgroupids)>0){

		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
	
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$expgrouparray = $expirylist = $termsarray = array();
	
		if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
			$termsarray = $groupterms['ext'];
		}
		if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
			$termsarray[$_G['groupid']] = $groupterms['main']['time'];
		}
		
		foreach($termsarray as $expgroupid => $expiry) {
			if($expiry <= TIMESTAMP) {
				$expgrouparray[] = $expgroupid;
			}
		}
	
		$groupids = array();
		foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
			if(!empty($usergroup['pubtype'])) {
				$groupids[] = $groupid;
			}
		}
		
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
			}
		}
		
		if(!empty($groupterms['main'])) {
			$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
		}
		
		$expiryids = array_keys($expirylist);
		$groupids = array_merge($extgroupids, $expiryids, $groupids);
		
		if($groupids) {
			foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
				$groupid=$group['groupid'];
				
				if(in_array($groupid, $vipgroupids)){
					
					$isgroupok=1;
					if($group['type']!='system'&&$group['type']!='member'){
						$timestamp=$expirylist[$group['groupid']]['timestamp'];
						$grouptime=$expirylist[$group['groupid']]['time'];
						
						if($timestamp-3600*24*365*60>$_G['timestamp']||$grouptime==''){
							$grouptime=$it618_union_lang['s25'];
						}elseif($timestamp<$_G['timestamp']){
							$isgroupok=0;
						}
					}else{
						$grouptime='';
					}
					if($isgroupok==1){
						$okvipgroupids[0][]=$groupid;
						$okvipgroupids[1][]=$grouptime;
					}
				}
			}
		}
		
		if(!in_array($_G['groupid'], $okvipgroupids[0])){
			if(in_array($_G['groupid'], $vipgroupids)){
				$okvipgroupids[0][]=$_G['groupid'];
				$timestamp=$_G['member']['groupexpiry'];
				if($timestamp>0){
					$timestamp= dgmdate($timestamp, 'd');
				}
				$okvipgroupids[1][]=$timestamp;
			}
		}

	}
	
	return $okvipgroupids;
}

function it618_union_getjltype($jltype1=0,$jltype2=0,$jltype3=0){
	global $_G,$it618_union_lang;
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php';
	}
	
	if($jl_group_isok1==1||$jl_tuicount_isok1==1){
		if($jltype1==1)$check1='checked="checked"';
		$chkjltype.='<input type="checkbox" name="jltype[]" id="chkjltype1" value="G1" style="vertical-align:middle" '.$check1.'><label for="chkjltype1" style="cursor:pointer">G1</label> ';
		$tmpjs.='if(document.getElementById("chkjltype1").checked){chkjltype=chkjltype+"G1";}';
	}
	
	if($jl_group_isok2==1||$jl_tuicount_isok2==1){
		if($jltype2==1)$check2='checked="checked"';
		$chkjltype.='<input type="checkbox" name="jltype[]" id="chkjltype2" value="G2" style="vertical-align:middle" '.$check2.'><label for="chkjltype2" style="cursor:pointer">G2</label> ';
		$tmpjs.='if(document.getElementById("chkjltype2").checked){chkjltype=chkjltype+"G2";}';
	}
	
	if($jl_group_isok3==1||$jl_tuicount_isok3==1){
		if($jltype3==1)$check3='checked="checked"';
		$chkjltype.='<input type="checkbox" name="jltype[]" id="chkjltype3" value="G3" style="vertical-align:middle" '.$check3.'><label for="chkjltype3" style="cursor:pointer">G3</label> ';
		$tmpjs.='if(document.getElementById("chkjltype3").checked){chkjltype=chkjltype+"G3";}';
	}
	
	return $chkjltype.'it618_splitvar chkjltype="";'.$tmpjs;
}

function it618_union_getquans($key='',$page=1,$wap=0){
	global $_G,$it618_union_lang;
	if($wap==1){
		$ppp = 10;
	}else{
		$ppp = 18;
	}
	$page = max(1, intval($page));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_union#it618_union_quan')->fetch_all_by_shoptype_shopid(
		'',0,'it618_ison=1','id desc',$key,0,$startlimit,$ppp
	) as $it618_union_quan) {
		
		if($wap==1){
			$pricestr='';
			for($i=1;$i<=8;$i++){
				if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_quan['it618_credit'.$i]>0){
					$pricestr.=$it618_union_quan['it618_credit'.$i].$_G['setting']['extcredits'][$i]['title'].'+';
				}
			}
			
			if($pricestr!=''){
				$pricestr=$pricestr.'@';
				$pricestr=str_replace('+@','',$pricestr);
			}else{
				$pricestr=$it618_union_lang['s256'];	
			}
			
			if($it618_union_quan['it618_pids']==''){
				$it618_pids=$it618_union_lang['s547'];
			}else{
				$count=count(explode(",",$it618_union_quan['it618_pids']));
				$it618_pids='<a href="javascript:" onclick="showgoods(\'quan\','.$it618_union_quan['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
			}
	
			$tmpurl=it618_union_getrewrite('union_wap','quan@'.$it618_union_quan['id'],'plugin.php?id=it618_union:wap&pagetype=quan&cid='.$it618_union_quan['id']);
			
			$quansstr.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_union_quan['it618_pic'].'"/></a></td>
							<td class="tdright">
								<div class="tdname" onclick="location.href=\''.$tmpurl.'\'">'.$it618_union_quan['it618_name'].'</div>
								<div class="tddes">'.$pricestr.'</div>
								<div class="tddes">'.$it618_union_lang['s279'].$it618_union_quan['it618_count'].' '.$it618_union_lang['s280'].$it618_union_quan['it618_salecount'].'</div>
								
								<div class="tddes">'.$it618_pids.'</div>
								<a  href="'.$tmpurl.'" style="background-color:#f30;line-height:28px;color:#fff;font-size:12px;float:right;margin-right:6px;margin-top:-10px;padding-left:10px;padding-right:10px;border-radius:3px">'.$it618_union_lang['s616'].'</a>
								<div class="tdprice">'.strip_tags(it618_union_getquantype($it618_union_quan)).'</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';		  
		}else{
			
			if($it618_union_quan['it618_pids']==''){
				$it618_pids='<p>'.$it618_union_lang['s547'].'</p>';
			}else{
				$it618_pids='<p onclick="showgoods(\'quan\','.$it618_union_quan['id'].')" style="cursor:pointer;color:#39F">'.$it618_union_lang['s545'].'</p>';
			}
			
			$tmpurl=it618_union_getrewrite('union_quan',$it618_union_quan['id'],'plugin.php?id=it618_union:union_quan&qid='.$it618_union_quan['id']);
		
			$quansstr.='<div class="quanItem clearfix">
							  <div class="gameImg">
								  <img src="'.$it618_union_quan['it618_pic'].'" height="120" width="120" alt="" />
							  </div>
							  <div class="gameInfo">
								  <h4 style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'.$it618_union_quan['it618_name'].'</h4>
								  <p style="color:#f60">'.strip_tags(it618_union_getquantype($it618_union_quan)).'</p> 
								  '.$it618_pids.'
								  <div class="itemAction">
									  <a href="'.$tmpurl.'" target="_blank" class="androidGet clearfix"><i></i><span>'.$it618_union_lang['s269'].'</span></a>
								  </div>
							  </div>
						  </div>';
		}
	}
	
	$count = C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('',0,'it618_ison=1','id desc',$key,0);
	$funname='getquans';
	
	if($wap==1){
		$tmparr=explode('</tr>',$quansstr);
		if(count($tmparr)>1){
			$quansstr=$quansstr.'@@@';
			$quansstr=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$quansstr);
		}
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}else{
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].'plugin.php?id=it618_union:ajax');
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',''.$funname.'(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
	}
	
	return $quansstr.'it618_split'.$multipage;
}

function it618_union_gettuis($key='',$page=1,$wap=0){
	global $_G,$it618_union_lang;
	if($wap==1){
		$ppp = 10;
	}else{
		$ppp = 18;
	}
	$page = max(1, intval($page));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_union#it618_union_tui')->fetch_all_by_shoptype_shopid(
		'',0,'it618_ison=1 and UNIX_TIMESTAMP(it618_etime)>'.$_G['timestamp'],'id desc',$key,$startlimit,$ppp
	) as $it618_union_tui) {
		
		if($wap==1){
			
			$tmpurl=it618_union_getrewrite('union_wap','tui@'.$it618_union_tui['id'],'plugin.php?id=it618_union:wap&pagetype=tui&cid='.$it618_union_tui['id']);
			
			$jionbtn='<a  href="'.$tmpurl.'" style="height:28px; line-height:28px; float:right;padding:0 10px; background-color:#fc6a52; color:#fff; font-size:12px; border-radius:6px; margin-top:-10px" target="_blank">'.$it618_union_lang['s615'].'</a>';
			
			$state='';
			if($_G['uid']>0){
				$count=C::t('#it618_union#it618_union_tuijoin')->count_by_tid_uid($it618_union_tui['id'],$_G['uid']);
				if($count>0){
					$state=$it618_union_lang['s617'];
					$jionbtn='';
				}
			}
			
			$count=count(explode(",",$it618_union_tui['it618_pids']));
			$it618_pids='<a href="javascript:" onclick="showgoods(\'tui\','.$it618_union_tui['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
			
			$tuisstr.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_union_tui['it618_pic'].'" style="border-radius:3px"/></a></td>
							<td class="tdright">
								<div class="tdname" onclick="location.href=\''.$tmpurl.'\'">'.$it618_union_tui['it618_name'].'</div>
								<div class="tddes">'.$it618_union_lang['s112'].$it618_union_tui['it618_joincount'].' '.$state.'</div>
								<div class="tddes">'.$it618_union_lang['s517'].$it618_union_tui['it618_etime'].'</div>
								<div class="tddes">'.$it618_pids.'</div>
								'.$jionbtn.'
								<div class="tdprice">'.$it618_union_lang['s515'].$it618_union_tui['it618_tcbl'].'%</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';		  
		}else{
			
			$it618_pids='<p onclick="showgoods(\'tui\','.$it618_union_tui['id'].')" style="cursor:pointer;color:#39F">'.$it618_union_lang['s545'].'</p>';
			
			$tmpurl=it618_union_getrewrite('union_tui',$it618_union_tui['id'],'plugin.php?id=it618_union:union_tui&tid='.$it618_union_tui['id']);
		
			$tuisstr.='<div class="quanItem clearfix">
							  <div class="gameImg">
								  <img src="'.$it618_union_tui['it618_pic'].'" height="120" width="120" alt="" />
							  </div>
							  <div class="gameInfo">
								  <h4 style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'.$it618_union_tui['it618_name'].'</h4>
								  <p>'.$it618_union_lang['s515'].'<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font></p> 
								  '.$it618_pids.'
								  <div class="itemAction">
									  <a href="'.$tmpurl.'" target="_blank" class="androidGet clearfix"><i></i><span>'.$it618_union_lang['s558'].'</span></a>
								  </div>
							  </div>
						  </div>';
		}
	}
	
	$count = C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('',0,'it618_ison=1','id desc',$key);
	$funname='gettuis';
	
	if($wap==1){
		$tmparr=explode('</tr>',$quansstr);
		if(count($tmparr)>1){
			$quansstr=$quansstr.'@@@';
			$quansstr=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$quansstr);
		}
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}else{
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].'plugin.php?id=it618_union:ajax');
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',''.$funname.'(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
	}
	
	return $tuisstr.'it618_split'.$multipage;
}

function it618_union_getquantype($it618_union_quansale,$type=''){
	global $_G,$it618_union_lang;
	
	if($it618_union_quansale['it618_type']==1){
		if($type=='quanmoney'){
			$tmpstr=$it618_union_quansale['it618_mjmoney2'];
		}else{
			$tmpstr='<font color=red>'.$it618_union_lang['s240'].$it618_union_quansale['it618_mjmoney1'].$it618_union_lang['s195'].$it618_union_lang['s241'].$it618_union_quansale['it618_mjmoney2'].$it618_union_lang['s195'].'</font>';
		}
	}else{
		if($type=='quanmoney'){
			$tmpstr=$it618_union_quansale['it618_money'];
		}else{
			$tmpstr='<font color=red>'.$it618_union_lang['s1584'].$it618_union_quansale['it618_money'].$it618_union_lang['s195'].'</font>';
		}
	}
	
	return $tmpstr;
}

function it618_union_getquanoktime($type,$oktime1,$oktime2){
	global $_G,$it618_union_lang;
	
	$timetmp1=explode(" ",$oktime1);
	$timetmp2=explode(" ",$oktime2);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);

	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);

	$timecss='#390';
	if($etime<$_G['timestamp']){
		$timecss='#999';
	}else{
		if($btime>$_G['timestamp']){
			$timecss='blue';
		}
	}
	
	if($type=='quan'){
		return '<font color='.$timecss.'>'.$oktime1.' - '.$oktime2.'</font>';
	}
	
	if($type=='quangwc'){
		if($etime<$_G['timestamp']){
			return '';
		}else{
			if($btime>$_G['timestamp']){
				return '';
			}
		}
		
		return '<font color=#390>'.it618_union_gettime1($etime).'</font>';
	}
}

function it618_union_get_contents($str){
	return dfsockopen($str);
}

function it618_union_getisokquan($it618_union_quansale,$pid=0,$money=0){
	global $_G,$it618_union_lang;
	
	$timetmp1=explode(" ",$it618_union_quansale['it618_oktime1']);
	$timetmp2=explode(" ",$it618_union_quansale['it618_oktime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);

	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	if($etime<$_G['timestamp']){
		return '';
	}else{
		if($btime>$_G['timestamp']){
			return '';
		}
	}
	
	if($pid>0){
		if($it618_union_quansale['it618_pids']!=''){
			
			$tmparr=explode(",",$it618_union_quansale['it618_pids']);
			if(!in_array($pid,$tmparr))return '';
		}
		
		if($it618_union_quansale['it618_type']==1){
			if($money<$it618_union_quansale['it618_mjmoney1']){
				return '';
			}
		}
	}else{
		if($it618_union_quansale['it618_pids']!=''){
			$money=DB::result_first("SELECT SUM(it618_money) FROM ".DB::table("it618_".$it618_union_quansale['it618_shoptype']."_gwc")." where it618_uid=".$it618_union_quansale['it618_uid']." and it618_pid in(".$it618_union_quansale['it618_pids'].")");
			if($money==0)return '';
		}else{
			$money=DB::result_first("SELECT SUM(it618_money) FROM ".DB::table("it618_".$it618_union_quansale['it618_shoptype']."_gwc")." where it618_shopid=".$it618_union_quansale['it618_shopid']." and it618_uid=".$it618_union_quansale['it618_uid']);
		}
		
		if($it618_union_quansale['it618_type']==1){
			if($money<$it618_union_quansale['it618_mjmoney1']){
				return '';
			}
		}
	}
	
	$tmpstr=it618_union_gettime1($etime);
	
	return $tmpstr;
}

function it618_union_setquanmoney($it618_union_quansale){
	global $_G,$it618_union_lang;
	
	$uid=$it618_union_quansale['it618_uid'];
	$shopid=$it618_union_quansale['it618_shopid'];
	
	$gwctablename='it618_'.$it618_union_quansale['it618_shoptype'].'_gwc';
	
	$quanmoney=it618_union_getquantype($it618_union_quansale,'quanmoney');
	
	$allmoney=DB::result_first("SELECT SUM(it618_money) FROM ".DB::table($gwctablename)." where it618_uid=".$uid." and it618_shopid=".$shopid);
	
	if($allmoney>$quanmoney){
		$allcount=DB::result_first("SELECT count(1) FROM ".DB::table($gwctablename)." where it618_uid=".$uid." and it618_shopid=".$shopid);
		
		$count=1;$tmpallquanmoney=0;
		$query = DB::query("SELECT * FROM ".DB::table($gwctablename)." where it618_uid=".$uid." and it618_shopid=".$shopid." order by it618_money");
		while($gwctabletmp = DB::fetch($query)) {
			
			if($count==$allcount){
				$tmpquanmoney=$quanmoney-$tmpallquanmoney;
			}else{
				$tmpquanmoney=intval($gwctabletmp['it618_money']/$allmoney*$quanmoney);
			}
			
			if($tmpquanmoney>$gwctabletmp['it618_money'])$tmpquanmoney=$gwctabletmp['it618_money'];
			
			DB::query("UPDATE ".DB::table($gwctablename)." SET it618_quanmoney=".$tmpquanmoney." WHERE id=".$gwctabletmp['id']);
			
			$count=$count+1;
			$tmpallquanmoney=$tmpallquanmoney+$tmpquanmoney;
		}
	}else{
		DB::query("UPDATE ".DB::table($gwctablename)." SET it618_quanmoney=it618_money where it618_uid=".$uid." and it618_shopid=".$shopid);
	}
}

function it618_union_getquansale($shoptype,$shopid,$wap,$pid,$money){
	global $_G,$it618_union_lang;
	
	$it618sql='it618_uid='.$_G['uid'].' and it618_state=0';
	
	$n=0;
	foreach(C::t('#it618_union#it618_union_quansale')->fetch_all_by_shoptype_shopid(
		$shoptype,$shopid,$it618sql,'it618_oktime2','',0,'','',0,0
	) as $it618_union_quansale) {
		$oktimestr=it618_union_getisokquan($it618_union_quansale,$pid,$money);
		if($oktimestr=='')continue;
		
		if($it618_union_quansale['it618_qid']>0){
			$it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_id($it618_union_quansale['it618_qid']);
			$it618_name=$it618_union_quan['it618_name'];
		}else{
			$it618_name=$it618_union_quansale['it618_name'];
		}
		$quanmoney=it618_union_getquantype($it618_union_quansale,'quanmoney');
		
		if($wap==1){
			$it618_name1=cutstr($it618_name,36,'...');
			$width=';width:100%';
			
			$myquan_get.='<option value="'.$it618_union_quansale['id'].'@'.$quanmoney.'">'.$it618_union_lang['s311'].' &yen; '.$quanmoney.' -- '.$it618_name1.' '.$oktimestr.'</option>';
		}else{
			$myquan_get.='<option value="'.$it618_union_quansale['id'].'@'.$quanmoney.'">'.$it618_union_lang['s311'].' &yen; '.$quanmoney.' -- '.$it618_name.' '.$oktimestr.'</option>';
		}
		
		$n=$n+1;
	}
	
	if($myquan_get!=''){
		$tmpjs='var tmparr=this.value.split(\'@\');document.getElementById(\'quanid\').value=tmparr[0];var tmpmoney=parseFloat(document.getElementById(\'yfmoneyvalue\').value)-tmparr[1];if(tmpmoney<0)tmpmoney=0;document.getElementById(\'yfmoney\').innerHTML=tmpmoney.toFixed(2);if(tmpmoney==0){document.getElementById(\'payselect\').style.display=\'none\';}else{document.getElementById(\'payselect\').style.display=\'\';}';
		$quanstr2='<select onchange="'.$tmpjs.'" class="quanselect" style="border:#f1f1f1 1px solid; border-radius:3px;height:30px;background-color:#f9f9f9;color:red'.$width.'"><option value="0@0">'.$it618_union_lang['s321'].$n.$it618_union_lang['s322'].' '.$it618_union_lang['s323'].'</option>'.$myquan_get.'</select>';
		
		return $quanstr2.'<input type="hidden" id="quanid" name="quanid" value="0"><input type="hidden" id="confirmtitle" value="'.$it618_union_lang['s317'].'"><br>';
	}else{
		return '<input type="hidden" id="quanid" name="quanid" value="0"><input type="hidden" id="confirmtitle" value="'.$it618_union_lang['s317'].'">';
	}
}

function it618_union_getquangwc($shoptype,$wap,$width){
	global $_G,$it618_union_lang;
	$uid=$_G['uid'];
	$isquan=0;
	if($shoptype=='brand'){
		$jqueryname='IT618_BRAND';
		foreach(C::t('#it618_brand#it618_brand_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($shopids['it618_shopid']);
			$shopid=$it618_brand_brand['id'];
			$shopname=$it618_brand_brand['it618_name'];
			
			$money=DB::result_first("SELECT SUM(it618_money) FROM ".DB::table("it618_brand_gwc")." where it618_uid=".$uid." and it618_shopid=".$shopid);
			
			$tmpmyquan_gettmp=it618_union_getquangwctmp($shoptype,$shopid);
			$tmparr=explode("it618_split",$tmpmyquan_gettmp);
			$tmpmyquan_count=$tmparr[0];
			$tmpmyquan_get=$tmparr[1];
			
			if($tmpmyquan_get!=''){
				if($wap!=1){
					$myquan_get.='<tr><td class="tdquanshop"><div>'.$it618_union_lang['s307'].'<span>&yen;</span><span id="summoney'.$shopid.'" class="quanmoney">'.$money.'</span> '.$it618_union_lang['s308'].'<span>&yen;</span><span id="quanmoney'.$shopid.'" class="quanmoney"></span></div>'.$shopname.'</td></tr>
					<tr><td class="tdquanselect"><div class="selectquandiv">'.$tmpmyquan_get.'<input type="hidden" id="quanid'.$shopid.'" name="quanid'.$shopid.'"></div></td></tr>
					<tr><td class="tdhr"></td></tr>
					';
				}else{
					$myquan_get.='<tr><td class="tdquanshop" onClick="collapsed(\'div_shop'.$shopid.'\',\'img_selectquan\')"><span style="float:right;color:#999">'.$tmpmyquan_count.$it618_union_lang['s320'].'<img src="source/plugin/it618_union/wap/images/collapsed_yes.gif" style="float:right;cursor:pointer;margin-left:6px" id="img_selectquan"></span>'.$shopname.'</td></tr>
					<tr><td class="tdquanselect"><div id="div_shop'.$shopid.'" class="selectquandiv" style="display:none">'.$tmpmyquan_get.'<input type="hidden" id="quanid'.$shopid.'" name="quanid'.$shopid.'"></div></td></tr>
					<tr><td class="tdquanmoney">'.$it618_union_lang['s307'].'<span>&yen;</span><span id="summoney'.$shopid.'" class="quanmoney">'.$money.'</span> '.$it618_union_lang['s308'].'<span>&yen;</span><span id="quanmoney'.$shopid.'" class="quanmoney"></span></td></tr>
					<tr><td class="tdhr"></td></tr>
					';
				}
				$shopidstr.=$shopid.',';
				$isquan=1;
			}else{
				$myquan_get.='<span id="quanmoney'.$shopid.'" style="display:none">'.$money.'</span>';
			}
		}
	}
	
	if($shoptype=='tuan'){
		$jqueryname='IT618_TUAN';
		$tmpscore='tmpsumscore=document.getElementById("tmpsumscore").value;';
		foreach(C::t('#it618_tuan#it618_tuan_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($shopids['it618_shopid']);
			$shopid=$it618_tuan_shop['id'];
			$shopname=$it618_tuan_shop['it618_name'];
			
			$money=DB::result_first("SELECT SUM(it618_money) FROM ".DB::table("it618_tuan_gwc")." where it618_uid=".$uid." and it618_shopid=".$shopid);
			
			$tmpmyquan_gettmp=it618_union_getquangwctmp($shoptype,$shopid);
			$tmparr=explode("it618_split",$tmpmyquan_gettmp);
			$tmpmyquan_count=$tmparr[0];
			$tmpmyquan_get=$tmparr[1];
			
			if($tmpmyquan_get!=''){
				if($wap!=1){
					$myquan_get.='<tr><td class="tdquanshop"><div>'.$it618_union_lang['s307'].'<span>&yen;</span><span id="summoney'.$shopid.'" class="quanmoney">'.$money.'</span> '.$it618_union_lang['s308'].'<span>&yen;</span><span id="quanmoney'.$shopid.'" class="quanmoney"></span></div>'.$shopname.'</td></tr>
					<tr><td class="tdquanselect"><div class="selectquandiv">'.$tmpmyquan_get.'<input type="hidden" id="quanid'.$shopid.'" name="quanid'.$shopid.'"></div></td></tr>
					<tr><td class="tdhr"></td></tr>
					';
				}else{
					$myquan_get.='<tr><td class="tdquanshop" onClick="collapsed(\'div_shop'.$shopid.'\',\'img_selectquan\')"><span style="float:right;color:#999">'.$tmpmyquan_count.$it618_union_lang['s320'].'<img src="source/plugin/it618_union/wap/images/collapsed_yes.gif" style="float:right;cursor:pointer;margin-left:6px" id="img_selectquan"></span>'.$shopname.'</td></tr>
					<tr><td class="tdquanselect"><div id="div_shop'.$shopid.'" class="selectquandiv" style="display:none">'.$tmpmyquan_get.'<input type="hidden" id="quanid'.$shopid.'" name="quanid'.$shopid.'"></div></td></tr>
					<tr><td class="tdquanmoney">'.$it618_union_lang['s307'].'<span>&yen;</span><span id="summoney'.$shopid.'" class="quanmoney">'.$money.'</span> '.$it618_union_lang['s308'].'<span>&yen;</span><span id="quanmoney'.$shopid.'" class="quanmoney"></span></td></tr>
					<tr><td class="tdhr"></td></tr>
					';
				}
				$shopidstr.=$shopid.',';
				$isquan=1;
			}else{
				$myquan_get.='<span id="quanmoney'.$shopid.'" style="display:none">'.$money.'</span>';
			}
		}
	}
	
	if($shoptype=='video'){
		$jqueryname='IT618_VIDEO';
		$tmpscore='tmpsumscore=document.getElementById("tmpsumscore").value;';
		foreach(C::t('#it618_video#it618_video_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($shopids['it618_shopid']);
			$shopid=$it618_video_shop['id'];
			$shopname=$it618_video_shop['it618_name'];
			
			$money=DB::result_first("SELECT SUM(it618_money) FROM ".DB::table("it618_video_gwc")." where it618_uid=".$uid." and it618_shopid=".$shopid);
			
			$tmpmyquan_gettmp=it618_union_getquangwctmp($shoptype,$shopid);
			$tmparr=explode("it618_split",$tmpmyquan_gettmp);
			$tmpmyquan_count=$tmparr[0];
			$tmpmyquan_get=$tmparr[1];
			
			if($tmpmyquan_get!=''){
				if($wap!=1){
					$myquan_get.='<tr><td class="tdquanshop"><div>'.$it618_union_lang['s307'].'<span>&yen;</span><span id="summoney'.$shopid.'" class="quanmoney">'.$money.'</span> '.$it618_union_lang['s308'].'<span>&yen;</span><span id="quanmoney'.$shopid.'" class="quanmoney"></span></div>'.$shopname.'</td></tr>
					<tr><td class="tdquanselect"><div class="selectquandiv">'.$tmpmyquan_get.'<input type="hidden" id="quanid'.$shopid.'" name="quanid'.$shopid.'"></div></td></tr>
					<tr><td class="tdhr"></td></tr>
					';
				}else{
					$myquan_get.='<tr><td class="tdquanshop" onClick="collapsed(\'div_shop'.$shopid.'\',\'img_selectquan\')"><span style="float:right;color:#999">'.$tmpmyquan_count.$it618_union_lang['s320'].'<img src="source/plugin/it618_union/wap/images/collapsed_yes.gif" style="float:right;cursor:pointer;margin-left:6px" id="img_selectquan"></span>'.$shopname.'</td></tr>
					<tr><td class="tdquanselect"><div id="div_shop'.$shopid.'" class="selectquandiv" style="display:none">'.$tmpmyquan_get.'<input type="hidden" id="quanid'.$shopid.'" name="quanid'.$shopid.'"></div></td></tr>
					<tr><td class="tdquanmoney">'.$it618_union_lang['s307'].'<span>&yen;</span><span id="summoney'.$shopid.'" class="quanmoney">'.$money.'</span> '.$it618_union_lang['s308'].'<span>&yen;</span><span id="quanmoney'.$shopid.'" class="quanmoney"></span></td></tr>
					<tr><td class="tdhr"></td></tr>
					';
				}
				$shopidstr.=$shopid.',';
				$isquan=1;
			}else{
				$myquan_get.='<span id="quanmoney'.$shopid.'" style="display:none">'.$money.'</span>';
			}
		}
	}
	
	if($shoptype=='exam'){
		$jqueryname='IT618_EXAM';
		$tmpscore='tmpsumscore=document.getElementById("tmpsumscore").value;';
		foreach(C::t('#it618_exam#it618_exam_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($shopids['it618_shopid']);
			$shopid=$it618_exam_shop['id'];
			$shopname=$it618_exam_shop['it618_name'];
			
			$money=DB::result_first("SELECT SUM(it618_money) FROM ".DB::table("it618_exam_gwc")." where it618_uid=".$uid." and it618_shopid=".$shopid);
			
			$tmpmyquan_gettmp=it618_union_getquangwctmp($shoptype,$shopid);
			$tmparr=explode("it618_split",$tmpmyquan_gettmp);
			$tmpmyquan_count=$tmparr[0];
			$tmpmyquan_get=$tmparr[1];
			
			if($tmpmyquan_get!=''){
				if($wap!=1){
					$myquan_get.='<tr><td class="tdquanshop"><div>'.$it618_union_lang['s307'].'<span>&yen;</span><span id="summoney'.$shopid.'" class="quanmoney">'.$money.'</span> '.$it618_union_lang['s308'].'<span>&yen;</span><span id="quanmoney'.$shopid.'" class="quanmoney"></span></div>'.$shopname.'</td></tr>
					<tr><td class="tdquanselect"><div class="selectquandiv">'.$tmpmyquan_get.'<input type="hidden" id="quanid'.$shopid.'" name="quanid'.$shopid.'"></div></td></tr>
					<tr><td class="tdhr"></td></tr>
					';
				}else{
					$myquan_get.='<tr><td class="tdquanshop" onClick="collapsed(\'div_shop'.$shopid.'\',\'img_selectquan\')"><span style="float:right;color:#999">'.$tmpmyquan_count.$it618_union_lang['s320'].'<img src="source/plugin/it618_union/wap/images/collapsed_yes.gif" style="float:right;cursor:pointer;margin-left:6px" id="img_selectquan"></span>'.$shopname.'</td></tr>
					<tr><td class="tdquanselect"><div id="div_shop'.$shopid.'" class="selectquandiv" style="display:none">'.$tmpmyquan_get.'<input type="hidden" id="quanid'.$shopid.'" name="quanid'.$shopid.'"></div></td></tr>
					<tr><td class="tdquanmoney">'.$it618_union_lang['s307'].'<span>&yen;</span><span id="summoney'.$shopid.'" class="quanmoney">'.$money.'</span> '.$it618_union_lang['s308'].'<span>&yen;</span><span id="quanmoney'.$shopid.'" class="quanmoney"></span></td></tr>
					<tr><td class="tdhr"></td></tr>
					';
				}
				$shopidstr.=$shopid.',';
				$isquan=1;
			}else{
				$myquan_get.='<span id="quanmoney'.$shopid.'" style="display:none">'.$money.'</span>';
			}
		}
	}
	
	$tmpjscss='
	<script>
	function setselectquan(name,n,sid,qid,money){
		'.$jqueryname.'("a[name="+name+"]").each(function(i, o){
			if(n==i){
				'.$jqueryname.'(o).addClass("current");
				document.getElementById("quanid"+sid).value=qid;
				var tmpmoney=parseFloat(document.getElementById("summoney"+sid).innerHTML)-money;
				if(tmpmoney<0)tmpmoney=0;
				document.getElementById("quanmoney"+sid).innerHTML=tmpmoney;
				
				getallquanmoney();
			}else{
				'.$jqueryname.'(o).removeClass("current");
			}
		
		});
	}
	
	function getallquanmoney(){
		var tmpsumscore="";
		var shopids=document.getElementById("shopids").value;
		var tmparr=shopids.split(",");
		var money=0;
		for(var i=0;i<tmparr.length;i++){
			if(tmparr[i]>0)
			money=money+parseFloat(document.getElementById("quanmoney"+tmparr[i]).innerHTML);
		}
		
		'.$tmpscore.'
		
		document.getElementById("allquanmoney").innerHTML=money.toFixed(2)+tmpsumscore;
		
		if(money==0){
			document.getElementById("payselect").style.display="none";
		}else{
			document.getElementById("payselect").style.display="";
		}
	}
	
	function collapsed(ddid,imgid){
		ddobj=document.getElementById(ddid);
		imgobj=document.getElementById(imgid);
		
		var tmparr=imgobj.src.split(\'collapsed_no.gif\');
		if(tmparr.length>1){
			ddobj.style.display=\'none\';
			imgobj.src=\'source/plugin/it618_union/wap/images/collapsed_yes.gif\'
		}else{
			ddobj.style.display=\'\';
			imgobj.src=\'source/plugin/it618_union/wap/images/collapsed_no.gif\'
		}
		
	}
	</script>
	
	<style>
	.quangwc{width:100%; margin-top:10px; margin-bottom:10px;font:18px/20px arial;}
	.quangwc tr td.tdquanshop{padding:10px 6px; font-size:15px; background-color:#f9f9f9; color:#000}
	
	.quangwc tr td.tdquanshop div{float:right; font-size:12px; color:#999}
	.quangwc tr td.tdquanshop div span{color:#999;font:13px/15px arial;}
	.quangwc tr td.tdquanshop div span.quanmoney{font-size:15px}
	
	.quangwc tr td.tdquanmoney{font-size:12px; color:#999;padding-top:10px}
	.quangwc tr td.tdquanmoney span{color:#999;font:13px/15px arial;}
	.quangwc tr td.tdquanmoney span.quanmoney{font-size:15px}
	
	.quangwc tr td.tdquanselect{padding-left:8px}
	
	.quangwc tr td.tdallmoney{text-align:right;padding:10px 6px; background-color:#f9f9f9; font-size:13px; color:#333}
	.quangwc tr td.tdallmoney span{color:#f60;font:18px/20px arial;}
	.quangwc tr td.tdallmoney span.quanmoney{color:#f60;font-size:23px}
	
	.quangwc tr td.tdhr{height:26px}
	
	.selectquandiv i{background:url(source/plugin/it618_union/images/selected.png)no-repeat}
	.selectquandiv{overflow:hidden;}
	.selectquandiv a{display:inline-block;height:40px;text-decoration:none;width:30%;border:1px solid #e8e8e8; font-size:12px;float:left;margin-right:10px; margin-top:10px;position:relative; padding:6px 10px;color:#999}
	.selectquandiv a.current{border-color:#f55a0d}
	.selectquandiv i{display:none;width:11px;height:11px;font-size:0;line-height:0;overflow:hidden;position:absolute;right:-1px;bottom:-1px}
	.selectquandiv a.current i{display:inline-block}
	.selectquandiv a img{float:left; margin-right:6px; width:38px; height:38px}
	.selectquandiv a span{color:#999}
	.selectquandiv a span.quanname{color:#565656}
	.selectquandiv a span.quanprice{color:#f30; margin-top:-4px;font:16px/28px arial; display:inline-block;float:right}
	</style>
	';
		
	if($wap==1){
		$width=$width-35;
		$tmpjscss.='
		<style>
		.quangwc tr td.tdquanshop{font-size:13px;color:#333}
		.quangwc tr td.tdquanselect{padding-left:6px}
		.selectquandiv a{width:'.$width.'px;margin-right:0;border:1px solid #f1f1f1;}
		.selectquandiv a span.quanprice{font-size:13px}
		</style>
		';
	}
	
	if($wap!=1){
		if($isquan==0){
			$myquan_get='<tr><td style="color:#999;padding-left:6px">'.$it618_union_lang['s318'].'</td></tr>';
		}else{
			$myquan_get.='
		<tr><td class="tdallmoney">'.$it618_union_lang['s310'].'<span>&yen;</span> <span id="allquanmoney" class="quanmoney"></span></td></tr>';
		}
		
		return '
		'.$tmpjscss.'
		<div class="buy-block-title"><h3>'.$it618_union_lang['s306'].'</h3></div>
		<div style="padding:10px">
		<table class="quangwc">
		'.$myquan_get.'<input type="hidden" id="shopids" value="'.$shopidstr.'"><input type="hidden" id="confirmtitle" value="'.$it618_union_lang['s317'].'">
		</table>
		</div>it618_split'.$isquan;
	}else{
		if($isquan==0){
			$myquan_get='<td style="color:#999;padding-left:6px">'.$it618_union_lang['s318'].'</td></tr>';
		}else{
			$myquan_get.='
		<tr><td class="tdallmoney">'.$it618_union_lang['s310'].'<span>&yen;</span> <span id="allquanmoney" class="quanmoney"></span></td></tr>';
		}
		
		return '
		'.$tmpjscss.'
		<tr><td><table width="100%">
		<tr class="gwctrtitle">
		<th style="padding-left:3px">'.$it618_union_lang['s306'].'</th>
		</tr>
		</table></td></tr>
		<tr><td style="padding:3px">
		<table class="quangwc">
		'.$myquan_get.'<input type="hidden" id="shopids" value="'.$shopidstr.'"><input type="hidden" id="confirmtitle" value="'.$it618_union_lang['s317'].'">
		</table>
		</td></tr>it618_split'.$isquan;
	}
}

function it618_union_getquangwctmp($shoptype,$shopid){
	global $_G,$it618_union_lang;
	
	$it618sql='it618_uid='.$_G['uid'].' and it618_state=0';
	
	$n=0;
	foreach(C::t('#it618_union#it618_union_quansale')->fetch_all_by_shoptype_shopid(
		$shoptype,$shopid,$it618sql,'it618_oktime2','',0,'','',0,0
	) as $it618_union_quansale) {
		$oktimestr=it618_union_getisokquan($it618_union_quansale);
		if($oktimestr=='')continue;
		
		if($it618_union_quansale['it618_qid']>0){
			$it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_id($it618_union_quansale['it618_qid']);
			$it618_name=$it618_union_quan['it618_name'];
			$it618_pic=$it618_union_quan['it618_pic'];
		}else{
			$it618_name=$it618_union_quansale['it618_name'];
			$it618_pic=$it618_union_quansale['it618_pic'];
		}
		$money=it618_union_getquantype($it618_union_quansale,'quanmoney');

		$it618_name1=cutstr($it618_name,36,'...');
		
		$myquan_get.='<a href="javascript:void(0)" onclick="setselectquan(\'gwcquan'.$shopid.'\','.$n.','.$shopid.','.$it618_union_quansale['id'].','.$money.')" name="gwcquan'.$shopid.'"><img src="'.$it618_pic.'"/><span class="quanname" title="'.$it618_union_quan['it618_name'].'">'.$it618_name1.'</span><br>'.$oktimestr.'<span class="quanprice">'.$it618_union_lang['s311'].' &yen; '.$money.'</span><i></i></a>
		';
		
		$n=$n+1;
	}
	
	if($myquan_get!=''){
		$tmpjs='setselectquan(\'gwcquan'.$shopid.'\','.$n.','.$shopid.',0,0)';
		
		return $n.'it618_split'.$myquan_get.'<a href="javascript:void(0)" onclick="setselectquan(\'gwcquan'.$shopid.'\','.$n.','.$shopid.',0,0)" name="gwcquan'.$shopid.'"><div style="font-size:14px;color:#888;padding-top:10px">'.$it618_union_lang['s323'].'</div><i></i></a><script>'.$tmpjs.'</script>';
	}
	
	return '';
}

function it618_union_delsalework(){
	DB::query("delete from ".DB::table('it618_union_salework'));
}

function it618_union_sendmessage($type,$id,$type1=''){
	global $_G,$it618_union_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/message.php';
	
	$tmpurl=it618_union_getrewrite('union_wap','','plugin.php?id=it618_union:wap');
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='reg_admin'&&$it618_body_reg_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_reg_admin;
				
				$it618_union_reguser = C::t('#it618_union#it618_union_reguser')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_reg_admin_tplid_wxsms;
				$body_wxsms=$it618_body_reg_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_union_getusername($it618_union_reguser['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{tuiuser}",it618_union_getusername($it618_union_reguser['it618_tuiuid']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_union_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_union_getusername($it618_union_reguser['it618_uid']),$Body);
				$Body=str_replace("{tuiuser}",it618_union_getusername($it618_union_reguser['it618_tuiuid']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_reg_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_union_getusername($it618_union_reguser['it618_uid']).'",';
					
					$tmparr=explode("{tuiuser}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tuiuser":"'.it618_union_getusername($it618_union_reguser['it618_tuiuid']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='jl_admin'&&$it618_body_jl_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_jl_admin;
				
				$it618_union_reguser = C::t('#it618_union#it618_union_reguser')->fetch_by_id($id);
				
				$it618_union_jl=C::t('#it618_union#it618_union_jl')->fetch_by_uid($it618_union_reguser['it618_uid']);
				for($i=1;$i<=8;$i++){
					if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_jl['it618_credit'.$i]>0){
						$jlstr.=$it618_union_jl['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
					}
				}
				if($jlstr!=''){
					$jlstr=$jlstr.'@';
					$jlstr=str_replace(', @','',$jlstr);
				}
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_jl_admin_tplid_wxsms;
				$body_wxsms=$it618_body_jl_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_union_getusername($it618_union_reguser['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{tuiuser}",it618_union_getusername($it618_union_reguser['it618_tuiuid']),$tmpvalue);
						$tmpvalue=str_replace("{jl}",$jlstr,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_union_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_union_getusername($it618_union_reguser['it618_uid']),$Body);
				$Body=str_replace("{tuiuser}",it618_union_getusername($it618_union_reguser['it618_tuiuid']),$Body);
				$Body=str_replace("{jl}",$jlstr,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_jl_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_union_getusername($it618_union_reguser['it618_uid']).'",';
					
					$tmparr=explode("{tuiuser}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tuiuser":"'.it618_union_getusername($it618_union_reguser['it618_tuiuid']).'",';
					
					$tmparr=explode("{jl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"jl":"'.$jlstr.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='reg_user'&&$it618_body_reg_user_isok==1){
			$it618_union_reguser = C::t('#it618_union#it618_union_reguser')->fetch_by_id($id);
			
			$count=C::t('#it618_union#it618_union_userset')->count_by_uid_ismsgok_reg($it618_union_reguser['it618_tuiuid']);
			if($count>0){
				$tel=C::t('#it618_union#it618_union_userset')->fetch_tel_by_uid($it618_union_reguser['it618_tuiuid']);
				$Body=$it618_body_reg_user;
				
				$uid=$it618_union_reguser['it618_tuiuid'];
				$tplid_wxsms=$it618_body_reg_user_tplid_wxsms;
				$body_wxsms=$it618_body_reg_user_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_union_getusername($it618_union_reguser['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{tuiuser}",it618_union_getusername($it618_union_reguser['it618_tuiuid']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_union_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_union_getusername($it618_union_reguser['it618_uid']),$Body);
				$Body=str_replace("{tuiuser}",it618_union_getusername($it618_union_reguser['it618_tuiuid']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_reg_user_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_union_getusername($it618_union_reguser['it618_uid']).'",';
					
					$tmparr=explode("{tuiuser}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tuiuser":"'.it618_union_getusername($it618_union_reguser['it618_tuiuid']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}

		}
		
		if($type=='jl_user'&&$it618_body_jl_user_isok==1){
			$it618_union_reguser = C::t('#it618_union#it618_union_reguser')->fetch_by_id($id);
			
			$count=C::t('#it618_union#it618_union_userset')->count_by_uid_ismsgok_jl($it618_union_reguser['it618_tuiuid']);
			if($count>0){
				$tel=C::t('#it618_union#it618_union_userset')->fetch_tel_by_uid($it618_union_reguser['it618_tuiuid']);
				$Body=$it618_body_jl_user;
				
				$it618_union_jl=C::t('#it618_union#it618_union_jl')->fetch_by_uid($it618_union_reguser['it618_uid']);
				for($i=1;$i<=8;$i++){
					if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_jl['it618_credit'.$i]>0){
						$jlstr.=$it618_union_jl['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
					}
				}
				if($jlstr!=''){
					$jlstr=$jlstr.'@';
					$jlstr=str_replace(', @','',$jlstr);
				}
				
				$uid=$it618_union_reguser['it618_tuiuid'];
				$tplid_wxsms=$it618_body_jl_user_tplid_wxsms;
				$body_wxsms=$it618_body_jl_user_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_union_getusername($it618_union_reguser['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{tuiuser}",it618_union_getusername($it618_union_reguser['it618_tuiuid']),$tmpvalue);
						$tmpvalue=str_replace("{jl}",$jlstr,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_union_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_union_getusername($it618_union_reguser['it618_uid']),$Body);
				$Body=str_replace("{tuiuser}",it618_union_getusername($it618_union_reguser['it618_tuiuid']),$Body);
				$Body=str_replace("{jl}",$jlstr,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_jl_user_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_union_getusername($it618_union_reguser['it618_uid']).'",';
					
					$tmparr=explode("{tuiuser}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tuiuser":"'.it618_union_getusername($it618_union_reguser['it618_tuiuid']).'",';
					
					$tmparr=explode("{jl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"jl":"'.$jlstr.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}

		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_union_lang['s478'].$it618_smsbaosign.$it618_union_lang['s479'];
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}

function it618_union_getfileext($filestr){
	$file_ext=strtolower(substr($filestr,strrpos($filestr, '.')+1)); 
	$tmparr=explode("?",$file_ext);
	return $tmparr[0];
}

function it618_union_getvipgoodsunit($it618_group_goods){
	global $_G,$it618_union_lang;
	
	$it618_unitcount=$it618_group_goods['it618_unitcount'];
	
	if($it618_group_goods['it618_unit']==1)$it618_unit=$it618_unitcount.$it618_union_lang['s760'];
	if($it618_group_goods['it618_unit']==2)$it618_unit=$it618_unitcount.$it618_union_lang['s761'];
	if($it618_group_goods['it618_unit']==3)$it618_unit=$it618_unitcount.$it618_union_lang['s762'];
	if($it618_group_goods['it618_unit']==4)$it618_unit=$it618_unitcount.$it618_union_lang['s763'];
	if($it618_group_goods['it618_unit']==5)$it618_unit=$it618_union_lang['s764'];
	
	return $it618_unit;
}

function it618_union_getgoodspic_plugin($plugin,$shopid,$pid,$it618_picbig,$i=0){
	$file_ext=it618_union_getfileext($it618_picbig);
	
	if($plugin=='it618_video'||$plugin=='it618_exam'){
		return 'source/plugin/'.$plugin.'/kindeditor/data/shop'.$shopid.'/smallimages/goods'.$pid.'_'.md5($it618_picbig).'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
	}elseif($plugin=='it618_group'){
		return 'source/plugin/'.$plugin.'/kindeditor/data/smallimages/goods'.$pid.'_'.md5($it618_picbig).'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
	}elseif($plugin=='it618_scoremall'){
		return 'source/plugin/'.$plugin.'/kindeditor/data/u'.$shopid.'/smallimage/goods'.$pid.'_0.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
	}else{
		return 'source/plugin/'.$plugin.'/kindeditor/data/shop'.$shopid.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
	}
}

function it618_union_getgoodsprice_plugin($plugin,$it618goods,$type=''){
	global $_G,$it618_union_lang,$it618_sale_lang;
	
	$goodspricestr='<font color=#390>'.$it618_union_lang['s546'].'</font>';
	
	if($plugin=='it618_tuan'||$plugin=='it618_video'||$plugin=='it618_exam'||$plugin=='it618_group'){
		if($plugin=='it618_video'){
			$typecountok = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid_ok($it618goods['id'],0,0);
			if($typecountok>1){
				$tmpprice=$it618_union_lang['s771'];
			}
		}
		
		if($it618goods['it618_saleprice']>0&&$it618goods['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618goods['it618_jfid']]['title'];
			$goodspricestr='&yen;'.$it618goods['it618_saleprice'].'+'.$it618goods['it618_score'].$goodsjfname;
		}else{
			if($it618goods['it618_saleprice']>0){
				$goodspricestr='&yen;'.$it618goods['it618_saleprice'];
			}
			
			if($it618goods['it618_score']>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618goods['it618_jfid']]['title'];
				$goodspricestr=$it618goods['it618_score'].$goodsjfname;
			}
		}
		
		$goodspricestr='<font color=#f30>'.$goodspricestr.'</font>';
		
		if($plugin=='it618_video'){
			$pricestr=$it618_video_lang['s1534'];
			$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618goods['it618_shopid']);
			if($it618_video_shop['it618_issale']!=1){
				$goodspricestr='<font color=#f30>'.$it618_union_lang['s879'].'</font>';
			}
		}
	}
	
	if($plugin=='it618_brand'){
		$it618_brand = $_G['cache']['plugin']['it618_brand'];
		$creditname=$_G['setting']['extcredits'][$it618_brand['brand_credit']]['title'];
		
		if($it618goods['it618_isalipay']==1&&$it618goods['it618_isduihuan']==1){
			$goodspricestr='&yen;'.$it618goods['it618_uprice'].' <font color=#390>'.$it618goods['it618_score'].$creditname.'</font>';
		}else{
			if($it618goods['it618_isalipay']==1){
				$goodspricestr='&yen;'.$it618goods['it618_uprice'];
			}else{
				$goodspricestr='<font color=#390>'.$it618goods['it618_score'].$creditname.'</font>';
			}	
		}
		
		$goodspricestr='<font color=#f30>'.$goodspricestr.'</font>';
	}
	
	if($plugin=='it618_sale'){
		require_once DISCUZ_ROOT.'./source/plugin/it618_sale/lang.func.php';
		$tmparr=explode($it618_sale_lang['s688'],$it618goods['it618_quanstr']);
		if(count($tmparr)>1){
			$tmparr1=explode($it618_sale_lang['s687'],$tmparr[0]);
			$tmparr2=explode($it618_sale_lang['s689'],$tmparr[1]);
			$price1=$tmparr1[1];
			$price2=$tmparr2[0];
			
			$goodspricestr = $it618goods['it618_saleprice']-$price2;
		}else{
			$tmparr=explode($it618_sale_lang['s690'],$it618goods['it618_quanstr']);
			if(count($tmparr)>1){
				$price1=$tmparr[0];
			}else{
				$tmparr=explode($it618_sale_lang['s692'],$it618goods['it618_quanstr']);
				$tmparr1=explode($it618_sale_lang['s689'],$tmparr[1]);
				$price1=$tmparr1[0];
			}
			
			$goodspricestr = $it618goods['it618_saleprice']-$price1;
		}
	}
	
	if($type=='sharecode'){
		$goodspricestr=str_replace("<font color=#f30>","",$goodspricestr);
		$goodspricestr=str_replace("<font color=#390>","",$goodspricestr);
		$goodspricestr=str_replace("</font>","",$goodspricestr);
		$goodspricestr=str_replace("&yen;",$it618_union_lang['s1228'],$goodspricestr);
	}
	
	return $goodspricestr.' '.$tmpprice;
}

function it618_union_getsaletcmoney_plugin($plugin,$saletmp,$tcbl){
	global $_G,$it618_union_lang;
	
	if($plugin=='it618_brand'){
		if($saletmp['it618_type']==1){
			$it618_brand = $_G['cache']['plugin']['it618_brand'];
			$salejfid=$it618_brand['brand_credit'];
			$goodsjfname=$_G['setting']['extcredits'][$salejfid]['title'];
			$salemoney=$saletmp['it618_score']*$saletmp['it618_count'].$goodsjfname;
			$tcmoney=intval($saletmp['it618_score']*$saletmp['it618_count']*$tcbl/100).$goodsjfname;
		}else{
			$prepaybl=1;
			if($saletmp['it618_saletype']==6){
				$prepaybl=$saletmp['it618_prepaybl']/100;
			}
			
			$it618_goodsmoney=round(($saletmp['it618_price']*$prepaybl*$saletmp['it618_count']*$saletmp['it618_zk']/100),2);
			$salemoney=$it618_goodsmoney.$it618_union_lang['s195'];
			$tcmoney=round((($it618_goodsmoney-$saletmp['it618_quanmoney'])*$tcbl/100), 2).$it618_union_lang['s195'];
		}
		
		if($saletmp['it618_quanmoney']>0){
			$salemoney.='-'.$saletmp['it618_quanmoney'].$it618_union_lang['s195'];
		}
	}
	
	if($plugin=='it618_tuan'||$plugin=='it618_video'||$plugin=='it618_exam'||$plugin=='it618_group'){
		if($saletmp['it618_price']>0&&$saletmp['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$saletmp['it618_jfid']]['title'];
			$salemoney=$saletmp['it618_price']*$saletmp['it618_count'].$it618_union_lang['s195'].'+'.$saletmp['it618_score']*$saletmp['it618_count'].$goodsjfname;
			$tcmoney=round((($saletmp['it618_price']*$saletmp['it618_count']-$saletmp['it618_quanmoney'])*$tcbl/100), 2).$it618_union_lang['s195'].'+'.intval($saletmp['it618_score']*$saletmp['it618_count']*$tcbl/100).$goodsjfname;
		}else{
			if($saletmp['it618_price']>0){
				$salemoney=$saletmp['it618_price']*$saletmp['it618_count'].$it618_union_lang['s195'];
				$tcmoney=round((($saletmp['it618_price']*$saletmp['it618_count']-$saletmp['it618_quanmoney'])*$tcbl/100), 2).$it618_union_lang['s195'];
			}
			
			if($saletmp['it618_score']>0){
				$goodsjfname=$_G['setting']['extcredits'][$saletmp['it618_jfid']]['title'];
				$salemoney=$saletmp['it618_score']*$saletmp['it618_count'].$goodsjfname;
				$tcmoney=intval($saletmp['it618_score']*$saletmp['it618_count']*$tcbl/100).$goodsjfname;
			}
		}
		
		if($saletmp['it618_quanmoney']>0){
			$salemoney.='-'.$saletmp['it618_quanmoney'].$it618_union_lang['s195'];
		}
	}
	
	$saletcmoney[]=$salemoney;
	$saletcmoney[]=$tcmoney;
	
	return $saletcmoney;
}

function it618_union_wike_rewriteurl($fl_html){
	global $_G;
	if($_G['cache']['plugin']['it618_wike']['rewriteurl']==1){
		//	forum.php?mod=viewthread&tid=43
		//	thread-43-1-1.html
		$tmparr=explode("forum.php?mod=viewthread",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"tid=")==1){
					$tmp=str_replace("&tid=","thread-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'-1-1.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}
		
		$tmparr=explode("do=album&id=",$fl_html);
		if(count($tmparr)>1){return $fl_html;}
		
		//	home.php?mod=space&uid=5
		//	space-uid-5.html
		$tmparr=explode("home.php?mod=space",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"uid=")==1){
					$tmp=str_replace("&uid=","space-uid-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}

	}
	
	return $fl_html;
}

function it618_union_getrewrite_plugin($plugin,$pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	
	if($_G['cache']['plugin'][$plugin]['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/'.$plugin.'/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/'.$plugin.'/config/rewrite.php';
	
	if($pagetype=='shop_home'){//shop-{sid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$shop_home.$shop_home1;
		
		if(count($tmparr)>1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=$pageurl.'?'.$tmparr[1];
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_page'){//shop_page-{sid}-{oid}.html
		$tmparr=explode("@",$pagevalue);
		
		$pageurl=$shop_page.$shop_page1;
		$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		$pageurl=str_replace("{oid}",$tmparr[1],$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_product'){//shop_product-{sid}-{pid}.html
		$tmparr=explode("@",$pagevalue);
		
		$pageurl=$shop_product.$shop_product1;
		$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		$pageurl=str_replace("{pid}",$tmparr[1],$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='brand_wap'){//brand_wap-{pagetype}-{sid}-{oid}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$brand_wap.$brand_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{sid}-{oid}-{cid}-{page}","",$pageurl);
		}else{
			$tmparr=explode("@",$pagevalue);
			if(count($tmparr)==2){
				$pageurl=str_replace("-{oid}-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
			}if(count($tmparr)==3){
				$pageurl=str_replace("-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
			}else{
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_lecturer'){//lecturer-{lid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_lecturer.$video_lecturer1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{lid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_product'){//video_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_product.$video_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_wap'){//video_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_wap.$video_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_teacher'){//teacher-{lid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_teacher.$exam_teacher1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{lid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_product'){//exam_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_product.$exam_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_wap'){//exam_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_wap.$exam_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='group_class'){//group_class-{cid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$group_class.$group_class1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{cid}",$tmparr[0],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='group_product'){//group_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$group_product.$group_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='group_wap'){//group_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$group_wap.$group_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_shop'){//tuan_shop-{sid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_shop.$tuan_shop1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_product'){//tuan_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_product.$tuan_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_wap'){//tuan_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_wap.$tuan_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_home'){//shop-{sid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$wshop_home.$wshop_home1;
		
		if(count($tmparr)>1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=$pageurl.'?'.$tmparr[1];
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='waimai_wap'){//waimai_wap-{pagetype}-{sid}-{oid}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$waimai_wap.$waimai_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{sid}-{oid}-{cid}-{page}","",$pageurl);
		}else{
			$tmparr=explode("@",$pagevalue);
			if(count($tmparr)==2){
				$pageurl=str_replace("-{oid}-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
			}if(count($tmparr)==3){
				$pageurl=str_replace("-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
			}else{
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='sale_product'){//sale_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$sale_product.$sale_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='sale_wap'){//sale_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$sale_wap.$sale_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='product'){//product-{pid}.html
	
		$pageurl=$product.$product1;
		$pageurl=str_replace("{pid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
}

function it618_union_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_union']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/rewrite.php';
	
	if($pagetype=='union_home'){
		return $union_home.$urltype;
	}
	
	if($pagetype=='union_yq'){//reg-{tuiuid}.html
		$pageurl=$union_yq.$union_yq1;
		
		$pageurl=str_replace("{tuiuid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='union_quans'){
		return $union_quans.$urltype;
	}
	
	if($pagetype=='union_quan'){//quan-{qid}.html
		$pageurl=$union_quan.$union_quan1;
		
		$pageurl=str_replace("{qid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='union_tuis'){
		return $union_tuis.$urltype;
	}
	
	if($pagetype=='union_tui'){//union_tui-{tid}.html
		$pageurl=$union_tui.$union_tui1;
		
		$pageurl=str_replace("{tid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='union_uc'){//union_uc-{pagetype}.html
		$pageurl=$union_uc.$union_uc1;
		
		$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='union_wap'){//union_wap-{pagetype}-{cid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$union_wap.$union_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid}","",$pageurl);
		}else{
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
			}else{
				$pageurl=str_replace("-{cid}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_union_getpluginstate($plugin){
	if($plugin=='it618_union')return true;
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/'.$plugin.'/ajax.inc.php')){
		return true;
	}else{
		return false;
	}
}

function it618_union_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);

	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_union_gbktoutf($strcontent);
	}
}

function it618_union_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

/**
 * @param array  ����,����ͼƬ������
 * @param string  $filename ���ɺ����ļ���,�����˲����������ļ�,ֱ�����ͼƬ
 * @return [type] [description]
 */
function it618_union_createPoster($config=array(),$filename=""){
  //���Ҫ����ʲô����������ע�͵����header
  if(empty($filename)) header("content-type: image/png");
  mb_internal_encoding("UTF-8");
  $imageDefault = array(
    'left'=>0,
    'top'=>0,
    'right'=>0,
    'bottom'=>0,
    'width'=>100,
    'height'=>100,
    'opacity'=>100
  );
  $textDefault = array(
    'text'=>'',
    'left'=>0,
    'top'=>0,
    'fontSize'=>32,       //�ֺ�
    'fontColor'=>'255,255,255', //������ɫ
    'angle'=>0,
  );
  $background = $config['bg_url'];//������ײ�ñ���
  //��������
  $backgroundInfo = getimagesize($background);
  $backgroundFun = 'imagecreatefrom'.image_type_to_extension($backgroundInfo[2], false);
  $background = $backgroundFun($background);
  $backgroundWidth = imagesx($background);  //��������
  $backgroundHeight = imagesy($background);  //�����߶�
  $txtbackgroundWidth = 268;  //��������
  $txtbackgroundHeight = 80;  //�����߶�
  $imageRes = imageCreatetruecolor($backgroundWidth,$backgroundHeight);
  $color = imagecolorallocate($imageRes, 0, 0, 0);
  imagefill($imageRes, 0, 0, $color);
  // imageColorTransparent($imageRes, $color);  //��ɫ͸��
  imagecopyresampled($imageRes,$background,0,0,0,0,imagesx($background),imagesy($background),imagesx($background),imagesy($background));
  //������ͼƬ
  if(!empty($config['image'])){
    foreach ($config['image'] as $key => $val) {
      $val = array_merge($imageDefault,$val);
      $info = getimagesize($val['url']);
      $function = 'imagecreatefrom'.image_type_to_extension($info[2], false);
      if($val['stream']){   //����������ַ���ͼ����
        $info = getimagesizefromstring($val['url']);
        $function = 'imagecreatefromstring';
      }
      $res = $function($val['url']);
      $resWidth = $info[0];
      $resHeight = $info[1];
      //�������� ������ͼƬ��ָ���ߴ�
      $canvas=imagecreatetruecolor($val['width'], $val['height']);
      imagefill($canvas, 0, 0, $color);
      //�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h��
      imagecopyresampled($canvas, $res, 0, 0, 0, 0, $val['width'], $val['height'],$resWidth,$resHeight);
      $val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']) - $val['width']:$val['left'];
      $val['top'] = $val['top']<0?$backgroundHeight- abs($val['top']) - $val['height']:$val['top'];
      //����ͼ��
      imagecopymerge($imageRes,$canvas, $val['left'],$val['top'],$val['right'],$val['bottom'],$val['width'],$val['height'],$val['opacity']);//���ϣ��ң��£����ȣ��߶ȣ�͸����
    }
  }
  //��������
  if(!empty($config['text'])){
    foreach ($config['text'] as $key => $val) {
      $val = array_merge($textDefault,$val);
      list($R,$G,$B) = explode(',', $val['fontColor']);
      $fontColor = imagecolorallocate($imageRes, $R, $G, $B);
      $val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']):$val['left'];
      $val['top'] = $val['top']<0?$backgroundHeight- abs($val['top']):$val['top'];
	  
	  unset($letter);$content='';
	  for ($i=0;$i<mb_strlen($val['text']);$i++) {
		  $letter[] = mb_substr($val['text'], $i, 1);
	  }
	  
	  foreach ($letter as $l) {
		  $teststr = $content." ".$l;
		  $fontBox = imagettfbbox($val['fontSize'], 0, $val['fontPath'], $teststr);
		  if (($fontBox[2] > $val['width']) && ($content !== "")) {
			  $content .= "\n";
		  }
		  $content .= $l;
	  }
	  
	  $content=mb_convert_encoding($content, "html-entities", "utf-8");
	  
      imagettftext($imageRes,$val['fontSize'],$val['angle'],$val['left'],$val['top'],$fontColor,$val['fontPath'],$content);
    }
  }
  //����ͼƬ
  if(!empty($filename)){
    $res = imagejpeg ($imageRes,$filename,90); //���浽����
    imagedestroy($imageRes);
    if(!$res) return false;
    return $filename;
  }else{
    imagepng ($imageRes);     //�����������ʾ
    imagedestroy($imageRes);
  }
}

function it618_union_getsharecodetxtimg($it618_union_sharecode,$dataid){
	global $_G,$it618_union,$IsWxMini;
	
	$userimgsrc='';$uname='';$uid='';
	if($_GET['shareurl']!=''){
		$shareurl=urldecode($_GET['shareurl']);
		$tmparr=explode('tuiuid=',$shareurl);
		if(count($tmparr)>1){
			$tmparr=explode('&',$tmparr[1]);
			$uid=$tmparr[0];
		}
		if($uid==0){
			$uid=$_GET['uid'];
		}
	}
	if($uid==0){
		if($_G['uid']>0){
			$userimgsrc=it618_union_discuz_uc_avatar($_G['uid'],'middle');
			$uname=$_G['username'];
			$uid=$_G['uid'];
		}
	}else{
		$userimgsrc=it618_union_discuz_uc_avatar($uid,'middle');
		$uname=it618_union_getusername($uid);	
	}
	
	$cid=$it618_union_sharecode['it618_cid'];
	$class=$it618_union_sharecode['it618_class'];
	$type=$it618_union_sharecode['it618_type'];
	$content=$it618_union_sharecode['it618_content'];
	$length=$it618_union_sharecode['it618_length'];
	$img=$it618_union_sharecode['it618_img'];
	
	if($cid==1){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php';
		}
		
		if($type=='txt'){
			if($uid>0)$content=str_replace("{uid}",it618_union_getsmsstr($uid,$length),$content);
			if($uid>0)$content=str_replace("{uname}",it618_union_getsmsstr($uname,$length),$content);
			$content=str_replace("{title}",$share_name,$content);
			$content=str_replace("{about}",$share_des,$content);
			return it618_union_gbktoutf($content);
		}
		
		if($type=='img'){
			$tmparr=explode('://',$share_img);
			if(count($tmparr)==1)$share_img=$_G['siteurl'].$share_img;
			
			if($_GET['shareurl']!=''){
				$tmpurl=$_GET['shareurl'];
			}else{
				$tmpurl=$_G['siteurl'].it618_union_getrewrite('union_yq',$_G['uid'],'plugin.php?id=it618_union:union&tuiuid='.$_G['uid']);
			}
			
			$qrcodesrc=$_G['siteurl'].'plugin.php?id=it618_union:urlcode&url='.urlencode($tmpurl);

			$img=str_replace("{imgsrc}",$share_img,$img);
			$img=str_replace("{codeimgsrc}",$qrcodesrc,$img);
			if($uid>0)$img=str_replace("{userimgsrc}",$userimgsrc,$img);
			return $img;
		}
	}else{
		if($cid==2){
			$it618_plugin='it618_video';
			$it618_shop_tablename='it618_video_shop';
			$it618_shop_tableorder='it618_views';
			$it618_product_tablename='it618_video_goods';
			
		}
		if($cid==3){
			$it618_plugin='it618_exam';
			$it618_shop_tablename='it618_exam_shop';
			$it618_shop_tableorder='it618_views';
			$it618_product_tablename='it618_exam_goods';
			
		}
		if($cid==4){
			$it618_plugin='it618_brand';
			$it618_shop_tablename='it618_brand_brand';
			$it618_shop_tableorder='it618_levelsum';
			$it618_product_tablename='it618_brand_goods';
		}
		if($cid==5){
			$it618_plugin='it618_tuan';
			$it618_shop_tablename='it618_tuan_shop';
			$it618_shop_tableorder='it618_money';
			$it618_product_tablename='it618_tuan_goods';
		}
		if($cid==6){
			$it618_plugin='it618_waimai';
			$it618_shop_tablename='it618_waimai_waimai';
			$it618_shop_tableorder='it618_views';
		}
		if($cid==7){
			$it618_plugin='it618_sale';
			$it618_product_tablename='it618_sale_goods';
		}
		if($cid==8){
			$it618_plugin='it618_group';
			$it618_product_tablename='it618_group_goods';
			
		}
		
		if($class=='shop'){
			if($dataid>0){
				$it618_shop = C::t('#'.$it618_plugin.'#'.$it618_shop_tablename.'')->fetch_by_id($dataid);
			}else{
				$it618_shop = DB::fetch_first("SELECT * FROM ".DB::table($it618_shop_tablename)." order by $it618_shop_tableorder desc");
			}
		
			if($type=='txt'){
				$it618_name=$it618_shop['it618_name'];
				$it618_about=$it618_shop['it618_about'];
				$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
				
				if($uid>0)$content=str_replace("{uid}",it618_union_getsmsstr($uid,$length),$content);
				if($uid>0)$content=str_replace("{uname}",it618_union_getsmsstr($uname,$length),$content);
				$content=str_replace("{shopname}",$it618_name,$content);
				$content=str_replace("{shopabout}",$it618_about,$content);
				$content=str_replace("{shopaddr}",$it618_shop['it618_addr'],$content);
				$content=str_replace("{shoptel}",$it618_shop['it618_tel'],$content);
				return it618_union_gbktoutf($content);
			}
			
			if($type=='img'){
				$it618_img=$it618_shop['it618_logo'];
				$tmparr=explode('://',$it618_img);
				if(count($tmparr)==1)$it618_img=$_G['siteurl'].$it618_img;
				
				if($_GET['shareurl']!=''){
					$tmpurl=$_GET['shareurl'];
				}else{
					if($_GET['wap']==1){
						if($it618_plugin=='it618_video')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_video','video_wap','lecturer@'.$it618_shop['id'],'plugin.php?id=it618_video:wap&pagetype=lecturer&cid='.$it618_shop['id']);
						
						if($it618_plugin=='it618_exam')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_exam','exam_wap','teacher@'.$it618_shop['id'],'plugin.php?id=it618_exam:wap&pagetype=teacher&cid='.$it618_shop['id']);
						
						if($it618_plugin=='it618_brand')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_brand','brand_wap','shop@'.$it618_shop['id'],'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$it618_shop['id']);
						
						if($it618_plugin=='it618_tuan')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_tuan','tuan_wap','shop@'.$it618_shop['id'],'plugin.php?id=it618_tuan:wap&pagetype=shop&cid='.$it618_shop['id']);
						
						if($it618_plugin=='it618_waimai')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_waimai','waimai_wap','shop@'.$it618_shop['id'],'plugin.php?id=it618_waimai:wap&pagetype=shop&sid='.$it618_shop['id']);
						
					}else{
						if($it618_plugin=='it618_video')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_video','video_lecturer',$it618_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_shop['id']);
						
						if($it618_plugin=='it618_exam')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_exam','exam_teacher',$it618_shop['id'],'plugin.php?id=it618_exam:teacher&lid='.$it618_shop['id']);
						
						if($it618_plugin=='it618_brand')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_brand','shop_home',$it618_shop['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_shop['id']);
						
						if($it618_plugin=='it618_tuan')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_tuan','tuan_shop',$it618_shop['id'],'plugin.php?id=it618_tuan:shop&sid='.$it618_shop['id']);
						
						if($it618_plugin=='it618_waimai')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_waimai','shop_home',$it618_shop['id'],'plugin.php?id=it618_waimai:shop&sid='.$it618_shop['id']);
					}
				}
				
				$qrcodesrc=$_G['siteurl'].'plugin.php?id='.$it618_plugin.':urlcode&url='.urlencode($tmpurl);
				
				$img=str_replace("{logosrc}",$it618_img,$img);
				$img=str_replace("{codeimgsrc}",$qrcodesrc,$img);
				if($uid>0)$img=str_replace("{userimgsrc}",$userimgsrc,$img);
				return $img;
			}
		}
		
		if($class=='product'||$class=='tui'){
			if($dataid>0){
				$it618_product = C::t('#'.$it618_plugin.'#'.$it618_product_tablename.'')->fetch_by_id($dataid);
			}else{
				$it618_product = DB::fetch_first("SELECT * FROM ".DB::table($it618_product_tablename)." order by it618_views desc");
			}
		
			if($type=='txt'){
				$it618_name=$it618_product['it618_name'];
				$it618_about=$it618_product['it618_description'];
				if($it618_plugin=='it618_sale')$it618_about=$it618_about.' '.$it618_product['it618_quanstr'];
				if($it618_about=='')$it618_about=$it618_product['it618_seodescription'];
				
				if($it618_plugin=='it618_group'){
					$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_product['it618_groupid']);
					$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_product['it618_groupid']);
					$it618_unit=it618_union_getvipgoodsunit($it618_product);
					$it618_name=$grouptitle.' '.$it618_unit;
					$it618_about=$it618_group_group['it618_power'];
				}
				
				$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
				
				if($uid>0)$content=str_replace("{uid}",it618_union_getsmsstr($uid,$length),$content);
				if($uid>0)$content=str_replace("{uname}",it618_union_getsmsstr($uname,$length),$content);
				$content=str_replace("{pname}",it618_union_getsmsstr($it618_name,$length),$content);
				$content=str_replace("{pabout}",it618_union_getsmsstr($it618_about,$length),$content);
				$content=str_replace("{pprice}",it618_union_getgoodsprice_plugin($it618_plugin,$it618_product,'sharecode'),$content);

				return it618_union_gbktoutf($content);
			}
			
			if($type=='img'){
				if($it618_plugin=='it618_sale'){
					$it618_img=$it618_product['it618_pic'];
				}else{
					$it618_img=it618_union_getgoodspic_plugin($it618_plugin,$it618_product['it618_shopid'],$it618_product['id'],$it618_product['it618_picbig']);
				}
				$tmparr=explode('://',$it618_img);
				if(count($tmparr)==1)$it618_img=$_G['siteurl'].$it618_img;
				
				if($_GET['shareurl']!=''){
					$tmpurl=$_GET['shareurl'];
				}else{
					if($_GET['wap']==1){
						if($it618_plugin=='it618_video')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_video','video_wap','product@'.$it618_product['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_product['id']);
						
						if($it618_plugin=='it618_exam')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_exam','exam_wap','product@'.$it618_product['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_product['id']);
						
						if($it618_plugin=='it618_group')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_group','group_wap','product@'.$it618_product['id'],'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$it618_product['id']);
						
						if($it618_plugin=='it618_brand')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_brand','brand_wap','product@'.$it618_product['it618_shopid'].'@0@'.$it618_product['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_product['it618_shopid'].'&cid='.$it618_product['id']);
						
						if($it618_plugin=='it618_tuan')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_tuan','tuan_wap','product@'.$it618_product['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_product['id']);
						
						if($it618_plugin=='it618_sale')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_sale','sale_wap','product@'.$it618_product['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_product['id']);
					}else{
						if($it618_plugin=='it618_video')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_video','video_product',$it618_product['id'],'plugin.php?id=it618_video:product&pid='.$it618_product['id']);
						
						if($it618_plugin=='it618_exam')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_exam','exam_product',$it618_product['id'],'plugin.php?id=it618_exam:product&pid='.$it618_product['id']);
						
						if($it618_plugin=='it618_group')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_group','group_product',$it618_product['id'],'plugin.php?id=it618_group:product&pid='.$it618_product['id']);
						
						if($it618_plugin=='it618_brand')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_brand','shop_product',$it618_product['it618_shopid'].'@'.$it618_product['id'],'plugin.php?id=it618_brand:product&sid='.$it618_product['it618_shopid'].'&pid='.$it618_product['id']);
						
						if($it618_plugin=='it618_tuan')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_tuan','tuan_product',$it618_product['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_product['id']);
						
						if($it618_plugin=='it618_sale')$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_sale','sale_product',$it618_product['id'],'plugin.php?id=it618_sale:product&pid='.$it618_product['id']);
					}
				}
				
				$qrcodesrc=$_G['siteurl'].'plugin.php?id='.$it618_plugin.':urlcode&url='.urlencode($tmpurl);

				$img=str_replace("{pimgsrc}",$it618_img,$img);
				$img=str_replace("{codeimgsrc}",$qrcodesrc,$img);
				if($uid>0)$img=str_replace("{userimgsrc}",$userimgsrc,$img);

				return $img;
			}
		}
	}
}

function it618_union_getsmsstr($strtmp,$length){
	if($length>0){
		return cutstr($strtmp,$length,'...');
	}
	return $strtmp;
}

function it618_union_colorhex2rgb($hexColor) {
	$color = str_replace('#', '', $hexColor);
	if (strlen($color) > 3) {
		$rgb = array(
			'r' => hexdec(substr($color, 0, 2)),
			'g' => hexdec(substr($color, 2, 2)),
			'b' => hexdec(substr($color, 4, 2))
		);
	} else {
		$color = $hexColor;
		$r = substr($color, 0, 1) . substr($color, 0, 1);
		$g = substr($color, 1, 1) . substr($color, 1, 1);
		$b = substr($color, 2, 1) . substr($color, 2, 1);
		$rgb = array(
			'r' => hexdec($r),
			'g' => hexdec($g),
			'b' => hexdec($b)
		);
	}

	return $rgb['r'].','.$rgb['g'].','.$rgb['b'];
}

function it618_union_getusername($uid){
	return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".intval($uid));
}

function it618_union_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_union_getlang('s342');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_union_getlang('s343');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_union_getlang('s344');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_union_getlang('s345');
		}
	}
	
	return $timestr;
}

function it618_union_gettime1($it618_time){
	global $_G;
	$timecount=intval(($it618_time-$_G['timestamp'])/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_union_getlang('s312');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_union_getlang('s313');
	}else{
		$timecount=intval(($it618_time-$_G['timestamp'])/60);
		if($timecount>=1){
			$timestr=$timecount.it618_union_getlang('s314');
		}else{
			$timecount=intval(($it618_time-$_G['timestamp']));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_union_getlang('s315');
		}
	}
	
	return $timestr;
}

function it618_union_getonlinestate($it618_uid){
	if(TIMESTAMP-C::t('#it618_union#it618_union_reguser')->fetch_lastactivity_by_uid($it618_uid)<=900){
		$tmponlineico='<img src="source/plugin/it618_union/images/online.gif" align="absmiddle"/>';
	}else{
		$tmponlineico='<img src="source/plugin/it618_union/images/offline.gif" align="absmiddle"/>';
	}
	
	return $tmponlineico;
}

function it618_union_getwapppic($aid,$get_it618_picbig,$type=1){
	$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
	$it618_smallurl='source/plugin/it618_union/kindeditor/data/smallimage/wapad'.$aid.'.'.$file_ext;
	
	if($type==1){
		if(!file_exists($it618_smallurl))$flag=1;
	}else{
		$flag=1;
	}
	if($flag==1) {
			
		$smallpath=DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/data/smallimage/';
		if(!file_exists($smallpath)) {
			mkdir($smallpath);
		}
	
		$tmparr1=explode("://",$get_it618_picbig);
		if(count($tmparr1)>1){
			$it618_url=$get_it618_picbig;
		}else{
			$tmparr=explode("source",$get_it618_picbig);
			$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
		}
		
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/data/smallimage/wapad'.$aid.'.'.$file_ext;
		it618_union_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,280);
	}
	
	return $it618_smallurl;
}

function it618_union_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height,$type=1){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function it618_union_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_union_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_union']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function union_qrcode($url,$plugin='it618_union'){
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/'.$plugin.'/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		include DISCUZ_ROOT.'./source/plugin/it618_union/phpqrcode.php';
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function union_is_mobile(){ 
	global $_GET;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
?>