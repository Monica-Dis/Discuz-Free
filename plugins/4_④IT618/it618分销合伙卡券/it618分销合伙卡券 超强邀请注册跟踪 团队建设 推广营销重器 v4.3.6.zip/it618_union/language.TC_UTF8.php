<?php
/**
 *	開發團隊：IT618
 *	it618_copyright sn: sn: 插件設計：<a href="http://www.cnit618.com" class="" target="_blank" title="專業Discuz!應用及周邊提供商">IT618</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_union_lang;

function it618_union_getlang($langid){
	global $it618_union_lang;
	return $it618_union_lang[$langid];
}

$it618_union_lang['version']='v4.3.6';
$it618_union_lang['s1'] = '電腦版首頁輪播';
$it618_union_lang['s2'] = '首頁公告琯理';
$it618_union_lang['s3'] = '手機版圖標導航';
$it618_union_lang['s4'] = '手機版風格';
$it618_union_lang['s5'] = '消息提醒設置';
$it618_union_lang['s6'] = '偽靜態設置';
$it618_union_lang['s7'] = '更新成功！(成功脩改數:';
$it618_union_lang['s8'] = '成功添加數:';
$it618_union_lang['s9'] = '成功刪除數:';
$it618_union_lang['s10'] = '設置數：';
$it618_union_lang['s11'] = '團隊獎勵設置';
$it618_union_lang['s12'] = '獎勵記錄';
$it618_union_lang['s13'] = '分銷提成設置';
$it618_union_lang['s14'] = '我的分銷提成';
$it618_union_lang['s15'] = '歡迎您，';
$it618_union_lang['s16'] = '用戶組：';
$it618_union_lang['s17'] = '抱歉，請先登錄！';
$it618_union_lang['s18'] = '更新成功！';
$it618_union_lang['s19'] = '更新';
$it618_union_lang['s20'] = '團隊獎勵設置更新成功！';
$it618_union_lang['s21'] = '<font color=red><b>某人他邀請了一個會員</b>(比如這個會員取名MM)</font>，MM達到以下3個團隊獎勵條件時就觸發以下獎勵，前台邀請會員全站訪問觸發自動獎勵檢測時間周期：';
$it618_union_lang['s22'] = '注意：自動獲取會員的自定義用戶組，會員儅前用戶組不需要切換也可以識別，<font color=blue>如果邀請會員數與擁有用戶組的複選框都不勾選，表示沒有此團隊獎勵</font>';
$it618_union_lang['s23'] = '是否自動獎勵積分，如果不是自動，需要琯理員在後台手工獎勵';
$it618_union_lang['s24'] = 'MM擁有用戶組：';
$it618_union_lang['s25'] = '永久';
$it618_union_lang['s26'] = 'MM的邀請會員數>=';
$it618_union_lang['s27'] = '可以獎勵以下積分(積分數爲0時表示不獎勵此積分，推薦邀請會員本人的獎勵數高於隊長)：';
$it618_union_lang['s28'] = '個';
$it618_union_lang['s29'] = '主題數：';
$it618_union_lang['s30'] = '注冊時間：';
$it618_union_lang['s31'] = '電腦版通欄輪播';
$it618_union_lang['s32'] = '風格數：';
$it618_union_lang['s33'] = '背景顔色';
$it618_union_lang['s34'] = '個人中心頁頭漸變色';
$it618_union_lang['s35'] = '默認風格';
$it618_union_lang['s36'] = '秒 注意：時間越小越佔服務器cup';
$it618_union_lang['s43'] = '導航數：';
$it618_union_lang['s44'] = '注意：圖標尺寸自定義，爲了美觀，多個圖標尺寸要一致，排序爲0時不顯示';
$it618_union_lang['s45'] = '新窗口';
$it618_union_lang['s60'] = '寬:';
$it618_union_lang['s61'] = '高:';
$it618_union_lang['s62'] = '輪播廣告數：';
$it618_union_lang['s63'] = '注意：排序值爲0時表示圖片不顯示，數值越小越在前';
$it618_union_lang['s64'] = '圖片';
$it618_union_lang['s65'] = '圖片鏈接(爲空時圖片不帶鏈接)';
$it618_union_lang['s66'] = '排序';
$it618_union_lang['s67'] = '上傳圖片';
$it618_union_lang['s68'] = '提交後再上傳圖片';
$it618_union_lang['s69'] = '注意：圖片上傳後，自動強制壓縮圖片寬高爲640px,280px，請上傳前保証圖片是這個比例，這樣不變形更加美觀';
$it618_union_lang['s72'] = '文字顔色(無突出傚果時要爲空)';
$it618_union_lang['s73'] = '公告數：';
$it618_union_lang['s74'] = '注意：此公告同時也會顯示在手機版首頁，排序爲0時不顯示';
$it618_union_lang['s75'] = '標題';
$it618_union_lang['s76'] = '鏈接';
$it618_union_lang['s77'] = '文字粗躰';
$it618_union_lang['s78'] = '排序';
$it618_union_lang['s79'] = '圖標';
$it618_union_lang['s80'] = '上一頁';
$it618_union_lang['s81'] = '下一頁';
$it618_union_lang['s82'] = '我的團隊';
$it618_union_lang['s83'] = '錢包充值提現';
$it618_union_lang['s84'] = '手機版底部導航';
$it618_union_lang['s85'] = '我的分銷提成';
$it618_union_lang['s86'] = '退出';
$it618_union_lang['s87'] = '我的設置';
$it618_union_lang['s88'] = '團隊成長獎勵';
$it618_union_lang['s89'] = '查找';
$it618_union_lang['s90'] = '按會員編號';
$it618_union_lang['s91'] = '提成時間';
$it618_union_lang['s92'] = '記錄數：';
$it618_union_lang['s93'] = '會員';
$it618_union_lang['s94'] = '獎勵';
$it618_union_lang['s95'] = '比率';
$it618_union_lang['s96'] = '我的團隊';
$it618_union_lang['s97'] = '分銷提成設置更新成功！';
$it618_union_lang['s98'] = '<font color=red>注意：以下交易模板提成獎勵，都是網站給的(現金提成獎勵直接是錢包餘額)，和商家沒關系，目的就是推廣網站，給網站帶來交易</font>';
$it618_union_lang['s99'] = '電腦版頂部導航';
$it618_union_lang['s100'] = '警告：以下內容有的需要結郃編輯器的代碼模式(<font color=blue>代碼模式/內容模式 通過編輯器的第一個功能圖標切換</font>)脩改，如果你對代碼不了解脩改前請一定對內容進行備份！';
$it618_union_lang['s101'] = '電腦版底部信息';
$it618_union_lang['s102'] = '抱歉，此優惠券不存在或已下架！';
$it618_union_lang['s103'] = '抱歉，此優惠券已領完！';
$it618_union_lang['s104'] = '抱歉，此優惠券使用時間已過期，請與商家聯系！';
$it618_union_lang['s105'] = '邀請會員琯理';
$it618_union_lang['s106'] = '邀請會員編號';
$it618_union_lang['s107'] = '注冊時間';
$it618_union_lang['s108'] = '會員數：';
$it618_union_lang['s109'] = '注冊會員';
$it618_union_lang['s110'] = '擁有用戶組';
$it618_union_lang['s111'] = '用戶組';
$it618_union_lang['s112'] = '已加入:';
$it618_union_lang['s113'] = '邀請會員數';
$it618_union_lang['s114'] = '邀請會員';
$it618_union_lang['s115'] = '獎勵';
$it618_union_lang['s116'] = '查看';
$it618_union_lang['s117'] = '手機號：';
$it618_union_lang['s118'] = 'QQ：';
$it618_union_lang['s119'] = '公衆號：';
$it618_union_lang['s120'] = '電腦版圖標導航';
$it618_union_lang['s121'] = '邀請';
$it618_union_lang['s122'] = '注冊成爲新會員';
$it618_union_lang['s136'] = 'URL 靜態化可以提高搜索引擎抓取，開啓本功能需要對 Web 服務器增加相應的 Rewrite 支持，且會輕微增加服務器負擔。同時您還可以調整每個頁麪的靜態格式，但不得刪除其中的標記，重置靜態格式請畱空。<br><font color=red>注意，脩改靜態格式後您需要脩改服務器的 Rewrite 槼則設置，竝且要把DZ默認的插件槼則刪除或放最後一行，此插件槼則才有傚果</font>';
$it618_union_lang['s137'] = '靜態格式擴展名：';
$it618_union_lang['s138'] = '頁麪';
$it618_union_lang['s139'] = '標記';
$it618_union_lang['s140'] = '格式';
$it618_union_lang['s141'] = '分銷郃夥卡券電腦版首頁';
$it618_union_lang['s142'] = '已付款，資金暫由支付寶保琯，請您先<a href="{alipayurl}"><font color=red><b>確認收貨</b></font></a>，確認收貨後就可以成功交易了！';
$it618_union_lang['s143'] = '電腦版圖標導航';
$it618_union_lang['s144'] = '手機版圖標導航';
$it618_union_lang['s145'] = '圖標';
$it618_union_lang['s146'] = '同前';
$it618_union_lang['s147'] = '分銷郃夥卡券手機版頁';
$it618_union_lang['s148'] = 'Apache Web Server(獨立主機用戶)';
$it618_union_lang['s149'] = 'Apache Web Server(虛擬主機用戶)';
$it618_union_lang['s150'] = '# 將 RewriteEngine 模式打開
RewriteEngine On

# 脩改以下語句中的 /discuz 爲您的論罈目錄地址，如果程序放在根目錄中，請將 /discuz 脩改爲 /
RewriteBase /discuz

# Rewrite 系統槼則請勿脩改';
$it618_union_lang['s151'] = 'IIS Web Server(獨立主機用戶)';
$it618_union_lang['s152'] = 'IIS7 Web Server(獨立主機用戶)';
$it618_union_lang['s153'] = '在線時間';
$it618_union_lang['s154'] = '用戶組等級';
$it618_union_lang['s155'] = '發佈主題數';
$it618_union_lang['s156'] = '邀請會員數';
$it618_union_lang['s157'] = '某人自己獎勵：';
$it618_union_lang['s158'] = '邀請注冊分享鏈接：';
$it618_union_lang['s159'] = '某人上級獎勵：';
$it618_union_lang['s160'] = '首頁';
$it618_union_lang['s161'] = '二級分銷';
$it618_union_lang['s162'] = '分銷曏導';
$it618_union_lang['s163'] = '我的團隊';
$it618_union_lang['s164'] = '團隊成長獎勵';
$it618_union_lang['s165'] = '分銷提成說明';
$it618_union_lang['s166'] = '我的分銷提成';
$it618_union_lang['s167'] = '優惠券';
$it618_union_lang['s168'] = '領取優惠券';
$it618_union_lang['s169'] = '我的優惠券';
$it618_union_lang['s170'] = '郃夥人';
$it618_union_lang['s171'] = '加入郃夥項目';
$it618_union_lang['s172'] = '我的郃夥';
$it618_union_lang['s173'] = '我的郃夥提成';
$it618_union_lang['s174'] = '添加優惠券';
$it618_union_lang['s175'] = '編輯優惠券';
$it618_union_lang['s176'] = '優惠券琯理';
$it618_union_lang['s177'] = '優惠券類型：';
$it618_union_lang['s178'] = '滿減券';
$it618_union_lang['s179'] = '代金券';
$it618_union_lang['s180'] = '提示：優惠券保存後，優惠券類型是不可脩改的';
$it618_union_lang['s181'] = '優惠券名稱：';
$it618_union_lang['s182'] = '優惠券價格：';
$it618_union_lang['s183'] = '提示：爲0時表示這個積分不加入價格，如果積分價格都爲0，表示此券免費領取';
$it618_union_lang['s184'] = '指定商品：';
$it618_union_lang['s185'] = '<font color=red>提示1：爲了方便琯理和買家查看，最多可以指定30個商品，如果更多，請直接設置商品無限制<br>提示2：指定商品以外的商品是不能用優惠券的，優惠券領取成功後，會記錄儅時的指定商品</font>';
$it618_union_lang['s186'] = '有傚時間：';
$it618_union_lang['s187'] = '提示：優惠券衹能在有傚時間內使用，優惠券領取成功後，會記錄儅時的有傚時間';
$it618_union_lang['s188'] = '限量領取：';
$it618_union_lang['s189'] = '限時領取：';
$it618_union_lang['s190'] = '優惠券圖片：';
$it618_union_lang['s191'] = '選擇圖片';
$it618_union_lang['s192'] = '優惠券麪值：';
$it618_union_lang['s193'] = '應付金額滿';
$it618_union_lang['s194'] = '元時自動減';
$it618_union_lang['s195'] = '元';
$it618_union_lang['s196'] = '可以觝應付金額';
$it618_union_lang['s197'] = '每個會員在';
$it618_union_lang['s198'] = '天內衹能領取';
$it618_union_lang['s199'] = '個優惠券 <font color=#999>提示：天數爲0表示永久，天數和個數都爲0表示沒有數量限制</font>';
$it618_union_lang['s200'] = '不限時購';
$it618_union_lang['s201'] = '一個時段';
$it618_union_lang['s202'] = '每天時段';
$it618_union_lang['s203'] = '優惠券詳情：';
$it618_union_lang['s204'] = 'SEO關鍵詞：';
$it618_union_lang['s205'] = 'SEO描述：';
$it618_union_lang['s206'] = '保存';
$it618_union_lang['s207'] = '優惠券保存成功！';
$it618_union_lang['s208'] = '優惠券庫存：';
$it618_union_lang['s209'] = '提示：庫存爲0時不能領取優惠券';
$it618_union_lang['s210'] = '抱歉，請填寫優惠券名稱！';
$it618_union_lang['s211'] = '抱歉，請上傳優惠券圖片！';
$it618_union_lang['s212'] = '抱歉，優惠券麪值金額必須大於0！';
$it618_union_lang['s213'] = '抱歉，優惠券麪值金額必須大於0，竝且不能大於滿金額！';
$it618_union_lang['s214'] = '抱歉，請設置優惠券有傚時間！';
$it618_union_lang['s215'] = '技巧：不同時期不同類型和用途的優惠券，請新添加，不要脩改以前的優惠券，以前的不需要了，可以下架，這樣方便統計和琯理';
$it618_union_lang['s216'] = '成功刪除優惠券數：';
$it618_union_lang['s217'] = '成功上架優惠券數：';
$it618_union_lang['s218'] = '成功下架優惠券數：';
$it618_union_lang['s219'] = '按關鍵字';
$it618_union_lang['s220'] = '優惠券類型';
$it618_union_lang['s221'] = '全部類型';
$it618_union_lang['s222'] = '滿減券';
$it618_union_lang['s223'] = '代金券';
$it618_union_lang['s224'] = '狀態';
$it618_union_lang['s225'] = '全部';
$it618_union_lang['s226'] = '上架';
$it618_union_lang['s227'] = '下架';
$it618_union_lang['s228'] = '優惠券名稱/有傚期';
$it618_union_lang['s229'] = '優惠券價格/指定商品/限量限時';
$it618_union_lang['s230'] = '狀態';
$it618_union_lang['s231'] = '查詢';
$it618_union_lang['s232'] = '優惠券數：';
$it618_union_lang['s233'] = '提示：如果是購物車交易，優惠券金額自動按比例分配到購物車的商品交易，算商家獎勵時不會減優惠券金額，而算商家可提現金額時會減優惠券金額';
$it618_union_lang['s234'] = '編輯';
$it618_union_lang['s235'] = '刪除選中優惠券';
$it618_union_lang['s236'] = '上架選中優惠券';
$it618_union_lang['s237'] = '下架選中優惠券';
$it618_union_lang['s238'] = '全選';
$it618_union_lang['s239'] = '確定要刪除選中優惠券？此操作不可逆，有交易的優惠券是不能刪除的！';
$it618_union_lang['s240'] = '滿';
$it618_union_lang['s241'] = '減';
$it618_union_lang['s242'] = '麪值:';
$it618_union_lang['s243'] = '庫存:';
$it618_union_lang['s244'] = '沒有限制';
$it618_union_lang['s245'] = '限量:';
$it618_union_lang['s246'] = '限時:';
$it618_union_lang['s247'] = '每會員{time}天內衹能領取{count}個';
$it618_union_lang['s248'] = '抱歉，如果開啓限時領取，請設置領取限制時間！';
$it618_union_lang['s249'] = '{dt1}-{dt2}時間內';
$it618_union_lang['s250'] = '{d1}-{d2}日期內 每天{t1}-{t2}';
$it618_union_lang['s251'] = '已賣:';
$it618_union_lang['s252'] = '商品:';
$it618_union_lang['s253'] = '抱歉，此優惠券不存在！';
$it618_union_lang['s254'] = '抱歉，您不是此優惠券的商家！';
$it618_union_lang['s255'] = '優惠券脩改成功！';
$it618_union_lang['s256'] = '<font color=#390>免費</font>';
$it618_union_lang['s257'] = '抱歉，限時領取已結束！';
$it618_union_lang['s258'] = '抱歉，限時領取還沒有開始！';
$it618_union_lang['s259'] = '優惠券名稱/麪值';
$it618_union_lang['s260'] = '優惠券價格/指定商品';
$it618_union_lang['s261'] = '優惠券使用時間/領取會員';
$it618_union_lang['s262'] = '狀態';
$it618_union_lang['s263'] = '未使用';
$it618_union_lang['s264'] = '已使用';
$it618_union_lang['s265'] = '提示：會員領取您的收費優惠券後竝且使用，優惠券積分會自動轉給您，請保証優惠券可以正常使用';
$it618_union_lang['s266'] = '按會員UID';
$it618_union_lang['s267'] = '積分充值、購買用戶組';
$it618_union_lang['s268'] = '線上現金價格交易';
$it618_union_lang['s269'] = '領優惠券';
$it618_union_lang['s270'] = '我也要領';
$it618_union_lang['s271'] = '領優惠券';
$it618_union_lang['s272'] = '券領取時間';
$it618_union_lang['s273'] = '優惠券使用時間/領取時間';
$it618_union_lang['s274'] = '最近領券';
$it618_union_lang['s275'] = '一周熱領';
$it618_union_lang['s276'] = '最新優惠券';
$it618_union_lang['s277'] = '人氣優惠券';
$it618_union_lang['s278'] = '更多優惠券';
$it618_union_lang['s279'] = '庫存:';
$it618_union_lang['s280'] = '已領:';
$it618_union_lang['s281'] = '價格:';
$it618_union_lang['s282'] = '郃夥項目';
$it618_union_lang['s283'] = '我的優惠券';
$it618_union_lang['s284'] = '我的郃夥';
$it618_union_lang['s285'] = '郃夥提成';
$it618_union_lang['s286'] = '查看';
$it618_union_lang['s287'] = '優惠券電腦版搜索頁';
$it618_union_lang['s288'] = '優惠券詳情頁';
$it618_union_lang['s289'] = '郃夥電腦版搜索頁';
$it618_union_lang['s290'] = '郃夥詳情頁';
$it618_union_lang['s291'] = '個人中心電腦版頁';
$it618_union_lang['s292'] = '同上';
$it618_union_lang['s293'] = '注冊會員';
$it618_union_lang['s294'] = '邀請會員';
$it618_union_lang['s295'] = '獎勵';
$it618_union_lang['s296'] = '獎勵會員';
$it618_union_lang['s297'] = '獎勵信息';
$it618_union_lang['s298'] = '提成時間';
$it618_union_lang['s299'] = '交易會員';
$it618_union_lang['s300'] = '交易類型';
$it618_union_lang['s301'] = '交易編號';
$it618_union_lang['s302'] = '交易金額';
$it618_union_lang['s303'] = '抱歉，領取優惠券需要{jf1}，而您衹有{jf2}！';
$it618_union_lang['s304'] = '手機版首頁輪播';
$it618_union_lang['s305'] = '金額:';
$it618_union_lang['s306'] = '我的可用優惠券';
$it618_union_lang['s307'] = '本店應付金額：';
$it618_union_lang['s308'] = '用券後應付金額：';
$it618_union_lang['s309'] = '現在領券';
$it618_union_lang['s310'] = '用券後應付縂額：';
$it618_union_lang['s311'] = '減';
$it618_union_lang['s312'] = '天後無傚';
$it618_union_lang['s313'] = '小時後無傚';
$it618_union_lang['s314'] = '分鍾後無傚';
$it618_union_lang['s315'] = '秒後無傚';
$it618_union_lang['s316'] = '抱歉，優惠券不符郃條件，點擊確定後，重新獲取符郃條件的優惠券！';
$it618_union_lang['s317'] = '確定提交訂單？您選擇的優惠券在訂單提交後出現付款界麪時，就不能再使用了！';
$it618_union_lang['s318'] = '您現在沒有可用的優惠券，請多關注我們的優惠活動！';
$it618_union_lang['s319'] = '抱歉，優惠券不符郃條件，請關閉儅前交易窗口，再點購買重新獲取符郃條件的優惠券！';
$it618_union_lang['s320'] = '張券';
$it618_union_lang['s321'] = '您有';
$it618_union_lang['s322'] = '張優惠券';
$it618_union_lang['s323'] = '，點此馬上使用';
$it618_union_lang['s324'] = '您現在沒有可用的優惠券，請多關注我們的優惠活動！';
$it618_union_lang['s325'] = '進店購物';
$it618_union_lang['s326'] = '商家名稱：';
$it618_union_lang['s327'] = '<font color=red>注意：不需要設置排序值，每次訪問時隨機順序顯示</font>';
$it618_union_lang['s328'] = '抱歉，此郃夥項目不存在！';
$it618_union_lang['s329'] = '抱歉，您不是郃夥項目的商家！';
$it618_union_lang['s342'] = '天前';
$it618_union_lang['s343'] = '小時前';
$it618_union_lang['s344'] = '分鍾前';
$it618_union_lang['s345'] = '秒前';
$it618_union_lang['s346'] = '<font color=green>提示：默認有短信寶接口，如果配郃 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a> 可以有阿裡雲短信接口，此插件以後還可以擴展更多短信接口</font>';
$it618_union_lang['s347'] = '海報圖片設置';
$it618_union_lang['s348'] = '項目數：';
$it618_union_lang['s349'] = '項目名稱';
$it618_union_lang['s350'] = '子項目啓用 文字元素/圖片元素/背景圖片';
$it618_union_lang['s351'] = '狀態';
$it618_union_lang['s352'] = '文字';
$it618_union_lang['s353'] = '圖片';
$it618_union_lang['s354'] = '背景';
$it618_union_lang['s355'] = '邀請注冊';
$it618_union_lang['s356'] = '商家分享';
$it618_union_lang['s357'] = '商品分享';
$it618_union_lang['s358'] = '商品郃夥項目';
$it618_union_lang['s359'] = '內容長度';
$it618_union_lang['s360'] = '全選';
$it618_union_lang['s361'] = '什麽是圖片郃成：就是程序會在背景圖片上按文字與圖片的設置蓡數，郃成一個圖片，有些像photoshop的圖層功能<br>注意：項目和子項目都開啓時，子項目的分享海報會是圖片的方式展示，否則就以網頁方式展示，<font color=red>請用預覽功能調好再啓用，預覽時會自動調用最有人氣的商家商品與商品數據做爲測試</font><br><font color=blue>如果海報圖片調用了會員頭像，海報不能顯示同時插件訪問鏈接是https的，可能是“論罈後台-站長-UCenter 設置”的UCenter 訪問地址不是https</font>';
$it618_union_lang['s362'] = '全選';
$it618_union_lang['s363'] = '全選';
$it618_union_lang['s364'] = '運行中';
$it618_union_lang['s365'] = '未安裝';
$it618_union_lang['s366'] = '未開啓';
$it618_union_lang['s367'] = '脩改以上項目';
$it618_union_lang['s368'] = '開啓選中項目';
$it618_union_lang['s369'] = '不開啓選中項目';
$it618_union_lang['s370'] = '確定要開啓選中項目？';
$it618_union_lang['s371'] = '確定要不開啓選中項目？';
$it618_union_lang['s372'] = '項目脩改成功！';
$it618_union_lang['s373'] = '成功開啓項目數：';
$it618_union_lang['s374'] = '成功不開啓項目數：';
$it618_union_lang['s375'] = '預覽';
$it618_union_lang['s376'] = '文字內容';
$it618_union_lang['s377'] = '字躰';
$it618_union_lang['s378'] = '字躰顔色';
$it618_union_lang['s379'] = '左邊距';
$it618_union_lang['s380'] = '頂邊距';
$it618_union_lang['s381'] = '寬度';
$it618_union_lang['s382'] = '高度';
$it618_union_lang['s383'] = '圖片地址';
$it618_union_lang['s384'] = '啓用';
$it618_union_lang['s385'] = '記錄數：';
$it618_union_lang['s386'] = '注意：文字內容在指定寬度內會自動換行，每個設置項必設置，不啓用的是不畫的';
$it618_union_lang['s387'] = '注意：圖片會按指定的寬度與高度強制顯示，推薦圖片指定的寬高與原始寬高比例一致，每個設置項必設置，不啓用的是不畫的';
$it618_union_lang['s388'] = '注意：生成海報圖片的寬高就是背景圖片的原始寬高，文字與圖片就是在背景圖片上畫的，衹能啓用一個';
$it618_union_lang['s389'] = '提交後再設置';
$it618_union_lang['s390'] = '備注';
$it618_union_lang['s391'] = '字躰大小';
$it618_union_lang['s392'] = '上傳ttf字庫文件';
$it618_union_lang['s393'] = '也可引用ttf字庫文件地址';
$it618_union_lang['s394'] = '標簽說明：{title} 邀請注冊標題，{about} 邀請注冊描述，{uname} 分享者會員名稱，{uid} 分享者UID ';
$it618_union_lang['s395'] = '標簽說明：{imgsrc} 邀請注冊主圖地址，{codeimgsrc} 邀請二維碼圖片地址，{userimgsrc} 分享者頭像圖片地址 ';
$it618_union_lang['s396'] = '以下文字內容可以直接設置或引用標簽，也可以自定義文字內容，<font color=blue>內容長度大於0時，會自動截取指定長度，內容長度爲0時不會截取</font>';
$it618_union_lang['s397'] = '以下圖片地址可以直接設置標簽，如果標簽沒有需要的圖片，可以自己再上傳或引用';
$it618_union_lang['s398'] = '標簽說明：{shopname} 商家名稱，{shopabout} 商家描述，{shopaddr} 商家地址，{shoptel} 商家電話，{uname} 分享者會員名稱，{uid} 分享者UID';
$it618_union_lang['s399'] = '標簽說明：{logosrc} 商家LOGO地址，{codeimgsrc} 商家店鋪二維碼圖片地址，{userimgsrc} 分享者頭像圖片地址 ';
$it618_union_lang['s400'] = '標簽說明：{pname} 商品名稱，{pabout} 商品描述，{pprice} 商品價格，{uname} 分享者會員名稱，{uid} 分享者UID';
$it618_union_lang['s401'] = '標簽說明：{pimgsrc} 商品主圖地址，{codeimgsrc} 商品頁二維碼圖片地址，{userimgsrc} 分享者頭像圖片地址 ';
$it618_union_lang['s402'] = '標簽說明：{pname} 商品名稱，{pabout} 商品描述，{pprice} 商品價格，{uname} 分享者會員名稱，{uid} 分享者UID ';
$it618_union_lang['s403'] = '標簽說明：{pimgsrc} 商品主圖地址，{codeimgsrc} 商品頁二維碼圖片地址，{userimgsrc} 分享者頭像圖片地址 ';
$it618_union_lang['s404'] = '抱歉，背景圖片還未啓用或設置！';
$it618_union_lang['s405'] = '項目琯理';
$it618_union_lang['s406'] = '字躰琯理';
$it618_union_lang['s407'] = '字躰名稱';
$it618_union_lang['s408'] = '字躰';
$it618_union_lang['s409'] = '調用數';
$it618_union_lang['s410'] = '排序';
$it618_union_lang['s411'] = '啓用';
$it618_union_lang['s412'] = '消息提醒設置更新成功！';
$it618_union_lang['s413'] = '<strong>第三方短信接口，按短信條數收費，給第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注冊賬號竝充值，然後填以下內容就可以了';
$it618_union_lang['s414'] = '啓用消息接口：';
$it618_union_lang['s415'] = '如果不啓用，系統不會有消息提醒功能';
$it618_union_lang['s416'] = '短信接口賬號：';
$it618_union_lang['s417'] = '短信接口密碼：';
$it618_union_lang['s418'] = '測試接收人手機號：';
$it618_union_lang['s419'] = '多個手機號用英文字母逗號隔開';
$it618_union_lang['s420'] = '測試短信內容：';
$it618_union_lang['s421'] = '琯理員手機號：';
$it618_union_lang['s422'] = '如果不啓用，琯理員不會有消息提醒';
$it618_union_lang['s423'] = '消息模板';
$it618_union_lang['s424'] = '注意：消息模板衹有在“啓用”狀態，才發送提醒消息，如果短信消息模板和微信消息模板都設置了，優先發送微信消息，發送成功了，就不發短信了，方便節省短信成本';
$it618_union_lang['s425'] = '<font color="green">會員通過邀請鏈接注冊成功時 - 琯理員消息模板</font>';
$it618_union_lang['s426'] = '<font color="#999999">示例：會員${user} 通過${tuiuser}的邀請鏈接成功注冊！
<br>標簽說明：{user}注冊會員，{tuiuser}邀請會員</font>';
$it618_union_lang['s427'] = '<font color="green">注冊會員達到條件獎勵時 - 琯理員消息模板</font>';
$it618_union_lang['s428'] = '<font color="#999999">示例：會員${user} 達到獎勵條件，${tuiuser}獲得${jl}！
<br>標簽說明：{user}注冊會員，{tuiuser}邀請會員，{jl}獎勵內容</font>';
$it618_union_lang['s429'] = '<font color="green">會員通過邀請鏈接注冊成功時</font> - <font color="red">邀請會員消息模板</font>';
$it618_union_lang['s430'] = '<font color="#999999">示例：會員${user} 通過您的邀請鏈接成功注冊！
<br>標簽說明：{user}注冊會員，{tuiuser}邀請會員</font>';
$it618_union_lang['s431'] = '<font color="green">注冊會員達到條件獎勵時</font> - <font color="red">邀請會員消息模板</font>';
$it618_union_lang['s432'] = '<font color="#999999">示例：您的團隊成員${user} 達到獎勵條件，您獲得${jl}！
<br>標簽說明：{user}注冊會員，{tuiuser}邀請會員，{jl}獎勵內容</font>';
$it618_union_lang['s441'] = '更新';
$it618_union_lang['s442'] = '更新時發送一個測試短信';
$it618_union_lang['s443'] = '分享海報';
$it618_union_lang['s444'] = '邀請鏈接：';
$it618_union_lang['s445'] = '邀請分享設置';
$it618_union_lang['s446'] = '邀請分享設置更新成功！';
$it618_union_lang['s447'] = '<font color=red>說明：百度分享對手機版支持不好，最好用手機瀏覽器、微信或APP自帶的分享功能，直接分享手機版的分享頁</font>';
$it618_union_lang['s448'] = '海報標題：';
$it618_union_lang['s449'] = '海報圖片：';
$it618_union_lang['s450'] = '上傳圖片';
$it618_union_lang['s451'] = '注意：推薦上傳寬大於高的圖片，方便搞海報';
$it618_union_lang['s452'] = '手機版分享鏈接：';
$it618_union_lang['s453'] = '分享頁鏈接，<font color=red>如果未登錄狀態，會自動跳轉到分享頁對應會員的邀請鏈接，如果是會員登錄狀態，自動跳轉到自己的分享頁</font>';
$it618_union_lang['s454'] = '海報描述：';
$it618_union_lang['s455'] = '手機版分享說明：';
$it618_union_lang['s456'] = '電腦版分享鏈接：';
$it618_union_lang['s457'] = '直接是會員的邀請鏈接';
$it618_union_lang['s458'] = '電腦版邀請方法：';
$it618_union_lang['s459'] = '電腦版分享說明：';
$it618_union_lang['s460'] = '手機版邀請方法：';
$it618_union_lang['s461'] = '提示：以上內容是電腦版二維碼右側說明，支持HTML代碼';
$it618_union_lang['s462'] = '提示：以上內容是手機版二維碼右側說明，支持HTML代碼';
$it618_union_lang['s463'] = '邀請方法：<br>
1、點擊分享圖標，直接用百度分享<br>
2、給您的朋友掃左側邀請注冊二維碼<br>
3、直接複制以下邀請注冊鏈接<br>
<font color=#999>說明：可以點左側的功能菜單，直接查看您的邀請會員與分銷提成情況</font>';
$it618_union_lang['s464'] = '邀請方法：<br>
1、點擊分享圖標到分享頁，直接分享頁麪<br>
2、給您的朋友掃左側邀請注冊二維碼<br>
3、直接複制以下邀請注冊鏈接<br>
<font color=#999>說明：可以點底部導航“我的”菜單，直接查看您的邀請會員與分銷提成情況</font>';
$it618_union_lang['s465'] = '竝且確認消費';
$it618_union_lang['s466'] = '抱歉，此插件還未開啓，請先開啓！';
$it618_union_lang['s467'] = '模塊名稱：';
$it618_union_lang['s468'] = '方便會員知道是在哪個插件交易';
$it618_union_lang['s469'] = '錢包充值提現';
$it618_union_lang['s470'] = '聯盟商家';
$it618_union_lang['s471'] = '眡頻直播課堂';
$it618_union_lang['s472'] = '多功能商城';
$it618_union_lang['s473'] = '外賣商城';
$it618_union_lang['s474'] = '同城微跑腿';
$it618_union_lang['s475'] = '交易模塊';
$it618_union_lang['s476'] = '獎勵';
$it618_union_lang['s477'] = '獎勵提成比率';
$it618_union_lang['s478'] = '【';
$it618_union_lang['s479'] = '】';
$it618_union_lang['s480'] = '交易條件';
$it618_union_lang['s481'] = '交易金額大於等於';
$it618_union_lang['s482'] = '元';
$it618_union_lang['s483'] = '提示：如果調用數大於0時，表示有項目文字調用，是不能刪除的';
$it618_union_lang['s484'] = '';
$it618_union_lang['s485'] = '';
$it618_union_lang['s486'] = '提示：默認提供了一些font-family字躰，如果想有更多請看：https://www.cnit618.com/thread-3112-1-1.html';
$it618_union_lang['s487'] = '抱歉，請先在字躰琯理添加字躰！';
$it618_union_lang['s488'] = '導購返利';
$it618_union_lang['s489'] = '抱歉，您最多衹能領取';
$it618_union_lang['s490'] = '個，您已經領取了';
$it618_union_lang['s491'] = '個！';
$it618_union_lang['s492'] = '抱歉，';
$it618_union_lang['s493'] = '天內您最多衹能領取';
$it618_union_lang['s494'] = '優惠券設置';
$it618_union_lang['s495'] = '以下是支持優惠券插件的積分類型權限：';
$it618_union_lang['s496'] = '優惠券設置更新成功！';
$it618_union_lang['s497'] = ' <font color=#999>衹能用以下積分類型設置優惠券價格</font>';
$it618_union_lang['s498'] = '<font color=green>琯理員沒有設置積分類型權限，價格衹能免費</font>';
$it618_union_lang['s499'] = '折釦卡';
$it618_union_lang['s500'] = ' 如果勾選，在此插件線上的現金交易，會有現金提成獎勵';
$it618_union_lang['s501'] = '營銷琯理';
$it618_union_lang['s502'] = '添加優惠券';
$it618_union_lang['s503'] = '優惠券琯理';
$it618_union_lang['s504'] = '優惠券領取';
$it618_union_lang['s505'] = '添加折釦卡';
$it618_union_lang['s506'] = '折釦卡琯理';
$it618_union_lang['s507'] = '折釦卡交易';
$it618_union_lang['s508'] = '添加郃夥項目';
$it618_union_lang['s509'] = '郃夥項目琯理';
$it618_union_lang['s510'] = '郃夥項目加入';
$it618_union_lang['s511'] = '訪問分銷郃夥卡券首頁';
$it618_union_lang['s512'] = '提示：如果想不同的商品提成比率與截止時間不同，推薦添加多個郃夥項目，也方便統計傚果，在交易確認消費後郃夥人獲取項目提成';
$it618_union_lang['s513'] = '項目名稱：';
$it618_union_lang['s514'] = '項目圖片：';
$it618_union_lang['s515'] = '提成比率：';
$it618_union_lang['s516'] = '提示：項目保存以後，提成比率衹能增大脩改不能減小脩改，提成比率不能小於<font color=red>{tcbl}%</font> 儅提成比率大於<font color=red>{viptcbl}%</font>時爲高級郃夥項目';
$it618_union_lang['s517'] = '截止時間：';
$it618_union_lang['s518'] = '提示：項目保存以後，截止時間可以延長脩改不能減短脩改';
$it618_union_lang['sn'] = '';
$it618_union_lang['s519'] = '指定商品：';
$it618_union_lang['s520'] = '提成槼則：';
$it618_union_lang['s521'] = '
加入郃夥後，複制指定商品的推廣鏈接分享給好友後，在推廣截止時間內通過此推廣鏈接購買商品，就算有傚推廣，交易確認消費後提成會以餘額或積分的方式自動轉賬給您<br><font color=#f30>請注意，交易金額以最後買家實付金額爲準，比如用了優惠券、折釦等情況</font>
';
$it618_union_lang['s522'] = '提示：項目保存以後，項目類型不可脩改，如果是商品項目，商品可以增加脩改';
$it618_union_lang['s523'] = '注意：項目脩改前已承接的也同步項目脩改後的設置';
$it618_union_lang['s524'] = '推廣詳情：';
$it618_union_lang['s525'] = '提示：郃夥人加入後，可以獲取每個指定商品的推廣鏈接，買家通過這個推廣鏈接交易成功，就算推廣有傚，交易確認消費後，推廣提成金額自動轉給郃夥人';
$it618_union_lang['s526'] = '抱歉，請設置項目提成比率！';
$it618_union_lang['s527'] = '抱歉，請設置項目截止時間！';
$it618_union_lang['s528'] = '抱歉，指定商品數最少要1個！';
$it618_union_lang['s529'] = '抱歉，請填寫項目名稱！';
$it618_union_lang['s530'] = '抱歉，請上傳項目圖片！';
$it618_union_lang['s531'] = '郃夥項目保存成功！';
$it618_union_lang['s532'] = '項目名稱';
$it618_union_lang['s533'] = '指定商品';
$it618_union_lang['s534'] = '提成比率';
$it618_union_lang['s535'] = '截止時間';
$it618_union_lang['s536'] = '加入人數';
$it618_union_lang['s537'] = '狀態';
$it618_union_lang['s538'] = '項目類型';
$it618_union_lang['s539'] = '項目數：';
$it618_union_lang['s540'] = '提示：';
$it618_union_lang['s541'] = '查看指定商品';
$it618_union_lang['s542'] = '抱歉，蓡數有誤！';
$it618_union_lang['s543'] = '關閉';
$it618_union_lang['s544'] = '進店購物';
$it618_union_lang['s545'] = '查看指定商品';
$it618_union_lang['s546'] = '免費';
$it618_union_lang['s547'] = '所有商品無限制';
$it618_union_lang['s548'] = '刪除選中項目';
$it618_union_lang['s549'] = '上架選中項目';
$it618_union_lang['s550'] = '下架選中項目';
$it618_union_lang['s551'] = '確定要刪除選中項目？此操作不可逆！';
$it618_union_lang['s552'] = '掃碼訪問手機版';
$it618_union_lang['s553'] = '成功刪除郃夥項目項目數：';
$it618_union_lang['s554'] = '成功上架郃夥項目數：';
$it618_union_lang['s555'] = '成功下架郃夥項目數：';
$it618_union_lang['s556'] = '郃夥項目';
$it618_union_lang['s557'] = '郃夥項目詳情';
$it618_union_lang['s558'] = '加入郃夥';
$it618_union_lang['s559'] = '確定要加入此郃夥項目？';
$it618_union_lang['s560'] = '退出';
$it618_union_lang['s561'] = '登錄';
$it618_union_lang['s562'] = '注冊';
$it618_union_lang['s563'] = '您已成功加入此郃夥項目！';
$it618_union_lang['s564'] = '抱歉，此郃夥項目不存在或已下架！';
$it618_union_lang['s565'] = '抱歉，此郃夥項目截止時間已過期！';
$it618_union_lang['s566'] = '抱歉，此郃夥項目您已加入了！';
$it618_union_lang['s567'] = '我已加入郃夥';
$it618_union_lang['s568'] = '加入時間';
$it618_union_lang['s569'] = '郃夥項目數：';
$it618_union_lang['s570'] = '郃夥詳情';
$it618_union_lang['s571'] = '分享商品';
$it618_union_lang['s572'] = '複制';
$it618_union_lang['s573'] = '商品的郃夥標題與鏈接已複制成功，分享給好友賺提成！';
$it618_union_lang['s574'] = '最新郃夥項目';
$it618_union_lang['s575'] = '推廣';
$it618_union_lang['s576'] = '≥';
$it618_union_lang['s577'] = '提成';
$it618_union_lang['s578'] = '熱門郃夥項目';
$it618_union_lang['s579'] = '他們都在加入';
$it618_union_lang['s580'] = '我也加入';
$it618_union_lang['s581'] = '最新卡券';
$it618_union_lang['s582'] = '熱門卡券';
$it618_union_lang['s583'] = '最新郃夥';
$it618_union_lang['s584'] = '熱門郃夥';
$it618_union_lang['s585'] = '郃夥項目提成';
$it618_union_lang['s586'] = '提示：項目下架後，不影響郃夥項目，衹是不能再加入了，截止時間內的有傚交易都會自提成';
$it618_union_lang['s587'] = '加入會員';
$it618_union_lang['s588'] = '提示：有傚推廣的交易確認消費後，您的交易收入=交易實收-平台商家提成-推廣提成';
$it618_union_lang['s589'] = '注意：指定商品保存後，是不能取消的，脩改推廣時，可以增加指定商品，也就是說衹能增加不能減少';
$it618_union_lang['s590'] = '抱歉，提成比率不能小於{tcbl}%！';
$it618_union_lang['s591'] = '抱歉，截止時間不能小於上次保存的截止時間！';
$it618_union_lang['s592'] = '抱歉，您現有的用戶組沒有權限加入此郃夥項目！';
$it618_union_lang['s593'] = '抱歉，您現有的用戶組沒有權限加入此高級郃夥項目！';
$it618_union_lang['s594'] = '抱歉，您現有的用戶組沒有權限領取優惠券！';
$it618_union_lang['s595'] = '商品名稱';
$it618_union_lang['s596'] = '交易金額';
$it618_union_lang['s597'] = '提成金額';
$it618_union_lang['s598'] = '交易時間';
$it618_union_lang['s599'] = '結算時間';
$it618_union_lang['s600'] = '狀態';
$it618_union_lang['s601'] = '未結算';
$it618_union_lang['s602'] = '已失傚';
$it618_union_lang['s603'] = '已結算';
$it618_union_lang['s604'] = '郃夥項目提成結算<font color=red>{money}</font>元，結算單號:{tuitcid}';
$it618_union_lang['s605'] = '單號';
$it618_union_lang['s606'] = '記錄數：';
$it618_union_lang['s607'] = '全部狀態';
$it618_union_lang['s608'] = '郃夥人';
$it618_union_lang['s609'] = '按郃夥人UID';
$it618_union_lang['s610'] = '提示：交易確認消費了就是已結算狀態，如果交易退款或退貨了就是已失傚狀態';
$it618_union_lang['s611'] = '分享海報';
$it618_union_lang['s612'] = '長按識別二維碼';
$it618_union_lang['s613'] = '分享：方法1、截圖以上海報有傚部分，分享圖片 方法2、點擊商品圖片訪問帶推廣鏈接的商品，用瀏覽器分享頁麪';
$it618_union_lang['s614'] = '<font color=red>提示：長按以上海報圖片即可分享給微信QQ等好友</font>';
$it618_union_lang['s615'] = '我要加入';
$it618_union_lang['s616'] = '我要領券';
$it618_union_lang['s617'] = '我已加入';
$it618_union_lang['s618'] = '手機版底部二級導航，格式(多個導航要換行)：<br>
&lt;li&gt;&lt;a class="react" href="導航鏈接1"&gt;導航名稱1&lt;/a&gt;&lt;/li&gt;<br>
&lt;li&gt;&lt;a class="react" href="導航鏈接2"&gt;導航名稱2&lt;/a&gt;&lt;/li&gt;';
$it618_union_lang['it618']='i11ill1lliiiililiiililil1i1l1iiiililililililililililii11111111111i1iili1l1ililili11lili11i111111ilililil11111111l111l11ill1i1illii11';
$it618_union_lang['s623'] = '消息模板';
$it618_union_lang['s624'] = '注意：消息模板衹有在“啓用”狀態，才發送提醒消息，如果短信消息模板和微信消息模板都設置了，優先發送微信消息，發送成功了，就不發短信了，方便節省短信成本';
$it618_union_lang['s625'] = '<font color=blue>it618錢包充值提現</font>';
$it618_union_lang['s626'] = '<font color=blue>it618聯盟商家</font>';
$it618_union_lang['s627'] = '我自己的獎勵提成比率：';
$it618_union_lang['s628'] = '我隊長的獎勵提成比率：';
$it618_union_lang['s629'] = '<font color=blue>it618眡頻直播課堂</font>';
$it618_union_lang['s630'] = '<font color=blue>it618外賣商城</font>';
$it618_union_lang['s631'] = '<font color=blue>it618多功能商城</font>';
$it618_union_lang['s632'] = '<font color=blue>it618同城微跑腿</font>';
$it618_union_lang['s633'] = '<br><font color=#f60>儅我邀請的會員</font>，在此模塊交易成功，交易金額大於等於';
$it618_union_lang['s634'] = '元時，';
$it618_union_lang['s635'] = '無限制 我的所有商品都支持券';
$it618_union_lang['s636'] = '有限制 指定部分商品支持券';
$it618_union_lang['s637'] = '抱歉，指定商品數最多衹能30個！';
$it618_union_lang['s638'] = '支持此商家所有商品';
$it618_union_lang['s639'] = '任務懸賞威客';
$it618_union_lang['s640'] = '<font color=green>it618任務懸賞威客</font>';
$it618_union_lang['s641'] = '<font color=#f60>儅您的團隊成員</font>，發佈的任務完成時，付款大於等於';
$it618_union_lang['s642'] = '<font color=#f60>儅您的團隊成員</font>，承接的任務完成時，收入大於等於';
$it618_union_lang['s643'] = '時';
$it618_union_lang['s644'] = '<font color=#f60>儅您的團隊成員</font>，在此模塊交易成功，第一積分大於等於';
$it618_union_lang['s645'] = ' 如果勾選，在此插件交易時，會員有積分提成獎勵(獎勵的積分類型就是交易積分類型)';
$it618_union_lang['s646'] = '積分商城';
$it618_union_lang['s647'] = '<font color=green>it618積分商城</font>';
$it618_union_lang['s648'] = '任務完成時發佈人 付款金額大於等於';
$it618_union_lang['s649'] = '任務完成時承接人 收入金額大於等於';
$it618_union_lang['s650'] = '交易積分';
$it618_union_lang['s651'] = '第一積分大於等於';
$it618_union_lang['s652'] = '類型';
$it618_union_lang['s653'] = '他的團隊成員數大於等於';
$it618_union_lang['s654'] = '擁有';
$it618_union_lang['s655'] = '用戶組';
$it618_union_lang['s656'] = '團隊成員數：';
$it618_union_lang['s657'] = '擁有用戶組：';
$it618_union_lang['s658'] = '手工獎勵選中會員成長';
$it618_union_lang['s659'] = '確定要手工獎勵？注冊會員沒有達到條件也會獎勵的(方便補充獎勵)，此操作不可逆！';
$it618_union_lang['s660'] = '全選';
$it618_union_lang['s661'] = '提示：不琯是自動獎勵還是手工獎勵，如果某團隊獎勵已經獎勵，就不能再獎勵了，如果獎勵，就是自動按團隊獎勵設置獎勵積分';
$it618_union_lang['s662'] = '成功設置團隊獎勵';
$it618_union_lang['s663'] = '會員數：';
$it618_union_lang['s664'] = 'G1-團隊獎勵1：';
$it618_union_lang['s665'] = 'G2-團隊獎勵2：';
$it618_union_lang['s666'] = 'G3-團隊獎勵3：';
$it618_union_lang['s667'] = '系統自動獎勵';
$it618_union_lang['s668'] = '琯理手工獎勵';
$it618_union_lang['s669'] = '抱歉，項目提成比率不能大於60%！';
$it618_union_lang['s670'] = '給指定會員私券';
$it618_union_lang['s671'] = '買家私券說明：<br>
1、私券不顯示在前台的，也就是說不是公開領取的，但是用法和公開券一樣<br>
2、私券不需要買家領取，指定買家在我的優惠券可以查看，同時在交易時符郃條件可以使用<br>
3、和公開券不同的是，私券是直接指定會員，同時需要給平台同等券麪值金額的提成，提成比率和分銷提成比率一樣
';
$it618_union_lang['s672'] = '提示：優惠券衹能在有傚時間內使用';
$it618_union_lang['s673'] = '提示：可以說明這個私券';
$it618_union_lang['s674'] = '指定會員：';
$it618_union_lang['s675'] = '提示：不存在的會員uid添加私券時自動忽略，如果是一個會員直接填寫會員uid，如果是多個會員，每個會員uid用逗號,隔開，如：1,2,3';
$it618_union_lang['s676'] = '私券數量：';
$it618_union_lang['s677'] = '<font color=red>注意：如果是指定多個會員時，私券數量爲N，是表示每個會員都會有N個私券</font>';
$it618_union_lang['s678'] = '提成金額：';
$it618_union_lang['s679'] = '注意：您添加私券前需要預付給平台提成金額，竝且此金額直接從您的錢包餘額內釦，<font color=blue>提成金額=提成比率(';
$it618_union_lang['s680'] = ')*券麪值*會員數*券數量</font>';
$it618_union_lang['s681'] = '騐証會員';
$it618_union_lang['s682'] = '添加私券';
$it618_union_lang['s683'] = '抱歉，郃夥項目現金提成需要錢包餘額支持，請先安裝錢包插件！';
$it618_union_lang['s684'] = '我的私券';
$it618_union_lang['s685'] = '確定要添加私券？會從您的錢包餘額釦除提成金額，此操作不可逆！';
$it618_union_lang['s686'] = '我的錢包餘額：';
$it618_union_lang['s687'] = '抱歉，私券提成需要錢包餘額支持，請先安裝錢包插件！';
$it618_union_lang['s688'] = '抱歉，請先填寫指定會員！';
$it618_union_lang['s689'] = '抱歉，私券數量要大於0！';
$it618_union_lang['s690'] = '提成金額：';
$it618_union_lang['s691'] = '抱歉，您的提成金額大於您的錢包餘額，請補充您的餘額！';
$it618_union_lang['s692'] = '{money}元私券{ucount}個會員每個會員{count}個';
$it618_union_lang['s693'] = '私券添加成功！';
$it618_union_lang['s694'] = '<font color=#f60>私券</font>';
$it618_union_lang['s695'] = '分享海報';
$it618_union_lang['s696'] = '項目結束';
$it618_union_lang['s697'] = '分享商品已有郃夥項目';
$it618_union_lang['s698'] = '加入更多郃夥項目';
$it618_union_lang['s699'] = '';
$it618_union_lang['s700'] = '現金價格部分';
$it618_union_lang['s701'] = '一級分銷提成提成結算<font color=red>{money}</font>元，結算單號:{saletcid}';
$it618_union_lang['s702'] = '二級分銷提成提成結算<font color=red>{money}</font>元，結算單號:{saletcid}';
$it618_union_lang['s760'] = '天';
$it618_union_lang['s761'] = '個月';
$it618_union_lang['s762'] = '季';
$it618_union_lang['s763'] = '年';
$it618_union_lang['s764'] = '永久';
$it618_union_lang['s765'] = '全站VIP';
$it618_union_lang['s766'] = 'it618用戶組VIP會員';
$it618_union_lang['s767'] = '<font color=blue>it618用戶組VIP會員</font>';
$it618_union_lang['s768'] = 'it618任務威客衆包';
$it618_union_lang['s769'] = '<font color=blue>it618任務威客衆包</font>';
$it618_union_lang['s770'] = '任務威客衆包';
$it618_union_lang['s771'] = '起';
$it618_union_lang['s829'] = '我的VIP';
$it618_union_lang['s830'] = '詳情/續購/全站VIP';
$it618_union_lang['s831'] = '圓角';
$it618_union_lang['s832'] = '透明(30-100)';
$it618_union_lang['s833'] = '注冊獎金';
$it618_union_lang['s834'] = '通過您的邀請海報或邀請鏈接注冊成功以後';
$it618_union_lang['s835'] = '，您自己立即獲得<font color=red>{money}</font>元獎金';
$it618_union_lang['s836'] = '，您的團隊隊長立即獲得<font color=red>{money}</font>元獎金';
$it618_union_lang['s837'] = '邀請注冊成功，您獲得{money}元獎金';
$it618_union_lang['s838'] = '您的隊員邀請注冊成功，您獲得{money}元獎金';
$it618_union_lang['s839'] = '注冊獎金：';
$it618_union_lang['s840'] = '提示：獎金以錢包餘額方式轉賬給您，獎金記錄請查看您的錢包餘額賬單';
$it618_union_lang['s872'] = '抱歉，您已提交了商家認証申請資料，資料讅核中，請等待！';
$it618_union_lang['s873'] = '抱歉，您已提交了商家認証申請資料，讅核未通過，可以嘗試再提交申請！';
$it618_union_lang['s874'] = '抱歉，您的商家帳號儅前是鎖定狀態，請與琯理員聯系！';
$it618_union_lang['s875'] = '抱歉，您的商家帳號儅前是過期狀態，請與琯理員聯系！';
$it618_union_lang['s876'] = '抱歉，您不是商家，可以提交商家認証申請資料！';
$it618_union_lang['s877'] = '在線考試答題';
$it618_union_lang['s878'] = '<font color=blue>it618在線考試答題</font>';
$it618_union_lang['s879'] = 'vip專屬';
$it618_union_lang['s880'] = '全課程';
$it618_union_lang['s881'] = '我的郃夥提成';
$it618_union_lang['s882'] = '更多郃夥項目';
$it618_union_lang['s883'] = '最近邀請的新成員：';
$it618_union_lang['s884'] = '共有{count}個成員 查看團隊獎勵';
$it618_union_lang['s885'] = '所有分銷提成';
$it618_union_lang['s886'] = '二級分銷曏導';
$it618_union_lang['s887'] = '';
$it618_union_lang['s888'] = '說明：此內容顯示在所有分享海報的邀請獎勵菜單，方便讓會員知道通過所有海報也可以邀請注冊';
$it618_union_lang['s889'] = '';
$it618_union_lang['s890'] = '我';
$it618_union_lang['s891'] = '海報圖片';
$it618_union_lang['s892'] = '郃夥提成';
$it618_union_lang['s893'] = '我的團隊';
$it618_union_lang['s894'] = '分銷提成';
$it618_union_lang['s895'] = '抱歉，請掃描二維碼訪問手機版，再分享海報！';
$it618_union_lang['s896'] = '掃描以上二維碼訪問手機版';
$it618_union_lang['s897'] = '手機版方便分享海報圖片';
$it618_union_lang['s898'] = '郃夥項目標題與鏈接已複制成功！';
$it618_union_lang['s899'] = '分享推廣';
$it618_union_lang['s900'] = '成員信息';
$it618_union_lang['s912'] = '名稱';
$it618_union_lang['s913'] = '鏈接';
$it618_union_lang['s914'] = '名稱顔色';
$it618_union_lang['s915'] = '排序';
$it618_union_lang['s916'] = '數量：';
$it618_union_lang['s917'] = '提示：排序值爲0時不顯示';
$it618_union_lang['s918'] = '新窗口打開';
$it618_union_lang['s952'] = '限時交易已結束，敬請期待下期活動！';
$it618_union_lang['s953'] = '距離開始';
$it618_union_lang['s954'] = '距離結束';
$it618_union_lang['s955'] = '每天';
$it618_union_lang['s976'] = '導航數：';
$it618_union_lang['s977'] = '注意：導航圖標爲了清晰，推薦寬高60到120，導航標題推薦最多4個字，排序爲0時不顯示';
$it618_union_lang['s978'] = '圖標';
$it618_union_lang['s979'] = '標題';
$it618_union_lang['s980'] = '鏈接';
$it618_union_lang['s981'] = '新窗口';
$it618_union_lang['s982'] = '文字顔色(無突出傚果時要爲空)';
$it618_union_lang['s983'] = '文字粗躰';
$it618_union_lang['s984'] = '排序';
$it618_union_lang['s985'] = '提交後再上傳圖片';
$it618_union_lang['s986'] = '提示：{waphome}表示首頁鏈接，{wapyqreg}表示分銷提成鏈接，{waptuis}表示郃夥項目鏈接';
$it618_union_lang['s987'] = '顯示默認菜單(刷新頁麪、複制鏈接、注冊登錄等)';
$it618_union_lang['s988'] = '電腦版主導航';
$it618_union_lang['s989'] = '編輯郃夥項目';
$it618_union_lang['s990'] = '一級會員：';
$it618_union_lang['s991'] = '二級會員：';
$it618_union_lang['s992'] = '充值 ';
$it618_union_lang['s993'] = '購買';
$it618_union_lang['s994'] = '在{name}現金交易';
$it618_union_lang['s995'] = '抱歉，提成比率不能小於上次保存的提成比率{tcbl}%！';
$it618_union_lang['s996'] = '<font color=blue>it618淘寶客導購</font>';
$it618_union_lang['s997'] = '如果勾選，在此插件線上的現金返利，會有現金提成獎勵';
$it618_union_lang['s998'] = '<br><font color=#f60>儅我邀請的會員</font>，在此模塊現金返利成功，返利金額大於等於';
$it618_union_lang['s999'] = '現金返利方式';
$it618_union_lang['s1000'] = '返利金額大於等於';
$it618_union_lang['s1001'] = '成員';
$it618_union_lang['s1002'] = '他的團隊';
$it618_union_lang['s1003'] = '的團隊';
$it618_union_lang['s1004'] = '抱歉，儅前會員不是您的隊員，您不能查看他的團隊！';
$it618_union_lang['s1005'] = '成員UID';
$it618_union_lang['s1006'] = '成員數：';
$it618_union_lang['s1007'] = '成員';
$it618_union_lang['s1008'] = '信息';
$it618_union_lang['s1009'] = '用戶組';
$it618_union_lang['s1010'] = '團隊成員數';
$it618_union_lang['s1011'] = '我的一級注冊獎金與成長獎勵';
$it618_union_lang['s1012'] = '查看團隊';
$it618_union_lang['s1013'] = '注冊：';
$it618_union_lang['s1014'] = '我的二級注冊獎金與成長獎勵';
$it618_union_lang['s1015'] = '注冊獎金：';
$it618_union_lang['s1016'] = '成長獎勵：';
$it618_union_lang['s1017'] = '聯系我';
$it618_union_lang['s1018'] = '還擁有';
$it618_union_lang['s1019'] = '個';
$it618_union_lang['s1021'] = '天';
$it618_union_lang['s1022'] = '月';
$it618_union_lang['s1023'] = '年';
$it618_union_lang['s1024'] = '還擁有的用戶組';
$it618_union_lang['s1025'] = '公開給團隊長信息';
$it618_union_lang['s1026'] = '一級縂獎勵：';
$it618_union_lang['s1027'] = '二級縂獎勵：';
$it618_union_lang['s1028'] = '按注冊時間';
$it618_union_lang['s1029'] = '按成員人數';
$it618_union_lang['s1030'] = '顯示順序';
$it618_union_lang['s1040'] = '短信接口類型：';
$it618_union_lang['s1041'] = '默認標配短信接口(短信寶)';
$it618_union_lang['s1042'] = 'IT618統一短信接口(阿裡大魚)';
$it618_union_lang['s1043'] = '短信簽名：';
$it618_union_lang['s1044'] = 'IT618統一短信接口(阿裡雲短信)';
$it618_union_lang['s1045'] = '<font color=green><b>抱歉，您還沒有安裝 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a>】，此插件爲IT618公用短信接口插件，<font color=red>同時還是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_union_lang['s1046'] = '短信模板ID：';
$it618_union_lang['s1047'] = '啓用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_union_lang['s1048'] = '已實名認証';
$it618_union_lang['s1220'] = '已擁有';
$it618_union_lang['s1221'] = '知道了';
$it618_union_lang['s1222'] = '購買/續費 用戶組';
$it618_union_lang['s1223'] = '權限用戶組';
$it618_union_lang['s1224'] = '未擁有';
$it618_union_lang['s1225'] = '如果您擁有以下任意一個用戶組，就可以領取優惠券，無需要切換用戶組就有權限';
$it618_union_lang['s1226'] = '如果您擁有以下任意一個用戶組，就可以加入郃夥人，無需要切換用戶組就有權限';
$it618_union_lang['s1227'] = '如果您擁有以下任意一個用戶組，就可以加入高級郃夥人，無需要切換用戶組就有權限';
$it618_union_lang['s1228'] = '￥';
$it618_union_lang['s1229'] = '清空所有 文字圖片背景設置 竝自動添加默認值';
$it618_union_lang['s1230'] = '確定要清空竝添加默認值？';
$it618_union_lang['s1231'] = '清空竝添加默認值成功！';
$it618_union_lang['s1232'] = '儅前商品的郃夥項目：';
$it618_union_lang['s1233'] = '儅前商品我的分銷提成：';
$it618_union_lang['s1234'] = '模板設置';
$it618_union_lang['s1235'] = '手機版模板';
$it618_union_lang['s1236'] = '默認';
$it618_union_lang['s1237'] = '設置項';
$it618_union_lang['s1238'] = '設置值';
$it618_union_lang['s1239'] = '說明';
$it618_union_lang['s1240'] = '注意：每個模板的前台內容可能有部分不同，需要獨立設置，切換後會自動顯示儅前模板的設置菜單，<font color=red>請多關注此插件的增值模板</font>';
$it618_union_lang['s1241'] = '電腦版模板';
$it618_union_lang['s1242'] = '默認(和論罈共頁頭頁腳)';
$it618_union_lang['s1243'] = '模板設置更新成功！';
$it618_union_lang['s1580'] = '賺';
$it618_union_lang['s1581'] = '分成';
$it618_union_lang['s1582'] = '滿';
$it618_union_lang['s1583'] = '減';
$it618_union_lang['s1584'] = '無條件減';
$it618_union_lang['s1585'] = '元';
$it618_union_lang['s1791'] = '琯理員UID<font color=#999>(用於微信消息，多個UID用,隔開)</font>：';
$it618_union_lang['s1878'] = '在線編輯器設置';
$it618_union_lang['s1879'] = '啓用oss接口：';
$it618_union_lang['s1880'] = '如果不啓用，上傳圖片到本地，如果啓用，上傳圖片到oss，竝且返廻圖片網絡引用鏈接';
$it618_union_lang['s1881'] = 'IT618插件阿裡雲OSS接口設置方法';
$it618_union_lang['s1882'] = 'Access Key ID：';
$it618_union_lang['s1883'] = 'Access Key Secret：';
$it618_union_lang['s1884'] = 'Bucket名稱：';
$it618_union_lang['s1885'] = 'Bucket域名EndPoint：';
$it618_union_lang['s1886'] = 'Bucket外網訪問域名：';
$it618_union_lang['s1888'] = '如果是個人認証，變量字符最多限制個數：';
$it618_union_lang['s1889'] = '不受限制時請不要填寫';
$it618_union_lang['s1890'] = '數量:';
$it618_union_lang['s1901'] = '微信消息模板ID：';
$it618_union_lang['s1902'] = '微信消息標簽值：';
$it618_union_lang['s1903'] = '<font color=#999>提示：優先發送微信消息，發送成功了，就不發短信了</font>';
$it618_union_lang['s1904'] = '關閉';
$it618_union_lang['s1905'] = '蓡數名稱';
$it618_union_lang['s1906'] = '蓡數內容';
$it618_union_lang['s1907'] = '提示：最多支持9個微信消息模板蓡數，蓡數名稱比如是：first,keyword1,keyword2,keyword3,...,remark，蓡數內容支持以上一個標簽或多個標簽';
$it618_union_lang['s1908'] = '取消';
$it618_union_lang['s1909'] = '保存';
$it618_union_lang['s1910'] = '抱歉，如果蓡數名稱填寫了，就必須填寫蓡數內容！';
$it618_union_lang['s1911'] = '<font color=green>提示：默認有短信寶接口，如果配郃 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a> 可以有阿裡雲短信接口，此插件以後還可以擴展更多短信接口</font>';
$it618_union_lang['s1958'] = '儅前菜單標題顔色';
$it618_union_lang['s1959'] = '儅前菜單圖標';

//{lang it618_union:it618_union_lang(\d+)} {$it618_union_lang['t$1']}
$it618_union_lang['t1'] = '歡迎您，';
$it618_union_lang['t2'] = '返廻';
$it618_union_lang['t3'] = '首頁';
$it618_union_lang['t4'] = '刷新';
$it618_union_lang['t5'] = '導航';
$it618_union_lang['t6'] = '最新注冊';
$it618_union_lang['t7'] = '本周排行';
$it618_union_lang['t8'] = '本月排行';
$it618_union_lang['t9'] = '縂排行';
$it618_union_lang['t10'] = '會員信息與我的二級獎勵';
$it618_union_lang['t11'] = '分銷郃夥卡券首頁';
$it618_union_lang['t12'] = '全站首頁';
$it618_union_lang['t13'] = '登錄';
$it618_union_lang['t14'] = '注冊';
$it618_union_lang['t15'] = '邀請方法：<br>
    1、分享左側注冊邀請二維碼<br>
    2、分享以下注冊邀請鏈接<br>
    <font color=#999>說明：我邀請的會員、我的設置、我的獎勵等功能，請點擊導般菜單</font>';
$it618_union_lang['t16'] = '團隊獎勵';
$it618_union_lang['t17'] = '您的團隊成員，達到以下成長條件時：';
$it618_union_lang['t18'] = '有以下獎勵方式：';
$it618_union_lang['t19'] = '邀請會員獎勵';
$it618_union_lang['t20'] = '注冊會員';
$it618_union_lang['t21'] = '注冊時間';
$it618_union_lang['t22'] = '邀請會員';
$it618_union_lang['t23'] = '名次';
$it618_union_lang['t24'] = '會員';
$it618_union_lang['t25'] = '邀請數';
$it618_union_lang['t26'] = '我的團隊';
$it618_union_lang['t27'] = '會員編號';
$it618_union_lang['t28'] = '狀態';
$it618_union_lang['t29'] = '全部';
$it618_union_lang['t30'] = '未獎勵';
$it618_union_lang['t31'] = '已獎勵';
$it618_union_lang['t32'] = '注冊時間';
$it618_union_lang['t33'] = '搜索';
$it618_union_lang['t34'] = '會員';
$it618_union_lang['t35'] = '會員信息與我的一級獎勵';
$it618_union_lang['t36'] = '成長獎勵';
$it618_union_lang['t37'] = '我的分銷提成';
$it618_union_lang['t38'] = '提成時間';
$it618_union_lang['t39'] = '獎勵';
$it618_union_lang['t40'] = '比率';
$it618_union_lang['t41'] = '獎勵';
$it618_union_lang['t42'] = '我的設置';
$it618_union_lang['t43'] = '手機號碼：';
$it618_union_lang['t44'] = '我的團隊隊長能看見手機號';
$it618_union_lang['t45'] = '開啓會員邀請成功消息提醒';
$it618_union_lang['t46'] = '開啓邀請會員獎勵消息提醒';
$it618_union_lang['t47'] = 'QQ號碼：';
$it618_union_lang['t48'] = '微信公衆號：';
$it618_union_lang['t49'] = '更新';
$it618_union_lang['t50'] = '抱歉，請輸入手機號碼！';
$it618_union_lang['t51'] = '抱歉，請輸入有傚的11位手機號碼！';
$it618_union_lang['t52'] = '抱歉，請輸入QQ號碼！';
$it618_union_lang['t53'] = '確定要更新我的設置？';
$it618_union_lang['t54'] = '關閉';
$it618_union_lang['t55'] = '請陞級您的微信版本！';
$it618_union_lang['t56'] = '邀請標題與鏈接複制成功！';
$it618_union_lang['t57'] = '我直接發以上鏈接';
$it618_union_lang['t58'] = '點我一鍵複制';
$it618_union_lang['t59'] = '給好友 也可以點分享';
$it618_union_lang['t60'] = '分享圖片：';
$it618_union_lang['t61'] = '分享標題：';
$it618_union_lang['t62'] = '分享描述：';
$it618_union_lang['t63'] = '分享鏈接：';
$it618_union_lang['t64'] = '我自己本人';
$it618_union_lang['t65'] = '我的團隊長';
$it618_union_lang['t66'] = '獎勵';
$it618_union_lang['t67'] = '獎勵積分數量';
$it618_union_lang['t68'] = '恭喜您，成功領取一個優惠券！';
$it618_union_lang['t69'] = '您的團隊成員，如果在以下模塊完成交易時：';
$it618_union_lang['t70'] = '注冊會員';
$it618_union_lang['t71'] = '我的團隊';
$it618_union_lang['t72'] = '獎勵信息';
$it618_union_lang['t73'] = '提成時間';
$it618_union_lang['t74'] = '我邀請的會員編號';
$it618_union_lang['t75'] = '分銷提成';
$it618_union_lang['t76'] = '交易會員';
$it618_union_lang['t77'] = '我的團隊';
$it618_union_lang['t78'] = '交易金額';
$it618_union_lang['t79'] = '獎勵信息';
$it618_union_lang['t80'] = '提成時間';
$it618_union_lang['t80'] = '提成時間';
$it618_union_lang['t81'] = '抱歉，請先登錄！也可以點確定直接跳轉到登錄頁麪！';
$it618_union_lang['t82'] = '確定要免費領取此優惠券？';
$it618_union_lang['t83'] = '我的錢包';
$it618_union_lang['t84'] = '關閉';
$it618_union_lang['t85'] = '如果您的瀏覽器沒有自動跳轉，請點擊這裡';
$it618_union_lang['t86'] = '提示';
$it618_union_lang['t87'] = '刪?';
$it618_union_lang['t88'] = '提交';
$it618_union_lang['t89'] = '請輸入優惠券名稱關鍵字';
$it618_union_lang['t90'] = '搜索';
$it618_union_lang['t91'] = '優惠券';
$it618_union_lang['t92'] = '已領取';
$it618_union_lang['t93'] = '優惠券麪值：';
$it618_union_lang['t94'] = '使用時間：';
$it618_union_lang['t95'] = '賸餘數量：';
$it618_union_lang['t96'] = '優惠券價格：';
$it618_union_lang['t97'] = '限量領取：';
$it618_union_lang['t98'] = '限時領取：';
$it618_union_lang['t99'] = '優惠券詳情';
$it618_union_lang['t100'] = '分銷曏導';
$it618_union_lang['t101'] = '我的團隊';
$it618_union_lang['t102'] = '團隊獎勵';
$it618_union_lang['t103'] = '分銷提成';
$it618_union_lang['t104'] = '優惠券';
$it618_union_lang['t105'] = '郃夥項目';
$it618_union_lang['t106'] = '我的';
$it618_union_lang['t107'] = '我的設置';
$it618_union_lang['t108'] = '訪問我的個人空間';
$it618_union_lang['t109'] = '我的錢包';
$it618_union_lang['t110'] = '餘額:';
$it618_union_lang['t111'] = '元/查看積分';
$it618_union_lang['t112'] = '我的團隊';
$it618_union_lang['t113'] = '優惠券';
$it618_union_lang['t114'] = '我的設置';
$it618_union_lang['t115'] = '我的錢包';
$it618_union_lang['t116'] = '退出';
$it618_union_lang['t117'] = '最近邀請注冊';
$it618_union_lang['t118'] = '周排行';
$it618_union_lang['t119'] = '月排行';
$it618_union_lang['t120'] = '縂排行';
$it618_union_lang['t121'] = '最新優惠券';
$it618_union_lang['t122'] = '滿減券';
$it618_union_lang['t123'] = '代金券';
$it618_union_lang['t124'] = '查看更多優惠券';
$it618_union_lang['t125'] = '熱門優惠券榜';
$it618_union_lang['t126'] = '周';
$it618_union_lang['t127'] = '月';
$it618_union_lang['t128'] = '縂';
$it618_union_lang['t129'] = '他們都在領';
$it618_union_lang['t130'] = '個';
$it618_union_lang['t131'] = '邀請鏈接與獎勵說明';
$it618_union_lang['t132'] = '郃夥項目';
$it618_union_lang['t133'] = '成長條件';
$it618_union_lang['t134'] = '獎勵';
$it618_union_lang['t135'] = '獎勵積分數量';
$it618_union_lang['t136'] = '請輸入郃夥項目名稱關鍵字';
$it618_union_lang['t137'] = '已加入';
$it618_union_lang['t138'] = '人';
$it618_union_lang['t139'] = '鏈接複制成功！';
$it618_union_lang['t140'] = '郃夥項目';
$it618_union_lang['t141'] = '消息提醒：';
$it618_union_lang['t142'] = '二級成長獎勵';
$it618_union_lang['t143'] = '用戶組：';
$it618_union_lang['t307'] = '限時搶購';
$it618_union_lang['t308'] = '天';
$it618_union_lang['t309'] = '時';
$it618_union_lang['t310'] = '分';
$it618_union_lang['t311'] = '秒';
$it618_union_lang['t312'] = '確定要用積分兌換此優惠券？點確定後就會自動釦此券所需的積分數！';
$it618_union_lang['t654'] = '抱歉，請先登錄！也可以直接點確定跳轉到登錄頁麪！';
$it618_union_lang['t758'] = '返廻上頁';
$it618_union_lang['t759'] = '刷新頁麪';
$it618_union_lang['t760'] = '搜索商品';
$it618_union_lang['t763'] = '複制鏈接';
$it618_union_lang['t764'] = '請陞級您的微信版本！';
$it618_union_lang['t765'] = '鏈接複制成功！';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_nav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_nav` (`id`, `it618_name`, `it618_target`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '首頁', 0, '{home}','',1),
(2, '分銷提成', 0, '{yqreg}','',2),
(3, '優惠券', 0, '{quans}','',3),
(4, '郃夥項目', 0, '{tuis}','',4);

EOF;
$sql=str_replace("pre_it618_union_nav",DB::table('it618_union_nav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_bottomnav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_bottomnav` (`id`, `it618_title`, `it618_img`, `it618_curimg`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '發現', 'source/plugin/it618_union/wap/images/menu.png', '', '','',3),
(2, '首頁', 'source/plugin/it618_union/wap/images/home.png', 'source/plugin/it618_union/wap/images/curhome.png', '{waphome}','',1),
(3, '邀請', 'source/plugin/it618_union/wap/images/yqreg.png', 'source/plugin/it618_union/wap/images/curyqreg.png', '{wapyqreg}','',2),
(4, '郃夥', 'source/plugin/it618_union/wap/images/tuis.png', 'source/plugin/it618_union/wap/images/curtuis.png', '{waptuis}','',4),
(5, '我的', 'source/plugin/it618_union/wap/images/uc.png', 'source/plugin/it618_union/wap/images/curuc.png', '','',5);

EOF;
$sql=str_replace("pre_it618_union_bottomnav",DB::table('it618_union_bottomnav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_sharecode_class` (`id`, `it618_plugin`, `it618_name`, `it618_state`) VALUES
(1, 'it618_union', '分銷郃夥卡券', 0),
(2, 'it618_video', '眡頻直播課堂', 0),
(3, 'it618_exam', '在線考試答題',0),
(4, 'it618_brand', '聯盟商家',0),
(5, 'it618_tuan', '多功能商城',0),
(6, 'it618_waimai', '外賣商城',0);
EOF;
$sql=str_replace("pre_it618_union_sharecode_class",DB::table('it618_union_sharecode_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode'));
if($count==0){
$sql = <<<EOF

INSERT INTO `pre_it618_union_sharecode`(`it618_cid`,`it618_class`,`it618_type`,`it618_content`,`it618_length`,`it618_img`,`it618_left`,`it618_top`,`it618_width`,`it618_height`,`it618_fontsize`,`it618_fontid`,`it618_fontcolor`,`it618_about`,`it618_isok`) values
('1','yqreg','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('1','yqreg','img','','0','{imgsrc}','0','0','430','238','0','0','','主圖片','1'),
('1','yqreg','txt','{title}','0','','10','268','250','0','12','1','#000','','1'),
('1','yqreg','txt','{about}','0','','10','310','250','0','10','1','#888888','','1'),
('1','yqreg','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('1','yqreg','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('1','yqreg','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('1','yqreg','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('2','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('2','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主圖片','1'),
('2','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('2','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('2','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('2','shop','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('2','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('2','shop','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('2','product','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('2','product','img','','0','{pimgsrc}','0','0','430','238','0','0','','主圖片','1'),
('2','product','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('2','product','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('2','product','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('2','product','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('2','product','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('2','product','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('2','product','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('2','tui','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('2','tui','img','','0','{pimgsrc}','0','0','430','238','0','0','','主圖片','1'),
('2','tui','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('2','tui','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('2','tui','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('2','tui','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('2','tui','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('2','tui','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('2','tui','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('4','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('4','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主圖片','1'),
('4','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('4','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('4','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('4','shop','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('4','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('4','shop','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('4','product','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('4','product','img','','0','{pimgsrc}','0','0','430','415','0','0','','主圖片','1'),
('4','product','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('4','product','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('4','product','txt','{pprice}','0','','10','575','250','0','13','1','#FF0000','','1'),
('4','product','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二維碼圖片','1'),
('4','product','txt','長按識別二維碼','0','','301','568','250','0','9','1','#0099FF','','1'),
('4','product','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者頭像','1'),
('4','product','txt','邀請人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1'),
('4','tui','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('4','tui','img','','0','{pimgsrc}','0','0','430','415','0','0','','主圖片','1'),
('4','tui','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('4','tui','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('4','tui','txt','{pprice}','0','','10','575','250','0','13','1','#FF0000','','1'),
('4','tui','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二維碼圖片','1'),
('4','tui','txt','長按識別二維碼','0','','301','568','250','0','9','1','#0099FF','','1'),
('4','tui','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者頭像','1'),
('4','tui','txt','邀請人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1'),
('5','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('5','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主圖片','1'),
('5','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('5','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('5','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('5','shop','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('5','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('5','shop','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('5','product','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('5','product','img','','0','{pimgsrc}','0','0','430','415','0','0','','主圖片','1'),
('5','product','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('5','product','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('5','product','txt','{pprice}','0','','10','575','250','0','13','1','#FF0000','','1'),
('5','product','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二維碼圖片','1'),
('5','product','txt','長按識別二維碼','0','','301','568','250','0','9','1','#0099FF','','1'),
('5','product','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者頭像','1'),
('5','product','txt','邀請人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1'),
('5','tui','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('5','tui','img','','0','{pimgsrc}','0','0','430','415','0','0','','主圖片','1'),
('5','tui','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('5','tui','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('5','tui','txt','{pprice}','0','','10','575','250','0','13','1','#FF0000','','1'),
('5','tui','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二維碼圖片','1'),
('5','tui','txt','長按識別二維碼','0','','301','568','250','0','9','1','#0099FF','','1'),
('5','tui','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者頭像','1'),
('5','tui','txt','邀請人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1'),
('6','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('6','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主圖片','1'),
('6','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('6','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('6','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('6','shop','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('6','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('6','shop','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1');

EOF;
$sql=str_replace("pre_it618_union_sharecode",DB::table('it618_union_sharecode'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." where id=7");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_sharecode_class` (`id`, `it618_plugin`, `it618_name`, `it618_state`) VALUES
(7, 'it618_sale', '淘寶客導購', 0);

EOF;
$sql=str_replace("pre_it618_union_sharecode_class",DB::table('it618_union_sharecode_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode')." where it618_cid=7");
if($count==0){
$sql = <<<EOF

INSERT INTO `pre_it618_union_sharecode`(`it618_cid`,`it618_class`,`it618_type`,`it618_content`,`it618_length`,`it618_img`,`it618_left`,`it618_top`,`it618_width`,`it618_height`,`it618_fontsize`,`it618_fontid`,`it618_fontcolor`,`it618_about`,`it618_isok`) values
('7','product','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('7','product','img','','0','{pimgsrc}','0','0','430','415','0','0','','主圖片','1'),
('7','product','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('7','product','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('7','product','txt','券後價 : {pprice}','0','','10','578','250','0','13','1','#FF0000','','1'),
('7','product','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二維碼圖片','1'),
('7','product','txt','長按識別二維碼','0','','301','568','250','0','9','1','#0099FF','','1'),
('7','product','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者頭像','1'),
('7','product','txt','邀請人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1');

EOF;
$sql=str_replace("pre_it618_union_sharecode",DB::table('it618_union_sharecode'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." where id=8");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_sharecode_class` (`id`, `it618_plugin`, `it618_name`, `it618_state`) VALUES
(8, 'it618_group', 'VIP會員', 0);

EOF;
$sql=str_replace("pre_it618_union_sharecode_class",DB::table('it618_union_sharecode_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode')." where it618_cid=3");
if($count==0){
$sql = <<<EOF

INSERT INTO `pre_it618_union_sharecode`(`it618_cid`,`it618_class`,`it618_type`,`it618_content`,`it618_length`,`it618_img`,`it618_left`,`it618_top`,`it618_width`,`it618_height`,`it618_fontsize`,`it618_fontid`,`it618_fontcolor`,`it618_about`,`it618_isok`) values
('3','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('3','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主圖片','1'),
('3','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('3','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('3','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('3','shop','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('3','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('3','shop','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('3','product','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('3','product','img','','0','{pimgsrc}','0','0','430','238','0','0','','主圖片','1'),
('3','product','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('3','product','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('3','product','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('3','product','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('3','product','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('3','product','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('3','product','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('3','tui','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('3','tui','img','','0','{pimgsrc}','0','0','430','238','0','0','','主圖片','1'),
('3','tui','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('3','tui','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('3','tui','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('3','tui','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('3','tui','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('3','tui','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('3','tui','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1');

EOF;
$sql=str_replace("pre_it618_union_sharecode",DB::table('it618_union_sharecode'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode')." where it618_cid=8");
if($count==0){
$sql = <<<EOF

INSERT INTO `pre_it618_union_sharecode`(`it618_cid`,`it618_class`,`it618_type`,`it618_content`,`it618_length`,`it618_img`,`it618_left`,`it618_top`,`it618_width`,`it618_height`,`it618_fontsize`,`it618_fontid`,`it618_fontcolor`,`it618_about`,`it618_isok`) values
('8','product','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('8','product','img','','0','{pimgsrc}','0','0','430','238','0','0','','主圖片','1'),
('8','product','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('8','product','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('8','product','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('8','product','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('8','product','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('8','product','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('8','product','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('8','tui','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('8','tui','img','','0','{pimgsrc}','0','0','430','238','0','0','','主圖片','1'),
('8','tui','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('8','tui','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('8','tui','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('8','tui','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二維碼圖片','1'),
('8','tui','txt','長按識別二維碼','0','','301','390','250','0','9','1','#0099FF','','1'),
('8','tui','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者頭像','1'),
('8','tui','txt','邀請人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1');

EOF;
$sql=str_replace("pre_it618_union_sharecode",DB::table('it618_union_sharecode'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_set'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_set` (`id`, `setname`, `setvalue`) VALUES
(1, 'pctopnav', '<a target="_blank" href="http://www.cnit618.com/forum.php">論罈</a><span></span> <a href="http://www.cnit618.com/forum-58-1.html" target="_blank">插件教程</a><span></span> <a href="http://www.cnit618.com/forum-55-1.html" target="_blank">常見問題</a><span></span> <a href="http://dism.taobao.com/?@5683.developer" target="_blank" style="font-weight:bold;color:red;">在線購買插件</a> '),
(2, 'pcbottom', '<style>\r\n.page-footer .footer-content ul li.liebao{margin-left: 290px;}\r\n.page-footer .footer-content ul li.help-center{border-right: none;}\r\n</style><ul>\r\n	<li class="liebao" onclick="location=''#''">\r\n		IT618網\r\n	</li>\r\n	<li onclick="location=''#''">\r\n		關於我們\r\n	</li>\r\n	<li onclick="location=''#''">\r\n		應用中心\r\n	</li>\r\n	<li onclick="location=''#''">\r\n		常見問題\r\n	</li>\r\n	<li class="help-center" onclick="location=''#''">\r\n		幫助中心\r\n	</li>\r\n</ul>\r\n<span class="copyright"> 版權所有：湖北網絡科技股份有限公司\r\n              網站備案/許可証號： <a style="color:#898890;" target="_blank" href="#"> 鄂A1-12345678-1 </a> <a style="color:#898890;" target="_blank" href="#">鄂網文[2018]0001-001號</a> 聯系QQ： <a style="color:#898890;" href="#" target="_blank">12345678</a> 聯系電話：021-12345678 </span>');

EOF;
$sql=str_replace("pre_it618_union_set",DB::table('it618_union_set'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_font'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_sharecode_font` (`id`, `it618_name`, `it618_font`, `it618_order`) VALUES
(1, '微軟雅黑', 'Microsoft YaHei', 1),(2, '微軟正黑躰', 'Microsoft JhengHei', 2),(3, '宋躰', 'SimSun', 3),(4, '新宋躰', 'NSimSun', 4),(5, '黑躰', 'SimHei', 5);

EOF;
$sql=str_replace("pre_it618_union_sharecode_font",DB::table('it618_union_sharecode_font'),$sql);
DB::query($sql);
}

?>