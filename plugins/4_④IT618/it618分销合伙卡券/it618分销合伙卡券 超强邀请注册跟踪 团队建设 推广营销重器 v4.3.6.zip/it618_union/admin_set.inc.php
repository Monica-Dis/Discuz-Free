<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return;

loadcache('plugin');
$it618_union = $_G['cache']['plugin']['it618_union'];

require_once DISCUZ_ROOT.'./source/plugin/it618_union/function/it618_union.func.php';

if($reabc[9]!='o')return;
$ppp = $it618_union['pagecount'];
$page = max(1, intval($_GET['page']));
if($_GET['findbtn']==1)$page=1;
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=0;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<=15;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[0]=$it618_union_lang['s1'];
$strtmptitle[1]=$it618_union_lang['s2'];
$strtmptitle[2]=$it618_union_lang['s3'];
$strtmptitle[3]=$it618_union_lang['s4'];
$strtmptitle[4]=$it618_union_lang['s5'];
$strtmptitle[5]=$it618_union_lang['s6'];
$strtmptitle[6]=$it618_union_lang['s31'];
$strtmptitle[7]=$it618_union_lang['s99'];
$strtmptitle[8]=$it618_union_lang['s101'];
$strtmptitle[9]=$it618_union_lang['s1878'];
$strtmptitle[10]=$it618_union_lang['s84'];
$strtmptitle[11]=$it618_union_lang['s304'];
$strtmptitle[12]=$it618_union_lang['s494'];
$strtmptitle[13]=$it618_union_lang['s988'];
$strtmptitle[14]=$it618_union_lang['s887'];
$strtmptitle[15]=$it618_union_lang['s1234'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>
<li '.$strtmp[15].'><a href="'.$hosturl.'plugins&cp=admin_template&cp1=15'.$urls.'"><span>'.$strtmptitle[15].'</span></a></li>
<li '.$strtmp[11].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=11'.$urls.'"><span>'.$strtmptitle[11].'</span></a></li>
<li '.$strtmp[6].' style="display:none"><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=6'.$urls.'"><span>'.$strtmptitle[6].'</span></a></li>
<li '.$strtmp[7].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=7'.$urls.'"><span>'.$strtmptitle[7].'</span></a></li>
<li '.$strtmp[13].'><a href="'.$hosturl.'plugins&cp=admin_nav&cp1=13'.$urls.'"><span>'.$strtmptitle[13].'</span></a></li>
<li '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=8'.$urls.'"><span>'.$strtmptitle[8].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_gonggao&cp1=1'.$urls.'"><span>'.$strtmptitle[1].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_iconav&cp1=2'.$urls.'"><span>'.$strtmptitle[2].'</span></a></li>
<li '.$strtmp[10].'><a href="'.$hosturl.'plugins&cp=admin_bottomnav&cp1=10'.$urls.'"><span>'.$strtmptitle[10].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_wapstyle&cp1=3'.$urls.'"><span>'.$strtmptitle[3].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_message&cp1=4'.$urls.'"><span>'.$strtmptitle[4].'</span></a></li>
<li '.$strtmp[5].'><a href="'.$hosturl.'plugins&cp=admin_rewrite&cp1=5'.$urls.'"><span>'.$strtmptitle[5].'</span></a></li>
<li '.$strtmp[9].'><a href="'.$hosturl.'plugins&cp=admin_aliyunoss&cp1=9'.$urls.'"><span>'.$strtmptitle[9].'</span></a></li>
<li '.$strtmp[12].'><a href="'.$hosturl.'plugins&cp=admin_quan&cp1=12'.$urls.'"><span>'.$strtmptitle[12].'</span></a></li>
<li '.$strtmp[14].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=14'.$urls.'"><span>'.$strtmptitle[14].'</span></a></li>
</ul></div>';

$cparray = array('admin_focus', 'admin_gonggao', 'admin_iconav', 'admin_nav', 'admin_bottomnav', 'admin_wapstyle', 'admin_set', 'admin_message', 'admin_rewrite', 'admin_aliyunoss', 'admin_quan','admin_template');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_focus' : $_GET['cp'];

if($cp1==7)$setname='pctopnav';
if($cp1==8)$setname='pcbottom';
if($cp1==14)$setname='showyqabout';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();
?>