<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_header.func.php';

$urlsql='&key='.$_GET['key'].'&it618_type='.$_GET['it618_type'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount = C::t('#it618_union#it618_union_quansale')->count_by_qid($delid);
		
		if($salecount<=0){
			$it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_id($delid);
			
			$tmpurl=$_G['siteurl'].it618_union_getrewrite('union_wap','quan@'.$it618_union_quan['id'],'plugin.php?id=it618_union:wap&pagetype=quan&cid='.$it618_union_quan['id']);
			$qrcodeurl=md5($tmpurl);
			$qrcodeurl='source/plugin/it618_union/qrcode/'.$qrcodeurl.'.png';
			$tmparr=explode("source",$qrcodeurl);
			$qrcodeurl=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($qrcodeurl)){
				$result=unlink($qrcodeurl);
			}
			
			$tmparr=explode("source",$it618_union_quan['it618_pic']);
			$tmparr1=explode("://",$it618_union_quan['it618_pic']);
			$it618_pic=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_pic)&&count($tmparr1)==1){
				$result=unlink($it618_pic);
			}
			
			C::t('#it618_union#it618_union_quan')->delete_by_id($delid);
			$del=$del+1;
		}
	}

	it618_cpmsg(it618_union_getlang('s216').$del, "plugin.php?id=it618_union:sc_quan$adminsid&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_on')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		C::t('#it618_union#it618_union_quan')->update($delid,array(
			'it618_ison' => 1
		));

		$ok=$ok+1;
	}

	it618_cpmsg(it618_union_getlang('s217').$ok, "plugin.php?id=it618_union:sc_quan$adminsid&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_noton')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		C::t('#it618_union#it618_union_quan')->update($delid,array(
			'it618_ison' => 0
		));

		$ok=$ok+1;
	}

	it618_cpmsg(it618_union_getlang('s218').$ok, "plugin.php?id=it618_union:sc_quan$adminsid&page=$page".$sql, 'succeed');
}

it618_showformheader("plugin.php?id=it618_union:sc_quan$adminsid");
showtableheaders(it618_union_getlang('s176'),'it618_union_sum');
	echo '<tr><td colspan=14>'.it618_union_getlang('s219').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_union_getlang('s220').' <select name="it618_type"><option value="0">'.it618_union_getlang('s221').'</option><option value="1">'.it618_union_getlang('s222').'</option><option value="2">'.it618_union_getlang('s223').'</option></select> '.it618_union_getlang('s224').' <select name="state"><option value=0 '.$state0.'>'.it618_union_getlang('s225').'</option><option value=1 '.$state1.'>'.it618_union_getlang('s226').'</option><option value=2 '.$state2.'>'.it618_union_getlang('s227').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_union_getlang('s231').'" /></td></tr>';
	
	$count = C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid($ShopType,$ShopId,$it618sql,'',$_GET['key'],$_GET['it618_type']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_union:sc_quan$adminsid".$urlsql);
	
	echo '<tr><td colspan=15>'.it618_union_getlang('s232').$count.'<span style="float:right;">'.it618_union_getlang('s233').'</span></td></tr>';
	showsubtitle(array('',it618_union_getlang('s228'),it618_union_getlang('s229'),it618_union_getlang('s230')));
	
	$n=1;
	foreach(C::t('#it618_union#it618_union_quan')->fetch_all_by_shoptype_shopid(
		$ShopType,$ShopId,$it618sql,$it618orderby,$_GET['key'],$_GET['it618_type'],$startlimit,$ppp
	) as $it618_union_quan) {
		
		if($it618_union_quan['it618_ison']==1){
			$it618_ison='<font color=green>'.$it618_union_lang['s226'].'</font>';
		}else{
			$it618_ison='<font color=#999>'.$it618_union_lang['s227'].'</font>';
		}
		
		$pricestr='';
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_quan['it618_credit'.$i]>0){
				$pricestr.='<font color=#f60>'.$it618_union_quan['it618_credit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' , ';
			}
		}
		
		if($pricestr!=''){
			$pricestr=$pricestr.'@';
			$pricestr=str_replace(', @','',$pricestr);
		}else{
			$pricestr=$it618_union_lang['s256'];	
		}
		
		if($it618_union_quan['it618_xgtime']==0&&$it618_union_quan['it618_xgcount']==0){
			$xgstrcount=$it618_union_lang['s244'];
		}else{
			$xgstrcount=$it618_union_lang['s247'];
			$xgstrcount=str_replace("{time}",$it618_union_quan['it618_xgtime'],$xgstrcount);
			$xgstrcount=str_replace("{count}",$it618_union_quan['it618_xgcount'],$xgstrcount);
		}
		
		if($it618_union_quan['it618_xgtype']==0){
			$xgstrtime=$it618_union_lang['s244'];
		}else{
			if($it618_union_quan['it618_xgtype']==1){
				$xgstrtime=$it618_union_lang['s249'];
				
				$xgstrtime=str_replace("{dt1}",$it618_union_quan['it618_xgtime1'],$xgstrtime);
				$xgstrtime=str_replace("{dt2}",$it618_union_quan['it618_xgtime2'],$xgstrtime);
			}else{
				$timetmp1=explode(" ",$it618_union_quan['it618_xgtime1']);
				$timetmp2=explode(" ",$it618_union_quan['it618_xgtime2']);
				$d1=$timetmp1[0];
				$d2=$timetmp2[0];
				$t1=$timetmp1[1];
				$t2=$timetmp2[1];
				
				$xgstrtime=$it618_union_lang['s250'];
				
				$xgstrtime=str_replace("{d1}",$d1,$xgstrtime);
				$xgstrtime=str_replace("{d2}",$d2,$xgstrtime);
				$xgstrtime=str_replace("{t1}",$t1,$xgstrtime);
				$xgstrtime=str_replace("{t2}",$t2,$xgstrtime);
			}
		}
		
		if($it618_union_quan['it618_pids']==''){
			$it618_pids=$it618_union_lang['s547'];
		}else{
			$count=count(explode(",",$it618_union_quan['it618_pids']));
			$it618_pids='<a href="javascript:" onclick="showgoods(\'quan\','.$it618_union_quan['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
		}
		
		$preurl="plugin.php?id=it618_union:sc_quan$adminsid".$urlsql."&page=$page";
		$preurl=str_replace("&","@",$preurl);
		
		$tmpurl=it618_union_getrewrite('union_quan',$it618_union_quan['id'],'plugin.php?id=it618_union:union_quan&qid='.$it618_union_quan['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_union_quan['id'].'" '.$disabled.'><label for="chk_del'.$n.'">'.$it618_union_quan['id'].'</label>',
			'<div style="width:430px">
			<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_union_quan['it618_pic'].'" width="58" height="58" style="margin-right:6px" align="absmiddle"/></a>
			<div style="width:360px;float:left;line-height:20px"><a href="plugin.php?id=it618_union:sc_quan_edit'.$adminsid.'&qid='.$it618_union_quan['id'].'&preurl='.$preurl.'" style="float:right">'.$it618_union_lang['s234'].'</a>'.$it618_union_quan['it618_name'].'<br>
			'.it618_union_getquanoktime('quan',$it618_union_quan['it618_oktime1'],$it618_union_quan['it618_oktime2']).'<br>
			<span style="float:right"><font color=#999>'.$it618_union_lang['s243'].'</font>'.$it618_union_quan['it618_count'].' <font color=#999>'.$it618_union_lang['s251'].'</font>'.$it618_union_quan['it618_salecount'].'</span><font color=#999>'.$it618_union_lang['s242'].'</font>'.it618_union_getquantype($it618_union_quan).'
			</div></div>',
			'<div style="line-height:20px">'.$pricestr.'<br>
			'.$it618_pids.'<br>
			<font color=#999>'.$it618_union_lang['s245'].'</font>'.$xgstrcount.' <font color=#999>'.$it618_union_lang['s246'].'</font>'.$xgstrtime.'
			</div>',
			$it618_ison,
		));
				
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_union_getlang('s238').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_union_getlang('s235').'" onclick="return confirm(\''.it618_union_getlang('s239').'\')" /> <input type="submit" class="btn" name="it618submit_on" value="'.it618_union_getlang('s236').'"/> <input type="submit" class="btn" name="it618submit_noton" value="'.it618_union_getlang('s237').'"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter();

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_showgoods.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_footer.func.php';
?>