<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_header.func.php';

$tid=intval($_GET['tid']);
if($it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_id($tid)){
	if($ShopType!='group'){
		if($it618_union_tui['it618_shoptype']!=$ShopType||$it618_union_tui['it618_shopid']!=$ShopId){
			it618_cpmsg(it618_union_getlang('s329'), "", 'error');
		}
	}
}else{
	it618_cpmsg(it618_union_getlang('s328'), "", 'error');
}

if(submitcheck('it618submit')){	
	
	$pids_array = !empty($_GET['it618_pids']) ? $_GET['it618_pids'] : array();
	foreach($pids_array as $key => $value) {
		$pids.=intval($value).',';
	}
	if($pids!='')$pids=str_replace(",,","",$pids.',');

	$id=C::t('#it618_union#it618_union_tui')->update($tid,array(
		'it618_shoptype' => $ShopType,
		'it618_shopid' => $ShopId,
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_tcbl' => $_GET['it618_tcbl'],
		'it618_etime' => dhtmlspecialchars($_GET['it618_etime']),
		'it618_seokeywords' => dhtmlspecialchars($_GET['it618_seokeywords']),
		'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription']),
		'it618_pic' => dhtmlspecialchars($_GET['it618_pic']),
		'it618_pids' => $pids,
		'it618_message' => $_GET['it618_message']
	), true);
	
	$preurl=str_replace("@","&",$_GET['preurl']);
	it618_cpmsg(it618_union_getlang('s531'), $preurl, 'succeed');
}

it618_showformheader("plugin.php?id=it618_union:sc_tui_edit$adminsid&tid=$tid&preurl=".$_GET['preurl']);
showtableheaders(it618_union_getlang('s989'),'it618_union_tui');

if($ShopType=='video'){
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods')." where (it618_saleprice>0 or it618_score>0) and it618_state=1 and it618_shopid=$ShopId");
}
if($ShopType=='exam'){
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods')." where it618_gtype=1 and (it618_saleprice>0 or it618_score>0) and it618_state=1 and it618_shopid=$ShopId");
}
if($ShopType=='group'){
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_goods')." where (it618_saleprice>0 or it618_score>0) and it618_state=1");
}
if($ShopType=='brand'){
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods')." where (it618_uprice>0 or it618_score>0) and it618_ison=1 and it618_shopid=$ShopId");
}
if($ShopType=='tuan'){
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods')." where (it618_saleprice>0 or it618_score>0) and it618_state=1 and it618_shopid=$ShopId");
}

$tmparr=explode(",",$it618_union_tui['it618_pids']);
while($tmpgoods = DB::fetch($query)) {
	
	if($ShopType=='group'){
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($tmpgoods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$tmpgoods['it618_groupid']);
		$it618_unit=it618_union_getvipgoodsunit($tmpgoods);
		$tmpgoods['it618_name']=$grouptitle.' '.$it618_unit;
	}
	
	if(in_array($tmpgoods['id'],$tmparr)){
		$it618_pids_str.='<li><input type="checkbox" checked="checked" disabled="disabled" style="vertical-align:middle"><label style="color:#888">['.$tmpgoods['id'].'] '.$tmpgoods['it618_name'].'</label></li><input type="hidden" name="it618_pids[]" value="'.$tmpgoods['id'].'">';
	}else{
		$it618_pids_str.='<li><input type="checkbox" id="it618_pids'.$tmpgoods['id'].'" name="it618_pids[]" value="'.$tmpgoods['id'].'" style="vertical-align:middle"><label for="it618_pids'.$tmpgoods['id'].'" style="color:blue">['.$tmpgoods['id'].'] '.$tmpgoods['it618_name'].'</label></li>';
	}
}

$it618_union_lang['s995']=str_replace("{tcbl}",$it618_union_tui['it618_tcbl'],$it618_union_lang['s995']);
$it618_union_lang['s590']=str_replace("{tcbl}",$it618_union['union_tuitcbl'],$it618_union_lang['s590']);
$it618_union_lang['s516']=str_replace("{tcbl}",$it618_union['union_tuitcbl'],$it618_union_lang['s516']);
$it618_union_lang['s516']=str_replace("{viptcbl}",$it618_union['union_tuibigtcbl'],$it618_union_lang['s516']);

echo '
<link rel="stylesheet" href="source/plugin/it618_union/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_union/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/kindeditor/plugins/code/prettify.js"></script>
<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_union/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_union/kindeditor/php/upload_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'&imgwidth=930'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_union/kindeditor/php/file_manager_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false
		});
		
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_union/kindeditor/php/upload_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'&imgwidth=260'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_union/kindeditor/php/file_manager_json.php?shoptype='.$ShopType.'&shopid='.$ShopId.'\',
			allowFileManager : true
		});
		
		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#it618_pic\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
		
	});
	
	function checkvalue(){
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_union_getlang('s529').'");
			document.getElementById("it618_name").focus();
			return false;
		}
		
		if(document.getElementById("it618_pic").value==""){
			alert("'.it618_union_getlang('s530').'");
			return false;
		}
		
		if(document.getElementById("it618_tcbl").value==""){
			alert("'.it618_union_getlang('s526').'");
			document.getElementById("it618_tcbl").focus();
			return false;
		}else if(document.getElementById("it618_tcbl").value<'.$it618_union['union_tuitcbl'].'){
			alert("'.$it618_union_lang['s590'].'");
			document.getElementById("it618_tcbl").focus();
			return false;
		}else if(document.getElementById("it618_tcbl").value<'.$it618_union_tui['it618_tcbl'].'){
			alert("'.$it618_union_lang['s995'].'");
			document.getElementById("it618_tcbl").focus();
			return false;
		}else if(document.getElementById("it618_tcbl").value>60){
			alert("'.it618_union_getlang('s669').'");
			document.getElementById("it618_tcbl").focus();
			return false;
		}
		
		if(document.getElementById("it618_etime").value==""){
			alert("'.it618_union_getlang('s527').'");
			return false;
		}else{
			var etime="'.$it618_union_tui['it618_etime'].'";
			var newetime=document.getElementById("it618_etime").value;
			
			if(parseInt(newetime.replace(":","").replace(/-/g,"").replace(" ",""))<parseInt(etime.replace(":","").replace(/-/g,"").replace(" ",""))){
				alert("'.it618_union_getlang('s591').'");
				return false;
			}
		}
	}
	
	function check_all(obj)
	{
		var checkbox = document.getElementsByName("it618_pids[]");
		var checked_counts = 0;
		for(var i=0;i<checkbox.length;i++){
			
			checkbox[i].checked=obj.checked;
		}
	}
</script>

<style>
.goodsul{float:left;background-color:#f9f9f9;padding:10px}
.goodsul li{float:left;width:530px}
</style>

<tr><td colspan=2><font color=green>'.it618_union_getlang('s512').'</font></td></tr>
<tr><td width=80>'.it618_union_getlang('s513').'</td><td><input type="text" class="txt" style="width:400px;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_union_tui['it618_name'].'"></td></tr>
<tr><td>'.it618_union_getlang('s514').'</td><td><img id="img1" width="80" height="80" align="absmiddle" src="'.$it618_union_tui['it618_pic'].'"/> <input type="text" id="it618_pic" name="it618_pic" readonly="readonly" value="'.$it618_union_tui['it618_pic'].'"/> <input type="button" id="image1" value="'.it618_union_getlang('s191').'" /></td></tr>
<tr><td>'.it618_union_getlang('s519').'</td><td>
<div style="float:left;width:100%">
<ul class="goodsul">
'.$it618_pids_str.'
<li style="width:1000px"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="check_all(this)" /><label for="chkallDx4b" style="color:blue">'.it618_union_getlang('s238').'</label></li>
<li style="width:1000px"><font color=red>'.$it618_union_lang['s589'].'</font></li>
</ul>
</div>
</td></tr>
<tr><td>'.it618_union_getlang('s515').'</td><td><input type="text" class="txt" style="width:60px;margin-right:3px;color:red" id="it618_tcbl" name="it618_tcbl" value="'.$it618_union_tui['it618_tcbl'].'">% <font color=#999>'.$it618_union_lang['s516'].'</font></td></tr>
<tr><td>'.it618_union_getlang('s517').'</td><td><input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_etime" name="it618_etime" readonly="readonly" value="'.$it618_union_tui['it618_etime'].'"> '.$it618_union_tui['it618_etime'].' <font color=#999>'.$it618_union_lang['s518'].'</font></td></tr>
<tr><td>'.it618_union_getlang('s524').'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_union_tui['it618_message'].'</textarea></td></tr>
<tr><td>'.it618_union_getlang('s204').'</td><td><input type="text" class="txt" style="width:695px;margin-right:0" name="it618_seokeywords" value="'.$it618_union_tui['it618_seokeywords'].'"></td></tr>
<tr><td>'.it618_union_getlang('s205').'</td><td><textarea name="it618_seodescription" style="width:695px;height:50px;">'.$it618_union_tui['it618_seodescription'].'</textarea></td></tr>
<style>.laydate-btns-time{float:left}</style>
<script>
  laydate.render({
	elem: "#it618_etime"
	,type: "datetime"
	,format: "yyyy-MM-dd HH:mm"
  });
</script>
';

echo '<tr><td colspan=2><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_union_getlang('s206').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_footer.func.php';
?>