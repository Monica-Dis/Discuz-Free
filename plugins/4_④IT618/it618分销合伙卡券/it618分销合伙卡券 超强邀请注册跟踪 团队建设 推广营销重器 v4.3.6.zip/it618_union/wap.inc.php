<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_union = $_G['cache']['plugin']['it618_union'];
$metakeywords = $it618_union['seokeywords'];
$metadescription = $it618_union['seodescription'];
$sitetitle=$it618_union['seotitle'];

require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

if(!union_is_mobile()){
	$ispc=1;
}

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$waphome=it618_union_getrewrite('union_wap','','plugin.php?id=it618_union:wap');

if(isset($_GET['pagetype'])){
	$pagetypearray = array('index', 'myshare', 'quan', 'quans', 'tui', 'tuis', 'yqreg', 'myuser', 'yqjl', 'saletc', 'myquan', 'mytui', 'tuitc', 'u', 'myset');
	$pagetype = !in_array($_GET['pagetype'], $pagetypearray) ? 'index' : $_GET['pagetype'];
}else{
	$pagetype='index';
	$navtitle=$sitetitle;
}

$stylecount=C::t('#it618_union#it618_union_wapstyle')->count_by_isok_search();
$it618_union_wapstyle=C::t('#it618_union#it618_union_wapstyle')->fetch_by_isok_search();

if($_G['uid']>0){
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_union_getlang('s560').'</a></li>';
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_union_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_union_bottomnav = DB::fetch($query)) {
	$it618_url=$it618_union_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$tmpurl=it618_union_getrewrite('union_wap','','plugin.php?id=it618_union:wap');
	$it618_url=str_replace("{waphome}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='index'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapyqreg}",$it618_url);
	$tmpurl=it618_union_getrewrite('union_wap','yqreg','plugin.php?id=it618_union:wap&pagetype=yqreg');
	$it618_url=str_replace("{wapyqreg}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='yqreg'||$pagetype=='myuser'||$pagetype=='yqjl'||$pagetype=='saletc'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapquans}",$it618_url);
	$tmpurl=it618_union_getrewrite('union_wap','quans','plugin.php?id=it618_union:wap&pagetype=quans');
	$it618_url=str_replace("{wapquans}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='quans'||$pagetype=='myquan'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{waptuis}",$it618_url);
	$tmpurl=it618_union_getrewrite('union_wap','mytui','plugin.php?id=it618_union:wap&pagetype=mytui');
	$it618_url=str_replace("{waptuis}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='tuis'||$pagetype=='mytui'||$pagetype=='tuitc'){
			$iscur=1;
		}
	}
	
	if($it618_union_bottomnav['id']==5)$it618_url=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_union_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_union_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_union_bottomnav['it618_color'].'">'.$it618_union_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_union_bottomnav['it618_img'];
		$it618_title=$it618_union_bottomnav['it618_title'];
	}
	
	if($it618_union_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_union_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$wap=1;

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_union['union_appid']);
	$wx_secret=trim($it618_union['union_appsecret']);
}

if($pagetype=='myshare'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php';
	}
	
	$wxshare_title=$share_name;
	$wxshare_imgUrl=$share_img;
	$tmparr=explode('://',$wxshare_imgUrl);
	if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
	$wxshare_desc=$share_des;
	$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
	$wxshare_link=$myshareurl;
	
}else{
	$wxshare_title=$it618_union['seotitle'];
	$wxshare_imgUrl=$it618_union['union_logo'];
	$tmparr=explode('://',$wxshare_imgUrl);
	if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
	$wxshare_desc=$it618_union['seodescription'];
	$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
	$wxshare_link=$_G['siteurl'].it618_union_getrewrite('union_wap','','plugin.php?id=it618_union:wap');
}

if($wx_appid!=''&&$wx_secret!=''){
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl, DISCUZ_ROOT);
		$signPackage = $wxshare->getSignPackage();
	}
}

$pagetypearray = array('yqreg', 'myuser', 'yqjl', 'saletc', 'myquan', 'mytui', 'tuitc');

if($pagetype=='yqreg'){$navtitle=it618_union_getlang('s162').' - '.$sitetitle;$current_yqreg='class="current"';}
if($pagetype=='myuser'){$navtitle=it618_union_getlang('s163').' - '.$sitetitle;$current_myuser='class="current"';}
if($pagetype=='saletc'){$navtitle=it618_union_getlang('s166').' - '.$sitetitle;$current_saletc='class="current"';}

if($pagetype=='quans'){$navtitle=it618_union_getlang('t91').' - '.$sitetitle;$current_quans='class="current"';}
if($pagetype=='myquan'){$navtitle=it618_union_getlang('s169').' - '.$sitetitle;$current_myquan='class="current"';}

if($pagetype=='tuis'){$navtitle=it618_union_getlang('s282').' - '.$sitetitle;$current_tuis='class="current"';}
if($pagetype=='mytui'){$navtitle=it618_union_getlang('s172').' - '.$sitetitle;$current_mytui='class="current"';}
if($pagetype=='tuitc'){$navtitle=it618_union_getlang('s173').' - '.$sitetitle;$current_tuitc='class="current"';}

$url_yqreg=it618_union_getrewrite('union_wap','yqreg','plugin.php?id=it618_union:wap&pagetype=yqreg');
$url_myuser=it618_union_getrewrite('union_wap','myuser','plugin.php?id=it618_union:wap&pagetype=myuser');
$url_saletc=it618_union_getrewrite('union_wap','saletc','plugin.php?id=it618_union:wap&pagetype=saletc');
$url_myset=it618_union_getrewrite('union_wap','myset','plugin.php?id=it618_union:wap&pagetype=myset');

$url_quans=it618_union_getrewrite('union_wap','quans','plugin.php?id=it618_union:wap&pagetype=quans');
$url_myquan=it618_union_getrewrite('union_wap','myquan','plugin.php?id=it618_union:wap&pagetype=myquan');

$url_tuis=it618_union_getrewrite('union_wap','tuis','plugin.php?id=it618_union:wap&pagetype=tuis');
$url_mytui=it618_union_getrewrite('union_wap','mytui','plugin.php?id=it618_union:wap&pagetype=mytui');
$url_tuitc=it618_union_getrewrite('union_wap','tuitc','plugin.php?id=it618_union:wap&pagetype=tuitc');

$wapbottomsubnav=C::t('#it618_union#it618_union_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_union#it618_union_set')->getsetvalue_by_setname('wapbottomsubnavdefault');

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
	if($appurl=it618_members_apploginok($_GET['token'])){
		dheader("location:$appurl");
	}
}

$laydate='<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>';

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_wapad=it618_group_getad($_GET['id'],1);
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/it618_api.func.php';

if(in_array($pagetype, $pagetypearray)){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/wap/uc.inc.php';
}else{
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/wap/'.$pagetype.'.inc.php';	
}
?>