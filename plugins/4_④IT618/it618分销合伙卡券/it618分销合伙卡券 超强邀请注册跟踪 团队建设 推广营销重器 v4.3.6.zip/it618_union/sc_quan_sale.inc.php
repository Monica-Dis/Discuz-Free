<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_header.func.php';

$urlsql='&finduid='.$_GET['finduid'].'&it618_type='.$_GET['it618_type'].'&state='.$_GET['state'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

$it618sql='1=1';
if($_GET['finduid']>0)$it618sql.=' and it618_uid='.intval($_GET['finduid']);
if($_GET['it618_type']==1){$it618_type1='selected="selected"';}
if($_GET['it618_type']==2){$it618_type2='selected="selected"';}
if($_GET['state']==1){$it618sql.=' and it618_state=0';$state1='selected="selected"';}
if($_GET['state']==2){$it618sql.=' and it618_state=1';$state2='selected="selected"';}

it618_showformheader("plugin.php?id=it618_union:sc_quan_sale$adminsid".$urlsql);
showtableheaders(it618_union_getlang('s504'),'it618_union_sum');
	echo '<tr><td colspan=14>'.it618_union_getlang('s266').' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:80px" /> '.it618_union_getlang('s220').' <select name="it618_type"><option value="0">'.it618_union_getlang('s221').'</option><option value="1" '.$it618_type1.'>'.it618_union_getlang('s222').'</option><option value="2" '.$it618_type2.'>'.it618_union_getlang('s223').'</option></select> '.it618_union_getlang('s224').' <select name="state"><option value=0 '.$state0.'>'.it618_union_getlang('s225').'</option><option value=1 '.$state1.'>'.it618_union_getlang('s263').'</option><option value=2 '.$state2.'>'.it618_union_getlang('s264').'</option></select> '.$it618_union_lang['s272'].' <input id="it618_time1" name="it618_time1" class="txt" style="width:80px;margin-right:0;" readonly value="'.$_GET['it618_time1'].'"/> - <input id="it618_time2" name="it618_time2" class="txt" style="width:83px;" readonly value="'.$_GET['it618_time2'].'"/> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_union_getlang('s231').'" /></td></tr>';
	
	$count = C::t('#it618_union#it618_union_quansale')->count_by_shoptype_shopid($ShopType,$ShopId,$it618sql,'','',$_GET['it618_type'],$_GET['it618_time1'],$_GET['it618_time2']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_union:sc_quan_sale$adminsid".$urlsql);
	
	echo '<tr><td colspan=15>'.it618_union_getlang('s232').$count.'<span style="float:right;">'.it618_union_getlang('s265').'</span></td></tr>';
	showsubtitle(array('',it618_union_getlang('s259'),it618_union_getlang('s260'),it618_union_getlang('s261'),it618_union_getlang('s262')));
	
	$n=1;
	foreach(C::t('#it618_union#it618_union_quansale')->fetch_all_by_shoptype_shopid(
		$ShopType,$ShopId,$it618sql,'id desc','',$_GET['it618_type'],$_GET['it618_time1'],$_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_quansale) {
		
		if($it618_union_quansale['it618_qid']>0){
			$it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_id($it618_union_quansale['it618_qid']);
			$it618_pic=$it618_union_quan['it618_pic'];
			$it618_name=$it618_union_quan['it618_name'];
		}else{
			$it618_pic=$it618_union_quansale['it618_pic'];
			$it618_name=$it618_union_quansale['it618_name'];
		}
		
		$pricestr='';
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_quansale['it618_credit'.$i]>0){
				$pricestr.='<font color=#f60>'.$it618_union_quansale['it618_credit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' , ';
			}
		}
		
		if($pricestr!=''){
			$pricestr=$pricestr.'@';
			$pricestr=str_replace(', @','',$pricestr);
		}else{
			if($it618_union_quansale['it618_qid']>0){
				$pricestr=$it618_union_lang['s256'];	
			}else{
				$pricestr=$it618_union_lang['s694'];
			}
		}
		
		if($it618_union_quansale['it618_state']==0){
			$it618_state='<font color=red>'.$it618_union_lang['s263'].'</font>';
			$timestr=''.it618_union_getquanoktime('quan',$it618_union_quansale['it618_oktime1'],$it618_union_quansale['it618_oktime2']).' ';
		}else{
			$it618_state='<font color=green>'.$it618_union_lang['s264'].'</font>';
			$timestr='';
		}
		
		if($it618_union_quansale['it618_pids']==''){
			$it618_pids=$it618_union_lang['s547'];
		}else{
			$count=count(explode(",",$it618_union_quansale['it618_pids']));
			$it618_pids='<a href="javascript:" onclick="showgoods(\'quansale\','.$it618_union_quansale['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
		}
		
		$tmpurl=it618_union_getrewrite('union_quan',$it618_union_quansale['it618_qid'],'plugin.php?id=it618_union:union_quan&qid='.$it618_union_quansale['it618_qid']);
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			$it618_union_quansale[id],
			'<div style="width:330px">
			<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_pic.'" width="38" height="38" style="margin-right:6px" align="absmiddle"/></a>
			<div style="width:280px;float:left;line-height:20px">'.$it618_name.'<br>
			'.it618_union_getquantype($it618_union_quansale).'
			</div></div>',
			'<div style="line-height:20px">'.$pricestr.'<br>
			'.$it618_pids.'
			</div>',
			$timestr.'
			'.it618_union_getusername($it618_union_quansale['it618_uid']).'<br><font color=#999>'.date('Y-m-d H:i:s', $it618_union_quansale['it618_time']).'</font>
			',
			$it618_state,
		));
				
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div></td></tr>
	<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>
	<script>
	laydate.render({
	  elem: "#it618_time1"
	});
	laydate.render({
	  elem: "#it618_time2"
	});
	</script>
	';

showtablefooter();

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_showgoods.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_footer.func.php';
?>