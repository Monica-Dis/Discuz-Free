<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_header.func.php';

$urlsql='&finduid='.$_GET['finduid'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

$it618sql='1=1';
if($_GET['finduid']>0)$it618sql.=' and it618_uid='.intval($_GET['finduid']);

it618_showformheader("plugin.php?id=it618_union:sc_tui_join$adminsid".$urlsql);
showtableheaders(it618_union_getlang('s510'),'it618_union_sum');
	echo '<tr><td colspan=14>'.it618_union_getlang('s266').' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:80px" />'.$it618_union_lang['s568'].' <input id="it618_time1" name="it618_time1" class="txt" style="width:80px;margin-right:0;" readonly value="'.$_GET['it618_time1'].'" /> - <input id="it618_time2" name="it618_time2" class="txt" style="width:83px;" readonly value="'.$_GET['it618_time2'].'"/> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_union_getlang('s231').'" /></td></tr>';
	
	$count = C::t('#it618_union#it618_union_tuijoin')->count_by_shoptype_shopid($ShopType,$ShopId,$it618sql,'','',$_GET['it618_time1'],$_GET['it618_time2']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_union:sc_tui_join$adminsid".$urlsql);
	
	echo '<tr><td colspan=15>'.it618_union_getlang('s569').$count.'<span style="float:right;">'.it618_union_getlang('s588').'</span></td></tr>';
	showsubtitle(array('',it618_union_getlang('s532'),it618_union_getlang('s533'),it618_union_getlang('s534'),it618_union_getlang('s535'),it618_union_getlang('s587'),it618_union_getlang('s568')));
	
	$n=1;
	foreach(C::t('#it618_union#it618_union_tuijoin')->fetch_all_by_shoptype_shopid(
		$ShopType,$ShopId,$it618sql,'id desc','',$_GET['it618_time1'],$_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_tuijoin) {
		
		$it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_id($it618_union_tuijoin['it618_tid']);
		
		$count=count(explode(",",$it618_union_tui['it618_pids']));
		$it618_pids='<a href="javascript:" onclick="showgoods(\'tui\','.$it618_union_tui['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
		
		$tmpurl=it618_union_getrewrite('union_tui',$it618_union_tui['id'],'plugin.php?id=it618_union:union_tui&tid='.$it618_union_tui['id']);
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			$it618_union_tuijoin[id],
			'<div style="width:430px">
			<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_union_tui['it618_pic'].'" width="38" height="38" style="margin-right:6px" align="absmiddle"/></a>
			<div style="width:360px;float:left;line-height:20px">'.$it618_union_tui['it618_name'].'</div>
			</div>',
			$it618_pids,
			'<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font>',
			$it618_union_tui['it618_etime'],
			it618_union_getusername($it618_union_tuijoin['it618_uid']),
			'<font color=#999>'.date('Y-m-d H:i:s', $it618_union_tuijoin['it618_time']).'</font>',
		));
				
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div></td></tr>
	<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>
	<script>
	laydate.render({
	  elem: "#it618_time1"
	});
	laydate.render({
	  elem: "#it618_time2"
	});
	</script>
	';

showtablefooter();

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_showgoods.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_footer.func.php';
?>