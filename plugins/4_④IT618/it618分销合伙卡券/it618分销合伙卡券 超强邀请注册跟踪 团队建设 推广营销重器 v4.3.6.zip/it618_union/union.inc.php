<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$tuipower=1;
$tuiuid=intval($_GET['tuiuid']);
if($tuiuid>0){
	$usercount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$tuiuid);
	if($usercount>0){
		if($it618_union['union_yqpowermode']==1||$it618_union['union_yqpowermode']==3){
			$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
			
			if($union_tuigroup[0]!=''){
				$tmpgrouparr=it618_union_getisvipuser($union_tuigroup);
				if(count($tmpgrouparr[0])==0){
					$tuipower=0;
				}
			}
		}
		if($it618_union['union_yqpowermode']==2||$it618_union['union_yqpowermode']==3){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($tuiuid)==0){
				$tuipower=0;
			}
		}
	}
}

if($tuipower==1){
	if($it618_union['union_cookietime']==0)$union_cookietime=3600;else $union_cookietime=$it618_union['union_cookietime']*3600;
	dsetcookie('it618_union_tuiuid',$tuiuid,$union_cookietime);
	
	if(union_is_mobile()){
		if($it618_union['union_wapurl']!='')$union_url=$it618_union['union_wapurl'];
	}else{
		if($it618_union['union_pcurl']!='')$union_url=$it618_union['union_pcurl'];
	}
	if($union_url==''){
		$regname=$_G['setting']['regname'];
		dheader("location:member.php?mod=$regname&tuiuid=".$_GET['tuiuid']);
	}else{
		dheader("location:".$union_url);
	}
}else{
	dheader("location:".$_G['siteurl']);
}

?>