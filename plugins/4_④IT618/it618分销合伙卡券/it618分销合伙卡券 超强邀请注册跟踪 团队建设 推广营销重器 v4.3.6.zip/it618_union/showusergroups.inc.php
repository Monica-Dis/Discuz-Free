<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_union = $_G['cache']['plugin']['it618_union'];
require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$uid = intval($_GET['uid']);
$tuiuid = intval($_GET['tuiuid']);

if($tuiuid>0){
	if(!$it618_union_reguser=DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." WHERE it618_tuiuid=".$_G['uid']." and it618_uid=$tuiuid")){
		echo $it618_union_lang['s1004'];exit;
	}else{
		if(!$it618_union_reguser=DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." WHERE it618_tuiuid=".$tuiuid." and it618_uid=$uid")){
			echo $it618_union_lang['s1004'];exit;
		}
	}
}else{
	if(!$it618_union_reguser=DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." WHERE it618_tuiuid=".$_G['uid']." and it618_uid=$uid")){
		echo $it618_union_lang['s1004'];exit;
	}
}

require_once libfile('function/member');
$member=getuserbyuid($uid, 1);
$extgroupids = $member['extgroupids'] ? explode("\t", $member['extgroupids']) : array();
		
$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
$groupterms = dunserialize($memberfieldforum['groupterms']);
unset($memberfieldforum);
$expgrouparray = $expirylist = $termsarray = array();

if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
	$termsarray = $groupterms['ext'];
}
if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
	$termsarray[$_G['groupid']] = $groupterms['main']['time'];
}

foreach($termsarray as $expgroupid => $expiry) {
	if($expiry <= TIMESTAMP) {
		$expgrouparray[] = $expgroupid;
	}
}

if(!empty($groupterms['ext'])) {
	foreach($groupterms['ext'] as $extgroupid => $time) {
		$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => date('Y-m-d H:i:s', $time), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
	}
}

if(!empty($groupterms['main'])) {
	$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => date('Y-m-d H:i:s', $groupterms['main']['time']), 'type' => 'main');
}

$groupids = array();
foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
	if(!empty($usergroup['pubtype'])) {
		$groupids[] = $groupid;
	}
}

$expiryids = array_keys($expirylist);

$groupids = array_merge($extgroupids, $expiryids, $groupids);

$tmpgroups=implode(',',$groupids);
DB::query("UPDATE ".DB::table('it618_union_reguser')." SET it618_groupid=".$member['groupid'].",it618_groups='".$tmpgroups."' where it618_uid=".$uid);

if($tmpgroups!=''){
	$tmparr=explode(",",$tmpgroups);
	for($i=0;$i<count($tmparr);$i++){
		if($tmparr[$i]>0){
			$groupcount=$groupcount+1;
			$grouptitles.=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$tmparr[$i]).'<br>';
		}
	}
}

echo $grouptitles;
?>