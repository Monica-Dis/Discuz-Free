<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_witkey_main`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_title` varchar(300) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_fid` int(10) unsigned NOT NULL,
  `it618_typeid` int(10) unsigned NOT NULL,
  `it618_mode` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_read` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_hfread` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_select` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_editcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mancount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bmmoney` float(9,2) NOT NULL,
  `it618_uids` varchar(800) NOT NULL,
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_moneycount1` float(9,2) NOT NULL,
  `it618_moneycount2` float(9,2) NOT NULL,
  `it618_getwitkeymoney` float(9,2) NOT NULL,
  `it618_tc` float(9,2) NOT NULL,
  `it618_jlbl` float(9,2) NOT NULL,
  `it618_jl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_attachment` varchar(255) NOT NULL,
  `it618_attachmentsize` float(9,3) NOT NULL,
  `it618_postbz` varchar(8000) NOT NULL,
  `it618_getbz` varchar(8000) NOT NULL,
  `it618_attachmenttime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_postbztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_getbztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_creditnum` float(9,2) NOT NULL,
  `it618_getwitkeymoney` float(9,2) NOT NULL,
  `it618_bmmoney` float(9,2) NOT NULL,
  `it618_jlbl` float(9,2) NOT NULL,
  `it618_jl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc` float(9,2) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_pf`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_pf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_postuid` int(10) unsigned NOT NULL,
  `it618_getuid` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_gettime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_getwitkeymoney` float(9,2) NOT NULL,
  `it618_bmmoney` float(9,2) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_user`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(11) NOT NULL,
  `it618_bztel` varchar(11) NOT NULL,
  `it618_qq` varchar(20) NOT NULL,
  `it618_wx` varchar(80) NOT NULL,
  `it618_bz` varchar(800) NOT NULL,
  `it618_msgisok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_grouppower`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_grouppower` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_posttc` float(9,2) NOT NULL,
  `it618_gettc` float(9,2) NOT NULL,
  `it618_postjlbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_getjlbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_bmmoney` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_findtid`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_findtid` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_fid` int(10) unsigned NOT NULL,
  `it618_wid` int(10) unsigned NOT NULL,
  `it618_title` varchar(1000) NOT NULL,
  `it618_tid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_it618`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_it618` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_witkey` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_sql` varchar(100) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_witkey_findkey`;
CREATE TABLE IF NOT EXISTS `pre_it618_witkey_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

if(isset($_GET['pluginid'])&&$_GET['pluginid']!=''){
	DB::query("insert into ".DB::table('it618_witkey_it618')."(it618_witkey) values ('".addslashes($_GET['dir'])."')");
}else{
	DB::query("insert into ".DB::table('it618_witkey_it618')."(it618_witkey) values ('it618_witkey')");
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>