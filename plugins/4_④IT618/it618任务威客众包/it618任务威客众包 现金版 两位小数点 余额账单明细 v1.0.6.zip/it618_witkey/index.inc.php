<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsCredits,$it618_witkey;

require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/function.func.php';
$navtitle = $it618_witkey['seotitle'];
$metakeywords = $it618_witkey['seokeywords'];
$metadescription = $it618_witkey['seodescription'];

if(witkey_is_mobile()){
	$tmpurl=it618_witkey_getrewrite('witkey_wap','','plugin.php?id=it618_witkey:wap');
	dheader("location:$tmpurl");
}

$n=1;
$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'witkeyclass1\',0,0)" name="witkeyclass1"><span>'.$it618_witkey_lang['s396'].'</span></a>';
$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
foreach($witkey_forums as $key => $fid) {
	$tmpforumname=it618_witkey_getforumname($fid);
	if($tmpforumname!=''){
		$classtmp.='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'witkeyclass1\','.$n.','.$fid.')" name="witkeyclass1"><span>'.$tmpforumname.'</span></a>';
		$n=$n+1;
	}
}

$il1i1l=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$il1i1l[]=substr($_GET['id'],$i,1);}
if(count($il1i1l)!=12)return;
if($il1i1l[6]!='w')return;

if($_G['uid']>0){
	$menuusername=$_G['username'];
	$u_avatarimg=it618_witkey_discuz_uc_avatar($_G['uid'],'middle');
	$moneyname=$it618_witkey_lang['s201'];
	$creditnum=it618_witkey_getumoney($_G['uid']);
	
	$postcount = C::t('#it618_witkey#it618_witkey_main')->count_by_search('','',$_G['uid'],0);
	$postmoney = C::t('#it618_witkey#it618_witkey_main')->sum_jlmoney_by_search('','',$_G['uid'],0);
	if($postmoney=='')$postmoney=0;
	
	$getcount = C::t('#it618_witkey#it618_witkey_main')->count_by_search('','',0,$_G['uid']);
	$getmoney = C::t('#it618_witkey#it618_witkey_main')->sum_jlmoney_by_search('','',0,$_G['uid']);
	if($getmoney=='')$getmoney=0;
	
	$postpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_witkey_pf')." WHERE it618_postuid=".$_G['uid']);
	$getpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_witkey_pf')." WHERE it618_getuid=".$_G['uid']);
	
	$postpfmoney = DB::result_first("SELECT sum(it618_getwitkeymoney) FROM ".DB::table('it618_witkey_pf')." WHERE it618_postuid=".$_G['uid']);
	$getpfmoney = DB::result_first("SELECT sum(it618_getwitkeymoney) FROM ".DB::table('it618_witkey_pf')." WHERE it618_getuid=".$_G['uid']);
	
	$wappostpf=it618_witkey_getrewrite('witkey_wap','pf@1@'.$_G['uid'],'plugin.php?id=it618_witkey:wap&pagetype=pf&cid=1&uid='.$_G['uid']);
	$wapgetpf=it618_witkey_getrewrite('witkey_wap','pf@2@'.$_G['uid'],'plugin.php?id=it618_witkey:wap&pagetype=pf&cid=2&uid='.$_G['uid']);
}

$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
$forumcount=count($witkey_forums);

if($forumcount==1){
	$posttmp='href="forum.php?mod=post&action=newthread&fid='.$witkey_forums[0].'&paytype=money" target="_blank"';
}else{
	$posttmp='href="javascript:" onclick="showpost()"';
}

//�ֲ�
$witkey_focus_pics = $it618_witkey['witkey_focus_pics'];
$witkey_focus_pics=explode("|",str_replace(array("\r\n", "\r", "\n"), '|', $it618_witkey['witkey_focus_pics']));
if($il1i1l[5]!='_')return;
foreach($witkey_focus_pics as $key => $witkey_focus_pic){
	if($witkey_focus_pic!=""){
		$tmparr=explode("==",$witkey_focus_pic);
		$str_focus.='<div><a href="'.$tmparr[1].'" target="_blank"><img src="'.$tmparr[0].'"/></a></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_witkey_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_witkey_gonggao = DB::fetch($query)) {
	$it618_title=$it618_witkey_gonggao['it618_title'];
	
	if($it618_witkey_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_witkey_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_witkey_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_witkey_gonggao['it618_url'].'" target="_blank" title="'.$it618_witkey_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

//��������
$query = DB::query("SELECT it618_uid,count(1) as witkeycount FROM ".DB::table('it618_witkey_main')." group by it618_uid order by witkeycount desc limit 0,".$it618_witkey['witkey_rightcount']);
$n=1;
while($it618_witkey_witkey =DB::fetch($query)) {
	$uid=$it618_witkey_witkey['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$postph.='<li><span style="float:right"><font color=red>'.$it618_witkey_witkey['witkeycount'].'</font> '.it618_witkey_getlang('s331').'</span><span class="phnum'.$tmpcss.'">'.$n.'</span><a href="home.php?mod=space&uid='.$uid.'" target="_blank">'.it618_witkey_getauthor($uid).'</a></li>';
	$n=$n+1;
}
$postph=it618_witkey_rewriteurl($postph);
$il1i1l=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$il1i1l[]=substr($_GET['id'],$i,1);}
if($il1i1l[9]!='k')return;

//�н�����
$query = DB::query("SELECT it618_uid,count(1) as getcount FROM ".DB::table('it618_witkey')." group by it618_uid order by getcount desc limit 0,".$it618_witkey['witkey_rightcount']);
$n=1;
while($it618_witkey_witkey =DB::fetch($query)) {
	$uid=$it618_witkey_witkey['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$getph.='<li><span style="float:right"><font color=red>'.$it618_witkey_witkey['getcount'].'</font> '.it618_witkey_getlang('s331').'</span><span class="phnum'.$tmpcss.'">'.$n.'</span><a href="home.php?mod=space&uid='.$uid.'" target="_blank">'.it618_witkey_getauthor($uid).'</a></li>';
	$n=$n+1;
}
$getph=it618_witkey_rewriteurl($getph);
if($il1i1l[6]!='w')return;

//��������
$query = DB::query("SELECT it618_uid,sum(it618_creditnum) as money FROM ".DB::table('it618_witkey')." group by it618_uid order by money desc limit 0,".$it618_witkey['witkey_rightcount']);
$n=1;
while($it618_witkey_witkey =DB::fetch($query)) {
	$uid=$it618_witkey_witkey['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$moneyph.='<li><span style="float:right"><font color=red>'.$it618_witkey_witkey['money'].'</font> '.$witkey_moneyname.'</span><span class="phnum'.$tmpcss.'">'.$n.'</span><a href="home.php?mod=space&uid='.$uid.'" target="_blank">'.it618_witkey_getauthor($uid).'</a></li>';
	$n=$n+1;
}
$moneyph=it618_witkey_rewriteurl($moneyph);
if($il1i1l[6]!='w')return;

//����н�
$query = DB::query("SELECT * FROM ".DB::table('it618_witkey')." order by id desc LIMIT 0, 10");
while($it618_witkey_witkey = DB::fetch($query)) {

	$username=it618_witkey_getauthor($it618_witkey_witkey['it618_uid']);
	$subject=it618_witkey_getsubject($it618_witkey_witkey['it618_tid']);
	
	$newgetwitkeylist.='<li><font color=red>'.it618_witkey_it618_witkey_gettime($it618_witkey_witkey['it618_time']).'</font> <font color="#333333">'.$username.'</font> '.it618_witkey_getlang('s332').'<br>[<a href="forum.php?mod=viewthread&tid='.$it618_witkey_witkey['it618_tid'].'" target="_blank">'.$subject.'</a>]</li>';
}
$newgetwitkeylist=it618_witkey_rewriteurl($newgetwitkeylist);

//�������
$query = DB::query("SELECT * FROM ".DB::table('it618_witkey')." where it618_creditnum>0 order by id desc LIMIT 0, 10");
while($it618_witkey_witkey = DB::fetch($query)) {

	$username=it618_witkey_getauthor($it618_witkey_witkey['it618_uid']);
	$subject=it618_witkey_getsubject($it618_witkey_witkey['it618_tid']);
	
	$newgetmoney.='<li><font color=red>'.it618_witkey_it618_witkey_gettime($it618_witkey_witkey['it618_time']).'</font> <font color="#333333">'.$username.'</font> '.it618_witkey_getlang('s333').' [<a href="forum.php?mod=viewthread&tid='.$it618_witkey_witkey['it618_tid'].'" target="_blank">'.$subject.'</a>] '.it618_witkey_getlang('s334').'<font color=red>'.$it618_witkey_witkey['it618_creditnum'].'</font> '.$witkey_moneyname.'</li>';
}
$newgetmoney=it618_witkey_rewriteurl($newgetmoney);

$listwitkey=getwitkeylist();

$w4=708;$w8=680;
if($it618_witkey['witkey_width']>960){
	$w=$it618_witkey['witkey_width']-960;
	$w1=960+$w;$w2=716+$w;$w3=710+$w;$w4=708+$w-6;$w5=680+$w-6;$w6=698+$w;$w7=704+$w;$w8=693+$w-6;
	
	$strcss='<style>
			.grid_c2a{width:'.$w1.'px;}
			.mainbar,#goodsfind,.mod_auction_goods,.game_act_filter{width:'.$w2.'px;}
			#slides-thumbnail,.game_act_filter{width:'.$w3.'px}
			#slides-thumbnail .slidesjs-slide img{width:'.$w4.'px;height:'.$it618_witkey['witkey_foucsheight'].'px;}
			.finddiv{width:'.$w5.'px;}
			.finddiv1{width:'.($w5+10).'px;}
			.witkeylisttable tr td a{font-size:14px}
			</style>';
}

$moden=0;
$witkey_modes=(array)unserialize($it618_witkey['witkey_modes']);
if(!in_array(1, $witkey_modes)){$mode1='style="display:none"';$moden=$moden+1;}
if(!in_array(2, $witkey_modes)){$mode2='style="display:none"';$moden=$moden+1;}
if(!in_array(3, $witkey_modes)){$mode3='style="display:none"';$moden=$moden+1;}

if($IsCredits==1){
	$tmpuser1='<a class="it618_credits" href="javascript:">';
	$tmpuser2='</a>';
}

$allcount = C::t('#it618_witkey#it618_witkey_main')->count_by_search();
$allmoney = C::t('#it618_witkey#it618_witkey_main')->sum_jlmoney_by_search();

include template('it618_witkey:index');
?>