<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/function.func.php';

$type=intval($_GET['type']);
$tid=intval($_GET['tid']);
$uid=intval($_GET['uid']);

$adminauthor=0;
if($_G['uid']>0){
	$tmpwitkeyadmin=explode(",",$it618_witkey['witkey_witkeyadmin']);
	for($tmpi=0;$tmpi<count($tmpwitkeyadmin);$tmpi++){
	   if($_G['uid']==$tmpwitkeyadmin[$tmpi]){
		   $adminauthor=1;
		   break;
	   }
	}
}

if($type<=0||$tid<=0||$uid<=0)$errstr=$it618_witkey_lang['s555'];

if($it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." where it618_tid=".$tid)){
	if($adminauthor==0){
		if($type==1){
			$getwitkeycounttmp=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_tid=".$it618_witkey_main['it618_tid']." and it618_uid=".$_G['uid']);
			if($getwitkeycounttmp==0)$errstr=$it618_witkey_lang['s556'];
		}else{
			if($it618_witkey_main['it618_uid']!=$_G['uid'])$errstr=$it618_witkey_lang['s556'];
		}
	}
}else{
	$errstr=$it618_witkey_lang['s555'];
}

if($errstr==''){
	$it618_witkey_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_user')." where it618_uid=".$uid);
	
	$it618_bztel=$it618_witkey_user['it618_tel'];
	$it618_tel=$it618_witkey_user['it618_tel'];
	$it618_qq=$it618_witkey_user['it618_qq'];
	$it618_wx=$it618_witkey_user['it618_wx'];
	
	if($it618_witkey['witkey_rzdatatype']==1){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$uid)){
				$it618_bztel=$it618_members_user['it618_tel'];
			}
		}
	}
	
	if($it618_witkey['witkey_rzdatatype']==2){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$uid)){
				$it618_bztel=$it618_members_rzuser['it618_tel'];
				$it618_qq=$it618_members_rzuser['it618_qq'];
				$it618_wx=$it618_members_rzuser['it618_wx'];
			}
		}
	}
	
	$allpostcount = C::t('#it618_witkey#it618_witkey_main')->count_by_search('','',$uid,0);
	$allwitkeycount =C::t('#it618_witkey#it618_witkey_main')->count_by_search('','',0,$uid);
	
	$allpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_witkey_pf')." WHERE it618_getuid=".$uid);
	
	if($allpfcount==0){
		$pfcss='green';
	}else{
		$pfcss='red';
	}
	
	$pfstr=$it618_witkey_lang['s978'].'<font color="'.$pfcss.'">'.$allpfcount.'</font>'.$it618_witkey_lang['s979'];
	
	if($it618_qq!=''){
		$qqstr='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$it618_qq.'&site=qq&menu=yes"><img src="source/plugin/it618_witkey/images/qq.png" align="absmiddle" style="border:none"/></a> '.$it618_qq;
	}else{
		$qqstr=$it618_witkey_lang['s965'];
	}
	
	if($it618_bztel!=''){
		if($_GET['wap']==1){
			$bztelstr='<a href="tel://'.$it618_bztel.'"><img src="source/plugin/it618_witkey/images/tel.png" align="absmiddle" style="border:none; width:22px;margin-left:2px"/></a>  '.$it618_bztel;
		}else{
			$bztelstr=$it618_bztel;
		}
	}else{
		$bztelstr=$it618_witkey_lang['s965'];
	}
	
	if($it618_wx!=''){
		$wxstr=$it618_wx;
	}else{
		$wxstr=$it618_witkey_lang['s965'];
	}
	
	$tmpstr= '
	<tr><td><font color=green><b>'.it618_witkey_getusername($uid).'</b></font> <a href="javascript:" style="text-decoration:none" onclick="showwitkey(10001,'.$uid.')">'.it618_witkey_getlang('s348').'(<font color="red">'.$allpostcount.'</font>)</a> <a href="javascript:" style="text-decoration:none" onclick="showwitkey(10002,'.$uid.')">'.it618_witkey_getlang('s349').'(<font color="red">'.$allwitkeycount.'</font>)</a> '.$pfstr.'</td></tr>
	<tr><td><font color=#999>'.it618_witkey_getlang('s548').'</font>'.$qqstr.'</td></tr>
	<tr><td><font color=#999>'.it618_witkey_getlang('s553').'</font>'.$bztelstr.'</td></tr>
	<tr><td><font color=#999>'.it618_witkey_getlang('s551').'</font>'.$wxstr.'</td></tr>
	<tr><td style="border:none;">'.$it618_witkey_user['it618_bz'].'</td></tr>
	';
}else{
	$tmpstr= '
	<tr><td style="border:none;">'.$errstr.'</td></tr>
	';
}

$_G['mobiletpl'][IN_MOBILE]='/';

if($_GET['wap']!=1){
	include template('it618_witkey:showqq');
}else{
	include template('it618_witkey:showwapqq');
}
//From: Dism_taobao-com
?>