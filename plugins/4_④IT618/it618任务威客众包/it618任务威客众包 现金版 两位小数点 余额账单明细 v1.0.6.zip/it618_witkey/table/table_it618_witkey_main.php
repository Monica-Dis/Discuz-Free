<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_witkey_main extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_witkey_main';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_search($it618sql = '', $it618_name = '', $it618_postuid = 0, $it618_getuid = 0, $it618_money1 = 0, $it618_money2 = 0, $it618_time1 = '', $it618_time2 = '') {
		if($it618_getuid>0){
			$condition = $this->make_query_condition($it618sql, $it618_name, $it618_postuid, $it618_getuid, $it618_money1, $it618_money2, $it618_time1, $it618_time2);
			
			$query = DB::query("SELECT m.it618_tid FROM %t m LEFT JOIN ".DB::table('it618_witkey')." w ON m.it618_tid=w.it618_tid $condition[0] GROUP BY m.it618_tid", $condition[1]);
			$n=0;
			while($value = DB::fetch($query)) {
				$n=$n+1;
			}
		}else{
			$it618sql=str_replace("m.","",$it618sql);
			$condition = $this->make_query_condition1($it618sql, $it618_name, $it618_postuid, $it618_getuid, $it618_money1, $it618_money2, $it618_time1, $it618_time2);
			
			$n = DB::result_first("SELECT count(1) FROM %t $condition[0]", $condition[1]);
		}
		
		return $n;
	}
	
	public function sum_money_by_search($it618sql = '', $it618_name = '', $it618_postuid = 0, $it618_getuid = 0, $it618_money1 = 0, $it618_money2 = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618_name, $it618_postuid, $it618_getuid, $it618_money1, $it618_money2, $it618_time1, $it618_time2);
		$tmpmoney = DB::result_first("SELECT SUM(m.it618_moneycount2) FROM %t m LEFT JOIN ".DB::table('it618_witkey')." w ON m.it618_tid=w.it618_tid $condition[0]", $condition[1]);
		if($tmpmoney=='')return 0;else return $tmpmoney;
	}
	
	public function sum_jlmoney_by_search($it618sql = '', $it618_name = '', $it618_postuid = 0, $it618_getuid = 0, $it618_money1 = 0, $it618_money2 = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618_name, $it618_postuid, $it618_getuid, $it618_money1, $it618_money2, $it618_time1, $it618_time2);
		$tmpmoney = DB::result_first("SELECT SUM(w.it618_creditnum) FROM %t m LEFT JOIN ".DB::table('it618_witkey')." w ON m.it618_tid=w.it618_tid $condition[0]", $condition[1]);
		if($tmpmoney=='')return 0;else return $tmpmoney;
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_postuid = 0, $it618_getuid = 0, $it618_money1 = 0, $it618_money2 = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		if($it618_getuid>0){
			$condition = $this->make_query_condition($it618sql, $it618_name, $it618_postuid, $it618_getuid, $it618_money1, $it618_money2, $it618_time1, $it618_time2);
			$query = DB::query("SELECT m.id FROM %t m LEFT JOIN ".DB::table('it618_witkey')." w ON m.it618_tid=w.it618_tid $condition[0] GROUP BY m.it618_tid ".$it618orderby.DB::limit($start, $limit), $condition[1]);
		}else{
			$it618sql=str_replace("m.","",$it618sql);
			$it618orderby=str_replace("m.","",$it618orderby);
			$condition = $this->make_query_condition1($it618sql, $it618_name, $it618_postuid, $it618_getuid, $it618_money1, $it618_money2, $it618_time1, $it618_time2);
			$query = DB::query("SELECT * FROM %t $condition[0] ".$it618orderby.DB::limit($start, $limit), $condition[1]);
		}
		$data = array();
		while($value = DB::fetch($query)) {
			if($it618_getuid>0){
				$it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE id=".$value['id']);
				$data[] = $it618_witkey_main;
			}else{
				$data[] = $value;
			}
		}
		return $data;
	}
	
	private function make_query_condition($it618sql, $it618_name, $it618_postuid, $it618_getuid, $it618_money1, $it618_money2, $it618_time1, $it618_time2) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$it618sql.=' and m.it618_tid>0';
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "m.it618_title LIKE %s";
		}
		if(!empty($it618_postuid)) {
			$parameter[] = $it618_postuid;
			$wherearr[] = 'm.it618_uid=%d';
		}
		if(!empty($it618_getuid)) {
			$parameter[] = $it618_getuid;
			$wherearr[] = 'w.it618_uid=%d';
		}
		if(!empty($it618_money1)) {
			$parameter[] = $it618_money1;
			$wherearr[] = 'm.it618_moneycount2>=%d';
		}
		if(!empty($it618_money2)) {
			$parameter[] = $it618_money2;
			$wherearr[] = 'm.it618_moneycount2<=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 'm.it618_time>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 'm.it618_time<=unix_timestamp(%s)';
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	private function make_query_condition1($it618sql, $it618_name, $it618_postuid, $it618_getuid, $it618_money1, $it618_money2, $it618_time1, $it618_time2) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$it618sql.=' and it618_tid>0';
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "it618_title LIKE %s";
		}
		if(!empty($it618_postuid)) {
			$parameter[] = $it618_postuid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($it618_money1)) {
			$parameter[] = $it618_money1;
			$wherearr[] = 'it618_moneycount2>=%d';
		}
		if(!empty($it618_money2)) {
			$parameter[] = $it618_money2;
			$wherearr[] = 'it618_moneycount2<=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 'it618_time>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 'it618_time<=unix_timestamp(%s)';
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}
//From: Dism_taobao-com
?>