<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsCredits,$it618_witkey,$witkey_moneyname;
require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/lang.func.php';

$it618_witkey = $_G['cache']['plugin']['it618_witkey'];
$witkey_moneyname=$it618_witkey_lang['s201'];
$moneyname=$it618_witkey_lang['s201'];

$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_it618_witkey.php';
if(($_G['timestamp'] - @filemtime($cache_file)) > 60) {
	
	require_once libfile('function/cache');
	$contents[]='';
	$cacheArray .= "\$contents=".arrayeval($contents).";\n";
	writetocache('it618_witkey', $cacheArray);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_witkey_main')." where it618_tid=0 and it618_time1<".($_G['timestamp']-60));
	while($it618_witkey_main = DB::fetch($query)) {
		DB::query("delete FROM ".DB::table('it618_witkey_main')." where id=".$it618_witkey_main['id']);
		DB::query("delete FROM ".DB::table('it618_witkey_findtid')." where it618_wid=".$it618_witkey_main['id']);
	}
	
	$query = DB::query("SELECT count(1) as c,it618_tid FROM ".DB::table('it618_witkey_main')." group by it618_tid having c>1");
	while($it618_witkey_main = DB::fetch($query)) {
		$it618_witkey_maintmp=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE it618_tid=".$it618_witkey_main['it618_tid']);
		DB::query("delete FROM ".DB::table('it618_witkey_main')." where id!=".$it618_witkey_maintmp['id']." and it618_tid=".$it618_witkey_main['it618_tid']);
	}
}

function it618_witkey_getumoney($uid,$type=0){
	global $_G,$IsCredits;
	if($IsCredits!=1)return 0;
	if($type==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		set_time_limit (0);
		ignore_user_abort(true);
	
		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
			
		$it618_moneytmp=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uid);
		DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_moneytmp." where it618_uid=".$uid);
		
		it618_credits_delmoneywork();
	}else{
		$it618_moneytmp=DB::result_first("select it618_money from ".DB::table('it618_credits_uset')." where it618_uid=".$uid);	
	}
	
	return $it618_moneytmp;
}

function it618_witkey_money($type,$id,$uid,$editmoney,$bz,$moneytype){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	
	$it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE id=".$id);
	$it618_bz=str_replace("{money}",'<font color=red>'.round($editmoney,2).'</font>',$bz.' '.$it618_witkey_main['it618_title']);
	
	if($moneytype==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		savemoney(array(
			'it618_uid' => $uid,
			'it618_type' => 'zy',
			'it618_money1' => $editmoney,
			'it618_bz' => $it618_bz,
			'it618_zytype' => $type,
			'it618_zyid' => $id,
			'it618_time' => $_G['timestamp']
		));
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
	
		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$id=savemoney(array(
			'it618_uid' => $uid,
			'it618_type' => 'pay',
			'it618_money2' => $editmoney,
			'it618_bz' => $it618_bz,
			'it618_zftype' => $type,
			'it618_zfid' => $id
		));
		it618_credits_delmoneywork();
	}
	
	$it618_moneytmp=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uid);
	DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_moneytmp." where it618_uid=".$uid);
}

function getwitkeylist($type='index',$it618_forumid=0,$it618_forumtypeid=0,$it618_witkeystate=0,$it618_mancount=0,$it618_postuid=0,$it618_getuid=0,$it618_name='',$it618_money1=0,$it618_money2=0,$it618_time1=0,$it618_time2=0,$getpage=1,$it618_witkeymode=0,$it618_order=0){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	if($type=='index')$ppp = $it618_witkey['witkey_witkeycount'];else $ppp = 6;
	$page = max(1, intval($getpage));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='1';
	
	if($it618_forumid>0)$sql.=" and m.it618_fid=".$it618_forumid;
	if($it618_forumtypeid>0)$sql.=" and m.it618_typeid=".$it618_forumtypeid;
	
	if($it618_witkeystate==0)$sql.="";
	if($it618_witkeystate==1)$sql.=" and m.it618_state=10";
	if($it618_witkeystate==2)$sql.=" and m.it618_state=0";
	if($it618_witkeystate==3)$sql.=" and m.it618_state=1";
	
	if($it618_witkeymode==0)$sql.="";
	if($it618_witkeymode==1)$sql.=" and m.it618_mode=1";
	if($it618_witkeymode==2)$sql.=" and m.it618_mode=2";
	if($it618_witkeymode==3)$sql.=" and m.it618_mode=3";
	
	if($it618_order==0)$orderby="order by m.id desc";
	if($it618_order==1)$orderby="order by m.it618_time2";
	if($it618_order==2)$orderby="order by m.it618_mancount desc";
	if($it618_order==3)$orderby="order by m.it618_moneycount2 desc";
	if($it618_order==4)$orderby="order by m.it618_moneycount2";
	if($it618_order==5)$orderby="order by m.it618_views desc";
	
	$count = C::t('#it618_witkey#it618_witkey_main')->count_by_search($sql,$it618_name,$it618_postuid,$it618_getuid,$it618_money1,$it618_money2,$it618_time1,$it618_time2);
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].'plugin.php?id=it618_witkey:ajax');
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getwitkeylist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getwitkeylist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getwitkeylist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	$pagecount=intval($count/$ppp);
	if($page<$pagecount){
		$lastindex=$ppp;
	}else{
		$lastindex=$count;
	}
	
	$n=1;
	foreach(C::t('#it618_witkey#it618_witkey_main')->fetch_all_by_search(
			$sql,$orderby,$it618_name,$it618_postuid,$it618_getuid,$it618_money1,$it618_money2,$it618_time1,$it618_time2,$startlimit,$ppp
	) as $it618_witkey_main) {
		if($n==$lastindex)$lastcss=' class="listlast"';else $lastcss='';
		$n=$n+1;
		
		$tid=$it618_witkey_main['it618_tid'];
		
		$subject=it618_witkey_getsubject($tid);
		$subject1=cutstr($subject, 50, '');

		$getstate=it618_witkey_getstate($it618_witkey_main,0);
		$getmancount=it618_witkey_getmancount($it618_witkey_main,0);
		$getmode=it618_witkey_getmode($it618_witkey_main,0);
		$getmoney=it618_witkey_getmoney($it618_witkey_main,0);
		$gettjimg=it618_witkey_gettjimg($it618_witkey_main,0);
		
		if($type!='index'&&$it618_witkey_main['it618_jl']>0){
			$jfname=$_G['setting']['extcredits'][$it618_witkey['witkey_jlcredit']]['title'];
			$getstate.=' '.$it618_witkey_lang['s1024'].'<font color=#f60>'.$it618_witkey_main['it618_jl'].'</font>'.$jfname;
		}
		
		$getwitkeylist.='<tr><td class="witkeytd">
						  <table>
						  <tr class="trwitkey1">
						  <td class="tdwitkeyleft"><a href="forum.php?mod=viewthread&tid='.$tid.'" title="'.$subject.'" target="_blank">'.$subject1.'</a>'.it618_witkey_getico($tid).'</td>
						  <td class="tdwitkeyright">'.$getstate.'</td>
						  </tr>
						  <tr class="trwitkey2">
						  <td class="tdwitkeyleft">'.$getmode.' '.it618_witkey_getclass($tid).'<span class="spanmoney">'.$getmoney.'</span> <span class="spanmancount">'.$getmancount.'</span></td>
						  <td class="tdwitkeyright"><span class="spanauthortime"><img src="source/plugin/it618_witkey/images/user.png" style="vertical-align:middle;height:13px;margin-top:-4px"> <a href="home.php?mod=space&uid='.$it618_witkey_main['it618_uid'].'" target="_blank">'.it618_witkey_getauthor($it618_witkey_main['it618_uid']).'</a><em>/</em>'.date('Y-m-d', $it618_witkey_main['it618_time1']).$gettjimg.'</span></td>
						  </tr>
						  </table>
						  </td></tr>';
		
	}
	
	$getwitkeylist=it618_witkey_rewriteurl($getwitkeylist);
	
	if($type=='index'){
		if($multipage!='')$multipage='<tr><td class="witkeypage">'.$multipage.'</td></tr>';
		return $getwitkeylist.$multipage;	
	}else{
		if($multipage!='')$multipage='<tr><td class="witkeypage">'.$multipage.'</td></tr>';
		if($it618_postuid>0||$it618_getuid>0){
			$jlmoney = C::t('#it618_witkey#it618_witkey_main')->sum_jlmoney_by_search($sql,$it618_name,$it618_postuid,$it618_getuid,$it618_money1,$it618_money2,$it618_time1,$it618_time2);
			if($jlmoney=='')$jlmoney=0;
			
			if($it618_getuid>0)$tmpstr=it618_witkey_getlang('s336');else $tmpstr=it618_witkey_getlang('s337');
			
			return '<tr><td class="listsum"><span class="witkeysum">'.it618_witkey_getlang('s338').'<font color="red">'.$count.'</font> '.$tmpstr.'<font color="red">'.$jlmoney.'</font> '.$witkey_moneyname.'</span></td></tr>'.$getwitkeylist.$multipage;	
		}else{
			return $getwitkeylist.$multipage;	
		}
	}
}

function it618_witkey_getmode($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	if($it618_witkey_main['it618_uids']!='')$it618_uids=$it618_witkey_lang['s284'];
	
	if($wap==1){
		if($it618_witkey_main['it618_mode']==1)$modestr='<span style="float:left; background-color:#F90;margin-top:3px;margin-right:3px;color:#fff; font-size:10px; padding:2px 3px;line-height:11px;border-radius:2px">'.$it618_witkey_lang['s313'].$it618_uids.'</span>';
		if($it618_witkey_main['it618_mode']==2)$modestr='<span style="float:left; background-color:#b09ffa;margin-top:3px;margin-right:3px;color:#fff; font-size:10px; padding:2px 3px;line-height:11px;border-radius:2px">'.$it618_witkey_lang['s314'].$it618_uids.'</span>';
		if($it618_witkey_main['it618_mode']==3)$modestr='<span style="float:left; background-color:#de0515;margin-top:3px;margin-right:3px;color:#fff; font-size:10px; padding:2px 3px;line-height:11px;border-radius:2px">'.$it618_witkey_lang['s315'].$it618_uids.'</span>';
	}
	if($wap==0){
		if($it618_witkey_main['it618_mode']==1)$modestr='<span style="display:inline-block; background-color:#F90; color:#fff; font-size:12px; padding:2px 5px;padding-bottom:3px;line-height:12px;border-radius:2px">'.$it618_witkey_lang['s313'].$it618_uids.'</span>';
		if($it618_witkey_main['it618_mode']==2)$modestr='<span style="display:inline-block; background-color:#b09ffa; color:#fff; font-size:12px; padding:2px 5px;padding-bottom:3px;line-height:12px;border-radius:2px">'.$it618_witkey_lang['s314'].$it618_uids.'</span>';
		if($it618_witkey_main['it618_mode']==3)$modestr='<span style="display:inline-block; background-color:#de0515; color:#fff; font-size:12px; padding:2px 5px;padding-bottom:3px;line-height:12px;border-radius:2px">'.$it618_witkey_lang['s315'].$it618_uids.'</span>';
	}
	if($wap==3){
		if($it618_witkey_main['it618_mode']==1)$modestr='<span style="display:inline-block; background-color:#F90; color:#fff; font-size:10px; padding:2px 3px;padding-bottom:3px;line-height:11px;border-radius:2px">'.$it618_witkey_lang['s313'].$it618_uids.'</span>';
		if($it618_witkey_main['it618_mode']==2)$modestr='<span style="display:inline-block; background-color:#b09ffa; color:#fff; font-size:10px; padding:2px 3px;padding-bottom:3px;line-height:11px;border-radius:2px">'.$it618_witkey_lang['s314'].$it618_uids.'</span>';
		if($it618_witkey_main['it618_mode']==3)$modestr='<span style="display:inline-block; background-color:#de0515; color:#fff; font-size:10px; padding:2px 3px;padding-bottom:3px;line-height:11px;border-radius:2px">'.$it618_witkey_lang['s315'].$it618_uids.'</span>';
	}
	
	return $modestr;
}

function it618_witkey_getmode1($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	if($it618_witkey_main['it618_uids']!='')$it618_uids=$it618_witkey_lang['s284'];
	
	if($it618_witkey_main['it618_mode']==1)$modestr='<span style="display:inline-block; background-color:#F90; color:#fff; font-size:12px; padding:3px 5px;padding-top:1px;line-height:12px;border-radius:2px">'.$it618_witkey_lang['s313'].$it618_uids.'</span>';
	if($it618_witkey_main['it618_mode']==2)$modestr='<span style="display:inline-block; background-color:#b09ffa; color:#fff; font-size:12px; padding:3px 5px;padding-top:1px;line-height:12px;border-radius:2px">'.$it618_witkey_lang['s314'].$it618_uids.'</span>';
	if($it618_witkey_main['it618_mode']==3)$modestr='<span style="display:inline-block; background-color:#de0515; color:#fff; font-size:12px; padding:3px 5px;padding-top:1px;line-height:12px;border-radius:2px">'.$it618_witkey_lang['s315'].$it618_uids.'</span>';
	
	return $modestr;
}

function it618_witkey_getmode2($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	if($it618_witkey_main['it618_uids']!='')$it618_uids=$it618_witkey_lang['s284'];
	
	if($it618_witkey_main['it618_mode']==1)$modestr='<font color=#f60>'.$it618_witkey_lang['s313'].$it618_uids.'</font>';
	if($it618_witkey_main['it618_mode']==2)$modestr='<font color=grenn>'.$it618_witkey_lang['s314'].$it618_uids.'</font>';
	if($it618_witkey_main['it618_mode']==3)$modestr='<font color=red>'.$it618_witkey_lang['s315'].$it618_uids.'</font>';
	
	return $modestr;
}

function it618_witkey_gettjimg($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	if($it618_witkey_main['it618_istj']==1){
		if($wap==1){
			$tmpimg=' <img src="source/plugin/it618_witkey/images/se.gif" height="13" style="margin-top:-3px">';
		}else{
			$tmpimg=' <img src="source/plugin/it618_witkey/images/se.gif" height="13" style="margin-bottom:-2px">';
		}
	}else{
		$tmpimg='';
	}
	
	return $tmpimg;
}

function it618_witkey_getmoney($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	if($it618_witkey_main['it618_mode']!=3){
		$moneystr=$it618_witkey_main['it618_moneycount2'];
		$spanmoney=$it618_witkey_lang['s689'].'<b>'.$moneystr.$witkey_moneyname.'</b>';
	}else{
		$moneystr=$it618_witkey_main['it618_moneycount2'];
		$spanmoney=$it618_witkey_lang['s690'].'<b>'.$moneystr.$witkey_moneyname.'</b>';
	}
	
	return $spanmoney;
}

function it618_witkey_getmoney1($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	if($it618_witkey_main['it618_mode']!=3){
		$moneystr=$it618_witkey_main['it618_moneycount2'];
		$spanmoney=$it618_witkey_lang['s689'].'<b style="font-size:12px; color:#f60; padding-left:3px">'.$moneystr.$witkey_moneyname.'</b>';
	}else{
		$moneystr=$it618_witkey_main['it618_moneycount2'];
		$spanmoney=$it618_witkey_lang['s690'].'<b style="font-size:12px; color:#f60; padding-left:3px">'.$moneystr.$witkey_moneyname.'</b>';
	}
	
	return $spanmoney;
}

function it618_witkey_getstate($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	if($it618_witkey_main['it618_state']==0)$it618_state="<font color=red>".it618_witkey_getlang('s13')."</font>";
	if($it618_witkey_main['it618_state']==1)$it618_state="<font color=#390>".it618_witkey_getlang('s14')."</font>";
	$it618_timestr='';
	if($it618_witkey_main['it618_state']==10){
		$it618_state="<font color=#03a6fe>".it618_witkey_getlang('s408')."</font>";
		$it618_timestr=it618_witkey_getbmtime($it618_witkey_main,$it618_witkey_main['it618_time2']);
	}
	
	if($wap==1){
		return $it618_timestr.' '.$it618_state;
	}else{
		return $it618_state.' '.$it618_timestr;
	}
}

function it618_witkey_getbmtime($it618_witkey_main,$it618_time){
	global $_G;
	$timecount=intval(($it618_time-$_G['timestamp'])/3600);
	
	if($timecount>24){
		$timecount1=intval($timecount/24);
		$timestr='<font color="red">'.$timecount1.'</font> '.it618_witkey_getlang('s687');
		
		$timecount2=$timecount-$timecount1*24;
		$timestr.=' <font color="red">'.$timecount2.'</font> '.it618_witkey_getlang('s688');
	}elseif($timecount>=0){
		$timecount=round((($it618_time-$_G['timestamp'])/3600),1);
		$timestr='<font color="red">'.$timecount.'</font> '.it618_witkey_getlang('s688');
	}else{
		DB::query('update '.DB::table('it618_witkey_main').' set it618_state=0 where id='.$it618_witkey_main['id']);
	}
	
	if($timestr!='') $timestr=$timestr.it618_witkey_getlang('s912');
	return $timestr;
}

function it618_witkey_getmancount($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	$tid=$it618_witkey_main['it618_tid'];
	$witkeyallcount=DB::result_first("select it618_mancount from ".DB::table('it618_witkey_main')." where it618_tid=".$tid);
	$tidwitkeycount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_tid=".$tid);
	
	if($it618_witkey_main['it618_mode']!=3){
		$tidwitkeycountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_ok=1 and it618_tid=".$tid);
		
		if($witkeyallcount-$tidwitkeycount>0||$tidwitkeycount==0){
			if($tidwitkeycountok<=$tidwitkeycount){
				$tmpstr='';
				if($it618_witkey_main['it618_state']!=1)$tmpstr='<em>/</em>'.$it618_witkey_lang['s693'].'<font color=#f30>'.'<font color=red>'.($witkeyallcount-$tidwitkeycount).'</font>'.$it618_witkey_lang['s700'];
				
				$spanmancount='<font color=red>'.$tidwitkeycount.'</font>'.$it618_witkey_lang['s691'].'<em>/</em>'.'<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s692'].$tmpstr;
			}else{
				$tmpstr='';
				if($it618_witkey_main['it618_state']!=1)$tmpstr='<em>/</em>'.$it618_witkey_lang['s693'].'<font color=red>'.($witkeyallcount-$tidwitkeycount).'</font>'.$it618_witkey_lang['s700'];
				
				$spanmancount='<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s694'].$tmpstr;
			}
		}else{
			$tmpstr='';
			if($it618_witkey_main['it618_state']!=1)$tmpstr='<em>/</em>'.$it618_witkey_lang['s695'];
				
			if($tidwitkeycountok<=$tidwitkeycount){
				$spanmancount='<font color=red>'.$tidwitkeycount.'</font>'.$it618_witkey_lang['s691'].'<em>/</em>'.'<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s692'].$tmpstr;
			}else{
				$spanmancount='<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s694'].$tmpstr;
			}
		}
	}else{
		$tmpstr='';
		$tidwitkeycountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_creditnum<>0 and it618_tid=".$tid);
		if($witkeyallcount-$tidwitkeycountok>0||$tidwitkeycount==0){
			if($it618_witkey_main['it618_state']!=1)$tmpstr='<em>/</em>'.$it618_witkey_lang['s697'].'<font color=#f30>'.'<font color=red>'.($witkeyallcount-$tidwitkeycountok).'</font>'.$it618_witkey_lang['s700'];
			
			$spanmancount='<font color=red>'.$tidwitkeycount.'</font>'.$it618_witkey_lang['s691'].'<em>/</em>'.'<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s696'].$tmpstr;
		}else{
			if($it618_witkey_main['it618_state']!=1)$tmpstr='<em>/</em>'.$it618_witkey_lang['s698'];
			
			$spanmancount='<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s696'].$tmpstr;
		}
		
	}
	
	return $it618_witkey_main['it618_views'].$it618_witkey_lang['s699'].'<em>/</em>'.$spanmancount;
}

function it618_witkey_getmancount1($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	$tid=$it618_witkey_main['it618_tid'];
	$witkeyallcount=DB::result_first("select it618_mancount from ".DB::table('it618_witkey_main')." where it618_tid=".$tid);
	$tidwitkeycount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_tid=".$tid);
	
	if($it618_witkey_main['it618_mode']!=3){
		$tidwitkeycountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_ok=1 and it618_tid=".$tid);
		
		if($witkeyallcount-$tidwitkeycount>0||$tidwitkeycount==0){
			$tmpstr='';
			if($it618_witkey_main['it618_state']!=1)$tmpstr='<em style="padding:3px;padding-right:0px; color:#ccc">/</em>'.$it618_witkey_lang['s693'].'<font color=red>'.($witkeyallcount-$tidwitkeycount).'</font>'.$it618_witkey_lang['s700'];
			
			if($tidwitkeycountok<=$tidwitkeycount){
				$spanmancount='<font color=red>'.$tidwitkeycount.'</font>'.$it618_witkey_lang['s701'].'<em style="padding:3px;padding-right:0px; color:#ccc">/</em>'.'<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s702'].$tmpstr;
			}else{
				$spanmancount='<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s703'].$tmpstr;
			}
		}else{
			$tmpstr='';
			if($it618_witkey_main['it618_state']!=1)$tmpstr='<em style="padding:3px;padding-right:0px; color:#ccc">/</em>'.$it618_witkey_lang['s704'];
			
			if($tidwitkeycountok<=$tidwitkeycount){
				$spanmancount='<font color=red>'.$tidwitkeycount.'</font>'.$it618_witkey_lang['s701'].'<em style="padding:3px;padding-right:0px; color:#ccc">/</em>'.'<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s702'].$tmpstr;
			}else{
				$spanmancount='<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s703'].$tmpstr;
			}
		}
	}else{
		$tmpstr='';
			
		$tidwitkeycountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_creditnum<>0 and it618_tid=".$tid);
		if($witkeyallcount-$tidwitkeycountok>0||$tidwitkeycount==0){
			if($it618_witkey_main['it618_state']!=1)$tmpstr='<em style="padding:3px;padding-right:0px; color:#ccc">/</em>'.$it618_witkey_lang['s693'].'<font color=red>'.($witkeyallcount-$tidwitkeycountok).'</font>'.$it618_witkey_lang['s700'];
			
			$spanmancount='<font color=red>'.$tidwitkeycount.'</font>'.$it618_witkey_lang['s701'].'<em style="padding:3px;padding-right:0px; color:#ccc">/</em>'.'<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s705'].$tmpstr;
		}else{
			if($it618_witkey_main['it618_state']!=1)$tmpstr='<em style="padding:3px;padding-right:0px; color:#ccc">/</em>'.$it618_witkey_lang['s704'];
			
			$spanmancount='<font color=red>'.$tidwitkeycountok.'</font>'.$it618_witkey_lang['s705'].$tmpstr;
		}
		
	}
	
	return $spanmancount;
}

function it618_witkey_getmancount2($it618_witkey_main,$wap){
	global $_G,$it618_witkey,$it618_witkey_lang,$witkey_moneyname;
	
	$tid=$it618_witkey_main['it618_tid'];
	$witkeyallcount=DB::result_first("select it618_mancount from ".DB::table('it618_witkey_main')." where it618_tid=".$tid);
	$tidwitkeycount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_tid=".$tid);
	
	if($it618_witkey_main['it618_mode']!=3){
		$tidwitkeycountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_ok=1 and it618_tid=".$tid);
		
		if($witkeyallcount-$tidwitkeycount>0||$tidwitkeycount==0){
			if($tidwitkeycountok<=$tidwitkeycount){
				$spanmancount=$tidwitkeycount.$it618_witkey_lang['s706'].$tidwitkeycountok.$it618_witkey_lang['s707'].($witkeyallcount-$tidwitkeycount).$it618_witkey_lang['s700'];
			}else{
				$spanmancount=$tidwitkeycountok.$it618_witkey_lang['s708'].($witkeyallcount-$tidwitkeycount).$it618_witkey_lang['s700'];
			}
		}else{
			if($tidwitkeycountok<=$tidwitkeycount){
				$spanmancount=$tidwitkeycount.$it618_witkey_lang['s706'].$tidwitkeycountok.$it618_witkey_lang['s709'];
			}else{
				$spanmancount=$tidwitkeycountok.$it618_witkey_lang['s710'];
			}
		}
	}else{
		$tidwitkeycountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_creditnum<>0 and it618_tid=".$tid);
		if($witkeyallcount-$tidwitkeycountok>0||$tidwitkeycount==0){
			$spanmancount=$tidwitkeycount.$it618_witkey_lang['s706'].$tidwitkeycountok.$it618_witkey_lang['s711'].($witkeyallcount-$tidwitkeycountok).$it618_witkey_lang['s700'];
		}else{
			$spanmancount=$tidwitkeycountok.$it618_witkey_lang['s712'];
		}
		
	}
	
	return $spanmancount;
}

function it618_witkey_deletewitkey($tid){
	DB::query("delete FROM ".DB::table('it618_witkey_main')." where it618_tid=".$tid);
	DB::query("delete FROM ".DB::table('it618_witkey')." where it618_tid=".$tid);
	DB::query("delete FROM ".DB::table('it618_witkey_pf')." where it618_tid=".$tid);
	DB::query("delete FROM ".DB::table('it618_witkey_findtid')." where it618_tid=".$tid);
}

function it618_witkey_getforumname($fid){
	if($fid=='')return '';
	return DB::result_first("select name from ".DB::table('forum_forum')." where fid=$fid");
}

function it618_witkey_getsubject($tid){
	if($tid=='')return '';
	return DB::result_first("select it618_title from ".DB::table('it618_witkey_main')." where it618_tid=$tid");
}

function it618_witkey_getauthor($uid){
	if($uid=='')return '';
	return DB::result_first("select username from ".DB::table('common_member')." where uid=$uid");
}

function it618_witkey_getclass($tid){
	if($tid=='')return '';
	$forum_thread=DB::fetch_first("select fid,typeid from ".DB::table('forum_thread')." where tid=$tid");
	$fid=$forum_thread['fid'];
	$typeid=$forum_thread['typeid'];
	
	if($typeid==0)return '';
	$subject=DB::result_first("select name from ".DB::table('forum_threadclass')." where fid=$fid and typeid=$typeid");
	
	return '[<a href="forum.php?mod=forumdisplay&fid='.$fid.'&filter=typeid&typeid='.$typeid.'" class="witkeyclass" target="_blank"><font color=#888>'.$subject.'</font></a>]';
}

function it618_witkey_getclass_name($tid){
	$forum_thread=DB::fetch_first("select fid,typeid from ".DB::table('forum_thread')." where tid=$tid");
	$fid=$forum_thread['fid'];
	$typeid=$forum_thread['typeid'];
	
	if($typeid==0)return '';
	$subject=DB::result_first("select name from ".DB::table('forum_threadclass')." where fid=$fid and typeid=$typeid");
	
	return $subject;
}

function it618_witkey_getclass_url($tid){
	$forum_thread=DB::fetch_first("select fid,typeid from ".DB::table('forum_thread')." where tid=$tid");
	$fid=$forum_thread['fid'];
	$typeid=$forum_thread['typeid'];
	
	if($typeid==0)return '';
	$subject=DB::result_first("select name from ".DB::table('forum_threadclass')." where fid=$fid and typeid=$typeid");
	
	return 'forum.php?mod=forumdisplay&fid='.$fid.'&filter=typeid&typeid='.$typeid;
}

function it618_witkey_getforumclass(){
	global $it618_witkey;
	$findclass='<input type="hidden" name="it618_class1" value="0"><input type="hidden" name="it618_class2" value="0">';
	$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
	$forumcount=count($witkey_forums);
	if($forumcount>0){
		$findclass=it618_witkey_getlang('s340');
		$n1=1;
		$tmp1='';
		foreach($witkey_forums as $key => $fid) {
			if($fid>0){
				$forumtmp.='<option value="'.$fid.'">'.it618_witkey_getforumname($fid).'</option>';
				$n2=1;
				$query = DB::query("SELECT * FROM ".DB::table('forum_threadclass')." where fid=$fid order by displayorder");
				while($forum_threadclass =DB::fetch($query)) {
					$tmp1.='select_forum['.$n1.']['.$n2.'] = new Option("'.$forum_threadclass['name'].'", "'.$forum_threadclass['typeid'].'");';
					$n2=$n2+1;
				}
				$n1=$n1+1;
			}
		}
		
		$witkeyclassjs='
		var arrcount='.$forumcount.';
		var select_forum = new Array(arrcount+1);
		
		for (i=0; i<arrcount+1; i++) 
		{
		 select_forum[i] = new Array();
		}
		
		'.$tmp1.'
		
		function redirec_forum(x)
		{
		 var temp = document.getElementById("it618_class2"); 
		 temp.options.length=1;
		 for (i=1;i<select_forum[x].length;i++)
		 {
		  temp.options[i]=new Option(select_forum[x][i].text,select_forum[x][i].value);
		 }
		 temp.options[0].selected=true;
		
		}
		
		';
		
		$findclass.=' <select name="it618_class1" onchange="redirec_forum(this.options.selectedIndex)"><option value="0">'.it618_witkey_getlang('s341').'</option>'.$forumtmp.'</select> <select id="it618_class2" name="it618_class2"><option value="0">'.it618_witkey_getlang('s342').'</option></select>';
	}
	
	return $findclass.'it618split'.$witkeyclassjs;
}

function it618_witkey_it618_witkey_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	
	if($timecount>24*10){
		$timestr=date('Y-m-d', $it618_time);
	}elseif($timecount>24){
		$timecount=intval($timecount/24);
		$timestr='<font color="red">'.$timecount.''.it618_witkey_getlang('s343').'</font>';
	}elseif($timecount>=1){
		$timestr='<font color="red">'.$timecount.''.it618_witkey_getlang('s344').'</font>';
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr='<font color="red">'.$timecount.''.it618_witkey_getlang('s345').'</font>';
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr='<font color="red">'.$timecount.''.it618_witkey_getlang('s346').'</font>';
		}
	}
	
	return $timestr;
}

function it618_witkey_gettime($tid){
	return '<span class="time">'.it618_witkey_it618_witkey_gettime(DB::result_first("select it618_time1 from ".DB::table('it618_witkey_main')." where it618_tid=$tid")).'</span>';
}

function it618_witkey_getico($tid){
	$query = DB::query("select * from ".DB::table('forum_thread')." where tid='$tid'");
	if($result = DB::fetch($query)) {
		if($result['attachment']==2)$tmpall.='<span style="padding-left:12px;background:url(static/image/filetype/image_s.gif) no-repeat center center;">&nbsp;</span>';
		
		if($result['displayorder']>0)$tmpall.='<span style="padding-left:15px;background:url(static/image/common/pin_'.$result['displayorder'].'.gif) no-repeat center top;"/>&nbsp;</span>';
		
		if($result['digest']>0)$tmpall.='<span style="padding-left:19px;background:url(static/image/common/digest_'.$result['digest'].'.gif) no-repeat center center;"/>&nbsp;</span>';
	}
	
	return $tmpall;
}

function it618_witkey_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_witkey_sendmessage($type,$id,$type1='',$money=0){	
	global $_G,$it618_witkey,$it618_witkey_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_witkey/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_witkey/config/message.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='witkeypost_admin'&&$it618_body_witkeypost_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_witkeypost_admin;
				
				$it618_witkey_main=DB::fetch_first("select * from ".DB::table('it618_witkey_main')." where id=$id");
				$tmpurl=it618_witkey_gettidurl($it618_witkey_main['it618_tid']);

				if($it618_mode==3){
					$modestr=it618_witkey_getlang('s277');
				}elseif($it618_mode==2){
					$modestr=it618_witkey_getlang('s222');
				}else{
					$modestr=it618_witkey_getlang('s223');
				}
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_witkeypost_admin_tplid_wxsms;
				$body_wxsms=$it618_body_witkeypost_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_witkey_getusername($it618_witkey_main['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{money}",$it618_witkey_main['it618_moneycount2'],$tmpvalue);
						$tmpvalue=str_replace("{mancount}",$it618_witkey_main['it618_mancount'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						$tmpvalue=str_replace("{mode}",$modestr,$tmpvalue);
						$tmpvalue=str_replace("{name}",it618_witkey_getsmsstr($it618_witkey_main['it618_title'],$it618_length),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_witkey_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_witkey_getusername($it618_witkey_main['it618_uid']),$Body);
				$Body=str_replace("{money}",$it618_witkey_main['it618_moneycount2'],$Body);
				$Body=str_replace("{mancount}",$it618_witkey_main['it618_mancount'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				$Body=str_replace("{mode}",$modestr,$Body);
				$Body=str_replace("{name}",it618_witkey_getsmsstr($it618_witkey_main['it618_title'],$it618_length),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_witkeypost_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_witkey_getusername($it618_witkey_main['it618_uid']).'",';
					
					$tmparr=explode("{money}",$ALDYBody);
					if(count($tmparr)>1)$param.='"money":"'.$it618_witkey_main['it618_moneycount2'].'",';
					
					$tmparr=explode("{mancount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"mancount":"'.$it618_witkey_main['it618_mancount'].'",';
					
					$tmparr=explode("{mode}",$ALDYBody);
					if(count($tmparr)>1)$param.='"mode":"'.$modestr.'",';
					
					$tmparr=explode("{name}",$ALDYBody);
					if(count($tmparr)>1)$param.='"name":"'.it618_witkey_getsmsstr($it618_witkey_main['it618_title'],$it618_length).'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='witkeyok_admin'&&$it618_body_witkeyok_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_witkeyok_admin;
				
				$it618_witkey_main=DB::fetch_first("select * from ".DB::table('it618_witkey_main')." where id=$id");
				$tmpurl=it618_witkey_gettidurl($it618_witkey_main['it618_tid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_witkeyok_admin_tplid_wxsms;
				$body_wxsms=$it618_body_witkeyok_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_witkey_getusername($it618_witkey_main['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						$tmpvalue=str_replace("{name}",it618_witkey_getsmsstr($it618_witkey_main['it618_title'],$it618_length),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_witkey_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_witkey_getusername($it618_witkey_main['it618_uid']),$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				$Body=str_replace("{name}",it618_witkey_getsmsstr($it618_witkey_main['it618_title'],$it618_length),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_witkeyok_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_witkey_getusername($it618_witkey_main['it618_uid']).'",';
					
					$tmparr=explode("{name}",$ALDYBody);
					if(count($tmparr)>1)$param.='"name":"'.it618_witkey_getsmsstr($it618_witkey_main['it618_title'],$it618_length).'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='getwitkey_post'&&$it618_body_getwitkey_post_isok==1){
			$it618_witkey_witkey=DB::fetch_first("select * from ".DB::table('it618_witkey')." where id=$id");
			$it618_witkey_main=DB::fetch_first("select * from ".DB::table('it618_witkey_main')." where it618_tid=".$it618_witkey_witkey['it618_tid']);
			$tmpurl=it618_witkey_gettidurl($it618_witkey_main['it618_tid']);
			
			$it618_witkey_user=DB::fetch_first("select * from ".DB::table('it618_witkey_user')." where it618_uid=".$it618_witkey_main['it618_uid']);
			$it618_tel=$it618_witkey_user['it618_tel'];
			
			if($it618_witkey['witkey_rzdatatype']==1){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$it618_witkey_main['it618_uid'])){
						$it618_teltmp=$it618_members_user['it618_tel'];
					}
				}
			}
			
			if($it618_witkey['witkey_rzdatatype']==2){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$it618_witkey_main['it618_uid'])){
						$it618_teltmp=$it618_members_rzuser['it618_tel'];
					}
				}
			}
			
			if($it618_teltmp!=''){
				$tel=$it618_teltmp;
				if($it618_witkey_user['it618_msgisok']==1){
					$Body=$it618_body_getwitkey_post;
					$msguid=$it618_witkey_main['it618_uid'];
					
					$uid=$it618_witkey_main['it618_uid'];
					$tplid_wxsms=$it618_body_getwitkey_post_tplid_wxsms;
					$body_wxsms=$it618_body_getwitkey_post_wxsms;
					if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
						$param_wxsms=array();
						$tmparr=explode("@",$body_wxsms);
						for($i=0;$i<count($tmparr);$i++){
							$tmparr1=explode("|",$tmparr[$i]);
							$tmplabel=$tmparr1[0];
							$tmpvalue=$tmparr1[1];
							
							$tmpvalue=str_replace("{user}",it618_witkey_getusername($it618_witkey_witkey['it618_uid']),$tmpvalue);
							$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
							$tmpvalue=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_witkey['it618_tid']),$it618_length),$tmpvalue);
							
							$param_wxsms[$tmplabel]=array();
							$param_wxsms[$tmplabel]["value"]=it618_witkey_gbktoutf($tmpvalue);
							$param_wxsms[$tmplabel]["color"]="#666666";
						}
					}
		
					$ALDYBody=$Body;
					$Body=str_replace("{user}",it618_witkey_getusername($it618_witkey_witkey['it618_uid']),$Body);
					$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
					$Body=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_witkey['it618_tid']),$it618_length),$Body);
					
					if($it618_type!='smsbao'){
						$tplid=$it618_body_getwitkey_post_tplid;
						
						$tmparr=explode("{user}",$ALDYBody);
						if(count($tmparr)>1)$param.='"user":"'.it618_witkey_getusername($it618_witkey_witkey['it618_uid']).'",';
						
						$tmparr=explode("{name}",$ALDYBody);
						if(count($tmparr)>1)$param.='"name":"'.it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_witkey['it618_tid']),$it618_length).'",';
						
						$tmparr=explode("{time}",$ALDYBody);
						if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
						
						if($param!=''){
							$param.='@';
							$param=str_replace(",@","",$param);
						}
					}
				}
			}
		}
		
		if($type=='pf_post'&&$it618_body_pf_post_isok==1){
			$it618_witkey_pf=DB::fetch_first("select * from ".DB::table('it618_witkey_pf')." where id=$id");
			$it618_witkey_main=DB::fetch_first("select * from ".DB::table('it618_witkey_main')." where it618_tid=".$it618_witkey_pf['it618_tid']);
			$tmpurl=it618_witkey_gettidurl($it618_witkey_main['it618_tid']);
			
			$it618_witkey_user=DB::fetch_first("select * from ".DB::table('it618_witkey_user')." where it618_uid=".$it618_witkey_main['it618_uid']);
			$it618_teltmp=$it618_witkey_user['it618_tel'];
			
			if($it618_witkey['witkey_rzdatatype']==1){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$it618_witkey_main['it618_uid'])){
						$it618_teltmp=$it618_members_user['it618_tel'];
					}
				}
			}
			
			if($it618_witkey['witkey_rzdatatype']==2){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$it618_witkey_main['it618_uid'])){
						$it618_teltmp=$it618_members_rzuser['it618_tel'];
					}
				}
			}
			
			if($it618_teltmp!=''){
				$tel=$it618_teltmp;
				if($it618_witkey_user['it618_msgisok']==1){
					$Body=$it618_body_pf_post;
					$msguid=$it618_witkey_main['it618_uid'];
					
					$uid=$it618_witkey_main['it618_uid'];
					$tplid_wxsms=$it618_body_pf_post_tplid_wxsms;
					$body_wxsms=$it618_body_pf_post_wxsms;
					if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
						$param_wxsms=array();
						$tmparr=explode("@",$body_wxsms);
						for($i=0;$i<count($tmparr);$i++){
							$tmparr1=explode("|",$tmparr[$i]);
							$tmplabel=$tmparr1[0];
							$tmpvalue=$tmparr1[1];
							
							$tmpvalue=str_replace("{user}",it618_witkey_getusername($it618_witkey_pf['it618_uid']),$tmpvalue);
							$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
							$tmpvalue=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_pf['it618_tid']),$it618_length),$tmpvalue);
							
							$param_wxsms[$tmplabel]=array();
							$param_wxsms[$tmplabel]["value"]=it618_witkey_gbktoutf($tmpvalue);
							$param_wxsms[$tmplabel]["color"]="#666666";
						}
					}
		
					$ALDYBody=$Body;
					$Body=str_replace("{user}",it618_witkey_getusername($it618_witkey_pf['it618_getuid']),$Body);
					$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
					$Body=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_pf['it618_tid']),$it618_length),$Body);
					
					if($it618_type!='smsbao'){
						$tplid=$it618_body_pf_post_tplid;
						
						$tmparr=explode("{user}",$ALDYBody);
						if(count($tmparr)>1)$param.='"user":"'.it618_witkey_getusername($it618_witkey_pf['it618_getuid']).'",';
						
						$tmparr=explode("{name}",$ALDYBody);
						if(count($tmparr)>1)$param.='"name":"'.it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_pf['it618_tid']),$it618_length).'",';
						
						$tmparr=explode("{time}",$ALDYBody);
						if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
						
						if($param!=''){
							$param.='@';
							$param=str_replace(",@","",$param);
						}
					}
				}
			}
		}
		
		if($type=='adminpf_post'&&$it618_body_adminpf_post_isok==1){
			$it618_witkey_pf=DB::fetch_first("select * from ".DB::table('it618_witkey_pf')." where id=$id");
			$it618_witkey_main=DB::fetch_first("select * from ".DB::table('it618_witkey_main')." where it618_tid=".$it618_witkey_pf['it618_tid']);
			$tmpurl=it618_witkey_gettidurl($it618_witkey_main['it618_tid']);
			
			$it618_witkey_user=DB::fetch_first("select * from ".DB::table('it618_witkey_user')." where it618_uid=".$it618_witkey_main['it618_uid']);
			$it618_teltmp=$it618_witkey_user['it618_tel'];
			
			if($it618_witkey['witkey_rzdatatype']==1){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$it618_witkey_main['it618_uid'])){
						$it618_teltmp=$it618_members_user['it618_tel'];
					}
				}
			}
			
			if($it618_witkey['witkey_rzdatatype']==2){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$it618_witkey_main['it618_uid'])){
						$it618_teltmp=$it618_members_rzuser['it618_tel'];
					}
				}
			}
			
			if($it618_teltmp!=''){
				$tel=$it618_teltmp;
				if($it618_witkey_user['it618_msgisok']==1){
					$Body=$it618_body_adminpf_post;
					$msguid=$it618_witkey_main['it618_uid'];
					
					$uid=$it618_witkey_main['it618_uid'];
					$tplid_wxsms=$it618_body_adminpf_post_tplid_wxsms;
					$body_wxsms=$it618_body_adminpf_post_wxsms;
					if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
						$param_wxsms=array();
						$tmparr=explode("@",$body_wxsms);
						for($i=0;$i<count($tmparr);$i++){
							$tmparr1=explode("|",$tmparr[$i]);
							$tmplabel=$tmparr1[0];
							$tmpvalue=$tmparr1[1];
							
							$tmpvalue=str_replace("{user}",it618_witkey_getusername($it618_witkey_pf['it618_getuid']),$tmpvalue);
							$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
							$tmpvalue=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_pf['it618_tid']),$it618_length),$tmpvalue);
							
							$param_wxsms[$tmplabel]=array();
							$param_wxsms[$tmplabel]["value"]=it618_witkey_gbktoutf($tmpvalue);
							$param_wxsms[$tmplabel]["color"]="#666666";
						}
					}
		
					$ALDYBody=$Body;
					$Body=str_replace("{user}",it618_witkey_getusername($it618_witkey_pf['it618_getuid']),$Body);
					$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
					$Body=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_pf['it618_tid']),$it618_length),$Body);
					
					if($it618_type!='smsbao'){
						$tplid=$it618_body_adminpf_post_tplid;
						
						$tmparr=explode("{user}",$ALDYBody);
						if(count($tmparr)>1)$param.='"user":"'.it618_witkey_getusername($it618_witkey_pf['it618_getuid']).'",';
						
						$tmparr=explode("{name}",$ALDYBody);
						if(count($tmparr)>1)$param.='"name":"'.it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_pf['it618_tid']),$it618_length).'",';
						
						$tmparr=explode("{time}",$ALDYBody);
						if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
						
						if($param!=''){
							$param.='@';
							$param=str_replace(",@","",$param);
						}
					}
				}
			}
		}
		
		if($type=='rx_user'&&$it618_body_rx_user_isok==1){
			$it618_witkey_witkey=DB::fetch_first("select * from ".DB::table('it618_witkey')." where id=$id");
			$tmpurl=it618_witkey_gettidurl($it618_witkey_witkey['it618_tid']);
			
			$it618_witkey_user=DB::fetch_first("select * from ".DB::table('it618_witkey_user')." where it618_uid=".$it618_witkey_witkey['it618_uid']);
			$it618_teltmp=$it618_witkey_user['it618_tel'];
			
			if($it618_witkey['witkey_rzdatatype']==1){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$it618_witkey_witkey['it618_uid'])){
						$it618_teltmp=$it618_members_user['it618_tel'];
					}
				}
			}
			
			if($it618_witkey['witkey_rzdatatype']==2){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$it618_witkey_witkey['it618_uid'])){
						$it618_teltmp=$it618_members_rzuser['it618_tel'];
					}
				}
			}
			
			if($it618_teltmp!=''){
				$tel=$it618_teltmp;
				if($it618_witkey_user['it618_msgisok']==1){
					$Body=$it618_body_rx_user;
					$msguid=$it618_witkey_witkey['it618_uid'];
					
					$uid=$it618_witkey_witkey['it618_uid'];
					$tplid_wxsms=$it618_body_rx_user_tplid_wxsms;
					$body_wxsms=$it618_body_rx_user_wxsms;
					if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
						$param_wxsms=array();
						$tmparr=explode("@",$body_wxsms);
						for($i=0;$i<count($tmparr);$i++){
							$tmparr1=explode("|",$tmparr[$i]);
							$tmplabel=$tmparr1[0];
							$tmpvalue=$tmparr1[1];
							
							$tmpvalue=str_replace("{user}",it618_witkey_getusername($it618_witkey_witkey['it618_uid']),$tmpvalue);
							$tmpvalue=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_witkey['it618_tid']),$it618_length),$tmpvalue);
							
							$param_wxsms[$tmplabel]=array();
							$param_wxsms[$tmplabel]["value"]=it618_witkey_gbktoutf($tmpvalue);
							$param_wxsms[$tmplabel]["color"]="#666666";
						}
					}
		
					$ALDYBody=$Body;
					$Body=str_replace("{user}",it618_witkey_getusername($it618_witkey_witkey['it618_uid']),$Body);
					$Body=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_witkey['it618_tid']),$it618_length),$Body);
					
					if($it618_type!='smsbao'){
						$tplid=$it618_body_rx_user_tplid;
						
						$tmparr=explode("{user}",$ALDYBody);
						if(count($tmparr)>1)$param.='"user":"'.it618_witkey_getusername($it618_witkey_witkey['it618_uid']).'",';
						
						$tmparr=explode("{name}",$ALDYBody);
						if(count($tmparr)>1)$param.='"name":"'.it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_witkey['it618_tid']),$it618_length).'",';
						
						if($param!=''){
							$param.='@';
							$param=str_replace(",@","",$param);
						}
					}
				}
			}

		}
		
		if($type=='delget_user'&&$it618_body_delget_user_isok==1){
			$tmpurl=it618_witkey_gettidurl($type1);
			$it618_witkey_user=DB::fetch_first("select * from ".DB::table('it618_witkey_user')." where it618_uid=".$id);
			$it618_teltmp=$it618_witkey_user['it618_tel'];
			
			if($it618_witkey['witkey_rzdatatype']==1){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$id)){
						$it618_teltmp=$it618_members_user['it618_tel'];
					}
				}
			}
			
			if($it618_witkey['witkey_rzdatatype']==2){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$id)){
						$it618_teltmp=$it618_members_rzuser['it618_tel'];
					}
				}
			}
			
			if($it618_teltmp!=''){
				$tel=$it618_teltmp;
				if($it618_witkey_user['it618_msgisok']==1){
					$Body=$it618_body_delget_user;
					$msguid=$id;
					
					$uid=$id;
					$tplid_wxsms=$it618_body_delget_user_tplid_wxsms;
					$body_wxsms=$it618_body_delget_user_wxsms;
					if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
						$param_wxsms=array();
						$tmparr=explode("@",$body_wxsms);
						for($i=0;$i<count($tmparr);$i++){
							$tmparr1=explode("|",$tmparr[$i]);
							$tmplabel=$tmparr1[0];
							$tmpvalue=$tmparr1[1];
							
							$tmpvalue=str_replace("{user}",it618_witkey_getusername($id),$tmpvalue);
							$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
							$tmpvalue=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($type1),$it618_length),$tmpvalue);
							
							$param_wxsms[$tmplabel]=array();
							$param_wxsms[$tmplabel]["value"]=it618_witkey_gbktoutf($tmpvalue);
							$param_wxsms[$tmplabel]["color"]="#666666";
						}
					}
		
					$ALDYBody=$Body;
					$Body=str_replace("{user}",it618_witkey_getusername($id),$Body);
					$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
					$Body=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($type1),$it618_length),$Body);
					
					if($it618_type!='smsbao'){
						$tplid=$it618_body_delget_user_tplid;
						
						$tmparr=explode("{user}",$ALDYBody);
						if(count($tmparr)>1)$param.='"user":"'.it618_witkey_getusername($id).'",';
						
						$tmparr=explode("{name}",$ALDYBody);
						if(count($tmparr)>1)$param.='"name":"'.it618_witkey_getsmsstr(it618_witkey_getsubject($type1),$it618_length).'",';
						
						$tmparr=explode("{time}",$ALDYBody);
						if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
						
						if($param!=''){
							$param.='@';
							$param=str_replace(",@","",$param);
						}
					}
				}
			}

		}
		
		if($type=='adminpf_user'&&$it618_body_adminpf_user_isok==1){
			$it618_witkey_pf=DB::fetch_first("select * from ".DB::table('it618_witkey_pf')." where id=$id");
			$tmpurl=it618_witkey_gettidurl($it618_witkey_pf['it618_tid']);
			
			$it618_witkey_user=DB::fetch_first("select * from ".DB::table('it618_witkey_user')." where it618_uid=".$it618_witkey_pf['it618_getuid']);
			$it618_teltmp=$it618_witkey_user['it618_tel'];
			
			if($it618_witkey['witkey_rzdatatype']==1){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$it618_witkey_pf['it618_getuid'])){
						$it618_teltmp=$it618_members_user['it618_tel'];
					}
				}
			}
			
			if($it618_witkey['witkey_rzdatatype']==2){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$it618_witkey_pf['it618_getuid'])){
						$it618_teltmp=$it618_members_rzuser['it618_tel'];
					}
				}
			}
			
			if($it618_teltmp!=''){
				$tel=$it618_teltmp;
				if($it618_witkey_user['it618_msgisok']==1){
					$Body=$it618_body_adminpf_user;
					$msguid=$it618_witkey_pf['it618_getuid'];
					
					$uid=$it618_witkey_witkey['it618_uid'];
					$tplid_wxsms=$it618_body_adminpf_user_tplid_wxsms;
					$body_wxsms=$it618_body_adminpf_user_wxsms;
					if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
						$param_wxsms=array();
						$tmparr=explode("@",$body_wxsms);
						for($i=0;$i<count($tmparr);$i++){
							$tmparr1=explode("|",$tmparr[$i]);
							$tmplabel=$tmparr1[0];
							$tmpvalue=$tmparr1[1];
							
							$tmpvalue=str_replace("{user}",it618_witkey_getusername($it618_witkey_pf['it618_getuid']),$tmpvalue);
							$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
							$tmpvalue=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_pf['it618_tid']),$it618_length),$tmpvalue);
							
							$param_wxsms[$tmplabel]=array();
							$param_wxsms[$tmplabel]["value"]=it618_witkey_gbktoutf($tmpvalue);
							$param_wxsms[$tmplabel]["color"]="#666666";
						}
					}
		
					$ALDYBody=$Body;
					$Body=str_replace("{user}",it618_witkey_getusername($it618_witkey_pf['it618_getuid']),$Body);
					$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
					$Body=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_pf['it618_tid']),$it618_length),$Body);
					
					if($it618_type!='smsbao'){
						$tplid=$it618_body_adminpf_user_tplid;
						
						$tmparr=explode("{user}",$ALDYBody);
						if(count($tmparr)>1)$param.='"user":"'.it618_witkey_getusername($it618_witkey_pf['it618_getuid']).'",';
						
						$tmparr=explode("{name}",$ALDYBody);
						if(count($tmparr)>1)$param.='"name":"'.it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_pf['it618_tid']),$it618_length).'",';
						
						$tmparr=explode("{time}",$ALDYBody);
						if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
						
						if($param!=''){
							$param.='@';
							$param=str_replace(",@","",$param);
						}
					}
				}
			}

		}
		
		if($type=='jl_user'&&$it618_body_jl_user_isok==1){
			$it618_witkey_witkey=DB::fetch_first("select * from ".DB::table('it618_witkey')." where id=$id");
			$tmpurl=it618_witkey_gettidurl($it618_witkey_witkey['it618_tid']);
			
			$it618_witkey_user=DB::fetch_first("select * from ".DB::table('it618_witkey_user')." where it618_uid=".$it618_witkey_witkey['it618_uid']);
			$it618_teltmp=$it618_witkey_user['it618_tel'];
			
			if($it618_witkey['witkey_rzdatatype']==1){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$it618_witkey_witkey['it618_uid'])){
						$it618_teltmp=$it618_members_user['it618_tel'];
					}
				}
			}
			
			if($it618_witkey['witkey_rzdatatype']==2){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
					if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$it618_witkey_witkey['it618_uid'])){
						$it618_teltmp=$it618_members_rzuser['it618_tel'];
					}
				}
			}
			
			if($it618_teltmp!=''){
				$tel=$it618_teltmp;
				if($it618_witkey_user['it618_msgisok']==1){
					$Body=$it618_body_jl_user;
					$msguid=$it618_witkey_witkey['it618_uid'];
					
					if($type1==1)$mode=it618_witkey_getlang('s466');
					if($type1==2)$mode=it618_witkey_getlang('s467');
					if($type1==3)$mode=it618_witkey_getlang('s468');
					
					$tmpmoney=$it618_witkey_witkey['it618_creditnum'];
					if($money>0)$tmpmoney=$money;
					
					$uid=$it618_witkey_witkey['it618_uid'];
					$tplid_wxsms=$it618_body_jl_user_tplid_wxsms;
					$body_wxsms=$it618_body_jl_user_wxsms;
					if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
						$param_wxsms=array();
						$tmparr=explode("@",$body_wxsms);
						for($i=0;$i<count($tmparr);$i++){
							$tmparr1=explode("|",$tmparr[$i]);
							$tmplabel=$tmparr1[0];
							$tmpvalue=$tmparr1[1];
							
							$tmpvalue=str_replace("{user}",it618_witkey_getusername($it618_witkey_witkey['it618_uid']),$tmpvalue);
							$tmpvalue=str_replace("{mode}",$mode,$tmpvalue);
							$tmpvalue=str_replace("{money}",$tmpmoney,$tmpvalue);
							$tmpvalue=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_witkey['it618_tid']),$it618_length),$tmpvalue);
							
							$param_wxsms[$tmplabel]=array();
							$param_wxsms[$tmplabel]["value"]=it618_witkey_gbktoutf($tmpvalue);
							$param_wxsms[$tmplabel]["color"]="#666666";
						}
					}
		
					$ALDYBody=$Body;
					$Body=str_replace("{user}",it618_witkey_getusername($it618_witkey_witkey['it618_uid']),$Body);
					$Body=str_replace("{mode}",$mode,$Body);
					$Body=str_replace("{money}",$tmpmoney,$Body);
					$Body=str_replace("{name}",it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_witkey['it618_tid']),$it618_length),$Body);
					
					if($it618_type!='smsbao'){
						$tplid=$it618_body_jl_user_tplid;
						
						$tmparr=explode("{user}",$ALDYBody);
						if(count($tmparr)>1)$param.='"user":"'.it618_witkey_getusername($it618_witkey_witkey['it618_uid']).'",';
						
						$tmparr=explode("{mode}",$ALDYBody);
						if(count($tmparr)>1)$param.='"mode":"'.$mode.'",';
						
						$tmparr=explode("{money}",$ALDYBody);
						if(count($tmparr)>1)$param.='"money":"'.$tmpmoney.'",';
						
						$tmparr=explode("{name}",$ALDYBody);
						if(count($tmparr)>1)$param.='"name":"'.it618_witkey_getsmsstr(it618_witkey_getsubject($it618_witkey_witkey['it618_tid']),$it618_length).'",';
						
						if($param!=''){
							$param.='@';
							$param=str_replace(",@","",$param);
						}
					}
				}
			}

		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($Body!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_smsbaosign!='')$it618_smsbaosign=it618_witkey_getlang('s882').$it618_smsbaosign.it618_witkey_getlang('s883');
				if($msguid>0){
					$creditnum=DB::result_first("select extcredits".$it618_witkey['witkey_msgcredit']." from ".DB::table('common_member_count')." where uid=".$msguid);
					if($creditnum>=$it618_creditcount){
						if($it618_type=='smsbao'){
							$tmpstr=sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
						}else{
							$tmpstr=sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
						}
						if($tmpstr=="0"||$tmpstr=="ok"){
							C::t('common_member_count')->increase($msguid, array(
								'extcredits'.$it618_witkey['witkey_msgcredit'] => (0-$it618_creditcount))
							);
						}
					}
				}else{
					if($it618_type=='smsbao'){
						sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
					}else{
						sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
					}
				}
			}
		}
	}
}

function it618_witkey_getsmsstr($strtmp,$length){
	if($length>0){
		$tmpstr = "";
		$strlen = $length;
		for($i = 0; $i < $strlen; $i++){
			if(ord(substr($strtmp, $i, 1)) > 0xa0) {
				if(CHARSET=='gbk'){
					$tmpstr .= substr($strtmp, $i, 2);
					$i++;
				}else{
					$tmpstr.=substr($str,$i,3);
					$i+=2;
				}
			} else {
				$tmpstr .= substr($strtmp, $i, 1);
			}
			
		}
		return $tmpstr; 
	}
	return $strtmp;
}

function it618_witkey_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_witkey']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_witkey/config/rewrite.php')){
		if(isset($_GET['pc']))$url=$url.'&pc';
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_witkey/config/rewrite.php';
	
	if($pagetype=='witkey_home'){
		return $witkey_home.$urltype;
	}
	
	if($pagetype=='witkey_wap'){//witkey_wap-{pagetype}-{cid}-{uid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$witkey_wap.$witkey_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid}-{uid}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("-{cid}-{uid}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{uid}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_witkey_gettidurl($tid){
	global $_G;
	if($_G['cache']['plugin']['it618_witkey']['rewriteurl']==1){
		return 'thread-'.$tid.'-1-1.html';
	}else{
		return 'forum.php?mod=viewthread&tid='.$tid;
	}
}

function it618_witkey_get_contents($str){
	return dfsockopen($str);
}

function it618_witkey_rewriteurl($fl_html){
	global $_G;
	if($_G['cache']['plugin']['it618_witkey']['rewriteurl']==1){
		//	forum.php?mod=viewthread&tid=43
		//	thread-43-1-1.html
		$tmparr=explode("forum.php?mod=viewthread",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"tid=")==1){
					$tmp=str_replace("&tid=","thread-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'-1-1.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}
		
		$tmparr=explode("do=album&id=",$fl_html);
		if(count($tmparr)>1){return $fl_html;}
		
		//	home.php?mod=space&uid=5
		//	space-uid-5.html
		$tmparr=explode("home.php?mod=space",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"uid=")==1){
					$tmp=str_replace("&uid=","space-uid-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}

	}
	
	return $fl_html;
}

function it618_witkey_getusername($uid){
	return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
}

function it618_witkey_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_witkey_gbktoutf($strcontent);
	}
}

function it618_witkey_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_witkey_getwapppic($get_it618_picbig,$type=1){
	$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
	$tmpname=md5($get_it618_picbig);
	$it618_smallurl='source/plugin/it618_witkey/img/wapad/'.$tmpname.'.'.$file_ext;
	
	if($type==1){
		if(!file_exists($it618_smallurl))$flag=1;
	}else{
		$flag=1;
	}
	if($flag==1) {
			
		$smallpath=DISCUZ_ROOT.'./source/plugin/it618_witkey/img/wapad';
		if(!file_exists($smallpath)) {
			mkdir($smallpath);
		}
	
		$tmparr1=explode("://",$get_it618_picbig);
		if(count($tmparr1)>1){
			$it618_url=$get_it618_picbig;
		}else{
			$tmparr=explode("source",$get_it618_picbig);
			$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
		}
		
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_witkey/img/wapad/'.$tmpname.'.'.$file_ext;
		it618_witkey_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,280);
		$it618_smallurl='source/plugin/it618_witkey/img/wapad/'.$tmpname.'.'.$file_ext;
	}
	
	return $it618_smallurl;
}

function it618_witkey_imagetosmall1($imagepath,$max){
	$file_ext=strtolower(substr($imagepath,strrpos($imagepath, '.')+1)); 
	
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($imagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($imagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($imagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($imagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	//�������ֵ�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
	if($w > $max){ 
	   $w=$max;
	   $h=$h*($max/$size_src['0']); 
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if(file_exists($imagepath)){
		$result=unlink($imagepath);
	}
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$imagepath); 
	if($file_ext=='png')imagepng($image,$imagepath); 
	if($file_ext=='gif')imagegif($image,$imagepath); 
	@chmod($imagepath, 0644);
	
	//������Դ 
	imagedestroy($image);  
}

function it618_witkey_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height,$type=1){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function it618_witkey_filedown($file_path,$file_name,$file_ext) {
	$tmparr=explode("://",$file_path);
	if(count($tmparr)>1){
		$info = get_headers($file_path, true);
		$file_size = $info['Content-Length'];
		readfile($file_path);
	}else{
		$file_path = iconv('utf-8', 'gb2312', $file_path);
		if (!file_exists($file_path)) {
		  echo 'err';exit;
		}
		$file_size = filesize($file_path);
		$fp = fopen($file_path, 'r');
		$buffer = 1024;
		$file_count = 0;
		while (!feof($fp) && ($file_size-$file_count>0)) {
		  $file_data = fread($fp, $buffer);
		  $file_count += $buffer;
		  echo $file_data;
		}
		fclose($fp);
	}
	
	if($file_ext=='gif'||$file_ext=='jpg'||$file_ext=='jpeg'||$file_ext=='png'){
		header("Content-type: image/$file_ext");
	}else{
		header("Content-type: application/octet-stream");
		header("Accept-Ranges: bytes");
		header("Accept-Length: {$file_size}");
		header("Content-Disposition: attachment;filename={$file_name}");
	}

	if(count($tmparr)>1){
		readfile($file_path);
	}else{
		$fp = fopen($file_path, 'r');
		$buffer = 1024;
		$file_count = 0;
		while (!feof($fp) && ($file_size-$file_count>0)) {
		  $file_data = fread($fp, $buffer);
		  $file_count += $buffer;
		  echo $file_data;
		}
		fclose($fp);
	}
}

function witkey_qrcode($url){
	include DISCUZ_ROOT.'./source/plugin/it618_witkey/phpqrcode.php';
	
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/it618_witkey/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function witkey_is_mobile(){ 
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: Dism_taobao-com
?>