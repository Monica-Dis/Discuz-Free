<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_witkey/config/rewrite.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_witkey/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$witkey_home=\''.'witkey'."';\n";
		$fileData .= '$witkey_wap=\''.'witkey_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$witkey_home1=\''.$urltype."';\n";
		$fileData .= '$witkey_wap1=\'-{pagetype}-{cid}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_witkey/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$witkey_home=\''.str_replace("-","",$_GET['witkey_home'])."';\n";
		$fileData .= '$witkey_wap=\''.str_replace("-","",$_GET['witkey_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$witkey_home1=\''.$urltype."';\n";
		$fileData .= '$witkey_wap1=\'-{pagetype}-{cid}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_witkey_lang['s390'], "action=plugins&identifier=$identifier&cp=admin_rewrite&pmod=admin_rewrite&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_rewrite&pmod=admin_rewrite&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_witkey_lang['s394'].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_witkey_lang['s436'].'</font></td></tr>
<tr><td colspan="3">'.$it618_witkey_lang['s437'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_witkey_lang['s438'].'</th><th>'.$it618_witkey_lang['s439'].'</th><th>'.$it618_witkey_lang['s440'].'</th></tr>
<tr class="hover">
<td>'.$it618_witkey_lang['s392'].'</td><td></td><td class="longtxt"><input name="witkey_home" value="'.$witkey_home.'"/>'.$witkey_home.$witkey_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_witkey_lang['s393'].'</td><td>{pagetype}, {cid}</td><td class="longtxt"><input name="witkey_wap" value="'.$witkey_wap.'"/>'.$witkey_wap.$witkey_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_witkey_lang['s391']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_witkey_lang['s448'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$witkey_home.$urltype.'$ $1/plugin.php?id=it618_witkey:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$witkey_wap.$urltype.'$ $1/plugin.php?id=it618_witkey:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$witkey_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_witkey:wap&pagetype=$2&cid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$witkey_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_witkey:wap&pagetype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_witkey_lang['s449'].'</h1>
<pre class="colorbox">
'.$it618_witkey_lang['s450'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$witkey_home.$urltype.'$ plugin.php?id=it618_witkey:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$witkey_wap.$urltype.'$ plugin.php?id=it618_witkey:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$witkey_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_witkey:wap&pagetype=$1&cid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$witkey_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_witkey:wap&pagetype=$1&%1</font>

</pre>

<h1>'.$it618_witkey_lang['s451'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$witkey_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_witkey:index&$3
RewriteRule ^(.*)/'.$witkey_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_witkey:wap&$3
RewriteRule ^(.*)/'.$witkey_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_witkey:wap&pagetype=$2&cid=$3&$4
RewriteRule ^(.*)/'.$witkey_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_witkey:wap&pagetype=$2&$4</font>

</pre>

<h1>'.$it618_witkey_lang['s452'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="witkey_home"&gt;
			&lt;match url="^(.*/)*'.$witkey_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_witkey:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="witkey_wap"&gt;
			&lt;match url="^(.*/)*'.$witkey_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_witkey:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="witkey_wap2"&gt;
			&lt;match url="^(.*/)*'.$witkey_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_witkey:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="witkey_wap1"&gt;
			&lt;match url="^(.*/)*'.$witkey_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_witkey:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$witkey_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_witkey:index&$2
endif
match URL into $ with ^(.*)/'.$witkey_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_witkey:wap&$2
endif
match URL into $ with ^(.*)/'.$witkey_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_witkey:wap&pagetype=$2&cid=$3&$4
endif
match URL into $ with ^(.*)/'.$witkey_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_witkey:wap&pagetype=$2&$3
endif</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$witkey_home.$urltype.'$ $1/plugin.php?id=it618_witkey:index&$2 last;
rewrite ^([^\.]*)/'.$witkey_wap.$urltype.'$ $1/plugin.php?id=it618_witkey:wap&$2 last;
rewrite ^([^\.]*)/'.$witkey_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_witkey:wap&pagetype=$2&cid=$3&$4 last;
rewrite ^([^\.]*)/'.$witkey_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_witkey:wap&pagetype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=12)return;
showtablefooter();/*Dism��taobao��com*/

?>