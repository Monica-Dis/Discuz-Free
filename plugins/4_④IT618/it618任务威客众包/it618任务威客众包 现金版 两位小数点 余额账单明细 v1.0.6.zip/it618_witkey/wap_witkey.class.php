<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class mobileplugin_it618_witkey {
	function global_footer_mobile(){
		global $_G,$it618_witkey_lang;
		$it618_wike = $_G['cache']['plugin']['it618_wike'];
		$it618_witkey = $_G['cache']['plugin']['it618_witkey'];
		$it618_members = $_G['cache']['plugin']['it618_members'];
		$wike_forums = unserialize($it618_wike["wike_forums"]);
		$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
		$i1il11i=DB::result_first("SELECT it618_witkey FROM ".DB::table('it618_witkey_it618'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		if(count($i1iii1)!=12)return;
		
		if($_GET['mod']=="post"&&$_GET['action']=="newthread"&&!(isset($_GET['special'])||isset($_GET['specialextra'])||isset($_GET['topicsubmit']))){
			if(in_array($_GET['fid'], $wike_forums)&&in_array($_GET['fid'], $witkey_forums)){
				if($_GET['paytype']!='credit'&&$_GET['paytype']!='money'){
					$urlarr=explode("https://",$_G['siteurl']);
					if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';		
					$url_this = $httpstr.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
					
					return '<script>if(confirm("'.$it618_witkey_lang['s675'].'"))location.href="'.$url_this.'&paytype=money";else location.href="'.$url_this.'&paytype=credit";</script>';
				}else{
					$paytype=$_GET['paytype'];
				}
			}else{
				if(in_array($_GET['fid'], $wike_forums)){
					$paytype='credit';
				}
				if(in_array($_GET['fid'], $witkey_forums)){
					$paytype='money';
				}
			}
		}

		if($i1iii1[5]!='_')return;
		if($paytype=='money'&&$_GET['mod']=="post"&&$_GET['action']=="newthread"&&!(isset($_GET['special'])||isset($_GET['specialextra']))&&in_array($_GET['fid'], $witkey_forums)){
			$isok=1;
			if($it618_members['members_bdok']==1){
				if($it618_members["members_bdtype"]==1&&$_GET['action']=='newthread')$flag=1;
				if($it618_members["members_bdtype"]==2&&$_GET['action']=='reply')$flag=1;
				if($it618_members["members_bdtype"]==3&&($_GET['action']=='newthread'||$_GET['action']=='reply'))$flag=1;
			
				if($_GET['mod']=='post'&&$flag==1){
					$members_usergroups = unserialize($it618_members["members_usergroups"]);
					$members_forums=unserialize($it618_members['members_forums']);

					if(in_array($_G['groupid'], $members_usergroups)&&in_array($_GET['fid'], $members_forums)) $isok1=1;
					
					if($isok1==1){
						$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid']);
						if($count==0){					
							$isok=0;
						}
					}
				}
				
			}

			if($isok==1){
				$wap=1;
				$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
				$_G['mobiletpl'][IN_MOBILE]='/';
				include template('it618_witkey:witkeypost');
				$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
				$witkeypost=$it618_witkey_block;
			}
		}
		
		if(count($i1iii1)!=12)return;
		return $witkeypost;
	}
	
	function common() {
		global $_G,$it618_witkey_lang;
		$it618_witkey = $_G['cache']['plugin']['it618_witkey'];
		
		require DISCUZ_ROOT.'./source/plugin/it618_witkey/lang.func.php';
		$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
		$i1il11i=DB::result_first("SELECT it618_witkey FROM ".DB::table('it618_witkey_it618'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		if($_GET['mod']=="topicadmin"&&$_GET['action']=="moderate"&&$_GET['operation']=="delete"){
			$tids="#";
			foreach($_GET['moderate'] as $key => $tid) {
				$tid=intval($tid);
				if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_witkey_main')." WHERE it618_tid=".$tid)>0){
					$tids.=",".$tid;
			    }
			}
			$tids=str_replace("#,","",$tids);
			if($tids!="#")showmessage(it618_witkey_getlang('s304').$tids.it618_witkey_getlang('s305'), '', array(), array('alert' => 'info'));
		}
		
		if($_GET['mod']=="post"&&$_GET['action']=="edit"&&$_GET['delete']==1){
			$tid=intval($_GET['tid']);
			if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_witkey_main')." WHERE it618_tid=".$tid)>0){
				showmessage(it618_witkey_getlang('s306'), '', array(), array('alert' => 'info'));
			}
		}
		
		if($_GET['paytype']=='money'&&$_GET['mod']=="post"&&$_GET['action']=="newthread"&&in_array($_GET['fid'], $witkey_forums)&&isset($_GET['subject'])){
			
			$adminauthor=0;
			if($_G['uid']>0){
				$tmpwitkeyadmin=explode(",",$it618_witkey['witkey_witkeyadmin']);
				for($tmpi=0;$tmpi<count($tmpwitkeyadmin);$tmpi++){
				   if($_G['uid']==$tmpwitkeyadmin[$tmpi]){
					   $adminauthor=1;
					   break;
				   }
				}
			}
			$uid = $_G['uid'];
			$it618_mode = intval($_GET['it618_mode']);
			$it618_mancount = intval($_GET['it618_mancount']);
			$it618_bmmoney = floatval($_GET['it618_bmmoney']);
			$it618_moneycount1 = floatval($_GET['it618_moneycount1']);
			$it618_moneycount2 = floatval($_GET['it618_moneycount2']);
			$it618_getwitkeymoney = floatval($_GET['it618_getwitkeymoney']);
			$witkey_groups=(array)unserialize($it618_witkey['witkey_groups']);
			$witkey_witkeymancount=explode(",",$it618_witkey['witkey_witkeymancount']);
			
			$witkey_moneyname=$it618_witkey_lang['s201'];
		
			if(in_array($_G['groupid'], $witkey_groups)){
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/function.func.php';
				
				if(DB::result_first("select count(1) from ".DB::table('it618_witkey_grouppower'))==0){
					showmessage(it618_witkey_getlang('s321'), '', array(), array('alert' => 'info'));
				}
				
				$bmmoney=DB::result_first("SELECT it618_bmmoney FROM ".DB::table('it618_witkey_grouppower')." WHERE it618_groupid=".$_G['groupid']);
				if($it618_bmmoney>$bmmoney){
					showmessage(it618_witkey_getlang('s945').$bmmoney.$witkey_moneyname.it618_witkey_getlang('s946'), '', array(), array('alert' => 'info'));
				}
				
				if(lang('plugin/it618_witkey', $it618_witkey_lang['it618'])!=$it618_witkey_lang['version'])return;
				$count=DB::result_first("select count(1) from ".DB::table('it618_witkey_main')." where it618_state!=1 and it618_uid=".$uid);
				if($adminauthor!=1&&$count>=$it618_witkey['witkey_postnotokcount']){
					showmessage(it618_witkey_getlang('s322').' <font color=red>'.$count.'</font> '.it618_witkey_getlang('s323').' <font color=red>'.$it618_witkey['witkey_postnotokcount'].'</font> '.it618_witkey_getlang('s324'), '', array(), array('alert' => 'info'));
				}
				
				$creditnum=it618_witkey_getumoney($uid,1);
				if($creditnum<$it618_witkey['witkey_mincount']){
					showmessage(it618_witkey_getlang('s3')." <font color=red>".$it618_witkey['witkey_mincount']."</font> ".$witkey_moneyname.",".it618_witkey_getlang('s4')." <font color=red>".$creditnum."</font> ".$witkey_moneyname."!", '', array(), array('alert' => 'info'));
				}
		
				$it618_groupid=$_G['groupid'];
				$it618_posttc=DB::result_first("select it618_posttc from ".DB::table('it618_witkey_grouppower')." where it618_groupid=".$it618_groupid);
				
				if($adminauthor!=1){
					$tmpmoney2arr=explode(",",$it618_witkey['witkey_money2']);
					if($it618_mode==1){
						if($it618_moneycount2<$tmpmoney2arr[0]){
							showmessage($it618_witkey_lang['s475']." <font color=red>".$tmpmoney2arr[0]."</font> ".$witkey_moneyname.$it618_witkey_lang['s477'], '', array(), array('alert' => 'info'));
						}
					}
					if($it618_mode==2){
						if($it618_moneycount2<$tmpmoney2arr[1]){
							showmessage($it618_witkey_lang['s475']." <font color=red>".$tmpmoney2arr[1]."</font> ".$witkey_moneyname.$it618_witkey_lang['s477'], '', array(), array('alert' => 'info'));
						}
						
					}
					if($it618_mode==3){
						if($it618_moneycount2<$tmpmoney2arr[2]){
							showmessage($it618_witkey_lang['s476']." <font color=red>".$tmpmoney2arr[2]."</font> ".$witkey_moneyname.$it618_witkey_lang['s477'], '', array(), array('alert' => 'info'));
						}
					}
				}
				
				if($it618_mode==3){
					if($it618_mancount>$witkey_witkeymancount[2]){
						showmessage($it618_witkey_lang['s547'].'<font color=red>'.$witkey_witkeymancount[2].'</font>', '', array(), array('alert' => 'info'));
					}
					
					if($it618_moneycount2<1){
						showmessage(it618_witkey_getlang('s262'), '', array(), array('alert' => 'info'));
					}
					
					if($it618_mancount<=0){
						showmessage(it618_witkey_getlang('s263'), '', array(), array('alert' => 'info'));
					}
					if(lang('plugin/it618_witkey', $it618_witkey_lang['it618'])!=$it618_witkey_lang['version'])return;
					$curcreditcount=it618_witkey_getumoney($uid,1);
					
					$it618_tcnum=floatval($it618_posttc*$it618_moneycount2*$it618_mancount/100);
					if(($it618_moneycount2*$it618_mancount+$it618_tcnum)>$curcreditcount){
						showmessage(it618_witkey_getlang('s264').$witkey_moneyname."(<font color=red>".$curcreditcount."</font>)".it618_witkey_getlang('s68'), '', array(), array('alert' => 'info'));
					}
					
				}else{
					$tmparr=explode(" ",$_GET['it618_time2']);
					$tmparr1=explode("-",$tmparr[0]);
					$tmparr2=explode(":",$tmparr[1]);
					$it618_time2=mktime($tmparr2[0],$tmparr2[1],$tmparr2[2],$tmparr1[1],$tmparr1[2],$tmparr1[0]);
					
					if($it618_mancount<=0){
						showmessage(it618_witkey_getlang('s83'), '', array(), array('alert' => 'info'));
					}
					if(lang('plugin/it618_witkey', $it618_witkey_lang['it618'])!=$it618_witkey_lang['version'])return;
					if($it618_moneycount2<1){
						showmessage(it618_witkey_getlang('s42'), '', array(), array('alert' => 'info'));
					}
					
					$curcreditcount=it618_witkey_getumoney($uid,1);
					if($it618_mode==2){
						if($it618_mancount>$witkey_witkeymancount[1]){
							showmessage($it618_witkey_lang['s547'].'<font color=red>'.$witkey_witkeymancount[1].'</font>', '', array(), array('alert' => 'info'));
						}
					}else{
						if($it618_mancount>$witkey_witkeymancount[0]){
							showmessage($it618_witkey_lang['s547'].'<font color=red>'.$witkey_witkeymancount[0].'</font>', '', array(), array('alert' => 'info'));
						}
					}
					
					$it618_tcnum=floatval($it618_posttc*$it618_moneycount2/100);	
					if($it618_moneycount2+$it618_tcnum>$curcreditcount){
						showmessage(it618_witkey_getlang('s319').$witkey_moneyname."(<font color=red>".$curcreditcount."</font>)".it618_witkey_getlang('s68'), '', array(), array('alert' => 'info'));
					}
					
					if($it618_time2<=$_G['timestamp']){
						showmessage(it618_witkey_getlang('s44'), '', array(), array('alert' => 'info'));
					}
				}
				if(lang('plugin/it618_witkey', $it618_witkey_lang['it618'])!=$it618_witkey_lang['version'])return;
		
			}else{
				showmessage(it618_witkey_getlang('s182'), '', array(), array('alert' => 'info'));
			}
			
			$uid = $_G['uid'];
			$fid = intval($_GET['fid']);
			$it618_mode = intval($_GET['it618_mode']);
			$it618_read = intval($_GET['it618_read']);
			$it618_hfread = intval($_GET['it618_hfread']);
			$it618_mancount = intval($_GET['it618_mancount']);
			$it618_bmmoney = floatval($_GET['it618_bmmoney']);
			$it618_moneycount1 = floatval($_GET['it618_moneycount1']);
			$it618_moneycount2 = floatval($_GET['it618_moneycount2']);
			$it618_getwitkeymoney = floatval($_GET['it618_getwitkeymoney']);
			if($i1iii1[5]!='_')return;
			$timeStr = str_replace("-","",$_GET['it618_time2']);
			$timeStr = str_replace(" ","",$timeStr);
			$timeStr = str_replace(":","",$timeStr);

			$hour = substr($timeStr,8,2);
			$minute = substr($timeStr,10,2);
			$second= substr($timeStr,12,2);
			$year= substr($timeStr,0,4);
			$month= substr($timeStr,4,2);
			$day = substr($timeStr,6,2);
			$it618_time2=mktime($hour,$minute,$second,$month,$day,$year);
			if(count($i1iii1)!=12)return;
			$it618_select=intval($_GET['it618_select']);
			
			$it618_groupid=$_G['groupid'];
			$it618_posttc=DB::result_first("select it618_posttc from ".DB::table('it618_witkey_grouppower')." where it618_groupid=".$it618_groupid);
			$it618_postjlbl=DB::result_first("select it618_postjlbl from ".DB::table('it618_witkey_grouppower')." where it618_groupid=".$it618_groupid);
			
			if($_GET['it618_uids']!=''){
				$tmpuidsarr=explode(",",$_GET['it618_uids']);
				for($i=0;$i<count($tmpuidsarr);$i++){
					if(it618_witkey_getusername(intval($tmpuidsarr[$i]))!=''){
						$tmpuids.=$tmpuidsarr[$i].',';
					}
				}
				if($tmpuids!=''){
					$tmpuids=$tmpuids.'@';
					$tmpuids=str_replace(",@","",$tmpuids);
				}
			}
			
			$setarr = array(
				  'it618_uid' => $uid,
				  'it618_tid' => $tid,
				  'it618_mode' => $it618_mode,
				  'it618_read' => $it618_read,
				  'it618_hfread' => $it618_hfread,
				  'it618_select' => $it618_select,
				  'it618_mancount' => $it618_mancount,
				  'it618_bmmoney' => $it618_bmmoney,
				  'it618_moneycount1' => $it618_moneycount1,
				  'it618_moneycount2' => $it618_moneycount2,
				  'it618_getwitkeymoney' => $it618_getwitkeymoney,
				  'it618_state' => 10,
				  'it618_tc' => $it618_posttc,
				  'it618_jlbl' => $it618_postjlbl,
				  'it618_time1' => $_G['timestamp'],
				  'it618_time2' => $it618_time2,
				  'it618_title' => $_GET['subject'],
				  'it618_uids' => $tmpuids
			);
			if(count($i1iii1)!=12)return;
			$id = C::t('#it618_witkey#it618_witkey_main')->insert($setarr, true);

			if($id>0){
				if($i1iii1[4]!='8')return;
				$setarr = array(
					  'it618_uid' => $uid,
					  'it618_fid' => $fid,
					  'it618_wid' => $id,
					  'it618_title' => $_GET['subject']
				);
	
				C::t('#it618_witkey#it618_witkey_findtid')->insert($setarr, true);

			}
			
		}
	}
	
	function post_message($value){
		global $_G,$it618_witkey_lang;
		$it618_witkey = $_G['cache']['plugin']['it618_witkey'];
		
		$type=$value['param'][0];
		$fid=$value['param'][2]['fid'];
		$tid=$value['param'][2]['tid'];
		$pid=$value['param'][2]['pid'];
		
		if($type=='post_newthread_succeed'){

			if($it618_witkey_findtid = DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_findtid')." WHERE it618_tid=0 and it618_fid=".$fid." and it618_uid=".$_G['uid']." order by id desc")){
				$it618_uid=$it618_witkey_findtid['it618_uid'];
				$it618_fid=$it618_witkey_findtid['it618_fid'];
				$it618_wid=$it618_witkey_findtid['it618_wid'];
				$it618_title=dhtmlspecialchars($it618_witkey_findtid['it618_title']);
				
				$forum_thread=DB::fetch_first("SELECT subject,authorid,fid,typeid FROM ".DB::table('forum_thread')." WHERE tid=".$tid);

				if($forum_thread['subject']==$it618_title&&$forum_thread['authorid']==$it618_uid&&$forum_thread['fid']==$it618_fid){
					DB::query("update ".DB::table('it618_witkey_findtid')." set it618_tid=".$tid." WHERE id=".$it618_witkey_findtid['id']);
					
					DB::query("UPDATE ".DB::table('it618_witkey_main')." SET it618_tid=".$tid.",it618_title=%s,it618_fid=%d,it618_typeid=%d WHERE id=%d", array($forum_thread['subject'],$forum_thread['fid'],$forum_thread['typeid'],$it618_wid));
					
					$it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE it618_tid=".$tid);
					
					$it618_mode=$it618_witkey_main['it618_mode'];
					$it618_uid=$it618_witkey_main['it618_uid'];
					$it618_moneycount2=$it618_witkey_main['it618_moneycount2'];
					$it618_mancount=$it618_witkey_main['it618_mancount'];
					$it618_posttc=$it618_witkey_main['it618_tc'];
					
					require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/function.func.php';
					
					if($it618_mode!=3){
						$it618_tcnum=floatval($it618_posttc*$it618_moneycount2/100);
						it618_witkey_money('it618_witkey_postwike',$it618_witkey_main['id'],$it618_uid,$it618_moneycount2,$it618_witkey_lang['s582'],2);
						it618_witkey_money('it618_witkey_postwike',$it618_witkey_main['id'],$it618_uid,$it618_tcnum,$it618_witkey_lang['s583'],2);
					}else{
						$it618_tcnum=floatval($it618_posttc*$it618_moneycount2*$it618_mancount/100);
						it618_witkey_money('it618_witkey_postwike',$it618_witkey_main['id'],$it618_uid,($it618_moneycount2*$it618_mancount),$it618_witkey_lang['s582'],2);
						it618_witkey_money('it618_witkey_postwike',$it618_witkey_main['id'],$it618_uid,$it618_tcnum,$it618_witkey_lang['s583'],2);
					}
					
					it618_witkey_sendmessage('witkeypost_admin',$it618_wid);
				}
			}
		}
	}

}

class mobileplugin_it618_witkey_forum extends mobileplugin_it618_witkey{
	
	function forumdisplay_thread_mobile_output(){
		global $_G,$it618_witkey_lang;
			
		$it618_witkey = $_G['cache']['plugin']['it618_witkey'];
		$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
		$witkey_moneyname=$it618_witkey_lang['s201'];
		$i1il11i=DB::result_first("SELECT it618_witkey FROM ".DB::table('it618_witkey_it618'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		if(!in_array($_G[fid], $witkey_forums)) return array();
		
		$thread_subject=array();
		$threadlist = $_G['forum_threadlist'];
		require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/function.func.php';
		foreach($threadlist as $id => $thread){
			if(($it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE it618_tid=".$thread[tid]))){
				$getstate=it618_witkey_getstate($it618_witkey_main,1);
				$getmancount=it618_witkey_getmancount($it618_witkey_main,1);
				$getmode=it618_witkey_getmode($it618_witkey_main,3);
				$getmoney=it618_witkey_getmoney1($it618_witkey_main,1);
				$gettjimg=it618_witkey_gettjimg($it618_witkey_main,1);

				if($i1iii1[2]!='6')return;
				$thread[subject]=$thread[subject].'<div><span style="color:#999; font-size:11px; float:right;">'.date('Y-m-d H:i:s', $it618_witkey_main['it618_time1']).$gettjimg.'</span><span style="color:#999; font-size:11px;">'.$getmancount.'</span>
		<br><span style="color:#999; font-size:11px; float:right">'.$getstate.'</span>
		<span style="margin-top:-2px;float:left;margin-right:3px">'.$getmode.'</span> <span style="color:#999; font-size:11px;">'.$getmoney.'</span></div>';
				$threadlist[$id]=$thread;
			}
		}
		$_G['forum_threadlist']=$threadlist;
		
		return array();
	}
	
	function viewthread_posttop_mobile_output(){
			global $_G,$it618_witkey_lang, $postlist;
			require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/lang.func.php';
			
			$it618_witkey = $_G['cache']['plugin']['it618_witkey'];
			$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
			$witkey_moneyname=$it618_witkey_lang['s201'];
			$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
			if(!in_array($_G[fid], $witkey_forums)) return array();
			$i1il11i=DB::result_first("SELECT it618_witkey FROM ".DB::table('it618_witkey_it618'));
		    $i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
			if($_G[tid]=='')return array();
			if(!($it618_witkey_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_main')." WHERE it618_tid=".$_G[tid]))){
				return array();
			}
			
			$it618_state=$it618_witkey_main['it618_state'];
			$it618_witkey_mainuid=$it618_witkey_main['it618_uid'];
			DB::query("update ".DB::table('it618_witkey_main')." set it618_views=it618_views+1 WHERE it618_tid=".$_G[tid]);
			if(count($i1iii1)!=12)return;
			$n=1;
			
			$tmpwitkeyadmin=explode(",",$it618_witkey['witkey_witkeyadmin']);
			for($tmpi=0;$tmpi<count($tmpwitkeyadmin);$tmpi++){
			   if($_G['uid']==$tmpwitkeyadmin[$tmpi]){
				   $adminauthor=1;
				   break;
			   }
			}
			
			foreach($postlist as $id => $post) {
				if($i1iii1[2]!='6')return;
				
				if($post['first']){
					$it618_first=1;
					$wap=1;
					require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/function.func.php';
					$waphome=it618_witkey_getrewrite('witkey_wap','','plugin.php?id=it618_witkey:wap');
					$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
					$_G['mobiletpl'][IN_MOBILE]='/';
					include template('it618_witkey:witkey');
					$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
					
					$it618_read=$it618_witkey_main['it618_read'];
					if($it618_read==2)$readabout=$it618_witkey_lang['t58'];
					if($it618_read==3)$readabout=$it618_witkey_lang['t83'];
					$readstr='<img src="source/plugin/it618_witkey/images/lock.png" style="vertical-align:middle;height:20px;margin-top:-4px"><font color=red>'.$readabout.'</font>';
					if($postlist[$id]['authorid']!=$_G[uid]){
						if($it618_read==1)$readstr=$post['message'];
						if($it618_read==2){
							if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_tid=".$_G[tid]." and it618_uid=".$_G[uid])>0)$readstr=$post['message'];
						}
						if($it618_read==3){
							if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_tid=".$_G[tid]." and it618_ok=1 and it618_uid=".$_G[uid])>0)$readstr=$post['message'];
						}
					}else{
						$readstr=$post['message'];
					}
					
					if($adminauthor==1){
						$readstr=$post['message'];
					}
					
					$post['message']=$it618_witkey_block.$readstr;
					
					if($i1iii1[3]!='1')return;
					$postlist[$id] =$post;
				}else{
					if($i1iii1[5]!='_')return;
					if($it618_witkey['witkey_isreply']==1){
						$query = DB::query("SELECT * FROM ".DB::table('it618_witkey')." WHERE it618_tid=".$_G[tid]." order by id");
						$it618_mode=$it618_witkey_main['it618_mode'];
						$it618_moneycount2=$it618_witkey_main['it618_moneycount2'];
						if($it618_mode==2){
							$it618_witkey['witkey_jiangedit']=0;
							$it618_witkey['witkey_isreply']=0;
						}
						$it618_witkey_replay="";
						while($it618_witkey_witkey =DB::fetch($query)) {
							if($postlist[$id]['authorid']==$it618_witkey_witkey['it618_uid']){
								 if($it618_mode==3){
									 if($it618_state!=1&&($it618_witkey_mainuid==$_G[uid]||$adminauthor==1)){
											if($it618_witkey_witkey['it618_creditnum']==0){
												$it618_witkey_replay='<div name="it618_witkey_reply'.$it618_witkey_witkey['it618_uid'].'" class="it618_witkey_reply"><a href="javascript:" class="witkeybtn" onclick="if(confirm(\''.it618_witkey_getlang('s299').$it618_witkey_main['it618_moneycount2'].$witkey_moneyname.it618_witkey_getlang('s317').'\')){it618_getajax(\'caina1\',\''.$it618_witkey_witkey['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_witkey:ajax&wap=1&witkeyid='.$it618_witkey_witkey['id'].'&formhash='.FORMHASH.'&ac=caina\')}">'.$it618_witkey_lang['s927'].'</a> '.it618_witkey_getlang('s316').' <font color=red>'.$it618_moneycount2.'</font> <font color=green>'.$witkey_moneyname.'</font></div>';
											}
									 }
									 
								 }else{
									 if($it618_witkey['witkey_jiangedit']==1){
										 $jiangedit=1;
									 }else{
										 if($it618_witkey_witkey['it618_creditnum']>0){
											 $jiangedit=0;
										 }else{
											 $jiangedit=1;
										 }
									 }
									 if($it618_state!=1&&($it618_witkey_mainuid==$_G[uid]||$adminauthor==1)&&$jiangedit==1){
											if($it618_witkey_witkey['it618_ok']==1){
												$it618_witkey_replay='<div name="it618_witkey_reply'.$it618_witkey_witkey['it618_uid'].'" class="it618_witkey_reply" style="display:none"></div>';
												if($it618_mode!=2){
												$it618_witkey_replay='<div name="it618_witkey_reply'.$it618_witkey_witkey['it618_uid'].'" class="it618_witkey_reply">'.$witkey_moneyname.'=<input type="text" value="'.$it618_witkey_witkey['it618_creditnum'].'" id="it618_creditnum'.$postlist[$id]['pid'].'" size="5" name="it618_witkey_replyinput'.$it618_witkey_witkey['it618_uid'].'"/><a href="javascript:" class="witkeybtn" onclick="it618_getajax(\'setmoney1\',\''.$it618_witkey_witkey['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_witkey:ajax&wap=1&witkeyid='.$it618_witkey_witkey['id'].'&it618_creditnum=\'+document.getElementById(\'it618_creditnum'.$postlist[$id]['pid'].'\').value+\'&formhash='.FORMHASH.'&ac=setmoney\')">'.$it618_witkey_lang['s928'].'</a></div>';
												}
											}else{
												$it618_witkey_replay='<div name="tmpdiv'.$it618_witkey_witkey['it618_uid'].'" style="display:none">'.$witkey_moneyname.'=<input type="text" value="0" id="it618_creditnum'.$postlist[$id]['pid'].'" size="5" name="it618_witkey_replyinput'.$it618_witkey_witkey['it618_uid'].'"/><a href="javascript:" class="witkeybtn" onclick="it618_getajax(\'setmoney1\',\''.$it618_witkey_witkey['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_witkey:ajax&wap=1&witkeyid='.$it618_witkey_witkey['id'].'&it618_creditnum=\'+document.getElementById(\'it618_creditnum'.$postlist[$id]['pid'].'\').value+\'&formhash='.FORMHASH.'&ac=setmoney\')">'.$it618_witkey_lang['s928'].'</a></div><div name="it618_witkey_reply'.$it618_witkey_witkey['it618_uid'].'" class="it618_witkey_reply"><a href="javascript:" class="witkeybtn" onclick="if(confirm(\''.it618_witkey_getlang('s247').'\')){it618_getajax(\'setselect1\',\''.$it618_witkey_witkey['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_witkey:ajax&wap=1&tid='.$_G[tid].'&witkeyid='.$it618_witkey_witkey['id'].'&formhash='.FORMHASH.'&ac=setselect\')}">'.$it618_witkey_lang['s929'].'</a></div>';
											}
									 }
									 
									 if($i1iii1[4]!='8')return;
									 
								 }
								 
								 if($it618_witkey_replay==''){
									if($it618_witkey_witkey['it618_creditnum']>0){
										if($it618_mode==3){
											$it618_witkey_replay='<div class="it618_witkey_reply">'.it618_witkey_getlang('s290').' <font color=green>'.$witkey_moneyname.'</font><font color=red>+'.$it618_witkey_witkey['it618_creditnum'].'</font></div>';
										}else{
											 $it618_witkey_replay='<div class="it618_witkey_reply">'.it618_witkey_getlang('s36').' <font color=green>'.$witkey_moneyname.'</font><font color=red>+'.$it618_witkey_witkey['it618_creditnum'].'</font></div>';
										}
									}
								 }
	
							}
						}
						if($i1iii1[6]!='w')return;
					}
					
					if($it618_witkey_main['it618_hfread']==1){
						$hfreadstr='<img src="source/plugin/it618_witkey/images/lock.png" style="vertical-align:middle;height:20px;margin-top:-4px"><font color=red>'.$it618_witkey_lang['s562'].'</font>';
						if($postlist[$id]['authorid']==$_G[uid]){
							$hfreadstr=$post['message'];
						}
					}
					
					if($it618_witkey_main['it618_hfread']==2){
						$hfreadstr=$post['message'];
					}
					
					if($it618_witkey_main['it618_hfread']==3){
						$hfreadstr='<img src="source/plugin/it618_witkey/images/lock.png" style="vertical-align:middle;height:20px;margin-top:-4px"><font color=red>'.$it618_witkey_lang['s566'].'</font>';
						if($postlist[$id]['authorid']!=$_G[uid]){
							if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_tid=".$_G[tid]." and it618_uid=".$_G[uid])>0)$hfreadstr=$post['message'];
						}else{
							$hfreadstr=$post['message'];
						}
					}
					
					if($it618_witkey_main['it618_hfread']==4){
						$hfreadstr='<img src="source/plugin/it618_witkey/images/lock.png" style="vertical-align:middle;height:20px;margin-top:-4px"><font color=red>'.$it618_witkey_lang['s567'].'</font>';
						if($postlist[$id]['authorid']!=$_G[uid]){
							if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey')." WHERE it618_tid=".$_G[tid]." and it618_ok=1 and it618_uid=".$_G[uid])>0)$hfreadstr=$post['message'];
						}else{
							$hfreadstr=$post['message'];
						}
					}
					
					if($adminauthor==1||$it618_witkey_mainuid==$_G[uid]){
						$hfreadstr=$post['message'];
					}
			
					$post['message']=$it618_witkey_replay.$hfreadstr;
					
					$postlist[$id] =$post;
				}
				
				$n=$n+1;
			}
			
			
			return array();
	}

}
//From: Dism_taobao-com
?>