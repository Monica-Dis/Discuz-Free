<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/function.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_witkey/config/message.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/config/message.php';
}

if($it618_isok==1){
	$tmpstr='<font color="green">'.it618_witkey_getlang('s453').'</font> ';
	if($it618_body_getwitkey_post_isok==1)$tmpstr.='<img src="source/plugin/it618_witkey/images/se.gif">';else $tmpstr.='<img src="source/plugin/it618_witkey/images/se0.gif">';
	
	$tmpstr.='<font color="green">'.it618_witkey_getlang('s454').'</font> ';
	if($it618_body_rx_user_isok==1)$tmpstr.='<img src="source/plugin/it618_witkey/images/se.gif">';else $tmpstr.='<img src="source/plugin/it618_witkey/images/se0.gif">';
	
	$tmpstr.='<font color="green">'.it618_witkey_getlang('s455').'</font> ';
	if($it618_body_jl_user_isok==1)$tmpstr.='<img src="source/plugin/it618_witkey/images/se.gif">';else $tmpstr.='<img src="source/plugin/it618_witkey/images/se0.gif">';
	
	$tmpstr='<tr><td>'.$tmpstr.'</td></tr>';
	
}else{
	$tmpstr='<tr><td>'.it618_witkey_getlang('s459').'</td></tr>';
}

$it618_witkey_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_witkey_user')." where it618_uid=".$_G['uid']);
if($it618_witkey_user['it618_msgisok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
if($it618_creditcount=="")$it618_creditcount=0;

$it618_bztel=$it618_witkey_user['it618_tel'];
$it618_tel=$it618_witkey_user['it618_tel'];
$it618_qq=$it618_witkey_user['it618_qq'];
$it618_wx=$it618_witkey_user['it618_wx'];

if($it618_witkey['witkey_rzdatatype']==1){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
			$it618_bztel=$it618_members_user['it618_tel'];
			$it618_tel=$it618_members_user['it618_tel'];
			$csstmp1='readonly="readonly"';
			$cssstyle1='border:none';
		}
	}
}

if($it618_witkey['witkey_rzdatatype']==2){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$_G['uid'])){
			$it618_bztel=$it618_members_rzuser['it618_tel'];
			$it618_tel=$it618_members_rzuser['it618_tel'];
			$it618_qq=$it618_members_rzuser['it618_qq'];
			$it618_wx=$it618_members_rzuser['it618_wx'];
			$csstmp2='readonly="readonly"';
			$cssstyle2='border:none';
		}
	}
}

if($_GET['wap']!=1){
	$tmpqqstr='<tr><td>'.it618_witkey_getlang('s548').'<input type="text" class="settxt" name="it618_qq" '.$csstmp2.' style="'.$cssstyle2.'" value="'.$it618_qq.'"> '.it618_witkey_getlang('s553').'<input type="text" class="settxt" name="it618_bztel" '.$csstmp1.' '.$csstmp2.' style="'.$cssstyle1.''.$cssstyle2.'" value="'.$it618_bztel.'"> '.it618_witkey_getlang('s551').'<input type="text" class="settxt" name="it618_wx" '.$csstmp2.' style="width:226px;'.$cssstyle2.'" value="'.$it618_wx.'"></td></tr>';
}else{
	$tmpqqstr='<tr><td>'.it618_witkey_getlang('s548').'<input type="text" class="settxt" name="it618_qq" '.$csstmp2.' style="'.$cssstyle2.'" value="'.$it618_qq.'"> '.it618_witkey_getlang('s553').'<input type="text" class="settxt" name="it618_bztel" '.$csstmp1.' '.$csstmp2.' style="'.$cssstyle1.''.$cssstyle2.'" value="'.$it618_bztel.'"></td></tr>
<tr><td>'.it618_witkey_getlang('s551').'<input type="text" class="settxt" '.$csstmp2.' name="it618_wx" style="width:236px;'.$cssstyle2.'" value="'.$it618_wx.'"></td></tr>';
}
$tmpstr= '
<tr><td style="padding-top:0"><b>'.it618_witkey_getlang('s457').'</b></td></tr>
'.$tmpstr.'
<tr><td><b>'.it618_witkey_getlang('s465').'</b></td></tr>
<tr><td>'.it618_witkey_getlang('s544').'<font color=red>'.$it618_creditcount.'</font> <font color=green>'.$witkey_moneyname.'</font><br><font color=#999>'.$it618_witkey_lang['s880'].'<font color=green>'.$witkey_moneyname.'</font>'.$it618_witkey_lang['s881'].'</font></td></tr>
<tr><td>'.it618_witkey_getlang('s462').'<input type="text" class="settxt" id="it618_tel" '.$csstmp1.' '.$csstmp2.' name="it618_tel" style="font-weight:bold;color:red;width:100px;'.$cssstyle1.''.$cssstyle2.'" value="'.$it618_tel.'"> <input type="checkbox" id="it618_msgisok" name="it618_msgisok" value="1" class="chk_1" '.$it618_isok_checked.'> <label for="it618_msgisok">'.$it618_witkey_lang['s550'].'</label></td></tr>
<tr><td><b>'.it618_witkey_getlang('s549').'</b></td></tr>
'.$tmpqqstr.'
<tr><td style="border:none;">'.it618_witkey_getlang('s552').'<textarea class="settxt it618textarea" name="it618_bz" style="width:100%;height:80px;padding-top:3px;margin-top:3px">'.$it618_witkey_user['it618_bz'].'</textarea></td></tr>
';

$_G['mobiletpl'][IN_MOBILE]='/';

if($_GET['wap']!=1){
	include template('it618_witkey:showset');
}else{
	include template('it618_witkey:showwapset');
}
//From: Dism_taobao-com
?>