<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/function.func.php';

function it618_witkey_getmodecontent($modetype,$modesql,$modecode,$modecount){
	global $_G;
	$it618_witkey = $_G['cache']['plugin']['it618_witkey'];
	
	$tmparr=explode("[loop]",$modecode);
	$tmparr1=explode("[/loop]",$tmparr[1]);
	
	if($modetype=='witkey_new'||$modetype=='witkey_hot'){
		if($modetype=='witkey_new')$orderby='order by m.id desc';else $orderby='order by m.it618_views desc';
		
		$it618_sql=explode("|",$modesql);
		
		$sql='1';
		
		if($it618_sql[0]!=''){
			$tmparr_sql=explode(",",$it618_sql[0]);
			for($i=0;$i<count($tmparr_sql);$i++){
				$it618_forumid.=','.intval($tmparr_sql[$i]);
			}
			$it618_forumid='@'.$it618_forumid;
			$it618_forumid=str_replace("@,","",$it618_forumid);
			
			$sql.=" and m.it618_fid in(".$it618_forumid.")";
		}
		
		if($it618_sql[1]!=''){
			$tmparr_sql=explode(",",$it618_sql[1]);
			for($i=0;$i<count($tmparr_sql);$i++){
				$it618_forumtypeid.=','.intval($tmparr_sql[$i]);
			}
			$it618_forumtypeid='@'.$it618_forumtypeid;
			$it618_forumtypeid=str_replace("@,","",$it618_forumtypeid);
			
			$sql.=" and m.it618_typeid in(".$it618_forumtypeid.")";
		}
		
		if(intval($it618_sql[2])==0)$sql.="";
		if(intval($it618_sql[2])==1)$sql.=" and m.it618_state=10";
		if(intval($it618_sql[2])==2)$sql.=" and m.it618_state=1";
		
		foreach(C::t('#it618_witkey#it618_witkey_main')->fetch_all_by_search(
				$sql,$orderby,'',0,0,0,0,'','',0,$modecount
		) as $it618_witkey_main) {
			
			$tid=$it618_witkey_main['it618_tid'];
			if($tid==0)continue;
			$uid=$it618_witkey_main['it618_uid'];
			$subject=it618_witkey_getsubject($tid);
			
			$tmparr_n=explode("{name,",$tmparr1[0]);
			if(count($tmparr)>1){
				$tmparr_n1=explode("}",$tmparr_n[1]);
				$name_n=$tmparr_n1[0];
				$subject1=cutstr($subject, $name_n, '');
			}
			
			$getstate=it618_witkey_getstate($it618_witkey_main,0);
			$getmancount=it618_witkey_getmancount($it618_witkey_main,0);
			$getmode=it618_witkey_getmode($it618_witkey_main,0);
			$getmoney=it618_witkey_getmoney($it618_witkey_main,0);
			$gettjimg=it618_witkey_gettjimg($it618_witkey_main,0);
			
			$tmpstr=str_replace("{classname}",it618_witkey_getclass_name($tid),$tmparr1[0]);
			$tmpstr=str_replace("{classurl}",it618_witkey_getclass_url($tid),$tmpstr);
			$tmpstr=str_replace("{name}",$subject,$tmpstr);
			$tmpstr=str_replace("{name,".$name_n."}",$subject1,$tmpstr);
			$tmpstr=str_replace("{url}",'forum.php?mod=viewthread&tid='.$tid,$tmpstr);
			$tmpstr=str_replace("{name}",$subject,$tmpstr);
			$tmpstr=str_replace("{getico}",it618_witkey_getico($tid),$tmpstr);
			$tmpstr=str_replace("{getstate}",$getstate,$tmpstr);
			$tmpstr=str_replace("{getmancount}",$getmancount,$tmpstr);
			$tmpstr=str_replace("{getmode}",$getmode,$tmpstr);
			$tmpstr=str_replace("{getmoney}",$getmoney,$tmpstr);
			$tmpstr=str_replace("{gettjimg}",$gettjimg,$tmpstr);
			$tmpstr=str_replace("{time}",date('Y-m-d', $it618_witkey_main['it618_time1']),$tmpstr);
			$tmpstr=str_replace("{username}",it618_witkey_getauthor($uid),$tmpstr);
			$tmpstr=str_replace("{userurl}",'home.php?mod=space&uid='.$uid,$tmpstr);
			
			$content.=it618_witkey_rewriteurl($tmpstr);
			
		}
	}
	
	$content=$tmparr[0].$content.$tmparr1[1];
	$content=str_replace("{siteurl}",$_G['siteurl'],$content);
	
	$allcount = C::t('#it618_witkey#it618_witkey_main')->count_by_search();
	$allmoney = C::t('#it618_witkey#it618_witkey_main')->sum_jlmoney_by_search();
	
	$content=str_replace("{allcount}",$allcount,$content);
	$content=str_replace("{summoney}",$allmoney,$content);
	
	return $content;
}
//From: Dism_taobao-com
?>