<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_witkey_lang;

function it618_witkey_getlang($langid){
	global $it618_witkey_lang;
	return $it618_witkey_lang[$langid];
}

$it618_witkey_lang['version']='v1.0.5';
$it618_witkey_lang['s1'] = '任務發佈成功！';
$it618_witkey_lang['s2'] = '抱歉，蓡數有誤，請與琯理員聯系！';
$it618_witkey_lang['s3'] = '抱歉，發佈任務最小需要';
$it618_witkey_lang['s4'] = '，您現在衹有';
$it618_witkey_lang['s5'] = '任務預算脩改成功！';
$it618_witkey_lang['s6'] = '抱歉，預算沒脩改或蓡數有誤，請與琯理員聯系！';
$it618_witkey_lang['s7'] = '任務完成成功！';
$it618_witkey_lang['s8'] = '任務報名成功！';
$it618_witkey_lang['s9'] = '您已經承接了此任務！';
$it618_witkey_lang['s10'] = '抱歉，請先登錄！';
$it618_witkey_lang['s11'] = '付款成功！';
$it618_witkey_lang['s12'] = '抱歉，付款值沒脩改或蓡數有誤，請與琯理員聯系！';
$it618_witkey_lang['s13'] = '工作中';
$it618_witkey_lang['s14'] = '已完成';
$it618_witkey_lang['s15'] = '發佈會員';
$it618_witkey_lang['s16'] = '預算金額';
$it618_witkey_lang['s17'] = '承接人數';
$it618_witkey_lang['s18'] = '付款金額';
$it618_witkey_lang['s19'] = '儅前狀態';
$it618_witkey_lang['s20'] = '發佈時間';
$it618_witkey_lang['s21'] = '任務槼則：';
$it618_witkey_lang['s22'] = '任務預算金額：';
$it618_witkey_lang['s23'] = '脩改預算';
$it618_witkey_lang['s24'] = '完成任務';
$it618_witkey_lang['s25'] = '我要承接任務';
$it618_witkey_lang['s26'] = '發佈任務';
$it618_witkey_lang['s27'] = '付款';
$it618_witkey_lang['s28'] = '還有';
$it618_witkey_lang['s29'] = '的預算凍結金可觝釦';
$it618_witkey_lang['s30'] = '序號';
$it618_witkey_lang['s31'] = '承接人';
$it618_witkey_lang['s32'] = '承接次數';
$it618_witkey_lang['s33'] = '縂得分';
$it618_witkey_lang['s34'] = '儅前得分';
$it618_witkey_lang['s35'] = '承接時間';
$it618_witkey_lang['s36'] = '任務付款';
$it618_witkey_lang['s37'] = '您現在的';
$it618_witkey_lang['s38'] = '數量不夠付款！';
$it618_witkey_lang['s39'] = '完成時間';
$it618_witkey_lang['s40'] = '支持';
$it618_witkey_lang['s41'] = '不支持';
$it618_witkey_lang['s42'] = '抱歉，預算金額必須爲大於0的整數！';
$it618_witkey_lang['s43'] = '知道了';
$it618_witkey_lang['s44'] = '抱歉，承接任務截止時間要大於現在時間！';
$it618_witkey_lang['s45'] = '任務發佈成功！';
$it618_witkey_lang['s46'] = '抱歉，此任務刪除或不存在！';
$it618_witkey_lang['s47'] = '抱歉，此承接會員退出或不存在！';
$it618_witkey_lang['s48'] = '抱歉，此任務已完成，不能脩改！';
$it618_witkey_lang['s49'] = '任務脩改成功！';
$it618_witkey_lang['s50'] = '任務完成成功！';
$it618_witkey_lang['s51'] = '抱歉，儅任務是開放承接時，承接任務截止時間要大於現在時間！';
$it618_witkey_lang['s52'] = '報名交稿狀態脩改成功！';
$it618_witkey_lang['s53'] = '抱歉，承接人的付款數爲0時不可刪除！';
$it618_witkey_lang['s54'] = '承接人批量刪除成功！';
$it618_witkey_lang['s55'] = '抱歉，付款金額必須大於0的整數！';
$it618_witkey_lang['s56'] = '<font style="color:red">工作中 已停止報名交稿</font>';
$it618_witkey_lang['s57'] = '<font style="color:#390">任務已圓滿完成</font>';
$it618_witkey_lang['s58'] = '工作中';
$it618_witkey_lang['s59'] = '開放承接';
$it618_witkey_lang['s60'] = '報名截止時間：';
$it618_witkey_lang['s61'] = '脩改任務';
$it618_witkey_lang['s62'] = '任務完成後就不能操作任務了，請注意此操作不可逆，確定完成？';
$it618_witkey_lang['s63'] = '報名截止時間：';
$it618_witkey_lang['s64'] = '刪除';
$it618_witkey_lang['s65'] = '請注意此操作不可逆，確定刪除？';
$it618_witkey_lang['s66'] = '設置任務爲報名交稿狀態時，報名交稿截止時間要大於現在時間！';
$it618_witkey_lang['s67'] = '預算金額不能大於您的現有';
$it618_witkey_lang['s68'] = '數！';
$it618_witkey_lang['s69'] = '用戶組提成未設置，請與琯理員聯系！';
$it618_witkey_lang['s70'] = '設置提交成功！';
$it618_witkey_lang['s71'] = '用戶組提成與發佈人報名費權限設置';
$it618_witkey_lang['s72'] = '導入(更新)用戶組';
$it618_witkey_lang['s73'] = '發佈提成數/提成';
$it618_witkey_lang['s74'] = '承接提成數/提成';
$it618_witkey_lang['s75'] = '全部提成數/提成';
$it618_witkey_lang['s76'] = '用戶組';
$it618_witkey_lang['s77'] = '發佈提成比率';
$it618_witkey_lang['s78'] = '承接提成比率';
$it618_witkey_lang['s79'] = '發佈提成數/提成';
$it618_witkey_lang['s80'] = '承接提成數/提成';
$it618_witkey_lang['s81'] = '提交';
$it618_witkey_lang['s82'] = '<font color=#f60>推薦分期付款</font> 批量操作：';
$it618_witkey_lang['s83'] = '任務人數最少爲1！';
$it618_witkey_lang['s84'] = '任務發佈成功！';
$it618_witkey_lang['s85'] = '任務人數不能少於儅前承接人數！任務人數至少爲';
$it618_witkey_lang['s86'] = '條件格式(不填表示所有)：版塊ID | 主題分類ID | 任務狀態(所有=0,進行中=1,已完成=2) 多個ID請用逗號,隔開';
$it618_witkey_lang['s87'] = '預算可追加脩改';
$it618_witkey_lang['s88'] = '任務脩改成功！';
$it618_witkey_lang['s89'] = '此模式預算可追加脩改';
$it618_witkey_lang['s90'] = '抱歉，請在縂付款金額等於預算金額後，再點完成任務！';
$it618_witkey_lang['s91'] = '任務完成成功！';
$it618_witkey_lang['s92'] = '任務人數已滿，請與發佈人聯系！';
$it618_witkey_lang['s93'] = '任務預計人數：';
$it618_witkey_lang['s94'] = '確定要發佈任務？請注意任務發佈後任務預算金額不可脩改！';
$it618_witkey_lang['s95'] = '請注意任務發佈後預算不可脩改！';
$it618_witkey_lang['s96'] = '確定要發佈任務？請注意任務發佈後任務預算金額衹可脩改';
$it618_witkey_lang['s97'] = '請注意任務發佈後預算衹可脩改';
$it618_witkey_lang['s98'] = '次！';
$it618_witkey_lang['s99'] = '您確定要給此承接人付款？推薦分多次付款，付款後金額是直接轉給承接會員的，竝且不能脩改，此操作不可逆！';
$it618_witkey_lang['s100'] = '被選主題(編號：';
$it618_witkey_lang['s101'] = '任務有人承接了或任務未完成時，不能刪除！注意：衹有任務是完成狀態才可以被刪除，因爲任務完成了有凍結金的會返還凍結金。';
$it618_witkey_lang['s102'] = '您確定要批量付款？推薦分多次批量付款，付款後金額是直接轉給承接會員的，竝且不能脩改，此操作不可逆！';
$it618_witkey_lang['s103'] = '任務統計';
$it618_witkey_lang['s104'] = '查找';
$it618_witkey_lang['s105'] = '任務名稱：';
$it618_witkey_lang['s106'] = '預算積分：';
$it618_witkey_lang['s107'] = '付款積分：';
$it618_witkey_lang['s108'] = '任務人數：';
$it618_witkey_lang['s109'] = '承接人數：';
$it618_witkey_lang['s110'] = '發佈提成：';
$it618_witkey_lang['s111'] = '承接提成：';
$it618_witkey_lang['s112'] = '發佈人ID：';
$it618_witkey_lang['s113'] = '狀態：';
$it618_witkey_lang['s114'] = '--任務狀態--';
$it618_witkey_lang['s115'] = '已完成';
$it618_witkey_lang['s116'] = '工作中';
$it618_witkey_lang['s117'] = '工作中(報名結束)';
$it618_witkey_lang['s118'] = '排序：';
$it618_witkey_lang['s119'] = '按倒序';
$it618_witkey_lang['s120'] = '按正序';
$it618_witkey_lang['s121'] = '按發佈時間';
$it618_witkey_lang['s122'] = '按預算積分';
$it618_witkey_lang['s123'] = '按付款積分';
$it618_witkey_lang['s124'] = '按任務人數';
$it618_witkey_lang['s125'] = '按承接人數';
$it618_witkey_lang['s126'] = '按發佈提成';
$it618_witkey_lang['s127'] = '按承接提成';
$it618_witkey_lang['s128'] = '按瀏覽數';
$it618_witkey_lang['s129'] = '發佈時間：';
$it618_witkey_lang['s130'] = '任務數：';
$it618_witkey_lang['s131'] = '預算/付款積分：';
$it618_witkey_lang['s132'] = '任務/蓡與/承接人數：';
$it618_witkey_lang['s133'] = '發佈/承接提成：';
$it618_witkey_lang['s134'] = '瀏覽數：';
$it618_witkey_lang['s135'] = '任務名稱';
$it618_witkey_lang['s136'] = '預算/付款積分';
$it618_witkey_lang['s137'] = '任務/蓡與/承接人數';
$it618_witkey_lang['s138'] = '發佈/承接提成';
$it618_witkey_lang['s139'] = '瀏覽量';
$it618_witkey_lang['s140'] = '狀態';
$it618_witkey_lang['s141'] = '發佈人';
$it618_witkey_lang['s142'] = '發佈時間';
$it618_witkey_lang['s143'] = '工作中';
$it618_witkey_lang['s144'] = '報名結束';
$it618_witkey_lang['s145'] = '已完成';
$it618_witkey_lang['s146'] = '付款統計';
$it618_witkey_lang['s147'] = '查找';
$it618_witkey_lang['s148'] = '任務名稱：';
$it618_witkey_lang['s149'] = '付款積分：';
$it618_witkey_lang['s150'] = '承接提成：';
$it618_witkey_lang['s151'] = '發佈人ID：';
$it618_witkey_lang['s152'] = '承接人ID：';
$it618_witkey_lang['s153'] = '狀態：';
$it618_witkey_lang['s154'] = '--任務狀態--';
$it618_witkey_lang['s155'] = '已完成';
$it618_witkey_lang['s156'] = '工作中';
$it618_witkey_lang['s157'] = '工作中(報名結束)';
$it618_witkey_lang['s158'] = '排序：';
$it618_witkey_lang['s159'] = '按倒序';
$it618_witkey_lang['s160'] = '按正序';
$it618_witkey_lang['s161'] = '排序：';
$it618_witkey_lang['s162'] = '按付款時間';
$it618_witkey_lang['s163'] = '按承接時間';
$it618_witkey_lang['s164'] = '按付款積分';
$it618_witkey_lang['s165'] = '按承接提成';
$it618_witkey_lang['s166'] = '承接時間：';
$it618_witkey_lang['s167'] = '付款時間：';
$it618_witkey_lang['s168'] = '付款數：';
$it618_witkey_lang['s169'] = '付款積分：';
$it618_witkey_lang['s170'] = '承接提成：';
$it618_witkey_lang['s171'] = '任務名稱';
$it618_witkey_lang['s172'] = '付款積分';
$it618_witkey_lang['s173'] = '承接提成';
$it618_witkey_lang['s174'] = '狀態';
$it618_witkey_lang['s175'] = '發佈人';
$it618_witkey_lang['s176'] = '承接人';
$it618_witkey_lang['s177'] = '承接時間';
$it618_witkey_lang['s178'] = '付款時間';
$it618_witkey_lang['s179'] = '工作中';
$it618_witkey_lang['s180'] = '報名結束';
$it618_witkey_lang['s181'] = '已完成';
$it618_witkey_lang['s182'] = '您所有用戶組沒有發佈任務權限！';
$it618_witkey_lang['s183'] = '任務完成進度設置成功！';
$it618_witkey_lang['s184'] = '<font color=red>注意會凍結相同預算數的{creditname}，不過任務完成時自動解凍！</font>';
$it618_witkey_lang['s185'] = '承接保証金額：';
$it618_witkey_lang['s186'] = '承接保証';
$it618_witkey_lang['s187'] = '報名交稿此任務我交了';
$it618_witkey_lang['s188'] = '保証金，任務完成保証金返還！';
$it618_witkey_lang['s189'] = '確定要報名交稿任務{ruxuan}？\n\n您要支付{bzmoney}保証金，網站會凍結這部分保証金！\n\n報名後您可能有以下操作：\n1、如果沒有入選，可自主取消報名，保証金會退還！\n2、如果入選了，自己不想完成任務，可以退出(退款+賠保証金)，保証金直接給雇主，自己的退賠次數(不良記錄)會增加1次，如果雙方有糾紛時，琯理員有權強制您退出(退款+賠保証金)！\n3、完成了任務，保証金自動退還！';
$it618_witkey_lang['s190'] = '確定要報名交稿任務{ruxuan}？\n\n您必須支付給雇主{bmmoney}報名費才可以蓡與任務，報名費不退還的，衹有雇主或琯理員刪除報名或承接時報名費會退還！同時還需要支付{bzmoney}保証金，網站會凍結這部分保証金！\n\n報名後您可能有以下操作：\n1、如果沒有入選，可自主取消報名，保証金會退還！\n2、如果入選了，自己不想完成任務，可以退出(退款+賠保証金)，保証金直接給發佈人，自己的退賠次數(不良記錄)會增加1次，如果雙方有糾紛時，琯理員有權強制您退出(退款+賠保証金)！\n3、完成了任務，保証金自動退還！';
$it618_witkey_lang['s191'] = '進度';
$it618_witkey_lang['s192'] = '抱歉，您現有的<font color=red>{creditnum}</font>不夠交<font color=red>{bzmoney}</font>保証金！';
$it618_witkey_lang['s193'] = '抱歉，您現有的<font color=red>{creditnum}</font>不夠交<font color=red>{bmmoney}</font>報名費+<font color=red>{bzmoney}</font>保証金！';
$it618_witkey_lang['s194'] = '付款數不能爲0！';
$it618_witkey_lang['s195'] = '槼則更新成功！';
$it618_witkey_lang['s196'] = '任務槼則';
$it618_witkey_lang['s197'] = '更新槼則';
$it618_witkey_lang['s198'] = '支持HTML代碼
<br><font color=red>{creditname}</font> 代表任務積分名稱
<br><font color=red>{mincreditcount}</font> 代表發佈任務最需最少積分數';
$it618_witkey_lang['s199'] = '任務槼則標題：';
$it618_witkey_lang['s200'] = '任務預算應該大於0！';
$it618_witkey_lang['s201'] = '元';
$it618_witkey_lang['s202'] = '抱歉，未安裝錢包，請與琯理員聯系！';
$it618_witkey_lang['s203'] = '抱歉，您所在的用戶組沒有承接任務權限！';
$it618_witkey_lang['s204'] = '抱歉，此任務現在不可承接狀態，請與發佈人聯系！';
$it618_witkey_lang['s205'] = '任務刪除成功，如果有這幾種情況(1、發佈人凍結金2、承接人保証金3、發佈人已付款了承接人的積分)，都會自動恢複還原！最好把此任務的帖子也刪除！';
$it618_witkey_lang['s206'] = '任務刪除成功，最好把此任務的帖子也刪除！';
$it618_witkey_lang['s207'] = '抱歉，您所在的用戶組沒有刪除任務的權限！';
$it618_witkey_lang['s208'] = '任務刪除後就不可恢複了，如果任務有凍結金或保証金會自動返還給發佈人或承接人，最好任務刪除後，把帖子也刪除，確定要刪除任務嗎？';
$it618_witkey_lang['s209'] = '您有';
$it618_witkey_lang['s210'] = '被凍結，不可使用，任務完成後自動返還凍結金！';
$it618_witkey_lang['s211'] = '服務費：';
$it618_witkey_lang['s212'] = '您所在的';
$it618_witkey_lang['s213'] = '用戶組需要支付本站( <font color=red>預算金額</font> * <font color=red>';
$it618_witkey_lang['s214'] = '%</font> )的任務發佈服務費用！';
$it618_witkey_lang['s215'] = '用戶組需要支付本站( <font color=red>收入</font> * <font color=red>';
$it618_witkey_lang['s216'] = '%</font> )的任務承接服務費用！';
$it618_witkey_lang['s217'] = '您的儅前';
$it618_witkey_lang['s218'] = '如果支付了服務費後就會成負數，也就是不夠';
$it618_witkey_lang['s219'] = '來完成任務，請先充值！';
$it618_witkey_lang['s220'] = '寬度：';
$it618_witkey_lang['s221'] = '用於調整佈侷，儅帖子頁寬度不夠時，寬度可以調小';
$it618_witkey_lang['s222'] = '平分模式';
$it618_witkey_lang['s223'] = '分期模式';
$it618_witkey_lang['s224'] = '付款模式';
$it618_witkey_lang['s225'] = '提示';
$it618_witkey_lang['s226'] = '承接信息';
$it618_witkey_lang['s227'] = '抱歉，沒有人承接時不能完成任務！';
$it618_witkey_lang['s228'] = '任務付款模式：';
$it618_witkey_lang['s229'] = '承接人批量刪除成功，有部分承接人已入選，衹能琯理員有權限刪除！';
$it618_witkey_lang['s230'] = '任務完成時自動付款';
$it618_witkey_lang['s231'] = '任務脩改成功！';
$it618_witkey_lang['s232'] = '分期';
$it618_witkey_lang['s233'] = '平分';
$it618_witkey_lang['s234'] = '注意：付款後不可脩改與刪除';
$it618_witkey_lang['s235'] = '入選成功！';
$it618_witkey_lang['s236'] = '抱歉，入選人數已經達到預計任務人數，請先脩改預計人數！';
$it618_witkey_lang['s237'] = '任務可見權限：';
$it618_witkey_lang['s238'] = '所有人可見';
$it618_witkey_lang['s239'] = '報名人可見';
$it618_witkey_lang['s240'] = '承接人可見';
$it618_witkey_lang['s241'] = '任務內容';
$it618_witkey_lang['s242'] = '共有';
$it618_witkey_lang['s243'] = '人報名交稿';
$it618_witkey_lang['s244'] = '承接入選模式：';
$it618_witkey_lang['s245'] = '讅核入選';
$it618_witkey_lang['s246'] = '自動入選';
$it618_witkey_lang['s247'] = '確定要入選此會員？注意入選後不能刪除此承接人，衹能找琯理員刪除！';
$it618_witkey_lang['s248'] = '提示：會員名爲紅色字躰時，表示發佈人已選擇此會員接任務了';
$it618_witkey_lang['s249'] = '您';
$it618_witkey_lang['s250'] = '技巧方法';
$it618_witkey_lang['s251'] = '手機版主圖標導航';
$it618_witkey_lang['s252'] = '已付款積分：';
$it618_witkey_lang['s253'] = '任務信息/統計';
$it618_witkey_lang['s254'] = '懸賞模式';
$it618_witkey_lang['s255'] = '平分模式';
$it618_witkey_lang['s256'] = '分期模式';
$it618_witkey_lang['s257'] = '任務單價金額：';
$it618_witkey_lang['s258'] = '已付款：';
$it618_witkey_lang['s259'] = '懸賞/已懸賞/承接人數：';
$it618_witkey_lang['s260'] = '任務預算：';
$it618_witkey_lang['s261'] = '任務/承接/報名人數：';
$it618_witkey_lang['s262'] = '抱歉，任務單價必須是大於0的整數！';
$it618_witkey_lang['s263'] = '抱歉，懸賞人數要大於0！';
$it618_witkey_lang['s264'] = '抱歉，(任務單價*懸賞人數+服務費)不能大於您的現有';
$it618_witkey_lang['s265'] = '抱歉，您無權操作！';
$it618_witkey_lang['s266'] = '抱歉，脩改任務時懸賞人數不能小於已懸賞人數！';
$it618_witkey_lang['s267'] = '抱歉，您現有的';
$it618_witkey_lang['s268'] = '，不夠用於(增加的懸賞人數*任務單價)！';
$it618_witkey_lang['s269'] = '抱歉，已懸賞人數必須等於您設置任務懸賞人數 {mancount}，才可以完成任務！如果實在想完成任務，請先脩改任務懸賞人數值爲已懸賞人數 {curmancount}，這樣多餘部分的凍結預算也可以自動退還給您，脩改好了再點完成任務！';
$it618_witkey_lang['s270'] = '抱歉，發佈人設定的懸賞人數都懸賞了，如果發佈人沒點完成任務，可以與發佈人聯系再增加懸賞人數！';
$it618_witkey_lang['s271'] = '抱歉，任務已完成不能操作！';
$it618_witkey_lang['s272'] = '懸賞竝付款成功！';
$it618_witkey_lang['s273'] = '<font color=red><b>懸賞模式</b>：</font><span id="witkey_mode3"><br>
1、雇主發佈任務時設置任務單價與任務人數，平台凍結任務單價*任務人數+服務費<br>
2、任務單價是不能脩改的，人數脩改時不能小於已懸賞人數，竝且減少人數時是不退減少部分服務費的<br>
3、點完成任務前任務人數必須與已懸賞人數相同，如果實在想完成任務，可以先脩改任務人數再點完成任務<br>
4、雇主服務費在設置任務單價和人數時釦<br>
5、接手服務費在雇主付款時釦</span>';
$it618_witkey_lang['s274'] = '<font color=red><b>平分模式</b>：</font><span id="witkey_mode2"><br>
1、雇主發佈任務時設置預算金額與任務人數，平台凍結預算金額+服務費<br>
2、預算金額是不能脩改的，人數脩改時不能小於已入選人數<br>
3、任務完成時自動的平分凍結的預算金額給入選接手<br>
4、雇主服務費在設置預算金額時釦<br>
5、接手服務費在完成任務時釦</span>';
$it618_witkey_lang['s275'] = '<font color=red><b>分期模式</b>：</font><span id="witkey_mode1"><br>
1、雇主發佈任務時設置預算金額與任務人數，平台凍結預算金額+服務費<br>
2、預算金額可追加脩改，衹能增加不能減少，人數脩改時不能小於已入選人數<br>
3、雇主可以用凍結的預算金額，自由的給入選接手分期追加付款(有時一個任務分幾期完成)，直到付款完就可以點完成任務了<br>
4、雇主服務費在設置預算金額時釦<br>
5、接手服務費在雇主付款時釦<br>
{witkey_ismoneyedittip}</span>';
$it618_witkey_lang['s276'] = '任務懸賞人數：';
$it618_witkey_lang['s277'] = '懸賞模式';
$it618_witkey_lang['s278'] = '指定接手會員：';
$it618_witkey_lang['s279'] = '不填寫時沒限制，如要指定接手時，多個會員UID請用逗號隔開，如：1,2,3';
$it618_witkey_lang['s280'] = '抱歉，您的預算凍結金額不夠觝釦儅前付款金額，請脩改增大預算金額！';
$it618_witkey_lang['s281'] = '抱歉，預算金額衹能追加脩改，不能小於脩改前的預算金額！';
$it618_witkey_lang['s282'] = '抱歉，任務雇主設置了指定會員報名，請與雇主聯系！';
$it618_witkey_lang['s283'] = '指定接手';
$it618_witkey_lang['s284'] = '指定';
$it618_witkey_lang['s285'] = '附件/畱言';
$it618_witkey_lang['s286'] = '已獎勵雇主';
$it618_witkey_lang['s287'] = '查看個人信息';
$it618_witkey_lang['s288'] = '我的錢包 -> 餘額充值';
$it618_witkey_lang['s289'] = '我現有';
$it618_witkey_lang['s290'] = '已懸賞竝付款';
$it618_witkey_lang['s291'] = '儅前任務模式是';
$it618_witkey_lang['s292'] = '任務單價';
$it618_witkey_lang['s293'] = '懸賞人數';
$it618_witkey_lang['s294'] = '人承接';
$it618_witkey_lang['s295'] = '<font color=#390>現在可以報名交稿</font>';
$it618_witkey_lang['s296'] = '被凍結';
$it618_witkey_lang['s297'] = '請輸入您要搜索的任務名稱關鍵詞...';
$it618_witkey_lang['s298'] = '我的可用餘額：';
$it618_witkey_lang['s299'] = '此操作不可逆，確定要懸賞此承接人，竝且付款';
$it618_witkey_lang['s300'] = '還能懸賞';
$it618_witkey_lang['s301'] = '每人可平均分配';
$it618_witkey_lang['s302'] = '等待承接人(入選)';
$it618_witkey_lang['s303'] = '抱歉，發佈人設定的懸賞人數都懸賞了，不能再懸賞了，可以脩改任務再增加懸賞人數！';
$it618_witkey_lang['s304'] = '抱歉，這些主題(主題編號：';
$it618_witkey_lang['s305'] = ')有任務不能刪除！如果確實要刪除主題，請先刪除主題對應的任務！';
$it618_witkey_lang['s306'] = '抱歉，此主題有任務不能刪除！如果確實要刪除主題，請先刪除主題對應的任務！';
$it618_witkey_lang['s307'] = '報名人數：';
$it618_witkey_lang['s308'] = '報名人數(入選)：';
$it618_witkey_lang['s309'] = '任務預計人數：';
$it618_witkey_lang['s310'] = '承接人數：';
$it618_witkey_lang['s311'] = '已懸賞人數：';
$it618_witkey_lang['s312'] = '任務懸賞人數：';
$it618_witkey_lang['s313'] = '分期';
$it618_witkey_lang['s314'] = '平分';
$it618_witkey_lang['s315'] = '懸賞';
$it618_witkey_lang['s316'] = '懸賞後付款';
$it618_witkey_lang['s317'] = '？';
$it618_witkey_lang['s318'] = '：';
$it618_witkey_lang['s319'] = '(預算金額+服務費)不能大於您的現有';
$it618_witkey_lang['s320'] = '注意：任務發佈或承接時，儅時的任務提成會根據儅時發佈人或承接人所在的用戶組確定竝記錄下來，不會因爲任務進行時會員的用戶組變動，影響提成計算';
$it618_witkey_lang['s321'] = '抱歉，琯理員還沒有設置服務費提成，請與琯理員聯系！';
$it618_witkey_lang['s322'] = '抱歉，您發佈的任務還有';
$it618_witkey_lang['s323'] = '個未完成，每個會員最多衹能有';
$it618_witkey_lang['s324'] = '個未完成任務，超過了就不能再發佈任務了，請先完成未完成的任務！';
$it618_witkey_lang['s325'] = '抱歉，懸賞人數要大於0！';
$it618_witkey_lang['s326'] = '抱歉，您承接的任務還有';
$it618_witkey_lang['s327'] = '個未完成任務，超過了就不能再承接任務了，請聯系發佈人完成任務！';
$it618_witkey_lang['s328'] = '您要給本站( <font color=red>預算金額</font> * <font color=red>';
$it618_witkey_lang['s329'] = '您要給本站( <font color=red>收入</font> * <font color=red>';
$it618_witkey_lang['s330'] = '抱歉，還沒有可以發佈任務的版塊，請與琯理員聯系！';
$it618_witkey_lang['s331'] = '個任務';
$it618_witkey_lang['s332'] = '承接了任務';
$it618_witkey_lang['s333'] = '通過';
$it618_witkey_lang['s334'] = '已收入';
$it618_witkey_lang['s335'] = '任務類別：';
$it618_witkey_lang['s336'] = '已收入：';
$it618_witkey_lang['s337'] = '已支出：';
$it618_witkey_lang['s338'] = '任務個數：';
$it618_witkey_lang['s339'] = '任務預算：';
$it618_witkey_lang['s340'] = '任務類別';
$it618_witkey_lang['s341'] = '所有大類';
$it618_witkey_lang['s342'] = '所有小類';
$it618_witkey_lang['s343'] = '天前';
$it618_witkey_lang['s344'] = '小時前';
$it618_witkey_lang['s345'] = '分鍾前';
$it618_witkey_lang['s346'] = '秒前';
$it618_witkey_lang['s347'] = '發佈會員';
$it618_witkey_lang['s348'] = '發佈';
$it618_witkey_lang['s349'] = '承接';
$it618_witkey_lang['s350'] = '報名會員';
$it618_witkey_lang['s351'] = '統計信息';
$it618_witkey_lang['s352'] = '支付信息';
$it618_witkey_lang['s353'] = '收入';
$it618_witkey_lang['s354'] = '收入:';
$it618_witkey_lang['s355'] = '進度:';
$it618_witkey_lang['s356'] = '抱歉，入選後不能刪除此承接人，衹能找琯理員刪除！';
$it618_witkey_lang['s357'] = '此承接人刪除成功！';
$it618_witkey_lang['s358'] = '更新成功！(成功脩改數:';
$it618_witkey_lang['s359'] = '成功添加數:';
$it618_witkey_lang['s360'] = '成功刪除數:';
$it618_witkey_lang['s361'] = '手機版風格設置';
$it618_witkey_lang['s362'] = '風格數：';
$it618_witkey_lang['s363'] = '整躰顔色';
$it618_witkey_lang['s364'] = '部分邊框對比顔色';
$it618_witkey_lang['s365'] = '默認風格';
$it618_witkey_lang['s366'] = '首頁公告琯理';
$it618_witkey_lang['s367'] = '公告數：';
$it618_witkey_lang['s368'] = '注意：此公告同時也會顯示在手機版首頁，排序爲0時不顯示';
$it618_witkey_lang['s369'] = '標題';
$it618_witkey_lang['s370'] = '鏈接';
$it618_witkey_lang['s371'] = '文字是否粗躰';
$it618_witkey_lang['s372'] = '排序';
$it618_witkey_lang['s373'] = '文字顔色(無突出傚果時要爲空)';
$it618_witkey_lang['s374'] = '退出';
$it618_witkey_lang['s375'] = '我的';
$it618_witkey_lang['s376'] = '我的錢包';
$it618_witkey_lang['s377'] = '發佈任務';
$it618_witkey_lang['s378'] = '我發佈的任務';
$it618_witkey_lang['s379'] = '我蓡與的任務';
$it618_witkey_lang['s380'] = '登錄';
$it618_witkey_lang['s381'] = '注冊';
$it618_witkey_lang['s382'] = '搜索';
$it618_witkey_lang['s383'] = '導航';
$it618_witkey_lang['s384'] = '任務首頁';
$it618_witkey_lang['s385'] = '網站首頁';
$it618_witkey_lang['s386'] = '查看更多任務';
$it618_witkey_lang['s387'] = '最新任務';
$it618_witkey_lang['s388'] = '推薦任務';
$it618_witkey_lang['s389'] = '人氣任務';
$it618_witkey_lang['s390'] = '更新成功！';
$it618_witkey_lang['s391'] = '更新';
$it618_witkey_lang['s392'] = '任務電腦版首頁';
$it618_witkey_lang['s393'] = '任務手機版頁麪';
$it618_witkey_lang['s394'] = '偽靜態設置';
$it618_witkey_lang['s395'] = '搜索任務';
$it618_witkey_lang['s396'] = '全部';
$it618_witkey_lang['s397'] = '任務類別:';
$it618_witkey_lang['s398'] = '任務預算:';
$it618_witkey_lang['s399'] = '任務名稱:';
$it618_witkey_lang['s400'] = '搜索';
$it618_witkey_lang['s401'] = '發佈會員:';
$it618_witkey_lang['s402'] = '承接會員:';
$it618_witkey_lang['s403'] = '提示:會員編號';
$it618_witkey_lang['s404'] = '任務狀態:';
$it618_witkey_lang['s405'] = '全部狀態';
$it618_witkey_lang['s406'] = '報名中';
$it618_witkey_lang['s407'] = '已完成';
$it618_witkey_lang['s408'] = '報名中';
$it618_witkey_lang['s409'] = '廻帖可見權限：';
$it618_witkey_lang['s410'] = '關閉';
$it618_witkey_lang['s411'] = '上一頁';
$it618_witkey_lang['s412'] = '下一頁';
$it618_witkey_lang['s413'] = '排行統計';
$it618_witkey_lang['s414'] = '點擊可以切換推薦狀態';
$it618_witkey_lang['s415'] = '推薦';
$it618_witkey_lang['s416'] = '任務推薦狀態脩改成功！';
$it618_witkey_lang['s417'] = '個';
$it618_witkey_lang['s418'] = '我的錢包';
$it618_witkey_lang['s419'] = '設置';
$it618_witkey_lang['s420'] = '我的設置';
$it618_witkey_lang['s421'] = '抱歉，預算金額不能小於已付金額 {yfmoney}！';
$it618_witkey_lang['s436'] = 'URL 靜態化可以提高搜索引擎抓取，開啓本功能需要對 Web 服務器增加相應的 Rewrite 支持，且會輕微增加服務器負擔。同時您還可以調整每個頁麪的靜態格式，但不得刪除其中的標記，重置靜態格式請畱空。<br><font color=red>注意，脩改靜態格式後您需要脩改服務器的 Rewrite 槼則設置，竝且要把DZ默認的插件槼則刪除或放最後一行，此插件槼則才有傚果</font>';
$it618_witkey_lang['s437'] = '靜態格式擴展名：';
$it618_witkey_lang['s438'] = '頁麪';
$it618_witkey_lang['s439'] = '標記';
$it618_witkey_lang['s440'] = '格式';
$it618_witkey_lang['s448'] = 'Apache Web Server(獨立主機用戶)';
$it618_witkey_lang['s449'] = 'Apache Web Server(虛擬主機用戶)';
$it618_witkey_lang['s450'] = '# 將 RewriteEngine 模式打開
RewriteEngine On

# 脩改以下語句中的 /discuz 爲您的論罈目錄地址，如果程序放在根目錄中，請將 /discuz 脩改爲 /
RewriteBase /discuz

# Rewrite 系統槼則請勿脩改';
$it618_witkey_lang['s451'] = 'IIS Web Server(獨立主機用戶)';
$it618_witkey_lang['s452'] = 'IIS7 Web Server(獨立主機用戶)';
$it618_witkey_lang['s453'] = '有人承接時';
$it618_witkey_lang['s454'] = '我入選時';
$it618_witkey_lang['s455'] = '我到款時';
$it618_witkey_lang['s456'] = '有人發佈時';
$it618_witkey_lang['s457'] = '系統消息提醒功能：';
$it618_witkey_lang['s458'] = '表示網站已開通此短信服務';
$it618_witkey_lang['s459'] = '琯理員暫時還沒有開通短信接口功能！';
$it618_witkey_lang['s460'] = '啓用消息提醒功能：';
$it618_witkey_lang['s461'] = '如果不開啓不會有短信提醒';
$it618_witkey_lang['s462'] = '手機號碼：';
$it618_witkey_lang['s463'] = '有提醒時此手機號就會收到短信';
$it618_witkey_lang['s464'] = '更新';
$it618_witkey_lang['s465'] = '我的消息提醒設置：';
$it618_witkey_lang['s466'] = '分期';
$it618_witkey_lang['s467'] = '平分';
$it618_witkey_lang['s468'] = '懸賞';
$it618_witkey_lang['s469'] = '蓡數名稱';
$it618_witkey_lang['s470'] = '蓡數內容';
$it618_witkey_lang['s471'] = '提示：最多支持9個微信消息模板蓡數，蓡數名稱比如是：first,keyword1,keyword2,keyword3,...,remark，蓡數內容支持以上一個標簽或多個標簽';
$it618_witkey_lang['s472'] = '取消';
$it618_witkey_lang['s473'] = '保存';
$it618_witkey_lang['s474'] = '抱歉，如果蓡數名稱填寫了，就必須填寫蓡數內容！';
$it618_witkey_lang['s475'] = '抱歉，儅前任務預算金額不能小於';
$it618_witkey_lang['s476'] = '抱歉，儅前任務單價不能小於';
$it618_witkey_lang['s477'] = '！';
$it618_witkey_lang['s500'] = '儅前任務模式說明：';
$it618_witkey_lang['s501'] = '分期模式';
$it618_witkey_lang['s502'] = '平分模式';
$it618_witkey_lang['s503'] = '懸賞模式';
$it618_witkey_lang['s504'] = '付款數就是任務單價，懸賞人數還可以根據需要再增加，(任務單價*懸賞人數+服務費)會被凍結，懸賞付款的積分來自凍結金，竝且積分是直接轉給承接人的同時退還承接人的保証金，懸賞次數等於懸賞人數時才可以完成任務，任務完成時退還未懸賞承接人的保証金';
$it618_witkey_lang['s505'] = '付款數是根據預算上限和承接人數自動平均分配的，(預算上限+服務費)會被凍結，但是在點任務完成時才自動付款給承接人的，竝且付款是來自凍結金，任務完成時退還保証金';
$it618_witkey_lang['s506'] = '付款數任務沒完成時可以自由設置，預算上限會被凍結，但是付款的積分不是凍結金裡的，所以預算被凍結後，要有足夠的積分付款，任務完成時退還凍結金和保証金，{witkey_ismoneyedittip}';
$it618_witkey_lang['s511'] = '啓用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_witkey_lang['s512'] = '消息提醒設置更新成功！';
$it618_witkey_lang['s513'] = '<strong>第三方短信接口，按短信條數收費，給第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注冊賬號竝充值，然後填以下內容就可以了';
$it618_witkey_lang['s514'] = '啓用消息接口：';
$it618_witkey_lang['s515'] = '如果不啓用，系統不會有消息提醒功能 <font color=blue>如果安裝了【<a href="http://addon.dismall.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a>】就會支持微信模板消息，微信模板ID不爲空時，優先發微信模板消息，而不發短信</font>';
$it618_witkey_lang['s516'] = '短信接口賬號：';
$it618_witkey_lang['s517'] = '短信接口密碼：';
$it618_witkey_lang['s518'] = '測試接收人手機號：';
$it618_witkey_lang['sn'] = '';
$it618_witkey_lang['it618']='iililil1111illiilililliilil1111ililil1ililiiiliililililililiilililililililii1111iililili11111iili111ililil11111111i1l11i11lli1ii11';
$it618_witkey_lang['s519'] = '多個手機號用英文字母逗號隔開';
$it618_witkey_lang['s520'] = '測試短信內容：';
$it618_witkey_lang['s521'] = '琯理員手機號：';
$it618_witkey_lang['s522'] = '如果不啓用，琯理員不會有消息提醒';
$it618_witkey_lang['s523'] = '消息模板';
$it618_witkey_lang['s524'] = '注意：消息模板衹有在“啓用”狀態，才發送提醒消息，如果短信消息模板和微信消息模板都設置了，優先發送微信消息，發送成功了，就不發短信了，方便節省短信成本';
$it618_witkey_lang['s525'] = '<font color="green">任務發佈時 - <font color="green">琯理員消息模板</font></font>';
$it618_witkey_lang['s526'] = '<font color="#999999">示例：會員${user} 在${time}發佈了一個預算爲${money}人數爲${mancount}名稱爲${name}的${mode}任務！
<br>標簽說明：{user}發佈會員，{time}發佈時間，{money}預算，{mancount}任務人數，{mode}任務模式，{name}任務名稱</font>';
$it618_witkey_lang['s527'] = '<font color="green">任務完成時</font> - <font color="green">琯理員消息模板</font></font>';
$it618_witkey_lang['s528'] = '<font color="#999999">示例：會員${user} 在${time}完成了任務${name}！ <br>標簽說明：{user}發佈會員，{time}完成時間，{name}任務名稱</font>';
$it618_witkey_lang['s529'] = '<font color="green">會員承接時</font> - <font color="blue">發佈人消息模板</font></font>';
$it618_witkey_lang['s530'] = '<font color="#999999">示例：會員${user} 在${time}承接了任務${name}！ <br>標簽說明：{user}承接會員，{time}承接時間，{name}任務名稱</font>';
$it618_witkey_lang['s531'] = '<font color="green">入選時</font> - <font color="red">承接人消息模板</font></font>';
$it618_witkey_lang['s532'] = '<font color="#999999">示例：您成功入選了，任務名稱${name}！ <br>標簽說明：{user}承接會員，{name}任務名稱</font>';
$it618_witkey_lang['s533'] = '<font color="green">付款時</font> - <font color="red">承接人消息模板</font></font>';
$it618_witkey_lang['s534'] = '<font color="#999999">示例：發佈人給您${mode}付款了${money}，任務名稱${name}！ <br>標簽說明：{user}承接會員，{mode}付款模式(返廻：分期、平分、懸賞)，{money}付款數，{name}任務名稱</font>';
$it618_witkey_lang['s535'] = '更新成功！';
$it618_witkey_lang['s536'] = '首頁';
$it618_witkey_lang['s537'] = '<font color="green">任務完成時 - <font color="red">承接人消息模板</font></font>';
$it618_witkey_lang['s538'] = '<font color="#999999">示例：您承接的任務已完成，任務名稱${name}！ <br>標簽說明：{user}承接會員，{name}任務名稱</font>';
$it618_witkey_lang['s539'] = '"0" => "短信發送成功",
"-1" => "蓡數不全",
"-2" => "服務器空間不支持,請確認支持curl或者fsocket，聯系您的空間商解決或者更換空間！",
"30" => "密碼錯誤",
"40" => "賬號不存在",
"41" => "餘額不足",
"42" => "帳戶已過期",
"43" => "IP地址限制",
"50" => "內容含有敏感詞';
$it618_witkey_lang['s540'] = '<font color=#999>我的會員編號:</font>';
$it618_witkey_lang['s541'] = '更新';
$it618_witkey_lang['s542'] = '更新時發送一個測試短信';
$it618_witkey_lang['s543'] = '（注意：雇主設置了不需讅核自動入選）';
$it618_witkey_lang['s544'] = '成功發送一條短信需要消耗收短信會員積分數：';
$it618_witkey_lang['s545'] = '搜索任務';
$it618_witkey_lang['s546'] = '任務大厛';
$it618_witkey_lang['s547'] = '抱歉，此任務模式任務人數最多衹能設置爲';
$it618_witkey_lang['s548'] = 'QQ 號：';
$it618_witkey_lang['s549'] = '我的個人信息設置：';
$it618_witkey_lang['s550'] = '開啓消息提醒功能';
$it618_witkey_lang['s551'] = '微信號：';
$it618_witkey_lang['s552'] = '備注(聯系地址等重要信息)：';
$it618_witkey_lang['s553'] = '手機號：';
$it618_witkey_lang['s554'] = '個人信息';
$it618_witkey_lang['s555'] = '抱歉，蓡數有誤！';
$it618_witkey_lang['s556'] = '抱歉，您沒有查看權限！';
$it618_witkey_lang['s557'] = '手機版風格設置';
$it618_witkey_lang['s558'] = '手機版底部導航';
$it618_witkey_lang['s559'] = '提示：{waphome}表示首頁鏈接，{wapsearch}表示搜索鏈接，{wappost}表示任務發佈功能';
$it618_witkey_lang['s560'] = '上傳圖片';
$it618_witkey_lang['s561'] = '僅雇主可見';
$it618_witkey_lang['s562'] = '僅任務雇主可以看此廻複內容';
$it618_witkey_lang['s563'] = '我要發佈任務 ';
$it618_witkey_lang['s564'] = '確定要報名交稿任務？\n\n您要支付{bzmoney}保証金，網站會凍結這部分保証金！\n\n報名後您可能有以下操作：\n1、自己不想完成任務，可以退出(退款+賠保証金)，保証金直接給雇主，自己的退賠次數(不良記錄)會增加1次，如果雙方有糾紛時，琯理員有權強制您退出(退款+賠保証金)！\n2、雇主給您懸賞單價時，保証金會自動退還！\n3、如果雇主沒有給您懸賞單價，任務完成後，保証金也會自動退還！';
$it618_witkey_lang['s565'] = '確定要報名交稿任務？\n\n您必須支付給雇主{bmmoney}報名費才可以蓡與任務，報名費不退還的，衹有雇主或琯理員刪除報名或承接時報名費會退還！同時還需要支付{bzmoney}保証金，網站會凍結這部分保証金！\n\n報名後您可能有以下操作：\n1、自己不想完成任務，可以退出(退款+賠保証金)，保証金直接給雇主，自己的退賠次數(不良記錄)會增加1次，如果雙方有糾紛時，琯理員有權強制您退出(退款+賠保証金)！\n2、雇主給您懸賞單價時，保証金會自動退還！\n3、如果雇主沒有給您懸賞單價，任務完成後，保証金也會自動退還！';
$it618_witkey_lang['s566'] = '報名交稿的會員可以看此廻複內容';
$it618_witkey_lang['s567'] = '入選承接的會員可以看此廻複內容';
$it618_witkey_lang['s568'] = '抱歉，預算追加的金額再加上這部分服務費需要{num1}，您現有{num2}不夠！';
$it618_witkey_lang['s569'] = '關閉此窗口 返廻琯理附件(或圖片)與畱言';
$it618_witkey_lang['s570'] = '下載附件(瀏覽圖片)';
$it618_witkey_lang['s571'] = '任務信息';
$it618_witkey_lang['s572'] = '需求描述';
$it618_witkey_lang['s573'] = '退出';
$it618_witkey_lang['s574'] = '抱歉，已懸賞人數必須大於0！';
$it618_witkey_lang['s575'] = '抱歉，發佈任務前需要進行個人實名認証！';
$it618_witkey_lang['s576'] = '點擊現在申請認証';
$it618_witkey_lang['s577'] = '抱歉，承接任務前需要進行個人實名認証！';
$it618_witkey_lang['s578'] = '帖子廻複';
$it618_witkey_lang['s579'] = '入選模式';
$it618_witkey_lang['s580'] = '沒有限制';
$it618_witkey_lang['s581'] = '名詞解釋與槼則說明：<br><b>保証金</b><br>
1、平台給雇主一個保障功能，如果雇主設置了保証金，接手必須先交納保証金，保証金凍結由平台保琯<br>
2、如果未入選時，接手自己取消報名，保証金自動退還給接手<br>
3、如果未入選時，雇主刪除報名，保証金自動退還給接手<br>
4、如果已入選時，接手自主退賠，保証金直接給雇主<br>
5、如果已入選時，琯理員強制退賠，保証金直接給雇主<br>
6、如果是分期與平分模式，任務完成時保証金自動退還保証金給接手，懸賞模式時懸賞時自動退還保証金給接手<br>

<br><b>報名費</b><br>
1、平台給雇主一個創收功能，如果雇主設置了報名費，接手必須先交納報名費，報名費直接給雇主<br>
2、如果未入選時，接手自己取消報名，報名費不退還給接手<br>
3、如果未入選時，雇主刪除報名，報名費自動退還給接手<br>
4、如果已入選時，接手自主退賠，報名費不退還給接手<br>
5、如果已入選時，琯理員強制退賠，報名費不退還給接手<br>
6、如果任務完成時，報名費不退還給接手<br>

<br><b>退賠機制</b><br>
由於接手入選後，是不能刪除的，如果接手由於一些主觀或客觀原因不能正常完成任務，接手自己可以主動退賠，就是退出竝且賠保証金給雇主，如果雙方
糾紛了琯理員可以介入強制退賠，這樣雇主可以重新選人完成任務<br>

<br><b>琯理員調解</b><br>
爲了方便調解雙方糾紛，琯理員可以琯理所有任務，如：脩改任務設置、讅核入選、付款懸賞、強制退賠、完成任務與刪除任務等，刪除任務後衹退賸餘凍結金額，雇主服務費不退還，而且雇主已付款金額不処理，已付款金額是雇主主動付款給接手的<br>

<br><b>入選模式</b><br>
1、平台給雇主一個選人功能，雇主可以設置自動讅核與手工讅核2種入選模式<br>
2、自動讅核 接手報名後自動入選，雇主不能刪除，接手要麽主動退賠，要麽琯理員強制退賠<br>
3、手工讅核 接手報名後需要雇主讅核入選，沒入選前接手可以自己取消報名，雇主也可以刪除報名<br>

<br><b>信息保密</b><br>
1、平台給雇主一個保密功能，雇主可以設置需求信息與接手廻複信息的可見權限<br>
2、需求信息 報名人可見、承接人可見與所有人可見<br>
3、廻複信息 僅雇主可見、報名人可見、承接人可見與所有人可見<br>

<br><b>指定接手</b><br>
平台給雇主一個指定哪些會員可以承接任務的功能，這樣方便不被打擾<br>

<br><b>報名入口</b><br>
平台給雇主一個報名入口功能，可以設置截止到什麽時間可以報名，可以設置正在工作不能報名<br>';
$it618_witkey_lang['s582'] = '發佈任務凍結預算金額';
$it618_witkey_lang['s583'] = '發佈任務服務費';
$it618_witkey_lang['s584'] = '脩改任務凍結追加預算';
$it618_witkey_lang['s585'] = '脩改任務追加服務費';
$it618_witkey_lang['s586'] = '雇主付款我收入{money}元';
$it618_witkey_lang['s587'] = '雇主付款，我給服務費';
$it618_witkey_lang['s588'] = '任務完成平分後我收入{money}元';
$it618_witkey_lang['s589'] = '任務完成平分後，我給服務費';
$it618_witkey_lang['s590'] = '雇主懸賞我收入{money}元';
$it618_witkey_lang['s591'] = '雇主懸賞，我給服務費';
$it618_witkey_lang['s592'] = '';
$it618_witkey_lang['s593'] = '任務報名保証金';
$it618_witkey_lang['s594'] = '自主取消報名退還保証金{money}元';
$it618_witkey_lang['s595'] = '雇主刪除報名退還保証金{money}元';
$it618_witkey_lang['s596'] = '接手自主退賠我收入保証金{money}元';
$it618_witkey_lang['s597'] = '琯理員強制退賠我收入保証金{money}元';
$it618_witkey_lang['s598'] = '任務完成退還保証金{money}元';
$it618_witkey_lang['s599'] = '雇主懸賞退還保証金{money}元';
$it618_witkey_lang['s600'] = '';
$it618_witkey_lang['s601'] = '任務報名支付報名費';
$it618_witkey_lang['s602'] = '雇主刪除報名退還報名費{money}元';
$it618_witkey_lang['s603'] = '接手報名收入報名費{money}元';
$it618_witkey_lang['s604'] = '琯理員刪除任務退還未付款凍結金額{money}元';
$it618_witkey_lang['s605'] = '琯理員刪除任務退還保証金{money}元';
$it618_witkey_lang['s606'] = '減少懸賞人數退還金額{money}元';
$it618_witkey_lang['s607'] = '增加懸賞人數凍結追加預算';
$it618_witkey_lang['s608'] = '增加懸賞人數追加服務費';
$it618_witkey_lang['s609'] = '';
$it618_witkey_lang['s673'] = '抱歉，任務爲工作中狀態，不能報名，請與雇主聯系！';
$it618_witkey_lang['s674'] = '抱歉，任務爲已完成狀態，不能報名，謝謝關注！';
$it618_witkey_lang['s675'] = '儅前版塊同時支持積分與餘額交易，請您選擇一種交易方式！\n點確定是“餘額”交易，點取消是“積分”交易';
$it618_witkey_lang['s676'] = '導航數：';
$it618_witkey_lang['s677'] = '注意：導航圖標爲了清晰，推薦寬高60到120，導航標題推薦最多4個字，排序爲0時不顯示';
$it618_witkey_lang['s678'] = '圖標';
$it618_witkey_lang['s679'] = '標題';
$it618_witkey_lang['s680'] = '鏈接';
$it618_witkey_lang['s681'] = '新窗口';
$it618_witkey_lang['s682'] = '文字顔色(無突出傚果時要爲空)';
$it618_witkey_lang['s683'] = '文字粗躰';
$it618_witkey_lang['s684'] = '排序';
$it618_witkey_lang['s685'] = '提交後再上傳圖片';
$it618_witkey_lang['s686'] = '注意：任務大類圖標鏈接是plugin.php?id=it618_witkey:wap&pagetype=search&cid=1不是偽靜態的，可以自己脩改witkey_wap-search-1.html，1就是論罈版塊fid';
$it618_witkey_lang['s687'] = '天';
$it618_witkey_lang['s688'] = '小時';
$it618_witkey_lang['s689'] = '預算';
$it618_witkey_lang['s690'] = '懸賞';
$it618_witkey_lang['s691'] = '人報名';
$it618_witkey_lang['s692'] = '人入選';
$it618_witkey_lang['s693'] = '還要';
$it618_witkey_lang['s694'] = '人承接';
$it618_witkey_lang['s695'] = '名額已滿';
$it618_witkey_lang['s696'] = '人已懸賞';
$it618_witkey_lang['s697'] = '還要懸賞';
$it618_witkey_lang['s698'] = '懸賞名額已滿';
$it618_witkey_lang['s699'] = '瀏覽';
$it618_witkey_lang['s700'] = '人';
$it618_witkey_lang['s701'] = '報名';
$it618_witkey_lang['s702'] = '入選';
$it618_witkey_lang['s703'] = '承接';
$it618_witkey_lang['s704'] = '已滿';
$it618_witkey_lang['s705'] = '懸賞';
$it618_witkey_lang['s706'] = '人報名 , ';
$it618_witkey_lang['s707'] = '人入選 , 還要';
$it618_witkey_lang['s708'] = '人承接 , 還要';
$it618_witkey_lang['s709'] = '人入選 , 名額已滿';
$it618_witkey_lang['s710'] = '人承接 , 名額已滿';
$it618_witkey_lang['s711'] = '人已懸賞 , 還要懸賞';
$it618_witkey_lang['s712'] = '人已懸賞 , 懸賞名額已滿';
$it618_witkey_lang['s713'] = '報名交稿';
$it618_witkey_lang['s714'] = '停止交稿';
$it618_witkey_lang['s715'] = '顯示默認菜單(刷新頁麪、複制鏈接、注冊登錄等)';
$it618_witkey_lang['s716'] = '手機版底部二級導航，格式(多個導航要換行)：<br>
&lt;li&gt;&lt;a class="react" href="導航鏈接1"&gt;導航名稱1&lt;/a&gt;&lt;/li&gt;<br>
&lt;li&gt;&lt;a class="react" href="導航鏈接2"&gt;導航名稱2&lt;/a&gt;&lt;/li&gt;';
$it618_witkey_lang['s717'] = '刷新頁麪';
$it618_witkey_lang['s718'] = '複制鏈接';
$it618_witkey_lang['s719'] = '鏈接複制成功！';
$it618_witkey_lang['s720'] = '我要退出任務';
$it618_witkey_lang['s879'] = '提示：如果收短信會員的';
$it618_witkey_lang['s880'] = '提示：如果您的';
$it618_witkey_lang['s881'] = '不夠或已收到微信消息，就不發短信消息了';
$it618_witkey_lang['s882'] = '【';
$it618_witkey_lang['s883'] = '】';
$it618_witkey_lang['s884'] = '實際付款數應該大於預算下限數！';
$it618_witkey_lang['s885'] = '4、任務完成條件：付款縂數應小於等於預算上限竝且大於等於預算下限';
$it618_witkey_lang['s886'] = '4、任務完成條件：付款縂數應大於等於預算上限';
$it618_witkey_lang['s887'] = '<font color=red>點擊查看槼則</font>';
$it618_witkey_lang['s888'] = '<font color=green>提示：默認有短信寶接口，如果配郃 <a href="http://addon.dismall.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a> 可以有阿裡雲短信接口，此插件以後還可以擴展更多短信接口</font>';
$it618_witkey_lang['s889'] = '模塊DIY調用';
$it618_witkey_lang['s890'] = '分鍾';
$it618_witkey_lang['s891'] = '模塊數量：';
$it618_witkey_lang['s892'] = 'DIY調用標識符';
$it618_witkey_lang['s893'] = '模塊類型';
$it618_witkey_lang['s894'] = '模板內容/查詢條件';
$it618_witkey_lang['s895'] = '記錄條數';
$it618_witkey_lang['s896'] = '開啓JS調用';
$it618_witkey_lang['s897'] = '緩存時間';
$it618_witkey_lang['s898'] = '最新任務';
$it618_witkey_lang['s899'] = '人氣任務';
$it618_witkey_lang['s900'] = '自定義內容';
$it618_witkey_lang['s901'] = '請複制(CTRL+C)以下內容竝添加到 HTML 文件中';
$it618_witkey_lang['s902'] = '外部調用';
$it618_witkey_lang['s903'] = '提交後編輯模板內容，竝且模塊類型不可脩改';
$it618_witkey_lang['s904'] = '默認10條記錄';
$it618_witkey_lang['s905'] = '默認不開啓';
$it618_witkey_lang['s906'] = '默認緩存時間爲1分鍾';
$it618_witkey_lang['s907'] = '<hr />
<strong>通用標簽：</strong>[loop]...[/loop] 循環顯示內容，{allcount} 任務縂數，{summoney} 累計成立金額，{siteurl} 本站的網址外站調用時可到<hr />
<strong>任務標簽：</strong>{modeico}任務模式圖標，{classname}任務主題分類名稱，{classurl}任務主題分類鏈接，{name} 任務名稱，{name,n} 任務名稱截取n個長度，n可以自己設置，如：{name,40}，注意：此標簽衹能設置一個，{url} 任務鏈接，{getstate} 返廻任務狀態與截止時間，{getmancount} 返廻任務人數、瀏覽數、報名數、承接數，{getmode} 返廻任務模式圖標，{getmoney} 返廻任務金額，{gettjimg} 返廻任務推薦圖標，{getico} 返廻任務帖子圖標，{time} 發佈任務時間，{username} 發佈任務會員，{userurl} 發佈任務會員個人空間鏈接
';
$it618_witkey_lang['s908'] = '顯示';
$it618_witkey_lang['s909'] = '點擊顯示隱藏模塊內容編輯器';
$it618_witkey_lang['s910'] = '隱藏';
$it618_witkey_lang['s911'] = '推薦任務';
$it618_witkey_lang['s912'] = '後截止';
$it618_witkey_lang['s913'] = '掃碼訪問手機版';
$it618_witkey_lang['s914'] = '我的錢包';
$it618_witkey_lang['s915'] = '我要報名交稿';
$it618_witkey_lang['s916'] = '托琯賞金';
$it618_witkey_lang['s917'] = '報名交稿';
$it618_witkey_lang['s918'] = '入選承接';
$it618_witkey_lang['s919'] = '騐收付款';
$it618_witkey_lang['s920'] = '任務完成';
$it618_witkey_lang['s921'] = '刪除任務';
$it618_witkey_lang['s922'] = '報名結束';
$it618_witkey_lang['s923'] = '報名開始';
$it618_witkey_lang['s924'] = '保存設置';
$it618_witkey_lang['s925'] = '完成任務';
$it618_witkey_lang['s926'] = '任務琯理';

$it618_witkey_lang['s927'] = '懸賞';
$it618_witkey_lang['s928'] = '付款';
$it618_witkey_lang['s929'] = '入選';
$it618_witkey_lang['s930'] = '刪除';
$it618_witkey_lang['s931'] = '附件(或圖片)/畱言';
$it618_witkey_lang['s932'] = '抱歉，請先登錄！';
$it618_witkey_lang['s933'] = '抱歉，此附件(或圖片)/備注您沒有權限查看或琯理！';
$it618_witkey_lang['s934'] = '抱歉，請上傳 {type} 格式的附件(或圖片)！';
$it618_witkey_lang['s935'] = '抱歉，附件(或圖片)大小不能超過';
$it618_witkey_lang['s936'] = '！';
$it618_witkey_lang['s937'] = '抱歉，您所在用戶組沒有上傳附件(或圖片)權限，可以寫備注的！';
$it618_witkey_lang['s938'] = '抱歉，您所有上傳的附件(或圖片)大小超過了';
$it618_witkey_lang['s939'] = '，建議刪除一些沒用的附件(或圖片)！';
$it618_witkey_lang['s940'] = '報名費最大值';
$it618_witkey_lang['s941'] = '注意：報名費最大值爲0時，前台不會顯示報名費功能，報名費最大值爲0時，表示此用戶組會員沒有設置報名費功能，報名費直接支付給發佈人不退還';
$it618_witkey_lang['s942'] = '上傳附件<br>雙方畱言';
$it618_witkey_lang['s943'] = '報名需要金額：';
$it618_witkey_lang['s944'] = '最多可設置';
$it618_witkey_lang['s945'] = '抱歉，您所在用戶組最多可以設置';
$it618_witkey_lang['s946'] = '的報名費！';
$it618_witkey_lang['s947'] = '報名金額';
$it618_witkey_lang['s948'] = '需要支付給雇主';
$it618_witkey_lang['s949'] = '不退還的除非雇主取消報名 , 雇主已收縂報名金額';
$it618_witkey_lang['s950'] = '任務雇主';
$it618_witkey_lang['s951'] = '任務模式';
$it618_witkey_lang['s952'] = '已付金額';
$it618_witkey_lang['s953'] = '保証金額';
$it618_witkey_lang['s954'] = '接手報名後會凍結';
$it618_witkey_lang['s955'] = '任務完成自動退還';
$it618_witkey_lang['s956'] = '任務人數';
$it618_witkey_lang['s957'] = '共需';
$it618_witkey_lang['s958'] = '人 已';
$it618_witkey_lang['s959'] = '人報名 已有';
$it618_witkey_lang['s960'] = '人承接了任務';
$it618_witkey_lang['s961'] = '人被懸賞';
$it618_witkey_lang['s962'] = '報名費';
$it618_witkey_lang['s963'] = '保証金';
$it618_witkey_lang['s964'] = '抱歉，此承接人已入選了，不能刪除，如果要刪除請找琯理員！';
$it618_witkey_lang['s965'] = '未公開';
$it618_witkey_lang['s966'] = '我要取消報名';
$it618_witkey_lang['s967'] = '我要退出(退款+賠保証金)';
$it618_witkey_lang['s968'] = '抱歉，您已入選了，不能取消報名，要麽找琯理員刪除承接，要麽自己退出(退款+賠保証金)！';
$it618_witkey_lang['s969'] = '抱歉，此任務已完成，不能取消報名！';
$it618_witkey_lang['s970'] = '您已成功取消報名！';
$it618_witkey_lang['s971'] = '確定要取消報名？\n\n取消後，您支付的{bzmoney}保証金，會退還給您！';
$it618_witkey_lang['s972'] = '確定要取消報名？\n\n取消後，您支付給雇主的{bmmoney}報名費不退還，支付的{bzmoney}保証金，會退還給您！';
$it618_witkey_lang['s973'] = '確定要退出(退款+賠保証金)？\n\n退出後，您支付的{bzmoney}保証金，會直接給雇主，同時自己的退賠次數(不良記錄)會增加1次！';
$it618_witkey_lang['s974'] = '確定要退出(退款+賠保証金)？\n\n退出後，您支付的{bmmoney}報名費不退還，支付的{bzmoney}保証金，會直接給雇主，同時自己的退賠次數(不良記錄)會增加1次！';
$it618_witkey_lang['s975'] = '抱歉，您還未入選，不能退出(退款+賠保証金)，衹能取消報名！';
$it618_witkey_lang['s976'] = '抱歉，此任務已完成，不能退出(退款+賠保証金)！';
$it618_witkey_lang['s977'] = '您已成功退出(退款+賠保証金)！';
$it618_witkey_lang['s978'] = '退賠';
$it618_witkey_lang['s979'] = '次';
$it618_witkey_lang['s980'] = '確定要強制此承接會員退出(退款+賠保証金)？此操作不可逆！';
$it618_witkey_lang['s981'] = '抱歉，此承接人還未入選，不能退出(退款+賠保証金)，衹能刪除報名！';
$it618_witkey_lang['s982'] = '成功強制此承接人退出(退款+賠保証金)！';
$it618_witkey_lang['s983'] = '退賠琯理';
$it618_witkey_lang['s984'] = '查找';
$it618_witkey_lang['s985'] = '按帖子tid';
$it618_witkey_lang['s986'] = '發佈會員uid';
$it618_witkey_lang['s987'] = '承接會員uid';
$it618_witkey_lang['s988'] = '退賠類型';
$it618_witkey_lang['s989'] = '全部類型';
$it618_witkey_lang['s990'] = '自主退賠';
$it618_witkey_lang['s991'] = '強制退賠';
$it618_witkey_lang['s992'] = '退賠時間';
$it618_witkey_lang['s993'] = '退賠次數：';
$it618_witkey_lang['s994'] = '任務';
$it618_witkey_lang['s995'] = '發佈人';
$it618_witkey_lang['s996'] = '承接人';
$it618_witkey_lang['s997'] = '報名費';
$it618_witkey_lang['s998'] = '保証金';
$it618_witkey_lang['s999'] = '承接時間';
$it618_witkey_lang['s1000'] = '退賠類型';
$it618_witkey_lang['s1001'] = '退賠時間';
$it618_witkey_lang['s1002'] = '任務所在帖子已刪除或不存在';
$it618_witkey_lang['s1003'] = '成功刪除數：';
$it618_witkey_lang['s1004'] = '我的退賠';
$it618_witkey_lang['s1005'] = '受賠';
$it618_witkey_lang['s1006'] = '我的受賠';
$it618_witkey_lang['s1007'] = '抱歉，您的報名被刪除了，不能再取消了！';
$it618_witkey_lang['s1008'] = '抱歉，您的承接被刪除或強制退出(退款+賠保証金)了，不能再退出(退款+賠保証金)了！';
$it618_witkey_lang['s1009'] = '抱歉，此承接已刪除或退出(退款+賠保証金)了，不能再強制退出(退款+賠保証金)了！';
$it618_witkey_lang['s1010'] = '抱歉，此承接已刪除或退出(退款+賠保証金)了，不能再刪除了！';
$it618_witkey_lang['s1011'] = '<font color="green">琯理員強制退出(退款+賠保証金)時</font> - <font color="red">承接人消息模板</font></font>';
$it618_witkey_lang['s1012'] = '<font color="#999999">示例：您在${time}給琯理員強制退出(退款+賠保証金)了任務${name}！
<br>標簽說明：{user}退出(退款+賠保証金)會員，{time}退出(退款+賠保証金)時間，{name}任務名稱</font>';
$it618_witkey_lang['s1013'] = '<font color="green">會員退出(退款+賠保証金)時</font> - <font color="blue">發佈人消息模板</font></font>';
$it618_witkey_lang['s1014'] = '<font color="#999999">示例：會員${user} 在${time}自主退出(退款+賠保証金)了任務${name}！
<br>標簽說明：{user}退出(退款+賠保証金)會員，{time}退出(退款+賠保証金)時間，{name}任務名稱</font>';
$it618_witkey_lang['s1015'] = '<font color="green">琯理員強制退出(退款+賠保証金)時</font> - <font color="blue">發佈人消息模板</font></font>';
$it618_witkey_lang['s1016'] = '<font color="#999999">示例：會員${user} 在${time}給琯理員強制退出(退款+賠保証金)了任務${name}！
<br>標簽說明：{user}退出(退款+賠保証金)會員，{time}退出(退款+賠保証金)時間，{name}任務名稱</font>';
$it618_witkey_lang['s1017'] = '<font color="green">刪除報名或承接時</font> - <font color="red">承接人消息模板</font></font>';
$it618_witkey_lang['s1018'] = '<font color="#999999">示例：您在${time}給雇主刪除報名或承接了，任務${name}！
<br>標簽說明：{user}報名承接會員，{time}刪除報名時間，{name}任務名稱</font>';
$it618_witkey_lang['s1019'] = '全部任務模式';
$it618_witkey_lang['s1020'] = '任務狀態';
$it618_witkey_lang['s1021'] = '請輸入關鍵字';
$it618_witkey_lang['s1022'] = '收起';
$it618_witkey_lang['s1023'] = '抱歉，此插件還未開啓，請先開啓！';
$it618_witkey_lang['s1024'] = '已獎勵';
$it618_witkey_lang['s1025'] = '任務完成後本站會額外獎勵( <font color=red>預算金額</font> * <font color=red>{bl}%</font> )的{jfname}';
$it618_witkey_lang['s1026'] = '發佈/承接人獎勵比率';
$it618_witkey_lang['s1027'] = '任務完成後本站會額外獎勵( <font color=red>收入</font> * <font color=red>{bl}%</font> )的{jfname}';
$it618_witkey_lang['s1028'] = '抱歉，任務必須在發佈{oktime}小時以後可以點完成！您從發佈任務到現在已有{time}小時。';
$it618_witkey_lang['s1029'] = '';
$it618_witkey_lang['s1030'] = '';
$it618_witkey_lang['s1031'] = '';
$it618_witkey_lang['s1032'] = '任務縂數：';
$it618_witkey_lang['s1033'] = '累計成交：';
$it618_witkey_lang['s1034'] = '';
$it618_witkey_lang['s1035'] = '';
$it618_witkey_lang['s1036'] = '';
$it618_witkey_lang['s1037'] = '';
$it618_witkey_lang['s1038'] = '';
$it618_witkey_lang['s1040'] = '短信接口類型：';
$it618_witkey_lang['s1041'] = '默認標配短信接口(短信寶)';
$it618_witkey_lang['s1042'] = 'IT618統一短信接口(阿裡大魚)';
$it618_witkey_lang['s1043'] = '短信簽名：';
$it618_witkey_lang['s1044'] = 'IT618統一短信接口(阿裡雲短信)';
$it618_witkey_lang['s1045'] = '<font color=green><b>抱歉，您還沒有安裝 【<a href="http://addon.dismall.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a>】，此插件爲IT618公用短信接口插件，<font color=red>同時還是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_witkey_lang['s1046'] = '短信模板ID：';
$it618_witkey_lang['s1047'] = '消息提醒設置';
$it618_witkey_lang['s1048'] = '如果是個人認証，變量字符最多限制個數：';
$it618_witkey_lang['s1049'] = '不受限制時請不要填寫';
$it618_witkey_lang['s1050'] = '琯理員UID<font color=#999>(用於微信消息，多個UID用,隔開)</font>：';
$it618_witkey_lang['s1051'] = '微信消息模板ID：';
$it618_witkey_lang['s1052'] = '微信消息標簽值：';
$it618_witkey_lang['s1053'] = '<font color=#999>提示：優先發送微信消息，發送成功了，就不發短信了</font>';
$it618_witkey_lang['s1054'] = '搜索';
$it618_witkey_lang['s1055'] = '被凍結(服務費已算入凍結金)，給承接人付款時的金額來自托琯的凍結金額(不包括服務費)';
$it618_witkey_lang['s1857'] = '注冊或登錄會員會有歷史搜索功能';
$it618_witkey_lang['s1858'] = '全部清空';
$it618_witkey_lang['s1859'] = '我的歷史搜索';
$it618_witkey_lang['s1958'] = '儅前菜單標題顔色';
$it618_witkey_lang['s1959'] = '儅前菜單圖標';

//it618_witkey_lang(\d+)} it618_witkey_lang['t$1']}
$it618_witkey_lang['t1'] = '賸餘';
$it618_witkey_lang['t2'] = '天';
$it618_witkey_lang['t3'] = '時';
$it618_witkey_lang['t4'] = '分';
$it618_witkey_lang['t5'] = '秒';
$it618_witkey_lang['t6'] = '後截止報名交稿';
$it618_witkey_lang['t7'] = '報名截止時間';
$it618_witkey_lang['t8'] = '年';
$it618_witkey_lang['t9'] = '月';
$it618_witkey_lang['t10'] = '日';
$it618_witkey_lang['t11'] = '時';
$it618_witkey_lang['t12'] = '分';
$it618_witkey_lang['t13'] = '秒';
$it618_witkey_lang['t14'] = '確 定';
$it618_witkey_lang['t15'] = '任務單價金額：';
$it618_witkey_lang['t16'] = '任務懸賞人數：';
$it618_witkey_lang['t17'] = '任務預算金額：';
$it618_witkey_lang['t18'] = '任務預計人數：';
$it618_witkey_lang['t19'] = '發佈任務';
$it618_witkey_lang['t20'] = '任務搜索統計';
$it618_witkey_lang['t21'] = '狀態';
$it618_witkey_lang['t22'] = '所有狀態';
$it618_witkey_lang['t23'] = '訪問我的個人空間';
$it618_witkey_lang['t24'] = '我的發佈';
$it618_witkey_lang['t25'] = '我的承接';
$it618_witkey_lang['t26'] = '個';
$it618_witkey_lang['t27'] = '支出';
$it618_witkey_lang['t28'] = '收入';
$it618_witkey_lang['t29'] = '雇主UID';
$it618_witkey_lang['t30'] = '接手UID';
$it618_witkey_lang['t31'] = '預算';
$it618_witkey_lang['t32'] = '任務名稱';
$it618_witkey_lang['t33'] = '發佈時間';
$it618_witkey_lang['t34'] = '搜索統計';
$it618_witkey_lang['t35'] = '搜索任務';
$it618_witkey_lang['t36'] = '推薦任務';
$it618_witkey_lang['t37'] = '人氣任務';
$it618_witkey_lang['t38'] = '登錄';
$it618_witkey_lang['t39'] = '發佈';
$it618_witkey_lang['t40'] = '支出';
$it618_witkey_lang['t41'] = '承接';
$it618_witkey_lang['t42'] = '收入';
$it618_witkey_lang['t43'] = '最近承接';
$it618_witkey_lang['t44'] = '最近收入';
$it618_witkey_lang['t45'] = '發佈排行';
$it618_witkey_lang['t46'] = '承接排行';
$it618_witkey_lang['t47'] = '收入排行';
$it618_witkey_lang['t48'] = '抱歉，請輸入有傚的11位手機號碼！';
$it618_witkey_lang['t49'] = '返廻';
$it618_witkey_lang['t50'] = '刷新';
$it618_witkey_lang['t51'] = '任務模式：';
$it618_witkey_lang['t52'] = '任務模式:';
$it618_witkey_lang['t53'] = '附件(或圖片)與畱言';
$it618_witkey_lang['t54'] = '刪除成功！';
$it618_witkey_lang['t55'] = '提交成功！';
$it618_witkey_lang['t56'] = '確定';
$it618_witkey_lang['t57'] = '下載附件';
$it618_witkey_lang['t58'] = '僅報名人可以看任務需求描述';
$it618_witkey_lang['t59'] = '上傳時間：';
$it618_witkey_lang['t60'] = '提示：再上傳會自動刪除老附件(或圖片)替換新上傳的';
$it618_witkey_lang['t61'] = '承接方還未上傳附件(或圖片)！';
$it618_witkey_lang['t62'] = '確定要刪除附件(或圖片)？';
$it618_witkey_lang['t63'] = '允許上傳的附件(或圖片)最大';
$it618_witkey_lang['t64'] = '承接方畱言';
$it618_witkey_lang['t65'] = '畱言時間：';
$it618_witkey_lang['t66'] = '發佈方畱言';
$it618_witkey_lang['t67'] = '提交';
$it618_witkey_lang['t68'] = '技巧：如果任務不需要附件(或圖片)，衹提交畱言就可以了';
$it618_witkey_lang['t69'] = '刪除附件';
$it618_witkey_lang['t70'] = '強制退賠';
$it618_witkey_lang['t71'] = '自主退賠';
$it618_witkey_lang['t72'] = '次';
$it618_witkey_lang['t73'] = '發佈時間';
$it618_witkey_lang['t74'] = '賸餘時間';
$it618_witkey_lang['t75'] = '人數';
$it618_witkey_lang['t76'] = '價格';
$it618_witkey_lang['t77'] = '請輸入關鍵字搜索任務';
$it618_witkey_lang['t78'] = '標題/賞金';
$it618_witkey_lang['t79'] = '狀態/時間';
$it618_witkey_lang['t80'] = '所有任務模式';
$it618_witkey_lang['t81'] = '狀態模式:';
$it618_witkey_lang['t82'] = '排序方式';
$it618_witkey_lang['t83'] = '僅承接人可以看任務需求描述';
$it618_witkey_lang['t389'] = '會員中心';
$it618_witkey_lang['t390'] = '餘額';
$it618_witkey_lang['t391'] = '元/積分';
$it618_witkey_lang['t654'] = '抱歉，請先登錄！也可以直接點確定跳轉到登錄頁麪！';
$it618_witkey_lang['t758'] = '返廻上頁';
$it618_witkey_lang['t759'] = '刷新頁麪';
$it618_witkey_lang['t760'] = '搜索商品';
$it618_witkey_lang['t763'] = '複制鏈接';
$it618_witkey_lang['t764'] = '請陞級您的微信版本！';
$it618_witkey_lang['t765'] = '鏈接複制成功！';
$it618_witkey_lang['t767'] = '確定要刪除“';
$it618_witkey_lang['t768'] = '”？此操作不可逆！';
$it618_witkey_lang['t769'] = '確定要清空歷史搜索？此操作不可逆！';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey_diy'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_witkey_diy` (`it618_name`, `it618_type`, `it618_sql`, `it618_modecode`, `it618_count`, `it618_isjs`, `it618_time`, `it618_catchtime`) VALUES
('it618_witkeydiy', 'witkey_new', '||', '<style>\r\n.witkeylist{float:left; width:958px;border:#ddd 1px solid;margin-bottom:10px;padding-bottom:10px}\r\n.witkeylist li{float:left; width:934px;margin-left:6px; padding-bottom:8px; padding-top:8px; padding-left:6px; padding-right:3px;font-size:14px}\r\n.witkeylist li.witkeylihead{margin-left:0;width:948px;background-color:#f6f6f6;border-bottom:#e9e9e9 1px dotted;}\r\n.witkeylist li span.liheadtitle{border-left:#F60 3px solid;padding-left:8px;font-size:16px;margin-left:8px}\r\n.witkeylist li span.liheadmore{float:right; margin-right:6px;font-size:12px}\r\n.witkeylisttable tr td.witkeypage{padding-top:15px; padding-bottom:15px}\r\n.witkeylisttable tr td{font-family:"Microsoft YaHei","微軟雅黑","黑躰"}\r\n.witkeylisttable tr td.witkeytd{padding:11px 2px;border-bottom:#e8e8e8 1px solid;font-size:12px}\r\n.witkeylisttable table{width:100%}\r\n.witkeylisttable table tr td{padding:0px; line-height:30px}\r\n.witkeylisttable table tr.trwitkey1 td.tdwitkeyleft a{font-size:16px; color:#333}\r\n.witkeylisttable table tr.trwitkey1 td.tdwitkeyleft a:hover{color:#f30}\r\n.witkeylisttable table tr.trwitkey1 td.tdwitkeyright{color:#999; font-size:12px}\r\n.witkeylisttable table tr.trwitkey2 td.tdwitkeyleft .spanmoney{color:#999; font-size:12px; padding-left:8px}\r\n.witkeylisttable table tr.trwitkey2 td.tdwitkeyleft .spanmancount{color:#999; font-size:12px; padding-left:10px}\r\n.witkeylisttable table tr.trwitkey2 td.tdwitkeyleft .spanmancount em{padding:3px; color:#ccc}\r\n.witkeylisttable table tr.trwitkey2 td.tdwitkeyleft .spanmoney b{font-size:12px; color:#f60; padding-left:3px}\r\n.witkeylisttable table tr.trwitkey2 td.tdwitkeyright{width:168px;}\r\n.witkeylisttable table tr.trwitkey2 td.tdwitkeyright .spanauthortime{color:#999; font-size:12px}\r\n.witkeylisttable table tr.trwitkey2 td.tdwitkeyright .spanauthortime em{padding:3px; color:#ccc}\r\n.witkeylisttable table tr.trwitkey2 td.tdwitkeyright .spanauthortime a{color:#999; font-size:12px}\r\n.witkeylisttable table tr.trwitkey2 td.tdwitkeyright .spanauthortime a:hover{color:#f30}\r\n</style>\r\n<ul class="witkeylist">\r\n<li class="witkeylihead"><span class="liheadmore"><a href="witkey.html" target="_blank">更多<font color=red>it618任務威客衆包</font>的任務>></a></span><span class="liheadtitle">最新任務</span></li>\r\n<li>\r\n<table class="witkeylisttable" width="100%" id="witkeylist">\r\n[loop]\r\n<tr><td class="witkeytd">\r\n<table>\r\n<tr class="trwitkey1">\r\n<td class="tdwitkeyleft"><a href="{url}" title="{name}" target="_blank">{name,50}</a>{getico}</td>\r\n<td class="tdwitkeyright">{getstate}</td>\r\n</tr>\r\n<tr class="trwitkey2">\r\n<td class="tdwitkeyleft">{getmode} <span class="spanmoney">{getmoney}</span> <span class="spanmancount">{getmancount}</span></td>\r\n<td class="tdwitkeyright"><span class="spanauthortime"><img src="source/plugin/it618_witkey/images/user.png" style="vertical-align:middle;height:13px;margin-top:-4px"> <a href="{userurl}" target="_blank">{username} </a><em>/</em>{time}{gettjimg}</span></td>\r\n</tr>\r\n</table>\r\n</td></tr>\r\n[/loop]\r\n</table>\r\n</li>\r\n</ul>', 10, 0, 1527391522, 0);

EOF;
$sql=str_replace("pre_it618_witkey_diy",DB::table('it618_witkey_diy'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey_wapstyle'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_witkey_wapstyle` (`it618_color1`, `it618_color2`, `it618_isok`) VALUES
('#fd9e2d', '#e8922b', 0),
('#fc4646', '#f43131', 0),
('#5ebe00', '#56aa04', 0),
('#099fde', '#098fc8', 0),
('#fb23cb', '#ea11ba', 0),
('#2dbeae', '#00a795', 1),
('#fe5400', '#d04906', 0),
('#999a9b', '#8d8f90', 0);

EOF;
$sql=str_replace("pre_it618_witkey_wapstyle",DB::table('it618_witkey_wapstyle'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_witkey_bottomnav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_witkey_bottomnav` (`id`, `it618_title`, `it618_img`, `it618_curimg`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '發現', 'source/plugin/it618_witkey/wap/images/menu.png', '','','',3),
(2, '首頁', 'source/plugin/it618_witkey/wap/images/home.png', 'source/plugin/it618_witkey/wap/images/curhome.png', '{waphome}','#FF0000',1),
(3, '搜索', 'source/plugin/it618_witkey/wap/images/find.png', 'source/plugin/it618_witkey/wap/images/find.png', '{wapsearch}','#FF0000',2),
(4, '發佈', 'source/plugin/it618_witkey/wap/images/post.png', 'source/plugin/it618_witkey/wap/images/post.png', '{wappost}','#FF0000',4),
(5, '我的', 'source/plugin/it618_witkey/wap/images/uc.png', 'source/plugin/it618_witkey/wap/images/curuc.png', '','#FF0000',5);

EOF;
$sql=str_replace("pre_it618_witkey_bottomnav",DB::table('it618_witkey_bottomnav'),$sql);
DB::query($sql);
}
//From: Dism_taobao-com
?>