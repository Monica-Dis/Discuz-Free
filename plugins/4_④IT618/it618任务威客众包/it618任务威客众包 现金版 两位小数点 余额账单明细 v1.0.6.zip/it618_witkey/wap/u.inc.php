<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!witkey_is_mobile()){
	$tmpurl=it618_witkey_getrewrite('witkey_home','','plugin.php?id=it618_witkey:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_witkey_getlang('t389').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_witkey_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_witkey:wap_witkey');
	return;
}

$menuusername=$_G['username'];
$u_avatarimg=it618_witkey_discuz_uc_avatar($_G['uid'],'middle');
$moneyname=$it618_witkey_lang['s201'];
$creditnum=it618_witkey_getumoney($_G['uid']);

$postcount = C::t('#it618_witkey#it618_witkey_main')->count_by_search('','',$_G['uid'],0);
$postmoney = C::t('#it618_witkey#it618_witkey_main')->sum_jlmoney_by_search('','',$_G['uid'],0);
if($postmoney=='')$postmoney=0;

$getcount = C::t('#it618_witkey#it618_witkey_main')->count_by_search('','',0,$_G['uid']);
$getmoney = C::t('#it618_witkey#it618_witkey_main')->sum_jlmoney_by_search('','',0,$_G['uid']);
if($getmoney=='')$getmoney=0;

$postpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_witkey_pf')." WHERE it618_postuid=".$_G['uid']);
$getpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_witkey_pf')." WHERE it618_getuid=".$_G['uid']);

$postpfmoney = DB::result_first("SELECT sum(it618_getwitkeymoney) FROM ".DB::table('it618_witkey_pf')." WHERE it618_postuid=".$_G['uid']);
$getpfmoney = DB::result_first("SELECT sum(it618_getwitkeymoney) FROM ".DB::table('it618_witkey_pf')." WHERE it618_getuid=".$_G['uid']);

$wappostpf=it618_witkey_getrewrite('witkey_wap','pf@1@'.$_G['uid'],'plugin.php?id=it618_witkey:wap&pagetype=pf&cid=1&uid='.$_G['uid']);
$wapgetpf=it618_witkey_getrewrite('witkey_wap','pf@2@'.$_G['uid'],'plugin.php?id=it618_witkey:wap&pagetype=pf&cid=2&uid='.$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_witkey:wap_witkey');
?>