<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_witkey/function.func.php';

if(!witkey_is_mobile()){ 
	$tmpurl=it618_witkey_getrewrite('witkey_home','','plugin.php?id=it618_witkey:index');
	dheader("location:$tmpurl");
}

$witkey_focus_pics_wap = $it618_witkey['witkey_focus_pics_wap'];
$witkey_focus_pics_wap=explode("|",str_replace(array("\r\n", "\r", "\n"), '|', $it618_witkey['witkey_focus_pics_wap']));
if($il1i1l[5]!='_')return;
$i=1;
foreach($witkey_focus_pics_wap as $key => $witkey_focus_pic){
	if($witkey_focus_pic!=""){
		$tmparr=explode("==",$witkey_focus_pic);
		if($tmparr[1]!=''){
			$str_focus.='<div class="swiper-slide"><a href="'.$tmparr[1].'" target="_blank"><img class="img" src="'.it618_witkey_getwapppic($tmparr[0]).'"/></a></div>';
		}else{
			$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_witkey_getwapppic($tmparr[0]).'" /></div>';
		}
		$i=$i1;
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_witkey_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_witkey_gonggao = DB::fetch($query)) {
	$it618_title=$it618_witkey_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_witkey_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_witkey_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_witkey_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_witkey_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_witkey_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_witkey_iconav = DB::fetch($query)) {
	$it618_title=$it618_witkey_iconav['it618_title'];
	
	if($it618_witkey_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_witkey_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_witkey_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_witkey_iconav['it618_color'].'">'.$it618_title.'</font>';
	}

	$str_iconav.='<td width="20%"><a href="'.$it618_witkey_iconav['it618_url'].'"'.$it618_target.'><img src="'.$it618_witkey_iconav['it618_img'].'" /><br>'.$it618_title.'</a></td>';
	
	if($n%5==0){
		$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav">';
		$n=1;
	}
	$n=$n+1;
	
	$isiconav=1;
}

for($i=1;$i<=($n+1)%5;$i++){
	$str_iconav.='<td width="20%"></td>';
}
$str_iconav.='</tr>';
$str_iconav=str_replace('<tr><td width="20%"></td></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"></tr></table></div>','',$str_iconav);

for($n=1;$n<=3;$n++){
	if($n==1)$current=' class="current"';else $current=' ';
	if($n==1){
		$tab_witkey.='<li'.$current.'onclick="it618_witkey_tabChange(this,\'searchli_bd\')">'.$it618_witkey_lang['s387'].'</li>';
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_witkey_main')." where it618_tid>0 order by id desc limit 0,".$it618_witkey['witkey_witkeycount']);
	}
	
	if($n==2){
		$tab_witkey.='<li'.$current.'onclick="it618_witkey_tabChange(this,\'searchli_bd\')">'.$it618_witkey_lang['s388'].'</li>';
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_witkey_main')." where it618_tid>0 and it618_istj=1 order by id desc limit 0,".$it618_witkey['witkey_witkeycount']);
	}
	
	if($n==3){
		$tab_witkey.='<li'.$current.'onclick="it618_witkey_tabChange(this,\'searchli_bd\')">'.$it618_witkey_lang['s389'].'</li>';
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_witkey_main')." where it618_tid>0 order by it618_views desc limit 0,".$it618_witkey['witkey_witkeycount']);
	}
	
	$home_witkeytmp='';
	while($it618_witkey_main =DB::fetch($query)) {

		$tid=$it618_witkey_main['it618_tid'];
		$uid=$it618_witkey_main['it618_uid'];
		$subject=it618_witkey_getsubject($tid);
		
		$getstate=it618_witkey_getstate($it618_witkey_main,1);
		$getmancount=it618_witkey_getmancount($it618_witkey_main,1);
		$getmode=it618_witkey_getmode($it618_witkey_main,1);
		$getmoney=it618_witkey_getmoney($it618_witkey_main,1);
		$gettjimg=it618_witkey_gettjimg($it618_witkey_main,1);
		
		$home_witkeytmp.='<tr><td onclick="dohref('.$tid.')">
		<a href="forum.php?mod=viewthread&tid='.$tid.'" id="href'.$tid.'">'.$subject.'</a> '.it618_witkey_getico($tid).'
		<br><span class="spanauthortime">'.it618_witkey_getauthor($it618_witkey_main['it618_uid']).'<em>/</em>'.date('Y-m-d', $it618_witkey_main['it618_time1']).$gettjimg.'</span><span class="spanmancount">'.$getmancount.'</span>
		<br><span class="spanstate">'.$getstate.'</span>
		'.$getmode.' <span class="spanmoney">'.$getmoney.'</span>
		</td></tr>';

	}
	$tmpurl=it618_witkey_getrewrite('witkey_wap','search','plugin.php?id=it618_witkey:wap&pagetype=search');
	if($n==1)$bdstyle=' ;display:';else $bdstyle=' ;display:none';
	$home_witkey.='<dl class="list" id="searchli_bd'.($n-1).'" style="border-top:none; margin:0;'.$bdstyle.'">
					<dd>
						<table class="witkeylist">
						'.$home_witkeytmp.'
						<tr><td style="border:none"><div class="wapmore"><a href="'.$tmpurl.'">'.it618_witkey_getlang('s386').'&gt;&gt;</a></div></td></tr>
						</table>
					</dd>
				  </dl>';
}


//��������
$query = DB::query("SELECT it618_uid,count(1) as witkeycount FROM ".DB::table('it618_witkey_main')." group by it618_uid order by witkeycount desc limit 0,".$it618_witkey['witkey_rightcount']);
$n=1;
while($it618_witkey_witkey =DB::fetch($query)) {
	$uid=$it618_witkey_witkey['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$postph.='<tr><td><span style="float:right" class="tdspanright"><font color=red>'.$it618_witkey_witkey['witkeycount'].'</font> '.it618_witkey_getlang('s331').'</span><span class="phnum'.$tmpcss.'">'.$n.'</span> '.it618_witkey_getauthor($uid).'<span style="color:#999">('.$uid.')</span>'.'</td></tr>';
	$n=$n+1;
}
$postph=it618_witkey_rewriteurl($postph);
$il1i1l=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$il1i1l[]=substr($_GET['id'],$i,1);}
if($il1i1l[9]!='k')return;

//�н�����
$query = DB::query("SELECT it618_uid,count(1) as getcount FROM ".DB::table('it618_witkey')." group by it618_uid order by getcount desc limit 0,".$it618_witkey['witkey_rightcount']);
$n=1;
while($it618_witkey_witkey =DB::fetch($query)) {
	$uid=$it618_witkey_witkey['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$getph.='<tr><td><span style="float:right" class="tdspanright"><font color=red>'.$it618_witkey_witkey['getcount'].'</font> '.it618_witkey_getlang('s331').'</span><span class="phnum'.$tmpcss.'">'.$n.'</span> '.it618_witkey_getauthor($uid).'<span style="color:#999">('.$uid.')</span>'.'</td></tr>';
	$n=$n+1;
}
$getph=it618_witkey_rewriteurl($getph);
if($il1i1l[6]!='w')return;

//��������
$query = DB::query("SELECT it618_uid,sum(it618_creditnum) as money FROM ".DB::table('it618_witkey')." group by it618_uid order by money desc limit 0,".$it618_witkey['witkey_rightcount']);
$n=1;
while($it618_witkey_witkey =DB::fetch($query)) {
	$uid=$it618_witkey_witkey['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$moneyph.='<tr><td><span style="float:right" class="tdspanright"><font color=red>'.$it618_witkey_witkey['money'].'</font> '.$witkey_moneyname.'</span><span class="phnum'.$tmpcss.'">'.$n.'</span> '.it618_witkey_getauthor($uid).'<span style="color:#999">('.$uid.')</span>'.'</td></tr>';
	$n=$n+1;
}
$moneyph=it618_witkey_rewriteurl($moneyph);

$tab_witkey.='<li'.$current.'onclick="it618_witkey_tabChange(this,\'searchli_bd\')">'.$it618_witkey_lang['s413'].'</li>';

$home_witkey.='<dl class="list" id="searchli_bd3" style="border-top:none; margin:0;display:none">
				<dd>
					<ul class="searchli1">
						<li class="current" onclick="it618_witkey_tabChange(this,\'searchtable_bd\')">'.$it618_witkey_lang['t45'].'</li>
						<li onclick="it618_witkey_tabChange(this,\'searchtable_bd\')">'.$it618_witkey_lang['t46'].'</li>
						<li onclick="it618_witkey_tabChange(this,\'searchtable_bd\')">'.$it618_witkey_lang['t47'].'</li>
					</ul>
					<table class="phtable" id="searchtable_bd0">
					'.$postph.'
					</table>
					<table class="phtable" id="searchtable_bd1" style="display:none">
					'.$getph.'
					</table>
					<table class="phtable" id="searchtable_bd2" style="display:none">
					'.$moneyph.'
					</table>
				</dd>
			  </dl>';

$homewitkey_str='<dl style="margin:0;margin-top:10px;padding-left:10px;padding-right:10px;background-color:#fff"><ul class="searchlihome">'.$tab_witkey.'</ul></dl>'.$home_witkey.'';
$homewitkey_str=it618_witkey_rewriteurl($homewitkey_str);

$allcount = C::t('#it618_witkey#it618_witkey_main')->count_by_search();
$allmoney = C::t('#it618_witkey#it618_witkey_main')->sum_jlmoney_by_search();

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_witkey:wap_witkey');
?>