<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_wike_main`;

DROP TABLE IF EXISTS `pre_it618_wike`;

DROP TABLE IF EXISTS `pre_it618_wike_pf`;

DROP TABLE IF EXISTS `pre_it618_wike_user`;

DROP TABLE IF EXISTS `pre_it618_wike_grouppower`;

DROP TABLE IF EXISTS `pre_it618_wike_it618`;

DROP TABLE IF EXISTS `pre_it618_wike_wapstyle`;

DROP TABLE IF EXISTS `pre_it618_wike_gonggao`;

DROP TABLE IF EXISTS `pre_it618_wike_diy`;

DROP TABLE IF EXISTS `pre_it618_wike_iconav`;

DROP TABLE IF EXISTS `pre_it618_wike_set`;

DROP TABLE IF EXISTS `pre_it618_wike_bottomnav`;

DROP TABLE IF EXISTS `pre_it618_wike_findkey`;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>