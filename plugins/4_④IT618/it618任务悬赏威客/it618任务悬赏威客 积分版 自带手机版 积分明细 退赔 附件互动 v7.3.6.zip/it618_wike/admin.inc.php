<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
global $_G;

loadcache('plugin');
$it618_images = $_G['cache']['plugin']['it618_wike'];

loadcache('pluginlanguage_template');
loadcache('pluginlanguage_script');
$scriptlang['it618_wike'] = $_G['cache']['pluginlanguage_script']['it618_wike'];

$it618_lang = $scriptlang['it618_wike'];

for($i=70;$i<=81;$i++){
	$it618_lang_admin[$i]=$it618_lang['it618_wike_lang'.$i];
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function/it618_wike.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_grouppower');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_grouppower' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');


require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();
?>