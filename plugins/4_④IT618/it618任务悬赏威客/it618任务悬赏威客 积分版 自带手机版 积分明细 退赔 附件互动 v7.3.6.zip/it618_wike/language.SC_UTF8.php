<?php
/**
 *	开发团队：IT618
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1012" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_wike_lang;

function it618_wike_getlang($langid){
	global $it618_wike_lang;
	return $it618_wike_lang[$langid];
}

$it618_wike_lang['version']='v7.3.6';
$it618_wike_lang['s1'] = '任务发布成功！';
$it618_wike_lang['s2'] = '抱歉，参数有误，请与管理员联系！';
$it618_wike_lang['s3'] = '抱歉，发布任务最小需要';
$it618_wike_lang['s4'] = '，您现在只有';
$it618_wike_lang['s5'] = '任务预算修改成功！';
$it618_wike_lang['s6'] = '抱歉，预算没修改或参数有误，请与管理员联系！';
$it618_wike_lang['s7'] = '任务圆满完成成功！';
$it618_wike_lang['s8'] = '任务报名成功！';
$it618_wike_lang['s9'] = '您已经承接了此任务！';
$it618_wike_lang['s10'] = '抱歉，请先登录！';
$it618_wike_lang['s11'] = '付款成功！';
$it618_wike_lang['s12'] = '抱歉，付款值没修改或参数有误，请与管理员联系！';
$it618_wike_lang['s13'] = '工作中';
$it618_wike_lang['s14'] = '已完成';
$it618_wike_lang['s15'] = '发布会员';
$it618_wike_lang['s16'] = '预算金额';
$it618_wike_lang['s17'] = '承接人数';
$it618_wike_lang['s18'] = '付款金额';
$it618_wike_lang['s19'] = '当前状态';
$it618_wike_lang['s20'] = '发布时间';
$it618_wike_lang['s21'] = '任务规则：';
$it618_wike_lang['s22'] = '任务预算金额：';
$it618_wike_lang['s23'] = '修改预算';
$it618_wike_lang['s24'] = '完成任务';
$it618_wike_lang['s25'] = '我要承接任务';
$it618_wike_lang['s26'] = '发布任务';
$it618_wike_lang['s27'] = '付款';
$it618_wike_lang['s28'] = '还有';
$it618_wike_lang['s29'] = '的预算冻结金可抵扣';
$it618_wike_lang['s30'] = '序号';
$it618_wike_lang['s31'] = '承接人';
$it618_wike_lang['s32'] = '承接次数';
$it618_wike_lang['s33'] = '总得分';
$it618_wike_lang['s34'] = '当前得分';
$it618_wike_lang['s35'] = '承接时间';
$it618_wike_lang['s36'] = '任务付款';
$it618_wike_lang['s37'] = '您现在的';
$it618_wike_lang['s38'] = '数量不够付款！';
$it618_wike_lang['s39'] = '完成时间';
$it618_wike_lang['s40'] = '支持';
$it618_wike_lang['s41'] = '不支持';
$it618_wike_lang['s42'] = '抱歉，预算金额必须为大于0的整数！';
$it618_wike_lang['s43'] = '知道了';
$it618_wike_lang['s44'] = '抱歉，承接任务截止时间要大于现在时间！';
$it618_wike_lang['s45'] = '任务发布成功！';
$it618_wike_lang['s46'] = '抱歉，此任务删除或不存在！';
$it618_wike_lang['s47'] = '抱歉，此承接会员退出或不存在！';
$it618_wike_lang['s48'] = '抱歉，此任务已完成，不能修改！';
$it618_wike_lang['s49'] = '任务修改成功！';
$it618_wike_lang['s50'] = '任务圆满完成成功！';
$it618_wike_lang['s51'] = '抱歉，当任务是开放承接时，承接任务截止时间要大于现在时间！';
$it618_wike_lang['s52'] = '报名交稿状态修改成功！';
$it618_wike_lang['s53'] = '抱歉，承接人的付款数为0时不可删除！';
$it618_wike_lang['s54'] = '承接人批量删除成功！';
$it618_wike_lang['s55'] = '抱歉，付款金额必须大于0的整数！';
$it618_wike_lang['s56'] = '<font style="color:red">工作中 已停止报名交稿</font>';
$it618_wike_lang['s57'] = '<font style="color:#390">任务已圆满完成</font>';
$it618_wike_lang['s58'] = '工作中';
$it618_wike_lang['s59'] = '开放承接';
$it618_wike_lang['s60'] = '报名截止时间：';
$it618_wike_lang['s61'] = '修改任务';
$it618_wike_lang['s62'] = '点击任务圆满完成后就不能操作任务了，请注意此操作不可逆，确定完成？';
$it618_wike_lang['s63'] = '报名截止时间：';
$it618_wike_lang['s64'] = '删除';
$it618_wike_lang['s65'] = '请注意此操作不可逆，确定删除？';
$it618_wike_lang['s66'] = '设置任务为报名交稿状态时，报名交稿截止时间要大于现在时间！';
$it618_wike_lang['s67'] = '预算金额不能大于您的现有';
$it618_wike_lang['s68'] = '数！';
$it618_wike_lang['s69'] = '用户组提成未设置，请与管理员联系！';
$it618_wike_lang['s70'] = '设置提交成功！';
$it618_wike_lang['s71'] = '用户组提成与发布人报名费权限设置';
$it618_wike_lang['s72'] = '导入(更新)用户组';
$it618_wike_lang['s73'] = '发布提成数/提成';
$it618_wike_lang['s74'] = '承接提成数/提成';
$it618_wike_lang['s75'] = '全部提成数/提成';
$it618_wike_lang['s76'] = '用户组';
$it618_wike_lang['s77'] = '发布提成比率';
$it618_wike_lang['s78'] = '承接提成比率';
$it618_wike_lang['s79'] = '发布提成数/提成';
$it618_wike_lang['s80'] = '承接提成数/提成';
$it618_wike_lang['s81'] = '提交';
$it618_wike_lang['s82'] = '<font color=#f60>推荐分期付款</font> 批量操作：';
$it618_wike_lang['s83'] = '任务人数最少为1！';
$it618_wike_lang['s84'] = '任务发布成功！';
$it618_wike_lang['s85'] = '任务人数不能少于当前承接人数！任务人数至少为';
$it618_wike_lang['s86'] = '条件格式(不填表示所有)：版块ID | 主题分类ID | 任务状态(所有=0,进行中=1,已完成=2) 多个ID请用逗号,隔开';
$it618_wike_lang['s87'] = '预算可追加修改';
$it618_wike_lang['s88'] = '任务修改成功！';
$it618_wike_lang['s89'] = '此模式预算可追加修改';
$it618_wike_lang['s90'] = '抱歉，请在总付款金额等于预算金额后，再点完成任务！';
$it618_wike_lang['s91'] = '任务圆满完成成功！';
$it618_wike_lang['s92'] = '任务人数已满，请与发布人联系！';
$it618_wike_lang['s93'] = '任务预计人数：';
$it618_wike_lang['s94'] = '确定要发布任务？请注意任务发布后任务预算金额不可修改！';
$it618_wike_lang['s95'] = '请注意任务发布后预算不可修改！';
$it618_wike_lang['s96'] = '确定要发布任务？请注意任务发布后任务预算金额只可修改';
$it618_wike_lang['s97'] = '请注意任务发布后预算只可修改';
$it618_wike_lang['s98'] = '次！';
$it618_wike_lang['s99'] = '您确定要给此承接人付款？推荐分多次付款，付款后金额是直接转给承接会员的，并且不能修改，此操作不可逆！';
$it618_wike_lang['s100'] = '被选主题(编号：';
$it618_wike_lang['s101'] = '任务有人承接了或任务未完成时，不能删除！注意：只有任务是完成状态才可以被删除，因为任务圆满完成了有冻结金的会返还冻结金。';
$it618_wike_lang['s102'] = '您确定要批量付款？推荐分多次批量付款，付款后金额是直接转给承接会员的，并且不能修改，此操作不可逆！';
$it618_wike_lang['s103'] = '任务统计';
$it618_wike_lang['s104'] = '查找';
$it618_wike_lang['s105'] = '任务名称：';
$it618_wike_lang['s106'] = '预算积分：';
$it618_wike_lang['s107'] = '付款积分：';
$it618_wike_lang['s108'] = '任务人数：';
$it618_wike_lang['s109'] = '承接人数：';
$it618_wike_lang['s110'] = '发布提成：';
$it618_wike_lang['s111'] = '承接提成：';
$it618_wike_lang['s112'] = '发布人ID：';
$it618_wike_lang['s113'] = '状态：';
$it618_wike_lang['s114'] = '--任务状态--';
$it618_wike_lang['s115'] = '已完成';
$it618_wike_lang['s116'] = '工作中';
$it618_wike_lang['s117'] = '工作中(报名结束)';
$it618_wike_lang['s118'] = '排序：';
$it618_wike_lang['s119'] = '按倒序';
$it618_wike_lang['s120'] = '按正序';
$it618_wike_lang['s121'] = '按发布时间';
$it618_wike_lang['s122'] = '按预算积分';
$it618_wike_lang['s123'] = '按付款积分';
$it618_wike_lang['s124'] = '按任务人数';
$it618_wike_lang['s125'] = '按承接人数';
$it618_wike_lang['s126'] = '按发布提成';
$it618_wike_lang['s127'] = '按承接提成';
$it618_wike_lang['s128'] = '按浏览数';
$it618_wike_lang['s129'] = '发布时间：';
$it618_wike_lang['s130'] = '任务数：';
$it618_wike_lang['s131'] = '预算/付款积分：';
$it618_wike_lang['s132'] = '任务/参与/承接人数：';
$it618_wike_lang['s133'] = '发布/承接提成：';
$it618_wike_lang['s134'] = '浏览数：';
$it618_wike_lang['s135'] = '任务名称';
$it618_wike_lang['s136'] = '预算/付款积分';
$it618_wike_lang['s137'] = '任务/参与/承接人数';
$it618_wike_lang['s138'] = '发布/承接提成';
$it618_wike_lang['s139'] = '浏览量';
$it618_wike_lang['s140'] = '状态';
$it618_wike_lang['s141'] = '发布人';
$it618_wike_lang['s142'] = '发布时间';
$it618_wike_lang['s143'] = '工作中';
$it618_wike_lang['s144'] = '报名结束';
$it618_wike_lang['s145'] = '已完成';
$it618_wike_lang['s146'] = '付款统计';
$it618_wike_lang['s147'] = '查找';
$it618_wike_lang['s148'] = '任务名称：';
$it618_wike_lang['s149'] = '付款积分：';
$it618_wike_lang['s150'] = '承接提成：';
$it618_wike_lang['s151'] = '发布人ID：';
$it618_wike_lang['s152'] = '承接人ID：';
$it618_wike_lang['s153'] = '状态：';
$it618_wike_lang['s154'] = '--任务状态--';
$it618_wike_lang['s155'] = '已完成';
$it618_wike_lang['s156'] = '工作中';
$it618_wike_lang['s157'] = '工作中(报名结束)';
$it618_wike_lang['s158'] = '排序：';
$it618_wike_lang['s159'] = '按倒序';
$it618_wike_lang['s160'] = '按正序';
$it618_wike_lang['s161'] = '排序：';
$it618_wike_lang['s162'] = '按付款时间';
$it618_wike_lang['s163'] = '按承接时间';
$it618_wike_lang['s164'] = '按付款积分';
$it618_wike_lang['s165'] = '按承接提成';
$it618_wike_lang['s166'] = '承接时间：';
$it618_wike_lang['s167'] = '付款时间：';
$it618_wike_lang['s168'] = '付款数：';
$it618_wike_lang['s169'] = '付款积分：';
$it618_wike_lang['s170'] = '承接提成：';
$it618_wike_lang['s171'] = '任务名称';
$it618_wike_lang['s172'] = '付款积分';
$it618_wike_lang['s173'] = '承接提成';
$it618_wike_lang['s174'] = '状态';
$it618_wike_lang['s175'] = '发布人';
$it618_wike_lang['s176'] = '承接人';
$it618_wike_lang['s177'] = '承接时间';
$it618_wike_lang['s178'] = '付款时间';
$it618_wike_lang['s179'] = '工作中';
$it618_wike_lang['s180'] = '报名结束';
$it618_wike_lang['s181'] = '已完成';
$it618_wike_lang['s182'] = '您所有用户组没有发布任务权限！';
$it618_wike_lang['s183'] = '任务圆满完成进度设置成功！';
$it618_wike_lang['s184'] = '<font color=red>注意会冻结相同预算数的{creditname}，不过任务圆满完成时自动解冻！</font>';
$it618_wike_lang['s185'] = '承接保证金额：';
$it618_wike_lang['s186'] = '承接保证';
$it618_wike_lang['s187'] = '报名交稿此任务我交了';
$it618_wike_lang['s188'] = '保证金，任务圆满完成保证金返还！';
$it618_wike_lang['s189'] = '确定要报名交稿任务{ruxuan}？\n\n您要支付{bzmoney}保证金，网站会冻结这部分保证金！\n\n报名后您可能有以下操作：\n1、如果没有入选，可自主取消报名，保证金会退还！\n2、如果入选了，自己不想做任务，可以退出(退款+赔保证金)，保证金直接给雇主，自己的退赔次数(不良记录)会增加1次，如果双方有纠纷时，管理员有权强制您退出(退款+赔保证金)！\n3、任务圆满完成以后，保证金自动退还！';
$it618_wike_lang['s190'] = '确定要报名交稿任务{ruxuan}？\n\n您必须支付给雇主{bmmoney}报名费才可以参与任务，报名费不退还的，只有雇主或管理员删除报名或承接时报名费会退还！同时还需要支付{bzmoney}保证金，网站会冻结这部分保证金！\n\n报名后您可能有以下操作：\n1、如果没有入选，可自主取消报名，保证金会退还！\n2、如果入选了，自己不想做任务，可以退出(退款+赔保证金)，保证金直接给发布人，自己的退赔次数(不良记录)会增加1次，如果双方有纠纷时，管理员有权强制您退出(退款+赔保证金)！\n3、任务圆满完成以后，保证金自动退还！';
$it618_wike_lang['s191'] = '进度';
$it618_wike_lang['s192'] = '抱歉，您现有的<font color=red>{creditnum}</font>不够交<font color=red>{bzmoney}</font>保证金！';
$it618_wike_lang['s193'] = '抱歉，您现有的<font color=red>{creditnum}</font>不够交<font color=red>{bmmoney}</font>报名费+<font color=red>{bzmoney}</font>保证金！';
$it618_wike_lang['s194'] = '付款数不能为0！';
$it618_wike_lang['s195'] = '规则更新成功！';
$it618_wike_lang['s196'] = '任务规则';
$it618_wike_lang['s197'] = '更新规则';
$it618_wike_lang['s198'] = '支持HTML代码
<br><font color=red>{creditname}</font> 代表任务积分名称
<br><font color=red>{mincreditcount}</font> 代表发布任务最需最少积分数';
$it618_wike_lang['s199'] = '任务规则标题：';
$it618_wike_lang['s200'] = '任务预算应该大于0！';
$it618_wike_lang['s201'] = '您安装的it618任务悬赏威客没有设置任务积分类型，请到插件后台设置一下！';
$it618_wike_lang['s202'] = '抱歉，统计需要的数据库视图没有安装成功，请咨询空间技术，看空间是否没有创建视图的权限！也可以加IT618插件售后群联系！';
$it618_wike_lang['s203'] = '抱歉，您所在的用户组没有承接任务权限！';
$it618_wike_lang['s204'] = '抱歉，此任务现在不可承接状态，请与发布人联系！';
$it618_wike_lang['s205'] = '任务删除成功，如果有这几种情况(1、发布人冻结金2、承接人保证金3、发布人已付款了承接人的积分)，都会自动恢复还原！最好把此任务的帖子也删除！';
$it618_wike_lang['s206'] = '任务删除成功，最好把此任务的帖子也删除！';
$it618_wike_lang['s207'] = '抱歉，您所在的用户组没有删除任务的权限！';
$it618_wike_lang['s208'] = '任务删除后就不可恢复了，如果任务有冻结金或保证金会自动返还给发布人或承接人，最好任务删除后，把帖子也删除，确定要删除任务吗？';
$it618_wike_lang['s209'] = '您有';
$it618_wike_lang['s210'] = '被冻结，不可使用，任务圆满完成后自动返还冻结金！';
$it618_wike_lang['s211'] = '服务费：';
$it618_wike_lang['s212'] = '您所在的';
$it618_wike_lang['s213'] = '用户组发布任务 需要额外支付( <font color=red>预算金额</font> * <font color=red>';
$it618_wike_lang['s214'] = '%</font> ) 的服务费！';
$it618_wike_lang['s215'] = '用户组承接任务 需要额外支付( <font color=red>收入</font> * <font color=red>';
$it618_wike_lang['s216'] = '%</font> ) 的服务费！';
$it618_wike_lang['s217'] = '您的当前';
$it618_wike_lang['s218'] = '如果支付了服务费后就会成负数，也就是不够';
$it618_wike_lang['s219'] = '来完成任务，请先充值！';
$it618_wike_lang['s220'] = '宽度：';
$it618_wike_lang['s221'] = '用于调整布局，当帖子页宽度不够时，宽度可以调小';
$it618_wike_lang['s222'] = '平分模式';
$it618_wike_lang['s223'] = '分期模式';
$it618_wike_lang['s224'] = '付款模式';
$it618_wike_lang['s225'] = '提示';
$it618_wike_lang['s226'] = '承接信息';
$it618_wike_lang['s227'] = '抱歉，没有人承接时不能完成任务！';
$it618_wike_lang['s228'] = '任务付款模式：';
$it618_wike_lang['s229'] = '承接人批量删除成功，有部分承接人已入选，只能管理员有权限删除！';
$it618_wike_lang['s230'] = '任务圆满完成时自动付款';
$it618_wike_lang['s231'] = '任务修改成功！';
$it618_wike_lang['s232'] = '分期';
$it618_wike_lang['s233'] = '平分';
$it618_wike_lang['s234'] = '注意：付款后不可修改与删除';
$it618_wike_lang['s235'] = '入选成功！';
$it618_wike_lang['s236'] = '抱歉，入选人数已经达到预计任务人数，请先修改预计人数！';
$it618_wike_lang['s237'] = '任务可见权限：';
$it618_wike_lang['s238'] = '所有人可见';
$it618_wike_lang['s239'] = '报名人可见';
$it618_wike_lang['s240'] = '承接人可见';
$it618_wike_lang['s241'] = '任务内容';
$it618_wike_lang['s242'] = '共有';
$it618_wike_lang['s243'] = '人报名交稿';
$it618_wike_lang['s244'] = '承接入选模式：';
$it618_wike_lang['s245'] = '审核入选';
$it618_wike_lang['s246'] = '自动入选';
$it618_wike_lang['s247'] = '确定要入选此会员？注意入选后不能删除此承接人，只能找管理员删除！';
$it618_wike_lang['s248'] = '提示：会员名为红色字体时，表示发布人已选择此会员接任务了';
$it618_wike_lang['s249'] = '您';
$it618_wike_lang['s250'] = '技巧方法';
$it618_wike_lang['s251'] = '手机版主图标导航';
$it618_wike_lang['s252'] = '已付款积分：';
$it618_wike_lang['s253'] = '任务信息/统计';
$it618_wike_lang['s254'] = '悬赏模式';
$it618_wike_lang['s255'] = '平分模式';
$it618_wike_lang['s256'] = '分期模式';
$it618_wike_lang['s257'] = '任务单价金额：';
$it618_wike_lang['s258'] = '已付款：';
$it618_wike_lang['s259'] = '悬赏/已悬赏/承接人数：';
$it618_wike_lang['s260'] = '任务预算：';
$it618_wike_lang['s261'] = '任务/承接/报名人数：';
$it618_wike_lang['s262'] = '抱歉，任务单价必须是大于0的整数！';
$it618_wike_lang['s263'] = '抱歉，悬赏人数要大于0！';
$it618_wike_lang['s264'] = '抱歉，(任务单价*悬赏人数+服务费)不能大于您的现有';
$it618_wike_lang['s265'] = '抱歉，您无权操作！';
$it618_wike_lang['s266'] = '抱歉，修改任务时悬赏人数不能小于已悬赏人数！';
$it618_wike_lang['s267'] = '抱歉，您现有的';
$it618_wike_lang['s268'] = '，不够用于(增加的悬赏人数*任务单价)！';
$it618_wike_lang['s269'] = '抱歉，已悬赏人数必须等于您设置任务悬赏人数 {mancount}，才可以完成任务！如果实在想完成任务，请先修改任务悬赏人数值为已悬赏人数 {curmancount}，这样多余部分的冻结预算也可以自动退还给您，修改好了再点完成任务！';
$it618_wike_lang['s270'] = '抱歉，发布人设定的悬赏人数都悬赏了，如果发布人没点完成任务，可以与发布人联系再增加悬赏人数！';
$it618_wike_lang['s271'] = '抱歉，任务已完成不能操作！';
$it618_wike_lang['s272'] = '悬赏并付款成功！';
$it618_wike_lang['s273'] = '<font color=red><b>悬赏模式</b>：</font><span id="wike_mode3"><br>
1、雇主发布任务时设置任务单价与任务人数，平台冻结任务单价*任务人数+服务费<br>
2、任务单价是不能修改的，人数修改时不能小于已悬赏人数，并且减少人数时是不退减少部分服务费的<br>
3、点完成任务前任务人数必须与已悬赏人数相同，如果实在想完成任务，可以先修改任务人数再点完成任务<br>
4、雇主服务费在设置任务单价和人数时扣<br>
5、接手服务费在雇主付款时扣</span>';
$it618_wike_lang['s274'] = '<font color=red><b>平分模式</b>：</font><span id="wike_mode2"><br>
1、雇主发布任务时设置预算金额与任务人数，平台冻结预算金额+服务费<br>
2、预算金额是不能修改的，人数修改时不能小于已入选人数<br>
3、任务圆满完成时自动的平分冻结的预算金额给入选接手<br>
4、雇主服务费在设置预算金额时扣<br>
5、接手服务费在完成任务时扣</span>';
$it618_wike_lang['s275'] = '<font color=red><b>分期模式</b>：</font><span id="wike_mode1"><br>
1、雇主发布任务时设置预算金额与任务人数，平台冻结预算金额+服务费<br>
2、预算金额可追加修改，只能增加不能减少，人数修改时不能小于已入选人数<br>
3、雇主可以用冻结的预算金额，自由的给入选接手分期追加付款(有时一个任务分几期完成)，直到付款完就可以点完成任务了<br>
4、雇主服务费在设置预算金额时扣<br>
5、接手服务费在雇主付款时扣<br>
{wike_ismoneyedittip}</span>';
$it618_wike_lang['s276'] = '任务悬赏人数：';
$it618_wike_lang['s277'] = '悬赏模式';
$it618_wike_lang['s278'] = '指定接手会员：';
$it618_wike_lang['s279'] = '不填写时没限制，如要指定接手时，多个会员UID请用逗号隔开，如：1,2,3';
$it618_wike_lang['s280'] = '抱歉，您的预算冻结金额不够抵扣当前付款金额，请修改增大预算金额！';
$it618_wike_lang['s281'] = '抱歉，预算金额只能追加修改，不能小于修改前的预算金额！如果实在想修改，请与管理员联系！';
$it618_wike_lang['s282'] = '抱歉，任务雇主设置了指定会员报名，请与雇主联系！';
$it618_wike_lang['s283'] = '指定接手';
$it618_wike_lang['s284'] = '指定';
$it618_wike_lang['s285'] = '附件/留言';
$it618_wike_lang['s286'] = '已奖励雇主';
$it618_wike_lang['s287'] = '查看个人信息';
$it618_wike_lang['s288'] = '我的钱包 -> {creditsname}充值';
$it618_wike_lang['s289'] = '我现有';
$it618_wike_lang['s290'] = '已悬赏并付款';
$it618_wike_lang['s291'] = '当前任务模式是';
$it618_wike_lang['s292'] = '任务单价';
$it618_wike_lang['s293'] = '悬赏人数';
$it618_wike_lang['s294'] = '人承接';
$it618_wike_lang['s295'] = '<font color=#390>现在可以报名交稿</font>';
$it618_wike_lang['s296'] = '被冻结';
$it618_wike_lang['s297'] = '请输入您要搜索的任务名称关键词...';
$it618_wike_lang['s298'] = '我的可用';
$it618_wike_lang['s299'] = '此操作不可逆，确定要悬赏此承接人，并且付款';
$it618_wike_lang['s300'] = '还能悬赏';
$it618_wike_lang['s301'] = '每人可平均分配';
$it618_wike_lang['s302'] = '等待承接人(入选)';
$it618_wike_lang['s303'] = '抱歉，发布人设定的悬赏人数都悬赏了，不能再悬赏了，可以修改任务再增加悬赏人数！';
$it618_wike_lang['s304'] = '抱歉，这些主题(主题编号：';
$it618_wike_lang['s305'] = ')有任务不能删除！如果确实要删除主题，请先删除主题对应的任务！';
$it618_wike_lang['s306'] = '抱歉，此主题有任务不能删除！如果确实要删除主题，请先删除主题对应的任务！';
$it618_wike_lang['s307'] = '报名人数：';
$it618_wike_lang['s308'] = '报名人数(入选)：';
$it618_wike_lang['s309'] = '任务预计人数：';
$it618_wike_lang['s310'] = '承接人数：';
$it618_wike_lang['s311'] = '已悬赏人数：';
$it618_wike_lang['s312'] = '任务悬赏人数：';
$it618_wike_lang['s313'] = '分期';
$it618_wike_lang['s314'] = '平分';
$it618_wike_lang['s315'] = '悬赏';
$it618_wike_lang['s316'] = '悬赏后付款';
$it618_wike_lang['s317'] = '？';
$it618_wike_lang['s318'] = '：';
$it618_wike_lang['s319'] = '(预算金额+服务费)不能大于您的现有';
$it618_wike_lang['s320'] = '注意：任务发布或承接时，当时的任务提成会根据当时发布人或承接人所在的用户组确定并记录下来，不会因为任务进行时会员的用户组变动，影响提成计算';
$it618_wike_lang['s321'] = '抱歉，管理员还没有设置服务费提成，请与管理员联系！';
$it618_wike_lang['s322'] = '抱歉，您发布的任务还有';
$it618_wike_lang['s323'] = '个未完成，每个会员最多只能有';
$it618_wike_lang['s324'] = '个未完成任务，超过了就不能再发布任务了，请先完成未完成的任务！';
$it618_wike_lang['s325'] = '抱歉，悬赏人数要大于0！';
$it618_wike_lang['s326'] = '抱歉，您承接的任务还有';
$it618_wike_lang['s327'] = '个未完成任务，超过了就不能再承接任务了，请联系发布人完成任务！';
$it618_wike_lang['s328'] = '任务圆满完成以后 您要支付( <font color=red>预算金额</font> * <font color=red>';
$it618_wike_lang['s329'] = '雇主付款以后 您要支付( <font color=red>收入</font> * <font color=red>';
$it618_wike_lang['s330'] = '抱歉，还没有可以发布任务的版块，请与管理员联系！';
$it618_wike_lang['s331'] = '个任务';
$it618_wike_lang['s332'] = '承接了任务';
$it618_wike_lang['s333'] = '通过';
$it618_wike_lang['s334'] = '已收入';
$it618_wike_lang['s335'] = '任务类别：';
$it618_wike_lang['s336'] = '已收入：';
$it618_wike_lang['s337'] = '已支出：';
$it618_wike_lang['s338'] = '任务个数：';
$it618_wike_lang['s339'] = '任务预算：';
$it618_wike_lang['s340'] = '任务类别';
$it618_wike_lang['s341'] = '所有大类';
$it618_wike_lang['s342'] = '所有小类';
$it618_wike_lang['s343'] = '天前';
$it618_wike_lang['s344'] = '小时前';
$it618_wike_lang['s345'] = '分钟前';
$it618_wike_lang['s346'] = '秒前';
$it618_wike_lang['s347'] = '发布会员';
$it618_wike_lang['s348'] = '发布';
$it618_wike_lang['s349'] = '承接';
$it618_wike_lang['s350'] = '报名会员';
$it618_wike_lang['s351'] = '统计信息';
$it618_wike_lang['s352'] = '支付信息';
$it618_wike_lang['s353'] = '收入';
$it618_wike_lang['s354'] = '收入:';
$it618_wike_lang['s355'] = '进度:';
$it618_wike_lang['s356'] = '抱歉，入选后不能删除此承接人，只能找管理员删除！';
$it618_wike_lang['s357'] = '此承接人删除成功！';
$it618_wike_lang['s358'] = '更新成功！(成功修改数:';
$it618_wike_lang['s359'] = '成功添加数:';
$it618_wike_lang['s360'] = '成功删除数:';
$it618_wike_lang['s361'] = '手机版风格设置';
$it618_wike_lang['s362'] = '风格数：';
$it618_wike_lang['s363'] = '整体颜色';
$it618_wike_lang['s364'] = '个人中心页头渐变色';
$it618_wike_lang['s365'] = '默认风格';
$it618_wike_lang['s366'] = '首页公告管理';
$it618_wike_lang['s367'] = '公告数：';
$it618_wike_lang['s368'] = '注意：此公告同时也会显示在手机版首页，排序为0时不显示';
$it618_wike_lang['s369'] = '标题';
$it618_wike_lang['s370'] = '链接';
$it618_wike_lang['s371'] = '文字是否粗体';
$it618_wike_lang['s372'] = '排序';
$it618_wike_lang['s373'] = '文字颜色(无突出效果时要为空)';
$it618_wike_lang['s374'] = '退出';
$it618_wike_lang['s375'] = '我的';
$it618_wike_lang['s376'] = '我的钱包';
$it618_wike_lang['s377'] = '发布任务';
$it618_wike_lang['s378'] = '我发布的任务';
$it618_wike_lang['s379'] = '我参与的任务';
$it618_wike_lang['s380'] = '登录';
$it618_wike_lang['s381'] = '注册';
$it618_wike_lang['s382'] = '搜索';
$it618_wike_lang['s383'] = '导航';
$it618_wike_lang['s384'] = '任务首页';
$it618_wike_lang['s385'] = '网站首页';
$it618_wike_lang['s386'] = '查看更多任务';
$it618_wike_lang['s387'] = '最新任务';
$it618_wike_lang['s388'] = '推荐任务';
$it618_wike_lang['s389'] = '人气任务';
$it618_wike_lang['s390'] = '更新成功！';
$it618_wike_lang['s391'] = '更新';
$it618_wike_lang['s392'] = '任务电脑版首页';
$it618_wike_lang['s393'] = '任务手机版页面';
$it618_wike_lang['s394'] = '伪静态设置';
$it618_wike_lang['s395'] = '搜索任务';
$it618_wike_lang['s396'] = '全部';
$it618_wike_lang['s397'] = '任务类别:';
$it618_wike_lang['s398'] = '任务预算:';
$it618_wike_lang['s399'] = '任务名称:';
$it618_wike_lang['s400'] = '搜索';
$it618_wike_lang['s401'] = '发布会员:';
$it618_wike_lang['s402'] = '承接会员:';
$it618_wike_lang['s403'] = '提示:会员编号';
$it618_wike_lang['s404'] = '任务状态:';
$it618_wike_lang['s405'] = '全部状态';
$it618_wike_lang['s406'] = '报名中';
$it618_wike_lang['s407'] = '已完成';
$it618_wike_lang['s408'] = '报名中';
$it618_wike_lang['s409'] = '回帖可见权限：';
$it618_wike_lang['s410'] = '关闭';
$it618_wike_lang['s411'] = '上一页';
$it618_wike_lang['s412'] = '下一页';
$it618_wike_lang['s413'] = '排行统计';
$it618_wike_lang['s414'] = '点击可以切换推荐状态';
$it618_wike_lang['s415'] = '推荐';
$it618_wike_lang['s416'] = '任务推荐状态修改成功！';
$it618_wike_lang['s417'] = '个';
$it618_wike_lang['s418'] = '我的钱包';
$it618_wike_lang['s419'] = '设置';
$it618_wike_lang['s420'] = '我的设置';
$it618_wike_lang['s421'] = '抱歉，预算金额不能小于已付金额 {yfmoney}！';
$it618_wike_lang['s436'] = 'URL 静态化可以提高搜索引擎抓取，开启本功能需要对 Web 服务器增加相应的 Rewrite 支持，且会轻微增加服务器负担。同时您还可以调整每个页面的静态格式，但不得删除其中的标记，重置静态格式请留空。<br><font color=red>注意，修改静态格式后您需要修改服务器的 Rewrite 规则设置，并且要把DZ默认的插件规则删除或放最后一行，此插件规则才有效果</font>';
$it618_wike_lang['s437'] = '静态格式扩展名：';
$it618_wike_lang['s438'] = '页面';
$it618_wike_lang['s439'] = '标记';
$it618_wike_lang['s440'] = '格式';
$it618_wike_lang['s448'] = 'Apache Web Server(独立主机用户)';
$it618_wike_lang['s449'] = 'Apache Web Server(虚拟主机用户)';
$it618_wike_lang['s450'] = '# 将 RewriteEngine 模式打开
RewriteEngine On

# 修改以下语句中的 /discuz 为您的论坛目录地址，如果程序放在根目录中，请将 /discuz 修改为 /
RewriteBase /discuz

# Rewrite 系统规则请勿修改';
$it618_wike_lang['s451'] = 'IIS Web Server(独立主机用户)';
$it618_wike_lang['s452'] = 'IIS7 Web Server(独立主机用户)';
$it618_wike_lang['s453'] = '有人承接时';
$it618_wike_lang['s454'] = '我入选时';
$it618_wike_lang['s455'] = '我到款时';
$it618_wike_lang['s456'] = '有人发布时';
$it618_wike_lang['s457'] = '系统消息提醒功能：';
$it618_wike_lang['s458'] = '表示网站已开通此短信服务';
$it618_wike_lang['s459'] = '管理员暂时还没有开通短信接口功能！';
$it618_wike_lang['s460'] = '启用消息提醒功能：';
$it618_wike_lang['s461'] = '如果不开启不会有短信提醒';
$it618_wike_lang['s462'] = '手机号码：';
$it618_wike_lang['s463'] = '有提醒时此手机号就会收到短信';
$it618_wike_lang['s464'] = '更新';
$it618_wike_lang['s465'] = '我的消息提醒设置：';
$it618_wike_lang['s466'] = '分期';
$it618_wike_lang['s467'] = '平分';
$it618_wike_lang['s468'] = '悬赏';
$it618_wike_lang['s469'] = '参数名称';
$it618_wike_lang['s470'] = '参数内容';
$it618_wike_lang['s471'] = '提示：最多支持9个微信消息模板参数，参数名称比如是：first,keyword1,keyword2,keyword3,...,remark，参数内容支持以上一个标签或多个标签';
$it618_wike_lang['s472'] = '取消';
$it618_wike_lang['s473'] = '保存';
$it618_wike_lang['s474'] = '抱歉，如果参数名称填写了，就必须填写参数内容！';
$it618_wike_lang['s475'] = '抱歉，当前任务预算金额不能小于';
$it618_wike_lang['s476'] = '抱歉，当前任务单价不能小于';
$it618_wike_lang['s477'] = '！';
$it618_wike_lang['s478'] = '未读';
$it618_wike_lang['s500'] = '当前任务模式说明：';
$it618_wike_lang['s501'] = '分期模式';
$it618_wike_lang['s502'] = '平分模式';
$it618_wike_lang['s503'] = '悬赏模式';
$it618_wike_lang['s504'] = '付款数就是任务单价，悬赏人数还可以根据需要再增加，(任务单价*悬赏人数+服务费)会被冻结，悬赏付款的积分来自冻结金，并且积分是直接转给承接人的同时退还承接人的保证金，悬赏次数等于悬赏人数时才可以完成任务，任务圆满完成时退还未悬赏承接人的保证金';
$it618_wike_lang['s505'] = '付款数是根据预算上限和承接人数自动平均分配的，(预算上限+服务费)会被冻结，但是在点任务圆满完成时才自动付款给承接人的，并且付款是来自冻结金，任务圆满完成时退还保证金';
$it618_wike_lang['s506'] = '付款数任务没完成时可以自由设置，预算上限会被冻结，但是付款的积分不是冻结金里的，所以预算被冻结后，要有足够的积分付款，任务圆满完成时退还冻结金和保证金，{wike_ismoneyedittip}';
$it618_wike_lang['s511'] = '启用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_wike_lang['s512'] = '消息提醒设置更新成功！';
$it618_wike_lang['s513'] = '<strong>第三方短信接口，按短信条数收费，给第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注册账号并充值，然后填以下内容就可以了';
$it618_wike_lang['s514'] = '启用消息接口：';
$it618_wike_lang['s515'] = '如果不启用，系统不会有消息提醒功能 <font color=blue>如果安装了【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】就会支持微信模板消息，微信模板ID不为空时，优先发微信模板消息，而不发短信</font>';
$it618_wike_lang['s516'] = '短信接口账号：';
$it618_wike_lang['s517'] = '短信接口密码：';
$it618_wike_lang['s518'] = '测试接收人手机号：';
$it618_wike_lang['sn'] = '';
$it618_wike_lang['it618']='iililil1111illiilililliilil1111ililil1ililiiil111ililililili1111il1111111111ii1111111111li111lilili111ililil11111111i1l11i11lli1ii11';
$it618_wike_lang['s519'] = '多个手机号用英文字母逗号隔开';
$it618_wike_lang['s520'] = '测试短信内容：';
$it618_wike_lang['s521'] = '管理员手机号：';
$it618_wike_lang['s522'] = '如果不启用，管理员不会有消息提醒';
$it618_wike_lang['s523'] = '消息模板';
$it618_wike_lang['s524'] = '注意：消息模板只有在“启用”状态，才发送提醒消息，如果短信消息模板和微信消息模板都设置了，优先发送微信消息，发送成功了，就不发短信了，方便节省短信成本';
$it618_wike_lang['s525'] = '<font color="green">任务发布时 - <font color="green">管理员消息模板</font></font>';
$it618_wike_lang['s526'] = '<font color="#999999">示例：会员${user} 在${time}发布了一个预算为${money}人数为${mancount}名称为${name}的${mode}任务！
<br>标签说明：{user}发布会员，{time}发布时间，{money}预算，{mancount}任务人数，{mode}任务模式，{name}任务名称</font>';
$it618_wike_lang['s527'] = '<font color="green">任务圆满完成时</font> - <font color="green">管理员消息模板</font></font>';
$it618_wike_lang['s528'] = '<font color="#999999">示例：会员${user} 在${time}完成了任务${name}！ <br>标签说明：{user}发布会员，{time}完成时间，{name}任务名称</font>';
$it618_wike_lang['s529'] = '<font color="green">会员承接时</font> - <font color="blue">发布人消息模板</font></font>';
$it618_wike_lang['s530'] = '<font color="#999999">示例：会员${user} 在${time}承接了任务${name}！ <br>标签说明：{user}承接会员，{time}承接时间，{name}任务名称</font>';
$it618_wike_lang['s531'] = '<font color="green">入选时</font> - <font color="red">承接人消息模板</font></font>';
$it618_wike_lang['s532'] = '<font color="#999999">示例：您成功入选了，任务名称${name}！ <br>标签说明：{user}承接会员，{name}任务名称</font>';
$it618_wike_lang['s533'] = '<font color="green">付款时</font> - <font color="red">承接人消息模板</font></font>';
$it618_wike_lang['s534'] = '<font color="#999999">示例：发布人给您${mode}付款了${money}，任务名称${name}！ <br>标签说明：{user}承接会员，{mode}付款模式(返回：分期、平分、悬赏)，{money}付款数，{name}任务名称</font>';
$it618_wike_lang['s535'] = '更新成功！';
$it618_wike_lang['s536'] = '首页';
$it618_wike_lang['s537'] = '<font color="green">任务圆满完成时 - <font color="red">承接人消息模板</font></font>';
$it618_wike_lang['s538'] = '<font color="#999999">示例：您承接的任务已完成，任务名称${name}！ <br>标签说明：{user}承接会员，{name}任务名称</font>';
$it618_wike_lang['s539'] = '"0" => "短信发送成功",
"-1" => "参数不全",
"-2" => "服务器空间不支持,请确认支持curl或者fsocket，联系您的空间商解决或者更换空间！",
"30" => "密码错误",
"40" => "账号不存在",
"41" => "余额不足",
"42" => "帐户已过期",
"43" => "IP地址限制",
"50" => "内容含有敏感词';
$it618_wike_lang['s540'] = '<font color=#999>我的会员编号:</font>';
$it618_wike_lang['s541'] = '更新';
$it618_wike_lang['s542'] = '更新时发送一个测试短信';
$it618_wike_lang['s543'] = '（注意：雇主设置了不需审核自动入选）';
$it618_wike_lang['s544'] = '成功发送一条短信需要消耗收短信会员积分数：';
$it618_wike_lang['s545'] = '搜索任务';
$it618_wike_lang['s546'] = '任务大厅';
$it618_wike_lang['s547'] = '抱歉，此任务模式任务人数最多只能设置为';
$it618_wike_lang['s548'] = 'QQ 号：';
$it618_wike_lang['s549'] = '我的个人信息设置：';
$it618_wike_lang['s550'] = '开启消息提醒功能';
$it618_wike_lang['s551'] = '微信号：';
$it618_wike_lang['s552'] = '备注(联系地址等重要信息)：';
$it618_wike_lang['s553'] = '手机号：';
$it618_wike_lang['s554'] = '个人信息';
$it618_wike_lang['s555'] = '抱歉，参数有误！';
$it618_wike_lang['s556'] = '抱歉，您没有查看权限！';
$it618_wike_lang['s557'] = '手机版风格设置';
$it618_wike_lang['s558'] = '手机版底部导航';
$it618_wike_lang['s559'] = '提示：{waphome}表示首页链接，{wapsearch}表示搜索链接，{wappost}表示任务发布功能';
$it618_wike_lang['s560'] = '上传图片';
$it618_wike_lang['s561'] = '仅雇主可见';
$it618_wike_lang['s562'] = '仅任务雇主可以看此回复内容';
$it618_wike_lang['s563'] = '我要发布任务 ';
$it618_wike_lang['s564'] = '确定要报名交稿任务？\n\n您要支付{bzmoney}保证金，网站会冻结这部分保证金！\n\n报名后您可能有以下操作：\n1、自己不想做任务，可以退出(退款+赔保证金)，保证金直接给雇主，自己的退赔次数(不良记录)会增加1次，如果双方有纠纷时，管理员有权强制您退出(退款+赔保证金)！\n2、雇主给您悬赏付款时，保证金会自动退还！\n3、如果雇主没有给您悬赏付款，任务圆满完成以后，保证金也会自动退还！';
$it618_wike_lang['s565'] = '确定要报名交稿任务？\n\n您必须支付给雇主{bmmoney}报名费才可以参与任务，报名费不退还的，只有雇主或管理员删除报名或承接时报名费会退还！同时还需要支付{bzmoney}保证金，网站会冻结这部分保证金！\n\n报名后您可能有以下操作：\n1、自己不想做任务，可以退出(退款+赔保证金)，保证金直接给雇主，自己的退赔次数(不良记录)会增加1次，如果双方有纠纷时，管理员有权强制您退出(退款+赔保证金)！\n2、雇主给您悬赏付款时，保证金会自动退还！\n3、如果雇主没有给您悬赏付款，任务圆满完成以后，保证金也会自动退还！';
$it618_wike_lang['s566'] = '报名交稿的会员可以看此回复内容';
$it618_wike_lang['s567'] = '入选承接的会员可以看此回复内容';
$it618_wike_lang['s568'] = '抱歉，预算追加部分再加上这部分服务费需要{num1}，您现有{num2}不够！';
$it618_wike_lang['s569'] = '关闭此窗口 返回管理附件(或图片)与留言';
$it618_wike_lang['s570'] = '下载附件(浏览图片)';
$it618_wike_lang['s571'] = '任务信息';
$it618_wike_lang['s572'] = '需求描述';
$it618_wike_lang['s573'] = '退出';
$it618_wike_lang['s574'] = '抱歉，已悬赏人数必须大于0！';
$it618_wike_lang['s575'] = '抱歉，发布任务前需要进行个人实名认证！';
$it618_wike_lang['s576'] = '点击现在申请认证';
$it618_wike_lang['s577'] = '抱歉，承接任务前需要进行个人实名认证！';
$it618_wike_lang['s578'] = '帖子回复';
$it618_wike_lang['s579'] = '入选模式';
$it618_wike_lang['s580'] = '没有限制';
$it618_wike_lang['s581'] = '名词解释与规则说明：<br><b>保证金</b><br>
1、平台给雇主一个保障功能，如果雇主设置了保证金，接手必须先交纳保证金，保证金冻结由平台保管<br>
2、如果未入选时，接手自己取消报名，保证金自动退还给接手<br>
3、如果未入选时，雇主删除报名，保证金自动退还给接手<br>
4、如果已入选时，接手自主退赔，保证金直接给雇主<br>
5、如果已入选时，管理员强制退赔，保证金直接给雇主<br>
6、如果是分期与平分模式，任务圆满完成时保证金自动退还保证金给接手，悬赏模式时悬赏时自动退还保证金给接手<br>

<br><b>报名费</b><br>
1、平台给雇主一个创收功能，如果雇主设置了报名费，接手必须先交纳报名费，报名费直接给雇主<br>
2、如果未入选时，接手自己取消报名，报名费不退还给接手<br>
3、如果未入选时，雇主删除报名，报名费自动退还给接手<br>
4、如果已入选时，接手自主退赔，报名费不退还给接手<br>
5、如果已入选时，管理员强制退赔，报名费不退还给接手<br>
6、如果任务圆满完成时，报名费不退还给接手<br>

<br><b>退赔机制</b><br>
由于接手入选后，是不能删除的，如果接手由于一些主观或客观原因不能正常完成任务，接手自己可以主动退赔，就是退出并且赔保证金给雇主，如果双方
纠纷了管理员可以介入强制退赔，这样雇主可以重新选人完成任务<br>

<br><b>管理员调解</b><br>
为了方便调解双方纠纷，管理员可以管理所有任务，如：修改任务设置、审核入选、付款悬赏、强制退赔、完成任务与删除任务等，删除任务后只退剩余冻结金额，雇主服务费不退还，而且雇主已付款金额不处理，已付款金额是雇主主动付款给接手的<br>

<br><b>入选模式</b><br>
1、平台给雇主一个选人功能，雇主可以设置自动审核与手工审核2种入选模式<br>
2、自动审核 接手报名后自动入选，雇主不能删除，接手要么主动退赔，要么管理员强制退赔<br>
3、手工审核 接手报名后需要雇主审核入选，没入选前接手可以自己取消报名，雇主也可以删除报名<br>

<br><b>信息保密</b><br>
1、平台给雇主一个保密功能，雇主可以设置需求信息与接手回复信息的可见权限<br>
2、需求信息 报名人可见、承接人可见与所有人可见<br>
3、回复信息 仅雇主可见、报名人可见、承接人可见与所有人可见<br>

<br><b>指定接手</b><br>
平台给雇主一个指定哪些会员可以承接任务的功能，这样方便不被打扰<br>

<br><b>报名入口</b><br>
平台给雇主一个报名入口功能，可以设置截止到什么时间可以报名，可以设置正在工作不能报名<br>';
$it618_wike_lang['s582'] = '发布任务冻结预算金额';
$it618_wike_lang['s583'] = '发布任务服务费';
$it618_wike_lang['s584'] = '修改任务冻结追加预算';
$it618_wike_lang['s585'] = '修改任务追加服务费';
$it618_wike_lang['s586'] = '雇主付款我收入';
$it618_wike_lang['s587'] = '雇主付款，我给服务费';
$it618_wike_lang['s588'] = '任务圆满完成平分后我收入';
$it618_wike_lang['s589'] = '任务圆满完成平分后，我给服务费';
$it618_wike_lang['s590'] = '雇主悬赏我收入';
$it618_wike_lang['s591'] = '雇主悬赏，我给服务费';
$it618_wike_lang['s592'] = '任务圆满完成雇主奖励';
$it618_wike_lang['s593'] = '任务报名保证金';
$it618_wike_lang['s594'] = '自主取消报名退还保证金';
$it618_wike_lang['s595'] = '雇主删除报名退还保证金';
$it618_wike_lang['s596'] = '接手自主退赔我收入保证金';
$it618_wike_lang['s597'] = '管理员强制退赔我收入保证金';
$it618_wike_lang['s598'] = '任务圆满完成退还保证金';
$it618_wike_lang['s599'] = '雇主悬赏退还保证金';
$it618_wike_lang['s600'] = '任务圆满完成我的奖励';
$it618_wike_lang['s601'] = '任务报名支付报名费';
$it618_wike_lang['s602'] = '雇主删除报名退还报名费';
$it618_wike_lang['s603'] = '接手报名收入报名费';
$it618_wike_lang['s604'] = '管理员删除任务退还未付款冻结金额';
$it618_wike_lang['s605'] = '管理员删除任务退还保证金';
$it618_wike_lang['s606'] = '减少悬赏人数退还金额';
$it618_wike_lang['s607'] = '增加悬赏人数冻结追加预算';
$it618_wike_lang['s608'] = '增加悬赏人数追加服务费';
$it618_wike_lang['s609'] = '雇主取消任务退还保证金';
$it618_wike_lang['s610'] = '雇主取消任务退还报名费';
$it618_wike_lang['s611'] = '自己取消任务退还冻结金额';
$it618_wike_lang['s612'] = '自己取消任务退还冻结服务费';
$it618_wike_lang['s613'] = '自己取消任务退还报名费';
$it618_wike_lang['s614'] = '自己删除报名退还报名费';
$it618_wike_lang['s673'] = '抱歉，任务为工作中状态，不能报名，请与雇主联系！';
$it618_wike_lang['s674'] = '抱歉，任务为已完成状态，不能报名，谢谢关注！';
$it618_wike_lang['s675'] = '当前版块同时支持积分与余额交易，请您选择一种交易方式！\n点确定是“余额”交易，点取消是“积分”交易';
$it618_wike_lang['s676'] = '导航数：';
$it618_wike_lang['s677'] = '注意：导航图标为了清晰，推荐宽高60到120，导航标题推荐最多4个字，排序为0时不显示';
$it618_wike_lang['s678'] = '图标';
$it618_wike_lang['s679'] = '标题';
$it618_wike_lang['s680'] = '链接';
$it618_wike_lang['s681'] = '新窗口';
$it618_wike_lang['s682'] = '文字颜色(无突出效果时要为空)';
$it618_wike_lang['s683'] = '文字粗体';
$it618_wike_lang['s684'] = '排序';
$it618_wike_lang['s685'] = '提交后再上传图片';
$it618_wike_lang['s686'] = '注意：任务大类图标链接是plugin.php?id=it618_wike:wap&pagetype=search&cid=1不是伪静态的，可以自己修改wike_wap-search-1.html，1就是论坛版块fid';
$it618_wike_lang['s687'] = '天';
$it618_wike_lang['s688'] = '小时';
$it618_wike_lang['s689'] = '预算';
$it618_wike_lang['s690'] = '悬赏';
$it618_wike_lang['s691'] = '人报名';
$it618_wike_lang['s692'] = '人入选';
$it618_wike_lang['s693'] = '还要';
$it618_wike_lang['s694'] = '人承接';
$it618_wike_lang['s695'] = '名额已满';
$it618_wike_lang['s696'] = '人已悬赏';
$it618_wike_lang['s697'] = '还要悬赏';
$it618_wike_lang['s698'] = '悬赏名额已满';
$it618_wike_lang['s699'] = '浏览';
$it618_wike_lang['s700'] = '人';
$it618_wike_lang['s701'] = '报名';
$it618_wike_lang['s702'] = '入选';
$it618_wike_lang['s703'] = '承接';
$it618_wike_lang['s704'] = '已满';
$it618_wike_lang['s705'] = '悬赏';
$it618_wike_lang['s706'] = '人报名 , ';
$it618_wike_lang['s707'] = '人入选 , 还要';
$it618_wike_lang['s708'] = '人承接 , 还要';
$it618_wike_lang['s709'] = '人入选 , 名额已满';
$it618_wike_lang['s710'] = '人承接 , 名额已满';
$it618_wike_lang['s711'] = '人已悬赏 , 还要悬赏';
$it618_wike_lang['s712'] = '人已悬赏 , 悬赏名额已满';
$it618_wike_lang['s713'] = '报名交稿';
$it618_wike_lang['s714'] = '停止交稿';
$it618_wike_lang['s715'] = '显示默认菜单(刷新页面、复制链接、注册登录等)';
$it618_wike_lang['s716'] = '手机版底部二级导航，格式(多个导航要换行)：<br>
&lt;li&gt;&lt;a class="react" href="导航链接1"&gt;导航名称1&lt;/a&gt;&lt;/li&gt;<br>
&lt;li&gt;&lt;a class="react" href="导航链接2"&gt;导航名称2&lt;/a&gt;&lt;/li&gt;';
$it618_wike_lang['s717'] = '刷新页面';
$it618_wike_lang['s718'] = '复制链接';
$it618_wike_lang['s719'] = '链接复制成功！';
$it618_wike_lang['s720'] = '我要退出任务';
$it618_wike_lang['s721'] = '管理员修改任务退还预算减少部分';
$it618_wike_lang['s722'] = '管理员修改任务退还预算减少部分的服务费';
$it618_wike_lang['s723'] = '管理员';
$it618_wike_lang['s879'] = '提示：如果收短信会员的';
$it618_wike_lang['s880'] = '提示：如果您的';
$it618_wike_lang['s881'] = '不够或已收到微信消息，就不发短信消息了';
$it618_wike_lang['s882'] = '【';
$it618_wike_lang['s883'] = '】';
$it618_wike_lang['s884'] = '实际付款数应该大于预算下限数！';
$it618_wike_lang['s885'] = '4、任务圆满完成条件：付款总数应小于等于预算上限并且大于等于预算下限';
$it618_wike_lang['s886'] = '4、任务圆满完成条件：付款总数应大于等于预算上限';
$it618_wike_lang['s887'] = '<font color=red>点击查看规则</font>';
$it618_wike_lang['s888'] = '<font color=green>提示：默认有短信宝接口，如果配合 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a> 可以有阿里云短信接口，此插件以后还可以扩展更多短信接口</font>';
$it618_wike_lang['s889'] = '模块DIY调用';
$it618_wike_lang['s890'] = '分钟';
$it618_wike_lang['s891'] = '模块数量：';
$it618_wike_lang['s892'] = 'DIY调用标识符';
$it618_wike_lang['s893'] = '模块类型';
$it618_wike_lang['s894'] = '模板内容/查询条件';
$it618_wike_lang['s895'] = '记录条数';
$it618_wike_lang['s896'] = '开启JS调用';
$it618_wike_lang['s897'] = '缓存时间';
$it618_wike_lang['s898'] = '最新任务';
$it618_wike_lang['s899'] = '人气任务';
$it618_wike_lang['s900'] = '自定义内容';
$it618_wike_lang['s901'] = '请复制(CTRL+C)以下内容并添加到 HTML 文件中';
$it618_wike_lang['s902'] = '外部调用';
$it618_wike_lang['s903'] = '提交后编辑模板内容，并且模块类型不可修改';
$it618_wike_lang['s904'] = '默认10条记录';
$it618_wike_lang['s905'] = '默认不开启';
$it618_wike_lang['s906'] = '默认缓存时间为1分钟';
$it618_wike_lang['s907'] = '<hr />
<strong>通用标签：</strong>[loop]...[/loop] 循环显示内容，{allcount} 任务总数，{summoney} 累计成立金额，{siteurl} 本站的网址外站调用时可到<hr />
<strong>任务标签：</strong>{modeico}任务模式图标，{classname}任务主题分类名称，{classurl}任务主题分类链接，{name} 任务名称，{name,n} 任务名称截取n个长度，n可以自己设置，如：{name,40}，注意：此标签只能设置一个，{url} 任务链接，{getstate} 返回任务状态与截止时间，{getmancount} 返回任务人数、浏览数、报名数、承接数，{getmode} 返回任务模式图标，{getmoney} 返回任务金额，{gettjimg} 返回任务推荐图标，{getico} 返回任务帖子图标，{time} 发布任务时间，{username} 发布任务会员，{userurl} 发布任务会员个人空间链接
';
$it618_wike_lang['s908'] = '显示';
$it618_wike_lang['s909'] = '点击显示隐藏模块内容编辑器';
$it618_wike_lang['s910'] = '隐藏';
$it618_wike_lang['s911'] = '推荐任务';
$it618_wike_lang['s912'] = '后截止';
$it618_wike_lang['s913'] = '扫码访问手机版';
$it618_wike_lang['s914'] = '我的钱包';
$it618_wike_lang['s915'] = '我要报名交稿';
$it618_wike_lang['s916'] = '托管赏金';
$it618_wike_lang['s917'] = '报名交稿';
$it618_wike_lang['s918'] = '入选承接';
$it618_wike_lang['s919'] = '验收付款';
$it618_wike_lang['s920'] = '圆满完成';
$it618_wike_lang['s921'] = '删除任务';
$it618_wike_lang['s922'] = '报名结束';
$it618_wike_lang['s923'] = '报名开始';
$it618_wike_lang['s924'] = '保存设置';
$it618_wike_lang['s925'] = '完成任务';
$it618_wike_lang['s926'] = '任务管理';
$it618_wike_lang['s927'] = '悬赏';
$it618_wike_lang['s928'] = '付款';
$it618_wike_lang['s929'] = '入选';
$it618_wike_lang['s930'] = '删除';
$it618_wike_lang['s931'] = '附件(或图片)/留言';
$it618_wike_lang['s932'] = '抱歉，请先登录！';
$it618_wike_lang['s933'] = '抱歉，此附件(或图片)/备注您没有权限查看或管理！';
$it618_wike_lang['s934'] = '抱歉，请上传 {type} 格式的附件(或图片)！';
$it618_wike_lang['s935'] = '抱歉，附件(或图片)大小不能超过';
$it618_wike_lang['s936'] = '！';
$it618_wike_lang['s937'] = '抱歉，您所在用户组没有上传附件(或图片)权限，可以写备注的！';
$it618_wike_lang['s938'] = '抱歉，您所有上传的附件(或图片)大小超过了';
$it618_wike_lang['s939'] = '，建议删除一些没用的附件(或图片)！';
$it618_wike_lang['s940'] = '报名费最大值';
$it618_wike_lang['s941'] = '注意：报名费最大值为0时，前台不会显示报名费功能，报名费最大值为0时，表示此用户组会员没有设置报名费功能，报名费直接支付给发布人不退还';
$it618_wike_lang['s942'] = '上传附件<br>双方留言';
$it618_wike_lang['s943'] = '报名需要金额：';
$it618_wike_lang['s944'] = '最多可设置';
$it618_wike_lang['s945'] = '抱歉，您所在用户组最多可以设置';
$it618_wike_lang['s946'] = '的报名费！';
$it618_wike_lang['s947'] = '报名金额';
$it618_wike_lang['s948'] = '需要支付给雇主';
$it618_wike_lang['s949'] = '不退还的除非雇主取消报名 , 雇主已收总报名金额';
$it618_wike_lang['s950'] = '任务雇主';
$it618_wike_lang['s951'] = '任务模式';
$it618_wike_lang['s952'] = '已付金额';
$it618_wike_lang['s953'] = '保证金额';
$it618_wike_lang['s954'] = '接手报名后会冻结';
$it618_wike_lang['s955'] = '任务圆满完成自动退还';
$it618_wike_lang['s956'] = '任务人数';
$it618_wike_lang['s957'] = '共需';
$it618_wike_lang['s958'] = '人 已';
$it618_wike_lang['s959'] = '人报名 已有';
$it618_wike_lang['s960'] = '人承接了任务';
$it618_wike_lang['s961'] = '人被悬赏';
$it618_wike_lang['s962'] = '报名费';
$it618_wike_lang['s963'] = '保证金';
$it618_wike_lang['s964'] = '抱歉，此承接人已入选了，不能删除，如果要删除请找管理员！';
$it618_wike_lang['s965'] = '未公开';
$it618_wike_lang['s966'] = '我要取消报名';
$it618_wike_lang['s967'] = '我要退出(退款+赔保证金)';
$it618_wike_lang['s968'] = '抱歉，您已入选了，不能取消报名，要么找管理员删除承接，要么自己退出(退款+赔保证金)！';
$it618_wike_lang['s969'] = '抱歉，此任务已完成，不能取消报名！';
$it618_wike_lang['s970'] = '您已成功取消报名！';
$it618_wike_lang['s971'] = '确定要取消报名？\n\n取消后，您支付的{bzmoney}保证金，会退还给您！';
$it618_wike_lang['s972'] = '确定要取消报名？\n\n取消后，您支付给雇主的{bmmoney}报名费不退还，支付的{bzmoney}保证金，会退还给您！';
$it618_wike_lang['s973'] = '确定要退出(退款+赔保证金)？\n\n退出后，您支付的{bzmoney}保证金，会直接给雇主，同时自己的退赔次数(不良记录)会增加1次！';
$it618_wike_lang['s974'] = '确定要退出(退款+赔保证金)？\n\n退出后，您支付的{bmmoney}报名费不退还，支付的{bzmoney}保证金，会直接给雇主，同时自己的退赔次数(不良记录)会增加1次！';
$it618_wike_lang['s975'] = '抱歉，您还未入选，不能退出(退款+赔保证金)，只能取消报名！';
$it618_wike_lang['s976'] = '抱歉，此任务已完成，不能退出(退款+赔保证金)！';
$it618_wike_lang['s977'] = '您已成功退出(退款+赔保证金)！';
$it618_wike_lang['s978'] = '退赔';
$it618_wike_lang['s979'] = '次';
$it618_wike_lang['s980'] = '确定要强制此承接会员退出(退款+赔保证金)？此操作不可逆！';
$it618_wike_lang['s981'] = '抱歉，此承接人还未入选，不能退出(退款+赔保证金)，只能删除报名！';
$it618_wike_lang['s982'] = '成功强制此承接人退出(退款+赔保证金)！';
$it618_wike_lang['s983'] = '退赔管理';
$it618_wike_lang['s984'] = '查找';
$it618_wike_lang['s985'] = '按帖子tid';
$it618_wike_lang['s986'] = '发布会员uid';
$it618_wike_lang['s987'] = '承接会员uid';
$it618_wike_lang['s988'] = '退赔类型';
$it618_wike_lang['s989'] = '全部类型';
$it618_wike_lang['s990'] = '自主退赔';
$it618_wike_lang['s991'] = '强制退赔';
$it618_wike_lang['s992'] = '退赔时间';
$it618_wike_lang['s993'] = '退赔次数：';
$it618_wike_lang['s994'] = '任务';
$it618_wike_lang['s995'] = '发布人';
$it618_wike_lang['s996'] = '承接人';
$it618_wike_lang['s997'] = '报名费';
$it618_wike_lang['s998'] = '保证金';
$it618_wike_lang['s999'] = '承接时间';
$it618_wike_lang['s1000'] = '退赔类型';
$it618_wike_lang['s1001'] = '退赔时间';
$it618_wike_lang['s1002'] = '任务所在帖子已删除或不存在';
$it618_wike_lang['s1003'] = '成功删除数：';
$it618_wike_lang['s1004'] = '我的退赔';
$it618_wike_lang['s1005'] = '受赔';
$it618_wike_lang['s1006'] = '我的受赔';
$it618_wike_lang['s1007'] = '抱歉，您的报名被删除了，不能再取消了！';
$it618_wike_lang['s1008'] = '抱歉，您的承接被删除或强制退出(退款+赔保证金)了，不能再退出(退款+赔保证金)了！';
$it618_wike_lang['s1009'] = '抱歉，此承接已删除或退出(退款+赔保证金)了，不能再强制退出(退款+赔保证金)了！';
$it618_wike_lang['s1010'] = '抱歉，此承接已删除或退出(退款+赔保证金)了，不能再删除了！';
$it618_wike_lang['s1011'] = '<font color="green">管理员强制退出(退款+赔保证金)时</font> - <font color="red">承接人消息模板</font></font>';
$it618_wike_lang['s1012'] = '<font color="#999999">示例：您在${time}给管理员强制退出(退款+赔保证金)了任务${name}！
<br>标签说明：{user}退出(退款+赔保证金)会员，{time}退出(退款+赔保证金)时间，{name}任务名称</font>';
$it618_wike_lang['s1013'] = '<font color="green">会员退出(退款+赔保证金)时</font> - <font color="blue">发布人消息模板</font></font>';
$it618_wike_lang['s1014'] = '<font color="#999999">示例：会员${user} 在${time}自主退出(退款+赔保证金)了任务${name}！
<br>标签说明：{user}退出(退款+赔保证金)会员，{time}退出(退款+赔保证金)时间，{name}任务名称</font>';
$it618_wike_lang['s1015'] = '<font color="green">管理员强制退出(退款+赔保证金)时</font> - <font color="blue">发布人消息模板</font></font>';
$it618_wike_lang['s1016'] = '<font color="#999999">示例：会员${user} 在${time}给管理员强制退出(退款+赔保证金)了任务${name}！
<br>标签说明：{user}退出(退款+赔保证金)会员，{time}退出(退款+赔保证金)时间，{name}任务名称</font>';
$it618_wike_lang['s1017'] = '<font color="green">删除报名或承接时</font> - <font color="red">承接人消息模板</font></font>';
$it618_wike_lang['s1018'] = '<font color="#999999">示例：您在${time}给雇主删除报名或承接了，任务${name}！
<br>标签说明：{user}报名承接会员，{time}删除报名时间，{name}任务名称</font>';
$it618_wike_lang['s1019'] = '全部任务模式';
$it618_wike_lang['s1020'] = '任务状态';
$it618_wike_lang['s1021'] = '请输入关键字';
$it618_wike_lang['s1022'] = '收起';
$it618_wike_lang['s1023'] = '抱歉，此插件还未开启，请先开启！';
$it618_wike_lang['s1024'] = '已奖励';
$it618_wike_lang['s1025'] = '任务圆满完成以后 可额外获得( <font color=red>预算金额</font> * <font color=red>{bl}%</font> ){jfname} 的奖励';
$it618_wike_lang['s1026'] = '发布/承接人奖励比率';
$it618_wike_lang['s1027'] = '任务圆满完成以后 可额外获得( <font color=red>收入</font> * <font color=red>{bl}%</font> ){jfname} 的奖励';
$it618_wike_lang['s1028'] = '抱歉，任务必须在发布{oktime}小时以后可以点完成！您从发布任务到现在已有{time}小时。';
$it618_wike_lang['s1029'] = '联系信息与提醒';
$it618_wike_lang['s1030'] = '定时';
$it618_wike_lang['s1031'] = '发布任务 不需要额外支付 服务费！';
$it618_wike_lang['s1032'] = '任务总数：';
$it618_wike_lang['s1033'] = '累计成交：';
$it618_wike_lang['s1034'] = '承接任务 不需要额外支付 服务费！';
$it618_wike_lang['s1035'] = '大小：';
$it618_wike_lang['s1036'] = '变更记录';
$it618_wike_lang['s1037'] = '抱歉，当前版块为任务版块，不支持快速发帖，请点击此编辑器上的“高级模式”链接发布任务！';
$it618_wike_lang['s1038'] = '';
$it618_wike_lang['s1040'] = '短信接口类型：';
$it618_wike_lang['s1041'] = '默认标配短信接口(短信宝)';
$it618_wike_lang['s1042'] = 'IT618统一短信接口(阿里大鱼)';
$it618_wike_lang['s1043'] = '短信签名：';
$it618_wike_lang['s1044'] = 'IT618统一短信接口(阿里云短信)';
$it618_wike_lang['s1045'] = '<font color=green><b>抱歉，您还没有安装 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】，此插件为IT618公用短信接口插件，<font color=red>同时还是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_wike_lang['s1046'] = '短信模板ID：';
$it618_wike_lang['s1047'] = '消息提醒设置';
$it618_wike_lang['s1048'] = '如果是个人认证，变量字符最多限制个数：';
$it618_wike_lang['s1049'] = '不受限制时请不要填写';
$it618_wike_lang['s1050'] = '管理员UID<font color=#999>(用于微信消息，多个UID用,隔开)</font>：';
$it618_wike_lang['s1051'] = '微信消息模板ID：';
$it618_wike_lang['s1052'] = '微信消息标签值：';
$it618_wike_lang['s1053'] = '<font color=#999>提示：优先发送微信消息，发送成功了，就不发短信了</font>';
$it618_wike_lang['s1054'] = '搜索';
$it618_wike_lang['s1055'] = '被冻结(服务费已算入冻结金)，给承接人付款时的金额来自托管的冻结金额(不包括服务费)';
$it618_wike_lang['s1857'] = '注册或登录会员会有历史搜索功能';
$it618_wike_lang['s1858'] = '全部清空';
$it618_wike_lang['s1859'] = '我的历史搜索';
$it618_wike_lang['s1944'] = '我的福利';
$it618_wike_lang['s1945'] = '邀请分销/合伙人/卡券';
$it618_wike_lang['s1946'] = '我的VIP';
$it618_wike_lang['s1947'] = '详情/续购/全站VIP';
$it618_wike_lang['s1958'] = '当前菜单标题颜色';
$it618_wike_lang['s1959'] = '当前菜单图标';

//it618_wike_lang(\d+)} it618_wike_lang['t$1']}
$it618_wike_lang['t1'] = '剩余';
$it618_wike_lang['t2'] = '天';
$it618_wike_lang['t3'] = '时';
$it618_wike_lang['t4'] = '分';
$it618_wike_lang['t5'] = '秒';
$it618_wike_lang['t6'] = '后截止报名交稿';
$it618_wike_lang['t7'] = '报名截止时间';
$it618_wike_lang['t8'] = '年';
$it618_wike_lang['t9'] = '月';
$it618_wike_lang['t10'] = '日';
$it618_wike_lang['t11'] = '时';
$it618_wike_lang['t12'] = '分';
$it618_wike_lang['t13'] = '秒';
$it618_wike_lang['t14'] = '确 定';
$it618_wike_lang['t15'] = '任务单价金额：';
$it618_wike_lang['t16'] = '任务悬赏人数：';
$it618_wike_lang['t17'] = '任务预算金额：';
$it618_wike_lang['t18'] = '任务预计人数：';
$it618_wike_lang['t19'] = '发布任务';
$it618_wike_lang['t20'] = '任务搜索统计';
$it618_wike_lang['t21'] = '状态';
$it618_wike_lang['t22'] = '所有状态';
$it618_wike_lang['t23'] = '访问我的个人空间';
$it618_wike_lang['t24'] = '我的发布';
$it618_wike_lang['t25'] = '我的承接';
$it618_wike_lang['t26'] = '个';
$it618_wike_lang['t27'] = '支出';
$it618_wike_lang['t28'] = '收入';
$it618_wike_lang['t29'] = '雇主UID';
$it618_wike_lang['t30'] = '接手UID';
$it618_wike_lang['t31'] = '预算';
$it618_wike_lang['t32'] = '任务名称';
$it618_wike_lang['t33'] = '发布时间';
$it618_wike_lang['t34'] = '搜索统计';
$it618_wike_lang['t35'] = '搜索任务';
$it618_wike_lang['t36'] = '推荐任务';
$it618_wike_lang['t37'] = '人气任务';
$it618_wike_lang['t38'] = '登录';
$it618_wike_lang['t39'] = '发布';
$it618_wike_lang['t40'] = '支出';
$it618_wike_lang['t41'] = '承接';
$it618_wike_lang['t42'] = '收入';
$it618_wike_lang['t43'] = '最近承接';
$it618_wike_lang['t44'] = '最近收入';
$it618_wike_lang['t45'] = '发布排行';
$it618_wike_lang['t46'] = '承接排行';
$it618_wike_lang['t47'] = '收入排行';
$it618_wike_lang['t48'] = '抱歉，请输入有效的11位手机号码！';
$it618_wike_lang['t49'] = '返回';
$it618_wike_lang['t50'] = '刷新';
$it618_wike_lang['t51'] = '任务模式：';
$it618_wike_lang['t52'] = '任务模式:';
$it618_wike_lang['t53'] = '附件(或图片)与留言';
$it618_wike_lang['t54'] = '删除成功！';
$it618_wike_lang['t55'] = '提交成功！';
$it618_wike_lang['t56'] = '确定';
$it618_wike_lang['t57'] = '下载附件';
$it618_wike_lang['t58'] = '仅报名人可以看任务需求描述';
$it618_wike_lang['t59'] = '上传时间：';
$it618_wike_lang['t60'] = '提示：修改上传后自动删除老附件(或图片)替换新上传的并且下载次数自动为0';
$it618_wike_lang['t61'] = '承接方还未上传附件(或图片)！';
$it618_wike_lang['t62'] = '确定要删除附件(或图片)？';
$it618_wike_lang['t63'] = '允许上传的附件(或图片)最大';
$it618_wike_lang['t64'] = '承接方留言';
$it618_wike_lang['t65'] = '留言时间：';
$it618_wike_lang['t66'] = '发布方留言';
$it618_wike_lang['t67'] = '提交';
$it618_wike_lang['t68'] = '技巧：如果任务不需要附件(或图片)，只提交留言就可以了';
$it618_wike_lang['t69'] = '删除附件';
$it618_wike_lang['t70'] = '强制退赔';
$it618_wike_lang['t71'] = '自主退赔';
$it618_wike_lang['t72'] = '次';
$it618_wike_lang['t73'] = '发布时间';
$it618_wike_lang['t74'] = '剩余时间';
$it618_wike_lang['t75'] = '人数';
$it618_wike_lang['t76'] = '价格';
$it618_wike_lang['t77'] = '请输入关键字搜索任务';
$it618_wike_lang['t78'] = '标题/赏金';
$it618_wike_lang['t79'] = '状态/时间';
$it618_wike_lang['t80'] = '所有任务模式';
$it618_wike_lang['t81'] = '状态模式:';
$it618_wike_lang['t82'] = '排序方式';
$it618_wike_lang['t83'] = '仅承接人可以看任务需求描述';
$it618_wike_lang['t84'] = '下载：';
$it618_wike_lang['t389'] = '我的';
$it618_wike_lang['t390'] = '余额';
$it618_wike_lang['t391'] = '元/查看积分';
$it618_wike_lang['t654'] = '抱歉，请先登录！也可以直接点确定跳转到登录页面！';
$it618_wike_lang['t758'] = '返回上页';
$it618_wike_lang['t759'] = '刷新页面';
$it618_wike_lang['t760'] = '搜索商品';
$it618_wike_lang['t763'] = '复制链接';
$it618_wike_lang['t764'] = '请升级您的微信版本！';
$it618_wike_lang['t765'] = '链接复制成功！';
$it618_wike_lang['t767'] = '确定要删除“';
$it618_wike_lang['t768'] = '”？此操作不可逆！';
$it618_wike_lang['t769'] = '确定要清空历史搜索？此操作不可逆！';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike_diy'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_wike_diy` (`it618_name`, `it618_type`, `it618_sql`, `it618_modecode`, `it618_count`, `it618_isjs`, `it618_time`, `it618_catchtime`) VALUES
('it618_wikediy', 'wike_new', '||', '<style>\r\n.wikelist{float:left; width:958px;border:#ddd 1px solid;margin-bottom:10px;padding-bottom:10px}\r\n.wikelist li{float:left; width:934px;margin-left:6px; padding-bottom:8px; padding-top:8px; padding-left:6px; padding-right:3px;font-size:14px}\r\n.wikelist li.wikelihead{margin-left:0;width:948px;background-color:#f6f6f6;border-bottom:#e9e9e9 1px dotted;}\r\n.wikelist li span.liheadtitle{border-left:#F60 3px solid;padding-left:8px;font-size:16px;margin-left:8px}\r\n.wikelist li span.liheadmore{float:right; margin-right:6px;font-size:12px}\r\n.wikelisttable tr td.wikepage{padding-top:15px; padding-bottom:15px}\r\n.wikelisttable tr td{font-family:"Microsoft YaHei","微软雅黑","黑体"}\r\n.wikelisttable tr td.wiketd{padding:11px 2px;border-bottom:#e8e8e8 1px solid;font-size:12px}\r\n.wikelisttable table{width:100%}\r\n.wikelisttable table tr td{padding:0px; line-height:30px}\r\n.wikelisttable table tr.trwike1 td.tdwikeleft a{font-size:16px; color:#333}\r\n.wikelisttable table tr.trwike1 td.tdwikeleft a:hover{color:#f30}\r\n.wikelisttable table tr.trwike1 td.tdwikeright{color:#999; font-size:12px}\r\n.wikelisttable table tr.trwike2 td.tdwikeleft .spanmoney{color:#999; font-size:12px; padding-left:8px}\r\n.wikelisttable table tr.trwike2 td.tdwikeleft .spanmancount{color:#999; font-size:12px; padding-left:10px}\r\n.wikelisttable table tr.trwike2 td.tdwikeleft .spanmancount em{padding:3px; color:#ccc}\r\n.wikelisttable table tr.trwike2 td.tdwikeleft .spanmoney b{font-size:12px; color:#f60; padding-left:3px}\r\n.wikelisttable table tr.trwike2 td.tdwikeright{width:168px;}\r\n.wikelisttable table tr.trwike2 td.tdwikeright .spanauthortime{color:#999; font-size:12px}\r\n.wikelisttable table tr.trwike2 td.tdwikeright .spanauthortime em{padding:3px; color:#ccc}\r\n.wikelisttable table tr.trwike2 td.tdwikeright .spanauthortime a{color:#999; font-size:12px}\r\n.wikelisttable table tr.trwike2 td.tdwikeright .spanauthortime a:hover{color:#f30}\r\n</style>\r\n<ul class="wikelist">\r\n<li class="wikelihead"><span class="liheadmore"><a href="wike.html" target="_blank">更多<font color=red>it618任务悬赏威客</font>的任务>></a></span><span class="liheadtitle">最新任务</span></li>\r\n<li>\r\n<table class="wikelisttable" width="100%" id="wikelist">\r\n[loop]\r\n<tr><td class="wiketd">\r\n<table>\r\n<tr class="trwike1">\r\n<td class="tdwikeleft"><a href="{url}" title="{name}" target="_blank">{name,50}</a>{getico}</td>\r\n<td class="tdwikeright">{getstate}</td>\r\n</tr>\r\n<tr class="trwike2">\r\n<td class="tdwikeleft">{getmode} <span class="spanmoney">{getmoney}</span> <span class="spanmancount">{getmancount}</span></td>\r\n<td class="tdwikeright"><span class="spanauthortime"><img src="source/plugin/it618_wike/images/user.png" style="vertical-align:middle;height:13px;margin-top:-4px"> <a href="{userurl}" target="_blank">{username} </a><em>/</em>{time}{gettjimg}</span></td>\r\n</tr>\r\n</table>\r\n</td></tr>\r\n[/loop]\r\n</table>\r\n</li>\r\n</ul>', 10, 0, 1527391522, 0);

EOF;
$sql=str_replace("pre_it618_wike_diy",DB::table('it618_wike_diy'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike_wapstyle'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_wike_wapstyle` (`it618_color1`, `it618_color2`, `it618_isok`) VALUES
('#fd9e2d', '#e8922b', 0),
('#fc4646', '#f43131', 0),
('#5ebe00', '#56aa04', 0),
('#099fde', '#098fc8', 0),
('#fb23cb', '#ea11ba', 0),
('#2dbeae', '#00a795', 1),
('#fe5400', '#d04906', 0),
('#999a9b', '#8d8f90', 0);

EOF;
$sql=str_replace("pre_it618_wike_wapstyle",DB::table('it618_wike_wapstyle'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike_bottomnav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_wike_bottomnav` (`id`, `it618_title`, `it618_img`, `it618_curimg`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '发现', 'source/plugin/it618_wike/wap/images/menu.png', '','','',3),
(2, '首页', 'source/plugin/it618_wike/wap/images/home.png', 'source/plugin/it618_wike/wap/images/curhome.png', '{waphome}','#FF0000',1),
(3, '搜索', 'source/plugin/it618_wike/wap/images/find.png', 'source/plugin/it618_wike/wap/images/curfind.png', '{wapsearch}','#FF0000',2),
(4, '发布', 'source/plugin/it618_wike/wap/images/post.png', 'source/plugin/it618_wike/wap/images/curpost.png', '{wappost}','#FF0000',4),
(5, '我的', 'source/plugin/it618_wike/wap/images/uc.png', 'source/plugin/it618_wike/wap/images/curuc.png', '','#FF0000',5);

EOF;
$sql=str_replace("pre_it618_wike_bottomnav",DB::table('it618_wike_bottomnav'),$sql);
DB::query($sql);
}

$tmpplugin = $_G['cache']['plugin']['it618_wike'];
if($tmpplugin['wike_credit']==''||$tmpplugin['wike_jlcredit']==''||$tmpplugin['wike_getjlcredit']==''){
	echo '抱歉，请先在插件后台(it618_wike)设置好积分类型！';exit;
}
?>