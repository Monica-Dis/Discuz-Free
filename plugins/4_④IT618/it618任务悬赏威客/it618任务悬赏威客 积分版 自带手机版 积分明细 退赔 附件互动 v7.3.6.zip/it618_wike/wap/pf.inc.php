<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

if(!wike_is_mobile()){ 
	$tmpurl=it618_wike_getrewrite('wike_home','','plugin.php?id=it618_wike:index');
	dheader("location:$tmpurl");
}

$menutype=intval($_GET['cid']);
if($menutype==0)$menutype=1;
if($menutype==1){$titlestr=$it618_wike_lang['t70'];$current1='class="current"';}
if($menutype==2){$titlestr=$it618_wike_lang['t71'];$current2='class="current"';}

$wappostpf=it618_wike_getrewrite('wike_wap','pf@1@'.$_G['uid'],'plugin.php?id=it618_wike:wap&pagetype=pf&cid=1&uid='.$_G['uid']);
$wapgetpf=it618_wike_getrewrite('wike_wap','pf@2@'.$_G['uid'],'plugin.php?id=it618_wike:wap&pagetype=pf&cid=2&uid='.$_G['uid']);

$navtitle=$titlestr.' - '.$sitetitle;

$_G['mobiletpl'][2]='/';
include template('it618_wike:wap_wike');
?>