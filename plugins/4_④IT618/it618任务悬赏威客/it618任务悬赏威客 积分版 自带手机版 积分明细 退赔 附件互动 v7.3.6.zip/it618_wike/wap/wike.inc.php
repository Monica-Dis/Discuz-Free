<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

if(!wike_is_mobile()){ 
	$tmpurl=it618_wike_getrewrite('wike_home','','plugin.php?id=it618_wike:index');
	dheader("location:$tmpurl");
}

$wike_focus_pics_wap = $it618_wike['wike_focus_pics_wap'];
$wike_focus_pics_wap=explode("|",str_replace(array("\r\n", "\r", "\n"), '|', $it618_wike['wike_focus_pics_wap']));
if($il1i1l[5]!='_')return;
$i=1;
foreach($wike_focus_pics_wap as $key => $wike_focus_pic){
	if($wike_focus_pic!=""){
		$tmparr=explode("==",$wike_focus_pic);
		if($tmparr[1]!=''){
			$str_focus.='<div class="swiper-slide"><a href="'.$tmparr[1].'" target="_blank"><img class="img" src="'.it618_wike_getwapppic($tmparr[0]).'"/></a></div>';
		}else{
			$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_wike_getwapppic($tmparr[0]).'" /></div>';
		}
		$i=$i1;
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_wike_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_wike_gonggao = DB::fetch($query)) {
	$it618_title=$it618_wike_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_wike_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_wike_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_wike_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_wike_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

if($it618_wike['waphomeico']=='')$it618_wike['waphomeico']='1|5|11|#888|6';
$waphomeico=explode("|",$it618_wike['waphomeico']);
$tmpn=$waphomeico[0];
$pppn=$waphomeico[1];
$tmpsize=$waphomeico[2];
$tmpcolor=$waphomeico[3];
$tmpw=$waphomeico[4];
$pppw=100/$pppn;
$tmpn=$tmpn*$pppn;

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_wike_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_wike_iconav = DB::fetch($query)) {
	$it618_title=$it618_wike_iconav['it618_title'];
	
	if($it618_wike_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_wike_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_wike_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_wike_iconav['it618_color'].'">'.$it618_title.'</font>';
	}

	$str_iconav.='<td width="'.$pppw.'%"><a href="'.$it618_wike_iconav['it618_url'].'"'.$it618_target.'><img src="'.$it618_wike_iconav['it618_img'].'" /><br>'.$it618_title.'</a></td>';
	
	if($n%$pppn==0)$str_iconav.='</tr><tr>';
	if($n%$tmpn==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';

	$n=$n+1;
}

if($n>1)$n=$n-1;

if($n%$pppn>0){
	for($i=1;$i<=($pppn-$n%$pppn);$i++){
		$str_iconav.='<td width="'.$pppw.'%"></td>';
	}
}

$str_iconav.='</tr>';
$str_iconav=str_replace('<tr></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"></table></div>','',$str_iconav);
$str_iconav=str_replace('<tr><td','<tr><td width='.$tmpw.'></td><td',$str_iconav);
$str_iconav=str_replace('</td></tr>','</td><td width='.$tmpw.'></td></tr>',$str_iconav);
$str_iconav.='<style>.swiper-slide .iconav{table-layout:fixed;}.swiper-slide .iconav tr td a{color:'.$tmpcolor.';font-size:'.$tmpsize.'px}</style>';

$isiconav=count(explode('<img src',$str_iconav))-1;

$sql='(it618_crondate=0 or it618_crondate<'.$_G['timestamp'].")";
if($_G['uid']>0){
	$tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
	for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
	   if($_G['uid']==$tmpwikeadmin[$tmpi]){
		   $sql='1';
		   break;
	   }
	}
}

for($n=1;$n<=3;$n++){
	if($n==1)$current=' class="current"';else $current=' ';
	if($n==1){
		$tab_wike.='<li'.$current.'onclick="it618_wike_tabChange(this,\'searchli_bd\')">'.$it618_wike_lang['s387'].'</li>';
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_wike_main')." where $sql and it618_tid>0 order by id desc limit 0,".$it618_wike['wike_wikecount']);
	}
	
	if($n==2){
		$tab_wike.='<li'.$current.'onclick="it618_wike_tabChange(this,\'searchli_bd\')">'.$it618_wike_lang['s388'].'</li>';
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_wike_main')." where $sql and it618_tid>0 and it618_istj=1 order by id desc limit 0,".$it618_wike['wike_wikecount']);
	}
	
	if($n==3){
		$tab_wike.='<li'.$current.'onclick="it618_wike_tabChange(this,\'searchli_bd\')">'.$it618_wike_lang['s389'].'</li>';
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_wike_main')." where $sql and it618_tid>0 order by it618_views desc limit 0,".$it618_wike['wike_wikecount']);
	}
	
	$home_wiketmp='';
	while($it618_wike_main =DB::fetch($query)) {

		$tid=$it618_wike_main['it618_tid'];
		$uid=$it618_wike_main['it618_uid'];
		$subject=it618_wike_getsubject($tid);
		
		$getstate=it618_wike_getstate($it618_wike_main,1);
		$getmancount=it618_wike_getmancount($it618_wike_main,1);
		$getmode=it618_wike_getmode($it618_wike_main,1);
		$getmoney=it618_wike_getmoney($it618_wike_main,1);
		$gettjimg=it618_wike_gettjimg($it618_wike_main,1);
		
		$it618_crondate='';
		if($it618_wike_main['it618_crondate']>$_G['timestamp']){
			$it618_crondate='['.$it618_wike_lang['s1030'].']';
		}
		
		$home_wiketmp.='<tr><td onclick="dohref('.$tid.')">
		<a href="forum.php?mod=viewthread&tid='.$tid.'" id="href'.$tid.'">'.$it618_crondate.$subject.'</a> '.it618_wike_getico($tid).'
		<br><span class="spanauthortime">'.it618_wike_getauthor($it618_wike_main['it618_uid']).'<em>/</em>'.date('Y-m-d', $it618_wike_main['it618_time1']).$gettjimg.'</span><span class="spanmancount">'.$getmancount.'</span>
		<br><span class="spanstate">'.$getstate.'</span>
		'.$getmode.' <span class="spanmoney">'.$getmoney.'</span>
		</td></tr>';

	}
	$tmpurl=it618_wike_getrewrite('wike_wap','search','plugin.php?id=it618_wike:wap&pagetype=search');
	if($n==1)$bdstyle=' ;display:';else $bdstyle=' ;display:none';
	$home_wike.='<dl class="list" id="searchli_bd'.($n-1).'" style="border-top:none; margin:0;'.$bdstyle.'">
					<dd>
						<table class="wikelist">
						'.$home_wiketmp.'
						<tr><td style="border:none"><div class="wapmore"><a href="'.$tmpurl.'">'.it618_wike_getlang('s386').'&gt;&gt;</a></div></td></tr>
						</table>
					</dd>
				  </dl>';
}


//��������
$query = DB::query("SELECT it618_uid,count(1) as wikecount FROM ".DB::table('it618_wike_main')." group by it618_uid order by wikecount desc limit 0,".$it618_wike['wike_rightcount']);
$n=1;
while($it618_wike_wike =DB::fetch($query)) {
	$uid=$it618_wike_wike['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$postph.='<tr><td><span style="float:right" class="tdspanright"><font color=red>'.$it618_wike_wike['wikecount'].'</font> '.it618_wike_getlang('s331').'</span><span class="phnum'.$tmpcss.'">'.$n.'</span> '.it618_wike_getauthor($uid).'<span style="color:#999">('.$uid.')</span>'.'</td></tr>';
	$n=$n+1;
}
$postph=it618_wike_rewriteurl($postph);
$il1i1l=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$il1i1l[]=substr($_GET['id'],$i,1);}
if($il1i1l[9]!='e')return;

//�н�����
$query = DB::query("SELECT it618_uid,count(1) as getcount FROM ".DB::table('it618_wike')." group by it618_uid order by getcount desc limit 0,".$it618_wike['wike_rightcount']);
$n=1;
while($it618_wike_wike =DB::fetch($query)) {
	$uid=$it618_wike_wike['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$getph.='<tr><td><span style="float:right" class="tdspanright"><font color=red>'.$it618_wike_wike['getcount'].'</font> '.it618_wike_getlang('s331').'</span><span class="phnum'.$tmpcss.'">'.$n.'</span> '.it618_wike_getauthor($uid).'<span style="color:#999">('.$uid.')</span>'.'</td></tr>';
	$n=$n+1;
}
$getph=it618_wike_rewriteurl($getph);
if($il1i1l[6]!='w')return;

//��������
$query = DB::query("SELECT it618_uid,sum(it618_creditnum) as money FROM ".DB::table('it618_wike')." group by it618_uid order by money desc limit 0,".$it618_wike['wike_rightcount']);
$n=1;
while($it618_wike_wike =DB::fetch($query)) {
	$uid=$it618_wike_wike['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$moneyph.='<tr><td><span style="float:right" class="tdspanright"><font color=red>'.$it618_wike_wike['money'].'</font> '.$wike_creditname.'</span><span class="phnum'.$tmpcss.'">'.$n.'</span> '.it618_wike_getauthor($uid).'<span style="color:#999">('.$uid.')</span>'.'</td></tr>';
	$n=$n+1;
}
$moneyph=it618_wike_rewriteurl($moneyph);

$tab_wike.='<li'.$current.'onclick="it618_wike_tabChange(this,\'searchli_bd\')">'.$it618_wike_lang['s413'].'</li>';

$home_wike.='<dl class="list" id="searchli_bd3" style="border-top:none; margin:0;display:none">
				<dd>
					<ul class="searchli1">
						<li class="current" onclick="it618_wike_tabChange(this,\'searchtable_bd\')">'.$it618_wike_lang['t45'].'</li>
						<li onclick="it618_wike_tabChange(this,\'searchtable_bd\')">'.$it618_wike_lang['t46'].'</li>
						<li onclick="it618_wike_tabChange(this,\'searchtable_bd\')">'.$it618_wike_lang['t47'].'</li>
					</ul>
					<table class="phtable" id="searchtable_bd0">
					'.$postph.'
					</table>
					<table class="phtable" id="searchtable_bd1" style="display:none">
					'.$getph.'
					</table>
					<table class="phtable" id="searchtable_bd2" style="display:none">
					'.$moneyph.'
					</table>
				</dd>
			  </dl>';

$homewike_str='<dl style="margin:0;margin-top:10px;padding:0px;background-color:#fff"><style>
	.divsearchli{border-bottom:#f9f9f9 1px solid;background-color:#fff;}
	.divsearchli ul{height:38px;}
	.divsearchli ul li{height:38px;line-height:38px; margin:0 13px;font-size:14px;}
	</style>
	<div class="divsearchli"><ul>'.$tab_wike.'</ul></div></dl>'.$home_wike.'';
$homewike_str=it618_wike_rewriteurl($homewike_str);

$allcount = C::t('#it618_wike#it618_wike_main')->count_by_search();
$allmoney = C::t('#it618_wike#it618_wike_main')->sum_jlmoney_by_search();

$_G['mobiletpl'][2]='/';
include template('it618_wike:wap_wike');
?>