<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!wike_is_mobile()){
	$tmpurl=it618_wike_getrewrite('wike_home','','plugin.php?id=it618_wike:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_wike_getlang('t389').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_wike_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_wike:wap_wike');
	return;
}

$it618_members = $_G['cache']['plugin']['it618_members'];
$menuusername=$_G['username'];
$u_avatarimg=it618_wike_discuz_uc_avatar($_G['uid'],'middle');
$creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
$creditnum=DB::result_first("select extcredits".$it618_wike['wike_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);

$postcount = C::t('#it618_wike#it618_wike_main')->count_by_search('','',$_G['uid'],0);
$postmoney = C::t('#it618_wike#it618_wike_main')->sum_jlmoney_by_search('','',$_G['uid'],0);
if($postmoney=='')$postmoney=0;

$getcount = C::t('#it618_wike#it618_wike_main')->count_by_search('','',0,$_G['uid']);
$getmoney = C::t('#it618_wike#it618_wike_main')->sum_jlmoney_by_search('','',0,$_G['uid']);
if($getmoney=='')$getmoney=0;

$postpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_pf')." WHERE it618_postuid=".$_G['uid']);
$getpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_pf')." WHERE it618_getuid=".$_G['uid']);

$postpfmoney = DB::result_first("SELECT sum(it618_getwikemoney) FROM ".DB::table('it618_wike_pf')." WHERE it618_postuid=".$_G['uid']);
$getpfmoney = DB::result_first("SELECT sum(it618_getwikemoney) FROM ".DB::table('it618_wike_pf')." WHERE it618_getuid=".$_G['uid']);

$wappostpf=it618_wike_getrewrite('wike_wap','pf@1@'.$_G['uid'],'plugin.php?id=it618_wike:wap&pagetype=pf&cid=1&uid='.$_G['uid']);
$wapgetpf=it618_wike_getrewrite('wike_wap','pf@2@'.$_G['uid'],'plugin.php?id=it618_wike:wap&pagetype=pf&cid=2&uid='.$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_buygroup=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$tmpurl_myvip=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$viplogo='source/plugin/it618_credits/images/group.png';
}

if($IsGroup==1){
	$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	$viplogo='source/plugin/it618_group/images/group.png';
}

if($IsUnion==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
}

$_G['mobiletpl'][2]='/';
include template('it618_wike:wap_wike');
?>