<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

if(!wike_is_mobile()){ 
	$tmpurl=it618_wike_getrewrite('wike_home','','plugin.php?id=it618_wike:index');
	dheader("location:$tmpurl");
}

$cid=intval($_GET['cid']);

$navtitle=$it618_wike_lang['s395'].' - '.$sitetitle;

$n=1;
$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'wikeclass1\',0,0)" name="wikeclass1"><span>'.$it618_wike_lang['s396'].'</span><i></i></a>';
$wike_forums = unserialize($it618_wike["wike_forums"]);
foreach($wike_forums as $key => $fid) {
	if($cid==$fid){
		$tmpgetjs='setselect(\'wikeclass1\','.$n.','.$fid.');';
	}
	$classtmp.='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'wikeclass1\','.$n.','.$fid.')" name="wikeclass1"><span>'.it618_wike_getforumname($fid).'</span><i></i></a>';
	$n=$n+1;
}

$moden=0;
$wike_modes=(array)unserialize($it618_wike['wike_modes']);
if(!in_array(1, $wike_modes)){$mode1='style="display:none"';$moden=$moden+1;}
if(!in_array(2, $wike_modes)){$mode2='style="display:none"';$moden=$moden+1;}
if(!in_array(3, $wike_modes)){$mode3='style="display:none"';$moden=$moden+1;}

$_G['mobiletpl'][2]='/';
include template('it618_wike:wap_wike');
?>