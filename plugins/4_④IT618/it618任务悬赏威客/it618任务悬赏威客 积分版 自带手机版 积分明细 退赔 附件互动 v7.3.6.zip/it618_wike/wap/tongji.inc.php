<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

if(!wike_is_mobile()){ 
	$tmpurl=it618_wike_getrewrite('wike_home','','plugin.php?id=it618_wike:index');
	dheader("location:$tmpurl");
}

$cid=intval($_GET['cid']);
$uid=intval($_GET['uid']);

if($cid==10001){
	if($uid>0)$postuid=$uid;
}

if($cid==10002){
	if($uid>0)$getuid=$uid;
}

$tmparr=explode("it618split",it618_wike_getforumclass());
$findclass=str_replace(it618_wike_getlang('s340'),"<font color=#999>".it618_wike_getlang('s340').':</font>',$tmparr[0]);
$wikeclassjs=$tmparr[1];

$moden=0;
$wike_modes=(array)unserialize($it618_wike['wike_modes']);
if(!in_array(1, $wike_modes)){$mode1='style="display:none"';$moden=$moden+1;}
if(!in_array(2, $wike_modes)){$mode2='style="display:none"';$moden=$moden+1;}
if(!in_array(3, $wike_modes)){$mode3='style="display:none"';$moden=$moden+1;}

$navtitle=$it618_wike_lang['s103'].' - '.$sitetitle;

$_G['mobiletpl'][2]='/';
include template('it618_wike:wap_wike');
?>