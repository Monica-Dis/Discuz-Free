<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

$tid = intval($_GET['tid']);
if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)>0){
	$it618_time2=DB::result_first("SELECT it618_time2 FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid);
	$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
	$etimestr=date('Y-m-d H:i:s', $it618_time2);
}

$_G['mobiletpl'][2]='/';
include template('it618_wike:time');
?>