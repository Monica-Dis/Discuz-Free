<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

$it618_wike = $_G['cache']['plugin']['it618_wike'];
$it618_witkey = $_G['cache']['plugin']['it618_witkey'];
$wike_forums = unserialize($it618_wike["wike_forums"]);
$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
$forumcount=count($wike_forums);

if($_GET['wap']==1){
	foreach($wike_forums as $key => $fid) {
		$tmpstr='';
		$query = DB::query("SELECT * FROM ".DB::table('forum_threadclass')." where fid=$fid order by displayorder");
		while($forum_threadclass =DB::fetch($query)) {
			$tmpstr.=$forum_threadclass['name'].',';
		}
		$tmpstr.=',';
		$tmpstr=str_replace(",,","",$tmpstr);
		$tmpfidurl='';
		if(in_array($fid, $wike_forums)&&in_array($fid, $witkey_forums)){
			$tmpfidurl='&paytype=credit';
		}
		$posttmp.='<tr><td style="padding:10px 5px"><a href="forum.php?mod=post&action=newthread&fid='.$fid.$tmpfidurl.'" onclick="layer.closeAll()" target="_blank">'.it618_wike_getforumname($fid).'<br><font color="#999" style="font-size:12px; font-weight:normal">'.it618_wike_getlang('s335').''.$tmpstr.'</font></a></td></tr>';
	}
	$posttmp='<table class="showpost">'.$posttmp.'</table>';
}else{
	if($forumcount<=0){
		showmessage(it618_wike_getlang('s330'), '', array(), array('alert' => 'error'));	
	}else{
		foreach($wike_forums as $key => $fid) {
			$tmpstr='';
			$query = DB::query("SELECT * FROM ".DB::table('forum_threadclass')." where fid=$fid order by displayorder");
			while($forum_threadclass =DB::fetch($query)) {
				$tmpstr.=$forum_threadclass['name'].',';
			}
			$tmpstr.=',';
			$tmpstr=str_replace(",,","",$tmpstr);
			$tmpfidurl='';
		if(in_array($fid, $wike_forums)&&in_array($fid, $witkey_forums)){
			$tmpfidurl='&paytype=credit';
		}
			$posttmp.='<li><a href="forum.php?mod=post&action=newthread&fid='.$fid.$tmpfidurl.'" onclick="hideWindow(\'it618_showpost\')" target="_blank">'.it618_wike_getforumname($fid).'</a> <font color="#999">('.it618_wike_getlang('s335').''.$tmpstr.')</font></li>';
		}
		$posttmp='<ul class="showpost">'.$posttmp.'</ul>';
	}
}

$_G['mobiletpl'][2]='/';

if($_GET['wap']!=1){
	include template('it618_wike:showpost');
}else{
	include template('it618_wike:showwappost');
}
?>