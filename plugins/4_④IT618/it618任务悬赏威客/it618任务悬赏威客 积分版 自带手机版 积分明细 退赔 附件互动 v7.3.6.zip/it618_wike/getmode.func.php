<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

function it618_wike_getmodecontent($modetype,$modesql,$modecode,$modecount){
	global $_G;
	$it618_wike = $_G['cache']['plugin']['it618_wike'];
	
	$tmparr=explode("[loop]",$modecode);
	$tmparr1=explode("[/loop]",$tmparr[1]);
	
	if($modetype=='wike_new'||$modetype=='wike_hot'){
		if($modetype=='wike_new')$orderby='order by m.id desc';else $orderby='order by m.it618_views desc';
		
		$it618_sql=explode("|",$modesql);
		
		$sql='(m.it618_crondate=0 or m.it618_crondate<'.$_G['timestamp'].")";
		
		if($it618_sql[0]!=''){
			$tmparr_sql=explode(",",$it618_sql[0]);
			for($i=0;$i<count($tmparr_sql);$i++){
				$it618_forumid.=','.intval($tmparr_sql[$i]);
			}
			$it618_forumid='@'.$it618_forumid;
			$it618_forumid=str_replace("@,","",$it618_forumid);
			
			$sql.=" and m.it618_fid in(".$it618_forumid.")";
		}
		
		if($it618_sql[1]!=''){
			$tmparr_sql=explode(",",$it618_sql[1]);
			for($i=0;$i<count($tmparr_sql);$i++){
				$it618_forumtypeid.=','.intval($tmparr_sql[$i]);
			}
			$it618_forumtypeid='@'.$it618_forumtypeid;
			$it618_forumtypeid=str_replace("@,","",$it618_forumtypeid);
			
			$sql.=" and m.it618_typeid in(".$it618_forumtypeid.")";
		}
		
		if(intval($it618_sql[2])==0)$sql.="";
		if(intval($it618_sql[2])==1)$sql.=" and m.it618_state=10";
		if(intval($it618_sql[2])==2)$sql.=" and m.it618_state=1";
		
		foreach(C::t('#it618_wike#it618_wike_main')->fetch_all_by_search(
				$sql,$orderby,'',0,0,0,0,'','',0,$modecount
		) as $it618_wike_main) {
			
			$tid=$it618_wike_main['it618_tid'];
			if($tid==0)continue;
			$uid=$it618_wike_main['it618_uid'];
			$subject=it618_wike_getsubject($tid);
			
			$tmparr_n=explode("{name,",$tmparr1[0]);
			if(count($tmparr)>1){
				$tmparr_n1=explode("}",$tmparr_n[1]);
				$name_n=$tmparr_n1[0];
				$subject1=cutstr($subject, $name_n, '');
			}

			$tmpstr=$tmparr1[0];
			
			$tmpstr=str_replace("{name}",$subject,$tmpstr);
			$tmpstr=str_replace("{name,".$name_n."}",$subject1,$tmpstr);
			$tmpstr=str_replace("{url}",'forum.php?mod=viewthread&tid='.$tid,$tmpstr);
			$tmpstr=str_replace("{name}",$subject,$tmpstr);
			
			$tmparrtmp=explode("{classname}",$tmpstr);
			if(count($tmparrtmp)>1){
				$tmpstr=str_replace("{classname}",it618_wike_getclass_name($tid),$tmpstr);
			}
			
			$tmparrtmp=explode("{classurl}",$tmpstr);
			if(count($tmparrtmp)>1){
				$tmpstr=str_replace("{classurl}",it618_wike_getclass_url($tid),$tmpstr);
			}

			$tmparrtmp=explode("{getico}",$tmpstr);
			if(count($tmparrtmp)>1){
				$tmpstr=str_replace("{getico}",it618_wike_getico($tid),$tmpstr);
			}
			
			$tmparrtmp=explode("{getstate}",$tmpstr);
			if(count($tmparrtmp)>1){
				$tmpstr=str_replace("{getstate}",it618_wike_getstate($it618_wike_main,0),$tmpstr);
			}
			
			$tmparrtmp=explode("{getmancount}",$tmpstr);
			if(count($tmparrtmp)>1){
				$tmpstr=str_replace("{getmancount}",it618_wike_getmancount($it618_wike_main,0),$tmpstr);
			}
			
			$tmparrtmp=explode("{getmode}",$tmpstr);
			if(count($tmparrtmp)>1){
				$tmpstr=str_replace("{getmode}",it618_wike_getmode($it618_wike_main,0),$tmpstr);
			}
			
			$tmparrtmp=explode("{getmoney}",$tmpstr);
			if(count($tmparrtmp)>1){
				$tmpstr=str_replace("{getmoney}",it618_wike_getmoney($it618_wike_main,0),$tmpstr);
			}
			
			$tmparrtmp=explode("{gettjimg}",$tmpstr);
			if(count($tmparrtmp)>1){
				$tmpstr=str_replace("{gettjimg}",it618_wike_gettjimg($it618_wike_main,0),$tmpstr);
			}
			
			$tmparrtmp=explode("{username}",$tmpstr);
			if(count($tmparrtmp)>1){
				$tmpstr=str_replace("{username}",it618_wike_getauthor($uid),$tmpstr);
			}
			
			$tmpstr=str_replace("{time}",date('Y-m-d', $it618_wike_main['it618_time1']),$tmpstr);
			
			$tmpstr=str_replace("{userurl}",'home.php?mod=space&uid='.$uid,$tmpstr);
			
			$content.=it618_wike_rewriteurl($tmpstr);
			
		}
	}
	
	$content=$tmparr[0].$content.$tmparr1[1];
	$content=str_replace("{siteurl}",$_G['siteurl'],$content);
	
	$tmparrtmp=explode("{allcount}",$content);
	if(count($tmparrtmp)>1){
		$allcount = C::t('#it618_wike#it618_wike_main')->count_by_search();
		$content=str_replace("{allcount}",$allcount,$content);
	}
	$tmparrtmp=explode("{summoney}",$content);
	if(count($tmparrtmp)>1){
		$allmoney = C::t('#it618_wike#it618_wike_main')->sum_jlmoney_by_search();
		$content=str_replace("{summoney}",$allmoney,$content);
	}
	
	return $content;
}

?>