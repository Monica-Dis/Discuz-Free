<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

if($_G['uid']<=0){
	$errstr=$it618_wike_lang['s932'];
}else{
	$getwikeid=intval($_GET['getwikeid']);

	if($it618_wike_wike=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike')." WHERE id=".$getwikeid)){
		$tid=$it618_wike_wike['it618_tid'];
		
		if($it618_wike_wike['it618_attachment']!=''){
			$isimg=0;
			$tmparrtype=explode(",",".jpg,.jpeg,.png,.gif");
			for($i=0;$i<count($tmparrtype);$i++){
				$tmparr=explode($tmparrtype[$i],$it618_wike_wike['it618_attachment']);
				if(count($tmparr)>1){
					$isimg=1;break;
				}
			}
			
			if($isimg==1){
				if($_GET['wap']==1){
					$attachmenttitle='<img src="'.$it618_wike_wike['it618_attachment'].'" width="100%" style="vertical-align:middle">';
				}else{
					$attachmenttitle='<img src="'.$it618_wike_wike['it618_attachment'].'" height="40" style="vertical-align:middle">';
				}
			}else{
				$attachmenttitle='<img src="source/plugin/it618_wike/images/fj.png" height="14" style="vertical-align:middle;margin-top:-3px;margin-right:2px">'.$it618_wike_lang['t57'];
			}
			
			$attachmenturl='plugin.php?id=it618_wike:attachmentdown&aid='.$it618_wike_wike['id'];
		}
		
		if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)){
			$it618_attachmenttime=date('Y-m-d H:i:s', $it618_wike_wike['it618_attachmenttime']);
			$it618_attachmentdown=$it618_wike_wike['it618_attachmentdown'];
			$it618_postbztime=date('Y-m-d H:i:s', $it618_wike_wike['it618_postbztime']);
			$it618_getbztime=date('Y-m-d H:i:s', $it618_wike_wike['it618_getbztime']);
			
			$adminauthor=0;
			if($_G['uid']>0){
				$tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
				for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
				   if($_G['uid']==$tmpwikeadmin[$tmpi]){
					   $adminauthor=1;
					   break;
				   }
				}
			}
			
			if($it618_wike_main['it618_uid']==$_G['uid']){
				$ispostwike=1;
			}
			
			if($it618_wike_wike['it618_uid']==$_G['uid']){
				$isgetwike=1;
			}
			
			if($ispostwike!=1&&$isgetwike!=1&&$adminauthor!=1){
				$errstr=$it618_wike_lang['s933'];
			}
		}else{
			$errstr=$it618_wike_lang['s2'];
		}
	}else{
		$errstr=$it618_wike_lang['s2'];
	}
}

if(submitcheck('submitattachment')&&$errstr==''){

	if($_FILES['it618_upfile']['error']==0&&$_FILES["it618_upfile"]["name"]!=''){
	
		$tmparr=explode(".", $_FILES["it618_upfile"]["name"]);
		$filetype=strtolower($tmparr[count($tmparr)-1]);
		
		$tmptypearr=explode(",",$it618_wike['wike_attachmenttype']);
		if(!in_array($filetype, $tmptypearr)){
			$errstr=$it618_wike_lang['s934'];
			$errstr=str_replace("{type}",$it618_wike['wike_attachmenttype'],$errstr);
		}
		
		$filesize=$_FILES['it618_upfile']['size']/1024/1024;
		if($filesize>$it618_wike['wike_attachmentsize']&&$errstr==''){ 
			$errstr=$it618_wike_lang['s935'].$it618_wike['wike_attachmentsize'].'M'.$it618_wike_lang['s936'];
		}
		
		$wike_attachmentgroups=(array)unserialize($it618_wike['wike_attachmentgroups']);
		if(!in_array($_G['groupid'], $wike_attachmentgroups)&&$errstr==''){
			$errstr=$it618_wike_lang['s937'];
		}
		
		$sumsize=DB::result_first("SELECT sum(it618_attachmentsize) FROM ".DB::table('it618_wike')." WHERE it618_uid=".$it618_wike_wike['it618_uid']);	
		if($sumsize>$it618_wike['wike_attachmentsizes']&&$errstr==''){
			$errstr=$it618_wike_lang['s938'].$it618_wike['wike_attachmentsizes'].'M'.$it618_wike_lang['s939'];
		}
			
		if($errstr==''){
			$filepath = "source/plugin/it618_wike/attachment/";
			$filename=md5(FORMHASH.$getwikeid.$_G['timestamp']).".".$filetype;

			if(@copy($_FILES['it618_upfile']['tmp_name'], $filepath.$filename) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['it618_upfile']['tmp_name'], $filepath.$filename))) {
				@unlink($_FILES['it618_upfile']['tmp_name']);
				
				$tmparr=@getimagesize($filepath.$filename);
				if($tmparr === FALSE){

					if($filetype=='gif'||$filetype=='jpg'||$filetype=='jpeg'||$filetype=='png'){
						if(file_exists($filepath.$filename)){
							$result=unlink($filepath.$filename);
						}
						echo 'err';exit;
					}
				}else{
					$imgwidth=3000;
					it618_wike_imagetosmall1($filepath.$filename,$imgwidth);
				}
				
				if($it618_wike_wike['it618_attachment']!=$_G['siteurl'].$filepath.$filename){
					$tmparr=explode("source",$it618_wike_wike['it618_attachment']);
					$it618_attachment=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_attachment)){
						$result=unlink($it618_attachment);
					}
					$downcount=0;
				}else{
					$downcount=$it618_wike_wike['it618_attachmentdown'];	
				}
				
				C::t('#it618_wike#it618_wike')->update($it618_wike_wike['id'],array(
					'it618_attachment' => $_G['siteurl'].$filepath.$filename,
					'it618_attachmentsize' => $filesize,
					'it618_attachmentdown' => $downcount,
					'it618_attachmenttime' => $_G['timestamp']
				));

			}
		}
	}
	
	if($errstr==''){
		$isok=1;
	}
}

if(submitcheck('submitattachmentdel')&&$errstr==''){
	$tmparr=explode("source",$it618_wike_wike['it618_attachment']);
	$it618_attachment=DISCUZ_ROOT.'./source'.$tmparr[1];
	
	if(file_exists($it618_attachment)){
		$result=unlink($it618_attachment);
	}
	
	C::t('#it618_wike#it618_wike')->update($it618_wike_wike['id'],array(
		'it618_attachment' => '',
		'it618_attachmentsize' => 0,
		'it618_attachmentdown' => 0,
		'it618_attachmenttime' => 0
	));
	
	$isok=1;
	$isdel=1;
}

$_G['mobiletpl'][2]='/';
include template('it618_wike:attachment');
?>