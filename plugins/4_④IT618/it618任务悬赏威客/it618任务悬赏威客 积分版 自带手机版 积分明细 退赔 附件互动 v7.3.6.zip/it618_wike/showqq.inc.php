<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

$type=intval($_GET['type']);
$tid=intval($_GET['tid']);
$uid=intval($_GET['uid']);

$adminauthor=0;
if($_G['uid']>0){
	$tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
	for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
	   if($_G['uid']==$tmpwikeadmin[$tmpi]){
		   $adminauthor=1;
		   break;
	   }
	}
}

if($type<=0||$tid<=0||$uid<=0)$errstr=$it618_wike_lang['s555'];

if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." where it618_tid=".$tid)){
	if($adminauthor==0){
		if($type==1){
			$getwikecounttmp=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$it618_wike_main['it618_tid']." and it618_uid=".$_G['uid']);
			if($getwikecounttmp==0)$errstr=$it618_wike_lang['s556'];
		}else{
			if($it618_wike_main['it618_uid']!=$_G['uid'])$errstr=$it618_wike_lang['s556'];
		}
	}
}else{
	$errstr=$it618_wike_lang['s555'];
}

if($errstr==''){
	$it618_wike_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_user')." where it618_uid=".$uid);
	
	$it618_bztel=$it618_wike_user['it618_tel'];
	$it618_tel=$it618_wike_user['it618_tel'];
	$it618_qq=$it618_wike_user['it618_qq'];
	$it618_wx=$it618_wike_user['it618_wx'];
	
	if($it618_wike['wike_rzdatatype']==1){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$uid)){
				$it618_bztel=$it618_members_user['it618_tel'];
			}
		}
	}
	
	if($it618_wike['wike_rzdatatype']==2){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$uid)){
				$it618_bztel=$it618_members_rzuser['it618_tel'];
				$it618_qq=$it618_members_rzuser['it618_qq'];
				$it618_wx=$it618_members_rzuser['it618_wx'];
			}
		}
	}
	
	$allpostcount = C::t('#it618_wike#it618_wike_main')->count_by_search('','',$uid,0);
	$allwikecount =C::t('#it618_wike#it618_wike_main')->count_by_search('','',0,$uid);
	
	$allpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_pf')." WHERE it618_getuid=".$uid);
	
	if($allpfcount==0){
		$pfcss='green';
	}else{
		$pfcss='red';
	}
	
	$pfstr=$it618_wike_lang['s978'].'<font color="'.$pfcss.'">'.$allpfcount.'</font>'.$it618_wike_lang['s979'];
	
	if($it618_qq!=''){
		$qqstr='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$it618_qq.'&site=qq&menu=yes"><img src="source/plugin/it618_wike/images/qq.png" align="absmiddle" style="border:none;width:22px;margin-right:3px"/>'.$it618_qq.'</a>';
	}else{
		$qqstr='<img src="source/plugin/it618_wike/images/qq.png" align="absmiddle" style="border:none;width:22px;margin-right:3px"/>'.$it618_wike_lang['s965'];
	}
	
	if($it618_bztel!=''){
		if($_GET['wap']==1){
			$bztelstr='<a href="tel://'.$it618_bztel.'"><img src="source/plugin/it618_wike/images/tel.png" align="absmiddle" style="border:none;width:22px;margin-left:2px"/>'.$it618_bztel.'</a>';
		}else{
			$bztelstr='<img src="source/plugin/it618_wike/images/tel.png" align="absmiddle" style="border:none;width:22px;margin-right:3px"/>'.$it618_bztel;
		}
	}else{
		$bztelstr='<img src="source/plugin/it618_wike/images/tel.png" align="absmiddle" style="border:none;width:22px;margin-right:3px"/>'.$it618_wike_lang['s965'];
	}
	
	if($it618_wx!=''){
		$wxstr='<img src="source/plugin/it618_wike/images/wx.png" align="absmiddle" style="border:none;width:22px;margin-right:3px"/>'.$it618_wx;
	}else{
		$wxstr='<img src="source/plugin/it618_wike/images/wx.png" align="absmiddle" style="border:none;width:22px;margin-right:3px"/>'.$it618_wike_lang['s965'];
	}
	
	$tmpstr= '
	<tr><td><font color=green><b>'.it618_wike_getusername($uid).'</b></font> <a href="javascript:" style="text-decoration:none" onclick="showwike(10001,'.$uid.')">'.it618_wike_getlang('s348').'(<font color="red">'.$allpostcount.'</font>)</a> <a href="javascript:" style="text-decoration:none" onclick="showwike(10002,'.$uid.')">'.it618_wike_getlang('s349').'(<font color="red">'.$allwikecount.'</font>)</a> '.$pfstr.'</td></tr>
	<tr><td><font color=#999>'.it618_wike_getlang('1s548').'</font>'.$qqstr.'</td></tr>
	<tr><td><font color=#999>'.it618_wike_getlang('1s553').'</font>'.$bztelstr.'</td></tr>
	<tr><td><font color=#999>'.it618_wike_getlang('1s551').'</font>'.$wxstr.'</td></tr>
	<tr><td style="border:none;">'.$it618_wike_user['it618_bz'].'</td></tr>
	';
}else{
	$tmpstr= '
	<tr><td style="border:none;">'.$errstr.'</td></tr>
	';
}

$_G['mobiletpl'][2]='/';

if($_GET['wap']!=1){
	include template('it618_wike:showqq');
}else{
	include template('it618_wike:showwapqq');
}
?>