<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsCredits,$it618_wike;
require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';
$navtitle = $it618_wike['seotitle'];
$metakeywords = $it618_wike['seokeywords'];
$metadescription = $it618_wike['seodescription'];

if(wike_is_mobile()){
	$tmpurl=it618_wike_getrewrite('wike_wap','','plugin.php?id=it618_wike:wap');
	dheader("location:$tmpurl");
}

$n=1;
$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'wikeclass1\',0,0)" name="wikeclass1"><span>'.$it618_wike_lang['s396'].'</span></a>';
$wike_forums = unserialize($it618_wike["wike_forums"]);
foreach($wike_forums as $key => $fid) {
	$tmpforumname=it618_wike_getforumname($fid);
	if($tmpforumname!=''){
		$classtmp.='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'wikeclass1\','.$n.','.$fid.')" name="wikeclass1"><span>'.$tmpforumname.'</span></a>';
		$n=$n+1;
	}
}

$il1i1l=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$il1i1l[]=substr($_GET['id'],$i,1);}
if(count($il1i1l)!=10)return;
if($il1i1l[6]!='w')return;

if($_G['uid']>0){
	$menuusername=$_G['username'];
	$u_avatarimg=it618_wike_discuz_uc_avatar($_G['uid'],'middle');
	$creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	$creditnum=DB::result_first("select extcredits".$it618_wike['wike_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	
	$postcount = C::t('#it618_wike#it618_wike_main')->count_by_search('','',$_G['uid'],0);
	$postmoney = C::t('#it618_wike#it618_wike_main')->sum_jlmoney_by_search('','',$_G['uid'],0);
	if($postmoney=='')$postmoney=0;
	
	$getcount = C::t('#it618_wike#it618_wike_main')->count_by_search('','',0,$_G['uid']);
	$getmoney = C::t('#it618_wike#it618_wike_main')->sum_jlmoney_by_search('','',0,$_G['uid']);
	if($getmoney=='')$getmoney=0;
	
	$postpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_pf')." WHERE it618_postuid=".$_G['uid']);
	$getpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_pf')." WHERE it618_getuid=".$_G['uid']);
	
	$postpfmoney = DB::result_first("SELECT sum(it618_getwikemoney) FROM ".DB::table('it618_wike_pf')." WHERE it618_postuid=".$_G['uid']);
	$getpfmoney = DB::result_first("SELECT sum(it618_getwikemoney) FROM ".DB::table('it618_wike_pf')." WHERE it618_getuid=".$_G['uid']);
	
	$wappostpf=it618_wike_getrewrite('wike_wap','pf@1@'.$_G['uid'],'plugin.php?id=it618_wike:wap&pagetype=pf&cid=1&uid='.$_G['uid']);
	$wapgetpf=it618_wike_getrewrite('wike_wap','pf@2@'.$_G['uid'],'plugin.php?id=it618_wike:wap&pagetype=pf&cid=2&uid='.$_G['uid']);
}

$wike_forums = unserialize($it618_wike["wike_forums"]);
$forumcount=count($wike_forums);

if($forumcount==1){
	$posttmp='href="forum.php?mod=post&action=newthread&fid='.$wike_forums[0].'&paytype=credit" target="_blank"';
}else{
	$posttmp='href="javascript:" onclick="showpost()"';
}

if($it618_wike['wike_ispostrz']==1){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
			
			$posttmp='href="javascript:" onclick="alert(\''.it618_wike_getlang('s575').'\');jQuery(\'.it618_members\').first().click()"';

		}
	}
}

//�ֲ�
$wike_focus_pics = $it618_wike['wike_focus_pics'];
$wike_focus_pics=explode("|",str_replace(array("\r\n", "\r", "\n"), '|', $it618_wike['wike_focus_pics']));
if($il1i1l[5]!='_')return;
foreach($wike_focus_pics as $key => $wike_focus_pic){
	if($wike_focus_pic!=""){
		$tmparr=explode("==",$wike_focus_pic);
		$str_focus.='<div><a href="'.$tmparr[1].'" target="_blank"><img src="'.$tmparr[0].'"/></a></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_wike_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_wike_gonggao = DB::fetch($query)) {
	$it618_title=$it618_wike_gonggao['it618_title'];
	
	if($it618_wike_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_wike_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_wike_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_wike_gonggao['it618_url'].'" target="_blank" title="'.$it618_wike_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

//��������
$query = DB::query("SELECT it618_uid,count(1) as wikecount FROM ".DB::table('it618_wike_main')." group by it618_uid order by wikecount desc limit 0,".$it618_wike['wike_rightcount']);
$n=1;
while($it618_wike_wike =DB::fetch($query)) {
	$uid=$it618_wike_wike['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$postph.='<li><span style="float:right"><font color=red>'.$it618_wike_wike['wikecount'].'</font> '.it618_wike_getlang('s331').'</span><span class="phnum'.$tmpcss.'">'.$n.'</span><a href="home.php?mod=space&uid='.$uid.'" target="_blank">'.it618_wike_getauthor($uid).'</a></li>';
	$n=$n+1;
}
$postph=it618_wike_rewriteurl($postph);
$il1i1l=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$il1i1l[]=substr($_GET['id'],$i,1);}
if($il1i1l[9]!='e')return;

//�н�����
$query = DB::query("SELECT it618_uid,count(1) as getcount FROM ".DB::table('it618_wike')." group by it618_uid order by getcount desc limit 0,".$it618_wike['wike_rightcount']);
$n=1;
while($it618_wike_wike =DB::fetch($query)) {
	$uid=$it618_wike_wike['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$getph.='<li><span style="float:right"><font color=red>'.$it618_wike_wike['getcount'].'</font> '.it618_wike_getlang('s331').'</span><span class="phnum'.$tmpcss.'">'.$n.'</span><a href="home.php?mod=space&uid='.$uid.'" target="_blank">'.it618_wike_getauthor($uid).'</a></li>';
	$n=$n+1;
}
$getph=it618_wike_rewriteurl($getph);
if($il1i1l[6]!='w')return;

//��������
$query = DB::query("SELECT it618_uid,sum(it618_creditnum) as money FROM ".DB::table('it618_wike')." group by it618_uid order by money desc limit 0,".$it618_wike['wike_rightcount']);
$n=1;
while($it618_wike_wike =DB::fetch($query)) {
	$uid=$it618_wike_wike['it618_uid'];
	if($n<=3)$tmpcss=' phnum1';else $tmpcss='';
	$moneyph.='<li><span style="float:right"><font color=red>'.$it618_wike_wike['money'].'</font> '.$wike_creditname.'</span><span class="phnum'.$tmpcss.'">'.$n.'</span><a href="home.php?mod=space&uid='.$uid.'" target="_blank">'.it618_wike_getauthor($uid).'</a></li>';
	$n=$n+1;
}
$moneyph=it618_wike_rewriteurl($moneyph);
if($il1i1l[6]!='w')return;

//����н�
$query = DB::query("SELECT * FROM ".DB::table('it618_wike')." order by id desc LIMIT 0, 10");
while($it618_wike_wike = DB::fetch($query)) {

	$username=it618_wike_getauthor($it618_wike_wike['it618_uid']);
	$subject=it618_wike_getsubject($it618_wike_wike['it618_tid']);
	
	$newgetwikelist.='<li><font color=red>'.it618_wike_gettime($it618_wike_wike['it618_time']).'</font> <font color="#333333">'.$username.'</font> '.it618_wike_getlang('s332').'<br>[<a href="forum.php?mod=viewthread&tid='.$it618_wike_wike['it618_tid'].'" target="_blank">'.$subject.'</a>]</li>';
}
$newgetwikelist=it618_wike_rewriteurl($newgetwikelist);

//�������
$query = DB::query("SELECT * FROM ".DB::table('it618_wike')." where it618_creditnum>0 order by id desc LIMIT 0, 10");
while($it618_wike_wike = DB::fetch($query)) {

	$username=it618_wike_getauthor($it618_wike_wike['it618_uid']);
	$subject=it618_wike_getsubject($it618_wike_wike['it618_tid']);
	
	$newgetmoney.='<li><font color=red>'.it618_wike_gettime($it618_wike_wike['it618_time']).'</font> <font color="#333333">'.$username.'</font> '.it618_wike_getlang('s333').' [<a href="forum.php?mod=viewthread&tid='.$it618_wike_wike['it618_tid'].'" target="_blank">'.$subject.'</a>] '.it618_wike_getlang('s334').'<font color=red>'.$it618_wike_wike['it618_creditnum'].'</font> '.$wike_creditname.'</li>';
}
$newgetmoney=it618_wike_rewriteurl($newgetmoney);

$listwike=getwikelist();

if($it618_wike['wike_width']<960)$it618_wike['wike_width']=960;
$w4=708;$w8=680;
$w=$it618_wike['wike_width']-960;
$w1=960+$w;$w2=716+$w;$w3=710+$w;$w4=708+$w-3;$w5=680+$w-5;$w6=698+$w;$w7=704+$w;$w8=693+$w-12;

$strcss='<style>
		.grid_c2a{width:'.$w1.'px;}
		.mainbar,#goodsfind,.mod_auction_goods,.game_act_filter{width:'.$w2.'px;}
		#slides-thumbnail,.game_act_filter{width:'.$w3.'px}
		#slides-thumbnail .slidesjs-slide img{width:'.$w4.'px;height:'.$it618_wike['wike_foucsheight'].'px;}
		.finddiv{width:'.$w5.'px;}
		.finddiv1{width:'.($w5+10).'px;}
		.wikelisttable tr td a{font-size:14px}
		</style>';

$moden=0;
$wike_modes=(array)unserialize($it618_wike['wike_modes']);
if(!in_array(1, $wike_modes)){$mode1='style="display:none"';$moden=$moden+1;}
if(!in_array(2, $wike_modes)){$mode2='style="display:none"';$moden=$moden+1;}
if(!in_array(3, $wike_modes)){$mode3='style="display:none"';$moden=$moden+1;}

if($IsCredits==1){
	$tmpuser1='<a class="it618_credits" href="javascript:">';
	$tmpuser2='</a>';
}

$allcount = C::t('#it618_wike#it618_wike_main')->count_by_search();
$allmoney = C::t('#it618_wike#it618_wike_main')->sum_jlmoney_by_search();

include template('it618_wike:index');
?>