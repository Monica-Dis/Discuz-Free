<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';


if($_GET['ac']=="getmode"){
	$modeid=intval($_GET['modeid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_wike/getmode.func.php';
	
	if($it618_wike_diy=C::t('#it618_wike#it618_wike_diy')->fetch_by_id($modeid)){
		if($it618_wike_diy['it618_isjs']==1){
			if((time()-$it618_wike_diy["it618_time"])<(60*$it618_wike_diy["it618_catchtime"])){
				exit;
			}else{
				C::t('#it618_wike#it618_wike_diy')->update_it618_time_by_id(time(),$it618_wike_diy["id"]);
			}
			
			$tmpstr = it618_wike_getmodecontent($it618_wike_diy['it618_type'],$it618_wike_diy['it618_sql'],$it618_wike_diy['it618_modecode'],$it618_wike_diy['it618_count']);
			$tmpstr=str_replace(array("\r\n", "\r", "\n"),"",$tmpstr);
			$tmpstr=str_replace("'",'"',$tmpstr);
			
			echo "document.write('".$tmpstr."')";
		}
	}
	exit;
}

if($_GET['formhash']!=FORMHASH)exit;


if($_GET['ac']=="savebz"){
	if($_G['uid']<=0){
		$errstr=$it618_wike_lang['s932'];
	}else{
		$getwikeid=intval($_GET['getwikeid']);
	
		if($it618_wike_wike=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike')." WHERE id=".$getwikeid)){
			$tid=$it618_wike_wike['it618_tid'];
			
			if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)){
				$it618_attachmenttime=date('Y-m-d H:i:s', $it618_wike_wike['it618_attachmenttime']);
				$it618_postbztime=date('Y-m-d H:i:s', $it618_wike_wike['it618_postbztime']);
				$it618_getbztime=date('Y-m-d H:i:s', $it618_wike_wike['it618_getbztime']);
				
				$adminauthor=0;
				if($_G['uid']>0){
					$tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
					for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
					   if($_G['uid']==$tmpwikeadmin[$tmpi]){
						   $adminauthor=1;
						   break;
					   }
					}
				}
				
				if($it618_wike_main['it618_uid']==$_G['uid']){
					$ispostwike=1;
				}
				
				if($it618_wike_wike['it618_uid']==$_G['uid']){
					$isgetwike=1;
				}
				
				if($ispostwike!=1&&$isgetwike!=1&&$adminauthor!=1){
					$errstr=$it618_wike_lang['s933'];
				}
			}else{
				$errstr=$it618_wike_lang['s2'];
			}
		}else{
			$errstr=$it618_wike_lang['s2'];
		}
	}
	
	if($errstr==''){
		$it618_postbz=it618_wike_utftogbk($_GET['it618_postbz']);
		$it618_getbz=it618_wike_utftogbk($_GET['it618_getbz']);
		
		if($adminauthor==1){
			C::t('#it618_wike#it618_wike')->update($it618_wike_wike['id'],array(
				'it618_postbz' => $it618_postbz,
				'it618_postbztime' => $_G['timestamp'],
				'it618_getbz' => $it618_getbz,
				'it618_getbztime' => $_G['timestamp']
			));
		}
		
		if($ispostwike==1){
			C::t('#it618_wike#it618_wike')->update($it618_wike_wike['id'],array(
				'it618_postbz' => $it618_postbz,
				'it618_postbztime' => $_G['timestamp']
			));
		}
		
		if($isgetwike==1){
			C::t('#it618_wike#it618_wike')->update($it618_wike_wike['id'],array(
				'it618_getbz' => $it618_getbz,
				'it618_getbztime' => $_G['timestamp']
			));
		}
		
		if($it618_postbz!=$it618_wike_wike['it618_postbz']){
			C::t('#it618_wike#it618_wike')->update($it618_wike_wike['id'],array(
				'it618_postbzread' => 0
			));
		}
		if($it618_getbz!=$it618_wike_wike['it618_getbz']){
			C::t('#it618_wike#it618_wike')->update($it618_wike_wike['id'],array(
				'it618_getbzread' => 0
			));
		}
		
		echo 'ok';
	}else{
		echo $errstr;
	}
	exit;
}

$adminauthor=0;
if($_G['uid']>0){
	$tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
	for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
	   if($_G['uid']==$tmpwikeadmin[$tmpi]){
		   $adminauthor=1;
		   break;
	   }
	}
}


if($_GET['ac']=="editwike"){
	$uid = $_G['uid'];
	$tid = intval($_GET['tid']);
	$it618_read = intval($_GET['it618_read']);
	$it618_hfread = intval($_GET['it618_hfread']);
	$it618_select = intval($_GET['it618_select']);
	$it618_state = intval($_GET['it618_state']);
	$it618_mancount = intval($_GET['it618_mancount']);
	$it618_bmmoney = intval($_GET['it618_bmmoney']);
	$it618_moneycount1 = intval($_GET['it618_moneycount1']);
	$it618_moneycount2 = intval($_GET['it618_moneycount2']);
	$it618_getwikemoney = intval($_GET['it618_getwikemoney']);
	$wike_groups=(array)unserialize($it618_wike['wike_groups']);
	$wike_wikemancount=explode(",",$it618_wike['wike_wikemancount']);
	if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
	if($uid>0){
		if(in_array($_G['groupid'], $wike_groups)||$adminauthor==1){
			$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
			if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)){
				$postuid=$it618_wike_main['it618_uid'];
				if($postuid!=$uid&&$adminauthor!=1){
					it618_showmessage(it618_wike_getlang('s265'), '', array(), array('alert' => 'error'));exit;
				}
				$it618_time2=strtotime($_GET['it618_time2']);
				if($liii1il[6]!='w')exit;
				
				$it618_mode=$it618_wike_main['it618_mode'];
				$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
				if($it618_wike_main['it618_state']==1){
					it618_showmessage(it618_wike_getlang('s48'), '', array(), array('alert' => 'error'));exit;
				}
				
				$bmmoney=DB::result_first("SELECT it618_bmmoney FROM ".DB::table('it618_wike_grouppower')." WHERE it618_groupid=".$_G['groupid']);
				if($it618_bmmoney>$bmmoney){
					it618_showmessage(it618_wike_getlang('s945').$bmmoney.$wike_creditname.it618_wike_getlang('s946'), '', array(), array('alert' => 'error'));exit;
				}
				
				if($it618_state==10&&$it618_time2<=$_G['timestamp']){
					it618_showmessage(it618_wike_getlang('s66'), '', array(), array('alert' => 'error'));exit;
				}
		
				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
				$wike_credit=$it618_wike['wike_credit'];
				$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
				$curcreditcount=DB::result_first("select extcredits".$wike_credit." from ".DB::table('common_member_count')." where uid=".$postuid);
				if($it618_mode==3){
					$it618_moneycount2=$it618_wike_main['it618_moneycount2'];
					$it618_mancount_cur=$it618_wike_main['it618_mancount'];
					$it618_mancount_cur1=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_creditnum>0 and it618_tid=$tid");
					
					if($it618_mancount<=0){
						it618_showmessage(it618_wike_getlang('s325'), '', array(), array('alert' => 'error'));exit;
					}
					
					if($it618_mancount>$wike_wikemancount[2]){
						it618_showmessage($it618_wike_lang['s547'].'<font color=red>'.$wike_wikemancount[2].'</font>', '', array(), array('alert' => 'error'));exit;
					}
					
					if($it618_mancount<$it618_mancount_cur1){
						it618_showmessage(it618_wike_getlang('s266'), '', array(), array('alert' => 'error'));exit;
					}
					
					$it618_posttc=$it618_wike_main['it618_tc'];
					$it618_tcnum=intval($it618_posttc*$it618_moneycount2*($it618_mancount-$it618_mancount_cur)/100);if($it618_posttc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];
					if($curcreditcount<(($it618_mancount-$it618_mancount_cur)*$it618_moneycount2+$it618_tcnum)){
						it618_showmessage(it618_wike_getlang('s267').$wike_creditname."(<font color=red>".$curcreditcount."</font>)".it618_wike_getlang('s268'), '', array(), array('alert' => 'error'));exit;
					}
					
					$it618_posttc=$it618_wike_main['it618_tc'];
					$tmpmoney=($it618_mancount-$it618_mancount_cur)*$it618_moneycount2;
					$tmptcnum=intval($it618_posttc*$tmpmoney/100);if($it618_posttc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];
					if($tmpmoney>0){
						if($curcreditcount<($tmpmoney+$tmptcnum)){
							it618_showmessage(it618_wike_getlang('s267').$wike_credit."(<font color=red>".$curcreditcount."</font>)".it618_wike_getlang('s268'), '', array(), array('alert' => 'error'));exit;
						}else{
							updatemembercount($postuid,array($wike_credit=>(0-$tmpmoney)), 1, '', $tid,'',it618_wike_getcreditlog('wike_edit'),it618_wike_getcreditlog($it618_wike_lang['s607'],$tid));
							if($it618_tcnum>0)updatemembercount($postuid,array($wike_credit=>(0-$it618_tcnum)), 1, '', $tid,'',it618_wike_getcreditlog('wike_edit'),it618_wike_getcreditlog($it618_wike_lang['s608'],$tid));
						}
					}else{
						updatemembercount($postuid,array($wike_credit=>(0-$tmpmoney)), 1, '', $tid,'',it618_wike_getcreditlog('wike_edit'),it618_wike_getcreditlog($it618_wike_lang['s606'],$tid));
					}
					
					
					if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
					
					if($_GET['it618_uids']!=''){
						$tmpuidsarr=explode(",",$_GET['it618_uids']);
						for($i=0;$i<count($tmpuidsarr);$i++){
							if(it618_wike_getusername(intval($tmpuidsarr[$i]))!=''){
								$tmpuids.=$tmpuidsarr[$i].',';
							}
						}
						if($tmpuids!=''){
							$tmpuids=$tmpuids.'@';
							$tmpuids=str_replace(",@","",$tmpuids);
						}
					}
					
					C::t('#it618_wike#it618_wike_main')->update($it618_wike_main['id'],array(
						'it618_mancount' => $it618_mancount,
						'it618_bmmoney' => $it618_bmmoney,
						'it618_getwikemoney' => $it618_getwikemoney,
						'it618_time2' => $it618_time2,
						'it618_read' => $it618_read,
						'it618_hfread' => $it618_hfread,
						'it618_select' => $it618_select,
						'it618_state' => $it618_state,
						'it618_uids' => $tmpuids
					));
					
					it618_showmessage(it618_wike_getlang('s88'), '', array(), array('alert' => 'right'));exit;
					
				}else{
					if($it618_mode==2){
						if($it618_mancount>$wike_wikemancount[1]){
							it618_showmessage($it618_wike_lang['s547'].'<font color=red>'.$wike_wikemancount[1].'</font>', '', array(), array('alert' => 'error'));exit;
						}
					}else{
						if($it618_mancount>$wike_wikemancount[0]){
							it618_showmessage($it618_wike_lang['s547'].'<font color=red>'.$wike_wikemancount[0].'</font>', '', array(), array('alert' => 'error'));exit;
						}
					}
					
					$it618_mancount_cur=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_ok=1 and it618_tid=$tid");
					if($liii1il[5]!='_')exit;
					$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
					if($it618_mancount<=0){
						it618_showmessage(it618_wike_getlang('s83'), '', array(), array('alert' => 'error'));exit;
					}elseif($it618_mancount<$it618_mancount_cur){
						it618_showmessage(it618_wike_getlang('s85')." ".$it618_mancount_cur, '', array(), array('alert' => 'error'));exit;
					}
					if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
					if($it618_moneycount2<0){
						it618_showmessage(it618_wike_getlang('s42'), '', array(), array('alert' => 'error'));exit;
					}
					
					if($it618_mode==1){
						if($it618_moneycount2<$it618_wike_main['it618_moneycount2']){
							if($adminauthor==1){
								$tidwikesum=DB::result_first("select sum(it618_creditnum) from ".DB::table('it618_wike')." where it618_tid=$tid");
								if($it618_moneycount2<$tidwikesum){
									it618_showmessage(str_replace("{yfmoney}",$tidwikesum,it618_wike_getlang('s421')), '', array(), array('alert' => 'error'));exit;
								}
								$iseditok=1;
							}else{
								it618_showmessage(it618_wike_getlang('s281'), '', array(), array('alert' => 'error'));exit;
							}
						}else{
							$iseditok=2;
						}
						
						if($iseditok>=1){
							$it618_posttc=$it618_wike_main['it618_tc'];
							$it618_moneycount_old=$it618_wike_main['it618_moneycount2'];
							$it618_tcnum_old=intval($it618_posttc*$it618_moneycount_old/100);if($it618_posttc>0&&$it618_tcnum_old==0)$it618_tcnum_old=$it618_wike['wike_tccheck'];
							$it618_tcnum=intval($it618_posttc*$it618_moneycount2/100);if($it618_posttc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];

							if($iseditok==1){
								updatemembercount($postuid,array($wike_credit=>($it618_moneycount_old-$it618_moneycount2)), 1, '', $tid,'',it618_wike_getcreditlog('wike_edit'),it618_wike_getcreditlog($it618_wike_lang['s721'],$tid));
								if($it618_tcnum-$it618_tcnum_old!=0)updatemembercount($postuid,array($wike_credit=>($it618_tcnum_old-$it618_tcnum)), 1, '', $tid,'',it618_wike_getcreditlog('wike_edit'),it618_wike_getcreditlog($it618_wike_lang['s722'],$tid));
							}else{
								if($adminauthor==1){
									$tmpadminstr=$it618_wike_lang['s723'];
								}
								if($it618_moneycount2+$it618_tcnum>$curcreditcount+$it618_moneycount_old+$it618_tcnum_old){
									$tmpstr=$it618_wike_lang['s568'];
									$tmpstr=str_replace("{num1}",($it618_moneycount2+$it618_tcnum-$it618_moneycount_old-$it618_tcnum_old).$wike_creditname,$tmpstr);
									$tmpstr=str_replace("{num2}",$curcreditcount.$wike_creditname,$tmpstr);
									it618_showmessage($tmpstr, '', array(), array('alert' => 'error'));exit;
								}
								
								updatemembercount($postuid,array($wike_credit=>($it618_moneycount_old-$it618_moneycount2)), 1, '', $tid,'',it618_wike_getcreditlog('wike_edit'),it618_wike_getcreditlog($tmpadminstr.$it618_wike_lang['s584'],$tid));
								if($it618_tcnum-$it618_tcnum_old!=0)updatemembercount($postuid,array($wike_credit=>($it618_tcnum_old-$it618_tcnum)), 1, '', $tid,'',it618_wike_getcreditlog('wike_edit'),it618_wike_getcreditlog($tmpadminstr.$it618_wike_lang['s585'],$tid));
							}
						
							DB::query('update '.DB::table('it618_wike_main').' set it618_moneycount2='.$it618_moneycount2.' where it618_tid='.$tid);
						}
					}
					
					if($_GET['it618_uids']!=''){
						$tmpuidsarr=explode(",",$_GET['it618_uids']);
						for($i=0;$i<count($tmpuidsarr);$i++){
							if(it618_wike_getusername(intval($tmpuidsarr[$i]))!=''){
								$tmpuids.=$tmpuidsarr[$i].',';
							}
						}
						if($tmpuids!=''){
							$tmpuids=$tmpuids.'@';
							$tmpuids=str_replace(",@","",$tmpuids);
						}
					}
					
					C::t('#it618_wike#it618_wike_main')->update($it618_wike_main['id'],array(
						'it618_mancount' => $it618_mancount,
						'it618_bmmoney' => $it618_bmmoney,
						'it618_getwikemoney' => $it618_getwikemoney,
						'it618_time2' => $it618_time2,
						'it618_read' => $it618_read,
						'it618_hfread' => $it618_hfread,
						'it618_select' => $it618_select,
						'it618_state' => $it618_state,
						'it618_uids' => $tmpuids
					));
					
					$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
					if($liii1il[0]!='i')exit;

					it618_showmessage(it618_wike_getlang('s231'), '', array(), array('alert' => 'right'));exit;
				}
			}
		}
	}
	exit;
}


if($_GET['ac']=="okwike"){
	$uid = $_G['uid'];
	$tid = intval($_GET['tid']);
	$wike_credit=$it618_wike['wike_credit'];
	$wike_jlcredit=$it618_wike['wike_jlcredit'];
	$wike_getjlcredit=$it618_wike['wike_getjlcredit'];
	$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	$wike_groups=(array)unserialize($it618_wike['wike_groups']);
	
	if($uid>0){
		if(in_array($_G['groupid'], $wike_groups)||$adminauthor==1){
			$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
			if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)){
				$postuid=$it618_wike_main['it618_uid'];
				if($postuid!=$uid&&$adminauthor!=1){
					it618_showmessage(it618_wike_getlang('s265'), '', array(), array('alert' => 'error'));exit;
				}
				
				if($it618_wike['wike_oktime']>0){
					if(($_G['timestamp']-$it618_wike['wike_oktime']*3600)<$it618_wike_main['it618_time1']){
						$it618_wike_lang['s1028']=str_replace("{oktime}",$it618_wike['wike_oktime'],$it618_wike_lang['s1028']);
						$tmptime=round(($_G['timestamp']-$it618_wike_main['it618_time1'])/3600,2);
						$it618_wike_lang['s1028']=str_replace("{time}",$tmptime,$it618_wike_lang['s1028']);
						echo $it618_wike_lang['s1028'];exit;
					}
				}
				
				$setarr = array(
					'it618_state' => 1,
					'it618_time2' => $_G['timestamp']
				);
				
				$wid=$it618_wike_main['id'];
				$it618_mode=$it618_wike_main['it618_mode'];
				$getwikecount=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_ok=1 and it618_tid=$tid");
				
				if($getwikecount==0){
					$it618_uid=$it618_wike_main['it618_uid'];
					$it618_moneycount2=$it618_wike_main['it618_moneycount2'];
					$it618_mancount=$it618_wike_main['it618_mancount'];
					$it618_posttc=$it618_wike_main['it618_tc'];
					
					$query = DB::query("SELECT * FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid." order by id");
					$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
					if($liii1il[8]!='k')exit;
					while($it618_wike_wike =DB::fetch($query)) {
						$tmparr=explode("source",$it618_wike_wike['it618_attachment']);
						$it618_attachment=DISCUZ_ROOT.'./source'.$tmparr[1];
						
						if(file_exists($it618_attachment)){
							$result=unlink($it618_attachment);
						}

						if($it618_wike_wike['it618_getwikemoney']>0){
							updatemembercount($it618_wike_wike['it618_uid'],array($wike_credit=>$it618_wike_wike['it618_getwikemoney']), 1, '', $tid,'',it618_wike_getcreditlog('wike_bzj'),it618_wike_getcreditlog($it618_wike_lang['s609'],$tid));
						}
						
						if($it618_wike_wike['it618_bmmoney']>0){
							updatemembercount($it618_wike_wike['it618_uid'],array($wike_credit=>$it618_wike_wike['it618_bmmoney']), 1, '', $tid,'',it618_wike_getcreditlog('wike_bm'),it618_wike_getcreditlog($it618_wike_lang['s610'],$tid));
							updatemembercount($it618_uid,array($wike_credit=>(0-$it618_wike_wike['it618_bmmoney'])), 1, '', $tid,'',it618_wike_getcreditlog('wike_bm'),it618_wike_getcreditlog($it618_wike_lang['s613'],$tid));
						}
					}
					
					if($it618_mode!=3){
						$it618_tcnum=intval($it618_posttc*$it618_moneycount2/100);if($it618_posttc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];

						updatemembercount($it618_uid,array($wike_credit=>$it618_moneycount2), 1, '', $tid,'',it618_wike_getcreditlog('wike_del'),it618_wike_getcreditlog($it618_wike_lang['s611'],$tid));
						if($it618_tcnum>0)updatemembercount($it618_uid,array($wike_credit=>$it618_tcnum), 1, '', $tid,'',it618_wike_getcreditlog('wike_del'),it618_wike_getcreditlog($it618_wike_lang['s612'],$tid));
					}else{
						$it618_tcnum=intval($it618_posttc*$it618_moneycount2*$it618_mancount/100);if($it618_posttc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];

						updatemembercount($it618_uid,array($wike_credit=>$it618_moneycount2*$it618_mancount), 1, '', $tid,'',it618_wike_getcreditlog('wike_del'),it618_wike_getcreditlog($it618_wike_lang['s611'],$tid));
						if($it618_tcnum>0)updatemembercount($it618_uid,array($wike_credit=>$it618_tcnum), 1, '', $tid,'',it618_wike_getcreditlog('wike_del'),it618_wike_getcreditlog($it618_wike_lang['s612'],$tid));
					}
					
					$id = C::t('#it618_wike#it618_wike_main')->update($wid,$setarr);
					
					it618_wike_sendmessage('wikeok_admin',$wid);
					it618_showmessage(it618_wike_getlang('s91'), '', array(), array('alert' => 'right'));exit;
				}
				
				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
				if($it618_mode==3){
					$it618_mancount_cur=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_creditnum>0 and it618_tid=$tid");
					$it618_mancount=$it618_wike_main['it618_mancount'];
					if($it618_mancount_cur<1){
						it618_showmessage(it618_wike_getlang('s574'), '', array(), array('alert' => 'error'));exit;
					}
					if($it618_mancount_cur!=$it618_mancount){
						$tmpstr=str_replace("{mancount}",$it618_mancount,it618_wike_getlang('s269'));
						$tmpstr=str_replace("{curmancount}",$it618_mancount_cur,$tmpstr);
						it618_showmessage($tmpstr, '', array(), array('alert' => 'error'));exit;
					}
				}elseif($it618_mode==2){
					if($getwikecount==0){
						it618_showmessage(it618_wike_getlang('s227'), '', array(), array('alert' => 'error'));exit;
					}
				}
				if($liii1il[9]!='e')exit;
				$it618_creditnumall=DB::result_first("select sum(it618_creditnum) from ".DB::table('it618_wike')." where it618_tid=$tid");
				if($it618_mode==1){
					$it618_moneycount2=$it618_wike_main['it618_moneycount2'];
					
					$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
					if($it618_creditnumall<$it618_moneycount2){
						it618_showmessage(it618_wike_getlang('s90'), '', array(), array('alert' => 'error'));exit;
					}
				}
				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
				
				$id = C::t('#it618_wike#it618_wike_main')->update($wid,$setarr);
				if($id>0){
					$it618_moneycount_cur=$it618_wike_main['it618_moneycount2'];
					$it618_posttc=$it618_wike_main['it618_tc'];
					$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
					
					if($liii1il[7]!='i')exit;

					if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
					
					if($it618_mode==2){
						DB::query('update '.DB::table('it618_wike').' set it618_creditnum='.(intval($it618_moneycount_cur/$getwikecount)).' where it618_ok=1 and it618_tid='.$tid);
					}
					
					$query = DB::query("SELECT * FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid." order by id");
					$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
					if($liii1il[8]!='k')exit;
					
					if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
						require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
					}
					
					if($union_wike_isok==1&&$it618_creditnumall>=$union_wike_post_money){
						require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
						for($i=1;$i<=8;$i++){
							$salecredit[$i]=0;
							if($wike_credit==$i){
								$salecredit[$i]=$it618_creditnumall;
							}
						}
						Union_SaleCreditsTC('it618_wike_post',$salecredit,$it618_wike_main['id'],$it618_wike_main['it618_uid']);
					}
					
					if($it618_wike_main['it618_jlbl']>0){
						$jl=intval($it618_creditnumall*$it618_wike_main['it618_jlbl']/100);
						DB::query('update '.DB::table('it618_wike_main').' set it618_jl='.$jl.' where id='.$it618_wike_main['id']);
						updatemembercount($postuid,array($wike_jlcredit=>$jl), 1, '', $tid,'',it618_wike_getcreditlog('wike_postjl'),it618_wike_getcreditlog($it618_wike_lang['s592'],$tid));
					}
					
					while($it618_wike_wike =DB::fetch($query)) {
						$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
						if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
						if($it618_wike_wike['it618_creditnum']>0){
							if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
							if($it618_mode==2){
								$it618_gettc=$it618_wike_wike['it618_tc'];
								$it618_tcnum=intval($it618_gettc*$it618_wike_wike['it618_creditnum']/100);if($it618_gettc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];
								updatemembercount($it618_wike_wike['it618_uid'],array($wike_credit=>$it618_wike_wike['it618_creditnum']), 1, '', $tid,'',it618_wike_getcreditlog('wike_getmoney'),it618_wike_getcreditlog($it618_wike_lang['s588'],$tid));
								if($it618_tcnum>0)updatemembercount($it618_wike_wike['it618_uid'],array($wike_credit=>(0-$it618_tcnum)), 1, '', $tid,'',it618_wike_getcreditlog('wike_gettc'),it618_wike_getcreditlog($it618_wike_lang['s589'],$tid));
								
								it618_wike_sendmessage('jl_user',$it618_wike_wike['id'],2);
							}
						}
						
						if($it618_wike_wike['it618_jlbl']>0&&$it618_wike_wike['it618_creditnum']>0){
							$jl=intval($it618_wike_wike['it618_creditnum']*$it618_wike_wike['it618_jlbl']/100);
							DB::query('update '.DB::table('it618_wike').' set it618_jl='.$jl.' where id='.$it618_wike_wike['id']);
							updatemembercount($it618_wike_wike['it618_uid'],array($wike_jlcredit=>$jl), 1, '', $tid,'',it618_wike_getcreditlog('wike_getjl'),it618_wike_getcreditlog($it618_wike_lang['s600'],$tid));
						}
						
						if($it618_mode!=3){
							if($it618_wike_wike['it618_getwikemoney']>0){
								updatemembercount($it618_wike_wike['it618_uid'],array($wike_credit=>$it618_wike_wike['it618_getwikemoney']), 1, '', $tid,'',it618_wike_getcreditlog('wike_bzj'),it618_wike_getcreditlog($it618_wike_lang['s598'],$tid));
							}
						}
						
						if($union_wike_isok==1&&$it618_wike_wike['it618_creditnum']>=$union_wike_get_money){
							require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
							for($i=1;$i<=8;$i++){
								$salecredit[$i]=0;
								if($wike_credit==$i){
									$salecredit[$i]=$it618_wike_wike['it618_creditnum'];
								}
							}
							Union_SaleCreditsTC('it618_wike_get',$salecredit,$it618_wike_main['id'],$it618_wike_wike['it618_uid']);
						}
					}
					it618_wike_sendmessage('wikeok_admin',$wid);
					it618_showmessage(it618_wike_getlang('s91'), '', array(), array('alert' => 'right'));exit;
				}else{
					it618_showmessage(it618_wike_getlang('s2'), '', array(), array('alert' => 'error'));exit;
				}
			}
		}
	}
	exit;
}


if($_GET['ac']=="delwike"){
	$uid = $_G['uid'];
	$tid = intval($_GET['tid']);
	$wike_delwikegroups=(array)unserialize($it618_wike['wike_delwikegroups']);
	if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
	if($uid>0){
		if(in_array($_G['groupid'], $wike_delwikegroups)||$adminauthor==1){
			$wike_credit=$it618_wike['wike_credit'];
			$count=DB::result_first("select count(1) from ".DB::table('it618_wike_main')." where it618_tid=$tid");
			
			if($count>1){
				$it618_wike_main=DB::fetch_first("select * from ".DB::table('it618_wike_main')." where it618_tid=$tid");
				DB::query("delete from ".DB::table('it618_wike_main')." where it618_tid=$tid and id!=".$it618_wike_main['id']);
			}
			
			$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}

			if($it618_wike_main=DB::fetch_first("select * from ".DB::table('it618_wike_main')." where it618_tid=$tid")){
				$postuid=$it618_wike_main['it618_uid'];
				if($postuid!=$uid&&$adminauthor!=1){
					it618_showmessage(it618_wike_getlang('s265'), '', array(), array('alert' => 'error'));exit;
				}
				if($liii1il[9]!='e')exit;
				$it618_mode=$it618_wike_main['it618_mode'];
				
				if($it618_wike_main['it618_state']!=1){
					$query = DB::query("SELECT * FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid." order by id");
					$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
					if($liii1il[8]!='k')exit;
					while($it618_wike_wike =DB::fetch($query)) {
						$tmparr=explode("source",$it618_wike_wike['it618_attachment']);
						$it618_attachment=DISCUZ_ROOT.'./source'.$tmparr[1];
						
						if(file_exists($it618_attachment)){
							$result=unlink($it618_attachment);
						}

						if($it618_mode!=3||($it618_mode==3&&$it618_wike_wike['it618_creditnum']==0)){
							updatemembercount($it618_wike_wike['it618_uid'],array($wike_credit=>$it618_wike_wike['it618_getwikemoney']), 1, '', $tid,'',it618_wike_getcreditlog('wike_bzj'),it618_wike_getcreditlog($it618_wike_lang['s605'],$tid));
						}
					}
					if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
					$it618_posttc=$it618_wike_main['it618_tc'];
					if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
					$tidwikesum=DB::result_first("select sum(it618_creditnum) from ".DB::table('it618_wike')." where it618_tid=$tid");
					if($it618_mode!=3){
						updatemembercount($it618_wike_main['it618_uid'],array($wike_credit=>($it618_wike_main['it618_moneycount2']-$tidwikesum)), 1, '', $tid,'',it618_wike_getcreditlog('wike_del'),it618_wike_getcreditlog($it618_wike_lang['s604'],$tid));
					}else{
						updatemembercount($it618_wike_main['it618_uid'],array($wike_credit=>($it618_wike_main['it618_moneycount2']*$it618_wike_main['it618_mancount']-$tidwikesum)), 1, '', $tid,'',it618_wike_getcreditlog('wike_del'),it618_wike_getcreditlog($it618_wike_lang['s604'],$tid));
					}
					
					it618_wike_deletewike($tid);
					
					it618_showmessage(it618_wike_getlang('s205'), '', array(), array('alert' => 'right'));exit;
				}else{
					it618_wike_deletewike($tid);
					it618_showmessage(it618_wike_getlang('s206'), '', array(), array('alert' => 'right'));exit;
				}
			}else{
				it618_showmessage(it618_wike_getlang('s2'), '', array(), array('alert' => 'error'));exit;
			}
		}else{
			it618_showmessage(it618_wike_getlang('s207'), '', array(), array('alert' => 'error'));exit;
		}
	}
	exit;
}


if($_GET['ac']=="settj"){
	$uid = $_G['uid'];
	$wid = intval($_GET['wid']);

	$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
	if($liii1il[2]!='6')exit;
	if($uid>0){
		if($adminauthor==1){
			$it618_wike_main=DB::fetch_first("select * from ".DB::table('it618_wike_main')." where id=$wid");
			if($it618_wike_main['it618_istj']==1)$it618_istj=0;else $it618_istj=1;
			$setarr = array(
				'it618_istj' => $it618_istj,
			);
			$id = C::t('#it618_wike#it618_wike_main')->update($wid,$setarr);
			if($id>0){
				it618_showmessage(it618_wike_getlang('s416'), '', array(), array('alert' => 'right'));exit;
			}
		}
	}
	exit;
}


if($_GET['ac']=="saveset"){
	$uid = $_G['uid'];

	$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
	if($liii1il[2]!='6')exit;
	if($uid>0){
		if($it618_wike_user=DB::fetch_first("select * from ".DB::table('it618_wike_user')." where it618_uid=$uid")){
			$setarr = array(
				'it618_tel' => it618_wike_utftogbk($_GET['it618_tel']),
				'it618_qq' => it618_wike_utftogbk($_GET['it618_qq']),
				'it618_bztel' => it618_wike_utftogbk($_GET['it618_bztel']),
				'it618_wx' => it618_wike_utftogbk($_GET['it618_wx']),
				'it618_bz' => it618_wike_utftogbk($_GET['it618_bz']),
				'it618_msgisok' => $_GET['it618_msgisok'],
			);
			$id = C::t('#it618_wike#it618_wike_user')->update($it618_wike_user['id'],$setarr);
			echo $it618_wike_lang['s535'];
		}else{
			$setarr = array(
				'it618_uid' => $_G['uid'],
				'it618_tel' => it618_wike_utftogbk($_GET['it618_tel']),
				'it618_qq' => it618_wike_utftogbk($_GET['it618_qq']),
				'it618_bztel' => it618_wike_utftogbk($_GET['it618_bztel']),
				'it618_wx' => it618_wike_utftogbk($_GET['it618_wx']),
				'it618_bz' => it618_wike_utftogbk($_GET['it618_bz']),
				'it618_msgisok' => $_GET['it618_msgisok'],
			);
			$id = C::t('#it618_wike#it618_wike_user')->insert($setarr, true);
			echo $it618_wike_lang['s535'];
		}
	}else{
		echo $it618_wike_lang['s10'];
	}
	exit;
}


if($_GET['ac']=="getwike"){
	$uid = $_G['uid'];
	$tid = intval($_GET['tid']);
	$wike_credit=$it618_wike['wike_credit'];
	$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	$wike_getwikegroups=(array)unserialize($it618_wike['wike_getwikegroups']);
	if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
	if(!in_array($_G['groupid'], $wike_getwikegroups)){
		it618_showmessage(it618_wike_getlang('s203'), '', array(), array('alert' => 'error'));exit;
	}
	
	if(!($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid))){
		it618_showmessage(it618_wike_getlang('s204'), '', array(), array('alert' => 'error'));exit;
	}else{
		if($it618_wike_main['it618_state']==0){
			it618_showmessage(it618_wike_getlang('s673'), '', array(), array('alert' => 'error'));exit;
		}
		if($it618_wike_main['it618_state']==1){
			it618_showmessage(it618_wike_getlang('s674'), '', array(), array('alert' => 'error'));exit;
		}
	}
	
	if($it618_wike['wike_isgetrz']==1){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
				it618_showmessage(it618_wike_getlang('s577'), '', array(), array('alert' => 'error'));exit;
			}
		}
	}
	
	if($it618_wike_main['it618_uids']!=''){
		$uidsarr=explode(",", $it618_wike_main['it618_uids']);
		if(!in_array($uid, $uidsarr)){
			it618_showmessage(it618_wike_getlang('s282'), '', array(), array('alert' => 'error'));exit;
		}
	}
	
	$count=DB::result_first("select count(1) from ".DB::table('it618_wike')." w join ".DB::table('it618_wike_main')." m on w.it618_tid=m.it618_tid where m.it618_state!=1 and w.it618_uid=".$uid);
	if($adminauthor!=1&&$count>=$it618_wike['wike_getnotokcount']){
		it618_showmessage(it618_wike_getlang('s326').' <font color=red>'.$count.'</font> '.it618_wike_getlang('s323').' <font color=red>'.$it618_wike['wike_getnotokcount'].'</font> '.it618_wike_getlang('s327'), '', array(), array('alert' => 'error'));exit;
	}
	
	$it618_mode=$it618_wike_main['it618_mode'];
	$it618_select=$it618_wike_main['it618_select'];
	$it618_mancount=$it618_wike_main['it618_mancount'];
	$it618_bmmoney=$it618_wike_main['it618_bmmoney'];
	$it618_getwikemoney=$it618_wike_main['it618_getwikemoney'];

	$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}

	if($liii1il[3]!='1')exit;
	if($uid>0){
		$groupid=$_G['groupid'];
		$it618_gettc=DB::result_first("select it618_gettc from ".DB::table('it618_wike_grouppower')." where it618_groupid=".$groupid);
		$count=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_tid=$tid and it618_uid=$uid");
		$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
		if($count==0){
			if($it618_mode==3){
				$it618_mancount_cur=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_creditnum>0 and it618_tid=$tid");
				if($it618_mancount_cur==$it618_mancount){
					it618_showmessage(it618_wike_getlang('s270'), '', array(), array('alert' => 'error'));exit;
				}
			}else{
				$it618_mancount_cur=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_ok=1 and it618_tid=$tid");
				if($it618_mancount_cur==$it618_mancount){
					it618_showmessage(it618_wike_getlang('s92'), '', array(), array('alert' => 'error'));exit;
				}
			}
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_wike/kindeditor/themes/common/right.txt')){
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_wike/ajax.inc.php';
				
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_wike/lang.func.php';
				
			}
			if($it618_select==2)$it618_ok=1; else $it618_ok=0;
			$it618_groupid=$_G['groupid'];
			$it618_getjlbl=DB::result_first("select it618_getjlbl from ".DB::table('it618_wike_grouppower')." where it618_groupid=".$it618_groupid);
			$setarr = array(
				'it618_tid' => $tid,
				'it618_uid' => $uid,
				'it618_ok' => $it618_ok,
				'it618_creditnum' => 0,
				'it618_bmmoney' => $it618_bmmoney,
				'it618_getwikemoney' => $it618_getwikemoney,
				'it618_tc' => $it618_gettc,
				'it618_jlbl' => $it618_getjlbl,
				'it618_time' => $_G['timestamp']
			);
			
			$creditnum=DB::result_first("select extcredits".$it618_wike['wike_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
			if($creditnum>=($it618_bmmoney+$it618_getwikemoney)){
				$id = C::t('#it618_wike#it618_wike')->insert($setarr, true);
				if($id>0){
					if($it618_mode!=3){
						$it618_mancount_cur=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_ok=1 and it618_tid=$tid");
						if($it618_mancount_cur==$it618_mancount){
							DB::query('update '.DB::table('it618_wike_main').' set it618_state=0 where it618_tid='.$tid);
						}
					}
					
					if($it618_bmmoney>0){
						updatemembercount($uid,array($wike_credit=>(0-$it618_bmmoney)), 1, '', $tid,'',it618_wike_getcreditlog('wike_bm'),it618_wike_getcreditlog($it618_wike_lang['s601'],$tid));
						updatemembercount($it618_wike_main['it618_uid'],array($wike_credit=>$it618_bmmoney), 1, '', $tid,'',it618_wike_getcreditlog('wike_bm'),it618_wike_getcreditlog($it618_wike_lang['s603'],$tid));
					}
					if($it618_getwikemoney>0){
						updatemembercount($uid,array($wike_credit=>(0-$it618_getwikemoney)), 1, '', $tid,'',it618_wike_getcreditlog('wike_bzj'),it618_wike_getcreditlog($it618_wike_lang['s593'],$tid));
					}

					it618_wike_sendmessage('getwike_post',$id);
					it618_showmessage(it618_wike_getlang('s8'), '', array(), array('alert' => 'right'));exit;
				}else{
					it618_showmessage(it618_wike_getlang('s2'), '', array(), array('alert' => 'error'));exit;
				}
			}else{
				if($it618_bmmoney>0){
					$tipstr=str_replace("{bmmoney}",$it618_bmmoney.$wike_creditname,it618_wike_getlang('s193'));
					$tipstr=str_replace("{bzmoney}",$it618_getwikemoney.$wike_creditname,$tipstr);
				}else{
					$tipstr=str_replace("{bzmoney}",$it618_getwikemoney.$wike_creditname,it618_wike_getlang('s192'));
				}
				$tipstr=str_replace("{creditnum}",$creditnum.$wike_creditname,$tipstr);
				it618_showmessage($tipstr, '', array(), array('alert' => 'error'));exit;
			}
		}else{
			it618_showmessage(it618_wike_getlang('s9'), '', array(), array('alert' => 'error'));exit;
		}
	}else{
		it618_showmessage(it618_wike_getlang('s10'), '', array(), array('alert' => 'error'));exit;
	}
	exit;
}


if($_GET['ac']=="setgetwikejd"){
	$uid = $_G['uid'];
	$wid = intval($_GET['wid']);

	$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
	if($liii1il[2]!='6')exit;
	$setarr = array(
		'it618_state' => $_GET['it618_state'],
	);
	$id = C::t('#it618_wike#it618_wike')->update($wid,$setarr);
	if($id>0){
		it618_showmessage(it618_wike_getlang('s183'), '', array(), array('alert' => 'right'));exit;
	}
	exit;
}


if($_GET['ac']=="setwikestate"){
	$tid = intval($_GET['tid']);
	
	if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)){
	
		$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
		if($liii1il[2]!='6')exit;
		$setarr = array(
			'it618_state' => 0,
		);
		$id = C::t('#it618_wike#it618_wike_main')->update($it618_wike_main['id'],$setarr);
		exit;
	}
}


if($_GET['ac']=="delgetwike"){
	$uid = $_G['uid'];
	$wikeid = intval($_GET['wikeid']);
	if(!($it618_wike_wike=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike')." WHERE id=".$wikeid))){
		if($_GET['ac1']=='qx'){
			it618_showmessage(it618_wike_getlang('s1007'), '', array(), array('alert' => 'error'));exit;
		}elseif($_GET['ac1']=='pf'){
			it618_showmessage(it618_wike_getlang('s1008'), '', array(), array('alert' => 'error'));exit;
		}elseif($_GET['ac1']=='adminpf'){
			it618_showmessage(it618_wike_getlang('s1009'), '', array(), array('alert' => 'error'));exit;
		}else{
			it618_showmessage(it618_wike_getlang('s1010'), '', array(), array('alert' => 'error'));exit;
		}
	}
	
	if($uid>0){
		$it618_ok=$it618_wike_wike['it618_ok'];
		$tid=$it618_wike_wike['it618_tid'];
		$setuid=$it618_wike_wike['it618_uid'];
		$it618_wike_main=DB::fetch_first("select * from ".DB::table('it618_wike_main')." where it618_tid=".$it618_wike_wike['it618_tid']);
		
		if($_GET['ac1']=='qx'){
			if($setuid!=$_G['uid']){
				it618_showmessage(it618_wike_getlang('s2'), '', array(), array('alert' => 'error'));exit;	
			}
			if($it618_ok==1){
				it618_showmessage(it618_wike_getlang('s968'), '', array(), array('alert' => 'error'));exit;
			}else{
				if($it618_wike_main['it618_state']==1){
					it618_showmessage(it618_wike_getlang('s969'), '', array(), array('alert' => 'error'));exit;
				}
				
				$it618_getwikemoney=$it618_wike_wike['it618_getwikemoney'];
				$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
				if($liii1il[1]!='t')exit;
				$wike_credit=$it618_wike['wike_credit'];

				updatemembercount($setuid,array($wike_credit=>$it618_getwikemoney), 1, '', $tid,'',it618_wike_getcreditlog('wike_bzj'),it618_wike_getcreditlog($it618_wike_lang['s594'],$tid));
				
				$it618_attachment=$it618_wike_wike['it618_attachment'];
				$tmparr=explode("source",$it618_attachment);
				$it618_attachment=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_attachment)){
					$result=unlink($it618_attachment);
				}
				
				$id=DB::delete('it618_wike', "id=".$wikeid);
				if($id>0){
					it618_showmessage(it618_wike_getlang('s970'), '', array(), array('alert' => 'right'));exit;
				}
			}
		}if($_GET['ac1']=='pf'){
			if($setuid!=$_G['uid']){
				it618_showmessage(it618_wike_getlang('s2'), '', array(), array('alert' => 'error'));exit;	
			}
			if($it618_ok==0){
				it618_showmessage(it618_wike_getlang('s975'), '', array(), array('alert' => 'error'));exit;
			}else{
				if($it618_wike_main['it618_state']==1){
					it618_showmessage(it618_wike_getlang('s976'), '', array(), array('alert' => 'error'));exit;
				}
				
				$it618_getwikemoney=$it618_wike_wike['it618_getwikemoney'];
				$it618_bmmoney=$it618_wike_wike['it618_bmmoney'];
				$it618_time=$it618_wike_wike['it618_time'];

				$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
				if($liii1il[1]!='t')exit;
				$wike_credit=$it618_wike['wike_credit'];
				$postuid=$it618_wike_main['it618_uid'];

				updatemembercount($postuid,array($wike_credit=>$it618_getwikemoney), 1, '', $tid,'',it618_wike_getcreditlog('wike_bzj'),it618_wike_getcreditlog($it618_wike_lang['s596'],$tid));
				
				if($it618_wike_main['it618_mode']==1){
					$setarr = array(
						'it618_moneycount2' => $it618_wike_main['it618_moneycount2']-$it618_wike_wike['it618_creditnum'],
					);
					C::t('#it618_wike#it618_wike_main')->update($it618_wike_main['id'],$setarr);
				}
				
				$it618_attachment=$it618_wike_wike['it618_attachment'];
				$tmparr=explode("source",$it618_attachment);
				$it618_attachment=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_attachment)){
					$result=unlink($it618_attachment);
				}
				
				$id=DB::delete('it618_wike', "id=".$wikeid);
				if($id>0){
					$setarr = array(
						'it618_tid' => $tid,
						'it618_postuid' => $postuid,
						'it618_getuid' => $setuid,
						'it618_type' => 1,
						'it618_gettime' => $it618_time,
						'it618_getwikemoney' => $it618_getwikemoney,
						'it618_bmmoney' => $it618_bmmoney,
						'it618_time' => $_G['timestamp']
					);
					$id = C::t('#it618_wike#it618_wike_pf')->insert($setarr, true);
					
					it618_wike_sendmessage('pf_post',$id);
					it618_showmessage(it618_wike_getlang('s977'), '', array(), array('alert' => 'right'));exit;
				}
			}
		}if($_GET['ac1']=='adminpf'){
			if($adminauthor!=1){
				it618_showmessage(it618_wike_getlang('s2'), '', array(), array('alert' => 'error'));exit;	
			}
			if($it618_ok==0){
				it618_showmessage(it618_wike_getlang('s981'), '', array(), array('alert' => 'error'));exit;
			}else{
				if($it618_wike_main['it618_state']==1){
					it618_showmessage(it618_wike_getlang('s976'), '', array(), array('alert' => 'error'));exit;
				}
				
				$it618_bmmoney=$it618_wike_wike['it618_bmmoney'];
				$it618_getwikemoney=$it618_wike_wike['it618_getwikemoney'];
				$it618_time=$it618_wike_wike['it618_time'];

				$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
				if($liii1il[1]!='t')exit;
				$wike_credit=$it618_wike['wike_credit'];
				$postuid=$it618_wike_main['it618_uid'];

				updatemembercount($postuid,array($wike_credit=>$it618_getwikemoney), 1, '', $tid,'',it618_wike_getcreditlog('wike_bzj'),it618_wike_getcreditlog($it618_wike_lang['s597'],$tid));
				
				if($it618_wike_main['it618_mode']==1){
					$setarr = array(
						'it618_moneycount2' => $it618_wike_main['it618_moneycount2']-$it618_wike_wike['it618_creditnum'],
					);
					C::t('#it618_wike#it618_wike_main')->update($it618_wike_main['id'],$setarr);
				}
				
				$it618_attachment=$it618_wike_wike['it618_attachment'];
				$tmparr=explode("source",$it618_attachment);
				$it618_attachment=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_attachment)){
					$result=unlink($it618_attachment);
				}
				
				$id=DB::delete('it618_wike', "id=".$wikeid);
				if($id>0){
					$setarr = array(
						'it618_tid' => $tid,
						'it618_postuid' => $postuid,
						'it618_getuid' => $setuid,
						'it618_type' => 2,
						'it618_gettime' => $it618_time,
						'it618_getwikemoney' => $it618_getwikemoney,
						'it618_bmmoney' => $it618_bmmoney,
						'it618_time' => $_G['timestamp']
					);
					$id = C::t('#it618_wike#it618_wike_pf')->insert($setarr, true);
					
					it618_wike_sendmessage('adminpf_post',$id);
					it618_wike_sendmessage('adminpf_user',$id);
					it618_showmessage(it618_wike_getlang('s982'), '', array(), array('alert' => 'right'));exit;
				}
			}
		}else{
			if($it618_ok==0||$adminauthor==1){
				$postuid=$it618_wike_main['it618_uid'];
				if($postuid!=$uid&&$adminauthor!=1){
					it618_showmessage(it618_wike_getlang('s265'), '', array(), array('alert' => 'error'));exit;
				}
				
				if($it618_wike_main['it618_state']==1){
					it618_showmessage(it618_wike_getlang('s271'), '', array(), array('alert' => 'error'));exit;
				}
				
				if($it618_ok==0){
					$delflag=1;
				}else{
					if($adminauthor==1){
						$delflag=1;
					}else{
						it618_showmessage(it618_wike_getlang('s356'), '', array(), array('alert' => 'error'));exit;
					}
				}
				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
				if($delflag==1){
					$it618_creditnum=$it618_wike_wike['it618_creditnum'];
					$it618_bmmoney=$it618_wike_wike['it618_bmmoney'];
					$it618_getwikemoney=$it618_wike_wike['it618_getwikemoney'];
					$it618_time=$it618_wike_wike['it618_time'];

					$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
					if($liii1il[1]!='t')exit;
					$wike_credit=$it618_wike['wike_credit'];
					
					if($it618_getwikemoney>0){
						updatemembercount($setuid,array($wike_credit=>$it618_getwikemoney), 1, '', $tid,'',it618_wike_getcreditlog('wike_bzj'),it618_wike_getcreditlog($it618_wike_lang['s595'],$tid));
					}
					
					if($it618_bmmoney>0){
						updatemembercount($setuid,array($wike_credit=>$it618_bmmoney), 1, '', $tid,'',it618_wike_getcreditlog('wike_bm'),it618_wike_getcreditlog($it618_wike_lang['s602'],$tid));
						updatemembercount($postuid,array($wike_credit=>(0-$it618_bmmoney)), 1, '', $tid,'',it618_wike_getcreditlog('wike_bm'),it618_wike_getcreditlog($it618_wike_lang['s614'],$tid));
					}
					
					$it618_attachment=$it618_wike_wike['it618_attachment'];
					$tmparr=explode("source",$it618_attachment);
					$it618_attachment=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_attachment)){
						$result=unlink($it618_attachment);
					}
					
					$id=DB::delete('it618_wike', "id=".$wikeid);
					if($id>0){
						it618_wike_sendmessage('delget_user',$setuid,$tid);
						it618_showmessage(it618_wike_getlang('s357'), '', array(), array('alert' => 'right'));exit;
					}	
				}
			}else{
				it618_showmessage(it618_wike_getlang('s964'), '', array(), array('alert' => 'error'));exit;
			}
		}
	}
	exit;
}


if($_GET['ac']=="setmoney"){
	$uid = $_G['uid'];
	$wikeid = intval($_GET['wikeid']);
	$it618_creditnum = intval($_GET['it618_creditnum']);
	$wike_groups=(array)unserialize($it618_wike['wike_groups']);
	$wike_credit=$it618_wike['wike_credit'];
	$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
	if($uid>0){
		if(in_array($_G['groupid'], $wike_groups)){
			$count=DB::result_first("select count(1) from ".DB::table('it618_wike')." where id=$wikeid");
			if($count==1){
				$it618_wike_wike=DB::fetch_first("select * from ".DB::table('it618_wike')." where id=$wikeid");
				$tid=$it618_wike_wike['it618_tid'];
				if(!$it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)){
					it618_showmessage(it618_wike_getlang('s46'), '', array(), array('alert' => 'error'));exit;
				}
				$postuid=$it618_wike_main['it618_uid'];
				if($postuid!=$uid&&$adminauthor!=1){
					it618_showmessage(it618_wike_getlang('s265'), '', array(), array('alert' => 'error'));exit;
				}
				$it618_state=$it618_wike_main['it618_state'];
				if($it618_state==1){
					it618_showmessage(it618_wike_getlang('s271'), '', array(), array('alert' => 'error'));exit;
				}

				$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
				
				if($it618_creditnum<=0){
					it618_showmessage(it618_wike_getlang('s55'), '', array(), array('alert' => 'error'));exit;
				}
				
				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
				
				$it618_creditnumall=DB::result_first("select sum(it618_creditnum) from ".DB::table('it618_wike')." where it618_tid=$tid");
				if($it618_creditnumall+$it618_creditnum>$it618_wike_main['it618_moneycount2']){
					it618_showmessage(it618_wike_getlang('s280'), '', array(), array('alert' => 'error'));exit;
				}
				
				$setuid=$it618_wike_wike['it618_uid'];
				$it618_gettc=$it618_wike_wike['it618_tc'];
				$it618_tcnum=intval($it618_gettc*$it618_creditnum/100);if($it618_gettc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];

				updatemembercount($setuid,array($wike_credit=>$it618_creditnum), 1, '', $tid,'',it618_wike_getcreditlog('wike_getmoney'),it618_wike_getcreditlog($it618_wike_lang['s586'],$tid));
				if($it618_tcnum>0)updatemembercount($setuid,array($wike_credit=>(0-$it618_tcnum)), 1, '', $tid,'',it618_wike_getcreditlog('wike_gettc'),it618_wike_getcreditlog($it618_wike_lang['s587'],$tid));
				
				DB::query('update '.DB::table('it618_wike').' set it618_creditnum=it618_creditnum+'.$it618_creditnum.' where id='.$wikeid);
				
				$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
				it618_wike_sendmessage('jl_user',$wikeid,1,$it618_creditnum);
				it618_showmessage(it618_wike_getlang('s11'), '', array(), array('alert' => 'right'));exit;
			}else{
				it618_showmessage(it618_wike_getlang('s47'), '', array(), array('alert' => 'error'));exit;
			}
		}
	}
	exit;
}


if($_GET['ac']=="caina"){
	$uid = $_G['uid'];
	$wikeid = intval($_GET['wikeid']);
	$wike_groups=(array)unserialize($it618_wike['wike_groups']);
	$wike_credit=$it618_wike['wike_credit'];
	$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	
	if($uid>0){
		if(in_array($_G['groupid'], $wike_groups)||$adminauthor==1){
			$count=DB::result_first("select count(1) from ".DB::table('it618_wike')." where id=$wikeid");
			if($count==1){
				$it618_wike_wike=DB::fetch_first("select * from ".DB::table('it618_wike')." where id=$wikeid");
				$tid=$it618_wike_wike['it618_tid'];
				$it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid);
				$postuid=$it618_wike_main['it618_uid'];
				if($postuid!=$uid&&$adminauthor!=1){
					it618_showmessage(it618_wike_getlang('s265'), '', array(), array('alert' => 'error'));exit;
				}
				$it618_state=$it618_wike_main['it618_state'];
				if($it618_state==1){
					it618_showmessage(it618_wike_getlang('s271'), '', array(), array('alert' => 'error'));exit;
				}
				$it618_mancount_cur=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_creditnum>0 and it618_tid=$tid");
				$it618_mancount=$it618_wike_main['it618_mancount'];
				if($it618_mancount_cur==$it618_mancount){
					it618_showmessage(it618_wike_getlang('s303'), '', array(), array('alert' => 'error'));exit;
				}
				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
				$setuid=$it618_wike_wike['it618_uid'];
				$it618_gettc=$it618_wike_wike['it618_tc'];
				$it618_getwikemoney=DB::result_first("select it618_getwikemoney from ".DB::table('it618_wike')." where id=$wikeid");
				$it618_moneycount2=$it618_wike_main['it618_moneycount2'];
				$it618_tcnum=intval($it618_gettc*$it618_moneycount2/100);if($it618_gettc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];
				
				updatemembercount($setuid,array($wike_credit=>$it618_moneycount2), 1, '', $tid,'',it618_wike_getcreditlog('wike_getmoney'),it618_wike_getcreditlog($it618_wike_lang['s590'],$tid));
				if($it618_tcnum>0)updatemembercount($setuid,array($wike_credit=>(0-$it618_tcnum)), 1, '', $tid,'',it618_wike_getcreditlog('wike_gettc'),it618_wike_getcreditlog($it618_wike_lang['s591'],$tid));
				if($it618_getwikemoney>0){
					updatemembercount($setuid,array($wike_credit=>$it618_getwikemoney), 1, '', $tid,'',it618_wike_getcreditlog('wike_bzj'),it618_wike_getcreditlog($it618_wike_lang['s599'],$tid));
				}

				DB::query('update '.DB::table('it618_wike').' set it618_creditnum='.$it618_moneycount2.' where id='.$wikeid);
				
				$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
				it618_wike_sendmessage('jl_user',$wikeid,3);
				it618_showmessage(it618_wike_getlang('s272'), '', array(), array('alert' => 'right'));exit;
				if($liii1il[5]!='_')exit;
			}else{
				it618_showmessage(it618_wike_getlang('s47'), '', array(), array('alert' => 'error'));exit;
			}
		}
	}
	exit;
}


if($_GET['ac']=="autosetmoney"){
	$uid = $_G['uid'];
	$tid = intval($_GET['tid']);
	$it618_creditnum = intval($_GET['it618_creditnumauto']);
	$wike_groups=(array)unserialize($it618_wike['wike_groups']);
	$wike_credit=$it618_wike['wike_credit'];
	$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	
	if($uid>0){
		if(in_array($_G['groupid'], $wike_groups)||$adminauthor==1){
			if(!$it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)){
				it618_showmessage(it618_wike_getlang('s46'), '', array(), array('alert' => 'error'));exit;
			}
				
			$postuid=$it618_wike_main['it618_uid'];
			if($postuid!=$uid&&$adminauthor!=1){
				it618_showmessage(it618_wike_getlang('s265'), '', array(), array('alert' => 'error'));exit;
			}
			$it618_state=$it618_wike_main['it618_state'];
			if($it618_state==1){
				it618_showmessage(it618_wike_getlang('s271'), '', array(), array('alert' => 'error'));exit;
			}
			$query = DB::query("SELECT * FROM ".DB::table('it618_wike')." WHERE it618_ok=1 and it618_tid=".$tid." order by id");
			while($it618_wike_wike =DB::fetch($query)) {
				$wikeid=$it618_wike_wike['id'];
				
				if($it618_creditnum<=0){
					it618_showmessage(it618_wike_getlang('s55'), '', array(), array('alert' => 'error'));exit;
				}

				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
				$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
				if($liii1il[6]!='w')exit;
				
				$it618_creditnumall=DB::result_first("select sum(it618_creditnum) from ".DB::table('it618_wike')." where it618_tid=$tid");
				if($it618_creditnumall+$it618_creditnum>$it618_wike_main['it618_moneycount2']){
					it618_showmessage(it618_wike_getlang('s280'), '', array(), array('alert' => 'error'));exit;
				}
				
				$setuid=$it618_wike_wike['it618_uid'];
				$it618_gettc=$it618_wike_wike['it618_tc'];
				$it618_tcnum=intval($it618_gettc*$it618_creditnum/100);if($it618_gettc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];

				updatemembercount($setuid,array($wike_credit=>$it618_creditnum), 1, '', $tid,'',it618_wike_getcreditlog('wike_getmoney'),it618_wike_getcreditlog($it618_wike_lang['s586'],$tid));
				if($it618_tcnum>0)updatemembercount($setuid,array($wike_credit=>(0-$it618_tcnum)), 1, '', $tid,'',it618_wike_getcreditlog('wike_gettc'),it618_wike_getcreditlog($it618_wike_lang['s587'],$tid));
				
				DB::query('update '.DB::table('it618_wike').' set it618_creditnum=it618_creditnum+'.$it618_creditnum.' where id='.$wikeid);
				
				it618_wike_sendmessage('jl_user',$wikeid,1,$it618_creditnum);

			}
			it618_showmessage(it618_wike_getlang('s11'), '', array(), array('alert' => 'right'));exit;
		}
	}
	exit;
}


if($_GET['ac']=="setselect"){
	$uid = $_G['uid'];
	$tid = intval($_GET['tid']);
	$wikeid = intval($_GET['wikeid']);
	$wike_groups=(array)unserialize($it618_wike['wike_groups']);
	$wike_credit=$it618_wike['wike_credit'];
	$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	
	if($uid>0){
		if(in_array($_G['groupid'], $wike_groups)||$adminauthor==1){
			if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)){
				$postuid=$it618_wike_main['it618_uid'];
				if($postuid!=$uid&&$adminauthor!=1){
					it618_showmessage(it618_wike_getlang('s265'), '', array(), array('alert' => 'error'));exit;
				}
				$it618_state=$it618_wike_main['it618_state'];
				if($it618_state==1){
					it618_showmessage(it618_wike_getlang('s271'), '', array(), array('alert' => 'error'));exit;
				}
				$it618_mancount=$it618_wike_main['it618_mancount'];
				$it618_mancount_cur=DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_ok=1 and it618_tid=$tid");
				if($it618_mancount_cur<$it618_mancount){
					$count=DB::result_first("select count(1) from ".DB::table('it618_wike')." where id=$wikeid");
					if($count==1){
						DB::query('update '.DB::table('it618_wike').' set it618_ok=1 where id='.$wikeid);
						$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
						it618_wike_sendmessage('rx_user',$wikeid);
						it618_showmessage(it618_wike_getlang('s235'), '', array(), array('alert' => 'right'));exit;
						if($liii1il[5]!='_')exit;
					}
				}else{
					it618_showmessage(it618_wike_getlang('s236'), '', array(), array('alert' => 'error'));exit;
				}
			}
		}
	}
}


if($_GET['ac']=="getit618_wikeitem"){
	$tid = intval($_GET['tid']);
	getit618_wikeitem($tid);
	exit;
}


if($_GET['ac']=="getit618_wikepost"){
	$uid = $_G['uid'];
	$tid = intval($_GET['tid']);
	global $_G,$it618_wike,$IsCredits,$it618_wike_get;
	$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	$wike_width=$it618_wike['wike_width'];
	
	if($it618_wike['wike_ispostrz']==1){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
				
				if($_GET['wap']!=1){
					$tmpstr='<tr><td colspan=2 style="color:red;font-size:15px">'.it618_wike_getlang('s575').' <a href="javascript:" onclick="jQuery(\'.it618_members\').first().click()">'.it618_wike_getlang('s576').'</a></td></tr>';
				}else{
					$tmpstr='<tr><td colspan=2 style="color:red;font-size:13px">'.it618_wike_getlang('s575').' <a href="plugin.php?id=it618_members:home">'.it618_wike_getlang('s576').'</a></td></tr>';
				}
				
				echo '
				<style>
				.wiketable tr td{border-bottom:#f9f9f9 1px solid;padding-top:3px;padding-bottom:3px;color:#666}
				</style>
				<input type="hidden" id="it618_mode" name="it618_mode" value="1"/>
				<div id="moneycounttitle" style="display:none"></div>
				<div id="it618_mancounttitle" style="display:none"></div>
				<div id="it618_select" style="display:none"></div>
				<div id="moneyabout" style="display:none"></div>
				<table class="wiketable" width="100%">
				'.$tmpstr.'
				</table>
				';exit;
			}
		}
	}
	
	$wike_modes=(array)unserialize($it618_wike['wike_modes']);
	
	$moneycounttitle=it618_wike_getlang('s22');
	$it618_mancounttitle=it618_wike_getlang('s93');
	
	$n=1;
	if(in_array(1, $wike_modes)){
		if($n!=1)$csstmp='style="display:none"';
		$modeoption.='<option value=1>'.it618_wike_getlang('s501').'</option>';
		$n=$n+1;
	}
	if(in_array(2, $wike_modes)){
		if($n!=1)$csstmp='style="display:none"';
		$modeoption.='<option value=2>'.it618_wike_getlang('s502').'</option>';
		$n=$n+1;
	}
	if(in_array(3, $wike_modes)){
		if($n!=1)$csstmp='style="display:none"';
		$modeoption.='<option value=3>'.it618_wike_getlang('s503').'</option>';
		$n=$n+1;
	}
	
	if(count($wike_modes)==1){
		if(in_array(3, $wike_modes)){
			$wike_mode='<input type="hidden" id="it618_mode" name="it618_mode" value="3"/>'.it618_wike_getlang('s503').' ';
			$moneycounttitle=it618_wike_getlang('s257');
			$it618_mancounttitle=it618_wike_getlang('s276');
		}
	
		if(in_array(2, $wike_modes)){
			$wike_mode='<input type="hidden" id="it618_mode" name="it618_mode" value="2"/>'.it618_wike_getlang('s502').' ';
		}
		
		if(in_array(1, $wike_modes)){
			$wike_mode='<input type="hidden" id="it618_mode" name="it618_mode" value="1"/>'.it618_wike_getlang('s501').' ';
		}
	}elseif(count($wike_modes)>0){
		$wike_mode='<select style="line-height:12px" id="it618_mode" name="it618_mode" onclick="wikemode()" onchange="wikemode()">'.$modeoption.'</select> ';
	}else{
		$wike_mode='<input type="hidden" id="it618_mode" name="it618_mode" value="1"/>'.it618_wike_getlang('s501');
	}
			
	 $creditnum=DB::result_first("select extcredits".$it618_wike['wike_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
	 $tmpstr=it618_wike_getlang('s289').'<font color=red>'.$creditnum.'</font><font color=#66666>'.$wike_creditname.'</font> ';
	 
	 if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
	
	$it618_bmmoney=DB::result_first("SELECT it618_bmmoney FROM ".DB::table('it618_wike_grouppower')." WHERE it618_groupid=".$_G['groupid']);
	
	if($it618_wike['wike_selectmode']==1){
		$wike_selectmode1='selected="selected"';
	}else{
		$wike_selectmode2='selected="selected"';
	}
	
	if($it618_wike['wike_hfread']==1)$it618_hfreadchk1='selected="selected"';
	if($it618_wike['wike_hfread']==2)$it618_hfreadchk2='selected="selected"';
	if($it618_wike['wike_hfread']==3)$it618_hfreadchk3='selected="selected"';
	if($it618_wike['wike_hfread']==4)$it618_hfreadchk4='selected="selected"';
	
	if($it618_wike['wike_rwread']==1)$it618_rwreadchk1='selected="selected"';
	if($it618_wike['wike_rwread']==2)$it618_rwreadchk2='selected="selected"';
	if($it618_wike['wike_rwread']==3)$it618_rwreadchk3='selected="selected"';
	
	if($it618_wike['wike_postdiy']!='')$wike_postdiy='<tr><td colspan=2>'.$it618_wike['wike_postdiy'].'</td></tr>';
	
	if($it618_bmmoney==0)$bmcss='style="display:none"';
	
	if($_GET['wap']!=1){
		if($wike_width<=1100){
			$tmpwidth=360;
		}else{
			$tmpwidth=450;	
		}
		
		$tmpwikepost='
		<input type="hidden" name="paytype" value="credit">
		<table class="wiketable" width="100%">
		<tr><td colspan=2>'.it618_wike_getlang('s228').$wike_mode.' <a href="javascript:" onclick="showrules('.$tid.')">'.it618_wike_getlang('s887').'</a></td></tr>
		<tr>
		<td width="'.$tmpwidth.'"><span id="moneycounttitle">'.$moneycounttitle.'</span><input type="text" id="it618_moneycount2" name="it618_moneycount2" style="width:80px;color:red" onclick="setdisable()" /><font color=#66666>'.$wike_creditname.'</font> <span id="moneyabout" style="color:red"></span></td>
		<td><span id="it618_mancounttitle">'.$it618_mancounttitle.'</span><input type="text" value="1" id="it618_mancount" name="it618_mancount" style="width:80px" onclick="setdisable()" />'.$it618_bmmoneystr.'</td>
		</tr>
		<tr>
		<td>'.it618_wike_getlang('s63').'<input type="text" id="it618_time2" name="it618_time2" style="width:125px" onclick="SetDate(this,\'yyyy-MM-dd hh:mm:ss\');setdisable()" readonly="readonly" value="'.date('Y-m-d H:i:s', (time()+3600*24*$it618_wike['wike_wiketime'])).'" /></td>
		<td><span '.$bmcss.'>'.$it618_wike_lang['s943'].'<input type="text" value="0" id="it618_bmmoney" name="it618_bmmoney" style="width:80px"/><font color=#66666>'.$wike_creditname.'</font> <font color=#999>'.$it618_wike_lang['s944'].$it618_bmmoney.$wike_creditname.'</font></span></td>
		</tr>
		<tr>
		<td>'.it618_wike_getlang('s185').'<input type="text" value="0" id="it618_getwikemoney" name="it618_getwikemoney" style="width:80px"/><font color=#66666>'.$wike_creditname.'</font></td>
		<td>'.it618_wike_getlang('s244').'<select style="line-height:12px" name="it618_select"><option value=1 '.$wike_selectmode1.'>'.it618_wike_getlang('s245').'</option><option value=2 '.$wike_selectmode2.'>'.it618_wike_getlang('s246').'</option></select><span id="it618_select"></span></td>
		</tr>
		<tr>
		<td>'.it618_wike_getlang('s237').'<select style="line-height:12px" id="it618_read" name="it618_read"><option value=1 '.$it618_rwreadchk1.'>'.it618_wike_getlang('s238').'</option><option value=2 '.$it618_rwreadchk2.'>'.it618_wike_getlang('s239').'</option><option value=3 '.$it618_rwreadchk3.'>'.it618_wike_getlang('s240').'</option></select></td>
		<td>'.it618_wike_getlang('s409').'<select style="line-height:12px" id="it618_hfread" name="it618_hfread"><option value=1 '.$it618_hfreadchk1.'>'.it618_wike_getlang('s561').'</option><option value=2 '.$it618_hfreadchk2.'>'.it618_wike_getlang('s238').'</option><option value=3 '.$it618_hfreadchk3.'>'.it618_wike_getlang('s239').'</option><option value=4 '.$it618_hfreadchk4.'>'.it618_wike_getlang('s240').'</option></select></td>
		</tr>
		<tr><td colspan=2>'.it618_wike_getlang('s278').'<input type="text" style="width:'.($tmpwidth-92).'px" name="it618_uids"> <font color=#999>'.it618_wike_getlang('s279').'</font></td></tr>
		<tr><td colspan=2>'.$tmpstr.gettctip(1,$_G['uid'],0,$adminauthor).'<div id="wike_mode"><strong>'.$it618_wike_lang['s500'].'</strong><br>'.$modestrtmp.'</div></td></tr>
		'.$wike_postdiy.'
		<table>
		<script>document.getElementById("hiddenreplies").checked=false;</script>
		';
	}else{
		$waphome=it618_wike_getrewrite('wike_wap','','plugin.php?id=it618_wike:wap');
		if($IsCredits==1&&$_G['uid']>0){
			
			$langs288=str_replace("{creditsname}",$wike_creditname,$it618_wike_lang['s288']);
			if($_G['cache']['plugin']['it618_wike']['rewriteurl']==0){
				$creditstr='<a href="plugin.php?id=it618_credits:wap&dotype=recharge&ctype='.$it618_wike['wike_credit'].'" target="_blank">'.$langs288.'</a>';
			}else{
				$creditstr='<a href="credits_wap-recharge-'.$it618_wike['wike_credit'].'.html" target="_blank">'.$langs288.'</a>';
			}
		}
		$tmpwikepost='
		<input type="hidden" name="paytype" value="credit">
		<table class="wiketable" width="97%">
		<tr><td colspan=2><div class="wikenav"><a href="'.$waphome.'" target="_blank"><font color=#666>'.it618_wike_getlang('s546').'</font></a>'.$creditstr.'</div></td></tr>
		<tr><td width=90 class="tdleft">'.it618_wike_getlang('s228').'</td><td>'.$wike_mode.' <a href="javascript:" onclick="showrules('.$tid.')">'.it618_wike_getlang('s887').'</a></td></tr>
		
		<tr><td class="tdleft"><span id="moneycounttitle">'.$moneycounttitle.'</span></td><td><input type="text" id="it618_moneycount2" name="it618_moneycount2" style="width:80px;color:red" onclick="setdisable()" /><font color=#66666>'.$wike_creditname.'</font> <span id="moneyabout" style="color:red"></span></td></tr>
		
		<tr><td class="tdleft"><span id="it618_mancounttitle">'.$it618_mancounttitle.'</span></td><td><input type="text" value="1" id="it618_mancount" name="it618_mancount" style="width:80px" onclick="setdisable()" />'.$it618_bmmoneystr.'</td></tr>
		
		<tr><td class="tdleft">'.it618_wike_getlang('s63').'</td><td><input type="text" id="it618_time2" name="it618_time2" style="width:125px" onclick="SetDate(this,\'yyyy-MM-dd hh:mm:ss\');setdisable()" readonly="readonly" value="'.date('Y-m-d H:i:s', (time()+3600*24*$it618_wike['wike_wiketime'])).'" /></td></tr>
		
		<tr '.$bmcss.'><td class="tdleft">'.it618_wike_getlang('s943').'</td><td><input type="text" value="0" id="it618_bmmoney" name="it618_bmmoney" style="width:80px"/><font color=#66666>'.$wike_creditname.'</font> <font color=#999 style="font-size:10px">'.$it618_wike_lang['s944'].$it618_bmmoney.$wike_creditname.'</font></td></tr>
		
		<tr><td class="tdleft">'.it618_wike_getlang('s185').'</td><td><input type="text" value="0" id="it618_getwikemoney" name="it618_getwikemoney" style="width:80px"/><font color=#66666>'.$wike_creditname.'</font></td></tr>
		
		<tr><td class="tdleft">'.it618_wike_getlang('s244').'</td><td><select style="line-height:12px" name="it618_select"><option value=1 '.$wike_selectmode1.'>'.it618_wike_getlang('s245').'</option><option value=2 '.$wike_selectmode2.'>'.it618_wike_getlang('s246').'</option></select><span id="it618_select"></span></td></tr>
		
		<tr><td class="tdleft">'.it618_wike_getlang('s237').'</td><td><select style="line-height:12px" id="it618_read" name="it618_read"><option value=1 selected="selected">'.it618_wike_getlang('s238').'</option><option value=2>'.it618_wike_getlang('s239').'</option><option value=3>'.it618_wike_getlang('s240').'</option></select></td></tr>
		
		<tr><td class="tdleft">'.it618_wike_getlang('s409').'</td><td><select style="line-height:12px" id="it618_hfread" name="it618_hfread"><option value=1 '.$it618_hfreadchk1.'>'.it618_wike_getlang('s561').'</option><option value=2 '.$it618_hfreadchk2.'>'.it618_wike_getlang('s238').'</option><option value=3 '.$it618_hfreadchk3.'>'.it618_wike_getlang('s239').'</option><option value=4 '.$it618_hfreadchk4.'>'.it618_wike_getlang('s240').'</option></select></td></tr>
		
		<tr><td>'.it618_wike_getlang('s278').'</td><td><input type="text" style="width:98%;margin-bottom:3px" name="it618_uids"><br><font color=#999>'.it618_wike_getlang('s279').'</font></td></tr>
		
		<tr><td colspan=2>'.$tmpstr.gettctip(1,$_G['uid'],0,$adminauthor).'<div id="wike_mode"><strong>'.$it618_wike_lang['s500'].'</strong><br>'.$modestrtmp.'</div></td></tr>
		
		'.$wike_postdiy.'
		<table>
		';
	}
	
	echo $tmpwikepost;
}

function gettctip($type,$uid,$tid,$adminauthor){
	global $_G,$it618_wike;
	$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	$wike_jlcreditname=$_G['setting']['extcredits'][$it618_wike['wike_jlcredit']]['title'];
	$wike_getjlcreditname=$_G['setting']['extcredits'][$it618_wike['wike_getjlcredit']]['title'];
	if($uid<=0)return '';
	$groupid=$_G['groupid'];
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
	if($type==1){
		if($tid==0){
			$it618_jlbl=DB::result_first("select it618_postjlbl from ".DB::table('it618_wike_grouppower')." where it618_groupid=".$groupid);
		}else{
			$it618_jlbl=DB::result_first("select it618_jlbl from ".DB::table('it618_wike_main')." where it618_tid=$tid");
		}
		
		if($it618_jlbl>0){
			$tmpstr=it618_wike_getlang('s1025');
			$tmpstr=str_replace("{bl}",$it618_jlbl,$tmpstr);
			$tmpstr=str_replace("{jfname}",$wike_jlcreditname,$tmpstr);
		}
	}else{
		if(DB::result_first("select count(1) from ".DB::table('it618_wike')." where it618_tid=$tid and it618_uid=$uid")==0){
			$it618_jlbl=DB::result_first("select it618_getjlbl from ".DB::table('it618_wike_grouppower')." where it618_groupid=".$groupid);
		}else{
			$it618_jlbl=DB::result_first("select it618_jlbl from ".DB::table('it618_wike')." where it618_tid=$tid and it618_uid=$uid");
		}
		
		if($it618_jlbl>0){
			$tmpstr=it618_wike_getlang('s1027');
			$tmpstr=str_replace("{bl}",$it618_jlbl,$tmpstr);
			$tmpstr=str_replace("{jfname}",$wike_getjlcreditname,$tmpstr);
		}
	}
	
	if($tid==0){
		if($type==1){
			$tc=DB::result_first("select it618_posttc from ".DB::table('it618_wike_grouppower')." where it618_groupid=".$groupid);
			if($tc>0){
				$tc=it618_wike_getlang('s212').' <font color=red>'.$grouptitle.'</font> '.it618_wike_getlang('s213').$tc.it618_wike_getlang('s214').$tmpstr;
			}else{
				$tc=it618_wike_getlang('s212').' <font color=red>'.$grouptitle.'</font> '.it618_wike_getlang('s1031').$tmpstr;
			}
		}
		
		if($adminauthor==1)$tc=str_replace(it618_wike_getlang('s249')," <font color=red><strong>".it618_wike_getusername($uid)."</strong></font>",$tc);
		
		return $tc;
	}else{
		if($type==1){
			$tc=DB::result_first("select it618_tc from ".DB::table('it618_wike_main')." where it618_tid=$tid");

			if($tc>0){
				$tc=it618_wike_getlang('s328').$tc.it618_wike_getlang('s214').$tmpstr;
			}else{
				$tc=$tmpstr;
			}
		}else{
			$tc = DB::result_first("SELECT it618_tc FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid." and it618_uid=".$uid);
			if($tc=='')$tc=DB::result_first("select it618_gettc from ".DB::table('it618_wike_grouppower')." where it618_groupid=".$groupid);
			if($tc>0){
				$tc=it618_wike_getlang('s329').$tc.it618_wike_getlang('s216');
				if($tmpstr!='')$tc=$tc.'<br>'.$tmpstr.'<br>';
			}else{
				$tc=$tmpstr;
			}
			
		}
		
		return $tc;
	}
}


if($_GET['ac']=="getit618_wikereply"){
	 $tid = intval($_GET['tid']);
	 $uid = intval($_GET['uid']);
	 $wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	
	 if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid." and it618_uid=".$uid)==0){
		 echo 'del';exit;
	 }
	
	 $it618_wike_wike=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid." and it618_uid=".$uid);
	 $it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid);
	 $liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
	 if($liii1il[9]!='e')exit;
	
	 if($it618_wike_main['it618_mode']==3){
		 if($it618_wike_wike['it618_creditnum']>0){
			 echo '<div class="it618_wike_reply">'.it618_wike_getlang('s290').' <font color=#66666>'.$wike_creditname.'</font><font color=red>+'.$it618_wike_wike['it618_creditnum'].'</font></div>';
		 }
	 }else{
		 if($it618_wike_main['it618_state']!=1&&$it618_wike_main['it618_uid']==$_G[uid]){
			 echo '';
		 }else{
			 echo it618_wike_getlang('s36').' <font color=#66666>'.$wike_creditname.'</font><font color=red>+'.$it618_wike_wike['it618_creditnum'].'</font>';
		 }
	 }
}

function getit618_wikeitem($tid){
	global $_G,$it618_wike,$it618_wike_get,$it618_wike_lang,$IsCredits;
	$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
	$wike_width=$it618_wike['wike_width'];
	$tid = intval($tid);
	if($_G['uid']>0){
		 $tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
		 for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
			 if($_G['uid']==$tmpwikeadmin[$tmpi]){
				 $adminauthor=1;
				 break;
			 }
		 }
	}
	
	if(!$it618_wike_main=DB::fetch_first("select * from ".DB::table('it618_wike_main')." where it618_tid=$tid"))exit;
	if($forum_thread=DB::fetch_first("SELECT subject,authorid,fid,typeid FROM ".DB::table('forum_thread')." WHERE tid=".$tid)){
		DB::query("UPDATE ".DB::table('it618_wike_main')." SET it618_title=%s,it618_fid=%d,it618_typeid=%d WHERE it618_tid=%d", array($forum_thread['subject'],$forum_thread['fid'],$forum_thread['typeid'],$tid));
	}else{
		it618_wike_deletewike($tid);
	}
	$it618_authorid=DB::result_first("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid=".$tid);
	$it618_mode=$it618_wike_main['it618_mode'];
	if($it618_mode==3){
		$it618_wike['wike_isreply']=0;
		$modestr=it618_wike_getlang('s277');
	}elseif($it618_mode==2){
		$modestr=it618_wike_getlang('s222');
	}else{
		$modestr=it618_wike_getlang('s223');
	}

	if($it618_uid=$it618_wike_main['it618_uid']){
		 
		 $liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
		 if($liii1il[6]!='w')exit;
		 if($it618_wike_main['it618_state']==0||$it618_wike_main['it618_state']==10){
		 	$tmpstate=it618_wike_getlang('s13');
		 }else{
			$tmpstate='<font color=red>'.it618_wike_getlang('s14').'</font>';
		 }

		 $tidwikecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid);
		 $tidwikesum = DB::result_first("SELECT sum(it618_creditnum) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid);
		 if($tidwikesum=="")$tidwikesum=0;
		 
		 if($it618_wike['rewriteurl']==0){
			$it618_wike_post='<a href="home.php?mod=space&uid='.$it618_wike_main['it618_uid'].'" target="_blank" c="1">'.it618_wike_getusername($it618_wike_main['it618_uid']).'</a>';
			$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
			if($liii1il[4]!='8')exit;
		}else{
			$it618_wike_post='<a href="space-uid-'.$it618_wike_main['it618_uid'].'.html" target="_blank" c="1">'.it618_wike_getusername($it618_wike_main['it618_uid']).'</a>';
		}
		$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
		if($liii1il[6]!='w')exit;
		
		if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
		
		if($it618_wike_main['it618_read']==1)$it618_read=it618_wike_getlang('s238');
		if($it618_wike_main['it618_read']==2)$it618_read=it618_wike_getlang('s239');
		if($it618_wike_main['it618_read']==3)$it618_read=it618_wike_getlang('s240');
		
		if($it618_wike_main['it618_hfread']==1)$it618_hfread=it618_wike_getlang('s561');
		if($it618_wike_main['it618_hfread']==2)$it618_hfread=it618_wike_getlang('s238');
		if($it618_wike_main['it618_hfread']==3)$it618_hfread=it618_wike_getlang('s239');
		if($it618_wike_main['it618_hfread']==4)$it618_hfread=it618_wike_getlang('s240');
		
		if($it618_mode==3){
			$tidwikeokcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_creditnum>0 and it618_tid=".$tid);
			$listr1=it618_wike_getlang('s292');
			$mancountstr1=$it618_wike_lang['s961'];
		}else{
			$tidwikeokcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_ok=1 and it618_tid=".$tid);
			$listr1=it618_wike_getlang('s16');
			$mancountstr1=$it618_wike_lang['s960'];
		}
		if($it618_wike_main['it618_state']==10){
			$tmptime="<iframe width='100%' marginwidth='0' style='height:15px' marginheight='0'  frameborder='no' scrolling='no'  src=".$_G['siteurl']."plugin.php?id=it618_wike:time&tid=".$tid."&".$_G['timestamp']."></iframe>";
		 }elseif($it618_wike_main['it618_state']==0){
			 $tmptime="<div class=getwikestate>".it618_wike_getlang('s56')."</div>";
		 }else{
			 if($it618_wike_main['it618_jl']>0){
				$jfname=$_G['setting']['extcredits'][$it618_wike['wike_jlcredit']]['title'];
				$getstate=' '.$it618_wike_lang['s286'].'<font color=#f60>'.$it618_wike_main['it618_jl'].'</font>'.$jfname;
			 }
			 $tmptime="<div class=getwikestate>".it618_wike_getlang('s57')." ".$getstate."</div>";
		 }

		$listr1='<div style="float:left;background-color:#ff534c;width:auto;color:#fff;padding:6px 15px;text-align:center;font-size:12px;border-radius:3px 0 0 3px">'.$listr1.'</div><div style="float:left;background-color:#fff;width:auto;color:#ff534c;padding:5px;border:red 1px solid;font-weight:bold;padding-left:15px;padding-right:15px;font-size:12px;border-radius:0 3px 3px 0"><font color=red style="font-size:12px">'.$it618_wike_main['it618_moneycount2'].'</font> '.$wike_creditname.'</div>';
		
		if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
		$allpostcount = C::t('#it618_wike#it618_wike_main')->count_by_search('','',$it618_wike_main['it618_uid'],0);
		$allwikecount =C::t('#it618_wike#it618_wike_main')->count_by_search('','',0,$it618_wike_main['it618_uid']);
		
		if($it618_wike_main['it618_istj']==1){
			$tmpimg='tj1.png';
		}else{
			$tmpimg='tj.png';
		}
		
		if($_GET['wap']==1)$tjright='float:right';
		
		if($adminauthor==1){
			$tjbtn='<img src="source/plugin/it618_wike/images/'.$tmpimg.'" style="width:21px;margin-top:5px;'.$tjright.'" class="tjbtn" onclick="it618_getajax(\'settj\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wid='.$it618_wike_main['id'].'&formhash='.FORMHASH.'&ac=settj\');" title="'.it618_wike_getlang('s414').'">';
		}else{
			if($it618_wike_main['it618_istj']==1)$tjbtn='<img src="source/plugin/it618_wike/images/'.$tmpimg.'" style="width:21px;margin-top:4px;'.$tjright.'" class="tjbtn">';
		}
		
		$getwikecounttmp=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$it618_wike_main['it618_tid']." and it618_uid=".$_G['uid']);
		if($getwikecounttmp>0||$adminauthor==1){
			$it618_wike_wike=DB::fetch_first("select * from ".DB::table('it618_wike')." where it618_tid=".$it618_wike_main['it618_tid']." and it618_uid=".$_G['uid']);
			if($it618_wike_wike['it618_ok']==1||$it618_wike['wike_postwikeuser']==1){
				$qqstr='<a href="javascript:" onclick="showqq(1,'.$it618_wike_main['it618_tid'].','.$it618_wike_main['it618_uid'].')" title="'.$it618_wike_lang['s287'].'"><img src="source/plugin/it618_wike/images/u.png" align="absmiddle" style="border:none;width:18px;margin-top:-3px"/></a>';
			}
		}
		 
		 if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;

		if($it618_authorid!=$_G[uid]&&$_G[uid]>0){
			 $curcreditcount=DB::result_first("select extcredits".$it618_wike['wike_credit']." from ".DB::table('common_member_count')." where uid=".$_G[uid]);
			 $curcreditcountstr=it618_wike_getlang('s298').$wike_creditname.it618_wike_getlang('s318').'<font color=red>'.$curcreditcount.'</font>';
			 if($_GET['wap']==1){
				 $curcreditcountstr='<tr><td style="position:relative;padding-bottom:3px">'.$curcreditcountstr.'</td></tr>';
				 if(DB::result_first("SELECT it618_ok FROM ".DB::table('it618_wike')." WHERE it618_tid=".$it618_wike_main['it618_tid']." and it618_uid=".$_G['uid'])==1){
					 $curcreditcountstr='';
				 }
			 }
			 if($adminauthor!=1)$tctipstr=gettctip(2,$_G['uid'],$tid,0);
		}

		$it618_groupid=DB::result_first("select groupid from ".DB::table('common_member')." where uid=".$it618_authorid);
		if($it618_groupid>0)$it618_bmmoney=DB::result_first("SELECT it618_bmmoney FROM ".DB::table('it618_wike_grouppower')." WHERE it618_groupid=".$it618_groupid);
		if($it618_bmmoney>0&&$it618_wike_main['it618_bmmoney']>0){
			$bmmoneysum = DB::result_first("SELECT sum(it618_bmmoney) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid);
		 	if($bmmoneysum=="")$bmmoneysum=0;
			$it618_bmmoneystr='<tr><td><span style="margin-left:0;color:#333">'.$it618_wike_lang['s947'].' </span>'.$it618_wike_lang['s948'].' <font color=red>'.$it618_wike_main['it618_bmmoney'].'</font> '.$wike_creditname.' , '.$it618_wike_lang['s949'].' <font color=red>'.$bmmoneysum.'</font> '.$wike_creditname.' </td>';
			
			if($it618_mode!=3){
				$tmpconfirm=it618_wike_getlang('s190');
				
				if($it618_wike_main['it618_select']!=1){
					$ruxuan=$it618_wike_lang['s543'];
				}else{
					$ruxuan='';
				}
			}else{
				$tmpconfirm=it618_wike_getlang('s565');
			}
			
			$adminbtn1tipstr=str_replace("{bzmoney}",$it618_wike_main['it618_getwikemoney'].$wike_creditname,$tmpconfirm);
			$adminbtn1tipstr=str_replace("{bmmoney}",$it618_wike_main['it618_bmmoney'].$wike_creditname,$adminbtn1tipstr);
			$adminbtn1tipstr=str_replace("{ruxuan}",$ruxuan,$adminbtn1tipstr);
			
			$adminbtn2tipstr=str_replace("{bzmoney}",$it618_wike_main['it618_getwikemoney'].$wike_creditname,it618_wike_getlang('s972'));
			$adminbtn2tipstr=str_replace("{bmmoney}",$it618_wike_main['it618_bmmoney'].$wike_creditname,$adminbtn2tipstr);
			
			$adminbtn3tipstr=str_replace("{bzmoney}",$it618_wike_main['it618_getwikemoney'].$wike_creditname,it618_wike_getlang('s974'));
			$adminbtn3tipstr=str_replace("{bmmoney}",$it618_wike_main['it618_bmmoney'].$wike_creditname,$adminbtn3tipstr);
		}else{
			if($it618_mode!=3){
				$tmpconfirm=it618_wike_getlang('s189');
				
				if($it618_wike_main['it618_select']!=1){
					$ruxuan=$it618_wike_lang['s543'];
				}else{
					$ruxuan='';
				}
			}else{
				$tmpconfirm=it618_wike_getlang('s564');
			}
			$adminbtn1tipstr=str_replace("{bzmoney}",$it618_wike_main['it618_getwikemoney'].$wike_creditname,$tmpconfirm);
			$adminbtn1tipstr=str_replace("{ruxuan}",$ruxuan,$adminbtn1tipstr);
			
			$adminbtn2tipstr=str_replace("{bzmoney}",$it618_wike_main['it618_getwikemoney'].$wike_creditname,it618_wike_getlang('s971'));
			
			$adminbtn3tipstr=str_replace("{bzmoney}",$it618_wike_main['it618_getwikemoney'].$wike_creditname,it618_wike_getlang('s973'));
		}
		
		if($it618_wike_main['it618_state']!=1){
			 if($adminauthor==1){
				 if($it618_authorid!=$_G[uid])$wikegetflag=1;
			 }elseif($it618_authorid!=$_G[uid]){
				 $wikeget=1;
			 }
			 
			 if($wikeget==1){
				 if($it618_wike_tmp = DB::fetch_first("SELECT * FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid." AND it618_uid=".$_G[uid])){
					 if($_GET['wap']==1){
						  $tmpattachmentshow='showattachment('.$it618_wike_tmp['id'].')';
					  }else{
						  $tmpattachmentshow='showWindow(\'it618_showattachment\',\'plugin.php?id=it618_wike:showattachment&getwikeid='.$it618_wike_tmp['id'].'\')';
					  }
					 
					 if($it618_wike_tmp['it618_ok']==0){
						$adminbtn1='
						<a href="javascript:" class="wikebtn getwike getwike1" style="margin-left:0;float:left;width:49%;padding:0;height:45px;line-height:45px;text-align:center;font-size:15px" onclick="'.$tmpattachmentshow.'"><font color=#fff>'.$it618_wike_lang['s375'].$it618_wike_lang['s285'].'</font></a>
						<a href="javascript:" class="wikebtn getwike getwike0" style="float:right;width:49%;padding:0;height:45px;line-height:45px;text-align:center;font-size:15px" onclick="if(confirm(\''.$adminbtn2tipstr.'\')){it618_getajax(\'delgetwike\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wikeid='.$it618_wike_tmp['id'].'&formhash='.FORMHASH.'&ac=delgetwike&ac1=qx\');}"><font color=#666>'.$it618_wike_lang['s966'].'</font></a>
						';
					 }else{
						 $ispfbtn=1;
						 if($it618_mode==3){
						 	if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_creditnum>0 and it618_tid=".$tid." AND it618_uid=".$_G[uid])>0){
								$ispfbtn=0;
							}
						 }
						 if($ispfbtn==1){
						 $adminbtn1='
						 <a href="javascript:" class="wikebtn getwike getwike1" style="margin-left:0;float:left;width:49%;padding:0;height:45px;line-height:45px;text-align:center;font-size:15px" onclick="'.$tmpattachmentshow.'"><font color=#fff>'.$it618_wike_lang['s375'].$it618_wike_lang['s285'].'</font></a>
						 <a href="javascript:" class="wikebtn getwike getwike0" style="float:right;width:49%;padding:0;height:45px;line-height:45px;text-align:center;font-size:15px" onclick="if(confirm(\''.$adminbtn3tipstr.'\')){it618_getajax(\'delgetwike\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wikeid='.$it618_wike_tmp['id'].'&formhash='.FORMHASH.'&ac=delgetwike&ac1=pf\');}"><font color=#666>'.$it618_wike_lang['s720'].'</font></a>';
						 }
					 }
				 }else{
					 if($it618_wike_main['it618_state']==10){
						 $tmprzbtn='if(confirm(\''.$adminbtn1tipstr.'\')){it618_getajax(\'getwike\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&tid='.$tid.'&formhash='.FORMHASH.'&ac=getwike\');}';
						 if($it618_wike['wike_isgetrz']==1){
							  if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
								  if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
									  if($_GET['wap']!=1){
										  $tmprzbtn='alert(\''.$it618_wike_lang['s577'].'\');jQuery(\'.it618_members\').first().click()';
									  }else{
										  $tmprzbtn='alert(\''.$it618_wike_lang['s577'].'\');location.href=\'plugin.php?id=it618_members:home\'';
									  } 
								  }
							  }
						  }
						 
						 $adminbtn1='<a href="javascript:" class="wikebtn getwike" style="margin-left:0;width:100%;padding:0;height:45px;line-height:45px;text-align:center;font-size:15px" onclick="'.$tmprzbtn.'" style="width:100%;padding:0;height:45px;line-height:45px;text-align:center;"><font color=#fff>'.$it618_wike_lang['s915'].'</font></a>';	
					 }
				 }
				 
				 $wikeget='<tr><td class="wikeget" style="height:0px;padding:0"></td></tr>';
				 if($adminbtn1!='')$wikeget='<tr><td class="wikeget">'.$adminbtn1.'</td></tr>';
			 }
		 }
		 
		 $waphome=it618_wike_getrewrite('wike_wap','','plugin.php?id=it618_wike:wap');
		  if($IsCredits==1&&$_G['uid']>0){
			  if($_G['cache']['plugin']['it618_wike']['rewriteurl']==0){
				  $creditstr='<a href="plugin.php?id=it618_credits:wap" target="_blank">'.$it618_wike_lang['s914'].'</a>';
			  }else{
				  $creditstr='<a href="credits_wap.html" target="_blank">'.$it618_wike_lang['s914'].'</a>';
			  }
		  }
		  
		  if($it618_mode!=3){
			  if($it618_wike_main['it618_select']!=1){
				  $ruxuan='<font color=#66666>'.$it618_wike_lang['s246'].'</font> ';
			  }else{
				  $ruxuan='<font color=#66666>'.$it618_wike_lang['s245'].'</font> ';
			  }
		  }
		  
		  if($it618_wike_main['it618_uids']!=''){
			  $tmpuidsarr=explode(",",$it618_wike_main['it618_uids']);
			  for($i=0;$i<count($tmpuidsarr);$i++){
				  $tmpuname=it618_wike_getusername(intval($tmpuidsarr[$i]));
				  if($tmpuname!='')$tmpunames.=$tmpuname.', ';
			  }
			  $tmpunames=$tmpunames.'@';
			  $tmpunames=str_replace(", @","",$tmpunames);
		  }
		  
		  if($tctipstr!='')$tctipstr='<tr><td>'.$tctipstr.'</td></tr>';
		  
		  if($it618_wike_main['it618_select']!=1){
			  $ruxuanmode=$it618_wike_lang['s246'];
		  }else{
			  $ruxuanmode=$it618_wike_lang['s245'];
		  }
		  
		  if($tmpunames==''){
			  $tmpunames=$it618_wike_lang['s580'];
		  }else{
			  $tmpunames1='<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s283'].'</td><td class="tddatavalue" colspan=3>'.$tmpunames.'</td>
						</tr>';  
		  }

		if($_GET['wap']==1){
			
			$wikeinfo='<table class="wikeinfo">
						<tr><td style="padding-top:6px">'.$tjbtn.$listr1.'</td></tr>
						<tr>
						<td>'.$it618_wike_lang['s950'].'<span style="padding-left:1px;color:#666">'.it618_wike_getusername($it618_wike_main['it618_uid']).' '.$qqstr.' <span style="font-size:11px;color:#999;margin-left:3px"><a href="javascript:" style="text-decoration:none" onclick="showwike(10001,'.$it618_wike_main['it618_uid'].')">'.it618_wike_getlang('s348').'(<font color="red">'.$allpostcount.'</font>)</a> <a href="javascript:" style="text-decoration:none" onclick="showwike(10002,'.$it618_wike_main['it618_uid'].')">'.it618_wike_getlang('s349').'(<font color="red">'.$allwikecount.'</font>)</a></span></span></td>
						</tr>
						<tr><td style="padding:0;border:none">
						<table width="100%" class="wiketdataable">
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s951'].'</td><td class="tddatavalue">'.$modestr.'</font></td>
						<td class="tddatatitle">'.$it618_wike_lang['s952'].'</td><td class="tddatavalue">'.$tidwikesum.' '.$wike_creditname.'</td>
						</tr>
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s953'].'</td><td class="tddatavalue">'.$it618_wike_main['it618_getwikemoney'].' '.$wike_creditname.'</td>
						<td class="tddatatitle">'.$it618_wike_lang['s579'].'</td><td class="tddatavalue">'.$ruxuanmode.'</td>
						</tr>
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s572'].'</td><td class="tddatavalue">'.$it618_read.'</td>
						<td class="tddatatitle">'.$it618_wike_lang['s578'].'</td><td class="tddatavalue">'.$it618_hfread.'</td>
						</tr>
						'.$tmpunames1.'
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s956'].'</td><td class="tddatavalue" colspan=3>'.it618_wike_getmancount2($it618_wike_main,0).'</td>
						</tr>
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s1020'].'</td><td class="tddatavalue" colspan=3 style="position:relative;">'.$tmptime.'</td>
						</tr>
						</table>
						</td>
						</tr>
						'.$it618_bmmoneystr.'
						'.$tctipstr.'
						'.$wikeget.'
						</table>';		
		}else{
			
			$homeurl=it618_wike_getrewrite('wike_home','','plugin.php?id=it618_wike:index');
			if($_G['cache']['plugin']['it618_wike']['rewriteurl']==1){
				$url_this=$_G['siteurl'].'thread-'.$tid.'-1-1.html';
			}else{
				$url_this=$_G['siteurl'].'forum.php?mod=viewthread&tid='.$tid;
			}
			$qrcodesrc=wike_qrcode($url_this);
			if($IsCredits==1&&$_G['uid']>0){
				$creditstr='<a href="javascript:" onclick="document.getElementById(\'creditsbtn\').click()">'.$it618_wike_lang['s914'].'</a>';
			}
			
			if($it618_wike_main['it618_state']!=1){
				if($it618_wike_main['it618_state']==10){
					$item_process='<div class="item_process">
									<div class="jinduline">
										<div class="jindu_item">
										<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
										<div class="jindu_y_text">'.$it618_wike_lang['s916'].'<br/><span class="jd_date"></span></div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
										<div class="jindu_y_text jindu_y_text_red">'.$it618_wike_lang['s917'].'<br/><span class="jd_date"></span></div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line "><div class="jindu_y_q_gray"></div></div>
										<div class="jindu_y_text">'.$it618_wike_lang['s918'].'<br/><span class="jd_date"></span>
										</div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line "><div class="jindu_y_q_gray"></div></div>
										<div class="jindu_y_text ">'.$it618_wike_lang['s919'].'<br/><span class="jd_date"> </span>
										</div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line "><div class="jindu_y_q_gray"></div></div>
										<div class="jindu_y_text">'.$it618_wike_lang['s920'].'<br/><span class="jd_date"></span>
										</div>
										</div>
									</div>
									</div>';
				}else{
					$item_process='<div class="item_process">
									<div class="jinduline">
										<div class="jindu_item">
										<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
										<div class="jindu_y_text">'.$it618_wike_lang['s916'].'<br/><span class="jd_date"></span></div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
										<div class="jindu_y_text">'.$it618_wike_lang['s917'].'<br/><span class="jd_date"></span></div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
										<div class="jindu_y_text jindu_y_text_red">'.$it618_wike_lang['s918'].'<br/><span class="jd_date"></span>
										</div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line "><div class="jindu_y_q_gray"></div></div>
										<div class="jindu_y_text ">'.$it618_wike_lang['s919'].'<br/><span class="jd_date"> </span>
										</div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line "><div class="jindu_y_q_gray"></div></div>
										<div class="jindu_y_text">'.$it618_wike_lang['s920'].'<br/><span class="jd_date"></span>
										</div>
										</div>
									</div>
									</div>';
				}
				
				$tidwikecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid);
				if($tidwikecount==0&&$it618_wike_main['it618_state']==0){
					$item_process='<div class="item_process">
									<div class="jinduline">
										<div class="jindu_item">
										<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
										<div class="jindu_y_text jindu_y_text_red">'.$it618_wike_lang['s916'].'<br/><span class="jd_date"></span></div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line"><div class="jindu_y_q_gray"></div></div>
										<div class="jindu_y_text \">'.$it618_wike_lang['s917'].'<br/><span class="jd_date"></span></div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line "><div class="jindu_y_q_gray"></div></div>
										<div class="jindu_y_text">'.$it618_wike_lang['s918'].'<br/><span class="jd_date"></span>
										</div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line "><div class="jindu_y_q_gray"></div></div>
										<div class="jindu_y_text ">'.$it618_wike_lang['s919'].'<br/><span class="jd_date"> </span>
										</div>
										</div>
										
										<div class="jindu_item">
										<div class="jindu_y_line "><div class="jindu_y_q_gray"></div></div>
										<div class="jindu_y_text">'.$it618_wike_lang['s920'].'<br/><span class="jd_date"></span>
										</div>
										</div>
									</div>
									</div>';
				}
			}else{
				$item_process='<div class="item_process">
								<div class="jinduline">
									<div class="jindu_item">
									<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
									<div class="jindu_y_text">'.$it618_wike_lang['s916'].'<br/><span class="jd_date"></span></div>
									</div>
									
									<div class="jindu_item">
									<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
									<div class="jindu_y_text ">'.$it618_wike_lang['s917'].'<br/><span class="jd_date"></span></div>
									</div>
									
									<div class="jindu_item">
									<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
									<div class="jindu_y_text">'.$it618_wike_lang['s918'].'<br/><span class="jd_date"></span>
									</div>
									</div>
									
									<div class="jindu_item">
									<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
									<div class="jindu_y_text ">'.$it618_wike_lang['s919'].'<br/><span class="jd_date"> </span>
									</div>
									</div>
									
									<div class="jindu_item">
									<div class="jindu_y_line jindu_out"><div class="jindu_y_q_blue_s"></div></div>
									<div class="jindu_y_text jindu_y_text_red">'.$it618_wike_lang['s920'].'<br/><span class="jd_date"></span>
									</div>
									</div>
								</div>
								</div>';
			}
			
			if($it618_mode!=3){
				if($it618_wike_main['it618_select']!=1){
					$ruxuan='<font color=#66666>'.$it618_wike_lang['s246'].'</font> ';
				}else{
					$ruxuan='<font color=#66666>'.$it618_wike_lang['s245'].'</font> ';
				}
			}

			$wikeinfo='<table class="wikeinfo">
						<tr><td style="border:none;padding-bottom:10px">'.$tjbtn.$listr1.'</td></tr>
						<tr><td style="padding:0;border:none;position:relative">
						<div style="position:absolute;top:10px;right:15px; text-align:center; width:108px"><img src="'.$qrcodesrc.'" style="width:118px;height:118px; margin-top:-15px; margin-bottom:10px"/></div>
						<table width="100%" class="wiketdataable">
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s950'].'</td><td class="tddatavalue">'.it618_wike_getusername($it618_wike_main['it618_uid']).' '.$qqstr.' <span style="font-size:11px;color:#999;margin-left:3px"><a href="javascript:" style="text-decoration:none" onclick="showwike(10001,'.$it618_wike_main['it618_uid'].')">'.it618_wike_getlang('s348').'(<font color="red">'.$allpostcount.'</font>)</a> <a href="javascript:" style="text-decoration:none" onclick="showwike(10002,'.$it618_wike_main['it618_uid'].')">'.it618_wike_getlang('s349').'(<font color="red">'.$allwikecount.'</font>)</a></span></td>
						<td class="tddatatitle">'.$it618_wike_lang['s283'].'</td><td class="tddatavalue">'.$tmpunames.'</td>
						</tr>
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s951'].'</td><td class="tddatavalue">'.$modestr.'</td>
						<td class="tddatatitle">'.$it618_wike_lang['s952'].'</td><td class="tddatavalue">'.$tidwikesum.' '.$wike_creditname.'</td>
						</tr>
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s953'].'</td><td class="tddatavalue">'.$it618_wike_main['it618_getwikemoney'].' '.$wike_creditname.'</td>
						<td class="tddatatitle">'.$it618_wike_lang['s579'].'</td><td class="tddatavalue">'.$ruxuanmode.'</td>
						</tr>
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s572'].'</td><td class="tddatavalue">'.$it618_read.'</td>
						<td class="tddatatitle">'.$it618_wike_lang['s578'].'</td><td class="tddatavalue">'.$it618_hfread.'</td>
						</tr>
						<tr>
						<td class="tddatatitle">'.$it618_wike_lang['s956'].'</td><td class="tddatavalue">'.it618_wike_getmancount2($it618_wike_main,0).'</td>
						<td class="tddatatitle">'.$it618_wike_lang['s1020'].'</td><td class="tddatavalue" style="position:relative;">'.$tmptime.'</td>
						</tr>
						</table>
						</td>
						</tr>
						<tr><td style="padding:10px 0px;">'.$item_process.'</td></tr>
						'.$it618_bmmoneystr.'
						'.$tctipstr.'
						'.$wikeget.'
						</table>';
		}
		 
		 if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
		 $deletebtn='<a href="javascript:" class="wikebtn wikebtndel" onclick="if(confirm(\''.it618_wike_getlang('s208').'\')){it618_getajax(\'delwike\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&tid='.$tid.'&formhash='.FORMHASH.'&ac=delwike\');}"><font color=#fff>'.$it618_wike_lang['s921'].'</font></a>';
		 
		 $wike_delwikegroups=(array)unserialize($it618_wike['wike_delwikegroups']);
		 if(in_array($_G['groupid'], $wike_delwikegroups)||$adminauthor==1){
			 $posterdeletebtn=$deletebtn;
		 }
		 
		 if($it618_authorid==$_G[uid]||$adminauthor==1){
			 if($it618_wike_main['it618_state']==10){
				  $strbtn=$it618_wike_lang['s922'];
			 }elseif($it618_wike_main['it618_state']==0){
				  $strbtn=$it618_wike_lang['s923'];
			 }
			 if($it618_wike_main['it618_state']!=1){
				 $liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
				 if($liii1il[5]!='_')exit;

				if($adminauthor==1)$clockmoney_tip=str_replace(it618_wike_getlang('s249'),"<font color=red><strong>".it618_wike_getusername($it618_uid)."</strong></font>",$clockmoney_tip);
				
				if($it618_wike_main['it618_read']==1)$it618_readchk1='selected="selected"';
				if($it618_wike_main['it618_read']==2)$it618_readchk2='selected="selected"';
				if($it618_wike_main['it618_read']==3)$it618_readchk3='selected="selected"';
				
				if($it618_wike_main['it618_hfread']==1)$it618_hfreadchk1='selected="selected"';
				if($it618_wike_main['it618_hfread']==2)$it618_hfreadchk2='selected="selected"';
				if($it618_wike_main['it618_hfread']==3)$it618_hfreadchk3='selected="selected"';
				if($it618_wike_main['it618_hfread']==4)$it618_hfreadchk4='selected="selected"';
				
				if($it618_wike_main['it618_select']==1)$it618_selectchk1='selected="selected"';
				if($it618_wike_main['it618_select']==2)$it618_selectchk2='selected="selected"';
				
				if($it618_wike_main['it618_state']==10)$wike_state1='selected="selected"';
				if($it618_wike_main['it618_state']==0)$wike_state2='selected="selected"';
				
				if($it618_mode==3){
					$moneycounttitle=it618_wike_getlang('t15');
					$it618_mancounttitle=it618_wike_getlang('s276');
					$it618_moneycountstr='<input type="hidden" value="'.$it618_wike_main['it618_moneycount2'].'" id="it618_moneycount2"/>'.$it618_wike_main['it618_moneycount2'].' <font color=#66666>'.$wike_creditname.'</font>';
					
					if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
					$clockmoney_tip=it618_wike_getlang('s209').'<font color=red>'.($it618_wike_main['it618_moneycount2']*$it618_wike_main['it618_mancount']-$tidwikesum+intval($it618_wike_main['it618_tc']*$it618_wike_main['it618_moneycount2']*$it618_wike_main['it618_mancount']/100)).'</font><font color=#66666>'.$wike_creditname.'</font>'.it618_wike_getlang('s1055');
				}else{
					$moneycounttitle=it618_wike_getlang('s22');
					$it618_mancounttitle=it618_wike_getlang('s93');
					$it618_moneycount_display='';
					
					if($it618_mode==2){
						$it618_moneycountstr='<input type="hidden" value="'.$it618_wike_main['it618_moneycount2'].'" id="it618_moneycount2"/>'.$it618_wike_main['it618_moneycount2'].' <font color=#66666>'.$wike_creditname.'</font>';
						
					}else{
						$it618_moneycountstr='<input type="text" value="'.$it618_wike_main['it618_moneycount2'].'" id="it618_moneycount2" style="width:80px;color:red"/><font color=#66666>'.$wike_creditname.'</font> <font color="red">'.$it618_wike_lang['s87'].'</font>';
					}
					
					$clockmoney_tip=it618_wike_getlang('s209').'<font color=red>'.($it618_wike_main['it618_moneycount2']+intval($it618_wike_main['it618_tc']*$it618_wike_main['it618_moneycount2']/100)).'</font><font color=#66666>'.$wike_creditname.'</font>'.it618_wike_getlang('s1055');
				}
				
				
				$it618_bmmoney=DB::result_first("SELECT it618_bmmoney FROM ".DB::table('it618_wike_grouppower')." WHERE it618_groupid=".$_G['groupid']);
				
				if($it618_bmmoney==0)$bmcss='style="display:none"';
				if($_GET['wap']!=1){
					if($wike_width<=1100){
						$tmpwidth=360;
					}else{
						$tmpwidth=450;	
					}
					
					$adminbtn='
					<style>
					.wiketable tr td{border-bottom:#f9f9f9 1px solid;padding-top:6px;padding-bottom:6px;color:#666;font-size:12px}
					.wiketable tr td input,.wiketable tr td select{color:#333;border:#e3e3e3 1px solid;margin-right:3px;padding-left:3px;height:23px;border-radius:3px}
					</style>
					<table class="wiketable" id="wiketable" width="100%" style="display:none">
					<tr>
					<td width="'.$tmpwidth.'">'.$moneycounttitle.$it618_moneycountstr.'</td>
					<td>'.$it618_mancounttitle.'<input type="text"  id="it618_mancount" style="width:80px" value="'.$it618_wike_main['it618_mancount'].'"/></td>
					</tr>
					
					<tr>
					<td>'.it618_wike_getlang('s60').'<input type="text" id="it618_time2" style="width:130px" value="'.date('Y-m-d H:i:s', $it618_wike_main['it618_time2']).'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm:ss\')" readonly="readonly"/><select style="line-height:12px" id="it618_state"><option value=10 '.$wike_state1.'>'.it618_wike_getlang('s713').'</option><option value=0 '.$wike_state2.'>'.it618_wike_getlang('s714').'</option></select></td>
					<td><span '.$bmcss.'>'.$it618_wike_lang['s943'].'<input type="text" id="it618_bmmoney" name="it618_bmmoney" value="'.$it618_wike_main['it618_bmmoney'].'" style="width:80px"/><font color=#66666>'.$wike_creditname.'</font> <font color=#999>'.$it618_wike_lang['s944'].$it618_bmmoney.$wike_creditname.'</font></span></td>
					</tr>
					
					<tr>
					<td>'.it618_wike_getlang('s185').'<input type="text" id="it618_getwikemoney" style="width:80px" value="'.$it618_wike_main['it618_getwikemoney'].'"/><font color=#66666>'.$wike_creditname.'</font></td>
					<td>'.it618_wike_getlang('s244').'<select style="line-height:12px" id="it618_select" name="it618_select"><option value=1 '.$it618_selectchk1.'>'.it618_wike_getlang('s245').'</option><option value=2 '.$it618_selectchk2.'>'.it618_wike_getlang('s246').'</option></select></td>
					</tr>
					
					<tr>
					<td>'.it618_wike_getlang('s237').'<select style="line-height:12px" id="it618_read" name="it618_read"><option value=1 '.$it618_readchk1.'>'.it618_wike_getlang('s238').'</option><option value=2 '.$it618_readchk2.'>'.it618_wike_getlang('s239').'</option><option value=3 '.$it618_readchk3.'>'.it618_wike_getlang('s240').'</option></select></td>
					<td>'.it618_wike_getlang('s409').'<select style="line-height:12px" id="it618_hfread" name="it618_hfread"><option value=1 '.$it618_hfreadchk1.'>'.it618_wike_getlang('s561').'</option><option value=2 '.$it618_hfreadchk2.'>'.it618_wike_getlang('s238').'</option><option value=3 '.$it618_hfreadchk3.'>'.it618_wike_getlang('s239').'</option><option value=4 '.$it618_hfreadchk4.'>'.it618_wike_getlang('s240').'</option></select></td>
					</tr>
					
					<tr><td colspan=2>'.it618_wike_getlang('s278').'<input type="text" style="width:'.($tmpwidth-92).'px" id="it618_uids" value="'.$it618_wike_main['it618_uids'].'"> <font color=#999>'.it618_wike_getlang('s279').'</font></td></tr>
					
					<tr><td colspan=2><div class="btntips">'.$clockmoney_tip.'</div></td></tr>
					
					<tr><td colspan=2><div class="btntips">'.gettctip(1,$it618_uid,$tid,$adminauthor).'</div></td></tr>
					
					<tr><td colspan=2><a href="javascript:" class="wikebtn" onclick="it618_getajax(\'editwike\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&tid='.$tid.'&it618_uids=\'+document.getElementById(\'it618_uids\').value+\'&it618_moneycount2=\'+document.getElementById(\'it618_moneycount2\').value+\'&it618_getwikemoney=\'+document.getElementById(\'it618_getwikemoney\').value+\'&it618_time2=\'+document.getElementById(\'it618_time2\').value+\'&it618_state=\'+document.getElementById(\'it618_state\').value+\'&it618_mancount=\'+document.getElementById(\'it618_mancount\').value+\'&it618_bmmoney=\'+document.getElementById(\'it618_bmmoney\').value+\'&it618_read=\'+document.getElementById(\'it618_read\').value+\'&it618_hfread=\'+document.getElementById(\'it618_hfread\').value+\'&it618_select=\'+document.getElementById(\'it618_select\').value+\'&formhash='.FORMHASH.'&ac=editwike\');"><font color=#fff>'.$it618_wike_lang['s924'].'</font></a>
				<a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s62').'\')){it618_getajax(\'okwike\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&tid='.$tid.'&formhash='.FORMHASH.'&ac=okwike\');}"><font color=#fff>'.$it618_wike_lang['s925'].'</font></a>'.$posterdeletebtn.'</td></tr>
					<table>
					';
				}else{
					$adminbtn='
					<style>
					.wiketable tr td{border-bottom:#f9f9f9 1px solid;padding:4px 1px;color:#888;font-size:12px}
					.wiketable tr td.tdleft{padding-right:0px;text-align:right;}
					.wiketable tr td input,.wiketable tr td select{color:#333;border:#f1f1f1 1px solid;margin-right:3px;padding-left:3px;height:26px;background-color:#fff;font-size:12px;border-radius:3px}
					</style>
					<table class="wiketable" id="wiketable" width="100%" style="display:none">
					
					<tr><td width=90 style="padding-top:15px" class="tdleft">'.$moneycounttitle.'</td><td style="padding-top:15px">'.$it618_moneycountstr.'</td></tr>
					
					<tr><td class="tdleft">'.$it618_mancounttitle.'</td><td><input type="text"  id="it618_mancount" style="width:80px" value="'.$it618_wike_main['it618_mancount'].'"/></td></tr>
					
					<tr><td class="tdleft">'.it618_wike_getlang('s60').'</td><td><input type="text" id="it618_time2" style="width:126px" value="'.date('Y-m-d H:i:s', $it618_wike_main['it618_time2']).'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm:ss\')" readonly="readonly"/><select style="line-height:12px;height:26px" id="it618_state"><option value=10 '.$wike_state1.'>'.it618_wike_getlang('s713').'</option><option value=0 '.$wike_state2.'>'.it618_wike_getlang('s714').'</option></select></td></tr>
					
					<tr'.$bmcss.'><td class="tdleft">'.it618_wike_getlang('s943').'</td><td><input type="text" id="it618_bmmoney" name="it618_bmmoney" value="'.$it618_wike_main['it618_bmmoney'].'" style="width:80px"/><font color=#66666>'.$wike_creditname.'</font> <font color=#999>'.$it618_wike_lang['s944'].$it618_bmmoney.$wike_creditname.'</font></td></tr>
					
					<tr><td class="tdleft">'.it618_wike_getlang('s185').'</td><td><input type="text" id="it618_getwikemoney" style="width:80px" value="'.$it618_wike_main['it618_getwikemoney'].'"/><font color=#66666>'.$wike_creditname.'</font></td></tr>
					
					<tr><td class="tdleft">'.it618_wike_getlang('s244').'</td><td><select style="line-height:12px" id="it618_select" name="it618_select"><option value=1 '.$it618_selectchk1.'>'.it618_wike_getlang('s245').'</option><option value=2 '.$it618_selectchk2.'>'.it618_wike_getlang('s246').'</option></select></span></td></tr>
					
					<tr><td class="tdleft">'.it618_wike_getlang('s237').'</td><td><select style="line-height:12px" id="it618_read" name="it618_read"><option value=1 '.$it618_readchk1.'>'.it618_wike_getlang('s238').'</option><option value=2 '.$it618_readchk2.'>'.it618_wike_getlang('s239').'</option><option value=3 '.$it618_readchk3.'>'.it618_wike_getlang('s240').'</option></select></td></tr>
					
					<tr><td class="tdleft">'.it618_wike_getlang('s409').'</td><td><select style="line-height:12px" id="it618_hfread" name="it618_hfread"><option value=1 '.$it618_hfreadchk1.'>'.it618_wike_getlang('s561').'</option><option value=2 '.$it618_hfreadchk2.'>'.it618_wike_getlang('s238').'</option><option value=3 '.$it618_hfreadchk3.'>'.it618_wike_getlang('s239').'</option><option value=4 '.$it618_hfreadchk4.'>'.it618_wike_getlang('s240').'</option></select></td></tr>
					
					<tr><td class="tdleft">'.it618_wike_getlang('s278').'</td><td><input type="text" style="width:98%" id="it618_uids" value="'.$it618_wike_main['it618_uids'].'"> <font color=#999>'.it618_wike_getlang('s279').'</font></td></tr>
					
					<tr><td colspan=2><div class="btntips">'.$clockmoney_tip.'</div></td></tr>
					
					<tr><td colspan=2><div class="btntips">'.gettctip(1,$it618_uid,$tid,$adminauthor).'</div></td></tr>
					
					<tr><td colspan=2><a href="javascript:" class="wikebtn" style="padding-left:15px;padding-right:15px" onclick="it618_getajax(\'editwike\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&tid='.$tid.'&it618_uids=\'+document.getElementById(\'it618_uids\').value+\'&it618_moneycount2=\'+document.getElementById(\'it618_moneycount2\').value+\'&it618_getwikemoney=\'+document.getElementById(\'it618_getwikemoney\').value+\'&it618_time2=\'+document.getElementById(\'it618_time2\').value+\'&it618_state=\'+document.getElementById(\'it618_state\').value+\'&it618_mancount=\'+document.getElementById(\'it618_mancount\').value+\'&it618_bmmoney=\'+document.getElementById(\'it618_bmmoney\').value+\'&it618_read=\'+document.getElementById(\'it618_read\').value+\'&it618_hfread=\'+document.getElementById(\'it618_hfread\').value+\'&it618_select=\'+document.getElementById(\'it618_select\').value+\'&formhash='.FORMHASH.'&ac=editwike\');"><font color=#fff>'.$it618_wike_lang['s924'].'</font></a><a href="javascript:" class="wikebtn" style="padding-left:15px;padding-right:15px" onclick="if(confirm(\''.it618_wike_getlang('s62').'\')){it618_getajax(\'okwike\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&tid='.$tid.'&formhash='.FORMHASH.'&ac=okwike\');}"><font color=#fff>'.$it618_wike_lang['s925'].'</font></a>'.$posterdeletebtn.'</td></tr>
					<table>
					';
				}
				
				if($it618_mode!=2){
					$curcreditcount=DB::result_first("select extcredits".$it618_wike['wike_credit']." from ".DB::table('common_member_count')." where uid=".$it618_wike_main['it618_uid']);
					$curcreditcountstr1='<span style="float:right">'.it618_wike_getlang('s298').$wike_creditname.it618_wike_getlang('s318').'<font color=red>'.$curcreditcount.'</font></span>';
				}
				
				if($_GET['wap']!=1){
					$tmpheight="18px";
				}else{
					$tmpheight="15px";	
				}
				
				$adminbtn='<tr><td class="adminbtntitle adminbtnbgcolor" style="font-size:13px;font-weight:normal; height:39px; line-height:39px; padding:0 8px; border-radius:3px;cursor:pointer" onclick="collapsed(\'img_admin\',\'wiketable\')"><img src="source/plugin/it618_wike/images/collapsed_yes.png" style="vertical-align:middle;float:right;margin-top:10px;margin-left:6px;width:'.$tmpheight.';cursor:pointer" id="img_admin">'.$curcreditcountstr1.'<img src="source/plugin/it618_wike/images/admin.png" style="vertical-align:middle;width:18px;margin-top:-3px;margin-right:3px">'.$it618_wike_lang['s926'].'</td></tr><tr><td>'.$adminbtn.'</td></tr>';
				
			 }else{
				 $adminbtn=$posterdeletebtn;
			 }
			
			if($adminauthor==1||$it618_wike_main['it618_state']!=1)$adminbtn='<table class="adminbtn">'.$adminbtn.'</table>';
		 } 
	}
	
	$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
	if($liii1il[7]!='i')exit;
	
	$index=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_wike')." WHERE it618_tid=".$tid." order by id");
	while($it618_wike_wike =DB::fetch($query)) {
		$uid=$it618_wike_wike['it618_uid'];
		$allpostcount = C::t('#it618_wike#it618_wike_main')->count_by_search('','',$uid,0);
		$allwikecount =C::t('#it618_wike#it618_wike_main')->count_by_search('','',0,$uid);
		$allwikesum = DB::result_first("SELECT sum(it618_creditnum) FROM ".DB::table('it618_wike')." WHERE it618_uid=".$uid);
		$allpfcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_pf')." WHERE it618_getuid=".$uid);
		if($allwikesum=='')$allwikesum=0;
		$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
		 		 
		$it618_wike_td7="";
		
		if($it618_mode==3){
			if($it618_authorid==$_G[uid]||$adminauthor==1){
				 if($it618_wike_main['it618_state']!=1){
					 $tmpstr='';
					 if($it618_wike['wike_isreply']==1){
						 $tmpuids.=$it618_wike_wike['it618_uid'].",";
					 }
					 
					 if($it618_wike_wike['it618_creditnum']==0){
						 $edittmp='<a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s299').$it618_wike_main['it618_moneycount2'].$wike_creditname.it618_wike_getlang('s317').'\')){it618_getajax(\'caina'.$it618_wike['wike_isreply'].'\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=caina\');}"><font color=#fff>'.$it618_wike_lang['s927'].'</font></a>';
						 
						$oktmp='';$pftmp='';$deletegetwikebtn='';
						if($it618_wike_wike['it618_ok']==0){
							$oktmp='<a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s247').'\')){it618_getajax(\'setselect'.$it618_wike['wike_isreply'].'\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&tid='.$tid.'&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=setselect\');}"><font color=#fff>'.$it618_wike_lang['s929'].'</font></a>';
							$edittmp=$oktmp;
							$deletegetwikebtn='<a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s65').'\')){it618_getajax(\'delgetwike'.$it618_wike['wike_isreply'].'\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=delgetwike\');}"><font color=#fff>'.$it618_wike_lang['s930'].'</font></a>';
						 }else{
							 if($adminauthor==1){
								 $pftmp='<a href="javascript:" class="wikebtn btnpf" onclick="if(confirm(\''.it618_wike_getlang('s980').'\')){it618_getajax(\'delgetwike'.$it618_wike['wike_isreply'].'\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=delgetwike&ac1=adminpf\');}"><font color=#fff>'.$it618_wike_lang['s978'].'</font></a>';
							 }
						 }
						 
						if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
						$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
						if($liii1il[6]!='w')exit;
						
						if($_GET['wap']==1){
							$it618_wike_td7='<spann class="it618_wike_td7">'.$edittmp.$deletegetwikebtn.$pftmp.'</span>';
						}else{
							$it618_wike_td7=$edittmp.$deletegetwikebtn.$pftmp;
						}
					 }else{
						 if($_GET['wap']==1){
							$it618_wike_td7='<span style="float:right"><font color=#66666>'.it618_wike_getlang('s290').'</font></span>';
						}else{
							$it618_wike_td7='<font color=#66666>'.it618_wike_getlang('s290').'</font>';
						}
					 }
	
				 }else{
					$it618_wike_td7='';
				 }
			}
			$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
			if($liii1il[6]!='w')exit;

		}else{
			if($it618_authorid==$_G[uid]||$adminauthor==1){
				 if($it618_wike_main['it618_state']!=1){
					 $tmpstr='';
					 if($it618_wike['wike_isreply']==1){
						 $tmpuids.=$it618_wike_wike['it618_uid'].",";
					 }
	
					 $edittmp=$wike_creditname.'=<input type="text" value="" id="it618_wike'.$it618_wike_wike['id'].'" size="5"/><a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s99').'\')){it618_getajax(\'setmoney'.$it618_wike['wike_isreply'].'\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wikeid='.$it618_wike_wike['id'].'&it618_creditnum=\'+document.getElementById(\'it618_wike'.$it618_wike_wike['id'].'\').value+\'&formhash='.FORMHASH.'&ac=setmoney\');}"><font color=#fff>'.$it618_wike_lang['s928'].'</font></a>';
					 
					 $pftmp='';$ispf=0;
					 if($it618_wike_wike['it618_ok']==0){
						$oktmp='<a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s247').'\')){it618_getajax(\'setselect'.$it618_wike['wike_isreply'].'\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&tid='.$tid.'&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=setselect\');}"><font color=#fff>'.$it618_wike_lang['s929'].'</font></a>';
						$edittmp=$oktmp;
					 }else{
						 $oktmp=it618_wike_getlang('s230');
						 if($adminauthor==1){
							 $pftmp='<a href="javascript:" class="wikebtn btnpf" onclick="if(confirm(\''.it618_wike_getlang('s980').'\')){it618_getajax(\'delgetwike'.$it618_wike['wike_isreply'].'\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=delgetwike&ac1=adminpf\');}"><font color=#fff>'.$it618_wike_lang['s978'].'</font></a>';
						 }
					 }
					
					$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
					if($liii1il[6]!='w')exit;
					if($it618_wike_wike['it618_ok']==0){
						 $deletegetwikebtn='<a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s65').'\')){it618_getajax(\'delgetwike\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=delgetwike\');}'.$tmpstr.'"><font color=#fff>'.$it618_wike_lang['s930'].'</font></a>';
					 }
					if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
					if($_GET['wap']==1){
						$it618_wike_td7='<span class="it618_wike_td7">'.$edittmp.$deletegetwikebtn.$pftmp.'</span>';
						
						if($it618_mode==2){
							$it618_wike_td7='<span class="it618_wike_td7">'.$oktmp.$deletegetwikebtn.$pftmp.'</span>';
						}
					}else{
						$it618_wike_td7=$edittmp.$deletegetwikebtn.$pftmp;
						
						if($it618_mode==2){
							$it618_wike_td7=$oktmp.$deletegetwikebtn.$pftmp;
						}
					}
	
				 }else{
					$it618_wike_td7='';
				 }
			}
			
			$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
			if($liii1il[6]!='w')exit;
			 
			if(($it618_authorid==$_G[uid]||$adminauthor==1) && $it618_wike_main['it618_state']!=1){
				$tmpcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike')." WHERE it618_ok=1 and it618_tid=".$tid);
				$edittmp='if(confirm(\''.it618_wike_getlang('s102').'\'))';
				$edittmp=$wike_creditname.'=<input type="text" id="it618_creditnumauto" size="5"/><input id="it618_setuids" type="hidden" value="'.$tmpuids.'"/><a href="javascript:" class="wikebtn" onclick="'.$edittmp.'it618_getajax(\'autosetmoney\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&tid='.$tid.'&it618_creditnumauto=\'+document.getElementById(\'it618_creditnumauto\').value+\'&formhash='.FORMHASH.'&ac=autosetmoney\');"><font color=#fff>'.$it618_wike_lang['s928'].'</font></a>';
				
				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
				if($it618_mode==1&&$tmpcount>0){
					$autostr='<div style="float:right;">'.it618_wike_getlang('s82').$edittmp.'</div>';
				}
			}
		}
		
		if($it618_wike_main['it618_state']!=1){
			if($_G[uid]==$it618_wike_wike['it618_uid']){
				for($i=0;$i<=20;$i++){
					if($it618_wike_wike['it618_state']==$i*5){
						$optiontmp.='<option value="'.($i*5).'" selected="selected">'.($i*5).'</option>';
					}else{
						$optiontmp.='<option value="'.($i*5).'">'.($i*5).'</option>';
					}
				}
				$selecttmp='<select style="line-height:12px" onchange="it618_getajax(\'setgetwikejd\',\'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wap='.$_GET['wap'].'&wid='.$it618_wike_wike['id'].'&it618_state=\'+this.value+\'&formhash='.FORMHASH.'&ac=setgetwikejd\');">'.$optiontmp.'</select>';
			}else{
				$selecttmp=$it618_wike_wike['it618_state'];
			}
			$selecttmp=$selecttmp.'%';
		}
		
		if($it618_wike_wike['it618_ok']==1){
			$it618_ok=' style="color:red"';
			if($it618_wike_wike['it618_jl']>0){
				$wike_getjlcreditname=$_G['setting']['extcredits'][$it618_wike['wike_getjlcredit']]['title'];
				$jlstr=$it618_wike_lang['s1024'].$it618_wike_wike['it618_jl'].$wike_getjlcreditname;
			}
			if($_GET['wap']==1){
				$it618_ok1='+'.$it618_wike_wike['it618_creditnum'].' <font color=#999>'.$jlstr.'</font>';
			}else{
				$it618_ok1='+'.$it618_wike_wike['it618_creditnum'].'<br><font color=#999>'.$jlstr.'</font>';
			}
		}else{
			$it618_ok='';
			$it618_ok1='';
			$selecttmp='';
		}
		
		if($it618_wike_main['it618_state']==1)$selecttmp='';
		
		$qqstr='';$tmpcss1='<br>';
		if($it618_wike_main['it618_uid']==$_G['uid']||$adminauthor==1){
			if($it618_wike_wike['it618_ok']==1||$it618_wike['wike_getwikeuser']==1){
				$qqstr='<a href="javascript:" onclick="showqq(2,'.$it618_wike_main['it618_tid'].','.$it618_wike_wike['it618_uid'].')"  title="'.$it618_wike_lang['s287'].'"><img src="source/plugin/it618_wike/images/u.png" align="absmiddle" style="border:none;width:18px;margin-top:-3px"/></a>';
			}
			$tmpcss1='';
		}
		
		if($_GET['wap']==1){
			$tmpattachment=$it618_wike_lang['s285'];
			$tmpattachmentshow='showattachment('.$it618_wike_wike['id'].')';
		}else{
			$tmpattachment=$it618_wike_lang['s942'];
			$tmpattachmentshow='showWindow(\'it618_showattachment\',\'plugin.php?id=it618_wike:showattachment&getwikeid='.$it618_wike_wike['id'].'\')';
		}
		
		$attachmentstr='';
		if($it618_wike_wike['it618_attachment']!=''){
			$attachmentstr='<img src="source/plugin/it618_wike/images/attachment.png" style="vertical-align:middle; margin-top:-3px;width:20px; cursor:pointer" onclick="'.$tmpattachmentshow.'">';
		}
		
		$bzstr='-';
		if($it618_wike_wike['it618_postbz']!=''||$it618_wike_wike['it618_getbz']!=''){
			$bzstr='<img src="source/plugin/it618_wike/images/bz.png" style="vertical-align:middle; margin-top:-3px;width:20px;margin-right:3px; cursor:pointer" onclick="'.$tmpattachmentshow.'">';
			if($it618_wike_main['it618_uid']==$_G['uid']||$adminauthor==1){
				if($it618_wike_wike['it618_getbzread']==0){
					$bzstr.=$it618_wike_lang['s478'];
				}
			}
			if($it618_wike_wike['it618_uid']==$_G['uid']){
				if($it618_wike_wike['it618_postbzread']==0){
					$bzstr.=$it618_wike_lang['s478'];
				}
			}
		}
		
		if($attachmentstr==''&&$bzstr=='-'){
			if($_G['uid']>0&&$it618_wike_main['it618_state']!=1){
				$bzstr='<a href="javascript:" style="text-decoration:none" onclick="'.$tmpattachmentshow.'">'.$tmpattachment.'</a>';
			}
		}
		
		if($it618_bmmoneystr!='')$bmmoneystr='<font color="#999" style="font-size:11px;">'.$it618_wike_lang['s962'].':'.$it618_wike_wike['it618_bmmoney'].'</font>'.$tmpcss1.' ';

		if($allpfcount==0){
			$pfcss='#66666';
		}else{
			$pfcss='red';
		}
		
		if($it618_ok1=='')$it618_ok1=0;
			
		if($_GET['wap']==1){
			$it618_wike_td2='<img class="imgavatar" style="float:left" src="'.it618_wike_discuz_uc_avatar($it618_wike_wike['it618_uid'],'small').'"/>';
		
			$it618_wike_get.='<tr><td class="it618_wike_td2" style="vertical-align:top;line-height:26px;text-align:left" width="55">'.$it618_wike_td2.' <span'.$it618_ok.'>'.it618_wike_getusername($it618_wike_wike['it618_uid']).' '.$qqstr.'</span>';
			$it618_wike_get.='<span style="font-size:11px;color:#999;float:right"><a href="javascript:" style="text-decoration:none" onclick="showwike(10002,'.$it618_wike_wike['it618_uid'].')"><font color=#999>'.it618_wike_getlang('s349').'(<font color="red">'.$allwikecount.'</font>)</font></a> '.$it618_wike_lang['s978'].'<font color="'.$pfcss.'">'.$allpfcount.'</font>'.$it618_wike_lang['s979'].'</span><br>';
			$it618_wike_get.='<span style="float:right;font-size:11px;color:#ccc">'.date('Y-m-d H:i:s', $it618_wike_wike['it618_time']).'</span><span style="float:left;font-size:11px;color:#999"><font color=#999>'.it618_wike_getlang('s354').'</font>'.$it618_ok1.' '.$it618_wike_lang['s963'].':'.$it618_wike_wike['it618_getwikemoney'].'</span>';
			$tmpwikegetstr=$attachmentstr.$bzstr.$bmmoneystr.$it618_wike_td7;
			if($tmpwikegetstr!==''&&$tmpwikegetstr!='-')$it618_wike_get.='<br><span style="float:left;margin-left:50px">'.$attachmentstr.$bzstr.' '.$bmmoneystr.'</span>'.$it618_wike_td7;
			$it618_wike_get.='</td></tr>';
		}else{
			if($it618_wike['rewriteurl']==0){
				$it618_wike_td2='<a href="home.php?mod=space&uid='.$it618_wike_wike['it618_uid'].'" target="_blank" c="1"><img class="imgavatar" src="'.it618_wike_discuz_uc_avatar($it618_wike_wike['it618_uid'],'small').'" width="27" height="27"/></a>';
			}else{
				$it618_wike_td2='<a href="space-uid-'.$it618_wike_wike['it618_uid'].'.html" target="_blank" c="1"><img class="imgavatar" src="'.it618_wike_discuz_uc_avatar($it618_wike_wike['it618_uid'],'small').'" width="27" height="27"/></a>';
			}
			
			if($it618_wike_td7!='')$it618_wike_td7.='<br>';
			$it618_wike_get.='<tr><td>'.$index.'</td>';
			$it618_wike_get.='<td class="it618_wike_td2" style="font-size:12px;">'.$it618_wike_td2.'<div'.$it618_ok.'>'.it618_wike_getusername($it618_wike_wike['it618_uid']).' '.$qqstr.'</div></td>';
			$it618_wike_get.='<td align="center">'.$attachmentstr.$bzstr.'</td>';
			$it618_wike_get.='<td><span style="font-size:12px;color:#999;width:150px"><a href="javascript:" style="text-decoration:none" onclick="showwike(10002,'.$it618_wike_wike['it618_uid'].')">'.it618_wike_getlang('s349').'(<font color="red">'.$allwikecount.'</font>)</a><br>'.$it618_wike_lang['s978'].'<font color="'.$pfcss.'">'.$allpfcount.'</font>'.$it618_wike_lang['s979'].'</span></td>';
			$it618_wike_get.='<td style="color:red">'.$it618_ok1.'</td>';
			$it618_wike_get.='<td style="font-size:12px;color:#999">'.date('Y-m-d H:i:s', $it618_wike_wike['it618_time']).'</td><td style="text-align:right;padding-right:3px">'.$it618_wike_td7.'<font color=#999>'.$bmmoneystr.$it618_wike_lang['s963'].':'.$it618_wike_wike['it618_getwikemoney'].'</font></td></tr>';
			$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
			if($liii1il[6]!='w')exit;
		}
		
		$index+=1;
	}
	$tmpstr="";
	
	if(($it618_authorid==$_G[uid]||$adminauthor==1)&&$it618_wike_main['it618_state']!=1){
		if($it618_mode==3){
			if($_GET['wap']==1){
				$tmpstr='<span style="float:right;padding-right:6px">'.it618_wike_getlang('s300').'<font color=red>'.($it618_wike_main['it618_mancount']-$tidwikeokcount).'</font>'.it618_wike_getlang('s700').'</span>';
			}else{
				$tmpstr='<td width=230 align="right" style="padding-right:6px">'.it618_wike_getlang('s300').'<font color=red>'.($it618_wike_main['it618_mancount']-$tidwikeokcount).'</font>'.it618_wike_getlang('s700').'</td>';
			}
		}elseif($it618_mode==2){
			if($_GET['wap']==1){
				if($tidwikeokcount>0){
					$tmpstr='<span style="float:right;padding-right:6px">'.it618_wike_getlang('s301').'<font color=red>'.intval($it618_wike_main['it618_moneycount2']/$tidwikeokcount).'</font>'.$wike_creditname.'</span>';
				}else{
					$tmpstr='<span style="float:right;padding-right:6px">'.it618_wike_getlang('s302').'</span>';
				}
			}else{
				if($tidwikeokcount>0){
					$tmpstr='<td width=230 align="right" style="padding-right:6px">'.it618_wike_getlang('s301').'<font color=red>'.intval($it618_wike_main['it618_moneycount2']/$tidwikeokcount).'</font>'.$wike_creditname.'</td>';
				}else{
					$tmpstr='<td width=230 align="right" style="padding-right:6px">'.it618_wike_getlang('s302').'</td>';
				}
			}
		}else{
			$it618_creditnumall=DB::result_first("select sum(it618_creditnum) from ".DB::table('it618_wike')." where it618_tid=$tid");
			
			if($_GET['wap']==1){
				$tmpstr='<span style="float:right;padding-right:6px">'.it618_wike_getlang('s28').'<font color=red>'.($it618_wike_main['it618_moneycount2']-$it618_creditnumall).'</font>'.$wike_creditname.''.it618_wike_getlang('s29').'</span>';
			}else{
				$tmpstr='<td width=230 align="right" style="padding-right:6px">'.it618_wike_getlang('s28').'<font color=red>'.($it618_wike_main['it618_moneycount2']-$it618_creditnumall).'</font>'.$wike_creditname.''.it618_wike_getlang('s29').'</td>';
			}
		}
		
	}
	
	if($it618_wike['wike_diy']!="")$wike_diy='<table class="wike_diy"><tr><td>'.$it618_wike['wike_diy'].'</td></tr></table>';
	if($_GET['wap']==1){
		echo '<div id="searchli_bd1" style="display:none"></div><div id="searchli_bd0">'.$wikeinfo.$wike_diy.$adminbtn.'<table class="getwiketable"><tr class="it618_wike_r1"><td colspan="2" class="adminbtntitle adminbtnbgcolor" style="font-size:13px;font-weight:normal; height:39px; line-height:39px; padding:0 8px;border-radius:3px" onclick="collapsed(\'img_getwike\',\'getwiketable\')"><img src="source/plugin/it618_wike/images/collapsed_no.png" style="vertical-align:middle;float:right;margin-top:12px;margin-left:6px;width:15px;cursor:pointer" id="img_getwike"><img src="source/plugin/it618_wike/images/getwiker.png" style="vertical-align:middle;width:15px;margin-top:-5px;margin-left:1px;margin-right:4px">'.it618_wike_getlang('s226').$tmpstr.'</td></tr><tbody id="getwiketable">'.$it618_wike_get.'</tbody></table><span style="font-size:11px;color:#888">'.$autostr.'</span></div>';
	}else{
		if($tmpstr=='')$tmpstr='<td width=200 align="right" style="padding-right:10px">'.$it618_wike_lang['s352'].'</td>';
		echo '<div id="searchli_bd1" style="display:none"></div><div id="searchli_bd0">'.$wikeinfo.$wike_diy.$adminbtn.'<table class="getwiketable"><tr class="it618_wike_r1 adminbtnbgcolor"><td width=22><img src="source/plugin/it618_wike/images/getwiker.png" style="vertical-align:middle;width:15px;margin-left:4px"></td><td width="158" style="text-align:left">'.it618_wike_getlang('s350').'</td><td>'.it618_wike_getlang('s931').'</td><td>'.it618_wike_getlang('s351').'</td><td>'.it618_wike_getlang('s353').'</td>'.$selecttmpstr.'<td width=68>'.it618_wike_getlang('s35').'</td>'.$tmpstr.'</tr>'.$it618_wike_get.'</table><span style="font-size:12px">'.$autostr.'</span></div>';
	}
	exit;
}

$n=1;
if($_GET['ac']=="getwikeclass"){
	$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'wikeclass2\',0,0)" name="wikeclass2"><span>'.$it618_wike_lang['s396'].'</span><i></i></a>';
	$query = DB::query("SELECT * FROM ".DB::table('forum_threadclass')." where fid=".intval($_GET['cid'])." order by displayorder");
	while($forum_threadclass =DB::fetch($query)) {
		$tmparr=explode("[",$forum_threadclass['name']);
		if(count($tmparr)>1){
			require_once libfile('function/discuzcode');
			$forum_threadclass['name']=discuzcode($forum_threadclass['name'], 0, 0, 0, 1, 1, 0, 0, 0, 0, 0);
		}
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'wikeclass2\','.$n.','.$forum_threadclass['typeid'].')" name="wikeclass2"><span>'.$forum_threadclass['name'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $classtmp;
	exit;
}


if($_GET['ac']=="getwikelist"){
	echo getwikelist($_GET['ac1'],intval($_GET['it618_class1']),intval($_GET['it618_class2']),$_GET['it618_wikestate'],$_GET['it618_mancount'],$_GET['it618_postuid'],$_GET['it618_getuid'],it618_wike_utftogbk($_GET['it618_name']),$_GET['it618_money1'],$_GET['it618_money2'],$_GET['it618_time1'],$_GET['it618_time2'],$_GET['page'],$_GET['it618_wikemode'],$_GET['it618_order']);
	exit;
}


if($_GET['ac']=="wikelist_get"){
	$ppp = $it618_wike['wike_wikecount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	$it618_forumid=intval($_GET['it618_class1']);
	$it618_forumtypeid=intval($_GET['it618_class2']);
	$it618_wikestate=intval($_GET['it618_wikestate']);
	$it618_wikemode=intval($_GET['it618_wikemode']);
	$it618_mancount=intval($_GET['it618_mancount']);
	$it618_order=intval($_GET['it618_order']);
	
	$sql='(m.it618_crondate=0 or m.it618_crondate<'.$_G['timestamp'].")";
	if($_G['uid']>0){
		$tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
		for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
		   if($_G['uid']==$tmpwikeadmin[$tmpi]){
			   $sql='1';
			   break;
		   }
		}
	}
	
	if($it618_forumid>0)$sql.=" and m.it618_fid=".$it618_forumid;
	if($it618_forumtypeid>0)$sql.=" and m.it618_typeid=".$it618_forumtypeid;
	
	if($it618_wikestate==0)$sql.="";
	if($it618_wikestate==1)$sql.=" and m.it618_state=10";
	if($it618_wikestate==2)$sql.=" and m.it618_state=0";
	if($it618_wikestate==3)$sql.=" and m.it618_state=1";
	
	if($it618_wikemode==0)$sql.="";
	if($it618_wikemode==1)$sql.=" and m.it618_mode=1";
	if($it618_wikemode==2)$sql.=" and m.it618_mode=2";
	if($it618_wikemode==3)$sql.=" and m.it618_mode=3";
	
	if($it618_order==0)$orderby="order by m.it618_time1 desc";
	if($it618_order==1)$orderby="order by m.it618_time2";
	if($it618_order==2)$orderby="order by m.it618_mancount desc";
	if($it618_order==3)$orderby="order by m.it618_moneycount2 desc";
	if($it618_order==4)$orderby="order by m.it618_moneycount2";
	if($it618_order==5)$orderby="order by m.it618_views desc";
	
	$count = C::t('#it618_wike#it618_wike_main')->count_by_search($sql,it618_wike_utftogbk($_GET['it618_name']),$_GET['it618_postuid'],$_GET['it618_getuid'],$_GET['it618_money1'],$_GET['it618_money2']);
	
	$n=1;
	foreach(C::t('#it618_wike#it618_wike_main')->fetch_all_by_search(
			$sql,$orderby,it618_wike_utftogbk($_GET['it618_name']),$_GET['it618_postuid'],$_GET['it618_getuid'],$_GET['it618_money1'],$_GET['it618_money2'],'','',$startlimit,$ppp
	) as $it618_wike_main) {

		$tid=$it618_wike_main['it618_tid'];
		
		$uid=$it618_wike_main['it618_uid'];
		$subject=it618_wike_getsubject($tid);
		$subject1=cutstr($subject, 40, '');
		
		$getstate=it618_wike_getstate($it618_wike_main,1);
		$getmancount=it618_wike_getmancount($it618_wike_main,1);
		$getmode=it618_wike_getmode($it618_wike_main,1);
		$getmoney=it618_wike_getmoney($it618_wike_main,1);
		$gettjimg=it618_wike_gettjimg($it618_wike_main,1);
		
		$it618_crondate='';
		if($it618_wike_main['it618_crondate']>$_G['timestamp']){
			$it618_crondate='['.$it618_wike_lang['s1030'].']';
		}
		
		$getwikelist.='<table class="wikelist">
						<tr><td onclick="dohref('.$tid.')">
						<a href="forum.php?mod=viewthread&tid='.$tid.'" id="href'.$tid.'">'.$it618_crondate.$subject.'</a> '.it618_wike_getico($tid).'
						<br><span class="spanauthortime"><a href="home.php?mod=space&uid='.$it618_wike_main['it618_uid'].'" target="_blank">'.it618_wike_getauthor($it618_wike_main['it618_uid']).'</a><em>/</em>'.date('Y-m-d', $it618_wike_main['it618_time1']).$gettjimg.'</span><span class="spanmancount">'.$getmancount.'</span>
						<br><span class="spanstate">'.$getstate.'</span>
						'.$getmode.' <span class="spanmoney">'.$getmoney.'</span>
						</td></tr>
						</table>
					   ';
		
	}
	
	$funname='getwikelist';
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select style="line-height:12px" class="pageselect" onchange="'.$funname.'(this.value,\'\')">'.$curpage.'</select>';
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_wike_getlang('s411').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',\'\')">'.it618_wike_getlang('s412').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_wike_getlang('s412').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',\'\')">'.it618_wike_getlang('s411').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',\'\')">'.it618_wike_getlang('s412').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',\'\')">'.it618_wike_getlang('s411').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_wike_getlang('s412').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	if($_GET['it618_type']=="search"){
		$classname=$it618_wike_lang['s340'];
		if($it618_forumtypeid>0){
			$classname=DB::result_first("select name from ".DB::table('forum_threadclass')." where fid=$it618_forumid and typeid=$it618_forumtypeid");;
		}else{
			if($it618_forumid>0){
				$classname=it618_wike_getforumname($it618_forumid);
			}	
		}
		
		$wikestatename=$it618_wike_lang['s405'];
		if($it618_wikestate==1)$wikestatename=$it618_wike_lang['s406'];
		if($it618_wikestate==2)$wikestatename=$it618_wike_lang['s58'];
		if($it618_wikestate==3)$wikestatename=$it618_wike_lang['s407'];
		
		$ordername=$it618_wike_lang['t73'].'<img src="source/plugin/it618_wike/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
		if($_GET['it618_order']==2)$ordername=$it618_wike_lang['t74'].'<img src="source/plugin/it618_wike/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
		if($_GET['it618_order']==3)$ordername=$it618_wike_lang['t75'].'<img src="source/plugin/it618_wike/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
		if($_GET['it618_order']==4)$ordername=$it618_wike_lang['t76'].'<img src="source/plugin/it618_wike/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
		if($_GET['it618_order']==5)$ordername=$it618_wike_lang['t76'].'<img src="source/plugin/it618_wike/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
		
		if($_GET['it618_name']=='')$it618_name=$it618_wike_lang['s1021'];else $it618_name=it618_wike_utftogbk($_GET['it618_name']);
	
		$sqlbq='<tr><td class="bq1" id="td1" onClick="getbq1(this)">'.$classname.'<img src="source/plugin/it618_wike/wap/images/arw_b.gif"></td><td class="bq2" id="td2" onClick="getbq2(this)">'.$wikestatename.'<img src="source/plugin/it618_wike/wap/images/arw_b.gif"></td><td class="bq3" id="td3" onClick="getbq3(this)">'.$ordername.'<img src="source/plugin/it618_wike/wap/images/arw_b.gif"></td><td class="bq4" id="td4"><input type="text" id="searchli_txt1" style="padding-left:3px;font-size:12px" value="'.$it618_name.'" readonly onClick="getname()"></td></tr>';
		
		if($_G['uid']>0&&isset($_GET['findkey'])&&$_GET['it618_name']!=''){
			if($it618_wike_findkey=C::t('#it618_wike#it618_wike_findkey')->fetch_by_uid_key($_G['uid'],it618_wike_utftogbk($_GET['it618_name']))){
				C::t('#it618_wike#it618_wike_findkey')->update($it618_wike_findkey['id'],array(
					'it618_count' => ($it618_wike_findkey['it618_count']+1),
					'it618_time' => $_G['timestamp']
				));
			}else{
				C::t('#it618_wike#it618_wike_findkey')->insert(array(
					'it618_uid' => $_G['uid'],
					'it618_key' => it618_wike_utftogbk($_GET['it618_name']),
					'it618_count' => 1,
					'it618_time' => $_G['timestamp']
				), true);
			}
		}
	}
	
	if($_GET['it618_postuid']>0||$_GET['it618_getuid']>0){
		$jlmoney = C::t('#it618_wike#it618_wike_main')->sum_jlmoney_by_search($sql,it618_wike_utftogbk($_GET['it618_name']),$_GET['it618_postuid'],$_GET['it618_getuid'],$_GET['it618_money1'],$_GET['it618_money2']);
		if($jlmoney=='')$jlmoney=0;
		
		$getwikelist=it618_wike_rewriteurl($getwikelist);
		
		if($_GET['it618_getuid']>0)$tmpstr=it618_wike_getlang('s336');else $tmpstr=it618_wike_getlang('s337');
		
		echo '<span class="wikesum">'.it618_wike_getlang('s338').'<font color="red">'.$count.'</font><span style="float:right">'.$tmpstr.'<font color="red">'.$jlmoney.'</font></span> </span>it618_split'.$getwikelist.'it618_split'.$multipage;
	}else{
		echo $getwikelist."it618_split".$multipage."it618_split".$sqlbq;
	}
	exit;
}


if($_GET['ac']=="getfindkey"){
	if($_G['uid']>0){
		foreach(C::t('#it618_wike#it618_wike_findkey')->fetch_all_by_uid($_G['uid']) as $it618_tmp) {	
			$getfindkey.='<tr><td><a href="javascript:" onClick="delfindkey('.$it618_tmp['id'].',\''.$it618_tmp['it618_key'].'\')" style="float:right">'.$it618_wike_lang['s64'].'</a><span onClick="findbykey(\''.$it618_tmp['it618_key'].'\')">'.$it618_tmp['it618_key'].'</span></td></tr>';
		}
	}else{
		$getfindkey='<tr><td>'.$it618_wike_lang['s1857'].'</td></tr>';
	}
	echo $getfindkey;
	exit;
}


if($_GET['ac']=="delfindkey"){
	if($_G['uid']>0){
		C::t('#it618_wike#it618_wike_findkey')->delete_by_uid_id($_G['uid'],$_GET['fid']);
	}
	exit;
}


if($_GET['ac']=="clearfindkey"){
	if($_G['uid']>0){
		C::t('#it618_wike#it618_wike_findkey')->delete_by_uid($_G['uid']);
	}
	exit;
}


if($_GET['ac']=="getpflist"){
	if($_GET['wap']==1)$ppp = $it618_wike['wike_wikecount'];else $ppp = 11;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if($_GET['type']==1){
		$postuid=$_G['uid'];
		$getuid=0;
	}else{
		$postuid=0;
		$getuid=$_G['uid'];
	}
	
	$count = C::t('#it618_wike#it618_wike_pf')->count_by_search($it618sql,'',0,$postuid,$getuid,$_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2']);
	$sum = C::t('#it618_wike#it618_wike_pf')->sum_by_search($it618sql,'',0,$postuid,$getuid,$_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$pagecount=intval($count/$ppp);
	if($page<$pagecount){
		$lastindex=$ppp;
	}else{
		$lastindex=$count;
	}
	
	$n=1;
	foreach(C::t('#it618_wike#it618_wike_pf')->fetch_all_by_search($it618sql,'it618_time desc',0,$postuid,$getuid,$_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_wike_pf) {
		if($n==$lastindex)$lastcss=' class="listlast"';else $lastcss='';
		$n=$n+1;

		$subject=it618_wike_getsubject($it618_wike_pf['it618_tid']);
		$subject1=cutstr($subject, 40, '');
		if($subject==''){
			$tidstr='<font color=#999>'.$it618_wike_lang['s1002'].'</font>';
		}else{
			$tidstr='<a href="forum.php?mod=viewthread&tid='.$it618_wike_pf['it618_tid'].'" title="'.$subject.'" target="_blank">'.$subject1.'</a>';
		}
		$tidstr=it618_wike_rewriteurl($tidstr);
		
		if($it618_wike_pf['it618_type']==1)$it618_type=$it618_wike_lang['s990'];else $it618_type=$it618_wike_lang['s991'];
		
		if($_GET['wap']==1){
			$getpflist.='<table class="wikelist">
						<tr><td>'.$tidstr.'<div class="wikelistpfdiv"><font color=#999>'.$it618_wike_lang['s349'].': </font>'.it618_wike_gettime($it618_wike_pf['it618_gettime']).' <font color=#999>'.$it618_wike_lang['s997'].': </font><font color=red>'.$it618_wike_pf['it618_bmmoney'].'</font> <font color=#999>'.$it618_wike_lang['s998'].': </font><font color=red>'.$it618_wike_pf['it618_getwikemoney'].'</font> <font color=#66666>'.$it618_type.'</font><br><span class="time">'.it618_wike_gettime($it618_wike_pf['it618_time']).'</span><span class="author">'.it618_wike_getusername($it618_wike_pf['it618_postuid']).'</span></div></td></tr>
						</table>';
		}else{
			$getpflist.='<li'.$lastcss.'>'.$tidstr.' '.it618_wike_getusername($it618_wike_pf['it618_postuid']).' <font color=#999>'.$it618_wike_lang['s349'].':</font>'.it618_wike_gettime($it618_wike_pf['it618_gettime']).' <font color=#999>'.$it618_wike_lang['s997'].':</font><font color=red>'.$it618_wike_pf['it618_bmmoney'].'</font> <font color=#999>'.$it618_wike_lang['s998'].':</font><font color=red>'.$it618_wike_pf['it618_getwikemoney'].'</font> <font color=#66666>'.$it618_type.'</font><span class="time">'.it618_wike_gettime($it618_wike_pf['it618_time']).'</span></li>';
		}
		
	}
	
	$funname='getpflist';
	if($_GET['wap']==1){
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select style="line-height:12px" class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_wike_getlang('s411').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_wike_getlang('s412').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_wike_getlang('s412').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_wike_getlang('s411').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_wike_getlang('s412').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_wike:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_wike_getlang('s411').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_wike_getlang('s412').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		echo '<span class="wikesum">'.it618_wike_getlang('s993').'<font color="red">'.$count.'</font> '.$it618_wike_lang['s978'].$wike_creditname.$it618_wike_lang['s318'].'<font color="red">'.$sum.'</font></span>it618_split'.$getpflist.'it618_split'.$multipage;
	}else{
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].'plugin.php?id=it618_wike:ajax');
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',''.$funname.'(',$multipage);
		$multipage=str_replace('this.value;;','this.value');
		
		echo '<li class="listsum"><span class="wikesum">'.it618_wike_getlang('s993').'<font color="red">'.$count.'</font> '.$it618_wike_lang['s978'].$wike_creditname.$it618_wike_lang['s318'].'<font color="red">'.$sum.'</font></span></li>'.$getpflist.'<div style="float:right;margin-top:10px">'.$multipage.'</div>';
	}
	exit;
}

function it618_showmessage($msg,$v1,$v2,$v3){
	if($_GET['wap']==1){
		if($v3['alert']=="right"){
			$tmpimg='right.gif';
		}
		if($v3['alert']=="info"){
			$tmpimg='info.gif';
		}
		if($v3['alert']=="error"){
			$tmpimg='error.gif';
		}
		//echo '<table><tr><td width="58" style="vertical-align:top;text-align:center;padding-top:6px"><img src="source/plugin/it618_wike/images/'.$tmpimg.'"></td><td>'.$msg.'</td></tr></table>';
		echo $msg.'it618_split'.$v3['alert'];
	}else{
		echo $msg.'it618_split'.$v3['alert'];
	}
}
?>