<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_wike_main`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_title` varchar(300) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_fid` int(10) unsigned NOT NULL,
  `it618_typeid` int(10) unsigned NOT NULL,
  `it618_mode` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_read` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_hfread` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_select` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_editcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mancount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bmmoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uids` varchar(800) NOT NULL,
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_moneycount1` int(10) unsigned NOT NULL,
  `it618_moneycount2` int(10) unsigned NOT NULL,
  `it618_getwikemoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc` float(9,2) NOT NULL,
  `it618_jlbl` float(9,2) NOT NULL,
  `it618_jl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_crondate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_attachment` varchar(255) NOT NULL,
  `it618_attachmentsize` float(9,3) NOT NULL,
  `it618_postbz` varchar(8000) NOT NULL,
  `it618_getbz` varchar(8000) NOT NULL,
  `it618_postbztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_getbztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_postbzread` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_getbzread` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_attachmentdown` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_attachmenttime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_creditnum` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_getwikemoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bmmoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jlbl` float(9,2) NOT NULL,
  `it618_jl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tc` float(9,2) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_pf`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_pf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_postuid` int(10) unsigned NOT NULL,
  `it618_getuid` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_gettime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_getwikemoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bmmoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_user`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(11) NOT NULL,
  `it618_bztel` varchar(11) NOT NULL,
  `it618_qq` varchar(20) NOT NULL,
  `it618_wx` varchar(80) NOT NULL,
  `it618_bz` varchar(800) NOT NULL,
  `it618_msgisok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_grouppower`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_grouppower` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_posttc` float(9,2) NOT NULL,
  `it618_gettc` float(9,2) NOT NULL,
  `it618_postjlbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_getjlbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_bmmoney` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_it618`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_it618` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_wike` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_sql` varchar(100) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_findkey`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

if(isset($_GET['pluginid'])&&$_GET['pluginid']!=''){
	DB::query("insert into ".DB::table('it618_wike_it618')."(it618_wike) values ('".addslashes($_GET['dir'])."')");
}else{
	DB::query("insert into ".DB::table('it618_wike_it618')."(it618_wike) values ('it618_wike')");
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzRhZDkwNmFjNGUxOTJmYzg4OWY1MTg0MzY0ZTE0ZDhlLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzhlZDE5N2IzY2U5MzkyOWQ0NGViOTQ1YjYxM2MwYWI3LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzI3YjM5NTcwNzRjZjk1NTBhOTQ0M2IxMTVkOGI4OWExLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzMzYjVjZTllOWY4MWUwZmFkZGEwNWYyNDUyMjAzZGM2LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzgxYjg3YWFkNzY5ZWRmMGM0MTA5MTNjMGRhNWRiZjQwLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzYwN2UxMGZmZDlhNWI4M2I1NmZjNGY3N2U1MmFmMzQ5LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzgzNWQ3Njg5ODVkODg0ODgwNDIwY2ZlNjUzOTg1NDdjLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzUyMzgxNzVlNzA2NDFkZDRjMjYzZTQ2ODM1MTI3Nzc4LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlL2I3ZmVkNDViMWJlMzliNWRjNzYxYmNjN2I0NTdkOWIyLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlL2UxZDU0NTRlNzc1YWVjNTM1ODU1MTBjZmNlNzgxODU2LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlL2Y4NjJjNWFhZTY2NzhjODQxOGExYjAwOTYxYjc0YmQyLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvdXBncmFkZS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvaW5zdGFsbC5waHA='));
?>