<?php
/**
 *	�����Ŷӣ�IT618��Ѷ��
 *	it618_copyright �����ƣ�<a href="http://www.cnit618.com" target="_blank" title="Ϊվ���ṩѧϰ����">IT618��Ѷ��</a>
 */
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_wike {
	function global_header(){
		global $_G,$it618_wike_lang;
		$it618_wike = $_G['cache']['plugin']['it618_wike'];
		$it618_witkey = $_G['cache']['plugin']['it618_witkey'];
		$it618_members = $_G['cache']['plugin']['it618_members'];
		$wike_forums = unserialize($it618_wike["wike_forums"]);
		$witkey_forums = unserialize($it618_witkey["witkey_forums"]);
		require_once DISCUZ_ROOT.'./source/plugin/it618_wike/lang.func.php';
		$i1il11i=DB::result_first("SELECT it618_wike FROM ".DB::table('it618_wike_it618'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		if(count($i1iii1)!=10)return;
		
		if($_GET['mod']=="post"&&$_GET['action']=="newthread"&&!(isset($_GET['special'])||isset($_GET['specialextra'])||isset($_GET['topicsubmit']))){
			if(in_array($_GET['fid'], $wike_forums)&&in_array($_GET['fid'], $witkey_forums)){
				if($_GET['paytype']!='credit'&&$_GET['paytype']!='money'){
					$urlarr=explode("https://",$_G['siteurl']);
					if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';		
					$url_this = $httpstr.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
					
					return '<script>if(confirm("'.$it618_wike_lang['s675'].'"))location.href="'.$url_this.'&paytype=money";else location.href="'.$url_this.'&paytype=credit";</script>';
				}else{
					$paytype=$_GET['paytype'];
				}
			}else{
				if(in_array($_GET['fid'], $wike_forums)){
					$paytype='credit';
				}
				if(in_array($_GET['fid'], $witkey_forums)){
					$paytype='money';
				}
			}
		}

		if($i1iii1[5]!='_')return;
		if($paytype=='credit'&&$_GET['mod']=="post"&&$_GET['action']=="newthread"&&!(isset($_GET['special'])||isset($_GET['specialextra']))&&in_array($_GET['fid'], $wike_forums)){
			$isok=1;
			if($it618_members['members_bdok']==1){
				if($it618_members["members_bdtype"]==1&&$_GET['action']=='newthread')$flag=1;
				if($it618_members["members_bdtype"]==2&&$_GET['action']=='reply')$flag=1;
				if($it618_members["members_bdtype"]==3&&($_GET['action']=='newthread'||$_GET['action']=='reply'))$flag=1;
			
				if($_GET['mod']=='post'&&$flag==1){
					$members_usergroups = unserialize($it618_members["members_usergroups"]);
					$members_forums=unserialize($it618_members['members_forums']);

					if(in_array($_G['groupid'], $members_usergroups)&&in_array($_GET['fid'], $members_forums)) $isok1=1;
					
					if($isok1==1){
						$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid']);
						if($count==0){					
							$isok=0;
						}
					}
				}
				
			}

			if($isok==1){
				include template('it618_wike:wikepost');
				$wikepost=$it618_wike_block;
			}
		}

		foreach(C::t('#it618_wike#it618_wike_diy')->fetch_all_by_search() as $it618_wike_diy) {
			
			if((time()-$it618_wike_diy["it618_time"])<(60*$it618_wike_diy["it618_catchtime"])){
				break;
			}else{
				C::t('#it618_wike#it618_wike_diy')->update_it618_time_by_id(time(),$it618_wike_diy["id"]);
			}

			$blockcount=C::t('#it618_wike#it618_wike_diy')->count_by_name($it618_wike_diy["it618_name"]);
			if($blockcount>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_wike/getmode.func.php';
				$content=it618_wike_getmodecontent($it618_wike_diy['it618_type'],$it618_wike_diy['it618_sql'],$it618_wike_diy['it618_modecode'],$it618_wike_diy['it618_count']);
				
				C::t('#it618_wike#it618_wike_diy')->update_summary_dateline_by_name($content,time(),$it618_wike_diy["it618_name"]);
			}
		}
		
		if(count($i1iii1)!=10)return;
		if($it618_wike["wike_credit"]==0){
			$wike_credit='<div style="font-size:20px;color:red;margin:0 auto;width:'.$it618_wike['wike_width'].'px">'.it618_wike_getlang('s201').'</div>';
		}
		return $wike_credit.$wikepost;
	}
	
	function common() {
		global $_G,$it618_wike_lang;
		$it618_wike = $_G['cache']['plugin']['it618_wike'];
		$wike_forums = unserialize($it618_wike["wike_forums"]);
		require_once DISCUZ_ROOT.'./source/plugin/it618_wike/lang.func.php';
		$i1il11i=DB::result_first("SELECT it618_wike FROM ".DB::table('it618_wike_it618'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		if($_GET['mod']=="topicadmin"&&$_GET['action']=="moderate"&&$_GET['operation']=="delete"){
			$tids="#";
			foreach($_GET['moderate'] as $key => $tid) {
				$tid=intval($tid);
				if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)>0){
					$tids.=",".$tid;
			    }
				//require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';
				//it618_wike_deletewike($tid);
			}
			$tids=str_replace("#,","",$tids);
			if($tids!="#")showmessage(it618_wike_getlang('s304').$tids.it618_wike_getlang('s305'), '', array(), array('alert' => 'info'));
		}
		
		if($_GET['handlekey']=='fastnewpost'&&$_GET['mod']=="post"&&$_GET['action']=="newthread"&&in_array($_GET['fid'], $wike_forums)){
			showmessage(it618_wike_getlang('s1037'), '', array(), array('alert' => 'info'));
		}
		
		if($_GET['mod']=="post"&&$_GET['action']=="edit"&&$_GET['delete']==1){
			$tid=intval($_GET['tid']);
			if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)>0){
				showmessage(it618_wike_getlang('s306'), '', array(), array('alert' => 'info'));
			}
		}

		if($_GET['mod']=="post"&&$_GET['action']=="edit"&&isset($_GET['cronpublish'])){
			$tid=intval($_GET['tid']);
			if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)>0){
				$it618_crondate=0;
				if($_GET['cronpublish']&&$_GET['cronpublishdate']!=''){
					$it618_crondate = strtotime($_GET['cronpublishdate']);
					DB::query("update ".DB::table('it618_wike_main')." set it618_time1=".$it618_crondate." WHERE it618_tid=".$tid);
				}
				DB::query("update ".DB::table('it618_wike_main')." set it618_crondate=".$it618_crondate." WHERE it618_tid=".$tid);
			}
		}
		
		if($_GET['mod']=="misc"&&$_GET['action']=="pubsave"){
			$tid=intval($_GET['tid']);
			if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)>0){
				DB::query("update ".DB::table('it618_wike_main')." set it618_time1=".$_G['timestamp']." WHERE it618_tid=".$tid);
				DB::query("update ".DB::table('it618_wike_main')." set it618_crondate=0 WHERE it618_tid=".$tid);
			}
		}
		
		if($_GET['mod']=="post"&&$_GET['action']=="newthread"&&in_array($_GET['fid'], $wike_forums)){
			if($_GET['paytype']=='credit'||!isset($_GET['paytype'])){
				if($it618_wike['wike_ispostrz']==1){
					if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
						if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
							
							showmessage(it618_wike_getlang('s575'), '', array(), array('alert' => 'info'));
	
						}
					}
				}
			}
		}

		if($_GET['paytype']=='credit'&&$_GET['mod']=="post"&&$_GET['action']=="newthread"&&in_array($_GET['fid'], $wike_forums)&&isset($_GET['subject'])){
			$adminauthor=0;
			if($_G['uid']>0){
				$tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
				for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
				   if($_G['uid']==$tmpwikeadmin[$tmpi]){
					   $adminauthor=1;
					   break;
				   }
				}
			}
			$uid = $_G['uid'];
			$it618_mode = intval($_GET['it618_mode']);
			$it618_mancount = intval($_GET['it618_mancount']);
			$it618_bmmoney = intval($_GET['it618_bmmoney']);
			$it618_moneycount1 = intval($_GET['it618_moneycount1']);
			$it618_moneycount2 = intval($_GET['it618_moneycount2']);
			$it618_getwikemoney = intval($_GET['it618_getwikemoney']);
			$wike_groups=(array)unserialize($it618_wike['wike_groups']);
			$wike_wikemancount=explode(",",$it618_wike['wike_wikemancount']);
			
			$wike_credit=$it618_wike['wike_credit'];
			$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
		
			if(in_array($_G['groupid'], $wike_groups)){
				
				if(DB::result_first("select count(1) from ".DB::table('it618_wike_grouppower'))==0){
					showmessage(it618_wike_getlang('s321'), '', array(), array('alert' => 'info'));
				}
				
				$bmmoney=DB::result_first("SELECT it618_bmmoney FROM ".DB::table('it618_wike_grouppower')." WHERE it618_groupid=".$_G['groupid']);
				if($it618_bmmoney>$bmmoney){
					showmessage(it618_wike_getlang('s945').$bmmoney.$wike_creditname.it618_wike_getlang('s946'), '', array(), array('alert' => 'info'));
				}
				
				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
				$count=DB::result_first("select count(1) from ".DB::table('it618_wike_main')." where it618_state!=1 and it618_uid=".$uid);
				if($adminauthor!=1&&$count>=$it618_wike['wike_postnotokcount']){
					showmessage(it618_wike_getlang('s322').' <font color=red>'.$count.'</font> '.it618_wike_getlang('s323').' <font color=red>'.$it618_wike['wike_postnotokcount'].'</font> '.it618_wike_getlang('s324'), '', array(), array('alert' => 'info'));
				}
				
				$creditnum=DB::result_first("select extcredits".$it618_wike['wike_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
				if($creditnum<$it618_wike['wike_mincount']){
					showmessage(it618_wike_getlang('s3')." <font color=red>".$it618_wike['wike_mincount']."</font> ".$wike_creditname.",".it618_wike_getlang('s4')." <font color=red>".$creditnum."</font> ".$wike_creditname."!", '', array(), array('alert' => 'info'));
				}
				
				if($adminauthor!=1){
					$tmpmoney2arr=explode(",",$it618_wike['wike_money2']);
					if($it618_mode==1){
						if($it618_moneycount2<$tmpmoney2arr[0]){
							showmessage($it618_wike_lang['s475']." <font color=red>".$tmpmoney2arr[0]."</font> ".$wike_creditname.$it618_wike_lang['s477'], '', array(), array('alert' => 'info'));
						}
					}
					if($it618_mode==2){
						if($it618_moneycount2<$tmpmoney2arr[1]){
							showmessage($it618_wike_lang['s475']." <font color=red>".$tmpmoney2arr[1]."</font> ".$wike_creditname.$it618_wike_lang['s477'], '', array(), array('alert' => 'info'));
						}
						
					}
					if($it618_mode==3){
						if($it618_moneycount2<$tmpmoney2arr[2]){
							showmessage($it618_wike_lang['s476']." <font color=red>".$tmpmoney2arr[2]."</font> ".$wike_creditname.$it618_wike_lang['s477'], '', array(), array('alert' => 'info'));
						}
					}
				}
		
				$it618_groupid=$_G['groupid'];
				$it618_posttc=DB::result_first("select it618_posttc from ".DB::table('it618_wike_grouppower')." where it618_groupid=".$it618_groupid);
				
				
				if($it618_mode==3){
					if($it618_mancount>$wike_wikemancount[2]){
						showmessage($it618_wike_lang['s547'].'<font color=red>'.$wike_wikemancount[2].'</font>', '', array(), array('alert' => 'info'));
					}
					
					if($it618_moneycount2<1){
						showmessage(it618_wike_getlang('s262'), '', array(), array('alert' => 'info'));
					}
					
					if($it618_mancount<=0){
						showmessage(it618_wike_getlang('s263'), '', array(), array('alert' => 'info'));
					}
					if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
					$wike_credit=$it618_wike['wike_credit'];
					$curcreditcount=DB::result_first("select extcredits".$wike_credit." from ".DB::table('common_member_count')." where uid=".$uid);
					
					$it618_tcnum=intval($it618_posttc*$it618_moneycount2*$it618_mancount/100);if($it618_posttc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];
					if(($it618_moneycount2*$it618_mancount+$it618_tcnum)>$curcreditcount){
						showmessage(it618_wike_getlang('s264').$wike_creditname."(<font color=red>".$curcreditcount."</font>)".it618_wike_getlang('s68'), '', array(), array('alert' => 'info'));
					}
					
				}else{
					$it618_time2=strtotime($_GET['it618_time2']);
					
					if($it618_mancount<=0){
						showmessage(it618_wike_getlang('s83'), '', array(), array('alert' => 'info'));
					}
					if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
					if($it618_moneycount2<1){
						showmessage(it618_wike_getlang('s42'), '', array(), array('alert' => 'info'));
					}
					
					$wike_credit=$it618_wike['wike_credit'];
					$curcreditcount=DB::result_first("select extcredits".$wike_credit." from ".DB::table('common_member_count')." where uid=".$uid);
					if($it618_mode==2){
						if($it618_mancount>$wike_wikemancount[1]){
							showmessage($it618_wike_lang['s547'].'<font color=red>'.$wike_wikemancount[1].'</font>', '', array(), array('alert' => 'info'));
						}
					}else{
						if($it618_mancount>$wike_wikemancount[0]){
							showmessage($it618_wike_lang['s547'].'<font color=red>'.$wike_wikemancount[0].'</font>', '', array(), array('alert' => 'info'));
						}
					}
					
					$it618_tcnum=intval($it618_posttc*$it618_moneycount2/100);	if($it618_posttc>0&&$it618_tcnum==0)$it618_tcnum=$it618_wike['wike_tccheck'];
					if($it618_moneycount2+$it618_tcnum>$curcreditcount){
						showmessage(it618_wike_getlang('s319').$wike_creditname."(<font color=red>".$curcreditcount."</font>)".it618_wike_getlang('s68'), '', array(), array('alert' => 'info'));
					}
					
					if($it618_time2<=$_G['timestamp']){
						showmessage(it618_wike_getlang('s44'), '', array(), array('alert' => 'info'));
					}
				}
				if(lang('plugin/it618_wike', $it618_wike_lang['it618'])!=$it618_wike_lang['version'])exit;
		
			}else{
				showmessage(it618_wike_getlang('s182'), '', array(), array('alert' => 'info'));
			}
			
			$uid = $_G['uid'];
			$fid = intval($_GET['fid']);
			$it618_mode = intval($_GET['it618_mode']);
			$it618_read = intval($_GET['it618_read']);
			$it618_hfread = intval($_GET['it618_hfread']);
			$it618_mancount = intval($_GET['it618_mancount']);
			$it618_bmmoney = intval($_GET['it618_bmmoney']);
			$it618_moneycount1 = intval($_GET['it618_moneycount1']);
			$it618_moneycount2 = intval($_GET['it618_moneycount2']);
			$it618_getwikemoney = intval($_GET['it618_getwikemoney']);
			if($i1iii1[5]!='_')return;
			$it618_time2=strtotime($_GET['it618_time2']);
			if(count($i1iii1)!=10)return;
			$it618_select=intval($_GET['it618_select']);
			
			$it618_crondate=0;$it618_time1=$_G['timestamp'];
			if($_GET['cronpublish']&&$_GET['cronpublishdate']!=''){
				$it618_crondate = strtotime($_GET['cronpublishdate']);
				$it618_time1=$it618_crondate;
			}
			
			$it618_groupid=$_G['groupid'];
			$it618_posttc=DB::result_first("select it618_posttc from ".DB::table('it618_wike_grouppower')." where it618_groupid=".$it618_groupid);
			$it618_postjlbl=DB::result_first("select it618_postjlbl from ".DB::table('it618_wike_grouppower')." where it618_groupid=".$it618_groupid);
			
			if($_GET['it618_uids']!=''){
				require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';
				$tmpuidsarr=explode(",",$_GET['it618_uids']);
				for($i=0;$i<count($tmpuidsarr);$i++){
					if(it618_wike_getusername(intval($tmpuidsarr[$i]))!=''){
						$tmpuids.=$tmpuidsarr[$i].',';
					}
				}
				if($tmpuids!=''){
					$tmpuids=$tmpuids.'@';
					$tmpuids=str_replace(",@","",$tmpuids);
				}
			}
			
			$setarr = array(
				  'it618_uid' => $uid,
				  'it618_tid' => $tid,
				  'it618_mode' => $it618_mode,
				  'it618_read' => $it618_read,
				  'it618_hfread' => $it618_hfread,
				  'it618_select' => $it618_select,
				  'it618_mancount' => $it618_mancount,
				  'it618_bmmoney' => $it618_bmmoney,
				  'it618_moneycount1' => $it618_moneycount1,
				  'it618_moneycount2' => $it618_moneycount2,
				  'it618_getwikemoney' => $it618_getwikemoney,
				  'it618_state' => 10,
				  'it618_tc' => $it618_posttc,
				  'it618_jlbl' => $it618_postjlbl,
				  'it618_crondate' => $it618_crondate,
				  'it618_time1' => $it618_time1,
				  'it618_time2' => $it618_time2,
				  'it618_title' => $_GET['subject'],
				  'it618_uids' => $tmpuids
			);
			if(count($i1iii1)!=10)return;
			$id = C::t('#it618_wike#it618_wike_main')->insert($setarr, true);
			if($id>0){
				if($i1iii1[4]!='8')return;
				dsetcookie('it618_wike_findtid'.$fid,$id,30);
			}
			
		}
	}
	
	function post_message($value){
		global $_G,$it618_wike_lang;
		$it618_wike = $_G['cache']['plugin']['it618_wike'];
		
		$type=$value['param'][0];
		$fid=$value['param'][2]['fid'];
		$tid=$value['param'][2]['tid'];
		$pid=$value['param'][2]['pid'];
		
		if($type=='post_newthread_succeed'){
			$wid=getcookie('it618_wike_findtid'.$fid);
			if($wid>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';
				wikefind($wid,$tid);
				dsetcookie('it618_wike_findtid'.$fid,0,30);
			}
		}
	}

}

class plugin_it618_wike_forum extends plugin_it618_wike{
	
	function viewthread_sidetop_output(){
		global $_G,$it618_wike_lang,$postlist;
			
		$it618_wike = $_G['cache']['plugin']['it618_wike'];
		$wike_forums = unserialize($it618_wike["wike_forums"]);
		$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
		$i1il11i=DB::result_first("SELECT it618_wike FROM ".DB::table('it618_wike_it618'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		if($it618_wike["wike_lefttipsset"]==1) return array();
		if($it618_wike["wike_lefttipsset"]==2){
			if(!in_array($_G['fid'], $wike_forums)) return array();
		}
		if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$_G['tid'])){
			if($i1iii1[4]!='8')return;
			$viewthread_sidetop=array();
			foreach($postlist as $id => $post){
				$uid=$post['authorid'];
				if($uid=="")$uid=0;
				if(count($i1iii1)!=10)return;
				if($uid>0){
					$allpostcount = C::t('#it618_wike#it618_wike_main')->count_by_search('','',$uid,0);
					$allwikecount =C::t('#it618_wike#it618_wike_main')->count_by_search('','',0,$uid);
		
					if($i1iii1[5]!='_')return;
					$wike_lefttips='<div style="margin-top:-3px;margin-bottom:10px;text-align:center"><a href="javascript:" style="text-decoration:none" onclick="showwike(10001,'.$uid.')">'.it618_wike_getlang('s348').'(<font color="red">'.$allpostcount.'</font>)</a> <a href="javascript:" style="text-decoration:none" onclick="showwike(10002,'.$uid.')">'.it618_wike_getlang('s349').'(<font color="red">'.$allwikecount.'</font>)</a></div>';
					if($i1iii1[1]!='t')return;
				}
				$viewthread_sidetop[]=$wike_lefttips;
	
			}
	
			return $viewthread_sidetop;
		}
	}
	
	function forumdisplay_thread_subject_output(){
		global $_G,$it618_wike_lang;
	
		$it618_wike = $_G['cache']['plugin']['it618_wike'];
		$wike_forums = unserialize($it618_wike["wike_forums"]);
		$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
		$i1il11i=DB::result_first("SELECT it618_wike FROM ".DB::table('it618_wike_it618'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		if(!in_array($_G['fid'], $wike_forums)) return array();
		
		$thread_subject=array();
		$threadlist = $_G['forum_threadlist'];
		foreach($threadlist as $id => $thread){
			if($thread['tid']>0){
				if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$thread['tid'])){
					require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';
					$getstate=it618_wike_getstate($it618_wike_main,0);
					$getmancount=it618_wike_getmancount1($it618_wike_main,0);
					$getmoney=it618_wike_getmoney1($it618_wike_main,0);
					$gettjimg=it618_wike_gettjimg($it618_wike_main,0);
	
					if($i1iii1[2]!='6')return;
					$thread_subject[$id]='<span style="float:right;color:#999; font-size:12px">'.$getstate.'</span> <span style="color:#999; font-size:12px">'.$getmoney.'</span> <span style="color:#999; font-size:12px; padding-left:6px">'.$getmancount.'</span>';
				}
			}
		}

		return $thread_subject;
	}
	
	function forumdisplay_thread_output(){
		global $_G,$it618_wike_lang;
			
		$it618_wike = $_G['cache']['plugin']['it618_wike'];
		$wike_forums = unserialize($it618_wike["wike_forums"]);
		$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
		$i1il11i=DB::result_first("SELECT it618_wike FROM ".DB::table('it618_wike_it618'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		if(!in_array($_G['fid'], $wike_forums)) return array();
		
		$thread=array();
		$threadlist = $_G['forum_threadlist'];
		foreach($threadlist as $id => $thread1){
			if($thread1['tid']>0){
				if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$thread1['tid'])){
					require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';
					$getmode=it618_wike_getmode1($it618_wike_main,0);
					$thread[$id]=$getmode.' ';
				}
			}
		}

		return $thread;
	}
	
	function viewthread_posttop_output(){
			global $_G,$it618_wike_lang, $postlist;
			require_once DISCUZ_ROOT.'./source/plugin/it618_wike/lang.func.php';
			$it618_wike = $_G['cache']['plugin']['it618_wike'];
			$wike_forums = unserialize($it618_wike["wike_forums"]);
			$wike_creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
			$wike_forums = unserialize($it618_wike["wike_forums"]);
			if(!in_array($_G['fid'], $wike_forums)) return array();
			$i1il11i=DB::result_first("SELECT it618_wike FROM ".DB::table('it618_wike_it618'));
		    $i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
			if($_G['tid']=='')return array();

			if(count($i1iii1)!=10)return;
			$n=1;
			
			$tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
			for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
			   if($_G['uid']==$tmpwikeadmin[$tmpi]){
				   $adminauthor=1;
				   break;
			   }
			}
			
			if(!($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$_G['tid']))){
				return array();
			}
			
			foreach($postlist as $id => $post) {
				if($i1iii1[2]!='6')return;
				
				if($post['first']){
					
					$it618_state=$it618_wike_main['it618_state'];
					$it618_wike_mainuid=$it618_wike_main['it618_uid'];
					DB::query("update ".DB::table('it618_wike_main')." set it618_views=it618_views+1 WHERE it618_tid=".$_G['tid']);
					
					$it618_first=1;
					$widthtmp=317+$it618_width;
					include template('it618_wike:wike');
					
					$it618_read=$it618_wike_main['it618_read'];
					if($it618_read==2)$readabout=$it618_wike_lang['t58'];
					if($it618_read==3)$readabout=$it618_wike_lang['t83'];
					$readstr='<img src="source/plugin/it618_wike/images/lock.png" style="vertical-align:middle;height:48px"><font color=red>'.$readabout.'</font>';
					if($postlist[$id]['authorid']!=$_G['uid']){
						if($it618_read==1)$readstr=$post['message'];
						if($it618_read==2){
							if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$_G['tid']." and it618_uid=".$_G['uid'])>0)$readstr=$post['message'];
						}
						if($it618_read==3){
							if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$_G['tid']." and it618_ok=1 and it618_uid=".$_G['uid'])>0)$readstr=$post['message'];
						}
					}else{
						$readstr=$post['message'];
					}
					
					if($adminauthor==1){
						$readstr=$post['message'];
					}

					$post['message']=$it618_wike_block.$readstr;
					if($i1iii1[3]!='1')return;
					$postlist[$id] =$post;
				}else{
					if($i1iii1[5]!='_')return;
					if($it618_wike['wike_isreply']==1){
						$query = DB::query("SELECT * FROM ".DB::table('it618_wike')." WHERE it618_tid=".$_G['tid']." order by id");
						$it618_mode=$it618_wike_main['it618_mode'];
						$it618_moneycount2=$it618_wike_main['it618_moneycount2'];
						if($it618_mode==2){
							$it618_wike['wike_jiangedit']=0;
							$it618_wike['wike_isreply']=0;
						}
						$it618_wike_replay="";
						while($it618_wike_wike =DB::fetch($query)) {
							if($postlist[$id]['authorid']==$it618_wike_wike['it618_uid']){
								 if($it618_mode==3){
									 if($it618_state!=1&&($it618_wike_mainuid==$_G['uid']||$adminauthor==1)){
											if($it618_wike_wike['it618_ok']==1){
												if($it618_wike_wike['it618_creditnum']==0){
													$it618_wike_replay='<div name="it618_wike_reply'.$it618_wike_wike['it618_uid'].'" class="it618_wike_reply"><a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s299').$it618_wike_main['it618_moneycount2'].$wike_moneyname.it618_wike_getlang('s317').'\')){it618_getajax(\'caina1\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=caina\')}">'.$it618_wike_lang['s927'].'</a> '.it618_wike_getlang('s316').' <font color=red>'.$it618_moneycount2.'</font> <font color=green>'.$wike_moneyname.'</font></div>';
												}
											}else{
												$it618_wike_replay='<div name="tmpdiv'.$it618_wike_wike['it618_uid'].'" style="display:none"><a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s299').$it618_wike_main['it618_moneycount2'].$wike_moneyname.it618_wike_getlang('s317').'\')){it618_getajax(\'caina1\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=caina\')}">'.$it618_wike_lang['s927'].'</a> '.it618_wike_getlang('s316').' <font color=red>'.$it618_moneycount2.'</font> <font color=green>'.$wike_moneyname.'</font></div><div name="it618_wike_reply'.$it618_wike_wike['it618_uid'].'" class="it618_wike_reply"><a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s247').'\')){it618_getajax(\'setselect1\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&tid='.$_G['tid'].'&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=setselect\')}">'.$it618_wike_lang['s929'].'</a></div>';
											}
									 }
									 
								 }else{
									 if($it618_wike['wike_jiangedit']==1){
										 $jiangedit=1;
									 }else{
										 if($it618_wike_wike['it618_creditnum']>0){
											 $jiangedit=0;
										 }else{
											 $jiangedit=1;
										 }
									 }
									 if($it618_state!=1&&($it618_wike_mainuid==$_G['uid']||$adminauthor==1)&&$jiangedit==1){
											if($it618_wike_wike['it618_ok']==1){
												$it618_wike_replay='<div name="it618_wike_reply'.$it618_wike_wike['it618_uid'].'" class="it618_wike_reply" style="display:none"></div>';
												if($it618_mode!=2){
												$it618_wike_replay='<div name="it618_wike_reply'.$it618_wike_wike['it618_uid'].'" class="it618_wike_reply">'.$wike_creditname.'=<input type="text" value="'.$it618_wike_wike['it618_creditnum'].'" id="it618_creditnum'.$postlist[$id]['pid'].'" size="5" name="it618_wike_replyinput'.$it618_wike_wike['it618_uid'].'"/><a href="javascript:" class="wikebtn" onclick="it618_getajax(\'setmoney1\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wikeid='.$it618_wike_wike['id'].'&it618_creditnum=\'+document.getElementById(\'it618_creditnum'.$postlist[$id]['pid'].'\').value+\'&formhash='.FORMHASH.'&ac=setmoney\')">'.$it618_wike_lang['s928'].'</a></div>';
												}
											}else{
												$it618_wike_replay='<div name="tmpdiv'.$it618_wike_wike['it618_uid'].'" style="display:none">'.$wike_creditname.'=<input type="text" value="0" id="it618_creditnum'.$postlist[$id]['pid'].'" size="5" name="it618_wike_replyinput'.$it618_wike_wike['it618_uid'].'"/><a href="javascript:" class="wikebtn" onclick="it618_getajax(\'setmoney1\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&wikeid='.$it618_wike_wike['id'].'&it618_creditnum=\'+document.getElementById(\'it618_creditnum'.$postlist[$id]['pid'].'\').value+\'&formhash='.FORMHASH.'&ac=setmoney\')">'.$it618_wike_lang['s928'].'</a></div><div name="it618_wike_reply'.$it618_wike_wike['it618_uid'].'" class="it618_wike_reply"><a href="javascript:" class="wikebtn" onclick="if(confirm(\''.it618_wike_getlang('s247').'\')){it618_getajax(\'setselect1\',\''.$it618_wike_wike['it618_uid'].'\',\''.$_G['siteurl'].'plugin.php?id=it618_wike:ajax&tid='.$_G['tid'].'&wikeid='.$it618_wike_wike['id'].'&formhash='.FORMHASH.'&ac=setselect\')}">'.$it618_wike_lang['s929'].'</a></div>';
											}
									 }
									 
									 if($i1iii1[4]!='8')return;
									 
								 }
								 
								 if($it618_wike_replay==''){
									if($it618_wike_wike['it618_creditnum']>0){
										if($it618_mode==3){
											$it618_wike_replay='<div class="it618_wike_reply">'.it618_wike_getlang('s290').' <font color=green>'.$wike_creditname.'</font><font color=red>+'.$it618_wike_wike['it618_creditnum'].'</font></div>';
										}else{
											 $it618_wike_replay='<div class="it618_wike_reply">'.it618_wike_getlang('s36').' <font color=green>'.$wike_creditname.'</font><font color=red>+'.$it618_wike_wike['it618_creditnum'].'</font></div>';
										}
									}
								 }
	
							}
						}
						if($i1iii1[6]!='w')return;
					}
					
					if($it618_wike_main['it618_hfread']==1){
						$hfreadstr='<img src="source/plugin/it618_wike/images/lock.png" style="vertical-align:middle;height:48px"><font color=red>'.$it618_wike_lang['s562'].'</font>';
						if($postlist[$id]['authorid']==$_G['uid']){
							$hfreadstr=$post['message'];
						}
					}
					
					if($it618_wike_main['it618_hfread']==2){
						$hfreadstr=$post['message'];
					}
					
					if($it618_wike_main['it618_hfread']==3){
						$hfreadstr='<img src="source/plugin/it618_wike/images/lock.png" style="vertical-align:middle;height:48px"><font color=red>'.$it618_wike_lang['s566'].'</font>';
						if($postlist[$id]['authorid']!=$_G['uid']){
							if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$_G['tid']." and it618_uid=".$_G['uid'])>0)$hfreadstr=$post['message'];
						}else{
							$hfreadstr=$post['message'];
						}
					}
					
					if($it618_wike_main['it618_hfread']==4){
						$hfreadstr='<img src="source/plugin/it618_wike/images/lock.png" style="vertical-align:middle;height:48px"><font color=red>'.$it618_wike_lang['s567'].'</font>';
						if($postlist[$id]['authorid']!=$_G['uid']){
							if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." WHERE it618_tid=".$_G['tid']." and it618_ok=1 and it618_uid=".$_G['uid'])>0)$hfreadstr=$post['message'];
						}else{
							$hfreadstr=$post['message'];
						}
					}
					
					if($adminauthor==1||$it618_wike_mainuid==$_G['uid']){
						$hfreadstr=$post['message'];
					}
			
					$post['message']=$it618_wike_replay.$hfreadstr;
					
					$postlist[$id] =$post;
				}
				
				$n=$n+1;
			}
			
			
			return array();
	}

}
?>