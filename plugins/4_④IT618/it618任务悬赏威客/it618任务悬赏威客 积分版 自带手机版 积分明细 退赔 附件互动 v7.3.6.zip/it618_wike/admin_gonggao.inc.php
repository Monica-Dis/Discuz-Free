<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
global $_G;

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function/it618_wike.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_gonggao');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_gonggao' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');


require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();
?>