<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

$it618_type0='';$it618_type1='';$it618_type2='';
if($_GET['it618_type']==0)$it618_type0='selected="selected"';
if($_GET['it618_type']==1)$it618_type1='selected="selected"';
if($_GET['it618_type']==2)$it618_type2='selected="selected"';

if(submitcheck('it618submit')){
	$del=0;
	
	if($reabc[8]!='k')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_wike#it618_wike_pf')->delete_by_id($delid);
		$del=$del+1;
	}

	cpmsg($it618_wike_lang['s1003'].$del,"action=plugins&identifier=$identifier&cp=admin_pf&pmod=admin_pf&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_pf&pmod=admin_pf&operation=$operation&do=$do");
showtableheaders($it618_wike_lang['s983'],'it618_wike_pf');

showsubmit('it618sercsubmit', $it618_wike_lang['s984'], $it618_wike_lang['s985'].' <input name="it618_tid" value="'.$_GET['it618_tid'].'" class="txt" style="width:50px" />'.$it618_wike_lang['s986'].' <input name="it618_postuid" value="'.$_GET['it618_postuid'].'" class="txt" style="width:50px" /> '.$it618_wike_lang['s987'].' <input name="it618_getuid" value="'.$_GET['it618_getuid'].'" class="txt" style="width:50px" /> '.$it618_wike_lang['s988'].' <select name="it618_type"><option value=0 '.$it618_type0.'>'.$it618_wike_lang['s989'].'</option><option value=1 '.$it618_type1.'>'.$it618_wike_lang['s990'].'</option><option value=2 '.$it618_type2.'>'.$it618_wike_lang['s991'].'</option></select>'.$it618_wike_lang['s992'].' <input name="it618_time1" class="txt" style="width:80px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time1'].'" /> - <input name="it618_time2" class="txt" style="width:80px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time2'].'"/>');
	
	$count = C::t('#it618_wike#it618_wike_pf')->count_by_search($it618sql,'',$_GET['it618_tid'],$_GET['it618_postuid'],$_GET['it618_getuid'],$_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2']);
	$sum = C::t('#it618_wike#it618_wike_pf')->sum_by_search($it618sql,'',$_GET['it618_tid'],$_GET['it618_postuid'],$_GET['it618_getuid'],$_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	echo '<tr><td colspan=4>'.$it618_wike_lang['s993'].$count.' '.$it618_wike_lang['s978'].$wike_creditname.$it618_wike_lang['s318'].$sum.'</td></tr>';
	showsubtitle(array('', $it618_wike_lang['s994'], $it618_wike_lang['s995'],$it618_wike_lang['s996'],$it618_wike_lang['s997'],$it618_wike_lang['s998'],$it618_wike_lang['s999'],$it618_wike_lang['s1000'],$it618_wike_lang['s1001']));
	
	foreach(C::t('#it618_wike#it618_wike_pf')->fetch_all_by_search($it618sql,'it618_time desc',$_GET['it618_tid'],$_GET['it618_postuid'],$_GET['it618_getuid'],$_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_wike_pf) {
		
		$subject=it618_wike_getsubject($it618_wike_pf['it618_tid']);
		if($subject==''){
			$tidstr='<font color=#999>'.$it618_wike_lang['s1002'].'</font>';
		}else{
			$tidstr='<a href="forum.php?mod=viewthread&tid='.$it618_wike_pf['id'].'" target="_blank">'.$subject.'</a>';
		}
		$tidstr=it618_wike_rewriteurl($tidstr);
		
		$postuidstr='<a href="" target="_blank">'.it618_wike_getusername($it618_wike_pf['it618_postuid']).'</a>';
		$postuidstr=it618_wike_rewriteurl($postuidstr);
		
		$getuidstr='<a href="" target="_blank">'.it618_wike_getusername($it618_wike_pf['it618_getuid']).'</a>';
		$getuidstr=it618_wike_rewriteurl($getuidstr);
		
		if($it618_wike_pf['it618_type']==1)$it618_type=$it618_wike_lang['s990'];else $it618_type=$it618_wike_lang['s991'];
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id".$it618_wike_pf['id']."\" name=\"delete[]\" value=\"".$it618_wike_pf['id']."\"><label for=\"id".$it618_wike_pf['id']."\">".$it618_wike_pf['id']."</label><input type=\"hidden\" name=\"id[".$it618_wike_pf['id']."]\" value=\"".$it618_wike_pf['id']."\">",
			$tidstr,
			$postuidstr,
			$getuidstr,
			$it618_wike_pf['it618_bmmoney'],
			$it618_wike_pf['it618_getwikemoney'],
			date('Y-m-d H:i:s', $it618_wike_pf['it618_gettime']),
			$it618_type,
			date('Y-m-d H:i:s', $it618_wike_pf['it618_time'])
		));
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=10)return;
showtablefooter();
echo '<script charset="utf-8" src="source/plugin/it618_wike/js/Calendar1.js"></script>';
?>