<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if(submitcheck('it618submit')){

	if(is_array($_GET['it618_posttc'])) {
		foreach($_GET['it618_posttc'] as $id => $val) {
			
				C::t('#it618_wike#it618_wike_grouppower')->update($id,array(
					'it618_posttc' => floatval($_GET['it618_posttc'][$id]),
					'it618_gettc' => floatval($_GET['it618_gettc'][$id]),
					'it618_postjlbl' => floatval($_GET['it618_postjlbl'][$id]),
					'it618_getjlbl' => floatval($_GET['it618_getjlbl'][$id]),
					'it618_bmmoney' => floatval($_GET['it618_bmmoney'][$id])
				));
		}
	}

	cpmsg($it618_wike_lang['s70'], "action=plugins&identifier=$identifier&cp=admin_grouppower&pmod=admin&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return;
if(submitcheck('it618daosubmit')) {
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike_grouppower')." WHERE it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_wike#it618_wike_grouppower')->insert(array(
				'it618_groupid' => $common_usergroup['groupid'],
				'it618_posttc' => 5,
				'it618_gettc' => 5,
			), true);
		}
	}
}

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike_grouppower'))==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike_grouppower')." WHERE it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_wike#it618_wike_grouppower')->insert(array(
				'it618_groupid' => $common_usergroup['groupid'],
				'it618_posttc' => 5,
				'it618_gettc' => 5,
			), true);
		}
	}	
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_class2&pmod=admin&operation=$operation&do=$do");

showtableheaders($it618_wike_lang['s71'],'it618_wike_grouppower');
	showsubmit('it618daosubmit', $it618_wike_lang['s72']);
	if($reabc[5]!='_')return;
	$posttccount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike_main')." where it618_state=1");
	$posttcsum=DB::result_first("SELECT SUM(it618_tc*it618_moneycount2) FROM ".DB::table('it618_wike_main')." where it618_state=1 and it618_mode!=2");
	$posttcsum=$posttcsum+DB::result_first("SELECT SUM(it618_tc*it618_moneycount2*it618_mancount) FROM ".DB::table('it618_wike_main')." where it618_state=1 and it618_mode=2");
	$gettccount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wike')." where it618_creditnum>0");
	$gettcsum=DB::result_first("SELECT SUM(it618_tc*it618_creditnum) FROM ".DB::table('it618_wike')." where it618_creditnum>0");
	$posttcsum=intval($posttcsum);
	$gettcsum=intval($gettcsum);
	
	echo '<tr><td colspan=10><font color=red>'.$it618_wike_lang['s320'].'</font></td></tr>';
	echo '<tr><td colspan=10>'.$it618_wike_lang['s73'].'<font color=red>'.$posttccount.'/'.$posttcsum.'</font> '.$it618_wike_lang['s74'].'<font color=red>'.$gettccount.'/'.$gettcsum.'</font> '.$it618_wike_lang['s75'].'<font color=red>'.($posttccount+$gettccount).'/'.($posttcsum+$gettcsum).'</font><span style="float:right;color:blue">'.$it618_wike_lang['s941'].'</span></td></tr>';
	showsubtitle(array($it618_wike_lang['s76'],$it618_wike_lang['s77'],$it618_wike_lang['s78'],$it618_wike_lang['s1026'],$it618_wike_lang['s940']));
	$query = DB::query("SELECT p.id,g.groupid,g.grouptitle,p.* FROM ".DB::table('it618_wike_grouppower')." p,".DB::table('common_usergroup')." g WHERE p.it618_groupid=g.groupid");
	while($it618_wike_grouppower =	DB::fetch($query)) {
		
		if($reabc[1]!='t')return;
		showtablerow('', array('class="td28"', '', ''), array(
			$it618_wike_grouppower[grouptitle]."<input type=\"hidden\" name=\"id[".$it618_wike_grouppower['id']."]\" value=\"".$it618_wike_grouppower['id']."\">",
			"<input type=\"text\" class=\"txt\" style=\"width:80px;margin-right:3px\" name=\"it618_posttc[".$it618_wike_grouppower['id']."]\" value=\"".$it618_wike_grouppower['it618_posttc']."\">%",
			"<input type=\"text\" class=\"txt\" style=\"width:80px;margin-right:3px\" name=\"it618_gettc[".$it618_wike_grouppower['id']."]\" value=\"".$it618_wike_grouppower['it618_gettc']."\">%",
			"<input type=\"text\" class=\"txt\" style=\"width:40px;margin-right:3px\" name=\"it618_postjlbl[".$it618_wike_grouppower['id']."]\" value=\"".$it618_wike_grouppower['it618_postjlbl']."\">%/<input type=\"text\" class=\"txt\" style=\"width:40px;margin-right:3px\" name=\"it618_getjlbl[".$it618_wike_grouppower['id']."]\" value=\"".$it618_wike_grouppower['it618_getjlbl']."\">%",
			"<input type=\"text\" class=\"txt\" style=\"width:80px\" name=\"it618_bmmoney[".$it618_wike_grouppower['id']."]\" value=\"".$it618_wike_grouppower['it618_bmmoney']."\">",
		));
	}
	showsubmit('it618submit', $it618_wike_lang['s81']);
	showtablefooter();
?>