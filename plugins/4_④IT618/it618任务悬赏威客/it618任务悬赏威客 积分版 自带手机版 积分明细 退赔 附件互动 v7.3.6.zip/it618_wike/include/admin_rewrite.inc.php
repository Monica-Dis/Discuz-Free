<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_wike/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_wike/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_wike/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$wike_home=\''.'wike'."';\n";
		$fileData .= '$wike_wap=\''.'wike_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$wike_home1=\''.$urltype."';\n";
		$fileData .= '$wike_wap1=\'-{pagetype}-{cid}-{uid}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_wike/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_wike/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$wike_home=\''.str_replace("-","",$_GET['wike_home'])."';\n";
		$fileData .= '$wike_wap=\''.str_replace("-","",$_GET['wike_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$wike_home1=\''.$urltype."';\n";
		$fileData .= '$wike_wap1=\'-{pagetype}-{cid}-{uid}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_wike_lang['s390'], "action=plugins&identifier=$identifier&cp=admin_rewrite&pmod=admin_rewrite&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rewrite&pmod=admin_rewrite&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_wike_lang['s394'].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_wike_lang['s436'].'</font></td></tr>
<tr><td colspan="3">'.$it618_wike_lang['s437'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_wike_lang['s438'].'</th><th>'.$it618_wike_lang['s439'].'</th><th>'.$it618_wike_lang['s440'].'</th></tr>
<tr class="hover">
<td>'.$it618_wike_lang['s392'].'</td><td></td><td class="longtxt"><input name="wike_home" value="'.$wike_home.'"/>'.$wike_home.$wike_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_wike_lang['s393'].'</td><td>{pagetype}, {cid}</td><td class="longtxt"><input name="wike_wap" value="'.$wike_wap.'"/>'.$wike_wap.$wike_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_wike_lang['s391']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_wike_lang['s448'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$wike_home.$urltype.'$ $1/plugin.php?id=it618_wike:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$wike_wap.$urltype.'$ $1/plugin.php?id=it618_wike:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$wike_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_wike:wap&pagetype=$2&cid=$3&uid=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$wike_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_wike:wap&pagetype=$2&cid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$wike_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_wike:wap&pagetype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_wike_lang['s449'].'</h1>
<pre class="colorbox">
'.$it618_wike_lang['s450'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$wike_home.$urltype.'$ plugin.php?id=it618_wike:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$wike_wap.$urltype.'$ plugin.php?id=it618_wike:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$wike_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_wike:wap&pagetype=$1&cid=$2&uid=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$wike_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_wike:wap&pagetype=$1&cid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$wike_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_wike:wap&pagetype=$1&%1</font>

</pre>

<h1>'.$it618_wike_lang['s451'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$wike_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_wike:index&$3
RewriteRule ^(.*)/'.$wike_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_wike:wap&$3
RewriteRule ^(.*)/'.$wike_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_wike:wap&pagetype=$2&cid=$3&uid=$4&$6
RewriteRule ^(.*)/'.$wike_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_wike:wap&pagetype=$2&cid=$3&$5
RewriteRule ^(.*)/'.$wike_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_wike:wap&pagetype=$2&$4</font>

</pre>

<h1>'.$it618_wike_lang['s452'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="wike_home"&gt;
			&lt;match url="^(.*/)*'.$wike_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_wike:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wike_wap"&gt;
			&lt;match url="^(.*/)*'.$wike_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_wike:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wike_wap3"&gt;
			&lt;match url="^(.*/)*'.$wike_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_wike:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;uid={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wike_wap2"&gt;
			&lt;match url="^(.*/)*'.$wike_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_wike:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wike_wap1"&gt;
			&lt;match url="^(.*/)*'.$wike_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_wike:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$wike_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_wike:index&$2
endif
match URL into $ with ^(.*)/'.$wike_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_wike:wap&$2
endif
match URL into $ with ^(.*)/'.$wike_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_wike:wap&pagetype=$2&cid=$3&uid=$4&$5
endif
match URL into $ with ^(.*)/'.$wike_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_wike:wap&pagetype=$2&cid=$3&$4
endif
match URL into $ with ^(.*)/'.$wike_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_wike:wap&pagetype=$2&$3
endif</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$wike_home.$urltype.'$ $1/plugin.php?id=it618_wike:index&$2 last;
rewrite ^([^\.]*)/'.$wike_wap.$urltype.'$ $1/plugin.php?id=it618_wike:wap&$2 last;
rewrite ^([^\.]*)/'.$wike_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_wike:wap&pagetype=$2&cid=$3&uid=$4&$5 last;
rewrite ^([^\.]*)/'.$wike_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_wike:wap&pagetype=$2&cid=$3&$4 last;
rewrite ^([^\.]*)/'.$wike_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_wike:wap&pagetype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=12)return;
showtablefooter();

?>