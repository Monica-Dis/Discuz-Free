<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';
$metakeywords = $it618_wike['seokeywords'];
$metadescription = $it618_wike['seodescription'];
$creditname=$_G['setting']['extcredits'][$it618_wike['wike_credit']]['title'];
$sitetitle=$it618_wike['seotitle'];
$navtitle=$sitetitle;

if(!wike_is_mobile()){
	$ispc=1;
}

$waphome=it618_wike_getrewrite('wike_wap','','plugin.php?id=it618_wike:wap');
$wapsearch=it618_wike_getrewrite('wike_wap','search','plugin.php?id=it618_wike:wap&pagetype=search');
$wapu=it618_wike_getrewrite('wike_wap','u','plugin.php?id=it618_wike:wap&pagetype=u');

$wike_forums = unserialize($it618_wike["wike_forums"]);
$forumcount=count($wike_forums);

if($forumcount==1){
	$posttmp='href="forum.php?mod=post&action=newthread&fid='.$wike_forums[0].'"';
}elseif($forumcount==0){
	$posttmp='href="javascript:" onclick="alert(\''.it618_wike_getlang('s330').'\')"';
}else{
	$posttmp='href="javascript:" onclick="showpost()"';
}

if($it618_wike['wike_ispostrz']==1){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
			
			$posttmp='href="javascript:" onclick="alert(\''.it618_wike_getlang('s575').'\');location.href=\'plugin.php?id=it618_members:home\'"';

		}
	}
}

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_wike#it618_wike_wapstyle')->count_by_isok_search();
$it618_wike_wapstyle=C::t('#it618_wike#it618_wike_wapstyle')->fetch_by_isok_search();

$il1i1l=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$il1i1l[]=substr($_GET['id'],$i,1);}
if(count($il1i1l)!=10)return;
if($il1i1l[6]!='w')return;
if(isset($_GET['pagetype'])){
	$pagetype=$_GET['pagetype'];
}else{
	$pagetype='wike';
}

if($_G['uid']>0){
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_wike_getlang('s374').'</a></li>';
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_wike_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_wike_bottomnav = DB::fetch($query)) {
	$it618_url=$it618_wike_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$tmpurl=it618_wike_getrewrite('wike_wap','','plugin.php?id=it618_wike:wap');
	$it618_url=str_replace("{waphome}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='wike'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapsearch}",$it618_url);
	$tmpurl=it618_wike_getrewrite('wike_wap','search','plugin.php?id=it618_wike:wap&pagetype=search');
	$it618_url=str_replace("{wapsearch}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='search'){
			$iscur=1;
		}
	}
	
	if($it618_url=='{wappost}'){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a '.$posttmp.' style="color:#666"><img src="'.$it618_wike_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_wike_bottomnav['it618_title'].'</a></td>';
		$n=$n+1;
		continue;
	}
	
	if($it618_wike_bottomnav['id']==5)$it618_url=it618_wike_getrewrite('wike_wap','u','plugin.php?id=it618_wike:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_wike_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_wike_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_wike_bottomnav['it618_color'].'">'.$it618_wike_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_wike_bottomnav['it618_img'];
		$it618_title=$it618_wike_bottomnav['it618_title'];
	}
	
	if($it618_wike_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_wike_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$wapbottomsubnav=C::t('#it618_wike#it618_wike_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_wike#it618_wike_set')->getsetvalue_by_setname('wapbottomsubnavdefault');

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/wap/'.$pagetype.'.inc.php';
?>