<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_wike/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_wike/rewrite.php',DISCUZ_ROOT.'./source/plugin/it618_wike/config/rewrite.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_wike/message.php',DISCUZ_ROOT.'./source/plugin/it618_wike/config/message.php');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_wike_grouppower` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_posttc` float(9,2) NOT NULL,
  `it618_gettc` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_wike_it618`;
CREATE TABLE IF NOT EXISTS `pre_it618_wike_it618` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_wike` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_wike_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_wike_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_wike_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(11) NOT NULL,
  `it618_msgisok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_wike_pf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_postuid` int(10) unsigned NOT NULL,
  `it618_getuid` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_gettime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_getwikemoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bmmoney` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_wike_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_sql` varchar(100) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_wike_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_wike_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_wike_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_wike_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);


$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_wike_main'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_mancount', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_mancount` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_bmmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_bmmoney` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_editcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_editcount` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_views', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_views` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_getwikemoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_getwikemoney` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_mode', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_mode` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_read', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_read` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_hfread', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_hfread` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_select', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_select` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_tc', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_tc` float(9,2) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_istj', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_istj` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_title', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_title` varchar(300) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_fid', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_fid` int(10) unsigned NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_typeid', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_typeid` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_jlbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_jlbl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_jl', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_jl` int(10) unsigned NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_uids', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_uids` varchar(800) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_crondate', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_main')." add `it618_crondate` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_wike'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_getwikemoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_getwikemoney` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('it618_bmmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_bmmoney` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('it618_state', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_state` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('it618_attachment', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_attachment` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_attachmentsize', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_attachmentsize` float(9,3) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_attachmenttime', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_attachmenttime` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('it618_postbz', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_postbz` varchar(8000) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_getbz', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_getbz` varchar(8000) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_postbztime', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_postbztime` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('it618_getbztime', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_getbztime` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('it618_ok', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_ok` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
	DB::query("update ".DB::table('it618_wike')." set it618_ok=1"); 
}

if(!in_array('it618_tc', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_tc` float(9,2) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_jlbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_jlbl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_jl', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_jl` int(10) unsigned NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_attachmentdown', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_attachmentdown` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_postbzread', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_postbzread` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}

if(!in_array('it618_getbzread', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike')." add `it618_getbzread` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_wike_user'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_bztel', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_user')." add `it618_bztel` varchar(11) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_qq', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_user')." add `it618_qq` varchar(20) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_wx', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_user')." add `it618_wx` varchar(80) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_bz', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_user')." add `it618_bz` varchar(800) NOT NULL;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_wike_grouppower'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_bmmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_grouppower')." add `it618_bmmoney` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_postjlbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_grouppower')." add `it618_postjlbl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_getjlbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_grouppower')." add `it618_getjlbl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

if(isset($_GET['pluginid'])&&$_GET['pluginid']!=''){
	$identifier=DB::result_first("SELECT identifier FROM ".DB::table('common_plugin')." WHERE pluginid=".intval($_GET['pluginid']));
}else{
	$identifier='it618_wike';
}
DB::query("insert into ".DB::table('it618_wike_it618')."(it618_wike) values ('".$identifier."')");

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_wike_bottomnav'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_curimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_wike_bottomnav')." add `it618_curimg` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzRhZDkwNmFjNGUxOTJmYzg4OWY1MTg0MzY0ZTE0ZDhlLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzhlZDE5N2IzY2U5MzkyOWQ0NGViOTQ1YjYxM2MwYWI3LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzI3YjM5NTcwNzRjZjk1NTBhOTQ0M2IxMTVkOGI4OWExLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzMzYjVjZTllOWY4MWUwZmFkZGEwNWYyNDUyMjAzZGM2LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzgxYjg3YWFkNzY5ZWRmMGM0MTA5MTNjMGRhNWRiZjQwLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzYwN2UxMGZmZDlhNWI4M2I1NmZjNGY3N2U1MmFmMzQ5LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzgzNWQ3Njg5ODVkODg0ODgwNDIwY2ZlNjUzOTg1NDdjLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlLzUyMzgxNzVlNzA2NDFkZDRjMjYzZTQ2ODM1MTI3Nzc4LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlL2I3ZmVkNDViMWJlMzliNWRjNzYxYmNjN2I0NTdkOWIyLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlL2UxZDU0NTRlNzc1YWVjNTM1ODU1MTBjZmNlNzgxODU2LnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvcXJjb2RlL2Y4NjJjNWFhZTY2NzhjODQxOGExYjAwOTYxYjc0YmQyLnBuZw=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvZGlzY3V6X3BsdWdpbl9pdDYxOF93aWtlX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvaW5zdGFsbC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3dpa2UvdXBncmFkZS5waHA='));
?>