<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_wike_pf extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_wike_pf';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_search($it618sql = '', $it618orderby = '', $it618_tid = 0, $it618_postuid = 0, $it618_getuid = 0, $it618_type = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_tid, $it618_postuid, $it618_getuid, $it618_type, $it618_time1, $it618_time2);
		return DB::result_first("SELECT count(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function sum_by_search($it618sql = '', $it618orderby = '', $it618_tid = 0, $it618_postuid = 0, $it618_getuid = 0, $it618_type = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_tid, $it618_postuid, $it618_getuid, $it618_type, $it618_time1, $it618_time2);
		$tmpsum = DB::result_first("SELECT sum(it618_getwikemoney) FROM %t $condition[0]", $condition[1]);
		if($tmpsum=='')$tmpsum=0;
		return $tmpsum;
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $it618_tid = 0, $it618_postuid = 0, $it618_getuid = 0, $it618_type = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_tid, $it618_postuid, $it618_getuid, $it618_type, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby = '', $it618_tid = 0, $it618_postuid = 0, $it618_getuid = 0, $it618_type = 0, $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_tid)) {
			$parameter[] = $it618_tid;
			$wherearr[] = 'it618_tid=%d';
		}
		if(!empty($it618_postuid)) {
			$parameter[] = $it618_postuid;
			$wherearr[] = 'it618_postuid=%d';
		}
		if(!empty($it618_getuid)) {
			$parameter[] = $it618_getuid;
			$wherearr[] = 'it618_getuid=%d';
		}
		if(!empty($it618_type)) {
			$parameter[] = $it618_type;
			$wherearr[] = 'it618_type=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 'it618_time>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 'it618_time<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}

?>