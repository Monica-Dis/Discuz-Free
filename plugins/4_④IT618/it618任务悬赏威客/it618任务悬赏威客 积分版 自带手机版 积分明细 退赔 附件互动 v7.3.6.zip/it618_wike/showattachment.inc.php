<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_wike/function.func.php';

if($_G['uid']<=0){
	if($_GET['wap']==1){
		echo 'alertit618_split'.$it618_wike_lang['s932'];exit;
	}else{
		showmessage($it618_wike_lang['s932'], '', array(), array('alert' => 'error'));exit;
	}
}else{
	$getwikeid=intval($_GET['getwikeid']);

	if($it618_wike_wike=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike')." WHERE id=".$getwikeid)){
		$tid=$it618_wike_wike['it618_tid'];
		
		if($it618_wike_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_wike_main')." WHERE it618_tid=".$tid)){
			$it618_attachmenttime=date('Y-m-d H:i:s', $it618_wike_wike['it618_attachmenttime']);
			$it618_postbztime=date('Y-m-d H:i:s', $it618_wike_wike['it618_postbztime']);
			$it618_getbztime=date('Y-m-d H:i:s', $it618_wike_wike['it618_getbztime']);
			
			$adminauthor=0;
			if($_G['uid']>0){
				$tmpwikeadmin=explode(",",$it618_wike['wike_wikeadmin']);
				for($tmpi=0;$tmpi<count($tmpwikeadmin);$tmpi++){
				   if($_G['uid']==$tmpwikeadmin[$tmpi]){
					   $adminauthor=1;
					   break;
				   }
				}
			}
			
			if($it618_wike_main['it618_uid']==$_G['uid']){
				$ispostwike=1;
				C::t('#it618_wike#it618_wike')->update($it618_wike_wike['id'],array(
					'it618_getbzread' => 1
				));
			}
			
			if($it618_wike_wike['it618_uid']==$_G['uid']){
				$isgetwike=1;
				C::t('#it618_wike#it618_wike')->update($it618_wike_wike['id'],array(
					'it618_postbzread' => 1
				));
			}
			
			if($ispostwike!=1&&$isgetwike!=1&&$adminauthor!=1){
				if($_GET['wap']==1){
					echo 'alertit618_split'.$it618_wike_lang['s933'];exit;
				}else{
					showmessage($it618_wike_lang['s933'], '', array(), array('alert' => 'error'));exit;
				}
			}
		}else{
			if($_GET['wap']==1){
				echo 'alertit618_split'.$it618_wike_lang['s2'];exit;
			}else{
				showmessage($it618_wike_lang['s2'], '', array(), array('alert' => 'error'));exit;
			}
		}
	}else{
		if($_GET['wap']==1){
			echo 'alertit618_split'.$it618_wike_lang['s2'];exit;
		}else{
			showmessage($it618_wike_lang['s2'], '', array(), array('alert' => 'error'));exit;
		}
	}
}

$height=$_GET['height']*0.8-30;

$_G['mobiletpl'][2]='/';

if($_GET['wap']!=1){
	include template('it618_wike:showattachment');
}else{
	include template('it618_wike:showwapattachment');
}
?>