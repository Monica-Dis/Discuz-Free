<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$out_trade_no=C::t('#it618_credits#it618_credits_salepay')->fetch_out_trade_no_by_uid($_G['uid']);
$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
dheader("location:$ajaxpay");
?>