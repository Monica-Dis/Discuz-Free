<?php
/**
 *	开发团队：IT618
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1012" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', 1);
require '../../../../source/class/class_core.php';

$DiscuzApp = C::app();
$DiscuzApp->init();

loadcache('plugin');

if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($_GET['out_trade_no'])){
	$it618_url=$it618_salepay['it618_url'];
	if($it618_salepay['it618_state']==1)dheader("location:$it618_url");
}else{
	exit;
}

$it618_plugin=$it618_salepay['it618_plugin'];

require DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php';

$alipay_config['seller_email'] = $seller_email;
$alipay_config['partner'] = $partner;
$alipay_config['key'] = $key;
$alipay_config['sign_type'] = strtoupper('MD5');
$alipay_config['input_charset'] = "utf-8";
$alipay_config['cacert'] = DISCUZ_ROOT.'./source/plugin/it618_credits/pay/cacert.pem';
$alipay_config['transport'] = 'http';

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay/lib/alipay_notify.class.php';

//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyReturn();
if($verify_result) {
    if($_GET['trade_status'] == 'TRADE_FINISHED'||$_GET['trade_status'] == 'TRADE_SUCCESS') {
		C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($_GET['trade_no'],$_GET['out_trade_no']);
		require_once DISCUZ_ROOT.'./source/plugin/'.$it618_plugin.'/ajaxpay.func.php';
		pay_success($_GET['out_trade_no']);
		dheader("location:$it618_url");
    }
}
?>