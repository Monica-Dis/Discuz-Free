<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_credits = $_G['cache']['plugin']['it618_credits'];
require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';

$buygroupid=intval($_GET['buygroupid']);
$saletype=intval($_GET['saletype']);

if(DB::result_first("select count(1) from ".DB::table('it618_credits_buygroup')." where it618_isok=1 and id=".$buygroupid)==0){
	$errorstr=$it618_credits_lang['s243'];
}else{
	$it618_credits_buygroup=C::t('#it618_credits#it618_credits_buygroup')->fetch_by_id($buygroupid);
	$groupid=$it618_credits_buygroup['it618_groupid'];
	if(DB::result_first("select count(1) from ".DB::table('common_usergroup')." where groupid=".$groupid)==0){
		$errorstr=$it618_credits_lang['s243'];
	}else{
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
		
		if($it618_credits_buygroup['it618_unit']==1){$it618_unit=$it618_credits_lang['s1021'];$it618_unit1=$it618_credits_lang['s1021'];}
		if($it618_credits_buygroup['it618_unit']==2){$it618_unit=$it618_credits_lang['s1022'];$it618_unit1=$it618_credits_lang['s1022'].$it618_credits_lang['s1852'];}
		if($it618_credits_buygroup['it618_unit']==3){$it618_unit=$it618_credits_lang['s1023'];$it618_unit1=$it618_credits_lang['s1023'].$it618_credits_lang['s1853'];}
		if($it618_credits_buygroup['it618_unit']==4){$it618_unit=$it618_credits_lang['s1619'];$it618_unit1=$it618_credits_lang['s1619'];}
		
		if($saletype==1){
			$saletypestr=$it618_credits_lang['s602'];
			$it618_credit='';$it618_credit1='';$tmpn=0;
			
			if($it618_credits_buygroup['it618_unit']==4){
				$it618_days3=1;
				$tmpcoutstr='<tr style="display:none"><td align="right"></td><td><input type="text" class="txt" id="it618_days" onkeyup="getit618_credit()" value="1"/></td></tr>';
			}else{
				$it618_days3=$it618_credits_buygroup['it618_days3'];
				$tmpcoutstr='<tr><td align="right">'.$it618_credits_lang['s613'].'</td><td><input type="text" class="txt" id="it618_days" style="width:60px;border:#e3e3e3 1px solid;padding-left:3px;height:26px" onkeyup="getit618_credit()" value="'.$it618_days3.'"/> '.$it618_unit.' <font color=#999 style="font-size:11px">'.$it618_credits_lang['s614'].''.$it618_credits_buygroup['it618_days1'].$it618_unit.$it618_credits_lang['s615'].''.$it618_credits_buygroup['it618_days2'].''.$it618_unit.'</font></td></tr>';
			}
			
			for($i=1;$i<=8;$i++){
				if($it618_credits_buygroup['it618_credit'.$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
					$tmpn=$tmpn+1;
					$it618_credit.='<font color="#FF6600"><span name="it618_buygroupcredit">'.$it618_credits_buygroup['it618_credit'.$i].'</span></font>'.$_G['setting']['extcredits'][$i]['title'].' + ';
					$it618_credit2.='<font color="#FF6600"><span name="it618_buygroupcredit2">'.($it618_credits_buygroup['it618_credit'.$i]*$it618_days3).'</span></font>'.$_G['setting']['extcredits'][$i]['title'].' + ';
					
					$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
					$it618_credit1.='<font color="#390">'.$creditnum.'</font>'.$_G['setting']['extcredits'][$i]['title'].' , ';
				}
			}
			if($it618_credit!=''){
				$it618_credit.='@';
				$it618_credit=str_replace(" + @","",$it618_credit);
				$it618_credit2.='@';
				$it618_credit2=str_replace(" + @","",$it618_credit2);
				$it618_credit1.='@';
				$it618_credit1=str_replace(" , @","",$it618_credit1);
			}
			
			if($tmpn>1)$it618_credit='('.$it618_credit.')';
			
			$tmpstr='
			<tr><td align="right" width="68">'.$it618_credits_lang['s611'].'</td><td>'.$it618_credit." / ".$it618_unit1.'</td>
			<tr><td align="right">'.$it618_credits_lang['s612'].'</td><td>'.$it618_credit1.'</td>
			'.$tmpcoutstr.'
            <tr><td align="right">'.$it618_credits_lang['s616'].'</td><td>'.$it618_credit2.'</td></tr>
			';
			
			$btnstr='group_saleadd('.$it618_credits_buygroup['id'].')';
			
		}else{
			if($it618_credits_buygroup['it618_unit']==4){
				$it618_days3=1;
				$tmpcoutstr='<tr style="display:none"><td align="right"></td><td><input type="text" class="txt" id="it618_days" onkeyup="getit618_credit()" value="1"/></td></tr>';
			}else{
				$it618_days3=$it618_credits_buygroup['it618_days3'];
				$tmpcoutstr='<tr><td align="right">'.$it618_credits_lang['s613'].'</td><td style="line-height:15px"><input type="text" class="txt" id="it618_days" style="width:60px;border:#e3e3e3 1px solid;padding-left:3px;height:26px" onkeyup="getit618_price()" value="'.$it618_days3.'"/> '.$it618_unit.$strbr.'<font color=#999>'.$it618_credits_lang['s614'].''.$it618_credits_buygroup['it618_days1'].$it618_unit.$it618_credits_lang['s615'].''.$it618_credits_buygroup['it618_days2'].''.$it618_unit.'</font></td></tr>';
			}
			
			$saletypestr=$it618_credits_lang['s603'];
			$tmpstr='
			<tr><td align="right" width="68">'.$it618_credits_lang['s611'].'</td><td><font color="#FF6600"><span id="it618_buygroupprice">'.$it618_credits_buygroup['it618_price'].'</span></font> '.$it618_credits_lang['s28']." / ".$it618_unit1.'</td>
			'.$tmpcoutstr.'
            <tr><td align="right">'.$it618_credits_lang['s617'].'</td><td><font color="#FF6600"><b><span id="it618_buygroupprice2">'.($it618_credits_buygroup['it618_price']*$it618_days3).'</span></b></font> '.$it618_credits_lang['s28'].'</td></tr>
			';
			
			$it618paystr=it618_credits_pay('group',$it618_credits_lang['t221']);
			
			$btnstr='group_payadd('.$it618_credits_buygroup['id'].')';
		}
		
	}
}
if($errorstr!='')$errorstr='errit618_split'.$errorstr.'it618_split';

$_G['mobiletpl'][2]='/';
include template('it618_credits:buygroup');
?>