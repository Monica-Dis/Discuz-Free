<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits_default.func.php';

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php';
}

if($_GET['type']=='money'){
	if(credits_is_mobile()){ 
		$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:wap&dotype=moneysum";
		dheader("location:$tmpurl");
	}
	
	if($it618_credits_money=C::t('#it618_credits#it618_credits_moneycztmp')->fetch_by_id($_GET['saleid'])) {
	
		$bzstr='';
		if($it618_credits_money['it618_bz']!=''){
			$bzstr='<a href="javascript:" onclick="alert(\''.$it618_credits_money['it618_bz'].'\')">'.$it618_credits_lang['s191'].'</a>';
		}
		
		$paystr=getpaystr($it618_credits_money['it618_paytype'],$it618_credits_money['it618_payid']);
		
		$zsjfstr='';
		if($it618_credits_money['it618_zsjfcount']>0){
			$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_money['it618_zsjfcount'].'</font><font color=green>'.$_G['setting']['extcredits'][$it618_credits_money['it618_zsjfid']]['title'].'</font> ';
		}
		
		$tmpstr=$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font>'.$it618_credits_lang['s198'].' '.$zsjfstr.' '.$bzstr.' '.$paystr;
		
		$tmpstr= '<table><tr><td><img src="source/plugin/it618_credits/images/se.gif"> '.$it618_credits_lang['s242'].'</td></tr><tr>
			  <td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_money['it618_time']).'</font> '.$tmpstr.'</td>
			  </tr></table>';

	}else{
		$tmpstr= $it618_credits_lang['s243'];
	}
}

if($_GET['type']=='sale'){
	if(credits_is_mobile()){ 
		$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:wap&dotype=buygroup";
		dheader("location:$tmpurl");
	}
	
	if($it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($_GET['saleid'])) {
	
		$bzstr='';
		if($it618_credits_sale['it618_bz']!=''){
			$bzstr='<a href="javascript:" onclick="alert(\''.$it618_credits_sale['it618_bz'].'\')">'.$it618_credits_lang['s191'].'</a>';
		}
		
		if($it618_credits_sale['it618_saletype']=='recharge'){
			if($it618_credits_sale['it618_uid1']==$it618_credits_sale['it618_uid2']){
				$whostr=$it618_credits_lang['s192'];
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
				$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$username.'('.$it618_credits_sale['it618_uid2'].')</a>';
			}
			
			$credittitle=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
	
			if($it618_credits_sale['it618_paytype']!='quan'){
	
				$tmphl='1 '.$credittitle.' = '.$it618_credits_sale['it618_bl'].' '.$it618_credits_lang['s28'];
				
				$paystr=getpaystr($it618_credits_sale['it618_paytype'],$it618_credits_sale['it618_payid']);
				
				$tmpstr=$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green title="'.$tmphl.'">'.$credittitle.'</font> '.$it618_credits_lang['s197'].'<font color=red>'.$it618_credits_sale['it618_money'].'</font>'.$it618_credits_lang['s198'].' '.$it618_credits_lang['s1253'].'<font color=red>'.$it618_credits_sale['it618_zk'].'</font>% '.$bzstr.' '.$paystr;
	
			}
		}
		
		$tmpstr= '<table><tr><td><img src="source/plugin/it618_credits/images/se.gif"> '.$it618_credits_lang['s242'].'</td></tr><tr>
			  <td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_sale['it618_time']).'</font> '.$tmpstr.'</td>
			  </tr></table>';

	}else{
		$tmpstr= $it618_credits_lang['s243'];
	}
}

if($_GET['type']=='group'){
	if(credits_is_mobile()){ 
		$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:wap&dotype=moneysum";
		dheader("location:$tmpurl");
	}
	
	if($it618_credits_buygroup_sale=C::t('#it618_credits#it618_credits_buygroup_sale')->fetch_by_id($_GET['saleid'])) {
	
		$bzstr='';
		if($it618_credits_sale['it618_bz']!=''){
			$bzstr='<a href="javascript:" onclick="alert(\''.$it618_credits_sale['it618_bz'].'\')">'.$it618_credits_lang['s191'].'</a>';
		}
		
		$it618_credit='<font color="#FF6600"><b>'.$it618_credits_buygroup_sale['it618_price'].'</b></font> '.$it618_credits_lang['s28'];
	
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_credits_buygroup_sale['it618_groupid']);
		
		if($it618_credits_buygroup_sale['it618_paytype']!='')$paystr=getpaystr($it618_credits_buygroup_sale['it618_paytype'],$it618_credits_buygroup_sale['it618_payid']);
		
		$tmpstr= '
		<style>table tr th,table tr td{font-size:12px; text-align:left}</style>
		<table><tr><td colspan=4 style="font-size:15px"><img src="source/plugin/it618_credits/images/se.gif"> '.$it618_credits_lang['s242'].' '.$paystr.'</td></tr><tr>
				<tr><th width=150>'.$it618_credits_lang['t205'].'</th><th width=60>'.$it618_credits_lang['t214'].'</th><th width=60>'.$it618_credits_lang['t215'].'</th><th width=150>'.$it618_credits_lang['t216'].'</th></tr>
				<tr>
				<td><font color=green>'.$grouptitle.'</font></td>
				<td>'.$it618_credit.'</td>
				<td><font color=red>'.$it618_credits_buygroup_sale['it618_days'].'</font></td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_buygroup_sale['it618_time']).'</font></td>
				</tr>
			  </table>';
	}else{
		$tmpstr= $it618_credits_lang['s243'];
	}

}

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml"  xml:lang="zh-CN" lang="zh-CN">
<head>
<title>'.$it618_credits_lang['s244'].'</title>
<meta http-equiv="Content-Type" content="text/html; charset={CHARSET}" />

</head>
<body>
'.$tmpstr.'
<a href="javascript:window.opener=null;window.open(\'\',\'_self\');window.close();">'.$it618_credits_lang['s1227'].'</a>
</body>
</html>
';

?>