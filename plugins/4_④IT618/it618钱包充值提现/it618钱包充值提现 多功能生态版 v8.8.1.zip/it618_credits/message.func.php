<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function sendSMS($uid,$pwd,$mobile,$content){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	
	$smsapi='http://www.smsbao.com/';
	$pwd = md5($pwd);
	
	$sendurl = $smsapi."sms?u=".$uid."&p=".$pwd."&m=".$mobile."&c=".urlencode(it618_credits_gbktoutf($content));
	$result =dfsockopen($sendurl);

	return $result;
}

function sendSMS_ALi($it618_tel,$members_bz,$members_sign,$members_tplid,$members_param,$it618_jktype){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
	
	return sendSMS_ALIAPI('it618_credits',$it618_tel,$members_bz,$members_sign,$members_tplid,$members_param,$it618_jktype);
}

function sendSMS_WX($uid,$url,$members_tplid,$members_param){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
	
	return sendSMS_WXAPI('it618_credits',$uid,$url,$members_tplid,$members_param);
}

function debugSMS($content){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/debug.txt',"a");
	fwrite($fp,$content);
	fclose($fp);
}
?>