<?php
/**
 *	开发团队：IT618
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1012" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', 1);
require '../../../../source/class/class_core.php';

$DiscuzApp = C::app();
$DiscuzApp->init();

loadcache('plugin');

if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($_POST['out_trade_no'])){
	if($it618_salepay['it618_state']==1)exit;
}else{
	exit;	
}

$it618_paytype=$it618_salepay['it618_paytype'];
$it618_plugin=$it618_salepay['it618_plugin'];

require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';

$tmparr=explode("wx",$it618_paytype);
if(count($tmparr)>1){
	$key=$payjs_key;
}else{
	$key=$payjs_alikey;
}

$user_sign = $_POST['sign'];
unset($_POST['sign']);

ksort($_POST);
$check_sign = strtoupper(md5(urldecode(http_build_query($_POST).'&key='.$key)));

if ($user_sign == $check_sign) {
	require_once DISCUZ_ROOT.'./source/plugin/'.$it618_plugin.'/ajaxpay.func.php';
	
	echo pay_success($_POST['out_trade_no']);
}
?>