<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_credits_uset extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_credits_uset';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d", array($this->_table,$uid));
	}
	
	public function count_by_uid_isqfuser($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d and it618_isqfuser=1", array($this->_table,$uid));
	}
	
	public function countbank_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE (it618_alipayname!='' or it618_wxname!='' or it618_bankname!='') and it618_uid=%d", array($this->_table,$uid));
	}
	
	public function fetch_tel_by_uid($uid) {
		return DB::result_first("SELECT it618_tel FROM %t WHERE it618_uid=%d", array($this->_table,$uid));
	}
	
	public function fetch_money_by_uid($uid) {
		return DB::result_first("SELECT it618_money FROM %t WHERE it618_uid=%d", array($this->_table,$uid));
	}
	
	public function fetch_by_uid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_search($it618sql = '', $it618orderby = '', $it618_uid = 0, $it618_money1 = '', $it618_money2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_uid, $it618_money1, $it618_money2);
		return DB::result_first("SELECT count(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function sum_by_search($it618sql = '', $it618orderby = '', $it618_uid = 0, $it618_money1 = '', $it618_money2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_uid, $it618_money1, $it618_money2);
		return DB::result_first("SELECT sum(it618_money) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $it618key = '', $it618_uid = 0, $it618_money1 = '', $it618_money2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618key, $it618_uid, $it618_money1, $it618_money2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby = '', $it618key = '', $it618_uid = 0, $it618_money1 = '', $it618_money2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618key)) {
			$parameter[] = '%'.$it618key.'%';
			$parameter[] = '%'.$it618key.'%';
			$parameter[] = '%'.$it618key.'%';
			$parameter[] = '%'.$it618key.'%';
			$parameter[] = '%'.$it618key.'%';
			$parameter[] = '%'.$it618key.'%';
			$wherearr[] = "(it618_tel LIKE %s or it618_name LIKE %s or it618_skname LIKE %s or it618_bankname LIKE %s or it618_alipayname LIKE %s or it618_wxname LIKE %s)";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($it618_money1)) {
			$parameter[] = $it618_money1;
			$wherearr[] = 'it618_money>=%f';
		}
		if(!empty($it618_money2)) {
			$parameter[] = $it618_money2;
			$wherearr[] = 'it618_money<=%f';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
}

?>