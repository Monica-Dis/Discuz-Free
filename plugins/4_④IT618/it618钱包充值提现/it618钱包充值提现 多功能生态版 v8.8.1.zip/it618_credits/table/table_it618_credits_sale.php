<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_credits_sale extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_credits_sale';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_tq_by_uid_last($uid) {
		return DB::result_first("SELECT it618_bank FROM %t WHERE it618_uid1=%d and it618_saletype='tq' order by id desc", array($this->_table, $uid));
	}
	
	public function fetch_by_u_utype($u,$utype) {
		if($utype==1){
			return DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE uid=%d", array($u));
		}else{
			return DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE username=%s", array($u));
		}
	}
	
	public function count_by_search($it618sql = '', $it618orderby = '', $it618_uid = 0, $it618_saletype = '', $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_uid, $it618_saletype, $it618_time1, $it618_time2);
		return DB::result_first("SELECT count(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $it618_uid = 0, $it618_saletype = '', $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_uid, $it618_saletype, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby = '', $it618_uid = 0, $it618_saletype = '', $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$parameter[] = $it618_uid;
			$wherearr[] = '(it618_uid1=%d or it618_uid2=%d)';
		}
		if(!empty($it618_saletype)) {
			$parameter[] = $it618_saletype;
			$wherearr[] = 'it618_saletype=%s';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 'it618_time>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 'it618_time<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function update_it618_paycode($id,$it618_paycode) {
		DB::query("UPDATE %t SET it618_paycode=%s WHERE id=%d", array($this->_table, $it618_paycode, $id));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}

?>