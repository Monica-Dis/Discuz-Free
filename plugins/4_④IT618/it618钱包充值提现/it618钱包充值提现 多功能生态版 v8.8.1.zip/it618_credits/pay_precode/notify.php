<?php
/**
 *	开发团队：IT618
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1012" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', 1);
require '../../../../source/class/class_core.php';

$DiscuzApp = C::app();
$DiscuzApp->init();

loadcache('plugin');

$out_trade_no = $_GET['payId'];

if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
	if($it618_salepay['it618_state']==1)exit;
}else{
	exit;	
}

$it618_plugin=$it618_salepay['it618_plugin'];

require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php';

$param = $_GET['param'];
$type = $_GET['type'];
$price = $_GET['price'];
$reallyPrice = $_GET['reallyPrice'];
$user_sign = $_GET['sign'];

$check_sign =  md5($precode_mchid . $out_trade_no . $param . $type . $price . $reallyPrice . $precode_key);

if ($user_sign == $check_sign) {
	require_once DISCUZ_ROOT.'./source/plugin/'.$it618_plugin.'/ajaxpay.func.php';
	
	echo pay_success($out_trade_no);
}
?>