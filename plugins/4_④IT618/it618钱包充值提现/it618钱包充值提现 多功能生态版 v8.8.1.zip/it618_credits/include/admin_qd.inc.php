<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$sqlurl='&finduid='.$_GET['finduid'];
$sql='1';
if($_GET['finduid']!=''){
	$sql='it618_uid='.intval($_GET['finduid']);
}

if(count($reabc)!=13)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_qd&pmod=admin_qd&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s491'],'it618_credits_qd');
	showsubmit('it618sercsubmit', $it618_credits_lang['s103'], $it618_credits_lang['s104'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />');
	
	$count = DB::result_first("select count(1) from ".DB::table('it618_credits_qd')." WHERE $sql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_qd&pmod=admin_qd&operation=$operation&do=$do".$sqlurl);
	
	echo '<tr><td colspan=14>'.$it618_credits_lang['s499'].$count.'<span style="float:right;color:red"></span></td></tr>';
	showsubtitle(array($it618_credits_lang['s496'],$it618_credits_lang['s497'],$it618_credits_lang['s498']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_credits_qd')." WHERE $sql order by id desc LIMIT $startlimit, $ppp");
	while($it618_credits_qd = DB::fetch($query)) {
		
		$it618_credit='';
		for($i=1;$i<=8;$i++){
			if($it618_credits_qd['it618_credit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
				$it618_credit.='<font color=red>'.$it618_credits_qd['it618_credit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' ';
			}
		}
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_qd['it618_uid']);
		
		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			$it618_credit,
			'<a href="home.php?mod=space&uid='.$it618_credits_qd['it618_uid'].'" target="_blank">'.$username.'('.$it618_credits_qd['it618_uid'].')</a>',
			date('Y-m-d H:i:s', $it618_credits_qd['it618_time'])
		));
	}


	echo '<tr><td colspan=14><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter();
?>