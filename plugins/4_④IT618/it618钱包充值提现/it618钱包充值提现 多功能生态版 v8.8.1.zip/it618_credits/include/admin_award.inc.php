<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='e')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_credits#it618_credits_award')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_credits#it618_credits_award')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_gailv' => trim($_GET['it618_gailv'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			
			for($i=1;$i<=8;$i++){
				if($_G['setting']['extcredits'][$i]['title']!=''){
					C::t('#it618_credits#it618_credits_award')->update($id,array(
						'it618_credit'.$i => intval($_GET['it618_credit'.$i][$id]),
					));
				}
			}
			
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_gailv_array = !empty($_GET['newit618_gailv']) ? $_GET['newit618_gailv'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = trim($newit618_name_array[$key]);
		
		if($newit618_name != '') {
			
			C::t('#it618_credits#it618_credits_award')->insert(array(
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_gailv' => trim($newit618_gailv_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_credits_lang['s7'].$ok1.' '.$it618_credits_lang['s8'].$ok2.' '.$it618_credits_lang['s9'].$del, "action=plugins&identifier=$identifier&cp=admin_award&pmod=admin_award&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=13)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_award&pmod=admin_award&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s447'],'it618_credits_award');
	$count = C::t('#it618_credits#it618_credits_award')->count_by_search();
	$sum = C::t('#it618_credits#it618_credits_award')->sum_by_order();
	
	echo '<tr><td colspan=6 style="font-size:15px;line-height:20px">'.$it618_credits_lang['s519'].'</td></tr>';
	echo '<tr><td colspan=6>'.$it618_credits_lang['s449'].$count.'<span style="float:right;color:red">'.$it618_credits_lang['s454'].'</span></td></tr>';
	showsubtitle(array('', $it618_credits_lang['s450'], $it618_credits_lang['s451'],$it618_credits_lang['s452'],$it618_credits_lang['s453']));
	
	foreach(C::t('#it618_credits#it618_credits_award')->fetch_all_by_search() as $it618_credits_award) {	
		
		$it618_credit='';
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$it618_credit.=$_G['setting']['extcredits'][$i]['title'].'= <input type="text" class="txt" style="width:40px;color:blue" name="it618_credit'.$i.'['.$it618_credits_award['id'].']" value="'.$it618_credits_award['it618_credit'.$i].'">';
			}
		}
		
		if($it618_credits_award['it618_order']>0){
			$gailv='<font color=green><b>'.round(($it618_credits_award['it618_gailv']/$sum*100),3).'%</b></font>';	
		}else{
			$gailv='';	
		}
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_credits_award['id']."\" $disabled><input type=\"hidden\" name=\"id[".$it618_credits_award['id']."]\" value=\"".$it618_credits_award['id']."\">",
			'<input class="txt" type="text" style="width:100px" name="it618_name['.$it618_credits_award['id'].']" value="'.$it618_credits_award['it618_name'].'">',
			$it618_credit,
			'<input class="txt" type="text" style="width:50px;color:red" name="it618_gailv['.$it618_credits_award['id'].']" value="'.$it618_credits_award['it618_gailv'].'">'.$gailv,
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_credits_award['id'].']" value="'.$it618_credits_award['it618_order'].'">',
		));
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$it618_credits_lang184=$it618_credits_lang['s455'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_name[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:100px\" name="newit618_name[]">'], [1,'$it618_credits_lang184'], [1, ' <input class="txt" type="text" style="width:50px;color:red" name="newit618_gailv[]" value="1">'], [1, ' <input class="txt" type="text" style="width:30px" name="newit618_order[]" value="0">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=13)return;
showtablefooter();
?>