<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if(submitcheck('it618submit')){

	foreach($_GET['id'] as $id => $val) {
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				C::t('#it618_credits#it618_credits_groupzk')->update($id,array(
					'it618_zk'.$i => floatval($_GET['it618_zk'.$i][$id]),
					'it618_max'.$i => intval($_GET['it618_max'.$i][$id])
				));
			}
		}
	}

	cpmsg($it618_credits_lang['s25'], "action=plugins&identifier=$identifier&cp=admin_groupzk&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

if(count($reabc)!=13)return;
if(submitcheck('it618daosubmit')) {
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_groupzk')." WHERE it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_credits#it618_credits_groupzk')->insert(array(
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}
}

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_groupzk'))==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_groupzk')." WHERE it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_credits#it618_credits_groupzk')->insert(array(
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}	
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_groupzk&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1");

showtableheaders($strtmptitle[$cp1],'it618_credits_groupzk');
	showsubmit('it618daosubmit', $it618_credits_lang['s125']);
	if($reabc[5]!='_')return;
	
	$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_groupzk'));
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_groupzk&pmod=admin_set&operation=$operation&do=$do&page=$page".$sql);
	
	echo '<tr><td colspan=15>'.$it618_credits_lang['s126'].$count.'<span style="float:right">'.$it618_credits_lang['s127'].'</span></td></tr>';
	
	for($i=1;$i<=8;$i++){
		$jfname[$i]=$_G['setting']['extcredits'][$i]['title'];
		if($jfname[$i]!='')$jfname[$i].=$it618_credits_lang['s1218'];
	}

	showsubtitle(array($it618_credits_lang['s128'],$jfname[1],$jfname[2],$jfname[3],$jfname[4],$jfname[5],$jfname[6],$jfname[7],$jfname[8]));

	$query = DB::query("SELECT p.*,g.groupid,g.grouptitle FROM ".DB::table('it618_credits_groupzk')." p,".DB::table('common_usergroup')." g WHERE p.it618_groupid=g.groupid LIMIT $startlimit, $ppp");
	while($it618_credits_groupzk =	DB::fetch($query)) {
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$tmpzk=$it618_credits_groupzk['it618_zk'.$i];
				$tmpmax=$it618_credits_groupzk['it618_max'.$i];
				$jfstr[$i]='<input type="text" class="txt" style="width:68px;margin-right:3px;margin-bottom:3px;background-color:#FFE" name="it618_zk'.$i.'['.$it618_credits_groupzk['id'].']" value="'.$tmpzk.'">%<br><input type="text" class="txt" style="width:68px;margin-right:3px;" name="it618_max'.$i.'['.$it618_credits_groupzk['id'].']" value="'.$tmpmax.'">';
			}else{
				$jfstr[$i]='';
			}
		}
		
		if($reabc[1]!='t')return;
		showtablerow('', array('class="td28"', '', ''), array(
			$it618_credits_groupzk['grouptitle']."<input type=\"hidden\" name=\"id[".$it618_credits_groupzk['id']."]\" value=\"".$it618_credits_groupzk['id']."\">",
			$jfstr[1],$jfstr[2],$jfstr[3],$jfstr[4],$jfstr[5],$jfstr[6],$jfstr[7],$jfstr[8],
		));
	}
	
	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type="submit" class="btn" name="it618submit" value="'.$it618_credits_lang['s130'].'"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	showtablefooter();
?>