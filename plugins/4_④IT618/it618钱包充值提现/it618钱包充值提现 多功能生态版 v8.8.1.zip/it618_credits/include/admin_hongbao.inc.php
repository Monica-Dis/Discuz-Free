<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$sqlurl='&finduid='.$_GET['finduid'].'&findtid='.$_GET['findtid'];
$sql='1';
if($_GET['finduid']!=''){
	$sql.=' and it618_uid='.intval($_GET['finduid']);
}
if($_GET['findtid']!=''){
	$sql.=' and it618_tid='.intval($_GET['findtid']);
}

if(count($reabc)!=13)return;

if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_hongbao'")==0){
	dheader("location:".ADMINSCRIPT."?action=plugins&cp=admin_hongbao_set".'&pmod=admin_hongbao&identifier='.$identifier.'&operation='.$operation.'&do='.$do);
	exit;
}

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		C::t('#it618_hongbao#it618_hongbao_main')->update($delid,array(
			'it618_islock' => 1
		));
		
		$it618_hongbao_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_main')." where id=$delid");
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=$delid");
		while($it618_hongbao_tmp = DB::fetch($query)) {
			$tmp[]=$it618_hongbao_tmp;
		}
		
		$count=$it618_hongbao_main['it618_count'];
		$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$count1=$count-$count2;
		
		$money=$it618_hongbao_main['it618_money'];
		$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$money1=$it618_hongbao_main['it618_money']-$moneytmp;
		
		if($it618_hongbao_main['it618_jfid']>0){
			C::t('common_member_count')->increase($it618_hongbao_main['it618_uid'], array(
				'extcredits'.$it618_hongbao_main['it618_jfid'] => $money1)
			);
		}else{
			if($money1>0){
				$it618_bz=$it618_credits_lang['s1552'];
				$it618_bz=str_replace("{money}",$money1,$it618_bz);
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
				savemoney(array(
					'it618_uid' => $it618_hongbao_main['it618_uid'],
					'it618_type' => 'zy',
					'it618_money1' => $money1,
					'it618_bz' => $it618_bz,
					'it618_zytype' => 'it618_hongbao_tk',
					'it618_zyid' => $it618_hongbao_main["id"],
					'it618_time' => $_G['timestamp']
				));
			}
		}
		
		DB::delete('it618_hongbao_item', "it618_mid=$delid");
		DB::delete('it618_hongbao_main', "id=$delid");
		
		$it618_postcount=DB::result_first("select count(1) from ".DB::table('it618_hongbao_main')." where it618_uid=".$it618_hongbao_main['it618_uid']);
		if($it618_hongbao_ph=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_ph')." WHERE it618_uid=".$it618_hongbao_main['it618_uid'])){
			C::t('#it618_hongbao#it618_hongbao_ph')->update($it618_hongbao_ph["id"],array(
				'it618_postcount' => $it618_postcount
			));
		}
		
		foreach($tmp as $it618_hongbao_item) {
			$it618_getcount=DB::result_first("select count(1) from ".DB::table('it618_hongbao_item')." where it618_uid=".$it618_hongbao_item['it618_uid']);
		
			if($it618_hongbao_ph=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_ph')." WHERE it618_uid=".$it618_hongbao_item['it618_uid'])){
				C::t('#it618_hongbao#it618_hongbao_ph')->update($it618_hongbao_ph["id"],array(
					'it618_getcount' => $it618_getcount
				));
			}
		}

		$del=$del+1;
	}

	cpmsg($it618_credits_lang['s1217'].$del, "action=plugins&identifier=$identifier&cp=admin_hongbao&pmod=admin_hongbao&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_hongbao&pmod=admin_hongbao&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_credits_lang['s550'],'it618_hongbao_main');
	showsubmit('it618sercsubmit', $it618_credits_lang['s103'], $it618_credits_lang['s104'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:80px" />'.$it618_credits_lang['s546'].' <input name="findtid" value="'.$_GET['findtid'].'" class="txt" style="width:80px" />');
	
	$count = 0;
	$query = DB::query("SELECT it618_type,it618_tid FROM ".DB::table('it618_hongbao_main')." WHERE $sql group by it618_type,it618_tid");
	while($it618_hongbao_maintmp = DB::fetch($query)) {
		$count=$count+1;
	}
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_hongbao&pmod=admin_hongbao&operation=$operation&do=$do".$sqlurl);
	
	$count1 = DB::result_first("select count(1) from ".DB::table('it618_hongbao_item')." WHERE $sql");
	
	echo '<tr><td colspan=14>'.$it618_credits_lang['s551'].'<font color=red>'.$count.'</font> '.$it618_credits_lang['s560'].'<font color=red>'.$count1.'</font><span style="float:right;color:red">'.$it618_credits_lang['s359'].'</span></td></tr>';
	showsubtitle(array($it618_credits_lang['s546'],$it618_credits_lang['s544'],$it618_credits_lang['s545'],$it618_credits_lang['s554'],$it618_credits_lang['s547'],$it618_credits_lang['s548'],$it618_credits_lang['s549']));
	
	$query = DB::query("SELECT it618_type,it618_tid FROM ".DB::table('it618_hongbao_main')." WHERE $sql group by it618_type,it618_tid order by id desc LIMIT $startlimit, $ppp");
	while($it618_hongbao_maintmp = DB::fetch($query)) {
		$it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hongbao_maintmp['it618_type'],$it618_hongbao_maintmp['it618_tid']);
		
		$namestr=it618_credits_gethbname($it618_hongbao_main);
		
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_main['it618_uid']);
			
		$hbindex=DB::result_first("select count(1) from ".DB::table('it618_hongbao_main')." where it618_type='".$it618_hongbao_main['it618_type']."' and it618_tid=".$it618_hongbao_main['it618_tid']." and id<=".$it618_hongbao_main['id']);
		
		if($it618_hongbao_main['it618_isrand']==1)$tmpname=$it618_credits_lang['s552'];else $tmpname=$it618_credits_lang['s16'];
		if($it618_hongbao_main['it618_code']!='')$tmpname.=$it618_credits_lang['s529'];
		
		$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$count1=$it618_hongbao_main['it618_count']-$count2;
		
		$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$money=$it618_hongbao_main['it618_money']-$moneytmp;
		
		if($it618_hongbao_main['it618_jfid']>0){
			$money1=str_replace(".00","",$money1);
			$moneytmp=str_replace(".00","",$moneytmp);
			$money=str_replace(".00","",$money);
			$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
		}else{
			$moneyname=$it618_credits_lang['s198'];
		}
		
		$tmpbm='';
		if($it618_hongbao_main['it618_code']!=''){
			if($it618_hongbao_main['it618_codetype']==1)$tmpbm=' <font color=red>'.$it618_credits_lang['s555'].'</font>';
			if($it618_hongbao_main['it618_codetype']==2)$tmpbm=' <font color=red>'.$it618_credits_lang['s1010'].'</font>';
		}
		
		if($it618_hongbao_main['it618_state']==1){
			$it618_state=$it618_credits_lang['s1213'].':<font color=red>'.$count1.'</font>'.$it618_credits_lang['s1214'].' '.$money.$moneyname.' '.$it618_credits_lang['s1215'].':'.'<font color=#390>'.$count2.'</font>'.$it618_credits_lang['s1214'];
		}else{
			$it618_state=$it618_credits_lang['s1216'].':'.$count2.''.$it618_credits_lang['s1214'].' '.$moneytmp.$moneyname;
		}
		
		showtablerow('', array('', '', ''), array(
			"<div style=\"width:80px\"><input class=\"checkbox\" type=\"checkbox\" id=\"id".$it618_hongbao_main['id']."\" name=\"delete[]\" value=\"".$it618_hongbao_main['id']."\" $disabled><label for=\"id".$it618_hongbao_main['id']."\">".$it618_hongbao_main['it618_tid']."</label></div>",
			$namestr,
			$tmpname,
			$it618_hongbao_main['it618_code'].$tmpbm,
			'['.$it618_credits_lang['s1211'].$hbindex.$it618_credits_lang['s1212'].'] '.$it618_state,
			'<a href="home.php?mod=space&uid='.$it618_hongbao_main['it618_uid'].'" target="_blank">'.$username.'('.$it618_hongbao_main['it618_uid'].')</a>',
			date('Y-m-d H:i:s', $it618_hongbao_main['it618_time'])
		));
	}

	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type="submit" class="btn" name="it618submit_del" value="'.$it618_credits_lang['s357'].'" onclick="return confirm(\''.$it618_credits_lang['s358'].'\')"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter();
?>