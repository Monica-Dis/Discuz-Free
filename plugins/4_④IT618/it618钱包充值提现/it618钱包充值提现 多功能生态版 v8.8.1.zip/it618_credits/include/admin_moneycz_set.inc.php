<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php';
}

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$money_count=\''.floatval($_GET['money_count'])."';\n";
		$fileData .= '$money_zsbl=\''.floatval($_GET['money_zsbl'])."';\n";
		$fileData .= '$money_zsjfid=\''.intval($_GET['money_zsjfid'])."';\n";
		$fileData .= '$money_counts=\''.trim($_GET['money_counts'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	cpmsg($it618_credits_lang['s456'], "action=plugins&identifier=$identifier&cp=admin_moneycz_set&pmod=admin_money&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_moneycz_set&pmod=admin_money&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s902'],'it618_credits_set');

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$tmp.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
}
if($qf_isgold==1){
	$tmp.='<option value="11">'.$qf_goldname.'</option>';
}

$tmp1=str_replace('<option value="'.$money_zsjfid.'">','<option value="'.$money_zsjfid.'" selected="selected">',$tmp);

echo '
<tr><td width="150">'.$it618_credits_lang['s1027'].'</td><td style="line-height:28px">'.$it618_credits_lang['s27'].'<input class="txt" type="text" style="width:50px;color:green;font-weight:bold" name="money_count" value="'.$money_count.'">'.$it618_credits_lang['s28'].' ('.$it618_credits_lang['s1047'].'*<input class="txt" type="text" style="width:50px;color:red;font-weight:bold;margin-right:3px" name="money_zsbl" value="'.$money_zsbl.'">% '.$it618_credits_lang['s636'].' <select name="money_zsjfid">'.$tmp1.'</select> <font color=#999>'.$it618_credits_lang['s638'].'</font>)<br>'.$it618_credits_lang['s697'].'<input class="txt" type="text" style="width:322px;" name="money_counts" value="'.$money_counts.'"><font color=#999>'.$it618_credits_lang['s698'].'</font></td></tr>
<tr><td>'.$it618_credits_lang['s1028'].'</td><td><a href="'.ADMINSCRIPT.'?action=plugins&cp=admin_groupzk&cp1=5&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'">'.$it618_credits_lang['s1029'].'</a></td></tr>
<tr><td>'.$it618_credits_lang['s1030'].'</td><td>'.$it618_credits_lang['s1031'].'</td></tr>
';

showsubmit('it618submit', $it618_credits_lang['s29']);

$tmpurl=$_G['siteurl'].it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
$it618_credits_lang['s1346']=str_replace("{url}",$tmpurl,$it618_credits_lang['s1346']);

echo '<table><tr><td>'.$it618_credits_lang['s1346'].'</td></tr></table>';

if(count($reabc)!=13)return;
showtablefooter();

?>