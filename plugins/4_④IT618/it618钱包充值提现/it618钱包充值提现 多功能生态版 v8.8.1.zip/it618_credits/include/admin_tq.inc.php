<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	
	if($reabc[8]!='e')return;

	if(is_array($_GET['it618_jfcount1'])) {
		foreach($_GET['it618_jfcount1'] as $id => $val) {
			if($_GET['it618_jfcount1'][$id]>0){
				C::t('#it618_credits#it618_credits_tq')->update($id,array(
					'it618_jfcount1' => $_GET['it618_jfcount1'][$id],
					'it618_jfcount2' => $_GET['it618_jfcount2'][$id],
					'it618_isok' => $_GET['it618_isok'][$id]
				));
			}
		}
	}

	cpmsg($it618_credits_lang['s25'],"action=plugins&identifier=$identifier&cp=admin_tq&pmod=admin_do&operation=$operation&do=$do&page=$page", 'succeed');
}

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_tq')." where it618_jfid=".$i)==0){
			C::t('#it618_credits#it618_credits_tq')->insert(array(
				'it618_jfid' => $i,
				'it618_jfcount1' => 10,
				'it618_jfcount2' => 100
			), true);
		}
	}
}

if(count($reabc)!=13)return;

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$tmp.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
}
if($qf_isgold==1){
	if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_tq')." where it618_jfid=11")==0){
		C::t('#it618_credits#it618_credits_tq')->insert(array(
			'it618_jfid' => 11,
			'it618_jfcount1' => 10,
			'it618_jfcount2' => 100
		), true);
	}
	$tmp.='<option value="11">'.$qf_goldname.'</option>';
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_tq&pmod=admin_do&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s1571'],'it618_credits_tq');
	$count = C::t('#it618_credits#it618_credits_tq')->count_by_search();
	
	echo '<tr><td colspan=5>'.$it618_credits_lang['s23'].$count.'</td></tr>';
	showsubtitle(array($it618_credits_lang['s16'],$it618_credits_lang['s81'],$it618_credits_lang['s1572']));
	
	foreach(C::t('#it618_credits#it618_credits_tq')->fetch_all_by_search() as $it618_credits_tq) {
		
		if($it618_credits_tq['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		if($it618_credits_tq['it618_jfid']<=8){
			$jfname=$_G['setting']['extcredits'][$it618_credits_tq['it618_jfid']]['title'];
		}else{
			if($it618_credits_tq['it618_jfid']==11){
				if($qf_isgold==1)$jfname=$qf_goldname;
			}
		}
		
		if($jfname!=''){
			showtablerow('', array('', '', ''), array(
				'<div style="width:40px">'.$jfname.'</div>',
				$it618_credits_lang['s1573'].'<input class="txt" type="text" style="width:50px;color:green;font-weight:bold;margin-right:0px" name="it618_jfcount1['.$it618_credits_tq['id'].']" value="'.$it618_credits_tq['it618_jfcount1'].'">/<input class="txt" type="text" style="width:50px;color:red;font-weight:bold" name="it618_jfcount2['.$it618_credits_tq['id'].']" value="'.$it618_credits_tq['it618_jfcount2'].'">',
				'<input class="checkbox" type="checkbox" name="it618_isok['.$it618_credits_tq['id'].']" '.$it618_isok_checked.' value="1">',
			));
		}
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	
	echo '<tr><td colspan="5"><div class="fixsel"><input type="submit" class="btn" id="it618submit" name="it618submit" value="'.$it618_credits_lang['s29'].'" /></div></td></tr>';
	
	if(count($reabc)!=13)return;
showtablefooter();
?>