<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$sql='&finduid='.$_GET['finduid'].'&findkey='.$_GET['findkey'].'&it618_money1='.$_GET['it618_money1'].'&it618_money2='.$_GET['it618_money2'];

if(submitcheck('it618submit_money')){
	if($_GET['moneyuid']!='' && $_GET['moneyvalue']>0){
		if($_GET['moneytype']=='plus'){
			$uidarr=explode(",",$_GET['moneyuid']);
			for($i=0;$i<count($uidarr);$i++){
				if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_member')." WHERE uid=%d", array($uidarr[$i]))>0){
				
					$it618_bz=$it618_credits_lang['s1304'];
					$it618_bz=str_replace("{money}",'<font color=red>'.$_GET['moneyvalue'].'</font>',$it618_bz);
					
					savemoney(array(
						'it618_uid' => $uidarr[$i],
						'it618_type' => 'plus',
						'it618_money1' => $_GET['moneyvalue'],
						'it618_bz' => $it618_bz,
						'it618_zftype' => 'money',
						'it618_zyid' => $_G['uid'],
						'it618_time' => $_G['timestamp']
					));
				}
			}
		}else{
			$uidarr=explode(",",$_GET['moneyuid']);
			for($i=0;$i<count($uidarr);$i++){
				set_time_limit (0);
				ignore_user_abort(true);
		
				$flagkm=0;$times=0;
				while($flagkm==0){
					if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
						$flagkm=1;
					}
					if($flagkm==0){
						sleep(1);
						$times=$times+1;
					}
					if($times>60){
						it618_credits_delmoneywork();
					}
				}
				C::t('#it618_credits#it618_credits_moneywork')->insert(array(
					'it618_iswork' => 1
				), true);
				
				$it618_moneytmp=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uidarr[$i]);
				DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_moneytmp." where it618_uid=".$uidarr[$i]);
				if($_GET['moneyvalue']>$it618_moneytmp){
					it618_credits_delmoneywork();continue;
				}
				
				$it618_bz=$it618_credits_lang['s1305'];
				$it618_bz=str_replace("{money}",'<font color=red>'.$_GET['moneyvalue'].'</font>',$it618_bz);
				
				$id=savemoney(array(
					'it618_uid' => $uidarr[$i],
					'it618_type' => 'minus',
					'it618_money2' => $_GET['moneyvalue'],
					'it618_bz' => $it618_bz,
					'it618_zftype' => 'hongbao',
					'it618_zyid' => $_G['uid'],
					'it618_time' => $_G['timestamp']
				));
				it618_credits_delmoneywork();
			}
		}
	}
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_users&pmod=admin_users&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s682'],'it618_credits_uset');
	showsubmit('it618sercsubmit', $it618_credits_lang['s103'], '<span style="float:right">'.$it618_credits_lang['s1300'].'<input name="moneyuid" class="txt" style="width:150px" /><select name="moneytype" style="margin-right:3px"><option value="plus">'.$it618_credits_lang['s1298'].'</option><option value="minus">'.$it618_credits_lang['s1299'].'</option></select> <input name="moneyvalue" class="txt" style="width:50px" /> <input type="submit" class="btn" name="it618submit_money" value="'.$it618_credits_lang['s1302'].'" onclick="return confirm(\''.$it618_credits_lang['s1303'].'\')"/></span>'.$it618_credits_lang['s104'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />'.$it618_credits_lang['s853'].' <input name="findkey" value="'.$_GET['findkey'].'" class="txt" style="width:180px" /> '.$it618_credits_lang['s695'].' <input id="it618_money1" name="it618_money1" value="'.$_GET['it618_money1'].'" class="txt" style="width:80px;margin-right:0"/> - <input id="it618_money2" name="it618_money2" value="'.$_GET['it618_money2'].'" class="txt" style="width:80px;"/>');
	
	$count = C::t('#it618_credits#it618_credits_uset')->count_by_search($it618sql,'',$_GET['findkey'],$_GET['finduid'],$_GET['it618_money1'], $_GET['it618_money2']);
	$sum = C::t('#it618_credits#it618_credits_uset')->sum_by_search($it618sql,'',$_GET['findkey'],$_GET['finduid'],$_GET['it618_money1'], $_GET['it618_money2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_users&pmod=admin_users&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=14>'.$it618_credits_lang['s689'].'<font color=red>'.$count.'</font> '.$it618_credits_lang['s690'].'<font color=red>'.round($sum,2).'</font> '.$it618_credits_lang['s28'].'<span style="float:right;color:red">'.$it618_credits_lang['s694'].'</span></td></tr>';
	showsubtitle(array($it618_credits_lang['s683'],$it618_credits_lang['s684'],$it618_credits_lang['s685'],$it618_credits_lang['s686'],$it618_credits_lang['s687'],$it618_credits_lang['s688']));
	
	foreach(C::t('#it618_credits#it618_credits_uset')->fetch_all_by_search($it618sql,'it618_money desc',$_GET['findkey'],$_GET['finduid'],$_GET['it618_money1'], $_GET['it618_money2'],$startlimit,$ppp) as $it618_credits_uset) {
		
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_uset['it618_uid']);
		
		$it618_alipaycodeimg='';
		if($it618_credits_uset["it618_alipaycodeimg"]!=''){
			$it618_alipaycodeimg='<a href="'.$it618_credits_uset["it618_alipaycodeimg"].'" target="_blank"><img src="'.$it618_credits_uset["it618_alipaycodeimg"].'" height="26" style="vertical-align:middle" /></a>';
		}
		
		$it618_wxpaycodeimg='';
		if($it618_credits_uset["it618_wxpaycodeimg"]!=''){
			$it618_wxpaycodeimg='<a href="'.$it618_credits_uset["it618_wxpaycodeimg"].'" target="_blank"><img src="'.$it618_credits_uset["it618_wxpaycodeimg"].'" height="26" style="vertical-align:middle" /></a>';
		}
		
		$bankstr='';
		if($it618_credits_uset["it618_bankname"]!=''){
			$bankstr='<br><font color=#999>'.$it618_credits_lang['s693'].'</font>'.$it618_credits_uset['it618_bankname'].' '.$it618_credits_uset['it618_bankid'].' '.' '.$it618_credits_uset['it618_bankaddr'];
		}

		showtablerow('', array('', '', ''), array(
			$it618_credits_uset['it618_uid'],
			'<a href="'.it618_credits_rewriteurl($it618_credits_uset['it618_uid']).'" target="_blank">'.$username.'</a>',
			$it618_credits_uset['it618_tel'],
			'<font color=red>'.$it618_credits_uset['it618_money'].'</font>',
			'<font color=#999>'.$it618_credits_lang['s691'].'</font>'.$it618_credits_uset['it618_alipayname'].' '.$it618_credits_uset['it618_alipay'].' '.$it618_alipaycodeimg.' '.
			'<font color=#999>'.$it618_credits_lang['s692'].'</font>'.$it618_credits_uset['it618_wxname'].' '.$it618_credits_uset['it618_wx'].' '.$it618_wxpaycodeimg.$bankstr,
			$it618_credits_uset['it618_skname'].'<br>'.$it618_credits_uset['it618_skurl']
		));
	}


	echo '<tr><td width=58></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter();
?>