<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php';
}
				
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php';
}

if($_GET['dotype']) {
	$it618_state0='';$it618_state1='';$it618_state2='';$it618_state3='';$it618_state4='';$it618_state5='';$it618_state6='';$it618_state7='';$it618_state8='';$it618_state9='';$it618_state10='';
	if($_GET['dotype']==''){$it618_state0='selected="selected"';}
	if($_GET['dotype']=='cz'){$it618sql.="it618_type='cz'";$it618_state1='selected="selected"';}
	if($_GET['dotype']=='sk'){$it618sql.="it618_type='sk'";$it618_state2='selected="selected"';}
	if($_GET['dotype']=='zy'){$it618sql.= "it618_type='zy'";$it618_state3='selected="selected"';}
	if($_GET['dotype']=='pay'){$it618sql.= "it618_type='pay'";$it618_state4='selected="selected"';}
	if($_GET['dotype']=='tx'){$it618sql.="it618_type='tx'";$it618_state5='selected="selected"';}
	if($_GET['dotype']=='tx1'){$it618sql.="it618_type='tx' and it618_txstate=0";$it618_state6='selected="selected"';}
	if($_GET['dotype']=='tx2'){$it618sql.="it618_type='tx' and it618_txstate=1";$it618_state7='selected="selected"';}
	if($_GET['dotype']=='tx3'){$it618sql.="it618_type='tx' and it618_txstate=2";$it618_state8='selected="selected"';}
	if($_GET['dotype']=='plus'){$it618sql.="it618_type='plus'";$it618_state9='selected="selected"';}
	if($_GET['dotype']=='minus'){$it618sql.="it618_type='minus'";$it618_state10='selected="selected"';}
}

$sql='&finduid='.$_GET['finduid'].'&dotype='.$_GET['dotype'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

if(submitcheck('it618submit_money')){
	if($_GET['moneyuid']!='' && $_GET['moneyvalue']>0){
		if($_GET['moneytype']=='plus'){
			$uidarr=explode(",",$_GET['moneyuid']);
			for($i=0;$i<count($uidarr);$i++){
				if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_member')." WHERE uid=%d", array($uidarr[$i]))>0){
				
					$it618_bz=$it618_credits_lang['s1304'];
					$it618_bz=str_replace("{money}",'<font color=red>'.$_GET['moneyvalue'].'</font>',$it618_bz);
					
					savemoney(array(
						'it618_uid' => $uidarr[$i],
						'it618_type' => 'plus',
						'it618_money1' => $_GET['moneyvalue'],
						'it618_bz' => $it618_bz,
						'it618_zftype' => 'money',
						'it618_zyid' => $_G['uid'],
						'it618_time' => $_G['timestamp']
					));
				}
			}
		}else{
			$uidarr=explode(",",$_GET['moneyuid']);
			for($i=0;$i<count($uidarr);$i++){
				set_time_limit (0);
				ignore_user_abort(true);
		
				$flagkm=0;$times=0;
				while($flagkm==0){
					if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
						$flagkm=1;
					}
					if($flagkm==0){
						sleep(1);
						$times=$times+1;
					}
					if($times>60){
						it618_credits_delmoneywork();
					}
				}
				C::t('#it618_credits#it618_credits_moneywork')->insert(array(
					'it618_iswork' => 1
				), true);
				
				$it618_moneytmp=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uidarr[$i]);
				DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_moneytmp." where it618_uid=".$uidarr[$i]);
				if($_GET['moneyvalue']>$it618_moneytmp){
					it618_credits_delmoneywork();continue;
				}
				
				$it618_bz=$it618_credits_lang['s1305'];
				$it618_bz=str_replace("{money}",'<font color=red>'.$_GET['moneyvalue'].'</font>',$it618_bz);
				
				$id=savemoney(array(
					'it618_uid' => $uidarr[$i],
					'it618_type' => 'minus',
					'it618_money2' => $_GET['moneyvalue'],
					'it618_bz' => $it618_bz,
					'it618_zftype' => 'hongbao',
					'it618_zyid' => $_G['uid'],
					'it618_time' => $_G['timestamp']
				));
				it618_credits_delmoneywork();
			}
		}
	}
}

if(submitcheck('it618submit_del')){
	$ok=0;
	if($reabc[8]!='e')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_credits_money=C::t('#it618_credits#it618_credits_money')->fetch_by_id($delid);
		
		if($it618_credits_money['it618_txstate']==0||$it618_credits_money['it618_txstate']==2){
			
			C::t('#it618_credits#it618_credits_money')->delete_by_id($delid);
			$it618_money=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($it618_credits_money['it618_uid']);
			DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_money." where it618_uid=".$it618_credits_money['it618_uid']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_credits_lang['s174'].$ok, "action=plugins&identifier=$identifier&cp=admin_moneysum&pmod=admin_money&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_yfk')){
	$ok=0;
	if($reabc[7]!='r')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_credits_money=C::t('#it618_credits#it618_credits_money')->fetch_by_id($delid);
		
		if($it618_credits_money['it618_txstate']==0){
			C::t('#it618_credits#it618_credits_money')->update($it618_credits_money['id'],array(
				'it618_txstate' => 1
			));
			it618_credits_sendmessage("tx_user",$it618_credits_money['id']);
			$ok=$ok+1;
		}
	}
	cpmsg($it618_credits_lang['s175'].$ok, "action=plugins&identifier=$identifier&cp=admin_moneysum&pmod=admin_money&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_chehuifk')){
	$ok=0;
	if($reabc[7]!='r')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_credits_money=C::t('#it618_credits#it618_credits_money')->fetch_by_id($delid);
		
		if($it618_credits_money['it618_txstate']==0||$it618_credits_money['it618_txstate']==2){
			C::t('#it618_credits#it618_credits_money')->update($it618_credits_money['id'],array(
				'it618_txstate' => 2,
				'it618_txstatebz' => $_GET['chehuiabout']
			));
			it618_credits_sendmessage("txchehui_user",$it618_credits_money['id']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_credits_lang['s1325'].$ok, "action=plugins&identifier=$identifier&cp=admin_moneysum&pmod=admin_money&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_moenyyfk')){
	$ok=0;
	if($reabc[7]!='r')return;
	$errorstr='';
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_credits_money=C::t('#it618_credits#it618_credits_money')->fetch_by_id($delid);
		
		if($it618_credits_money['it618_txstate']==0){

			if($it618_credits_money["it618_txtype"]=='alipay'){
				if($alipay_adminisok==1){
					$out_biz_no = date("YmdHis").'0101'.$it618_credits_money["id"];
					$ytmoney=round(($it618_credits_money["it618_money2"]-$it618_credits_money["it618_money2"]*$it618_credits_money["it618_txtcbl"]/100),2);
					$transstr=alitrans($out_biz_no,$it618_credits_money["it618_txid"],$ytmoney,it618_credits_gbktoutf($it618_credits_money["it618_bz"]));
					$transarr=explode("it618_split",$transstr);
					
					if($transarr[0]=='Success'){
						C::t('#it618_credits#it618_credits_money')->update($it618_credits_money['id'],array(
							'it618_txstate' => 1
						));
						it618_credits_sendmessage("tx_user",$it618_credits_money['id']);
						$ok=$ok+1;
					}else{
						$errorstr.=$it618_credits_money['id'].': '.$transarr[0].'<br>';
					}
				}else{
					$errorstr.=$it618_credits_money['id'].': '.$it618_credits_lang['s1224'].'<br>';
				}
			}
			
			if($it618_credits_money["it618_txtype"]=='wx'){
				if($wx_adminisok==1){
					$out_biz_no = date("YmdHis").'0102'.$it618_credits_money["id"];
					$ytmoney=round(($it618_credits_money["it618_money2"]-$it618_credits_money["it618_money2"]*$it618_credits_money["it618_txtcbl"]/100),2);
					$openid=C::t('#it618_members#it618_members_wxuser')->fetch_openid_by_uid($it618_credits_money["it618_uid"],$it618_credits_money['it618_payid']);
					
					if($openid!=''){
						if($it618_credits_money["it618_bz"]==''){
							$remark=it618_credits_gbktoutf($it618_credits_lang['s1562']);
						}else{
							$remark=it618_credits_gbktoutf($it618_credits_money["it618_bz"]);
						}
						$transstr=alitrans_wx($out_biz_no,$openid,$ytmoney,$remark);
						$transarr=explode("it618_split",$transstr);
						
						if($transarr[0]=='Success'){
							C::t('#it618_credits#it618_credits_money')->update($it618_credits_money['id'],array(
								'it618_txstate' => 1
							));
							it618_credits_sendmessage("tx_user",$it618_credits_money['id']);
							$ok=$ok+1;
						}else{
							$errorstr.=$it618_credits_money['id'].': '.$transarr[0].'<br>';
						}
					}else{
						$errorstr.=$it618_credits_money['id'].': '.$it618_credits_lang['s1570'].'<br>';
					}
				}else{
					$errorstr.=$it618_credits_money['id'].': '.$it618_credits_lang['s1224'].'<br>';
				}
			}
		}
	}

	cpmsg($it618_credits_lang['s175'].$ok.'<br>'.$errorstr, "action=plugins&identifier=$identifier&cp=admin_moneysum&pmod=admin_money&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=13)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_moneysum&pmod=admin_money&operation=$operation&do=$do".$sql);
showtableheaders($it618_credits_lang['s917'],'it618_credits_money');
	showsubmit('it618sercsubmit', $it618_credits_lang['s103'], '<span style="float:right">'.$it618_credits_lang['s1300'].'<input name="moneyuid" class="txt" style="width:150px" /><select name="moneytype" style="margin-right:3px"><option value="plus">'.$it618_credits_lang['s1298'].'</option><option value="minus">'.$it618_credits_lang['s1299'].'</option></select> <input name="moneyvalue" class="txt" style="width:50px" /> <input type="submit" class="btn" name="it618submit_money" value="'.$it618_credits_lang['s1302'].'" onclick="return confirm(\''.$it618_credits_lang['s1303'].'\')"/></span>'.$it618_credits_lang['s104'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />'.$it618_credits_lang['s842'].' <select id="dotype" name="dotype" style="margin-right:3px"><option value="" '.$it618_state0.'>'.$it618_credits_lang['s178'].'</option><option value="cz" '.$it618_state1.'>'.$it618_credits_lang['t4'].'</option><option value="sk" '.$it618_state2.'>'.$it618_credits_lang['t109'].'</option><option value="zy" '.$it618_state3.'>'.$it618_credits_lang['s240'].'</option><option value="pay" '.$it618_state4.'>'.$it618_credits_lang['s1207'].'</option><option value="tx" '.$it618_state5.'>'.$it618_credits_lang['t105'].'</option><option value="tx1" '.$it618_state6.'>'.$it618_credits_lang['t106'].'</option><option value="tx2" '.$it618_state7.'>'.$it618_credits_lang['t107'].'</option><option value="tx3" '.$it618_state8.'>'.$it618_credits_lang['s1328'].'</option><option value="plus" '.$it618_state9.'>'.$it618_credits_lang['s1298'].'</option><option value="minus" '.$it618_state10.'>'.$it618_credits_lang['s1299'].'</option></select> '.$it618_credits_lang['s190'].' <input id="it618_time1" name="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:80px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" /> - <input id="it618_time2" name="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:80px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>');

	$count = C::t('#it618_credits#it618_credits_money')->count_by_search($it618sql,'',$_GET['finduid'], '', $_GET['it618_time1'], $_GET['it618_time2']);
	$sum = C::t('#it618_credits#it618_credits_money')->sum_by_search($it618sql,'',$_GET['finduid'], '', $_GET['it618_time1'], $_GET['it618_time2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_moneysum&pmod=admin_money&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=14>'.$it618_credits_lang['s483'].'<font color=red>'.$count.'</font> '.$it618_credits_lang['s1049'].'<font color=red>'.$sum.'</font><span style="float:right;color:red">'.$it618_credits_lang['s1070'].'</span></td></tr>';
	showsubtitle(array('',$it618_credits_lang['s189'],$it618_credits_lang['s190']));
	
	foreach(C::t('#it618_credits#it618_credits_money')->fetch_all_by_search($it618sql,'id desc',$_GET['finduid'], '', $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_credits_money) {
		
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_money['it618_uid']);
		$userstr='<a href="'.it618_credits_rewriteurl($it618_credits_money['it618_uid']).'" target="_blank">'.$username.'</a> ';
		
		$bzstr='';
		if($it618_credits_money['it618_bz']!=''){
			$bzstr='<a href="javascript:" onclick="alert(\''.$it618_credits_money['it618_bz'].'\')">'.$it618_credits_lang['s191'].'</a>';
		}
		
		$tmpstr=$userstr.$it618_credits_money['it618_bz'];
		
		if($it618_credits_money['it618_type']=='cz'){
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;

			if($it618_credits_money['it618_paytype']!='quan'){
				
				$paystr=getpaystr($it618_credits_money['it618_paytype'],$it618_credits_money['it618_payid']);
				
				$zsjfstr='';
				if($it618_credits_money['it618_zsjfcount']>0){
					$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_money['it618_zsjfcount'].'</font><font color=green>'.$_G['setting']['extcredits'][$it618_credits_money['it618_zsjfid']]['title'].'</font> ';
				}
				
				$tmpstr=$userstr.$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font>'.$it618_credits_lang['s198'].' '.$zsjfstr.' '.$bzstr.' '.$paystr;

			}else{
				$tmpstr=$userstr.$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font> '.$it618_credits_lang['t283'].' '.$it618_credits_lang['s200'].$it618_credits_money['it618_payid'].' '.$bzstr;
			}
		}
		
		if($it618_credits_money['it618_type']=='sk'){
			$paystr=getpaystr($it618_credits_money['it618_paytype'],$it618_credits_money['it618_payid']);
			
			$it618_money1=$it618_credits_money['it618_money1'];
			
			$tcstr='';
			if($it618_credits_money['it618_sktcbl']>0){
				$it618_money1=$it618_credits_money['it618_skmoney'];
				$tcstr=$it618_credits_lang['s1058'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font>'.$it618_credits_lang['s198'].' '.$it618_credits_lang['s1059'].$it618_credits_money['it618_sktcbl'].'%';
			}
			
			$zsjfstr='';
			if($it618_credits_money['it618_zsjfcount']>0){
				$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_money['it618_zsjfcount'].'</font><font color=green>'.$_G['setting']['extcredits'][$it618_credits_money['it618_zsjfid']]['title'].'</font> ';
			}
			
			$tmpstr=$userstr.$it618_credits_lang['s1181'].'<font color=red>'.$it618_money1.'</font>'.$it618_credits_lang['s198'].' '.$tcstr.' '.$zsjfstr.' '.$bzstr.' '.$paystr;
		}
		
		if($it618_credits_money['it618_type']=='zy'){
			if($it618_credits_money['it618_zytype']=='it618_credits'){
				$it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($it618_credits_money['it618_zyid']);
				
				$cname=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
				$tmptitle='1'.$cname.' = '.floatval($it618_credits_sale['it618_bl']).$it618_credits_lang['s28'];
				
				$tmpstr=$userstr.$it618_credits_lang['s201'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$it618_credits_lang['t96'].'<font color=red><b>'.$it618_credits_sale['it618_money'].'</b></font>'.$it618_credits_lang['s28'].' '.$tmptitle.' '.$bzstr;
			}else if($it618_credits_money['it618_zytype']=='it618_union_yqmoney1'){
				$tmpstr=$it618_credits_money['it618_bz'];
				if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where id=".$it618_credits_money['it618_zyid'])) {
					$regname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_uid']);
					$tmpstr=str_replace($it618_credits_lang['s1362'],$it618_credits_lang['s1362'].' '.$regname.' ',$tmpstr);
				}
			}else if($it618_credits_money['it618_zytype']=='it618_union_yqmoney2'){
				$tmpstr=$it618_credits_money['it618_bz'];
				if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where id=".$it618_credits_money['it618_zyid'])) {
					$regname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_uid']);
					$tmpstr=str_replace($it618_credits_lang['s1362'],$it618_credits_lang['s1362'].' '.$regname.' ',$tmpstr);
					$tuiname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_tuiuid']);
					$tmpstr=str_replace($it618_credits_lang['s1363'],$it618_credits_lang['s1363'].' '.$tuiname.' ',$tmpstr);
				}
			}else{
				$tmpstr=$it618_credits_money['it618_bz'];
			}
		}
		
		if($it618_credits_money['it618_type']=='pay'){
			$tmpstr=$userstr.' '.$it618_credits_lang['s1206'].'<font color=red>'.$it618_credits_money['it618_money2'].'</font>'.$it618_credits_lang['s1208'].$it618_credits_money['it618_bz'];
		}
		
		$strcss='style="display:none"';
		if($it618_credits_money['it618_type']=='tx'){			
			$bankstr=$it618_credits_money['it618_bank'];

			if($it618_credits_money['it618_txstate']==0){$strcss='style="display:"';$state='<font color=red>'.$it618_credits_lang['s205'].'</font>';}
			if($ispower==1)$btnstr.=' <a href="javascript:" onclick="deltx('.$it618_credits_money['id'].')"><font color=#999>'.$it618_credits_lang['s310'].'</font></a> <a href="javascript:" onclick="yfktx('.$it618_credits_money['id'].')"><font color=#999>'.$it618_credits_lang['s311'].'</font></a>';
			
			if($it618_credits_money['it618_txstate']==1){$state='<font color=green>'.$it618_credits_lang['s206'].'</font>';}
			
			$txstatebz='';
			if($it618_credits_money['it618_txstate']==2){
				$strcss='style="display:"';
				$state='<font color=blue>'.$it618_credits_lang['s1327'].'</font>';
				$txstatebz=' '.$it618_credits_lang['s1324'].$it618_credits_money['it618_txstatebz'];
			}
			
			$tcblstr='';
			if($it618_credits_money['it618_txtcbl']>0){
				$sjmoney=round(($it618_credits_money['it618_money2']-$it618_credits_money['it618_money2']*$it618_credits_money['it618_txtcbl']/100),2);
				$tcblstr=' '.$it618_credits_lang['s573'].$it618_credits_money['it618_txtcbl'].'% '.$it618_credits_lang['s574'].'<font color=red><b>'.$sjmoney.'</b></font> '.$it618_credits_lang['s28'];
			}
			
			$tmpwxstr='';
			if($it618_credits_money["it618_txtype"]=='wx'&&$it618_credits_money["it618_txstate"]==0&&$wx_adminisok==1&&$it618_credits_money["it618_payid"]>0){
				$it618_wxname=DB::result_first("SELECT it618_wxname FROM ".DB::table('it618_members_wxuser')." WHERE id=".$it618_credits_money["it618_payid"]);
				$tmpwxstr=$it618_credits_lang['s1229'].'<font color=red>'.$it618_wxname.'</font>';
			}
			
			$bankcodeimgstr='';
			if($it618_credits_money["it618_bankcodeimg"]!=''){
				$bankcodeimgstr='<a href="'.$it618_credits_money["it618_bankcodeimg"].'" target="_blank"><img src="'.$it618_credits_money["it618_bankcodeimg"].'" width="23" style="vertical-align:middle" /></a>';
			}
			
			$tmpstr=$userstr.$it618_credits_lang['s353'].'<font color=red>'.$it618_credits_money['it618_money2'].'</font> '.$it618_credits_lang['s28'].' '.$tcblstr.' '.$state.' '.$bankstr.' '.$bankcodeimgstr.' '.$bzstr.' '.$tmpwxstr.$txstatebz;
		}
		
		showtablerow('', array('class="td25"','', '', ''), array(
			'<div style="text-align:center;width:60px"><input class="checkbox" type="checkbox" id="chk_del'.$it618_credits_money['id'].'" name="delete[]" value="'.$it618_credits_money['id'].'" '.$strcss.'><label for="chk_del'.$it618_credits_money['id'].'">'.$it618_credits_money['id'].'</label><input type="hidden" name="id['.$it618_credits_money['id'].']" value="'.$it618_credits_money['id'].'"></div>',
			$tmpstr,
			date('Y-m-d H:i:s', $it618_credits_money['it618_time'])
		));
	}
	
	if($alipay_adminisok==1||$wx_adminisok==1){
		$tmpbtn='<input type="submit" class="btn" name="it618submit_moenyyfk" style="color:red" value="'.$it618_credits_lang['s1221'].'" onclick="return confirm(\''.$it618_credits_lang['s1222'].'\')"/>';
	}

	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type="submit" class="btn" name="it618submit_del" value="'.$it618_credits_lang['s208'].'" onclick="return confirm(\''.$it618_credits_lang['s209'].'\')"/> <input type="submit" class="btn" name="it618submit_yfk" value="'.$it618_credits_lang['s210'].'" onclick="return confirm(\''.$it618_credits_lang['s211'].'\')"/> '.$tmpbtn.'<br>'.$it618_credits_lang['s1324'].'<input type="text" name="chehuiabout" style="width:500px"> <input type="submit" class="btn" name="it618submit_chehuifk" value="'.$it618_credits_lang['s1323'].'" onclick="return confirm(\''.$it618_credits_lang['s1326'].'\')"/> <script type="text/javascript" src="source/plugin/it618_credits/js/Calendar.js"></script><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter();
?>