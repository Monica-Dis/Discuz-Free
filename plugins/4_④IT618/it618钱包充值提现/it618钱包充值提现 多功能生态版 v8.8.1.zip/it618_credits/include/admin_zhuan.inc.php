<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='e')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_credits#it618_credits_zhuan')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_zhuanbl'])) {
		foreach($_GET['it618_zhuanbl'] as $id => $val) {
			if($_GET['it618_zhuanbl'][$id]>0){
				C::t('#it618_credits#it618_credits_zhuan')->update($id,array(
					'it618_zhuanbl' => $_GET['it618_zhuanbl'][$id],
					'it618_jfcount1' => $_GET['it618_jfcount1'][$id],
					'it618_jfcount2' => $_GET['it618_jfcount2'][$id],
					'it618_isok' => $_GET['it618_isok'][$id]
				));
				$ok1=$ok1+1;
			}
		}
	}

	$newit618_jfid1_array = !empty($_GET['newit618_jfid1']) ? $_GET['newit618_jfid1'] : array();
	$newit618_jfid2_array = !empty($_GET['newit618_jfid2']) ? $_GET['newit618_jfid2'] : array();
	$newit618_isok_array = !empty($_GET['newit618_isok']) ? $_GET['newit618_isok'] : array();
	
	foreach($newit618_jfid1_array as $key => $value) {
		$newit618_jfid1 = $newit618_jfid1_array[$key];
		
		if($newit618_jfid1 != '') {
			if($newit618_jfid1_array[$key]!=$newit618_jfid2_array[$key]){
				$count = C::t('#it618_credits#it618_credits_zhuan')->count_by_isadd($newit618_jfid1_array[$key],$newit618_jfid2_array[$key]);
				if($count==0){
					C::t('#it618_credits#it618_credits_zhuan')->insert(array(
						'it618_jfid1' => $newit618_jfid1_array[$key],
						'it618_jfid2' => $newit618_jfid2_array[$key],
						'it618_isok' => $newit618_isok_array[$key]
					), true);
					$ok2=$ok2+1;
				}
			}
		}
	}

	cpmsg($it618_credits_lang['s7'].$ok1.' '.$it618_credits_lang['s8'].$ok2.' '.$it618_credits_lang['s9'].$del.')',"action=plugins&identifier=$identifier&cp=admin_zhuan&pmod=admin_do&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=13)return;

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$tmp.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
}
if($qf_isgold==1){
	$tmp.='<option value="11">'.$qf_goldname.'</option>';
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_zhuan&pmod=admin_do&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s15'],'it618_credits_zhuan');
	$count = C::t('#it618_credits#it618_credits_zhuan')->count_by_search();
	
	echo '<tr><td colspan=5>'.$it618_credits_lang['s10'].$count.'<span style="float:right;color:red">'.$it618_credits_lang['s171'].'</span></td></tr>';
	showsubtitle(array('', $it618_credits_lang['s11'], $it618_credits_lang['s12'],$it618_credits_lang['s81'],$it618_credits_lang['s13']));
	
	foreach(C::t('#it618_credits#it618_credits_zhuan')->fetch_all_by_search() as $it618_credits_zhuan) {
		
		if($it618_credits_zhuan['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		if($it618_credits_zhuan['it618_jfid1']<=8){
			$jfname1=$_G['setting']['extcredits'][$it618_credits_zhuan['it618_jfid1']]['title'];
		}else{
			if($it618_credits_zhuan['it618_jfid1']==11){
				if($qf_isgold==1)$jfname1=$qf_goldname;
			}
		}
		if($it618_credits_zhuan['it618_jfid2']<=8){
			$jfname2=$_G['setting']['extcredits'][$it618_credits_zhuan['it618_jfid2']]['title'];
		}else{
			if($it618_credits_zhuan['it618_jfid2']==11){
				if($qf_isgold==1)$jfname2=$qf_goldname;
			}
		}
		
		if($jfname1!=''&&$jfname2!=''){
			showtablerow('', array('class="td25"', '', '', ''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_credits_zhuan['id']."\" $disabled><input type=\"hidden\" name=\"id[".$it618_credits_zhuan['id']."]\" value=\"".$it618_credits_zhuan['id']."\">",
				$jfname1,
				$jfname2,
				$jfname2.$it618_credits_lang['t215'].' = '.$jfname1.$it618_credits_lang['t215'].' * <input class="txt" type="text" style="width:50px;color:blue;font-weight:bold" name="it618_zhuanbl['.$it618_credits_zhuan['id'].']" value="'.$it618_credits_zhuan['it618_zhuanbl'].'">  '.$it618_credits_lang['s172'].'<input class="txt" type="text" style="width:50px;color:green;font-weight:bold;margin-right:0px" name="it618_jfcount1['.$it618_credits_zhuan['id'].']" value="'.$it618_credits_zhuan['it618_jfcount1'].'">/<input class="txt" type="text" style="width:50px;color:red;font-weight:bold" name="it618_jfcount2['.$it618_credits_zhuan['id'].']" value="'.$it618_credits_zhuan['it618_jfcount2'].'">',
				'<input class="checkbox" type="checkbox" name="it618_isok['.$it618_credits_zhuan['id'].']" '.$it618_isok_checked.' value="1">',
			));
		}
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$s73=$it618_credits_lang['s173'];
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_jfid1[]").length;
	
		return [
		[[1,''], 
		[1,'<select name="newit618_jfid1[]">$tmp</select>'], 
		[1,'<select name="newit618_jfid2[]">$tmp</select>'], 
		[1,'$s73'],
		[1,'<input class="checkbox" type="checkbox" name="newit618_isok[]" value="1">']]
		];
	}
	rowtypedata=rundata();

	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=13)return;
showtablefooter();
?>