<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if($_GET['bzfind']!='allquan')$extrasql = " AND it618_bz LIKE '".addcslashes(addslashes($_GET['bzfind']),'%_')."'";

$strtmp=$it618_credits_lang['s147'].",".$it618_credits_lang['s148'].",".$it618_credits_lang['s884'].",".$it618_credits_lang['s149'].",".$it618_credits_lang['s150'].",".$it618_credits_lang['s151']."\n";
$query = DB::query("SELECT * FROM ".DB::table('it618_credits_quan')." WHERE it618_usetime=0$extrasql ORDER BY id DESC");
while($it618_credits_quan = DB::fetch($query)) {
	if($it618_credits_quan['it618_etime']==0){
		$it618_etime=$it618_credits_lang['s152'];
	}else{
		$it618_etime=date('Y-m-d H:i:s', $it618_credits_quan['it618_etime']);
	}
	$cname=$_G['setting']['extcredits'][$it618_credits_quan['it618_jfid']]['title'];
	
	if($it618_credits_quan['it618_xgtime']>0){
		$it618_xgtime=$it618_credits_quan['it618_xgtime'].$it618_credits_lang['s885'];
	}else{
		$it618_xgtime=$it618_credits_lang['s886'];
	}
	
	$datacount=$datacount+1;
	$strtmp.=$it618_credits_quan['it618_code'].",".$it618_credits_quan['it618_jfcount'].$cname.",".$it618_xgtime.",".$it618_etime.",".$it618_credits_quan['it618_bz'].",".date('Y-m-d H:i:s', $it618_credits_quan['it618_addtime'])."\n";

}
$csvstr.=$strtmp;

if(CHARSET=='utf-8')$csvstr=iconv("utf-8", "gb2312", $csvstr);
export_csv('data_'.$datacount.'.csv',$csvstr);

function export_csv($filename,$data) { 
   header("Content-type:text/csv"); 
   header("Content-Disposition:attachment;filename=".$filename); 
   header('Cache-Control:must-revalidate,post-check=0,pre-check=0'); 
   header('Expires:0'); 
   header('Pragma:public'); 
   ob_end_clean();
   echo $data; 
   for($n=0;$n<100;$n++){
	   echo "\n";
   }
   
} 

?>