<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php';
}

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$hongbao_isok=$_GET['hongbao_isok'];
		if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_hongbao'")==0){
			$hongbao_isok=0;
		}
		
		$fileData = '$hongbao_isok=\''.$hongbao_isok."';\n";
		
		$fileData .= '$hongbao_credit[0]=\''.floatval($_GET['hongbao_credit0'])."';\n";
		$fileData .= '$hongbao_min[0]=\''.floatval($_GET['hongbao_min0'])."';\n";
		$fileData .= '$hongbao_max[0]=\''.floatval($_GET['hongbao_max0'])."';\n";
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$fileData .= '$hongbao_credit['.$i.']=\''.intval($_GET['hongbao_credit'.$i])."';\n";
				$fileData .= '$hongbao_min['.$i.']=\''.intval($_GET['hongbao_min'.$i])."';\n";
				$fileData .= '$hongbao_max['.$i.']=\''.intval($_GET['hongbao_max'.$i])."';\n";
			}
		}
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s527'], "action=plugins&identifier=$identifier&cp=admin_hongbao_set&pmod=admin_hongbao&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_hongbao_set&pmod=admin_hongbao&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s520'],'it618_credits_set');

if($hongbao_isok==1)$hongbao_isok_checked='checked="checked"';else $hongbao_isok_checked="";

$it618_credit='<table><tr><td>'.$it618_credits_lang['s1061'].'</td><td>'.$it618_credits_lang['s1062'].'</td><td>'.$it618_credits_lang['s1063'].'</td><td>'.$it618_credits_lang['s1064'].'</td></tr>';

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$it618_credit.='<tr>
		<td>'.$_G['setting']['extcredits'][$i]['title'].'</td>
		<td><input type="text" class="txt" style="width:50px;color:blue" name="hongbao_min'.$i.'" value="'.$hongbao_min[$i].'"></td>
		<td><input type="text" class="txt" style="width:50px;color:blue" name="hongbao_max'.$i.'" value="'.$hongbao_max[$i].'"></td>
		<td><input type="text" class="txt" style="width:50px;color:blue" name="hongbao_credit'.$i.'" value="'.$hongbao_credit[$i].'"></td>
		</tr>';
	}
}

$it618_credit.='</table>';

if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_hongbao'")==0){
	$disabled='disabled="disabled"';
	$hongbao_isok_checked="";
}

echo '
<tr><td width="130">'.$it618_credits_lang['s522'].'</td><td><input type="checkbox" id="hongbao_isok" name="hongbao_isok" value="1" '.$disabled.' style="vertical-align:middle" '.$hongbao_isok_checked.'> <label for="hongbao_isok">'.$it618_credits_lang['s523'].'</label><br><font color=#999>'.$it618_credits_lang['s526'].'</font></td></tr>
<tr><td>'.$it618_credits_lang['s525'].'</td><td style="line-height:26px">'.$it618_credits_lang['s1065'].'<input type="text" class="txt" style="width:50px;color:blue" name="hongbao_min0" value="'.$hongbao_min[0].'">'.$it618_credits_lang['s198'].' '.$it618_credits_lang['s1066'].'<input type="text" class="txt" style="width:50px;color:blue" name="hongbao_max0" value="'.$hongbao_max[0].'">'.$it618_credits_lang['s198'].' '.$it618_credits_lang['s1067'].'<input type="text" class="txt" style="width:50px;color:blue" name="hongbao_credit0" value="'.$hongbao_credit[0].'">'.$it618_credits_lang['s198'].'
<br><font color=#999>'.$it618_credits_lang['s1068'].'</font>
</td></tr>
<tr><td>'.$it618_credits_lang['s524'].'</td><td>'.$it618_credit.'
<br><font color=#999>'.$it618_credits_lang['s1069'].'</font>
</td></tr>
';

showsubmit('it618submit', $it618_credits_lang['s29']);

if(count($reabc)!=13)return;
showtablefooter();

?>