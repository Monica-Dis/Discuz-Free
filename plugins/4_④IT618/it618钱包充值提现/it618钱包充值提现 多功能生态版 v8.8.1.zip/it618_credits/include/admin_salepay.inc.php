<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql="it618_state=1";

if($_GET['paystate']==1){
	$it618sql="it618_state=1";
}

if($_GET['paystate']==2){
	$it618sql="it618_state=0";
}

$paystate='<option value="1">'.$it618_credits_lang['s923'].'</option>';
$paystate.='<option value="2">'.$it618_credits_lang['s924'].'</option>';

$paystate=str_replace('<option value="'.$_GET['paystate'].'"','<option value="'.$_GET['paystate'].'" selected="selected"',$paystate);


if($_GET['paytype']=='money'){
	$it618sql.=" and it618_paytype='money'";
}

if($_GET['paytype']=='alipay'){
	$it618sql.=" and (it618_paytype='alipay' or it618_paytype='alipaycode' or it618_paytype='alipay_f2fcode')";
}

if($_GET['paytype']=='wx'){
	$it618sql.=" and (it618_paytype='wxwap' or it618_paytype='wxcode' or it618_paytype='wxh5' or it618_paytype='Appbyme')";
}

if($_GET['paytype']=='MAGAPPX'){
	$it618sql.=" and (it618_paytype='MAGAPPX' or it618_paytype='MAGAPPXcode')";
}

if($_GET['paytype']=='epay'){
	$it618sql.=" and it618_paytype='epay'";
}

if($_GET['paytype']=='payjs'){
	$it618sql.=" and it618_paytype like 'payjs_%'";
}

if($_GET['paytype']=='precode'){
	$it618sql.=" and it618_paytype like 'precode_%'";
}

$urlsql='&finduid='.$_GET['finduid'].'&findkey='.$_GET['findkey'].'&saletype='.$_GET['saletype'].'&paytype='.$_GET['paytype'].'&paystate='.$_GET['paystate'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		DB::delete('it618_credits_salepay', "id=$delid");

		$del=$del+1;
	}

	cpmsg($it618_credits_lang['s938'].$del, "action=plugins&identifier=$identifier&cp=admin_salepay&pmod=admin_salepay&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

$paytype='<option value="0">'.$it618_credits_lang['s869'].'</option>';
$paytype.='<option value="money">'.$it618_credits_lang['s1899'].'</option>';
$paytype.='<option value="alipay">'.$it618_credits_lang['s865'].'</option>';
$paytype.='<option value="wx">'.$it618_credits_lang['s866'].'</option>';
$paytype.='<option value="MAGAPPX">'.$it618_credits_lang['s867'].'</option>';
//$paytype.='<option value="epay">'.$it618_credits_lang['s1000'].'</option>';
$paytype.='<option value="payjs">PAYJS</option>';
$paytype.='<option value="precode">'.$it618_credits_lang['s995'].'</option>';

$paytype=str_replace('<option value="'.$_GET['paytype'].'"','<option value="'.$_GET['paytype'].'" selected="selected"',$paytype);

$saletype='<option value="0">'.$it618_credits_lang['s868'].'</option>';
$saletype.='<option value="0101">'.$it618_credits_lang['s857'].'</option>';
$saletype.='<option value="0102">'.$it618_credits_lang['s858'].'</option>';
$saletype.='<option value="0103">'.$it618_credits_lang['s859'].'</option>';
$saletype.='<option value="0108">'.$it618_credits_lang['s1001'].'</option>';
$saletype.='<option value="0109">'.$it618_credits_lang['s933'].'</option>';
$saletype.='<option value="0201">'.$it618_credits_lang['s860'].'</option>';
$saletype.='<option value="0301">'.$it618_credits_lang['s920'].'</option>';
$saletype.='<option value="0302">'.$it618_credits_lang['s921'].'</option>';
$saletype.='<option value="0303">'.$it618_credits_lang['s1006'].'</option>';
$saletype.='<option value="0401">'.$it618_credits_lang['s1002'].'</option>';
$saletype.='<option value="0501">'.$it618_credits_lang['s1004'].'</option>';
$saletype.='<option value="0502">'.$it618_credits_lang['s1005'].'</option>';
$saletype.='<option value="0503">'.$it618_credits_lang['s1007'].'</option>';
$saletype.='<option value="0601">'.$it618_credits_lang['s861'].'</option>';
$saletype.='<option value="0602">'.$it618_credits_lang['s862'].'</option>';
$saletype.='<option value="0603">'.$it618_credits_lang['s932'].'</option>';
$saletype.='<option value="0701">'.$it618_credits_lang['s1003'].'</option>';
$saletype.='<option value="0801">'.$it618_credits_lang['s863'].'</option>';
$saletype.='<option value="0802">'.$it618_credits_lang['s864'].'</option>';
$saletype.='<option value="0803">'.$it618_credits_lang['s931'].'</option>';
$saletype.='<option value="0901">'.$it618_credits_lang['s926'].'</option>';
$saletype.='<option value="0903">'.$it618_credits_lang['s928'].'</option>';
$saletype.='<option value="1001">'.$it618_credits_lang['s929'].'</option>';
$saletype.='<option value="1101">'.$it618_credits_lang['s930'].'</option>';

$saletype=str_replace('<option value="'.$_GET['saletype'].'"','<option value="'.$_GET['saletype'].'" selected="selected"',$saletype);


showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_salepay&pmod=admin_salepay&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s870'],'it618_credits_salepay');
	showsubmit('it618sercsubmit', $it618_credits_lang['s103'], $it618_credits_lang['s104'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />'.$it618_credits_lang['s853'].' <input name="findkey" value="'.$_GET['findkey'].'" class="txt" style="width:180px" /> '.$it618_credits_lang['s854'].' <select name="saletype" style="margin-right:3px">'.$saletype.'</select> '.$it618_credits_lang['s855'].' <select name="paytype" style="margin-right:3px">'.$paytype.'</select> '.$it618_credits_lang['s922'].' <select name="paystate" style="margin-right:3px">'.$paystate.'</select> '.$it618_credits_lang['s187'].'<input id="it618_time1" name="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:80px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" /> - <input id="it618_time2" name="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:80px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>');
	
	$count = C::t('#it618_credits#it618_credits_salepay')->count_by_search($it618sql,'',$_GET['findkey'],$_GET['finduid'],$_GET['saletype'],$_GET['it618_time1'],$_GET['it618_time2']);
	$sum = C::t('#it618_credits#it618_credits_salepay')->sum_by_search($it618sql,'',$_GET['findkey'],$_GET['finduid'],$_GET['saletype'],$_GET['it618_time1'],$_GET['it618_time2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_salepay&pmod=admin_salepay&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=14>'.$it618_credits_lang['s188'].'<font color=red>'.$count.'</font> '.$it618_credits_lang['s871'].'<font color=red>'.round($sum,2).'</font> '.$it618_credits_lang['s28'].'<span style="float:right;color:red"></span></td></tr>';
	showsubtitle(array($it618_credits_lang['s872'],$it618_credits_lang['s873'],$it618_credits_lang['s874'].'/'.$it618_credits_lang['s875'].'/'.$it618_credits_lang['s876'].'/'.$it618_credits_lang['s878'].'/'.$it618_credits_lang['s879'],$it618_credits_lang['s877'],$it618_credits_lang['s880']));
	
	foreach(C::t('#it618_credits#it618_credits_salepay')->fetch_all_by_search($it618sql,'id desc',$_GET['findkey'],$_GET['finduid'],$_GET['saletype'],$_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_credits_salepay) {
		
		$userstr='';
		if($it618_credits_salepay['it618_uid']>0){
			$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_salepay['it618_uid']);
			$userstr='<a href="'.it618_credits_rewriteurl($it618_credits_salepay['it618_uid']).'" target="_blank">'.$username.'</a>';
		}
		
		$payurl='';
		if($it618_credits_salepay['it618_state']==0){
			$out_trade_no=$it618_credits_salepay['it618_out_trade_no'];
			$payurl=$it618_credits_lang['s924'].' <a href="plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no.'" target="_blank">'.$it618_credits_lang['s925'].'</a>';
			$it618_time=date('Y-m-d H:i:s', $it618_credits_salepay['it618_time']);
		}else{
			$it618_time=date('Y-m-d H:i:s', $it618_credits_salepay['it618_paytime']);
		}
		
		$paystr=getpaystr($it618_credits_salepay['it618_paytype'],$it618_credits_salepay['it618_payid']);
		
		$it618_body=$it618_credits_salepay['it618_body'];
		
		if($_GET['paystate']==2){
			$tmpstr="<div style=\"width:80px\"><input class=\"checkbox\" type=\"checkbox\" id=\"id".$it618_credits_salepay['id']."\" name=\"delete[]\" value=\"".$it618_credits_salepay['id']."\" $disabled><label for=\"id".$it618_credits_salepay['id']."\">".$it618_credits_salepay['it618_saleid']."</label></div>";
		}else{
			$tmpstr='<div style="width:60px">'.$it618_credits_salepay['it618_saleid'].'</div>';
		}

		showtablerow('', array('', '', ''), array(
			$tmpstr,
			$it618_credits_salepay['it618_saletype'],
			$it618_body.'<br>'.$paystr.'<br>'.$userstr.' '.$it618_credits_salepay['it618_out_trade_no'].'<br><font color=#999>'.$it618_time.'</font>',
			'<font color=red>'.$it618_credits_salepay['it618_total_fee'].'</font> '.$it618_credits_lang['s28'].'<br>'.$payurl,
			'<div style="width:480px">'.$it618_credits_salepay['it618_client'].' '.$it618_credits_salepay['it618_plugin'].'</div>',
		));
	}
	
	if($_GET['paystate']==2){
		$tmpstr1='<input type="submit" class="btn" name="it618submit_del" value="'.$it618_credits_lang['s791'].'" onclick="return confirm(\''.$it618_credits_lang['s792'].'\')"/>';
	}

	echo '<tr><td width=58><script type="text/javascript" src="source/plugin/it618_credits/js/Calendar.js"></script><input type="checkbox" name="chkall" id="paystatechkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="paystatechkall">'.$it618_credits_lang['s120'].'</label> </td><td colspan="15">'.$tmpstr1.'<div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter();
?>