<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$sqlurl='&finduid='.$_GET['finduid'];
$sql='it618_state=1';
if($_GET['finduid']!=''){
	$sql.=' and it618_uid='.intval($_GET['finduid']);
}

if(count($reabc)!=13)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_buygroup_sale&pmod=admin_buygroup&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s577'],'it618_credits_buygroup_sale');
	showsubmit('it618sercsubmit', $it618_credits_lang['s103'], $it618_credits_lang['s104'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />');
	
	$count = DB::result_first("select count(1) from ".DB::table('it618_credits_buygroup_sale')." WHERE $sql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_buygroup_sale&pmod=admin_buygroup&operation=$operation&do=$do".$sqlurl);
	
	echo '<tr><td colspan=14>'.$it618_credits_lang['s483'].$count.'<span style="float:right;color:red"></span></td></tr>';
	showsubtitle(array($it618_credits_lang['t205'],$it618_credits_lang['t214'],$it618_credits_lang['t215'],$it618_credits_lang['t217'],$it618_credits_lang['t216']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_credits_buygroup_sale')." WHERE $sql order by id desc LIMIT $startlimit, $ppp");
	while($it618_credits_buygroup_sale = DB::fetch($query)) {
		
		if($it618_credits_buygroup_sale['it618_unit']==1)$it618_unit=$it618_credits_lang['s1021'];
		if($it618_credits_buygroup_sale['it618_unit']==2)$it618_unit=$it618_credits_lang['s1022'];
		if($it618_credits_buygroup_sale['it618_unit']==3)$it618_unit=$it618_credits_lang['s1023'];
		if($it618_credits_buygroup_sale['it618_unit']==4)$it618_unit=$it618_credits_lang['s1619'];
		
		$paystr='';
		if($it618_credits_buygroup_sale['it618_saletype']==1){
			$it618_credit='';
			for($i=1;$i<=8;$i++){
				if($it618_credits_buygroup_sale['it618_credit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
					$it618_credit.='<font color="#FF6600"><b>'.$it618_credits_buygroup_sale['it618_credit'.$i].'</b></font> '.$_G['setting']['extcredits'][$i]['title'].' + ';
				}
			}
			
			$it618_credit.='@';
			$it618_credit=str_replace(" + @","",$it618_credit);
		}else{
			$it618_credit='<font color="#FF6600"><b>'.$it618_credits_buygroup_sale['it618_price'].'</b></font> '.$it618_credits_lang['s28'];
			$paystr=getpaystr($it618_credits_buygroup_sale['it618_paytype'],$it618_credits_buygroup_sale['it618_payid']);
		}
		
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_credits_buygroup_sale['it618_groupid']);
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_buygroup_sale['it618_uid']);

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<font color=green>'.$grouptitle.'</font>',
			$it618_credit.' '.$paystr,
			'<font color=red>'.$it618_credits_buygroup_sale['it618_days'].$it618_unit.'</font>',
			'<a href="'.it618_credits_rewriteurl($it618_credits_buygroup_sale['it618_uid']).'" target="_blank">'.$username.'('.$it618_credits_buygroup_sale['it618_uid'].')</a>',
			date('Y-m-d H:i:s', $it618_credits_buygroup_sale['it618_time'])
		));
	}


	echo '<tr><td colspan=14><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter();
?>