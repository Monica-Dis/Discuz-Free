<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php';
	$transsign=md5($alipay_privatekey);
}

$btnstr='<input type="button" class="btn" value="'.it618_credits_getlang('s1275').'" onclick="trans()" /> ';

if($alipay_appid==''||$alipay_privatekey==''||$alipay_publickey==''){
	$btnstr='<font color=red>'.$it618_credits_lang['s1293'].'</font>';
}elseif($alipay_transmoney==0){
	$btnstr='<font color=red>'.$it618_credits_lang['s1294'].'</font>';
}

showtableheaders(it618_credits_getlang('s1269'),'it618_credits_sum');

	echo '<tr><td colspan="15" style="line-height:23px"><span style="float:right;">'.$it618_credits_lang['s1276'].'<br>
	<textarea style="width:100%;height:130px" id="transdatas"></textarea><br>
	<form id="transalipay">
	<input type="hidden" id="transdata" name="transdata">
	</form>
	'.$btnstr.'
	</td></tr>';

	echo '<tr><td colspan="15"><div class="fixsel">'.it618_credits_getlang('s1270').' <input id="name" class="txt" style="width:180px;margin-right:1px" /> '.it618_credits_getlang('s1279').' <input id="bz" class="txt" style="width:180px" />'.it618_credits_getlang('s1281').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> '.it618_credits_getlang('s1280').' <select id="state"><option value="0">'.$it618_credits_lang['s1282'].'</option><option value="1">'.$it618_credits_lang['s1283'].'</option><option value="2">'.$it618_credits_lang['s1284'].'</option></select> &nbsp;<input type="button" class="btn" value="'.it618_credits_getlang('s1273').'" onclick="findsalelist()" /> </div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>';
	
	showsubtitle(array(it618_credits_getlang('s1277'),it618_credits_getlang('s1278'),it618_credits_getlang('s1279'),it618_credits_getlang('s1280'),it618_credits_getlang('s1281')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_credits/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr>';

showtablefooter();

echo '
<script charset="utf-8" src="source/plugin/it618_credits/js/Calendar.js"></script>
<script charset="utf-8" src="source/plugin/it618_credits/js/jquery.js"></script>

<script>
function trans(){
	if(!confirm("'.$it618_credits_lang['s1285'].'")){
		return;
	}
	var transdatas=document.getElementById("transdatas").value;
	if(transdata==""){
		alert("'.$it618_credits_lang['s1286'].'");
		return;
	}
	
	transdatas.trim().split("\n").forEach(function(transdata, i) {
		
		if(transdata!=""){
			document.getElementById("transdata").value=transdata;
			
			IT618_CREDITS.post("'.$_G['siteurl'].'plugin.php?id=it618_credits:ajax&ac=transalipay&transsign='.$transsign.'", IT618_CREDITS("#transalipay").serialize(),function (data, textStatus){
				gettranslist(saleurl);
			}, "html");	
		}
	})
}

var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_credits:ajax";
var sqlurl="";
function gettranslist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_CREDITS.post(url+sqlurl+"&transsign='.$transsign.'", {ac:"trans_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_CREDITS("#tr_salesum").html(tmparr[0]);
	IT618_CREDITS("#tr_salelist").html(tmparr[1]);
	IT618_CREDITS("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
gettranslist(saleurl);

function findsalelist(){
	var name = document.getElementById("name").value;
	var bz = document.getElementById("bz").value;
	var state = document.getElementById("state").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&name="+name+"&bz="+bz+"&state="+state+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_credits:ajax";
	gettranslist(url);
}

function del(tid){
	IT618_CREDITS.get(saleurl+"&tid="+tid+"&transsign='.$transsign.'", {ac:"trans_del"},function (data, textStatus){
	gettranslist(saleurl);
	}, "html");	
}
</script>
';
	if(count($reabc)!=13)return;
showtablefooter();
?>