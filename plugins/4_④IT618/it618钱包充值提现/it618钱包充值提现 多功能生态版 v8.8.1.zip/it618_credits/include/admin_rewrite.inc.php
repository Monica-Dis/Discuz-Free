<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$credits_home=\''.'credits'."';\n";
		$fileData .= '$credits_wap=\''.'credits_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$credits_home1=\'-{dotype}-{ctype}'.$urltype."';\n";
		$fileData .= '$credits_wap1=\'-{dotype}-{ctype}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$credits_home=\''.str_replace("-","",it618_str($_GET['credits_home']))."';\n";
		$fileData .= '$credits_wap=\''.str_replace("-","",it618_str($_GET['credits_wap']))."';\n";
		
		$urltype=str_replace("-","",it618_str($_GET['urltype']));
		$urltype=str_replace("?","",it618_str($_GET['urltype']));
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$credits_home1=\'-{dotype}-{ctype}'.$urltype."';\n";
		$fileData .= '$credits_wap1=\'-{dotype}-{ctype}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s319'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_credits_lang['s336'].'</font></td></tr>
<tr><td colspan="3">'.$it618_credits_lang['s337'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_credits_lang['s338'].'</th><th>'.$it618_credits_lang['s339'].'</th><th>'.$it618_credits_lang['s340'].'</th></tr>
<tr class="hover">
<td>'.$it618_credits_lang['s341'].'</td><td>{dotype}, {ctype}</td><td class="longtxt"><input name="credits_home" value="'.$credits_home.'"/>'.$credits_home.$credits_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_credits_lang['s347'].'</td><td>{dotype}, {ctype}</td><td class="longtxt"><input name="credits_wap" value="'.$credits_wap.'"/>'.$credits_wap.$credits_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_credits_lang['s332']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_credits_lang['s348'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$credits_home.$urltype.'$ $1/plugin.php?id=it618_credits:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$credits_home.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_credits:do&dotype=$2&ctype=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$credits_home.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_credits:do&dotype=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$credits_wap.$urltype.'$ $1/plugin.php?id=it618_credits:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$credits_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_credits:wap&dotype=$2&ctype=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$credits_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_credits:wap&dotype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_credits_lang['s349'].'</h1>
<pre class="colorbox">
'.$it618_credits_lang['s350'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$credits_home.$urltype.'$ plugin.php?id=it618_credits:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$credits_home.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_credits:do&dotype=$1&ctype=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$credits_home.'-(.+)'.$urltype.'$ plugin.php?id=it618_credits:do&dotype=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$credits_wap.$urltype.'$ plugin.php?id=it618_credits:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$credits_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_credits:wap&dotype=$1&ctype=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$credits_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_credits:wap&dotype=$1&%1</font>

</pre>

<h1>'.$it618_credits_lang['s351'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$credits_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_credits:index&$3
RewriteRule ^(.*)/'.$credits_home.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_credits:do&dotype=$2&ctype=$3&$5
RewriteRule ^(.*)/'.$credits_home.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_credits:do&dotype=$2&$4
RewriteRule ^(.*)/'.$credits_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_credits:wap&$3
RewriteRule ^(.*)/'.$credits_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_credits:wap&dotype=$2&ctype=$3&$5
RewriteRule ^(.*)/'.$credits_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_credits:wap&dotype=$2&$4</font>

</pre>

<h1>'.$it618_credits_lang['s352'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="credits_home"&gt;
			&lt;match url="^(.*/)*'.$credits_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_credits:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="credits_home2"&gt;
			&lt;match url="^(.*/)*'.$credits_home.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_credits:do&amp;amp;dotype={R:2}&amp;amp;ctype={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="credits_home1"&gt;
			&lt;match url="^(.*/)*'.$credits_home.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_credits:do&amp;amp;dotype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="credits_wap"&gt;
			&lt;match url="^(.*/)*'.$credits_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_credits:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="credits_wap2"&gt;
			&lt;match url="^(.*/)*'.$credits_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_credits:wap&amp;amp;dotype={R:2}&amp;amp;ctype={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
				&lt;rule name="credits_wap1"&gt;
			&lt;match url="^(.*/)*'.$credits_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_credits:wap&amp;amp;dotype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$credits_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_credits:index&$2
endif
match URL into $ with ^(.*)/'.$credits_home.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_credits:do&dotype=$2&ctype=$3&$4
endif
match URL into $ with ^(.*)/'.$credits_home.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_credits:do&dotype=$2&$3
endif
match URL into $ with ^(.*)/'.$credits_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_credits:wap&$2
endif
match URL into $ with ^(.*)/'.$credits_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_credits:wap&dotype=$2&ctype=$3&$4
endif
match URL into $ with ^(.*)/'.$credits_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_credits:wap&dotype=$2&$3
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$credits_home.$urltype.'$ $1/plugin.php?id=it618_credits:index&$2 last;
rewrite ^([^\.]*)/'.$credits_home.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_credits:do&dotype=$2&ctype=$3&$4 last;
rewrite ^([^\.]*)/'.$credits_home.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_credits:do&dotype=$2&$3 last;
rewrite ^([^\.]*)/'.$credits_wap.$urltype.'$ $1/plugin.php?id=it618_credits:wap&$2 last;
rewrite ^([^\.]*)/'.$credits_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_credits:wap&dotype=$2&ctype=$3&$4 last;
rewrite ^([^\.]*)/'.$credits_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_credits:wap&dotype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=10)return;
showtablefooter();

?>