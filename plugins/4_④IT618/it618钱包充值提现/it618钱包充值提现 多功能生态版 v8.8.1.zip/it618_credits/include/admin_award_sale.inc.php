<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$sqlurl='&finduid='.$_GET['finduid'];
$sql='1';
if($_GET['finduid']!=''){
	$sql='it618_uid='.intval($_GET['finduid']);
}

if(submitcheck('it618submit_del')){
	DB::query("delete from ".DB::table('it618_credits_award_sale')." where it618_time<".($_G['timestamp']-3600*24*intval($_GET['delday'])));
	
	cpmsg($it618_credits_lang['s1617'], "action=plugins&identifier=$identifier&cp=admin_award_sale&pmod=admin_award&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

$clearsql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_credits_award_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_award_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pname` varchar(50) NOT NULL,
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

if(submitcheck('it618submit_clear')){
	runquery($clearsql);
	
	cpmsg($it618_credits_lang['s1618'], "action=plugins&identifier=$identifier&cp=admin_award_sale&pmod=admin_award&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=13)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_award_sale&pmod=admin_award&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s102'],'it618_credits_award_sale');
	
	echo '<tr><td colspan="15">
	<div style="float:right">'.$it618_credits_lang['s1610'].'<input name="delday" value="365" class="txt" style="width:40px;margin-right:3px;margin-left:3px" />'.$it618_credits_lang['s1611'].' <input type="submit" class="btn" name="it618submit_del" onclick="return confirm(\''.$it618_credits_lang['s1615'].'\')" value="'.$it618_credits_lang['s1612'].'" /> <input type="submit" class="btn" name="it618submit_clear" onclick="return confirm(\''.$it618_credits_lang['s1616'].'\')" value="'.$it618_credits_lang['s1613'].'" /></div>
	<div class="fixsel">'.$it618_credits_lang['s104'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> &nbsp;<input type="submit" class="btn" id="submit_it618sercsubmit" name="it618sercsubmit" value="'.$it618_credits_lang['s103'].'" /></div>
	</td></tr><script type="text/JavaScript">_attachEvent(document.documentElement, \'keydown\', function (e) { entersubmit(e, \'it618sercsubmit\'); });</script>';
	
	$count = DB::result_first("select count(1) from ".DB::table('it618_credits_award_sale')." WHERE $sql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_award_sale&pmod=admin_award&operation=$operation&do=$do".$sqlurl);
	
	echo '<tr><td colspan=14>'.$it618_credits_lang['s483'].$count.'<span style="float:right;color:red">'.$it618_credits_lang['s1614'].'</span></td></tr>';
	showsubtitle(array($it618_credits_lang['s484'],$it618_credits_lang['s485'],$it618_credits_lang['s486'],$it618_credits_lang['s487'],$it618_credits_lang['s488']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_credits_award_sale')." WHERE $sql order by id desc LIMIT $startlimit, $ppp");
	while($it618_credits_award_sale = DB::fetch($query)) {
		
		$it618_credit='';
		$it618_salecredit='';
		for($i=1;$i<=8;$i++){
			if($it618_credits_award_sale['it618_credit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
				$it618_credit.='<font color=red>'.$it618_credits_award_sale['it618_credit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' ';
			}
			if($it618_credits_award_sale['it618_salecredit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
				$it618_salecredit.='<font color=red>'.$it618_credits_award_sale['it618_salecredit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' ';
			}
		}
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_award_sale['it618_uid']);
		
		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<font color=#F60>'.$it618_credits_award_sale['it618_pname'].'</font>',
			$it618_credit,
			$it618_salecredit,
			'<a href="home.php?mod=space&uid='.$it618_credits_award_sale['it618_uid'].'" target="_blank">'.$username.'('.$it618_credits_award_sale['it618_uid'].')</a>',
			date('Y-m-d H:i:s', $it618_credits_award_sale['it618_time'])
		));
	}


	echo '<tr><td colspan=14><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter();
?>