<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if($_GET['it618_code']!='')$extrasql .= " AND it618_code LIKE '".addcslashes(addslashes($_GET['it618_code']),'%_')."'";
if($_GET['it618_uid']>0)$extrasql .= " AND it618_useuid = ".intval($_GET['it618_uid']);

$urlsql='&it618_bzfind='.$bzfind;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_quanuser&pmod=admin_quan&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s320'].'  <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_quan&pmod=admin_quan&operation='.$operation.'&do='.$do.'">'.$it618_credits_lang['s321'].'</a>','it618_credits_quan');
showsubmit('it618submitfind', $it618_credits_lang['s144'], $it618_credits_lang['s1055'].' <input name="it618_uid" class="txt" value="'.$_GET['it618_uid'].'" style="width:68px" />'.$it618_credits_lang['s1056'].' <input name="it618_code" value="'.$_GET['it618_code'].'" class="txt" style="width:180px" />');

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_quan')." WHERE it618_usetime>0 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_quanuser&pmod=admin_quan&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=10>'.$it618_credits_lang['s322'].$count.'</td></tr>';
	showsubtitle(array($it618_credits_lang['s147'], $it618_credits_lang['s148'],$it618_credits_lang['s149'],$it618_credits_lang['s151'],$it618_credits_lang['s323'],$it618_credits_lang['s324']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_credits_quan')." WHERE it618_usetime>0 $extrasql ORDER BY id DESC LIMIT $startlimit, $ppp");
	while($it618_credits_quan = DB::fetch($query)) {
		if($it618_credits_quan['it618_etime']==0){
			$it618_etime=$it618_credits_lang['s152'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_credits_quan['it618_etime']);
		}
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_credits_quan['it618_useuid']);
		
		if($it618_credits_quan['it618_jfid']>0){
			$cname=$_G['setting']['extcredits'][$it618_credits_quan['it618_jfid']]['title'];
			$it618_jfcount=$it618_credits_quan['it618_jfcount'];
		}else{
			$cname=$it618_credits_lang['s198'].'('.$it618_credits_lang['s223'].')';
			$it618_jfcount=$it618_credits_quan['it618_money'];
		}
		
		showtablerow('', array('', '', ''), array(
			$it618_credits_quan['it618_code'],
			'<span style="color:#F60; font-weight:bold;margin-right:1px">'.$it618_jfcount.'</span><font color="green">'.$cname.'</font>',
			$it618_etime,
			date('Y-m-d H:i:s', $it618_credits_quan['it618_addtime']),
			$username,
			date('Y-m-d H:i:s', $it618_credits_quan['it618_usetime'])
		));

	}

	echo '<tr><td colspan=10><input type=hidden value=$page name=page />'.$multipage.'</td></tr>';
	if(count($reabc)!=13)return;
showtablefooter();
?>