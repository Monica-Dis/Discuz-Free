<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php';
}

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$award_isok=\''.intval($_GET['award_isok'])."';\n";
		$fileData .= '$award_count=\''.intval($_GET['award_count'])."';\n";
		$fileData .= '$award_money=\''.floatval($_GET['award_money'])."';\n";
		$fileData .= '$award_money1=\''.floatval($_GET['award_money1'])."';\n";
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$fileData .= '$award_credit['.$i.']=\''.intval($_GET['award_credit'.$i])."';\n";
			}
		}
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s456'], "action=plugins&identifier=$identifier&cp=admin_award_set&pmod=admin_award&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_award_set&pmod=admin_award&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s457'],'it618_credits_set');

if($award_isok==1)$award_isok_checked='checked="checked"';else $award_isok_checked="";

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$it618_credit.=$_G['setting']['extcredits'][$i]['title'].'= <input type="text" class="txt" style="width:50px;color:blue" name="award_credit'.$i.'" value="'.$award_credit[$i].'">';
	}
}

echo '
<tr><td width="170">'.$it618_credits_lang['s458'].'</td><td><input type="checkbox" id="award_isok" name="award_isok" value="1" style="vertical-align:middle" '.$award_isok_checked.'> <label for="award_isok">'.$it618_credits_lang['s459'].'</label></td></tr>
<tr><td>'.$it618_credits_lang['s460'].'</td><td>'.$it618_credit.'</td></tr>
<tr><td>'.$it618_credits_lang['s461'].'</td><td><input type="text" class="txt" style="width:50px;color:red" name="award_count" value="'.$award_count.'"/>'.$it618_credits_lang['s463'].'</td></tr>
<tr><td>'.$it618_credits_lang['s462'].'</td><td>'.$it618_credits_lang['s464'].'<input type="text" class="txt" style="width:50px;color:red;margin-left:3px;margin-right:3px" name="award_money" value="'.$award_money.'"/>'.$it618_credits_lang['s465'].'</td></tr>
<tr><td>'.$it618_credits_lang['s588'].'</td><td>'.$it618_credits_lang['s464'].'<input type="text" class="txt" style="width:50px;color:red;margin-left:3px;margin-right:3px" name="award_money1" value="'.$award_money1.'"/>'.$it618_credits_lang['s465'].'</td></tr>
';

showsubmit('it618submit', $it618_credits_lang['s29']);

if(count($reabc)!=13)return;
showtablefooter();

?>