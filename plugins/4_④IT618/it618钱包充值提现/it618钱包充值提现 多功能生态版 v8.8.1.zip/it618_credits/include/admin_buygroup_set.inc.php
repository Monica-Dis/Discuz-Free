<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php';
}

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$buygroup_isok=\''.$_GET['buygroup_isok']."';\n";
		
		$fileData .= '$buygroup_saleuids=\''.$_GET['buygroup_saleuids']."';\n";
		
		$fileData .= '$buygroup_isswitch=\''.$_GET['buygroup_isswitch']."';\n";
		
		$fileData .= '$buygroup_switchabout=\''.$_GET['buygroup_switchabout']."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s456'], "action=plugins&identifier=$identifier&cp=admin_buygroup_set&pmod=admin_buygroup&operation=$operation&do=$do&page=$page", 'succeed');

}

if($buygroup_switchabout==''){
	$buygroup_switchabout=$it618_credits_lang['s790'];
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_buygroup_set&pmod=admin_buygroup&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s584'],'it618_credits_set');

if($buygroup_isok==1)$buygroup_isok_checked='checked="checked"';else $buygroup_isok_checked="";
if($buygroup_isswitch==1)$buygroup_isswitch_checked='checked="checked"';else $buygroup_isswitch_checked="";


echo '
<tr><td width="180">'.$it618_credits_lang['s585'].'</td><td><input type="checkbox" id="buygroup_isok" name="buygroup_isok" value="1" style="vertical-align:middle" '.$buygroup_isok_checked.'> <label for="buygroup_isok">'.$it618_credits_lang['s586'].'</label></td></tr>
<tr><td>'.$it618_credits_lang['s1295'].'</td><td><input type="text" class="txt" style="width:300px" name="buygroup_saleuids" value="'.$buygroup_saleuids.'">'.$it618_credits_lang['s1296'].'</td></tr>
<tr><td>'.$it618_credits_lang['s786'].'</td><td><input type="checkbox" id="buygroup_isswitch" name="buygroup_isswitch" value="1" style="vertical-align:middle" '.$buygroup_isswitch_checked.'> <label for="buygroup_isswitch">'.$it618_credits_lang['s789'].'</label></td></tr>
<tr><td>'.$it618_credits_lang['s787'].'</td><td><input type="text" name="buygroup_switchabout" value="'.$buygroup_switchabout.'" style="width:800px;margin-bottom:3px"><br>'.$it618_credits_lang['s788'].$it618_credits_lang['s790'].'</td></tr>
<tr><td>'.$it618_credits_lang['s593'].'</td><td><a href="'.ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_set&cp1=12&pmod=admin_set&operation=$operation&do=$do".'">'.$it618_credits_lang['s594'].'</a></td></tr>
';

showsubmit('it618submit', $it618_credits_lang['s29']);

if(count($reabc)!=13)return;
showtablefooter();

?>