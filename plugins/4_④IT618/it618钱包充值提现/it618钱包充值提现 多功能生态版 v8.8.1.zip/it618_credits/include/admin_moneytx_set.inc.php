<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
$it618_members = $_G['cache']['plugin']['it618_members'];

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
	$ismembers=1;
}

if(submitcheck('it618submit_alipay')){
	
	$alipay_isok=intval($_GET['alipay_isok']);
//	if($alipay_isok==1){
//		$tmpstr=dfsockopen($_G['siteurl']."source/plugin/it618_credits/trans/check.php");
//		
//		if($tmpstr!='Success'){
//			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
//			$alipay_isok=0;
//			$tmpstr='<br><br>'.$it618_credits_lang['s342'].it618_credits_utftogbk($tmpstr);
//		}else{
//			$tmpstr='';
//		}
//	}

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$alipay_isok=\''.$alipay_isok."';\n";
		$fileData .= '$alipay_adminisok=\''.intval($_GET['alipay_adminisok'])."';\n";
		$fileData .= '$alipay_txcount=\''.floatval($_GET['alipay_txcount'])."';\n";
		$fileData .= '$alipay_txmoney=\''.floatval($_GET['alipay_txmoney'])."';\n";
		$fileData .= '$alipay_txalert=\''.trim($_GET['alipay_txalert'])."';\n";
		$fileData .= '$alipay_appid=\''.trim($_GET['alipay_appid'])."';\n";
		$fileData .= '$alipay_privatekey=\''.trim($_GET['alipay_privatekey'])."';\n";
		$fileData .= '$alipay_publickey=\''.trim($_GET['alipay_publickey'])."';\n";
		$fileData .= '$alipay_transmoney=\''.floatval($_GET['alipay_transmoney'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s456'].$tmpstr, "action=plugins&identifier=$identifier&cp=admin_moneytx_set&pmod=admin_money&operation=$operation&do=$do&page=$page", 'succeed');

}

if(submitcheck('it618submit_wx')){
	$wx_isok=intval($_GET['wx_isok']);
	$wx_adminisok=intval($_GET['wx_adminisok']);
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/ajax.inc.php')){
		if($wxjk_appid!=trim($_GET['wx_appid'])){
			$wx_isok=0;
			$wx_adminisok=0;
		}
	}else{
		$wx_isok=0;
		$wx_adminisok=0;
	}

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$wx_isok=\''.$wx_isok."';\n";
		$fileData .= '$wx_adminisok=\''.$wx_adminisok."';\n";
		$fileData .= '$wx_txcount=\''.floatval($_GET['wx_txcount'])."';\n";
		$fileData .= '$wx_txmoney=\''.floatval($_GET['wx_txmoney'])."';\n";
		$fileData .= '$wx_txalert=\''.trim($_GET['wx_txalert'])."';\n";
		$fileData .= '$wx_appid=\''.trim($_GET['wx_appid'])."';\n";
		$fileData .= '$wx_mch_id=\''.trim($_GET['wx_mch_id'])."';\n";
		$fileData .= '$wx_key=\''.trim($_GET['wx_key'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s456'], "action=plugins&identifier=$identifier&cp=admin_moneytx_set&pmod=admin_money&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_moneytx_set&pmod=admin_money&operation=$operation&do=$do");

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php';
}

if($alipay_isok==1)$alipay_isok_checked='checked="checked"';else $alipay_isok_checked='';
if($alipay_adminisok==1)$alipay_adminisok_checked='checked="checked"';else $alipay_adminisok_checked='';

showtableheaders($it618_credits_lang['s1196'],'it618_credits_set');

echo '
<tr><td width="210">'.$it618_credits_lang['s1187'].'</td><td><input type="checkbox" id="alipay_isok" name="alipay_isok" value="1" style="vertical-align:middle" '.$alipay_isok_checked.'> <label for="alipay_isok">'.$it618_credits_lang['s1188'].'</font></label></td></tr>
<tr><td>'.$it618_credits_lang['s1225'].'</td><td><input type="checkbox" id="alipay_adminisok" name="alipay_adminisok" value="1" style="vertical-align:middle" '.$alipay_adminisok_checked.'> <label for="alipay_adminisok">'.$it618_credits_lang['s1226'].'</font></label></td></tr>
<tr><td>'.$it618_credits_lang['s1192'].'</td><td>'.$it618_credits_lang['s1193'].' <input type="text" class="txt" style="width:60px;margin-right:3px;color:red" name="alipay_txmoney" value="'.$alipay_txmoney.'">'.$it618_credits_lang['s1194'].'</td></tr>
<tr><td>'.$it618_credits_lang['s1189'].'</td><td>'.$it618_credits_lang['s1190'].' <input type="text" class="txt" style="width:60px;margin-right:3px;color:red" name="alipay_txcount" value="'.$alipay_txcount.'">'.$it618_credits_lang['s1191'].'</td></tr>
<tr><td>'.$it618_credits_lang['s1568'].'</td><td><input type="text" class="txt" style="width:800px;margin-right:3px;color:red;margin-bottom:3px" name="alipay_txalert" value="'.$alipay_txalert.'"><br>'.$it618_credits_lang['s1569'].'</td></tr>
<tr><td>'.$it618_credits_lang['s1195'].'</td><td><a href="'.ADMINSCRIPT.'?action=plugins&cp=admin_txtcbl&cp1=10&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'">'.$it618_credits_lang['s1029'].'</a></td></tr>
<tr><td>'.$it618_credits_lang['s1197'].'</td><td><input type="text" class="txt" style="width:300px" name="alipay_appid" value="'.$alipay_appid.'"/></td></tr>
<tr><td>'.$it618_credits_lang['s1200'].'</td><td><textarea name="alipay_publickey" style="width:800px;height:80px;margin-bottom:3px">'.$alipay_publickey.'</textarea><br><font color=#999>'.$it618_credits_lang['s1201'].'</font></td></tr>
<tr><td>'.$it618_credits_lang['s1198'].'</td><td><textarea name="alipay_privatekey" style="width:800px;height:80px;margin-bottom:3px">'.$alipay_privatekey.'</textarea><br><font color=#999>'.$it618_credits_lang['s1199'].'</font></td></tr>
<tr><td>'.$it618_credits_lang['s1290'].'</td><td><input type="text" class="txt" style="width:60px;margin-right:3px;color:red" name="alipay_transmoney" value="'.$alipay_transmoney.'">'.$it618_credits_lang['s1291'].'</td></tr>
';

showsubmit('it618submit_alipay', $it618_credits_lang['s29']);

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php';
}

if($wx_appid=='')$wx_appid=$wxjk_appid;

if($wx_isok==1)$wx_isok_checked='checked="checked"';else $wx_isok_checked='';
if($wx_adminisok==1)$wx_adminisok_checked='checked="checked"';else $wx_adminisok_checked='';

showtableheaders($it618_credits_lang['s1558'],'it618_credits_set');

echo '
<tr><td width="210">'.$it618_credits_lang['s1187'].'</td><td><input type="checkbox" id="wx_isok" name="wx_isok" value="1" style="vertical-align:middle" '.$wx_isok_checked.'> <label for="wx_isok">'.$it618_credits_lang['s1559'].'</font></label></td></tr>
<tr><td>'.$it618_credits_lang['s1225'].'</td><td><input type="checkbox" id="wx_adminisok" name="wx_adminisok" value="1" style="vertical-align:middle" '.$wx_adminisok_checked.'> <label for="wx_adminisok">'.$it618_credits_lang['s1226'].'</font></label></td></tr>
<tr><td>'.$it618_credits_lang['s1192'].'</td><td>'.$it618_credits_lang['s1193'].' <input type="text" class="txt" style="width:60px;margin-right:3px;color:red" name="wx_txmoney" value="'.$wx_txmoney.'">'.$it618_credits_lang['s1560'].'</td></tr>
<tr><td>'.$it618_credits_lang['s1189'].'</td><td>'.$it618_credits_lang['s1190'].' <input type="text" class="txt" style="width:60px;margin-right:3px;color:red" name="wx_txcount" value="'.$wx_txcount.'">'.$it618_credits_lang['s1191'].'</td></tr>
<tr><td>'.$it618_credits_lang['s1568'].'</td><td><input type="text" class="txt" style="width:800px;margin-right:3px;color:red;margin-bottom:3px" name="wx_txalert" value="'.$wx_txalert.'"><br>'.$it618_credits_lang['s1569'].'</td></tr>
<tr><td>'.$it618_credits_lang['s1195'].'</td><td><a href="'.ADMINSCRIPT.'?action=plugins&cp=admin_txtcbl&cp1=10&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'">'.$it618_credits_lang['s1029'].'</a></td></tr>
<tr><td>'.$it618_credits_lang['s93'].'</td><td><input type="text" class="txt" style="width:300px" name="wx_appid" value="'.$wx_appid.'"/></td></tr>
<tr><td>'.$it618_credits_lang['s94'].'</td><td><input type="text" class="txt" style="width:300px" name="wx_mch_id" value="'.$wx_mch_id.'"/></td></tr>
<tr><td>'.$it618_credits_lang['s95'].'</td><td><input type="text" class="txt" style="width:300px" name="wx_key" value="'.$wx_key.'"/></td></tr>
<tr><td colspan=2><font color=red>'.$it618_credits_lang['s1561'].'</font></td></tr>
';

showsubmit('it618submit_wx', $it618_credits_lang['s29']);

if(count($reabc)!=13)return;
showtablefooter();

?>