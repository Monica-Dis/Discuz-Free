<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_credits_set=C::t('#it618_credits#it618_credits_set')->fetch_by_setname($setname);

if(submitcheck('it618submit')){
	if(C::t('#it618_credits#it618_credits_set')->count_by_setname($setname)==0){
		C::t('#it618_credits#it618_credits_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $_GET[$setname]
		), true);
	}else{
		C::t('#it618_credits#it618_credits_set')->update($it618_credits_set['id'],array(
			'setvalue' => $_GET[$setname]
		));
	}

	cpmsg($it618_credits_lang['s330'], "action=plugins&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1].'<span style="font-weight:normal;color:red;margin-left:90px">'.$it618_credits_lang['s331'].'</span>','it618_credits_set');

if($setname=='homejfbottomdiy'){
	$aboutstr='<br><font color=green>'.$it618_credits_lang['s567'].'</font><br><br>';
}

if($cp1==14){
	$tmpstr='<br>'.$it618_credits_lang['s1846'];
}

echo '
<link rel="stylesheet" href="source/plugin/it618_credits/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_credits/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/plugins/code/prettify.js"></script>

<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="'.$setname.'"]\', {
			cssPath : \'source/plugin/it618_credits/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_credits/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_credits/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>


<tr><td width=800>'.$aboutstr.'<textarea name="'.$setname.'" style="width:800px;height:400px;visibility:hidden;">'.$it618_credits_set['setvalue'].'</textarea>'.$tmpstr.'</td><td valign="top">'.$it618_credits_lang['s333'].'</td></tr>
';

showsubmit('it618submit', $it618_credits_lang['s332']);
if(count($reabc)!=11)return;
showtablefooter();

?>