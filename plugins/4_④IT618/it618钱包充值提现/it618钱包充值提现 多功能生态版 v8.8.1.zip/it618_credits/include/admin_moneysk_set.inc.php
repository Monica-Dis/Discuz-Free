<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php';
}

$setname1='sksetabout';$setname2='skpayabout';
$it618_credits_set1=C::t('#it618_credits#it618_credits_set')->fetch_by_setname($setname1);
$it618_credits_set2=C::t('#it618_credits#it618_credits_set')->fetch_by_setname($setname2);

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {		
		$sk_urls=str_replace("http://","",it618_str($_GET['sk_urls']));
		$sk_urls=str_replace("https://","",$sk_urls);
		
		$fileData = '$sk_isok=\''.intval($_GET['sk_isok'])."';\n";
		$fileData .= '$sk_urls=\''.$sk_urls."';\n";
		$fileData .= '$sk_url=\''.it618_str($_GET['sk_url'])."';\n";
		$fileData .= '$sk_money=\''.floatval($_GET['sk_money'])."';\n";
		$fileData .= '$sk_zsbl=\''.floatval($_GET['sk_zsbl'])."';\n";
		$fileData .= '$sk_zsjfid=\''.intval($_GET['sk_zsjfid'])."';\n";
		$fileData .= '$sk_tcbl=\''.floatval($_GET['sk_tcbl'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	if(C::t('#it618_credits#it618_credits_set')->count_by_setname($setname1)==0){
		C::t('#it618_credits#it618_credits_set')->insert(array(
			'setname' => $setname1,
			'setvalue' => $_GET[$setname1]
		), true);
	}else{
		C::t('#it618_credits#it618_credits_set')->update($it618_credits_set1['id'],array(
			'setvalue' => $_GET[$setname1]
		));
	}
	
	if(C::t('#it618_credits#it618_credits_set')->count_by_setname($setname2)==0){
		C::t('#it618_credits#it618_credits_set')->insert(array(
			'setname' => $setname2,
			'setvalue' => $_GET[$setname2]
		), true);
	}else{
		C::t('#it618_credits#it618_credits_set')->update($it618_credits_set2['id'],array(
			'setvalue' => $_GET[$setname2]
		));
	}

	cpmsg($it618_credits_lang['s456'], "action=plugins&identifier=$identifier&cp=admin_moneysk_set&pmod=admin_money&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_moneysk_set&pmod=admin_money&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s641'],'it618_credits_set');

if($sk_isok==1)$sk_isok_checked='checked="checked"';else $sk_isok_checked="";

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$tmp.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
}
if($qf_isgold==1){
	$tmp.='<option value="11">'.$qf_goldname.'</option>';
}

$tmp1=str_replace('<option value="'.$sk_zsjfid.'">','<option value="'.$sk_zsjfid.'" selected="selected">',$tmp);

echo '
<link rel="stylesheet" href="source/plugin/it618_credits/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_credits/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/plugins/code/prettify.js"></script>

<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="'.$setname1.'"]\', {
			cssPath : \'source/plugin/it618_credits/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_credits/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_credits/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
		
		var editor1 = K.create(\'textarea[name="'.$setname2.'"]\', {
			cssPath : \'source/plugin/it618_credits/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_credits/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_credits/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
	});
</script>

<tr><td width="170">'.$it618_credits_lang['s643'].'</td><td><input type="checkbox" id="sk_isok" name="sk_isok" value="1" style="vertical-align:middle" '.$sk_isok_checked.'> <label for="sk_isok">'.$it618_credits_lang['s644'].'</label></td></tr>
<tr><td>'.$it618_credits_lang['s647'].'</td><td><input type="text" class="txt" style="width:690px;margin-bottom:3px" name="sk_urls" value="'.$sk_urls.'"><br><font color=#999>'.$it618_credits_lang['s648'].'</font></td></tr>
<tr><td>'.$it618_credits_lang['s657'].'</td><td><input type="text" class="txt" style="width:690px;margin-bottom:3px" name="sk_url" value="'.$sk_url.'"><br><font color=#999>'.$it618_credits_lang['s658'].'</font></td></tr>
<tr><td>'.$it618_credits_lang['s649'].'</td><td style="line-height:26px">'.$it618_credits_lang['s650'].'<input class="txt" type="text" style="width:50px;color:red;font-weight:bold" name="sk_money" value="'.$sk_money.'">'.$it618_credits_lang['s651'].'*<input class="txt" type="text" style="width:50px;color:red;font-weight:bold;margin-right:3px" name="sk_zsbl" value="'.$sk_zsbl.'">% '.$it618_credits_lang['s636'].' <select name="sk_zsjfid">'.$tmp1.'</select> <font color=#999>'.$it618_credits_lang['s638'].'</font>)</td></tr>
<tr><td>'.$it618_credits_lang['s1180'].'</td><td style="line-height:26px"><input class="txt" type="text" style="width:50px;color:red;font-weight:bold;margin-right:3px" name="sk_tcbl" value="'.$sk_tcbl.'">% <font color=#999>'.$it618_credits_lang['s1904'].'</font></td></tr>
<tr><td>'.$it618_credits_lang['s652'].'</td><td><textarea name="'.$setname1.'" style="width:700px;height:300px;visibility:hidden;">'.$it618_credits_set1['setvalue'].'</textarea></td></tr>
<tr><td>'.$it618_credits_lang['s653'].'</td><td><textarea name="'.$setname2.'" style="width:700px;height:300px;visibility:hidden;">'.$it618_credits_set2['setvalue'].'</textarea></td></tr>
';

showsubmit('it618submit', $it618_credits_lang['s29']);

if(count($reabc)!=13)return;
showtablefooter();

?>