<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;


$it618sql='it618_state>0';

if($_GET['creditstype']>0)$it618sql.=' and (it618_jfid1='.intval($_GET['creditstype']).' or it618_jfid2='.intval($_GET['creditstype']).')';

if($_GET['dotype']) {
	$it618_state0='';$it618_state1='';$it618_state2='';$it618_state3='';$it618_state4='';$it618_state5='';$it618_state6='';$it618_state7='';
	if($_GET['dotype']==''){$it618_state0='selected="selected"';}
	if($_GET['dotype']=='recharge'){$it618sql.=" and it618_saletype='recharge'";$it618_state1='selected="selected"';}
	if($_GET['dotype']=='zhuan'){$it618sql.= " and it618_saletype='zhuan'";$it618_state2='selected="selected"';}
	if($_GET['dotype']=='transfer'){$it618sql.=" and it618_saletype='transfer'";$it618_state3='selected="selected"';}
	if($_GET['dotype']=='tq'){$it618sql.=" and it618_saletype='tq'";$it618_state4='selected="selected"';}
	if($_GET['dotype']=='credit_plus'){$it618sql.=" and it618_saletype='credit_plus'";$it618_state5='selected="selected"';}
	if($_GET['dotype']=='credit_minus'){$it618sql.=" and it618_saletype='credit_minus'";$it618_state6='selected="selected"';}
	if($_GET['dotype']=='zy'){$it618sql.=" and it618_saletype='zy'";$it618_state7='selected="selected"';}
}

$sql='&finduid='.$_GET['finduid'].'&creditstype='.$_GET['creditstype'].'&dotype='.$_GET['dotype'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

if(submitcheck('it618submit_del')){
	$ok=0;
	if($reabc[8]!='e')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($delid);
		
		if($it618_credits_sale['it618_state']==10){
			$creditsindex=$it618_credits_sale['it618_jfid1'];
			$creditscount=$it618_credits_sale['it618_jfcount'];
			
			if($creditsindex<=8){
				C::t('common_member_count')->increase($it618_credits_sale['it618_uid1'], array(
					'extcredits'.$creditsindex => $creditscount)
				);
			}else{
				$body=$it618_credits_lang['s1602'];
				it618_credits_qianfan('write',$it618_credits_sale['it618_uid1'],10005,$creditscount,it618_credits_gbktoutf($body));
			}
			
			C::t('#it618_credits#it618_credits_sale')->delete_by_id($delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_credits_lang['s1609'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_do&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}


if(submitcheck('it618submit_ytq')){
	$ok=0;
	if($reabc[7]!='r')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($delid);
		
		if($it618_credits_sale['it618_state']==10){
			C::t('#it618_credits#it618_credits_sale')->update($it618_credits_sale['id'],array(
				'it618_state' => 1
			));
			$ok=$ok+1;
		}
	}

	cpmsg($it618_credits_lang['s1610'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_do&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=13)return;

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$creditstype.='<option value='.$i.'>'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
}
if($qf_isgold==1){
	$creditstype.='<option value=11>'.$qf_goldname.'</option>';
}
$creditstype=str_replace('<option value='.$_GET['creditstype'].'>','<option value='.$_GET['creditstype'].' selected="selected">',$creditstype);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_sale&pmod=admin_do&operation=$operation&do=$do".$sql);
showtableheaders($it618_credits_lang['s176'],'it618_credits_sale');
	showsubmit('it618sercsubmit', $it618_credits_lang['s103'], $it618_credits_lang['s104'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />'.$it618_credits_lang['s177'].' <select name="creditstype" style="margin-right:3px"><option value="0">'.$it618_credits_lang['s178'].'</option>'.$creditstype.'</select> '.$it618_credits_lang['s842'].' <select id="dotype" name="dotype" style="margin-right:3px"><option value="" '.$it618_state0.'>'.$it618_credits_lang['s178'].'</option><option value="recharge" '.$it618_state1.'>'.$it618_credits_lang['s181'].'</option><option value="zhuan" '.$it618_state2.'>'.$it618_credits_lang['s182'].'</option><option value="transfer" '.$it618_state3.'>'.$it618_credits_lang['s183'].'</option><option value="tq" '.$it618_state4.'>'.$it618_credits_lang['s1574'].'</option><option value="credit_plus" '.$it618_state5.'>'.$it618_credits_lang['s908'].'</option><option value="credit_minus" '.$it618_state6.'>'.$it618_credits_lang['s909'].'</option><option value="zy" '.$it618_state7.'>'.$it618_credits_lang['t74'].'</option></select> '.$it618_credits_lang['s190'].' <input id="it618_time1" name="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:80px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" /> - <input id="it618_time2" name="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:80px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>');
	
	$count = C::t('#it618_credits#it618_credits_sale')->count_by_search($it618sql,'',$_GET['finduid'], '', $_GET['it618_time1'], $_GET['it618_time2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_do&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=14>'.$it618_credits_lang['s188'].$count.'<span style="float:right;color:red"></span></td></tr>';
	showsubtitle(array($it618_credits_lang['s189'],$it618_credits_lang['s190']));
	
	foreach(C::t('#it618_credits#it618_credits_sale')->fetch_all_by_search($it618sql,'id desc',$_GET['finduid'], '', $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_credits_sale) {
		
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid1']);
		$userstr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid1']).'" target="_blank">'.$username.'('.$it618_credits_sale['it618_uid1'].')</a> ';
		
		$bzstr='';
		if($it618_credits_sale['it618_bz']!=''){
			$bzstr='<a href="javascript:" onclick="alert(\''.$it618_credits_sale['it618_bz'].'\')">'.$it618_credits_lang['s191'].'</a>';
		}
		
		if($it618_credits_sale['it618_saletype']=='recharge'){
			if($it618_credits_sale['it618_uid1']==$it618_credits_sale['it618_uid2']){
				$whostr=$it618_credits_lang['s192'];
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
				$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$username.'('.$it618_credits_sale['it618_uid2'].')</a>';
			}
			
			$credittitle=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];

			if($it618_credits_sale['it618_paytype']!='quan'){

				$tmphl='1 '.$credittitle.' = '.$it618_credits_sale['it618_bl'].' '.$it618_credits_lang['s28'];
				
				$paystr=getpaystr($it618_credits_sale['it618_paytype'],$it618_credits_sale['it618_payid']);
				
				$tmpstr=$userstr.$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green title="'.$tmphl.'">'.$credittitle.'</font> '.$it618_credits_lang['s197'].'<font color=red>'.$it618_credits_sale['it618_money'].'</font>'.$it618_credits_lang['s198'].'<font color=red>'.$it618_credits_sale['it618_zk'].'</font>% '.$bzstr.' '.$paystr;

			}else{
				$tmpstr=$userstr.$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s199'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$credittitle.'</font> '.$it618_credits_lang['s200'].$it618_credits_sale['it618_payid'].' '.$bzstr;
			}
		}
		
		if($it618_credits_sale['it618_saletype']=='zhuan'){
			$cname1=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
			$cname2=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid2']]['title'];
			
			$tmpstr=$userstr.$it618_credits_lang['s201'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname1.'</font>'.$it618_credits_lang['s202'].'<font color=red>'.intval($it618_credits_sale['it618_jfcount']*$it618_credits_sale['it618_bl']).'</font><font color=green>'.$cname2.'</font> '.$cname2.$it618_credits_lang['t215'].' = '.$cname1.$it618_credits_lang['t215'].'*'.floatval($it618_credits_sale['it618_bl']).' '.$bzstr;	
		}
		
		if($it618_credits_sale['it618_saletype']=='transfer'){
			$cname=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
			
			$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
			$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$username.'('.$it618_credits_sale['it618_uid2'].')</a>';
			
			$tmpstr=$userstr.$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s203'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$bzstr;	
		}
		
		if($it618_credits_sale['it618_saletype']=='tq'){
			$cname=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
			
			$tmptqarr=explode("@@@",$it618_credits_sale['it618_bank']);
			
			$chkstr='';
			if($it618_credits_sale['it618_state']==10){
				$chkstr='<input class="checkbox" type="checkbox" id="chk_del'.$it618_credits_sale['id'].'" name="delete[]" value="'.$it618_credits_sale['id'].'" '.$strcss.'><label for="chk_del'.$it618_credits_sale['id'].'">'.$it618_credits_sale['id'].'</label><input type="hidden" name="id['.$it618_credits_sale['id'].']" value="'.$it618_credits_sale['id'].'"> ';
				$state=' <font color=red>'.$it618_credits_lang['s1597'].'</font>';
			}
			if($it618_credits_sale['it618_state']==1)$state=' <font color=green>'.$it618_credits_lang['s1598'].'</font>';
			
			$tqstr=$it618_credits_lang['s1581'].$tmptqarr[0].' '.$it618_credits_lang['s1582'].$tmptqarr[1];
			
			$tmpstr=$chkstr.$userstr.$it618_credits_lang['s1574'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font>  '.$tqstr.$state.$bzstr;		
		}
		
		if($it618_credits_sale['it618_saletype']=='credit_plus'){
			$cname=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
			
			$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
			$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$username.'('.$it618_credits_sale['it618_uid2'].')</a>';
			
			$tmpstr=$it618_credits_lang['s910'].$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s908'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$bzstr;	
		}
		
		if($it618_credits_sale['it618_saletype']=='credit_minus'){
			$cname=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
			
			$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
			$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$username.'('.$it618_credits_sale['it618_uid2'].')</a>';
			
			$tmpstr=$it618_credits_lang['s910'].$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s909'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$bzstr;	
		}
		
		if($it618_credits_sale['it618_saletype']=='zy'){
			$cname=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
			$tmptitle=$it618_credits_lang['t214'].' = '.$cname.$it618_credits_lang['t215'].' * '.floatval($it618_credits_sale['it618_bl']);
			
			$tcblstr='';
			if($it618_credits_sale['it618_tcbl']>0){
				$sjmoney=$it618_credits_sale['it618_money']-round(($it618_credits_sale['it618_money']*$it618_credits_sale['it618_tcbl']/100),2);
				
				if($it618_credits_sale['it618_bank']!='')$tmptxstr=$it618_credits_lang['s574'];else $tmptxstr=$it618_credits_lang['s1012'];
					
				$tcblstr=' '.$it618_credits_lang['s573'].'<font color=red><b>'.$it618_credits_sale['it618_tcbl'].'</b></font>% '.$tmptxstr.'<font color=red><b>'.$sjmoney.'</b></font>'.$it618_credits_lang['s28'];
			}
			
			$zsjfstr='';
			if($it618_credits_sale['it618_zsjfcount']>0){
				$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_sale['it618_zsjfcount'].'</font><font color=green>'.$_G['setting']['extcredits'][$it618_credits_sale['it618_zsjfid']]['title'].'</font> ';
			}
			
			$tmpstr=$userstr.$it618_credits_lang['s201'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$it618_credits_lang['t96'].'<font color=red><b>'.$it618_credits_sale['it618_money'].'</b></font>'.$it618_credits_lang['s28'].' '.$zsjfstr.' '.$tmptitle.' '.$tcblstr.' '.$bzstr;
		}
		
		showtablerow('', array('', '', ''), array(
			$tmpstr,
			date('Y-m-d H:i:s', $it618_credits_sale['it618_time'])
		));
	}

	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type="submit" class="btn" name="it618submit_del" value="'.$it618_credits_lang['s1605'].'" onclick="return confirm(\''.$it618_credits_lang['s1607'].'\')"/> <input type="submit" class="btn" name="it618submit_ytq" value="'.$it618_credits_lang['s1606'].'" onclick="return confirm(\''.$it618_credits_lang['s1608'].'\')"/><script type="text/javascript" src="source/plugin/it618_credits/js/Calendar.js"></script><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter();
?>