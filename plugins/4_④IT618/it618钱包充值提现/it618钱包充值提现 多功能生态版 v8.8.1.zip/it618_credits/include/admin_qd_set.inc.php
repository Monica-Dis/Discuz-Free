<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php';
}

$setname='qdabout';
$it618_credits_set=C::t('#it618_credits#it618_credits_set')->fetch_by_setname($setname);

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {		
		$fileData = '$qd_isok=\''.intval($_GET['qd_isok'])."';\n";
		$fileData .= '$qd_pc=\''.it618_str($_GET['qd_pc'])."';\n";
		$fileData .= '$qd_tip=\''.it618_str($_GET['qd_tip'])."';\n";
		$fileData .= '$qd_pcauto=\''.it618_str($_GET['qd_pcauto'])."';\n";
		$fileData .= '$qd_wapauto=\''.it618_str($_GET['qd_wapauto'])."';\n";
		$fileData .= '$qd_phcount=\''.intval($_GET['qd_phcount'])."';\n";
		$fileData .= '$qd_timecount=\''.intval($_GET['qd_timecount'])."';\n";
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$fileData .= '$qd_credit1['.$i.']=\''.intval($_GET['qd_credit1'.$i])."';\n";
				$fileData .= '$qd_credit2['.$i.']=\''.intval($_GET['qd_credit2'.$i])."';\n";
			}
		}
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	if(C::t('#it618_credits#it618_credits_set')->count_by_setname($setname)==0){
		C::t('#it618_credits#it618_credits_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $_GET[$setname]
		), true);
	}else{
		C::t('#it618_credits#it618_credits_set')->update($it618_credits_set['id'],array(
			'setvalue' => $_GET[$setname]
		));
	}

	cpmsg($it618_credits_lang['s456'], "action=plugins&identifier=$identifier&cp=admin_qd_set&pmod=admin_qd&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_qd_set&pmod=admin_qd&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s490'],'it618_credits_set');

if($qd_isok==1)$qd_isok_checked='checked="checked"';else $qd_isok_checked="";
if($qd_pc==1)$qd_pc_checked='checked="checked"';else $qd_pc_checked="";
if($qd_pcauto==1)$qd_pcauto_checked='checked="checked"';else $qd_pcauto_checked="";
if($qd_wapauto==1)$qd_wapauto_checked='checked="checked"';else $qd_wapauto_checked="";

$it618_credit='<table><tr>';
for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$it618_credit.='<td>'.$_G['setting']['extcredits'][$i]['title'].'=</td><td><input type="text" class="txt" style="width:50px;color:blue" name="qd_credit1'.$i.'" value="'.$qd_credit1[$i].'"><br><input type="text" class="txt" style="width:50px;color:blue" name="qd_credit2'.$i.'" value="'.$qd_credit2[$i].'"></td>';
	}
}
$it618_credit.='</tr></table>';

if($qd_tip=='')$qd_tip=$it618_credits_lang['s535'];
if($qd_phcount=='')$qd_phcount=50;

echo '
<link rel="stylesheet" href="source/plugin/it618_credits/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_credits/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/plugins/code/prettify.js"></script>

<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="'.$setname.'"]\', {
			cssPath : \'source/plugin/it618_credits/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_credits/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_credits/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>

<tr><td width="170">'.$it618_credits_lang['s530'].'</td><td><input type="checkbox" id="qd_isok" name="qd_isok" value="1" style="vertical-align:middle" '.$qd_isok_checked.'> <label for="qd_isok">'.$it618_credits_lang['s533'].'</label></td></tr>
<tr><td>'.$it618_credits_lang['s531'].'</td><td><input type="checkbox" id="qd_pc" name="qd_pc" value="1" style="vertical-align:middle" '.$qd_pc_checked.'> <label for="qd_pc">'.$it618_credits_lang['s532'].'</label> '.$it618_credits_lang['s543'].'<input type="text" class="txt" style="width:350px;" name="qd_tip" value="'.$qd_tip.'"></td></tr>
<tr><td>'.$it618_credits_lang['s1341'].'</td><td><input type="checkbox" id="qd_pcauto" name="qd_pcauto" value="1" style="vertical-align:middle" '.$qd_pcauto_checked.'> <label for="qd_pcauto">'.$it618_credits_lang['s1342'].'</label></td></tr>
<tr><td>'.$it618_credits_lang['s1343'].'</td><td><input type="checkbox" id="qd_wapauto" name="qd_wapauto" value="1" style="vertical-align:middle" '.$qd_wapauto_checked.'> <label for="qd_wapauto">'.$it618_credits_lang['s1344'].'</label></td></tr>
<tr><td>'.$it618_credits_lang['s541'].'</td><td><input type="text" class="txt" style="width:50px;color:red" name="qd_timecount" value="'.$qd_timecount.'">'.$it618_credits_lang['s542'].'</td></tr>
<tr><td>'.$it618_credits_lang['s562'].'</td><td><input type="text" class="txt" style="width:50px;" name="qd_phcount" value="'.$qd_phcount.'">'.$it618_credits_lang['s563'].'</td></tr>
<tr><td>'.$it618_credits_lang['s492'].'</td><td>'.$it618_credit.'<font color=red>'.$it618_credits_lang['s534'].'</font></td></tr>
<tr><td>'.$it618_credits_lang['s493'].'</td><td><textarea name="'.$setname.'" style="width:700px;height:400px;visibility:hidden;">'.$it618_credits_set['setvalue'].'</textarea></td></tr>
';

showsubmit('it618submit', $it618_credits_lang['s29']);

if(count($reabc)!=13)return;
showtablefooter();

?>