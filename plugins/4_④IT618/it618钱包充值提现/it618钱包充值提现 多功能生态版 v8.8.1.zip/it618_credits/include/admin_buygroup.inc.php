<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if(submitcheck('it618submit')){

	if(is_array($_GET['it618_price'])) {
		foreach($_GET['it618_price'] as $id => $val) {
			
				C::t('#it618_credits#it618_credits_buygroup')->update($id,array(
					'it618_price' => $_GET['it618_price'][$id],
					'it618_credit1' => $_GET['it618_credit1'][$id],
					'it618_credit2' => $_GET['it618_credit2'][$id],
					'it618_credit3' => $_GET['it618_credit3'][$id],
					'it618_credit4' => $_GET['it618_credit4'][$id],
					'it618_credit5' => $_GET['it618_credit5'][$id],
					'it618_credit6' => $_GET['it618_credit6'][$id],
					'it618_credit7' => $_GET['it618_credit7'][$id],
					'it618_credit8' => $_GET['it618_credit8'][$id],
					'it618_days1' => $_GET['it618_days1'][$id],
					'it618_days2' => $_GET['it618_days2'][$id],
					'it618_days3' => $_GET['it618_days3'][$id],
					'it618_unit' => $_GET['it618_unit'][$id],
					'it618_isok' => $_GET['it618_isok'][$id],
					'it618_order' => $_GET['it618_order'][$id]
				));
		}
	}

	cpmsg($it618_credits_lang['s25'], "action=plugins&identifier=$identifier&cp=admin_buygroup&pmod=admin_buygroup&operation=$operation&do=$do", 'succeed');
}

if(count($reabc)!=13)return;
if(submitcheck('it618daosubmit')) {
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup')." where radminid=0 and type='special' order by groupid");
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_buygroup')." WHERE it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_credits#it618_credits_buygroup')->insert(array(
				'it618_groupid' => $common_usergroup['groupid']
			), true);
		}
	}
}

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_buygroup'))==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup')." where radminid=0 and type='special' order by groupid");
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_buygroup')." WHERE it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_credits#it618_credits_buygroup')->insert(array(
				'it618_groupid' => $common_usergroup['groupid']
			), true);
		}
	}	
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_buygroup&pmod=admin_buygroup&operation=$operation&do=$do");

showtableheaders($it618_credits_lang['s576'],'it618_credits_buygroup');
	showsubmit('it618daosubmit', $it618_credits_lang['s583']);
	if($reabc[5]!='_')return;
	
	echo '<tr><td colspan=10 style="line-height:23px;color:blue">'.$it618_credits_lang['s1231'].'</td></tr>';
	
	$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_buygroup'));
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_buygroup&pmod=admin_buygroup&operation=$operation&do=$do&page=$page".$sql);
	echo '<style>.hover td{line-height:26px}</style><tr><td colspan=10>'.$it618_credits_lang['s126'].$count.'<span style="float:right;">'.$it618_credits_lang['s581'].'</span></td></tr>';

	showsubtitle(array($it618_credits_lang['s128'],$it618_credits_lang['s578'],$it618_credits_lang['s1020'],$it618_credits_lang['s579'],$it618_credits_lang['s1624'],$it618_credits_lang['s580']));

	$query = DB::query("SELECT * FROM ".DB::table('it618_credits_buygroup')." order by it618_isok desc,it618_order LIMIT $startlimit, $ppp");
	while($it618_credits_buygroup =	DB::fetch($query)) {
		
		if($it618_credits_buygroup['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		if($reabc[1]!='t')return;
		
		$pricestr=$it618_credits_lang['s1017'].'<input type="text" class="txt" style="width:60px;margin-right:3px;color:red" name="it618_price['.$it618_credits_buygroup['id'].']" value="'.$it618_credits_buygroup['it618_price'].'">'.$it618_credits_lang['s28'].'<br>'.$it618_credits_lang['s1018'];
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$pricestr.='<input type="text" class="txt" style="width:40px;margin-right:3px;color:blue" name="it618_credit'.$i.'['.$it618_credits_buygroup['id'].']" value="'.$it618_credits_buygroup['it618_credit'.$i].'">'.$_G['setting']['extcredits'][$i]['title'].' ';
			}
		}
		
		if(DB::result_first("select count(1) from ".DB::table('common_usergroup')." where groupid=".$it618_credits_buygroup['it618_groupid'])>0){
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_credits_buygroup['it618_groupid']);
		}else{
			DB::query("delete FROM ".DB::table('it618_credits_buygroup')." where id=".$it618_credits_buygroup['id']);
		}
		
		if($it618_credits_buygroup['it618_unit']==1)$it618_unit1_selected='selected="selected"';else $it618_unit1_selected="";
		if($it618_credits_buygroup['it618_unit']==2)$it618_unit2_selected='selected="selected"';else $it618_unit2_selected="";
		if($it618_credits_buygroup['it618_unit']==3)$it618_unit3_selected='selected="selected"';else $it618_unit3_selected="";
		if($it618_credits_buygroup['it618_unit']==4)$it618_unit4_selected='selected="selected"';else $it618_unit4_selected="";
		
		$tmpcss='display:none';
		if($it618_credits_buygroup['it618_unit']!=4){
			$tmpprice=$it618_credits_lang['s621'];
			$tmpprice=str_replace("{input1}",'<input type="text" class="txt" style="width:40px;margin-right:1px;color:green" name="it618_days1['.$it618_credits_buygroup['id'].']" value="'.$it618_credits_buygroup['it618_days1'].'">',$tmpprice);
			$tmpprice=str_replace("{input2}",'<input type="text" class="txt" style="width:40px;margin-right:1px;color:green" name="it618_days2['.$it618_credits_buygroup['id'].']" value="'.$it618_credits_buygroup['it618_days2'].'">',$tmpprice);
			$tmpprice=str_replace("{input3}",'<input type="text" class="txt" style="width:40px;margin-right:1px;color:green" name="it618_days3['.$it618_credits_buygroup['id'].']" value="'.$it618_credits_buygroup['it618_days3'].'">',$tmpprice);
			$tmpcss='display:';
		}
		
		showtablerow('', array('class="td28"', '', ''), array(
			$grouptitle."<input type=\"hidden\" name=\"id[".$it618_credits_buygroup['id']."]\" value=\"".$it618_credits_buygroup['id']."\">",
			$pricestr.'<br><span id="priceset" '.$tmpcss.'>'.$tmpprice.'</span>',
			'<select name="it618_unit['.$it618_credits_buygroup['id'].']"><option value=1 '.$it618_unit1_selected.'>'.$it618_credits_lang['s1021'].'</option><option value=2 '.$it618_unit2_selected.'>'.$it618_credits_lang['s1022'].'</option><option value=3 '.$it618_unit3_selected.'>'.$it618_credits_lang['s1023'].'</option><option value=4 '.$it618_unit4_selected.'>'.$it618_credits_lang['s1619'].'</option></select>',
			'<input class="checkbox" type="checkbox" id="isok'.$it618_credits_buygroup['id'].'" name="it618_isok['.$it618_credits_buygroup['id'].']" '.$it618_isok_checked.' value="1"><label for="isok'.$it618_credits_buygroup['id'].'">'.$it618_credits_lang['s582'].'</label>',
			"<input type=\"text\" class=\"txt\" style=\"width:30px\" name=\"it618_order[".$it618_credits_buygroup['id']."]\" value=\"".$it618_credits_buygroup['it618_order']."\">",
		));
	}
	
	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type="submit" class="btn" name="it618submit" value="'.$it618_credits_lang['s130'].'"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	showtablefooter();
?>