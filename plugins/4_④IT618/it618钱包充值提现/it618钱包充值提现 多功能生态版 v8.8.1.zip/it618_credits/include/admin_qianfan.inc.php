<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
}

//10000 ͬ����Ա
//10001 ���߳�ֵ
//10002 ��ֵȯ��ֵ 
//10003 ��ֵ���� 
//10004 ת�� 
//10005 ת�� 
//10006 ���� 
//10007 ת�� 
//10008 ת������
//10009 ����ֵ����
//10010 ����տ�����

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$qf_goldname=trim($_GET['qf_goldname']);
		if($qf_goldname=='')$qf_goldname=$it618_credits_lang['s1246'];
		
		$fileData = '$qf_hostname=\''.trim($_GET['qf_hostname'])."';\n";
		$fileData .= '$qf_secret=\''.trim($_GET['qf_secret'])."';\n";
		$fileData .= '$qf_isgold=\''.trim($_GET['qf_isgold'])."';\n";
		$fileData .= '$qf_goldname=\''.$qf_goldname."';\n";
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s1247'], "action=plugins&identifier=$identifier&cp=admin_qianfan&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

if($qf_goldname=='')$qf_goldname=$it618_credits_lang['s1246'];

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_qianfan&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

if($qf_isgold==1)$check_qf_isgold='checked="checked"';else $check_qf_isgold='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr class="header"><th width=180>'.$it618_credits_lang['s1239'].'</th><th width=360>'.$it618_credits_lang['s1241'].'</th><th>'.$it618_credits_lang['s1240'].'</th></tr>

<tr class="hover">
<td>'.$it618_credits_lang['s1244'].'</td><td class="longtxt"><input name="qf_hostname" value="'.$qf_hostname.'" style="width:300px" /></td>
<td>'.$it618_credits_lang['s1245'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_credits_lang['s1242'].'</td><td class="longtxt"><input name="qf_secret" value="'.$qf_secret.'" style="width:300px" /></td>
<td>'.$it618_credits_lang['s1243'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_credits_lang['s1235'].'</td><td class="longtxt"><input type="checkbox" name="qf_isgold" value=1 '.$check_qf_isgold.'></td>
<td>'.$it618_credits_lang['s1236'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_credits_lang['s1237'].'</td><td class="longtxt"><input name="qf_goldname" value="'.$qf_goldname.'" style="width:300px" /></td>
<td>'.$it618_credits_lang['s1238'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_credits_lang['s1248']);

if(count($reabc)!=11)return;
showtablefooter();

?>