<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_magapp/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_magapp/config.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_alif2f/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_alif2f/config.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php';
}

if(submitcheck('it618submit_alipay')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$alipay_isok=\''.intval($_GET['alipay_isok'])."';\n";
		$fileData .= '$seller_email=\''.it618_str($_GET['seller_email'])."';\n";
		$fileData .= '$partner=\''.it618_str($_GET['partner'])."';\n";
		$fileData .= '$key=\''.it618_str($_GET['key'])."';\n";
		$fileData .= '$hbfq=\''.it618_str($_GET['hbfq'])."';\n";
		$fileData .= '$alipay_iswx=\''.intval($_GET['alipay_iswx'])."';\n";
		$fileData .= '$alipay_checked=\''.intval($_GET['alipay_checked'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s87'], "action=plugins&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');

}

if(submitcheck('it618submit_wx')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		$fileData = '$wx_isok=\''.intval($_GET['wx_isok'])."';\n";
		$fileData .= '$wx_iscode=\''.it618_str($_GET['wx_iscode'])."';\n";
		$fileData .= '$wx_appid=\''.it618_str($_GET['wx_appid'])."';\n";
		$fileData .= '$wx_mch_id=\''.it618_str($_GET['wx_mch_id'])."';\n";
		$fileData .= '$wx_key=\''.it618_str($_GET['wx_key'])."';\n";
		$fileData .= '$wx_secret=\''.it618_str($_GET['wx_secret'])."';\n";
		$fileData .= '$wx_domain=\''.it618_str($_GET['wx_domain'])."';\n";
		$fileData .= '$wx_getcodeurl=\''.it618_str($_GET['wx_getcodeurl'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s88'], "action=plugins&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');

}

if(submitcheck('it618submit_wxh5')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$wxh5_isok=\''.intval($_GET['wxh5_isok'])."';\n";
		$fileData .= '$wxh5_appid=\''.it618_str($_GET['wxh5_appid'])."';\n";
		$fileData .= '$wxh5_mch_id=\''.it618_str($_GET['wxh5_mch_id'])."';\n";
		$fileData .= '$wxh5_key=\''.it618_str($_GET['wxh5_key'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s919'], "action=plugins&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');

}

if(submitcheck('it618submit_wxapp')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$wxapp_isok=\''.intval($_GET['wxapp_isok'])."';\n";
		$fileData .= '$wxapp_appid=\''.it618_str($_GET['wxapp_appid'])."';\n";
		$fileData .= '$wxapp_mch_id=\''.it618_str($_GET['wxapp_mch_id'])."';\n";
		$fileData .= '$wxapp_key=\''.it618_str($_GET['wxapp_key'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s631'], "action=plugins&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');

}

if(submitcheck('it618submit_magapp')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_magapp/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$magapp_isok=\''.intval($_GET['magapp_isok'])."';\n";
		$fileData .= '$magapp_url=\''.it618_str($_GET['magapp_url'])."';\n";
		$fileData .= '$magapp_secret=\''.it618_str($_GET['magapp_secret'])."';\n";
		$fileData .= '$magapp_isqbmoney=\''.intval($_GET['magapp_isqbmoney'])."';\n";
		$fileData .= '$magapp_ismagpay=\''.intval($_GET['magapp_ismagpay'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s990'], "action=plugins&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');

}

if(submitcheck('it618submit_alif2f')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_alif2f/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$alif2f_isok=\''.intval($_GET['alif2f_isok'])."';\n";
		$fileData .= '$alif2f_appid=\''.it618_str($_GET['alif2f_appid'])."';\n";
		$fileData .= '$alif2f_publickey=\''.it618_str($_GET['alif2f_publickey'])."';\n";
		$fileData .= '$alif2f_privatekey=\''.it618_str($_GET['alif2f_privatekey'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s1076'], "action=plugins&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');

}

if(submitcheck('it618submit_payjs')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$payjs_mchid=\''.it618_str($_GET['payjs_mchid'])."';\n";
		$fileData .= '$payjs_key=\''.it618_str($_GET['payjs_key'])."';\n";
		$fileData .= '$payjs_alimchid=\''.it618_str($_GET['payjs_alimchid'])."';\n";
		$fileData .= '$payjs_alikey=\''.it618_str($_GET['payjs_alikey'])."';\n";
		$fileData .= '$payjs_istowx=\''.it618_str($_GET['payjs_istowx'])."';\n";
		$fileData .= '$payjs_istowxh5=\''.it618_str($_GET['payjs_istowxh5'])."';\n";
		$fileData .= '$payjs_istowxcode=\''.it618_str($_GET['payjs_istowxcode'])."';\n";
		$fileData .= '$payjs_istoalipay=\''.it618_str($_GET['payjs_istoalipay'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s1310'], "action=plugins&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');

}

if(submitcheck('it618submit_precode')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$precode_apiurl=\''.it618_str($_GET['precode_apiurl'])."';\n";
		$fileData .= '$precode_mchid=\''.it618_str($_GET['precode_mchid'])."';\n";
		$fileData .= '$precode_key=\''.it618_str($_GET['precode_key'])."';\n";
		$fileData .= '$precode_about=\''.it618_str($_GET['precode_about'])."';\n";
		$fileData .= '$precode_istowx=\''.it618_str($_GET['precode_istowx'])."';\n";
		$fileData .= '$precode_istoalipay=\''.it618_str($_GET['precode_istoalipay'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_credits_lang['s999'], "action=plugins&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s89'].'<span style="float:right;font-weight:normal"></span>','it618_credits_set');

if($alipay_isok==1)$alipay_isok_checked='checked="checked"';else $alipay_isok_checked="";
if($alipay_iswx==1)$alipay_iswx_checked='checked="checked"';else $alipay_iswx_checked="";
if($alipay_checked==1)$alipay_checked_checked='checked="checked"';else $alipay_checked_checked="";

echo '
<tr><td width="270">'.$it618_credits_lang['s90'].'</td><td><input type="checkbox" id="alipay_isok" name="alipay_isok" value="1" style="vertical-align:middle" '.$alipay_isok_checked.'> <label for="alipay_isok">'.$it618_credits_lang['s91'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s83'].'</td><td>'.$it618_credits_lang['s99'].'</td></tr>
<tr><td width="270">'.$it618_credits_lang['s84'].'</td><td><input type="text" class="txt" style="width:300px" name="seller_email" value="'.$seller_email.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s85'].'</td><td><input type="text" class="txt" style="width:300px" name="partner" value="'.$partner.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s86'].'</td><td><input type="text" class="txt" style="width:300px" name="key" value="'.$key.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1321'].'</td><td><input type="text" class="txt" style="width:80px" name="hbfq" value="'.$hbfq.'"/>'.$it618_credits_lang['s1322'].'</td></tr>
<tr><td width="270">'.$it618_credits_lang['s849'].'</td><td><input type="checkbox" id="alipay_iswx" name="alipay_iswx" value="1" style="vertical-align:middle" '.$alipay_iswx_checked.'> <label for="alipay_iswx">'.$it618_credits_lang['s850'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s851'].'</td><td><input type="checkbox" id="alipay_checked" name="alipay_checked" value="1" style="vertical-align:middle" '.$alipay_checked_checked.'> <label for="alipay_checked">'.$it618_credits_lang['s852'].'</label></td></tr>
';

showsubmit('it618submit_alipay', $it618_credits_lang['s29']);


showtableheaders($it618_credits_lang['s98'].'<span style="float:right;font-weight:normal"></span>','it618_credits_set');

if($wx_isok==1)$wx_isok_checked='checked="checked"';else $wx_isok_checked="";
if($wx_iscode==1)$wx_iscode_checked='checked="checked"';else $wx_iscode_checked="";

echo '
<tr><td width="270">'.$it618_credits_lang['s90'].'</td><td><input type="checkbox" id="wx_isok" name="wx_isok" value="1" style="vertical-align:middle" '.$wx_isok_checked.'> <label for="wx_isok">'.$it618_credits_lang['s92'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1354'].'</td><td><input type="checkbox" id="wx_iscode" name="wx_iscode" value="1" style="vertical-align:middle" '.$wx_iscode_checked.'> <label for="wx_iscode">'.$it618_credits_lang['s1355'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s93'].'</td><td><input type="text" class="txt" style="width:300px" name="wx_appid" value="'.$wx_appid.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s94'].'</td><td><input type="text" class="txt" style="width:300px" name="wx_mch_id" value="'.$wx_mch_id.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s95'].'</td><td><input type="text" class="txt" style="width:300px" name="wx_key" value="'.$wx_key.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s96'].'</td><td><input type="text" class="txt" style="width:300px" name="wx_secret" value="'.$wx_secret.'"/></td></tr>
<tr style="display:none"><td width="270">'.$it618_credits_lang['s992'].'</td><td><input type="text" class="txt" style="width:300px;margin-bottom:3px" name="wx_domain" value="'.$wx_domain.'"/><font color=#999>'.$it618_credits_lang['s991'].'</font></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1306'].'</td><td><input type="text" class="txt" style="width:300px;margin-bottom:3px" name="wx_getcodeurl" value="'.$wx_getcodeurl.'"/><br><font color=#999>'.$it618_credits_lang['s1307'].'</font></td></tr>
<tr><td colspan=2>'.$it618_credits_lang['s97'].'</td></tr>
';

showsubmit('it618submit_wx', $it618_credits_lang['s29']);

showtableheaders($it618_credits_lang['s914'].'<span style="float:right;font-weight:normal"></span>','it618_credits_set');

if($wxh5_isok==1)$wxh5_isok_checked='checked="checked"';else $wxh5_isok_checked="";

echo '
<tr><td width="270">'.$it618_credits_lang['s90'].'</td><td><input type="checkbox" id="wxh5_isok" name="wxh5_isok" value="1" style="vertical-align:middle" '.$wxh5_isok_checked.'> <label for="wxh5_isok">'.$it618_credits_lang['s915'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s93'].'</td><td><input type="text" class="txt" style="width:300px" name="wxh5_appid" value="'.$wxh5_appid.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s94'].'</td><td><input type="text" class="txt" style="width:300px" name="wxh5_mch_id" value="'.$wxh5_mch_id.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s95'].'</td><td><input type="text" class="txt" style="width:300px" name="wxh5_key" value="'.$wxh5_key.'"/></td></tr>
<tr><td colspan=2>'.$it618_credits_lang['s916'].'</td></tr>
';

showsubmit('it618submit_wxh5', $it618_credits_lang['s29']);

showtableheaders($it618_credits_lang['s626'].'<span style="float:right;font-weight:normal"></span>','it618_credits_set');

if($wxapp_isok==1)$wxapp_isok_checked='checked="checked"';else $wxapp_isok_checked="";

echo '
<tr><td width="270">'.$it618_credits_lang['s90'].'</td><td><input type="checkbox" id="wxapp_isok" name="wxapp_isok" value="1" style="vertical-align:middle" '.$wxapp_isok_checked.'> <label for="wxapp_isok">'.$it618_credits_lang['s627'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s628'].'</td><td><input type="text" class="txt" style="width:300px" name="wxapp_appid" value="'.$wxapp_appid.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s629'].'</td><td><input type="text" class="txt" style="width:300px" name="wxapp_mch_id" value="'.$wxapp_mch_id.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s630'].'</td><td><input type="text" class="txt" style="width:300px" name="wxapp_key" value="'.$wxapp_key.'"/></td></tr>
';

showsubmit('it618submit_wxapp', $it618_credits_lang['s29']);

showtableheaders($it618_credits_lang['s986'].'<span style="float:right;font-weight:normal"></span>','it618_credits_set');

if($magapp_isok==1)$magapp_isok_checked='checked="checked"';else $magapp_isok_checked="";
if($magapp_isqbmoney==1)$magapp_isqbmoney_checked='checked="checked"';else $magapp_isqbmoney_checked="";
if($magapp_ismagpay==1)$magapp_ismagpay_checked='checked="checked"';else $magapp_ismagpay_checked="";

echo '
<tr><td width="270">'.$it618_credits_lang['s90'].'</td><td><input type="checkbox" id="magapp_isok" name="magapp_isok" value="1" style="vertical-align:middle" '.$magapp_isok_checked.'> <label for="magapp_isok">'.$it618_credits_lang['s987'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s988'].'</td><td><input type="text" class="txt" style="width:300px" name="magapp_url" value="'.$magapp_url.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s989'].'</td><td><input type="text" class="txt" style="width:300px" name="magapp_secret" value="'.$magapp_secret.'"/></td></tr>
<tr><td>'.$it618_credits_lang['s1334'].'</td><td><input type="checkbox" id="magapp_isqbmoney" name="magapp_isqbmoney" value="1" style="vertical-align:middle" '.$magapp_isqbmoney_checked.'> <label for="magapp_isqbmoney">'.$it618_credits_lang['s1335'].'</label></td></tr>
<tr><td>'.$it618_credits_lang['s1336'].'</td><td><input type="checkbox" id="magapp_ismagpay" name="magapp_ismagpay" value="1" style="vertical-align:middle" '.$magapp_ismagpay_checked.'> <label for="magapp_ismagpay">'.$it618_credits_lang['s1337'].'</label></td></tr>
';

showsubmit('it618submit_magapp', $it618_credits_lang['s29']);


showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_pay&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($it618_credits_lang['s1071'].'<span style="float:right;font-weight:normal"></span>','it618_credits_set');

if($alif2f_isok==1)$alif2f_isok_checked='checked="checked"';else $alif2f_isok_checked="";

echo '
<tr><td width="270">'.$it618_credits_lang['s90'].'</td><td><input type="checkbox" id="alif2f_isok" name="alif2f_isok" value="1" style="vertical-align:middle" '.$alif2f_isok_checked.'> <label for="alif2f_isok">'.$it618_credits_lang['s1072'].'</label></td></tr>
<tr><td>'.$it618_credits_lang['s1073'].'</td><td><input type="text" class="txt" style="width:300px" name="alif2f_appid" value="'.$alif2f_appid.'"/></td></tr>
<tr><td>'.$it618_credits_lang['s1074'].'</td><td><textarea name="alif2f_publickey" style="width:800px;height:80px;margin-bottom:3px">'.$alif2f_publickey.'</textarea><br><font color=#999>'.$it618_credits_lang['s1201'].'</font></td></tr>
<tr><td>'.$it618_credits_lang['s1075'].'</td><td><textarea name="alif2f_privatekey" style="width:800px;height:80px;margin-bottom:3px">'.$alif2f_privatekey.'</textarea><br><font color=#999>'.$it618_credits_lang['s1199'].'</font></td></tr>
<tr><td colspan="2" style="color:red">'.$it618_credits_lang['s1077'].'</td></tr>
';

showsubmit('it618submit_alif2f', $it618_credits_lang['s29']);

showtableheaders($it618_credits_lang['s1351'].'<span style="float:right;font-weight:normal"></span>','it618_credits_set');

if($precode_istowx==1)$precode_istowx_checked='checked="checked"';else $precode_istowx_checked="";
if($precode_istoalipay==1)$precode_istoalipay_checked='checked="checked"';else $precode_istoalipay_checked="";
if($precode_about=='')$precode_about=$it618_credits_lang['s1360'];

echo '
<tr><td width="270">'.$it618_credits_lang['s1313'].'</td><td><input type="checkbox" id="precode_istowx" name="precode_istowx" value="1" style="vertical-align:middle" '.$precode_istowx_checked.'> <label for="precode_istowx">'.$it618_credits_lang['s1314'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1315'].'</td><td><input type="checkbox" id="precode_istoalipay" name="precode_istoalipay" value="1" style="vertical-align:middle" '.$precode_istoalipay_checked.'> <label for="precode_istoalipay">'.$it618_credits_lang['s1316'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1361'].'</td><td><input type="text" class="txt" style="width:300px" name="precode_apiurl" value="'.$precode_apiurl.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1352'].'</td><td><input type="text" class="txt" style="width:300px" name="precode_mchid" value="'.$precode_mchid.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1353'].'</td><td><input type="text" class="txt" style="width:300px" name="precode_key" value="'.$precode_key.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1358'].'</td><td><input type="text" class="txt" style="width:300px" name="precode_about" value="'.$precode_about.'"/> '.$it618_credits_lang['s1359'].'</td></tr>
';

showsubmit('it618submit_precode', $it618_credits_lang['s29']);

showtableheaders($it618_credits_lang['s1308'].'<span style="float:right;font-weight:normal"></span>','it618_credits_set');

if($payjs_isok==1)$payjs_isok_checked='checked="checked"';else $payjs_isok_checked="";
if($payjs_istowx==1)$payjs_istowx_checked='checked="checked"';else $payjs_istowx_checked="";
if($payjs_istowxh5==1)$payjs_istowxh5_checked='checked="checked"';else $payjs_istowxh5_checked="";
if($payjs_istowxcode==1)$payjs_istowxcode_checked='checked="checked"';else $payjs_istowxcode_checked="";
if($payjs_istoalipay==1)$payjs_istoalipay_checked='checked="checked"';else $payjs_istoalipay_checked="";

echo '
<tr><td width="270"></td><td>'.$it618_credits_lang['s618'].'</td></tr>

<tr><td width="270">'.$it618_credits_lang['s1313'].'</td><td><input type="checkbox" id="payjs_istowx" name="payjs_istowx" value="1" style="vertical-align:middle" '.$payjs_istowx_checked.'> <label for="payjs_istowx">'.$it618_credits_lang['s1314'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1354'].'</td><td><input type="checkbox" id="payjs_istowxcode" name="payjs_istowxcode" value="1" style="vertical-align:middle" '.$payjs_istowxcode_checked.'> <label for="payjs_istowxcode">'.$it618_credits_lang['s1355'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1356'].'</td><td><input type="checkbox" id="payjs_istowxh5" name="payjs_istowxh5" value="1" style="vertical-align:middle" '.$payjs_istowxh5_checked.'> <label for="payjs_istowxh5">'.$it618_credits_lang['s1357'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s997'].'</td><td><input type="text" class="txt" style="width:300px" name="payjs_mchid" value="'.$payjs_mchid.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s998'].'</td><td><input type="text" class="txt" style="width:300px" name="payjs_key" value="'.$payjs_key.'"/></td></tr>

<tr><td width="270">'.$it618_credits_lang['s1315'].'</td><td><input type="checkbox" id="payjs_istoalipay" name="payjs_istoalipay" value="1" style="vertical-align:middle" '.$payjs_istoalipay_checked.'> <label for="payjs_istoalipay">'.$it618_credits_lang['s1316'].'</label></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1348'].'</td><td><input type="text" class="txt" style="width:300px" name="payjs_alimchid" value="'.$payjs_alimchid.'"/></td></tr>
<tr><td width="270">'.$it618_credits_lang['s1349'].'</td><td><input type="text" class="txt" style="width:300px" name="payjs_alikey" value="'.$payjs_alikey.'"/></td></tr>
';

showsubmit('it618submit_payjs', $it618_credits_lang['s29']);

echo '<table><tr><td colspan=2>'.$it618_credits_lang['s1350'].'</td></tr></table>';

if(count($reabc)!=13)return;
showtablefooter();

?>