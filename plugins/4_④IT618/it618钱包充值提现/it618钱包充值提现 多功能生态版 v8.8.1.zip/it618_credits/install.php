<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_credits_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_moneytxtcbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_moneytxtcbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_num1` float(9,2) NOT NULL,
  `it618_num2` float(9,2) NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_moneycztmp`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_moneycztmp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_money1` float(9,2) NOT NULL,
  `it618_zsjfid` int(10) unsigned NOT NULL,
  `it618_zsjfcount` int(10) unsigned NOT NULL,
  `it618_zsbl` float(9,2) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_paytype` varchar(20) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_czyfmoney` float(9,2) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_moneysktmp`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_moneysktmp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_money1` float(9,2) NOT NULL,
  `it618_zsjfid` int(10) unsigned NOT NULL,
  `it618_zsjfcount` int(10) unsigned NOT NULL,
  `it618_zsbl` float(9,2) NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL,
  `it618_zsuid` int(10) unsigned NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_paytype` varchar(20) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_money`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_type` varchar(10) NOT NULL,
  `it618_money1` float(9,2) NOT NULL,
  `it618_money2` float(9,2) NOT NULL,
  `it618_zsjfid` int(10) unsigned NOT NULL,
  `it618_zsjfcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_zsbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_skmoney` float(9,2) NOT NULL,
  `it618_sktcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_bank` varchar(1000) NOT NULL,
  `it618_bankcodeimg` varchar(300) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_paytype` varchar(20) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_czyfmoney` float(9,2) NOT NULL,
  `it618_zytype` varchar(30) NOT NULL,
  `it618_zyid` int(10) unsigned NOT NULL,
  `it618_txtype` varchar(10) NOT NULL,
  `it618_txid` varchar(50) NOT NULL,
  `it618_txtcbl` float(9,2) NOT NULL,
  `it618_txtransid` varchar(50) NOT NULL,
  `it618_txstate` int(10) unsigned NOT NULL,
  `it618_txstatebz` varchar(1000) NOT NULL,
  `it618_zftype` varchar(10) NOT NULL,
  `it618_zfid` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_moneywork`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_moneywork` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_trans`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_trans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_money` float(9,2) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_statebz` varchar(1000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saletype` varchar(20) NOT NULL,
  `it618_jfid1` int(10) unsigned NOT NULL,
  `it618_jfid2` int(10) unsigned NOT NULL,
  `it618_uid1` int(10) unsigned NOT NULL,
  `it618_uid2` int(10) unsigned NOT NULL,
  `it618_jfcount` int(10) unsigned NOT NULL,
  `it618_bl` float(9,3) NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_bank` varchar(1000) NOT NULL,
  `it618_zk` float(9,2) NOT NULL,
  `it618_money` float(9,2) NOT NULL,
  `it618_zsjfid` int(10) unsigned NOT NULL,
  `it618_zsjfcount` int(10) unsigned NOT NULL,
  `it618_zsbl` float(9,2) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_paytype` varchar(20) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_recharge`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_moneycount` int(10) unsigned NOT NULL,
  `it618_rechargebl` float(9,3) NOT NULL,
  `it618_zsjfid` int(10) unsigned NOT NULL,
  `it618_zsbl` float(9,2) NOT NULL,
  `it618_counts` varchar(300) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_quan`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_quan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_useuid` int(10) unsigned NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL DEFAULT '',
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_jfcount` int(10) unsigned NOT NULL,
  `it618_money` float(9,2) NOT NULL,
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_usetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_groupzk`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_groupzk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_zk` float(9,2) NOT NULL DEFAULT '100',
  `it618_zk1` float(9,2) NOT NULL DEFAULT '100',
  `it618_zk2` float(9,2) NOT NULL DEFAULT '100',
  `it618_zk3` float(9,2) NOT NULL DEFAULT '100',
  `it618_zk4` float(9,2) NOT NULL DEFAULT '100',
  `it618_zk5` float(9,2) NOT NULL DEFAULT '100',
  `it618_zk6` float(9,2) NOT NULL DEFAULT '100',
  `it618_zk7` float(9,2) NOT NULL DEFAULT '100',
  `it618_zk8` float(9,2) NOT NULL DEFAULT '100',
  `it618_zk11` float(9,2) NOT NULL DEFAULT '100',
  `it618_max1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_max2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_max3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_max4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_max5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_max6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_max7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_max8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_max11` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_groupforum`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_groupforum` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_fid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_zhuan`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_zhuan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_jfid1` int(10) unsigned NOT NULL,
  `it618_jfid2` int(10) unsigned NOT NULL,
  `it618_jfcount1` int(10) unsigned NOT NULL,
  `it618_jfcount2` int(10) unsigned NOT NULL,
  `it618_zhuanbl` float(9,3) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_transfer`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_transfer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_jfcount1` int(10) unsigned NOT NULL,
  `it618_jfcount2` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_tq`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_tq` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_jfcount1` int(10) unsigned NOT NULL,
  `it618_jfcount2` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_txbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_txbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_jfcount1` int(10) unsigned NOT NULL,
  `it618_jfcount2` int(10) unsigned NOT NULL,
  `it618_txbl` float(9,3) NOT NULL,
  `it618_zsjfid` int(10) unsigned NOT NULL,
  `it618_zsbl` float(9,2) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_uset`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_uset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_skname` varchar(50) NOT NULL,
  `it618_skurl` varchar(200) NOT NULL,
  `it618_bankname` varchar(200) NOT NULL,
  `it618_bankid` varchar(50) NOT NULL,
  `it618_bankaddr` varchar(50) NOT NULL,
  `it618_alipayname` varchar(50) NOT NULL,
  `it618_alipay` varchar(100) NOT NULL,
  `it618_alipaycodeimg` varchar(300) NOT NULL,
  `it618_wxname` varchar(50) NOT NULL,
  `it618_wx` varchar(100) NOT NULL,
  `it618_wxpaycodeimg` varchar(300) NOT NULL,
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_bz` varchar(300) NOT NULL,
  `it618_isqfuser` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_qd_main`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_qd_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_concount` int(10) unsigned NOT NULL,
  `it618_allcount` int(10) unsigned NOT NULL,
  `it618_concount_month` int(10) unsigned NOT NULL,
  `it618_allcount_month` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_qd`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_qd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_award`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_award` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(50) NOT NULL,
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gailv` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_award_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_award_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pname` varchar(50) NOT NULL,
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecredit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_buygroup`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_buygroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_days1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_days2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_days3` int(10) unsigned NOT NULL DEFAULT '30',
  `it618_unit` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isforumok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_buygroup_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_buygroup_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saletype` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_days` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_unit` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_paycode` varchar(20) NOT NULL,
  `it618_paytype` varchar(20) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_isswitch` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_credits_salepay`;
CREATE TABLE IF NOT EXISTS `pre_it618_credits_salepay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_out_trade_no` varchar(50) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_saletype` varchar(10) NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_paytype` varchar(20) NOT NULL,
  `it618_paytypeid` int(10) unsigned NOT NULL,
  `it618_payid` varchar(100) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_body` varchar(255) NOT NULL,
  `it618_total_fee` varchar(50) NOT NULL,
  `it618_plugin` varchar(50) NOT NULL,
  `it618_client` varchar(1000) NOT NULL,
  `it618_wap` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_paytime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_groupzk'))==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_credits_groupzk')." WHERE it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_credits#it618_credits_groupzk')->insert(array(
				'it618_groupid' => $common_usergroup['groupid'],
				'it618_zk' => 100,
			), true);
		}
	}	
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvdXBncmFkZS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvaW5zdGFsbC5waHA='));
?>