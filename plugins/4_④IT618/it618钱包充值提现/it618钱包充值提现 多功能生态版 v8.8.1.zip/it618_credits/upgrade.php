<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_credits_moneytxtcbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_num1` float(9,2) NOT NULL,
  `it618_num2` float(9,2) NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_moneywork` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_moneycztmp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_money1` float(9,2) NOT NULL,
  `it618_zsjfid` int(10) unsigned NOT NULL,
  `it618_zsjfcount` int(10) unsigned NOT NULL,
  `it618_zsbl` float(9,2) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_paytype` varchar(10) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_czyfmoney` float(9,2) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_moneysktmp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_money1` float(9,2) NOT NULL,
  `it618_zsjfid` int(10) unsigned NOT NULL,
  `it618_zsjfcount` int(10) unsigned NOT NULL,
  `it618_zsbl` float(9,2) NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_paytype` varchar(10) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_trans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_money` float(9,2) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_statebz` varchar(1000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_type` varchar(10) NOT NULL,
  `it618_money1` float(9,2) NOT NULL,
  `it618_money2` float(9,2) NOT NULL,
  `it618_zsjfid` int(10) unsigned NOT NULL,
  `it618_zsjfcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_zsbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_skmoney` float(9,2) NOT NULL,
  `it618_sktcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_bank` varchar(1000) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_paytype` varchar(10) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_czyfmoney` float(9,2) NOT NULL,
  `it618_zytype` varchar(30) NOT NULL,
  `it618_zyid` int(10) unsigned NOT NULL,
  `it618_txtype` varchar(10) NOT NULL,
  `it618_txid` varchar(50) NOT NULL,
  `it618_txtcbl` float(9,2) NOT NULL,
  `it618_txtransid` varchar(50) NOT NULL,
  `it618_txstate` int(10) unsigned NOT NULL,
  `it618_zftype` varchar(10) NOT NULL,
  `it618_zfid` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_buygroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_days1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_days2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_buygroup_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saletype` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_credit1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit6` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit7` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_credit8` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_days` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_paycode` varchar(20) NOT NULL,
  `it618_paytype` varchar(10) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_salepay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_out_trade_no` varchar(50) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_saletype` varchar(10) NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_paytype` varchar(50) NOT NULL,
  `it618_payid` varchar(100) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_body` varchar(255) NOT NULL,
  `it618_total_fee` varchar(50) NOT NULL,
  `it618_plugin` varchar(50) NOT NULL,
  `it618_client` varchar(1000) NOT NULL,
  `it618_wap` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_paytime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_tq` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_jfcount1` int(10) unsigned NOT NULL,
  `it618_jfcount2` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_credits_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_qd_main'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_concount_month', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_qd_main')." add `it618_concount_month` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_sale')." modify column `it618_bl` float(9,3) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_recharge')." modify column `it618_rechargebl` float(9,3) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_txbl')." modify column `it618_txbl` float(9,3) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_allcount_month', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_qd_main')." add `it618_allcount_month` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_moneysktmp'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_zsuid', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_moneysktmp')." add `it618_zsuid` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_time', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_moneysktmp')." add `it618_time` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_recharge'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_zsjfid', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_recharge')." add `it618_zsjfid` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_credits_recharge')." add `it618_zsbl` float(9,2) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_counts', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_recharge')." add `it618_counts` varchar(300) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_txbl'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_zsjfid', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_txbl')." add `it618_zsjfid` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_credits_txbl')." add `it618_zsbl` float(9,2) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_groupzk'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_zk1', $col_field)){
	for($i=1;$i<=8;$i++){
		$sql = "Alter table ".DB::table('it618_credits_groupzk')." add `it618_zk".$i."` float(9,2) NOT NULL DEFAULT '100';"; 
		DB::query($sql);
		$sql = "update ".DB::table('it618_credits_groupzk')." set it618_zk".$i."=it618_zk;"; 
		DB::query($sql);
	}
}

if(!in_array('it618_max1', $col_field)){
	for($i=1;$i<=8;$i++){
		$sql = "Alter table ".DB::table('it618_credits_groupzk')." add `it618_max".$i."` int(10) unsigned NOT NULL DEFAULT '0';"; 
		DB::query($sql);
	}
}

if(!in_array('it618_zk11', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_groupzk')." add `it618_zk11` float(9,2) NOT NULL DEFAULT '100';"; 
	DB::query($sql);
	$sql = "update ".DB::table('it618_credits_groupzk')." set it618_zk11=it618_zk;"; 
	DB::query($sql);
}

if(!in_array('it618_max11', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_groupzk')." add `it618_max11` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_quan'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_xgtime', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_quan')." add `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_money', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_quan')." add `it618_money` float(9,2) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_tcbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_sale')." add `it618_tcbl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_zhuan')." modify column `it618_zhuanbl` float(9,3) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_zsjfid', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_sale')." add `it618_zsjfid` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_credits_sale')." add `it618_zsjfcount` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_credits_sale')." add `it618_zsbl` float(9,2) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_salepay'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_paytypeid', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_salepay')." add `it618_paytypeid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_money'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_bankcodeimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_money')." add `it618_bankcodeimg` varchar(300) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_txstatebz', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_money')." add `it618_txstatebz` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_uset'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_bz', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_bz` varchar(300) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_moneycztmp')." modify column `it618_paytype` varchar(20) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_moneysktmp')." modify column `it618_paytype` varchar(20) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_money')." modify column `it618_paytype` varchar(20) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_sale')." modify column `it618_paytype` varchar(20) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_buygroup_sale')." modify column `it618_paytype` varchar(20) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_credits_salepay')." modify column `it618_paytype` varchar(20) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "update ".DB::table('it618_credits_salepay')." set it618_paytype='payjs_wxwap' where it618_paytype='payjswap';"; 
	DB::query($sql);
	
	$sql = "update ".DB::table('it618_credits_salepay')." set it618_paytype='payjs_wxcode' where it618_paytype='payjscode';"; 
	DB::query($sql);
}

if(!in_array('it618_wxname', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_wxname` varchar(50) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_wx', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_wx` varchar(100) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_alipaycodeimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_alipaycodeimg` varchar(300) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_wxpaycodeimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_wxpaycodeimg` varchar(300) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_skname', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_skname` varchar(50) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_skurl', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_skurl` varchar(200) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_tel', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_tel` varchar(20) NOT NULL;"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_credits_rz'));
	while($it618_credits_rz = DB::fetch($query)) {
		$sql = "update ".DB::table('it618_credits_uset')." set it618_tel='".$it618_credits_rz['it618_tel']."' where it618_uid=".$it618_credits_rz['it618_uid'].";"; 
		DB::query($sql);
	}
}

if(!in_array('it618_money', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_money` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_isqfuser', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_uset')." add `it618_isqfuser` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_buygroup'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_days3', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_buygroup')." add `it618_days3` int(10) unsigned NOT NULL DEFAULT '30';"; 
	DB::query($sql);
}

if(!in_array('it618_unit', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_buygroup')." add `it618_unit` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_buygroup_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_unit', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_buygroup_sale')." add `it618_unit` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
	
	$sql = "update ".DB::table('it618_credits_sale')." set it618_saletype='zy' where it618_saletype='tx';"; 
	DB::query($sql);
	
	rename(DISCUZ_ROOT.'./source/plugin/it618_credits/rewrite.php',DISCUZ_ROOT.'./source/plugin/it618_credits/config/rewrite.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_credits/message.php',DISCUZ_ROOT.'./source/plugin/it618_credits/config/message.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_credits/skset.php',DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_credits/buygroupset.php',DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_credits/qdset.php',DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_credits/awardset.php',DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_credits/hongbaoset.php',DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php');
}

if(!in_array('it618_isswitch', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_buygroup_sale')." add `it618_isswitch` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_bottomnav'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_curimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_bottomnav')." add `it618_curimg` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_credits_moneywork'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_v1', $col_field)){
	$sql = "Alter table ".DB::table('it618_credits_moneywork')." add `it618_v1` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('common_member')." modify column `extgroupids` char(255) NOT NULL;"; 
	DB::query($sql);
}

DB::query("update ".DB::table('common_plugin')." set name='".lang('plugin/it618_credits', 'it618_name')."' where identifier='it618_credits'");

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvZGlzY3V6X3BsdWdpbl9pdDYxOF9jcmVkaXRzX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvaW5zdGFsbC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NyZWRpdHMvdXBncmFkZS5waHA='));
?>