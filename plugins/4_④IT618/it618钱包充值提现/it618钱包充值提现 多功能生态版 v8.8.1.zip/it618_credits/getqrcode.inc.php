<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['type']=='alipay'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php';
	}
	
	$url=$_GET['url'];
	$tmpsign=md5($key.$url);
	if($_GET['sign']!=$tmpsign){
		exit;
	}
}

if($_GET['type']=='wx'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
	}
	
	$url=$_GET['url'];
	$tmpsign=md5($wx_key.$url);
	if($_GET['sign']!=$tmpsign){
		exit;
	}
}

if($_GET['type']=='alif2f'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_alif2f/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_alif2f/config.php';
	}
	
	$url=$_GET['url'];
	$tmpsign=md5($alif2f_privatekey.$url);
	if($_GET['sign']!=$tmpsign){
		exit;
	}
}

if($_GET['type']=='payjs'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';
	}
	
	$url=$_GET['url'];
	$tmpsign=md5($payjs_key.$url);
	if($_GET['sign']!=$tmpsign){
		exit;
	}
}

if($_GET['type']=='precode'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php';
	}
	
	$url=$_GET['url'];
	$tmpsign=md5($precode_key.$url);
	if($_GET['sign']!=$tmpsign){
		exit;
	}
}

if($_GET['type']=='magapp'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_magapp/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_magapp/config.php';
	}
	
	$url=$_GET['url'];
	$tmpsign=md5($magapp_secret.$url);
	if($_GET['sign']!=$tmpsign){
		exit;
	}
}

include DISCUZ_ROOT.'./source/plugin/it618_credits/phpqrcode.php';

$errorCorrectionLevel = 'L';//容错级别 
$matrixPointSize = 6;//生成图片大小 
//生成二维码图片 
QRcode::png($url, false, $errorCorrectionLevel, $matrixPointSize, 0); 
exit;
?>