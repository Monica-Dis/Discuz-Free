<?php
ini_set('date.timezone','Asia/Shanghai');

require_once 'AopClient.php';
require_once '../trans/AlipayFundTransToaccountTransferRequest.php';
require_once 'SignData.php';

$aop = new AopClient ();
$aop->appId = '2016082000291688';
$aop->rsaPrivateKey = 'MIIEowIBAAKCAQEAzuZpuA0aiXK7QxGds7Sv+CbRHoOLCodtpK4wgvPBk6GQSIhKU8Y6R9itdgw//4U/Q7h8ldQIYDYnjEedI73wgSxq+NP/k/G/dBRMkFc4LQTDmkGxBn8c/sCotlq3qLrUTGWrTGnwMKU7Q8iZefGEyRGCPigcft6jmlpX65WHlF0HJFHj5Vx7nbvCruaZVxxuXL0AlyFD6HT3xk9XBm8y+gh0aiFnfHVggraUAk46K/sNEdihEVMghKTQKYV5f58dkk1/f+BKN5beoA1xDZGj06vS+oMpnAdgkpBKnmMOaHh9QMPz2aSccBx+dcUHYcc5LzHYFJkRRyn3Gc4f67cPuQIDAQABAoIBAHbQRJeoFrwlwbnzLM/dDEyB5gcS3U7PlLxEN6GL33crCZNNiPlw1Vka6gnnYP0YhMsb75eO6rxtfOqG2YuD8NANNOTtwVAxPJOpcIpXO/BGUxmLbeBgMMNu2bPWhq+DkpTIscUw9PjKei0jzlcDxhA9WMDfAfYtXmAuT1z/QpuEg0y0U0YNhJIqbENgufLQnVLkrUEKLtWE93HoDO8An1W3AY1rSWYGx1EiyicH8bqHf+ti/11K52raCUtAukx8ZPm4GGqTaFTR4dDOUc3LW30GjVLYefRugCzVL9HH4okVNb9MQN/wWwpLB/3wL95knQMfH4pkCG3jcnRQwWPx/wECgYEA+436oG6KfNdkIQXAvRYhsduSwjDzBmg95neozADLi23DzGYDJ9TQQ0GLyO30SQ7kQsczjJxgrajYIBuUvKkHFg7Si52JVoYkqv/N9ePPgIUSzLKy7hB7+4PaGADG88Th/vuBrlU12GlMxQO+9epWBR+WYs8mHX4zpU6vWsd/kNkCgYEA0o5rPCD6bFG4ECSgvw4hG0MizRjgsIAgxvCbaLKn3NxxcmRBI2V/18HdGMnvUb+7/5ua3V7tNMbaQc9AWLqozqPKR1za2oYGvkpemo3tF30xQUJvKreV5KhC+lyjK1vmxFRcFatjHtvGB4Oj34/U33iLJhVofCYZNJ7ZpfnWKeECgYEAqMHhB0vhQEtHcxfm63Mze5wwYnJwNzYrgLd52BIYextSJYeySkBszxHj8xIftft1io8UuBoYiagiBbg7Gi3TAStEeEFhZ1hqtQUTaQhBppifug+QFkGcy2jzIPM0hUjpzCNyJkAn9Vz/EZSnwVZKCvnb68HIcjS99QJKhX4cyFECgYBwP5CXe5VFTcNsh7pSYDvyBrZ01IBkV8ohhH+1LxkiOzsXmq7HKgMfiLBP2MeGs0qMF+5VeZfHfQM59jz9kHURxGu/45agzLanl4obpvHwhcNOYRZWlYyJW9JpGh26rcG2hKqausWa29sUgm9Ibas0f1TfNqZ/GOhzDwRE4Y30wQKBgHEEMoDyfTjgPtp2wUOpXyMshBPhYBYa0uVMJQiJWb2+DQS/Ng1SiOMdA6VxRK7JNh79JCIlQfV+j+t8803Hhwlqcj2e8pccW7K2nVnr4QbfBn8Q+0/plTnKNTPw+Plsf5Ocm99RR98mm1uaCI14dc5VCnpbEqJF4fAcqPjJ1Li8';
$aop->alipayrsaPublicKey='MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqZFlu7ZFnotnRNMqssWSgcRZPWxB5fxtUjDrAsGUs1db6ibSfFZKZilXJt71zaO5Yx6w12p3tWoEWEPc3V+LzJS/ubgQE24OR/Iy2TMHNTDfBbLMyFfsSx9M29hgLybcuRXkFyNBYOdYprQPYat+lM9fCwefa8X9SsS6Tac+gZ5dpDEb6hijSaaqwWeeR3hMJmu8xHpiVNKB2nT7dHybVXNsudrH6lU9Y7CU94tgtaWnEb1XMNCiVmhFsF7WadBDtF5XRZSekalR+124jOH38zPI9W96EQTe34WIEBtG4uRdPAzu75N74aUKRbQDBFBjO1Zxq1X7tfzsjTa2FfAbSwIDAQAB';
$aop->gatewayUrl = 'https://openapi.alipaydev.com/gateway.do';
$aop->apiVersion = '1.0';
$aop->signType = 'RSA2';
$aop->postCharset='utf-8';
$aop->format='json';
$date=date("YmdHis");
$arr=range(1000,9999);
shuffle($arr);
$request = new AlipayFundTransToaccountTransferRequest ();
//收款方账户类型为：ALIPAY_LOGONID：支付宝登录号，支持邮箱和手机号格式。
$request->setBizContent("{" .
    "\"out_biz_no\":\"".$date.$arr[0]."\"," .
    "\"payee_type\":\"ALIPAY_LOGONID\"," .
    "\"payee_account\":\"oxxcqe1255@sandbox.com\"," .
    "\"amount\":\"0.1\"," .
    "\"remark\":\"dasdasdsa\"" .
    "}");
$result = $aop->execute ($request);

$result = json_decode(json_encode($result),true);
	
$code=$result['alipay_fund_trans_toaccount_transfer_response']['code'];
$msg=$result['alipay_fund_trans_toaccount_transfer_response']['msg'];
$sub_code=$result['alipay_fund_trans_toaccount_transfer_response']['sub_code'];
$sub_msg=$result['alipay_fund_trans_toaccount_transfer_response']['sub_msg'];
$order_id=$result['alipay_fund_trans_toaccount_transfer_response']['order_id'];
$pay_date=$result['alipay_fund_trans_toaccount_transfer_response']['pay_date'];

if($msg=='Success'){
	echo $msg;
}else{
	echo '<br>code：'.$code.'<br>msg：'.$msg.'<br>sub_code：'.$sub_code.'<br>sub_msg：'.$sub_msg;
}
?>