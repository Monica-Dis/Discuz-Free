<?php
/**
 *	开发团队：IT618
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1012" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', 1);
require '../../../../source/class/class_core.php';

$DiscuzApp = C::app();
$DiscuzApp->init();

loadcache('plugin');

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/function.php';

if(function_exists('file_get_contents')){
	$xml = file_get_contents("php://input");
}else{
	$xml = $GLOBALS["HTTP_RAW_POST_DATA"];
}

$data = it618_xmltoarray($xml);

//@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/debug.txt',"a");
//fwrite($fp,$data['out_trade_no'].date('Y-m-d H:i:s', $_G['timestamp'])."\n");
//fclose($fp);

if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($data['out_trade_no'])){
	if($it618_salepay['it618_state']==1)exit;
}else{
	exit;
}

$it618_plugin=$it618_salepay['it618_plugin'];

if($it618_salepay['it618_paytype']=='Appbyme'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php';
	$key=$wxapp_key;
}else{
	if($it618_salepay['it618_paytype']=='wxh5'){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php';
		$key=$wxh5_key;
	}else{
		if($it618_salepay['it618_paytypeid']>0){
			if($it618_wxmini_app = C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_id($it618_salepay['it618_paytypeid'])){
				$key=$it618_wxmini_app['it618_wxpaykey'];
			}
		}else{
			require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
			$key=$wx_key;
		}
	}
}

$data1=$data;
unset($data1["sign"]);
$sign=it618_getwxsign($data1,$key);

if($sign!=$data["sign"])exit;

if($data["return_code"]=="SUCCESS"&&$data["result_code"]=="SUCCESS"){
	C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($data['transaction_id'],$data['out_trade_no']);
	require_once DISCUZ_ROOT.'./source/plugin/'.$it618_plugin.'/ajaxpay.func.php';
	echo pay_success($data['out_trade_no']);
}

?>