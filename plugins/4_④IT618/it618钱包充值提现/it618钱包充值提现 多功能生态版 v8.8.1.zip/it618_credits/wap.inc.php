<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_credits = $_G['cache']['plugin']['it618_credits'];
$metakeywords = $it618_credits['seokeywords'];
$metadescription = $it618_credits['seodescription'];
$sitetitle=$it618_credits['seotitle'];

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';

if($_G['uid']>0){
	$count=C::t('#it618_credits#it618_credits_uset')->count_by_uid($_G['uid']);
	if($count==0){
		if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_members'")>0){
			$it618_members_user=C::t('#it618_members#it618_members_user')->fetch_id_by_uid($_G['uid']);
			$it618_tel=$it618_members_user['it618_tel'];
		}
		
		$id = C::t('#it618_credits#it618_credits_uset')->insert(array(
			'it618_uid' => $_G['uid'],
			'it618_tel' => $it618_tel,
		), true);
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
	}
	if($qf_isgold==1){
		if($it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($_G['uid'])){
			if($it618_credits_uset["it618_isqfuser"]!=1){
				
				$qfdata=it618_credits_qianfan('read',$_G['uid']);
				if($qfdata['status']==1){
					C::t('#it618_credits#it618_credits_uset')->update($it618_credits_uset["id"],array(
						'it618_isqfuser' => 1
					));
				}elseif($qfdata['status']==-2){
					it618_credits_qianfan('write_adduser',$_G['uid'],10000,1,it618_credits_gbktoutf($it618_credits_lang['s1251']));
				}elseif($qfdata['status']==-1){
					echo $it618_credits_lang['s1250'];exit;
				}else{
					echo $it618_credits_lang['s1249'];exit;
				}
			}
		}
	}
}

if(!credits_is_mobile()){
	$ispc=1;
}

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

if(isset($_GET['dotype'])){
	$pagetype='do';
}else{
	$pagetype='index';
	$navtitle=$sitetitle;
}

$stylecount=C::t('#it618_credits#it618_credits_wapstyle')->count_by_isok_search();
$it618_credits_wapstyle=C::t('#it618_credits#it618_credits_wapstyle')->fetch_by_isok_search();

$tmpurl_home=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
$tmpurl_qd=it618_credits_getrewrite('credits_wap','qd','plugin.php?id=it618_credits:wap&dotype=qd');
$tmpurl_award=it618_credits_getrewrite('credits_wap','award','plugin.php?id=it618_credits:wap&dotype=award');
$tmpurl_hb=it618_credits_getrewrite('credits_wap','hb','plugin.php?id=it618_credits:wap&dotype=hb');
$wapu=it618_credits_getrewrite('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php';
}

if($_G['uid']>0){
	if($qd_isok==1)$usermenu.='<li><a href="'.$tmpurl_qd.'" class="react">'.$it618_credits_lang['t170'].'</a></li>';
	if($award_isok==1)$usermenu.='<li><a href="'.$tmpurl_award.'" class="react">'.$it618_credits_lang['t164'].'</a></li>';
	if($hongbao_isok==1)$usermenu.='<li><a href="'.$tmpurl_hb.'" class="react">'.$it618_credits_lang['t191'].'</a></li>';
	
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.$it618_credits_lang['s252'].'</a></li>';
	
}else{
	$RegName=$_G['setting']['regname'];
	$regurl	="member.php?mod=$RegName";	
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_credits_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_credits_bottomnav = DB::fetch($query)) {
	$it618_url=$it618_credits_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
	$it618_url=str_replace("{waphome}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='index'){
			$iscur=1;
		}
	}

	$tmpurlarr1=explode("{wapmoney}",$it618_url);
	$tmpurl=it618_credits_getrewrite('credits_wap','moneysum','plugin.php?id=it618_credits:wap&dotype=moneysum');
	$it618_url=str_replace("{wapmoney}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($_GET['dotype']=='moneycz'||$_GET['dotype']=='moneyskset'||$_GET['dotype']=='moneytx'||$_GET['dotype']=='moneysum'||$_GET['dotype']=='moneypay'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapcredits}",$it618_url);
	$tmpurl=it618_credits_getrewrite('credits_wap','credits','plugin.php?id=it618_credits:wap&dotype=credits');
	$it618_url=str_replace("{wapcredits}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($_GET['dotype']=='credits'||$_GET['dotype']=='recharge'||$_GET['dotype']=='zhuan'||$_GET['dotype']=='transfer'||$_GET['dotype']=='tq'||$_GET['dotype']=='credit'||$_GET['dotype']=='zy'||$_GET['dotype']=='sum'){
			$iscur=1;
		}
	}
	
	if($it618_credits_bottomnav['id']==5)$it618_url=it618_credits_getrewrite('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_credits_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_credits_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_credits_bottomnav['it618_color'].'">'.$it618_credits_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_credits_bottomnav['it618_img'];
		$it618_title=$it618_credits_bottomnav['it618_title'];
	}
	
	if($it618_credits_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_credits_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;

$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_credits['credits_appid']);
	$wx_secret=trim($it618_credits['credits_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){

	$wxshare_title=$it618_credits['seotitle'];
	if($it618_credits['credits_wxlogo']!=''){
		$wxshare_imgUrl=$it618_credits['credits_wxlogo'];
	}
	$tmparr=explode('://',$wxshare_imgUrl);
	if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
	$wxshare_desc=$it618_credits['seodescription'];
	$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl, DISCUZ_ROOT);
		$signPackage = $wxshare->getSignPackage();
		
		$wxshare_link=$signPackage["url"];
	}
}

$wap=1;
if($pagetype=='index'){
	global $it618_hongbao_lang;
	$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
		
	if(in_array(11,(array)unserialize($it618_hongbao['hongbao_power']))){
		$it618_hbtype='it618_credits';
		$tid=0;
		if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
			$authorid=$it618_hongbao_main['it618_uid'];
		}else{
			if($_G['uid']==$it618_credits['credits_wapsalepower']){
				$authorid=$_G['uid'];
			}
		}
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
		$_G['mobiletpl'][2]='/';
		include template('it618_hongbao:hongbao');
	}
}

$wapbottomsubnav=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('wapbottomsubnavdefault');

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
	if($appurl=it618_members_apploginok($_GET['token'])){
		dheader("location:$appurl");
	}
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_wapad=it618_group_getad($_GET['id'],1);
}

if($_GET['dotype']!='moneysk'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/it618_api.func.php';
}

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/wap/'.$pagetype.'.inc.php';
?>