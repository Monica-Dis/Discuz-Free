﻿<?php
/**
 *	开发团队：IT618
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1012" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($_GET['out_trade_no'])){
	if($it618_salepay['it618_state']==1)exit;
}else{
	if(isset($_GET['test'])){
		echo 'This url is ok!';
	}
	exit;
}

if(!function_exists('curl_init')){
	echo 'please open the curl!';exit;
}

//$time=$_G['timestamp']-3600*24*30;
//DB::query("delete from ".DB::table('it618_credits_salepay')." where it618_state=0 and it618_time<$time");

$out_trade_no=$it618_salepay['it618_out_trade_no'];
$paytype=$it618_salepay['it618_paytype'];
$url=$it618_salepay['it618_url'];
$tmparr=explode("//",$url);
if(count($tmparr)==1){
	$url=$tmparr[0].'//'.urlencode($tmparr[1]);
}
$body=gbktoutf($it618_salepay['it618_body']);
$body=str_replace("<","",$body);
$body=str_replace(">","",$body);
$total_fee=$it618_salepay['it618_total_fee'];
$it618_plugin=$it618_salepay['it618_plugin'];
$it618_wap=$it618_salepay['it618_wap'];

if($paytype=='money'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	if($_GET['ac']=='it618'){
		$uid = $_G['uid'];
		if($uid<=0){
			echo 'it618_split'.gbktoutf($it618_credits_lang['s217']);
		}else{
			set_time_limit (0);
			ignore_user_abort(true);
	
			$flagkm=0;$times=0;
			while($flagkm==0){
				if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
					$flagkm=1;
				}
				if($flagkm==0){
					sleep(1);
					$times=$times+1;
				}
				if($times>60){
					it618_credits_delmoneywork();
				}
			}
			C::t('#it618_credits#it618_credits_moneywork')->insert(array(
				'it618_iswork' => 1
			), true);
			
			$it618_money2=$it618_salepay['it618_total_fee'];
			
			$it618_money=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uid);
			DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_money." where it618_uid=".$uid);
			if($it618_money2>$it618_money){
				header('Content-Type:text/html;charset=utf-8');
				echo 'it618_split'.gbktoutf($it618_credits_lang['s1893']);it618_credits_delmoneywork();exit;
			}
			
			$id=savemoney(array(
				'it618_uid' => $uid,
				'it618_type' => 'pay',
				'it618_money2' => $it618_money2,
				'it618_bz' => $it618_salepay['it618_body'],
				'it618_zftype' => $it618_salepay['it618_saletype'],
				'it618_zfid' => $it618_salepay['id']
			));
	
			C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($id,$it618_salepay['it618_out_trade_no']);
			require_once DISCUZ_ROOT.'./source/plugin/'.$it618_salepay['it618_plugin'].'/ajaxpay.func.php';
			
			pay_success($it618_salepay['it618_out_trade_no']);
			
			header('Content-Type:text/html;charset=utf-8');
			echo 'it618_splitokit618_split'.gbktoutf($it618_credits_lang['s1008']).'it618_split'.$url;
			it618_credits_delmoneywork();exit;
		}
	}else{
		if($it618_wap==0){
			$tmpurl=$_G['siteurl'].it618_credits_getrewrite('credits_home','moneypay@'.$it618_salepay['id'],'plugin.php?id=it618_credits:do&dotype=moneypay&ctype='.$it618_salepay['id']);
		}else{
			$tmpurl=$_G['siteurl'].it618_credits_getrewrite('credits_wap','moneypay@'.$it618_salepay['id'],'plugin.php?id=it618_credits:wap&dotype=moneypay&ctype='.$it618_salepay['id']);
		}
		
		dheader("location:$tmpurl");
	}
}

if($paytype=='alipaycode'){
	if(is_mobile()){
		$paytype='alipay';
		$it618_wap=1;
	}
}

if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')!==false){
	if($paytype=='alipay')$paytype='alipaycode';
}

if(strpos($_SERVER['HTTP_USER_AGENT'],'MAGAPPX')!==false)$ismagapp=1;
if($ismagapp==1){
	if($paytype=='MAGAPPXcode')$paytype='MAGAPPX';
}

if($paytype=='alipay'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php';
	$alipay_config = array();
	$alipay_config['seller_email'] = $seller_email;
	$alipay_config['partner'] = $partner;
	$alipay_config['key'] = $key;
	$alipay_config['sign_type'] = strtoupper('MD5');
	$alipay_config['input_charset'] = "utf-8";
	$alipay_config['cacert'] = DISCUZ_ROOT.'./source/plugin/it618_credits/pay/cacert.pem';
	$alipay_config['transport'] = 'http';
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay/lib/alipay_submit.class.php';

	$payment_type = "1";
	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay/notify.php';
	$return_url = $_G['siteurl'].'source/plugin/it618_credits/pay/return.php';
	
	if($it618_wap==0){
		$parameter = array(
				"service" => "create_direct_pay_by_user",
				"partner" => trim($alipay_config['partner']),
				"seller_email" => trim($alipay_config['seller_email']),
				"payment_type"	=> $payment_type,
				"notify_url"	=> $notify_url,
				"return_url"	=> $return_url,
				"out_trade_no"	=> $out_trade_no,
				"subject"	=> $body,
				"total_fee"	=> $total_fee,
				"body"	=> $body,
				"show_url"	=> $url,
				"anti_phishing_key"	=> $anti_phishing_key,
				"exter_invoke_ip"	=> $exter_invoke_ip,
				"_input_charset"	=> "utf-8"
		);
	}else{
		if($hbfq!=''){
			$tmphbfq=explode('@',$hbfq);
			if($total_fee>=$tmphbfq[1])$fqbl=100;else $fqbl=0;
			$hb_fq_param='{"hb_fq_num":"'.$tmphbfq[0].'","hb_fq_seller_percent":"'.$fqbl.'"}';
		}
		
		$parameter = array(
				"service" => "alipay.wap.create.direct.pay.by.user",
				"partner" => trim($alipay_config['partner']),
				"seller_id" => trim($alipay_config['partner']),
				"payment_type"	=> $payment_type,
				"notify_url"	=> $notify_url,
				"return_url"	=> $return_url,
				"out_trade_no"	=> $out_trade_no,
				"subject"	=> $body,
				"total_fee"	=> $total_fee,
				"hb_fq_param" => $hb_fq_param,
				"show_url"	=> $url,
				"body"	=> $body,
				"it_b_pay"	=> $it_b_pay,
				"extern_token"	=> $extern_token,
				"_input_charset"	=> "utf-8"
		);
	}
	
	$alipaySubmit = new AlipaySubmit($alipay_config);
	
	$html_text = $alipaySubmit->buildRequestForm($parameter,"get", "ok");
	
	$html_text = str_replace("type='submit' value='ok'>","type='submit' style='display:none' value=''><img src='source/plugin/it618_credits/images/loading_r.gif'/>",$html_text);
	
	$charset='utf-8';
	echo '
	<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
	</head>
	<style>
	body{background-color:#fff}
	</style>
	'.$html_text.'
	</html>
	';
}

if($paytype=='alipaycode'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php';
	
	$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
	$tmpsign=md5($key.$ajaxpay);
	$tmpstr=$_G['siteurl'].'plugin.php?id=it618_credits:getqrcode&type=alipay&sign='.$tmpsign.'&url='.urlencode($ajaxpay);
		
	if($_GET['ac']=='it618'){
		header('Content-Type:text/html;charset=utf-8');
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
		echo 'it618_split'.$ajaxpay.'it618_split'.$it618_salepay['it618_saleid'].'it618_split'.$tmpstr.'it618_split'.gbktoutf($it618_credits_lang['s1319'].'it618_split'.$it618_credits_lang['s1320']);
	}
}

if($paytype=='wxwap'||$paytype=='wxcode'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
	}
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	
	if($wx_domain==''){
		$wxdomainurl=$_G['siteurl'];
	}else{
		$urlarr=explode("://",$wx_domain);
		if(count($urlarr)==1){
			$wxdomainurl=$httpstr.$wx_domain.'/';
		}else{
			$wxdomainurl=$wx_domain.'/';
		}
		$wxdomainurl=$wxdomainurl.'@';
		$wxdomainurl=str_replace('/@','/',$wxdomainurl);
		$wxdomainurl=str_replace('//@','/',$wxdomainurl);
	}
}

if($paytype=='wxcode'){
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')!==false){
		$paytype='wxwap';
	}else{
		if(is_mobile()){ 
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php';
			}
			if($wxh5_isok==1)$paytype='wxh5';
		}
	}
}

if(($paytype=='wxwap')){
	$notify_url = $wxdomainurl.'source/plugin/it618_credits/pay_wx/notify.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/function.php';
	
	if($openid==''){
		if(isset($_GET['code'])){
			$code=$_GET['code'];
		} else {
			$redirect_uri=urlencode($wxdomainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no);
			$scope='snsapi_base';
			//$scope='snsapi_userinfo';
			
			if($wx_getcodeurl!=''){
				dheader("location:$wx_getcodeurl/getweixincode.html?appid=$wx_appid&scope=$scope&state=$state&redirect_uri=$redirect_uri");
			}else{
				dheader("location:https://open.weixin.qq.com/connect/oauth2/authorize?appid=$wx_appid&redirect_uri=$redirect_uri&response_type=code&scope=$scope&state=$state#wechat_redirect");
			}
		}
		
		$curlurl = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$wx_appid."&secret=".$wx_secret."&code=".$code."&grant_type=authorization_code";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_URL, $curlurl);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$res = curl_exec($ch);
		curl_close( $ch );
		$data = json_decode($res, true);
	
		if($data["errmsg"]!=''){
			echo '<div style="font-size:38px;">'.$res.'</div>';
			exit;
		}
		
		$openid=$data['openid'];
	}
	
	$input = array(
		'body' => $body,
		'out_trade_no' => $out_trade_no,
		'total_fee' => ($total_fee*100),
		'notify_url' => $notify_url,
	);
	
	$input["trade_type"] = 'JSAPI';
	$input["appid"] = $wx_appid;
	$input["mch_id"] = $wx_mch_id; 
	$input["openid"] = $openid;
	$input["nonce_str"] = it618_getrandstr();
	$input["spbill_create_ip"] = $_G['clientip']; 
	$input["sign"] = it618_getwxsign($input,$wx_key);
	
	$prepaystr = it618_postxmlcurl(it618_arraytoxml($input),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postobj = it618_xmltoarray($prepaystr);
	$prepayid = $postobj["prepay_id"];
	
	if($postobj["return_code"]=='FAIL'){
		echo '<div style="font-size:38px;">'.$postobj["return_msg"].'</div>';
		exit;
	}
	//$s = var_export($postobj,true);
	//it618debug($s);
	
	$wxpay = array();
	$wxpay["appId"] = $wx_appid;
	$wxpay["timeStamp"] = $_G['timestamp'];
	$wxpay["nonceStr"] = it618_getrandstr();
	$wxpay["package"] = "prepay_id=".$prepayid;
	$wxpay['signType'] = "MD5";
	$wxpay["paySign"] = it618_getwxsign($wxpay,$wx_key);
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
	
	$charset='utf-8';
	$wxstr='
	<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/> 
		<title>'.$body.'</title>
		<style>
		body{background-color:#fff}
		.loading{
		position:absolute;
		top:50%;
		left:50%;
		width:200px;
		height:100px;
		margin-top:-58px;
		margin-left:-100px;
		font-size:13px;
		text-align:center;
		}
		</style>
		<div class="loading" id="loading">
		<img src="source/plugin/it618_credits/images/payloading.gif" style="width:58px;margin-bottom:3px"><br>
		'.gbktoutf($it618_credits_lang['s1268']).'
		</div>
		<script type="text/javascript" src="https://res.wx.qq.com/open/js/jweixin-1.3.2.js"></script>
		
		<script>
		wx.config({
			debug: false, 
			appId: "'.$wxpay["appId"].'", 
			timestamp: '.$wxpay["timeStamp"].', 
			nonceStr: "'.$wxpay["nonceStr"].'", 
			signature: "'.$wxpay["paySign"].'", 
			jsApiList: ["chooseWXPay"] 
		});
		
		wx.ready(function () {
			wx.chooseWXPay({
				timestamp: '.$wxpay["timeStamp"].', 
				nonceStr: "'.$wxpay["nonceStr"].'", 
				package: "'.$wxpay["package"].'", 
				signType: "'.$wxpay["signType"].'", 
				paySign: "'.$wxpay["paySign"].'", 
				success: function (res) {
					location.href=\''.$url.'\';
				},
				cancel: function () { 
					history.back();
				}
			});
			document.getElementById("loading").style.display="none";
		});
		</script>
	</head>
	</html>
	';
	echo $wxstr;
	//it618debug($wxstr);
}

if($paytype=='wxh5'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php';
	$appid=$wxh5_appid;
	$mchid=$wxh5_mch_id;
	$key=$wxh5_key;
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/function.php';
	
	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_wx/notify.php';
	
	$input = array(
		'body' => $body,
		'out_trade_no' => $out_trade_no,	
		'total_fee' => ($total_fee*100),	
		'notify_url' => $notify_url,
	);
	
	$input["trade_type"] = "MWEB";
	$input["appid"] = $appid;
	$input["mch_id"] = $mchid; 
	$input["nonce_str"] = it618_getrandstr();
	$input["spbill_create_ip"] = get_client_ip(); 
	$input["scene_info"] = '{"h5_info":{"type":"Wap","wap_url":"'.$url.'","wap_name":"pay"}}'; 
	$input["sign"] = it618_getwxsign($input,$key);
	$prepaystr = it618_postxmlcurl(it618_arraytoxml($input),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	
	$postobj = it618_xmltoarray($prepaystr);
	$mweb_url = $postobj["mweb_url"];
	
	if($postobj["return_code"]=='FAIL'){
		echo '<div style="font-size:38px;">'.$postobj["return_msg"].'</div>';
		exit;
	}
	
	dheader("location:$mweb_url&redirect_url=".urlencode($url));
}

if($paytype=='wxcode'){
	$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
	if($wx_iscode==1){
		$notify_url = $wxdomainurl.'source/plugin/it618_credits/pay_wx/notify.php';
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/function.php';
		
		$input = array();
		$input["out_trade_no"] = $out_trade_no;
		$input["body"] = $body;
		$input["total_fee"] = ($total_fee*100);
		$input["notify_url"] = $notify_url;
		$input["trade_type"] = 'NATIVE';
		$input["appid"] = $wx_appid;
		$input["mch_id"] = $wx_mch_id; 
		$input["nonce_str"] = it618_getrandstr();
		$input["spbill_create_ip"] = $_G['clientip'];
		$input["sign"] = it618_getwxsign($input,$wx_key);
		
		$prepaystr = it618_postxmlcurl(it618_arraytoxml($input),"https://api.mch.weixin.qq.com/pay/unifiedorder");
		$postobj = it618_xmltoarray($prepaystr);
		
		if($postobj["return_code"]=='FAIL'){
			echo 'it618_split'.$postobj["return_msg"];exit;
		}
		
		$code_url=$postobj["code_url"];
		$tmpsign=md5($wx_key.$code_url);
		$tmpstr=$_G['siteurl'].'plugin.php?id=it618_credits:getqrcode&type=wx&sign='.$tmpsign.'&url='.urlencode($code_url);	
	}else{
		$tmpsign=md5($wx_key.$ajaxpay);
		$tmpstr=$_G['siteurl'].'plugin.php?id=it618_credits:getqrcode&type=wx&sign='.$tmpsign.'&url='.urlencode($ajaxpay);	
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
	if($_GET['ac']=='it618'){
		header('Content-Type:text/html;charset=utf-8');
		echo 'it618_split'.$ajaxpay.'it618_split'.$it618_salepay['it618_saleid'].'it618_split'.$tmpstr.'it618_split'.gbktoutf($it618_credits_lang['s1317'].'it618_split'.$it618_credits_lang['s1318']);
	}else{
		if(!is_mobile()){
			$tmpselect='onclick="this.select()"';
		}
		$charset='utf-8';
		echo '
		<html>
		<head>
			<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
			<meta name="viewport" content="width=device-width, initial-scale=1"/> 
			<title>'.$body.'</title>
			<style>
			body{background-color:#fff}
			</style>
			<table style="width:100%;"><tr>
			<td align="center" style="position:relative">
			'.gbktoutf($it618_credits_lang['s1312']).'<br><br>
			<img style="width:230px;height:230px;" src="'.$tmpstr.'"/>
			</td>
			</tr>
			<tr><td align="center">
			'.gbktoutf($it618_credits_lang['t224']).'
			<br><input type="text" value="'.$ajaxpay.'" style="border:none;width:260px; text-align:center" '.$tmpselect.'>
			</td></tr>
			</table>
		</head>
		</html>
		';
	}
}

if($paytype=='Appbyme'){
	$tmpcode=md5($_G['timestamp'].$out_trade_no.FORMHASH.$plugin);

	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php';
	$appid=$wxapp_appid;
	$mchid=$wxapp_mch_id;
	$key=$wxapp_key;
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/function.php';
	
	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_wx/notify.php';
	
	$input = array(
		'body' => $body,
		'out_trade_no' => $out_trade_no,	
		'total_fee' => ($total_fee*100),	
		'notify_url' => $notify_url,
	);
	
	$input["trade_type"] = "APP";
	$input["appid"] = $appid;
	$input["mch_id"] = $mchid; 
	$input["nonce_str"] = it618_getrandstr();
	$input["spbill_create_ip"] = $_G['clientip']; 
	$input["sign"] = it618_getwxsign($input,$key);
	$prepaystr = it618_postxmlcurl(it618_arraytoxml($input),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postobj = it618_xmltoarray($prepaystr);
	$prepayid = $postobj["prepay_id"];
	
	if($postobj["return_code"]=='FAIL'){
		echo '<div style="font-size:38px;">'.$postobj["return_msg"].'</div>';
		exit;
	}
	
	$appwxpay = array();
	$appwxpay["appid"] = $appid;
	$appwxpay["partnerid"] = $mchid;
	$appwxpay["timestamp"] = $_G['timestamp'];
	$appwxpay["package"] = "Sign=WXPay";
	$appwxpay["prepayid"] = $prepayid;
	$appwxpay["noncestr"] = it618_getrandstr();
	$appwxpay["sign"] = it618_getwxsign($appwxpay,$key);
	
	$codepath=DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/wxappcode'.$tmpcode.'.php';
	@$fp = fopen($codepath,"w");
	fwrite($fp,'<?php $code="'.$appwxpay["appid"].'it618_split'.$appwxpay["partnerid"].'it618_split'.$appwxpay["prepayid"].'it618_split'.$appwxpay["sign"].'";?>');
	fclose($fp);
	
	$charset='utf-8';
	echo '
	<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/> 
		<title>'.$body.'</title>
		<style>
		body{background-color:#fff}
		.loading{
		position:absolute;
		top:50%;
		left:50%;
		width:200px;
		height:100px;
		margin-top:-58px;
		margin-left:-100px;
		font-size:13px;
		text-align:center;
		}
		</style>
		<div class="loading" id="loading">
		<img src="source/plugin/it618_credits/images/payloading.gif" style="width:58px;margin-bottom:3px"><br>
		'.gbktoutf($it618_credits_lang['s1268']).'
		</div>
		<script src="https://market-cdn.app.xiaoyun.com/release/sq-2.3.js"></script>
		<script type="text/javascript" src="source/plugin/it618_credits/js/jquery.js"></script>
		<script type="text/javascript">
			IT618_CREDITS.get("'.$_G['siteurl'].'plugin.php?id=it618_credits:ajax&code='.$tmpcode.'", {ac:"getwxappcode"},function (data, textStatus){
			var tmparr=data.split("it618_split");																					
			connectSQJavascriptBridge(function(){
			  var payParam ={
					appid:tmparr[0],
					partnerid:tmparr[1],
					prepayid:tmparr[2],
					attach:"Sign=WXPay",
					noncestr:"'.$appwxpay['noncestr'].'",
					timestamp:"'.$appwxpay['timestamp'].'",
					sign:tmparr[3]
				};
												
			  sq.payRequest(function(result){
				  location.href=\''.$url.'\';
			  },1,JSON.stringify(payParam));
			});
			}, "html");
		</script>
	</head>
	</html>
	';
}

if($paytype=='MAGAPPX'){
	if(!function_exists('file_get_contents')){
		echo 'please open the file_get_contents!';exit;
	}
	$it618_payid=C::t('#it618_credits#it618_credits_salepay')->fetch_payid_by_out_trade_no($out_trade_no);
	if($it618_payid==''){	
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_magapp/config.php';
		
		$sign=md5($magapp_secret.$out_trade_no);
		$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_magapp/notify.php?out_trade_no='.$out_trade_no.'&sign='.$sign;
		$urltmp = $magapp_url.'/core/pay/pay/unifiedOrder';
		
		$re = array();
		$re['trade_no'] = $out_trade_no;
		$re['callback'] = $notify_url;
		$re['amount'] = $total_fee;
		$re['title'] = $body;
		$re['user_id'] = $_G['uid'];
		$re['des'] = $body;
		$re['remark'] = $body;
		$re['secret'] = $magapp_secret;

		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $urltmp);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch,CURLOPT_TIMEOUT,10);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($re));
        $res = curl_exec($ch);
        
        curl_close($ch);
		$data = json_decode($res,true);
		$unionOrderNum=$data["data"]["unionOrderNum"];
		
		if($unionOrderNum==''){
			echo '<div style="font-size:38px;">'.$res.'</div>';
			exit;
		}
	
		C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($unionOrderNum,$out_trade_no);
	}else{
		$unionOrderNum=$it618_payid;
	}

	$charset='utf-8';
	echo '
	<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/> 
		<title>'.$body.'</title>
		<style>
		body{background-color:#fff}
		.loading{
		position:absolute;
		top:50%;
		left:50%;
		width:200px;
		height:100px;
		margin-top:-58px;
		margin-left:-100px;
		font-size:13px;
		text-align:center;
		}
		</style>
		<div class="loading" id="loading">
		<img src="source/plugin/it618_credits/images/payloading.gif" style="width:58px;margin-bottom:3px"><br>
		'.gbktoutf($it618_credits_lang['s1268']).'
		</div>
		<script src="source/plugin/it618_credits/pay_magapp/magjs-x.js"></script>
		<script type="text/javascript">
			var config = {
				money:"'.$total_fee.'",
				title:"'.$body.'",
				des:"'.$body.'",
				payWay:{
					wallet:1,
					weixin:1,
					alipay:1,
				},
				orderNum:"'.$out_trade_no.'",
				unionOrderNum:"'.$unionOrderNum.'",
				type: "xiaofei"
			}
			mag.pay(config, function(){
			  location.href=\''.$url.'\';
			}, function(){
			  location.href=\''.$url.'\';
			});
		</script>
	</head>
	</html>
	';
}

if($paytype=='MAGAPPXcode'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_magapp/config.php';
	
	$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
	$tmpsign=md5($magapp_secret.$ajaxpay);
	$tmpstr=$_G['siteurl'].'plugin.php?id=it618_credits:getqrcode&type=magapp&sign='.$tmpsign.'&url='.urlencode($ajaxpay);
		
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
	if($_GET['ac']=='it618'){
		header('Content-Type:text/html;charset=utf-8');
		echo 'it618_split'.$ajaxpay.'it618_split'.$it618_salepay['it618_saleid'].'it618_split'.$tmpstr.'it618_split'.gbktoutf($it618_credits_lang['s1339'].'it618_split'.$it618_credits_lang['s1320']);
	}else{
		if(!is_mobile()){
			$tmpselect='onclick="this.select()"';
		}
		$charset='utf-8';
		echo '
		<html>
		<head>
			<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
			<meta name="viewport" content="width=device-width, initial-scale=1"/> 
			<title>'.$body.'</title>
			<style>
			body{background-color:#fff}
			</style>
			<table style="width:100%;"><tr>
			<td align="center" style="position:relative">
			'.gbktoutf($it618_credits_lang['s1340']).'<br><br>
			<img style="width:230px;height:230px;" src="'.$tmpstr.'"/>
			</td>
			</tr>
			</table>
		</head>
		</html>
		';
	}
}

if($paytype=='alipay_f2fcode'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_alif2f/config.php';
	
	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_alif2f/notify.php';
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/alipay/AopClient.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_alif2f/AlipayTradePrecreateRequest.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/alipay/SignData.php';
	
	$aop = new AopClient ();
	$aop->appId = $alif2f_appid;
	$aop->rsaPrivateKey = $alif2f_privatekey;
	$aop->alipayrsaPublicKey=$alif2f_publickey;
	$aop->gatewayUrl = 'https://openapi.alipay.com/gateway.do';
	$aop->apiVersion = '1.0';
	$aop->signType = 'RSA2';
	$aop->postCharset='utf-8';
	$aop->format='json';

	$request = new AlipayTradePrecreateRequest();
	$request->setNotifyUrl($notify_url);
	$request->setBizContent("{" .
		"\"out_trade_no\":\"".$out_trade_no."\"," .
		"\"total_amount\":\"".$total_fee."\"," .
		"\"subject\":\"".$body."\"" .
		"}");
	$result = $aop->execute ($request);
	
//	$s = var_export($result,true);
//	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/debug.txt',"a");
//	fwrite($fp,$s);
//	fclose($fp);
	
	$result = json_decode(json_encode($result),true);
	
	$code=$result['alipay_trade_precreate_response']['code'];
	$msg=$result['alipay_trade_precreate_response']['msg'];
	$sub_code=$result['alipay_trade_precreate_response']['sub_code'];
	$sub_msg=$result['alipay_trade_precreate_response']['sub_msg'];
	$qr_code=$result['alipay_trade_precreate_response']['qr_code'];
	
	if($msg=='Success'){
		$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
	  	$tmpsign=md5($alif2f_privatekey.$qr_code);
	  	$tmpstr=$_G['siteurl'].'plugin.php?id=it618_credits:getqrcode&type=alif2f&sign='.$tmpsign.'&url='.urlencode($qr_code);
	}else{
		echo 'it618_split'.$code.':'.$msg."\n".$sub_code.':'.it618_credits_utftogbk($sub_msg);exit;
	}
		
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
	if($_GET['ac']=='it618'){
		header('Content-Type:text/html;charset=utf-8');
		echo 'it618_split'.$ajaxpay.'it618_split'.$it618_salepay['it618_saleid'].'it618_split'.$tmpstr.'it618_split'.gbktoutf($it618_credits_lang['s1319'].'it618_split'.$it618_credits_lang['s1320']);
	}else{
		if(!is_mobile()){
			$tmpselect='onclick="this.select()"';
		}
		$charset='utf-8';
		echo '
		<html>
		<head>
			<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
			<meta name="viewport" content="width=device-width, initial-scale=1"/> 
			<title>'.$body.'</title>
			<style>
			body{background-color:#fff}
			</style>
			<table style="width:100%;"><tr>
			<td align="center" style="position:relative">
			'.gbktoutf($it618_credits_lang['s1272']).'<br><br>
			<img style="width:230px;height:230px;" src="'.$tmpstr.'"/>
			</td>
			</tr>
			</table>
		</head>
		</html>
		';
	}
}

if($paytype=='payjs_wxh5'||$paytype=='payjs_wxcode'){
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')!==false){
		$paytype='payjs_wxwap';
	}
}

if(($paytype=='payjs_wxwap')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';
	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_payjs/notify.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/function.php';
	
	if($openid==''){
		if(isset($_GET['openid'])){
			$openid=$_GET['openid'];
		} else {
			$callback_url=urlencode($_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no);
			
			dheader("location:https://payjs.cn/api/openid?mchid=$payjs_mchid&callback_url=$callback_url");
		}
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/function.php';

	$input = array(
		'mchid'   => $payjs_mchid,
		'body'    => $body,
		'total_fee'    => ($total_fee*100),
		'out_trade_no' => $out_trade_no,
		'notify_url'   => $notify_url,
		'callback_url'   => $url,
		'openid'   => $openid,
	);
	$input['sign'] = it618_sign($input,$payjs_key);
	
	$jsapiurl = 'https://payjs.cn/api/jsapi';
	$res = it618_post($input,$jsapiurl);
	
	$data = json_decode($res,true);
	
	if($data["return_code"]==0){
		echo '<div style="font-size:38px;">'.$data["return_msg"].'</div>';
		exit;
	}
	
	$payjs_order_id=$data["payjs_order_id"];
	C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($payjs_order_id,$out_trade_no);
	
	$wxpay = array();
	$wxpay["appId"] = $data["jsapi"]['appId'];
	$wxpay["timeStamp"] = $data["jsapi"]['timeStamp'];
	$wxpay["nonceStr"] = $data["jsapi"]['nonceStr'];
	$wxpay["package"] = $data["jsapi"]['package'];
	$wxpay['signType'] = $data["jsapi"]['signType'];
	$wxpay["paySign"] = $data["jsapi"]['paySign'];
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
	
	$charset='utf-8';
	$wxstr='
	<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/> 
		<title>'.$body.'</title>
		<style>
		body{background-color:#fff}
		.loading{
		position:absolute;
		top:50%;
		left:50%;
		width:200px;
		height:100px;
		margin-top:-58px;
		margin-left:-100px;
		font-size:13px;
		text-align:center;
		}
		</style>
		<div class="loading" id="loading">
		<img src="source/plugin/it618_credits/images/payloading.gif" style="width:58px;margin-bottom:3px"><br>
		'.gbktoutf($it618_credits_lang['s1268']).'
		</div>
		<script>
		if (typeof WeixinJSBridge == "undefined") {
			if (document.addEventListener) {
				document.addEventListener(\'WeixinJSBridgeReady\', onBridgeReady, false);
			} else if (document.attachEvent) {
				document.attachEvent(\'WeixinJSBridgeReady\', onBridgeReady);
				document.attachEvent(\'onWeixinJSBridgeReady\', onBridgeReady);
			}
		}
		function onBridgeReady() {
			WeixinJSBridge.call(\'hideOptionMenu\');
		
			WeixinJSBridge.invoke(
				\'getBrandWCPayRequest\', {
					"appId": "'.$wxpay["appId"].'",
					"timeStamp": "'.$wxpay["timeStamp"].'",
					"nonceStr": "'.$wxpay["nonceStr"].'",
					"package": "'.$wxpay["package"].'",
					"signType": "'.$wxpay["signType"].'",
					"paySign": "'.$wxpay["paySign"].'"
				},
				function (res) {
					if (res.err_msg == "get_brand_wcpay_request:ok") {
						location.href=\''.$url.'\';
					}else{
						history.back();
					}
				}
			);
		}
		</script>
	</head>
	</html>
	';
	echo $wxstr;
	//it618debug($wxstr);
}

if($paytype=='payjs_wxh5'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';
	
	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_payjs/notify.php';
		
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/function.php';

	$input = array(
		'mchid'   => $payjs_mchid,
		'body'    => $body,
		'attach'    => 'it618',
		'total_fee'    => ($total_fee*100),
		'out_trade_no' => $out_trade_no,
		'callback_url'   => $url,
		'notify_url'   => $notify_url,
	);
	$input['sign'] = it618_sign($input,$payjs_key);
	
	$jsapiurl = 'https://payjs.cn/api/mweb';
	$res = it618_post($input,$jsapiurl);
	$data = json_decode($res,true);
	
	if($data["return_code"]==0){
		echo $data["return_msg"];exit;
	}
	
	$payjs_order_id=$data["payjs_order_id"];
	C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($payjs_order_id,$out_trade_no);
	//var_dump($res);
	
	$h5_url=$data["h5_url"];
	dheader("location:$h5_url");
}

if($paytype=='payjs_wxcode'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';
	
	$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
	if($payjs_istowxcode==1){
		$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_payjs/notify.php';
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/function.php';
	
		$input = array(
			'mchid'   => $payjs_mchid,
			'body'    => $body,
			'total_fee'    => ($total_fee*100),
			'out_trade_no' => $out_trade_no,
			'notify_url'   => $notify_url,
		);
		$input['sign'] = it618_sign($input,$payjs_key);
		
		$jsapiurl = 'https://payjs.cn/api/native';
		$res = it618_post($input,$jsapiurl);
		$data = json_decode($res,true);
		
		if($data["return_code"]==0){
			echo 'it618_split'.$data["return_msg"];exit;
		}
		
		$payjs_order_id=$data["payjs_order_id"];
		C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($payjs_order_id,$out_trade_no);
		//var_dump($res);
		
		$wxurl=$data["code_url"];
		
		$tmpsign=md5($payjs_key.$wxurl);
		$tmpstr=$_G['siteurl'].'plugin.php?id=it618_credits:getqrcode&type=payjs&sign='.$tmpsign.'&url='.urlencode($wxurl);
	}else{
		$tmpsign=md5($payjs_key.$ajaxpay);
		$tmpstr=$_G['siteurl'].'plugin.php?id=it618_credits:getqrcode&type=payjs&sign='.$tmpsign.'&url='.urlencode($ajaxpay);
	}
		
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
	if($_GET['ac']=='it618'){
		header('Content-Type:text/html;charset=utf-8');
		echo 'it618_split'.$ajaxpay.'it618_split'.$it618_salepay['it618_saleid'].'it618_split'.$tmpstr.'it618_split'.gbktoutf($it618_credits_lang['s1317'].'it618_split'.$it618_credits_lang['s1318']);
	}else{
		if(!is_mobile()){
			$tmpselect='onclick="this.select()"';
		}
		$charset='utf-8';
		echo '
		<html>
		<head>
			<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
			<meta name="viewport" content="width=device-width, initial-scale=1"/> 
			<title>'.$body.'</title>
			<style>
			body{background-color:#fff}
			</style>
			<table style="width:100%;"><tr>
			<td align="center" style="position:relative">
			'.gbktoutf($it618_credits_lang['s1312']).'<br><br>
			<img style="width:230px;height:230px;" src="'.$tmpstr.'"/>
			</td>
			</tr>
			<tr><td align="center">
			'.gbktoutf($it618_credits_lang['t224']).'
			<br><input type="text" value="'.$ajaxpay.'" style="border:none;width:260px; text-align:center" '.$tmpselect.'>
			</td></tr>
			</table>
		</head>
		</html>
		';
	}
}

if($paytype=='payjs_alipaycode'){
	if(is_mobile()){
		if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false){
			$paytype='payjs_alipay';
		}
	}
}

if($paytype=='payjs_alipay'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';
	
	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_payjs/notify.php';
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/function.php';

	$input = array(
		'mchid'   => $payjs_alimchid,
		'body'    => $body,
		'total_fee'    => ($total_fee*100),
		'out_trade_no' => $out_trade_no,
		'notify_url'   => $notify_url,
		'callback_url'   => $url,
		'type'   => 'alipay',
	);
	$input['sign'] = it618_sign($input,$payjs_alikey);
	
	$jsapiurl = 'https://payjs.cn/api/native';
	$res = it618_post($input,$jsapiurl);
	$data = json_decode($res,true);
	
	if($data["return_code"]==0){
		echo 'it618_split'.$data["return_msg"];exit;
	}
	
	$payjs_order_id=$data["payjs_order_id"];
	C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($payjs_order_id,$out_trade_no);
	//var_dump($res);
	
	$code_url=$data["code_url"];
	dheader("location:$code_url");
}

if($paytype=='payjs_alipaycode'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';
	
	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_payjs/notify.php';
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/function.php';

	$input = array(
		'mchid'   => $payjs_alimchid,
		'body'    => $body,
		'total_fee'    => ($total_fee*100),
		'out_trade_no' => $out_trade_no,
		'notify_url'   => $notify_url,
		'callback_url'   => $url,
		'type'   => 'alipay',
	);
	$input['sign'] = it618_sign($input,$payjs_alikey);
	
	$jsapiurl = 'https://payjs.cn/api/native';
	$res = it618_post($input,$jsapiurl);
	$data = json_decode($res,true);
	
	if($data["return_code"]==0){
		echo 'it618_split'.$data["return_msg"];exit;
	}
	
	$payjs_order_id=$data["payjs_order_id"];
	$qrcode=$data["qrcode"];
	C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($payjs_order_id,$out_trade_no);
	//var_dump($res);
	
	$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
	$tmpstr=$data["qrcode"];
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
		
	if($_GET['ac']=='it618'){
		header('Content-Type:text/html;charset=utf-8');
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
		echo 'it618_split'.$ajaxpay.'it618_split'.$it618_salepay['it618_saleid'].'it618_split'.$tmpstr.'it618_split'.gbktoutf($it618_credits_lang['s1319'].'it618_split'.$it618_credits_lang['s1320']);
	}else{
		if(!is_mobile()){
			$tmpselect='onclick="this.select()"';
		}
		$charset='utf-8';
		echo '
		<html>
		<head>
			<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
			<meta name="viewport" content="width=device-width, initial-scale=1"/> 
			<title>'.$body.'</title>
			<style>
			body{background-color:#fff}
			</style>
			<table style="width:100%;"><tr>
			<td align="center" style="position:relative">
			'.gbktoutf($it618_credits_lang['s1272']).'<br><br>
			<img style="width:230px;height:230px;" src="'.$tmpstr.'"/>
			</td>
			</tr>
			<tr><td align="center">
			'.gbktoutf($it618_credits_lang['s1320']).'
			<br><input type="text" value="'.$ajaxpay.'" style="border:none;width:260px; text-align:center" '.$tmpselect.'>
			</td></tr>
			</table>
		</head>
		</html>
		';
	}
}

if($paytype=='precode_wx'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php';
	
	$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;

	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_precode/notify.php';
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/function.php';

	$input = array(
		'mid'   => $precode_mchid,
		'param'    => $body,
		'price'    => $total_fee,
		'payId' => $out_trade_no,
		'type' => 1,
		'notify_url'   => $notify_url,
		"isHtml" => 0,
	);
	$input['sign'] = md5($precode_mchid.$input['payId'].$input['param'].$input['type'].$input['price'].$precode_key);
	
	$res = it618_post($input,$precode_apiurl);
	$data = json_decode($res,true);
	
	if($data["code"]!=1){
		echo 'it618_split'.$data["msg"];exit;
	}
	
	$orderId=$data["data"]["orderId"];
	C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($orderId,$out_trade_no);
	
	$payUrl=$data["data"]["payUrl"];
	$reallyPrice=$data["data"]["reallyPrice"];
	
	$tmpsign=md5($precode_key.$payUrl);
	$tmpstr=$_G['siteurl'].'plugin.php?id=it618_credits:getqrcode&type=precode&sign='.$tmpsign.'&url='.urlencode($payUrl);
		
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
	if($precode_about=='')$precode_about=$it618_credits_lang['s1360'];
	$precode_about=str_replace("{money}",number_format($reallyPrice,2),$precode_about);
		
	if($_GET['ac']=='it618'){
		header('Content-Type:text/html;charset=utf-8');
		echo 'it618_split'.$ajaxpay.'it618_split'.$it618_salepay['it618_saleid'].'it618_split'.$tmpstr.'it618_split'.gbktoutf($it618_credits_lang['s1317'].'it618_split'.$precode_about);
	}else{
		if(!is_mobile()){
			$tmpselect='onclick="this.select()"';
		}
		$charset='utf-8';
		echo '
		<html>
		<head>
			<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
			<meta name="viewport" content="width=device-width, initial-scale=1"/> 
			<title>'.$body.'</title>
			<style>
			body{background-color:#fff}
			</style>
			<table style="width:100%;"><tr>
			<td align="center" style="position:relative">
			'.gbktoutf($it618_credits_lang['s1312']).'<br><br>
			<img style="width:230px;height:230px;" src="'.$tmpstr.'"/>
			</td>
			</tr>
			<tr><td align="center">
			'.$precode_about.'
			<br><input type="text" value="'.$ajaxpay.'" style="border:none;width:260px; text-align:center" '.$tmpselect.'>
			</td></tr>
			</table>
		</head>
		</html>
		';
	}
}

if($paytype=='precode_alipay'){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php';
	
	$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;

	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_precode/notify.php';
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/function.php';

	$input = array(
		'mid'   => $precode_mchid,
		'param'    => $body,
		'price'    => $total_fee,
		'payId' => $out_trade_no,
		'type' => 2,
		'notify_url'   => $notify_url,
		"isHtml" => 0,
	);
	$input['sign'] = md5($precode_mchid.$input['payId'].$input['param'].$input['type'].$input['price'].$precode_key);
	
	$res = it618_post($input,$precode_apiurl);
	$data = json_decode($res,true);
	
	if($data["code"]!=1){
		echo 'it618_split'.$data["msg"];exit;
	}
	
	$orderId=$data["data"]["orderId"];
	C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($orderId,$out_trade_no);
	
	$payUrl=$data["data"]["payUrl"];
	$reallyPrice=$data["data"]["reallyPrice"];
	
	$tmpsign=md5($precode_key.$payUrl);
	$tmpstr=$_G['siteurl'].'plugin.php?id=it618_credits:getqrcode&type=precode&sign='.$tmpsign.'&url='.urlencode($payUrl);
		
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
	
	if($precode_about=='')$precode_about=$it618_credits_lang['s1360'];
	$precode_about=str_replace("{money}",number_format($reallyPrice,2),$precode_about);
		
	if($_GET['ac']=='it618'){
		header('Content-Type:text/html;charset=utf-8');
		echo 'it618_split'.$ajaxpay.'it618_split'.$it618_salepay['it618_saleid'].'it618_split'.$tmpstr.'it618_split'.gbktoutf($it618_credits_lang['s1319'].'it618_split'.$precode_about);
	}else{
		if(!is_mobile()){
			$tmpselect='onclick="this.select()"';
		}
		$charset='utf-8';
		echo '
		<html>
		<head>
			<meta http-equiv="content-type" content="text/html;charset='.$charset.'"/>
			<meta name="viewport" content="width=device-width, initial-scale=1"/> 
			<title>'.$body.'</title>
			<style>
			body{background-color:#fff}
			</style>
			<table style="width:100%;"><tr>
			<td align="center" style="position:relative">
			'.gbktoutf($it618_credits_lang['s1272']).'<br><br>
			<img style="width:230px;height:230px;" src="'.$tmpstr.'"/>
			</td>
			</tr>
			<tr><td align="center">
			'.$precode_about.'
			<br><input type="text" value="'.$ajaxpay.'" style="border:none;width:260px; text-align:center" '.$tmpselect.'>
			</td></tr>
			</table>
		</head>
		</html>
		';
	}
}

function gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function is_mobile(){ 
	global $_GET;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}

function it618debug($content){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/debug.txt',"a");
	fwrite($fp,$content);
	fclose($fp);
}
?>