<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!credits_is_mobile()){
	$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
	dheader("location:$tmpurl");
}

$navtitle=$it618_credits_lang['t3'];

$isactive=$it618_credits['credits_isactive'];
if($it618_credits['credits_wapsalepower']==$_G['uid'])$isadmin=1;
if($_G['uid']==0&&$isactive>0)$isuserall=1;

$weekarray=array($it618_credits_lang['s506'],$it618_credits_lang['s507'],$it618_credits_lang['s508'],$it618_credits_lang['s509'],$it618_credits_lang['s510'],$it618_credits_lang['s511'],$it618_credits_lang['s512']);
$weekstr=$it618_credits_lang['s505'].$weekarray[date("w")];
$datestr=date('n').'.'.date('j');

$tomonth = date('n');
$todate = date('j');
$toyear = date('Y');
$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
		
$todaycount=C::t('#it618_credits#it618_credits_qd')->count_by_time($time);
if($todaycount>0){
	$uid=C::t('#it618_credits#it618_credits_qd')->fetch_uid_by_time($time);
	$qdnewusername=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$uid);
}

$qd_allcount=0;
$qdtitle=$it618_credits_lang['s504'];
$qdcolor='#999';

if($_G['uid']>0){
	if($qd_isok==1){
		$it618_credits_qd_main=C::t('#it618_credits#it618_credits_qd_main')->fetch_by_uid($_G['uid']);
		$qd_allcount=$it618_credits_qd_main['it618_allcount'];if($qd_allcount=='')$qd_allcount=0;
		
		$myqdcount=C::t('#it618_credits#it618_credits_qd')->count_by_uid_time($_G['uid'],$time);
		
		if($myqdcount>0){
			$qdtitle='<img src="source/plugin/it618_credits/images/qd.png" style="vertical-align:middle; height:18px; margin-top:-5px; margin-right:3px" />'.$it618_credits_lang['s503'];
			$qdcolor='#f30';
		}else{
			$credits_qdgroup=(array)unserialize($it618_credits['credits_qdgroup']);
			if(!in_array($_G['groupid'], $credits_qdgroup)&&$credits_qdgroup[0]!=''){
			}else{
				$isqdgroup=1;
			}
			$qdtitle='<img src="source/plugin/it618_credits/images/qd0.png" style="vertical-align:middle; height:18px; margin-top:-5px; margin-right:3px" />'.$it618_credits_lang['s504'];
			$qdcolor='#999';
		}
	}
	
	$menuusername=$_G['username'];
	
	$groupid=$_G['groupid'];
	if($groupid>0)$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
	
	if($buygroup_isok==1){
		$tmpurl_buygroup=it618_credits_getrewrite('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
		$buygroupstr='[<a href="'.$tmpurl_buygroup.'"><span style="font-size:12px">'.$it618_credits_lang['s589'].'</span></a>]';
	}
	
	$usergroupstr=$it618_credits_lang['s215'].'<b style="color:red">'.$menuusername.'</b> '.$it618_credits_lang['s216'].'<font color="#FF6600">'.$grouptitle.'</font> '.$buygroupstr;
	
	$tmpurl_moneysum=it618_credits_getrewrite('credits_wap','moneysum','plugin.php?id=it618_credits:wap&dotype=moneysum');
	$tmpurl_sum=it618_credits_getrewrite('credits_wap','sum','plugin.php?id=it618_credits:wap&dotype=sum');
}

foreach(C::t('#it618_credits#it618_credits_focus')->fetch_all_by_type_order(13) as $it618_credits_focus) {
	if($it618_credits_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_credits_focus['it618_url'].'" target="_blank"><img class="img" src="'.it618_credits_getwapppic($it618_credits_focus['id'],$it618_credits_focus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_credits_getwapppic($it618_credits_focus['id'],$it618_credits_focus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_credits_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_credits_gonggao = DB::fetch($query)) {
	$it618_title=$it618_credits_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_credits_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_credits_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_credits_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_credits_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

if($it618_credits['waphomeico']=='')$it618_credits['waphomeico']='2|5|11|#888|6';
$waphomeico=explode("|",$it618_credits['waphomeico']);
$tmpn=$waphomeico[0];
$pppn=$waphomeico[1];
$tmpsize=$waphomeico[2];
$tmpcolor=$waphomeico[3];
$tmpw=$waphomeico[4];
$pppw=100/$pppn;
$tmpn=$tmpn*$pppn;

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_credits_iconav')." where it618_type=2 and it618_order<>0 ORDER BY it618_order");
while($it618_credits_iconav = DB::fetch($query)) {
	$it618_title=$it618_credits_iconav['it618_title'];
	
	if($it618_credits_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_credits_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_credits_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_credits_iconav['it618_color'].'">'.$it618_title.'</font>';
	}

	$str_iconav.='<td width="'.$pppw.'%"><a href="'.$it618_credits_iconav['it618_url'].'"'.$it618_target.'><img src="'.$it618_credits_iconav['it618_img'].'" /><br>'.$it618_title.'</a></td>';
	
	if($n%$pppn==0)$str_iconav.='</tr><tr>';
	if($n%$tmpn==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';

	$n=$n+1;
}

if($n>1)$n=$n-1;

if($n%$pppn>0){
	for($i=1;$i<=($pppn-$n%$pppn);$i++){
		$str_iconav.='<td width="'.$pppw.'%"></td>';
	}
}

$str_iconav.='</tr>';
$str_iconav=str_replace('<tr></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"></table></div>','',$str_iconav);
$str_iconav=str_replace('<tr><td','<tr><td width='.$tmpw.'></td><td',$str_iconav);
$str_iconav=str_replace('</td></tr>','</td><td width='.$tmpw.'></td></tr>',$str_iconav);
$str_iconav.='<style>.swiper-slide .iconav{table-layout:fixed;}.swiper-slide .iconav tr td a{color:'.$tmpcolor.';font-size:'.$tmpsize.'px}</style>';

$isiconav=count(explode('<img src',$str_iconav))-1;

$waphomead=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('waphomead');

$_G['mobiletpl'][2]='/';
include template('it618_credits:wap_credits');
?>