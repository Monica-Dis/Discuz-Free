<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_G['uid']<=0&&$_GET['dotype']!='moneysk'){
	$tmpurl_home=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
	dheader("location:$tmpurl_home");
}

if(!credits_is_mobile()){ 
	$url_this = "http://".$_SERVER ['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	$url_this=str_replace("it618_credits:wap","it618_credits:do",$url_this);
	$url_this=str_replace("credits_wap-","credits-",$url_this);
	dheader("location:$url_this");
}

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';

if($_GET['dotype']=='uc'){
	$menuusername=$_G['username'];
	$u_avatarimg=it618_credits_discuz_uc_avatar($_G['uid'],'middle');
	
	$groupid=$_G['groupid'];
	if($groupid>0)$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
	
	if($buygroup_isok==1){
		$tmpurl_buygroup=it618_credits_getrewrite('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
		$buygroupstr='[<a href="'.$tmpurl_buygroup.'"><span style="font-size:12px">'.$it618_credits_lang['s589'].'</span></a>]';
	}
	
	$usergroupstr=$it618_credits_lang['s215'].'<b style="color:red">'.$menuusername.'</b> '.$it618_credits_lang['s216'].'<font color="#FF6600">'.$grouptitle.'</font> '.$buygroupstr;
	
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php';
	}
	
	if($sk_isok==1){
		$tmpurl_skset=it618_credits_getrewrite('credits_wap','moneyskset','plugin.php?id=it618_credits:wap&dotype=moneyskset');
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php';
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php';
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php';
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php';
	}
	
	$tmpurl_uset=it618_credits_getrewrite('credits_wap','uset','plugin.php?id=it618_credits:wap&dotype=uset');
	
	if($buygroup_isok==1){
		$tmpurl_myvip=it618_credits_getrewrite('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	}
	
	$tmpurl_money=it618_credits_getrewrite('credits_wap','moneysum','plugin.php?id=it618_credits:wap&dotype=moneysum');
	$tmpurl_credits=it618_credits_getrewrite('credits_wap','credits','plugin.php?id=it618_credits:wap&dotype=credits');
	
	$tmpurl_qd=it618_credits_getrewrite('credits_wap','qd','plugin.php?id=it618_credits:wap&dotype=qd');
	$tmpurl_award=it618_credits_getrewrite('credits_wap','award','plugin.php?id=it618_credits:wap&dotype=award');
	$tmpurl_hb=it618_credits_getrewrite('credits_wap','hb','plugin.php?id=it618_credits:wap&dotype=hb');
	
	$it618_credits_qd_main=C::t('#it618_credits#it618_credits_qd_main')->fetch_by_uid($_G['uid']);
	$qd_allcount=$it618_credits_qd_main['it618_allcount'];if($qd_allcount=='')$qd_allcount=0;
	
	if($IsGroup==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
		$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	}
	
	if($IsUnion==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
		$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
	}
	
	for($i=1;$i<=11;$i++){
		if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
			$tmpstr='';$tmpurl='';
			$count=C::t('#it618_credits#it618_credits_recharge')->count_by_isok_jfid($i);
			if($count>0){
				if($tmpurl=='')$tmpurl=it618_credits_getrewrite('credits_wap','recharge@'.$i,'plugin.php?id=it618_credits:wap&dotype=recharge&ctype='.$i);
				$tmpstr.=' '.$it618_credits_lang['s237'];
			}
			
			$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok_jfid1($i);
			if($count>0){
				if($tmpurl=='')$tmpurl=it618_credits_getrewrite('credits_wap','zhuan@'.$i,'plugin.php?id=it618_credits:wap&dotype=zhuan&ctype='.$i);
				$tmpstr.=' '.$it618_credits_lang['s238'];
			}
			
			$count=C::t('#it618_credits#it618_credits_transfer')->count_by_isok_jfid($i);
			if($count>0){
				if($tmpurl=='')$tmpurl=it618_credits_getrewrite('credits_wap','transfer@'.$i,'plugin.php?id=it618_credits:wap&dotype=transfer&ctype='.$i);
				$tmpstr.=' '.$it618_credits_lang['s239'];
			}
			
			$count=C::t('#it618_credits#it618_credits_tq')->count_by_isok_jfid($i);
			if($count>0){
				if($tmpurl=='')$tmpurl=it618_credits_getrewrite('credits_wap','tq@'.$i,'plugin.php?id=it618_credits:wap&dotype=tq&ctype='.$i);
				$tmpstr.=' '.$it618_credits_lang['s1574'];
			}
			
			$count=C::t('#it618_credits#it618_credits_txbl')->count_by_isok_jfid($i);
			if($count>0){
				if($tmpurl=='')$tmpurl=it618_credits_getrewrite('credits_wap','zy@'.$i,'plugin.php?id=it618_credits:wap&dotype=zy&ctype='.$i);
				$tmpstr.=' '.$it618_credits_lang['s240'];
			}
			
			if($tmpstr!=''){
				$jfname=it618_credits_getcreditstitle($i);
				$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
				$creditsstr.='<tr class="bodytr" onClick="location.href=\''.$tmpurl.'\'"><td><img src="source/plugin/it618_credits/wap/images/ucredit.png" width="26"></td><td class="bodytd">'.$jfname.'<img src="source/plugin/it618_credits/wap/images/uc_right.png"><span>'.$tmpstr.' '.$creditnum.'</span></td></tr>';
			}
		}
	}
	
	$navtitle=$it618_credits_lang['t178'];
}

if($_GET['dotype']=='moneycz'||$_GET['dotype']=='moneyskset'||$_GET['dotype']=='moneytx'||$_GET['dotype']=='moneysum'||$_GET['dotype']=='moneypay'){
	
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	
	$topmoneymenu='<ul class="topmenu"><li style="padding-right:30px"><b style="font-size:16px;">'.$it618_credits_lang['s223'].'</b> <span style="color:red;font-size:16px;" id="spanit618_money">'.$it618_money.'</span></li>';
	
	if($_GET['dotype']=='moneypay'&&$_GET['ctype']>0){
		$tmpcss='class="current"';
		$topmoneymenu.='<li '.$tmpcss.'>'.$it618_credits_lang['s1060'].'</li><li onclick="history.back()">'.$it618_credits_lang['s1895'].'</li>';
	}else{
		if($it618_credits['credits_ismoneycz']==1){
			$tmpurl=it618_credits_getrewrite('credits_wap','moneycz','plugin.php?id=it618_credits:wap&dotype=moneycz');
			if($_GET['dotype']=='moneycz')$tmpcss='class="current"';else $tmpcss='';
			$topmoneymenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['t4'].'</li>';
		}
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php';
		}
		if($sk_isok==1){
			$tmpurl=it618_credits_getrewrite('credits_wap','moneyskset','plugin.php?id=it618_credits:wap&dotype=moneyskset');
			if($_GET['dotype']=='moneyskset')$tmpcss='class="current"';else $tmpcss='';
			$topmoneymenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['t109'].'</li>';
		}
		
		if($it618_credits['credits_ismoneytx']==1){
			$tmpurl=it618_credits_getrewrite('credits_wap','moneytx','plugin.php?id=it618_credits:wap&dotype=moneytx');
			if($_GET['dotype']=='moneytx')$tmpcss='class="current"';else $tmpcss='';
			$topmoneymenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['t5'].'</li>';
		}
		
		$moneysumurl=it618_credits_getrewrite('credits_wap','moneysum','plugin.php?id=it618_credits:wap&dotype=moneysum');
		if($_GET['dotype']=='moneysum')$tmpcss='class="current"';else $tmpcss='';
		$topmoneymenu.='<li '.$tmpcss.' onclick="location.href=\''.$moneysumurl.'\'">'.$it618_credits_lang['t8'].'</li>';
	}
	
	$topmoneymenu.='</ul>';
}

if($_GET['dotype']=='moneycz'){
	$iswx=1;
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php';
	}

	$credits_moneyczgroup=(array)unserialize($it618_credits['credits_moneyczgroup']);
	if(!in_array($_G['groupid'], $credits_moneyczgroup)&&$credits_moneyczgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s538'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	$navtitle=$it618_credits_lang['s1014'];
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php';
	}
	
	$tmpcount=$money_count;
	if($money_zsbl>0){
		$cname=it618_credits_getcreditstitle($money_zsjfid);
		$tmptips=$it618_credits_lang['s1048'].'*<font color=red>'.$money_zsbl.'%</font> '.$it618_credits_lang['s636'].$cname;
	}
	
	if($it618_credits['credits_paytype']==''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s354'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($_G['uid']>0){
		$groupid=$_G['groupid'];
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
	}
	
	if($errmsg==''){
		$sumurl=it618_credits_getrewrite('credits_wap','sum@9','plugin.php?id=it618_credits:wap&dotype=sum&ctype=9');
		
		$paycss1='none';$paycss2='none';$paycss3='none';$creditscss='none';
		
		$n=0;
		$credits_paytype=explode(",",$it618_credits['credits_paytype']);
		$credits_typecss='none';
		for($i=0;$i<count($credits_paytype);$i++){
			if($credits_paytype[$i]==1){
				if($i==0){$strtmp=' class="current"';$paycss1='';$creditscss='';}else $strtmp='';
				$credits_typecss='';
				
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" name="paytype" onclick="setselect(\'paytype\','.$n.',1)"><span>'.$it618_credits_lang['s326'].'</span><i></i></a>';
				$n=$n+1;
			}
			
			if($credits_paytype[$i]==2){
				if($i==0){$strtmp=' class="current"';$paycss2='';}else $strtmp='';
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" name="paytype" onclick="setselect(\'paytype\','.$n.',2)"><span>'.$it618_credits_lang['s327'].'</span><i></i></a>';
				$n=$n+1;
			}
			
			if($credits_paytype[$i]==3){
				if($i==0){$strtmp=' class="current"';$paycss3='';}else $strtmp='';
				$payabout=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('payabout');
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" name="paytype" onclick="setselect(\'paytype\','.$n.',3)"><span>'.$it618_credits_lang['s328'].'</span><i></i></a>';
				$n=$n+1;
			}
		}
		
		$it618_counts=$money_counts;
		$iszdycont=0;
		if($it618_counts!=''){
			$countcss=';display:none';
			$tmpcountsarr=explode(",",$it618_counts);
			for($j=0;$j<count($tmpcountsarr);$j++){
				if($tmpcountsarr[$j]!='@'){
					if($j==0)$countsjs='setselect(\'creditscounts\','.$j.','.$tmpcountsarr[$j].',0,0,0);';
					$tmpcountsstr.='<a href="javascript:void(0)" name="creditscounts" onclick="setselect(\'creditscounts\','.$j.','.$tmpcountsarr[$j].',0,0,0)">'.$tmpcountsarr[$j].'</a>';
				}else{
					$iszdycont=1;
				}
			}
		}
		
		if($iszdycont==1){
			$tmpcountsstr.='<a href="javascript:void(0)" name="creditscounts" onclick="setselect(\'creditscounts\','.$j.',\'@\',0,0,0)">'.$it618_credits_lang['s1345'].'</a>';
		}
		
		$it618paystr=it618_credits_pay('moneypaywap',$it618_credits_lang['t221']);
	}
	
	if(isset($_GET["cztype"])){
		$tmpurlarr=explode("_",$_GET["cztype"]);
		$moneysumurl=$_G['siteurl'].'plugin.php?id=it618_auction:wap&pagetype=product&cid='.intval($tmpurlarr[1]);
	}
}

if($_GET['dotype']=='moneyskset'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php';
	}
	
	if($sk_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s659'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}else{
		$flag1=0;$flag2=0;
		$credits_skgroup=(array)unserialize($it618_credits['credits_skgroup']);
		if(!in_array($_G['groupid'], $credits_skgroup)&&$credits_skgroup[0]!=''){
			$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
			$errmsg = $it618_credits_lang['s660'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
		}
		
		if($errmsg==''){
			if($it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($_G['uid'])){
				$skrname=$it618_credits_uset['it618_skname'];
			}else{
				$skrname=$_G['username'];
			}
			
			$tmpurl_sk=$_G['siteurl'].it618_credits_getrewrite('credits_wap','moneysk@'.$_G['uid'],'plugin.php?id=it618_credits:wap&dotype=moneysk&ctype='.$_G['uid']);
			
			$skurlcode=it618_credits_qrcode($tmpurl_sk);
			
			$it618_credits_set=C::t('#it618_credits#it618_credits_set')->fetch_by_setname('sksetabout');
			
			if($sk_zsbl==0){
				$skjlstr=$it618_credits_lang['t256'];
				$skjlstr=str_replace("{money}",$sk_money,$skjlstr);
				$skjlstr=str_replace("{tc}",$sk_tcbl,$skjlstr);
			}else{
				$skjlstr=$it618_credits_lang['t255'];
				$skjlstr=str_replace("{money}",$sk_money,$skjlstr);
				$skjlstr=str_replace("{tc}",$sk_tcbl,$skjlstr);
				$skjlstr=str_replace("{zsbl}",$sk_zsbl,$skjlstr);
				$jfname=it618_credits_getcreditstitle($sk_zsjfid);
				$skjlstr=str_replace("{jfname}",$jfname,$skjlstr);
			}
			
			if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_brand'")>0){
				if($it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($_G['uid'])){
					$ShopId=$it618_brand_brand['id'];
					$ShopName=$it618_brand_brand['it618_name'];
					if($it618_brand_moneyset=C::t('#it618_brand#it618_brand_moneyset')->fetch_by_shopid_ok($ShopId)){
						if($it618_brand_brand['it618_state']==2&&$it618_brand_brand['it618_htstate']==1){
							$isshop=1;
						}
					}
				}
			}
		}
	}
	
	$navtitle=$it618_credits_lang['t268'];
}

if($_GET['dotype']=='moneysk'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php';
	}
	
	if($sk_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s659'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}else{
		$uid=intval($_GET['ctype']);
		$flag=1;
		if($uid>0){
			$groupid=DB::result_first("select groupid from ".DB::table('common_member')." where uid=".$uid);
			$credits_skgroup=(array)unserialize($it618_credits['credits_skgroup']);
			if(!in_array($groupid, $credits_skgroup)&&$credits_skgroup[0]!=''){
				$flag=0;
			}
		}else{
			$flag=0;
		}
		
		if($flag==0){
			$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
			$errmsg = $it618_credits_lang['s660'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
		}
		
		if($errmsg==''){
			if($it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($uid)){
				$skrname=$it618_credits_uset['it618_skname'];
				$skruname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$uid);
				$u_avatarimg=it618_credits_discuz_uc_avatar($uid,'middle');
	
				$it618paystr=it618_credits_pay('sk',$it618_credits_lang['t221']);
				
				$it618_credits_set=C::t('#it618_credits#it618_credits_set')->fetch_by_setname('skpayabout');
			}else{
				$tmpurl=it618_credits_getrewrite('credits_wap','skset','plugin.php?id=it618_credits:wap&dotype=skset');
				$errmsg = $it618_credits_lang['s662'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s641'].'</a>';
			}
		}
	}
	
	if($skrname=='')$skrname=$it618_credits_lang['s700'];
	
	$skjlstr='<input type="hidden" id="sk_money" value="'.$sk_money.'">';
	
	if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_brand'")>0){
		if($it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($uid)){
			$ShopId=$it618_brand_brand['id'];
			$ShopName=$it618_brand_brand['it618_name'];
			$Shop_homenavname=$it618_brand_brand['it618_homenavname'];
			if($it618_brand_moneyset=C::t('#it618_brand#it618_brand_moneyset')->fetch_by_shopid_ok($ShopId)){
				if($it618_brand_brand['it618_state']==2&&$it618_brand_brand['it618_htstate']==1){
					$isshop=1;
					
					if($it618_brand_moneyset['it618_islogin']==1&&$_G['uid']<=0){
						dheader("location:member.php?mod=logging&action=login");
					}
					
					if($_G['uid']>0)$it618_zsustr=$_G['uid'];
					
					$shopwapurl=it618_credits_getrewrite_plugin('it618_brand','shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);
					$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
					$ShopPower=$it618_brand_brandgroup['it618_groupname'];
					if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" align="absmiddle" style="margin-top:-1px"/>';
					$Shop_isgoods=$it618_brand_brandgroup['it618_isgoods'];
					
					$goodscount=C::t('#it618_brand#it618_brand_goods')->count_by_shopid($ShopId, 'it618_ison=1 and it618_state=1');
					$articlecount=C::t('#it618_brand#it618_brand_article')->count_by_shopid($ShopId);
					$articlecount1=C::t('#it618_brand#it618_brand_onepage')->count_by_shopid($ShopId);
					$articlecount=$articlecount+$articlecount1;
					$imagecount=C::t('#it618_brand#it618_brand_image')->count_by_shopid($ShopId);
					
					$zsblstr=$it618_credits_lang['t323'];
					$it618_zsbl=$it618_brand_moneyset['it618_zsbl'].'%';
					$it618_num=$it618_brand_moneyset['it618_num'];
					$it618_num1=$it618_brand_moneyset['it618_num1'];
					$it618_zsbl1=$it618_brand_moneyset['it618_zsbl1'].'%';
					$it618_zsbl2=$it618_brand_moneyset['it618_zsbl2'].'%';
					$it618_zsbl3=$it618_brand_moneyset['it618_zsbl3'].'%';
					
					$zsblstr=str_replace("{zsbl}",$it618_zsbl,$zsblstr);
					$zsblstr=str_replace("{num}",$it618_num,$zsblstr);
					$zsblstr=str_replace("{num1}",$it618_num1,$zsblstr);
					$zsblstr=str_replace("{zsbl1}",$it618_zsbl1,$zsblstr);
					$zsblstr=str_replace("{zsbl2}",$it618_zsbl2,$zsblstr);
					$zsblstr=str_replace("{zsbl3}",$it618_zsbl3,$zsblstr);
					
					require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
					require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_nav.func.php';
				}
			}
		}
	}
	
	$navtitle=$it618_credits_lang['t268'];
	
	$moneysumurl=it618_credits_getrewrite('credits_wap','moneysum','plugin.php?id=it618_credits:wap&dotype=moneysum');
}

if($_GET['dotype']=='moneytx'){
	$navtitle=$it618_credits_lang['s1025'];
	$useturl=it618_credits_getrewrite('credits_wap','uset','plugin.php?id=it618_credits:wap&dotype=uset');
	
	if($it618_credits['credits_ismoneytx']==0){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s1567'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	$credits_moneytxgroup=(array)unserialize($it618_credits['credits_moneytxgroup']);
	if(!in_array($_G['groupid'], $credits_moneytxgroup)&&$credits_moneytxgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s1026'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($IsMembers==1){
		$credits_moneytxpower=(array)unserialize($it618_credits['credits_moneytxpower']);
		if(in_array(1, $credits_moneytxpower)&&$credits_moneytxpower[0]!=''&&$errmsg==''){
			if(!$it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
				$tmpurl=it618_credits_getrewrite('credits_wap','moneytx','plugin.php?id=it618_credits:wap&dotype=moneytx');
				$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=sitetelbd&preurl=".urlencode($tmpurl),"?ac=sitetelbd&preurl=".urlencode($tmpurl));
				$errmsg = $it618_credits_lang['s1857'].'<a href="'.$uhomeurl.'">'.$it618_credits_lang['s1859'].'>></a>';
			}
		}
		
		if(in_array(2, $credits_moneytxpower)&&$credits_moneytxpower[0]!=''&&$errmsg==''){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
				$tmpurl=it618_credits_getrewrite('credits_wap','moneytx','plugin.php?id=it618_credits:wap&dotype=moneytx');
				$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=rzuser&preurl=".urlencode($tmpurl),"?ac=rzuser&preurl=".urlencode($tmpurl));
				$errmsg = $it618_credits_lang['s1858'].'<a href="'.$uhomeurl.'">'.$it618_credits_lang['s1860'].'>></a>';
			}
		}
	}
	
	if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_credits_moneytxtcbl'))==0){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s1036'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$ispay=';display:none';
		$count=C::t('#it618_credits#it618_credits_uset')->countbank_by_uid($_G['uid']);
		if($count==0){
			$errmsg=$it618_credits_lang['s226'].$it618_credits_lang['s228'].'<a href="'.$useturl.'">'.$it618_credits_lang['s227'].'</a>';
		}else{
			$it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($_G['uid']);
			$tmpstyle='style="display:none"';
			if($it618_credits_uset['it618_alipayname']!=''){
				$tmpstyle='';
				$it618_txtype='alipay';
				$it618_txid=$it618_credits_uset['it618_alipay'];
				
				if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php';
				}
				
				if($alipay_isok==1){
					$alipayabout=str_replace("{count}",$alipay_txcount,$it618_credits_lang['s1033']);
					$alipayabout=str_replace("{money}",$alipay_txmoney,$alipayabout);
				}
			}
			$paytmpstr1=$it618_credits_lang['s229'].$it618_credits_uset['it618_alipayname']."\n".$it618_credits_lang['s230'].$it618_credits_uset['it618_alipay'];
			$paystr='<a '.$tmpstyle.' href="javascript:void(0)" onclick="setselect(\'paytype\',0)" name="paytype" title="'.$paytmpstr1.'"><span>'.$it618_credits_lang['s231'].'</span><i></i></a><input type="hidden" id="codeimg0" value="'.$it618_credits_uset['it618_alipaycodeimg'].'"><input type="hidden" id="txid0" value="'.$it618_credits_uset['it618_alipay'].'"><input type="hidden" id="txabout0" value="'.$alipayabout.'">';
			if($it618_credits_uset['it618_alipaycodeimg']!='')$codeimgtmpstr1=$it618_credits_uset['it618_alipaycodeimg'];
			
			$credits_txtypes=(array)unserialize($it618_credits['credits_txtypes']);
			if(in_array(1, $credits_txtypes))$txtype_wx=1;
			if(in_array(2, $credits_txtypes))$txtype_bank=1;
			if(in_array(0, $credits_txtypes)){
				$txtype_wx=0;
				$txtype_bank=0;
			}
			
			$tmpstyle='style="display:none"';
			if($it618_credits_uset['it618_wxname']!=''&&$txtype_wx==1){
				$tmpstyle='';
				if($it618_txtype==''){
					$it618_txtype='wx';
					$it618_txid=$it618_credits_uset['it618_wx'];
				}
				
				$iswx=1;
				if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;
				if($iswx==1){
					$tmpwxjs='setselect("paytype",1);';
				}
				
				$wx_isok=0;
				if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php')&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/ajax.inc.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php';
				}
				
				if($wx_isok==1||$wx_adminisok==1){
					if($wx_isok==1){
						$wxabout=str_replace("{count}",$wx_txcount,$it618_credits_lang['s1033']);
						$wxabout=str_replace("{money}",$wx_txmoney,$wxabout);
					}
					
					$n=0;
					foreach(C::t('#it618_members#it618_members_wxuser')->fetch_all_by_uid(
						$_G['uid']
					) as $it618_members_wxuser) {
						$it618_wxname=$it618_members_wxuser['it618_wxname'];
						$wxuname.='<option value="'.$it618_members_wxuser['id'].'">'.$it618_wxname.'</option>';
						$n=$n+1;
					}
					
					if($n==0){
						$wxunamestr=$it618_credits_lang['s1565'];
					}
					if($n==1){
						$wxunamestr=$it618_credits_lang['s1563'].'<input type="hidden" name="it618_wxuserid" value="'.$it618_members_wxuser['id'].'">';
						$wxunamestr=str_replace("{wxname}",$it618_wxname,$wxunamestr);
					}
					if($n>1){
						$wxunamestr=$it618_credits_lang['s1566'];
						$wxuname='<select name="it618_wxuserid" style="width:100%;color:#f60;height:26px">'.$wxuname.'</select>';
						$wxunamestr=str_replace("{wxname}",$wxuname,$wxunamestr);
						if($wx_adminisok==1){
							$wxabout.=$it618_credits_lang['s1228'];
						}
					}
				}
			}
			$paytmpstr2=$it618_credits_lang['s623'].$it618_credits_uset['it618_wxname']."\n".$it618_credits_lang['s624'].$it618_credits_uset['it618_wx'];
			$paystr.='<a '.$tmpstyle.' href="javascript:void(0)" onclick="setselect(\'paytype\',1)" name="paytype" title="'.$paytmpstr2.'"><span>'.$it618_credits_lang['s625'].'</span><i></i></a><input type="hidden" id="codeimg1" value="'.$it618_credits_uset['it618_wxpaycodeimg'].'"><input type="hidden" id="txid1" value="'.$it618_credits_uset['it618_wx'].'"><input type="hidden" id="txabout1" value="'.$wxabout.'">';
			
			if($it618_credits_uset['it618_wxpaycodeimg']!='')$codeimgtmpstr2=$it618_credits_uset['it618_wxpaycodeimg'];
			
			$tmpstyle='style="display:none"';
			if($it618_credits_uset['it618_name']!=''&&$txtype_bank==1){
				$tmpstyle='';
				if($it618_txtype==''){
					$it618_txtype='bank';
				}
			}
			$paytmpstr3=$it618_credits_lang['s232'].$it618_credits_uset['it618_name'].' '.$it618_credits_lang['s233'].$it618_credits_uset['it618_bankname'].' '.$it618_credits_lang['s234'].$it618_credits_uset['it618_bankid'].' '.$it618_credits_lang['s235'].$it618_credits_uset['it618_bankaddr'];
			$paystr.='<a '.$tmpstyle.' href="javascript:void(0)" onclick="setselect(\'paytype\',2)" name="paytype" title="'.$paytmpstr3.'"><span>'.$it618_credits_lang['s236'].'</span><i></i></a>';
			
			if($it618_credits_uset['it618_name']!='')$paytmpstr=$paytmpstr3;
			if($it618_credits_uset['it618_wxname']!='')$paytmpstr=$paytmpstr2;
			if($it618_credits_uset['it618_alipayname']!='')$paytmpstr=$paytmpstr1;
			
			if($it618_credits_uset['it618_alipayname']!='')$codeimgtmpstr=$codeimgtmpstr1;else $codeimgtmpstr=$codeimgtmpstr2;
			
			$paystr='@'.$paystr;
			$paystr=str_replace('@<a','<a class="current"',$paystr);
			$paystr='<div class="credits_type">'.$paystr.'</div>';
			$ispay=';display';
		}
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_credits_moneytxtcbl')." ORDER BY it618_num1");
		while($it618_credits_moneytxtcbl = DB::fetch($query)) {
			$txtcblstr.='<font color=red style="font-size:13px">'.$it618_credits_moneytxtcbl['it618_bl'].'</font>% <span style="font-size:11px">('.$it618_credits_moneytxtcbl['it618_num1'].$it618_credits_lang['s28'].' - '.$it618_credits_moneytxtcbl['it618_num2'].$it618_credits_lang['s28'].')</span><br>';
		}
		
		$wxnamecss='display:none';
		if($it618_txtype=='alipay')$spantx=$alipayabout;
		if($it618_txtype=='wx'){$spantx=$wxabout;$wxnamecss='';}
	}
}

if($_GET['dotype']=='moneysum'){
	$ispower=0;
	if($it618_credits['credits_wapsalepower']==$_G['uid']){
		$ispower=1;
	}
	
	$navtitle=$it618_credits_lang['s917'];
}

if($_GET['dotype']=='moneypay'){
	$saleid=intval($_GET['ctype']);
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_id($saleid)){
		if($it618_salepay['it618_state']==1){
			$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
			$errmsg = $it618_credits_lang['s1892'];
		}
	}
	
	$navtitle=$it618_credits_lang['s1060'];
}

if($_GET['dotype']=='credits'||$_GET['dotype']=='recharge'||$_GET['dotype']=='zhuan'||$_GET['dotype']=='transfer'||$_GET['dotype']=='tq'||$_GET['dotype']=='credit'||$_GET['dotype']=='zy'||$_GET['dotype']=='sum'){
	
	$topmenu='<div class="divsearchli"><ul>';
	
	$count=C::t('#it618_credits#it618_credits_recharge')->count_by_isok();
	if($count>0){
		$tmpurl=it618_credits_getrewrite('credits_wap','recharge','plugin.php?id=it618_credits:wap&dotype=recharge');
		if($_GET['dotype']=='recharge')$tmpcss='class="current"';else $tmpcss='';
		$topmenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['s237'].'</li>';
	}
	
	$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok();
	if($count>0){
		$tmpurl=it618_credits_getrewrite('credits_wap','zhuan','plugin.php?id=it618_credits:wap&dotype=zhuan');
		if($_GET['dotype']=='zhuan')$tmpcss='class="current"';else $tmpcss='';
		$topmenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['s238'].'</li>';
	}
	
	$count=C::t('#it618_credits#it618_credits_transfer')->count_by_isok();
	if($count>0){
		$tmpurl=it618_credits_getrewrite('credits_wap','transfer','plugin.php?id=it618_credits:wap&dotype=transfer');
		if($_GET['dotype']=='transfer')$tmpcss='class="current"';else $tmpcss='';
		$topmenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['s239'].'</li>';
	}
	
	$count=C::t('#it618_credits#it618_credits_tq')->count_by_isok();
	if($count>0){
		$tmpurl=it618_credits_getrewrite('credits_wap','tq','plugin.php?id=it618_credits:wap&dotype=tq');
		if($_GET['dotype']=='tq')$tmpcss='class="current"';else $tmpcss='';
		$topmenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['s1574'].'</li>';
	}
	
	if($it618_credits['credits_creditpower']==$_G['uid']){
		$tmpurl=it618_credits_getrewrite('credits_wap','credit','plugin.php?id=it618_credits:wap&dotype=credit');
		if($_GET['dotype']=='credit')$tmpcss='class="current"';else $tmpcss='';
		$topmenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['s892'].'</li>';
	}
	
	$count=C::t('#it618_credits#it618_credits_txbl')->count_by_isok();
	if($count>0){
		$tmpurl=it618_credits_getrewrite('credits_wap','zy','plugin.php?id=it618_credits:wap&dotype=zy');
		if($_GET['dotype']=='zy')$tmpcss='class="current"';else $tmpcss='';
		$topmenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['s240'].'</li>';
	}
	
	if($topmenu!=''){
		$tmpurl=it618_credits_getrewrite('credits_wap','sum','plugin.php?id=it618_credits:wap&dotype=sum');
		if($_GET['dotype']=='sum')$tmpcss='class="current"';else $tmpcss='';
		$topmenu.='<li '.$tmpcss.' onclick="location.href=\''.$tmpurl.'\'">'.$it618_credits_lang['s241'].'</li>';
	}
	
	$topmenu.='</ul></div>';
}

if($_GET['dotype']=='credits'){
	$navtitle=$it618_credits_lang['s602'];
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
	}
	
	for($i=1;$i<=11;$i++){
		if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
			$tmpstr='';
			$count=C::t('#it618_credits#it618_credits_recharge')->count_by_isok_jfid($i);
			if($count>0){
				$tmpurl=it618_credits_getrewrite('credits_wap','recharge@'.$i,'plugin.php?id=it618_credits:wap&dotype=recharge&ctype='.$i);
				$tmpstr='<a href="'.$tmpurl.'">'.$it618_credits_lang['s237'].'</a>';
			}
			
			$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok_jfid1($i);
			if($count>0){
				$tmpurl=it618_credits_getrewrite('credits_wap','zhuan@'.$i,'plugin.php?id=it618_credits:wap&dotype=zhuan&ctype='.$i);
				$tmpstr.='<a href="'.$tmpurl.'">'.$it618_credits_lang['s238'].'</a>';
			}
			
			$count=C::t('#it618_credits#it618_credits_transfer')->count_by_isok_jfid($i);
			if($count>0){
				$tmpurl=it618_credits_getrewrite('credits_wap','transfer@'.$i,'plugin.php?id=it618_credits:wap&dotype=transfer&ctype='.$i);
				$tmpstr.='<a href="'.$tmpurl.'">'.$it618_credits_lang['s239'].'</a>';
			}
			
			$count=C::t('#it618_credits#it618_credits_tq')->count_by_isok_jfid($i);
			if($count>0){
				$tmpurl=it618_credits_getrewrite('credits_wap','tq@'.$i,'plugin.php?id=it618_credits:wap&dotype=tq&ctype='.$i);
				$tmpstr.='<a href="'.$tmpurl.'">'.$it618_credits_lang['s1574'].'</a>';
			}
			
			if($it618_credits['credits_creditpower']==$_G['uid']){
				$tmpurl=it618_credits_getrewrite('credits_wap','credit@'.$i,'plugin.php?id=it618_credits:wap&dotype=credit&ctype='.$i);
				$tmpstr.='<a href="'.$tmpurl.'">'.$it618_credits_lang['s892'].'</a>';
			}
			
			$count=C::t('#it618_credits#it618_credits_txbl')->count_by_isok_jfid($i);
			if($count>0){
				$tmpurl=it618_credits_getrewrite('credits_wap','zy@'.$i,'plugin.php?id=it618_credits:wap&dotype=zy&ctype='.$i);
				$tmpstr.='<a href="'.$tmpurl.'">'.$it618_credits_lang['s240'].'</a>';
			}
			
			$tmpurl=it618_credits_getrewrite('credits_wap','sum@'.$i,'plugin.php?id=it618_credits:wap&dotype=sum&ctype='.$i);
			$tmpstr.='<a href="'.$tmpurl.'">'.$it618_credits_lang['s241'].'</a>';	
			
			if($tmpstr!=''){
				$jfname=it618_credits_getcreditstitle($i);
				$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
				
				$alltmpstr.='<tr><td class="credits"><b>'.$jfname.'</b><span>'.$creditnum.'</span> <div style="float:right">'.$tmpstr.'</div></td></tr>';
			}
		}
	}
	
	$homejfbottomdiy=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('homejfbottomdiy');
}

if($_GET['dotype']=='recharge'){
	$iswx=1;
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php';
	}

	$credits_czgroup=(array)unserialize($it618_credits['credits_czgroup']);
	if(!in_array($_G['groupid'], $credits_czgroup)&&$credits_czgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s538'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$navtitle=$it618_credits_lang['s253'];
	$count=C::t('#it618_credits#it618_credits_recharge')->count_by_isok();
	if($count==0&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s218'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($it618_credits['credits_paytype']==''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s354'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($_G['uid']>0){
		$groupid=$_G['groupid'];
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
		
		$groupzk=DB::result_first("select it618_zk from ".DB::table('it618_credits_groupzk')." where it618_groupid=".$groupid);
	}
	
	if($errmsg==''){
		$paycss1='none';$paycss2='none';$paycss3='none';$creditscss='none';
		
		$n=0;
		$credits_paytype=explode(",",$it618_credits['credits_paytype']);
		$credits_typecss='none';
		for($i=0;$i<count($credits_paytype);$i++){
			if($credits_paytype[$i]==1){
				if($i==0){$strtmp=' class="current"';$paycss1='';$creditscss='';}else $strtmp='';
				$credits_typecss='';
				
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" name="paytype" onclick="setselect(\'paytype\','.$n.',1)"><span>'.$it618_credits_lang['s326'].'</span><i></i></a>';
				$n=$n+1;
			}
			
			if($credits_paytype[$i]==2){
				if($i==0){$strtmp=' class="current"';$paycss2='';}else $strtmp='';
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" name="paytype" onclick="setselect(\'paytype\','.$n.',2)"><span>'.$it618_credits_lang['s327'].'</span><i></i></a>';
				$n=$n+1;
			}
			
			if($credits_paytype[$i]==3){
				if($i==0){$strtmp=' class="current"';$paycss3='';}else $strtmp='';
				$payabout=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('payabout');
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" name="paytype" onclick="setselect(\'paytype\','.$n.',3)"><span>'.$it618_credits_lang['s328'].'</span><i></i></a>';
				$n=$n+1;
			}
		}
		
		$it618paystr=it618_credits_pay('paywap',$it618_credits_lang['t221']);
		
		$n=0;
		$css=' class="current"';
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				if($it618_credits_recharge=C::t('#it618_credits#it618_credits_recharge')->fetch_by_isok_jfid($i)){
					$rechargebl=$it618_credits_recharge['it618_rechargebl'];
					$moneycount=$it618_credits_recharge['it618_moneycount'];
					$zsbl=$it618_credits_recharge['it618_zsbl'];
					$zsjfid=$it618_credits_recharge['it618_zsjfid'];
					$tmptitle='1 '.$jfname.' = '.$rechargebl.' '.$it618_credits_lang['s28'];
					if($zsbl>0){
						$zsjfname=it618_credits_getcreditstitle($zsjfid);
						$tmptitle.=$it618_credits_lang['s635'].'*<font color=red>'.$zsbl.'%</font> '.$it618_credits_lang['s636'].$zsjfname;
					}
					
					$groupzk=DB::result_first("select it618_zk".$i." from ".DB::table('it618_credits_groupzk')." where it618_groupid=".$groupid);
		
					if($groupzk==''||$groupzk==0){
						$groupzk=100;
					}
					
					if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
						if(intval($_GET['ctype'])==$i){
							$css=' class="current"';
							$tmptips=$tmptitle;
							$tmpbl=$rechargebl;
							$tmpcount=$moneycount;
							$tmpindex=$i;
							$tmpzk=$groupzk;
							if($tmpzk==100){
								$zkcss='style="display:none"';
							}
						}else{
							$css='';
						}
					}
					
					if($css==' class="current"')$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
					
					$tmpurl=it618_credits_getrewrite('credits_wap','recharge@'.$i,'plugin.php?id=it618_credits:wap&dotype=recharge&ctype='.$i);
					
					$tmpstr.='<a'.$css.' href="'.$tmpurl.'"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
					
					if($css!=''){
						$tmpzk=$groupzk;
						if($tmpzk==100){
							$zkcss='style="display:none"';
						}
						
						$it618_counts=$it618_credits_recharge['it618_counts'];
						$iszdycont=0;
						if($it618_counts!=''){
							$countcss=';display:none';
							$tmpcountsarr=explode(",",$it618_counts);
							for($j=0;$j<count($tmpcountsarr);$j++){
								if($tmpcountsarr[$j]!='@'){
									if($j==0)$countsjs='setselect(\'creditscounts\','.$j.','.$tmpcountsarr[$j].',0,0,0);';
									$tmpcountsstr.='<a href="javascript:void(0)" name="creditscounts" onclick="setselect(\'creditscounts\','.$j.','.$tmpcountsarr[$j].',0,0,0)">'.$tmpcountsarr[$j].'</a>';
								}else{
									$iszdycont=1;
								}
							}
						}
						
						if($iszdycont==1){
							$tmpcountsstr.='<a href="javascript:void(0)" name="creditscounts" onclick="setselect(\'creditscounts\','.$j.',\'@\',0,0,0)">'.$it618_credits_lang['s1345'].'</a>';
						}
						
						$tmptips=$tmptitle;$tmpbl=$rechargebl;$tmpcount=$moneycount;$tmpindex=$i;$css='';
					}
				}
			}
		}
	}
	$creditssumurl=it618_credits_getrewrite('credits_wap','sum','plugin.php?id=it618_credits:wap&dotype=sum');
}

if($_GET['dotype']=='zhuan'){
	$credits_zhgroup=(array)unserialize($it618_credits['credits_zhgroup']);
	if(!in_array($_G['groupid'], $credits_zhgroup)&&$credits_zhgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s539'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$navtitle=$it618_credits_lang['s254'];
	
	$ctype=intval($_GET['ctype']);
	
	if($ctype>0){
		$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok_jfid1($ctype);
	}else{
		$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok();
	}
	
	if($count==0&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s220'].$cname.$it618_credits_lang['s221'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok_jfid1($i);
				if($count>0){
					if($ctype==0){
						$ctype=$i;
					}
					$css='';
					if($ctype==$i)$css=' class="current"';
					$tmpurl=it618_credits_getrewrite('credits_wap','zhuan@'.$i,'plugin.php?id=it618_credits:wap&dotype=zhuan&ctype='.$i);
					$tmpstr1.='<a'.$css.' href="'.$tmpurl.'"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
				}
			}
		}
		
		$cname=it618_credits_getcreditstitle($ctype);
		$creditnum=it618_credits_getcreditsnum($ctype,$_G['uid']);

		$n=0;
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok_jfid1_jfid2($ctype,$i);
				if($count>0){
					$it618_credits_zhuan=C::t('#it618_credits#it618_credits_zhuan')->fetch_by_jfid1_jfid2($ctype,$i);
					$tmptitle='<font color=#390>'.$jfname.$it618_credits_lang['t215'].' = '.$cname.$it618_credits_lang['t215'].'*'.$it618_credits_zhuan['it618_zhuanbl'].'</font>';
					
					if($tmpindex==0){
						$css=' class="current"';
						$tmptips=$tmptitle;
						$tmpbl=$it618_credits_zhuan['it618_zhuanbl'];
						$tmpcount1=$it618_credits_zhuan['it618_jfcount1'];
						$tmpcount2=$it618_credits_zhuan['it618_jfcount2'];
						$tmpindex=$i;
					}else{
						$css='';
					}
					
					$tmpstr2.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.','.$it618_credits_zhuan['it618_zhuanbl'].','.$it618_credits_zhuan['it618_jfcount1'].','.$it618_credits_zhuan['it618_jfcount2'].')"  data="'.$tmptitle.'"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
				}
			}
		}
	}
}

if($_GET['dotype']=='transfer'){
	$credits_zzgroup=(array)unserialize($it618_credits['credits_zzgroup']);
	if(!in_array($_G['groupid'], $credits_zzgroup)&&$credits_zzgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s540'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$navtitle=$it618_credits_lang['s255'];
	$count=C::t('#it618_credits#it618_credits_transfer')->count_by_isok();
	if($count==0&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s222'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$sumurl=it618_credits_getrewrite('credits_wap','sum@11','plugin.php?id=it618_credits:wap&dotype=sum&ctype=11');
		$n=0;
		$css=' class="current"';
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				$count=C::t('#it618_credits#it618_credits_transfer')->count_by_isok_jfid($i);
				if($count>0){
					$it618_credits_transfer=C::t('#it618_credits#it618_credits_transfer')->fetch_by_jfid($i);
					
					if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
						if(intval($_GET['ctype'])==$i){
							$css=' class="current"';
							$tmpcount1=$it618_credits_transfer['it618_jfcount1'];
							$tmpcount2=$it618_credits_transfer['it618_jfcount2'];
							$tmpindex=$i;
						}else{
							$css='';
						}
					}
					
					if($css==' class="current"')$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
					
					$tmpstr.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.','.$it618_credits_transfer['it618_jfcount1'].','.$it618_credits_transfer['it618_jfcount2'].')"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
					if($css!=''){$tmpcount1=$it618_credits_transfer['it618_jfcount1'];$tmpcount2=$it618_credits_transfer['it618_jfcount2'];$tmpindex=$i;$css='';}
				}
			}
		}
	}
}

if($_GET['dotype']=='tq'){
	$credits_tqgroup=(array)unserialize($it618_credits['credits_tqgroup']);
	if(!in_array($_G['groupid'], $credits_tqgroup)&&$credits_tqgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s1575'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$navtitle=$it618_credits_lang['s1601'];
	$count=C::t('#it618_credits#it618_credits_tq')->count_by_isok();
	if($count==0&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s1576'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$sumurl=it618_credits_getrewrite('credits_wap','sum@11','plugin.php?id=it618_credits:wap&dotype=sum&ctype=11');
		$n=0;
		$css=' class="current"';
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				$count=C::t('#it618_credits#it618_credits_tq')->count_by_isok_jfid($i);
				if($count>0){
					$it618_credits_tq=C::t('#it618_credits#it618_credits_tq')->fetch_by_jfid($i);
					
					if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
						if(intval($_GET['ctype'])==$i){
							$css=' class="current"';
							$tmpcount1=$it618_credits_tq['it618_jfcount1'];
							$tmpcount2=$it618_credits_tq['it618_jfcount2'];
							$tmpindex=$i;
						}else{
							$css='';
						}
					}
					
					if($css==' class="current"')$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
					
					$tmpstr.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.','.$it618_credits_tq['it618_jfcount1'].','.$it618_credits_tq['it618_jfcount2'].')"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
					if($css!=''){$tmpcount1=$it618_credits_tq['it618_jfcount1'];$tmpcount2=$it618_credits_tq['it618_jfcount2'];$tmpindex=$i;$css='';}
				}
			}
		}
		
		$tqstr=C::t('#it618_credits#it618_credits_sale')->fetch_tq_by_uid_last($_G['uid']);
		$tmptqarr=explode("@@@",$tqstr);
	}
}


if($_GET['dotype']=='credit'){
	if($it618_credits['credits_creditpower']!=$_G['uid']){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s893'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$navtitle=$it618_credits_lang['s911'];
	
	if($errmsg==''){
		$sumurl1=it618_credits_getrewrite('credits_wap','sum@12','plugin.php?id=it618_credits:wap&dotype=sum&ctype=12');
		$sumurl2=it618_credits_getrewrite('credits_wap','sum@13','plugin.php?id=it618_credits:wap&dotype=sum&ctype=13');
		$n=0;
		$css=' class="current"';
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
					
				if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
					if(intval($_GET['ctype'])==$i){
						$css=' class="current"';
						$tmpindex=$i;
					}else{
						$css='';
					}
				}
				
				$tmpstr.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.')"><span>'.$jfname.'</span><i></i></a>';
				$n=$n+1;
				if($css!=''){;$tmpindex=$i;$css='';}

			}
		}
	}
}

if($_GET['dotype']=='zy'){
	$navtitle=$it618_credits_lang['s256'];

	$count=C::t('#it618_credits#it618_credits_txbl')->count_by_isok();
	if($count==0){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s225'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$credits_txgroup=(array)unserialize($it618_credits['credits_txgroup']);
	if(!in_array($_G['groupid'], $credits_txgroup)&&$credits_txgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s518'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$n=0;
		$css=' class="current"';
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				if($it618_credits_txbl=C::t('#it618_credits#it618_credits_txbl')->fetch_by_isok_jfid($i)){

					$zsbl=$it618_credits_txbl['it618_zsbl'];
					$zsjfid=$it618_credits_txbl['it618_zsjfid'];
					$tmptitle='<font color=#390> '.$it618_credits_lang['t214'].' = '.$jfname.$it618_credits_lang['t215'].' * '.$it618_credits_txbl['it618_txbl'].'</font>';
					
					if($zsbl>0){
						$zsjfname=it618_credits_getcreditstitle($i);
						$tmptitle.=$it618_credits_lang['s1220'].'*<font color=red>'.$zsbl.'%</font> '.$it618_credits_lang['s636'].$_Gzsjfname;
					}
					
					if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
						if(intval($_GET['ctype'])==$i){
							$css=' class="current"';
							$tmptips=$tmptitle;
							$tmpbl=$it618_credits_txbl['it618_txbl'];
							$tmpcount1=$it618_credits_txbl['it618_jfcount1'];
							$tmpcount2=$it618_credits_txbl['it618_jfcount2'];
							
							$tmpindex=$i;
						}else{
							$css='';
						}
					}
					
					if($css==' class="current"')$creditnum=$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
					
					$tmpstr.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.','.$it618_credits_txbl['it618_txbl'].','.$it618_credits_txbl['it618_jfcount1'].','.$it618_credits_txbl['it618_jfcount2'].')" data="'.$tmptitle.'"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
					if($css!=''){$tmptips=$tmptitle;$tmpbl=$it618_credits_txbl['it618_txbl'];$tmpcount1=$it618_credits_txbl['it618_jfcount1'];$tmpcount2=$it618_credits_txbl['it618_jfcount2'];$tmpindex=$i;$css='';}
				}
			}
		}
	}
}

if($_GET['dotype']=='sum'){
	$ispower=0;
	if($it618_credits['credits_wapsalepower']==$_G['uid']){
		$ispower=1;
	}
	
	$navtitle=$it618_credits_lang['s249'];
	
	for($i=1;$i<=8;$i++){
		if($_G['setting']['extcredits'][$i]['title']!=''){
			$ctype.='<option value='.$i.'>'.$_G['setting']['extcredits'][$i]['title'].'</option>';
		}
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
	}
	if($qf_isgold==1){
		$ctype.='<option value="11">'.$qf_goldname.'</option>';
	}

	$ctype=str_replace('<option value='.$_GET['ctype'].'>','<option value='.$_GET['ctype'].' selected="selected">',$ctype);
}

if($_GET['dotype']=='buygroup'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php';
	}
	
	if($buygroup_switchabout==''){
		$buygroup_switchabout=$it618_credits_lang['s790'];
	}

	if($buygroup_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s590'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($buygroup_saleuids==''||$buygroup_saleuids==0){
		$isallsale=1;
	}else{
		$tmparr=explode(",",$buygroup_saleuids);
		if(in_array($_G['uid'], $tmparr)){
			$isallsale=1;
		}else{
			$isallsale=0;
		}
	}
	
	$iswx=1;
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php';
	}
	
	if(isset($_GET['groupexpiry'])){
		$groupexpiry='&groupexpiry';
	}
	
	$navtitle=$it618_credits_lang['t211'];
}

if($_GET['dotype']=='uset'){
	$it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($_G['uid']);
	$navtitle=$it618_credits_lang['t306'];
	
	$credits_txtypes=(array)unserialize($it618_credits['credits_txtypes']);
	if(in_array(1, $credits_txtypes))$txtype_wx=1;
	if(in_array(2, $credits_txtypes))$txtype_bank=1;
	if(in_array(0, $credits_txtypes)){
		$txtype_wx=0;
		$txtype_bank=0;
	}
	
	if($txtype_wx==0)$txtype_wxcss='style="display:none"';
	if($txtype_bank==0)$txtype_bankcss='style="display:none"';
	
	if($it618_credits_uset['it618_alipaycodeimg']!='')$src1='src="'.$it618_credits_uset['it618_alipaycodeimg'].'"';
	if($it618_credits_uset['it618_wxpaycodeimg']!='')$src2='src="'.$it618_credits_uset['it618_wxpaycodeimg'].'"';
	
	global $oss;
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/php/aliyunossconfig.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/php/aliyunossconfig.php';
		if($it618_isok==1){
			$oss='&oss';
		}
	}
	
	$paycodeimgjs='<link rel="stylesheet" href="source/plugin/it618_credits/kindeditor/themes/default/default.css" />
			<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/kindeditor-min.js"></script>
			<script charset="utf-8" src="source/plugin/it618_credits/kindeditor/lang/zh_CN.js"></script>';
}

if($_GET['dotype']=='qd'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php';
	}
	
	if($qd_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s440'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}else{
		$tomonth = date('n');
		$todate = date('j');
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
				
		$todaycount=C::t('#it618_credits#it618_credits_qd')->count_by_time($time);
		if($todaycount>0){
			$uid=C::t('#it618_credits#it618_credits_qd')->fetch_uid_by_time($time);
			$qdnewusername=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$uid);
		}
		
		$qdabout=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('qdabout');
		
		$myqdcount=C::t('#it618_credits#it618_credits_qd')->count_by_uid_time($_G['uid'],$time);
	
		$it618_credits_qd_main=C::t('#it618_credits#it618_credits_qd_main')->fetch_by_uid($_G['uid']);
		$qd_concount=$it618_credits_qd_main['it618_concount'];if($qd_concount=='')$qd_concount=0;
		$qd_allcount=$it618_credits_qd_main['it618_allcount'];if($qd_allcount=='')$qd_allcount=0;
		
		$qdtips=$it618_credits_lang['s501'].'<font color=red>'.$qd_concount.'</font> '.$it618_credits_lang['s502'].'<font color=red>'.$qd_allcount.'</font>';
		
		$qd_creditstr='';
		for($i=1;$i<=8;$i++){
			if($qd_credit2[$i]&&$_G['setting']['extcredits'][$i]['title']!=''){
				$qd_creditstr.='<font color=red>'.$qd_credit1[$i].'</font> - <font color=red>'.$qd_credit2[$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' , ';
			}
		}
		if($qd_creditstr!=''){$qd_creditstr.='@';$qd_creditstr=str_replace(" , @","",$qd_creditstr);}
	}
	
	$navtitle=$it618_credits_lang['t170'];
}

if($_GET['dotype']=='award'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php';
	}
	if($award_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s468'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$navtitle=$it618_credits_lang['t164'];
}

if($_GET['dotype']=='hb'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php';
	}
	if($hongbao_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
		$errmsg = $it618_credits_lang['s564'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$navtitle=$it618_credits_lang['t191'];
}

$_G['mobiletpl'][2]='/';
include template('it618_credits:wap_credits');
?>