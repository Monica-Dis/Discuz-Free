<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pagetype='do';
require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits_default.func.php';

if(credits_is_mobile()){ 
	$url_this = "http://".$_SERVER ['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	$url_this=str_replace("it618_credits:do","it618_credits:wap",$url_this);
	$url_this=str_replace("credits-","credits_wap-",$url_this);
	dheader("location:$url_this");
}

if($_GET['dotype']=='moneycz'){
	$credits_moneyczgroup=(array)unserialize($it618_credits['credits_moneyczgroup']);
	if(!in_array($_G['groupid'], $credits_moneyczgroup)&&$credits_moneyczgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s538'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php';
	}
	
	$tmpcount=$money_count;
	if($money_zsbl>0){
		$cname=it618_credits_getcreditstitle($money_zsjfid);
		$tmptips=$it618_credits_lang['s1048'].'*<font color=red>'.$money_zsbl.'%</font> '.$it618_credits_lang['s636'].$cname;
	}
	
	if($it618_credits['credits_paytype']==''&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s354'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
		$n=0;
		$paycss1='none';$paycss2='none';$paycss3='none';$creditscss='none';
		$credits_paytype=explode(",",$it618_credits['credits_paytype']);
		for($i=0;$i<count($credits_paytype);$i++){
			if($credits_paytype[$i]==1){
				if($i==0){$strtmp=' class="current"';$paycss1='';$creditscss='';}else $strtmp='';
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" onclick="setselect(\'paytype\','.$i.',1)" name="paytype"><span>'.$it618_credits_lang['s326'].'</span><i></i></a>';
				$n=$n+1;	
			}
			
			if($credits_paytype[$i]==2){
				if($i==0){$strtmp=' class="current"';$paycss2='';}else $strtmp='';
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" onclick="setselect(\'paytype\','.$i.',2)" name="paytype"><span>'.$it618_credits_lang['s327'].'</span><i></i></a>';
				$n=$n+1;	
			}
			
			if($credits_paytype[$i]==3){
				if($i==0){$strtmp=' class="current"';$paycss3='';}else $strtmp='';
				$payabout=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('payabout');
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" onclick="setselect(\'paytype\','.$i.',3)" name="paytype"><span>'.$it618_credits_lang['s328'].'</span><i></i></a>';
				$n=$n+1;	
			}
		}
		
		if($n==1)$paystr='';
		
		$it618_counts=$money_counts;
		$iszdycont=0;
		if($it618_counts!=''){
			$countcss=';display:none';
			$tmpcountsarr=explode(",",$it618_counts);
			for($j=0;$j<count($tmpcountsarr);$j++){
				if($tmpcountsarr[$j]!='@'){
					if($j==0)$countsjs='setselect(\'creditscounts\','.$j.','.$tmpcountsarr[$j].',0,0,0);';
					$tmpcountsstr.='<a href="javascript:void(0)" name="creditscounts" onclick="setselect(\'creditscounts\','.$j.','.$tmpcountsarr[$j].',0,0,0)">'.$tmpcountsarr[$j].'</a>';
				}else{
					$iszdycont=1;
				}
			}
		}
		
		if($iszdycont==1){
			$tmpcountsstr.='<a href="javascript:void(0)" name="creditscounts" onclick="setselect(\'creditscounts\','.$j.',\'@\',0,0,0)">'.$it618_credits_lang['s1345'].'</a>';
		}
		
		$it618paystr=it618_credits_pay('moneypay',$it618_credits_lang['t221']);
		
		$groupid=$_G['groupid'];
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
	}
	
	$moneysumurl=it618_credits_getrewrite('credits_home','moneysum','plugin.php?id=it618_credits:do&dotype=moneysum');
}

if($_GET['dotype']=='moneysk'){
	$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
	dheader("location:$tmpurl");
}

if($_GET['dotype']=='moneytx'){
	$navtitle=$it618_credits_lang['s1025'];
	$useturl=it618_credits_getrewrite('credits_home','uset','plugin.php?id=it618_credits:do&dotype=uset');
	
	if($it618_credits['credits_ismoneytx']==0){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s1567'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	$credits_moneytxgroup=(array)unserialize($it618_credits['credits_moneytxgroup']);
	if(!in_array($_G['groupid'], $credits_moneytxgroup)&&$credits_moneytxgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s1026'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($IsMembers==1){
		$credits_moneytxpower=(array)unserialize($it618_credits['credits_moneytxpower']);
		if(in_array(1, $credits_moneytxpower)&&$credits_moneytxpower[0]!=''&&$errmsg==''){
			if(!$it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
				$it618_members_telbd=it618_members_getmembers($_GET['id'],'#it618_members_telbd_credits','plugin.php?id=it618_members:home&ac=salebdtel').'<div id="it618_members_telbd_credits"></div>';
				$errmsg = $it618_credits_lang['s1857'].'<a href="javascript:" onclick="IT618_CREDITS(\'#it618_members_telbd_credits\').click();">'.$it618_credits_lang['s1859'].'>></a>'.$it618_members_telbd;
			}
		}
		
		if(in_array(2, $credits_moneytxpower)&&$credits_moneytxpower[0]!=''&&$errmsg==''){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
				$it618_members_rzuser=it618_members_getmembers($_GET['id'],'#it618_members_rzuser_credits','plugin.php?id=it618_members:home&ac=rzuser').'<div id="it618_members_rzuser_credits"></div>';
				$errmsg = $it618_credits_lang['s1858'].'<a href="javascript:" onclick="IT618_CREDITS(\'#it618_members_rzuser_credits\').click();">'.$it618_credits_lang['s1860'].'>></a>'.$it618_members_rzuser;
			}
		}
	}
	
	if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_credits_moneytxtcbl'))==0){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s1036'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
		
		$ispay=';display:none';
		$count=C::t('#it618_credits#it618_credits_uset')->countbank_by_uid($_G['uid']);
		if($count==0){
			$errmsg=$it618_credits_lang['s226'].$it618_credits_lang['s228'].'<a href="'.$useturl.'">'.$it618_credits_lang['s227'].'</a>';
		}else{
			$it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($_G['uid']);
			$tmpstyle='style="display:none"';
			if($it618_credits_uset['it618_alipayname']!=''){
				$tmpstyle='';
				$it618_txtype='alipay';
				$it618_txid=$it618_credits_uset['it618_alipay'];
				
				if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php';
				}
				
				if($alipay_isok==1){
					$alipayabout=str_replace("{count}",$alipay_txcount,$it618_credits_lang['s1033']);
					$alipayabout=str_replace("{money}",$alipay_txmoney,$alipayabout);
				}
			}
			$paytmpstr1=$it618_credits_lang['s229'].$it618_credits_uset['it618_alipayname']."\n".$it618_credits_lang['s230'].$it618_credits_uset['it618_alipay'];
			$paystr='<a '.$tmpstyle.' href="javascript:void(0)" onclick="setselect(\'paytype\',0)" name="paytype" title="'.$paytmpstr1.'"><span>'.$it618_credits_lang['s231'].'</span><i></i></a><input type="hidden" id="codeimg0" value="'.$it618_credits_uset['it618_alipaycodeimg'].'"><input type="hidden" id="txid0" value="'.$it618_credits_uset['it618_alipay'].'"><input type="hidden" id="txabout0" value="'.$alipayabout.'">';
			if($it618_credits_uset['it618_alipaycodeimg']!='')$codeimgtmpstr1=$it618_credits_uset['it618_alipaycodeimg'];
			
			$credits_txtypes=(array)unserialize($it618_credits['credits_txtypes']);
			if(in_array(1, $credits_txtypes))$txtype_wx=1;
			if(in_array(2, $credits_txtypes))$txtype_bank=1;
			if(in_array(0, $credits_txtypes)){
				$txtype_wx=0;
				$txtype_bank=0;
			}
			
			$tmpstyle='style="display:none"';
			if($it618_credits_uset['it618_wxname']!=''&&$txtype_wx==1){
				$tmpstyle='';
				if($it618_txtype==''){
					$it618_txtype='wx';
					$it618_txid=$it618_credits_uset['it618_wx'];
				}
				
				if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php')&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/ajax.inc.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php';
				}
				
				if($wx_isok==1||$wx_adminisok==1){
					if($wx_isok==1){
						$wxabout=str_replace("{count}",$wx_txcount,$it618_credits_lang['s1033']);
						$wxabout=str_replace("{money}",$wx_txmoney,$wxabout);
					}
					
					$n=0;
					foreach(C::t('#it618_members#it618_members_wxuser')->fetch_all_by_uid(
						$_G['uid']
					) as $it618_members_wxuser) {
						$it618_wxname=$it618_members_wxuser['it618_wxname'];
						$wxuname.='<option value="'.$it618_members_wxuser['id'].'">'.$it618_wxname.'</option>';
						$n=$n+1;
					}
					
					if($n==0){
						$wxunamestr=$it618_credits_lang['s1565'];
					}
					if($n==1){
						$wxunamestr=$it618_credits_lang['s1563'].'<input type="hidden" name="it618_wxuserid" value="'.$it618_members_wxuser['id'].'">';
						$wxunamestr=str_replace("{wxname}",$it618_wxname,$wxunamestr);
					}
					if($n>1){
						$wxunamestr=$it618_credits_lang['s1564'];
						$wxuname='<select name="it618_wxuserid">'.$wxuname.'</select>';
						$wxunamestr=str_replace("{wxname}",$wxuname,$wxunamestr);
						if($wx_adminisok==1){
							$wxabout.=$it618_credits_lang['s1228'];
						}
					}
					
				}
			}
			$paytmpstr2=$it618_credits_lang['s623'].$it618_credits_uset['it618_wxname']."\n".$it618_credits_lang['s624'].$it618_credits_uset['it618_wx'];
			$paystr.='<a '.$tmpstyle.' href="javascript:void(0)" onclick="setselect(\'paytype\',1)" name="paytype" title="'.$paytmpstr2.'"><span>'.$it618_credits_lang['s625'].'</span><i></i></a><input type="hidden" id="codeimg1" value="'.$it618_credits_uset['it618_wxpaycodeimg'].'"><input type="hidden" id="txid1" value="'.$it618_credits_uset['it618_wx'].'"><input type="hidden" id="txabout1" value="'.$wxabout.'">';
			if($it618_credits_uset['it618_wxpaycodeimg']!='')$codeimgtmpstr2=$it618_credits_uset['it618_wxpaycodeimg'];
			
			$tmpstyle='style="display:none"';
			if($it618_credits_uset['it618_name']!=''&&$txtype_bank==1){
				$tmpstyle='';
				if($it618_txtype==''){
					$it618_txtype='bank';
				}
			}
			$paytmpstr3=$it618_credits_lang['s232'].$it618_credits_uset['it618_name'].' '.$it618_credits_lang['s233'].$it618_credits_uset['it618_bankname'].' '.$it618_credits_lang['s234'].$it618_credits_uset['it618_bankid'].' '.$it618_credits_lang['s235'].$it618_credits_uset['it618_bankaddr'];
			$paystr.='<a '.$tmpstyle.' href="javascript:void(0)" onclick="setselect(\'paytype\',2)" name="paytype" title="'.$paytmpstr3.'"><span>'.$it618_credits_lang['s236'].'</span><i></i></a>';
			
			if($it618_credits_uset['it618_name']!='')$paytmpstr=$paytmpstr3;
			if($it618_credits_uset['it618_wxname']!='')$paytmpstr=$paytmpstr2;
			if($it618_credits_uset['it618_alipayname']!='')$paytmpstr=$paytmpstr1;
			
			if($it618_credits_uset['it618_alipayname']!='')$codeimgtmpstr=$codeimgtmpstr1;else $codeimgtmpstr=$codeimgtmpstr2;
			
			$paystr='@'.$paystr;
			$paystr=str_replace('@<a','<a class="current"',$paystr);
			$paystr='<div class="credits_type">'.$paystr.'</div>';
			$ispay=';display';
		}
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_credits_moneytxtcbl')." ORDER BY it618_num1");
		while($it618_credits_moneytxtcbl = DB::fetch($query)) {
			$txtcblstr.='<font color=red>'.$it618_credits_moneytxtcbl['it618_bl'].'</font>% ('.$it618_credits_moneytxtcbl['it618_num1'].$it618_credits_lang['s28'].' - '.$it618_credits_moneytxtcbl['it618_num2'].$it618_credits_lang['s28'].')<br>';
		}
		
		$wxnamecss='display:none';
		if($it618_txtype=='alipay')$spantx=$alipayabout;
		if($it618_txtype=='wx'){$spantx=$wxabout;$wxnamecss='';}
	}
}

if($_GET['dotype']=='moneypay'){
	$saleid=intval($_GET['ctype']);
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_id($saleid)){
		if($it618_salepay['it618_state']==1||$it618_salepay['it618_uid']!=$_G['uid']){
			$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
			$errmsg = $it618_credits_lang['s1892'];
		}
	}
	
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	
	$url=$it618_salepay['it618_url'];
	$body=$it618_salepay['it618_body'];
	$total_fee=$it618_salepay['it618_total_fee'];
}

if($_GET['dotype']=='recharge'){
	$credits_czgroup=(array)unserialize($it618_credits['credits_czgroup']);
	if(!in_array($_G['groupid'], $credits_czgroup)&&$credits_czgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s538'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$count=C::t('#it618_credits#it618_credits_recharge')->count_by_isok();
	if($count==0&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s218'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($it618_credits['credits_paytype']==''&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s354'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$n=0;
		$paycss1='none';$paycss2='none';$paycss3='none';$creditscss='none';
		$credits_paytype=explode(",",$it618_credits['credits_paytype']);
		for($i=0;$i<count($credits_paytype);$i++){
			if($credits_paytype[$i]==1){
				if($i==0){$strtmp=' class="current"';$paycss1='';$creditscss='';}else $strtmp='';
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" onclick="setselect(\'paytype\','.$i.',1)" name="paytype"><span>'.$it618_credits_lang['s326'].'</span><i></i></a>';
				$n=$n+1;	
			}
			
			if($credits_paytype[$i]==2){
				if($i==0){$strtmp=' class="current"';$paycss2='';}else $strtmp='';
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" onclick="setselect(\'paytype\','.$i.',2)" name="paytype"><span>'.$it618_credits_lang['s327'].'</span><i></i></a>';
				$n=$n+1;	
			}
			
			if($credits_paytype[$i]==3){
				if($i==0){$strtmp=' class="current"';$paycss3='';}else $strtmp='';
				$payabout=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('payabout');
				$paystr.='<a'.$strtmp.' href="javascript:void(0)" onclick="setselect(\'paytype\','.$i.',3)" name="paytype"><span>'.$it618_credits_lang['s328'].'</span><i></i></a>';
				$n=$n+1;	
			}
		}
		
		if($n==1)$paystr='';
		
		$it618paystr=it618_credits_pay('pay',$it618_credits_lang['t221']);
		
		$groupid=$_G['groupid'];
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
		
		$n=0;
		$css=' class="current"';
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				
				if($it618_credits_recharge=C::t('#it618_credits#it618_credits_recharge')->fetch_by_isok_jfid($i)){
					$rechargebl=$it618_credits_recharge['it618_rechargebl'];
					$moneycount=$it618_credits_recharge['it618_moneycount'];
					$zsbl=$it618_credits_recharge['it618_zsbl'];
					$zsjfid=$it618_credits_recharge['it618_zsjfid'];

					$tmptitle='<font color=#390>1 '.$jfname.' = '.$rechargebl.' '.$it618_credits_lang['s28'].'</font>';
					if($zsbl>0){
						$zsjfname=it618_credits_getcreditstitle($zsjfid);
						$tmptitle.=$it618_credits_lang['s635'].'*<font color=red>'.$zsbl.'%</font> '.$it618_credits_lang['s636'].$zsjfname;
					}
					
					$groupzk=DB::result_first("select it618_zk".$i." from ".DB::table('it618_credits_groupzk')." where it618_groupid=".$groupid);
		
					if($groupzk==''||$groupzk==0){
						$groupzk=100;
					}
					
					if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
						if(intval($_GET['ctype'])==$i){
							$css=' class="current"';
							$tmptips=$tmptitle;
							$tmpbl=$rechargebl;
							$tmpcount=$moneycount;
							$tmpindex=$i;
							$tmpzk=$groupzk;
							if($tmpzk==100){
								$zkcss='style="display:none"';
							}
						}else{
							$css='';
						}
					}
					
					if($css==' class="current"'){
						if($i<=8){
							$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
						}else{
							if($i==11){
								$qfdata=it618_credits_qianfan('read',$_G['uid']);
								if($qfdata['status']==1){
									$creditnum=$qfdata['data']['gold'];
								}
							}
						}
					}
					
					$tmpurl=it618_credits_getrewrite('credits_home','recharge@'.$i,'plugin.php?id=it618_credits:do&dotype=recharge&ctype='.$i);
					
					$tmpstr.='<a'.$css.' href="'.$tmpurl.'"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
					if($css!=''){
						$tmpzk=$groupzk;
						if($tmpzk==100){
							$zkcss='style="display:none"';
						}

						$it618_counts=$it618_credits_recharge['it618_counts'];
						$iszdycont=0;
						if($it618_counts!=''){
							$countcss=';display:none';
							$tmpcountsarr=explode(",",$it618_counts);
							for($j=0;$j<count($tmpcountsarr);$j++){
								if($tmpcountsarr[$j]!='@'){
									if($j==0)$countsjs='setselect(\'creditscounts\','.$j.','.$tmpcountsarr[$j].',0,0,0);';
									$tmpcountsstr.='<a href="javascript:void(0)" name="creditscounts" onclick="setselect(\'creditscounts\','.$j.','.$tmpcountsarr[$j].',0,0,0)">'.$tmpcountsarr[$j].'</a>';
								}else{
									$iszdycont=1;
								}
							}
						}
						
						if($iszdycont==1){
							$tmpcountsstr.='<a href="javascript:void(0)" name="creditscounts" onclick="setselect(\'creditscounts\','.$j.',\'@\',0,0,0)">'.$it618_credits_lang['s1345'].'</a>';
						}
						
						$tmptips=$tmptitle;$tmpbl=$rechargebl;$tmpcount=$moneycount;$tmpindex=$i;$css='';
					}
				}
			}
		}
	}
	
	$sumtmpurl=it618_credits_getrewrite('credits_home','sum@0','plugin.php?id=it618_credits:do&dotype=sum');
}

if($_GET['dotype']=='zhuan'){
	$credits_zhgroup=(array)unserialize($it618_credits['credits_zhgroup']);
	if(!in_array($_G['groupid'], $credits_zhgroup)&&$credits_zhgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s539'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$ctype=intval($_GET['ctype']);
	$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok_jfid1($ctype);
	$cname=it618_credits_getcreditstitle($ctype);
	if($count==0&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s220'].$cname.$it618_credits_lang['s221'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$n=0;
		$creditnum=it618_credits_getcreditsnum($ctype,$_G['uid']);
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok_jfid1_jfid2($ctype,$i);
				if($count>0){
					$jfname=it618_credits_getcreditstitle($i);
					$it618_credits_zhuan=C::t('#it618_credits#it618_credits_zhuan')->fetch_by_jfid1_jfid2($ctype,$i);
					$tmptitle='<font color=#390>'.$jfname.$it618_credits_lang['t215'].' = '.$cname.$it618_credits_lang['t215'].'*'.$it618_credits_zhuan['it618_zhuanbl'].'</font>';
					
					if($tmpindex==0){
						$css=' class="current"';
						$tmptips=$tmptitle;
						$tmpbl=$it618_credits_zhuan['it618_zhuanbl'];
						$tmpcount1=$it618_credits_zhuan['it618_jfcount1'];
						$tmpcount2=$it618_credits_zhuan['it618_jfcount2'];
						$tmpindex=$i;
					}else{
						$css='';
					}
					
					$tmpstr.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.','.$it618_credits_zhuan['it618_zhuanbl'].','.$it618_credits_zhuan['it618_jfcount1'].','.$it618_credits_zhuan['it618_jfcount2'].')"  data="'.$tmptitle.'"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
				}
			}
		}
	}
}

if($_GET['dotype']=='transfer'){
	$credits_zzgroup=(array)unserialize($it618_credits['credits_zzgroup']);
	if(!in_array($_G['groupid'], $credits_zzgroup)&&$credits_zzgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s540'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$count=C::t('#it618_credits#it618_credits_transfer')->count_by_isok();
	if($count==0&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s222'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$n=0;
		$css=' class="current"';
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				$count=C::t('#it618_credits#it618_credits_transfer')->count_by_isok_jfid($i);
				if($count>0){
					$it618_credits_transfer=C::t('#it618_credits#it618_credits_transfer')->fetch_by_jfid($i);
					
					if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
						if(intval($_GET['ctype'])==$i){
							$css=' class="current"';
							$tmpcount1=$it618_credits_transfer['it618_jfcount1'];
							$tmpcount2=$it618_credits_transfer['it618_jfcount2'];
							$tmpindex=$i;
						}else{
							$css='';
						}
					}
					
					if($css==' class="current"')$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
					
					$tmpstr.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.','.$it618_credits_transfer['it618_jfcount1'].','.$it618_credits_transfer['it618_jfcount2'].')"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
					if($css!=''){$tmpcount1=$it618_credits_transfer['it618_jfcount1'];$tmpcount2=$it618_credits_transfer['it618_jfcount2'];$tmpindex=$i;$css='';}
				}
			}
		}
	}
}

if($_GET['dotype']=='tq'){
	$credits_tqgroup=(array)unserialize($it618_credits['credits_tqgroup']);
	if(!in_array($_G['groupid'], $credits_tqgroup)&&$credits_tqgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s1575'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	$count=C::t('#it618_credits#it618_credits_tq')->count_by_isok();
	if($count==0&&$errmsg==''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s1576'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$n=0;
		$css=' class="current"';
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				$count=C::t('#it618_credits#it618_credits_tq')->count_by_isok_jfid($i);
				if($count>0){
					$it618_credits_tq=C::t('#it618_credits#it618_credits_tq')->fetch_by_jfid($i);
					
					if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
						if(intval($_GET['ctype'])==$i){
							$css=' class="current"';
							$tmpcount1=$it618_credits_tq['it618_jfcount1'];
							$tmpcount2=$it618_credits_tq['it618_jfcount2'];
							$tmpindex=$i;
						}else{
							$css='';
						}
					}
					
					if($css==' class="current"')$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
					
					$tmpstr.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.','.$it618_credits_tq['it618_jfcount1'].','.$it618_credits_tq['it618_jfcount2'].')"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
					if($css!=''){$tmpcount1=$it618_credits_tq['it618_jfcount1'];$tmpcount2=$it618_credits_tq['it618_jfcount2'];$tmpindex=$i;$css='';}
				}
			}
		}
		
		$tqstr=C::t('#it618_credits#it618_credits_sale')->fetch_tq_by_uid_last($_G['uid']);
		$tmptqarr=explode("@@@",$tqstr);
	}
}

if($_GET['dotype']=='credit'){
	if($it618_credits['credits_creditpower']!=$_G['uid']){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s893'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$n=0;
		$css=' class="current"';
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
					
				if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
					if(intval($_GET['ctype'])==$i){
						$css=' class="current"';
						$tmpindex=$i;
					}else{
						$css='';
					}
				}
				
				$tmpstr.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.')"><span>'.$jfname.'</span><i></i></a>';
				$n=$n+1;
				if($css!=''){;$tmpindex=$i;$css='';}

			}
		}
	}
}

if($_GET['dotype']=='zy'){
	$credits_txgroup=(array)unserialize($it618_credits['credits_txgroup']);
	
	$count=C::t('#it618_credits#it618_credits_txbl')->count_by_isok();
	if($count==0){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s225'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if(!in_array($_G['groupid'], $credits_txgroup)&&$credits_txgroup[0]!=''){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s518'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($errmsg==''){
		$n=0;
		$css=' class="current"';
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
		}
		
		for($i=1;$i<=11;$i++){
			if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
				$jfname=it618_credits_getcreditstitle($i);
				if($it618_credits_txbl=C::t('#it618_credits#it618_credits_txbl')->fetch_by_isok_jfid($i)){

					$zsbl=$it618_credits_txbl['it618_zsbl'];
					$zsjfid=$it618_credits_txbl['it618_zsjfid'];
					$tmptitle='<font color=#390> '.$it618_credits_lang['t214'].' = '.$jfname.$it618_credits_lang['t215'].' * '.$it618_credits_txbl['it618_txbl'].'</font>';

					if($zsbl>0){
						$zsjfname=it618_credits_getcreditstitle($zsjfid);
						$tmptitle.=$it618_credits_lang['s1220'].'*<font color=red>'.$zsbl.'%</font> '.$it618_credits_lang['s636'].$zsjfname;
					}
					
					if(isset($_GET['ctype'])&&intval($_GET['ctype'])>0){
						if(intval($_GET['ctype'])==$i){
							$css=' class="current"';
							$tmptips=$tmptitle;
							$tmpbl=$it618_credits_txbl['it618_txbl'];
							$tmpcount1=$it618_credits_txbl['it618_jfcount1'];
							$tmpcount2=$it618_credits_txbl['it618_jfcount2'];
							
							$tmpindex=$i;
						}else{
							$css='';
						}
					}
					
					if($css==' class="current"')$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
					
					$tmpstr.='<a'.$css.' href="javascript:void(0)" name="creditstype" onclick="setselect(\'creditstype\','.$n.','.$i.','.$it618_credits_txbl['it618_txbl'].','.$it618_credits_txbl['it618_jfcount1'].','.$it618_credits_txbl['it618_jfcount2'].')" data="'.$tmptitle.'"><span>'.$jfname.'</span><i></i></a>';
					$n=$n+1;
					if($css!=''){$tmptips=$tmptitle;$tmpbl=$it618_credits_txbl['it618_txbl'];$tmpcount1=$it618_credits_txbl['it618_jfcount1'];$tmpcount2=$it618_credits_txbl['it618_jfcount2'];$tmpindex=$i;$css='';}
				}
			}
		}
	}
}

if($_GET['dotype']=='buygroup'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php';
	}
	
	if($buygroup_switchabout==''){
		$buygroup_switchabout=$it618_credits_lang['s790'];
	}
	
	if($buygroup_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s590'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
	
	if($buygroup_saleuids==''||$buygroup_saleuids==0){
		$isallsale=1;
	}else{
		$tmparr=explode(",",$buygroup_saleuids);
		if(in_array($_G['uid'], $tmparr)){
			$isallsale=1;
		}else{
			$isallsale=0;
		}
	}
	
	if(isset($_GET['groupexpiry'])){
		$groupexpiry='&groupexpiry';
	}
}

if($_GET['dotype']=='uset'){
	$it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($_G['uid']);
	
	$credits_txtypes=(array)unserialize($it618_credits['credits_txtypes']);
	if(in_array(1, $credits_txtypes))$txtype_wx=1;
	if(in_array(2, $credits_txtypes))$txtype_bank=1;
	if(in_array(0, $credits_txtypes)){
		$txtype_wx=0;
		$txtype_bank=0;
	}
	
	if($txtype_wx==0)$txtype_wxcss='style="display:none"';
	if($txtype_bank==0)$txtype_bankcss='style="display:none"';
	
	if($it618_credits_uset['it618_alipaycodeimg']!='')$src1='src="'.$it618_credits_uset['it618_alipaycodeimg'].'"';
	if($it618_credits_uset['it618_wxpaycodeimg']!='')$src2='src="'.$it618_credits_uset['it618_wxpaycodeimg'].'"';
	
	global $oss;
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/php/aliyunossconfig.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/php/aliyunossconfig.php';
		if($it618_isok==1){
			$oss='&oss';
		}
	}
	
	$tmpcharset='charset="utf-8"';
}

if($_GET['dotype']=='qd'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php';
	}
	
	if($qd_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s440'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}else{
		$qdabout=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('qdabout');
	
		$it618_credits_qd_main=C::t('#it618_credits#it618_credits_qd_main')->fetch_by_uid($_G['uid']);
		$qd_concount=$it618_credits_qd_main['it618_concount'];if($qd_concount=='')$qd_concount=0;
		$qd_allcount=$it618_credits_qd_main['it618_allcount'];if($qd_allcount=='')$qd_allcount=0;
		
		$qdtips=$it618_credits_lang['s501'].'<font color=red>'.$qd_concount.'</font> '.$it618_credits_lang['s502'].'<font color=red>'.$qd_allcount.'</font>';
		
		$qd_creditstr='';
		for($i=1;$i<=8;$i++){
			if($qd_credit2[$i]&&$_G['setting']['extcredits'][$i]['title']!=''){
				$qd_creditstr.='<font color=red>'.$qd_credit1[$i].'</font> - <font color=red>'.$qd_credit2[$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' , ';
			}
		}
		if($qd_creditstr!=''){$qd_creditstr.='@';$qd_creditstr=str_replace(" , @","",$qd_creditstr);}
	}
}

if($_GET['dotype']=='award'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php';
	}
	if($award_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s468'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
}

if($_GET['dotype']=='hb'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php';
	}
	if($hongbao_isok==0){
		$tmpurl=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');
		$errmsg = $it618_credits_lang['s564'].'<a href="'.$tmpurl.'">'.$it618_credits_lang['s219'].'</a>';
	}
}

if($_GET['dotype']=='sum'){
	for($i=1;$i<=8;$i++){
		if($_G['setting']['extcredits'][$i]['title']!=''){
			$ctype.='<option value='.$i.'>'.$_G['setting']['extcredits'][$i]['title'].'</option>';
		}
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
	}
	if($qf_isgold==1){
		$ctype.='<option value="11">'.$qf_goldname.'</option>';
	}

	$ctype=str_replace('<option value='.$_GET['ctype'].'>','<option value='.$_GET['ctype'].' selected="selected">',$ctype);
}

$moneysumurl=it618_credits_getrewrite('credits_home','moneysum','plugin.php?id=it618_credits:do&dotype=moneysum');
$tmpurl_sum=it618_credits_getrewrite('credits_home','sum','plugin.php?id=it618_credits:do&dotype=sum');

$_G['mobiletpl'][2]='/';
include template('it618_credits:credits_default');
?>