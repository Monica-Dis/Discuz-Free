<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_credits = $_G['cache']['plugin']['it618_credits'];
$metatitle = $it618_credits['seotitle'];
$navtitle = $it618_credits['seotitle'];
$metakeywords = $it618_credits['seokeywords'];
$metadescription = $it618_credits['seodescription'];

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';

$istx=0;
$count=C::t('#it618_credits#it618_credits_txbl')->count_by_isok();
if($count>0){
	$istx=1;
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php';
}

$tmpurl_buygroup=it618_credits_getrewrite('credits_home','buygroup','plugin.php?id=it618_credits:do&dotype=buygroup');
$tmpurl_sum=it618_credits_getrewrite('credits_home','sum','plugin.php?id=it618_credits:do&dotype=sum');
$tmpurl_uset=it618_credits_getrewrite('credits_home','uset','plugin.php?id=it618_credits:do&dotype=uset');
$tmpurl_qd=it618_credits_getrewrite('credits_home','qd','plugin.php?id=it618_credits:do&dotype=qd');
$tmpurl_award=it618_credits_getrewrite('credits_home','award','plugin.php?id=it618_credits:do&dotype=award');
$tmpurl_hb=it618_credits_getrewrite('credits_home','hb','plugin.php?id=it618_credits:do&dotype=hb');
$tmpurl_moneysum=it618_credits_getrewrite('credits_home','moneysum','plugin.php?id=it618_credits:do&dotype=moneysum');

$tmpurl_home=it618_credits_getrewrite('credits_home','','plugin.php?id=it618_credits:index');

if($_G['uid']>0){

	$menuusername=$_G['username'];
	
	$groupid=$_G['groupid'];
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);

	if($buygroup_isok==1){
		$buygroupstr='[&nbsp;<a href="'.$tmpurl_buygroup.'"><font color="#F30">'.$it618_credits_lang['s589'].'</font></a>]';
	}
	
	if($it618_credits['credits_creditpower']==$_G['uid']){
		$tmpurl=it618_credits_getrewrite('credits_home','credit','plugin.php?id=it618_credits:do&dotype=credit');
		$creditpower='<span class="split">|</span><a href="'.$tmpurl.'">'.$it618_credits_lang['s892'].'</a>';
	}
	
	$usergroupstr=$it618_credits_lang['s215'].'<font color="#F30">'.$menuusername.'</font> '.$grouptitle.$buygroupstr.$creditpower;
}else{
	$RegName=$_G['setting']['regname'];
	$regurl	="member.php?mod=$RegName";		
}
?>