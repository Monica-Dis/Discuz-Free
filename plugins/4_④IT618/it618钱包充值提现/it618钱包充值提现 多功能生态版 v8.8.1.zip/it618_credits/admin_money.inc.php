<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

if($reabc[4]!='8')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function/it618_credits.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_money&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_moneycz_set', 'admin_moneysk_set', 'admin_moneytx_set', 'admin_moneysum', 'admin_transalipay');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_moneycz_set' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_moneycz_set'.$urls.'"><span>'.$it618_credits_lang['s902'].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_moneysk_set'.$urls.'"><span>'.$it618_credits_lang['s641'].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_moneytx_set'.$urls.'"><span>'.$it618_credits_lang['s355'].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_moneysum'.$urls.'"><span>'.$it618_credits_lang['s917'].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_transalipay'.$urls.'"><span>'.$it618_credits_lang['s1269'].'</span></a></li>
</ul></div>';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();
?>