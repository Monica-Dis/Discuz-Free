<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pagetype='index';
require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits_default.func.php';

if(credits_is_mobile()){ 
	$tmpurl=it618_credits_getrewrite('credits_wap','','plugin.php?id=it618_credits:wap');
	dheader("location:$tmpurl");
}

$isactive=$it618_credits['credits_isactive'];
if($it618_credits['credits_wapsalepower']==$_G['uid'])$isadmin=1;
if($_G['uid']==0&&$isactive>0)$isuserall=1;

if($qd_isok==1){
	$it618_credits_qd_main=C::t('#it618_credits#it618_credits_qd_main')->fetch_by_uid($_G['uid']);
	$qd_allcount=$it618_credits_qd_main['it618_allcount'];if($qd_allcount=='')$qd_allcount=0;
	
	$tomonth = date('n');
	$todate = date('j');
	$toyear = date('Y');
	$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
	
	$myqdcount=C::t('#it618_credits#it618_credits_qd')->count_by_uid_time($_G['uid'],$time);
	
	if($myqdcount>0){
		$qdtitle='<img src="source/plugin/it618_credits/images/qd.png" style="vertical-align:middle; height:16px; margin-top:-3px; margin-right:3px" /><font color="#f30">'.$it618_credits_lang['s503'].'</font>';
	}else{
		$credits_qdgroup=(array)unserialize($it618_credits['credits_qdgroup']);
		if(!in_array($_G['groupid'], $credits_qdgroup)&&$credits_qdgroup[0]!=''){
		}else{
			$isqdgroup=1;
		}
		$qdtitle='<img src="source/plugin/it618_credits/images/qd0.png" style="vertical-align:middle; height:16px; margin-top:-3px; margin-right:3px" /><font color="#999">'.$it618_credits_lang['s504'].'</font>';
	}
	
	$weekarray=array($it618_credits_lang['s506'],$it618_credits_lang['s507'],$it618_credits_lang['s508'],$it618_credits_lang['s509'],$it618_credits_lang['s510'],$it618_credits_lang['s511'],$it618_credits_lang['s512']);
	$weekstr=$it618_credits_lang['s505'].$weekarray[date("w")];
	$datestr=date('n').'.'.date('j');
	
	$todaycount=C::t('#it618_credits#it618_credits_qd')->count_by_time($time);
	if($todaycount>0){
		$uid=C::t('#it618_credits#it618_credits_qd')->fetch_uid_by_time($time);
		$qdnewusername=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$uid);
	}
}

foreach(C::t('#it618_credits#it618_credits_focus')->fetch_all_by_type_order(0) as $it618_credits_focus) {
	if($it618_credits_focus['it618_url']!=''){
		$str_focus.='<li><a href="'.$it618_credits_focus['it618_url'].'" target="_blank"><img width="560" height="260" src="'.$it618_credits_focus['it618_img'].'" /></a></li>';
	}else{
		$str_focus.='<li><img width="560" height="260" src="'.$it618_credits_focus['it618_img'].'" /></li>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_credits_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_credits_gonggao = DB::fetch($query)) {
	$it618_title=$it618_credits_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,88,'...');
	
	if($it618_credits_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_credits_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_credits_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<li><a href="'.$it618_credits_gonggao['it618_url'].'" title="'.$it618_credits_gonggao['it618_title'].'" target="_blank"><div>'.$it618_title.'</div></a></li>';
}

$n=1;
$str_iconav='<tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_credits_iconav')." where it618_type=1 and it618_order<>0 ORDER BY it618_order");
while($it618_credits_iconav = DB::fetch($query)) {
	$it618_title=$it618_credits_iconav['it618_title'];
	
	if($it618_credits_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_credits_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_credits_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_credits_iconav['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$it618_url=$it618_credits_iconav['it618_url'];

	$str_iconav.='<td width="20%"><a href="'.$it618_url.'"'.$it618_target.'><img src="'.$it618_credits_iconav['it618_img'].'" /><br>'.$it618_title.'</a></td>';
	
	if($n%5==0)$str_iconav.='</tr><tr>';
	$n=$n+1;
}

for($i=1;$i<=$n%5;$i++){
	$str_iconav.='<td width="20%"></td>';
}
$str_iconav.='</tr>';
$str_iconav=str_replace('<tr><td width="20%"></td></tr>','',$str_iconav);
if($n>11)$isscroll=1;

$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
if($it618_money=='')$it618_money='0.00';

$moneyczurl=it618_credits_getrewrite('credits_home','moneycz','plugin.php?id=it618_credits:do&dotype=moneycz');
$moneytxurl=it618_credits_getrewrite('credits_home','moneytx','plugin.php?id=it618_credits:do&dotype=moneytx');
$moneysumurl=it618_credits_getrewrite('credits_home','moneysum','plugin.php?id=it618_credits:do&dotype=moneysum');

if($_G['uid']>0){
	$moneyczurl='href="'.$moneyczurl.'"';
}else{
	$moneyczurl='href="javascript:" onclick="useralert()"';
}

if($_G['uid']>0){
	$moneytxurl='href="'.$moneytxurl.'"';
}else{
	$moneytxurl='href="javascript:" onclick="useralert()"';
}

if($_G['uid']>0){
	$moneysumurl='href="'.$moneysumurl.'"';
}else{
	$moneysumurl='href="javascript:" onclick="useralert()"';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qianfan.php';
}

$creditsczurl='';
for($i=1;$i<=11;$i++){
	if(($_G['setting']['extcredits'][$i]['title']!=''&&$i<=8)||($qf_isgold==1&&$i==11)){
		$tmpstr='';
		$count=C::t('#it618_credits#it618_credits_recharge')->count_by_isok_jfid($i);
		if($count>0){
			$tmpurl=it618_credits_getrewrite('credits_home','recharge@'.$i,'plugin.php?id=it618_credits:do&dotype=recharge&ctype='.$i);
			if($creditsczurl=='')$creditsczurl=$tmpurl;
			if($_G['uid']>0){
				$astr='href="'.$tmpurl.'"';
			}else{
				$astr='href="javascript:" onclick="useralert()"';
			}
			$tmpstr='<a '.$astr.'>'.$it618_credits_lang['s237'].'</a>';
		}
		
		$count=C::t('#it618_credits#it618_credits_zhuan')->count_by_isok_jfid1($i);
		if($count>0){
			$tmpurl=it618_credits_getrewrite('credits_home','zhuan@'.$i,'plugin.php?id=it618_credits:do&dotype=zhuan&ctype='.$i);
			if($_G['uid']>0){
				$astr='href="'.$tmpurl.'"';
			}else{
				$astr='href="javascript:" onclick="useralert()"';
			}
			$tmpstr.='<a '.$astr.'>'.$it618_credits_lang['s238'].'</a>';
		}
		
		$count=C::t('#it618_credits#it618_credits_transfer')->count_by_isok_jfid($i);
		if($count>0){
			$tmpurl=it618_credits_getrewrite('credits_home','transfer@'.$i,'plugin.php?id=it618_credits:do&dotype=transfer&ctype='.$i);
			if($_G['uid']>0){
				$astr='href="'.$tmpurl.'"';
			}else{
				$astr='href="javascript:" onclick="useralert()"';
			}
			$tmpstr.='<a '.$astr.'>'.$it618_credits_lang['s239'].'</a>';
		}
		
		$count=C::t('#it618_credits#it618_credits_tq')->count_by_isok_jfid($i);
		if($count>0){
			$tmpurl=it618_credits_getrewrite('credits_home','tq@'.$i,'plugin.php?id=it618_credits:do&dotype=tq&ctype='.$i);
			if($_G['uid']>0){
				$astr='href="'.$tmpurl.'"';
			}else{
				$astr='href="javascript:" onclick="useralert()"';
			}
			$tmpstr.='<a '.$astr.'>'.$it618_credits_lang['s1574'].'</a>';
		}
		
		$count=C::t('#it618_credits#it618_credits_txbl')->count_by_isok_jfid($i);
		if($count>0){
			$tmpurl=it618_credits_getrewrite('credits_home','zy@'.$i,'plugin.php?id=it618_credits:do&dotype=zy&ctype='.$i);
			if($_G['uid']>0){
				$astr='href="'.$tmpurl.'"';
			}else{
				$astr='href="javascript:" onclick="useralert()"';
			}
			$tmpstr.='<a '.$astr.'>'.$it618_credits_lang['s240'].'</a>';
		}
		
		$tmpurl=it618_credits_getrewrite('credits_home','sum@'.$i,'plugin.php?id=it618_credits:do&dotype=sum&ctype='.$i);
		
		if($_G['uid']>0){
			$astr='href="'.$tmpurl.'"';
		}else{
			$astr='href="javascript:" onclick="useralert()"';
		}
			
		$tmpstr.='<a '.$astr.'>'.$it618_credits_lang['s241'].'</a>';
		
		if($tmpstr!=''){
			$jfname=it618_credits_getcreditstitle($i);
			$creditnum=it618_credits_getcreditsnum($i,$_G['uid']);
			
			$alltmpstr.='<li><b>'.$jfname.'</b><span>'.$creditnum.'</span> <div style="float:right">'.$tmpstr.'</div></li>';
		}
	}
}

if($creditsczurl!=''){
	if($_G['uid']>0){
		$creditsczurl='href="'.$creditsczurl.'"';
	}else{
		$creditsczurl='href="javascript:" onclick="useralert()"';
	}
}

$homejfbottomdiy=C::t('#it618_credits#it618_credits_set')->getsetvalue_by_setname('homejfbottomdiy');


global $it618_hongbao_lang;
$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
	
if(in_array(11,(array)unserialize($it618_hongbao['hongbao_power']))){
	$it618_hbtype='it618_credits';
	$tid=0;
	if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
		$authorid=$it618_hongbao_main['it618_uid'];
	}else{
		if($_G['uid']==$it618_credits['credits_wapsalepower']){
			$authorid=$_G['uid'];
		}
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
	$_G['mobiletpl'][2]='/';
	include template('it618_hongbao:hongbao');
}

$_G['mobiletpl'][2]='/';
include template('it618_credits:credits_default');
?>