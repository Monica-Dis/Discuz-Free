<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_credits_base {
	function common_base($wap) {
		global $_G;
		
		if($_G['uid']>0){
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_credits/config/buygroupset.php';
			}
			
			if($buygroup_isok==1){
				$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
		
				$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
				$groupterms = dunserialize($memberfieldforum['groupterms']);
				unset($memberfieldforum);
				$expgrouparray = $expirylist = $termsarray = array();
			
				if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
					$termsarray = $groupterms['ext'];
				}
				if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
					$termsarray[$_G['groupid']] = $groupterms['main']['time'];
				}
				
				foreach($termsarray as $expgroupid => $expiry) {
					if($expiry <= TIMESTAMP) {
						$expgrouparray[] = $expgroupid;
					}
				}
			
				if(!empty($groupterms['ext'])) {
					foreach($groupterms['ext'] as $extgroupid => $time) {
						$expirylist[$extgroupid] = array('time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
					}
				}
			
				if(!empty($groupterms['main'])) {
					$expirylist[$_G['groupid']] = array('time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
				}
			
				$groupids = array();
				foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
					if(!empty($usergroup['pubtype'])) {
						$groupids[] = $groupid;
					}
				}
				$expiryids = array_keys($expirylist);
				
				if(!$expiryids && $_G['member']['groupexpiry']) {
					C::t('common_member')->update($_G['uid'], array('groupexpiry' => 0));
				}
				
				if($expgrouparray) {
					$isflag=0;
					if(in_array($_G['adminid'], array(1, 2, 3))) {
						$isflag=1;
					}else{
						$tmpgroupid = DB::result_first("SELECT groupid FROM ".DB::table('common_usergroup')." WHERE type='member' AND creditshigher<=".$_G['member']['credits']." AND creditslower>=".$_G['member']['credits']." LIMIT 1");
						if($_G['groupid']==$tmpgroupid){
							$isflag=1;
						}
					}
					
					if($isflag==0){
						$extgroupidarray = array();
						foreach(explode("\t", $_G['forum_extgroupids']) as $extgroupid) {
							if(($extgroupid = intval($extgroupid)) && !in_array($extgroupid, $expgrouparray)) {
									$extgroupidarray[] = $extgroupid;
							}
						}
				
						$groupidnew = $_G['groupid'];
						$adminidnew = $_G['adminid'];
						
						foreach($expgrouparray as $expgroupid) {
							if($expgroupid == $_G['groupid']) {
								if(!empty($groupterms['main']['groupid'])) {
										$groupidnew = $groupterms['main']['groupid'];
										$adminidnew = $groupterms['main']['adminid'];
								} else {
										$groupidnew = DB::result_first("SELECT groupid FROM ".DB::table('common_usergroup')." WHERE type='member' AND creditshigher<=".$_G['member']['credits']." AND creditslower>=".$_G['member']['credits']." LIMIT 1");
										if(in_array($_G['adminid'], array(1, 2, 3))) {
												$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup')." WHERE groupid IN (".dimplode($extgroupidarray).") AND radminid='$_G[adminid]' LIMIT 1");
												$adminidnew = (DB::num_rows($query)) ? $_G['adminid'] : 0;
										} else {
												$adminidnew = 0;
										}
								}
								unset($groupterms['main']);
							}
							unset($groupterms['ext'][$expgroupid]);
						}
				
						require_once libfile('function/forum');
						$groupexpirynew = groupexpiry($groupterms);
						$extgroupidsnew = implode("\t", $extgroupidarray);
						$grouptermsnew = addslashes(serialize($groupterms));
						
						if(in_array($_G['adminid'], array(1, 2, 3))) {
							$groupidnew = $_G['adminid'];
							$adminidnew = $_G['adminid'];
						}
				
						DB::query("UPDATE ".DB::table('common_member')." SET adminid='$adminidnew', groupid='$groupidnew', extgroupids='$extgroupidsnew', groupexpiry='$groupexpirynew' WHERE uid='$_G[uid]'");
						DB::query("UPDATE ".DB::table('common_member_field_forum')." SET groupterms='$grouptermsnew' WHERE uid='$_G[uid]'");
						
						$isbuygroup=1;
					}
			
				}
				
				if($isbuygroup==1){
					$urlarr=explode("https://",$_G['siteurl']);
					if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';		
					$url_this = $httpstr.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
					
					$tmparr1=explode("buygroup",$url_this);
					$tmparr2=explode("it618_credits:ajax",$url_this);
					
					$urlarr=explode(":ajax",$url_this);
					if(count($urlarr)>1)$url_this=$_G['siteurl'];
					dsetcookie('buygroup_preurl',$url_this,31536000);
					
					if(count($tmparr1)==1&&count($tmparr2)==1){
						require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
						if($wap==1){
							$tmpurl_buygroup=it618_credits_getrewrite('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup&groupexpiry','?groupexpiry');
						}else{
							$tmpurl_buygroup=it618_credits_getrewrite('credits_home','buygroup','plugin.php?id=it618_credits:do&dotype=buygroup&groupexpiry','?groupexpiry');
						}
						dheader("location:$tmpurl_buygroup");
					}
				}
			}
	
		}
	}
}

class mobileplugin_it618_credits extends plugin_it618_credits_base {
	function common() {
		$this->common_base(1);
	}
}

class plugin_it618_credits extends plugin_it618_credits_base {
	
	function common() {
		$this->common_base(0);
	}
	
	function global_footer(){
		global $_G;
		$it618_credits = $_G['cache']['plugin']['it618_credits'];
		$credits_diy=(array)unserialize($it618_credits['credits_diy']);
		
		if($_G['uid']>0&&$_GET['ac']!="usergroup"){
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_credits/config/qdset.php';
			}
			
			$credits_qdgroup=(array)unserialize($it618_credits['credits_qdgroup']);
			if(!in_array($_G['groupid'], $credits_qdgroup)&&$credits_qdgroup[0]!=''){
			}else{
				if($qd_isok==1&&($qd_pc==1||$qd_pcauto==1)){
					$tomonth = date('n');
					$todate = date('j');
					$toyear = date('Y');
					$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
					
					$count=C::t('#it618_credits#it618_credits_qd')->count_by_uid_time($_G['uid'],$time);
					
					if($count==0){
						if($qd_pcauto==1){
							$tmpstr='
							jQuery(".it618_credits").first().click();
							';
						}elseif($qd_pc==1){
							$tmpstr='
							jQuery(".it618_credits").first().click();
							setTimeout(\'alert("'.$qd_tip.'")\',800);
							';
						}
					}
				}
			}
		}
		
		$credits_diy=(array)unserialize($it618_credits['credits_diy']);
		if(count($credits_diy)>0){
			if($_G['uid']>0){
				$it618_credits['credits_jquerys']=$it618_credits['credits_jquerys'].'|spacecp&ac=avatar';
				if($it618_credits['credits_jquerys']!=''){
					$tmparr=explode("|",$it618_credits['credits_jquerys']);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode($tmparr[$i],$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
						if(count($tmparr1)>1){
							$tmpjs='<script>jQuery.noConflict();</'.'SCRIPT>';
							break;
						}
						if($_SERVER['REQUEST_URI']=='/'&&$tmparr[$i]=='@'){
							$tmpjs='<script>jQuery.noConflict();</'.'SCRIPT>';
							break;
						}
					}
				}
				if($tmpjs=='')$tmpjs='<SCRIPT src="source/plugin/it618_credits/js/jquery.js" type=text/javascript></'.'SCRIPT>';
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
				return $tmpjs.'
						'.it618_credits_getcredits('it618_discuz','.it618_credits').'
						<script>
						jQuery(document).ready(function() {
						'.$tmpstr.'
						});
						</script>
					';
			}
		}

	}
	
	function global_usernav_extra3(){
		global $_G;
		$it618_credits = $_G['cache']['plugin']['it618_credits'];
		$credits_diy=(array)unserialize($it618_credits['credits_diy']);
		if(in_array(1, $credits_diy)){
			if($_G['uid']>0){
				return $it618_credits['credits_apibtn1'].'<span class="pipe" style="margin-left:12px">|</span>';
			}
		}
		
		return '';
	}

}

class plugin_it618_credits_forum {
	
	function viewthread_sidetop_output(){
		global $_G,$postlist;
		$it618_credits = $_G['cache']['plugin']['it618_credits'];
		
		$viewthread_sidetop=array();
		
		if($_G['uid']>0){
			$credits_diy=(array)unserialize($it618_credits['credits_diy']);
			if(in_array(2, $credits_diy)){
				
				foreach($postlist as $id => $post){
					if($post['authorid']==$_G['uid']){
						$viewthread_sidetop[]='<div style="margin-top:-3px;margin-bottom:10px;text-align:center">'.$it618_credits['credits_apibtn2'].'</div>';
					}else{
						$viewthread_sidetop[]='';
					}
		
				}
			}
		}
		
		return $viewthread_sidetop;
	}

}
?>