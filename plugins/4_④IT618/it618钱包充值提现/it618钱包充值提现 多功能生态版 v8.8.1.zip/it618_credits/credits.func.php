<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

function it618_credits_getcredits($pluginid,$name,$url=''){
	if($url=='')$url="plugin.php?id=it618_credits:index";
	return '
			<script type="text/javascript" src="source/plugin/it618_credits/js/layer/layer.js"></script>
			<script>			
			jQuery(document).ready(function() {
			jQuery("'.$name.'").click(function() {
				layerindex=layer.open({
				  type: 2,
				  title: "<div style=\'float:left\'><img src=\'source/plugin/it618_credits/images/ico.png\' style=\'vertical-align:middle;margin-right:3px; margin-top:-3px\'>'.lang('plugin/it618_credits', 'it618_lang1').'</div>",
				  shadeClose: false,
				  scrollbar: false,
				  shade:  [0.5, "#393D49"],
				  maxmin: false,
				  area: ["868px", "588px"],
				  content: "'.$url.'",
				  cancel: function(index, layero){ 
				  }    
				});
			});
			});
			function IT618_QB(url) {
				layerindex=layer.open({
				  type: 2,
				  title: "<div style=\'float:left\'><img src=\'source/plugin/it618_credits/images/ico.png\' style=\'vertical-align:middle;margin-right:3px; margin-top:-3px\'>'.lang('plugin/it618_credits', 'it618_lang1').'</div>",
				  shadeClose: false,
				  scrollbar: false,
				  shade:  [0.5, "#393D49"],
				  maxmin: false,
				  area: ["868px", "588px"],
				  content: url,
				  cancel: function(index, layero){ 
				  }    
				});
			}
			</script>
		<div id="vippaybtn" style="display:none"></div>';
}

function it618_credits_getrewriteapi($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_credits']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_credits/config/rewrite.php';
	
	if($pagetype=='credits_home'){//credits-{dotype}-{ctype}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$credits_home.$credits_home1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{dotype}-{ctype}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{dotype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("-{ctype}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{dotype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{ctype}",$tmparr[1],$pageurl);
			}
		}
		
		if(isset($_GET['win']))$pageurl=$pageurl.'?win';
		return $pageurl.$uri;
	}
	
	if($pagetype=='credits_wap'){//credits_wap-{dotype}-{ctype}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$credits_wap.$credits_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{dotype}-{ctype}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{dotype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("-{ctype}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{dotype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{ctype}",$tmparr[1],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}
?>