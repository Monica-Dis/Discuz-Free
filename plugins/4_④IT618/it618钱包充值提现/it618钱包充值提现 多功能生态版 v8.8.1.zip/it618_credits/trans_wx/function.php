<?php
function it618_getwxsign($arrtmp,$wxkey){
	foreach ($arrtmp as $key => $value){
		$parameters[$key] = $value;
	}
	ksort($parameters);
	$string = it618_formatquery($parameters,false);
	$string = $string."&key=$wxkey";
	$string = md5($string);
	$resultstr = strtoupper($string);
	return $resultstr;
}

function it618_formatquery($querystr,$isurlencode){
	$tmpstr = '';
	ksort($querystr);
	foreach($querystr as $key => $value){
		if($isurlencode){
		   $value = urlencode($value);
		}
		$tmpstr .= $key.'='.$value.'&';
	}
	$returnstr='';
	if(strlen($tmpstr) > 0){
		$returnstr = substr($tmpstr,0,strlen($tmpstr)-1);
	}
	return $returnstr;
}

function it618_getrandstr($length = 32){
	$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';  
	$str ='';
	for($i=0;$i<$length;$i++){
		$str.= substr($chars,mt_rand(0,strlen($chars)-1),1); 
	}
	return $str;
}

function it618_postxmlsslcurl($xml,$url,$ssl1,$ssl2,$second=30){	 
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_TIMEOUT,$second);
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch,CURLOPT_HEADER,FALSE);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
	curl_setopt($ch,CURLOPT_POST,TRUE);
	curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
    curl_setopt($ch,CURLOPT_SSLCERT,$ssl1);
    curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
    curl_setopt($ch,CURLOPT_SSLKEY,$ssl2);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$xml);
	$data = curl_exec($ch);
	curl_close($ch);
	if($data){
		curl_close($ch);
		return $data;
	}
}

function it618_arraytoxml($arr){
	$xmlstr='';
	foreach($arr as $key=>$val){
		 if(is_numeric($val)){
			$xmlstr.='<'.$key.'>'.$val.'</'.$key.'>'; 
		 }else{
			$xmlstr.='<'.$key.'><![CDATA['.$val.']]></'.$key.'>';  
		 }
	}
	$xmlstr='<xml>'.$xmlstr.'</xml>';
	return $xmlstr; 
}

function it618_xmltoarray($xml){
	$disableLibxmlEntityLoader = libxml_disable_entity_loader(true);
	$xmltmp=simplexml_load_string($xml,'SimpleXMLElement',LIBXML_NOCDATA);
	$arraytmp = json_decode(json_encode($xmltmp),true);
	libxml_disable_entity_loader($disableLibxmlEntityLoader);
	return $arraytmp;
}

function it618_curl($url){
	return file_get_contents($url);	
}
?>