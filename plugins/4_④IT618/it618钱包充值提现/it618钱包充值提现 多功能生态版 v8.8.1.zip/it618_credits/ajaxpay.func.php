<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function pay_success($out_trade_no){
	global $_G,$it618_credits_lang;
	
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
		if($it618_salepay['it618_state']==1)return;
	}else{
		return;	
	}
	
	$salepay_saletype=$it618_salepay['it618_saletype'];
	$salepay_saleid=$it618_salepay['it618_saleid'];
	$salepay_paytype=$it618_salepay['it618_paytype'];
	$salepay_payid=$it618_salepay['it618_payid'];
	$salepay_url=$it618_salepay['it618_url'];
	$salepay_wap=$it618_salepay['it618_wap'];
	$salepay_body=$it618_salepay['it618_body'];

	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	
	if($salepay_saletype=='0108'){
		$it618_credits_moneycztmp=C::t('#it618_credits#it618_credits_moneycztmp')->fetch_by_id($salepay_saleid);
			
		if($it618_credits_moneycztmp['it618_state']!=1){
			C::t('#it618_credits#it618_credits_moneycztmp')->update($salepay_saleid,array(
				'it618_state' => 1,
				'it618_paytype' => $salepay_paytype,
				'it618_payid' => $salepay_payid,
				'it618_time' => $_G['timestamp']
			));
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			if($it618_credits_moneycztmp['it618_zsjfcount']>0){
				if($it618_credits_moneycztmp['it618_zsjfid']<=8){
					C::t('common_member_count')->increase($it618_credits_moneycztmp['it618_uid'], array(
						'extcredits'.$it618_credits_moneycztmp['it618_zsjfid'] => $it618_credits_moneycztmp['it618_zsjfcount'])
					);
				}else{
					$body=$it618_credits_lang['s1264'];
					$body=str_replace("{count}",$it618_credits_moneycztmp['it618_money1'].$it618_credits_lang['s28'],$body);
					it618_credits_qianfan('write',$it618_credits_moneycztmp['it618_uid'],10009,$it618_credits_moneycztmp['it618_zsjfcount'],it618_credits_gbktoutf($body));
				}
			}

			savemoney(array(
				'it618_uid' => $it618_credits_moneycztmp['it618_uid'],
				'it618_type' => 'cz',
				'it618_money1' => $it618_credits_moneycztmp['it618_money1'],
				'it618_zsjfid' => $it618_credits_moneycztmp['it618_zsjfid'],
				'it618_zsjfcount' => $it618_credits_moneycztmp['it618_zsjfcount'],
				'it618_zsbl' => $it618_credits_moneycztmp['it618_zsbl'],
				'it618_bz' => $it618_credits_moneycztmp['it618_bz'],
				'it618_paytype' => $salepay_paytype,
				'it618_payid' => $salepay_payid,
				'it618_czyfmoney' => $it618_credits_moneycztmp['it618_czyfmoney'],
				'it618_time' => $_G['timestamp']
			));
			
			it618_credits_sendmessage("cz_user",$it618_credits_moneycztmp['id'],'money');
			it618_credits_sendmessage("cz_admin",$it618_credits_moneycztmp['id'],'money');
			
			return 'success';
		}
	
	}
	
	if($salepay_saletype=='0101'){
		$it618_credits_sale=C::t('#it618_credits#it618_credits_sale')->fetch_by_id($salepay_saleid);
			
		if($it618_credits_sale['it618_state']!=1){
			C::t('#it618_credits#it618_credits_sale')->update($salepay_saleid,array(
				'it618_state' => 1,
				'it618_paytype' => $salepay_paytype,
				'it618_payid' => $salepay_payid
			));
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			if($it618_credits_sale['it618_jfid1']<=8){
				C::t('common_member_count')->increase($it618_credits_sale['it618_uid2'], array(
					'extcredits'.$it618_credits_sale['it618_jfid1'] => $it618_credits_sale['it618_jfcount'])
				);
			}else{
				it618_credits_qianfan('write',$it618_credits_sale['it618_uid2'],10001,$it618_credits_sale['it618_jfcount'],it618_credits_gbktoutf($it618_credits_lang['s1259']));
			}
			
			if($it618_credits_sale['it618_zsjfcount']>0){
				if($it618_credits_sale['it618_zsjfid']<=8){
					C::t('common_member_count')->increase($it618_credits_sale['it618_uid2'], array(
						'extcredits'.$it618_credits_sale['it618_zsjfid'] => $it618_credits_sale['it618_zsjfcount'])
					);
				}else{
					$jfname=it618_credits_getcreditstitle($it618_credits_sale['it618_jfid1']);
					$body=$it618_credits_lang['s1252'];
					$body=str_replace("{count}",$it618_credits_sale['it618_jfcount'].$jfname,$body);
					it618_credits_qianfan('write',$it618_credits_sale['it618_uid2'],10003,$it618_credits_sale['it618_zsjfcount'],it618_credits_gbktoutf($body));
				}
			}
			
			$tmpmoney=floatval($it618_salepay['it618_total_fee']);
			if($tmpmoney>0){
				if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
				}
				
				if($union_credits_isok==1&&$tmpmoney>=$union_credits_money){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					Union_SaleTC('it618_credits_cz',$tmpmoney,$it618_salepay['it618_saleid'],$it618_salepay['it618_uid']);
				}
			}
			
			it618_credits_sendmessage("cz_user",$it618_credits_sale['id']);
			it618_credits_sendmessage("cz_admin",$it618_credits_sale['id']);
			
			return 'success';
		}
	
	}
	
	if($salepay_saletype=='0102'){
		$it618_credits_moneysktmp=C::t('#it618_credits#it618_credits_moneysktmp')->fetch_by_id($salepay_saleid);
			
		if($it618_credits_moneysktmp['it618_state']!=1){
			C::t('#it618_credits#it618_credits_moneysktmp')->update($salepay_saleid,array(
				'it618_state' => 1,
				'it618_paytype' => $salepay_paytype,
				'it618_payid' => $salepay_payid,
				'it618_time' => $_G['timestamp']
			));
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			if($it618_credits_moneysktmp['it618_zsjfcount']>0){
				if($it618_credits_moneysktmp['it618_zsjfid']<=8){
					C::t('common_member_count')->increase($it618_credits_moneysktmp['it618_uid'], array(
						'extcredits'.$it618_credits_moneysktmp['it618_zsjfid'] => $it618_credits_moneysktmp['it618_zsjfcount'])
					);
				}else{
					$body=$it618_credits_lang['s1265'];
					$body=str_replace("{count}",$it618_credits_moneysktmp['it618_money1'].$it618_credits_lang['s28'],$body);
					it618_credits_qianfan('write',$it618_credits_moneysktmp['it618_uid'],10010,$it618_credits_moneysktmp['it618_zsjfcount'],it618_credits_gbktoutf($body));
				}
			}
			
			$it618_money1=round(($it618_credits_moneysktmp['it618_money1']-$it618_credits_moneysktmp['it618_money1']*$it618_credits_moneysktmp['it618_tcbl']/100),2);
			
			if($it618_zsuid>0){
				$bztmp=$it618_credits_lang['t331'].$it618_credits_moneysktmp['id'];
			}else{
				$bztmp=$it618_credits_lang['t334'].$it618_credits_moneysktmp['id'];
			}
			
			savemoney(array(
				'it618_uid' => $it618_credits_moneysktmp['it618_uid'],
				'it618_type' => 'sk',
				'it618_money1' => $it618_money1,
				'it618_zsjfid' => $it618_credits_moneysktmp['it618_zsjfid'],
				'it618_zsjfcount' => $it618_credits_moneysktmp['it618_zsjfcount'],
				'it618_zsbl' => $it618_credits_moneysktmp['it618_zsbl'],
				'it618_skmoney' => $it618_credits_moneysktmp['it618_money1'],
				'it618_sktcbl' => $it618_credits_moneysktmp['it618_tcbl'],
				'it618_bz' => $bztmp.' '.$it618_credits_moneysktmp['it618_bz'],
				'it618_paytype' => $salepay_paytype,
				'it618_payid' => $salepay_payid,
				'it618_time' => $_G['timestamp']
			));
			
			$it618_zsuid=$it618_credits_moneysktmp['it618_zsuid'];
			$it618_money=$it618_credits_moneysktmp['it618_money1'];
			if($it618_zsuid>0){
				$it618_brand = $_G['cache']['plugin']['it618_brand'];
				if($it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($it618_credits_moneysktmp['it618_uid'])){
					$ShopId=$it618_brand_brand['id'];
					$ShopUid=$it618_brand_brand['it618_uid'];
					if($it618_brand_moneyset=C::t('#it618_brand#it618_brand_moneyset')->fetch_by_shopid_ok($ShopId)){
						$it618_zsbl=$it618_brand_moneyset['it618_zsbl'];
						$it618_num=$it618_brand_moneyset['it618_num'];
						$it618_num1=$it618_brand_moneyset['it618_num1'];
						$it618_zsbl1=$it618_brand_moneyset['it618_zsbl1'];
						$it618_zsbl2=$it618_brand_moneyset['it618_zsbl2'];
						$it618_zsbl3=$it618_brand_moneyset['it618_zsbl3'];
						
						$moneycount=C::t('#it618_brand#it618_brand_money')->fetch_by_uid_shopid_type1($it618_zsuid,$ShopId);
						if($moneycount==0){
							$zsbl=$it618_zsbl;
						}else{
							if($moneycount>$it618_num1){
								$it618_score=0;
							}else{
								if($moneycount<=$it618_num){
									$zsbl=$it618_zsbl1;
								}else{
									$zsbl=$it618_zsbl1+($moneycount-$it618_num)*$it618_zsbl2;
									if($zsbl>$it618_zsbl3)$zsbl=$it618_zsbl3;
								}
							}
						}
						
						$it618_score=intval($it618_money*$zsbl/100);
						$zsbl=' '.$it618_credits_lang['t332'].$zsbl.'%';
					}else{
						$it618_score=0;
					}
				}
				
				C::t('#it618_brand#it618_brand_money')->insert(array(
					'it618_shopid' => $ShopId,
					'it618_money' => $it618_money,
					'it618_score' => $it618_score,
					'it618_uid' => $it618_zsuid,
					'it618_bz' => $it618_credits_lang['t331'].$it618_credits_moneysktmp['id'].$zsbl.' '.$it618_credits_moneysktmp['it618_bz'],
					'it618_type' => 1,
					'it618_time' => $_G['timestamp']
				), true);
				
				$tmpcount=C::t('#it618_brand#it618_brand_card')->count_by_uid_isok($it618_zsuid);
				if($tmpcount>0){
					$tmpcount=C::t('#it618_brand#it618_brand_cardmoney')->count_by_shopid_uid($ShopId,$it618_zsuid);
					if($tmpcount==0){
						C::t('#it618_brand#it618_brand_cardmoney')->insert(array(
							'it618_shopid' => $ShopId,
							'it618_uid' => $it618_zsuid,
							'it618_count2' => 1,
							'it618_money2' => $it618_money,
						), true);
					}else{
						DB::query("update ".DB::table('it618_brand_cardmoney')." set it618_count2=it618_count2+1,it618_money2=it618_money2+".$it618_money." where it618_shopid=".$ShopId." and it618_uid=".$it618_zsuid);
					}
				}
				
				if($it618_score>0){
					C::t('common_member_count')->increase($it618_zsuid, array(
						'extcredits'.$it618_brand['brand_credit'] => $it618_score)
					);
					C::t('common_member_count')->increase($ShopUid, array(
						'extcredits'.$it618_brand['brand_credit'] => (0-$it618_score))
					);
				}
			}
			
			it618_credits_sendmessage("sk_user",$it618_credits_moneysktmp['id']);
			it618_credits_sendmessage("sk_admin",$it618_credits_moneysktmp['id']);
			
			return 'success';
		}
	
	}
	
	if($salepay_saletype=='0103'){
		$it618_credits_buygroup_sale=C::t('#it618_credits#it618_credits_buygroup_sale')->fetch_by_id($salepay_saleid);
			
		if($it618_credits_buygroup_sale['it618_state']!=1){
			C::t('#it618_credits#it618_credits_buygroup_sale')->update($salepay_saleid,array(
				'it618_state' => 1,
				'it618_paytype' => $salepay_paytype,
				'it618_payid' => $salepay_payid
			));
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			$groupid=$it618_credits_buygroup_sale['it618_groupid'];

			$uid=$it618_credits_buygroup_sale['it618_uid'];
			$member=getuserbyuid($uid, 1);
			$extgroupids = $member['extgroupids'] ? explode("\t", $member['extgroupids']) : array();
			
			$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
			$groupterms = dunserialize($memberfieldforum['groupterms']);
			unset($memberfieldforum);
			require_once libfile('function/forum');
			
			$extgroupidsarray = array();
			foreach(array_unique(array_merge($extgroupids, array($groupid))) as $extgroupid) {
				if($extgroupid) {
					$extgroupidsarray[] = $extgroupid;
				}
			}
			
			$it618_unit=$it618_credits_buygroup_sale['it618_unit'];
			$it618_days=$it618_credits_buygroup_sale['it618_days'];
			
			if($it618_unit==2)$it618_days=$it618_days*30;
			if($it618_unit==3)$it618_days=$it618_days*365;
			if($it618_unit==4)$it618_days=$it618_days*365*150;
			
			$groupterms['ext'][$groupid] = ($groupterms['ext'][$groupid] > TIMESTAMP ? $groupterms['ext'][$groupid] : TIMESTAMP) + $it618_days * 86400;

			$grouptermsnew = serialize($groupterms);
			$groupexpirynew = groupexpiry($groupterms);
			$extgroupidsnew = implode("\t", $extgroupidsarray);
		
			C::t('common_member')->update($uid, array('extgroupids'=>$extgroupidsnew, 'groupexpiry'=>$groupexpirynew));
			if(C::t('common_member_field_forum')->fetch($uid)) {
				C::t('common_member_field_forum')->update($uid, array('groupterms' => $grouptermsnew));
			} else {
				C::t('common_member_field_forum')->insert(array('uid' => $uid, 'groupterms' => $grouptermsnew));
			}
			
			if($it618_credits_buygroup_sale['it618_isswitch']==1&&$groupid!=$member['groupid']){

				$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
				$groupterms = dunserialize($memberfieldforum['groupterms']);
				unset($memberfieldforum);
				$extgroupidsnew = $member['groupid'];
				$groupexpirynew = $groupterms['ext'][$extgroupidsnew];
				foreach($extgroupids as $extgroupid) {
					if($extgroupid && $extgroupid != $groupid) {
						$extgroupidsnew .= "\t".$extgroupid;
					}
				}
		
				C::t('common_member')->update($uid, array('groupid' => $groupid, 'groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
			}
			
			$tmpmoney=floatval($it618_salepay['it618_total_fee']);
			if($tmpmoney>0){
				if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
				}
				
				if($union_credits_isok==1&&$tmpmoney>=$union_credits_money){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					Union_SaleTC('it618_credits_buygroup',$tmpmoney,$it618_salepay['it618_saleid'],$it618_salepay['it618_uid']);
				}
			}
			
			it618_credits_sendmessage("buygroup_user",$it618_credits_buygroup_sale['id']);
			it618_credits_sendmessage("buygroup_admin",$it618_credits_buygroup_sale['id']);
			
			return 'success';
		}
	
	}

}

function getdomainurl_paytype($domainurl,$paytype,$wap=0){
	if($paytype=='alipay'){
		if($wap!=1){
			$paytype='alipaycode';
		}
	}
	
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')!==false){
		if($paytype=='alipay')$paytype='alipaycode';
	}
	
	if($paytype=='wxpay'){
		if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')!==false){
			$paytype='wxwap';
			
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
			}
			
			if($wx_domain!=''){
				$urlarr=explode("https://",$domainurl);
				if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
				
				$urlarr=explode("://",$wx_domain);
				if(count($urlarr)==1){
					$domainurl=$httpstr.$wx_domain.'/';
				}else{
					$domainurl=$wx_domain.'/';
				}
				
				$domainurl=$domainurl.'@';
				$domainurl=str_replace('/@','/',$domainurl);
				$domainurl=str_replace('//@','/',$domainurl);
			}
			
		}else{
			$paytype='wxcode';
			
			if($wap==1){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php';
				}
				if($wxh5_isok==1)$paytype='wxh5';
			}
			
			if(strpos($_SERVER['HTTP_USER_AGENT'],'Appbyme')!==false){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php';
				}
				if($wxapp_isok==1)$paytype='Appbyme';
			}
		}
	
	}
	
	if($paytype=='payjs_wx'){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';
		}
		
		if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')!==false){
			$paytype='payjs_wxwap';
		}else{
			$paytype='payjs_wxcode';
			if($wap==1&&$payjs_istowxh5==1){
				$paytype='payjs_wxh5';
			}
		}
	}
	
	if($paytype=='payjs_alipay'){
		if($wap!=1)$paytype='payjs_alipaycode';
	}
	
	if($paytype=='MAGAPPX'){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		
		if(strpos($_SERVER['HTTP_USER_AGENT'],'MAGAPPX')!==false)$ismagapp=1;
		if($ismagapp!=1){
			$paytype='MAGAPPXcode';
		}
	}
	
	return $domainurl.'it618_split'.$paytype;
}

function getpaytype($type=''){
	global $_G,$it618_credits,$it618_credits_lang;
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay/config.php';
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxh5.php';
	}
	if($wxh5_isok==1)$wx_isok=1;
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_magapp/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_magapp/config.php';
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_alif2f/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_alif2f/config.php';
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_payjs/config.php';
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_precode/config.php';
	}
	
	if($payjs_istowx==1||$precode_istowx==1){
		$wx_isok=0;
	}
	if($alif2f_isok==1||$payjs_istoalipay==1||$precode_istoalipay==1){
		$alipay_isok=0;
	}
	
	$wap=0;
	if(credits_is_mobile()){ 
		$wap=1;
	}
	
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')!==false)$iswx=1;
	
	$checked_alipay='';
	$checked_wx='checked="checked"';
	
	if($alipay_checked==1){
		$checked_alipay='checked="checked"';
		$checked_wx='';
	}
	
	$isall=1;
	if($iswx==1){
		$isall=0;
		if($alipay_iswx==1){
			$isall=1;
		}
		$checked_alipay='';
		$checked_wx='checked="checked"';
	}
	
	if($alipay_isok==1&&$wx_isok==1){
		if($isall==1){
			if($wap==1){
				$paystr='<p><label for="paytype_alipay"><img src="source/plugin/it618_credits/images/zhifubao.png" >'.$it618_credits_lang['s675'].'<input id="paytype_alipay" name="paytype" type="radio" value="alipay" '.$checked_alipay.'/><span></span></label></p>
						<p><label for="paytype_wxpay"><img src="source/plugin/it618_credits/images/weixin.png" >'.$it618_credits_lang['s676'].'<input id="paytype_wxpay" name="paytype" type="radio" value="wxpay" '.$checked_wx.'/><span></span></label></p>';
			}else{
				$paystr='<input type="radio" value="alipay" id="paytype_alipay" name="paytype" '.$checked_alipay.' style="vertical-align:middle"/><label for="paytype_alipay"><img src="source/plugin/it618_credits/images/chkalipay.png" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>
				<input type="radio" value="wxpay" id="paytype_wxpay" name="paytype" '.$checked_wx.' style="vertical-align:middle"/><label for="paytype_wxpay"><img src="source/plugin/it618_credits/images/chkwxpay.png" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>';
			}
			$isalpaywx=1;
		}else{
			$paystr='<input type="hidden" name="paytype" value="wxpay" />';
		}
	}else{
		if($alipay_isok==1&&$isall==1){
			$paystr='<input type="hidden" name="paytype" value="alipay" />';
		}
		
		if($wx_isok==1){
			$paystr='<input type="hidden" name="paytype" value="wxpay" />';
		}
	}
	
	if($paystr!=''){
		if($wap==1){
			$paystr=str_replace('<input type="hidden" name="paytype" value="alipay" />','<p><label for="paytype_alipay"><img src="source/plugin/it618_credits/images/zhifubao.png" >'.$it618_credits_lang['s675'].'<input id="paytype_alipay" name="paytype" type="radio" value="alipay" checked="checked"/><span></span></label></p>',$paystr);
			
			$paystr=str_replace('<input type="hidden" name="paytype" value="wxpay" />','<p><label for="paytype_wxpay"><img src="source/plugin/it618_credits/images/weixin.png" >'.$it618_credits_lang['s676'].'<input id="paytype_wxpay" name="paytype" type="radio" value="wxpay" checked="checked"/><span></span></label></p>',$paystr);
		}else{
			$paystr=str_replace('<input type="hidden" name="paytype" value="alipay" />','<input type="radio" value="alipay" id="paytype_alipay" name="paytype" checked="checked" style="vertical-align:middle"/><label for="paytype_alipay"><img src="source/plugin/it618_credits/images/chkalipay.png" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>',$paystr);
			
			$paystr=str_replace('<input type="hidden" name="paytype" value="wxpay" />','<input type="radio" value="wxpay" id="paytype_wxpay" name="paytype" checked="checked"  style="vertical-align:middle"/><label for="paytype_wxpay"><img src="source/plugin/it618_credits/images/chkwxpay.png" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>',$paystr);
		}
	}
	
	if($wap==1){
		if($payjs_istowx==1){
			$imgtmp='<img src="source/plugin/it618_credits/images/weixin.png" >'.$it618_credits_lang['s676'];
			$paystr_wx='<p><label for="paytype_payjs_wx">'.$imgtmp.'<input id="paytype_payjs_wx" name="paytype" type="radio" value="payjs_wx" '.$checked_wx.'/><span></span></label></p>';
		}
		
		if($precode_istowx==1&&$paystr_wx==''){
			$imgtmp='<img src="source/plugin/it618_credits/images/weixin.png" >'.$it618_credits_lang['s676'];
			$paystr_wx='<p><label for="paytype_precode_wx">'.$imgtmp.'<input id="paytype_precode_wx" name="paytype" type="radio" value="precode_wx" '.$checked_wx.'/><span></span></label></p>';
		}
		
		if($alif2f_isok==1){
			$imgtmp='<img src="source/plugin/it618_credits/images/zhifubao.png" >'.$it618_credits_lang['s675'];
			$paystr_alipay.='<p><label for="paytype_alipay_f2fcode">'.$imgtmp.'<input id="paytype_alipay_f2fcode" name="paytype" type="radio" value="alipay_f2fcode" '.$checked_alipay.'/><span></span></label></p>';
		}
		
		if($payjs_istoalipay==1&&$paystr_alipay==''){
			$imgtmp='<img src="source/plugin/it618_credits/images/zhifubao.png" >'.$it618_credits_lang['s675'];
			$paystr_alipay='<p><label for="paytype_payjs_alipay">'.$imgtmp.'<input id="paytype_payjs_alipay" name="paytype" type="radio" value="payjs_alipay" '.$checked_alipay.'/><span></span></label></p>';
		}
		
		if($precode_istoalipay==1&&$paystr_alipay==''){
			$imgtmp='<img src="source/plugin/it618_credits/images/zhifubao.png" >'.$it618_credits_lang['s675'];
			$paystr_alipay='<p><label for="paytype_precode_alipay">'.$imgtmp.'<input id="paytype_precode_alipay" name="paytype" type="radio" value="precode_alipay" '.$checked_alipay.'/><span></span></label></p>';
		}
		
	}else{
		if($payjs_istowx==1){
			$imgtmp='chkwxpay.png';
			$paystr_wx='<input type="radio" value="payjs_wx" id="paytype_payjs_wx" name="paytype" '.$checked_wx.' style="vertical-align:middle"/><label for="paytype_payjs_wx"><img src="source/plugin/it618_credits/images/'.$imgtmp.'" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>';
		}
		
		if($precode_istowx==1&&$paystr_wx==''){
			$imgtmp='chkwxpay.png';
			$paystr_wx='<input type="radio" value="precode_wx" id="paytype_precode_wx" name="paytype" '.$checked_wx.' style="vertical-align:middle"/><label for="paytype_precode_wx"><img src="source/plugin/it618_credits/images/'.$imgtmp.'" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>';
		}
		
		if($alif2f_isok==1){
			$imgtmp='chkalipay.png';
			$paystr_alipay.='<input type="radio" value="alipay_f2fcode" id="paytype_alipay_f2fcode" name="paytype" '.$checked_alipay.' style="vertical-align:middle"/><label for="paytype_alipay_f2fcode"><img src="source/plugin/it618_credits/images/'.$imgtmp.'" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>';
		}
		
		if($payjs_istoalipay==1&&$paystr_alipay==''){
			$imgtmp='chkalipay.png';
			$paystr_alipay='<input type="radio" value="payjs_alipay" id="paytype_payjs_alipay" name="paytype" '.$checked_alipay.' style="vertical-align:middle"/><label for="paytype_payjs_alipay"><img src="source/plugin/it618_credits/images/'.$imgtmp.'" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>';
		}
		
		if($precode_istoalipay==1&&$paystr_alipay==''){
			$imgtmp='chkalipay.png';
			$paystr_alipay='<input type="radio" value="precode_alipay" id="paytype_precode_alipay" name="paytype" '.$checked_alipay.' style="vertical-align:middle"/><label for="paytype_precode_alipay"><img src="source/plugin/it618_credits/images/'.$imgtmp.'" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>';
		}
	}
	
	$paystr.=$paystr_alipay.$paystr_wx;
	
	
	$paystr1='';
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MAGAPPX')!==false)$ismagapp=1;
	if($magapp_isok==1){
		if($ismagapp==1){
			$checked_magpay='checked="checked"';
			if($magapp_isqbmoney==1){
				$ismagpay=1;
			}else{
				$paystr='<input type="hidden" name="paytype" value="MAGAPPX" />';
				return $paystr;
			}
		}else{
			if($paystr=='')$checked_magpay='checked="checked"';
			if($magapp_ismagpay==1){
				$ismagpay=2;
			}
		}
		
		if($ismagpay>0){
			if($wap==1){
				$paystr1='<p><label for="paytype_magpay"><img src="source/plugin/it618_credits/images/magapp.png" >'.$it618_credits_lang['s1338'].'<input id="paytype_magpay" name="paytype" type="radio" value="MAGAPPX" '.$checked_magpay.'/><span></span></label></p>';
			}else{
				$paystr1='<input type="radio" value="MAGAPPX" id="paytype_magpay" name="paytype" '.$checked_magpay.' style="vertical-align:middle"/><label for="paytype_magpay"><img src="source/plugin/it618_credits/images/chkmagpay.png" style="margin-left:3px; margin-right:3px;height:22px;cursor:pointer;vertical-align:middle" /></label>';
			}
		}
	}
	
	if($ismagpay==1){
		$paystr=$paystr1;
	}
	if($ismagpay==2){
		$paystr.=$paystr1;
	}
	
	$it618_credits = $_G['cache']['plugin']['it618_credits'];
	if($it618_credits['credits_ismoneypay']==1&&$_G['uid']>0){
		if(!($type=='moneypay'||$type=='moneypaywap'||$type=='yqcodepay')){
			if($paystr=='')$checked_money='checked="checked"';
			
			$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
			if($it618_money=='')$it618_money=0;
			
			if($wap==1){
				$paystr.='<p><label for="paytype_money"><img src="source/plugin/it618_credits/images/yue.png" >'.$it618_credits_lang['s678'].' <font color=red>&yen;'.$it618_money.'</font><input id="paytype_money" name="paytype" type="radio" value="money" '.$checked_money.'/><span></span></label></p>';
			}else{
				$paystr.='<input type="radio" value="money" id="paytype_money" name="paytype" '.$checked_money.' style="vertical-align:middle;"/><label for="paytype_money" style="cursor:pointer;"><img src="source/plugin/it618_credits/images/yue.png" style="margin-left:4px; margin-right:3px;height:21px;margin-top:-2px;cursor:pointer;vertical-align:middle;" /><span style="display:inline-block;vertical-align:middle;color:#666;font-size:15px;font-weight:bold;">'.$it618_credits_lang['s678'].' <font color=red style="font-size:15px;font-weight:normal">  &yen;'.$it618_money.'</font></label>';
			}
		}
	}
	
	if(strpos($_GET['id'],'it618_waimai')!==false){
		$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
		if($it618_waimai['waimai_ishdfk']==1){
			if($paystr=='')$checked_hdfk='checked="checked"';
			
			$paystr.='<p><label for="paytype_hdfk"><img src="source/plugin/it618_credits/images/hdfk.png" >'.$it618_waimai['waimai_hdfkname'].'<input id="paytype_hdfk" name="paytype" type="radio" value="hdfk" '.$checked_hdfk.'/><span></span></label></p>';
		}
	}
	
	if(strpos($paystr,'<label')!==false){
		if($wap==1){
			$paystr='<style>
			.it618_creditspay{width:100%;margin-bottom:3px}
			.it618_creditspay p{height:40px;width:100%;line-height:40px;list-style:none; background:#fff;border-bottom:1px solid #f3f3f3;padding-bottom:3px;padding-bottom:3px;float:left;}
			.it618_creditspay p label{width:100%;float:left;}
			.it618_creditspay p img{ width:26px; height:26px; margin-left:6px; margin-right:6px;vertical-align:middle}
			.it618_creditspay input[type="radio"]{display:none;}
			.it618_creditspay input[type="radio"] + span{border:1px solid #CCCCCC;border-radius:20px;width:20px; height:20px; float:right; margin-right:10px;margin-top:11px}
			.it618_creditspay input[type="radio"]:checked + span{border:1px solid #66c068;border-radius:20px;background:url(source/plugin/it618_credits/images/checkbox-on.png) no-repeat;background-size: 20px 20px;}
			</style>
			<div class="it618_creditspay">
				'.$paystr.'
			</div>
			';
		}
		
		$paystr.='it618getpaytype';
	}

	return $paystr;
}
?>