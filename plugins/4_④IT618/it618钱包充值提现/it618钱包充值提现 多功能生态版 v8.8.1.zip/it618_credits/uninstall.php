<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_credits_focus`;

DROP TABLE IF EXISTS `pre_it618_credits_wapstyle`;

DROP TABLE IF EXISTS `pre_it618_credits_iconav`;

DROP TABLE IF EXISTS `pre_it618_credits_bottomnav`;

DROP TABLE IF EXISTS `pre_it618_credits_moneytxtcbl`;

DROP TABLE IF EXISTS `pre_it618_credits_moneycztmp`;

DROP TABLE IF EXISTS `pre_it618_credits_moneysktmp`;

DROP TABLE IF EXISTS `pre_it618_credits_money`;

DROP TABLE IF EXISTS `pre_it618_credits_moneywork`;

DROP TABLE IF EXISTS `pre_it618_credits_sale`;

DROP TABLE IF EXISTS `pre_it618_credits_recharge`;

DROP TABLE IF EXISTS `pre_it618_credits_quan`;

DROP TABLE IF EXISTS `pre_it618_credits_groupzk`;

DROP TABLE IF EXISTS `pre_it618_credits_zhuan`;

DROP TABLE IF EXISTS `pre_it618_credits_transfer`;

DROP TABLE IF EXISTS `pre_it618_credits_txbl`;

DROP TABLE IF EXISTS `pre_it618_credits_set`;

DROP TABLE IF EXISTS `pre_it618_credits_gonggao`;

DROP TABLE IF EXISTS `pre_it618_credits_uset`;

DROP TABLE IF EXISTS `pre_it618_credits_qd_main`;

DROP TABLE IF EXISTS `pre_it618_credits_qd`;

DROP TABLE IF EXISTS `pre_it618_credits_award`;

DROP TABLE IF EXISTS `pre_it618_credits_award_sale`;

DROP TABLE IF EXISTS `pre_it618_credits_buygroup`;

DROP TABLE IF EXISTS `pre_it618_credits_buygroup_sale`;

DROP TABLE IF EXISTS `pre_it618_credits_salepay`;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>