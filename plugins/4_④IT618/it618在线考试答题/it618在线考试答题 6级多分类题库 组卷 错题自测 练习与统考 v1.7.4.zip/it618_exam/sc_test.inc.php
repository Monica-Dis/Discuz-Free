<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_exam/js/jquery.js"></script>
';

showtableheaders(it618_exam_getlang('t225'),'it618_exam_sum');

	echo '<tr><td colspan="15"><div class="fixsel">'.it618_exam_getlang('s97').' <input id="pname" class="txt" style="width:300px;margin-right:1px" /> '.it618_exam_getlang('t239').' <input id="uid" class="txt" style="width:80px;margin-right:1px" /> &nbsp;<input type="button" class="btn" value="'.it618_exam_getlang('t244').'" onclick="findtestlist()" /> </div></td></tr>';
	
	echo '<tr id="tr_playsum"></tr>';
	
	showsubtitle(array(it618_exam_getlang('t226'),it618_exam_getlang('t228'),it618_exam_getlang('t229'),it618_exam_getlang('t231'),it618_exam_getlang('t230')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_exam/wap/images/loading.gif"></td></tr><tbody id="tr_testlist"></tbody>';
	
	echo '<tr id="playpage"></tr>';

showtablefooter(); /*dism��taobao��com*/
echo '
<script>
var playurl="'.$_G['siteurl'].'plugin.php?id=it618_exam:ajax";
var sqlurl="";
function gettestlist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_testlist").style.display="none";
	IT618_EXAM.post(url+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"test_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_EXAM("#tr_playsum").html(tmparr[0]);
	IT618_EXAM("#tr_testlist").html(tmparr[1]);
	IT618_EXAM("#playpage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_testlist").style.display="";
	}, "html");	
	playurl=url;
}
gettestlist(playurl);

function findtestlist(){
	var pname = document.getElementById("pname").value;
	var uid = document.getElementById("uid").value;
	
	sqlurl="&pname="+pname+"&uid="+uid;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_exam:ajax";
	gettestlist(url);
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>