<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$ppp = 10;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$pid=intval($_GET['pid']);

$state0='';$state1='';$state2='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql = "it618_state = 1";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql = "it618_state = 2";$state2='selected="selected"';}

if(submitcheck('it618submit')){
	$ok1=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_goods_user = C::t('#it618_exam#it618_exam_goods_user')->fetch_by_id($delid);
		if($it618_exam_goods_user['it618_state']==1){
			DB::delete('it618_exam_goods_user', "id=$delid");
			$del=$del+1;
		}
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_exam#it618_exam_goods_user')->update($id,array(
				'it618_testid' => $_GET['it618_testid'][$id],
				'it618_name' => $_GET['it618_name'][$id],
				'it618_bz' => $_GET['it618_bz'][$id]
			));
			$ok1=$ok1+1;
		}
	}
	
	it618_cpmsg(it618_exam_getlang('s33').$ok1.' '.it618_exam_getlang('s35').$del.')', "plugin.php?id=it618_exam:sc_product_user$adminsid&pid=$pid", 'succeed');
}

if(submitcheck('it618submit_adds')){
	$ok1=0;
	
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $_GET['it618_name_adds']);
	$line=explode("@||@",$lines);

	foreach($line as $key =>$li)
	{
		$tmpstr=trim($li);
		if($tmpstr!=''){
			$tmparr=explode(',',$tmpstr);
			$it618_uid=intval($tmparr[0]);
			$it618_pici=intval($tmparr[1]);
			if($it618_pici=='')$it618_pici=1;
			$it618_testid=$tmparr[2];
			$it618_name=$tmparr[3];
			$it618_bz=$tmparr[4];
			
			$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_uid);
			if($username!=''){
				$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_goods_user')." WHERE it618_pid=$pid and it618_uid=".$it618_uid);
				if($count==0){
					C::t('#it618_exam#it618_exam_goods_user')->insert(array(
						'it618_pid' => $pid,
						'it618_uid' => $it618_uid,
						'it618_pici' => $it618_pici,
						'it618_testid' => $it618_testid,
						'it618_name' => $it618_name,
						'it618_bz' => $it618_bz,
						'it618_state' => 1
					), true);
					$ok1=$ok1+1;
				}else{
					$errstr.='<br>'.$tmpstr.' '.$it618_exam_lang['t796'];
				}
			}else{
				$errstr.='<br>'.$tmpstr.' '.$it618_exam_lang['t797'];	
			}
		}
	}
	
	it618_cpmsg(it618_exam_getlang('t857').$ok1.$errstr, "plugin.php?id=it618_exam:sc_product_user$adminsid&pid=$pid", 'succeed');
}

if(submitcheck('it618submit_dao')){
	
	if (preg_match('/\.\./', $_GET['it618_name_dao'])||$_GET['it618_name_dao']=='') {
		cpmsg($it618_exam_lang['s1992'], "plugin.php?id=it618_exam:sc_product_user$adminsid&lid=$lid", 'error');
	}
	
	$tmparr=explode("source/plugin/it618_exam/kindeditor",$_GET['it618_name_dao']);
	$file_path='source/plugin/it618_exam/kindeditor'.$tmparr[1];
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_exam/phpexcel/reader.php';

	$data = new Spreadsheet_Excel_Reader();
	
	$data->setOutputEncoding('GB2312');
	
	$data->read(DISCUZ_ROOT.'./'.$file_path);

	error_reporting(E_ALL ^ E_NOTICE);
	
	$ok=0;
	for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {

		$msgtmpstr='';
		
		$it618_uid=it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i][1]));

		if($it618_name==''){
			if(it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i+1][1]))==''&&it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i+2][1]))==''){
				break;
			}else{
				continue;
			}
		}
		
		$it618_pici=it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i][2]));
		if($it618_pici=='')$it618_pici=1;
		$it618_testid=it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i][3]));
		$it618_name=it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i][4]));
		$it618_bz=it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i][5]));
		
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_uid);
		if($username!=''){
			$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_goods_user')." WHERE it618_pid=$pid and it618_uid=".$it618_uid);
			if($count==0){
				C::t('#it618_exam#it618_exam_goods_user')->insert(array(
					'it618_pid' => $pid,
					'it618_uid' => $it618_uid,
					'it618_pici' => $it618_pici,
					'it618_testid' => $it618_testid,
					'it618_name' => $it618_name,
					'it618_bz' => $it618_bz,
					'it618_state' => 1
				), true);
				$ok1=$ok1+1;
			}else{
				$errstr.='<br>'.$tmpstr.' '.$it618_exam_lang['t796'];
			}
		}else{
			$errstr.='<br>'.$tmpstr.' '.$it618_exam_lang['t797'];	
		}
	
	}

	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	it618_cpmsg($it618_exam_lang['t856'].$ok.$msgstr, "plugin.php?id=it618_exam:sc_product_user$adminsid&pid=$pid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_exam:sc_product_user&pid=$pid");

showtableheaders('','it618_exam_goods_user');

	$count = C::t('#it618_exam#it618_exam_goods_user')->count_by_search($it618sql,'',$pid,$_GET['key']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_exam:sc_product_user$adminsid&pid=$pid");
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
<script>
	KindEditor.ready(function(K) {
				var uploadbutton = K.uploadbutton({
					button : K(\'#btn_upfile\')[0],
					fieldName : \'imgFile\',
					url : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&dir=file&filetype=xls\',
					afterUpload : function(data) {
						if (data.error === 0) {
							var url = K.formatUrl(data.url, \'absolute\');
							K(\'#it618_name_dao\').val(url);
						} else {
							alert(data.message);
						}
					},
					afterError : function(str) {
						alert(str);
					}
				});
				uploadbutton.fileBox.change(function(e) {
					uploadbutton.submit();
				});
			});
</script>';

	echo '<tr><td colspan=14>'.it618_exam_getlang('t32').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:150px" /> '.it618_exam_getlang('t33').' <select name="state"><option value=0 '.$state0.'>'.it618_exam_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_exam_getlang('t798').'</option><option value=2 '.$state2.'>'.it618_exam_getlang('t799').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_exam_getlang('s350').'" /></td></tr>';
	
	echo '<tr><td colspan=10>'.it618_exam_getlang('t847').$count.'<span style="float:right;">'.$it618_exam_lang['t356'].'</span></td></tr>';
	showsubtitle(array('',it618_exam_getlang('t375'),$it618_exam_lang['t388'],it618_exam_getlang('t377'),$it618_exam_lang['t378'],it618_exam_getlang('t379'),it618_exam_getlang('t380')));

	foreach(C::t('#it618_exam#it618_exam_goods_user')->fetch_all_by_search(
		$it618sql,'it618_testid,id desc',$pid,$_GET['key'],$startlimit,$ppp
	) as $it618_exam_goods_user) {
		
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$it618_exam_goods_user['it618_uid'])>0){
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_exam_goods_user['it618_uid']);
		}else{
			C::t('#it618_exam#it618_exam_goods_user')->delete_by_id($it618_exam_goods_user['id']);
			continue;
		}
		
		if($it618_exam_goods_user['it618_state']==1){
			$disabled='';
			$it618_state='<font color=red>'.$it618_exam_lang['t798'].'</font>';
		}else{
			$disabled='disabled="disabled"';
			$it618_state='<font color=#390>'.$it618_exam_lang['t799'].'</font>';
		}
		
		$u_avatarimg=it618_exam_discuz_uc_avatar($it618_exam_goods_user['it618_uid'],'middle');
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_exam_goods_user[id]\" $disabled>",
			'<a href="home.php?mod=space&uid='.$it618_exam_goods_user['it618_uid'].'" target="_blank"><img src="'.$u_avatarimg.'" width=23 style="vertical-align:middle"></a> '.$username.'('.$it618_exam_goods_user['it618_uid'].')',
			"<input type=\"text\" class=\"txt\" style=\"width:30px;text-align:center\" name=\"it618_pici[$it618_exam_goods_user[id]]\" value=\"".$it618_exam_goods_user['it618_pici']."\">",
			"<input type=\"text\" class=\"txt\" style=\"width:130px\" name=\"it618_testid[$it618_exam_goods_user[id]]\" value=\"".$it618_exam_goods_user['it618_testid']."\">",
			"<input type=\"text\" class=\"txt\" style=\"width:80px\" name=\"it618_name[$it618_exam_goods_user[id]]\" value=\"".$it618_exam_goods_user['it618_name']."\">",
			"<input type=\"text\" class=\"txt\" style=\"width:400px\" name=\"it618_bz[$it618_exam_goods_user[id]]\" value=\"".$it618_exam_goods_user['it618_bz']."\">",
			$it618_state
		));
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_exam_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_exam_getlang('t27').'" onclick="return confirm(\''.it618_exam_getlang('t28').'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.it618_exam_getlang('t29').'" onclick="return checkvalue()"/><input type=hidden value='.$page.' name=page /></div></td></tr>';
	
	echo '
	<tr><td  colspan=10 style="color:blue">'.it618_exam_getlang('t848').'</td></tr>
	<tr><td  colspan=10>'.it618_exam_getlang('t850').'<br><textarea name="it618_name_adds" style="width:490px;height:200px;margin-top:6px;"></textarea><br><input type="submit" class="btn" name="it618submit_adds" value="'.it618_exam_getlang('t852').'"/></td></tr>
		  <tr><td  colspan=10>'.it618_exam_getlang('t851').'<br><input id="it618_name_dao" name="it618_name_dao" class="txt" style="width:390px"><input type="submit" class="btn" id="btn_upfile" value="'.it618_exam_getlang('t853').'"/><br><input type="submit" class="btn" name="it618submit_dao" value="'.it618_exam_getlang('t854').'"/></td></tr>';

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>