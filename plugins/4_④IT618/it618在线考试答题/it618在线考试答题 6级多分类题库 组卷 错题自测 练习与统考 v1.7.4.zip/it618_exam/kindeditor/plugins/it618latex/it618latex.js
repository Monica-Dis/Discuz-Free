KindEditor.plugin('it618latex', function(K) {
	var self = this, name = 'it618latex';
	self.clickToolbar(name, function() {
		var lang = self.lang(name + '.'),
			html = '<div style="padding:10px 20px;">' +
				'<textarea id="textarealatex" style="display:none"></textarea><iframe src="source/plugin/it618_exam/kindeditor/plugins/it618latex/it618latex.html" style="width:720px;height:430px;padding:3px;border:none"></iframe>' +
				'<div style="margin-top:8px;color:#666">' + lang.about + '</div>' +
				'</div>',
			dialog = self.createDialog({
				name : name,
				width : 768,
				height : 430,
				title : self.lang(name),
				body : html,
				yesBtn : {
					name : self.lang('yes'),
					click : function(e) {
						var html = textarea.val();
						self.insertHtml(html).hideDialog().focus();
					}
				}
			}),
			textarea = K('textarea', dialog.div);
		textarea[0].focus();
	});
});