<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pid=intval($_GET['cid']);
if(!exam_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	if(isset($_GET['e'])){
		if($urltmp!='')$urltmp.='&e='.$_GET['e'];else $urltmp.='e='.$_GET['e'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_exam_getrewrite('exam_product',$pid,'plugin.php?id=it618_exam:product&pid='.$pid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_exam_getrewrite('exam_product',$pid,'plugin.php?id=it618_exam:product&pid='.$pid);
	}
	
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid)){
	$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
	if($it618_exam_shop['it618_state']!=2||$it618_exam_shop['it618_htstate']!=1){
		$error=10;
		$errormsg=it618_exam_getlang('s470');
		$errorurl=it618_exam_getrewrite('video_wap','','plugin.php?id=it618_exam:wap');
	}
	if($it618_exam_shop['it618_uid']==$_G['uid']){
		$isshop=1;
		if($it618_exam_goods['it618_state']==0){
			$tmppname=$it618_exam_lang['s1842'];
		}
	}
}

if($isshop!=1){
	if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
		$error=10;
		$errormsg=it618_exam_getlang('s470');
		$errorurl=it618_exam_getrewrite('video_wap','','plugin.php?id=it618_exam:wap');
	}else{
		if(!it618_exam_issecretok($it618_exam_goods)){
			$error=10;
			$errormsg=it618_exam_getlang('s470');
			$errorurl=it618_exam_getrewrite('video_wap','','plugin.php?id=it618_exam:wap');
		}
	}
}

$footer_mall_wap.='<div style="display:none">'.$it618_exam_shop['it618_tongji'].'</div>';

if($error>0){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_exam:'.$templatename_wap.'/wap_exam');
	return;
}

$navtitle=$tmppname.$it618_exam_goods['it618_name'];

$wapproductad1=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('wapproductad1');
$wapproductad2=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('wapproductad2');

C::t('#it618_exam#it618_exam_goods')->update_it618_views_by_id($pid);

if(C::t('#it618_exam#it618_exam_shop_subscribe')->count_by_shopid_uid($ShopId,$_G['uid'])>0){
	$subscribetitle=$it618_exam_lang['s1397'];
}else{
	$subscribetitle=$it618_exam_lang['s1396'];
}
$shopsubscribes=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_shop_subscribe')." WHERE it618_shopid=".$it618_exam_shop['id']);
$shopviews=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_exam_goods')." WHERE it618_shopid=".$it618_exam_shop['id']);

$teacherurl=it618_exam_getrewrite('exam_teacher',$it618_exam_shop['id'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_shop['id']);
$adlogo='<img src="'.$it618_exam_shop['it618_logo'].'" style="margin-top:3px; max-width:100%; border-radius:3px"/>';

if($it618_exam_shop['it618_logourl']!=''){
	$adlogo='<a href="'.$it618_exam_shop['it618_logourl'].'" target="_blank">'.$adlogo.'</a>';
}

$it618_message=$it618_exam_goods['it618_message'];
$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img class="lazy" data-original="\1"/>',$it618_message);
$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);

$ShopId=$it618_exam_shop['id'];
$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
$testpjcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_test_pj')." WHERE it618_score1>0 and it618_shopid=$ShopId");
$testcount=DB::result_first("SELECT SUM(it618_tests) FROM ".DB::table('it618_exam_goods')." WHERE it618_shopid=$ShopId");

$ptestcount = C::t('#it618_exam#it618_exam_test_exam')->count_by_pid($pid);

if($it618_exam_goods['it618_gtype']==1){
	if($_G['uid']>0){
		if($it618_exam_test_pj=C::t('#it618_exam#it618_exam_test_pj')->fetch_by_pid_uid($it618_exam_goods['id'],$_G['uid'])){
			if($it618_exam_test_pj['it618_score1']==0){
				$upjstr='<span style="float:right; height:26px; line-height:26px; background-color:'.$it618_exam_wapstyle['it618_color1'].'; color:#fff; border-radius:3px; padding:0 10px; margin-top:-10px; cursor:pointer; font-size:14px" id="spanpj" onclick="settestpj1('.$it618_exam_test_pj['id'].')">'.$it618_exam_lang['s500'].'</span>';
			}else{
				$upjstr='<span style="float:right; height:30px; line-height:30px; font-size:14px; margin-top:-10px;color:'.$it618_exam_wapstyle['it618_color1'].'">'.$it618_exam_lang['s741'].'</span>';
			}
		}
	}
	
	if($it618_exam_goods['it618_answertype']==0)$it618_answertype=$it618_exam_lang['s386'];
	if($it618_exam_goods['it618_answertype']==1)$it618_answertype=$it618_exam_lang['s387'];
	
	$pjcount=C::t('#it618_exam#it618_exam_test_pj')->countpj_by_pid($it618_exam_goods['id']);
	if($pjcount>0){
		$pjname=C::t('#it618_exam#it618_exam_class1')->fetch_it618_pj_by_id($it618_exam_goods['it618_class1_id']);
		$pjname=explode("_",$pjname);
		
		$pjscore=C::t('#it618_exam#it618_exam_test_pj')->fetch_sumpjscore_by_pid($it618_exam_goods['id']);
		$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);
		$pjavgscore2=sprintf( "%.1f",$pjscore['score2']/$pjcount);
		$pjavgscore3=sprintf( "%.1f",$pjscore['score3']/$pjcount);
		$pjavgscore4=sprintf( "%.1f",$pjscore['score4']/$pjcount);
		$pjpl1=sprintf( "%.1f",$pjavgscore1/5*100);
		$pjpl2=sprintf( "%.1f",$pjavgscore2/5*100);
		$pjpl3=sprintf( "%.1f",$pjavgscore3/5*100);
		$pjpl4=sprintf( "%.1f",$pjavgscore4/5*100);
		
		$pj1_count1=C::t('#it618_exam#it618_exam_test_pj')->countpj1_by_pid_score($it618_exam_goods['id'],1);
		$pj1_count2=C::t('#it618_exam#it618_exam_test_pj')->countpj1_by_pid_score($it618_exam_goods['id'],2);
		$pj1_count3=C::t('#it618_exam#it618_exam_test_pj')->countpj1_by_pid_score($it618_exam_goods['id'],3);
		$pj1_count4=C::t('#it618_exam#it618_exam_test_pj')->countpj1_by_pid_score($it618_exam_goods['id'],4);
		$pj1_count5=C::t('#it618_exam#it618_exam_test_pj')->countpj1_by_pid_score($it618_exam_goods['id'],5);
		
		$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
		
		$pj1_pl1=intval($pj1_count1/$pjcount*100);
		$pj1_pl2=intval($pj1_count2/$pjcount*100);
		$pj1_pl3=intval($pj1_count3/$pjcount*100);
		$pj1_pl4=intval($pj1_count4/$pjcount*100);
		$pj1_pl5=intval($pj1_count5/$pjcount*100);
		
		$pj=$pjcount.' '.it618_exam_getlang('s482').' '.$pjavgscore1.' '.it618_exam_getlang('s483').':'.$mydpl.'% ';
		$it618_pjpfstr=$pjcount.' '.it618_exam_getlang('s482').' '.$pjavgscore1.' '.it618_exam_getlang('s483').':'.$mydpl.'% ';
	}else{
		$pj=it618_exam_getlang('s484');	
		$it618_pjpfstr=it618_exam_getlang('s484').' ';	
	}
	
	DB::query("UPDATE ".DB::table('it618_exam_goods')." SET it618_pjpfstr='".$it618_pjpfstr."' WHERE id=$pid");
	
	$timeflag=0;$isxgok=0;
	if($it618_exam_goods['it618_xgtype']==0)$isxgok=1;
	
	if($it618_exam_goods['it618_xgtype']==1){
		$timestr=$it618_exam_goods['it618_xgtime1'].' - '.$it618_exam_goods['it618_xgtime2'];
		
		$timetmp1=explode(" ",$it618_exam_goods['it618_xgtime1']);
		$timetmp2=explode(" ",$it618_exam_goods['it618_xgtime2']);
		$timetmp11=explode("-",$timetmp1[0]);
		$timetmp12=explode(":",$timetmp1[1]);
		$timetmp21=explode("-",$timetmp2[0]);
		$timetmp22=explode(":",$timetmp2[1]);
		
		
		$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
		$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
		
		$timeflag=1;$timebgcolor='#ff4628';$timecolor='#fff';
		if($etime<$_G['timestamp']){
			$timeflag=0;$timebgcolor='#eee';$timecolor='#999';
			$timetip=it618_exam_getlang('s952');
		}else{
			if($btime>$_G['timestamp']){
				$timetip=it618_exam_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=$it618_exam_goods['it618_xgtime1'];
			}else{
				$timetip=it618_exam_getlang('s954');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=$it618_exam_goods['it618_xgtime2'];
				$isxgok=1;
			}
		}
		
		$isxg=1;
	}
	
	if($it618_exam_goods['it618_xgtype']==2){
		$timetmp1=explode(" ",$it618_exam_goods['it618_xgtime1']);
		$timetmp2=explode(" ",$it618_exam_goods['it618_xgtime2']);
		$timetmp11=explode("-",$timetmp1[0]);
		$timetmp12=explode(":",$timetmp1[1]);
		$timetmp21=explode("-",$timetmp2[0]);
		$timetmp22=explode(":",$timetmp2[1]);
		
		$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_exam_getlang('s955').' '.$timetmp1[1].' - '.$timetmp2[1];
		
		$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
		$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
		
		$timeflag=1;$timebgcolor='#ff4628';$timecolor='#fff';
		if($etime<$_G['timestamp']){
			$timeflag=0;$timebgcolor='#eee';$timecolor='#999';
			$timetip=it618_exam_getlang('s952');
		}else{
			if($btime>$_G['timestamp']){
				$timetip=it618_exam_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=$it618_exam_goods['it618_xgtime1'];
			}else{
				$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
				$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
				$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
				
				if($btimecur>$_G['timestamp']){
					$timetip=it618_exam_getlang('s953');
					$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
					$etimestr=date('Y-m-d H:i:s', $btimecur);
				}
				
				if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
					$timetip=it618_exam_getlang('s954');
					$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
					$etimestr=date('Y-m-d H:i:s', $etimecur);
					$isxgok=1;
				}
				
				if($etimecur<$_G['timestamp']){
					$timetip=it618_exam_getlang('s953');
					$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
					$etimestr=date('Y-m-d H:i:s', $btimecur1);
				}
			}
		}
		
		$isxg=1;
	}
	
	$goodstypeid=0;
	$goodstypename='';
	$goodstypename1='';
	$n=0;
	
	if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($pid)>0){
		$goodspricestr=it618_exam_getgoodsprice($it618_exam_goods,'goods_price');
		$goodspricestr1=it618_exam_getgoodsprice($it618_exam_goods);
		
		$count=C::t('#it618_exam#it618_exam_goods_type')->count_by_pid_ok_isname1($pid);
		if($count>0){
			$it618_exam_goods_types=C::t('#it618_exam#it618_exam_goods_type')->fetch_name_by_it618_pid1($pid);
		}else{
			$it618_exam_goods_types=C::t('#it618_exam#it618_exam_goods_type')->fetch_name_by_it618_pid($pid);
		}
		
		if(!$it618_exam_goods_typetmp=C::t('#it618_exam#it618_exam_goods_type')->fetch_price_by_it618_pid($pid)){
			if(!$it618_exam_goods_typetmp=C::t('#it618_exam#it618_exam_goods_type')->fetch_score_by_it618_pid($pid)){
			}
		}
		
		foreach($it618_exam_goods_types as $it618_exam_goods_type) {
			$tmpstr='';
			if($it618_exam_goods_type['id']==$it618_exam_goods_typetmp['id']){
				$tmpstr='class="current"';
				$goodstypename=$it618_exam_goods_type['it618_name'];
				$goodstypeid=$it618_exam_goods_type['id'];
				
				$tmpcount='<font color=#999>'.$it618_exam_lang['s1067'].' <font style="color:red">'.$it618_exam_goods_type['it618_count'].'</font></font>';
				
				if($it618_exam_goods_type['it618_xgcount']>0){
					if($it618_exam_goods_type['it618_xgtime']>0){
						$tmpxgstr='<font color=#999>('.$it618_exam_lang['t24'].$it618_exam_goods_type['it618_xgtime'].$it618_exam_lang['t25'].$it618_exam_goods_type['it618_xgcount'].$it618_exam_lang['t57'].')</font>';
					}else{
						$tmpxgstr='<font color=#999>('.$it618_exam_lang['t71'].$it618_exam_goods_type['it618_xgcount'].$it618_exam_lang['t57'].')</font>';
					}
				}
			}
			$goodstypestr.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype\','.$n.',\''.$it618_exam_goods_type['it618_name'].'\')" name="goodstype"><span>'.$it618_exam_goods_type['it618_name'].'</span><i></i></a>';
			$n++;
		}
		
		if($goodstypename!=''){
			$n=0;
			foreach(C::t('#it618_exam#it618_exam_goods_type')->fetch_name1_by_it618_pid_name($pid,$goodstypename) as $it618_exam_goods_type) {
				$tmpstr='';
				if($it618_exam_goods_type['id']==$it618_exam_goods_typetmp['id']){
					$tmpstr='class="current"';
					$goodstypename1=$it618_exam_goods_type['it618_name1'];
					$goodstypeid=$it618_exam_goods_type['id'];
				
					$tmpcount='<font color=#999>'.$it618_exam_lang['s1067'].' <font style="color:red">'.$it618_exam_goods_type['it618_count'].'</font></font>';
					
					if($it618_exam_goods_type['it618_xgcount']>0){
						if($it618_exam_goods_type['it618_xgtime']>0){
							$tmpxgstr='<font color=#999>('.$it618_exam_lang['t24'].$it618_exam_goods_type['it618_xgtime'].$it618_exam_lang['t25'].$it618_exam_goods_type['it618_xgcount'].$it618_exam_lang['t57'].')</font>';
						}else{
							$tmpxgstr='<font color=#999>('.$it618_exam_lang['t71'].$it618_exam_goods_type['it618_xgcount'].$it618_exam_lang['t57'].')</font>';
						}
					}
				}
				
				$goodstypestr1.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype1\','.$n.',\''.$it618_exam_goods_type['it618_name1'].'\')" name="goodstype1"><span>'.$it618_exam_goods_type['it618_name1'].'</span><i></i></a>';
				$n=$n+1;
			}
		}
		
		$goodspricestrtype=$goodspricestr1;
		if($it618_exam_goods['it618_price']>0){
			$goodspricestrtype=$goodspricestr1.' <del style="color:#999;font-size:12px"><em style="font-size:12px">&yen;</em>'.$it618_exam_goods['it618_price'].'</del>';
		}
		
		$exampowerabout=$it618_exam_lang['t4'].'<br>'.$it618_exam_lang['t132'];
		$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
		if($_G['uid']>0){
			$exampower=it618_exam_getpower($_G['uid'],$pid);
			$exampowerabout=$exampower['count'].'<br>'.$it618_exam_lang['t132'];
			if($exampower['state']==1){
				$it618_exam_lang['t192']=$it618_exam_lang['s1466'];
			}
			if(count($vipgroupids)>0){
				$tmpgrouparr=it618_exam_getisvipuser($vipgroupids);
				$isvipuser=count($tmpgrouparr[0]);
			}
		}
		
		$exampowerabout=str_replace('(','',$exampowerabout);
		$exampowerabout=str_replace(')','',$exampowerabout);
		
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;height:15px;margin-top:-1px;margin-right:3px">';
			if($isvipuser>0){
				$exampowerabout='';
				$isvipok=1;
			}
			$it618_isvipstr='<a href="javascript:" id="showvipgroupbtn"><font color=red style="font-size:12px">'.$it618_exam_lang['s926'].'</font></a> <div id="vippaybtn"></div>';
		}
		
		if($_G['uid']>0){
			$it618_video = $_G['cache']['plugin']['it618_video'];
			if($it618_video['seotitle']!=''){
				$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson_exam')." WHERE it618_power=1 and it618_tid=".$pid);
				while($it618_video_goods_lesson_exam = DB::fetch($query)) {
					$isvideopower=it618_exam_getvideopower($it618_video_goods_lesson_exam['it618_pid'],$it618_video_goods_lesson_exam['it618_lid']);
					if($isvideopower==1)break;
				}
			}
		}
	}
}else{
	if($it618_exam_goods['it618_chkstate']==4){
		$tmptime2=strtotime($it618_exam_goods['it618_xgtime1'])+$it618_exam_goods['it618_examtime']*60;
		$it618_exam_goods['it618_xgtime2']=date('Y-m-d H:i', $tmptime2);
		$timestr=$it618_exam_goods['it618_xgtime1'].' - '.$it618_exam_goods['it618_xgtime2'];
		
		$timetmp1=explode(" ",$it618_exam_goods['it618_xgtime1']);
		$timetmp2=explode(" ",$it618_exam_goods['it618_xgtime2']);
		$timetmp11=explode("-",$timetmp1[0]);
		$timetmp12=explode(":",$timetmp1[1]);
		$timetmp21=explode("-",$timetmp2[0]);
		$timetmp22=explode(":",$timetmp2[1]);
		
		$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
		$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
		
		$timeflag=1;$timebgcolor='#ff4628';$timecolor='#fff';
		if($etime<$_G['timestamp']){
			$timeflag=0;$timebgcolor='#eee';$timecolor='#999';
			$timetip=it618_exam_getlang('s1513');
		}else{
			if($btime>$_G['timestamp']){
				$timetip=it618_exam_getlang('s1511');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=$it618_exam_goods['it618_xgtime1'];
			}else{
				$timetip=it618_exam_getlang('s1512');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=$it618_exam_goods['it618_xgtime2'];
				
				if($it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_pid_uid_state12($pid,$_G['uid'])){
					$it618_exam_lang['s1514']=$it618_exam_lang['s1521'];
				}
				$istkok=1;
			}
		}
	}else{
		$timetip=it618_exam_getlang('s1513');
	}
	$isxg=1;
}

$goodspicstr=it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);

$n=1;$ln=1;$vn=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order");
while($it618_exam_goods_lesson = DB::fetch($query)) {
	if($templatename=='default'){
		$dispcount=$it618_exam_goods_lesson['it618_dispcount'];
		
		$it618_exam_goods_lesson['it618_examscore']=str_replace(".0","",$it618_exam_goods_lesson['it618_examscore']);
		if($it618_exam_goods_lesson['it618_randcount']==0){
			$it618_examcount=$it618_exam_lang['s819'].$it618_exam_goods_lesson['it618_questioncount'].$it618_exam_lang['s820'].' '.$it618_exam_goods_lesson['it618_examscore'].$it618_exam_lang['s398'];
		}else{
			$it618_examcount=$it618_exam_lang['s774'].$it618_exam_goods_lesson['it618_randcount'].$it618_exam_lang['s820'].' '.$it618_exam_goods_lesson['it618_examscore'].$it618_exam_lang['s398'];
		}
		
		$limitstr='';
		if($dispcount==0){
			$it618_dispcount=$it618_exam_lang['s775'];
		}else{
			$it618_dispcount=$it618_exam_lang['s822'].$dispcount.$it618_exam_lang['s823'];
			$limitstr='limit '.$dispcount;
		}
		
		$tmpindexarr=explode("|",$it618_exam_lang['s488']);
		
		$examstr.='<tr><td>
							<p class="lessonname_p">'.$tmpindexarr[$ln-1].$it618_exam_goods_lesson['it618_name'].'</p>
							<p class="lessonabout_p">{isdispoption}'.$it618_exam_lang['s818'].$it618_examcount.' '.$it618_dispcount.'</p>
							<table width="100%" class="questiontable">';
	}
	
	if($dispcount>0){
		$vn=1;
		$isdispoption='';
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_questions')." WHERE it618_lid=".$it618_exam_goods_lesson['id']." ORDER BY it618_order $limitstr");
		while($it618_exam_goods_questions = DB::fetch($query1)) {
			
			$it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($it618_exam_goods_questions['it618_qid']);
			$it618_qtypeid=$it618_exam_questions['it618_qtypeid'];
			$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_qtypeid);
			
			$it618_name=$it618_exam_questions['it618_name'];
			if($it618_qtypeid==3){
				$it618_name=it618_exam_getquestionname($it618_name);
			}
			
			if($templatename=='default'){
				$it618_mcqscore='';
				if($it618_exam_goods_questions['it618_mcqscore']>0&&$it618_qtypeid==2){
					$it618_exam_goods_questions['it618_mcqscore']=str_replace(".0","",$it618_exam_goods_questions['it618_mcqscore']);
					$it618_mcqscore=$it618_exam_lang['s242'].$it618_exam_goods_questions['it618_mcqscore'].$it618_exam_lang['s1144'];
				}
				$examstr.='<tr><td id="li_'.$ln.'_'.$vn.'">
								'.$vn.$it618_exam_lang['s1149'].''.$it618_name.'
								<p class="questions_p">'.'[ '.$qtypename.' ] ('.$it618_exam_goods_questions['it618_score'].$it618_exam_lang['s1144'].$it618_mcqscore.')</p>
								{questions_option}
							</td></tr>';
			}
			
			$optionstr='';
			if(($it618_qtypeid==1||$it618_qtypeid==2)&&$it618_exam_goods_lesson['it618_isdispoption']==1){
				$on=1;
				$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']." ORDER BY it618_order");
				while($it618_exam_questions_option = DB::fetch($query2)) {
					if($it618_qtypeid==1){
						$tmpoption='<input type="radio" disabled="disabled">';
					}else{
						$tmpoption='<input type="checkbox" disabled="disabled">';
					}
					
					$optionstr.='<tr><td>'.$tmpoption.' '.it618_exam_getABC($on).$it618_exam_lang['s1149'].$it618_exam_questions_option['it618_name'].'</td></tr>';
					$on=$on+1;
					$isoptionstr=1;
				}
				$optionstr='<table width="100%" class="option_'.$ln.' optiontable" style="display:none">'.$optionstr.'</table>';
			}
			
			$examstr=str_replace("{questions_option}",$optionstr,$examstr);
			
			if($optionstr!=''){
				$isdispoption='<a href="javascript:" id="optionbtn_'.$ln.'" onclick="getoption('.$ln.')">'.$it618_exam_lang['s55'].'</a>';
			}
			
			$vn=$vn+1;
		}
		
		$examstr=str_replace("{isdispoption}",$isdispoption,$examstr);
		
		$examstr=str_replace('id="li_'.$ln.'_'.($vn-1).'">','id="li_'.$ln.'_'.($vn-1).'" style="border:none;padding-bottom:15px">',$examstr);
	}else{
		$optionstr='';
	}
	
	if($isoptionstr==''){
		$examstr=str_replace('onclick="getoption('.$ln.')"','onclick="getoption('.$ln.')" style="display:none"',$examstr);
	}
	
	$examstr.='</table></td></tr>';
	$examstr=str_replace("{isdispoption}",'',$examstr);
	$examstr=str_replace('&it618mediatype=audio"','" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$examstr);
	$ln=$ln+1;
}

$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
$it618_examstr=str_replace("{qcount}",$it618_exam_goods['it618_questioncount'],$it618_exam_lang['s168']);
$it618_examstr=str_replace("{score}",$it618_exam_goods['it618_examscore'],$it618_examstr);
$it618_examstr=str_replace("{time}",$it618_exam_goods['it618_examtime'],$it618_examstr);

$uurl=it618_exam_getrewrite('exam_wap','u@'.$_G['uid'],'plugin.php?id=it618_exam:wap&pagetype=u');
$teacherurl=it618_exam_getrewrite('exam_wap','teacher@'.$it618_exam_goods['it618_shopid'],'plugin.php?id=it618_exam:wap&pagetype=teacher&cid='.$it618_exam_goods['it618_shopid']);

$bottommenu=C::t('#it618_exam#it618_exam_bottomnav')->fetch_by_id(1);

$pjpicjs='<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
				<script src="source/plugin/it618_exam/kindeditor/kindeditor-min.js?v3.9" charset="utf-8"></script>
				<script src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';

if($exampowerabout==''){
	$footercss='margin-bottom:60px;';
}

if($_G['uid']>0){
	$count=C::t('#it618_exam#it618_exam_collect')->count_by_uid_pid($_G['uid'],$pid);
	if($count>0){
		$collectname=$it618_exam_lang['s1650'];
	}else{
		$collectname=$it618_exam_lang['s1648'];
	}
}else{
	$collectname=$it618_exam_lang['s1648'];
}

$testabouturl=it618_exam_getrewrite('exam_wap','testabout@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=testabout&cid='.$pid);

$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$pid.'&e='.$_GET['e'],'?e='.$_GET['e']);
if($it618_exam['exam_saletel']==2){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
	$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=sitetelbd&preurl=".urlencode($tmpurl),"?ac=sitetelbd&preurl=".urlencode($tmpurl));
}

$homeurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename_wap.'/wap_exam');
?>