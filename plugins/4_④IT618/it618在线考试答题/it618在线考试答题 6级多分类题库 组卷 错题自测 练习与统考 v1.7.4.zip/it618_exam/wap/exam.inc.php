<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_exam;

$it618_exam = $_G['cache']['plugin']['it618_exam'];
$creditname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];

if(!exam_is_mobile()){ 
	$tmpurl=it618_exam_getrewrite('exam_home','','plugin.php?id=it618_exam:index');
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

foreach(C::t('#it618_exam#it618_exam_focus')->fetch_all_by_type_order(26) as $it618_exam_focus) {
	if($it618_exam_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_exam_focus['it618_url'].'" target="_blank"><img class="img" src="'.it618_exam_getwapppic('wapad',$it618_exam_focus['id'],$it618_exam_focus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_exam_getwapppic('wapad',$it618_exam_focus['id'],$it618_exam_focus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_exam_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_exam_gonggao = DB::fetch($query)) {
	$it618_title=$it618_exam_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_exam_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_exam_gonggao['it618_color']!=''){
		$it618_title='<font color='.$it618_exam_gonggao['it618_color'].'>'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_exam_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

if($template_set['waphomeico']=='')$template_set['waphomeico']='1|5|12|#666|6';
$waphomeico=explode("|",$template_set['waphomeico']);
$tmpn=$waphomeico[0];
$pppn=$waphomeico[1];
$tmpsize=$waphomeico[2];
$tmpcolor=$waphomeico[3];
$tmpw=$waphomeico[4];
$pppw=100/$pppn;
$tmpn=$tmpn*$pppn;

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_exam_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_exam_iconav = DB::fetch($query)) {
	$it618_title=$it618_exam_iconav['it618_title'];
	
	if($it618_exam_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_exam_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_exam_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_exam_iconav['it618_color'].'">'.$it618_title.'</font>';
	}

	$str_iconav.='<td width="'.$pppw.'%"><a href="'.$it618_exam_iconav['it618_url'].'"'.$it618_target.'><img src="'.$it618_exam_iconav['it618_img'].'" /><br>'.$it618_title.'</a></td>';
	
	if($n%$pppn==0)$str_iconav.='</tr><tr>';
	if($n%$tmpn==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';

	$n=$n+1;
}

if($n>1)$n=$n-1;

if($n%$pppn>0){
	for($i=1;$i<=($pppn-$n%$pppn);$i++){
		$str_iconav.='<td width="'.$pppw.'%"></td>';
	}
}

$str_iconav.='</tr>';
$str_iconav=str_replace('<tr></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"></table></div>','',$str_iconav);
$str_iconav=str_replace('<tr><td','<tr><td width='.$tmpw.'></td><td',$str_iconav);
$str_iconav=str_replace('</td></tr>','</td><td width='.$tmpw.'></td></tr>',$str_iconav);
$str_iconav.='<style>.swiper-slide .iconav{table-layout:fixed;}.swiper-slide .iconav tr td a{color:'.$tmpcolor.';font-size:'.$tmpsize.'px}</style>';

$isiconav=count(explode('<img src',$str_iconav))-1;

$zjsalegoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('weeksalegoods');
$newgoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('newgoods');
$hotgoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('hotgoods');
$waphomead=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('waphomead');

$tmparr=explode(",",$zjsalegoods);
if(count($tmparr)>2){
	$zjsalegoods_count=$tmparr[1];
	$zjsalegoods_order=$tmparr[2];
}else{
	$zjsalegoods_count=8;
	$zjsalegoods_order=1;
}

$tmparr=explode(",",$weeksalegoods);
if(count($tmparr)>2){
	$weeksalegoods_count=$tmparr[1];
	$weeksalegoods_order=$tmparr[2];
}else{
	$weeksalegoods_count=8;
	$weeksalegoods_order=2;
}

$tmparr=explode(",",$newgoods);
if(count($tmparr)>2){
	$newgoods_count=$tmparr[1];
	$newgoods_order=$tmparr[2];
}else{
	$newgoods_count=8;
	$newgoods_order=3;
}

$tmparr=explode(",",$hotgoods);
if(count($tmparr)>2){
	$hotgoods_count=$tmparr[1];
	$hotgoods_order=$tmparr[2];
}else{
	$hotgoods_count=8;
	$hotgoods_order=4;
}

if(!($zjsalegoods_count==0&&$weeksalegoods_count==0&&$newgoods_count==0&&$hotgoods_count==0)){
	$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newgoods"=>$newgoods_order,"hotgoods"=>$hotgoods_order);
	asort($homegoods_arr);
	
	$n=1;
	foreach($homegoods_arr as $key=>$homegoods){
		if($n==1)$current=' class="current" ';else $current=' ';
		if($home_goods_js=='')$home_goods_js='get_home_goods("'.$key.'");';
		if($key=='zjsalegoods'){
			if($IsPinEdu==1){
				$it618_exam_lang['t91']=$it618_exam_lang['s593'];
			}
			$tab_goods.='<li'.$current.'onclick="it618_exam_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_exam_lang['t91'].'</li>';
		}
		
		if($key=='weeksalegoods'){
			$tab_goods.='<li'.$current.'onclick="it618_exam_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_exam_lang['t93'].'</li>';
		}
		
		if($key=='newgoods'){
			$tab_goods.='<li'.$current.'onclick="it618_exam_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_exam_lang['s989'].'</li>';
		}
		
		if($key=='hotgoods'){
			$tab_goods.='<li'.$current.'onclick="it618_exam_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_exam_lang['s990'].'</li>';
		}
		
		$tmpurl=it618_exam_getrewrite('exam_wap','search@0','plugin.php?id=it618_exam:wap&pagetype=search&cid=0');
		if($n==1)$bdstyle=' ;display:';else $bdstyle=' ;display:none';
		$home_goods.='<dl class="list" id="searchli_bd'.($n-1).'" style="border-top:none; margin:0;margin-bottom:10px;'.$bdstyle.'">
						<dd style="background-color:#fff;padding:13px">
							<div style="-webkit-overflow-scrolling:touch;overflow:scroll;">
							<table class="tablelist3" id="home_goods_'.$key.'"></table>
							</div>
						</dd>
					  </dl>';
		
		$n=$n+1;
	}
	
	$homegoods_str='<dl style="margin:0;background-color:#fff;padding:0;padding-top:6px;margin-top:10px">
	<style>
	.divsearchli{border-bottom:#f9f9f9 1px solid;background-color:#fff;}
	.divsearchli ul{height:38px;}
	.divsearchli ul li{height:38px;line-height:38px; margin:0 13px;font-size:15px;}
	</style>
	<div class="divsearchli"><ul>'.$tab_goods.'</ul></div></dl>'.$home_goods.'<script>'.$home_goods_js.'</script>';
}


$allproductlist=it618_exam_getrewrite('exam_wap','product_list@0','plugin.php?id=it618_exam:wap&pagetype=product_list&cid=0');

$hotclassgoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('hotclassgoods');
$hotclassgoods=explode('@@@',$hotclassgoods);
$tmpidsarr=explode(',',$hotclassgoods[2]);
$tdn=1;
for($i=1;$i<=count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i-1]);
	
	$it618sql='g.it618_state=1 and g.id='.$id;
	foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
		$it618sql,'',0,0,0,0,0,'',0,0,0,0
	) as $it618_exam_goods) {
			
		$pj=$it618_exam_goods['it618_pjpfstr'];
		
		$it618_isvip='';
		$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" class="imgvip">';
		}
		
		if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
			$pricestr='<span style="color:#f30">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
		}else{
			$pricestr='<span style="color:#390">'.$it618_exam_lang['s106'].'</span>';
		}
		
		if($it618_exam_goods['it618_price']>0){
			$pricestr.=' <del>&yen;'.$it618_exam_goods['it618_price'].'</del>';
		}
		
		$jfbl='';
		if($it618_exam_goods['it618_jfbl']>0&&$it618_exam_goods['it618_saleprice']>0){
			if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_goods['id'])>0){
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].str_replace(".00","",$it618_exam_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].intval($it618_exam_goods['it618_saleprice']*$it618_exam_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
		
		$examstyle1=$examstyle;
		if($template_set['waphomehot']>0){
			$examstyle1=1;
			if($hotn>$template_set['waphomehot'])break;
		}
	
		if($examstyle1=='1'){
		
			$it618goods_hot.='<tr>
								<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
									<div class="tddes">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' '.$it618_exam_goods['it618_tests'].it618_exam_getlang('s931').'</div>
									<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr='<tr>';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr.='<td '.$tdstr.'><div class="tddiv">
							<a href="'.$tmpurl.'">
							'.$jfbl.'
							<div class="divtime">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' <img src="source/plugin/it618_exam/images/plays.png" class="imguser">'.$it618_exam_goods['it618_tests'].'</div>
							<img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
								<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
							</a></div></td>';
						
			if($tdn%2==0){
				$trtmpstr.='</tr>';
				$it618goods_hot.=$trtmpstr;
			}
			
			$tdn=$tdn+1;
		}
	}
}

if($examstyle=='1'){
	$tmparr=explode('</tr>',$it618goods_hot);
	if(count($tmparr)>1){
		$it618goods_hot=$it618goods_hot.'@@@';
		$it618goods_hot=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$it618goods_hot);
	}
	$tmpdtheight=13;
}else{
	$trtmpstr1=$trtmpstr.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr1);
	if(count($tmparr)>1){
		$trtmpstr=str_replace('<td class="tdleft"','<td class="tdleft tdleft1" style="padding-right:13px"',$trtmpstr.'</tr>');
		$it618goods_hot.=$trtmpstr;
	}
	$tmpdtheight=13;
}

$tmpurl=it618_exam_getrewrite('exam_wap','search@0','plugin.php?id=it618_exam:wap&pagetype=search&cid=0');
if($it618goods_hot!='')$it618goods_hot='<dl class="list">
					<dd><dl style="padding:0;background:none">
						<dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:18px; padding-right:11px;background-color:#fff;height:'.$tmpdtheight.'px;padding-top:20px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_exam_lang['t301'].$it618_exam_lang['s994'].'<img src="source/plugin/it618_exam/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p><img src="source/plugin/it618_exam/template/default_wap/images/hot.png" style="vertical-align:middle;height:23px;margin-top:-5px; margin-right:2px">'.$it618_exam_lang['t314'].'</dt>
						<dd id="dd_goods_hot">
						<table width="100%" class="tablelist'.$examstyle1.'">
							'.$it618goods_hot.'
						</table>
						</dd>
					</dl></dd>
				</dl>';
				
if($template_set['waphometeacher']>0){
	foreach(C::t('#it618_exam#it618_exam_shop')->fetch_all_by_search(
			'it618_state=2 and it618_htstate=1','it618_order desc,it618_views desc','',0,0,$template_set['waphometeacher']
		) as $it618_exam_shop) {
			
		$tmpurl=it618_exam_getrewrite('exam_teacher',$it618_exam_shop['id'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_shop['id']);
		
		$teacherlists.='<td width="145"><a href="'.$tmpurl.'">
									<img width="135" height="135" src="'.$it618_exam_shop['it618_ulogo'].'"/>
									<div class="tdname">'.$it618_exam_shop['it618_name'].'</div>
									<div class="tdabout"><span>'.$it618_exam_shop['it618_about'].'</span></div>
								</a>
								</td>';
	}
				
	$teacherlists='<dl class="list" style="margin-bottom:10px">
					<dd><dl style="padding:0;background:none">
						<dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:18px; padding-right:11px;background-color:#fff;height:13px;padding-top:20px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" class="renzheng">'.$it618_exam_lang['s392'].'<img src="source/plugin/it618_exam/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p><img src="source/plugin/it618_exam/template/default_wap/images/teacher.png" style="vertical-align:middle;height:23px;margin-top:-5px; margin-right:2px">'.$it618_exam_lang['s393'].'</dt>
						<dd style="background-color:#fff;padding:13px">
						<div style="-webkit-overflow-scrolling:touch;overflow:scroll;">
						<table class="tablelist4">
						'.$teacherlists.'
						</table>
						</div>
						</dd>
					</dl></dd>
				</dl>';
				
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
while($it618_exam_class1 = DB::fetch($query1)) {
	
	if($it618_exam_class1['it618_wapgoodscount']==0)continue;
	
	$it618goods='';$tdn=1;
	foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
		'g.it618_gtype=1 and g.it618_state=1','g.it618_order desc,g.id desc',0,$it618_exam_class1['id'],0,0,0,'',0,0,$startlimit,$it618_exam_class1['it618_wapgoodscount']*2
	) as $it618_exam_goods) {
	
		$pj=$it618_exam_goods['it618_pjpfstr'];
		
		$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
		
		$it618_isvip='';
		$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" class="imgvip">';
		}
		
		if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
			$pricestr='<span style="color:#f30">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
		}else{
			$pricestr='<span style="color:#390">'.$it618_exam_lang['s106'].'</span>';
		}
		
		if($it618_exam_goods['it618_price']>0){
			$pricestr.=' <del>&yen;'.$it618_exam_goods['it618_price'].'</del>';
		}
		
		$jfbl='';
		if($it618_exam_goods['it618_jfbl']>0&&$it618_exam_goods['it618_saleprice']>0){
			if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_goods['id'])>0){
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].str_replace(".00","",$it618_exam_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].intval($it618_exam_goods['it618_saleprice']*$it618_exam_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		if($examstyle=='1'){
		
			$it618goods.='<tr>
								<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
									<div class="tddes">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' '.$it618_exam_goods['it618_tests'].it618_exam_getlang('s931').'</div>
									<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr='<tr>';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr.='<td '.$tdstr.'><div class="tddiv">
							<a href="'.$tmpurl.'">
							'.$jfbl.'
							<div class="divtime">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' <img src="source/plugin/it618_exam/images/plays.png" class="imguser">'.$it618_exam_goods['it618_tests'].'</div>
							<img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
								<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
							</a></div></td>';
						
			if($tdn%2==0){
				$trtmpstr.='</tr>';
				$it618goods.=$trtmpstr;
			}
			
			$tdn=$tdn+1;
		}
	}
	
	if($examstyle=='1'){
		$tmparr=explode('</tr>',$it618goods);
		if(count($tmparr)>1){
			$it618goods=$it618goods.'@@@';
			$it618goods=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$it618goods);
		}
		$tmpdtheight=13;
	}else{
		$trtmpstr1=$trtmpstr.'@@@';
		$tmparr=explode('</td>@@@',$trtmpstr1);
		if(count($tmparr)>1){
			$trtmpstr=str_replace('<td class="tdleft"','<td class="tdleft tdleft1" style="padding-right:13px"',$trtmpstr.'</tr>');
			$it618goods.=$trtmpstr;
		}
		$tmpdtheight=13;
	}
		
	$tmpurl=it618_exam_getrewrite('exam_wap','search@'.$it618_exam_class1['id'],'plugin.php?id=it618_exam:wap&pagetype=search&cid='.$it618_exam_class1['id']);
	$str_goods.='<dl class="list" style="margin:0;margin-bottom:10px;">
					<dd><dl style="padding:0">
						<dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:18px; padding-right:11px;background-color:#fff;height:'.$tmpdtheight.'px;padding-top:23px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_exam_lang['t301'].$it618_exam_lang['s994'].'<img src="source/plugin/it618_exam/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p>'.$it618_exam_class1['it618_classname'].'</dt>
						<dd id="dd_goods'.$it618_exam_class1['id'].'">
						<table width="100%" class="tablelist'.$examstyle.'">
							'.$it618goods.'
						</table>
						</dd>
					</dl></dd>
				</dl>';

}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods')." where it618_chkstate=4 order by UNIX_TIMESTAMP(it618_xgtime1)");
while($it618_exam_goods = DB::fetch($query)) {
	
	$csstmp='';
	if($livecontent==''){
		$tmpcontent=it618_exam_getlivecontent($it618_exam_goods['id'],1);
		$tmparr=explode("it618_split",$tmpcontent);
		$livecontent=$tmparr[0];
		if($tmparr[1]!=''){
			$timestr='serverTime="'.$tmparr[1].'";
		endTime="'.$tmparr[2].'";
		Czgou();
		curliveid='.$it618_exam_goods['id'].';';
		}
		$csstmp='style="background-color:#f6f6f6"';
	}
	
	$it618_exam_goods['it618_xgtime1']=strtotime($it618_exam_goods['it618_xgtime1']);
	
	$livestate='';
	if($it618_exam_goods['it618_xgtime1']>$_G['timestamp']){
		$livestate='<font color=red style="font-size:11px">'.it618_exam_gettime1($it618_exam_goods['it618_xgtime1']).$it618_exam_lang['s1522'].'</font>';
	}
	
	if($it618_exam_goods['it618_xgtime1']<$_G['timestamp']&&$_G['timestamp']<($it618_exam_goods['it618_xgtime1']+$it618_exam_goods['it618_examtime']*60)){
		$livestate='<img src="source/plugin/it618_exam/images/ks1.png" style="margin-right:1px;margin-top:-1px;height:15px"> <font color=#ccc style="font-size:10px">'.$it618_exam_lang['s1523'].'</font>';
	}
	
	$livestr.='<tr id="'.$it618_exam_goods['id'].'" '.$csstmp.'>
					<td>
					'.$isuserstr.'<span style="font-size:13px;color:#333">'.cutstr($it618_exam_goods['it618_name'],28,'...').'</span> '.$livestate.'
					</td>
				</tr>';
	$n=$n+1;
}

if($n==1)$livestr=str_replace("background-color:#f6f6f6","",$livestr);

if($n<5)$livestrheight=$n*45;else $livestrheight=180;

$tmplivearr=explode("|",$template_set['waphomelive']);
if($tmplivearr[1]=='')$tmplivearr[1]=$it618_exam_lang['s1524'];
if($tmplivearr[0]==1)$liveshow='';else $liveshow='none';

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename_wap.'/wap_exam');
?>