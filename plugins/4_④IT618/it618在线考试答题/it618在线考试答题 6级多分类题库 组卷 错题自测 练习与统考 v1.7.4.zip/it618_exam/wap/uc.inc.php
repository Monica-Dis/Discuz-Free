<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!exam_is_mobile()){
	dheader("location:$exam_home");
}

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_exam_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_exam:'.$templatename_wap.'/wap_exam');
	return;
}

$menutype=intval($_GET['cid']);
if($menutype==0)$menutype=1;
if($menutype==1){$current1='class="current"';$navtitle=it618_exam_getlang('t8');}
if($menutype==2){$current2='class="current"';$navtitle=it618_exam_getlang('s73');}
if($menutype==3){$current3='class="current"';$navtitle=it618_exam_getlang('s458');}
if($menutype==4){$current4='class="current"';$navtitle=it618_exam_getlang('s846');}
if($menutype==5){$current5='class="current"';$navtitle=it618_exam_getlang('s448');}
if($menutype==6){$current6='class="current"';$navtitle=it618_exam_getlang('s935');}
if($menutype==7){$current7='class="current"';$navtitle=it618_video_getlang('s1654');}

$ucurl1=it618_exam_getrewrite('exam_wap','uc@1','plugin.php?id=it618_exam:wap&pagetype=uc&cid=1');
$ucurl2=it618_exam_getrewrite('exam_wap','uc@2','plugin.php?id=it618_exam:wap&pagetype=uc&cid=2');
$ucurl3=it618_exam_getrewrite('exam_wap','uc@3','plugin.php?id=it618_exam:wap&pagetype=uc&cid=3');
$ucurl4=it618_exam_getrewrite('exam_wap','uc@4','plugin.php?id=it618_exam:wap&pagetype=uc&cid=4');
$ucurl5=it618_exam_getrewrite('exam_wap','uc@5','plugin.php?id=it618_exam:wap&pagetype=uc&cid=5');
$ucurl6=it618_exam_getrewrite('exam_wap','uc@6','plugin.php?id=it618_exam:wap&pagetype=uc&cid=6');
$ucurl7=it618_exam_getrewrite('exam_wap','uc@7','plugin.php?id=it618_exam:wap&pagetype=uc&cid=7');

if($menutype==4){
	if($it618_exam_user=C::t('#it618_exam#it618_exam_user')->fetch_by_uid($_G['uid'])){
		if($it618_exam_user['it618_isadderr']==1)$tmpadderrstr='checked="checked"';
	}
}

$utestabouturl=it618_exam_getrewrite('exam_wap','utestabout','plugin.php?id=it618_exam:wap&pagetype=utestabout');

if($menutype==6){
	global $oss;
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/php/aliyunossconfig.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/php/aliyunossconfig.php';
		if($it618_isok==1){
			$oss='&oss';
		}
	}
	
	$pjpicjs='<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
				<script src="source/plugin/it618_exam/kindeditor/kindeditor-min.js" charset="utf-8"></script>
				<script src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';
}

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename_wap.'/wap_exam');
?>