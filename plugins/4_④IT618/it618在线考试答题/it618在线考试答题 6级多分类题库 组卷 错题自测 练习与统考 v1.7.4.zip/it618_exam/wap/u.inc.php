<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!exam_is_mobile()){
	dheader("location:$exam_home");
}

$navtitle=it618_exam_getlang('t389');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_exam_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_exam:'.$templatename_wap.'/wap_exam');
	return;
}

$menuusername=$_G['username'];
$u_avatarimg=it618_exam_discuz_uc_avatar($_G['uid'],'middle');
$creditname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];
$creditnum=DB::result_first("select extcredits".$it618_exam['exam_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_myvip=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$viplogo='source/plugin/it618_credits/images/group.png';
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
	$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	$viplogo='source/plugin/it618_group/images/group.png';
}

if($IsUnion==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
}

$ucurl1=it618_exam_getrewrite('exam_wap','uc@1','plugin.php?id=it618_exam:wap&pagetype=uc&cid=1');
$ucurl2=it618_exam_getrewrite('exam_wap','uc@2','plugin.php?id=it618_exam:wap&pagetype=uc&cid=2');
$ucurl3=it618_exam_getrewrite('exam_wap','uc@3','plugin.php?id=it618_exam:wap&pagetype=uc&cid=3');
$ucurl4=it618_exam_getrewrite('exam_wap','uc@4','plugin.php?id=it618_exam:wap&pagetype=uc&cid=4');
$ucurl5=it618_exam_getrewrite('exam_wap','uc@5','plugin.php?id=it618_exam:wap&pagetype=uc&cid=5');
$ucurl6=it618_exam_getrewrite('exam_wap','uc@6','plugin.php?id=it618_exam:wap&pagetype=uc&cid=6');
$ucurl7=it618_exam_getrewrite('exam_wap','uc@7','plugin.php?id=it618_exam:wap&pagetype=uc&cid=7');
$subscribeurl=it618_exam_getrewrite('exam_wap','subscribe@'.$_G['uid'],'plugin.php?id=it618_exam:wap&pagetype=subscribe');

$collectcount=C::t('#it618_exam#it618_exam_collect')->count_by_search(0,'','','',$_G['uid']);

$subscribecount=C::t('#it618_exam#it618_exam_shop_subscribe')->count_by_search(0,'','',$_G['uid']);

$salecount=C::t('#it618_exam#it618_exam_sale')->count_by_search(0,"s.it618_state!=0 ",'','',$_G['uid']);
$salemoney=C::t('#it618_exam#it618_exam_sale')->sum_money_by_search(0,"s.it618_state!=0 ",'','',$_G['uid']);

$ucgoodscount=C::t('#it618_exam#it618_exam_goods_count')->count_by_search(0,'','','',$_G['uid']);

$testcount=C::t('#it618_exam#it618_exam_test_exam')->count_by_search(0, '', '', '', $_G['uid']);

$utestcount=C::t('#it618_exam#it618_exam_utest_exam')->count_by_search('', '', $_G['uid']);

$errcount=C::t('#it618_exam#it618_exam_errquestions')->count_by_search('', '', '', $_G['uid']);

$testpjcount1=C::t('#it618_exam#it618_exam_test_pj')->count_by_search('it618_score1>0','',0,$_G['uid']);
$testpjcount2=C::t('#it618_exam#it618_exam_test_pj')->count_by_search('','',0,$_G['uid']);

$shoptmp=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid_ok($_G['uid']);
if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
	$scurl=it618_exam_getrewrite('exam_wap','sc@'.$shoptmp['id'],'plugin.php?id=it618_exam:wap&pagetype=sc&cid='.$shoptmp['id']);
	$scsubscribeurl=it618_exam_getrewrite('exam_wap','sc_subscribe@'.$shoptmp['id'],'plugin.php?id=it618_exam:wap&pagetype=sc_subscribe&cid='.$shoptmp['id']);
	$scgwcurl=it618_exam_getrewrite('exam_wap','sc_gwc@'.$shoptmp['id'],'plugin.php?id=it618_exam:wap&pagetype=sc_gwc&cid='.$shoptmp['id']);
	$teacherurl=it618_exam_getrewrite('exam_wap','teacher@'.$shoptmp['id'],'plugin.php?id=it618_exam:wap&pagetype=teacher&cid='.$shoptmp['id']);
	
	$sccount=C::t('#it618_exam#it618_exam_sale')->count_by_search($shoptmp['id'],"s.it618_tel!='' and s.it618_state!=0 ");
	$scmoney=C::t('#it618_exam#it618_exam_sale')->sum_money_by_search($shoptmp['id'],"s.it618_tel!='' and s.it618_state!=0 ");
	$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods')." WHERE it618_shopid=".$shoptmp['id']." and it618_state=1");
	
	$sctesturl=it618_exam_getrewrite('exam_wap','sc_test@'.$shoptmp['id'],'plugin.php?id=it618_exam:wap&pagetype=sc_test&cid='.$shoptmp['id']);
	$sctestcount=C::t('#it618_exam#it618_exam_test_exam')->count_by_search($shoptmp['id']);
	
	$isshop=1;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename_wap.'/wap_exam');
?>