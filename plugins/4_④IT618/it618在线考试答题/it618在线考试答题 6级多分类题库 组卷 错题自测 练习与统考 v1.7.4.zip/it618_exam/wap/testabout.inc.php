<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];

$pid=intval($_GET['cid']);
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

if(!exam_is_mobile()){ 
	$tmpurl=it618_exam_getrewrite('exam_testabout',$pid,'plugin.php?id=it618_exam:testabout&pid='.$pid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
	$error=10;
	$errormsg=it618_exam_getlang('s470');
	$errorurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
}else{
	if(!it618_exam_issecretok($it618_exam_goods)){
		$error=10;
		$errormsg=it618_exam_getlang('s470');
		$errorurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
	}
	
	$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
	if($it618_exam_shop['it618_state']!=2||$it618_exam_shop['it618_htstate']!=1){
		$error=10;
		$errormsg=it618_exam_getlang('s470');
		$errorurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
	}
}

if($error>0){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_exam:'.$templatename_wap.'/wap_exam');
	return;
}

$navtitle=$it618_exam_goods['it618_name'];

if($_G['uid']>0){
	if($it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_pid_uid_state12($pid,$_G['uid'])){
		$tmpurl=it618_exam_getrewrite('exam_wap','test@'.$it618_exam_test_exam['id'],'plugin.php?id=it618_exam:wap&pagetype=test&cid='.$it618_exam_test_exam['id']);
		dheader("location:$tmpurl"); /*dism - taobao - com*/
	}
	
	$it618_exam_testabout=getcookie('it618_exam_testabout'.$pid);
	if($it618_exam_testabout==''){
		$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$pid);
		dheader("location:$tmpurl"); /*dism - taobao - com*/
	}
	dsetcookie('it618_exam_testabout'.$pid,'');
	
	if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($pid)==0){
		$isok=1;
	}else{
		$exampower=it618_exam_getpower($_G['uid'],$pid);
		$exampowerabout=$exampower['count'];
		if($exampower['state']==1){
			$isok=1;
		}else{
			$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
			if(count($vipgroupids)>0){
				$tmpgrouparr=it618_exam_getisvipuser($vipgroupids);
				$isvipuser=count($tmpgrouparr[0]);
				
				if($isvipuser>0){
					$isok=1;
					$isvipok=1;
				}
			}	
		}
	}
}else{
	$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$pid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if($isok==1){
	$tmpcode=md5($_G['timestamp'].FORMHASH.rand());
		
	C::t('#it618_exam#it618_exam_examwork')->insert(array(
		'it618_code' => $tmpcode,
		'it618_exam' => 'it618_split'.$pid
	), true);
}else{
	$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$pid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$menuusername=$_G['username'];
$u_avatarimg=it618_exam_discuz_uc_avatar($_G['uid'],'middle');

if($templatename=='default'){
	$tmparr=explode('src="',$it618_exam['exam_logo']);
	$tmparr1=explode('"',$tmparr[1]);
	$logosrc=$tmparr1[0];
}

$examname1=str_replace("{examname}",'<span>'.$it618_exam_goods['it618_name'].'</span>',$it618_exam_lang['s4']);

$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
$examname2=str_replace("{qcount}",$it618_exam_goods['it618_questioncount'],$it618_exam_lang['s168']);
$examname2=str_replace("{score}",$it618_exam_goods['it618_examscore'],$examname2);
$examname2=str_replace("{time}",$it618_exam_goods['it618_examtime'],$examname2);

$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order");
while($it618_exam_goods_lesson = DB::fetch($query)) {
	$it618_exam_goods_lesson['it618_examscore']=str_replace(".0","",$it618_exam_goods_lesson['it618_examscore']);
	$tmplessonstr=str_replace("{qcount}",$it618_exam_goods_lesson['it618_questioncount'],$it618_exam_lang['s193']);
	$tmplessonstr=str_replace("{score}",$it618_exam_goods_lesson['it618_examscore'],$tmplessonstr);
	$lessonstr.='<li>'.it618_exam_strip_tags($it618_exam_goods_lesson['it618_name']).$tmplessonstr.'</li>';
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename_wap.'/wap_exam');
?>