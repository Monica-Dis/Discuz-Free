<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];

$eid=intval($_GET['cid']);
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

if(!exam_is_mobile()){ 
	$tmpurl=it618_exam_getrewrite('exam_utest',$eid,'plugin.php?id=it618_exam:utest&eid='.$eid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if(!$it618_exam_utest_exam=C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_id($eid)){
	$tmpurl=it618_exam_getrewrite('exam_home','','plugin.php?id=it618_exam:index');
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}else{
	if($_GET['qid']>0){
		$qidn=1;
		$query = DB::query("SELECT * FROM ".DB::table('it618_exam_utest_exam_questions')." WHERE it618_eid=".$eid." ORDER BY it618_order,id");
		while($it618_exam_utest_exam_questions = DB::fetch($query)) {
			if($it618_exam_utest_exam_questions['it618_qid']==$_GET['qid']){
				break;
			}
			$qidn=$qidn+1;
		}
	}

	$tmpcode=md5($_G['timestamp'].FORMHASH.rand());
		
	C::t('#it618_exam#it618_exam_uexamwork')->insert(array(
		'it618_code' => $tmpcode,
		'it618_tmpid' => $eid
	), true);
}

$navtitle=$it618_exam_lang['s1385'];
$paperurl=it618_exam_getrewrite('exam_wap','uc@5','plugin.php?id=it618_exam:wap&pagetype=uc&cid=5');

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename_wap.'/wap_exam');
?>