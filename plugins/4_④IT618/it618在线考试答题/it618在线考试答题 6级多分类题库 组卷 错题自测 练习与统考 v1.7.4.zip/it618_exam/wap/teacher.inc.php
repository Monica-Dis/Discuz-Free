<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lid=intval($_GET['cid']);
if(!exam_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_exam_getrewrite('exam_teacher',$lid,'plugin.php?id=it618_exam:teacher&lid='.$lid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_exam_getrewrite('exam_teacher',$lid,'plugin.php?id=it618_exam:teacher&lid='.$lid);
	}

	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if($it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($lid)){	
	$it618_state=$it618_exam_shop['it618_state'];
	if($it618_state==0){
		$error=1;
		$errormsg=it618_exam_getlang('s334');
	}elseif($it618_state==1){
		$error=1;
		$errormsg=it618_exam_getlang('s335');
	}else{
		$it618_htstate=$it618_exam_shop['it618_htstate'];
		if($it618_htstate==0){
			$error=1;
			$errormsg=it618_exam_getlang('s336');
		}elseif($it618_htstate==2){
			$error=1;
			$errormsg=it618_exam_getlang('s337');
		}else{
			$ShopId=$it618_exam_shop['id'];
		}
	}
}else{
	$error=1;
	$errormsg=it618_exam_getlang('s338');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_exam:'.$templatename_wap.'/wap_exam');
	return;
}

$footer_mall_wap.='<div style="display:none">'.$it618_exam_shop['it618_tongji'].'</div>';

$navtitle=$it618_exam_shop['it618_name'];

$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
$testpjcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_test_pj')." WHERE it618_score1>0 and it618_shopid=$ShopId");
$salecount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_sale')." WHERE it618_shopid=$ShopId and it618_state!=0");
$testcount=DB::result_first("SELECT SUM(it618_tests) FROM ".DB::table('it618_exam_goods')." WHERE it618_shopid=$ShopId");

if(C::t('#it618_exam#it618_exam_shop_subscribe')->count_by_shopid_uid($ShopId,$_G['uid'])>0){
	$subscribetitle=$it618_exam_lang['s1397'];
}else{
	$subscribetitle=$it618_exam_lang['s1396'];
}
$shopsubscribes=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_shop_subscribe')." WHERE it618_shopid=".$it618_exam_shop['id']);
$shopviews=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_exam_goods')." WHERE it618_shopid=".$it618_exam_shop['id']);

if($it618_exam['exam_style']>2){
	$examstyle=getcookie('examstyle');
	if($examstyle==''){
		if($it618_exam['exam_style']==3)$examstyle='1';else $examstyle='2';
	}
}else{
	if($it618_exam['exam_style']==1)$examstyle='1';else $examstyle='2';
}

$shopgoodsarr=explode("it618_split",it618_exam_getshopgoods($ShopId,1,1));

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename_wap.'/wap_exam');
?>