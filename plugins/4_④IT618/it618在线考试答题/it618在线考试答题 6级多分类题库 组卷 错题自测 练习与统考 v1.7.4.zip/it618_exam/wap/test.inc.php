<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];

$eid=intval($_GET['cid']);
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

if(!exam_is_mobile()){ 
	$tmpurl=it618_exam_getrewrite('exam_test',$eid,'plugin.php?id=it618_exam:test&eid='.$eid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if(!$it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($eid)){
	$tmpurl=it618_exam_getrewrite('exam_home','','plugin.php?id=it618_exam:index');
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}else{
	$pid=$it618_exam_test_exam['it618_pid'];
	
	if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
		$error=10;
		$errormsg=it618_exam_getlang('s470');
		$errorurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
	}else{
		if(!it618_exam_issecretok($it618_exam_goods)){
			$error=10;
			$errormsg=it618_exam_getlang('s470');
			$errorurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
		}
		
		$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
		if($it618_exam_shop['it618_state']!=2||$it618_exam_shop['it618_htstate']!=1){
			$error=10;
			$errormsg=it618_exam_getlang('s470');
			$errorurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
		}
	}
	
	if($error>0){
		$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
		include template('it618_exam:'.$templatename_wap.'/wap_exam');
		return;
	}
	
	$paperurl=it618_exam_getrewrite('exam_wap','product@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$pid);
	
	$tdwdith=25;
	if($it618_exam_test_exam['it618_uid']!=$_G['uid']){
		if($it618_exam_test_exam['it618_state']==3){
			if($it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($_G['uid'])){
					
				$it618_state=$it618_exam_shop['it618_state'];
				if($it618_state==0){
					echo it618_exam_getlang('s334');exit;
				}elseif($it618_state==1){
					echo it618_exam_getlang('s335');exit;
				}else{
					$it618_htstate=$it618_exam_shop['it618_htstate'];
					if($it618_htstate==0){
						echo it618_exam_getlang('s336');exit;
					}elseif($it618_htstate==2){
						echo it618_exam_getlang('s337');exit;
					}else{
						if($it618_exam_test_exam['it618_shopid']!=$it618_exam_shop['id']){
							dheader("location:$paperurl");
						}else{
							$examuname=it618_exam_getusername($it618_exam_test_exam['it618_uid']);
							$examuavatarimg=it618_exam_discuz_uc_avatar($it618_exam_test_exam['it618_uid'],'middle');
							$tdwdith=20;
						}
					}
				}
				
			}
		}else{
			dheader("location:$paperurl");
		}
	}

	$tmpcode=md5($_G['timestamp'].FORMHASH.rand());
	
	if($_GET['qid']>0){
		$qidn=1;
		$query = DB::query("SELECT * FROM ".DB::table('it618_exam_test_exam_questions')." WHERE it618_eid=".$eid." ORDER BY it618_order,id");
		while($it618_exam_test_exam_questions = DB::fetch($query)) {
			if($it618_exam_test_exam_questions['it618_qid']==$_GET['qid']){
				break;
			}
			$qidn=$qidn+1;
		}
	}
	
	$it618_exam_test_pj=C::t('#it618_exam#it618_exam_test_pj')->fetch_by_pid_uid($pid,$_G['uid']);
		
	C::t('#it618_exam#it618_exam_examwork')->insert(array(
		'it618_code' => $tmpcode,
		'it618_exam' => 'it618_split'.$eid
	), true);
}

$navtitle=$it618_exam_goods['it618_name'];

$kindeditorjs='<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
			<script src="source/plugin/it618_exam/kindeditor/kindeditor-min.js?'.$it618_exam_lang['version'].'" charset="utf-8"></script>
			<script src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename_wap.'/wap_exam');
?>