<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function pay_success($out_trade_no){
	global $_G;
	
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
		if($it618_salepay['it618_state']==1)return;
	}else{
		return;	
	}
	
	$salepay_saletype=$it618_salepay['it618_saletype'];
	$salepay_saleid=$it618_salepay['it618_saleid'];
	$salepay_paytype=$it618_salepay['it618_paytype'];
	$salepay_payid=$it618_salepay['it618_payid'];
	$salepay_url=$it618_salepay['it618_url'];
	$salepay_wap=$it618_salepay['it618_wap'];

	require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_exam_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_exam_delsalework();
		}
	}
	C::t('#it618_exam#it618_exam_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	
	if($salepay_saletype=='0501'){
		$it618_exam_sale=C::t('#it618_exam#it618_exam_sale')->fetch_by_id($salepay_saleid);
			
		if($it618_exam_sale['it618_state']!=1){
			C::t('#it618_exam#it618_exam_sale')->update($salepay_saleid,array(
				'it618_state' => 1,
			));
			
			if($it618_exam_sale['it618_tuijid']>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_exam_sale['it618_tuijid'],$salepay_saleid);
			}
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			for($i=1;$i<=8;$i++){
				if($it618_exam_sale['it618_credit'.$i]>0){
					C::t('common_member_count')->increase($it618_exam_sale['it618_uid'], array(
						'extcredits'.$i => (0-$it618_exam_sale['it618_credit'.$i]))
					);
				}
			}
			
			it618_exam_updategoodscount($it618_exam_sale);
			
			it618_exam_qrxf($it618_exam_sale['id']);
			
			it618_exam_delsalework();
	
			it618_exam_sendmessage('sale_user',$it618_exam_sale['id']);
			it618_exam_sendmessage('sale_shop',$it618_exam_sale['id']);
			it618_exam_sendmessage('sale_admin',$it618_exam_sale['id']);
			
			return 'success';
		}
	
	}
	
	if($salepay_saletype=='0502'){
		$it618_exam_gwcsale_main=C::t('#it618_exam#it618_exam_gwcsale_main')->fetch_by_id($salepay_saleid);
			
		if($it618_exam_gwcsale_main['it618_state']!=1){
			C::t('#it618_exam#it618_exam_gwcsale_main')->update($salepay_saleid,array(
				'it618_state' => 1
			));
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			foreach(C::t('#it618_exam#it618_exam_gwcsale')->fetch_all_by_gwcid($salepay_saleid) as $it618_exam_gwcsale) {
				
				if($IsUnion==1&&$it618_exam_gwcsale['it618_tuijid']>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					$it618_tuijid=Union_IsTuiJoin('video',$it618_exam_gwcsale['it618_pid'],$it618_exam_gwcsale['it618_tuijid']);
				}
				
				$id = C::t('#it618_exam#it618_exam_sale')->insert(array(
					'it618_gwcid' => $salepay_saleid,
					'it618_shopid' => $it618_exam_gwcsale['it618_shopid'],
					'it618_uid' => $it618_exam_gwcsale['it618_uid'],
					'it618_pid' => $it618_exam_gwcsale['it618_pid'],
					'it618_gtypeid' => $it618_exam_gwcsale['it618_gtypeid'],
					'it618_tuijid' => $it618_tuijid,
					'it618_price' => $it618_exam_gwcsale['it618_price'],
					'it618_jfid' => $it618_exam_gwcsale['it618_jfid'],
					'it618_score' => $it618_exam_gwcsale['it618_score'],
					'it618_count' => $it618_exam_gwcsale['it618_count'],
					'it618_quanmoney' => $it618_exam_gwcsale['it618_quanmoney'],
					'it618_vipzk' => $it618_exam_gwcsale['it618_vipzk'],
					'it618_sfmoney' => $it618_exam_gwcsale['it618_sfmoney'],
					'it618_sfscore' => $it618_exam_gwcsale['it618_sfscore'],
					'it618_jfbl' => $it618_exam_gwcsale['it618_jfbl'],
					'it618_tel' => $it618_exam_gwcsale['it618_tel'],
					'it618_state' => 1,
					'it618_time' => $it618_exam_gwcsale['it618_time']
				), true);
				
				if($it618_tuijid>0){
					Union_TuiTC_Add($it618_tuijid,$id);
				}
				
				$it618_exam_sale=C::t('#it618_exam#it618_exam_sale')->fetch_by_id($id);
				
				for($i=1;$i<=8;$i++){
					if($it618_exam_sale['it618_credit'.$i]>0){
						C::t('common_member_count')->increase($it618_exam_sale['it618_uid'], array(
							'extcredits'.$i => (0-$it618_exam_sale['it618_credit'.$i]))
						);
					}
				}
				
				it618_exam_updategoodscount($it618_exam_sale);
			
				it618_exam_qrxf($it618_exam_sale['id']);
			}
			
			C::t('#it618_exam#it618_exam_gwcsale')->delete_by_uid($it618_exam_gwcsale_main['it618_uid']);
			C::t('#it618_exam#it618_exam_gwc')->delete_by_uid($it618_exam_gwcsale_main['it618_uid']);
			
			it618_exam_delsalework();

			it618_exam_sendmessage('gwc_user',$it618_exam_gwcsale_main['id']);
			foreach(C::t('#it618_exam#it618_exam_sale')->fetch_all_shopid_by_gwcid($it618_exam_gwcsale_main['id']) as $shopids) {
				it618_exam_sendmessage('gwc_shop',$it618_exam_gwcsale_main['id'],$shopids['it618_shopid']);
			}
			it618_exam_sendmessage('gwc_admin',$it618_exam_gwcsale_main['id']);
			
			return 'success';

		}
	
	}
	
	it618_exam_delsalework();

}
//From: Dism��taobao��com
?>