<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$pid=intval($_GET['pid']);
$preurl=$_GET['preurl'];
$preurl1=$_GET['preurl1'];
$urlsql='&pid='.$pid;
$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);
$it618_price = DB::result_first("SELECT it618_price FROM ".DB::table('it618_exam_shop')." WHERE id=".$it618_exam_goods['it618_shopid']);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_exam_goods_type', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			if(trim($_GET['it618_saleprice'][$id])>$it618_price){
				$it618_saleprice=trim($_GET['it618_saleprice'][$id]);
			}else{
				$it618_saleprice=$it618_price;
			}
			
			$it618_score=$_GET['it618_score'][$id];
			if($_GET['it618_jfid'][$id]==0)$it618_score=0;
			
			$it618_ison=$_GET['it618_ison'][$id];
			
			$it618_xgtime=trim($_GET['it618_xgtime'][$id]);
			$it618_xgcount=trim($_GET['it618_xgcount'][$id]);
			
			$testcount=trim($_GET['it618_testcount'][$id]);
			if($testcount==0)$testcount=1;

			C::t('#it618_exam#it618_exam_goods_type')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_testcount' => $testcount,
				'it618_count' => trim($_GET['it618_count'][$id]),
				'it618_xgtime' => $it618_xgtime,
				'it618_xgcount' => $it618_xgcount,
				'it618_order' => trim($_GET['it618_order'][$id]),
				'it618_saleprice' => $it618_saleprice,
				'it618_price' => trim($_GET['it618_price'][$id]),
				'it618_jfid' => trim($_GET['it618_jfid'][$id]),
				'it618_score' => $it618_score,
				'it618_ison' => $it618_ison
			));
			
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_testcount_array = !empty($_GET['newit618_testcount']) ? $_GET['newit618_testcount'] : array();
	$newit618_count_array = !empty($_GET['newit618_count']) ? $_GET['newit618_count'] : array();
	$newit618_xgtime_array = !empty($_GET['newit618_xgtime']) ? $_GET['newit618_xgtime'] : array();
	$newit618_xgcount_array = !empty($_GET['newit618_xgcount']) ? $_GET['newit618_xgcount'] : array();
	$newit618_saleprice_array = !empty($_GET['newit618_saleprice']) ? $_GET['newit618_saleprice'] : array();
	$newit618_price_array = !empty($_GET['newit618_price']) ? $_GET['newit618_price'] : array();
	$newit618_jfid_array = !empty($_GET['newit618_jfid']) ? $_GET['newit618_jfid'] : array();
	$newit618_score_array = !empty($_GET['newit618_score']) ? $_GET['newit618_score'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			if(trim($newit618_saleprice_array[$key])>$it618_price){
				$it618_saleprice=trim($newit618_saleprice_array[$key]);
			}else{
				$it618_saleprice=$it618_price;
			}
			
			$it618_xgtime=trim($newit618_xgtime_array[$key]);
			$it618_xgcount=trim($newit618_xgcount_array[$key]);
			
			$testcount=trim($newit618_testcount_array[$key]);
			if($testcount==0)$testcount=1;
			                                        
			C::t('#it618_exam#it618_exam_goods_type')->insert(array(
				'it618_pid' => $pid,
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_testcount' => $testcount,
				'it618_count' => trim($newit618_count_array[$key]),
				'it618_xgtime' => $it618_xgtime,
				'it618_xgcount' => $it618_xgcount,
				'it618_saleprice' => $it618_saleprice,
				'it618_price' => trim($newit618_price_array[$key]),
				'it618_jfid' => trim($newit618_jfid_array[$key]),
				'it618_score' => trim($newit618_score_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}
	
	if($_GET['it618_ptypename']=='')$it618_ptypename=$it618_exam_lang['s638'];else $it618_ptypename=$_GET['it618_ptypename'];
	C::t('#it618_exam#it618_exam_goods')->update($pid,array(
		'it618_ptypename' => $it618_ptypename,
		'it618_ptypename1' => $_GET['it618_ptypename1']
	));
	
	if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($pid)>0){
		if(!$it618_exam_goods_typetmp=C::t('#it618_exam#it618_exam_goods_type')->fetch_price_by_it618_pid($pid)){
			if(!$it618_exam_goods_typetmp=C::t('#it618_exam#it618_exam_goods_type')->fetch_score_by_it618_pid($pid)){
				
			}
		}
	}
	
	C::t('#it618_exam#it618_exam_goods')->update($pid,array(
		'it618_saleprice' => $it618_exam_goods_typetmp['it618_saleprice'],
		'it618_price' => $it618_exam_goods_typetmp['it618_price'],
		'it618_jfid' => $it618_exam_goods_typetmp['it618_jfid'],
		'it618_score' => $it618_exam_goods_typetmp['it618_score']
	));

	it618_cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s34'].$ok2.' '.$it618_exam_lang['s35'].$del.')', "plugin.php?id=it618_exam:sc_product_type&pid=$pid&preurl=$preurl", 'succeed');
}

if(submitcheck('it618submitcopy')){
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods_type')." WHERE it618_pid=".intval($_GET['it618_copyid']));
	if($count==0){
		it618_cpmsg($it618_exam_lang['s1164'], "plugin.php?id=it618_exam:sc_product_type&pid=$pid&preurl=$preurl", 'error');
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods_type')." WHERE it618_pid=".$pid);
	if($count>0){
		it618_cpmsg($it618_exam_lang['s1165'], "plugin.php?id=it618_exam:sc_product_type&pid=$pid&preurl=$preurl", 'error');
	}
	
	$ok=0;
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_type')." WHERE it618_pid=".intval($_GET['it618_copyid'])." ORDER BY it618_order,it618_name");
	while($it618_exam_goods_type = DB::fetch($query)) {
		C::t('#it618_exam#it618_exam_goods_type')->insert(array(
			'it618_pid' => $pid,
			'it618_name' => $it618_exam_goods_type['it618_name'],
			'it618_testcount' => $it618_exam_goods_type['it618_testcount'],
			'it618_count' => $it618_exam_goods_type['it618_count'],
			'it618_xgtime' => $it618_exam_goods_type['it618_xgtime'],
			'it618_xgcount' => $it618_exam_goods_type['it618_xgcount'],
			'it618_saleprice' => $it618_exam_goods_type['it618_saleprice'],
			'it618_price' => $it618_exam_goods_type['it618_price'],
			'it618_jfid' => $it618_exam_goods_type['it618_jfid'],
			'it618_score' => $it618_exam_goods_type['it618_score'],
			'it618_order' => $it618_exam_goods_type['it618_order']
		), true);
		$ok=$ok+1;
	}
	
	if($ok>0){
		if($_GET['it618_ptypename']=='')$it618_ptypename=$it618_exam_lang['s638'];else $it618_ptypename=$_GET['it618_ptypename'];
		C::t('#it618_exam#it618_exam_goods')->update($pid,array(
			'it618_ptypename' => $it618_ptypename,
			'it618_ptypename1' => $_GET['it618_ptypename1']
		));
		
		if(!$it618_exam_goods_typetmp=C::t('#it618_exam#it618_exam_goods_type')->fetch_price_by_it618_pid($pid)){
			if(!$it618_exam_goods_typetmp=C::t('#it618_exam#it618_exam_goods_type')->fetch_score_by_it618_pid($pid)){
				
			}
		}
		
		C::t('#it618_exam#it618_exam_goods')->update($pid,array(
			'it618_saleprice' => $it618_exam_goods_typetmp['it618_saleprice'],
			'it618_price' => $it618_exam_goods_typetmp['it618_price'],
			'it618_jfid' => $it618_exam_goods_typetmp['it618_jfid'],
			'it618_score' => $it618_exam_goods_typetmp['it618_score']
		));
	}
	
	it618_cpmsg($it618_exam_lang['s1166'].$ok, "plugin.php?id=it618_exam:sc_product_type&pid=$pid&preurl=$preurl", 'succeed');
}

it618_showformheader("plugin.php?id=it618_exam:sc_product_type&pid=$pid");
showtableheaders($it618_exam_goods['it618_name'],'admin_shopproduct_type');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods_type')." WHERE it618_pid=".$pid);

echo '<tr><td colspan=15><span style="float:right">'.$it618_exam_lang['s1167'].'<input class="txt" type="text" name="it618_copyid" style="width:60px"><input type="submit" class="btn" name="it618submitcopy" value="'.$it618_exam_lang['s1168'].'" onclick="return confirm(\''.$it618_exam_lang['s1169'].'\')" /></span>'.$it618_exam_lang['s711'].'<input class="txt" type="text" name="it618_ptypename" style="width:100px" value="'.$it618_exam_goods['it618_ptypename'].'"> '.$it618_exam_lang['s712'].'</td></tr>';
echo '<tr><td colspan=15><font color=blue>'.$it618_exam_lang['s1354'].'</font></td></tr>';
echo '<tr><td colspan=15>'.$it618_exam_lang['s713'].$count.'<span style="float:right;color:red">'.$it618_exam_lang['s714'].'</span></td></tr>';

showsubtitle(array('', $it618_exam_lang['s715'],$it618_exam_lang['s716'],$it618_exam_lang['s717'],$it618_exam_lang['s718'], $it618_exam_lang['s719'], $it618_exam_lang['s1120'], $it618_exam_lang['s720'], $it618_exam_lang['s721'], $it618_exam_lang['s722']));

$tmpoptionstr='<option value="1">'.$it618_exam_lang['s1144'].'</option><option value="2">'.$it618_exam_lang['s1145'].'</option><option value="3">'.$it618_exam_lang['s1146'].'</option><option value="4">'.$it618_exam_lang['s1147'].'</option><option value="5">'.$it618_exam_lang['s1148'].'</option>';

$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_type')." WHERE it618_pid=".$pid." ORDER BY it618_order,it618_name");
while($it618_exam_goods_type = DB::fetch($query)) {

	$salecount = $it618_exam_goods_type['it618_salecount'];
	$disabled="";$readonly="";$bgcolor="";
	if($salecount>0){
		$disabled="disabled=\"disabled\"";
		$readonly="readonly";
		$bgcolor=";background-color:#e8e8e8";
	}
	if($it618_exam_goods_type['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
	
	if($IsPinEdu==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
		$goodspin=it618_pinedu_getgoodspinstate('exam',$it618_exam_goods_type['id']);
		$goodspinstr=' <a href="javascript:" onclick="showgoodspin('.$goodspin['id'].','.$it618_exam_goods_type['id'].')"><font color=blue>'.$goodspin['name'].'</font>'.$goodspin['count'].'</a>';
	}
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_exam_goods_type['id'].'" name="delete[]" value="'.$it618_exam_goods_type['id'].'" '.$disabled.'><label for="chk_del'.$it618_exam_goods_type['id'].'">'.$it618_exam_goods_type['id'].'</label>',
		"<input type=\"text\" class=\"txt\" style=\"width:150px$bgcolor\" name=\"it618_name[$it618_exam_goods_type[id]]\" value=\"$it618_exam_goods_type[it618_name]\" $readonly>",
		"<input type=\"text\" class=\"txt\" style=\"width:40px;margin-right:3px$bgcolor\" name=\"it618_testcount[$it618_exam_goods_type[id]]\" value=\"$it618_exam_goods_type[it618_testcount]\" $readonly>",
		"<input type=\"text\" class=\"txt\" style=\"width:60px;color:red;margin-right:3px\" name=\"it618_saleprice[$it618_exam_goods_type[id]]\" value=\"$it618_exam_goods_type[it618_saleprice]\">".it618_exam_getlang('s125')." + <input type=\"text\" class=\"txt\" style=\"width:60px;color:red;margin-right:3px\" name=\"it618_score[$it618_exam_goods_type[id]]\" value=\"$it618_exam_goods_type[it618_score]\">".'<select name="it618_jfid['.$it618_exam_goods_type['id'].']">'.it618_exam_getjftype($it618_exam_goods_type['it618_jfid']).'</select>'.$goodspinstr,
		"<input type=\"text\" class=\"txt\" style=\"width:80px\" name=\"it618_price[$it618_exam_goods_type[id]]\" value=\"$it618_exam_goods_type[it618_price]\">",
		"<input type=\"text\" class=\"txt\" style=\"width:60px\" name=\"it618_count[$it618_exam_goods_type[id]]\" value=\"$it618_exam_goods_type[it618_count]\">",
		"<input type=\"text\" class=\"txt\" style=\"width:30px;margin-right:3px\" name=\"it618_xgtime[$it618_exam_goods_type[id]]\" value=\"$it618_exam_goods_type[it618_xgtime]\">".$it618_exam_lang['s1124']." <input type=\"text\" class=\"txt\" style=\"width:30px;margin-right:3px\" name=\"it618_xgcount[$it618_exam_goods_type[id]]\" value=\"$it618_exam_goods_type[it618_xgcount]\">".$it618_exam_lang['s1129'],
		"<input type=\"text\" class=\"txt\" style=\"width:30px\" name=\"it618_order[$it618_exam_goods_type[id]]\" value=\"$it618_exam_goods_type[it618_order]\">",
		'<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_exam_goods_type['id'].']" '.$it618_ison_checked.' value="1">',
		$salecount
	));
}
	
	$s125=it618_exam_getlang('s125');
	$s1124=it618_exam_getlang('s1124');
	$s1129=it618_exam_getlang('s1129');
	$tmpjftype='<select name="newit618_jfid[]">'.it618_exam_getjftype().'</select>';
	
	if($IsPinEdu==1){
	echo '
	<script charset="utf-8" src="source/plugin/it618_exam/js/jquery.js"></script>
	<script type="text/javascript" src="source/plugin/it618_exam/js/layer/layer.js"></script>
	<script>
	function showgoodspin(pinid,typeid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_pinedu_lang['s5'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["930px", "430px"],
			content: "plugin.php?id=it618_pinedu:sc_product&shoptype=exam&pinid="+pinid+"&typeid="+typeid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	</script>
	';
	}
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:150px" name="newit618_name[]">'],
		[1,'<input type="text" class="txt" style="width:40px;margin-right:3px" name="newit618_testcount[]" value="1">'],
		[1,'<input type="text" class="txt" style="width:60px;margin-right:3px" name="newit618_saleprice[]">$s125 + <input type="text" class="txt" style="width:60px;color:red;margin-right:3px" name="newit618_score[]">$tmpjftype'],
		[1,'<input type="text" class="txt" style="width:80px" name="newit618_price[]">'],
		[1,'<input type="text" class="txt" style="width:60px" name="newit618_count[]">'],
		[1,'<input type="text" class="txt" style="width:30px;margin-right:3px" name="newit618_xgtime[]">$s1124 <input type="text" class="txt" style="width:30px;margin-right:3px" name="newit618_xgcount[]">$s1129'],
		[1,'<input type="text" class="txt" style="width:30px" name="newit618_order[]">'],
		[1,''], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_exam_lang['s831'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />".$it618_exam_lang['s1130']);
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>