<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_exam_lang;

function it618_exam_getlang($langid){
	global $it618_exam_lang;
	return $it618_exam_lang[$langid];
}

$it618_exam_lang['version']='v1.7.4';
$it618_exam_lang['s1'] = '热门类别与试卷';
$it618_exam_lang['s2'] = '电脑版底部信息';
$it618_exam_lang['s3'] = '类别名称设置';
$it618_exam_lang['s4'] = '您好，欢迎参加《{examname}》';
$it618_exam_lang['s5'] = '试卷描述：';
$it618_exam_lang['s6'] = '批量设置分数：';
$it618_exam_lang['s7'] = '注意事项：';
$it618_exam_lang['s8'] = '伪静态设置';
$it618_exam_lang['s9'] = '消息提醒设置';
$it618_exam_lang['s10'] = '购买试卷';
$it618_exam_lang['s11'] = '提现比率设置';
$it618_exam_lang['s12'] = '管理';
$it618_exam_lang['s13'] = '类别数：';
$it618_exam_lang['s14'] = '我知道了';
$it618_exam_lang['s15'] = '成为会员';
$it618_exam_lang['s16'] = '更新成功！';
$it618_exam_lang['s17'] = '点击可以查看此试卷支持哪些vip用户组免费考试同时还可以点击购买用户组 您不需要切换就自动识别VIP用户组';
$it618_exam_lang['s18'] = '返回首页';
$it618_exam_lang['s19'] = '答题过程中系统自动计时、自动保存答案，到时自动交卷；开始考试后请在计时时间内完成作答。';
$it618_exam_lang['s20'] = '答题前请关闭其他浏览器窗口，关闭可能弹窗的应用如QQ、屏保等，答题中不要切换到考试窗口之外的区域；';
$it618_exam_lang['s21'] = '如果答题过程中因电源、网络故障等造成中断，可以直接从我的成绩点击继续答题，自动从中断处继续答题；';
$it618_exam_lang['s22'] = 'Sogou、360浏览器请用极速模式，如果出现异常无法答题请换一种浏览器；';
$it618_exam_lang['s23'] = '更新';
$it618_exam_lang['s24'] = '答卷结构';
$it618_exam_lang['s25'] = '查找';
$it618_exam_lang['s26'] = '即将作答：';
$it618_exam_lang['s27'] = '收费考生';
$it618_exam_lang['s28'] = '注册会员';
$it618_exam_lang['s29'] = '文字颜色(无突出效果时要为空)';
$it618_exam_lang['s30'] = '所有访客';
$it618_exam_lang['s31'] = '老师：';
$it618_exam_lang['s32'] = '老师数';
$it618_exam_lang['s33'] = '更新成功！(成功修改数:';
$it618_exam_lang['s34'] = '成功添加数:';
$it618_exam_lang['s35'] = '成功删除数:';
$it618_exam_lang['s36'] = '您好，考试部分正在开发中。。。敬请期待！';
$it618_exam_lang['s37'] = '道题';
$it618_exam_lang['s38'] = '警告：以下内容有的需要结合编辑器的代码模式(<font color=blue>代码模式/内容模式 通过编辑器的第一个功能图标切换</font>)修改，如果你对代码不了解修改前请一定对内容进行备份！';
$it618_exam_lang['s39'] = '非VIP';
$it618_exam_lang['s40'] = '是VIP';
$it618_exam_lang['s41'] = '知道了，开始答题';
$it618_exam_lang['s42'] = '按类别名称';
$it618_exam_lang['s43'] = '试卷类别数：';
$it618_exam_lang['s44'] = '提示：试卷评价评分名称有4个，每个评分名称用_下划线隔开，<font color=blue>首页推荐试卷行数为0时就是不显示，不同模板风格每行显示试卷数不同的</font>';
$it618_exam_lang['s45'] = '类别名称';
$it618_exam_lang['s46'] = '下载';
$it618_exam_lang['s47'] = '试卷评价评分名称(<font color=red>第一个评分名称很重要</font>)';
$it618_exam_lang['s48'] = '主题颜色';
$it618_exam_lang['s49'] = '电脑版/手机版首推试卷行数';
$it618_exam_lang['s50'] = '排序';
$it618_exam_lang['s51'] = '在';
$it618_exam_lang['s52'] = '提示：1级{qname1}必须设置，也就是说最少要1级，如果不这样，在题库管理选择{qname1}时是没有内容的';
$it618_exam_lang['s53'] = '子类别数';
$it618_exam_lang['s54'] = '试卷数';
$it618_exam_lang['s55'] = '展开选项';
$it618_exam_lang['s56'] = '编号';
$it618_exam_lang['s57'] = '父类别';
$it618_exam_lang['s58'] = '类别名称';
$it618_exam_lang['s59'] = '收缩选项';
$it618_exam_lang['s60'] = '宽:';
$it618_exam_lang['s61'] = '高:';
$it618_exam_lang['s62'] = '轮播广告数：';
$it618_exam_lang['s63'] = '注意：排序值为0时表示图片不显示，数值越小越在前';
$it618_exam_lang['s64'] = '图片';
$it618_exam_lang['s65'] = '图片链接(为空时图片不带链接)';
$it618_exam_lang['s66'] = '排序';
$it618_exam_lang['s67'] = '上传图片';
$it618_exam_lang['s68'] = '提交后再上传图片';
$it618_exam_lang['s69'] = '注意：以下分类与试卷编号，多个时请用逗号隔开(如：1,2,3,4,5)，并且设置顺序就是显示顺序';
$it618_exam_lang['s70'] = '首页热门试卷分类编号：';
$it618_exam_lang['s71'] = '搜索页热门分类编号：';
$it618_exam_lang['s72'] = '首页热门试卷编号：';
$it618_exam_lang['s73'] = '我的试卷';
$it618_exam_lang['s74'] = '启用消息提醒功能：';
$it618_exam_lang['s75'] = '在<font color=green>申请老师、交易成功与申请提现</font>时会有短信提醒';
$it618_exam_lang['s76'] = '手机号码：';
$it618_exam_lang['s77'] = '有提醒时此手机号就会收到短信';
$it618_exam_lang['s78'] = '取消选中试卷VIP';
$it618_exam_lang['s79'] = '设置选中试卷VIP';
$it618_exam_lang['s80'] = '更新时发送一个测试短信';
$it618_exam_lang['s81'] = '确定要取消选中试卷VIP？这样VIP会员如果不购买此试卷，就不能考试了！';
$it618_exam_lang['s82'] = '启用消息提醒功能：';
$it618_exam_lang['s83'] = '确定要设置选中试卷VIP？这样VIP会员不购买此试卷，也是可以考试的，同时也会影响老师的收入，请先与此试卷老师联系！';
$it618_exam_lang['s84'] = '短信接口账号：';
$it618_exam_lang['s85'] = '短信接口密码：';
$it618_exam_lang['s86'] = '测试接收人手机号：';
$it618_exam_lang['s87'] = '多个手机号用英文字母逗号隔开';
$it618_exam_lang['s88'] = '测试短信内容：';
$it618_exam_lang['s89'] = '提示：可以利用发送测试短信功能，手工给多个手机发送短信';
$it618_exam_lang['s90'] = '成功修改试卷数：';
$it618_exam_lang['s91'] = '已被管理员锁定';
$it618_exam_lang['s92'] = '成功锁定试卷数：';
$it618_exam_lang['s93'] = '已被管理员解锁';
$it618_exam_lang['s94'] = '成功解锁试卷数：';
$it618_exam_lang['s95'] = '所有分类';
$it618_exam_lang['s96'] = '练习试卷';
$it618_exam_lang['s97'] = '按关键词';
$it618_exam_lang['s98'] = '价格';
$it618_exam_lang['s99'] = '试卷分类';
$it618_exam_lang['s100'] = '所有分类';
$it618_exam_lang['s101'] = '状态';
$it618_exam_lang['s102'] = '所有';
$it618_exam_lang['s103'] = '下架';
$it618_exam_lang['s104'] = '上架';
$it618_exam_lang['s105'] = '锁定';
$it618_exam_lang['s106'] = '免费';
$it618_exam_lang['s107'] = '成功设置VIP试卷数：';
$it618_exam_lang['s108'] = '课时';
$it618_exam_lang['s109'] = '成功取消VIP试卷数：';
$it618_exam_lang['s110'] = '按排序值排序';
$it618_exam_lang['s111'] = '按销量排序';
$it618_exam_lang['s112'] = '按人气值排序';
$it618_exam_lang['s113'] = '按价格排序';
$it618_exam_lang['s114'] = '试卷数：';
$it618_exam_lang['s115'] = '试卷名称/简洁描述';
$it618_exam_lang['s116'] = '试卷价格/试卷题目';
$it618_exam_lang['s117'] = '答案';
$it618_exam_lang['s118'] = '人气';
$it618_exam_lang['s119'] = '交易数';
$it618_exam_lang['s120'] = '销售额';
$it618_exam_lang['s121'] = '交卷后自动加入错题到我的错题库';
$it618_exam_lang['s122'] = '状态';
$it618_exam_lang['s123'] = '排序';
$it618_exam_lang['s124'] = '老师：';
$it618_exam_lang['s125'] = '元';
$it618_exam_lang['s126'] = '人气';
$it618_exam_lang['s127'] = '粉丝';
$it618_exam_lang['s128'] = '个目录';
$it618_exam_lang['s129'] = '全选';
$it618_exam_lang['s130'] = '修改以上排序';
$it618_exam_lang['s131'] = '锁定选中试卷';
$it618_exam_lang['s132'] = '确定要锁定选中试卷？';
$it618_exam_lang['s133'] = '解锁选中试卷';
$it618_exam_lang['s134'] = '确定要解锁选中试卷？';
$it618_exam_lang['s135'] = '<font color=#999>注意：试卷在锁定(如果试卷违规管理员有权锁定)状态下不能进行上下架操作，试卷被锁定后，可以与管理员联系申请解锁，解锁后试卷默认是下架状态<br><img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;"> 如果试卷给管理员设置成VIP试卷，那么VIP会员是可以免费考试的，管理员设置VIP试卷都会与老师联系的<br><img src="source/plugin/it618_exam/images/secret.png" style="vertical-align:middle;height:18px;"> 如果试卷给管理员设置成保密试卷，那么只有管理员、老师自己与指定会员（点试卷编辑可以设置会员）可以看到试卷，哪个试卷需要保密，请找管理员申请设置</font>';
$it618_exam_lang['s136'] = 'URL 静态化可以提高搜索引擎抓取，开启本功能需要对 Web 服务器增加相应的 Rewrite 支持，且会轻微增加服务器负担。同时您还可以调整每个页面的静态格式，但不得删除其中的标记，重置静态格式请留空。<br><font color=red>注意，修改静态格式后您需要修改服务器的 Rewrite 规则设置，并且要把DZ默认的插件规则删除或放最后一行，此插件规则才有效果</font>';
$it618_exam_lang['s137'] = '静态格式扩展名：';
$it618_exam_lang['s138'] = '页面';
$it618_exam_lang['s139'] = '标记';
$it618_exam_lang['s140'] = '格式';
$it618_exam_lang['s141'] = '首页';
$it618_exam_lang['s142'] = '试卷列表页';
$it618_exam_lang['s143'] = '试卷查找页';
$it618_exam_lang['s144'] = '试卷页';
$it618_exam_lang['s145'] = '试卷考试页';
$it618_exam_lang['s146'] = '老师管理页';
$it618_exam_lang['s147'] = '手机版页';
$it618_exam_lang['s148'] = 'Apache Web Server(独立主机用户)';
$it618_exam_lang['s149'] = 'Apache Web Server(虚拟主机用户)';
$it618_exam_lang['s150'] = '# 将 RewriteEngine 模式打开
RewriteEngine On

# 修改以下语句中的 /discuz 为您的论坛目录地址，如果程序放在根目录中，请将 /discuz 修改为 /
RewriteBase /discuz

# Rewrite 系统规则请勿修改';
$it618_exam_lang['s151'] = 'IIS Web Server(独立主机用户)';
$it618_exam_lang['s152'] = 'IIS7 Web Server(独立主机用户)';
$it618_exam_lang['s153'] = '成功删除老师数：';
$it618_exam_lang['s154'] = '老师审核通过数：';
$it618_exam_lang['s155'] = '成功修改老师数：';
$it618_exam_lang['s156'] = '抱歉，要转让的会员不存在！';
$it618_exam_lang['s157'] = '抱歉，要转让的会员已经是老师了，一个老师只能对应一个会员！';
$it618_exam_lang['s158'] = '已成功把';
$it618_exam_lang['s159'] = '转让给会员';
$it618_exam_lang['s160'] = '老师审核不通过数：';
$it618_exam_lang['s161'] = '抱歉，截止时间要大于现在时间！';
$it618_exam_lang['s162'] = '成功修改老师签约截止时间数：';
$it618_exam_lang['s163'] = '成功锁定老师数：';
$it618_exam_lang['s164'] = '成功解锁老师数：';
$it618_exam_lang['s165'] = '老师管理';
$it618_exam_lang['s166'] = '按老师名称';
$it618_exam_lang['s167'] = '老师会员ID';
$it618_exam_lang['s168'] = '共{qcount}题{score}分 考时{time}分钟';
$it618_exam_lang['s169'] = '所有状态';
$it618_exam_lang['s170'] = '审核状态';
$it618_exam_lang['s171'] = '待审核';
$it618_exam_lang['s172'] = '审核未通过';
$it618_exam_lang['s173'] = '审核已通过';
$it618_exam_lang['s174'] = '签约状态';
$it618_exam_lang['s175'] = '锁定';
$it618_exam_lang['s176'] = '有效';
$it618_exam_lang['s177'] = '过期';
$it618_exam_lang['s178'] = '老师数：';
$it618_exam_lang['s179'] = '老师信息';
$it618_exam_lang['s180'] = '试卷数';
$it618_exam_lang['s181'] = '交易数';
$it618_exam_lang['s182'] = '交易金额';
$it618_exam_lang['s183'] = '提成比率';
$it618_exam_lang['s184'] = '提成金额';
$it618_exam_lang['s185'] = '老师提现';
$it618_exam_lang['s186'] = '查看资料';
$it618_exam_lang['s187'] = '审核状态：';
$it618_exam_lang['s188'] = '会员：';
$it618_exam_lang['s189'] = '签约截止时间：';
$it618_exam_lang['s190'] = '签约状态：';
$it618_exam_lang['s191'] = '考时：';
$it618_exam_lang['s192'] = '分钟';
$it618_exam_lang['s193'] = '({qcount}题 {score}分)';
$it618_exam_lang['s194'] = '欢迎您，';
$it618_exam_lang['s195'] = '我的试卷';
$it618_exam_lang['s196'] = '可提金额';
$it618_exam_lang['s197'] = '正在申请金额';
$it618_exam_lang['s198'] = '已实提金额';
$it618_exam_lang['s199'] = '提现服务费';
$it618_exam_lang['s200'] = '<strong>老师名称：</strong>{name}<br><strong>联系电话：</strong>{tel}<br><strong>QQ号码：</strong>{qq}<br><strong>老师简介：</strong>{about}<br><strong>申请时间：</strong>{time}<br>';
$it618_exam_lang['s201'] = '删除选中老师';
$it618_exam_lang['s202'] = '此操作不可逆，确定要删除选中老师吗？';
$it618_exam_lang['s203'] = '修改以上老师';
$it618_exam_lang['s204'] = '审核通过选中老师';
$it618_exam_lang['s205'] = '此操作不可逆，确定要审核通过选中老师吗？';
$it618_exam_lang['s206'] = '审核不通过选中老师';
$it618_exam_lang['s207'] = '此操作不可逆，确定要审核不通过选中老师吗？';
$it618_exam_lang['s208'] = '注意：三个操作对应的状态，删除(<font color=red>待审核</font>、<font color=red>审核未通过</font>)，审核通过(<font color=red>待审核</font>)，审核不通过(<font color=red>待审核</font>)<br>注意：老师审核通过后才可以进行后面这些操作';
$it618_exam_lang['s209'] = '修改选中老师签约截止时间';
$it618_exam_lang['s210'] = '确定要修改选中老师签约截止时间？';
$it618_exam_lang['s211'] = '锁定选中老师';
$it618_exam_lang['s212'] = '确定要锁定选中老师？';
$it618_exam_lang['s213'] = '解锁选中老师';
$it618_exam_lang['s214'] = '确定要解锁选中老师？';
$it618_exam_lang['s215'] = '锁定后所有与锁定老师相关的功能都会无效';
$it618_exam_lang['s216'] = '请选择一个老师，输入要转让给的会员ID';
$it618_exam_lang['s217'] = '店铺转让给此会员';
$it618_exam_lang['s218'] = '请选择一个老师！';
$it618_exam_lang['s219'] = '只能选择一个老师！';
$it618_exam_lang['s220'] = '请输入会员ID！';
$it618_exam_lang['s221'] = '确定要把选中的老师转让给此会员？';
$it618_exam_lang['s222'] = '确定要选择钱包余额转账方式？操作后不能取消的！';
$it618_exam_lang['s223'] = '老师申请{money}元提现，实提{money1}元，单号:{saleid}';
$it618_exam_lang['s224'] = '按关键词';
$it618_exam_lang['s225'] = '交易会员ID';
$it618_exam_lang['s226'] = '状态';
$it618_exam_lang['s227'] = '所有可退状态';
$it618_exam_lang['s228'] = '交易时间';
$it618_exam_lang['s229'] = '交易数：';
$it618_exam_lang['s230'] = '交易金额：';
$it618_exam_lang['s231'] = '题数';
$it618_exam_lang['s232'] = '试卷考试说明页';
$it618_exam_lang['s233'] = '试卷名称';
$it618_exam_lang['s234'] = '得分/满分';
$it618_exam_lang['s235'] = '未作答';
$it618_exam_lang['s236'] = '金额';
$it618_exam_lang['s237'] = '已作答';
$it618_exam_lang['s238'] = '紫色分数表示部分对时得分';
$it618_exam_lang['s239'] = '状态';
$it618_exam_lang['s240'] = '交易会员';
$it618_exam_lang['s241'] = '交易时间';
$it618_exam_lang['s242'] = '，部分对';
$it618_exam_lang['s243'] = '天';
$it618_exam_lang['s244'] = '比率：';
$it618_exam_lang['s245'] = '金额：';
$it618_exam_lang['s246'] = '钱包余额转账';
$it618_exam_lang['s247'] = '微信转账';
$it618_exam_lang['s248'] = '请先设置财务信息';
$it618_exam_lang['s249'] = '成功删除数：';
$it618_exam_lang['s250'] = '申请的';
$it618_exam_lang['s251'] = '元提现已成功转账 ';
$it618_exam_lang['s252'] = '成功已支付数：';
$it618_exam_lang['s253'] = '提现管理';
$it618_exam_lang['s254'] = '按转账方式';
$it618_exam_lang['s255'] = '所有转账方式';
$it618_exam_lang['s256'] = '银行卡转账';
$it618_exam_lang['s257'] = '支付宝转账';
$it618_exam_lang['s258'] = '申请时间';
$it618_exam_lang['s259'] = '转账状态';
$it618_exam_lang['s260'] = '所有状态';
$it618_exam_lang['s261'] = '等待转账';
$it618_exam_lang['s262'] = '已转账';
$it618_exam_lang['s263'] = '提现数：';
$it618_exam_lang['s264'] = '提现金额：';
$it618_exam_lang['s265'] = '申请提现金额';
$it618_exam_lang['s266'] = '服务费比率';
$it618_exam_lang['s267'] = '服务费';
$it618_exam_lang['s268'] = '实提金额';
$it618_exam_lang['s269'] = '提现备注';
$it618_exam_lang['s270'] = '申请时间';
$it618_exam_lang['s271'] = '提现老师';
$it618_exam_lang['s272'] = '转账方式';
$it618_exam_lang['s273'] = '转账状态';
$it618_exam_lang['s274'] = '收款人：';
$it618_exam_lang['s275'] = ' 收款银行：';
$it618_exam_lang['s276'] = '银行账号：';
$it618_exam_lang['s277'] = ' 开户地：';
$it618_exam_lang['s278'] = ' 支付宝账号：';
$it618_exam_lang['s279'] = '删除选中提现申请';
$it618_exam_lang['s280'] = '确定要删除选中的提现申请？';
$it618_exam_lang['s281'] = '设置选中已转账';
$it618_exam_lang['s282'] = '确定设置选中已转账？此操作不可逆';
$it618_exam_lang['s283'] = '等待转账状态可以删除，申请金额还原';
$it618_exam_lang['s284'] = '比率数：';
$it618_exam_lang['s285'] = '提现金额区间下限';
$it618_exam_lang['s286'] = '提现金额区间上限';
$it618_exam_lang['s287'] = '此区间服务费比率';
$it618_exam_lang['s288'] = '老师资料';
$it618_exam_lang['s289'] = '关闭';
$it618_exam_lang['s290'] = '保存成功！';
$it618_exam_lang['s291'] = '财务信息';
$it618_exam_lang['s292'] = '请输入支付宝姓名！';
$it618_exam_lang['s293'] = '请输入支付宝账号！';
$it618_exam_lang['s294'] = '回复';
$it618_exam_lang['s295'] = '回复评价';
$it618_exam_lang['s296'] = '如果要输入，银行转账信息必须都输入！';
$it618_exam_lang['s297'] = '请准确填写以下信息(如果转账服务没开通就不需要设置了)，<font color=red>如果有待转账的提现申请，请不要修改财务信息</font>，否则将影响您获得收入。';
$it618_exam_lang['s298'] = '银行转账信息';
$it618_exam_lang['s299'] = '收款人姓名：';
$it618_exam_lang['s300'] = '收款银行：';
$it618_exam_lang['s301'] = '如：中国工商银行 武汉分行';
$it618_exam_lang['s302'] = '银行账号：';
$it618_exam_lang['s303'] = '开户地：';
$it618_exam_lang['s304'] = '如：湖北省 武汉市';
$it618_exam_lang['s305'] = '支付宝转账信息';
$it618_exam_lang['s306'] = '支付宝姓名：';
$it618_exam_lang['s307'] = '支付宝账号：';
$it618_exam_lang['s308'] = '保存';
$it618_exam_lang['s309'] = '基本信息更新成功！';
$it618_exam_lang['s310'] = '基本信息';
$it618_exam_lang['s311'] = '请输入老师名称！';
$it618_exam_lang['s312'] = '请输入联系电话！';
$it618_exam_lang['s313'] = '请输入老师QQ！';
$it618_exam_lang['s314'] = '请输入老师简介！';
$it618_exam_lang['s315'] = '收费';
$it618_exam_lang['s316'] = '公开';
$it618_exam_lang['s317'] = '老师照片：';
$it618_exam_lang['s318'] = '上传图片';
$it618_exam_lang['s319'] = ' 微信账号：';
$it618_exam_lang['s320'] = '老师名称：';
$it618_exam_lang['s321'] = '必填';
$it618_exam_lang['s322'] = '联系电话：';
$it618_exam_lang['s323'] = '不公开';
$it618_exam_lang['s324'] = 'QQ：';
$it618_exam_lang['s325'] = '注意：红色标记内容只对管理员显示，便于管理联系您';
$it618_exam_lang['s326'] = '个试卷';
$it618_exam_lang['s327'] = '老师电话：';
$it618_exam_lang['s328'] = '客服QQ：';
$it618_exam_lang['s329'] = '工作时间：';
$it618_exam_lang['s330'] = '试卷内容';
$it618_exam_lang['s331'] = '老师简介：';
$it618_exam_lang['s332'] = '注意字数不要太多';
$it618_exam_lang['s333'] = '抱歉，您尚未登录！';
$it618_exam_lang['s334'] = '抱歉，您已提交了认证老师申请资料，资料审核中，请等待！';
$it618_exam_lang['s335'] = '抱歉，您已提交了认证老师申请资料，审核未通过，可以尝试再提交申请！';
$it618_exam_lang['s336'] = '抱歉，您的老师帐号当前是锁定状态，请与管理员联系！';
$it618_exam_lang['s337'] = '抱歉，您的老师帐号当前是过期状态，请与管理员联系！';
$it618_exam_lang['s338'] = '抱歉，您不是老师，请先申请认证老师！';
$it618_exam_lang['s339'] = '消息提醒设置更新成功！';
$it618_exam_lang['s340'] = '！';
$it618_exam_lang['s341'] = '在<font color=green>交易成功、提现成功、试卷锁定与试卷解锁</font>时会有短信提醒';
$it618_exam_lang['s342'] = '成功删除数：';
$it618_exam_lang['s343'] = '成功上架试卷数：';
$it618_exam_lang['s344'] = '成功下架试卷数：';
$it618_exam_lang['s345'] = '成功更新数：';
$it618_exam_lang['s346'] = '所有分类';
$it618_exam_lang['s347'] = '钱包余额';
$it618_exam_lang['s348'] = '微信';
$it618_exam_lang['s349'] = '试卷管理';
$it618_exam_lang['s350'] = '查找';
$it618_exam_lang['s351'] = '编辑';
$it618_exam_lang['s352'] = '删除选中试卷';
$it618_exam_lang['s353'] = '确定要删除选中试卷？此操作不可逆。';
$it618_exam_lang['s354'] = '修改以上试卷';
$it618_exam_lang['s355'] = '上架选中试卷';
$it618_exam_lang['s356'] = '确定要上架选中试卷？\n试卷上架条件：\n1、试卷内有题目，并且设置了分数\n2、试卷要设置考试时间';
$it618_exam_lang['s357'] = '下架选中试卷';
$it618_exam_lang['s358'] = '确定要下架选中试卷？';
$it618_exam_lang['s359'] = '试卷添加成功！';
$it618_exam_lang['s360'] = '添加试卷';
$it618_exam_lang['s361'] = '抱歉，请选择试卷分类！';
$it618_exam_lang['s362'] = '抱歉，请输入老师名称！';
$it618_exam_lang['s363'] = '编辑内容详情';
$it618_exam_lang['s364'] = '无';
$it618_exam_lang['s365'] = '提示：可以现金+积分购买，也可以单独设置现金或积分一种价格，设置为0时表示不支持此支付方式，都不设置表示试卷免费';
$it618_exam_lang['s366'] = '抱歉，最少要设置现金或积分一种价格！';
$it618_exam_lang['s367'] = '抱歉，请先选择{qname}！';
$it618_exam_lang['s368'] = '抱歉，请先选择题型！';
$it618_exam_lang['s369'] = '随机数';
$it618_exam_lang['s370'] = '';
$it618_exam_lang['s371'] = '题';
$it618_exam_lang['s372'] = '请上传试卷图片！';
$it618_exam_lang['s373'] = '提示：提交后再设置内容的详情、资料与音频';
$it618_exam_lang['s374'] = '试卷分类：';
$it618_exam_lang['s375'] = '请选择';
$it618_exam_lang['s376'] = '';
$it618_exam_lang['s377'] = '老师名称：';
$it618_exam_lang['s378'] = '试卷价格：';
$it618_exam_lang['s379'] = '试卷原价：';
$it618_exam_lang['s380'] = '试卷计时';
$it618_exam_lang['s381'] = '答题卡';
$it618_exam_lang['s382'] = '请在此输入';
$it618_exam_lang['s383'] = '答案:';
$it618_exam_lang['s384'] = '解析:';
$it618_exam_lang['s385'] = '排序';
$it618_exam_lang['s386'] = '提示答案';
$it618_exam_lang['s387'] = '不提示答案';
$it618_exam_lang['s388'] = 'T,TRUE,√,对,正确';
$it618_exam_lang['s389'] = '自测计时';
$it618_exam_lang['s390'] = '+';
$it618_exam_lang['s391'] = '-';
$it618_exam_lang['s392'] = '加入老师团队';
$it618_exam_lang['s393'] = '大咖老师';
$it618_exam_lang['s394'] = '试卷图片：';
$it618_exam_lang['s395'] = '选择图片';
$it618_exam_lang['s396'] = '删除图片';
$it618_exam_lang['s397'] = '时';
$it618_exam_lang['s398'] = '分';
$it618_exam_lang['s399'] = '共';
$it618_exam_lang['s400'] = '秒';
$it618_exam_lang['s401'] = '不检错';
$it618_exam_lang['s402'] = '考试页右上自定广告';
$it618_exam_lang['s403'] = '考试页左下自定广告';
$it618_exam_lang['s404'] = '详细内容：';
$it618_exam_lang['s405'] = 'SEO关键词：';
$it618_exam_lang['s406'] = 'SEO描述：';
$it618_exam_lang['s407'] = '保存';
$it618_exam_lang['s408'] = '试卷编辑成功！';
$it618_exam_lang['s409'] = '编辑试卷';
$it618_exam_lang['s410'] = '正在考试';
$it618_exam_lang['s411'] = '关闭';
$it618_exam_lang['s412'] = '缺选项';
$it618_exam_lang['s413'] = '交易管理';
$it618_exam_lang['s414'] = '所有状态';
$it618_exam_lang['s415'] = '提成金额：';
$it618_exam_lang['s416'] = '提示：交易成功后，会自动的累加您的可提现金额';
$it618_exam_lang['s417'] = '数量为0时表示不显示老师展示功能';
$it618_exam_lang['s418'] = '状态';
$it618_exam_lang['s419'] = '提成';
$it618_exam_lang['s420'] = '可提现：';
$it618_exam_lang['s421'] = '元 正在申请：';
$it618_exam_lang['s422'] = '元 已转账：';
$it618_exam_lang['s423'] = '申请提现';
$it618_exam_lang['s424'] = '支付宝转账';
$it618_exam_lang['s425'] = '抱歉，管理员还没有设置提现服务费(提成比率)，不能提现，请与管理员联系！';
$it618_exam_lang['s426'] = '转账方式：';
$it618_exam_lang['s427'] = '银行卡转账';
$it618_exam_lang['s428'] = '提现金额：';
$it618_exam_lang['s429'] = '申请提现';
$it618_exam_lang['s430'] = '可提现金额：';
$it618_exam_lang['s431'] = '提现备注：';
$it618_exam_lang['s432'] = '提现服务费比率(提现金额区间下限 - 提现金额区间上限)：';
$it618_exam_lang['s433'] = '提现记录';
$it618_exam_lang['s434'] = '请输入提现金额！';
$it618_exam_lang['s435'] = '确定要取消此提现申请？';
$it618_exam_lang['s436'] = '购买了';
$it618_exam_lang['s437'] = '个';
$it618_exam_lang['s438'] = '元的';
$it618_exam_lang['s439'] = '收入';
$it618_exam_lang['s440'] = '支付宝单号';
$it618_exam_lang['s441'] = '金额';
$it618_exam_lang['s442'] = '资料管理';
$it618_exam_lang['s443'] = '个';
$it618_exam_lang['s444'] = '您购买了';
$it618_exam_lang['s445'] = '自测设置页';
$it618_exam_lang['s446'] = '自测答题页';
$it618_exam_lang['s447'] = '我的自测设置';
$it618_exam_lang['s448'] = '我的自测';
$it618_exam_lang['s449'] = '天前';
$it618_exam_lang['s450'] = '小时前';
$it618_exam_lang['s451'] = '分钟前';
$it618_exam_lang['s452'] = '秒前';
$it618_exam_lang['s453'] = '老师审核进度';
$it618_exam_lang['s454'] = '老师后台';
$it618_exam_lang['s455'] = '申请认证老师';
$it618_exam_lang['s456'] = '我的';
$it618_exam_lang['s457'] = '我的交易';
$it618_exam_lang['s458'] = '我的成绩';
$it618_exam_lang['s459'] = '试卷评价';
$it618_exam_lang['s460'] = '退出';
$it618_exam_lang['s461'] = '登录';
$it618_exam_lang['s462'] = '注册';
$it618_exam_lang['s463'] = '您购买的';
$it618_exam_lang['s464'] = '内容详情';
$it618_exam_lang['s465'] = '人购买';
$it618_exam_lang['s466'] = '全部';
$it618_exam_lang['s467'] = '查看更多';
$it618_exam_lang['s468'] = '元以下';
$it618_exam_lang['s469'] = '元以上';
$it618_exam_lang['s470'] = '抱歉，您访问的试卷不存在！';
$it618_exam_lang['s471'] = '申请提醒成功并转账到钱包余额，可到钱包余额账单查看！';
$it618_exam_lang['s472'] = '修改认证老师申请资料';
$it618_exam_lang['s473'] = '资料审核中...';
$it618_exam_lang['s474'] = '审核未通过，可以尝试再提交申请';
$it618_exam_lang['s475'] = '您在';
$it618_exam_lang['s476'] = '提交了老师申请资料<br>审核状态：';
$it618_exam_lang['s477'] = '认证老师申请资料';
$it618_exam_lang['s478'] = '您已经是认证老师了，请进老师后台管理系统！';
$it618_exam_lang['s479'] = '点击进入后台管理系统';
$it618_exam_lang['s480'] = '提交认证老师申请资料';
$it618_exam_lang['s481'] = '您还没有提交过认证老师申请资料！<br>请仔细填写资料，提交后不可修改，审核未通过可再提交';
$it618_exam_lang['s482'] = '评价';
$it618_exam_lang['s483'] = '分 ';
$it618_exam_lang['s484'] = '暂无评价';
$it618_exam_lang['s485'] = '抱歉，请先登录！';
$it618_exam_lang['s486'] = '抱歉，如果要设置微信转账信息，请设置完整！';
$it618_exam_lang['s487'] = '抱歉，此试卷不存在！';
$it618_exam_lang['s488'] = '一、|二、|三、|四、|五、|六、|七、|八、|九、|十、|十一、|十二、|十三、|十四、|十五、|十六、|十七、|十八、|十九、';
$it618_exam_lang['s489'] = '题目答案：';
$it618_exam_lang['s490'] = '正确';
$it618_exam_lang['s491'] = '错误';
$it618_exam_lang['s492'] = '显示聊天';
$it618_exam_lang['s493'] = '隐藏聊天';
$it618_exam_lang['s494'] = '显示我的笔记';
$it618_exam_lang['s495'] = '购买了';
$it618_exam_lang['s496'] = '个价格为';
$it618_exam_lang['s497'] = '的';
$it618_exam_lang['s498'] = '抱歉，交易失败，请与管理员联系！';
$it618_exam_lang['s499'] = '隐藏我的笔记';
$it618_exam_lang['s500'] = '我要评价';
$it618_exam_lang['s501'] = '分';
$it618_exam_lang['s502'] = '评价:';
$it618_exam_lang['s503'] = '排序';
$it618_exam_lang['s504'] = '测试题目生成完成后自动跳转，生成中请稍等';
$it618_exam_lang['s505'] = '金额:';
$it618_exam_lang['s506'] = '电脑版首页显示老师数';
$it618_exam_lang['s507'] = '手机版首页显示老师数';
$it618_exam_lang['s508'] = '状态:';
$it618_exam_lang['s509'] = '提成金额：';
$it618_exam_lang['s510'] = '上一页';
$it618_exam_lang['s511'] = '下一页';
$it618_exam_lang['s512'] = '保存成功！';
$it618_exam_lang['s513'] = '抱歉，参数有误！';
$it618_exam_lang['s514'] = '《';
$it618_exam_lang['s515'] = '》';
$it618_exam_lang['s516'] = '评价成功！';
$it618_exam_lang['s517'] = '全部试卷';
$it618_exam_lang['s518'] = '按关键词：';
$it618_exam_lang['sn'] = '';
$it618_exam_lang['s519'] = '搜 索';
$it618_exam_lang['s520'] = '折';
$it618_exam_lang['s521'] = '返回内容管理';
$it618_exam_lang['s522'] = '抱歉，您所在用户组没有申请老师认证权限！';
$it618_exam_lang['s523'] = '申请了老师认证 老师名称';
$it618_exam_lang['s524'] = '抱歉，请先申请认证老师！';
$it618_exam_lang['s525'] = '提示答案';
$it618_exam_lang['s526'] = '交卷';
$it618_exam_lang['s527'] = '交卷后不能再答题了，确定要交卷？';
$it618_exam_lang['s528'] = '参考答案：';
$it618_exam_lang['s529'] = '正确';
$it618_exam_lang['s530'] = '错误';
$it618_exam_lang['s531'] = '试卷正在生成中，请稍等';
$it618_exam_lang['s532'] = '试卷已生成好，等待答题';
$it618_exam_lang['s533'] = '得';
$it618_exam_lang['s534'] = '未考完';
$it618_exam_lang['s535'] = '剩余';
$it618_exam_lang['s536'] = '已考完';
$it618_exam_lang['s537'] = '得分';
$it618_exam_lang['s538'] = '考生成绩';
$it618_exam_lang['s539'] = '确定要考试？如果是新考试，点确定您的考试次数会减少一次，如果此试卷未考完，点确定可以继续接着上次考试！';
$it618_exam_lang['s540'] = '抱歉，您的提现金额不在提现服务费比率区间内！';
$it618_exam_lang['s541'] = '银行卡';
$it618_exam_lang['s542'] = '抱歉，您的提现金额不能大于可提现金额！';
$it618_exam_lang['s543'] = '申请了';
$it618_exam_lang['s544'] = '元提现 老师名称';
$it618_exam_lang['s545'] = '申请成功，请等待管理员转账！';
$it618_exam_lang['s546'] = '人气:';
$it618_exam_lang['s547'] = '人购买';
$it618_exam_lang['s548'] = '试卷数:';
$it618_exam_lang['s549'] = '交易时间：';
$it618_exam_lang['s550'] = '支付宝';
$it618_exam_lang['s551'] = '取消';
$it618_exam_lang['s552'] = '';
$it618_exam_lang['s553'] = '综合评分_描述相符_讲解表达_答疑服务';
$it618_exam_lang['s554'] = '继续答题';
$it618_exam_lang['s555'] = '查看试卷';
$it618_exam_lang['s556'] = '删?';
$it618_exam_lang['s557'] = '提交 + 编辑当前题目';
$it618_exam_lang['s558'] = '提交 + 继续添加题目';
$it618_exam_lang['s559'] = '热门编号设置';
$it618_exam_lang['s560'] = '字符';
$it618_exam_lang['s561'] = '积分价格类型';
$it618_exam_lang['s562'] = '老师管理';
$it618_exam_lang['s563'] = '提交 + 关闭当前窗口';
$it618_exam_lang['s564'] = '抱歉，请输入题目名称！';
$it618_exam_lang['s565'] = '抱歉，请设置答案选项！';
$it618_exam_lang['s566'] = '取消加入';
$it618_exam_lang['s567'] = '简洁描述：';
$it618_exam_lang['s568'] = '简洁描述';
$it618_exam_lang['s569'] = '交易数';
$it618_exam_lang['s570'] = '状态';
$it618_exam_lang['s571'] = '排序';
$it618_exam_lang['s572'] = '修改以上试卷';
$it618_exam_lang['s573'] = '，';
$it618_exam_lang['s574'] = '请输入试卷名称！';
$it618_exam_lang['s575'] = '试卷老师：';
$it618_exam_lang['s576'] = '请选择老师';
$it618_exam_lang['s577'] = '试卷名称：';
$it618_exam_lang['s578'] = '批量导入题目';
$it618_exam_lang['s579'] = '注意：不同题型的导入规则与格式不同，题目内容检测已存在的不添加';
$it618_exam_lang['s580'] = '本地文件';
$it618_exam_lang['s581'] = '按老师名称';
$it618_exam_lang['s582'] = '老师数：';
$it618_exam_lang['s583'] = '添加方式一：直接把题目复制到下面文本框内，格式看右侧说明 <a href="https://www.cnit618.com/thread-2673-1-1.html" target="_blank">如导入有带图片题目的word 点击可看</a>';
$it618_exam_lang['s584'] = '添加方式二：直接导入有题目的记事本文件，格式看右侧说明';
$it618_exam_lang['s585'] = '批量添加';
$it618_exam_lang['s586'] = '批量导入';
$it618_exam_lang['s587'] = '上传文件';
$it618_exam_lang['s588'] = '
<b>导入规则：</b>
<br>
1、每个内容必须一行显示，如换行请用&lt;br&gt;，题目内容检测已存在的不添加<br>
2、题目前面加<font color=red>#</font>，答案选项(包括多选)前面加<font color=blue>@</font><br>
3、题目解析前面加<font color=#f0f>*</font>，没有解析可以忽略<br>
4、多用空行有易读与结束当前题目的作用<br>
5、选项前面推荐不要加A、B、C，1、2、3等<br>
6、内容只支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html标签<br>
<br>
<b>导入示例：</b>
<br>
<font color=red>#</font>店铺基本设置的入口在哪里？<br>
钱掌柜<br>
淘宝卖家助手<br>
<font color=blue>@</font>管理我的店铺<br>
<font color=#f0f>*</font>可以这么理解，店铺基本设置就是管理店铺<br>
<br>
<font color=red>#</font>评价的入口在哪里？<br>
管理我的店铺<br>
<font color=blue>@</font>评价管理<br>
钱掌柜<br>
<font color=#f0f>*</font>直接从字面上理解<br>';
$it618_exam_lang['s589'] = '
<b>导入规则：</b>
<br>
1、每个内容必须一行显示，如换行请用&lt;br&gt;<br>
2、题目前面加<font color=red>#</font>，题目内的填项用<font color=blue>{}</font>表示<br>
3、题目解析前面加<font color=#f0f>*</font>，没有解析可以忽略<br>
4、请保证填项与填项答案一样的排序<br>
5、多用空行有易读与结束当前题目的作用<br>
6、内容只支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html标签<br>
<br>
<b>导入示例：</b>
<br>
<font color=red>#</font>店铺基本设置的入口在<font color=blue>{}</font><br>
管理我的店铺<br>
<font color=#f0f>*</font>可以这么理解，店铺基本设置就是管理店铺<br>
<br>
<font color=red>#</font>评价的入口在<font color=blue>{}</font><br>
评价管理<br>
<font color=#f0f>*</font>直接从字面上理解<br>
<br>
<font color=red>#</font>宝贝三要素是指<font color=blue>{}</font>、<font color=blue>{}</font>与<font color=blue>{}</font><br>
标题<br>
图片<br>
描述<br>
<font color=#f0f>*</font>就是商品的内容由哪些组成<br>';
$it618_exam_lang['s590'] = '
<b>导入规则：</b>
<br>
1、每个内容必须一行显示，如换行请用&lt;br&gt;<br>
2、正确的题目，题目内容前面加<font color=red>#@</font><br>
3、错误的题目，题目内容前面加<font color=red>#</font><br>
4、题目解析前面加<font color=#f0f>*</font>，没有解析可以忽略<br>
5、多用空行有易读与结束当前题目的作用<br>
6、内容只支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html标签<br>
<br>
<b>导入示例：</b>
<br>
<font color=red>#@</font>钻石展位是靠展现来扣费的。<br>
<font color=#f0f>*</font>广告都是要收费的<br>
<br>
<font color=red>#</font>微信不是二次营销工具。<br>
<font color=#f0f>*</font>社交软件是最好的营销工具<br>
<br>
<font color=red>#@</font>QQ群也可以进行二次营销。<br>
<font color=#f0f>*</font>社交软件是最好的营销工具<br>';
$it618_exam_lang['s591'] = '
<b>导入规则：</b>
<br>
1、每个内容必须一行显示，如换行请用&lt;br&gt;<br>
2、题目前面加<font color=red>#</font><br>
3、题目解析前面加<font color=#f0f>*</font>，没有解析可以忽略<br>
4、多用空行有易读与结束当前题目的作用<br>
5、内容只支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html标签<br>
<br>
<b>导入示例：</b>
<br>
<font color=red>#</font>对批量导入功能有什么好建议？<br>
<font color=#f0f>*</font>从操作方便性方面着手想<br>
<br>
<font color=red>#</font>对批量导入功能有什么好建议？1<br>
<font color=#f0f>*</font>从操作方便性方面着手想1<br>';
$it618_exam_lang['s592'] = '提交';
$it618_exam_lang['s593'] = '拼团活动';
$it618_exam_lang['s594'] = '要导入的文件不存在！';
$it618_exam_lang['s595'] = '拼团活动价格更低';
$it618_exam_lang['s596'] = '媒体分类';
$it618_exam_lang['s597'] = '查找';
$it618_exam_lang['s598'] = '成功批量添加题目数：';
$it618_exam_lang['s599'] = '成功批量导入题目数：';
$it618_exam_lang['s600'] = '确定要批量添加题目？请看清楚当前的题型与导入规则！';
$it618_exam_lang['s601'] = '确定要批量导入题目？请看清楚当前的题型与导入规则！';
$it618_exam_lang['s602'] = '题目解析：';
$it618_exam_lang['s603'] = '发货数';
$it618_exam_lang['s604'] = '，重复题目数：';
$it618_exam_lang['s605'] = '管理试卷';
$it618_exam_lang['s606'] = '按试卷老师';
$it618_exam_lang['s607'] = '试卷单位';
$it618_exam_lang['s608'] = '个';
$it618_exam_lang['s609'] = '';
$it618_exam_lang['s610'] = '';
$it618_exam_lang['s611'] = '启用';
$it618_exam_lang['s612'] = '消息提醒设置更新成功！';
$it618_exam_lang['s613'] = '<strong>第三方短信接口，按短信条数收费，给第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注册账号并充值，然后填以下内容就可以了';
$it618_exam_lang['s614'] = '启用消息接口：';
$it618_exam_lang['s615'] = '如果不启用，系统不会有消息提醒功能 <font color=blue>如果安装了【<a href="http://addon.dismall.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】就会支持微信模板消息，微信模板ID不为空时，优先发微信模板消息，而不发短信</font>';
$it618_exam_lang['s616'] = '短信接口账号：';
$it618_exam_lang['s617'] = '短信接口密码：';
$it618_exam_lang['s618'] = '测试接收人手机号：';
$it618_exam_lang['it618']='i11iili1i1ilililil11iliiilili111li1ililiilili111iiililili11i11il1111iilili11il1111111ilili111111iliilili11i111ilili1111ll1i1ill1111';
$it618_exam_lang['s619'] = '多个手机号用英文字母逗号隔开';
$it618_exam_lang['s620'] = '测试短信内容：';
$it618_exam_lang['s621'] = '管理员手机号：';
$it618_exam_lang['s622'] = '如果不启用，管理员不会有消息提醒';
$it618_exam_lang['s623'] = '消息模板';
$it618_exam_lang['s624'] = '注意：消息模板只有在“启用”状态，才发送提醒消息，如果短信消息模板和微信消息模板都设置了，优先发送微信消息，发送成功了，就不发短信了，方便节省短信成本';
$it618_exam_lang['s625'] = '<font color="green">申请老师认证时</font> - <font color=green>管理员消息模板</font>';
$it618_exam_lang['s626'] = '<font color="#999999">示例：${user} 在${time}申请了老师认证，请审核！
<br>标签说明：{user}申请会员，{time}申请时间</font>';
$it618_exam_lang['s627'] = '';
$it618_exam_lang['s628'] = '';
$it618_exam_lang['s629'] = '<font color="green">老师申请提现时</font> - <font color=green>管理员消息模板</font>';
$it618_exam_lang['s630'] = '<font color="#999999">示例：${shopname} 在${time}申请了 ${txmoney} 元提现，请支付！ <br>标签说明：{shopname}老师名称，{time}申请时间，{txmoney}提现金额</font>';
$it618_exam_lang['s631'] = '<font color="green">会员交易成功时</font> - <font color=green>管理员消息模板</font>';
$it618_exam_lang['s632'] = '<font color="#999999">示例：${user}购买了${pprice}的${pname} <br>标签说明：{user}交易会员名，{pname}试卷名称，{pprice}试卷金额，{purl}试卷链接，{tel}会员手机号，{time}交易时间</font>';
$it618_exam_lang['s633'] = '<font color="green">提现成功时</font> - <font color=blue>老师消息模板</font>';
$it618_exam_lang['s634'] = '<font color="#999999">示例：您申请的 ${txmoney} 元提现成功，请查收！ <br>标签说明：{txmoney}提现金额，{time}申请时间</font>';
$it618_exam_lang['s635'] = '<font color="green">会员交易成功时</font> - <font color=blue>老师消息模板</font>';
$it618_exam_lang['s636'] = '<font color="#999999">示例：${user}购买了${pprice}的${pname}<br>标签说明：{user}交易会员名，{pname}试卷名称，{pprice}试卷金额，{purl}试卷链接，{tel}会员手机号，{time}交易时间</font>';
$it618_exam_lang['s637'] = '满减券代金券活动';
$it618_exam_lang['s638'] = '考试次数';
$it618_exam_lang['s639'] = '<font color="green">会员交易成功时</font> - <font color=red>会员消息模板</font>';
$it618_exam_lang['s640'] = '<font color="#999999">示例：您购买了${pprice}的${pname}<br>标签说明：{user}交易会员名，{pname}试卷名称，{pprice}试卷金额，{purl}试卷链接，{time}交易时间</font>';
$it618_exam_lang['s641'] = '更新';
$it618_exam_lang['s642'] = '更新时发送一个测试短信';
$it618_exam_lang['s643'] = '．';
$it618_exam_lang['s644'] = '删？';
$it618_exam_lang['s645'] = '提交';
$it618_exam_lang['s646'] = '格式：图标导航行数|每行图标个数|字体大小|默认字体颜色|导航模块与屏幕边距 如：1|5|13|#666|3';
$it618_exam_lang['s647'] = '积分数：';
$it618_exam_lang['s648'] = '注意：如果商家支持商品有积分价格，那么积分类型下拉就是以下开启的积分类型';
$it618_exam_lang['s649'] = '积分类型';
$it618_exam_lang['s650'] = '显示排序';
$it618_exam_lang['s651'] = '开启';
$it618_exam_lang['s652'] = '需要';
$it618_exam_lang['s653'] = '元';
$it618_exam_lang['s654'] = '测试金额：';
$it618_exam_lang['s655'] = '请设置好后，不要经常修改，如果商品的积分类型与以上开启的积分类型不同，购买时会提示没有权限的';
$it618_exam_lang['s656'] = '风格管理';
$it618_exam_lang['s657'] = '风格数：';
$it618_exam_lang['s658'] = '搜索框、主导航与类别二级菜单颜色';
$it618_exam_lang['s659'] = '主导航当前与鼠标移动颜色';
$it618_exam_lang['s660'] = '默认风格';
$it618_exam_lang['s661'] = '注意：考试时生成的试卷会记录题目设置的分数，也就是说试卷目录或此处分数修改不会影响生成的试卷分数';
$it618_exam_lang['s662'] = '标记';
$it618_exam_lang['s663'] = '上一题';
$it618_exam_lang['s664'] = '下一题';
$it618_exam_lang['s665'] = '取消标记';
$it618_exam_lang['s666'] = '已标记';
$it618_exam_lang['s667'] = '取消';
$it618_exam_lang['s668'] = '';
$it618_exam_lang['s669'] = '天';
$it618_exam_lang['s670'] = '积分：';
$it618_exam_lang['s671'] = '记录数：';
$it618_exam_lang['s672'] = '考生UID';
$it618_exam_lang['s673'] = '1、购买后，老师赠送我';
$it618_exam_lang['s674'] = '我的统计信息';
$it618_exam_lang['s675'] = '2、给此交易点评后，我获得了';
$it618_exam_lang['s676'] = '查看';
$it618_exam_lang['s677'] = '待审核';
$it618_exam_lang['s678'] = '已通过';
$it618_exam_lang['s679'] = '未通过';
$it618_exam_lang['s680'] = '购买了';
$it618_exam_lang['s681'] = '的';
$it618_exam_lang['s682'] = '消息提醒设置更新成功！';
$it618_exam_lang['s683'] = '您申请的提现成功了，会有短信提醒';
$it618_exam_lang['s684'] = '您的试卷交易成功了，会有短信提醒';
$it618_exam_lang['s685'] = '表示已开通，只要您开启了短信提醒功能就会有短信提醒';
$it618_exam_lang['s686'] = '管理员暂时还没有开通短信接口功能！';
$it618_exam_lang['s687'] = '消息提醒设置';
$it618_exam_lang['s688'] = '系统短信提醒功能：';
$it618_exam_lang['s689'] = '启用消息提醒功能：';
$it618_exam_lang['s690'] = '如果不开启不会有短信提醒';
$it618_exam_lang['s691'] = '手机号码：';
$it618_exam_lang['s692'] = '有提醒时此手机号就会收到短信';
$it618_exam_lang['s693'] = '更新';
$it618_exam_lang['s694'] = '';
$it618_exam_lang['s695'] = '与';
$it618_exam_lang['s696'] = '有一个是必选的，请先选择其中一个！';
$it618_exam_lang['s697'] = '抱歉，';
$it618_exam_lang['s698'] = '题卡/交卷';
$it618_exam_lang['s699'] = '根';
$it618_exam_lang['s700'] = '保存';
$it618_exam_lang['s701'] = '手机：';
$it618_exam_lang['s702'] = '';
$it618_exam_lang['s703'] = '关闭';
$it618_exam_lang['s704'] = '我有';
$it618_exam_lang['s705'] = '，只用';
$it618_exam_lang['s706'] = '购买需要';
$it618_exam_lang['s707'] = '无广告试卷编号：';
$it618_exam_lang['s708'] = '现在评价';
$it618_exam_lang['s709'] = '提示：这些编号试卷，没有以下广告，多个编号用逗号隔开';
$it618_exam_lang['s710'] = '网站顶部导航';
$it618_exam_lang['s710'] = '价格设置';
$it618_exam_lang['s711'] = '类型组名称：';
$it618_exam_lang['s712'] = '如：考试次数';
$it618_exam_lang['s713'] = '类型数：';
$it618_exam_lang['s714'] = '提示：类型名称与时间在购买后是不能修改的，要么下架';
$it618_exam_lang['s715'] = '类型名称';
$it618_exam_lang['s716'] = '次数';
$it618_exam_lang['s717'] = '价格(现金价与积分价，可同时也可独立)';
$it618_exam_lang['s718'] = '原价(选填)';
$it618_exam_lang['s719'] = '库存';
$it618_exam_lang['s720'] = '排序';
$it618_exam_lang['s721'] = '上架';
$it618_exam_lang['s722'] = '交易数';
$it618_exam_lang['s723'] = '排序';
$it618_exam_lang['s724'] = '交易次数';
$it618_exam_lang['s725'] = '考试总次数';
$it618_exam_lang['s726'] = '剩余次数';
$it618_exam_lang['s727'] = '电脑版顶部导航';
$it618_exam_lang['s728'] = '数量：';
$it618_exam_lang['s729'] = '大咖老师排序：';
$it618_exam_lang['s730'] = '注意：如果老师的积分少于预警积分时，不能购买此老师的试卷，大咖老师排序值大的在前';
$it618_exam_lang['s731'] = '';
$it618_exam_lang['s732'] = '确定要删除选中的题目？此操作不可逆！';
$it618_exam_lang['s733'] = '成功删除题目数：';
$it618_exam_lang['s734'] = '起';
$it618_exam_lang['s735'] = '单独购买';
$it618_exam_lang['s736'] = '拼团购买';
$it618_exam_lang['s737'] = '电脑版考试前广告';
$it618_exam_lang['s738'] = '手机版考试前广告';
$it618_exam_lang['s739'] = '广告时间(秒)：';
$it618_exam_lang['s740'] = '提示：时间为0时表示没有广告';
$it618_exam_lang['s741'] = '我已评价';
$it618_exam_lang['s742'] = '抱歉，课程需要在开始学习{count}天后评价！';
$it618_exam_lang['s743'] = '淡雅风格(默认)';
$it618_exam_lang['s744'] = '黑金风格';
$it618_exam_lang['s745'] = '老师后台电脑模板';
$it618_exam_lang['s746'] = '';
$it618_exam_lang['s761'] = '交易会员ID';
$it618_exam_lang['s762'] = '交易状态';
$it618_exam_lang['s763'] = '刷新交易';
$it618_exam_lang['s764'] = '类型：';
$it618_exam_lang['s765'] = '手机';
$it618_exam_lang['s766'] = '老师主页';
$it618_exam_lang['s767'] = '老师详情';
$it618_exam_lang['s768'] = '访问我的主页';
$it618_exam_lang['s769'] = '手机版首页轮播';
$it618_exam_lang['s770'] = '提示：原价可以不填，如果填写会在试卷页说明此试卷原价多少';
$it618_exam_lang['s771'] = '点击进入 ';
$it618_exam_lang['s772'] = '回复';
$it618_exam_lang['s773'] = '回复提问';
$it618_exam_lang['s774'] = '随机抽取';
$it618_exam_lang['s775'] = '不可预览';
$it618_exam_lang['s776'] = '聊天笔记';
$it618_exam_lang['s777'] = '考试时聊天';
$it618_exam_lang['s778'] = '考完后聊天';
$it618_exam_lang['s779'] = '以上都聊天';
$it618_exam_lang['s780'] = '不支持聊天';
$it618_exam_lang['s781'] = '考试时笔记';
$it618_exam_lang['s782'] = '考完后笔记';
$it618_exam_lang['s783'] = '以上都笔记';
$it618_exam_lang['s784'] = '不支持笔记';
$it618_exam_lang['s785'] = '提示：一个试卷一个课程只能引用一次，也就是说一个课程目录引用了，此课程另一个目录就不能引用了';
$it618_exam_lang['s786'] = '试卷信息';
$it618_exam_lang['s787'] = '状态';
$it618_exam_lang['s788'] = '未引用';
$it618_exam_lang['s789'] = '已引用';
$it618_exam_lang['s790'] = '引用以上勾选试卷';
$it618_exam_lang['s791'] = '成功引用试卷数：';
$it618_exam_lang['s792'] = '每页记录数：';
$it618_exam_lang['s793'] = '查找内容：';
$it618_exam_lang['s794'] = '替换内容：';
$it618_exam_lang['s795'] = '添加时替换内容';
$it618_exam_lang['s796'] = '我的福利';
$it618_exam_lang['s797'] = '邀请分销/合伙人/卡券';
$it618_exam_lang['s798'] = '必须设置';
$it618_exam_lang['s799'] = '秒';
$it618_exam_lang['s800'] = '金额';
$it618_exam_lang['s801'] = '大小：';
$it618_exam_lang['s802'] = '编号';
$it618_exam_lang['s803'] = '交易会员手机';
$it618_exam_lang['s804'] = '交易时间';
$it618_exam_lang['s805'] = '需购买';
$it618_exam_lang['s806'] = '可下载';
$it618_exam_lang['s807'] = '请先登录';
$it618_exam_lang['s808'] = '文件已上传成功！';
$it618_exam_lang['s809'] = '组卷管理';
$it618_exam_lang['s810'] = '返回练习试卷管理';
$it618_exam_lang['s811'] = '目录数：';
$it618_exam_lang['s812'] = '试卷目录标题与解析';
$it618_exam_lang['s813'] = '题目管理';
$it618_exam_lang['s814'] = '随机抽取题目数：';
$it618_exam_lang['s815'] = '试卷预览题目数：';
$it618_exam_lang['s816'] = '';
$it618_exam_lang['s817'] = '加入题目';
$it618_exam_lang['s818'] = '本部分';
$it618_exam_lang['s819'] = '共';
$it618_exam_lang['s820'] = '题';
$it618_exam_lang['s821'] = '{username} 本试卷您凭VIP已免费考试了<font color=red>{ykcount}</font>次，还可以免费考<font color=red>{wkcount}</font>次';
$it618_exam_lang['s822'] = '可预览';
$it618_exam_lang['s823'] = '题';
$it618_exam_lang['s824'] = '抱歉，考试前，请您先购买试卷！';
$it618_exam_lang['s825'] = '{username} 本试卷您总共购买了<font color=red>{ygcount}</font>次，已考<font color=red>{ykcount}</font>次，还可以考<font color=red>{wkcount}</font>次';
$it618_exam_lang['s826'] = '抱歉，考试前，请您先购买试卷或成为VIP会员！';
$it618_exam_lang['s827'] = '提示：试卷目录就是大题目，有时也可以用来实现组合题目，多个小题目共用一个目录标题';
$it618_exam_lang['s828'] = '如果勾选此目录所有题目共用目录解析，如果不勾选显示题目自己的解析';
$it618_exam_lang['s829'] = '我的VIP';
$it618_exam_lang['s830'] = '详情/续购/全站VIP';
$it618_exam_lang['s831'] = '新增';
$it618_exam_lang['s832'] = '我的';
$it618_exam_lang['s833'] = '我的交易';
$it618_exam_lang['s834'] = '交易管理';
$it618_exam_lang['s835'] = '抱歉，请先登录！';
$it618_exam_lang['s836'] = '请选择导入规则：';
$it618_exam_lang['s837'] = '简洁规则(用于自己创作的新题目)';
$it618_exam_lang['s838'] = '统一规则(行业通用统一的题目规则)';
$it618_exam_lang['s839'] = '试卷名称：';
$it618_exam_lang['s840'] = '所有';
$it618_exam_lang['s841'] = '
<b>导入规则：</b>
<br>
1、每个内容必须一行显示，如换行请用&lt;br&gt;,题目内容检测已存在的不添加<br>
2、题目前面加<font color=red>数字.</font>，如：1. 2. 3.<br>
3、选项前面必须是<font color=red>大写字母.</font>，如A. B. C.等<br>
4、<font color=blue>答案:</font>后面的内容是题目答案，必须有答案<br>
5、<font color=#f0f>解析:</font>后面的内容是题目解析，没有解析可以忽略<br>
6、内容只支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html标签<br>
<br>
<b>导入示例：</b>
<br>
<font color=red>1.</font>店铺基本设置的入口在哪里？<br>
<font color=red>A.</font>钱掌柜<br>
<font color=red>B.</font>淘宝卖家助手<br>
<font color=red>C.</font>管理我的店铺<br>
<font color=blue>答案:</font>C<br>
<font color=#f0f>解析:</font>可以这么理解，店铺基本设置就是管理店铺<br>
<br>
<font color=red>2.</font>下面哪些是社交软件？<br>
<font color=red>A.</font>微信<br>
<font color=red>B.</font>QQ<br>
<font color=red>C.</font>支付宝<br>
<font color=blue>答案:</font>AB<br>
<font color=#f0f>解析:</font>这个很简单<br>';
$it618_exam_lang['s842'] = '<b>导入规则：</b>
<br>
1、每个内容必须一行显示，如换行请用&lt;br&gt;,题目内容检测已存在的不添加<br>
2、题目前面加<font color=red>数字.</font>，如：1. 2. 3.<br>
3、填空与简答一样的基本都一样的<br>
4、<font color=blue>答案:</font>后面的内容是题目答案，必须有答案<br>
5、<font color=#f0f>解析:</font>后面的内容是题目解析，没有解析可以忽略<br>
6、内容只支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html标签<br>
<br>
<b>导入示例：</b>
<br>
<font color=red>1.</font>店铺基本设置的入口在____<br>
<font color=blue>答案:</font>管理我的店铺<br>
<font color=#f0f>解析:</font>可以这么理解，店铺基本设置就是管理店铺<br>
<br>
<font color=red>2.</font>评价的入口在哪？<br>
<font color=blue>答案:</font>评价管理<br>
<font color=#f0f>解析:</font>直接从字面上理解<br>';
$it618_exam_lang['s843'] = '<b>导入规则：</b>
<br>
1、每个内容必须一行显示，如换行请用&lt;br&gt;,题目内容检测已存在的不添加<br>
2、题目前面加<font color=red>数字.</font>，如：1. 2. 3.<br>
3、T,TRUE,√,对,正确 这几个都识别成正确<br>
4、<font color=blue>答案:</font>后面的内容是题目答案，必须有答案<br>
5、<font color=#f0f>解析:</font>后面的内容是题目解析，没有解析可以忽略<br>
6、内容只支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html标签<br>
<br>
<b>导入示例：</b>
<br>
<font color=red>1.</font>店铺基本设置的入口在管理我的店铺<br>
<font color=blue>答案:</font>正确<br>
<font color=#f0f>解析:</font>只要识别不到T,TRUE,√,对或正确，这个题目答案就是错误的<br>
';
$it618_exam_lang['s844'] = '交易管理';
$it618_exam_lang['s845'] = '考生管理';
$it618_exam_lang['s846'] = '我的错题';
$it618_exam_lang['s847'] = '题目';
$it618_exam_lang['s848'] = '[考试ID]试卷';
$it618_exam_lang['s849'] = '正确率';
$it618_exam_lang['s850'] = '加入时间';
$it618_exam_lang['s851'] = '按题目关键词';
$it618_exam_lang['s852'] = '查看本题';
$it618_exam_lang['s853'] = '提成比率：';
$it618_exam_lang['s854'] = '交易数：';
$it618_exam_lang['s855'] = '试卷名称：';
$it618_exam_lang['s856'] = '返回试卷列表';
$it618_exam_lang['s857'] = '销售金额：';
$it618_exam_lang['s858'] = '提成金额：';
$it618_exam_lang['s859'] = '多个QQ用逗号隔开 如：123456,234567';
$it618_exam_lang['s860'] = '客服职位';
$it618_exam_lang['s861'] = '多个职位用逗号隔开 如：销售,采购 请注意如果是多个时和上面的QQ的个数与顺序对应好';
$it618_exam_lang['s862'] = '交易匿名';
$it618_exam_lang['s863'] = '考试ID';
$it618_exam_lang['s864'] = '现在开始自测答题';
$it618_exam_lang['s865'] = '返回我的自测';
$it618_exam_lang['s866'] = '';
$it618_exam_lang['s867'] = '隐藏';
$it618_exam_lang['s868'] = '注意：有的站可能不显示这么多分类，<b>如果勾选隐藏，前台不显示这个分类选择</b>';
$it618_exam_lang['s869'] = '销售与提成金额';
$it618_exam_lang['s870'] = ':';
$it618_exam_lang['s871'] = '首页中间公告管理';
$it618_exam_lang['s872'] = '电脑版首页轮播';
$it618_exam_lang['s873'] = '公告数：';
$it618_exam_lang['s874'] = '注意：此公告同时也会显示在手机版首页，排序为0时不显示';
$it618_exam_lang['s875'] = '标题';
$it618_exam_lang['s876'] = '链接';
$it618_exam_lang['s877'] = '文字是否粗体';
$it618_exam_lang['s878'] = '排序';
$it618_exam_lang['s879'] = '注意：图片上传后，自动强制压缩图片宽高为640px,280px，请上传前保证图片是这个比例，这样不变形更加美观';
$it618_exam_lang['s880'] = '电脑版手机版首页轮播';
$it618_exam_lang['s881'] = '图片(宽：212px，高：52px)';
$it618_exam_lang['s882'] = '链接(为空时图片不带链接)';
$it618_exam_lang['s883'] = '上传图片';
$it618_exam_lang['s884'] = '删除';
$it618_exam_lang['s885'] = '提交';
$it618_exam_lang['s886'] = '';
$it618_exam_lang['s887'] = '，试卷最低价格限制(最低价格：<font color=blue><b>{price}</b></font> 元)';
$it618_exam_lang['s888'] = '老师认证须知信息';
$it618_exam_lang['s889'] = '模块DIY调用';
$it618_exam_lang['s890'] = '分钟';
$it618_exam_lang['s891'] = '模块数量：';
$it618_exam_lang['s892'] = 'DIY调用标识符';
$it618_exam_lang['s893'] = '模块类型';
$it618_exam_lang['s894'] = '模板内容(编辑器右下角可以缩小扩大)';
$it618_exam_lang['s895'] = '记录条数';
$it618_exam_lang['s896'] = '开启JS调用';
$it618_exam_lang['s897'] = '缓存时间';
$it618_exam_lang['s898'] = '最新试卷';
$it618_exam_lang['s899'] = '热销试卷';
$it618_exam_lang['s900'] = '自定义内容';
$it618_exam_lang['s901'] = '请复制(CTRL+C)以下内容并添加到 HTML 文件中';
$it618_exam_lang['s902'] = '外部调用';
$it618_exam_lang['s903'] = '提交后编辑模板内容，并且模块类型不可修改';
$it618_exam_lang['s904'] = '默认10条记录';
$it618_exam_lang['s905'] = '默认不开启';
$it618_exam_lang['s906'] = '默认缓存时间为1分钟';
$it618_exam_lang['s907'] = '<strong>编辑器用法：</strong><img src="source/plugin/it618_exam/images/editer.png"/> <font color="red">注意非自定义模块推荐在HTML代码模式下编辑，编辑器全屏功能很方便哦</font><hr />
<strong>通用标签：</strong>[loop]...[/loop] 循环显示内容，{siteurl} 本站的网址外站调用时可到<hr />
<strong>试卷标签：</strong>{pname} 试卷名称，{ppicsrc} 试卷图片地址，{puprice} 试卷价格，{pprice} 试卷原价，{pviews} 试卷人气，{psalecount} 试卷交易数，{purl} 试卷链接
';
$it618_exam_lang['s908'] = '显示';
$it618_exam_lang['s909'] = '点击显示隐藏模块内容编辑器';
$it618_exam_lang['s910'] = '隐藏';
$it618_exam_lang['s911'] = '电脑版主导航';
$it618_exam_lang['s912'] = '名称';
$it618_exam_lang['s913'] = '链接';
$it618_exam_lang['s914'] = '名称颜色';
$it618_exam_lang['s915'] = '排序';
$it618_exam_lang['s916'] = '数量：';
$it618_exam_lang['s917'] = '提示：如果以下主导航为空，主导航默认显示老师一级分类，排序值为0时不显示';
$it618_exam_lang['s918'] = '新窗口打开';
$it618_exam_lang['s919'] = '抱歉，网站还没开通支付宝电脑版支付功能！';
$it618_exam_lang['s920'] = '抱歉，网站还没开通微信支付功能！';
$it618_exam_lang['s921'] = '抱歉，网站还没开通支付宝手机版支付功能！';
$it618_exam_lang['s922'] = '支付方式：';
$it618_exam_lang['s923'] = '积分+现金';
$it618_exam_lang['s924'] = '只能积分';
$it618_exam_lang['s925'] = '只能现金';
$it618_exam_lang['s926'] = '开通VIP会员 免费考更省钱';
$it618_exam_lang['s927'] = '提示：试卷如果不设置价格，就是免费不限次数考试，如果想收费，可以设置价格，购买考试次数';
$it618_exam_lang['s928'] = '取消购买';
$it618_exam_lang['s929'] = '抱歉，当前会员';
$it618_exam_lang['s930'] = '已在另一个客户端考试，一个会员不能同时在多个客户端考试，请您先关闭另一个客户端，再点以下按钮重新加载！';
$it618_exam_lang['s931'] = '人考试';
$it618_exam_lang['s932'] = '已有';
$it618_exam_lang['s933'] = '考试成绩';
$it618_exam_lang['s934'] = '：';
$it618_exam_lang['s935'] = '试卷评价';
$it618_exam_lang['s936'] = '试卷可以考试的时候，聊天功能会自动加载！';
$it618_exam_lang['s937'] = '设置项';
$it618_exam_lang['s938'] = '说明';
$it618_exam_lang['s939'] = '设置值';
$it618_exam_lang['s940'] = '试卷最低价格：';
$it618_exam_lang['s941'] = '元';
$it618_exam_lang['s942'] = '需登录';
$it618_exam_lang['s943'] = '"0" => "短信发送成功",
"-1" => "参数不全",
"-2" => "服务器空间不支持,请确认支持curl或者fsocket，联系您的空间商解决或者更换空间！",
"30" => "密码错误",
"40" => "账号不存在",
"41" => "余额不足",
"42" => "帐户已过期",
"43" => "IP地址限制",
"50" => "内容含有敏感词';
$it618_exam_lang['s944'] = '不开启';
$it618_exam_lang['s945'] = '一个时段';
$it618_exam_lang['s946'] = '每天时段';
$it618_exam_lang['s947'] = ' 截止日期不能小于起始日期！';
$it618_exam_lang['s948'] = ' 截止时间点不能小于等于起始时间点！';
$it618_exam_lang['s949'] = '试卷(编号';
$it618_exam_lang['s950'] = '开启时请选择限时开始时间！';
$it618_exam_lang['s951'] = '开启时请选择限时截止时间！';
$it618_exam_lang['s952'] = '限时交易已结束，敬请期待下期活动！';
$it618_exam_lang['s953'] = '距离活动开始';
$it618_exam_lang['s954'] = '距离活动结束';
$it618_exam_lang['s955'] = '每天';
$it618_exam_lang['s956'] = '显示选项';
$it618_exam_lang['s957'] = '手机版试卷页自定广告1';
$it618_exam_lang['s958'] = '手机版试卷页自定广告2';
$it618_exam_lang['s959'] = '抱歉，如果要设置支付宝转账信息，请设置完整！';
$it618_exam_lang['s960'] = '我的钱包';
$it618_exam_lang['s961'] = '电脑版颜色风格';
$it618_exam_lang['s962'] = '手机版颜色风格';
$it618_exam_lang['s963'] = '手机版图标导航';
$it618_exam_lang['s973'] = '整体颜色';
$it618_exam_lang['s974'] = '试卷页底部购卷车按钮背景色';
$it618_exam_lang['s975'] = '默认风格';
$it618_exam_lang['s976'] = '导航数：';
$it618_exam_lang['s977'] = '注意：导航图标为了清晰，推荐宽高60到120，排序为0时不显示，如果不设置导航，默认显示前9个一级分类链接';
$it618_exam_lang['s978'] = '图标';
$it618_exam_lang['s979'] = '标题';
$it618_exam_lang['s980'] = '链接';
$it618_exam_lang['s981'] = '新窗口';
$it618_exam_lang['s982'] = '文字颜色(无突出效果时要为空)';
$it618_exam_lang['s983'] = '文字粗体';
$it618_exam_lang['s984'] = '排序';
$it618_exam_lang['s985'] = '提交后再上传图片';
$it618_exam_lang['s986'] = '注意：试卷1级分类链接plugin.php?id=it618_exam:wap&pagetype=search&cid=1不是伪静态的，可以自己修改exam_wap-search-1.html<br>试卷2级分类链接plugin.php?id=it618_exam:wap&pagetype=search&cid1=1&cid2=1不是伪静态的，可以自己修改exam_wap-search-1-1.html，前面的数值是一级分类编号，后面的数值是二级分类编号';
$it618_exam_lang['s987'] = '成功转让试卷数：';
$it618_exam_lang['s988'] = '上传图片';
$it618_exam_lang['s989'] = '最新试卷';
$it618_exam_lang['s990'] = '人气试卷';
$it618_exam_lang['s991'] = '电脑版显示试卷数,手机版显示试卷数,显示顺序：';
$it618_exam_lang['s992'] = '注意3个数值之间用逗号,隔开，默认值：';
$it618_exam_lang['s993'] = '查看全部';
$it618_exam_lang['s994'] = '试卷';
$it618_exam_lang['s995'] = '抱歉，此会员还不是老师，只是提交了申请！';
$it618_exam_lang['s996'] = '抱歉，此会员的老师审核未通过！';
$it618_exam_lang['s997'] = '抱歉，此会员的老师是锁定状态！';
$it618_exam_lang['s998'] = '抱歉，此会员的老师是过期状态！';
$it618_exam_lang['s999'] = '抱歉，此会员还不是老师，也没有提交申请！';
$it618_exam_lang['s1000'] = '请输入要转让的老师会员UID：';
$it618_exam_lang['s1001'] = '试卷引用的题库也跟着转让';
$it618_exam_lang['s1002'] = '转让选中试卷';
$it618_exam_lang['s1003'] = '确定要转让选中试卷？';
$it618_exam_lang['s1004'] = '注意：试卷的交易是不会转让的，涉及到了提现，试卷交易还是转让前老师的';
$it618_exam_lang['s1005'] = '';
$it618_exam_lang['s1006'] = '提示：{waphome}表示首页链接，{wapsearch}表示搜索链接，{wapgwc}表示购卷车链接';
$it618_exam_lang['s1007'] = '模板设置';
$it618_exam_lang['s1008'] = '电脑版模板';
$it618_exam_lang['s1009'] = '手机版模板';
$it618_exam_lang['s1010'] = '教育风格(默认)';
$it618_exam_lang['s1011'] = '类别名称设置';
$it618_exam_lang['s1012'] = '注意：每个模板的前台内容可能有部分不同，需要独立设置，切换后会自动显示当前模板的设置菜单，<font color=red>请多关注此插件的增值模板</font>';
$it618_exam_lang['s1013'] = '抱歉，一个考生只能在一个客户端的一个浏览器的一个页面考试！';
$it618_exam_lang['s1014'] = '实时聊天';
$it618_exam_lang['s1015'] = '开启https';
$it618_exam_lang['s1016'] = '';
$it618_exam_lang['s1017'] = '手机版底部二级导航，格式(多个导航要换行)：<br>
&lt;li&gt;&lt;a class="react" href="导航链接1"&gt;导航名称1&lt;/a&gt;&lt;/li&gt;<br>
&lt;li&gt;&lt;a class="react" href="导航链接2"&gt;导航名称2&lt;/a&gt;&lt;/li&gt;';
$it618_exam_lang['s1018'] = '我的晒帖';
$it618_exam_lang['s1019'] = '评价';
$it618_exam_lang['s1020'] = '收藏';
$it618_exam_lang['s1021'] = '不要聊天';
$it618_exam_lang['s1032'] = '删除成功！';
$it618_exam_lang['s1033'] = '提交订单';
$it618_exam_lang['s1034'] = '您已经是';
$it618_exam_lang['s1035'] = '查看';
$it618_exam_lang['s1036'] = '积分';
$it618_exam_lang['s1037'] = '赠送';
$it618_exam_lang['s1038'] = '我的';
$it618_exam_lang['s1039'] = '开启刷单交易有考试权限 如果不开启刷单的交易只是显示在试卷页交易记录，交易会员并没有考试权限';
$it618_exam_lang['s1040'] = '短信接口类型：';
$it618_exam_lang['s1041'] = '默认标配短信接口(短信宝)';
$it618_exam_lang['s1042'] = '';
$it618_exam_lang['s1043'] = '短信签名：';
$it618_exam_lang['s1044'] = 'IT618统一短信接口(阿里云短信)';
$it618_exam_lang['s1045'] = '<font color=green><b>抱歉，您还没有安装 【<a href="http://addon.dismall.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】，此插件为IT618公用短信接口插件，<font color=red>同时还是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_exam_lang['s1046'] = '短信模板ID：';
$it618_exam_lang['s1047'] = '返积分比率';
$it618_exam_lang['s1048'] = '赠送积分';
$it618_exam_lang['s1049'] = '购买后赠送 应付*';
$it618_exam_lang['s1050'] = '抱歉，老师的';
$it618_exam_lang['s1051'] = '不够赠送交易赠送的';
$it618_exam_lang['s1052'] = '数，请与老师联系！';
$it618_exam_lang['s1053'] = '注意：导航图标为了清晰，推荐宽高60到120，导航标题推荐最多4个字，排序为0时不显示';
$it618_exam_lang['s1054'] = '赠送积分：';
$it618_exam_lang['s1055'] = '抱歉，限时交易已结束！';
$it618_exam_lang['s1056'] = '抱歉，限时交易还没有开始！';
$it618_exam_lang['s1057'] = '交易刷单设置';
$it618_exam_lang['s1058'] = '抱歉，你没有刷单权限！';
$it618_exam_lang['s1059'] = '抱歉，管理员还没有设置交易会员ID！';
$it618_exam_lang['s1060'] = '客服';
$it618_exam_lang['s1061'] = '刷单权限会员ID：';
$it618_exam_lang['s1062'] = '多个会员ID用,逗号隔开，如果会员有权限，直接点击<font color=red>电脑版试卷页的试卷名称</font>就是刷单购买，点击前可以选择消费和设置购买数量';
$it618_exam_lang['s1063'] = '随机交易会员ID：';
$it618_exam_lang['s1064'] = '多个会员ID用,逗号隔开，最好用小号会员，交易是不需要现金和积分的';
$it618_exam_lang['s1065'] = '刷单评价';
$it618_exam_lang['s1066'] = '已购';
$it618_exam_lang['s1067'] = '库存';
$it618_exam_lang['s1068'] = '提示：如果开启刷单有考试权限，还可以用于会员A线下付款，以上交易会员UID设置成会员A的，就可以实现管理员帮会员购买，也可以用于赠送某会员试卷';
$it618_exam_lang['s1069'] = '抱歉，网站还没开通现金支付功能！';
$it618_exam_lang['s1070'] = '需用';
$it618_exam_lang['s1071'] = '购卷车页';
$it618_exam_lang['s1072'] = '抱歉，只有会员才可以购买试卷，请先登录！';
$it618_exam_lang['s1073'] = '微信转账信息';
$it618_exam_lang['s1074'] = '应付总额：';
$it618_exam_lang['s1075'] = '微信姓名：';
$it618_exam_lang['s1076'] = '手机号码';
$it618_exam_lang['s1077'] = '微信账号：';
$it618_exam_lang['s1078'] = '<font color=green>已开启</font>';
$it618_exam_lang['s1079'] = '手机：';
$it618_exam_lang['s1080'] = '<font color=red>未开启</font>';
$it618_exam_lang['s1081'] = '抱歉，请先添加试卷到购卷车！';
$it618_exam_lang['s1082'] = '抱歉，您购卷车内的试卷数超过了gwcpcount的最高限制数！';
$it618_exam_lang['s1083'] = '预警积分：';
$it618_exam_lang['s1084'] = '抱歉，老师 ({shopname}) 的{creditname}低于预警数不够用来赠送积分，需要充值，请与老师联系！';
$it618_exam_lang['s1085'] = '老师 ({shopname}) ';
$it618_exam_lang['s1086'] = '您访问的老师';
$it618_exam_lang['s1087'] = '抱歉，您访问的老师不存在！';
$it618_exam_lang['s1088'] = '抱歉，您访问的老师当前是锁定状态，请与管理员联系！';
$it618_exam_lang['s1089'] = '抱歉，您访问的老师当前是过期状态，请与管理员联系！';
$it618_exam_lang['s1090'] = '抱歉，试卷不存在，请从购卷车删除此试卷！';
$it618_exam_lang['s1091'] = '加入';
$it618_exam_lang['s1092'] = '出题模式';
$it618_exam_lang['s1093'] = '全部题目';
$it618_exam_lang['s1094'] = '随机抽取';
$it618_exam_lang['s1095'] = '题型';
$it618_exam_lang['s1096'] = '购前预览数';
$it618_exam_lang['s1097'] = '类型数量';
$it618_exam_lang['s1098'] = '我的money元购卷车订单[编号：gwcid]';
$it618_exam_lang['s1099'] = '转移成功！';
$it618_exam_lang['s1100'] = '确定要转移以上全部分类？';
$it618_exam_lang['s1101'] = '手机版底部导航';
$it618_exam_lang['s1102'] = '导出查询交易到csv文件';
$it618_exam_lang['s1103'] = '、';
$it618_exam_lang['s1104'] = ',试卷名称,类型数量,交易金额,赠送积分,网站提成,交易会员,交易时间';
$it618_exam_lang['s1105'] = '确定要清空购卷车？';
$it618_exam_lang['s1106'] = '购卷车清空成功！';
$it618_exam_lang['s1107'] = '我现在有';
$it618_exam_lang['s1108'] = '抱歉，此试卷价格的积分类型没有权限，请联系老师修改积分类型！';
$it618_exam_lang['s1109'] = '点击图片时会新窗口访问这个链接';
$it618_exam_lang['s1110'] = '可赠送';
$it618_exam_lang['s1111'] = '满分：';
$it618_exam_lang['s1112'] = '常见的颜色代码是#ff0000表示红色，此设置需要把#换成0x，也就是0xff0000';
$it618_exam_lang['s1113'] = '购买后可赠送';
$it618_exam_lang['s1114'] = '清空购卷车';
$it618_exam_lang['s1115'] = '实付金额：';
$it618_exam_lang['s1116'] = '问答互动记录';
$it618_exam_lang['s1117'] = '提问内容';
$it618_exam_lang['s1118'] = '回复内容';
$it618_exam_lang['s1119'] = '提问考生';
$it618_exam_lang['s1120'] = '限量购买';
$it618_exam_lang['s1121'] = '抱歉，您当前只有';
$it618_exam_lang['s1122'] = '不够用来付款！';
$it618_exam_lang['s1123'] = '没有';
$it618_exam_lang['s1124'] = '天';
$it618_exam_lang['s1125'] = '最近购买试卷';
$it618_exam_lang['s1126'] = '一周热购试卷';
$it618_exam_lang['s1127'] = '手机首页自定广告';
$it618_exam_lang['s1128'] = '提示：此广告内容显示在手机版首页的图标导航下面最近购买上面';
$it618_exam_lang['s1129'] = '个';
$it618_exam_lang['s1130'] = '提示：限量购买的天数为0时表示所有时间内，限量购买的个数为0时表示没有限制，例如设置成1天1个，表示1个会员1天内只能购买1个';
$it618_exam_lang['s1131'] = '试卷类型';
$it618_exam_lang['s1132'] = '数量';
$it618_exam_lang['s1133'] = '单笔最多购买';
$it618_exam_lang['s1134'] = '单笔最少购买';
$it618_exam_lang['s1135'] = '抱歉，交易数量要大于0！';
$it618_exam_lang['s1136'] = '抱歉，请先选择试卷类型！';
$it618_exam_lang['s1137'] = '抱歉，此试卷类型的商品不存在！';
$it618_exam_lang['s1138'] = '抱歉，您的购买数量不能大于试卷类型库存！';
$it618_exam_lang['s1139'] = '抱歉，您最多只能购买';
$it618_exam_lang['s1140'] = '个，您已经购买了';
$it618_exam_lang['s1141'] = '个！';
$it618_exam_lang['s1142'] = '抱歉，';
$it618_exam_lang['s1143'] = '天内您最多只能购买';
$it618_exam_lang['s1144'] = '分';
$it618_exam_lang['s1145'] = '时';
$it618_exam_lang['s1146'] = '天';
$it618_exam_lang['s1147'] = '月';
$it618_exam_lang['s1148'] = '年';
$it618_exam_lang['s1149'] = '、';
$it618_exam_lang['s1150'] = '抱歉，请先勾选题目！';
$it618_exam_lang['s1151'] = '请选择要转移的分类';
$it618_exam_lang['s1152'] = '只转移{qname}';
$it618_exam_lang['s1153'] = '确定要转移{qname}？';
$it618_exam_lang['s1154'] = '转移以上全部分类';
$it618_exam_lang['s1155'] = '您已购买此试卷 还可考试';
$it618_exam_lang['s1156'] = '次';
$it618_exam_lang['s1157'] = '天';
$it618_exam_lang['s1158'] = '小时';
$it618_exam_lang['s1159'] = '分钟';
$it618_exam_lang['s1160'] = '练习考试次数';
$it618_exam_lang['s1161'] = '永久考试';
$it618_exam_lang['s1162'] = '需要续费';
$it618_exam_lang['s1163'] = '考生';
$it618_exam_lang['s1164'] = '抱歉，要复制的试卷还没有类型可以复制！';
$it618_exam_lang['s1165'] = '抱歉，当前试卷已有类型，可以删除再操作！';
$it618_exam_lang['s1166'] = '成功复制试卷类型数：';
$it618_exam_lang['s1167'] = '输入要复制的试卷ID：';
$it618_exam_lang['s1168'] = '复制类型';
$it618_exam_lang['s1169'] = '确定要复制？';
$it618_exam_lang['s1170'] = '设置选中试卷保密';
$it618_exam_lang['s1171'] = '取消选中试卷保密';
$it618_exam_lang['s1172'] = '确定要设置选中试卷保密？推荐老师直接找管理员申请保密，保密后老师没有指定的会员是不能看到与购买的！';
$it618_exam_lang['s1173'] = '确定要取消选中试卷保密？这样操作后，试卷就所有人可以看到了！';
$it618_exam_lang['s1174'] = '成功设置试卷保密数：';
$it618_exam_lang['s1175'] = '成功取消试卷保密数：';
$it618_exam_lang['s1176'] = '非保密';
$it618_exam_lang['s1177'] = '保密';
$it618_exam_lang['s1178'] = '指定会员：';
$it618_exam_lang['s1179'] = '提示：当前试卷为保密试卷，只有指定会员可以看到，百度等搜索引擎也是收录不了的，多个会员UID请用逗号隔开，如：1,2,3';
$it618_exam_lang['s1180'] = '题库管理';
$it618_exam_lang['s1181'] = '题目';
$it618_exam_lang['s1182'] = '试卷/已考';
$it618_exam_lang['s1183'] = '题目数：';
$it618_exam_lang['s1184'] = '提示：组卷时“试卷/已考”表示题目给试卷引用的数量/题目已考总次数，数量大于0时题目不能删除';
$it618_exam_lang['s1185'] = '编号';
$it618_exam_lang['s1186'] = '题目分类';
$it618_exam_lang['s1187'] = '删除选中题目';
$it618_exam_lang['s1188'] = '转移选中题目';
$it618_exam_lang['s1189'] = '加入选中题目';
$it618_exam_lang['s1190'] = '操作';
$it618_exam_lang['s1191'] = '编辑';
$it618_exam_lang['s1192'] = '删除';
$it618_exam_lang['s1193'] = '加入';
$it618_exam_lang['s1194'] = '添加题目';
$it618_exam_lang['s1195'] = '抱歉，当前题目不存在或删除！';
$it618_exam_lang['s1196'] = '选项内容';
$it618_exam_lang['s1197'] = '答案项';
$it618_exam_lang['s1198'] = '排序';
$it618_exam_lang['s1199'] = '提交后再设置答案项目';
$it618_exam_lang['s1200'] = '记录数：';
$it618_exam_lang['s1201'] = '编辑题目';
$it618_exam_lang['s1202'] = '题目名称:';
$it618_exam_lang['s1203'] = '抱歉，{classname}是{classname2}子类别，请先在{classname2}管理选择一个类别再进行{classname}管理，点击以下链接自动跳转到{classname2}管理！';
$it618_exam_lang['s1204'] = '当前：';
$it618_exam_lang['s1205'] = '级';
$it618_exam_lang['s1206'] = '网站:';
$it618_exam_lang['s1207'] = '合伙:';
$it618_exam_lang['s1208'] = '子';
$it618_exam_lang['s1209'] = '确定要删除此题目？此操作不可逆！';
$it618_exam_lang['s1210'] = '抱歉，此题目不存在或已删除！';
$it618_exam_lang['s1211'] = '抱歉，此题目不是您的！';
$it618_exam_lang['s1212'] = '抱歉，此题目已有试卷引用了，不能删除！';
$it618_exam_lang['s1213'] = '删除成功！';
$it618_exam_lang['s1214'] = '抱歉，此试卷目录不是您的！';
$it618_exam_lang['s1215'] = '抱歉，此试卷目录不存在或已删除！';
$it618_exam_lang['s1216'] = 'vip用户组';
$it618_exam_lang['s1217'] = '不开启分类vip';
$it618_exam_lang['s1218'] = '文字颜色';
$it618_exam_lang['s1219'] = '分类vip：如果以下分类设置了vip用户组，那么这个用户组的会员可以免费考试这个分类下的所有试卷，推荐设置分类vip前和老师商量';
$it618_exam_lang['s1220'] = '已拥有';
$it618_exam_lang['s1221'] = '知道了';
$it618_exam_lang['s1222'] = '购买/续费 用户组';
$it618_exam_lang['s1223'] = '开通VIP会员';
$it618_exam_lang['s1224'] = '未拥有';
$it618_exam_lang['s1225'] = '与本试卷相关的VIP如下：';
$it618_exam_lang['s1226'] = '编号';
$it618_exam_lang['s1227'] = '试卷类别1名称：';
$it618_exam_lang['s1228'] = '此类别是试卷一级类别，试卷与题库都需要，比如：年级';
$it618_exam_lang['s1229'] = '试卷类别2名称：';
$it618_exam_lang['s1230'] = '此类别是试卷二级类别，也是一级类别的子类别，试卷与题库都需要，比如：学科';
$it618_exam_lang['s1231'] = '试卷类别3名称：';
$it618_exam_lang['s1232'] = '此类别是试卷独立的类别，比如：类型';
$it618_exam_lang['s1233'] = '试卷类别4名称：';
$it618_exam_lang['s1234'] = '此类别是试卷独立的类别，试卷与题库都需要，比如：年份';
$it618_exam_lang['s1235'] = '题库类别1名称：';
$it618_exam_lang['s1236'] = '<font color=red>此类别是试卷类别2的子类别</font>，并且支持3级分类，比如：章节';
$it618_exam_lang['s1237'] = '题库类别2名称：';
$it618_exam_lang['s1238'] = '此类别是题库独立的类别，并且支持5级分类，比如：知识点';
$it618_exam_lang['s1239'] = '题库类别3名称：';
$it618_exam_lang['s1240'] = '此类别是题库独立的类别，比如：难易';
$it618_exam_lang['s1241'] = '题库类别4名称：';
$it618_exam_lang['s1242'] = '此类别是题库独立的类别，比如：能力';
$it618_exam_lang['s1243'] = '类别名称设置更新成功！';
$it618_exam_lang['s1244'] = '类别数：';
$it618_exam_lang['s1245'] = '题目数';
$it618_exam_lang['s1246'] = '模式与预览';
$it618_exam_lang['s1247'] = '分数';
$it618_exam_lang['s1248'] = '选择';
$it618_exam_lang['s1249'] = '所有';
$it618_exam_lang['s1250'] = '所有题型';
$it618_exam_lang['s1251'] = '查询题目';
$it618_exam_lang['s1252'] = '重置查询';
$it618_exam_lang['s1253'] = '添加题目';
$it618_exam_lang['s1254'] = '抱歉，请先选择';
$it618_exam_lang['s1255'] = '！';
$it618_exam_lang['s1256'] = '抱歉，此题目已加入到当前试卷！';
$it618_exam_lang['s1257'] = '确定要加入此题目到试卷？';
$it618_exam_lang['s1258'] = '年级|学科|类型|年份|章节|知识点|难易|能力';
$it618_exam_lang['s1259'] = '题目名称';
$it618_exam_lang['s1260'] = '题目分数';
$it618_exam_lang['s1261'] = '题目排序';
$it618_exam_lang['s1262'] = '取消选中题目';
$it618_exam_lang['s1263'] = '图片广告：';
$it618_exam_lang['s1264'] = '晒排名';
$it618_exam_lang['s1265'] = '晒交易';
$it618_exam_lang['s1266'] = '匿名';
$it618_exam_lang['s1267'] = '考试会员';
$it618_exam_lang['s1268'] = '考试成绩';
$it618_exam_lang['s1269'] = '成绩排名';
$it618_exam_lang['s1270'] = '考试时间';
$it618_exam_lang['s1271'] = '第';
$it618_exam_lang['s1272'] = '名';
$it618_exam_lang['s1273'] = '永久';
$it618_exam_lang['s1351'] = '抱歉，本试卷的全部类型已下架，类型价格至少有一个是大于0的！';
$it618_exam_lang['s1352'] = '加入';
$it618_exam_lang['s1353'] = '领取';
$it618_exam_lang['s1354'] = '注意：类型价格可以免费为0，试卷默认显示价格是类型的大于0的最低价格，<font color=red>就算是免费的，也是需要购买的，只是付款时金额为0</font>';
$it618_exam_lang['s1355'] = '考试次数';
$it618_exam_lang['s1356'] = '已加入';
$it618_exam_lang['s1357'] = '自测设置';
$it618_exam_lang['s1358'] = '自测说明';
$it618_exam_lang['s1359'] = '您好，欢迎自测答题';
$it618_exam_lang['s1360'] = '已设置好 现在自测';
$it618_exam_lang['s1361'] = '您的购卷车还没有试卷，请先挑选试卷！';
$it618_exam_lang['s1362'] = '自测不同于考试，题目不设分数，答题完成后只计算正确率，如果题目做对了自动从错题库删除。';
$it618_exam_lang['s1363'] = '自测的题目可以来源于自己的错题库，也可以是某个老师的题库，可以按题库分类分别测试；';
$it618_exam_lang['s1364'] = '如果答题过程中因电源、网络故障等造成中断，可以直接从我的错题-自测答题，自动从中断处继续答题；';
$it618_exam_lang['s1365'] = 'Sogou、360浏览器请用极速模式，如果出现异常无法答题请换一种浏览器；';
$it618_exam_lang['s1366'] = '我的错题库(已有{count}题)';
$it618_exam_lang['s1367'] = '显示试卷聊天者IP';
$it618_exam_lang['s1368'] = '显示聊天者城市';
$it618_exam_lang['s1369'] = '试卷聊天：';
$it618_exam_lang['s1370'] = '题目来自：';
$it618_exam_lang['s1371'] = '赠送';
$it618_exam_lang['s1372'] = '随机抽取：';
$it618_exam_lang['s1373'] = '道题目';
$it618_exam_lang['s1374'] = '答题时间：';
$it618_exam_lang['s1375'] = '分钟(不大于150分钟)';
$it618_exam_lang['s1376'] = '答案解析：';
$it618_exam_lang['s1377'] = '不要提示';
$it618_exam_lang['s1378'] = '需要提示';
$it618_exam_lang['s1379'] = '抱歉，请填写答题时间为正整数数值！';
$it618_exam_lang['s1380'] = '抱歉，请填写答题时间数值不能大于150！';
$it618_exam_lang['s1381'] = '正确/比率';
$it618_exam_lang['s1382'] = '正确';
$it618_exam_lang['s1383'] = '错误';
$it618_exam_lang['s1384'] = '确定要根据以上设置进行自测？';
$it618_exam_lang['s1385'] = '自测答题';
$it618_exam_lang['s1386'] = '自测信息';
$it618_exam_lang['s1387'] = '正确率';
$it618_exam_lang['s1388'] = '已测完';
$it618_exam_lang['s1389'] = '未测完';
$it618_exam_lang['s1390'] = '查看测题';
$it618_exam_lang['s1391'] = '继续答题';
$it618_exam_lang['s1392'] = '共{qcount}题 考时{time}分钟';
$it618_exam_lang['s1393'] = '抱歉，您的错题库没有题目用来自测，可以设置考试交卷自动加入错题，也可以手工加入错题！';
$it618_exam_lang['s1394'] = '次数';
$it618_exam_lang['s1395'] = '';
$it618_exam_lang['s1396'] = '关注';
$it618_exam_lang['s1397'] = '已关注';
$it618_exam_lang['s1398'] = '关注成功！';
$it618_exam_lang['s1399'] = '取消关注成功！';
$it618_exam_lang['s1400'] = '我的粉丝';
$it618_exam_lang['s1401'] = '会员';
$it618_exam_lang['s1402'] = '关注时间';
$it618_exam_lang['s1403'] = '我的关注';
$it618_exam_lang['s1404'] = '老师';
$it618_exam_lang['s1405'] = '粉丝数：';
$it618_exam_lang['s1406'] = '按粉丝UID';
$it618_exam_lang['s1407'] = '看哪些人喜欢我';
$it618_exam_lang['s1408'] = '老师数：';
$it618_exam_lang['s1409'] = '手机版底部信息';
$it618_exam_lang['s1410'] = '提示：以上在代码模式下可以插入第三方访问统计代码，用于统计所有前台页面的访问情况';
$it618_exam_lang['s1411'] = '统计代码：';
$it618_exam_lang['s1412'] = '注意：此代码会自动插入到您的电脑版手机版的试卷页、个人页、考试页等，此内容都是隐藏的，请只填写第三方提供的统计代码';
$it618_exam_lang['s1413'] = '按excel规则(指定每行列字母序号)';
$it618_exam_lang['s1414'] = '题目名称：';
$it618_exam_lang['s1415'] = '题目选项：';
$it618_exam_lang['s1416'] = '题目答案：';
$it618_exam_lang['s1449'] = '天';
$it618_exam_lang['s1450'] = '小时';
$it618_exam_lang['s1451'] = '分钟';
$it618_exam_lang['s1452'] = '秒';
$it618_exam_lang['s1453'] = '题目解析：';
$it618_exam_lang['s1454'] = '先根据要导入的EXCEL列字母序号和以下设置对应：';
$it618_exam_lang['s1455'] = '显示默认菜单(刷新页面、复制链接、注册登录等)';
$it618_exam_lang['s1456'] = '无';
$it618_exam_lang['s1457'] = '从';
$it618_exam_lang['s1458'] = '<b>导入规则：</b>
<br>
1、每个题目在Excel内一行显示，不同列表示题目的不同内容<br>
2、导入时Excel内第一行标题不导的，从第二行开始导入<br>
3、判断题如果是正确的，内容可以是T,TRUE,√,对,正确 这几个都识别成正确<br>
4、解析是可选导入项，如果设置了解析列序号，没有解析内容可以忽略不导<br>
5、内容只支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html标签<br>
';
$it618_exam_lang['s1459'] = 'vip考试时显示广告的试卷编号：';
$it618_exam_lang['s1460'] = '提示：如果不设置表示vip考试所有的试卷时不显示广告';
$it618_exam_lang['s1461'] = '自定义查询';
$it618_exam_lang['s1462'] = '查询条件：';
$it618_exam_lang['s1463'] = '格式：分类1id(为0表示所有)<font color=red>|</font>分类2id(为0表示所有)<font color=red>|</font>老师id(为0表示所有)<font color=red>|</font>排序编号(1、最新发布 2、最多考试)';
$it618_exam_lang['s1464'] = '例如：1|3|1|1';
$it618_exam_lang['s1465'] = '到';
$it618_exam_lang['s1466'] = '增加次数';
$it618_exam_lang['s1467'] = '填项答案';
$it618_exam_lang['s1468'] = '填项编号';
$it618_exam_lang['s1469'] = '提示：题目名称内插入<font color=blue>{}</font>标签表示一个填项，可以插入多个标签，<font color=blue>注意：答案和标签顺序一致，不对应好会影响评分</font>，<a href="source/plugin/it618_exam/images/tk.png" target="_blank">如果不清楚请点击查看示例图片</a>';
$it618_exam_lang['s1470'] = '试卷';
$it618_exam_lang['s1471'] = '成绩';
$it618_exam_lang['s1472'] = '错题';
$it618_exam_lang['s1473'] = '自测';
$it618_exam_lang['s1474'] = '拼团活动试卷';
$it618_exam_lang['s1475'] = '限时抢购试卷';
$it618_exam_lang['s1476'] = '提示：拼团活动试卷仅安装了拼团插件有效';
$it618_exam_lang['s1477'] = '编辑标题与解析';
$it618_exam_lang['s1478'] = '更新内容并关闭当前弹窗';
$it618_exam_lang['s1479'] = '目录标题<font color=#999>(做题时目录下的小题目都显示这个目录标题，小技巧：有时需要时，可以实现类似组合题效果)</font>：';
$it618_exam_lang['s1480'] = '目录解析：';
$it618_exam_lang['s1481'] = '删除选中+更新所有分数';
$it618_exam_lang['s1482'] = '统考试卷';
$it618_exam_lang['s1483'] = '试卷类型：';
$it618_exam_lang['s1484'] = '注意：试卷类型在试卷添加保存后是不能修改的';
$it618_exam_lang['s1485'] = '统考审核信息';
$it618_exam_lang['s1486'] = '题目数：';
$it618_exam_lang['s1487'] = '状态';
$it618_exam_lang['s1488'] = '试卷题目/试卷考生';
$it618_exam_lang['s1489'] = '准考管理';
$it618_exam_lang['s1490'] = '人已考/共';
$it618_exam_lang['s1491'] = '人';
$it618_exam_lang['s1492'] = '注意：随机抽取题目，推荐题目类型一样，比如都是选择题或填空题等';
$it618_exam_lang['s1493'] = '随机抽取模式，题目分数必须相同，请在下面批量设置题目分数！';
$it618_exam_lang['s1494'] = '开始：';
$it618_exam_lang['s1495'] = '申请审核选中试卷';
$it618_exam_lang['s1496'] = '确定要申请审核选中试卷？试卷在审核中与已通过状态时，试卷的统考审核信息不能修改，未申请与未通过状态是可以再修改的！\n\n试卷申请条件：\n1、试卷内有题目，并且设置了分数\n2、试卷要设置考试时间\n3、试卷的统考开始时间（必须比现在时间多1小时）与限考人数';
$it618_exam_lang['s1497'] = '未申请';
$it618_exam_lang['s1498'] = '待审核';
$it618_exam_lang['s1499'] = '未通过';
$it618_exam_lang['s1500'] = '已通过';
$it618_exam_lang['s1501'] = '注意：如果考试人数不多，推荐不搞多批次考试，如果是多批次考试，每个批次什么时候考也需要申请审核';
$it618_exam_lang['s1502'] = '限考：';
$it618_exam_lang['s1503'] = '多批次考试时当前考试批次(选填)：';
$it618_exam_lang['s1504'] = '成功申请审核试卷数：';
$it618_exam_lang['s1505'] = '审核通过选中试卷';
$it618_exam_lang['s1506'] = '确定要审核通过选中试卷？\n试卷状态是待审核与未通过时，可以设置成已通过状态';
$it618_exam_lang['s1507'] = '审核不通过选中试卷';
$it618_exam_lang['s1508'] = '确定要审核不通过选中试卷？\n试卷状态是待审核与已通过时，可以设置成未通过状态';
$it618_exam_lang['s1509'] = '成功审核已通过试卷数：';
$it618_exam_lang['s1510'] = '成功审核未通过试卷数：';
$it618_exam_lang['s1511'] = '距离考试开始';
$it618_exam_lang['s1512'] = '距离考试结束';
$it618_exam_lang['s1513'] = '试卷准备中';
$it618_exam_lang['s1514'] = '开始考试';
$it618_exam_lang['s1515'] = '抱歉，此试卷还没有审核！';
$it618_exam_lang['s1516'] = '抱歉，此试卷已结束考试！';
$it618_exam_lang['s1517'] = '抱歉，此试卷还未开始考试！';
$it618_exam_lang['s1518'] = '抱歉，您不是本试卷的考生！';
$it618_exam_lang['s1519'] = '抱歉，此试卷您已考，请您在我的统考成绩查看！';
$it618_exam_lang['s1520'] = '抱歉，您的考试批次与试卷当前的考试批次不一致！';
$it618_exam_lang['s1521'] = '继续考试';
$it618_exam_lang['s1522'] = '后考试';
$it618_exam_lang['s1523'] = '正在考试中';
$it618_exam_lang['s1524'] = '展开更多';
$it618_exam_lang['s1525'] = '报名管理';
$it618_exam_lang['s1526'] = '人已审/共';
$it618_exam_lang['s1527'] = '练习权限';
$it618_exam_lang['s1528'] = '统考预告';
$it618_exam_lang['s1529'] = '注意：如果同步权限勾选，那么学员如果有本课程或章节的权限（同步权限仅在课程付费时有效），试卷可以免费练习';
$it618_exam_lang['s1530'] = '同步';
$it618_exam_lang['s1531'] = '已同步课程权限 现在考试';
$it618_exam_lang['s1532'] = '';
$it618_exam_lang['s1533'] = '';
$it618_exam_lang['s1534'] = '';
$it618_exam_lang['s1535'] = '试卷独立vip';
$it618_exam_lang['s1536'] = '注意：试卷分类vip与独立vip可以自动合并的';
$it618_exam_lang['s1537'] = '试卷独立vip设置成功！';
$it618_exam_lang['s1553'] = '能购买';
$it618_exam_lang['s1554'] = '抱歉，您还没拥有“购买试卷权限的VIP”！点击“开通VIP会员”可以查看相关VIP。';
$it618_exam_lang['s1555'] = '抱歉，您还没拥有“购买试卷权限的VIP”或“折扣优惠的VIP”！点击“开通VIP会员”可以查看相关VIP。';
$it618_exam_lang['s1560'] = '<font color="red">请登录</font>';
$it618_exam_lang['s1561'] = '您是讲师VIP，已为您自动审核通过！点击确定，自动进入讲师后台！';
$it618_exam_lang['s1562'] = '您是讲师VIP，已为您自动审核通过！';
$it618_exam_lang['s1592'] = '';
$it618_exam_lang['s1593'] = '';
$it618_exam_lang['s1617'] = '手机版APP提示管理';
$it618_exam_lang['s1618'] = '手机版首页APP提示标题';
$it618_exam_lang['s1619'] = '手机版首页APP提示链接';
$it618_exam_lang['s1620'] = '手机版试卷页APP提示左图标';
$it618_exam_lang['s1621'] = '手机版试卷页APP提示左标题';
$it618_exam_lang['s1622'] = '手机版试卷页APP提示左说明';
$it618_exam_lang['s1623'] = '手机版试卷页APP提示标题';
$it618_exam_lang['s1624'] = '手机版试卷页APP提示链接';
$it618_exam_lang['s1625'] = 'APP提示不显示的浏览器标识';
$it618_exam_lang['s1626'] = 'APP提示关闭重显周期(分钟)';
$it618_exam_lang['s1627'] = 'APP提示更新成功！';
$it618_exam_lang['s1628'] = '提示：如果没有APP或想显示别的提示内容也是可以的';
$it618_exam_lang['s1629'] = '开启手机版首页APP提示';
$it618_exam_lang['s1630'] = '开启手机版试卷页APP提示';
$it618_exam_lang['s1631'] = '不填写表示所有端访问都显示 常见APP标识：马甲APP(MAGAPPX)、小云APP(Appbyme) 多个标识用逗号隔开，如：MAGAPPX,Appbyme';
$it618_exam_lang['s1634'] = '购买';
$it618_exam_lang['s1635'] = '续费';
$it618_exam_lang['s1636'] = '更多VIP会员';
$it618_exam_lang['s1639'] = 'PC广告图片：';
$it618_exam_lang['s1640'] = 'PC广告链接：';
$it618_exam_lang['s1641'] = 'WAP广告图片：';
$it618_exam_lang['s1642'] = 'WAP广告链接：';
$it618_exam_lang['s1643'] = '提示：显示在电脑版试卷页';
$it618_exam_lang['s1644'] = '提示：显示在手机版试卷页，点老师菜单显示';
$it618_exam_lang['s1648'] = '收藏';
$it618_exam_lang['s1649'] = '已收藏';
$it618_exam_lang['s1650'] = '取消';
$it618_exam_lang['s1651'] = '收藏成功！';
$it618_exam_lang['s1652'] = '取消收藏成功！';
$it618_exam_lang['s1653'] = '我的课程';
$it618_exam_lang['s1654'] = '我的收藏';
$it618_exam_lang['s1655'] = '取消收藏';
$it618_exam_lang['s1656'] = '取消收藏成功！';
$it618_exam_lang['s1657'] = '操作';
$it618_exam_lang['s1658'] = '收藏时间';
$it618_exam_lang['s1683'] = '如果您的浏览器没有自动跳转，请点击这里';
$it618_exam_lang['s1684'] = '提示';
$it618_exam_lang['s1703'] = '会员编号';
$it618_exam_lang['s1704'] = '排序';
$it618_exam_lang['s1705'] = '状态推荐排序';
$it618_exam_lang['s1706'] = '手机版首页顶部显示搜索框';
$it618_exam_lang['s1707'] = '点这个搜索框会自动跳转到搜索页，并且自动弹出关键字输入';
$it618_exam_lang['s1721'] = '手机版首页统考预告';
$it618_exam_lang['s1722'] = '当有很多统考时，填0表示默认不展开，填1表示默认展开，格式：展开与否设置|右侧提示，如：0|展开更多';
$it618_exam_lang['s1723'] = '展开更多';
$it618_exam_lang['s1724'] = '手机版首页图标导航排数';
$it618_exam_lang['s1725'] = '手机版首页热门试卷';
$it618_exam_lang['s1726'] = '如果填0表示随插件设置的风格，如果填大于0的数，表示强制左图右信息风格显示，并且试卷强制只显示设置的数量';
$it618_exam_lang['s1759'] = '<font color="#999999">示例：${user}您成功支付了一个购卷车编号为${gwcid}交易！<br>标签说明：{user}交易会员名，{gwcid}订单编号，{time}交易时间</font>';
$it618_exam_lang['s1760'] = '<font color="green">会员购卷车交易成功时</font> - <font color="green">管理员消息模板</font>';
$it618_exam_lang['s1761'] = '<font color="#999999">示例：考生${user}成功支付了一个购卷车编号为${gwcid}交易！<br>标签说明：{user}交易会员名，{gwcid}订单编号，{tel}会员手机号，{time}交易时间</font>';
$it618_exam_lang['s1762'] = '<font color="green">会员购卷车交易成功时</font> - <font color="blue">老师消息模板</font>';
$it618_exam_lang['s1763'] = '<font color="#999999">示例：考生${user}成功支付了一个购卷车编号为${gwcid}交易！<br>标签说明：{user}交易会员名，{gwcid}订单编号，{tel}会员手机号，{time}交易时间</font>';
$it618_exam_lang['s1764'] = '<font color="green">会员购卷车交易成功时</font> - <font color="red">会员消息模板</font>';
$it618_exam_lang['s1765'] = '返回老师管理';
$it618_exam_lang['s1766'] = '已启用';
$it618_exam_lang['s1767'] = '插入';
$it618_exam_lang['s1768'] = '请输入您要搜索的试卷名称关键词...';
$it618_exam_lang['s1769'] = '';
$it618_exam_lang['s1770'] = '试卷类别';
$it618_exam_lang['s1771'] = '请输入试卷关键字';
$it618_exam_lang['s1772'] = '限5张';
$it618_exam_lang['s1773'] = '添加照片';
$it618_exam_lang['s1774'] = '<font color=red>提示：已审核通过的老师不能删除，可以转让给别的会员，也可以锁定老师，锁定相当于回收站，前台不会显示与此老师相关的信息！</font>';
$it618_exam_lang['s1775'] = '<font color=red>提示：有交易或有考试的试卷不能删除，可以修改试卷，也可以下架试卷！同时试卷下面有目录时，也不能删除，请先删除目录！</font>';
$it618_exam_lang['s1776'] = '收起';
$it618_exam_lang['s1777'] = '确定要考试？如果此试卷未考完，点确定可以继续接着上次考试！';
$it618_exam_lang['s1778'] = '';
$it618_exam_lang['s1779'] = '';
$it618_exam_lang['s1780'] = '';
$it618_exam_lang['s1781'] = '';
$it618_exam_lang['s1782'] = '字';
$it618_exam_lang['s1783'] = '抱歉，此插件还未开启，请先开启！';
$it618_exam_lang['s1784'] = '知道了';
$it618_exam_lang['s1785'] = '积分信息';
$it618_exam_lang['s1786'] = '启用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_exam_lang['s1787'] = '';
$it618_exam_lang['s1788'] = '';
$it618_exam_lang['s1789'] = '';
$it618_exam_lang['s1790'] = '';
$it618_exam_lang['s1791'] = '管理员UID<font color=#999>(用于微信消息，多个UID用,隔开)</font>：';
$it618_exam_lang['s1792'] = '购卷车改价';
$it618_exam_lang['s1793'] = '购卷车会员UID：';
$it618_exam_lang['s1794'] = '加载并锁定此会员在本店购卷车试卷';
$it618_exam_lang['s1795'] = '原价：';
$it618_exam_lang['s1796'] = '价格修改好了现在解锁';
$it618_exam_lang['s1797'] = '现价：';
$it618_exam_lang['s1798'] = '此会员在本店的购卷车解锁成功！';
$it618_exam_lang['s1799'] = '抱歉，您的购卷车有老师在修改价格，现已锁定，请在老师修改好价格解锁后再操作！';
$it618_exam_lang['s1800'] = '老师订购管理';
$it618_exam_lang['s1800'] = '笔记';
$it618_exam_lang['s1801'] = '聊天';
$it618_exam_lang['s1802'] = '老师推荐试卷';
$it618_exam_lang['s1803'] = '推荐排序';
$it618_exam_lang['s1804'] = '<font color=red>图片有效部分宽1200px，高359px，并且宽度必须大于1200px，这样适应更多的宽屏浏览器，宽度多余部分请用图片两侧颜色填充</font>';
$it618_exam_lang['s1805'] = '模板设置更新成功！';
$it618_exam_lang['s1806'] = '分享';
$it618_exam_lang['s1807'] = '长按识别二维码';
$it618_exam_lang['s1808'] = '此试卷还没有考生评价！';
$it618_exam_lang['s1809'] = '前台是否可以切换风格';
$it618_exam_lang['s1810'] = '如果开启访问者就可以自己选择风格模板，是以cookies方式记录模板风格在客户端';
$it618_exam_lang['s1811'] = '界面风格';
$it618_exam_lang['s1812'] = '推荐';
$it618_exam_lang['s1813'] = '删除选中题目';
$it618_exam_lang['s1814'] = '清空所有题目';
$it618_exam_lang['s1815'] = '老师';
$it618_exam_lang['s1816'] = '老师介绍';
$it618_exam_lang['s1817'] = '题ID';
$it618_exam_lang['s1818'] = '确定要删除选中题目？此操作不可逆！';
$it618_exam_lang['s1819'] = '确定要清空所有题目？此操作不可逆！';
$it618_exam_lang['s1820'] = '抱歉，请先选择要删除的题目！';
$it618_exam_lang['s1821'] = '电脑版试卷页显示交易记录';
$it618_exam_lang['s1822'] = '是否在试卷页显示合伙推广';
$it618_exam_lang['s1823'] = '试卷页默认显示内容';
$it618_exam_lang['s1824'] = '清空成功！';
$it618_exam_lang['s1825'] = '';
$it618_exam_lang['s1826'] = '有it618推广佣金联盟插件时，同时老师添加了合伙推广，如果不想试卷页显示合伙推广，可以不开启';
$it618_exam_lang['s1827'] = '';
$it618_exam_lang['s1828'] = '';
$it618_exam_lang['s1829'] = '手机版试卷页显示交易记录';
$it618_exam_lang['s1830'] = '';
$it618_exam_lang['s1831'] = '我要考试';
$it618_exam_lang['s1832'] = '来自试卷：';
$it618_exam_lang['s1833'] = '加入错题库';
$it618_exam_lang['s1834'] = '移出错题库';
$it618_exam_lang['s1835'] = '已加入';
$it618_exam_lang['s1836'] = '加入';
$it618_exam_lang['s1837'] = '移出';
$it618_exam_lang['s1838'] = '';
$it618_exam_lang['s1839'] = '';
$it618_exam_lang['s1840'] = '是否在老师页显示券与推广';
$it618_exam_lang['s1841'] = '如果开启就会在电脑版手机版的老师页显示优惠券与合伙推广菜单与功能';
$it618_exam_lang['s1842'] = '【预览】';
$it618_exam_lang['s1843'] = '重新加载';
$it618_exam_lang['s1844'] = '多VIP用户组设置';
$it618_exam_lang['s1845'] = '用户组名称';
$it618_exam_lang['s1846'] = '导入(更新)用户组';
$it618_exam_lang['s1847'] = '启用数：';
$it618_exam_lang['s1848'] = '提示：如果一个试卷是在当前一级分类下，那么以下开启的用户组都可以免费考试';
$it618_exam_lang['s1849'] = '已成功导入(更新)论坛所有用户组！';
$it618_exam_lang['s1850'] = '多VIP用户组设置成功！';
$it618_exam_lang['s1843'] = '重新加载';
$it618_exam_lang['s1857'] = '注册或登录会员会有历史搜索功能';
$it618_exam_lang['s1858'] = '全部清空';
$it618_exam_lang['s1859'] = '我的历史搜索';
$it618_exam_lang['s1860'] = '【';
$it618_exam_lang['s1861'] = '】';
$it618_exam_lang['s1862'] = '有效时间';
$it618_exam_lang['s1863'] = '';
$it618_exam_lang['s1878'] = '在线编辑器设置';
$it618_exam_lang['s1879'] = '启用oss接口：';
$it618_exam_lang['s1880'] = '如果不启用，上传图片到本地，如果启用，上传图片到oss，并且返回图片网络引用链接';
$it618_exam_lang['s1881'] = 'IT618插件阿里云OSS接口设置方法';
$it618_exam_lang['s1882'] = 'Access Key ID：';
$it618_exam_lang['s1883'] = 'Access Key Secret：';
$it618_exam_lang['s1884'] = 'OSS名称：';
$it618_exam_lang['s1885'] = 'Bucket域名EndPoint：';
$it618_exam_lang['s1886'] = 'Bucket外网访问域名：';
$it618_exam_lang['s1888'] = '如果是个人认证，变量字符最多限制个数：';
$it618_exam_lang['s1889'] = '不受限制时请不要填写';
$it618_exam_lang['s1890'] = '合伙推广赚提成';
$it618_exam_lang['s1901'] = '微信消息模板ID：';
$it618_exam_lang['s1902'] = '微信消息标签值：';
$it618_exam_lang['s1903'] = '<font color=#999>提示：优先发送微信消息，发送成功了，就不发短信了</font>';
$it618_exam_lang['s1904'] = '关闭';
$it618_exam_lang['s1905'] = '参数名称';
$it618_exam_lang['s1906'] = '参数内容';
$it618_exam_lang['s1907'] = '提示：最多支持9个微信消息模板参数，参数名称比如是：first,keyword1,keyword2,keyword3,...,remark，参数内容支持以上一个标签或多个标签';
$it618_exam_lang['s1908'] = '取消';
$it618_exam_lang['s1909'] = '保存';
$it618_exam_lang['s1910'] = '抱歉，如果参数名称填写了，就必须填写参数内容！';
$it618_exam_lang['s1911'] = '<font color=green>提示：默认有短信宝接口，如果配合 <a href="http://addon.dismall.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a> 可以有阿里云短信接口，此插件以后还可以扩展更多短信接口</font>';
$it618_exam_lang['s1952'] = '折后';
$it618_exam_lang['s1953'] = '折优惠';
$it618_exam_lang['s1954'] = '免费考';
$it618_exam_lang['s1955'] = 'VIP名称';
$it618_exam_lang['s1956'] = '权限';
$it618_exam_lang['s1957'] = '期限';
$it618_exam_lang['s1958'] = '当前菜单标题颜色';
$it618_exam_lang['s1959'] = '当前菜单图标';
$it618_exam_lang['s1960'] = '允许上传的图片扩展名：';
$it618_exam_lang['s1961'] = '允许上传的附件扩展名：';
$it618_exam_lang['s1962'] = '允许图片最大尺寸(M)：';
$it618_exam_lang['s1963'] = '允许附件最大尺寸(M)：';
$it618_exam_lang['s1964'] = '以下为空时，是编辑器默认值，不是必须填写的，和是否开启OSS没关系都有作用';
$it618_exam_lang['s1965'] = '如：jpg,jpeg,png 用逗号隔开';
$it618_exam_lang['s1966'] = '如：doc,docx,xls,xlsx,ppt,pdf 用逗号隔开';
$it618_exam_lang['s1967'] = '提示：不要大于服务器最大上传限制';

//{lang it618_exam:it618_exam_lang(\d+)} {$it618_exam_lang['t$1']}
$it618_exam_lang['t1'] = '：';
$it618_exam_lang['t2'] = '抱歉，试卷还未设置价格！';
$it618_exam_lang['t3'] = '剩';
$it618_exam_lang['t4'] = '(剩0次)';
$it618_exam_lang['t5'] = '工作时间：';
$it618_exam_lang['t6'] = '电话：';
$it618_exam_lang['t7'] = '老师简介：';
$it618_exam_lang['t8'] = '我的交易';
$it618_exam_lang['t9'] = '';
$it618_exam_lang['t10'] = '';
$it618_exam_lang['t11'] = '';
$it618_exam_lang['t12'] = '按关键词';
$it618_exam_lang['t13'] = '提示：考试试卷';
$it618_exam_lang['t14'] = '天后(免费试卷考试了也算)可以对试卷进行评价';
$it618_exam_lang['t15'] = '，评价一次奖励';
$it618_exam_lang['t16'] = '评价奖励:';
$it618_exam_lang['t17'] = '保存笔记';
$it618_exam_lang['t18'] = '抱歉，没有考试权限时，提问与笔记也会没权限！';
$it618_exam_lang['t19'] = '请选择';
$it618_exam_lang['t20'] = '交易时间';
$it618_exam_lang['t21'] = '查找';
$it618_exam_lang['t22'] = '确定要提交订单？为防止完成付款时积分不够扣，提交后出现现金付款界面时，就已经扣积分了，请务必完成付款！';
$it618_exam_lang['t23'] = '试卷名称';
$it618_exam_lang['t24'] = '每人';
$it618_exam_lang['t25'] = '天内可购买';
$it618_exam_lang['t26'] = '金额';
$it618_exam_lang['t27'] = '删除选中考生';
$it618_exam_lang['t28'] = '确定要删除选中考生？';
$it618_exam_lang['t29'] = '修改以上考生信息';
$it618_exam_lang['t30'] = '试卷评价';
$it618_exam_lang['t31'] = '交易时间';
$it618_exam_lang['t32'] = '按关键字';
$it618_exam_lang['t33'] = '状态';
$it618_exam_lang['t34'] = '';
$it618_exam_lang['t35'] = '很差';
$it618_exam_lang['t36'] = '较差';
$it618_exam_lang['t37'] = '一般';
$it618_exam_lang['t38'] = '较好';
$it618_exam_lang['t39'] = '很好';
$it618_exam_lang['t40'] = '请评分';
$it618_exam_lang['t41'] = '可以对考试的试卷进行评价，一个试卷只能评价一次，综合评分直接参与试卷总评分和满意度计算，其它3个评分是对试卷的更详细的评价，并且只对自己的总评分参与计算';
$it618_exam_lang['t42'] = '5至400字数内';
$it618_exam_lang['t43'] = '提交';
$it618_exam_lang['t44'] = '取消';
$it618_exam_lang['t45'] = '试卷评价';
$it618_exam_lang['t46'] = '老师设置';
$it618_exam_lang['t47'] = '基本信息';
$it618_exam_lang['t48'] = '消息提醒设置';
$it618_exam_lang['t49'] = '';
$it618_exam_lang['t50'] = '添加试卷';
$it618_exam_lang['t51'] = '管理试卷';
$it618_exam_lang['t52'] = '交易管理';
$it618_exam_lang['t53'] = '财务管理';
$it618_exam_lang['t54'] = '财务信息';
$it618_exam_lang['t55'] = '申请提现';
$it618_exam_lang['t56'] = '您确定要退出老师管理后台吗？';
$it618_exam_lang['t57'] = '个';
$it618_exam_lang['t58'] = '星期日';
$it618_exam_lang['t59'] = '星期一';
$it618_exam_lang['t60'] = '星期二';
$it618_exam_lang['t61'] = '星期三';
$it618_exam_lang['t62'] = '星期四';
$it618_exam_lang['t63'] = '星期五';
$it618_exam_lang['t64'] = '星期六';
$it618_exam_lang['t65'] = '月';
$it618_exam_lang['t66'] = '日';
$it618_exam_lang['t67'] = '查看交易';
$it618_exam_lang['t68'] = '发货';
$it618_exam_lang['t69'] = '确定要给以下交易发货？';
$it618_exam_lang['t70'] = '交易信息：';
$it618_exam_lang['t71'] = '每人最多可购买';
$it618_exam_lang['t72'] = '老师还为你推荐了以下几门试卷';
$it618_exam_lang['t73'] = '';
$it618_exam_lang['t74'] = '老师名称：';
$it618_exam_lang['t75'] = '联系电话：';
$it618_exam_lang['t76'] = 'QQ号码：';
$it618_exam_lang['t77'] = '店铺地址：';
$it618_exam_lang['t78'] = '老师简介：';
$it618_exam_lang['t79'] = '提交申请';
$it618_exam_lang['t80'] = '申请已提交，请等待管理员审核！';
$it618_exam_lang['t81'] = '确定';
$it618_exam_lang['t82'] = '抱歉，您所在用户组没有申请认证老师权限！';
$it618_exam_lang['t83'] = '搜索';
$it618_exam_lang['t84'] = '首页';
$it618_exam_lang['t85'] = '全部试卷分类';
$it618_exam_lang['t86'] = '热门分类';
$it618_exam_lang['t87'] = '全部区域';
$it618_exam_lang['t88'] = '更多';
$it618_exam_lang['t89'] = '热门试卷';
$it618_exam_lang['t90'] = '最近刚购买的试卷';
$it618_exam_lang['t91'] = '最近购买';
$it618_exam_lang['t92'] = '限时抢购促销活动课程';
$it618_exam_lang['t93'] = '限时抢购';
$it618_exam_lang['t94'] = '回到顶部';
$it618_exam_lang['t95'] = '找到';
$it618_exam_lang['t96'] = '“';
$it618_exam_lang['t97'] = '”';
$it618_exam_lang['t98'] = '相关的试卷共';
$it618_exam_lang['t99'] = '个。';
$it618_exam_lang['t100'] = '分&nbsp;&nbsp;类：';
$it618_exam_lang['t101'] = '位&nbsp;&nbsp;置：';
$it618_exam_lang['t102'] = '价&nbsp;&nbsp;格：';
$it618_exam_lang['t103'] = '默认排序';
$it618_exam_lang['t104'] = '销量从高到低';
$it618_exam_lang['t105'] = '销量';
$it618_exam_lang['t106'] = '价格从低到高';
$it618_exam_lang['t107'] = '价格';
$it618_exam_lang['t108'] = '价格从高到低';
$it618_exam_lang['t109'] = '按更新时间排序';
$it618_exam_lang['t110'] = '更新时间';
$it618_exam_lang['t111'] = '销量排行';
$it618_exam_lang['t112'] = '您的位置：';
$it618_exam_lang['t113'] = '折';
$it618_exam_lang['t114'] = '人购买';
$it618_exam_lang['t115'] = '人气';
$it618_exam_lang['t116'] = '人已评价';
$it618_exam_lang['t117'] = '分';
$it618_exam_lang['t118'] = '问答';
$it618_exam_lang['t119'] = '笔记';
$it618_exam_lang['t120'] = '考生评价';
$it618_exam_lang['t121'] = '购买数量';
$it618_exam_lang['t122'] = '立即购买';
$it618_exam_lang['t123'] = '该老师其它试卷';
$it618_exam_lang['t124'] = '销量排行';
$it618_exam_lang['t125'] = '动态';
$it618_exam_lang['t126'] = '老师简介';
$it618_exam_lang['t127'] = '试卷概述';
$it618_exam_lang['t128'] = '考生评价(';
$it618_exam_lang['t129'] = ')';
$it618_exam_lang['t130'] = '人气从高到低';
$it618_exam_lang['t131'] = '我是VIP会员 现在考试';
$it618_exam_lang['t132'] = '现在考试';
$it618_exam_lang['t133'] = '工作时间：';
$it618_exam_lang['t134'] = '联系电话：';
$it618_exam_lang['t135'] = '老师简介：';
$it618_exam_lang['t136'] = '试卷目录';
$it618_exam_lang['t137'] = '考试';
$it618_exam_lang['t138'] = '成绩排名(';
$it618_exam_lang['t139'] = '排名(';
$it618_exam_lang['t140'] = '已购';
$it618_exam_lang['t141'] = '交易(';
$it618_exam_lang['t142'] = '试卷评价';
$it618_exam_lang['t143'] = '评价人次：';
$it618_exam_lang['t144'] = '满意占比：';
$it618_exam_lang['t145'] = '分';
$it618_exam_lang['t146'] = '试卷评价';
$it618_exam_lang['t147'] = '请稍后，加载中…';
$it618_exam_lang['t148'] = '原价';
$it618_exam_lang['t149'] = '折扣';
$it618_exam_lang['t150'] = '更新时间：';
$it618_exam_lang['t151'] = '所属章节';
$it618_exam_lang['t152'] = '资料名称';
$it618_exam_lang['t153'] = '文件大小';
$it618_exam_lang['t154'] = '下载';
$it618_exam_lang['t155'] = '查看全部分类';
$it618_exam_lang['t156'] = '热&nbsp;&nbsp;门：';
$it618_exam_lang['t157'] = '至';
$it618_exam_lang['t158'] = '更多';
$it618_exam_lang['t159'] = '首页';
$it618_exam_lang['t160'] = '网站首页';
$it618_exam_lang['t161'] = '试卷分类';
$it618_exam_lang['t162'] = '试卷评价';
$it618_exam_lang['t163'] = '交易管理';
$it618_exam_lang['t164'] = '按关键词';
$it618_exam_lang['t165'] = '交易会员ID';
$it618_exam_lang['t166'] = '交易ID';
$it618_exam_lang['t167'] = '查看简介';
$it618_exam_lang['t168'] = '查看';
$it618_exam_lang['t169'] = '返回试卷';
$it618_exam_lang['t170'] = '试卷简介';
$it618_exam_lang['t171'] = '老师管理后台';
$it618_exam_lang['t172'] = '关闭';
$it618_exam_lang['t173'] = '试卷详情';
$it618_exam_lang['t174'] = '老师概览';
$it618_exam_lang['t175'] = '评价内容字数至少5个！';
$it618_exam_lang['t176'] = '评价内容字数最多400个！';
$it618_exam_lang['t177'] = '确定要提交此次评价？提交后不可修改。';
$it618_exam_lang['t178'] = '您输入了';
$it618_exam_lang['t179'] = '个字！';
$it618_exam_lang['t180'] = '登录';
$it618_exam_lang['t181'] = '注册';
$it618_exam_lang['t182'] = '老师地址：';
$it618_exam_lang['t183'] = '分 评价人次:';
$it618_exam_lang['t184'] = '满意占比:';
$it618_exam_lang['t185'] = '交易信息：';
$it618_exam_lang['t186'] = '关闭';
$it618_exam_lang['t187'] = '购卷车';
$it618_exam_lang['t188'] = '购买成功，您可以考试了！';
$it618_exam_lang['t189'] = '抱歉，现在没有开通支付接口，请与管理员联系！';
$it618_exam_lang['t190'] = '数量不能超过您自己现在有的数量！';
$it618_exam_lang['t191'] = '电脑版';
$it618_exam_lang['t192'] = '立即购买';
$it618_exam_lang['t193'] = '加入购卷车';
$it618_exam_lang['t194'] = '元';
$it618_exam_lang['t195'] = '应付金额：';
$it618_exam_lang['t196'] = '手机号码：';
$it618_exam_lang['t197'] = '购买试卷';
$it618_exam_lang['t198'] = '正在提交订单...如果您不想等可以关闭交易窗口，后台会自动运行！';
$it618_exam_lang['t199'] = '购买成功，您可以考试了！';
$it618_exam_lang['t200'] = '确定购买';
$it618_exam_lang['t201'] = '订单号';
$it618_exam_lang['t202'] = '赠送';
$it618_exam_lang['t203'] = '试卷金额:';
$it618_exam_lang['t204'] = '抱歉，登录后可以考试！';
$it618_exam_lang['t205'] = '现在登录';
$it618_exam_lang['t206'] = '确定现在登录？';
$it618_exam_lang['t207'] = '扫码访问我的主页';
$it618_exam_lang['t208'] = '试卷数量：';
$it618_exam_lang['t209'] = '试卷评价：';
$it618_exam_lang['t210'] = '：';
$it618_exam_lang['t211'] = '购买数量：';
$it618_exam_lang['t212'] = '考试人数：';
$it618_exam_lang['t213'] = '分享老师';
$it618_exam_lang['t214'] = '全部试卷';
$it618_exam_lang['t215'] = '方便老师与您联系';
$it618_exam_lang['t216'] = '抱歉，请输入有效的11位手机号码！';
$it618_exam_lang['t217'] = '老师详情';
$it618_exam_lang['t218'] = '老师入驻';
$it618_exam_lang['t219'] = '热卖试卷';
$it618_exam_lang['t220'] = '人气试卷';
$it618_exam_lang['t221'] = '活动卡券';
$it618_exam_lang['t222'] = '老师主页';
$it618_exam_lang['t223'] = '交易管理';
$it618_exam_lang['t224'] = '退出登录';
$it618_exam_lang['t225'] = '练习考试成绩';
$it618_exam_lang['t226'] = '试卷名称';
$it618_exam_lang['t227'] = '试卷数：';
$it618_exam_lang['t228'] = '考生';
$it618_exam_lang['t229'] = '得分';
$it618_exam_lang['t230'] = '开始时间/完成时间';
$it618_exam_lang['t231'] = '状态';
$it618_exam_lang['t232'] = '主页';
$it618_exam_lang['t233'] = '在线客服：';
$it618_exam_lang['t234'] = '当前IP';
$it618_exam_lang['t235'] = '历史IP';
$it618_exam_lang['t236'] = '按试卷ID';
$it618_exam_lang['t237'] = '提示';
$it618_exam_lang['t238'] = '个试卷';
$it618_exam_lang['t239'] = '考生UID';
$it618_exam_lang['t240'] = '交易记录(';
$it618_exam_lang['t241'] = '【交易记录】';
$it618_exam_lang['t242'] = '交易会员';
$it618_exam_lang['t243'] = '最近购买试卷';
$it618_exam_lang['t244'] = '刷新记录';
$it618_exam_lang['t245'] = '导出查询记录到csv文件';
$it618_exam_lang['t246'] = '考试时间';
$it618_exam_lang['t247'] = '交易时间';
$it618_exam_lang['t248'] = '状态';
$it618_exam_lang['t249'] = '刷新交易';
$it618_exam_lang['t250'] = '会员';
$it618_exam_lang['t251'] = '时间';
$it618_exam_lang['t252'] = '金额总计(元)';
$it618_exam_lang['t253'] = '交易记录';
$it618_exam_lang['t254'] = '全部试卷';
$it618_exam_lang['t255'] = '试卷类别:';
$it618_exam_lang['t256'] = '刷新';
$it618_exam_lang['t257'] = '所有一级分类';
$it618_exam_lang['t258'] = '所有二级分类';
$it618_exam_lang['t259'] = '不限次数 现在考试';
$it618_exam_lang['t260'] = '抱歉，购买后或成为vip会员可以考试！';
$it618_exam_lang['t261'] = '关键字词:';
$it618_exam_lang['t262'] = '试卷价格:';
$it618_exam_lang['t263'] = '抱歉，购买后可以考试！';
$it618_exam_lang['t264'] = '人考试';
$it618_exam_lang['t265'] = '手机版扫码';
$it618_exam_lang['t266'] = '扫码访问手机版';
$it618_exam_lang['t267'] = '试卷目录';
$it618_exam_lang['t268'] = '排序方式:';
$it618_exam_lang['t269'] = '默认排序';
$it618_exam_lang['t270'] = '试卷价格';
$it618_exam_lang['t271'] = '试卷交易';
$it618_exam_lang['t272'] = '试卷人气';
$it618_exam_lang['t273'] = '查看全部试卷';
$it618_exam_lang['t274'] = '奖励积分';
$it618_exam_lang['t275'] = '确定要用积分购买此试卷？';
$it618_exam_lang['t276'] = '抱歉，请先给此次消费评分！';
$it618_exam_lang['t277'] = '搜索';
$it618_exam_lang['t278'] = '现金购买';
$it618_exam_lang['t279'] = '认证须知';
$it618_exam_lang['t280'] = '购卷车编号';
$it618_exam_lang['t281'] = '请填写老师名称！';
$it618_exam_lang['t282'] = '请填写联系电话！';
$it618_exam_lang['t283'] = '请填写老师简介！';
$it618_exam_lang['t284'] = '合伙推广';
$it618_exam_lang['t285'] = '关闭';
$it618_exam_lang['t286'] = '评价内容字数至少5个！';
$it618_exam_lang['t287'] = '评价内容字数最多400个！';
$it618_exam_lang['t288'] = '确定要提交此次评价？提交后不可修改。';
$it618_exam_lang['t289'] = '考试人数';
$it618_exam_lang['t290'] = '评价数';
$it618_exam_lang['t291'] = '您输入了';
$it618_exam_lang['t292'] = '个字！';
$it618_exam_lang['t293'] = '开始日期不能大于截止日期！';
$it618_exam_lang['t294'] = '确定要申请随时退款？此操作不可逆。';
$it618_exam_lang['t295'] = '确定要确认收货？此操作不可逆。';
$it618_exam_lang['t296'] = '请输入试卷关键词';
$it618_exam_lang['t297'] = '';
$it618_exam_lang['t298'] = '点击头像访问老师主页';
$it618_exam_lang['t299'] = '输入我要搜索的试卷关键字';
$it618_exam_lang['t300'] = '';
$it618_exam_lang['t301'] = '更多';
$it618_exam_lang['t302'] = '支付方式:';
$it618_exam_lang['t303'] = '积分';
$it618_exam_lang['t304'] = '现金';
$it618_exam_lang['t305'] = '积分+现金';
$it618_exam_lang['t306'] = '抱歉，请先登录！也可以点确定直接跳转到登录页面！';
$it618_exam_lang['t307'] = '限时交易';
$it618_exam_lang['t308'] = '天';
$it618_exam_lang['t309'] = '时';
$it618_exam_lang['t310'] = '分';
$it618_exam_lang['t311'] = '秒';
$it618_exam_lang['t312'] = '最新发布的试卷';
$it618_exam_lang['t313'] = '浏览量最多的试卷';
$it618_exam_lang['t314'] = '热门试卷';
$it618_exam_lang['t315'] = '预览';
$it618_exam_lang['t316'] = '支付方式';
$it618_exam_lang['t317'] = '试卷搜索';
$it618_exam_lang['t339'] = '确定要修改此次评价？修改后您还可以再修改！';
$it618_exam_lang['t340'] = '返回';
$it618_exam_lang['t341'] = '刷新';
$it618_exam_lang['t342'] = '抱歉，请输入提问回复内容！';
$it618_exam_lang['t343'] = '确定要提交提问回复内容？';
$it618_exam_lang['t344'] = '提问回复成功！';
$it618_exam_lang['t345'] = '回复：';
$it618_exam_lang['t346'] = '抱歉，请输入评价回复内容！';
$it618_exam_lang['t347'] = '确定要提交评价回复内容？';
$it618_exam_lang['t348'] = '评价回复成功！';
$it618_exam_lang['t349'] = '分享';
$it618_exam_lang['t350'] = '抱歉，免费试卷不能刷交易！';
$it618_exam_lang['t351'] = '抱歉，随机到的会员已购买此试卷了！';
$it618_exam_lang['t352'] = '概述';
$it618_exam_lang['t353'] = '目录';
$it618_exam_lang['t354'] = '评价(';
$it618_exam_lang['t355'] = '老师';
$it618_exam_lang['t356'] = '注意：如果一个试卷需要组织多批次考试，可以根据批次进行区分，如果不搞批次，请保持批次为1，以免影响考试';
$it618_exam_lang['t357'] = '付款方式：';
$it618_exam_lang['t358'] = '微信扫码支付';
$it618_exam_lang['t359'] = '手机扫码访问此试卷';
$it618_exam_lang['t360'] = '在线客服';
$it618_exam_lang['t361'] = '手机扫描二维码访问此页面';
$it618_exam_lang['t362'] = '也可以复制以下支付链接到微信：';
$it618_exam_lang['t363'] = '查看在线客服';
$it618_exam_lang['t364'] = '展开';
$it618_exam_lang['t365'] = '关闭在线客服';
$it618_exam_lang['t366'] = '收缩';
$it618_exam_lang['t367'] = '老师简介';
$it618_exam_lang['t368'] = '工作时间';
$it618_exam_lang['t369'] = '热线电话';
$it618_exam_lang['t370'] = '确定要刷单购买？';
$it618_exam_lang['t371'] = '刷单成功，点击自动刷新页面！';
$it618_exam_lang['t372'] = '确定要删除？';
$it618_exam_lang['t373'] = '删除';
$it618_exam_lang['t374'] = '，如果无操作<font color=red>{time}秒</font>后自动从头播放！';
$it618_exam_lang['t375'] = '会员';
$it618_exam_lang['t376'] = '分享';
$it618_exam_lang['t377'] = '准考号';
$it618_exam_lang['t378'] = '姓名';
$it618_exam_lang['t379'] = '备注';
$it618_exam_lang['t380'] = '状态';
$it618_exam_lang['t381'] = '购卷车添加成功！';
$it618_exam_lang['t382'] = '此试卷已经在购卷车！';
$it618_exam_lang['t383'] = '提问删除成功！';
$it618_exam_lang['t384'] = '付款方式';
$it618_exam_lang['t385'] = '抱歉，您没有删除权限！';
$it618_exam_lang['t386'] = '其它试卷';
$it618_exam_lang['t387'] = '申请已提交，请等待管理员审核！';
$it618_exam_lang['t388'] = '批次';
$it618_exam_lang['t389'] = '我的';
$it618_exam_lang['t390'] = '余额';
$it618_exam_lang['t391'] = '元/查看积分';
$it618_exam_lang['t392'] = '购卷车';
$it618_exam_lang['t393'] = '有';
$it618_exam_lang['t394'] = '个试卷想购买';
$it618_exam_lang['t395'] = '个';
$it618_exam_lang['t396'] = '买家给UID我';
$it618_exam_lang['t405'] = '5至400字数内';
$it618_exam_lang['t406'] = '请输入右边交易码：';
$it618_exam_lang['t407'] = '看不清';
$it618_exam_lang['t408'] = '提问';
$it618_exam_lang['t409'] = '';
$it618_exam_lang['t410'] = '提问内容不能为空！';
$it618_exam_lang['t411'] = '提问内容字数至少5个！';
$it618_exam_lang['t412'] = '提问内容字数最多400个！';
$it618_exam_lang['t413'] = '您当前的访问请求当中含有非法字符，已经被系统拒绝！';
$it618_exam_lang['t414'] = '抱歉，交易码输入错误！';
$it618_exam_lang['t415'] = '您输入了';
$it618_exam_lang['t416'] = '个字！';
$it618_exam_lang['t417'] = '回复';
$it618_exam_lang['t418'] = '楼';
$it618_exam_lang['t654'] = '抱歉，请先登录！也可以直接点确定跳转到登录页面！';
$it618_exam_lang['t748'] = '提问成功！';
$it618_exam_lang['t749'] = '提交订单';
$it618_exam_lang['t750'] = '去支付';
$it618_exam_lang['t751'] = '完成';
$it618_exam_lang['t752'] = '试卷';
$it618_exam_lang['t753'] = '价格';
$it618_exam_lang['t754'] = '金额';
$it618_exam_lang['t755'] = '操作';
$it618_exam_lang['t756'] = '保存成功！';
$it618_exam_lang['t757'] = '数量';
$it618_exam_lang['t758'] = '返回上页';
$it618_exam_lang['t759'] = '刷新页面';
$it618_exam_lang['t760'] = '搜索试卷';
$it618_exam_lang['t763'] = '复制链接';
$it618_exam_lang['t764'] = '请升级您的微信版本！';
$it618_exam_lang['t765'] = '链接复制成功！';
$it618_exam_lang['t766'] = '';
$it618_exam_lang['t767'] = '确定要删除“';
$it618_exam_lang['t768'] = '”？此操作不可逆！';
$it618_exam_lang['t769'] = '确定要清空历史搜索？此操作不可逆！';
$it618_exam_lang['t796'] = '此会员已添加！';
$it618_exam_lang['t797'] = '没有此注册会员！';
$it618_exam_lang['t798'] = '待考';
$it618_exam_lang['t799'] = '已考';
$it618_exam_lang['t800'] = '';
$it618_exam_lang['t843'] = '抱歉，要导入的EXCEL文件不存在！';
$it618_exam_lang['t844'] = '成功批量导入考生数：';
$it618_exam_lang['t845'] = '';
$it618_exam_lang['t846'] = '';
$it618_exam_lang['t847'] = '考生数量：';
$it618_exam_lang['t848'] = '说明：“会员UID”是考试前必须在考试系统注册一个的会员，这个会员的编号，本试卷已存在会员UID在添加或导入时不再添加';
$it618_exam_lang['t849'] = '';
$it618_exam_lang['t850'] = '<strong>添加方式一：</strong>直接把考生信息 复制到下面文本框内，一行一个考生 格式如下：<br><br><font color=#390>会员UID(必填),批次(可填),准考号(可填),姓名(可填),备注(可填)</font>';
$it618_exam_lang['t851'] = '<strong>添加方式二：</strong>请在EXCEL内按以下指定字母序号填写内容(<font color=red>注意：从第二行开始读取</font>)：<br><br>
<font color=#390>A：会员UID(必填)、B：批次(可填)、C：准考号(可填)、D：姓名(可填)、E：备注(可填)';
$it618_exam_lang['t852'] = '批量添加';
$it618_exam_lang['t853'] = '上传文件';
$it618_exam_lang['t854'] = '批量导入';
$it618_exam_lang['t855'] = '商品名称：';
$it618_exam_lang['t856'] = '成功批量导入数：';
$it618_exam_lang['t857'] = '成功批量添加数：';
$it618_exam_lang['t894'] = '访问我的个人空间';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_set'));
if($count==0){
$sql = <<<EOF
	INSERT INTO `pre_it618_exam_set` (`id`, `setname`, `setvalue`) VALUES
(1, 'topnav', '<li>\r\n	<a target="_blank" href="">帮助</a><span></span>\r\n</li>\r\n<li>\r\n	<a target="_blank" href="">反馈</a>\r\n</li>'),
(2, 'hotclassgoods', '1,2,3,4,7,8,15,16,17,18,23,31,32,41,42,43,44,45,54@@@3,1,2,6,8,9,12,13,15,18,1,2,6,8,9,12,13,15,18,19@@@1,2,1,2'),
(3, 'footer', '<p>\r\n	<a href="#" target="_blank">在线考试</a><span>|</span><a href="#" target="_blank">多类别多题型</a><span>|</span><a href="#" target="_blank">树形类别</a><span>|</span><a href="#" target="_blank">题库组卷</a><span>|</span><a href="#" target="_blank">次数价格</a><span>|</span><a href="#" target="_blank">考试跟踪</a><span>|</span><a href="#" target="_blank">智能评分</a> \r\n</p>\r\n<p class="p_color">\r\n	网站客服电话:010－12345678　　友情提示：此处内容可以在插件后台“风格设置-电脑版底部信息”自定义\r\n</p>\r\n<p>\r\n	<br />\r\n</p>');

EOF;
$sql=str_replace("pre_it618_exam_set",DB::table('it618_exam_set'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_class1` (`id`, `it618_classname`, `it618_pj`, `it618_color`, `it618_order`, `it618_goodscount`, `it618_wapgoodscount`, `it618_img`, `it618_url`, `it618_vipgroupid`, `it618_istj`) VALUES
(1, '一年级', '综合评分_描述相符_讲解表达_答疑服务', '', 1, 8, 4, '', '', 0, 0),
(2, '二年级', '综合评分_描述相符_讲解表达_答疑服务', '', 2, 8, 4, '', '', 0, 0),
(3, '三年级', '综合评分_描述相符_讲解表达_答疑服务', '', 3, 8, 4, '', '', 0, 0),
(4, '四年级', '综合评分_描述相符_讲解表达_答疑服务', '', 4, 8, 4, '', '', 0, 0),
(5, '五年级', '综合评分_描述相符_讲解表达_答疑服务', '', 5, 8, 4, '', '', 0, 0),
(6, '六年级', '综合评分_描述相符_讲解表达_答疑服务', '', 6, 8, 4, '', '', 0, 0),
(7, '七年级', '综合评分_描述相符_讲解表达_答疑服务', '', 7, 8, 4, '', '', 0, 0),
(8, '八年级', '综合评分_描述相符_讲解表达_答疑服务', '', 8, 8, 4, '', '', 0, 0),
(9, '九年级', '综合评分_描述相符_讲解表达_答疑服务', '', 9, 8, 4, '', '', 0, 0),
(10, '高一', '综合评分_描述相符_讲解表达_答疑服务', '', 10, 8, 4, '', '', 0, 0),
(11, '高二', '综合评分_描述相符_讲解表达_答疑服务', '', 11, 8, 4, '', '', 0, 0),
(12, '高三', '综合评分_描述相符_讲解表达_答疑服务', '', 12, 8, 4, '', '', 0, 0);
EOF;
$sql=str_replace("pre_it618_exam_class1",DB::table('it618_exam_class1'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_class2` (`id`, `it618_class1_id`, `it618_classname`, `it618_color`, `it618_order`, `it618_istj`) VALUES
(1, 1, '语文', '', 1, 1),
(2, 1, '数学', '', 2, 1),
(3, 2, '语文', '', 1, 1),
(4, 2, '数学', '', 2, 1),
(5, 3, '语文', '', 1, 1),
(6, 3, '数学', '', 2, 1),
(7, 3, '英语', '', 3, 1),
(8, 4, '语文', '', 1, 1),
(9, 4, '数学', '', 2, 1),
(10, 4, '英语', '', 3, 1),
(11, 5, '语文', '', 1, 1),
(12, 5, '数学', '', 2, 1),
(13, 5, '英语', '', 3, 1),
(14, 6, '语文', '', 1, 1),
(15, 6, '数学', '', 2, 1),
(16, 6, '英语', '', 3, 1),
(17, 7, '语文', '', 1, 1),
(18, 7, '数学', '', 2, 1),
(19, 7, '英语', '', 3, 1),
(20, 7, '物理', '', 4, 1),
(21, 7, '化学', '', 5, 1),
(22, 7, '历史', '', 6, 1),
(23, 7, '生物', '', 7, 1),
(24, 7, '地理', '', 8, 1),
(25, 7, '政治', '', 9, 1),
(26, 8, '语文', '', 1, 1),
(27, 8, '数学', '', 2, 1),
(28, 8, '英语', '', 3, 1),
(29, 8, '物理', '', 4, 1),
(30, 8, '化学', '', 5, 1),
(31, 8, '历史', '', 6, 0),
(32, 8, '生物', '', 7, 0),
(33, 8, '地理', '', 8, 0),
(34, 8, '政治', '', 9, 0),
(35, 9, '语文', '', 1, 0),
(36, 9, '数学', '', 2, 0),
(37, 9, '英语', '', 3, 1),
(38, 9, '物理', '', 4, 1),
(39, 9, '化学', '', 5, 1),
(40, 9, '历史', '', 6, 1),
(41, 9, '生物', '', 7, 1),
(42, 9, '地理', '', 8, 1),
(43, 9, '政治', '', 9, 1),
(44, 10, '语文', '', 1, 1),
(45, 10, '数学', '', 2, 1),
(46, 10, '英语', '', 3, 1),
(47, 10, '物理', '', 4, 1),
(48, 10, '化学', '', 5, 1),
(49, 10, '历史', '', 6, 1),
(50, 10, '生物', '', 7, 1),
(51, 10, '地理', '', 8, 1),
(52, 10, '政治', '', 9, 1),
(53, 11, '语文', '', 1, 1),
(54, 11, '数学', '', 2, 1),
(55, 11, '英语', '', 3, 1),
(56, 11, '物理', '', 4, 1),
(57, 11, '化学', '', 5, 1),
(58, 11, '历史', '', 6, 1),
(59, 11, '生物', '', 7, 1),
(60, 11, '地理', '', 8, 1),
(61, 11, '政治', '', 9, 1),
(62, 12, '语文', '', 1, 1),
(63, 12, '数学', '', 2, 1),
(64, 12, '英语', '', 3, 1),
(65, 12, '物理', '', 4, 1),
(66, 12, '化学', '', 5, 1),
(67, 12, '历史', '', 6, 1),
(68, 12, '生物', '', 7, 1),
(69, 12, '地理', '', 8, 1),
(70, 12, '政治', '', 9, 1);
EOF;
$sql=str_replace("pre_it618_exam_class2",DB::table('it618_exam_class2'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_qtype` (`id`, `it618_typename`, `it618_order`) VALUES
(1, '单选题', 1),
(2, '多选题', 2),
(3, '填空题', 3),
(4, '判断题', 4),
(5, '主观题', 5);
EOF;
$sql=str_replace("pre_it618_exam_qtype",DB::table('it618_exam_qtype'),$sql);
DB::query($sql);
	
$sql = <<<EOF
INSERT INTO `pre_it618_exam_style` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#ff971b', '#e46703', 0),
(2, '#DD2525', '#B52020', 0),
(3, '#48b518', '#289a00', 0),
(4, '#03acde', '#0396cc', 1),
(5, '#f50bc1', '#c5099b', 0),
(6, '#09aeb0', '#089395', 0),
(8, '#ff4400', '#e03e03', 0),
(7, '#888c8e', '#6f7071', 0);
EOF;
$sql=str_replace("pre_it618_exam_style",DB::table('it618_exam_style'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_wapstyle` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#fd9e2d', '#e8922b', 0),
(2, '#fc4646', '#f43131', 1),
(3, '#5ebe00', '#56aa04', 0),
(4, '#23b8ff', '#12a8ff', 0),
(5, '#fb23cb', '#ea11ba', 0),
(6, '#2dbeae', '#00a795', 0),
(8, '#fe5400', '#d04906', 0),
(7, '#999a9b', '#8d8f90', 0);
EOF;
$sql=str_replace("pre_it618_exam_wapstyle",DB::table('it618_exam_wapstyle'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_iconav` (`id`, `it618_title`, `it618_img`, `it618_url`, `it618_target`, `it618_color`, `it618_isbold`, `it618_order`) VALUES
(1, 'Web开发', 'source/plugin/it618_exam/wap/images/1.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=1', 0, '', 0, 1),
(2, '编程开发', 'source/plugin/it618_exam/wap/images/2.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=2', 0, '', 0, 2),
(3, '考试认证', 'source/plugin/it618_exam/wap/images/3.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=3', 0, '', 0, 3),
(4, '数据库', 'source/plugin/it618_exam/wap/images/4.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=4', 0, '', 0, 4),
(5, '网络安全', 'source/plugin/it618_exam/wap/images/5.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=5', 0, '', 0, 5),
(6, '人工智能', 'source/plugin/it618_exam/wap/images/6.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=6', 0, '', 0, 6),
(7, '移动开发', 'source/plugin/it618_exam/wap/images/7.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=7', 0, '', 0, 7),
(8, '游戏开发', 'source/plugin/it618_exam/wap/images/8.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=8', 0, '', 0, 8),
(9, '嵌入式', 'source/plugin/it618_exam/wap/images/9.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=9', 0, '', 0, 9),
(10, '服务器运维', 'source/plugin/it618_exam/wap/images/10.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=10', 0, '', 0, 10),
(11, '办公效率', 'source/plugin/it618_exam/wap/images/11.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=11', 0, '', 0, 11),
(12, '产品设计', 'source/plugin/it618_exam/wap/images/12.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=12', 0, '', 0, 12);
EOF;
$sql=str_replace("pre_it618_exam_iconav",DB::table('it618_exam_iconav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_bottomnav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_exam_bottomnav` (`id`, `it618_title`, `it618_img`, `it618_curimg`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '发现', 'source/plugin/it618_exam/wap/images/menu.png', '', '','',3),
(2, '首页', 'source/plugin/it618_exam/wap/images/home.png', 'source/plugin/it618_exam/wap/images/curhome.png', '{waphome}','#2cb8ff',1),
(3, '搜索', 'source/plugin/it618_exam/wap/images/find.png', 'source/plugin/it618_exam/wap/images/curfind.png', '{wapsearch}','#2cb8ff',2),
(4, '购卷车', 'source/plugin/it618_exam/wap/images/gwc.png', 'source/plugin/it618_exam/wap/images/curgwc.png', '{wapgwc}','#2cb8ff',4),
(5, '我的', 'source/plugin/it618_exam/wap/images/uc.png', 'source/plugin/it618_exam/wap/images/curuc.png', '','#2cb8ff',5);

EOF;
$sql=str_replace("pre_it618_exam_bottomnav",DB::table('it618_exam_bottomnav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_qtype')." where id=5");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_exam_qtype` (`id`, `it618_typename`, `it618_order`) VALUES
(5, '主观题', 5);

EOF;
$sql=str_replace("pre_it618_exam_qtype",DB::table('it618_exam_qtype'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_set')." where setname='wapproductad1'");
if($count==0){
	C::t('#it618_exam#it618_exam_set')->insert(array(
		'setname' => 'wapproductad1'
	), true);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions')." where it618_qtypeid=3");
	while($it618_exam_questions = DB::fetch($query)) {
		$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." where it618_qid=".$it618_exam_questions['id']);
		while($it618_exam_questions_option = DB::fetch($query)) {
			$it618_name=strip_tags($it618_exam_questions_option['it618_name'],'');
			DB::query("update ".DB::table('it618_exam_questions_option')." set it618_name=$it618_name where id=".$it618_exam_questions_option['id']);
		}
	}
	
	DB::query("update ".DB::table('it618_exam_qtype')." set it618_typename='主观题' where id=5");
}

$tmpplugin = $_G['cache']['plugin'][$langpluginname];
if($tmpplugin['exam_credit']==''){
	echo '抱歉，请先在插件后台设置好积分类型！';exit;
}
//From: Dism·taobao·com
?>