<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsMembers,$IsCredits,$IsGroup,$IsUnion,$IsPinEdu,$IsChat,$IsWxMini,$RegName,$templatename,$templatename_wap,$templatename_admin,$template_set,$class_set;
$RegName=$_G['setting']['regname'];

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/templateset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_exam/config/templateset.php';
}

$templatename=$template_set['pcname'];
$templatename_wap=$template_set['wapname'];
$templatename_admin=$template_set['adminname'];

if($templatename=='')$templatename='default';
if($templatename_wap=='')$templatename_wap='default_wap';
if($templatename_admin=='')$templatename_admin='sc';

$it618_exam_pcstylename=getcookie('it618_exam_pcstylename');
if($it618_exam_pcstylename!=''){
	$templatename=$it618_exam_pcstylename;
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/plugins/image/it618.png')){
	$templatename_admin='sc';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/classset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_exam/config/classset.php';
}

$it618_members = $_G['cache']['plugin']['it618_members'];
if($it618_members['members_isok']==1){
	$IsMembers=1;
}

$it618_credits = $_G['cache']['plugin']['it618_credits'];
if($it618_credits['seotitle']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/plugins/autoheight/it618.png')){
	$IsCredits=1;
}

$it618_group = $_G['cache']['plugin']['it618_group'];
if($it618_group['pagecount']!=''){
	$IsGroup=1;
}

$it618_union = $_G['cache']['plugin']['it618_union'];
if($it618_union['seotitle']!=''){
	if($it618_union['seotitle']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/plugins/code/it618.png')){
		$IsUnion=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';
	}
}

$it618_pinedu = $_G['cache']['plugin']['it618_pinedu'];
if($it618_pinedu['pagecount']!=''){
	if($it618_pinedu['pagecount']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_pinedu/kindeditor/plugins/code/it618.png')){
		$IsPinEdu=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/lang.func.php';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php')){
	$IsChat=1;
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/lang.func.php';
}

$it618_wxmini = $_G['cache']['plugin']['it618_wxmini'];
if($it618_wxmini['pagecount']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_wxmini/kindeditor/plugins/autoheight/it618.png')){
	$IsWxMini=1;
}

$langpluginname='it618_exam';
if($_SERVER['HTTP_HOST']=='localhost'||strpos($_SERVER['HTTP_HOST'],'localhost'))$language = 'language.php';else$language = 'language.'.currentlang().'.php';
if(!file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language))$language = 'language.php';
require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language;$language_edit = 'language.'.currentlang().'_edit.php';
if(file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit)){
$lang_version=$it618_exam_lang['version'];	$lang_it618=$it618_exam_lang['it618'];	require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit;$it618_exam_lang['version']=$lang_version;$it618_exam_lang['it618']=$lang_it618;
}
//From: Dism��taobao��com
?>