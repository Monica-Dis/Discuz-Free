<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];
$jfname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

$type=intval($_GET['type']);
$cid=intval($_GET['cid']);

if($type==1){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order,id");
	while($it618_tmp1 =	DB::fetch($query1)) {
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order,id");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$query = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass'.$type)." WHERE it618_class2_id=".$it618_tmp2['id']." ORDER BY it618_order,id");
			while($it618_temp = DB::fetch($query)) {
				if($it618_temp['it618_parenttype']==1)$open='true';else $open='false';
				$classname=$it618_temp['it618_classname'];
				if($it618_temp['it618_color']!=''){
					$classname='<span style=\'color:'.$it618_temp['it618_color'].';margin-right:0px;\'>'.$classname.'</span>';
				}
				
				if($it618_temp['it618_parentclassid']==0){
					$pid='999999'.$it618_tmp2['id'];
				}else{
					$pid=$it618_temp['it618_parentclassid'];
				}
				
				$treestr.='{id: '.$it618_temp['id'].', pId: '.$pid.', name: "'.$classname.'",name1: "'.$it618_temp['it618_classname'].'", open: '.$open.', parenttype:'.$it618_temp['it618_parenttype'].'},';
			}
			
			$treestr.='{id: 999999'.$it618_tmp2['id'].', pId: 888888'.$it618_tmp1['id'].', name: "'.$it618_tmp2['it618_classname'].'",name1: "'.$it618_tmp2['it618_classname'].'", open: false, parenttype:999999'.'},';
		}
		
		$treestr.='{id: 888888'.$it618_tmp1['id'].', pId: 0, name: "'.$it618_tmp1['it618_classname'].'",name1: "'.$it618_tmp1['it618_classname'].'", open: false, parenttype:888888'.'},';
	}
}

if($type==2){
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass'.$type)." ORDER BY it618_order,id");
	while($it618_temp = DB::fetch($query)) {
		if($it618_temp['it618_parenttype']==1)$open='true';else $open='false';
		$classname=$it618_temp['it618_classname'];
		if($it618_temp['it618_color']!=''){
			$classname='<span style=\'color:'.$it618_temp['it618_color'].';margin-right:0px;\'>'.$classname.'</span>';
		}
		$treestr.='{id: '.$it618_temp['id'].', pId: '.$it618_temp['it618_parentclassid'].', name: "'.$classname.'",name1: "'.$it618_temp['it618_classname'].'", open: '.$open.', parenttype:'.$it618_temp['it618_parenttype'].'},';
	}
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:classtree');
?>