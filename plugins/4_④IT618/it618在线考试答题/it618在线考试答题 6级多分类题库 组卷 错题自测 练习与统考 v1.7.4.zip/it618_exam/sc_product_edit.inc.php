<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$pid=intval($_GET['pid']);
$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);

if(submitcheck('it618submit')){
	for($i=0;$i<=0;$i++){
		if($i==0)$tmpi='';else $tmpi=$i;
		$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
		
		if($it618_exam_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
			$tmparr=explode("source",$it618_exam_goods['it618_picbig'.$tmpi]);
			$tmparr1=explode("://",$it618_exam_goods['it618_picbig'.$tmpi]);
			$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_picbig)&&count($tmparr1)==1){
				$result=unlink($it618_picbig);
			}
		}
		
		$file_ext=strtolower(substr($it618_exam_goods['it618_picbig'.$tmpi],strrpos($it618_exam_goods['it618_picbig'.$tmpi], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		
		if($it618_exam_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$ShopId.'/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;
			it618_exam_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,385,1);
		}

	}
	
	C::t('#it618_exam#it618_exam_goods')->update($pid,array(
		'it618_shopuid' => $ShopUid,
		'it618_class1_id' => $_GET['it618_class1_id'],
		'it618_class2_id' => $_GET['it618_class2_id'],
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_description' => dhtmlspecialchars($_GET['it618_description']),
		'it618_seokeywords' => dhtmlspecialchars($_GET['it618_seokeywords']),
		'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription']),
		'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	));
	
	if($class_set['classname_e3_ishide']!=1){
		C::t('#it618_exam#it618_exam_goods')->update($pid,array(
			'it618_class3_id' => $_GET['it618_class3_id']
		));
	}
	
	if($class_set['classname_e4_ishide']!=1){
		C::t('#it618_exam#it618_exam_goods')->update($pid,array(
			'it618_class4_id' => $_GET['it618_class4_id']
		));
	}
	
	if($it618_exam_goods['it618_issecret']==1){
		$tmparr=explode(",",$_GET['it618_secretusers']);
		for($i=0;$i<count($tmparr);$i++){
			$count=C::t('#it618_exam#it618_exam_sale')->count_by_uid($tmparr[$i]);
			if($count>0){
				$tmpstr.=$tmparr[$i].',';
			}
		}
		if($tmpstr!='')$tmpstr.='@';
		$tmpstr=str_replace(',@','',$tmpstr);
	
		C::t('#it618_exam#it618_exam_goods')->update($pid,array(
			'it618_secretusers' => $tmpstr
		));
	}
	
	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_exam:sc_product_edit&pid=$pid&preurl=".$_GET['preurl']);
showtableheaders(it618_exam_getlang('s409'),'it618_exam_goods');

$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$classtmp1=str_replace('<option value='.$it618_exam_goods['it618_class1_id'].'>','<option value='.$it618_exam_goods['it618_class1_id'].' selected="selected">',$classtmp1);

if($class_set['classname_e3_ishide']!=1){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class3')." ORDER BY it618_order");
	while($it618_tmp = DB::fetch($query1)) {
		$classtmp3.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$classtmp3=str_replace('<option value='.$it618_exam_goods['it618_class3_id'].'>','<option value='.$it618_exam_goods['it618_class3_id'].' selected="selected">',$classtmp3);
	$e3str1='<select id="it618_class3_id"  name="it618_class3_id"><option value="0">'.it618_exam_getlang('s375').$class_set['classname_e3'].'</option>'.$classtmp3.'</select>';
	$e3str2='if(document.getElementById("it618_class3_id").value=="0"){
			alert("'.it618_exam_getlang('s361').'");
			return false;
		}';
}

if($class_set['classname_e4_ishide']!=1){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class4')." ORDER BY it618_order");
	while($it618_tmp = DB::fetch($query1)) {
		$classtmp4.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$classtmp4=str_replace('<option value='.$it618_exam_goods['it618_class4_id'].'>','<option value='.$it618_exam_goods['it618_class4_id'].' selected="selected">',$classtmp4);
	$e4str1='<select id="it618_class4_id"  name="it618_class4_id"><option value="0">'.it618_exam_getlang('s375').$class_set['classname_e4'].'</option>'.$classtmp4.'</select>';
	$e4str2='if(document.getElementById("it618_class4_id").value=="0"){
			alert("'.it618_exam_getlang('s361').'");
			return false;
		}';
}

if($it618_exam_goods['it618_paytype']==1)$it618_paytype1='selected="selected"';else $it618_paytype1="";
if($it618_exam_goods['it618_paytype']==2)$it618_paytype2='selected="selected"';else $it618_paytype2="";
if($it618_exam_goods['it618_paytype']==3)$it618_paytype3='selected="selected"';else $it618_paytype3="";

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

$indextmp=1;
$index=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_exam_class2')." where it618_class1_id=".$it618_exam_goods['it618_class1_id']." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query)) {
	if($it618_tmp['id']==$it618_exam_goods['it618_class2_id']){
		$index=$indextmp;
	}
	$indextmp+=1;
}
$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex,0);redirec_class_sel('it618_class2_id',".$index.");";

$it618_exam_goods['it618_tbts']=str_replace('[br]','<br />',$it618_exam_goods['it618_tbts']);

if($it618_exam_goods['it618_picbig']!='')$src='src="'.$it618_exam_goods['it618_picbig'].'"';

if($it618_exam_goods['it618_issecret']==1){
	$secretusersstr='';
	$tmparr=explode(",",$it618_exam_goods['it618_secretusers']);
	for($i=0;$i<count($tmparr);$i++){
		$username=C::t('#it618_exam#it618_exam_sale')->fetch_username_by_uid($tmparr[$i]);
		$secretusersstr.=$username.' , ';
	}
	if($secretusersstr!='')$secretusersstr.='@';
	$secretusersstr=str_replace(' , @','',$secretusersstr);
	if($secretusersstr!=''){
		$secretusersstr='<tr><td></td><td style="color:green">'.$secretusersstr.'</td></tr>';	
	}
	
	$it618_issecret='<tr><td>'.it618_exam_getlang('s1178').'</td><td><textarea name="it618_secretusers" style="width:776px;height:190px;margin-bottom:3px">'.$it618_exam_goods['it618_secretusers'].'</textarea><br><font color=red>'.it618_exam_getlang('s1179').'</font></td></tr>
	'.$secretusersstr.'
	';
}

if($it618_exam_goods['it618_isuser']==1)$it618_isuser_checked='checked="checked"';else $it618_isuser_checked="";
if($it618_exam_goods['it618_isip']==1)$it618_isip_checked='checked="checked"';else $it618_isip_checked="";
if($it618_exam_goods['it618_isaddr']==1)$it618_isaddr_checked='checked="checked"';else $it618_isaddr_checked="";

echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/plugins/code/prettify.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/js/Calendar.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	function checkvalue(){
		if(document.getElementById("it618_class2_id").value=="0"){
			alert("'.it618_exam_getlang('s361').'");
			return false;
		}
		'.$e3str2.'
		'.$e4str2.'
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_exam_getlang('s362').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_exam_getlang('s372').'");
			return false;
		}
	}
	
	function delpic(i){
		document.getElementById("url1"+i).value="";
		document.getElementById("img1"+i).src="";
	}
	
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x,n)
	{
	 if(n==0)n="";
	 var temp = document.getElementById("it618_class2_id"+n); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	
	function setpaytype(objvalue){
		document.getElementById("it618_jfprice").style.display="none"; 
		
		if(objvalue==1){ 
			document.getElementById("it618_jfprice").style.display=""; 
		}
	}
</script>

<tr><td width=80>'.it618_exam_getlang('s374').'</td><td>
<select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex,0)"><option value="0">'.it618_exam_getlang('s375').$class_set['classname_e1'].'</option>'.$classtmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_exam_getlang('s375').$class_set['classname_e2'].'</option></select> 
'.$e3str1.'
'.$e4str1.'
</td></tr>
<tr><td>'.it618_exam_getlang('s839').'</td><td><input type="text" class="txt" style="width:776px;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_exam_goods['it618_name'].'"> </td></tr>
<tr><td>'.it618_exam_getlang('s394').'</td><td><img id="img1" '.$src.' width="100" height="60" align="absmiddle"/> <input type="text" id="url1" name="it618_picbig" value="'.$it618_exam_goods['it618_picbig'].'" readonly="readonly"/> <input type="button" id="image1" value="'.it618_exam_getlang('s395').'" /></td></tr>
<tr><td>'.it618_exam_getlang('s567').'</td><td><textarea name="it618_description" style="width:776px;height:60px;">'.$it618_exam_goods['it618_description'].'</textarea></td></tr>
<tr><td>'.it618_exam_getlang('s404').'</td><td><textarea name="it618_message" style="width:780px;height:400px;visibility:hidden;">'.$it618_exam_goods['it618_message'].'</textarea></td></tr>
'.$it618_issecret.'
<tr><td>'.it618_exam_getlang('s405').'</td><td><input type="text" class="txt" style="width:776px;margin-right:0" name="it618_seokeywords" value="'.$it618_exam_goods['it618_seokeywords'].'"></td></tr>
<tr><td>'.it618_exam_getlang('s406').'</td><td><textarea name="it618_seodescription" style="width:776px;height:60px;">'.$it618_exam_goods['it618_seodescription'].'</textarea></td></tr>
';

echo '<tr><td colspan=15><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_exam_getlang('s1478').'" /> </div></td></tr><script>'.$jstmp.'</script>';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>