<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];
$metakeywords = $it618_exam['seokeywords'];
$metadescription = $it618_exam['seodescription'];
$sitetitle=$it618_exam['seotitle'];

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

$waphome=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
$wapsearch=it618_exam_getrewrite('exam_wap','search@0','plugin.php?id=it618_exam:wap&pagetype=search&cid=0');
$wapu=it618_exam_getrewrite('exam_wap','u@'.$_G['uid'],'plugin.php?id=it618_exam:wap&pagetype=u');

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_exam#it618_exam_wapstyle')->count_by_isok_search();
$it618_exam_wapstyle=C::t('#it618_exam#it618_exam_wapstyle')->fetch_by_isok_search();

if(isset($_GET['pagetype'])){
	$pagetypearray = array('exam', 'teacher', 'product', 'pin', 'testabout', 'test', 'utestabout', 'utest', 'sc', 'sc_test', 'sc_subscribe', 'sc_gwc', 'uc', 'subscribe', 'search', 'gwcsale', 'u');
	$pagetype = !in_array($_GET['pagetype'], $pagetypearray) ? 'exam' : $_GET['pagetype'];
}else{
	$pagetype='exam';
	$navtitle=$sitetitle;
}

if($it618_exam['exam_style']>2){
	$examstyle=getcookie('examstyle');
	if($examstyle==''){
		if($it618_exam['exam_style']==3)$examstyle='1';else $examstyle='2';
	}

	if($pagetype=='exam'||$pagetype=='search'||$pagetype=='teacher'){
		if($examstyle=='1')$examstyle1='2';else $examstyle1='1';
		$examstylestrtmp='<div class="style-btn" onClick="examstyle()"><i class="icon-style'.$examstyle1.'"></i></div>';
	}
}else{
	if($it618_exam['exam_style']==1)$examstyle='1';else $examstyle='2';
}

$ucbottomtitle=$it618_video_lang['s1560'];
$gwcpcount=0;
$gwcurl=it618_exam_getrewrite('exam_wap','gwcsale@'.$_G['uid'],'plugin.php?id=it618_exam:wap&pagetype=gwcsale');
if($_G['uid']>0){
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_exam_getlang('s460').'</a></li>';
	$strusr='<a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="btn btn-weak">'.it618_exam_getlang('s460').'</a> <a href="'.it618_exam_rewriteurl($_G['uid']).'" target="_blank">'.it618_exam_getusername($_G['uid']).'</a>';
	
	$gwcpcount=C::t('#it618_exam#it618_exam_gwc')->count_by_uid($_G['uid']);
	$ucbottomtitle=$it618_exam_lang['s832'];
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_exam_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_exam_bottomnav = DB::fetch($query)) {	
	$it618_url=$it618_exam_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$tmpurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
	$it618_url=str_replace("{waphome}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='index'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapsearch}",$it618_url);
	$tmpurl=it618_exam_getrewrite('exam_wap','search@0','plugin.php?id=it618_exam:wap&pagetype=search&cid=0');
	$it618_url=str_replace("{wapsearch}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='search'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapgwc}",$it618_url);
	$tmpurl=it618_exam_getrewrite('exam_wap','gwcsale@'.$_G['uid'],'plugin.php?id=it618_exam:wap&pagetype=gwcsale');
	$it618_url=str_replace("{wapgwc}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='gwcsale'){
			$iscur=1;
		}
	}
	
	if($it618_exam_bottomnav['id']==5)$it618_url=it618_exam_getrewrite('exam_wap','u@'.$_G['uid'],'plugin.php?id=it618_exam:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_exam_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_exam_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_exam_bottomnav['it618_color'].'">'.$it618_exam_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_exam_bottomnav['it618_img'];
		$it618_title=$it618_exam_bottomnav['it618_title'];
	}
	
	if($it618_exam_bottomnav['id']==5&&$_G['uid']==0){
		$it618_title=$it618_exam_lang['s1560'];
	}
	
	if($it618_exam_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_exam_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$wap=1;

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_exam['exam_appid']);
	$wx_secret=trim($it618_exam['exam_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){
	if($pagetype=='teacher'){
		$lid=intval($_GET['cid']);
		$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($lid);
		$wxshare_title=$it618_exam_shop['it618_name'];
		$wxshare_imgUrl=$it618_exam_shop['it618_logo'];
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_exam_shop['it618_about'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_exam_getrewrite('exam_wap','teacher@'.$lid,'plugin.php?id=it618_exam:wap&pagetype=teacher&cid='.$lid);
		
	}elseif($pagetype=='product'){
		$pid=intval($_GET['cid']);
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);
		$wxshare_title=$it618_exam_goods['it618_name'];
		$wxshare_imgUrl=it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_exam_goods['it618_description'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		if($_GET['e']!=''){
			$wxshare_link=$_G['siteurl'].it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id'].'&e='.$_GET['e'],'?e='.$_GET['e']);
		}else{
			$wxshare_link=$_G['siteurl'].it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
		}
		
	}else{
		$wxshare_title=$it618_exam['seotitle'];
		
		if($it618_exam['exam_wxlogo']!=''){
			$wxshare_imgUrl=$it618_exam['exam_wxlogo'];
		}else{
			$wxshare_imgUrl=$it618_exam['exam_logo'];
			$tmparr=explode('src="',$wxshare_imgUrl);
			$tmparr1=explode('"',$tmparr[1]);
			$wxshare_imgUrl=$tmparr1[0];
		}
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_exam['seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_exam/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
	}
}

$wapbottomsubnav=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('wapbottomsubnavdefault');
$footer_mall_wap=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('footer_mall_wap');

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
	if($appurl=it618_members_apploginok($_GET['token'])){
		dheader("location:$appurl");
	}
}

$searchurl=it618_exam_getrewrite('exam_wap','search@0','plugin.php?id=it618_exam:wap&pagetype=search&cid=0&findkey=1','?findkey=1');

if($pagetype=='exam'||$pagetype=='product'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/appad.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_exam/config/appad.php';
	}
	
	if($appad_browseragent!=''){
		$browseragent=explode(",",$appad_browseragent);
		for($i=0;$i<count($browseragent);$i++){
			if(strpos($_SERVER['HTTP_USER_AGENT'],$browseragent[$i])!==false){
				$appad_ishome=0;
				$appad_isproduct=0;
				break;
			}
		}
	}
	
	$it618_exam_appad=getcookie('it618_exam_appad');
	if($it618_exam_appad!=''){
		$appad_isproduct=0;
	}
}

if($pagetype=='testabout'||$pagetype=='test'){
	$footercss='display:none;';
}else{
	if($pagetype=='product')$footercss='margin-bottom:80px;';else $footercss='margin-bottom:60px;';
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_wapad=it618_group_getad($_GET['id'],1);
}

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/wap/'.$pagetype.'.inc.php';
?>