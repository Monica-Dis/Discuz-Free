<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$oss;

$it618_exam = $_G['cache']['plugin']['it618_exam'];

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

if($_G['uid']<=0){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		if(!exam_is_mobile()){ 
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
			$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','','winapilogin');
			echo '<script type="text/javascript" src="source/plugin/it618_exam/js/jquery.js"></script>'.$it618_members_index;exit;
		}
	}
	
	dheader("location:member.php?mod=logging&action=login");
}else{
	global $oss;
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/php/aliyunossconfig.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/php/aliyunossconfig.php';
		if($it618_isok==1){
			$oss='&oss';
		}
	}
	
	$username=C::t('#it618_exam#it618_exam_sale')->fetch_username_by_uid($_G['uid']);
	if($it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($_G['uid'])){
			
		$it618_state=$it618_exam_shop['it618_state'];
		if($it618_state==0){
			echo it618_exam_getlang('s334');exit;
		}elseif($it618_state==1){
			echo it618_exam_getlang('s335');exit;
		}else{
			$it618_htstate=$it618_exam_shop['it618_htstate'];
			if($it618_htstate==0){
				echo it618_exam_getlang('s336');exit;
			}elseif($it618_htstate==2){
				echo it618_exam_getlang('s337');exit;
			}else{
				$ShopId=$it618_exam_shop['id'];
				$ShopUid=$it618_exam_shop['it618_uid'];
				$ShopName=$it618_exam_shop['it618_name'];
				$Shopischeck_live=$it618_exam_shop['it618_ischeck_live'];
				
				$urltmp='member.php?mod=logging&action=logout&formhash='.FORMHASH;
				$username=$_G['username'];
				$u_avatarimg=it618_exam_discuz_uc_avatar($_G['uid'],'middle');
				$teacherurl=it618_exam_getrewrite('exam_teacher',$ShopId,'plugin.php?id=it618_exam:teacher&lid='.$ShopId);
			}
		}
		
	}else{
		echo it618_exam_getlang('s338');exit;
	}
}
//From: Dism��taobao��com
?>