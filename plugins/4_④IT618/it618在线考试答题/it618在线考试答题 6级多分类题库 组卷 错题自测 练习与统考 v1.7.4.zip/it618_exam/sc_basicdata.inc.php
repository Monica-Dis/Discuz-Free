<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($ShopId);
if(submitcheck('it618submit')){
	
	if($it618_exam_goods['it618_logo']!=$_GET['it618_logo']){
		$tmparr=explode("source",$it618_exam_goods['it618_logo']);
		$tmparr1=explode("://",$it618_exam_goods['it618_logo']);
		$it618_logo=DISCUZ_ROOT.'./source'.$tmparr[1];
		
		if(file_exists($it618_logo)&&count($tmparr1)==1){
			$result=unlink($it618_logo);
		}
	}
	
	if($it618_exam_goods['it618_ulogo']!=$_GET['it618_ulogo']){
		$tmparr=explode("source",$it618_exam_goods['it618_ulogo']);
		$tmparr1=explode("://",$it618_exam_goods['it618_ulogo']);
		$it618_ulogo=DISCUZ_ROOT.'./source'.$tmparr[1];
		
		if(file_exists($it618_ulogo)&&count($tmparr1)==1){
			$result=unlink($it618_ulogo);
		}
	}
	
	C::t('#it618_exam#it618_exam_shop')->update($ShopId,array(
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_tel' => dhtmlspecialchars($_GET['it618_tel']),
		'it618_qq' => dhtmlspecialchars($_GET['it618_qq']),
		'it618_dianhua' => dhtmlspecialchars($_GET['it618_dianhua']),
		'it618_ulogo' => dhtmlspecialchars($_GET['it618_ulogo']),
		'it618_logo' => dhtmlspecialchars($_GET['it618_logo']),
		'it618_waplogo' => dhtmlspecialchars($_GET['it618_waplogo']),
		'it618_logourl' => dhtmlspecialchars($_GET['it618_logourl']),
		'it618_waplogourl' => dhtmlspecialchars($_GET['it618_waplogourl']),
		'it618_tongji' => $_GET['it618_tongji'],
		'it618_about' => dhtmlspecialchars($_GET['it618_about']),
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	));
	
	if($IsChat!=1){
		C::t('#it618_tuan#it618_exam_shop')->update($ShopId,array(
			'it618_yytime' => dhtmlspecialchars($_GET['it618_yytime']),
			'it618_kefuqq' => dhtmlspecialchars($_GET['it618_kefuqq']),
			'it618_kefuqqname' => dhtmlspecialchars($_GET['it618_kefuqqname'])
		));
	}

	it618_cpmsg(it618_exam_getlang('s309'), "plugin.php?id=it618_exam:sc_basicdata", 'succeed');
}

it618_showformheader("plugin.php?id=it618_exam:sc_basicdata");
showtableheaders(it618_exam_getlang('s310'),'it618_exam_basicdata');
	
echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=640'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true
		});
		KindEditor.ready(function(K) {
			var editor1 = K.create(\'textarea[name="it618_message"]\', {
				cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
				uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=900'.$oss.'\',
				fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
				allowFileManager : true,
				filterMode:false
			});
		});
		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
		K(\'#image2\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url2\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url2\').val(url);
						K(\'#img2\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
		K(\'#image3\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url3\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url3\').val(url);
						K(\'#img3\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
	});

	function checkvalue(){
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_exam_getlang('s311').'");
			return false;
		}
		if(document.getElementById("it618_tel").value==""){
			alert("'.it618_exam_getlang('s312').'");
			return false;
		}
		if(document.getElementById("it618_qq").value==""){
			alert("'.it618_exam_getlang('s313').'");
			return false;
		}
		if(document.getElementById("it618_about").value==""){
			alert("'.it618_exam_getlang('s314').'");
			return false;
		}
	}
</script>

<tr><td width=90>'.it618_exam_getlang('s317').'</td><td><img id="img1" src="'.$it618_exam_shop['it618_ulogo'].'" width="80" align="absmiddle"/><input type="text" id="url1" name="it618_ulogo" readonly="readonly" value="'.$it618_exam_shop['it618_ulogo'].'"/> <input type="button" id="image1" value="'.it618_exam_getlang('s318').'" /></td></tr>
<tr><td>'.it618_exam_getlang('s1639').'</td><td><img id="img2" src="'.$it618_exam_shop['it618_logo'].'" width="150" align="absmiddle"/> <input type="text" id="url2" name="it618_logo" readonly="readonly" value="'.$it618_exam_shop['it618_logo'].'"/> <input type="button" id="image2" value="'.it618_exam_getlang('s318').'" /> '.it618_exam_getlang('s1643').'</td></tr>
<tr><td>'.it618_exam_getlang('s1640').'</td><td><input type="text" class="txt" style="width:400px" name="it618_logourl" value="'.$it618_exam_shop['it618_logourl'].'"></td></tr>
<tr><td>'.it618_exam_getlang('s1641').'</td><td><img id="img3" src="'.$it618_exam_shop['it618_waplogo'].'" width="150" align="absmiddle"/><input type="text" id="url3" name="it618_waplogo" readonly="readonly" value="'.$it618_exam_shop['it618_waplogo'].'"/> <input type="button" id="image3" value="'.it618_exam_getlang('s318').'" /> '.it618_exam_getlang('s1644').'</td></tr>
<tr><td>'.it618_exam_getlang('s1642').'</td><td><input type="text" class="txt" style="width:400px" name="it618_waplogourl" value="'.$it618_exam_shop['it618_waplogourl'].'"></td></tr>
<tr><td>'.it618_exam_getlang('s320').'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name" value="'.$it618_exam_shop['it618_name'].'">'.it618_exam_getlang('s316').' <font color="red">'.it618_exam_getlang('s321').'</font></td></tr>
<tr><td><font color="red">'.it618_exam_getlang('s322').'</font></td><td><input type="text" class="txt" style="width:252px" id="it618_tel" name="it618_tel" value="'.$it618_exam_shop['it618_tel'].'"><font color="red">'.it618_exam_getlang('s324').'</font><input type="text" class="txt" style="width:100px" id="it618_qq" name="it618_qq" value="'.$it618_exam_shop['it618_qq'].'">'.it618_exam_getlang('s323').'<font color="red"> '.it618_exam_getlang('s321').' '.it618_exam_getlang('s325').'</font></td></tr>
<tr><td>'.it618_exam_getlang('s327').'</td><td><input type="text" class="txt" style="width:400px" name="it618_dianhua" value="'.$it618_exam_shop['it618_dianhua'].'">'.it618_exam_getlang('s316').'</td></tr>';

if($IsChat!=1){
echo '<tr><td>'.it618_exam_getlang('s328').'</td><td><input type="text" class="txt" style="width:400px" name="it618_kefuqq" value="'.$it618_exam_shop['it618_kefuqq'].'">'.it618_exam_getlang('s316').' <font color="red">'.it618_exam_getlang('s859').'</font></td></tr>
<tr><td>'.it618_exam_getlang('s860').'</td><td><input type="text" class="txt" style="width:400px" name="it618_kefuqqname" value="'.$it618_exam_shop['it618_kefuqqname'].'">'.it618_exam_getlang('s316').' <font color="red">'.it618_exam_getlang('s861').'</font></td></tr>
<tr><td>'.it618_exam_getlang('s329').'</td><td><input type="text" class="txt" style="width:400px" name="it618_yytime" value="'.$it618_exam_shop['it618_yytime'].'">'.it618_exam_getlang('s316').'</td></tr>';
}

echo '<tr><td>'.it618_exam_getlang('s1411').'</td><td><textarea class="txt" style="width:400px;height:80px" name="it618_tongji">'.$it618_exam_shop['it618_tongji'].'</textarea>'.it618_exam_getlang('s1412').'</td></tr>
<tr><td>'.it618_exam_getlang('s331').'</td><td><textarea class="txt" style="width:400px;height:80px" name="it618_about">'.$it618_exam_shop['it618_about'].'</textarea>'.it618_exam_getlang('s316').' '.it618_exam_getlang('s332').'</td></tr>
<tr><td>'.it618_exam_getlang('s767').'</td><td><textarea name="it618_message" style="width:670px;height:390px;visibility:hidden;">'.$it618_exam_shop['it618_message'].'</textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_exam_getlang('s23').'" /></div></td></tr>';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>