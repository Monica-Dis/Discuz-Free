<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return; /*Dism_taobao-com*/

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function/it618_exam.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier']; /*dism- taobao- com*/
$urls = '&pmod=admin_class&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_class1', 'admin_class2', 'admin_class_e3', 'admin_class_e4', 'admin_class_q1', 'admin_class_q2', 'admin_class_q3', 'admin_class_q4', 'admin_classvipgroup');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_class1' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$e3css=';display:none';
if($class_set['classname_e3_ishide']!=1){
	$e3css=';display:';
}

$e4css=';display:none';
if($class_set['classname_e4_ishide']!=1){
	$e4css=';display:';
}

$q2css=';display:none';
if($class_set['classname_q2_ishide']!=1){
	$q2css=';display:';
}

$q3css=';display:none';
if($class_set['classname_q3_ishide']!=1){
	$q3css=';display:';
}

$q4css=';display:none';
if($class_set['classname_q4_ishide']!=1){
	$q4css=';display:';
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].' '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_class1'.$urls.'"><span>'.$class_set['classname_e1'].$it618_exam_lang['s12'].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_class2'.$urls.'"><span>'.$class_set['classname_e2'].$it618_exam_lang['s12'].'</span></a></li>
<li '.$strtmp[2].' style="'.$e3css.'"><a href="'.$hosturl.'plugins&cp=admin_class_e3'.$urls.'"><span>'.$class_set['classname_e3'].$it618_exam_lang['s12'].'</span></a></li>
<li '.$strtmp[3].' style="'.$e4css.'"><a href="'.$hosturl.'plugins&cp=admin_class_e4'.$urls.'"><span>'.$class_set['classname_e4'].$it618_exam_lang['s12'].'</span></a></li>
<li><span> | </span></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_class_q1'.$urls.'"><span>'.$class_set['classname_q1'].$it618_exam_lang['s12'].'</span></a></li>
<li '.$strtmp[5].' style="'.$q2css.'"><a href="'.$hosturl.'plugins&cp=admin_class_q2'.$urls.'"><span>'.$class_set['classname_q2'].$it618_exam_lang['s12'].'</span></a></li>
<li '.$strtmp[6].' style="'.$q3css.'"><a href="'.$hosturl.'plugins&cp=admin_class_q3'.$urls.'"><span>'.$class_set['classname_q3'].$it618_exam_lang['s12'].'</span></a></li>
<li '.$strtmp[7].' style="'.$q4css.'"><a href="'.$hosturl.'plugins&cp=admin_class_q4'.$urls.'"><span>'.$class_set['classname_q4'].$it618_exam_lang['s12'].'</span></a></li>
</ul></div>';

$tmparr=explode("_",$cp);
if(count($tmparr)>2){
	$type=$tmparr[2];
	$cp1=$cp;
	if($type=='e3'||$type=='e4'||$type=='q3'||$type=='q4'){
		$cp='admin_class';
	}else{
		if($type=='q1')$cp='admin_classtree1';
		if($type=='q2')$cp='admin_classtree2';
	}
	$title=$class_set['classname_'.$type].$it618_exam_lang['s12'];
}

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism��taobao��com*/
?>