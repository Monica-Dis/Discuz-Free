<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

if($reabc[4]!='8')return; /*Dism_taobao-com*/

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function/it618_exam.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier']; /*dism- taobao- com*/
$urls = '&pmod=admin_style&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=0;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<=32;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/templateset.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_exam/templateset.php';
}

$strtmptitle[0]=$it618_exam_lang['s1007'];
$strtmptitle[1]=$it618_exam_lang['s961'];

$strtmptitle[2]=$it618_exam_lang['s3'];
$strtmptitle[3]=$it618_exam_lang['s4'];
$strtmptitle[4]=$it618_exam_lang['s5'];
$strtmptitle[5]=$it618_exam_lang['s6'];
$strtmptitle[6]=$it618_exam_lang['s7'];
$strtmptitle[7]=$it618_exam_lang['s911'];
$strtmptitle[8]=$it618_exam_lang['s2'];
$strtmptitle[9]=$it618_exam_lang['s2'];
$strtmptitle[10]=$it618_exam_lang['s559'];
$strtmptitle[14]=$it618_exam_lang['s727'];
$strtmptitle[16]=$it618_exam_lang['s727'];
$strtmptitle[17]=$it618_exam_lang['s872'];
$strtmptitle[18]=$it618_exam_lang['s872'];
$strtmptitle[19]=$it618_exam_lang['s961'];
$strtmptitle[20]=$it618_exam_lang['s962'];
$strtmptitle[21]=$it618_exam_lang['s963'];
$strtmptitle[22]=$it618_exam_lang['s1101'];
$strtmptitle[26]=$it618_exam_lang['s769'];
$strtmptitle[28]=$it618_exam_lang['s1409'];

$menustr.='<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_template&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>';

if($templatename=='default'){
	$menustr.='
	<li '.$strtmp[10].'><a href="'.$hosturl.'plugins&cp=admin_hot&cp1=10'.$urls.'"><span>'.$strtmptitle[10].'</span></a></li>
	<li '.$strtmp[14].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=14'.$urls.'"><span>'.$strtmptitle[14].'</span></a></li>
	<li '.$strtmp[9].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=9'.$urls.'"><span>'.$strtmptitle[9].'</span></a></li>
	<li '.$strtmp[18].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=18'.$urls.'"><span>'.$strtmptitle[18].'</span></a></li>
	<li '.$strtmp[19].'><a href="'.$hosturl.'plugins&cp=admin_style&cp1=19'.$urls.'"><span>'.$strtmptitle[19].'</span></a></li>
	';
}

if($templatename_wap=='default_wap'){
	$menustr.='
	<li '.$strtmp[20].'><a href="'.$hosturl.'plugins&cp=admin_wapstyle&cp1=20'.$urls.'"><span>'.$strtmptitle[20].'</span></a></li>
	<li '.$strtmp[21].'><a href="'.$hosturl.'plugins&cp=admin_iconav&cp1=21'.$urls.'"><span>'.$strtmptitle[21].'</span></a></li>
	<li '.$strtmp[22].'><a href="'.$hosturl.'plugins&cp=admin_bottomnav&cp1=22'.$urls.'"><span>'.$strtmptitle[22].'</span></a></li>
	<li '.$strtmp[26].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=26'.$urls.'"><span>'.$strtmptitle[26].'</span></a></li>
	<li '.$strtmp[28].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=28'.$urls.'"><span>'.$strtmptitle[28].'</span></a></li>
	';
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
'.$menustr.'
</ul></div>';

$cparray = array('admin_template', 'admin_hot', 'admin_set', 'admin_style', 'admin_nav', 'admin_focus', 'admin_wapstyle', 'admin_iconav', 'admin_bottomnav');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_template' : $_GET['cp'];

if($cp1==0)$setname='hotclassgoods';
if($cp1==14)$setname='topnav';
if($cp1==9)$setname='footer';
if($cp1==28)$setname='footer_wap';

$pmod='admin_style';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism��taobao��com*/
?>