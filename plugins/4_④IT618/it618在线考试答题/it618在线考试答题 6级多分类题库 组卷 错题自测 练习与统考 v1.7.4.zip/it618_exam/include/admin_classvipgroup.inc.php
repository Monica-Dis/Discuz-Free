<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

$cid=intval($_GET['cid']);
$it618_exam_class1 = C::t('#it618_exam#it618_exam_class1')->fetch_by_id($cid);

if(submitcheck('it618submit')){

	if(is_array($_GET['it618_groupid'])) {
		foreach($_GET['it618_groupid'] as $id => $val) {
			
				C::t('#it618_exam#it618_exam_class_vipgroup')->update($id,array(
					'it618_isok' => $_GET['it618_isok'][$id],
				));
		}
	}

	cpmsg($it618_exam_lang['s1850'], "action=plugins&identifier=$identifier&cp=admin_classvipgroup&pmod=admin_class&cid=$cid&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618daosubmit')) {
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_class_vipgroup')." WHERE it618_groupid=".$common_usergroup[groupid])==0){
			C::t('#it618_exam#it618_exam_class_vipgroup')->insert(array(
				'it618_class1_id' => $cid,
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}
	
	cpmsg($it618_exam_lang['s1849'], "action=plugins&identifier=$identifier&cp=admin_classvipgroup&pmod=admin_class&cid=$cid&operation=$operation&do=$do&page=$page", 'succeed');
}

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_class_vipgroup')." where it618_class1_id=$cid")==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_class_vipgroup')." WHERE it618_class1_id=$cid and it618_groupid=".$common_usergroup[groupid])==0){
			C::t('#it618_exam#it618_exam_class_vipgroup')->insert(array(
				'it618_class1_id' => $cid,
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}	
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_classvipgroup&pmod=admin_class&cid=$cid&operation=$operation&do=$do");

showtableheaders('<font color="red">'.$it618_exam_class1['it618_classname'].'</font> '.$it618_exam_lang['s1844'],'it618_exam_class_vipgroup');
	showsubmit('it618daosubmit', $it618_exam_lang['s1846']);
	if($reabc[5]!='_')return;
	
	$groupcount=C::t('#it618_exam#it618_exam_class_vipgroup')->count_by_it618_class1_id($cid);
	
	echo '<tr><td colspan=10>'.$it618_exam_lang['s1847'].$groupcount.'<span style="float:right;color:red">'.$it618_exam_lang['s1848'].'</span></td></tr>';
	
	showsubtitle(array($it618_exam_lang['s1845']));
	
	echo '<tr><td colspan=10><ul>';
	$query = DB::query("SELECT p.id,g.groupid,g.grouptitle,p.* FROM ".DB::table('it618_exam_class_vipgroup')." p,".DB::table('common_usergroup')." g WHERE p.it618_groupid=g.groupid and p.it618_class1_id=$cid");
	while($it618_exam_class_vipgroup =	DB::fetch($query)) {
		
		if($it618_exam_class_vipgroup['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		echo '<li style="float:left;width:230px"><input type="hidden" name="it618_groupid['.$it618_exam_class_vipgroup['id'].']"><input type="checkbox" id="isok'.$it618_exam_class_vipgroup['id'].'" name="it618_isok['.$it618_exam_class_vipgroup['id'].']" style="vertical-align:middle" value="1" '.$it618_isok_checked.'><label for="isok'.$it618_exam_class_vipgroup['id'].'">'.$it618_exam_class_vipgroup['grouptitle'].'</label></li>';
	}
	echo '</ul></td></tr>';
	
	showsubmit('it618submit', $it618_exam_lang['s592']);
	showtablefooter(); /*dism��taobao��com*/
?>