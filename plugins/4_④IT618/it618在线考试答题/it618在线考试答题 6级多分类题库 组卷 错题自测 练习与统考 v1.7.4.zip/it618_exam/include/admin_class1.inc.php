<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_exam_class1', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_exam#it618_exam_class1')->update($id,array(
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_pj' => trim($_GET['it618_pj'][$id]),
				'it618_goodscount' => trim($_GET['it618_goodscount'][$id]),
				'it618_wapgoodscount' => trim($_GET['it618_wapgoodscount'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_classname_array as $key => $value) {
		$newit618_classname = addslashes(trim($newit618_classname_array[$key]));
		
		if($newit618_classname != '') {
			
			C::t('#it618_exam#it618_exam_class1')->insert(array(
				'it618_classname' => trim($newit618_classname_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_pj' => $it618_exam_lang['s553'],
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}
	
	cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s34'].$ok2.' '.$it618_exam_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
if(submitcheck('it618sercsubmit')) {
	if($_GET['beforeword']) {
		$extrasql = "AND it618_classname LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
	}
}

$tmpgroup='<option value="0">'.$it618_exam_lang['s1217'].'</option>';
$query = DB::query("SELECT * FROM ".DB::table('common_usergroup'));
while($common_usergroup = DB::fetch($query)) {
	$tmpgroup.='<option value="'.$common_usergroup[groupid].'">'.$common_usergroup[grouptitle].'</option>';
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do");
showtableheaders($class_set['classname_e1'].$it618_exam_lang['s12'],'it618_exam_class1');
	showsubmit('it618sercsubmit', $it618_exam_lang['s25'], $it618_exam_lang['s42'].' <input name="beforeword" value="'.$_GET['beforeword'].'" class="txt" />');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_class1')." w WHERE 1 $extrasql");
	
	echo '<tr><td colspan=10 style="color:green">'.$it618_exam_lang['s1219'].'</td></tr>';
	echo '<tr><td colspan=10>'.$it618_exam_lang['s43'].$count.'<span style="float:right;color:red">'.$it618_exam_lang['s44'].'</span></td></tr>';
	showsubtitle(array($it618_exam_lang['s56'], $it618_exam_lang['s45'],$it618_exam_lang['s1218'],$it618_exam_lang['s47'], $it618_exam_lang['s49'],$it618_exam_lang['s1216'],$it618_exam_lang['s50'],$it618_exam_lang['s53'],$it618_exam_lang['s54']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." WHERE 1 $extrasql ORDER BY it618_order");
	while($it618_exam = DB::fetch($query)) {
		$class2count = C::t('#it618_exam#it618_exam_class2')->count_by_it618_class1_id($it618_exam['id']);
		$goodscount=C::t('#it618_exam#it618_exam_goods')->count_by_search('','',0,$it618_exam['id']);
		$disabled="";
		if($class2count>0)$disabled="disabled=\"disabled\"";
		
		$groupcount=C::t('#it618_exam#it618_exam_class_vipgroup')->count_by_it618_class1_id($it618_exam['id']);
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id$it618_exam[id]\" name=\"delete[]\" value=\"$it618_exam[id]\" $disabled><label for=\"id$it618_exam[id]\">$it618_exam[id]</label>",
			"<input type=\"text\" class=\"txt\" style=\"width:90px\" name=\"it618_classname[$it618_exam[id]]\" value=\"$it618_exam[it618_classname]\">",
			"<input id=\"c".$it618_exam['id']."_v\" type=\"text\" class=\"txt\" style=\"width:68px;float:left\" name=\"it618_color[$it618_exam[id]]\" value=\"$it618_exam[it618_color]\" onchange=\"updatecolorpreview('c".$it618_exam['id']."')\"><input id=\"c".$it618_exam['id']."\" onclick=\"c".$it618_exam['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_exam['id']."|c".$it618_exam['id']."_v';showMenu({'ctrlid':'c".$it618_exam['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_exam['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_exam['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			"<input type=\"text\" class=\"txt\" style=\"width:260px\" name=\"it618_pj[$it618_exam[id]]\" value=\"$it618_exam[it618_pj]\">",
			'<input class="txt" type="text" style="width:65px;margin-right:0" name="it618_goodscount['.$it618_exam['id'].']" value="'.$it618_exam['it618_goodscount'].'">/<input class="txt" type="text" style="width:65px" name="it618_wapgoodscount['.$it618_exam['id'].']" value="'.$it618_exam['it618_wapgoodscount'].'">',
			'<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_class&cp=admin_classvipgroup&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_exam['id'].'">'.$it618_exam_lang['s1844'].'(<font color=red>'.$groupcount.'</font>)</a>',
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_exam['id'].']" value="'.$it618_exam['it618_order'].'">',
			$class2count,
			$goodscount
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_exam['id']."');";
	}
	
if($reabc[4]!='8')return; /*Dism_taobao-com*/

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_classname[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:90px" name="newit618_classname[]">'],
		[1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:68px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'],
		[1,''],
		[1,''], 
		[1,'<input class="txt" type="text" style="width:50px" name="newit618_order[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="15"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
	if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/
?>