<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(C::t('#it618_exam#it618_exam_set')->count_by_setname('sd_userpower')==0){
	C::t('#it618_exam#it618_exam_set')->insert(array(
		'setname' => 'sd_userpower',
		'setvalue' => ''
	), true);
	C::t('#it618_exam#it618_exam_set')->insert(array(
		'setname' => 'sd_saleuser',
		'setvalue' => ''
	), true);
}

if(C::t('#it618_exam#it618_exam_set')->count_by_setname('sd_isgoodstime')==0){
	C::t('#it618_exam#it618_exam_set')->insert(array(
		'setname' => 'sd_isgoodstime',
		'setvalue' => ''
	), true);
}

if(submitcheck('it618submit')){
	$tmparr=explode(",",$_GET['sd_userpower']);
	for($i=0;$i<count($tmparr);$i++){
		$count=C::t('#it618_exam#it618_exam_sale')->count_by_uid($tmparr[$i]);
		if($count>0){
			$tmpstr.=$tmparr[$i].',';
		}
	}
	if($tmpstr!='')$tmpstr.='@';
	$tmpstr=str_replace(',@','',$tmpstr);
	
	$it618_exam_set=C::t('#it618_exam#it618_exam_set')->fetch_by_setname('sd_userpower');
	C::t('#it618_exam#it618_exam_set')->update($it618_exam_set['id'],array(
		'setvalue' => $tmpstr
	));
	
	$tmpstr='';
	$tmparr=explode(",",$_GET['sd_saleuser']);
	for($i=0;$i<count($tmparr);$i++){
		$count=C::t('#it618_exam#it618_exam_sale')->count_by_uid($tmparr[$i]);
		if($count>0){
			$tmpstr.=$tmparr[$i].',';
		}
	}
	if($tmpstr!='')$tmpstr.='@';
	$tmpstr=str_replace(',@','',$tmpstr);
	
	$it618_exam_set=C::t('#it618_exam#it618_exam_set')->fetch_by_setname('sd_saleuser');
	C::t('#it618_exam#it618_exam_set')->update($it618_exam_set['id'],array(
		'setvalue' => $tmpstr
	));
	
	$it618_exam_set=C::t('#it618_exam#it618_exam_set')->fetch_by_setname('sd_isgoodstime');
	C::t('#it618_exam#it618_exam_set')->update($it618_exam_set['id'],array(
		'setvalue' => $_GET['sd_isgoodstime']
	));

	cpmsg($it618_exam_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_shuadan&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_shuadan&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1],'it618_exam_set');

$sd_userpower=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('sd_userpower');
$sd_saleuser=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('sd_saleuser');
$sd_isgoodstime=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('sd_isgoodstime');

$sd_userpowerstr='';
$tmparr=explode(",",$sd_userpower);
for($i=0;$i<count($tmparr);$i++){
	$username=C::t('#it618_exam#it618_exam_sale')->fetch_username_by_uid($tmparr[$i]);
	$sd_userpowerstr.=$username.' , ';
}
if($sd_userpowerstr!='')$sd_userpowerstr.='@';
$sd_userpowerstr=str_replace(' , @','',$sd_userpowerstr);

$sd_saleuserstr='';
$tmparr=explode(",",$sd_saleuser);
for($i=0;$i<count($tmparr);$i++){
	$username=C::t('#it618_exam#it618_exam_sale')->fetch_username_by_uid($tmparr[$i]);
	$sd_saleuserstr.=$username.' , ';
}
if($sd_saleuserstr!='')$sd_saleuserstr.='@';
$sd_saleuserstr=str_replace(' , @','',$sd_saleuserstr);

if($sd_isgoodstime==1)$chk_sd_isgoodstime='checked="checked"';else $chk_sd_isgoodstime='';

echo '
<tr><td width=100>'.$it618_exam_lang['s1061'].'</td><td><input type="text" name="sd_userpower" style="width:900px;" value="'.$sd_userpower.'"><br><font color=#999>'.$it618_exam_lang['s1062'].'</font></td></tr>
<tr><td></td><td style="color:green">'.$sd_userpowerstr.'</td></tr>
<tr><td>'.$it618_exam_lang['s1063'].'</td><td><textarea name="sd_saleuser" style="width:900px;height:100px">'.$sd_saleuser.'</textarea><br><font color=#999>'.$it618_exam_lang['s1064'].'</font></td></tr>
<tr><td></td><td style="color:green">'.$sd_saleuserstr.'</td></tr>
<tr><td></td><td style="color:blue"><input type="checkbox" id="sd_isgoodstime" name="sd_isgoodstime" value="1" style="vertical-align:middle" '.$chk_sd_isgoodstime.'><label for="sd_isgoodstime">'.$it618_exam_lang['s1039'].'</label><br><br><font color=red>'.$it618_exam_lang['s1068'].'</font></td></tr>
';

showsubmit('it618submit', $it618_exam_lang['s23']);
if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/

?>