<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_exam_txbl', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_num1'])) {
		foreach($_GET['it618_num1'] as $id => $val) {

			C::t('#it618_exam#it618_exam_txbl')->update($id,array(
				'it618_num1' => trim($_GET['it618_num1'][$id]),
				'it618_num2' => trim($_GET['it618_num2'][$id]),
				'it618_bl' => trim($_GET['it618_bl'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_num1_array = !empty($_GET['newit618_num1']) ? $_GET['newit618_num1'] : array();
	$newit618_num2_array = !empty($_GET['newit618_num2']) ? $_GET['newit618_num2'] : array();
	$newit618_bl_array = !empty($_GET['newit618_bl']) ? $_GET['newit618_bl'] : array();
	
	foreach($newit618_num1_array as $key => $value) {
		$newit618_num1 = trim($newit618_num1_array[$key]);
		
		if($newit618_num1 != '') {
			
			C::t('#it618_exam#it618_exam_txbl')->insert(array(
				'it618_num1' => trim($newit618_num1_array[$key]),
				'it618_num2' => trim($newit618_num2_array[$key]),
				'it618_bl' => trim($newit618_bl_array[$key]),
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}

	cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s34'].$ok2.' '.$it618_exam_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_txbl&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_txbl&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1],'it618_exam_class');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_txbl'));
	
	echo '<tr><td colspan=4>'.$it618_exam_lang['s284'].$count.'</td></tr>';
	showsubtitle(array('', $it618_exam_lang['s285'], $it618_exam_lang['s286'],$it618_exam_lang['s287']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_txbl')." ORDER BY it618_num1");
	while($it618_exam_txbl =	DB::fetch($query)) {
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_exam_txbl[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_num1[$it618_exam_txbl[id]]\" value=\"$it618_exam_txbl[it618_num1]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_num2[$it618_exam_txbl[id]]\" value=\"$it618_exam_txbl[it618_num2]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_bl[$it618_exam_txbl[id]]\" value=\"$it618_exam_txbl[it618_bl]\">%",
			""
		));
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_num1[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_num1[]">'], [1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_num2[]">'],[1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_bl[]">%'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="4"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/
?>