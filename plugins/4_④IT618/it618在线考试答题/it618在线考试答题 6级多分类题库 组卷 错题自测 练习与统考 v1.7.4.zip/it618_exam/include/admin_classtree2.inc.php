<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$parenttype=intval($_GET['parenttype']);
if($parenttype==0)$parenttype=1;
$parentclassid=intval($_GET['parentclassid']);

$tablename='it618_exam_qclass2';$countname=$it618_exam_lang['s1245'];

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete($tablename, "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_exam#'.$tablename)->update($id,array(
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_classname_array as $key => $value) {
		$newit618_classname = addslashes(trim($newit618_classname_array[$key]));
		
		if($newit618_classname != '') {
			
			C::t('#it618_exam#'.$tablename)->insert(array(
				'it618_parenttype' => $parenttype,
				'it618_parentclassid' => $parentclassid,
				'it618_classname' => trim($newit618_classname_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}

	cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s34'].$ok2.' '.$it618_exam_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=$parenttype&parentclassid=$parentclassid&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=$parenttype&parentclassid=$parentclassid&page=$page");
showtableheaders($title,'it618_exam_class1');
	
	$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=1");
	$navstr.=$it618_exam_lang['s699']." -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=1&parentclassid=0\">".'(1'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
	
	if($parenttype==2){
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($parentclassid);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=2 and it618_parentclassid=".$parentclassid);
		$navstr.=" -> <b>".$tmpname.'</b> (2'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)';
	}
	
	if($parenttype==3){
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=2 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=2&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (2'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($parentclassid);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=3 and it618_parentclassid=".$parentclassid);
		$navstr.=" -> <b>".$tmpname.'</b> (3'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)';
	}
	
	if($parenttype==4){
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=2 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=2&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (2'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=3 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=3&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (3'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($parentclassid);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=4 and it618_parentclassid=".$parentclassid);
		$navstr.=" -> <b>".$tmpname.'</b> (4'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)';
	}
	
	if($parenttype==5){
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=2 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=2&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (2'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=3 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=3&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (3'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=4 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=4&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (4'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($parentclassid);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=5 and it618_parentclassid=".$parentclassid);
		$navstr.=" -> <b>".$tmpname.'</b> (5'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)';
	}
	
	if($parenttype==6){
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=2 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=2&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (2'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=3 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=3&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (3'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($tmptable['it618_parentclassid']);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=4 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=4&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (4'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmptable=C::t('#it618_exam#'.$tablename)->fetch_by_id($parentclassid);
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($tmptable['it618_parentclassid']);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=5 and it618_parentclassid=".$tmptable['it618_parentclassid']);
		$navstr.=" -> <a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=5&parentclassid=".$tmptable['it618_parentclassid']."\"><b>".$tmpname.'</b> (5'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)</a>';
		
		$tmpname=C::t('#it618_exam#'.$tablename)->fetch_it618_name_by_id($parentclassid);
		$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=6 and it618_parentclassid=".$parentclassid);
		$navstr.=" -> <b>".$tmpname.'</b> (6'.$it618_exam_lang['s1205'].$title.' <font color=red>'.$tmpcount.'</font>)';
	}
	
	echo '<tr><td colspan=10>'.$it618_exam_lang['s1204'].$navstr.'</td></tr>';
	showsubtitle(array($it618_exam_lang['s56'], $it618_exam_lang['s45'],$it618_exam_lang['s1218'],$it618_exam_lang['s50'],$countname));
	
	$query = DB::query("SELECT * FROM ".DB::table($tablename)." WHERE it618_parenttype=$parenttype and it618_parentclassid=$parentclassid ORDER BY it618_order");
	while($it618_exam = DB::fetch($query)) {
		$cid1=0;$cid2=0;$cid3=0;$cid4=0;$cid5=0;$cid6=0;
		$tmpcid='cid'.$parenttype;
		$$tmpcid=$it618_exam['id'];
			
		$questionscount = C::t('#it618_exam#it618_exam_questions')->count_by_search('', '', 0, 0, 0, 0, 0, 0, 0, 0, $cid1, $cid2, $cid3, $cid4, $cid5, $cid6);
		
		if($parenttype<6){
			$tmpcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table($tablename)." WHERE it618_parenttype=".($parenttype+1)." and it618_parentclassid=".$it618_exam['id']);
			$tmpastr="<a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=$cp1&pmod=admin_class&operation=$operation&do=$do&parenttype=".($parenttype+1)."&parentclassid=".$it618_exam['id']."\">".$it618_exam_lang['s1208'].$class_set['classname_q1'].$it618_exam_lang['s12'].'(<font color=red>'.$tmpcount.'</font>)'."</a>";
		}
		
		$disabled="";
		if($tmpcount>0)$disabled="disabled=\"disabled\"";
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id$it618_exam[id]\" name=\"delete[]\" value=\"$it618_exam[id]\" $disabled><label for=\"id$it618_exam[id]\">$it618_exam[id]</label>",
			"<input type=\"text\" class=\"txt\" style=\"width:90px\" name=\"it618_classname[$it618_exam[id]]\" value=\"$it618_exam[it618_classname]\"> $tmpastr",
			"<input id=\"c".$it618_exam['id']."_v\" type=\"text\" class=\"txt\" style=\"width:68px;float:left\" name=\"it618_color[$it618_exam[id]]\" value=\"$it618_exam[it618_color]\" onchange=\"updatecolorpreview('c".$it618_exam['id']."')\"><input id=\"c".$it618_exam['id']."\" onclick=\"c".$it618_exam['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_exam['id']."|c".$it618_exam['id']."_v';showMenu({'ctrlid':'c".$it618_exam['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_exam['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_exam['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_exam['id'].']" value="'.$it618_exam['it618_order'].'">',
			$questionscount
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_exam['id']."');";
	}
	
if($reabc[4]!='8')return; /*Dism_taobao-com*/

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_classname[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:90px" name="newit618_classname[]">'],
		[1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:68px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'],
		[1,'<input class="txt" type="text" style="width:50px" name="newit618_order[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="15"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
	if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/
?>