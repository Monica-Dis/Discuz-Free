<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_exam_set=C::t('#it618_exam#it618_exam_set')->fetch_by_setname($setname);

if($cp1==11||$cp1==15){
	if($cp1==11)$setname1='wapplayadtime';
	if($cp1==15)$setname1='playadtime';
	
	$it618_exam_set1=C::t('#it618_exam#it618_exam_set')->fetch_by_setname($setname1);
	$playadtime=$it618_exam_set1['setvalue'];
	if($playadtime==''){
		$playadtime=0;
	}
	
	$tmpinputstr=$it618_exam_lang['s739'].'<input type="text" style="width:60px" name="'.$setname1.'" value="'.$playadtime.'"> '.$it618_exam_lang['s740'].'<br><br>';
	
	if($cp1==11)$setname2='wapplayadnotids';
	if($cp1==15)$setname2='playadnotids';
	
	$it618_exam_set2=C::t('#it618_exam#it618_exam_set')->fetch_by_setname($setname2);
	
	$tmpinputstr.=$it618_exam_lang['s707'].'<input type="text" style="width:300px" name="'.$setname2.'" value="'.$it618_exam_set2['setvalue'].'"> '.$it618_exam_lang['s709'].'<br><br>';
	
	if($cp1==11)$setname3='wapplayadvip';
	if($cp1==15)$setname3='playadvip';
	
	$it618_exam_set3=C::t('#it618_exam#it618_exam_set')->fetch_by_setname($setname3);
	
	$tmpinputstr.=$it618_exam_lang['s1459'].'<input type="text" style="width:300px" name="'.$setname3.'" value="'.$it618_exam_set3['setvalue'].'"> '.$it618_exam_lang['s1460'].'<br><br>';
}

if($cp1==12){
	$setname1='isscreencapad';
	
	$it618_exam_set1=C::t('#it618_exam#it618_exam_set')->fetch_by_setname($setname1);
	if($it618_exam_set1['setvalue']==1){
		$isscreencapad='checked="checked"';
	}
	
	$tmpinputstr=$it618_exam_lang['s1471'].'<input type="checkbox" style="vertical-align:middle" name="'.$setname1.'" value="1" '.$isscreencapad.'><br><br>';
	
	$setname2='noscreencapaduids';
	
	$it618_exam_set2=C::t('#it618_exam#it618_exam_set')->fetch_by_setname($setname2);
	
	$tmpinputstr.=$it618_exam_lang['s1468'].'<input type="text" style="width:300px" name="'.$setname2.'" value="'.$it618_exam_set2['setvalue'].'"> '.$it618_exam_lang['s1472'].'<br><br>';
	
	$setname3='screencapadtime';
	
	$it618_exam_set3=C::t('#it618_exam#it618_exam_set')->fetch_by_setname($setname3);
	
	$tmpinputstr.=$it618_exam_lang['s1469'].'<input type="text" style="width:80px" name="'.$setname3.'" value="'.$it618_exam_set3['setvalue'].'"> '.$it618_exam_lang['s1470'].'<br><br>';
	
	$setname4='screencapadwidthheight';
	
	$it618_exam_set4=C::t('#it618_exam#it618_exam_set')->fetch_by_setname($setname4);
	
	$tmpinputstr.=$it618_exam_lang['s1473'].'<input type="text" style="width:115px" name="'.$setname4.'" value="'.$it618_exam_set4['setvalue'].'"> '.$it618_exam_lang['s1474'].'<br><br>';
}

if(submitcheck('it618submit')){
	if(C::t('#it618_exam#it618_exam_set')->count_by_setname($setname)==0){
		C::t('#it618_exam#it618_exam_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $_GET[$setname]
		), true);
	}else{
		C::t('#it618_exam#it618_exam_set')->update($it618_exam_set['id'],array(
			'setvalue' => $_GET[$setname]
		));
	}
	
	if($setname1!=''){
		if(C::t('#it618_exam#it618_exam_set')->count_by_setname($setname1)==0){
			C::t('#it618_exam#it618_exam_set')->insert(array(
				'setname' => $setname1,
				'setvalue' => $_GET[$setname1]
			), true);
		}else{
			C::t('#it618_exam#it618_exam_set')->update($it618_exam_set1['id'],array(
				'setvalue' => $_GET[$setname1]
			));
		}
	}
	
	if($setname2!=''){
		if(C::t('#it618_exam#it618_exam_set')->count_by_setname($setname2)==0){
			C::t('#it618_exam#it618_exam_set')->insert(array(
				'setname' => $setname2,
				'setvalue' => $_GET[$setname2]
			), true);
		}else{
			C::t('#it618_exam#it618_exam_set')->update($it618_exam_set2['id'],array(
				'setvalue' => $_GET[$setname2]
			));
		}
	}
	
	if($setname3!=''){
		if(C::t('#it618_exam#it618_exam_set')->count_by_setname($setname3)==0){
			C::t('#it618_exam#it618_exam_set')->insert(array(
				'setname' => $setname3,
				'setvalue' => $_GET[$setname3]
			), true);
		}else{
			C::t('#it618_exam#it618_exam_set')->update($it618_exam_set3['id'],array(
				'setvalue' => $_GET[$setname3]
			));
		}
	}
	
	if($setname4!=''){
		if(C::t('#it618_exam#it618_exam_set')->count_by_setname($setname4)==0){
			C::t('#it618_exam#it618_exam_set')->insert(array(
				'setname' => $setname4,
				'setvalue' => $_GET[$setname4]
			), true);
		}else{
			C::t('#it618_exam#it618_exam_set')->update($it618_exam_set4['id'],array(
				'setvalue' => $_GET[$setname4]
			));
		}
	}
	
	cpmsg($it618_exam_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=$pmod&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=$pmod&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1].'<span style="font-weight:normal;color:red;margin-left:90px">'.$it618_exam_lang['s38'].'</span>','it618_exam_set');

if($cp1==22){
	$tmpstr='<br><font color=blue>'.$it618_exam_lang['s1128'].'</font>';
}

if($cp1==9||$cp1==28){
	$tmpstr='<br><font color=blue>'.$it618_exam_lang['s1410'].'</font>';
}

echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="'.$setname.'"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>

<tr><td width=800>'.$tmpinputstr.'<textarea name="'.$setname.'" style="width:800px;height:400px;visibility:hidden;">'.$it618_exam_set['setvalue'].'</textarea>'.$tmpstr.'</td></tr>
';

showsubmit('it618submit', $it618_exam_lang['s23']);
if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/

?>