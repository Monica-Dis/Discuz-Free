<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/classset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_exam/config/classset.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'.//source/plugin/it618_exam/config/classset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$class_set[\'classname_e1\']=\''.trim($_GET['classname_e1'])."';\n";
		$fileData .= '$class_set[\'classname_e2\']=\''.trim($_GET['classname_e2'])."';\n";
		$fileData .= '$class_set[\'classname_e3\']=\''.trim($_GET['classname_e3'])."';\n";
		$fileData .= '$class_set[\'classname_e4\']=\''.trim($_GET['classname_e4'])."';\n";
		$fileData .= '$class_set[\'classname_q1\']=\''.trim($_GET['classname_q1'])."';\n";
		$fileData .= '$class_set[\'classname_q2\']=\''.trim($_GET['classname_q2'])."';\n";
		$fileData .= '$class_set[\'classname_q3\']=\''.trim($_GET['classname_q3'])."';\n";
		$fileData .= '$class_set[\'classname_q4\']=\''.trim($_GET['classname_q4'])."';\n";
		$fileData .= '$class_set[\'classname_e3_ishide\']=\''.trim($_GET['classname_e3_ishide'])."';\n";
		$fileData .= '$class_set[\'classname_e4_ishide\']=\''.trim($_GET['classname_e4_ishide'])."';\n";
		$fileData .= '$class_set[\'classname_q2_ishide\']=\''.trim($_GET['classname_q2_ishide'])."';\n";
		$fileData .= '$class_set[\'classname_q3_ishide\']=\''.trim($_GET['classname_q3_ishide'])."';\n";
		$fileData .= '$class_set[\'classname_q4_ishide\']=\''.trim($_GET['classname_q4_ishide'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_exam_lang['s1243'], "action=plugins&identifier=$identifier&cp=admin_classset&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

$tmparr=explode("|",$it618_exam_lang['s1258']);
for($i=1;$i<=8;$i++){
	if($i<=4){
		if($class_set['classname_e'.$i]=='')$class_set['classname_e'.$i]=$tmparr[$i-1];
	}else{
		if($class_set['classname_q'.($i-4)]=='')$class_set['classname_q'.($i-4)]=$tmparr[$i-1];
	}
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_classset&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

if($class_set['classname_e3_ishide']==1)$check_classname_e3_ishide='checked="checked"';else $check_classname_e3_ishide='';
if($class_set['classname_e4_ishide']==1)$check_classname_e4_ishide='checked="checked"';else $check_classname_e4_ishide='';
if($class_set['classname_q2_ishide']==1)$check_classname_q2_ishide='checked="checked"';else $check_classname_q2_ishide='';
if($class_set['classname_q3_ishide']==1)$check_classname_q3_ishide='checked="checked"';else $check_classname_q3_ishide='';
if($class_set['classname_q4_ishide']==1)$check_classname_q4_ishide='checked="checked"';else $check_classname_q4_ishide='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_exam_lang['s1011'].'</th></tr>
<tr><td colspan="15" style="color:red">'.$it618_exam_lang['s868'].'</td></tr>
<tr class="header"><th width=180>'.$it618_exam_lang['s937'].'</th><th>'.$it618_exam_lang['s939'].'</th><th>'.$it618_exam_lang['s938'].'</th></tr>

<tr class="hover">
<td bgcolor="#f1f1f1">'.$it618_exam_lang['s1227'].'</td><td bgcolor="#f1f1f1" class="longtxt"><input name="classname_e1" value="'.$class_set['classname_e1'].'" style="width:150px" /></td>
<td bgcolor="#f1f1f1">'.$it618_exam_lang['s1228'].'</td>
</tr>

<tr class="hover">
<td bgcolor="#f1f1f1">'.$it618_exam_lang['s1229'].'</td><td bgcolor="#f1f1f1" class="longtxt"><input name="classname_e2" value="'.$class_set['classname_e2'].'" style="width:150px" /></td>
<td bgcolor="#f1f1f1">'.$it618_exam_lang['s1230'].'</td>
</tr>

<tr class="hover">
<td bgcolor="#f1f1f1">'.$it618_exam_lang['s1231'].'</td><td bgcolor="#f1f1f1" class="longtxt"><input name="classname_e3" value="'.$class_set['classname_e3'].'" style="width:150px" />
<input type="checkbox" id="classname_e3_ishide" style="vertical-align:middle" name="classname_e3_ishide" value=1 '.$check_classname_e3_ishide.'><label for="classname_e3_ishide">'.$it618_exam_lang['s867'].'</label>
</td>
<td bgcolor="#f1f1f1">'.$it618_exam_lang['s1232'].'</td>
</tr>

<tr class="hover">
<td bgcolor="#f1f1f1">'.$it618_exam_lang['s1233'].'</td><td bgcolor="#f1f1f1" class="longtxt"><input name="classname_e4" value="'.$class_set['classname_e4'].'" style="width:150px" />
<input type="checkbox" id="classname_e4_ishide" style="vertical-align:middle" name="classname_e4_ishide" value=1 '.$check_classname_e4_ishide.'><label for="classname_e4_ishide">'.$it618_exam_lang['s867'].'</label>
</td>
<td bgcolor="#f1f1f1">'.$it618_exam_lang['s1234'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1235'].'</td><td class="longtxt"><input name="classname_q1" value="'.$class_set['classname_q1'].'" style="width:150px" />
</td>
<td>'.$it618_exam_lang['s1236'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1237'].'</td><td class="longtxt"><input name="classname_q2" value="'.$class_set['classname_q2'].'" style="width:150px" />
<input type="checkbox" id="classname_q2_ishide" style="vertical-align:middle" name="classname_q2_ishide" value=1 '.$check_classname_q2_ishide.'><label for="classname_q2_ishide">'.$it618_exam_lang['s867'].'</label>
</td>
<td>'.$it618_exam_lang['s1238'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1239'].'</td><td class="longtxt"><input name="classname_q3" value="'.$class_set['classname_q3'].'" style="width:150px" />
<input type="checkbox" id="classname_q3_ishide" style="vertical-align:middle" name="classname_q3_ishide" value=1 '.$check_classname_q3_ishide.'><label for="classname_q3_ishide">'.$it618_exam_lang['s867'].'</label>
</td>
<td>'.$it618_exam_lang['s1240'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1241'].'</td><td class="longtxt"><input name="classname_q4" value="'.$class_set['classname_q4'].'" style="width:150px" />
<input type="checkbox" id="classname_q4_ishide" style="vertical-align:middle" name="classname_q4_ishide" value=1 '.$check_classname_q4_ishide.'><label for="classname_q4_ishide">'.$it618_exam_lang['s867'].'</label>
</td>
<td>'.$it618_exam_lang['s1242'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_exam_lang['s23']);

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/

?>