<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if(submitcheck('it618submit')){

	if(is_array($_GET['it618_order'])) {
		foreach($_GET['it618_order'] as $id => $val) {
			
			C::t('#it618_exam#it618_exam_jfhl')->update($id,array(
				'it618_order' => $_GET['it618_order'][$id],
				'it618_isok' => $_GET['it618_isok'][$id]
			));
		}
	}
	
	cpmsg($it618_exam_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_jfhl&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_jfhl')." where it618_jfid=".$i)==0){
			C::t('#it618_exam#it618_exam_jfhl')->insert(array(
				'it618_jfid' => $i,
				'it618_hl' => 0
			), true);
		}
	}
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_jfhl&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_exam_grouppower');
	if($reabc[5]!='_')return;
	$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_jfhl'));
	echo '<tr><td colspan=10>'.$it618_exam_lang['s647'].$count.'<span style="float:right;color:red">'.$it618_exam_lang['s648'].'</span></td></tr>';
	showsubtitle(array($it618_exam_lang['s649'],$it618_exam_lang['s650'],$it618_exam_lang['s651'],'<div style="width:100px"></div>'));

	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_jfhl')." ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_exam_jfhl = DB::fetch($query)) {
		$jfname=$_G['setting']['extcredits'][$it618_exam_jfhl['it618_jfid']]['title'];
		
		if($jfname!=''){
			if($reabc[1]!='t')return;
			if($it618_exam_jfhl['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
			showtablerow('', array('class="td28"', '', ''), array(
				$jfname,
				'<input class="txt" style="width:50px;" type="text" name="it618_order['.$it618_exam_jfhl['id'].']" value="'.$it618_exam_jfhl['it618_order'].'">',
				'<input class="checkbox" type="checkbox" id="it618_isok['.$it618_exam_jfhl['id'].']" name="it618_isok['.$it618_exam_jfhl['id'].']" '.$it618_isok_checked.' value="1">',
				''
			));
		}
	}
	echo '<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" id="submit_it618submit" name="it618submit" value="'.$it618_exam_lang['s641'].'" /> <font color=red>'.$it618_exam_lang['s655'].'</font></div></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
?>