<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_exam#it618_exam_gonggao')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_title'])) {
		foreach($_GET['it618_title'] as $id => $val) {

			C::t('#it618_exam#it618_exam_gonggao')->update($id,array(
				'it618_title' => trim($_GET['it618_title'][$id]),
				'it618_url' => trim($_GET['it618_url'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_isbold' => trim($_GET['it618_isbold'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_title_array = !empty($_GET['newit618_title']) ? $_GET['newit618_title'] : array();
	$newit618_url_array = !empty($_GET['newit618_url']) ? $_GET['newit618_url'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_title_array as $key => $value) {
		$newit618_title = trim($newit618_title_array[$key]);
		
		if($newit618_title != '') {
			
			C::t('#it618_exam#it618_exam_gonggao')->insert(array(
				'it618_title' => trim($newit618_title_array[$key]),
				'it618_url' => trim($newit618_url_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}

	cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s34'].$ok2.' '.$it618_exam_lang['s35'].$del, "action=plugins&identifier=$identifier&cp=admin_gonggao&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_gonggao&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1],'it618_exam_gonggao');
	$count = C::t('#it618_exam#it618_exam_gonggao')->count_by_search();
	
	echo '<tr><td colspan=6>'.$it618_exam_lang['s873'].$count.'<span style="float:right;color:red">'.$it618_exam_lang['s874'].'</span></td></tr>';
	showsubtitle(array('', $it618_exam_lang['s875'], $it618_exam_lang['s876'],$it618_exam_lang['s29'],$it618_exam_lang['s877'],$it618_exam_lang['s878']));
	
	foreach(C::t('#it618_exam#it618_exam_gonggao')->fetch_all_by_search() as $it618_exam_gonggao) {	
		
		if($it618_exam_gonggao['it618_isbold']==1)$it618_isbold_checked='checked="checked"';else $it618_isbold_checked="";
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_exam_gonggao[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_exam_gonggao[id]]\" value=\"$it618_exam_gonggao[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:480px\" name=\"it618_title[$it618_exam_gonggao[id]]\" value=\"$it618_exam_gonggao[it618_title]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_url[$it618_exam_gonggao[id]]\" value=\"$it618_exam_gonggao[it618_url]\">",
			"<input id=\"c".$it618_exam_gonggao['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_exam_gonggao[id]]\" value=\"$it618_exam_gonggao[it618_color]\" onchange=\"updatecolorpreview('c".$it618_exam_gonggao['id']."')\"><input id=\"c".$it618_exam_gonggao['id']."\" onclick=\"c".$it618_exam_gonggao['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_exam_gonggao['id']."|c".$it618_exam_gonggao['id']."_v';showMenu({'ctrlid':'c".$it618_exam_gonggao['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_exam_gonggao['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_exam_gonggao['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			'<input class="checkbox" type="checkbox" name="it618_isbold['.$it618_exam_gonggao['id'].']" '.$it618_isbold_checked.' value="1">',
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_exam_gonggao['id'].']" value="'.$it618_exam_gonggao['it618_order'].'">',
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_exam_gonggao['id']."');";
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_title[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:480px\" name="newit618_title[]">'], [1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_url[]">'], [1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1,''], [1, ' <input class="txt" type="text" style="width:30px" name="newit618_order[]" value="1">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/
?>