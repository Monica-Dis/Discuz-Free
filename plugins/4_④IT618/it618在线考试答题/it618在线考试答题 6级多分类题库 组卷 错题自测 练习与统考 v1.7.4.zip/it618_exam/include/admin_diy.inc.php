<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_exam_diy', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_exam#it618_exam_diy')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_modecode' => trim($_GET['it618_modecode'][$id]),
				'it618_sql' => trim($_GET['it618_sql'][$id]),
				'it618_count' => trim($_GET['it618_count'][$id]),
				'it618_catchtime' => trim($_GET['it618_catchtime'][$id]),
				'it618_isjs' => trim($_GET['it618_isjs'][$id])
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_type_array = !empty($_GET['newit618_type']) ? $_GET['newit618_type'] : array();
	$newit618_modecode_array = !empty($_GET['newit618_modecode']) ? $_GET['newit618_modecode'] : array();
	
	foreach($newit618_name_array as $key => $value) {

		C::t('#it618_exam#it618_exam_diy')->insert(array(
			'it618_name' => trim($newit618_name_array[$key]),
			'it618_type' => trim($newit618_type_array[$key]),
			'it618_modecode' => trim($newit618_modecode_array[$key])
		), true);
		$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
	}

	cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s34'].$ok2.' '.$it618_exam_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_diy&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_diy&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1],'it618_exam_diy');
echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/plugins/code/prettify.js"></script>
';

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_diy')." w WHERE 1 $extrasql");
	
	echo '<tr><td colspan=6>'.$it618_exam_lang['s891'].$count.'<span style="float:right">'.$it618_exam_lang['s1476'].'</span></td></tr>';
	showtablerow('', array('class="td25"', '', '', '', ''), array('', $it618_exam_lang['s892'],$it618_exam_lang['s893'],$it618_exam_lang['s894'],$it618_exam_lang['s895'],$it618_exam_lang['s897'],$it618_exam_lang['s896']));
	
	foreach(C::t('#it618_exam#it618_exam_diy')->fetch_all_by_search() as $it618_exam_diy) {
		
		if($it618_exam_diy['it618_isjs']==1)$checked='checked="checked"';else $checked="";
		if($it618_exam_diy['it618_type']=='product_zj')$it618_type=$it618_exam_lang['s1125'];
		if($it618_exam_diy['it618_type']=='product_weekhot')$it618_type=$it618_exam_lang['s1126'];
		if($it618_exam_diy['it618_type']=='product_new')$it618_type=$it618_exam_lang['s898'];
		if($it618_exam_diy['it618_type']=='product_hot')$it618_type=$it618_exam_lang['s899'];
		if($it618_exam_diy['it618_type']=='product_pin')$it618_type=$it618_exam_lang['s1474'];
		if($it618_exam_diy['it618_type']=='product_time')$it618_type=$it618_exam_lang['s1475'];
		$sqlstr='';
		if($it618_exam_diy['it618_type']=='product_sql'){
			$it618_type=$it618_exam_lang['s1461'];
			$sqlstr='<br>'.$it618_exam_lang['s1462'].'<input class="txt" style="width:300px;margin-bottom:3px" type="text" name="it618_sql['.$it618_exam_diy['id'].']" value="'.$it618_exam_diy['it618_sql'].'"> '.$it618_exam_lang['s1464'].'<br>'.$it618_exam_lang['s1463'].'<br>';
		}

		$tmpjs.='<script>
						KindEditor.ready(function(K) {
							var editor1 = K.create(\'textarea[id="it618_modecode'.$it618_exam_diy[id].'"]\', {
								cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
								uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
								fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php\',
								allowFileManager : true,
								filterMode:false
							});
									
							prettyPrint();
						});
					</script>';
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_exam_diy[id]\">",
			'<input class="txt" style="width:100px" type="text" name="it618_name['.$it618_exam_diy['id'].']" value="'.$it618_exam_diy['it618_name'].'">',
			$it618_type,
			"<input type='hidden' id='flag".$it618_exam_diy['id']."' value='0'><input type='button' id='btn".$it618_exam_diy['id']."' value='".$it618_exam_lang['s908']."' title='".$it618_exam_lang['s909']."' class='btn' onclick='setmodedisplay(".$it618_exam_diy['id'].")'>".$sqlstr."<div id='mode".$it618_exam_diy['id']."' style='display:none;margin-top:6px;'><textarea class=\"txt\" style=\"width:670px;height:300px;visibility:hidden;\" id=\"it618_modecode$it618_exam_diy[id]\" name=\"it618_modecode[$it618_exam_diy[id]]\">$it618_exam_diy[it618_modecode]</textarea></div>",
			'<input class="txt" style="width:30px" type="text" name="it618_count['.$it618_exam_diy['id'].']" value="'.$it618_exam_diy['it618_count'].'">',
			'<input class="txt" style="width:30px" type="text" name="it618_catchtime['.$it618_exam_diy['id'].']" value="'.$it618_exam_diy['it618_catchtime'].'">'.$it618_exam_lang['s890'],
			'<input class="checkbox" type="checkbox" name="it618_isjs['.$it618_exam_diy['id'].']" '.$checked.' value="1"><a href="javascript:;" onclick="prompt(\''.$it618_exam_lang['s901'].'\', \'&lt;script type=&quot;text/javascript&quot; src=&quot;'.$_G['siteurl'].'plugin.php?id=it618_exam:ajax&ac=getmode&modeid='.$it618_exam_diy['id'].'&quot;&gt;&lt;/script&gt;\')">'.$it618_exam_lang['s902'].'</a>'
		));
		
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
	
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:100px" name="newit618_name[]">'],
		[1,'<select name="newit618_type[]"><option value="product_zj">{$it618_exam_lang['s1125']}</option><option value="product_weekhot">{$it618_exam_lang['s1126']}</option><option value="product_new">{$it618_exam_lang['s898']}</option><option value="product_hot">{$it618_exam_lang['s899']}</option><option value="product_pin">{$it618_exam_lang['s1474']}</option><option value="product_time">{$it618_exam_lang['s1475']}</option><option value="product_sql">{$it618_exam_lang['s1461']}</option></select>'], 
		[1,'{$it618_exam_lang['s903']}'],
		[1,'{$it618_exam_lang['s904']}'],
		[1,'{$it618_exam_lang['s906']}'],
		[1,'{$it618_exam_lang['s905']}'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	
	function setmodedisplay(diyid){
		if(document.getElementById('flag'+diyid).value==0){
			document.getElementById('flag'+diyid).value=1;
			document.getElementById('btn'+diyid).value='{$it618_exam_lang['s910']}';
			document.getElementById('mode'+diyid).style.display='';
		}else{
			document.getElementById('flag'+diyid).value=0;
			document.getElementById('btn'+diyid).value='{$it618_exam_lang['s908']}';
			document.getElementById('mode'+diyid).style.display='none';
		}
	}
	</script>
EOT;
	echo '<tr><td></td><td colspan="7"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';

	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
    echo '
<tr><td colspan="7" style="line-height:22px">'.$it618_exam_lang['s907'].'
</td></tr>'.$tmpjs;
	if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/
?>