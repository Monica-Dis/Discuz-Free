<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/appad.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_exam/config/appad.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/config/appad.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$appad_cookiestime=trim($_GET['appad_cookiestime']);
		if($appad_cookiestime<1){
			$appad_cookiestime=1;
		}
		
		$fileData = '$appad_browseragent=\''.trim($_GET['appad_browseragent'])."';\n";
		$fileData .= '$appad_cookiestime=\''.$appad_cookiestime."';\n";
		$fileData .= '$appad_ishome=\''.trim($_GET['appad_ishome'])."';\n";
		$fileData .= '$appad_hometitle=\''.trim($_GET['appad_hometitle'])."';\n";
		$fileData .= '$appad_homeurl=\''.trim($_GET['appad_homeurl'])."';\n";
		$fileData .= '$appad_isproduct=\''.trim($_GET['appad_isproduct'])."';\n";
		$fileData .= '$appad_pleftico=\''.trim($_GET['appad_pleftico'])."';\n";
		$fileData .= '$appad_plefttitle=\''.trim($_GET['appad_plefttitle'])."';\n";
		$fileData .= '$appad_pleftabout=\''.trim($_GET['appad_pleftabout'])."';\n";
		$fileData .= '$appad_ptitle=\''.trim($_GET['appad_ptitle'])."';\n";
		$fileData .= '$appad_purl=\''.trim($_GET['appad_purl'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_exam_lang['s1627'], "action=plugins&identifier=$identifier&cp=admin_appad&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_appad&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

if($appad_ishome==1)$check_appad_ishome='checked="checked"';else $check_appad_ishome='';
if($appad_isproduct==1)$check_appad_isproduct='checked="checked"';else $check_appad_isproduct='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr class="header"><th width=180>'.$it618_exam_lang['s937'].'</th><th>'.$it618_exam_lang['s939'].'</th><th>'.$it618_exam_lang['s938'].'</th></tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1625'].'</td><td class="longtxt"><input name="appad_browseragent" value="'.$appad_browseragent.'" style="width:300px" /></td>
<td>'.$it618_exam_lang['s1631'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1626'].'</td><td class="longtxt"><input name="appad_cookiestime" value="'.$appad_cookiestime.'" style="width:300px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1629'].'</td><td class="longtxt"><input type="checkbox" name="appad_ishome" value=1 '.$check_appad_ishome.'></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1618'].'</td><td class="longtxt"><input name="appad_hometitle" value="'.$appad_hometitle.'" style="width:300px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1619'].'</td><td class="longtxt"><input name="appad_homeurl" value="'.$appad_homeurl.'" style="width:300px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1630'].'</td><td class="longtxt"><input type="checkbox" name="appad_isproduct" value=1 '.$check_appad_isproduct.'></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1620'].'</td><td class="longtxt"><input name="appad_pleftico" value="'.$appad_pleftico.'" style="width:300px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1621'].'</td><td class="longtxt"><input name="appad_plefttitle" value="'.$appad_plefttitle.'" style="width:300px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1622'].'</td><td class="longtxt"><input name="appad_pleftabout" value="'.$appad_pleftabout.'" style="width:300px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1623'].'</td><td class="longtxt"><input name="appad_ptitle" value="'.$appad_ptitle.'" style="width:300px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_exam_lang['s1624'].'</td><td class="longtxt"><input name="appad_purl" value="'.$appad_purl.'" style="width:300px" /></td>
<td></td>
</tr>

</table>
';

showsubmit('it618submit', $it618_exam_lang['s23']);

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/

?>