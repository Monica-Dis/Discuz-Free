<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/php/aliyunossconfig.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/php/aliyunossconfig.php';
}

if(submitcheck('it618submit')){
	$it618_bucket_url=trim($_GET['it618_bucket_url']);
	$urlarrtmp=explode("://",$it618_bucket_url);
	if(count($urlarrtmp)==1){
		$urlarr=explode("https://",$_G['siteurl']);
		if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
		$it618_bucket_url=$httpstr.$it618_bucket_url;
	}
	
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/php/aliyunossconfig.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {

		$fileData = '$it618_isok=\''.trim($_GET['it618_isok'])."';\n";
		
		$fileData .= '$it618_access_key_id=\''.trim($_GET['it618_access_key_id'])."';\n";
		
		$fileData .= '$it618_access_key_secret=\''.trim($_GET['it618_access_key_secret'])."';\n";
		
		$fileData .= '$it618_bucket_name=\''.trim($_GET['it618_bucket_name'])."';\n";
		
		$fileData .= '$it618_bucket_endpoint=\''.trim($_GET['it618_bucket_endpoint'])."';\n";
		
		$fileData .= '$it618_bucket_url=\''.$it618_bucket_url."';\n";
		
		$fileData .= '$it618_image_ext=\''.trim($_GET['it618_image_ext'])."';\n";
		
		$fileData .= '$it618_file_ext=\''.trim($_GET['it618_file_ext'])."';\n";
		
		$fileData .= '$it618_image_max_size=\''.trim($_GET['it618_image_max_size'])."';\n";
		
		$fileData .= '$it618_file_max_size=\''.trim($_GET['it618_file_max_size'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/php/aliyunoss.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		$fileData = 'require_once \'aliyun-oss-php-sdk-2.0.1.phar'."';\n";
		
		$fileData .= 'const OSS_ACCESS_ID = \''.trim($_GET['it618_access_key_id'])."';\n";

		$fileData .= 'const OSS_ACCESS_KEY = \''.trim($_GET['it618_access_key_secret'])."';\n";
		
		$fileData .= 'const OSS_ENDPOINT = \''.trim($_GET['it618_bucket_endpoint'])."';\n";
		
		$fileData .= '$it618_bucket_url=\''.$it618_bucket_url."';\n";
		
		$fileData .= '$it618_bucket_name=\''.trim($_GET['it618_bucket_name'])."';\n";
		
		$fileData .= '$ossClient=new OSS\OssClient(OSS_ACCESS_ID, OSS_ACCESS_KEY, OSS_ENDPOINT, false)'.";\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_exam_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_aliyunoss&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_aliyunoss&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_exam_aliyunoss');


if($it618_isok==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";

echo '<style>table tr td{line-height:20px}</style>
<tr><td width=150>'.$it618_exam_lang['s1879'].'</td><td><input type="checkbox" id="it618_isok" name="it618_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.$it618_exam_lang['s1880'].'</label></td></tr>
<tr><td>'.$it618_exam_lang['s1882'].'</td><td><input type="text" name="it618_access_key_id" style="width:600px" value="'.$it618_access_key_id.'"></td></tr>
<tr><td>'.$it618_exam_lang['s1883'].'</td><td><input type="text" name="it618_access_key_secret" style="width:600px" value="'.$it618_access_key_secret.'"></td></tr>
<tr><td>'.$it618_exam_lang['s1884'].'</td><td><input type="text" name="it618_bucket_name" style="width:600px" value="'.$it618_bucket_name.'"></td></tr>
<tr><td>'.$it618_exam_lang['s1885'].'</td><td><input type="text" name="it618_bucket_endpoint" style="width:600px" value="'.$it618_bucket_endpoint.'"></td></tr>
<tr><td>'.$it618_exam_lang['s1886'].'</td><td><input type="text" name="it618_bucket_url" style="width:600px" value="'.$it618_bucket_url.'"></td></tr>
<tr><td colspan=2>'.$it618_exam_lang['s1964'].'</td></tr>
<tr><td>'.$it618_exam_lang['s1960'].'</td><td><input type="text" name="it618_image_ext" style="width:600px" value="'.$it618_image_ext.'"> '.$it618_exam_lang['s1965'].'</td></tr>
<tr><td>'.$it618_exam_lang['s1961'].'</td><td><input type="text" name="it618_file_ext" style="width:600px" value="'.$it618_file_ext.'"> '.$it618_exam_lang['s1966'].'</td></tr>
<tr><td>'.$it618_exam_lang['s1962'].'</td><td><input type="text" name="it618_image_max_size" style="width:90px" value="'.$it618_image_max_size.'"> '.$it618_exam_lang['s1967'].'</td></tr>
<tr><td>'.$it618_exam_lang['s1963'].'</td><td><input type="text" name="it618_file_max_size" style="width:90px" value="'.$it618_file_max_size.'"> '.$it618_exam_lang['s1967'].'</td></tr>


<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_exam_lang['s23'].'" /></div></td></tr>
';

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/

?>