<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql = "g.it618_gtype=2";
$state0='';$state1='';$state2='';$state3='';$state4='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and g.it618_chkstate = 1";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and g.it618_chkstate = 2";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and g.it618_chkstate = 3";$state3='selected="selected"';}
if($_GET['state']==4){$it618sql .= " and g.it618_chkstate = 4";$state4='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&it618_class3_id='.$_GET['it618_class3_id'].'&it618_class4_id='.$_GET['it618_class4_id'].'&state='.$_GET['state'];

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_mancount'])) {
		foreach($_GET['it618_mancount'] as $id => $val) {
			$it618_examtime=intval($_GET['it618_examtime'][$id]);
			if($it618_examtime==0)$it618_examtime=60;
			
			C::t('#it618_exam#it618_exam_goods')->update($id,array(
				'it618_examtime' => $it618_examtime,
				'it618_mancount' => $_GET['it618_mancount'][$id],
				'it618_pici' => $_GET['it618_pici'][$id],
				'it618_xgtime1' => dhtmlspecialchars($_GET['it618_xgtime1'][$id]),
				'it618_ispm' => $_GET['it618_ispm'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_exam_lang['s90'].$ok, "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($delid);
		
		if($it618_exam_goods['it618_chkstate']==2||$it618_exam_goods['it618_chkstate']==3){
			DB::query("update ".DB::table('it618_exam_goods')." set it618_chkstate=4 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_exam_lang['s1509'].$ok, "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($delid);
		
		if($it618_exam_goods['it618_chkstate']==2||$it618_exam_goods['it618_chkstate']==4){
			DB::query("update ".DB::table('it618_exam_goods')." set it618_chkstate=3 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_exam_lang['s1510'].$ok, "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_zhuan')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	
	$zhuanuid=intval($_GET['zhuanuid']);
	if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$zhuanuid)==0){
		cpmsg($it618_exam_lang['s156'], "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'error');
	}else{
		if($it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($zhuanuid)){
				
			$it618_state=$it618_exam_shop['it618_state'];
			if($it618_state==0){
				cpmsg($it618_exam_lang['s995'], "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'error');
			}elseif($it618_state==1){
				cpmsg($it618_exam_lang['s996'], "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'error');
			}else{
				$it618_htstate=$it618_exam_shop['it618_htstate'];
				if($it618_htstate==0){
					cpmsg($it618_exam_lang['s997'], "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'error');
				}elseif($it618_htstate==2){
					cpmsg($it618_exam_lang['s998'], "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'error');
				}else{
					$ShopId=$it618_exam_shop['id'];
				}
			}
			
		}else{
			cpmsg($it618_exam_lang['s999'], "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'error');
		}
	}

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($delid);

		if($_GET['isquestion']==1){
			$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_questions')." WHERE it618_pid=".$it618_exam_goods['id']);
			while($it618_exam_goods_questions = DB::fetch($query1)) {
				DB::query("update ".DB::table('it618_exam_questions')." set it618_shopid=$ShopId where id=".$it618_exam_goods_questions['it618_qid']);
			}
		}
		
		$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($ShopId);
		
		DB::query("update ".DB::table('it618_exam_goods')." set it618_shopid=$ShopId,it618_shopuid=".$it618_exam_shop['it618_uid']." where id=".$delid);
		DB::query("update ".DB::table('it618_exam_test')." set it618_shopid=$ShopId where it618_pid=".$delid);
		DB::query("update ".DB::table('it618_exam_test_exam')." set it618_shopid=$ShopId where it618_pid=".$delid);
		DB::query("update ".DB::table('it618_exam_test_pj')." set it618_shopid=$ShopId where it618_pid=".$delid);
		
		$ok=$ok+1;
	}

	cpmsg($it618_exam_lang['s987'].$ok, "action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/

$tmp='<option value="0">'.it618_exam_getlang('s840').$class_set['classname_e1'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

$e3css=';display:none';
if($class_set['classname_e3_ishide']!=1){
	$tmp='<option value="0">'.it618_exam_getlang('s840').$class_set['classname_e3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmp3=str_replace('<option value='.$_GET['it618_class3_id'].'>','<option value='.$_GET['it618_class3_id'].' selected="selected">',$tmp);
	$e3css=';display:';
}

$e4css=';display:none';
if($class_set['classname_e4_ishide']!=1){
	$tmp='<option value="0">'.it618_exam_getlang('s840').$class_set['classname_e4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmp4=str_replace('<option value='.$_GET['it618_class4_id'].'>','<option value='.$_GET['it618_class4_id'].' selected="selected">',$tmp);
	$e4css=';display:';
}

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_class2')." where it618_class1_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1".$urlsql);
showtableheaders($it618_exam_lang['s1482'],'it618_exam_goods');
	showsubmit('it618sercsubmit', $it618_exam_lang['s25'], $it618_exam_lang['s97'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:150px" /> '.$it618_exam_lang['s99'].' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_exam_getlang('s840').$class_set['classname_e2'].'</option></select> <select id="it618_class3_id" name="it618_class3_id" style="'.$e3css.'">'.$tmp3.'</select> <select id="it618_class4_id" name="it618_class4_id" style="'.$e3css.'">'.$tmp4.'</select> '.$it618_exam_lang['s101'].' <select name="state"><option value=0 '.$state0.'>'.it618_exam_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_exam_getlang('s1497').'</option><option value=2 '.$state2.'>'.it618_exam_getlang('s1498').'</option><option value=3 '.$state3.'>'.it618_exam_getlang('s1499').'</option><option value=4 '.$state4.'>'.$it618_exam_lang['s1500'].'</option></select>');
	
	$count = C::t('#it618_exam#it618_exam_goods')->count_by_search('s.it618_uid>0 and '.$it618sql,'',0,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['it618_class3_id'],$_GET['it618_class4_id'],$_GET['key'],$_GET['price1'],$_GET['price2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_product_tk&pmod=admin_product_tk&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	echo '<tr><td colspan=14>'.$it618_exam_lang['s114'].$count.'<span style="float:right;color:red"></span></td></tr>';
	showsubtitle(array('',it618_exam_getlang('s115'),it618_exam_getlang('s1488'),it618_exam_getlang('s1485'),$it618_exam_lang['s1487']));
	
	$n=1;
	foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
		$it618sql,$it618orderby,0,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['it618_class3_id'],$_GET['it618_class4_id'],$_GET['key'],$_GET['price1'],$_GET['price2'],$startlimit,$ppp
	) as $it618_exam_goods) {
		
		if($it618_exam_goods['it618_ispm']==1)$it618_ispm_checked='checked="checked"';else $it618_ispm_checked="";
		
		$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
		
		$ykcount = C::t('#it618_exam#it618_exam_goods_user')->count_by_search('it618_state=2','',$it618_exam_goods['id']);
		$allkcount = C::t('#it618_exam#it618_exam_goods_user')->count_by_search('','',$it618_exam_goods['id']);
		
		$readonly='';$timeclick='onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"';
		if($it618_exam_goods['it618_chkstate']==1)$it618_chkstate='<font color=red>'.$it618_exam_lang['s1497'].'</font>';
		if($it618_exam_goods['it618_chkstate']==2){$it618_chkstate='<font color=blue>'.$it618_exam_lang['s1498'].'</font>';}
		if($it618_exam_goods['it618_chkstate']==3)$it618_chkstate='<font color=red>'.$it618_exam_lang['s1499'].'</font>';
		if($it618_exam_goods['it618_chkstate']==4){$it618_chkstate='<font color=#390>'.$it618_exam_lang['s1500'].'</font>';}
		
		$uid = C::t('#it618_exam#it618_exam_shop')->fetch_it618_uid_by_id($it618_exam_goods['it618_shopid']);
		
		$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_exam_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_exam_goods['id'].$it618_isvip.$it618_issecret.'</label>',
			'<div style="width:530px"><a style="float:left;width:130px" href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.'"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="130" height="80" style="border-radius:3px" align="absmiddle"/></a><div style="float:left;margin-left:6px;line-height:18px;width:380px"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a>'.$it618_issecret.'<br><font color=#999>'.$it618_exam_goods['it618_description'].'</font><br>'.$it618_isvip.'<br>'.$it618_exam_lang['s124'].'<a href="'.it618_exam_rewriteurl($uid).'" target="_blank">'.it618_exam_getusername($uid).'</a></div></div>',
			
			'<div style="line-height:28px">
			
			<font color="#999">'.$it618_exam_goods['it618_lessoncount'].$it618_exam_lang['s128'].'/'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font> <br>
			
			<font color=#999>'.$ykcount.$it618_exam_lang['s1490'].$allkcount.$it618_exam_lang['s1491'].'</font>
			
			</div>',
			'<font color=#999>'.$it618_exam_lang['s1494'].'<input type="text" class="txt" style="width:115px;margin-bottom:3px;margin-right:3px" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_exam_goods['id'].']" readonly="readonly" value="'.$it618_exam_goods['it618_xgtime1'].'" '.$timeclick.'> '.$it618_exam_lang['s191'].'<input type="text" class="txt" style="width:30px;margin-right:3px;color:red;text-align:center;margin-bottom:3px;" '.$readonly.' name="it618_examtime['.$it618_exam_goods['id'].']" value="'.$it618_exam_goods['it618_examtime'].'">'.$it618_exam_lang['s192'].' '.$it618_exam_lang['s1111'].'<font color=red>'.$it618_exam_goods['it618_examscore'].'</font><br>'.$it618_exam_lang['s1502'].'<input type="text" class="txt" style="width:30px;margin-right:3px;margin-top:3px;color:red;text-align:center;" '.$readonly.' name="it618_mancount['.$it618_exam_goods['id'].']" value="'.$it618_exam_goods['it618_mancount'].'">'.$it618_exam_lang['s1491'].' '.$it618_exam_lang['s1503'].'<input type="text" class="txt" style="width:30px;margin-right:3px;margin-top:3px;text-align:center;" '.$readonly.' name="it618_pici['.$it618_exam_goods['id'].']" value="'.$it618_exam_goods['it618_pici'].'"></font>',
			$it618_chkstate.'<br><input class="checkbox" type="checkbox" id="chk_ispm'.$n.'" name="it618_ispm['.$it618_exam_goods['id'].']" '.$it618_ispm_checked.' value="1"><label for="chk_ispm'.$n.'">'.it618_exam_getlang('s1264').'</label>'
		));
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_class1'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
	$n1=1;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$n2=1;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
	
	echo '
	<script charset="utf-8" src="source/plugin/it618_exam/js/Calendar.js"></script>
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	</script>';

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_exam_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_edit" value="'.$it618_exam_lang['s354'].'"/> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_exam_lang['s1505'].'" onclick="return confirm(\''.$it618_exam_lang['s1506'].'\')" /> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_exam_lang['s1507'].'" onclick="return confirm(\''.$it618_exam_lang['s1508'].'\')" /> <br>'.$it618_exam_lang['s1000'].'<input type="text" style="width:80px" name="zhuanuid"> <input type="checkbox" style="vertical-align:middle" id="isquestion" name="isquestion" value="1" checked="checked"><label for="ismadia">'.$it618_exam_lang['s1001'].'</label> <input type="submit" class="btn" name="it618submit_zhuan" value="'.$it618_exam_lang['s1002'].'" onclick="return confirm(\''.$it618_exam_lang['s1003'].'\')" /> <input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/
echo '<script>
		'.$jstmp.'
		</script>';
?>