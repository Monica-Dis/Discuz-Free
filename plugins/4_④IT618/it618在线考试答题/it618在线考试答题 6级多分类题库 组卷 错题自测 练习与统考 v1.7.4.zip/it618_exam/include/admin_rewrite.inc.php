<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$exam_home=\''.'exam'."';\n";
		$fileData .= '$exam_list=\''.'exam_list'."';\n";
		$fileData .= '$exam_search=\''.'exam_search'."';\n";
		$fileData .= '$exam_gwc=\''.'exam_gwc'."';\n";
		$fileData .= '$exam_product=\''.'paper'."';\n";
		$fileData .= '$exam_testabout=\''.'testabout'."';\n";
		$fileData .= '$exam_test=\''.'test'."';\n";
		$fileData .= '$exam_utestabout=\''.'testabout'."';\n";
		$fileData .= '$exam_utest=\''.'test'."';\n";
		$fileData .= '$exam_teacher=\''.'teacher'."';\n";
		$fileData .= '$exam_sc=\''.'exam_sc'."';\n";
		$fileData .= '$exam_wap=\''.'exam_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$exam_home1=\''.$urltype."';\n";
		$fileData .= '$exam_list1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$exam_search1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$exam_gwc1=\''.$urltype."';\n";
		$fileData .= '$exam_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$exam_testabout1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$exam_test1=\'-{eid}'.$urltype."';\n";
		$fileData .= '$exam_utestabout1=\''.$urltype."';\n";
		$fileData .= '$exam_utest1=\'-{eid}'.$urltype."';\n";
		$fileData .= '$exam_teacher1=\'-{lid}'.$urltype."';\n";
		$fileData .= '$exam_sc1=\''.$urltype."';\n";
		$fileData .= '$exam_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$exam_home=\''.str_replace("-","",$_GET['exam_home'])."';\n";
		$fileData .= '$exam_list=\''.str_replace("-","",$_GET['exam_list'])."';\n";
		$fileData .= '$exam_search=\''.str_replace("-","",$_GET['exam_search'])."';\n";
		$fileData .= '$exam_gwc=\''.str_replace("-","",$_GET['exam_gwc'])."';\n";
		$fileData .= '$exam_product=\''.str_replace("-","",$_GET['exam_product'])."';\n";
		$fileData .= '$exam_testabout=\''.str_replace("-","",$_GET['exam_testabout'])."';\n";
		$fileData .= '$exam_test=\''.str_replace("-","",$_GET['exam_test'])."';\n";
		$fileData .= '$exam_utestabout=\''.str_replace("-","",$_GET['exam_utestabout'])."';\n";
		$fileData .= '$exam_utest=\''.str_replace("-","",$_GET['exam_utest'])."';\n";
		$fileData .= '$exam_teacher=\''.str_replace("-","",$_GET['exam_teacher'])."';\n";
		$fileData .= '$exam_sc=\''.str_replace("-","",$_GET['exam_sc'])."';\n";
		$fileData .= '$exam_wap=\''.str_replace("-","",$_GET['exam_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$exam_home1=\''.$urltype."';\n";
		$fileData .= '$exam_list1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$exam_search1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$exam_gwc1=\''.$urltype."';\n";
		$fileData .= '$exam_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$exam_testabout1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$exam_test1=\'-{eid}'.$urltype."';\n";
		$fileData .= '$exam_utestabout1=\''.$urltype."';\n";
		$fileData .= '$exam_utest1=\'-{eid}'.$urltype."';\n";
		$fileData .= '$exam_teacher1=\'-{lid}'.$urltype."';\n";
		$fileData .= '$exam_sc1=\''.$urltype."';\n";
		$fileData .= '$exam_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_exam_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

if($exam_utestabout=='')$exam_utestabout='utestabout';
if($exam_utest=='')$exam_utest='utest';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_exam_lang['s136'].'</font></td></tr>
<tr><td colspan="3">'.$it618_exam_lang['s137'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_exam_lang['s138'].'</th><th>'.$it618_exam_lang['s139'].'</th><th>'.$it618_exam_lang['s140'].'</th></tr>
<tr class="hover">
<td>'.$it618_exam_lang['s141'].'</td><td></td><td class="longtxt"><input name="exam_home" value="'.$exam_home.'"/>'.$exam_home.$exam_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s142'].'</td><td>{cid1}, {cid2}, {price}, {order}, {page}</td><td class="longtxt"><input name="exam_list" value="'.$exam_list.'" />'.$exam_list.$exam_list1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s143'].'</td><td>{cid1}, {cid2}, {price}, {order}, {page}</td><td class="longtxt"><input name="exam_search" value="'.$exam_search.'" />'.$exam_search.$exam_search1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s1071'].'</td><td></td><td class="longtxt"><input name="exam_gwc" value="'.$exam_gwc.'"/>'.$exam_gwc.$exam_gwc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s144'].'</td><td>{pid}</td><td class="longtxt"><input name="exam_product" value="'.$exam_product.'" />'.$exam_product.$exam_product1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s232'].'</td><td>{pid}</td><td class="longtxt"><input name="exam_testabout" value="'.$exam_testabout.'" />'.$exam_testabout.$exam_testabout1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s145'].'</td><td>{eid}</td><td class="longtxt"><input name="exam_test" value="'.$exam_test.'" />'.$exam_test.$exam_test1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s445'].'</td><td></td><td class="longtxt"><input name="exam_utestabout" value="'.$exam_utestabout.'" />'.$exam_utestabout.$exam_utestabout1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s446'].'</td><td>{eid}</td><td class="longtxt"><input name="exam_utest" value="'.$exam_utest.'" />'.$exam_utest.$exam_utest1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s766'].'</td><td>{lid}</td><td class="longtxt"><input name="exam_teacher" value="'.$exam_teacher.'" />'.$exam_teacher.$exam_teacher1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s146'].'</td><td></td><td class="longtxt"><input name="exam_sc" value="'.$exam_sc.'"/>'.$exam_sc.$exam_sc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_exam_lang['s147'].'</td><td>{pagetype}, {cid1}, {cid2}</td><td class="longtxt"><input name="exam_wap" value="'.$exam_wap.'"/>'.$exam_wap.$exam_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_exam_lang['s23']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_exam_lang['s148'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_home.$urltype.'$ $1/plugin.php?id=it618_exam:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:list&class1=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:list&class1=$2&class2=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:list&class1=$2&class2=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_search.$urltype.'$ $1/plugin.php?id=it618_exam:search&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_gwc.$urltype.'$ $1/plugin.php?id=it618_exam:gwc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:product&pid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_testabout.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:testabout&pid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_test.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:test&eid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_utestabout.$urltype.'$ $1/plugin.php?id=it618_exam:utestabout&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_utest.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:utest&eid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_teacher.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:teacher&lid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_sc.$urltype.'$ $1/plugin.php?id=it618_exam:sc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_wap.$urltype.'$ $1/plugin.php?id=it618_exam:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:wap&pagetype=$2&cid1=$3&cid2=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:wap&pagetype=$2&cid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$exam_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_exam:wap&pagetype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_exam_lang['s149'].'</h1>
<pre class="colorbox">
'.$it618_exam_lang['s150'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_home.$urltype.'$ plugin.php?id=it618_exam:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_list.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:list&class1=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:list&class1=$1&class2=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:list&class1=$1&class2=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:list&class1=$1&class2=$2&area1=$3&order=$4&page=$5&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_search.$urltype.'$ plugin.php?id=it618_exam:search&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:search&class1=$1&class2=$2&price=$3&order=$4&page=$5&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_gwc.$urltype.'$ plugin.php?id=it618_exam:gwc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_product.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:product&pid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_testabout.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:testabout&pid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_test.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:test&eid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_utestabout.$urltype.'$ plugin.php?id=it618_exam:utestabout&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_utest.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:utest&eid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_teacher.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:teacher&lid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_sc.$urltype.'$ plugin.php?id=it618_exam:sc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_wap.$urltype.'$ plugin.php?id=it618_exam:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:wap&pagetype=$1&cid1=$2&cid2=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_exam:wap&pagetype=$1&cid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$exam_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_exam:wap&pagetype=$1&%1</font>

</pre>

<h1>'.$it618_exam_lang['s151'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$exam_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:index&$3
RewriteRule ^(.*)/'.$exam_list.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:list&class1=$2&$4
RewriteRule ^(.*)/'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:list&class1=$2&class2=$3&$5
RewriteRule ^(.*)/'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:list&class1=$2&class2=$3&$5
RewriteRule ^(.*)/'.$exam_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&$8
RewriteRule ^(.*)/'.$exam_search.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:search&$3
RewriteRule ^(.*)/'.$exam_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&$8
RewriteRule ^(.*)/'.$exam_gwc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:gwc&$3
RewriteRule ^(.*)/'.$exam_product.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:product&pid=$2&$4
RewriteRule ^(.*)/'.$exam_testabout.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:testabout&pid=$2&$4
RewriteRule ^(.*)/'.$exam_test.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:test&eid=$2&$4
RewriteRule ^(.*)/'.$exam_utestabout.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:utestabout&$3
RewriteRule ^(.*)/'.$exam_utest.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:utest&eid=$2&$4
RewriteRule ^(.*)/'.$exam_teacher.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:teacher&lid=$2&$4
RewriteRule ^(.*)/'.$exam_sc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:sc&$3
RewriteRule ^(.*)/'.$exam_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:wap&$3
RewriteRule ^(.*)/'.$exam_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:wap&pagetype=$2&cid1=$3&cid2=$4&$6
RewriteRule ^(.*)/'.$exam_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:wap&pagetype=$2&cid=$3&$5
RewriteRule ^(.*)/'.$exam_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_exam:wap&pagetype=$2&$4</font>

</pre>

<h1>'.$it618_exam_lang['s152'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="exam_home"&gt;
			&lt;match url="^(.*/)*'.$exam_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_list1"&gt;
			&lt;match url="^(.*/)*'.$exam_list.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:list&amp;amp;class1={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_list2"&gt;
			&lt;match url="^(.*/)*'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_list3"&gt;
			&lt;match url="^(.*/)*'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_list4"&gt;
			&lt;match url="^(.*/)*'.$exam_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;price={R:4}&amp;amp;order={R:5}&amp;amp;page={R:6}&amp;amp;{R:7}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_search"&gt;
			&lt;match url="^(.*/)*'.$exam_search.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:search&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_search1"&gt;
			&lt;match url="^(.*/)*'.$exam_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:search&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;price={R:4}&amp;amp;order={R:5}&amp;amp;page={R:6}&amp;amp;{R:7}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_gwc"&gt;
			&lt;match url="^(.*/)*'.$exam_gwc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:gwc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_product"&gt;
			&lt;match url="^(.*/)*'.$exam_product.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:product&amp;amp;pid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_testabout"&gt;
			&lt;match url="^(.*/)*'.$exam_testabout.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:testabout&amp;amp;pid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_test"&gt;
			&lt;match url="^(.*/)*'.$exam_test.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:test&amp;amp;eid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_utestabout"&gt;
			&lt;match url="^(.*/)*'.$exam_utestabout.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:utestabout&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_utest"&gt;
			&lt;match url="^(.*/)*'.$exam_utest.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:utest&amp;amp;eid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_teacher"&gt;
			&lt;match url="^(.*/)*'.$exam_teacher.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:teacher&amp;amp;lid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_sc"&gt;
			&lt;match url="^(.*/)*'.$exam_sc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:sc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_wap"&gt;
			&lt;match url="^(.*/)*'.$exam_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_wap1"&gt;
			&lt;match url="^(.*/)*'.$exam_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:wap&amp;amp;pagetype={R:2}&amp;amp;cid1={R:3}&amp;amp;cid2={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_wap2"&gt;
			&lt;match url="^(.*/)*'.$exam_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="exam_wap3"&gt;
			&lt;match url="^(.*/)*'.$exam_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_exam:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$exam_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:index&$2
endif
match URL into $ with ^(.*)/'.$exam_list.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:list&class1=$2&$3
endif
match URL into $ with ^(.*)/'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:list&class1=$2&class2=$3&$4
endif
match URL into $ with ^(.*)/'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:list&class1=$2&class2=$3&$4
endif
match URL into $ with ^(.*)/'.$exam_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7
endif
match URL into $ with ^(.*)/'.$exam_search.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:search&$2
endif
match URL into $ with ^(.*)/'.$exam_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7
endif
match URL into $ with ^(.*)/'.$exam_gwc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:gwc&$2
endif
match URL into $ with ^(.*)/'.$exam_product.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:product&pid=$2&$3
endif
match URL into $ with ^(.*)/'.$exam_testabout.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:testabout&pid=$2&$3
endif
match URL into $ with ^(.*)/'.$exam_test.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:test&eid=$2&$3
endif
match URL into $ with ^(.*)/'.$exam_utestabout.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:utestabout&$2
endif
match URL into $ with ^(.*)/'.$exam_utest.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:utest&eid=$2&$3
endif
match URL into $ with ^(.*)/'.$exam_teacher.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:teacher&lid=$2&$3
endif
match URL into $ with ^(.*)/'.$exam_sc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:sc&$2
endif
match URL into $ with ^(.*)/'.$exam_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:wap&$2
endif
match URL into $ with ^(.*)/'.$exam_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:wap&pagetype=$2&cid1=$3&cid2=$4&$5
endif
match URL into $ with ^(.*)/'.$exam_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:wap&pagetype=$2&cid=$3&$4
endif
match URL into $ with ^(.*)/'.$exam_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_exam:wap&pagetype=$2&$3
endif</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$exam_home.$urltype.'$ $1/plugin.php?id=it618_exam:index&$2 last;
rewrite ^([^\.]*)/'.$exam_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:list&class1=$2&$3 last;
rewrite ^([^\.]*)/'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:list&class1=$2&class2=$3&$4 last;
rewrite ^([^\.]*)/'.$exam_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:list&class1=$2&class2=$3&$4 last;
rewrite ^([^\.]*)/'.$exam_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7 last;
rewrite ^([^\.]*)/'.$exam_search.$urltype.'$ $1/plugin.php?id=it618_exam:search&$2 last;
rewrite ^([^\.]*)/'.$exam_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7 last;
rewrite ^([^\.]*)/'.$exam_gwc.$urltype.'$ $1/plugin.php?id=it618_exam:gwc&$2 last;
rewrite ^([^\.]*)/'.$exam_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:product&pid=$2&$3 last;
rewrite ^([^\.]*)/'.$exam_testabout.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:testabout&pid=$2&$3 last;
rewrite ^([^\.]*)/'.$exam_test.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:test&eid=$2&$3 last;
rewrite ^([^\.]*)/'.$exam_utestabout.$urltype.'$ $1/plugin.php?id=it618_exam:utestabout&$2 last;
rewrite ^([^\.]*)/'.$exam_utest.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:utest&eid=$2&$3 last;
rewrite ^([^\.]*)/'.$exam_teacher.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:teacher&lid=$2&$3 last;
rewrite ^([^\.]*)/'.$exam_sc.$urltype.'$ $1/plugin.php?id=it618_exam:sc&$2 last;
rewrite ^([^\.]*)/'.$exam_wap.$urltype.'$ $1/plugin.php?id=it618_exam:wap&$2 last;
rewrite ^([^\.]*)/'.$exam_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:wap&pagetype=$2&cid1=$3&cid2=$4&$5 last;
rewrite ^([^\.]*)/'.$exam_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_exam:wap&pagetype=$2&cid=$3&$4 last;
rewrite ^([^\.]*)/'.$exam_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_exam:wap&pagetype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/

?>