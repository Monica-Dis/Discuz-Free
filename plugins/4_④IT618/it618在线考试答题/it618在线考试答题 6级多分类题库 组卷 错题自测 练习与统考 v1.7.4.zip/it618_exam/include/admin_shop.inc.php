<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql='it618_uid>0';
if($_GET['state']) {
	$state0='';$state1='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$it618sql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$it618sql .= " AND it618_state = 0";$state1='selected="selected"';}
	if($_GET['state']==2){$it618sql .= " AND it618_state = 1";$state2='selected="selected"';}
	if($_GET['state']==3){$it618sql .= " AND it618_state = 2";$state3='selected="selected"';}
}

if($_GET['htstate']) {
	$htstate0='';$htstate1='';$htstate2='';$htstate3='';$htstate4='';
	if($_GET['htstate']==0){$it618sql .= "";$htstate0='selected="selected"';}
	if($_GET['htstate']==1){$it618sql .= " AND it618_htstate = 0";$htstate1='selected="selected"';}
	if($_GET['htstate']==2){$it618sql .= " AND it618_htstate = 1";$htstate2='selected="selected"';}
	if($_GET['htstate']==3){$it618sql .= " AND it618_htstate = 2";$htstate3='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&state='.$_GET['state'].'&htstate='.$_GET['htstate'];

foreach(C::t('#it618_exam#it618_exam_shop')->fetch_all_by_search("it618_htstate<>0 and it618_uid>0") as $it618_exam_shop) {
	if($_G['timestamp']>=$it618_exam_shop['it618_htetime']){
		C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($it618_exam_shop['id'],2);
	}else{
		C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($it618_exam_shop['id'],1);
	}
}

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[6]!='e')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($delid);
		if($it618_exam_shop['it618_state']!=2){
			
			C::t('#it618_exam#it618_exam_shop')->delete_by_id($delid);
			$del=$del+1;
		}else{
			$flag=1;
		}
	}
	
	if($flag==1)$tmpstr='<br><br>'.$it618_exam_lang['s1774'];

	cpmsg($it618_exam_lang['s153'].$del.$tmpstr, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($delid);
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$it618_htetime=mktime(0, 0, 0, $tomonth, $todate, $toyear+$it618_exam['exam_httimecount']);
		
		if($it618_exam_shop['it618_state']==0){
			C::t('#it618_exam#it618_exam_shop')->update_pass_by_id($delid,$it618_htetime);
			C::t('#it618_exam#it618_exam_shop')->update($delid,array(
				'it618_ulogo' => 'source/plugin/it618_exam/images/man.jpg',
			));
			$ok=$ok+1;
		}
	}
	cpmsg($it618_exam_lang['s154'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if($reabc[9]!='m')return;
	
	if(is_array($_GET['it618_tcbl'])) {
		foreach($_GET['it618_tcbl'] as $id => $val) {
		
			C::t('#it618_exam#it618_exam_shop')->update($id,array(
				'it618_price' => $_GET['it618_price'][$id],
				'it618_score' => $_GET['it618_score'][$id],
				'it618_ischeck' => $_GET['it618_ischeck'][$id],
				'it618_tcbl' => $_GET['it618_tcbl'][$id],
				'it618_order' => $_GET['it618_order'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_exam_lang['s155'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_zhuan')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$zhuanuid=intval($_GET['zhuanuid']);
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$zhuanuid)==0){
			cpmsg($it618_exam_lang['s156'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'error');
		}else{
			if(DB::result_first("select count(1) from ".DB::table('it618_exam_shop')." where it618_uid=".$zhuanuid)>0){
				cpmsg($it618_exam_lang['s157'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'error');
			}
		}
		
		$it618_exam_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_exam_shop')." where id=".$delid);
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$zhuanuid);
		
		C::t('#it618_exam#it618_exam_shop')->update_it618_uid_by_id($delid,$zhuanuid);
		DB::query("update ".DB::table('it618_exam_goods')." set it618_shopuid=".$it618_exam_shop['it618_uid']." where it618_shopid=".$delid);
		cpmsg($it618_exam_lang['s158'].$it618_exam_shop['it618_name'].$it618_exam_lang['s159'].$username.' '.$it618_exam_lang['s37'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
		break;
	}
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($delid);
		
		if($it618_exam_shop['it618_state']==0){
			C::t('#it618_exam#it618_exam_shop')->update_it618_state_by_id($delid,1);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_exam_lang['s160'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_editht')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	$time=mktime(0, 0, 0, $_GET['sel_month'], $_GET['sel_date'], $_GET['sel_year']);
	if($_G['timestamp']>=$time){
		cpmsg($it618_exam_lang['s161'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
	}
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($delid);
		
		if($it618_exam_shop['it618_state']==2){
			$isviptbtime=0;
			if($IsGroup==1){
				if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('exam',0)){
					if($it618_group_rzmoney['it618_istbtime']==1){
						$isviptbtime=1;
					}
				}
			}
			if($isviptbtime==0){
				C::t('#it618_exam#it618_exam_shop')->update_it618_htetime_by_id($delid,$time);
				if($_G['timestamp']>=$time){
					C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($delid,2);
				}else{
					C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($delid,1);
				}
				$ok=$ok+1;
			}
		}
	}

	cpmsg($it618_exam_lang['s162'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_clock')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($delid);
		
		if($it618_exam_shop['it618_state']==2){
			C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($delid,0);
			C::t('#it618_exam#it618_exam_shop')->fetch_by_id($delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_exam_lang['s163'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_unclock')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($delid);
		
		if($it618_exam_shop['it618_state']==2){
			C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($delid,1);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_exam_lang['s164'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/

echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($it618_exam_lang['s562'].'<span style="float:right">'.$it618_exam_lang['s1682'].'</span>','it618_store_renzheng');
	showsubmit('it618sercsubmit', $it618_exam_lang['s25'], $it618_exam_lang['s166'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:100px" /> '.$it618_exam_lang['s167'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_exam_lang['s170'].' <select name="state"><option value=0 '.$state0.'>'.$it618_exam_lang['s169'].'</option><option value=1 '.$state1.'>'.$it618_exam_lang['s171'].'</option><option value=2 '.$state2.'>'.$it618_exam_lang['s172'].'</option><option value=3 '.$state3.'>'.$it618_exam_lang['s173'].'</option></select> '.$it618_exam_lang['s174'].' <select name="htstate"><option value=0 '.$htstate0.'>'.$it618_exam_lang['s169'].'</option><option value=1 '.$htstate1.'>'.$it618_exam_lang['s175'].'</option><option value=2 '.$htstate2.'>'.$it618_exam_lang['s176'].'</option><option value=3 '.$htstate3.'>'.$it618_exam_lang['s177'].'</option></select>');
	
	$count = C::t('#it618_exam#it618_exam_shop')->count_by_search($it618sql,'',$_GET['key'],$_GET['finduid']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1".$sql);
	
	echo '<tr><td colspan=14>'.$it618_exam_lang['s178'].$count.'<span style="float:right;">'.$it618_exam_lang['s730'].'</span></td></tr>';
	showsubtitle(array('', $it618_exam_lang['s179'],$it618_exam_lang['s180'],$it618_exam_lang['s869'],$it618_exam_lang['s185']));
	
	foreach(C::t('#it618_exam#it618_exam_shop')->fetch_all_by_search(
		$it618sql,'it618_order desc,id desc',$_GET['key'],$_GET['finduid'],$startlimit,$ppp
	) as $it618_exam_shop) {
		
		$username=C::t('#it618_exam#it618_exam_sale')->fetch_username_by_uid($it618_exam_shop['it618_uid']);
		
		$salecountstr='';$salemoneystr='';
		if($it618_exam_shop['it618_state']==2){
			$pcount1=C::t('#it618_exam#it618_exam_goods')->count_by_shopid_state($it618_exam_shop['id'],0);
			$pcount2=C::t('#it618_exam#it618_exam_goods')->count_by_shopid_state($it618_exam_shop['id'],1);
			$pcount3=C::t('#it618_exam#it618_exam_goods')->count_by_shopid_state($it618_exam_shop['id'],2);

			$salecount=C::t('#it618_exam#it618_exam_sale')->sumcount_by_shopid($it618_exam_shop['id']);
			$salemoney=C::t('#it618_exam#it618_exam_sale')->summoney_by_shopid($it618_exam_shop['id']);
			
			$tcmoney=C::t('#it618_exam#it618_exam_sale')->sumtcmoney_by_shopid($it618_exam_shop['id']);
			$ktxmoney=C::t('#it618_exam#it618_exam_shop')->fetch_money_by_id($it618_exam_shop['id']);
			$sqmoney=C::t('#it618_exam#it618_exam_tx')->sumtxmoney_by_shopid_state($it618_exam_shop['id'],1);
			$txmoney=C::t('#it618_exam#it618_exam_tx')->sumtxmoney_by_shopid_state($it618_exam_shop['id'],2);
			if($sqmoney=='')$sqmoney='0.00';
			if($txmoney=='')$txmoney='0.00';else $txmoney=round($txmoney,2);
			$txtc=C::t('#it618_exam#it618_exam_tx')->sumtxtc_by_shopid($it618_exam_shop['id']);
		}
		
		if($salesum=="")$salesum=0;
		
		if($it618_exam_shop['it618_state']==0)$it618_state='<font color=red>'.$it618_exam_lang['s171'].'</font>';
		if($it618_exam_shop['it618_state']==1)$it618_state='<font color=blue>'.$it618_exam_lang['s172'].'</font>';
		if($it618_exam_shop['it618_state']==2)$it618_state='<font color=green>'.$it618_exam_lang['s173'].'</font>';
		
		if($it618_exam_shop['it618_state']==2){
			if($it618_exam_shop['it618_htstate']==0)$it618_htstate='<font color=red>'.$it618_exam_lang['s175'].'</font>';
			if($it618_exam_shop['it618_htstate']==1)$it618_htstate='<font color=green>'.$it618_exam_lang['s176'].'</font>';
			if($it618_exam_shop['it618_htstate']==2)$it618_htstate='<font color=#ccc>'.$it618_exam_lang['s177'].'</font>';
			$httime=date('Y-m-d', $it618_exam_shop['it618_htetime']);
			
			if($IsGroup==1){
				if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('exam',0)){
					if($it618_group_rzmoney['it618_istbtime']==1){
						if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$it618_exam_shop['it618_uid'])){
							if($it618_group_group_user['it618_etime']>0){
								$httime='VIP:'.date('Y-m-d', $it618_group_group_user['it618_etime']);
							}else{
								$httime='VIP:'.$it618_exam_lang['s1273'];
							}
						}else{
							$httime='VIP:'.$it618_exam_lang['s1224'];
						}
					}
				}
			}
		}else{
			$it618_htstate='';	
			$httime='';
		}
		
		$goodscount = $pcount1+$pcount2+$pcount3;
		
		$creditnum=C::t('#it618_exam#it618_exam_sale')->fetch_extcredits_by_uid($it618_exam['exam_credit'],$it618_exam_shop['it618_uid']);
		if($creditnum=="")$creditnum=0;
		
		$preurl=ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql;
		$preurl=str_replace("&","@",$preurl);
		
		$it618_ulogo='src="source/plugin/it618_exam/images/man.jpg"';
		if($it618_exam_shop['it618_ulogo']!='')$it618_ulogo='src="'.$it618_exam_shop['it618_ulogo'].'"';
		
		$tmpurl=it618_exam_getrewrite('exam_teacher',$it618_exam_shop['id'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_shop['id']);
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_exam_shop['id'].'" name="delete[]" value="'.$it618_exam_shop['id'].'" '.$disabled.'><input type="hidden" name="id['.$it618_exam_shop['id'].']" value="'.$it618_exam_shop['id'].'"><label for="chk_del'.$it618_exam_shop['id'].'">'.$it618_exam_shop['id'].'</label>',
			'<div style="float:left;width:80px;"><a href="'.$tmpurl.'" target="_blank">
			<img '.$it618_ulogo.' width=58 height=58 style="margin-bottom:5px; border-radius:30px;border:none">
			</a>
			</div><div style="float:left;width:380px;margin-left:6px;line-height:20px"><span style="font-size:13px;color:#666"><strong>'.$it618_exam_shop['it618_name'].'</strong></span> <a href="javascript:" id="about'.$it618_exam_shop['id'].'">'.$it618_exam_lang['s186'].'</a> '.$it618_state.' <br>'.$it618_exam_lang['s188'].'<a href="home.php?mod=space&uid='.$it618_exam_shop['it618_uid'].'" target="_blank">'.$username.'</a><br>'.$it618_exam_lang['s189'].$httime.' '.$it618_exam_lang['s190'].$it618_htstate.'<br>'.$it618_exam_lang['s1083'].'<input class="txt" style="width:50px;margin-right:3px;color:green;font-weight:bold" type="text" name="it618_score['.$it618_exam_shop['id'].']" value="'.$it618_exam_shop['it618_score'].'">/<font color=red>'.$creditnum.'</font>'.$creditname.' <br>'.$it618_exam_lang['s729'].'<input class="txt" style="width:58px;margin-top:3px;" type="text" name="it618_order['.$it618_exam_shop['id'].']" value="'.$it618_exam_shop['it618_order'].'"><span style="display:none">'.$it618_exam_lang['s940'].'<input class="txt" style="width:50px;margin-right:3px;color:blue;font-weight:bold" type="text" name="it618_price['.$it618_exam_shop['id'].']" value="'.$it618_exam_shop['it618_price'].'">'.$it618_exam_lang['s941'].'</span></div>',
			$it618_exam_lang['s103'].'(<font color=red>'.$pcount1.'</font>)<br>'.$it618_exam_lang['s104'].'(<font color=red>'.$pcount2.'</font>)<br>'.$it618_exam_lang['s105'].'(<font color=red>'.$pcount3.'</font>)',
			$it618_exam_lang['s853'].'<input class="txt" style="width:40px;margin-right:0;color:green;font-weight:bold" type="text" name="it618_tcbl['.$it618_exam_shop['id'].']" value="'.$it618_exam_shop['it618_tcbl'].'">%<br>'.$it618_exam_lang['s857'].$salemoney.'<br>'.$it618_exam_lang['s858'].'<font color=red>'.$tcmoney.'</font>',
			$it618_exam_lang['s196'].'(<font color=red>'.$ktxmoney.'</font>)<br>'.$it618_exam_lang['s197'].'(<font color=red>'.$sqmoney.'</font>)<br>'.$it618_exam_lang['s198'].'(<font color=red>'.$txmoney.'</font>)<br>'.$it618_exam_lang['s199'].'(<font color=red>'.round($txtc,2).'</font>)'
		));
		
		$morecontent=$it618_exam_lang['s200'];
		$morecontent=str_replace("{name}",$it618_exam_shop['it618_name'],$morecontent);
		$morecontent=str_replace("{tel}",$it618_exam_shop['it618_tel'],$morecontent);
		$morecontent=str_replace("{qq}",$it618_exam_shop['it618_qq'],$morecontent);
		$morecontent=str_replace("{about}",$it618_exam_shop['it618_about'],$morecontent);
		$morecontent=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_shop['it618_time']),$morecontent);
		
		$morecontent=str_replace("'","\"",$morecontent);
		$morecontent=str_replace(array("\r\n", "\r", "\n"),"",$morecontent);
		$tmpjs.='KindEditor.ready(function(K) {K(\'#about'.$it618_exam_shop['id'].'\').click(function() {
			var dialog = K.dialog({
				width : 500,
				height : 300,
				title : \''.$it618_exam_lang['s288'].'\',
				body : \'<div style="margin:10px;">'.$morecontent.'</div>\',
				closeBtn : {
					name : \''.$it618_exam_lang['s289'].'\',
					click : function(e) {
						dialog.remove();
					}
				},
				noBtn : {
					name : \''.$it618_exam_lang['s289'].'\',
					click : function(e) {
						dialog.remove();
					}
				}
			});
		});});';
		
	}
	
	$tmptime=date('Y-m-d H:i:s', $_G['timestamp']);
	$timearr=explode(" ",$tmptime);
	$timearr1=explode("-",$timearr[0]);
	$timearr2=explode(":",$timearr[1]);
	//
	$strtmp="";
	for($i=2013;$i<=2050;$i++){
		if($timearr1[0]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_year='<select name="sel_year">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=12;$i++){
		if($timearr1[1]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_month='<select name="sel_month">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=31;$i++){
		if($timearr1[2]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_date='<select name="sel_date">'.$strtmp.'</select>';
	
	function towstr($i){
		if(strlen($i)==1)return "0".$i;else return $i;
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_exam_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_exam_lang['s201'].'" onclick="return confirm(\''.$it618_exam_lang['s202'].'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_exam_lang['s203'].'"/> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_exam_lang['s204'].'" onclick="return confirm(\''.$it618_exam_lang['s205'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_exam_lang['s206'].'" onclick="return confirm(\''.$it618_exam_lang['s207'].'\')"/><br>'.$it618_exam_lang['s208'].' '.$sel_year.$sel_month.$sel_date.'<input type="submit" class="btn" name="it618submit_editht" value="'.$it618_exam_lang['s209'].'" onclick="return confirm(\''.$it618_exam_lang['s210'].'\')"/> <input type="submit" class="btn" name="it618submit_clock" value="'.$it618_exam_lang['s211'].'" onclick="return confirm(\''.$it618_exam_lang['s212'].'\')"/> <input type="submit" class="btn" name="it618submit_unclock" value="'.$it618_exam_lang['s213'].'" onclick="return confirm(\''.$it618_exam_lang['s214'].'\')"/> <font color=red>'.$it618_exam_lang['s215'].'</font><br>'.$it618_exam_lang['s216'].'<input type="test" id="zhuanuid" name="zhuanuid" style="width:50px"> <input type="submit" class="btn" name="it618submit_zhuan" value="'.$it618_exam_lang['s217'].'" onclick="return checkone()"  /><br>'.$it618_exam_lang['s1492'].' &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/
echo '<script>'.$tmpjs.'</script>';
echo  '<script>
		function checkone(){
		var inputs = document.getElementsByName("delete[]");
		var checked_counts = 0;
		for(var i=0;i<inputs.length;i++){
			if(inputs[i].checked){
				checked_counts++;
			}
		}
		if(checked_counts==0){
			alert("'.$it618_exam_lang['s218'].'");
			return false;
		}
		if(checked_counts>1){
			alert("'.$it618_exam_lang['s219'].'");
			return false;
		}
		if(document.getElementById("zhuanuid").value==""){
			alert("'.$it618_exam_lang['s220'].'");
			return false;
		}
		return confirm(\''.$it618_exam_lang['s221'].'\');
		}
		</script>';
?>