<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$ppp = 10;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$it618sql = "g.it618_gtype=1";

$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';$state7='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and g.it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and g.it618_state = 1";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and g.it618_state = 2";$state3='selected="selected"';}
if($_GET['state']==4){$it618sql .= " and g.it618_isvip = 0";$state4='selected="selected"';}
if($_GET['state']==5){$it618sql .= " and g.it618_isvip = 1";$state5='selected="selected"';}
if($_GET['state']==6){$it618sql .= " and g.it618_issecret = 0";$state6='selected="selected"';}
if($_GET['state']==7){$it618sql .= " and g.it618_issecret = 1";$state7='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';
if($_GET['orderby']==0){$it618orderby = "g.it618_shoporder desc,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "g.it618_salecount desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "g.it618_views desc";$orderby2='selected="selected"';}
if($_GET['orderby']==3){$it618orderby = "g.it618_saleprice desc";$orderby3='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&it618_class3_id='.$_GET['it618_class3_id'].'&it618_class4_id='.$_GET['it618_class4_id'].'&state='.$_GET['state'].'orderby='.$_GET['orderby'];

$preurl="plugin.php?id=it618_exam:sc_product".$urlsql."&page=$page";
$preurl=str_replace("&","@",$preurl);

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount = C::t('#it618_exam#it618_exam_sale')->sumcount_by_it618_pid($delid);
		$examcount = C::t('#it618_exam#it618_exam_test_exam')->count_by_pid($delid);
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($delid);
		if($salecount==0&&$examcount==0&&$it618_exam_goods['it618_lessoncount']==0){

			$tmpurl=$_G['siteurl'].it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			$tmparr=explode("source",$it618_exam_goods['it618_picbig']);
			$tmparr1=explode("://",$it618_exam_goods['it618_picbig']);
			$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_picbig)&&count($tmparr1)==1){
				$result=unlink($it618_picbig);
			}
			
			for($i=0;$i<=4;$i++){
				if($i==0)$tmpi='';else $tmpi=$i;
				$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
				
				if($it618_exam_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
					$tmparr=explode("source",$it618_exam_goods['it618_picbig'.$tmpi]);
					$tmparr1=explode("://",$it618_exam_goods['it618_picbig'.$tmpi]);
					$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_picbig)&&count($tmparr1)==1){
						$result=unlink($it618_picbig);
					}
				}
				
				$file_ext=strtolower(substr($it618_exam_goods['it618_picbig'.$tmpi],strrpos($it618_exam_goods['it618_picbig'.$tmpi], '.')+1)); 
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
				if(file_exists($it618_smallurl)){
					$result=unlink($it618_smallurl);
				}
			}
			
			C::t('#it618_exam#it618_exam_goods')->delete_by_id($delid);
			C::t('#it618_exam#it618_exam_goods_questions')->delete_by_pid($delid);
			$del=$del+1;
		}else{
			$flag=1;
		}
	}
	
	if($flag==1)$tmpstr='<br><br>'.$it618_exam_lang['s1775'];

	it618_cpmsg(it618_exam_getlang('s342').$del.$tmpstr, "plugin.php?id=it618_exam:sc_product&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_on')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($delid);
		if($it618_exam_goods['it618_state']==0&&$it618_exam_goods['it618_examtime']>0&&$it618_exam_goods['it618_questioncount']>0&&$it618_exam_goods['it618_examscore']>0){
			DB::query("update ".DB::table('it618_exam_goods')." set it618_state=1 where id=".$delid);
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_exam_getlang('s343').$ok, "plugin.php?id=it618_exam:sc_product&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_down')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($delid);
		if($it618_exam_goods['it618_state']==1){
			DB::query("update ".DB::table('it618_exam_goods')." set it618_state=0 where id=".$delid);
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_exam_getlang('s344').$ok, "plugin.php?id=it618_exam:sc_product&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			$it618_examtime=intval($_GET['it618_examtime'][$id]);
			if($it618_examtime==0)$it618_examtime=60;
			
			C::t('#it618_exam#it618_exam_goods')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_description' => dhtmlspecialchars($_GET['it618_description'][$id]),
				'it618_jfbl' => $_GET['it618_jfbl'][$id],
				'it618_examtime' => $it618_examtime,
				'it618_answertype' => $_GET['it618_answertype'][$id],
				'it618_ischat' => $_GET['it618_ischat'][$id],
				'it618_isnote' => $_GET['it618_isnote'][$id],
				'it618_xgtype' => $_GET['it618_xgtype'][$id],
				'it618_xgtime1' => dhtmlspecialchars($_GET['it618_xgtime1'][$id]),
				'it618_xgtime2' => dhtmlspecialchars($_GET['it618_xgtime2'][$id]),
				'it618_isbm' => $_GET['it618_isbm'][$id],
				'it618_issd' => $_GET['it618_issd'][$id],
				'it618_ispm' => $_GET['it618_ispm'][$id],
				'it618_shoporder' => $_GET['it618_shoporder'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_exam_getlang('s345').$ok, "plugin.php?id=it618_exam:sc_product&page=$page".$urlsql, 'succeed');
}

$tmp='<option value="0">'.it618_exam_getlang('s840').$class_set['classname_e1'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

$e3css=';display:none';
if($class_set['classname_e3_ishide']!=1){
	$tmp='<option value="0">'.it618_exam_getlang('s840').$class_set['classname_e3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmp3=str_replace('<option value='.$_GET['it618_class3_id'].'>','<option value='.$_GET['it618_class3_id'].' selected="selected">',$tmp);
	$e3css=';display:';
}

$e4css=';display:none';
if($class_set['classname_e4_ishide']!=1){
	$tmp='<option value="0">'.it618_exam_getlang('s840').$class_set['classname_e4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmp4=str_replace('<option value='.$_GET['it618_class4_id'].'>','<option value='.$_GET['it618_class4_id'].' selected="selected">',$tmp);
	$e4css=';display:';
}

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_class2')." where it618_class1_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

it618_showformheader("plugin.php?id=it618_exam:sc_product&page=$page".$urlsql);
showtableheaders(it618_exam_getlang('s96'),'it618_exam_sum');
	echo '<tr><td colspan=14>'.it618_exam_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:150px" /> '.it618_exam_getlang('s99').' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select> <select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_exam_getlang('s840').$class_set['classname_e2'].'</option></select> <select id="it618_class3_id" name="it618_class3_id" style="'.$e3css.'">'.$tmp3.'</select> <select id="it618_class4_id" name="it618_class4_id" style="'.$e4css.'">'.$tmp4.'</select> '.it618_exam_getlang('s101').' <select name="state"><option value=0 '.$state0.'>'.it618_exam_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_exam_getlang('s103').'</option><option value=2 '.$state2.'>'.it618_exam_getlang('s104').'</option><option value=3 '.$state3.'>'.it618_exam_getlang('s105').'</option><option value=4 '.$state4.'>'.$it618_exam_lang['s39'].'</option><option value=5 '.$state5.'>'.$it618_exam_lang['s40'].'</option><option value=6 '.$state6.'>'.$it618_exam_lang['s1176'].'</option><option value=7 '.$state7.'>'.$it618_exam_lang['s1177'].'</option></select> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_exam_getlang('s110').'</option><option value=1 '.$orderby1.'>'.it618_exam_getlang('s111').'</option><option value=2 '.$orderby2.'>'.it618_exam_getlang('s112').'</option><option value=3 '.$orderby3.'>'.it618_exam_getlang('s113').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_exam_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_exam#it618_exam_goods')->count_by_search($it618sql,'',$ShopId,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['it618_class3_id'],$_GET['it618_class4_id'],$_GET['key'],$_GET['price1'],$_GET['price2']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_exam:sc_product".$urlsql);
	
	echo '<tr><td colspan=14>'.it618_exam_getlang('s114').$count.'<span style="float:right;">'.it618_exam_getlang('s927').'</span></td></tr>';
	showsubtitle(array('',it618_exam_getlang('s115'),it618_exam_getlang('s116'),it618_exam_getlang('t307'),$it618_exam_lang['s1047'],it618_exam_getlang('s1705')));
	
	$n=1;
	foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
		$it618sql,$it618orderby,$ShopId,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['it618_class3_id'],$_GET['it618_class4_id'],$_GET['key'],$_GET['price1'],$_GET['price2'],$startlimit,$ppp
	) as $it618_exam_goods) {
		
		if($it618_exam_goods['it618_state']==0)$it618_state='<font color=blue>'.it618_exam_getlang('s103').'</font>';
		if($it618_exam_goods['it618_state']==1)$it618_state='<font color=green>'.it618_exam_getlang('s104').'</font>';
		if($it618_exam_goods['it618_state']==2)$it618_state='<font color=red>'.it618_exam_getlang('s105').'</font>';
		
		if($it618_exam_goods['it618_answertype']==0)$it618_answertype0=' selected="selected"';else $it618_answertype0="";
		if($it618_exam_goods['it618_answertype']==1)$it618_answertype1=' selected="selected"';else $it618_answertype1="";
		
		if($it618_exam_goods['it618_ischat']==0)$it618_ischat0=' selected="selected"';else $it618_ischat0="";
		if($it618_exam_goods['it618_ischat']==1)$it618_ischat1=' selected="selected"';else $it618_ischat1="";
		if($it618_exam_goods['it618_ischat']==2)$it618_ischat2=' selected="selected"';else $it618_ischat2="";
		if($it618_exam_goods['it618_ischat']==3)$it618_ischat3=' selected="selected"';else $it618_ischat3="";
		
		if($it618_exam_goods['it618_isnote']==0)$it618_isnote0=' selected="selected"';else $it618_isnote0="";
		if($it618_exam_goods['it618_isnote']==1)$it618_isnote1=' selected="selected"';else $it618_isnote1="";
		if($it618_exam_goods['it618_isnote']==2)$it618_isnote2=' selected="selected"';else $it618_isnote2="";
		if($it618_exam_goods['it618_isnote']==3)$it618_isnote3=' selected="selected"';else $it618_isnote3="";
		
		if($it618_exam_goods['it618_xgtype']==0)$it618_xgtype0=' selected="selected"';else $it618_xgtype0="";
		if($it618_exam_goods['it618_xgtype']==1)$it618_xgtype1=' selected="selected"';else $it618_xgtype1="";
		if($it618_exam_goods['it618_xgtype']==2)$it618_xgtype2=' selected="selected"';else $it618_xgtype2="";
		
		if($it618_exam_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		if($it618_exam_goods['it618_issd']==1)$it618_issd_checked='checked="checked"';else $it618_issd_checked="";
		if($it618_exam_goods['it618_ispm']==1)$it618_ispm_checked='checked="checked"';else $it618_ispm_checked="";
		
		$salecount = C::t('#it618_exam#it618_exam_sale')->sumcount_by_it618_pid($it618_exam_goods['id']);
		$salemoney = C::t('#it618_exam#it618_exam_sale')->summoney_by_it618_pid($it618_exam_goods['id']);
		$examcount = C::t('#it618_exam#it618_exam_test_exam')->count_by_pid($it618_exam_goods['id']);

		$jfpricecss='display:none';
		if($it618_exam_goods['it618_paytype']==1){
			$jfpricecss	= 'display:';
		}
		
		$it618_isvip='';
		$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<br><img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;margin-left:15px">';
		}
		
		$it618_issecret='';
		if($it618_exam_goods['it618_issecret']==1){
			$it618_issecret='<br><img src="source/plugin/it618_exam/images/secret.png" style="vertical-align:middle;height:18px;margin-left:15px">';
		}
		
		$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
		
		$typecountall = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods_type')." WHERE it618_pid=".$it618_exam_goods['id']);
		$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_exam_goods['id']);
		
		$goodstypestr='<a href="javascript:" onclick="showgoodstype('.$it618_exam_goods['id'].')"><img src="source/plugin/it618_exam/images/price.png" style="vertical-align:middle;height:13px;margin-top:-1px;margin-right:3px">'.$it618_exam_lang['s710'].'</a> <font color="#888">('.$typecountok.'/'.$typecountall.')</font>';
		
		
		$goodstypecss='';
		if($typecountok>0){
			$goodstypecss='display:none';
		}
		
		$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
		
		$redatmpstr='';
		if($it618_exam_goods['it618_state']!=1)$redatmpstr='<a href="'.$tmpurl.'" target="_blank">'.it618_exam_getlang('t315').'</a>';

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_exam_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_exam_goods['id'].$it618_isvip.$it618_issecret.'</label>',
			'<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="133" height="80" align="absmiddle" style="border-radius:3px"/></a><div style="float:left;margin-left:6px;line-height:20px"><input type="text" class="txt" style="width:300px;margin-right:3px;margin-bottom:3px" name="it618_name['.$it618_exam_goods['id'].']" value="'.$it618_exam_goods['it618_name'].'"><a href="javascript:" onclick="showgoodsedit('.$it618_exam_goods['id'].')">'.it618_exam_getlang('s351').'</a> '.$redatmpstr.'<br><textarea class="txt" style="width:300px;height:51px" name="it618_description['.$it618_exam_goods['id'].']">'.$it618_exam_goods['it618_description'].'</textarea>'.'</div>',
			
			'<div style="line-height:28px">
			
			<a href="plugin.php?id=it618_exam:sc_product_lesson&pid='.$it618_exam_goods['id'].'&preurl='.$preurl.'"><img src="source/plugin/it618_exam/images/zj.png" style="vertical-align:middle;height:14px;margin-top:-1px;margin-right:3px">'.$it618_exam_lang['s809'].'</a> <font color="#888">('.$it618_exam_goods['it618_lessoncount'].$it618_exam_lang['s128'].'/'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].')</font> <br>
			
			<font color=#999>'.$goodstypestr.' '.$it618_exam_lang['s191'].'<input type="text" class="txt" style="width:30px;margin-right:3px;color:red;text-align:center;" name="it618_examtime['.$it618_exam_goods['id'].']" value="'.$it618_exam_goods['it618_examtime'].'">'.$it618_exam_lang['s192'].' '.$it618_exam_lang['s1111'].'<font color=red>'.$it618_exam_goods['it618_examscore'].'</font></font><br>
			
			<select name="it618_answertype['.$it618_exam_goods['id'].']"><option value="0"'.$it618_answertype0.'>'.it618_exam_getlang('s386').'</option><option value="1"'.$it618_answertype1.'>'.it618_exam_getlang('s387').'</option></select>
			<select name="it618_ischat['.$it618_exam_goods['id'].']" style="margin-top:3px"><option value="1"'.$it618_ischat1.'>'.it618_exam_getlang('s777').'</option><option value="2"'.$it618_ischat2.'>'.it618_exam_getlang('s778').'</option><option value="3"'.$it618_ischat3.'>'.it618_exam_getlang('s779').'</option><option value="0"'.$it618_ischat0.'>'.it618_exam_getlang('s780').'</option></select> <select name="it618_isnote['.$it618_exam_goods['id'].']" style="margin-top:3px"><option value="1"'.$it618_isnote1.'>'.it618_exam_getlang('s781').'</option><option value="2"'.$it618_isnote2.'>'.it618_exam_getlang('s782').'</option><option value="3"'.$it618_isnote3.'>'.it618_exam_getlang('s783').'</option><option value="0"'.$it618_isnote0.'>'.it618_exam_getlang('s784').'</option></select>
			
			</div>',
			'<select id="it618_xgtype'.$n.'" name="it618_xgtype['.$it618_exam_goods['id'].']" style="margin-top:3px"><option value="0"'.$it618_xgtype0.'>'.it618_exam_getlang('s944').'</option><option value="1"'.$it618_xgtype1.'>'.it618_exam_getlang('s945').'</option><option value="2"'.$it618_xgtype2.'>'.it618_exam_getlang('s946').'</option></select><br><input type="text" class="txt" style="width:115px;margin-top:3px" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_exam_goods['id'].']" readonly="readonly" value="'.$it618_exam_goods['it618_xgtime1'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"><br><input type="text" class="txt" style="width:115px;margin-top:3px" id="it618_xgtime2_'.$n.'" name="it618_xgtime2['.$it618_exam_goods['id'].']" readonly="readonly" value="'.$it618_exam_goods['it618_xgtime2'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')">',
			'<input type="text" class="txt" style="width:50px;margin-right:1px;" name="it618_jfbl['.$it618_exam_goods['id'].']" value="'.$it618_exam_goods['it618_jfbl'].'">%<br><div style="line-height:15px">'.it618_exam_getlang('s118').''.$it618_exam_goods['it618_views'].'<br>'.it618_exam_getlang('s638').''.$examcount.'<br>'.it618_exam_getlang('s119').''.$salecount.''.'<br>'.it618_exam_getlang('s120').''.$salemoney.'</div>',
			$it618_state.' <input type="text" class="txt" style="width:30px;margin-right:1px;" name="it618_shoporder['.$it618_exam_goods['id'].']" value="'.$it618_exam_goods['it618_shoporder'].'"><br>
			<input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_exam_goods['id'].']" '.$it618_isbm_checked.' value="1"><label for="chk_isbm'.$n.'">'.it618_exam_getlang('s1266').'</label><br>
			<input class="checkbox" type="checkbox" id="chk_issd'.$n.'" name="it618_issd['.$it618_exam_goods['id'].']" '.$it618_issd_checked.' value="1"><label for="chk_issd'.$n.'">'.it618_exam_getlang('s1265').'</label><br>
			<input class="checkbox" type="checkbox" id="chk_ispm'.$n.'" name="it618_ispm['.$it618_exam_goods['id'].']" '.$it618_ispm_checked.' value="1"><label for="chk_ispm'.$n.'">'.it618_exam_getlang('s1264').'</label>'
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_exam_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_exam_getlang('s352').'" onclick="return confirm(\''.it618_exam_getlang('s353').'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.it618_exam_getlang('s354').'" onclick="return checkvalue()"/> <input type="submit" class="btn" name="it618submit_on" value="'.it618_exam_getlang('s355').'" onclick="return confirm(\''.it618_exam_getlang('s356').'\')" /> <input type="submit" class="btn" name="it618submit_down" value="'.it618_exam_getlang('s357').'" onclick="return confirm(\''.it618_exam_getlang('s358').'\')" /><br>'.$it618_exam_lang['s135'].'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter(); /*dism��taobao��com*/
$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
echo '
<style>.it618_exam_sum tr td{line-height:22px}</style>
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	</script>';
echo '<script>
		'.$jstmp.'
		
		function showgoodsedit(pid){
			layerindex=layer.open({
				type: 2,
				title: "<div style=\'float:left;color:blue\'>'.$it618_exam_lang['s409'].'</div>",
				shadeClose: false,
				scrollbar: false,
				shade:  [0.5, "#393D49"],
				maxmin: false,
				area: ["100%", "100%"],
				content: "plugin.php?id=it618_exam:sc_product_edit'.$adminsid.'&pid="+pid,
				cancel: function(index, layero){ 
					location.reload();
				}    
			});
		}
		
		function showgoodstype(pid){
			layerindex=layer.open({
				type: 2,
				title: "<div style=\'float:left;color:blue\'>'.$it618_exam_lang['s710'].'</div>",
				shadeClose: false,
				scrollbar: false,
				shade:  [0.5, "#393D49"],
				maxmin: false,
				area: ["100%", "100%"],
				content: "plugin.php?id=it618_exam:sc_product_type'.$adminsid.'&pid="+pid,
				cancel: function(index, layero){ 
					location.reload();
				}    
			});
		}
				
		function checkvalue(){
			for(var i=1;i<'.$n.';i++){
				var chk_del = document.getElementById("chk_del"+i).value;
				var it618_xgtype = document.getElementById("it618_xgtype"+i).value;
				var it618_xgtime1 = document.getElementById("it618_xgtime1_"+i).value;
				var it618_xgtime2 = document.getElementById("it618_xgtime2_"+i).value;
				
				var tmparr1=it618_xgtime1.split(" ");
				var tmparr2=it618_xgtime2.split(" ");
				
				if(it618_xgtype>0){
					if(it618_xgtime1==""){
						alert("'.it618_exam_getlang('s949').'"+chk_del+") '.it618_exam_getlang('s950').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
					if(it618_xgtime2==""){
						alert("'.it618_exam_getlang('s949').'"+chk_del+") '.it618_exam_getlang('s951').'");
						document.getElementById("it618_xgtime2_"+i).focus();
						return false;
					}
					if(parseInt(tmparr2[0].replace(/-/g,""))<parseInt(tmparr1[0].replace(/-/g,""))){
						alert("'.it618_exam_getlang('s949').'"+chk_del+")'.it618_exam_getlang('s947').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
					
					var flag=0;
					if(it618_xgtype==2){
						flag=1;
					}else{
						if(parseInt(tmparr2[0].replace(/-/g,""))==parseInt(tmparr1[0].replace(/-/g,""))){
							flag=1;
						}
					}
					if(flag==1&&parseInt(tmparr2[1].replace(":",""))<=parseInt(tmparr1[1].replace(":",""))){
						alert("'.it618_exam_getlang('s949').'"+chk_del+")'.it618_exam_getlang('s948').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
				}
			}
		}
		
		function setpaytype(pid,objvalue){
			document.getElementById("it618_jfprice"+pid).style.display="none"; 
			
			if(objvalue==1){ 
				document.getElementById("it618_jfprice"+pid).style.display=""; 
			}
		}
		</script>';
echo '<script charset="utf-8" src="source/plugin/it618_exam/js/Calendar.js"></script>
	  <script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>