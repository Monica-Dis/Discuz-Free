<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$ppp = 10;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$it618sql = "g.it618_gtype=1 and g.it618_state=1";

$lid=intval($_GET['lid']);
$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);

$orderby0='';$orderby1='';$orderby2='';$orderby3='';
if($_GET['orderby']==0){$it618orderby = "g.it618_shoporder desc,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "g.it618_salecount desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "g.it618_views desc";$orderby2='selected="selected"';}
if($_GET['orderby']==3){$it618orderby = "g.it618_saleprice desc";$orderby3='selected="selected"';}

$urlsql='&lid='.$lid.'&key='.$_GET['key'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&it618_class3_id='.$_GET['it618_class3_id'].'&it618_class4_id='.$_GET['it618_class4_id'].'&orderby='.$_GET['orderby'];

if(submitcheck('it618submit')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$examcount=C::t('#it618_video#it618_video_goods_lesson_exam')->count_by_pid_tid($it618_video_goods_lesson['it618_pid'],$delid);
		if($examcount==0){
			C::t('#it618_exam#it618_video_goods_lesson_exam')->insert(array(
				'it618_pid' => $it618_video_goods_lesson['it618_pid'],
				'it618_lid' => $lid,
				'it618_tid' => $delid
			), true);
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_exam_getlang('s791').$ok, "plugin.php?id=it618_exam:sc_product_examadd&page=$page".$urlsql, 'succeed');
}

$tmp='<option value="0">'.it618_exam_getlang('s840').$class_set['classname_e1'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

$tmp='<option value="0">'.it618_exam_getlang('s840').$class_set['classname_e3'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class3')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp3=str_replace('<option value='.$_GET['it618_class3_id'].'>','<option value='.$_GET['it618_class3_id'].' selected="selected">',$tmp);

$tmp='<option value="0">'.it618_exam_getlang('s840').$class_set['classname_e4'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class4')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp4=str_replace('<option value='.$_GET['it618_class4_id'].'>','<option value='.$_GET['it618_class4_id'].' selected="selected">',$tmp);

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_class2')." where it618_class1_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

it618_showformheader("plugin.php?id=it618_exam:sc_product_examadd&page=$page".$urlsql);
showtableheaders('','it618_exam_sum');
	echo '<tr><td colspan=14>'.it618_exam_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:150px" /> '.it618_exam_getlang('s99').' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select> <select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_exam_getlang('s840').$class_set['classname_e2'].'</option></select> <select id="it618_class3_id" name="it618_class3_id">'.$tmp3.'</select> <select id="it618_class4_id" name="it618_class4_id">'.$tmp4.'</select> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_exam_getlang('s110').'</option><option value=1 '.$orderby1.'>'.it618_exam_getlang('s111').'</option><option value=2 '.$orderby2.'>'.it618_exam_getlang('s112').'</option><option value=3 '.$orderby3.'>'.it618_exam_getlang('s113').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_exam_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_exam#it618_exam_goods')->count_by_search($it618sql,'',$ShopId,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['it618_class3_id'],$_GET['it618_class4_id'],$_GET['key'],$_GET['price1'],$_GET['price2']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_exam:sc_product_examadd".$urlsql);
	
	echo '<tr><td colspan=14>'.it618_exam_getlang('s114').$count.'<span style="float:right;">'.it618_exam_getlang('s785').'</span></td></tr>';
	showsubtitle(array('',it618_exam_getlang('s786'),it618_exam_getlang('s787')));
	
	$n=1;
	foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
		$it618sql,$it618orderby,$ShopId,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['it618_class3_id'],$_GET['it618_class4_id'],$_GET['key'],$_GET['price1'],$_GET['price2'],$startlimit,$ppp
	) as $it618_exam_goods) {
		
		$it618_isvip='';
		$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<br><img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;margin-left:15px">';
		}
		
		$it618_issecret='';
		if($it618_exam_goods['it618_issecret']==1){
			$it618_issecret='<br><img src="source/plugin/it618_exam/images/secret.png" style="vertical-align:middle;height:18px;margin-left:15px">';
		}
		
		$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
		
		if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
			$pricestr='<span style="color:#f30;">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
		}else{
			$pricestr='<span style="color:#390;">'.$it618_exam_lang['s106'].'</span>';
		}
		
		$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
		$it618_examstr=str_replace("{qcount}",$it618_exam_goods['it618_questioncount'],$it618_exam_lang['s168']);
		$it618_examstr=str_replace("{score}",$it618_exam_goods['it618_examscore'],$it618_examstr);
		$it618_examstr=str_replace("{time}",$it618_exam_goods['it618_examtime'],$it618_examstr);
		
		$strtmp=$it618_exam_lang['s788'];
		$disabled="";
		$examcount=C::t('#it618_video#it618_video_goods_lesson_exam')->count_by_pid_tid($it618_video_goods_lesson['it618_pid'],$it618_exam_goods['id']);
		if($examcount>0){
			$strtmp=$it618_exam_lang['s789'];
			$disabled="disabled=\"disabled\"";
		}

		showtablerow('', array('', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" '.$disabled.' value="'.$it618_exam_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_exam_goods['id'].$it618_isvip.$it618_issecret.'</label>',
			'<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="90" height="58" align="absmiddle"/></a><div style="float:left;margin-left:10px;line-height:20px">'.$it618_exam_goods['it618_name'].'<br><font color=#999>'.$it618_exam_goods['it618_description'].'</font><br>'.$pricestr.' '.$it618_examstr.'</div>',
			$strtmp
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_exam_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_exam_getlang('s790').'"/><input type=hidden value='.$page.' name=page /></div></td></tr>';

showtablefooter(); /*dism��taobao��com*/
$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
echo '
<style>.it618_exam_sum tr td{line-height:22px}</style>
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	</script>';
echo '<script>
		'.$jstmp.'
		</script>';
echo '<script charset="utf-8" src="source/plugin/it618_exam/js/Calendar.js"></script>
	  <script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>