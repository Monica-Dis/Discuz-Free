<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_exam_base {
	function common_base() {
		global $_G;
		$cache_file = DISCUZ_ROOT.'./source/plugin/it618_exam/cache.php';
		$tmptime=5;
		
		if(($_G['timestamp'] - @filemtime($cache_file)) > $tmptime) {
			
			@$fp = fopen($cache_file,"w");
			fwrite($fp,$_G['timestamp']);
			fclose($fp);
			
			$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods')." where it618_chkstate=4");
			while($it618_exam_goods = DB::fetch($query)) {
				if(strtotime($it618_exam_goods['it618_xgtime1'])+$it618_exam_goods['it618_examtime']*60<=$_G['timestamp']){
					C::t('#it618_exam#it618_exam_goods')->update($it618_exam_goods['id'],array(
						'it618_chkstate' => 1
					));
				}
			}
			
			$query = DB::query("SELECT * FROM ".DB::table('it618_exam_test_exam')." where it618_state!=3");
			while($it618_exam_test_exam = DB::fetch($query)) {
				if($it618_exam_test_exam['it618_etime']+3<$_G['timestamp']){
					$it618_testscore=C::t('#it618_exam#it618_exam_test_exam_questions')->sum_testscore_by_eid($it618_exam_test_exam['id']);
					C::t('#it618_exam#it618_exam_test_exam')->update($it618_exam_test_exam['id'],array(
						'it618_testscore' => $it618_testscore,
						'it618_state' => 3
					));
				}
			}
			
			$query = DB::query("SELECT * FROM ".DB::table('it618_exam_utest_exam')." where it618_state!=3");
			while($it618_exam_utest_exam = DB::fetch($query)) {
				if($it618_exam_utest_exam['it618_etime']+3<$_G['timestamp']){
					$it618_rightcount=0;
					$query = DB::query("SELECT * FROM ".DB::table('it618_exam_utest_exam_questions')." WHERE it618_eid=".$it618_exam_utest_exam['id']." ORDER BY it618_order,id");
					while($it618_exam_utest_exam_questions = DB::fetch($query)) {
						if($it618_exam_utest_exam_questions['it618_isok']==1){
							C::t('#it618_exam#it618_exam_errquestions')->delete_by_qid_uid($it618_exam_utest_exam_questions['it618_qid'],$it618_exam_utest_exam['it618_uid']);
							$it618_rightcount=$it618_rightcount+1;
						}
					}
					
					C::t('#it618_exam#it618_exam_utest_exam')->update($it618_exam_utest_exam['id'],array(
						'it618_rightcount' => $it618_rightcount,
						'it618_state' => 3
					));
				}
			}
			
			foreach(C::t('#it618_exam#it618_exam_shop')->fetch_all_by_search("it618_htstate<>0") as $it618_exam_shop) {
				$isviptbtime=0;
				if($IsGroup==1){
					if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('exam',0)){
						if($it618_group_rzmoney['it618_istbtime']==1){
							$isviptbtime=1;
							if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$it618_exam_shop['it618_uid'])){
								if($_G['timestamp']>=$it618_group_group_user['it618_etime']&&$it618_group_group_user['it618_etime']>0){
									C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($it618_exam_shop['id'],2);
								}else{
									C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($it618_exam_shop['id'],1);
								}
							}else{
								C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($it618_exam_shop['id'],2);
							}
						}
					}
				}
				
				if($isviptbtime==0){
					if($_G['timestamp']>=$it618_exam_shop['it618_htetime']){
						C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($it618_exam_shop['id'],2);
					}else{
						C::t('#it618_exam#it618_exam_shop')->update_it618_htstate_by_id($it618_exam_shop['id'],1);
					}
				}
			}
		}
	}
}

class plugin_it618_exam extends plugin_it618_exam_base{
	function common() {
		$this->common_base();
	}
	
	function global_header(){
		foreach(C::t('#it618_exam#it618_exam_diy')->fetch_all_by_search() as $it618_exam_diy) {
			
			$blockcount=C::t('#it618_exam#it618_exam_sale')->count_by_name($it618_exam_diy["it618_name"]);
			if($blockcount>0){
				if((time()-$it618_exam_diy["it618_time"])<(60*$it618_exam_diy["it618_catchtime"])){
					continue;
				}else{
					C::t('#it618_exam#it618_exam_diy')->update_it618_time_by_id(time(),$it618_exam_diy["id"]);
				}
			
				require_once DISCUZ_ROOT.'./source/plugin/it618_exam/getmode.func.php';
				$content=it618_exam_getmodecontent($it618_exam_diy['it618_type'],$it618_exam_diy['it618_sql'],$it618_exam_diy['it618_modecode'],$it618_exam_diy['it618_count']);
				C::t('#it618_exam#it618_exam_sale')->update_summary_dateline_by_name($content,time(),$it618_exam_diy["it618_name"]);
			}
		}
		
	}

}

class plugin_it618_exam_forum extends plugin_it618_exam{
	function viewthread_posttop_output(){
		global $_G,$postlist;
		$it618_exam = $_G['cache']['plugin']['it618_exam'];
		
		foreach($postlist as $id => $post) {
			if($post['first']){
				if($it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_tieid($post['tid'])){
					$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_test_exam['it618_pid']);
					require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
					
					$tmpurl=$_G['siteurl'].it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
					$tmpstr='<table width="100%" style="margin-bottom:15px"><tr>
								<td width="158" style="vertical-align:top"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" style="width:150px"/></a></td>
								<td style="vertical-align:top">
									<div style="font-size:13px;color:#000"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a></div>
									<div style="font-size:12px;color:#999;line-height:19px;padding-top:10px">'.$it618_exam_goods['it618_description'].'</div>
									<div style="font-size:13px;color:#333">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' '.$it618_exam_goods['it618_tests'].it618_exam_getlang('s931').'</div>
								</td>
							  </tr></table>';
					$post['message']=str_replace('<a href="'.$tmpurl.'" target="_blank">'.$tmpurl.'</a>',"",$post['message']);
					$post['message']=$tmpstr.$post['message'];
					$postlist[$id] =$post;
					
					return array();
				}
			}
		}
		return array();
	}
}

class mobileplugin_it618_exam extends plugin_it618_exam_base{
	function common() {
		$this->common_base();
	}
}

class mobileplugin_it618_exam_forum extends mobileplugin_it618_exam{
	
	function viewthread_posttop_mobile_output(){
		global $_G,$postlist;
		$it618_exam = $_G['cache']['plugin']['it618_exam'];
		
		foreach($postlist as $id => $post) {
			if($post['first']){
				if($it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_tieid($post['tid'])){
					$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_test_exam['it618_pid']);
					require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
					
					$tmpurl=$_G['siteurl'].it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
					$tmpstr='<table width="100%" style="margin-bottom:15px"><tr>
								<td width="118" style="vertical-align:top"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" style="width:110px"/></a></td>
								<td style="vertical-align:top">
									<div style="font-size:13px;color:#000"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a></div>
									<div style="font-size:12px;color:#999;line-height:19px;padding-top:5px">'.$it618_exam_goods['it618_description'].'</div>
									<div style="font-size:12px;color:#333">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' '.$it618_exam_goods['it618_tests'].it618_exam_getlang('s931').'</div>
								</td>
							  </tr></table>';
					$post['message']=str_replace('<a href="'.$tmpurl.'" target="_blank">'.$tmpurl.'</a>',"",$post['message']);
					$post['message']=$tmpstr.$post['message'];
					$postlist[$id] =$post;
					
					return array();
				}
			}
		}
		return array();
	}
}
//From: Dism��taobao��com
?>