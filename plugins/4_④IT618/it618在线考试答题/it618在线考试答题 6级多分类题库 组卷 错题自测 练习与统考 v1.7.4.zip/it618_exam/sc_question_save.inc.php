<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$qid=intval($_GET['qid']);

if($_GET['ac']=='add'){
	$it618_class1_id=intval($_GET['it618_class1_id']);
	$it618_class2_id=intval($_GET['it618_class2_id']);
	$it618_class3_id=intval($_GET['it618_class3_id']);
	$it618_class4_id=intval($_GET['it618_class4_id']);
	$it618_qclass11_id=intval($_GET['it618_qclass11_id']);
	$it618_qclass12_id=intval($_GET['it618_qclass12_id']);
	$it618_qclass13_id=intval($_GET['it618_qclass13_id']);
	$it618_qclass21_id=intval($_GET['it618_qclass21_id']);
	$it618_qclass22_id=intval($_GET['it618_qclass22_id']);
	$it618_qclass23_id=intval($_GET['it618_qclass23_id']);
	$it618_qclass24_id=intval($_GET['it618_qclass24_id']);
	$it618_qclass25_id=intval($_GET['it618_qclass25_id']);
	$it618_qclass26_id=intval($_GET['it618_qclass26_id']);
	$it618_qclass3_id=intval($_GET['it618_qclass3_id']);
	$it618_qclass4_id=intval($_GET['it618_qclass4_id']);
	$it618_qtypeid=intval($_GET['it618_qtypeid']);
}else{
	if(!$it618_exam_questions = C::t('#it618_exam#it618_exam_questions')->fetch_by_id($qid)){
		echo $it618_exam_lang['s1195'];exit;
	}
	
	$it618_class1_id=$it618_exam_questions['it618_class1_id'];
	$it618_class2_id=$it618_exam_questions['it618_class2_id'];
	$it618_class3_id=$it618_exam_questions['it618_class3_id'];
	$it618_class4_id=$it618_exam_questions['it618_class4_id'];
	$it618_qclass11_id=$it618_exam_questions['it618_qclass11_id'];
	$it618_qclass12_id=$it618_exam_questions['it618_qclass12_id'];
	$it618_qclass13_id=$it618_exam_questions['it618_qclass13_id'];
	$it618_qclass21_id=$it618_exam_questions['it618_qclass21_id'];
	$it618_qclass22_id=$it618_exam_questions['it618_qclass22_id'];
	$it618_qclass23_id=$it618_exam_questions['it618_qclass23_id'];
	$it618_qclass24_id=$it618_exam_questions['it618_qclass24_id'];
	$it618_qclass25_id=$it618_exam_questions['it618_qclass25_id'];
	$it618_qclass26_id=$it618_exam_questions['it618_qclass26_id'];
	$it618_qclass3_id=$it618_exam_questions['it618_qclass3_id'];
	$it618_qclass4_id=$it618_exam_questions['it618_qclass4_id'];
	$it618_qtypeid=$it618_exam_questions['it618_qtypeid'];
}

if($it618_qclass11_id>0)$cid1=$it618_qclass11_id;
if($it618_qclass12_id>0)$cid1=$it618_qclass12_id;
if($it618_qclass13_id>0)$cid1=$it618_qclass13_id;

if($it618_qclass23_id>0)$cid2=$it618_qclass23_id;
if($it618_qclass24_id>0)$cid2=$it618_qclass24_id;
if($it618_qclass25_id>0)$cid2=$it618_qclass25_id;
if($it618_qclass26_id>0)$cid2=$it618_qclass26_id;

$urlsql='&it618_class1_id='.$it618_class1_id;
$urlsql.='&it618_class2_id='.$it618_class2_id;
$urlsql.='&it618_class3_id='.$it618_class3_id;
$urlsql.='&it618_class4_id='.$it618_class4_id;
$urlsql.='&it618_qclass11_id='.$it618_qclass11_id;
$urlsql.='&it618_qclass12_id='.$it618_qclass12_id;
$urlsql.='&it618_qclass13_id='.$it618_qclass13_id;
$urlsql.='&it618_qclass21_id='.$it618_qclass21_id;
$urlsql.='&it618_qclass22_id='.$it618_qclass22_id;
$urlsql.='&it618_qclass23_id='.$it618_qclass23_id;
$urlsql.='&it618_qclass24_id='.$it618_qclass24_id;
$urlsql.='&it618_qclass25_id='.$it618_qclass25_id;
$urlsql.='&it618_qclass26_id='.$it618_qclass26_id;
$urlsql.='&it618_qclass3_id='.$it618_qclass3_id;
$urlsql.='&it618_qclass4_id='.$it618_qclass4_id;
$urlsql.='&it618_qtypeid='.$it618_qtypeid;

if(submitcheck('it618submit')){
	post('it618submit',$ShopId,$qid,$it618_qtypeid);
}

if(submitcheck('it618submit_close')){
	post('it618submit_close',$ShopId,$qid,$it618_qtypeid);
}

if(submitcheck('it618submit_add')){
	post('it618submit_add',$ShopId,$qid,$it618_qtypeid);
}

function post($type,$shopid,$qid,$it618_qtypeid){
	global $_G,$it618_exam_lang;
	
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($_GET['ac']=='add'){
		$qid=C::t('#it618_exam#it618_exam_questions')->insert(array(
			'it618_shopid' => $shopid,
			'it618_class1_id' => $_GET['it618_class1_id'],
			'it618_class2_id' => $_GET['it618_class2_id'],
			'it618_class3_id' => $_GET['it618_class3_id'],
			'it618_class4_id' => $_GET['it618_class4_id'],
			'it618_qclass11_id' => $_GET['it618_qclass11_id'],
			'it618_qclass12_id' => $_GET['it618_qclass12_id'],
			'it618_qclass13_id' => $_GET['it618_qclass13_id'],
			'it618_qclass21_id' => $_GET['it618_qclass21_id'],
			'it618_qclass22_id' => $_GET['it618_qclass22_id'],
			'it618_qclass23_id' => $_GET['it618_qclass23_id'],
			'it618_qclass24_id' => $_GET['it618_qclass24_id'],
			'it618_qclass25_id' => $_GET['it618_qclass25_id'],
			'it618_qclass26_id' => $_GET['it618_qclass26_id'],
			'it618_qclass3_id' => $_GET['it618_qclass3_id'],
			'it618_qclass4_id' => $_GET['it618_qclass4_id'],
			'it618_qtypeid' => $_GET['it618_qtypeid'],
			'it618_name' => it618_exam_strip_tags(trim($_GET['it618_qname']),'<img> <iframe> <sub> <sup> <u> <br>'),
			'it618_about' => it618_exam_strip_tags(trim($_GET['it618_about']),'<img> <iframe> <sub> <sup> <u> <br>')
		), true);
	}else{
		C::t('#it618_exam#it618_exam_questions')->update($qid,array(
			'it618_class1_id' => $_GET['it618_class1_id'],
			'it618_class2_id' => $_GET['it618_class2_id'],
			'it618_class3_id' => $_GET['it618_class3_id'],
			'it618_class4_id' => $_GET['it618_class4_id'],
			'it618_qclass11_id' => $_GET['it618_qclass11_id'],
			'it618_qclass12_id' => $_GET['it618_qclass12_id'],
			'it618_qclass13_id' => $_GET['it618_qclass13_id'],
			'it618_qclass21_id' => $_GET['it618_qclass21_id'],
			'it618_qclass22_id' => $_GET['it618_qclass22_id'],
			'it618_qclass23_id' => $_GET['it618_qclass23_id'],
			'it618_qclass24_id' => $_GET['it618_qclass24_id'],
			'it618_qclass25_id' => $_GET['it618_qclass25_id'],
			'it618_qclass26_id' => $_GET['it618_qclass26_id'],
			'it618_qclass3_id' => $_GET['it618_qclass3_id'],
			'it618_qclass4_id' => $_GET['it618_qclass4_id'],
			'it618_name' => it618_exam_strip_tags(trim($_GET['it618_qname']),'<img> <iframe> <sub> <sup> <u> <br>'),
			'it618_about' => it618_exam_strip_tags(trim($_GET['it618_about']),'<img> <iframe> <sub> <sup> <u> <br>')
		));
	}
	
	if($it618_qtypeid<=3){
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			DB::delete('it618_exam_questions_option', "id=$delid");
			$del=$del+1;
		}
		
		if(is_array($_GET['it618_name'])) {
			foreach($_GET['it618_name'] as $id => $val) {
				
				if($it618_qtypeid==1){
					if($_GET['it618_isok']==$id)$it618_isok=1;else $it618_isok=0;
				}else{
					$it618_isok=trim($_GET['it618_isok'][$id]);
				}
				
				if($it618_qtypeid==3){
					$it618_name=it618_exam_strip_tags(trim($_GET['it618_name'][$id]));
				}else{
					$it618_name=it618_exam_strip_tags(trim($_GET['it618_name'][$id]),'<img> <iframe> <sub> <sup> <u> <br>');
				}
				
				C::t('#it618_exam#it618_exam_questions_option')->update($id,array(
					'it618_name' => $it618_name,
					'it618_isok' => $it618_isok,
					'it618_order' => trim($_GET['it618_order'][$id])
				));
				$ok1=$ok1+1;
			}
		}
		
		$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
		$newit618_isok_array = !empty($_GET['newit618_isok']) ? $_GET['newit618_isok'] : array();
		$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
		
		foreach($newit618_name_array as $key => $value) {
			
			if(trim($newit618_name_array[$key]) != '') {
				if($it618_qtypeid==1){
					$it618_isok=0;
					if($_GET['it618_isok']=='new'.$key)$it618_isok=1;
				}else{
					$it618_isok=0;
					if(in_array($key,$newit618_isok_array))$it618_isok=1;
				}
				
				if($it618_qtypeid==3){
					$it618_name=it618_exam_strip_tags(trim($newit618_name_array[$key]),'');
				}else{
					$it618_name=it618_exam_strip_tags(trim($newit618_name_array[$key]),'<img> <iframe> <sub> <sup> <u> <br>');
				}
														
				C::t('#it618_exam#it618_exam_questions_option')->insert(array(
					'it618_qid' => $qid,
					'it618_name' => $it618_name,
					'it618_isok' => $it618_isok,
					'it618_order' => trim($newit618_order_array[$key])
				), true);
				$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
			}
		}
	}else{
		C::t('#it618_exam#it618_exam_questions')->update($qid,array(
			'it618_value' => it618_exam_strip_tags(trim($_GET['it618_value']),'<img> <iframe> <sub> <sup> <u> <br>'),
			'it618_isok' => $_GET['it618_isok']
		));
	}	
	
	$opcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$qid);
	$sql = "update ".DB::table('it618_exam_questions')." set it618_optioncount=$opcount where id=".$qid; 
	DB::query($sql);
	
	if($type=='it618submit'){
		it618_cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s34'].$ok2.' '.$it618_exam_lang['s35'].$del.')', "plugin.php?id=it618_exam:sc_question_save&ac=edit&qid=$qid", 'succeed');
	}
	
	if($type=='it618submit_add'){
		echo '<script>parent.getquestions(parent.questionsurl);parent.layer.closeAll();parent.addquestion();</script>';
	}
	
	if($type=='it618submit_close'){
		echo '<script>parent.getquestions(parent.questionsurl);parent.layer.closeAll();</script>';
	}
	
}

it618_showformheader("plugin.php?id=it618_exam:sc_question_save&ac=".$_GET['ac']."&qid=$qid");

showtableheaders('','admin_shopproduct_type');

$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_qtypeid);

$e3css=';display:none';
if($class_set['classname_e3_ishide']!=1){
	$tmpclass3='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_e3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpclass3.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmpclass3=str_replace('<option value='.$it618_class3_id.'>','<option value='.$it618_class3_id.' selected="selected">',$tmpclass3);
	$e3css=';display:';
}

$e4css=';display:none';
if($class_set['classname_e4_ishide']!=1){
	$tmpclass4='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_e4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpclass4.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmpclass4=str_replace('<option value='.$it618_class4_id.'>','<option value='.$it618_class4_id.' selected="selected">',$tmpclass4);
	$e4css=';display:';
}

$q2css=';display:none';
if($class_set['classname_q2_ishide']!=1){
	$q2css=';display:';
}

$q3css=';display:none';
if($class_set['classname_q3_ishide']!=1){
	$tmpqclass3='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_q3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpqclass3.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmpqclass3=str_replace('<option value='.$it618_qclass3_id.'>','<option value='.$it618_qclass3_id.' selected="selected">',$tmpqclass3);
	$q3css=';display:';
}

$q4css=';display:none';
if($class_set['classname_q4_ishide']!=1){
	$tmpqclass4='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_q4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpqclass4.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmpqclass4=str_replace('<option value='.$it618_qclass4_id.'>','<option value='.$it618_qclass4_id.' selected="selected">',$tmpqclass4);
	$q4css=';display:';
}

echo '<tr bgcolor="#f1f1f1"><td width=68><font color=blue>['.$qtypename.']</font></td><td colspan=15 style="font-size:15px">

	<input type="hidden" id="it618_class1_id" name="it618_class1_id" value="'.$it618_class1_id.'">
	<input type="hidden" id="it618_class2_id" name="it618_class2_id" value="'.$it618_class2_id.'">
	<input type="hidden" id="it618_qclass11_id" name="it618_qclass11_id" value="'.$it618_qclass11_id.'">
	<input type="hidden" id="it618_qclass12_id" name="it618_qclass12_id" value="'.$it618_qclass12_id.'">
	<input type="hidden" id="it618_qclass13_id" name="it618_qclass13_id" value="'.$it618_qclass13_id.'">
	<input type="hidden" id="it618_qclass21_id" name="it618_qclass21_id" value="'.$it618_qclass21_id.'">
	<input type="hidden" id="it618_qclass22_id" name="it618_qclass22_id" value="'.$it618_qclass22_id.'">
	<input type="hidden" id="it618_qclass23_id" name="it618_qclass23_id" value="'.$it618_qclass23_id.'">
	<input type="hidden" id="it618_qclass24_id" name="it618_qclass24_id" value="'.$it618_qclass24_id.'">
	<input type="hidden" id="it618_qclass25_id" name="it618_qclass25_id" value="'.$it618_qclass25_id.'">
	<input type="hidden" id="it618_qclass26_id" name="it618_qclass26_id" value="'.$it618_qclass26_id.'">
	<input type="hidden" name="it618_qtypeid" value="'.$it618_qtypeid.'">
	
	<select id="it618_class3_id" name="it618_class3_id" style="margin-right:0px'.$e3css.'">'.$tmpclass3.'</select>
	<select id="it618_class4_id" name="it618_class4_id" style="margin-right:0px'.$e4css.'">'.$tmpclass4.'</select>
	<select id="it618_qclass3_id" name="it618_qclass3_id" style="margin-right:0px'.$q3css.'">'.$tmpqclass3.'</select>
	<select id="it618_qclass4_id" name="it618_qclass4_id" style="margin-right:0px'.$q4css.'">'.$tmpqclass4.'</select>
	
	<div style="margin-top:6px">
	<input type="text" id="classq1" readonly="readonly" style="width:793px;border:#e8e8e8 1px solid;padding:4px 3px" onclick="showclasstree(1)"> <a id="classtreebtn1" href="javascript:" onclick="showclasstree(1)" style="font-size:12px">'.$it618_exam_lang['s1248'].$class_set['classname_q1'].'</a>
	</div>
	
	<div style="margin-top:6px'.$q2css.'">
	<input type="text" id="classq2" readonly="readonly" style="width:793px;border:#e8e8e8 1px solid;padding:4px 3px" onclick="showclasstree(2)"> <a id="classtreebtn2" href="javascript:" onclick="showclasstree(2)" style="font-size:12px">'.$it618_exam_lang['s1248'].$class_set['classname_q2'].'</a>
	</div>
	
	<div id="classtree1" class="classtree" style="display:none;position:absolute;background-color:#f9f9f9;border:#e8e8e8 1px solid;width:520px;height:520px;z-index:1000">
		<iframe id="iframe1" width="100%" height="520" marginwidth="0" marginheight="0" frameborder="no" src="'.$_G['siteurl'].'plugin.php?id=it618_exam:classtree&type=1&cid='.$cid1.'"></iframe>
	</div>
	<div id="classtree2" class="classtree" style="display:none;position:absolute;background-color:#f9f9f9;border:#e8e8e8 1px solid;width:520px;height:520px;z-index:1000">
		<iframe id="iframe2" width="100%" height="520" marginwidth="0" marginheight="0" frameborder="no" src="'.$_G['siteurl'].'plugin.php?id=it618_exam:classtree&type=2&cid='.$cid2.'"></iframe>
	</div>
</td></tr>
<tr><td width=68>'.$it618_exam_lang['s1202'].'</td><td colspan=15><textarea class="textarea" style="width:800px;height:30px;visibility:hidden;" id="it618_qname" name="it618_qname">'.$it618_exam_questions['it618_name'].'</textarea></td></tr>';

echo '
<tr><td>'.$it618_exam_lang['s602'].'</td><td colspan=15><textarea class="textarea" style="width:800px;height:30px;visibility:hidden;margin-bottom:6px" id="it618_about" name="it618_about">'.$it618_exam_questions['it618_about'].'</textarea></td></tr>';

if($it618_qtypeid==1||$it618_qtypeid==2){
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$qid);
	echo '<tr><td colspan=15 style="background-color:#f6f6f6">'.$it618_exam_lang['s1200'].$count.'<span style="float:right;color:red"></span></td></tr>';
	
	showsubtitle(array('', $it618_exam_lang['s1196'], $it618_exam_lang['s1197'],$it618_exam_lang['s1198']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$qid." ORDER BY it618_order,id");
	while($it618_exam_questions_option = DB::fetch($query)) {
		
		if($it618_exam_questions_option['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		if($it618_qtypeid==1){
			$isokstr='<input class="radio" type="radio" name="it618_isok" '.$it618_isok_checked.' value="'.$it618_exam_questions_option['id'].'">';
		}else{
			$isokstr='<input class="checkbox" type="checkbox" name="it618_isok['.$it618_exam_questions_option['id'].']" '.$it618_isok_checked.' value="1">';
		}
	
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_exam_questions_option['id'].'" name="delete[]" value="'.$it618_exam_questions_option['id'].'" '.$disabled.'><label for="chk_del'.$it618_exam_questions_option['id'].'">'.$it618_exam_questions_option['id'].'</label>',
			'<textarea class="textarea" style="width:800px;height:28px;visibility:hidden;" id="it618_name'.$it618_exam_questions_option['id'].'" name="it618_name['.$it618_exam_questions_option['id'].']">'.$it618_exam_questions_option['it618_name'].'</textarea>',
			$isokstr,
			'<input type="text" class="txt" style="width:30px;text-align:center;" name="it618_order['.$it618_exam_questions_option['id'].']" value="'.$it618_exam_questions_option['it618_order'].'">'
		));
		
		$tmpjs.='var editoroption'.$it618_exam_questions_option['id'].' = K.create(\'textarea[id="it618_name'.$it618_exam_questions_option['id'].'"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			minHeight:58,
			newlineTag:"br",
			afterBlur: function () { this.sync(); },
			items : [\'source\', \'|\', \'undo\', \'redo\', \'|\', \'image\',\'multiimage\',\'it618media\', \'|\', \'it618latex\', \'subscript\',
        \'superscript\', \'|\', \'fullscreen\']
		});';
	}
}

if($it618_qtypeid==3){
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$qid);
	echo '<tr><td colspan=15 style="background-color:#f6f6f6">'.$it618_exam_lang['s1200'].$count.'<span style="float:right;color:red">'.$it618_exam_lang['s1469'].'</span></td></tr>';
	
	showsubtitle(array('', $it618_exam_lang['s1467']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$qid." ORDER BY id");
	while($it618_exam_questions_option = DB::fetch($query)) {
	
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_exam_questions_option['id'].'" name="delete[]" value="'.$it618_exam_questions_option['id'].'" '.$disabled.'><label for="chk_del'.$it618_exam_questions_option['id'].'">'.$it618_exam_questions_option['id'].'</label>',
			'<textarea class="textarea" style="width:820px;height:38px"  id="it618_name'.$it618_exam_questions_option['id'].'" name="it618_name['.$it618_exam_questions_option['id'].']">'.$it618_exam_questions_option['it618_name'].'</textarea>'
		));
		
		$tmpjs.='var editoroption'.$it618_exam_questions_option['id'].' = K.create(\'textarea[id="it618_name'.$it618_exam_questions_option['id'].'"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			minHeight:58,
			newlineTag:"br",
			afterBlur: function () { this.sync(); },
			items : [\'source\', \'|\', \'undo\', \'redo\', \'|\', \'image\',\'multiimage\',\'it618media\', \'|\', \'it618latex\', \'subscript\',
        \'superscript\', \'|\', \'fullscreen\']
		});';
	}
}

if($it618_qtypeid==4){
	if($it618_exam_questions['it618_isok']==1)$it618_isok_checked1='checked="checked"';
	if($it618_exam_questions['it618_isok']==0)$it618_isok_checked2='checked="checked"';
	
	echo '<tr><td colspan=15 style="background-color:#f6f6f6">'.$it618_exam_lang['s489'].'
	<input class="radio" type="radio" name="it618_isok" id="isok1" '.$it618_isok_checked1.' value="1"><label for="isok1" style="vertical-align:middle">'.$it618_exam_lang['s490'].'</label>
	<input class="radio" type="radio" name="it618_isok" id="isok2" '.$it618_isok_checked2.' value="0"><label for="isok2" style="vertical-align:middle">'.$it618_exam_lang['s491'].'</label>
	</td></tr>';
}

echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/plugins/code/prettify.js"></script>

<script>
	var curn,TMPK;
	
	KindEditor.ready(function(K) {
		TMPK=K;
		var editor1 = K.create(\'textarea[name="it618_qname"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			newlineTag:"br",
			afterBlur: function () { this.sync(); },
			items : [\'source\', \'|\', \'undo\', \'redo\', \'|\', \'image\',\'multiimage\',\'it618media\', \'|\', \'it618latex\', \'subscript\',
        \'superscript\', \'|\', \'fullscreen\']
		});
		
		var editor2 = K.create(\'textarea[name="it618_about"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			newlineTag:"br",
			afterBlur: function () { this.sync(); },
			items : [\'source\', \'|\', \'undo\', \'redo\', \'|\', \'image\',\'multiimage\',\'it618media\', \'|\', \'it618latex\', \'subscript\',
        \'superscript\', \'|\', \'fullscreen\']
		});
		
		'.$tmpjs.'
	});
	
	function addeditor(n){
		TMPK.create(\'textarea[id="txtname\'+n+\'"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			minHeight:58,
			newlineTag:"br",
			afterBlur: function () { this.sync(); },
			items : [\'source\', \'|\', \'undo\', \'redo\', \'|\', \'image\',\'multiimage\',\'it618media\', \'|\', \'it618latex\', \'subscript\',
        \'superscript\', \'|\', \'fullscreen\']
		});
	}
</script>
';
	
if($it618_qtypeid==1){
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_name[]").length;
		curn=n;
		return [
		[[1,''], 
		[1,'<textarea class="textarea" id="txtname'+n+'" style="width:820px;height:38px;visibility:hidden;" name="newit618_name[]"></textarea>'],
		[1,'<input class="radio" type="radio" name="it618_isok" value="new'+n+'">'],
		[1,'<input type="text" class="txt" style="width:30px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
}

if($it618_qtypeid==2){
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
    	var n=document.getElementsByName("newit618_name[]").length;
        curn=n;
		return [
		[[1,''], 
		[1,'<textarea class="textarea" id="txtname'+n+'" style="width:820px;height:38px;visibility:hidden;" name="newit618_name[]"></textarea>'],
		[1,'<input class="checkbox" type="checkbox" name="newit618_isok[]" value="'+n+'">'],
		[1,'<input type="text" class="txt" style="width:30px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
}

if($it618_qtypeid==3){
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
    	var n=document.getElementsByName("newit618_name[]").length;
        curn=n;
		return [
		[[1,''], 
		[1,'<textarea class="textarea" id="txtname'+n+'" style="width:820px;height:38px;visibility:hidden;" name="newit618_name[]"></textarea>']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
}

if($_GET['ac']=='edit'){
	echo '<script>parent.IT618_EXAM("#divaddtitle").html("'.$it618_exam_lang['s1201'].'")</script>';
}

if($it618_qtypeid<=3){
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0);addeditor(curn)" class="addtr">'.$it618_exam_lang['s831'].'</a></div></td></tr>';
    echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallSlt5" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallSlt5">'.$it618_exam_lang['s556'].'</label></td><td colspan="15"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" style="color:blue" value="'.$it618_exam_lang['s557'].'" /> <input type="submit" class="btn" onclick="return checkvalue();" name="it618submit_add" style="color:#390" value="'.$it618_exam_lang['s558'].'" /> <input type="submit" class="btn" onclick="return checkvalue();" name="it618submit_close" style="color:#666" value="'.$it618_exam_lang['s563'].'" /> &nbsp;<input type=hidden value=1 name=page /></div><br></td></tr>';
}else{
	echo '<tr><td colspan="15"><div class="fixsel"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" style="color:blue" value="'.$it618_exam_lang['s557'].'" /> <input type="submit" class="btn" onclick="return checkvalue();" name="it618submit_add" style="color:#390" value="'.$it618_exam_lang['s558'].'" /> <input type="submit" class="btn" onclick="return checkvalue();" name="it618submit_close" style="color:#666" value="'.$it618_exam_lang['s563'].'" /></div></td></tr>';
}

echo '
<script>
function checkvalue(){
	if(document.getElementById("it618_qname").value==""){
		alert("'.it618_exam_getlang('s564').'");
		document.getElementById("it618_qname").focus();
		return false;
	}
}

function showclasstree(index) {
	var cityObj = $("#classq"+index);
	var cityOffset = $("#classq"+index).offset();

	IT618_EXAM("#classtree"+index).css({left:cityOffset.left + "px", top:cityOffset.top + cityObj.outerHeight() + "px"}).slideDown("fast");
	
	if(index==1){
		IT618_EXAM("body").bind("mousedown", onBodyDown1);
	}else{
		IT618_EXAM("body").bind("mousedown", onBodyDown2);
	}
}

function hideclasstree(index) {
	IT618_EXAM("#classtree"+index).fadeOut("fast");
	if(index==1){
		IT618_EXAM("body").unbind("mousedown", onBodyDown1);
	}else{
		IT618_EXAM("body").unbind("mousedown", onBodyDown2);
	}
}

function onBodyDown1(event) {
	if (!(event.target.id == "classtreebtn1" || event.target.id == "classq1" || event.target.id == "classtree1")) {
		hideclasstree(1);
	}
}

function onBodyDown2(event) {
	if (!(event.target.id == "classtreebtn2" || event.target.id == "classq2" || event.target.id == "classtree2")) {
		hideclasstree(2);
	}
}
</script>
';

echo '<style>.btn{height:35px;width:150px}</style>';

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>