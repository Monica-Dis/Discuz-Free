<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pagetype='index';
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/exam_default.func.php';

if(exam_is_mobile()){ 
	$tmpurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$homehotgoods=it618_exam_template_pchomehotgoods($templatename,$hotclassgoods[2]);

$str_goods=it618_exam_template_pchomeclassgoods($templatename);

$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods')." where it618_chkstate=4 order by UNIX_TIMESTAMP(it618_xgtime1)");
while($it618_exam_goods = DB::fetch($query)) {
	
	$csstmp='1';$csstmp1='';
	if($livecontent==''){
		$tmpcontent=it618_exam_getlivecontent($it618_exam_goods['id']);
		$tmparr=explode("it618_split",$tmpcontent);
		$livecontent=$tmparr[0];
		if($tmparr[1]!=''){
			$timestr='serverTime="'.$tmparr[1].'";
		endTime="'.$tmparr[2].'";
		Czgou();
		curliveid='.$it618_exam_goods['id'].';';
		}
		$csstmp='';
		$csstmp1='style="background-color:#ececec"';
	}
	
	$it618_exam_goods['it618_xgtime1']=strtotime($it618_exam_goods['it618_xgtime1']);
	
	$livestate='';
	if($it618_exam_goods['it618_xgtime1']>$_G['timestamp']){
		$livestate='<font color=red>'.it618_exam_gettime1($it618_exam_goods['it618_xgtime1']).$it618_exam_lang['s1522'].'</font>';
		$imgstr='source/plugin/it618_exam/images/ks0.png';
	}
	
	if($it618_exam_goods['it618_xgtime1']<$_G['timestamp']&&$_G['timestamp']<($it618_exam_goods['it618_xgtime1']+$it618_exam_goods['it618_examtime']*60)){
		$livestate='<font color=#39f>'.$it618_exam_lang['s1523'].'</font>';
		$imgstr='source/plugin/it618_exam/images/ks1.png';
	}

	$livestr.='<li id="'.$it618_exam_goods['id'].'" '.$csstmp1.'>
					<img src="'.$imgstr.'" width="20" class="liimg" style="vertical-align:middle;margin-top:-3px;">&nbsp;&nbsp;
					'.$isuserstr.''.$it618_exam_goods['it618_name'].' '.$livestate.'
				</li>';
}

if($template_set['pchometeacher']>0){
	foreach(C::t('#it618_exam#it618_exam_shop')->fetch_all_by_search(
			'it618_state=2 and it618_htstate=1','it618_order desc,it618_views desc','',0,0,$template_set['pchometeacher']
		) as $it618_exam_shop) {
			
		$tmpurl=it618_exam_getrewrite('exam_teacher',$it618_exam_shop['id'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_shop['id']);
		
		$teacherlists.='<div class="swiper-slide">
					<a href="'.$tmpurl.'" target="_blank" class="i-item">
						<div class="i-avatar-box">
							<img src="'.$it618_exam_shop['it618_ulogo'].'"/>
						</div>
						<div class="i-text-box" title="'.$it618_exam_shop['it618_about'].'">
							<div class="i-name">'.$it618_exam_shop['it618_name'].'</div>
							<div class="i-slogan">'.$it618_exam_shop['it618_about'].'</div>
						</div>
					</a>
				</div>';
	}
}

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename.'/exam_default');
?>