<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

if($_GET['sharetype']=='shop'){
	$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($_GET['shareid']);
	$it618_name=$it618_exam_shop['it618_name'];
	$share_img=$it618_exam_shop['it618_logo'];
	$tmparr=explode('://',$share_img);
	if(count($tmparr)==1)$share_img=$_G['siteurl'].$share_img;
	$it618_about=$it618_exam_shop['it618_about'];
	$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
	$it618_about=cutstr($it618_about,190,'...');
	
	if($IsUnion==1&&$_G['uid']>0){
		$urltmp='tuiuid='.$_G['uid'];
	}
	
	if($urltmp!=''){
		$tmpurl=$_G['siteurl'].it618_exam_getrewrite('exam_teacher',$it618_exam_shop['id'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_shop['id'].'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=$_G['siteurl'].it618_exam_getrewrite('exam_teacher',$it618_exam_shop['id'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_shop['id']);
	}
	
	if($IsWxMini==1){
		if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_exam')){
			$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
		}
	}
	
	$qrcodesrc='plugin.php?id=it618_exam:urlcode&url='.urlencode($tmpurl);

	if($IsUnion==1){
		$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=3 and it618_isshop=1 and it618_state=1");
		if($sharecodecount>0){
			$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=3&class=shop&dataid='.$it618_exam_shop['id'].'&shareurl='.urlencode($tmpurl);
		}
	}
}else{
	$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($_GET['shareid']);
	$pid=$it618_exam_goods['id'];
	$it618_name=$it618_exam_goods['it618_name'];
	$share_img=it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);
	$tmparr=explode('://',$share_img);
	if(count($tmparr)==1)$share_img=$_G['siteurl'].$share_img;
	$it618_about=$it618_exam_goods['it618_description'];
	$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
	$it618_about=cutstr($it618_about,90,'...');
	
	$pricestr=$it618_exam_lang['s1534'];
	$it618_exam_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_exam_shop')." WHERE id=".$it618_exam_goods['it618_shopid']);

	if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
		$pricestr=it618_exam_getgoodsprice($it618_exam_goods,'goods_price');
	}else{
		$pricestr=$it618_exam_lang['s106'];
	}
	
	if($IsUnion==1&&$_G['uid']>0){
		$urltmp='tuiuid='.$_G['uid'];
	}
	
	if($urltmp!=''){
		$tmpurl=$_G['siteurl'].it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id'].'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=$_G['siteurl'].it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
	}
	
	if($IsWxMini==1){
		if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_exam')){
			$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
		}
	}
	
	$qrcodesrc='plugin.php?id=it618_exam:urlcode&url='.urlencode($tmpurl);
	
	if($IsUnion==1){
		$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=3 and it618_isproduct=1 and it618_state=1");
		if($sharecodecount>0){
			$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=3&class=product&dataid='.$it618_exam_goods['id'].'&shareurl='.urlencode($tmpurl);
		}
	}
}

if($IsUnion==1){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
	}
}

$tuicount=intval($_GET['tuicount']);
if($sharecodecount>0||$union_exam_isok>0||$tuicount>0){
	$sharetui=1;
}

if($_GET['wap']==1){
	if($sharetui>0){
		$shoptype='exam';
		$scrolldivheight=$_GET['height']-100;
		
		$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
		$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
		include template('it618_union:unionshare');
		$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
	}
}else{
	if($sharetui>0){
		$shoptype='exam';
		$scrolldivheight=390;
		
		include template('it618_union:unionshare');
	}
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:share');
?>