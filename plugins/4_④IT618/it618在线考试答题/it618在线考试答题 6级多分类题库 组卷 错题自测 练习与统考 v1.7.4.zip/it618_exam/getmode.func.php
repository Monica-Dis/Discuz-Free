<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

function it618_exam_getmodecontent($modetype,$modesql,$modecode,$modecount){
	global $_G,$it618_exam_lang;
	$it618_exam = $_G['cache']['plugin']['it618_exam'];
	
	$tmparr=explode("[loop]",$modecode);
	$tmparr1=explode("[/loop]",$tmparr[1]);
	
	if($modetype=='product_new'||$modetype=='product_hot'||$modetype=='product_sql'){
		if($modetype=='product_new')$orderby='g.id desc';
		if($modetype=='product_hot')$orderby='g.it618_salecount desc';
		if($modetype=='product_sql'){
			$tmparrsql=explode("|",$modesql);
			$shopid=$tmparrsql[2];
			$classid1=$tmparrsql[0];
			$classid2=$tmparrsql[1];
			if($tmparrsql[3]==1){
				$orderby='g.id desc';
			}else{
				$orderby='g.it618_tests desc';
			}
		}

		foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
			'g.it618_gtype=1 and g.it618_state=1',$orderby,$shopid,$classid1,$classid2,$classid3,$classid4,'',0,0,0,$modecount
		) as $it618_exam_goods) {
			
			if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
				$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span class="price" style="color:#390;font-weight:bold">'.$it618_exam_lang['s106'].'</span>';
			}
			
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			$tmpstr=str_replace("{pname}",$it618_exam_goods['it618_name'],$tmparr1[0]);
			$tmpstr=str_replace("{ppicsrc}",it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']),$tmpstr);
			$tmpstr=str_replace("{puprice}",$pricestr,$tmpstr);
			$tmpstr=str_replace("{pprice}",$it618_exam_goods['it618_price'],$tmpstr);
			$tmpstr=str_replace("{pcount}",$it618_exam_goods['it618_count'],$tmpstr);
			$tmpstr=str_replace("{pviews}",$it618_exam_goods['it618_views'],$tmpstr);
			$tmpstr=str_replace("{psalecount}",$it618_exam_goods['it618_salecount'],$tmpstr);
			$tmpstr=str_replace("{purl}",$tmpurl,$tmpstr);
			
			$content.=$tmpstr;
			
		}
	}
	
	if($modetype=='product_zj'||$modetype=='product_weekhot'||$modetype=='product_pin'||$modetype=='product_time'){
		if($modetype=='product_zj'){	
			$query = DB::query("SELECT max(m.id) as maxid,m.it618_pid FROM ".DB::table('it618_exam_sale')." m left join ".DB::table('it618_exam_goods')." g on m.it618_pid=g.id left join ".DB::table('it618_exam_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and m.it618_pid>0 GROUP BY m.it618_pid ORDER BY maxid desc limit 0,".$modecount);
		}
		
		if($modetype=='product_weekhot'){
			$tomonth = date('n'); 
			$todate = date('j'); 
			$toyear = date('Y');
			$time=mktime(0, 0, 0, $tomonth, $todate-7, $toyear);
			$query = DB::query("SELECT m.it618_pid,count(1) as salecount FROM ".DB::table('it618_exam_sale')." m left join ".DB::table('it618_exam_goods')." g on m.it618_pid=g.id left join ".DB::table('it618_exam_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and m.it618_pid>0 and m.it618_time>=$time GROUP BY m.it618_pid ORDER BY salecount desc limit 0,".$modecount);
		}
		
		if($modetype=='product_pin'){
			$query = DB::query("SELECT p.it618_pid FROM ".DB::table('it618_pinedu_goods')." p left join ".DB::table('it618_exam_goods')." g on p.it618_pid=g.id left join ".DB::table('it618_exam_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and p.it618_shoptype='exam' GROUP BY p.it618_pid limit 0,".$modecount);
		}
		
		if($modetype=='product_time'){
			$query = DB::query("SELECT id as it618_pid from ".DB::table('it618_exam_goods')." where it618_xgtype>0 and UNIX_TIMESTAMP(it618_xgtime2)>".$_G['timestamp']." order by it618_xgtime2 limit 0,".$modecount);
		}
		
		while($it618_homegoods = DB::fetch($query)) {
			$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
			if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
				$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span class="price" style="color:#390;font-weight:bold">'.$it618_exam_lang['s106'].'</span>';
			}
			
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			$tmpstr=str_replace("{pname}",$it618_exam_goods['it618_name'],$tmparr1[0]);
			$tmpstr=str_replace("{ppicsrc}",it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']),$tmpstr);
			$tmpstr=str_replace("{puprice}",$pricestr,$tmpstr);
			$tmpstr=str_replace("{pprice}",$it618_exam_goods['it618_price'],$tmpstr);
			$tmpstr=str_replace("{pcount}",$it618_exam_goods['it618_count'],$tmpstr);
			$tmpstr=str_replace("{pviews}",$it618_exam_goods['it618_views'],$tmpstr);
			$tmpstr=str_replace("{psalecount}",$it618_exam_goods['it618_salecount'],$tmpstr);
			$tmpstr=str_replace("{purl}",$tmpurl,$tmpstr);
			
			$content.=$tmpstr;
		}
	}
	
	$content=$tmparr[0].$content.$tmparr1[1];
	$content=str_replace("{siteurl}",$_G['siteurl'],$content);
	
	return $content;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>