<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_exam_shop`;

DROP TABLE IF EXISTS `pre_it618_exam_shop_subscribe`;

DROP TABLE IF EXISTS `pre_it618_exam_nav`;

DROP TABLE IF EXISTS `pre_it618_exam_focus`;

DROP TABLE IF EXISTS `pre_it618_exam_class1`;

DROP TABLE IF EXISTS `pre_it618_exam_class2`;

DROP TABLE IF EXISTS `pre_it618_exam_class3`;

DROP TABLE IF EXISTS `pre_it618_exam_class4`;

DROP TABLE IF EXISTS `pre_it618_exam_qclass1`;

DROP TABLE IF EXISTS `pre_it618_exam_qclass2`;

DROP TABLE IF EXISTS `pre_it618_exam_qclass3`;

DROP TABLE IF EXISTS `pre_it618_exam_qclass4`;

DROP TABLE IF EXISTS `pre_it618_exam_qtype`;

DROP TABLE IF EXISTS `pre_it618_exam_questions`;

DROP TABLE IF EXISTS `pre_it618_exam_questions_option`;

DROP TABLE IF EXISTS `pre_it618_exam_goods`;

DROP TABLE IF EXISTS `pre_it618_exam_goods_type`;

DROP TABLE IF EXISTS `pre_it618_exam_goods_lesson`;

DROP TABLE IF EXISTS `pre_it618_exam_goods_questions`;

DROP TABLE IF EXISTS `pre_it618_exam_goods_count`;

DROP TABLE IF EXISTS `pre_it618_exam_test`;

DROP TABLE IF EXISTS `pre_it618_exam_test_exam`;

DROP TABLE IF EXISTS `pre_it618_exam_test_exam_questions`;

DROP TABLE IF EXISTS `pre_it618_exam_test_pj`;

DROP TABLE IF EXISTS `pre_it618_exam_test_pjpic`;

DROP TABLE IF EXISTS `pre_it618_exam_sale`;

DROP TABLE IF EXISTS `pre_it618_exam_gwc`;

DROP TABLE IF EXISTS `pre_it618_exam_gwcsale_main`;

DROP TABLE IF EXISTS `pre_it618_exam_gwcsale`;

DROP TABLE IF EXISTS `pre_it618_exam_bank`;

DROP TABLE IF EXISTS `pre_it618_exam_txbl`;

DROP TABLE IF EXISTS `pre_it618_exam_tx`;

DROP TABLE IF EXISTS `pre_it618_exam_jfhl`;

DROP TABLE IF EXISTS `pre_it618_exam_set`;

DROP TABLE IF EXISTS `pre_it618_exam_style`;

DROP TABLE IF EXISTS `pre_it618_exam_wapstyle`;

DROP TABLE IF EXISTS `pre_it618_exam_iconav`;

DROP TABLE IF EXISTS `pre_it618_exam_gonggao`;

DROP TABLE IF EXISTS `pre_it618_exam_diy`;

DROP TABLE IF EXISTS `pre_it618_exam_findkey`;

DROP TABLE IF EXISTS `pre_it618_exam_bottomnav`;

DROP TABLE IF EXISTS `pre_it618_exam_examwork`;

DROP TABLE IF EXISTS `pre_it618_exam_salework`;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>