<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_exam;

$it618_exam = $_G['cache']['plugin']['it618_exam'];
$creditname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/template.func.php';

function it618_exam_getisvipuser($vipgroupids){
	global $_G,$it618_exam,$it618_exam_lang;
	
	$okvipgroupids = array(array(),array());
	
	if(count($vipgroupids)>0){

		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
	
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$expgrouparray = $expirylist = $termsarray = array();
	
		if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
			$termsarray = $groupterms['ext'];
		}
		if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
			$termsarray[$_G['groupid']] = $groupterms['main']['time'];
		}
		
		foreach($termsarray as $expgroupid => $expiry) {
			if($expiry <= TIMESTAMP) {
				$expgrouparray[] = $expgroupid;
			}
		}
	
		$groupids = array();
		foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
			if(!empty($usergroup['pubtype'])) {
				$groupids[] = $groupid;
			}
		}
		
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
			}
		}
		
		if(!empty($groupterms['main'])) {
			$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
		}
		
		$expiryids = array_keys($expirylist);
		$groupids = array_merge($extgroupids, $expiryids, $groupids);
		
		if($groupids) {
			foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
				$groupid=$group['groupid'];
				
				if(in_array($groupid, $vipgroupids)){
					
					$isgroupok=1;
					if($group['type']!='system'&&$group['type']!='member'){
						$timestamp=$expirylist[$group['groupid']]['timestamp'];
						$grouptime=$expirylist[$group['groupid']]['time'];
						
						if($timestamp-3600*24*365*60>$_G['timestamp']||$grouptime==''){
							$grouptime=$it618_exam_lang['s1273'];
						}elseif($timestamp<$_G['timestamp']){
							$isgroupok=0;
						}
					}else{
						$grouptime='';
					}
					if($isgroupok==1){
						$okvipgroupids[0][]=$groupid;
						$okvipgroupids[1][]=$grouptime;
					}
				}
			}
		}
		
		if(!in_array($_G['groupid'], $okvipgroupids[0])){
			if(in_array($_G['groupid'], $vipgroupids)){
				$okvipgroupids[0][]=$_G['groupid'];
				$timestamp=$_G['member']['groupexpiry'];
				if($timestamp>0){
					$timestamp= dgmdate($timestamp, 'd');
				}
				$okvipgroupids[1][]=$timestamp;
			}
		}

	}
	
	return $okvipgroupids;
}

function it618_exam_getvipzk($pid){
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='exam' and it618_pid=$pid and it618_zk>0 order by it618_zk");
	while($it618_group_group_zk = DB::fetch($query)) {
		$vipzkgroupids[] = $it618_group_group_zk['it618_groupid'];
		
		$okvipgroupids=it618_exam_getisvipuser($vipzkgroupids);
		if(in_array($it618_group_group_zk['it618_groupid'], $okvipgroupids[0])){
			return $it618_group_group_zk['it618_zk'];
		}
	}
	return 0;
}

function it618_exam_getvideopower($pid,$lid){
	global $_G,$it618_exam;
	
	$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
	
	$isgoodsprice=0;
	if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
		$isgoodsprice=1;
	}
	
	$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
	if($it618_video_shop['it618_issale']==0){
		$isgoodsprice=1;
	}
	
	if($isgoodsprice==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
		$videopower=it618_video_getpower($_G['uid'],$pid,$lid,0);
		
		if($videopower['state']>0){
			return 1;
		}else{
			$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
			if(count($vipgroupids)>0){
				$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
				$isvipuser=count($tmpgrouparr[0]);
				if($isvipuser>0)return 1;
			}
		}
	}
	
	return 0;
}

function it618_exam_getgoodsvipgroupids($it618_exam_goods){
	global $_G,$it618_exam;
	
	$vipgroupids = array();
	
	if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
	
		$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_vipgroup')." WHERE it618_pid=".$it618_exam_goods['id']." and it618_isok=1");
		while($it618_exam_goods_vipgroup =	DB::fetch($query)) {
			if($it618_exam_goods_vipgroup['it618_groupid']>0){
				if(!in_array($it618_exam_goods_vipgroup['it618_groupid'], $vipgroupids)){
					$vipgroupids[]=$it618_exam_goods_vipgroup['it618_groupid'];
				}
			}
		}
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_exam_class_vipgroup')." WHERE it618_class1_id=".$it618_exam_goods['it618_class1_id']." and it618_isok=1");
		while($it618_exam_class_vipgroup =	DB::fetch($query)) {
			if($it618_exam_class_vipgroup['it618_groupid']>0){
				if(!in_array($it618_exam_class_vipgroup['it618_groupid'], $vipgroupids)){
					$vipgroupids[]=$it618_exam_class_vipgroup['it618_groupid'];
				}
			}
		}
	
	}
	
	return $vipgroupids;
}

function it618_exam_groupsalepower($pid){
	$vipgroupids_zk = array();$vipgroupids_sale = array();
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_salepower')." where it618_shoptype='exam' and it618_pid=$pid and it618_isok=1");
	while($it618_group_group_salepower = DB::fetch($query)) {
		if(!in_array($it618_group_group_salepower['it618_groupid'], $vipgroupids_sale)){
			$vipgroupids_sale[]=$it618_group_group_salepower['it618_groupid'];
		}
	}
	
	if(count($vipgroupids_sale)>0){
		$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='exam' and it618_pid=$pid and it618_zk>0");
		while($it618_group_group_zk = DB::fetch($query)) {
			if(!in_array($it618_group_group_zk['it618_groupid'], $vipgroupids_zk)){
				$vipgroupids_zk[]=$it618_group_group_zk['it618_groupid'];
			}
		}
		
		$vipgroupids=array_merge($vipgroupids_zk,$vipgroupids_sale);
	
		$okvipgroupids=it618_exam_getisvipuser($vipgroupids);
		
		if(count($okvipgroupids[0])==0){
			if(count($vipgroupids_zk)>0){
				return 2;
			}else{
				return 1;
			}
		}
	}
}

function it618_exam_pay($type,$title){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		return;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype();
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		if($type=='pay'){
			$paystr='<li style="margin-top:15px; height:20px; margin-bottom:0" id="payselect">'.$title.$tmpstr.'</li>';
		}
		
		if($type=='paywap'){
			$paystr='<tr id="payselect"><td style=" padding-top:3px">'.$tmpstr.'</td></tr>';
		}
		
		if($type=='gwc'){
			$paystr='<div class="buy-block" id="payselect">
					<div class="buy-block-title"><h3>'.$title.'</h3></div>
					<div style="padding:10px">'.$tmpstr.'</div>
					</div>';
		}
		
		if($type=='gwcwap'){
			$paystr='<table width="100%" class="gwctable" bgcolor="#FFFFFF" id="payselect">
					<tr><td><table width="100%">
					<tr class="gwctrtitle">
					<th style="padding-left:3px">'.$title.'</th>
					</tr>
					</table></td></tr><tr><td style="padding:3px">
					'.$tmpstr.'
					</td></tr></table>';
		}
	}else{
		$paystr=$tmpstr.'<span id="payselect"></span>';
	}
    
	return $paystr;
}

function it618_exam_strip_tags($value,$html=''){
	$value1=str_replace('&nbsp;','',$value);
	$tmpstr=strip_tags($value1,$html);
	if($value1!=$value){
		$tmpstr=str_replace('<u>  </u>','_______',$tmpstr);
		$tmpstr=str_replace('<u></u>','_______',$tmpstr);
		$tmpstr=str_replace('<u> </u>','_______',$tmpstr);
	}
	return $tmpstr;
}

function it618_exam_getlivecontent($pid,$wap=0){
	global $_G,$it618_exam,$it618_exam_lang;
	
	if($it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid)){
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
		
		$goodspic=it618_exam_getgoodspic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig'],0);
		
		$it618_exam_goods['it618_xgtime1']=strtotime($it618_exam_goods['it618_xgtime1']);
		
		if($wap==0){
			$livestate='';
			if($it618_exam_goods['it618_xgtime1']>$_G['timestamp']){
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $it618_exam_goods['it618_xgtime1']);
				
				$livestate='<div class="livecountdown" style="background-color:rgba(10,10,10,0.5); width:300px; padding:6px; margin-left:150px; border-radius:10px;">
							<span>00</span>
							<em>'.$it618_exam_lang['t308'].'</em>
							<span>00</span>
							<em>'.$it618_exam_lang['t309'].'</em>
							<span>00</span>
							<em>'.$it618_exam_lang['t310'].'</em>
							<span>00</span>
							<em>'.$it618_exam_lang['t311'].'</em>
							<span>00</span>
						  </div>';
			}
			
			if($it618_exam_goods['it618_xgtime1']<$_G['timestamp']&&$_G['timestamp']<($it618_exam_goods['it618_xgtime1']+$it618_exam_goods['it618_examtime']*60)){
				$livestate='<div style="background-color:rgba(10,10,10,0.5); width:200px; padding:6px; margin-left:200px; border-radius:10px;font-size:18px; color:#fff;">
							<img src="source/plugin/it618_exam/images/ks1.png" /> '.$it618_exam_lang['s1317'].'
						  </div>';
			}
			
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
			
			$livecontent='<div style="position:absolute;">
				<img width="590" height="338" border="0" src="'.$goodspic.'">
				</div>
			   <div style="position:absolute;width:590px; height:278px;background-color:rgba(50,50,50,0.6);text-align:center;"><div style="position:absolute; top:55px;width:590px; text-align:center; font-size:22px; color:#fff">'.$it618_exam_goods['it618_name'].'</div>
			  <div class="divlive" style="position: absolute;top:120px;left: 0;width: 100%;text-align:center; color:#fff; font-size:23px">
			  '.$livestate.'
			   <a href="'.$tmpurl.'" class="salebtn" style="margin-top:10px; margin-left:239px" target="_blank">'.$it618_exam_lang['s1831'].'</a>
			   </div>
			   </div>
			   <div style="position:absolute; bottom:0px;width:570px;font-size:16px; color:#fff; background-color:rgba(10,10,10,0.5); height:40px; padding:10px 10px"><a class="bottomkca" href="'.$tmpurl.'" target="_blank">'.$it618_exam_lang['s191'].$it618_exam_goods['it618_examtime'].''.$it618_exam_lang['s192'].' '.$it618_exam_lang['s1111'].''.$it618_exam_goods['it618_examscore'].'</a><img src="'.$it618_exam_shop['it618_ulogo'].'" height="40" style="border-radius:20px; margin-right:10px" />'.it618_exam_getsmsstr($it618_exam_shop['it618_name'],10).'</div>';
		}else{
			$livestate='';
			if($it618_exam_goods['it618_xgtime1']>$_G['timestamp']){
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $it618_exam_goods['it618_xgtime1']);
				
				$livestate='<div class="livecountdown">
							<span style="color:#39F">00</span>
							<em>'.$it618_exam_lang['t308'].'</em>
							<span style="color:#39F">00</span>
							<em>'.$it618_exam_lang['t309'].'</em>
							<span style="color:#39F">00</span>
							<em>'.$it618_exam_lang['t310'].'</em>
							<span style="color:#39F">00</span>
							<em>'.$it618_exam_lang['t311'].'</em>
							<span style="color:#39F">00</span>
						  </div>';
			}
			
			if($it618_exam_goods['it618_xgtime1']<$_G['timestamp']&&$_G['timestamp']<($it618_exam_goods['it618_xgtime1']+$it618_exam_goods['it618_examtime']*60)){
				$livestate='<img src="source/plugin/it618_exam/images/ks1.png" height="20" style="margin-top:-3px" /> '.$it618_exam_lang['s1317'];
			}
			
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
			
			$livecontent='<td width="146" style="padding-top:13px;padding-bottom:13px;border-bottom:#f3f3f3 1px solid;position:relative">
			<a href="'.$tmpurl.'" target="_blank"><img width="138" border="0" style="border-radius:3px;" src="'.$goodspic.'"></a>
			<div style="position:absolute;top:13px;width:138px;background-color:rgba(0,0,0,0.1);text-align:center; height:78px"><a href="'.$tmpurl.'" target="_blank"><div  style="width:68px; height:23px;line-height:23px; border-radius:20px; margin-top:28px;color:#fff;border:#fff 1px solid;margin-left:33px">'.$it618_exam_lang['s1831'].'</div></a>
			</div></td>
			<td style="padding-top:11px;vertical-align:top;border-bottom:#f3f3f3 1px solid">
			<div style="margin-bottom:3px;line-height:20px;height:40px;"><a href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.cutstr($it618_exam_goods['it618_name'],58,'...').'</a></div>
			<div style="font-size:12px;color:#999;margin-top:0px;">
			<div style="font-size:11px;line-height:15px;margin-bottom:10px;">'.$livestate.'</div>
			<div style="margin-top:-3px"><img src="'.$it618_exam_shop['it618_ulogo'].'" height="18" style="border-radius:10px; margin-right:3px;margin-top:-5px" />'.cutstr($it618_exam_shop['it618_name'],26,'...').'</div></div>
			</td>';
		}

		return $livecontent.'it618_split'.$btimestr.'it618_split'.$etimestr;
	}	
}

function it618_exam_getsmsstr($strtmp,$length){
	if($length>0){
		return cutstr($strtmp,$length,'...');
	}
	return $strtmp;
}

function it618_exam_issecretok($it618_exam_goods){
	global $_G,$it618_exam,$it618_exam_lang;
	
	if($it618_exam_goods['it618_issecret']==1){
		$it618_secretusers=explode(",",$it618_exam_goods['it618_secretusers']);
		
		if($_G['uid']>0){
			if(!in_array($_G['uid'], $it618_secretusers)){
				if($it618_exam_goods['it618_shopuid']!=$_G['uid']){
					$exam_shopadmin=explode(",",$it618_exam['exam_shopadmin']);
					if(!in_array($_G['uid'], $exam_shopadmin)){
						return false;
					}
				}
			}
		}else{
			return false;
		}
	}
	
	return true;
}

function it618_exam_updategoodscount($it618_exam_sale,$type=''){	
	$dotmp='-';
	if($type=='tui'){
		$dotmp='+';
	}
	if($it618_exam_sale['it618_gtypeid']>0){
		$salecount = C::t('#it618_exam#it618_exam_sale')->sumcount_by_it618_gtypeid($it618_exam_sale['it618_gtypeid']);
		if($salecount=='')$salecount=0;
		
		DB::query("update ".DB::table('it618_exam_goods_type')." set it618_salecount=".$salecount.",it618_count=it618_count".$dotmp.$it618_exam_sale['it618_count']." where id=".$it618_exam_sale['it618_gtypeid']);
	}
	
	$salecount = C::t('#it618_exam#it618_exam_sale')->sumcount_by_it618_pid1($it618_exam_sale['it618_pid']);
	if($salecount=='')$salecount=0;
	
	DB::query("update ".DB::table('it618_exam_goods')." set it618_salecount=".$salecount." where id=".$it618_exam_sale['it618_pid']);
}

function it618_exam_getABC($num){
	if($num==1)return 'A';
	if($num==2)return 'B';
	if($num==3)return 'C';
	if($num==4)return 'D';
	if($num==5)return 'E';
	if($num==6)return 'F';
	if($num==7)return 'G';
	if($num==8)return 'H';
	if($num==9)return 'I';
	if($num==10)return 'J';
	if($num==11)return 'K';
	if($num==12)return 'L';
}

function it618_exam_isABC($str){
	if($str=='A')return true;
	if($str=='B')return true;
	if($str=='C')return true;
	if($str=='D')return true;
	if($str=='E')return true;
	if($str=='F')return true;
	if($str=='G')return true;
	if($str=='H')return true;
	if($str=='I')return true;
	if($str=='J')return true;
	if($str=='K')return true;
	if($str=='L')return true;
	return false;
}

function it618_exam_getquestionname($name){
	$name=str_replace("{}","______",$name);
	return $name;
}

function it618_exam_getpower($uid,$pid){
	global $_G,$it618_exam,$it618_exam_lang;
	
	$exampower['state']=0;
	$exampower['count']='';
	if($it618_exam_goods_count=C::t('#it618_exam#it618_exam_goods_count')->fetch_by_uid_pid($uid,$pid)){
		$tmpcount=$it618_exam_goods_count['it618_count']-$it618_exam_goods_count['it618_testcount'];
		if($tmpcount>0){
			$exampower['state']=1;
			$exampower['count']=$_G['username'].' '.$it618_exam_lang['s1155'].$it618_exam_goods_count['it618_count'].$it618_exam_lang['s1156'];
		}
//		$it618_exam_lang['s825']=str_replace("{username}",$_G['username'],$it618_exam_lang['s825']);
//		$it618_exam_lang['s825']=str_replace("{ygcount}",$it618_exam_goods_count['it618_count'],$it618_exam_lang['s825']);
//		$it618_exam_lang['s825']=str_replace("{ykcount}",intval($it618_exam_goods_count['it618_testcount']),$it618_exam_lang['s825']);
//		$it618_exam_lang['s825']=str_replace("{wkcount}",$tmpcount,$it618_exam_lang['s825']);
		//$exampower['count']=$it618_exam_lang['s825'];
		$exampower['count']=' ('.$it618_exam_lang['t3'].$tmpcount.$it618_exam_lang['s1156'].')';
	}
	
	return $exampower;
}

function it618_exam_getexam($eid,$wap){
	global $_G,$it618_exam,$it618_exam_lang;
	
	$it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($eid);
	if($it618_exam_test_exam['it618_state']==3){
		$disabled='disabled="disabled"';
		$readonly='readonly="readonly"';
	}
	
    $ln=1;
	$lidmenustr='<li class="current" onclick="it618_exam_tabChange_test(this,0);">'.$it618_exam_lang['s466'].'</li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_lesson')." WHERE it618_pid=".$it618_exam_test_exam['it618_pid']." ORDER BY it618_order");
	while($it618_exam_goods_lesson = DB::fetch($query)) {
		$tmpindexarr=explode("|",$it618_exam_lang['s488']);
        if($wap==1){
			$it618_nametmp=cutstr(it618_exam_strip_tags($tmpindexarr[$ln-1].$it618_exam_goods_lesson['it618_name']),4,'');
		}else{
			$it618_nametmp=cutstr(it618_exam_strip_tags($tmpindexarr[$ln-1].$it618_exam_goods_lesson['it618_name']),10,'');
		}
		
		$lidmenustr.='<li onclick="it618_exam_tabChange_test(this,'.$it618_exam_goods_lesson['id'].');" title="'.it618_exam_strip_tags($tmpindexarr[$ln-1].$it618_exam_goods_lesson['it618_name']).'">'.$it618_nametmp.'</li>';
        $ln=$ln+1;
	}
	
	$n=1; $ln=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_test_exam_questions')." WHERE it618_eid=".$eid." ORDER BY it618_order,id");
	while($it618_exam_test_exam_questions = DB::fetch($query)) {
		
		$it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($it618_exam_test_exam_questions['it618_qid']);
		$it618_qtypeid=$it618_exam_questions['it618_qtypeid'];
		
        if($tmplid!=$it618_exam_test_exam_questions['it618_lid']){
        	$tmplid=$it618_exam_test_exam_questions['it618_lid'];
            $tmpindexarr=explode("|",$it618_exam_lang['s488']);
			$it618_exam_goods_lesson=C::t('#it618_exam#it618_exam_goods_lesson')->fetch_by_id($it618_exam_test_exam_questions['it618_lid']);
            $tmplname=$tmpindexarr[$ln-1].$it618_exam_goods_lesson['it618_name'];
            $ln=$ln+1;
        }
		
		$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_qtypeid);
		
		$it618_name=$it618_exam_questions['it618_name'];
		$it618_about=$it618_exam_questions['it618_about'];
		if($it618_qtypeid==3){
			$it618_name=it618_exam_getquestionname($it618_name);
		}
		if($it618_exam_goods_lesson['it618_shareabout']==1){
			$it618_about=$it618_exam_goods_lesson['it618_about'];
		}
		
		$it618_exam_test_exam_questions['it618_score']=str_replace(".0","",$it618_exam_test_exam_questions['it618_score']);
		
		$iserr=0;$csstmp3='display:none';
		if($it618_exam_test_exam['it618_state']==3){
			$it618_exam_test_exam_questions['it618_testscore']=str_replace(".0","",$it618_exam_test_exam_questions['it618_testscore']);
			$it618_testscore=' <span class="testscore">'.$it618_exam_lang['s533'].$it618_exam_test_exam_questions['it618_testscore'].$it618_exam_lang['s1144'].'</span>';
			$csstmp='#f30';
			if($it618_exam_test_exam_questions['it618_testscore']==$it618_exam_test_exam_questions['it618_score']){
				$csstmp='#390';
			}
			
			if($it618_qtypeid==5){
				$iserr=2;
			}else{
				if($it618_exam_test_exam['it618_uid']==$_G['uid']){
					if(C::t('#it618_exam#it618_exam_errquestions')->count_by_qid_uid($it618_exam_questions['id'],$it618_exam_test_exam['it618_uid'])>0){
						$iserr=1;
						$csstmp3='display:';
					}	
				}
			}
				
			$rightmenu='
			<span style="'.$csstmp3.'" class="spanerr">'.$it618_exam_lang['s1835'].'</span>
			<span style="color:'.$csstmp.'">'.$it618_exam_lang['s533'].$it618_exam_test_exam_questions['it618_testscore'].$it618_exam_lang['s1144'].'</span>';
		}else{
			$csstmp1='display:';$csstmp2='display:none';
			if($it618_exam_test_exam_questions['it618_value']!=''){
				$csstmp1='display:none';
				$csstmp2='display:';
			}
			if($it618_exam_test_exam_questions['it618_isbj']==1){
				$csstmp3='display:';
			}
			
			$rightmenu='
			<span style="'.$csstmp3.'" class="spanbj">'.$it618_exam_lang['s666'].'</span>
			<span style="color:#f30;'.$csstmp1.'" class="spanwzd">'.$it618_exam_lang['s235'].'</span><span style="color:#390;'.$csstmp2.'" class="spanyzd">'.$it618_exam_lang['s237'].'</span>';
		}
		
		if($wap==1){
			$it618_nametmp=cutstr(it618_exam_strip_tags($it618_name),26,'...');
		}else{
			$it618_nametmp=cutstr(it618_exam_strip_tags($it618_name),68,'...');
		}
		
		$it618_mcqscore='';
		if($it618_exam_test_exam_questions['it618_mcqscore']>0&&$it618_qtypeid==2){
			$it618_exam_test_exam_questions['it618_mcqscore']=str_replace(".0","",$it618_exam_test_exam_questions['it618_mcqscore']);
			$it618_mcqscore=$it618_exam_lang['s242'].$it618_exam_test_exam_questions['it618_mcqscore'].$it618_exam_lang['s1144'];
		}
		
		$it618_name=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder="0" allowfullscreen="1"/>',$it618_name);
		$it618_about=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder="0" allowfullscreen="1"/>',$it618_about);
		
		if($wap==1){
			$tmparriframe=explode('&it618mediatype=audio"',$it618_name);
			if(count($tmparriframe)>1){
				$it618_name=str_replace('&it618mediatype=audio"','" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$it618_name);
			}else{
				$it618_name=str_replace('allowfullscreen="1"','" width="640" height="220"',$it618_name);
			}
			
			$tmparriframe=explode('&it618mediatype=audio"',$it618_about);
			if(count($tmparriframe)>1){
				$it618_about=str_replace('&it618mediatype=audio','" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$it618_about);
			}else{
				$it618_about=str_replace('allowfullscreen="1"','" width="640" height="220"',$it618_about);
			}
			
		}else{
			
			$tmparriframe=explode('&it618mediatype=audio"',$it618_name);
			if(count($tmparriframe)>1){
				$it618_name=str_replace('&it618mediatype=audio"','" style="border:0;width:780px;height:53px" scrolling="no" frameborder=0',$it618_name);
			}else{
				$tmparriframe=explode('bilibili.com',$it618_name);
				if(count($tmparriframe)>1){
					$it618_name=str_replace('allowfullscreen="1"','" width="700" height="464"',$it618_name);
				}else{
					$it618_name=str_replace('allowfullscreen="1"','" width="700" height="394"',$it618_name);	
				}
			}
			
			$tmparriframe=explode('&it618mediatype=audio"',$it618_about);
			if(count($tmparriframe)>1){
				$it618_about=str_replace('&it618mediatype=audio"','" style="border:0;width:780px;height:53px" scrolling="no" frameborder=0',$it618_about);
			}else{
				$tmparriframe=explode('bilibili.com',$it618_about);
				if(count($tmparriframe)>1){
					$it618_about=str_replace('allowfullscreen="1"','" width="700" height="464"',$it618_about);
				}else{
					$it618_about=str_replace('allowfullscreen="1"','" width="700" height="394"',$it618_about);	
				}
			}
		}
		
		$it618_exam_goods_lesson['it618_examscore']=str_replace(".0","",$it618_exam_goods_lesson['it618_examscore']);
		$tmplessonstr=str_replace("{qcount}",$it618_exam_goods_lesson['it618_questioncount'],$it618_exam_lang['s193']);
		$tmplessonstr=str_replace("{score}",$it618_exam_goods_lesson['it618_examscore'],$tmplessonstr);
		
		$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_qtypeid);
		
		$examstr.='<tr id="exam_questions_'.$n.'" class="exam_questions"><td><form id="form'.$n.'">
						<input type="hidden" id="eqid'.$n.'" name="eqid" value="'.$it618_exam_test_exam_questions['id'].'">
						<input type="hidden" id="elid'.$n.'" value="'.$it618_exam_test_exam_questions['it618_lid'].'">
						<div class="qlname">'.$tmplname.'<br><span>'.$tmplessonstr.'</span></div>
						<span id="eqname'.$n.'" style="display:none">
						<span style="float:right">'.$rightmenu.'</span>
						'.$n.$it618_exam_lang['s1103'].'['.$qtypename.'] '.$it618_nametmp.'('.$it618_exam_test_exam_questions['it618_score'].$it618_exam_lang['s1144'].$it618_mcqscore.')
						</span>
						<input type="hidden" id="eqbj'.$n.'" name="eqbj" value="'.$it618_exam_test_exam_questions['it618_isbj'].'">
						<input type="hidden" id="eqerr'.$n.'" value="'.$iserr.'">
						<span class="spantime"><span class="qindex"><span class="curindex">'.$n.'</span>/'.$it618_exam_test_exam['it618_questioncount'].'</span><span class="qtypename">'.$qtypename.'</span> ('.$it618_exam_test_exam_questions['it618_score'].$it618_exam_lang['s1144'].$it618_mcqscore.')'.$it618_testscore.'</span><br>
						<div class="qname">'.$it618_name.'</div>
						{exam_questions}
					</form></td></tr>';
		
		$optionstr='';
		if($it618_qtypeid==1||$it618_qtypeid==2){
			$on=1;
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']." ORDER BY it618_order,id");
			while($it618_exam_questions_option = DB::fetch($query2)) {
				if($it618_qtypeid==1){
					$checkedstr='';
					if($it618_exam_test_exam_questions['it618_value']==$it618_exam_questions_option['id']){
						$checkedstr='checked="checked"';
					}
					$tmpquestions='<input type="radio" name="questionvalue" '.$disabled.' value="'.$it618_exam_questions_option['id'].'" id="chk'.$it618_exam_questions_option['id'].'" '.$checkedstr.'>';
				}else{
					$checkedstr='';
					$tmpvaluearr=explode("it618_split",$it618_exam_test_exam_questions['it618_value']);
					if(in_array($it618_exam_questions_option['id'],$tmpvaluearr)){
						$checkedstr='checked="checked"';
					}
					$tmpquestions='<input type="checkbox" name="questionvalue[]" '.$disabled.' value="'.$it618_exam_questions_option['id'].'" id="chk'.$it618_exam_questions_option['id'].'" '.$checkedstr.'>';
				}
				
				$tmpcss='';
				if($it618_exam_questions_option['it618_isok']==1){
					$tmpcss='class="rightanswercolor'.$n.'"';
				}
				
				$it618_optionname=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder="0" allowfullscreen="1"/>',$it618_exam_questions_option['it618_name']);
				
				if($wap==1){
					$it618_optionname=str_replace('&it618mediatype=audio"','" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$it618_optionname);
					$it618_optionname=str_replace('&it618mediatype=video"','" width="640" height="220"',$it618_optionname);
				}else{
					$it618_optionname=str_replace('&it618mediatype=audio"','" style="border:0;width:780px;height:53px" scrolling="no" frameborder=0',$it618_optionname);
					$it618_optionname=str_replace('&it618mediatype=video"','" width="700" height="394"',$it618_optionname);
				}
				
				$optionstr.='<tr><td><div>'.$tmpquestions.' <label for="chk'.$it618_exam_questions_option['id'].'" '.$tmpcss.'>'.it618_exam_getABC($on).$it618_exam_lang['s1149'].$it618_optionname.'</label></div></td></tr>';
				$on=$on+1;
			}
		}
		
		if($it618_qtypeid==3){
			$on=1;
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']." ORDER BY id");
			while($it618_exam_questions_option = DB::fetch($query2)) {
				
				if($it618_exam_test_exam_questions['it618_value']!=''){
					$tmpvaluearr=explode("it618_split",$it618_exam_test_exam_questions['it618_value']);
					$tmpvalue=$tmpvaluearr[$on-1];
				}else{
					$tmpvalue='';
				}
				
				if($wap==1)$textareacss='style="padding-left:0;padding-right:10px"';
				
				$tmpreadvalue='';
				$tmpcss='class="rightanswer'.$n.'"';
				$tmpreadvalue='<tr><td '.$tmpcss.' style="font-size:15px; line-height:21px; color:#0eaef9; padding-top:10px;display:none"><span style="color:#999;font-size:15px">'.$it618_exam_lang['s528'].'</span><br>'.$it618_exam_questions_option['it618_name'].'</td></tr>';

				$optionstr.='<tr><td '.$textareacss.'><textarea name="questionvalue[]" '.$readonly.' style="width:99%;height:80px;border:#e8e8e8 1px solid;padding:3px" placeholder="'.$it618_exam_lang['s382'].'">'.$tmpvalue.'</textarea></td></tr>'.$tmpreadvalue;
				
				$on=$on+1;
			}
		}
		
		if($it618_qtypeid==4){
			for($i=1;$i<=2;$i++){
				if($i==1){
					$tmpname=$it618_exam_lang['s529'];
					$tmpvalue=1;
				}else{
					$tmpname=$it618_exam_lang['s530'];
					$tmpvalue=0;
				}
				
				$checkedstr='';
				if($it618_exam_test_exam_questions['it618_value']!=''&&$it618_exam_test_exam_questions['it618_value']==$tmpvalue){
					$checkedstr='checked="checked"';
				}
				$tmpquestions='<input type="radio" name="questionvalue" '.$disabled.' value="'.$tmpvalue.'" id="chk'.$it618_exam_test_exam_questions['id'].'_'.$i.'" '.$checkedstr.'>';
				
				$tmpcss='';
				if($it618_exam_questions['it618_isok']==$tmpvalue){
					$tmpcss='class="rightanswercolor'.$n.'"';
				}
	
				$optionstr.='<tr><td><div>'.$tmpquestions.' <label for="chk'.$it618_exam_test_exam_questions['id'].'_'.$i.'" '.$tmpcss.'>'.it618_exam_getABC($i).$it618_exam_lang['s1149'].$tmpname.'</label></div></td></tr>';
			}
		}
		
		if($it618_qtypeid==5){
			$tmpvalue=$it618_exam_test_exam_questions['it618_value'];
			
			if($wap==1)$textareacss='style="padding-left:0;padding-right:10px"';

			$optionstr='<tr><td '.$textareacss.'><textarea name="questionvalue" '.$readonly.' style="width:99%;height:380px;border:#e8e8e8 1px solid;padding:3px" placeholder="'.$it618_exam_lang['s382'].'">'.$tmpvalue.'</textarea></td></tr>';
		}
		
		$tmpreadabout='';
		if($it618_about!=''){
			$tmpcss='class="rightanswer'.$n.'"';
			$tmpreadabout='<tr><td '.$tmpcss.' style="font-size:15px; line-height:21px; color:#0eaef9; padding-top:10px;display:none"><span style="color:#999;font-size:15px">'.$it618_exam_lang['s602'].'</span><br>'.$it618_about.'</td></tr>';
		}
		
		$examstr=str_replace("{exam_questions}",'<table width="100%" class="tableoption">'.$optionstr.$tmpreadabout.'</table>',$examstr);
		
		$n=$n+1;
	}
	
	return $examstr.'it618testsplit'.$lidmenustr;
}

function it618_exam_getuexam($eid,$wap){
	global $_G,$it618_exam,$it618_exam_lang;
	
	$it618_exam_utest_exam=C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_id($eid);
	if($it618_exam_utest_exam['it618_state']==3){
		$disabled='disabled="disabled"';
		$readonly='readonly="readonly"';
	}
	
	$lidmenustr='<li class="current" onclick="it618_exam_tabChange_test(this,0);">'.$it618_exam_lang['s466'].'</li>';
	
	$n=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_utest_exam_questions')." WHERE it618_eid=".$eid." ORDER BY it618_order,id");
	while($it618_exam_utest_exam_questions = DB::fetch($query)) {
		
		$it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($it618_exam_utest_exam_questions['it618_qid']);
		$it618_qtypeid=$it618_exam_questions['it618_qtypeid'];
		$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_qtypeid);
		
		$it618_name=$it618_exam_questions['it618_name'];
		$it618_about=$it618_exam_questions['it618_about'];
		if($it618_qtypeid==3){
			$it618_name=it618_exam_getquestionname($it618_name);
		}
		
		$iserr=0;$csstmp3='display:none';
		if($it618_exam_utest_exam['it618_state']==3){
			$csstmp='#f30';
			if($it618_exam_utest_exam_questions['it618_isok']==1){
				$csstmp='#390';
				$it618_isok=$it618_exam_lang['s1382'];
			}else{
				$it618_isok=$it618_exam_lang['s1383'];	
			}
			
			$it618_testscore=' <span class="testscore">'.$it618_isok.'</span>';	
			
			if($it618_qtypeid==5){
				$iserr=2;
			}else{
				if($it618_exam_utest_exam['it618_uid']==$_G['uid']){
					if(C::t('#it618_exam#it618_exam_errquestions')->count_by_qid_uid($it618_exam_questions['id'],$it618_exam_utest_exam['it618_uid'])>0){
						$iserr=1;
						$csstmp3='display:';
					}	
				}
			}
				
			$rightmenu='
			<span style="'.$csstmp3.'" class="spanerr">'.$it618_exam_lang['s1835'].'</span>
			<span style="color:'.$csstmp.'">'.$it618_isok.'</span>';
		}else{
			$csstmp1='display:';$csstmp2='display:none';
			if($it618_exam_utest_exam_questions['it618_value']!=''){
				$csstmp1='display:none';
				$csstmp2='display:';
			}
			if($it618_exam_utest_exam_questions['it618_isbj']==1){
				$csstmp3='display:';
			}
			
			$rightmenu='
			<span style="'.$csstmp3.'" class="spanbj">'.$it618_exam_lang['s666'].'</span>
			<span style="color:#f30;'.$csstmp1.'" class="spanwzd">'.$it618_exam_lang['s235'].'</span><span style="color:#390;'.$csstmp2.'" class="spanyzd">'.$it618_exam_lang['s237'].'</span>';
		}
		
		if($wap==1){
			$it618_nametmp=cutstr(it618_exam_strip_tags($it618_name),26,'...');
		}else{
			$it618_nametmp=cutstr(it618_exam_strip_tags($it618_name),68,'...');
		}
		
		$it618_name=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder="0" allowfullscreen="1"/>',$it618_name);
		$it618_about=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder="0" allowfullscreen="1"/>',$it618_about);
		
		if($wap==1){
			$tmparriframe=explode('&it618mediatype=audio"',$it618_name);
			if(count($tmparriframe)>1){
				$it618_name=str_replace('&it618mediatype=audio"','" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$it618_name);
			}else{
				$it618_name=str_replace('allowfullscreen="1"','" width="640" height="220"',$it618_name);
			}
			
			$tmparriframe=explode('&it618mediatype=audio"',$it618_about);
			if(count($tmparriframe)>1){
				$it618_about=str_replace('&it618mediatype=audio','" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$it618_about);
			}else{
				$it618_about=str_replace('allowfullscreen="1"','" width="640" height="220"',$it618_about);
			}
			
		}else{
			
			$tmparriframe=explode('&it618mediatype=audio"',$it618_name);
			if(count($tmparriframe)>1){
				$it618_name=str_replace('&it618mediatype=audio"','" style="border:0;width:780px;height:53px" scrolling="no" frameborder=0',$it618_name);
			}else{
				$tmparriframe=explode('bilibili.com',$it618_name);
				if(count($tmparriframe)>1){
					$it618_name=str_replace('allowfullscreen="1"','" width="700" height="464"',$it618_name);
				}else{
					$it618_name=str_replace('allowfullscreen="1"','" width="700" height="394"',$it618_name);	
				}
			}
			
			$tmparriframe=explode('&it618mediatype=audio"',$it618_about);
			if(count($tmparriframe)>1){
				$it618_about=str_replace('&it618mediatype=audio"','" style="border:0;width:780px;height:53px" scrolling="no" frameborder=0',$it618_about);
			}else{
				$tmparriframe=explode('bilibili.com',$it618_about);
				if(count($tmparriframe)>1){
					$it618_about=str_replace('allowfullscreen="1"','" width="700" height="464"',$it618_about);
				}else{
					$it618_about=str_replace('allowfullscreen="1"','" width="700" height="394"',$it618_about);	
				}
			}
		}
		
		$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_qtypeid);
		
		$tmpqlname='<div class="qlname">'.$tmplname.'<br>'.$tmplessonstr.'</div>';
		$tmpqlname='';
		
		$examstr.='<tr id="exam_questions_'.$n.'" class="exam_questions"><td><form id="form'.$n.'">
						<input type="hidden" id="eqid'.$n.'" name="eqid" value="'.$it618_exam_utest_exam_questions['id'].'">
						<input type="hidden" id="elid'.$n.'" value="'.$it618_exam_utest_exam_questions['it618_lid'].'">
						'.$tmpqlname.'
						<span id="eqname'.$n.'" style="display:none">
						<span style="float:right">'.$rightmenu.'</span>
						'.$n.$it618_exam_lang['s1103'].'['.$qtypename.'] '.$it618_nametmp.'
						</span>
						<input type="hidden" id="eqbj'.$n.'" name="eqbj" value="'.$it618_exam_utest_exam_questions['it618_isbj'].'">
						<input type="hidden" id="eqerr'.$n.'" value="'.$iserr.'">
						<span class="spantime"><span class="qindex"><span class="curindex">'.$n.'</span>/'.$it618_exam_utest_exam['it618_questioncount'].'</span><span class="qtypename">'.$qtypename.'</span> '.$it618_testscore.'</span><br>
						<div class="qname">'.$it618_name.'</div>
						{exam_questions}
					</form></td></tr>';
		
		$optionstr='';
		if($it618_qtypeid==1||$it618_qtypeid==2){
			$on=1;
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']." ORDER BY it618_order,id");
			while($it618_exam_questions_option = DB::fetch($query2)) {
				if($it618_qtypeid==1){
					$checkedstr='';
					if($it618_exam_utest_exam_questions['it618_value']==$it618_exam_questions_option['id']){
						$checkedstr='checked="checked"';
					}
					$tmpquestions='<input type="radio" name="questionvalue" '.$disabled.' value="'.$it618_exam_questions_option['id'].'" id="chk'.$it618_exam_questions_option['id'].'" '.$checkedstr.'>';
				}else{
					$checkedstr='';
					$tmpvaluearr=explode("it618_split",$it618_exam_utest_exam_questions['it618_value']);
					if(in_array($it618_exam_questions_option['id'],$tmpvaluearr)){
						$checkedstr='checked="checked"';
					}
					$tmpquestions='<input type="checkbox" name="questionvalue[]" '.$disabled.' value="'.$it618_exam_questions_option['id'].'" id="chk'.$it618_exam_questions_option['id'].'" '.$checkedstr.'>';
				}
				
				$tmpcss='';
				if($it618_exam_questions_option['it618_isok']==1){
					$tmpcss='class="rightanswercolor'.$n.'"';
				}
				
				$it618_optionname=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder="0" allowfullscreen="1"/>',$it618_exam_questions_option['it618_name']);
				
				if($wap==1){
					$it618_optionname=str_replace('&it618mediatype=audio"','" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$it618_optionname);
					$it618_optionname=str_replace('&it618mediatype=video"','" width="640" height="220"',$it618_optionname);
				}else{
					$it618_optionname=str_replace('&it618mediatype=audio"','" style="border:0;width:780px;height:53px" scrolling="no" frameborder=0',$it618_optionname);
					$it618_optionname=str_replace('&it618mediatype=video"','" width="700" height="394"',$it618_optionname);
				}
				
				$optionstr.='<tr><td><div>'.$tmpquestions.' <label for="chk'.$it618_exam_questions_option['id'].'" '.$tmpcss.'>'.it618_exam_getABC($on).$it618_exam_lang['s1149'].$it618_optionname.'</label></div></td></tr>';
				$on=$on+1;
			}
		}
		
		if($it618_qtypeid==3){
			$on=1;
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']." ORDER BY id");
			while($it618_exam_questions_option = DB::fetch($query2)) {
				
				if($it618_exam_utest_exam_questions['it618_value']!=''){
					$tmpvaluearr=explode("it618_split",$it618_exam_utest_exam_questions['it618_value']);
					$tmpvalue=$tmpvaluearr[$on-1];
				}else{
					$tmpvalue='';
				}
				
				if($wap==1)$textareacss='style="padding-left:0;padding-right:10px"';
				
				$tmpreadvalue='';
				$tmpcss='class="rightanswer'.$n.'"';
				$tmpreadvalue='<tr><td '.$tmpcss.' style="font-size:15px; line-height:21px; color:red; padding-top:10px;display:none"><span style="color:#999;font-size:15px">'.$it618_exam_lang['s528'].'</span><br>'.$it618_exam_questions_option['it618_name'].'</td></tr>';

				$optionstr.='<tr><td '.$textareacss.'><textarea name="questionvalue[]" '.$readonly.' style="width:99%;height:80px;border:#e8e8e8 1px solid;padding:3px" placeholder="'.$it618_exam_lang['s382'].'">'.$tmpvalue.'</textarea></td></tr>'.$tmpreadvalue;
				
				$on=$on+1;
			}
		}
		
		if($it618_qtypeid==4){
			for($i=1;$i<=2;$i++){
				if($i==1){
					$tmpname=$it618_exam_lang['s529'];
					$tmpvalue=1;
				}else{
					$tmpname=$it618_exam_lang['s530'];
					$tmpvalue=0;
				}
				
				$checkedstr='';
				if($it618_exam_utest_exam_questions['it618_value']!=''&&$it618_exam_utest_exam_questions['it618_value']==$tmpvalue){
					$checkedstr='checked="checked"';
				}
				$tmpquestions='<input type="radio" name="questionvalue" '.$disabled.' value="'.$tmpvalue.'" id="chk'.$it618_exam_utest_exam_questions['id'].'_'.$i.'" '.$checkedstr.'>';
				
				$tmpcss='';
				if($it618_exam_questions['it618_isok']==$tmpvalue){
					$tmpcss='class="rightanswercolor'.$n.'"';
				}
	
				$optionstr.='<tr><td><div>'.$tmpquestions.' <label for="chk'.$it618_exam_utest_exam_questions['id'].'_'.$i.'" '.$tmpcss.'>'.it618_exam_getABC($i).$it618_exam_lang['s1149'].$tmpname.'</label></div></td></tr>';
			}
		}
		
		$tmpreadabout='';
		if($it618_about!=''){
			$tmpcss='class="rightanswer'.$n.'"';
			$tmpreadabout='<tr><td '.$tmpcss.' style="font-size:15px; line-height:21px; color:red; padding-top:10px;display:none"><span style="color:#999;font-size:15px">'.$it618_exam_lang['s602'].'</span><br>'.$it618_about.'</td></tr>';
		}
		
		$examstr=str_replace("{exam_questions}",'<table width="100%" class="tableoption">'.$optionstr.$tmpreadabout.'</table>',$examstr);
		
		$n=$n+1;
	}
	
	return $examstr.'it618testsplit'.$lidmenustr;
}

function it618_exam_qrxf($saleid){
	global $_G,$it618_exam;
	
	$it618_exam_sale=C::t('#it618_exam#it618_exam_sale')->fetch_by_id($saleid);
	
	if($it618_exam_sale['it618_gtypeid']>0){
		$it618_exam_goods_type=C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($it618_exam_sale['it618_gtypeid']);
		
		$tmpcount=$it618_exam_goods_type['it618_testcount']*$it618_exam_sale['it618_count'];
	}
	
	if($it618_exam_goods_count=C::t('#it618_exam#it618_exam_goods_count')->fetch_by_uid_pid($it618_exam_sale['it618_uid'],$it618_exam_sale['it618_pid'])){
		DB::query("update ".DB::table('it618_exam_goods_count')." set it618_count=it618_count+".$tmpcount." where id=".$it618_exam_goods_count['id']);
	}else{
		
		C::t('#it618_exam#it618_exam_goods_count')->insert(array(
			'it618_shopid' => $it618_exam_sale['it618_shopid'],
			'it618_pid' => $it618_exam_sale['it618_pid'],
			'it618_uid' => $it618_exam_sale['it618_uid'],
			'it618_count' => $tmpcount
		), true);	
	}
	
	if($it618_exam_sale['it618_tel']=='')return;
	
	$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_sale['it618_shopid']);
	$ShopTCBL=$it618_exam_shop['it618_tcbl'];
	
	$allmoney=$it618_exam_sale['it618_sfmoney'];
	$tcmoney=round((($ShopTCBL*$allmoney)/100), 2);
	$it618_money=$allmoney-$tcmoney;
	
	DB::query("update ".DB::table('it618_exam_sale')." set it618_tcbl=".$ShopTCBL.",it618_tc=".$tcmoney." where id=".$saleid);
	
	if($it618_money>0)DB::query("update ".DB::table('it618_exam_shop')." set it618_money=it618_money+".$it618_money." where id=".$it618_exam_sale['it618_shopid']);
	
	if($it618_exam_sale['it618_score']>0){
		$tmpscore=($it618_exam_sale['it618_sfscore'])-intval($ShopTCBL*($it618_exam_sale['it618_sfscore'])/100);
		C::t('common_member_count')->increase($it618_exam_shop['it618_uid'], array(
			'extcredits'.$it618_exam_sale['it618_jfid'] => $tmpscore)
		);
	}
	
	if($it618_exam_sale['it618_jfbl']>0){
		$it618_jfbl=intval($it618_exam_sale['it618_jfbl']*$it618_exam_sale['it618_sfmoney']/100);
		C::t('common_member_count')->increase($it618_exam_sale['it618_uid'], array(
			'extcredits'.$it618_exam['exam_credit'] => $it618_jfbl)
		);
		C::t('common_member_count')->increase($it618_exam_shop['it618_uid'], array(
			'extcredits'.$it618_exam['exam_credit'] => (0-$it618_jfbl))
		);
	}
	
	if($it618_exam_sale['it618_tuijid']>0){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
		Union_TuiTC_OK($saleid,$it618_exam_shop['it618_uid']);
	}

	$tmpmoney=$it618_exam_sale['it618_sfmoney'];
	
	if($tmpmoney>0){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
		}
		
		if($union_exam_isok==1&&$tmpmoney>=$union_exam_money){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			Union_SaleTC('it618_exam',$tmpmoney,$it618_exam_sale['id'],$it618_exam_sale['it618_uid']);
		}
	}
}

function it618_exam_getjftype($jfid=0){
	global $_G,$it618_exam_lang;
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_jfhl')." where it618_isok=1 ORDER BY it618_order");
	while($it618_exam_jfhl = DB::fetch($query)) {
		$jfname=$_G['setting']['extcredits'][$it618_exam_jfhl['it618_jfid']]['title'];
		
		if($jfname!=''){
			if($jfid==$it618_exam_jfhl['it618_jfid'])$selectedstr='selected="selected"';else $selectedstr='';
			$tmpstr.='<option value="'.$it618_exam_jfhl['it618_jfid'].'" '.$selectedstr.'>'.$jfname.'</option>';
		}
	}
	
	return '<option value="0">'.$it618_exam_lang['s364'].'</option>'.$tmpstr;
}

function it618_exam_getgoodsprice($it618_exam_goods, $type=''){
	global $_G,$it618_exam,$it618_exam_lang,$IsGroup;
	
	if($type=='vipzk'){
		if($IsGroup==1){
			$pid=$it618_exam_goods['id'];
			if($it618_exam_goods['it618_pid']>0)$pid=$it618_exam_goods['it618_pid'];
			
			$vipzk=it618_exam_getvipzk($pid);
		}
	}else{
		if($type=='goods_price'){
			$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_exam_goods['id']);
			if($typecountok>1){
				$tmpprice='<em class="jfname">'.$it618_exam_lang['s734'].'</em>';
			}
		}
	}
	
	$goodspricestr=$it618_exam_lang['s106'];
	
	if($vipzk>0){
		$it618_exam_goods['it618_saleprice']=round($it618_exam_goods['it618_saleprice']*$vipzk/100,2);
		$it618_exam_goods['it618_score']=intval($it618_exam_goods['it618_score']*$vipzk/100);
	}
	
	$it618_exam_goods['it618_saleprice']=floatval($it618_exam_goods['it618_saleprice']);
	
	if($it618_exam_goods['it618_saleprice']>0&&$it618_exam_goods['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_exam_goods['it618_jfid']]['title'];
		$goodspricestr='<em>&yen;</em>'.$it618_exam_goods['it618_saleprice'].'+'.$it618_exam_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
	}else{
		if($it618_exam_goods['it618_saleprice']>0){
			$goodspricestr='<em>&yen;</em>'.$it618_exam_goods['it618_saleprice'];
		}
		
		if($it618_exam_goods['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_exam_goods['it618_jfid']]['title'];
			$goodspricestr=$it618_exam_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
		}
	}
	
	if($vipzk>0){
		$zk=round(($vipzk/10),2);
		$zkstr=$zk.$it618_exam_lang['s1952'];
		
		$goodspricestr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:3px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px">'.$zkstr.'</span> '.$goodspricestr;
	}
	
	return $goodspricestr.$tmpprice;
}

function it618_exam_getsaleprice($it618_exam_sale){
	global $_G,$it618_exam,$it618_exam_lang;
	
	if($it618_exam_sale['it618_price']>0&&$it618_exam_sale['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_exam_sale['it618_jfid']]['title'];
		$goodspricestr=$it618_exam_sale['it618_price'].$it618_exam_lang['s125'].'+'.$it618_exam_sale['it618_score'].$goodsjfname;
	}else{
		if($it618_exam_sale['it618_price']>0){
			$goodspricestr=$it618_exam_sale['it618_price'].$it618_exam_lang['s125'];
		}
		
		if($it618_exam_sale['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_exam_sale['it618_jfid']]['title'];
			$goodspricestr=$it618_exam_sale['it618_score'].$goodsjfname;
		}
	}
	
	if($it618_exam_sale['it618_quanmoney']>0){
		$goodspricestr.='-'.$it618_exam_sale['it618_quanmoney'].$it618_exam_lang['s125'];
	}
	
	return $goodspricestr;
}

function it618_exam_getsalemoney($it618_exam_sale){
	global $_G,$it618_exam,$it618_exam_lang;
	
	if($it618_exam_sale['it618_price']>0&&$it618_exam_sale['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_exam_sale['it618_jfid']]['title'];
		$goodspricestr=$it618_exam_sale['it618_sfmoney'].$it618_exam_lang['s125'].'+'.$it618_exam_sale['it618_sfscore'].$goodsjfname;
	}else{
		if($it618_exam_sale['it618_price']>0){
			$goodspricestr=$it618_exam_sale['it618_sfmoney'].$it618_exam_lang['s125'];
		}
		
		if($it618_exam_sale['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_exam_sale['it618_jfid']]['title'];
			$goodspricestr=$it618_exam_sale['it618_sfscore'].$goodsjfname;
		}
	}
	
	return $goodspricestr;
}

function it618_exam_getsalemoneytmp($it618_exam_sale){
	global $_G,$it618_exam,$it618_exam_lang;
	
	if($it618_exam_sale['it618_price']>0&&$it618_exam_sale['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_exam_sale['it618_jfid']]['title'];
		$goodspricestr=round($it618_exam_sale['it618_price']*$it618_exam_sale['it618_count'],2).$it618_exam_lang['s125'].'+'.$it618_exam_sale['it618_score']*$it618_exam_sale['it618_count'].$goodsjfname;
	}else{
		if($it618_exam_sale['it618_price']>0){
			$goodspricestr=round($it618_exam_sale['it618_price']*$it618_exam_sale['it618_count'],2).$it618_exam_lang['s125'];
		}
		
		if($it618_exam_sale['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_exam_sale['it618_jfid']]['title'];
			$goodspricestr=$it618_exam_sale['it618_score']*$it618_exam_sale['it618_count'].$goodsjfname;
		}
	}
	
	if($it618_exam_sale['it618_quanmoney']>0){
		$goodspricestr.='-'.$it618_exam_sale['it618_quanmoney'].$it618_exam_lang['s125'];
	}
	
	return $goodspricestr;
}

function it618_exam_getvideotimestr($it618_exam_goods_video){
	if($it618_exam_goods_video['it618_islive']==0){
		$it618_examtime=$it618_exam_goods_video['it618_examtime1'];
		if($it618_examtime>0){
			if($it618_examtime<10)$it618_examtime='0'.$it618_examtime;
			$videotimestr.=$it618_examtime.':';
		}
		
		$it618_examtime=$it618_exam_goods_video['it618_examtime2'];
		if($it618_examtime<10)$it618_examtime='0'.$it618_examtime;
		$videotimestr.=$it618_examtime.':';
			
		$it618_examtime=$it618_exam_goods_video['it618_examtime3'];
		if($it618_examtime<10)$it618_examtime='0'.$it618_examtime;
		$videotimestr.=$it618_examtime;
		
		if($videotimestr=='00:')$videotimestr='00:00';
	}else{
		$videotimestr='live';
	}
	
	return $videotimestr;
}

function it618_exam_getplaytime($playtime){
	global $it618_exam_lang;
	if($playtime<60){
		$tmpstr='00:00:'.$playtime;
	}
	
	if($playtime>=60&&$playtime<3600){
		$time1=intval($playtime/60);
		$time2=$playtime-$time1*60;
		$tmpstr='00:'.$time1.':'.$time2;
	}
	
	if($playtime>=3600){
		$time1=intval($playtime/3600);
		$playtime=$playtime-$time1*3600;
		$time2=intval($playtime/60);
		$time3=$playtime-$time2*60;
		
		$tmpstr=$time1.':'.$time2.':'.$time3;
	}
	
	return $tmpstr;
}

function it618_exam_getvideocounttime($videocount,$videotime,$type=0){
	global $it618_exam_lang;
	if($type==0){
		return $it618_exam_lang['s399'].$videocount.$it618_exam_lang['s108'];
	}else{
		return $it618_exam_lang['s399'].$videocount.$it618_exam_lang['s108'].it618_exam_getvideotime($videotime);
	}
}

function it618_exam_getvideotime($videotime){
	global $it618_exam_lang;
	if($videotime<60){
		$tmpstr=$videotime.$it618_exam_lang['s400'];
	}
	
	if($videotime>=60&&$videotime<3600){
		$time1=intval($videotime/60);
		$time2=$videotime-$time1*60;
		$tmpstr=$time1.$it618_exam_lang['s398'].$time2.$it618_exam_lang['s400'];
	}
	
	if($videotime>=3600){
		$time1=intval($videotime/3600);
		$videotime=$videotime-$time1*3600;
		$time2=intval($videotime/60);
		$time3=$videotime-$time2*60;
		
		$tmpstr=$time1.$it618_exam_lang['s397'].$time2.$it618_exam_lang['s398'].$time3.$it618_exam_lang['s400'];
	}
	
	return $tmpstr;
}

function it618_exam_getvideotimearr($videotime){
	$tmparr[0]=0;
	$tmparr[1]=0;
	$tmparr[2]=0;
	
	if($videotime<60){
		$tmparr[2]=$videotime;
	}
	
	if($videotime>=60&&$videotime<3600){
		$time1=intval($videotime/60);
		$time2=$videotime-$time1*60;
		
		$tmparr[1]=$time1;
		$tmparr[2]=$time2;
	}
	
	if($videotime>=3600){
		$time1=intval($videotime/3600);
		$videotime=$videotime-$time1*3600;
		$time2=intval($videotime/60);
		$time3=$videotime-$time2*60;
		
		$tmparr[0]=$time1;
		$tmparr[1]=$time2;
		$tmparr[2]=$time3;
	}
	
	return $tmparr;
}

function it618_exam_lidquestion($lid,$qid,$shopid){
	global $_G,$it618_exam_lang;
	
	if($it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($qid)){
		if($it618_exam_questions['it618_shopid']!=$shopid){
			return $it618_exam_lang['s1211'];
		}else{
			if($it618_exam_questions['it618_optioncount']==0&&($it618_exam_questions['it618_qtypeid']<=3)){
				return $it618_exam_lang['s371'];
			}
			if($it618_exam_goods_lesson=C::t('#it618_exam#it618_exam_goods_lesson')->fetch_by_id($lid)){
				$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_goods_lesson['it618_pid']);
				if($it618_exam_goods['it618_shopid']!=$shopid){
					return $it618_exam_lang['s1214'];
				}else{
					$questionscount=C::t('#it618_exam#it618_exam_goods_questions')->count_by_pid_qid($it618_exam_goods_lesson['it618_pid'],$qid);
					if($questionscount>0){
						return $it618_exam_lang['s1256'];
					}else{
					    C::t('#it618_exam#it618_exam_goods_questions')->insert(array(
							'it618_pid' => $it618_exam_goods_lesson['it618_pid'],
							'it618_lid' => $lid,
							'it618_qid' => $qid
						), true);
						
						if($it618_exam_goods_lesson['it618_type']==1){
							$it618_examscore=C::t('#it618_exam#it618_exam_goods_questions')->sum_score_by_lid($it618_exam_goods_lesson['id']);
							$it618_questioncount=C::t('#it618_exam#it618_exam_goods_questions')->count_by_lid($it618_exam_goods_lesson['id']);
							C::t('#it618_exam#it618_exam_goods_lesson')->update($it618_exam_goods_lesson['id'],array(
								'it618_questioncount' => $it618_questioncount,
								'it618_examscore' => $it618_examscore
							));
							
							$it618_questioncount=C::t('#it618_exam#it618_exam_goods_lesson')->sum_questioncount_by_pid($it618_exam_goods_lesson['it618_pid']);
							$it618_examscore=C::t('#it618_exam#it618_exam_goods_lesson')->sum_examscore_by_pid($it618_exam_goods_lesson['it618_pid']);
							C::t('#it618_exam#it618_exam_goods')->update($it618_exam_goods_lesson['it618_pid'],array(
								'it618_questioncount' => $it618_questioncount,
								'it618_examscore' => $it618_examscore
							));
						}
						
						return 'it618_splitokit618_split';
					}
				}
			}else{
				return $it618_exam_lang['s1215'];
			}
		}
	}else{
		return $it618_exam_lang['s1210'];
	}
}

function it618_exam_liddelquestion($lid,$qid,$shopid){
	global $_G,$it618_exam_lang;
	
	if($it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($qid)){
		if($it618_exam_questions['it618_shopid']!=$shopid){
			return $it618_exam_lang['s1211'];
		}else{
			if($it618_exam_goods_lesson=C::t('#it618_exam#it618_exam_goods_lesson')->fetch_by_id($lid)){
				$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_goods_lesson['it618_pid']);
				if($it618_exam_goods['it618_shopid']!=$shopid){
					return $it618_exam_lang['s1214'];
				}else{
					if($it618_exam_goods_questions=C::t('#it618_exam#it618_exam_goods_questions')->fetch_by_pid_qid($it618_exam_goods_lesson['it618_pid'],$qid)){
					    C::t('#it618_exam#it618_exam_goods_questions')->delete_by_id($it618_exam_goods_questions['id']);
						
						if($it618_exam_goods_lesson['it618_type']==1){
							$it618_examscore=C::t('#it618_exam#it618_exam_goods_questions')->sum_score_by_lid($it618_exam_goods_lesson['id']);
							$it618_questioncount=C::t('#it618_exam#it618_exam_goods_questions')->count_by_lid($it618_exam_goods_lesson['id']);
							C::t('#it618_exam#it618_exam_goods_lesson')->update($it618_exam_goods_lesson['id'],array(
								'it618_questioncount' => $it618_questioncount,
								'it618_examscore' => $it618_examscore
							));
							
							$it618_questioncount=C::t('#it618_exam#it618_exam_goods_lesson')->sum_questioncount_by_pid($it618_exam_goods_lesson['it618_pid']);
							$it618_examscore=C::t('#it618_exam#it618_exam_goods_lesson')->sum_examscore_by_pid($it618_exam_goods_lesson['it618_pid']);
							C::t('#it618_exam#it618_exam_goods')->update($it618_exam_goods_lesson['it618_pid'],array(
								'it618_questioncount' => $it618_questioncount,
								'it618_examscore' => $it618_examscore
							));
						}
						
						return 'it618_splitokit618_split';
					}
				}
			}else{
				return $it618_exam_lang['s1215'];
			}
		}
	}else{
		return $it618_exam_lang['s1210'];
	}
}

function it618_exam_addliverecordconfig($it618_exam_live){
	global $_G;
	include_once DISCUZ_ROOT.'./source/plugin/it618_exam/aliapi/alilive.php';
	
	$it618_exam_liveset=C::t('#it618_exam#it618_exam_liveset')->fetch_by_id($it618_exam_live['it618_liveset_id']);

	$accessid=$it618_exam_liveset['it618_accessid'];
	$accesskey=$it618_exam_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_exam_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new AddLiveAppRecordConfigRequest();
	$request->setAppName($it618_exam_liveset['it618_appname']);
	$request->setStreamName($it618_exam_live['it618_streamname']);
	$request->setDomainName($it618_exam_liveset['it618_domainname']);
	$request->setOssBucket($it618_exam_live['it618_ossbucket']);
	$request->setOssEndpoint($it618_exam_live['it618_ossendpoint']);
	
	$RecordFormats[0]['CycleDuration']=360*60;
	$RecordFormats[0]['Format']='m3u8';
	$RecordFormats[0]['OssObjectPrefix']="record/".$it618_exam_liveset['it618_appname']."/".$it618_exam_live['it618_streamname']."/{EscapedStartTime}_{EscapedEndTime}";
	$RecordFormats[0]['SliceOssObjectPrefix']="record/".$it618_exam_liveset['it618_appname']."/".$it618_exam_live['it618_streamname']."/{UnixTimestamp}_{Sequence}";
	
	$request->setRecordFormats($RecordFormats);
	//$request->setStartTime(str_replace(" ","T",date('Y-m-d H:i:s', $it618_exam_live['it618_btime'])).'Z');
	//$request->setEndTime(str_replace(" ","T",date('Y-m-d H:i:s', $it618_exam_live['it618_etime'])).'Z');
	
	$response = $client->getAcsResponse($request);
	
	$s = var_export($response,true);
	
	$tmparr=explode("Code",$s);
	if(count($tmparr)==1){
		return 1;
	}else{
		return $s;
	}
}

function it618_exam_delliverecordconfig($it618_exam_live){
	global $_G;
	include_once DISCUZ_ROOT.'./source/plugin/it618_exam/aliapi/alilive.php';
	
	$it618_exam_liveset=C::t('#it618_exam#it618_exam_liveset')->fetch_by_id($it618_exam_live['it618_liveset_id']);

	$accessid=$it618_exam_liveset['it618_accessid'];
	$accesskey=$it618_exam_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_exam_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new DeleteLiveAppRecordConfigRequest();
	$request->setAppName($it618_exam_liveset['it618_appname']);
	$request->setStreamName($it618_exam_live['it618_streamname']);
	$request->setDomainName($it618_exam_liveset['it618_domainname']);
	
	$response = $client->getAcsResponse($request);
	
	$s = var_export($response,true);
	
	$tmparr=explode("Code",$s);
	if(count($tmparr)==1){
		return 1;
	}else{
		return $s;
	}
}

function it618_exam_forbidlivestream($it618_exam_live){
	include_once DISCUZ_ROOT.'./source/plugin/it618_exam/aliapi/alilive.php';
	
	$it618_exam_liveset=C::t('#it618_exam#it618_exam_liveset')->fetch_by_id($it618_exam_live['it618_liveset_id']);

	$accessid=$it618_exam_liveset['it618_accessid'];
	$accesskey=$it618_exam_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_exam_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new ForbidLiveStreamRequest();
	$request->setAppName($it618_exam_liveset['it618_appname']);
	$request->setStreamName($it618_exam_live['it618_streamname']);
	$request->setDomainName($it618_exam_liveset['it618_domainname']);
	$request->setLiveStreamType('publisher');
	
	$response = $client->getAcsResponse($request);
	
	$s = var_export($response,true);
	
	$tmparr=explode("Code",$s);
	if(count($tmparr)==1){
		return 1;
	}else{
		return $s;
	}
}

function it618_exam_getlivestreamrecord($it618_exam_live){
	global $_G;
	include_once DISCUZ_ROOT.'./source/plugin/it618_exam/aliapi/alilive.php';
	
	$it618_exam_liveset=C::t('#it618_exam#it618_exam_liveset')->fetch_by_id($it618_exam_live['it618_liveset_id']);

	$accessid=$it618_exam_liveset['it618_accessid'];
	$accesskey=$it618_exam_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_exam_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new DescribeLiveStreamRecordIndexFilesRequest();
	$request->setAppName($it618_exam_liveset['it618_appname']);
	$request->setStreamName($it618_exam_live['it618_streamname']);
	$request->setDomainName($it618_exam_liveset['it618_domainname']);
	$request->setStartTime(str_replace(" ","T",date('Y-m-d H:i:s', $it618_exam_live['it618_btime']-3600*10)).'Z');
	$request->setEndTime(str_replace(" ","T",date('Y-m-d H:i:s', $_G['timestamp']+3600)).'Z');
	
	$response = $client->getAcsResponse($request);
	
	$tmparr=object_array($response);
	
//	$s = var_export($response,true);
//	
//	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/debug.txt',"a");
//	fwrite($fp,$s);
//	fclose($fp);

	$RecordArr=$tmparr['RecordIndexInfoList']['RecordIndexInfo'];
	
	return $RecordArr;
}

function it618_exam_addlivem3u8($it618_exam_live, $m3u8object){
	global $_G;
	include_once DISCUZ_ROOT.'./source/plugin/it618_exam/aliapi/alilive.php';
	
	$it618_exam_liveset=C::t('#it618_exam#it618_exam_liveset')->fetch_by_id($it618_exam_live['it618_liveset_id']);

	$accessid=$it618_exam_liveset['it618_accessid'];
	$accesskey=$it618_exam_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_exam_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new CreateLiveStreamRecordIndexFilesRequest();
	$request->setAppName($it618_exam_liveset['it618_appname']);
	$request->setStreamName($it618_exam_live['it618_streamname']);
	$request->setDomainName($it618_exam_liveset['it618_domainname']);
	$request->setOssBucket($it618_exam_live['it618_ossbucket']);
	$request->setOssEndpoint($it618_exam_live['it618_ossendpoint']);
	$request->setOssObject($m3u8object);
	$request->setStartTime(str_replace(" ","T",date('Y-m-d H:i:s', $it618_exam_live['it618_btime']-3600*10)).'Z');
	$request->setEndTime(str_replace(" ","T",date('Y-m-d H:i:s', $_G['timestamp']+3600)).'Z');
	
	$response = $client->getAcsResponse($request);
}

function it618_exam_updatevideolive($it618_exam_live){
	global $_G;
	$etime=$it618_exam_live['it618_etime'];
	
	if($etime+1000<$_G['timestamp']){
		C::t('#it618_exam#it618_exam_live')->update($it618_exam_live['id'],array(
			'it618_isok' => 1
		));
		DB::query("delete from ".DB::table('it618_exam_goods_video')." where it618_liveid=".$it618_exam_live['id']);
		DB::query("delete from ".DB::table('it618_exam_live_order')." where it618_liveid=".$it618_exam_live['id']);
	}
		
	if($it618_exam_live['it618_forbid']==0){
		if($etime+90<$_G['timestamp']&&$it618_exam_live['it618_rtmpcode']!=''){
			$returnvalue=it618_exam_forbidlivestream($it618_exam_live);
			if($returnvalue==1){
				C::t('#it618_exam#it618_exam_live')->update($it618_exam_live['id'],array(
					'it618_forbid' => 1,
					'it618_forbidtime' => $_G['timestamp']
				));
			}
		}
	}else{

		if($it618_exam_live['it618_ossbucket']!=''&&$it618_exam_live['it618_ossendpoint']!=''){

			$forbidtime=$it618_exam_live['it618_forbidtime'];
			if($forbidtime+180<$_G['timestamp']){
				$it618_exam_liveset=C::t('#it618_exam#it618_exam_liveset')->fetch_by_id($it618_exam_live['it618_liveset_id']);
				$RecordArr=it618_exam_getlivestreamrecord($it618_exam_live);
	
				for($i=0;$i<count($RecordArr);$i++){
					
					$it618_examurl=$RecordArr[$i]['RecordUrl'];
					
					$tmparr=explode($it618_exam_live['it618_streamname'],$it618_examurl);
					$m3u8path=$tmparr[0].$it618_exam_live['it618_streamname'].'/'.$_G['timestamp'].'.m3u8';
					$tmparr=explode($it618_exam_live['it618_ossendpoint'].'/',$m3u8path);
					$m3u8object=$tmparr[1];
					
					break;
				}
				
				if($m3u8path!=''){
					it618_exam_addlivem3u8($it618_exam_live, $m3u8object);
					
					$it618_order=C::t('#it618_exam#it618_exam_goods_video')->fetch_order_by_lid($it618_exam_live['it618_lid']);
			
					$tmpid=C::t('#it618_exam#it618_exam_goods_video')->insert(array(
						'it618_pid' => $it618_exam_live['it618_pid'],
						'it618_lid' => $it618_exam_live['it618_lid'],
						'it618_name' => $it618_exam_live['it618_name'].$tmpname,
						'it618_description' => $it618_exam_live['it618_description'],
						'it618_examurl' => $m3u8path,
						'it618_islive' => 0,
						'it618_isuser' => $it618_exam_live['it618_isuser'],
						'it618_order' => $it618_order
					), true);
					
					C::t('#it618_exam#it618_exam_media_live')->insert(array(
						'it618_shopid' => $it618_exam_live['it618_shopid'],
						'it618_liveset_id' => $it618_exam_live['it618_liveset_id'],
						'it618_live_id' => $it618_exam_live['id'],
						'it618_endpoint' => $OssEndpoint,
						'it618_name' => $it618_exam_live['it618_name'].$tmpname,
						'it618_url' => $m3u8path,
						'it618_time' => $_G['timestamp'],
					), true);	
					
					it618_exam_delliverecordconfig($it618_exam_live);
					
					C::t('#it618_exam#it618_exam_live')->update($it618_exam_live['id'],array(
						'it618_vid' => $tmpid,
						'it618_isok' => 1
					));
					DB::query("delete from ".DB::table('it618_exam_goods_video')." where it618_liveid=".$it618_exam_live['id']);
					DB::query("delete from ".DB::table('it618_exam_live_order')." where it618_liveid=".$it618_exam_live['id']);
				}
			}

		}else{
			C::t('#it618_exam#it618_exam_live')->update($it618_exam_live['id'],array(
				'it618_isok' => 1
			));
			DB::query("delete from ".DB::table('it618_exam_goods_video')." where it618_liveid=".$it618_exam_live['id']);
			DB::query("delete from ".DB::table('it618_exam_live_order')." where it618_liveid=".$it618_exam_live['id']);
		}
	}

}

function it618_exam_updatevideoliveonline($it618_liveset_id){
	global $_G;
	if($it618_exam_liveset=C::t('#it618_exam#it618_exam_liveset')->fetch_by_id($it618_liveset_id)){
		
		DB::query("update ".DB::table('it618_exam_live')." set it618_isonline=0 where it618_liveset_id=".$it618_liveset_id);
		
		include_once DISCUZ_ROOT.'./source/plugin/it618_exam/aliapi/alilive.php';
	
		$accessid=$it618_exam_liveset['it618_accessid'];
		$accesskey=$it618_exam_liveset['it618_accesskey'];
		
		$profile = DefaultProfile::getProfile($it618_exam_liveset['it618_cnname'], $accessid, $accesskey);
		$client = new DefaultAcsClient($profile);
		
		$request = new DescribeLiveStreamsOnlineListRequest();
		$request->setAppName($it618_exam_liveset['it618_appname']);
		$request->setDomainName($it618_exam_liveset['it618_domainname']);
		$request->setPageNum(1);
		$request->setPageSize(3000);
		
		$response = $client->getAcsResponse($request);
		
		$tmparr=object_array($response);
		
		$OnlineArr=$tmparr['OnlineInfo']['LiveStreamOnlineInfo'];
//		$s = var_export($tmparr,true);
//		
//		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/debug.txt',"a");
//		fwrite($fp,$s);
//		fclose($fp);
		
		for($i=0;$i<count($OnlineArr);$i++){
			$StreamName=$OnlineArr[$i]['StreamName'];
			$PublishTime=$OnlineArr[$i]['PublishTime'];
			$PublishTime=str_replace("Z","",$PublishTime);
			$PublishTime=str_replace("T"," ",$PublishTime);
			
			if($it618_exam_live=C::t('#it618_exam#it618_exam_live')->fetch_by_livesetid_streamname($it618_liveset_id,$StreamName)){
				if(strtotime($PublishTime)+50<$_G['timestamp']){
					C::t('#it618_exam#it618_exam_live')->update($it618_exam_live['id'],array(
						'it618_isonline' => 1
					));
				}
			}
		}
	}

}

function it618_exam_setlivecdn($it618_exam_live){
	global $_G;
			
	$it618_exam_liveset=C::t('#it618_exam#it618_exam_liveset')->fetch_by_id($it618_exam_live['it618_liveset_id']);
	
	$time=$it618_exam_live['it618_etime'];

	$key=$it618_exam_liveset['it618_pushcdnkey'];

	$filename='/'.$it618_exam_liveset['it618_appname'].'/'.$it618_exam_live['it618_streamname'];
	$sstring = $filename."-".$time."-0-0-".$key;
	$md5=md5($sstring);
	$auth_key="auth_key=".$time."-0-0-".$md5;
	$it618_rtmpcode=$it618_exam_live['it618_streamname']."?".$auth_key;
	
	$key=$it618_exam_liveset['it618_cdnkey'];
	
	$filename='/'.$it618_exam_liveset['it618_appname'].'/'.$it618_exam_live['it618_streamname'].'.m3u8';
	$sstring = $filename."-".$time."-0-0-".$key;
	$md5=md5($sstring);
	$auth_key="auth_key=".$time."-0-0-".$md5;
	$it618_m3u8url="http://".$it618_exam_liveset['it618_domainname'].$filename."?".$auth_key;
	
	$filename='/'.$it618_exam_liveset['it618_appname'].'/'.$it618_exam_live['it618_streamname'].'.flv';
	$sstring = $filename."-".$time."-0-0-".$key;
	$md5=md5($sstring);
	$auth_key="auth_key=".$time."-0-0-".$md5;
	$it618_flvurl="http://".$it618_exam_liveset['it618_domainname'].$filename."?".$auth_key;
  
	C::t('#it618_exam#it618_exam_live')->update($it618_exam_live['id'],array(
		'it618_rtmpcode' => $it618_rtmpcode,
		'it618_m3u8url' => $it618_m3u8url,
		'it618_flvurl' => $it618_flvurl,
	));
}

function it618_exam_get_contents($str){
	return dfsockopen($str);
}

function it618_exam_getshopgoods($shopid,$page=1,$wap=0,$type=''){
	global $_G,$it618_exam,$templatename,$it618_exam_lang,$creditname;
	$creditname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];
	if($wap==1){
		$ppp = 10;
		
		if($it618_exam['exam_style']>2){
			$examstyle=getcookie('examstyle');
			if($examstyle==''){
				if($it618_exam['exam_style']==3)$examstyle='1';else $examstyle='2';
			}
		}else{
			if($it618_exam['exam_style']==1)$examstyle='1';else $examstyle='2';
		}
	}else{
		if($templatename=='mall')$ppp = 10;else $ppp = 12;
	}
	$page = max(1, intval($page));
	$startlimit = ($page - 1) * $ppp;
	
	$orderby='it618_tests desc,id desc';
	if($type=='views'){
		$startlimit=0;
		$orderby='g.it618_views desc';
	}
	if($type=='hot'){
		$startlimit=0;
		$orderby='g.it618_salecount desc';
	}
	
	$tdn=1;
	foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
		'g.it618_gtype=1 and g.it618_state=1',$orderby,$shopid,0,0,0,0,'',0,0,$startlimit,$ppp
	) as $it618_exam_goods) {
		
		$jfbl='';
		if($it618_exam_goods['it618_jfbl']>0&&$it618_exam_goods['it618_saleprice']>0){
			if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_goods['id'])>0){
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].str_replace(".00","",$it618_exam_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].intval($it618_exam_goods['it618_saleprice']*$it618_exam_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		if($wap==1){
			
			$it618_isvip='';
			$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;margin-top:-1px;margin-right:3px">';
			}
			
			if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
				$pricestr='<span style="color:#f30">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span style="color:#390">'.$it618_exam_lang['s106'].'</span>';
			}
			
			if($it618_exam_goods['it618_price']>0){
				$pricestr.=' <del>&yen;'.$it618_exam_goods['it618_price'].'</del>';
			}
			
			DB::query("UPDATE ".DB::table('it618_exam_goods')." SET it618_pjpfstr='".$pj."' WHERE id=".$it618_exam_goods['id']);
			
			$zk=sprintf("%.2f", $it618_exam_goods['it618_saleprice']/$it618_exam_goods['it618_price'])*10;
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			
			if($examstyle=='1'){
			
				$strlist.='<tr>
									<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/></a></td>
									<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
										<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
										<div class="tddes">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' '.$it618_exam_goods['it618_tests'].it618_exam_getlang('s931').'</div>
										<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
									</td>
								  </tr>
								  <tr><td colspan="2" class="tdcolspan"></td></tr>';
			}else{
				if($tdn%2>0){
					$trtmpstr='<tr>';
					$tdstr='class="tdleft"';
				}else{
					$tdstr='class="tdright"';
				}
				
				$trtmpstr.='<td '.$tdstr.'><div class="tddiv">
								<a href="'.$tmpurl.'">
								'.$jfbl.'
							<div class="divtime">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' <img src="source/plugin/it618_exam/images/plays.png" class="imguser">'.$it618_exam_goods['it618_tests'].'</div>
							<img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
								<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
							</a></div></td>';
							
				if($tdn%2==0){
					$trtmpstr.='</tr>';
					$strlist.=$trtmpstr;
				}
				
				$tdn=$tdn+1;
			}
		}else{
			
			if($templatename=='default'){
				if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
					$pricestr='<span class="price">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span style="color:#390;">'.$it618_exam_lang['s106'].'</span>';
				}
				
				$it618_isvip='';
				$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
				if(count($vipgroupids)>0){
					$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				}
				
				$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				$getshopgoods.='<div class="course-card" title="'.$it618_exam_goods['it618_name'].'">
									'.$jfbl.'
									<div class="course-img">
										<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" alt="'.$it618_exam_goods['it618_name'].'" class="goodsimg"></a>
										<div class="course-name">
											<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_exam_goods['it618_name'],58,'...').'</a>
										</div>
										<div class="course-author">
											'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'
										</div>
										<div class="course-price">
											'.$pricestr.'
											<span class="course-plays">'.$it618_exam_goods['it618_tests'].''.it618_exam_getlang('s931').'</span>
										</div>
									</div>
								</div>';
			}
		}
	}
	
	if($wap==1){
		if($examstyle=='1'){
			$tmparr=explode('</tr>',$strlist);
			if(count($tmparr)>1){
				$strlist=$strlist.'@@@';
				$strlist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$strlist);
			}
		}else{
			$trtmpstr=$trtmpstr1.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr);
			if(count($tmparr)>1){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$strlist.=$trtmpstr1.$trtmpstr2;
			}
		}
		
		$getshopgoods=$strlist;
	}
	
	if($type!='')return $getshopgoods;
	
	$count = C::t('#it618_exam#it618_exam_goods')->count_by_search('g.it618_gtype=1 and g.it618_state=1','',$shopid);
	$funname='getshopgoods';
	
	if($wap==1){
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}else{
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].'plugin.php?id=it618_exam:ajax');
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',''.$funname.'(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
	}
	
	return $getshopgoods.'it618_split'.$multipage;
}

function it618_exam_delsalework(){
	DB::query("delete from ".DB::table('it618_exam_salework'));
}

function it618_exam_get_contents1($str){
	return dfsockopen($str);
}

function it618_exam_sendmessage($type,$id,$type1=''){
	global $_G,$creditname,$it618_exam_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_exam/config/message.php';
	
	$tmpurl=it618_exam_getrewrite('exam_wap','','plugin.php?id=it618_exam:wap');
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='rz_admin'&&$it618_body_rz_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_rz_admin_tplid_wxsms;
				$body_wxsms=$it618_body_rz_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_exam_getusername($it618_exam_shop['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_rz_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_exam_getusername($it618_exam_shop['it618_uid']),$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rz_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_exam_getusername($it618_exam_shop['it618_uid']).'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='tx_admin'&&$it618_body_tx_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_exam_tx = C::t('#it618_exam#it618_exam_tx')->fetch_by_id($id);
				$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_tx['it618_shopid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_tx_admin_tplid_wxsms;
				$body_wxsms=$it618_body_tx_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{shopname}",$it618_exam_shop['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{txmoney}",$it618_exam_tx['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_tx_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{shopname}",$it618_exam_shop['it618_name'],$Body);
				$Body=str_replace("{txmoney}",$it618_exam_tx['it618_price'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_admin_tplid;
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_exam_shop['it618_name'].'",';
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_exam_tx['it618_price'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;

				$it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($id);
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
				$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				
				if($it618_exam_sale['it618_price']>0||$it618_exam_sale['it618_score']>0){
					$pricestr=it618_exam_getsalemoney($it618_exam_sale);
				}else{
					$pricestr=$it618_exam_lang['s106'];
				}
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_exam_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$pricestr,$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_exam_sale['it618_tel'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_sale_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_exam_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$pricestr,$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_exam_sale['it618_tel'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_exam_getusername($it618_exam_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_exam_getsmsstr($it618_exam_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$pricestr.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_exam_sale['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='gwc_admin'&&$it618_body_gwc_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_gwcid($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_gwc_admin_tplid_wxsms;
				$body_wxsms=$it618_body_gwc_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_exam_sale['it618_tel'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_gwc_admin;	

				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$Body);
				$Body=str_replace("{gwcid}",$id,$Body);
				$Body=str_replace("{tel}",$it618_exam_sale['it618_tel'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_gwc_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_exam_getusername($it618_exam_sale['it618_uid']).'",';
					
					$tmparr=explode("{gwcid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_exam_sale['it618_tel'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
		}
		
		if($type=='tx_shop'&&$it618_body_tx_shop_isok==1){
			$it618_exam_tx = C::t('#it618_exam#it618_exam_tx')->fetch_by_id($id);
			$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_tx['it618_shopid']);
			
			$tel=$it618_exam_shop['it618_msgtel'];
			
			if($it618_exam_shop['it618_msgisok']==1){
				
				$uid=$it618_exam_shop['it618_uid'];
				$tplid_wxsms=$it618_body_tx_shop_tplid_wxsms;
				$body_wxsms=$it618_body_tx_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{txmoney}",$it618_exam_tx['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_tx['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_tx_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{txmoney}",$it618_exam_tx['it618_price'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_tx['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_shop_tplid;
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_exam_tx['it618_price'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_exam_tx['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_shop'&&$it618_body_sale_shop_isok==1){
			$it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($id);
			$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
			
			$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_sale['it618_shopid']);
			
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			if($it618_exam_sale['it618_price']>0||$it618_exam_sale['it618_score']>0){
				$pricestr=it618_exam_getsalemoney($it618_exam_sale);
			}else{
				$pricestr=$it618_exam_lang['s106'];
			}
			
			$tel=$it618_exam_shop['it618_msgtel'];
			
			if($it618_exam_shop['it618_msgisok']==1){
				$uid=$it618_exam_brand['it618_uid'];
				$tplid_wxsms=$it618_body_sale_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_exam_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$pricestr,$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_exam_sale['it618_tel'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_sale_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_exam_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$pricestr,$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_exam_sale['it618_tel'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_exam_getusername($it618_exam_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_exam_getsmsstr($it618_exam_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$pricestr.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_exam_sale['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='gwc_shop'&&$it618_body_gwc_shop_isok==1){
			$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($type1);
	
			$tel=$it618_exam_shop['it618_msgtel'];

			if($it618_exam_shop['it618_msgisok']==1){
				$it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_gwcid_shopid($id,$type1);
				
				$uid=$it618_exam_shop['it618_uid'];
				$tplid_wxsms=$it618_body_gwc_shop_tplid_wxsms;
				$body_wxsms=$it618_body_gwc_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_exam_sale['it618_tel'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_gwc_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$Body);
				$Body=str_replace("{gwcid}",$id,$Body);
				$Body=str_replace("{tel}",$it618_exam_sale['it618_tel'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_gwc_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_exam_getusername($it618_exam_sale['it618_uid']).'",';
					
					$tmparr=explode("{gwcid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_exam_sale['it618_tel'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='media_shop'&&$it618_body_media_shop_isok==1){
			$it618_exam_media = C::t('#it618_exam#it618_exam_media')->fetch_by_id($id);
			$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_media['it618_shopid']);
	
			$tel=$it618_exam_shop['it618_msgtel'];

			if($it618_exam_shop['it618_msgisok']==1){
				if($it618_exam_media['it618_chkstate']==0)$chkstate=$it618_exam_lang['s678'];
				if($it618_exam_media['it618_chkstate']==1)$chkstate=$it618_exam_lang['s679'];

				$uid=$it618_exam_shop['it618_uid'];
				$tplid_wxsms=$it618_body_media_shop_tplid_wxsms;
				$body_wxsms=$it618_body_media_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{medianame}",$it618_exam_media['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{chkstate}",$chkstate,$tmpvalue);
						$tmpvalue=str_replace("{mediaid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_media['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_media_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{medianame}",$it618_exam_media['it618_name'],$Body);
				$Body=str_replace("{chkstate}",$chkstate,$Body);
				$Body=str_replace("{mediaid}",$id,$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_media['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_media_shop_tplid;
					
					$tmparr=explode("{medianame}",$ALDYBody);
					if(count($tmparr)>1)$param.='"medianame":"'.$it618_exam_media['it618_name'].'",';
					
					$tmparr=explode("{chkstate}",$ALDYBody);
					if(count($tmparr)>1)$param.='"chkstate":"'.$chkstate.'",';
					
					$tmparr=explode("{mediaid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"mediaid":"'.$id.'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_exam_media['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			
			}

		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($id);
			$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
			
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			if($it618_exam_sale['it618_price']>0||$it618_exam_sale['it618_score']>0){
				$pricestr=it618_exam_getsalemoney($it618_exam_sale);
			}else{
				$pricestr=$it618_exam_lang['s106'];
			}
			
			$tel=$it618_exam_sale['it618_tel'];
			
			$uid=$it618_exam_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$it618_exam_goods['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{pprice}",$pricestr,$tmpvalue);
					$tmpvalue=str_replace("{code}",$it618_exam_sale['it618_code'],$tmpvalue);
					$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
				
			$Body=$it618_body_sale_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$it618_exam_goods['it618_name'],$Body);
			$Body=str_replace("{pprice}",$pricestr,$Body);
			$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_exam_getusername($it618_exam_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_exam_getsmsstr($it618_exam_goods['it618_name'],$it618_length).'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.$pricestr.'",';
				
				$tmparr=explode("{purl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='gwc_user'&&$it618_body_gwc_user_isok==1){
			$it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_gwcid($id);
			$tel=$it618_exam_sale['it618_tel'];
			
			$uid=$it618_exam_sale['it618_uid'];
			$tplid_wxsms=$it618_body_gwc_user_tplid_wxsms;
			$body_wxsms=$it618_body_gwc_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_gwc_user;		

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_exam_getusername($it618_exam_sale['it618_uid']),$Body);
			$Body=str_replace("{gwcid}",$id,$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_sale['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_gwc_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_exam_getusername($it618_exam_sale['it618_uid']).'",';
				
				$tmparr=explode("{gwcid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='live_user'&&$it618_body_live_user_isok==1){
			$it618_exam_live_order = C::t('#it618_exam#it618_exam_live_order')->fetch_by_id($id);
			$it618_exam_live = C::t('#it618_exam#it618_exam_live')->fetch_by_id($it618_exam_live_order['it618_liveid']);
			$it618_exam_goods_video = C::t('#it618_exam#it618_exam_goods_video')->fetch_by_liveid($it618_exam_live_order['it618_liveid']);
			
			$tel=$it618_exam_live_order['it618_tel'];
			
			$tmpurl=it618_exam_getrewrite('exam_test',$it618_exam_goods_video['id'],'plugin.php?id=it618_exam:test&lid='.$it618_exam_goods_video['id']);
			
			$uid=$it618_exam_live_order['it618_uid'];
			$tplid_wxsms=$it618_body_live_user_tplid_wxsms;
			$body_wxsms=$it618_body_live_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_exam_getusername($it618_exam_live_order['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{name}",$it618_exam_live['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_live['it618_btime']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_exam_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_live_user;		

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_exam_getusername($it618_exam_live_order['it618_uid']),$Body);
			$Body=str_replace("{name}",$it618_exam_live['it618_name'],$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_exam_live['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_live_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_exam_getusername($it618_exam_live_order['it618_uid']).'",';
				
				$tmparr=explode("{name}",$ALDYBody);
				if(count($tmparr)>1)$param.='"name":"'.$it618_exam_live['it618_name'].'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_exam_live['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_exam/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_exam_lang['s1860'].$it618_smsbaosign.$it618_exam_lang['s1861'];
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}

		}
	}
}

function it618_exam_get_contents2($str){
	return dfsockopen($str);
}

function it618_exam_multipage($pagevalue,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_exam']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php')){
		return $pagevalue;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';

	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}


function it618_exam_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_exam']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php';
	
	if($pagetype=='exam_home'){
		return $exam_home.$urltype;
	}
	
	if($pagetype=='exam_list'){//exam_list-{cid1}-{cid2}-{price}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_list.$exam_list1;

		if(count($tmparr)==1){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("-{cid2}-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==2){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("-{aid1}-{aid2}-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==2){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==4){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{page}",'1',$pageurl);
		}
		
		if(count($tmparr)==5){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_search'){//exam_search-{cid1}-{cid2}-{price}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_search.$exam_search1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid1}-{cid2}-{price}-{order}-{page}","",$pageurl);
		}else{
			if(count($tmparr)==4){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",'1',$pageurl);
			}
			
			if(count($tmparr)==5){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_product'){//exam_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_product.$exam_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_testabout'){//testabout-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_testabout.$exam_testabout1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_test'){//test-{eid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_test.$exam_test1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{eid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_utestabout'){//utestabout.html
		return $exam_utestabout.$urltype;
	}
	
	if($pagetype=='exam_utest'){//utest-{eid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_utest.$exam_utest1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{eid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_teacher'){//teacher-{lid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_teacher.$exam_teacher1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{lid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='exam_gwc'){
		return $exam_gwc.$urltype;
	}
	
	if($pagetype=='exam_gwcmysale'){
		return $exam_gwc.$urltype.'?mysale';
	}
	
	if($pagetype=='exam_sc'){
		return $exam_sc.$urltype;
	}
	
	if($pagetype=='exam_wap'){//exam_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_wap.$exam_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_exam_get_contents3($str){
	return dfsockopen($str);
}

function it618_exam_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_exam_gbktoutf($strcontent);
	}
}

function it618_exam_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_exam_delfile($dirName){
}

function it618_exam_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
            }else{
            }
        }
        if($type==1);
    }else{
        return false;
    }
}

function it618_exam_getsize($size) { 
	$format = 'M';
	$size1=$size;
    $size /= pow(1024, 2); 
	$getsize=number_format($size, 2);
	if($getsize<1){
		$format = 'K';
		$size1 /= pow(1024, 1); 
		$getsize=number_format($size1, 2);
	}
	
    return $getsize.$format;  
}  

function it618_exam_get_contents4($str){
	return dfsockopen($str);
}

function it618_exam_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_exam_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_exam_getusername($uid){
	return C::t('#it618_exam#it618_exam_sale')->fetch_username_by_uid($uid);
}

function it618_exam_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_exam_getlang('s449');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_exam_getlang('s450');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_exam_getlang('s451');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_exam_getlang('s452');
		}
	}
	
	return $timestr;
}

function it618_exam_gettime1($it618_time){
	global $_G;
	$timecount=intval(($it618_time-$_G['timestamp'])/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_exam_getlang('s1449');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_exam_getlang('s1450');
	}else{
		$timecount=intval(($it618_time-$_G['timestamp'])/60);
		if($timecount>=1){
			$timestr=$timecount.it618_exam_getlang('s1451');
		}else{
			$timecount=intval(($it618_time-$_G['timestamp']));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_exam_getlang('s1452');
		}
	}
	
	return $timestr;
}

function it618_exam_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_exam_get_contents5($str){
	return dfsockopen($str);
}

function it618_exam_discuz_uc_avatar1($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   $uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_exam_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_exam']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_exam_getfileext($filestr){
	$file_ext=strtolower(substr($filestr,strrpos($filestr, '.')+1)); 
	$tmparr=explode("?",$file_ext);
	return $tmparr[0];
}

function it618_exam_getgoodspic($shopid,$pid,$it618_picbig,$i=0){
	$file_ext=it618_exam_getfileext($it618_picbig);
	
	return 'source/plugin/it618_exam/kindeditor/data/shop'.$shopid.'/smallimage/goods'.$pid.'_'.md5($it618_picbig).'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
}

function it618_exam_getwapppic($shopid,$pid,$get_it618_picbig,$type=1){
	$file_ext=it618_exam_getfileext($get_it618_picbig); 
	
	if($shopid=='wapad'){
		$file_ext=it618_exam_getfileext($get_it618_picbig); 
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			it618_exam_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,280,1);
		}
		
		$it618_smallurl='source/plugin/it618_exam/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
	}else{
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$shopid.'/smallimages/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;

		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
			
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$shopid.'/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$shopid.'/smallimages/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$shopid.'/smallimages/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;
			it618_exam_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,360,1);
		}
		
		$it618_smallurl='source/plugin/it618_exam/kindeditor/data/shop'.$shopid.'/smallimages/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;
	}
	
	return $it618_smallurl.'?'.substr(md5($get_it618_picbig),0,6);
}

function it618_exam_getpjpic($uid,$pjpicid,$picurl){
	$file_ext=it618_exam_getfileext($picurl); 

	$tmparr1=explode("://",$picurl);
	if(count($tmparr1)>1){
		$it618_url=$picurl;
	}else{
		$tmparr=explode("source",$picurl);
		$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
	}

	$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/user/u'.$uid.'/smallimages/pjpic'.$pjpicid.'.'.$file_ext;
	
	it618_exam_imagetosmall($it618_url,$it618_smallurl,$file_ext,48);

}

function it618_exam_hex2rgb($hexColor) {
	$color = str_replace('#', '', $hexColor);
	if (strlen($color) > 3) {
		$rgb = array(
			'r' => hexdec(substr($color, 0, 2)),
			'g' => hexdec(substr($color, 2, 2)),
			'b' => hexdec(substr($color, 4, 2))
		);
	} else {
		$color = $hexColor;
		$r = substr($color, 0, 1) . substr($color, 0, 1);
		$g = substr($color, 1, 1) . substr($color, 1, 1);
		$b = substr($color, 2, 1) . substr($color, 2, 1);
		$rgb = array(
			'r' => hexdec($r),
			'g' => hexdec($g),
			'b' => hexdec($b)
		);
	}
	return $rgb;
}

function it618_exam_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height=0,$type=0){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		$max=$width;
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function it618_exam_filedown($file_path,$file_name,$file_ext) {
	$tmparr=explode("://",$file_path);
	if(count($tmparr)>1){
		$info = get_headers($file_path, true);
		$file_size = $info['Content-Length'];
		readfile($file_path);
	}else{
		$file_path = iconv('utf-8', 'gb2312', $file_path);
		if (!file_exists($file_path)) {
		  echo 'err';exit;
		}
		$file_size = filesize($file_path);
		$fp = fopen($file_path, 'r');
		$buffer = 1024;
		$file_count = 0;
		while (!feof($fp) && ($file_size-$file_count>0)) {
		  $file_data = fread($fp, $buffer);
		  $file_count += $buffer;
		  echo $file_data;
		}
		fclose($fp);
	}
	
	if($file_ext=='gif'||$file_ext=='jpg'||$file_ext=='jpeg'||$file_ext=='png'){
		header("Content-type: image/$file_ext");
	}else{
		header("Content-type: application/octet-stream");
		header("Accept-Ranges: bytes");
		header("Accept-Length: {$file_size}");
		header("Content-Disposition: attachment;filename={$file_name}");
	}
	
	if(count($tmparr)>1){
		readfile($file_path);
	}else{
		$fp = fopen($file_path, 'r');
		$buffer = 1024;
		$file_count = 0;
		while (!feof($fp) && ($file_size-$file_count>0)) {
		  $file_data = fread($fp, $buffer);
		  $file_count += $buffer;
		  echo $file_data;
		}
		fclose($fp);
	}
}

function exam_is_mobile(){ 
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: Dism��taobao��com
?>