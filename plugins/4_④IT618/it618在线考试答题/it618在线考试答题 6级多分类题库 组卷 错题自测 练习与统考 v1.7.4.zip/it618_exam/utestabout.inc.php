<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

if(exam_is_mobile()){ 
	$tmpurl=it618_exam_getrewrite('exam_wap','utestabout','plugin.php?id=it618_exam:wap&pagetype=utestabout');
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$metatitle = $it618_exam_lang['s447'];

$shopid=0;
$homeurl=it618_exam_getrewrite('exam_home','','plugin.php?id=it618_exam:index');

if($_G['uid']>0){
	if($it618_exam_utest_exam=C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_shopid_uid_state12($shopid,$_G['uid'])){
		$tmpurl=it618_exam_getrewrite('exam_utest',$it618_exam_utest_exam['id'],'plugin.php?id=it618_exam:utest&eid='.$it618_exam_utest_exam['id']);
		dheader("location:$tmpurl"); /*dism - taobao - com*/
	}
}else{
	$tmpurl=it618_exam_getrewrite('exam_home','','plugin.php?id=it618_exam:index');
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$menuusername=$_G['username'];
$u_avatarimg=it618_exam_discuz_uc_avatar($_G['uid'],'middle');

if($templatename=='default'){
	$tmparr=explode('src="',$it618_exam['exam_logo']);
	$tmparr1=explode('"',$tmparr[1]);
	$logosrc=$tmparr1[0];
}

$errcount=C::t('#it618_exam#it618_exam_errquestions')->count_by_search('', '', '', $_G['uid']);
$it618_exam_lang['s1366']=str_replace("{count}",$errcount,$it618_exam_lang['s1366']);

$pagetype='utestabout';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename.'/exam_utest');
?>