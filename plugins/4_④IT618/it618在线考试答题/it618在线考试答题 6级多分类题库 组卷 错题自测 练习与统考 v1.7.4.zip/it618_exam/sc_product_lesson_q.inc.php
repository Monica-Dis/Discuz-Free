<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$ppp = 100;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$lid=intval($_GET['lid']);
$urlsql='&lid='.$lid;

$it618_exam_goods_lesson=C::t('#it618_exam#it618_exam_goods_lesson')->fetch_by_id($lid);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_exam_goods_questions', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_score'])) {
		foreach($_GET['it618_score'] as $id => $val) {

			C::t('#it618_exam#it618_exam_goods_questions')->update($id,array(
				'it618_score' => trim($_GET['it618_score'][$id]),
				'it618_mcqscore' => trim($_GET['it618_mcqscore'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$it618_examscore=C::t('#it618_exam#it618_exam_goods_questions')->sum_score_by_lid($lid);
	$it618_questioncount=C::t('#it618_exam#it618_exam_goods_questions')->count_by_lid($lid);
	C::t('#it618_exam#it618_exam_goods_lesson')->update($lid,array(
		'it618_questioncount' => $it618_questioncount,
		'it618_examscore' => $it618_examscore
	));
	
	if($it618_exam_goods_lesson['it618_type']==2){
		$it618_randcount=$it618_exam_goods_lesson['it618_randcount'];
		if($it618_randcount>$it618_questioncount)$it618_randcount=$it618_questioncount;
		
		C::t('#it618_exam#it618_exam_goods_lesson')->update($it618_exam_goods_lesson['id'],array(
			'it618_questioncount' => $it618_randcount,
			'it618_examscore' => $it618_examscore/$it618_questioncount*$it618_randcount
		));
	}
	
	$it618_questioncount=C::t('#it618_exam#it618_exam_goods_lesson')->sum_questioncount_by_pid($it618_exam_goods_lesson['it618_pid']);
	$it618_examscore=C::t('#it618_exam#it618_exam_goods_lesson')->sum_examscore_by_pid($it618_exam_goods_lesson['it618_pid']);
	C::t('#it618_exam#it618_exam_goods')->update($it618_exam_goods_lesson['it618_pid'],array(
		'it618_questioncount' => $it618_questioncount,
		'it618_examscore' => $it618_examscore
	));

	it618_cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s35'].$del.')', "plugin.php?id=it618_exam:sc_product_lesson_q&lid=$lid&page=$page", 'succeed');
}

it618_showformheader("plugin.php?id=it618_exam:sc_product_lesson_q&lid=$lid&page=$page");

showtableheaders('','it618_exam_goods_questions');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods_questions')." WHERE it618_lid=".$lid);
$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_exam:sc_product_lesson_q&lid=$lid");

echo '
<style>
.it618_exam_goods_questions img{max-height:40px}
</style>
<tr><td colspan=15>'.$it618_exam_lang['s1486'].$count.'<span style="float:right;color:#999">'.$it618_exam_lang['s661'].'</span></td></tr>
';

if($it618_exam_goods_lesson['it618_type']==2){
	echo '<tr><td colspan=15 style="color:red">'.$it618_exam_lang['s1492'].'</td></tr>';
	$readonly='readonly="readonly" onclick="alert(\''.$it618_exam_lang['s1493'].'\')"';
	showsubtitle(array($it618_exam_lang['s1259'],$class_set['classname_q3'].$class_set['classname_q4'],$it618_exam_lang['s1260'],$it618_exam_lang['s1355']));
}else{
	showsubtitle(array($it618_exam_lang['s1259'],$class_set['classname_q3'].$class_set['classname_q4'],$it618_exam_lang['s1260'],$it618_exam_lang['s1355'],$it618_exam_lang['s1261']));	
}

$n=1;$n1=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_questions')." WHERE it618_lid=".$lid." ORDER BY it618_order,id limit $startlimit,$ppp");
while($it618_exam_goods_questions = DB::fetch($query)) {
	$doexamcount=C::t('#it618_exam#it618_exam_test_exam_questions')->count_by_pid_qid($it618_exam_goods_questions['it618_pid'],$it618_exam_goods_questions['it618_qid']);
	
	$it618_exam_questions = C::t('#it618_exam#it618_exam_questions')->fetch_by_id($it618_exam_goods_questions['it618_qid']);
	$qclass3_name=C::t('#it618_exam#it618_exam_qclass3')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass3_id']);
	$qclass4_name=C::t('#it618_exam#it618_exam_qclass4')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass4_id']);
	$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_exam_questions['it618_qtypeid']);
	
	$it618_mcqscore='';
	if($it618_exam_questions['it618_qtypeid']==2){
		$it618_mcqscore='<input type="text" class="txt" id="mcqscore'.$n1.'" '.$readonly.' style="width:60px;text-align:center;margin-left:3px;color:#F0F" name="it618_mcqscore['.$it618_exam_goods_questions['id'].']" value="'.$it618_exam_goods_questions['it618_mcqscore'].'"><br><div style="margin-top:3px;color:#999">'.$it618_exam_lang['s238'].'</div>';
		$it618_mcqscore1='/<font color="#F0F">'.$it618_exam_goods_questions['it618_mcqscore'].'</font>';
		$n1=$n1+1;
	}
	
	if($it618_exam_goods_lesson['it618_type']!=2){
		$orderstr='<input type="text" class="txt" style="width:30px;text-align:center;" name="it618_order['.$it618_exam_goods_questions['id'].']" value="'.$it618_exam_goods_questions['it618_order'].'">';
	}
	
	$disabled="";
	if($doexamcount>0)$disabled="disabled=\"disabled\"";
	
	showtablerow('', array('', '', '', '', '', ''), array(
		'<div style="width:680px"><input class="checkbox" type="checkbox" id="chk_del'.$it618_exam_goods_questions['id'].'" name="delete[]" value="'.$it618_exam_goods_questions['id'].'" '.$disabled.'><label for="chk_del'.$it618_exam_goods_questions['id'].'">['.$qtypename.'] '.it618_exam_getsmsstr(it618_exam_strip_tags($it618_exam_questions['it618_name']),80).'</label></div>',
		$qclass3_name.' '.$qclass4_name,
		'<input type="text" class="txt" id="score'.$n.'" '.$readonly.' style="width:60px;text-align:center;color:red" name="it618_score['.$it618_exam_goods_questions['id'].']" value="'.$it618_exam_goods_questions['it618_score'].'">'.$it618_mcqscore,
		$doexamcount,
		$orderstr
	));
	$n=$n+1;
}

if($it618_mcqscore!=''){
	$tmpstr='<input type="text" class="txt" id="editmcqscore" style="width:60px;text-align:center;margin-right:3px;color:#F0F">';
}

echo '<script>
function geteditscore(){
	for(var n=1;n<'.$n.';n++){
		if(document.getElementById("editscore").value!="")document.getElementById("score"+n).value=document.getElementById("editscore").value;
	}
	for(var n=1;n<'.$n1.';n++){
		if(document.getElementById("editmcqscore").value!="")document.getElementById("mcqscore"+n).value=document.getElementById("editmcqscore").value;
	}
}
</script>';

echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_exam_getlang('s556').'</label> <input type="submit" class="btn" name="it618submit" value="'.it618_exam_getlang('s1481').'" /><input type=hidden value='.$page.' name=page />
<div style="float:right">'.$it618_exam_lang['s6'].'<input type="text" class="txt" id="editscore" style="width:60px;text-align:center;margin-right:3px;color:red"> '.$tmpstr.'<input type="button" class="btn" value="'.$it618_exam_lang['t81'].'" onclick="geteditscore()"></div></div><br></td></tr>';

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>