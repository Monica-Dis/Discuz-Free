<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

$lid=intval($_GET['lid']);
if($lid>0){
	$it618_exam_goods_lesson = C::t('#it618_exam#it618_exam_goods_lesson')->fetch_by_id($lid);
	$class2jsstr='getquestions(questionsurl);var lid='.$lid;
}else{
	$class2jsstr='getquestions(questionsurl);var lid=0';
}

$e3css=';display:none';
if($class_set['classname_e3_ishide']!=1){
	$tmpclass3='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_e3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpclass3.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$e3css=';display:';
}

$e4css=';display:none';
if($class_set['classname_e4_ishide']!=1){
	$tmpclass4='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_e4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpclass4.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$e4css=';display:';
}

$q1q2name=$class_set['classname_q1'];
$q2css=';display:none';
if($class_set['classname_q2_ishide']!=1){
	$q2css=';display:';
	$q1q2name=$class_set['classname_q1'].'/'.$class_set['classname_q2'];
}

$q3css=';display:none';
if($class_set['classname_q3_ishide']!=1){
	$tmpqclass3='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_q3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpqclass3.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$q3css=';display:';
}

$q4css=';display:none';
if($class_set['classname_q4_ishide']!=1){
	$tmpqclass4='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_q4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpqclass4.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$q4css=';display:';
}

$tmpqtype='<option value="0">'.it618_exam_getlang('s1250').'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_qtype')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmpqtype.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_typename'].'</option>';
}

echo '
<script charset="utf-8" src="source/plugin/it618_exam/js/Calendar.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/js/jquery.js"></script>
<script type="text/javascript" src="source/plugin/it618_exam/js/layer/layer.js"></script>
';

if($lid>0){
	showtableheaders('','it618_exam_questions');
}else{
	showtableheaders($it618_exam_lang['s1180'],'it618_exam_questions');
}

	echo '<tr><td colspan="15"><div class="fixsel"><form id="it618_exam">
	<input type="hidden" id="it618_class1_id" name="it618_class1_id" value="0">
	<input type="hidden" id="it618_class2_id" name="it618_class2_id" value="0">
	<input type="hidden" id="it618_qclass11_id" name="it618_qclass11_id" value="0">
	<input type="hidden" id="it618_qclass12_id" name="it618_qclass12_id" value="0">
	<input type="hidden" id="it618_qclass13_id" name="it618_qclass13_id" value="0">
	<input type="hidden" id="it618_qclass21_id" name="it618_qclass21_id" value="0">
	<input type="hidden" id="it618_qclass22_id" name="it618_qclass22_id" value="0">
	<input type="hidden" id="it618_qclass23_id" name="it618_qclass23_id" value="0">
	<input type="hidden" id="it618_qclass24_id" name="it618_qclass24_id" value="0">
	<input type="hidden" id="it618_qclass25_id" name="it618_qclass25_id" value="0">
	<input type="hidden" id="it618_qclass26_id" name="it618_qclass26_id" value="0">
	
	<style>
	#tr_questionslist img{max-height:40px}
	</style>
	
	<div style="background-color:#e1e1e1;border:#ccc 1px solid;padding:5px 2px;height:33px;line-height:33px;margin-bottom:19px;margin-top:10px;border-radius:3px;padding-left:10px">
	
	<input type="text" id="classq1" readonly="readonly" style="width:300px" onclick="showclasstree(1)"> <a id="classtreebtn1" href="javascript:" onclick="showclasstree(1)">'.$it618_exam_lang['s1248'].$class_set['classname_q1'].'</a>
	
	<span style="'.$q2css.'"><input type="text" id="classq2" readonly="readonly" style="width:300px" onclick="showclasstree(2)"> <a id="classtreebtn2" href="javascript:" onclick="showclasstree(2)">'.$it618_exam_lang['s1248'].$class_set['classname_q2'].'</a></span>
	
	<span style="float:right;margin-right:6px">
	<select id="it618_class3_id" name="it618_class3_id" style="margin-right:0px'.$e3css.'" onchange="getquestions(questionsurl)">'.$tmpclass3.'</select>
	<select id="it618_class4_id" name="it618_class4_id" style="margin-right:0px'.$e4css.'" onchange="getquestions(questionsurl)">'.$tmpclass4.'</select>
	<select id="it618_qclass3_id" name="it618_qclass3_id" style="margin-right:0px'.$q3css.'" onchange="getquestions(questionsurl)">'.$tmpqclass3.'</select>
	<select id="it618_qclass4_id" name="it618_qclass4_id" style="margin-right:0px'.$q4css.'" onchange="getquestions(questionsurl)">'.$tmpqclass4.'</select>
	</span>
	
	<div id="classtree1" class="classtree" style="display:none;position:absolute;background-color:#f9f9f9;border:#e8e8e8 1px solid;width:520px;height:520px">
		<iframe id="iframe1" width="100%" height="520" marginwidth="0" marginheight="0" frameborder="no" src="'.$_G['siteurl'].'plugin.php?id=it618_exam:classtree&type=1&ac=find"></iframe>
	</div>
	<div id="classtree2" class="classtree" style="display:none;position:absolute;background-color:#f9f9f9;border:#e8e8e8 1px solid;width:520px;height:520px">
		<iframe id="iframe2" width="100%" height="520" marginwidth="0" marginheight="0" frameborder="no" src="'.$_G['siteurl'].'plugin.php?id=it618_exam:classtree&type=2&ac=find"></iframe>
	</div>
	</div>
	
	'.it618_exam_getlang('s224').' <input type="text" id="it618_name" name="it618_name" class="txt" style="width:280px;margin-right:1px" />
	'.$it618_exam_lang['s792'].'<select name="pageppp" onchange="getppppage(this)"><option value="10">10</option><option value="30">30</option><option value="50">50</option><option value="100">100</option><option value="150">150</option><option value="200">200</option><option value="300">300</option><option value="400">400</option><option value="500">500</option><option value="1000">1000</option><option value="2000">2000</option></select>
	<select id="it618_isoption" name="it618_isoption" onchange="getquestions(questionsurl)"><option value=0>'.$it618_exam_lang['s401'].'</option><option value=1>'.$it618_exam_lang['s412'].'</option></select>
	<input type="button" class="btn" value="'.it618_exam_getlang('s1251').'" onclick="getquestions(questionsurl)" />
	<input type="button" class="btn" value="'.it618_exam_getlang('s1252').'" onclick="findinit()" />
	<span style="float:right;color:#999">
	<select id="it618_qtypeid" name="it618_qtypeid" onchange="getquestions(questionsurl)" style="margin-right:0px;color:blue">'.$tmpqtype.'</select>
	<input type="button" class="btn" value="'.it618_exam_getlang('s1253').'" onclick="addquestion()" />
	<input type="button" class="btn" value="'.it618_exam_getlang('s578').'" onclick="daoquestions()" />
	</span>
	</form></div></td></tr>';
	
	echo '<tr id="tr_questionssum"></tr>';
	
	if($e3css==';display:none'&&$e4css==';display:none'&&$q3css==';display:none'&&$q4css==';display:none'){
		$it618_exam_lang['s1186']='';
	}
	
	showsubtitle(array(it618_exam_getlang('s1181'), it618_exam_getlang('s1186'),$q1q2name,it618_exam_getlang('s1182'),it618_exam_getlang('s1190')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_exam/wap/images/loading.gif"></td></tr><tbody id="tr_questionslist"></tbody>';
	
	if($lid>0){
		$goodsquestions='<input type="button" class="btn" value="'.it618_exam_getlang('s1189').'" onclick="lidquestions()" /> <input type="button" class="btn" value="'.it618_exam_getlang('s1262').'" onclick="dellidquestions()" />';
	}
	
	echo '<tr><td colspan="15">
	<input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkquestion(this)" /><label for="chkallDx4b">'.it618_exam_getlang('s129').'</label>
	<input type="button" class="btn" value="'.it618_exam_getlang('s1187').'" onclick="delquestions()" />
	<input type="button" class="btn" value="'.it618_exam_getlang('s1188').'" onclick="movequestions()" />
	'.$goodsquestions.'
	<div id="questionspage" style="float:right"></div>
	</td></tr>';

showtablefooter(); /*dism��taobao��com*/
echo '
<script>
var questionsurl="'.$_G['siteurl'].'plugin.php?id=it618_exam:ajax";
function getquestions(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_questionslist").style.display="none";
	IT618_EXAM.post(url+"&ac=questions_get&lid='.$lid.'&formhash='.FORMHASH.'", IT618_EXAM("#it618_exam").serialize(),function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_EXAM("#tr_questionssum").html(tmparr[0]);
	IT618_EXAM("#tr_questionslist").html(tmparr[1]);
	IT618_EXAM("#questionspage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_questionslist").style.display="";
	}, "html");	
	questionsurl=url;
}

function getppppage(obj){
	questionsurl=questionsurl+"&page=1";
	getquestions(questionsurl);
}

function checkquestion(obj){
	var qids=document.getElementById("qids").value;
	var tmparr=qids.split(",");
	for(var i=0;i<tmparr.length;i++){
		if(tmparr[i]>0)document.getElementById("chk_q"+tmparr[i]).checked=obj.checked;
	}
}

function delquestions(){
	var qidchks="";
	var qids=document.getElementById("qids").value;
	var tmparr=qids.split(",");
	for(var i=0;i<tmparr.length;i++){
		if(tmparr[i]>0){
			if(document.getElementById("chk_q"+tmparr[i]).checked){
				qidchks=qidchks+"@"+tmparr[i];
			}
		}
	}
	
	if(qidchks==""){
		alert("'.$it618_exam_lang['s1150'].'");
		return;
	}
	
	if(confirm("'.$it618_exam_lang['s732'].'")){
		IT618_EXAM.get(questionsurl+"&qids="+qidchks+"&formhash='.FORMHASH.'", {ac:"questions_del"},function (data, textStatus){
			var tmparr=data.split("it618_split");
			if(tmparr[1]=="ok"){
				alert(tmparr[2]);
				getquestions(questionsurl);
			}else{
				alert(data);
			}
			document.getElementById("chkallDx4b").checked=false;
		}, "html");
	}
}

function addquestion(){
	if(document.getElementById("it618_qtypeid").value==0){
		alert("'.$it618_exam_lang['s368'].'");
		return;
	}
	
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left\' id=\'divaddtitle\'>'.$it618_exam_lang['s1194'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["93%", "98%"],
		content: "plugin.php?id=it618_exam:sc_question_save&ac=add&"+IT618_EXAM("#it618_exam").serialize(),
		cancel: function(index, layero){ 
			getquestions(questionsurl);
		}    
	});
}

function daoquestions(){
	if(document.getElementById("it618_qtypeid").value==0){
		alert("'.$it618_exam_lang['s368'].'");
		return;
	}
	
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left;color:blue\'>'.$it618_exam_lang['s578'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["100%", "100%"],
		content: "plugin.php?id=it618_exam:sc_question_dao&"+IT618_EXAM("#it618_exam").serialize(),
		cancel: function(index, layero){ 
			getquestions(questionsurl);
		}    
	});
}

function movequestions(){
	var qidchks="";
	var qids=document.getElementById("qids").value;
	var tmparr=qids.split(",");
	for(var i=0;i<tmparr.length;i++){
		if(tmparr[i]>0){
			if(document.getElementById("chk_q"+tmparr[i]).checked){
				qidchks=qidchks+"@"+tmparr[i];
			}
		}
	}
	
	if(qidchks==""){
		alert("'.$it618_exam_lang['s1150'].'");
		return;
	}
	
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left\' id=\'divaddtitle\'>'.$it618_exam_lang['s1188'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["93%", "98%"],
		content: "plugin.php?id=it618_exam:sc_editclass&qids="+qidchks,
		cancel: function(index, layero){ 
			
		}    
	});
}

function editquestion(qid){
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left\'>'.$it618_exam_lang['s1201'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["93%", "98%"],
		content: "plugin.php?id=it618_exam:sc_question_save&ac=edit&qid="+qid,
		cancel: function(index, layero){ 
			getquestions(questionsurl);
		}    
	});
}

function delquestion(qid){
	if(confirm("'.$it618_exam_lang['s1209'].'")){
		IT618_EXAM.get(questionsurl+"&qid="+qid+"&formhash='.FORMHASH.'", {ac:"question_del"},function (data, textStatus){
			var tmparr=data.split("it618_split");
			if(tmparr[1]=="ok"){
				alert(tmparr[2]);
				getquestions(questionsurl);
			}else{
				alert(data);
			}
		}, "html");	
	}
}

function lidquestion(lid,qid){
	IT618_EXAM.get(questionsurl+"&lid="+lid+"&qid="+qid+"&formhash='.FORMHASH.'", {ac:"question_lid"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[1]=="ok"){
			getquestions(questionsurl);
		}else{
			alert(data);
		}
	}, "html");	
}

function dellidquestion(lid,qid){
	IT618_EXAM.get(questionsurl+"&lid="+lid+"&qid="+qid+"&formhash='.FORMHASH.'", {ac:"delquestion_lid"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[1]=="ok"){
			getquestions(questionsurl);
		}else{
			alert(data);
		}
	}, "html");	
}

function lidquestions(){
	var qidchks="";
	var qids=document.getElementById("qids").value;
	var tmparr=qids.split(",");
	for(var i=0;i<tmparr.length;i++){
		if(tmparr[i]>0){
			if(document.getElementById("chk_q"+tmparr[i]).checked){
				qidchks=qidchks+"@"+tmparr[i];
			}
		}
	}
	
	if(qidchks==""){
		alert("'.$it618_exam_lang['s1150'].'");
		return;
	}

	IT618_EXAM.get(questionsurl+"&lid='.$lid.'&qids="+qidchks+"&formhash='.FORMHASH.'", {ac:"questions_lid"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[1]=="ok"){
			getquestions(questionsurl);
		}else{
			alert(data);
		}
		document.getElementById("chkallDx4b").checked=false;
	}, "html");	
}

function dellidquestions(){
	var qidchks="";
	var qids=document.getElementById("qids").value;
	var tmparr=qids.split(",");
	for(var i=0;i<tmparr.length;i++){
		if(tmparr[i]>0){
			if(document.getElementById("chk_q"+tmparr[i]).checked){
				qidchks=qidchks+"@"+tmparr[i];
			}
		}
	}
	
	if(qidchks==""){
		alert("'.$it618_exam_lang['s1150'].'");
		return;
	}

	IT618_EXAM.get(questionsurl+"&lid='.$lid.'&qids="+qidchks+"&formhash='.FORMHASH.'", {ac:"delquestions_lid"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[1]=="ok"){
			getquestions(questionsurl);
		}else{
			alert(data);
		}
		document.getElementById("chkallDx4b").checked=false;
	}, "html");	
}

'.$class2jsstr.'

function findinit(){
   document.getElementById("it618_class1_id").value=0;
   document.getElementById("it618_class2_id").value=0;
   document.getElementById("it618_class3_id").value=0;
   document.getElementById("it618_class4_id").value=0;
   document.getElementById("classq1").value="";
   document.getElementById("classq2").value="";
   document.getElementById("it618_qclass11_id").value=0;
   document.getElementById("it618_qclass12_id").value=0;
   document.getElementById("it618_qclass13_id").value=0;
   document.getElementById("it618_qclass21_id").value=0;
   document.getElementById("it618_qclass22_id").value=0;
   document.getElementById("it618_qclass23_id").value=0;
   document.getElementById("it618_qclass24_id").value=0;
   document.getElementById("it618_qclass25_id").value=0;
   document.getElementById("it618_qclass26_id").value=0;
   document.getElementById("iframe1").src="";
   document.getElementById("iframe2").src="";
   document.getElementById("it618_qclass3_id").value=0;
   document.getElementById("it618_qclass4_id").value=0;
   document.getElementById("it618_qtypeid").value=0;
   document.getElementById("it618_name").value="";
   getquestions(questionsurl);
}

function showclasstree(index) {
	var cityObj = $("#classq"+index);
	var cityOffset = $("#classq"+index).offset();

	IT618_EXAM("#classtree"+index).css({left:cityOffset.left + "px", top:cityOffset.top + cityObj.outerHeight() + "px"}).slideDown("fast");
	
	if(index==1){
		IT618_EXAM("body").bind("mousedown", onBodyDown1);
	}else{
		IT618_EXAM("body").bind("mousedown", onBodyDown2);
	}
}

function hideclasstree(index) {
	IT618_EXAM("#classtree"+index).fadeOut("fast");
	if(index==1){
		IT618_EXAM("body").unbind("mousedown", onBodyDown1);
	}else{
		IT618_EXAM("body").unbind("mousedown", onBodyDown2);
	}
}

function onBodyDown1(event) {
	if (!(event.target.id == "classtreebtn1" || event.target.id == "classq1" || event.target.id == "classtree1")) {
		hideclasstree(1);
	}
}

function onBodyDown2(event) {
	if (!(event.target.id == "classtreebtn2" || event.target.id == "classq2" || event.target.id == "classtree2")) {
		hideclasstree(2);
	}
}
</script>
';

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>