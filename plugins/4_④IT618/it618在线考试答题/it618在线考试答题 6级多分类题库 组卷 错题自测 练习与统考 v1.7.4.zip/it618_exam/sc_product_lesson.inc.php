<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$pid=intval($_GET['pid']);
$preurl=$_GET['preurl'];
$urlsql='&pid='.$pid;

$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_exam_goods_lesson', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_order'])) {
		foreach($_GET['it618_order'] as $id => $val) {
			
			$it618_exam_goods_lesson=C::t('#it618_exam#it618_exam_goods_lesson')->fetch_by_id($id);
			
			C::t('#it618_exam#it618_exam_goods_lesson')->update($id,array(
				'it618_dispcount' => trim($_GET['it618_dispcount'][$id]),
				'it618_isdispoption' => trim($_GET['it618_isdispoption'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			
			if($it618_exam_goods_lesson['it618_type']==2){
				$it618_questioncount=C::t('#it618_exam#it618_exam_goods_questions')->count_by_lid($id);
				$it618_randcount=trim($_GET['it618_randcount'][$id]);
				if($it618_randcount>$it618_questioncount)$it618_randcount=$it618_questioncount;
				
				$it618_examscore=C::t('#it618_exam#it618_exam_goods_questions')->sum_score_by_lid($id);
				
				C::t('#it618_exam#it618_exam_goods_lesson')->update($id,array(
					'it618_randcount' => $it618_randcount,
					'it618_questioncount' => $it618_randcount,
					'it618_examscore' => $it618_examscore/$it618_questioncount*$it618_randcount
				));
			}
			
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_type_array = !empty($_GET['newit618_type']) ? $_GET['newit618_type'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		
		if(trim($newit618_name_array[$key]) != '') {
			                                        
			C::t('#it618_exam#it618_exam_goods_lesson')->insert(array(
				'it618_pid' => $pid,
				'it618_name' => it618_exam_strip_tags(trim($newit618_name_array[$key]),'<img> <iframe> <sub> <sup> <u> <br>'),
				'it618_type' => trim($newit618_type_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}
	
	$it618_lessoncount=C::t('#it618_exam#it618_exam_goods_lesson')->count_by_pid($pid);
	$it618_questioncount=C::t('#it618_exam#it618_exam_goods_lesson')->sum_questioncount_by_pid($pid);
	$it618_examscore=C::t('#it618_exam#it618_exam_goods_lesson')->sum_examscore_by_pid($pid);
	C::t('#it618_exam#it618_exam_goods')->update($pid,array(
		'it618_lessoncount' => $it618_lessoncount,
		'it618_questioncount' => $it618_questioncount,
		'it618_examscore' => $it618_examscore
	));

	it618_cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s34'].$ok2.' '.$it618_exam_lang['s35'].$del.')', "plugin.php?id=it618_exam:sc_product_lesson&pid=$pid&preurl=$preurl", 'succeed');
}

echo '
<script charset="utf-8" src="source/plugin/it618_exam/js/jquery.js"></script>
<script type="text/javascript" src="source/plugin/it618_exam/js/layer/layer.js"></script>
';

it618_showformheader("plugin.php?id=it618_exam:sc_product_lesson&pid=$pid&preurl=$preurl");

$preurlhref=str_replace("@","&",$preurl);
showtableheaders('<a href="'.$preurlhref.'">'.$it618_exam_lang['s810'].'<font color=red>'.$it618_exam_lang['s514'].$it618_exam_goods['it618_name'].$it618_exam_lang['s515'].'</font></a> '.$it618_exam_lang['s809'],'admin_shopproduct_type');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_goods_lesson')." WHERE it618_pid=".$pid);

echo '<tr><td colspan=15>'.$it618_exam_lang['s811'].$count.'<span style="float:right;color:#999">'.$it618_exam_lang['s827'].'</span></td></tr>';

if($it618_exam_goods['it618_gtype']==1){
	showsubtitle(array('', $it618_exam_lang['s812'],$it618_exam_lang['s1092'],$it618_exam_lang['s1096'],$it618_exam_lang['s231'],$it618_exam_lang['s1247'],$it618_exam_lang['s503']));
}else{
	showsubtitle(array('', $it618_exam_lang['s812'],$it618_exam_lang['s1092'],'',$it618_exam_lang['s231'],$it618_exam_lang['s1247'],$it618_exam_lang['s503']));
	$gtypecss='display:none';
}

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order");
while($it618_exam_goods_lesson = DB::fetch($query)) {
	$it618_examcount=C::t('#it618_exam#it618_exam_goods_questions')->count_by_lid($it618_exam_goods_lesson['id']);
	
	$disabled="";
	if($it618_examcount>0)$disabled="disabled=\"disabled\"";
	
	if($it618_exam_goods_lesson['it618_type']==1){
		$it618_type=$it618_exam_lang['s1093'];
		$randcount='';
	}else{
		$it618_type=$it618_exam_lang['s1094'];

		$randcount=' <input type="text" class="txt" style="width:40px;text-align:center;margin-right:3px;color:red" name="it618_randcount['.$it618_exam_goods_lesson['id'].']" value="'.$it618_exam_goods_lesson['it618_randcount'].'">'.$it618_exam_lang['s371'];
	}
	
	$it618_exam_goods_lesson['it618_examscore']=str_replace(".0","",$it618_exam_goods_lesson['it618_examscore']);
	
	if($it618_exam_goods_lesson['it618_isdispoption']==1){
		$it618_isdispoption_checked='checked="checked"';
	}else{
		$it618_isdispoption_checked="";
	}
	
	$it618_nametmp=str_replace(array("\r\n", "\r", "\n"), ' ', it618_exam_strip_tags($it618_exam_goods_lesson['it618_name']));

	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_exam_goods_lesson['id'].'" name="delete[]" value="'.$it618_exam_goods_lesson['id'].'" '.$disabled.'><label for="chk_del'.$it618_exam_goods_lesson['id'].'">'.$it618_exam_goods_lesson['id'].'</label>',
		'<div style="margin:6px 0px;width:580px"><div style="font-size:13px;color:#000;margin-bottom:6px">
		
		'.
		it618_exam_strip_tags($it618_exam_goods_lesson['it618_name']).'
		</div>
		
		<img src="source/plugin/it618_exam/images/tmtitle.png" style="vertical-align:middle;height:14px;margin-top:-1px;margin-right:3px"><a href="javascript:" onclick="showedit('.$it618_exam_goods_lesson['id'].',\''.$it618_exam_goods['it618_name'].' -> '.it618_exam_getsmsstr($it618_nametmp,60).'\')">'.$it618_exam_lang['s1477'].'</a>
		
		</div>',
		$it618_type.$randcount.'<br><div style="margin-top:6px"><img src="source/plugin/it618_exam/images/addtm.png" style="vertical-align:middle;height:14px;margin-top:-1px;margin-right:3px"><a href="javascript:" onclick="addquestions('.$it618_exam_goods_lesson['id'].',\''.$it618_exam_goods['it618_name'].' -> '.it618_exam_getsmsstr($it618_nametmp,60).'\')">'.$it618_exam_lang['s817'].'</a> <img src="source/plugin/it618_exam/images/tm.png" style="vertical-align:middle;height:15px;margin-top:-1px;margin-right:3px"><a href="javascript:" onclick="editquestions('.$it618_exam_goods_lesson['id'].',\''.$it618_exam_goods['it618_name'].' -> '.it618_exam_getsmsstr($it618_nametmp,60).'\')">'.$it618_exam_lang['s813'].'</a> <font color="#888">('.$it618_examcount.')</font></div>',
		'<span style="'.$gtypecss.'"><input type="text" class="txt" style="width:58px;margin-bottom:3px;text-align:center;" name="it618_dispcount['.$it618_exam_goods_lesson['id'].']" value="'.$it618_exam_goods_lesson['it618_dispcount'].'"><br><input type="checkbox" id="it618_isdispoption'.$it618_exam_goods_lesson['id'].'" name="it618_isdispoption['.$it618_exam_goods_lesson['id'].']" value="1" style="vertical-align:middle;margin-left:0" '.$it618_isdispoption_checked.'><label for="it618_isdispoption'.$it618_exam_goods_lesson['id'].'">'.$it618_exam_lang['s956'].'</label></span>',
		'<font color=red>'.$it618_exam_goods_lesson['it618_questioncount'].'</font>',
		'<font color=red>'.$it618_exam_goods_lesson['it618_examscore'].'</font>',
		'<input type="text" class="txt" style="width:30px;text-align:center;" name="it618_order['.$it618_exam_goods_lesson['id'].']" value="'.$it618_exam_goods_lesson['it618_order'].'">'
	));
		
	$n=$n+1;
}

echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/plugins/code/prettify.js"></script>

<script>
var curn,TMPK;

KindEditor.ready(function(K) {
	TMPK=K;
});

function addeditor(n){
	TMPK.create(\'textarea[id="txtname\'+n+\'"]\', {
		cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
		uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
		fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
		allowFileManager : true,
		filterMode:false,
		minHeight:58,
		newlineTag:"br",
		afterBlur: function () { this.sync(); },
		items : [\'source\', \'|\', \'undo\', \'redo\', \'|\', \'image\',\'multiimage\',\'it618media\', \'|\', \'it618latex\', \'subscript\',
	\'superscript\', \'|\', \'fullscreen\']
	});
}

function showedit(lid,title){
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left;color:blue\'>'.$it618_exam_lang['s1477'].'<font color=#999> - "+title+"</font></div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["93%", "98%"],
		content: "plugin.php?id=it618_exam:sc_product_lessonedit'.$adminsid.'&lid="+lid,
		cancel: function(index, layero){ 
			location.reload();
		}    
	});
}
	
function addquestions(lid,title){
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left;color:blue\'>'.$it618_exam_lang['s817'].'<font color=#999> - "+title+"</font></div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["100%", "100%"],
		content: "plugin.php?id=it618_exam:sc_question&lid="+lid,
		cancel: function(index, layero){ 
			location.reload();
		}    
	});
}

function editquestions(lid,title){
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left;color:blue\'>"+title+" - '.$it618_exam_lang['s813'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["100%", "100%"],
		content: "plugin.php?id=it618_exam:sc_product_lesson_q&lid="+lid,
		cancel: function(index, layero){ 
			location.reload();
		}    
	});
}
</script>
';

	$typeoption='<option value="1">'.$it618_exam_lang['s1093'].'</option><option value="2">'.$it618_exam_lang['s1094'].'</option>';
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		curn=n;
		
		return [
		[[1,''], 
		[1,'<textarea class="textarea" id="txtname'+n+'" style="width:580px;height:38px;visibility:hidden;" name="newit618_name[]"></textarea>'],
		[1,'<select name="newit618_type[]">$typeoption</select>'],
		[1,''],
		[1,''],
		[1,''],
		[1,'<input type="text" class="txt" style="width:30px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0);addeditor(curn)" class="addtr">'.$it618_exam_lang['s831'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>