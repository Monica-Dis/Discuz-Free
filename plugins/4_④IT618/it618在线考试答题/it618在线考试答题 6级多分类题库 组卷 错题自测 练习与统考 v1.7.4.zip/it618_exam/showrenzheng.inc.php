<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

$uid = $_G['uid'];
if($uid<=0){
	return;
}else{
	$rzpower=1;
	$exam_rzpower=(array)unserialize($it618_exam['exam_rzpower']);
	$okvipgroupids=it618_exam_getisvipuser($exam_rzpower);
	if(count($okvipgroupids[0])==0){
		$rzpower=0;
	}else{
		if($it618_exam['exam_iscert']==1){
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
				if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
					$rzpower=2;
				}
			}
		}
	}
	
	$ispost=1;
	$username=C::t('#it618_exam#it618_exam_sale')->fetch_username_by_uid($uid);
	if(C::t('#it618_exam#it618_exam_shop')->count_by_it618_uid($uid)>0&&$uid>0){
		$t=it618_exam_getlang('s472');
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($uid);
		$it618_state=$it618_exam_shop['it618_state'];
		if($it618_state==0){
			$statestr=it618_exam_getlang('s473');
			$ispost=0;
		}elseif($it618_state==1){
			$statestr=it618_exam_getlang('s474');
		}
		$tip="$username ".it618_exam_getlang('s475')." ".date('Y-m-d H:i:s', $it618_exam_shop['it618_time'])." ".it618_exam_getlang('s476')."<font color=red>".$statestr."</font>";
		if($it618_state==2){
			$t=it618_exam_getlang('s477');
			$exam_sc=it618_exam_getrewrite('exam_sc','','plugin.php?id=it618_exam:sc');
			$tip="$username ".it618_exam_getlang('s478')."<br><a href='".$exam_sc."' target='_blank'>".it618_exam_getlang('s479')."</a>";
			$ispost=0;
		}
		
		$it618_name=$it618_exam_shop['it618_name'];
		$it618_tel=$it618_exam_shop['it618_tel'];
		$it618_qq=$it618_exam_shop['it618_qq'];
		$it618_about=$it618_exam_shop['it618_about'];
		
		$rzpower=1;
	}else{
		$t=it618_exam_getlang('s480');
		$tip="$username ".it618_exam_getlang('s481');
	}
	
	if($rzpower==0||$rzpower==2){
		$ispost=0;
	}
	
	$btnname=$it618_exam_lang['t79'];
	$oktip=$it618_exam_lang['t80'];
	
	$rzabout=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('rzabout');
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:showrenzheng');
?>