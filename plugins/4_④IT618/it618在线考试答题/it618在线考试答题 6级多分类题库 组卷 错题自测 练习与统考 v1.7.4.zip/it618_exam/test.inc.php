<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];

$eid=intval($_GET['eid']);
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

if(exam_is_mobile()){ 
	$tmpurl=it618_exam_getrewrite('exam_wap','test@'.$eid,'plugin.php?id=it618_exam:wap&pagetype=test&cid='.$eid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if(!$it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($eid)){
	$tmpurl=it618_exam_getrewrite('exam_home','','plugin.php?id=it618_exam:index');
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}else{
	$pid=$it618_exam_test_exam['it618_pid'];
	
	if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
		echo it618_exam_getlang('s470').' <a href="'.$homeurl.'">'.$it618_exam_lang['s18'].'</a>';exit;
	}else{
		if(!it618_exam_issecretok($it618_exam_goods)){
			echo it618_exam_getlang('s470').' <a href="'.$homeurl.'">'.$it618_exam_lang['s18'].'</a>';exit;
		}
		
		$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
		if($it618_exam_shop['it618_state']!=2||$it618_exam_shop['it618_htstate']!=1){
			echo it618_exam_getlang('s470').' <a href="'.$homeurl.'">'.$it618_exam_lang['s18'].'</a>';exit;
		}
	}
	
	$paperurl=it618_exam_getrewrite('exam_product',$pid,'plugin.php?id=it618_exam:product&pid='.$pid);
	
	if($it618_exam_test_exam['it618_uid']!=$_G['uid']){
		if($it618_exam_test_exam['it618_state']==3){
			if($it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($_G['uid'])){
					
				$it618_state=$it618_exam_shop['it618_state'];
				if($it618_state==0){
					echo it618_exam_getlang('s334');exit;
				}elseif($it618_state==1){
					echo it618_exam_getlang('s335');exit;
				}else{
					$it618_htstate=$it618_exam_shop['it618_htstate'];
					if($it618_htstate==0){
						echo it618_exam_getlang('s336');exit;
					}elseif($it618_htstate==2){
						echo it618_exam_getlang('s337');exit;
					}else{
						if($it618_exam_test_exam['it618_shopid']!=$it618_exam_shop['id']){
							dheader("location:$paperurl");
						}else{
							$examuname=it618_exam_getusername($it618_exam_test_exam['it618_uid']);
							$examuavatarimg=it618_exam_discuz_uc_avatar($it618_exam_test_exam['it618_uid'],'middle');
						}
					}
				}
				
			}
		}else{
			dheader("location:$paperurl");
		}
	}
	
	if($_GET['qid']>0){
		$qidn=1;
		$query = DB::query("SELECT * FROM ".DB::table('it618_exam_test_exam_questions')." WHERE it618_eid=".$eid." ORDER BY it618_order,id");
		while($it618_exam_test_exam_questions = DB::fetch($query)) {
			if($it618_exam_test_exam_questions['it618_qid']==$_GET['qid']){
				break;
			}
			$qidn=$qidn+1;
		}
	}
	
	$it618_exam_test_pj=C::t('#it618_exam#it618_exam_test_pj')->fetch_by_pid_uid($pid,$_G['uid']);

	$tmpcode=md5($_G['timestamp'].FORMHASH.rand());
		
	C::t('#it618_exam#it618_exam_examwork')->insert(array(
		'it618_code' => $tmpcode,
		'it618_exam' => 'it618_split'.$eid
	), true);
}

$homeurl=it618_exam_getrewrite('exam_home','','plugin.php?id=it618_exam:index');

$metatitle = $it618_exam_goods['it618_name'];

$menuusername=$_G['username'];
$u_avatarimg=it618_exam_discuz_uc_avatar($_G['uid'],'middle');

if($templatename=='default'){
	$tmparr=explode('src="',$it618_exam['exam_logo']);
	$tmparr1=explode('"',$tmparr[1]);
	$logosrc=$tmparr1[0];
}

$pagetype='test';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:'.$templatename.'/exam_test');
?>