<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_exam;

$it618_exam = $_G['cache']['plugin']['it618_exam'];
$creditname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';

function it618_exam_template_pchomehotgoods($templatename,$hotclassgoods){
	global $_G,$it618_exam,$it618_exam_lang,$creditname;
	
	if($templatename=='default'){
		
		$tmpidsarr=explode(',',$hotclassgoods);
		$n=1;
		for($i=1;$i<=count($tmpidsarr);$i++){
			$id=intval($tmpidsarr[$i-1]);
			$it618sql='g.it618_gtype=1 and g.it618_state=1 and g.id='.$id;
			foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
				$it618sql,'',0,0,0,0,0,'',0,0,0,0
			) as $it618_exam_goods) {
				$it618_exam_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_exam_shop')." WHERE id=".$it618_exam_goods['it618_shopid']);
				
				if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
					$pricestr='<span class="price">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span style="color:#390;">'.$it618_exam_lang['s106'].'</span>';
				}
				
				$it618_isvip='';
				$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
				if(count($vipgroupids)>0){
					$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				}
				
				$jfbl='';
				if($it618_exam_goods['it618_jfbl']>0&&$it618_exam_goods['it618_saleprice']>0){
					if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_goods['id'])>0){
						//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].str_replace(".00","",$it618_exam_goods['it618_jfbl']).'%'.$creditname.'</div>';
					}else{
						//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].intval($it618_exam_goods['it618_saleprice']*$it618_exam_goods['it618_jfbl']/100).$creditname.'</div>';
					}
				}
				
				$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				$homehotgoods.='<div class="course-card" title="'.$it618_exam_goods['it618_name'].'">
									'.$jfbl.'
									<div class="course-img">
										<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" alt="'.$it618_exam_goods['it618_name'].'" class="goodsimg"></a>
										<div class="course-name">
											<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_exam_goods['it618_name'],58,'...').'</a>
										</div>
										<div class="course-author">
											'.$it618_isvip.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'
											<a href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_shop['it618_name'].'">'.cutstr($it618_exam_shop['it618_name'],18,'...').'</a>
										</div>
										<div class="course-price">
											'.$pricestr.'
											<span class="course-plays">'.$it618_exam_goods['it618_tests'].''.it618_exam_getlang('s931').'</span>
										</div>
									</div>
								</div>';
			}
		}
	}
	
	return $homehotgoods;
}

function it618_exam_template_pchomeclassgoods($templatename){
	global $_G,$it618_exam,$it618_exam_lang,$creditname;
	
	if($templatename=='default'){
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class1')." ORDER BY it618_order");
		while($it618_exam_class1 = DB::fetch($query1)) {
			
			if($it618_exam_class1['it618_goodscount']==0)continue;
			
			$tmpurl=it618_exam_getrewrite('exam_list',$it618_exam_class1['id'],'plugin.php?id=it618_exam:list&class1='.$it618_exam_class1['id']);
			$str_goods.='<div class="content">
							  <div class="content-c">
								  <div class="homemoddiv">
									  <div class="homemodtitle">
										  <h3><a href="'.$tmpurl.'">'.$it618_exam_class1['it618_classname'].'</a></h3>
									  </div>
									  {it618goods}
								  </div>
						  
							  </div>
						  </div>';
			
			$it618goods='';
			foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
				'g.it618_gtype=1 and g.it618_state=1','g.it618_order desc,g.id desc',0,$it618_exam_class1['id'],0,0,0,'',0,0,$startlimit,$it618_exam_class1['it618_goodscount']*5
			) as $it618_exam_goods) {
				$it618_exam_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_exam_shop')." WHERE id=".$it618_exam_goods['it618_shopid']);
				
				if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
					$pricestr='<span class="price">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span style="color:#390;">'.$it618_exam_lang['s106'].'</span>';
				}
				
				$it618_isvip='';
				$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
				if(count($vipgroupids)>0){
					$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				}
				
				$jfbl='';
				if($it618_exam_goods['it618_jfbl']>0&&$it618_exam_goods['it618_saleprice']>0){
					if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_goods['id'])>0){
						//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].str_replace(".00","",$it618_exam_goods['it618_jfbl']).'%'.$creditname.'</div>';
					}else{
						//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].intval($it618_exam_goods['it618_saleprice']*$it618_exam_goods['it618_jfbl']/100).$creditname.'</div>';
					}
				}
				
				$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				$it618goods.='<div class="course-card" title="'.$it618_exam_goods['it618_name'].'">
									'.$jfbl.'
									<div class="course-img">
										<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" alt="'.$it618_exam_goods['it618_name'].'" class="goodsimg"></a>
										<div class="course-name">
											<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_exam_goods['it618_name'],58,'...').'</a>
										</div>
										<div class="course-author">
											'.$it618_isvip.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'
											<a href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_shop['it618_name'].'">'.cutstr($it618_exam_shop['it618_name'],18,'...').'</a>
										</div>
										<div class="course-price">
											'.$pricestr.'
											<span class="course-plays">'.$it618_exam_goods['it618_tests'].''.it618_exam_getlang('s931').'</span>
										</div>
									</div>
								</div>';
			}
			
			$str_goods=str_replace("{it618goods}",$it618goods,$str_goods);
		}
	}
	
	return $str_goods;
}

function it618_exam_template_pcpagetjgoods($templatename,$shopid){
	global $_G,$it618_exam,$it618_exam_lang;
	
	if($templatename=='default'){
		
		$it618sql='g.it618_gtype=1 and g.it618_state=1';
		foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
			$it618sql,'g.it618_shoporder desc,g.it618_tests desc',$shopid,0,0,0,0,'',0,0,0,5
		) as $it618_exam_goods) {
			
			if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
				$pricestr='<span class="price">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span style="color:#390;">'.$it618_exam_lang['s106'].'</span>';
			}
			
			$it618_isvip='';
			$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
			}
			
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			$tjgoods.='<div class="course-card" title="'.$it618_exam_goods['it618_name'].'">
								<div class="course-img">
									<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" alt="'.$it618_exam_goods['it618_name'].'" class="goodsimg"></a>
									<div class="course-name">
										<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_exam_goods['it618_name'],58,'...').'</a>
									</div>
									<div class="course-author">
											'.$it618_isvip.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'
										</div>
										<div class="course-price">
											'.$pricestr.'
											<span class="course-plays">'.$it618_exam_goods['it618_tests'].''.it618_exam_getlang('s931').'</span>
										</div>
								</div>
							</div>';
		}
	}
	
	return $tjgoods;
}
//From: Dism��taobao��com
?>