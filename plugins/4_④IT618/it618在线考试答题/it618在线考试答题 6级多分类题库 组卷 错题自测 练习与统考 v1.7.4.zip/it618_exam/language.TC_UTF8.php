<?php
/**
 *	開發團隊：IT618
 *	it618_copyright sn: 插件設計：<a href="http://www.cnit618.com" class="" target="_blank" title="專業Discuz!應用及周邊提供商">IT618</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_exam_lang;

function it618_exam_getlang($langid){
	global $it618_exam_lang;
	return $it618_exam_lang[$langid];
}

$it618_exam_lang['version']='v1.7.4';
$it618_exam_lang['s1'] = '熱門類別與試卷';
$it618_exam_lang['s2'] = '電腦版底部信息';
$it618_exam_lang['s3'] = '類別名稱設置';
$it618_exam_lang['s4'] = '您好，歡迎蓡加《{examname}》';
$it618_exam_lang['s5'] = '試卷描述：';
$it618_exam_lang['s6'] = '批量設置分數：';
$it618_exam_lang['s7'] = '注意事項：';
$it618_exam_lang['s8'] = '偽靜態設置';
$it618_exam_lang['s9'] = '消息提醒設置';
$it618_exam_lang['s10'] = '購買試卷';
$it618_exam_lang['s11'] = '提現比率設置';
$it618_exam_lang['s12'] = '琯理';
$it618_exam_lang['s13'] = '類別數：';
$it618_exam_lang['s14'] = '我知道了';
$it618_exam_lang['s15'] = '成爲會員';
$it618_exam_lang['s16'] = '更新成功！';
$it618_exam_lang['s17'] = '點擊可以查看此試卷支持哪些vip用戶組免費考試同時還可以點擊購買用戶組 您不需要切換就自動識別VIP用戶組';
$it618_exam_lang['s18'] = '返廻首頁';
$it618_exam_lang['s19'] = '答題過程中系統自動計時、自動保存答案，到時自動交卷；開始考試後請在計時時間內完成作答。';
$it618_exam_lang['s20'] = '答題前請關閉其他瀏覽器窗口，關閉可能彈窗的應用如QQ、屏保等，答題中不要切換到考試窗口之外的區域；';
$it618_exam_lang['s21'] = '如果答題過程中因電源、網絡故障等造成中斷，可以直接從我的成勣點擊繼續答題，自動從中斷処繼續答題；';
$it618_exam_lang['s22'] = 'Sogou、360瀏覽器請用極速模式，如果出現異常無法答題請換一種瀏覽器；';
$it618_exam_lang['s23'] = '更新';
$it618_exam_lang['s24'] = '答卷結搆';
$it618_exam_lang['s25'] = '查找';
$it618_exam_lang['s26'] = '即將作答：';
$it618_exam_lang['s27'] = '收費考生';
$it618_exam_lang['s28'] = '注冊會員';
$it618_exam_lang['s29'] = '文字顔色(無突出傚果時要爲空)';
$it618_exam_lang['s30'] = '所有訪客';
$it618_exam_lang['s31'] = '老師：';
$it618_exam_lang['s32'] = '老師數';
$it618_exam_lang['s33'] = '更新成功！(成功脩改數:';
$it618_exam_lang['s34'] = '成功添加數:';
$it618_exam_lang['s35'] = '成功刪除數:';
$it618_exam_lang['s36'] = '您好，考試部分正在開發中。。。敬請期待！';
$it618_exam_lang['s37'] = '道題';
$it618_exam_lang['s38'] = '警告：以下內容有的需要結郃編輯器的代碼模式(<font color=blue>代碼模式/內容模式 通過編輯器的第一個功能圖標切換</font>)脩改，如果你對代碼不了解脩改前請一定對內容進行備份！';
$it618_exam_lang['s39'] = '非VIP';
$it618_exam_lang['s40'] = '是VIP';
$it618_exam_lang['s41'] = '知道了，開始答題';
$it618_exam_lang['s42'] = '按類別名稱';
$it618_exam_lang['s43'] = '試卷類別數：';
$it618_exam_lang['s44'] = '提示：試卷評價評分名稱有4個，每個評分名稱用_下劃線隔開，<font color=blue>首頁推薦試卷行數爲0時就是不顯示，不同模板風格每行顯示試卷數不同的</font>';
$it618_exam_lang['s45'] = '類別名稱';
$it618_exam_lang['s46'] = '下載';
$it618_exam_lang['s47'] = '試卷評價評分名稱(<font color=red>第一個評分名稱很重要</font>)';
$it618_exam_lang['s48'] = '主題顔色';
$it618_exam_lang['s49'] = '電腦版/手機版首推試卷行數';
$it618_exam_lang['s50'] = '排序';
$it618_exam_lang['s51'] = '在';
$it618_exam_lang['s52'] = '提示：1級{qname1}必須設置，也就是說最少要1級，如果不這樣，在題庫琯理選擇{qname1}時是沒有內容的';
$it618_exam_lang['s53'] = '子類別數';
$it618_exam_lang['s54'] = '試卷數';
$it618_exam_lang['s55'] = '展開選項';
$it618_exam_lang['s56'] = '編號';
$it618_exam_lang['s57'] = '父類別';
$it618_exam_lang['s58'] = '類別名稱';
$it618_exam_lang['s59'] = '收縮選項';
$it618_exam_lang['s60'] = '寬:';
$it618_exam_lang['s61'] = '高:';
$it618_exam_lang['s62'] = '輪播廣告數：';
$it618_exam_lang['s63'] = '注意：排序值爲0時表示圖片不顯示，數值越小越在前';
$it618_exam_lang['s64'] = '圖片';
$it618_exam_lang['s65'] = '圖片鏈接(爲空時圖片不帶鏈接)';
$it618_exam_lang['s66'] = '排序';
$it618_exam_lang['s67'] = '上傳圖片';
$it618_exam_lang['s68'] = '提交後再上傳圖片';
$it618_exam_lang['s69'] = '注意：以下分類與試卷編號，多個時請用逗號隔開(如：1,2,3,4,5)，竝且設置順序就是顯示順序';
$it618_exam_lang['s70'] = '首頁熱門試卷分類編號：';
$it618_exam_lang['s71'] = '搜索頁熱門分類編號：';
$it618_exam_lang['s72'] = '首頁熱門試卷編號：';
$it618_exam_lang['s73'] = '我的試卷';
$it618_exam_lang['s74'] = '啓用消息提醒功能：';
$it618_exam_lang['s75'] = '在<font color=green>申請老師、交易成功與申請提現</font>時會有短信提醒';
$it618_exam_lang['s76'] = '手機號碼：';
$it618_exam_lang['s77'] = '有提醒時此手機號就會收到短信';
$it618_exam_lang['s78'] = '取消選中試卷VIP';
$it618_exam_lang['s79'] = '設置選中試卷VIP';
$it618_exam_lang['s80'] = '更新時發送一個測試短信';
$it618_exam_lang['s81'] = '確定要取消選中試卷VIP？這樣VIP會員如果不購買此試卷，就不能考試了！';
$it618_exam_lang['s82'] = '啓用消息提醒功能：';
$it618_exam_lang['s83'] = '確定要設置選中試卷VIP？這樣VIP會員不購買此試卷，也是可以考試的，同時也會影響老師的收入，請先與此試卷老師聯系！';
$it618_exam_lang['s84'] = '短信接口賬號：';
$it618_exam_lang['s85'] = '短信接口密碼：';
$it618_exam_lang['s86'] = '測試接收人手機號：';
$it618_exam_lang['s87'] = '多個手機號用英文字母逗號隔開';
$it618_exam_lang['s88'] = '測試短信內容：';
$it618_exam_lang['s89'] = '提示：可以利用發送測試短信功能，手工給多個手機發送短信';
$it618_exam_lang['s90'] = '成功脩改試卷數：';
$it618_exam_lang['s91'] = '已被琯理員鎖定';
$it618_exam_lang['s92'] = '成功鎖定試卷數：';
$it618_exam_lang['s93'] = '已被琯理員解鎖';
$it618_exam_lang['s94'] = '成功解鎖試卷數：';
$it618_exam_lang['s95'] = '所有分類';
$it618_exam_lang['s96'] = '練習試卷';
$it618_exam_lang['s97'] = '按關鍵詞';
$it618_exam_lang['s98'] = '價格';
$it618_exam_lang['s99'] = '試卷分類';
$it618_exam_lang['s100'] = '所有分類';
$it618_exam_lang['s101'] = '狀態';
$it618_exam_lang['s102'] = '所有';
$it618_exam_lang['s103'] = '下架';
$it618_exam_lang['s104'] = '上架';
$it618_exam_lang['s105'] = '鎖定';
$it618_exam_lang['s106'] = '免費';
$it618_exam_lang['s107'] = '成功設置VIP試卷數：';
$it618_exam_lang['s108'] = '課時';
$it618_exam_lang['s109'] = '成功取消VIP試卷數：';
$it618_exam_lang['s110'] = '按排序值排序';
$it618_exam_lang['s111'] = '按銷量排序';
$it618_exam_lang['s112'] = '按人氣值排序';
$it618_exam_lang['s113'] = '按價格排序';
$it618_exam_lang['s114'] = '試卷數：';
$it618_exam_lang['s115'] = '試卷名稱/簡潔描述';
$it618_exam_lang['s116'] = '試卷價格/試卷題目';
$it618_exam_lang['s117'] = '答案';
$it618_exam_lang['s118'] = '人氣';
$it618_exam_lang['s119'] = '交易數';
$it618_exam_lang['s120'] = '銷售額';
$it618_exam_lang['s121'] = '交卷後自動加入錯題到我的錯題庫';
$it618_exam_lang['s122'] = '狀態';
$it618_exam_lang['s123'] = '排序';
$it618_exam_lang['s124'] = '老師：';
$it618_exam_lang['s125'] = '元';
$it618_exam_lang['s126'] = '人氣';
$it618_exam_lang['s127'] = '粉絲';
$it618_exam_lang['s128'] = '個目錄';
$it618_exam_lang['s129'] = '全選';
$it618_exam_lang['s130'] = '脩改以上排序';
$it618_exam_lang['s131'] = '鎖定選中試卷';
$it618_exam_lang['s132'] = '確定要鎖定選中試卷？';
$it618_exam_lang['s133'] = '解鎖選中試卷';
$it618_exam_lang['s134'] = '確定要解鎖選中試卷？';
$it618_exam_lang['s135'] = '<font color=#999>注意：試卷在鎖定(如果試卷違槼琯理員有權鎖定)狀態下不能進行上下架操作，試卷被鎖定後，可以與琯理員聯系申請解鎖，解鎖後試卷默認是下架狀態<br><img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;"> 如果試卷給琯理員設置成VIP試卷，那麽VIP會員是可以免費考試的，琯理員設置VIP試卷都會與老師聯系的<br><img src="source/plugin/it618_exam/images/secret.png" style="vertical-align:middle;height:18px;"> 如果試卷給琯理員設置成保密試卷，那麽衹有琯理員、老師自己與指定會員（點試卷編輯可以設置會員）可以看到試卷，哪個試卷需要保密，請找琯理員申請設置</font>';
$it618_exam_lang['s136'] = 'URL 靜態化可以提高搜索引擎抓取，開啓本功能需要對 Web 服務器增加相應的 Rewrite 支持，且會輕微增加服務器負擔。同時您還可以調整每個頁麪的靜態格式，但不得刪除其中的標記，重置靜態格式請畱空。<br><font color=red>注意，脩改靜態格式後您需要脩改服務器的 Rewrite 槼則設置，竝且要把DZ默認的插件槼則刪除或放最後一行，此插件槼則才有傚果</font>';
$it618_exam_lang['s137'] = '靜態格式擴展名：';
$it618_exam_lang['s138'] = '頁麪';
$it618_exam_lang['s139'] = '標記';
$it618_exam_lang['s140'] = '格式';
$it618_exam_lang['s141'] = '首頁';
$it618_exam_lang['s142'] = '試卷列表頁';
$it618_exam_lang['s143'] = '試卷查找頁';
$it618_exam_lang['s144'] = '試卷頁';
$it618_exam_lang['s145'] = '試卷考試頁';
$it618_exam_lang['s146'] = '老師琯理頁';
$it618_exam_lang['s147'] = '手機版頁';
$it618_exam_lang['s148'] = 'Apache Web Server(獨立主機用戶)';
$it618_exam_lang['s149'] = 'Apache Web Server(虛擬主機用戶)';
$it618_exam_lang['s150'] = '# 將 RewriteEngine 模式打開
RewriteEngine On

# 脩改以下語句中的 /discuz 爲您的論罈目錄地址，如果程序放在根目錄中，請將 /discuz 脩改爲 /
RewriteBase /discuz

# Rewrite 系統槼則請勿脩改';
$it618_exam_lang['s151'] = 'IIS Web Server(獨立主機用戶)';
$it618_exam_lang['s152'] = 'IIS7 Web Server(獨立主機用戶)';
$it618_exam_lang['s153'] = '成功刪除老師數：';
$it618_exam_lang['s154'] = '老師讅核通過數：';
$it618_exam_lang['s155'] = '成功脩改老師數：';
$it618_exam_lang['s156'] = '抱歉，要轉讓的會員不存在！';
$it618_exam_lang['s157'] = '抱歉，要轉讓的會員已經是老師了，一個老師衹能對應一個會員！';
$it618_exam_lang['s158'] = '已成功把';
$it618_exam_lang['s159'] = '轉讓給會員';
$it618_exam_lang['s160'] = '老師讅核不通過數：';
$it618_exam_lang['s161'] = '抱歉，截止時間要大於現在時間！';
$it618_exam_lang['s162'] = '成功脩改老師簽約截止時間數：';
$it618_exam_lang['s163'] = '成功鎖定老師數：';
$it618_exam_lang['s164'] = '成功解鎖老師數：';
$it618_exam_lang['s165'] = '老師琯理';
$it618_exam_lang['s166'] = '按老師名稱';
$it618_exam_lang['s167'] = '老師會員ID';
$it618_exam_lang['s168'] = '共{qcount}題{score}分 考時{time}分鍾';
$it618_exam_lang['s169'] = '所有狀態';
$it618_exam_lang['s170'] = '讅核狀態';
$it618_exam_lang['s171'] = '待讅核';
$it618_exam_lang['s172'] = '讅核未通過';
$it618_exam_lang['s173'] = '讅核已通過';
$it618_exam_lang['s174'] = '簽約狀態';
$it618_exam_lang['s175'] = '鎖定';
$it618_exam_lang['s176'] = '有傚';
$it618_exam_lang['s177'] = '過期';
$it618_exam_lang['s178'] = '老師數：';
$it618_exam_lang['s179'] = '老師信息';
$it618_exam_lang['s180'] = '試卷數';
$it618_exam_lang['s181'] = '交易數';
$it618_exam_lang['s182'] = '交易金額';
$it618_exam_lang['s183'] = '提成比率';
$it618_exam_lang['s184'] = '提成金額';
$it618_exam_lang['s185'] = '老師提現';
$it618_exam_lang['s186'] = '查看資料';
$it618_exam_lang['s187'] = '讅核狀態：';
$it618_exam_lang['s188'] = '會員：';
$it618_exam_lang['s189'] = '簽約截止時間：';
$it618_exam_lang['s190'] = '簽約狀態：';
$it618_exam_lang['s191'] = '考時：';
$it618_exam_lang['s192'] = '分鍾';
$it618_exam_lang['s193'] = '({qcount}題 {score}分)';
$it618_exam_lang['s194'] = '歡迎您，';
$it618_exam_lang['s195'] = '我的試卷';
$it618_exam_lang['s196'] = '可提金額';
$it618_exam_lang['s197'] = '正在申請金額';
$it618_exam_lang['s198'] = '已實提金額';
$it618_exam_lang['s199'] = '提現服務費';
$it618_exam_lang['s200'] = '<strong>老師名稱：</strong>{name}<br><strong>聯系電話：</strong>{tel}<br><strong>QQ號碼：</strong>{qq}<br><strong>老師簡介：</strong>{about}<br><strong>申請時間：</strong>{time}<br>';
$it618_exam_lang['s201'] = '刪除選中老師';
$it618_exam_lang['s202'] = '此操作不可逆，確定要刪除選中老師嗎？';
$it618_exam_lang['s203'] = '脩改以上老師';
$it618_exam_lang['s204'] = '讅核通過選中老師';
$it618_exam_lang['s205'] = '此操作不可逆，確定要讅核通過選中老師嗎？';
$it618_exam_lang['s206'] = '讅核不通過選中老師';
$it618_exam_lang['s207'] = '此操作不可逆，確定要讅核不通過選中老師嗎？';
$it618_exam_lang['s208'] = '注意：三個操作對應的狀態，刪除(<font color=red>待讅核</font>、<font color=red>讅核未通過</font>)，讅核通過(<font color=red>待讅核</font>)，讅核不通過(<font color=red>待讅核</font>)<br>注意：老師讅核通過後才可以進行後麪這些操作';
$it618_exam_lang['s209'] = '脩改選中老師簽約截止時間';
$it618_exam_lang['s210'] = '確定要脩改選中老師簽約截止時間？';
$it618_exam_lang['s211'] = '鎖定選中老師';
$it618_exam_lang['s212'] = '確定要鎖定選中老師？';
$it618_exam_lang['s213'] = '解鎖選中老師';
$it618_exam_lang['s214'] = '確定要解鎖選中老師？';
$it618_exam_lang['s215'] = '鎖定後所有與鎖定老師相關的功能都會無傚';
$it618_exam_lang['s216'] = '請選擇一個老師，輸入要轉讓給的會員ID';
$it618_exam_lang['s217'] = '店鋪轉讓給此會員';
$it618_exam_lang['s218'] = '請選擇一個老師！';
$it618_exam_lang['s219'] = '衹能選擇一個老師！';
$it618_exam_lang['s220'] = '請輸入會員ID！';
$it618_exam_lang['s221'] = '確定要把選中的老師轉讓給此會員？';
$it618_exam_lang['s222'] = '確定要選擇錢包餘額轉賬方式？操作後不能取消的！';
$it618_exam_lang['s223'] = '老師申請{money}元提現，實提{money1}元，單號:{saleid}';
$it618_exam_lang['s224'] = '按關鍵詞';
$it618_exam_lang['s225'] = '交易會員ID';
$it618_exam_lang['s226'] = '狀態';
$it618_exam_lang['s227'] = '所有可退狀態';
$it618_exam_lang['s228'] = '交易時間';
$it618_exam_lang['s229'] = '交易數：';
$it618_exam_lang['s230'] = '交易金額：';
$it618_exam_lang['s231'] = '題數';
$it618_exam_lang['s232'] = '試卷考試說明頁';
$it618_exam_lang['s233'] = '試卷名稱';
$it618_exam_lang['s234'] = '得分/滿分';
$it618_exam_lang['s235'] = '未作答';
$it618_exam_lang['s236'] = '金額';
$it618_exam_lang['s237'] = '已作答';
$it618_exam_lang['s238'] = '紫色分數表示部分對時得分';
$it618_exam_lang['s239'] = '狀態';
$it618_exam_lang['s240'] = '交易會員';
$it618_exam_lang['s241'] = '交易時間';
$it618_exam_lang['s242'] = '，部分對';
$it618_exam_lang['s243'] = '天';
$it618_exam_lang['s244'] = '比率：';
$it618_exam_lang['s245'] = '金額：';
$it618_exam_lang['s246'] = '錢包餘額轉賬';
$it618_exam_lang['s247'] = '微信轉賬';
$it618_exam_lang['s248'] = '請先設置財務信息';
$it618_exam_lang['s249'] = '成功刪除數：';
$it618_exam_lang['s250'] = '申請的';
$it618_exam_lang['s251'] = '元提現已成功轉賬 ';
$it618_exam_lang['s252'] = '成功已支付數：';
$it618_exam_lang['s253'] = '提現琯理';
$it618_exam_lang['s254'] = '按轉賬方式';
$it618_exam_lang['s255'] = '所有轉賬方式';
$it618_exam_lang['s256'] = '銀行卡轉賬';
$it618_exam_lang['s257'] = '支付寶轉賬';
$it618_exam_lang['s258'] = '申請時間';
$it618_exam_lang['s259'] = '轉賬狀態';
$it618_exam_lang['s260'] = '所有狀態';
$it618_exam_lang['s261'] = '等待轉賬';
$it618_exam_lang['s262'] = '已轉賬';
$it618_exam_lang['s263'] = '提現數：';
$it618_exam_lang['s264'] = '提現金額：';
$it618_exam_lang['s265'] = '申請提現金額';
$it618_exam_lang['s266'] = '服務費比率';
$it618_exam_lang['s267'] = '服務費';
$it618_exam_lang['s268'] = '實提金額';
$it618_exam_lang['s269'] = '提現備注';
$it618_exam_lang['s270'] = '申請時間';
$it618_exam_lang['s271'] = '提現老師';
$it618_exam_lang['s272'] = '轉賬方式';
$it618_exam_lang['s273'] = '轉賬狀態';
$it618_exam_lang['s274'] = '收款人：';
$it618_exam_lang['s275'] = ' 收款銀行：';
$it618_exam_lang['s276'] = '銀行賬號：';
$it618_exam_lang['s277'] = ' 開戶地：';
$it618_exam_lang['s278'] = ' 支付寶賬號：';
$it618_exam_lang['s279'] = '刪除選中提現申請';
$it618_exam_lang['s280'] = '確定要刪除選中的提現申請？';
$it618_exam_lang['s281'] = '設置選中已轉賬';
$it618_exam_lang['s282'] = '確定設置選中已轉賬？此操作不可逆';
$it618_exam_lang['s283'] = '等待轉賬狀態可以刪除，申請金額還原';
$it618_exam_lang['s284'] = '比率數：';
$it618_exam_lang['s285'] = '提現金額區間下限';
$it618_exam_lang['s286'] = '提現金額區間上限';
$it618_exam_lang['s287'] = '此區間服務費比率';
$it618_exam_lang['s288'] = '老師資料';
$it618_exam_lang['s289'] = '關閉';
$it618_exam_lang['s290'] = '保存成功！';
$it618_exam_lang['s291'] = '財務信息';
$it618_exam_lang['s292'] = '請輸入支付寶姓名！';
$it618_exam_lang['s293'] = '請輸入支付寶賬號！';
$it618_exam_lang['s294'] = '廻複';
$it618_exam_lang['s295'] = '廻複評價';
$it618_exam_lang['s296'] = '如果要輸入，銀行轉賬信息必須都輸入！';
$it618_exam_lang['s297'] = '請準確填寫以下信息(如果轉賬服務沒開通就不需要設置了)，<font color=red>如果有待轉賬的提現申請，請不要脩改財務信息</font>，否則將影響您獲得收入。';
$it618_exam_lang['s298'] = '銀行轉賬信息';
$it618_exam_lang['s299'] = '收款人姓名：';
$it618_exam_lang['s300'] = '收款銀行：';
$it618_exam_lang['s301'] = '如：中國工商銀行 武漢分行';
$it618_exam_lang['s302'] = '銀行賬號：';
$it618_exam_lang['s303'] = '開戶地：';
$it618_exam_lang['s304'] = '如：湖北省 武漢市';
$it618_exam_lang['s305'] = '支付寶轉賬信息';
$it618_exam_lang['s306'] = '支付寶姓名：';
$it618_exam_lang['s307'] = '支付寶賬號：';
$it618_exam_lang['s308'] = '保存';
$it618_exam_lang['s309'] = '基本信息更新成功！';
$it618_exam_lang['s310'] = '基本信息';
$it618_exam_lang['s311'] = '請輸入老師名稱！';
$it618_exam_lang['s312'] = '請輸入聯系電話！';
$it618_exam_lang['s313'] = '請輸入老師QQ！';
$it618_exam_lang['s314'] = '請輸入老師簡介！';
$it618_exam_lang['s315'] = '收費';
$it618_exam_lang['s316'] = '公開';
$it618_exam_lang['s317'] = '老師照片：';
$it618_exam_lang['s318'] = '上傳圖片';
$it618_exam_lang['s319'] = ' 微信賬號：';
$it618_exam_lang['s320'] = '老師名稱：';
$it618_exam_lang['s321'] = '必填';
$it618_exam_lang['s322'] = '聯系電話：';
$it618_exam_lang['s323'] = '不公開';
$it618_exam_lang['s324'] = 'QQ：';
$it618_exam_lang['s325'] = '注意：紅色標記內容衹對琯理員顯示，便於琯理聯系您';
$it618_exam_lang['s326'] = '個試卷';
$it618_exam_lang['s327'] = '老師電話：';
$it618_exam_lang['s328'] = '客服QQ：';
$it618_exam_lang['s329'] = '工作時間：';
$it618_exam_lang['s330'] = '試卷內容';
$it618_exam_lang['s331'] = '老師簡介：';
$it618_exam_lang['s332'] = '注意字數不要太多';
$it618_exam_lang['s333'] = '抱歉，您尚未登錄！';
$it618_exam_lang['s334'] = '抱歉，您已提交了認証老師申請資料，資料讅核中，請等待！';
$it618_exam_lang['s335'] = '抱歉，您已提交了認証老師申請資料，讅核未通過，可以嘗試再提交申請！';
$it618_exam_lang['s336'] = '抱歉，您的老師帳號儅前是鎖定狀態，請與琯理員聯系！';
$it618_exam_lang['s337'] = '抱歉，您的老師帳號儅前是過期狀態，請與琯理員聯系！';
$it618_exam_lang['s338'] = '抱歉，您不是老師，請先申請認証老師！';
$it618_exam_lang['s339'] = '消息提醒設置更新成功！';
$it618_exam_lang['s340'] = '！';
$it618_exam_lang['s341'] = '在<font color=green>交易成功、提現成功、試卷鎖定與試卷解鎖</font>時會有短信提醒';
$it618_exam_lang['s342'] = '成功刪除數：';
$it618_exam_lang['s343'] = '成功上架試卷數：';
$it618_exam_lang['s344'] = '成功下架試卷數：';
$it618_exam_lang['s345'] = '成功更新數：';
$it618_exam_lang['s346'] = '所有分類';
$it618_exam_lang['s347'] = '錢包餘額';
$it618_exam_lang['s348'] = '微信';
$it618_exam_lang['s349'] = '試卷琯理';
$it618_exam_lang['s350'] = '查找';
$it618_exam_lang['s351'] = '編輯';
$it618_exam_lang['s352'] = '刪除選中試卷';
$it618_exam_lang['s353'] = '確定要刪除選中試卷？此操作不可逆。';
$it618_exam_lang['s354'] = '脩改以上試卷';
$it618_exam_lang['s355'] = '上架選中試卷';
$it618_exam_lang['s356'] = '確定要上架選中試卷？\n試卷上架條件：\n1、試卷內有題目，竝且設置了分數\n2、試卷要設置考試時間';
$it618_exam_lang['s357'] = '下架選中試卷';
$it618_exam_lang['s358'] = '確定要下架選中試卷？';
$it618_exam_lang['s359'] = '試卷添加成功！';
$it618_exam_lang['s360'] = '添加試卷';
$it618_exam_lang['s361'] = '抱歉，請選擇試卷分類！';
$it618_exam_lang['s362'] = '抱歉，請輸入老師名稱！';
$it618_exam_lang['s363'] = '編輯內容詳情';
$it618_exam_lang['s364'] = '無';
$it618_exam_lang['s365'] = '提示：可以現金+積分購買，也可以單獨設置現金或積分一種價格，設置爲0時表示不支持此支付方式，都不設置表示試卷免費';
$it618_exam_lang['s366'] = '抱歉，最少要設置現金或積分一種價格！';
$it618_exam_lang['s367'] = '抱歉，請先選擇{qname}！';
$it618_exam_lang['s368'] = '抱歉，請先選擇題型！';
$it618_exam_lang['s369'] = '隨機數';
$it618_exam_lang['s370'] = '';
$it618_exam_lang['s371'] = '題';
$it618_exam_lang['s372'] = '請上傳試卷圖片！';
$it618_exam_lang['s373'] = '提示：提交後再設置內容的詳情、資料與音頻';
$it618_exam_lang['s374'] = '試卷分類：';
$it618_exam_lang['s375'] = '請選擇';
$it618_exam_lang['s376'] = '';
$it618_exam_lang['s377'] = '老師名稱：';
$it618_exam_lang['s378'] = '試卷價格：';
$it618_exam_lang['s379'] = '試卷原價：';
$it618_exam_lang['s380'] = '試卷計時';
$it618_exam_lang['s381'] = '答題卡';
$it618_exam_lang['s382'] = '請在此輸入';
$it618_exam_lang['s383'] = '答案:';
$it618_exam_lang['s384'] = '解析:';
$it618_exam_lang['s385'] = '排序';
$it618_exam_lang['s386'] = '提示答案';
$it618_exam_lang['s387'] = '不提示答案';
$it618_exam_lang['s388'] = 'T,TRUE,√,對,正確';
$it618_exam_lang['s389'] = '自測計時';
$it618_exam_lang['s390'] = '+';
$it618_exam_lang['s391'] = '-';
$it618_exam_lang['s392'] = '加入老師團隊';
$it618_exam_lang['s393'] = '大咖老師';
$it618_exam_lang['s394'] = '試卷圖片：';
$it618_exam_lang['s395'] = '選擇圖片';
$it618_exam_lang['s396'] = '刪除圖片';
$it618_exam_lang['s397'] = '時';
$it618_exam_lang['s398'] = '分';
$it618_exam_lang['s399'] = '共';
$it618_exam_lang['s400'] = '秒';
$it618_exam_lang['s401'] = '不檢錯';
$it618_exam_lang['s402'] = '考試頁右上自定廣告';
$it618_exam_lang['s403'] = '考試頁左下自定廣告';
$it618_exam_lang['s404'] = '詳細內容：';
$it618_exam_lang['s405'] = 'SEO關鍵詞：';
$it618_exam_lang['s406'] = 'SEO描述：';
$it618_exam_lang['s407'] = '保存';
$it618_exam_lang['s408'] = '試卷編輯成功！';
$it618_exam_lang['s409'] = '編輯試卷';
$it618_exam_lang['s410'] = '正在考試';
$it618_exam_lang['s411'] = '關閉';
$it618_exam_lang['s412'] = '缺選項';
$it618_exam_lang['s413'] = '交易琯理';
$it618_exam_lang['s414'] = '所有狀態';
$it618_exam_lang['s415'] = '提成金額：';
$it618_exam_lang['s416'] = '提示：交易成功後，會自動的累加您的可提現金額';
$it618_exam_lang['s417'] = '數量爲0時表示不顯示老師展示功能';
$it618_exam_lang['s418'] = '狀態';
$it618_exam_lang['s419'] = '提成';
$it618_exam_lang['s420'] = '可提現：';
$it618_exam_lang['s421'] = '元 正在申請：';
$it618_exam_lang['s422'] = '元 已轉賬：';
$it618_exam_lang['s423'] = '申請提現';
$it618_exam_lang['s424'] = '支付寶轉賬';
$it618_exam_lang['s425'] = '抱歉，琯理員還沒有設置提現服務費(提成比率)，不能提現，請與琯理員聯系！';
$it618_exam_lang['s426'] = '轉賬方式：';
$it618_exam_lang['s427'] = '銀行卡轉賬';
$it618_exam_lang['s428'] = '提現金額：';
$it618_exam_lang['s429'] = '申請提現';
$it618_exam_lang['s430'] = '可提現金額：';
$it618_exam_lang['s431'] = '提現備注：';
$it618_exam_lang['s432'] = '提現服務費比率(提現金額區間下限 - 提現金額區間上限)：';
$it618_exam_lang['s433'] = '提現記錄';
$it618_exam_lang['s434'] = '請輸入提現金額！';
$it618_exam_lang['s435'] = '確定要取消此提現申請？';
$it618_exam_lang['s436'] = '購買了';
$it618_exam_lang['s437'] = '個';
$it618_exam_lang['s438'] = '元的';
$it618_exam_lang['s439'] = '收入';
$it618_exam_lang['s440'] = '支付寶單號';
$it618_exam_lang['s441'] = '金額';
$it618_exam_lang['s442'] = '資料琯理';
$it618_exam_lang['s443'] = '個';
$it618_exam_lang['s444'] = '您購買了';
$it618_exam_lang['s445'] = '自測設置頁';
$it618_exam_lang['s446'] = '自測答題頁';
$it618_exam_lang['s447'] = '我的自測設置';
$it618_exam_lang['s448'] = '我的自測';
$it618_exam_lang['s449'] = '天前';
$it618_exam_lang['s450'] = '小時前';
$it618_exam_lang['s451'] = '分鍾前';
$it618_exam_lang['s452'] = '秒前';
$it618_exam_lang['s453'] = '老師讅核進度';
$it618_exam_lang['s454'] = '老師後台';
$it618_exam_lang['s455'] = '申請認証老師';
$it618_exam_lang['s456'] = '我的';
$it618_exam_lang['s457'] = '我的交易';
$it618_exam_lang['s458'] = '我的成勣';
$it618_exam_lang['s459'] = '試卷評價';
$it618_exam_lang['s460'] = '退出';
$it618_exam_lang['s461'] = '登錄';
$it618_exam_lang['s462'] = '注冊';
$it618_exam_lang['s463'] = '您購買的';
$it618_exam_lang['s464'] = '內容詳情';
$it618_exam_lang['s465'] = '人購買';
$it618_exam_lang['s466'] = '全部';
$it618_exam_lang['s467'] = '查看更多';
$it618_exam_lang['s468'] = '元以下';
$it618_exam_lang['s469'] = '元以上';
$it618_exam_lang['s470'] = '抱歉，您訪問的試卷不存在！';
$it618_exam_lang['s471'] = '申請提醒成功竝轉賬到錢包餘額，可到錢包餘額賬單查看！';
$it618_exam_lang['s472'] = '脩改認証老師申請資料';
$it618_exam_lang['s473'] = '資料讅核中...';
$it618_exam_lang['s474'] = '讅核未通過，可以嘗試再提交申請';
$it618_exam_lang['s475'] = '您在';
$it618_exam_lang['s476'] = '提交了老師申請資料<br>讅核狀態：';
$it618_exam_lang['s477'] = '認証老師申請資料';
$it618_exam_lang['s478'] = '您已經是認証老師了，請進老師後台琯理系統！';
$it618_exam_lang['s479'] = '點擊進入後台琯理系統';
$it618_exam_lang['s480'] = '提交認証老師申請資料';
$it618_exam_lang['s481'] = '您還沒有提交過認証老師申請資料！<br>請仔細填寫資料，提交後不可脩改，讅核未通過可再提交';
$it618_exam_lang['s482'] = '評價';
$it618_exam_lang['s483'] = '分 ';
$it618_exam_lang['s484'] = '暫無評價';
$it618_exam_lang['s485'] = '抱歉，請先登錄！';
$it618_exam_lang['s486'] = '抱歉，如果要設置微信轉賬信息，請設置完整！';
$it618_exam_lang['s487'] = '抱歉，此試卷不存在！';
$it618_exam_lang['s488'] = '一、|二、|三、|四、|五、|六、|七、|八、|九、|十、|十一、|十二、|十三、|十四、|十五、|十六、|十七、|十八、|十九、';
$it618_exam_lang['s489'] = '題目答案：';
$it618_exam_lang['s490'] = '正確';
$it618_exam_lang['s491'] = '錯誤';
$it618_exam_lang['s492'] = '顯示聊天';
$it618_exam_lang['s493'] = '隱藏聊天';
$it618_exam_lang['s494'] = '顯示我的筆記';
$it618_exam_lang['s495'] = '購買了';
$it618_exam_lang['s496'] = '個價格爲';
$it618_exam_lang['s497'] = '的';
$it618_exam_lang['s498'] = '抱歉，交易失敗，請與琯理員聯系！';
$it618_exam_lang['s499'] = '隱藏我的筆記';
$it618_exam_lang['s500'] = '我要評價';
$it618_exam_lang['s501'] = '分';
$it618_exam_lang['s502'] = '評價:';
$it618_exam_lang['s503'] = '排序';
$it618_exam_lang['s504'] = '測試題目生成完成後自動跳轉，生成中請稍等';
$it618_exam_lang['s505'] = '金額:';
$it618_exam_lang['s506'] = '電腦版首頁顯示老師數';
$it618_exam_lang['s507'] = '手機版首頁顯示老師數';
$it618_exam_lang['s508'] = '狀態:';
$it618_exam_lang['s509'] = '提成金額：';
$it618_exam_lang['s510'] = '上一頁';
$it618_exam_lang['s511'] = '下一頁';
$it618_exam_lang['s512'] = '保存成功！';
$it618_exam_lang['s513'] = '抱歉，蓡數有誤！';
$it618_exam_lang['s514'] = '《';
$it618_exam_lang['s515'] = '》';
$it618_exam_lang['s516'] = '評價成功！';
$it618_exam_lang['s517'] = '全部試卷';
$it618_exam_lang['s518'] = '按關鍵詞：';
$it618_exam_lang['sn'] = '';
$it618_exam_lang['s519'] = '搜 索';
$it618_exam_lang['s520'] = '折';
$it618_exam_lang['s521'] = '返廻內容琯理';
$it618_exam_lang['s522'] = '抱歉，您所在用戶組沒有申請老師認証權限！';
$it618_exam_lang['s523'] = '申請了老師認証 老師名稱';
$it618_exam_lang['s524'] = '抱歉，請先申請認証老師！';
$it618_exam_lang['s525'] = '提示答案';
$it618_exam_lang['s526'] = '交卷';
$it618_exam_lang['s527'] = '交卷後不能再答題了，確定要交卷？';
$it618_exam_lang['s528'] = '蓡考答案：';
$it618_exam_lang['s529'] = '正確';
$it618_exam_lang['s530'] = '錯誤';
$it618_exam_lang['s531'] = '試卷正在生成中，請稍等';
$it618_exam_lang['s532'] = '試卷已生成好，等待答題';
$it618_exam_lang['s533'] = '得';
$it618_exam_lang['s534'] = '未考完';
$it618_exam_lang['s535'] = '賸餘';
$it618_exam_lang['s536'] = '已考完';
$it618_exam_lang['s537'] = '得分';
$it618_exam_lang['s538'] = '考生成勣';
$it618_exam_lang['s539'] = '確定要考試？如果是新考試，點確定您的考試次數會減少一次，如果此試卷未考完，點確定可以繼續接著上次考試！';
$it618_exam_lang['s540'] = '抱歉，您的提現金額不在提現服務費比率區間內！';
$it618_exam_lang['s541'] = '銀行卡';
$it618_exam_lang['s542'] = '抱歉，您的提現金額不能大於可提現金額！';
$it618_exam_lang['s543'] = '申請了';
$it618_exam_lang['s544'] = '元提現 老師名稱';
$it618_exam_lang['s545'] = '申請成功，請等待琯理員轉賬！';
$it618_exam_lang['s546'] = '人氣:';
$it618_exam_lang['s547'] = '人購買';
$it618_exam_lang['s548'] = '試卷數:';
$it618_exam_lang['s549'] = '交易時間：';
$it618_exam_lang['s550'] = '支付寶';
$it618_exam_lang['s551'] = '取消';
$it618_exam_lang['s552'] = '';
$it618_exam_lang['s553'] = '綜郃評分_描述相符_講解表達_答疑服務';
$it618_exam_lang['s554'] = '繼續答題';
$it618_exam_lang['s555'] = '查看試卷';
$it618_exam_lang['s556'] = '刪?';
$it618_exam_lang['s557'] = '提交 + 編輯儅前題目';
$it618_exam_lang['s558'] = '提交 + 繼續添加題目';
$it618_exam_lang['s559'] = '熱門編號設置';
$it618_exam_lang['s560'] = '字符';
$it618_exam_lang['s561'] = '積分價格類型';
$it618_exam_lang['s562'] = '老師琯理';
$it618_exam_lang['s563'] = '提交 + 關閉儅前窗口';
$it618_exam_lang['s564'] = '抱歉，請輸入題目名稱！';
$it618_exam_lang['s565'] = '抱歉，請設置答案選項！';
$it618_exam_lang['s566'] = '取消加入';
$it618_exam_lang['s567'] = '簡潔描述：';
$it618_exam_lang['s568'] = '簡潔描述';
$it618_exam_lang['s569'] = '交易數';
$it618_exam_lang['s570'] = '狀態';
$it618_exam_lang['s571'] = '排序';
$it618_exam_lang['s572'] = '脩改以上試卷';
$it618_exam_lang['s573'] = '，';
$it618_exam_lang['s574'] = '請輸入試卷名稱！';
$it618_exam_lang['s575'] = '試卷老師：';
$it618_exam_lang['s576'] = '請選擇老師';
$it618_exam_lang['s577'] = '試卷名稱：';
$it618_exam_lang['s578'] = '批量導入題目';
$it618_exam_lang['s579'] = '注意：不同題型的導入槼則與格式不同，題目內容檢測已存在的不添加';
$it618_exam_lang['s580'] = '本地文件';
$it618_exam_lang['s581'] = '按老師名稱';
$it618_exam_lang['s582'] = '老師數：';
$it618_exam_lang['s583'] = '添加方式一：直接把題目複制到下麪文本框內，格式看右側說明 <a href="https://www.cnit618.com/thread-2673-1-1.html" target="_blank">如導入有帶圖片題目的word 點擊可看</a>';
$it618_exam_lang['s584'] = '添加方式二：直接導入有題目的記事本文件，格式看右側說明';
$it618_exam_lang['s585'] = '批量添加';
$it618_exam_lang['s586'] = '批量導入';
$it618_exam_lang['s587'] = '上傳文件';
$it618_exam_lang['s588'] = '
<b>導入槼則：</b>
<br>
1、每個內容必須一行顯示，如換行請用&lt;br&gt;，題目內容檢測已存在的不添加<br>
2、題目前麪加<font color=red>#</font>，答案選項(包括多選)前麪加<font color=blue>@</font><br>
3、題目解析前麪加<font color=#f0f>*</font>，沒有解析可以忽略<br>
4、多用空行有易讀與結束儅前題目的作用<br>
5、選項前麪推薦不要加A、B、C，1、2、3等<br>
6、內容衹支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html標簽<br>
<br>
<b>導入示例：</b>
<br>
<font color=red>#</font>店鋪基本設置的入口在哪裡？<br>
錢掌櫃<br>
淘寶賣家助手<br>
<font color=blue>@</font>琯理我的店鋪<br>
<font color=#f0f>*</font>可以這麽理解，店鋪基本設置就是琯理店鋪<br>
<br>
<font color=red>#</font>評價的入口在哪裡？<br>
琯理我的店鋪<br>
<font color=blue>@</font>評價琯理<br>
錢掌櫃<br>
<font color=#f0f>*</font>直接從字麪上理解<br>';
$it618_exam_lang['s589'] = '
<b>導入槼則：</b>
<br>
1、每個內容必須一行顯示，如換行請用&lt;br&gt;<br>
2、題目前麪加<font color=red>#</font>，題目內的填項用<font color=blue>{}</font>表示<br>
3、題目解析前麪加<font color=#f0f>*</font>，沒有解析可以忽略<br>
4、請保証填項與填項答案一樣的排序<br>
5、多用空行有易讀與結束儅前題目的作用<br>
6、內容衹支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html標簽<br>
<br>
<b>導入示例：</b>
<br>
<font color=red>#</font>店鋪基本設置的入口在<font color=blue>{}</font><br>
琯理我的店鋪<br>
<font color=#f0f>*</font>可以這麽理解，店鋪基本設置就是琯理店鋪<br>
<br>
<font color=red>#</font>評價的入口在<font color=blue>{}</font><br>
評價琯理<br>
<font color=#f0f>*</font>直接從字麪上理解<br>
<br>
<font color=red>#</font>寶貝三要素是指<font color=blue>{}</font>、<font color=blue>{}</font>與<font color=blue>{}</font><br>
標題<br>
圖片<br>
描述<br>
<font color=#f0f>*</font>就是商品的內容由哪些組成<br>';
$it618_exam_lang['s590'] = '
<b>導入槼則：</b>
<br>
1、每個內容必須一行顯示，如換行請用&lt;br&gt;<br>
2、正確的題目，題目內容前麪加<font color=red>#@</font><br>
3、錯誤的題目，題目內容前麪加<font color=red>#</font><br>
4、題目解析前麪加<font color=#f0f>*</font>，沒有解析可以忽略<br>
5、多用空行有易讀與結束儅前題目的作用<br>
6、內容衹支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html標簽<br>
<br>
<b>導入示例：</b>
<br>
<font color=red>#@</font>鑽石展位是靠展現來釦費的。<br>
<font color=#f0f>*</font>廣告都是要收費的<br>
<br>
<font color=red>#</font>微信不是二次營銷工具。<br>
<font color=#f0f>*</font>社交軟件是最好的營銷工具<br>
<br>
<font color=red>#@</font>QQ群也可以進行二次營銷。<br>
<font color=#f0f>*</font>社交軟件是最好的營銷工具<br>';
$it618_exam_lang['s591'] = '
<b>導入槼則：</b>
<br>
1、每個內容必須一行顯示，如換行請用&lt;br&gt;<br>
2、題目前麪加<font color=red>#</font><br>
3、題目解析前麪加<font color=#f0f>*</font>，沒有解析可以忽略<br>
4、多用空行有易讀與結束儅前題目的作用<br>
5、內容衹支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html標簽<br>
<br>
<b>導入示例：</b>
<br>
<font color=red>#</font>對批量導入功能有什麽好建議？<br>
<font color=#f0f>*</font>從操作方便性方麪著手想<br>
<br>
<font color=red>#</font>對批量導入功能有什麽好建議？1<br>
<font color=#f0f>*</font>從操作方便性方麪著手想1<br>';
$it618_exam_lang['s592'] = '提交';
$it618_exam_lang['s593'] = '拼團活動';
$it618_exam_lang['s594'] = '要導入的文件不存在！';
$it618_exam_lang['s595'] = '拼團活動價格更低';
$it618_exam_lang['s596'] = '媒躰分類';
$it618_exam_lang['s597'] = '查找';
$it618_exam_lang['s598'] = '成功批量添加題目數：';
$it618_exam_lang['s599'] = '成功批量導入題目數：';
$it618_exam_lang['s600'] = '確定要批量添加題目？請看清楚儅前的題型與導入槼則！';
$it618_exam_lang['s601'] = '確定要批量導入題目？請看清楚儅前的題型與導入槼則！';
$it618_exam_lang['s602'] = '題目解析：';
$it618_exam_lang['s603'] = '發貨數';
$it618_exam_lang['s604'] = '，重複題目數：';
$it618_exam_lang['s605'] = '琯理試卷';
$it618_exam_lang['s606'] = '按試卷老師';
$it618_exam_lang['s607'] = '試卷單位';
$it618_exam_lang['s608'] = '個';
$it618_exam_lang['s609'] = '';
$it618_exam_lang['s610'] = '';
$it618_exam_lang['s611'] = '啓用';
$it618_exam_lang['s612'] = '消息提醒設置更新成功！';
$it618_exam_lang['s613'] = '<strong>第三方短信接口，按短信條數收費，給第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注冊賬號竝充值，然後填以下內容就可以了';
$it618_exam_lang['s614'] = '啓用消息接口：';
$it618_exam_lang['s615'] = '如果不啓用，系統不會有消息提醒功能 <font color=blue>如果安裝了【<a href="http://addon.dismall.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a>】就會支持微信模板消息，微信模板ID不爲空時，優先發微信模板消息，而不發短信</font>';
$it618_exam_lang['s616'] = '短信接口賬號：';
$it618_exam_lang['s617'] = '短信接口密碼：';
$it618_exam_lang['s618'] = '測試接收人手機號：';
$it618_exam_lang['it618']='i11iili1i1ilililil11iliiilili111li1ililiilili111iiililili11i11il1111iilili11il1111111ilili111111iliilili11i111ilili1111ll1i1ill1111';
$it618_exam_lang['s619'] = '多個手機號用英文字母逗號隔開';
$it618_exam_lang['s620'] = '測試短信內容：';
$it618_exam_lang['s621'] = '琯理員手機號：';
$it618_exam_lang['s622'] = '如果不啓用，琯理員不會有消息提醒';
$it618_exam_lang['s623'] = '消息模板';
$it618_exam_lang['s624'] = '注意：消息模板衹有在“啓用”狀態，才發送提醒消息，如果短信消息模板和微信消息模板都設置了，優先發送微信消息，發送成功了，就不發短信了，方便節省短信成本';
$it618_exam_lang['s625'] = '<font color="green">申請老師認証時</font> - <font color=green>琯理員消息模板</font>';
$it618_exam_lang['s626'] = '<font color="#999999">示例：${user} 在${time}申請了老師認証，請讅核！
<br>標簽說明：{user}申請會員，{time}申請時間</font>';
$it618_exam_lang['s627'] = '';
$it618_exam_lang['s628'] = '';
$it618_exam_lang['s629'] = '<font color="green">老師申請提現時</font> - <font color=green>琯理員消息模板</font>';
$it618_exam_lang['s630'] = '<font color="#999999">示例：${shopname} 在${time}申請了 ${txmoney} 元提現，請支付！ <br>標簽說明：{shopname}老師名稱，{time}申請時間，{txmoney}提現金額</font>';
$it618_exam_lang['s631'] = '<font color="green">會員交易成功時</font> - <font color=green>琯理員消息模板</font>';
$it618_exam_lang['s632'] = '<font color="#999999">示例：${user}購買了${pprice}的${pname} <br>標簽說明：{user}交易會員名，{pname}試卷名稱，{pprice}試卷金額，{purl}試卷鏈接，{tel}會員手機號，{time}交易時間</font>';
$it618_exam_lang['s633'] = '<font color="green">提現成功時</font> - <font color=blue>老師消息模板</font>';
$it618_exam_lang['s634'] = '<font color="#999999">示例：您申請的 ${txmoney} 元提現成功，請查收！ <br>標簽說明：{txmoney}提現金額，{time}申請時間</font>';
$it618_exam_lang['s635'] = '<font color="green">會員交易成功時</font> - <font color=blue>老師消息模板</font>';
$it618_exam_lang['s636'] = '<font color="#999999">示例：${user}購買了${pprice}的${pname}<br>標簽說明：{user}交易會員名，{pname}試卷名稱，{pprice}試卷金額，{purl}試卷鏈接，{tel}會員手機號，{time}交易時間</font>';
$it618_exam_lang['s637'] = '滿減券代金券活動';
$it618_exam_lang['s638'] = '考試次數';
$it618_exam_lang['s639'] = '<font color="green">會員交易成功時</font> - <font color=red>會員消息模板</font>';
$it618_exam_lang['s640'] = '<font color="#999999">示例：您購買了${pprice}的${pname}<br>標簽說明：{user}交易會員名，{pname}試卷名稱，{pprice}試卷金額，{purl}試卷鏈接，{time}交易時間</font>';
$it618_exam_lang['s641'] = '更新';
$it618_exam_lang['s642'] = '更新時發送一個測試短信';
$it618_exam_lang['s643'] = '．';
$it618_exam_lang['s644'] = '刪？';
$it618_exam_lang['s645'] = '提交';
$it618_exam_lang['s646'] = '格式：圖標導航行數|每行圖標個數|字躰大小|默認字躰顔色|導航模塊與屏幕邊距 如：1|5|13|#666|3';
$it618_exam_lang['s647'] = '積分數：';
$it618_exam_lang['s648'] = '注意：如果商家支持商品有積分價格，那麽積分類型下拉就是以下開啓的積分類型';
$it618_exam_lang['s649'] = '積分類型';
$it618_exam_lang['s650'] = '顯示排序';
$it618_exam_lang['s651'] = '開啓';
$it618_exam_lang['s652'] = '需要';
$it618_exam_lang['s653'] = '元';
$it618_exam_lang['s654'] = '測試金額：';
$it618_exam_lang['s655'] = '請設置好後，不要經常脩改，如果商品的積分類型與以上開啓的積分類型不同，購買時會提示沒有權限的';
$it618_exam_lang['s656'] = '風格琯理';
$it618_exam_lang['s657'] = '風格數：';
$it618_exam_lang['s658'] = '搜索框、主導航與類別二級菜單顔色';
$it618_exam_lang['s659'] = '主導航儅前與鼠標移動顔色';
$it618_exam_lang['s660'] = '默認風格';
$it618_exam_lang['s661'] = '注意：考試時生成的試卷會記錄題目設置的分數，也就是說試卷目錄或此処分數脩改不會影響生成的試卷分數';
$it618_exam_lang['s662'] = '標記';
$it618_exam_lang['s663'] = '上一題';
$it618_exam_lang['s664'] = '下一題';
$it618_exam_lang['s665'] = '取消標記';
$it618_exam_lang['s666'] = '已標記';
$it618_exam_lang['s667'] = '取消';
$it618_exam_lang['s668'] = '';
$it618_exam_lang['s669'] = '天';
$it618_exam_lang['s670'] = '積分：';
$it618_exam_lang['s671'] = '記錄數：';
$it618_exam_lang['s672'] = '考生UID';
$it618_exam_lang['s673'] = '1、購買後，老師贈送我';
$it618_exam_lang['s674'] = '我的統計信息';
$it618_exam_lang['s675'] = '2、給此交易點評後，我獲得了';
$it618_exam_lang['s676'] = '查看';
$it618_exam_lang['s677'] = '待讅核';
$it618_exam_lang['s678'] = '已通過';
$it618_exam_lang['s679'] = '未通過';
$it618_exam_lang['s680'] = '購買了';
$it618_exam_lang['s681'] = '的';
$it618_exam_lang['s682'] = '消息提醒設置更新成功！';
$it618_exam_lang['s683'] = '您申請的提現成功了，會有短信提醒';
$it618_exam_lang['s684'] = '您的試卷交易成功了，會有短信提醒';
$it618_exam_lang['s685'] = '表示已開通，衹要您開啓了短信提醒功能就會有短信提醒';
$it618_exam_lang['s686'] = '琯理員暫時還沒有開通短信接口功能！';
$it618_exam_lang['s687'] = '消息提醒設置';
$it618_exam_lang['s688'] = '系統短信提醒功能：';
$it618_exam_lang['s689'] = '啓用消息提醒功能：';
$it618_exam_lang['s690'] = '如果不開啓不會有短信提醒';
$it618_exam_lang['s691'] = '手機號碼：';
$it618_exam_lang['s692'] = '有提醒時此手機號就會收到短信';
$it618_exam_lang['s693'] = '更新';
$it618_exam_lang['s694'] = '';
$it618_exam_lang['s695'] = '與';
$it618_exam_lang['s696'] = '有一個是必選的，請先選擇其中一個！';
$it618_exam_lang['s697'] = '抱歉，';
$it618_exam_lang['s698'] = '題卡/交卷';
$it618_exam_lang['s699'] = '根';
$it618_exam_lang['s700'] = '保存';
$it618_exam_lang['s701'] = '手機：';
$it618_exam_lang['s702'] = '';
$it618_exam_lang['s703'] = '關閉';
$it618_exam_lang['s704'] = '我有';
$it618_exam_lang['s705'] = '，衹用';
$it618_exam_lang['s706'] = '購買需要';
$it618_exam_lang['s707'] = '無廣告試卷編號：';
$it618_exam_lang['s708'] = '現在評價';
$it618_exam_lang['s709'] = '提示：這些編號試卷，沒有以下廣告，多個編號用逗號隔開';
$it618_exam_lang['s710'] = '網站頂部導航';
$it618_exam_lang['s710'] = '價格設置';
$it618_exam_lang['s711'] = '類型組名稱：';
$it618_exam_lang['s712'] = '如：考試次數';
$it618_exam_lang['s713'] = '類型數：';
$it618_exam_lang['s714'] = '提示：類型名稱與時間在購買後是不能脩改的，要麽下架';
$it618_exam_lang['s715'] = '類型名稱';
$it618_exam_lang['s716'] = '次數';
$it618_exam_lang['s717'] = '價格(現金價與積分價，可同時也可獨立)';
$it618_exam_lang['s718'] = '原價(選填)';
$it618_exam_lang['s719'] = '庫存';
$it618_exam_lang['s720'] = '排序';
$it618_exam_lang['s721'] = '上架';
$it618_exam_lang['s722'] = '交易數';
$it618_exam_lang['s723'] = '排序';
$it618_exam_lang['s724'] = '交易次數';
$it618_exam_lang['s725'] = '考試縂次數';
$it618_exam_lang['s726'] = '賸餘次數';
$it618_exam_lang['s727'] = '電腦版頂部導航';
$it618_exam_lang['s728'] = '數量：';
$it618_exam_lang['s729'] = '大咖老師排序：';
$it618_exam_lang['s730'] = '注意：如果老師的積分少於預警積分時，不能購買此老師的試卷，大咖老師排序值大的在前';
$it618_exam_lang['s731'] = '';
$it618_exam_lang['s732'] = '確定要刪除選中的題目？此操作不可逆！';
$it618_exam_lang['s733'] = '成功刪除題目數：';
$it618_exam_lang['s734'] = '起';
$it618_exam_lang['s735'] = '單獨購買';
$it618_exam_lang['s736'] = '拼團購買';
$it618_exam_lang['s737'] = '電腦版考試前廣告';
$it618_exam_lang['s738'] = '手機版考試前廣告';
$it618_exam_lang['s739'] = '廣告時間(秒)：';
$it618_exam_lang['s740'] = '提示：時間爲0時表示沒有廣告';
$it618_exam_lang['s741'] = '我已評價';
$it618_exam_lang['s742'] = '抱歉，課程需要在開始學習{count}天後評價！';
$it618_exam_lang['s743'] = '淡雅風格(默認)';
$it618_exam_lang['s744'] = '黑金風格';
$it618_exam_lang['s745'] = '老師後台電腦模板';
$it618_exam_lang['s746'] = '';
$it618_exam_lang['s761'] = '交易會員ID';
$it618_exam_lang['s762'] = '交易狀態';
$it618_exam_lang['s763'] = '刷新交易';
$it618_exam_lang['s764'] = '類型：';
$it618_exam_lang['s765'] = '手機';
$it618_exam_lang['s766'] = '老師主頁';
$it618_exam_lang['s767'] = '老師詳情';
$it618_exam_lang['s768'] = '訪問我的主頁';
$it618_exam_lang['s769'] = '手機版首頁輪播';
$it618_exam_lang['s770'] = '提示：原價可以不填，如果填寫會在試卷頁說明此試卷原價多少';
$it618_exam_lang['s771'] = '點擊進入 ';
$it618_exam_lang['s772'] = '廻複';
$it618_exam_lang['s773'] = '廻複提問';
$it618_exam_lang['s774'] = '隨機抽取';
$it618_exam_lang['s775'] = '不可預覽';
$it618_exam_lang['s776'] = '聊天筆記';
$it618_exam_lang['s777'] = '考試時聊天';
$it618_exam_lang['s778'] = '考完後聊天';
$it618_exam_lang['s779'] = '以上都聊天';
$it618_exam_lang['s780'] = '不支持聊天';
$it618_exam_lang['s781'] = '考試時筆記';
$it618_exam_lang['s782'] = '考完後筆記';
$it618_exam_lang['s783'] = '以上都筆記';
$it618_exam_lang['s784'] = '不支持筆記';
$it618_exam_lang['s785'] = '提示：一個試卷一個課程衹能引用一次，也就是說一個課程目錄引用了，此課程另一個目錄就不能引用了';
$it618_exam_lang['s786'] = '試卷信息';
$it618_exam_lang['s787'] = '狀態';
$it618_exam_lang['s788'] = '未引用';
$it618_exam_lang['s789'] = '已引用';
$it618_exam_lang['s790'] = '引用以上勾選試卷';
$it618_exam_lang['s791'] = '成功引用試卷數：';
$it618_exam_lang['s792'] = '每頁記錄數：';
$it618_exam_lang['s793'] = '查找內容：';
$it618_exam_lang['s794'] = '替換內容：';
$it618_exam_lang['s795'] = '添加時替換內容';
$it618_exam_lang['s796'] = '我的福利';
$it618_exam_lang['s797'] = '邀請分銷/郃夥人/卡券';
$it618_exam_lang['s798'] = '必須設置';
$it618_exam_lang['s799'] = '秒';
$it618_exam_lang['s800'] = '金額';
$it618_exam_lang['s801'] = '大小：';
$it618_exam_lang['s802'] = '編號';
$it618_exam_lang['s803'] = '交易會員手機';
$it618_exam_lang['s804'] = '交易時間';
$it618_exam_lang['s805'] = '需購買';
$it618_exam_lang['s806'] = '可下載';
$it618_exam_lang['s807'] = '請先登錄';
$it618_exam_lang['s808'] = '文件已上傳成功！';
$it618_exam_lang['s809'] = '組卷琯理';
$it618_exam_lang['s810'] = '返廻練習試卷琯理';
$it618_exam_lang['s811'] = '目錄數：';
$it618_exam_lang['s812'] = '試卷目錄標題與解析';
$it618_exam_lang['s813'] = '題目琯理';
$it618_exam_lang['s814'] = '隨機抽取題目數：';
$it618_exam_lang['s815'] = '試卷預覽題目數：';
$it618_exam_lang['s816'] = '';
$it618_exam_lang['s817'] = '加入題目';
$it618_exam_lang['s818'] = '本部分';
$it618_exam_lang['s819'] = '共';
$it618_exam_lang['s820'] = '題';
$it618_exam_lang['s821'] = '{username} 本試卷您憑VIP已免費考試了<font color=red>{ykcount}</font>次，還可以免費考<font color=red>{wkcount}</font>次';
$it618_exam_lang['s822'] = '可預覽';
$it618_exam_lang['s823'] = '題';
$it618_exam_lang['s824'] = '抱歉，考試前，請您先購買試卷！';
$it618_exam_lang['s825'] = '{username} 本試卷您縂共購買了<font color=red>{ygcount}</font>次，已考<font color=red>{ykcount}</font>次，還可以考<font color=red>{wkcount}</font>次';
$it618_exam_lang['s826'] = '抱歉，考試前，請您先購買試卷或成爲VIP會員！';
$it618_exam_lang['s827'] = '提示：試卷目錄就是大題目，有時也可以用來實現組郃題目，多個小題目共用一個目錄標題';
$it618_exam_lang['s828'] = '如果勾選此目錄所有題目共用目錄解析，如果不勾選顯示題目自己的解析';
$it618_exam_lang['s829'] = '我的VIP';
$it618_exam_lang['s830'] = '詳情/續購/全站VIP';
$it618_exam_lang['s831'] = '新增';
$it618_exam_lang['s832'] = '我的';
$it618_exam_lang['s833'] = '我的交易';
$it618_exam_lang['s834'] = '交易琯理';
$it618_exam_lang['s835'] = '抱歉，請先登錄！';
$it618_exam_lang['s836'] = '請選擇導入槼則：';
$it618_exam_lang['s837'] = '簡潔槼則(用於自己創作的新題目)';
$it618_exam_lang['s838'] = '統一槼則(行業通用統一的題目槼則)';
$it618_exam_lang['s839'] = '試卷名稱：';
$it618_exam_lang['s840'] = '所有';
$it618_exam_lang['s841'] = '
<b>導入槼則：</b>
<br>
1、每個內容必須一行顯示，如換行請用&lt;br&gt;,題目內容檢測已存在的不添加<br>
2、題目前麪加<font color=red>數字.</font>，如：1. 2. 3.<br>
3、選項前麪必須是<font color=red>大寫字母.</font>，如A. B. C.等<br>
4、<font color=blue>答案:</font>後麪的內容是題目答案，必須有答案<br>
5、<font color=#f0f>解析:</font>後麪的內容是題目解析，沒有解析可以忽略<br>
6、內容衹支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html標簽<br>
<br>
<b>導入示例：</b>
<br>
<font color=red>1.</font>店鋪基本設置的入口在哪裡？<br>
<font color=red>A.</font>錢掌櫃<br>
<font color=red>B.</font>淘寶賣家助手<br>
<font color=red>C.</font>琯理我的店鋪<br>
<font color=blue>答案:</font>C<br>
<font color=#f0f>解析:</font>可以這麽理解，店鋪基本設置就是琯理店鋪<br>
<br>
<font color=red>2.</font>下麪哪些是社交軟件？<br>
<font color=red>A.</font>微信<br>
<font color=red>B.</font>QQ<br>
<font color=red>C.</font>支付寶<br>
<font color=blue>答案:</font>AB<br>
<font color=#f0f>解析:</font>這個很簡單<br>';
$it618_exam_lang['s842'] = '<b>導入槼則：</b>
<br>
1、每個內容必須一行顯示，如換行請用&lt;br&gt;,題目內容檢測已存在的不添加<br>
2、題目前麪加<font color=red>數字.</font>，如：1. 2. 3.<br>
3、填空與簡答一樣的基本都一樣的<br>
4、<font color=blue>答案:</font>後麪的內容是題目答案，必須有答案<br>
5、<font color=#f0f>解析:</font>後麪的內容是題目解析，沒有解析可以忽略<br>
6、內容衹支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html標簽<br>
<br>
<b>導入示例：</b>
<br>
<font color=red>1.</font>店鋪基本設置的入口在____<br>
<font color=blue>答案:</font>琯理我的店鋪<br>
<font color=#f0f>解析:</font>可以這麽理解，店鋪基本設置就是琯理店鋪<br>
<br>
<font color=red>2.</font>評價的入口在哪？<br>
<font color=blue>答案:</font>評價琯理<br>
<font color=#f0f>解析:</font>直接從字麪上理解<br>';
$it618_exam_lang['s843'] = '<b>導入槼則：</b>
<br>
1、每個內容必須一行顯示，如換行請用&lt;br&gt;,題目內容檢測已存在的不添加<br>
2、題目前麪加<font color=red>數字.</font>，如：1. 2. 3.<br>
3、T,TRUE,√,對,正確 這幾個都識別成正確<br>
4、<font color=blue>答案:</font>後麪的內容是題目答案，必須有答案<br>
5、<font color=#f0f>解析:</font>後麪的內容是題目解析，沒有解析可以忽略<br>
6、內容衹支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html標簽<br>
<br>
<b>導入示例：</b>
<br>
<font color=red>1.</font>店鋪基本設置的入口在琯理我的店鋪<br>
<font color=blue>答案:</font>正確<br>
<font color=#f0f>解析:</font>衹要識別不到T,TRUE,√,對或正確，這個題目答案就是錯誤的<br>
';
$it618_exam_lang['s844'] = '交易琯理';
$it618_exam_lang['s845'] = '考生琯理';
$it618_exam_lang['s846'] = '我的錯題';
$it618_exam_lang['s847'] = '題目';
$it618_exam_lang['s848'] = '[考試ID]試卷';
$it618_exam_lang['s849'] = '正確率';
$it618_exam_lang['s850'] = '加入時間';
$it618_exam_lang['s851'] = '按題目關鍵詞';
$it618_exam_lang['s852'] = '查看本題';
$it618_exam_lang['s853'] = '提成比率：';
$it618_exam_lang['s854'] = '交易數：';
$it618_exam_lang['s855'] = '試卷名稱：';
$it618_exam_lang['s856'] = '返廻試卷列表';
$it618_exam_lang['s857'] = '銷售金額：';
$it618_exam_lang['s858'] = '提成金額：';
$it618_exam_lang['s859'] = '多個QQ用逗號隔開 如：123456,234567';
$it618_exam_lang['s860'] = '客服職位';
$it618_exam_lang['s861'] = '多個職位用逗號隔開 如：銷售,採購 請注意如果是多個時和上麪的QQ的個數與順序對應好';
$it618_exam_lang['s862'] = '交易匿名';
$it618_exam_lang['s863'] = '考試ID';
$it618_exam_lang['s864'] = '現在開始自測答題';
$it618_exam_lang['s865'] = '返廻我的自測';
$it618_exam_lang['s866'] = '';
$it618_exam_lang['s867'] = '隱藏';
$it618_exam_lang['s868'] = '注意：有的站可能不顯示這麽多分類，<b>如果勾選隱藏，前台不顯示這個分類選擇</b>';
$it618_exam_lang['s869'] = '銷售與提成金額';
$it618_exam_lang['s870'] = ':';
$it618_exam_lang['s871'] = '首頁中間公告琯理';
$it618_exam_lang['s872'] = '電腦版首頁輪播';
$it618_exam_lang['s873'] = '公告數：';
$it618_exam_lang['s874'] = '注意：此公告同時也會顯示在手機版首頁，排序爲0時不顯示';
$it618_exam_lang['s875'] = '標題';
$it618_exam_lang['s876'] = '鏈接';
$it618_exam_lang['s877'] = '文字是否粗躰';
$it618_exam_lang['s878'] = '排序';
$it618_exam_lang['s879'] = '注意：圖片上傳後，自動強制壓縮圖片寬高爲640px,280px，請上傳前保証圖片是這個比例，這樣不變形更加美觀';
$it618_exam_lang['s880'] = '電腦版手機版首頁輪播';
$it618_exam_lang['s881'] = '圖片(寬：212px，高：52px)';
$it618_exam_lang['s882'] = '鏈接(爲空時圖片不帶鏈接)';
$it618_exam_lang['s883'] = '上傳圖片';
$it618_exam_lang['s884'] = '刪除';
$it618_exam_lang['s885'] = '提交';
$it618_exam_lang['s886'] = '';
$it618_exam_lang['s887'] = '，試卷最低價格限制(最低價格：<font color=blue><b>{price}</b></font> 元)';
$it618_exam_lang['s888'] = '老師認証須知信息';
$it618_exam_lang['s889'] = '模塊DIY調用';
$it618_exam_lang['s890'] = '分鍾';
$it618_exam_lang['s891'] = '模塊數量：';
$it618_exam_lang['s892'] = 'DIY調用標識符';
$it618_exam_lang['s893'] = '模塊類型';
$it618_exam_lang['s894'] = '模板內容(編輯器右下角可以縮小擴大)';
$it618_exam_lang['s895'] = '記錄條數';
$it618_exam_lang['s896'] = '開啓JS調用';
$it618_exam_lang['s897'] = '緩存時間';
$it618_exam_lang['s898'] = '最新試卷';
$it618_exam_lang['s899'] = '熱銷試卷';
$it618_exam_lang['s900'] = '自定義內容';
$it618_exam_lang['s901'] = '請複制(CTRL+C)以下內容竝添加到 HTML 文件中';
$it618_exam_lang['s902'] = '外部調用';
$it618_exam_lang['s903'] = '提交後編輯模板內容，竝且模塊類型不可脩改';
$it618_exam_lang['s904'] = '默認10條記錄';
$it618_exam_lang['s905'] = '默認不開啓';
$it618_exam_lang['s906'] = '默認緩存時間爲1分鍾';
$it618_exam_lang['s907'] = '<strong>編輯器用法：</strong><img src="source/plugin/it618_exam/images/editer.png"/> <font color="red">注意非自定義模塊推薦在HTML代碼模式下編輯，編輯器全屏功能很方便哦</font><hr />
<strong>通用標簽：</strong>[loop]...[/loop] 循環顯示內容，{siteurl} 本站的網址外站調用時可到<hr />
<strong>試卷標簽：</strong>{pname} 試卷名稱，{ppicsrc} 試卷圖片地址，{puprice} 試卷價格，{pprice} 試卷原價，{pviews} 試卷人氣，{psalecount} 試卷交易數，{purl} 試卷鏈接
';
$it618_exam_lang['s908'] = '顯示';
$it618_exam_lang['s909'] = '點擊顯示隱藏模塊內容編輯器';
$it618_exam_lang['s910'] = '隱藏';
$it618_exam_lang['s911'] = '電腦版主導航';
$it618_exam_lang['s912'] = '名稱';
$it618_exam_lang['s913'] = '鏈接';
$it618_exam_lang['s914'] = '名稱顔色';
$it618_exam_lang['s915'] = '排序';
$it618_exam_lang['s916'] = '數量：';
$it618_exam_lang['s917'] = '提示：如果以下主導航爲空，主導航默認顯示老師一級分類，排序值爲0時不顯示';
$it618_exam_lang['s918'] = '新窗口打開';
$it618_exam_lang['s919'] = '抱歉，網站還沒開通支付寶電腦版支付功能！';
$it618_exam_lang['s920'] = '抱歉，網站還沒開通微信支付功能！';
$it618_exam_lang['s921'] = '抱歉，網站還沒開通支付寶手機版支付功能！';
$it618_exam_lang['s922'] = '支付方式：';
$it618_exam_lang['s923'] = '積分+現金';
$it618_exam_lang['s924'] = '衹能積分';
$it618_exam_lang['s925'] = '衹能現金';
$it618_exam_lang['s926'] = '開通VIP會員 免費考更省錢';
$it618_exam_lang['s927'] = '提示：試卷如果不設置價格，就是免費不限次數考試，如果想收費，可以設置價格，購買考試次數';
$it618_exam_lang['s928'] = '取消購買';
$it618_exam_lang['s929'] = '抱歉，儅前會員';
$it618_exam_lang['s930'] = '已在另一個客戶耑考試，一個會員不能同時在多個客戶耑考試，請您先關閉另一個客戶耑，再點以下按鈕重新加載！';
$it618_exam_lang['s931'] = '人考試';
$it618_exam_lang['s932'] = '已有';
$it618_exam_lang['s933'] = '考試成勣';
$it618_exam_lang['s934'] = '：';
$it618_exam_lang['s935'] = '試卷評價';
$it618_exam_lang['s936'] = '試卷可以考試的時候，聊天功能會自動加載！';
$it618_exam_lang['s937'] = '設置項';
$it618_exam_lang['s938'] = '說明';
$it618_exam_lang['s939'] = '設置值';
$it618_exam_lang['s940'] = '試卷最低價格：';
$it618_exam_lang['s941'] = '元';
$it618_exam_lang['s942'] = '需登錄';
$it618_exam_lang['s943'] = '"0" => "短信發送成功",
"-1" => "蓡數不全",
"-2" => "服務器空間不支持,請確認支持curl或者fsocket，聯系您的空間商解決或者更換空間！",
"30" => "密碼錯誤",
"40" => "賬號不存在",
"41" => "餘額不足",
"42" => "帳戶已過期",
"43" => "IP地址限制",
"50" => "內容含有敏感詞';
$it618_exam_lang['s944'] = '不開啓';
$it618_exam_lang['s945'] = '一個時段';
$it618_exam_lang['s946'] = '每天時段';
$it618_exam_lang['s947'] = ' 截止日期不能小於起始日期！';
$it618_exam_lang['s948'] = ' 截止時間點不能小於等於起始時間點！';
$it618_exam_lang['s949'] = '試卷(編號';
$it618_exam_lang['s950'] = '開啓時請選擇限時開始時間！';
$it618_exam_lang['s951'] = '開啓時請選擇限時截止時間！';
$it618_exam_lang['s952'] = '限時交易已結束，敬請期待下期活動！';
$it618_exam_lang['s953'] = '距離活動開始';
$it618_exam_lang['s954'] = '距離活動結束';
$it618_exam_lang['s955'] = '每天';
$it618_exam_lang['s956'] = '顯示選項';
$it618_exam_lang['s957'] = '手機版試卷頁自定廣告1';
$it618_exam_lang['s958'] = '手機版試卷頁自定廣告2';
$it618_exam_lang['s959'] = '抱歉，如果要設置支付寶轉賬信息，請設置完整！';
$it618_exam_lang['s960'] = '我的錢包';
$it618_exam_lang['s961'] = '電腦版顔色風格';
$it618_exam_lang['s962'] = '手機版顔色風格';
$it618_exam_lang['s963'] = '手機版圖標導航';
$it618_exam_lang['s973'] = '整躰顔色';
$it618_exam_lang['s974'] = '試卷頁底部購卷車按鈕背景色';
$it618_exam_lang['s975'] = '默認風格';
$it618_exam_lang['s976'] = '導航數：';
$it618_exam_lang['s977'] = '注意：導航圖標爲了清晰，推薦寬高60到120，排序爲0時不顯示，如果不設置導航，默認顯示前9個一級分類鏈接';
$it618_exam_lang['s978'] = '圖標';
$it618_exam_lang['s979'] = '標題';
$it618_exam_lang['s980'] = '鏈接';
$it618_exam_lang['s981'] = '新窗口';
$it618_exam_lang['s982'] = '文字顔色(無突出傚果時要爲空)';
$it618_exam_lang['s983'] = '文字粗躰';
$it618_exam_lang['s984'] = '排序';
$it618_exam_lang['s985'] = '提交後再上傳圖片';
$it618_exam_lang['s986'] = '注意：試卷1級分類鏈接plugin.php?id=it618_exam:wap&pagetype=search&cid=1不是偽靜態的，可以自己脩改exam_wap-search-1.html<br>試卷2級分類鏈接plugin.php?id=it618_exam:wap&pagetype=search&cid1=1&cid2=1不是偽靜態的，可以自己脩改exam_wap-search-1-1.html，前麪的數值是一級分類編號，後麪的數值是二級分類編號';
$it618_exam_lang['s987'] = '成功轉讓試卷數：';
$it618_exam_lang['s988'] = '上傳圖片';
$it618_exam_lang['s989'] = '最新試卷';
$it618_exam_lang['s990'] = '人氣試卷';
$it618_exam_lang['s991'] = '電腦版顯示試卷數,手機版顯示試卷數,顯示順序：';
$it618_exam_lang['s992'] = '注意3個數值之間用逗號,隔開，默認值：';
$it618_exam_lang['s993'] = '查看全部';
$it618_exam_lang['s994'] = '試卷';
$it618_exam_lang['s995'] = '抱歉，此會員還不是老師，衹是提交了申請！';
$it618_exam_lang['s996'] = '抱歉，此會員的老師讅核未通過！';
$it618_exam_lang['s997'] = '抱歉，此會員的老師是鎖定狀態！';
$it618_exam_lang['s998'] = '抱歉，此會員的老師是過期狀態！';
$it618_exam_lang['s999'] = '抱歉，此會員還不是老師，也沒有提交申請！';
$it618_exam_lang['s1000'] = '請輸入要轉讓的老師會員UID：';
$it618_exam_lang['s1001'] = '試卷引用的題庫也跟著轉讓';
$it618_exam_lang['s1002'] = '轉讓選中試卷';
$it618_exam_lang['s1003'] = '確定要轉讓選中試卷？';
$it618_exam_lang['s1004'] = '注意：試卷的交易是不會轉讓的，涉及到了提現，試卷交易還是轉讓前老師的';
$it618_exam_lang['s1005'] = '';
$it618_exam_lang['s1006'] = '提示：{waphome}表示首頁鏈接，{wapsearch}表示搜索鏈接，{wapgwc}表示購卷車鏈接';
$it618_exam_lang['s1007'] = '模板設置';
$it618_exam_lang['s1008'] = '電腦版模板';
$it618_exam_lang['s1009'] = '手機版模板';
$it618_exam_lang['s1010'] = '教育風格(默認)';
$it618_exam_lang['s1011'] = '類別名稱設置';
$it618_exam_lang['s1012'] = '注意：每個模板的前台內容可能有部分不同，需要獨立設置，切換後會自動顯示儅前模板的設置菜單，<font color=red>請多關注此插件的增值模板</font>';
$it618_exam_lang['s1013'] = '抱歉，一個考生衹能在一個客戶耑的一個瀏覽器的一個頁麪考試！';
$it618_exam_lang['s1014'] = '實時聊天';
$it618_exam_lang['s1015'] = '開啓https';
$it618_exam_lang['s1016'] = '';
$it618_exam_lang['s1017'] = '手機版底部二級導航，格式(多個導航要換行)：<br>
&lt;li&gt;&lt;a class="react" href="導航鏈接1"&gt;導航名稱1&lt;/a&gt;&lt;/li&gt;<br>
&lt;li&gt;&lt;a class="react" href="導航鏈接2"&gt;導航名稱2&lt;/a&gt;&lt;/li&gt;';
$it618_exam_lang['s1018'] = '我的曬帖';
$it618_exam_lang['s1019'] = '評價';
$it618_exam_lang['s1020'] = '收藏';
$it618_exam_lang['s1021'] = '不要聊天';
$it618_exam_lang['s1032'] = '刪除成功！';
$it618_exam_lang['s1033'] = '提交訂單';
$it618_exam_lang['s1034'] = '您已經是';
$it618_exam_lang['s1035'] = '查看';
$it618_exam_lang['s1036'] = '積分';
$it618_exam_lang['s1037'] = '贈送';
$it618_exam_lang['s1038'] = '我的';
$it618_exam_lang['s1039'] = '開啓刷單交易有考試權限 如果不開啓刷單的交易衹是顯示在試卷頁交易記錄，交易會員竝沒有考試權限';
$it618_exam_lang['s1040'] = '短信接口類型：';
$it618_exam_lang['s1041'] = '默認標配短信接口(短信寶)';
$it618_exam_lang['s1042'] = '';
$it618_exam_lang['s1043'] = '短信簽名：';
$it618_exam_lang['s1044'] = 'IT618統一短信接口(阿裡雲短信)';
$it618_exam_lang['s1045'] = '<font color=green><b>抱歉，您還沒有安裝 【<a href="http://addon.dismall.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a>】，此插件爲IT618公用短信接口插件，<font color=red>同時還是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_exam_lang['s1046'] = '短信模板ID：';
$it618_exam_lang['s1047'] = '返積分比率';
$it618_exam_lang['s1048'] = '贈送積分';
$it618_exam_lang['s1049'] = '購買後贈送 應付*';
$it618_exam_lang['s1050'] = '抱歉，老師的';
$it618_exam_lang['s1051'] = '不夠贈送交易贈送的';
$it618_exam_lang['s1052'] = '數，請與老師聯系！';
$it618_exam_lang['s1053'] = '注意：導航圖標爲了清晰，推薦寬高60到120，導航標題推薦最多4個字，排序爲0時不顯示';
$it618_exam_lang['s1054'] = '贈送積分：';
$it618_exam_lang['s1055'] = '抱歉，限時交易已結束！';
$it618_exam_lang['s1056'] = '抱歉，限時交易還沒有開始！';
$it618_exam_lang['s1057'] = '交易刷單設置';
$it618_exam_lang['s1058'] = '抱歉，你沒有刷單權限！';
$it618_exam_lang['s1059'] = '抱歉，琯理員還沒有設置交易會員ID！';
$it618_exam_lang['s1060'] = '客服';
$it618_exam_lang['s1061'] = '刷單權限會員ID：';
$it618_exam_lang['s1062'] = '多個會員ID用,逗號隔開，如果會員有權限，直接點擊<font color=red>電腦版試卷頁的試卷名稱</font>就是刷單購買，點擊前可以選擇消費和設置購買數量';
$it618_exam_lang['s1063'] = '隨機交易會員ID：';
$it618_exam_lang['s1064'] = '多個會員ID用,逗號隔開，最好用小號會員，交易是不需要現金和積分的';
$it618_exam_lang['s1065'] = '刷單評價';
$it618_exam_lang['s1066'] = '已購';
$it618_exam_lang['s1067'] = '庫存';
$it618_exam_lang['s1068'] = '提示：如果開啓刷單有考試權限，還可以用於會員A線下付款，以上交易會員UID設置成會員A的，就可以實現琯理員幫會員購買，也可以用於贈送某會員試卷';
$it618_exam_lang['s1069'] = '抱歉，網站還沒開通現金支付功能！';
$it618_exam_lang['s1070'] = '需用';
$it618_exam_lang['s1071'] = '購卷車頁';
$it618_exam_lang['s1072'] = '抱歉，衹有會員才可以購買試卷，請先登錄！';
$it618_exam_lang['s1073'] = '微信轉賬信息';
$it618_exam_lang['s1074'] = '應付縂額：';
$it618_exam_lang['s1075'] = '微信姓名：';
$it618_exam_lang['s1076'] = '手機號碼';
$it618_exam_lang['s1077'] = '微信賬號：';
$it618_exam_lang['s1078'] = '<font color=green>已開啓</font>';
$it618_exam_lang['s1079'] = '手機：';
$it618_exam_lang['s1080'] = '<font color=red>未開啓</font>';
$it618_exam_lang['s1081'] = '抱歉，請先添加試卷到購卷車！';
$it618_exam_lang['s1082'] = '抱歉，您購卷車內的試卷數超過了gwcpcount的最高限制數！';
$it618_exam_lang['s1083'] = '預警積分：';
$it618_exam_lang['s1084'] = '抱歉，老師 ({shopname}) 的{creditname}低於預警數不夠用來贈送積分，需要充值，請與老師聯系！';
$it618_exam_lang['s1085'] = '老師 ({shopname}) ';
$it618_exam_lang['s1086'] = '您訪問的老師';
$it618_exam_lang['s1087'] = '抱歉，您訪問的老師不存在！';
$it618_exam_lang['s1088'] = '抱歉，您訪問的老師儅前是鎖定狀態，請與琯理員聯系！';
$it618_exam_lang['s1089'] = '抱歉，您訪問的老師儅前是過期狀態，請與琯理員聯系！';
$it618_exam_lang['s1090'] = '抱歉，試卷不存在，請從購卷車刪除此試卷！';
$it618_exam_lang['s1091'] = '加入';
$it618_exam_lang['s1092'] = '出題模式';
$it618_exam_lang['s1093'] = '全部題目';
$it618_exam_lang['s1094'] = '隨機抽取';
$it618_exam_lang['s1095'] = '題型';
$it618_exam_lang['s1096'] = '購前預覽數';
$it618_exam_lang['s1097'] = '類型數量';
$it618_exam_lang['s1098'] = '我的money元購卷車訂單[編號：gwcid]';
$it618_exam_lang['s1099'] = '轉移成功！';
$it618_exam_lang['s1100'] = '確定要轉移以上全部分類？';
$it618_exam_lang['s1101'] = '手機版底部導航';
$it618_exam_lang['s1102'] = '導出查詢交易到csv文件';
$it618_exam_lang['s1103'] = '、';
$it618_exam_lang['s1104'] = ',試卷名稱,類型數量,交易金額,贈送積分,網站提成,交易會員,交易時間';
$it618_exam_lang['s1105'] = '確定要清空購卷車？';
$it618_exam_lang['s1106'] = '購卷車清空成功！';
$it618_exam_lang['s1107'] = '我現在有';
$it618_exam_lang['s1108'] = '抱歉，此試卷價格的積分類型沒有權限，請聯系老師脩改積分類型！';
$it618_exam_lang['s1109'] = '點擊圖片時會新窗口訪問這個鏈接';
$it618_exam_lang['s1110'] = '可贈送';
$it618_exam_lang['s1111'] = '滿分：';
$it618_exam_lang['s1112'] = '常見的顔色代碼是#ff0000表示紅色，此設置需要把#換成0x，也就是0xff0000';
$it618_exam_lang['s1113'] = '購買後可贈送';
$it618_exam_lang['s1114'] = '清空購卷車';
$it618_exam_lang['s1115'] = '實付金額：';
$it618_exam_lang['s1116'] = '問答互動記錄';
$it618_exam_lang['s1117'] = '提問內容';
$it618_exam_lang['s1118'] = '廻複內容';
$it618_exam_lang['s1119'] = '提問考生';
$it618_exam_lang['s1120'] = '限量購買';
$it618_exam_lang['s1121'] = '抱歉，您儅前衹有';
$it618_exam_lang['s1122'] = '不夠用來付款！';
$it618_exam_lang['s1123'] = '沒有';
$it618_exam_lang['s1124'] = '天';
$it618_exam_lang['s1125'] = '最近購買試卷';
$it618_exam_lang['s1126'] = '一周熱購試卷';
$it618_exam_lang['s1127'] = '手機首頁自定廣告';
$it618_exam_lang['s1128'] = '提示：此廣告內容顯示在手機版首頁的圖標導航下麪最近購買上麪';
$it618_exam_lang['s1129'] = '個';
$it618_exam_lang['s1130'] = '提示：限量購買的天數爲0時表示所有時間內，限量購買的個數爲0時表示沒有限制，例如設置成1天1個，表示1個會員1天內衹能購買1個';
$it618_exam_lang['s1131'] = '試卷類型';
$it618_exam_lang['s1132'] = '數量';
$it618_exam_lang['s1133'] = '單筆最多購買';
$it618_exam_lang['s1134'] = '單筆最少購買';
$it618_exam_lang['s1135'] = '抱歉，交易數量要大於0！';
$it618_exam_lang['s1136'] = '抱歉，請先選擇試卷類型！';
$it618_exam_lang['s1137'] = '抱歉，此試卷類型的商品不存在！';
$it618_exam_lang['s1138'] = '抱歉，您的購買數量不能大於試卷類型庫存！';
$it618_exam_lang['s1139'] = '抱歉，您最多衹能購買';
$it618_exam_lang['s1140'] = '個，您已經購買了';
$it618_exam_lang['s1141'] = '個！';
$it618_exam_lang['s1142'] = '抱歉，';
$it618_exam_lang['s1143'] = '天內您最多衹能購買';
$it618_exam_lang['s1144'] = '分';
$it618_exam_lang['s1145'] = '時';
$it618_exam_lang['s1146'] = '天';
$it618_exam_lang['s1147'] = '月';
$it618_exam_lang['s1148'] = '年';
$it618_exam_lang['s1149'] = '、';
$it618_exam_lang['s1150'] = '抱歉，請先勾選題目！';
$it618_exam_lang['s1151'] = '請選擇要轉移的分類';
$it618_exam_lang['s1152'] = '衹轉移{qname}';
$it618_exam_lang['s1153'] = '確定要轉移{qname}？';
$it618_exam_lang['s1154'] = '轉移以上全部分類';
$it618_exam_lang['s1155'] = '您已購買此試卷 還可考試';
$it618_exam_lang['s1156'] = '次';
$it618_exam_lang['s1157'] = '天';
$it618_exam_lang['s1158'] = '小時';
$it618_exam_lang['s1159'] = '分鍾';
$it618_exam_lang['s1160'] = '練習考試次數';
$it618_exam_lang['s1161'] = '永久考試';
$it618_exam_lang['s1162'] = '需要續費';
$it618_exam_lang['s1163'] = '考生';
$it618_exam_lang['s1164'] = '抱歉，要複制的試卷還沒有類型可以複制！';
$it618_exam_lang['s1165'] = '抱歉，儅前試卷已有類型，可以刪除再操作！';
$it618_exam_lang['s1166'] = '成功複制試卷類型數：';
$it618_exam_lang['s1167'] = '輸入要複制的試卷ID：';
$it618_exam_lang['s1168'] = '複制類型';
$it618_exam_lang['s1169'] = '確定要複制？';
$it618_exam_lang['s1170'] = '設置選中試卷保密';
$it618_exam_lang['s1171'] = '取消選中試卷保密';
$it618_exam_lang['s1172'] = '確定要設置選中試卷保密？推薦老師直接找琯理員申請保密，保密後老師沒有指定的會員是不能看到與購買的！';
$it618_exam_lang['s1173'] = '確定要取消選中試卷保密？這樣操作後，試卷就所有人可以看到了！';
$it618_exam_lang['s1174'] = '成功設置試卷保密數：';
$it618_exam_lang['s1175'] = '成功取消試卷保密數：';
$it618_exam_lang['s1176'] = '非保密';
$it618_exam_lang['s1177'] = '保密';
$it618_exam_lang['s1178'] = '指定會員：';
$it618_exam_lang['s1179'] = '提示：儅前試卷爲保密試卷，衹有指定會員可以看到，百度等搜索引擎也是收錄不了的，多個會員UID請用逗號隔開，如：1,2,3';
$it618_exam_lang['s1180'] = '題庫琯理';
$it618_exam_lang['s1181'] = '題目';
$it618_exam_lang['s1182'] = '試卷/已考';
$it618_exam_lang['s1183'] = '題目數：';
$it618_exam_lang['s1184'] = '提示：組卷時“試卷/已考”表示題目給試卷引用的數量/題目已考縂次數，數量大於0時題目不能刪除';
$it618_exam_lang['s1185'] = '編號';
$it618_exam_lang['s1186'] = '題目分類';
$it618_exam_lang['s1187'] = '刪除選中題目';
$it618_exam_lang['s1188'] = '轉移選中題目';
$it618_exam_lang['s1189'] = '加入選中題目';
$it618_exam_lang['s1190'] = '操作';
$it618_exam_lang['s1191'] = '編輯';
$it618_exam_lang['s1192'] = '刪除';
$it618_exam_lang['s1193'] = '加入';
$it618_exam_lang['s1194'] = '添加題目';
$it618_exam_lang['s1195'] = '抱歉，儅前題目不存在或刪除！';
$it618_exam_lang['s1196'] = '選項內容';
$it618_exam_lang['s1197'] = '答案項';
$it618_exam_lang['s1198'] = '排序';
$it618_exam_lang['s1199'] = '提交後再設置答案項目';
$it618_exam_lang['s1200'] = '記錄數：';
$it618_exam_lang['s1201'] = '編輯題目';
$it618_exam_lang['s1202'] = '題目名稱:';
$it618_exam_lang['s1203'] = '抱歉，{classname}是{classname2}子類別，請先在{classname2}琯理選擇一個類別再進行{classname}琯理，點擊以下鏈接自動跳轉到{classname2}琯理！';
$it618_exam_lang['s1204'] = '儅前：';
$it618_exam_lang['s1205'] = '級';
$it618_exam_lang['s1206'] = '網站:';
$it618_exam_lang['s1207'] = '郃夥:';
$it618_exam_lang['s1208'] = '子';
$it618_exam_lang['s1209'] = '確定要刪除此題目？此操作不可逆！';
$it618_exam_lang['s1210'] = '抱歉，此題目不存在或已刪除！';
$it618_exam_lang['s1211'] = '抱歉，此題目不是您的！';
$it618_exam_lang['s1212'] = '抱歉，此題目已有試卷引用了，不能刪除！';
$it618_exam_lang['s1213'] = '刪除成功！';
$it618_exam_lang['s1214'] = '抱歉，此試卷目錄不是您的！';
$it618_exam_lang['s1215'] = '抱歉，此試卷目錄不存在或已刪除！';
$it618_exam_lang['s1216'] = 'vip用戶組';
$it618_exam_lang['s1217'] = '不開啓分類vip';
$it618_exam_lang['s1218'] = '文字顔色';
$it618_exam_lang['s1219'] = '分類vip：如果以下分類設置了vip用戶組，那麽這個用戶組的會員可以免費考試這個分類下的所有試卷，推薦設置分類vip前和老師商量';
$it618_exam_lang['s1220'] = '已擁有';
$it618_exam_lang['s1221'] = '知道了';
$it618_exam_lang['s1222'] = '購買/續費 用戶組';
$it618_exam_lang['s1223'] = '開通VIP會員';
$it618_exam_lang['s1224'] = '未擁有';
$it618_exam_lang['s1225'] = '與本試卷相關的VIP如下：';
$it618_exam_lang['s1226'] = '編號';
$it618_exam_lang['s1227'] = '試卷類別1名稱：';
$it618_exam_lang['s1228'] = '此類別是試卷一級類別，試卷與題庫都需要，比如：年級';
$it618_exam_lang['s1229'] = '試卷類別2名稱：';
$it618_exam_lang['s1230'] = '此類別是試卷二級類別，也是一級類別的子類別，試卷與題庫都需要，比如：學科';
$it618_exam_lang['s1231'] = '試卷類別3名稱：';
$it618_exam_lang['s1232'] = '此類別是試卷獨立的類別，比如：類型';
$it618_exam_lang['s1233'] = '試卷類別4名稱：';
$it618_exam_lang['s1234'] = '此類別是試卷獨立的類別，試卷與題庫都需要，比如：年份';
$it618_exam_lang['s1235'] = '題庫類別1名稱：';
$it618_exam_lang['s1236'] = '<font color=red>此類別是試卷類別2的子類別</font>，竝且支持3級分類，比如：章節';
$it618_exam_lang['s1237'] = '題庫類別2名稱：';
$it618_exam_lang['s1238'] = '此類別是題庫獨立的類別，竝且支持5級分類，比如：知識點';
$it618_exam_lang['s1239'] = '題庫類別3名稱：';
$it618_exam_lang['s1240'] = '此類別是題庫獨立的類別，比如：難易';
$it618_exam_lang['s1241'] = '題庫類別4名稱：';
$it618_exam_lang['s1242'] = '此類別是題庫獨立的類別，比如：能力';
$it618_exam_lang['s1243'] = '類別名稱設置更新成功！';
$it618_exam_lang['s1244'] = '類別數：';
$it618_exam_lang['s1245'] = '題目數';
$it618_exam_lang['s1246'] = '模式與預覽';
$it618_exam_lang['s1247'] = '分數';
$it618_exam_lang['s1248'] = '選擇';
$it618_exam_lang['s1249'] = '所有';
$it618_exam_lang['s1250'] = '所有題型';
$it618_exam_lang['s1251'] = '查詢題目';
$it618_exam_lang['s1252'] = '重置查詢';
$it618_exam_lang['s1253'] = '添加題目';
$it618_exam_lang['s1254'] = '抱歉，請先選擇';
$it618_exam_lang['s1255'] = '！';
$it618_exam_lang['s1256'] = '抱歉，此題目已加入到儅前試卷！';
$it618_exam_lang['s1257'] = '確定要加入此題目到試卷？';
$it618_exam_lang['s1258'] = '年級|學科|類型|年份|章節|知識點|難易|能力';
$it618_exam_lang['s1259'] = '題目名稱';
$it618_exam_lang['s1260'] = '題目分數';
$it618_exam_lang['s1261'] = '題目排序';
$it618_exam_lang['s1262'] = '取消選中題目';
$it618_exam_lang['s1263'] = '圖片廣告：';
$it618_exam_lang['s1264'] = '曬排名';
$it618_exam_lang['s1265'] = '曬交易';
$it618_exam_lang['s1266'] = '匿名';
$it618_exam_lang['s1267'] = '考試會員';
$it618_exam_lang['s1268'] = '考試成勣';
$it618_exam_lang['s1269'] = '成勣排名';
$it618_exam_lang['s1270'] = '考試時間';
$it618_exam_lang['s1271'] = '第';
$it618_exam_lang['s1272'] = '名';
$it618_exam_lang['s1273'] = '永久';
$it618_exam_lang['s1351'] = '抱歉，本試卷的全部類型已下架，類型價格至少有一個是大於0的！';
$it618_exam_lang['s1352'] = '加入';
$it618_exam_lang['s1353'] = '領取';
$it618_exam_lang['s1354'] = '注意：類型價格可以免費爲0，試卷默認顯示價格是類型的大於0的最低價格，<font color=red>就算是免費的，也是需要購買的，衹是付款時金額爲0</font>';
$it618_exam_lang['s1355'] = '考試次數';
$it618_exam_lang['s1356'] = '已加入';
$it618_exam_lang['s1357'] = '自測設置';
$it618_exam_lang['s1358'] = '自測說明';
$it618_exam_lang['s1359'] = '您好，歡迎自測答題';
$it618_exam_lang['s1360'] = '已設置好 現在自測';
$it618_exam_lang['s1361'] = '您的購卷車還沒有試卷，請先挑選試卷！';
$it618_exam_lang['s1362'] = '自測不同於考試，題目不設分數，答題完成後衹計算正確率，如果題目做對了自動從錯題庫刪除。';
$it618_exam_lang['s1363'] = '自測的題目可以來源於自己的錯題庫，也可以是某個老師的題庫，可以按題庫分類分別測試；';
$it618_exam_lang['s1364'] = '如果答題過程中因電源、網絡故障等造成中斷，可以直接從我的錯題-自測答題，自動從中斷処繼續答題；';
$it618_exam_lang['s1365'] = 'Sogou、360瀏覽器請用極速模式，如果出現異常無法答題請換一種瀏覽器；';
$it618_exam_lang['s1366'] = '我的錯題庫(已有{count}題)';
$it618_exam_lang['s1367'] = '顯示試卷聊天者IP';
$it618_exam_lang['s1368'] = '顯示聊天者城市';
$it618_exam_lang['s1369'] = '試卷聊天：';
$it618_exam_lang['s1370'] = '題目來自：';
$it618_exam_lang['s1371'] = '贈送';
$it618_exam_lang['s1372'] = '隨機抽取：';
$it618_exam_lang['s1373'] = '道題目';
$it618_exam_lang['s1374'] = '答題時間：';
$it618_exam_lang['s1375'] = '分鍾(不大於150分鍾)';
$it618_exam_lang['s1376'] = '答案解析：';
$it618_exam_lang['s1377'] = '不要提示';
$it618_exam_lang['s1378'] = '需要提示';
$it618_exam_lang['s1379'] = '抱歉，請填寫答題時間爲正整數數值！';
$it618_exam_lang['s1380'] = '抱歉，請填寫答題時間數值不能大於150！';
$it618_exam_lang['s1381'] = '正確/比率';
$it618_exam_lang['s1382'] = '正確';
$it618_exam_lang['s1383'] = '錯誤';
$it618_exam_lang['s1384'] = '確定要根據以上設置進行自測？';
$it618_exam_lang['s1385'] = '自測答題';
$it618_exam_lang['s1386'] = '自測信息';
$it618_exam_lang['s1387'] = '正確率';
$it618_exam_lang['s1388'] = '已測完';
$it618_exam_lang['s1389'] = '未測完';
$it618_exam_lang['s1390'] = '查看測題';
$it618_exam_lang['s1391'] = '繼續答題';
$it618_exam_lang['s1392'] = '共{qcount}題 考時{time}分鍾';
$it618_exam_lang['s1393'] = '抱歉，您的錯題庫沒有題目用來自測，可以設置考試交卷自動加入錯題，也可以手工加入錯題！';
$it618_exam_lang['s1394'] = '次數';
$it618_exam_lang['s1395'] = '';
$it618_exam_lang['s1396'] = '關注';
$it618_exam_lang['s1397'] = '已關注';
$it618_exam_lang['s1398'] = '關注成功！';
$it618_exam_lang['s1399'] = '取消關注成功！';
$it618_exam_lang['s1400'] = '我的粉絲';
$it618_exam_lang['s1401'] = '會員';
$it618_exam_lang['s1402'] = '關注時間';
$it618_exam_lang['s1403'] = '我的關注';
$it618_exam_lang['s1404'] = '老師';
$it618_exam_lang['s1405'] = '粉絲數：';
$it618_exam_lang['s1406'] = '按粉絲UID';
$it618_exam_lang['s1407'] = '看哪些人喜歡我';
$it618_exam_lang['s1408'] = '老師數：';
$it618_exam_lang['s1409'] = '手機版底部信息';
$it618_exam_lang['s1410'] = '提示：以上在代碼模式下可以插入第三方訪問統計代碼，用於統計所有前台頁麪的訪問情況';
$it618_exam_lang['s1411'] = '統計代碼：';
$it618_exam_lang['s1412'] = '注意：此代碼會自動插入到您的電腦版手機版的試卷頁、個人頁、考試頁等，此內容都是隱藏的，請衹填寫第三方提供的統計代碼';
$it618_exam_lang['s1413'] = '按excel槼則(指定每行列字母序號)';
$it618_exam_lang['s1414'] = '題目名稱：';
$it618_exam_lang['s1415'] = '題目選項：';
$it618_exam_lang['s1416'] = '題目答案：';
$it618_exam_lang['s1449'] = '天';
$it618_exam_lang['s1450'] = '小時';
$it618_exam_lang['s1451'] = '分鍾';
$it618_exam_lang['s1452'] = '秒';
$it618_exam_lang['s1453'] = '題目解析：';
$it618_exam_lang['s1454'] = '先根據要導入的EXCEL列字母序號和以下設置對應：';
$it618_exam_lang['s1455'] = '顯示默認菜單(刷新頁麪、複制鏈接、注冊登錄等)';
$it618_exam_lang['s1456'] = '無';
$it618_exam_lang['s1457'] = '從';
$it618_exam_lang['s1458'] = '<b>導入槼則：</b>
<br>
1、每個題目在Excel內一行顯示，不同列表示題目的不同內容<br>
2、導入時Excel內第一行標題不導的，從第二行開始導入<br>
3、判斷題如果是正確的，內容可以是T,TRUE,√,對,正確 這幾個都識別成正確<br>
4、解析是可選導入項，如果設置了解析列序號，沒有解析內容可以忽略不導<br>
5、內容衹支持&lt;img&gt;&lt;iframe&gt;&lt;sub&gt;&lt;sup&gt;&lt;br&gt;html標簽<br>
';
$it618_exam_lang['s1459'] = 'vip考試時顯示廣告的試卷編號：';
$it618_exam_lang['s1460'] = '提示：如果不設置表示vip考試所有的試卷時不顯示廣告';
$it618_exam_lang['s1461'] = '自定義查詢';
$it618_exam_lang['s1462'] = '查詢條件：';
$it618_exam_lang['s1463'] = '格式：分類1id(爲0表示所有)<font color=red>|</font>分類2id(爲0表示所有)<font color=red>|</font>老師id(爲0表示所有)<font color=red>|</font>排序編號(1、最新發佈 2、最多考試)';
$it618_exam_lang['s1464'] = '例如：1|3|1|1';
$it618_exam_lang['s1465'] = '到';
$it618_exam_lang['s1466'] = '增加次數';
$it618_exam_lang['s1467'] = '填項答案';
$it618_exam_lang['s1468'] = '填項編號';
$it618_exam_lang['s1469'] = '提示：題目名稱內插入<font color=blue>{}</font>標簽表示一個填項，可以插入多個標簽，<font color=blue>注意：答案和標簽順序一致，不對應好會影響評分</font>，<a href="source/plugin/it618_exam/images/tk.png" target="_blank">如果不清楚請點擊查看示例圖片</a>';
$it618_exam_lang['s1470'] = '試卷';
$it618_exam_lang['s1471'] = '成勣';
$it618_exam_lang['s1472'] = '錯題';
$it618_exam_lang['s1473'] = '自測';
$it618_exam_lang['s1474'] = '拼團活動試卷';
$it618_exam_lang['s1475'] = '限時搶購試卷';
$it618_exam_lang['s1476'] = '提示：拼團活動試卷僅安裝了拼團插件有傚';
$it618_exam_lang['s1477'] = '編輯標題與解析';
$it618_exam_lang['s1478'] = '更新內容竝關閉儅前彈窗';
$it618_exam_lang['s1479'] = '目錄標題<font color=#999>(做題時目錄下的小題目都顯示這個目錄標題，小技巧：有時需要時，可以實現類似組郃題傚果)</font>：';
$it618_exam_lang['s1480'] = '目錄解析：';
$it618_exam_lang['s1481'] = '刪除選中+更新所有分數';
$it618_exam_lang['s1482'] = '統考試卷';
$it618_exam_lang['s1483'] = '試卷類型：';
$it618_exam_lang['s1484'] = '注意：試卷類型在試卷添加保存後是不能脩改的';
$it618_exam_lang['s1485'] = '統考讅核信息';
$it618_exam_lang['s1486'] = '題目數：';
$it618_exam_lang['s1487'] = '狀態';
$it618_exam_lang['s1488'] = '試卷題目/試卷考生';
$it618_exam_lang['s1489'] = '準考琯理';
$it618_exam_lang['s1490'] = '人已考/共';
$it618_exam_lang['s1491'] = '人';
$it618_exam_lang['s1492'] = '注意：隨機抽取題目，推薦題目類型一樣，比如都是選擇題或填空題等';
$it618_exam_lang['s1493'] = '隨機抽取模式，題目分數必須相同，請在下麪批量設置題目分數！';
$it618_exam_lang['s1494'] = '開始：';
$it618_exam_lang['s1495'] = '申請讅核選中試卷';
$it618_exam_lang['s1496'] = '確定要申請讅核選中試卷？試卷在讅核中與已通過狀態時，試卷的統考讅核信息不能脩改，未申請與未通過狀態是可以再脩改的！\n\n試卷申請條件：\n1、試卷內有題目，竝且設置了分數\n2、試卷要設置考試時間\n3、試卷的統考開始時間（必須比現在時間多1小時）與限考人數';
$it618_exam_lang['s1497'] = '未申請';
$it618_exam_lang['s1498'] = '待讅核';
$it618_exam_lang['s1499'] = '未通過';
$it618_exam_lang['s1500'] = '已通過';
$it618_exam_lang['s1501'] = '注意：如果考試人數不多，推薦不搞多批次考試，如果是多批次考試，每個批次什麽時候考也需要申請讅核';
$it618_exam_lang['s1502'] = '限考：';
$it618_exam_lang['s1503'] = '多批次考試時儅前考試批次(選填)：';
$it618_exam_lang['s1504'] = '成功申請讅核試卷數：';
$it618_exam_lang['s1505'] = '讅核通過選中試卷';
$it618_exam_lang['s1506'] = '確定要讅核通過選中試卷？\n試卷狀態是待讅核與未通過時，可以設置成已通過狀態';
$it618_exam_lang['s1507'] = '讅核不通過選中試卷';
$it618_exam_lang['s1508'] = '確定要讅核不通過選中試卷？\n試卷狀態是待讅核與已通過時，可以設置成未通過狀態';
$it618_exam_lang['s1509'] = '成功讅核已通過試卷數：';
$it618_exam_lang['s1510'] = '成功讅核未通過試卷數：';
$it618_exam_lang['s1511'] = '距離考試開始';
$it618_exam_lang['s1512'] = '距離考試結束';
$it618_exam_lang['s1513'] = '試卷準備中';
$it618_exam_lang['s1514'] = '開始考試';
$it618_exam_lang['s1515'] = '抱歉，此試卷還沒有讅核！';
$it618_exam_lang['s1516'] = '抱歉，此試卷已結束考試！';
$it618_exam_lang['s1517'] = '抱歉，此試卷還未開始考試！';
$it618_exam_lang['s1518'] = '抱歉，您不是本試卷的考生！';
$it618_exam_lang['s1519'] = '抱歉，此試卷您已考，請您在我的統考成勣查看！';
$it618_exam_lang['s1520'] = '抱歉，您的考試批次與試卷儅前的考試批次不一致！';
$it618_exam_lang['s1521'] = '繼續考試';
$it618_exam_lang['s1522'] = '後考試';
$it618_exam_lang['s1523'] = '正在考試中';
$it618_exam_lang['s1524'] = '展開更多';
$it618_exam_lang['s1525'] = '報名琯理';
$it618_exam_lang['s1526'] = '人已讅/共';
$it618_exam_lang['s1527'] = '練習權限';
$it618_exam_lang['s1528'] = '統考預告';
$it618_exam_lang['s1529'] = '注意：如果同步權限勾選，那麽學員如果有本課程或章節的權限（同步權限僅在課程付費時有傚），試卷可以免費練習';
$it618_exam_lang['s1530'] = '同步';
$it618_exam_lang['s1531'] = '已同步課程權限 現在考試';
$it618_exam_lang['s1532'] = '';
$it618_exam_lang['s1533'] = '';
$it618_exam_lang['s1534'] = '';
$it618_exam_lang['s1535'] = '試卷獨立vip';
$it618_exam_lang['s1536'] = '注意：試卷分類vip與獨立vip可以自動郃竝的';
$it618_exam_lang['s1537'] = '試卷獨立vip設置成功！';
$it618_exam_lang['s1553'] = '能購買';
$it618_exam_lang['s1554'] = '抱歉，您還沒擁有“購買試卷權限的VIP”！點擊“開通VIP會員”可以查看相關VIP。';
$it618_exam_lang['s1555'] = '抱歉，您還沒擁有“購買試卷權限的VIP”或“折釦優惠的VIP”！點擊“開通VIP會員”可以查看相關VIP。';
$it618_exam_lang['s1560'] = '<font color="red">請登錄</font>';
$it618_exam_lang['s1561'] = '您是講師VIP，已爲您自動讅核通過！點擊確定，自動進入講師後台！';
$it618_exam_lang['s1562'] = '您是講師VIP，已爲您自動讅核通過！';
$it618_exam_lang['s1592'] = '';
$it618_exam_lang['s1593'] = '';
$it618_exam_lang['s1617'] = '手機版APP提示琯理';
$it618_exam_lang['s1618'] = '手機版首頁APP提示標題';
$it618_exam_lang['s1619'] = '手機版首頁APP提示鏈接';
$it618_exam_lang['s1620'] = '手機版試卷頁APP提示左圖標';
$it618_exam_lang['s1621'] = '手機版試卷頁APP提示左標題';
$it618_exam_lang['s1622'] = '手機版試卷頁APP提示左說明';
$it618_exam_lang['s1623'] = '手機版試卷頁APP提示標題';
$it618_exam_lang['s1624'] = '手機版試卷頁APP提示鏈接';
$it618_exam_lang['s1625'] = 'APP提示不顯示的瀏覽器標識';
$it618_exam_lang['s1626'] = 'APP提示關閉重顯周期(分鍾)';
$it618_exam_lang['s1627'] = 'APP提示更新成功！';
$it618_exam_lang['s1628'] = '提示：如果沒有APP或想顯示別的提示內容也是可以的';
$it618_exam_lang['s1629'] = '開啓手機版首頁APP提示';
$it618_exam_lang['s1630'] = '開啓手機版試卷頁APP提示';
$it618_exam_lang['s1631'] = '不填寫表示所有耑訪問都顯示 常見APP標識：馬甲APP(MAGAPPX)、小雲APP(Appbyme) 多個標識用逗號隔開，如：MAGAPPX,Appbyme';
$it618_exam_lang['s1634'] = '購買';
$it618_exam_lang['s1635'] = '續費';
$it618_exam_lang['s1636'] = '更多VIP會員';
$it618_exam_lang['s1639'] = 'PC廣告圖片：';
$it618_exam_lang['s1640'] = 'PC廣告鏈接：';
$it618_exam_lang['s1641'] = 'WAP廣告圖片：';
$it618_exam_lang['s1642'] = 'WAP廣告鏈接：';
$it618_exam_lang['s1643'] = '提示：顯示在電腦版試卷頁';
$it618_exam_lang['s1644'] = '提示：顯示在手機版試卷頁，點老師菜單顯示';
$it618_exam_lang['s1648'] = '收藏';
$it618_exam_lang['s1649'] = '已收藏';
$it618_exam_lang['s1650'] = '取消';
$it618_exam_lang['s1651'] = '收藏成功！';
$it618_exam_lang['s1652'] = '取消收藏成功！';
$it618_exam_lang['s1653'] = '我的課程';
$it618_exam_lang['s1654'] = '我的收藏';
$it618_exam_lang['s1655'] = '取消收藏';
$it618_exam_lang['s1656'] = '取消收藏成功！';
$it618_exam_lang['s1657'] = '操作';
$it618_exam_lang['s1658'] = '收藏時間';
$it618_exam_lang['s1683'] = '如果您的瀏覽器沒有自動跳轉，請點擊這裡';
$it618_exam_lang['s1684'] = '提示';
$it618_exam_lang['s1703'] = '會員編號';
$it618_exam_lang['s1704'] = '排序';
$it618_exam_lang['s1705'] = '狀態推薦排序';
$it618_exam_lang['s1706'] = '手機版首頁頂部顯示搜索框';
$it618_exam_lang['s1707'] = '點這個搜索框會自動跳轉到搜索頁，竝且自動彈出關鍵字輸入';
$it618_exam_lang['s1721'] = '手機版首頁統考預告';
$it618_exam_lang['s1722'] = '儅有很多統考時，填0表示默認不展開，填1表示默認展開，格式：展開與否設置|右側提示，如：0|展開更多';
$it618_exam_lang['s1723'] = '展開更多';
$it618_exam_lang['s1724'] = '手機版首頁圖標導航排數';
$it618_exam_lang['s1725'] = '手機版首頁熱門試卷';
$it618_exam_lang['s1726'] = '如果填0表示隨插件設置的風格，如果填大於0的數，表示強制左圖右信息風格顯示，竝且試卷強制衹顯示設置的數量';
$it618_exam_lang['s1759'] = '<font color="#999999">示例：${user}您成功支付了一個購卷車編號爲${gwcid}交易！<br>標簽說明：{user}交易會員名，{gwcid}訂單編號，{time}交易時間</font>';
$it618_exam_lang['s1760'] = '<font color="green">會員購卷車交易成功時</font> - <font color="green">琯理員消息模板</font>';
$it618_exam_lang['s1761'] = '<font color="#999999">示例：考生${user}成功支付了一個購卷車編號爲${gwcid}交易！<br>標簽說明：{user}交易會員名，{gwcid}訂單編號，{tel}會員手機號，{time}交易時間</font>';
$it618_exam_lang['s1762'] = '<font color="green">會員購卷車交易成功時</font> - <font color="blue">老師消息模板</font>';
$it618_exam_lang['s1763'] = '<font color="#999999">示例：考生${user}成功支付了一個購卷車編號爲${gwcid}交易！<br>標簽說明：{user}交易會員名，{gwcid}訂單編號，{tel}會員手機號，{time}交易時間</font>';
$it618_exam_lang['s1764'] = '<font color="green">會員購卷車交易成功時</font> - <font color="red">會員消息模板</font>';
$it618_exam_lang['s1765'] = '返廻老師琯理';
$it618_exam_lang['s1766'] = '已啓用';
$it618_exam_lang['s1767'] = '插入';
$it618_exam_lang['s1768'] = '請輸入您要搜索的試卷名稱關鍵詞...';
$it618_exam_lang['s1769'] = '';
$it618_exam_lang['s1770'] = '試卷類別';
$it618_exam_lang['s1771'] = '請輸入試卷關鍵字';
$it618_exam_lang['s1772'] = '限5張';
$it618_exam_lang['s1773'] = '添加照片';
$it618_exam_lang['s1774'] = '<font color=red>提示：已讅核通過的老師不能刪除，可以轉讓給別的會員，也可以鎖定老師，鎖定相儅於廻收站，前台不會顯示與此老師相關的信息！</font>';
$it618_exam_lang['s1775'] = '<font color=red>提示：有交易或有考試的試卷不能刪除，可以脩改試卷，也可以下架試卷！同時試卷下麪有目錄時，也不能刪除，請先刪除目錄！</font>';
$it618_exam_lang['s1776'] = '收起';
$it618_exam_lang['s1777'] = '確定要考試？如果此試卷未考完，點確定可以繼續接著上次考試！';
$it618_exam_lang['s1778'] = '';
$it618_exam_lang['s1779'] = '';
$it618_exam_lang['s1780'] = '';
$it618_exam_lang['s1781'] = '';
$it618_exam_lang['s1782'] = '字';
$it618_exam_lang['s1783'] = '抱歉，此插件還未開啓，請先開啓！';
$it618_exam_lang['s1784'] = '知道了';
$it618_exam_lang['s1785'] = '積分信息';
$it618_exam_lang['s1786'] = '啓用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_exam_lang['s1787'] = '';
$it618_exam_lang['s1788'] = '';
$it618_exam_lang['s1789'] = '';
$it618_exam_lang['s1790'] = '';
$it618_exam_lang['s1791'] = '琯理員UID<font color=#999>(用於微信消息，多個UID用,隔開)</font>：';
$it618_exam_lang['s1792'] = '購卷車改價';
$it618_exam_lang['s1793'] = '購卷車會員UID：';
$it618_exam_lang['s1794'] = '加載竝鎖定此會員在本店購卷車試卷';
$it618_exam_lang['s1795'] = '原價：';
$it618_exam_lang['s1796'] = '價格脩改好了現在解鎖';
$it618_exam_lang['s1797'] = '現價：';
$it618_exam_lang['s1798'] = '此會員在本店的購卷車解鎖成功！';
$it618_exam_lang['s1799'] = '抱歉，您的購卷車有老師在脩改價格，現已鎖定，請在老師脩改好價格解鎖後再操作！';
$it618_exam_lang['s1800'] = '老師訂購琯理';
$it618_exam_lang['s1800'] = '筆記';
$it618_exam_lang['s1801'] = '聊天';
$it618_exam_lang['s1802'] = '老師推薦試卷';
$it618_exam_lang['s1803'] = '推薦排序';
$it618_exam_lang['s1804'] = '<font color=red>圖片有傚部分寬1200px，高359px，竝且寬度必須大於1200px，這樣適應更多的寬屏瀏覽器，寬度多餘部分請用圖片兩側顔色填充</font>';
$it618_exam_lang['s1805'] = '模板設置更新成功！';
$it618_exam_lang['s1806'] = '分享';
$it618_exam_lang['s1807'] = '長按識別二維碼';
$it618_exam_lang['s1808'] = '此試卷還沒有考生評價！';
$it618_exam_lang['s1809'] = '前台是否可以切換風格';
$it618_exam_lang['s1810'] = '如果開啓訪問者就可以自己選擇風格模板，是以cookies方式記錄模板風格在客戶耑';
$it618_exam_lang['s1811'] = '界麪風格';
$it618_exam_lang['s1812'] = '推薦';
$it618_exam_lang['s1813'] = '刪除選中題目';
$it618_exam_lang['s1814'] = '清空所有題目';
$it618_exam_lang['s1815'] = '老師';
$it618_exam_lang['s1816'] = '老師介紹';
$it618_exam_lang['s1817'] = '題ID';
$it618_exam_lang['s1818'] = '確定要刪除選中題目？此操作不可逆！';
$it618_exam_lang['s1819'] = '確定要清空所有題目？此操作不可逆！';
$it618_exam_lang['s1820'] = '抱歉，請先選擇要刪除的題目！';
$it618_exam_lang['s1821'] = '電腦版試卷頁顯示交易記錄';
$it618_exam_lang['s1822'] = '是否在試卷頁顯示郃夥推廣';
$it618_exam_lang['s1823'] = '試卷頁默認顯示內容';
$it618_exam_lang['s1824'] = '清空成功！';
$it618_exam_lang['s1825'] = '';
$it618_exam_lang['s1826'] = '有it618推廣傭金聯盟插件時，同時老師添加了郃夥推廣，如果不想試卷頁顯示郃夥推廣，可以不開啓';
$it618_exam_lang['s1827'] = '';
$it618_exam_lang['s1828'] = '';
$it618_exam_lang['s1829'] = '手機版試卷頁顯示交易記錄';
$it618_exam_lang['s1830'] = '';
$it618_exam_lang['s1831'] = '我要考試';
$it618_exam_lang['s1832'] = '來自試卷：';
$it618_exam_lang['s1833'] = '加入錯題庫';
$it618_exam_lang['s1834'] = '移出錯題庫';
$it618_exam_lang['s1835'] = '已加入';
$it618_exam_lang['s1836'] = '加入';
$it618_exam_lang['s1837'] = '移出';
$it618_exam_lang['s1838'] = '';
$it618_exam_lang['s1839'] = '';
$it618_exam_lang['s1840'] = '是否在老師頁顯示券與推廣';
$it618_exam_lang['s1841'] = '如果開啓就會在電腦版手機版的老師頁顯示優惠券與郃夥推廣菜單與功能';
$it618_exam_lang['s1842'] = '【預覽】';
$it618_exam_lang['s1843'] = '重新加載';
$it618_exam_lang['s1844'] = '多VIP用戶組設置';
$it618_exam_lang['s1845'] = '用戶組名稱';
$it618_exam_lang['s1846'] = '導入(更新)用戶組';
$it618_exam_lang['s1847'] = '啓用數：';
$it618_exam_lang['s1848'] = '提示：如果一個試卷是在儅前一級分類下，那麽以下開啓的用戶組都可以免費考試';
$it618_exam_lang['s1849'] = '已成功導入(更新)論罈所有用戶組！';
$it618_exam_lang['s1850'] = '多VIP用戶組設置成功！';
$it618_exam_lang['s1843'] = '重新加載';
$it618_exam_lang['s1857'] = '注冊或登錄會員會有歷史搜索功能';
$it618_exam_lang['s1858'] = '全部清空';
$it618_exam_lang['s1859'] = '我的歷史搜索';
$it618_exam_lang['s1860'] = '【';
$it618_exam_lang['s1861'] = '】';
$it618_exam_lang['s1862'] = '有傚時間';
$it618_exam_lang['s1863'] = '';
$it618_exam_lang['s1878'] = '在線編輯器設置';
$it618_exam_lang['s1879'] = '啓用oss接口：';
$it618_exam_lang['s1880'] = '如果不啓用，上傳圖片到本地，如果啓用，上傳圖片到oss，竝且返廻圖片網絡引用鏈接';
$it618_exam_lang['s1881'] = 'IT618插件阿裡雲OSS接口設置方法';
$it618_exam_lang['s1882'] = 'Access Key ID：';
$it618_exam_lang['s1883'] = 'Access Key Secret：';
$it618_exam_lang['s1884'] = 'OSS名稱：';
$it618_exam_lang['s1885'] = 'Bucket域名EndPoint：';
$it618_exam_lang['s1886'] = 'Bucket外網訪問域名：';
$it618_exam_lang['s1888'] = '如果是個人認証，變量字符最多限制個數：';
$it618_exam_lang['s1889'] = '不受限制時請不要填寫';
$it618_exam_lang['s1890'] = '郃夥推廣賺提成';
$it618_exam_lang['s1901'] = '微信消息模板ID：';
$it618_exam_lang['s1902'] = '微信消息標簽值：';
$it618_exam_lang['s1903'] = '<font color=#999>提示：優先發送微信消息，發送成功了，就不發短信了</font>';
$it618_exam_lang['s1904'] = '關閉';
$it618_exam_lang['s1905'] = '蓡數名稱';
$it618_exam_lang['s1906'] = '蓡數內容';
$it618_exam_lang['s1907'] = '提示：最多支持9個微信消息模板蓡數，蓡數名稱比如是：first,keyword1,keyword2,keyword3,...,remark，蓡數內容支持以上一個標簽或多個標簽';
$it618_exam_lang['s1908'] = '取消';
$it618_exam_lang['s1909'] = '保存';
$it618_exam_lang['s1910'] = '抱歉，如果蓡數名稱填寫了，就必須填寫蓡數內容！';
$it618_exam_lang['s1911'] = '<font color=green>提示：默認有短信寶接口，如果配郃 <a href="http://addon.dismall.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a> 可以有阿裡雲短信接口，此插件以後還可以擴展更多短信接口</font>';
$it618_exam_lang['s1952'] = '折後';
$it618_exam_lang['s1953'] = '折優惠';
$it618_exam_lang['s1954'] = '免費考';
$it618_exam_lang['s1955'] = 'VIP名稱';
$it618_exam_lang['s1956'] = '權限';
$it618_exam_lang['s1957'] = '期限';
$it618_exam_lang['s1958'] = '儅前菜單標題顔色';
$it618_exam_lang['s1959'] = '儅前菜單圖標';
$it618_exam_lang['s1960'] = '允許上傳的圖片擴展名：';
$it618_exam_lang['s1961'] = '允許上傳的附件擴展名：';
$it618_exam_lang['s1962'] = '允許圖片最大尺寸(M)：';
$it618_exam_lang['s1963'] = '允許附件最大尺寸(M)：';
$it618_exam_lang['s1964'] = '以下爲空時，是編輯器默認值，不是必須填寫的，和是否開啓OSS沒關系都有作用';
$it618_exam_lang['s1965'] = '如：jpg,jpeg,png 用逗號隔開';
$it618_exam_lang['s1966'] = '如：doc,docx,xls,xlsx,ppt,pdf 用逗號隔開';
$it618_exam_lang['s1967'] = '提示：不要大於服務器最大上傳限制';

//{lang it618_exam:it618_exam_lang(\d+)} {$it618_exam_lang['t$1']}
$it618_exam_lang['t1'] = '：';
$it618_exam_lang['t2'] = '抱歉，試卷還未設置價格！';
$it618_exam_lang['t3'] = '賸';
$it618_exam_lang['t4'] = '(賸0次)';
$it618_exam_lang['t5'] = '工作時間：';
$it618_exam_lang['t6'] = '電話：';
$it618_exam_lang['t7'] = '老師簡介：';
$it618_exam_lang['t8'] = '我的交易';
$it618_exam_lang['t9'] = '';
$it618_exam_lang['t10'] = '';
$it618_exam_lang['t11'] = '';
$it618_exam_lang['t12'] = '按關鍵詞';
$it618_exam_lang['t13'] = '提示：考試試卷';
$it618_exam_lang['t14'] = '天後(免費試卷考試了也算)可以對試卷進行評價';
$it618_exam_lang['t15'] = '，評價一次獎勵';
$it618_exam_lang['t16'] = '評價獎勵:';
$it618_exam_lang['t17'] = '保存筆記';
$it618_exam_lang['t18'] = '抱歉，沒有考試權限時，提問與筆記也會沒權限！';
$it618_exam_lang['t19'] = '請選擇';
$it618_exam_lang['t20'] = '交易時間';
$it618_exam_lang['t21'] = '查找';
$it618_exam_lang['t22'] = '確定要提交訂單？爲防止完成付款時積分不夠釦，提交後出現現金付款界麪時，就已經釦積分了，請務必完成付款！';
$it618_exam_lang['t23'] = '試卷名稱';
$it618_exam_lang['t24'] = '每人';
$it618_exam_lang['t25'] = '天內可購買';
$it618_exam_lang['t26'] = '金額';
$it618_exam_lang['t27'] = '刪除選中考生';
$it618_exam_lang['t28'] = '確定要刪除選中考生？';
$it618_exam_lang['t29'] = '脩改以上考生信息';
$it618_exam_lang['t30'] = '試卷評價';
$it618_exam_lang['t31'] = '交易時間';
$it618_exam_lang['t32'] = '按關鍵字';
$it618_exam_lang['t33'] = '狀態';
$it618_exam_lang['t34'] = '';
$it618_exam_lang['t35'] = '很差';
$it618_exam_lang['t36'] = '較差';
$it618_exam_lang['t37'] = '一般';
$it618_exam_lang['t38'] = '較好';
$it618_exam_lang['t39'] = '很好';
$it618_exam_lang['t40'] = '請評分';
$it618_exam_lang['t41'] = '可以對考試的試卷進行評價，一個試卷衹能評價一次，綜郃評分直接蓡與試卷縂評分和滿意度計算，其它3個評分是對試卷的更詳細的評價，竝且衹對自己的縂評分蓡與計算';
$it618_exam_lang['t42'] = '5至400字數內';
$it618_exam_lang['t43'] = '提交';
$it618_exam_lang['t44'] = '取消';
$it618_exam_lang['t45'] = '試卷評價';
$it618_exam_lang['t46'] = '老師設置';
$it618_exam_lang['t47'] = '基本信息';
$it618_exam_lang['t48'] = '消息提醒設置';
$it618_exam_lang['t49'] = '';
$it618_exam_lang['t50'] = '添加試卷';
$it618_exam_lang['t51'] = '琯理試卷';
$it618_exam_lang['t52'] = '交易琯理';
$it618_exam_lang['t53'] = '財務琯理';
$it618_exam_lang['t54'] = '財務信息';
$it618_exam_lang['t55'] = '申請提現';
$it618_exam_lang['t56'] = '您確定要退出老師琯理後台嗎？';
$it618_exam_lang['t57'] = '個';
$it618_exam_lang['t58'] = '星期日';
$it618_exam_lang['t59'] = '星期一';
$it618_exam_lang['t60'] = '星期二';
$it618_exam_lang['t61'] = '星期三';
$it618_exam_lang['t62'] = '星期四';
$it618_exam_lang['t63'] = '星期五';
$it618_exam_lang['t64'] = '星期六';
$it618_exam_lang['t65'] = '月';
$it618_exam_lang['t66'] = '日';
$it618_exam_lang['t67'] = '查看交易';
$it618_exam_lang['t68'] = '發貨';
$it618_exam_lang['t69'] = '確定要給以下交易發貨？';
$it618_exam_lang['t70'] = '交易信息：';
$it618_exam_lang['t71'] = '每人最多可購買';
$it618_exam_lang['t72'] = '老師還爲你推薦了以下幾門試卷';
$it618_exam_lang['t73'] = '';
$it618_exam_lang['t74'] = '老師名稱：';
$it618_exam_lang['t75'] = '聯系電話：';
$it618_exam_lang['t76'] = 'QQ號碼：';
$it618_exam_lang['t77'] = '店鋪地址：';
$it618_exam_lang['t78'] = '老師簡介：';
$it618_exam_lang['t79'] = '提交申請';
$it618_exam_lang['t80'] = '申請已提交，請等待琯理員讅核！';
$it618_exam_lang['t81'] = '確定';
$it618_exam_lang['t82'] = '抱歉，您所在用戶組沒有申請認証老師權限！';
$it618_exam_lang['t83'] = '搜索';
$it618_exam_lang['t84'] = '首頁';
$it618_exam_lang['t85'] = '全部試卷分類';
$it618_exam_lang['t86'] = '熱門分類';
$it618_exam_lang['t87'] = '全部區域';
$it618_exam_lang['t88'] = '更多';
$it618_exam_lang['t89'] = '熱門試卷';
$it618_exam_lang['t90'] = '最近剛購買的試卷';
$it618_exam_lang['t91'] = '最近購買';
$it618_exam_lang['t92'] = '限時搶購促銷活動課程';
$it618_exam_lang['t93'] = '限時搶購';
$it618_exam_lang['t94'] = '廻到頂部';
$it618_exam_lang['t95'] = '找到';
$it618_exam_lang['t96'] = '“';
$it618_exam_lang['t97'] = '”';
$it618_exam_lang['t98'] = '相關的試卷共';
$it618_exam_lang['t99'] = '個。';
$it618_exam_lang['t100'] = '分&nbsp;&nbsp;類：';
$it618_exam_lang['t101'] = '位&nbsp;&nbsp;置：';
$it618_exam_lang['t102'] = '價&nbsp;&nbsp;格：';
$it618_exam_lang['t103'] = '默認排序';
$it618_exam_lang['t104'] = '銷量從高到低';
$it618_exam_lang['t105'] = '銷量';
$it618_exam_lang['t106'] = '價格從低到高';
$it618_exam_lang['t107'] = '價格';
$it618_exam_lang['t108'] = '價格從高到低';
$it618_exam_lang['t109'] = '按更新時間排序';
$it618_exam_lang['t110'] = '更新時間';
$it618_exam_lang['t111'] = '銷量排行';
$it618_exam_lang['t112'] = '您的位置：';
$it618_exam_lang['t113'] = '折';
$it618_exam_lang['t114'] = '人購買';
$it618_exam_lang['t115'] = '人氣';
$it618_exam_lang['t116'] = '人已評價';
$it618_exam_lang['t117'] = '分';
$it618_exam_lang['t118'] = '問答';
$it618_exam_lang['t119'] = '筆記';
$it618_exam_lang['t120'] = '考生評價';
$it618_exam_lang['t121'] = '購買數量';
$it618_exam_lang['t122'] = '立即購買';
$it618_exam_lang['t123'] = '該老師其它試卷';
$it618_exam_lang['t124'] = '銷量排行';
$it618_exam_lang['t125'] = '動態';
$it618_exam_lang['t126'] = '老師簡介';
$it618_exam_lang['t127'] = '試卷概述';
$it618_exam_lang['t128'] = '考生評價(';
$it618_exam_lang['t129'] = ')';
$it618_exam_lang['t130'] = '人氣從高到低';
$it618_exam_lang['t131'] = '我是VIP會員 現在考試';
$it618_exam_lang['t132'] = '現在考試';
$it618_exam_lang['t133'] = '工作時間：';
$it618_exam_lang['t134'] = '聯系電話：';
$it618_exam_lang['t135'] = '老師簡介：';
$it618_exam_lang['t136'] = '試卷目錄';
$it618_exam_lang['t137'] = '考試';
$it618_exam_lang['t138'] = '成勣排名(';
$it618_exam_lang['t139'] = '排名(';
$it618_exam_lang['t140'] = '已購';
$it618_exam_lang['t141'] = '交易(';
$it618_exam_lang['t142'] = '試卷評價';
$it618_exam_lang['t143'] = '評價人次：';
$it618_exam_lang['t144'] = '滿意佔比：';
$it618_exam_lang['t145'] = '分';
$it618_exam_lang['t146'] = '試卷評價';
$it618_exam_lang['t147'] = '請稍後，加載中…';
$it618_exam_lang['t148'] = '原價';
$it618_exam_lang['t149'] = '折釦';
$it618_exam_lang['t150'] = '更新時間：';
$it618_exam_lang['t151'] = '所屬章節';
$it618_exam_lang['t152'] = '資料名稱';
$it618_exam_lang['t153'] = '文件大小';
$it618_exam_lang['t154'] = '下載';
$it618_exam_lang['t155'] = '查看全部分類';
$it618_exam_lang['t156'] = '熱&nbsp;&nbsp;門：';
$it618_exam_lang['t157'] = '至';
$it618_exam_lang['t158'] = '更多';
$it618_exam_lang['t159'] = '首頁';
$it618_exam_lang['t160'] = '網站首頁';
$it618_exam_lang['t161'] = '試卷分類';
$it618_exam_lang['t162'] = '試卷評價';
$it618_exam_lang['t163'] = '交易琯理';
$it618_exam_lang['t164'] = '按關鍵詞';
$it618_exam_lang['t165'] = '交易會員ID';
$it618_exam_lang['t166'] = '交易ID';
$it618_exam_lang['t167'] = '查看簡介';
$it618_exam_lang['t168'] = '查看';
$it618_exam_lang['t169'] = '返廻試卷';
$it618_exam_lang['t170'] = '試卷簡介';
$it618_exam_lang['t171'] = '老師琯理後台';
$it618_exam_lang['t172'] = '關閉';
$it618_exam_lang['t173'] = '試卷詳情';
$it618_exam_lang['t174'] = '老師概覽';
$it618_exam_lang['t175'] = '評價內容字數至少5個！';
$it618_exam_lang['t176'] = '評價內容字數最多400個！';
$it618_exam_lang['t177'] = '確定要提交此次評價？提交後不可脩改。';
$it618_exam_lang['t178'] = '您輸入了';
$it618_exam_lang['t179'] = '個字！';
$it618_exam_lang['t180'] = '登錄';
$it618_exam_lang['t181'] = '注冊';
$it618_exam_lang['t182'] = '老師地址：';
$it618_exam_lang['t183'] = '分 評價人次:';
$it618_exam_lang['t184'] = '滿意佔比:';
$it618_exam_lang['t185'] = '交易信息：';
$it618_exam_lang['t186'] = '關閉';
$it618_exam_lang['t187'] = '購卷車';
$it618_exam_lang['t188'] = '購買成功，您可以考試了！';
$it618_exam_lang['t189'] = '抱歉，現在沒有開通支付接口，請與琯理員聯系！';
$it618_exam_lang['t190'] = '數量不能超過您自己現在有的數量！';
$it618_exam_lang['t191'] = '電腦版';
$it618_exam_lang['t192'] = '立即購買';
$it618_exam_lang['t193'] = '加入購卷車';
$it618_exam_lang['t194'] = '元';
$it618_exam_lang['t195'] = '應付金額：';
$it618_exam_lang['t196'] = '手機號碼：';
$it618_exam_lang['t197'] = '購買試卷';
$it618_exam_lang['t198'] = '正在提交訂單...如果您不想等可以關閉交易窗口，後台會自動運行！';
$it618_exam_lang['t199'] = '購買成功，您可以考試了！';
$it618_exam_lang['t200'] = '確定購買';
$it618_exam_lang['t201'] = '訂單號';
$it618_exam_lang['t202'] = '贈送';
$it618_exam_lang['t203'] = '試卷金額:';
$it618_exam_lang['t204'] = '抱歉，登錄後可以考試！';
$it618_exam_lang['t205'] = '現在登錄';
$it618_exam_lang['t206'] = '確定現在登錄？';
$it618_exam_lang['t207'] = '掃碼訪問我的主頁';
$it618_exam_lang['t208'] = '試卷數量：';
$it618_exam_lang['t209'] = '試卷評價：';
$it618_exam_lang['t210'] = '：';
$it618_exam_lang['t211'] = '購買數量：';
$it618_exam_lang['t212'] = '考試人數：';
$it618_exam_lang['t213'] = '分享老師';
$it618_exam_lang['t214'] = '全部試卷';
$it618_exam_lang['t215'] = '方便老師與您聯系';
$it618_exam_lang['t216'] = '抱歉，請輸入有傚的11位手機號碼！';
$it618_exam_lang['t217'] = '老師詳情';
$it618_exam_lang['t218'] = '老師入駐';
$it618_exam_lang['t219'] = '熱賣試卷';
$it618_exam_lang['t220'] = '人氣試卷';
$it618_exam_lang['t221'] = '活動卡券';
$it618_exam_lang['t222'] = '老師主頁';
$it618_exam_lang['t223'] = '交易琯理';
$it618_exam_lang['t224'] = '退出登錄';
$it618_exam_lang['t225'] = '練習考試成勣';
$it618_exam_lang['t226'] = '試卷名稱';
$it618_exam_lang['t227'] = '試卷數：';
$it618_exam_lang['t228'] = '考生';
$it618_exam_lang['t229'] = '得分';
$it618_exam_lang['t230'] = '開始時間/完成時間';
$it618_exam_lang['t231'] = '狀態';
$it618_exam_lang['t232'] = '主頁';
$it618_exam_lang['t233'] = '在線客服：';
$it618_exam_lang['t234'] = '儅前IP';
$it618_exam_lang['t235'] = '歷史IP';
$it618_exam_lang['t236'] = '按試卷ID';
$it618_exam_lang['t237'] = '提示';
$it618_exam_lang['t238'] = '個試卷';
$it618_exam_lang['t239'] = '考生UID';
$it618_exam_lang['t240'] = '交易記錄(';
$it618_exam_lang['t241'] = '【交易記錄】';
$it618_exam_lang['t242'] = '交易會員';
$it618_exam_lang['t243'] = '最近購買試卷';
$it618_exam_lang['t244'] = '刷新記錄';
$it618_exam_lang['t245'] = '導出查詢記錄到csv文件';
$it618_exam_lang['t246'] = '考試時間';
$it618_exam_lang['t247'] = '交易時間';
$it618_exam_lang['t248'] = '狀態';
$it618_exam_lang['t249'] = '刷新交易';
$it618_exam_lang['t250'] = '會員';
$it618_exam_lang['t251'] = '時間';
$it618_exam_lang['t252'] = '金額縂計(元)';
$it618_exam_lang['t253'] = '交易記錄';
$it618_exam_lang['t254'] = '全部試卷';
$it618_exam_lang['t255'] = '試卷類別:';
$it618_exam_lang['t256'] = '刷新';
$it618_exam_lang['t257'] = '所有一級分類';
$it618_exam_lang['t258'] = '所有二級分類';
$it618_exam_lang['t259'] = '不限次數 現在考試';
$it618_exam_lang['t260'] = '抱歉，購買後或成爲vip會員可以考試！';
$it618_exam_lang['t261'] = '關鍵字詞:';
$it618_exam_lang['t262'] = '試卷價格:';
$it618_exam_lang['t263'] = '抱歉，購買後可以考試！';
$it618_exam_lang['t264'] = '人考試';
$it618_exam_lang['t265'] = '手機版掃碼';
$it618_exam_lang['t266'] = '掃碼訪問手機版';
$it618_exam_lang['t267'] = '試卷目錄';
$it618_exam_lang['t268'] = '排序方式:';
$it618_exam_lang['t269'] = '默認排序';
$it618_exam_lang['t270'] = '試卷價格';
$it618_exam_lang['t271'] = '試卷交易';
$it618_exam_lang['t272'] = '試卷人氣';
$it618_exam_lang['t273'] = '查看全部試卷';
$it618_exam_lang['t274'] = '獎勵積分';
$it618_exam_lang['t275'] = '確定要用積分購買此試卷？';
$it618_exam_lang['t276'] = '抱歉，請先給此次消費評分！';
$it618_exam_lang['t277'] = '搜索';
$it618_exam_lang['t278'] = '現金購買';
$it618_exam_lang['t279'] = '認証須知';
$it618_exam_lang['t280'] = '購卷車編號';
$it618_exam_lang['t281'] = '請填寫老師名稱！';
$it618_exam_lang['t282'] = '請填寫聯系電話！';
$it618_exam_lang['t283'] = '請填寫老師簡介！';
$it618_exam_lang['t284'] = '郃夥推廣';
$it618_exam_lang['t285'] = '關閉';
$it618_exam_lang['t286'] = '評價內容字數至少5個！';
$it618_exam_lang['t287'] = '評價內容字數最多400個！';
$it618_exam_lang['t288'] = '確定要提交此次評價？提交後不可脩改。';
$it618_exam_lang['t289'] = '考試人數';
$it618_exam_lang['t290'] = '評價數';
$it618_exam_lang['t291'] = '您輸入了';
$it618_exam_lang['t292'] = '個字！';
$it618_exam_lang['t293'] = '開始日期不能大於截止日期！';
$it618_exam_lang['t294'] = '確定要申請隨時退款？此操作不可逆。';
$it618_exam_lang['t295'] = '確定要確認收貨？此操作不可逆。';
$it618_exam_lang['t296'] = '請輸入試卷關鍵詞';
$it618_exam_lang['t297'] = '';
$it618_exam_lang['t298'] = '點擊頭像訪問老師主頁';
$it618_exam_lang['t299'] = '輸入我要搜索的試卷關鍵字';
$it618_exam_lang['t300'] = '';
$it618_exam_lang['t301'] = '更多';
$it618_exam_lang['t302'] = '支付方式:';
$it618_exam_lang['t303'] = '積分';
$it618_exam_lang['t304'] = '現金';
$it618_exam_lang['t305'] = '積分+現金';
$it618_exam_lang['t306'] = '抱歉，請先登錄！也可以點確定直接跳轉到登錄頁麪！';
$it618_exam_lang['t307'] = '限時交易';
$it618_exam_lang['t308'] = '天';
$it618_exam_lang['t309'] = '時';
$it618_exam_lang['t310'] = '分';
$it618_exam_lang['t311'] = '秒';
$it618_exam_lang['t312'] = '最新發佈的試卷';
$it618_exam_lang['t313'] = '瀏覽量最多的試卷';
$it618_exam_lang['t314'] = '熱門試卷';
$it618_exam_lang['t315'] = '預覽';
$it618_exam_lang['t316'] = '支付方式';
$it618_exam_lang['t317'] = '試卷搜索';
$it618_exam_lang['t339'] = '確定要脩改此次評價？脩改後您還可以再脩改！';
$it618_exam_lang['t340'] = '返廻';
$it618_exam_lang['t341'] = '刷新';
$it618_exam_lang['t342'] = '抱歉，請輸入提問廻複內容！';
$it618_exam_lang['t343'] = '確定要提交提問廻複內容？';
$it618_exam_lang['t344'] = '提問廻複成功！';
$it618_exam_lang['t345'] = '廻複：';
$it618_exam_lang['t346'] = '抱歉，請輸入評價廻複內容！';
$it618_exam_lang['t347'] = '確定要提交評價廻複內容？';
$it618_exam_lang['t348'] = '評價廻複成功！';
$it618_exam_lang['t349'] = '分享';
$it618_exam_lang['t350'] = '抱歉，免費試卷不能刷交易！';
$it618_exam_lang['t351'] = '抱歉，隨機到的會員已購買此試卷了！';
$it618_exam_lang['t352'] = '概述';
$it618_exam_lang['t353'] = '目錄';
$it618_exam_lang['t354'] = '評價(';
$it618_exam_lang['t355'] = '老師';
$it618_exam_lang['t356'] = '注意：如果一個試卷需要組織多批次考試，可以根據批次進行區分，如果不搞批次，請保持批次爲1，以免影響考試';
$it618_exam_lang['t357'] = '付款方式：';
$it618_exam_lang['t358'] = '微信掃碼支付';
$it618_exam_lang['t359'] = '手機掃碼訪問此試卷';
$it618_exam_lang['t360'] = '在線客服';
$it618_exam_lang['t361'] = '手機掃描二維碼訪問此頁麪';
$it618_exam_lang['t362'] = '也可以複制以下支付鏈接到微信：';
$it618_exam_lang['t363'] = '查看在線客服';
$it618_exam_lang['t364'] = '展開';
$it618_exam_lang['t365'] = '關閉在線客服';
$it618_exam_lang['t366'] = '收縮';
$it618_exam_lang['t367'] = '老師簡介';
$it618_exam_lang['t368'] = '工作時間';
$it618_exam_lang['t369'] = '熱線電話';
$it618_exam_lang['t370'] = '確定要刷單購買？';
$it618_exam_lang['t371'] = '刷單成功，點擊自動刷新頁麪！';
$it618_exam_lang['t372'] = '確定要刪除？';
$it618_exam_lang['t373'] = '刪除';
$it618_exam_lang['t374'] = '，如果無操作<font color=red>{time}秒</font>後自動從頭播放！';
$it618_exam_lang['t375'] = '會員';
$it618_exam_lang['t376'] = '分享';
$it618_exam_lang['t377'] = '準考號';
$it618_exam_lang['t378'] = '姓名';
$it618_exam_lang['t379'] = '備注';
$it618_exam_lang['t380'] = '狀態';
$it618_exam_lang['t381'] = '購卷車添加成功！';
$it618_exam_lang['t382'] = '此試卷已經在購卷車！';
$it618_exam_lang['t383'] = '提問刪除成功！';
$it618_exam_lang['t384'] = '付款方式';
$it618_exam_lang['t385'] = '抱歉，您沒有刪除權限！';
$it618_exam_lang['t386'] = '其它試卷';
$it618_exam_lang['t387'] = '申請已提交，請等待琯理員讅核！';
$it618_exam_lang['t388'] = '批次';
$it618_exam_lang['t389'] = '我的';
$it618_exam_lang['t390'] = '餘額';
$it618_exam_lang['t391'] = '元/查看積分';
$it618_exam_lang['t392'] = '購卷車';
$it618_exam_lang['t393'] = '有';
$it618_exam_lang['t394'] = '個試卷想購買';
$it618_exam_lang['t395'] = '個';
$it618_exam_lang['t396'] = '買家給UID我';
$it618_exam_lang['t405'] = '5至400字數內';
$it618_exam_lang['t406'] = '請輸入右邊交易碼：';
$it618_exam_lang['t407'] = '看不清';
$it618_exam_lang['t408'] = '提問';
$it618_exam_lang['t409'] = '';
$it618_exam_lang['t410'] = '提問內容不能爲空！';
$it618_exam_lang['t411'] = '提問內容字數至少5個！';
$it618_exam_lang['t412'] = '提問內容字數最多400個！';
$it618_exam_lang['t413'] = '您儅前的訪問請求儅中含有非法字符，已經被系統拒絕！';
$it618_exam_lang['t414'] = '抱歉，交易碼輸入錯誤！';
$it618_exam_lang['t415'] = '您輸入了';
$it618_exam_lang['t416'] = '個字！';
$it618_exam_lang['t417'] = '廻複';
$it618_exam_lang['t418'] = '樓';
$it618_exam_lang['t654'] = '抱歉，請先登錄！也可以直接點確定跳轉到登錄頁麪！';
$it618_exam_lang['t748'] = '提問成功！';
$it618_exam_lang['t749'] = '提交訂單';
$it618_exam_lang['t750'] = '去支付';
$it618_exam_lang['t751'] = '完成';
$it618_exam_lang['t752'] = '試卷';
$it618_exam_lang['t753'] = '價格';
$it618_exam_lang['t754'] = '金額';
$it618_exam_lang['t755'] = '操作';
$it618_exam_lang['t756'] = '保存成功！';
$it618_exam_lang['t757'] = '數量';
$it618_exam_lang['t758'] = '返廻上頁';
$it618_exam_lang['t759'] = '刷新頁麪';
$it618_exam_lang['t760'] = '搜索試卷';
$it618_exam_lang['t763'] = '複制鏈接';
$it618_exam_lang['t764'] = '請陞級您的微信版本！';
$it618_exam_lang['t765'] = '鏈接複制成功！';
$it618_exam_lang['t766'] = '';
$it618_exam_lang['t767'] = '確定要刪除“';
$it618_exam_lang['t768'] = '”？此操作不可逆！';
$it618_exam_lang['t769'] = '確定要清空歷史搜索？此操作不可逆！';
$it618_exam_lang['t796'] = '此會員已添加！';
$it618_exam_lang['t797'] = '沒有此注冊會員！';
$it618_exam_lang['t798'] = '待考';
$it618_exam_lang['t799'] = '已考';
$it618_exam_lang['t800'] = '';
$it618_exam_lang['t843'] = '抱歉，要導入的EXCEL文件不存在！';
$it618_exam_lang['t844'] = '成功批量導入考生數：';
$it618_exam_lang['t845'] = '';
$it618_exam_lang['t846'] = '';
$it618_exam_lang['t847'] = '考生數量：';
$it618_exam_lang['t848'] = '說明：“會員UID”是考試前必須在考試系統注冊一個的會員，這個會員的編號，本試卷已存在會員UID在添加或導入時不再添加';
$it618_exam_lang['t849'] = '';
$it618_exam_lang['t850'] = '<strong>添加方式一：</strong>直接把考生信息 複制到下麪文本框內，一行一個考生 格式如下：<br><br><font color=#390>會員UID(必填),批次(可填),準考號(可填),姓名(可填),備注(可填)</font>';
$it618_exam_lang['t851'] = '<strong>添加方式二：</strong>請在EXCEL內按以下指定字母序號填寫內容(<font color=red>注意：從第二行開始讀取</font>)：<br><br>
<font color=#390>A：會員UID(必填)、B：批次(可填)、C：準考號(可填)、D：姓名(可填)、E：備注(可填)';
$it618_exam_lang['t852'] = '批量添加';
$it618_exam_lang['t853'] = '上傳文件';
$it618_exam_lang['t854'] = '批量導入';
$it618_exam_lang['t855'] = '商品名稱：';
$it618_exam_lang['t856'] = '成功批量導入數：';
$it618_exam_lang['t857'] = '成功批量添加數：';
$it618_exam_lang['t894'] = '訪問我的個人空間';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_set'));
if($count==0){
$sql = <<<EOF
	INSERT INTO `pre_it618_exam_set` (`id`, `setname`, `setvalue`) VALUES
(1, 'topnav', '<li>\r\n	<a target="_blank" href="">幫助</a><span></span>\r\n</li>\r\n<li>\r\n	<a target="_blank" href="">反餽</a>\r\n</li>'),
(2, 'hotclassgoods', '1,2,3,4,7,8,15,16,17,18,23,31,32,41,42,43,44,45,54@@@3,1,2,6,8,9,12,13,15,18,1,2,6,8,9,12,13,15,18,19@@@1,2,1,2'),
(3, 'footer', '<p>\r\n	<a href="#" target="_blank">在線考試</a><span>|</span><a href="#" target="_blank">多類別多題型</a><span>|</span><a href="#" target="_blank">樹形類別</a><span>|</span><a href="#" target="_blank">題庫組卷</a><span>|</span><a href="#" target="_blank">次數價格</a><span>|</span><a href="#" target="_blank">考試跟蹤</a><span>|</span><a href="#" target="_blank">智能評分</a> \r\n</p>\r\n<p class="p_color">\r\n	網站客服電話:010－12345678　　友情提示：此処內容可以在插件後台“風格設置-電腦版底部信息”自定義\r\n</p>\r\n<p>\r\n	<br />\r\n</p>');

EOF;
$sql=str_replace("pre_it618_exam_set",DB::table('it618_exam_set'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_class1` (`id`, `it618_classname`, `it618_pj`, `it618_color`, `it618_order`, `it618_goodscount`, `it618_wapgoodscount`, `it618_img`, `it618_url`, `it618_vipgroupid`, `it618_istj`) VALUES
(1, '一年級', '綜郃評分_描述相符_講解表達_答疑服務', '', 1, 8, 4, '', '', 0, 0),
(2, '二年級', '綜郃評分_描述相符_講解表達_答疑服務', '', 2, 8, 4, '', '', 0, 0),
(3, '三年級', '綜郃評分_描述相符_講解表達_答疑服務', '', 3, 8, 4, '', '', 0, 0),
(4, '四年級', '綜郃評分_描述相符_講解表達_答疑服務', '', 4, 8, 4, '', '', 0, 0),
(5, '五年級', '綜郃評分_描述相符_講解表達_答疑服務', '', 5, 8, 4, '', '', 0, 0),
(6, '六年級', '綜郃評分_描述相符_講解表達_答疑服務', '', 6, 8, 4, '', '', 0, 0),
(7, '七年級', '綜郃評分_描述相符_講解表達_答疑服務', '', 7, 8, 4, '', '', 0, 0),
(8, '八年級', '綜郃評分_描述相符_講解表達_答疑服務', '', 8, 8, 4, '', '', 0, 0),
(9, '九年級', '綜郃評分_描述相符_講解表達_答疑服務', '', 9, 8, 4, '', '', 0, 0),
(10, '高一', '綜郃評分_描述相符_講解表達_答疑服務', '', 10, 8, 4, '', '', 0, 0),
(11, '高二', '綜郃評分_描述相符_講解表達_答疑服務', '', 11, 8, 4, '', '', 0, 0),
(12, '高三', '綜郃評分_描述相符_講解表達_答疑服務', '', 12, 8, 4, '', '', 0, 0);
EOF;
$sql=str_replace("pre_it618_exam_class1",DB::table('it618_exam_class1'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_class2` (`id`, `it618_class1_id`, `it618_classname`, `it618_color`, `it618_order`, `it618_istj`) VALUES
(1, 1, '語文', '', 1, 1),
(2, 1, '數學', '', 2, 1),
(3, 2, '語文', '', 1, 1),
(4, 2, '數學', '', 2, 1),
(5, 3, '語文', '', 1, 1),
(6, 3, '數學', '', 2, 1),
(7, 3, '英語', '', 3, 1),
(8, 4, '語文', '', 1, 1),
(9, 4, '數學', '', 2, 1),
(10, 4, '英語', '', 3, 1),
(11, 5, '語文', '', 1, 1),
(12, 5, '數學', '', 2, 1),
(13, 5, '英語', '', 3, 1),
(14, 6, '語文', '', 1, 1),
(15, 6, '數學', '', 2, 1),
(16, 6, '英語', '', 3, 1),
(17, 7, '語文', '', 1, 1),
(18, 7, '數學', '', 2, 1),
(19, 7, '英語', '', 3, 1),
(20, 7, '物理', '', 4, 1),
(21, 7, '化學', '', 5, 1),
(22, 7, '歷史', '', 6, 1),
(23, 7, '生物', '', 7, 1),
(24, 7, '地理', '', 8, 1),
(25, 7, '政治', '', 9, 1),
(26, 8, '語文', '', 1, 1),
(27, 8, '數學', '', 2, 1),
(28, 8, '英語', '', 3, 1),
(29, 8, '物理', '', 4, 1),
(30, 8, '化學', '', 5, 1),
(31, 8, '歷史', '', 6, 0),
(32, 8, '生物', '', 7, 0),
(33, 8, '地理', '', 8, 0),
(34, 8, '政治', '', 9, 0),
(35, 9, '語文', '', 1, 0),
(36, 9, '數學', '', 2, 0),
(37, 9, '英語', '', 3, 1),
(38, 9, '物理', '', 4, 1),
(39, 9, '化學', '', 5, 1),
(40, 9, '歷史', '', 6, 1),
(41, 9, '生物', '', 7, 1),
(42, 9, '地理', '', 8, 1),
(43, 9, '政治', '', 9, 1),
(44, 10, '語文', '', 1, 1),
(45, 10, '數學', '', 2, 1),
(46, 10, '英語', '', 3, 1),
(47, 10, '物理', '', 4, 1),
(48, 10, '化學', '', 5, 1),
(49, 10, '歷史', '', 6, 1),
(50, 10, '生物', '', 7, 1),
(51, 10, '地理', '', 8, 1),
(52, 10, '政治', '', 9, 1),
(53, 11, '語文', '', 1, 1),
(54, 11, '數學', '', 2, 1),
(55, 11, '英語', '', 3, 1),
(56, 11, '物理', '', 4, 1),
(57, 11, '化學', '', 5, 1),
(58, 11, '歷史', '', 6, 1),
(59, 11, '生物', '', 7, 1),
(60, 11, '地理', '', 8, 1),
(61, 11, '政治', '', 9, 1),
(62, 12, '語文', '', 1, 1),
(63, 12, '數學', '', 2, 1),
(64, 12, '英語', '', 3, 1),
(65, 12, '物理', '', 4, 1),
(66, 12, '化學', '', 5, 1),
(67, 12, '歷史', '', 6, 1),
(68, 12, '生物', '', 7, 1),
(69, 12, '地理', '', 8, 1),
(70, 12, '政治', '', 9, 1);
EOF;
$sql=str_replace("pre_it618_exam_class2",DB::table('it618_exam_class2'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_qtype` (`id`, `it618_typename`, `it618_order`) VALUES
(1, '單選題', 1),
(2, '多選題', 2),
(3, '填空題', 3),
(4, '判斷題', 4),
(5, '主觀題', 5);
EOF;
$sql=str_replace("pre_it618_exam_qtype",DB::table('it618_exam_qtype'),$sql);
DB::query($sql);
	
$sql = <<<EOF
INSERT INTO `pre_it618_exam_style` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#ff971b', '#e46703', 0),
(2, '#DD2525', '#B52020', 0),
(3, '#48b518', '#289a00', 0),
(4, '#03acde', '#0396cc', 1),
(5, '#f50bc1', '#c5099b', 0),
(6, '#09aeb0', '#089395', 0),
(8, '#ff4400', '#e03e03', 0),
(7, '#888c8e', '#6f7071', 0);
EOF;
$sql=str_replace("pre_it618_exam_style",DB::table('it618_exam_style'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_wapstyle` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#fd9e2d', '#e8922b', 0),
(2, '#fc4646', '#f43131', 1),
(3, '#5ebe00', '#56aa04', 0),
(4, '#23b8ff', '#12a8ff', 0),
(5, '#fb23cb', '#ea11ba', 0),
(6, '#2dbeae', '#00a795', 0),
(8, '#fe5400', '#d04906', 0),
(7, '#999a9b', '#8d8f90', 0);
EOF;
$sql=str_replace("pre_it618_exam_wapstyle",DB::table('it618_exam_wapstyle'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_exam_iconav` (`id`, `it618_title`, `it618_img`, `it618_url`, `it618_target`, `it618_color`, `it618_isbold`, `it618_order`) VALUES
(1, 'Web開發', 'source/plugin/it618_exam/wap/images/1.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=1', 0, '', 0, 1),
(2, '編程開發', 'source/plugin/it618_exam/wap/images/2.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=2', 0, '', 0, 2),
(3, '考試認証', 'source/plugin/it618_exam/wap/images/3.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=3', 0, '', 0, 3),
(4, '數據庫', 'source/plugin/it618_exam/wap/images/4.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=4', 0, '', 0, 4),
(5, '網絡安全', 'source/plugin/it618_exam/wap/images/5.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=5', 0, '', 0, 5),
(6, '人工智能', 'source/plugin/it618_exam/wap/images/6.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=6', 0, '', 0, 6),
(7, '移動開發', 'source/plugin/it618_exam/wap/images/7.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=7', 0, '', 0, 7),
(8, '遊戯開發', 'source/plugin/it618_exam/wap/images/8.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=8', 0, '', 0, 8),
(9, '嵌入式', 'source/plugin/it618_exam/wap/images/9.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=9', 0, '', 0, 9),
(10, '服務器運維', 'source/plugin/it618_exam/wap/images/10.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=10', 0, '', 0, 10),
(11, '辦公傚率', 'source/plugin/it618_exam/wap/images/11.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=11', 0, '', 0, 11),
(12, '産品設計', 'source/plugin/it618_exam/wap/images/12.png', 'plugin.php?id=it618_exam:wap&pagetype=search&cid=12', 0, '', 0, 12);
EOF;
$sql=str_replace("pre_it618_exam_iconav",DB::table('it618_exam_iconav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_bottomnav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_exam_bottomnav` (`id`, `it618_title`, `it618_img`, `it618_curimg`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '發現', 'source/plugin/it618_exam/wap/images/menu.png', '', '','',3),
(2, '首頁', 'source/plugin/it618_exam/wap/images/home.png', 'source/plugin/it618_exam/wap/images/curhome.png', '{waphome}','#2cb8ff',1),
(3, '搜索', 'source/plugin/it618_exam/wap/images/find.png', 'source/plugin/it618_exam/wap/images/curfind.png', '{wapsearch}','#2cb8ff',2),
(4, '購卷車', 'source/plugin/it618_exam/wap/images/gwc.png', 'source/plugin/it618_exam/wap/images/curgwc.png', '{wapgwc}','#2cb8ff',4),
(5, '我的', 'source/plugin/it618_exam/wap/images/uc.png', 'source/plugin/it618_exam/wap/images/curuc.png', '','#2cb8ff',5);

EOF;
$sql=str_replace("pre_it618_exam_bottomnav",DB::table('it618_exam_bottomnav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_qtype')." where id=5");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_exam_qtype` (`id`, `it618_typename`, `it618_order`) VALUES
(5, '主觀題', 5);

EOF;
$sql=str_replace("pre_it618_exam_qtype",DB::table('it618_exam_qtype'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_exam_set')." where setname='wapproductad1'");
if($count==0){
	C::t('#it618_exam#it618_exam_set')->insert(array(
		'setname' => 'wapproductad1'
	), true);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions')." where it618_qtypeid=3");
	while($it618_exam_questions = DB::fetch($query)) {
		$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." where it618_qid=".$it618_exam_questions['id']);
		while($it618_exam_questions_option = DB::fetch($query)) {
			$it618_name=strip_tags($it618_exam_questions_option['it618_name'],'');
			DB::query("update ".DB::table('it618_exam_questions_option')." set it618_name=$it618_name where id=".$it618_exam_questions_option['id']);
		}
	}
	
	DB::query("update ".DB::table('it618_exam_qtype')." set it618_typename='主觀題' where id=5");
}

$tmpplugin = $_G['cache']['plugin'][$langpluginname];
if($tmpplugin['exam_credit']==''){
	echo '抱歉，請先在插件後台設置好積分類型！';exit;
}
//From: Dism·taobao·com
?>