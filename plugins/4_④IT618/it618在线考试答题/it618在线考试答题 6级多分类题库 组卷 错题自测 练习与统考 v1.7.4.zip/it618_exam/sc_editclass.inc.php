<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

$e3css=';display:none';
if($class_set['classname_e3_ishide']!=1){
	$tmpclass3='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_e3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpclass3.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$e3css=';display:';
}

$e4css=';display:none';
if($class_set['classname_e4_ishide']!=1){
	$tmpclass4='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_e4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpclass4.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$e4css=';display:';
}

$q2css=';display:none';
if($class_set['classname_q2_ishide']!=1){
	$q2css=';display:';
}

$q3css=';display:none';
if($class_set['classname_q3_ishide']!=1){
	$tmpqclass3='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_q3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpqclass3.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$q3css=';display:';
}

$q4css=';display:none';
if($class_set['classname_q4_ishide']!=1){
	$tmpqclass4='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_q4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpqclass4.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$q4css=';display:';
}

$q1btn=str_replace("{qname}",$class_set['classname_q1'],it618_exam_getlang('s1152'));
$q2btn=str_replace("{qname}",$class_set['classname_q2'],it618_exam_getlang('s1152'));
$e3btn=str_replace("{qname}",$class_set['classname_e3'],it618_exam_getlang('s1152'));
$e4btn=str_replace("{qname}",$class_set['classname_e4'],it618_exam_getlang('s1152'));
$q3btn=str_replace("{qname}",$class_set['classname_q3'],it618_exam_getlang('s1152'));
$q4btn=str_replace("{qname}",$class_set['classname_q4'],it618_exam_getlang('s1152'));

$q1about=str_replace("{qname}",$class_set['classname_q1'],it618_exam_getlang('s1153'));
$q2about=str_replace("{qname}",$class_set['classname_q2'],it618_exam_getlang('s1153'));
$e3about=str_replace("{qname}",$class_set['classname_e3'],it618_exam_getlang('s1153'));
$e4about=str_replace("{qname}",$class_set['classname_e4'],it618_exam_getlang('s1153'));
$q3about=str_replace("{qname}",$class_set['classname_q3'],it618_exam_getlang('s1153'));
$q4about=str_replace("{qname}",$class_set['classname_q4'],it618_exam_getlang('s1153'));

echo '
<script charset="utf-8" src="source/plugin/it618_exam/js/Calendar.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/js/jquery.js"></script>
<script type="text/javascript" src="source/plugin/it618_exam/js/layer/layer.js"></script>
';

showtableheaders($it618_exam_lang['s1151'],'it618_exam_questions');

echo '<tr><td colspan=15>
	<form id="it618_exam">
	<input type="hidden" id="qids" name="qids" value="'.$_GET['qids'].'">
	<input type="hidden" id="it618_class1_id" name="it618_class1_id" value="0">
	<input type="hidden" id="it618_class2_id" name="it618_class2_id" value="0">
	<input type="hidden" id="it618_qclass11_id" name="it618_qclass11_id" value="0">
	<input type="hidden" id="it618_qclass12_id" name="it618_qclass12_id" value="0">
	<input type="hidden" id="it618_qclass13_id" name="it618_qclass13_id" value="0">
	<input type="hidden" id="it618_qclass21_id" name="it618_qclass21_id" value="0">
	<input type="hidden" id="it618_qclass22_id" name="it618_qclass22_id" value="0">
	<input type="hidden" id="it618_qclass23_id" name="it618_qclass23_id" value="0">
	<input type="hidden" id="it618_qclass24_id" name="it618_qclass24_id" value="0">
	<input type="hidden" id="it618_qclass25_id" name="it618_qclass25_id" value="0">
	<input type="hidden" id="it618_qclass26_id" name="it618_qclass26_id" value="0">
	
	<div style="padding:10px">
	<input type="button" class="btn" style="width:130px;height:30px;float:right" value="'.$q1btn.'" onclick="saveclass(1,\''.$q1about.'\')" /><input type="text" id="classq1" readonly="readonly" style="width:796px;border:#e8e8e8 1px solid;padding:4px 3px;background-color:#fff" onclick="showclasstree(1)"> <a id="classtreebtn1" href="javascript:" onclick="showclasstree(1)" style="font-size:12px">'.$it618_exam_lang['s1248'].$class_set['classname_q1'].'</a> 
	</div>
	
	<div style="padding:10px'.$q2css.'">
	<input type="button" class="btn" style="width:130px;height:30px;float:right" value="'.$q2btn.'" onclick="saveclass(2,\''.$q2about.'\')" /><input type="text" id="classq2" readonly="readonly" style="width:796px;border:#e8e8e8 1px solid;padding:4px 3px;background-color:#fff" onclick="showclasstree(2)"> <a id="classtreebtn2" href="javascript:" onclick="showclasstree(2)" style="font-size:12px">'.$it618_exam_lang['s1248'].$class_set['classname_q2'].'</a> 
	</div>
	
	<div style="padding:10px'.$e3css.'">
	<input type="button" class="btn" style="width:130px;height:30px;float:right" value="'.$e3btn.'" onclick="saveclass(13,\''.$e3about.'\')" /><select id="it618_class3_id" name="it618_class3_id" style="width:803px">'.$tmpclass3.'</select>
	</div>
	
	<div style="padding:10px'.$e4css.'">
	<input type="button" class="btn" style="width:130px;height:30px;float:right" value="'.$e4btn.'" onclick="saveclass(14,\''.$e4about.'\')" /><select id="it618_class4_id" name="it618_class4_id" style="width:803px">'.$tmpclass4.'</select>
	</div>
	
	<div style="padding:10px'.$q3css.'">
	<input type="button" class="btn" style="width:130px;height:30px;float:right" value="'.$q3btn.'" onclick="saveclass(3,\''.$q3about.'\')" /><select id="it618_qclass3_id" name="it618_qclass3_id" style="width:803px">'.$tmpqclass3.'</select>
	</div>
	
	<div style="padding:10px'.$q4css.'">
	<input type="button" class="btn" style="width:130px;height:30px;float:right" value="'.$q4btn.'" onclick="saveclass(4,\''.$q4about.'\')" /><select id="it618_qclass4_id" name="it618_qclass4_id" style="width:803px">'.$tmpqclass4.'</select>
	</div>
	
	<div id="classtree1" class="classtree" style="display:none;position:absolute;background-color:#f9f9f9;border:#e8e8e8 1px solid;width:520px;height:520px;z-index:1000">
		<iframe id="iframe1" width="100%" height="520" marginwidth="0" marginheight="0" frameborder="no" src="'.$_G['siteurl'].'plugin.php?id=it618_exam:classtree&type=1&cid='.$cid1.'"></iframe>
	</div>
	<div id="classtree2" class="classtree" style="display:none;position:absolute;background-color:#f9f9f9;border:#e8e8e8 1px solid;width:520px;height:520px;z-index:1000">
		<iframe id="iframe2" width="100%" height="520" marginwidth="0" marginheight="0" frameborder="no" src="'.$_G['siteurl'].'plugin.php?id=it618_exam:classtree&type=2&cid='.$cid2.'"></iframe>
	</div>
	</form>

<input type="button" class="btn" style="width:130px;height:30px" value="'.it618_exam_getlang('s1154').'" onclick="saveclass(0,\''.$it618_exam_lang['s1100'].'\')" />
</td></tr>';

showtablefooter(); /*dism��taobao��com*/
echo '
<script>
function saveclass(type,about){
	if(confirm(about)){
		IT618_EXAM.post("'.$_G['siteurl'].'plugin.php?id=it618_exam:ajax&ac=questions_saveclass&type="+type+"&formhash='.FORMHASH.'", IT618_EXAM("#it618_exam").serialize(),function (data, textStatus){
			var tmparr=data.split("it618_split");
			if(tmparr[1]=="ok"){
				alert("'.$it618_exam_lang['s1099'].'");
				parent.getquestions(parent.questionsurl);
				parent.document.getElementById("chkallDx4b").checked=false;
				parent.layer.closeAll();
			}else{
				alert(data);
			}
		}, "html");	
	}
}

function showclasstree(index) {
	var cityObj = $("#classq"+index);
	var cityOffset = $("#classq"+index).offset();

	IT618_EXAM("#classtree"+index).css({left:cityOffset.left + "px", top:cityOffset.top + cityObj.outerHeight() + "px"}).slideDown("fast");
	
	if(index==1){
		IT618_EXAM("body").bind("mousedown", onBodyDown1);
	}else{
		IT618_EXAM("body").bind("mousedown", onBodyDown2);
	}
}

function hideclasstree(index) {
	IT618_EXAM("#classtree"+index).fadeOut("fast");
	if(index==1){
		IT618_EXAM("body").unbind("mousedown", onBodyDown1);
	}else{
		IT618_EXAM("body").unbind("mousedown", onBodyDown2);
	}
}

function onBodyDown1(event) {
	if (!(event.target.id == "classtreebtn1" || event.target.id == "classq1" || event.target.id == "classtree1")) {
		hideclasstree(1);
	}
}

function onBodyDown2(event) {
	if (!(event.target.id == "classtreebtn2" || event.target.id == "classq2" || event.target.id == "classtree2")) {
		hideclasstree(2);
	}
}
</script>
';

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>