<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$lid=intval($_GET['lid']);
$it618_exam_goods_lesson=C::t('#it618_exam#it618_exam_goods_lesson')->fetch_by_id($lid);

if(submitcheck('it618submit')){
	C::t('#it618_exam#it618_exam_goods_lesson')->update($lid,array(
		'it618_name' => it618_exam_strip_tags(trim($_GET['it618_name']),'<img> <iframe> <sub> <sup> <u> <br>'),
		'it618_shareabout' => $_GET['it618_shareabout'],
		'it618_about' => it618_exam_strip_tags(trim($_GET['it618_about']),'<img> <iframe> <sub> <sup> <u> <br>')
	));

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_exam:sc_product_lessonedit$adminsid&lid=$lid");
showtableheaders('','sc_product_lessonedit');

if($it618_exam_goods_lesson['it618_shareabout']==1){
	$it618_shareabout_checked='checked="checked"';
	$aboutcss='';
}else{
	$it618_shareabout_checked="";
	$aboutcss='none';
}

echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/plugins/code/prettify.js"></script>

<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_name"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			minHeight:58,
			newlineTag:"br",
			afterBlur: function () { this.sync(); },
			items : [\'source\', \'|\', \'undo\', \'redo\', \'|\', \'image\',\'multiimage\',\'it618media\', \'|\', \'it618latex\', \'subscript\',
        \'superscript\', \'|\', \'fullscreen\']
		});
		
		var editor2 = K.create(\'textarea[name="it618_about"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			minHeight:58,
			newlineTag:"br",
			afterBlur: function () { this.sync(); },
			items : [\'source\', \'|\', \'undo\', \'redo\', \'|\', \'image\',\'multiimage\',\'it618media\', \'|\', \'it618latex\', \'subscript\',
        \'superscript\', \'|\', \'fullscreen\']
		});
		document.getElementById("spanabout").style.display="'.$aboutcss.'";
	});
	
	function getshareabout(obj){
		if(obj.checked){
			document.getElementById("spanabout").style.display="";
		}else{
			document.getElementById("spanabout").style.display="none";
		}
	}
</script>

<tr><td style="line-height:26px">'.$it618_exam_lang['s1479'].'<br><textarea name="it618_name" style="width:780px;height:210px;visibility:hidden;">'.$it618_exam_goods_lesson['it618_name'].'</textarea></td></tr>
<tr><td><input type="checkbox" id="it618_shareabout" name="it618_shareabout" value=1 style="vertical-align:middle" '.$it618_shareabout_checked.' onchange="getshareabout(this)"><label for="it618_shareabout">'.$it618_exam_lang['s828'].'</label></td></tr>
<tr id="spanabout"><td style="line-height:26px">'.$it618_exam_lang['s1480'].'<br><textarea name="it618_about" style="width:780px;height:210px;visibility:hidden;">'.$it618_exam_goods_lesson['it618_about'].'</textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_exam_getlang('s1478').'" /></div></td></tr>';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>