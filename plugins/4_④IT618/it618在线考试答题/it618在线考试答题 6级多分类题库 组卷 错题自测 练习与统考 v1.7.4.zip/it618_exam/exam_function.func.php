<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];
$metatitle = $it618_exam['seotitle'];
$metakeywords = $it618_exam['seokeywords'];
$metadescription = $it618_exam['seodescription'];
$creditname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

$hotclassgoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('hotclassgoods');
$hotclassgoods=explode('@@@',$hotclassgoods);

if($pagetype=='index'){
	$zjsalegoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('zjsalegoods');
	$weeksalegoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('weeksalegoods');
	$newgoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('newgoods');
	$hotgoods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('hotgoods');
	
	$tmparr=explode(",",$zjsalegoods);
	if(count($tmparr)>2){
		$zjsalegoods_count=$tmparr[0];
		$zjsalegoods_order=$tmparr[2];
	}else{
		$zjsalegoods_count=15;
		$zjsalegoods_order=1;
	}
	
	$tmparr=explode(",",$weeksalegoods);
	if(count($tmparr)>2){
		$weeksalegoods_count=$tmparr[0];
		$weeksalegoods_order=$tmparr[2];
	}else{
		$weeksalegoods_count=15;
		$weeksalegoods_order=2;
	}
	
	$tmparr=explode(",",$newgoods);
	if(count($tmparr)>2){
		$newgoods_count=$tmparr[0];
		$newgoods_order=$tmparr[2];
	}else{
		$newgoods_count=15;
		$newgoods_order=3;
	}
	
	$tmparr=explode(",",$hotgoods);
	if(count($tmparr)>2){
		$hotgoods_count=$tmparr[0];
		$hotgoods_order=$tmparr[2];
	}else{
		$hotgoods_count=15;
		$hotgoods_order=4;
	}
	
	$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newgoods"=>$newgoods_order,"hotgoods"=>$hotgoods_order);
	asort($homegoods_arr);
	
	$n=1;
	foreach($homegoods_arr as $key=>$homegoods){
		if($n==1)$current=' class="current" ';else $current=' ';
		if($key=='zjsalegoods'){
			if($IsPinEdu==1){
				$it618_exam_lang['t91']=$it618_exam_lang['s593'];
				$it618_exam_lang['t90']=$it618_exam_lang['s595'];
			}
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-new"),\'rc-new\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-new" onclick="tabCutover(this,\'rc-new\');get_home_goods(\''.$key.'\');" title="'.$it618_exam_lang['t90'].'">'.$it618_exam_lang['t91'].'<i></i></span>';
		}
		
		if($key=='weeksalegoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-week"),\'re-week\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-week" onclick="tabCutover(this,\'re-week\');get_home_goods(\''.$key.'\');" title="'.$it618_exam_lang['t92'].'">'.$it618_exam_lang['t93'].'<i></i></span>';
		}
		
		if($key=='newgoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-newjf"),\'re-newjf\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-re-newjf" onclick="tabCutover(this,\'re-newjf\');get_home_goods(\''.$key.'\');" title="'.$it618_exam_lang['t312'].'">'.$it618_exam_lang['s989'].'<i></i></span>';
		}
		
		if($key=='hotgoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-hotjf"),\'re-hotjf\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-re-hotjf" onclick="tabCutover(this,\'re-hotjf\');get_home_goods(\''.$key.'\');" title="'.$it618_exam_lang['t313'].'">'.$it618_exam_lang['s990'].'<i></i></span>';
		}
		$n=$n+1;
	
		if($key=='zjsalegoods'){
			$home_goods.='<div class="rc-new" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='weeksalegoods'){
			$home_goods.='<div class="re-week" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='newgoods'){
			$home_goods.='<div class="re-newjf" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='hotgoods'){
			$home_goods.='<div class="re-hotjf" id="home_goods_'.$key.'"></div>';
		}
	}
	
	$homegoods_str='<div class="recommend-goods">
			<div class="recommend-title">
				'.$tab_goods.'
			</div>
			<div class="recommend-content">
				'.$home_goods.'
			</div>
			</div>';
}

if($templatename=='default'&&$pagetype=='index'){

	$i=1;
	foreach(C::t('#it618_exam#it618_exam_focus')->fetch_all_by_type_order(18) as $it618_exam_focus) {
		$indexfocuscss.='.main_image li .img_'.$i.'{background:url(\''.$it618_exam_focus['it618_img'].'\') center top no-repeat}';
		
		
		$indexfocusem.='<em></em>';
		
		if($it618_exam_focus['it618_url']!=''){
			$indexfocusimg.='<li><a href="'.$it618_exam_focus['it618_url'].'" target="_blank"><span class="img_'.$i.'"></span></a></li>';
		}else{
			$indexfocusimg.='<li><span class="img_'.$i.'"></span></li>';
		}
		$i=$i+1;
	}
}
//From: Dism��taobao��com
?>