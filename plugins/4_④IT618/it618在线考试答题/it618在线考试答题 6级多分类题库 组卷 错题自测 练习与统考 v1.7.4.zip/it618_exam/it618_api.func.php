<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsUnion,$IsCredits,$IsChat,$it618_exam,$it618_hongbao_lang;

if(exam_is_mobile())$wap=1;

if($IsUnion==1&&$pagetype=='teacher'){
	$sql='it618_ison=1';
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('exam',$it618_exam_shop['id'],$sql);
	
	$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('exam',$it618_exam_shop['id'],$sql);
}

if($IsUnion==1&&$pagetype=='product'){
	$sql='it618_ison=1 and (it618_pids=\'\' or CONCAT(\',\',it618_pids,\',\') like \'%,'.$pid.',%\')';
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('exam',$it618_exam_goods['it618_shopid'],$sql);
	
	if($quancount>0){
		$shopquanurl=it618_exam_getrewrite('exam_teacher',$it618_exam_goods['it618_shopid'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_goods['it618_shopid'].'&quan','?quan');
		
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_money_by_shoptype_shopid('exam',$it618_exam_goods['it618_shopid'],$sql,'it618_money desc');
		if($union_quanmoney>0){
			$union_quan=$it618_union_lang['s1584'].$union_quanmoney.$it618_union_lang['s1585'];
		}
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_mjmoney_by_shoptype_shopid('exam',$it618_exam_goods['it618_shopid'],$sql,'it618_mjmoney2 desc');
		if($union_quanmoney['it618_mjmoney2']>0){
			$union_quan.=' '.$it618_union_lang['s1582'].$union_quanmoney['it618_mjmoney1'].$it618_union_lang['s1585'].$it618_union_lang['s1583'].$union_quanmoney['it618_mjmoney2'].$it618_union_lang['s1585'];
		}
	}
	
	$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('exam',$it618_exam_goods['it618_shopid'],$sql);
	if($tuicount>0){
		$union_tuitcbl=C::t('#it618_union#it618_union_tui')->fetch_tc_by_shoptype_shopid('exam',$it618_exam_goods['it618_shopid'],$sql,'it618_tcbl desc');
		$union_tuitc=$it618_union_lang['s1580'].str_replace(".00","",$union_tuitcbl).'%'.$it618_union_lang['s1581'];
	}
}

if($IsUnion==1){
	$tuipower=1;
	$tuiuid=intval($_GET['tuiuid']);
	if($tuiuid>0){
		$usercount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$tuiuid);
		if($usercount>0){
			$groupid=DB::result_first("select groupid from ".DB::table('common_member')." where uid=".$tuiuid);
			$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
			if(!in_array($groupid, $union_tuigroup)&&$union_tuigroup[0]!=''){
				$tuipower=0;
			}
		}
	}
	
	if($tuipower==1){
		if($it618_union['union_cookietime']==0)$union_cookietime=3600;else $union_cookietime=$it618_union['union_cookietime']*3600;
		dsetcookie('it618_union_tuiuid',$tuiuid,$union_cookietime);
	}
}

if($IsPinEdu==1&&$pagetype=='product'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
	$shoptype='exam';
	$pingoods=it618_pinedu_getpingoods($shoptype,$it618_exam_goods['id'],$wap);
	if($pingoods['pinstr']!=''){
		$ispinok=1;
		$jqueryname='IT618_EXAM';
		if($wap==1){
			if($_GET['e']!=''){
				$pinurl=$_G['siteurl'].it618_exam_getrewrite('exam_wap','pin@tmptypeid@tmpspid','plugin.php?id=it618_exam:wap&pagetype=pin&cid1=tmptypeid&cid2=tmpspid'.'&e='.$_GET['e'],'?e='.$_GET['e']);
			}else{
				$pinurl=$_G['siteurl'].it618_exam_getrewrite('exam_wap','pin@tmptypeid@tmpspid','plugin.php?id=it618_exam:wap&pagetype=pin&cid1=tmptypeid&cid2=tmpspid');
			}
			
			$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
			$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
			include template('it618_pinedu:pinsale');
			$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
		}else{
			include template('it618_pinedu:pinsale');
		}
	}
}

if($IsCredits==1){
	$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
	
	if(in_array(1,(array)unserialize($it618_hongbao['hongbao_power']))){
		$ishongbao=0;
		if($wap==1){
			if($pagetype=='exam'||$pagetype=='search')$ishongbao=1;
		}else{
			if($pagetype=='index'||$pagetype=='list'||$pagetype=='search')$ishongbao=1;
		}
		
		if($ishongbao==1){
			$it618_hbtype='it618_exam_admin';
			$tid=0;
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$it618_exam = $_G['cache']['plugin']['it618_exam'];
				$shopadmin=explode(",",$it618_exam['exam_shopadmin']);
				if(in_array($_G['uid'],$shopadmin)){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
			include template('it618_hongbao:hongbao');
		}
	}
	
	if(in_array(2,(array)unserialize($it618_hongbao['hongbao_power']))){
		$ishongbao=0;
		if($pagetype=='teacher')$ishongbao=1;
		
		if($ishongbao==1){
			$it618_hbtype='it618_exam_shop';
			$tid=$it618_exam_shop['id'];
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$shoptmp=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($tid);
				if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
			include template('it618_hongbao:hongbao');
		}
	}
}

if($IsChat==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/function.func.php';
	
	$chatplugin='it618_exam';
	if($pagetype=='product'){
		$chatsid=$it618_exam_goods['it618_shopid'];
	}elseif($pagetype=='teacher'){
		$chatsid=$ShopId;
	}else{
		$chatsid=0;
	}
	
	$it618_chat_kefu = it618_chat_getkefu($chatplugin,$chatsid,$wap);
}

if(($pagetype=='teacher'||$pagetype=='product')&&$it618_chat_kefu==''){
	$exam_kefu = $it618_exam['exam_kefu'];
	$exam_kefu=explode(",",$exam_kefu);

	if($it618_exam_shop['it618_kefuqq']!=''){
		$qqarr=explode(",",$it618_exam_shop['it618_kefuqq']);
		$qqnamearr=explode(",",$it618_exam_shop['it618_kefuqqname']);
		for($i=0;$i<count($qqarr);$i++)
		{
			if($qqarr[$i]!='')$shopqq.='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="source/plugin/it618_exam/images/qqbtnsmall.gif" align="absmiddle"/>'.$qqnamearr[$i].'</a> ';
			
			$shoprightqq.='<h3>'.$qqnamearr[$i].'</h3>
			<ul>
				<li><span>'.$it618_exam_lang['s1060'].'</span>
				<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="source/plugin/it618_exam/images/qqbtn.gif" align="absmiddle"/></a>
				</li>
			</ul>';
			
		}
		
	}
}
//From: Dism��taobao��com
?>