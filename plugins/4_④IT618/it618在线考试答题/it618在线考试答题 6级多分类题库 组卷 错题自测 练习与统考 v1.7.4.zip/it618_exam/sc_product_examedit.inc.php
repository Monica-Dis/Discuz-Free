<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$lid=intval($_GET['lid']);
$urlsql='&lid='.$lid;

$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_goods_lesson_exam', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_order'])) {
		foreach($_GET['it618_order'] as $id => $val) {

			C::t('#it618_video#it618_video_goods_lesson_exam')->update($id,array(
				'it618_power' => trim($_GET['it618_power'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			$ok1=$ok1+1;
		}
	}

	it618_cpmsg($it618_exam_lang['s33'].$ok1.' '.$it618_exam_lang['s35'].$del.')', "plugin.php?id=it618_exam:sc_product_examedit&lid=$lid&page=$page", 'succeed');
}

it618_showformheader("plugin.php?id=it618_exam:sc_product_examedit&lid=$lid&page=$page");

showtableheaders('','it618_video_goods_lesson_exam');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_lesson_exam')." WHERE it618_lid=".$lid);

echo '
<tr><td colspan=15>'.$it618_exam_lang['s811'].$count.'<span style="float:right;color:red">'.$it618_exam_lang['s1529'].'</span></td></tr>';

showsubtitle(array('', $it618_exam_lang['s786'],$it618_exam_lang['s1527'],$it618_exam_lang['s50']));

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson_exam')." WHERE it618_lid=".$lid." ORDER BY it618_order,id");
while($it618_video_goods_lesson_exam = DB::fetch($query)) {
	$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_video_goods_lesson_exam['it618_tid']);
	
	$it618_isvip='';
	$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
	if(count($vipgroupids)>0){
		$it618_isvip='<br><img src="source/plugin/it618_exam/images/vip.png" style="vertical-align:middle;margin-left:15px">';
	}
	
	$it618_issecret='';
	if($it618_exam_goods['it618_issecret']==1){
		$it618_issecret='<br><img src="source/plugin/it618_exam/images/secret.png" style="vertical-align:middle;height:18px;margin-left:15px">';
	}
	
	$tmpurl=it618_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
	
	if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
		$pricestr='<span style="color:#f30;">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
	}else{
		$pricestr='<span style="color:#390;">'.$it618_exam_lang['s106'].'</span>';
	}
	
	$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
	$it618_examstr=str_replace("{qcount}",$it618_exam_goods['it618_questioncount'],$it618_exam_lang['s168']);
	$it618_examstr=str_replace("{score}",$it618_exam_goods['it618_examscore'],$it618_examstr);
	$it618_examstr=str_replace("{time}",$it618_exam_goods['it618_examtime'],$it618_examstr);
	
	if($it618_video_goods_lesson_exam['it618_power']==1)$it618_power_checked='checked="checked"';else $it618_power_checked="";

	showtablerow('', array('', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" '.$disabled.' value="'.$it618_video_goods_lesson_exam['id'].'"><label for="chk_del'.$n.'">'.$it618_video_goods_lesson_exam['id'].$it618_isvip.$it618_issecret.'</label>',
		'<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'" width="90" height="58" align="absmiddle"/></a><div style="float:left;margin-left:10px;line-height:20px">'.$it618_exam_goods['it618_name'].'<br><font color=#999>'.$it618_exam_goods['it618_description'].'</font><br>'.$pricestr.' '.$it618_examstr.'</div>',
		'<input class="checkbox" type="checkbox" id="chk_power'.$n.'" name="it618_power['.$it618_video_goods_lesson_exam['id'].']" '.$it618_power_checked.' value="1"><label for="chk_power'.$n.'">'.it618_exam_getlang('s1530').'</label>',
		'<input type="text" class="txt" style="width:30px;text-align:center;" name="it618_order['.$it618_video_goods_lesson_exam['id'].']" value="'.$it618_video_goods_lesson_exam['it618_order'].'">'
	));
}
	
showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>