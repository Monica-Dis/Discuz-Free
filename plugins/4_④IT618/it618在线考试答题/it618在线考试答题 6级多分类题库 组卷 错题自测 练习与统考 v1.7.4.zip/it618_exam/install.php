<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_exam_shop`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(200) NOT NULL,
  `it618_tel` varchar(200) NOT NULL,
  `it618_msgtel` varchar(20) NOT NULL,
  `it618_msgisok` int(10) unsigned NOT NULL default '0',
  `it618_qq` varchar(200) NOT NULL,
  `it618_dianhua` varchar(200) NOT NULL,
  `it618_kefuqq` varchar(200) NOT NULL,
  `it618_kefuqqname` varchar(200) NOT NULL,
  `it618_kefuwx` varchar(200) NOT NULL,
  `it618_kefuwxname` varchar(200) NOT NULL,
  `it618_yytime` varchar(200) NOT NULL,
  `it618_ulogo` varchar(255) NOT NULL,
  `it618_logo` varchar(255) NOT NULL,
  `it618_waplogo` varchar(255) NOT NULL,
  `it618_logourl` varchar(255) NOT NULL,
  `it618_waplogourl` varchar(255) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_tongji` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_ischeck` int(10) unsigned NOT NULL default '1',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_htstate` int(10) unsigned NOT NULL,
  `it618_money` float(9,2) NOT NULL default '0.00',
  `it618_price` float(9,2) NOT NULL default '0.00',
  `it618_score` int(10) unsigned NOT NULL default '1000',
  `it618_tcbl` float(9,2) NOT NULL default '5.00',
  `it618_subscribes` int(10) unsigned NOT NULL default '0',
  `it618_wxmessagecount` int(10) unsigned NOT NULL,
  `it618_views` int(10) unsigned NOT NULL default '0',
  `it618_order` int(10) unsigned NOT NULL default '0',
  `it618_time` int(10) unsigned NOT NULL default '0',
  `it618_rztime` int(10) unsigned NOT NULL default '0',
  `it618_htetime` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_user`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isadderr` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_shop_subscribe`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_shop_subscribe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_nav`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_class1`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_class1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_pj` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL,
  `it618_wapgoodscount` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL DEFAULT '',
  `it618_url` varchar(255) NOT NULL,
  `it618_vipgroupid` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_class2`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_class2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_class_vipgroup`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_class_vipgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_goods_vipgroup`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_vipgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_class3`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_class3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_class4`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_class4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_qclass1`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_qclass1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_parenttype` int(10) unsigned NOT NULL default '0',
  `it618_parentclassid` int(10) unsigned NOT NULL default '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_qclass2`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_qclass2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_parenttype` int(10) unsigned NOT NULL default '0',
  `it618_parentclassid` int(10) unsigned NOT NULL default '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_qclass3`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_qclass3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_qclass4`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_qclass4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_qtype`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_qtype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_typename` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_questions`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL default '0',
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_class3_id` int(10) unsigned NOT NULL,
  `it618_class4_id` int(10) unsigned NOT NULL,
  `it618_qclass11_id` int(10) unsigned NOT NULL,
  `it618_qclass12_id` int(10) unsigned NOT NULL,
  `it618_qclass13_id` int(10) unsigned NOT NULL,
  `it618_qclass21_id` int(10) unsigned NOT NULL,
  `it618_qclass22_id` int(10) unsigned NOT NULL,
  `it618_qclass23_id` int(10) unsigned NOT NULL,
  `it618_qclass24_id` int(10) unsigned NOT NULL,
  `it618_qclass25_id` int(10) unsigned NOT NULL,
  `it618_qclass26_id` int(10) unsigned NOT NULL,
  `it618_qclass3_id` int(10) unsigned NOT NULL,
  `it618_qclass4_id` int(10) unsigned NOT NULL,
  `it618_qtypeid` int(10) unsigned NOT NULL default '0',
  `it618_name` text NOT NULL,
  `it618_value` text NOT NULL,
  `it618_about` text NOT NULL,
  `it618_optioncount` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_questions_option`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_questions_option` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_qid` int(10) unsigned NOT NULL default '0',
  `it618_name` text NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_questions_group`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_questions_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_qid` int(10) unsigned NOT NULL default '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_class3_id` int(10) unsigned NOT NULL,
  `it618_class4_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_ptypename` varchar(255) NOT NULL,
  `it618_ptypename1` varchar(255) NOT NULL,
  `it618_gtype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_answertype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_description` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_xgtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtime1` varchar(20) NOT NULL,
  `it618_xgtime2` varchar(20) NOT NULL,
  `it618_testcount` int(10) unsigned NOT NULL DEFAULT '80',
  `it618_pici` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isbm` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_picbig` varchar(255) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shoporder` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tests` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lessoncount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_questioncount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_examtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_examscore` float(6,1) NOT NULL,
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjpfstr` varchar(255) NOT NULL,
  `it618_issd` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_ispm` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ischat` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isnote` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issecret` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_secretusers` varchar(8000) NOT NULL,
  `it618_shopuid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_goods_type`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL default '0',
  `it618_name1` varchar(255) NOT NULL,
  `it618_order1` int(10) unsigned NOT NULL default '0',
  `it618_testcount` int(10) unsigned NOT NULL default '0',
  `it618_count` int(10) unsigned NOT NULL default '0',
  `it618_xgtime` int(10) unsigned NOT NULL default '0',
  `it618_xgcount` int(10) unsigned NOT NULL default '0',
  `it618_salecount` int(10) unsigned NOT NULL default '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL default '0',
  `it618_score` int(10) unsigned NOT NULL default '0',
  `it618_ison` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_goods_lesson`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_lesson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_name` text NOT NULL,
  `it618_type` int(10) unsigned NOT NULL default '1',
  `it618_shareabout` int(10) unsigned NOT NULL default '0',
  `it618_about` text NOT NULL,
  `it618_randcount` int(10) unsigned NOT NULL default '0',
  `it618_dispcount` int(10) unsigned NOT NULL default '0',
  `it618_isdispoption` int(10) unsigned NOT NULL default '1',
  `it618_questioncount` int(10) unsigned NOT NULL default '0',
  `it618_examscore` float(6,1) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_goods_user`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_uid` int(10) unsigned NOT NULL default '0',
  `it618_eid` int(10) unsigned NOT NULL default '0',
  `it618_pici` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_testid` varchar(30) NOT NULL,
  `it618_name` varchar(30) NOT NULL,
  `it618_bz` varchar(300) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL default '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_goods_bmuser`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_bmuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_uid` int(10) unsigned NOT NULL default '0',
  `it618_testid` varchar(30) NOT NULL,
  `it618_name` varchar(30) NOT NULL,
  `it618_bz` varchar(300) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL default '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_goods_questions`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_questions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_lid` int(10) unsigned NOT NULL default '0',
  `it618_qid` int(10) unsigned NOT NULL default '0',
  `it618_score` float(6,1) NOT NULL,
  `it618_mcqscore` float(6,1) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_goods_count`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_count` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_testcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islock` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_test`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_test` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ip` varchar(20) NOT NULL,
  `it618_ips` varchar(1000) NOT NULL,
  `it618_testcode` varchar(32) NOT NULL,
  `it618_ucode` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_test_exam`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_test_exam` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_tieid` int(10) unsigned NOT NULL default '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_answertype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_eindex` int(10) unsigned NOT NULL default '1',
  `it618_qindex` int(10) unsigned NOT NULL default '1',
  `it618_isvip` int(10) unsigned NOT NULL default '0',
  `it618_isadderr` int(10) unsigned NOT NULL default '1',
  `it618_score` float(6,1) NOT NULL,
  `it618_testscore` float(6,1) NOT NULL,
  `it618_questioncount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_examtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_test_exam_questions`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_test_exam_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_eid` int(10) unsigned NOT NULL default '0',
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_qid` int(10) unsigned NOT NULL default '0',
  `it618_lid` int(10) unsigned NOT NULL default '0',
  `it618_value` text NOT NULL,
  `it618_mcqscore` float(6,1) NOT NULL,
  `it618_score` float(6,1) NOT NULL,
  `it618_testscore` float(6,1) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  `it618_isbj` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_errquestions`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_errquestions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_eid` int(10) unsigned NOT NULL default '0',
  `it618_qid` int(10) unsigned NOT NULL default '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_utest`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_utest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ip` varchar(20) NOT NULL,
  `it618_ips` varchar(1000) NOT NULL,
  `it618_testcode` varchar(32) NOT NULL,
  `it618_ucode` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_utest_exam`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_utest_exam` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_answertype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_qindex` int(10) unsigned NOT NULL default '1',
  `it618_questioncount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rightcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_examtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_utest_exam_questions`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_utest_exam_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_eid` int(10) unsigned NOT NULL default '0',
  `it618_qid` int(10) unsigned NOT NULL default '0',
  `it618_value` text NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  `it618_isbj` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_test_pj`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_test_pj` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_score1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjjl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content` varchar(2000) NOT NULL,
  `it618_hfcontent` varchar(2000) NOT NULL,
  `it618_notecontent` mediumtext NOT NULL,
  `it618_pjtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_test_pjpic`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_test_pjpic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pjid` int(10) unsigned NOT NULL,
  `it618_pjpic` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_price` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_quanmoney` float(9,2) NOT NULL,
  `it618_vipzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tc` float(9,2) NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuitcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tuitc` float(9,2) NOT NULL DEFAULT '0',
  `it618_pinsaleid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_gwc`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_gwc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_price` float(9,2) NOT NULL DEFAULT '0',
  `it618_pricescore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0',
  `it618_iseditprice` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_gwcsale_main`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_gwcsale_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_moneybz` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_gwcsale`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_gwcsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_quanmoney` float(9,2) NOT NULL,
  `it618_vipzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tel` varchar(20) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_bank`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_bankname` varchar(200) NOT NULL,
  `it618_bankid` varchar(50) NOT NULL,
  `it618_bankaddr` varchar(50) NOT NULL,
  `it618_alipayname` varchar(50) NOT NULL,
  `it618_alipay` varchar(100) NOT NULL,
  `it618_wxname` varchar(50) NOT NULL,
  `it618_wx` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_txbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_txbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_num1` int(10) unsigned NOT NULL,
  `it618_num2` int(10) unsigned NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_tx`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_tx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_bz` varchar(1000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_jfhl`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_jfhl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_hl` float(9,3) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_style`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_style` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_sql` varchar(200) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_findkey`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_collect`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_examwork`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_examwork` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_code` varchar(32) NOT NULL,
  `it618_exam` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_uexamwork`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_uexamwork` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_code` varchar(32) NOT NULL,
  `it618_tmpid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_exam_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vdXBncmFkZS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vaW5zdGFsbC5waHA='));
?>