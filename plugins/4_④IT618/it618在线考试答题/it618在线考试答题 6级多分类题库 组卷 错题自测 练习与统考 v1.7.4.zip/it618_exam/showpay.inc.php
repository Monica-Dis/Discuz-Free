<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_exam = $_G['cache']['plugin']['it618_exam'];
$creditname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';

if($_G['uid']>0){
	$it618_gtypeid=intval($_GET['it618_gtypeid']);
	$it618_count=intval($_GET['it618_count']);

	$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($_GET['pid']);
	
	if($it618_exam['exam_saletel']==2){
		$isbd='telbd';
		if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
			$tel=$it618_members_user['it618_tel'];
			$isbd='ok';
		}
	}else{
		$tel=C::t('#it618_exam#it618_exam_sale')->fetch_tel_by_uid($_G['uid']);
	}
	
	if($it618_gtypeid>0){
		if($it618_exam_goods_type=C::t('#it618_exam#it618_exam_goods_type')->fetch_by_idok($it618_gtypeid)){
			$goods_price=$it618_exam_goods_type['it618_saleprice'];
			$goods_jfid=$it618_exam_goods_type['it618_jfid'];
			$goods_score=$it618_exam_goods_type['it618_score'];
			$gtypename = C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_gtypeid);
		}
	}else{
		$goods_price=$it618_exam_goods['it618_saleprice'];
		$goods_jfid=$it618_exam_goods['it618_jfid'];
		$goods_score=$it618_exam_goods['it618_score'];
	}
	
	if($IsGroup==1){
		$vipzk=it618_exam_getvipzk($_GET['pid']);
	}
	
	if($vipzk>0){
		$goods_price=round($goods_price*$vipzk/100,2);
		$goods_score=intval($goods_score*$vipzk/100);
	}
	
	if($vipzk>0){
		$zk=round(($vipzk/10),2);
		$zkstr=$zk.$it618_exam_lang['s1952'];
		
		$zkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:3px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px">'.$zkstr.'</span>';
	}
	
	$yfmoney=0;
	if($goods_price>0&&$goods_score>0){
		$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
		$yfmoney=$goods_price*$it618_count;
		$yfscore=$goods_score*$it618_count;
		$sumscore[$goods_jfid]+=$yfscore;
	}else{
		if($goods_price>0){
			$yfmoney=$goods_price*$it618_count;
		}
		
		if($goods_score>0){
			$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
			$yfscore=$goods_score*$it618_count;
			$sumscore[$goods_jfid]+=$yfscore;
		}
	}
	
	if($it618_exam_goods['it618_jfbl']>0&&$goods_price>0){
		$jfbl='<font color=#888>'.it618_exam_getlang('s1049').'<font color=red>'.$it618_exam_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
	}
	
	for($i=1;$i<=8;$i++){
		if($sumscore[$i]>0){
			$jfname=$_G['setting']['extcredits'][$i]['title'];
			
			$scorestr.='<em class="yf">'.$sumscore[$i].'</em> <em class="yf yfjfname" style="font-size:12px">'.$jfname.'</em><em class="yf">+</em>';
			
			$creditnum=C::t('#it618_exam#it618_exam_sale')->fetch_extcredits_by_uid($i,$_G['uid']);
			if($creditnum=="")$creditnum=0;
			$jfcounttmp.='<font color="red">'.$creditnum.'</font>'.$jfname;
		}
	}
	
	if($scorestr!=''){
		$scorestr.='@';
		$scorestr=str_replace('<em class="yf">+</em>@',"",$scorestr);
		
		$jfcountstr=$it618_exam_lang['s1107'].' '.$jfcounttmp;
	}
	
	if($yfmoney>0&&$scorestr!=''){
		$yfmoneystr='<em class="yf">&yen;</em> <em class="yf" id="yfmoney">'.$yfmoney.'</em><input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'"><em class="yf">+</em>'.$scorestr;
		$moneyscore=1;
	}else{
		if($yfmoney>=0){
			$yfmoneystr='<em class="yf">&yen;</em> <em class="yf" id="yfmoney">'.$yfmoney.'</em><input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'">';
		}
		if($scorestr!=''){
			$yfmoneystr=$scorestr;
		}
	}
	
}

if($yfmoney>0){
	if($_GET['wap']==1){
		$it618paystr=it618_exam_pay('paywap',$it618_exam_lang['t357']);
	}else{
		$it618paystr=it618_exam_pay('pay',$it618_exam_lang['t357']);
	}
}

if($IsUnion==1){
	if($yfmoney>0){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
		
		$quanstr=it618_union_getquansale('exam',$it618_exam_goods['it618_shopid'],$_GET['wap'],$it618_exam_goods['id'],$yfmoney);
	}else{
		$quanstr='<input type="hidden" id="quanid" value="0">';
	}
}

if($_GET['wap']==1){
	$height=$_GET['height']*0.8-26;
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_exam:showpay');
?>