<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_header.func.php';

$it618_class1_id=intval($_GET['it618_class1_id']);
$it618_class2_id=intval($_GET['it618_class2_id']);
$it618_class3_id=intval($_GET['it618_class3_id']);
$it618_class4_id=intval($_GET['it618_class4_id']);
$it618_qclass11_id=intval($_GET['it618_qclass11_id']);
$it618_qclass12_id=intval($_GET['it618_qclass12_id']);
$it618_qclass13_id=intval($_GET['it618_qclass13_id']);
$it618_qclass21_id=intval($_GET['it618_qclass21_id']);
$it618_qclass22_id=intval($_GET['it618_qclass22_id']);
$it618_qclass23_id=intval($_GET['it618_qclass23_id']);
$it618_qclass24_id=intval($_GET['it618_qclass24_id']);
$it618_qclass25_id=intval($_GET['it618_qclass25_id']);
$it618_qclass26_id=intval($_GET['it618_qclass26_id']);
$it618_qclass3_id=intval($_GET['it618_qclass3_id']);
$it618_qclass4_id=intval($_GET['it618_qclass4_id']);
$it618_qtypeid=intval($_GET['it618_qtypeid']);

if($it618_qclass11_id>0)$cid1=$it618_qclass11_id;
if($it618_qclass12_id>0)$cid1=$it618_qclass12_id;
if($it618_qclass13_id>0)$cid1=$it618_qclass13_id;

if($it618_qclass23_id>0)$cid2=$it618_qclass23_id;
if($it618_qclass24_id>0)$cid2=$it618_qclass24_id;
if($it618_qclass25_id>0)$cid2=$it618_qclass25_id;
if($it618_qclass26_id>0)$cid2=$it618_qclass26_id;

$urlsql='&it618_class1_id='.$it618_class1_id;
$urlsql.='&it618_class2_id='.$it618_class2_id;
$urlsql.='&it618_class3_id='.$it618_class3_id;
$urlsql.='&it618_class4_id='.$it618_class4_id;
$urlsql.='&it618_qclass11_id='.$it618_qclass11_id;
$urlsql.='&it618_qclass12_id='.$it618_qclass12_id;
$urlsql.='&it618_qclass13_id='.$it618_qclass13_id;
$urlsql.='&it618_qclass21_id='.$it618_qclass21_id;
$urlsql.='&it618_qclass22_id='.$it618_qclass22_id;
$urlsql.='&it618_qclass23_id='.$it618_qclass23_id;
$urlsql.='&it618_qclass24_id='.$it618_qclass24_id;
$urlsql.='&it618_qclass25_id='.$it618_qclass25_id;
$urlsql.='&it618_qclass26_id='.$it618_qclass26_id;
$urlsql.='&it618_qclass3_id='.$it618_qclass3_id;
$urlsql.='&it618_qclass4_id='.$it618_qclass4_id;
$urlsql.='&it618_qtypeid='.$it618_qtypeid;

$qtypename=C::t('#it618_exam#it618_exam_qtype')->fetch_it618_name_by_id($it618_qtypeid);

if(submitcheck('it618submit_adds')){
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', it618_exam_strip_tags($_GET['it618_name_adds'],'<img> <iframe> <sub> <sup> <u> <br>'));
	$lines=str_replace($it618_exam_lang['s643'],'.',$lines);
	
	if($_GET['chkreplace']==1){
		$lines=str_replace(trim($_GET['replaccon1']),trim($_GET['replaccon2']),$lines);
	}
	
	$line=explode("@||@",$lines);
	
	if($_GET['daomode']==1){
		$ok=post($ShopId,$line);
	}else{
		$ok=post_tongyi($ShopId,$line,$it618_qtypeid);
	}

	it618_cpmsg(it618_exam_getlang('s598').$ok, "plugin.php?id=it618_exam:sc_question_dao".$urlsql, 'succeed');
}

if(submitcheck('it618submit_dao')){
	if (preg_match('/\.\./', $_GET['it618_name_dao'])) {
		it618_cpmsg(it618_exam_getlang('s594'), "plugin.php?id=it618_exam:sc_question_dao".$urlsql, 'error');
	}
	
	$tmparr=explode("source/plugin/it618_exam/kindeditor",$_GET['it618_name_dao']);
	$file_path='source/plugin/it618_exam/kindeditor'.$tmparr[1];
	
	if (!file_exists($file_path)) {
		it618_cpmsg(it618_exam_getlang('s594'), "plugin.php?id=it618_exam:sc_question_dao".$urlsql, 'error');
	}
	
	$lines = dfsockopen($_G['siteurl'].$file_path);
	if(CHARSET!='gbk'){
		$lines = it618_exam_gbktoutf($lines);
	}
	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	$lines=str_replace($it618_exam_lang['s643'],'.',$lines);
	
	if($_GET['chkreplace']==1){
		$lines=str_replace(trim($_GET['replaccon1']),trim($_GET['replaccon2']),$lines);
	}
	
	ini_set('memory_limit', '-1');
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $lines);
	
	$line=explode("@||@",$lines);
	@unlink($file_path);
	
	if($_GET['daomode']==1){
		$ok=post($ShopId,$line);
	}else{
		$ok=post_tongyi($ShopId,$line,$it618_qtypeid);
	}

	it618_cpmsg(it618_exam_getlang('s599').$ok, "plugin.php?id=it618_exam:sc_question_dao".$urlsql, 'succeed');
}

if(submitcheck('it618submit_dao2')){
	
	if (preg_match('/\.\./', $_GET['it618_name_dao2'])||$_GET['it618_name_dao2']=='') {
		it618_cpmsg($it618_sale_lang['s594'], "plugin.php?id=it618_exam:sc_question_dao".$urlsql, 'error');
	}
	
	$tmparr=explode("source/plugin/it618_exam/kindeditor",$_GET['it618_name_dao2']);
	$file_path='source/plugin/it618_exam/kindeditor'.$tmparr[1];
	
	if (!file_exists($file_path)) {
		it618_cpmsg(it618_exam_getlang('s594'), "plugin.php?id=it618_exam:sc_question_dao".$urlsql, 'error');
	}

	$qtypeid=intval($_GET['it618_qtypeid']);
	$excel_name=intval($_GET['excel_name']);
	$excel_option1=intval($_GET['excel_option1']);
	$excel_option2=intval($_GET['excel_option2']);
	$excel_answer=intval($_GET['excel_answer']);
	$excel_about=intval($_GET['excel_about']);
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_exam/phpexcel/reader.php';

	$data = new Spreadsheet_Excel_Reader();
	
	$data->setOutputEncoding('GB2312');
	
	$data->read(DISCUZ_ROOT.'./'.$file_path);

	error_reporting(E_ALL ^ E_NOTICE);
	
	$ok=0;$ok1=0;
	for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {
		
		if(trim($data->sheets[0]['cells'][$i][$excel_name])==''&&trim($data->sheets[0]['cells'][$i][$excel_answer])==''){
			if(trim($data->sheets[0]['cells'][$i+1][$excel_name])==''&&trim($data->sheets[0]['cells'][$i+2][$excel_name])==''&&trim($data->sheets[0]['cells'][$i+3][$excel_name])==''){
				break;
			}else{
				continue;
			}
		}
		
		$it618_name=it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i][$excel_name]));
		$it618_answer=it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i][$excel_answer]));
		$it618_about=it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i][$excel_about]));
		
		if(strlen($it618_name)>28){
			if(C::t('#it618_exam#it618_exam_questions')->count_by_shopid_name($ShopId,$it618_name)>0){
				$ok1=$ok1+1;
				continue;
			}
		}
		
		$qid=C::t('#it618_exam#it618_exam_questions')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_class1_id' => $_GET['it618_class1_id'],
			'it618_class2_id' => $_GET['it618_class2_id'],
			'it618_class3_id' => $_GET['it618_class3_id'],
			'it618_class4_id' => $_GET['it618_class4_id'],
			'it618_qclass11_id' => $_GET['it618_qclass11_id'],
			'it618_qclass12_id' => $_GET['it618_qclass12_id'],
			'it618_qclass13_id' => $_GET['it618_qclass13_id'],
			'it618_qclass21_id' => $_GET['it618_qclass21_id'],
			'it618_qclass22_id' => $_GET['it618_qclass22_id'],
			'it618_qclass23_id' => $_GET['it618_qclass23_id'],
			'it618_qclass24_id' => $_GET['it618_qclass24_id'],
			'it618_qclass25_id' => $_GET['it618_qclass25_id'],
			'it618_qclass26_id' => $_GET['it618_qclass26_id'],
			'it618_qclass3_id' => $_GET['it618_qclass3_id'],
			'it618_qclass4_id' => $_GET['it618_qclass4_id'],
			'it618_qtypeid' => $_GET['it618_qtypeid'],
			'it618_name' => it618_exam_strip_tags($it618_name,'<img> <iframe> <sub> <sup> <u> <br>'),
		), true);
		
		$ok=$ok+1;
		
		$qoorder=1;
		if($qtypeid==1||$qtypeid==2){
			unset($tmpoption);
			for($j=$excel_option1;$j<=$excel_option2;$j++){
				$it618_name=it618_exam_utftogbk(trim($data->sheets[0]['cells'][$i][$j]));
				
				$ABC=it618_exam_getABC($qoorder);
				$tmpoption[$ABC]['it618_qid']=$qid;
				$tmpoption[$ABC]['it618_name']=it618_exam_strip_tags($it618_name,'<img> <iframe> <sub> <sup> <u> <br>');
				$tmpoption[$ABC]['it618_isok']=0;
				$tmpoption[$ABC]['it618_order']=$qoorder;
  
				$qoorder+=1;
			}
			
			if($it618_answer!=''){
				foreach($tmpoption as $key => $value){
				  $answerarr=explode($key,$it618_answer);
				  if(count($answerarr)>1){
					  $value['it618_isok']=1;
				  }
				  
				  C::t('#it618_exam#it618_exam_questions_option')->insert($value, true);
				}
				
			}
		}
	
		if($qtypeid==3){
			if($it618_answer!=''){
				$it618_name=it618_exam_strip_tags($it618_answer);
				C::t('#it618_exam#it618_exam_questions_option')->insert(array(
					'it618_qid' => $qid,
					'it618_name' => $it618_name
				), true);
			}
		}
		
		if($qtypeid==4){
			if($it618_answer!=''){
				$answerarr=explode($it618_answer,$it618_exam_lang['s388']);
				if(count($answerarr)>1){
					C::t('#it618_exam#it618_exam_questions')->update($qid,array(
						'it618_isok' => 1
					));
				}
			}
		}
		
		if($excel_about>0){
			C::t('#it618_exam#it618_exam_questions')->update($qid,array(
				'it618_about' => it618_exam_strip_tags($it618_about,'<img> <iframe> <sub> <sup> <u> <br>')
			));
		}
		
		$opcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$qid);
		$sql = "update ".DB::table('it618_exam_questions')." set it618_optioncount=$opcount where id=".$qid; 
		DB::query($sql);
	
	}

	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	it618_cpmsg(it618_exam_getlang('s599').$ok.it618_exam_getlang('s604').$ok1, "plugin.php?id=it618_exam:sc_question_dao".$urlsql, 'succeed');
}

function post_tongyi($shopid,$line,$qtypeid){
	global $_G,$it618_exam_lang;
	
	$ok=0;$ok1=0;
	if($qtypeid==1||$qtypeid==2){
		$tmpoption = array(array());
	}

	foreach($line as $key =>$li)
	{
		$li=trim(it618_exam_strip_tags($li,'<img> <iframe> <sub> <sup> <u> <br>'));
		if($li!=''){
			
			$tmparr1=explode(".",$li);
			if($tmparr1[0]==intval($tmparr1[0]).''&&$tmparr1[1]!=''){
				$it618_name = trim(str_replace("@@@".$tmparr1[0].'.',"",'@@@'.$li));
				
				if(strlen($it618_name)>28){
					if(C::t('#it618_exam#it618_exam_questions')->count_by_shopid_name($shopid,$it618_name)>0){
						$ok1=$ok1+1;
						$qid=0;
						continue;
					}
				}
				$qoorder=1;
				
				$qid=C::t('#it618_exam#it618_exam_questions')->insert(array(
					'it618_shopid' => $shopid,
					'it618_class1_id' => $_GET['it618_class1_id'],
					'it618_class2_id' => $_GET['it618_class2_id'],
					'it618_class3_id' => $_GET['it618_class3_id'],
					'it618_class4_id' => $_GET['it618_class4_id'],
					'it618_qclass11_id' => $_GET['it618_qclass11_id'],
					'it618_qclass12_id' => $_GET['it618_qclass12_id'],
					'it618_qclass13_id' => $_GET['it618_qclass13_id'],
					'it618_qclass21_id' => $_GET['it618_qclass21_id'],
					'it618_qclass22_id' => $_GET['it618_qclass22_id'],
					'it618_qclass23_id' => $_GET['it618_qclass23_id'],
					'it618_qclass24_id' => $_GET['it618_qclass24_id'],
					'it618_qclass25_id' => $_GET['it618_qclass25_id'],
					'it618_qclass26_id' => $_GET['it618_qclass26_id'],
					'it618_qclass3_id' => $_GET['it618_qclass3_id'],
					'it618_qclass4_id' => $_GET['it618_qclass4_id'],
					'it618_qtypeid' => $_GET['it618_qtypeid'],
					'it618_name' => $it618_name,
				), true);
				
				if($qtypeid==1||$qtypeid==2){
					unset($tmpoption);
				}
				
				$ok=$ok+1;
			}else{
				if($qid>0){

					if($qtypeid==1||$qtypeid==2){

						$tmparr2=explode(".",$li);
						$ABC=trim($tmparr2[0]);
						if(it618_exam_isABC($ABC)&&$tmparr2[1]!=''){
							$it618_name = trim(str_replace("@@@".$tmparr2[0].'.',"",'@@@'.$li));
							
							$tmpoption[$ABC]['it618_qid']=$qid;
							$tmpoption[$ABC]['it618_name']=$it618_name;
							$tmpoption[$ABC]['it618_isok']=0;
							$tmpoption[$ABC]['it618_order']=$qoorder;

							$qoorder+=1;
						}
						
						$tmparr3=explode($it618_exam_lang['s383'],$li);
						if($tmparr3[0]==''&&$tmparr3[1]!=''){
							foreach($tmpoption as $key => $value){
							  $tmparr3[1]=it618_exam_strip_tags($tmparr3[1]);
							  $answerarr=explode($key,$tmparr3[1]);
							  if(count($answerarr)>1){
								  $value['it618_isok']=1;
							  }
							  
							  C::t('#it618_exam#it618_exam_questions_option')->insert($value, true);
							}
							
						}
					}
				
					if($qtypeid==3){
						$tmparr3=explode($it618_exam_lang['s383'],$li);
						if($tmparr3[0]==''&&$tmparr3[1]!=''){
							$it618_name=it618_exam_strip_tags($tmparr3[1]);
							C::t('#it618_exam#it618_exam_questions_option')->insert(array(
								'it618_qid' => $qid,
								'it618_name' => $it618_name
							), true);
						}
					}
					
					if($qtypeid==4){
						$tmparr3=explode($it618_exam_lang['s383'],$li);
						if($tmparr3[0]==''&&$tmparr3[1]!=''){
							$tmparr3[1]=it618_exam_strip_tags($tmparr3[1]);
							$answerarr=explode($tmparr3[1],$it618_exam_lang['s388']);
							if(count($answerarr)>1){
								C::t('#it618_exam#it618_exam_questions')->update($qid,array(
									'it618_isok' => 1
								));
							}
						}
					}
					
					$tmparr4=explode($it618_exam_lang['s384'],$li);
					if($tmparr4[0]==''&&$tmparr4[1]!=''){
						C::t('#it618_exam#it618_exam_questions')->update($qid,array(
							'it618_about' => trim($tmparr4[1])
						));
					}
					
					$opcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$qid);
					$sql = "update ".DB::table('it618_exam_questions')." set it618_optioncount=$opcount where id=".$qid; 
					DB::query($sql);
				}
			}
		}
	}
	
	return $ok.it618_exam_getlang('s604').$ok1;
}

function post($shopid,$line){
	global $_G,$it618_exam_lang;
	
	$ok=0;$ok1=0;
	
	foreach($line as $key =>$li)
	{
		$li=trim(it618_exam_strip_tags($li,'<img> <iframe> <sub> <sup> <u> <br>'));
		if($li!=''){
			$tmparr1=explode("#",$li);
			if($tmparr1[0]==''&&$tmparr1[1]!=''){
				if(strlen($it618_name)>28){
					if(C::t('#it618_exam#it618_exam_questions')->count_by_shopid_name($shopid,$tmparr1[1])>0){
						$ok1=$ok1+1;
						$qid=0;
						continue;
					}
				}
				$qoorder=1;
				$tmparrname=explode("@",$tmparr1[1]);
				if($tmparrname[0]==''&&$tmparrname[1]!=''){
					$it618_name=$tmparrname[1];
				}else{
					$it618_name=$tmparr1[1];
				}
				
				$qid=C::t('#it618_exam#it618_exam_questions')->insert(array(
					'it618_shopid' => $shopid,
					'it618_class1_id' => $_GET['it618_class1_id'],
					'it618_class2_id' => $_GET['it618_class2_id'],
					'it618_class3_id' => $_GET['it618_class3_id'],
					'it618_class4_id' => $_GET['it618_class4_id'],
					'it618_qclass11_id' => $_GET['it618_qclass11_id'],
					'it618_qclass12_id' => $_GET['it618_qclass12_id'],
					'it618_qclass13_id' => $_GET['it618_qclass13_id'],
					'it618_qclass21_id' => $_GET['it618_qclass21_id'],
					'it618_qclass22_id' => $_GET['it618_qclass22_id'],
					'it618_qclass23_id' => $_GET['it618_qclass23_id'],
					'it618_qclass24_id' => $_GET['it618_qclass24_id'],
					'it618_qclass25_id' => $_GET['it618_qclass25_id'],
					'it618_qclass26_id' => $_GET['it618_qclass26_id'],
					'it618_qclass3_id' => $_GET['it618_qclass3_id'],
					'it618_qclass4_id' => $_GET['it618_qclass4_id'],
					'it618_qtypeid' => $_GET['it618_qtypeid'],
					'it618_name' => $it618_name,
				), true);
				
				$tmparr11=explode("@",$tmparr1[1]);
				if($tmparr11[0]==''&&$tmparr11[1]!=''){
					C::t('#it618_exam#it618_exam_questions')->update($qid,array(
						'it618_isok' => 1
					));
				}
				
				$ok=$ok+1;
			}else{
				if($qid>0){
					$tmparr2=explode("@",$li);
					if($tmparr2[0]==''&&$tmparr2[1]!=''){
						$it618_isok=1;
						$it618_name=$tmparr2[1];
					}else{
						$it618_isok=0;
						$it618_name=$li;
					}
					
					$tmparr3=explode("*",$li);
					if($tmparr3[0]==''&&$tmparr3[1]!=''){
						C::t('#it618_exam#it618_exam_questions')->update($qid,array(
							'it618_about' => $tmparr3[1]
						));
					}else{
						$it618_name=it618_exam_strip_tags($it618_name);
						C::t('#it618_exam#it618_exam_questions_option')->insert(array(
							'it618_qid' => $qid,
							'it618_name' => $it618_name,
							'it618_isok' => $it618_isok,
							'it618_order' => $qoorder
						), true);
						$qoorder+=1;
					}
					
					$opcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$qid);
					$sql = "update ".DB::table('it618_exam_questions')." set it618_optioncount=$opcount where id=".$qid; 
					DB::query($sql);
				}
			}
		}
	}
	
	return $ok.it618_exam_getlang('s604').$ok1;
}

it618_showformheader("plugin.php?id=it618_exam:sc_question_dao");

showtableheaders('','sc_question_dao');

$e3css=';display:none';
if($class_set['classname_e3_ishide']!=1){
	$tmpclass3='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_e3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpclass3.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmpclass3=str_replace('<option value='.$it618_class3_id.'>','<option value='.$it618_class3_id.' selected="selected">',$tmpclass3);
	$e3css=';display:';
}

$e4css=';display:none';
if($class_set['classname_e4_ishide']!=1){
	$tmpclass4='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_e4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_class4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpclass4.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmpclass4=str_replace('<option value='.$it618_class4_id.'>','<option value='.$it618_class4_id.' selected="selected">',$tmpclass4);
	$e4css=';display:';
}

$q2css=';display:none';
if($class_set['classname_q2_ishide']!=1){
	$q2css=';display:';
}

$q3css=';display:none';
if($class_set['classname_q3_ishide']!=1){
	$tmpqclass3='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_q3'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass3')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpqclass3.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmpqclass3=str_replace('<option value='.$it618_qclass3_id.'>','<option value='.$it618_qclass3_id.' selected="selected">',$tmpqclass3);
	$q3css=';display:';
}

$q4css=';display:none';
if($class_set['classname_q4_ishide']!=1){
	$tmpqclass4='<option value="0">'.it618_exam_getlang('s1249').$class_set['classname_q4'].'</option>';
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_qclass4')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmpqclass4.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmpqclass4=str_replace('<option value='.$it618_qclass4_id.'>','<option value='.$it618_qclass4_id.' selected="selected">',$tmpqclass4);
	$q4css=';display:';
}

echo '<tr bgcolor="#f1f1f1"><td colspan=15 style="font-size:15px"><font color=blue>['.$qtypename.']</font><span style="float:right;color:red;font-size:13px">'.$it618_exam_lang['s579'].'</span>

	<input type="hidden" id="it618_class1_id" name="it618_class1_id" value="'.$it618_class1_id.'">
	<input type="hidden" id="it618_class2_id" name="it618_class2_id" value="'.$it618_class2_id.'">
	<input type="hidden" id="it618_qclass11_id" name="it618_qclass11_id" value="'.$it618_qclass11_id.'">
	<input type="hidden" id="it618_qclass12_id" name="it618_qclass12_id" value="'.$it618_qclass12_id.'">
	<input type="hidden" id="it618_qclass13_id" name="it618_qclass13_id" value="'.$it618_qclass13_id.'">
	<input type="hidden" id="it618_qclass21_id" name="it618_qclass21_id" value="'.$it618_qclass21_id.'">
	<input type="hidden" id="it618_qclass22_id" name="it618_qclass22_id" value="'.$it618_qclass22_id.'">
	<input type="hidden" id="it618_qclass23_id" name="it618_qclass23_id" value="'.$it618_qclass23_id.'">
	<input type="hidden" id="it618_qclass24_id" name="it618_qclass24_id" value="'.$it618_qclass24_id.'">
	<input type="hidden" id="it618_qclass25_id" name="it618_qclass25_id" value="'.$it618_qclass25_id.'">
	<input type="hidden" id="it618_qclass26_id" name="it618_qclass26_id" value="'.$it618_qclass26_id.'">
	<input type="hidden" name="it618_qtypeid" value="'.$it618_qtypeid.'">
	
	<select id="it618_class3_id" name="it618_class3_id" style="margin-right:0px'.$e3css.'">'.$tmpclass3.'</select>
	<select id="it618_class4_id" name="it618_class4_id" style="margin-right:0px'.$e4css.'">'.$tmpclass4.'</select>
	<select id="it618_qclass3_id" name="it618_qclass3_id" style="margin-right:0px'.$q3css.'">'.$tmpqclass3.'</select>
	<select id="it618_qclass4_id" name="it618_qclass4_id" style="margin-right:0px'.$q4css.'">'.$tmpqclass4.'</select>
	
	<div style="margin-top:6px">
	<input type="text" id="classq1" readonly="readonly" style="width:796px;border:#e8e8e8 1px solid;padding:4px 3px;background-color:#fff" onclick="showclasstree(1)"> <a id="classtreebtn1" href="javascript:" onclick="showclasstree(1)" style="font-size:12px">'.$it618_exam_lang['s1248'].$class_set['classname_q1'].'</a>
	</div>
	
	<div style="margin-top:6px'.$q2css.'">
	<input type="text" id="classq2" readonly="readonly" style="width:796px;border:#e8e8e8 1px solid;padding:4px 3px;background-color:#fff" onclick="showclasstree(2)"> <a id="classtreebtn2" href="javascript:" onclick="showclasstree(2)" style="font-size:12px">'.$it618_exam_lang['s1248'].$class_set['classname_q2'].'</a>
	</div>
	
	<div id="classtree1" class="classtree" style="display:none;position:absolute;background-color:#f9f9f9;border:#e8e8e8 1px solid;width:520px;height:520px;z-index:1000">
		<iframe id="iframe1" width="100%" height="520" marginwidth="0" marginheight="0" frameborder="no" src="'.$_G['siteurl'].'plugin.php?id=it618_exam:classtree&type=1&cid='.$cid1.'"></iframe>
	</div>
	<div id="classtree2" class="classtree" style="display:none;position:absolute;background-color:#f9f9f9;border:#e8e8e8 1px solid;width:520px;height:520px;z-index:1000">
		<iframe id="iframe2" width="100%" height="520" marginwidth="0" marginheight="0" frameborder="no" src="'.$_G['siteurl'].'plugin.php?id=it618_exam:classtree&type=2&cid='.$cid2.'"></iframe>
	</div>

</td></tr>';

echo '
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_exam/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_exam/kindeditor/plugins/code/prettify.js"></script>

<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_name_adds"]\', {
			cssPath : \'source/plugin/it618_exam/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_exam/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			newlineTag:"br",
			afterBlur: function () { this.sync(); },
			items : [\'source\', \'|\', \'undo\', \'redo\', \'|\', \'image\',\'multiimage\',\'it618media\', \'|\', \'it618latex\', \'subscript\',
        \'superscript\', \'|\', \'fullscreen\']
		});
	});

	function showclasstree(index) {
		var cityObj = $("#classq"+index);
		var cityOffset = $("#classq"+index).offset();
	
		IT618_EXAM("#classtree"+index).css({left:cityOffset.left + "px", top:cityOffset.top + cityObj.outerHeight() + "px"}).slideDown("fast");
		
		if(index==1){
			IT618_EXAM("body").bind("mousedown", onBodyDown1);
		}else{
			IT618_EXAM("body").bind("mousedown", onBodyDown2);
		}
	}
	
	function hideclasstree(index) {
		IT618_EXAM("#classtree"+index).fadeOut("fast");
		if(index==1){
			IT618_EXAM("body").unbind("mousedown", onBodyDown1);
		}else{
			IT618_EXAM("body").unbind("mousedown", onBodyDown2);
		}
	}
	
	function onBodyDown1(event) {
		if (!(event.target.id == "classtreebtn1" || event.target.id == "classq1" || event.target.id == "classtree1")) {
			hideclasstree(1);
		}
	}
	
	function onBodyDown2(event) {
		if (!(event.target.id == "classtreebtn2" || event.target.id == "classq2" || event.target.id == "classtree2")) {
			hideclasstree(2);
		}
	}
	
	function checkvalue(about){
		if(!confirm(about)){
			return false;
		}
	}

	KindEditor.ready(function(K) {
		var uploadbutton = K.uploadbutton({
			button : K(\'#btn_upfiletxt\')[0],
			fieldName : \'imgFile\',
			url : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?dir=file&filetype=txt\',
			afterUpload : function(data) {
				if (data.error === 0) {
					var url = K.formatUrl(data.url, \'absolute\');
					K(\'#it618_name_dao\').val(url);
				} else {
					alert(data.message);
				}
			},
			afterError : function(str) {
				alert(str);
			}
		});
		uploadbutton.fileBox.change(function(e) {
			uploadbutton.submit();
		});
		
		var uploadbutton2 = K.uploadbutton({
			button : K(\'#btn_upfilexls\')[0],
			fieldName : \'imgFile\',
			url : \'source/plugin/it618_exam/kindeditor/php/upload_json.php?dir=file&filetype=xls\',
			afterUpload : function(data) {
				if (data.error === 0) {
					var url = K.formatUrl(data.url, \'absolute\');
					K(\'#it618_name_dao2\').val(url);
				} else {
					alert(data.message);
				}
			},
			afterError : function(str) {
				alert(str);
			}
		});
		uploadbutton2.fileBox.change(function(e) {
			uploadbutton2.submit();
		});
		
		getdaomode(2);
	});
</script>';

if($_GET['it618_qtypeid']==1||$_GET['it618_qtypeid']==2)$aboutstr1=$it618_exam_lang['s588'];
if($_GET['it618_qtypeid']==3)$aboutstr1=$it618_exam_lang['s589'];
if($_GET['it618_qtypeid']==4)$aboutstr1=$it618_exam_lang['s590'];
if($_GET['it618_qtypeid']==5)$aboutstr1=$it618_exam_lang['s591'];

if($_GET['it618_qtypeid']==1||$_GET['it618_qtypeid']==2)$aboutstr2=$it618_exam_lang['s841'];
if($_GET['it618_qtypeid']==3||$_GET['it618_qtypeid']==5)$aboutstr2=$it618_exam_lang['s842'];
if($_GET['it618_qtypeid']==4)$aboutstr2=$it618_exam_lang['s843'];

$aboutstr3=$it618_exam_lang['s1458'];

$divdao2optcss='display:none';
if($_GET['it618_qtypeid']==1||$_GET['it618_qtypeid']==2)$divdao2optcss='';

$excelindex='
<option value="1">A</option><option value="2">B</option><option value="3">C</option><option value="4">D</option><option value="5">E</option>
<option value="6">F</option><option value="7">G</option><option value="8">H</option><option value="9">I</option><option value="10">J</option>
<option value="11">K</option><option value="12">L</option><option value="13">M</option><option value="14">N</option><option value="15">O</option>
<option value="16">P</option><option value="17">Q</option><option value="18">R</option><option value="19">S</option><option value="20">T</option>
<option value="21">U</option><option value="22">V</option><option value="23">W</option><option value="24">X</option><option value="25">Y</option>
<option value="26">Z</option>';

$excel_name=str_replace('<option value="2">','<option value="2" selected="selected">',$excelindex);
$excel_option1=str_replace('<option value="3">','<option value="3" selected="selected">',$excelindex);
$excel_option2=str_replace('<option value="6">','<option value="6" selected="selected">',$excelindex);
$excel_answer=str_replace('<option value="8">','<option value="8" selected="selected">',$excelindex);
$excel_about=str_replace('<option value="9">','<option value="9" selected="selected">',$excelindex);
	
echo '
<style>
.divabout font{font-weight:bold}
</style>

<tr><td colspan=2 style="position:relative">
<div id="divabout1" style="position:absolute;right:0px;top:20px;width:300px;font-size:13px;line-height:18px;display:none" class="divabout">'.$aboutstr1.'</div>
<div id="divabout2" style="position:absolute;right:0px;top:20px;width:300px;font-size:13px;line-height:18px" class="divabout">'.$aboutstr2.'</div>
<div id="divabout3" style="position:absolute;right:0px;top:20px;width:300px;font-size:13px;line-height:18px;display:none" class="divabout">'.$aboutstr3.'</div>
<div style="padding-top:10px;padding-bottom:10px">'.it618_exam_getlang('s836').'<select name="daomode" onchange="getdaomode(this.value)"><option value=1>'.it618_exam_getlang('s837').'</option><option value=2 selected=selected>'.it618_exam_getlang('s838').'</option><option value=3>'.it618_exam_getlang('s1413').'</option></select></div>

<div id="divdao1">
'.it618_exam_getlang('s583').'<br><br><textarea name="it618_name_adds" style="width:800px;height:300px;padding:3px"></textarea>
<div style="line-height:26px;margin-top:10px;display:none" id="divreplace">
'.$it618_exam_lang['s793'].'<input type="text" name="replaccon1" style="width:735px"><br>
'.$it618_exam_lang['s794'].'<input type="text" name="replaccon2" style="width:735px">
</div>
<input type="submit" class="btn" name="it618submit_adds" value="'.it618_exam_getlang('s585').'" onclick="return checkvalue(\''.$it618_exam_lang['s600'].'\')"/> <input type="checkbox" id="chkreplace" name="chkreplace" style="vertical-align:middle" onchange="if(this.checked)document.getElementById(\'divreplace\').style.display=\'\';else document.getElementById(\'divreplace\').style.display=\'none\';" value="1"><label for="chkreplace">'.$it618_exam_lang['s795'].'</label>

<br><br>
'.it618_exam_getlang('s584').'<br><input id="it618_name_dao" name="it618_name_dao" class="txt" style="width:300px"><input type="submit" class="btn" id="btn_upfiletxt" value="'.it618_exam_getlang('s587').'"/><br>
</div>

<div id="divdao2" style="display:">
<style>
.daocss{color:blue;font-weight:bold;margin-right:6px;text-align:center}
.must{color:red}
</style>
<br>'.$it618_exam_lang['s1454'].'<br><br>
'.$it618_exam_lang['s1414'].'<select class="daocss must" name="excel_name">'.$excel_name.'</select>
<span style="'.$divdao2optcss.'">'.$it618_exam_lang['s1415'].$it618_exam_lang['s1457'].'<select class="daocss must" name="excel_option1">'.$excel_option1.'</select>'.$it618_exam_lang['s1465'].' <select class="daocss must" name="excel_option2">'.$excel_option2.'</select></span>
'.$it618_exam_lang['s1416'].'<select class="daocss must" name="excel_answer">'.$excel_answer.'</select>
'.$it618_exam_lang['s1453'].'<select class="daocss" name="excel_about"><option value="0">'.$it618_exam_lang['s1456'].'</option>'.$excel_about.'</select>
<br><br><input id="it618_name_dao2" name="it618_name_dao2" class="txt" style="width:300px"><input type="submit" class="btn" id="btn_upfilexls" value="'.it618_exam_getlang('s587').'"/><br>
</div>

<input type="submit" class="btn" name="it618submit_dao2" value="'.it618_exam_getlang('s586').'" onclick="return checkvalue(\''.$it618_exam_lang['s601'].'\')"/></td></tr>

<script>
function getdaomode(i){
	document.getElementById("divdao1").style.display="none";
	document.getElementById("divdao2").style.display="none";
	
	document.getElementById("divabout1").style.display="none";
	document.getElementById("divabout2").style.display="none";
	document.getElementById("divabout3").style.display="none";
	document.getElementById("divabout"+i).style.display="";
	
	if(i==3){
		document.getElementById("divdao2").style.display="";
	}else{
		document.getElementById("divdao1").style.display="";
	}
}
</script>
';

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/sc_footer.func.php';
?>