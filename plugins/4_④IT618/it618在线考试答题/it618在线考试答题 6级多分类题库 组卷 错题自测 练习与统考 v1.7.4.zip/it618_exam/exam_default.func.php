<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_exam/exam_function.func.php';

if($pagetype=='search'||$templatename=='default'){
	if($_GET['sw']==''||!isset($_GET['sw']))$searchsw=$it618_exam['exam_sw'];else $searchsw=dhtmlspecialchars($_GET['sw']);
}
if($searchsw!='')$sw=' style="display:none"';

$homeurl=it618_exam_getrewrite('exam_home','','plugin.php?id=it618_exam:index');
$listurl=it618_exam_getrewrite('exam_list','0@0','plugin.php?id=it618_exam:list');
$searchurl=it618_exam_getrewrite('exam_search','','plugin.php?id=it618_exam:search');

$exam_hotsw=explode(',',$it618_exam['exam_hotsw']);
for($i=0;$i<count($exam_hotsw);$i++){
	$tmpurl=it618_exam_getrewrite('exam_search','','plugin.php?id=it618_exam:search&sw='.urlencode($exam_hotsw[$i]),'?sw='.urlencode($exam_hotsw[$i]));
	$hotsw.='<a href="'.$tmpurl.'">'.$exam_hotsw[$i].'</a>';
}

$stylecount=C::t('#it618_exam#it618_exam_style')->count_by_isok();
$it618_exam_style=C::t('#it618_exam#it618_exam_style')->fetch_by_isok();

$topnav=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('topnav');

if($templatename=='default'){
	$footer=C::t('#it618_exam#it618_exam_set')->getsetvalue_by_setname('footer');
	$tmparr=explode('src="',$it618_exam['exam_logo']);
	$tmparr1=explode('"',$tmparr[1]);
	$logosrc=$tmparr1[0];
}

if($_G['uid']>0){
	C::t('#it618_exam#it618_exam_sale')->update_lastactivity_by_uid(TIMESTAMP,$_G['uid']);
	if(C::t('#it618_exam#it618_exam_shop')->count_by_it618_uid($_G['uid'])>0){
		if(C::t('#it618_exam#it618_exam_shop')->fetch_it618_state_by_it618_uid($_G['uid'])==2){
			$adminurl=it618_exam_getrewrite('exam_sc','','plugin.php?id=it618_exam:sc');
		}
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		$it618_members = $_G['cache']['plugin']['it618_members'];
		if($it618_members['members_ishome']==1||$it618_members['members_ishome']==2){
			$tmpmembers='<li>
					<a href="javascript:" class="login-link" id="it618_members"><img src="source/plugin/it618_members/images/logo.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px" />'.$it618_members['members_homename'].'</a> 
					</li>';
		}
	}
	
	if($IsCredits==1){
		$tmpcredits='<li>
					<a href="javascript:" class="login-link" id="it618_credits"><img src="source/plugin/it618_credits/images/bigico.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px" />'.it618_exam_getlang('s960').'</a> 
					</li>';
	}
	
	if($IsGroup==1){
		$tmpgroup='<li>
					<a href="javascript:" class="login-link" id="it618_group"><img src="source/plugin/it618_group/images/group.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px" />'.it618_exam_getlang('s829').'</a> 
					</li>';
	}
	
	$count=C::t('#it618_exam#it618_exam_gwc')->count_by_uid($_G['uid']);
	if($count>0)$count='<font color=red>'.$count.'</font>';
	$gwcurl=it618_exam_getrewrite('exam_gwc','','plugin.php?id=it618_exam:gwc');
	
	$usermenu='<ul class="login cl">
				<li class="login-link">'.it618_exam_getusername($_G['uid']).'</li>
				'.$tmpmembers.'
				'.$tmpcredits.'
				'.$tmpgroup.'
				<li style="padding-top:5px;"><a href="'.$gwcurl.'" target="_blank"><img src="source/plugin/it618_exam/images/gwc.png" style="vertical-align:middle;height:13px;margin-top:-1px"/> '.it618_exam_getlang('t187').'(<span id="gwccount">'.$count.'</span>)</a></li>
                <li class="dropdown dropdown-account">
                    <p class="textwarp">
                        <em class="text">'.it618_exam_getlang('s456').'</em>
                        <i class="triangle"></i>
                        <em class="account-num" style="display:none;"></em>
					</p>
                    <ul class="htul">
						<li>
						<a href="javascript:" id="mysale">'.it618_exam_getlang('s457').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mysubscribe">'.it618_exam_getlang('s1403').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mygoods">'.it618_exam_getlang('s73').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mytest">'.it618_exam_getlang('s458').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="myerr">'.it618_exam_getlang('s846').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="myutest">'.it618_exam_getlang('s448').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mycollect">'.it618_exam_getlang('s1654').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mytestpj"><font color=green>'.it618_exam_getlang('s459').'</font></a> 
				    	</li>
                    </ul>
                </li>
				'.$templatestylestr.'
                <li><a class="login-link" href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'">['.it618_exam_getlang('s460').']</a></li>
			   </ul>';
}else{
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if($it618_members['members_isok']==1){
		$usermenu='<ul class="login cl">
				'.$templatestylestr.'
                <li><a class="login-link it618_members_login" href="javascript:">['.it618_exam_getlang('s461').']</a></li>
                <li><a class="login-link it618_members_reg" href="javascript:">['.it618_exam_getlang('s462').']</a></li>    
               </ul>';
	}else{
		$usermenu='<ul class="login cl">
				'.$templatestylestr.'
                <li><a class="login-link" href="member.php?mod=logging&action=login">['.it618_exam_getlang('s461').']</a></li>
                <li><a class="login-link" href="member.php?mod='.$RegName.'">['.it618_exam_getlang('s462').']</a></li>    
               </ul>';
	}
}

foreach(C::t('#it618_exam#it618_exam_focus')->fetch_all_by_type_order(2) as $it618_exam_focus) {
	if($it618_exam_focus['it618_url']!=''){
		$str_focus2.='<li><a href="'.$it618_exam_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_exam/images/a.gif" imgsrc="'.$it618_exam_focus['it618_img'].'" width="1200" height="63" /></a></li>';
	}else{
		$str_focus2.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_exam/images/a.gif" imgsrc="'.$it618_exam_focus['it618_img'].'" width="1200" height="63" /></li>';
	}
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	if(isset($_GET['reg']))$winapireg='winapireg';
	$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','',$winapireg);
	if($it618_exam['exam_saletel']==2){
		if($_G['uid']>0)$it618_members_telbd=it618_members_getmembers($_GET['id'],'#it618_members_telbd','plugin.php?id=it618_members:home&ac=salebdtel').'<div id="it618_members_telbd"></div>';
	}
}

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$it618_credits_index=it618_credits_getcredits($_GET['id'],'#it618_credits');
	$it618_credits_buygroup=it618_credits_getcredits($_GET['id'],'#vippaybtn','plugin.php?id=it618_credits:do&dotype=buygroup');
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_uc=it618_group_getgroup($_GET['id'],'#it618_group');
	$it618_group_ad=it618_group_getad($_GET['id'],2);
}
//From: Dism��taobao��com
?>