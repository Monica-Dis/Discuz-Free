<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_exam_questions extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_exam_questions';
		$this->_pk = 'id';
		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	
	public function count_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table, $shopid));
	}
	
	public function count_by_shopid_name($shopid, $name) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d and it618_name=%s", array($this->_table, $shopid, $name));
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_it618_shopid_by_id($id) {
		return DB::result_first("SELECT it618_shopid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $shopid = 0, $class1_id = 0, $class2_id = 0, $class3_id = 0, $class4_id = 0, $qclass11_id = 0, $qclass12_id = 0, $qclass13_id = 0, $qclass21_id = 0, $qclass22_id = 0, $qclass23_id = 0, $qclass24_id = 0, $qclass25_id = 0, $qclass26_id = 0, $qclass3_id = 0, $qclass4_id = 0, $qtypeid = 0, $it618_name = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $class1_id, $class2_id, $class3_id, $class4_id, $qclass11_id, $qclass12_id, $qclass13_id, $qclass21_id, $qclass22_id, $qclass23_id, $qclass24_id, $qclass25_id, $qclass26_id, $qclass3_id, $qclass4_id, $qtypeid, $it618_name);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $shopid = 0, $class1_id = 0, $class2_id = 0, $class3_id = 0, $class4_id = 0, $qclass11_id = 0, $qclass12_id = 0, $qclass13_id = 0, $qclass21_id = 0, $qclass22_id = 0, $qclass23_id = 0, $qclass24_id = 0, $qclass25_id = 0, $qclass26_id = 0, $qclass3_id = 0, $qclass4_id = 0, $qtypeid = 0, $it618_name = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $class1_id, $class2_id, $class3_id, $class4_id, $qclass11_id, $qclass12_id, $qclass13_id, $qclass21_id, $qclass22_id, $qclass23_id, $qclass24_id, $qclass25_id, $qclass26_id, $qclass3_id, $qclass4_id, $qtypeid, $it618_name);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $shopid = 0, $class1_id = 0, $class2_id = 0, $class3_id = 0, $class4_id = 0, $qclass11_id = 0, $qclass12_id = 0, $qclass13_id = 0, $qclass21_id = 0, $qclass22_id = 0, $qclass23_id = 0, $qclass24_id = 0, $qclass25_id = 0, $qclass26_id = 0, $qclass3_id = 0, $qclass4_id = 0, $qtypeid = 0, $it618_name = '') {
		
		$parameter = array($this->_table);
		$wherearr = array();
		
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($shopid)) {
			$parameter[] = $shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($class1_id)) {
			$parameter[] = $class1_id;
			$wherearr[] = 'it618_class1_id=%d';
		}
		if(!empty($class2_id)) {
			$parameter[] = $class2_id;
			$wherearr[] = 'it618_class2_id=%d';
		}
		if(!empty($class3_id)) {
			$parameter[] = $class3_id;
			$wherearr[] = 'it618_class3_id=%d';
		}
		if(!empty($class4_id)) {
			$parameter[] = $class4_id;
			$wherearr[] = 'it618_class4_id=%d';
		}
		if(!empty($qclass11_id)) {
			$parameter[] = $qclass11_id;
			$wherearr[] = 'it618_qclass11_id=%d';
		}
		if(!empty($qclass12_id)) {
			$parameter[] = $qclass12_id;
			$wherearr[] = 'it618_qclass12_id=%d';
		}
		if(!empty($qclass13_id)) {
			$parameter[] = $qclass13_id;
			$wherearr[] = 'it618_qclass13_id=%d';
		}
		if(!empty($qclass21_id)) {
			$parameter[] = $qclass21_id;
			$wherearr[] = 'it618_qclass21_id=%d';
		}
		if(!empty($qclass22_id)) {
			$parameter[] = $qclass22_id;
			$wherearr[] = 'it618_qclass22_id=%d';
		}
		if(!empty($qclass23_id)) {
			$parameter[] = $qclass23_id;
			$wherearr[] = 'it618_qclass23_id=%d';
		}
		if(!empty($qclass24_id)) {
			$parameter[] = $qclass24_id;
			$wherearr[] = 'it618_qclass24_id=%d';
		}
		if(!empty($qclass25_id)) {
			$parameter[] = $qclass25_id;
			$wherearr[] = 'it618_qclass25_id=%d';
		}
		if(!empty($qclass26_id)) {
			$parameter[] = $qclass26_id;
			$wherearr[] = 'it618_qclass26_id=%d';
		}
		if(!empty($qclass3_id)) {
			$parameter[] = $qclass3_id;
			$wherearr[] = 'it618_qclass3_id=%d';
		}
		if(!empty($qclass4_id)) {
			$parameter[] = $qclass4_id;
			$wherearr[] = 'it618_qclass4_id=%d';
		}
		if(!empty($qtypeid)) {
			$parameter[] = $qtypeid;
			$wherearr[] = 'it618_qtypeid=%d';
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = 'it618_name LIKE %s';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>