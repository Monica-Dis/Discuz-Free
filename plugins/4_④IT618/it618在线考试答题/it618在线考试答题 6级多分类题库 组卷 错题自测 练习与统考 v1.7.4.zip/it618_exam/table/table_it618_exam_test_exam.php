<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_exam_test_exam extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_exam_test_exam';
		$this->_pk = 'id';
		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	
	public function count_by_pid($pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
	
	public function count_by_pid_uid($pid, $uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d and it618_uid=%d", array($this->_table, $pid, $uid));
	}
	
	public function fetch_by_pid_uid_state12($pid, $uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_pid=%d and it618_uid=%d and (it618_state=1 or it618_state=2)", array($this->_table, $pid, $uid));
	}
	
	public function count_by_pid_uid_isvip($pid, $uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d and it618_uid=%d and it618_isvip=1", array($this->_table, $pid, $uid));
	}
	
	public function count_by_pid_uid_issale($pid, $uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d and it618_uid=%d and it618_isvip!=1", array($this->_table, $pid, $uid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_tieid($tieid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_tieid=%d", array($this->_table, $tieid));
	}
	
	public function count_by_search($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		return DB::result_first("SELECT count(1) FROM %t s LEFT JOIN ".DB::table('it618_exam_goods')." g ON s.it618_pid=g.id $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT s.* FROM %t s LEFT JOIN ".DB::table('it618_exam_goods')." g ON s.it618_pid=g.id $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 's.it618_shopid=%d';
		}
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "(g.it618_name LIKE %s or g.it618_description LIKE %s)";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 's.it618_uid=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 's.it618_btime>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 's.it618_btime<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function fetch_all_by_it618_pid($it618_pid, $start = 0, $limit = 0) {
		$data = array();
		$query = DB::query("SELECT * FROM %t WHERE it618_pid=%d ORDER BY it618_testscore desc,it618_etime".DB::limit($start, $limit), array($this->_table,$it618_pid));
		while($value = DB::fetch($query)) {
			$value['it618_rank']=DB::result_first("SELECT COUNT(1)+1 FROM %t WHERE it618_pid=%d and it618_testscore>".$value['it618_testscore'], array($this->_table, $it618_pid));
			$data[] = $value;
		}
		return $data;
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>