<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_exam_test extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_exam_test';
		$this->_pk = 'id';
		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	
	public function count_by_tid_uid($tid, $uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_tid=%d AND it618_uid=%d", array($this->_table, $tid, $uid));
	}
	
	public function fetch_by_tid_uid($tid, $uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_tid=%d AND it618_uid=%d", array($this->_table, $tid, $uid));
	}
	
	public function count_by_pid_uid($pid, $uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d AND it618_uid=%d", array($this->_table, $pid, $uid));
	}
	
	public function fetch_by_pid_uid($pid, $uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_pid=%d AND it618_uid=%d", array($this->_table, $pid, $uid));
	}
	
	public function fetch_by_uid_etime($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d order by it618_etime desc", array($this->_table, $uid));
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_it618_testcode($testcode) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_testcode=%s", array($this->_table, $testcode));
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pid = 0, $tid = 0, $ips='') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $uid, $pid, $tid, $ips);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pid = 0, $tid = 0, $ips='', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $uid, $pid, $tid, $ips);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pid = 0, $tid = 0, $ips='') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($shopid)) {
			$parameter[] = $shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($uid)) {
			$parameter[] = $uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($pid)) {
			$parameter[] = $pid;
			$wherearr[] = 'it618_pid=%d';
		}
		if(!empty($tid)) {
			$parameter[] = $tid;
			$wherearr[] = 'it618_tid=%d';
		}
		if(!empty($ips)) {
			$parameter[] = '%'.$ips.'%';
			$wherearr[] = "it618_ips LIKE %s";
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>