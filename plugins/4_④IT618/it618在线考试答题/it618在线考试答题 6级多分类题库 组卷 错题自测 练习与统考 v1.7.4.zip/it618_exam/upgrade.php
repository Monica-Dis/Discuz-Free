<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_exam_class_vipgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_vipgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_errquestions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_eid` int(10) unsigned NOT NULL default '0',
  `it618_qid` int(10) unsigned NOT NULL default '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_uid` int(10) unsigned NOT NULL default '0',
  `it618_eid` int(10) unsigned NOT NULL default '0',
  `it618_pici` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_testid` varchar(30) NOT NULL,
  `it618_name` varchar(30) NOT NULL,
  `it618_bz` varchar(300) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL default '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_goods_bmuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL default '0',
  `it618_uid` int(10) unsigned NOT NULL default '0',
  `it618_testid` varchar(30) NOT NULL,
  `it618_name` varchar(30) NOT NULL,
  `it618_bz` varchar(300) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL default '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isadderr` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_utest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ip` varchar(20) NOT NULL,
  `it618_ips` varchar(1000) NOT NULL,
  `it618_testcode` varchar(32) NOT NULL,
  `it618_ucode` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_utest_exam` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_answertype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_qindex` int(10) unsigned NOT NULL default '1',
  `it618_questioncount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rightcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_examtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_utest_exam_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_eid` int(10) unsigned NOT NULL default '0',
  `it618_qid` int(10) unsigned NOT NULL default '0',
  `it618_value` text NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  `it618_isbj` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_uexamwork` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_code` varchar(32) NOT NULL,
  `it618_tmpid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_shop'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_waplogo', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_shop')." add `it618_waplogo` varchar(255) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_shop')." add `it618_logourl` varchar(255) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_shop')." add `it618_waplogourl` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_questions'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_about', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_questions')." add `it618_about` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_class3_id', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_questions')." add `it618_class3_id` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_class4_id', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_questions')." add `it618_class4_id` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_qclass24_id', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_questions')." add `it618_qclass24_id` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_qclass25_id', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_questions')." add `it618_qclass25_id` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_qclass26_id', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_questions')." add `it618_qclass26_id` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	
	$sql = "update ".DB::table('it618_exam_questions')." set it618_qclass21_id=0,it618_qclass22_id=0,it618_qclass23_id=0"; 
	DB::query($sql);
	
$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_exam_qclass2`;
CREATE TABLE IF NOT EXISTS `pre_it618_exam_qclass2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_parenttype` int(10) unsigned NOT NULL default '0',
  `it618_parentclassid` int(10) unsigned NOT NULL default '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_questions_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_qid` int(10) unsigned NOT NULL default '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);
}

if(!in_array('it618_optioncount', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_questions')." add `it618_optioncount` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_questions'));
	while($it618_exam_questions = DB::fetch($query)) {
		$opcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_exam_questions_option')." WHERE it618_qid=".$it618_exam_questions['id']);
		$sql = "update ".DB::table('it618_exam_questions')." set it618_optioncount=$opcount where id=".$it618_exam_questions['id']; 
		DB::query($sql);
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_goods'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_answertype', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods')." add `it618_answertype` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
}

if(!in_array('it618_ischat', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods')." add `it618_ischat` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_isnote', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods')." add `it618_isnote` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_ispl', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods')." add `it618_ispl` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_exam_questions')." modify column `it618_name` text NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_questions')." modify column `it618_value` text NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_questions')." modify column `it618_about` text NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_questions_option')." modify column `it618_name` text NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_issd', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods')." add `it618_issd` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

if(!in_array('it618_ispm', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods')." add `it618_ispm` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

if(!in_array('it618_chkstate', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods')." add `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

if(!in_array('it618_mancount', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods')." add `it618_mancount` int(10) unsigned NOT NULL DEFAULT '80';"; 
	DB::query($sql);
}

if(!in_array('it618_pici', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods')." add `it618_pici` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_goods_lesson'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_mcqscore', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods_lesson')." add `it618_mcqscore` float(6,1) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_shareabout', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods_lesson')." add `it618_shareabout` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_exam_goods_lesson')." modify column `it618_name` text NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_goods_lesson')." add `it618_about` text NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_isdispoption', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods_lesson')." add `it618_isdispoption` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_goods_questions'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_mcqscore', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_goods_questions')." add `it618_mcqscore` float(6,1) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_test_exam'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_answertype', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_test_exam')." add `it618_answertype` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
}

if(!in_array('it618_isadderr', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_test_exam')." add `it618_isadderr` int(10) unsigned NOT NULL default '1';"; 
	DB::query($sql);
}

if(!in_array('it618_tieid', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_test_exam')." add `it618_tieid` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_test_exam_questions'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_lid', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_test_exam_questions')." add `it618_lid` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_test_exam_questions'));
	while($it618_exam_test_exam_questions = DB::fetch($query)) {
		$it618_exam_goods_questions=C::t('#it618_exam#it618_exam_goods_questions')->fetch_by_pid_qid($it618_exam_test_exam_questions['it618_pid'],$it618_exam_test_exam_questions['it618_qid']);
		DB::query("update ".DB::table('it618_exam_test_exam_questions')." set it618_lid=".$it618_exam_goods_questions['it618_lid']." where id=".$it618_exam_test_exam_questions['id']);
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_test_exam_questions'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_mcqscore', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_test_exam_questions')." add `it618_mcqscore` float(6,1) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_shop'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_order', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_shop')." add `it618_order` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_wxmessagecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_shop')." add `it618_wxmessagecount` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods_count'));
	while($it618_exam_goods_count1 = DB::fetch($query)) {
		$tmpcount=C::t('#it618_exam#it618_exam_test_exam')->count_by_pid_uid_issale($it618_exam_goods_count1['it618_pid'],$it618_exam_goods_count1['it618_uid']);
		DB::query("update ".DB::table('it618_exam_goods_count')." set it618_testcount=$tmpcount where id=".$it618_exam_goods_count1['id']);
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_gwc'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_iseditprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_gwc')." add `it618_iseditprice` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_exam_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_pinsaleid', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_sale')." add `it618_pinsaleid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_vipzk', $col_field)){
	$sql = "Alter table ".DB::table('it618_exam_sale')." add `it618_vipzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_sale')." add `it618_sfmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_sale')." add `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_exam_gwcsale')." add `it618_vipzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_gwcsale')." add `it618_sfmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_exam_gwcsale')." add `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_sale'));
	while($it618_exam_sale = DB::fetch($query)) {
		$it618_sfmoney = $it618_exam_sale['it618_price']*$it618_exam_sale['it618_count']-$it618_exam_sale['it618_quanmoney'];
		$it618_sfscore = $it618_exam_sale['it618_score']*$it618_exam_sale['it618_count'];
		$sql = "update ".DB::table('it618_exam_sale')." set it618_sfmoney=$it618_sfmoney,it618_sfscore=$it618_sfscore where id=".$it618_exam_sale['id']; 
		DB::query($sql);
	}
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vZGlzY3V6X3BsdWdpbl9pdDYxOF9leGFtX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vaW5zdGFsbC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2V4YW0vdXBncmFkZS5waHA='));
?>