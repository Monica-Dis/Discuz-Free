<?php

 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_crowd_kd', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_crowd#it618_crowd_kd')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_url' => trim($_GET['it618_url'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_url_array = !empty($_GET['newit618_url']) ? $_GET['newit618_url'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
	
		if($newit618_name_array[$key] != '') {
			
			C::t('#it618_crowd#it618_crowd_kd')->insert(array(
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_url' => trim($newit618_url_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_crowd_lang['s33'].$ok1.' '.$it618_crowd_lang['s34'].$ok2.' '.$it618_crowd_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_kd&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

if(count($reabc)!=11)return;
if(submitcheck('it618sercsubmit')) {
	if($_GET['beforeword']) {
		$extrasql = "AND it618_name LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
	}
}
showformheader("plugins&identifier=$identifier&cp=admin_kd&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_crowd_kd');
	showsubmit('it618sercsubmit', $it618_crowd_lang['s597'], $it618_crowd_lang['s598'].' <input name="beforeword" value="" class="txt" />');
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_crowd_kd')." w WHERE 1 $extrasql");
	
	echo '<tr><td colspan=4>'.$it618_crowd_lang['s599'].$count.'</td></tr>';
	showsubtitle(array('', $it618_crowd_lang['s600'], $it618_crowd_lang['s601'], $it618_crowd_lang['s602'], $it618_crowd_lang['s603']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_kd')." WHERE 1 $extrasql ORDER BY it618_order");
	while($it618_crowd = DB::fetch($query)) {
		$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_crowd_sale')." WHERE it618_kdid=".$it618_crowd['id']);
		$disabled="";
		if($salecount>0)$disabled="disabled=\"disabled\"";
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_crowd[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_crowd[id]]\" value=\"$it618_crowd[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_crowd[id]]\" value=\"$it618_crowd[it618_name]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:600px\" name=\"it618_url[$it618_crowd[id]]\" value=\"$it618_crowd[it618_url]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:50px\" name=\"it618_order[$it618_crowd[id]]\" value=\"$it618_crowd[it618_order]\">",
			$salecount
		));
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		return [
		[[1,''], [1,'<input type="text" class="txt" style="width:200px" name="newit618_name[]">'], [1,'<input type="text" class="txt" style="width:600px" name="newit618_url[]">'], [1, ' <input class="txt" style="width:50px" type="text" name="newit618_order[]">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="4"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=11)return;
showtablefooter();/*Dism��taobao��com*/
?>