<?php

 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/kefu.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/kefu.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_crowd/kefu.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}
		
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/kefu.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_crowd/kefu.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$it618_addr_title=\''.trim($_GET['it618_addr_title'])."';\n";
		
		$fileData .= '$it618_addr=\''.trim($_GET['it618_addr'])."';\n";
		
		$fileData .= '$it618_time_title=\''.trim($_GET['it618_time_title'])."';\n";
		
		$fileData .= '$it618_time=\''.trim($_GET['it618_time'])."';\n";
		
		$fileData .= '$it618_tel_title=\''.trim($_GET['it618_tel_title'])."';\n";
		
		$fileData .= '$it618_tel=\''.trim($_GET['it618_tel'])."';\n";
		
		$fileData .= '$it618_title=\''.trim($_GET['it618_title'])."';\n";
		
		$fileData .= '$it618_qq=\''.trim($_GET['it618_qq'])."';\n";
		
		$fileData .= '$it618_wx=\''.trim($_GET['it618_wx'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_crowd_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_kefu&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_kefu&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_crowd_kefu');

if($it618_addr_title=='')$it618_addr_title=$it618_crowd_lang['s364'];
if($it618_time_title=='')$it618_time_title=$it618_crowd_lang['s365'];
if($it618_tel_title=='')$it618_tel_title=$it618_crowd_lang['s366'];

echo '

<tr><td width=100><input type="text" class="txt" style="width:80px;margin-right:0" name="it618_addr_title" value="'.dhtmlspecialchars($it618_addr_title).'">'.$it618_crowd_lang['s120'].'</td><td><input type="text" class="txt" style="width:700px" name="it618_addr" value="'.dhtmlspecialchars($it618_addr).'"></td></tr>

<tr><td><input type="text" class="txt" style="width:80px;margin-right:0" name="it618_time_title" value="'.dhtmlspecialchars($it618_time_title).'">'.$it618_crowd_lang['s120'].'</td><td><input type="text" class="txt" style="width:700px" name="it618_time" value="'.dhtmlspecialchars($it618_time).'"></td></tr>

<tr><td><input type="text" class="txt" style="width:80px;margin-right:0" name="it618_tel_title" value="'.dhtmlspecialchars($it618_tel_title).'">'.$it618_crowd_lang['s120'].'</td><td><input type="text" class="txt" style="width:700px" name="it618_tel" value="'.dhtmlspecialchars($it618_tel).'"></td></tr>

<tr><td>'.$it618_crowd_lang['s367'].'</td><td><input type="text" class="txt" style="width:700px" name="it618_title" value="'.dhtmlspecialchars($it618_title).'"><br><font color=#999>'.$it618_crowd_lang['s368'].'</font></td></tr>

<tr><td>'.$it618_crowd_lang['s369'].'</td><td><input type="text" class="txt" style="width:700px" name="it618_qq" value="'.dhtmlspecialchars($it618_qq).'"></td></tr>

<tr><td>'.$it618_crowd_lang['s370'].'</td><td><input type="text" class="txt" style="width:700px" name="it618_wx" value="'.dhtmlspecialchars($it618_wx).'"><br><font color=#999>'.$it618_crowd_lang['s371'].'</font></td></tr>


<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_crowd_lang['s641'].'" /></div></td></tr>
';

if(count($reabc)!=11)return;
showtablefooter();/*Dism��taobao��com*/

?>