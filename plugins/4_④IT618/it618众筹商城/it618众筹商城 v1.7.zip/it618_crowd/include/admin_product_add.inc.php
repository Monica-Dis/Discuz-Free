<?php
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	
	$id=C::t('#it618_crowd#it618_crowd_goods')->insert(array(
		'it618_class1_id' => $_GET['it618_class1_id'],
		'it618_class2_id' => $_GET['it618_class2_id'],
		'it618_name' => $_GET['it618_name'],
		'it618_ptype' => $_GET['it618_ptype'],
		'it618_jfid' => $_GET['it618_jfid'],
		'it618_unit' => it618_crowd_getlang('s608'),
		'it618_description' => $_GET['it618_description'],
		'it618_seokeywords' => $_GET['it618_seokeywords'],
		'it618_seodescription' => $_GET['it618_seodescription'],
		'it618_picbig' => $_GET['it618_picbig'],
		'it618_picbig1' => $_GET['it618_picbig1'],
		'it618_picbig2' => $_GET['it618_picbig2'],
		'it618_picbig3' => $_GET['it618_picbig3'],
		'it618_picbig4' => $_GET['it618_picbig4'],
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	), true);
	
	for($i=0;$i<=4;$i++){
		if($i==0)$tmpi='';else $tmpi=$i;
		$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
		
		if($get_it618_picbig!=''){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
			it618_crowd_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);

		}
	}

	cpmsg(it618_crowd_getlang('s359'), "action=plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_crowd_goods');

$query1 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_crowd_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$jfidstrtmp.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_crowd/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_crowd/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_crowd/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_crowd/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_crowd/kindeditor/plugins/code/prettify.js"></script>
<script charset="utf-8" src="source/plugin/it618_crowd/js/Calendar.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_crowd/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_crowd/kindeditor/php/upload_json.php?imgwidth=913'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_crowd/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false
		});
		
		var editor2 = K.create(\'textarea[name="it618_message_buy"]\', {
			cssPath : \'source/plugin/it618_crowd/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_crowd/kindeditor/php/upload_json.php?imgwidth=913'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_crowd/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image11\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url11\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url11\').val(url);
						K(\'#img11\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image12\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url12\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url12\').val(url);
						K(\'#img12\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image13\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url13\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url13\').val(url);
						K(\'#img13\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image14\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url14\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url14\').val(url);
						K(\'#img14\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	function checkvalue(){
		if(document.getElementById("it618_class2_id").value=="0"){
			alert("'.it618_crowd_getlang('s361').'");
			return false;
		}
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_crowd_getlang('s362').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_crowd_getlang('s372').'");
			return false;
		}
	}
	
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
</script>

<tr><td width=80>'.it618_crowd_getlang('s374').'</td><td><select name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)"><option value="0">'.it618_crowd_getlang('s375').'</option>'.$classtmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_crowd_getlang('s376').'</option></select> </td></tr>
<tr><td>'.it618_crowd_getlang('s839').'</td><td><input type="text" class="txt" style="width:400px;margin-right:0" id="it618_name" name="it618_name"> </td></tr>
<tr><td>'.it618_crowd_getlang('s378').'</td><td><select name="it618_ptype"><option value=1>'.it618_crowd_getlang('s381').'</option><option value=2>'.it618_crowd_getlang('s382').'</option></select> <font color=red>'.it618_crowd_getlang('s362').'</font></td></tr>
<tr><td>'.it618_crowd_getlang('s17').'</td><td><select name="it618_jfid">'.$jfidstrtmp.'</select> <font color=red>'.it618_crowd_getlang('s10').'</font></td></tr>
<tr><td>'.it618_crowd_getlang('s394').'</td><td><img id="img1" width="80" height="80" align="absmiddle"/><input type="text" id="url1" name="it618_picbig" readonly="readonly"/> <input type="button" id="image1" value="'.it618_crowd_getlang('s395').'" />   '.it618_crowd_getlang('s397').'</td></tr>
<tr><td></td><td><img id="img11"  width="80" height="80" align="absmiddle"/><input type="text" id="url11" name="it618_picbig1" readonly="readonly" /> <input type="button" id="image11" value="'.it618_crowd_getlang('s395').'" /> <input type="button" value="'.it618_crowd_getlang('s396').'" onclick="delpic(1)" /> <img id="img12"  width="80" height="80" align="absmiddle"/><input type="text" id="url12" name="it618_picbig2" readonly="readonly"/> <input type="button" id="image12" value="'.it618_crowd_getlang('s395').'" /> <input type="button" value="'.it618_crowd_getlang('s396').'" onclick="delpic(2)" /></td></tr>
<tr><td></td><td><img id="img13" width="80" height="80" align="absmiddle"/><input type="text" id="url13" name="it618_picbig3" readonly="readonly"/> <input type="button" id="image13" value="'.it618_crowd_getlang('s395').'"/> <input type="button" value="'.it618_crowd_getlang('s396').'" onclick="delpic(3)" />  <img id="img14" width="80" height="80" align="absmiddle"/><input type="text" id="url14" name="it618_picbig4" readonly="readonly"/> <input type="button" id="image14" value="'.it618_crowd_getlang('s395').'" /> <input type="button" value="'.it618_crowd_getlang('s396').'" onclick="delpic(4)"/></td></tr>
<tr><td>'.it618_crowd_getlang('s403').'</td><td><textarea name="it618_description" style="width:696px;height:60px;"></textarea></td></tr>
<tr><td>'.it618_crowd_getlang('s404').'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;"></textarea></td></tr>
<tr><td>'.it618_crowd_getlang('s405').'</td><td><input type="text" class="txt" style="width:696px;margin-right:0" name="it618_seokeywords"></td></tr>
<tr><td>'.it618_crowd_getlang('s406').'</td><td><textarea name="it618_seodescription" style="width:696px;height:60px;"></textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_crowd_getlang('s407').'" /></div></td></tr>';

if(count($reabc)!=11)return;
showtablefooter();/*Dism��taobao��com*/
?>