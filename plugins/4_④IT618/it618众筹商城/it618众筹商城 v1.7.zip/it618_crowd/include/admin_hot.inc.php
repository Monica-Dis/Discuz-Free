<?php
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(C::t('#it618_crowd#it618_crowd_set')->count_by_setname('zjsalegoods')==0){
	C::t('#it618_crowd#it618_crowd_set')->insert(array(
		'setname' => 'zjsalegoods',
		'setvalue' => '15,8,1'
	), true);
	C::t('#it618_crowd#it618_crowd_set')->insert(array(
		'setname' => 'weeksalegoods',
		'setvalue' => '15,8,2'
	), true);
	C::t('#it618_crowd#it618_crowd_set')->insert(array(
		'setname' => 'newgoods',
		'setvalue' => '15,8,3'
	), true);
	C::t('#it618_crowd#it618_crowd_set')->insert(array(
		'setname' => 'hotgoods',
		'setvalue' => '15,8,4'
	), true);
}

if(submitcheck('it618submit')){
	$hot1=getids($_GET['hot1'],'SELECT * FROM '.DB::table('it618_crowd_class2').' WHERE id=');
	$hot2=getids($_GET['hot2'],'SELECT * FROM '.DB::table('it618_crowd_class2').' WHERE id=');
	$hot3=getids($_GET['hot3'],'SELECT * FROM '.DB::table('it618_crowd_goods').' WHERE id=');
	
	if(C::t('#it618_crowd#it618_crowd_set')->count_by_setname($setname)==0){
		C::t('#it618_crowd#it618_crowd_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $hot1.'@@@'.$hot2.'@@@'.$hot3
		), true);
	}else{
		$it618_crowd_set=C::t('#it618_crowd#it618_crowd_set')->fetch_by_setname($setname);
		C::t('#it618_crowd#it618_crowd_set')->update($it618_crowd_set['id'],array(
			'setvalue' => $hot1.'@@@'.$hot2.'@@@'.$hot3
		));
	}
	
	$it618_crowd_set=C::t('#it618_crowd#it618_crowd_set')->fetch_by_setname('zjsalegoods');
	C::t('#it618_crowd#it618_crowd_set')->update($it618_crowd_set['id'],array(
		'setvalue' => $_GET['zjsalegoods']
	));
	
	$it618_crowd_set=C::t('#it618_crowd#it618_crowd_set')->fetch_by_setname('weeksalegoods');
	C::t('#it618_crowd#it618_crowd_set')->update($it618_crowd_set['id'],array(
		'setvalue' => $_GET['weeksalegoods']
	));
	
	$it618_crowd_set=C::t('#it618_crowd#it618_crowd_set')->fetch_by_setname('newgoods');
	C::t('#it618_crowd#it618_crowd_set')->update($it618_crowd_set['id'],array(
		'setvalue' => $_GET['newgoods']
	));
	
	$it618_crowd_set=C::t('#it618_crowd#it618_crowd_set')->fetch_by_setname('hotgoods');
	C::t('#it618_crowd#it618_crowd_set')->update($it618_crowd_set['id'],array(
		'setvalue' => $_GET['hotgoods']
	));

	cpmsg($it618_crowd_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_hot&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

function getids($ids,$sql){
	$tmpids=',';
	$tmpidsarr=explode(',',$ids);
	for($i=0;$i<count($tmpidsarr);$i++){
		$id=intval($tmpidsarr[$i]);
		if($id>0){
			if(DB::result_first($sql.$id)>0){
				$tmpids.=','.$id;
			}
		}
	}
	if($tmpids==','){
		$tmpids='';
	}else{
		$tmpids=str_replace(',,','',$tmpids);
	}
	
	return $tmpids;
}

$it618_crowd_set=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname($setname);
$value=explode('@@@',$it618_crowd_set);

$tmpidsarr=explode(',',$value[0]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);

	if($i==count($tmpidsarr)-1)$tmpstr='';else $tmpstr=' , ';
	$valuename[0].=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_crowd_class2')." WHERE id=".$id).$tmpstr;
}

$tmpidsarr=explode(',',$value[1]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);

	if($i==count($tmpidsarr)-1)$tmpstr='';else $tmpstr=' , ';
	$valuename[1].=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_crowd_class2')." WHERE id=".$id).$tmpstr;
}

$tmpidsarr=explode(',',$value[2]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	
	$valuename[2].='<option>'.DB::result_first("SELECT it618_name FROM ".DB::table('it618_crowd_goods')." WHERE id=".$id).'</option>';
}

$it618_crowd_set=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname($setname);
$value=explode('@@@',$it618_crowd_set);

$zjsalegoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('weeksalegoods');
$newgoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('newgoods');
$hotgoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('hotgoods');

showformheader("plugins&identifier=$identifier&cp=admin_hot&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1].'<span style="font-weight:normal;color:red;margin-left:90px">'.$it618_crowd_lang['s69'].'</span>','it618_crowd_set');

echo '
<tr><td>'.$it618_crowd_lang['s70'].'</td><td><input type="text" name="hot1" style="width:800px;" value="'.$value[0].'"></td></tr>
<tr><td></td><td style="color:green">'.$valuename[0].'</td></tr>
<tr><td>'.$it618_crowd_lang['s71'].'</td><td><input type="text" name="hot2" style="width:800px;" value="'.$value[1].'"></td></tr>
<tr><td></td><td style="color:green">'.$valuename[1].'</td></tr>
<tr><td>'.$it618_crowd_lang['s72'].'</td><td><input type="text" name="hot3" style="width:800px;" value="'.$value[2].'"></td></tr>
<tr><td></td><td><select style="color:green;">'.$valuename[2].'</select></td></tr>
<tr><td>'.$it618_crowd_lang['t91'].'</td><td>'.$it618_crowd_lang['s991'].'<input type="text" name="zjsalegoods" style="width:80px;" value="'.$zjsalegoods.'">  '.$it618_crowd_lang['s992'].'15,8,1</td></tr>
<tr><td>'.$it618_crowd_lang['t93'].'</td><td>'.$it618_crowd_lang['s991'].'<input type="text" name="weeksalegoods" style="width:80px;" value="'.$weeksalegoods.'"> '.$it618_crowd_lang['s992'].'15,8,2</td></tr>
<tr><td>'.$it618_crowd_lang['s989'].'</td><td>'.$it618_crowd_lang['s991'].'<input type="text" name="newgoods" style="width:80px;" value="'.$newgoods.'"> '.$it618_crowd_lang['s992'].'15,8,3</td></tr>
<tr><td>'.$it618_crowd_lang['s990'].'</td><td>'.$it618_crowd_lang['s991'].'<input type="text" name="hotgoods" style="width:80px;" value="'.$hotgoods.'"> '.$it618_crowd_lang['s992'].'15,8,4</td></tr>
';

showsubmit('it618submit', $it618_crowd_lang['s23']);
if(count($reabc)!=10)return;
showtablefooter();/*Dism��taobao��com*/

?>