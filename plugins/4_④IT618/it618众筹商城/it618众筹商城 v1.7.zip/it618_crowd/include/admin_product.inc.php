<?php
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

$it618sql = "1";

$state0='';$state1='';$state2='';$state3='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and g.it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and g.it618_state = 1";$state2='selected="selected"';}

$ptype0='';$ptype1='';
if($_GET['ptype']==0){$ptype0='selected="selected"';}
if($_GET['ptype']==1){$it618sql .= " and g.it618_ptype = 1";$ptype1='selected="selected"';}
if($_GET['ptype']==2){$it618sql .= " and g.it618_ptype = 2";$ptype2='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';$orderby4='';
if($_GET['orderby']==0){$it618orderby = "it618_order,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "it618_salecount desc";$orderby2='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "it618_views desc";$orderby3='selected="selected"';}
if($_GET['orderby']==3){$it618orderby = "it618_price desc";$orderby4='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'].'&ptype='.$_GET['ptype'].'&orderby='.$_GET['orderby'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_crowd_sale')." WHERE it618_pid=".$delid);
		if($salecount<=0){
			$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($delid);
			
			$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
			$qrcodeurl=md5($tmpurl);
			$qrcodeurl='source/plugin/it618_crowd/qrcode/'.$qrcodeurl.'.png';
			$tmparr=explode("source",$qrcodeurl);
			$qrcodeurl=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($qrcodeurl)){
				$result=unlink($qrcodeurl);
			}
			
			for($i=0;$i<=4;$i++){
				if($i==0)$tmpi='';else $tmpi=$i;
				$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
				
				if($it618_crowd_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
					$tmparr=explode("source",$it618_crowd_goods['it618_picbig'.$tmpi]);
					$tmparr1=explode("http://",$it618_crowd_goods['it618_picbig'.$tmpi]);
					$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_picbig)&&count($tmparr1)==1){
						$result=unlink($it618_picbig);
					}
				}
				
				$file_ext=strtolower(substr($it618_crowd_goods['it618_picbig'.$tmpi],strrpos($it618_crowd_goods['it618_picbig'.$tmpi], '.')+1)); 
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
				if(file_exists($it618_smallurl)){
					$result=unlink($it618_smallurl);
				}
			}
			
			C::t('#it618_crowd#it618_crowd_goods')->delete_by_id($delid);
			$del=$del+1;
		}else{
			$flag=1;
		}
	}
	
	if($flag==1)$tmpstr='<br><br>'.$it618_crowd_lang['s1775'];

	cpmsg(it618_crowd_getlang('s342').$del.$tmpstr,  "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_on')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		if($_GET['it618_price'][$delid]>0&&$_GET['it618_pricecount'][$delid]>0){
			$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($delid);
			if($it618_crowd_goods['it618_state']==0){
				DB::query("update ".DB::table('it618_crowd_goods')." set it618_state=1 where id=".$delid);
				$ok=$ok+1;
			}
		}
	}

	cpmsg(it618_crowd_getlang('s343').$ok,  "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_down')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($delid);
		if($it618_crowd_goods['it618_state']==1){
			DB::query("update ".DB::table('it618_crowd_goods')." set it618_state=0 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg(it618_crowd_getlang('s344').$ok,  "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			C::t('#it618_crowd#it618_crowd_goods')->update($id,array(
				'it618_name' => $_GET['it618_name'][$id],
				'it618_description' => $_GET['it618_description'][$id],
				'it618_unit' => $_GET['it618_unit'][$id],
				'it618_count' => $_GET['it618_count'][$id],
				'it618_isbm' => $_GET['it618_isbm'][$id]
			));
			
			$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($id);
			
			if($it618_crowd_goods['it618_ptype']==2){
				C::t('#it618_crowd#it618_crowd_goods')->update($id,array(
					'it618_count' => $_GET['it618_count'][$id]
				));
			}
			
			if($_GET['it618_price'][$id]>0&&$_GET['it618_pricecount'][$id]>0){
				C::t('#it618_crowd#it618_crowd_goods')->update($id,array(
					'it618_price' => $_GET['it618_price'][$id],
					'it618_pricecount' => $_GET['it618_pricecount'][$id],
				));
			}
	
			$ok=$ok+1;
		}
	}

	cpmsg(it618_crowd_getlang('s345').$ok,  "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

$tmp='<option value="0">'.it618_crowd_getlang('s346').'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_class2')." where it618_class1_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

showformheader("plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql);
showtableheaders($strtmptitle[$cp1],'it618_crowd_sum');
	echo '<tr><td colspan=14>'.$it618_crowd_lang['s94'].' <input type="text" name="key" style="width:180px"> '.it618_crowd_getlang('s99').' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_crowd_getlang('s100').'</option></select> '.it618_crowd_getlang('s101').' <select name="state"><option value=0 '.$state0.'>'.it618_crowd_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_crowd_getlang('s103').'</option><option value=2 '.$state2.'>'.it618_crowd_getlang('s104').'</option></select> '.it618_crowd_getlang('s379').' <select name="ptype"><option value=0 '.$ptype0.'>'.it618_crowd_getlang('s380').'</option><option value=1 '.$ptype1.'>'.it618_crowd_getlang('s381').'</option><option value=2 '.$ptype2.'>'.it618_crowd_getlang('s382').'</option></select> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_crowd_getlang('s110').'</option><option value=1 '.$orderby1.'>'.it618_crowd_getlang('s111').'</option><option value=2 '.$orderby2.'>'.it618_crowd_getlang('s112').'</option><option value=3 '.$orderby3.'>'.it618_crowd_getlang('s113').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_crowd_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_crowd#it618_crowd_goods')->count_by_search($it618sql,'',$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	echo '<tr><td colspan=14>'.it618_crowd_getlang('s114').$count.'<span style="float:right;color:red">'.$it618_crowd_lang['s11'].'</span></td></tr>';
	showsubtitle(array('',it618_crowd_getlang('s115'),it618_crowd_getlang('s116'),it618_crowd_getlang('s121'),it618_crowd_getlang('s12'),it618_crowd_getlang('s36'),it618_crowd_getlang('s862'),it618_crowd_getlang('s122')));
	
	$n=1;
	foreach(C::t('#it618_crowd#it618_crowd_goods')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['key'],0,0,$startlimit,$ppp
	) as $it618_crowd_goods) {
		
		if($it618_crowd_goods['it618_ptype']==1)$it618_ptype1='selected="selected"';else $it618_ptype1="";
		if($it618_crowd_goods['it618_ptype']==2)$it618_ptype2='selected="selected"';else $it618_ptype2="";
		
		if($it618_crowd_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		
		if($it618_crowd_goods['it618_state']==0)$it618_state='<font color=blue>'.it618_crowd_getlang('s103').'</font>';
		if($it618_crowd_goods['it618_state']==1)$it618_state='<font color=green>'.it618_crowd_getlang('s104').'</font>';
		
		$class1name = C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($it618_crowd_goods['it618_class1_id']);
		$class2name = C::t('#it618_crowd#it618_crowd_class2')->fetch_it618_name_by_id($it618_crowd_goods['it618_class2_id']);
		
		$preurl="action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql;
		$preurl=str_replace("&","@",$preurl);
		
		if($it618_crowd_goods['it618_ptype']==2){
			$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_crowd_goods_km')." WHERE it618_pid=".$it618_crowd_goods['id']);
			$ptypestr='<a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product_km&pmod=admin_product&operation='.$operation.'&do='.$do.'&cp1=3&pid='.$it618_crowd_goods['id'].'&preurl='.$preurl.'">'.it618_crowd_getlang('s837').'(<font color=red>'.$kmcount.'</font>)</a>';
		}else{
			$ptypestr='<input type="text" class="txt" style="width:50px;margin-right:1px;color:green;" name="it618_count['.$it618_crowd_goods['id'].']" value="'.$it618_crowd_goods['it618_count'].'">';
		}
		
		$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
			if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
			$pricecount=$it618_crowd_sale['it618_pricecount'];
			$price=$it618_crowd_sale['it618_price'];
		}else{
			$pricecount=$it618_crowd_goods['it618_pricecount'];
			$price=$it618_crowd_goods['it618_price'];
			
			if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
			}
		}
		
		if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
		}
		$salestr=$price.$jfidstr.'<br>'.$pricecount.$it618_crowd_lang['s13'];
		
		$sumprice=C::t('#it618_crowd#it618_crowd_crowdsale')->sumprice_by_pid($it618_crowd_goods['id']);
		
		if($it618_crowd_goods['it618_unit']=='')$it618_unit=it618_crowd_getlang('s608');else $it618_unit=$it618_crowd_goods['it618_unit'];
		$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
		
		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_crowd_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_crowd_goods['id'].'</label>',
			'<a style="float:left" href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.'"><img src="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" width="60" height="60" align="absmiddle"/></a><div style="float:left;margin-left:3px;line-height:20px"><input type="text" class="txt" style="width:360px;margin-right:3px;margin-bottom:3px" name="it618_name['.$it618_crowd_goods['id'].']" value="'.$it618_crowd_goods['it618_name'].'"><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product_edit&pmod=admin_product&operation='.$operation.'&do='.$do.'&cp1=2&pid='.$it618_crowd_goods[id].'&preurl='.$preurl.'">'.it618_crowd_getlang('s351').'</a><br><textarea name="it618_description['.$it618_crowd_goods['id'].']" style="width:360px;height:30px">'.$it618_crowd_goods['it618_description'].'</textarea></div>',
			$ptypestr.'<br><input type="text" class="txt" style="width:50px;margin-top:3px" name="it618_unit['.$it618_crowd_goods['id'].']" value="'.$it618_unit.'">',
			'<input type="text" class="txt" style="width:60px;margin-right:3px;color:red" name="it618_price['.$it618_crowd_goods['id'].']" value="'.$it618_crowd_goods['it618_price'].'">'.$jfidstr.'<br>'.'<input type="text" class="txt" style="width:60px;margin-top:3px;margin-right:3px" name="it618_pricecount['.$it618_crowd_goods['id'].']" value="'.$it618_crowd_goods['it618_pricecount'].'">'.$it618_crowd_lang['s13'],
			$salestr,
			it618_crowd_getlang('s118').'<font color=red>'.$it618_crowd_goods['it618_views'].'</font><br>'.it618_crowd_getlang('s119').'<font color=red>'.$it618_crowd_goods['it618_salecount'].'</font>'.'<br>'.$jfidstr.it618_crowd_getlang('s120').'<font color=red>'.$sumprice.'</font>',
			'<input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_crowd_goods['id'].']" '.$it618_isbm_checked.' value="1"><label for="chk_isbm'.$n.'">'.$it618_crowd_lang['s868'].'</label>',
			$it618_state
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_crowd_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_crowd_getlang('s352').'" onclick="return confirm(\''.it618_crowd_getlang('s353').'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.it618_crowd_getlang('s354').'"/> <input type="submit" class="btn" name="it618submit_on" value="'.it618_crowd_getlang('s355').'" onclick="return confirm(\''.it618_crowd_getlang('s356').'\')" /> <input type="submit" class="btn" name="it618submit_down" value="'.it618_crowd_getlang('s357').'" onclick="return confirm(\''.it618_crowd_getlang('s358').'\')" /> '.$it618_crowd_lang['s19'].'<input type=hidden value=1 name=page /></div></td></tr>';

showtablefooter();/*Dism��taobao��com*/
$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_crowd_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
echo '
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	</script>';

echo '<script charset="utf-8" src="source/plugin/it618_crowd/js/Calendar.js"></script>
	  <script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
if(count($reabc)!=11)return;
showtablefooter();/*Dism��taobao��com*/
?>