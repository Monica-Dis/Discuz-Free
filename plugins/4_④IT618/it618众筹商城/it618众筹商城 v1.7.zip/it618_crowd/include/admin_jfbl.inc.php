<?php

 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$jfidstrtmp.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
				$fileData .= '$it618_jfbl['.$i.']=\''.trim($_GET['it618_jfbl'.$i])."';\n";
			}
		}
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_crowd_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_jfbl&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_jfbl&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_crowd_kefu');

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$jfidstrtmp.='<tr><td width=50>1'.$_G['setting']['extcredits'][$i]['title'].' =</td><td><input type="text" class="txt" style="width:80px;margin-right:3px" name="it618_jfbl'.$i.'" value="'.$it618_jfbl[$i].'">'.$it618_crowd_lang['s400'].'</td></tr>';
	}
}

echo '

'.$jfidstrtmp.'
<tr><td colspan="15">'.$it618_crowd_lang['s401'].'</td></tr>

<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_crowd_lang['s641'].'" /></div></td></tr>
';

if(count($reabc)!=11)return;
showtablefooter();/*Dism��taobao��com*/

?>