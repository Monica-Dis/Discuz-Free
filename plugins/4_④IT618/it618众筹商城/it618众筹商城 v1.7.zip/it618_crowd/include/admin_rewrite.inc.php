<?php
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$crowd_home=\''.'crowd'."';\n";
		$fileData .= '$crowd_list=\''.'crowd_list'."';\n";
		$fileData .= '$crowd_search=\''.'crowd_search'."';\n";
		$fileData .= '$crowd_gwc=\''.'crowd_gwc'."';\n";
		$fileData .= '$crowd_product=\''.'crowd_product'."';\n";
		$fileData .= '$crowd_wap=\''.'crowd_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$crowd_home1=\''.$urltype."';\n";
		$fileData .= '$crowd_list1=\'-{cid1}-{cid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$crowd_search1=\'-{cid1}-{cid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$crowd_gwc1=\''.$urltype."';\n";
		$fileData .= '$crowd_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$crowd_wap1=\'-{pagetype}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$crowd_home=\''.str_replace("-","",$_GET['crowd_home'])."';\n";
		$fileData .= '$crowd_list=\''.str_replace("-","",$_GET['crowd_list'])."';\n";
		$fileData .= '$crowd_search=\''.str_replace("-","",$_GET['crowd_search'])."';\n";
		$fileData .= '$crowd_sale=\''.str_replace("-","",$_GET['crowd_sale'])."';\n";
		$fileData .= '$crowd_gwc=\''.str_replace("-","",$_GET['crowd_gwc'])."';\n";
		$fileData .= '$crowd_product=\''.str_replace("-","",$_GET['crowd_product'])."';\n";
		$fileData .= '$crowd_wap=\''.str_replace("-","",$_GET['crowd_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$crowd_home1=\''.$urltype."';\n";
		$fileData .= '$crowd_list1=\'-{cid1}-{cid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$crowd_search1=\'-{cid1}-{cid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$crowd_sale1=\'-{cid1}-{page}'.$urltype."';\n";
		$fileData .= '$crowd_gwc1=\''.$urltype."';\n";
		$fileData .= '$crowd_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$crowd_wap1=\'-{pagetype}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_crowd_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_crowd_lang['s136'].'</font></td></tr>
<tr><td colspan="3">'.$it618_crowd_lang['s137'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_crowd_lang['s138'].'</th><th>'.$it618_crowd_lang['s139'].'</th><th>'.$it618_crowd_lang['s140'].'</th></tr>
<tr class="hover">
<td>'.$it618_crowd_lang['s141'].'</td><td></td><td class="longtxt"><input name="crowd_home" value="'.$crowd_home.'"/>'.$crowd_home.$crowd_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_crowd_lang['s142'].'</td><td>{cid1}, {cid2}, {order}, {page}</td><td class="longtxt"><input name="crowd_list" value="'.$crowd_list.'" />'.$crowd_list.$crowd_list1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_crowd_lang['s143'].'</td><td>{cid1}, {cid2}, {order}, {page}</td><td class="longtxt"><input name="crowd_search" value="'.$crowd_search.'" />'.$crowd_search.$crowd_search1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_crowd_lang['s842'].'</td><td>{cid1}, {page}</td><td class="longtxt"><input name="crowd_sale" value="'.$crowd_sale.'"/>'.$crowd_sale.$crowd_sale1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_crowd_lang['s1774'].'</td><td></td><td class="longtxt"><input name="crowd_gwc" value="'.$crowd_gwc.'"/>'.$crowd_gwc.$crowd_gwc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_crowd_lang['s144'].'</td><td>{pid}</td><td class="longtxt"><input name="crowd_product" value="'.$crowd_product.'" />'.$crowd_product.$crowd_product1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_crowd_lang['s147'].'</td><td>{pagetype}, {cid}, {page}</td><td class="longtxt"><input name="crowd_wap" value="'.$crowd_wap.'"/>'.$crowd_wap.$crowd_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_crowd_lang['s23']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_crowd_lang['s148'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_home.$urltype.'$ $1/plugin.php?id=it618_crowd:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:list&class1=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:list&class1=$2&class2=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:list&class1=$2&class2=$3&order=$4&page=$5&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_search.$urltype.'$ $1/plugin.php?id=it618_crowd:search&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:search&class1=$2&class2=$3&order=$4&page=$5&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_sale.$urltype.'$ $1/plugin.php?id=it618_crowd:sale&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_sale.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:sale&class1=$2&page=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_gwc.$urltype.'$ $1/plugin.php?id=it618_crowd:gwc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:product&pid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_wap.$urltype.'$ $1/plugin.php?id=it618_crowd:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:wap&pagetype=$2&cid=$3&page=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:wap&pagetype=$2&cid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$crowd_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:wap&pagetype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_crowd_lang['s149'].'</h1>
<pre class="colorbox">
'.$it618_crowd_lang['s150'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_home.$urltype.'$ plugin.php?id=it618_crowd:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_list.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_crowd:list&class1=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_crowd:list&class1=$1&class2=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_crowd:list&class1=$1&class2=$2&order=$3&page=$4&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_search.$urltype.'$ plugin.php?id=it618_crowd:search&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_crowd:search&class1=$1&class2=$2&order=$3&page=$4&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_sale.$urltype.'$ plugin.php?id=it618_crowd:sale&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_sale.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_crowd:sale&class1=$1&page=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_gwc.$urltype.'$ plugin.php?id=it618_crowd:gwc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_product.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_crowd:product&pid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_wap.$urltype.'$ plugin.php?id=it618_crowd:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_crowd:wap&pagetype=$1&cid=$2&page=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_crowd:wap&pagetype=$1&cid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$crowd_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_crowd:wap&pagetype=$1&%1</font>

</pre>

<h1>'.$it618_crowd_lang['s151'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$crowd_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:index&$3
RewriteRule ^(.*)/'.$crowd_list.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:list&class1=$2&$4
RewriteRule ^(.*)/'.$crowd_list.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:list&class1=$2&class2=$3&$5
RewriteRule ^(.*)/'.$crowd_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:list&class1=$2&class2=$3&order=$4&page=$5&$7
RewriteRule ^(.*)/'.$crowd_search.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:search&$3
RewriteRule ^(.*)/'.$crowd_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:search&class1=$2&class2=$3&order=$4&page=$5&$7
RewriteRule ^(.*)/'.$crowd_sale.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:sale&$3
RewriteRule ^(.*)/'.$crowd_sale.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:sale&class1=$2&page=$3&$5
RewriteRule ^(.*)/'.$crowd_gwc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:gwc&$3
RewriteRule ^(.*)/'.$crowd_product.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:product&pid=$2&$4
RewriteRule ^(.*)/'.$crowd_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:wap&$3
RewriteRule ^(.*)/'.$crowd_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:wap&pagetype=$2&cid=$3&page=$4&$6
RewriteRule ^(.*)/'.$crowd_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:wap&pagetype=$2&cid=$3&$5
RewriteRule ^(.*)/'.$crowd_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_crowd:wap&pagetype=$2&$4</font>

</pre>

<h1>'.$it618_crowd_lang['s152'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="crowd_home"&gt;
			&lt;match url="^(.*/)*'.$crowd_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_list1"&gt;
			&lt;match url="^(.*/)*'.$crowd_list.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:list&amp;amp;class1={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_list2"&gt;
			&lt;match url="^(.*/)*'.$crowd_list.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_list4"&gt;
			&lt;match url="^(.*/)*'.$crowd_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;order={R:4}&amp;amp;page={R:5}&amp;amp;{R:6}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_search"&gt;
			&lt;match url="^(.*/)*'.$crowd_search.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:search&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_search1"&gt;
			&lt;match url="^(.*/)*'.$crowd_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:search&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;order={R:4}&amp;amp;page={R:5}&amp;amp;{R:6}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_sale"&gt;
			&lt;match url="^(.*/)*'.$crowd_sale.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:sale&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_sale1"&gt;
			&lt;match url="^(.*/)*'.$crowd_sale.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:sale&amp;amp;class1={R:2}&amp;amp;page={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_gwc"&gt;
			&lt;match url="^(.*/)*'.$crowd_gwc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:gwc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_product"&gt;
			&lt;match url="^(.*/)*'.$crowd_product.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:product&amp;amp;pid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_wap"&gt;
			&lt;match url="^(.*/)*'.$crowd_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_wap1"&gt;
			&lt;match url="^(.*/)*'.$crowd_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;page={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_wap2"&gt;
			&lt;match url="^(.*/)*'.$crowd_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="crowd_wap3"&gt;
			&lt;match url="^(.*/)*'.$crowd_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_crowd:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$crowd_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:index&$2
endif
match URL into $ with ^(.*)/'.$crowd_list.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:list&class1=$2&$3
endif
match URL into $ with ^(.*)/'.$crowd_list.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:list&class1=$2&class2=$3&$4
endif
match URL into $ with ^(.*)/'.$crowd_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:list&class1=$2&class2=$3&order=$4&page=$5&$6
endif
match URL into $ with ^(.*)/'.$crowd_search.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:search&$2
endif
match URL into $ with ^(.*)/'.$crowd_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:search&class1=$2&class2=$3&order=$4&page=$5&$6
endif
match URL into $ with ^(.*)/'.$crowd_sale.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:sale&$2
endif
match URL into $ with ^(.*)/'.$crowd_sale.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:sale&class1=$2&page=$3&$4
endif
match URL into $ with ^(.*)/'.$crowd_gwc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:gwc&$2
endif
match URL into $ with ^(.*)/'.$crowd_product.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:product&pid=$2&$3
endif
match URL into $ with ^(.*)/'.$crowd_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:wap&$2
endif
match URL into $ with ^(.*)/'.$crowd_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:wap&pagetype=$2&cid=$3&page=$4&$5
endif
match URL into $ with ^(.*)/'.$crowd_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:wap&pagetype=$2&cid=$3&$4
endif
match URL into $ with ^(.*)/'.$crowd_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_crowd:wap&pagetype=$2&$3
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$crowd_home.$urltype.'$ $1/plugin.php?id=it618_crowd:index&$2 last;
rewrite ^([^\.]*)/'.$crowd_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:list&class1=$2&$3 last;
rewrite ^([^\.]*)/'.$crowd_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:list&class1=$2&class2=$3&$4 last;
rewrite ^([^\.]*)/'.$crowd_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:list&class1=$2&class2=$3&order=$4&page=$5&$6 last;
rewrite ^([^\.]*)/'.$crowd_search.$urltype.'$ $1/plugin.php?id=it618_crowd:search&$2 last;
rewrite ^([^\.]*)/'.$crowd_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:search&class1=$2&class2=$3&order=$4&page=$5&$6 last;
rewrite ^([^\.]*)/'.$crowd_gwc.$urltype.'$ $1/plugin.php?id=it618_crowd:gwc&$2 last;
rewrite ^([^\.]*)/'.$crowd_sale.$urltype.'$ $1/plugin.php?id=it618_crowd:sale&$2 last;
rewrite ^([^\.]*)/'.$crowd_sale.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:sale&class1=$2&page=$3&$4 last;
rewrite ^([^\.]*)/'.$crowd_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:product&pid=$2&$3 last;
rewrite ^([^\.]*)/'.$crowd_wap.$urltype.'$ $1/plugin.php?id=it618_crowd:wap&$2 last;
rewrite ^([^\.]*)/'.$crowd_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:wap&pagetype=$2&cid=$3&page=$4&$5 last;
rewrite ^([^\.]*)/'.$crowd_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:wap&pagetype=$2&cid=$3&$4 last;
rewrite ^([^\.]*)/'.$crowd_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_crowd:wap&pagetype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=11)return;
showtablefooter();/*Dism��taobao��com*/

?>