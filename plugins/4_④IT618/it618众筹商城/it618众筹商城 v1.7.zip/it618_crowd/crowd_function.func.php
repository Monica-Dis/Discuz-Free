<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
$metatitle = $it618_crowd['seotitle'];
$metakeywords = $it618_crowd['seokeywords'];
$metadescription = $it618_crowd['seodescription'];

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

if($_G['uid']>0){
	C::t('#it618_crowd#it618_crowd_sale')->update_lastactivity_by_uid(TIMESTAMP,$_G['uid']);
	
	if($IsCredits==1){
		$tmpcredits='<li>
					<a href="javascript:" id="it618_credits"><font color=green>'.it618_crowd_getlang('s960').'</font></a> 
					</li>';
	}
	
	$count=C::t('#it618_crowd#it618_crowd_gwc')->count_by_uid($_G['uid']);
	if($count>0)$count='<font color=red>'.$count.'</font>';
	$gwcurl=it618_crowd_getrewrite('crowd_gwc','','plugin.php?id=it618_crowd:gwc');
	
	$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
	if(in_array($_G['uid'],$crowd_adminuids)){
		$adminmenu='<li><a href="plugin.php?id=it618_crowd:admincrowdsale" target="_blank"><font color=blue>'.it618_crowd_getlang('s30').'</font></a></li><li><a href="plugin.php?id=it618_crowd:adminsale" target="_blank"><font color=blue>'.it618_crowd_getlang('s40').'</font></a></li>';
	}
	
	$usermenu='<ul class="login cl">
                <li><a class="login-link" href="'.it618_crowd_rewriteurl($_G['uid']).'">'.it618_crowd_getusername($_G['uid']).'</a> </li>
				<li style="padding-top:5px;"><a href="'.$gwcurl.'" target="_blank"><img src="source/plugin/it618_crowd/images/gwc.png" style="vertical-align:middle;height:11px;margin-top:-3px"/> '.it618_crowd_getlang('t187').'(<span id="gwccount">'.$count.'</span>)</a></li>
                <li class="dropdown dropdown-account">
                    <p class="textwarp">
                        <em class="text">'.it618_crowd_getlang('s456').'</em>
                        <i class="triangle"></i>
                        <em class="account-num" style="display:none;"></em>
					</p>
                    <ul class="htul">
						<li><a href="javascript:" id="mycrowdsale"><font color=green>'.it618_crowd_getlang('s455').'</font></a></li>
						<li><a href="javascript:" id="mysale"><font color=red>'.it618_crowd_getlang('s457').'</font></a></li>
						'.$tmpcredits.'
						'.$tmprz.'
						'.$adminmenu.'
                    </ul>
                </li>
                <li><a class="login-link" href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'">['.it618_crowd_getlang('s460').']</a></li>
			   </ul>';
}else{
	$usermenu='<ul class="login cl">
                <li><a class="login-link" href="member.php?mod=logging&action=login">['.it618_crowd_getlang('s461').']</a></li>
                <li><a class="login-link" href="member.php?mod='.$RegName.'">['.it618_crowd_getlang('s462').']</a></li>    
               </ul>';
}
//From: dis'.'m.tao'.'bao.com
?>