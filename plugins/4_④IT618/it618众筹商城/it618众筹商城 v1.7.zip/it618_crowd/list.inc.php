<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/crowd_default.func.php';

if($it618_crowd['crowd_wap']==1){
	if(crowd_is_mobile()){ 
		$tmpurl=it618_crowd_getrewrite('crowd_wap','','plugin.php?id=it618_crowd:wap');
		dheader("location:$tmpurl");
	}
}

$tmpidsarr=explode(',',$hotclassgoods[1]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_crowd_class2=C::t('#it618_crowd#it618_crowd_class2')->fetch_by_id($id);
	$tmpurl=it618_crowd_getrewrite('crowd_list',$it618_crowd_class2['it618_class1_id'].'@'.$id,'plugin.php?id=it618_crowd:list&class1='.$it618_crowd_class2['it618_class1_id'].'&class2='.$id);
	$listhotclass.='<li><a href="'.$tmpurl.'">'.$it618_crowd_class2['it618_classname'].'</a></li>';
}

foreach(C::t('#it618_crowd#it618_crowd_focus')->fetch_all_by_type_order(5) as $it618_crowd_focus) {
	if($it618_crowd_focus['it618_url']!=''){
		$str_focus5.='<li><a href="'.$it618_crowd_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus5.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

$class1=intval($_GET['class1']);
$class2=intval($_GET['class2']);
$order=intval($_GET['order']);

if($class1>0){
	$class1name=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($class1);
	$classtitle.=$class1name.' ';
	$tmpurl=it618_crowd_getrewrite('crowd_list','0@0@'.$order,'plugin.php?id=it618_crowd:list&class1=0&class2=0&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$class1name.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

if($class2>0){
	$tmpname=C::t('#it618_crowd#it618_crowd_class2')->fetch_it618_name_by_id($class2);
	$classtitle.=$tmpname.' ';
	$tmpurl=it618_crowd_getrewrite('crowd_list',$class1.'@0@'.$order,'plugin.php?id=it618_crowd:list&class1='.$class1.'&class2=0&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

$listnav.='@';
$listnav=str_replace('<i class="crumb-icon"></i>@','',$listnav);

if($class1==0)$current=' class="current"';else $current='';
$tmpurl=it618_crowd_getrewrite('crowd_list','0@0@'.$order,'plugin.php?id=it618_crowd:list&class1=0&class2=0&order='.$order);
$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_crowd_getlang('s466').'</a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
while($it618_crowd_class1 = DB::fetch($query)) {
	$goodscount=C::t('#it618_crowd#it618_crowd_goods')->count_by_search('it618_state=1','',$it618_crowd_class1['id']);
	if($class1==$it618_crowd_class1['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_crowd_getrewrite('crowd_list',$it618_crowd_class1['id'].'@0@'.$order,'plugin.php?id=it618_crowd:list&class1='.$it618_crowd_class1['id'].'&class2=0&order='.$order);
	$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_crowd_class1['it618_classname'].'<span>'.$goodscount.'</span></a></li>';
}

if($class1>0){
	if($class2==0)$current=' class="current"';else $current='';
	$tmpurl=it618_crowd_getrewrite('crowd_list',$class1.'@0@'.$order,'plugin.php?id=it618_crowd:list&class1='.$class1.'&class2=0&order='.$order);
	$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_crowd_getlang('s466').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_class2')." where it618_class1_id=".$class1." ORDER BY it618_order");
	while($it618_crowd_class2 = DB::fetch($query)) {
		$goodscount=C::t('#it618_crowd#it618_crowd_goods')->count_by_search('it618_state=1','',0,$it618_crowd_class2['id']);
		if($class2==$it618_crowd_class2['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_crowd_getrewrite('crowd_list',$class1.'@'.$it618_crowd_class2['id'].'@'.$order,'plugin.php?id=it618_crowd:list&class1='.$class1.'&class2='.$it618_crowd_class2['id'].'&order='.$order);
		$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_crowd_class2['it618_classname'].'<span>'.$goodscount.'</span></a></li>';
	}
}

if($order==0){$current0=' class="left current"';$it618orderby='jiexiao';}else $current0=' class="left"';
if($order==1){$current1=' class="current"';$it618orderby='it618_pricecount_find';}else $current1='';
if($order==2){$current2=' class="current"';$it618orderby='it618_salecount desc';}else $current2='';
if($order==3){$current3=' class="current"';$it618orderby='it618_price';}else $current3='';
if($order==4){$current4=' class="current"';$it618orderby='price_sale desc';}else $current4='';
if($order==5){$current5=' class="current"';$it618orderby='price_sale';}else $current5='';
if($order==6){$current6=' class="current"';$it618orderby='it618_time desc';}else $current6='';

for($i=0;$i<=6;$i++){
	$tmpurl=it618_crowd_getrewrite('crowd_list',$class1.'@'.$class2.'@'.$i,'plugin.php?id=it618_crowd:list&class1='.$class1.'&class2='.$class2.'&order='.$i);
	$orderurl[$i]=$tmpurl;
}

$ppp=$it618_crowd['crowd_listpagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$it618sql='it618_state=1';

$count = C::t('#it618_crowd#it618_crowd_goods')->count_by_search($it618sql,'',$class1,$class2);
$hrefsql=it618_crowd_getrewrite('crowd_list',$class1.'@'.$class2.'@'.$order.'@it618page','plugin.php?id=it618_crowd:list&class1='.$class1.'&class2='.$class2.'&order='.$order);
$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_crowd_multipage($multipage,$uri);

foreach(C::t('#it618_crowd#it618_crowd_goods')->fetch_all_by_search(
	$it618sql,$it618orderby,$class1,$class2,'',0,0,$startlimit,$ppp
) as $it618_crowd_goods) {
	
	$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
	
	if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
		$pricecount=$it618_crowd_sale['it618_pricecount'];
		$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
		$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
		$pricecountbl=$pricecount1/$pricecount*100;
		$price=$it618_crowd_sale['it618_price'];
	}else{
		$pricecount=$it618_crowd_goods['it618_pricecount'];
		$pricecount1=0;
		$pricecount2=$pricecount;
		$pricecountbl=$pricecount1/$pricecount*100;
		$price=$it618_crowd_goods['it618_price'];
		
		if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
		}
	}
	
	if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;
	
	if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
		DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
	}
	
	$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
	
	$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
	$str_goodslist.='<div class="goods">
				<a class="goods-img" href="'.$tmpurl.'" target="_blank">
				<img imgsrc="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" src="source/plugin/it618_crowd/images/a.gif" class="dynload" width="308" height="308" alt="'.$it618_name.'" />
				<span class="goods-place">'.$it618_crowd_goods['it618_description'].'</span>
				</a>
				<h3>
				<a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_name.'">'.$it618_name.'</a>
				</h3>
				<div class="goods-info">
					<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
					<div class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></div>
					<table class="graphtable"><tr>
					<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
					<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
					<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
					</tr></table>
				</div>
				</div>';
}

if($class1==0){
	$sql='';
}else{
	$sql=' and it618_class1_id='.$class1;
}
$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_goods')." where it618_state=1".$sql." ORDER BY it618_salecount desc limit 0,".$it618_crowd['crowd_listsalecount']);
while($it618_crowd_goods = DB::fetch($query)) {
	
	$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
	
	if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
		$pricecount=$it618_crowd_sale['it618_pricecount'];
		$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
		$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
		$pricecountbl=$pricecount1/$pricecount*100;
		$price=$it618_crowd_sale['it618_price'];
	}else{
		$pricecount=$it618_crowd_goods['it618_pricecount'];
		$pricecount1=0;
		$pricecount2=$pricecount;
		$pricecountbl=$pricecount1/$pricecount*100;
		$price=$it618_crowd_goods['it618_price'];
		
		if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
		}
	}
	
	if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;
	
	if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
		DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
	}
	
	$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
	
	$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
	$str_goodshot.='<div class="small-goods"><a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload" src="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" alt="'.$it618_name.'"/></a><h4><a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_name.'">'.$it618_name.'</a></h4>
	<div class="small-goods-info">
		<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
		<div class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></div>
		<table class="graphtable"><tr>
		<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
		<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
		<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
		</tr></table>
	</div>
	</div>';
}

$classtitle1=str_replace(' ','',$classtitle);
if($classtitle1=='')$classtitle=it618_crowd_getlang('s100');
$metatitle=$classtitle.' - '.$metatitle;

$pagetype='list';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:crowd_default');
?>