function tabCutover(e, t) {
	$(e).parent().attr("class"), $(e).parent().children().removeClass("current"), $(e).addClass("current"), $("." + t).parent().children().hide(), $("." + t).show(), $("." + t).children(".slider-warp").hasClass("click_start") && ($("." + t).children(".slider-warp").addClass("lazy_start"), startLsSwitch(), $("." + t).children(".slider-warp").removeClass("click_start"))
}

function new_checksubmit() {
	var e = $("#sw").val(),
		t = $.trim(e);
	return t || (t = $.trim($("#sw").prev().text()), lang1 != t && ($("#sw").prev().text("").hide(), $("#sw").val(t), ifclicksubmit = !1)), lang1 == t || "" == t ? !1 : (ifclicksubmit , !0)
}

$(function() {
	
}), $(document).ready(function() {
	function e() {
		i.each(function() {
			"undefined" != typeof $(this).attr("imgsrc") && $(this).offset().top < $(document).scrollTop() + $(window).height() && $(this).attr("src", $(this).attr("imgsrc")).removeAttr("imgsrc")
		})
	}
	var t = 0;
	t = $("#main .sort-filter").length > 0 ? 20 : $("#main").offset().top, $(window).width() < 965 ? ($(".sidebar-title").show(), $(".index-main").css("position", "relative"), $(".sidebar-warp").css("top", "0px")) : $(window).width() < 1200 ? ($(".index-main").css("position", "static"), $(".sidebar-warp").css("top", t + "px")) : ($(".index-main").css("position", "static"), $(".sidebar-warp").css("top", t + "px")), $(".scroll-block").css($(window).width() < 1320 ? {
		right: "0px",
		"margin-right": "0px"
	} : {
		right: "50%",
		"margin-right": "-665px"
	}), $(".banner-close").click(function() {
		$(this).parent().remove(), t = $("#main .sort-filter").length > 0 ? 20 : $("#main").offset().top, $(".sidebar-warp").css("top", t + "px")
	});
	var i = ($("#header .city h2").attr("city_id"), $(".dynload,.dynload1"));
	if ($(window).scroll(function() {
		e()
	}), e(), $(".dropdown-shopcart").length > 0 && bindhover(), $(".sidebar-switch").click(function() {
		$(".sidebar-warp").hasClass("sw-open") ? ($(".sidebar-warp").removeClass("sw-open"), $(".sidebar-warp").animate({
			marginRight: "-193px"
		}, 500, function() {
			$(".sidebar-title").show(), $(".sidebar-warp").css({
				"margin-right": 0,
				width: "31px"
			})
		}), $(".index-sidebar").animate({
			width: "30px"
		}, 500)) : ($(".sidebar-warp").addClass("sw-open"), $(".sidebar-title").hide(), $(".sidebar-warp").css({
			"margin-right": "-193px",
			width: "224px"
		}), $(".sidebar-warp").animate({
			marginRight: "0px"
		}, 500), $(".index-sidebar").animate({
			width: "223px"
		}, 500));
		var e = "",
			t = [];
		
	}), $(window).resize(function() {
		var e = $(this).width();
		965 > e ? ($(".sidebar-warp").hasClass("sw-open") ? $(".sidebar-title").hide() : $(".sidebar-title").show(), $(".index-main").css("position", "relative"), $(".sidebar-warp").css("top", "0px")) : 1200 > e ? ($(".sidebar-warp").hasClass("sw-open") ? $(".sidebar-title").hide() : $(".sidebar-title").show(), $(".index-main").css("position", "static"), $(".sidebar-warp").css("top", t + "px")) : ($(".sidebar-warp").removeClass("sw-open").attr("style", "auto"), $(".sidebar-title").hide(), $(".index-main").css("position", "static"), $(".sidebar-warp").css("top", t + "px"), $(".index-sidebar").attr("style", "auto")), $(".scroll-block").css(1320 > e ? {
			right: "0px",
			"margin-right": "0px"
		} : {
			right: "50%",
			"margin-right": "-665px"
		}), $(".search-text").hide()
	})) {

	}
});
var ifgethis = !0,
	ifclicksubmit = !0;
$(document).ready(function() {
	if($("#zuijinbuy_bd").length>0){
		new it618_Marquee(
		{
		MSClass : {MSClassID:"zuijinbuy_bd",ContentID:"zuijinbuy_item"},
		Direction : "up",
		Step:1,
		Width : 210,
		Height : 390,
		Timer : 50,
		WaitTime : 3000,
		AutoStart : 1
		});
	}

	function hidesearchcookie() {
		$("#searchcookie").hide()
	}
	function init_var() {
		s_c_left = $(".sort-nav .sort-cen").offset().left, s_c_right = $(".sort-nav .sort-cen").offset().left + $(".sort-nav .sort-cen").width(), s_c_top = $(".sort-nav .sort-cen").offset().top, s_c_bottom = $(".sort-nav .sort-cen").offset().top + $(".sort-nav .sort-cen").height(), startPoint = {
			x: 0,
			y: 0
		}, movePoint = {
			x: 0,
			y: 0
		}, rightTop = {
			x: s_c_right,
			y: s_c_top
		}, rightBottom = {
			x: s_c_right,
			y: s_c_bottom
		}, sort_top = [];
		for (var e = 0; e < $(".sort-nav .sort1 .sort-menu").length; e++) sort_top.push($(".sort-nav .sort1 .sort-menu").eq(e).offset().top - 2);
		sort_top.push($(".sort-lottery .sort-menu").offset().top - 2)
	}
	function init_cate_index_sort() {
		$(".sort-nav .sort-cen").hover(function() {}, function() {
			$(".sort.sort-hover").removeClass("sort-hover"), st_m && clearTimeout(st_m), clearTimeout(timeOut), st_m = setTimeout(function() {
				m_dot = []
			}, 200)
		}), $(".sort-nav .sort-menu").hover(function(e) {
			st_m && clearTimeout(st_m);
			var t = $(this).parent(),
				o = $(".sort").index(t);
			o > -1 && o < timeOutList.length && timeOutList[o] > 0 && clearTimeout(timeOutList[o]);
			var s = 300,
				n = e.clientX + $(window).scrollLeft(),
				r = e.clientY + $(window).scrollTop();
			if (m_dot.length > 0) if (startPoint = {
				x: m_dot[0][0],
				y: m_dot[0][1]
			}, movePoint = {
				x: n,
				y: r
			}, compareMove(startPoint, movePoint, rightTop, rightBottom)) for (s = 300, i = 0; i < timeOutList.length; i++) timeOutList[i] > 0 && clearTimeout(timeOutList[i]);
			else $(".sort-hover").removeClass("sort-hover"), s = 0;
			else s = 0;
			clearTimeout(timeOut), timeOut = setTimeout(function() {
				showSubList(t), setNull(n, r)
			}, s), $(".sort-con", t).hover(function() {
				clearTimeout(timeOut), setNull(n, r)
			}, function() {
				hideSubList(t)
			})
		}, function() {
			var e = $(this).parent(),
				t = $(".sort").index(e);
			if (t > -1) timeOutList[t] = i, $(".sort-con", e).hover(function() {
				clearTimeout(timeOutList[t]), timeOutList[t] = 0
			}, function() {
				hideSubList(e)
			});
			else var i = setTimeout(function() {
				hideSubList(e)
			}, 300)
		}), $(".sort-nav .sort-lottery").hover(function() {
			m_dot = [], $(this).addClass("sort-lottery-hover"), $(this).removeClass("sort-hover")
		}, function() {
			m_dot = [], $(this).removeClass("sort-lottery-hover"), $(this).removeClass("sort-hover")
		})
	}
	function init_cate_gouwu_sort() {
		$(".shop-content .sort-cen").hover(function() {}, function() {
			$(".sort.sort-hover").removeClass("sort-hover"), st_m && clearTimeout(st_m), clearTimeout(timeOut), st_m = setTimeout(function() {
				m_dot = []
			}, 200)
		}), $(".shop-content .sort-menu").hover(function(e) {
			st_m && clearTimeout(st_m);
			var t = $(this).parent(),
				o = $(".sort").index(t);
			o > -1 && o < timeOutList.length && timeOutList[o] > 0 && clearTimeout(timeOutList[o]);
			var s = 200,
				n = e.clientX + $(window).scrollLeft(),
				r = e.clientY + $(window).scrollTop();
			if (m_dot.length > 0) if (startPoint = {
				x: m_dot[0][0],
				y: m_dot[0][1]
			}, movePoint = {
				x: n,
				y: r
			}, compareMove(startPoint, movePoint, rightTop, rightBottom)) for (s = 200, i = 0; i < timeOutList.length; i++) timeOutList[i] > 0 && clearTimeout(timeOutList[i]);
			else $(".sort-hover").removeClass("sort-hover"), s = 0;
			else s = 0;
			clearTimeout(timeOut), timeOut = setTimeout(function() {
				showSubList(t), setNull(n, r)
			}, s), $(".sort-con", t).hover(function() {
				clearTimeout(timeOut), setNull(n, r)
			}, function() {
				hideSubList(t)
			})
		}, function() {
			var e = $(this).parent(),
				t = $(".sort").index(e);
			if (t > -1) timeOutList[t] = i, $(".sort-con", e).hover(function() {
				clearTimeout(timeOutList[t]), timeOutList[t] = 0
			}, function() {
				hideSubList(e)
			});
			else var i = setTimeout(function() {
				hideSubList(e)
			}, 200)
		})
	}
	function init_var_gouwu() {
		for (s_c_left = $(".shop-content .sort-cen").offset().left, s_c_right = $(".shop-content .sort-cen").offset().left + $(".shop-content .sort-cen").width(), s_c_top = $(".shop-content .sort-cen").offset().top, s_c_bottom = $(".shop-content .sort-cen").offset().top + $(".shop-content .sort-cen").height(), startPoint = {
			x: 0,
			y: 0
		}, movePoint = {
			x: 0,
			y: 0
		}, rightTop = {
			x: s_c_right,
			y: s_c_top
		}, rightBottom = {
			x: s_c_right,
			y: s_c_bottom
		}, sort_top = [], i = 0; i < $(".sort .sort-menu").length; i++) sort_top.push($(".sort .sort-menu").eq(i).offset().top - 2)
	}
	function compareMove(e, t, i, o) {
		return t.x > e.x && t.x < s_c_right && (e.y - t.y) / (t.x - e.x) > (e.y - o.y) / (o.x - e.x) && (e.y - t.y) / (t.x - e.x) < (e.y - i.y) / (i.x - e.x) ? !0 : !1
	}
	function setNull(e, t) {
		if (m_dot = [], mouseX = e, mouseY = t, mouseY > s_c_top && s_c_bottom > mouseY && mouseX > s_c_left && s_c_right > mouseX) for (var i = 0; i < sort_top.length - 1; i++) if (mouseY >= sort_top[i] && mouseY < sort_top[i + 1]) {
			$(".sort.sort-hover").removeClass("sort-hover"), $(".sort").eq(i).addClass("sort-hover");
			break
		}
	}
	function stopBubble(e) {
		e || e.stopPropagation ? e.stopPropagation() : window.event.CancelBubble = !0
	}
	function showSubList(e) {
		if ($(".sort-hover").removeClass("sort-hover"), $(e).hasClass("sort-lottery"));
		else if ($(e).addClass("sort-hover"), $(e).parents(".sort-cen").offset().top - $(".sort-con", $(e)).offset().top > 1) {
			var t = $(e).parents(".sort-cen").offset().top - $(e).offset().top;
			$(".sort-con", $(e)).css("top", t + "px")
		}
		hoverLazyloadImg($(e))
	}
	$(".dropdown-account").hover(function() {
		hoverdiv.myls = !0, hoverdiv.myls && ($(this).addClass("dropdown-hover"))
	}, function() {
		$(this).removeClass("dropdown-hover"), hoverdiv.myls = !1
	}), $("#buyvalue-goods .small-goods").hover(function() {
		$(this).addClass("small-goodsHover")
	}, function() {
		$(this).removeClass("small-goodsHover")
	}),$(".scvalue").click(function() {
		$(this).next().focus()
	}), $(".sctext").bind("paste", function() {
		var e = $(this);
		setTimeout(function() {
			var t = $(e).val();
			"" != t && $(e).siblings("span").hide()
		}, 1)
	}), $(".sctext").focus(function() {
		$(this).prev().addClass("scvalue-nobg");
		var e = $.trim($(this).siblings("span").text());
		"" == $(this).val() && "undefined" == typeof ifsearchlist ? ($(this).siblings("span").text(lang1), $(this).parents(".search").length > 0 && 1) : $(this).siblings("span").hide(), lang1 != e && "undefined" != typeof ifsearchlist && $(this).siblings("span").hide()
	}), $(".sctext").keyup(function() {
		"" != $(this).val() ? 1 : ($(this).siblings("span").show(), $(this).siblings("span").text(lang1), $(this).parents(".search").length > 0)
	}), $(".sctext").keydown(function(e) {
		$(this).siblings("span").hide(), "" == $(this).val() && $(this).parents(".search").length > 0
	})
	var m_dot = [],
		sort_top = [],
		st_m = null,
		s_c_left = 0,
		s_c_right = 0,
		s_c_top = 0,
		s_c_bottom = 0,
		m_time = 0,
		mouseX = 0,
		mouseY = 0,
		startPoint = {},
		movePoint = {},
		rightTop = {},
		rightBottom = {},
		timeOut, timeOutList = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
		ifshow_all_catepage = !0;
	$(".sort-nav").hover(function() {
		($(this).removeClass("sort-hide"),init_var(), init_cate_index_sort()), $(".index_nav_out").length >= 1 && (init_var(), init_cate_index_sort())
	}, function() {
		$(this).hasClass("index_nav_out") || (ifshow_all_catepage = !1, $(this).addClass("sort-hide"))
	}), $("body").bind("mousemove", function(e) {
		var t = e.clientX + $(window).scrollLeft(),
			i = e.clientY + $(window).scrollTop();
		st_m && clearTimeout(st_m), st_m = setTimeout(function() {
			setNull(t, i)
		}, 200), s_c_right > t ? m_dot.push([t, i]) : setNull(t, i)
	}), $(".shop-content .sort-cen").length > 0 && init_cate_gouwu_sort(), $(".goods").live("mouseover", function() {
		$(this).addClass("goods-hover")
	}), $(".goods").live("mouseout", function() {
		$(this).removeClass("goods-hover")
	}), $(".index-goods").hover(function() {
		$(this).addClass("index-goodsHover")
	}, function() {
		$(this).removeClass("index-goodsHover")
	}), $(".big-goods").live("mouseover", function() {
		$(this).addClass("big-goodsHover")
	}), $(".big-goods").live("mouseout", function() {
		$(this).removeClass("big-goodsHover")
	}), $("#buyvalue-goods .small-goods").live("mouseover", function() {
		$(this).addClass("small-goodsHover")
	}), $("#buyvalue-goods .small-goods").live("mouseout", function() {
		$(this).removeClass("small-goodsHover")
	}), $(".sfbc-item-open").hover(function() {
		$(".sfbc-item-option a", $(this)).length > 0 && $(this).addClass("sfbc-item-hover")
	}, function() {
		$(this).removeClass("sfbc-item-hover")
	}), $(".sf-select-title a").live("mouseover", function() {
		if ($(this).hasClass("disabled")) return !1;
		var e = "sf-select-" + $(this).attr("name");
		$(this).siblings().removeClass("current"), $(this).addClass("current"), $(this).parent().next().find("ul").hide().siblings("." + e).show()
	}), $(".gotop").click(function() {
		$("html,body").animate({
			scrollTop: 0
		}, 500)
	}), $(".scroll-block .return").click(function() {
		setCookie("version", 2, 1, null, null), window.location.reload()
	}), $("#AddFavorite").click(function() {
		var e = window.location.host;
		sURL = "http://" + e + "/?from=favorites";
		var t = $(".logo img").attr("title");
		try {
			window.external.addFavorite(sURL, t)
		} catch (i) {
			try {
				window.sidebar.addPanel(t, sURL, "")
			} catch (i) {
				alert(lang2)
			}
		}
		return !0
	})
}), function(e) {
	e.fn.lsSwitch = function(t) {
		function o(o) {
			return o.each(function() {
				function s() {
					if (e("ul li", d).length > 1 && (t.controls ? (d.append('<div class="slider-pn"><a class="slider-prev iepng" hidefocus="true" href="javascript:void(0);"></a><a class="slider-next iepng" hidefocus="true" href="javascript:void(0);"></a></div>'), e(".slider-pn .slider-next", d).live("click", function() {
						return r(), clearInterval(f), !1
					}), e(".slider-pn .slider-prev", d).live("click", function() {
						return a(), clearInterval(f), !1
					}), d.hover(function() {
						d.find(".slider-pn").addClass("slider-pnhover"), t.auto && clearInterval(f)
					}, function() {
						d.find(".slider-pn").removeClass("slider-pnhover"), t.auto && n()
					})) : d.hover(function() {
						t.auto && clearInterval(f)
					}, function() {
						t.auto && n()
					}), t.slider_btn)) {
						for (d.append('<div class="slider-page"><span class="select"><a hidefocus="true">H</a></span></div>'), i = 1; i < e("ul li", d).length; i++) e(".slider-page", d).append('<span><a hidefocus="true">H</a></span>');
						e(".slider-page span", d).live("click", function() {
							var i = e(".slider-page span", d).index(e(".slider-page span.select", d)),
								o = e(".slider-page span", d).index(e(this)),
								s = o - i;
							if (0 != s) if (s > 0) for (pr = 0; s > pr; pr++) clearInterval(f), l("next"), c(), e(u[i]).css({
								"z-index": "0"
							}).fadeOut(0), pr == s - 1 ? e(u[m]).css({
								"z-index": "1"
							}).hide().fadeIn(t.fade_interval) : e(u[m]).css({
								"z-index": "0"
							}).fadeOut(0);
							else if (0 > s) for (pr = s; 0 > pr; pr++) clearInterval(f), l("prev"), c(), -1 == pr ? e(u[m]).css({
								"z-index": "1"
							}).hide().fadeIn(t.fade_interval) : e(u[m]).css({
								"z-index": "0"
							}).fadeOut(0)
						})
					}
				}
				function n() {
					f = "next" == t.auto_dir ? setInterval(function() {
						r()
					}, t.auto_interval) : setInterval(function() {
						a()
					}, t.auto_interval)
				}
				function r() {
					if (!v) {
						v = !0, l("next");
						var i = e(".slider-page span", d).index(e(".slider-page span.select", d));
						c(), e(u[m]).css({
							"z-index": "1"
						}).hide().fadeIn(t.fade_interval, function() {
							v = !1
						}), e(u[i]).css({
							"z-index": "0"
						}).hide()
					}
				}
				function a() {
					if (!v) {
						v = !0, l("prev");
						var i = e(".slider-page span", d).index(e(".slider-page span.select", d));
						c(), e(u[m]).css({
							"z-index": "1"
						}).hide().fadeIn(t.fade_interval, function() {
							v = !1
						}), e(u[i]).css({
							"z-index": "0"
						}).hide()
					}
				}
				function l(e) {
					"next" == e ? (m += t.move, m >= u.length && (m %= u.length), p += t.move, p >= u.length && (p %= u.length)) : "prev" == e && (m -= t.move, 0 > m && (m = u.length + m), p -= t.move, 0 > p && (p = u.length + p))
				}
				function c() {
					e(".slider-page", d).children("span").removeClass("select"), e(e(".slider-page", d).children("span")[m]).addClass("select")
				}
				var d = e(o),
					h = e(o).find("ul"),
					u = h.find("li");
				if (!(u.length < 2)) {
					s();
					var m = 0,
						p = t.display_num - 1,
						v = (t.display_num - 1, !1),
						f = "",
						$ = !1;
					u.css({
						"float": "left",
						listStyle: "none",
						marginRight: t.margin
					});
					var g = u.outerWidth(!0);
					wrap_width = g * t.display_num - t.margin, t.auto && (n(), t.auto_hover && 1 != $ && (d.live("mouseenter", function() {
						$ || clearInterval(f)
					}), d.live("mouseleave", function() {
						$ || n()
					})))
				}
			})
		}
		function s(o) {
			return o.each(function() {
				function s() {
					if (e("ul li", u).length > 1 && (t.controls ? (u.append('<div class="slider-pn"><a class="slider-prev iepng" hidefocus="true" href="javascript:void(0);"></a><a class="slider-next iepng" hidefocus="true" href="javascript:void(0);"></a></div>'), e(".slider-pn .slider-next", u).live("click", function() {
						return r(), clearInterval(w), !1
					}), e(".slider-pn .slider-prev", u).live("click", function() {
						return a(), clearInterval(w), !1
					}), u.hover(function() {
						u.find(".slider-pn").addClass("slider-pnhover"), t.auto && clearInterval(w)
					}, function() {
						u.find(".slider-pn").removeClass("slider-pnhover"), t.auto && n()
					})) : u.hover(function() {
						t.auto && clearInterval(w)
					}, function() {
						t.auto && n()
					}), t.slider_btn)) {
						for (u.append('<div class="slider-page"><span class="select"><a hidefocus="true">H</a></span></div>'), i = 1; i < e("ul li", u).length; i++) e(".slider-page", u).append('<span><a hidefocus="true">H</a></span>');
						e(".slider-page span", u).live("click", function() {
							var i = e(".slider-page span", u).index(e(".slider-page span.select", u)),
								o = e(".slider-page span", u).index(e(this)),
								s = o - i;
							if (0 != s) if (s > 0) for (pr = 0; s > pr; pr++) clearInterval(w), d("next"), h(), pr == s - 1 ? m.animate({
								left: "-=" + C
							}, t.speed, function() {
								m.find("li").slice(0, t.move).remove(), m.css("left", -C), l()
							}) : m.animate({
								left: "-=" + C
							}, 0, function() {
								m.find("li").slice(0, t.move).remove(), m.css("left", -C), l()
							});
							else if (0 > s) for (pr = s; 0 > pr; pr++) clearInterval(w), d("prev"), h(), -1 == pr ? m.animate({
								left: "+=" + C
							}, t.speed, function() {
								m.find("li").slice(-t.move).remove(), m.css("left", -C), c()
							}) : m.animate({
								left: "+=" + C
							}, 0, function() {
								m.find("li").slice(-t.move).remove(), m.css("left", -C), c()
							})
						})
					}
				}
				function n() {
					w = "next" == t.auto_dir ? setInterval(function() {
						r()
					}, t.auto_interval) : setInterval(function() {
						a()
					}, t.auto_interval)
				}
				function r() {
					_ || (_ = !0, d("next"), h(), m.animate({
						left: "-=" + C
					}, t.speed, function() {
						m.find("li").slice(0, t.move).remove(), m.css("left", -C), l(), _ = !1
					}))
				}
				function a() {
					_ || (_ = !0, d("prev"), h(), m.animate({
						left: "+=" + C
					}, t.speed, function() {
						m.find("li").slice(-t.move).remove(), m.css("left", -C), c(), _ = !1
					}))
				}
				function l() {
					var o = new Array,
						s = p.clone();
					for (g = $, i = 0; i < t.move; i++) g++, void 0 != s[g] ? o[i] = e(s[g]) : (g = 0, o[i] = e(s[g]));
					e.each(o, function(e) {
						m.append(o[e][0])
					})
				}
				function c() {
					var o = new Array,
						s = p.clone();
					for (f = v, i = 0; i < t.move; i++) f--, void 0 != s[f] ? o[i] = e(s[f]) : (f = p.length - 1, o[i] = e(s[f]));
					e.each(o, function(e) {
						m.prepend(o[e][0])
					})
				}
				function d(e) {
					"next" == e ? (v += t.move, v >= p.length && (v %= p.length), $ += t.move, $ >= p.length && ($ %= p.length)) : "prev" == e && (v -= t.move, 0 > v && (v = p.length + v), $ -= t.move, 0 > $ && ($ = p.length + $))
				}
				function h() {
					e(".slider-page", u).children("span").removeClass("select"), e(e(".slider-page", u).children("span")[v]).addClass("select")
				}
				var u = e(o),
					m = e(o).find("ul"),
					p = m.find("li");
				if (!(p.length < 2)) {
					s();
					var v = 0,
						f = 0,
						$ = t.display_num - 1,
						g = t.display_num - 1,
						_ = !1,
						w = "",
						y = !1,
						b = u.width();
					p.css({
						"float": "left",
						listStyle: "none",
						width: b,
						marginRight: t.margin
					}), m.css({
						width: (e("li", m).length + 1) * e("li", m).width() + "px"
					}), wrap_width = b * t.display_num - t.margin; {
						var C = b * t.move,
							x = p.slice(0, t.display_num).clone();
						t.display_num + t.move - 1
					}
					m.empty().append(x), c(), l(), m.css({
						position: "relative",
						left: -C
					}), t.auto && (n(), t.auto_hover && 1 != y && (u.live("mouseenter", function() {
						y || clearInterval(w)
					}), u.live("mouseleave", function() {
						y || n()
					})))
				}
			})
		}
		function n(o) {
			return o.each(function() {
				function s() {
					if (e("ul li", u).length > 1 && (t.controls ? (u.append('<div class="slider-pn"><a class="slider-prev iepng" hidefocus="true" href="javascript:void(0);"></a><a class="slider-next iepng" hidefocus="true" href="javascript:void(0);"></a></div>'), e(".slider-pn .slider-next", u).live("click", function() {
						return r(), clearInterval(w), !1
					}), e(".slider-pn .slider-prev", u).live("click", function() {
						return a(), clearInterval(w), !1
					}), u.hover(function() {
						u.find(".slider-pn").addClass("slider-pnhover"), t.auto && clearInterval(w)
					}, function() {
						u.find(".slider-pn").removeClass("slider-pnhover"), t.auto && n()
					})) : u.hover(function() {
						t.auto && clearInterval(w)
					}, function() {
						t.auto && n()
					}), t.slider_btn)) {
						for (u.append('<div class="slider-page"><span class="select"><a hidefocus="true">H</a></span></div>'), i = 1; i < e("ul li", u).length; i++) e(".slider-page", u).append('<span><a hidefocus="true">H</a></span>');
						e(".slider-page span", u).live("click", function() {
							var i = e(".slider-page span", u).index(e(".slider-page span.select", u)),
								o = e(".slider-page span", u).index(e(this)),
								s = o - i;
							if (0 != s) if (s > 0) for (pr = 0; s > pr; pr++) clearInterval(w), d("next"), h(), pr == s - 1 ? m.animate({
								top: "-=" + C
							}, t.speed, function() {
								m.find("li").slice(0, t.move).remove(), m.css("top", -C), l()
							}) : m.animate({
								top: "-=" + C
							}, 0, function() {
								m.find("li").slice(0, t.move).remove(), m.css("top", -C), l()
							});
							else if (0 > s) for (pr = s; 0 > pr; pr++) clearInterval(w), d("prev"), h(), -1 == pr ? m.animate({
								top: "+=" + C
							}, t.speed, function() {
								m.find("li").slice(-t.move).remove(), m.css("top", -C), c()
							}) : m.animate({
								top: "+=" + C
							}, 0, function() {
								m.find("li").slice(-t.move).remove(), m.css("top", -C), c()
							})
						})
					}
				}
				function n() {
					w = "next" == t.auto_dir ? setInterval(function() {
						r()
					}, t.auto_interval) : setInterval(function() {
						a()
					}, t.auto_interval)
				}
				function r() {
					_ || (_ = !0, d("next"), h(), m.animate({
						top: "-=" + C
					}, t.speed, function() {
						m.find("li").slice(0, t.move).remove(), m.css("top", -C), l(), _ = !1
					}))
				}
				function a() {
					_ || (_ = !0, d("prev"), h(), m.animate({
						top: "+=" + C
					}, t.speed, function() {
						m.find("li").slice(-t.move).remove(), m.css("top", -C), c(), _ = !1
					}))
				}
				function l() {
					var o = new Array,
						s = p.clone();
					for (g = $, i = 0; i < t.move; i++) g++, void 0 != s[g] ? o[i] = e(s[g]) : (g = 0, o[i] = e(s[g]));
					e.each(o, function(e) {
						m.append(o[e][0])
					})
				}
				function c() {
					var o = new Array,
						s = p.clone();
					for (f = v, i = 0; i < t.move; i++) f--, void 0 != s[f] ? o[i] = e(s[f]) : (f = p.length - 1, o[i] = e(s[f]));
					e.each(o, function(e) {
						m.prepend(o[e][0])
					})
				}
				function d(e) {
					"next" == e ? (v += t.move, v >= p.length && (v %= p.length), $ += t.move, $ >= p.length && ($ %= p.length)) : "prev" == e && (v -= t.move, 0 > v && (v = p.length + v), $ -= t.move, 0 > $ && ($ = p.length + $))
				}
				function h() {
					e(".slider-page", u).children("span").removeClass("select"), e(e(".slider-page", u).children("span")[v]).addClass("select")
				}
				var u = e(o),
					m = e(o).find("ul"),
					p = m.find("li");
				if (!(p.length < 2)) {
					s();
					var v = 0,
						f = 0,
						$ = t.display_num - 1,
						g = t.display_num - 1,
						_ = !1,
						w = "",
						y = !1,
						b = u.height();
					p.css({
						"float": "left",
						listStyle: "none",
						height: b,
						marginRight: t.margin
					}), m.css({
						height: (e("li", m).length + 1) * e("li", m).height() + "px"
					}), wrap_width = b * t.display_num - t.margin; {
						var C = b * t.move,
							x = p.slice(0, t.display_num).clone();
						t.display_num + t.move - 1
					}
					m.empty().append(x), c(), l(), m.css({
						position: "relative",
						top: -C
					}), t.auto && (n(), t.auto_hover && 1 != y && (u.live("mouseenter", function() {
						y || clearInterval(w)
					}), u.live("mouseleave", function() {
						y || n()
					})))
				}
			})
		}
		var r = {
			effectName: "left",
			move: 1,
			display_num: 1,
			speed: 500,
			margin: 0,
			auto: !1,
			auto_interval: 2e3,
			auto_dir: "next",
			auto_hover: !1,
			slider_btn: !0,
			fade_interval: 500,
			controls: !0
		},
			t = e.extend(r, t),
			a = e("img.lsSwitchload", e(this));
		switch (a.each(function() {
			"undefined" != typeof e(this).attr("imgsrc") && e(this).attr("src", e(this).attr("imgsrc")).removeClass("lsSwitchload").removeAttr("imgsrc")
		}), t.effectName) {
		case "fade":
			return o(this);
		case "left":
			return s(this);
		case "top":
			return n(this);
		default:
			return s(this)
		}
	}
}(jQuery), $(function() {
	var e;
	$(window).scroll(jQuery.browser.msie && "6.0" == jQuery.browser.version ?
	function() {
		e && clearTimeout(e), e = setTimeout(function() {
			startLsSwitch()
		}, 500)
	} : function() {
		startLsSwitch()
	}), setTimeout(function() {
		startLsSwitch()
	}, 1e3)
});
var just_m = "",
	just_ok = !1;
$(document).ready(function() {
	$(".handy-recharge .handy-dropdowncen a").bind("click", function() {
		$("#quick_price").val($(this).attr("val")), $(".handy-input", $(this).parents(".handy-dropdown")).html($(this).text()), getrechargeinfobyprice(), $(".handy-dropdown").removeClass("handy-dropdown-unfold")
	}), $(".handy-movie .handy-dropdown,.handy-recharge .handy-dropdown").hover(function() {
		$(this).addClass("handy-dropdown-unfold")
	}, function() {
		$(this).removeClass("handy-dropdown-unfold")
	}), $(".sf-hotel .handy-dropdown").click(function() {
		$(this).addClass("handy-dropdown-unfold")
	}, function() {
		$(this).removeClass("handy-dropdown-unfold")
	}), $(".handy-hotel .handy-dropdown,.handy-flights .handy-dropdown,.sf-hotel .handy-dropdown").mouseleave(function() {
		$(this).removeClass("handy-dropdown-unfold")
	}), $(".address-hot .address-hot-con a").live("click", function() {
		$(this).parents(".handy-dropdown").find(".handy-input").val($(this).text()), $(this).parents(".handy-dropdown").removeClass("handy-dropdown-unfold")
	}), $(".address-hot .address-hot-close").live("click", function() {
		$(this).parents(".handy-dropdown").removeClass("handy-dropdown-unfold")
	}), $("#hotelCity,#frmcity,#tocity").hover(function() {
		var e = $(this).parents(".handy-dropdown").find(".address-hot");
		e.length > 0 && "" == e.html() && ("flights" == e.attr("dialoghtml") ? e.html(flights_city_html) : "hotel" == e.attr("dialoghtml") && e.html(hotel_city_html))
	}), $("#hotelCity,#frmcity,#tocity,#hotelCity_list").click(function() {
		var e = $(this).parents(".handy-dropdown").find(".address-hot");
		e.length > 0 && "" == e.html() && ("flights" == e.attr("dialoghtml") ? e.html(flights_city_html) : "hotel" == e.attr("dialoghtml") && e.html(hotel_city_html)), $(this).parents(".handy-dropdown").addClass("handy-dropdown-unfold")
	}), $("#i-date").focus(function() {
		"undefined" == typeof WdatePicker && e()
	}), $("#i-date").mouseover(function() {
		"undefined" == typeof WdatePicker && e()
	}), $("#i-date").click(function() {
		"undefined" == typeof WdatePicker ? e() : WdatePicker({
			startDate: $(this).attr("today"),
			minDate: $(this).attr("today")
		})
	}), $(".handy-dropdown input.handy-input").focus(function() {
		$(this).addClass("hover")
	})
}), $(document).ready(function() {
	setMoreBtn(), $(window).resize(function() {
		setMoreBtn()
	}), $(".scroll-block li").click(function() {
		var e = $(".scroll-block li").index($(this)),
			t = $(".index-floor .index-floor-title i").eq(e).offset().top - 30;
		$("html, body").animate({
			scrollTop: t
		}, 0)
	});
	var e;
	$(window).scroll(jQuery.browser.msie && "6.0" == jQuery.browser.version ?
	function() {
		e && clearTimeout(e), e = setTimeout(function() {
			indexFloorHeight()
		}, 100)
	} : function() {
		indexFloorHeight()
	}), indexFloorHeight()
}), $(document).ready(function() {
	$("#time_over").length > 0 && time_over()
});

var online= new Array();
var tOut = -1;
var drag = false;
var g_safeNode = null;
lastScrollY = 0;
var kfguin;
var ws;
var companyname;
var welcomeword;
var type;
var wpadomain;
var eid;

var Browser = {
	ie:/msie/.test(window.navigator.userAgent.toLowerCase()),
	moz:/gecko/.test(window.navigator.userAgent.toLowerCase()),
	opera:/opera/.test(window.navigator.userAgent.toLowerCase()),
	safari:/safari/.test(window.navigator.userAgent.toLowerCase())
};


if(kfguin)
{
	
  //_Ten_rightDivHtml = '<div id="_Ten_rightDiv" style="position:absolute; top:160px; right:1px; display:none;">';

  //_Ten_rightDivHtml += kf_getPopup_Ten_rightDivHtml(kfguin,ws,wpadomain);
  
  //_Ten_rightDivHtml += '</div>';
  
  //document.write(_Ten_rightDivHtml);
  if(type==1 && kf_getCookie('hasshown')==0)
  {
  	  companyname = companyname.substr(0,15);	   	  
      welcomeword = kf_processWelcomeword(welcomeword);
  	  
  	  kfguin = kf_getSafeHTML(kfguin);
  	  companyname = kf_getSafeHTML(companyname);
  	  
  	  welcomeword = welcomeword.replace(/<br>/g,'\r\n');
  	  welcomeword = kf_getSafeHTML(welcomeword);
  	  welcomeword = welcomeword.replace(/\r/g, "").replace(/\n/g, "<BR>");
  
      window.setTimeout("kf_sleepShow()",200);
  }
  window.setTimeout("kf_moveWithScroll()",1);
}

function kf_getSafeHTML(s)
{
	var html = "";
	var safeNode = g_safeNode;
	if(!safeNode){
		safeNode = document.createElement("TEXTAREA");
	}
	if(safeNode){
		if(Browser.moz){
			safeNode.textContent = s;
		}
		else{
			safeNode.innerText = s;
		}
		html = safeNode.innerHTML;
		if(Browser.moz){
			safeNode.textContent = "";
		}
		else{
			safeNode.innerText = "";
		}
		g_safeNode = safeNode;
	}
	return html;
}

function kf_moveWithScroll() 
{ 
	 if(typeof window.pageYOffset != 'undefined') { 
        nowY = window.pageYOffset; 
     } 
     else if(typeof document.compatMode != 'undefined' && document.compatMode != 'BackCompat') { 
        nowY = document.documentElement.scrollTop; 
     } 
     else if(typeof document.body != 'undefined') { 
        nowY = document.body.scrollTop; 
     }  

		percent = .1*(nowY - lastScrollY);
		if(percent > 0) 
		{
			percent=Math.ceil(percent);
		} 
		else
		{
			percent=Math.floor(percent);
		}

	 //document.getElementById("_Ten_rightDiv").style.top = parseInt(document.getElementById("_Ten_rightDiv").style.top) + percent+"px";
	 if(document.getElementById("kfpopupDiv"))
	 {
	 	document.getElementById("kfpopupDiv").style.top = parseInt(document.getElementById("kfpopupDiv").style.top) + percent+"px";
	 }
	 lastScrollY = lastScrollY + percent;
	 tOut = window.setTimeout("kf_moveWithScroll()",1);
}

function kf_hide() 
{
	if(tOut!=-1)
	{
		clearTimeout(tOut);   
		tOut=-1;
	}
	//document.getElementById("_Ten_rightDiv").style.visibility = "hidden";
	//document.getElementById("_Ten_rightDiv").style.display = "none";
	kf_setCookie('hasshown', 1, '', '/', wpadomain); 
}

function kf_hidekfpopup()
{
	if(tOut!=-1)
	{
		clearTimeout(tOut);   
		tOut=-1;
	}
	document.getElementById("kfpopupDiv").style.visibility = "hidden";
	document.getElementById("kfpopupDiv").style.display = "none";
	tOut=window.setTimeout("kf_moveWithScroll()",1);
	kf_setCookie('hasshown', 1, '', '/', wpadomain); 
}



//added by simon 2008-11-04
function kf_openChatWindow(flag, wpadomain, kfguin)
{
	window.open('http://b.qq.com/webc.htm?new=0&sid='+kfguin+'&eid='+eid+'&o=&q=7', '_blank', 'height=544, width=644,toolbar=no,scrollbars=no,menubar=no,status=no');
	if(flag==1)
	{
		kf_hidekfpopup();
	}
	return false;
}
//added by simon 2008-11-04 end

function kf_validateWelcomeword(word)
{
	var count = 0;
	
	for(var i=0;i<word.length;i++)
	{
		if(word.charAt(i)=='\n')
		{
			count++;
		}
		if(count>2)
		{
				return 2;
		}
	}
	if(word.length > 57+2*count)
	{
		return 1;
	}
	
	count = 0;
  var temp = word.indexOf('\n');
  while(temp!=-1)
  {
  	word = word.substr(temp+1); 
  	if(temp-1<=19) 
  	{
  		count += 19;
  	}
  	else if(temp-1<=38)
  	{
  		count += 38;
  	}
  	else if(temp-1<=57)
  	{
  		count += 57;
  	}
  	
  	temp = word.indexOf('\n');
  }
  count+=word.length;	
  if(count>57)
  {
  	return 3;
  }
  
  return 0;
}

function kf_processWelcomeword(word)
{
	word = word.substr(0,57+10);
	var result = '';
	var count = 0;	
	var temp = word.indexOf('<br>');
	
  while(count<57 && temp!=-1)
  {

  	if(temp<=19) 
  	{
  		count += 19;
  		if(count<=57)
  		{
  		   result += word.substr(0,temp+5);
  	  }
  	  else
  	  {
  	  	 result += word.substr(0,57-count>word.length?word.length:57-count);
  	  }
  	}
  	else if(temp<=38)
  	{
  		count += 38;
  		if(count<=57)
  		{
  		   result += word.substr(0,temp+5);
  	  }
  	  else
  	  {
  	  	 result += word.substr(0,57-count>word.length?word.length:57-count);
  	  }
  	}
  	else if(temp<=57)
  	{
  		count += 57;
  		if(count<=57)
  		{
  		   result += word.substr(0,temp+5);
  	  }
  	  else
  	  {
  	  	 result += word.substr(0,57-count>word.length?word.length:57-count);
  	  }
  	}
  	
  	word = word.substr(temp+5); 
  	temp = word.indexOf('<br>');
  }
  
  if(count<57)
  {
      result += word.substr(0,57-count>word.length?word.length:57-count);
  }
  
  return result;
}

function kf_setCookie(name, value, exp, path, domain)
{
	var nv = name + "=" + escape(value) + ";";

	var d = null;
	if(typeof(exp) == "object")
	{
		d = exp;
	}
	else if(typeof(exp) == "number")
	{
		d = new Date();
		d = new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes() + exp, d.getSeconds(), d.getMilliseconds());
	}
	
	if(d)
	{
		nv += "expires=" + d.toGMTString() + ";";
	}
	
	if(!path)
	{
		nv += "path=/;";
	}
	else if(typeof(path) == "string" && path != "")
	{
		nv += "path=" + path + ";";
	}

	if(!domain && typeof(VS_COOKIEDM) != "undefined")
	{
		domain = VS_COOKIEDM;
	}
	
	if(typeof(domain) == "string" && domain != "")
	{
		nv += "domain=" + domain + ";";
	}

	document.cookie = nv;
}

function kf_getCookie(name)
{
	var value = "";
	var cookies = document.cookie.split("; ");
	var nv;
	var i;

	for(i = 0; i < cookies.length; i++)
	{
		nv = cookies[i].split("=");

		if(nv && nv.length >= 2 && name == kf_rTrim(kf_lTrim(nv[0])))
		{
			value = unescape(nv[1]);
		}
	}

	return value;
} 

function kf_sleepShow()   
{   
	kf_setCookie('hasshown', 0, '', '/', wpadomain); 
	var position_1 = (document.documentElement.clientWidth-381)/2+document.body.scrollLeft;
	var position_2 = (document.documentElement.clientHeight-159)/2+document.body.scrollTop; 
	popupDivHtml = '<div class="zixun0704" id="kfpopupDiv" onmousedown="MyMove.Move(\'kfpopupDiv\',event,1);"  style="z-index:10000; position: absolute; top: '+position_2+'px; left: '+position_1+'px;color:#000;font-size: 12px;cursor:move;height: 159px;width: 381px;">';
  	popupDivHtml += kf_getPopupDivHtml(kfguin,ws,companyname,welcomeword, wpadomain);
  	popupDivHtml += '</div>';
	if(document.body.insertAdjacentHTML)
	{
  		document.body.insertAdjacentHTML("beforeEnd",popupDivHtml);
	}
	else
	{
		$("#footer").before(popupDivHtml);
//		sWhere="beforeEnd";
//		sHTML=popupDivHtml;
//		alert(HTMLElement.prototype.insertAdjacentHTML);
//		HTMLElement.prototype.insertAdjacentHTML = function(sWhere, sHTML){
//            var df = null,r = this.ownerDocument.createRange();
//            switch (String(sWhere).toLowerCase()) {
//                case "beforebegin":
//                    r.setStartBefore(this);
//                    df = r.createContextualFragment(sHTML);
//                    this.parentNode.insertBefore(df, this);
//                    break;
//                case "afterbegin":
//                    r.selectNodeContents(this);
//                    r.collapse(true);
//                    df = r.createContextualFragment(sHTML);
//                    this.insertBefore(df, this.firstChild);
//                    break;
//                case "beforeend":				
//                    r.selectNodeContents(this);
//                    r.collapse(false);
//                    df = r.createContextualFragment(sHTML);
//                    this.appendChild(df);
//                    break;
//                case "afterend":
//                    r.setStartAfter(this);
//                    df = r.createContextualFragment(sHTML);
//                    this.parentNode.insertBefore(df, this.nextSibling);
//                    break;
//            }
//        };
	}
} 

function kf_dealErrors() 
{
	kf_hide();
	return true;
}

function kf_lTrim(str)
{
  while (str.charAt(0) == " ")
  {
    str = str.slice(1);
  }
  return str;
}

function kf_rTrim(str)
{
  var iLength = str.length;
  while (str.charAt(iLength - 1) == " ")
  {
    str = str.slice(0, iLength - 1);
	iLength--;
  }
  return str;
}

window.onerror = kf_dealErrors;
var MyMove = new Tong_MoveDiv();   

function Tong_MoveDiv()
{ 
 	  this.Move=function(Id,Evt,T) 
 	  {    
 	  	if(Id == "") 
		{
			return;
		} 
 	  	var o = document.getElementById(Id);    
 	  	if(!o) 
		{
			return;
		}    
 	    evt = Evt ? Evt : window.event;    
 	    o.style.position = "absolute";    
 	    o.style.zIndex = 9999;    
 	    var obj = evt.srcElement ? evt.srcElement : evt.target;   
 	    var w = o.offsetWidth;      
 	    var h = o.offsetHeight;      
 	    var l = o.offsetLeft;      
 	    var t = o.offsetTop;  
 	    var div = document.createElement("DIV");  
 	    document.body.appendChild(div);   
 	    div.style.cssText = "filter:alpha(Opacity=10,style=0);opacity:0.2;width:"+w+"px;height:"+h+"px;top:"+t+"px;left:"+l+"px;position:absolute;background:#000";      
 	    div.setAttribute("id", Id +"temp");    
 	    this.Move_OnlyMove(Id,evt,T); 
 	}  
 	
 	this.Move_OnlyMove = function(Id,Evt,T) 
 	{    
 		  var o = document.getElementById(Id+"temp");    
 		  if(!o)
		  {
			return;
		  }   
 		  evt = Evt?Evt:window.event; 
 		  var relLeft = evt.clientX - o.offsetLeft;
 		  var relTop = evt.clientY - o.offsetTop;    
 		  if(!window.captureEvents)    
 		  {      
 		  	 o.setCapture();           
 		  }   
 		  else   
 		  {     
 		  	 window.captureEvents(Event.MOUSEMOVE|Event.MOUSEUP);      
 		  }       
 		  			  
	      document.onmousemove = function(e)
	      {
	            if(!o)
	            {
	                return;
	            }
	            e = e ? e : window.event;
	
	        	var bh = Math.max(document.body.scrollHeight,document.body.clientHeight,document.body.offsetHeight,
	        						document.documentElement.scrollHeight,document.documentElement.clientHeight,document.documentElement.offsetHeight);
	        	var bw = Math.max(document.body.scrollWidth,document.body.clientWidth,document.body.offsetWidth,
	        						document.documentElement.scrollWidth,document.documentElement.clientWidth,document.documentElement.offsetWidth);
	        	var sbw = 0;
	        	if(document.body.scrollWidth < bw)
	        		sbw = document.body.scrollWidth;
	        	if(document.body.clientWidth < bw && sbw < document.body.clientWidth)
	        		sbw = document.body.clientWidth;
	        	if(document.body.offsetWidth < bw && sbw < document.body.offsetWidth)
	        		sbw = document.body.offsetWidth;
	        	if(document.documentElement.scrollWidth < bw && sbw < document.documentElement.scrollWidth)
	        		sbw = document.documentElement.scrollWidth;
	        	if(document.documentElement.clientWidth < bw && sbw < document.documentElement.clientWidth)
	        		sbw = document.documentElement.clientWidth;
	        	if(document.documentElement.offsetWidth < bw && sbw < document.documentElement.offsetWidth)
	        		sbw = document.documentElement.offsetWidth;
	             
	            if(e.clientX - relLeft <= 0)
	            {
	                o.style.left = 0 +"px";
	            }
	            else if(e.clientX - relLeft >= bw - o.offsetWidth - 2)
	            {
	                o.style.left = (sbw - o.offsetWidth - 2) +"px";
	            }
	            else
	            {
	                o.style.left = e.clientX - relLeft +"px";
	            }
	            if(e.clientY - relTop <= 1)
	            {
	                o.style.top = 1 +"px";
	            }
	            else if(e.clientY - relTop >= bh - o.offsetHeight - 30)
	            {
	                o.style.top = (bh - o.offsetHeight) +"px";
	            }
	            else
	            {
	                o.style.top = e.clientY - relTop +"px";
	            }
	      }
 		   
 		  document.onmouseup = function()      
 		  {       
 		   	   if(!o) return;       
 		   	   	
 		   	   if(!window.captureEvents) 
			   {
			   	  o.releaseCapture();  
			   }         		   	   	      
 		   	   else  
			   {
			   	  window.releaseEvents(Event.MOUSEMOVE|Event.MOUSEUP); 
			   }     
 		   	   	        
 		   	   var o1 = document.getElementById(Id);       
 		   	   if(!o1) 
			   {
			      return; 
			   }        		   	   	
 		   	   var l0 = o.offsetLeft;       
 		   	   var t0 = o.offsetTop;       
 		   	   var l = o1.offsetLeft;       
 		   	   var t = o1.offsetTop;   
 		   	   
 		   	   //alert(l0 + " " +  t0 +" "+ l +" "+t);     
 		   	   
 		   	   MyMove.Move_e(Id, l0 , t0, l, t,T);       
 		   	   document.body.removeChild(o);       
 		   	   o = null;      
 		}  
 	}  
 	
 	
 	this.Move_e = function(Id, l0 , t0, l, t,T)     
 	{      
 		    if(typeof(window["ct"+ Id]) != "undefined") 
			{
				  clearTimeout(window["ct"+ Id]);   
			}
 		    
 		    var o = document.getElementById(Id);      
 		    if(!o) return;      
 		    var sl = st = 8;      
 		    var s_l = Math.abs(l0 - l);      
 		    var s_t = Math.abs(t0 - t);      
 		    if(s_l - s_t > 0)  
			{
				if(s_t) 
				{
					sl = Math.round(s_l / s_t) > 8 ? 8 : Math.round(s_l / s_t) * 6; 
				}       
 		    		      
 		        else
				{
					sl = 0; 
				}            		      
			}        		    	   
 		    else
			{
				if(s_l)
				{
					st = Math.round(s_t / s_l) > 8 ? 8 : Math.round(s_t / s_l) * 6;   
				}          		    		    
 		        else  
			    {
			  	    st = 0;
			    }       		      	  
			}       
 		    	       		      	
 		    if(l0 - l < 0) 
			{
				sl *= -1; 
			}  		    	     
 		    if(t0 - t < 0) 
			{
				st *= -1; 
			}   		    	     
 		    if(Math.abs(l + sl - l0) < 52 && sl) 
			{
 		    	sl = sl > 0 ? 2 : -2; 					
			}    
 		    if(Math.abs(t + st - t0) < 52 && st) 
			{
	        	st = st > 0 ? 2 : -2;  					
			}      
 		    if(Math.abs(l + sl - l0) < 16 && sl) 
			{
 		    	sl = sl > 0 ? 1 : -1;  					
			}   
 		    if(Math.abs(t + st - t0) < 16 && st) 
			{
 		    	st = st > 0 ? 1 : -1;    					
			} 
 		    if(s_l == 0 && s_t == 0)
			{
     		    return;   				
			} 
 		    if(T)      
 		    {    
 		    	o.style.left = l0 +"px";    
 		    	o.style.top = t0 +"px";    
 		    	return;      
 		    }      
 		    else      
 		    {    
 		    	if(Math.abs(l + sl - l0) < 2) 
				{
					o.style.left = l0 +"px";  
				}       		    		 
 		    	else     
				{
					o.style.left = l + sl +"px";   
				}   		    	 
 		    	if(Math.abs(t + st - t0) < 2) 
				{
					o.style.top = t0 +"px";   
				}        		    		 
 		    	else    
				{
					o.style.top = t + st +"px";   
				}
 		    		         		    	
 		    	window["ct"+ Id] = window.setTimeout("MyMove.Move_e('"+ Id +"', "+ l0 +" , "+ t0 +", "+ (l + sl) +", "+ (t + st) +","+T+")", 1);      
 		    }     
 		}   
} 