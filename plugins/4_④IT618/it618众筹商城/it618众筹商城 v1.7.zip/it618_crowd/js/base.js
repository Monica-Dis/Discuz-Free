﻿function hoverLazyloadImg(e, i) {
	if (i) var r = $("img.hoverload", $(e).parent().parent().find("." + i));
	else var r = $("img.hoverload", $(e));
	r.each(function() {
		"undefined" != typeof $(this).attr("imgsrc") && $(this).attr("src", $(this).attr("imgsrc")).removeClass("hoverload").removeAttr("imgsrc")
	})
}

function setMoreBtn() {
	if ($(".sf-firstsub>.sf-link>.filter-more").live("click", function() {
		$(this).parent().next(".sf-select").length > 0 ? $(this).parent().hide().siblings(".sf-select").show() : ($(this).parent().addClass("sf-unfold"), $(this).hide())
	}), $(".sf-content>.sf-link>.filter-more").live("click", function() {
		$(this).parent().addClass("sf-unfold"), $(this).hide()
	}), $(".sf-secondsub>.sf-link>.filter-more").live("click", function() {
		$(this).parent().next(".sf-select").length > 0 ? $(this).parent().hide().siblings(".sf-select").show() : ($(this).parent().addClass("sf-unfold"), $(this).hide())
	}), $(".sf-select .filter-more").live("click", function() {
		$(this).parent().hide().siblings(".sf-link").show()
	}), $(".sf-link .filter-more").length > 0) {
		var e = $(".sf-link .filter-more").siblings("ul");
		for (u = 0; u < e.length; u++) if ($(e[u]).parent().hasClass("sf-unfold")) $(e[u]).siblings(".filter-more").hide();
		else {
			var r = $("li", $(e[u])),
				t = $("li", $(e[u])).length,
				o = 0;
			for (i = 0; t > i; i++) o += $(r[i]).outerWidth(!0);
			$(e[u]).width() > o ? $(e[u]).siblings(".filter-more").hide() : $(e[u]).siblings(".filter-more").show(), $("li a.current", $(e[u])).length > 0 && $("li a.current", $(e[u])).offset().top - $(e[u]).offset().top > 5 && $(e[u]).siblings(".filter-more").trigger("click")
		}
	}
	if ($(".filter-strip .filter-more").length > 0) {
		var e = $(".filter-strip .filter-more").parents(".filter-link").children("ul");
		for (u = 0; u < e.length; u++) {
			var r = $("li", $(e[u])),
				t = $("li", $(e[u])).length,
				o = 0;
			for (i = 0; t > i; i++) o += $(r[i]).outerWidth(!0);
			$(e[u]).width() > o ? $(e[u]).siblings(".filter-more").remove() : $(e[u]).siblings(".filter-more").show()
		}
		$(".filter-strip .filter-more").mouseenter(function() {
			$(this).parents(".filter-strip").addClass("filter-strip-unfold")
		}), $(".filter-strip-warp").mouseleave(function() {
			$(this).children(".filter-strip").removeClass("filter-strip-unfold")
		})
	}
}

function toTxt(e) {
	var i = /\<|\>/g;
	return e = e.replace(i, function(e) {
		switch (e) {
		case "<":
			return "&_lt;".replace("_", "");
		case ">":
			return "&_gt;".replace("_", "")
		}
	})
}
function close_tips(e, i) {
	$(e).parent().remove();
	var r = getCookie("tips");
	r += i, setCookie("tips", r, null, null, null)
}
function startLsSwitch() {
	var e = $(".lazy_start");
	e.each(function() {
		var e = $(this).attr("options").toString().split("|");
		$(this).hasClass("lazy_start") && $(this).offset().top < $(document).scrollTop() + $(window).height() - 100 && "sort-movie" != e[0] && ($(this).lsSwitch({
			effectName: e[1].toString(),
			auto: "1" == e[2] ? !0 : !1,
			auto_interval: parseInt(e[3]),
			fade_interval: parseInt(e[4]),
			controls: "1" == e[5] ? !0 : !1,
			slider_btn: "1" == e[6] ? !0 : !1,
			margin: parseInt(e[7]),
			auto_hover: "1" == e[8] ? !0 : !1
		}), $(this).removeClass("lazy_start"))
	})
}
function is_variable_mobile(e) {
	var i = /^1[34578]\d{9}$/;
	return i.test(e) ? !0 : !1
}

function indexFloorHeight() {
	var e = $(window).scrollTop(),
		r = $(window).height(),
		t = $(".index-floor"),
		o = 200;
	if (t.length > 0 && e + r < $(t[0]).offset().top + 300) $(".scroll-block ul,.scroll-block a.gotop").hide();
	else if (t.length > 0 && $(t[0]).offset().top - e < 550) for ($(".scroll-block ul,.scroll-block a.gotop").show(), i = 0; i < t.length; i++) {
		if (i == t.length - 1) {
			$(t[i]).offset().top - e < o && ($(".scroll-block li").removeClass("select"), $(".scroll-block li:last").addClass("select"));
			break
		}
		if ($(t[i]).offset().top - e < o && $(t[i + 1]).offset().top - e > o) {
			$(".scroll-block li").removeClass("select"), $(".scroll-block li").eq(i).addClass("select");
			break
		}
	} else $(".scroll-block ul,.scroll-block a.gotop").show(), $(".scroll-block li").removeClass("select");
	0 == t.length && 800 > e + r ? $(".scroll-block a.gotop").hide() : 0 == t.length && e + r > 800 && $(".scroll-block a.gotop").show();
	var s = $("#main").height(),
		a = $("#main").offset().top,
		l = ($(".scroll-block").height(), $("body").height()),
		n = $(".gp-hot").outerHeight(!0) + $("#footer").outerHeight(!0),
		c = e + r - l + n;
	if (c > 0) {
		if ($(".scroll-block").css({
			bottom: c + "px"
		}), jQuery.browser.msie && "6.0" == jQuery.browser.version) {
			var d = s + a - $(".scroll-block").height();
			$(".scroll-block").css({
				bottom: "auto",
				top: d
			})
		}
	} else if ($(".scroll-block").css({
		bottom: "20px"
	}), jQuery.browser.msie && "6.0" == jQuery.browser.version) {
		var d = e + r - 20 - $(".scroll-block").height();
		$(".scroll-block").css({
			bottom: "auto",
			top: d
		})
	}
	if ($(".sidebar-switch").length > 0 && "none" != $(".sidebar-switch").css("display")) {
		var h = $(".sidebar-switch").offset().top,
			p = $(".sidebar-switch").offset().top + $(".sidebar-switch").height();
		$(".sidebar-switch .ss-icon").css(h > e ? {
			top: 100,
			"margin-top": "0"
		} : e > h && p - 85 > e + 100 ? {
			top: e - h + 100,
			"margin-top": "0"
		} : e + 100 > p - 85 && p > e ? {
			top: p - 85 - h,
			"margin-top": "0"
		} : {
			top: "50%",
			"margin-top": "55px"
		})
	}
	if ($(".index-sidebar").length > 0) {
		if ("fixed" != $(".index-sidebar").css("position")) var _ = $(".detail-content .detail-sidebar").outerHeight() + n;
		else var _ = $(".detail-content .detail-sidebar").outerHeight() + n + $(".index-sidebar").outerHeight();
		if ($(".detail-content .detail-right").outerHeight() > _) if (c > 0) $(".index-sidebar").css($(".detail-content .detail-sidebar").offset().top + $(".detail-content .detail-sidebar").outerHeight() - $(".index-sidebar").outerHeight() < e ? l - n < e + $(".index-sidebar").outerHeight() ? {
			position: "fixed",
			top: "auto",
			bottom: c - 12
		} : {
			position: "fixed",
			top: "0",
			bottom: "auto"
		} : {
			position: "static",
			top: "auto",
			bottom: "auto"
		});
		else {
			if ("fixed" != $(".index-sidebar").css("position")) var f = $(".detail-content .detail-sidebar").offset().top + $(".detail-content .detail-sidebar").outerHeight() - $(".index-sidebar").outerHeight();
			else var f = $(".detail-content .detail-sidebar").offset().top + $(".detail-content .detail-sidebar").outerHeight();
			$(".index-sidebar").css(e > f ? {
				position: "fixed",
				top: "0",
				bottom: "auto"
			} : {
				position: "static",
				top: "auto",
				bottom: "auto"
			})
		}
	}
}

function popok(e) {
	$(".pop-cutover-tit").hide(), $(".pop-cutover-con").hide(), $("." + e).css("visibility", "visible"), $("." + e).show()
}
function mobile_getyzmimg(e) {
	e && "none" != $(".mobile_yzm", $(e)).css("display") && ($(".mobile_chkimg", $(e)).attr("src", "/account/captcha?" + Math.random()), $(".mobile_yzmtip", $(e)).removeClass("error").removeClass("correct"), $(".mobile_myyzm", $(e)).removeClass("error").removeClass("correct"))
}
function IsNumeric(e) {
	var r, t = "0123456789",
		o = !0;
	for (i = 0; i < e.length && 1 == o; i++) r = e.charAt(i), -1 == t.indexOf(r) && (o = !1);
	return String(parseInt(e)).length < String(e).length && (o = !1), o
}

function setShareQQTest(e) {
	$("#test_shareQQ-pop").val("aa"), $("#test_shareQQ-pop").val(e)
}
function goTopOnsubmit(e) {
	if ("bsearch" == e) {
		var i = $("#bsearch").val();
		$("#bsearch").val() ? (setCookie("<{:C('COOKIE_PREFIX')}>bsearch", encodeURI(i), !1, null, null), window.location.reload()) : (setCookie("<{:C('COOKIE_PREFIX')}>bsearch", null, !1, null, null), window.location.reload())
	}
}
function goTopOnsubmit1(e) {
	if ("bsearch" == e) {
		var i = $("#bsearch").val();
		$("#bsearch").val() ? (setCookie("<{:C('COOKIE_PREFIX')}>bsearch", encodeURI(i), !1, null, null), window.location.href = "http://" + window.location.host + "/top/") : (setCookie("<{:C('COOKIE_PREFIX')}>bsearch", null, !1, null, null), window.location.href = "http://" + window.location.host + "/top/")
	}
}
var ifgetcart = !0,
	hoverdiv = {
		shopcart: !1,
		history: !1,
		myls: !1
	},
	wait = 120,
	DetailSysSecond, DetailInterValObj;