<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_crowd_lang;

function it618_crowd_getlang($langid){
	global $it618_crowd_lang;
	return $it618_crowd_lang[$langid];
}

$it618_crowd_lang['version']='v1.7';
$it618_crowd_lang['s1'] = '热门类别与商品';
$it618_crowd_lang['s2'] = '网站底部信息';
$it618_crowd_lang['s3'] = '顶部全局轮播';
$it618_crowd_lang['s4'] = '首页右上轮播';
$it618_crowd_lang['s5'] = '首页右下轮播';
$it618_crowd_lang['s6'] = '列表页右下轮播';
$it618_crowd_lang['s7'] = '商品页左下轮播';
$it618_crowd_lang['s8'] = '伪静态设置';
$it618_crowd_lang['s9'] = '消息提醒设置';
$it618_crowd_lang['s10'] = '注意：保存后价格积分类型不可修改，为了方便统计';
$it618_crowd_lang['s11'] = '注意：每一期开始时，会自动记录每份价格和份数的(同时也会记录剩余次数)，这样修改商品的价格份数只能在下期有效';
$it618_crowd_lang['s12'] = '当前价格/份数';
$it618_crowd_lang['s13'] = '人次';
$it618_crowd_lang['s14'] = '一级商品类别';
$it618_crowd_lang['s15'] = '二级商品类别';
$it618_crowd_lang['s16'] = '更新成功！';
$it618_crowd_lang['s17'] = '积分类型：';
$it618_crowd_lang['s18'] = '返回首页';
$it618_crowd_lang['s19'] = '提示：1、保存或上架时每份价格与份数必须大于0 2、如果库存为0时，会提示不能参与 3、如果众筹开始了就不能下架';
$it618_crowd_lang['s20'] = '库存:';
$it618_crowd_lang['s21'] = '第';
$it618_crowd_lang['s22'] = '期';
$it618_crowd_lang['s23'] = '更新';
$it618_crowd_lang['s24'] = '';
$it618_crowd_lang['s25'] = '查找';
$it618_crowd_lang['s26'] = '已参与';
$it618_crowd_lang['s27'] = '总需人次';
$it618_crowd_lang['s28'] = '剩余';
$it618_crowd_lang['s29'] = '文字颜色(无突出效果时要为空)';
$it618_crowd_lang['s30'] = '参与管理';
$it618_crowd_lang['s31'] = '会员名称为红色时表示是获得者';
$it618_crowd_lang['s32'] = '参与会员';
$it618_crowd_lang['s33'] = '更新成功！(成功修改数:';
$it618_crowd_lang['s34'] = '成功添加数:';
$it618_crowd_lang['s35'] = '成功删除数:';
$it618_crowd_lang['s36'] = '统计信息';
$it618_crowd_lang['s37'] = '！';
$it618_crowd_lang['s38'] = '警告：以下内容有的需要结合编辑器的代码模式(<font color=blue>代码模式/内容模式 通过编辑器的第一个功能图标切换</font>)修改，如果你对代码不了解修改前请一定对内容进行备份！';
$it618_crowd_lang['s39'] = '参与记录';
$it618_crowd_lang['s40'] = '揭晓管理';
$it618_crowd_lang['s41'] = '商品一级分类管理 <font color=red>(注意：为了电脑版首页界面一级分类最多有9个，不能删除的，如果想不显示哪个分类，就在以下哪个分类上传图片)</font>';
$it618_crowd_lang['s42'] = '按类别名称';
$it618_crowd_lang['s43'] = '商品类别数：';
$it618_crowd_lang['s44'] = '提示：类别简称用于首页右侧的类别快捷导航，类别简称2个字表示类别，晒单评价评分名称有4个，每个评分名称用_下划线隔开，<font color=blue>首页推荐商家数为0时就是不显示</font>';
$it618_crowd_lang['s45'] = '类别名称';
$it618_crowd_lang['s46'] = '简称';
$it618_crowd_lang['s47'] = '晒单评价评分名称(<font color=red>第一个评分名称很重要</font>)';
$it618_crowd_lang['s48'] = '主题颜色';
$it618_crowd_lang['s49'] = '电脑版/手机版首推商家数';
$it618_crowd_lang['s50'] = '排序';
$it618_crowd_lang['s51'] = '在';
$it618_crowd_lang['s52'] = '提示：推荐如果勾选会显示在左侧类别主菜单和首页分类商品右上角';
$it618_crowd_lang['s53'] = '子类别数';
$it618_crowd_lang['s54'] = '商品数';
$it618_crowd_lang['s55'] = '商品二级分类管理';
$it618_crowd_lang['s56'] = '编号';
$it618_crowd_lang['s57'] = '类别1';
$it618_crowd_lang['s58'] = '类别2名称';
$it618_crowd_lang['s59'] = '推荐';
$it618_crowd_lang['s60'] = '宽:';
$it618_crowd_lang['s61'] = '高:';
$it618_crowd_lang['s62'] = '轮播广告数：';
$it618_crowd_lang['s63'] = '注意：排序值为0时表示图片不显示，数值越小越在前';
$it618_crowd_lang['s64'] = '图片';
$it618_crowd_lang['s65'] = '图片链接(为空时图片不带链接)';
$it618_crowd_lang['s66'] = '排序';
$it618_crowd_lang['s67'] = '上传图片';
$it618_crowd_lang['s68'] = '提交后再上传图片';
$it618_crowd_lang['s69'] = '注意：以下分类与商品编号，多个时请用逗号隔开(如：1,2,3,4,5)，并且设置顺序就是显示顺序';
$it618_crowd_lang['s70'] = '首页热门商品分类编号：';
$it618_crowd_lang['s71'] = '搜索页热门分类编号：';
$it618_crowd_lang['s72'] = '首页热门商品编号：';
$it618_crowd_lang['s73'] = '给自己发送短信(用自己的手机号到飞信官方注册一个账号，短信是免费的)';
$it618_crowd_lang['s74'] = '启用短信提醒功能：';
$it618_crowd_lang['s75'] = '在<font color=green>申请商家、交易成功、申请退款与申请提现</font>时会有短信提醒';
$it618_crowd_lang['s76'] = '手机号码：';
$it618_crowd_lang['s77'] = '有提醒时此手机号就会收到短信';
$it618_crowd_lang['s78'] = '此商品删除成功！';
$it618_crowd_lang['s79'] = '购物车清空成功！';
$it618_crowd_lang['s80'] = '更新时发送一个测试短信';
$it618_crowd_lang['s81'] = '<font color=green>提示：默认有短信宝接口，如果配合 <a href="http://addon.discuz.com/?@it618_members.plugin" target="_blank">it618会员短信微信</a> 可以有阿里大鱼短信接口、阿里云短信与接口微信消息接口</font>';
$it618_crowd_lang['s82'] = '启用短信提醒功能：';
$it618_crowd_lang['s83'] = '参与记录';
$it618_crowd_lang['s84'] = '短信接口账号：';
$it618_crowd_lang['s85'] = '短信接口密码：';
$it618_crowd_lang['s86'] = '测试接收人手机号：';
$it618_crowd_lang['s87'] = '多个手机号用英文字母逗号隔开';
$it618_crowd_lang['s88'] = '测试短信内容：';
$it618_crowd_lang['s89'] = '提示：可以利用发送测试短信功能，手工给多个手机发送短信';
$it618_crowd_lang['s90'] = '成功修改商品数：';
$it618_crowd_lang['s91'] = '抱歉，参与{count}人次需要{jfcount}{jfname}，您现在只有{creditnum}{jfname}，请先充值积分！';
$it618_crowd_lang['s92'] = '确定要清空购物车？';
$it618_crowd_lang['s93'] = '确定要购买？点确定会批量购买购物车的商品！';
$it618_crowd_lang['s94'] = '按关键字';
$it618_crowd_lang['s95'] = '所有分类';
$it618_crowd_lang['s96'] = '商品管理';
$it618_crowd_lang['s97'] = '按关键词';
$it618_crowd_lang['s98'] = '剩余人次';
$it618_crowd_lang['s99'] = '商品分类';
$it618_crowd_lang['s100'] = '所有分类';
$it618_crowd_lang['s101'] = '状态';
$it618_crowd_lang['s102'] = '所有';
$it618_crowd_lang['s103'] = '下架';
$it618_crowd_lang['s104'] = '上架';
$it618_crowd_lang['s105'] = '提示';
$it618_crowd_lang['s106'] = '当前价格：';
$it618_crowd_lang['s107'] = '当前份数：';
$it618_crowd_lang['s108'] = '单价:';
$it618_crowd_lang['s109'] = '积分:';
$it618_crowd_lang['s110'] = '按即将揭晓';
$it618_crowd_lang['s111'] = '按揭晓排序';
$it618_crowd_lang['s112'] = '按人气排序';
$it618_crowd_lang['s113'] = '按价格排序';
$it618_crowd_lang['s114'] = '商品数：';
$it618_crowd_lang['s115'] = '商品名称/简洁描述';
$it618_crowd_lang['s116'] = '库存/单位';
$it618_crowd_lang['s117'] = '有效时间';
$it618_crowd_lang['s118'] = '人气：';
$it618_crowd_lang['s119'] = '已揭：';
$it618_crowd_lang['s120'] = '：';
$it618_crowd_lang['s121'] = '每份价格/份数';
$it618_crowd_lang['s122'] = '状态';
$it618_crowd_lang['s123'] = '排序';
$it618_crowd_lang['s124'] = '发布会员：';
$it618_crowd_lang['s125'] = '元';
$it618_crowd_lang['s126'] = '限购';
$it618_crowd_lang['s127'] = '天';
$it618_crowd_lang['s128'] = '个';
$it618_crowd_lang['s129'] = '全选';
$it618_crowd_lang['s130'] = '修改以上排序';
$it618_crowd_lang['s131'] = '会员ID';
$it618_crowd_lang['s132'] = '刷新交易';
$it618_crowd_lang['s133'] = '导出查询交易到CSV文件';
$it618_crowd_lang['s134'] = '会员ID';
$it618_crowd_lang['s135'] = '刷新参与';
$it618_crowd_lang['s136'] = 'URL 静态化可以提高搜索引擎抓取，开启本功能需要对 Web 服务器增加相应的 Rewrite 支持，且会轻微增加服务器负担。同时您还可以调整每个页面的静态格式，但不得删除其中的标记，重置静态格式请留空。<br><font color=red>注意，修改静态格式后您需要修改服务器的 Rewrite 规则设置，并且要把DZ默认的插件规则删除或放最后一行，此插件规则才有效果</font>';
$it618_crowd_lang['s137'] = '静态格式扩展名：';
$it618_crowd_lang['s138'] = '页面';
$it618_crowd_lang['s139'] = '标记';
$it618_crowd_lang['s140'] = '格式';
$it618_crowd_lang['s141'] = '商城首页';
$it618_crowd_lang['s142'] = '商城商品列表页';
$it618_crowd_lang['s143'] = '商城商品查找页';
$it618_crowd_lang['s144'] = '商城商品页';
$it618_crowd_lang['s145'] = '计算方法';
$it618_crowd_lang['s146'] = '首页推荐文章管理';
$it618_crowd_lang['s147'] = '商城手机版页';
$it618_crowd_lang['s148'] = 'Apache Web Server(独立主机用户)';
$it618_crowd_lang['s149'] = 'Apache Web Server(虚拟主机用户)';
$it618_crowd_lang['s150'] = '# 将 RewriteEngine 模式打开
RewriteEngine On

# 修改以下语句中的 /discuz 为您的论坛目录地址，如果程序放在根目录中，请将 /discuz 修改为 /
RewriteBase /discuz

# Rewrite 系统规则请勿修改';
$it618_crowd_lang['s151'] = 'IIS Web Server(独立主机用户)';
$it618_crowd_lang['s152'] = 'IIS7 Web Server(独立主机用户)';
$it618_crowd_lang['s219'] = '交易号';
$it618_crowd_lang['s220'] = '商品名称';
$it618_crowd_lang['s221'] = '参与人次';
$it618_crowd_lang['s222'] = '积分';
$it618_crowd_lang['s223'] = '状态';
$it618_crowd_lang['s224'] = '揭晓会员';
$it618_crowd_lang['s225'] = '本期总参与人次：';
$it618_crowd_lang['s226'] = '获得者：';
$it618_crowd_lang['s227'] = '';
$it618_crowd_lang['s228'] = '揭晓时间';
$it618_crowd_lang['s229'] = '揭晓数：';
$it618_crowd_lang['s230'] = '';
$it618_crowd_lang['s294'] = '回复';
$it618_crowd_lang['s295'] = '回复评价';
$it618_crowd_lang['s339'] = '消息提醒设置更新成功！';
$it618_crowd_lang['s340'] = '！';
$it618_crowd_lang['s341'] = '在<font color=green>交易成功、提现成功、商品锁定与商品解锁</font>时会有短信提醒';
$it618_crowd_lang['s342'] = '成功删除数：';
$it618_crowd_lang['s343'] = '成功上架商品数：';
$it618_crowd_lang['s344'] = '成功下架商品数：';
$it618_crowd_lang['s345'] = '成功更新数：';
$it618_crowd_lang['s346'] = '所有分类';
$it618_crowd_lang['s347'] = '';
$it618_crowd_lang['s348'] = '';
$it618_crowd_lang['s349'] = '商品管理';
$it618_crowd_lang['s350'] = '查找';
$it618_crowd_lang['s351'] = '编辑';
$it618_crowd_lang['s352'] = '删除选中商品';
$it618_crowd_lang['s353'] = '确定要删除选中商品？此操作不可逆。';
$it618_crowd_lang['s354'] = '修改以上商品';
$it618_crowd_lang['s355'] = '上架选中商品';
$it618_crowd_lang['s356'] = '确定要上架选中商品？';
$it618_crowd_lang['s357'] = '下架选中商品';
$it618_crowd_lang['s358'] = '确定要下架选中商品？';
$it618_crowd_lang['s359'] = '商品添加成功！';
$it618_crowd_lang['s360'] = '添加商品';
$it618_crowd_lang['s361'] = '请选择商品分类！';
$it618_crowd_lang['s362'] = '注意：保存后商品类型不可修改';
$it618_crowd_lang['s363'] = '在线客服信息';
$it618_crowd_lang['s364'] = '联系地址';
$it618_crowd_lang['s365'] = '工作时间';
$it618_crowd_lang['s366'] = '热线电话';
$it618_crowd_lang['s367'] = '客服职位：';
$it618_crowd_lang['s368'] = '多个职位用逗号隔开，如：销售,采购,售后';
$it618_crowd_lang['s369'] = '客服QQ：';
$it618_crowd_lang['s370'] = '客服微信：';
$it618_crowd_lang['s371'] = '多个QQ或微信事情用逗号隔开，如：111111,222222,333333';
$it618_crowd_lang['s372'] = '请上传商品图片！';
$it618_crowd_lang['s373'] = '';
$it618_crowd_lang['s374'] = '商品分类：';
$it618_crowd_lang['s375'] = '请选择商品一级分类';
$it618_crowd_lang['s376'] = '请选择商品二级分类';
$it618_crowd_lang['s377'] = '';
$it618_crowd_lang['s378'] = '商品类型：';
$it618_crowd_lang['s379'] = '商品类型';
$it618_crowd_lang['s380'] = '所有';
$it618_crowd_lang['s381'] = '实物';
$it618_crowd_lang['s382'] = '卡密';
$it618_crowd_lang['s383'] = '截至该商品最后支持时间【{time}】网站所有商品的最后{count}条支持时间(时、分、秒、毫秒)记录';
$it618_crowd_lang['s384'] = '计算结果';
$it618_crowd_lang['s385'] = '以下';
$it618_crowd_lang['s386'] = '条时间取值之和';
$it618_crowd_lang['s387'] = '取余';
$it618_crowd_lang['s388'] = '总需参与人次';
$it618_crowd_lang['s389'] = '固定数值';
$it618_crowd_lang['s390'] = '总人次';
$it618_crowd_lang['s391'] = '以下时间总和';
$it618_crowd_lang['s392'] = '第';
$it618_crowd_lang['s393'] = '名';
$it618_crowd_lang['s394'] = '商品图片：';
$it618_crowd_lang['s395'] = '选择图片';
$it618_crowd_lang['s396'] = '删除图片';
$it618_crowd_lang['s397'] = '商品图片在商品提交时会自动生成640*640的缩略图，注意：为了美观请保证商品图片宽高都大于640，并且宽高相同';
$it618_crowd_lang['s398'] = '商品列表页的图片';
$it618_crowd_lang['s399'] = '积分与经验比率';
$it618_crowd_lang['s400'] = '经验';
$it618_crowd_lang['s401'] = '说明：如果不设置，积分比率默认为1，可以是大于0的整数或小数，参与记录会记录积分类型与积分比率，这样可以知道每次参与可以增加多少经验，计算后经验值取整';
$it618_crowd_lang['s402'] = '积分类型';
$it618_crowd_lang['s403'] = '简洁描述：';
$it618_crowd_lang['s404'] = '详细内容：';
$it618_crowd_lang['s405'] = 'SEO关键词：';
$it618_crowd_lang['s406'] = 'SEO描述：';
$it618_crowd_lang['s407'] = '保存';
$it618_crowd_lang['s408'] = '商品编辑成功！';
$it618_crowd_lang['s409'] = '编辑商品';
$it618_crowd_lang['s449'] = '天前';
$it618_crowd_lang['s450'] = '小时前';
$it618_crowd_lang['s451'] = '分钟前';
$it618_crowd_lang['s452'] = '秒前';
$it618_crowd_lang['s453'] = '';
$it618_crowd_lang['s454'] = '';
$it618_crowd_lang['s455'] = '我的参与';
$it618_crowd_lang['s456'] = '我的众筹';
$it618_crowd_lang['s457'] = '我的揭晓';
$it618_crowd_lang['s458'] = '发表新帖';
$it618_crowd_lang['s459'] = '帐户设置';
$it618_crowd_lang['s460'] = '退出';
$it618_crowd_lang['s461'] = '登录';
$it618_crowd_lang['s462'] = '注册';
$it618_crowd_lang['s463'] = '您购买的';
$it618_crowd_lang['s464'] = '';
$it618_crowd_lang['s465'] = '已售';
$it618_crowd_lang['s466'] = '全部';
$it618_crowd_lang['s467'] = '查看更多';
$it618_crowd_lang['s468'] = '';
$it618_crowd_lang['s469'] = '';
$it618_crowd_lang['s470'] = '抱歉，您访问的商品不存在！';
$it618_crowd_lang['s471'] = '获得者：';
$it618_crowd_lang['s472'] = '众筹经验：';
$it618_crowd_lang['s473'] = '幸运众筹码：';
$it618_crowd_lang['s474'] = '本期参与：';
$it618_crowd_lang['s475'] = '商品价值：';
$it618_crowd_lang['s476'] = '总需参与：';
$it618_crowd_lang['s477'] = '揭晓时间：';
$it618_crowd_lang['s478'] = '查看详情';
$it618_crowd_lang['s479'] = '';
$it618_crowd_lang['s480'] = '';
$it618_crowd_lang['s481'] = '';
$it618_crowd_lang['s482'] = '评价';
$it618_crowd_lang['s483'] = '分 ';
$it618_crowd_lang['s484'] = '暂无晒单评价';
$it618_crowd_lang['s485'] = '抱歉，请先登录！';
$it618_crowd_lang['s486'] = '抱歉，购买数量要大于0！';
$it618_crowd_lang['s487'] = '抱歉，此商品不存在！';
$it618_crowd_lang['s488'] = '现在充值积分？';
$it618_crowd_lang['s489'] = '';
$it618_crowd_lang['s490'] = '';
$it618_crowd_lang['s491'] = '';
$it618_crowd_lang['s492'] = '';
$it618_crowd_lang['s493'] = '';
$it618_crowd_lang['s494'] = '';
$it618_crowd_lang['s495'] = '';
$it618_crowd_lang['s496'] = '';
$it618_crowd_lang['s497'] = '';
$it618_crowd_lang['s498'] = '抱歉，交易失败，请与管理员联系！';
$it618_crowd_lang['s499'] = '';
$it618_crowd_lang['s500'] = '我要评价';
$it618_crowd_lang['s501'] = '分';
$it618_crowd_lang['s502'] = '评价:';
$it618_crowd_lang['s503'] = '';
$it618_crowd_lang['s504'] = '';
$it618_crowd_lang['s505'] = '金额:';
$it618_crowd_lang['s506'] = '';
$it618_crowd_lang['s507'] = '';
$it618_crowd_lang['s508'] = '状态:';
$it618_crowd_lang['s509'] = '';
$it618_crowd_lang['s510'] = '上一页';
$it618_crowd_lang['s511'] = '下一页';
$it618_crowd_lang['s512'] = '保存成功！';
$it618_crowd_lang['s513'] = '抱歉，参数有误！';
$it618_crowd_lang['s514'] = '';
$it618_crowd_lang['s515'] = '';
$it618_crowd_lang['s516'] = '晒单评价成功！';
$it618_crowd_lang['s517'] = '全部商品';
$it618_crowd_lang['s518'] = '按关键词：';
$it618_crowd_lang['s519'] = '搜 索';
$it618_crowd_lang['s520'] = '折';
$it618_crowd_lang['s521'] = '';
$it618_crowd_lang['s522'] = '';
$it618_crowd_lang['s523'] = '';
$it618_crowd_lang['s524'] = '';
$it618_crowd_lang['s525'] = '';
$it618_crowd_lang['s526'] = '';
$it618_crowd_lang['s527'] = '';
$it618_crowd_lang['s528'] = '';
$it618_crowd_lang['s529'] = '';
$it618_crowd_lang['s530'] = '';
$it618_crowd_lang['s531'] = '';
$it618_crowd_lang['s532'] = '';
$it618_crowd_lang['s533'] = '';
$it618_crowd_lang['s534'] = '';
$it618_crowd_lang['s535'] = '';
$it618_crowd_lang['s536'] = '';
$it618_crowd_lang['s537'] = '';
$it618_crowd_lang['s538'] = '';
$it618_crowd_lang['s539'] = '成功确认消费！';
$it618_crowd_lang['s540'] = '';
$it618_crowd_lang['s541'] = '';
$it618_crowd_lang['s542'] = '';
$it618_crowd_lang['s543'] = '';
$it618_crowd_lang['s544'] = '';
$it618_crowd_lang['s545'] = '';
$it618_crowd_lang['s546'] = '人气:';
$it618_crowd_lang['s547'] = '已售';
$it618_crowd_lang['s548'] = '商品数:';
$it618_crowd_lang['s549'] = '';
$it618_crowd_lang['s550'] = '';
$it618_crowd_lang['s551'] = '';
$it618_crowd_lang['s552'] = '';
$it618_crowd_lang['s553'] = '';
$it618_crowd_lang['s554'] = '';
$it618_crowd_lang['s555'] = '';
$it618_crowd_lang['s556'] = '添加商品';
$it618_crowd_lang['s557'] = '编辑商品';
$it618_crowd_lang['s558'] = '管理商品';
$it618_crowd_lang['s559'] = '首页设置';
$it618_crowd_lang['s597'] = '查找';
$it618_crowd_lang['s598'] = '按快递公司名称';
$it618_crowd_lang['s599'] = '快递公司数量：';
$it618_crowd_lang['s600'] = '快递公司名称';
$it618_crowd_lang['s601'] = '快递公司官网链接';
$it618_crowd_lang['s602'] = '排序';
$it618_crowd_lang['s603'] = '发货数';
$it618_crowd_lang['s607'] = '';
$it618_crowd_lang['s608'] = '个';
$it618_crowd_lang['s609'] = '';
$it618_crowd_lang['s610'] = '';
$it618_crowd_lang['s611'] = '启用';
$it618_crowd_lang['s612'] = '消息提醒设置更新成功！';
$it618_crowd_lang['s613'] = '<strong>第三方短信接口，按短信条数收费，给第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注册账号并充值，然后填以下内容就可以了';
$it618_crowd_lang['s614'] = '启用消息接口：';
$it618_crowd_lang['s615'] = '如果不启用，系统不会有消息提醒功能 <font color=blue>如果支持微信模板消息接口，微信模板ID不为空时，优先发微信模板消息，而不发短信</font>';
$it618_crowd_lang['s616'] = '短信接口账号：';
$it618_crowd_lang['s617'] = '短信接口密码：';
$it618_crowd_lang['s618'] = '测试接收人手机号：';
$it618_crowd_lang['it618']='i11iili1i1ilili111ilil1111iililil11ililil111il11iilili11111111liilili1111ll1i1illii11';
$it618_crowd_lang['s619'] = '多个手机号用英文字母逗号隔开';
$it618_crowd_lang['s620'] = '测试短信内容：';
$it618_crowd_lang['s621'] = '管理员手机号：';
$it618_crowd_lang['s622'] = '如果不启用，管理员不会有消息提醒';
$it618_crowd_lang['s623'] = '消息模板';
$it618_crowd_lang['s624'] = '注意：消息模板只有在“启用”状态，才发送提醒消息，如果短信消息模板和微信消息模板都设置了，优先发送微信消息，发送成功了，就不发短信了，方便节省短信成本';
$it618_crowd_lang['s631'] = '<font color="green">揭晓成功时</font> - <font color=green>管理员消息模板</font>';
$it618_crowd_lang['s632'] = '<font color="#999999">示例：会员${user}成为了${pname}的获得者！<br>标签说明：{user}获得者会员名，{pname}商品名称带期数</font>';
$it618_crowd_lang['s639'] = '<font color="green">揭晓成功时</font> - <font color=red>会员消息模板</font>';
$it618_crowd_lang['s640'] = '<font color="#999999">示例：祝贺您成为了${pname}的获得者！<br>标签说明：{user}获得者会员名，{pname}商品名称带期数</font>';
$it618_crowd_lang['s641'] = '更新';
$it618_crowd_lang['s642'] = '更新时发送一个测试短信';
$it618_crowd_lang['s643'] = '<font color="green">商家发货时</font> - <font color=red>会员消息模板</font>';
$it618_crowd_lang['s644'] = '<font color="#999999">示例：您的${pname}已发货，请在我的揭晓查看快递信息！<br>标签说明：{user}获得者会员名，{pname}商品名称带期数</font>';
$it618_crowd_lang['s645'] = 'QQ号:';
$it618_crowd_lang['s646'] = '微信:';
$it618_crowd_lang['s647'] = '注意：此文章同时也会显示在手机版首页，排序为0时不显示，<font color=blue>首页只能显示3个</font>';
$it618_crowd_lang['s648'] = '文章数：';
$it618_crowd_lang['s649'] = '幸运获得';
$it618_crowd_lang['s650'] = '【';
$it618_crowd_lang['s651'] = '】';
$it618_crowd_lang['s652'] = '';
$it618_crowd_lang['s653'] = '元';
$it618_crowd_lang['s654'] = '';
$it618_crowd_lang['s655'] = '';
$it618_crowd_lang['s656'] = '风格管理';
$it618_crowd_lang['s657'] = '风格数：';
$it618_crowd_lang['s658'] = '搜索框、主导航与类别二级菜单颜色';
$it618_crowd_lang['s659'] = '主导航当前与鼠标移动颜色';
$it618_crowd_lang['s660'] = '默认风格';
$it618_crowd_lang['s661'] = '启用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_crowd_lang['s662'] = '参数名称';
$it618_crowd_lang['s663'] = '参数内容';
$it618_crowd_lang['s664'] = '提示：最多支持9个微信消息模板参数，参数名称比如是：first,keyword1,keyword2,keyword3,...,remark，参数内容支持以上一个标签或多个标签';
$it618_crowd_lang['s665'] = '取消';
$it618_crowd_lang['s666'] = '保存';
$it618_crowd_lang['s667'] = '抱歉，如果参数名称填写了，就必须填写参数内容！';
$it618_crowd_lang['s668'] = '';
$it618_crowd_lang['s669'] = '';
$it618_crowd_lang['s670'] = '';
$it618_crowd_lang['s671'] = '';
$it618_crowd_lang['s672'] = '';
$it618_crowd_lang['s673'] = '';
$it618_crowd_lang['s674'] = '';
$it618_crowd_lang['s675'] = '';
$it618_crowd_lang['s676'] = '查看';
$it618_crowd_lang['s677'] = '快递保存成功！';
$it618_crowd_lang['s678'] = '';
$it618_crowd_lang['s679'] = '未设置收货地址';
$it618_crowd_lang['s680'] = '参与了';
$it618_crowd_lang['s681'] = '的';
$it618_crowd_lang['s682'] = '消息提醒设置更新成功！';
$it618_crowd_lang['s683'] = '您申请的提现成功了，会有短信提醒';
$it618_crowd_lang['s684'] = '您的商品交易成功了，会有短信提醒';
$it618_crowd_lang['s685'] = '表示已开通，只要您开启了短信提醒功能就会有短信提醒';
$it618_crowd_lang['s686'] = '管理员暂时还没有开通短信接口功能！';
$it618_crowd_lang['s687'] = '消息提醒设置';
$it618_crowd_lang['s688'] = '系统短信提醒功能：';
$it618_crowd_lang['s689'] = '启用短信提醒功能：';
$it618_crowd_lang['s690'] = '如果不开启不会有短信提醒';
$it618_crowd_lang['s691'] = '手机号码：';
$it618_crowd_lang['s692'] = '有提醒时此手机号就会收到短信';
$it618_crowd_lang['s693'] = '更新';
$it618_crowd_lang['s694'] = '抱歉，您没有商品管理权限，请与管理员联系！';
$it618_crowd_lang['s695'] = '请选择快递公司！';
$it618_crowd_lang['s696'] = '请输入快递单号！';
$it618_crowd_lang['s697'] = '留言/发货地址';
$it618_crowd_lang['s698'] = '请选择快递公司';
$it618_crowd_lang['s699'] = '快递单号：';
$it618_crowd_lang['s700'] = '保存';
$it618_crowd_lang['s701'] = '参与手机：';
$it618_crowd_lang['s702'] = '查看留言/发货地址';
$it618_crowd_lang['s703'] = '关闭';
$it618_crowd_lang['s704'] = '我有';
$it618_crowd_lang['s705'] = '，只用';
$it618_crowd_lang['s706'] = '购买需要';
$it618_crowd_lang['s707'] = '';
$it618_crowd_lang['s708'] = '快递公司管理';
$it618_crowd_lang['s709'] = '';
$it618_crowd_lang['s710'] = '网站顶部导航';
$it618_crowd_lang['s712'] = '购买右边分享';
$it618_crowd_lang['s713'] = '';
$it618_crowd_lang['s714'] = '';
$it618_crowd_lang['s715'] = '';
$it618_crowd_lang['s716'] = '排序';
$it618_crowd_lang['s717'] = '发货数';
$it618_crowd_lang['s718'] = '';
$it618_crowd_lang['s719'] = '';
$it618_crowd_lang['s720'] = '';
$it618_crowd_lang['s721'] = '';
$it618_crowd_lang['s722'] = '买家确认收货';
$it618_crowd_lang['s723'] = '';
$it618_crowd_lang['s724'] = '';
$it618_crowd_lang['s725'] = '';
$it618_crowd_lang['s726'] = '';
$it618_crowd_lang['s727'] = '';
$it618_crowd_lang['s728'] = '交易成功';
$it618_crowd_lang['s729'] = '';
$it618_crowd_lang['s730'] = '如果开通了短信提醒，会收到短信';
$it618_crowd_lang['s769'] = '确认收货';
$it618_crowd_lang['s770'] = '';
$it618_crowd_lang['s771'] = '';
$it618_crowd_lang['s772'] = '';
$it618_crowd_lang['s773'] = '';
$it618_crowd_lang['s774'] = '';
$it618_crowd_lang['s775'] = '配送：';
$it618_crowd_lang['s776'] = '现在评价';
$it618_crowd_lang['s777'] = '';
$it618_crowd_lang['s778'] = '';
$it618_crowd_lang['s779'] = '成功确认收货，现在可以给此次晒单评价！';
$it618_crowd_lang['s780'] = '';
$it618_crowd_lang['s781'] = '';
$it618_crowd_lang['s782'] = '';
$it618_crowd_lang['s783'] = '买家给我的留言';
$it618_crowd_lang['s784'] = '给买家发货';
$it618_crowd_lang['s785'] = '发货';
$it618_crowd_lang['s786'] = '修改';
$it618_crowd_lang['s787'] = '查看';
$it618_crowd_lang['s788'] = '原因';
$it618_crowd_lang['s789'] = '';
$it618_crowd_lang['s790'] = '抱歉，此会员还没有参与过一次众筹！';
$it618_crowd_lang['s791'] = '抱歉，会员不存在！';
$it618_crowd_lang['s792'] = '买家收货地址';
$it618_crowd_lang['s793'] = '';
$it618_crowd_lang['s794'] = '';
$it618_crowd_lang['s795'] = '价格：';
$it618_crowd_lang['s796'] = '数量：';
$it618_crowd_lang['s797'] = '金额：';
$it618_crowd_lang['s798'] = '';
$it618_crowd_lang['s799'] = '给买家发货';
$it618_crowd_lang['s800'] = '金额';
$it618_crowd_lang['s829'] = '';
$it618_crowd_lang['s830'] = '';
$it618_crowd_lang['s831'] = '新增';
$it618_crowd_lang['s832'] = '我的';
$it618_crowd_lang['s833'] = '我的揭晓';
$it618_crowd_lang['s834'] = '揭晓管理';
$it618_crowd_lang['s835'] = '抱歉，请先登录！';
$it618_crowd_lang['s836'] = '';
$it618_crowd_lang['s837'] = '卡密管理';
$it618_crowd_lang['s838'] = '商品库存：';
$it618_crowd_lang['s839'] = '商品名称：';
$it618_crowd_lang['s840'] = '';
$it618_crowd_lang['s841'] = '';
$it618_crowd_lang['s842'] = '商城最新揭晓页';
$it618_crowd_lang['s843'] = '要导入的记事本文件不存在！';
$it618_crowd_lang['s844'] = '成功批量导入卡密数：';
$it618_crowd_lang['s845'] = '成功清空此商品卡密！';
$it618_crowd_lang['s846'] = '卡密管理';
$it618_crowd_lang['s847'] = '卡密数量：';
$it618_crowd_lang['s848'] = '清空';
$it618_crowd_lang['s849'] = '此操作不可逆，确定要清空此商品所有的卡密？';
$it618_crowd_lang['s850'] = '<strong>添加方式一：</strong>直接把卡密复制到下面文本框内，一行一个卡密';
$it618_crowd_lang['s851'] = '<strong>添加方式二：</strong>直接导入有卡密的记事本txt文件，记事本内一行一个卡密';
$it618_crowd_lang['s852'] = '批量添加';
$it618_crowd_lang['s853'] = '上传文件';
$it618_crowd_lang['s854'] = '批量导入';
$it618_crowd_lang['s855'] = '商品名称：';
$it618_crowd_lang['s856'] = '返回商品列表';
$it618_crowd_lang['s857'] = '成功批量添加卡密数：';
$it618_crowd_lang['s858'] = '修改收货地址';
$it618_crowd_lang['s859'] = '多个QQ用逗号隔开 如：123456,234567';
$it618_crowd_lang['s860'] = '客服职位';
$it618_crowd_lang['s861'] = '多个职位用逗号隔开 如：销售,采购 请注意如果是多个时和上面的QQ的个数与顺序对应好';
$it618_crowd_lang['s862'] = '参与会员';
$it618_crowd_lang['s863'] = '收货地址';
$it618_crowd_lang['s864'] = '抱歉，此商品没有库存了，请与管理员联系！';
$it618_crowd_lang['s865'] = '查看卡密';
$it618_crowd_lang['s866'] = '给买家发货';
$it618_crowd_lang['s867'] = '买家留言';
$it618_crowd_lang['s868'] = '保密';
$it618_crowd_lang['s869'] = '留言';
$it618_crowd_lang['s870'] = '设置收货地址';
$it618_crowd_lang['s871'] = '首页中间公告管理';
$it618_crowd_lang['s872'] = '电脑版手机版首页轮播';
$it618_crowd_lang['s873'] = '公告数：';
$it618_crowd_lang['s874'] = '注意：此公告同时也会显示在手机版首页，排序为0时不显示';
$it618_crowd_lang['s875'] = '标题';
$it618_crowd_lang['s876'] = '链接';
$it618_crowd_lang['s877'] = '文字是否粗体';
$it618_crowd_lang['s878'] = '排序';
$it618_crowd_lang['s879'] = '此轮播同时也会显示在手机版首页，为了手机版首页轮播美观，请一定保持图片的宽高一致';
$it618_crowd_lang['s880'] = '电脑版手机版首页轮播';
$it618_crowd_lang['s881'] = '图片(宽：212px，高：52px)';
$it618_crowd_lang['s882'] = '链接(为空时图片不带链接)';
$it618_crowd_lang['s883'] = '上传图片';
$it618_crowd_lang['s884'] = '删除';
$it618_crowd_lang['s885'] = '提交';
$it618_crowd_lang['s886'] = '注意：有时商品一级类别不够8个时，可以设置图片，分类导航就显示带链接图片，同时其它与此分类相关的功能也隐藏';
$it618_crowd_lang['s887'] = '，商品最低价格限制(最低价格：<font color=blue><b>{price}</b></font> 元)';
$it618_crowd_lang['s888'] = '本月经验';
$it618_crowd_lang['s889'] = '模块DIY调用';
$it618_crowd_lang['s890'] = '分钟';
$it618_crowd_lang['s891'] = '模块数量：';
$it618_crowd_lang['s892'] = 'DIY调用标识符';
$it618_crowd_lang['s893'] = '模块类型';
$it618_crowd_lang['s894'] = '模板内容(编辑器右下角可以缩小扩大)';
$it618_crowd_lang['s895'] = '记录条数';
$it618_crowd_lang['s896'] = '开启JS调用';
$it618_crowd_lang['s897'] = '缓存时间';
$it618_crowd_lang['s898'] = '最新商品';
$it618_crowd_lang['s899'] = '热销商品';
$it618_crowd_lang['s900'] = '自定义内容';
$it618_crowd_lang['s901'] = '请复制(CTRL+C)以下内容并添加到 HTML 文件中';
$it618_crowd_lang['s902'] = '外部调用';
$it618_crowd_lang['s903'] = '提交后编辑模板内容，并且模块类型不可修改';
$it618_crowd_lang['s904'] = '默认10条记录';
$it618_crowd_lang['s905'] = '默认不开启';
$it618_crowd_lang['s906'] = '默认缓存时间为1分钟';
$it618_crowd_lang['s907'] = '<strong>编辑器用法：</strong><img src="source/plugin/it618_crowd/images/editer.png"/> <font color="red">注意非自定义模块推荐在HTML代码模式下编辑，编辑器全屏功能很方便哦</font><hr />
<strong>通用标签：</strong>[loop]...[/loop] 循环显示内容，{siteurl} 本站的网址外站调用时可到<hr />
<strong>商品标签：</strong>{pname} 商品名称，{ppicsrc} 商品图片地址，{puprice} 商品价格，{pprice} 商品市场价，{pcount} 商品库存，{pviews} 商品人气，{psalecount} 商品交易数，{purl} 商品链接
';
$it618_crowd_lang['s908'] = '显示';
$it618_crowd_lang['s909'] = '点击显示隐藏模块内容编辑器';
$it618_crowd_lang['s910'] = '隐藏';
$it618_crowd_lang['s911'] = '主导航设置';
$it618_crowd_lang['s912'] = '名称';
$it618_crowd_lang['s913'] = '链接';
$it618_crowd_lang['s914'] = '名称颜色';
$it618_crowd_lang['s915'] = '排序';
$it618_crowd_lang['s916'] = '数量：';
$it618_crowd_lang['s917'] = '提示：如果以下主导航为空，主导航默认显示商家一级分类，排序值为0时不显示';
$it618_crowd_lang['s918'] = '新窗口打开';
$it618_crowd_lang['s941'] = '元';
$it618_crowd_lang['s942'] = '';
$it618_crowd_lang['s943'] = '"0" => "短信发送成功",
"-1" => "参数不全",
"-2" => "服务器空间不支持,请确认支持curl或者fsocket，联系您的空间商解决或者更换空间！",
"30" => "密码错误",
"40" => "账号不存在",
"41" => "余额不足",
"42" => "帐户已过期",
"43" => "IP地址限制",
"50" => "内容含有敏感词';
$it618_crowd_lang['s960'] = '积分钱包';
$it618_crowd_lang['s961'] = '电脑版风格';
$it618_crowd_lang['s962'] = '手机版风格';
$it618_crowd_lang['s963'] = '手机版图标导航';
$it618_crowd_lang['s973'] = '整体颜色';
$it618_crowd_lang['s974'] = '部分边框对比颜色';
$it618_crowd_lang['s975'] = '默认风格';
$it618_crowd_lang['s976'] = '导航数：';
$it618_crowd_lang['s977'] = '注意：导航图标为了清晰，推荐宽高60到120，导航标题推荐最多4个字，排序为0时不显示';
$it618_crowd_lang['s978'] = '图标';
$it618_crowd_lang['s979'] = '标题';
$it618_crowd_lang['s980'] = '链接';
$it618_crowd_lang['s981'] = '新窗口';
$it618_crowd_lang['s982'] = '文字颜色(无突出效果时要为空)';
$it618_crowd_lang['s983'] = '文字粗体';
$it618_crowd_lang['s984'] = '排序';
$it618_crowd_lang['s985'] = '提交后再上传图片';
$it618_crowd_lang['s986'] = '注意：默认8个图标导航是商品分类，默认的链接plugin.php?id=it618_crowd:wap&pagetype=search&cid=1不是伪静态的，可以自己修改crowd_wap-search-1.html，1就是一级商品分类编号';
$it618_crowd_lang['s987'] = '手机首页自定广告';
$it618_crowd_lang['s988'] = '上传图片';
$it618_crowd_lang['s989'] = '最新商品';
$it618_crowd_lang['s990'] = '人气商品';
$it618_crowd_lang['s991'] = '电脑版显示商品数,手机版显示商品数,显示顺序：';
$it618_crowd_lang['s992'] = '注意3个数值之间用逗号,隔开，默认值：';
$it618_crowd_lang['s993'] = '查看全部';
$it618_crowd_lang['s994'] = '商品';
$it618_crowd_lang['s1028'] = '抱歉，您的';
$it618_crowd_lang['s1029'] = '不足，不能订购商品！';
$it618_crowd_lang['s1040'] = '短信接口类型：';
$it618_crowd_lang['s1041'] = '默认标配短信接口(短信宝)';
$it618_crowd_lang['s1042'] = 'IT618统一短信接口(阿里大鱼)';
$it618_crowd_lang['s1043'] = '短信签名：';
$it618_crowd_lang['s1044'] = 'IT618统一短信接口(阿里云短信)';
$it618_crowd_lang['s1045'] = '<font color=green><b>抱歉，您还没有安装 【<a href="http://addon.discuz.com/?@it618_members.plugin" target="_blank">it618会员短信微信</a>】，此插件为IT618公用短信接口插件，<font color=red>同时还是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_crowd_lang['s1046'] = '短信模板ID：';
$it618_crowd_lang['s1050'] = '管理员UID<font color=#999>(用于微信消息，多个UID用,隔开)</font>：';
$it618_crowd_lang['s1051'] = '微信消息模板ID：';
$it618_crowd_lang['s1052'] = '微信消息标签值：';
$it618_crowd_lang['s1053'] = '<font color=#999>提示：优先发送微信消息，发送成功了，就不发短信了</font>';
$it618_crowd_lang['s1054'] = '';
$it618_crowd_lang['s1060'] = '客服';
$it618_crowd_lang['s1076'] = '手机号码';
$it618_crowd_lang['s1077'] = '收货地址';
$it618_crowd_lang['s1078'] = '姓名：';
$it618_crowd_lang['s1079'] = '手机：';
$it618_crowd_lang['s1080'] = '地址：';
$it618_crowd_lang['s1081'] = '抱歉，请先添加商品到购物车！';
$it618_crowd_lang['s1082'] = '抱歉，您购物车内的商品种数超过了gwcpcount的最高限制数！';
$it618_crowd_lang['s1090'] = '抱歉，商品不存在，请从购物车删除此商品！';
$it618_crowd_lang['s1096'] = '抱歉，此商品没有库存，不能参与！';
$it618_crowd_lang['s1767'] = '';
$it618_crowd_lang['s1768'] = '请输入您要搜索的商品名称关键词...';
$it618_crowd_lang['s1769'] = '验证买家到店交易密码 点击此按钮';
$it618_crowd_lang['s1770'] = '商品类别';
$it618_crowd_lang['s1771'] = '请输入商品关键字';
$it618_crowd_lang['s1772'] = '限5张';
$it618_crowd_lang['s1773'] = '添加照片';
$it618_crowd_lang['s1774'] = '商城购物车页';
$it618_crowd_lang['s1775'] = '<font color=red>提示：有交易的商品不能删除，可以修改商品，也可以下架商品！</font>';
$it618_crowd_lang['s1776'] = '收起';
$it618_crowd_lang['s1777'] = '交易备注';
$it618_crowd_lang['s1778'] = '备注内容：';
$it618_crowd_lang['s1779'] = '揭晓管理人员可以给交易备注，方便给买家准确发货';
$it618_crowd_lang['s1780'] = '备注成功！';
$it618_crowd_lang['s1781'] = '抱歉，请输入备注内容！';
$it618_crowd_lang['s1782'] = '字';
$it618_crowd_lang['s1783'] = '抱歉，此插件还未开启，请先开启！';
$it618_crowd_lang['s1784'] = '交易积分：';
$it618_crowd_lang['s1785'] = '积分信息';
$it618_crowd_lang['s1878'] = '阿里云OSS设置';
$it618_crowd_lang['s1879'] = '启用oss接口：';
$it618_crowd_lang['s1880'] = '如果不启用，上传图片到本地，如果启用，上传图片到oss，并且返回图片网络引用链接';
$it618_crowd_lang['s1881'] = 'IT618插件阿里云OSS接口设置方法';
$it618_crowd_lang['s1882'] = 'Access Key ID：';
$it618_crowd_lang['s1883'] = 'Access Key Secret：';
$it618_crowd_lang['s1884'] = 'Bucket名称：';
$it618_crowd_lang['s1885'] = 'Bucket域名EndPoint：';
$it618_crowd_lang['s1886'] = 'Bucket外网访问域名：';
$it618_crowd_lang['s1888'] = '如果是个人申请的变量字符最多限制个数：';
$it618_crowd_lang['s1889'] = '不受限制时请不要填写';


$it618_crowd_lang['t1'] = '交易号';
$it618_crowd_lang['t2'] = '商品名称';
$it618_crowd_lang['t3'] = '状态';
$it618_crowd_lang['t4'] = '晒单评价';
$it618_crowd_lang['t5'] = '参与时间';
$it618_crowd_lang['t6'] = '揭晓时间';
$it618_crowd_lang['t7'] = '参与人次';
$it618_crowd_lang['t8'] = '我的揭晓';
$it618_crowd_lang['t9'] = '单价';
$it618_crowd_lang['t10'] = '积分';
$it618_crowd_lang['t11'] = '保存';
$it618_crowd_lang['t12'] = '按关键词';
$it618_crowd_lang['t13'] = '状态';
$it618_crowd_lang['t14'] = '所有状态';
$it618_crowd_lang['t15'] = '未发货';
$it618_crowd_lang['t16'] = '已发货';
$it618_crowd_lang['t17'] = '已收货';
$it618_crowd_lang['t18'] = '参与数：';
$it618_crowd_lang['t19'] = '商品名称为红色时，表示此次参与是获得者';
$it618_crowd_lang['t20'] = '已参与：';
$it618_crowd_lang['t21'] = '查找';
$it618_crowd_lang['t22'] = '已揭晓';
$it618_crowd_lang['t23'] = '';
$it618_crowd_lang['t24'] = '';
$it618_crowd_lang['t25'] = '';
$it618_crowd_lang['t26'] = '';
$it618_crowd_lang['t27'] = '';
$it618_crowd_lang['t28'] = '必填 方便联系';
$it618_crowd_lang['t29'] = '同时支持短信提醒，如果您成为获得者，会给此手机号发短信';
$it618_crowd_lang['t30'] = '晒单评价';
$it618_crowd_lang['t31'] = '揭晓时间';
$it618_crowd_lang['t32'] = '';
$it618_crowd_lang['t33'] = '';
$it618_crowd_lang['t34'] = '';
$it618_crowd_lang['t35'] = '很差';
$it618_crowd_lang['t36'] = '较差';
$it618_crowd_lang['t37'] = '一般';
$it618_crowd_lang['t38'] = '较好';
$it618_crowd_lang['t39'] = '很好';
$it618_crowd_lang['t40'] = '请评分';
$it618_crowd_lang['t41'] = '确认收货后可以对商品进行晒单评价，每次消费只能评价一次，综合评分直接参与商品总评分和满意度计算，其它3个评分是买家对商品的更详细的评价，并且只对自己的总评分参与计算';
$it618_crowd_lang['t42'] = '5至400字数内';
$it618_crowd_lang['t43'] = '提交';
$it618_crowd_lang['t44'] = '取消';
$it618_crowd_lang['t45'] = '晒单评价';
$it618_crowd_lang['t46'] = '商家设置';
$it618_crowd_lang['t47'] = '基本信息';
$it618_crowd_lang['t48'] = '消息提醒设置';
$it618_crowd_lang['t49'] = '商品管理';
$it618_crowd_lang['t50'] = '最新揭晓';
$it618_crowd_lang['t51'] = '总经验';
$it618_crowd_lang['t52'] = '推荐文章';
$it618_crowd_lang['t53'] = '会员';
$it618_crowd_lang['t54'] = '经验';
$it618_crowd_lang['t55'] = '排名';
$it618_crowd_lang['t56'] = '';
$it618_crowd_lang['t57'] = '';
$it618_crowd_lang['t58'] = '星期日';
$it618_crowd_lang['t59'] = '星期一';
$it618_crowd_lang['t60'] = '星期二';
$it618_crowd_lang['t61'] = '星期三';
$it618_crowd_lang['t62'] = '星期四';
$it618_crowd_lang['t63'] = '星期五';
$it618_crowd_lang['t64'] = '星期六';
$it618_crowd_lang['t65'] = '月';
$it618_crowd_lang['t66'] = '日';
$it618_crowd_lang['t67'] = '';
$it618_crowd_lang['t68'] = '';
$it618_crowd_lang['t69'] = '';
$it618_crowd_lang['t70'] = '';
$it618_crowd_lang['t71'] = '';
$it618_crowd_lang['t72'] = '';
$it618_crowd_lang['t73'] = '';
$it618_crowd_lang['t74'] = '';
$it618_crowd_lang['t75'] = '';
$it618_crowd_lang['t76'] = '';
$it618_crowd_lang['t77'] = '';
$it618_crowd_lang['t78'] = '';
$it618_crowd_lang['t79'] = '';
$it618_crowd_lang['t80'] = '';
$it618_crowd_lang['t81'] = '';
$it618_crowd_lang['t82'] = '';
$it618_crowd_lang['t83'] = '搜索';
$it618_crowd_lang['t84'] = '首页';
$it618_crowd_lang['t85'] = '全部商品分类';
$it618_crowd_lang['t86'] = '热门分类';
$it618_crowd_lang['t87'] = '人气分类';
$it618_crowd_lang['t88'] = '更多';
$it618_crowd_lang['t89'] = '热门商品';
$it618_crowd_lang['t90'] = '最近刚参与的商品';
$it618_crowd_lang['t91'] = '最近参与';
$it618_crowd_lang['t92'] = '一周内揭晓最多的商品';
$it618_crowd_lang['t93'] = '一周热揭';
$it618_crowd_lang['t94'] = '回到顶部';
$it618_crowd_lang['t95'] = '找到';
$it618_crowd_lang['t96'] = '“';
$it618_crowd_lang['t97'] = '”';
$it618_crowd_lang['t98'] = '相关的商品共';
$it618_crowd_lang['t99'] = '个。';
$it618_crowd_lang['t100'] = '分&nbsp;&nbsp;类：';
$it618_crowd_lang['t101'] = '揭晓期数';
$it618_crowd_lang['t102'] = '揭晓期数从高到低';
$it618_crowd_lang['t103'] = '即将揭晓';
$it618_crowd_lang['t104'] = '剩余人次从低到高';
$it618_crowd_lang['t105'] = '剩余人次';
$it618_crowd_lang['t106'] = '参与单价从低到高';
$it618_crowd_lang['t107'] = '单价';
$it618_crowd_lang['t108'] = '商品价值从高到低';
$it618_crowd_lang['t109'] = '按发布时间排序';
$it618_crowd_lang['t110'] = '发布时间';
$it618_crowd_lang['t111'] = '揭晓排行';
$it618_crowd_lang['t112'] = '您的位置：';
$it618_crowd_lang['t113'] = '价值';
$it618_crowd_lang['t114'] = '商品价值从低到高';
$it618_crowd_lang['t115'] = '人气';
$it618_crowd_lang['t116'] = '人已评价';
$it618_crowd_lang['t117'] = '分';
$it618_crowd_lang['t118'] = '价值:';
$it618_crowd_lang['t119'] = '我现有';
$it618_crowd_lang['t120'] = '参与';
$it618_crowd_lang['t121'] = '我要参与';
$it618_crowd_lang['t122'] = '立即购买';
$it618_crowd_lang['t123'] = '即将揭晓商品';
$it618_crowd_lang['t124'] = '揭晓排行';
$it618_crowd_lang['t125'] = '参与动态';
$it618_crowd_lang['t126'] = '商家位置';
$it618_crowd_lang['t127'] = '商品详情';
$it618_crowd_lang['t128'] = '晒单评价（';
$it618_crowd_lang['t129'] = '）';
$it618_crowd_lang['t130'] = '单价:';
$it618_crowd_lang['t131'] = '还没有人晒单评价';
$it618_crowd_lang['t132'] = '需';
$it618_crowd_lang['t133'] = '确定购买';
$it618_crowd_lang['t134'] = '1、参与人次如果大于实时剩余人次，交易时参与人次自动等于剩余人次<br>2、如果商品揭晓时，<font color=red>您幸运的成为获得者，请在我的揭晓填写收货地址，不填写不发货</font>，如果是虚拟商品，会自动发货的';
$it618_crowd_lang['t141'] = '查看本期参与记录';
$it618_crowd_lang['t142'] = '晒单评价';
$it618_crowd_lang['t143'] = '评价人次：';
$it618_crowd_lang['t144'] = '满意占比：';
$it618_crowd_lang['t145'] = '分';
$it618_crowd_lang['t146'] = '晒单评价';
$it618_crowd_lang['t147'] = '请稍后，加载中…';
$it618_crowd_lang['t148'] = '购买提示：<br>';
$it618_crowd_lang['t149'] = '购买提示';
$it618_crowd_lang['t150'] = '已消费';
$it618_crowd_lang['t151'] = '人';
$it618_crowd_lang['t152'] = '最多只能参与';
$it618_crowd_lang['t153'] = '最少要参与';
$it618_crowd_lang['t154'] = '人次';
$it618_crowd_lang['t155'] = '查看全部分类';
$it618_crowd_lang['t156'] = '热&nbsp;&nbsp;门：';
$it618_crowd_lang['t157'] = '至';
$it618_crowd_lang['t158'] = '导航';
$it618_crowd_lang['t159'] = '商城首页';
$it618_crowd_lang['t160'] = '网站首页';
$it618_crowd_lang['t161'] = '商品分类';
$it618_crowd_lang['t162'] = '晒单评价';
$it618_crowd_lang['t163'] = '揭晓管理';
$it618_crowd_lang['t164'] = '按关键词';
$it618_crowd_lang['t165'] = '会员名称：';
$it618_crowd_lang['t166'] = '查询';
$it618_crowd_lang['t167'] = '';
$it618_crowd_lang['t168'] = '查看';
$it618_crowd_lang['t169'] = '发货';
$it618_crowd_lang['t170'] = '确定要给以下交易发货？';
$it618_crowd_lang['t171'] = '管理后台';
$it618_crowd_lang['t172'] = '关闭';
$it618_crowd_lang['t173'] = '我的揭晓';
$it618_crowd_lang['t174'] = '';
$it618_crowd_lang['t175'] = '评价内容字数至少5个！';
$it618_crowd_lang['t176'] = '评价内容字数最多400个！';
$it618_crowd_lang['t177'] = '确定要提交此次晒单评价？提交后不可修改。';
$it618_crowd_lang['t178'] = '您输入了';
$it618_crowd_lang['t179'] = '个字！';
$it618_crowd_lang['t180'] = '登录';
$it618_crowd_lang['t181'] = '注册';
$it618_crowd_lang['t182'] = '商家地址：';
$it618_crowd_lang['t183'] = '分 评价人次:';
$it618_crowd_lang['t184'] = '满意占比:';
$it618_crowd_lang['t185'] = '交易信息：';
$it618_crowd_lang['t186'] = '关闭';
$it618_crowd_lang['t187'] = '购物车';
$it618_crowd_lang['t188'] = '购买成功，谢谢您的参与支持！';
$it618_crowd_lang['t189'] = '';
$it618_crowd_lang['t190'] = '数量不能超过您自己现在有的数量！';
$it618_crowd_lang['t191'] = '电脑版';
$it618_crowd_lang['t192'] = '立即购买';
$it618_crowd_lang['t193'] = '加入购物车';
$it618_crowd_lang['t194'] = '';
$it618_crowd_lang['t195'] = '';
$it618_crowd_lang['t196'] = '手机号码：';
$it618_crowd_lang['t197'] = '库存';
$it618_crowd_lang['t198'] = '正在交易...如果您不想等可以关闭交易窗口，后台会自动运行！';
$it618_crowd_lang['t199'] = '积分购买';
$it618_crowd_lang['t200'] = '本次参与';
$it618_crowd_lang['t201'] = '';
$it618_crowd_lang['t202'] = '积分';
$it618_crowd_lang['t203'] = '';
$it618_crowd_lang['t204'] = '';
$it618_crowd_lang['t205'] = '收货地址：';
$it618_crowd_lang['t206'] = '给商家留言：';
$it618_crowd_lang['t207'] = '在商家没有设置快递信息前，收货地址是可以修改的';
$it618_crowd_lang['t208'] = '收货姓名：';
$it618_crowd_lang['t209'] = '收货手机：';
$it618_crowd_lang['t210'] = '：';
$it618_crowd_lang['t211'] = '收货地址：';
$it618_crowd_lang['t212'] = '';
$it618_crowd_lang['t213'] = '';
$it618_crowd_lang['t214'] = '';
$it618_crowd_lang['t215'] = '收货地址提交成功！';
$it618_crowd_lang['t216'] = '抱歉，请填写有效的11位手机号码！';
$it618_crowd_lang['t217'] = '抱歉，请填写收货地址！';
$it618_crowd_lang['t218'] = '在线客服';
$it618_crowd_lang['t219'] = '【参与记录】';
$it618_crowd_lang['t220'] = '确定要确认收货？此操作不可逆。';
$it618_crowd_lang['t221'] = '三大服务保证：';
$it618_crowd_lang['t222'] = '100%公平公正';
$it618_crowd_lang['t223'] = '100%正品保证';
$it618_crowd_lang['t224'] = '全国免费配送';
$it618_crowd_lang['t225'] = '怎么玩儿';
$it618_crowd_lang['t226'] = '选择商品';
$it618_crowd_lang['t227'] = '选择心仪商品<br /> 点击立即购买';
$it618_crowd_lang['t228'] = '积分购买';
$it618_crowd_lang['t229'] = '支持N个单价积分<br /> 获得N个众筹码';
$it618_crowd_lang['t230'] = '揭晓幸运儿';
$it618_crowd_lang['t231'] = '当1件商品的所有份额都获得<br /> 支持后，计算出幸运获得者';
$it618_crowd_lang['t232'] = '查看众筹码';
$it618_crowd_lang['t233'] = '客服QQ：';
$it618_crowd_lang['t234'] = '商家发货后，超过';
$it618_crowd_lang['t235'] = '天不确认收货，系统自动确认收货';
$it618_crowd_lang['t237'] = '提示';
$it618_crowd_lang['t238'] = '期数';
$it618_crowd_lang['t239'] = '参与记录';
$it618_crowd_lang['t240'] = '揭晓记录（';
$it618_crowd_lang['t241'] = '【揭晓记录】';
$it618_crowd_lang['t242'] = '会员';
$it618_crowd_lang['t243'] = '参与人次';
$it618_crowd_lang['t244'] = '单价';
$it618_crowd_lang['t245'] = '积分';
$it618_crowd_lang['t246'] = '参与时间';
$it618_crowd_lang['t247'] = '揭晓时间';
$it618_crowd_lang['t248'] = '幸运众筹码';
$it618_crowd_lang['t249'] = '刷新交易';
$it618_crowd_lang['t250'] = '会员';
$it618_crowd_lang['t251'] = '时间';
$it618_crowd_lang['t252'] = '参与记录';
$it618_crowd_lang['t253'] = '揭晓记录';
$it618_crowd_lang['t254'] = '全部商品';
$it618_crowd_lang['t255'] = '商品类别:';
$it618_crowd_lang['t256'] = '商品地区:';
$it618_crowd_lang['t257'] = '所有一级分类';
$it618_crowd_lang['t258'] = '所有二级分类';
$it618_crowd_lang['t261'] = '关键字词:';
$it618_crowd_lang['t262'] = '商品价格:';
$it618_crowd_lang['t268'] = '排序方式:';
$it618_crowd_lang['t269'] = '即将揭晓';
$it618_crowd_lang['t270'] = '商品价格';
$it618_crowd_lang['t271'] = '商品揭晓';
$it618_crowd_lang['t272'] = '商品人气';
$it618_crowd_lang['t273'] = '查看全部商品';
$it618_crowd_lang['t274'] = '还未揭晓';
$it618_crowd_lang['t275'] = '';
$it618_crowd_lang['t276'] = '';
$it618_crowd_lang['t277'] = '搜索';
$it618_crowd_lang['t278'] = '现金购买';
$it618_crowd_lang['t285'] = '关闭';
$it618_crowd_lang['t286'] = '评价内容字数至少5个！';
$it618_crowd_lang['t287'] = '评价内容字数最多400个！';
$it618_crowd_lang['t288'] = '确定要提交此次晒单评价？提交后不可修改。';
$it618_crowd_lang['t289'] = '';
$it618_crowd_lang['t290'] = '';
$it618_crowd_lang['t291'] = '您输入了';
$it618_crowd_lang['t292'] = '个字！';
$it618_crowd_lang['t293'] = '开始日期不能大于截止日期！';
$it618_crowd_lang['t294'] = '';
$it618_crowd_lang['t295'] = '确定要确认收货？此操作不可逆。';
$it618_crowd_lang['t296'] = '请输入商品关键词';
$it618_crowd_lang['t297'] = '抱歉，你的浏览器不支持此操作。\n请使用按键 Ctrl+D 收藏网站。';
$it618_crowd_lang['t306'] = '抱歉，请先登录！也可以点确定直接跳转到登录页面！';
$it618_crowd_lang['t312'] = '最新发布的商品';
$it618_crowd_lang['t313'] = '浏览量最多的商品';
$it618_crowd_lang['t314'] = '热门商品';
$it618_crowd_lang['t315'] = '消费类型';
$it618_crowd_lang['t316'] = '支付方式';
$it618_crowd_lang['t317'] = '商品搜索';
$it618_crowd_lang['t326'] = '揭晓';
$it618_crowd_lang['t339'] = '确定要修改此次晒单评价？修改后您还可以再修改！';
$it618_crowd_lang['t340'] = '返回';
$it618_crowd_lang['t341'] = '刷新';
$it618_crowd_lang['t342'] = '';
$it618_crowd_lang['t343'] = '';
$it618_crowd_lang['t344'] = '抱歉，请填写收货姓名！';
$it618_crowd_lang['t345'] = '回复：';
$it618_crowd_lang['t346'] = '抱歉，请输入评价回复内容！';
$it618_crowd_lang['t347'] = '确定要提交评价回复内容？';
$it618_crowd_lang['t348'] = '评价回复成功！';
$it618_crowd_lang['t349'] = '分享商品';
$it618_crowd_lang['t359'] = '手机扫码访问此商品';
$it618_crowd_lang['t363'] = '查看在线客服';
$it618_crowd_lang['t364'] = '展开';
$it618_crowd_lang['t365'] = '关闭在线客服';
$it618_crowd_lang['t366'] = '收缩';
$it618_crowd_lang['t367'] = '商家信息';
$it618_crowd_lang['t368'] = '工作时间';
$it618_crowd_lang['t369'] = '热线电话';
$it618_crowd_lang['t376'] = '分享';
$it618_crowd_lang['t377'] = '';
$it618_crowd_lang['t378'] = '';
$it618_crowd_lang['t379'] = '';
$it618_crowd_lang['t380'] = '';
$it618_crowd_lang['t381'] = '购物车添加成功！';
$it618_crowd_lang['t382'] = '此商品已经在购物车！';
$it618_crowd_lang['t383'] = '给商家留言';
$it618_crowd_lang['t758'] = '返回上页';
$it618_crowd_lang['t759'] = '刷新页面';
$it618_crowd_lang['t760'] = '搜索商品';
$it618_crowd_lang['t748'] = '单价/参与人次';
$it618_crowd_lang['t749'] = '设置参与人次';
$it618_crowd_lang['t750'] = '批量购买';
$it618_crowd_lang['t751'] = '完成';
$it618_crowd_lang['t752'] = '商品/参与情况';
$it618_crowd_lang['t753'] = '清空购物车';
$it618_crowd_lang['t754'] = '小计';
$it618_crowd_lang['t755'] = '操作';
$it618_crowd_lang['t756'] = '确定购买';
$it618_crowd_lang['t757'] = '我的<br>导航';
$it618_crowd_lang['t758'] = '返回上页';
$it618_crowd_lang['t759'] = '刷新页面';
$it618_crowd_lang['t760'] = '搜索商品';
$it618_crowd_lang['t763'] = '复制链接';
$it618_crowd_lang['t764'] = '请升级您的微信版本！';
$it618_crowd_lang['t765'] = '链接复制成功！';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_crowd_set'));
if($count==0){
$sql = <<<EOF
	INSERT INTO `pre_it618_crowd_set` (`id`, `setname`, `setvalue`) VALUES
(1, 'topnav', '<li>\r\n	<a id="AddFavorite" href="javascript:void(0);">收藏IT618</a><span></span>\r\n</li>\r\n<li>\r\n	<a target="_blank" href="">帮助</a><span></span>\r\n</li>\r\n<li>\r\n	<a target="_blank" href="">反馈</a>\r\n</li>'),
(2, 'hotclassgoods', '3,1,2,6,8,9,12,13,15,18,19@@@3,1,2,6,8,9,12,13,15,18,1,2,6,8,9,12,13,15,18,19@@@1,2,1,2,1,2,1,2,1,2,1,2'),
(3, 'footer', '<footer id="footer">\r\n<div class="footer-top">\r\n	<div class="site-info">\r\n		<dl>\r\n			<dt>\r\n				服务保障\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">商城三包</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">退换货服务</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">支付方式</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				用户帮助\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">答疑反馈</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">常见问题</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">往期商城</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">抽奖活动</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				商务合作\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">商城合作</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">开放API</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank">商城联盟</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="">友情链接</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				公司信息\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">关于商城</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">媒体报道</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">加入我们</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">法律中心</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				移动商城\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank">团购APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">商城酒店预订APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">商城电影APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">商城wap版</a> \r\n			</dd>\r\n		</dl>\r\n		<div class="code">\r\n			<img src="source/plugin/it618_crowd/images/code.png" /> \r\n		</div>\r\n		<div class="clr">\r\n		</div>\r\n	</div>\r\n</div>\r\n</footer>');

EOF;
$sql=str_replace("pre_it618_crowd_set",DB::table('it618_crowd_set'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_crowd_class1` (`id`, `it618_classname`, `it618_color`, `it618_order`, `it618_istj`, `it618_cssname`, `it618_goodscount`, `it618_wapgoodscount`, `it618_classnamenav`, `it618_pj`) VALUES
(1, '手机数码', '#6f7edb', 1, 0, 'jiudian', 8, 4, '手机', '综合评分_描述相符_质量_服务'),
(2, '电脑办公', '#ef6452', 2, 0, 'yule', 8, 4, '电脑', '综合评分_描述相符_质量_服务'),
(3, '家用电器', '#4caf7d', 3, 0, 'dianying', 8, 4, '电器', '综合评分_描述相符_质量_服务'),
(4, '化妆个护', '#da6cb3', 4, 0, 'liren', 8, 4, '个护', '综合评分_描述相符_质量_服务'),
(5, '食品饮料', '#AC735F', 5, 0, 'meishi', 8, 4, '食品', '综合评分_描述相符_质量_服务'),
(6, '家居箱包', '#4caf7d', 6, 0, 'sheying', 8, 4, '家居', '综合评分_描述相符_质量_服务'),
(7, '母婴用品', '#82bc55', 7, 0, 'shenghuo', 8, 4, '母婴', '综合评分_描述相符_质量_服务'),
(8, '运动户外', '#5cb0c8', 8, 0, 'lvyou', 8, 4, '运动', '综合评分_描述相符_质量_服务'),
(9, '其他商品', '#c89d66', 9, 0, 'gouwu', 8, 4, '其他', '综合评分_描述相符_质量_服务');
EOF;
$sql=str_replace("pre_it618_crowd_class1",DB::table('it618_crowd_class1'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_crowd_class2` (`id`, `it618_class1_id`, `it618_classname`, `it618_color`, `it618_order`, `it618_istj`) VALUES
(1, 1, '华为', '#FF0000', 1, 1),
(2, 1, '苹果', '', 2, 1),
(3, 1, '魅族', '', 3, 1),
(4, 1, '小米', '', 4, 1),
(5, 1, 'vivo', '', 5, 1),
(6, 1, '三星', '', 6, 1),
(7, 1, '相机', '', 7, 1),
(8, 1, '电玩', '', 8, 1),
(9, 2, '台式机', '', 1, 1),
(10, 2, '笔记本', '#FF0000', 2, 1),
(11, 2, '显示器', '', 3, 1),
(12, 2, '音箱', '', 4, 1),
(13, 2, '键盘', '', 5, 1),
(14, 2, '鼠标', '', 6, 1),
(15, 2, '路由器', '', 7, 1),
(16, 2, '打印机', '', 8, 1),
(17, 3, '彩电', '#FF0000', 1, 1),
(18, 3, '冰箱', '', 2, 1),
(19, 3, '空调', '', 3, 1),
(20, 3, '洗衣机', '', 4, 1),
(21, 3, '电风扇', '', 5, 1),
(22, 3, '热水器', '', 6, 1),
(23, 3, '电饭煲', '', 7, 1),
(24, 3, '电吹风机', '', 8, 1),
(25, 4, '洗发水', '', 1, 1),
(26, 4, '牙膏', '', 2, 1),
(27, 4, '沐浴露', '', 3, 1),
(28, 4, '护肤霜', '', 4, 1),
(29, 4, '肥皂', '', 5, 1),
(30, 4, '口红', '', 6, 1),
(31, 4, '洗手液', '', 7, 1),
(32, 4, '面膜', '', 8, 1),
(33, 5, '矿泉水', '#009900', 1, 1),
(34, 5, '汽水果汁', '', 2, 1),
(35, 5, '奶品', '', 3, 1),
(36, 5, '食用油', '', 4, 1),
(37, 5, '烟酒', '', 5, 1),
(38, 5, '方便面', '', 6, 1),
(39, 5, '干果', '', 7, 1),
(40, 5, '水果', '', 8, 1),
(41, 6, '沙发', '', 1, 1),
(42, 6, '棹子', '', 2, 1),
(43, 6, '纸品', '', 3, 1),
(44, 6, '毛巾', '', 4, 1),
(45, 6, '书包', '', 5, 1),
(46, 6, '旅行箱', '', 6, 1),
(47, 6, '钱包', '', 7, 1),
(48, 6, '皮带', '', 8, 1),
(49, 7, '推车', '', 1, 1),
(50, 7, '纸尿裤', '', 2, 1),
(51, 7, '婴儿床', '', 3, 1),
(52, 7, '奶瓶', '', 4, 1),
(53, 7, '孕妇装', '', 5, 1),
(54, 7, '吸奶器', '', 6, 1),
(55, 7, '奶嘴', '', 7, 1),
(56, 7, '婴儿床', '', 8, 1),
(57, 8, '山地车', '', 1, 1),
(58, 8, '望远镜', '', 2, 1),
(59, 8, '球类', '', 3, 1),
(60, 8, '跑步机', '', 4, 1),
(61, 8, '摩托车', '', 5, 1),
(62, 8, '坐躺椅床', '', 6, 1),
(63, 8, '运动服', '', 7, 1),
(64, 8, '休闲车', '', 8, 1),
(65, 9, '虚拟商品', '#FF6600', 1, 1),
(66, 9, '服装', '', 2, 1),
(67, 9, '鞋子', '', 3, 1),
(68, 9, '汽车', '', 4, 1),
(69, 9, '书籍', '', 5, 1),
(70, 9, '乐器', '', 6, 1),
(71, 9, '黄金珠宝', '', 7, 1),
(72, 9, '安全套', '', 8, 1);
EOF;
$sql=str_replace("pre_it618_crowd_class2",DB::table('it618_crowd_class2'),$sql);
DB::query($sql);
	
$sql = <<<EOF
INSERT INTO `pre_it618_crowd_style` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#ff971b', '#e46703', 0),
(2, '#DD2525', '#B52020', 1),
(3, '#48b518', '#289a00', 0),
(4, '#2c7ccd', '#0c59ad', 0),
(5, '#f50bc1', '#c5099b', 0),
(6, '#09aeb0', '#089395', 0),
(8, '#ff4400', '#e03e03', 0),
(7, '#888c8e', '#6f7071', 0);
EOF;
$sql=str_replace("pre_it618_crowd_style",DB::table('it618_crowd_style'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_crowd_wapstyle` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#fd9e2d', '#e8922b', 0),
(2, '#fc4646', '#f43131', 1),
(3, '#5ebe00', '#56aa04', 0),
(4, '#099fde', '#098fc8', 0),
(5, '#fb23cb', '#ea11ba', 0),
(6, '#2dbeae', '#00a795', 0),
(8, '#fe5400', '#d04906', 0),
(7, '#999a9b', '#8d8f90', 0);
EOF;
$sql=str_replace("pre_it618_crowd_wapstyle",DB::table('it618_crowd_wapstyle'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_crowd_iconav` (`id`, `it618_title`, `it618_img`, `it618_url`, `it618_target`, `it618_color`, `it618_isbold`, `it618_order`) VALUES
(1, '食品饮料', 'source/plugin/it618_crowd/wap/images/1.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=5', 0, '', 0, 4),
(2, '其他商品', 'source/plugin/it618_crowd/wap/images/2.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=8', 0, '', 0, 8),
(3, '化妆个护', 'source/plugin/it618_crowd/wap/images/3.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=4', 0, '', 0, 6),
(4, '手机数码', 'source/plugin/it618_crowd/wap/images/4.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=1', 0, '', 0, 1),
(5, '家用电器', 'source/plugin/it618_crowd/wap/images/5.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=3', 0, '', 0, 3),
(6, '运动户外', 'source/plugin/it618_crowd/wap/images/6.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=8', 0, '', 0, 7),
(7, '电脑办公', 'source/plugin/it618_crowd/wap/images/7.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=2', 0, '', 0, 2),
(8, '母婴用品', 'source/plugin/it618_crowd/wap/images/8.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=7', 0, '', 0, 5);
EOF;
$sql=str_replace("pre_it618_crowd_iconav",DB::table('it618_crowd_iconav'),$sql);
DB::query($sql);
}
//From: Dism_taobao_com
?>