<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/crowd_default.func.php';

$pid=intval($_GET['pid']);
if($it618_crowd['crowd_wap']==1){
	if(crowd_is_mobile()){ 
		$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$pid,'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$pid);
		dheader("location:$tmpurl");
	}
}

$homeurl=it618_crowd_getrewrite('crowd_home','','plugin.php?id=it618_crowd:index');
if(!($it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id_state($pid,1))){
	echo it618_crowd_getlang('s470').' <a href="'.$homeurl.'">'.$it618_crowd_lang['s18'].'</a>';exit;
}

foreach(C::t('#it618_crowd#it618_crowd_focus')->fetch_all_by_type_order(6) as $it618_crowd_focus) {
	if($it618_crowd_focus['it618_url']!=''){
		$str_focus6.='<li><a href="'.$it618_crowd_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus6.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

$class1=$it618_crowd_goods['it618_class1_id'];
$class2=$it618_crowd_goods['it618_class2_id'];

$class1name=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($class1);
$tmpurl=it618_crowd_getrewrite('crowd_list',$class1.'@0','plugin.php?id=it618_crowd:list&class1='.$class1);
$productnav.='<a href="'.$tmpurl.'">'.$class1name.'</a><i></i>';

$class2name=C::t('#it618_crowd#it618_crowd_class2')->fetch_it618_name_by_id($class2);
$tmpurl=it618_crowd_getrewrite('crowd_list',$class1.'@'.$class2,'plugin.php?id=it618_crowd:list&class1='.$class1.'&class2='.$class2);
$productnav.='<a href="'.$tmpurl.'">'.$class2name.'</a><i></i>';


C::t('#it618_crowd#it618_crowd_goods')->update_it618_views_by_id($pid);
$salecount = C::t('#it618_crowd#it618_crowd_sale')->count_by_it618_pid($pid);
if($it618_crowd_goods['it618_salecount']!=$salecount){
	C::t('#it618_crowd#it618_crowd_goods')->update_it618_salecount_by_id($pid,$salecount);
}

for($i=0;$i<=4;$i++){
	if($i==0){$tmpi='';$tmpcss=' class="firstimg curimg"';}else {$tmpi=$i;$tmpcss='';}
	$it618_picbig=$it618_crowd_goods['it618_picbig'.$tmpi];
	if($it618_picbig!=''){
		$goodspicbig.='<li'.$tmpcss.'><img width="48" height="48" border="0" src="'.it618_crowd_getgoodspic($it618_crowd_goods['id'],$it618_picbig,$i).'" rel="'.$it618_picbig.'" ></li>';
	}
}

$goodspic=it618_crowd_getgoodspic($it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig'],0);

if($it618_crowd_goods['it618_ptype']==2){
	$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_crowd_goods_km')." WHERE it618_pid=".$pid);
	if($it618_crowd_goods['it618_count']!=$kmcount)DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_count=$kmcount WHERE id=$pid");
}

$query = DB::query("SELECT *,it618_pricecount_find/it618_pricecount_sale as jiexiao FROM ".DB::table('it618_crowd_goods')." where it618_state=1 and id<>".$it618_crowd_goods['id']." ORDER BY jiexiao limit 0,".$it618_crowd['crowd_pagesalecount']);
while($it618_jiexiao = DB::fetch($query)) {
	
	$jfidstr=$_G['setting']['extcredits'][$it618_jiexiao['it618_jfid']]['title'];
	
	if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_jiexiao['id'])){
		$pricecount=$it618_crowd_sale['it618_pricecount'];
		$pricecount1=$pricecount-$it618_jiexiao['it618_pricecount_find'];
		$pricecount2=$it618_jiexiao['it618_pricecount_find'];
		$pricecountbl=$pricecount1/$pricecount*100;
		$price=$it618_crowd_sale['it618_price'];
	}else{
		$pricecount=$it618_jiexiao['it618_pricecount'];
		$pricecount1=0;
		$pricecount2=$pricecount;
		$pricecountbl=$pricecount1/$pricecount*100;
		$price=$it618_jiexiao['it618_price'];
		
		if($pricecount!=$it618_jiexiao['it618_pricecount_find']){
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_jiexiao['id']);
		}
	}
	
	if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;
	
	if($price!=$it618_jiexiao['it618_price_sale']||$pricecount!=$it618_jiexiao['it618_pricecount_sale']){
		DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_jiexiao['id']);
	}
	
	$it618_name='('.$it618_crowd_lang['s21'].($it618_jiexiao['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_jiexiao['it618_name'];
	
	$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_jiexiao['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_jiexiao['id']);
	$jiexiao.='<div class="small-goods"><a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload" src="'.it618_crowd_getwapppic('wapgoodspic',$it618_jiexiao['id'],$it618_jiexiao['it618_picbig']).'" alt="'.$it618_name.'"/></a><h4><a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_name.'">'.$it618_name.'</a></h4>
			<div class="small-goods-info">
				<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_jiexiao['it618_count'].'
				<div class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></div>
				<table class="graphtable"><tr>
				<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
				<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
				<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
				</tr></table>
			</div>
			</div>';
}

$query = DB::query("SELECT s.it618_uid as buyuid,s.it618_count as buycount,s.it618_price as buyprice,s.it618_pid as buypid,g.it618_jfid as buyjfid,g.it618_name as buypname,g.it618_unit as buypunit,s.it618_time as buytime FROM ".DB::table('it618_crowd_crowdsale')." s left join ".DB::table('it618_crowd_goods')." g on s.it618_pid=g.id and g.it618_state=1 where g.it618_class1_id=".$class1." ORDER BY s.id desc limit 0,".$it618_crowd['crowd_activecount']);
while($it618_active = DB::fetch($query)) {
	
	$jfidstr=$_G['setting']['extcredits'][$it618_active['buyjfid']]['title'];
	
	$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_active['buypid'],'plugin.php?id=it618_crowd:product&pid='.$it618_active['buypid']);
	$active.='<li><span><a href="'.it618_crowd_rewriteurl($it618_active['buyuid']).'" target="_blank"><img src="'.it618_crowd_discuz_uc_avatar($it618_active['buyuid'],'small').'"></a></span><p>'.it618_crowd_getusername($it618_active['buyuid']).' '.it618_crowd_gettime($it618_active['buytime']).' '.it618_crowd_getlang('s680').'<font color=red>'.$it618_active['buycount'].'</font>'.$it618_active['buypunit'].'<font color=red>'.$it618_active['buyprice'].'</font><font color=green>'.$jfidstr.'</font>'.it618_crowd_getlang('s681').'<a href="'.$tmpurl.'" title="'.$it618_active['buypname'].'" target="_blank">'.$it618_active['buypname'].'</a></p></li>';
}

$pjcount=C::t('#it618_crowd#it618_crowd_sale')->countpj_by_pid($it618_crowd_goods['id']);
if($pjcount>0){
	$pjname=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_pj_by_id($it618_crowd_goods['it618_class1_id']);
	$pjname=explode("_",$pjname);
	
	$pjscore=C::t('#it618_crowd#it618_crowd_sale')->fetch_sumpjscore_by_pid($it618_crowd_goods['id']);
	$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);
	$pjavgscore2=sprintf( "%.1f",$pjscore['score2']/$pjcount);
	$pjavgscore3=sprintf( "%.1f",$pjscore['score3']/$pjcount);
	$pjavgscore4=sprintf( "%.1f",$pjscore['score4']/$pjcount);
	$pjpl1=sprintf( "%.1f",$pjavgscore1/5*100);
	$pjpl2=sprintf( "%.1f",$pjavgscore2/5*100);
	$pjpl3=sprintf( "%.1f",$pjavgscore3/5*100);
	$pjpl4=sprintf( "%.1f",$pjavgscore4/5*100);
	
	$pj1_count1=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],1);
	$pj1_count2=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],2);
	$pj1_count3=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],3);
	$pj1_count4=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],4);
	$pj1_count5=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],5);
	
	$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
	
	$pj1_pl1=intval($pj1_count1/$pjcount*100);
	$pj1_pl2=intval($pj1_count2/$pjcount*100);
	$pj1_pl3=intval($pj1_count3/$pjcount*100);
	$pj1_pl4=intval($pj1_count4/$pjcount*100);
	$pj1_pl5=intval($pj1_count5/$pjcount*100);
	
	$it618_pjpfstr=$pjcount.' '.it618_crowd_getlang('s482').' '.$pjavgscore1.' '.it618_crowd_getlang('s483').':'.$mydpl.'% ';
}else{
	$it618_pjpfstr=it618_crowd_getlang('s484').' ';	
}

DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pjpfstr='".$it618_pjpfstr."' WHERE id=$pid");

$it618_crowd_goods['it618_message']=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="910" height="552" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_crowd_goods['it618_message']);

$crowdid=$salecount+1;

$it618_pname='('.$it618_crowd_lang['s21'].$crowdid.$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
$pjfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
$price_sale=$it618_crowd_goods['it618_price_sale']*$it618_crowd_goods['it618_pricecount_sale'];

$crowdsalecount=0;
if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
	$pricecount=$it618_crowd_sale['it618_pricecount'];
	$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
	$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
	$pricecountbl=$pricecount1/$pricecount*100;
	$price=$it618_crowd_sale['it618_price'];
	$saleid=$it618_crowd_sale['id'];
}else{
	$pricecount=$it618_crowd_goods['it618_pricecount'];
	$pricecount1=0;
	$pricecount2=$pricecount;
	$pricecountbl=$pricecount1/$pricecount*100;
	$price=$it618_crowd_goods['it618_price'];
	$saleid=0;
	
	if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
		DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
	}
}

if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;

if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
	DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
}

$creditnum=0;
if($_G['uid']>0){
	$creditnum=DB::result_first("select extcredits".$it618_crowd_goods['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php';
	if($it618_jfbl[$it618_crowd_goods['it618_jfid']]<=0){
		$jfbl=1;
	}else{
		$jfbl=$it618_jfbl[$it618_crowd_goods['it618_jfid']];
	}
}else{
	$jfbl=1;
}

if($_GET['saleid']>0){
	$get_saleid=$_GET['saleid'];
	$get_crowdid=C::t('#it618_crowd#it618_crowd_sale')->fetch_crowdid_by_id($_GET['saleid']);
}

$metatitle=$it618_pname.' - '.$metatitle;
$metakeywords=$it618_crowd_goods['it618_seokeywords'];
$metadescription=$it618_crowd_goods['it618_seodescription'];

$url_this=$_G['siteurl'].it618_crowd_getrewrite('crowd_wap','product@'.$pid,'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$pid);
$qrcodesrc=crowd_qrcode($url_this);

$pagetype='product';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:crowd_default');
?>