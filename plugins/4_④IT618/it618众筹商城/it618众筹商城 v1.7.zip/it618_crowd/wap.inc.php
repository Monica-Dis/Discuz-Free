<?php
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
$metakeywords = $it618_crowd['seokeywords'];
$metadescription = $it618_crowd['seodescription'];
$sitetitle=$it618_crowd['seotitle'];

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

if(!crowd_is_mobile()){
	$ispc=1;
}

$waphome=it618_crowd_getrewrite('crowd_wap','','plugin.php?id=it618_crowd:wap');
$wapsearch=it618_crowd_getrewrite('crowd_wap','search','plugin.php?id=it618_crowd:wap&pagetype=search');
$wapsale=it618_crowd_getrewrite('crowd_wap','sale','plugin.php?id=it618_crowd:wap&pagetype=sale');

$topmiddle='1';
$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_crowd#it618_crowd_wapstyle')->count_by_isok_search();
$it618_crowd_wapstyle=C::t('#it618_crowd#it618_crowd_wapstyle')->fetch_by_isok_search();

if(isset($_GET['pagetype'])){
	$pagetypearray = array('crowd', 'product', 'mycrowdsale', 'mysale', 'admincrowdsale', 'adminsale', 'uc', 'search', 'sale', 'gwcsale');
	$pagetype = !in_array($_GET['pagetype'], $pagetypearray) ? 'crowd' : $_GET['pagetype'];
	
	if(count($tmparr)>1){
		$topleft='<a class="react back" href="javascript:history.back()"><i class="text-icon icon-back"></i></a>';
	}else{
		$topleft='<a class="react back" href="'.$waphome.'"><i class="text-icon icon-back"></i></a>';
	}
}else{
	$pagetype='crowd';
	$topleft='<a href="'.$waphome.'" class="react crowd"><span style="font-size:18px">'.$sitetitle.'</span></a>';
	$topmiddle='';
	$navtitle=$sitetitle;
}

if($it618_crowd['crowd_style']>2){
	$crowdstyle=getcookie('crowdstyle');
	if($crowdstyle==''){
		if($it618_crowd['crowd_style']==3)$crowdstyle='1';else $crowdstyle='2';
	}

	if($pagetype=='crowd'||$pagetype=='search'){
		if($crowdstyle=='1')$crowdstyle1='2';else $crowdstyle1='1';
		$crowdstylestrtmp='<div class="style-btn" onClick="crowdstyle()"><i class="icon-style'.$crowdstyle1.'"></i></div>';
	}
}else{
	if($it618_crowd['crowd_style']==1)$crowdstyle='1';else $crowdstyle='2';
}

$gwcpcount=0;
$gwcurl=it618_crowd_getrewrite('crowd_wap','gwcsale@'.$_G['uid'],'plugin.php?id=it618_crowd:wap&pagetype=gwcsale');
if($_G['uid']>0){
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_crowd_getlang('s460').'</a></li>';
	$strusr='<a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="btn btn-weak">'.it618_crowd_getlang('s460').'</a> <a href="'.it618_crowd_rewriteurl($_G['uid']).'" target="_blank">'.it618_crowd_getusername($_G['uid']).'</a>';
	
	if($IsCredits==1){
		if($_G['cache']['plugin']['it618_credits']['rewriteurl']==0){
			$tmpcredits='<li><a class="react" href="plugin.php?id=it618_credits:wap">'.it618_crowd_getlang('s960').'</a></li>';
			$tmpcreditsurl='plugin.php?id=it618_credits:wap';
		}else{
			$tmpcredits='<li><a class="react" href="credits_wap.html">'.it618_crowd_getlang('s960').'</a></li>';
			$tmpcreditsurl='credits_wap.html';
		}
	}
	
	$gwcpcount=C::t('#it618_crowd#it618_crowd_gwc')->count_by_uid($_G['uid']);
	
	$ucurl1=it618_crowd_getrewrite('crowd_wap','mycrowdsale@'.$_G['uid'],'plugin.php?id=it618_crowd:wap&pagetype=mycrowdsale');
	$ucurl2=it618_crowd_getrewrite('crowd_wap','mysale@'.$_G['uid'],'plugin.php?id=it618_crowd:wap&pagetype=mysale');
	$uc='<li><a class="react" href="'.$ucurl1.'">'.it618_crowd_getlang('s455').'</a></li><li><a class="react" href="'.$ucurl2.'">'.it618_crowd_getlang('s457').'</a></li>';
	
	$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
	if(in_array($_G['uid'],$crowd_adminuids)){
		$scurl1=it618_crowd_getrewrite('crowd_wap','admincrowdsale@'.$_G['uid'],'plugin.php?id=it618_crowd:wap&pagetype=admincrowdsale');
		$scurl2=it618_crowd_getrewrite('crowd_wap','adminsale@'.$_G['uid'],'plugin.php?id=it618_crowd:wap&pagetype=adminsale');
		$sc='<li><a class="react" href="'.$scurl1.'">'.it618_crowd_getlang('s30').'</a></li><li><a class="react" href="'.$scurl2.'">'.it618_crowd_getlang('s40').'</a></li>';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/kefu.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/kefu.php';
	
	if($it618_qq!=''){
		$qqarr=explode(",",$it618_qq);
		$wxarr=explode(",",$it618_wx);
		$qqnamearr=explode(",",$it618_title);
		for($i=0;$i<count($qqarr);$i++)
		{
			if($qqarr[$i]!='')$shopqq.='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:'.$qqarr[$i].':52" align="absmiddle"/>'.$qqnamearr[$i].'</a> ';
			
			$rightqq.='<h3>'.$qqnamearr[$i].'</h3>
			<ul>
				<li><span>'.$it618_crowd_lang['s645'].'</span>
				<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:'.$qqarr[$i].':51" align="absmiddle"/></a> <span>'.$it618_crowd_lang['s646'].'</span>'.$wxarr[$i].'
				</li>
			</ul>';
			
		}
	}
}

$wap=1;
if(isset($_GET['app']))$appstr='&app';

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')==false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_crowd['crowd_appid']);
	$wx_secret=trim($it618_crowd['crowd_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){
	if($pagetype=='product'){
		$pid=intval($_GET['cid']);
		$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($pid);
		$wxshare_title=$it618_crowd_goods['it618_name'];
		$wxshare_imgUrl=it618_crowd_getgoodspic($it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig'],0);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_crowd_goods['it618_seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
		
	}else{
		$wxshare_title=$it618_crowd['seotitle'];
		
		if($it618_crowd['crowd_wxlogo']!=''){
			$wxshare_imgUrl=$it618_crowd['crowd_wxlogo'];
		}else{
			$wxshare_imgUrl=$it618_crowd['crowd_logo'];
			$tmparr=explode('src="',$wxshare_imgUrl);
			$tmparr1=explode('"',$tmparr[1]);
			$wxshare_imgUrl=$tmparr1[0];
		}
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_crowd['seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_crowd_getrewrite('tuan_wap','','plugin.php?id=it618_crowd:wap');
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
	}
}

require DISCUZ_ROOT.'./source/plugin/it618_crowd/wap/'.$pagetype.'.inc.php';
?>