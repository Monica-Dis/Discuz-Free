<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid']);
$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);

$pname=$it618_crowd_goods['it618_name'].' '.$it618_crowd_goods['it618_mealname'];

$it618_crowd_sale["it618_content"]=str_replace("[br]","\n",$it618_crowd_sale["it618_content"]);
$it618_crowd_sale["it618_hfcontent"]=str_replace("[br]","\n",$it618_crowd_sale["it618_hfcontent"]);

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:hfsalepj');
?>