<?php
ob_start();


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/crowd_function.func.php';

$uid = $_G['uid'];
$it618_pid=intval($_GET['it618_pid']);

$pagetype=$_GET['pagetype'];
$idforly=intval($_GET['idforly']);

if($_GET['ac']=="getmode"){
	$modeid=intval($_GET['modeid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/getmode.func.php';
	
	if($it618_crowd_diy=C::t('#it618_crowd#it618_crowd_diy')->fetch_by_id($modeid)){
		if($it618_crowd_diy['it618_isjs']==1){
			if((time()-$it618_crowd_diy["it618_time"])<(60*$it618_crowd_diy["it618_catchtime"])){
				return;
			}else{
				C::t('#it618_crowd#it618_crowd_diy')->update_it618_time_by_id(time(),$it618_crowd_diy["id"]);
			}
			
			$tmpstr = it618_crowd_getmodecontent($it618_crowd_diy['it618_type'],$it618_crowd_diy['it618_modecode'],$it618_crowd_diy['it618_count']);
			$tmpstr=str_replace(array("\r\n", "\r", "\n"),"",$tmpstr);
			$tmpstr=str_replace("'",'"',$tmpstr);
			
			echo "document.write('".$tmpstr."')";
		}
	}

}

if($_GET['ac']=="home_goods"){
	$home_goods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname($_GET['ac1']);
	
	$tmparr=explode(",",$home_goods);
	if($_GET['wap']!=1){
		if(count($tmparr)>2){
			$goods_count=$tmparr[0];
		}else{
			$goods_count=15;
		}
	}else{
		if(count($tmparr)>2){
			$goods_count=$tmparr[1];
		}else{
			$goods_count=8;
		}
	}
	
	if($_GET['ac1']=='zjsalegoods'){	
		$query = DB::query("SELECT max(m.id) as maxid,m.it618_pid FROM ".DB::table('it618_crowd_crowdsale')." m left join ".DB::table('it618_crowd_goods')." g on m.it618_pid=g.id where g.it618_state=1 and m.it618_pid>0 GROUP BY m.it618_pid ORDER BY maxid desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='weeksalegoods'){
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate-24*7, $toyear);
		$query = DB::query("SELECT m.it618_pid,count(1) as salecount FROM ".DB::table('it618_crowd_sale')." m left join ".DB::table('it618_crowd_goods')." g on m.it618_pid=g.id where g.it618_state=1 and m.it618_pid>0 and m.it618_time>=$time GROUP BY m.it618_pid ORDER BY salecount desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='newgoods'){
		$query = DB::query("SELECT id as it618_pid FROM ".DB::table('it618_crowd_goods')." where it618_state=1 ORDER BY id desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='hotgoods'){
		$query = DB::query("SELECT id as it618_pid FROM ".DB::table('it618_crowd_goods')." where it618_state=1 ORDER BY it618_salecount desc limit 0,".$goods_count);
	}
	
	if($_GET['wap']!=1){
		$i=1;
		$home_goodstmp='';
		while($it618_homegoods = DB::fetch($query)) {
			$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_homegoods['it618_pid']);
		
			if($it618_crowd_goods['it618_state']==1){
				if($i%5==1){$home_goodstmp.='<li>';$noml=' noml';}else{$noml='';}
				
				$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
				
				if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
					$pricecount=$it618_crowd_sale['it618_pricecount'];
					$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
					$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
					$pricecountbl=$pricecount1/$pricecount*100;
					$price=$it618_crowd_sale['it618_price'];
				}else{
					$pricecount=$it618_crowd_goods['it618_pricecount'];
					$pricecount1=0;
					$pricecount2=$pricecount;
					$pricecountbl=$pricecount1/$pricecount*100;
					$price=$it618_crowd_goods['it618_price'];
					
					if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
						DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
					}
				}
				
				if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;
				
				if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
					DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
				}
				
				$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
				
				$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
				$home_goodstmp.='<div class="small-goods small-goods1'.$noml.'">
								<a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload" src="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" alt="'.$it618_name.'"/></a><h4><a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_name.'">'.$it618_name.'</a></h4>
								<div class="small-goods-info">
									<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
									<div class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></div>
									<table class="graphtable"><tr>
									<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
									<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
									<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
									</tr></table>
								</div>
								</div>';
				if($i%5==0)$home_goodstmp.='</li>';
				$i=$i+1;
			}
		}
		if(($i-1)%5>0)$home_goodstmp.='</li>';
		
		$home_goodstmp='<div id="'.$_GET['ac1'].'" class="slider-warp lazy_start" options="'.$_GET['ac1'].'|left|0|5000|1000|1|1|0|1">
							<div class="slider-ulwarp">
								<ul class="slider-ul">'.$home_goodstmp.'</ul>	
							</div>
						</div>';
	}else{
		if($it618_crowd['crowd_style']>2){
			$crowdstyle=getcookie('crowdstyle');
			if($crowdstyle==''){
				if($it618_crowd['crowd_style']==3)$crowdstyle='1';else $crowdstyle='2';
			}
		}else{
			if($it618_crowd['crowd_style']==1)$crowdstyle='1';else $crowdstyle='2';
		}
		$home_goodstmp='';$tdn=1;
		while($it618_homegoods = DB::fetch($query)) {
			$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
			$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
				
			if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
				$pricecount=$it618_crowd_sale['it618_pricecount'];
				$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
				$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
				$pricecountbl=$pricecount1/$pricecount*100;
				$price=$it618_crowd_sale['it618_price'];
			}else{
				$pricecount=$it618_crowd_goods['it618_pricecount'];
				$pricecount1=0;
				$pricecount2=$pricecount;
				$pricecountbl=$pricecount1/$pricecount*100;
				$price=$it618_crowd_goods['it618_price'];
				
				if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
					DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
				}
			}
			
			if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;
			
			if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
			}
			
			$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
	
			$pjcount=C::t('#it618_crowd#it618_crowd_sale')->countpj_by_pid($it618_crowd_goods['id']);
			if($pjcount>0){
				$pjscore=C::t('#it618_crowd#it618_crowd_sale')->fetch_sumpjscore_by_pid($it618_crowd_goods['id']);
				$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);
				
				$pj1_count4=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],4);
				$pj1_count5=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],5);
				
				$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
				
				$pj=$pjcount.' '.it618_crowd_getlang('s482').' '.$pjavgscore1.' '.it618_crowd_getlang('s483').':'.$mydpl.'% ';
			}else{
				$pj=it618_crowd_getlang('s484').' ';	
			}
			
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pjpfstr='".$pj."' WHERE id=".$it618_crowd_goods['id']);
			
			$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
			
			if($crowdstyle=='1'){
				$views=' '.it618_crowd_getlang('s118').''.$it618_crowd_goods['it618_views'];
			
				$home_goodstmp.='<tr>
								<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_name.'</div>
									<div class="tddes">'.$pj.' '.$views.'</div>
									<ul class="tdprice">
									  <li>
									    <span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
										<p class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></p>
										<table class="graphtable"><tr>
										<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
										<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
										<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
										</tr></table>
									  </li>
									</ul>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
			}else{
				if($tdn%2>0){
					$trtmpstr1='<tr class="trimg">';
					$trtmpstr2='<tr class="trabout">';
					$tdstr='class="tdleft"';
				}else{
					$tdstr='class="tdright"';
				}
				
				$trtmpstr1.='<td '.$tdstr.'><a href="'.$tmpurl.'">
								<img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"/>
							</a></td>';
				
				$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
								<div class="tdname">'.$it618_name.'</div>
								<div class="tddes">'.$pj.'</div>
								<div class="tdprice">
									<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
									<p class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></p>
									<table class="graphtable"><tr>
									<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
									<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
									<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
									</tr></table>
								</div>
							</a></td>';
							
				if($tdn%2==0){
					$trtmpstr1.='</tr>';
					$trtmpstr2.='</tr>';
					$home_goodstmp.=$trtmpstr1.$trtmpstr2;
				}
				
				$tdn=$tdn+1;
			}
		}
		
		if($crowdstyle=='1'){
			$tmparr=explode('</tr>',$home_goodstmp);
			if(count($tmparr)>1){
				$home_goodstmp=$home_goodstmp.'@@@';
				$home_goodstmp=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$home_goodstmp);
			}
		}else{
			$trtmpstr=$trtmpstr1.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr);
			if(count($tmparr)>1){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$home_goodstmp.=$trtmpstr1.$trtmpstr2;
			}
		}
	}
	
	echo $home_goodstmp;
}

if($_GET['formhash']!=FORMHASH)return;

if($_GET['ac']=="imgdelete"){
	if($uid<=0){
		echo '0';
	}else{
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
		if(!in_array($_G['uid'],$crowd_adminuids)){
			echo '0';return;
		}
		
		$tmparr=explode('source/plugin/it618_crowd/kindeditor/attached/image/',$_GET['imgurl']);
		if(count($tmparr)>1){
			$tmppath=str_replace("..","",$tmparr[1]);
			$tmparr1=explode("/",$tmppath);
			if(count($tmparr1)!=2){
				echo '0';return;
			}
			
			$delpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/attached/image/'.$tmparr1[0].'/'.$tmparr1[1];
		}
			
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		if (file_exists($delpath)) {
			$result=unlink($delpath);
			if(it618_crowd_dirsize(dirname($delpath))==0){
				rmdir(dirname($delpath));
			}
			
			echo '1';
		}else{
			echo '0';
		}
	}
}

function setkm($saleid){
	$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($saleid);
	$query1 = DB::query("select * from ".DB::table('it618_crowd_goods_km')." WHERE it618_pid=".$it618_crowd_sale['it618_pid']." limit 0,1");
	while($it618_crowd_goods_km = DB::fetch($query1)) {
		$id = C::t('#it618_crowd#it618_crowd_goods_salekm')->insert(array(
			'it618_saleid' => $saleid,
			'it618_code' => $it618_crowd_goods_km['it618_code']
		), true);
		if($id>0)DB::query("delete from ".DB::table('it618_crowd_goods_km')." where id=".$it618_crowd_goods_km['id']);
	}
}

function delsalework(){
	DB::query("delete from ".DB::table('it618_crowd_salework'));
}

if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo it618_crowd_getlang('s485');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_crowd_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				delsalework();
			}
		}
		C::t('#it618_crowd#it618_crowd_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		usleep(mt_rand(0,1000000));
		
		$pid=intval($_GET['pid']);
		$it618_count=intval($_GET['it618_count']);
		
		if($it618_count<=0){
			echo it618_crowd_getlang('s486');delsalework();return;
		}
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if(!($it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id_state($pid,1))){
			echo it618_crowd_getlang('s487');delsalework();return;
		}
		
		if($it618_crowd_goods['it618_ptype']==2){
			$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_crowd_goods_km')." WHERE it618_pid=".$pid);
			if($kmcount!=$it618_crowd_goods['it618_count'])DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_count=$kmcount WHERE id=$pid");
			$goods_count=$kmcount;
		}else{
			$goods_count=$it618_crowd_goods['it618_count'];
		}
		
		if($goods_count<=0){
			echo it618_crowd_getlang('s864');delsalework();return;
		}

		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if($ii1i11i[9]!='w')return;
		
		if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($pid)){
			$saleid=$it618_crowd_sale['id'];
			
			$it618_price=$it618_crowd_sale['it618_price'];
			$it618_pricecount=$it618_crowd_sale['it618_pricecount'];
		}else{
			$saleid = C::t('#it618_crowd#it618_crowd_sale')->insert(array(
				'it618_pid' => $pid,
				'it618_saletype' => $it618_crowd_goods['it618_ptype'],
				'it618_jfid' => $it618_crowd_goods['it618_jfid'],
				'it618_price' => $it618_crowd_goods['it618_price'],
				'it618_pricecount' => $it618_crowd_goods['it618_pricecount']
			), true);
			
			$salecount=C::t('#it618_crowd#it618_crowd_sale')->count_by_pid_saleid($it618_crowd_goods['id'],$saleid);
			C::t('#it618_crowd#it618_crowd_sale')->update($saleid,array(
				'it618_crowdid' => $salecount
			));

			$it618_price=$it618_crowd_goods['it618_price'];
			$it618_pricecount=$it618_crowd_goods['it618_pricecount'];
			
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$it618_price.",it618_pricecount_sale=".$it618_pricecount.",it618_pricecount_find=".$it618_pricecount." where id=".$it618_crowd_goods['id']);
		}
		
		$crowdsalecount=C::t('#it618_crowd#it618_crowd_crowdsale')->sumcount_by_saleid($saleid);
		if($it618_count>$it618_pricecount-$crowdsalecount){
			$it618_count=$it618_pricecount-$crowdsalecount;
		}
		
		$it618_jfcount=$it618_price*$it618_count;
		
		$jfname=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
		
		$creditnum=DB::result_first("select extcredits".$it618_crowd_goods['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$uid);
		if($creditnum<$it618_jfcount){
			$tmpstr=$it618_crowd_lang['s91'];
			$tmpstr=str_replace("{count}",$it618_count,$tmpstr);
			$tmpstr=str_replace("{jfcount}",$it618_jfcount,$tmpstr);
			$tmpstr=str_replace("{jfname}",$jfname,$tmpstr);
			$tmpstr=str_replace("{creditnum}",$creditnum,$tmpstr);
			
			echo 'saleit618_split'.$tmpstr;delsalework();return;
		}
		
		$tmptime=$_G['timestamp'];
		$it618_time=$tmptime.'.'.getmsec('Y-m-d H:i:s.u');
		
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php';
			if($it618_jfbl[$it618_crowd_goods['it618_jfid']]<=0){
				$jfbl=1;
			}else{
				$jfbl=$it618_jfbl[$it618_crowd_goods['it618_jfid']];
			}
		}else{
			$jfbl=1;
		}
	
		$id = C::t('#it618_crowd#it618_crowd_crowdsale')->insert(array(
			'it618_saleid' => $saleid,
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_jfid' => $it618_crowd_goods['it618_jfid'],
			'it618_jfbl' => $jfbl,
			'it618_price' => $it618_price,
			'it618_count' => $it618_count,
			'it618_tel' => it618_crowd_utftogbk($_GET["it618_tel"]),
			'it618_state' => 0,
			'it618_time' => $it618_time
		), true);
		
		if($id>0){
			C::t('common_member_count')->increase($uid, array(
				'extcredits'.$it618_crowd_goods['it618_jfid'] => (0-$it618_jfcount))
			);
			
			if($it618_crowd['crowd_jfuid']>0){
				C::t('common_member_count')->increase($it618_crowd['crowd_jfuid'], array(
					'extcredits'.$it618_crowd_goods['it618_jfid'] => $it618_jfcount)
				);
			}
		
			$groupsum=intval($it618_price*$it618_count*$jfbl);
			$groupcount=C::t('#it618_crowd#it618_crowd_crowdsale_group')->count_by_uid($uid);
			
			if($groupcount==0){
				C::t('#it618_crowd#it618_crowd_crowdsale_group')->insert(array(
					'it618_uid' => $uid,
					'it618_groupsum' => $groupsum
				), true);
			}else{
				DB::query("UPDATE ".DB::table('it618_crowd_crowdsale_group')." SET it618_groupsum=it618_groupsum+".$groupsum." where it618_uid=".$uid);
			}
			
			C::t('#it618_crowd#it618_crowd_crowdsale_grouplog')->insert(array(
				'it618_uid' => $uid,
				'it618_group' => $groupsum,
				'it618_time' => $it618_time
			), true);
			
			$it618_codes=getrandcode($saleid,$it618_pricecount,$it618_count);
			C::t('#it618_crowd#it618_crowd_crowdsale')->update($id,array(
				'it618_codes' => $it618_codes
			));
			
			$crowdsalecount=C::t('#it618_crowd#it618_crowd_crowdsale')->sumcount_by_saleid($saleid);
			
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".($it618_pricecount-$crowdsalecount)." where id=".$it618_crowd_goods['id']);
			
			if($crowdsalecount>=$it618_pricecount){
				$it618_code=getsalecode($tmptime,$it618_pricecount);
				
				$it618_crowd_crowdsale=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_by_saleid_code($saleid,$it618_code);
				
				C::t('#it618_crowd#it618_crowd_crowdsale')->update($it618_crowd_crowdsale['id'],array(
					'it618_state' => 1
				));
				
				$it618_crowd_crowdsale=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_by_saleid_uid($saleid,$it618_crowd_crowdsale['it618_uid']);
				
				if($it618_crowd_goods['it618_ptype']==1){
					$it618_state=1;
				}else{
					$it618_state=3;
					setkm($saleid);
				}
				
				C::t('#it618_crowd#it618_crowd_sale')->update($saleid,array(
					'it618_uid' => $it618_crowd_crowdsale['it618_uid'],
					'it618_crowtel' => $it618_crowd_crowdsale['it618_tel'],
					'it618_code' => $it618_code,
					'it618_state' => $it618_state,
					'it618_time' => $tmptime
				));
				
				$salecount = C::t('#it618_crowd#it618_crowd_sale')->count_by_it618_pid($it618_crowd_goods['id']);

				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_count=it618_count-1,it618_salecount=".$salecount.",it618_price_sale=".$it618_crowd_goods['it618_price'].",it618_pricecount_sale=".$it618_crowd_goods['it618_pricecount']." where id=".$it618_crowd_goods['id']);
				
				it618_crowd_sendmessage('sale_user',$saleid);
				it618_crowd_sendmessage('sale_admin',$saleid);
			}
				
			echo "ok";delsalework();
		}else{
			echo it618_crowd_getlang('s498');delsalework();return;
		}

	}
}

function getmsec($format = 'u', $utimestamp = null) {
   if (is_null($utimestamp))
	   $utimestamp = microtime(true);

   $timestamp = floor($utimestamp);
   $milliseconds = round(($utimestamp - $timestamp) * 1000000);

   $tmptime = date(preg_replace('`(?<!\\\\)u`', $milliseconds, $format), $timestamp);
   $tmparr=explode(".",$tmptime);
   
   return substr($tmparr[1],0,3);
}

function getsalecode($tmptime,$pricecount){
	$timesum=0;
	foreach(C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_all_by_time($tmptime,0,100) as $it618_crowd_crowdsale) {
		$it618_time=it618_crowd_getudate($it618_crowd_crowdsale['it618_time']);
		
		$tmparr=explode(" ",$it618_time);
		$tmptime=str_replace(":","",$tmparr[1]);
		$tmptime=str_replace(".","",$tmptime);
		$timesum=$timesum+$tmptime;
	}
	
	$it618_code=$timesum%$pricecount+10000001;
	
	return $it618_code;
}

function getrandcode($saleid,$pricecount,$n){
	$arrcode = array();
	
	for($i=1;$i<=$pricecount;$i++){
		$arrcode[]=10000000+$i;
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_crowdsale')." WHERE it618_codes!=''AND it618_saleid=".$saleid);
	while($it618_crowd_crowdsale = DB::fetch($query)) {
		$tmpstr=$it618_crowd_crowdsale['it618_codes'];
		$tmparr=explode(",",$tmpstr);
		
		for($i=0;$i<count($tmparr);$i++){
			array_splice($arrcode,array_search($tmparr[$i],$arrcode),1);
		}
	}
	
	for($i=1;$i<=$n;$i++){
		$tmpi=mt_rand(0,(count($arrcode)-1));
		$randcode.=$arrcode[$tmpi].',';
		array_splice($arrcode,$tmpi,1);
	}
	
	$randcode.='@';
	
	$randcode=str_replace(",@","",$randcode);
	
	return $randcode;
}

if($_GET['ac']=="gwcpay_add"){
	if($uid<=0){
		echo it618_crowd_getlang('s484');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_crowd_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				delsalework();
			}
		}
		C::t('#it618_crowd#it618_crowd_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		
		usleep(mt_rand(0,1000000));
		
		$crowd_gwcpcount=$it618_crowd['crowd_gwcpcount'];
		
		$count=C::t('#it618_crowd#it618_crowd_gwc')->count_by_uid($uid);
		if($count==0){
			echo it618_crowd_getlang('s1081');delsalework();return;
		}else if($count>$crowd_gwcpcount){
			echo str_replace("gwcpcount",$crowd_gwcpcount,it618_crowd_getlang('s1082'));delsalework();return;
		}
		
		foreach(C::t('#it618_crowd#it618_crowd_gwc')->fetch_all_by_uid($uid) as $it618_crowd_gwc) {
			
			if(!($it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id_state($it618_crowd_gwc['it618_pid'],1))){
				echo 'gidit618_split'.$it618_crowd_gwc['id'].'it618_split'.it618_crowd_getlang('s1090');delsalework();return;
			}
			
			if($it618_crowd_goods['it618_ptype']==2){
				$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_crowd_goods_km')." WHERE it618_pid=".$it618_crowd_gwc['it618_pid']);
				if($kmcount!=$it618_crowd_goods['it618_count'])DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_count=$kmcount WHERE id=".$it618_crowd_gwc['it618_pid']);
				$goods_count=$kmcount;
			}else{
				$goods_count=$it618_crowd_goods['it618_count'];
			}
			
			if($goods_count<=0){
				echo 'gidit618_split'.$it618_crowd_gwc['id'].'it618_split'.it618_crowd_getlang('s1096');delsalework();return;
			}
			
			$it618_count=intval($it618_crowd_gwc['it618_count']);
			
			if($it618_count<=0){
				echo 'gidit618_split'.$it618_crowd_gwc['id'].'it618_split'.it618_crowd_getlang('s486');delsalework();return;
			}
			
		}
		
		$tmptime=$_G['timestamp'];
		$it618_time=$tmptime.'.'.getmsec('Y-m-d H:i:s.u');
		foreach(C::t('#it618_crowd#it618_crowd_gwc')->fetch_all_by_uid($uid) as $it618_crowd_gwc) {
			
			if(!($it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id_state($it618_crowd_gwc['it618_pid'],1))){
				echo 'gidit618_split'.$it618_crowd_gwc['id'].'it618_split'.it618_crowd_getlang('s1090');delsalework();return;
			}

			$pid=$it618_crowd_goods['id'];
			$it618_count=intval($it618_crowd_gwc['it618_count']);
			
			if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($pid)){
				$saleid=$it618_crowd_sale['id'];
				
				$it618_price=$it618_crowd_sale['it618_price'];
				$it618_pricecount=$it618_crowd_sale['it618_pricecount'];
			}else{
				$saleid = C::t('#it618_crowd#it618_crowd_sale')->insert(array(
					'it618_pid' => $pid,
					'it618_saletype' => $it618_crowd_goods['it618_ptype'],
					'it618_jfid' => $it618_crowd_goods['it618_jfid'],
					'it618_price' => $it618_crowd_goods['it618_price'],
					'it618_pricecount' => $it618_crowd_goods['it618_pricecount']
				), true);
				
				$salecount=C::t('#it618_crowd#it618_crowd_sale')->count_by_pid_saleid($it618_crowd_goods['id'],$saleid);
				C::t('#it618_crowd#it618_crowd_sale')->update($saleid,array(
					'it618_crowdid' => $salecount
				));
	
				$it618_price=$it618_crowd_goods['it618_price'];
				$it618_pricecount=$it618_crowd_goods['it618_pricecount'];
				
				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$it618_price.",it618_pricecount_sale=".$it618_pricecount.",it618_pricecount_find=".$it618_pricecount." where id=".$it618_crowd_goods['id']);
			}
			
			$crowdsalecount=C::t('#it618_crowd#it618_crowd_crowdsale')->sumcount_by_saleid($saleid);
			if($it618_count>$it618_pricecount-$crowdsalecount){
				$it618_count=$it618_pricecount-$crowdsalecount;
			}
			
			$it618_jfcount=$it618_price*$it618_count;
			
			$jfname=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
			
			$creditnum=DB::result_first("select extcredits".$it618_crowd_goods['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$uid);
			if($creditnum1<$it618_jfcount){
				$tmpstr=$it618_crowd_lang['s91'];
				$tmpstr=str_replace("{count}",$it618_count,$tmpstr);
				$tmpstr=str_replace("{jfcount}",$it618_jfcount,$tmpstr);
				$tmpstr=str_replace("{jfname}",$jfname,$tmpstr);
				$tmpstr=str_replace("{creditnum}",$creditnum,$tmpstr);
				
				echo 'gidsaleit618_split'.$it618_crowd_gwc['id'].'it618_split'.$tmpstr;delsalework();return;
			}
			
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php')){
				require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php';
				if($it618_jfbl[$it618_crowd_goods['it618_jfid']]<=0){
					$jfbl=1;
				}else{
					$jfbl=$it618_jfbl[$it618_crowd_goods['it618_jfid']];
				}
			}else{
				$jfbl=1;
			}
			
			$id = C::t('#it618_crowd#it618_crowd_crowdsale')->insert(array(
				'it618_saleid' => $saleid,
				'it618_uid' => $uid,
				'it618_pid' => $pid,
				'it618_jfid' => $it618_crowd_goods['it618_jfid'],
				'it618_jfbl' => $jfbl,
				'it618_price' => $it618_price,
				'it618_count' => $it618_count,
				'it618_tel' => it618_crowd_utftogbk($_GET["it618_tel"]),
				'it618_state' => 0,
				'it618_time' => $it618_time
			), true);
			
			if($id>0){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$it618_crowd_goods['it618_jfid'] => (0-$it618_jfcount))
				);
				
				if($it618_crowd['crowd_jfuid']>0){
					C::t('common_member_count')->increase($it618_crowd['crowd_jfuid'], array(
						'extcredits'.$it618_crowd_goods['it618_jfid'] => $it618_jfcount)
					);
				}
		
				$groupsum=intval($it618_price*$it618_count*$jfbl);
				$groupcount=C::t('#it618_crowd#it618_crowd_crowdsale_group')->count_by_uid($uid);
				if($groupcount==0){
					C::t('#it618_crowd#it618_crowd_crowdsale_group')->insert(array(
						'it618_uid' => $uid,
						'it618_groupsum' => $groupsum
					), true);
				}else{
					DB::query("UPDATE ".DB::table('it618_crowd_crowdsale_group')." SET it618_groupsum=it618_groupsum+".$groupsum." where it618_uid=".$uid);
				}
				
				C::t('#it618_crowd#it618_crowd_crowdsale_grouplog')->insert(array(
					'it618_uid' => $uid,
					'it618_group' => $groupsum,
					'it618_time' => $it618_time
				), true);
				
				$it618_codes=getrandcode($saleid,$it618_pricecount,$it618_count);
				C::t('#it618_crowd#it618_crowd_crowdsale')->update($id,array(
					'it618_codes' => $it618_codes
				));
				
				$crowdsalecount=C::t('#it618_crowd#it618_crowd_crowdsale')->sumcount_by_saleid($saleid);
				
				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".($it618_pricecount-$crowdsalecount)." where id=".$it618_crowd_goods['id']);
				
				C::t('#it618_crowd#it618_crowd_gwc')->delete_by_id($it618_crowd_gwc['id']);
				
				if($crowdsalecount>=$it618_pricecount){
					$it618_code=getsalecode($tmptime,$it618_pricecount);
					
					$it618_crowd_crowdsale=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_by_saleid_code($saleid,$it618_code);
					
					C::t('#it618_crowd#it618_crowd_crowdsale')->update($it618_crowd_crowdsale['id'],array(
						'it618_state' => 1
					));
					
					$it618_crowd_crowdsale=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_by_saleid_uid($saleid,$it618_crowd_crowdsale['it618_uid']);
					
					if($it618_crowd_goods['it618_ptype']==1){
						$it618_state=1;
					}else{
						$it618_state=3;
						setkm($saleid);
					}
					
					C::t('#it618_crowd#it618_crowd_sale')->update($saleid,array(
						'it618_uid' => $it618_crowd_crowdsale['it618_uid'],
						'it618_crowtel' => $it618_crowd_crowdsale['it618_tel'],
						'it618_code' => $it618_code,
						'it618_state' => $it618_state,
						'it618_time' => $tmptime
					));
					
					$salecount = C::t('#it618_crowd#it618_crowd_sale')->count_by_it618_pid($it618_crowd_goods['id']);
	
					DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_count=it618_count-1,it618_salecount=".$salecount." where id=".$it618_crowd_goods['id']);
					
					it618_crowd_sendmessage('sale_user',$saleid);
					it618_crowd_sendmessage('sale_admin',$saleid);
				}
			}

		}

		echo "ok";delsalework();

	}
}

if($_GET['ac']=="getgwc"){
	if($uid>0){
		$count=C::t('#it618_crowd#it618_crowd_gwc')->count_by_uid_pid($uid,$_GET['pid']);
		if($count>0){
			echo '2';
		}else{
			C::t('#it618_crowd#it618_crowd_gwc')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $_GET['pid']
			), true);
			
			$count=C::t('#it618_crowd#it618_crowd_gwc')->count_by_uid($uid);
			echo '1it618_split<span>'.$count.'</span>';
		}
	}else{
		echo $it618_crowd_lang['s485'];
	}
}

if($_GET['ac']=="gwclist_get"){
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	
	$count=C::t('#it618_crowd#it618_crowd_gwc')->count_by_uid($uid);
	$funname='getgwclist';
	
	$allsummoney=0;$isaddr=0;
	foreach(C::t('#it618_crowd#it618_crowd_gwc')->fetch_all_by_uid($uid) as $it618_crowd_gwc) {
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
		
		$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_gwc['it618_pid']);
		
		$disabled='';
		$onclickstr='onclick="gwcminus('.$it618_crowd_gwc['id'].')"';
		if($it618_crowd_gwc['it618_count']==1){
			$disabled='disabled';
			$onclickstr='';
		}
		
		if($it618_crowd_goods['it618_ptype']==1)$isaddr=1;
		
		$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
		
		if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
			$pricecount=$it618_crowd_sale['it618_pricecount'];
			$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
			$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_sale['it618_price'];
		}else{
			$pricecount=$it618_crowd_goods['it618_pricecount'];
			$pricecount1=0;
			$pricecount2=$pricecount;
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_goods['it618_price'];
			
			if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
			}
		}
		
		if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;
		
		if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
		}
		
		$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];

		if($_GET['ac1']=='pcgwc'){
			$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);

			$goodslist.='<div id="gwcpid'.$it618_crowd_gwc['id'].'" class="cart-list cl">
							<div class="product">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" width="60" height="60"/></a>
							<div class="product-info">
							<p><a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_name.'">'.$it618_name.'</a></p>
							<p><div class="graphdiv graphdivgwc" style="width:260px;margin-bottom:6px;margin-top:10px"><span class="orange" style="width:'.$pricecountbl.'%;"></span></div></p>
							<p>'.$it618_crowd_lang['s26'].''.$pricecount1.' '.$it618_crowd_lang['s27'].''.$pricecount.' '.$it618_crowd_lang['s28'].''.$pricecount2.'</p>
							</div>
							</div>
							<div class="quantity">
							<div class="quantity-number">
							<div style="float:left;padding-bottom:8px;width:260px;text-align:left">'.$it618_crowd_lang['t130'].'<span style="color:#F60;">'.$it618_crowd_goods['it618_price_sale'].'</span> <font color="#390">'.$jfidstr.'</font></div><br>
							<span class="minus '.$disabled.'" '.$onclickstr.'><i class="minus-icon"></i></span>
							<input type="text" value="'.$it618_crowd_gwc['it618_count'].'" readonly="readonly" />
							<span class="plus" onclick="gwcplus('.$it618_crowd_gwc['id'].')"><i class="plus-icon"></i></span>
							<div class="pricediv">
							 <a href="javascript:" onclick="gwcsetcount('.$it618_crowd_gwc['id'].',10)">10</a>
							 <a href="javascript:" onclick="gwcsetcount('.$it618_crowd_gwc['id'].',50)">50</a>
							 <a href="javascript:" onclick="gwcsetcount('.$it618_crowd_gwc['id'].',100)">100</a>
							 <a href="javascript:" onclick="gwcsetcount('.$it618_crowd_gwc['id'].',200)">200</a>
							 </div>
							</div>
							</div><div class="price">
							<em class="sig_pri"><b>'.($it618_crowd_goods['it618_price_sale']*$it618_crowd_gwc['it618_count']).'</b></em> <span style="color:#999;font-size:12px">'.$jfidstr.'</span>
							</div>
							<div class="operate">
							<p><a href="javascript:" onclick="delgwc('.$it618_crowd_gwc['id'].')">'.$it618_crowd_lang['s884'].'</a></p>
							</div>
						</div>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			
			$goodslist.='<tr id="gwcpid'.$it618_crowd_gwc['id'].'" class="cart-list cl"><td><table width="100%">
							<tr class="gwclisttr1"><td width="69" style="padding-left:3px">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" width="65" height="65"/></a>
							</td><td colspan="3">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_name.'">'.$it618_name.'</a>
							<p><div class="graphdiv graphdivgwc" style="width:200px;margin-bottom:6px;margin-top:6px"><span class="orange" style="width:'.$pricecountbl.'%;"></span></div></p>
							<p style="color:#999;font-size:12px"><span style="float:right;color:red;margin-right:2px">'.($it618_crowd_goods['it618_price_sale']*$it618_crowd_gwc['it618_count']).'<font color="#999">'.$jfidstr.'</font></span>'.$it618_crowd_lang['s26'].''.$pricecount1.' '.$it618_crowd_lang['s27'].''.$pricecount.' '.$it618_crowd_lang['s28'].''.$pricecount2.'</p>
							</td></tr>
							<tr class="gwclisttr2"><td style="padding-left:3px"><span style="color:#F60;">'.$it618_crowd_goods['it618_price_sale'].'</span> <font color="#390">'.$jfidstr.'</font>
							</td><td>
							<div class="quantity-number">
							<span class="minus '.$disabled.'" '.$onclickstr.'><i class="minus-icon"></i></span>
							<input type="text" value="'.$it618_crowd_gwc['it618_count'].'" readonly="readonly" />
							<span class="plus" onclick="gwcplus('.$it618_crowd_gwc['id'].')"><i class="plus-icon"></i></span>
							<div class="pricediv" style="margin-top:3px">
							 <a href="javascript:" onclick="gwcsetcount('.$it618_crowd_gwc['id'].',10)">10</a>
							 <a href="javascript:" onclick="gwcsetcount('.$it618_crowd_gwc['id'].',50)">50</a>
							 <a href="javascript:" onclick="gwcsetcount('.$it618_crowd_gwc['id'].',100)">100</a>
							 <a href="javascript:" onclick="gwcsetcount('.$it618_crowd_gwc['id'].',200)">200</a>
							 </div>
							</div>
							</td><td align="center">
							<b><font color="#FF9900">'.$summoney.'</font></b>
							</td><td align="center">
							<a href="javascript:" onclick="delgwc('.$it618_crowd_gwc['id'].')">'.$it618_crowd_lang['s884'].'</a></td></tr>
						</table></td></tr>';
			
		}

	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_crowd/message.php';
		
		if($it618_isok==1){
			if($it618_body_sale_user_isok==1){
				$tmp=' <font color=#999>'.$it618_crowd_lang['t29'].'</font>';
			}
		}
	}
	
	$tel=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_tel_by_uid($_G['uid']);
	if($_GET['ac1']=='pcgwc'){
		$tmpstr=$it618_crowd_lang['t196'].'<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:130px;height:26px;border:#e8e8e8 1px solid;color:green;padding-left:3px;font-weight:bold" value="'.$tel.'" /> '.$it618_crowd_lang['t28'].$tmp;
		
		$addrstr='<div class="buy-block-title"><h3>'.$it618_crowd_lang['t149'].'</h3></div><div style="padding:10px;padding-right:0;line-height:35px"><div style="line-height:20px;color:#999;margin-bottom:10px">'.$it618_crowd_lang['t134'].'</div>'.$tmpstr.'</div>';
	}
	
	if($_GET['ac1']=='wapgwc'){
		$tmpstr='<tr><td style="padding:3px;padding-bottom:10px">
				'.$it618_crowd_lang['t196'].'<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:130px;height:23px;border:#e8e8e8 1px solid;color:green;padding-left:3px;font-weight:bold;" value="'.$tel.'" /> '.$it618_crowd_lang['t28'].$tmp.'
				</td></tr>';
		
		$addrstr='<tr><td><table width="100%">
				<tr class="gwctrtitle">
				<th style="padding-left:3px">'.$it618_crowd_lang['t149'].'</th>
				</tr>
				</table></td></tr>
				<tr><td style="line-height:20px;color:#999;padding:3px;font-size:11px">
				'.$it618_crowd_lang['t134'].'
				</td></tr>
				'.$tmpstr;
	}
	
	if($_GET['ac1']=='pcgwc'){
		echo $goodslist.'<div class="total-price"><a href="javascript:" onclick="cleargwc()" style="line-height:32px">'.$it618_crowd_lang['t753'].'</a> <span>'.$it618_crowd_lang['s1074'].'</span><span style="float:left"></span></div>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr;
	}else{
		echo $goodslist.'<tr><td align="right" style="padding:6px;padding-top:10px;padding-right:10px"><a href="javascript:" onclick="cleargwc()">'.$it618_crowd_lang['t753'].'</a></td></tr><tr><td align="right" style="padding:6px;padding-right:10px;padding-bottom:0;line-height:15px;color:#999"></td></tr>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr;
	}
}

if($_GET['ac']=="gwcminus"){
	if($uid>0){
		C::t('#it618_crowd#it618_crowd_gwc')->update_count1_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_crowd_lang['s485'];
	}
}

if($_GET['ac']=="gwcplus"){
	if($uid>0){
		C::t('#it618_crowd#it618_crowd_gwc')->update_count2_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_crowd_lang['s485'];
	}
}

if($_GET['ac']=="gwcsetcount"){
	if($uid>0){
		C::t('#it618_crowd#it618_crowd_gwc')->update_count_by_id_uid($_GET['gid'],$uid,$_GET['count']);
		echo 'ok';
	}else{
		echo $it618_crowd_lang['s485'];
	}
}

if($_GET['ac']=="delgwc"){
	if($uid>0){
		C::t('#it618_crowd#it618_crowd_gwc')->delete_by_id_uid($_GET['gid'],$uid);
		echo 'okit618_split'.$it618_crowd_lang['s78'];
	}else{
		echo $it618_crowd_lang['s485'];
	}
}

if($_GET['ac']=="cleargwc"){
	if($uid>0){
		C::t('#it618_crowd#it618_crowd_gwc')->delete_by_uid($uid);
		echo 'okit618_split'.$it618_crowd_lang['s79'];
	}else{
		echo $it618_crowd_lang['s485'];
	}
}

if($_GET['ac']=="goodscrowdsalelist_get"){
	if($_GET['wap']==0)$ppp = $it618_crowd['crowd_pagelistcount'];
	if($_GET['wap']==1)$ppp = $it618_crowd['crowd_waplistcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	foreach(C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_all_by_saleid(
		$_GET['saleid'],$startlimit,$ppp
	) as $it618_crowd_crowdsale) {
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
	
		$username=it618_crowd_getusername($it618_crowd_crowdsale['it618_uid']);
		
		$salestr='';
		if($it618_crowd_goods['it618_isbm']==1){
			if($_G['uid']!=$it618_crowd_sale['it618_uid'])$buyuser=cutstr($username, 2, '').'***';
			if($it618_crowd_crowdsale['it618_state']==1){
				$buyuser='<font color=red>'.$buyuser.'</font>';
			}
		}else{
			if($it618_crowd_crowdsale['it618_state']==1){
				$username='<font color=red>'.$username.'</font>';
			}
			$buyuser='<a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale['it618_uid']).'" target="_blank">'.$username.'</a>';	
		}
		
		if($it618_crowd_crowdsale['it618_state']==1){
			$it618_crowd_sale = C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($it618_crowd_crowdsale['it618_saleid']);
			$salestr='<br><font color=#390>'.$it618_crowd_sale['it618_code'].'</font> <a href="javascript:" onclick="setsalecal('.$it618_crowd_sale['id'].')">'.$it618_crowd_lang['s145'].'</a>';
		}
		
		if($jfname==''){
			$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_crowdsale['it618_pid']);
			$jfname=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
		}

		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		$groupsum=intval($it618_crowd_crowdsale['it618_price']*$it618_crowd_crowdsale['it618_count']*$it618_crowd_crowdsale['it618_jfbl']);
		if($_GET['wap']==0){
			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						<td><font color="red">'.$it618_crowd_crowdsale['it618_count'].'</font> <a href="javascript:" onclick="setsalecodes('.$it618_crowd_crowdsale['id'].')">'.$it618_crowd_lang['t232'].'</a>'.$salestr.'</td>
						<td><font color="red">'.($it618_crowd_crowdsale['it618_price']*$it618_crowd_crowdsale['it618_count']).'</font> '.$jfname.'</td>
						<td><font color="green">+ '.$groupsum.'</font></td>
						<td><font color=#999>'.it618_crowd_getudate($it618_crowd_crowdsale['it618_time']).'</font></td>
						</tr>';
		}else{
			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						<td align="center"><font color="red">'.$it618_crowd_crowdsale['it618_count'].'</font> <a href="javascript:" onclick="setsalecodes('.$it618_crowd_crowdsale['id'].')">'.$it618_crowd_lang['t232'].'</a>'.$salestr.'</td>
						<td align="center"><font color=#999>'.it618_crowd_getudate($it618_crowd_crowdsale['it618_time']).'</font></td>
						</tr>';
		}
	}
	
	$saleid=intval($_GET['saleid']);
	$count = C::t('#it618_crowd#it618_crowd_crowdsale')->count_by_saleid($saleid);
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_crowd:ajax&saleid=".$saleid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getcrowdsalelist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getcrowdsalelist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getcrowdsalelist(',$multipage);
		$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
		
		if($multipage!='')$multipage='<div class="pjpage">'.$multipage.'</div>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&saleid=".$saleid.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getcrowdsalelist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&saleid=".$saleid.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getcrowdsalelist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_crowd_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&saleid=".$saleid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getcrowdsalelist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&saleid=".$saleid.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getcrowdsalelist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&saleid=".$saleid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getcrowdsalelist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext.' '.it618_crowd_getlang('s229').$count;
		}

	}
	
	echo $salelist_get."it618_split".$multipage;
}

if($_GET['ac']=="goodssalelist_get"){
	if($_GET['wap']==0)$ppp = $it618_crowd['crowd_pagelistcount'];
	if($_GET['wap']==1)$ppp = $it618_crowd['crowd_waplistcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	foreach(C::t('#it618_crowd#it618_crowd_sale')->fetch_all_by_it618_pid(
		$_GET['it618_pid'],$startlimit,$ppp
	) as $it618_crowd_sale) {
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
	
		$username=it618_crowd_getusername($it618_crowd_sale['it618_uid']);
		
		$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
		
		$buyuser='<a href="'.it618_crowd_rewriteurl($it618_crowd_sale['it618_uid']).'" target="_blank">'.$username.'</a>';
		
		if($it618_crowd_goods['it618_isbm']==1){
			if($_G['uid']!=$it618_crowd_sale['it618_uid'])$buyuser=cutstr($username, 2, '').'***';
		}
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		
		$it618_crowd_crowdsale = C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_by_saleid_state($it618_crowd_sale['id']);
		
		if($_GET['wap']==0){
			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						<td>'.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].' <a href="javascript:" onclick="crowdsalelist('.$it618_crowd_sale['id'].','.$it618_crowd_sale['it618_crowdid'].')">'.$it618_crowd_lang['s39'].'</a></td>
						<td align="center"><font color=#390>'.$it618_crowd_sale['it618_code'].'</font> <a href="javascript:" onclick="setsalecal('.$it618_crowd_sale['id'].')">'.$it618_crowd_lang['s145'].'</a></td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).'</font></td>
						</tr>';
		}else{
			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						<td align="center" style="line-height:14px">'.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].'<br><a href="javascript:" onclick="crowdsalelist('.$it618_crowd_sale['id'].','.$it618_crowd_sale['it618_crowdid'].')">'.$it618_crowd_lang['s83'].'</a></td>
						<td align="center" style="line-height:14px"><font color=#390>'.$it618_crowd_sale['it618_code'].'</font><br><a href="javascript:" onclick="setsalecal('.$it618_crowd_sale['id'].')">'.$it618_crowd_lang['s145'].'</a></td>
						<td align="center" width="80" style="line-height:14px"><font color=#999>'.date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).'</font></td>
						</tr>';
		}
	}
	
	$pid=intval($_GET['it618_pid']);
	$count = C::t('#it618_crowd#it618_crowd_sale')->count_by_it618_pid($pid);
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_crowd:ajax&it618_pid=".$pid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getsalelist(',$multipage);
		$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
		
		if($multipage!='')$multipage='<div class="pjpage">'.$multipage.'</div>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getsalelist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&sid=$ShopId&it618_pid=".$pid.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_crowd_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext.' '.it618_crowd_getlang('s229').$count;
		}

	}
	
	echo $salelist_get."it618_split".$multipage;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d.i"."sz"."z. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	return;
}
if($_GET['ac']=="salelist_get"){
	if($_GET['ac1']=='pcmysale')$ppp = 10;
	if($_GET['ac1']=='wapmysale')$ppp = $it618_crowd['crowd_wapmysalecount'];
	if($_GET['ac1']=='wapadminsale')$ppp = $it618_crowd['crowd_wapshopsalecount'];

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "and s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "and s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "and s.it618_state = 3";
	}
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	if($_GET['saletype']) {
		if($_GET['saletype']==1)$it618sql .= " and s.it618_saletype = 1";
		if($_GET['saletype']==2)$it618sql .= " and s.it618_saletype = 2";
	}
	
	if($_GET['ac1']=='pcmysale'){		
		$it618_crowd_sales=C::t('#it618_crowd#it618_crowd_sale')->fetch_all_by_search("s.it618_state!=0 ".$it618sql,'s.id desc',it618_crowd_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_crowd#it618_crowd_sale')->count_by_search("s.it618_state!=0 ".$it618sql,'',it618_crowd_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmysalelist';
	}
	
	if($_GET['ac1']=='wapmysale'){
		$it618_crowd_sales=C::t('#it618_crowd#it618_crowd_sale')->fetch_all_by_search("s.it618_state!=0 ".$it618sql,'s.id desc',it618_crowd_utftogbk($_GET['pname']),$uid, '', '',$startlimit,$ppp);
		$count=C::t('#it618_crowd#it618_crowd_sale')->count_by_search("s.it618_state!=0 ".$it618sql,'',it618_crowd_utftogbk($_GET['pname']),$uid);
		$funname='getmysalelist';
	}
	

	if($_GET['ac1']=='wapadminsale'){
		if($uid>0){
			$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
			if(in_array($_G['uid'],$crowd_adminuids)){
				$it618_crowd_sales=C::t('#it618_crowd#it618_crowd_sale')->fetch_all_by_search("s.it618_state!=0 ".$it618sql,'s.id desc',it618_crowd_utftogbk($_GET['pname']),$_GET['finduid'], '', '',$startlimit,$ppp);
				$count=C::t('#it618_crowd#it618_crowd_sale')->count_by_search("s.it618_state!=0 ".$it618sql,'',it618_crowd_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
				$funname='getmyshopsalelist';
			}else{
				echo '';return;
			}
		}else{
			echo '';return;
		}
		
		$tmp.='<option value="0">'.it618_crowd_getlang('s698').'</option>';
		foreach(C::t('#it618_crowd#it618_crowd_kd')->fetch_all_by_search() as $it618_crowd_kd) {
			$tmp.='<option value='.$it618_crowd_kd['id'].'>'.$it618_crowd_kd['it618_name'].'</option>';
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';
		
	}
	$n=0;
	foreach($it618_crowd_sales as $it618_crowd_sale) {
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;

		$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);

		if($it618_crowd_sale['it618_state']==1)$it618_state='<font color=red>'.it618_crowd_getlang('t15').'</font>';
		if($it618_crowd_sale['it618_state']==2)$it618_state='<font color=#f60>'.it618_crowd_getlang('t16').'</font>';
		if($it618_crowd_sale['it618_state']==3)$it618_state='<font color=green>'.it618_crowd_getlang('t17').'</font>';
		
		$addrstr=str_replace("'","\"",$it618_crowd_sale['it618_addr'].' '.$it618_crowd_sale['it618_tel'].' '.$it618_crowd_sale['it618_bz']);
		
		$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
		$jfname=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
		
		if($_GET['ac1']=='pcmysale'){
			$class1name = C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($it618_crowd_goods['it618_class1_id']);
			$class2name = C::t('#it618_crowd#it618_crowd_class2')->fetch_it618_name_by_id($it618_crowd_goods['it618_class2_id']);
			$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
			
			$it618_kddan='';$addrtmp='';
			if($it618_crowd_sale['it618_saletype']==1){
				$addrtmp='<a href="javascript:" onclick="alert(\''.$addrstr.'\')">'.it618_crowd_getlang('s863').'</a>';	
				if($it618_crowd_sale['it618_kddan']==''){
					if($it618_crowd_sale['it618_tel']==''){
						$tmpaddrbtn=$it618_crowd_lang['s870'];	
					}else{
						$tmpaddrbtn=$it618_crowd_lang['s858'];	
					}
					$addrtmp='<a href="javascript:" onclick="setsaleaddr('.$it618_crowd_sale[id].')"><font color=blue>'.$tmpaddrbtn.'</font></a>';	
				}
			}else{
				$it618_state.='<br><a href="javascript:" onclick="setsalekm('.$it618_crowd_sale['id'].')">'.it618_crowd_getlang('s865').'</a>';
			}
			
			if($it618_crowd_sale['it618_saletype']==1&&$it618_crowd_sale['it618_state']==2){
				if($it618_crowd_sale['it618_kddan']!=''){
					$it618_state.=' <a href="javascript:" onclick="shouhuo('.$it618_crowd_sale['id'].')">'.it618_crowd_getlang('s769').'</a>';
				}
			}
			
			if($it618_crowd_sale['it618_kddan']!=''){
				$it618_crowd_kd=C::t('#it618_crowd#it618_crowd_kd')->fetch_by_id($it618_crowd_sale['it618_kdid']);
				$it618_kddan='<br>'.it618_crowd_getlang('s775').'<span><a href="'.$it618_crowd_kd['it618_url'].'" target="_blank">'.$it618_crowd_kd['it618_name'].'</a> '.$it618_crowd_sale['it618_kddan'].'</span>';
			}
			
			$it618_state.=$it618_kddan;
			
			$pjname=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_pj_by_id($it618_crowd_goods['it618_class1_id']);
			$pjname=explode("_",$pjname);
			$pl='';
			if($it618_crowd_sale['it618_state']==3){
				if($it618_crowd_sale['it618_score1']==0){
					$pl='<a href="javascript:" onclick="setsalepj('.$it618_crowd_sale['id'].')">'.it618_crowd_getlang('s776').'</a>';
				}else{
					$pl='<span title="'.$pjname[0].''.$it618_crowd_sale['it618_score1'].it618_crowd_getlang('s501').' '.$pjname[1].''.$it618_crowd_sale['it618_score2'].it618_crowd_getlang('s501').' '.$pjname[2].''.$it618_crowd_sale['it618_score3'].it618_crowd_getlang('s501').' '.$pjname[3].''.$it618_crowd_sale['it618_score4'].it618_crowd_getlang('s501').' '.str_replace('[br]','',$it618_crowd_sale["it618_content"]).'"><font color="#FF6600"><strong>'.$it618_crowd_sale['it618_score1'].'</strong></font>'.it618_crowd_getlang('s501').' '.$it618_crowd_sale['it618_score2'].it618_crowd_getlang('s501').' '.$it618_crowd_sale['it618_score3'].it618_crowd_getlang('s501').' '.$it618_crowd_sale['it618_score4'].it618_crowd_getlang('s501').'</span>';
				}
			}

			$salelist_get.='<tr class="hover">
						<td>'.$it618_crowd_sale[id].'</td>
						<td><a href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_crowd_goods['it618_description'].'">'.$pname.'</a></td>
						<td>'.$it618_state.' '.$addrtmp.'</td>
						<td>'.$pl.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).'</font></td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysale'){
			$pl='';
			if($it618_crowd_sale['it618_state']==3){
				if($it618_crowd_sale['it618_score1']==0){
					$pl=it618_crowd_getlang('s502').'<a href="javascript:" onclick="setsalepj('.$it618_crowd_sale['id'].')"><font color=red>'.it618_crowd_getlang('s500').'</font></a>';
				}else{
					$pl=it618_crowd_getlang('s502').'<font color="#FF6600"><strong>'.$it618_crowd_sale['it618_score1'].'</strong></font>'.it618_crowd_getlang('s501').' '.$it618_crowd_sale['it618_score2'].it618_crowd_getlang('s501').' '.$it618_crowd_sale['it618_score3'].it618_crowd_getlang('s501').' '.$it618_crowd_sale['it618_score4'].it618_crowd_getlang('s501');
				}
			}
			
			$it618_statebtn='';$strtmp='';
			if($it618_crowd_sale['it618_saletype']==1&&$it618_crowd_sale['it618_state']==2){
				if($it618_crowd_sale['it618_kddan']!=''){
					$it618_statebtn.=' <a href="javascript:" onclick="shouhuo('.$it618_crowd_sale['id'].')">'.it618_crowd_getlang('s769').'</a>';
					
				}
			}
					
			$it618_kddan='';
			if($it618_crowd_sale['it618_kddan']!=''){
				$it618_crowd_kd=C::t('#it618_crowd#it618_crowd_kd')->fetch_by_id($it618_crowd_sale['it618_kdid']);
				$it618_kddan=it618_crowd_getlang('s775').'<span title="'.$it618_crowd_sale['it618_bz'].'"><a href="'.$it618_crowd_kd['it618_url'].'" target="_blank">'.$it618_crowd_kd['it618_name'].'</a> '.$it618_crowd_sale['it618_kddan'].'</span>';
			}
			
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			if($it618_crowd_sale['it618_saletype']==1){
				$strtmp=$it618_kddan.' <a href="javascript:" onclick="alert(\''.$addrstr.'\')">'.it618_crowd_getlang('s863').'</a>';
				if($it618_crowd_sale['it618_kddan']==''){
					if($it618_crowd_sale['it618_tel']==''){
						$tmpaddrbtn=$it618_crowd_lang['s870'];	
					}else{
						$tmpaddrbtn=$it618_crowd_lang['s858'];	
					}
					
					$strtmp=$it618_kddan.' <a href="javascript:" onclick="setsaleaddr('.$it618_crowd_sale[id].')"><font color=blue>'.$tmpaddrbtn.'</font></a>';	
				}
			}else{
				$strtmp=' <a href="javascript:" onclick="setsalekm('.$it618_crowd_sale['id'].')">'.it618_crowd_getlang('s865').'</a>';
			}
			
			$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
			$salelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;font-size:13px;line-height:15px">
							<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" style="float:left;margin-right:3px" width="68" height="68"/></a>
							<div class="dealcard-crowd single-line" style="font-size:13px"><a href="'.$tmpurl.'" target="_blank">'.$pname.'</a></div>
							
							<div class="text-block" style="text-align:left">'.$strtmp.'</div>
							
							<div class="titlemysale text-block1">'.$it618_statebtn.$pl.'<br><div style="float:right">'.it618_crowd_getlang('s508').$it618_state.'</div><font color=#ccc>'.date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).'</font></div>

						</div>
					</dd>';
		}
		
		if($_GET['ac1']=='wapadminsale'){
			$username=it618_crowd_getusername($it618_crowd_sale['it618_uid']);
			$buyuser='<a href="'.it618_crowd_rewriteurl($it618_crowd_sale['it618_uid']).'" target="_blank">'.$username.'</a>';
			
			$pl='';
			if($it618_crowd_sale['it618_state']==3){
				if($it618_crowd_sale['it618_score1']>0){
					$pl=it618_crowd_getlang('s502').'<font color="#FF6600"><strong>'.$it618_crowd_sale['it618_score1'].'</strong></font>'.it618_crowd_getlang('s501').' '.$it618_crowd_sale['it618_score2'].it618_crowd_getlang('s501').' '.$it618_crowd_sale['it618_score3'].it618_crowd_getlang('s501').' '.$it618_crowd_sale['it618_score4'].it618_crowd_getlang('s501');
				}
			}
			
			$bz='';$strcontent='';
			if($it618_crowd_sale['it618_bz']!=""){
				$strcontent.='<strong>'.it618_crowd_getlang('s783').'</strong><br>'.$it618_crowd_sale['it618_bz'].'<br><br>';
			}
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			$it618_statebtn='';$bzbtn='';$kdbtn='1';$it618_kddan='';
			if($it618_crowd_sale['it618_saletype']==1){
				$it618_crowd_kd=C::t('#it618_crowd#it618_crowd_kd')->fetch_by_id($it618_crowd_sale['it618_kdid']);
				if($it618_crowd_sale['it618_kddan']!='')$it618_kddan='<br><span title="'.$it618_crowd_sale['it618_bz'].'" style="color:green">'.$it618_crowd_kd['it618_name'].' '.$it618_crowd_sale['it618_kddan'].'</span>';
				if($it618_crowd_sale['it618_state']==1){
					if($it618_crowd_sale['it618_tel']==''){
						$it618_statebtn.='<font color=blue>'.$it618_crowd_lang['s679'].'</font>';
					}else{
						if($it618_crowd_sale['it618_kddan']==''){
							$it618_statebtn.='<a href="javascript:" onclick="fahuo'.$it618_crowd_sale[id].'()">'.it618_crowd_getlang('s784').'</a>';
							$kdbtnname=it618_crowd_getlang('s785');
						}else{
							$kdbtnname=it618_crowd_getlang('s786');
							$it618_kddan.=' <a href="javascript:" onclick="fahuo'.$it618_crowd_sale[id].'()">'.$kdbtnname.'</a>';
						}
					}
				}else{
					$kdbtnname=it618_crowd_getlang('s787');
					$it618_kddan.=' <a href="javascript:" onclick="fahuo'.$it618_crowd_sale[id].'()">'.$kdbtnname.'</a>';
					$kdbtn='';
				}
				
				if($kdbtn!='')$kdbtn='<input type="button" class="it618btn" value="'.$kdbtnname.'" onclick="savekd()">';

				$tmp1=str_replace("<option value=".$it618_crowd_kd['id'],"<option value=".$it618_crowd_kd['id']." selected=selected",$tmp);
				
				$strcontent.='<div class="kd_fahuo">'.$it618_crowd_sale['it618_name'].' '.$it618_crowd_sale['it618_addr'].' '.$it618_crowd_sale['it618_tel'].'<br><br>'.$bz.it618_crowd_getlang('s699').'<select id="it618_kdid">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_crowd_sale['it618_kddan'].'"><input type="hidden" id="saleid" value="'.$it618_crowd_sale['id'].'"> '.$kdbtn.' <span style="color:red" id="kdtips"></span></div>';
			}
			
			if($it618_crowd_sale['it618_saletype']==1){
				$it618_salebz='';
				if($it618_crowd_sale['it618_salebz']!=''){
					$it618_salebz='(<font color="red">'.strlen($it618_crowd_sale['it618_salebz']).'</font>'.$it618_crowd_lang['s1782'].')';
				}
				$it618_statebtn.=' <a href="javascript:" onclick="setsalebz('.$it618_crowd_sale[id].')">'.$it618_crowd_lang['s1777'].$it618_salebz.'</a>';
			}
			
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			$strtel=it618_crowd_getlang('s701').$it618_crowd_sale['it618_crowtel'];
			
			$username=it618_crowd_getusername($it618_crowd_sale['it618_uid']);
			$buyuser='<a href="'.it618_crowd_rewriteurl($it618_crowd_sale['it618_uid']).'" target="_blank">'.$username.'</a>';
			
			$strtmp=$buyuser.' '.$strtel;
			
			$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
			$salelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;font-size:13px;line-height:15px">
							<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" style="float:left;margin-right:3px" width="68" height="68"/></a>
							<div class="dealcard-crowd single-line" style="font-size:13px"><a href="'.$tmpurl.'" target="_blank">'.$pname.'</a></div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;color:#999">'.it618_crowd_getlang('s221').':<font color="red">'.$it618_crowd_sale['it618_pricecount'].'</font> '.it618_crowd_getlang('s222').':<font color="red">'.($it618_crowd_sale['it618_price']*$it618_crowd_sale['it618_pricecount']).'</font>'.$jfname.'<br>'.$strtmp.$it618_kddan.'</div>
							
							<div class="titlemysale text-block1" style="line-height:15px">'.$it618_statebtn.'<br><div style="float:right">'.it618_crowd_getlang('s508').$it618_state.'</div>'.$pl.' <font color=#ccc>'.date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).'</font></div>

						</div>
					</dd>';
			if($it618_crowd_sale['it618_saletype']==1){
				$strcontent=str_replace("'","\"",$strcontent);
				$strcontent=str_replace(array("\r\n", "\r", "\n"),"<br>",$strcontent);
				$tmpjs.='function fahuo'.$it618_crowd_sale[id].'(){
							IT618_CROWD(\'.cd-popup\').addClass(\'is-visible\');
							IT618_CROWD(\'.popuptitle\').html(\''.it618_crowd_getlang('s866').'\');
							IT618_CROWD(\'.popupbody\').html(\'<table class="fahuo" width="98%"><tr><td>'.$strcontent.'</td></tr></table>\');
						}';
			}
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_crowd:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_crowd_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	if($_GET['ac1']=='wapadminsale'){
		echo it618_crowd_getlang('s229')."<font color=red>$count</font>"."it618_split".$salelist_get."it618_split".$multipage.'<script>'.$tmpjs.'</script>';;
	}else{
		echo it618_crowd_getlang('s229')."<font color=red>$count</font>"."it618_split".$salelist_get."it618_split".$multipage;
	}
}

if($_GET['ac']=="crowdsalelist_get"){
	if($_GET['ac1']=='pcmycrowdsale')$ppp = 10;
	if($_GET['ac1']=='wapmycrowdsale')$ppp = $it618_crowd['crowd_wapmysalecount'];
	if($_GET['ac1']=='wapadmincrowdsale')$ppp = $it618_crowd['crowd_wapadminsalecount'];

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	
	if($_GET['ac1']=='pcmycrowdsale'){		
		$it618_crowd_crowdsales=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_all_by_search($it618sql,'s.id desc',it618_crowd_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_crowd#it618_crowd_crowdsale')->count_by_search($it618sql,'',it618_crowd_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmycrowdsalelist';
	}
	
	if($_GET['ac1']=='wapmycrowdsale'){
		$it618_crowd_crowdsales=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_all_by_search($it618sql,'s.id desc',it618_crowd_utftogbk($_GET['pname']),$uid, '', '',$startlimit,$ppp);
		$count=C::t('#it618_crowd#it618_crowd_crowdsale')->count_by_search($it618sql,'',it618_crowd_utftogbk($_GET['pname']),$uid, '', '');
		$funname='getmycrowdsalelist';
	}
	
	if($_GET['ac1']=='wapadmincrowdsale'){
		$it618_crowd_crowdsales=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_all_by_search($it618sql,'s.id desc',it618_crowd_utftogbk($_GET['pname']),$_GET['finduid'], '', '',$startlimit,$ppp);
		$count=C::t('#it618_crowd#it618_crowd_crowdsale')->count_by_search($it618sql,'',it618_crowd_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
		$funname='getadmincrowdsalelist';
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';
		
	}
	$n=0;
	foreach($it618_crowd_crowdsales as $it618_crowd_crowdsale) {
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
		
		$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_crowdsale['it618_pid']);
		
		$groupsum=intval($it618_crowd_crowdsale['it618_price']*$it618_crowd_crowdsale['it618_count']*$it618_crowd_crowdsale['it618_jfbl']);
		
		if($jfname==''){
			$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_crowdsale['it618_pid']);
			$jfname=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
		}
		
		$salecount=C::t('#it618_crowd#it618_crowd_sale')->count_by_pid_saleid($it618_crowd_crowdsale['it618_pid'],$it618_crowd_crowdsale['it618_saleid']);
		$pname='('.$it618_crowd_lang['s21'].$salecount.$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
		
		if($it618_crowd_crowdsale['it618_state']==1){
			$pname='<font color=red>'.$pname.'</font>';
		}
		
		$it618_crowd_sale = C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($it618_crowd_crowdsale['it618_saleid']);
		if($it618_crowd_sale['it618_state']==0){
			$pricecount=$it618_crowd_sale['it618_pricecount'];
			$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
			$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
			$pricecountbl=intval($pricecount1/$pricecount*100);
			$tmppname='<font color=#999>'.$it618_crowd_lang['t20'].'</font><font color=#f60>'.$pricecountbl.'%</font>';
		}else{
			$tmppname='<font color=#999>'.$it618_crowd_lang['t22'].'</font>';
		}
		
		if($_GET['ac1']=='pcmycrowdsale'){
			$pname.=' '.$tmppname;
		}
		
		if($_GET['ac1']=='pcmycrowdsale'){
			$class1name = C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($it618_crowd_goods['it618_class1_id']);
			$class2name = C::t('#it618_crowd#it618_crowd_class2')->fetch_it618_name_by_id($it618_crowd_goods['it618_class2_id']);
			$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
			
			$salelist_get.='<tr class="hover">
						<td><a href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_crowd_goods['it618_description'].'">'.$pname.'</a></td>
						<td><font color="red">'.$it618_crowd_crowdsale['it618_count'].'</font> <a href="javascript:" onclick="setsalecodes('.$it618_crowd_crowdsale['id'].')">'.$it618_crowd_lang['t232'].'</a></td>
						<td>'.$it618_crowd_crowdsale['it618_price'].' '.$jfname.'</td>
						<td><font color="red">'.($it618_crowd_crowdsale['it618_price']*$it618_crowd_crowdsale['it618_count']).'</font> '.$jfname.'</td>
						<td><font color="green">+ '.$groupsum.'</font></td>
						<td><font color=#999>'.it618_crowd_getudate($it618_crowd_crowdsale['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmycrowdsale'){
			
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			
			$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
			$salelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;font-size:13px;line-height:15px">
							<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" style="float:left;margin-right:3px" width="68" height="68"/></a>
							<div class="dealcard-crowd single-line" style="font-size:13px;color:#999"><a href="'.$tmpurl.'" target="_blank">'.$pname.'</a><br>'.$it618_crowd_lang['s108'].$it618_crowd_crowdsale['it618_price'].' '.$jfname.' '.$it618_crowd_lang['s109'].($it618_crowd_crowdsale['it618_price']*$it618_crowd_crowdsale['it618_count']).' '.$jfname.' '.$it618_crowd_lang['s400'].'<font color="#390">+'.$groupsum.'</font></div>
							
							<div class="text-block" style="text-align:left;color:#999">'.$it618_crowd_lang['s221'].':<font color=red>'.$it618_crowd_crowdsale['it618_count'].'</font> <a href="javascript:" onclick="setsalecodes('.$it618_crowd_crowdsale['id'].')">'.$it618_crowd_lang['t232'].'</a><br><span style="float:right">'.$tmppname.'</span><font color=#ccc>'.it618_crowd_getudate($it618_crowd_crowdsale['it618_time']).'</font></div>

						</div>
					</dd>';
		}
		
		if($_GET['ac1']=='wapadmincrowdsale'){
			$username=it618_crowd_getusername($it618_crowd_crowdsale['it618_uid']);
			$buyuser='<a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale['it618_uid']).'" target="_blank">'.$username.'</a>';
			
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			
			$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
			$salelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;font-size:13px;line-height:15px">
							<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" style="float:left;margin-right:3px" width="68" height="68"/></a>
							<div class="dealcard-crowd single-line" style="font-size:13px;color:#999"><a href="'.$tmpurl.'" target="_blank">'.$pname.'</a><br>'.$it618_crowd_lang['s108'].$it618_crowd_crowdsale['it618_price'].' '.$jfname.' '.$it618_crowd_lang['s109'].($it618_crowd_crowdsale['it618_price']*$it618_crowd_crowdsale['it618_count']).' '.$jfname.' '.$it618_crowd_lang['s400'].'<font color="#390">+'.$groupsum.'</font></div>
							
							<div class="text-block" style="text-align:left;color:#999">'.$buyuser.' '.$it618_crowd_lang['s221'].':<font color=red>'.$it618_crowd_crowdsale['it618_count'].'</font> <a href="javascript:" onclick="setsalecodes('.$it618_crowd_crowdsale['id'].')">'.$it618_crowd_lang['t232'].'</a><br><span style="float:right">'.$tmppname.'</span><font color=#ccc>'.it618_crowd_getudate($it618_crowd_crowdsale['it618_time']).'</font></div>

						</div>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmycrowdsale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_crowd:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_crowd_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_crowd_getlang('t18')."<font color=red>$count</font>"."it618_split".$salelist_get."it618_split".$multipage;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d.i"."sz"."z. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	return;
}
if($_GET['ac']=="pj_get"){
	if($_GET['wap']!=1) $ppp = $it618_crowd['crowd_pagepjcount'];
	if($_GET['wap']==1) $ppp = $it618_crowd['crowd_wappjcount'];

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	$count=C::t('#it618_crowd#it618_crowd_sale')->countpj_by_pid($_GET['pid']);
	$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';
		
	}
	foreach(C::t('#it618_crowd#it618_crowd_sale')->fetch_allpj_by_it618_pid($_GET['pid'],$startlimit,$ppp) as $it618_crowd_sale) {
		if(in_array($_G['uid'], $crowd_adminuids)){
			$strtmpdel='<a href="javascript:" onclick="setsalepj(\''.$it618_crowd_sale['id'].'\')">'.it618_crowd_getlang('s351').'</a> <a href="javascript:" onclick="hfsalepj(\''.$it618_crowd_sale['id'].'\')">'.it618_crowd_getlang('s294').'</a>';
		}
		
		$it618_hfcontent='';
		if($it618_crowd_sale["it618_hfcontent"]!=''){
			$it618_hfcontent='<br>'.$it618_crowd_lang['t345'].'<font color="#FF3300">'.str_replace('[br]','<br>',$it618_crowd_sale["it618_hfcontent"]).'</font><br>';
		}
		
		$tmpstr='';
		foreach(C::t('#it618_crowd#it618_crowd_sale_pjpic')->fetch_all_by_saleid($it618_crowd_sale['id']) as $it618_crowd_sale_pjpic) {
			$file_ext=strtolower(substr($it618_crowd_sale_pjpic['it618_pjpic'],strrpos($it618_crowd_sale_pjpic['it618_pjpic'], '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl='source/plugin/it618_crowd/kindeditor/data/user/u'.$it618_crowd_sale['it618_uid'].'/smallimage/pjpic'.$it618_crowd_sale_pjpic['id'].'.'.$file_ext;
				
			$tmpstr.='<img src="'.$it618_smallurl.'" width="48" height="48" onclick="getbigpjpic('.$it618_crowd_sale['id'].',\''.$it618_crowd_sale_pjpic['it618_pjpic'].'\')"/>';
		}
		
		if($tmpstr!=''){
			$tmpstr='<ul class="pjpic"><li>'.$tmpstr.'</li><li class="bigpjpic" style="display:none" id="bigpjpic'.$it618_crowd_sale['id'].'"></li></ul>';
		}
		
		$pjpl1=sprintf( "%.1f",$it618_crowd_sale['it618_score1']/5*100);
		$pj_get.='<tr><td class="pjtr">
					  <table>
						  <tr><td><span class="pjuser">'.cutstr(it618_crowd_getusername($it618_crowd_sale['it618_uid']), 2, '').'***</span><p class="star12"><span style="width:'.$pjpl1.'%;"></span></p></td></tr>
						  <tr><td class="pjcontent">'.str_replace('[br]','<br>',$it618_crowd_sale["it618_content"]).$tmpstr.$it618_hfcontent.'</td></tr>
						  <tr><td class="pjtimetd"><span class="pjtime">'.date('Y-m-d H:i:s', $it618_crowd_sale['it618_pjtime']).'</span>'.$strtmpdel.'</td></tr>
					  </table>
				  </td></tr>';
	}
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_crowd:ajax".$urlsql);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getpjlist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getpjlist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getpjlist(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getpjlist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_crowd_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	if($multipage!=''){
		$pj_get.='<tr><td><div class="pjpage">'.$multipage.'</div></td></tr>';
	}
	
	echo $pj_get;
}

if($_GET['ac']=="getpjpic"){
	$n=0;
	$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid']);
	foreach(C::t('#it618_crowd#it618_crowd_sale_pjpic')->fetch_all_by_saleid($_GET['saleid']) as $it618_crowd_sale_pjpic) {
		$file_ext=strtolower(substr($it618_crowd_sale_pjpic['it618_pjpic'],strrpos($it618_crowd_sale_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl='source/plugin/it618_crowd/kindeditor/data/user/u'.$it618_crowd_sale['it618_uid'].'/smallimage/pjpic'.$it618_crowd_sale_pjpic['id'].'.'.$file_ext;
			
		$tmpstr.='<li><img src="'.$it618_smallurl.'"/><span onclick="delpjpic('.$_GET['saleid'].','.$it618_crowd_sale_pjpic['id'].')">'.$it618_crowd_lang['s884'].'</span></li>';
		$n=$n+1;
	}
	if($n>0){
		$tmpstr.='<li class="litxt">'.$n.'/5</li>';
	}else{
		$tmpstr.='<li class="litxt">'.$it618_crowd_lang['s1772'].'</li>';
	}
	
	echo $tmpstr.'<input type="hidden" id="pjpiccount" value="'.$n.'">';
}

if($_GET['ac']=="saleaddr"){
	
	if(!$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid'])){
		echo it618_crowd_getlang('s513');return;
	}
	
	if($uid!=$it618_crowd_sale['it618_uid']){
		echo it618_crowd_getlang('s513');return;
	}
	
	if(!($it618_crowd_sale['it618_state']==1&&$it618_crowd_sale['it618_kddan']=='')){
		echo it618_crowd_getlang('s513');return;
	}
	
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	C::t('#it618_crowd#it618_crowd_sale')->update($_GET['saleid'],array(
		'it618_name' => it618_crowd_utftogbk($_GET["it618_name"]),
		'it618_tel' => it618_crowd_utftogbk($_GET["it618_tel"]),
		'it618_addr' => it618_crowd_utftogbk($_GET["it618_addr"]),
		'it618_bz' => it618_crowd_utftogbk($_GET["it618_bz"])
	));
	
	echo 'okit618_split'.it618_crowd_getlang('t215');
}

if($_GET['ac']=="shouhuo"){
	if(!$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid'])){
		echo it618_crowd_getlang('s513');return;
	}
	
	if($uid!=$it618_crowd_sale['it618_uid']){
		echo it618_crowd_getlang('s513');return;
	}
	
	if($it618_crowd_sale['it618_state']!=2){
		echo it618_crowd_getlang('s513');return;
	}
	
	qrxf(intval($_GET['saleid']));
	
	echo 'okit618_split'.it618_crowd_getlang('s779');
}

function qrxf($saleid){
	C::t('#it618_crowd#it618_crowd_sale')->update_it618_state($saleid,3);
}

if($_GET['ac']=="salepj"){
	$tmparr=explode('@',$_GET['score']);
	$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid']);
	
	$flag=0;
	if($it618_crowd_sale['it618_score1']>0){
		$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
		if(!in_array($_G['uid'], $crowd_adminuids)){
			echo it618_crowd_getlang('s513');return;
		}
	}else{
		if($uid!=$it618_crowd_sale['it618_uid']||$it618_crowd_sale['it618_state']!=3||$it618_crowd_sale['it618_score1']>0){
			echo it618_crowd_getlang('s513');return;
		}
		$flag=1;
	}
	
	if($_GET['ac1']=="addpjpic"){
		$count=C::t('#it618_crowd#it618_crowd_sale_pjpic')->count_by_saleid($_GET['saleid']);
		if($count<5){
			$id=C::t('#it618_crowd#it618_crowd_sale_pjpic')->insert(array(
				'it618_saleid' => $_GET['saleid'],
				'it618_pjpic' => $_GET['picurl'],
				'it618_time' => $_G['timestamp']
			), true);
			
			it618_crowd_getpjpic($it618_crowd_sale['it618_uid'],$id,$_GET['picurl']);
		}
	}elseif($_GET['ac1']=="delpjpic"){
		$it618_crowd_sale_pjpic=C::t('#it618_crowd#it618_crowd_sale_pjpic')->fetch_by_id($_GET['pjpicid']);
		
		$it618_pjpic=$it618_crowd_sale_pjpic['it618_pjpic'];
		$tmparr=explode("source",$it618_pjpic);
		$it618_pjpic=DISCUZ_ROOT.'./source'.$tmparr[1];
		
		if(file_exists($it618_pjpic)){
			$result=unlink($it618_pjpic);
		}
		
		$file_ext=strtolower(substr($it618_crowd_sale_pjpic['it618_pjpic'],strrpos($it618_crowd_sale_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/user/u'.$it618_crowd_sale['it618_uid'].'/smallimage/pjpic'.$it618_crowd_sale_pjpic['id'].'.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		C::t('#it618_crowd#it618_crowd_sale_pjpic')->delete_by_id($_GET['pjpicid']);
	}else{
		C::t('#it618_crowd#it618_crowd_sale')->update($it618_crowd_sale['id'],array(
			'it618_score1' => $tmparr[0],
			'it618_score2' => $tmparr[1],
			'it618_score3' => $tmparr[2],
			'it618_score4' => $tmparr[3],
			'it618_content' => it618_crowd_utftogbk($_GET["pjvalue"])
		));
		
		if($flag==1){
			C::t('#it618_crowd#it618_crowd_sale')->update($it618_crowd_sale['id'],array(
				'it618_pjtime' => $_G['timestamp']
			));
			echo 'okit618_split'.it618_crowd_getlang('s516');
		}else{
			echo 'editokit618_split'.it618_crowd_getlang('s786').it618_crowd_getlang('s516');
		}
	}
}

if($_GET['ac']=="hfsalepj"){
	$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid']);
	$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
	
	if(in_array($_G['uid'], $crowd_adminuids)){
		$adminflag=1;
	}
	
	if($adminflag==1){
		C::t('#it618_crowd#it618_crowd_sale')->update($it618_crowd_sale['id'],array(
			'it618_hfcontent' => it618_crowd_utftogbk($_GET["hfvalue"])
		));
		
		echo 'okit618_split'.it618_crowd_getlang('t348');
	}else{
		echo it618_crowd_getlang('s513');return;
	}
}

if($_GET['ac']=="goodslist_get"){
	if($it618_crowd['crowd_style']>2){
		$crowdstyle=getcookie('crowdstyle');
		if($crowdstyle==''){
			if($it618_crowd['crowd_style']==3)$crowdstyle='1';else $crowdstyle='2';
		}
	}else{
		if($it618_crowd['crowd_style']==1)$crowdstyle='1';else $crowdstyle='2';
	}
	
	$ppp = $it618_crowd['crowd_wappcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='it618_state=1';
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	if($_GET['it618_saletype']==1)$sql.=" and it618_saletype=1";
	if($_GET['it618_saletype']==2)$sql.=" and it618_saletype=2";
	
	if($_GET['it618_order']==1)$orderby='jiexiao';
	if($_GET['it618_order']==2)$orderby='it618_pricecount_find';
	if($_GET['it618_order']==3)$orderby='it618_salecount desc';
	if($_GET['it618_order']==4)$orderby='it618_price';
	if($_GET['it618_order']==5)$orderby='price_sale desc';
	if($_GET['it618_order']==6)$orderby='price_sale';
	if($_GET['it618_order']==7)$orderby='it618_time desc';
	
	$listcount = C::t('#it618_crowd#it618_crowd_goods')->count_by_search($sql,'',$_GET['it618_class1'],$_GET['it618_class2'],it618_crowd_utftogbk($_GET['it618_name']));
	
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')return;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';
		
	}
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".$urlsql.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value)">'.$curpage.'</select>';
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".$urlsql.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_crowd_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".$urlsql.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s511').'</a>';
		}
	}
	
	$tdn=1;
	foreach(C::t('#it618_crowd#it618_crowd_goods')->fetch_all_by_search(
		$sql,$orderby,$_GET['it618_class1'],$_GET['it618_class2'],it618_crowd_utftogbk($_GET['it618_name']),0,0,$startlimit,$ppp
	) as $it618_crowd_goods) {
		$pjcount=C::t('#it618_crowd#it618_crowd_sale')->countpj_by_pid($it618_crowd_goods['id']);
		if($pjcount>0){
			$pjscore=C::t('#it618_crowd#it618_crowd_sale')->fetch_sumpjscore_by_pid($it618_crowd_goods['id']);
			$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);

			$pjpl1=sprintf( "%.1f",$pjavgscore1/5*100);
			$pjpl2=sprintf( "%.1f",$pjavgscore2/5*100);
			$pjpl3=sprintf( "%.1f",$pjavgscore3/5*100);
			$pjpl4=sprintf( "%.1f",$pjavgscore4/5*100);
			
			$pj1_count4=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],4);
			$pj1_count5=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],5);
			
			$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
			
			$pj=$pjcount.' '.it618_crowd_getlang('s482').' '.$pjavgscore1.' '.it618_crowd_getlang('s483').':'.$mydpl.'% ';
		}else{
			$pj=it618_crowd_getlang('s484').' ';	
		}
		
		DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pjpfstr='".$pj."' WHERE id=".$it618_crowd_goods['id']);
		
		$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
				
		if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
			$pricecount=$it618_crowd_sale['it618_pricecount'];
			$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
			$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_sale['it618_price'];
		}else{
			$pricecount=$it618_crowd_goods['it618_pricecount'];
			$pricecount1=0;
			$pricecount2=$pricecount;
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_goods['it618_price'];
			
			if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
			}
		}
		
		$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
		
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		
		$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
		
		if($crowdstyle=='1'){
			$views=' '.it618_crowd_getlang('s118').''.$it618_crowd_goods['it618_views'];
		
			$strlist.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"/></a></td>
							<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
								<div class="tdname">'.$it618_name.'</div>
								<div class="tddes">'.$pj.' '.$views.'</div>
								<ul class="tdprice">
								  <li>
									<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
									<p class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></p>
									<table class="graphtable"><tr>
									<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
									<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
									<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
									</tr></table>
								  </li>
								</ul>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr1='<tr class="trimg">';
				$trtmpstr2='<tr class="trabout">';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr1.='<td '.$tdstr.'><a href="'.$tmpurl.'">
							<img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"/>
						</a></td>';
			
			$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
							<div class="tdname">'.$it618_name.'</div>
							<div class="tddes">'.$pj.'</div>
							<div class="tdprice">
								<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
								<p class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></p>
								<table class="graphtable"><tr>
								<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
								<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
								<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
								</tr></table>
							</div>
						</a></td>';
						
			if($tdn%2==0){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$strlist.=$trtmpstr1.$trtmpstr2;
			}
			
			$tdn=$tdn+1;
		}
	}
	
	if($crowdstyle=='1'){
		$tmparr=explode('</tr>',$strlist);
		if(count($tmparr)>1){
			$strlist=$strlist.'@@@';
			$strlist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$strlist);
		}
	}else{
		$trtmpstr=$trtmpstr1.'@@@';
		$tmparr=explode('</td>@@@',$trtmpstr);
		if(count($tmparr)>1){
			$trtmpstr1.='</tr>';
			$trtmpstr2.='</tr>';
			$strlist.=$trtmpstr1.$trtmpstr2;
		}
	}
	
	$classname=$it618_crowd_lang['s1770'];
	if($_GET['it618_class1']>0){
		$classname=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($_GET['it618_class1']);
	}
	if($_GET['it618_class2']>0){
		$classname=C::t('#it618_crowd#it618_crowd_class2')->fetch_it618_name_by_id($_GET['it618_class2']);
	}
	
	$ordername=$it618_crowd_lang['t103'];
	if($_GET['it618_order']==2)$ordername=$it618_crowd_lang['t105'].'<img src="source/plugin/it618_crowd/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==3)$ordername=$it618_crowd_lang['t101'].'<img src="source/plugin/it618_crowd/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==4)$ordername=$it618_crowd_lang['t107'].'<img src="source/plugin/it618_crowd/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==5)$ordername=$it618_crowd_lang['t113'].'<img src="source/plugin/it618_crowd/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==6)$ordername=$it618_crowd_lang['t113'].'<img src="source/plugin/it618_crowd/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==7)$ordername=$it618_crowd_lang['t110'].'<img src="source/plugin/it618_crowd/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	
	if($_GET['it618_name']=='')$it618_name=$it618_crowd_lang['s1771'];else $it618_name=it618_crowd_utftogbk($_GET['it618_name']);

	$sqlbq='<tr><td class="bq1" onClick="getfind(0)">'.$classname.'<img src="source/plugin/it618_crowd/wap/images/arw_b.gif"></td><td class="bq2" onClick="getfind(0)">'.$ordername.'<img src="source/plugin/it618_crowd/wap/images/arw_b.gif"></td><td class="bq3"><input type="text" id="searchli_txt1" value="'.$it618_name.'" readonly onClick="getfind(1)"></td></tr>';
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext.' '.it618_crowd_getlang('s548').$listcount."it618_split".$sqlbq;
}

if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d.i"."sz"."z. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	return;
}

if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d.i"."sz"."z. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	return;
}

if($_GET['ac']=="savekd"){
	$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
	if(!in_array($_G['uid'],$crowd_adminuids)){
		echo 'it618_split'.it618_crowd_getlang('s513');return;
	}
	
	C::t('#it618_crowd#it618_crowd_sale')->update($_GET['saleid'],array(
		'it618_state' => 2,
		'it618_kdid' => $_GET['it618_kdid'],
		'it618_kddan' => $_GET['it618_kddan']
	));
	
	it618_crowd_sendmessage('sale1_user',$_GET['saleid']);
	
	echo 'okit618_split'.it618_crowd_getlang('s677');return;

}

if($_GET['ac']=="salebz"){
	$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
	if(!in_array($_G['uid'],$crowd_adminuids)){
		echo 'it618_split'.it618_crowd_getlang('s513');return;
	}
	
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	C::t('#it618_crowd#it618_crowd_sale')->update($_GET['saleid'],array(
		'it618_salebz' => it618_crowd_utftogbk($_GET["bzvalue"])
	));
	
	echo 'okit618_split'.it618_crowd_getlang('s1780');
}

if($_GET['ac']=="sale_dao"){
	$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
	if(!in_array($_G['uid'],$crowd_adminuids)){
		echo 'it618_split'.it618_crowd_getlang('s513');return;
	}
	
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "and s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "and s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "and s.it618_state = 3";
	}
	
	if($_GET['saletype']) {
		if($_GET['saletype']==1)$it618sql .= " and s.it618_saletype = 1";
		if($_GET['saletype']==2)$it618sql .= " and s.it618_saletype = 2";
	}
	
	$strtmp=$it618_crowd_lang['s1104']."\n";
	foreach(C::t('#it618_crowd#it618_crowd_sale')->fetch_all_by_search(
		"s.it618_state!=0 ".$it618sql,'s.it618_uid,s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']
	) as $it618_crowd_sale) {
		$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
		
		$it618_kddan='';
		if($it618_crowd_sale['it618_kdid']>0){
			$it618_crowd_kd=C::t('#it618_crowd#it618_crowd_kd')->fetch_by_id($it618_crowd_sale['it618_kdid']);
			$it618_kddan=it618_crowd_getlang('s775').$it618_crowd_kd['it618_name'].' '.$it618_crowd_sale['it618_kddan'];
		}
		
		$strtmp.=$it618_crowd_goods['it618_name'].",".$gtypename.",".$it618_crowd_sale['it618_count'].",".$it618_saletype.",".$it618_gthdname.",".it618_crowd_getusername($it618_crowd_sale['it618_uid'])." ".$it618_crowd_sale['it618_name']." ".$it618_crowd_sale['it618_tel']." ".$it618_crowd_sale['it618_addr']." ".$it618_crowd_sale['it618_bz']." ".$it618_kddan.",".date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).",".$it618_crowd_sale['it618_salebz']."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/shop'.$ShopId.'/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/shop'.$ShopId.'/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_crowd_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_crowd/kindeditor/data/shop'.$ShopId.'/dao/'.$timestr.'.csv';
}

if($_GET['ac']=="sale_get"){
	$time=$_G['timestamp']-3600*24*$it618_crowd['crowd_autodatecount'];
	foreach(C::t('#it618_crowd#it618_crowd_sale')->fetch_all_by_search("s.it618_time<".$time." and s.it618_state=2 and s.it618_saletype=1") as $it618_crowd_sale) {
		qrxf($it618_crowd_sale['id']);
	}
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "and s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "and s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "and s.it618_state = 3";
	}
	
	if($_GET['saletype']) {
		if($_GET['saletype']==1)$it618sql .= " and s.it618_saletype = 1";
		if($_GET['saletype']==2)$it618sql .= " and s.it618_saletype = 2";
	}
	
	if($_GET['jfid']>0) {
		$it618sql .= " and s.it618_jfid = ".intval($_GET['jfid']);
	}
	
	$ppp = 12;
	$count = C::t('#it618_crowd#it618_crowd_sale')->count_by_search("s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	if($_GET['jfid']>0) {
		$jfname=$_G['setting']['extcredits'][$_GET['jfid']]['title'];
		$sum = C::t('#it618_crowd#it618_crowd_sale')->sum_by_search("s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
		$sumstr=$jfname.$it618_crowd_lang['s120'].'<font color=red>'.$sum.'</font>';
	}
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_crowd:sc_sale".$urlsql);
	
	$salesum= '<td colspan=15>'.it618_crowd_getlang('s229').'<font color=red>'.$count.'</font> '.$sumstr.'<span style="float:right">'.$it618_crowd_lang['t234'].'<font color="red">'.$it618_crowd['crowd_autodatecount'].'</font>'.$it618_crowd_lang['t235'].'</span></td>';
	
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_crowd:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
	
	$tmp.='<option value="0">'.it618_crowd_getlang('s698').'</option>';
	foreach(C::t('#it618_crowd#it618_crowd_kd')->fetch_all_by_search() as $it618_crowd_kd) {
		$tmp.='<option value='.$it618_crowd_kd['id'].'>'.$it618_crowd_kd['it618_name'].'</option>';
	}
			
	foreach(C::t('#it618_crowd#it618_crowd_sale')->fetch_all_by_search(
		"s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_crowd_sale) {
		
		$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
		$class1name = C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($it618_crowd_goods['it618_class1_id']);
		$class2name = C::t('#it618_crowd#it618_crowd_class2')->fetch_it618_name_by_id($it618_crowd_goods['it618_class2_id']);
		
		if($it618_crowd_sale['it618_state']==1)$it618_state='<font color=red>'.it618_crowd_getlang('t15').'</font>';
		if($it618_crowd_sale['it618_state']==2)$it618_state='<font color=#f60>'.it618_crowd_getlang('t16').'</font>';
		if($it618_crowd_sale['it618_state']==3)$it618_state='<font color=green>'.it618_crowd_getlang('t17').'</font>';
		
		$bz='';$strcontent='';
		if($it618_crowd_sale['it618_bz']!=""){
			$strcontent.='<strong>'.it618_crowd_getlang('s783').'</strong><br>'.$it618_crowd_sale['it618_bz'].'<br><br>';
		}
		
		$bzbtn='';$kdbtn='1';$it618_kddan='';
		if($it618_crowd_sale['it618_saletype']==1){
			$it618_crowd_kd=C::t('#it618_crowd#it618_crowd_kd')->fetch_by_id($it618_crowd_sale['it618_kdid']);
			if($it618_crowd_sale['it618_kddan']!='')$it618_kddan='<span title="'.$it618_crowd_sale['it618_bz'].'" style="color:green">'.$it618_crowd_kd['it618_name'].' '.$it618_crowd_sale['it618_kddan'].'</span>';
			
			if($it618_crowd_sale['it618_state']==1){
				if($it618_crowd_sale['it618_tel']==''){
					$it618_state.='<br><font color=blue>'.$it618_crowd_lang['s679'].'</font>';
				}else{
					if($it618_crowd_sale['it618_kddan']==''){
						$it618_state.='<br><a href="javascript:" id="fahuo'.$it618_crowd_sale[id].'">'.it618_crowd_getlang('s784').'</a>';
						$kdbtnname=it618_crowd_getlang('s785');
					}else{
						$kdbtnname=it618_crowd_getlang('s786');
						$it618_kddan.=' <a href="javascript:" id="fahuo'.$it618_crowd_sale[id].'">'.$kdbtnname.'</a>';
					}
				}
			}else{
				$kdbtnname=it618_crowd_getlang('s787');
				$it618_kddan.=' <a href="javascript:" id="fahuo'.$it618_crowd_sale[id].'">'.$kdbtnname.'</a>';
				$kdbtn='';
			}
			
			if($kdbtn!='')$kdbtn='<input type="button" class="it618btn" value="'.$kdbtnname.'" onclick="savekd()">';
			if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;

			$tmp1=str_replace("<option value=".$it618_crowd_kd['id'],"<option value=".$it618_crowd_kd['id']." selected=selected",$tmp);
			
			$strcontent.='<div class="kd_fahuo">'.$it618_crowd_sale['it618_name'].' '.$it618_crowd_sale['it618_addr'].' '.$it618_crowd_sale['it618_tel'].'<br><br>'.$bz.it618_crowd_getlang('s699').'<select id="it618_kdid">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_crowd_sale['it618_kddan'].'"><input type="hidden" id="saleid" value="'.$it618_crowd_sale['id'].'"> '.$kdbtn.' <span style="color:red" id="kdtips"></span></div>';
		}else{
			$it618_kddan='';
		}
		
		$strtel=it618_crowd_getlang('s701').$it618_crowd_sale['it618_crowtel'];
		
		$salebz='';
		if($it618_crowd_sale['it618_saletype']==1){
			$it618_salebz='';
			if($it618_crowd_sale['it618_salebz']!=''){
				$it618_salebz='(<font color="red">'.strlen($it618_crowd_sale['it618_salebz']).'</font>'.$it618_crowd_lang['s1782'].')';
			}
			$salebz='<br><a href="javascript:" onclick="setsalebz('.$it618_crowd_sale[id].')">'.$it618_crowd_lang['s1777'].$it618_salebz.'</a>';
		}
		
		$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
		
		$jfname=$_G['setting']['extcredits'][$it618_crowd_sale['it618_jfid']]['title'];
		
		if($it618_kddan!='')$it618_kddan='<br>'.$it618_kddan;
		$strtmp=$strtel.$bz.$it618_kddan;
		
		$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
		$sale_get.='<tr class="hover">
		<td>'.$it618_crowd_sale['id'].'</td>
		<td><a href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_crowd_goods['it618_description'].'">'.$pname.'</a></td>
		<td>'.$it618_crowd_sale['it618_pricecount'].'</td>
		<td>'.($it618_crowd_sale['it618_price']*$it618_crowd_sale['it618_pricecount']).' <font color=#999>'.$jfname.'</font>'.$salebz.'</td>
		<td width=300>'.$it618_state.'<br>'.$strtmp.'</td>
		<td><a href="'.it618_crowd_rewriteurl($it618_crowd_sale['it618_uid']).'" target="_blank">'.it618_crowd_getusername($it618_crowd_sale['it618_uid']).'</a></td>
		<td><div style="width:80px;color:#999">'.date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).'<div></td>
		</tr>';

		if($it618_crowd_sale['it618_saletype']==1){
			$strcontent=str_replace("'","\"",$strcontent);
			$strcontent=str_replace(array("\r\n", "\r", "\n"),"<br>",$strcontent);
		
			$tmpjs.='KindEditor.ready(function(K) {K(\'#fahuo'.$it618_crowd_sale[id].'\').click(function() {
				dialog_fahuo = K.dialog({
					width : 660,
					height : 350,
					title : \''.it618_crowd_getlang('s866').'\',
					body : \'<div style="margin:10px;">'.$strcontent.'</div>\',
					closeBtn : {
						name : \''.it618_crowd_getlang('s703').'\',
						click : function(e) {
							dialog_fahuo.remove();
						}
					},
					noBtn : {
						name : \''.it618_crowd_getlang('s703').'\',
						click : function(e) {
							dialog_fahuo.remove();
						}
					}
				});
			});});';
			
			$strsalebz=str_replace("'","\"",$strsalebz);
			$strsalebz=str_replace(array("\r\n", "\r", "\n"),"<br>",$strsalebz);
		}

	}

	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value=1 name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
}

if($_GET['ac']=="crowdsale_get"){
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	
	$ppp = 15;
	$count = C::t('#it618_crowd#it618_crowd_crowdsale')->count_by_search($it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_crowd:sc_sale".$urlsql);
	
	$salesum= '<td colspan=15>'.it618_crowd_getlang('s229').'<font color=red>'.$count.'</font><span style="float:right">'.$it618_crowd_lang['s31'].'</span></td>';
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_crowd:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
			
	foreach(C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_all_by_search(
		$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_crowd_crowdsale) {
		
		$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_crowdsale['it618_pid']);
		$class1name = C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($it618_crowd_goods['it618_class1_id']);
		$class2name = C::t('#it618_crowd#it618_crowd_class2')->fetch_it618_name_by_id($it618_crowd_goods['it618_class2_id']);
		
		$username=it618_crowd_getusername($it618_crowd_crowdsale['it618_uid']);
		if($it618_crowd_crowdsale['it618_state']==1){
			$username='<font color=red>'.$username.'</font>';
		}

		$it618_crowd_sale = C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($it618_crowd_crowdsale['it618_saleid']);
		
		$buyuser='<a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale['it618_uid']).'" target="_blank">'.$username.'</a>';
		
		$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
		
		if($it618_crowd_sale['it618_state']==0){
			$pricecount=$it618_crowd_sale['it618_pricecount'];
			$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
			$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
			$pricecountbl=intval($pricecount1/$pricecount*100);
			$tmppname='<font color=#999>'.$it618_crowd_lang['t20'].'</font><font color=#f60>'.$pricecountbl.'%</font>';
		}else{
			$tmppname='<font color=#999>'.$it618_crowd_lang['t22'].'</font>';
		}
		
		$pname.=' '.$tmppname;
		
		$jfname=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
		
		$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
		$sale_get.='<tr class="hover">
		<td><a href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_crowd_goods['it618_description'].'">'.$pname.'</a></td>
		<td><font color="red">'.$it618_crowd_crowdsale['it618_count'].'</font> <a href="javascript:" onclick="setsalecodes('.$it618_crowd_crowdsale['id'].')">'.$it618_crowd_lang['t232'].'</a></td>
		<td>'.$it618_crowd_crowdsale['it618_price'].' '.$jfname.'</td>
		<td><font color="red">'.($it618_crowd_crowdsale['it618_price']*$it618_crowd_crowdsale['it618_count']).'</font> '.$jfname.'</td>
		<td>'.$buyuser.'</td>
		<td><font color=#999>'.it618_crowd_getudate($it618_crowd_crowdsale['it618_time']).'</font></td>
		</tr>';
	}

	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value=1 name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
}

if($_GET['ac']=="getgrouplist1"){
	$ppp = 30;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	$tomonth = date('n'); 
	$todate = date('j'); 
	$toyear = date('Y');
	$time=mktime(0, 0, 0, $tomonth, 1, $toyear);
	
	$n=1;
	$query = DB::query("SELECT it618_uid,sum(it618_group) as it618_groupsum FROM ".DB::table('it618_crowd_crowdsale_grouplog')." where it618_time>=$time group by it618_uid ORDER BY it618_groupsum desc limit $startlimit,$ppp");
	while($it618_crowd_crowdsale_group = DB::fetch($query)) {
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		$grouplist.='<tr>
						<td><a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale_group['it618_uid']).'" target="_blank"><img src="'.it618_crowd_discuz_uc_avatar($it618_crowd_crowdsale_group['it618_uid'],'small').'" width="30" height="30"> '.it618_crowd_getusername($it618_crowd_crowdsale_group['it618_uid']).'</a></td>
						<td><font color=#F60>'.$it618_crowd_crowdsale_group['it618_groupsum'].'</font></td>
						<td>'.$n.'</td>
						</tr>';
		$n=$n+1;
	}

	$count = DB::result_first("SELECT count(DISTINCT it618_uid) FROM ".DB::table('it618_crowd_crowdsale_grouplog')." where it618_time>=$time group by it618_uid limit $startlimit,$ppp");

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgrouplist2(this.value)">'.$curpage.'</select>';
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl'].'plugin.php?id=it618_crowd:ajax&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgrouplist2(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_crowd_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgrouplist2(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgrouplist2(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgrouplist2(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s511').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext.' '.it618_crowd_getlang('s229').$count;
	}

	
	echo $grouplist."it618_split".$multipage;
}

if($_GET['ac']=="getgrouplist2"){
	$ppp = 30;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_crowdsale_group')." ORDER BY it618_groupsum desc limit $startlimit,$ppp");
	while($it618_crowd_crowdsale_group = DB::fetch($query)) {
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		$grouplist.='<tr>
						<td><a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale_group['it618_uid']).'" target="_blank"><img src="'.it618_crowd_discuz_uc_avatar($it618_crowd_crowdsale_group['it618_uid'],'small').'" width="30" height="30"> '.it618_crowd_getusername($it618_crowd_crowdsale_group['it618_uid']).'</a></td>
						<td><font color=#F60>'.$it618_crowd_crowdsale_group['it618_groupsum'].'</font></td>
						<td>'.$n.'</td>
						</tr>';
		$n=$n+1;
	}
	
	$count = C::t('#it618_crowd#it618_crowd_crowdsale_group')->count_by_search();

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgrouplist1(this.value)">'.$curpage.'</select>';
		if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl'].'plugin.php?id=it618_crowd:ajax&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgrouplist1(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_crowd_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgrouplist1(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgrouplist1(\''.$tmpurl.'\')">'.it618_crowd_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax".'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgrouplist1(\''.$tmpurl.'\')">'.it618_crowd_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s511').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext.' '.it618_crowd_getlang('s229').$count;
	}

	
	echo $grouplist."it618_split".$multipage;
}

if($_GET['ac']=="crowdstyle"){
	$crowdstyle=getcookie('crowdstyle');
	if($crowdstyle==''){
		if($it618_crowd['crowd_style']==3)$crowdstyle='1';else $crowdstyle='2';
	}
	if($crowdstyle=='1')$crowdstyle='2';else $crowdstyle='1';
	dsetcookie('crowdstyle',$crowdstyle);
	echo 'ok';
}

$n=1;
if($_GET['ac']=="getproductclass"){
	$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productclass2\',0,0)" name="productclass2"><span>'.$it618_crowd_lang['s466'].'</span><i></i></a>';
	foreach(C::t('#it618_crowd#it618_crowd_class2')->fetch_all_by_it618_class1_id($_GET['cid']) as $it618_tmp) {	
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass2\','.$n.','.$it618_tmp['id'].')" name="productclass2"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $classtmp;
}

if($_GET['ac']=="findgroup"){	
	$finduid=C::t('#it618_crowd#it618_crowd_crowdsale_group')->fetch_uid_by_username(it618_crowd_utftogbk($_GET["groupuser"]));
	
	if($finduid>0){
	    $count=C::t('#it618_crowd#it618_crowd_crowdsale_group')->count_by_uid($finduid);
		if($count>0){
			if($_GET['type']=="1"){
				$tmpstr=C::t('#it618_crowd#it618_crowd_crowdsale_grouplog')->getcount_by_groupsum($finduid);
				$tmparr=explode("@",$tmpstr);
				$groupsum=$tmparr[0];
				$count=$tmparr[1];
			}else{
				$groupsum=C::t('#it618_crowd#it618_crowd_crowdsale_group')->get_groupsum_by_uid($finduid);
				$count=C::t('#it618_crowd#it618_crowd_crowdsale_group')->count_by_groupsum($groupsum);
				$count=$count+1;
			}
			
			echo $groupsum.$it618_crowd_lang['s400'].' '.$it618_crowd_lang['s392'].$count.$it618_crowd_lang['s393'];
		}else{
			echo $it618_crowd_lang['s790'];
		}
	}else{
		echo $it618_crowd_lang['s791'];
	}
}
//From: Dism_taobao_com
?>