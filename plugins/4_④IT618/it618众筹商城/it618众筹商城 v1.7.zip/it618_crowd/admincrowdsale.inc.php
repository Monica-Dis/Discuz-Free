<?php
 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
 
global $title;
$title='crowdsale';
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/adminheader.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_crowd/js/Calendar.js"></script>
<link rel="stylesheet" href="source/plugin/it618_crowd/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_crowd/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_crowd/js/jquery.js"></script>
';

showtableheaders(it618_crowd_getlang('s413'),'it618_crowd_sum');

	echo '<tr><td colspan="15" style="background-color:#f9f9f9;"><span id="salecodes"></span><div class="fixsel">'.it618_crowd_getlang('t12').' <input id="pname" class="txt" style="width:231px;margin-right:1px" /><br>'.it618_crowd_getlang('s134').' <input id="finduid" class="txt" style="width:76px" />'.it618_crowd_getlang('t5').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_crowd_getlang('s135').'" onclick="findsalelist()" /></div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>';
	
	showsubtitle(array(it618_crowd_getlang('t2'),it618_crowd_getlang('t7'),it618_crowd_getlang('t9'),it618_crowd_getlang('t10'),it618_crowd_getlang('s32'),it618_crowd_getlang('t5')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_crowd/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr>';

showtablefooter();/*Dism��taobao��com*/
echo '
<script>
var dialog_salecodes,salecodesid=0;
KindEditor.ready(function(K) {K(\'#salecodes\').click(function() {
	getsalecodes(K);
});});

function getsalecodes(K){
	IT618_CROWD.get("'.$_G['siteurl'].'plugin.php?id=it618_crowd:salecodes"+"&crowdsaleid="+salecodesid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	dialog_salecodes = K.dialog({
		width : 620,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.$it618_crowd_lang['t285'].'\',
			click : function(e) {
				dialog_salecodes.remove();
				salecodesid=0;
			}
		}
	});
	
	}, "html");		
}

function setsalecodes(crowdsaleid){
	if(salecodesid==0){
		salecodesid=crowdsaleid;
		IT618_CROWD("#salecodes").click();
	}
}

var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_crowd:ajax";
var sqlurl="";
function getsalelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_CROWD.post(url+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"crowdsale_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_CROWD("#tr_salesum").html(tmparr[0]);
	IT618_CROWD("#tr_salelist").html(tmparr[1]);
	IT618_CROWD("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
getsalelist(saleurl);

function findsalelist(){
	var pname = document.getElementById("pname").value;
	var finduid = document.getElementById("finduid").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&pname="+pname+"&finduid="+finduid+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_crowd:ajax";
	getsalelist(url);
}
</script>

</body></html>
';
?>