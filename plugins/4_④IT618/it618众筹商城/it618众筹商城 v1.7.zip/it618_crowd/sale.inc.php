<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/crowd_default.func.php';

if($it618_crowd['crowd_wap']==1){
	if(crowd_is_mobile()){ 
		$tmpurl=it618_crowd_getrewrite('crowd_wap','sale','plugin.php?id=it618_crowd:wap&pagetype=sale');
		dheader("location:$tmpurl");
	}
}

foreach(C::t('#it618_crowd#it618_crowd_focus')->fetch_all_by_type_order(5) as $it618_crowd_focus) {
	if($it618_crowd_focus['it618_url']!=''){
		$str_focus5.='<li><a href="'.$it618_crowd_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus5.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

$class1=intval($_GET['class1']);

$it618sql="s.it618_code!=''";

if($class1==0)$current=' class="current"';else $current='';
$tmpurl=it618_crowd_getrewrite('crowd_sale','','plugin.php?id=it618_crowd:sale');
$salecount=C::t('#it618_crowd#it618_crowd_sale')->count_by_search($it618sql);
$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_crowd_getlang('s466').'<span>'.$salecount.'</span></a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
$salecount=0;
while($it618_crowd_class1 = DB::fetch($query)) {
	$it618sql1=$it618sql.' and g.it618_class1_id='.$it618_crowd_class1['id'];
	$salecount=C::t('#it618_crowd#it618_crowd_sale')->count_by_search($it618sql1);
	if($class1==$it618_crowd_class1['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_crowd_getrewrite('crowd_sale',$it618_crowd_class1['id'].'@1','plugin.php?id=it618_crowd:sale&class1='.$it618_crowd_class1['id'].'&page=1');
	$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_crowd_class1['it618_classname'].'<span>'.$salecount.'</span></a></li>';
}

if($class1>0){
	$class1name=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($class1);
	$classtitle.=$class1name.' ';
	
	$it618sql.=' and g.it618_class1_id='.$class1;
}

$ppp=$it618_crowd['crowd_listpagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$count = C::t('#it618_crowd#it618_crowd_sale')->count_by_search($it618sql);
$hrefsql=it618_crowd_getrewrite('crowd_sale',$class1.'@it618page','plugin.php?id=it618_crowd:sale&class1='.$class1);
$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_crowd_multipage($multipage,$uri);

if($_G['cache']['plugin']['it618_crowd']['rewriteurl']==1&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php')){
	$isrewrite=1;
}

foreach(C::t('#it618_crowd#it618_crowd_sale')->fetch_all_by_search(
	$it618sql,'s.it618_time desc','',0,'','',$startlimit,$ppp
) as $it618_crowd_sale) {
	
	$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
	$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
	$jfname=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
	$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id'].'&saleid='.$it618_crowd_sale['id']);
	if($isrewrite==1)$tmpurl=$tmpurl.'?saleid='.$it618_crowd_sale['id'];
	
	$sumcont=C::t('#it618_crowd#it618_crowd_crowdsale')->sumcount_by_saleid_uid($it618_crowd_sale['id'],$it618_crowd_sale['it618_uid']);
	$groupsum=C::t('#it618_crowd#it618_crowd_crowdsale_group')->get_groupsum_by_uid($it618_crowd_sale['it618_uid']);
	
	$str_goodslist.='<div class="goods salegoods">
				<a class="goods-img" href="'.$tmpurl.'" target="_blank">
				<img imgsrc="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" src="source/plugin/it618_crowd/images/a.gif" class="dynload" width="200" height="200" alt="'.$it618_name.'" />
				</a>
				<ul>
				<li class="liavatar"><a href="'.it618_crowd_rewriteurl($it618_crowd_sale['it618_uid']).'" target="_blank"><img src="'.it618_crowd_discuz_uc_avatar($it618_crowd_sale['it618_uid'],'small').'"></a></li>
				<li>'.$it618_crowd_lang['s471'].'<a href="'.it618_crowd_rewriteurl($it618_crowd_sale['it618_uid']).'" target="_blank">'.it618_crowd_getusername($it618_crowd_sale['it618_uid']).'</a></li>
				<li>'.$it618_crowd_lang['s472'].'<font color=red>'.$groupsum.'</font></li>
				<li>'.$it618_crowd_lang['s473'].'<font color=#f60>'.$it618_crowd_sale['it618_code'].'</font></li>
				<li>'.$it618_crowd_lang['s474'].'<font color=#f60>'.$sumcont.'</font>'.$it618_crowd_lang['s13'].'</li>
				<li class="lipname"><a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$pname.'">'.$pname.'</a></li>
				<li class="lipinfo">'.$it618_crowd_lang['s475'].''.($it618_crowd_sale['it618_price']*$it618_crowd_sale['it618_pricecount']).'</font>'.$jfname.'</li>
				<li class="lipinfo">'.$it618_crowd_lang['s476'].''.$it618_crowd_sale['it618_pricecount'].$it618_crowd_lang['s13'].'</li>
				<li class="lipinfo">'.$it618_crowd_lang['s477'].''.date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).'</li>
				<li class="lipbtn"><a href="'.$tmpurl.'" target="_blank">'.$it618_crowd_lang['s478'].'</a></li>
				</ul>
				</div>';
}

$tomonth = date('n'); 
$todate = date('j'); 
$toyear = date('Y');
$time=mktime(0, 0, 0, $tomonth, 1, $toyear);

$n=1;
$query = DB::query("SELECT it618_uid,sum(it618_group) as it618_groupsum FROM ".DB::table('it618_crowd_crowdsale_grouplog')." where it618_time>=$time group by it618_uid ORDER BY it618_groupsum desc limit 0,30");
while($it618_crowd_crowdsale_group = DB::fetch($query)) {
	$monthgroupstr.='<li><span><a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale_group['it618_uid']).'" target="_blank"><img src="'.it618_crowd_discuz_uc_avatar($it618_crowd_crowdsale_group['it618_uid'],'small').'"></a></span><p><span style="float:right;margin-top:10px;color:#999;width:auto">'.$it618_crowd_lang['s392'].'<font color=red>'.$n.'</font>'.$it618_crowd_lang['s393'].'</span>'.it618_crowd_getusername($it618_crowd_crowdsale_group['it618_uid']).'<br><font color=#F60>'.$it618_crowd_crowdsale_group['it618_groupsum'].'</font> <font color=#999>'.$it618_crowd_lang['s400'].'</font></p></li>';
	$n=$n+1;
}

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_crowdsale_group')." ORDER BY it618_groupsum desc limit 0,30");
while($it618_crowd_crowdsale_group = DB::fetch($query)) {
	$groupstr.='<li><span><a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale_group['it618_uid']).'" target="_blank"><img src="'.it618_crowd_discuz_uc_avatar($it618_crowd_crowdsale_group['it618_uid'],'small').'"></a></span><p><span style="float:right;margin-top:10px;color:#999;width:auto">'.$it618_crowd_lang['s392'].'<font color=red>'.$n.'</font>'.$it618_crowd_lang['s393'].'</span>'.it618_crowd_getusername($it618_crowd_crowdsale_group['it618_uid']).'<br><font color=#F60>'.$it618_crowd_crowdsale_group['it618_groupsum'].'</font> <font color=#999>'.$it618_crowd_lang['s400'].'</font></p></li>';
	$n=$n+1;
}

if($classtitle!='')$classtitle=$classtitle.'- ';
$metatitle=$classtitle.$it618_crowd_lang['t50'].' - '.$metatitle;

$pagetype='sale';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:crowd_default');
?>