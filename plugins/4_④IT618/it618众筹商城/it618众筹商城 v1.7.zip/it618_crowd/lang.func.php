<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $IsCredits,$RegName;

if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_credits'")>0){
	$IsCredits=1;
}

$RegName=DB::result_first("SELECT svalue FROM ".DB::table('common_setting')." WHERE skey='regname'");

if($_SERVER['HTTP_HOST']=='localhost'||strpos($_SERVER['HTTP_HOST'],'localhost')){
	$language = 'language.php';
}else{
	$language = 'language.'.currentlang().'.php';
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/'.$language)){
	$language = 'language.php';
}

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/'.$language;
?>