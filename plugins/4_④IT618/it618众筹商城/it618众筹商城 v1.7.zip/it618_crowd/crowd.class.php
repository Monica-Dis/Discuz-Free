<?php

 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_crowd{
	
	function global_header(){
		foreach(C::t('#it618_crowd#it618_crowd_diy')->fetch_all_by_search() as $it618_crowd_diy) {
			
			$blockcount=C::t('#it618_crowd#it618_crowd_sale')->count_by_name($it618_crowd_diy["it618_name"]);
			if($blockcount>0){
				if((time()-$it618_crowd_diy["it618_time"])<(60*$it618_crowd_diy["it618_catchtime"])){
					continue;
				}else{
					C::t('#it618_crowd#it618_crowd_diy')->update_it618_time_by_id(time(),$it618_crowd_diy["id"]);
				}
			
				require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/getmode.func.php';
				$content=it618_crowd_getmodecontent($it618_crowd_diy['it618_type'],$it618_crowd_diy['it618_modecode'],$it618_crowd_diy['it618_count']);
				C::t('#it618_crowd#it618_crowd_sale')->update_summary_dateline_by_name($content,time(),$it618_crowd_diy["it618_name"]);
			}
		}
		
	}

}
//From: dis'.'m.tao'.'bao.com
?>