<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid']);
$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);

$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];

if($it618_crowd_sale['it618_uid']==$_G['uid']){
	$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_goods_salekm')." WHERE it618_saleid=".intval($_GET['saleid']));
	while($it618_crowd_goods_salekm = DB::fetch($query)) {
		$kmstr.=$it618_crowd_goods_salekm['it618_code']."\n";
		$n=$n+1;
	}
	$km_str='<span style="font-size:12px">'.it618_crowd_getlang('s847').$n.'</span><br>';
	if($_GET['wap']!=1){
		$km_str.='<textarea style="width:600px; height:400px; margin-top:8px; float:left; padding:3px" readonly="readonly">'.dhtmlspecialchars($kmstr).'</textarea>';
	}else{
		$km_str.='<textarea style="width:97%; height:300px; margin-top:8px " readonly="readonly">'.dhtmlspecialchars($kmstr).'</textarea>';
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:salekm');
?>