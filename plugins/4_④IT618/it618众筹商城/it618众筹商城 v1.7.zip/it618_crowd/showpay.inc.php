<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

if($_G['uid']>0){
	$it618_count=intval($_GET['it618_count']);
	
	$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($_GET['pid']);
	
	$it618_price=$it618_crowd_goods['it618_price_sale']*$it618_count;
	
	$pjfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
	$creditnum=DB::result_first("select extcredits".$it618_crowd_goods['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	
	$username=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_username_by_uid($_G['uid']);
	$tel=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_tel_by_uid($_G['uid']);
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_crowd/message.php';
		
		if($it618_isok==1){
			if($it618_body_sale_user_isok==1){
				$messageok=1;
			}
		}
	}
}else{
	echo $it618_crowd_lang['t192'].'it618_split'.$it618_crowd_lang['s485'];
	exit;
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:showpay');
?>