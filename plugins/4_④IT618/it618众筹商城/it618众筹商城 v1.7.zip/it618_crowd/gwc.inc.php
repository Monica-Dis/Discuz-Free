<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/crowd_default.func.php';


if($it618_crowd['crowd_wap']==1){
	if(crowd_is_mobile()){ 
		$tmpurl=it618_crowd_getrewrite('crowd_wap','gwcsale@'.$_G['uid'],'plugin.php?id=it618_crowd:wap&pagetype=gwcsale');
		dheader("location:$tmpurl");
	}
}

$uid = $_G['uid'];
if($uid<=0){
	echo it618_crowd_getlang('s1072').'<a href="member.php?mod=logging&action=login">'.it618_crowd_getlang('s461').'</a> <a href="member.php?mod='.$RegName.'">'.it618_crowd_getlang('s462').'</a>';exit;
}

if(isset($_GET['mysale'])){
	$mysale=1;
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/pay/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_crowd/pay/config.php';
}
if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/pay_wx/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_crowd/pay_wx/config.php';
}

$metatitle=it618_crowd_getlang('t187').' - '.$metatitle;

$pagetype='gwc';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:crowd_default');
?>