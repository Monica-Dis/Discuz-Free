<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_crowd_goods extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_crowd_goods';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_id_state($id,$state) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d AND it618_state=%d", array($this->_table, $id, $state));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $class1 = 0, $class2 = 0, $it618_name = '', $pricecount1 = 0, $pricecount2 = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $class1, $class2, $it618_name, $pricecount1, $pricecount2);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $class1 = 0, $class2 = 0, $it618_name = '', $pricecount1 = 0, $pricecount2 = 0, $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $class1, $class2, $it618_name, $pricecount1, $pricecount2);
		$data = array();
		$query = DB::query("SELECT *,it618_pricecount_find/it618_pricecount_sale as jiexiao,it618_price_sale*it618_pricecount_sale as price_sale FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $class1 = 0, $class2 = 0, $it618_name = '', $pricecount1 = 0, $pricecount2 = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($class1)) {
			$parameter[] = $class1;
			$wherearr[] = 'it618_class1_id=%d';
		}
		if(!empty($class2)) {
			$parameter[] = $class2;
			$wherearr[] = 'it618_class2_id=%d';
		}
		if(!empty($it618_name)) {
			$tmparr=explode(" ",$it618_name);
			for($n=0;$n<count($tmparr);$n++){
				$parameter[] = '%'.$tmparr[$n].'%';
				$parameter[] = '%'.$tmparr[$n].'%';
				$tmpsql.='(it618_name LIKE %s OR it618_description LIKE %s) and';
			}
			$tmpsql.='@';
			$tmpsql=str_replace(" and@","",$tmpsql);
			$wherearr[] = $tmpsql;
		}
		if(!empty($pricecount1)) {
			$parameter[] = $pricecount1;
			$wherearr[] = 'it618_pricecount_find>=%d';
		}
		if(!empty($pricecount2)) {
			$parameter[] = $pricecount2;
			$wherearr[] = 'it618_pricecount_find<=%d';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function update_it618_views_by_id($id) {
		DB::query("UPDATE %t SET it618_views=it618_views+1 WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_it618_salecount_by_id($id,$salecount) {
		DB::query("UPDATE %t SET it618_salecount=%d WHERE id=%d", array($this->_table, $salecount, $id));
	}
}
//From: Dism_taobao_com
?>