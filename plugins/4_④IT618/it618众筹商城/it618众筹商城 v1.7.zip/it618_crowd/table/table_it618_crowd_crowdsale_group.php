<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_crowd_crowdsale_group extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_crowd_crowdsale_group';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d", array($this->_table,$uid));
	}
	
	public function count_by_groupsum($groupsum) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_groupsum>%d", array($this->_table,$groupsum));
	}
	
	public function fetch_username_by_uid($uid) {
		return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function fetch_uid_by_username($username) {
		return DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username=%s", array($username));
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function get_groupsum_by_uid($uid) {
		return DB::result_first("SELECT it618_groupsum FROM %t WHERE it618_uid=%d", array($this->_table,$uid));
	}
}
//From: Dism_taobao_com
?>