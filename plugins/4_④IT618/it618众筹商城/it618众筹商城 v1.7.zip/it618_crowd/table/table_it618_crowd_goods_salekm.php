<?php
 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_crowd_goods_salekm extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_crowd_goods_salekm';
		$this->_pk = 'id';
		parent::__construct();
	}
}
//From: Dism_taobao_com
?>