<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_crowd_sale extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_crowd_sale';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_it618_pid($it618_pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_state!=0 AND it618_pid=%d", array($this->_table, $it618_pid));
	}
	
	public function count_by_pid_saleid($pid,$saleid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d AND id<=%d", array($this->_table, $pid, $saleid));
	}
	
	public function fetch_by_pid_state($pid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_pid=%d AND it618_state=0", array($this->_table, $pid));
	}
	
	public function countpj_by_pid($pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_score1>0 AND it618_pid=%d", array($this->_table, $pid));
	}
	
	public function countpj1_by_pid_score($pid,$score) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_score1=%d AND it618_pid=%d", array($this->_table, $score, $pid));
	}
	
	public function fetch_sumpjscore_by_pid($pid) {
		return DB::fetch_first("SELECT SUM(it618_score1) as score1,SUM(it618_score2) as score2,SUM(it618_score3) as score3,SUM(it618_score4) as score4 FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_uid_by_id($id) {
		return DB::result_first("SELECT it618_uid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_crowdid_by_id($id) {
		return DB::result_first("SELECT it618_crowdid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_name_by_uid($uid) {
		return DB::result_first("SELECT it618_name FROM %t WHERE it618_name<>'' AND it618_uid=%d ORDER BY id desc", array($this->_table, $uid));
	}
	
	public function fetch_tel_by_uid($uid) {
		return DB::result_first("SELECT it618_tel FROM %t WHERE it618_tel<>'' AND it618_uid=%d ORDER BY id desc", array($this->_table, $uid));
	}
	
	public function fetch_addr_by_uid($uid) {
		return DB::result_first("SELECT it618_addr FROM %t WHERE it618_addr<>'' AND it618_uid=%d ORDER BY id desc", array($this->_table, $uid));
	}
	
	public function fetch_username_by_uid($uid) {
		return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function count_by_name($name) {
		return DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_block')." WHERE name=%s", array($name));
	}
	
	public function update_summary_dateline_by_name($summary, $dateline, $name) {
		DB::query("update ".DB::table('common_block')." set summary=%s, dateline=%d WHERE name=%s", array($summary, $dateline, $name));
	}
	
	public function fetch_extcredits_by_uid($creditindex,$uid) {
		return DB::result_first("select extcredits%d from ".DB::table('common_member_count')." where uid=%d", array($creditindex,$uid));
	}
	
	public function fetch_lastactivity_by_uid($uid) {
		return DB::result_first("SELECT lastactivity FROM ".DB::table('common_member_status')." WHERE uid=%d", array($uid));
	}
	
	public function count_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		return DB::result_first("SELECT count(1) FROM %t s LEFT JOIN ".DB::table('it618_crowd_goods')." g ON s.it618_pid=g.id $condition[0]", $condition[1]);
	}
	
	public function sum_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$sum = DB::result_first("SELECT SUM(s.it618_price*s.it618_pricecount) FROM %t s LEFT JOIN ".DB::table('it618_crowd_goods')." g ON s.it618_pid=g.id $condition[0]", $condition[1]);
		if($sum=='')$sum=0;
		return $sum;
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT s.* FROM %t s LEFT JOIN ".DB::table('it618_crowd_goods')." g ON s.it618_pid=g.id $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "(g.it618_name LIKE %s or g.it618_description LIKE %s)";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 's.it618_uid=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 's.it618_time>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2;
			$wherearr[] = 's.it618_time<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function fetch_all_by_it618_pid($it618_pid, $start = 0, $limit = 0) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_state!=0 AND it618_pid=%d ORDER BY id DESC".DB::limit($start, $limit), array($this->_table,$it618_pid));
	}
	
	public function fetch_allpj_by_it618_pid($it618_pid, $start = 0, $limit = 0) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_score1>0 AND it618_pid=%d ORDER BY it618_pjtime DESC".DB::limit($start, $limit), array($this->_table,$it618_pid));
	}
	
	public function update_it618_state($id,$it618_state) {
		DB::query("UPDATE %t SET it618_state=%d WHERE id=%d", array($this->_table, $it618_state, $id));
	}
	
	public function update_it618_code($id,$it618_code) {
		DB::query("UPDATE %t SET it618_code=%s WHERE id=%d", array($this->_table, $it618_code, $id));
	}
	
	public function update_lastactivity_by_uid($lastactivity,$uid) {
		DB::query("UPDATE ".DB::table('common_member_status')." SET lastactivity=%d WHERE uid=%d", array($this->_table, $lastactivity, $uid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism_taobao_com
?>