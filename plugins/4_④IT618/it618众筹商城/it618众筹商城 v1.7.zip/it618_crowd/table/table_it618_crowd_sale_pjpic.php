<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_crowd_sale_pjpic extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_crowd_sale_pjpic';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_saleid($saleid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_saleid=%d", array($this->_table,$saleid));
	}
	
	public function fetch_all_by_saleid($saleid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_saleid=%d ORDER BY it618_time desc", array($this->_table,$saleid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism_taobao_com
?>