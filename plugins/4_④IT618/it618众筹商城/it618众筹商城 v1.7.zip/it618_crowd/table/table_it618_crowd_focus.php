<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_crowd_focus extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_crowd_focus';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function count_by_type($it618_type) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_type=%d", array($this->_table,$it618_type));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_all_by_type_order($it618_type) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_type=%d AND it618_order<>0 ORDER BY it618_order", array($this->_table,$it618_type));
	}
	
	public function fetch_all_by_type($it618_type) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_type=%d ORDER BY it618_order", array($this->_table,$it618_type));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism_taobao_com
?>