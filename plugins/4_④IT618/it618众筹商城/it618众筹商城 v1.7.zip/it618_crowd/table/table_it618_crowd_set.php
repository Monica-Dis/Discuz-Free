<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_crowd_set extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_crowd_set';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function count_by_setname($setname) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE setname=%s", array($this->_table, $setname));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_setname($setname) {
		return DB::fetch_first("SELECT * FROM %t WHERE setname=%s", array($this->_table, $setname));
	}
	
	public function getsetvalue_by_setname($setname) {
		return DB::result_first("SELECT setvalue FROM %t WHERE setname=%s", array($this->_table, $setname));
	}
	
	public function fetch_by_search() {
		return DB::fetch_first("SELECT * FROM %t", array($this->_table));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism_taobao_com
?>