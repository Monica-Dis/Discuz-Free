<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_crowd_crowdsale_grouplog extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_crowd_crowdsale_grouplog';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function getcount_by_groupsum($uid) {
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, 1, $toyear);
		
		$n=1;
		$query = DB::query("SELECT it618_uid,sum(it618_group) as it618_groupsum FROM %t WHERE it618_time>=$time group by it618_uid ORDER BY it618_groupsum desc", array($this->_table));
		while($it618_crowdtmp = DB::fetch($query)) {
			if($it618_crowdtmp['it618_uid']==$uid){
				return $it618_crowdtmp['it618_groupsum'].'@'.$n;
			}
			$n=$n+1;
		}
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
}
//From: Dism_taobao_com
?>