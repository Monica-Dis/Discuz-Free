<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid']);
$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);

$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];

if($it618_crowd_sale['it618_tel']==''){
	$tmptitle=$it618_crowd_lang['s870'];	
}else{
	$tmptitle=$it618_crowd_lang['s858'];	
}

$name=$it618_crowd_sale['it618_name'];
if($name==''){
	$name=C::t('#it618_crowd#it618_crowd_sale')->fetch_name_by_uid($it618_crowd_sale['it618_uid']);
}

$tel=$it618_crowd_sale['it618_tel'];
if($tel==''){
	$tel=C::t('#it618_crowd#it618_crowd_sale')->fetch_tel_by_uid($it618_crowd_sale['it618_uid']);
}

$addr=$it618_crowd_sale['it618_addr'];
if($addr==''){
	$addr=C::t('#it618_crowd#it618_crowd_sale')->fetch_addr_by_uid($it618_crowd_sale['it618_uid']);
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:saleaddr');
?>