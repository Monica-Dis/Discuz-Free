<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid']);
$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);

$it618_code=$it618_crowd_sale['it618_code'];
$it618_pricecount=$it618_crowd_sale['it618_pricecount'];
$username=it618_crowd_getusername($it618_crowd_sale['it618_uid']);
$saleuser='<a href="'.it618_crowd_rewriteurl($it618_crowd_sale['it618_uid']).'" target="_blank">'.$username.'</a>';

$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];

$tmptime=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_time_by_saleid($_GET['saleid']);

$calabout=$it618_crowd_lang['s383'];
$calabout=str_replace("{time}",it618_crowd_getudate($tmptime),$calabout);

$n=0;
foreach(C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_all_by_time($tmptime,0,100) as $it618_crowd_crowdsale) {
	
	$it618_time=it618_crowd_getudate($it618_crowd_crowdsale['it618_time']);
	
	$tmparr=explode(" ",$it618_time);
	$tmptime=str_replace(":","",$tmparr[1]);
	$tmptime=str_replace(".","",$tmptime);
	
	$username=it618_crowd_getusername($it618_crowd_crowdsale['it618_uid']);
	$buyuser='<a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale['it618_uid']).'" target="_blank">'.$username.'</a>';
	
	$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($it618_crowd_crowdsale['it618_saleid']);
	$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_crowdsale['it618_pid']);
	
	$pnametmp='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
	
	if($_GET['wap']!=1){
		$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
		
		$callist.='<tr>
				<td width="150">'.$it618_time.'</td>
				<td width="80" style="color:#f60;font-weight:bold">'.$tmptime.'</td>
				<td width="100">'.$buyuser.'</td>
				<td width="60">'.$it618_crowd_crowdsale['it618_count'].$it618_crowd_lang['s13'].'</td>
				<td><a href="'.$tmpurl.'" target="_ablank">'.$pnametmp.'</a></td>
			   </tr>';
	}else{
		$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
		
		$callist.='<tr>
				<td><span style="color:#f60;font-weight:bold">'.$tmptime.'</span> '.$it618_time.' '.$buyuser.' '.$it618_crowd_crowdsale['it618_count'].$it618_crowd_lang['s13'].'</td>
				</tr>
				<tr>
				<td><div style="overflow:hidden;height:13px;width:100%"><a href="'.$tmpurl.'" target="_ablank">'.$pnametmp.'</a></div></td>
			   </tr>';
	}
	
	$timesum=$timesum+$tmptime;
			   
	$n=$n+1;
}

$it618_code1=$timesum%$it618_pricecount+10000001;

$calabout=str_replace("{count}",$n,$calabout);

$callist='<table class="salecal">'.$callist.'</table>';

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:salecal');
?>