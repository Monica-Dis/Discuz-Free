<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:js');
?>