<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($it618_crowd['crowd_computer']==1){
	if(!crowd_is_mobile()){
		dheader("location:$crowd_home");
	}
}

if($topmiddle!='')$topmiddle=it618_crowd_getlang('s833');
$navtitle=$topmiddle=it618_crowd_getlang('s833');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_crowd_getlang('s835');
}

if($error==1){
	$topmiddle=$it618_crowd_lang['s105'];
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_crowd:wap_crowd');
	return;
}

global $oss;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/php/aliyunossconfig.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/php/aliyunossconfig.php';
	if($it618_isok==1){
		$oss='&oss';
	}
}

$pjpicjs='<link rel="stylesheet" href="source/plugin/it618_crowd/kindeditor/themes/default/default.css" />
			<script src="source/plugin/it618_crowd/kindeditor/kindeditor-min.js?v3.9" charset="utf-8"></script>
			<script src="source/plugin/it618_crowd/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:wap_crowd');
?>