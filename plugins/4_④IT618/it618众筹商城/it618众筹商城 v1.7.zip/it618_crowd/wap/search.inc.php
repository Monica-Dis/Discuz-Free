<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cid=intval($_GET['cid']);
if($it618_crowd['crowd_computer']==1){
	if(!crowd_is_mobile()){ 
		if($cid>0){
			$tmpurl=it618_crowd_getrewrite('crowd_list',$cid,'plugin.php?id=it618_crowd:list&class1='.$cid);
		}else{
			$tmpurl=it618_crowd_getrewrite('crowd_list','','plugin.php?id=it618_crowd:list');
		}
		dheader("location:$tmpurl");
	}
}

if($topmiddle!='')$topmiddle=$it618_crowd_lang['t317'];
$navtitle=$topmiddle.' - '.$sitetitle;


$n=1;
if($cid>0){
	$current='';
}else{
	$current='class="current"';
}
$classtmp='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'productclass1\',0,0)" name="productclass1"><span>'.$it618_crowd_lang['s466'].'</span><i></i></a>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	if($it618_tmp['id']==$cid){
		$current='class="current"';
		$classjs='setselect(\'productclass1\','.$n.','.$it618_tmp['id'].');';
	}else{
		$current='';
	}
	$classtmp.='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'productclass1\','.$n.','.$it618_tmp['id'].')" name="productclass1"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
	$n=$n+1;
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:wap_crowd');
?>