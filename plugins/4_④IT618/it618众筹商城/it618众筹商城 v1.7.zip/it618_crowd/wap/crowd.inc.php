<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($it618_crowd['crowd_computer']==1){
	if(!crowd_is_mobile()){ 
		$tmpurl=it618_crowd_getrewrite('crowd_home','','plugin.php?id=it618_crowd:index');
		dheader("location:$tmpurl");
	}
}

foreach(C::t('#it618_crowd#it618_crowd_focus')->fetch_all_by_type_order(17) as $it618_crowd_focus) {
	if($it618_crowd_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_crowd_focus['it618_url'].'" target="_blank"><img class="img" src="'.it618_crowd_getwapppic('wapad',$it618_crowd_focus['id'],$it618_crowd_focus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_crowd_getwapppic('wapad',$it618_crowd_focus['id'],$it618_crowd_focus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_crowd_gonggao = DB::fetch($query)) {
	$it618_title=$it618_crowd_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_crowd_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_crowd_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_crowd_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_crowd_gonggao['it618_url'].'" title="'.$it618_crowd_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_crowd_iconav = DB::fetch($query)) {
	$it618_title=$it618_crowd_iconav['it618_title'];
	
	if($it618_crowd_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_crowd_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_crowd_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_crowd_iconav['it618_color'].'">'.$it618_title.'</font>';
	}

	$str_iconav.='<td width="25%"><a href="'.$it618_crowd_iconav['it618_url'].'"'.$it618_target.'><img src="'.$it618_crowd_iconav['it618_img'].'"/><br>'.$it618_title.'</a></td>';
	
	if($n%8==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav">';
	if($n%4==0)$str_iconav.='</tr><tr>';
	
	$isiconav=1;

	$n=$n+1;
}

for($i=1;$i<=$n%4;$i++){
	$str_iconav.='<td width="25%"></td>';
}
$str_iconav.='</tr>';
$str_iconav=str_replace('<tr><td width="25%"></td></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"></tr></table></div>','',$str_iconav);

$zjsalegoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('weeksalegoods');
$newgoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('newgoods');
$hotgoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('hotgoods');
$waphomead=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('waphomead');

$tmparr=explode(",",$zjsalegoods);
if(count($tmparr)>2){
	$zjsalegoods_count=$tmparr[1];
	$zjsalegoods_order=$tmparr[2];
}else{
	$zjsalegoods_count=8;
	$zjsalegoods_order=1;
}

$tmparr=explode(",",$weeksalegoods);
if(count($tmparr)>2){
	$weeksalegoods_count=$tmparr[1];
	$weeksalegoods_order=$tmparr[2];
}else{
	$weeksalegoods_count=8;
	$weeksalegoods_order=2;
}

$tmparr=explode(",",$newgoods);
if(count($tmparr)>2){
	$newgoods_count=$tmparr[1];
	$newgoods_order=$tmparr[2];
}else{
	$newgoods_count=8;
	$newgoods_order=3;
}

$tmparr=explode(",",$hotgoods);
if(count($tmparr)>2){
	$hotgoods_count=$tmparr[1];
	$hotgoods_order=$tmparr[2];
}else{
	$hotgoods_count=8;
	$hotgoods_order=4;
}

$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newgoods"=>$newgoods_order,"hotgoods"=>$hotgoods_order);
asort($homegoods_arr);

$n=1;
foreach($homegoods_arr as $key=>$homegoods){
	if($n==1)$current=' class="current" style="margin-left:6px" ';else $current=' ';
	if($home_goods_js=='')$home_goods_js='get_home_goods("'.$key.'");';
	if($key=='zjsalegoods'){
		$tab_goods.='<li'.$current.'onclick="it618_crowd_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_crowd_lang['t91'].'</li>';
	}
	
	if($key=='weeksalegoods'){
		$tab_goods.='<li'.$current.'onclick="it618_crowd_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_crowd_lang['t93'].'</li>';
	}
	
	if($key=='newgoods'){
		$tab_goods.='<li'.$current.'onclick="it618_crowd_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_crowd_lang['s989'].'</li>';
	}
	
	if($key=='hotgoods'){
		$tab_goods.='<li'.$current.'onclick="it618_crowd_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_crowd_lang['s990'].'</li>';
	}
	
	$tmpurl=it618_crowd_getrewrite('crowd_wap','search@0','plugin.php?id=it618_crowd:wap&pagetype=search&cid=0');
	if($n==1)$bdstyle=' ;display:';else $bdstyle=' ;display:none';
	$home_goods.='<dl class="list" id="searchli_bd'.($n-1).'" style="border-top:none; margin:0;'.$bdstyle.'">
					<dd><dl style="padding:0">
						<dd>
						<table width="100%" class="tablelist'.$crowdstyle.'" id="home_goods_'.$key.'"></table>
						<div class="wapmore"><a href="'.$tmpurl.'">'.it618_crowd_getlang('t273').'&gt;&gt;</a></div>
						</dd>
					</dl></dd>
				  </dl>';
	
	$n=$n+1;
}

$homegoods_str='<ul class="searchli">'.$tab_goods.'</ul><div id="home_goods">'.$home_goods.'</div><script>'.$home_goods_js.'</script>';

$allproductlist=it618_crowd_getrewrite('crowd_wap','product_list@0','plugin.php?id=it618_crowd:wap&pagetype=product_list&cid=0');

$hotclassgoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('hotclassgoods');
$hotclassgoods=explode('@@@',$hotclassgoods);
$tmpidsarr=explode(',',$hotclassgoods[2]);
$tdn=1;

for($i=1;$i<=count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i-1]);
	$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($id);
	if($it618_crowd_goods['it618_state']==1) {
			
		$pj=$it618_crowd_goods['it618_pjpfstr'];
		
		$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
				
		if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
			$pricecount=$it618_crowd_sale['it618_pricecount'];
			$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
			$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_sale['it618_price'];
		}else{
			$pricecount=$it618_crowd_goods['it618_pricecount'];
			$pricecount1=0;
			$pricecount2=$pricecount;
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_goods['it618_price'];
			
			if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
			}
		}
		
		$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
		
		$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);

		if($crowdstyle=='1'){
			$views=' '.it618_crowd_getlang('s118').''.$it618_crowd_goods['it618_views'];
		
			$it618goods_hot.='<tr>
							<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"/></a></td>
							<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
								<div class="tdname">'.$it618_name.'</div>
								<div class="tddes">'.$pj.' '.$views.'</div>
								<ul class="tdprice">
								  <li>
									<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
									<p class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></p>
									<table class="graphtable"><tr>
									<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
									<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
									<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
									</tr></table>
								  </li>
								</ul>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr1='<tr class="trimg">';
				$trtmpstr2='<tr class="trabout">';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr1.='<td '.$tdstr.'><a href="'.$tmpurl.'">
							<img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"/>
						</a></td>';
			
			$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
							<div class="tdname">'.$it618_name.'</div>
							<div class="tddes">'.$pj.'</div>
							<div class="tdprice">
								<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
								<p class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></p>
								<table class="graphtable"><tr>
								<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
								<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
								<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
								</tr></table>
							</div>
						</a></td>';
						
			if($tdn%2==0){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$it618goods_hot.=$trtmpstr1.$trtmpstr2;
			}
			
			$tdn=$tdn+1;
		}
	}
}

if($crowdstyle=='1'){
	$tmparr=explode('</tr>',$it618goods_hot);
	if(count($tmparr)>1){
		$it618goods_hot=$it618goods_hot.'@@@';
		$it618goods_hot=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$it618goods_hot);
	}
}else{
	$trtmpstr=$trtmpstr1.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr);
	if(count($tmparr)>1){
		$trtmpstr1.='</tr>';
		$trtmpstr2.='</tr>';
		$it618goods_hot.=$trtmpstr1.$trtmpstr2;
	}
}

$tmpurl=it618_crowd_getrewrite('crowd_wap','search@0','plugin.php?id=it618_crowd:wap&pagetype=search&cid=0');
$it618goods_hot='<dl class="list">
					<dd><dl style="padding:0">
						<dt><span>'.$it618_crowd_lang['t314'].'</span><img src="source/plugin/it618_crowd/wap/images/collapsed_no.gif" id="img_goods_hot" onClick="collapsed(\'dd_goods_hot\',\'img_goods_hot\')" class="collapsed"></dt>
						<dd id="dd_goods_hot">
						<table width="100%" class="tablelist'.$crowdstyle.'">
							'.$it618goods_hot.'
						</table>
						<div class="wapmore"><a href="'.$tmpurl.'">'.it618_crowd_getlang('t273').'&gt;&gt;</a></div>
						</dd>
					</dl></dd>
				</dl>';

$query1 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
while($it618_crowd_class1 = DB::fetch($query1)) {
	if($it618_crowd_class1['it618_wapgoodscount']!=0){
		$it618goods='';$tdn=1;
		foreach(C::t('#it618_crowd#it618_crowd_goods')->fetch_all_by_search(
			'it618_state=1','jiexiao',$it618_crowd_class1['id'],0,'',0,0,$startlimit,$it618_crowd_class1['it618_wapgoodscount']
		) as $it618_crowd_goods) {
		
			$pj=$it618_crowd_goods['it618_pjpfstr'];
			
			$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
				
			if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
				$pricecount=$it618_crowd_sale['it618_pricecount'];
				$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
				$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
				$pricecountbl=$pricecount1/$pricecount*100;
				$price=$it618_crowd_sale['it618_price'];
			}else{
				$pricecount=$it618_crowd_goods['it618_pricecount'];
				$pricecount1=0;
				$pricecount2=$pricecount;
				$pricecountbl=$pricecount1/$pricecount*100;
				$price=$it618_crowd_goods['it618_price'];
				
				if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
					DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
				}
			}
			
			$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
			
			$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
			
			if($crowdstyle=='1'){
				$views=' '.it618_crowd_getlang('s118').''.$it618_crowd_goods['it618_views'];
			
				$it618goods.='<tr>
								<td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_name.'</div>
									<div class="tddes">'.$pj.' '.$views.'</div>
									<ul class="tdprice">
									  <li>
									    <span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
										<p class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></p>
										<table class="graphtable"><tr>
										<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
										<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
										<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
										</tr></table>
									  </li>
									</ul>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
			}else{
				if($tdn%2>0){
					$trtmpstr1='<tr class="trimg">';
					$trtmpstr2='<tr class="trabout">';
					$tdstr='class="tdleft"';
				}else{
					$tdstr='class="tdright"';
				}
				
				$trtmpstr1.='<td '.$tdstr.'><a href="'.$tmpurl.'">
								<img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"/>
							</a></td>';
				
				$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
							<div class="tdname">'.$it618_name.'</div>
							<div class="tddes">'.$pj.'</div>
							<div class="tdprice">
								<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
								<p class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></p>
								<table class="graphtable"><tr>
								<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
								<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
								<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
								</tr></table>
							</div>
						</a></td>';
							
				if($tdn%2==0){
					$trtmpstr1.='</tr>';
					$trtmpstr2.='</tr>';
					$it618goods.=$trtmpstr1.$trtmpstr2;
				}
				
				$tdn=$tdn+1;
			}
		}
	
		if($crowdstyle=='1'){
			$tmparr=explode('</tr>',$it618goods);
			if(count($tmparr)>1){
				$it618goods=$it618goods.'@@@';
				$it618goods=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$it618goods);
			}
		}else{
			$trtmpstr=$trtmpstr1.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr);
			if(count($tmparr)>1){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$it618goods.=$trtmpstr1.$trtmpstr2;
			}
		}
			
			$tmpurl=it618_crowd_getrewrite('crowd_wap','search@'.$it618_crowd_class1['id'],'plugin.php?id=it618_crowd:wap&pagetype=search&cid='.$it618_crowd_class1['id']);
			$str_goods.='<dl class="list">
							<dd><dl style="padding:0">
								<dt><span>'.$it618_crowd_class1['it618_classname'].$it618_crowd_lang['t103'].'</span><img src="source/plugin/it618_crowd/wap/images/collapsed_no.gif" id="img_goods'.$it618_crowd_class1['id'].'" onClick="collapsed(\'dd_goods'.$it618_crowd_class1['id'].'\',\'img_goods'.$it618_crowd_class1['id'].'\')" class="collapsed"></dt>
								<dd id="dd_goods'.$it618_crowd_class1['id'].'">
								<table width="100%" class="tablelist'.$crowdstyle.'">
									'.$it618goods.'
								</table>
								<div class="wapmore"><a href="'.$tmpurl.'">'.it618_crowd_getlang('s993').$it618_crowd_class1['it618_classname'].it618_crowd_getlang('s994').'&gt;&gt;</a></div>
								</dd>
							</dl></dd>
						</dl>';
	}

}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:wap_crowd');
?>