<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cid=intval($_GET['cid']);
if($it618_crowd['crowd_computer']==1){
	if(!crowd_is_mobile()){ 
		$tmpurl=it618_crowd_getrewrite('crowd_sale','','plugin.php?id=it618_crowd:sale');
		dheader("location:$tmpurl");
	}
}

$class1=intval($_GET['cid']);

$it618sql="s.it618_code!=''";


if($class1==0)$current=' class="current"';else $current='';
$tmpurl=it618_crowd_getrewrite('crowd_wap','sale','plugin.php?id=it618_crowd:sale');
$salecount=C::t('#it618_crowd#it618_crowd_sale')->count_by_search($it618sql);
$str_class1.='<a href="'.$tmpurl.'"'.$current.'><span>'.it618_crowd_getlang('s466').'<font color=#999>'.$salecount.'</font></span><i></i></a>';
$salediv=it618_crowd_getlang('s466').'<font color=#999>'.$salecount.'</font>';

$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
while($it618_crowd_class1 = DB::fetch($query)) {
	$it618sql1=$it618sql.' and g.it618_class1_id='.$it618_crowd_class1['id'];
	$salecount=C::t('#it618_crowd#it618_crowd_sale')->count_by_search($it618sql1);
	if($class1==$it618_crowd_class1['id']){$current=' class="current"';$salediv=$it618_crowd_class1['it618_classname'].'<font color=#999>'.$salecount.'</font>';}else $current='';
	
	$tmpurl=it618_crowd_getrewrite('crowd_wap','sale@'.$it618_crowd_class1['id'].'@1','plugin.php?id=it618_crowd:wap&pagetype=sale&cid='.$it618_crowd_class1['id'].'&page=1');
	$str_class1.='<a href="'.$tmpurl.'"'.$current.'><span>'.$it618_crowd_class1['it618_classname'].'<font color=#999>'.$salecount.'</font></span><i></i></a>';
}

if($class1>0){
	$class1name=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($class1);
	$classtitle.=$class1name.' ';
	
	$it618sql.=' and g.it618_class1_id='.$class1;
}

$ppp=20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$count = C::t('#it618_crowd#it618_crowd_sale')->count_by_search($it618sql);

if($count<=$ppp){
	$pagecount=1;
}else{
	$pagecount=ceil($count/$ppp);
}

if($pagecount>1){
	$n=1;
	while($n<=$pagecount){
		$tmpurl=it618_crowd_getrewrite('crowd_wap','sale@'.$class1.'@'.$n,'plugin.php?id=it618_crowd:wap&pagetype=sale&cid='.$class1.'&page='.$n);
		if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
		$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
		$n=$n+1;
	}
	$curpage='<select class="pageselect" onchange="location.href=this.value">'.$curpage.'</select>';
	if(lang('plugin/it618_crowd', $it618_crowd_lang['it618'])!=$it618_crowd_lang['version'])return;
	if($page==1){
		$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s510').'</a>';
		if($pagecount>1){
			$tmpurl=it618_crowd_getrewrite('crowd_wap','sale@'.$class1.'@2','plugin.php?id=it618_crowd:wap&pagetype=sale&cid='.$class1.'&page=2');
			$pagenext='<a href="'.$tmpurl.'" class="btn btn-weak">'.it618_crowd_getlang('s511').'</a>';
		}else{
			$pagenext='<a class="btn btn-weak btn-disabled">'.it618_crowd_getlang('s511').'</a>';
		}
	}elseif($page<$pagecount){
		$tmpurl=it618_crowd_getrewrite('crowd_wap','sale@'.$class1.'@'.($page-1),'plugin.php?id=it618_crowd:wap&pagetype=sale&cid='.$class1.'&page='.($page-1));
		$pagepre='<a href="'.$tmpurl.'" class="btn btn-weak">'.it618_crowd_getlang('s510').'</a>';
		$tmpurl=it618_crowd_getrewrite('crowd_wap','sale@'.$class1.'@'.($page+1),'plugin.php?id=it618_crowd:wap&pagetype=sale&cid='.$class1.'&page='.($page+1));
		$pagenext='<a href="'.$tmpurl.'" class="btn btn-weak">'.it618_crowd_getlang('s511').'</a>';
	}else{
		$tmpurl=it618_crowd_getrewrite('crowd_wap','sale@'.$class1.'@'.($page-1),'plugin.php?id=it618_crowd:wap&pagetype=sale&cid='.$class1.'&page='.($page-1));
		$pagepre='<a href="'.$tmpurl.'" class="btn btn-weak">'.it618_crowd_getlang('s510').'</a>';
		$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_crowd_getlang('s511').'</a>';
	}
	$multipage=$pagepre.' '.$curpage.' '.$pagenext;
}

if($_G['cache']['plugin']['it618_crowd']['rewriteurl']==1&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php')){
	$isrewrite=1;
}

foreach(C::t('#it618_crowd#it618_crowd_sale')->fetch_all_by_search(
	$it618sql,'s.it618_time desc','',0,'','',$startlimit,$ppp
) as $it618_crowd_sale) {
	
	$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
	$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
	$jfname=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
	$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id'].'&saleid='.$it618_crowd_sale['id']);
	if($isrewrite==1)$tmpurl=$tmpurl.'?saleid='.$it618_crowd_sale['id'];
	
	$sumcont=C::t('#it618_crowd#it618_crowd_crowdsale')->sumcount_by_saleid_uid($it618_crowd_sale['id'],$it618_crowd_sale['it618_uid']);
	$groupsum=C::t('#it618_crowd#it618_crowd_crowdsale_group')->get_groupsum_by_uid($it618_crowd_sale['it618_uid']);
				
	$str_salelist.='<tr>
					  <td class="tdleft"><a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"/></a></td>
					  <td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
						  <table class="tablesalelist">
						  	<tr>
							<td class="liavatar"><a href="'.it618_crowd_rewriteurl($it618_crowd_sale['it618_uid']).'"><img src="'.it618_crowd_discuz_uc_avatar($it618_crowd_sale['it618_uid'],'small').'"></a></td>
							<td class="liuser">'.$it618_crowd_lang['s471'].'<a href="'.it618_crowd_rewriteurl($it618_crowd_sale['it618_uid']).'">'.it618_crowd_getusername($it618_crowd_sale['it618_uid']).'</a></li>
							<br>'.$it618_crowd_lang['s472'].'<font color=red>'.$groupsum.'</font>
							<br>'.$it618_crowd_lang['s473'].'<font color=#f60>'.$it618_crowd_sale['it618_code'].'</font>
							<br>'.$it618_crowd_lang['s474'].'<font color=#f60>'.$sumcont.'</font>'.$it618_crowd_lang['s13'].'</td>
							</tr>
							<tr><td colspan="2" class="lipname"><a class="goods-name" href="'.$tmpurl.'" title="'.$pname.'">'.$pname.'</a></td></tr>
							<tr><td colspan="2" class="lipinfo">'.$it618_crowd_lang['s475'].''.($it618_crowd_sale['it618_price']*$it618_crowd_sale['it618_pricecount']).'</font>'.$jfname.'</td></tr>
							<tr><td colspan="2" class="lipinfo">'.$it618_crowd_lang['s476'].''.$it618_crowd_sale['it618_pricecount'].$it618_crowd_lang['s13'].'</td></tr>
							<tr><td colspan="2" class="lipinfo">'.$it618_crowd_lang['s477'].''.date('Y-m-d H:i:s', $it618_crowd_sale['it618_time']).'</td></tr>
							<tr><td colspan="2" class="lipbtn"><a href="'.$tmpurl.'">'.$it618_crowd_lang['s478'].'</a></td></tr>
						  </table>
					  </td>
					</tr>
					<tr><td colspan="2" class="tdcolspan"></td></tr>';
}

$tmparr=explode('</tr>',$str_salelist);
if(count($tmparr)>1){
	$str_salelist=$str_salelist.'@@@';
	$str_salelist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$str_salelist);
}

if($classtitle!='')$classtitle=$classtitle.'- ';
$topmiddle=$classtitle.$it618_crowd_lang['t50'];
$navtitle=$topmiddle.' - '.$sitetitle;

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:wap_crowd');
?>