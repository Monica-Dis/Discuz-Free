<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($it618_crowd['crowd_computer']==1){
	if(!crowd_is_mobile()){
		$tmpurl=it618_crowd_getrewrite('crowd_home','','plugin.php?id=it618_crowd:index');
		dheader("location:$tmpurl");
	}
}

if($topmiddle!='')$topmiddle=it618_crowd_getlang('s40');
$navtitle=it618_crowd_getlang('s40');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_crowd_getlang('s40');
}else{
	$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
	if(!in_array($_G['uid'],$crowd_adminuids)){
		$error=1;
		$errormsg=it618_crowd_getlang('s513');
	}
}

if($error==1){
	$topmiddle=$it618_crowd_lang['s105'];
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_crowd:wap_crowd');
	return;
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:wap_crowd');
?>