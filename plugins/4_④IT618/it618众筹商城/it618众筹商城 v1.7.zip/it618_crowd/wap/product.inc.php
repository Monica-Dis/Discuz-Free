<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pid=intval($_GET['cid']);
if($it618_crowd['crowd_computer']==1){
	if(!crowd_is_mobile()){ 
		$tmpurl=it618_crowd_getrewrite('crowd_product',$pid,'plugin.php?id=it618_crowd:product&pid='.$pid);
		dheader("location:$tmpurl");
	}
}

if(!($it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id_state($pid,1))){
	$error=1;
	$errormsg=it618_crowd_getlang('s470');
}

if($error==1){
	$topmiddle=$it618_crowd_lang['s105'];
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_crowd:wap_crowd');
	return;
}

C::t('#it618_crowd#it618_crowd_goods')->update_it618_views_by_id($pid);
$salecount = C::t('#it618_crowd#it618_crowd_sale')->count_by_it618_pid($pid);
if($it618_crowd_goods['it618_salecount']!=$salecount){
	C::t('#it618_crowd#it618_crowd_goods')->update_it618_salecount_by_id($pid,$salecount);
}

for($i=0;$i<=4;$i++){
	if($i==0){$tmpi='';$tmpcss=' class="firstimg curimg"';}else {$tmpi=$i;$tmpcss='';}
	$it618_picbig=$it618_crowd_goods['it618_picbig'.$tmpi];
	if($it618_picbig!=''){
		$goodspicbig.='<div class="swiper-slide"><img class="img" '.$sdbtn.' src="'.it618_crowd_getgoodspic($it618_crowd_goods['id'],$it618_picbig,$i).'" /></div>';
	}
}

if($it618_crowd_goods['it618_ptype']==2){
	$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_crowd_goods_km')." WHERE it618_pid=".$pid);
	if($it618_crowd_goods['it618_count']!=$kmcount)DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_count=$kmcount WHERE id=$pid");
}

$it618_message=$it618_crowd_goods['it618_message'];
$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img class="lazy" data-original="\1"/>',$it618_message);
$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="200" frameborder="0" allowfullscreen="1">',$it618_message);

$pjcount=C::t('#it618_crowd#it618_crowd_sale')->countpj_by_pid($it618_crowd_goods['id']);
if($pjcount>0){
	$pjname=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_pj_by_id($it618_crowd_goods['it618_class1_id']);
	$pjname=explode("_",$pjname);
	
	$pjscore=C::t('#it618_crowd#it618_crowd_sale')->fetch_sumpjscore_by_pid($it618_crowd_goods['id']);
	$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);
	$pjavgscore2=sprintf( "%.1f",$pjscore['score2']/$pjcount);
	$pjavgscore3=sprintf( "%.1f",$pjscore['score3']/$pjcount);
	$pjavgscore4=sprintf( "%.1f",$pjscore['score4']/$pjcount);
	$pjpl1=sprintf( "%.1f",$pjavgscore1/5*100);
	$pjpl2=sprintf( "%.1f",$pjavgscore2/5*100);
	$pjpl3=sprintf( "%.1f",$pjavgscore3/5*100);
	$pjpl4=sprintf( "%.1f",$pjavgscore4/5*100);
	
	$pj1_count1=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],1);
	$pj1_count2=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],2);
	$pj1_count3=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],3);
	$pj1_count4=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],4);
	$pj1_count5=C::t('#it618_crowd#it618_crowd_sale')->countpj1_by_pid_score($it618_crowd_goods['id'],5);
	
	$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
	
	$pj1_pl1=intval($pj1_count1/$pjcount*100);
	$pj1_pl2=intval($pj1_count2/$pjcount*100);
	$pj1_pl3=intval($pj1_count3/$pjcount*100);
	$pj1_pl4=intval($pj1_count4/$pjcount*100);
	$pj1_pl5=intval($pj1_count5/$pjcount*100);
	
	$pj=$pjcount.' '.it618_crowd_getlang('s482').' <strong>'.$pjavgscore1.'</strong> '.it618_crowd_getlang('s483').':'.$mydpl.'% ';
	$it618_pjpfstr=$pjcount.' '.it618_crowd_getlang('s482').' '.$pjavgscore1.' '.it618_crowd_getlang('s483').':'.$mydpl.'% ';
}else{
	$pj=it618_crowd_getlang('s484');	
	$it618_pjpfstr=it618_crowd_getlang('s484').' ';	
}

$pjpicjs='<link rel="stylesheet" href="source/plugin/it618_crowd/kindeditor/themes/default/default.css" />
			<script src="source/plugin/it618_crowd/kindeditor/kindeditor-min.js?v3.9" charset="utf-8"></script>
			<script src="source/plugin/it618_crowd/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';

DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pjpfstr='".$it618_pjpfstr."' WHERE id=$pid");

if($it618_crowd_shop['it618_kefuqq']!=''){
	$qqarr=explode(",",$it618_crowd_shop['it618_kefuqq']);
	$qqnamearr=explode(",",$it618_crowd_shop['it618_kefuqqname']);
	for($i=0;$i<count($qqarr);$i++)
	{
		if($qqarr[$i]!='')$shopqq.='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:'.$qqarr[$i].':52" align="absmiddle"/>'.$qqnamearr[$i].'</a> ';
		
		$shoprightqq.='<h3>'.$qqnamearr[$i].'</h3>
		<ul>
			<li><span>'.$it618_crowd_lang['s1060'].'</span>
			<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:'.$qqarr[$i].':51" align="absmiddle"/></a>
			</li>
		</ul>';
		
	}
}

$crowdid=$salecount+1;

$it618_pname='('.$it618_crowd_lang['s21'].$crowdid.$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
$pjfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
$price_sale=$it618_crowd_goods['it618_price_sale']*$it618_crowd_goods['it618_pricecount_sale'];

$crowdsalecount=0;
if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
	$pricecount=$it618_crowd_sale['it618_pricecount'];
	$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
	$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
	$pricecountbl=$pricecount1/$pricecount*100;
	$price=$it618_crowd_sale['it618_price'];
	$saleid=$it618_crowd_sale['id'];
}else{
	$pricecount=$it618_crowd_goods['it618_pricecount'];
	$pricecount1=0;
	$pricecount2=$pricecount;
	$pricecountbl=$pricecount1/$pricecount*100;
	$price=$it618_crowd_goods['it618_price'];
	$saleid=0;
	
	if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
		DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
	}
}

if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;

if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
	DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
}

$creditnum=0;
if($_G['uid']>0){
	$creditnum=DB::result_first("select extcredits".$it618_crowd_goods['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/jfbl.php';
	if($it618_jfbl[$it618_crowd_goods['it618_jfid']]<=0){
		$jfbl=1;
	}else{
		$jfbl=$it618_jfbl[$it618_crowd_goods['it618_jfid']];
	}
}else{
	$jfbl=1;
}

if($_GET['saleid']>0){
	$get_saleid=$_GET['saleid'];
	$get_crowdid=C::t('#it618_crowd#it618_crowd_sale')->fetch_crowdid_by_id($_GET['saleid']);
}

$class1name=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_name_by_id($it618_crowd_goods['it618_class1_id']);
$class2name=C::t('#it618_crowd#it618_crowd_class2')->fetch_it618_name_by_id($it618_crowd_goods['it618_class2_id']);
if($topmiddle!='')$topmiddle=$class1name.' '.$class2name;
$navtitle=$it618_pname.' - '.$sitetitle;

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:wap_crowd');
?>