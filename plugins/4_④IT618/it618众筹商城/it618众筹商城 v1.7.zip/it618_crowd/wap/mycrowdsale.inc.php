<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($it618_crowd['crowd_computer']==1){
	if(!crowd_is_mobile()){
		dheader("location:$crowd_home");
	}
}

if($topmiddle!='')$topmiddle=it618_crowd_getlang('s455');
$navtitle=$topmiddle=it618_crowd_getlang('s455');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_crowd_getlang('s455');
}

if($error==1){
	$topmiddle=$it618_crowd_lang['s105'];
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_crowd:wap_crowd');
	return;
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:wap_crowd');
?>