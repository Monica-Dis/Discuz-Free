<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($it618_crowd['crowd_computer']==1){
	if(!crowd_is_mobile()){
		$tmpurl=it618_crowd_getrewrite('crowd_gwc','','plugin.php?id=it618_crowd:gwc');
		dheader("location:$tmpurl");
	}
}

$uid = $_G['uid'];
if($uid<=0){
	$error=1;
}

if(isset($_GET['mysale'])){
	$mysale=1;
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/pay/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_crowd/pay/config.php';
}
if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/pay_wx/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_crowd/pay_wx/config.php';
}

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')==false)$iswx=0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config_wxapp.php';
}
if(strpos($_SERVER['HTTP_USER_AGENT'],'Appbyme')==true&&$wxapp_isok==1)$isappwx=1;

if($topmiddle!='')$topmiddle=it618_crowd_getlang('t187');
$navtitle=it618_crowd_getlang('t187').' - '.$sitetitle;

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:wap_crowd');
?>