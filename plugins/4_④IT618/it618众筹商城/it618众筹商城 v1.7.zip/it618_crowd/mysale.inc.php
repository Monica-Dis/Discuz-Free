<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

$mysaleurl=$_G['siteurl']."plugin.php?id=it618_crowd:ajax";

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:mysale');
?>