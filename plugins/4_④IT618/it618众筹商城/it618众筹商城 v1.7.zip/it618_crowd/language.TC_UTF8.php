<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_crowd_lang;

function it618_crowd_getlang($langid){
	global $it618_crowd_lang;
	return $it618_crowd_lang[$langid];
}

$it618_crowd_lang['version']='v1.7';
$it618_crowd_lang['s1'] = '熱門類別與商品';
$it618_crowd_lang['s2'] = '網站底部信息';
$it618_crowd_lang['s3'] = '頂部全局輪播';
$it618_crowd_lang['s4'] = '首頁右上輪播';
$it618_crowd_lang['s5'] = '首頁右下輪播';
$it618_crowd_lang['s6'] = '列表頁右下輪播';
$it618_crowd_lang['s7'] = '商品頁左下輪播';
$it618_crowd_lang['s8'] = '偽靜態設置';
$it618_crowd_lang['s9'] = '消息提醒設置';
$it618_crowd_lang['s10'] = '注意︰保存後價格積分類型不可修改，為了方便統計';
$it618_crowd_lang['s11'] = '注意︰每一期開始時，會自動記錄每份價格和份數的(同時也會記錄剩余次數)，這樣修改商品的價格份數只能在下期有效';
$it618_crowd_lang['s12'] = '當前價格/份數';
$it618_crowd_lang['s13'] = '人次';
$it618_crowd_lang['s14'] = '一級商品類別';
$it618_crowd_lang['s15'] = '二級商品類別';
$it618_crowd_lang['s16'] = '更新成功！';
$it618_crowd_lang['s17'] = '積分類型︰';
$it618_crowd_lang['s18'] = '返回首頁';
$it618_crowd_lang['s19'] = '提示︰1、保存或上架時每份價格與份數必須大于0 2、如果庫存為0時，會提示不能參與 3、如果眾籌開始了就不能下架';
$it618_crowd_lang['s20'] = '庫存:';
$it618_crowd_lang['s21'] = '第';
$it618_crowd_lang['s22'] = '期';
$it618_crowd_lang['s23'] = '更新';
$it618_crowd_lang['s24'] = '';
$it618_crowd_lang['s25'] = '查找';
$it618_crowd_lang['s26'] = '已參與';
$it618_crowd_lang['s27'] = '總需人次';
$it618_crowd_lang['s28'] = '剩余';
$it618_crowd_lang['s29'] = '文字顏色(無突出效果時要為空)';
$it618_crowd_lang['s30'] = '參與管理';
$it618_crowd_lang['s31'] = '會員名稱為紅色時表示是獲得者';
$it618_crowd_lang['s32'] = '參與會員';
$it618_crowd_lang['s33'] = '更新成功！(成功修改數:';
$it618_crowd_lang['s34'] = '成功添加數:';
$it618_crowd_lang['s35'] = '成功刪除數:';
$it618_crowd_lang['s36'] = '統計信息';
$it618_crowd_lang['s37'] = '！';
$it618_crowd_lang['s38'] = '警告︰以下內容有的需要結合編輯器的代碼模式(<font color=blue>代碼模式/內容模式 通過編輯器的第一個功能圖標切換</font>)修改，如果你對代碼不了解修改前請一定對內容進行備份！';
$it618_crowd_lang['s39'] = '參與記錄';
$it618_crowd_lang['s40'] = '揭曉管理';
$it618_crowd_lang['s41'] = '商品一級分類管理 <font color=red>(注意︰為了電腦版首頁界面一級分類最多有9個，不能刪除的，如果想不顯示哪個分類，就在以下哪個分類上傳圖片)</font>';
$it618_crowd_lang['s42'] = '按類別名稱';
$it618_crowd_lang['s43'] = '商品類別數︰';
$it618_crowd_lang['s44'] = '提示︰類別簡稱用于首頁右側的類別快捷導航，類別簡稱2個字表示類別，曬單評價評分名稱有4個，每個評分名稱用_下劃線隔開，<font color=blue>首頁推薦商家數為0時就是不顯示</font>';
$it618_crowd_lang['s45'] = '類別名稱';
$it618_crowd_lang['s46'] = '簡稱';
$it618_crowd_lang['s47'] = '曬單評價評分名稱(<font color=red>第一個評分名稱很重要</font>)';
$it618_crowd_lang['s48'] = '主題顏色';
$it618_crowd_lang['s49'] = '電腦版/手機版首推商家數';
$it618_crowd_lang['s50'] = '排序';
$it618_crowd_lang['s51'] = '在';
$it618_crowd_lang['s52'] = '提示︰推薦如果勾選會顯示在左側類別主菜單和首頁分類商品右上角';
$it618_crowd_lang['s53'] = '子類別數';
$it618_crowd_lang['s54'] = '商品數';
$it618_crowd_lang['s55'] = '商品二級分類管理';
$it618_crowd_lang['s56'] = '編號';
$it618_crowd_lang['s57'] = '類別1';
$it618_crowd_lang['s58'] = '類別2名稱';
$it618_crowd_lang['s59'] = '推薦';
$it618_crowd_lang['s60'] = '寬:';
$it618_crowd_lang['s61'] = '高:';
$it618_crowd_lang['s62'] = '輪播廣告數︰';
$it618_crowd_lang['s63'] = '注意︰排序值為0時表示圖片不顯示，數值越小越在前';
$it618_crowd_lang['s64'] = '圖片';
$it618_crowd_lang['s65'] = '圖片鏈接(為空時圖片不帶鏈接)';
$it618_crowd_lang['s66'] = '排序';
$it618_crowd_lang['s67'] = '上傳圖片';
$it618_crowd_lang['s68'] = '提交後再上傳圖片';
$it618_crowd_lang['s69'] = '注意︰以下分類與商品編號，多個時請用逗號隔開(如︰1,2,3,4,5)，並且設置順序就是顯示順序';
$it618_crowd_lang['s70'] = '首頁熱門商品分類編號︰';
$it618_crowd_lang['s71'] = '搜索頁熱門分類編號︰';
$it618_crowd_lang['s72'] = '首頁熱門商品編號︰';
$it618_crowd_lang['s73'] = '給自己發送短信(用自己的手機號到飛信官方注冊一個賬號，短信是免費的)';
$it618_crowd_lang['s74'] = '啟用短信提醒功能︰';
$it618_crowd_lang['s75'] = '在<font color=green>申請商家、交易成功、申請退款與申請提現</font>時會有短信提醒';
$it618_crowd_lang['s76'] = '手機號碼︰';
$it618_crowd_lang['s77'] = '有提醒時此手機號就會收到短信';
$it618_crowd_lang['s78'] = '此商品刪除成功！';
$it618_crowd_lang['s79'] = '購物車清空成功！';
$it618_crowd_lang['s80'] = '更新時發送一個測試短信';
$it618_crowd_lang['s81'] = '<font color=green>提示︰默認有短信寶接口，如果配合 <a href="http://addon.discuz.com/?@it618_members.plugin" target="_blank">it618會員短信微信</a> 可以有阿里大魚短信接口、阿里雲短信與接口微信消息接口</font>';
$it618_crowd_lang['s82'] = '啟用短信提醒功能︰';
$it618_crowd_lang['s83'] = '參與記錄';
$it618_crowd_lang['s84'] = '短信接口賬號︰';
$it618_crowd_lang['s85'] = '短信接口密碼︰';
$it618_crowd_lang['s86'] = '測試接收人手機號︰';
$it618_crowd_lang['s87'] = '多個手機號用英文字母逗號隔開';
$it618_crowd_lang['s88'] = '測試短信內容︰';
$it618_crowd_lang['s89'] = '提示︰可以利用發送測試短信功能，手工給多個手機發送短信';
$it618_crowd_lang['s90'] = '成功修改商品數︰';
$it618_crowd_lang['s91'] = '抱歉，參與{count}人次需要{jfcount}{jfname}，您現在只有{creditnum}{jfname}，請先充值積分！';
$it618_crowd_lang['s92'] = '確定要清空購物車？';
$it618_crowd_lang['s93'] = '確定要購買？點確定會批量購買購物車的商品！';
$it618_crowd_lang['s94'] = '按關鍵字';
$it618_crowd_lang['s95'] = '所有分類';
$it618_crowd_lang['s96'] = '商品管理';
$it618_crowd_lang['s97'] = '按關鍵詞';
$it618_crowd_lang['s98'] = '剩余人次';
$it618_crowd_lang['s99'] = '商品分類';
$it618_crowd_lang['s100'] = '所有分類';
$it618_crowd_lang['s101'] = '狀態';
$it618_crowd_lang['s102'] = '所有';
$it618_crowd_lang['s103'] = '下架';
$it618_crowd_lang['s104'] = '上架';
$it618_crowd_lang['s105'] = '提示';
$it618_crowd_lang['s106'] = '當前價格︰';
$it618_crowd_lang['s107'] = '當前份數︰';
$it618_crowd_lang['s108'] = '單價:';
$it618_crowd_lang['s109'] = '積分:';
$it618_crowd_lang['s110'] = '按即將揭曉';
$it618_crowd_lang['s111'] = '按揭曉排序';
$it618_crowd_lang['s112'] = '按人氣排序';
$it618_crowd_lang['s113'] = '按價格排序';
$it618_crowd_lang['s114'] = '商品數︰';
$it618_crowd_lang['s115'] = '商品名稱/簡潔描述';
$it618_crowd_lang['s116'] = '庫存/單位';
$it618_crowd_lang['s117'] = '有效時間';
$it618_crowd_lang['s118'] = '人氣︰';
$it618_crowd_lang['s119'] = '已揭︰';
$it618_crowd_lang['s120'] = '︰';
$it618_crowd_lang['s121'] = '每份價格/份數';
$it618_crowd_lang['s122'] = '狀態';
$it618_crowd_lang['s123'] = '排序';
$it618_crowd_lang['s124'] = '發布會員︰';
$it618_crowd_lang['s125'] = '元';
$it618_crowd_lang['s126'] = '限購';
$it618_crowd_lang['s127'] = '天';
$it618_crowd_lang['s128'] = '個';
$it618_crowd_lang['s129'] = '全選';
$it618_crowd_lang['s130'] = '修改以上排序';
$it618_crowd_lang['s131'] = '會員ID';
$it618_crowd_lang['s132'] = '刷新交易';
$it618_crowd_lang['s133'] = '導出查詢交易到CSV文件';
$it618_crowd_lang['s134'] = '會員ID';
$it618_crowd_lang['s135'] = '刷新參與';
$it618_crowd_lang['s136'] = 'URL 靜態化可以提高搜索引擎抓取，開啟本功能需要對 Web 服務器增加相應的 Rewrite 支持，且會輕微增加服務器負擔。同時您還可以調整每個頁面的靜態格式，但不得刪除其中的標記，重置靜態格式請留空。<br><font color=red>注意，修改靜態格式後您需要修改服務器的 Rewrite 規則設置，並且要把DZ默認的插件規則刪除或放最後一行，此插件規則才有效果</font>';
$it618_crowd_lang['s137'] = '靜態格式擴展名︰';
$it618_crowd_lang['s138'] = '頁面';
$it618_crowd_lang['s139'] = '標記';
$it618_crowd_lang['s140'] = '格式';
$it618_crowd_lang['s141'] = '商城首頁';
$it618_crowd_lang['s142'] = '商城商品列表頁';
$it618_crowd_lang['s143'] = '商城商品查找頁';
$it618_crowd_lang['s144'] = '商城商品頁';
$it618_crowd_lang['s145'] = '計算方法';
$it618_crowd_lang['s146'] = '首頁推薦文章管理';
$it618_crowd_lang['s147'] = '商城手機版頁';
$it618_crowd_lang['s148'] = 'Apache Web Server(獨立主機用戶)';
$it618_crowd_lang['s149'] = 'Apache Web Server(虛擬主機用戶)';
$it618_crowd_lang['s150'] = '# 將 RewriteEngine 模式打開
RewriteEngine On

# 修改以下語句中的 /discuz 為您的論壇目錄地址，如果程序放在根目錄中，請將 /discuz 修改為 /
RewriteBase /discuz

# Rewrite 系統規則請勿修改';
$it618_crowd_lang['s151'] = 'IIS Web Server(獨立主機用戶)';
$it618_crowd_lang['s152'] = 'IIS7 Web Server(獨立主機用戶)';
$it618_crowd_lang['s219'] = '交易號';
$it618_crowd_lang['s220'] = '商品名稱';
$it618_crowd_lang['s221'] = '參與人次';
$it618_crowd_lang['s222'] = '積分';
$it618_crowd_lang['s223'] = '狀態';
$it618_crowd_lang['s224'] = '揭曉會員';
$it618_crowd_lang['s225'] = '本期總參與人次︰';
$it618_crowd_lang['s226'] = '獲得者︰';
$it618_crowd_lang['s227'] = '';
$it618_crowd_lang['s228'] = '揭曉時間';
$it618_crowd_lang['s229'] = '揭曉數︰';
$it618_crowd_lang['s230'] = '';
$it618_crowd_lang['s294'] = '回復';
$it618_crowd_lang['s295'] = '回復評價';
$it618_crowd_lang['s339'] = '消息提醒設置更新成功！';
$it618_crowd_lang['s340'] = '！';
$it618_crowd_lang['s341'] = '在<font color=green>交易成功、提現成功、商品鎖定與商品解鎖</font>時會有短信提醒';
$it618_crowd_lang['s342'] = '成功刪除數︰';
$it618_crowd_lang['s343'] = '成功上架商品數︰';
$it618_crowd_lang['s344'] = '成功下架商品數︰';
$it618_crowd_lang['s345'] = '成功更新數︰';
$it618_crowd_lang['s346'] = '所有分類';
$it618_crowd_lang['s347'] = '';
$it618_crowd_lang['s348'] = '';
$it618_crowd_lang['s349'] = '商品管理';
$it618_crowd_lang['s350'] = '查找';
$it618_crowd_lang['s351'] = '編輯';
$it618_crowd_lang['s352'] = '刪除選中商品';
$it618_crowd_lang['s353'] = '確定要刪除選中商品？此操作不可逆。';
$it618_crowd_lang['s354'] = '修改以上商品';
$it618_crowd_lang['s355'] = '上架選中商品';
$it618_crowd_lang['s356'] = '確定要上架選中商品？';
$it618_crowd_lang['s357'] = '下架選中商品';
$it618_crowd_lang['s358'] = '確定要下架選中商品？';
$it618_crowd_lang['s359'] = '商品添加成功！';
$it618_crowd_lang['s360'] = '添加商品';
$it618_crowd_lang['s361'] = '請選擇商品分類！';
$it618_crowd_lang['s362'] = '注意︰保存後商品類型不可修改';
$it618_crowd_lang['s363'] = '在線客服信息';
$it618_crowd_lang['s364'] = '聯系地址';
$it618_crowd_lang['s365'] = '工作時間';
$it618_crowd_lang['s366'] = '熱線電話';
$it618_crowd_lang['s367'] = '客服職位︰';
$it618_crowd_lang['s368'] = '多個職位用逗號隔開，如︰銷售,采購,售後';
$it618_crowd_lang['s369'] = '客服QQ︰';
$it618_crowd_lang['s370'] = '客服微信︰';
$it618_crowd_lang['s371'] = '多個QQ或微信事情用逗號隔開，如︰111111,222222,333333';
$it618_crowd_lang['s372'] = '請上傳商品圖片！';
$it618_crowd_lang['s373'] = '';
$it618_crowd_lang['s374'] = '商品分類︰';
$it618_crowd_lang['s375'] = '請選擇商品一級分類';
$it618_crowd_lang['s376'] = '請選擇商品二級分類';
$it618_crowd_lang['s377'] = '';
$it618_crowd_lang['s378'] = '商品類型︰';
$it618_crowd_lang['s379'] = '商品類型';
$it618_crowd_lang['s380'] = '所有';
$it618_crowd_lang['s381'] = '實物';
$it618_crowd_lang['s382'] = '卡密';
$it618_crowd_lang['s383'] = '截至該商品最後支持時間【{time}】網站所有商品的最後{count}條支持時間(時、分、秒、毫秒)記錄';
$it618_crowd_lang['s384'] = '計算結果';
$it618_crowd_lang['s385'] = '以下';
$it618_crowd_lang['s386'] = '條時間取值之和';
$it618_crowd_lang['s387'] = '取余';
$it618_crowd_lang['s388'] = '總需參與人次';
$it618_crowd_lang['s389'] = '固定數值';
$it618_crowd_lang['s390'] = '總人次';
$it618_crowd_lang['s391'] = '以下時間總和';
$it618_crowd_lang['s392'] = '第';
$it618_crowd_lang['s393'] = '名';
$it618_crowd_lang['s394'] = '商品圖片︰';
$it618_crowd_lang['s395'] = '選擇圖片';
$it618_crowd_lang['s396'] = '刪除圖片';
$it618_crowd_lang['s397'] = '商品圖片在商品提交時會自動生成640*640的縮略圖，注意︰為了美觀請保證商品圖片寬高都大于640，並且寬高相同';
$it618_crowd_lang['s398'] = '商品列表頁的圖片';
$it618_crowd_lang['s399'] = '積分與經驗比率';
$it618_crowd_lang['s400'] = '經驗';
$it618_crowd_lang['s401'] = '說明︰如果不設置，積分比率默認為1，可以是大于0的整數或小數，參與記錄會記錄積分類型與積分比率，這樣可以知道每次參與可以增加多少經驗，計算後經驗值取整';
$it618_crowd_lang['s402'] = '積分類型';
$it618_crowd_lang['s403'] = '簡潔描述︰';
$it618_crowd_lang['s404'] = '詳細內容︰';
$it618_crowd_lang['s405'] = 'SEO關鍵詞︰';
$it618_crowd_lang['s406'] = 'SEO描述︰';
$it618_crowd_lang['s407'] = '保存';
$it618_crowd_lang['s408'] = '商品編輯成功！';
$it618_crowd_lang['s409'] = '編輯商品';
$it618_crowd_lang['s449'] = '天前';
$it618_crowd_lang['s450'] = '小時前';
$it618_crowd_lang['s451'] = '分鐘前';
$it618_crowd_lang['s452'] = '秒前';
$it618_crowd_lang['s453'] = '';
$it618_crowd_lang['s454'] = '';
$it618_crowd_lang['s455'] = '我的參與';
$it618_crowd_lang['s456'] = '我的眾籌';
$it618_crowd_lang['s457'] = '我的揭曉';
$it618_crowd_lang['s458'] = '發表新帖';
$it618_crowd_lang['s459'] = '帳戶設置';
$it618_crowd_lang['s460'] = '退出';
$it618_crowd_lang['s461'] = '登錄';
$it618_crowd_lang['s462'] = '注冊';
$it618_crowd_lang['s463'] = '您購買的';
$it618_crowd_lang['s464'] = '';
$it618_crowd_lang['s465'] = '已售';
$it618_crowd_lang['s466'] = '全部';
$it618_crowd_lang['s467'] = '查看更多';
$it618_crowd_lang['s468'] = '';
$it618_crowd_lang['s469'] = '';
$it618_crowd_lang['s470'] = '抱歉，您訪問的商品不存在！';
$it618_crowd_lang['s471'] = '獲得者︰';
$it618_crowd_lang['s472'] = '眾籌經驗︰';
$it618_crowd_lang['s473'] = '幸運眾籌碼︰';
$it618_crowd_lang['s474'] = '本期參與︰';
$it618_crowd_lang['s475'] = '商品價值︰';
$it618_crowd_lang['s476'] = '總需參與︰';
$it618_crowd_lang['s477'] = '揭曉時間︰';
$it618_crowd_lang['s478'] = '查看詳情';
$it618_crowd_lang['s479'] = '';
$it618_crowd_lang['s480'] = '';
$it618_crowd_lang['s481'] = '';
$it618_crowd_lang['s482'] = '評價';
$it618_crowd_lang['s483'] = '分 ';
$it618_crowd_lang['s484'] = '暫無曬單評價';
$it618_crowd_lang['s485'] = '抱歉，請先登錄！';
$it618_crowd_lang['s486'] = '抱歉，購買數量要大于0！';
$it618_crowd_lang['s487'] = '抱歉，此商品不存在！';
$it618_crowd_lang['s488'] = '現在充值積分？';
$it618_crowd_lang['s489'] = '';
$it618_crowd_lang['s490'] = '';
$it618_crowd_lang['s491'] = '';
$it618_crowd_lang['s492'] = '';
$it618_crowd_lang['s493'] = '';
$it618_crowd_lang['s494'] = '';
$it618_crowd_lang['s495'] = '';
$it618_crowd_lang['s496'] = '';
$it618_crowd_lang['s497'] = '';
$it618_crowd_lang['s498'] = '抱歉，交易失敗，請與管理員聯系！';
$it618_crowd_lang['s499'] = '';
$it618_crowd_lang['s500'] = '我要評價';
$it618_crowd_lang['s501'] = '分';
$it618_crowd_lang['s502'] = '評價:';
$it618_crowd_lang['s503'] = '';
$it618_crowd_lang['s504'] = '';
$it618_crowd_lang['s505'] = '金額:';
$it618_crowd_lang['s506'] = '';
$it618_crowd_lang['s507'] = '';
$it618_crowd_lang['s508'] = '狀態:';
$it618_crowd_lang['s509'] = '';
$it618_crowd_lang['s510'] = '上一頁';
$it618_crowd_lang['s511'] = '下一頁';
$it618_crowd_lang['s512'] = '保存成功！';
$it618_crowd_lang['s513'] = '抱歉，參數有誤！';
$it618_crowd_lang['s514'] = '';
$it618_crowd_lang['s515'] = '';
$it618_crowd_lang['s516'] = '曬單評價成功！';
$it618_crowd_lang['s517'] = '全部商品';
$it618_crowd_lang['s518'] = '按關鍵詞︰';
$it618_crowd_lang['s519'] = '搜 索';
$it618_crowd_lang['s520'] = '折';
$it618_crowd_lang['s521'] = '';
$it618_crowd_lang['s522'] = '';
$it618_crowd_lang['s523'] = '';
$it618_crowd_lang['s524'] = '';
$it618_crowd_lang['s525'] = '';
$it618_crowd_lang['s526'] = '';
$it618_crowd_lang['s527'] = '';
$it618_crowd_lang['s528'] = '';
$it618_crowd_lang['s529'] = '';
$it618_crowd_lang['s530'] = '';
$it618_crowd_lang['s531'] = '';
$it618_crowd_lang['s532'] = '';
$it618_crowd_lang['s533'] = '';
$it618_crowd_lang['s534'] = '';
$it618_crowd_lang['s535'] = '';
$it618_crowd_lang['s536'] = '';
$it618_crowd_lang['s537'] = '';
$it618_crowd_lang['s538'] = '';
$it618_crowd_lang['s539'] = '成功確認消費！';
$it618_crowd_lang['s540'] = '';
$it618_crowd_lang['s541'] = '';
$it618_crowd_lang['s542'] = '';
$it618_crowd_lang['s543'] = '';
$it618_crowd_lang['s544'] = '';
$it618_crowd_lang['s545'] = '';
$it618_crowd_lang['s546'] = '人氣:';
$it618_crowd_lang['s547'] = '已售';
$it618_crowd_lang['s548'] = '商品數:';
$it618_crowd_lang['s549'] = '';
$it618_crowd_lang['s550'] = '';
$it618_crowd_lang['s551'] = '';
$it618_crowd_lang['s552'] = '';
$it618_crowd_lang['s553'] = '';
$it618_crowd_lang['s554'] = '';
$it618_crowd_lang['s555'] = '';
$it618_crowd_lang['s556'] = '添加商品';
$it618_crowd_lang['s557'] = '編輯商品';
$it618_crowd_lang['s558'] = '管理商品';
$it618_crowd_lang['s559'] = '首頁設置';
$it618_crowd_lang['s597'] = '查找';
$it618_crowd_lang['s598'] = '按快遞公司名稱';
$it618_crowd_lang['s599'] = '快遞公司數量︰';
$it618_crowd_lang['s600'] = '快遞公司名稱';
$it618_crowd_lang['s601'] = '快遞公司官網鏈接';
$it618_crowd_lang['s602'] = '排序';
$it618_crowd_lang['s603'] = '發貨數';
$it618_crowd_lang['s607'] = '';
$it618_crowd_lang['s608'] = '個';
$it618_crowd_lang['s609'] = '';
$it618_crowd_lang['s610'] = '';
$it618_crowd_lang['s611'] = '啟用';
$it618_crowd_lang['s612'] = '消息提醒設置更新成功！';
$it618_crowd_lang['s613'] = '<strong>第三方短信接口，按短信條數收費，給第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注冊賬號並充值，然後填以下內容就可以了';
$it618_crowd_lang['s614'] = '啟用消息接口︰';
$it618_crowd_lang['s615'] = '如果不啟用，系統不會有消息提醒功能 <font color=blue>如果支持微信模板消息接口，微信模板ID不為空時，優先發微信模板消息，而不發短信</font>';
$it618_crowd_lang['s616'] = '短信接口賬號︰';
$it618_crowd_lang['s617'] = '短信接口密碼︰';
$it618_crowd_lang['s618'] = '測試接收人手機號︰';
$it618_crowd_lang['it618']='i11iili1i1ilili111ilil1111iililil11ililil111il11iilili11111111liilili1111ll1i1illii11';
$it618_crowd_lang['s619'] = '多個手機號用英文字母逗號隔開';
$it618_crowd_lang['s620'] = '測試短信內容︰';
$it618_crowd_lang['s621'] = '管理員手機號︰';
$it618_crowd_lang['s622'] = '如果不啟用，管理員不會有消息提醒';
$it618_crowd_lang['s623'] = '消息模板';
$it618_crowd_lang['s624'] = '注意︰消息模板只有在“啟用”狀態，才發送提醒消息，如果短信消息模板和微信消息模板都設置了，優先發送微信消息，發送成功了，就不發短信了，方便節省短信成本';
$it618_crowd_lang['s631'] = '<font color="green">揭曉成功時</font> - <font color=green>管理員消息模板</font>';
$it618_crowd_lang['s632'] = '<font color="#999999">示例︰會員${user}成為了${pname}的獲得者！<br>標簽說明︰{user}獲得者會員名，{pname}商品名稱帶期數</font>';
$it618_crowd_lang['s639'] = '<font color="green">揭曉成功時</font> - <font color=red>會員消息模板</font>';
$it618_crowd_lang['s640'] = '<font color="#999999">示例︰祝賀您成為了${pname}的獲得者！<br>標簽說明︰{user}獲得者會員名，{pname}商品名稱帶期數</font>';
$it618_crowd_lang['s641'] = '更新';
$it618_crowd_lang['s642'] = '更新時發送一個測試短信';
$it618_crowd_lang['s643'] = '<font color="green">商家發貨時</font> - <font color=red>會員消息模板</font>';
$it618_crowd_lang['s644'] = '<font color="#999999">示例︰您的${pname}已發貨，請在我的揭曉查看快遞信息！<br>標簽說明︰{user}獲得者會員名，{pname}商品名稱帶期數</font>';
$it618_crowd_lang['s645'] = 'QQ號:';
$it618_crowd_lang['s646'] = '微信:';
$it618_crowd_lang['s647'] = '注意︰此文章同時也會顯示在手機版首頁，排序為0時不顯示，<font color=blue>首頁只能顯示3個</font>';
$it618_crowd_lang['s648'] = '文章數︰';
$it618_crowd_lang['s649'] = '幸運獲得';
$it618_crowd_lang['s650'] = '【';
$it618_crowd_lang['s651'] = '】';
$it618_crowd_lang['s652'] = '';
$it618_crowd_lang['s653'] = '元';
$it618_crowd_lang['s654'] = '';
$it618_crowd_lang['s655'] = '';
$it618_crowd_lang['s656'] = '風格管理';
$it618_crowd_lang['s657'] = '風格數︰';
$it618_crowd_lang['s658'] = '搜索框、主導航與類別二級菜單顏色';
$it618_crowd_lang['s659'] = '主導航當前與鼠標移動顏色';
$it618_crowd_lang['s660'] = '默認風格';
$it618_crowd_lang['s661'] = '啟用,短信消息模板︰,短信消息模板ID︰,微信消息模板︰,微信消息模板ID︰';
$it618_crowd_lang['s662'] = '參數名稱';
$it618_crowd_lang['s663'] = '參數內容';
$it618_crowd_lang['s664'] = '提示︰最多支持9個微信消息模板參數，參數名稱比如是︰first,keyword1,keyword2,keyword3,...,remark，參數內容支持以上一個標簽或多個標簽';
$it618_crowd_lang['s665'] = '取消';
$it618_crowd_lang['s666'] = '保存';
$it618_crowd_lang['s667'] = '抱歉，如果參數名稱填寫了，就必須填寫參數內容！';
$it618_crowd_lang['s668'] = '';
$it618_crowd_lang['s669'] = '';
$it618_crowd_lang['s670'] = '';
$it618_crowd_lang['s671'] = '';
$it618_crowd_lang['s672'] = '';
$it618_crowd_lang['s673'] = '';
$it618_crowd_lang['s674'] = '';
$it618_crowd_lang['s675'] = '';
$it618_crowd_lang['s676'] = '查看';
$it618_crowd_lang['s677'] = '快遞保存成功！';
$it618_crowd_lang['s678'] = '';
$it618_crowd_lang['s679'] = '未設置收貨地址';
$it618_crowd_lang['s680'] = '參與了';
$it618_crowd_lang['s681'] = '的';
$it618_crowd_lang['s682'] = '消息提醒設置更新成功！';
$it618_crowd_lang['s683'] = '您申請的提現成功了，會有短信提醒';
$it618_crowd_lang['s684'] = '您的商品交易成功了，會有短信提醒';
$it618_crowd_lang['s685'] = '表示已開通，只要您開啟了短信提醒功能就會有短信提醒';
$it618_crowd_lang['s686'] = '管理員暫時還沒有開通短信接口功能！';
$it618_crowd_lang['s687'] = '消息提醒設置';
$it618_crowd_lang['s688'] = '系統短信提醒功能︰';
$it618_crowd_lang['s689'] = '啟用短信提醒功能︰';
$it618_crowd_lang['s690'] = '如果不開啟不會有短信提醒';
$it618_crowd_lang['s691'] = '手機號碼︰';
$it618_crowd_lang['s692'] = '有提醒時此手機號就會收到短信';
$it618_crowd_lang['s693'] = '更新';
$it618_crowd_lang['s694'] = '抱歉，您沒有商品管理權限，請與管理員聯系！';
$it618_crowd_lang['s695'] = '請選擇快遞公司！';
$it618_crowd_lang['s696'] = '請輸入快遞單號！';
$it618_crowd_lang['s697'] = '留言/發貨地址';
$it618_crowd_lang['s698'] = '請選擇快遞公司';
$it618_crowd_lang['s699'] = '快遞單號︰';
$it618_crowd_lang['s700'] = '保存';
$it618_crowd_lang['s701'] = '參與手機︰';
$it618_crowd_lang['s702'] = '查看留言/發貨地址';
$it618_crowd_lang['s703'] = '關閉';
$it618_crowd_lang['s704'] = '我有';
$it618_crowd_lang['s705'] = '，只用';
$it618_crowd_lang['s706'] = '購買需要';
$it618_crowd_lang['s707'] = '';
$it618_crowd_lang['s708'] = '快遞公司管理';
$it618_crowd_lang['s709'] = '';
$it618_crowd_lang['s710'] = '網站頂部導航';
$it618_crowd_lang['s712'] = '購買右邊分享';
$it618_crowd_lang['s713'] = '';
$it618_crowd_lang['s714'] = '';
$it618_crowd_lang['s715'] = '';
$it618_crowd_lang['s716'] = '排序';
$it618_crowd_lang['s717'] = '發貨數';
$it618_crowd_lang['s718'] = '';
$it618_crowd_lang['s719'] = '';
$it618_crowd_lang['s720'] = '';
$it618_crowd_lang['s721'] = '';
$it618_crowd_lang['s722'] = '買家確認收貨';
$it618_crowd_lang['s723'] = '';
$it618_crowd_lang['s724'] = '';
$it618_crowd_lang['s725'] = '';
$it618_crowd_lang['s726'] = '';
$it618_crowd_lang['s727'] = '';
$it618_crowd_lang['s728'] = '交易成功';
$it618_crowd_lang['s729'] = '';
$it618_crowd_lang['s730'] = '如果開通了短信提醒，會收到短信';
$it618_crowd_lang['s769'] = '確認收貨';
$it618_crowd_lang['s770'] = '';
$it618_crowd_lang['s771'] = '';
$it618_crowd_lang['s772'] = '';
$it618_crowd_lang['s773'] = '';
$it618_crowd_lang['s774'] = '';
$it618_crowd_lang['s775'] = '配送︰';
$it618_crowd_lang['s776'] = '現在評價';
$it618_crowd_lang['s777'] = '';
$it618_crowd_lang['s778'] = '';
$it618_crowd_lang['s779'] = '成功確認收貨，現在可以給此次曬單評價！';
$it618_crowd_lang['s780'] = '';
$it618_crowd_lang['s781'] = '';
$it618_crowd_lang['s782'] = '';
$it618_crowd_lang['s783'] = '買家給我的留言';
$it618_crowd_lang['s784'] = '給買家發貨';
$it618_crowd_lang['s785'] = '發貨';
$it618_crowd_lang['s786'] = '修改';
$it618_crowd_lang['s787'] = '查看';
$it618_crowd_lang['s788'] = '原因';
$it618_crowd_lang['s789'] = '';
$it618_crowd_lang['s790'] = '抱歉，此會員還沒有參與過一次眾籌！';
$it618_crowd_lang['s791'] = '抱歉，會員不存在！';
$it618_crowd_lang['s792'] = '買家收貨地址';
$it618_crowd_lang['s793'] = '';
$it618_crowd_lang['s794'] = '';
$it618_crowd_lang['s795'] = '價格︰';
$it618_crowd_lang['s796'] = '數量︰';
$it618_crowd_lang['s797'] = '金額︰';
$it618_crowd_lang['s798'] = '';
$it618_crowd_lang['s799'] = '給買家發貨';
$it618_crowd_lang['s800'] = '金額';
$it618_crowd_lang['s829'] = '';
$it618_crowd_lang['s830'] = '';
$it618_crowd_lang['s831'] = '新增';
$it618_crowd_lang['s832'] = '我的';
$it618_crowd_lang['s833'] = '我的揭曉';
$it618_crowd_lang['s834'] = '揭曉管理';
$it618_crowd_lang['s835'] = '抱歉，請先登錄！';
$it618_crowd_lang['s836'] = '';
$it618_crowd_lang['s837'] = '卡密管理';
$it618_crowd_lang['s838'] = '商品庫存︰';
$it618_crowd_lang['s839'] = '商品名稱︰';
$it618_crowd_lang['s840'] = '';
$it618_crowd_lang['s841'] = '';
$it618_crowd_lang['s842'] = '商城最新揭曉頁';
$it618_crowd_lang['s843'] = '要導入的記事本文件不存在！';
$it618_crowd_lang['s844'] = '成功批量導入卡密數︰';
$it618_crowd_lang['s845'] = '成功清空此商品卡密！';
$it618_crowd_lang['s846'] = '卡密管理';
$it618_crowd_lang['s847'] = '卡密數量︰';
$it618_crowd_lang['s848'] = '清空';
$it618_crowd_lang['s849'] = '此操作不可逆，確定要清空此商品所有的卡密？';
$it618_crowd_lang['s850'] = '<strong>添加方式一︰</strong>直接把卡密復制到下面文本框內，一行一個卡密';
$it618_crowd_lang['s851'] = '<strong>添加方式二︰</strong>直接導入有卡密的記事本txt文件，記事本內一行一個卡密';
$it618_crowd_lang['s852'] = '批量添加';
$it618_crowd_lang['s853'] = '上傳文件';
$it618_crowd_lang['s854'] = '批量導入';
$it618_crowd_lang['s855'] = '商品名稱︰';
$it618_crowd_lang['s856'] = '返回商品列表';
$it618_crowd_lang['s857'] = '成功批量添加卡密數︰';
$it618_crowd_lang['s858'] = '修改收貨地址';
$it618_crowd_lang['s859'] = '多個QQ用逗號隔開 如︰123456,234567';
$it618_crowd_lang['s860'] = '客服職位';
$it618_crowd_lang['s861'] = '多個職位用逗號隔開 如︰銷售,采購 請注意如果是多個時和上面的QQ的個數與順序對應好';
$it618_crowd_lang['s862'] = '參與會員';
$it618_crowd_lang['s863'] = '收貨地址';
$it618_crowd_lang['s864'] = '抱歉，此商品沒有庫存了，請與管理員聯系！';
$it618_crowd_lang['s865'] = '查看卡密';
$it618_crowd_lang['s866'] = '給買家發貨';
$it618_crowd_lang['s867'] = '買家留言';
$it618_crowd_lang['s868'] = '保密';
$it618_crowd_lang['s869'] = '留言';
$it618_crowd_lang['s870'] = '設置收貨地址';
$it618_crowd_lang['s871'] = '首頁中間公告管理';
$it618_crowd_lang['s872'] = '電腦版手機版首頁輪播';
$it618_crowd_lang['s873'] = '公告數︰';
$it618_crowd_lang['s874'] = '注意︰此公告同時也會顯示在手機版首頁，排序為0時不顯示';
$it618_crowd_lang['s875'] = '標題';
$it618_crowd_lang['s876'] = '鏈接';
$it618_crowd_lang['s877'] = '文字是否粗體';
$it618_crowd_lang['s878'] = '排序';
$it618_crowd_lang['s879'] = '此輪播同時也會顯示在手機版首頁，為了手機版首頁輪播美觀，請一定保持圖片的寬高一致';
$it618_crowd_lang['s880'] = '電腦版手機版首頁輪播';
$it618_crowd_lang['s881'] = '圖片(寬︰212px，高︰52px)';
$it618_crowd_lang['s882'] = '鏈接(為空時圖片不帶鏈接)';
$it618_crowd_lang['s883'] = '上傳圖片';
$it618_crowd_lang['s884'] = '刪除';
$it618_crowd_lang['s885'] = '提交';
$it618_crowd_lang['s886'] = '注意︰有時商品一級類別不夠8個時，可以設置圖片，分類導航就顯示帶鏈接圖片，同時其它與此分類相關的功能也隱藏';
$it618_crowd_lang['s887'] = '，商品最低價格限制(最低價格︰<font color=blue><b>{price}</b></font> 元)';
$it618_crowd_lang['s888'] = '本月經驗';
$it618_crowd_lang['s889'] = '模塊DIY調用';
$it618_crowd_lang['s890'] = '分鐘';
$it618_crowd_lang['s891'] = '模塊數量︰';
$it618_crowd_lang['s892'] = 'DIY調用標識符';
$it618_crowd_lang['s893'] = '模塊類型';
$it618_crowd_lang['s894'] = '模板內容(編輯器右下角可以縮小擴大)';
$it618_crowd_lang['s895'] = '記錄條數';
$it618_crowd_lang['s896'] = '開啟JS調用';
$it618_crowd_lang['s897'] = '緩存時間';
$it618_crowd_lang['s898'] = '最新商品';
$it618_crowd_lang['s899'] = '熱銷商品';
$it618_crowd_lang['s900'] = '自定義內容';
$it618_crowd_lang['s901'] = '請復制(CTRL+C)以下內容並添加到 HTML 文件中';
$it618_crowd_lang['s902'] = '外部調用';
$it618_crowd_lang['s903'] = '提交後編輯模板內容，並且模塊類型不可修改';
$it618_crowd_lang['s904'] = '默認10條記錄';
$it618_crowd_lang['s905'] = '默認不開啟';
$it618_crowd_lang['s906'] = '默認緩存時間為1分鐘';
$it618_crowd_lang['s907'] = '<strong>編輯器用法︰</strong><img src="source/plugin/it618_crowd/images/editer.png"/> <font color="red">注意非自定義模塊推薦在HTML代碼模式下編輯，編輯器全屏功能很方便哦</font><hr />
<strong>通用標簽︰</strong>[loop]...[/loop] 循環顯示內容，{siteurl} 本站的網址外站調用時可到<hr />
<strong>商品標簽︰</strong>{pname} 商品名稱，{ppicsrc} 商品圖片地址，{puprice} 商品價格，{pprice} 商品市場價，{pcount} 商品庫存，{pviews} 商品人氣，{psalecount} 商品交易數，{purl} 商品鏈接
';
$it618_crowd_lang['s908'] = '顯示';
$it618_crowd_lang['s909'] = '點擊顯示隱藏模塊內容編輯器';
$it618_crowd_lang['s910'] = '隱藏';
$it618_crowd_lang['s911'] = '主導航設置';
$it618_crowd_lang['s912'] = '名稱';
$it618_crowd_lang['s913'] = '鏈接';
$it618_crowd_lang['s914'] = '名稱顏色';
$it618_crowd_lang['s915'] = '排序';
$it618_crowd_lang['s916'] = '數量︰';
$it618_crowd_lang['s917'] = '提示︰如果以下主導航為空，主導航默認顯示商家一級分類，排序值為0時不顯示';
$it618_crowd_lang['s918'] = '新窗口打開';
$it618_crowd_lang['s941'] = '元';
$it618_crowd_lang['s942'] = '';
$it618_crowd_lang['s943'] = '"0" => "短信發送成功",
"-1" => "參數不全",
"-2" => "服務器空間不支持,請確認支持curl或者fsocket，聯系您的空間商解決或者更換空間！",
"30" => "密碼錯誤",
"40" => "賬號不存在",
"41" => "余額不足",
"42" => "帳戶已過期",
"43" => "IP地址限制",
"50" => "內容含有敏感詞';
$it618_crowd_lang['s960'] = '積分錢包';
$it618_crowd_lang['s961'] = '電腦版風格';
$it618_crowd_lang['s962'] = '手機版風格';
$it618_crowd_lang['s963'] = '手機版圖標導航';
$it618_crowd_lang['s973'] = '整體顏色';
$it618_crowd_lang['s974'] = '部分邊框對比顏色';
$it618_crowd_lang['s975'] = '默認風格';
$it618_crowd_lang['s976'] = '導航數︰';
$it618_crowd_lang['s977'] = '注意︰導航圖標為了清晰，推薦寬高60到120，導航標題推薦最多4個字，排序為0時不顯示';
$it618_crowd_lang['s978'] = '圖標';
$it618_crowd_lang['s979'] = '標題';
$it618_crowd_lang['s980'] = '鏈接';
$it618_crowd_lang['s981'] = '新窗口';
$it618_crowd_lang['s982'] = '文字顏色(無突出效果時要為空)';
$it618_crowd_lang['s983'] = '文字粗體';
$it618_crowd_lang['s984'] = '排序';
$it618_crowd_lang['s985'] = '提交後再上傳圖片';
$it618_crowd_lang['s986'] = '注意︰默認8個圖標導航是商品分類，默認的鏈接plugin.php?id=it618_crowd:wap&pagetype=search&cid=1不是偽靜態的，可以自己修改crowd_wap-search-1.html，1就是一級商品分類編號';
$it618_crowd_lang['s987'] = '手機首頁自定廣告';
$it618_crowd_lang['s988'] = '上傳圖片';
$it618_crowd_lang['s989'] = '最新商品';
$it618_crowd_lang['s990'] = '人氣商品';
$it618_crowd_lang['s991'] = '電腦版顯示商品數,手機版顯示商品數,顯示順序︰';
$it618_crowd_lang['s992'] = '注意3個數值之間用逗號,隔開，默認值︰';
$it618_crowd_lang['s993'] = '查看全部';
$it618_crowd_lang['s994'] = '商品';
$it618_crowd_lang['s1028'] = '抱歉，您的';
$it618_crowd_lang['s1029'] = '不足，不能訂購商品！';
$it618_crowd_lang['s1040'] = '短信接口類型︰';
$it618_crowd_lang['s1041'] = '默認標配短信接口(短信寶)';
$it618_crowd_lang['s1042'] = 'IT618統一短信接口(阿里大魚)';
$it618_crowd_lang['s1043'] = '短信簽名︰';
$it618_crowd_lang['s1044'] = 'IT618統一短信接口(阿里雲短信)';
$it618_crowd_lang['s1045'] = '<font color=green><b>抱歉，您還沒有安裝 【<a href="http://addon.discuz.com/?@it618_members.plugin" target="_blank">it618會員短信微信</a>】，此插件為IT618公用短信接口插件，<font color=red>同時還是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_crowd_lang['s1046'] = '短信模板ID︰';
$it618_crowd_lang['s1050'] = '管理員UID<font color=#999>(用于微信消息，多個UID用,隔開)</font>︰';
$it618_crowd_lang['s1051'] = '微信消息模板ID︰';
$it618_crowd_lang['s1052'] = '微信消息標簽值︰';
$it618_crowd_lang['s1053'] = '<font color=#999>提示︰優先發送微信消息，發送成功了，就不發短信了</font>';
$it618_crowd_lang['s1054'] = '';
$it618_crowd_lang['s1060'] = '客服';
$it618_crowd_lang['s1076'] = '手機號碼';
$it618_crowd_lang['s1077'] = '收貨地址';
$it618_crowd_lang['s1078'] = '姓名︰';
$it618_crowd_lang['s1079'] = '手機︰';
$it618_crowd_lang['s1080'] = '地址︰';
$it618_crowd_lang['s1081'] = '抱歉，請先添加商品到購物車！';
$it618_crowd_lang['s1082'] = '抱歉，您購物車內的商品種數超過了gwcpcount的最高限制數！';
$it618_crowd_lang['s1090'] = '抱歉，商品不存在，請從購物車刪除此商品！';
$it618_crowd_lang['s1096'] = '抱歉，此商品沒有庫存，不能參與！';
$it618_crowd_lang['s1767'] = '';
$it618_crowd_lang['s1768'] = '請輸入您要搜索的商品名稱關鍵詞...';
$it618_crowd_lang['s1769'] = '驗證買家到店交易密碼 點擊此按鈕';
$it618_crowd_lang['s1770'] = '商品類別';
$it618_crowd_lang['s1771'] = '請輸入商品關鍵字';
$it618_crowd_lang['s1772'] = '限5張';
$it618_crowd_lang['s1773'] = '添加照片';
$it618_crowd_lang['s1774'] = '商城購物車頁';
$it618_crowd_lang['s1775'] = '<font color=red>提示︰有交易的商品不能刪除，可以修改商品，也可以下架商品！</font>';
$it618_crowd_lang['s1776'] = '收起';
$it618_crowd_lang['s1777'] = '交易備注';
$it618_crowd_lang['s1778'] = '備注內容︰';
$it618_crowd_lang['s1779'] = '揭曉管理人員可以給交易備注，方便給買家準確發貨';
$it618_crowd_lang['s1780'] = '備注成功！';
$it618_crowd_lang['s1781'] = '抱歉，請輸入備注內容！';
$it618_crowd_lang['s1782'] = '字';
$it618_crowd_lang['s1783'] = '抱歉，此插件還未開啟，請先開啟！';
$it618_crowd_lang['s1784'] = '交易積分︰';
$it618_crowd_lang['s1785'] = '積分信息';
$it618_crowd_lang['s1878'] = '阿里雲OSS設置';
$it618_crowd_lang['s1879'] = '啟用oss接口︰';
$it618_crowd_lang['s1880'] = '如果不啟用，上傳圖片到本地，如果啟用，上傳圖片到oss，並且返回圖片網絡引用鏈接';
$it618_crowd_lang['s1881'] = 'IT618插件阿里雲OSS接口設置方法';
$it618_crowd_lang['s1882'] = 'Access Key ID︰';
$it618_crowd_lang['s1883'] = 'Access Key Secret︰';
$it618_crowd_lang['s1884'] = 'Bucket名稱︰';
$it618_crowd_lang['s1885'] = 'Bucket域名EndPoint︰';
$it618_crowd_lang['s1886'] = 'Bucket外網訪問域名︰';
$it618_crowd_lang['s1888'] = '如果是個人申請的變量字符最多限制個數︰';
$it618_crowd_lang['s1889'] = '不受限制時請不要填寫';


$it618_crowd_lang['t1'] = '交易號';
$it618_crowd_lang['t2'] = '商品名稱';
$it618_crowd_lang['t3'] = '狀態';
$it618_crowd_lang['t4'] = '曬單評價';
$it618_crowd_lang['t5'] = '參與時間';
$it618_crowd_lang['t6'] = '揭曉時間';
$it618_crowd_lang['t7'] = '參與人次';
$it618_crowd_lang['t8'] = '我的揭曉';
$it618_crowd_lang['t9'] = '單價';
$it618_crowd_lang['t10'] = '積分';
$it618_crowd_lang['t11'] = '保存';
$it618_crowd_lang['t12'] = '按關鍵詞';
$it618_crowd_lang['t13'] = '狀態';
$it618_crowd_lang['t14'] = '所有狀態';
$it618_crowd_lang['t15'] = '未發貨';
$it618_crowd_lang['t16'] = '已發貨';
$it618_crowd_lang['t17'] = '已收貨';
$it618_crowd_lang['t18'] = '參與數︰';
$it618_crowd_lang['t19'] = '商品名稱為紅色時，表示此次參與是獲得者';
$it618_crowd_lang['t20'] = '已參與︰';
$it618_crowd_lang['t21'] = '查找';
$it618_crowd_lang['t22'] = '已揭曉';
$it618_crowd_lang['t23'] = '';
$it618_crowd_lang['t24'] = '';
$it618_crowd_lang['t25'] = '';
$it618_crowd_lang['t26'] = '';
$it618_crowd_lang['t27'] = '';
$it618_crowd_lang['t28'] = '必填 方便聯系';
$it618_crowd_lang['t29'] = '同時支持短信提醒，如果您成為獲得者，會給此手機號發短信';
$it618_crowd_lang['t30'] = '曬單評價';
$it618_crowd_lang['t31'] = '揭曉時間';
$it618_crowd_lang['t32'] = '';
$it618_crowd_lang['t33'] = '';
$it618_crowd_lang['t34'] = '';
$it618_crowd_lang['t35'] = '很差';
$it618_crowd_lang['t36'] = '較差';
$it618_crowd_lang['t37'] = '一般';
$it618_crowd_lang['t38'] = '較好';
$it618_crowd_lang['t39'] = '很好';
$it618_crowd_lang['t40'] = '請評分';
$it618_crowd_lang['t41'] = '確認收貨後可以對商品進行曬單評價，每次消費只能評價一次，綜合評分直接參與商品總評分和滿意度計算，其它3個評分是買家對商品的更詳細的評價，並且只對自己的總評分參與計算';
$it618_crowd_lang['t42'] = '5至400字數內';
$it618_crowd_lang['t43'] = '提交';
$it618_crowd_lang['t44'] = '取消';
$it618_crowd_lang['t45'] = '曬單評價';
$it618_crowd_lang['t46'] = '商家設置';
$it618_crowd_lang['t47'] = '基本信息';
$it618_crowd_lang['t48'] = '消息提醒設置';
$it618_crowd_lang['t49'] = '商品管理';
$it618_crowd_lang['t50'] = '最新揭曉';
$it618_crowd_lang['t51'] = '總經驗';
$it618_crowd_lang['t52'] = '推薦文章';
$it618_crowd_lang['t53'] = '會員';
$it618_crowd_lang['t54'] = '經驗';
$it618_crowd_lang['t55'] = '排名';
$it618_crowd_lang['t56'] = '';
$it618_crowd_lang['t57'] = '';
$it618_crowd_lang['t58'] = '星期日';
$it618_crowd_lang['t59'] = '星期一';
$it618_crowd_lang['t60'] = '星期二';
$it618_crowd_lang['t61'] = '星期三';
$it618_crowd_lang['t62'] = '星期四';
$it618_crowd_lang['t63'] = '星期五';
$it618_crowd_lang['t64'] = '星期六';
$it618_crowd_lang['t65'] = '月';
$it618_crowd_lang['t66'] = '日';
$it618_crowd_lang['t67'] = '';
$it618_crowd_lang['t68'] = '';
$it618_crowd_lang['t69'] = '';
$it618_crowd_lang['t70'] = '';
$it618_crowd_lang['t71'] = '';
$it618_crowd_lang['t72'] = '';
$it618_crowd_lang['t73'] = '';
$it618_crowd_lang['t74'] = '';
$it618_crowd_lang['t75'] = '';
$it618_crowd_lang['t76'] = '';
$it618_crowd_lang['t77'] = '';
$it618_crowd_lang['t78'] = '';
$it618_crowd_lang['t79'] = '';
$it618_crowd_lang['t80'] = '';
$it618_crowd_lang['t81'] = '';
$it618_crowd_lang['t82'] = '';
$it618_crowd_lang['t83'] = '搜索';
$it618_crowd_lang['t84'] = '首頁';
$it618_crowd_lang['t85'] = '全部商品分類';
$it618_crowd_lang['t86'] = '熱門分類';
$it618_crowd_lang['t87'] = '人氣分類';
$it618_crowd_lang['t88'] = '更多';
$it618_crowd_lang['t89'] = '熱門商品';
$it618_crowd_lang['t90'] = '最近剛參與的商品';
$it618_crowd_lang['t91'] = '最近參與';
$it618_crowd_lang['t92'] = '一周內揭曉最多的商品';
$it618_crowd_lang['t93'] = '一周熱揭';
$it618_crowd_lang['t94'] = '回到頂部';
$it618_crowd_lang['t95'] = '找到';
$it618_crowd_lang['t96'] = '“';
$it618_crowd_lang['t97'] = '”';
$it618_crowd_lang['t98'] = '相關的商品共';
$it618_crowd_lang['t99'] = '個。';
$it618_crowd_lang['t100'] = '分&nbsp;&nbsp;類︰';
$it618_crowd_lang['t101'] = '揭曉期數';
$it618_crowd_lang['t102'] = '揭曉期數從高到低';
$it618_crowd_lang['t103'] = '即將揭曉';
$it618_crowd_lang['t104'] = '剩余人次從低到高';
$it618_crowd_lang['t105'] = '剩余人次';
$it618_crowd_lang['t106'] = '參與單價從低到高';
$it618_crowd_lang['t107'] = '單價';
$it618_crowd_lang['t108'] = '商品價值從高到低';
$it618_crowd_lang['t109'] = '按發布時間排序';
$it618_crowd_lang['t110'] = '發布時間';
$it618_crowd_lang['t111'] = '揭曉排行';
$it618_crowd_lang['t112'] = '您的位置︰';
$it618_crowd_lang['t113'] = '價值';
$it618_crowd_lang['t114'] = '商品價值從低到高';
$it618_crowd_lang['t115'] = '人氣';
$it618_crowd_lang['t116'] = '人已評價';
$it618_crowd_lang['t117'] = '分';
$it618_crowd_lang['t118'] = '價值:';
$it618_crowd_lang['t119'] = '我現有';
$it618_crowd_lang['t120'] = '參與';
$it618_crowd_lang['t121'] = '我要參與';
$it618_crowd_lang['t122'] = '立即購買';
$it618_crowd_lang['t123'] = '即將揭曉商品';
$it618_crowd_lang['t124'] = '揭曉排行';
$it618_crowd_lang['t125'] = '參與動態';
$it618_crowd_lang['t126'] = '商家位置';
$it618_crowd_lang['t127'] = '商品詳情';
$it618_crowd_lang['t128'] = '曬單評價（';
$it618_crowd_lang['t129'] = '）';
$it618_crowd_lang['t130'] = '單價:';
$it618_crowd_lang['t131'] = '還沒有人曬單評價';
$it618_crowd_lang['t132'] = '需';
$it618_crowd_lang['t133'] = '確定購買';
$it618_crowd_lang['t134'] = '1、參與人次如果大于實時剩余人次，交易時參與人次自動等于剩余人次<br>2、如果商品揭曉時，<font color=red>您幸運的成為獲得者，請在我的揭曉填寫收貨地址，不填寫不發貨</font>，如果是虛擬商品，會自動發貨的';
$it618_crowd_lang['t141'] = '查看本期參與記錄';
$it618_crowd_lang['t142'] = '曬單評價';
$it618_crowd_lang['t143'] = '評價人次︰';
$it618_crowd_lang['t144'] = '滿意佔比︰';
$it618_crowd_lang['t145'] = '分';
$it618_crowd_lang['t146'] = '曬單評價';
$it618_crowd_lang['t147'] = '請稍後，加載中…';
$it618_crowd_lang['t148'] = '購買提示︰<br>';
$it618_crowd_lang['t149'] = '購買提示';
$it618_crowd_lang['t150'] = '已消費';
$it618_crowd_lang['t151'] = '人';
$it618_crowd_lang['t152'] = '最多只能參與';
$it618_crowd_lang['t153'] = '最少要參與';
$it618_crowd_lang['t154'] = '人次';
$it618_crowd_lang['t155'] = '查看全部分類';
$it618_crowd_lang['t156'] = '熱&nbsp;&nbsp;門︰';
$it618_crowd_lang['t157'] = '至';
$it618_crowd_lang['t158'] = '導航';
$it618_crowd_lang['t159'] = '商城首頁';
$it618_crowd_lang['t160'] = '網站首頁';
$it618_crowd_lang['t161'] = '商品分類';
$it618_crowd_lang['t162'] = '曬單評價';
$it618_crowd_lang['t163'] = '揭曉管理';
$it618_crowd_lang['t164'] = '按關鍵詞';
$it618_crowd_lang['t165'] = '會員名稱︰';
$it618_crowd_lang['t166'] = '查詢';
$it618_crowd_lang['t167'] = '';
$it618_crowd_lang['t168'] = '查看';
$it618_crowd_lang['t169'] = '發貨';
$it618_crowd_lang['t170'] = '確定要給以下交易發貨？';
$it618_crowd_lang['t171'] = '管理後台';
$it618_crowd_lang['t172'] = '關閉';
$it618_crowd_lang['t173'] = '我的揭曉';
$it618_crowd_lang['t174'] = '';
$it618_crowd_lang['t175'] = '評價內容字數至少5個！';
$it618_crowd_lang['t176'] = '評價內容字數最多400個！';
$it618_crowd_lang['t177'] = '確定要提交此次曬單評價？提交後不可修改。';
$it618_crowd_lang['t178'] = '您輸入了';
$it618_crowd_lang['t179'] = '個字！';
$it618_crowd_lang['t180'] = '登錄';
$it618_crowd_lang['t181'] = '注冊';
$it618_crowd_lang['t182'] = '商家地址︰';
$it618_crowd_lang['t183'] = '分 評價人次:';
$it618_crowd_lang['t184'] = '滿意佔比:';
$it618_crowd_lang['t185'] = '交易信息︰';
$it618_crowd_lang['t186'] = '關閉';
$it618_crowd_lang['t187'] = '購物車';
$it618_crowd_lang['t188'] = '購買成功，謝謝您的參與支持！';
$it618_crowd_lang['t189'] = '';
$it618_crowd_lang['t190'] = '數量不能超過您自己現在有的數量！';
$it618_crowd_lang['t191'] = '電腦版';
$it618_crowd_lang['t192'] = '立即購買';
$it618_crowd_lang['t193'] = '加入購物車';
$it618_crowd_lang['t194'] = '';
$it618_crowd_lang['t195'] = '';
$it618_crowd_lang['t196'] = '手機號碼︰';
$it618_crowd_lang['t197'] = '庫存';
$it618_crowd_lang['t198'] = '正在交易...如果您不想等可以關閉交易窗口，後台會自動運行！';
$it618_crowd_lang['t199'] = '積分購買';
$it618_crowd_lang['t200'] = '本次參與';
$it618_crowd_lang['t201'] = '';
$it618_crowd_lang['t202'] = '積分';
$it618_crowd_lang['t203'] = '';
$it618_crowd_lang['t204'] = '';
$it618_crowd_lang['t205'] = '收貨地址︰';
$it618_crowd_lang['t206'] = '給商家留言︰';
$it618_crowd_lang['t207'] = '在商家沒有設置快遞信息前，收貨地址是可以修改的';
$it618_crowd_lang['t208'] = '收貨姓名︰';
$it618_crowd_lang['t209'] = '收貨手機︰';
$it618_crowd_lang['t210'] = '︰';
$it618_crowd_lang['t211'] = '收貨地址︰';
$it618_crowd_lang['t212'] = '';
$it618_crowd_lang['t213'] = '';
$it618_crowd_lang['t214'] = '';
$it618_crowd_lang['t215'] = '收貨地址提交成功！';
$it618_crowd_lang['t216'] = '抱歉，請填寫有效的11位手機號碼！';
$it618_crowd_lang['t217'] = '抱歉，請填寫收貨地址！';
$it618_crowd_lang['t218'] = '在線客服';
$it618_crowd_lang['t219'] = '【參與記錄】';
$it618_crowd_lang['t220'] = '確定要確認收貨？此操作不可逆。';
$it618_crowd_lang['t221'] = '三大服務保證︰';
$it618_crowd_lang['t222'] = '100%公平公正';
$it618_crowd_lang['t223'] = '100%正品保證';
$it618_crowd_lang['t224'] = '全國免費配送';
$it618_crowd_lang['t225'] = '怎麼玩兒';
$it618_crowd_lang['t226'] = '選擇商品';
$it618_crowd_lang['t227'] = '選擇心儀商品<br /> 點擊立即購買';
$it618_crowd_lang['t228'] = '積分購買';
$it618_crowd_lang['t229'] = '支持N個單價積分<br /> 獲得N個眾籌碼';
$it618_crowd_lang['t230'] = '揭曉幸運兒';
$it618_crowd_lang['t231'] = '當1件商品的所有份額都獲得<br /> 支持後，計算出幸運獲得者';
$it618_crowd_lang['t232'] = '查看眾籌碼';
$it618_crowd_lang['t233'] = '客服QQ︰';
$it618_crowd_lang['t234'] = '商家發貨後，超過';
$it618_crowd_lang['t235'] = '天不確認收貨，系統自動確認收貨';
$it618_crowd_lang['t237'] = '提示';
$it618_crowd_lang['t238'] = '期數';
$it618_crowd_lang['t239'] = '參與記錄';
$it618_crowd_lang['t240'] = '揭曉記錄（';
$it618_crowd_lang['t241'] = '【揭曉記錄】';
$it618_crowd_lang['t242'] = '會員';
$it618_crowd_lang['t243'] = '參與人次';
$it618_crowd_lang['t244'] = '單價';
$it618_crowd_lang['t245'] = '積分';
$it618_crowd_lang['t246'] = '參與時間';
$it618_crowd_lang['t247'] = '揭曉時間';
$it618_crowd_lang['t248'] = '幸運眾籌碼';
$it618_crowd_lang['t249'] = '刷新交易';
$it618_crowd_lang['t250'] = '會員';
$it618_crowd_lang['t251'] = '時間';
$it618_crowd_lang['t252'] = '參與記錄';
$it618_crowd_lang['t253'] = '揭曉記錄';
$it618_crowd_lang['t254'] = '全部商品';
$it618_crowd_lang['t255'] = '商品類別:';
$it618_crowd_lang['t256'] = '商品地區:';
$it618_crowd_lang['t257'] = '所有一級分類';
$it618_crowd_lang['t258'] = '所有二級分類';
$it618_crowd_lang['t261'] = '關鍵字詞:';
$it618_crowd_lang['t262'] = '商品價格:';
$it618_crowd_lang['t268'] = '排序方式:';
$it618_crowd_lang['t269'] = '即將揭曉';
$it618_crowd_lang['t270'] = '商品價格';
$it618_crowd_lang['t271'] = '商品揭曉';
$it618_crowd_lang['t272'] = '商品人氣';
$it618_crowd_lang['t273'] = '查看全部商品';
$it618_crowd_lang['t274'] = '還未揭曉';
$it618_crowd_lang['t275'] = '';
$it618_crowd_lang['t276'] = '';
$it618_crowd_lang['t277'] = '搜索';
$it618_crowd_lang['t278'] = '現金購買';
$it618_crowd_lang['t285'] = '關閉';
$it618_crowd_lang['t286'] = '評價內容字數至少5個！';
$it618_crowd_lang['t287'] = '評價內容字數最多400個！';
$it618_crowd_lang['t288'] = '確定要提交此次曬單評價？提交後不可修改。';
$it618_crowd_lang['t289'] = '';
$it618_crowd_lang['t290'] = '';
$it618_crowd_lang['t291'] = '您輸入了';
$it618_crowd_lang['t292'] = '個字！';
$it618_crowd_lang['t293'] = '開始日期不能大于截止日期！';
$it618_crowd_lang['t294'] = '';
$it618_crowd_lang['t295'] = '確定要確認收貨？此操作不可逆。';
$it618_crowd_lang['t296'] = '請輸入商品關鍵詞';
$it618_crowd_lang['t297'] = '抱歉，你的瀏覽器不支持此操作。\n請使用按鍵 Ctrl+D 收藏網站。';
$it618_crowd_lang['t306'] = '抱歉，請先登錄！也可以點確定直接跳轉到登錄頁面！';
$it618_crowd_lang['t312'] = '最新發布的商品';
$it618_crowd_lang['t313'] = '瀏覽量最多的商品';
$it618_crowd_lang['t314'] = '熱門商品';
$it618_crowd_lang['t315'] = '消費類型';
$it618_crowd_lang['t316'] = '支付方式';
$it618_crowd_lang['t317'] = '商品搜索';
$it618_crowd_lang['t326'] = '揭曉';
$it618_crowd_lang['t339'] = '確定要修改此次曬單評價？修改後您還可以再修改！';
$it618_crowd_lang['t340'] = '返回';
$it618_crowd_lang['t341'] = '刷新';
$it618_crowd_lang['t342'] = '';
$it618_crowd_lang['t343'] = '';
$it618_crowd_lang['t344'] = '抱歉，請填寫收貨姓名！';
$it618_crowd_lang['t345'] = '回復︰';
$it618_crowd_lang['t346'] = '抱歉，請輸入評價回復內容！';
$it618_crowd_lang['t347'] = '確定要提交評價回復內容？';
$it618_crowd_lang['t348'] = '評價回復成功！';
$it618_crowd_lang['t349'] = '分享商品';
$it618_crowd_lang['t359'] = '手機掃碼訪問此商品';
$it618_crowd_lang['t363'] = '查看在線客服';
$it618_crowd_lang['t364'] = '展開';
$it618_crowd_lang['t365'] = '關閉在線客服';
$it618_crowd_lang['t366'] = '收縮';
$it618_crowd_lang['t367'] = '商家信息';
$it618_crowd_lang['t368'] = '工作時間';
$it618_crowd_lang['t369'] = '熱線電話';
$it618_crowd_lang['t376'] = '分享';
$it618_crowd_lang['t377'] = '';
$it618_crowd_lang['t378'] = '';
$it618_crowd_lang['t379'] = '';
$it618_crowd_lang['t380'] = '';
$it618_crowd_lang['t381'] = '購物車添加成功！';
$it618_crowd_lang['t382'] = '此商品已經在購物車！';
$it618_crowd_lang['t383'] = '給商家留言';
$it618_crowd_lang['t758'] = '返回上頁';
$it618_crowd_lang['t759'] = '刷新頁面';
$it618_crowd_lang['t760'] = '搜索商品';
$it618_crowd_lang['t748'] = '單價/參與人次';
$it618_crowd_lang['t749'] = '設置參與人次';
$it618_crowd_lang['t750'] = '批量購買';
$it618_crowd_lang['t751'] = '完成';
$it618_crowd_lang['t752'] = '商品/參與情況';
$it618_crowd_lang['t753'] = '清空購物車';
$it618_crowd_lang['t754'] = '小計';
$it618_crowd_lang['t755'] = '操作';
$it618_crowd_lang['t756'] = '確定購買';
$it618_crowd_lang['t757'] = '我的<br>導航';
$it618_crowd_lang['t758'] = '返回上頁';
$it618_crowd_lang['t759'] = '刷新頁面';
$it618_crowd_lang['t760'] = '搜索商品';
$it618_crowd_lang['t763'] = '復制鏈接';
$it618_crowd_lang['t764'] = '請升級您的微信版本！';
$it618_crowd_lang['t765'] = '鏈接復制成功！';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_crowd_set'));
if($count==0){
$sql = <<<EOF
	INSERT INTO `pre_it618_crowd_set` (`id`, `setname`, `setvalue`) VALUES
(1, 'topnav', '<li>\r\n	<a id="AddFavorite" href="javascript:void(0);">收藏IT618</a><span></span>\r\n</li>\r\n<li>\r\n	<a target="_blank" href="">幫助</a><span></span>\r\n</li>\r\n<li>\r\n	<a target="_blank" href="">反饋</a>\r\n</li>'),
(2, 'hotclassgoods', '3,1,2,6,8,9,12,13,15,18,19@@@3,1,2,6,8,9,12,13,15,18,1,2,6,8,9,12,13,15,18,19@@@1,2,1,2,1,2,1,2,1,2,1,2'),
(3, 'footer', '<footer id="footer">\r\n<div class="footer-top">\r\n	<div class="site-info">\r\n		<dl>\r\n			<dt>\r\n				服務保障\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">商城三包</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">退換貨服務</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">支付方式</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				用戶幫助\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">答疑反饋</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">常見問題</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">往期商城</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">抽獎活動</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				商務合作\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">商城合作</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">開放API</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank">商城聯盟</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="">友情鏈接</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				公司信息\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">關于商城</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">媒體報道</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">加入我們</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">法律中心</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				移動商城\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank">團購APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">商城酒店預訂APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">商城電影APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">商城wap版</a> \r\n			</dd>\r\n		</dl>\r\n		<div class="code">\r\n			<img src="source/plugin/it618_crowd/images/code.png" /> \r\n		</div>\r\n		<div class="clr">\r\n		</div>\r\n	</div>\r\n</div>\r\n</footer>');

EOF;
$sql=str_replace("pre_it618_crowd_set",DB::table('it618_crowd_set'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_crowd_class1` (`id`, `it618_classname`, `it618_color`, `it618_order`, `it618_istj`, `it618_cssname`, `it618_goodscount`, `it618_wapgoodscount`, `it618_classnamenav`, `it618_pj`) VALUES
(1, '手機數碼', '#6f7edb', 1, 0, 'jiudian', 8, 4, '手機', '綜合評分_描述相符_質量_服務'),
(2, '電腦辦公', '#ef6452', 2, 0, 'yule', 8, 4, '電腦', '綜合評分_描述相符_質量_服務'),
(3, '家用電器', '#4caf7d', 3, 0, 'dianying', 8, 4, '電器', '綜合評分_描述相符_質量_服務'),
(4, '化妝個護', '#da6cb3', 4, 0, 'liren', 8, 4, '個護', '綜合評分_描述相符_質量_服務'),
(5, '食品飲料', '#AC735F', 5, 0, 'meishi', 8, 4, '食品', '綜合評分_描述相符_質量_服務'),
(6, '家居箱包', '#4caf7d', 6, 0, 'sheying', 8, 4, '家居', '綜合評分_描述相符_質量_服務'),
(7, '母嬰用品', '#82bc55', 7, 0, 'shenghuo', 8, 4, '母嬰', '綜合評分_描述相符_質量_服務'),
(8, '運動戶外', '#5cb0c8', 8, 0, 'lvyou', 8, 4, '運動', '綜合評分_描述相符_質量_服務'),
(9, '其他商品', '#c89d66', 9, 0, 'gouwu', 8, 4, '其他', '綜合評分_描述相符_質量_服務');
EOF;
$sql=str_replace("pre_it618_crowd_class1",DB::table('it618_crowd_class1'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_crowd_class2` (`id`, `it618_class1_id`, `it618_classname`, `it618_color`, `it618_order`, `it618_istj`) VALUES
(1, 1, '華為', '#FF0000', 1, 1),
(2, 1, '隻果', '', 2, 1),
(3, 1, '魅族', '', 3, 1),
(4, 1, '小米', '', 4, 1),
(5, 1, 'vivo', '', 5, 1),
(6, 1, '三星', '', 6, 1),
(7, 1, '相機', '', 7, 1),
(8, 1, '電玩', '', 8, 1),
(9, 2, '台式機', '', 1, 1),
(10, 2, '筆記本', '#FF0000', 2, 1),
(11, 2, '顯示器', '', 3, 1),
(12, 2, '音箱', '', 4, 1),
(13, 2, '鍵盤', '', 5, 1),
(14, 2, '鼠標', '', 6, 1),
(15, 2, '路由器', '', 7, 1),
(16, 2, '打印機', '', 8, 1),
(17, 3, '彩電', '#FF0000', 1, 1),
(18, 3, '冰箱', '', 2, 1),
(19, 3, '空調', '', 3, 1),
(20, 3, '洗衣機', '', 4, 1),
(21, 3, '電風扇', '', 5, 1),
(22, 3, '熱水器', '', 6, 1),
(23, 3, '電飯煲', '', 7, 1),
(24, 3, '電吹風機', '', 8, 1),
(25, 4, '洗發水', '', 1, 1),
(26, 4, '牙膏', '', 2, 1),
(27, 4, '沐浴露', '', 3, 1),
(28, 4, '護膚霜', '', 4, 1),
(29, 4, '肥皂', '', 5, 1),
(30, 4, '口紅', '', 6, 1),
(31, 4, '洗手液', '', 7, 1),
(32, 4, '面膜', '', 8, 1),
(33, 5, '礦泉水', '#009900', 1, 1),
(34, 5, '汽水果汁', '', 2, 1),
(35, 5, '奶品', '', 3, 1),
(36, 5, '食用油', '', 4, 1),
(37, 5, '煙酒', '', 5, 1),
(38, 5, '方便面', '', 6, 1),
(39, 5, '干果', '', 7, 1),
(40, 5, '水果', '', 8, 1),
(41, 6, '沙發', '', 1, 1),
(42, 6, '棹子', '', 2, 1),
(43, 6, '紙品', '', 3, 1),
(44, 6, '毛巾', '', 4, 1),
(45, 6, '書包', '', 5, 1),
(46, 6, '旅行箱', '', 6, 1),
(47, 6, '錢包', '', 7, 1),
(48, 6, '皮帶', '', 8, 1),
(49, 7, '推車', '', 1, 1),
(50, 7, '紙尿褲', '', 2, 1),
(51, 7, '嬰兒床', '', 3, 1),
(52, 7, '奶瓶', '', 4, 1),
(53, 7, '孕婦裝', '', 5, 1),
(54, 7, '吸奶器', '', 6, 1),
(55, 7, '奶嘴', '', 7, 1),
(56, 7, '嬰兒床', '', 8, 1),
(57, 8, '山地車', '', 1, 1),
(58, 8, '望遠鏡', '', 2, 1),
(59, 8, '球類', '', 3, 1),
(60, 8, '跑步機', '', 4, 1),
(61, 8, '摩托車', '', 5, 1),
(62, 8, '坐躺椅床', '', 6, 1),
(63, 8, '運動服', '', 7, 1),
(64, 8, '休閑車', '', 8, 1),
(65, 9, '虛擬商品', '#FF6600', 1, 1),
(66, 9, '服裝', '', 2, 1),
(67, 9, '鞋子', '', 3, 1),
(68, 9, '汽車', '', 4, 1),
(69, 9, '書籍', '', 5, 1),
(70, 9, '樂器', '', 6, 1),
(71, 9, '黃金珠寶', '', 7, 1),
(72, 9, '安全套', '', 8, 1);
EOF;
$sql=str_replace("pre_it618_crowd_class2",DB::table('it618_crowd_class2'),$sql);
DB::query($sql);
	
$sql = <<<EOF
INSERT INTO `pre_it618_crowd_style` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#ff971b', '#e46703', 0),
(2, '#DD2525', '#B52020', 1),
(3, '#48b518', '#289a00', 0),
(4, '#2c7ccd', '#0c59ad', 0),
(5, '#f50bc1', '#c5099b', 0),
(6, '#09aeb0', '#089395', 0),
(8, '#ff4400', '#e03e03', 0),
(7, '#888c8e', '#6f7071', 0);
EOF;
$sql=str_replace("pre_it618_crowd_style",DB::table('it618_crowd_style'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_crowd_wapstyle` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#fd9e2d', '#e8922b', 0),
(2, '#fc4646', '#f43131', 1),
(3, '#5ebe00', '#56aa04', 0),
(4, '#099fde', '#098fc8', 0),
(5, '#fb23cb', '#ea11ba', 0),
(6, '#2dbeae', '#00a795', 0),
(8, '#fe5400', '#d04906', 0),
(7, '#999a9b', '#8d8f90', 0);
EOF;
$sql=str_replace("pre_it618_crowd_wapstyle",DB::table('it618_crowd_wapstyle'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_crowd_iconav` (`id`, `it618_title`, `it618_img`, `it618_url`, `it618_target`, `it618_color`, `it618_isbold`, `it618_order`) VALUES
(1, '食品飲料', 'source/plugin/it618_crowd/wap/images/1.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=5', 0, '', 0, 4),
(2, '其他商品', 'source/plugin/it618_crowd/wap/images/2.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=8', 0, '', 0, 8),
(3, '化妝個護', 'source/plugin/it618_crowd/wap/images/3.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=4', 0, '', 0, 6),
(4, '手機數碼', 'source/plugin/it618_crowd/wap/images/4.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=1', 0, '', 0, 1),
(5, '家用電器', 'source/plugin/it618_crowd/wap/images/5.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=3', 0, '', 0, 3),
(6, '運動戶外', 'source/plugin/it618_crowd/wap/images/6.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=8', 0, '', 0, 7),
(7, '電腦辦公', 'source/plugin/it618_crowd/wap/images/7.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=2', 0, '', 0, 2),
(8, '母嬰用品', 'source/plugin/it618_crowd/wap/images/8.png', 'plugin.php?id=it618_crowd:wap&pagetype=search&cid=7', 0, '', 0, 5);
EOF;
$sql=str_replace("pre_it618_crowd_iconav",DB::table('it618_crowd_iconav'),$sql);
DB::query($sql);
}
//From: Dism_taobao_com
?>