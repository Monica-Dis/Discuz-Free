<?php
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

DB::query("DROP TABLE IF EXISTS pre_it618_crowd_nav");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_class1");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_class2");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_focus");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_goods");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_goods_km");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_goods_salekm");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_sale");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_sale_pjpic");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_gwc");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_set");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_style");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_wapstyle");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_iconav");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_gonggao");
DB::query("DROP TABLE IF EXISTS pre_it618_crowd_diy");


$finish = TRUE;
?>