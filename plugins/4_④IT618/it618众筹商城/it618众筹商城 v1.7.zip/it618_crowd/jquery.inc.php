<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';

$isok=0;$shopid=0;
if($_G['uid']>0){
	$crowd_adminuids=explode(",",$it618_crowd['crowd_adminuids']);
	if(in_array($_G['uid'],$crowd_adminuids)){
		$isok=1;
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:jquery');
?>