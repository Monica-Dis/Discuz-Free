<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

$it618_crowd_crowdsale=C::t('#it618_crowd#it618_crowd_crowdsale')->fetch_by_id($_GET['crowdsaleid']);
$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_crowdsale['it618_pid']);
$salecount=C::t('#it618_crowd#it618_crowd_sale')->count_by_pid_saleid($it618_crowd_crowdsale['it618_pid'],$it618_crowd_crowdsale['it618_saleid']);

$pname='('.$it618_crowd_lang['s21'].$salecount.$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];

$username=it618_crowd_getusername($it618_crowd_crowdsale['it618_uid']);

$buyuser='<a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale['it618_uid']).'" target="_blank">'.$username.'</a>';

$codes_str=$it618_crowd_crowdsale['it618_codes'];

$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($it618_crowd_crowdsale['it618_saleid']);
$it618_code=$it618_crowd_sale['it618_code'];
if($it618_code==''){
	$it618_code=$it618_crowd_lang['t274'];
}

if($it618_crowd_crowdsale['it618_state']==1){
	$codes_str=str_replace($it618_code,"<font color=red>".$it618_code."</font>",$codes_str);
}

$tmparr=explode(",",$codes_str);
$codescount=count($tmparr);

$n=1;
$codes_str='<table class="salecodes"><tr>';
for($i=0;$i<$codescount;$i++){

	$codes_str.='<td>'.$tmparr[$i].'</td>';
	
	if($n%5==0)$codes_str.='</tr><tr>';

	$n=$n+1;
}

for($i=1;$i<=(5-$codescount%5);$i++){
	$codes_str.='<td></td>';
}
$codes_str.='</tr>';
$codes_str.='</table>';

$codes_str=str_replace("<tr><td></td><td></td><td></td><td></td><td></td></tr>","",$codes_str);

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:salecodes');
?>