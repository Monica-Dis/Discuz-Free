<?php
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

global $_G;
if($reabc[4]!='8')return;

loadcache('plugin');
$it618_crowd = $_G['cache']['plugin']['it618_crowd'];

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function/it618_crowd.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_product&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=2;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<4;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[0]=$it618_crowd_lang['s556'];
$strtmptitle[1]=$it618_crowd_lang['s557'];
$strtmptitle[2]=$it618_crowd_lang['s558'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_product_add&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>
<li '.$strtmp[1].' '.$strtmp[2].' '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_product&cp1=2'.$urls.'"><span>'.$strtmptitle[2].'</span></a></li>
</ul></div>';

$cparray = array('admin_product', 'admin_product_add', 'admin_product_edit', 'admin_product_km');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_product' : $_GET['cp'];

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();/*Dism_taobao-com*/
?>