<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';

$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($_GET['shareid']);
$t=$it618_crowd_goods['it618_name'].' - '.$it618_crowd_lang['t349'];

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:showshare');
?>