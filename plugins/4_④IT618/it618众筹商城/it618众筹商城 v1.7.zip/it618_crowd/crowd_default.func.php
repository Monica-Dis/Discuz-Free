<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/crowd_function.func.php';

if($pagetype=='search'){
	if($_GET['sw']==''||!isset($_GET['sw']))$searchsw=$it618_crowd['crowd_sw'];else $searchsw=$_GET['sw'];
}
if($searchsw!='')$sw=' style="display:none"';

$homeurl=it618_crowd_getrewrite('crowd_home','','plugin.php?id=it618_crowd:index');
$searchurl=it618_crowd_getrewrite('crowd_search','','plugin.php?id=it618_crowd:search');
$saleurl=it618_crowd_getrewrite('crowd_sale','','plugin.php?id=it618_crowd:sale');

$crowd_logo=str_replace("{homeurl}",$homeurl,$it618_crowd['crowd_logo']);

$crowd_hotsw=explode(',',$it618_crowd['crowd_hotsw']);
for($i=0;$i<count($crowd_hotsw);$i++){
	$tmpurl=it618_crowd_getrewrite('crowd_search','','plugin.php?id=it618_crowd:search&sw='.urlencode($crowd_hotsw[$i]),'?sw='.urlencode($crowd_hotsw[$i]));
	$hotsw.='<a href="'.$tmpurl.'">'.$crowd_hotsw[$i].'</a>';
}

$hotclassgoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('hotclassgoods');
$hotclassgoods=explode('@@@',$hotclassgoods);

$stylecount=C::t('#it618_crowd#it618_crowd_style')->count_by_isok();
$it618_crowd_style=C::t('#it618_crowd#it618_crowd_style')->fetch_by_isok();

$footer=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('footer');
$topnav=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('topnav');

foreach(C::t('#it618_crowd#it618_crowd_focus')->fetch_all_by_type_order(2) as $it618_crowd_focus) {
	if($it618_crowd_focus['it618_url']!=''){
		$str_focus2.='<li><a href="'.$it618_crowd_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="1200" height="63" /></a></li>';
	}else{
		$str_focus2.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="1200" height="63" /></li>';
	}
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." ORDER BY it618_order");
while($it618_crowd_class1 = DB::fetch($query1)) {
	if($it618_crowd_class1['it618_img']==''){
		$tmpurl=it618_crowd_getrewrite('crowd_list',$it618_crowd_class1['id'],'plugin.php?id=it618_crowd:list&class1='.$it618_crowd_class1['id']);
		$str_nav.='<a href="'.$tmpurl.'">'.$it618_crowd_class1['it618_classname'].'</a>';
		
		$str_class.='<div class="sort">
						<div class="sort-menu"><em class="sort-icon"></em><i class="'.$it618_crowd_class1['it618_cssname'].'"></i><a class="title '.$it618_crowd_class1['it618_cssname'].'" href="'.$tmpurl.'">'.cutstr($it618_crowd_class1['it618_classname'],18,'...').'</a>
							<p>
								{it618classtj}
							</p>
						  </div>
						  <div class="sort-con '.$it618_crowd_class1['it618_cssname'].'-top">
							<div class="sort-con-left">
								<h4><a href="'.$tmpurl.'">'.$it618_crowd_class1['it618_classname'].'</a></h4>
								<ul class="sort-link02 cl">
									{it618classall}
								</ul>
							</div>
						  </div>
					</div>';
		$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class2')." where it618_class1_id=".$it618_crowd_class1['id']." ORDER BY it618_order");
		$it618classtj='';$it618classall='';
		while($it618_crowd_class2 = DB::fetch($query2)) {
			if($it618_crowd_class2['it618_color']!="")
			$tmpname='<font color='.$it618_crowd_class2['it618_color'].'>'.$it618_crowd_class2['it618_classname'].'</font>';else $tmpname=$it618_crowd_class2['it618_classname'];
			
			$tmpurl=it618_crowd_getrewrite('crowd_list',$it618_crowd_class1['id'].'@'.$it618_crowd_class2['id'],'plugin.php?id=it618_crowd:list&class1='.$it618_crowd_class1['id'].'&class2='.$it618_crowd_class2['id']);
			if($it618_crowd_class2['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'">'.$tmpname.'</a>';
			$it618classall.='<li><a href="'.$tmpurl.'">'.$tmpname.'</a></li>';
			if($i1ii1[5]!='_')return;
		}
		
		$str_class=str_replace("{it618classtj}",$it618classtj,$str_class);
		$str_class=str_replace("{it618classall}",$it618classall,$str_class);
	}else{
		if($it618_crowd_class1['it618_url']!=''){
			$str_class.='<div class="sort">
						<a href="'.$it618_crowd_class1['it618_url'].'" target="_blank"><img src="'.$it618_crowd_class1['it618_img'].'" width="212" height="56" style="margin-left:2px"></a>
					</div>';
		}else{
			$str_class.='<div class="sort">
						<img src="'.$it618_crowd_class1['it618_img'].'" width="212" height="56" style="margin-left:2px">
					</div>';
		}
	}
}

$str_class.='<div class="sort-lottery">
				<div class="sort-menu" style="height:0;padding:0; margin:0"></div>
			 </div>';
			 
$count = C::t('#it618_crowd#it618_crowd_nav')->count_by_search();
if($count>0){
	$str_nav='';
	foreach(C::t('#it618_crowd#it618_crowd_nav')->fetch_all_by_search() as $it618_crowd_nav) {
		if($it618_crowd_nav['it618_color']!="")
		$tmpname='<font color='.$it618_crowd_nav['it618_color'].'>'.$it618_crowd_nav['it618_name'].'</font>';else $tmpname=$it618_crowd_nav['it618_name'];
		
		if($it618_crowd_nav['it618_target']==1)$it618_target=' target="_blank"';else $it618_target='';
		
		$str_nav.='<a href="'.$it618_crowd_nav['it618_url'].'"'.$it618_target.'>'.$tmpname.'</a>';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_crowd/kefu.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/kefu.php';
	
	if($it618_qq!=''){
		$qqarr=explode(",",$it618_qq);
		$wxarr=explode(",",$it618_wx);
		$qqnamearr=explode(",",$it618_title);
		for($i=0;$i<count($qqarr);$i++)
		{
			if($qqarr[$i]!='')$shopqq.='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:'.$qqarr[$i].':52" align="absmiddle"/>'.$qqnamearr[$i].'</a> ';
			
			$rightqq.='<h3>'.$qqnamearr[$i].'</h3>
			<ul>
				<li><span>'.$it618_crowd_lang['s645'].'</span>
				<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:'.$qqarr[$i].':51" align="absmiddle"/></a><br><span>'.$it618_crowd_lang['s646'].'</span>'.$wxarr[$i].'
				</li>
			</ul>';
			
		}
	}
}

$crowd_kefu = $it618_crowd['crowd_kefu'];
$crowd_kefu=explode(",",$crowd_kefu);

?>