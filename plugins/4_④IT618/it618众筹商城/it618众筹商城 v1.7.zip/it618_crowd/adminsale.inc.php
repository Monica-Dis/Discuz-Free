<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $title;
$title='sale';
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/adminheader.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_crowd/js/Calendar.js"></script>
<link rel="stylesheet" href="source/plugin/it618_crowd/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_crowd/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_crowd/js/jquery.js"></script>

<script>
function savekd(){
	var saleid=document.getElementById("saleid").value;
	var it618_kdid=document.getElementById("it618_kdid").value;
	var it618_kdid=it618_kdid.replace("selected=selected","");
	var it618_kddan=document.getElementById("it618_kddan").value;
	if(it618_kdid==0){
		sendmsg(\'kdtips\',\''.it618_crowd_getlang('s695').'\');
		return;
	}
	if(it618_kddan==""){
		sendmsg(\'kdtips\',\''.it618_crowd_getlang('s696').'\');
		return;
	}
	
	IT618_CROWD.get("'.$_G['siteurl'].'plugin.php?id=it618_crowd:ajax&saleid="+saleid+"&it618_kdid="+it618_kdid+"&it618_kddan="+it618_kddan+"&formhash='.FORMHASH.'", {ac:"savekd"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		alert(tmparr[1]);
		getsalelist(saleurl);
		dialog_fahuo.remove();
	}else{
		sendmsg(\'kdtips\',tmparr[1]);
	}
	}, "html");

}

var dialog_salebz,salebzid=0;
KindEditor.ready(function(K) {K(\'#salebz\').click(function() {
	getsalebz(K);
});});

function setsalebz(saleid){
	if(salebzid==0){
		salebzid=saleid;
		IT618_CROWD("#salebz").click();
	}
}

function getsalebz(K){
IT618_CROWD.get("'.$_G['siteurl'].'plugin.php?id=it618_crowd:salebz"+"&saleid="+salebzid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	dialog_salebz = K.dialog({
		width : 520,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.$it618_crowd_lang['t285'].'\',
			click : function(e) {
				dialog_salebz.remove();
				salebzid=0;
			}
		}
	});
	
	IT618_CROWD(\'.ns-sub-a\').click(function(){
		
		if(it618_content=document.getElementById("bzvalue").value==\'\'){
			alert("'.$it618_crowd_lang['s1781'].'");
			return;
		}

		IT618_CROWD.post("'.$_G['siteurl'].'plugin.php?id=it618_crowd:ajax"+"&ac=salebz&saleid="+salebzid+"&formhash='.FORMHASH.'",IT618_CROWD("#it618_salebz").serialize(),function (data, textStatus){
			var tmparr=data.split("it618_split");
		
			if(tmparr[0]=="ok"){
				alert(tmparr[1]);
				dialog_salebz.remove();
				getsalelist(saleurl);
				salebzid=0;
			}else{
				alert(data);
			}
		}, "html");
	})
	
	IT618_CROWD(\'.ns-sub-b\').click(function(){
		dialog_salebz.remove();
		salebzid=0;
	})
	
	}, "html");		
}

function sendmsg(msgid,msgvalue){
	document.getElementById(msgid).innerHTML=msgvalue;
	setTimeout(\'sendmsg1("\'+msgid+\'")\',3000);
}
function sendmsg1(msgid){
	document.getElementById(msgid).innerHTML="";
}
</script>
';

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$jfidstrtmp.='<option value='.$i.'>'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}

showtableheaders(it618_crowd_getlang('s413'),'it618_crowd_sum');

	echo '<tr><td colspan="15" style="background-color:#f9f9f9;"><span id="salebz"></span><div class="fixsel">'.it618_crowd_getlang('t12').' <input id="pname" class="txt" style="width:231px;margin-right:1px" /> '.it618_crowd_getlang('s131').' <input id="finduid" class="txt" style="width:76px" /><br>'.it618_crowd_getlang('s379').' <select id="saletype"><option value=0>'.it618_crowd_getlang('s380').'</option><option value=1>'.it618_crowd_getlang('s381').'</option><option value=2>'.it618_crowd_getlang('s382').'</option></select> '.it618_crowd_getlang('s402').' <select id="jfid"><option value=0>'.it618_crowd_getlang('s380').'</option>'.$jfidstrtmp.'</select> '.it618_crowd_getlang('t12').' <select id="state"><option value=0>'.it618_crowd_getlang('t14').'</option><option value=1>'.it618_crowd_getlang('t15').'</option><option value=2>'.it618_crowd_getlang('t16').'</option><option value=3>'.it618_crowd_getlang('t17').'</option></select>'.it618_crowd_getlang('t6').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_crowd_getlang('s132').'" onclick="findsalelist()" /> <input type="button" class="btn" value="'.it618_crowd_getlang('s133').'" onclick="dao()" /> </div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>';
	
	showsubtitle(array(it618_crowd_getlang('s219'),it618_crowd_getlang('s220'),it618_crowd_getlang('s221'),it618_crowd_getlang('s222'),it618_crowd_getlang('s223'),it618_crowd_getlang('s224'),it618_crowd_getlang('s228')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_crowd/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr>';

showtablefooter();/*Dism��taobao��com*/
echo '
<script>
var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_crowd:ajax";
var sqlurl="";
function getsalelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_CROWD.post(url+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_CROWD("#tr_salesum").html(tmparr[0]);
	IT618_CROWD("#tr_salelist").html(tmparr[1]);
	IT618_CROWD("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
getsalelist(saleurl);

function findsalelist(){
	var pname = document.getElementById("pname").value;
	var finduid = document.getElementById("finduid").value;
	var state = document.getElementById("state").value;
	var saletype = document.getElementById("saletype").value;
	var jfid = document.getElementById("jfid").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&pname="+pname+"&finduid="+finduid+"&state="+state+"&saletype="+saletype+"&jfid="+jfid+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_crowd:ajax";
	getsalelist(url);
}

function dao(){
	findsalelist();
	IT618_CROWD.get(saleurl+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_dao"},function (data, textStatus){
	window.open(data);
	}, "html");	
}
</script>

</body></html>
';
?>