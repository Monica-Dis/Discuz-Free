<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/crowd_default.func.php';

if($it618_crowd['crowd_wap']==1){
	if(crowd_is_mobile()){ 
		$tmpurl=it618_crowd_getrewrite('crowd_wap','','plugin.php?id=it618_crowd:wap');
		dheader("location:$tmpurl");
	}
}

$tmpidsarr=explode(',',$hotclassgoods[0]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_crowd_class2=C::t('#it618_crowd#it618_crowd_class2')->fetch_by_id($id);
	$tmpurl=it618_crowd_getrewrite('crowd_list',$it618_crowd_class2['it618_class1_id'].'@'.$id,'plugin.php?id=it618_crowd:list&class1='.$it618_crowd_class2['it618_class1_id'].'&class2='.$id);
	$homehotclass.='<li><a href="'.$tmpurl.'">'.$it618_crowd_class2['it618_classname'].'</a></li>';
}

$query = DB::query("SELECT it618_class2_id,sum(it618_views) as views FROM ".DB::table('it618_crowd_goods')." GROUP BY it618_class2_id ORDER BY views desc LIMIT 0, 10");
while($it618_tmp = DB::fetch($query)) {
	$it618_crowd_class2=C::t('#it618_crowd#it618_crowd_class2')->fetch_by_id($it618_tmp['it618_class2_id']);
	$tmpurl=it618_crowd_getrewrite('crowd_list',$it618_crowd_class2['it618_class1_id'].'@'.$id,'plugin.php?id=it618_crowd:list&class1='.$it618_crowd_class2['it618_class1_id'].'&class2='.$id);
	$homeviewsclass.='<li><a href="'.$tmpurl.'">'.$it618_crowd_class2['it618_classname'].'</a></li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_crowd_gonggao = DB::fetch($query)) {
	$it618_title=$it618_crowd_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,80,'...');
	
	if($it618_crowd_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_crowd_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_crowd_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_crowd_gonggao['it618_url'].'" title="'.$it618_crowd_gonggao['it618_title'].'" target="_blank"><div>'.$it618_title.'</div></a></td></tr>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_tj')." where it618_order<>0 ORDER BY it618_order limit 0,3");
while($it618_crowd_tj = DB::fetch($query)) {
	$it618_title=$it618_crowd_tj['it618_title'];
	$it618_title=cutstr($it618_title,32,'...');
	
	if($it618_crowd_tj['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_crowd_tj['it618_color']!=''){
		$it618_title='<font color="'.$it618_crowd_tj['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_tj.='<li><a href="'.$it618_crowd_tj['it618_url'].'" title="'.$it618_crowd_tj['it618_title'].'" target="_blank">'.$it618_title.'</a></li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_sale')." where it618_code!='' ORDER BY it618_time desc limit 0,30");
while($it618_crowd_sale = DB::fetch($query)) {
	$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
	$pname='('.$it618_crowd_lang['s21'].$it618_crowd_sale['it618_crowdid'].$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
	$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
	
	$salestr.='<li><span><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'"></a></span><p>'.it618_crowd_getusername($it618_crowd_sale['it618_uid']).' '.it618_crowd_gettime($it618_crowd_sale['it618_time']).' '.it618_crowd_getlang('s649').'<a href="'.$tmpurl.'" title="'.$pname.'" target="_blank">'.$pname.'</a></p></li>';
}

$tomonth = date('n'); 
$todate = date('j'); 
$toyear = date('Y');
$time=mktime(0, 0, 0, $tomonth, 1, $toyear);

$n=1;
$query = DB::query("SELECT it618_uid,sum(it618_group) as it618_groupsum FROM ".DB::table('it618_crowd_crowdsale_grouplog')." where it618_time>=$time group by it618_uid ORDER BY it618_groupsum desc limit 0,30");
while($it618_crowd_crowdsale_group = DB::fetch($query)) {
	$monthgroupstr.='<li><span><a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale_group['it618_uid']).'" target="_blank"><img src="'.it618_crowd_discuz_uc_avatar($it618_crowd_crowdsale_group['it618_uid'],'small').'"></a></span><p><span style="float:right;margin-top:10px;color:#999;width:auto">'.$it618_crowd_lang['s392'].'<font color=red>'.$n.'</font>'.$it618_crowd_lang['s393'].'</span>'.it618_crowd_getusername($it618_crowd_crowdsale_group['it618_uid']).'<br><font color=#F60>'.$it618_crowd_crowdsale_group['it618_groupsum'].'</font> <font color=#999>'.$it618_crowd_lang['s400'].'</font></p></li>';
	$n=$n+1;
}

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_crowd_crowdsale_group')." ORDER BY it618_groupsum desc limit 0,30");
while($it618_crowd_crowdsale_group = DB::fetch($query)) {
	$groupstr.='<li><span><a href="'.it618_crowd_rewriteurl($it618_crowd_crowdsale_group['it618_uid']).'" target="_blank"><img src="'.it618_crowd_discuz_uc_avatar($it618_crowd_crowdsale_group['it618_uid'],'small').'"></a></span><p><span style="float:right;margin-top:10px;color:#999;width:auto">'.$it618_crowd_lang['s392'].'<font color=red>'.$n.'</font>'.$it618_crowd_lang['s393'].'</span>'.it618_crowd_getusername($it618_crowd_crowdsale_group['it618_uid']).'<br><font color=#F60>'.$it618_crowd_crowdsale_group['it618_groupsum'].'</font> <font color=#999>'.$it618_crowd_lang['s400'].'</font></p></li>';
	$n=$n+1;
}

$tmpidsarr=explode(',',$hotclassgoods[2]);
$n=1;
for($i=1;$i<=count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i-1]);
	$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($id);
	if($it618_crowd_goods['it618_state']==1){
		if($n%2>0){$homehotgoods.='<li>';$tmpfloat='fl';}else{$tmpfloat='fr';}
		
		if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
			$pricecount=$it618_crowd_sale['it618_pricecount'];
			$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
			$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_sale['it618_price'];
		}else{
			$pricecount=$it618_crowd_goods['it618_pricecount'];
			$pricecount1=0;
			$pricecount2=$pricecount;
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_goods['it618_price'];
			
			if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
			}
		}
		
		if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;
		
		if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
		}
		
		$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
		
		$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
		$homehotgoods.='<div class="big-goods '.$tmpfloat.'">
							  <a class="big-goods-img" href="'.$tmpurl.'" target="_blank"><img src="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" alt="'.$it618_name.'" width="340" height="276" /><span class="big-goods-place">'.$it618_crowd_goods['it618_description'].'</span></a>
							  <div class="big-goods-info">
								  <h3>
									  <span class="ti"><a class="big-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_name.'">'.$it618_name.'</a></span>
								  </h3>
								  <div class="big-goods-price">
										<div class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></div>
										<table class="graphtable"><tr>
										<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
										<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
										<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
										</tr></table>
								  </div>
							  </div>
						  </div>';
		if($n==count($tmpidsarr)||$n%2==0)$homehotgoods.='</li>';
		$n=$n+1;
	}
}

foreach(C::t('#it618_crowd#it618_crowd_focus')->fetch_all_by_type_order(17) as $it618_crowd_focus) {
	if($it618_crowd_focus['it618_url']!=''){
		$str_focus.='<li><a href="'.$it618_crowd_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="705" height="358" /></a></li>';
	}else{
		$str_focus.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="705" height="358" /></li>';
	}
}

foreach(C::t('#it618_crowd#it618_crowd_focus')->fetch_all_by_type_order(3) as $it618_crowd_focus) {
	if($it618_crowd_focus['it618_url']!=''){
		$str_focus3.='<li><a href="'.$it618_crowd_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="256" /></a></li>';
	}else{
		$str_focus3.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="256" /></li>';
	}
}

foreach(C::t('#it618_crowd#it618_crowd_focus')->fetch_all_by_type_order(4) as $it618_crowd_focus) {
	if($it618_crowd_focus['it618_url']!=''){
		$str_focus4.='<li><a href="'.$it618_crowd_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="256" /></a></li>';
	}else{
		$str_focus4.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_crowd/images/a.gif" imgsrc="'.$it618_crowd_focus['it618_img'].'" width="223" height="256" /></li>';
	}
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class1')." where it618_img='' ORDER BY it618_order");
while($it618_crowd_class1 = DB::fetch($query1)) {
	$str_classnav.='<li><a href="javascript:void(0);" class="'.$it618_crowd_class1['it618_cssname'].' newga ga">'.$it618_crowd_class1['it618_classnamenav'].'</a></li>';
	
	$tmpurl=it618_crowd_getrewrite('crowd_list',$it618_crowd_class1['id'],'plugin.php?id=it618_crowd:list&class1='.$it618_crowd_class1['id']);
	$str_goods.='<div class="index-floor">
					<h2 class="index-floor-title">
						<i class="'.$it618_crowd_class1['it618_cssname'].'"></i><a class="'.$it618_crowd_class1['it618_cssname'].'" href="'.$tmpurl.'">'.$it618_crowd_class1['it618_classname'].'</a> <span style="color:#f60;padding-left:10px">'.$it618_crowd_lang['t103'].'</span>
						<div class="fr">
							{it618classtj}
							<a href="'.$tmpurl.'" target="_blank">'.it618_crowd_getlang('s466').'&nbsp;<em>&gt;&gt;</em></a>
						</div>
					</h2>
					<div class="index-goods-list cl">
						{it618goods}
					</div>
					<div class="floor-more"><a href="'.$tmpurl.'">'.it618_crowd_getlang('s467').$it618_crowd_class1['it618_classname'].'&nbsp;&gt;&gt;</a></div>
				</div>';
	$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_crowd_class2')." where it618_class1_id=".$it618_crowd_class1['id']." ORDER BY it618_order");
	$it618classtj='';
	while($it618_crowd_class2 = DB::fetch($query2)) {
		if($it618_crowd_class2['it618_color']!="")
		$tmpname='<font color='.$it618_crowd_class2['it618_color'].'>'.$it618_crowd_class2['it618_classname'].'</font>';else $tmpname=$it618_crowd_class2['it618_classname'];
		
		$tmpurl=it618_crowd_getrewrite('crowd_list',$it618_crowd_class1['id'].'@'.$it618_crowd_class2['id'],'plugin.php?id=it618_crowd:list&class1='.$it618_crowd_class1['id'].'&class2='.$it618_crowd_class2['id']);
		if($it618_crowd_class2['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'" target="_blank">'.$tmpname.'</a><span></span>';

		if($i1ii1[5]!='_')return;
	}
	
	$it618goods='';
	foreach(C::t('#it618_crowd#it618_crowd_goods')->fetch_all_by_search(
		'it618_state=1','jiexiao',$it618_crowd_class1['id'],0,'',0,0,$startlimit,$it618_crowd_class1['it618_goodscount']
	) as $it618_crowd_goods) {
		
		$jfidstr=$_G['setting']['extcredits'][$it618_crowd_goods['it618_jfid']]['title'];
		
		if($it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_pid_state($it618_crowd_goods['id'])){
			$pricecount=$it618_crowd_sale['it618_pricecount'];
			$pricecount1=$pricecount-$it618_crowd_goods['it618_pricecount_find'];
			$pricecount2=$it618_crowd_goods['it618_pricecount_find'];
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_sale['it618_price'];
		}else{
			$pricecount=$it618_crowd_goods['it618_pricecount'];
			$pricecount1=0;
			$pricecount2=$pricecount;
			$pricecountbl=$pricecount1/$pricecount*100;
			$price=$it618_crowd_goods['it618_price'];
			
			if($pricecount!=$it618_crowd_goods['it618_pricecount_find']){
				DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_pricecount_find=".$pricecount." where id=".$it618_crowd_goods['id']);
			}
		}
		
		if($pricecountbl>0&&$pricecountbl<1)$pricecountbl=1;
		
		if($price!=$it618_crowd_goods['it618_price_sale']||$pricecount!=$it618_crowd_goods['it618_pricecount_sale']){
			DB::query("UPDATE ".DB::table('it618_crowd_goods')." SET it618_price_sale=".$price.",it618_pricecount_sale=".$pricecount." where id=".$it618_crowd_goods['id']);
		}
		
		$it618_name='('.$it618_crowd_lang['s21'].($it618_crowd_goods['it618_salecount']+1).$it618_crowd_lang['s22'].')'.$it618_crowd_goods['it618_name'];
		
		$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
		$it618goods.='<div class="index-goods">
							<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
								<img class="dynload lsSwitchload" imgsrc="'.it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']).'" src="source/plugin/it618_crowd/images/a.gif" alt="'.$it618_name.'"/>
								<span class="index-goods-place">'.$it618_crowd_goods['it618_description'].'</span>
							</a>
							<h3>
								<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_name.'">'.$it618_name.'</a>
							</h3>
							<div class="index-goods-info">
								<span style="float:right">'.$price.$jfidstr.'</span>'.$it618_crowd_lang['s20'].$it618_crowd_goods['it618_count'].'
								<div class="graphdiv"><span class="orange" style="width:'.$pricecountbl.'%;"></span></div>
								<table class="graphtable"><tr>
								<td class="td1"><span>'.$pricecount1.'</span><br>'.$it618_crowd_lang['s26'].'</td>
								<td class="td2"><span>'.$pricecount.'</span><br>'.$it618_crowd_lang['s27'].'</td>
								<td class="td3"><span>'.$pricecount2.'</span><br>'.$it618_crowd_lang['s28'].'</td>
								</tr></table>
							</div>
						</div>';
		
		if($i1ii1[6]!='c')return;
	}
	
	$str_goods=str_replace("{it618classtj}",$it618classtj,$str_goods);
	$str_goods=str_replace("{it618goods}",$it618goods,$str_goods);
}

$zjsalegoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('weeksalegoods');
$newgoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('newgoods');
$hotgoods=C::t('#it618_crowd#it618_crowd_set')->getsetvalue_by_setname('hotgoods');

$tmparr=explode(",",$zjsalegoods);
if(count($tmparr)>2){
	$zjsalegoods_count=$tmparr[0];
	$zjsalegoods_order=$tmparr[2];
}else{
	$zjsalegoods_count=15;
	$zjsalegoods_order=1;
}

$tmparr=explode(",",$weeksalegoods);
if(count($tmparr)>2){
	$weeksalegoods_count=$tmparr[0];
	$weeksalegoods_order=$tmparr[2];
}else{
	$weeksalegoods_count=15;
	$weeksalegoods_order=2;
}

$tmparr=explode(",",$newgoods);
if(count($tmparr)>2){
	$newgoods_count=$tmparr[0];
	$newgoods_order=$tmparr[2];
}else{
	$newgoods_count=15;
	$newgoods_order=3;
}

$tmparr=explode(",",$hotgoods);
if(count($tmparr)>2){
	$hotgoods_count=$tmparr[0];
	$hotgoods_order=$tmparr[2];
}else{
	$hotgoods_count=15;
	$hotgoods_order=4;
}

$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newgoods"=>$newgoods_order,"hotgoods"=>$hotgoods_order);
asort($homegoods_arr);

$n=1;
foreach($homegoods_arr as $key=>$homegoods){
	if($n==1)$current=' class="current" ';else $current=' ';
	if($key=='zjsalegoods'){
		if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-new"),\'rc-new\');get_home_goods(\''.$key.'\');</script>';
		$tab_goods.='<span'.$current.' id="span-rc-new" onclick="tabCutover(this,\'rc-new\');get_home_goods(\''.$key.'\');" title="'.$it618_crowd_lang['t90'].'">'.$it618_crowd_lang['t91'].'<i></i></span>';
	}
	
	if($key=='weeksalegoods'){
		if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-week"),\'re-week\');get_home_goods(\''.$key.'\');</script>';
		$tab_goods.='<span'.$current.' id="span-rc-week" onclick="tabCutover(this,\'re-week\');get_home_goods(\''.$key.'\');" title="'.$it618_crowd_lang['t92'].'">'.$it618_crowd_lang['t93'].'<i></i></span>';
	}
	
	if($key=='newgoods'){
		if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-newjf"),\'re-newjf\');get_home_goods(\''.$key.'\');</script>';
		$tab_goods.='<span'.$current.' id="span-re-newjf" onclick="tabCutover(this,\'re-newjf\');get_home_goods(\''.$key.'\');" title="'.$it618_crowd_lang['t312'].'">'.$it618_crowd_lang['s989'].'<i></i></span>';
	}
	
	if($key=='hotgoods'){
		if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-hotjf"),\'re-hotjf\');get_home_goods(\''.$key.'\');</script>';
		$tab_goods.='<span'.$current.' id="span-re-hotjf" onclick="tabCutover(this,\'re-hotjf\');get_home_goods(\''.$key.'\');" title="'.$it618_crowd_lang['t313'].'">'.$it618_crowd_lang['s990'].'<i></i></span>';
	}
	$n=$n+1;

	if($key=='zjsalegoods'){
		$home_goods.='<div class="rc-new" id="home_goods_'.$key.'"></div>';
	}
	
	if($key=='weeksalegoods'){
		$home_goods.='<div class="re-week" id="home_goods_'.$key.'"></div>';
	}
	
	if($key=='newgoods'){
		$home_goods.='<div class="re-newjf" id="home_goods_'.$key.'"></div>';
	}
	
	if($key=='hotgoods'){
		$home_goods.='<div class="re-hotjf" id="home_goods_'.$key.'"></div>';
	}
}

$homegoods_str='<div class="recommend-goods">
		<div class="recommend-title">
			'.$tab_goods.'
		</div>
		<div class="recommend-content">
			'.$home_goods.'
		</div>
		</div>';

$pagetype='index';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:crowd_default');
?>