<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];

require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

$it618_crowd_goods = C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($_GET['shareid']);
$it618_name=$it618_crowd_goods['it618_name'];
$it618_img=it618_crowd_getwapppic('wapgoodspic',$it618_crowd_goods['id'],$it618_crowd_goods['it618_picbig']);
$tmparr=explode('://',$it618_img);
if(count($tmparr)==1)$it618_img=$_G['siteurl'].$it618_img;
$it618_about=$it618_crowd_goods['it618_seodescription'];
$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);

if($_GET['wap']==1){
	$tmpurl=it618_crowd_getrewrite('crowd_wap','product@'.$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:wap&pagetype=product&cid='.$it618_crowd_goods['id']);
}else{
	$tmpurl=it618_crowd_getrewrite('crowd_product',$it618_crowd_goods['id'],'plugin.php?id=it618_crowd:product&pid='.$it618_crowd_goods['id']);
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:share');
?>