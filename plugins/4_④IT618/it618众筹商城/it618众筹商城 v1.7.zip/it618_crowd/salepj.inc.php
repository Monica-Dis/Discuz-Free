<?php
 
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_crowd = $_G['cache']['plugin']['it618_crowd'];
require_once DISCUZ_ROOT.'./source/plugin/it618_crowd/function.func.php';

$it618_crowd_sale=C::t('#it618_crowd#it618_crowd_sale')->fetch_by_id($_GET['saleid']);
$it618_crowd_goods=C::t('#it618_crowd#it618_crowd_goods')->fetch_by_id($it618_crowd_sale['it618_pid']);
$pjname=C::t('#it618_crowd#it618_crowd_class1')->fetch_it618_pj_by_id($it618_crowd_goods['it618_class1_id']);
$pjname=explode("_",$pjname);

$tmpstr1=$it618_crowd_lang['t288'];
if($it618_crowd_sale['it618_score1']>0){
	$tmpstr=$it618_crowd_lang['s786'];
	$tmpstr1=$it618_crowd_lang['t339'];
	if($_GET['wap']==1){
		$tmpstr2='document.getElementById("score1").options['.$it618_crowd_sale['it618_score1'].'].selected = true;
				  document.getElementById("score2").options['.$it618_crowd_sale['it618_score2'].'].selected = true;
				  document.getElementById("score3").options['.$it618_crowd_sale['it618_score3'].'].selected = true;
				  document.getElementById("score4").options['.$it618_crowd_sale['it618_score4'].'].selected = true;';
	}else{
		$tmpstr2='IT618_CROWD(\'.sp_a\').children().eq('.($it618_crowd_sale['it618_score1']-1).').click();
				  IT618_CROWD(\'.sp_b\').children().eq('.($it618_crowd_sale['it618_score2']-1).').click();
				  IT618_CROWD(\'.sp_c\').children().eq('.($it618_crowd_sale['it618_score3']-1).').click();
				  IT618_CROWD(\'.sp_d\').children().eq('.($it618_crowd_sale['it618_score4']-1).').click();';
	}
}

$it618_crowd_sale['it618_content']=str_replace("[br]","\n",$it618_crowd_sale['it618_content']);

$pname=$it618_crowd_goods['it618_name'].' '.$it618_crowd_goods['it618_mealname'];

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_crowd:salepj');
?>