<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_it618_ad {
	
	function global_header_mobile(){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
		return it618_hook_wap('global_header_mobile');
	}
	
	function global_footer_mobile(){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
		return it618_hook_wap('global_footer_mobile');
	}

}

class mobileplugin_it618_ad_forum {
	
	function index_top_mobile(){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
		return it618_hook_wap('index_top_mobile');
	}
	
	function index_middle_mobile(){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
		return it618_hook_wap('index_middle_mobile');
	}
	
	function forumdisplay_top_mobile(){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
		return it618_hook_wap('forumdisplay_top_mobile');
	}
	
	function forumdisplay_bottom_mobile(){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
		return it618_hook_wap('forumdisplay_bottom_mobile');
	}
	
	function viewthread_top_mobile(){
		global $_G;
		if($_G['tid']>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
			$uid=DB::result_first("select authorid from ".DB::table('forum_thread')." where tid=".$_G['tid']);
			return it618_hook_wap('viewthread_top_mobile',0,$_G['tid'],$uid);
		}
	}
	
	function viewthread_bottom_mobile(){
		global $_G;
		if($_G['tid']>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
			$uid=DB::result_first("select authorid from ".DB::table('forum_thread')." where tid=".$_G['tid']);
			return it618_hook_wap('viewthread_bottom_mobile',0,$_G['tid'],$uid);
		}
	}
	
	function post_bottom_mobile(){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
		return it618_hook_wap('post_bottom_mobile');
	}
	
	function viewthread_posttop_mobile_output(){
		global $_G,$postlist;
		if($_G['tid']>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
			
			$n=1;
			foreach($postlist as $id => $post) {
				$tmparr[] =it618_hook_wap('tiecontent_top',$n,$_G['tid'],$postlist[$id]['authorid']);
				$n=$n+1;
			}
			
			return $tmparr;
		}
	}
	
	function viewthread_postbottom_mobile_output(){
		global $_G,$postlist;
		if($_G['tid']>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
			
			$n=1;
			foreach($postlist as $id => $post) {
				$tmparr[] =it618_hook_wap('tiecontent_bottom',$n,$_G['tid'],$postlist[$id]['authorid']);
				$n=$n+1;
			}
			
			return $tmparr;
		}
	}
}

class mobileplugin_it618_ad_member {
	
	function logging_bottom_mobile(){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
		return it618_hook_wap('logging_bottom_mobile');
	}
}
//From: dis'.'m.tao'.'bao.com
?>