<?php
  /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_ad = $_G['cache']['plugin']['it618_ad'];
$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_ad/lang.func.php';

$uid = $_G['uid'];
$ad_usergroup=(array)unserialize($it618_ad['ad_usergroup']);
if(!in_array($_G['groupid'], $ad_usergroup)){
	showmessage(it618_ad_getlang('s62'), '', array(), array('alert' => 'error'));
}
if($uid<=0){
	showmessage(it618_ad_getlang('s63'), '', array(), array('alert' => 'error'));	
}else{
	if($_GET['ac']=='xf'){
		$saleid=intval($_GET['saleid']);
		$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$saleid);
		$it618_ad_ad = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$it618_ad_sale['it618_aid']);
		$pid=$it618_ad_sale['it618_pid'];
		
		$saletitle=$it618_ad_lang['s248'];
	}else{
		$aid=intval($_GET['aid']);
		$pid=intval($_GET['pid']);
		$it618_ad_ad=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$aid);
		
		$saletitle=$it618_ad_lang['t78'];
	}
	
	$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
	$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$_G['uid']);
	$creditnum=DB::result_first("select extcredits".$it618_ad['ad_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	
	$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_sale')." WHERE it618_aid=".$it618_ad_ad['id']);

	if(count($liil1i)!=8)return;
	$aidstr=$it618_ad_ad['id'];
	if($it618_ad_ad['it618_adtype']==1)$it618_adtype=it618_ad_getlang('s64');
	if($it618_ad_ad['it618_adtype']==2)$it618_adtype=it618_ad_getlang('s65');
	if($it618_ad_ad['it618_adtype']==3)$it618_adtype=it618_ad_getlang('s221');
	if($it618_ad_ad['it618_adtype']==4){
		$aidstr=$it618_ad_ad['id'].'-'.$pid;
		if($it618_ad_ad['it618_isrand']==1){
			$it618_isrand=$it618_ad_lang['t5'];
		}else{
			$it618_isrand='';
		}
		$foucscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_ad_focus')." WHERE it618_order<>0 and it618_aid=".$it618_ad_ad['id']);
		$it618_adtype=it618_ad_getlang('s255').' '.it618_ad_getlang('s267').$foucscount.it618_ad_getlang('s266').' '.$it618_isrand;
		
		$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_sale')." WHERE it618_aid=".$it618_ad_ad['id']." and it618_pid=".$pid);
	}
	
	$it618_blockname=str_replace("it618ad_","",$it618_ad_ad['it618_blockname']);
	if($it618_blockname=='global_header'){
		$it618_blockname=$it618_ad_lang['s304'];
	}
	
	if($it618_ad_ad['it618_saletype']==2){
		showmessage(it618_ad_getlang('s66'), '', array(), array('alert' => 'info'));
	}
	
	if($it618_ad_ad['it618_pricetype']==1)$it618_pricetype=it618_ad_getlang('s33');
	if($it618_ad_ad['it618_pricetype']==2)$it618_pricetype=it618_ad_getlang('s223');
	if($liil1i[7]!='d')return;
	
	if($it618_ad_ad['it618_count1']>0){
		$it618_count=' '.it618_ad_getlang('s245').'<font color=red>'.$it618_ad_ad['it618_count1'].'</font>'.$it618_pricetype;
	}
	
	if($it618_ad_ad['it618_count2']>0){
		$it618_count.=' '.it618_ad_getlang('s246').'<font color=red>'.$it618_ad_ad['it618_count2'].'</font>'.$it618_pricetype;
	}
	
	if($it618_count!='')$it618_count=it618_ad_getlang('s247').$it618_count;
	
	$it618_price=$it618_ad_ad['it618_price']*$it618_ad_ad['it618_count'];
}

$ad_buytimetip=str_replace("{buytime}",$it618_ad['ad_buytime'],$it618_ad['ad_buytimetip']);
include template('it618_ad:showsale');
?>