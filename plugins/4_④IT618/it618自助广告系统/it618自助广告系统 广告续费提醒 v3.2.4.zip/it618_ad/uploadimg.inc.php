<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$it618_ad = $_G['cache']['plugin']['it618_ad'];
require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';

$saleid=intval($_GET['saleid']);

if($it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$saleid)){
	if(isset($_GET['admin'])){
		$ad_adminuid=explode(",",$it618_ad['ad_adminuid']);
		$urladmin='&admin';
		if(!in_array($_G['uid'],$ad_adminuid)){
			$errstr=$it618_ad_lang['s364'];
		}
	}else{
		if($it618_ad_sale['it618_uid']!=$_G['uid']){
			$errstr=$it618_ad_lang['s251'];
		}
	}
	$it618_ad_ad = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$it618_ad_sale['it618_aid']);
}else{
	$errstr=$it618_ad_lang['s60'];
}

if(submitcheck('mysubmit')){
	
	if($_FILES['it618_upfile']['error']==0){

		$tmparr=explode(".", $_FILES["it618_upfile"]["name"]);
		$filetype=strtolower($tmparr[count($tmparr)-1]);
		
		if($it618_ad_ad['it618_adtype']==1||$it618_ad_ad['it618_adtype']==4){
			if(!in_array($filetype, array("jpg","jpeg","gif","png"))){
				$errstr=it618_ad_getlang('s299');
			}
			
			if($_FILES['it618_upfile']['size']/1024>$it618_ad['ad_maximg']){ 
				$errstr=it618_ad_getlang('s300');
			}
		}else{
			if(!in_array($filetype, array("swf"))){
				$errstr=it618_ad_getlang('s301');
			}
			
			if($_FILES['it618_upfile']['size']/1024>$it618_ad['ad_maxflash']){ 
				$errstr=it618_ad_getlang('s302');
			}
		}
			
		if($errstr==''){
			$filepath = "source/plugin/it618_ad/img/";
			$filename = "adimg".$saleid.".".$filetype;

			if(@copy($_FILES['it618_upfile']['tmp_name'], $filepath.$filename) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['it618_upfile']['tmp_name'], $filepath.$filename))) {
				@unlink($_FILES['it618_upfile']['tmp_name']);
				
				$tmparr=@getimagesize($filepath.$filename);
				if($tmparr === FALSE){

					if($filetype=='gif'||$filetype=='jpg'||$filetype=='jpeg'||$filetype=='png'){
						if(file_exists($filepath.$filename)){
							$result=unlink($filepath.$filename);
						}
						echo 'err';exit;
					}
				}else{
					$imgwidth=3000;
					it618_ad_imagetosmall($filepath.$filename,$imgwidth);
				}
				
				@chmod($file_path, 0644);
				
				if($it618_ad_sale['it618_uploadimg']!=$_G['siteurl'].$filepath.$filename){
					$tmparr=explode("source",$it618_ad_sale['it618_uploadimg']);
					$it618_uploadimg=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_uploadimg)){
						$result=unlink($it618_uploadimg);
					}
				}
				
				C::t('#it618_ad#it618_ad_sale')->update($saleid,array(
					'it618_uploadimg' => $_G['siteurl'].$filepath.$filename.'?'.substr(md5($_G['timestamp']),0,6)
				));
				
				$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$saleid);
			}
		}
	}else{
		$errstr=$it618_ad_lang['s303'];
	}
}

include template('it618_ad:uploadimg');
?>