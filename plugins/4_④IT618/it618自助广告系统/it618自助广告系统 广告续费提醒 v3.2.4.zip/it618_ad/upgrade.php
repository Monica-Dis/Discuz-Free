<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_ad/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_ad/rewrite.php',DISCUZ_ROOT.'./source/plugin/it618_ad/config/rewrite.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_ad/message.php',DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_ad_xf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_price` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_buytime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_ad_onepage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_ad_adblock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_width` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_height` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_margin_top` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_margin_bottom` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_margin_left` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_margin_right` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bordertype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_bordercolor` varchar(10) NOT NULL,
  `it618_bgcolor` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_ad_ad_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_price` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_ad_wap_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_blockname` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_lou` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_row` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_padding_top` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_padding_bottom` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isrand` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_speed` int(10) unsigned NOT NULL DEFAULT '5000',
  `it618_isnofollow` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_adtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_ad_wap_ad_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_ad_wap_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_etime` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_ad_ad'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_row', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_row` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_col', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_col` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_isrand', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_isrand` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_padding_top', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_padding_top` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_padding_bottom', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_padding_bottom` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_padding_left', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_padding_left` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_padding_right', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_padding_right` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_pricetype', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_pricetype` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_count', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_count` int(10) unsigned NOT NULL default 30;"; 
	DB::query($sql); 
}
if(!in_array('it618_count1', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_count1` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_count2', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_count2` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_isnofollow', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_isnofollow` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_isnoprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_isnoprice` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_speed', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_speed` int(10) unsigned NOT NULL default 8000;"; 
	DB::query($sql); 
}
if(!in_array('it618_ison', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_ison` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_url', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_url` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_fontalign', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_fontalign` int(10) unsigned NOT NULL default 2;"; 
	DB::query($sql); 
}
if(!in_array('it618_fontsize', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_fontsize` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_fontcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_ad')." add `it618_fontcount` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_ad_wap_ad'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_tids', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_wap_ad')." add `it618_tids` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_typids', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_wap_ad')." add `it618_typids` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_fids', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_wap_ad')." add `it618_fids` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_isuser', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_wap_ad')." add `it618_isuser` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_ad_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_pricetype', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_sale')." add `it618_pricetype` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_isfontbold', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_sale')." add `it618_isfontbold` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_pid', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_sale')." add `it618_pid` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_uploadimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_sale')." add `it618_uploadimg` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_tel', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_sale')." add `it618_tel` varchar(50) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_score', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_sale')." add `it618_score` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_adtime1', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_sale')." add `it618_adtime1` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_adtime2', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_sale')." add `it618_adtime2` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_adtime3', $col_field)){
	$sql = "Alter table ".DB::table('it618_ad_sale')." add `it618_adtime3` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>