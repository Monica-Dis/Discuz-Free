<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$it618_ad = $_G['cache']['plugin']['it618_ad'];
$navtitle = $it618_ad['seotitle'];
$metakeywords = $it618_ad['seokeywords'];
$metadescription = $it618_ad['seodescription'];
$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_ad/lang.func.php';

if($_G[uid]<=0){
	showmessage(it618_ad_getlang('s37'));
}
if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;

$ppp = $it618_ad['pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$_G[uid]);

if($_GET['formhash']==FORMHASH){

$adtype0='';$adtype1='';$adtype2='';$adtype3='';$adtype4='';
if($_GET['adtype']==0){$extrasql .= "";$adtype0='selected="selected"';}
if($_GET['adtype']==1){$extrasql .= " AND a.it618_adtype = 1";$adtype1='selected="selected"';}
if($_GET['adtype']==2){$extrasql .= " AND a.it618_adtype = 2";$adtype2='selected="selected"';}
if($_GET['adtype']==3){$extrasql .= " AND a.it618_adtype = 3";$adtype3='selected="selected"';}
if($_GET['adtype']==4){$extrasql .= " AND a.it618_adtype = 4";$adtype4='selected="selected"';}

$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';
if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
if($_GET['state']==1){$extrasql .= " AND s.it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$extrasql .= " AND s.it618_state = 1";$state2='selected="selected"';}
if($_GET['state']==3){$extrasql .= " AND s.it618_state = 2";$state3='selected="selected"';}
if($_GET['state']==4){$extrasql .= " AND s.it618_state = 3";$state4='selected="selected"';}
if($_GET['state']==5){$extrasql .= " AND s.it618_state = 4";$state5='selected="selected"';}
if($_GET['state']==6){$extrasql .= " AND s.it618_state = 5";$state6='selected="selected"';}
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_ad_sale')." s,".DB::table('it618_ad_ad')." a WHERE s.it618_aid=a.id and it618_uid=".$_G[uid]."$extrasql");
if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
$query = DB::query("SELECT s.* FROM ".DB::table('it618_ad_sale')." s,".DB::table('it618_ad_ad')." a WHERE s.it618_aid=a.id and s.it618_uid=".$_G[uid]."$extrasql");
while($it618_ad_sale =DB::fetch($query)) {
	$allsum=$allsum+$it618_ad_sale['it618_price']*$it618_ad_sale['it618_count'];
	$sumtmp=DB::result_first("SELECT sum(it618_price*it618_count) FROM ".DB::table('it618_ad_xf')." WHERE it618_saleid=".$it618_ad_sale['id']);
	$allsum=$allsum+$sumtmp;
}
if($allsum=='')$allsum=0;

$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_ad:ads");
if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
if($it618_ad['ad_autopass']==1){
	$ad_autopassuid=explode(",",$it618_ad['ad_autopassuid']);
	if($it618_ad['ad_autopassuid']=='0'||in_array($_G['uid'], $ad_autopassuid)){
		$ad_autopass=1;
	}
}

if($it618_ad['ad_isedit']==1){
	$ad_isedituid=explode(",",$it618_ad['ad_isedituid']);
	if($it618_ad['ad_isedituid']=='0'||in_array($_G['uid'], $ad_isedituid)){
		$ad_isedit=1;
	}
}

if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
$query = DB::query("SELECT s.*,a.it618_blockname FROM ".DB::table('it618_ad_sale')." s,".DB::table('it618_ad_ad')." a WHERE s.it618_aid=a.id and s.it618_uid=".$_G[uid]." $extrasql order by s.id desc LIMIT $startlimit, $ppp");
while($it618_ad_sale =DB::fetch($query)) {
	
	$it618_ad_ad = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$it618_ad_sale['it618_aid']);
	if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
	$aidstr=$it618_ad_sale['it618_aid'];
	if($it618_ad_ad['it618_adtype']==1)$it618_adtype=$it618_ad_lang['s102'];
	if($it618_ad_ad['it618_adtype']==2)$it618_adtype=$it618_ad_lang['s103'];
	if($it618_ad_ad['it618_adtype']==3)$it618_adtype=$it618_ad_lang['s221'];
	if($it618_ad_ad['it618_adtype']==4){
		$aidstr=$it618_ad_sale['it618_aid'].'-'.$it618_ad_sale['it618_pid'];
		$it618_adtype=$it618_ad_lang['s255'];
	}
	if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
	if($it618_ad_ad['it618_pricetype']==1)$it618_pricetype=it618_ad_getlang('s33');
	if($it618_ad_ad['it618_pricetype']==2)$it618_pricetype=it618_ad_getlang('s223');
	if($it618_ad_sale['it618_state']==0)$it618_state='<font color=blue>'.it618_ad_getlang('s40').'</font>';
	if($it618_ad_sale['it618_state']==1)$it618_state='<font color=red>'.it618_ad_getlang('s41').'</font>';
	if($it618_ad_sale['it618_state']==2)$it618_state='<font color=blue>'.it618_ad_getlang('s42').'</font>';
	if($it618_ad_sale['it618_state']==3)$it618_state='<font color=green>'.it618_ad_getlang('s43').'</font>';
	if($it618_ad_sale['it618_state']==4)$it618_state='<font color=#ccc>'.it618_ad_getlang('s44').'</font>';
	if($it618_ad_sale['it618_state']==5)$it618_state='<font color=#ccc>'.$it618_ad_lang['s366'].'</font>';
	
	if($it618_ad_sale['it618_btime']==0)$it618_btime=it618_ad_getlang('s45');else $it618_btime=date('Y-m-d H:i:s', $it618_ad_sale['it618_btime']);
	if($it618_ad_sale['it618_etime']==0)$it618_etime=it618_ad_getlang('s45');else $it618_etime=date('Y-m-d H:i:s', $it618_ad_sale['it618_etime']);
	if($it618_ad_sale['it618_state']==3)$it618_etime='<font color=green>'.$it618_etime.'</font>';
	if($it618_ad_sale['it618_state']>=4)$it618_etime='<font color=#ccc>'.$it618_etime.'</font>';
	if($it618_ad_sale['it618_btime']==0)$timecount=it618_ad_getlang('s45');
	if($it618_ad_sale['it618_state']==3){
		if($it618_ad_sale['it618_pricetype']==1){
			$timecount='<font color=green><b>'.sprintf("%.2f", ($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600).'</b></font> '.$it618_pricetype;
		}else{
			$timecount='<font color=green><b>'.sprintf("%.2f", ($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600/24).'</b></font> '.$it618_pricetype;
		}
		$timecount.=' <button type="button" class="pn vm" style="width:40px" onclick="showWindow(\'it618_showsale\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showsale&ac=xf&saleid='.$it618_ad_sale['id'].'\')">'.it618_ad_getlang('s244').'</button>';
	}
	if($it618_ad_sale['it618_state']>=4)$timecount='<font color=#ccc>0 '.$it618_pricetype.'</font>';
	
	if($it618_ad_sale['it618_state']==0||$it618_ad_sale['it618_state']==2){
		$adcontent='<button type="button" class="pn vm" style="width:40px" onclick="showWindow(\'it618_showad\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showad&saleid='.$it618_ad_sale['id'].'&ac=post\')">'.it618_ad_getlang('s46').'</button>';
	}elseif($it618_ad_sale['it618_state']==3){
		if($ad_isedit==1){
			$adcontent='<button type="button" class="pn vm" style="width:40px" onclick="showWindow(\'it618_showad\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showad&saleid='.$it618_ad_sale['id'].'&ac=edit\')">'.it618_ad_getlang('s239').'</button>';
		}else{
			$adcontent='<button type="button" class="pn vm" style="width:40px" onclick="showWindow(\'it618_showad\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showad&saleid='.$it618_ad_sale['id'].'&ac=read\')">'.it618_ad_getlang('s47').'</button>';
		}
	}else{
		$adcontent='<button type="button" class="pn vm" style="width:40px" onclick="showWindow(\'it618_showad\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showad&saleid='.$it618_ad_sale['id'].'&ac=read\')">'.it618_ad_getlang('s47').'</button>';
	}
	if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_ad_xf')." WHERE it618_saleid=".$it618_ad_sale['id']);
	if($count>0){
		$xfstr='<span style="float:right;color:#999"><a href="javascript:" style="color:blue" onclick="showWindow(\'it618_showxf\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showxf&saleid='.$it618_ad_sale['id'].'\')"">'.it618_ad_getlang('s256').' <font color=red>'.$count.'</font> '.it618_ad_getlang('s257').'</a></span>';
		$sum=DB::result_first("SELECT sum(it618_price*it618_count) FROM ".DB::table('it618_ad_xf')." WHERE it618_saleid=".$it618_ad_sale['id']);
		$allcount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_ad_xf')." WHERE it618_saleid=".$it618_ad_sale['id']);
	}else{
		$xfstr='';
		$sum=0;
	}
	
	$it618_blockname=str_replace("it618ad_","",$it618_ad_sale['it618_blockname']);
	if($it618_blockname=='global_header'){
		$it618_blockname=$it618_ad_lang['s304'];
	}
	
	$it618_score='';
	if($it618_ad_sale['it618_score']>0){
		$it618_score=' <font color=blue>-'.$it618_ad_sale['it618_score'].'</font> '.$creditname;
	}
	
	if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
	$salelist.='<tr align="center">';
	$salelist.='<td>'.$it618_ad_sale['id'].'</td>';
	$salelist.='<td title="'.$it618_ad_lang['t46'].':'.$aidstr.' '.$it618_ad_lang['s116'].$it618_blockname.' '.$it618_ad_lang['s119'].$it618_ad_ad['it618_title'].'">'.$it618_adtype.'<br><font color=#999>'.$it618_ad_ad['it618_width'].'*'.$it618_ad_ad['it618_height'].'</font></td>';
	$salelist.='<td  title="'.$it618_ad_lang['t46'].':'.$it618_ad_sale['it618_aid'].' '.$it618_ad_lang['s116'].$it618_blockname.' '.$it618_ad_lang['s119'].$it618_ad_ad['it618_title'].'" valign="top" align="left"><font color=#999>'.it618_ad_getlang('s258').'</font><font color=red>'.$it618_ad_sale['it618_price'].'</font> '.$creditname.'/'.$it618_pricetype.' <font color=#999>'.it618_ad_getlang('s259').'</font><font color=red>'.$it618_ad_sale['it618_count'].'</font> '.$it618_pricetype.'<br><font color=#999>'.it618_ad_getlang('s260').'</font><font color=#ccc>'.date('Y-m-d H:i:s', $it618_ad_sale['it618_buytime']).'</font>'.$xfstr.'</td>';
	$salelist.='<td><font color=red>'.($it618_ad_sale['it618_count']+$allcount).'</font> '.$it618_pricetype.'</td>';
	$salelist.='<td><font color=red>'.intval($it618_ad_sale['it618_price']*$it618_ad_sale['it618_count']+$sum).'</font> '.$creditname.$it618_score.'</td>';
	$salelist.='<td><font color=#999>'.$it618_btime.'</font></td>';
	$salelist.='<td>'.$it618_etime.'</td>';
	$salelist.='<td>'.$timecount.'</td>';
	$salelist.='<td>'.$adcontent.'</td>';
	$salelist.='<td>'.$it618_state.'</td>';
	$salelist.='</tr>';
}
if($salelist==''&&$extrasql==''){
	$nosaletip='<div style="margin-top:10px; color:red">'.it618_ad_getlang('s48').'</div>';
}
if($multipage!=''){
	$multipage='<div style="margin-top:10px; margin-bottom:10px;height:30px">'.$multipage.'</div>';
}

if($_GET['saleid']>0){
	$tmpjs='showWindow(\'it618_showad\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showad&saleid='.$_GET['saleid'].'&ac=edit&admin\')';
}

$ad_buytimetip=str_replace("{buytime}",$it618_ad['ad_buytime'],$it618_ad['ad_buytimetip']);

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php';
}

if($it618_body_adtime_user_isok==1){
	$ad_buytimetip=$ad_buytimetip.'<br><br><font color=blue>'.$it618_ad_lang['s559'].'</font>';
}
		
include template('it618_ad:ads');
?>