<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_ad#it618_ad_ad_focus')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_img'])) {
		foreach($_GET['it618_img'] as $id => $val) {

			C::t('#it618_ad#it618_ad_ad_focus')->update($id,array(
				'it618_img' => $_GET['it618_img'][$id],
				'it618_url' => $_GET['it618_url'][$id],
				'it618_order' => $_GET['it618_order'][$id],
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_order_array as $key => $value) {

		C::t('#it618_ad#it618_ad_ad_focus')->insert(array(
			'it618_aid' => $_GET['aid'],
			'it618_order' => $newit618_order_array[$key],
		), true);
		$ok2=$ok2+1;
	}

	cpmsg($it618_ad_lang['s150'].$ok1.' '.$it618_ad_lang['s151'].$ok2.' '.$it618_ad_lang['s152'].$del.')', "action=plugins&identifier=$identifier&cp=admin_ad_focus&pmod=admin_ad&operation=$operation&do=$do&page=$page&aid=".$_GET['aid']."&sql=".$_GET['sql'], 'succeed');
}

$it618_ad_ad=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." WHERE id=".intval($_GET['aid']));

$sql=str_replace("@","&",$_GET['sql']);

showformheader("plugins&identifier=$identifier&cp=admin_ad_focus&pmod=admin_ad&operation=$operation&do=$do&aid=".$_GET['aid']."&sql=".$_GET['sql']);
showtableheaders('<font color=red>'.$it618_ad_ad['it618_title'].' '.$it618_ad_lang['s31'].$it618_ad_ad['id'].'</font> '.$it618_ad_lang['s4'].' <a href="'.ADMINSCRIPT.'?'."action=plugins&identifier=$identifier&cp=admin_ad&pmod=admin_ad&operation=$operation&do=$do&page=$page".$sql.'"><<<'.$it618_ad_lang['s30'].'</a>','it618_ad_ad_focus');
	
	$count = C::t('#it618_ad#it618_ad_ad_focus')->count_by_aid($_GET['aid']);
	
	echo '<tr><td colspan=3>'.$it618_ad_lang['s28'].$count.'<span style="float:right;color:red">'.$it618_ad_lang['s29'].'</span></td></tr>';
	showsubtitle(array('', $it618_ad_lang['s22'],$it618_ad_lang['s95'],$it618_ad_lang['s23']));
	
	foreach(C::t('#it618_ad#it618_ad_ad_focus')->fetch_all_by_aid($_GET['aid']) as $it618_ad_ad_focus) {

		$deldisabled="";
		$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_sale')." WHERE it618_aid=".$it618_ad_ad['id']." and it618_pid=".$it618_ad_ad_focus['id']);
		if($salecount>0)$deldisabled="disabled=\"disabled\"";
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_ad_ad_focus[id]\" $deldisabled>",
			'<img src="'.$it618_ad_ad_focus['it618_img'].'" id="img'.$it618_ad_ad_focus['id'].'" width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url'.$it618_ad_ad_focus['id'].'" name="it618_img['.$it618_ad_ad_focus['id'].']" readonly="readonly" value="'.$it618_ad_ad_focus['it618_img'].'" /> <input type="button" id="image'.$it618_ad_ad_focus['id'].'" value="'.$it618_ad_lang['s32'].'" /><br><input class="txt" type="text" style="width:400px;margin-top:3px" name="it618_url['.$it618_ad_ad_focus['id'].']" value="'.$it618_ad_ad_focus['it618_url'].'">',
			$it618_ad_lang['s236'].'<font color=red>'.$salecount.'</font>',
			'<input class="txt" type="text" style="width:30px;" name="it618_order['.$it618_ad_ad_focus['id'].']" value="'.$it618_ad_ad_focus['it618_order'].'">'
		));
		
		$editorjs.='K(\'#image'.$it618_ad_ad_focus['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_ad_ad_focus['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_ad_ad_focus['id'].'\').val(url);
								K(\'#img'.$it618_ad_ad_focus['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_ad/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_ad/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
$it618_ad_lang184=$it618_ad_lang['s27'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
	
		return [
				[[1,''], [1, '$it618_ad_lang184'], [1, ' <input class="txt" style="width:30px" type="text" name="newit618_order[]" value="1">'], [1,'']]
				];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="5"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=8)return; /*dism_ taobao_ com*/
showtablefooter(); /*dism��taobao��com*/
?>