<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];

$countad = DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_advertisement')." where title LIKE 'it618ad_%'");
$countdiy = DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_block')." where name LIKE 'it618ad_%'");
if(($countad+$countdiy)==0){
	echo $it618_ad_lang['s19'];
	return;
}

$n=1;
$blocktmp='<option value="global_header">'.$it618_ad_lang['s304'].'</option>';
$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_ad')." WHERE it618_blockname='global_header'");
if(isset($_GET['find_blockname'])){
	if($_GET['find_blockname']=='global_header'){
		$licss='class="current"';
		$it618_blockname='global_header';
	}else{
		$licss='';
	}
}elseif(!isset($_GET['noblock'])){
	$licss='class="current"';
	$it618_blockname='global_header';
}
$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_ad&pmod=admin_ad&find_blockname=global_header&operation=$operation&do=$do&page=$page\"><span>".$it618_ad_lang['s304'].'(<font color=red>'.$count.'</font>)</span></a></li>';
$blocksql.="'global_header',";

$licss='';

$query1 = DB::query("SELECT * FROM ".DB::table('common_advertisement')." where title LIKE 'it618ad_%' ORDER BY title");
while($it618_tmp =	DB::fetch($query1)) {
	$tmpname='[AD] '.str_replace("it618ad_","",$it618_tmp['title']);
	$blocktmp.='<option value="'.$it618_tmp['title'].'">'.$tmpname.'</option>';
	
	if(isset($_GET['find_blockname'])){
		if(getfromurl($_GET['find_blockname'])==$it618_tmp['title']){
			$licss='class="current"';
			$it618_blockname=$it618_tmp['title'];
			$blocktype='ad';
		}else{
			$licss='';
		}
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_ad')." WHERE it618_blockname='".$it618_tmp['title']."'");
	
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_ad&pmod=admin_ad&find_blockname=".gettourl($it618_tmp['title'])."&operation=$operation&do=$do&page=$page\"><span>".$tmpname.'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$blocksql.="'".$it618_tmp['title']."',";
	
	$n=$n+1;
}

$query1 = DB::query("SELECT name FROM ".DB::table('common_block')." where name LIKE 'it618ad_%' group by name ORDER BY name");
while($it618_tmp =	DB::fetch($query1)) {
	$tmpname='[DIY] '.str_replace("it618ad_","",$it618_tmp['name']);
	$blocktmp.='<option value="'.$it618_tmp['name'].'">'.$tmpname.'</option>';
	if(isset($_GET['find_blockname'])){
		if(getfromurl($_GET['find_blockname'])==$it618_tmp['name']){
			$licss='class="current"';
			$it618_blockname=$it618_tmp['name'];
			$blocktype='diy';
		}else{
			$licss='';
		}
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_ad')." WHERE it618_blockname='".$it618_tmp['name']."'");
	
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_ad&pmod=admin_ad&find_blockname=".gettourl($it618_tmp['name'])."&operation=$operation&do=$do&page=$page\"><span>".$tmpname.'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$blocksql.="'".$it618_tmp['name']."',";
	
	$n=$n+1;
}

function gettourl($tmpstr){
	$tmpstr = str_replace("(","@6181@",$tmpstr);
	$tmpstr = str_replace(")","@6182@",$tmpstr);
	return $tmpstr;
}

function getfromurl($tmpstr){
	$tmpstr = str_replace("@6181@","(",$tmpstr);
	$tmpstr = str_replace("@6182@",")",$tmpstr);
	return $tmpstr;
}

if($blocksql!=''){
	$blocksql=$blocksql.'@';
	$blocksql=str_replace(",@","",$blocksql);
	
	if(isset($_GET['noblock'])){
		$licss='class="current"';
		$blocktmp='<option value="noblock">'.$it618_ad_lang['s21'].'</option>'.$blocktmp;
	}else{
		$licss='';
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_ad')." WHERE it618_blockname not in(".$blocksql.")");
	if($count>0){
		DB::query("update ".DB::table('it618_ad_ad')." set it618_ison=0,it618_blockname='noblock' WHERE it618_blockname not in(".$blocksql.")");
		$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_ad&pmod=admin_ad&noblock&operation=$operation&do=$do&page=$page\"><span class='noblock'>".$it618_ad_lang['s17'].'</font>(<font color=red>0/'.$count.'</font>)</span></a></li>';
	}
}

echo '<style>.itemtitle1 .current{background-color:#666} .itemtitle1 .noblock{color:blue}</style><div class="itemtitle itemtitle1" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_adblock')." WHERE it618_name='".$it618_blockname."'");
if($count==0){
	C::t('#it618_ad#it618_ad_adblock')->insert(array(
		'it618_name' => $it618_blockname
	), true);
}

$it618_ad_adblock=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_adblock')." WHERE it618_name='".$it618_blockname."'");

if(isset($_GET['noblock'])){
	$extrasql = "it618_blockname not in(".$blocksql.")";	
	$sql='&noblock';
}else{
	$extrasql = "it618_blockname ='".$it618_blockname."'";	
}

if($_GET['find_title']) {
	$extrasql .= " AND it618_title LIKE '%".addcslashes($_GET['find_title'],'%_')."%'";
}
if($_GET['adtype']) {
	$adtype0='';$adtype1='';$adtype2='';$adtype3='';
	if($_GET['adtype']==0){$extrasql .= "";$adtype0='selected="selected"';}
	if($_GET['adtype']==1){$extrasql .= " AND it618_adtype = 1";$adtype1='selected="selected"';}
	if($_GET['adtype']==2){$extrasql .= " AND it618_adtype = 2";$adtype2='selected="selected"';}
	if($_GET['adtype']==3){$extrasql .= " AND it618_adtype = 3";$adtype3='selected="selected"';}
	if($_GET['adtype']==4){$extrasql .= " AND it618_adtype = 4";$adtype4='selected="selected"';}
}
if($_GET['state']) {
	$state0='';$state1='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$extrasql .= " AND it618_saletype = 1";$state1='selected="selected"';}
	if($_GET['state']==2){$extrasql .= " AND it618_saletype = 2";$state2='selected="selected"';}
	if($_GET['state']==3){$extrasql .= " AND it618_state = 0";$state3='selected="selected"';}
	if($_GET['state']==4){$extrasql .= " AND it618_state = 1";$state4='selected="selected"';}
}
if($_GET['orderby']) {
	$orderby0='';$orderby1='';$orderby2='';$orderby3='';
	if($_GET['orderby']==0){$extrasql .= " order by it618_orderby,id desc";$orderby0='selected="selected"';}
	if($_GET['orderby']==1){$extrasql .= " order by it618_salecount desc";$orderby1='selected="selected"';}
	if($_GET['orderby']==2){$extrasql .= " order by it618_width*it618_height desc";$orderby2='selected="selected"';}
	if($_GET['orderby']==3){$extrasql .= " order by it618_price desc";$orderby3='selected="selected"';}
}
$sql.='&find_blockname='.$it618_blockname.'&find_title='.$_GET['find_title'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'].'&adtype='.$_GET['adtype'];


if(submitcheck('it618submitdeldiy')){
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_ad')." WHERE it618_blockname ='".$it618_blockname."'");
	if($count>0){
		cpmsg($it618_ad_lang['s358'].$count.''.$it618_ad_lang['s359'], "action=plugins&identifier=$identifier&cp=admin_ad&pmod=admin_ad&operation=$operation&do=$do&page=$page".$sql, 'error');
	}else{
		if($blocktype=='diy'){
			DB::query("delete FROM ".DB::table('common_block')." where name ='".$it618_blockname."'");
		}else{
			DB::query("delete FROM ".DB::table('common_advertisement')." where title ='".$it618_blockname."'");
		}
		cpmsg($it618_ad_lang['s360'], "action=plugins&identifier=$identifier&cp=admin_ad&pmod=admin_ad&operation=$operation&do=$do&page=$page".$sql, 'succeed');	
	}
}

if(submitcheck('it618submit')){
	$del=0;
	$ok=0;
	if($reabc[7]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_ad_ad', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_title'])) {
		foreach($_GET['it618_title'] as $id => $val) {
			if(intval($_GET['it618_row'][$id])==0)$it618_row=1; else$it618_row=intval($_GET['it618_row'][$id]);
			if(intval($_GET['it618_col'][$id])==0)$it618_col=1; else$it618_col=intval($_GET['it618_col'][$id]);
	
			C::t('#it618_ad#it618_ad_adblock')->update($it618_ad_adblock['id'],array(
				'it618_width' => $_GET['adblock_width'],
				'it618_height' => $_GET['adblock_height'],
				'it618_margin_top' => $_GET['adblock_margin_top'],
				'it618_margin_bottom' => $_GET['adblock_margin_bottom'],
				'it618_margin_left' => $_GET['adblock_margin_left'],
				'it618_margin_right' => $_GET['adblock_margin_right'],
				'it618_bordertype' => $_GET['adblock_bordertype'],
				'it618_bordercolor' => $_GET['adblock_bordercolor'],
				'it618_bgcolor' => $_GET['adblock_bgcolor']
			));
			
			C::t('#it618_ad#it618_ad_ad')->update($id,array(
				'it618_title' => $_GET['it618_title'][$id],
				'it618_blockname' => $_GET['it618_blockname'][$id],
				'it618_url' => $_GET['it618_url'][$id],
				'it618_price' => intval($_GET['it618_price'][$id]),
				'it618_count' => intval($_GET['it618_count'][$id]),
				'it618_count1' => intval($_GET['it618_count1'][$id]),
				'it618_count2' => intval($_GET['it618_count2'][$id]),
				'it618_saletype' => intval($_GET['it618_saletype'][$id]),
				'it618_adtype' => intval($_GET['it618_adtype'][$id]),
				'it618_fontalign' => intval($_GET['it618_fontalign'][$id]),
				'it618_fontsize' => intval($_GET['it618_fontsize'][$id]),
				'it618_fontcount' => intval($_GET['it618_fontcount'][$id]),
				'it618_row' => $it618_row,
				'it618_col' => $it618_col,
				'it618_width' => intval($_GET['it618_width'][$id]),
				'it618_height' => intval($_GET['it618_height'][$id]),
				'it618_padding_top' => intval($_GET['it618_padding_top'][$id]),
				'it618_padding_bottom' => intval($_GET['it618_padding_bottom'][$id]),
				'it618_padding_left' => intval($_GET['it618_padding_left'][$id]),
				'it618_padding_right' => intval($_GET['it618_padding_right'][$id]),
				'it618_isrand' => intval($_GET['it618_isrand'][$id]),
				'it618_speed' => intval($_GET['it618_speed'][$id]),
				'it618_isnofollow' => intval($_GET['it618_isnofollow'][$id]),
				'it618_isnoprice' => intval($_GET['it618_isnoprice'][$id]),
				'it618_ison' => intval($_GET['it618_ison'][$id])
			));
			$ok=$ok+1;
		}
	}
	
	if(isset($_GET['noblock'])){
		$sql='';
	}

	cpmsg($it618_ad_lang['s70'].$ok.' '.$it618_ad_lang['s71'].$del, "action=plugins&identifier=$identifier&cp=admin_ad&pmod=admin_ad&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=8)return; /*dism_ taobao_ com*/

echo '
<style>
tr td{line-height:22px}
</style>
';

$adblock_bordertype='<select name="adblock_bordertype"><option value="1">'.$it618_ad_lang['s6'].'</option><option value="2">'.$it618_ad_lang['s7'].'</option><option value="3">'.$it618_ad_lang['s8'].'</option></select>';

$adblock_bordertype=str_replace('<option value="'.$it618_ad_adblock['it618_bordertype'].'">','<option value="'.$it618_ad_adblock['it618_bordertype'].'" selected="selected">',$adblock_bordertype);

if($blocktype!=''){
	$deldiybtn='<input type="submit" class="btn" style="float:right;" onclick="return confirm(\''.$it618_ad_lang['s357'].'\')" name="it618submitdeldiy" value="'.$it618_ad_lang['s355'].'" />';
}

showformheader("plugins&identifier=$identifier&cp=admin_ad&pmod=admin_ad&operation=$operation&do=$do".$sql);
showtableheaders('','it618_ad_set');
echo '<tr><td colspan=8 style="background-color:#f1f1f1">
<span style="float:left">'.$it618_ad_lang['s2'].'<input type="text" name="adblock_width" style="width:40px;color:red;font-weight:bold" value="'.$it618_ad_adblock['it618_width'].'"><input type="text" name="adblock_height" style="width:40px;color:red;font-weight:bold" value="'.$it618_ad_adblock['it618_height'].'"><input type="text" name="adblock_margin_top" style="width:30px" value="'.$it618_ad_adblock['it618_margin_top'].'"><input type="text" name="adblock_margin_bottom" style="width:30px" value="'.$it618_ad_adblock['it618_margin_bottom'].'"><input type="text" name="adblock_margin_left" style="width:30px" value="'.$it618_ad_adblock['it618_margin_left'].'"><input type="text" name="adblock_margin_right" style="width:30px" value="'.$it618_ad_adblock['it618_margin_right'].'"> '.$it618_ad_lang['s5'].$adblock_bordertype.' </span><span style="float:left;margin-left:6px">'.$it618_ad_lang['s9']."</span><input id=\"cadblock_bordercolor_v\" type=\"text\" class=\"txt\" style=\"width:68px;float:left;margin-right:3px\" name=\"adblock_bordercolor\" value=\"$it618_ad_adblock[it618_bordercolor]\" onchange=\"updatecolorpreview('cadblock_bordercolor')\"><input id=\"cadblock_bordercolor\" onclick=\"cadblock_bordercolor_frame.location='static/image/admincp/getcolor.htm?cadblock_bordercolor|cadblock_bordercolor_v';showMenu({'ctrlid':'cadblock_bordercolor'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"cadblock_bordercolor_menu\" style=\"display: none\"><iframe name=\"cadblock_bordercolor_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>".'<span style="float:left;margin-left:6px">'.$it618_ad_lang['s10']."</span><input id=\"cadblock_bgcolor_v\" type=\"text\" class=\"txt\" style=\"width:68px;float:left;margin-right:3px\" name=\"adblock_bgcolor\" value=\"$it618_ad_adblock[it618_bgcolor]\" onchange=\"updatecolorpreview('cadblock_bgcolor')\"><input id=\"cadblock_bgcolor\" onclick=\"cadblock_bgcolor_frame.location='static/image/admincp/getcolor.htm?cadblock_bgcolor|cadblock_bgcolor_v';showMenu({'ctrlid':'cadblock_bgcolor'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"cadblock_bgcolor_menu\" style=\"display: none\"><iframe name=\"cadblock_bgcolor_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>".'
<script>
updatecolorpreview(\'cadblock_bordercolor\');
updatecolorpreview(\'cadblock_bgcolor\');
</script> '.$deldiybtn.'
</td></tr>';
echo '<tr><td colspan=8 style="background-color:#f1f1f1;"><font color=blue>'.$it618_ad_lang['s3'].'</font></td></tr>';
showtablefooter(); /*dism��taobao��com*/

showtableheaders('<span style="float:right;color:red;">'.$it618_ad_lang['s306'].'</span>'.$it618_ad_lang['s72'],'it618_ad');
	showsubmit('it618sercsubmit', $it618_ad_lang['s73'], $it618_ad_lang['s75'].' <input name="find_title" value="'.$_GET['find_title'].'" class="txt" style="width:150px" /> '.$it618_ad_lang['s218'].' <select name="adtype"><option value=0 '.$adtype0.'>'.$it618_ad_lang['s219'].'</option><option value=1 '.$adtype1.'>'.$it618_ad_lang['s102'].'</option><option value=2 '.$adtype2.'>'.$it618_ad_lang['s103'].'</option><option value=3 '.$adtype3.'>'.$it618_ad_lang['s221'].'</option><option value=4 '.$adtype4.'>'.$it618_ad_lang['s255'].'</option></select>'.$it618_ad_lang['s76'].' <select name="state"><option value=0 '.$state0.'>'.$it618_ad_lang['s77'].'</option><option value=1 '.$state1.'>'.$it618_ad_lang['s78'].'</option><option value=2 '.$state2.'>'.$it618_ad_lang['s79'].'</option><option value=3 '.$state3.'>'.$it618_ad_lang['s80'].'</option><option value=4 '.$state4.'>'.$it618_ad_lang['s81'].'</option></select> '.$it618_ad_lang['s82'].' <select name="orderby"><option value=0 '.$orderby0.'>'.$it618_ad_lang['s83'].'</option><option value=1 '.$orderby1.'>'.$it618_ad_lang['s84'].'</option><option value=2 '.$orderby2.'>'.$it618_ad_lang['s85'].'</option><option value=3 '.$orderby3.'>'.$it618_ad_lang['s86'].'</option></select>');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_ad')." WHERE $extrasql");
	
	echo '<tr><td colspan=9>'.$it618_ad_lang['s87'].$count.'<span style="float:right">'.$it618_ad_lang['s107'].'</span></td></tr>';
	showsubtitle(array($it618_ad_lang['s88'],$it618_ad_lang['s89'],$it618_ad_lang['s90'],$it618_ad_lang['s356'],$it618_ad_lang['s92'].'/'.$it618_ad_lang['s365'],$it618_ad_lang['s231'],$it618_ad_lang['s94'],$it618_ad_lang['s95'],$it618_ad_lang['s296']));

	$n=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_ad_ad')." WHERE $extrasql order by it618_blockname,it618_row,it618_col,id desc");
	while($it618_ad_ad = DB::fetch($query)) {
		
		$preurl='&sql='.str_replace("&","@",$sql);
		
		if($it618_ad_ad['it618_saletype']==1)$it618_saletype_selected1='selected="selected"';else $it618_saletype_selected1="";
		if($it618_ad_ad['it618_saletype']==2)$it618_saletype_selected2='selected="selected"';else $it618_saletype_selected2="";
		
		$it618_adtype_selected1="";$it618_adtype_selected2="";$it618_adtype_selected3="";$pagestr='';
		if($it618_ad_ad['it618_adtype']==1)$it618_adtype_selected1='selected="selected"';
		if($it618_ad_ad['it618_adtype']==2)$it618_adtype_selected2='selected="selected"';
		if($it618_ad_ad['it618_adtype']==3)$it618_adtype_selected3='selected="selected"';
		$foucsstr='';
		if($it618_ad_ad['it618_adtype']==4){
			if($it618_ad_ad['it618_isrand']==1)$it618_isrand_checked='checked="checked"';else $it618_isrand_checked="";
			
			$pagestr=' <input type="checkbox" id="it618_isrand'.$it618_ad_ad[id].'" style="vertical-align:middle" name="it618_isrand['.$it618_ad_ad[id].']" value="1" '.$it618_isrand_checked.'><label for="it618_isrand'.$it618_ad_ad[id].'">'.$it618_ad_lang['s11'].'</label><br>'.$it618_ad_lang['s262'].'<input type="text" name="it618_speed['.$it618_ad_ad[id].']" style="width:35px" value="'.$it618_ad_ad[it618_speed].'">';
			$it618_adtypename=$it618_ad_lang['s255'].$pagestr;
			
			$selectadtype=$it618_adtypename.'<input type="hidden" name="it618_adtype['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_adtype].'">';
			
			$foucscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_ad_focus')." WHERE it618_aid=".$it618_ad_ad['id']);
			$foucsstr=' <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_ad_focus&pmod=admin_ad&operation='.$operation.'&do='.$do.'&aid='.$it618_ad_ad[id].$preurl.'">'.$it618_ad_lang['s4'].'(<font color=red>'.$foucscount.'</font>)</a>';
		}
		
		if($it618_ad_ad['it618_isnofollow']==1)$it618_isnofollow_checked='checked="checked"';else $it618_isnofollow_checked="";
		if($it618_ad_ad['it618_isnoprice']==1)$it618_isnoprice_checked='checked="checked"';else $it618_isnoprice_checked="";
		if($it618_ad_ad['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
		
		if($it618_ad_ad['it618_fontalign']==1)$it618_fontalign1='selected="selected"';else $it618_fontalign1='';
		if($it618_ad_ad['it618_fontalign']==2)$it618_fontalign2='selected="selected"';else $it618_fontalign2='';
		if($it618_ad_ad['it618_fontalign']==3)$it618_fontalign3='selected="selected"';else $it618_fontalign3='';
		
		if($it618_ad_ad['it618_state']==0)$it618_state='<font color=green>'.$it618_ad_lang['s97'].'</font>';
		if($it618_ad_ad['it618_state']==1)$it618_state='<font color=red>'.$it618_ad_lang['s98'].'</font>';
		
		if($it618_ad_ad['it618_state']==1){
			if($it618_ad_ad['it618_adtype']!=4){
				if($it618_ad_ad['it618_adtype']==1)$it618_adtypename=$it618_ad_lang['s102'];
				if($it618_ad_ad['it618_adtype']==2)$it618_adtypename=$it618_ad_lang['s103'];
				if($it618_ad_ad['it618_adtype']==3)$it618_adtypename=$it618_ad_lang['s221'];
				
				$selectadtype=$it618_adtypename.'<input type="hidden" name="it618_adtype['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_adtype].'">';
			}
			
			if($it618_ad_ad['it618_saletype']==1)$it618_saletypename=$it618_ad_lang['s104'];
			if($it618_ad_ad['it618_saletype']==2)$it618_saletypename=$it618_ad_lang['s105'];
			$selectsaletype=$it618_state.' '.$it618_saletypename.'<input type="hidden" name="it618_saletype['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_saletype].'">';
			
		}else{
			if($it618_ad_ad['it618_adtype']!=4){
				$selectadtype='<select name="it618_adtype['.$it618_ad_ad[id].']" onchange="getadtype(this,'.$it618_ad_ad[id].')"><option value=1 '.$it618_adtype_selected1.'>'.$it618_ad_lang['s102'].'</option><option value=2 '.$it618_adtype_selected2.'>'.$it618_ad_lang['s103'].'</option><option value=3 '.$it618_adtype_selected3.'>'.$it618_ad_lang['s221'].'</option></select>'.$pagestr;
			}
			
			$selectsaletype=$it618_state.'<select name="it618_saletype['.$it618_ad_ad[id].']" '.$editreadonly.'><option value=1 '.$it618_saletype_selected1.'>'.$it618_ad_lang['s104'].'</option><option value=2 '.$it618_saletype_selected2.'>'.$it618_ad_lang['s105'].'</option></select>';
		}
		
		$editstr='<a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_ad_edit&pmod=admin_ad&operation='.$operation.'&do='.$do.'&aid='.$it618_ad_ad[id].$preurl.'">'.$it618_ad_lang['s99'].'</a>';
		
		if($it618_ad_ad['it618_pricetype']==1)$it618_pricetype=$it618_ad_lang['s33'];
		if($it618_ad_ad['it618_pricetype']==2)$it618_pricetype=$it618_ad_lang['s223'];
		
		$blocktmp1=str_replace('<option value="'.$it618_ad_ad['it618_blockname'].'">','<option value="'.$it618_ad_ad['it618_blockname'].'" selected="selected">',$blocktmp);
		
		$deldisabled="";
		$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_sale')." WHERE it618_aid=".$it618_ad_ad['id']);
		if($salecount>0)$deldisabled="disabled=\"disabled\"";
		
		if($it618_ad_ad['it618_adtype']==2){
			$fontcss='display:';
		}else{
			$fontcss='display:none';
		}
		
		showtablerow('', array('style="width:60px"', '', '', '', '', '', '', ''), array(
			$it618_ad_ad[id].'<input class="checkbox" type="checkbox" name="delete[]" value="'.$it618_ad_ad[id].'" '.$deldisabled.'><input type="hidden" id="it618_id'.$n.'" name="id['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[id].'">',
			'<input type="text" class="txt" style="width:130px" name="it618_title['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_title].'"><br><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_ad_edit&pmod=admin_ad&operation='.$operation.'&do='.$do.'&ac=copy&aid='.$it618_ad_ad[id].$preurl.'">'.$it618_ad_lang['s100'].'</a> '.$editstr.$foucsstr,
			'<select id="it618_blockname'.$n.'" name="it618_blockname['.$it618_ad_ad[id].']" style="color:blue">'.$blocktmp1.'</select><br><input type="checkbox" id="it618_isnofollow'.$it618_ad_ad[id].'" style="vertical-align:middle" name="it618_isnofollow['.$it618_ad_ad[id].']" value="1" '.$it618_isnofollow_checked.'><label for="it618_isnofollow'.$it618_ad_ad[id].'">'.$it618_ad_lang['s234'].'</label> <input type="checkbox" id="it618_isnoprice'.$it618_ad_ad[id].'" style="vertical-align:middle" name="it618_isnoprice['.$it618_ad_ad[id].']" value="1" '.$it618_isnoprice_checked.'><label for="it618_isnoprice'.$it618_ad_ad[id].'">'.$it618_ad_lang['s235'].'</label>',
			$selectadtype.'<span id="fontspan'.$it618_ad_ad[id].'" style="'.$fontcss.'"><br><select name="it618_fontalign['.$it618_ad_ad[id].']" style="padding:0"><option value=1 '.$it618_fontalign1.'>'.$it618_ad_lang['t16'].'</option><option value=2 '.$it618_fontalign2.'>'.$it618_ad_lang['t17'].'</option><option value=3 '.$it618_fontalign3.'>'.$it618_ad_lang['t18'].'</option></select>/<input type="text" class="txt" style="width:18px;margin-right:1px" name="it618_fontsize['.$it618_ad_ad[id].']" value="'.$it618_ad_ad['it618_fontsize'].'">/<input type="text" class="txt" style="width:28px;margin-right:1px" name="it618_fontcount['.$it618_ad_ad[id].']" value="'.$it618_ad_ad['it618_fontcount'].'"></span>',
			'<input type="text" class="txt" style="width:50px;margin-right:1px;color:red" name="it618_price['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_price].'">'.$creditname.'<br><input type="text" class="txt" style="width:50px;margin-right:1px;" name="it618_count['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_count].'">'.$it618_pricetype,
			$it618_ad_lang['s232'].'<input type="text" class="txt" style="width:40px;margin-right:1px" name="it618_count1['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_count1].'">'.$it618_pricetype.'<br>'.$it618_ad_lang['s233'].'<input type="text" class="txt" style="width:40px;margin-right:1px" name="it618_count2['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_count2].'">'.$it618_pricetype,
			'<input type="text" class="txt" style="width:18px;margin-right:0px;color:blue; font-weight:bold" name="it618_row['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_row].'"><input type="text" class="txt" style="width:18px;margin-right:0px;color:blue; font-weight:bold" name="it618_col['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_col].'">/<input type="text" class="txt" style="width:35px;margin-right:0px" id="it618_width'.$n.'" name="it618_width['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_width].'"><input type="text" class="txt" style="width:35px;margin-right:0px" id="it618_height'.$n.'" name="it618_height['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_height].'">/<input type="text" class="txt" style="width:23px;margin-right:0px" name="it618_padding_top['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_padding_top].'"><input type="text" class="txt" style="width:23px;margin-right:0px" name="it618_padding_bottom['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_padding_bottom].'"><input type="text" class="txt" style="width:23px;margin-right:0px" name="it618_padding_left['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_padding_left].'"><input type="text" class="txt" style="width:23px;margin-right:0px" name="it618_padding_right['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_padding_right].'"><br><input type="text" class="txt" style="width:251px; margin-top:3px;color:blue" name="it618_url['.$it618_ad_ad[id].']" value="'.$it618_ad_ad[it618_url].'">',
			$selectsaletype.'<br>'.$it618_ad_lang['s236'].'<font color=red>'.$salecount.'</font>',
			'<input type="checkbox" id="it618_ison'.$n.'" name="it618_ison['.$it618_ad_ad[id].']" value="1" '.$it618_ison_checked.'>'
		));
		
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallI3B2" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallI3B2">'.$it618_ad_lang['s12'].'</label></td><td colspan="15"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue()" name="it618submit" value="'.$it618_ad_lang['s13'].'" /> <font color=red>'.$it618_ad_lang['s313'].'</font></div></td></tr>';
	
	if(count($reabc)!=8)return; /*dism_ taobao_ com*/
showtablefooter(); /*dism��taobao��com*/
echo '<script>
function checkvalue(){
	for(var i=1;i<'.$n.';i++){
		var it618_id = document.getElementById("it618_id"+i).value;
		var it618_ison = document.getElementById("it618_ison"+i);
		var it618_blockname = document.getElementById("it618_blockname"+i).value;
		var it618_width = parseInt(document.getElementById("it618_width"+i).value);
		var it618_height = parseInt(document.getElementById("it618_height"+i).value);
		
		if(it618_blockname=="noblock"){
			alert("'.$it618_ad_lang['s14'].'"+it618_id+"'.$it618_ad_lang['s18'].'");
			return false;
		}
		
		if(it618_ison.checked==true){
			if(it618_width<=0){
				alert("'.$it618_ad_lang['s14'].'"+it618_id+"'.$it618_ad_lang['s15'].'");
				document.getElementById("it618_width"+i).focus();
				return false;
			}
			
			if(it618_height<=0){
				alert("'.$it618_ad_lang['s14'].'"+it618_id+"'.$it618_ad_lang['s16'].'");
				document.getElementById("it618_height"+i).focus();
				return false;
			}
		}
	}
}

function getadtype(obj,id){
	if(obj.value==2){
		document.getElementById("fontspan"+id).style.display="";
	}else{
		document.getElementById("fontspan"+id).style.display="none";
	}
}
</script>';
?>