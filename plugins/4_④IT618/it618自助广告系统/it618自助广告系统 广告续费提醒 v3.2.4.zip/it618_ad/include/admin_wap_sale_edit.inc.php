<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
$sid=intval($_GET['sid']);
$it618_ad_wap_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_wap_sale')." WHERE id=".$sid);
$it618_ad_wap_ad=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_wap_ad')." WHERE id=".$it618_ad_wap_sale['it618_aid']);

if(submitcheck('it618submit')){
	
	if($it618_ad_wap_ad['it618_adtype']==1){
		C::t('#it618_ad#it618_ad_wap_sale')->update($sid,array(
			'it618_message' => $_GET['it618_message']
		));
	}else{
		C::t('#it618_ad#it618_ad_wap_sale')->update($sid,array(
			'it618_img' => $_GET['it618_img'],
			'it618_url' => $_GET['it618_url']
		));
	}
	
	$_GET['sql']=str_replace("@","&",$_GET['sql']);
	cpmsg($it618_ad_lang['s146'], "action=plugins&identifier=$identifier&cp=admin_wap_sale&pmod=admin_wap_sale&operation=$operation&do=$do&page=$page".$_GET['sql'], 'succeed');
}

$sql=str_replace("@","&",$_GET['sql']);

showformheader("plugins&identifier=$identifier&cp=admin_wap_sale_edit&pmod=admin_wap_sale&operation=$operation&do=$do&sid=$sid&sql=".$_GET['sql']);
showtableheaders($it618_ad_lang['s353'].' <a href="'.ADMINSCRIPT.'?'."action=plugins&identifier=$identifier&cp=admin_wap_sale&pmod=admin_wap_sale&operation=$operation&do=$do&page=$page".$sql.'"><<<'.$it618_ad_lang['s30'].'</a>','it618_ad_edit');

echo '
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_ad/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_ad/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_ad/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
		
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_ad/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_ad/kindeditor/php/file_manager_json.php\',
			allowFileManager : true
		});
		
		K(\'#image\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url\').val(url);
						K(\'#img\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});

		prettyPrint();
	});
</script>
';

if($it618_ad_wap_ad['it618_adtype']==1){
	echo '<tr><td width=77>'.$it618_ad_lang['s311'].'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_ad_wap_sale['it618_message'].'</textarea></td></tr>';
}else{
	echo '<tr><td width=77>'.$it618_ad_lang['s351'].'</td><td><img src="'.$it618_ad_wap_sale['it618_img'].'" id="img" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url" name="it618_img" readonly="readonly" value="'.$it618_ad_wap_sale['it618_img'].'" /> <input type="button" id="image" value="'.$it618_ad_lang['s32'].'" /></td></tr>
		  <tr><td>'.$it618_ad_lang['s352'].'</td><td><input class="txt" type="text" style="width:400px;" name="it618_url" value="'.$it618_ad_wap_sale['it618_url'].'"></td></tr>
	';
}
echo '<tr><td colspan="2"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_ad_lang['s149'].'" /></div></td></tr>
';

if(count($reabc)!=8)return; /*dism_ taobao_ com*/
showtablefooter(); /*dism��taobao��com*/

?>