<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$it618_tel=\''.trim($_GET['it618_tel'])."';\n";
		
		$fileData .= '$it618_password=\''.trim($_GET['it618_password'])."';\n";
		
		$fileData .= '$it618_smsbaosign=\''.trim($_GET['it618_smsbaosign'])."';\n";
		
		$fileData .= '$it618_isok=\''.trim($_GET['it618_isok'])."';\n";
		
		$fileData .= '$it618_type=\''.trim($_GET['it618_type'])."';\n";
		
		$fileData .= '$it618_sign=\''.trim($_GET['it618_sign'])."';\n";
		
		$fileData .= '$it618_length=\''.trim($_GET['it618_length'])."';\n";
		
		$fileData .= '$it618_testsendto=\''.trim($_GET['it618_testsendto'])."';\n";
		
		$fileData .= '$it618_testbody=\''.trim($_GET['it618_testbody'])."';\n";
		
		$fileData .= '$it618_tel_admin=\''.trim($_GET['it618_tel_admin'])."';\n";
		
		$fileData .= '$it618_uid_admin=\''.trim($_GET['it618_uid_admin'])."';\n";
		
		$fileData .= '$it618_isok_admin=\''.trim($_GET['it618_isok_admin'])."';\n";
		
		$fileData .= '$it618_body_sale_admin=\''.trim($_GET['it618_body_sale_admin'])."';\n";
		$fileData .= '$it618_body_sale_admin_tplid=\''.trim($_GET['it618_body_sale_admin_tplid'])."';\n";
		$fileData .= '$it618_body_sale_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_sale_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_sale_admin_tplid_wxsms=\''.trim($_GET['it618_body_sale_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_sale_admin_isok=\''.trim($_GET['it618_body_sale_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_sale1_admin=\''.trim($_GET['it618_body_sale1_admin'])."';\n";
		$fileData .= '$it618_body_sale1_admin_tplid=\''.trim($_GET['it618_body_sale1_admin_tplid'])."';\n";
		$fileData .= '$it618_body_sale1_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_sale1_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_sale1_admin_tplid_wxsms=\''.trim($_GET['it618_body_sale1_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_sale1_admin_isok=\''.trim($_GET['it618_body_sale1_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_ad_admin=\''.trim($_GET['it618_body_ad_admin'])."';\n";
		$fileData .= '$it618_body_ad_admin_tplid=\''.trim($_GET['it618_body_ad_admin_tplid'])."';\n";
		$fileData .= '$it618_body_ad_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_ad_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_ad_admin_tplid_wxsms=\''.trim($_GET['it618_body_ad_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_ad_admin_isok=\''.trim($_GET['it618_body_ad_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_ad1_admin=\''.trim($_GET['it618_body_ad1_admin'])."';\n";
		$fileData .= '$it618_body_ad1_admin_tplid=\''.trim($_GET['it618_body_ad1_admin_tplid'])."';\n";
		$fileData .= '$it618_body_ad1_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_ad1_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_ad1_admin_tplid_wxsms=\''.trim($_GET['it618_body_ad1_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_ad1_admin_isok=\''.trim($_GET['it618_body_ad1_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_ad_user=\''.trim($_GET['it618_body_ad_user'])."';\n";
		$fileData .= '$it618_body_ad_user_tplid=\''.trim($_GET['it618_body_ad_user_tplid'])."';\n";
		$fileData .= '$it618_body_ad_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_ad_user_wxsms']))."';\n";
		$fileData .= '$it618_body_ad_user_tplid_wxsms=\''.trim($_GET['it618_body_ad_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_ad_user_isok=\''.trim($_GET['it618_body_ad_user_isok'])."';\n";
		
		$fileData .= '$it618_body_ad1_user=\''.trim($_GET['it618_body_ad1_user'])."';\n";
		$fileData .= '$it618_body_ad1_user_tplid=\''.trim($_GET['it618_body_ad1_user_tplid'])."';\n";
		$fileData .= '$it618_body_ad1_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_ad1_user_wxsms']))."';\n";
		$fileData .= '$it618_body_ad1_user_tplid_wxsms=\''.trim($_GET['it618_body_ad1_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_ad1_user_isok=\''.trim($_GET['it618_body_ad1_user_isok'])."';\n";
		
		if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_members'")!=0){
			$it618_body_adtime_user_isok=trim($_GET['it618_body_adtime_user_isok']);
		}else{
			$it618_body_adtime_user_isok=0;
		}
		
		$fileData .= '$it618_body_adtime_user=\''.trim($_GET['it618_body_adtime_user'])."';\n";
		$fileData .= '$it618_body_adtime_user_tplid=\''.trim($_GET['it618_body_adtime_user_tplid'])."';\n";
		$fileData .= '$it618_body_adtime_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_adtime_user_wxsms']))."';\n";
		$fileData .= '$it618_body_adtime_user_tplid_wxsms=\''.trim($_GET['it618_body_adtime_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_adtime_user_isok=\''.$it618_body_adtime_user_isok."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	if($_GET['it618_istest']==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/message.func.php';
		if(trim($_GET['it618_smsbaosign'])!='')$it618_smsbaosign=$it618_ad_lang['s553'].trim($_GET['it618_smsbaosign']).$it618_ad_lang['s554'];
		$tmpstr=sendSMS(trim($_GET['it618_tel']),trim($_GET['it618_password']),trim($_GET['it618_testsendto']),$it618_smsbaosign.trim($_GET['it618_testbody']));
		
		$tmpaboutstr='<br><br>'.$it618_ad_lang['s539'];
	}

	cpmsg($it618_ad_lang['s512'].'<br>'.$tmpstr.$tmpaboutstr, "action=plugins&identifier=$identifier&cp=admin_message&pmod=admin_message&operation=$operation&do=$do&page=$page", 'succeed');
}

echo '
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/js/jquery.js"></script>
';

showformheader("plugins&identifier=$identifier&cp=admin_message&pmod=admin_message&operation=$operation&do=$do");
showtableheaders($it618_ad_lang['s1047'],'it618_ad_message');

$it618_typestyle1='display:none';$it618_typestyle2='display:none';
if($it618_type=='')$it618_type='smsbao';
if($it618_type=='smsbao'){$it618_type1=' selected=selected';$it618_typestyle1='display:';}
if($it618_type=='alidayu'){$it618_type2=' selected=selected';$it618_typestyle2='display:';}
if($it618_type=='alisms'){$it618_type3=' selected=selected';$it618_typestyle2='display:';}

if($it618_isok==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
if($it618_isok_admin==1)$it618_isok_admin_checked='checked="checked"';else $it618_isok_admin_checked="";
if($it618_body_sale_admin_isok==1)$it618_body_sale_admin_isok_checked='checked="checked"';else $it618_body_sale_admin_isok_checked="";
if($it618_body_sale1_admin_isok==1)$it618_body_sale1_admin_isok_checked='checked="checked"';else $it618_body_sale1_admin_isok_checked="";
if($it618_body_ad_admin_isok==1)$it618_body_ad_admin_isok_checked='checked="checked"';else $it618_body_ad_admin_isok_checked="";
if($it618_body_ad1_admin_isok==1)$it618_body_ad1_admin_isok_checked='checked="checked"';else $it618_body_ad1_admin_isok_checked="";
if($it618_body_ad_user_isok==1)$it618_body_ad_user_isok_checked='checked="checked"';else $it618_body_ad_user_isok_checked="";
if($it618_body_ad1_user_isok==1)$it618_body_ad1_user_isok_checked='checked="checked"';else $it618_body_ad1_user_isok_checked="";
if($it618_body_adtime_user_isok==1)$it618_body_adtime_user_isok_checked='checked="checked"';else $it618_body_adtime_user_isok_checked="";

$wxsmscss='display:none';

if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_members'")!=0){
	$it618_membersstr= '<tr name="tr_alidayu" style="background-color:#e8e8e8;'.$it618_typestyle2.'"><td>'.$it618_ad_lang['s1043'].'</td><td><input type="text" class="txt" style="width:150px" name="it618_sign" value="'.$it618_sign.'"> '.$it618_ad_lang['s1048'].'<input type="text" class="txt" style="width:30px;margin-right:3px" name="it618_length" value="'.$it618_length.'">'.$it618_ad_lang['s1049'].'</td></tr>';
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if($it618_members['members_iswxsms']==1){
		$wxsmscss='';
		$adminuidstr=$it618_ad_lang['s1050'].'<input type="text" class="txt" style="width:300px" name="it618_uid_admin" value="'.$it618_uid_admin.'">';
	}
}else{
	$it618_membersstr= '<tr name="tr_alidayu" style="background-color:#e8e8e8;'.$it618_typestyle2.'"><td colspan=2>'.$it618_ad_lang['s1045'].'</td></tr>';
}

echo '<style>table tr td{line-height:20px}</style>
<tr><td width=110>'.$it618_ad_lang['s514'].'</td><td><input type="checkbox" id="it618_isok" name="it618_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.$it618_ad_lang['s515'].'</label></td></tr>
<tr><td>'.$it618_ad_lang['s521'].'</td><td><input type="text" class="txt" style="width:115px" name="it618_tel_admin" value="'.$it618_tel_admin.'">'.$adminuidstr.'<input type="checkbox" id="it618_isok_admin" name="it618_isok_admin" value="1" style="vertical-align:middle" '.$it618_isok_admin_checked.'> <label for="it618_isok_admin">'.$it618_ad_lang['s522'].'</label></td></tr>
<tr><td width=110>'.$it618_ad_lang['s1040'].'</td><td><select name="it618_type" onchange="gettype(this)"><option value="smsbao" '.$it618_type1.'>'.$it618_ad_lang['s1041'].'</option><option value="alidayu" style="display:none" '.$it618_type2.'>'.$it618_ad_lang['s1042'].'</option><option value="alisms" '.$it618_type3.'>'.$it618_ad_lang['s1044'].'</option></select> '.$it618_ad_lang['s888'].'</td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td colspan=2>'.$it618_ad_lang['s513'].'</td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_ad_lang['s516'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_tel" value="'.$it618_tel.'"></td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_ad_lang['s517'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_password" value="'.$it618_password.'"></td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_ad_lang['s1043'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_smsbaosign" value="'.$it618_smsbaosign.'"></td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_ad_lang['s518'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_testsendto" value="'.$it618_testsendto.'"> '.$it618_ad_lang['s519'].'</td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_ad_lang['s520'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_testbody" value="'.$it618_testbody.'"></td></tr>

'.$it618_membersstr.'

<tr><td colspan=2><strong>'.$it618_ad_lang['s523'].'</strong> <font color=red>'.$it618_ad_lang['s524'].'</font></td></tr>';

$it618_bodyarr=array(
'sale_admin','sale1_admin',
'ad_admin','ad1_admin','ad_user',
'ad1_user','adtime_user'
);

$it618lang=explode(",",$it618_ad_lang['s511']);

for($i=0;$i<count($it618_bodyarr);$i++){
	$it618_body_name=$it618_bodyarr[$i];
	
	if($it618_body_name=='sale_admin'){$it618_body_title=$it618_ad_lang['s525'];$it618_body_about=$it618_ad_lang['s526'];}
	if($it618_body_name=='sale1_admin'){$it618_body_title=$it618_ad_lang['s527'];$it618_body_about=$it618_ad_lang['s528'];}
	if($it618_body_name=='ad_admin'){$it618_body_title=$it618_ad_lang['s529'];$it618_body_about=$it618_ad_lang['s530'];}
	if($it618_body_name=='ad1_admin'){$it618_body_title=$it618_ad_lang['s531'];$it618_body_about=$it618_ad_lang['s532'];}
	
	if($it618_body_name=='ad_user'){$it618_body_title=$it618_ad_lang['s533'];$it618_body_about=$it618_ad_lang['s534'];}
	if($it618_body_name=='ad1_user'){$it618_body_title=$it618_ad_lang['s550'];$it618_body_about=$it618_ad_lang['s551'];}
	if($it618_body_name=='adtime_user'){$it618_body_title=$it618_ad_lang['s555'];$it618_body_about=$it618_ad_lang['s556'];}
	
	$tmpname='it618_body_'.$it618_body_name.'_isok_checked';
	$it618_body_isok_checked=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name;
	$it618_body=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name.'_tplid';
	$it618_body_tplid=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name.'_wxsms';
	$it618_body_wxsms=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name.'_tplid_wxsms';
	$it618_body_tplid_wxsms=$$tmpname;
	
	echo '<tr><td colspan=2><input type="checkbox" id="it618_body_'.$it618_body_name.'_isok" name="it618_body_'.$it618_body_name.'_isok" value="1" style="vertical-align:middle" '.$it618_body_isok_checked.'><label for="it618_body_'.$it618_body_name.'_isok">'.$it618lang[0].' <span id="it618_body_'.$it618_body_name.'_title">'.$it618_body_title.'</span></label><br>'.$it618lang[1].'<input type="text" class="txt" style="width:670px" name="it618_body_'.$it618_body_name.'" value="'.$it618_body.'"><span name="tr_alidayu" style="'.$it618_typestyle2.'">'.$it618lang[2].'<input type="text" class="txt" style="width:130px" name="it618_body_'.$it618_body_name.'_tplid" value="'.$it618_body_tplid.'"></span>
	<span style="'.$wxsmscss.'">
	<br>'.$it618lang[3].'<input type="text" class="txt" style="width:420px;margin-top:3px" id="it618_body_'.$it618_body_name.'_wxsms" name="it618_body_'.$it618_body_name.'_wxsms" readonly="readonly" onclick="getwxsms(\''.$it618_body_name.'\')" value="'.$it618_body_wxsms.'">'.$it618lang[4].'<input type="text" class="txt" style="width:380px" name="it618_body_'.$it618_body_name.'_tplid_wxsms" value="'.$it618_body_tplid_wxsms.'">
	</span>
	<br><span id="it618_body_'.$it618_body_name.'_about">'.$it618_body_about.'</span>
	</td></tr>';
}

echo '<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_ad_lang['s557'].'" /><input type="checkbox" id="it618_istest" name="it618_istest" value="1" style="vertical-align:middle;'.$it618_typestyle1.'"><label for="it618_istest" name="tr_smsbao" style="'.$it618_typestyle1.'">'.$it618_ad_lang['s558'].'</label></div></td></tr>

<div id="tmpsmsbtn"></div>
<style>
.wxsmstable tr th{font-weight:bold}
.wxsmstable tr td{padding:1px;padding-top:3px;padding-bottom:3px}
.wxsmstable tr td .tmplabel{width:113px;line-height:22px;text-align:right;color:blue;padding-right:3px;margin-right:2px;background-color:#fff}
.wxsmstable tr td .tmpvalue{width:760px;line-height:22px;padding-left:3px;background-color:#fff}
.wxsmstable tr td .savebtn{background-color:#390;padding:8px 35px;padding-bottom:10px;color:#fff;border:none}
.wxsmstable tr td .savebtn:hover{background-color:#3a0;}
.wxsmstable tr td .savebtn1{background-color:#e3e3e3;padding:8px 35px;padding-bottom:10px;color:#666;border:none}
.wxsmstable tr td .savebtn1:hover{background-color:#e8e8e8;}
</style>
<script>
var dialog_wxsms,tmpname,tmptitle,tmpabout,tmpbody;

KindEditor.ready(function(K) {K(\'#tmpsmsbtn\').click(function() {
	dialog_wxsms = K.dialog({
		width : 915,
		title : tmptitle,
		body : \'<div style="padding:8px;background-color:#fcfcfc;width:910px"><table class="wxsmstable"><tr><th>'.$it618_ad_lang['s469'].'</th><th>'.$it618_ad_lang['s470'].'</th></tr>\'+tmpbody+\'<tr><td colspan=2>\'+tmpabout+\'</td></tr><tr><td colspan=2><font color=green>'.$it618_ad_lang['s471'].'</font></td></tr><tr><td colspan=2 align="center" style="padding-top:10px;padding-bottom:10px"><a class="savebtn" href="javascript:" onclick="savewxsms()">'.$it618_ad_lang['s473'].'</a> <a class="savebtn1" href="javascript:" onclick="savewxsms1()">'.$it618_ad_lang['s472'].'</a></td></tr></table></div>\',
		closeBtn : {
			name : \''.it618_ad_getlang('s410').'\',
			click : function(e) {
				dialog_wxsms.remove();
			}
		}
	});
	
	}, "html");
});

function getwxsms(it618_body_name){
	tmpname=it618_body_name;
	tmptitle=document.getElementById("it618_body_"+it618_body_name+"_title").innerHTML;
	tmpabout=document.getElementById("it618_body_"+it618_body_name+"_about").innerHTML;
	
	var tmpbody1=document.getElementById("it618_body_"+it618_body_name+"_wxsms").value;
	
	tmpbody="";
	if(tmpbody1=="")tmpbody1="|";
	var tmpbodyarr1=tmpbody1.split("@");
	for(var i=tmpbodyarr1.length;i<9;i++){
		tmpbodyarr1[i]="|";
	}
	
	for(var i=0;i<9;i++){
		var tmpbodyarr2=tmpbodyarr1[i].split("|");
		tmpbody=tmpbody+\'<tr><td><input type="text" class="tmplabel" id="tmplabel\'+i+\'" value="\'+tmpbodyarr2[0]+\'">:</td><td><input type="text" class="tmpvalue" id="tmpvalue\'+i+\'" value="\'+tmpbodyarr2[1]+\'"></td></tr>\';
	}

	document.getElementById("tmpsmsbtn").click();
}

function trimStr(str){return str.replace(/(^\s*)|(\s*$)/g,"");}

function savewxsms(){
	var wxsmsstr="";
	for(var i=0;i<9;i++){
		var tmplabel=trimStr(document.getElementById("tmplabel"+i).value);
		if(tmplabel!=""){
			var tmpvalue=document.getElementById("tmpvalue"+i).value;
			if(tmpvalue!=""){
				wxsmsstr=wxsmsstr+tmplabel+"|"+tmpvalue+"@";
			}else{
				alert("'.$it618_ad_lang['s474'].'");
				document.getElementById("tmpvalue"+i).focus();
				return;
			}
		}
	}
	if(wxsmsstr!=""){
		wxsmsstr=wxsmsstr+"@";
		wxsmsstr=wxsmsstr.replace("@@","");
		document.getElementById("it618_body_"+tmpname+"_wxsms").value=wxsmsstr; 
	}
	dialog_wxsms.remove();
}

function savewxsms1(){
	dialog_wxsms.remove();
}

function gettype(obj){
	var trobj=document.getElementsByName("tr_smsbao");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}
	
	var trobj=document.getElementsByName("tr_alidayu");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}

	var jktype=obj.value;
	if(jktype=="alisms")jktype="alidayu";
	
	var trobj=document.getElementsByName("tr_"+jktype);
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="";
	}
	
	if(obj.value=="smsbao"){
		document.getElementById("it618_istest").style.display="";
	}else{
		document.getElementById("it618_istest").style.display="none";
	}
}
</script>
';

if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/

?>