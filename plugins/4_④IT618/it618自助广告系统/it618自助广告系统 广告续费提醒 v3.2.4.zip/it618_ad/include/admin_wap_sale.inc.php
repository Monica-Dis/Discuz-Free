<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];

if(isset($_GET['ac'])&&$_GET['ac']=='add'){
	if($it618_ad_wap_ad=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_wap_ad')." WHERE id=".intval($_GET['aid']))){
		if($it618_ad_wap_ad['it618_isuser']==0&&DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')."  WHERE it618_aid=".intval($_GET['aid']))>0){$_GET['sql']=str_replace("@","&",$_GET['sql']);
			cpmsg($it618_ad_lang['s346'], "action=plugins&identifier=$identifier&cp=admin_wap_ad&pmod=admin_wap_ad&operation=$operation&do=$do&page=$page".$_GET['sql'], 'succeed');
		}
		
		$id=DB::insert('it618_ad_wap_sale', array(
			'it618_aid' => $_GET['aid'],
			'it618_pid' => $_GET['pid']
		), true);
		
		$_GET['find_blockname']=$it618_ad_wap_ad['it618_blockname'];
	}
}

foreach($adblock_arr as $id => $adblock){
	$blocktmp.='<option value="'.$adblock.'">'.$adblocktitle_arr[$id].'</option>';
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')." s left join ".DB::table('it618_ad_wap_ad')." a on a.id=s.it618_aid WHERE a.it618_blockname='".$adblock."'");
	$licss='';
	if(isset($_GET['find_blockname'])){
		if($_GET['find_blockname']==$adblock){
			$licss='class="current"';
			$it618_blockname=$adblock;
		}else{
			$licss='';
		}
	}elseif($id==0){
		$licss='class="current"';
		$it618_blockname=$adblock;
	}
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_wap_sale&pmod=admin_wap_sale&find_blockname=$adblock&operation=$operation&do=$do&page=$page\"><span>".$adblocktitle_arr[$id].'(<font color=red>'.$count.'</font>)</span></a></li>';
}


echo '<style>.itemtitle1 .current{background-color:#666} .itemtitle1 .noblock{color:blue}</style><div class="itemtitle itemtitle1" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';


$extrasql = "a.it618_blockname ='".$it618_blockname."'";	

if($_GET['find_title']) {
	$extrasql .= " AND a.it618_title LIKE '%".addcslashes($_GET['find_title'],'%_')."%'";
}
if($_GET['adtype']) {
	$adtype0='';$adtype1='';$adtype2='';$adtype3='';
	if($_GET['adtype']==0){$extrasql .= "";$adtype0='selected="selected"';}
	if($_GET['adtype']==1){$extrasql .= " AND a.it618_adtype = 1";$adtype1='selected="selected"';}
	if($_GET['adtype']==2){$extrasql .= " AND a.it618_adtype = 2";$adtype2='selected="selected"';}
}
$sql.='&find_blockname='.$it618_blockname.'&find_title='.$_GET['find_title'].'&adtype='.$_GET['adtype'];

if(submitcheck('it618submit')){
	$del=0;
	$ok=0;
	if($reabc[7]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_ad_wap_sale', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_uid'])) {
		foreach($_GET['it618_uid'] as $id => $val) {
			
			C::t('#it618_ad#it618_ad_wap_sale')->update($id,array(
				'it618_uid' => $_GET['it618_uid'][$id],
				'it618_bz' => $_GET['it618_bz'][$id],
				'it618_etime' => $_GET['it618_etime'][$id],
				'it618_isok' => $_GET['it618_isok'][$id],
			));
			$ok=$ok+1;
		}
	}

	cpmsg($it618_ad_lang['s70'].$ok.' '.$it618_ad_lang['s71'].$del, "action=plugins&identifier=$identifier&cp=admin_wap_sale&pmod=admin_wap_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=8)return; /*dism_ taobao_ com*/

echo '
<style>
tr td{line-height:22px}
</style>
';

showformheader("plugins&identifier=$identifier&cp=admin_wap_sale&pmod=admin_wap_sale&operation=$operation&do=$do".$sql);
showtableheaders('<span style="float:right;color:blue">'.$it618_blockname.'</span>'.$it618_ad_lang['s72'],'it618_ad');
	showsubmit('it618sercsubmit', $it618_ad_lang['s73'], $it618_ad_lang['s75'].' <input name="find_title" value="'.$_GET['find_title'].'" class="txt" style="width:150px" /> '.$it618_ad_lang['s218'].' <select name="adtype"><option value=0 '.$adtype0.'>'.$it618_ad_lang['s219'].'</option><option value=1 '.$adtype1.'>'.$it618_ad_lang['s309'].'</option><option value=2 '.$adtype2.'>'.$it618_ad_lang['s310'].'</option</select>');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')." s left join ".DB::table('it618_ad_wap_ad')." a on a.id=s.it618_aid WHERE $extrasql");
	
	echo '<tr><td colspan=8>'.$it618_ad_lang['s87'].$count.'<span style="float:right;color:red">'.$it618_ad_lang['s308'].'</span></td></tr>';
	showsubtitle(array($it618_ad_lang['s338'],$it618_ad_lang['s332'],$it618_ad_lang['s333'],$it618_ad_lang['s335'],$it618_ad_lang['s336'],$it618_ad_lang['s337']));

	$n=1;
	$query = DB::query("SELECT s.*,a.it618_adtype,a.it618_lou,a.it618_isuser FROM ".DB::table('it618_ad_wap_sale')." s left join ".DB::table('it618_ad_wap_ad')." a on a.id=s.it618_aid WHERE $extrasql order by s.id desc");
	while($it618_ad_wap_sale = DB::fetch($query)) {
		if($it618_ad_wap_sale[it618_adtype]==1)$it618_adtype=$it618_ad_lang['s309'];else $it618_adtype=$it618_ad_lang['s310'];
		if($it618_ad_wap_sale[it618_lou]>0)$it618_lou=' '.$it618_ad_wap_sale[it618_lou].$it618_ad_lang['s326'];else $it618_lou='';
		if($it618_ad_wap_sale[it618_isuser]==1){
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_ad_wap_sale['it618_uid']);
			$it618_isuser=' '.$it618_ad_lang['s349'].' '.$it618_ad_lang['s354'].'<input type="text" class="txt" style="width:50px;margin-right:3px" name="it618_uid['.$it618_ad_wap_sale[id].']" value="'.$it618_ad_wap_sale[it618_uid].'"><b><font color=green>'.$username.'</font></b>';
		}else{
			$it618_isuser='';	
		}
		if($it618_ad_wap_sale[it618_pid]>0)$it618_pid=' '.$it618_ad_lang['s350'].'<font color=red>'.$it618_ad_wap_sale[it618_pid].'</font> ';else $it618_pid='';
		
		$adstr=$it618_ad_lang['s344'].'<font color=red>'.$it618_ad_wap_sale[it618_aid].'</font> '.$it618_adtype.$it618_pid.$it618_lou.$it618_isuser;
		
		$preurl='&sql='.str_replace("&","@",$sql);
		
		$it618_etime=explode(" ",$it618_ad_wap_sale['it618_etime']);
		$it618_etime1=explode("-",$it618_etime[0]);
		$it618_etime2=explode(":",$it618_etime[1]);
		
		$etime=mktime($it618_etime2[0], $it618_etime2[1], 0, $it618_etime1[1], $it618_etime1[2], $it618_etime1[0]);
		
		if($etime-$_G['timestamp']>0){
			$timecount=$it618_ad_lang['s347'].'<font color=green>'.sprintf("%.2f", ($etime-$_G['timestamp'])/3600/24).'</font>'.' '.$it618_ad_lang['s223'];
		}else{
			$timecount='<font color=#999>'.$it618_ad_lang['s348'].'</font>';
		}
		
		if($it618_ad_wap_sale['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		showtablerow('', array('style="width:60px"', '', '', '', '', '', '', ''), array(
			$it618_ad_wap_sale[id].'<input class="checkbox" type="checkbox" name="delete[]" value="'.$it618_ad_wap_sale[id].'">',
			$adstr,
			'<a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_wap_sale_edit&pmod=admin_wap_sale&operation='.$operation.'&do='.$do.'&sid='.$it618_ad_wap_sale[id].$preurl.'">'.$it618_ad_lang['s343'].'</a>',
			'<input type="text" class="txt" style="width:126px;margin-right:3px" name="it618_etime['.$it618_ad_wap_sale[id].']" value="'.$it618_ad_wap_sale[it618_etime].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')" readonly="readonly">'.$timecount,
			'<input type="text" class="txt" style="width:300px" name="it618_bz['.$it618_ad_wap_sale[id].']" value="'.$it618_ad_wap_sale[it618_bz].'">',
			'<input type="checkbox" name="it618_isok['.$it618_ad_wap_sale[id].']" value="1" '.$it618_isok_checked.'>'
		));
		
		$n=$n+1;
	}
	
	showsubmit('it618submit', 'submit', 'del');
	echo '<script charset="utf-8" src="source/plugin/it618_ad/js/Calendar.js"></script>';
	if(count($reabc)!=8)return; /*dism_ taobao_ com*/
showtablefooter(); /*dism��taobao��com*/
?>