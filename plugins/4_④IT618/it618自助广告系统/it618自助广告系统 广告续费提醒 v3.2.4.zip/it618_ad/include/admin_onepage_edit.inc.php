<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$oid=intval($_GET['oid']);
if(submitcheck('it618submit')){

	C::t('#it618_ad#it618_ad_onepage')->update($oid,array(
		'it618_name' => $_GET['it618_name'],
		'it618_seokeywords' => $_GET['it618_seokeywords'],
		'it618_seodescription' => $_GET['it618_seodescription'],
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	));

	cpmsg($it618_ad_lang['s290'], "action=plugins&identifier=$identifier&cp=admin_onepage_edit&pmod=admin_onepage&operation=$operation&do=$do&page=$page&oid=$oid", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_onepage_edit&pmod=admin_onepage&operation=$operation&do=$do&oid=$oid");
showtableheaders($it618_ad_lang['s291'],'it618_ad_onepage');

$it618_ad_onepage=C::t('#it618_ad#it618_ad_onepage')->fetch_by_id($oid);

echo '
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/plugins/code/prettify.js"></script>
<script>
KindEditor.ready(function(K) {
	var editor1 = K.create(\'textarea[name="it618_message"]\', {
		cssPath : \'source/plugin/it618_ad/kindeditor/plugins/code/prettify.css\',
		uploadJson : \'source/plugin/it618_ad/kindeditor/php/upload_json.php\',
		fileManagerJson : \'source/plugin/it618_ad/kindeditor/php/file_manager_json.php\',
		allowFileManager : true,
		filterMode:false
	});
	prettyPrint();
});
	
function checkvalue(){
	if(document.getElementById("it618_name").value==""){
		alert("'.$it618_ad_lang['s283'].'");
		return false;
	}
}
</script>
	
<tr><td width=80>'.$it618_ad_lang['s284'].'</td><td><input type="text" class="txt" style="width:400px;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_ad_onepage['it618_name'].'"></td></tr>
<tr><td>'.$it618_ad_lang['s285'].'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_ad_onepage['it618_message'].'</textarea></td></tr>
<tr><td>'.$it618_ad_lang['s287'].'</td><td><input type="text" class="txt" style="width:695px;margin-right:0" name="it618_seokeywords" value="'.$it618_ad_onepage[it618_seokeywords].'"></td></tr>
<tr><td>'.$it618_ad_lang['s288'].'</td><td><textarea name="it618_seodescription" style="width:695px;height:50px;">'.$it618_ad_onepage[it618_seodescription].'</textarea></td></tr>
<tr><td colspan="2"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.$it618_ad_lang['s289'].'" /></div></td></tr>';

showtablefooter(); /*dism��taobao��com*/
?>