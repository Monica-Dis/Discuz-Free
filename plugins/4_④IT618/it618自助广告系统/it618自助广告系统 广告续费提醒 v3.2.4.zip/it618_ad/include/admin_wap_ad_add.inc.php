<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){

	C::t('#it618_ad#it618_ad_wap_ad')->insert(array(
		'it618_title' => $_GET['it618_title'],
		'it618_blockname' => $_GET['it618_blockname'],
		'it618_isuser' => $_GET['it618_isuser'],
		'it618_adtype' => intval($_GET['it618_adtype']),
		'it618_ison' => 0,
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	), true);

	cpmsg($it618_ad_lang['s111'], "action=plugins&identifier=$identifier&cp=admin_wap_ad_add&pmod=admin_wap_ad&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_wap_ad_add&pmod=admin_wap_ad&operation=$operation&do=$do");
showtableheaders($it618_ad_lang['s112'],'it618_ad_wap_add');

foreach($adblock_arr as $id => $adblock){
	$blocktmp.='<option value="'.$adblock.'">'.$adblocktitle_arr[$id].'</option>';
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_ad/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_ad/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_ad/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});

		prettyPrint();
	});
	
	function checkvalue(){
		var it618_blockname = document.getElementById("it618_blockname").value;
		
		if(it618_blockname==""){
			alert("'.$it618_ad_lang['s19'].'");
			return false;
		}
	}
	
	function adtype(obj){
		if(obj.value==2){
			document.getElementById("trmsg").style.display="none";
		}else{
			document.getElementById("trmsg").style.display="";
		}
	}
	
	function adblock(obj){
		if(obj.value=="viewthread_top_mobile"||obj.value=="tiecontent_top"||obj.value=="tiecontent_bottom"||obj.value=="viewthread_bottom_mobile"){
			document.getElementById("isuser").style.display="";
		}else{
			document.getElementById("isuser").style.display="none";
		}
	}
</script>
	
<tr><td width=77>'.$it618_ad_lang['s119'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_title"/>'.$it618_ad_lang['s120'].'</td></tr>
<tr><td><font color=red>'.$it618_ad_lang['s124'].'</font></td><td><select id="it618_blockname" onchange="adblock(this)" name="it618_blockname" style="color:blue">'.$blocktmp.'</select> <span id="isuser" style="display:none"><input type="checkbox" id="it618_isuser" style="vertical-align:middle" name="it618_isuser" value="1"><label for="it618_isuser">'.$it618_ad_lang['s340'].'</label><br><br>'.$it618_ad_lang['s342'].'</span></td></tr>
<tr><td>'.$it618_ad_lang['s129'].'</td><td><select name="it618_adtype" onchange="adtype(this)"><option value=1>'.$it618_ad_lang['s309'].'</option><option value=2>'.$it618_ad_lang['s310'].'</option></select></td></tr>
<tr id="trmsg"><td>'.$it618_ad_lang['s311'].'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;"></textarea></td></tr>
<tr><td colspan="2"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.$it618_ad_lang['s144'].'" /></div></td></tr>
';

if(count($reabc)!=8)return; /*dism_ taobao_ com*/
showtablefooter(); /*dism��taobao��com*/

?>