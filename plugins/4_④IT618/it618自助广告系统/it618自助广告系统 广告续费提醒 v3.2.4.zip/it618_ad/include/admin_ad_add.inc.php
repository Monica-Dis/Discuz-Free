<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){

	C::t('#it618_ad#it618_ad_ad')->insert(array(
		'it618_title' => $_GET['it618_title'],
		'it618_blockname' => $_GET['it618_blockname'],
		'it618_price' => intval($_GET['it618_price']),
		'it618_count1' => intval($_GET['it618_count1']),
		'it618_count2' => intval($_GET['it618_count2']),
		'it618_pricetype' => intval($_GET['it618_pricetype']),
		'it618_adtype' => intval($_GET['it618_adtype']),
		'it618_saletype' => intval($_GET['it618_saletype']),
		'it618_ison' => 0,
		'it618_about' => $_GET['it618_about'],
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	), true);

	cpmsg($it618_ad_lang['s111'], "action=plugins&identifier=$identifier&cp=admin_ad_add&pmod=admin_ad&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_ad_add&pmod=admin_ad&operation=$operation&do=$do");
showtableheaders($it618_ad_lang['s112'],'it618_ad_add');

$blocktmp='<option value="global_header">'.$it618_ad_lang['s304'].'</option>';
$query1 = DB::query("SELECT title FROM ".DB::table('common_advertisement')." where title LIKE 'it618ad_%' ORDER BY title");
while($it618_tmp =	DB::fetch($query1)) {
	$blocktmp.='<option value='.$it618_tmp['title'].'>[AD] '.str_replace("it618ad_","",$it618_tmp['title']).'</option>';
}

$query1 = DB::query("SELECT name FROM ".DB::table('common_block')." where name LIKE 'it618ad_%' group by name ORDER BY name");
while($it618_tmp =	DB::fetch($query1)) {
	$blocktmp.='<option value='.$it618_tmp['name'].'>[DIY] '.str_replace("it618ad_","",$it618_tmp['name']).'</option>';
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_ad/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_ad/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_ad/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});

		prettyPrint();
	});
	
	function checkvalue(){
		var it618_blockname = document.getElementById("it618_blockname").value;
		
		if(it618_blockname==""){
			alert("'.$it618_ad_lang['s19'].'");
			return false;
		}
	}
	
	function adtype(obj){
		if(obj.value==4){
			document.getElementById("trmsg").style.display="none";
		}else{
			document.getElementById("trmsg").style.display="";
		}
	}
</script>
	
<tr><td width=77>'.$it618_ad_lang['s119'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_title"/>'.$it618_ad_lang['s120'].'</td></tr>
<tr><td><font color=red>'.$it618_ad_lang['s124'].'</font></td><td><select id="it618_blockname" name="it618_blockname" style="color:blue">'.$blocktmp.'</select></td></tr>
<tr><td>'.$it618_ad_lang['s129'].'</td><td><select name="it618_adtype" onchange="adtype(this)"><option value=1>'.$it618_ad_lang['s130'].'</option><option value=2>'.$it618_ad_lang['s131'].'</option><option value=3>'.$it618_ad_lang['s221'].'</option><option value=4>'.$it618_ad_lang['s255'].'</option></select> <font color=red>'.$it618_ad_lang['s20'].'</font></td></tr>
<tr><td>'.$it618_ad_lang['s127'].'</td><td><input type="text" class="txt" style="width:50px" name="it618_price" value="0"/>'.$creditname.'/<select name="it618_pricetype" style="margin-right:6px"><option value=2>'.$it618_ad_lang['s223'].'</option><option value=1>'.$it618_ad_lang['s33'].'</option></select></td></tr>
<tr><td>'.$it618_ad_lang['s141'].'</td><td><textarea name="it618_about" style="width:696px;height:70px;">'.$it618_ad_lang['s142'].'</textarea></td></tr>
<tr id="trmsg"><td>'.$it618_ad_lang['s143'].'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;"></textarea></td></tr>
<tr><td colspan="2"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.$it618_ad_lang['s144'].'" /></div></td></tr>
';

if(count($reabc)!=8)return; /*dism_ taobao_ com*/
showtablefooter(); /*dism��taobao��com*/

?>