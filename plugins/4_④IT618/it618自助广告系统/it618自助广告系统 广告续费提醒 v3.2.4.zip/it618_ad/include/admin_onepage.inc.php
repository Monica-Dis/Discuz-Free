<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$sql='&key='.$_GET['key'];

if(submitcheck('it618submit')){
	$del=0;
	$ok=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_ad#it618_ad_onepage')->delete_by_id($delid);
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_ad#it618_ad_onepage')->update($id,array(
				'it618_name' => $_GET['it618_name'][$id],
				'it618_order' => $_GET['it618_order'][$id]
			));

			$ok=$ok+1;
		}
	}

	cpmsg($it618_ad_lang['s70'].$ok.' '.$it618_ad_lang['s71'].$del, "action=plugins&identifier=$identifier&cp=admin_onepage&pmod=admin_onepage&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_onepage&pmod=admin_onepage&operation=$operation&do=$do".$sql);
showtableheaders($it618_ad_lang['s272'],'it618_ad_onepage');

	echo '<tr><td colspan=14>'.$it618_ad_lang['s273'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.$it618_ad_lang['s274'].'" /></td></tr>';
	
	$count = C::t('#it618_ad#it618_ad_onepage')->count_by_search($_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_onepage&pmod=admin_onepage&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=8>'.$it618_ad_lang['s275'].$count.'</td></tr>';
	showsubtitle(array('',$it618_ad_lang['s276'],$it618_ad_lang['s277'],$it618_ad_lang['s278'],$it618_ad_lang['s279']));

	$n=1;
	foreach(C::t('#it618_ad#it618_ad_onepage')->fetch_all_by_search(
		$_GET['key'],$startlimit,$ppp
	) as $it618_ad_onepage) {

		showtablerow('', array('class="td25"', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_ad_onepage[id].'"><label for="chk_del'.$n.'">'.$it618_ad_onepage['id'].'</label>',
			'<input type="text" class="txt" style="width:300px" name="it618_name['.$it618_ad_onepage[id].']" value="'.$it618_ad_onepage[it618_name].'"><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_onepage_edit&pmod=admin_onepage&operation='.$operation.'&do='.$do.'&oid='.$it618_ad_onepage[id].'">'.$it618_ad_lang['s99'].'</a>',
			'<a href="'.$_G['siteurl'].'plugin.php?id=it618_ad:onepage&oid='.$it618_ad_onepage[id].'" target="_blank">'.$_G['siteurl'].'plugin.php?id=it618_ad:onepage&oid='.$it618_ad_onepage[id].'</a>',
			'<a href="'.$_G['siteurl'].'ad-'.$it618_ad_onepage[id].'.html" target="_blank">'.$_G['siteurl'].'ad-'.$it618_ad_onepage[id].'.html</a>',
			$it618_ad_onepage[it618_views]
		));
		$n=$n+1;
	}
	
	showsubmit('it618submit', 'submit', 'del', '<input type=hidden value=$page name=page />', $multipage);
	
	echo '<tr><td colspan=8><br>'.$it618_ad_lang['s280'].'</td></tr>';

showtablefooter(); /*dism��taobao��com*/
?>