<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];

foreach($adblock_arr as $id => $adblock){
	$blocktmp.='<option value="'.$adblock.'">'.$adblocktitle_arr[$id].'</option>';
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_ad')." WHERE it618_blockname='".$adblock."'");
	$licss='';
	if(isset($_GET['find_blockname'])){
		if($_GET['find_blockname']==$adblock){
			$licss='class="current"';
			$it618_blockname=$adblock;
		}else{
			$licss='';
		}
	}elseif($id==0){
		$licss='class="current"';
		$it618_blockname=$adblock;
	}
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_wap_ad&pmod=admin_wap_ad&find_blockname=$adblock&operation=$operation&do=$do&page=$page\"><span>".$adblocktitle_arr[$id].'(<font color=red>'.$count.'</font>)</span></a></li>';
}


echo '<style>.itemtitle1 .current{background-color:#666} .itemtitle1 .noblock{color:blue}</style><div class="itemtitle itemtitle1" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';


$extrasql = "it618_blockname ='".$it618_blockname."'";	

if($_GET['find_title']) {
	$extrasql .= " AND it618_title LIKE '%".addcslashes($_GET['find_title'],'%_')."%'";
}
if($_GET['adtype']) {
	$adtype0='';$adtype1='';$adtype2='';$adtype3='';
	if($_GET['adtype']==0){$extrasql .= "";$adtype0='selected="selected"';}
	if($_GET['adtype']==1){$extrasql .= " AND it618_adtype = 1";$adtype1='selected="selected"';}
	if($_GET['adtype']==2){$extrasql .= " AND it618_adtype = 2";$adtype2='selected="selected"';}
}
$sql.='&find_blockname='.$it618_blockname.'&find_title='.$_GET['find_title'].'&adtype='.$_GET['adtype'];

if(submitcheck('it618submit')){
	$del=0;
	$ok=0;
	if($reabc[7]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_ad_wap_ad', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_title'])) {
		foreach($_GET['it618_title'] as $id => $val) {
			if(intval($_GET['it618_row'][$id])==0)$it618_row=1; else$it618_row=intval($_GET['it618_row'][$id]);
			
			C::t('#it618_ad#it618_ad_wap_ad')->update($id,array(
				'it618_title' => $_GET['it618_title'][$id],
				'it618_blockname' => $_GET['it618_blockname'][$id],
				'it618_url' => $_GET['it618_url'][$id],
				'it618_tids' => $_GET['it618_tids'][$id],
				'it618_typids' => $_GET['it618_typids'][$id],
				'it618_fids' => $_GET['it618_fids'][$id],
				'it618_lou' => $_GET['it618_lou'][$id],
				'it618_row' => $it618_row,
				'it618_padding_top' => intval($_GET['it618_padding_top'][$id]),
				'it618_padding_bottom' => intval($_GET['it618_padding_bottom'][$id]),
				'it618_isrand' => intval($_GET['it618_isrand'][$id]),
				'it618_speed' => intval($_GET['it618_speed'][$id]),
				'it618_isnofollow' => intval($_GET['it618_isnofollow'][$id]),
				'it618_ison' => intval($_GET['it618_ison'][$id])
			));
			$ok=$ok+1;
		}
	}

	cpmsg($it618_ad_lang['s70'].$ok.' '.$it618_ad_lang['s71'].$del, "action=plugins&identifier=$identifier&cp=admin_wap_ad&pmod=admin_wap_ad&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=8)return; /*dism_ taobao_ com*/

echo '
<style>
tr td{line-height:22px}
</style>
';

if($it618_blockname=='viewthread_top_mobile'||$it618_blockname=='tiecontent_top'||$it618_blockname=='tiecontent_bottom'||$it618_blockname=='viewthread_bottom_mobile'){
	$url_str=$it618_ad_lang['s331'];
	$str_urltip=$it618_ad_lang['s327'].$it618_ad_lang['s342'];
}else{
	$url_str=$it618_ad_lang['s312'];
	$str_urltip=$it618_ad_lang['s313'];
}

showformheader("plugins&identifier=$identifier&cp=admin_wap_ad&pmod=admin_wap_ad&operation=$operation&do=$do".$sql);
showtableheaders('<span style="float:right;color:blue">'.$it618_blockname.'</span>'.$it618_ad_lang['s72'],'it618_ad');
	showsubmit('it618sercsubmit', $it618_ad_lang['s73'], $it618_ad_lang['s75'].' <input name="find_title" value="'.$_GET['find_title'].'" class="txt" style="width:150px" /> '.$it618_ad_lang['s218'].' <select name="adtype"><option value=0 '.$adtype0.'>'.$it618_ad_lang['s219'].'</option><option value=1 '.$adtype1.'>'.$it618_ad_lang['s309'].'</option><option value=2 '.$adtype2.'>'.$it618_ad_lang['s310'].'</option</select>');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_ad')." WHERE $extrasql");
	
	echo '<tr><td colspan=8>'.$it618_ad_lang['s87'].$count.'<span style="float:right;color:red">'.$it618_ad_lang['s308'].'</span></td></tr>';
	showsubtitle(array($it618_ad_lang['s88'],$it618_ad_lang['s89'],$it618_ad_lang['s90'],$it618_ad_lang['s91'],$url_str,$it618_ad_lang['s307'],$it618_ad_lang['s296']));

	$n=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_ad_wap_ad')." WHERE $extrasql order by it618_lou,it618_row,id desc");
	while($it618_ad_wap_ad = DB::fetch($query)) {
		
		$preurl='&sql='.str_replace("&","@",$sql);
		
		$pagestr='';
		$foucsstr='';
		$editstr='';
		$addstr='';
		if($it618_ad_wap_ad['it618_adtype']==2){
			if($it618_ad_wap_ad['it618_isrand']==1)$it618_isrand_checked='checked="checked"';else $it618_isrand_checked="";
			
			$pagestr=' <input type="checkbox" id="it618_isrand'.$it618_ad_wap_ad[id].'" style="vertical-align:middle" name="it618_isrand['.$it618_ad_wap_ad[id].']" value="1" '.$it618_isrand_checked.'><label for="it618_isrand'.$it618_ad_wap_ad[id].'">'.$it618_ad_lang['s11'].'</label><br>'.$it618_ad_lang['s262'].'<input type="text" name="it618_speed['.$it618_ad_wap_ad[id].']" style="width:35px" value="'.$it618_ad_wap_ad[it618_speed].'">';
			$it618_adtypename=$it618_ad_lang['s310'].$pagestr;
			
			$foucscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_ad_focus')." WHERE it618_aid=".$it618_ad_wap_ad['id']);
			$foucsstr=' <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_wap_ad_focus&pmod=admin_wap_ad&operation='.$operation.'&do='.$do.'&aid='.$it618_ad_wap_ad[id].$preurl.'">'.$it618_ad_lang['s4'].'(<font color=red>'.$foucscount.'</font>)</a>';
		}else{
			$it618_adtypename=$it618_ad_lang['s309'];
			$editstr='<a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_wap_ad_edit&pmod=admin_wap_ad&operation='.$operation.'&do='.$do.'&aid='.$it618_ad_wap_ad[id].$preurl.'">'.$it618_ad_lang['s99'].'</a>';	
			
			if(($it618_ad_wap_ad['it618_isuser']==0&&DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')."  WHERE it618_aid=".$it618_ad_wap_ad['id'])==0)||$it618_ad_wap_ad['it618_isuser']==1){
				$addstr='<a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_wap_sale&pmod=admin_wap_sale&operation='.$operation.'&do='.$do.'&ac=add&aid='.$it618_ad_wap_ad[id].'&pid=0'.$preurl.'">'.$it618_ad_lang['s341'].'(<font color=red>'.DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')."  WHERE it618_aid=".$it618_ad_wap_ad['id']).'</font>)</a> | ';
			}
		}
		
		if($it618_ad_wap_ad['it618_isnofollow']==1)$it618_isnofollow_checked='checked="checked"';else $it618_isnofollow_checked="";
		if($it618_ad_wap_ad['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
		
		$blocktmp1=str_replace('<option value="'.$it618_ad_wap_ad['it618_blockname'].'">','<option value="'.$it618_ad_wap_ad['it618_blockname'].'" selected="selected">',$blocktmp);
		
		$tmplou='';
		$tmpuser='';
		if($it618_blockname=='tiecontent_top'||$it618_blockname=='tiecontent_bottom'){
			for($i=1;$i<=10;$i++){
				$tmplou.='<option value="'.$i.'">'.$i.$it618_ad_lang['s326'].'</option>';
			}
			
			$tmplou=str_replace('<option value="'.$it618_ad_wap_ad['it618_lou'].'">','<option value="'.$it618_ad_wap_ad['it618_lou'].'" selected="selected">',$tmplou);
			$tmplou='<select name="it618_lou['.$it618_ad_wap_ad[id].']">'.$tmplou.'</select> ';
			
		}
		
		if($it618_blockname=='viewthread_top_mobile'||$it618_blockname=='tiecontent_top'||$it618_blockname=='tiecontent_bottom'||$it618_blockname=='viewthread_bottom_mobile'){
			if($it618_ad_wap_ad['it618_isuser']==1){
				$tmpuser='<br>'.$it618_ad_lang['s340'];
			}
		}
		
		if($it618_blockname=='viewthread_top_mobile'||$it618_blockname=='tiecontent_top'||$it618_blockname=='tiecontent_bottom'||$it618_blockname=='viewthread_bottom_mobile'){
			$str_url=$it618_ad_lang['s328'].'<input type="text" class="txt" style="width:100px;color:blue" name="it618_fids['.$it618_ad_wap_ad[id].']" value="'.$it618_ad_wap_ad[it618_fids].'">'.$it618_ad_lang['s329'].'<input type="text" class="txt" style="width:100px;color:blue" name="it618_typids['.$it618_ad_wap_ad[id].']" value="'.$it618_ad_wap_ad[it618_typids].'"><br>'.$it618_ad_lang['s330'].'<input type="text" class="txt" style="width:266px;color:blue" name="it618_tids['.$it618_ad_wap_ad[id].']" value="'.$it618_ad_wap_ad[it618_tids].'">';
		}else{
			$str_url='<input type="text" class="txt" style="width:350px" name="it618_url['.$it618_ad_wap_ad[id].']" value="'.$it618_ad_wap_ad[it618_url].'">';
		}
		
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')." WHERE it618_aid=".$it618_ad_wap_ad['id'])>0)$deldisabled='disabled="disabled"';else $deldisabled='';
		
		showtablerow('', array('style="width:60px"', '', '', '', '', '', '', ''), array(
			$it618_ad_wap_ad[id].'<input class="checkbox" type="checkbox" name="delete[]" value="'.$it618_ad_wap_ad[id].'" '.$deldisabled.'><input type="hidden" id="it618_id'.$n.'" name="id['.$it618_ad_wap_ad[id].']" value="'.$it618_ad_wap_ad[id].'">',
			'<input type="text" class="txt" style="width:190px" name="it618_title['.$it618_ad_wap_ad[id].']" value="'.$it618_ad_wap_ad[it618_title].'"><br>'.$addstr.'<a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_wap_ad_edit&pmod=admin_wap_ad&operation='.$operation.'&do='.$do.'&ac=copy&aid='.$it618_ad_wap_ad[id].$preurl.'">'.$it618_ad_lang['s100'].'</a> | '.$editstr.$foucsstr,
			'<select id="it618_blockname'.$n.'" name="it618_blockname['.$it618_ad_wap_ad[id].']" style="color:blue">'.$blocktmp1.'</select>'.$tmplou.$tmpuser,
			$it618_adtypename,
			$str_url,
			'<input type="text" class="txt" style="width:30px;margin-right:0px;color:blue; font-weight:bold" name="it618_row['.$it618_ad_wap_ad[id].']" value="'.$it618_ad_wap_ad[it618_row].'">/<input type="text" class="txt" style="width:30px;margin-right:0px" name="it618_padding_top['.$it618_ad_wap_ad[id].']" value="'.$it618_ad_wap_ad[it618_padding_top].'"><input type="text" class="txt" style="width:30px;margin-right:0px" name="it618_padding_bottom['.$it618_ad_wap_ad[id].']" value="'.$it618_ad_wap_ad[it618_padding_bottom].'"><br><input type="checkbox" id="it618_isnofollow'.$it618_ad_wap_ad[id].'" style="vertical-align:middle" name="it618_isnofollow['.$it618_ad_wap_ad[id].']" value="1" '.$it618_isnofollow_checked.'><label for="it618_isnofollow'.$it618_ad_wap_ad[id].'">'.$it618_ad_lang['s234'].'</label>',
			'<input type="checkbox" name="it618_ison['.$it618_ad_wap_ad[id].']" value="1" '.$it618_ison_checked.'>'
		));
		
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallI3B2" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallI3B2">'.$it618_ad_lang['s12'].'</label></td><td colspan="15"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue()" name="it618submit" value="'.$it618_ad_lang['s13'].'" /> <font color=red>'.$str_urltip.'</font></div></td></tr>';
	
	if(count($reabc)!=8)return; /*dism_ taobao_ com*/
showtablefooter(); /*dism��taobao��com*/
?>