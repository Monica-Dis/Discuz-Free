<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';

if(submitcheck('it618submit_del3')){
	$del=0;
	if($reabc[7]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$delid);
		$saleuid=$it618_ad_sale['it618_uid'];
		if($it618_ad_sale['it618_state']<4){
			if($it618_ad_sale['it618_uploadimg']!=''){
				$tmparr=explode("source",$it618_ad_sale['it618_uploadimg']);
				$it618_uploadimg=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_uploadimg)){
					$result=unlink($it618_uploadimg);
				}
			}
			
			if($it618_ad_sale['it618_state']==3){
				if($it618_ad_sale['it618_pricetype']==1){
					$ad_credit=intval(($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600*$it618_ad_sale['it618_price']);
				}else{
					$ad_credit=intval(($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600/24*$it618_ad_sale['it618_price']);
				}
			}else{
				$ad_credit=$it618_ad_sale['it618_price']*$it618_ad_sale['it618_count'];
			}
			
			C::t('common_member_count')->increase($saleuid, array(
				'extcredits'.$it618_ad['ad_credit'] => $ad_credit)
			);
			
			DB::query("update ".DB::table('it618_ad_ad')." set it618_salecount=it618_salecount-1,it618_state=0 where id=".$it618_ad_sale['it618_aid']);
			
			DB::delete('it618_ad_sale', "id=$delid");
			$del=$del+1;
		}
	}

	cpmsg($it618_ad_lang['s160'].$del.$it618_ad_lang['s161'], "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_del4')){
	$del=0;
	if($reabc[7]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$delid);
		$saleuid=$it618_ad_sale['it618_uid'];
		
		if($it618_ad_sale['it618_state']<4){
			if($it618_ad_sale['it618_uploadimg']!=''){
				$tmparr=explode("source",$it618_ad_sale['it618_uploadimg']);
				$it618_uploadimg=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_uploadimg)){
					$result=unlink($it618_uploadimg);
				}
			}
			
			DB::query("update ".DB::table('it618_ad_ad')." set it618_salecount=it618_salecount-1,it618_state=0 where id=".$it618_ad_sale['it618_aid']);
			
			DB::delete('it618_ad_sale', "id=$delid");
			$del=$del+1;
		}
	}

	cpmsg($it618_ad_lang['s160'].$del.$it618_ad_lang['s372'], "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_del1')){
	$del=0;
	if($reabc[7]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$delid);
		$saleuid=$it618_ad_sale['it618_uid'];
		
		if($it618_ad_sale['it618_state']<4){
			if($it618_ad_sale['it618_state']==3){
				if($it618_ad_sale['it618_pricetype']==1){
					$ad_credit=intval(($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600*$it618_ad_sale['it618_price']);
				}else{
					$ad_credit=intval(($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600/24*$it618_ad_sale['it618_price']);
				}
			}else{
				$ad_credit=$it618_ad_sale['it618_price']*$it618_ad_sale['it618_count'];
			}
			
			C::t('common_member_count')->increase($saleuid, array(
				'extcredits'.$it618_ad['ad_credit'] => $ad_credit)
			);
			
			DB::query("update ".DB::table('it618_ad_ad')." set it618_salecount=it618_salecount-1,it618_state=0 where id=".$it618_ad_sale['it618_aid']);
			
			DB::query("update ".DB::table('it618_ad_sale')." set it618_score=$ad_credit,it618_state=5 where id=".$it618_ad_sale['id']);
			
			$del=$del+1;
		}

	}

	cpmsg($it618_ad_lang['s371'].$del.$it618_ad_lang['s161'], "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_del2')){
	$del=0;
	if($reabc[7]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$delid);
		$saleuid=$it618_ad_sale['it618_uid'];
		
		if($it618_ad_sale['it618_state']<4){
			if($it618_ad_sale['it618_state']==3){
				if($it618_ad_sale['it618_pricetype']==1){
					$ad_credit=intval(($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600*$it618_ad_sale['it618_price']);
				}else{
					$ad_credit=intval(($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600/24*$it618_ad_sale['it618_price']);
				}
			}else{
				$ad_credit=$it618_ad_sale['it618_price']*$it618_ad_sale['it618_count'];
			}
			
			DB::query("update ".DB::table('it618_ad_ad')." set it618_salecount=it618_salecount-1,it618_state=0 where id=".$it618_ad_sale['it618_aid']);
			
			DB::query("update ".DB::table('it618_ad_sale')." set it618_state=5 where id=".$it618_ad_sale['id']);
			
			$del=$del+1;
		}
	}

	cpmsg($it618_ad_lang['s371'].$del.$it618_ad_lang['s372'], "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[6]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$delid);
		
		if($it618_ad_sale['it618_state']==1){
			$it618_btime=$_G['timestamp'];
			if($it618_ad_sale['it618_pricetype']==1){
				$it618_etime=$it618_btime + 3600*$it618_ad_sale['it618_count'];
			}else{
				$it618_etime=$it618_btime + 3600*24*$it618_ad_sale['it618_count'];
			}
			
			it618_ad_sendmessage("ad_user",$it618_ad_sale['id']);
			DB::query("update ".DB::table('it618_ad_sale')." set it618_state=3,it618_btime=".$it618_btime.",it618_etime=".$it618_etime." WHERE id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_ad_lang['s162'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[6]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_ad_sale = DB::fetch_first("SELECT it618_state FROM ".DB::table('it618_ad_sale')." where id=".$delid);
		
		if($it618_ad_sale['it618_state']==1){
			it618_ad_sendmessage("ad1_user",$delid);
			DB::query("update ".DB::table('it618_ad_sale')." set it618_state=2 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_ad_lang['s163'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=8)return; /*dism_ taobao_ com*/
if(submitcheck('it618sercsubmit')) {
	if($_GET['key']) {
		$extrasql .= " AND a.it618_title LIKE '%".addcslashes($_GET['key'],'%_')."%'";
	}
	
	if($_GET['finduid']) {
		$extrasql .= " AND s.it618_uid = ".intval($_GET['finduid']);
	}
	
	if($_GET['adtype']) {
		$adtype0='';$adtype1='';$adtype2='';$adtype3='';
		if($_GET['adtype']==0){$extrasql .= "";$adtype0='selected="selected"';}
		if($_GET['adtype']==1){$extrasql .= " AND a.it618_adtype = 1";$adtype1='selected="selected"';}
		if($_GET['adtype']==2){$extrasql .= " AND a.it618_adtype = 2";$adtype2='selected="selected"';}
		if($_GET['adtype']==3){$extrasql .= " AND a.it618_adtype = 3";$adtype3='selected="selected"';}
		if($_GET['adtype']==4){$extrasql .= " AND a.it618_adtype = 4";$adtype4='selected="selected"';}
	}
	
	if($_GET['state']) {
		$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';
		if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
		if($_GET['state']==1){$extrasql .= " AND s.it618_state = 0";$state1='selected="selected"';}
		if($_GET['state']==2){$extrasql .= " AND s.it618_state = 1";$state2='selected="selected"';}
		if($_GET['state']==3){$extrasql .= " AND s.it618_state = 2";$state3='selected="selected"';}
		if($_GET['state']==4){$extrasql .= " AND s.it618_state = 3";$state4='selected="selected"';}
		if($_GET['state']==5){$extrasql .= " AND s.it618_state = 4";$state5='selected="selected"';}
		if($_GET['state']==6){$extrasql .= " AND s.it618_state = 5";$state6='selected="selected"';}
	}
}

echo '
<link rel="stylesheet" href="source/plugin/it618_ad/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_ad/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_ad/js/jquery.js"></script>
';

showformheader("plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do");
showtableheaders($it618_ad_lang['s164'],'it618_ad_sale');
	showsubmit('it618sercsubmit', $it618_ad_lang['s165'], $it618_ad_lang['s166'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.$it618_ad_lang['s167'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_ad_lang['t119'].'<select name="adtype"><option value=0 '.$adtype0.'>'.$it618_ad_lang['s219'].'</option><option value=1 '.$adtype1.'>'.$it618_ad_lang['s102'].'</option><option value=2 '.$adtype2.'>'.$it618_ad_lang['s103'].'</option><option value=3 '.$adtype3.'>'.$it618_ad_lang['s221'].'</option><option value=4 '.$adtype4.'>'.$it618_ad_lang['s255'].'</option></select> '.$it618_ad_lang['s168'].' <select name="state"><option value=0 '.$state0.'>'.$it618_ad_lang['s169'].'</option><option value=1 '.$state1.'>'.$it618_ad_lang['s170'].'</option><option value=2 '.$state2.'>'.$it618_ad_lang['s171'].'</option><option value=3 '.$state3.'>'.$it618_ad_lang['s172'].'</option><option value=4 '.$state4.'>'.$it618_ad_lang['s173'].'</option><option value=5 '.$state5.'>'.$it618_ad_lang['s174'].'</option><option value=6 '.$state6.'>'.$it618_ad_lang['s366'].'</option></select>');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_sale')." s,".DB::table('it618_ad_ad')." a WHERE s.it618_aid=a.id $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do");
	
	echo '<tr><td colspan=7>'.$it618_ad_lang['s175'].$count.'</td></tr>';
	showsubtitle(array('', $it618_ad_lang['s176'],$it618_ad_lang['t49'],$it618_ad_lang['t50'],$it618_ad_lang['t51'],$it618_ad_lang['s181'],$it618_ad_lang['s182'],$it618_ad_lang['s212'],$it618_ad_lang['t56'],$it618_ad_lang['s184'],$it618_ad_lang['s185']));
	
	$query = DB::query("SELECT s.*,a.it618_blockname FROM ".DB::table('it618_ad_sale')." s,".DB::table('it618_ad_ad')." a WHERE s.it618_aid=a.id $extrasql order by id desc LIMIT $startlimit, $ppp");
	while($it618_ad_sale = DB::fetch($query)) {
		
		$it618_ad_ad = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$it618_ad_sale['it618_aid']);
		$it618_class_id=$it618_ad_ad['it618_class_id'];
		$it618_title=$it618_ad_ad['it618_title'];
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_ad_sale['it618_uid']);
		
		$aidstr=$it618_ad_sale['it618_aid'];
		if($it618_ad_ad['it618_adtype']==1)$it618_adtype=$it618_ad_lang['s102'];
		if($it618_ad_ad['it618_adtype']==2)$it618_adtype=$it618_ad_lang['s103'];
		if($it618_ad_ad['it618_adtype']==3)$it618_adtype=$it618_ad_lang['s221'];
		if($it618_ad_ad['it618_adtype']==4){
			$aidstr=$it618_ad_sale['it618_aid'].'-'.$it618_ad_sale['it618_pid'];
			$it618_adtype=$it618_ad_lang['s255'];
		}
		
		$strtmp='<a href="javascript:" id="adcontent'.$it618_ad_sale[id].'">'.$it618_ad_lang['s188'].'</a>';
		
		if($it618_ad_ad['it618_pricetype']==1)$it618_pricetype=$it618_ad_lang['s33'];
		if($it618_ad_ad['it618_pricetype']==2)$it618_pricetype=$it618_ad_lang['s223'];
		
		if($it618_ad_sale['it618_state']==0)$it618_state='<font color=blue>'.$it618_ad_lang['s170'].'</font>';
		if($it618_ad_sale['it618_state']==1)$it618_state='<font color=red>'.$it618_ad_lang['s171'].'</font>';
		if($it618_ad_sale['it618_state']==2)$it618_state='<font color=blue>'.$it618_ad_lang['s172'].'</font>';
		if($it618_ad_sale['it618_state']==3)$it618_state='<font color=green>'.$it618_ad_lang['s173'].'</font>';
		if($it618_ad_sale['it618_state']==4)$it618_state='<font color=#ccc>'.$it618_ad_lang['s174'].'</font>';
		if($it618_ad_sale['it618_state']==5)$it618_state='<font color=#ccc>'.$it618_ad_lang['s366'].'</font>';
		
		if($it618_ad_sale['it618_btime']==0)$it618_btime=$it618_ad_lang['s189'];else $it618_btime=date('Y-m-d H:i:s', $it618_ad_sale['it618_btime']);
		if($it618_ad_sale['it618_etime']==0)$it618_etime=$it618_ad_lang['s189'];else $it618_etime=date('Y-m-d H:i:s', $it618_ad_sale['it618_etime']);
		if($it618_ad_sale['it618_btime']==0)$timecount=$it618_ad_lang['s189'];
		if($it618_ad_sale['it618_state']==3)$it618_etime='<font color=green>'.$it618_etime.'</font>';
		if($it618_ad_sale['it618_state']>=4)$it618_etime='<font color=#ccc>'.$it618_etime.'</font>';
		if($it618_ad_sale['it618_state']==3){
			if($it618_ad_sale['it618_pricetype']==1){
				$timecount='<font color=green>'.sprintf("%.2f", ($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600).'</font>'.' '.$it618_pricetype;
			}else{
				$timecount='<font color=green>'.sprintf("%.2f", ($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600/24).'</font>'.' '.$it618_pricetype;
			}
		}
		if($it618_ad_sale['it618_state']>=4)$timecount='<font color=#ccc>0 '.$it618_pricetype.'</font>';
		
		$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_ad_xf')." WHERE it618_saleid=".$it618_ad_sale['id']);
		if($count>0){
			$xfstr='<span style="float:right;color:#999"><a href="javascript:" id="showxf'.$it618_ad_sale[id].'">'.it618_ad_getlang('s256').' <font color=red>'.$count.'</font> '.it618_ad_getlang('s257').'</a></span>';
			$sum=DB::result_first("SELECT sum(it618_price*it618_count) FROM ".DB::table('it618_ad_xf')." WHERE it618_saleid=".$it618_ad_sale['id']);
			$allcount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_ad_xf')." WHERE it618_saleid=".$it618_ad_sale['id']);
		}else{
			$xfstr='';
			$sum=0;
		}
		
		$editbtn='';
		if($it618_ad_sale['it618_state']<4&&$it618_ad_sale['it618_state']!=0){
			$editbtn=' <a href="plugin.php?id=it618_ad:ads&saleid='.$it618_ad_sale['id'].'" target="_blank">'.$it618_ad_lang['s363'].'</a>';
		}
		
		$it618_blockname=str_replace("it618ad_","",$it618_ad_sale['it618_blockname']);
		
		$it618_score='';
		if($it618_ad_sale['it618_score']>0){
			$it618_score='<br><font color=blue>-'.$it618_ad_sale['it618_score'].'</font> '.$creditname;
		}
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" name="delete[]" id="saleid'.$it618_ad_sale[id].'" value="'.$it618_ad_sale[id].'" '.$disabled.'><label for="saleid'.$it618_ad_sale[id].'">'.$it618_ad_sale[id].'</label><input type="hidden" name="id['.$it618_ad_sale[id].']" value="'.$it618_ad_sale[id].'">',
			'<span title="'.$it618_ad_lang['t46'].':'.$aidstr.' '.$it618_ad_lang['s116'].$it618_blockname.' '.$it618_ad_lang['s119'].$it618_ad_ad['it618_title'].'">'.$it618_adtype.'<br><font color=#999>'.$it618_ad_ad['it618_width'].'*'.$it618_ad_ad['it618_height'].'</font></span>',
			'<font color=#999>'.it618_ad_getlang('s258').'</font><font color=red>'.$it618_ad_sale['it618_price'].'</font> '.$creditname.'/'.$it618_pricetype.' <font color=#999>'.it618_ad_getlang('s259').'</font><font color=red>'.$it618_ad_sale['it618_count'].'</font> '.$it618_pricetype.'<br><font color=#999>'.it618_ad_getlang('s260').'</font><font color=#ccc>'.date('Y-m-d H:i:s', $it618_ad_sale['it618_buytime']).'</font>'.$xfstr,
			'<font color=red>'.($it618_ad_sale['it618_count']+$allcount).'</font> '.$it618_pricetype,
			'<font color=red>'.intval($it618_ad_sale['it618_price']*$it618_ad_sale['it618_count']+$sum).'</font> '.$creditname.$it618_score,
			'<div style="width:80px">'.$it618_btime.'</div>',
			'<div style="width:80px">'.$it618_etime.'</div>',
			$timecount,
			$strtmp.$editbtn,
			'<font color=red>'.$it618_state.'</font>',
			'<a href="home.php?mod=space&uid='.$it618_ad_sale['it618_uid'].'" target="_blank">'.$username.'</a><br>'.$it618_ad_sale['it618_tel']
		));
		
		if($it618_ad_ad['it618_adtype']==1||$it618_ad_ad['it618_adtype']==4){
			$tmpstr=$it618_ad_lang['s193'].'<input type="text" class="txt" value="'.$it618_ad_sale['it618_imgurl'].'"/><br>';
		}elseif($it618_ad_ad['it618_adtype']==2){
			$tmpstr=$it618_ad_lang['s194'].'<input type="text" class="txt" value="'.$it618_ad_sale['it618_title'].'"/><br>';
		}else{
			$tmpstr=$it618_ad_lang['s222'].'<input type="text" class="txt" value="'.$it618_ad_sale['it618_imgurl'].'"/><br>';
		}
		
		if($it618_ad_ad['it618_adtype']!=3){
			$tmpstr1=$it618_ad_lang['s195'].'<input type="text" class="txt" value="'.$it618_ad_sale['it618_url'].'"/><br>'.$it618_ad_lang['s196'].'<input type="text" class="txt" value="'.$it618_ad_sale['it618_tip'].'"/>';
		}else{
			$tmpstr1='';
		}
		
		$ad_align=$it618_ad['ad_align'];
		if($ad_align==1)$ad_align="left";
		if($ad_align==2)$ad_align="right";
		if($ad_align==3)$ad_align="center";
		
		$strcontent='<style>.txt{padding:3px;outline:none;font-size:12px;line-height:14px;color:#333;border:1px solid #ddd;border-radius:3px;height:14px; width:758px;margin-bottom:5px}div.it618_ad_wrap {display:table;_position:relative;overflow:hidden;border:#CCC 2px solid;}div.it618_ad_subwrap {vertical-align:middle;display:table-cell;_position:absolute;_top:50%;}div.it618_ad_content { _position:relative;_top:-50%;}</style>'.$tmpstr.$tmpstr1.'<br>'.$it618_ad_lang['s197'].'<br><div class="it618_ad_wrap" style="width:'.$it618_ad_ad['it618_width'].'px;height:'.$it618_ad_ad['it618_height'].'px;text-align:'.$ad_align.'"><div class="it618_ad_subwrap"><div class="it618_ad_content" id="testad" style="width:'.$it618_ad_ad['it618_width'].'px;height:'.$it618_ad_ad['it618_height'].'px">';
		
		if($it618_ad_ad['it618_adtype']==1||$it618_ad_ad['it618_adtype']==4){
			$strcontent.='<a href="'.$it618_ad_sale['it618_url'].'" target="_blank" title="'.$it618_ad_sale['it618_tip'].'"><img width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" src="'.$it618_ad_sale['it618_imgurl'].'"/></a></div></div></div>'.$it618_ad_lang['s198'].$it618_ad_ad['it618_width'].'*'.$it618_ad_ad['it618_height'];
		}elseif($it618_ad_ad['it618_adtype']==2){
			if($it618_ad_sale['it618_isfontbold']==1)$it618_title='<b>'.$it618_ad_sale['it618_title'].'</b>';else $it618_title=$it618_ad_sale['it618_title'];
			$strcontent.='<a href="'.$it618_ad_sale['it618_url'].'" target="_blank" title="'.$it618_ad_sale['it618_tip'].'"><font color="'.$it618_ad_sale['it618_fontcolor'].'">'.$it618_title.'</font></a></div></div></div>'.$it618_ad_lang['s199'].$it618_ad_ad['it618_width'].'*'.$it618_ad_ad['it618_height'];
		}else{
			$strcontent.='<embed src="'.$it618_ad_sale['it618_imgurl'].'" allowFullScreen="true" quality="high" width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed></div></div></div>'.$it618_ad_lang['s199'].$it618_ad_ad['it618_width'].'*'.$it618_ad_ad['it618_height'];
		}
		
		$tmpjs.='KindEditor.ready(function(K) {K(\'#adcontent'.$it618_ad_sale[id].'\').click(function() {
			var dialog = K.dialog({
				width : 1000,
				height: 470,
				title : \''.$it618_ad_lang['s200'].'\',
				body : \'<div style="margin:10px;">'.$strcontent.'</div>\',
				closeBtn : {
					name : \''.$it618_ad_lang['s201'].'\',
					click : function(e) {
						dialog.remove();
					}
				},
				noBtn : {
					name : \''.$it618_ad_lang['s201'].'\',
					click : function(e) {
						dialog.remove();
					}
				}
			});
		});});';
		
		if($xfstr!=''){
			$tmpjs.='KindEditor.ready(function(K) {K(\'#showxf'.$it618_ad_sale[id].'\').click(function() {
						IT618_AD.get("'.$_G['siteurl'].'plugin.php?id=it618_ad:showxf&saleid='.$it618_ad_sale[id].'&admin", {ac:"it618"},function (data, textStatus){
						dialog_showxf = K.dialog({
							width : 500,
							title : \''.$it618_ad_lang['t113'].'\',
							body : \'<div style="padding:5px">\'+data+\'</div>\',
							closeBtn : {
								name : \''.$it618_ad_lang['s201'].'\',
								click : function(e) {
									dialog_showxf.remove();
								}
							},
							noBtn : {
								name : \''.$it618_ad_lang['s201'].'\',
								click : function(e) {
									dialog_showxf.remove();
								}
							}
						});
						}, "html");	
					});});';	
		}
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_ad_lang['s202'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del1" value="'.$it618_ad_lang['s367'].'" onclick="return confirm(\''.$it618_ad_lang['s368'].'\')" /> <input type="submit" class="btn" name="it618submit_del2" value="'.$it618_ad_lang['s203'].'" onclick="return confirm(\''.$it618_ad_lang['s204'].'\')" /> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_ad_lang['s205'].'" onclick="return confirm(\''.$it618_ad_lang['s206'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_ad_lang['s207'].'" onclick="return confirm(\''.$it618_ad_lang['s208'].'\')"/> <input type="submit" class="btn" name="it618submit_del3" value="'.$it618_ad_lang['s369'].'" style="color:red" onclick="return confirm(\''.$it618_ad_lang['s370'].'\')" /> <input type="submit" class="btn" name="it618submit_del4" value="'.$it618_ad_lang['s373'].'" style="color:red" onclick="return confirm(\''.$it618_ad_lang['s374'].'\')" /> '.$it618_ad_lang['s209'].'<input type=hidden value='.$page.' name=page /></div></td></tr>';
	
	if(count($reabc)!=8)return; /*dism_ taobao_ com*/
showtablefooter(); /*dism��taobao��com*/
echo '<script>var dialog_showxf;'.$tmpjs.'</script>';
?>