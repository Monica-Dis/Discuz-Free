<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_ad_adblock`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad_adblock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_width` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_height` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_margin_top` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_margin_bottom` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_margin_left` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_margin_right` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bordertype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_bordercolor` varchar(10) NOT NULL,
  `it618_bgcolor` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_ad_ad`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_blockname` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_price` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '30',
  `it618_count1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pricetype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_fontalign` int(10) unsigned NOT NULL DEFAULT '2',
  `it618_fontsize` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_fontcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_row` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_col` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_width` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_height` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_padding_top` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_padding_bottom` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_padding_left` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_padding_right` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isrand` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_speed` int(10) unsigned NOT NULL DEFAULT '5000',
  `it618_isnofollow` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isnoprice` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_adtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_about` varchar(8000) NOT NULL,
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_ad_ad_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad_ad_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_price` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_ad_wap_ad`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad_wap_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_blockname` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_tids` varchar(255) NOT NULL,
  `it618_typids` varchar(255) NOT NULL,
  `it618_fids` varchar(255) NOT NULL,
  `it618_lou` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_row` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_padding_top` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_padding_bottom` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isrand` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_speed` int(10) unsigned NOT NULL DEFAULT '5000',
  `it618_isnofollow` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_adtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_ad_wap_ad_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad_wap_ad_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_ad_wap_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad_wap_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_etime` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_ad_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_title` varchar(1000) NOT NULL,
  `it618_fontcolor` varchar(50) NOT NULL,
  `it618_imgurl` varchar(1000) NOT NULL,
  `it618_uploadimg` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_tip` varchar(1000) NOT NULL,
  `it618_isfontbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pricetype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(50) NOT NULL,
  `it618_buytime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_adtime1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_adtime2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_adtime3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_ad_xf`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad_xf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_price` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_buytime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_ad`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_ad` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_ad_onepage`;
CREATE TABLE IF NOT EXISTS `pre_it618_ad_onepage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

if(isset($_GET['pluginid'])&&$_GET['pluginid']!=''){
	DB::query("insert into ".DB::table('it618_ad')."(it618_ad) values ('".addslashes($_GET['dir'])."')");
}else{
	DB::query("insert into ".DB::table('it618_ad')."(it618_ad) values ('it618_ad')");
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>