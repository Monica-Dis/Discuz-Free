<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: uninstall.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

DB::query("DROP TABLE IF EXISTS ".DB::table('it618_ad_ad')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_ad_wap_ad')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_ad_sale')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_ad')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_ad_adblock')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_ad_wap_ad_focus')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_ad_xf')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_ad_onepage')."");

//DEFAULT CHARSET=gbk;
$finish = TRUE;

?>