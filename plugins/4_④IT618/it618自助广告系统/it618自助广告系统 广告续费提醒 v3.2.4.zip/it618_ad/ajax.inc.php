<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_ad;

$it618_ad = $_G['cache']['plugin']['it618_ad'];
$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_ad/lang.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';

$uid = $_G['uid'];


if($_GET['ac']=="sale_add"){
	if($uid<=0){
		echo it618_ad_getlang('s49');
	}else{
		$it618_count=intval($_GET['it618_count']);
		$it618_ad_ad=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".intval($_GET['aid']));
		if($it618_ad_ad['it618_pricetype']==1)$it618_pricetype=it618_ad_getlang('s33');
		if($it618_ad_ad['it618_pricetype']==2)$it618_pricetype=it618_ad_getlang('s223');
		if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
		if($it618_count<=0){
			echo it618_ad_getlang('s265');exit;
		}
		if($it618_ad_ad['it618_saletype']==2){
			
			echo it618_ad_getlang('s50');
			
		}else{
			$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_ad_sale')." where it618_state<4 and it618_aid=".$it618_ad_ad['id'].' and it618_pid='.intval($_GET['pid']));
			if($count>0){
				echo it618_ad_getlang('s268');exit;
			}
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
			if($it618_ad_ad['it618_count1']>0&&$it618_count<$it618_ad_ad['it618_count1']){
				echo it618_ad_getlang('s237').$it618_ad_ad['it618_count1'].$it618_pricetype;exit;
			}
			
			if($it618_ad_ad['it618_count2']>0&&$it618_count>$it618_ad_ad['it618_count2']){
				echo it618_ad_getlang('s238').$it618_ad_ad['it618_count2'].$it618_pricetype;exit;
			}

			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			$creditnum=DB::result_first("select extcredits".$it618_ad['ad_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
			if($creditnum=="")$creditnum=0;
			$price=$it618_ad_ad['it618_price'];
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
			if($creditnum>=$it618_count*$price){
				if($ii1i11i[5]!='_')exit;
				$id = C::t('#it618_ad#it618_ad_sale')->insert(array(
					'it618_uid' => $uid,
					'it618_aid' => intval($_GET['aid']),
					'it618_pid' => intval($_GET['pid']),
					'it618_price' => $price,
					'it618_pricetype' => $it618_ad_ad['it618_pricetype'],
					'it618_count' => $it618_count,
					'it618_state' => 0,
					'it618_buytime' => $_G['timestamp']
				), true);
				if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
				if($id>0){
					C::t('common_member_count')->increase($_G['uid'], array(
						'extcredits'.$it618_ad['ad_credit'] => (0-intval($it618_count*$price)))
					);

					$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
					if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
					DB::query("update ".DB::table('it618_ad_ad')." set it618_salecount=it618_salecount+1,it618_state=1 where id=".intval($_GET['aid']));
					if($ii1i11i[3]!='1')exit;
					
					it618_ad_sendmessage("sale_admin",$id);
					echo "ok";
				}
			}else{
				echo "<font color=#000>".it618_ad_getlang('s52')." <font color=green>".$creditname."</font> ".it618_ad_getlang('s53')." <font color=red>".$creditnum."</font> ".it618_ad_getlang('s54')." <font color=red>".($it618_count*$price)."</font> ".it618_ad_getlang('s55')." <font color=green>".$creditname."</font>".it618_ad_getlang('s56')."</font>";
			}
		}
	}
	exit;
}


if($_GET['ac']=="xf_add"){
	if($uid<=0){
		echo it618_ad_getlang('s49');
	}else{
		$it618_count=intval($_GET['it618_count']);
		if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
		$saleid=intval($_GET['saleid']);
		$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$saleid);
		$it618_ad_ad = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$it618_ad_sale['it618_aid']);
		if($it618_count<=0){
			echo it618_ad_getlang('s265');exit;
		}
		if($it618_ad_ad['it618_saletype']==2){
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
			echo it618_ad_getlang('s50');
			
		}else{
			if($it618_ad_sale['it618_state']==4){
				echo it618_ad_getlang('s269');exit;
			}
			
			if($it618_ad_ad['it618_pricetype']==1){
				$it618_pricetype=it618_ad_getlang('s33');
				$timetmp=($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600;
			}
			if($it618_ad_ad['it618_pricetype']==2){
				$it618_pricetype=it618_ad_getlang('s223');
				$timetmp=($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600/24;
			}

			if($it618_ad_ad['it618_count1']>0&&($it618_count+$timetmp)<$it618_ad_ad['it618_count1']){
				echo it618_ad_getlang('s237').'('.it618_ad_getlang('s270').sprintf("%.2f",$timetmp).$it618_pricetype.')'.$it618_ad_ad['it618_count1'].$it618_pricetype;exit;
			}
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
			if($it618_ad_ad['it618_count2']>0&&($it618_count+$timetmp)>$it618_ad_ad['it618_count2']){
				echo it618_ad_getlang('s238').'('.it618_ad_getlang('s270').sprintf("%.2f",$timetmp).$it618_pricetype.')'.$it618_ad_ad['it618_count2'].$it618_pricetype;exit;
			}
			
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			$creditnum=DB::result_first("select extcredits".$it618_ad['ad_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
			if($creditnum=="")$creditnum=0;
			$price=$it618_ad_ad['it618_price'];
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
			if($creditnum>$it618_count*$price){
				if($ii1i11i[5]!='_')exit;
				$id = C::t('#it618_ad#it618_ad_xf')->insert(array(
					'it618_uid' => $uid,
					'it618_saleid' => $it618_ad_sale['id'],
					'it618_price' => $price,
					'it618_count' => $it618_count,
					'it618_buytime' => $_G['timestamp']
				), true);
				
				
				if($id>0){
					C::t('common_member_count')->increase($_G['uid'], array(
						'extcredits'.$it618_ad['ad_credit'] => (0-intval($it618_count*$price)))
					);

					$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}

					if($it618_ad_sale['it618_pricetype']==1){
						$it618_etime=$it618_ad_sale['it618_etime'] + 3600*$it618_count;
					}else{
						$it618_etime=$it618_ad_sale['it618_etime'] + 3600*24*$it618_count;
					}
					if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
					DB::query("update ".DB::table('it618_ad_sale')." set it618_etime=".$it618_etime.",it618_adtime1=0,it618_adtime2=0,it618_adtime3=0 WHERE id=".$it618_ad_sale['id']);
					
					if($ii1i11i[3]!='1')exit;
					it618_ad_sendmessage("sale1_admin",$id);
					echo "ok";
				}
			}else{
				echo "<font color=#000>".it618_ad_getlang('s52')." <font color=green>".$creditname."</font> ".it618_ad_getlang('s53')." <font color=red>".$creditnum."</font> ".it618_ad_getlang('s54')." <font color=red>".($it618_count*$price)."</font> ".it618_ad_getlang('s55')." <font color=green>".$creditname."</font>".it618_ad_getlang('s56')."</font>";
			}
		}
	}
	exit;
}


if($_GET['ac']=="postad"){
	if($uid<=0){
		echo it618_ad_getlang('s57');
	}else{
		if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
		
		$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".intval($_GET['saleid']));
		$it618_ad_ad=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$it618_ad_sale['it618_aid']);
		
		if($it618_ad_sale['it618_uid']!=$uid){
			
			echo it618_ad_getlang('s58').$it618_ad_sale['it618_uid'];
			
		}elseif($it618_ad_ad['it618_saletype']==2){
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
			echo it618_ad_getlang('s59');
			
		}elseif($it618_ad_sale['it618_state']==1||$it618_ad_sale['it618_state']==3||$it618_ad_sale['it618_state']==4){
			
			echo it618_ad_getlang('s60');
			
		}else{
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[5]!='_')exit;
			if($ii1i11i[7]!='d')exit;
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
			C::t('#it618_ad#it618_ad_sale')->update($_GET['saleid'],array(
				'it618_title' => it618_ad_utftogbk($_GET['it618_title']),
				'it618_fontcolor' => $_GET['it618_fontcolor'],
				'it618_imgurl' => it618_ad_utftogbk($_GET['it618_imgurl']),
				'it618_url' => it618_ad_utftogbk($_GET['it618_url']),
				'it618_tip' => it618_ad_utftogbk($_GET['it618_tip']),
				'it618_tel' => it618_ad_utftogbk($_GET['it618_tel']),
				'it618_isfontbold' => $_GET['it618_isfontbold'],
				'it618_state' => 1
			));
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;

			if($it618_ad['ad_autopass']==1){
				$ad_autopassuid=explode(",",$it618_ad['ad_autopassuid']);
				if($it618_ad['ad_autopassuid']=='0'||in_array($_G['uid'], $ad_autopassuid)){
					$it618_btime=$_G['timestamp'];
					if($it618_ad_sale['it618_pricetype']==1){
						$it618_etime=$it618_btime + 3600*$it618_ad_sale['it618_count'];
					}else{
						$it618_etime=$it618_btime + 3600*24*$it618_ad_sale['it618_count'];
					}
					
					it618_ad_sendmessage("ad_admin",$it618_ad_sale['id']);
					DB::query("update ".DB::table('it618_ad_sale')." set it618_state=3,it618_btime=".$it618_btime.",it618_etime=".$it618_etime." WHERE id=".$it618_ad_sale['id']);
				}else{
					it618_ad_sendmessage("ad1_admin",$it618_ad_sale['id']);	
				}
			}else{
				it618_ad_sendmessage("ad1_admin",$it618_ad_sale['id']);	
			}

			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}

			if($ii1i11i[3]!='1')exit;
			echo "ok";
		}
	}
	exit;
}


if($_GET['ac']=="editad"){
	if($uid<=0){
		echo it618_ad_getlang('s57');
	}else{
		if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
		
		if($it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".intval($_GET['saleid']))){
			if(isset($_GET['admin'])){
				$ad_adminuid=explode(",",$it618_ad['ad_adminuid']);
				if(!in_array($_G['uid'],$ad_adminuid)){
					echo it618_ad_getlang('s364');exit;
				}
			}else{
				if($it618_ad_sale['it618_uid']!=$uid){
					echo it618_ad_getlang('s251');exit;
				}
				if($it618_ad_sale['it618_state']!=3){
					echo it618_ad_getlang('s240');exit;
				}
			}
		}else{
			echo it618_ad_getlang('s60');exit;
		}
		
		$it618_ad_ad=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$it618_ad_sale['it618_aid']);
		
		if($it618_ad_ad['it618_saletype']==2){
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
			echo it618_ad_getlang('s59');
			
		}else{
			
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[5]!='_')exit;
			if($ii1i11i[7]!='d')exit;
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])exit;
			C::t('#it618_ad#it618_ad_sale')->update($_GET['saleid'],array(
				'it618_title' => it618_ad_utftogbk($_GET['it618_title']),
				'it618_fontcolor' => $_GET['it618_fontcolor'],
				'it618_imgurl' => it618_ad_utftogbk($_GET['it618_imgurl']),
				'it618_url' => it618_ad_utftogbk($_GET['it618_url']),
				'it618_tip' => it618_ad_utftogbk($_GET['it618_tip']),
				'it618_isfontbold' => $_GET['it618_isfontbold']
			));
			

			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}

			if($ii1i11i[3]!='1')exit;
			echo "ok";
		}
	}
	exit;
}
//From: dis'.'m.tao'.'bao.com
?>