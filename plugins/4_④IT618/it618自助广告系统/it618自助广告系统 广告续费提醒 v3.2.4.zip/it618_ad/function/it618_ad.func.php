<?php

/*
	[Discuz!] (C)2001-2009 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: tools.func.php 109 2012-06-14 04:45:47Z fuqingrong $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('plugin');
$it618_ad = $_G['cache']['plugin']['it618_ad'];
$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_ad/lang.func.php';

if($it618_ad['pagecount']==''){
	cpmsg($it618_ad_lang['s552'], "", 'error');
}

$adblock_arr[0]="global_header_mobile";$adblocktitle_arr[0]=$it618_ad_lang['s314'];
$adblock_arr[1]="global_footer_mobile";$adblocktitle_arr[1]=$it618_ad_lang['s315'];
$adblock_arr[2]="index_top_mobile";$adblocktitle_arr[2]=$it618_ad_lang['s316'];
$adblock_arr[3]="index_middle_mobile";$adblocktitle_arr[3]=$it618_ad_lang['s317'];
$adblock_arr[4]="forumdisplay_top_mobile";$adblocktitle_arr[4]=$it618_ad_lang['s318'];
$adblock_arr[5]="forumdisplay_bottom_mobile";$adblocktitle_arr[5]=$it618_ad_lang['s319'];
$adblock_arr[6]="viewthread_top_mobile";$adblocktitle_arr[6]=$it618_ad_lang['s320'];
$adblock_arr[7]="tiecontent_top";$adblocktitle_arr[7]=$it618_ad_lang['s321'];
$adblock_arr[8]="tiecontent_bottom";$adblocktitle_arr[8]=$it618_ad_lang['s322'];
$adblock_arr[9]="viewthread_bottom_mobile";$adblocktitle_arr[9]=$it618_ad_lang['s323'];
$adblock_arr[10]="post_bottom_mobile";$adblocktitle_arr[10]=$it618_ad_lang['s324'];
$adblock_arr[11]="logging_bottom_mobile";$adblocktitle_arr[11]=$it618_ad_lang['s325'];

function showsubmenus($title, $menus = array(), $right = '', $replace = array()) {
	if(empty($menus)) {
		$s = '<div class="itemtitle">'.$right.'<h3>'.cplang($title, $replace).'</h3></div>';
	} elseif(is_array($menus)) {
		$s = '<div class="itemtitle">'.$right.'<h3>'.cplang($title, $replace).'</h3><ul class="tab1">';
		foreach($menus as $k => $menu) {
			if(is_array($menu[0])) {
				$s .= '<li id="addjs'.$k.'" class="'.($menu[1] ? 'current' : 'hasdropmenu').'" onmouseover="dropmenu(this);"><a href="#"><span>'.cplang($menu[0]['menu']).'<em>&nbsp;&nbsp;</em></span></a><div id="addjs'.$k.'child" class="dropmenu" style="display:none;" style="margin-top:-20px">';
				if(is_array($menu[0]['submenu'])) {
					foreach($menu[0]['submenu'] as $submenu) {
						$s .= $submenu[1] ? '<a href="'.ADMINSCRIPT.'?action='.$submenu[1].'" class="'.($submenu[2] ? 'current' : '').'" onclick="'.$submenu[3].'">'.cplang($submenu[0]).'</a>' : '<a><b>'.cplang($submenu[0]).'</b></a>';
					}
				}
				$s .= '</div></li>';
			} else {
				$s .= '<li'.($menu[2] ? ' class="current"' : '').'><a href="'.(!$menu[4] ? ADMINSCRIPT.'?action='.$menu[1] : $menu[1]).'"'.(!empty($menu[3]) ? ' target="_blank"' : '').'><span>'.cplang($menu[0]).'</span></a></li>';
			}
		}
		$s .= '</ul></div>';
	}
	echo !empty($menus) ? '<div class="floattop" style="top:27px;height:10px;padding:0px;_top:5px">'.$s.'</div>' : $s;
}

function showtipss($tips, $id = 'tips', $display = TRUE, $title = '') {
	$tips = cplang($tips);
	$tips = preg_replace('#</li>\s*<li>#i', '</li><li>', $tips);
	$tmp = explode('</li><li>', substr($tips, 4, -5));
	if(!count($tmp) > 4) {
		$tips = '<li>'.$tmp[0].'</li><li>'.$tmp[1].'</li><li id="'.$id.'_more" style="border: none; background: none; margin-bottom: 6px;"><a href="###" onclick="var tiplis = $(\''.$id.'lis\').getElementsByTagName(\'li\');for(var i = 0; i < tiplis.length; i++){tiplis[i].style.display=\'\'}$(\''.$id.'_more\').style.display=\'none\';">'.cplang('tips_all').'...</a></li>';
		foreach($tmp AS $k => $v) {
			if($k > 1) {
				$tips .= '<li style="display: none">'.$v.'</li>';
			}
		}
	}
	unset($tmp);
	$title = $title ? $title : 'tips';
	showtableheaders($title, '', 'id="'.$id.'"'.(!$display ? ' style="display: none;"' : ''), 0);
	showtablerow('', 'class="tipsblock" s="1"', '<ul id="'.$id.'lis">'.$tips.'</ul>');
	showtablefooter(); /*dism��taobao��com*/
}
function showtableheaders($title = '', $classname = '', $extra = '', $titlespan = 15) {
	global $_G;
	$classname = str_replace(array('nobottom', 'notop'), array('nobdb', 'nobdt'), $classname);
	if(isset($_G['showsetting_multi'])) {
		if($_G['showsetting_multi'] == 0) {
			$extra .= ' style="width:'.($_G['showsetting_multicount'] * 270 + 20).'px"';
		} else {
			return;
		}
	}
	echo "\n".'<table class="tb tb2 '.$classname.'"'.($extra ? " $extra" : '').' style="clear: both;margin-top: 5px;width: 100%">';
	if($title) {
		$span = $titlespan ? 'colspan="'.$titlespan.'"' : '';
		echo "\n".'<tr><th '.$span.' class="partition">'.cplang($title).'</th></tr>';
		showmultititle(1);
	}
}
//From: Dism��taobao��com
?>