<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_it618_ad{
	
	function global_header(){
		global $_G;
		$it618_ad = $_G['cache']['plugin']['it618_ad'];

		require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function.func.php';
		$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_it618_ad.php';
		
		$count=DB::result_first("select count(1) from ".DB::table('it618_ad_ad')." where it618_ison=1 and it618_blockname='global_header'");
		if($count>0){
			$global_header=it618_hook('global_header');
		}

		$count=DB::result_first("select count(1) from ".DB::table('it618_ad_ad')." where it618_ison=1");
		if($count>0){
			$returnstr = $global_header;
		}

		if(($_G['timestamp'] - @filemtime($cache_file)) > 8) {
			$query = DB::query("SELECT * FROM ".DB::table('it618_ad_sale')." WHERE it618_state=0 || it618_state=3");
			while($it618_ad_sale = DB::fetch($query)) {
				if($_G['timestamp']-$it618_ad_sale['it618_buytime']>=($it618_ad['ad_buytime']*60)&&$it618_ad_sale['it618_state']==0){
					if($it618_ad_sale['it618_uploadimg']!=''){
						$tmparr=explode("source",$it618_ad_sale['it618_uploadimg']);
						$it618_uploadimg=DISCUZ_ROOT.'./source'.$tmparr[1];
						
						if(file_exists($it618_uploadimg)){
							$result=unlink($it618_uploadimg);
						}
					}
					DB::query("delete from ".DB::table('it618_ad_sale')." where id=".$it618_ad_sale['id']);
	
					$it618_ad_ad = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$it618_ad_sale['it618_aid']);
				
					C::t('common_member_count')->increase($it618_ad_sale['it618_uid'], array(
						'extcredits'.$it618_ad['ad_credit'] => ($it618_ad_sale['it618_count']*$it618_ad_sale['it618_price']))
					);
					if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
					DB::query("update ".DB::table('it618_ad_ad')." set it618_salecount=it618_salecount-1,it618_state=0 where id=".$it618_ad_ad['id']);
				}
				
				if($it618_ad_sale['it618_state']==3){
					if($_G['timestamp']>=$it618_ad_sale['it618_etime']){
						DB::query("update ".DB::table('it618_ad_sale')." set it618_state=4 where id=".$it618_ad_sale['id']);
						DB::query("update ".DB::table('it618_ad_ad')." set it618_state=0 where id=".$it618_ad_sale['it618_aid']);
					}else{
						if($it618_ad_sale['it618_pricetype']==1){
							if($it618_ad_sale['it618_etime']-$_G['timestamp']<=3600&&$it618_ad_sale['it618_adtime1']==0){
								it618_ad_sendmessage("adtime_user",$it618_ad_sale['id']);
								DB::query("update ".DB::table('it618_ad_sale')." set it618_adtime1=1 where id=".$it618_ad_sale['id']);
							}
						}
						
						if($it618_ad_sale['it618_pricetype']==2){
							if($it618_ad_sale['it618_etime']-$_G['timestamp']<=3600*24*7&&$it618_ad_sale['it618_etime']-$_G['timestamp']>3600*24*3&&$it618_ad_sale['it618_adtime1']==0){
								it618_ad_sendmessage("adtime_user",$it618_ad_sale['id']);
								DB::query("update ".DB::table('it618_ad_sale')." set it618_adtime1=1 where id=".$it618_ad_sale['id']);
							}
							if($it618_ad_sale['it618_etime']-$_G['timestamp']<=3600*24*3&&$it618_ad_sale['it618_etime']-$_G['timestamp']>3600*24&&$it618_ad_sale['it618_adtime2']==0){
								it618_ad_sendmessage("adtime_user",$it618_ad_sale['id']);
								DB::query("update ".DB::table('it618_ad_sale')." set it618_adtime2=1 where id=".$it618_ad_sale['id']);
							}
							if($it618_ad_sale['it618_etime']-$_G['timestamp']<=3600*24&&$it618_ad_sale['it618_adtime3']==0){
								it618_ad_sendmessage("adtime_user",$it618_ad_sale['id']);
								DB::query("update ".DB::table('it618_ad_sale')." set it618_adtime3=1 where id=".$it618_ad_sale['id']);
							}
						}
					}
				}
			}
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
			$query = DB::query("SELECT * FROM ".DB::table('it618_ad_sale')." WHERE it618_state=3");
			while($it618_ad_sale = DB::fetch($query)) {
				if($_G['timestamp']>=$it618_ad_sale['it618_etime']){
					DB::query("update ".DB::table('it618_ad_sale')." set it618_state=4 where id=".$it618_ad_sale['id']);
					DB::query("update ".DB::table('it618_ad_ad')." set it618_state=0 where id=".$it618_ad_sale['it618_aid']);
				}
			}
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
			$query1 = DB::query("SELECT * FROM ".DB::table('common_advertisement')." where title LIKE 'it618ad_%' ORDER BY title");
			while($it618_tmp =	DB::fetch($query1)) {
				$count=DB::result_first("select count(1) from ".DB::table('it618_ad_ad')." where it618_ison=1 and it618_blockname='".$it618_tmp['title']."'");
				
				if($count==0){
					$setarr = array(
						'code' => ''
					);
					DB::update('common_advertisement', $setarr, "title='".$it618_tmp['title']."'");
				}
			}
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
			$query1 = DB::query("SELECT * FROM ".DB::table('common_block')." where name LIKE 'it618ad_%' ORDER BY name");
			while($it618_tmp =	DB::fetch($query1)) {
				$count=DB::result_first("select count(1) from ".DB::table('it618_ad_ad')." where it618_ison=1 and it618_blockname='".$it618_tmp['name']."'");
				
				if($count==0){
					$setarr = array(
						'summary' => '',
						'dateline' => $_G['timestamp']
					);
					DB::update('common_block', $setarr, "name='".$it618_tmp['name']."' and blockclass=0");
				}
			}
			
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
		
			$query = DB::query("SELECT it618_blockname FROM ".DB::table('it618_ad_ad')." WHERE it618_ison=1 group by it618_blockname");
			while($it618_ad_ad =DB::fetch($query)) {
				$blockname=$it618_ad_ad['it618_blockname'];
				$blockcount=DB::result_first("select count(1) from ".DB::table('common_block')." where name='".$blockname."' and blockclass=0");
				
				if($blockcount>0){
					$strContent=it618_hook($blockname);
					if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
					$setarr = array(
						'summary' => $strContent,
						'dateline' => $_G['timestamp']
					);
					DB::update('common_block', $setarr, "name='".$blockname."' and blockclass=0");
				}
			}
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
			$query = DB::query("SELECT it618_blockname FROM ".DB::table('it618_ad_ad')." WHERE it618_ison=1 group by it618_blockname");
			while($it618_ad_ad =DB::fetch($query)) {
				$blockname=$it618_ad_ad['it618_blockname'];
				$blockcount=DB::result_first("select count(1) from ".DB::table('common_advertisement')." where title='".$blockname."'");
	
				if($blockcount>0){
					$strContent=it618_hook($blockname);
					
					$setarr = array(
						'code' => $strContent
					);
					DB::update('common_advertisement', $setarr, "title='".$blockname."'");
				}
			}
			
			require_once libfile('function/cache');
			$contents[]='';
			$cacheArray .= "\$contents=".arrayeval($contents).";\n";
			writetocache('it618_ad', $cacheArray);	
			updatecache('advs');

		}
		
		return '<a style="display:none" class="it618_credits" id="it618ad_credits"></a>'.$returnstr;
	}

}
//From: dis'.'m.tao'.'bao.com
?>