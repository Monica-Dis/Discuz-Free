<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$it618_ad = $_G['cache']['plugin']['it618_ad'];
$navtitle = $it618_ad['seotitle'];
$metakeywords = $it618_ad['seokeywords'];
$metadescription = $it618_ad['seodescription'];
require_once DISCUZ_ROOT.'./source/plugin/it618_ad/lang.func.php';

$saleid=intval($_GET['saleid']);

if($it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$saleid)){
	if(isset($_GET['admin'])){
		$urladmin='&admin';
		$ad_adminuid=explode(",",$it618_ad['ad_adminuid']);
		if(!in_array($_G['uid'],$ad_adminuid)){
			showmessage(it618_ad_getlang('s364'), '', array(), array('alert' => 'info'));
		}
	}else{
		if($it618_ad_sale['it618_uid']!=$_G['uid']){
			showmessage(it618_ad_getlang('s251'), '', array(), array('alert' => 'info'));
		}
	}
}else{
	showmessage(it618_ad_getlang('s60'), '', array(), array('alert' => 'info'));
}

$it618_ad_ad = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_ad')." where id=".$it618_ad_sale['it618_aid']);
$it618_adtype=$it618_ad_ad['it618_adtype'];
$it618_width=$it618_ad_ad['it618_width'];
$it618_height=$it618_ad_ad['it618_height'];
if($it618_width>1000)$it618_width1=1200;else $it618_width1=1000;
$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$_G['uid']);

if($_GET['ac']!='post'){
	if($it618_adtype==1||$it618_adtype==4){
		$adread='<a href="'.$it618_ad_sale['it618_url'].'" target="_blank" title="'.$it618_ad_sale['it618_tip'].'"><img width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" src="'.$it618_ad_sale['it618_imgurl'].'"/></a>';
	}elseif($it618_adtype==2){
		
		if($it618_ad_sale['it618_isfontbold']==1)$it618_title='<b>'.$it618_ad_sale['it618_title'].'</b>';else $it618_title=$it618_ad_sale['it618_title'];
		$adread='<a href="'.$it618_ad_sale['it618_url'].'" target="_blank" title="'.$it618_ad_sale['it618_tip'].'"><font color="'.$it618_ad_sale['it618_fontcolor'].'">'.$it618_title.'</font></a>';
	}else{
		$adread='<embed src="'.$it618_ad_sale['it618_imgurl'].'" allowFullScreen="true" quality="high" width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>';
	}
	
	if($it618_ad_sale['it618_isfontbold']==1){
		$titlecss='color:'.$it618_ad_sale['it618_fontcolor'].';font-weight:bold;';
	}else{
		$titlecss='color:'.$it618_ad_sale['it618_fontcolor'].';';
	}
}

$lineheight=14;
if($it618_ad_ad['it618_fontsize']!=0){
	$fontsizecss='font-size:'.$it618_ad_ad['it618_fontsize'].'px;';
	$lineheight=$it618_ad_ad['it618_fontsize']+2;
}

if($it618_ad_ad['it618_fontcount']!=0){
	$maxlength='maxlength='.$it618_ad_ad['it618_fontcount'];
}else{
	$maxlength='maxlength=100';
}

if($_GET['ac']=='post'){$adtitle=it618_ad_getlang('s241');$acstr='var ac="postad";';}
if($_GET['ac']=='edit'){$adtitle=it618_ad_getlang('s242');$acstr='var ac="editad";';}
if($_GET['ac']=='read')$adtitle=it618_ad_getlang('s243');

$it618_ad_lang['t68']=str_replace(it618_ad_getlang('s241'),$adtitle,$it618_ad_lang['t68']);
$it618_ad_lang['t73']=str_replace(it618_ad_getlang('s241'),$adtitle,$it618_ad_lang['t73']);
$it618_ad_lang['t102']=str_replace(it618_ad_getlang('s241'),$adtitle,$it618_ad_lang['t102']);

if($it618_ad_sale['it618_fontcolor']=='')$it618_fontcolor='#000000';else $it618_fontcolor=$it618_ad_sale['it618_fontcolor'];

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php';
}

if($it618_ad['ad_autopass']==1){
	$ad_autopassuid=explode(",",$it618_ad['ad_autopassuid']);
	if($it618_ad['ad_autopassuid']=='0'||in_array($_G['uid'], $ad_autopassuid)){
		$ad_autopass=1;
	}
}

$it618_usertel = DB::result_first("SELECT it618_tel FROM ".DB::table('it618_ad_sale')." WHERE it618_tel<>'' AND it618_uid=".$_G['uid']." AND id<>$saleid ORDER BY id desc");

if($it618_usertel==''){
	if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_members'")>0){
		$it618_usertel = DB::result_first("SELECT it618_tel FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid']);
	}
}

if($it618_ad_sale['it618_isfontbold']==1)$it618_isfontbold_checked='checked="checked"';else $it618_isfontbold_checked="";
if($it618_ad_sale['it618_isfontbold']==1)$it618_isfontbold_checked='checked="checked"';else $it618_isfontbold_checked="";

if(isset($_GET['admin'])){
	$tmpjs1='window.close();';
	$tmpjs='window.close();';
}else{
	$tmpjs1='hideWindow(\'it618_showad\');if(iscolor==1)document.body.removeChild(document.getElementById(\'colorBoard\'));';
	$tmpjs='location.reload();';
}

include template('it618_ad:showad');
?>