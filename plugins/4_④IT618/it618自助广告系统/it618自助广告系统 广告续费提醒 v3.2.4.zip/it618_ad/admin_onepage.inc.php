<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if(count($reabc)!=8)return; /*dism_ taobao_ com*/

loadcache('plugin');
$it618_ad = $_G['cache']['plugin']['it618_ad'];

require_once DISCUZ_ROOT.'./source/plugin/it618_ad/function/it618_ad.func.php';

if($reabc[6]!='a')return;
$ppp = $it618_ad['pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_onepage&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_onepage_add', 'admin_onepage', 'admin_onepage_edit');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_onepage' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}
if($cp=='admin_onepage_edit')$strtmp[1]='class="current"';

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_onepage_add'.$urls.'"><span>'.$it618_ad_lang['s271'].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_onepage'.$urls.'"><span>'.$it618_ad_lang['s272'].'</span></a></li>
</ul></div>';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism _ taobao _ com*/
?>