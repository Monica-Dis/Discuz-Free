<?php 
$it618='http://www.cnit618.com';
?>