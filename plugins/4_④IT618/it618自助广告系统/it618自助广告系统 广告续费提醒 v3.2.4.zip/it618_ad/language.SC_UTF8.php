<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_ad_lang;

function it618_ad_getlang($langid){
	global $it618_ad_lang;
	return $it618_ad_lang[$langid];
}

$it618_ad_lang['version']='v3.2.4';
$it618_ad_lang['s1'] = '调用位置设置';
$it618_ad_lang['s2'] = '宽度高度/上下左右外边距：';
$it618_ad_lang['s3'] = '提示：<font color=red>如果调用位置宽高都为0时，表示自适应宽高</font>，如果想固定宽高，必须宽高都要大于0，并且宽高都大于0时，外边距设置才有效';
$it618_ad_lang['s4'] = '管理轮播图片';
$it618_ad_lang['s5'] = '边框类型：';
$it618_ad_lang['s6'] = '无';
$it618_ad_lang['s7'] = '实线';
$it618_ad_lang['s8'] = '虚线';
$it618_ad_lang['s9'] = '边框颜色：';
$it618_ad_lang['s10'] = '背景颜色：';
$it618_ad_lang['s11'] = '随机显示';
$it618_ad_lang['s12'] = '删?';
$it618_ad_lang['s13'] = '提交';
$it618_ad_lang['s14'] = '抱歉，编号为';
$it618_ad_lang['s15'] = '的广告位宽度要大于0！';
$it618_ad_lang['s16'] = '的广告位高度要大于0！';
$it618_ad_lang['s17'] = '无对应调用位置请设置';
$it618_ad_lang['s18'] = '的广告位调用位置还没有选择！';
$it618_ad_lang['s19'] = '抱歉，请先添加广告调用位置！';
$it618_ad_lang['s20'] = '注意：广告类型如果是轮播广告，那么广告类型以后就固定为轮播广告不可修改';
$it618_ad_lang['s21'] = '无';
$it618_ad_lang['s22'] = '图片/链接';
$it618_ad_lang['s23'] = '排序';
$it618_ad_lang['s24'] = '价格';
$it618_ad_lang['s25'] = '最小购买数';
$it618_ad_lang['s26'] = '最多购买数';
$it618_ad_lang['s27'] = '提交后再上传图片设置链接';
$it618_ad_lang['s28'] = '图片数：';
$it618_ad_lang['s29'] = '提示：排序值为0时表示不显示，如果轮播广告没有图片或没有可以显示的图片，那么轮播广告不显示';
$it618_ad_lang['s30'] = '返回广告位管理';
$it618_ad_lang['s31'] = '广告位编号：';
$it618_ad_lang['s32'] = '上传图片';
$it618_ad_lang['s33'] = '小时';
$it618_ad_lang['s34'] = '点击购买,会弹出广告位购买窗口)';
$it618_ad_lang['s35'] = '购买';
$it618_ad_lang['s36'] = '已被';
$it618_ad_lang['s37'] = '抱歉，只有会员才可以进入我的广告，请先登录！';
$it618_ad_lang['s38'] = '图片广告';
$it618_ad_lang['s39'] = '文字广告';
$it618_ad_lang['s40'] = '未提交';
$it618_ad_lang['s41'] = '已提交未审核';
$it618_ad_lang['s42'] = '未通过再提交';
$it618_ad_lang['s43'] = '审核已通过';
$it618_ad_lang['s44'] = '时长过期';
$it618_ad_lang['s45'] = '无';
$it618_ad_lang['s46'] = '提交';
$it618_ad_lang['s47'] = '查看';
$it618_ad_lang['s48'] = '您现在还没有广告位，请到本站有购买广告位的页面，选择您喜欢的广告位并购买，购买后提交广告内容给管理员审核，审核通过后就可以显示广告内容！';
$it618_ad_lang['s49'] = '抱歉，只有会员才可以购买广告位，请先登录！';
$it618_ad_lang['s50'] = '抱歉，此广告位不对外出售，请与管理员联系！';
$it618_ad_lang['s51'] = '抱歉，此广告位已有会员购买了！';
$it618_ad_lang['s52'] = '抱歉，您现在的可用';
$it618_ad_lang['s53'] = '只有';
$it618_ad_lang['s54'] = '，不够用于购买当前总金额为';
$it618_ad_lang['s55'] = '的广告位，请先增加你的';
$it618_ad_lang['s56'] = ' ！';
$it618_ad_lang['s57'] = '抱歉，只有会员才可以提交广告内容，请先登录！';
$it618_ad_lang['s58'] = '抱歉，此广告位购买者不是您！';
$it618_ad_lang['s59'] = '抱歉，此广告位不对外出售，请与管理员联系！';
$it618_ad_lang['s60'] = '抱歉，此广告位不存在现在不能提交广告内容！';
$it618_ad_lang['s61'] = '抱歉，您没有此广告位！';
$it618_ad_lang['s62'] = '抱歉，你所在的用户组没有购买广告位的权限！';
$it618_ad_lang['s63'] = '抱歉，只有会员才可以购买广告位，请先登录！';
$it618_ad_lang['s64'] = '图片广告';
$it618_ad_lang['s65'] = '文字广告';
$it618_ad_lang['s66'] = '抱歉，此广告位不对外出售，请与管理员联系！';
$it618_ad_lang['s67'] = '抱歉，此广告位已有会员购买了！';
$it618_ad_lang['s68'] = '添加广告位';
$it618_ad_lang['s69'] = '管理广告位';
$it618_ad_lang['s70'] = '成功能修改数：';
$it618_ad_lang['s71'] = '成功能删除数：';
$it618_ad_lang['s72'] = '管理广告位';
$it618_ad_lang['s73'] = '查找';
$it618_ad_lang['s74'] = '按广告调用位置';
$it618_ad_lang['s75'] = '广告位标题';
$it618_ad_lang['s76'] = '状态';
$it618_ad_lang['s77'] = '所有广告位状态';
$it618_ad_lang['s78'] = '出售';
$it618_ad_lang['s79'] = '自用';
$it618_ad_lang['s80'] = '可购买状态';
$it618_ad_lang['s81'] = '已购买状态';
$it618_ad_lang['s82'] = '排序';
$it618_ad_lang['s83'] = '选择排序方式';
$it618_ad_lang['s84'] = '按已售数量倒序';
$it618_ad_lang['s85'] = '按广告位面积倒序';
$it618_ad_lang['s86'] = '按价格倒序';
$it618_ad_lang['s87'] = '广告位数量:';
$it618_ad_lang['s88'] = '编号';
$it618_ad_lang['s89'] = '广告位标题';
$it618_ad_lang['s90'] = '广告调用位置';
$it618_ad_lang['s91'] = '广告位类型';
$it618_ad_lang['s92'] = '价格';
$it618_ad_lang['s93'] = '购买次数';
$it618_ad_lang['s94'] = '<font color=blue><b>行列序号值</b></font>/宽高/上下左右内边距/链接特征';
$it618_ad_lang['s95'] = '销售状态';
$it618_ad_lang['s96'] = '排序';
$it618_ad_lang['s97'] = '可购买状态';
$it618_ad_lang['s98'] = '已购买状态';
$it618_ad_lang['s99'] = '编辑/查看';
$it618_ad_lang['s100'] = '复制';
$it618_ad_lang['s101'] = '查看';
$it618_ad_lang['s102'] = '图片广告';
$it618_ad_lang['s103'] = '文字广告';
$it618_ad_lang['s104'] = '出售';
$it618_ad_lang['s105'] = '自用';
$it618_ad_lang['s106'] = '关闭';
$it618_ad_lang['s107'] = '<font color=red>注意：相同调用位置的广告通过单元格的行数与列数定位，根据调用位置的宽度与广告宽度，合理确定列数</font>，如果是文字广告，字大小或个数设置为0时表示默认12px或不限制';
$it618_ad_lang['s108'] = '请选择广告位类别！';
$it618_ad_lang['s109'] = '请输入广告位名称！';
$it618_ad_lang['s110'] = '请输入广告位价格！';
$it618_ad_lang['s111'] = '广告位添加成功！';
$it618_ad_lang['s112'] = '添加广告位';
$it618_ad_lang['s113'] = '：';
$it618_ad_lang['s114'] = '字';
$it618_ad_lang['s115'] = '关闭';
$it618_ad_lang['s116'] = '广告调用位置：';
$it618_ad_lang['s117'] = '请选择广告位类别';
$it618_ad_lang['s118'] = '注意：为了方便管理，类别推荐以广告位所在页面为角度，如：论坛首页、论坛列表页、论坛帖子页等';
$it618_ad_lang['s119'] = '广告位标题：';
$it618_ad_lang['s120'] = '注意: 广告标题只为识别辨认不同广告条目之用，并不在广告中显示';
$it618_ad_lang['s121'] = '广告位广告：';
$it618_ad_lang['s122'] = '上传图片';
$it618_ad_lang['s123'] = ' 推荐图片尺寸：200*120 购买窗口左上角显示的图片';
$it618_ad_lang['s124'] = '广告位置：';
$it618_ad_lang['s125'] = 'DIY使用教程';
$it618_ad_lang['s126'] = '注意：<font color=red>广告位在什么页面显示，全靠这个标识符识别</font>，为空时默认显示在论坛首页<br><br><font color=red>也支持 Discuz后台-运营-站点广告 里的广告位，和DIY类似，站点广告里“广告标题”就是广告位的模块标识</font><br><br>注意：在添加站点广告时，只设置广告在哪显示的属性，“广告起始时间”与“广告结束时间”可以空着，“展现方式”为代码，“广告 HTML 代码”随便填什么';
$it618_ad_lang['s127'] = '广告位价格：';
$it618_ad_lang['s128'] = '积分';
$it618_ad_lang['s129'] = '广告位类型：';
$it618_ad_lang['s130'] = '图片广告';
$it618_ad_lang['s131'] = '文字广告';
$it618_ad_lang['s132'] = '销售状态';
$it618_ad_lang['s133'] = '出售';
$it618_ad_lang['s134'] = '自用';
$it618_ad_lang['s135'] = '排序';
$it618_ad_lang['s136'] = '注意: <font color=blue>排序值为0时广告位不显示</font>，大于0时按数值大排在前';
$it618_ad_lang['s137'] = '广告位尺寸：';
$it618_ad_lang['s138'] = '宽度';
$it618_ad_lang['s139'] = '高度';
$it618_ad_lang['s140'] = '注意：同一行的广告位，为了排版美观高度最好一致';
$it618_ad_lang['s141'] = '广告位说明：';
$it618_ad_lang['s142'] = '先购买广告位，然后再在广告位管理面板，提交您的广告内容，等待管理员审核广告内容，审核通过了广告就显示。如果广告位到期了，自动转换成可购买状态。注意：在广告内容审核通过之前，管理员有权删除你的购买，不过购买的积分会返还您的。';
$it618_ad_lang['s143'] = '广告位内容：<br><font color=red>自用或无人购买时广告位显示的内容</font>';
$it618_ad_lang['s144'] = '添加';
$it618_ad_lang['s145'] = '广告位为已购买状态，不可修改！';
$it618_ad_lang['s146'] = '广告位编辑成功！';
$it618_ad_lang['s147'] = '广告位复制成功！';
$it618_ad_lang['s148'] = '编辑广告位';
$it618_ad_lang['s149'] = '更新';
$it618_ad_lang['s150'] = '更新成功！(成功修改数:';
$it618_ad_lang['s151'] = '成功添加数:';
$it618_ad_lang['s152'] = '成功删除数:';
$it618_ad_lang['s153'] = '广告位类别管理';
$it618_ad_lang['s154'] = '查找';
$it618_ad_lang['s155'] = '按类别名称';
$it618_ad_lang['s156'] = '广告位类别数:';
$it618_ad_lang['s157'] = '类别名称';
$it618_ad_lang['s158'] = '类别排序(数值)';
$it618_ad_lang['s159'] = '广告位数';
$it618_ad_lang['s160'] = '成功删除数：';
$it618_ad_lang['s161'] = '，购买广告位剩余时长的积分已返还给会员，并且购买的广告位恢复可购买状态！';
$it618_ad_lang['s162'] = '成功审核通过数：';
$it618_ad_lang['s163'] = '成功审核不通过数：';
$it618_ad_lang['s164'] = '广告位销售管理';
$it618_ad_lang['s165'] = '查找';
$it618_ad_lang['s166'] = '按广告位标题';
$it618_ad_lang['s167'] = '会员编号';
$it618_ad_lang['s168'] = '状态';
$it618_ad_lang['s169'] = '所有状态';
$it618_ad_lang['s170'] = '未提交';
$it618_ad_lang['s171'] = '已提交未审核';
$it618_ad_lang['s172'] = '未通过再提交';
$it618_ad_lang['s173'] = '审核已通过';
$it618_ad_lang['s174'] = '时长过期';
$it618_ad_lang['s175'] = '销售数量：';
$it618_ad_lang['s176'] = '广告位信息';
$it618_ad_lang['s177'] = '价格';
$it618_ad_lang['s178'] = '时长';
$it618_ad_lang['s179'] = '金额';
$it618_ad_lang['s180'] = '广告内容';
$it618_ad_lang['s181'] = '开始时间';
$it618_ad_lang['s182'] = '截止时间';
$it618_ad_lang['s183'] = '购买时间';
$it618_ad_lang['s184'] = '状态';
$it618_ad_lang['s185'] = '会员';
$it618_ad_lang['s186'] = '图片广告';
$it618_ad_lang['s187'] = '文字广告';
$it618_ad_lang['s188'] = '查看';
$it618_ad_lang['s189'] = '无';
$it618_ad_lang['s190'] = '广告位编号：';
$it618_ad_lang['s191'] = '类别：';
$it618_ad_lang['s192'] = '标题：';
$it618_ad_lang['s193'] = '广告图片地址：';
$it618_ad_lang['s194'] = '广告文字信息：';
$it618_ad_lang['s195'] = '广告链接地址：';
$it618_ad_lang['s196'] = '广告提示信息：';
$it618_ad_lang['s197'] = '广告效果预览如下：';
$it618_ad_lang['s198'] = '图片广告位尺寸(宽*高):';
$it618_ad_lang['s199'] = '文字广告位尺寸(宽*高):';
$it618_ad_lang['s200'] = '广告内容';
$it618_ad_lang['s201'] = '关闭';
$it618_ad_lang['s202'] = '反选';
$it618_ad_lang['s203'] = '取消选中销售单(不退积分)';
$it618_ad_lang['s204'] = '此操作不可逆，确定要取消(不退积分)吗？';
$it618_ad_lang['s205'] = '选中销售单审核通过';
$it618_ad_lang['s206'] = '此操作不可逆，确定要审核通过选中销售单吗？';
$it618_ad_lang['s207'] = '选中销售单审核不通过';
$it618_ad_lang['s208'] = '此操作不可逆，确定要审核不通过选中销售单吗？';
$it618_ad_lang['s209'] = '<br>销售单状态(<font color=blue>未提交</font>、<font color=red>已提交未审核</font>、<font color=blue>未通过再提交</font>、<font color=green>审核已通过</font>、<font color=#ccc>时长过期</font>)<br>注意：1、如果交易是审核通过状态，删除后积分自动返还给会员，广告位又可以购买了 2、销售单状态为(<font color=red>已提交未审核</font>)可以审核通过与审核不通过';
$it618_ad_lang['s210'] = '抱歉，只有会员才可以进入图片管理，请先登录！';
$it618_ad_lang['s211'] = '抱歉，只有购买了广告位才可以进入图片管理，请先购买广告位！';
$it618_ad_lang['s212'] = '可用时长';
$it618_ad_lang['s213'] = '左边距：';
$it618_ad_lang['s214'] = '上边距：';
$it618_ad_lang['s215'] = '下边距：';
$it618_ad_lang['s216'] = '广告位类别';
$it618_ad_lang['s217'] = '所有广告位类别';
$it618_ad_lang['s218'] = '广告位类型';
$it618_ad_lang['s219'] = '所有类型';
$it618_ad_lang['s220'] = '抱歉，您访问的页面不存在！';
$it618_ad_lang['s221'] = 'flash广告';
$it618_ad_lang['s222'] = '广告flash地址：';
$it618_ad_lang['s223'] = '天';
$it618_ad_lang['s224'] = '抱歉，请选择广告位类别！';
$it618_ad_lang['s225'] = '抱歉，广告位宽度不能为0！';
$it618_ad_lang['s226'] = '抱歉，广告位高度不能为0！';
$it618_ad_lang['s227'] = '最少购买';
$it618_ad_lang['s228'] = '时长 最多购买';
$it618_ad_lang['s229'] = '时长';
$it618_ad_lang['s230'] = '可以限制最少与最多购买的时长，为0时表示不限制';
$it618_ad_lang['s231'] = '时长购买限制';
$it618_ad_lang['s232'] = '最少';
$it618_ad_lang['s233'] = '最多';
$it618_ad_lang['s234'] = 'nofollow';
$it618_ad_lang['s235'] = '不显示价格';
$it618_ad_lang['s236'] = '购买次数：';
$it618_ad_lang['s237'] = '抱歉，广告时长最少要购买';
$it618_ad_lang['s238'] = '抱歉，广告时长最多只能购买';
$it618_ad_lang['s239'] = '修改';
$it618_ad_lang['s240'] = '抱歉，此广告位现在不能修改广告内容！';
$it618_ad_lang['s241'] = '提交广告内容';
$it618_ad_lang['s242'] = '修改广告内容';
$it618_ad_lang['s243'] = '查看广告内容';
$it618_ad_lang['s244'] = '续费';
$it618_ad_lang['s245'] = '最少要购买';
$it618_ad_lang['s246'] = '最多只能购买';
$it618_ad_lang['s247'] = '购买限制：';
$it618_ad_lang['s248'] = '续费广告位';
$it618_ad_lang['s249'] = '如果广告位有会员购买了并且时长还没过期，时长单位不能修改';
$it618_ad_lang['s250'] = '抱歉，请先登录！';
$it618_ad_lang['s251'] = '抱歉，参数有误！';
$it618_ad_lang['s252'] = '合计次数：';
$it618_ad_lang['s253'] = '合计费用：';
$it618_ad_lang['s254'] = '合计时长：';
$it618_ad_lang['s255'] = '轮播广告';
$it618_ad_lang['s256'] = '共续费';
$it618_ad_lang['s257'] = '次';
$it618_ad_lang['s258'] = '价格：';
$it618_ad_lang['s259'] = '时长：';
$it618_ad_lang['s260'] = '首次购买时间：';
$it618_ad_lang['s261'] = '如何添加广告调用位置';
$it618_ad_lang['s262'] = '切换时间(毫秒)：';
$it618_ad_lang['s264'] = '轮播';
$it618_ad_lang['s265'] = '抱歉，购买时长要大于0！';
$it618_ad_lang['s266'] = '页';
$it618_ad_lang['s267'] = '共';
$it618_ad_lang['s268'] = '抱歉，此广告位已有人购买了！';
$it618_ad_lang['s269'] = '抱歉，您续费的订单时长已过期，不能再续费，可以再重新购买此广告位！';
$it618_ad_lang['s270'] = '加上您剩余的';
$it618_ad_lang['s271'] = '添加单页';
$it618_ad_lang['s272'] = '单页管理';
$it618_ad_lang['s273'] = '按单页名称';
$it618_ad_lang['s274'] = '查找';
$it618_ad_lang['s275'] = '单页数：';
$it618_ad_lang['s276'] = '单页名称';
$it618_ad_lang['s277'] = '原始访问链接';
$it618_ad_lang['s278'] = '伪静态访问链接';
$it618_ad_lang['s279'] = '浏览数';
$it618_ad_lang['s280'] = '<font color=red>提示：如果空间支持伪静态，先找到论坛的伪静态规则文件，并且参照论坛的规则找到对应的插件伪静态规则，再把插件的伪静态规则复制到论坛规则前面</font><br><br><font color=blue>伪静态链接示例格式：ad-1.html 如果您会伪静态规则，可以改成别的</font><br><br><h1>Apache Web Server(独立主机用户)</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/ad-([0-9]+)\.html$ $1/plugin.php?id=it618_ad:onepage&oid=$2&%1

&lt;/IfModule&gt;
</pre>

<h1>Apache Web Server(虚拟主机用户)</h1>
<pre class="colorbox">
# 将 RewriteEngine 模式打开
RewriteEngine On

# 修改以下语句中的 /discuz 为您的论坛目录地址，如果程序放在根目录中，请将 /discuz 修改为 /
RewriteBase /discuz

# Rewrite 系统规则请勿修改
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^ad-([0-9]+)\.html$ plugin.php?id=it618_ad:onepage&oid=$1&%1</font>

</pre>

<h1>IIS Web Server(独立主机用户)</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/ad-([0-9]+)\.html(\?(.*))*$ $1/plugin\.php\?id=it618_ad:onepage&oid=$2&$4</font>

</pre>

<h1>IIS7 Web Server(独立主机用户)</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="ad"&gt;
			&lt;match url="^(.*/)*ad-([0-9]+).html\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_ad:onepage&amp;amp;oid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/ad-([0-9]+)\.html\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_ad:onepage&oid=$2&$3
endif
</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/ad-([0-9]+)\.html$ $1/plugin.php?id=it618_ad:onepage&oid=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>';
$it618_ad_lang['s281'] = '单页添加成功！';
$it618_ad_lang['s282'] = '添加单页';
$it618_ad_lang['s283'] = '请输入单页名称！';
$it618_ad_lang['s284'] = '单页名称：';
$it618_ad_lang['s285'] = '单页内容：';
$it618_ad_lang['s286'] = '可以直接引用广告位的模块标识符，比如：{标识符名称}，把这个{标识符名称}这个引用标签放在单页内容内，就可以了';
$it618_ad_lang['s287'] = 'SEO关键词：';
$it618_ad_lang['s288'] = 'SEO描述：';
$it618_ad_lang['s289'] = '提交';
$it618_ad_lang['s290'] = '单页修改成功！';
$it618_ad_lang['s291'] = '编辑单页';
$it618_ad_lang['s292'] = '全站最顶部';
$it618_ad_lang['s293'] = '全站导航下面';
$it618_ad_lang['s294'] = '全站页脚上面';
$it618_ad_lang['s295'] = '论坛首页发帖统计下面';
$it618_ad_lang['s296'] = '上架';
$it618_ad_lang['s297'] = '注意：如果是轮播广告，行列相同时就算一个轮播组合，按页数排序';
$it618_ad_lang['s298'] = '所有调用位置';
$it618_ad_lang['s299'] = '抱歉，上传图片的格式只能"jpg","jpeg","gif","png"！';
$it618_ad_lang['s300'] = '抱歉，上传的图片大小超过了最大限制！';
$it618_ad_lang['s301'] = '抱歉，上传flash的格式只能"swf"！';
$it618_ad_lang['s302'] = '抱歉，上传的flash大小超过了最大限制！';
$it618_ad_lang['s303'] = '抱歉，请先选择要上传的文件！';
$it618_ad_lang['s304'] = '全站二级导航下面';
$it618_ad_lang['s305'] = '购买此广告位';
$it618_ad_lang['s306'] = '注意：可以一行一列和一行多列，多列时一定要保证每行的列数相同';
$it618_ad_lang['s307'] = '排序值/上下内边距';
$it618_ad_lang['s308'] = '注意：手机版广告没有宽高，是根据广告内容自适应的';
$it618_ad_lang['s309'] = '自定广告';
$it618_ad_lang['s310'] = '轮播广告';
$it618_ad_lang['s311'] = '广告内容：';
$it618_ad_lang['s312'] = '链接特征';
$it618_ad_lang['s313'] = '<br>注意：链接特征为空了，表示所有页面的这个广告调用位置都显示广告位，如果设置了链接特征，自动匹配当前页面的链接显示，这样就可以设置不同页面显示不同广告位了<br><font color=blue>链接特征语法：@表示通配符(提示：@通配符最多可以用二个)，比如：只在论坛某一个版块页显示，可以这样表示：<font color=green>@fid=1@</font>，如果想匹配多个，条件间可以用|隔开，如：<font color=green>@fid=1@|@fid=2@</font>，支持任意特征字符</font>';
$it618_ad_lang['s314'] = '全站页头';
$it618_ad_lang['s315'] = '全站页脚';
$it618_ad_lang['s316'] = '论坛首页顶部';
$it618_ad_lang['s317'] = '论坛首页底部';
$it618_ad_lang['s318'] = '版块页顶部';
$it618_ad_lang['s319'] = '版块页底部';
$it618_ad_lang['s320'] = '<font color=blue>帖子页顶部</font>';
$it618_ad_lang['s321'] = '<font color=blue>帖子页内容上面</font>';
$it618_ad_lang['s322'] = '<font color=blue>帖子页内容下面</font>';
$it618_ad_lang['s323'] = '<font color=blue>帖子页底部</font>';
$it618_ad_lang['s324'] = '发贴页底部';
$it618_ad_lang['s325'] = '登录页底部';
$it618_ad_lang['s326'] = '楼帖子';
$it618_ad_lang['s327'] = '<font color=blue>注意：广告位置在帖子页的广告，如果排序值相同时，自动根据当前帖子的版块ID、分类ID与帖子ID对比条件，按优先级只显示一个，优先级别：<font color=green>帖子ID(tid)</font> > <font color=green>分类ID(typeid)</font> > <font color=green>版块ID(fid)</font></font> 如果没有设置条件，就是所有帖子都显示 ';
$it618_ad_lang['s328'] = '版块ID：';
$it618_ad_lang['s329'] = '分类ID：';
$it618_ad_lang['s330'] = '帖子ID：';
$it618_ad_lang['s331'] = '优先级设置(多个符合条件的ID编号用 , 隔开)';
$it618_ad_lang['s332'] = '广告位信息';
$it618_ad_lang['s333'] = '预设内容';
$it618_ad_lang['s334'] = '会员';
$it618_ad_lang['s335'] = '广告截止时间';
$it618_ad_lang['s336'] = '备注';
$it618_ad_lang['s337'] = '启用';
$it618_ad_lang['s338'] = '单号';
$it618_ad_lang['s339'] = '广告开始时间';
$it618_ad_lang['s340'] = '<font color=red>支持会员预设时帖子作者智能显示</font>';
$it618_ad_lang['s341'] = '添加预设';
$it618_ad_lang['s342'] = '<font color=green>如果“会员预设时帖子作者智能显示”不支持，那么会员预设可以独占，如果支持，可以多个会员预设，谁发的帖子就显示谁的预设广告，不是预设会员发的帖子显示默认广告</font>';
$it618_ad_lang['s343'] = '编辑内容';
$it618_ad_lang['s344'] = '广告位编号：';
$it618_ad_lang['s345'] = '类型：';
$it618_ad_lang['s346'] = '抱歉，此广告位不支持会员预设时帖子作者智能显示，您已添加了一个预设，不能再添加！';
$it618_ad_lang['s347'] = '剩余：';
$it618_ad_lang['s348'] = '过期';
$it618_ad_lang['s349'] = '<font color=red>帖子作者智能显示</font>';
$it618_ad_lang['s350'] = '图片编号：';
$it618_ad_lang['s351'] = '轮播图片：';
$it618_ad_lang['s352'] = '图片链接：';
$it618_ad_lang['s353'] = '编辑预设广告内容';
$it618_ad_lang['s354'] = '会员ID：';
$it618_ad_lang['s355'] = '删除此广告调用位置';
$it618_ad_lang['s356'] = '对齐/大小/个数';
$it618_ad_lang['s357'] = '确定要删除此广告调用位置？此操作不可逆！';
$it618_ad_lang['s358'] = '抱歉，此广告调用位置下还有';
$it618_ad_lang['s359'] = '个广告位，请先删除广告位或修改广告位的调用位置！';
$it618_ad_lang['s360'] = '广告调用位置删除成功！';
$it618_ad_lang['s361'] = '我的手机号：';
$it618_ad_lang['s362'] = '广告内容审核通过或未通过会自动短信提醒';
$it618_ad_lang['s363'] = '编辑';
$it618_ad_lang['s364'] = '抱歉，您没有超级管理权限，请在插件后台设置或与管理员联系！';
$it618_ad_lang['s365'] = '默认值';
$it618_ad_lang['s366'] = '已取消';
$it618_ad_lang['s367'] = '取消选中销售单(退积分)';
$it618_ad_lang['s368'] = '此操作不可逆，确定要取消(退积分)吗？';
$it618_ad_lang['s369'] = '删除选中销售单(退积分)';
$it618_ad_lang['s370'] = '此操作不可逆，而且删除后就没有这个交易记录了，确定要删除(退积分)吗？';
$it618_ad_lang['s371'] = '成功下架数：';
$it618_ad_lang['s372'] = '，购买的广告位恢复可购买状态！';
$it618_ad_lang['s373'] = '删除选中销售单(不退积分)';
$it618_ad_lang['s469'] = '参数名称';
$it618_ad_lang['s470'] = '参数内容';
$it618_ad_lang['s471'] = '提示：最多支持9个微信消息模板参数，参数名称比如是：first,keyword1,keyword2,keyword3,...,remark，参数内容支持以上一个标签或多个标签';
$it618_ad_lang['s472'] = '取消';
$it618_ad_lang['s473'] = '保存';
$it618_ad_lang['s474'] = '抱歉，如果参数名称填写了，就必须填写参数内容！';
$it618_ad_lang['s374'] = '此操作不可逆，而且删除后就没有这个交易记录了，确定要删除(不退积分)吗？';
$it618_ad_lang['s511'] = '启用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_ad_lang['s512'] = '消息提醒设置更新成功！';
$it618_ad_lang['s513'] = '<strong>第三方短信接口，按短信条数收费，给第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注册账号并充值，然后填以下内容就可以了';
$it618_ad_lang['s514'] = '启用消息接口：';
$it618_ad_lang['s515'] = '如果不启用，系统不会有消息提醒功能 <font color=blue>如果安装了【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】就会支持微信模板消息，微信模板ID不为空时，优先发微信模板消息，而不发短信</font>';
$it618_ad_lang['s516'] = '短信接口账号：';
$it618_ad_lang['s517'] = '短信接口密码：';
$it618_ad_lang['s518'] = '测试接收人手机号：';
$it618_ad_lang['it618']='iil11ll11liilliiili11ilililili1ililililililili1111111lililliliililili1111111ilililili1111111111i1llili111ll111111111ilili111111ii11';
$it618_ad_lang['s519'] = '多个手机号用英文字母逗号隔开';
$it618_ad_lang['s520'] = '测试短信内容：';
$it618_ad_lang['s521'] = '管理员手机号：';
$it618_ad_lang['s522'] = '如果不启用，管理员不会有消息提醒';
$it618_ad_lang['s523'] = '消息模板';
$it618_ad_lang['s524'] = '注意：消息模板只有在“启用”状态，才发送提醒消息，如果短信消息模板和微信消息模板都设置了，优先发送微信消息，发送成功了，就不发短信了，方便节省短信成本';
$it618_ad_lang['s525'] = '<font color="green">购买广告位时 - <font color=green>管理员消息模板</font></font>';
$it618_ad_lang['s526'] = '<font color="#999999">示例：会员${user} 用${money}购买了时长为${count}的广告位，交易号：${saleid}！
<br>标签说明：{user}购买会员，{money}积分数，{count}时长，{saleid}交易号</font>';
$it618_ad_lang['s527'] = '<font color="green">续费广告位时 - <font color=green>管理员消息模板</font></font>';
$it618_ad_lang['s528'] = '<font color="#999999">示例：会员${user} 用${money}续费了时长为${count}的广告位，交易号：${saleid}！
<br>标签说明：{user}续费会员，{money}积分数，{count}时长，{saleid}交易号</font>';
$it618_ad_lang['s529'] = '<font color="green">第一次提交广告内容时(自动审核) - <font color=green>管理员消息模板</font></font>';
$it618_ad_lang['s530'] = '<font color="#999999">示例：会员${user} 提交了广告内容并自动审核，交易号：${saleid}！ <br>标签说明：{user}提交会员，交易号：{saleid}</font>';
$it618_ad_lang['s531'] = '<font color="green">第一次提交广告内容时(手工审核) - <font color=green>管理员消息模板</font></font>';
$it618_ad_lang['s532'] = '<font color="#999999">示例：会员${user} 提交了广告内容，请审核，交易号：${saleid}！ <br>标签说明：{user}提交会员，交易号：{saleid}</font>';
$it618_ad_lang['s533'] = '<font color="green">广告内容审核通过时 - <font color=red>会员消息模板</font></font>';
$it618_ad_lang['s534'] = '<font color="#999999">示例：您的广告内容审核通过了，交易号：${saleid}！ <br>标签说明：{user}会员，交易号：{saleid}</font>';
$it618_ad_lang['s535'] = '更新成功！';
$it618_ad_lang['s536'] = '首页';
$it618_ad_lang['s537'] = '交易号';
$it618_ad_lang['s538'] = '';
$it618_ad_lang['s539'] = '"0" => "短信发送成功",
"-1" => "参数不全",
"-2" => "服务器空间不支持,请确认支持curl或者fsocket，联系您的空间商解决或者更换空间！",
"30" => "密码错误",
"40" => "账号不存在",
"41" => "余额不足",
"42" => "帐户已过期",
"43" => "IP地址限制",
"50" => "内容含有敏感词';
$it618_ad_lang['s540'] = '短信接口类型：';
$it618_ad_lang['s541'] = '默认标配短信接口(短信宝)';
$it618_ad_lang['s542'] = 'IT618统一短信接口(阿里大鱼)';
$it618_ad_lang['s543'] = '短信签名：';
$it618_ad_lang['s544'] = 'IT618统一短信接口(阿里云短信)';
$it618_ad_lang['s545'] = '<font color=green><b>抱歉，您还没有安装 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】，此插件为IT618公用短信接口插件，<font color=red>同时还是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_ad_lang['s546'] = '短信模板ID：';
$it618_ad_lang['s547'] = '消息提醒设置';
$it618_ad_lang['s548'] = '更新';
$it618_ad_lang['s549'] = '更新时发送一个测试短信';
$it618_ad_lang['s550'] = '<font color="green">广告内容审核不通过时 - <font color=red>会员消息模板</font></font>';
$it618_ad_lang['s551'] = '<font color="#999999">示例：您的广告内容审核未通过，请与管理员联系，交易号：${saleid}！ <br>标签说明：{user}会员，{saleid}交易号</font>';
$it618_ad_lang['s552'] = '抱歉，此插件还未开启，请先开启！';
$it618_ad_lang['s553'] = '【';
$it618_ad_lang['s554'] = '】';
$it618_ad_lang['s555'] = '<font color="green">自助广告即将到期时 - <font color=red>会员消息模板</font></font>';
$it618_ad_lang['s556'] = '<font color="#999999">示例：您的广告即将到期时，还剩余{timecount}，请即时续费，交易号：${saleid}！ <br>标签说明：{user}会员，{timecount}剩余时间+单位，{saleid}交易号</font><br><font color=red>注意：此自助广告即将到期提醒功能仅在安装了 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】，后可用，优先给会员发送微信消息，没发成功再给会员绑定的手机发送短信提醒<br>如果广告时间单位是天，会在7天内、3天内、1天内触发3次提醒，如果广告时间单位是时，会在1小时内触发1次提醒</font>';
$it618_ad_lang['s557'] = '更新';
$it618_ad_lang['s558'] = '更新时发送一个测试短信';
$it618_ad_lang['s559'] = '提示：如果广告时间单位是天，会在7天内、3天内、1天内触发3次提醒，如果广告时间单位是时，会在1小时内触发1次提醒，请在账号中心绑定手机或绑定关注微信号，推荐微信消息提醒';
$it618_ad_lang['s560'] = '';
$it618_ad_lang['s1040'] = '短信接口类型：';
$it618_ad_lang['s1041'] = '默认标配短信接口(短信宝)';
$it618_ad_lang['s1042'] = 'IT618统一短信接口(阿里大鱼)';
$it618_ad_lang['s1043'] = '短信签名：';
$it618_ad_lang['s1044'] = 'IT618统一短信接口(阿里云短信)';
$it618_ad_lang['s1045'] = '<font color=green><b>抱歉，您还没有安装 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】，此插件为IT618公用短信接口插件，<font color=red>同时还是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_ad_lang['s1046'] = '短信模板ID：';
$it618_ad_lang['s1047'] = '消息提醒设置';
$it618_ad_lang['s1048'] = '如果是个人认证，变量字符最多限制个数：';
$it618_ad_lang['s1049'] = '不受限制时请不要填写';
$it618_ad_lang['s1050'] = '管理员UID<font color=#999>(用于微信消息，多个UID用,隔开)</font>：';
$it618_ad_lang['s1051'] = '微信消息模板ID：';
$it618_ad_lang['s1052'] = '微信消息标签值：';
$it618_ad_lang['s1053'] = '<font color=#999>提示：优先发送微信消息，发送成功了，就不发短信了</font>';

//it618_lang_admin\[(\d+)\] it618_ad_lang['s$1']
//{lang it618_ad:it618_ad_lang(\d+)} {$it618_ad_lang['t$1']} 
$it618_ad_lang['t1'] = '广告位编号：';
$it618_ad_lang['t2'] = '广告位类型：';
$it618_ad_lang['t3'] = '广告显示位置：';
$it618_ad_lang['t4'] = '已购买次数：';
$it618_ad_lang['t5'] = '随机播放';
$it618_ad_lang['t6'] = '提示：可以直接引用外部图片地址，也可以自己上传本地图片';
$it618_ad_lang['t7'] = '提示：可以直接引用外部flash地址，也可以自己上传本地flash';
$it618_ad_lang['t8'] = '返回';
$it618_ad_lang['t9'] = '引用上传的图片';
$it618_ad_lang['t10'] = '提示：图片大小不要超过';
$it618_ad_lang['t11'] = '引用上传的flash';
$it618_ad_lang['t12'] = '提示：flash大小不要超过';
$it618_ad_lang['t13'] = '上传图片';
$it618_ad_lang['t14'] = '上传flash';
$it618_ad_lang['t15'] = '积分钱包';
$it618_ad_lang['t16'] = '左';
$it618_ad_lang['t17'] = '中';
$it618_ad_lang['t18'] = '右';
$it618_ad_lang['t19'] = '？';
$it618_ad_lang['t20'] = '';
$it618_ad_lang['t21'] = '';
$it618_ad_lang['t22'] = '';
$it618_ad_lang['t23'] = '';
$it618_ad_lang['t24'] = '';
$it618_ad_lang['t25'] = '';
$it618_ad_lang['t26'] = '';
$it618_ad_lang['t27'] = '';
$it618_ad_lang['t28'] = '';
$it618_ad_lang['t29'] = '';
$it618_ad_lang['t30'] = '';
$it618_ad_lang['t31'] = '';
$it618_ad_lang['t32'] = '';
$it618_ad_lang['t33'] = '类别排序：';
$it618_ad_lang['t34'] = '必填且必须为数字！';
$it618_ad_lang['t35'] = '确认修改';
$it618_ad_lang['t36'] = '取消修改';
$it618_ad_lang['t37'] = '添加物料类别';
$it618_ad_lang['t38'] = '确认添加';
$it618_ad_lang['t39'] = '插入物料';
$it618_ad_lang['t40'] = '我的广告管理';
$it618_ad_lang['t41'] = '广告物料管理';
$it618_ad_lang['t42'] = '所有已购买广告位';
$it618_ad_lang['t43'] = '文字广告数/金额：';
$it618_ad_lang['t44'] = '图片广告数/金额：';
$it618_ad_lang['t45'] = '所有广告数/金额：';
$it618_ad_lang['t46'] = '广告编号';
$it618_ad_lang['t47'] = '广告类型';
$it618_ad_lang['t48'] = '广告尺寸';
$it618_ad_lang['t49'] = '首次购买记录/续费记录';
$it618_ad_lang['t50'] = '总时长';
$it618_ad_lang['t51'] = '总费用';
$it618_ad_lang['t52'] = '开始时间';
$it618_ad_lang['t53'] = '截止时间';
$it618_ad_lang['t54'] = '可用时长';
$it618_ad_lang['t55'] = '购买时间';
$it618_ad_lang['t56'] = '内容';
$it618_ad_lang['t57'] = '状态';
$it618_ad_lang['t58'] = '提示：广告尺寸(宽*高 单位:px)';
$it618_ad_lang['t59'] = '提交广告内容';
$it618_ad_lang['t60'] = '提交广告内容后，请耐心等待管理员审核，审核通过后广告会自动显示。';
$it618_ad_lang['t61'] = '广告图片地址：';
$it618_ad_lang['t62'] = '选择物料';
$it618_ad_lang['t63'] = '管理物料';
$it618_ad_lang['t64'] = '广告文字信息：';
$it618_ad_lang['t65'] = '广告链接地址：';
$it618_ad_lang['t66'] = '广告提示信息：';
$it618_ad_lang['t67'] = '提交';
$it618_ad_lang['t68'] = '如果没有自由修改广告内容权限，提交了就不能修改了，最好先预览一下效果，确定要提交广告内容吗？';
$it618_ad_lang['t69'] = '预览';
$it618_ad_lang['t70'] = '取消';
$it618_ad_lang['t71'] = '预览广告效果';
$it618_ad_lang['t72'] = '广告位尺寸(宽*高):';
$it618_ad_lang['t73'] = '祝贺您成功提交广告内容，请耐心等待管理员审核！';
$it618_ad_lang['t74'] = '确定';
$it618_ad_lang['t75'] = '请输入图片地址！';
$it618_ad_lang['t76'] = '请输入文字信息！';
$it618_ad_lang['t77'] = '请输入广告链接！';
$it618_ad_lang['t78'] = '购买广告位';
$it618_ad_lang['t79'] = '广告编号：';
$it618_ad_lang['t80'] = '广告类型：';
$it618_ad_lang['t81'] = '广告尺寸(宽*高)：';
$it618_ad_lang['t82'] = '单位：';
$it618_ad_lang['t83'] = '我的';
$it618_ad_lang['t84'] = '广告价格：';
$it618_ad_lang['t85'] = '小时';
$it618_ad_lang['t86'] = '购买时长：';
$it618_ad_lang['t87'] = '应付：';
$it618_ad_lang['t88'] = '广告位说明';
$it618_ad_lang['t89'] = '购买';
$it618_ad_lang['t90'] = '确定要购买此广告位吗？';
$it618_ad_lang['t91'] = '取消';
$it618_ad_lang['t92'] = '祝贺您广告位购买成功！';
$it618_ad_lang['t93'] = '现在去提交广告内容';
$it618_ad_lang['t94'] = '记住以后要管理我的广告，请到<font color="red">快捷导航->我的广告</font>！';
$it618_ad_lang['t95'] = '请输入时长数量！';
$it618_ad_lang['t96'] = '时长数量一定要为整数值！';
$it618_ad_lang['t97'] = '如何获取';
$it618_ad_lang['t98'] = '？';
$it618_ad_lang['t99'] = '文字颜色：';
$it618_ad_lang['t100'] = '关闭';
$it618_ad_lang['t101'] = '提交广告内容后，自动审核通过，广告位直接显示你的广告内容。';
$it618_ad_lang['t102'] = '祝贺您成功提交广告内容，现在就去看您的广告效果吧！';
$it618_ad_lang['t103'] = 'flash广告数/金额：';
$it618_ad_lang['t104'] = '广告flash地址：';
$it618_ad_lang['t105'] = '加粗';
$it618_ad_lang['t106'] = '请设置文字的颜色！';
$it618_ad_lang['t107'] = '颜色选择器';
$it618_ad_lang['t108'] = '我的权限：';
$it618_ad_lang['t109'] = '广告内容自动审核';
$it618_ad_lang['t110'] = '广告内容自由修改';
$it618_ad_lang['t111'] = '祝贺您广告位续费成功！';
$it618_ad_lang['t112'] = '现在去查看我的广告管理';
$it618_ad_lang['t113'] = '续费记录';
$it618_ad_lang['t114'] = '价格';
$it618_ad_lang['t115'] = '时长';
$it618_ad_lang['t116'] = '购买时间';
$it618_ad_lang['t117'] = '费用';
$it618_ad_lang['t118'] = '费用：';
$it618_ad_lang['t119'] = '按广告类型：';
$it618_ad_lang['t120'] = '状态：';
$it618_ad_lang['t121'] = '搜索';
$it618_ad_lang['t122'] = '<font color=red>提示：也可以直接引用图片地址</font>';

?>