<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_ad/lang.func.php';

function it618_hook($blockname){
	global $_G,$it618_ad_lang;
	$it618_ad = $_G['cache']['plugin']['it618_ad'];
	$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];

	if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
	$it618_ad_adblock=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_adblock')." WHERE it618_name='".$blockname."'");
	if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
	$strall='<it618_tr>';
	$row=DB::result_first("SELECT it618_row FROM ".DB::table('it618_ad_ad')." WHERE it618_ison=1 and it618_blockname='".$blockname."' order by it618_blockname,it618_row,it618_col,id desc");
	$colcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_ad_ad')." WHERE it618_ison=1 and it618_blockname='".$blockname."' and it618_row=".$row);
	$usergroup=(array)unserialize($it618_ad['usergroup']);
	if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
	if(in_array($_G['groupid'], $usergroup)){
		$i1il11i=DB::result_first("SELECT it618_ad FROM ".DB::table('it618_ad'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		$query = DB::query("SELECT * FROM ".DB::table('it618_ad_ad')." WHERE it618_ison=1 and it618_blockname='".$blockname."' order by it618_blockname,it618_row,it618_col,id desc");
		while($it618_ad_ad =DB::fetch($query)) {
			$urlflag=1;
			$it618_url=$it618_ad_ad['it618_url'];
			if($it618_url!=''){
				$url_this = "http://".$_SERVER ['HTTP_HOST'].$_SERVER['REQUEST_URI'];
				$it618_urlarr=explode("|",$it618_url);
				for($i=0;$i<count($it618_urlarr);$i++){
					$tmparr=explode("@",$it618_urlarr[$i]);
					$urlflag=0;
					if(count($tmparr)==1){
						if($it618_urlarr[$i]==$url_this){$urlflag=1;break;}
					}
					if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
					if(count($tmparr)==2){
						if($tmparr[0]==""){
							$tmparr1=explode($tmparr[1],$url_this);
							if(count($tmparr1)>1&&$tmparr1[1]==""){$urlflag=1;break;}
						}else{
							$tmparr1=explode($tmparr[0],$url_this);
							if(count($tmparr1)>1&&$tmparr1[0]==""){$urlflag=1;break;}
						}
					}
					if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
					if(count($tmparr)==3){
						$tmparr1=explode($tmparr[1],$url_this);
						if(count($tmparr1)>1){$urlflag=1;break;}
					}
				}
			}
			
			if($urlflag==1){
				if(count($i1iii1)!=8)return;
				$buystr='';
				if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
				if($row!=$it618_ad_ad['it618_row']){
					$row=$it618_ad_ad['it618_row'];
					$colcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_ad_ad')." WHERE it618_ison=1 and it618_blockname='".$blockname."' and it618_row=".$row);
					
					$strall.='</it618_tr><it618_tr>';
				}
				if($colcount==1){
					$colspan=' colspan=3';
				}else{
					$colspan='';
				}
				if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
				$tdcss=' style="width:'.$it618_ad_ad['it618_width'].'px;height:'.$it618_ad_ad['it618_height'].'px;padding-top:'.$it618_ad_ad['it618_padding_top'].'px;padding-bottom:'.$it618_ad_ad['it618_padding_bottom'].'px;;padding-left:'.$it618_ad_ad['it618_padding_left'].'px;;padding-right:'.$it618_ad_ad['it618_padding_right'].'px;"';
				
				if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
				if($it618_ad_ad['it618_saletype']=='1'){
					if($it618_ad_ad['it618_pricetype']==1)$it618_pricetype=it618_ad_getlang('s33');
					if($it618_ad_ad['it618_pricetype']==2)$it618_pricetype=it618_ad_getlang('s223');
					if($it618_ad_ad['it618_isnoprice']==1){
						$pricestr='';
					}else{
						$pricestr='<span style="color:red">'.$it618_ad_ad['it618_price'].'</span><span style="color:green">'.$creditname.'</span>/'.$it618_pricetype;
					}
					if($it618_ad_ad['it618_adtype']!=2&&$pricestr!='')$pricestr=$pricestr.' ';
					if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
					if($it618_ad_ad['it618_state']==0){
						$flag=1;
						if($it618_ad_ad['it618_adtype']==2){
							$buystr='<a href="javascript:" title="'.it618_ad_getlang('s34').'" onclick="showWindow(\'it618_showsale\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showsale&aid='.$it618_ad_ad['id'].'\');">'.it618_ad_getlang('s305').'['.$pricestr.']</a>';
						}else{
							$buystr='<span class="it618_ad_float" style="z-index:9">'.$pricestr.'<a href="javascript:" title="'.it618_ad_getlang('s34').'" style="float:none;padding:0;margin:0;" onclick="showWindow(\'it618_showsale\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showsale&aid='.$it618_ad_ad['id'].'\');">'.it618_ad_getlang('s35').'</a></span>';
						}
						if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
						
					}elseif($it618_ad_ad['it618_adtype']<4){
						$it618_ad_salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_ad_sale')." where it618_state=3 and it618_aid=".$it618_ad_ad['id']);
						
						if($it618_ad_salecount>0){
							$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where it618_state=3 and it618_aid=".$it618_ad_ad['id']);
							if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
							if($i1iii1[5]!='_')return;
							
							if($it618_ad_ad['it618_isnofollow']==1)$isnofollow='rel="nofollow"';else $isnofollow='';
							if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
							$it618_fontalign='';
							if($it618_ad_ad['it618_adtype']==1){
								
								$strcontent='<a href="'.$it618_ad_sale['it618_url'].'" target="_blank" '.$isnofollow.' title="'.$it618_ad_sale['it618_tip'].'"><img width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" src="'.$it618_ad_sale['it618_imgurl'].'"/></a>';
								
							}elseif($it618_ad_ad['it618_adtype']==2){
								if($it618_ad_ad['it618_fontalign']==1)$it618_fontalign='text-align:left';
								if($it618_ad_ad['it618_fontalign']==2)$it618_fontalign='text-align:center';
								if($it618_ad_ad['it618_fontalign']==3)$it618_fontalign='text-align:right';
								$fontsizecss='';
								if($it618_ad_ad['it618_fontsize']!=0)$fontsizecss='style="font-size:'.$it618_ad_ad['it618_fontsize'].'px;"';
								if($it618_ad_sale['it618_isfontbold']==1)$it618_title='<b>'.$it618_ad_sale['it618_title'].'</b>';else $it618_title=$it618_ad_sale['it618_title'];
								$strcontent='<a href="'.$it618_ad_sale['it618_url'].'" target="_blank" '.$isnofollow.' title="'.$it618_ad_sale['it618_tip'].'"><font color="'.$it618_ad_sale['it618_fontcolor'].'" '.$fontsizecss.'>'.$it618_title.'</font></a>';
								
							}elseif($it618_ad_ad['it618_adtype']==3){
								if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
								$strcontent='<embed src="'.$it618_ad_sale['it618_imgurl'].'" allowFullScreen="true" quality="high" width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>';
								
							}
							
							if($i1iii1[7]!='d')return;
							
							if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
							$stralltmp='<td'.$colspan.$tdcss.'><div style="height:'.$it618_ad_ad['it618_height'].'px;" class="it618_tddiv"><div class="it618_tddivcontent" style="width:'.$it618_ad_ad['it618_width'].'px;'.$it618_fontalign.'">'.$strcontent.'</div></div></td>';
							
							$flag=0;
							if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
							if($i1iii1[6]!='a')return;
						}else{
							$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where it618_state=0 and it618_aid=".$it618_ad_ad['id']);
							if($it618_ad_sale['it618_uid']>0)$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_ad_sale['it618_uid']);
							if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
							if($it618_ad['ad_isbuyer']==1){
								if($it618_ad_ad['it618_adtype']==2){
									$buystr=$it618_ad_ad['it618_message'];
								}else{
									$buystr='<div style="height:'.$it618_ad_ad['it618_height'].'px;" class="it618_tddiv"><div class="it618_tddivcontent" style="width:'.$it618_ad_ad['it618_width'].'px;">'.$it618_ad_ad['it618_message'].'</div></div><span class="it618_ad_float">'.it618_ad_getlang('s36').$username.it618_ad_getlang('s35').'</span>';
								}
							}else{
								if($it618_ad_ad['it618_adtype']==2){
									$buystr=$it618_ad_ad['it618_message'];
								}else{
									$buystr='<div style="height:'.$it618_ad_ad['it618_height'].'px;" class="it618_tddiv"><div class="it618_tddivcontent" style="width:'.$it618_ad_ad['it618_width'].'px;">'.$it618_ad_ad['it618_message'].'</div></div><span class="it618_ad_float">'.it618_ad_getlang('s36').it618_ad_getlang('s35').'</span>';
								}
							}
							if($it618_ad_ad['it618_adtype']==2){	
								$buystr='<div style="height:'.$it618_ad_ad['it618_height'].'px;" class="it618_tddiv"><div class="it618_tddivcontent" style="width:'.$it618_ad_ad['it618_width'].'px;">'.$buystr.'</div></div>';
							}
							if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
							if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
							$stralltmp='<td'.$colspan.$tdcss.'>'.$buystr.'</td>';
							
							$flag=0;
						}
					}else{
						$flag=1;
					}
				}else{
					$flag=1;
				}
				if($i1iii1[4]!='8')return;
				if($it618_ad_ad['it618_adtype']==4){
					$foucscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_ad_focus')." WHERE it618_order<>0 and it618_aid=".$it618_ad_ad['id']);
					if($foucscount>0){
						if($it618_ad_ad['it618_isrand']==1){
							$it618_ad_ad_focuss=C::t('#it618_ad#it618_ad_ad_focus')->fetch_all_by_aid_rand($it618_ad_ad['id']);
						}else{
							$it618_ad_ad_focuss=C::t('#it618_ad#it618_ad_ad_focus')->fetch_all_by_aid_order($it618_ad_ad['id']);
						}
						$str_focus='';
						if($it618_ad_ad['it618_isnofollow']==1)$isnofollow='rel="nofollow"';else $isnofollow='';
						foreach($it618_ad_ad_focuss as $it618_ad_ad_focus) {
							if($it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where it618_state<4 and it618_aid=".$it618_ad_ad['id'].' and it618_pid='.$it618_ad_ad_focus['id'])){
								if($it618_ad_sale['it618_state']==3){
									$strcontent='<a href="'.$it618_ad_sale['it618_url'].'" target="_blank" '.$isnofollow.' title="'.$it618_ad_sale['it618_tip'].'"><img width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" src="'.$it618_ad_sale['it618_imgurl'].'"/></a>';
									if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
									$str_focus.='<div class="swiper-slide">'.$strcontent.'</div>';
								}else{
									$it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where it618_state=0 and it618_aid=".$it618_ad_ad['id']);
									if($it618_ad_sale['it618_uid']>0)$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_ad_sale['it618_uid']);
									if($it618_ad_ad_focus['it618_url']!=''){
										$str_focustmp='<a href="'.$it618_ad_ad_focus['it618_url'].'" '.$isnofollow.' target="_blank"><img src="'.$it618_ad_ad_focus['it618_img'].'" width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'"/></a>';
									}else{
										$str_focustmp='<img src="'.$it618_ad_ad_focus['it618_img'].'" width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" />';
									}
									
									if($it618_ad['ad_isbuyer']==1){
										$buystr='<span class="it618_ad_float">'.it618_ad_getlang('s36').$username.it618_ad_getlang('s35').'</span>';
									}else{
										$buystr='<span class="it618_ad_float">'.it618_ad_getlang('s36').it618_ad_getlang('s35').'</span>';
									}
									if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
									$str_focus.='<div class="swiper-slide">'.$buystr.$str_focustmp.'</div>';
								}
							}else{
								if($it618_ad_ad_focus['it618_url']!=''){
									$str_focustmp='<a href="'.$it618_ad_ad_focus['it618_url'].'" '.$isnofollow.' target="_blank"><img src="'.$it618_ad_ad_focus['it618_img'].'" width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'"/></a>';
								}else{
									$str_focustmp='<img src="'.$it618_ad_ad_focus['it618_img'].'" width="'.$it618_ad_ad['it618_width'].'" height="'.$it618_ad_ad['it618_height'].'" />';
								}
								
	
								$buystr='<span class="it618_ad_float" style="z-index:9">'.$pricestr.'<a href="javascript:" title="'.it618_ad_getlang('s34').'" style="float:none;padding:0;margin:0;" onclick="showWindow(\'it618_showsale\',\''.$_G['siteurl'].'plugin.php?id=it618_ad:showsale&aid='.$it618_ad_ad['id'].'&pid='.$it618_ad_ad_focus['id'].'\');">'.it618_ad_getlang('s35').'</a></span>';

								$str_focus.='<div class="swiper-slide">'.$buystr.$str_focustmp.'</div>';
							}
						}
						if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
						$str_focus='<div id="it618_banner">
									<div class="swiper-container" id="bannerSwiper'.$it618_ad_ad['id'].'"> 
									<div class="swiper-wrapper" style="width:'.$it618_ad_ad['it618_width'].'px;height:'.$it618_ad_ad['it618_height'].'px">
									'.$str_focus.'
									</div>
									</div>
									<div id="bannerpagination'.$it618_ad_ad['id'].'" class="pagination"></div>
								 </div>
								 
								<link href="source/plugin/it618_ad/images/swiper.css" rel="stylesheet" type="text/css" />
								<script type="text/javascript" src="source/plugin/it618_ad/js/swiper.js"></script>
								<script>
								var mySwiper = new Swiper(\'#bannerSwiper'.$it618_ad_ad['id'].'\',{
									loop: true,
									autoplay:'.$it618_ad_ad['it618_speed'].',
									speed:1000,
									pagination: \'#bannerpagination'.$it618_ad_ad['id'].'\',
									paginationClickable: true,
									preventClicks : false,
									autoplayDisableOnInteraction:false,
									grabCursor : true,
									parallax:true,
								  });
								</script>';
									
						$stralltmp='<td'.$colspan.$tdcss.'><div style="height:'.$it618_ad_ad['it618_height'].'px;" class="it618_tddiv"><div class="it618_tddivcontent" style="width:'.$it618_ad_ad['it618_width'].'px;">'.$str_focus.'</div></div></td>';
					}
				}else{
					if($flag==1){
						if($it618_ad_ad['it618_saletype']=='1'&&$it618_ad_ad['it618_adtype']==2){
							$it618_message='';
						}else{
							$it618_fontalign='';
							if($it618_ad_ad['it618_adtype']==2){
								if($it618_ad_ad['it618_fontalign']==1)$it618_fontalign='text-align:left';
								if($it618_ad_ad['it618_fontalign']==2)$it618_fontalign='text-align:center';
								if($it618_ad_ad['it618_fontalign']==3)$it618_fontalign='text-align:right';
							}
							$it618_message=$it618_ad_ad['it618_message'];
						}
						
						$stralltmp='<td'.$colspan.$tdcss.'><div style="height:'.$it618_ad_ad['it618_height'].'px;" class="it618_tddiv"><div class="it618_tddivcontent" style="width:'.$it618_ad_ad['it618_width'].'px;'.$it618_fontalign.'">'.$it618_message.''.$buystr.'</div></div></td>';
			
					}	
				}
				
				$strall.=$stralltmp;
			}
	
		}
		
		if($strall!="<it618_tr>"){
			$strall=str_replace("<it618_tr>","<tr>",$strall);
			$strall=str_replace("</it618_tr>","</tr>",$strall);
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
			if($it618_ad_adblock['it618_bordertype']==2&&$it618_ad_adblock['it618_bordercolor']!=''){
				$tmpbordercss='border:'.$it618_ad_adblock['it618_bordercolor'].' 1px solid;';
			}
			
			if($it618_ad_adblock['it618_bordertype']==3&&$it618_ad_adblock['it618_bordercolor']!=''){
				$tmpbordercss='border:'.$it618_ad_adblock['it618_bordercolor'].' 1px dashed;';
			}
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
			if($it618_ad_adblock['it618_bgcolor']!=''){
				$tmpbgrcss='background-color:'.$it618_ad_adblock['it618_bgcolor'].';';
			}
			
			if($it618_ad_adblock['it618_width']!=0&&$it618_ad_adblock['it618_height']!=0){
				$tmprcss='#it618_ad_div_'.$it618_ad_adblock['id'].'{width:'.$it618_ad_adblock['it618_width'].'px;height:'.$it618_ad_adblock['it618_height'].'px;margin-top:'.$it618_ad_adblock['it618_margin_top'].'px;margin-bottom:'.$it618_ad_adblock['it618_margin_bottom'].'px;margin-left:'.$it618_ad_adblock['it618_margin_left'].'px;margin-right:'.$it618_ad_adblock['it618_margin_right'].'px;}';
			}
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
			$cssstr='<style>
			        .it618_adtable{width:100%}
					.it618_adtable tr td{position:relative;}
					.it618_tddiv{display:table;}
					.it618_tddivcontent {
						text-align:center;
						vertical-align:middle;
						display:table-cell;
					}
					.it618_ad_float{position:absolute; right:0px; top:0px; background-color:#e8e8e8; color:#000; padding-left:3px;padding-right:1px;
						font-size:12px;
						font-weight:normal;
						filter:alpha(opacity=50);
						-moz-opacity:0.5;
						-khtml-opacity: 0.5;
						opacity: 0.8;
						z-index:99}
					.it618_ad_float a{color:#000; text-decoration:none;}
					.it618_ad_float a:hover{ color:#F00}
			'.$tmprcss.'
			#it618_ad_'.$it618_ad_adblock['id'].' tr td{'.$tmpbordercss.$tmpbgrcss.'}
			</style>';
			
			include template('it618_ad:ad');
			return $it618_ad_block;
		}
	}
	
}

function it618_hook_wap($blockname,$lou=0,$tid=0,$uid=0){
	global $_G,$it618_ad_lang;
	$it618_ad = $_G['cache']['plugin']['it618_ad'];
	
	if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
	
	$usergroup=(array)unserialize($it618_ad['usergroup']);
	if(in_array($_G['groupid'], $usergroup)){
		$i1il11i=DB::result_first("SELECT it618_ad FROM ".DB::table('it618_ad'));
		$i1iii1=array();for($i=0;$i<strlen($i1il11i);$i++){if(substr($i1il11i,$i,1)==':')break;$i1iii1[]=substr($i1il11i,$i,1);}
		
		if($lou==0){
			$sql = "and it618_blockname='".$blockname."'";
		}else{
			$sql = "and it618_blockname='".$blockname."' and it618_lou=".$lou;
		}
		
		if($tid>0){
			$query = DB::query("SELECT it618_row FROM ".DB::table('it618_ad_wap_ad')." WHERE it618_ison=1 $sql group by it618_row order by it618_row");
		}else{
			$query = DB::query("SELECT * FROM ".DB::table('it618_ad_wap_ad')." WHERE it618_ison=1 $sql order by it618_row,id desc");
		}

		while($it618_ad_wap_ad =DB::fetch($query)) {
			$urlflag=0;
			if($tid>0){
				$query1 = DB::query("SELECT * FROM ".DB::table('it618_ad_wap_ad')." WHERE it618_ison=1 $sql and it618_row=".$it618_ad_wap_ad['it618_row']);
				while($it618_ad_wap_ad1 =DB::fetch($query1)) {
					$tids_arr=explode(",",$it618_ad_wap_ad1['it618_tids']);
					if(in_array($tid, $tids_arr)){
						$it618_ad_wap_ad=$it618_ad_wap_ad1;
						$urlflag=1;
						break;
					}
				}
				if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
				if($urlflag==0){
					$query1 = DB::query("SELECT * FROM ".DB::table('it618_ad_wap_ad')." WHERE it618_ison=1 $sql and it618_row=".$it618_ad_wap_ad['it618_row']);
					while($it618_ad_wap_ad1 =DB::fetch($query1)) {
						$typeid=DB::result_first("select typeid from ".DB::table('forum_thread')." where tid=$tid");
						$typeids_arr=explode(",",$it618_ad_wap_ad1['it618_typids']);
						if(in_array($typeid, $typeids_arr)){
							$it618_ad_wap_ad=$it618_ad_wap_ad1;
							$urlflag=1;
							break;
						}
					}
				}
				if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
				if($urlflag==0){
					$query1 = DB::query("SELECT * FROM ".DB::table('it618_ad_wap_ad')." WHERE it618_ison=1 $sql and it618_row=".$it618_ad_wap_ad['it618_row']);
					while($it618_ad_wap_ad1 =DB::fetch($query1)) {
						$fid=DB::result_first("select fid from ".DB::table('forum_thread')." where tid=$tid");
						$fids_arr=explode(",",$it618_ad_wap_ad1['it618_fids']);
						if(in_array($fid, $fids_arr)){
							$it618_ad_wap_ad=$it618_ad_wap_ad1;
							$urlflag=1;
							break;
						}
					}
				}
				if($urlflag==0&&$it618_ad_wap_ad1=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_wap_ad')." WHERE it618_tids='' and it618_typids='' and it618_fids='' and it618_ison=1 $sql and it618_row=".$it618_ad_wap_ad['it618_row'])){
					$it618_ad_wap_ad=$it618_ad_wap_ad1;
					$urlflag=1;
				}
			}else{
				$urlflag=1;
				$it618_url=$it618_ad_wap_ad['it618_url'];
				if($it618_url!=''){
					$url_this = "http://".$_SERVER ['HTTP_HOST'].$_SERVER['REQUEST_URI'];
					$it618_urlarr=explode("|",$it618_url);
					for($i=0;$i<count($it618_urlarr);$i++){
						$tmparr=explode("@",$it618_urlarr[$i]);
						$urlflag=0;
						if(count($tmparr)==1){
							if($it618_urlarr[$i]==$url_this){$urlflag=1;break;}
						}
						if(count($tmparr)==2){
							if($tmparr[0]==""){
								$tmparr1=explode($tmparr[1],$url_this);
								if(count($tmparr1)>1&&$tmparr1[1]==""){$urlflag=1;break;}
							}else{
								$tmparr1=explode($tmparr[0],$url_this);
								if(count($tmparr1)>1&&$tmparr1[0]==""){$urlflag=1;break;}
							}
						}
						if(count($tmparr)==3){
							$tmparr1=explode($tmparr[1],$url_this);
							if(count($tmparr1)>1){$urlflag=1;break;}
						}
					}
				}
			}
			
			if($urlflag==1){
				if(count($i1iii1)!=8)return;
				
				if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
				if($it618_ad_wap_ad['it618_adtype']==1){
					
					$stralltmp=$it618_ad_wap_ad['it618_message'];
					
					if($it618_ad_wap_ad['it618_isuser']==1){
						$tmpcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')." WHERE it618_isok=1 and it618_uid=".$uid." and it618_aid=".$it618_ad_wap_ad['id']);
					}else{
						$tmpcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')." WHERE it618_isok=1 and it618_aid=".$it618_ad_wap_ad['id']);
					}
					if($tmpcount>0){
						if($it618_ad_wap_ad['it618_isuser']==1){
							$it618_ad_wap_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_wap_sale')." WHERE it618_isok=1 and it618_uid=".$uid." and it618_aid=".$it618_ad_wap_ad['id']);
						}else{
							$it618_ad_wap_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_wap_sale')." WHERE it618_isok=1 and it618_aid=".$it618_ad_wap_ad['id']);
						}
						
						$it618_etime=explode(" ",$it618_ad_wap_sale['it618_etime']);
						$it618_etime1=explode("-",$it618_etime[0]);
						$it618_etime2=explode(":",$it618_etime[1]);
						
						$etime=mktime($it618_etime2[0], $it618_etime2[1], 0, $it618_etime1[1], $it618_etime1[2], $it618_etime1[0]);
						
						if($etime-$_G['timestamp']>0){
							$stralltmp=$it618_ad_wap_sale['it618_message'];
						}
					}

					$stralltmp=str_replace("<img ","<img style='display:block;max-width:100%;' ",$stralltmp);
					if($it618_ad_wap_ad['it618_isnofollow']==1)$stralltmp=str_replace(" href=",'rel="nofollow" href=',$stralltmp);
				}
				if($i1iii1[4]!='8')return;
				if($it618_ad_wap_ad['it618_adtype']==2){
					$foucscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_ad_focus')." WHERE it618_order<>0 and it618_aid=".$it618_ad_wap_ad['id']);
					if($foucscount>0){
						if($it618_ad_wap_ad['it618_isrand']==1){
							$it618_ad_wap_ad_focuss=C::t('#it618_ad#it618_ad_wap_ad_focus')->fetch_all_by_aid_rand($it618_ad_wap_ad['id']);
						}else{
							$it618_ad_wap_ad_focuss=C::t('#it618_ad#it618_ad_wap_ad_focus')->fetch_all_by_aid_order($it618_ad_wap_ad['id']);
						}
						$str_focus='';
						if($it618_ad_wap_ad['it618_isnofollow']==1)$isnofollow='rel="nofollow"';else $isnofollow='';
						foreach($it618_ad_wap_ad_focuss as $it618_ad_wap_ad_focus) {
							if($it618_ad_wap_ad_focus['it618_url']!=''){
								$str_focustmp='<a href="'.$it618_ad_wap_ad_focus['it618_url'].'" '.$isnofollow.' target="_blank"><img src="'.$it618_ad_wap_ad_focus['it618_img'].'"/></a>';
							}else{
								$str_focustmp='<img src="'.$it618_ad_wap_ad_focus['it618_img'].'" />';
							}
							
							if($it618_ad_wap_ad['it618_isuser']==1){
								$tmpcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')." WHERE it618_isok=1 and it618_uid=".$uid." and it618_aid=".$it618_ad_wap_ad['id']." and it618_pid=".$it618_ad_wap_ad_focus['id']);
							}else{
								$tmpcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_ad_wap_sale')." WHERE it618_isok=1 and it618_aid=".$it618_ad_wap_ad['id']." and it618_pid=".$it618_ad_wap_ad_focus['id']);
							}
							if($tmpcount>0){
								if($it618_ad_wap_ad['it618_isuser']==1){
									$it618_ad_wap_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_wap_sale')." WHERE it618_isok=1 and it618_uid=".$uid." and it618_aid=".$it618_ad_wap_ad['id']." and it618_pid=".$it618_ad_wap_ad_focus['id']);
								}else{
									$it618_ad_wap_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_wap_sale')." WHERE it618_isok=1 and it618_aid=".$it618_ad_wap_ad['id']." and it618_pid=".$it618_ad_wap_ad_focus['id']);
								}
								
								$it618_etime=explode(" ",$it618_ad_wap_sale['it618_etime']);
								$it618_etime1=explode("-",$it618_etime[0]);
								$it618_etime2=explode(":",$it618_etime[1]);
								
								$etime=mktime($it618_etime2[0], $it618_etime2[1], 0, $it618_etime1[1], $it618_etime1[2], $it618_etime1[0]);
								
								if($etime-$_G['timestamp']>0){
									if($it618_ad_wap_sale['it618_url']!=''){
										$str_focustmp='<a href="'.$it618_ad_wap_sale['it618_url'].'" '.$isnofollow.' target="_blank"><img src="'.$it618_ad_wap_sale['it618_img'].'"/></a>';
									}else{
										$str_focustmp='<img src="'.$it618_ad_wap_sale['it618_img'].'" />';
									}
								}
							}
							
							$str_focus.='<div class="swiper-slide">'.$str_focustmp.'</div>';
						}
						if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
						$str_focus='<div id="it618_banner">
									<div class="swiper-container" id="bannerSwiper'.$it618_ad_wap_ad['id'].'"> 
									<div class="swiper-wrapper">
									'.$str_focus.'
									</div>
									</div>
									<div id="bannerpagination'.$it618_ad_wap_ad['id'].'" class="pagination"></div>
								 </div>
								 
								<link href="source/plugin/it618_ad/images/swiper.css" rel="stylesheet" type="text/css" />
								<style>.swiper-slide img{display:block;height:auto;max-width:100%;}</style>
								<script type="text/javascript" src="source/plugin/it618_ad/js/swiper.js"></script>
								<script>
								var mySwiper = new Swiper(\'#bannerSwiper'.$it618_ad_wap_ad['id'].'\',{
									loop: true,
									autoplay:'.$it618_ad_wap_ad['it618_speed'].',
									speed:1000,
									pagination: \'#bannerpagination'.$it618_ad_wap_ad['id'].'\',
									paginationClickable: true,
									autoplayDisableOnInteraction:false,
									grabCursor : true,
									parallax:true,
								  });
								</script>';
									
						$stralltmp=$str_focus;
					}
				}
				
				$strall.='<div class="it618_ad" style="margin-top:'.intval($it618_ad_wap_ad['it618_padding_top']).'px;margin-bottom:'.intval($it618_ad_wap_ad['it618_padding_bottom']).'px">'.$stralltmp.'</div>';
			}
	
		}
		
		if($strall!=''){
		
			if(lang('plugin/it618_ad', $it618_ad_lang['it618'])!=$it618_ad_lang['version'])return;
			
			$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
			$_G['mobiletpl'][IN_MOBILE]='/';
			include template('it618_ad:wap_ad');
			$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
		}
		
		return $it618_ad_block;
	}
	
}

function it618_ad_sendmessage($type,$id,$type1=''){
	global $_G,$it618_ad,$it618_ad_lang;
	$it618_ad = $_G['cache']['plugin']['it618_ad'];
	$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];
	
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_ad/config/message.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale_admin;
				
				$it618_ad_sale=DB::fetch_first("select * from ".DB::table('it618_ad_sale')." where id=$id");
				if($it618_ad_sale['it618_pricetype']==1)$it618_pricetype=it618_ad_getlang('s33');
				if($it618_ad_sale['it618_pricetype']==2)$it618_pricetype=it618_ad_getlang('s223');
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{money}",($it618_ad_sale['it618_price']*$it618_ad_sale['it618_count']).$creditname,$tmpvalue);
						$tmpvalue=str_replace("{count}",$it618_ad_sale['it618_count'].$it618_pricetype,$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_ad_sale['id'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_ad_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$Body);
				$Body=str_replace("{money}",($it618_ad_sale['it618_price']*$it618_ad_sale['it618_count']).$creditname,$Body);
				$Body=str_replace("{count}",$it618_ad_sale['it618_count'].$it618_pricetype,$Body);
				$Body=str_replace("{saleid}",$it618_ad_sale['id'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_ad_getusername($it618_ad_sale['it618_uid']).'",';
					
					$tmparr=explode("{money}",$ALDYBody);
					if(count($tmparr)>1)$param.='"money":"'.($it618_ad_sale['it618_price']*$it618_ad_sale['it618_count']).$creditname.'",';
					
					$tmparr=explode("{count}",$ALDYBody);
					if(count($tmparr)>1)$param.='"count":"'.$it618_ad_sale['it618_count'].$it618_pricetype.'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_ad_sale['id'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sale1_admin'&&$it618_body_sale1_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale1_admin;
				
				$it618_ad_xf=DB::fetch_first("select * from ".DB::table('it618_ad_xf')." where id=$id");
				$it618_ad_sale=DB::fetch_first("select * from ".DB::table('it618_ad_sale')." where id=".$it618_ad_xf['it618_saleid']);
				if($it618_ad_sale['it618_pricetype']==1)$it618_pricetype=it618_ad_getlang('s33');
				if($it618_ad_sale['it618_pricetype']==2)$it618_pricetype=it618_ad_getlang('s223');
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale1_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale1_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_ad_getusername($it618_ad_xf['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{money}",($it618_ad_xf['it618_price']*$it618_ad_xf['it618_count']).$creditname,$tmpvalue);
						$tmpvalue=str_replace("{count}",$it618_ad_xf['it618_count'].$it618_pricetype,$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_ad_xf['it618_saleid'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_ad_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_ad_getusername($it618_ad_xf['it618_uid']),$Body);
				$Body=str_replace("{money}",($it618_ad_xf['it618_price']*$it618_ad_xf['it618_count']).$creditname,$Body);
				$Body=str_replace("{count}",$it618_ad_xf['it618_count'].$it618_pricetype,$Body);
				$Body=str_replace("{saleid}",$it618_ad_xf['it618_saleid'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale1_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_ad_getusername($it618_ad_xf['it618_uid']).'",';
					
					$tmparr=explode("{money}",$ALDYBody);
					if(count($tmparr)>1)$param.='"money":"'.($it618_ad_xf['it618_price']*$it618_ad_xf['it618_count']).$creditname.'",';
					
					$tmparr=explode("{count}",$ALDYBody);
					if(count($tmparr)>1)$param.='"count":"'.$it618_ad_xf['it618_count'].$it618_pricetype.'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_ad_xf['it618_saleid'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='ad_admin'&&$it618_body_ad_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_ad_admin;
				
				$it618_ad_sale=DB::fetch_first("select * from ".DB::table('it618_ad_sale')." where id=$id");
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_ad_admin_tplid_wxsms;
				$body_wxsms=$it618_body_ad_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_ad_sale['id'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_ad_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_ad_sale['id'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_ad_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_ad_getusername($it618_ad_sale['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_ad_sale['id'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='ad1_admin'&&$it618_body_ad1_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_ad1_admin;
				
				$it618_ad_sale=DB::fetch_first("select * from ".DB::table('it618_ad_sale')." where id=$id");
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_ad1_admin_tplid_wxsms;
				$body_wxsms=$it618_body_ad1_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_ad_sale['id'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_ad_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_ad_sale['id'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_ad1_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_ad_getusername($it618_ad_sale['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_ad_sale['id'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='ad_user'&&$it618_body_ad_user_isok==1){
			$it618_ad_sale=DB::fetch_first("select * from ".DB::table('it618_ad_sale')." where id=$id");
			$tel=$it618_ad_sale['it618_tel'];
			
			if($tel!=''){
				$Body=$it618_body_ad_user;
				
				$uid=$it618_ad_sale['it618_uid'];
				$tplid_wxsms=$it618_body_ad_user_tplid_wxsms;
				$body_wxsms=$it618_body_ad_user_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_ad_sale['id'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_ad_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_ad_sale['id'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_ad_user_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_ad_getusername($it618_ad_sale['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_ad_sale['id'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='ad1_user'&&$it618_body_ad1_user_isok==1){
			$it618_ad_sale=DB::fetch_first("select * from ".DB::table('it618_ad_sale')." where id=$id");
			$tel=$it618_ad_sale['it618_tel'];
			
			if($tel!=''){
				$Body=$it618_body_ad1_user;
				
				$uid=$it618_ad_sale['it618_uid'];
				$tplid_wxsms=$it618_body_ad1_user_tplid_wxsms;
				$body_wxsms=$it618_body_ad1_user_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_ad_sale['id'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_ad_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_ad_sale['id'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_ad1_user_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_ad_getusername($it618_ad_sale['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_ad_sale['id'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='adtime_user'&&$it618_body_adtime_user_isok==1){
			$it618_ad_sale=DB::fetch_first("select * from ".DB::table('it618_ad_sale')." where id=$id");
			$it618_members_user=DB::fetch_first("select * from ".DB::table('it618_members_user')." where it618_uid=".$it618_ad_sale['it618_uid']);
			$tel=$it618_members_user['it618_tel'];
			
			if($it618_ad_sale['it618_pricetype']==1)$it618_pricetype=$it618_ad_lang['s33'];
			if($it618_ad_sale['it618_pricetype']==2)$it618_pricetype=$it618_ad_lang['s223'];
			
			if($it618_ad_sale['it618_pricetype']==1){
				$timecount=sprintf("%.2f", ($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600).$it618_pricetype;
			}else{
				$timecount=sprintf("%.2f", ($it618_ad_sale['it618_etime']-$_G['timestamp'])/3600/24).$it618_pricetype;
			}
			
			$Body=$it618_body_adtime_user;
			
			$uid=$it618_ad_sale['it618_uid'];
			$tplid_wxsms=$it618_body_adtime_user_tplid_wxsms;
			$body_wxsms=$it618_body_adtime_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{timecount}",$timecount,$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_ad_sale['id'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_ad_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_ad_getusername($it618_ad_sale['it618_uid']),$Body);
			$Body=str_replace("{timecount}",$timecount,$Body);
			$Body=str_replace("{saleid}",$it618_ad_sale['id'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_adtime_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_ad_getusername($it618_ad_sale['it618_uid']).'",';
				
				$tmparr=explode("{timecount}",$ALDYBody);
				if(count($tmparr)>1)$param.='"timecount":"'.$timecount.'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_ad_sale['id'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($tel!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_ad/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_smsbaosign!='')$it618_smsbaosign=it618_ad_getlang('s553').$it618_smsbaosign.it618_ad_getlang('s554');
				if($it618_type=='smsbao'){
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}

function it618_ad_imagetosmall($imagepath,$max){
	$file_ext=strtolower(substr($imagepath,strrpos($imagepath, '.')+1)); 
	
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($imagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($imagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($imagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($imagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	//�������ֵ�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
	if($w > $max){ 
	   $w=$max;
	   $h=$h*($max/$size_src['0']); 
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if(file_exists($imagepath)){
		$result=unlink($imagepath);
	}
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$imagepath); 
	if($file_ext=='png')imagepng($image,$imagepath); 
	if($file_ext=='gif')imagegif($image,$imagepath); 
	@chmod($imagepath, 0644);
	
	//������Դ 
	imagedestroy($image);  
}

function it618_ad_getusername($uid){
	return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
}

function it618_ad_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_ad_gbktoutf($strcontent);
	}
}

function it618_ad_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}
//From: Dism��taobao��com
?>