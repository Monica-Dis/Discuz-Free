<?php
  /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_ad = $_G['cache']['plugin']['it618_ad'];
$creditname=$_G['setting']['extcredits'][$it618_ad['ad_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_ad/lang.func.php';

$uid = $_G['uid'];

if($uid<=0){
	showmessage(it618_ad_getlang('s250'), '', array(), array('alert' => 'error'));	
}else{
	$saleid=intval($_GET['saleid']);
	
	if($it618_ad_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_ad_sale')." where id=".$saleid)){
		if(isset($_GET['admin'])){
			$urladmin='&admin';
			$ad_adminuid=explode(",",$it618_ad['ad_adminuid']);
			if(!in_array($_G['uid'],$ad_adminuid)){
				showmessage(it618_ad_getlang('s364'), '', array(), array('alert' => 'info'));
			}
		}else{
			if($it618_ad_sale['it618_uid']!=$_G['uid']){
				showmessage(it618_ad_getlang('s251'), '', array(), array('alert' => 'info'));
			}
		}
	}else{
		showmessage(it618_ad_getlang('s60'), '', array(), array('alert' => 'info'));
	}
	
	if($it618_ad_sale['it618_pricetype']==1)$it618_pricetype=it618_ad_getlang('s33');
	if($it618_ad_sale['it618_pricetype']==2)$it618_pricetype=it618_ad_getlang('s223');
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_ad_xf')." where it618_saleid=$saleid order by id desc");
	while($it618_ad_xf = DB::fetch($query)) {
		$count=$count+1;
		$sumcount=$sumcount+$it618_ad_xf['it618_count'];
		$sum=$sum+$it618_ad_xf['it618_price']*$it618_ad_xf['it618_count'];
		$xfstr.='<tr><td width="120"><font color="red">'.$it618_ad_xf['it618_price'].'</font> '.$creditname.'/'.$it618_pricetype.'</td><td width="90"><font color="red">'.$it618_ad_xf['it618_count'].'</font> '.$it618_pricetype.'</td><td><font color="red">'.($it618_ad_xf['it618_price']*$it618_ad_xf['it618_count']).'</font> '.$creditname.'</td><td width="135"><font color="#999">'.date('Y-m-d H:i:s', $it618_ad_xf['it618_buytime']).'</font></td></tr>';
	}
	
	$xfsum=it618_ad_getlang('s252').'<font color="red">'.$count.'</font> '.it618_ad_getlang('s254').'<font color="red">'.$sumcount.'</font> '.it618_ad_getlang('s253').'<font color="red">'.$sum.'</font>';
}

include template('it618_ad:showxf');
?>