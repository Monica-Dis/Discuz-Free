<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_chat;

$it618_chat = $_G['cache']['plugin']['it618_chat'];
require_once DISCUZ_ROOT.'./source/plugin/it618_chat/lang.func.php';

function it618_chat_getchaturl($plugin,$pagetype,$pid){
	if($plugin=='it618_video'){
		global $it618_video_lang;
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
		
		if($pagetype=='product'){
			
			if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
				echo it618_video_getlang('s470');exit;
			}
			
			$pj=$it618_video_goods['it618_pjpfstr'];
		
			$it618_isvip='';
			$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" class="imgvip">';
			}
			
			$it618_islive='';
			if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
				$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
			}
			
			$pricestr='<span style="color:#f30">'.$it618_video_lang['s1534'].'</span>';
			$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
			if($it618_video_shop['it618_issale']==1){
				if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
					$pricestr='<span style="color:#f30">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span style="color:#390">'.$it618_video_lang['s106'].'</span>';
				}
			}
			if($it618_video_goods['it618_price']>0){
				$pricestr.=' <del>&yen;'.$it618_video_goods['it618_price'].'</del>';
			}
			
			$jfbl='';
			if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
				$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}
	
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);

			$chaturlstr='<a href="'.$tmpurl.'" target="_blank" class="'.$plugin.'_achatgoodsurl"><table>
						<tr>
						  <td class="tdleft">'.$jfbl.'<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'"/></td>
						  <td class="tdright">
							  <div class="tdname">'.$it618_video_goods['it618_name'].'</div>
							  <div class="tddes">'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).' '.$it618_video_goods['it618_plays'].it618_video_getlang('s931').'</div>
							  <div class="tdprice">'.$it618_isvip.$pricestr.'</div>
						  </td>
						</tr>
						</table></a>';
		}
	}
	
	if($plugin=='it618_exam'){
		global $it618_exam_lang;
		require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
		
		if($pagetype=='product'){
			
			if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
				echo it618_exam_getlang('s470');exit;
			}
			
			$pj=$it618_exam_goods['it618_pjpfstr'];
		
			$it618_isvip='';
			$vipgroupids=it618_exam_getgoodsvipgroupids($it618_exam_goods);
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_exam/images/vip.png" class="imgvip">';
			}
			
			if($it618_exam_goods['it618_saleprice']>0||$it618_exam_goods['it618_score']>0){
				$pricestr='<span style="color:#f30">'.it618_exam_getgoodsprice($it618_exam_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span style="color:#390">'.$it618_exam_lang['s106'].'</span>';
			}
			
			if($it618_exam_goods['it618_price']>0){
				$pricestr.=' <del>&yen;'.$it618_exam_goods['it618_price'].'</del>';
			}
			
			$jfbl='';
			if($it618_exam_goods['it618_jfbl']>0&&$it618_exam_goods['it618_saleprice']>0){
				if(C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($it618_exam_goods['id'])>0){
					$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].str_replace(".00","",$it618_exam_goods['it618_jfbl']).'%'.$creditname.'</div>';
				}else{
					$jfbl='<div class="divjfbl">'.$it618_exam_lang['s1371'].intval($it618_exam_goods['it618_saleprice']*$it618_exam_goods['it618_jfbl']/100).$creditname.'</div>';
				}
			}
			
			$tmpurl=it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);

			$chaturlstr='<a href="'.$tmpurl.'" target="_blank" class="'.$plugin.'_achatgoodsurl"><table>
						<tr>
						  <td class="tdleft">'.$jfbl.'<img src="'.it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']).'"/></td>
						  <td class="tdright">
							  <div class="tdname">'.$it618_exam_goods['it618_name'].'</div>
							  <div class="tddes">'.$it618_exam_lang['s819'].$it618_exam_goods['it618_questioncount'].$it618_exam_lang['s820'].' '.$it618_exam_goods['it618_tests'].it618_exam_getlang('s931').'</div>
							  <div class="tdprice">'.$it618_isvip.$pricestr.'</div>
						  </td>
						</tr>
						</table></a>';
		}
	}
	
	if($plugin=='it618_brand'){
		global $it618_brand_lang;
		require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
		
		if($pagetype=='product'){
			
			if(!($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid))){
				echo it618_brand_getlang('s550');exit;
			}else{
				if($it618_brand_goods['it618_ison']!=1||$it618_brand_goods['it618_state']!=1){echo it618_brand_getlang('s550');exit;}
			}
			
			$jfblstr='';
			if($it618_brand_goods['it618_saletype']==6){
				$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
				$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
				$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
			}
			
			$jfbl='';
			if($jfblstr!=''){
				$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
			}
		
			$it618_count=$it618_brand_lang['s1652'].' '.$it618_brand_goods['it618_count'].' ';
			
			if($it618_brand_goods['it618_isalipay']==1){
				$pricestr='<strong><span>&yen;</span>'.$it618_brand_goods['it618_uprice'].'</strong>
						  <del>&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
			}else{
				$pricestr='<strong class="jfprice">'.$it618_brand_goods['it618_score'].'<span>'.$creditname.'</span></strong>';
			}
			
			$salecount=$it618_brand_goods['it618_salecount'];
			
			$salecount=' '.it618_brand_getlang('s716').''.$salecount;
			if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
				$pricestr='<strong class="noprice">'.$it618_brand_lang['s761'].'</strong>';
				$jfblstr=$it618_brand_lang['s1732'];
				$salecount='<span class="trfl">'.it618_brand_getlang('t474').''.$it618_brand_goods['it618_views'].'</span>';
			}
			
			$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);

			$chaturlstr='<a href="'.$tmpurl.'" target="_blank" class="'.$plugin.'_achatgoodsurl"><table>
						<tr>
						  <td class="tdleft">'.$jfbl.'<img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/></td>
						  <td class="tdright">
							  <div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
							  <div class="tddes">'.$it618_count.' '.$pj.' '.$salecount.'</div>
							  <div class="tdprice">'.$pricestr.'</div>
						  </td>
						</tr>
						</table></a>';
		}
	}
	
	if($plugin=='it618_tuan'){
		global $it618_tuan_lang;
		require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
		
		if($pagetype=='product'){
			
			if(!($it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id_state($pid,1))){
				echo it618_tuan_getlang('s470');exit;
			}
			
			$pj=$it618_tuan_goods['it618_pjpfstr'];
		
			$jfbl='';
			if($it618_tuan_goods['it618_jfbl']>0&&$it618_tuan_goods['it618_saleprice']>0){
				if(C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($it618_tuan_goods['id'])>0){
					$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').str_replace(".00","",$it618_tuan_goods['it618_jfbl']).'%'.$creditname.'</div>';
				}else{
					$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').intval($it618_tuan_goods['it618_saleprice']*$it618_tuan_goods['it618_jfbl']/100).$creditname.'</div>';
				}
			}
			
			$salecount=$it618_brand_goods['it618_salecount'];
			
			$salecount=' '.it618_tuan_getlang('s547').''.$salecount;
			$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
			
			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);

			$chaturlstr='<a href="'.$tmpurl.'" target="_blank" class="'.$plugin.'_achatgoodsurl"><table>
						<tr>
						  <td class="tdleft">'.$jfbl.'<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/></td>
						  <td class="tdright">
							  <div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
							  <div class="tddes">'.$pj.' '.$views.' '.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</div>
							  <ul class="tdprice">
								<li>
								<strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong>
								</li>
							  </ul>
						  </td>
						</tr>
						</table></a>';
		}
	}
	
	return 'it618_splitchatgoodsurlokit618_split'.$chaturlstr;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>