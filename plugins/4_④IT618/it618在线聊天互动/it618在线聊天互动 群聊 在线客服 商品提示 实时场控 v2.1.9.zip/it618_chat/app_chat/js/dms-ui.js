﻿var swiper = null;
var tis_perty_ui = function () {
    var tisApp, temp;
    function onInitUI(container,options) {
        var tmphtml='';
		if(iswap!=1){
			tmphtml='<textarea class="tis-sendText" placeholder="发送:Ctrl+Enter 换行:Enter"></textarea>';
		}else{
			tmphtml='<textarea class="tis-sendText"></textarea>';	
		}
		var tis_html =
        '<div class="tis-top-bar">\
           <span class="tis-top-total"></span><span class="tis-top-name"></span>\
        </div>\
		<div class="tis-center-box">\
            <div class="tis-msgs-panel"></div>\
            <div class="tis-tools-panel" style="display:none">\
                <div class="tis-tools-panel disableSelect">\
                    <div class="tis-faces-box">\
                        <div class="tis-faces-swiper">\
                            <div class="swiper-wrapper"><div class="swiper-slide"></div></div>\
                            <div class="swiper-pagination"></div>\
                        </div>\
                        <div class="tis-facegroups"></div>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div class="tis-bottom-panel">\
			<table width="100%"><tr>\
			<td id="tdface">\
            <div class="tis-tools-bar">\
                <a class="tis-face-btn"></a>\
            </div>\
			</td>\
			<td id="tdsendtext">\
            <div class="tis-sendText-wrap">\
                '+tmphtml+'</div>\
			</td>\
			<td id="tdbtn">\
            <a class="tis-sendBtn">发送</a>\
			</td>\
			</tr></table>\
        </div>';
        $(container).html(tis_html);
		$(".tis-top-name").html(options.name+nametmp);
        $(".tis-center-box").height(
                $(".tis-container").height() - $(".tis-top-bar").height() - $(".tis-bottom-panel").height());

		$(".tis-msgs-panel").height($(".tis-msgs-panel").parent().height());
		$(".tis-msgs-panel").scrollTop($(".tis-msgs-panel")[0].scrollHeight);
        $(".tis-msgs-panel").parent().scrollTop($(".tis-msgs-panel").parent()[0].scrollHeight);
		
        function hideToolPanel() {
            $(".tis-msgs-panel").height($(".tis-msgs-panel").parent().height());
            $(".tis-tools-panel").hide();
            $(".tis-msgs-panel").scrollTop($(".tis-msgs-panel")[0].scrollHeight);
            $(".tis-msgs-panel").parent().scrollTop($(".tis-msgs-panel").parent()[0].scrollHeight);
			$(".tis-face-btn").css("background", "url(source/plugin/it618_chat/app_chat/css/faceico0.png) no-repeat 0px 0px");
        }
        function showToolPanel() {
            if ($(".tis-tools-panel").parent().height() > 180) {
                $(".tis-msgs-panel").height($(".tis-tools-panel").parent().height() - 180);
                $(".tis-tools-panel").css("height", "180px");
            } else {
                $(".tis-msgs-panel").height(0);
                $(".tis-tools-panel").height($(".tis-tools-panel").parent().height());
            }
            $(".tis-tools-panel").show();
			$(".tis-face-btn").css("background", "url(source/plugin/it618_chat/app_chat/css/faceico1.png) no-repeat 0px 0px");
        }
        $(".tis-tools-bar a").click(function (e) {
            if ($(".tis-tools-panel").css("display") == "none") {
                showToolPanel();
            } else {
                hideToolPanel();
            }
            if (!swiper) {
                swiper = new Swiper('.tis-faces-swiper', {
                    pagination: '.swiper-pagination',
                    paginationClickable: true
                });
                if ($(container + " .tis-facegroups").children().length > 0) {
                    $(container + " .tis-facegroups").children()[0].click();
                }
            }
        });
        $(container + " .tis-sendText").mousedown(hideToolPanel);
        function sendMessage() {
            tisApp = tisApp ? tisApp : window.tis;
            hideToolPanel();
            var sendText = $(container + " .tis-sendText").val();
			if (sendText.length ==0) {
                alert("抱歉，请输入发送内容！");
                return;
            }
            if (sendText.length > 1000) {
                alert("抱歉，发送内容太长啦！");
                return;
            }
			if(forbidwords!=''){
				var words=forbidwords.split("|");
				for(var i=0;i<words.length;i++){
					sendText=sendText.replace(new RegExp(words[i],'ig'),'*');
				}
			}
            tisApp.SendMessage(sendText+"\n"+chatip);
            $(container + " .tis-sendText").val("")
        }
        $(container + " .tis-sendText").keydown(function (e) {
            if (e == null || e.keyCode == null || e.ctrlKey == null) return;
	
			if (e.keyCode == 13&&e.ctrlKey) {
                e.preventDefault();
                sendMessage();
            }
        });
        $(container + " .tis-sendBtn").click(sendMessage);
    }
	
	Date.prototype.format = function (format) {
           var args = {
               "M+": this.getMonth() + 1,
               "d+": this.getDate(),
               "h+": this.getHours(),
               "m+": this.getMinutes(),
               "s+": this.getSeconds(),
               "q+": Math.floor((this.getMonth() + 3) / 3),  //quarter
               "S": this.getMilliseconds()
           };
           if (/(y+)/.test(format))
               format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
           for (var i in args) {
               var n = args[i];
               if (new RegExp("(" + i + ")").test(format))
                   format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? n : ("00" + n).substr(("" + n).length));
           }
           return format;
       };

    function appendTisMessage(msgBox, data, faceMap, isHistory) {
        if (msgBox.children().length >= temp.maxMesageNum) {
            msgBox.children().eq(0).remove();
        }
		var tmparr=data.body.split("it618cmd");
		if(tmparr.length>1){
			return;
		}
		var tmparr=data.body.split("it618clientuser");
		if(tmparr.length>1){
			if(isHistory==1){
				//console.log("xczxcxzc:", data);
				return;
			}else{
				data.body=tmparr[1];
			}
		}
		
		var tmparr=data.body.split("it618chatgoodsurl");
		if(tmparr.length>1){
			//console.log("xczxcxzc:", data);
			data.body='<div id="chatgoodsurl'+data.time+'"><img src="source/plugin/it618_chat/images/loading.gif"></div>';
			if ( IT618_CHAT("#"+"chatgoodsurl"+data.time).length > 0 ) {
				return;
			}
			getchatgoodsurl1(tmparr[1],'chatgoodsurl'+data.time);
		}
		
        for (var item in faceMap) {
            data.body = data.body.replace(new RegExp("\\" + item, "g"), "<img src='" + faceMap[item] + "'/>");
        }
        var timestr;
        if(data.time) {
			var date1 = new Date();
			var date2 = new Date(data.time*1000);
			if(date1.getDate()>date2.getDate()){
				var timestr=new Date(data.time*1000).format("yyyy-MM-dd hh:mm:ss");
			}else{
				var timestr=new Date(data.time*1000).format("hh:mm:ss");
			}
        }
		//timestr=data.time;
        var headimg = $("<img src='" + (!!data.image ? data.image : "source/plugin/it618_chat/images/anonymous.png") + "'/>");
        var namelabel = $("<span class='tis-msg-name'>" + data.name + " <span class='tis-msg-time'>" + timestr +"</span></span>");
        var timelabel = $("<span></span>");
        var div = $("<div class='tis-msg-head'></div>").append(headimg).append(namelabel).append(timelabel);
        if (msgBox.width() < 180) {
            namelabel.width(msgBox.width() - 10 - 8 - 32 - 10);
            timelabel.html("");
        } else {
            namelabel.width(msgBox.width() - 10 - 8 - 32 - 55 - 10);
        }
        msgBox.append($("<a></a>").append(div).append("<div class='tis-msg-body'><i></i>" + data.body + "</div>"));
		$(".tis-msgs-panel a .tis-msg-body").css('max-width',($(".tis-msgs-panel").width()-80)+'px');
        if ($(".tis-tools-panel").css("display") != "none") {
            showToolPanel();
        } else {
            msgBox.height(msgBox.parent().height());
        }
        msgBox.scrollTop(msgBox[0].scrollHeight);
        msgBox.parent().scrollTop(msgBox.parent()[0].scrollHeight);
    }
    function onReceiveMessage(data, container, faceMap) {
        var msglist = $(container + " .tis-msgs-panel");
        appendTisMessage(msglist, data, faceMap,0);
		//console.log("xczxcxzc:", data);
		var tmparr=data.body.split("it618cmd");
		if(tmparr.length>1){
			var cmdtype=tmparr[1];
			var cmdvalue=tmparr[2];
			if(cmdkey==tmparr[3]){
				if(cmdtype=="onlinecount"){
					onlinecount=cmdvalue;
					getonlinetotal(onlinetotal,0);
				}
				if(cmdtype=="chatusers"){
					if(cmdvalue==1){
						ischatusers=1;
						$("#chatusersimg").show();
					}else{
						ischatusers=0;
						if(adminpower==0)$("#chatusersimg").hide();
					}
				}
				
				if(cmdtype=="alljy"||cmdtype=="alldeljy"){
					if(cmdtype=="alljy"){
						if(adminpower==0)$("#alljydiv").show();
					}
					if(cmdtype=="alldeljy"){
						$("#alljydiv").hide();
					}
					if(adminpower==1)getuseronline(clientidtmp,1);
				}
				if(cmdtype=="jy"||cmdtype=="deljy"||cmdtype=="pb"||cmdtype=="delpb"||cmdtype=="admin"||cmdtype=="deladmin"){
					if(clientidtmp==cmdvalue){
						if(cmdtype=="jy"){
							$("#jydiv").show();
						}
						if(cmdtype=="deljy"){
							$("#jydiv").hide();
						}
						if(cmdtype=="pb"){
							location.reload();
						}
						if(cmdtype=="admin"){
							$("#chatusersimg").show();
						}
						if(cmdtype=="deladmin"){
							if(ischatusers==0)$("#chatusersimg").hide();
						}
					}
					getuseronline(clientidtmp,1);
				}
			}
		}else{
			if(data.name!=chatname)chataudio.play();	
		}
    }
    function onLoadHistory(data, container, faceMap , opts) {
        var msglist = $(container + " .tis-msgs-panel");
        var list = data.list;
        var length = 0;
        if (list) {
            length = list.length;
        }
		
        for (var index = length - 1; index >= 0; --index) {
            var item = list[index];
			//console.log("xczxcxzc:", item);
            if (!item.msg) continue;
            var msgdata;
            try {
                msgdata = JSON.parse(item.msg);
                msgdata = opts.prepareMessage(msgdata);
                appendTisMessage(msglist, msgdata, faceMap,1);
            } catch (ex) { }
        }
		
		$(".tis-msgs-panel").height($(".tis-msgs-panel").parent().height());
		$(".tis-msgs-panel").scrollTop($(".tis-msgs-panel")[0].scrollHeight);
        $(".tis-msgs-panel").parent().scrollTop($(".tis-msgs-panel").parent()[0].scrollHeight);
    }
    function onLoadGroup(data, container, groupClicked) {
        var groups = $(container + " .tis-facegroups");
        for (var index in data) {
            var item = data[index];
            var group = $('<a gid="' + item.id + '" ><img src="' + item.icon + '" /></a>');
            group.click(function () {
                $(container + " .swiper-wrapper").html("");
            });
            group.click(groupClicked);
            groups.append(group);
        }
    }
    function onLoadFaces(keys, faceMap, container, groupId) {
        var i = 0, pageSize = 32;
        var pagePanel = $(container + " .swiper-wrapper").append('<div class="swiper-slide"></div>').children().last();
        for (var index = 0; index < keys.length; index++) {
            var item = keys[index];
			
            pagePanel.append($("<a text='" + item + "'><img src='" + faceMap[item] + "' /></a>").click(function () {
                var sendText = $(container + " .tis-sendText");
                sendText.val(sendText.val() + $(this).attr("text"));
            }));
            if (++i >= pageSize) {
                i = 0;
                pagePanel = $(container + " .swiper-wrapper").append('<div class="swiper-slide"></div>').children().last();
            }
        }
        for (; i < pageSize; i++) {
            pagePanel.append("<a class='noneFace'></a>");
        }
        swiper.swipeTo(0, 0, false);
        swiper.reInit();
    }
    temp = {
        onInitUI: onInitUI,               //必须，在这个时机去初始化界面
        onLoadHistory: onLoadHistory,          //可选，加载历史消息时调用，不填则不加载
        onLoadGroup: onLoadGroup,            //加载分组完毕时调用
        onLoadFaces: onLoadFaces,            //加载表情完毕时调用
        onReceiveMessage: onReceiveMessage,         //收到消息时调用
        onPreSendMessage: function (msg) { return true },         //发送消息之前调用
        setTisApp: function (_tisApp) {
            tisApp = _tisApp;
        },
        historyPageSize: 30,                        //加载历史消息的条数
        maxMesageNum: 30,
        version: 1.2                                //模版版本
    }
    return temp;
}();