<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_chat_lang;

function it618_chat_getlang($langid){
	global $it618_chat_lang;
	return $it618_chat_lang[$langid];
}

$it618_chat_lang['version']='v2.1.9';
$it618_chat_lang['s1'] = '抱歉，请先登录会员！';
$it618_chat_lang['s2'] = '群聊管理';
$it618_chat_lang['s3'] = '群聊说明';
$it618_chat_lang['s4'] = '参数错误';
$it618_chat_lang['s5'] = '抱歉，请先添加表情分组！';
$it618_chat_lang['s6'] = '启用';
$it618_chat_lang['s7'] = '编号';
$it618_chat_lang['s8'] = '群聊数：';
$it618_chat_lang['s9'] = '注意：如果不勾选“必须登录”，表示所有人包括访客也可以群聊，每个群聊的独立超级管理员是对插件设置默认的超级管理员进行补充';
$it618_chat_lang['s10'] = '提示：奥点云的某个DMS实例';
$it618_chat_lang['s11'] = '聊天接口设置';
$it618_chat_lang['s12'] = '奥点云DMS安全信息sub_key';
$it618_chat_lang['s13'] = '奥点云DMS安全信息s_key';
$it618_chat_lang['s14'] = '设置项';
$it618_chat_lang['s15'] = '说明';
$it618_chat_lang['s16'] = '设置值';
$it618_chat_lang['s17'] = '抱歉，您还没有此课程学习权限，不能参与聊天互动！';
$it618_chat_lang['s18'] = '抱歉，此课程视频还没有开通聊天功能，请与管理员联系！';
$it618_chat_lang['s19'] = '访问群聊';
$it618_chat_lang['s20'] = '抱歉，此课程视频不存在！';
$it618_chat_lang['s21'] = '抱歉，此群聊不存在或未开通，请与管理员联系！';
$it618_chat_lang['s22'] = '群聊名称';
$it618_chat_lang['s23'] = '表情管理';
$it618_chat_lang['s24'] = '表情分组管理';
$it618_chat_lang['s25'] = '表情图片管理';
$it618_chat_lang['s26'] = '分组数：';
$it618_chat_lang['s27'] = '抱歉，参数有误！';
$it618_chat_lang['s28'] = '表情数：';
$it618_chat_lang['s29'] = '分组名称';
$it618_chat_lang['s30'] = '分组图片';
$it618_chat_lang['s31'] = '分组排序';
$it618_chat_lang['s32'] = '表情名称';
$it618_chat_lang['s33'] = '更新成功！(成功修改数:';
$it618_chat_lang['s34'] = '成功添加数:';
$it618_chat_lang['s35'] = '成功删除数:';
$it618_chat_lang['s36'] = '聊天接口设置更新成功！';
$it618_chat_lang['s37'] = '表情图片';
$it618_chat_lang['s38'] = '表情排序';
$it618_chat_lang['s39'] = '查找';
$it618_chat_lang['s40'] = '按名称';
$it618_chat_lang['s41'] = '上传图片';
$it618_chat_lang['s42'] = '提交后再上传图片';
$it618_chat_lang['s43'] = '表情数';
$it618_chat_lang['s44'] = '表情分组';
$it618_chat_lang['s45'] = '网络用语屏蔽关键字';
$it618_chat_lang['s46'] = '多个关键字用|隔开，如：123|456|789';
$it618_chat_lang['s47'] = '必须登录';
$it618_chat_lang['s48'] = '显示IP';
$it618_chat_lang['s49'] = '显示城市';
$it618_chat_lang['s50'] = '聊天禁用语设置';
$it618_chat_lang['s51'] = '显示聊天者IP';
$it618_chat_lang['s52'] = '显示聊天者城市';
$it618_chat_lang['s53'] = '此设置用于视频学院对接等，群聊独立设置的';
$it618_chat_lang['s54'] = '人';
$it618_chat_lang['s55'] = '会员';
$it618_chat_lang['s56'] = '进入我的客户中心>>';
$it618_chat_lang['s57'] = '客服类别管理';
$it618_chat_lang['s58'] = '客服人员管理';
$it618_chat_lang['s59'] = '商家客服数';
$it618_chat_lang['s60'] = '类别数：';
$it618_chat_lang['s61'] = '提示：如果插件客服状态没开启，那么商家后台是没有客服功能的，如果开启商家可以添加管理自己的客服人员';
$it618_chat_lang['s62'] = '现在登录';
$it618_chat_lang['s63'] = '状态';
$it618_chat_lang['s64'] = '运行中';
$it618_chat_lang['s65'] = '未安装';
$it618_chat_lang['s66'] = '未开启';
$it618_chat_lang['s67'] = '类别名称';
$it618_chat_lang['s68'] = '操作(插件设置的是非商家页面客服)';
$it618_chat_lang['it618'] = 'i11iiiilll1ililllilill1ililil11111ililili1l1l1lilili1lilililliilil1lllll111ilili1ilili11il111lili111iililili1111111il111lilii111ill';
$it618_chat_lang['s69'] = '电脑版顶边距：';
$it618_chat_lang['s70'] = '电脑版宽度：';
$it618_chat_lang['s71'] = '电脑版颜色：';
$it618_chat_lang['s72'] = '手机版图标颜色：';
$it618_chat_lang['s73'] = '设置项';
$it618_chat_lang['s74'] = '设置值';
$it618_chat_lang['s75'] = '说明';
$it618_chat_lang['s76'] = '返回客服类别管理';
$it618_chat_lang['s77'] = '更新';
$it618_chat_lang['s78'] = '抱歉，您没有权限进入此群聊，请与管理员联系！';
$it618_chat_lang['s79'] = '';
$it618_chat_lang['s80'] = '论坛';
$it618_chat_lang['s81'] = '学院';
$it618_chat_lang['s82'] = '商盟';
$it618_chat_lang['s83'] = '商城';
$it618_chat_lang['s84'] = '客服样式';
$it618_chat_lang['s85'] = '自定义内容';
$it618_chat_lang['s86'] = '客服人员';
$it618_chat_lang['s87'] = '共用jquery页面特征：';
$it618_chat_lang['s88'] = '有时有的电脑版模板自带了jquery，可能会和插件的jquery冲突，注意：99%的站都不需要填写此设置，这个功能用于有显示论坛页脚的页面，不填写表示所有这样的页面都调用，如果不想某页面调用本插件的jquery，可以设置此页面的链接特征，多个特征用|隔开，注意：如果页面链接直接是域名的首页，链接特征用@代替 如：portal|forum|@';
$it618_chat_lang['s89'] = '客服样式更新成功！';
$it618_chat_lang['s90'] = '开启选中类别';
$it618_chat_lang['s91'] = '不开启选中类别';
$it618_chat_lang['s92'] = '确定要开启选中类别？如果插件未安装是不能开启的！';
$it618_chat_lang['s93'] = '确定不开启选中类别？这样前台或商家后台的客服功能不会显示！';
$it618_chat_lang['s94'] = '全选';
$it618_chat_lang['s95'] = '成功开启类别数：';
$it618_chat_lang['s96'] = '成功不开启类别数：';
$it618_chat_lang['s97'] = '标题';
$it618_chat_lang['s98'] = '内容(支持HTML代码)';
$it618_chat_lang['s99'] = '排序';
$it618_chat_lang['s100'] = '提示：为了美观请不要同时显示很多自定义内容，排序值小于10的显示在客服人员上面，大于10的显示在客服人员下面，排序为0时不显示';
$it618_chat_lang['s101'] = '内容数：';
$it618_chat_lang['s102'] = '比如：工作时间，热线电话等';
$it618_chat_lang['s103'] = '提示：客服人员可以自由绑定会员uid，已绑定客服人员的会员会有客服中心功能，如果设置不在线，前台在线客服不会显示';
$it618_chat_lang['s104'] = '客服数：';
$it618_chat_lang['s105'] = '头像';
$it618_chat_lang['s106'] = '昵称';
$it618_chat_lang['s107'] = '绑定会员uid';
$it618_chat_lang['s108'] = '手机号码';
$it618_chat_lang['s109'] = '按关键词';
$it618_chat_lang['s110'] = '客服类别';
$it618_chat_lang['s111'] = '全部类别';
$it618_chat_lang['s112'] = '状态';
$it618_chat_lang['s113'] = '上线';
$it618_chat_lang['s114'] = '下线';
$it618_chat_lang['s115'] = '全部';
$it618_chat_lang['s116'] = '查找';
$it618_chat_lang['s117'] = '提示：聊天记录是和客服ID绑定的，和会员没关系，如果会员和客服绑定了，那么这个会员就可以看绑定的客服记录';
$it618_chat_lang['s118'] = '客服类别';
$it618_chat_lang['s119'] = '所属商家';
$it618_chat_lang['s120'] = '客服ID';
$it618_chat_lang['s121'] = '客服人员分组标题：';
$it618_chat_lang['s122'] = '这个分组标题显示在客服人员上面的';
$it618_chat_lang['s123'] = '和 ';
$it618_chat_lang['s124'] = ' 会话';
$it618_chat_lang['s125'] = '抱歉，客服功能未开启，请与管理员联系！';
$it618_chat_lang['s126'] = '抱歉，当前客服人员未上线！';
$it618_chat_lang['s127'] = '抱歉，当前客服是您本人！';
$it618_chat_lang['s128'] = '抱歉，您不是此会话的客服人员！';
$it618_chat_lang['s129'] = '网友';
$it618_chat_lang['s130'] = '是';
$it618_chat_lang['s131'] = '否';
$it618_chat_lang['s132'] = '咨询人数';
$it618_chat_lang['s133'] = '我的客服中心';
$it618_chat_lang['s134'] = '抱歉，您还没有成为客服人员！';
$it618_chat_lang['s135'] = '我的客户类别';
$it618_chat_lang['s136'] = '，您已进入了客服中心，不能重复进入！';
$it618_chat_lang['s137'] = '确定要关闭客服中心？如果有已接入的会话也会退出！';
$it618_chat_lang['s138'] = ' 您正在和';
$it618_chat_lang['s139'] = '会话';
$it618_chat_lang['s140'] = '电脑端';
$it618_chat_lang['s141'] = '移动端';
$it618_chat_lang['s142'] = '手机版图标位置：';
$it618_chat_lang['s143'] = '手机版图标边距：';
$it618_chat_lang['s144'] = '手机版图标底距：';
$it618_chat_lang['s145'] = '左边';
$it618_chat_lang['s146'] = '右边';
$it618_chat_lang['s147'] = '修改以上客服类别';
$it618_chat_lang['s148'] = '类别名称修改成功！';
$it618_chat_lang['s149'] = '黑名单';
$it618_chat_lang['s150'] = '客服管理';
$it618_chat_lang['s151'] = '自定义内容';
$it618_chat_lang['s152'] = '客服人员管理';
$it618_chat_lang['s153'] = '点击切换 客服类别/会话窗口';
$it618_chat_lang['s154'] = '抱歉，您还没有和客户接入，现在还没有会话窗口！';
$it618_chat_lang['s155'] = '消息提醒设置';
$it618_chat_lang['s156'] = '微信消息';
$it618_chat_lang['s157'] = '未安装';
$it618_chat_lang['s158'] = '未绑定';
$it618_chat_lang['s159'] = '未关注';
$it618_chat_lang['s160'] = '说明：微信消息 未安装：表示微信消息接口需要的 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a> 还未安装 ，未绑定：表示会员插件的微信会员还没有此会员 ， 未关注：表示此会员还没有关注微信号 ， 正常：表示此会员可以接收微信消息';
$it618_chat_lang['s161'] = '正常';
$it618_chat_lang['s162'] = '说明：微信消息 未安装：表示微信消息接口需要的插件还未安装 ，未绑定：表示会员插件的微信会员还没有此会员 ， 未关注：表示此会员还没有关注微信号 ， 正常：表示此会员可以接收微信消息';
$it618_chat_lang['s163'] = '如果客服人员不在线，有会话时，会优先发送微信消息提醒，如果微信消息不能发送成功，会再发送短信消息的，推荐微信消息，这样提醒后可以直接点击微信消息链接直达自己的客服中心';
$it618_chat_lang['s164'] = '抱歉，客服人员已屏蔽您的会员uid，当前会员已不能与客服人员会话，请与管理员联系！';
$it618_chat_lang['s165'] = '抱歉，您所在的用户组没有会话权限，请与管理员联系！';
$it618_chat_lang['s166'] = '电脑版图标风格：';
$it618_chat_lang['s167'] = '手机版图标风格：';
$it618_chat_lang['s168'] = '1表示QQ风格、2表示笑脸风格 如果想自己搞图标，可以在source/plugin/it618_chat/images目录添加自定义图标，自己加序号3、4、5等';
$it618_chat_lang['s169'] = '微信关注提示';
$it618_chat_lang['s170'] = '抱歉，和此客服会话前，请先关注本站微信公众号，方便在您不在线时提醒您会话内容！<br><br><br>请联系管理员在后台设置微信关注引导说明！';
$it618_chat_lang['s171'] = '抱歉，此功能需要安装it618会员登录认证！';
$it618_chat_lang['s172'] = '提示：会员与客服会话前，如果会员没有关注本站微信公众号，就会显示此提示内容';
$it618_chat_lang['s173'] = '关注';
$it618_chat_lang['s174'] = '提示：如果勾选关注，表示会员与客服会话前，必须关注本站微信公众号，这样方便会员不在线时，也知道会话内容，黑名单uids表示这些会员就不能给客服会话了';
$it618_chat_lang['s175'] = '编辑内容';
$it618_chat_lang['s176'] = '微信关注提示内容更新成功！';
$it618_chat_lang['s177'] = '编辑微信关注提示内容';
$it618_chat_lang['s178'] = '黑名单uids(多个用逗号隔开，如：1,2,3)';
$it618_chat_lang['s179'] = '更新以上提示内容到所有客服类别';
$it618_chat_lang['s180'] = '共享';
$it618_chat_lang['s181'] = '提示：共享如果勾选，表示商家在没有设置客服时，默认是调用客服类别的客服功能，如果商家自己添加了客服，就显示商家自己的';
$it618_chat_lang['s182'] = '在此表情组导入QQ默认表情包(132个表情)';
$it618_chat_lang['s183'] = '确定要在此表情组导入QQ默认表情包？注意导入前会清空当前表情组的所有表情的！';
$it618_chat_lang['s184'] = 'QQ默认表情包(132个表情)导入成功！';
$it618_chat_lang['s185'] = '下载QQ默认表情包qq.zip,解压后整个目录放到app_chat/face目录内';
$it618_chat_lang['s186'] = '在线人数基数：';
$it618_chat_lang['s187'] = '提示：在线人数基数如果为0时，表示真实的在线人数，如果基数大于0，那么前台显示的在线人数=基数+真实在线人数 <font color=#390>点更新后，所有本群聊的客户端都会自动更新在线人数</font>';
$it618_chat_lang['s188'] = '群聊控制台';
$it618_chat_lang['s189'] = '更新';
$it618_chat_lang['s190'] = '取消';
$it618_chat_lang['s191'] = '真实在线人数：';
$it618_chat_lang['s192'] = '聊天设置更新成功！';
$it618_chat_lang['s193'] = '指定会员/超级管理员(多个会员uid用逗号隔开，如：1,2,3)';
$it618_chat_lang['s194'] = '抱歉，请您先关注讲师后再进入群聊！';
$it618_chat_lang['s195'] = '抱歉，讲师没有开启粉丝群聊功能！';
$it618_chat_lang['s196'] = '抱歉，粉丝关注时间大于';
$it618_chat_lang['s197'] = '小时就可以参与群聊了，谢谢您的关注！';
$it618_chat_lang['s198'] = '您已经关注了';
$it618_chat_lang['s199'] = '小时。';
$it618_chat_lang['s200'] = '抱歉，当前试卷没有聊天权限！';
$it618_chat_lang['s201'] = '抱歉，当前试卷只有考试时有聊天权限！';
$it618_chat_lang['s202'] = '抱歉，当前试卷只有考试完时聊天权限！';
$it618_chat_lang['s203'] = '抱歉，当前试卷你还没权限考试就不能聊天！';
$it618_chat_lang['s204'] = '抱歉，您已被管理员禁言！';
$it618_chat_lang['s205'] = '确定要禁言username？';
$it618_chat_lang['s206'] = '确定要给username取消禁言？';
$it618_chat_lang['s207'] = '确定要屏蔽username？屏蔽后此会员自动退出聊天。';
$it618_chat_lang['s208'] = '确定要给username取消屏蔽？，取消屏蔽后会员可以再进入聊天。';
$it618_chat_lang['s209'] = '抱歉，参数有误！';
$it618_chat_lang['s210'] = '在线会员';
$it618_chat_lang['s211'] = '设为管理员';
$it618_chat_lang['s212'] = '取消管理员';
$it618_chat_lang['s213'] = '禁言';
$it618_chat_lang['s214'] = '取消禁言';
$it618_chat_lang['s215'] = '屏蔽';
$it618_chat_lang['s216'] = '取消屏蔽';
$it618_chat_lang['s217'] = '抱歉，此会员不存在！';
$it618_chat_lang['s218'] = '确定要设置username为管理员？';
$it618_chat_lang['s219'] = '确定要取消username的管理员权限？';
$it618_chat_lang['s220'] = '抱歉，您已被管理员屏蔽，不能进入聊天！';
$it618_chat_lang['s221'] = '给username禁言成功！';
$it618_chat_lang['s222'] = '给username取消禁言成功！';
$it618_chat_lang['s223'] = '给username屏蔽成功！';
$it618_chat_lang['s224'] = '给username取消屏蔽成功！';
$it618_chat_lang['s225'] = '给username设置管理员成功！';
$it618_chat_lang['s226'] = '给username取消管理员成功！';
$it618_chat_lang['s227'] = '显示在线会员：';
$it618_chat_lang['s228'] = '如开启非管理人员也显示';
$it618_chat_lang['s229'] = '商品链接';
$it618_chat_lang['s230'] = '所有非管理人员';
$it618_chat_lang['s231'] = '请输入要发送的商品链接：';
$it618_chat_lang['s232'] = '发送链接到聊天';
$it618_chat_lang['s233'] = '抱歉，未能识别此商品链接！';
$it618_chat_lang['s234'] = '抱歉，此商品链接未能识别或正在识别中请等候，不能发送到群聊！';
$it618_chat_lang['s235'] = '商品已成功发送到聊天！';
$it618_chat_lang['s236'] = '提示：请您先复制商品链接到以下文本框，再点空白处待此处识别成功商品后，就可以发送商品链接到聊天了！';
$it618_chat_lang['s237'] = '抱歉，管理员已设置全员禁言！';
$it618_chat_lang['s238'] = '用户组权限';
$it618_chat_lang['s239'] = '管理';
$it618_chat_lang['s240'] = '返回群聊管理';
$it618_chat_lang['s241'] = '《';
$it618_chat_lang['s242'] = '》';
$it618_chat_lang['s243'] = '导入(更新)用户组';
$it618_chat_lang['s244'] = '启用数：';
$it618_chat_lang['s245'] = '提示：多个用户组时，如果会员在其中任何一个用户组也算有群聊权限';
$it618_chat_lang['s246'] = '用户组名称';
$it618_chat_lang['s247'] = '提交';
$it618_chat_lang['s248'] = '已成功导入(更新)论坛所有用户组！';
$it618_chat_lang['s249'] = '群聊用户组权限设置成功！';
$it618_chat_lang['s250'] = '发送:Ctrl+Enter 换行:Enter';
$it618_chat_lang['s251'] = '发送';
$it618_chat_lang['s252'] = '抱歉，请输入发送内容！';
$it618_chat_lang['s253'] = '抱歉，发送内容太长啦！';
$it618_chat_lang['s254'] = '确定要删除此条消息？';
$it618_chat_lang['s255'] = '';
$it618_chat_lang['s256'] = '';
$it618_chat_lang['s257'] = '';
$it618_chat_lang['s258'] = '';
$it618_chat_lang['s259'] = '';
$it618_chat_lang['sn'] = '';
$it618_chat_lang['s409'] = '会员进入提示：';
$it618_chat_lang['s410'] = '如开启进入群聊自动回复提示';
$it618_chat_lang['s411'] = '启用';
$it618_chat_lang['s412'] = '消息提醒设置更新成功！';
$it618_chat_lang['s413'] = '<strong>第三方短信接口，按短信条数收费，给第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注册账号并充值，然后填以下内容就可以了';
$it618_chat_lang['s414'] = '启用消息接口：';
$it618_chat_lang['s415'] = '如果不启用，系统不会有消息提醒功能 <font color=blue>如果安装了【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】就会支持微信模板消息，微信模板ID不为空时，优先发微信模板消息，而不发短信</font>';
$it618_chat_lang['s416'] = '短信接口账号：';
$it618_chat_lang['s417'] = '短信接口密码：';
$it618_chat_lang['s418'] = '测试接收人手机号：';
$it618_chat_lang['s419'] = '多个手机号用英文字母逗号隔开';
$it618_chat_lang['s420'] = '测试短信内容：';
$it618_chat_lang['s421'] = '管理员手机号：';
$it618_chat_lang['s422'] = '如果不启用，管理员不会有消息提醒';
$it618_chat_lang['s423'] = '消息模板';
$it618_chat_lang['s424'] = '注意：消息模板只有在“启用”状态，才发送提醒消息，如果短信消息模板和微信消息模板都设置了，优先发送微信消息，发送成功了，就不发短信了，方便节省短信成本';
$it618_chat_lang['s425'] = '<font color="green">不在线有会话时 - 客服人员消息模板</font>';
$it618_chat_lang['s426'] = '<font color="#999999">示例：您好${user}，您的${kefuname}-${kefuuser}，在${time}有会话者${talkuname}请求回复，会话内容：${talk}！
<br>标签说明：{kefuname}客服类别名称+客服商家名称(不是商家时返回空)，{kefuuser}客服昵称，{user}客服会员名称，{talkuname}会话者名称，{talk}会话内容，{time}会话时间</font>';
$it618_chat_lang['s427'] = '<font color="green">不在线有会话时 - 会话者消息模板(目前只支持微信消息)</font>';
$it618_chat_lang['s428'] = '<font color="#999999">示例：您好${user}，客服人员${kefuname}-${kefuuser}，在${time}回复了您，请求回复，回复内容：${talk}！
<br>标签说明：{kefuname}客服类别名称+客服商家名称(不是商家时返回空)，{kefuuser}客服昵称，{user}会话者会员名称，{talk}会话内容，{time}会话时间</font>';
$it618_chat_lang['s441'] = '更新';
$it618_chat_lang['s442'] = '更新时发送一个测试短信';
$it618_chat_lang['s890'] = '【';
$it618_chat_lang['s891'] = '】';
$it618_chat_lang['s893'] = '全局自定义JS/CSS';
$it618_chat_lang['s894'] = '提示：只要是有调用客服的页面都会调用此设置的JS代码或CSS代码，方便管理，<font color=red>CSS代码必须置于&lt;style&gt;&lt;/style&gt;内，JS代码必须置于&lt;script&gt;&lt;/script&gt;内</font>';
$it618_chat_lang['s895'] = '更新成功！';
$it618_chat_lang['s896'] = '注意：以下内容必须用编辑器的代码模式(<font color=blue>代码模式/内容模式 通过编辑器的第一个功能图标切换</font>)修改！';
$it618_chat_lang['s1040'] = '短信接口类型：';
$it618_chat_lang['s1041'] = '默认标配短信接口(短信宝)';
$it618_chat_lang['s1042'] = 'IT618统一短信接口(阿里大鱼)';
$it618_chat_lang['s1043'] = '短信签名：';
$it618_chat_lang['s1044'] = 'IT618统一短信接口(阿里云短信)';
$it618_chat_lang['s1045'] = '<font color=green><b>抱歉，您还没有安装 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】，此插件为IT618公用短信接口插件，<font color=red>同时还是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_chat_lang['s1046'] = '短信模板ID：';
$it618_chat_lang['s1050'] = '管理员UID<font color=#999>(用于微信消息，多个UID用,隔开)</font>：';
$it618_chat_lang['s1051'] = '微信消息模板ID：';
$it618_chat_lang['s1052'] = '微信消息标签值：';
$it618_chat_lang['s1053'] = '<font color=#999>提示：优先发送微信消息，发送成功了，就不发短信了</font>';
$it618_chat_lang['s1551'] = '启用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_chat_lang['s1877'] = '在线编辑器设置更新成功！';
$it618_chat_lang['s1878'] = '在线编辑器设置';
$it618_chat_lang['s1879'] = '启用oss接口：';
$it618_chat_lang['s1880'] = '如果不启用，上传图片到本地，如果启用，上传图片到oss，并且返回图片网络引用链接';
$it618_chat_lang['s1881'] = 'IT618插件阿里云OSS接口设置方法';
$it618_chat_lang['s1882'] = 'Access Key ID：';
$it618_chat_lang['s1883'] = 'Access Key Secret：';
$it618_chat_lang['s1884'] = 'Bucket名称：';
$it618_chat_lang['s1885'] = 'Bucket域名EndPoint：';
$it618_chat_lang['s1886'] = 'Bucket外网访问域名：';
$it618_chat_lang['s1887'] = '更新';
$it618_chat_lang['s1888'] = '如果是个人认证，变量字符最多限制个数：';
$it618_chat_lang['s1889'] = '不受限制时请不要填写';
$it618_chat_lang['s1905'] = '参数名称';
$it618_chat_lang['s1906'] = '参数内容';
$it618_chat_lang['s1907'] = '提示：最多支持9个微信消息模板参数，参数名称比如是：first,keyword1,keyword2,keyword3,...,remark，参数内容支持以上一个标签或多个标签';
$it618_chat_lang['s1908'] = '取消';
$it618_chat_lang['s1909'] = '保存';
$it618_chat_lang['s1910'] = '抱歉，如果参数名称填写了，就必须填写参数内容！';
$it618_chat_lang['s1911'] = '<font color=green>提示：默认有短信宝接口，如果配合 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a> 可以有阿里云短信接口，此插件以后还可以扩展更多短信接口</font>';


//it618_chat_lang(\d+)} it618_chat_lang['t$1']}
$it618_chat_lang['t1'] = '网友';
$it618_chat_lang['t2'] = '操作失败';
$it618_chat_lang['t3'] = '操作失败：';
$it618_chat_lang['t4'] = '在线人数:';
$it618_chat_lang['t5'] = '对方已在线';
$it618_chat_lang['t6'] = '对方不在线';
$it618_chat_lang['t7'] = '等待客服接入';
$it618_chat_lang['t8'] = '客服已接入';
$it618_chat_lang['t9'] = '在线客服';
$it618_chat_lang['t10'] = '知道了';
$it618_chat_lang['t11'] = '新增';
$it618_chat_lang['t12'] = '';
$it618_chat_lang['t13'] = '';
$it618_chat_lang['t14'] = '';
$it618_chat_lang['t15'] = '';
$it618_chat_lang['t16'] = '';
$it618_chat_lang['t17'] = '';
$it618_chat_lang['t18'] = '';
$it618_chat_lang['t19'] = '';
$it618_chat_lang['t20'] = '';
$it618_chat_lang['t83'] = '钱包';
$it618_chat_lang['t84'] = '关闭';
$it618_chat_lang['t85'] = '如果您的浏览器没有自动跳转，请点击这里';
$it618_chat_lang['t86'] = '提示';
$it618_chat_lang['t87'] = '删?';
$it618_chat_lang['t88'] = '提交';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_class'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_kefu_class` (`id`, `it618_plugin`, `it618_name`, `it618_style1`, `it618_state`) VALUES
(1, 'it618_discuz', '论坛', '150|it618split|230|it618split|#FF0000|it618split|#FF0000|it618split|2|it618split|8|it618split|130|it618split|我要咨询', 0),
(2, 'it618_video', '视频直播课堂', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|108|it618split|我要咨询', 0),
(3, 'it618_brand', '联盟商家', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|185|it618split|我要咨询', 0),
(4, 'it618_tuan', '多功能商城', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|109|it618split|我要咨询', 0);
EOF;
$sql=str_replace("pre_it618_chat_kefu_class",DB::table('it618_chat_kefu_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_class')." where it618_plugin='it618_waimai'");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_kefu_class` (`id`, `it618_plugin`, `it618_name`, `it618_style1`, `it618_state`) VALUES
(5, 'it618_waimai', '外卖商城', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要咨询', 0),
(6, 'it618_paotui', '同城跑腿', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要咨询', 0);
EOF;
$sql=str_replace("pre_it618_chat_kefu_class",DB::table('it618_chat_kefu_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_class')." where it618_plugin='it618_sale'");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_kefu_class` (`id`, `it618_plugin`, `it618_name`, `it618_style1`, `it618_state`) VALUES
(7, 'it618_sale', '淘宝客导购', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要咨询', 0),
(8, 'it618_union', '推广联盟', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要咨询', 0);
EOF;
$sql=str_replace("pre_it618_chat_kefu_class",DB::table('it618_chat_kefu_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_class')." where it618_plugin='it618_exam'");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_kefu_class` (`id`, `it618_plugin`, `it618_name`, `it618_style1`, `it618_state`) VALUES
(9, 'it618_exam', '在线考试答题', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要咨询', 0);
EOF;
$sql=str_replace("pre_it618_chat_kefu_class",DB::table('it618_chat_kefu_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_facegroup'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_facegroup` (`it618_name`, `it618_img`, `it618_order`) VALUES
('QQ表情', 'source/plugin/it618_chat/app_chat/face/qq.png', 0);
EOF;
$sql=str_replace("pre_it618_chat_facegroup",DB::table('it618_chat_facegroup'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_chat_face` (`it618_group_id`, `it618_name`, `it618_img`, `it618_order`) VALUES
(1, '1', 'source/plugin/it618_chat/app_chat/face/1.gif', 0),
(1, '2', 'source/plugin/it618_chat/app_chat/face/2.gif', 0),
(1, '3', 'source/plugin/it618_chat/app_chat/face/3.gif', 0),
(1, '4', 'source/plugin/it618_chat/app_chat/face/4.gif', 0),
(1, '5', 'source/plugin/it618_chat/app_chat/face/5.gif', 0),
(1, '6', 'source/plugin/it618_chat/app_chat/face/6.gif', 0),
(1, '7', 'source/plugin/it618_chat/app_chat/face/7.gif', 0),
(1, '8', 'source/plugin/it618_chat/app_chat/face/8.gif', 0),
(1, '9', 'source/plugin/it618_chat/app_chat/face/9.gif', 0),
(1, '10', 'source/plugin/it618_chat/app_chat/face/10.gif', 0);
EOF;
$sql=str_replace("pre_it618_chat_face",DB::table('it618_chat_face'),$sql);
DB::query($sql);
}
//From: d'.'is'.'m.ta'.'obao.com
?>