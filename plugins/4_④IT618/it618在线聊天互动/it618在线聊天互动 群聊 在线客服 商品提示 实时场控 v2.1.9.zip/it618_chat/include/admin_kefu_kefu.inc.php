<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; //d'.'i'.'sm.ta'.'o'.'bao.com

$cid=intval($_GET['cid']);
$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($cid);

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/ajax.inc.php')){
	$isMembers=1;
}

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_chat_kefu', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			$uid=trim($_GET['it618_uid'][$id]);
			$username=C::t('#it618_chat#it618_chat_kefu')->fetch_username_by_uid($uid);
			if($username=='')$uid=0;
			
			$it618_isuser=trim($_GET['it618_isuser'][$id]);
			$it618_iswxsubscribe=trim($_GET['it618_iswxsubscribe'][$id]);
			if($isMembers!=1)$it618_iswxsubscribe=0;
			if($it618_iswxsubscribe==1){
				$it618_isuser=1;
			}

			C::t('#it618_chat#it618_chat_kefu')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_uid' => $uid,
				'it618_tel' => trim($_GET['it618_tel'][$id]),
				'it618_isuser' => $it618_isuser,
				'it618_iswxsubscribe' => $it618_iswxsubscribe,
				'it618_uids' => trim($_GET['it618_uids'][$id]),
				'it618_state' => trim($_GET['it618_state'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_uid_array = !empty($_GET['newit618_uid']) ? $_GET['newit618_uid'] : array();
	$newit618_tel_array = !empty($_GET['newit618_tel']) ? $_GET['newit618_tel'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));

		if($newit618_name != '') {
			
			$uid=trim($newit618_uid_array[$key]);
			$username=C::t('#it618_chat#it618_chat_kefu')->fetch_username_by_uid($uid);
			if($username=='')$uid=0;
			
			C::t('#it618_chat#it618_chat_kefu')->insert(array(
				'it618_cid' => $cid,
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_uid' => $uid,
				'it618_tel' => trim($newit618_tel_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_chat_lang['s33'].$ok1.' '.$it618_chat_lang['s34'].$ok2.' '.$it618_chat_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_kefu_kefu&pmod=admin_kefu&operation=$operation&do=$do&cid=$cid", 'succeed');
}

if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com

$preurl=ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_kefu_class&pmod=admin_kefu&operation=$operation&do=$do";

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_kefu_kefu&pmod=admin_kefu&operation=$operation&do=$do&cid=$cid");
showtableheaders($it618_chat_kefu_class['it618_name'].$it618_chat_lang['s86'].' <a href="'.$preurl.'">'.$it618_chat_lang['s76'].'</a>','it618_chat_kefu');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu')." WHERE it618_cid=".$cid." and it618_sid=0");
	
	echo '<tr><td colspan=10><font color=red>'.$it618_chat_lang['s163'].'</font></span></td></tr>';
	echo '<tr><td colspan=10>'.$it618_chat_lang['s160'].'</span></td></tr>';
	echo '<tr><td colspan=10>'.$it618_chat_lang['s104'].$count.'<span style="float:right;">'.$it618_chat_lang['s103'].'</span></td></tr>';
	showsubtitle(array('',$it618_chat_lang['s106'],$it618_chat_lang['s107'],$it618_chat_lang['s156'],$it618_chat_lang['s108'],$it618_chat_lang['s55'],$it618_chat_lang['s173'],$it618_chat_lang['s178'],$it618_chat_lang['s113'],$it618_chat_lang['s99']));

	$query = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu')." WHERE it618_cid=".$cid." and it618_sid=0 ORDER BY it618_order");
	while($it618_chat_kefu = DB::fetch($query)) {
		
		if($isMembers==1){
			if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($it618_chat_kefu['it618_uid'])){
				if($it618_members_wxuser['it618_wxok']==1){
					$wxstr=$it618_members_wxuser['it618_wxname'].' '.$it618_chat_lang['s161'];
				}else{
					$wxstr=$it618_members_wxuser['it618_wxname'].' '.$it618_chat_lang['s159'];
				}
			}else{
				$wxstr=$it618_chat_lang['s158'];
			}
		}else{
			$wxstr=$it618_chat_lang['s157'];
		}
		
		$username=C::t('#it618_chat#it618_chat_kefu')->fetch_username_by_uid($it618_chat_kefu['it618_uid']);
		
		if($it618_chat_kefu['it618_isuser']==1)$it618_isuser_checked='checked="checked"';else $it618_isuser_checked="";
		if($it618_chat_kefu['it618_iswxsubscribe']==1)$it618_iswxsubscribe_checked='checked="checked"';else $it618_iswxsubscribe_checked="";
		if($it618_chat_kefu['it618_state']==1)$it618_state_checked='checked="checked"';else $it618_state_checked="";
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id$it618_chat[id]\" name=\"delete[]\" value=\"$it618_chat_kefu[id]\" $disabled><label for=\"id$it618_chat_kefu[id]\">$it618_chat_kefu[id]</label>",
			"<input type=\"text\" class=\"txt\" style=\"width:150px\" name=\"it618_name[$it618_chat_kefu[id]]\" value=\"$it618_chat_kefu[it618_name]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:50px;margin-right:3px\" name=\"it618_uid[$it618_chat_kefu[id]]\" value=\"$it618_chat_kefu[it618_uid]\">".$username,
			$wxstr,
			"<input type=\"text\" class=\"txt\" style=\"width:150px\" name=\"it618_tel[$it618_chat_kefu[id]]\" value=\"$it618_chat_kefu[it618_tel]\">",
			'<input class="checkbox" type="checkbox" name="it618_isuser['.$it618_chat_kefu['id'].']" '.$it618_isuser_checked.' value="1">',
			'<input class="checkbox" type="checkbox" name="it618_iswxsubscribe['.$it618_chat_kefu['id'].']" '.$it618_iswxsubscribe_checked.' value="1">',
			"<input type=\"text\" class=\"txt\" style=\"width:230px\" name=\"it618_uids[$it618_chat_kefu[id]]\" value=\"$it618_chat_kefu[it618_uids]\">",
			'<input class="checkbox" type="checkbox" name="it618_state['.$it618_chat_kefu['id'].']" '.$it618_state_checked.' value="1">',
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_chat_kefu['id'].']" value="'.$it618_chat_kefu['it618_order'].'">'
		));
	}
	
	global $_G;
if($reabc[4]!='8')return; //Dism_taobao-com

	loadcache('plugin');
	$it618_chat = $_G['cache']['plugin']['it618_chat'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$it618_chat_lang102=$it618_chat_lang['s102'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:150px;margin-bottom:3px" name="newit618_name[]">'],
		[1,'<input type="text" class="txt" style="width:50px;margin-bottom:3px" name="newit618_uid[]">'],
		[1,''],
		[1, '<input type="text" class="txt" style="width:150px;margin-bottom:3px" name="newit618_tel[]">']]
		];
	}
	rowtypedata=rundata();

	</script>
EOT;
	echo '<tr><td></td><td colspan="15"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page /> ".$it618_chat_lang['s174']);
	if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com
showtablefooter(); //dism��taobao��com
?>