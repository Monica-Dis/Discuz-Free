<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; //d'.'i'.'sm.ta'.'o'.'bao.com

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$adyun_dms_sub_key=\''.trim($_GET['adyun_dms_sub_key'])."';\n";
		$fileData .= '$adyun_dms_s_key=\''.trim($_GET['adyun_dms_s_key'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_chat_lang['s36'], "action=plugins&identifier=$identifier&cp=admin_aodianyun&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}


showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_aodianyun&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

if($chatset_isip==1)$check_chatset_isip='checked="checked"';else $check_chatset_isip='';
if($chatset_isaddr==1)$check_chatset_isaddr='checked="checked"';else $check_chatset_isaddr='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr class="header"><th width=180>'.$it618_chat_lang['s14'].'</th><th>'.$it618_chat_lang['s16'].'</th><th>'.$it618_chat_lang['s15'].'</th></tr>

<tr class="hover">
<td>'.$it618_chat_lang['s12'].'</td><td class="longtxt"><input name="adyun_dms_sub_key" value="'.$adyun_dms_sub_key.'" style="width:380px" /></td>
<td>'.$it618_chat_lang['s10'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s13'].'</td><td class="longtxt"><input name="adyun_dms_s_key" value="'.$adyun_dms_s_key.'" style="width:380px" /></td>
<td>'.$it618_chat_lang['s10'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_chat_lang['s1887']);

if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com
showtablefooter(); //dism��taobao��com

?>