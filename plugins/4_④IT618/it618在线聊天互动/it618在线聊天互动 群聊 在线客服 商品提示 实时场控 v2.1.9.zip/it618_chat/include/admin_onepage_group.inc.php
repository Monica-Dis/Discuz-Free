<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

$oid=intval($_GET['oid']);
$preurl=$_GET['preurl'];
$it618_chat_onepage = C::t('#it618_chat#it618_chat_onepage')->fetch_by_id($oid);

if(submitcheck('it618submit')){

	if(is_array($_GET['it618_groupid'])) {
		foreach($_GET['it618_groupid'] as $id => $val) {
			
				C::t('#it618_chat#it618_chat_onepage_group')->update($id,array(
					'it618_isok' => $_GET['it618_isok'][$id],
				));
		}
	}

	cpmsg($it618_chat_lang['s249'], "action=plugins&identifier=$identifier&cp=admin_onepage_group&pmod=admin_onepage&oid=$oid&operation=$operation&do=$do&page=$page&preurl=$preurl", 'succeed');
}

if(submitcheck('it618daosubmit')) {
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_onepage_group')." WHERE it618_oid=$oid and it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_chat#it618_chat_onepage_group')->insert(array(
				'it618_oid' => $oid,
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}
	
	cpmsg($it618_chat_lang['s248'], "action=plugins&identifier=$identifier&cp=admin_onepage_group&pmod=admin_onepage&oid=$oid&operation=$operation&do=$do&page=$page&preurl=$preurl", 'succeed');
}

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_onepage_group')." where it618_oid=$oid")==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_onepage_group')." WHERE it618_oid=$oid and it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_chat#it618_chat_onepage_group')->insert(array(
				'it618_oid' => $oid,
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}	
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_onepage_group&pmod=admin_onepage&oid=$oid&operation=$operation&do=$do&preurl=$preurl");

$preurlhref=str_replace("@","&",$preurl);
showtableheaders('<a href="'.$preurlhref.'">'.$it618_chat_lang['s240'].'<font color=red>'.$it618_chat_lang['s241'].$it618_chat_onepage['it618_name'].$it618_chat_lang['s242'].'</font></a> '.$it618_chat_lang['s1535'],'it618_chat_onepage_group');
	showsubmit('it618daosubmit', $it618_chat_lang['s243']);
	if($reabc[5]!='_')return; //d'.'i'.'sm.ta'.'o'.'bao.com
	
	$groupcount=C::t('#it618_chat#it618_chat_onepage_group')->count_by_oid($oid);
	
	echo '<tr><td colspan=10>'.$it618_chat_lang['s244'].$groupcount.'<span style="float:right;color:red">'.$it618_chat_lang['s245'].'</span></td></tr>';
	
	showsubtitle(array($it618_chat_lang['s246']));
	
	echo '<tr><td colspan=10><ul>';
	$query = DB::query("SELECT p.id,g.groupid,g.grouptitle,p.* FROM ".DB::table('it618_chat_onepage_group')." p,".DB::table('common_usergroup')." g WHERE p.it618_groupid=g.groupid and p.it618_oid=$oid");
	while($it618_chat_onepage_group =	DB::fetch($query)) {
		
		if($it618_chat_onepage_group['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		echo '<li style="float:left;width:230px"><input type="hidden" name="it618_groupid['.$it618_chat_onepage_group['id'].']"><input type="checkbox" id="isok'.$it618_chat_onepage_group['id'].'" name="it618_isok['.$it618_chat_onepage_group['id'].']" style="vertical-align:middle" value="1" '.$it618_isok_checked.'><label for="isok'.$it618_chat_onepage_group['id'].'">'.$it618_chat_onepage_group['grouptitle'].'</label></li>';
	}
	echo '</ul></td></tr>';
	
	showsubmit('it618submit', $it618_chat_lang['s247']);
	showtablefooter(); //dism��taobao��com
?>