<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; //d'.'i'.'sm.ta'.'o'.'bao.com

$it618sql = "1";

$findstate0='';$findstate1='';$findstate2='';
if($_GET['findstate']==0){$findstate0='selected="selected"';}
if($_GET['findstate']==1){$it618sql .= " and it618_state=1";$findstate1='selected="selected"';}
if($_GET['findstate']==2){$it618sql .= " and it618_state=0";$findstate2='selected="selected"';}

$it618orderby='it618_cid,it618_sid,id desc';

$urlsql='&key='.$_GET['key'].'&findclass='.$_GET['findclass'].'&findstate='.$_GET['findstate'];

$query1 = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu_class'));
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

$tmp1=str_replace('<option value='.$_GET['findclass'].'>','<option value='.$_GET['findclass'].' selected="selected">',$tmp);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_kefu&pmod=admin_kefu&operation=$operation&do=$do&cp1=$cp1".$urlsql);
showtableheaders($it618_chat_lang['s58'],'it618_chat_kefu');
	showsubmit('it618sercsubmit', $it618_chat_lang['s116'], $it618_chat_lang['s109'].' <input name="key" style="width:180px" value="'.$_GET['key'].'" class="txt" /> '.$it618_chat_lang['s110'].' <select name="findclass"><option value=0 '.$findclass0.'>'.$it618_chat_lang['s111'].'</option>'.$tmp1.'</select> '.$it618_chat_lang['s112'].' <select name="findstate"><option value=0 '.$findstate0.'>'.$it618_chat_lang['s115'].'</option><option value=1 '.$findstate1.'>'.$it618_chat_lang['s113'].'</option><option value=2 '.$findstate2.'>'.$it618_chat_lang['s114'].'</option></select>');
	
	$count = C::t('#it618_chat#it618_chat_kefu')->count_all_by_search($it618sql,$it618orderby,$_GET['key'],$_GET['findclass']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_kefu&pmod=admin_kefu&operation=$operation&do=$do".$urlsql);
	if($reabc[6]!='c')return;
	echo '<tr><td colspan=8>'.$it618_chat_lang['s104'].$count.' <span style="float:right">'.$it618_chat_lang['s117'].'</span></td></tr>';
	showsubtitle(array($it618_chat_lang['s120'],$it618_chat_lang['s118'],$it618_chat_lang['s119'],$it618_chat_lang['s106'],$it618_chat_lang['s107'],$it618_chat_lang['s156'],$it618_chat_lang['s108'],$it618_chat_lang['s55'],$it618_chat_lang['s173'],$it618_chat_lang['s149'],$it618_chat_lang['s112']));
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/ajax.inc.php')){
		$isMembers=1;
	}
	
	foreach(C::t('#it618_chat#it618_chat_kefu')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['key'],$_GET['findclass'],$startlimit,$ppp
	) as $it618_chat_kefu) {
		$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($it618_chat_kefu['it618_cid']);
		$username=C::t('#it618_chat#it618_chat_kefu')->fetch_username_by_uid($it618_chat_kefu['it618_uid']);
		
		if($isMembers==1){
			if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($it618_chat_kefu['it618_uid'])){
				if($it618_members_wxuser['it618_wxok']==1){
					$wxstr=$it618_members_wxuser['it618_wxname'].' '.$it618_chat_lang['s161'];
				}else{
					$wxstr=$it618_members_wxuser['it618_wxname'].' '.$it618_chat_lang['s159'];
				}
			}else{
				$wxstr=$it618_chat_lang['s158'];
			}
		}else{
			$wxstr=$it618_chat_lang['s157'];
		}
		
		if($it618_chat_kefu['it618_state']==0){
			$it618_state='<font color=red>'.$it618_chat_lang['s114'].'</font>';
		}else{
			$it618_state='<font color=green>'.$it618_chat_lang['s113'].'</font>';
		}
		
		if($it618_chat_kefu['it618_isuser']==1){
			$it618_isuser=$it618_chat_lang['s130'];
		}else{
			$it618_isuser=$it618_chat_lang['s131'];
		}
		
		if($it618_chat_kefu['it618_iswxsubscribe']==1){
			$it618_iswxsubscribe=$it618_chat_lang['s130'];
		}else{
			$it618_iswxsubscribe=$it618_chat_lang['s131'];
		}
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			$it618_chat_kefu['id'],
			$it618_chat_kefu_class['it618_name'],
			it618_chat_getshopname($it618_chat_kefu_class['it618_plugin'],$it618_chat_kefu['it618_sid']),
			$it618_chat_kefu['it618_name'],
			$username,
			$wxstr,
			$it618_chat_kefu['it618_tel'],
			$it618_isuser,
			$it618_iswxsubscribe,
			"<input type=\"text\" class=\"txt\" style=\"width:80px\" value=\"$it618_chat_kefu[it618_uids]\">",
			$it618_state
		));
	}
echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com
	showtablefooter(); //dism��taobao��com
?>