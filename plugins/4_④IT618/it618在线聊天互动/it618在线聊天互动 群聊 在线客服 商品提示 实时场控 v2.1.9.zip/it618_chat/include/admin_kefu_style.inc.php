<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; //d'.'i'.'sm.ta'.'o'.'bao.com

$cid=intval($_GET['cid']);
$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($cid);

if(submitcheck('it618submit')){
	$it618_style=intval($_GET['style_top'])."|it618split|";
	$it618_style.=intval($_GET['style_width'])."|it618split|";
	$it618_style.=trim($_GET['style_pccolor'])."|it618split|";
	$it618_style.=trim($_GET['style_wapcolor'])."|it618split|";
	$it618_style.=trim($_GET['style_wapfloat'])."|it618split|";
	$it618_style.=trim($_GET['style_wapwidth'])."|it618split|";
	$it618_style.=trim($_GET['style_wapbottom'])."|it618split|";
	$it618_style.=trim($_GET['style_title'])."|it618split|";
	$it618_style.=trim($_GET['style_jquery'])."|it618split|";
	
	C::t('#it618_chat#it618_chat_kefu_class')->update($cid,array(
		'it618_style1' => $it618_style,
		'it618_style1_ico' => $_GET['it618_style1_ico'],
		'it618_style1_wapico' => $_GET['it618_style1_wapico']
	));

	cpmsg($it618_chat_lang['s89'], "action=plugins&identifier=$identifier&cp=admin_kefu_style&pmod=admin_kefu&operation=$operation&do=$do&cid=$cid", 'succeed');
}

$stylearr=explode("|it618split|",$it618_chat_kefu_class['it618_style1']);
$style_top=$stylearr[0];
$style_width=$stylearr[1];
$style_pccolor=$stylearr[2];
$style_wapcolor=$stylearr[3];
$style_wapfloat=$stylearr[4];
$style_wapwidth=$stylearr[5];
$style_wapbottom=$stylearr[6];
$style_title=$stylearr[7];
$style_jquery=$stylearr[8];

$wapfloat='
<option value="1">'.$it618_chat_lang['s145'].'</option>
<option value="2">'.$it618_chat_lang['s146'].'</option>
';

$pcico='
<option value="1">'.$it618_chat_lang['s164'].'</option>
<option value="2">'.$it618_chat_lang['s165'].'</option>
';

$wapico='
<option value="1">'.$it618_chat_lang['s164'].'</option>
<option value="2">'.$it618_chat_lang['s165'].'</option>
';

$wapfloat=str_replace('<option value="'.$style_wapfloat.'"','<option value="'.$style_wapfloat.'" selected="selected"',$wapfloat);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_kefu_style&pmod=admin_kefu&operation=$operation&do=$do&cid=$cid");

$preurl=ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_kefu_class&pmod=admin_kefu&operation=$operation&do=$do";

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_chat_kefu_class['it618_name'].$it618_chat_lang['s84'].' <a href="'.$preurl.'">'.$it618_chat_lang['s76'].'</a></th></tr>
<tr class="header"><th width=190>'.$it618_chat_lang['s73'].'</th><th>'.$it618_chat_lang['s74'].'</th><th>'.$it618_chat_lang['s75'].'</th></tr>

<tr class="hover">
<td>'.$it618_chat_lang['s166'].'</td><td class="longtxt"><input name="it618_style1_ico" value="'.$it618_chat_kefu_class['it618_style1_ico'].'" style="width:80px;margin-right:3px" /></td>
<td>'.$it618_chat_lang['s168'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s69'].'</td><td class="longtxt"><input name="style_top" value="'.$style_top.'" style="width:80px;margin-right:3px" />px</td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s70'].'</td><td class="longtxt"><input name="style_width" value="'.$style_width.'" style="width:80px;margin-right:3px" />px</td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s71'].'</td><td class="longtxt">'."<input id=\"cstyle_pccolor_v\" type=\"text\" style=\"width:80px;float:left;margin-right:3px\" name=\"style_pccolor\" value=\"$style_pccolor\" onchange=\"updatecolorpreview('cstyle_pccolor')\"><input id=\"cstyle_pccolor\" onclick=\"cstyle_pccolor_frame.location='static/image/admincp/getcolor.htm?cstyle_pccolor|cstyle_pccolor_v';showMenu({'ctrlid':'cstyle_pccolor'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"cstyle_pccolor_menu\" style=\"display: none\"><iframe name=\"cstyle_pccolor_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>".'</td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s167'].'</td><td class="longtxt"><input name="it618_style1_wapico" value="'.$it618_chat_kefu_class['it618_style1_wapico'].'" style="width:80px;margin-right:3px" /></td>
<td>'.$it618_chat_lang['s168'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s72'].'</td><td class="longtxt">'."<input id=\"cstyle_wapcolor_v\" type=\"text\" style=\"width:80px;float:left;margin-right:3px\" name=\"style_wapcolor\" value=\"$style_wapcolor\" onchange=\"updatecolorpreview('cstyle_wapcolor')\"><input id=\"cstyle_wapcolor\" onclick=\"cstyle_wapcolor_frame.location='static/image/admincp/getcolor.htm?cstyle_wapcolor|cstyle_wapcolor_v';showMenu({'ctrlid':'cstyle_wapcolor'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"cstyle_wapcolor_menu\" style=\"display: none\"><iframe name=\"cstyle_wapcolor_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>".'</td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s142'].'</td><td class="longtxt"><select name="style_wapfloat">
	'.$wapfloat.'
</select></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s143'].'</td><td class="longtxt"><input name="style_wapwidth" value="'.$style_wapwidth.'" style="width:80px;margin-right:3px" />px</td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s144'].'</td><td class="longtxt"><input name="style_wapbottom" value="'.$style_wapbottom.'" style="width:80px;margin-right:3px" />px</td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_chat_lang['s121'].'</td><td class="longtxt"><input name="style_title" value="'.$style_title.'" style="width:150px;margin-right:3px" /></td>
<td>'.$it618_chat_lang['s122'].'</td>
</tr>
';

if($it618_chat_kefu_class['id']==1){
echo '<tr class="hover">
<td>'.$it618_chat_lang['s87'].'</td><td class="longtxt"><textarea name="style_jquery" style="width:300px;height:80px">'.$style_jquery.'</textarea></td>
<td>'.$it618_chat_lang['s88'].'</td>
</tr>';
}

echo '
</table>

<script>
updatecolorpreview(\'cstyle_pccolor\');
updatecolorpreview(\'cstyle_wapcolor\');
</script>
';

showsubmit('it618submit', $it618_chat_lang['s77']);

if(count($reabc)!=14)return;
showtablefooter(); //dism��taobao��com

?>