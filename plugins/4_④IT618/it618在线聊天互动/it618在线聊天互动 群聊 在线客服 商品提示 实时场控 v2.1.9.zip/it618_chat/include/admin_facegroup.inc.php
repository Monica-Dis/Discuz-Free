<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; //d'.'i'.'sm.ta'.'o'.'bao.com

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_chat_facegroup', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_chat#it618_chat_facegroup')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_img_array = !empty($_GET['newit618_img']) ? $_GET['newit618_img'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			C::t('#it618_chat#it618_chat_facegroup')->insert(array(
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_img' => trim($newit618_img_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_chat_lang['s33'].$ok1.' '.$it618_chat_lang['s34'].$ok2.' '.$it618_chat_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_facegroup&pmod=admin_face&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com
if(submitcheck('it618sercsubmit')) {
	if($_GET['beforeword']) {
		$extrasql = "AND it618_name LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
	}
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_facegroup&pmod=admin_face&operation=$operation&do=$do");
showtableheaders($it618_chat_lang['s24'],'it618_chat_facegroup');
	showsubmit('it618sercsubmit', $it618_chat_lang['s39'], $it618_chat_lang['s40'].' <input name="beforeword" value="'.$_GET['beforeword'].'" class="txt" />');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_facegroup')." w WHERE 1 $extrasql");
	
	echo '<tr><td colspan=10>'.$it618_chat_lang['s26'].$count.'<span style="float:right;color:red"></span></td></tr>';
	showsubtitle(array('',$it618_chat_lang['s29'], $it618_chat_lang['s30'],$it618_chat_lang['s31'],$it618_chat_lang['s43']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_chat_facegroup')." WHERE 1 $extrasql ORDER BY it618_order");
	while($it618_chat_facegroup = DB::fetch($query)) {
		$facecount = C::t('#it618_chat#it618_chat_face')->count_by_it618_group_id($it618_chat_facegroup['id']);
		$disabled="";
		if($facecount>0)$disabled="disabled=\"disabled\"";
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id$it618_chat[id]\" name=\"delete[]\" value=\"$it618_chat_facegroup[id]\" $disabled><label for=\"id$it618_chat_facegroup[id]\">$it618_chat_facegroup[id]</label>",
			"<input type=\"text\" class=\"txt\" style=\"width:180px\" name=\"it618_name[$it618_chat_facegroup[id]]\" value=\"$it618_chat_facegroup[it618_name]\">",
			'<img src="'.$it618_chat_facegroup['it618_img'].'" id="img'.$it618_chat_facegroup['id'].'" width="35" height="35" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" style="width:180px" id="url'.$it618_chat_facegroup['id'].'" name="it618_img['.$it618_chat_facegroup['id'].']" readonly="readonly" value="'.$it618_chat_facegroup['it618_img'].'" /> <input type="button" id="image'.$it618_chat_facegroup['id'].'" value="'.$it618_chat_lang['s41'].'" />',
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_chat_facegroup['id'].']" value="'.$it618_chat_facegroup['it618_order'].'">',
			$facecount
		));
		$editorjs.='K(\'#image'.$it618_chat_facegroup['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_chat_facegroup['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_chat_facegroup['id'].'\').val(url);
								K(\'#img'.$it618_chat_facegroup['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	global $_G;
if($reabc[4]!='8')return; //Dism_taobao-com

	loadcache('plugin');
	$it618_chat = $_G['cache']['plugin']['it618_chat'];
	
	echo '
	<link rel="stylesheet" href="source/plugin/it618_chat/kindeditor/themes/default/default.css" />
	<script charset="utf-8" src="source/plugin/it618_chat/kindeditor/kindeditor-min.js"></script>
	<script charset="utf-8" src="source/plugin/it618_chat/kindeditor/lang/zh_CN.js"></script>
	<script>
		KindEditor.ready(function(K) {
					var editor = K.editor({
						uploadJson : \'source/plugin/it618_chat/kindeditor/php/upload_json.php?imgwidth=1000'.$oss.'\',
						fileManagerJson : \'source/plugin/it618_chat/kindeditor/php/file_manager_json.php\',
						allowFileManager : true
					});
					'.$editorjs.'
				});
	</script>';

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$it618_chat_lang42=$it618_chat_lang['s42'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:180px" name="newit618_name[]">'],
		[1, '$it618_chat_lang42'],
		[1,'<input class="txt" type="text" style="width:50px" name="newit618_order[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();

	</script>
EOT;
	echo '<tr><td></td><td colspan="15"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
	if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com
showtablefooter(); //dism��taobao��com
?>