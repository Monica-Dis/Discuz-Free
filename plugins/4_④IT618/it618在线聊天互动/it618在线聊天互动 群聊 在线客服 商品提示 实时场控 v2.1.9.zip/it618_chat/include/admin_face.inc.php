<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; //d'.'i'.'sm.ta'.'o'.'bao.com
$n=1;
$query1 = DB::query("SELECT * FROM ".DB::table('it618_chat_facegroup')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	if(isset($_GET['groupid'])){
		if($_GET['groupid']==$it618_tmp['id']){
			$licss='class="current"';
			$groupid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}else{
		if($n==1){
			$licss='class="current"';
			$groupid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_face')." w WHERE it618_group_id=".$it618_tmp['id']);
	
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_face&pmod=admin_face&groupid=".$it618_tmp['id']."&operation=$operation&do=$do&page=1\"><span>".$it618_tmp['it618_name'].'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$n=$n+1;
}

if($tmp==''){
	cpmsg($it618_chat_lang['s5'], "action=plugins&identifier=$identifier&cp=admin_facegroup&pmod=admin_face&operation=$operation&do=$do&page=$page".$urlsql, 'error');
}

$tmp2=str_replace('<option value='.$groupid.'>','<option value='.$groupid.' selected="selected">',$tmp);
echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';

$extrasql .= "it618_group_id =".$groupid;
$urlsql='&groupid='.$groupid;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_chat_face', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_chat#it618_chat_face')->update($id,array(
				'it618_group_id' => trim($_GET['it618_group_id'][$id]),
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_group_id_array = !empty($_GET['newit618_group_id']) ? $_GET['newit618_group_id'] : array();
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_img_array = !empty($_GET['newit618_img']) ? $_GET['newit618_img'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			C::t('#it618_chat#it618_chat_face')->insert(array(
				'it618_group_id' => trim($newit618_group_id_array[$key]),
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_img' => trim($newit618_img_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_chat_lang['s33'].$ok1.' '.$it618_chat_lang['s34'].$ok2.' '.$it618_chat_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_face&pmod=admin_face&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_dao')){
	 DB::query("DELETE FROM ".DB::table('it618_chat_face')." WHERE it618_group_id=$groupid");
	
	for($i=1;$i<=132;$i++){
		C::t('#it618_chat#it618_chat_face')->insert(array(
			  'it618_group_id' => $groupid,
			  'it618_name' => $i,
			  'it618_img' => "source/plugin/it618_chat/app_chat/face/qq/$i.gif",
			  'it618_order' => $i
		  ), true);	
	}

	cpmsg($it618_chat_lang['s184'], "action=plugins&identifier=$identifier&cp=admin_face&pmod=admin_face&operation=$operation&do=$do&page=1".$urlsql, 'succeed');
}

if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com

if($_GET['beforeword']) {
	$extrasql .= " AND it618_name LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_face&pmod=admin_face&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_chat_lang['s25'],'it618_chat_face');
	showsubmit('it618sercsubmit', $it618_chat_lang['s39'], $it618_chat_lang['s40'].' <input name="beforeword" value="'.$_GET['beforeword'].'" class="txt" /><input style="float:right" type="submit" class="btn" name="it618submit_dao" value="'.$it618_chat_lang['s182'].'" onclick="return confirm(\''.$it618_chat_lang['s183'].'\')" />');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_face')." w WHERE $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_face&pmod=admin_face&operation=$operation&do=$do$urlsql");
	
	echo '<tr><td colspan=15>'.$it618_chat_lang['s28'].$count.'<span style="float:right"><a href="https://www.cnit618.com/image/qq.zip" target="_blank">'.$it618_chat_lang['s185'].'</a></span></td></tr>';
	showsubtitle(array('',$it618_chat_lang['s44'], $it618_chat_lang['s32'], $it618_chat_lang['s37'],$it618_chat_lang['s38']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_chat_face')." WHERE $extrasql ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_chat_face = DB::fetch($query)) {
		
		$tmp1=str_replace('<option value='.$it618_chat_face['it618_group_id'].'>','<option value='.$it618_chat_face['it618_group_id'].' selected="selected">',$tmp);
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id$it618_chat_face[id]\" name=\"delete[]\" value=\"$it618_chat_face[id]\"><label for=\"id$it618_chat_face[id]\">$it618_chat[id]</label>",
			'<select name="it618_group_id['.$it618_chat_face[id].']">'.$tmp1.'</select>',
			"<input type=\"text\" class=\"txt\" style=\"width:180px\" name=\"it618_name[$it618_chat_face[id]]\" value=\"$it618_chat_face[it618_name]\">",
			'<img src="'.$it618_chat_face['it618_img'].'" id="img'.$it618_chat_face['id'].'" width="35" height="35" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" style="width:180px" id="url'.$it618_chat_face['id'].'" name="it618_img['.$it618_chat_face['id'].']" readonly="readonly" value="'.$it618_chat_face['it618_img'].'" /> <input type="button" id="image'.$it618_chat_face['id'].'" value="'.$it618_chat_lang['s41'].'" />',
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_chat_face['id'].']" value="'.$it618_chat_face['it618_order'].'">',
		));
		$editorjs.='K(\'#image'.$it618_chat_face['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_chat_face['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_chat_face['id'].'\').val(url);
								K(\'#img'.$it618_chat_face['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	global $_G;
if($reabc[4]!='8')return; //Dism_taobao-com

	loadcache('plugin');
	$it618_chat = $_G['cache']['plugin']['it618_chat'];
	
	echo '
	<link rel="stylesheet" href="source/plugin/it618_chat/kindeditor/themes/default/default.css" />
	<script charset="utf-8" src="source/plugin/it618_chat/kindeditor/kindeditor-min.js"></script>
	<script charset="utf-8" src="source/plugin/it618_chat/kindeditor/lang/zh_CN.js"></script>
	<script>
		KindEditor.ready(function(K) {
					var editor = K.editor({
						uploadJson : \'source/plugin/it618_chat/kindeditor/php/upload_json.php?imgwidth=1000'.$oss.'\',
						fileManagerJson : \'source/plugin/it618_chat/kindeditor/php/file_manager_json.php\',
						allowFileManager : true
					});
					'.$editorjs.'
				});
	</script>';

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$it618_chat_lang42=$it618_chat_lang['s42'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<select name="newit618_group_id[]">$tmp2</select>'], 
		[1,'<input type="text" class="txt" style="width:180px" name="newit618_name[]">'],
		[1, '$it618_chat_lang42'],
		[1,'<input class="txt" type="text" style="width:50px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com
showtablefooter(); //dism��taobao��com
?>