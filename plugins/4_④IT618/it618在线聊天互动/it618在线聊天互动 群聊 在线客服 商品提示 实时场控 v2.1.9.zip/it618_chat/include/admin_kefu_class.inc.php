<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; //d'.'i'.'sm.ta'.'o'.'bao.com
if(submitcheck('it618submit_edit')){
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_chat#it618_chat_kefu_class')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_isshare' => trim($_GET['it618_isshare'][$id])
			));
		}
	}

	cpmsg($it618_chat_lang['s148'], "action=plugins&identifier=$identifier&cp=admin_kefu_class&pmod=admin_kefu&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_ok')){
	$ok=0;
	
	if($reabc[8]!='a')return;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($delid);
		if(it618_chat_getpluginstate($it618_chat_kefu_class['it618_plugin'])){
			$it618_state=1;
			$ok=$ok+1;
		}else{
			$it618_state=0;
		}
			
		C::t('#it618_chat#it618_chat_kefu_class')->update($delid,array(
			'it618_state' => $it618_state,
		));
	}

	cpmsg($it618_chat_lang['s95'].$ok, "action=plugins&identifier=$identifier&cp=admin_kefu_class&pmod=admin_kefu&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_no')){
	$ok=0;
	
	if($reabc[8]!='a')return;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
			
		C::t('#it618_chat#it618_chat_kefu_class')->update($delid,array(
			'it618_state' => 0,
		));
		$ok=$ok+1;
	}

	cpmsg($it618_chat_lang['s96'].$ok, "action=plugins&identifier=$identifier&cp=admin_kefu_class&pmod=admin_kefu&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_kefu_class&pmod=admin_kefu&operation=$operation&do=$do");
showtableheaders($it618_chat_lang['s57'],'it618_chat_kefu_class');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_class')." w WHERE 1 $extrasql");
	
	echo '<tr><td colspan=10>'.$it618_chat_lang['s60'].$count.'<span style="float:right;">'.$it618_chat_lang['s61'].'</span></td></tr>';
	showsubtitle(array('',$it618_chat_lang['s67'],$it618_chat_lang['s180'],$it618_chat_lang['s59'],$it618_chat_lang['s68'], $it618_chat_lang['s169'], $it618_chat_lang['s63']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu_class')." WHERE 1 $extrasql ORDER BY id LIMIT $startlimit, $ppp");
	while($it618_chat_kefu_class =	DB::fetch($query)) {
		
		if($it618_chat_kefu_class['it618_state']==0){
			if(it618_chat_getpluginstate($it618_chat_kefu_class['it618_plugin'])){
				$it618_state='<font color=red>'.$it618_chat_lang['s66'].'</font>';
			}else{
				$it618_state='<font color=#999>'.$it618_chat_lang['s65'].'</font>';
			}
		}else{
			$it618_state='<font color=green>'.$it618_chat_lang['s64'].'</font>';
		}
		
		$it618_isshare='';$kefucountstr='';
		if($it618_chat_kefu_class['it618_plugin']=='it618_video'||$it618_chat_kefu_class['it618_plugin']=='it618_exam'||$it618_chat_kefu_class['it618_plugin']=='it618_brand'||$it618_chat_kefu_class['it618_plugin']=='it618_tuan'||$it618_chat_kefu_class['it618_plugin']=='it618_waimai'){
			if($it618_chat_kefu_class['it618_isshare']==1)$it618_isshare_checked='checked="checked"';else $it618_isshare_checked="";
			$it618_isshare='<input class="checkbox" type="checkbox" name="it618_isshare['.$it618_chat_kefu_class['id'].']" '.$it618_isshare_checked.' value="1">';
			
			$kefucount1 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu')." WHERE it618_cid=".$it618_chat_kefu_class['id']." and it618_sid>0 and it618_state=1");
			$kefucount2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu')." WHERE it618_cid=".$it618_chat_kefu_class['id']." and it618_sid>0 and it618_state=0");
			$kefucountstr=$it618_chat_lang['s113'].'(<font color=red>'.$kefucount1.'</font>) '.$it618_chat_lang['s114'].'(<font color=red>'.$kefucount2.'</font>)';
		}
		
		$diycount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_diy')." WHERE it618_cid=".$it618_chat_kefu_class['id']." and it618_sid=0");
		$kefucount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu')." WHERE it618_cid=".$it618_chat_kefu_class['id']." and it618_sid=0");
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id$it618_chat_kefu_class[id]\" name=\"delete[]\" value=\"$it618_chat_kefu_class[id]\">",
			'<div style="width:460px"><input class="txt" type="text" style="width:150px" name="it618_name['.$it618_chat_kefu_class['id'].']" value="'.$it618_chat_kefu_class['it618_name'].'">'.$it618_chat_kefu_class['it618_plugin'].'</div>',
			$it618_isshare,
			$kefucountstr,
			'<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_kefu&cp=admin_kefu_style&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_chat_kefu_class['id'].'">'.$it618_chat_lang['s84'].'</a> |
			<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_kefu&cp=admin_kefu_diy&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_chat_kefu_class['id'].'">'.$it618_chat_lang['s85'].'(<font color=red>'.$diycount.'</font>)</a> |
			<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_kefu&cp=admin_kefu_kefu&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_chat_kefu_class['id'].'">'.$it618_chat_lang['s86'].'(<font color=red>'.$kefucount.'</font>)</a>',
			'<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_kefu&cp=admin_kefu_wxsubscribe&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&cid='.$it618_chat_kefu_class['id'].'">'.$it618_chat_lang['s175'].'(<font color=red>'.strlen($it618_chat_kefu_class['it618_wxsubscribe_about']).'</font>)</a>',
			$it618_state
		));
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_chat_lang['s94'].'</label></td><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit_edit" value="'.$it618_chat_lang['s147'].'"/> <input type="submit" class="btn" name="it618submit_ok" value="'.$it618_chat_lang['s90'].'" onclick="return confirm(\''.$it618_chat_lang['s92'].'\')" /> <input type="submit" class="btn" name="it618submit_no" value="'.$it618_chat_lang['s91'].'" onclick="return confirm(\''.$it618_chat_lang['s93'].'\')"/> <font color=red>'.$it618_chat_lang['s181'].'</font></div></td></tr>';

	if(count($reabc)!=10)return; //d'.'is'.'m.tao'.'ba'.'o.com
showtablefooter(); //dism��taobao��com
?>