<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; //d'.'i'.'sm.ta'.'o'.'bao.com

$cid=intval($_GET['cid']);
$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($cid);

if(submitcheck('it618submit')){
	if($_GET['it618_issave']==1){
		$query = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu_class'));
		while($it618_tmp =	DB::fetch($query)) {
			C::t('#it618_chat#it618_chat_kefu_class')->update($it618_tmp['id'],array(
				'it618_wxsubscribe_about' => $_GET['it618_wxsubscribe_about'],
			));
		}
	}else{
		C::t('#it618_chat#it618_chat_kefu_class')->update($cid,array(
			'it618_wxsubscribe_about' => $_GET['it618_wxsubscribe_about'],
		));
	}

	cpmsg($it618_chat_lang['s176'], "action=plugins&identifier=$identifier&cp=admin_kefu_wxsubscribe&pmod=admin_kefu&operation=$operation&do=$do&cid=$cid", 'succeed');
}

$preurl=ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_kefu_class&pmod=admin_kefu&operation=$operation&do=$do";

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_kefu_wxsubscribe&pmod=admin_kefu&operation=$operation&do=$do&cid=$cid");
showtableheaders($it618_chat_kefu_class['it618_name'].$it618_chat_lang['s177'].' <a href="'.$preurl.'">'.$it618_chat_lang['s76'].'</a>','it618_chat_set');

echo '
<link rel="stylesheet" href="source/plugin/it618_chat/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_chat/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_chat/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_chat/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_chat/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_wxsubscribe_about"]\', {
			cssPath : \'source/plugin/it618_chat/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_chat/kindeditor/php/upload_json.php?imgwidth=1000'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_chat/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>

<tr><td width=800><textarea name="it618_wxsubscribe_about" style="width:800px;height:400px;visibility:hidden;">'.$it618_chat_kefu_class['it618_wxsubscribe_about'].'</textarea><br><span style="color:red;">'.$it618_chat_lang['s172'].'</span></td></tr>

<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_chat_lang['s77'].'" /><input type="checkbox" id="it618_issave" name="it618_issave" value="1" style="vertical-align:middle;"><label for="it618_issave">'.$it618_chat_lang['s179'].'</label></div></td></tr>
';
if(count($reabc)!=11)return; //d'.'ism.ta'.'o'.'bao.com
showtablefooter(); //dism��taobao��com

?>