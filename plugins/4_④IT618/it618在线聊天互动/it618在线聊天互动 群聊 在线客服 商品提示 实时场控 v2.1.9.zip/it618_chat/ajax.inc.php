<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['formhash']!=FORMHASH)exit;

require_once DISCUZ_ROOT.'./source/plugin/it618_chat/function.func.php';


if($_GET['ac']=="getipaddr"){
	$tmpaddr=it618_chat_getarea($_G['clientip']);
	if($tmpaddr=='')$tmpaddr=it618_chat_getarea($_G['clientip']);
	if($tmpaddr!='')$ipaddr='('.$tmpaddr.')';
	echo $ipaddr;exit;
}


if($_GET['ac']=="getforbidwords"){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/forbidwords.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/forbidwords.php';
	}
		
	echo 'it618_split'.FORMHASH.'it618_split'.$chatset_forbidwords;exit;
}


if($_GET['ac']=="getformhash"){
	echo 'it618_split'.FORMHASH;exit;
}


if($_GET['ac']=="kefu"){
	if($_G['uid']==0)exit;
	if($it618_chat_user=C::t('#it618_chat#it618_chat_user')->fetch_by_uid($_G['uid'])){
		if(isset($_GET['exit'])){
			$it618_time=0;
		}else{
			$tmparr=explode("@",$_GET['kids']);
			for($i=0;$i<count($tmparr);$i++){
				$kefuid=intval($tmparr[$i]);
				if($kefuid>0){
					$talkstr='';
					$allcount=0;
					$query = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu_talk')." WHERE it618_kid=".$kefuid." ORDER BY it618_time desc");
					if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
					while($it618_chat_kefu_talk = DB::fetch($query)) {
						if($it618_chat_kefu_talk['it618_uid']>0){
							$name=it618_chat_getusername($it618_chat_kefu_talk['it618_uid']);
							$u_avatarimg=it618_chat_discuz_uc_avatar($it618_chat_kefu_talk['it618_uid'],'middle');
							if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
						}else{
							$name=$it618_chat_lang['s129'].$it618_chat_kefu_talk['id'];
							$u_avatarimg='source/plugin/it618_chat/images/user.jpg';
						}
						
						if(date("d",$it618_chat_kefu_talk['it618_time'])<date("d")){
							$it618_time=date('Y-m-d', $it618_chat_kefu_talk['it618_time']);
						}else{
							$it618_time=date('H:i:s', $it618_chat_kefu_talk['it618_time']);
						}
						if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
						$it618_count='';
						if($it618_chat_kefu_talk['it618_count']>0){
							if($_GET['wap']==1)$waplabel='style="padding-top:6px"';
							$it618_count='<span class="label label-success"	'.$waplabel.'>'.$it618_chat_kefu_talk['it618_count'].'</span>';
							$allcount=$allcount+$it618_chat_kefu_talk['it618_count'];
						}
						if($it618_chat_kefu_talk['it618_addr']==''){
							$it618_addr=it618_chat_getarea($it618_chat_kefu_talk['it618_ip']);
							C::t('#it618_chat#it618_chat_kefu_talk')->update($it618_chat_kefu_talk['id'],array(
								'it618_addr' => $it618_addr
							));
						}else{
							$it618_addr=$it618_chat_kefu_talk['it618_addr'];
						}
						if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
						if($it618_chat_kefu_talk['it618_wap']==1){
							$it618_wap=$it618_chat_lang['s141'];
						}else{
							$it618_wap=$it618_chat_lang['s140'];
						}
						
						$tmpgoodsname=explode("it618chatgoodsurl",$it618_chat_kefu_talk['it618_bz']);
						$tmpgoodsname=explode("it618chatid",$tmpgoodsname[0]);
						
						if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
						$talkstr.='<li id="litalk'.$it618_chat_kefu_talk['id'].'"><a href="javascript:" onclick="getiframe('.$kefuid.','.$it618_chat_kefu_talk['id'].')"><table><tr><td class="submenuimgtd"><img src="'.$u_avatarimg.'"></td><td><span class="talktime">'.$it618_time.'</span>'.$name.'<br>'.$it618_count.'<font color=#999>'.$tmpgoodsname[0].'<br>'.$it618_wap.' '.$it618_addr.' '.$it618_chat_kefu_talk['it618_ip'].'</font></td></tr></table></a> </li>';
					}
					$alltalkstr.=$talkstr.'@@@it618@@@'.$allcount.'it618_split';
				}
			}
			
			$it618_time=$_G['timestamp'];
		}
		
		C::t('#it618_chat#it618_chat_user')->update($it618_chat_user['id'],array(
			'it618_time' => $it618_time
		));
		
		echo $alltalkstr.'it618_formhashsplit'.FORMHASH;

	}
	exit;
}


if($_GET['ac']=="kefuclient"){
	if($_G['uid']==0)exit;
	if(!$it618_chat_kefu_talk=C::t('#it618_chat#it618_chat_kefu_talk')->fetch_by_kid_uid($_GET['typeid'],$_G['uid'])){
		
		C::t('#it618_chat#it618_chat_kefu_talk')->update($it618_chat_kefu_talk['id'],array(
			'it618_usertime' => $_G['timestamp']
		));

	}
	exit;
}


if($_GET['ac']=="getchatcode"){
	if($it618_chat_topicwork=C::t('#it618_chat#it618_chat_topicwork')->fetch_by_it618_code($_GET['code'])){
		if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
		C::t('#it618_chat#it618_chat_topicwork')->delete_by_id($it618_chat_topicwork['id']);
		
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php')){
			include DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php';
		}
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/forbidwords.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/forbidwords.php';
		}
		
		$cmdkey=md5($adyun_dms_sub_key.$adyun_dms_s_key);
		
		if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
		echo 'it618_split'.$it618_chat_topicwork['it618_topic'].'it618_split'.$adyun_dms_sub_key.'it618_split'.$chatset_forbidwords.'it618_split'.$cmdkey;
	}

	exit;
}


if($_GET['ac']=="getuseronline"){

	if(!$it618_chat_user_online=C::t('#it618_chat#it618_chat_user_online')->fetch_by_it618_topicid_clientid($_GET['topicid'],$_GET['clientid'])){
		
		$tmparr=explode('_',$_GET['clientid']);
		if(count($tmparr)==2&&$tmparr[0]=='u'){
			$it618_uid=$tmparr[1];
		}
	
		C::t('#it618_chat#it618_chat_user_online')->insert(array(
			'it618_topicid' => $_GET['topicid'],
			'it618_clientid' => $_GET['clientid'],
			'it618_uid' => $it618_uid,
			'it618_isonline' => 1,
			'it618_time' => $_G['timestamp']
		), true);

	}else{
		C::t('#it618_chat#it618_chat_user_online')->update($it618_chat_user_online['id'],array(
			'it618_isonline' => $_GET['state'],
			'it618_time' => $_G['timestamp']
		));
	}
	
	DB::query("UPDATE ".DB::table('it618_chat_user_online')." set it618_isonline=0 WHERE it618_time<".($_G['timestamp']-10));
	
	$chatadminuids=explode(",",$it618_chat['chat_adminuids'].','.it618_chat_adminuids($_GET['topicid']));
	if(in_array($_G['uid'], $chatadminuids)){
		$adminpower=1;
	}else if($it618_chat_user_online['it618_isadmin']==1){
		$adminpower=2;
	}
	
	foreach(C::t('#it618_chat#it618_chat_user_online')->fetch_all_by_it618_topicid_online($_GET['topicid']) as $it618_chat_user_online) {
		$tmparr=explode('_',$it618_chat_user_online['it618_clientid']);
		
		if($tmparr[0]=='u'){
			$u_avatarimg=it618_chat_discuz_uc_avatar($tmparr[1],'middle');
			$username=it618_chat_getusername($tmparr[1]);
		}else{
			$u_avatarimg='source/plugin/it618_chat/images/user.jpg';
			$username=$it618_chat_lang['t1'].$tmparr[1];
		}

		$tmpstr='';
		
		if($adminpower==1||($adminpower==2&&$it618_chat_user_online['it618_isadmin']==0)){
			if($it618_chat_user_online['it618_ispb']==1){
				$tmpstr.='<img src="source/plugin/it618_chat/images/pb1.png" class="gray" title="'.$it618_chat_lang['s216'].'" onclick="chatuserset('.$it618_chat_user_online['id'].',\'delpb\',\''.$username.'\')">';
			}else{
				$tmpstr.='<img src="source/plugin/it618_chat/images/pb0.png" title="'.$it618_chat_lang['s215'].'" onclick="chatuserset('.$it618_chat_user_online['id'].',\'pb\',\''.$username.'\')">';
			}
			
			if($it618_chat_user_online['it618_isjy']==1){
				$tmpstr.='<img src="source/plugin/it618_chat/images/jy1.png" title="'.$it618_chat_lang['s214'].'" onclick="chatuserset('.$it618_chat_user_online['id'].',\'deljy\',\''.$username.'\')">';
			}else{
				$tmpstr.='<img src="source/plugin/it618_chat/images/jy0.png" title="'.$it618_chat_lang['s213'].'" onclick="chatuserset('.$it618_chat_user_online['id'].',\'jy\',\''.$username.'\')">';
			}
			
		}
		
		if($adminpower==1&&$it618_chat_user_online['it618_uid']>0){
			if($it618_chat_user_online['it618_isadmin']==1){
				$tmpstr.='<img src="source/plugin/it618_chat/images/chatadmin1.png" title="'.$it618_chat_lang['s212'].'" onclick="chatuserset('.$it618_chat_user_online['id'].',\'deladmin\',\''.$username.'\')">';
			}else{
				
				$tmpstr.='<img src="source/plugin/it618_chat/images/chatadmin0.png" title="'.$it618_chat_lang['s211'].'" onclick="chatuserset('.$it618_chat_user_online['id'].',\'admin\',\''.$username.'\')">';
			}
		}
		
		$atstr='<img src="source/plugin/it618_chat/images/at.png" onclick="chatuserset('.$it618_chat_user_online['id'].',\'at\',\''.$username.'\')">';
		
		$it618_uid=0;
		$tmparr=explode('_',$it618_chat_user_online['it618_clientid']);
		if(count($tmparr)==2&&$tmparr[0]=='u'){
			$it618_uid=$tmparr[1];
		}
		
		if(in_array($it618_uid, $chatadminuids)){
			$adminstr1.='<tr><td class="chatuserimg"><img src="'.$u_avatarimg.'"></td><td class="chatuserset">
			<img src="source/plugin/it618_chat/images/chatadmin.png">'.$atstr.'
			'.$username.'
			</td></tr>';
		}else{
			if($it618_chat_user_online['it618_isadmin']==1){
				if($tmpstr=='')$tmpstr='<img src="source/plugin/it618_chat/images/chatadmin1.png">';
				$adminstr2.='<tr><td class="chatuserimg"><img src="'.$u_avatarimg.'"></td><td class="chatuserset">
				'.$tmpstr.''.$atstr.'
				'.$username.'
				</td></tr>';
			}else{
				$usersstr.='<tr><td class="chatuserimg"><img src="'.$u_avatarimg.'"></td><td class="chatuserset">
				'.$tmpstr.''.$atstr.'
				'.$username.'
				</td></tr>';
			}
		}
	}
	
	if($adminpower==1){
		if($it618_chat_topic=C::t('#it618_chat#it618_chat_topic')->fetch_by_id($_GET['topicid'])){
			if($it618_chat_topic['it618_isjy']==1){
				$tmpstr='<img src="source/plugin/it618_chat/images/jy1.png" title="'.$it618_chat_lang['s214'].'" onclick="chatuserset(0,\'alldeljy\',\''.$it618_chat_lang['s230'].'\')">';
			}else{
				$tmpstr='<img src="source/plugin/it618_chat/images/jy0.png" title="'.$it618_chat_lang['s213'].'" onclick="chatuserset(0,\'alljy\',\''.$it618_chat_lang['s230'].'\')">';
			}

			$allusersstr.='<tr><td class="chatuserimg"><img src="source/plugin/it618_chat/images/allusers.png"></td><td class="chatuserset">
					'.$tmpstr.'
					'.$it618_chat_lang['s230'].'
					</td></tr>';
		}
	}
	
	echo $adminstr1.$adminstr2.$allusersstr.$usersstr;
	exit;
}


if($_GET['ac']=="getuseronline1"){
	
	if($it618_chat_user_online=C::t('#it618_chat#it618_chat_user_online')->fetch_by_it618_topicid_clientid($_GET['topicid'],$_GET['clientid'])){
		C::t('#it618_chat#it618_chat_user_online')->update($it618_chat_user_online['id'],array(
			'it618_isonline' => 1,
			'it618_time' => $_G['timestamp']
		));
	}
	exit;
}


if($_GET['ac']=="delbyuuid"){
	if($it618_chat_topic=C::t('#it618_chat#it618_chat_topic')->fetch_by_id($_GET['topicid'])){
		$tmparr=explode("it618chatid",$_GET['uuid']);
		if(count($tmparr)>1){
			C::t('#it618_chat#it618_chat_topic_del')->insert(array(
				'it618_delid' => $tmparr[1]
			), true);
		}else{
			mds_api_curl("","/v1/historys/".$it618_chat_topic['it618_topic']."/uuid/".$_GET['uuid'],"DELETE");
		}
	}
	exit;
}


if($_GET['ac']=="chatuserset"){
	$chatadminuids=explode(",",$it618_chat['chat_adminuids'].','.it618_chat_adminuids($_GET['topicid']));
	if(in_array($_G['uid'], $chatadminuids)){
		$adminpower=1;
	}
	
	if($_GET['useset']=="admin"||$_GET['useset']=="deladmin"||$_GET['useset']=="alljy"||$_GET['useset']=="alldeljy"){
		if($adminpower!=1){
			echo $it618_chat_lang['s209'];exit;
		}
	}else{
		if($adminpower!=1){
			if(C::t('#it618_chat#it618_chat_user_online')->isadmin_by_it618_topic_uid($it618_chat_user_online['topicid'],$_G['uid'])==0){
				echo $it618_chat_lang['s209'];exit;
			}
		}
	}
	
	if($_GET['useset']=="alljy"||$_GET['useset']=="alldeljy"){
		if($it618_chat_topic=C::t('#it618_chat#it618_chat_topic')->fetch_by_id($_GET['topicid'])){
			if($_GET['useset']=="alljy"){
				C::t('#it618_chat#it618_chat_topic')->update($it618_chat_topic['id'],array(
					'it618_isjy' => 1
				));
				echo 'it618_splitokit618_splitit618_split'.$it618_chat_lang['s221'];exit;
			}
			if($_GET['useset']=="alldeljy"){
				C::t('#it618_chat#it618_chat_topic')->update($it618_chat_topic['id'],array(
					'it618_isjy' => 0
				));
				echo 'it618_splitokit618_splitit618_split'.$it618_chat_lang['s222'];exit;
			}
		}
	}else{
		
		if($it618_chat_user_online=C::t('#it618_chat#it618_chat_user_online')->fetch_by_id($_GET['onlineid'])){
	
			if($_GET['useset']=="jy"){
				C::t('#it618_chat#it618_chat_user_online')->update($it618_chat_user_online['id'],array(
					'it618_isjy' => 1
				));
				echo 'it618_splitokit618_split'.$it618_chat_user_online['it618_clientid'].'it618_split'.$it618_chat_lang['s221'];exit;
			}
			if($_GET['useset']=="deljy"){
				C::t('#it618_chat#it618_chat_user_online')->update($it618_chat_user_online['id'],array(
					'it618_isjy' => 0
				));
				echo 'it618_splitokit618_split'.$it618_chat_user_online['it618_clientid'].'it618_split'.$it618_chat_lang['s222'];exit;
			}
			if($_GET['useset']=="pb"){
				C::t('#it618_chat#it618_chat_user_online')->update($it618_chat_user_online['id'],array(
					'it618_ispb' => 1
				));
				echo 'it618_splitokit618_split'.$it618_chat_user_online['it618_clientid'].'it618_split'.$it618_chat_lang['s223'];exit;
			}
			if($_GET['useset']=="delpb"){
				C::t('#it618_chat#it618_chat_user_online')->update($it618_chat_user_online['id'],array(
					'it618_ispb' => 0
				));
				echo 'it618_splitokit618_split'.$it618_chat_user_online['it618_clientid'].'it618_split'.$it618_chat_lang['s224'];exit;
			}
			if($_GET['useset']=="admin"){
				C::t('#it618_chat#it618_chat_user_online')->update($it618_chat_user_online['id'],array(
					'it618_isadmin' => 1
				));
				echo 'it618_splitokit618_split'.$it618_chat_user_online['it618_clientid'].'it618_split'.$it618_chat_lang['s225'];exit;
			}
			if($_GET['useset']=="deladmin"){
				C::t('#it618_chat#it618_chat_user_online')->update($it618_chat_user_online['id'],array(
					'it618_isadmin' => 0
				));
				echo 'it618_splitokit618_split'.$it618_chat_user_online['it618_clientid'].'it618_split'.$it618_chat_lang['s226'];exit;
			}
		}else{
			echo $it618_chat_lang['s217'];exit;
		}
	}
	exit;
}


if($_GET['ac']=="mds_api"){
	$rst = mds_api($_GET);
	
	echo json_encode($rst);
	exit;
}


if($_GET['ac']=="topicsaveset"){
	if($_G['uid']==0)exit;
	$chatadminuids=explode(",",$it618_chat['chat_adminuids'].','.it618_chat_adminuids($_GET['topicid']));
	if(!in_array($_G['uid'], $chatadminuids)){
		echo $it618_chat_lang['s27'];exit;
	}
	C::t('#it618_chat#it618_chat_topic')->update($_GET['topicid'],array(
		'it618_ischatusers' => $_GET['it618_ischatusers'],
		'it618_iscomein' => $_GET['it618_iscomein'],
		'it618_onlinecount' => $_GET['it618_onlinecount']
	));
	echo 'it618_splitokit618_split'.$it618_chat_lang['s192'];
	exit;
}
//From: d'.'is'.'m.ta'.'obao.com
?>