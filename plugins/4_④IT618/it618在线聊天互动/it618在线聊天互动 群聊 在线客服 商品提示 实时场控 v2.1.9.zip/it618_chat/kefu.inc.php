<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_chat;

$it618_chat = $_G['cache']['plugin']['it618_chat'];
require_once DISCUZ_ROOT.'./source/plugin/it618_chat/function.func.php';

if(chat_is_mobile()){
	$wap=1;
	$waplabel='style="padding-top:6px"';
}

if($_G['uid']==0){
	if($wap==1){
		echo '<font color=red>'.$it618_chat_lang['s1'].'</font> <a href="javascript:" onclick="parent.location.href=\'member.php?mod=logging&action=login&referer=\'+encodeURIComponent(parent.location.href)">'.$it618_chat_lang['s62'].'</a>';exit;
	}else{
		echo '<font color=red>'.$it618_chat_lang['s1'].'</font>';exit;
	}
}

if(C::t('#it618_chat#it618_chat_kefu')->count_by_uid($_G['uid'])==0){
	echo '<font color=red>'.$it618_chat_lang['s134'].'</font>';exit;
}

if($it618_chat_user=C::t('#it618_chat#it618_chat_user')->fetch_by_uid($_G['uid'])){
	if($it618_chat_user['it618_time']+2>$_G['timestamp']){
		echo '<font color=red>'.$_G['username'].$it618_chat_lang['s136'].'</font>';exit;
	}
	C::t('#it618_chat#it618_chat_user')->update($it618_chat_user['id'],array(
		'it618_time' => $_G['timestamp']
	));
}else{
	C::t('#it618_chat#it618_chat_user')->insert(array(
		'it618_uid' => $_G['uid'],
		'it618_time' => $_G['timestamp']
	), true);
}

$query = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu')." WHERE it618_uid=".$_G['uid']." and it618_state=1 ORDER BY it618_cid");
while($it618_chat_kefu = DB::fetch($query)) {
	
	$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($it618_chat_kefu['it618_cid']);
	
	$shopname=it618_chat_getshopname($it618_chat_kefu_class['it618_plugin'],$it618_chat_kefu['it618_sid']);
	if($shopname!='')$shopname='-'.$shopname;
	
	$kefuids.=$it618_chat_kefu['id'].'@';
	
	$kefustr.='<li class="sidebar-dropdown">
					<a  href="javascript:" class="menua" id="menua'.$it618_chat_kefu['id'].'"><span class="label label-success" '.$waplabel.' id="menucount'.$it618_chat_kefu['id'].'"></span><span class="spantitle">'.$it618_chat_kefu_class['it618_name'].$shopname.'-'.$it618_chat_kefu['it618_name'].'</span></a>
					<div class="sidebar-submenu">
						<ul id="submenu'.$it618_chat_kefu['id'].'">
						</ul>
					</div>
				</li>';
}

if($it618_chat_kefu_talk=C::t('#it618_chat#it618_chat_kefu_talk')->fetch_by_id($_GET['tid'])){
	$kid=$it618_chat_kefu_talk['it618_kid'];
}

$u_avatarimg=it618_chat_discuz_uc_avatar($_G['uid'],'middle');

$groupid=$_G['groupid'];
if($groupid>0)$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);

$bootstrap='https://cdn.bootcss.com/bootstrap/3.3.7/';
$awesome='https://cdn.bootcss.com/font-awesome/4.7.0/';

$_G['mobiletpl'][IN_MOBILE]='/'; //DisM �� Taobao �� Com
include template('it618_chat:kefu');
?>