<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_chat_onepage_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_oid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_facegroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_img` varchar(255) NOT NULL DEFAULT '',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_face` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_group_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_img` varchar(255) NOT NULL DEFAULT '',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_kefu_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_plugin` varchar(50) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_style1` mediumtext NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_kefu_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_sid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_title` varchar(300) NOT NULL,
  `it618_content` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_kefu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_sid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_avatarimg` varchar(100) NOT NULL,
  `it618_name` varchar(100) NOT NULL,
  `it618_tel` varchar(15) NOT NULL,
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_kefu_talk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_kid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_topic` varchar(255) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ip` varchar(50) NOT NULL,
  `it618_addr` varchar(255) NOT NULL,
  `it618_wap` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_topic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_topic` varchar(255) NOT NULL,
  `it618_onlinecount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_topic_del` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_delid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_user_online`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_user_online` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_topicid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_clientid` varchar(255) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isonline` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isadmin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isjy` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ispb` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_chat_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_chat_onepage'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_isuser', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_onepage')." add `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1';";
	DB::query($sql);
}
if(!in_array('it618_isip', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_onepage')." add `it618_isip` int(10) unsigned NOT NULL DEFAULT '1';";
	DB::query($sql);
}
if(!in_array('it618_isaddr', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_onepage')." add `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '1';";
	DB::query($sql);
}
if(!in_array('it618_uids', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_onepage')." add `it618_uids` varchar(3000) NOT NULL;";
	DB::query($sql);
}
if(!in_array('it618_adminuids', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_onepage')." add `it618_adminuids` varchar(1000) NOT NULL;";
	DB::query($sql);
}
if(!in_array('it618_order', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_onepage')." add `it618_order` int(10) unsigned NOT NULL DEFAULT '0';";
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_chat_kefu_class'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_name', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_kefu_class')." add `it618_name` varchar(50) NOT NULL;";
	DB::query($sql);
}

if(!in_array('it618_wxsubscribe_about', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_kefu_class')." add `it618_wxsubscribe_about` mediumtext NOT NULL;";
	DB::query($sql);
}

if(!in_array('it618_style1_ico', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_kefu_class')." add `it618_style1_ico` int(10) unsigned NOT NULL DEFAULT '1';";
	DB::query($sql);
}

if(!in_array('it618_style1_wapico', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_kefu_class')." add `it618_style1_wapico` int(10) unsigned NOT NULL DEFAULT '1';";
	DB::query($sql);
}

if(!in_array('it618_isshare', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_kefu_class')." add `it618_isshare` int(10) unsigned NOT NULL DEFAULT '0';";
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_chat_topic'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_ischatusers', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_topic')." add `it618_ischatusers` int(10) unsigned NOT NULL DEFAULT '1';";
	DB::query($sql);
}

if(!in_array('it618_iscomein', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_topic')." add `it618_iscomein` int(10) unsigned NOT NULL DEFAULT '1';";
	DB::query($sql);
}

if(!in_array('it618_isjy', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_topic')." add `it618_isjy` int(10) unsigned NOT NULL DEFAULT '0';";
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_chat_kefu'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_uids', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_kefu')." add `it618_uids` varchar(1000) NOT NULL;";
	DB::query($sql);
}

if(!in_array('it618_iswxsubscribe', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_kefu')." add `it618_iswxsubscribe` int(10) unsigned NOT NULL DEFAULT '0';";
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_chat_kefu_talk'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_userbz', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_kefu_talk')." add `it618_userbz` varchar(1000) NOT NULL;";
	DB::query($sql);
}

if(!in_array('it618_usertime', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_kefu_talk')." add `it618_usertime` int(10) unsigned NOT NULL DEFAULT '0';";
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_chat_topicwork'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_tid', $col_field)){
	$sql = "Alter table ".DB::table('it618_chat_topicwork')." add `it618_tid` int(10) unsigned NOT NULL DEFAULT '0';";
	DB::query($sql);
}

$sql = "Alter table ".DB::table('it618_chat_kefu_diy')." modify column `it618_content` varchar(8000) NOT NULL;"; 
DB::query($sql);




//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0LnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0X1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0X1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0X1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0X1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvaW5zdGFsbC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvdXBncmFkZS5waHA='));
?>