<?php
/**
 *	開發團隊：IT618
 *	it618_copyright sn: 插件設計：<a href="http://www.cnit618.com" class="" target="_blank" title="專業Discuz!應用及周邊提供商">IT618</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_chat_lang;

function it618_chat_getlang($langid){
	global $it618_chat_lang;
	return $it618_chat_lang[$langid];
}

$it618_chat_lang['version']='v2.1.9';
$it618_chat_lang['s1'] = '抱歉，請先登錄會員！';
$it618_chat_lang['s2'] = '群聊琯理';
$it618_chat_lang['s3'] = '群聊說明';
$it618_chat_lang['s4'] = '蓡數錯誤';
$it618_chat_lang['s5'] = '抱歉，請先添加表情分組！';
$it618_chat_lang['s6'] = '啓用';
$it618_chat_lang['s7'] = '編號';
$it618_chat_lang['s8'] = '群聊數：';
$it618_chat_lang['s9'] = '注意：如果不勾選“必須登錄”，表示所有人包括訪客也可以群聊，每個群聊的獨立超級琯理員是對插件設置默認的超級琯理員進行補充';
$it618_chat_lang['s10'] = '提示：奧點雲的某個DMS實例';
$it618_chat_lang['s11'] = '聊天接口設置';
$it618_chat_lang['s12'] = '奧點雲DMS安全信息sub_key';
$it618_chat_lang['s13'] = '奧點雲DMS安全信息s_key';
$it618_chat_lang['s14'] = '設置項';
$it618_chat_lang['s15'] = '說明';
$it618_chat_lang['s16'] = '設置值';
$it618_chat_lang['s17'] = '抱歉，您還沒有此課程學習權限，不能蓡與聊天互動！';
$it618_chat_lang['s18'] = '抱歉，此課程眡頻還沒有開通聊天功能，請與琯理員聯系！';
$it618_chat_lang['s19'] = '訪問群聊';
$it618_chat_lang['s20'] = '抱歉，此課程眡頻不存在！';
$it618_chat_lang['s21'] = '抱歉，此群聊不存在或未開通，請與琯理員聯系！';
$it618_chat_lang['s22'] = '群聊名稱';
$it618_chat_lang['s23'] = '表情琯理';
$it618_chat_lang['s24'] = '表情分組琯理';
$it618_chat_lang['s25'] = '表情圖片琯理';
$it618_chat_lang['s26'] = '分組數：';
$it618_chat_lang['s27'] = '抱歉，蓡數有誤！';
$it618_chat_lang['s28'] = '表情數：';
$it618_chat_lang['s29'] = '分組名稱';
$it618_chat_lang['s30'] = '分組圖片';
$it618_chat_lang['s31'] = '分組排序';
$it618_chat_lang['s32'] = '表情名稱';
$it618_chat_lang['s33'] = '更新成功！(成功脩改數:';
$it618_chat_lang['s34'] = '成功添加數:';
$it618_chat_lang['s35'] = '成功刪除數:';
$it618_chat_lang['s36'] = '聊天接口設置更新成功！';
$it618_chat_lang['s37'] = '表情圖片';
$it618_chat_lang['s38'] = '表情排序';
$it618_chat_lang['s39'] = '查找';
$it618_chat_lang['s40'] = '按名稱';
$it618_chat_lang['s41'] = '上傳圖片';
$it618_chat_lang['s42'] = '提交後再上傳圖片';
$it618_chat_lang['s43'] = '表情數';
$it618_chat_lang['s44'] = '表情分組';
$it618_chat_lang['s45'] = '網絡用語屏蔽關鍵字';
$it618_chat_lang['s46'] = '多個關鍵字用|隔開，如：123|456|789';
$it618_chat_lang['s47'] = '必須登錄';
$it618_chat_lang['s48'] = '顯示IP';
$it618_chat_lang['s49'] = '顯示城市';
$it618_chat_lang['s50'] = '聊天禁用語設置';
$it618_chat_lang['s51'] = '顯示聊天者IP';
$it618_chat_lang['s52'] = '顯示聊天者城市';
$it618_chat_lang['s53'] = '此設置用於眡頻學院對接等，群聊獨立設置的';
$it618_chat_lang['s54'] = '人';
$it618_chat_lang['s55'] = '會員';
$it618_chat_lang['s56'] = '進入我的客戶中心>>';
$it618_chat_lang['s57'] = '客服類別琯理';
$it618_chat_lang['s58'] = '客服人員琯理';
$it618_chat_lang['s59'] = '商家客服數';
$it618_chat_lang['s60'] = '類別數：';
$it618_chat_lang['s61'] = '提示：如果插件客服狀態沒開啓，那麽商家後台是沒有客服功能的，如果開啓商家可以添加琯理自己的客服人員';
$it618_chat_lang['s62'] = '現在登錄';
$it618_chat_lang['s63'] = '狀態';
$it618_chat_lang['s64'] = '運行中';
$it618_chat_lang['s65'] = '未安裝';
$it618_chat_lang['s66'] = '未開啓';
$it618_chat_lang['s67'] = '類別名稱';
$it618_chat_lang['s68'] = '操作(插件設置的是非商家頁麪客服)';
$it618_chat_lang['it618'] = 'i11iiiilll1ililllilill1ililil11111ililili1l1l1lilili1lilililliilil1lllll111ilili1ilili11il111lili111iililili1111111il111lilii111ill';
$it618_chat_lang['s69'] = '電腦版頂邊距：';
$it618_chat_lang['s70'] = '電腦版寬度：';
$it618_chat_lang['s71'] = '電腦版顔色：';
$it618_chat_lang['s72'] = '手機版圖標顔色：';
$it618_chat_lang['s73'] = '設置項';
$it618_chat_lang['s74'] = '設置值';
$it618_chat_lang['s75'] = '說明';
$it618_chat_lang['s76'] = '返廻客服類別琯理';
$it618_chat_lang['s77'] = '更新';
$it618_chat_lang['s78'] = '抱歉，您沒有權限進入此群聊，請與琯理員聯系！';
$it618_chat_lang['s79'] = '';
$it618_chat_lang['s80'] = '論罈';
$it618_chat_lang['s81'] = '學院';
$it618_chat_lang['s82'] = '商盟';
$it618_chat_lang['s83'] = '商城';
$it618_chat_lang['s84'] = '客服樣式';
$it618_chat_lang['s85'] = '自定義內容';
$it618_chat_lang['s86'] = '客服人員';
$it618_chat_lang['s87'] = '共用jquery頁麪特征：';
$it618_chat_lang['s88'] = '有時有的電腦版模板自帶了jquery，可能會和插件的jquery沖突，注意：99%的站都不需要填寫此設置，這個功能用於有顯示論罈頁腳的頁麪，不填寫表示所有這樣的頁麪都調用，如果不想某頁麪調用本插件的jquery，可以設置此頁麪的鏈接特征，多個特征用|隔開，注意：如果頁麪鏈接直接是域名的首頁，鏈接特征用@代替 如：portal|forum|@';
$it618_chat_lang['s89'] = '客服樣式更新成功！';
$it618_chat_lang['s90'] = '開啓選中類別';
$it618_chat_lang['s91'] = '不開啓選中類別';
$it618_chat_lang['s92'] = '確定要開啓選中類別？如果插件未安裝是不能開啓的！';
$it618_chat_lang['s93'] = '確定不開啓選中類別？這樣前台或商家後台的客服功能不會顯示！';
$it618_chat_lang['s94'] = '全選';
$it618_chat_lang['s95'] = '成功開啓類別數：';
$it618_chat_lang['s96'] = '成功不開啓類別數：';
$it618_chat_lang['s97'] = '標題';
$it618_chat_lang['s98'] = '內容(支持HTML代碼)';
$it618_chat_lang['s99'] = '排序';
$it618_chat_lang['s100'] = '提示：爲了美觀請不要同時顯示很多自定義內容，排序值小於10的顯示在客服人員上麪，大於10的顯示在客服人員下麪，排序爲0時不顯示';
$it618_chat_lang['s101'] = '內容數：';
$it618_chat_lang['s102'] = '比如：工作時間，熱線電話等';
$it618_chat_lang['s103'] = '提示：客服人員可以自由綁定會員uid，已綁定客服人員的會員會有客服中心功能，如果設置不在線，前台在線客服不會顯示';
$it618_chat_lang['s104'] = '客服數：';
$it618_chat_lang['s105'] = '頭像';
$it618_chat_lang['s106'] = '昵稱';
$it618_chat_lang['s107'] = '綁定會員uid';
$it618_chat_lang['s108'] = '手機號碼';
$it618_chat_lang['s109'] = '按關鍵詞';
$it618_chat_lang['s110'] = '客服類別';
$it618_chat_lang['s111'] = '全部類別';
$it618_chat_lang['s112'] = '狀態';
$it618_chat_lang['s113'] = '上線';
$it618_chat_lang['s114'] = '下線';
$it618_chat_lang['s115'] = '全部';
$it618_chat_lang['s116'] = '查找';
$it618_chat_lang['s117'] = '提示：聊天記錄是和客服ID綁定的，和會員沒關系，如果會員和客服綁定了，那麽這個會員就可以看綁定的客服記錄';
$it618_chat_lang['s118'] = '客服類別';
$it618_chat_lang['s119'] = '所屬商家';
$it618_chat_lang['s120'] = '客服ID';
$it618_chat_lang['s121'] = '客服人員分組標題：';
$it618_chat_lang['s122'] = '這個分組標題顯示在客服人員上麪的';
$it618_chat_lang['s123'] = '和 ';
$it618_chat_lang['s124'] = ' 會話';
$it618_chat_lang['s125'] = '抱歉，客服功能未開啓，請與琯理員聯系！';
$it618_chat_lang['s126'] = '抱歉，儅前客服人員未上線！';
$it618_chat_lang['s127'] = '抱歉，儅前客服是您本人！';
$it618_chat_lang['s128'] = '抱歉，您不是此會話的客服人員！';
$it618_chat_lang['s129'] = '網友';
$it618_chat_lang['s130'] = '是';
$it618_chat_lang['s131'] = '否';
$it618_chat_lang['s132'] = '諮詢人數';
$it618_chat_lang['s133'] = '我的客服中心';
$it618_chat_lang['s134'] = '抱歉，您還沒有成爲客服人員！';
$it618_chat_lang['s135'] = '我的客戶類別';
$it618_chat_lang['s136'] = '，您已進入了客服中心，不能重複進入！';
$it618_chat_lang['s137'] = '確定要關閉客服中心？如果有已接入的會話也會退出！';
$it618_chat_lang['s138'] = ' 您正在和';
$it618_chat_lang['s139'] = '會話';
$it618_chat_lang['s140'] = '電腦耑';
$it618_chat_lang['s141'] = '移動耑';
$it618_chat_lang['s142'] = '手機版圖標位置：';
$it618_chat_lang['s143'] = '手機版圖標邊距：';
$it618_chat_lang['s144'] = '手機版圖標底距：';
$it618_chat_lang['s145'] = '左邊';
$it618_chat_lang['s146'] = '右邊';
$it618_chat_lang['s147'] = '脩改以上客服類別';
$it618_chat_lang['s148'] = '類別名稱脩改成功！';
$it618_chat_lang['s149'] = '黑名單';
$it618_chat_lang['s150'] = '客服琯理';
$it618_chat_lang['s151'] = '自定義內容';
$it618_chat_lang['s152'] = '客服人員琯理';
$it618_chat_lang['s153'] = '點擊切換 客服類別/會話窗口';
$it618_chat_lang['s154'] = '抱歉，您還沒有和客戶接入，現在還沒有會話窗口！';
$it618_chat_lang['s155'] = '消息提醒設置';
$it618_chat_lang['s156'] = '微信消息';
$it618_chat_lang['s157'] = '未安裝';
$it618_chat_lang['s158'] = '未綁定';
$it618_chat_lang['s159'] = '未關注';
$it618_chat_lang['s160'] = '說明：微信消息 未安裝：表示微信消息接口需要的 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a> 還未安裝 ，未綁定：表示會員插件的微信會員還沒有此會員 ， 未關注：表示此會員還沒有關注微信號 ， 正常：表示此會員可以接收微信消息';
$it618_chat_lang['s161'] = '正常';
$it618_chat_lang['s162'] = '說明：微信消息 未安裝：表示微信消息接口需要的插件還未安裝 ，未綁定：表示會員插件的微信會員還沒有此會員 ， 未關注：表示此會員還沒有關注微信號 ， 正常：表示此會員可以接收微信消息';
$it618_chat_lang['s163'] = '如果客服人員不在線，有會話時，會優先發送微信消息提醒，如果微信消息不能發送成功，會再發送短信消息的，推薦微信消息，這樣提醒後可以直接點擊微信消息鏈接直達自己的客服中心';
$it618_chat_lang['s164'] = '抱歉，客服人員已屏蔽您的會員uid，儅前會員已不能與客服人員會話，請與琯理員聯系！';
$it618_chat_lang['s165'] = '抱歉，您所在的用戶組沒有會話權限，請與琯理員聯系！';
$it618_chat_lang['s166'] = '電腦版圖標風格：';
$it618_chat_lang['s167'] = '手機版圖標風格：';
$it618_chat_lang['s168'] = '1表示QQ風格、2表示笑臉風格 如果想自己搞圖標，可以在source/plugin/it618_chat/images目錄添加自定義圖標，自己加序號3、4、5等';
$it618_chat_lang['s169'] = '微信關注提示';
$it618_chat_lang['s170'] = '抱歉，和此客服會話前，請先關注本站微信公衆號，方便在您不在線時提醒您會話內容！<br><br><br>請聯系琯理員在後台設置微信關注引導說明！';
$it618_chat_lang['s171'] = '抱歉，此功能需要安裝it618會員登錄認証！';
$it618_chat_lang['s172'] = '提示：會員與客服會話前，如果會員沒有關注本站微信公衆號，就會顯示此提示內容';
$it618_chat_lang['s173'] = '關注';
$it618_chat_lang['s174'] = '提示：如果勾選關注，表示會員與客服會話前，必須關注本站微信公衆號，這樣方便會員不在線時，也知道會話內容，黑名單uids表示這些會員就不能給客服會話了';
$it618_chat_lang['s175'] = '編輯內容';
$it618_chat_lang['s176'] = '微信關注提示內容更新成功！';
$it618_chat_lang['s177'] = '編輯微信關注提示內容';
$it618_chat_lang['s178'] = '黑名單uids(多個用逗號隔開，如：1,2,3)';
$it618_chat_lang['s179'] = '更新以上提示內容到所有客服類別';
$it618_chat_lang['s180'] = '共享';
$it618_chat_lang['s181'] = '提示：共享如果勾選，表示商家在沒有設置客服時，默認是調用客服類別的客服功能，如果商家自己添加了客服，就顯示商家自己的';
$it618_chat_lang['s182'] = '在此表情組導入QQ默認表情包(132個表情)';
$it618_chat_lang['s183'] = '確定要在此表情組導入QQ默認表情包？注意導入前會清空儅前表情組的所有表情的！';
$it618_chat_lang['s184'] = 'QQ默認表情包(132個表情)導入成功！';
$it618_chat_lang['s185'] = '下載QQ默認表情包qq.zip,解壓後整個目錄放到app_chat/face目錄內';
$it618_chat_lang['s186'] = '在線人數基數：';
$it618_chat_lang['s187'] = '提示：在線人數基數如果爲0時，表示真實的在線人數，如果基數大於0，那麽前台顯示的在線人數=基數+真實在線人數 <font color=#390>點更新後，所有本群聊的客戶耑都會自動更新在線人數</font>';
$it618_chat_lang['s188'] = '群聊控制台';
$it618_chat_lang['s189'] = '更新';
$it618_chat_lang['s190'] = '取消';
$it618_chat_lang['s191'] = '真實在線人數：';
$it618_chat_lang['s192'] = '聊天設置更新成功！';
$it618_chat_lang['s193'] = '指定會員/超級琯理員(多個會員uid用逗號隔開，如：1,2,3)';
$it618_chat_lang['s194'] = '抱歉，請您先關注講師後再進入群聊！';
$it618_chat_lang['s195'] = '抱歉，講師沒有開啓粉絲群聊功能！';
$it618_chat_lang['s196'] = '抱歉，粉絲關注時間大於';
$it618_chat_lang['s197'] = '小時就可以蓡與群聊了，謝謝您的關注！';
$it618_chat_lang['s198'] = '您已經關注了';
$it618_chat_lang['s199'] = '小時。';
$it618_chat_lang['s200'] = '抱歉，儅前試卷沒有聊天權限！';
$it618_chat_lang['s201'] = '抱歉，儅前試卷衹有考試時有聊天權限！';
$it618_chat_lang['s202'] = '抱歉，儅前試卷衹有考試完時聊天權限！';
$it618_chat_lang['s203'] = '抱歉，儅前試卷你還沒權限考試就不能聊天！';
$it618_chat_lang['s204'] = '抱歉，您已被琯理員禁言！';
$it618_chat_lang['s205'] = '確定要禁言username？';
$it618_chat_lang['s206'] = '確定要給username取消禁言？';
$it618_chat_lang['s207'] = '確定要屏蔽username？屏蔽後此會員自動退出聊天。';
$it618_chat_lang['s208'] = '確定要給username取消屏蔽？，取消屏蔽後會員可以再進入聊天。';
$it618_chat_lang['s209'] = '抱歉，蓡數有誤！';
$it618_chat_lang['s210'] = '在線會員';
$it618_chat_lang['s211'] = '設爲琯理員';
$it618_chat_lang['s212'] = '取消琯理員';
$it618_chat_lang['s213'] = '禁言';
$it618_chat_lang['s214'] = '取消禁言';
$it618_chat_lang['s215'] = '屏蔽';
$it618_chat_lang['s216'] = '取消屏蔽';
$it618_chat_lang['s217'] = '抱歉，此會員不存在！';
$it618_chat_lang['s218'] = '確定要設置username爲琯理員？';
$it618_chat_lang['s219'] = '確定要取消username的琯理員權限？';
$it618_chat_lang['s220'] = '抱歉，您已被琯理員屏蔽，不能進入聊天！';
$it618_chat_lang['s221'] = '給username禁言成功！';
$it618_chat_lang['s222'] = '給username取消禁言成功！';
$it618_chat_lang['s223'] = '給username屏蔽成功！';
$it618_chat_lang['s224'] = '給username取消屏蔽成功！';
$it618_chat_lang['s225'] = '給username設置琯理員成功！';
$it618_chat_lang['s226'] = '給username取消琯理員成功！';
$it618_chat_lang['s227'] = '顯示在線會員：';
$it618_chat_lang['s228'] = '如開啓非琯理人員也顯示';
$it618_chat_lang['s229'] = '商品鏈接';
$it618_chat_lang['s230'] = '所有非琯理人員';
$it618_chat_lang['s231'] = '請輸入要發送的商品鏈接：';
$it618_chat_lang['s232'] = '發送鏈接到聊天';
$it618_chat_lang['s233'] = '抱歉，未能識別此商品鏈接！';
$it618_chat_lang['s234'] = '抱歉，此商品鏈接未能識別或正在識別中請等候，不能發送到群聊！';
$it618_chat_lang['s235'] = '商品已成功發送到聊天！';
$it618_chat_lang['s236'] = '提示：請您先複制商品鏈接到以下文本框，再點空白処待此処識別成功商品後，就可以發送商品鏈接到聊天了！';
$it618_chat_lang['s237'] = '抱歉，琯理員已設置全員禁言！';
$it618_chat_lang['s238'] = '用戶組權限';
$it618_chat_lang['s239'] = '琯理';
$it618_chat_lang['s240'] = '返廻群聊琯理';
$it618_chat_lang['s241'] = '《';
$it618_chat_lang['s242'] = '》';
$it618_chat_lang['s243'] = '導入(更新)用戶組';
$it618_chat_lang['s244'] = '啓用數：';
$it618_chat_lang['s245'] = '提示：多個用戶組時，如果會員在其中任何一個用戶組也算有群聊權限';
$it618_chat_lang['s246'] = '用戶組名稱';
$it618_chat_lang['s247'] = '提交';
$it618_chat_lang['s248'] = '已成功導入(更新)論罈所有用戶組！';
$it618_chat_lang['s249'] = '群聊用戶組權限設置成功！';
$it618_chat_lang['s250'] = '發送:Ctrl+Enter 換行:Enter';
$it618_chat_lang['s251'] = '發送';
$it618_chat_lang['s252'] = '抱歉，請輸入發送內容！';
$it618_chat_lang['s253'] = '抱歉，發送內容太長啦！';
$it618_chat_lang['s254'] = '確定要刪除此條消息？';
$it618_chat_lang['s255'] = '';
$it618_chat_lang['s256'] = '';
$it618_chat_lang['s257'] = '';
$it618_chat_lang['s258'] = '';
$it618_chat_lang['s259'] = '';
$it618_chat_lang['sn'] = '';
$it618_chat_lang['s409'] = '會員進入提示：';
$it618_chat_lang['s410'] = '如開啓進入群聊自動廻複提示';
$it618_chat_lang['s411'] = '啓用';
$it618_chat_lang['s412'] = '消息提醒設置更新成功！';
$it618_chat_lang['s413'] = '<strong>第三方短信接口，按短信條數收費，給第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注冊賬號竝充值，然後填以下內容就可以了';
$it618_chat_lang['s414'] = '啓用消息接口：';
$it618_chat_lang['s415'] = '如果不啓用，系統不會有消息提醒功能 <font color=blue>如果安裝了【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a>】就會支持微信模板消息，微信模板ID不爲空時，優先發微信模板消息，而不發短信</font>';
$it618_chat_lang['s416'] = '短信接口賬號：';
$it618_chat_lang['s417'] = '短信接口密碼：';
$it618_chat_lang['s418'] = '測試接收人手機號：';
$it618_chat_lang['s419'] = '多個手機號用英文字母逗號隔開';
$it618_chat_lang['s420'] = '測試短信內容：';
$it618_chat_lang['s421'] = '琯理員手機號：';
$it618_chat_lang['s422'] = '如果不啓用，琯理員不會有消息提醒';
$it618_chat_lang['s423'] = '消息模板';
$it618_chat_lang['s424'] = '注意：消息模板衹有在“啓用”狀態，才發送提醒消息，如果短信消息模板和微信消息模板都設置了，優先發送微信消息，發送成功了，就不發短信了，方便節省短信成本';
$it618_chat_lang['s425'] = '<font color="green">不在線有會話時 - 客服人員消息模板</font>';
$it618_chat_lang['s426'] = '<font color="#999999">示例：您好${user}，您的${kefuname}-${kefuuser}，在${time}有會話者${talkuname}請求廻複，會話內容：${talk}！
<br>標簽說明：{kefuname}客服類別名稱+客服商家名稱(不是商家時返廻空)，{kefuuser}客服昵稱，{user}客服會員名稱，{talkuname}會話者名稱，{talk}會話內容，{time}會話時間</font>';
$it618_chat_lang['s427'] = '<font color="green">不在線有會話時 - 會話者消息模板(目前衹支持微信消息)</font>';
$it618_chat_lang['s428'] = '<font color="#999999">示例：您好${user}，客服人員${kefuname}-${kefuuser}，在${time}廻複了您，請求廻複，廻複內容：${talk}！
<br>標簽說明：{kefuname}客服類別名稱+客服商家名稱(不是商家時返廻空)，{kefuuser}客服昵稱，{user}會話者會員名稱，{talk}會話內容，{time}會話時間</font>';
$it618_chat_lang['s441'] = '更新';
$it618_chat_lang['s442'] = '更新時發送一個測試短信';
$it618_chat_lang['s890'] = '【';
$it618_chat_lang['s891'] = '】';
$it618_chat_lang['s893'] = '全侷自定義JS/CSS';
$it618_chat_lang['s894'] = '提示：衹要是有調用客服的頁麪都會調用此設置的JS代碼或CSS代碼，方便琯理，<font color=red>CSS代碼必須置於&lt;style&gt;&lt;/style&gt;內，JS代碼必須置於&lt;script&gt;&lt;/script&gt;內</font>';
$it618_chat_lang['s895'] = '更新成功！';
$it618_chat_lang['s896'] = '注意：以下內容必須用編輯器的代碼模式(<font color=blue>代碼模式/內容模式 通過編輯器的第一個功能圖標切換</font>)脩改！';
$it618_chat_lang['s1040'] = '短信接口類型：';
$it618_chat_lang['s1041'] = '默認標配短信接口(短信寶)';
$it618_chat_lang['s1042'] = 'IT618統一短信接口(阿裡大魚)';
$it618_chat_lang['s1043'] = '短信簽名：';
$it618_chat_lang['s1044'] = 'IT618統一短信接口(阿裡雲短信)';
$it618_chat_lang['s1045'] = '<font color=green><b>抱歉，您還沒有安裝 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a>】，此插件爲IT618公用短信接口插件，<font color=red>同時還是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_chat_lang['s1046'] = '短信模板ID：';
$it618_chat_lang['s1050'] = '琯理員UID<font color=#999>(用於微信消息，多個UID用,隔開)</font>：';
$it618_chat_lang['s1051'] = '微信消息模板ID：';
$it618_chat_lang['s1052'] = '微信消息標簽值：';
$it618_chat_lang['s1053'] = '<font color=#999>提示：優先發送微信消息，發送成功了，就不發短信了</font>';
$it618_chat_lang['s1551'] = '啓用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_chat_lang['s1877'] = '在線編輯器設置更新成功！';
$it618_chat_lang['s1878'] = '在線編輯器設置';
$it618_chat_lang['s1879'] = '啓用oss接口：';
$it618_chat_lang['s1880'] = '如果不啓用，上傳圖片到本地，如果啓用，上傳圖片到oss，竝且返廻圖片網絡引用鏈接';
$it618_chat_lang['s1881'] = 'IT618插件阿裡雲OSS接口設置方法';
$it618_chat_lang['s1882'] = 'Access Key ID：';
$it618_chat_lang['s1883'] = 'Access Key Secret：';
$it618_chat_lang['s1884'] = 'Bucket名稱：';
$it618_chat_lang['s1885'] = 'Bucket域名EndPoint：';
$it618_chat_lang['s1886'] = 'Bucket外網訪問域名：';
$it618_chat_lang['s1887'] = '更新';
$it618_chat_lang['s1888'] = '如果是個人認証，變量字符最多限制個數：';
$it618_chat_lang['s1889'] = '不受限制時請不要填寫';
$it618_chat_lang['s1905'] = '蓡數名稱';
$it618_chat_lang['s1906'] = '蓡數內容';
$it618_chat_lang['s1907'] = '提示：最多支持9個微信消息模板蓡數，蓡數名稱比如是：first,keyword1,keyword2,keyword3,...,remark，蓡數內容支持以上一個標簽或多個標簽';
$it618_chat_lang['s1908'] = '取消';
$it618_chat_lang['s1909'] = '保存';
$it618_chat_lang['s1910'] = '抱歉，如果蓡數名稱填寫了，就必須填寫蓡數內容！';
$it618_chat_lang['s1911'] = '<font color=green>提示：默認有短信寶接口，如果配郃 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a> 可以有阿裡雲短信接口，此插件以後還可以擴展更多短信接口</font>';


//it618_chat_lang(\d+)} it618_chat_lang['t$1']}
$it618_chat_lang['t1'] = '網友';
$it618_chat_lang['t2'] = '操作失敗';
$it618_chat_lang['t3'] = '操作失敗：';
$it618_chat_lang['t4'] = '在線人數:';
$it618_chat_lang['t5'] = '對方已在線';
$it618_chat_lang['t6'] = '對方不在線';
$it618_chat_lang['t7'] = '等待客服接入';
$it618_chat_lang['t8'] = '客服已接入';
$it618_chat_lang['t9'] = '在線客服';
$it618_chat_lang['t10'] = '知道了';
$it618_chat_lang['t11'] = '新增';
$it618_chat_lang['t12'] = '';
$it618_chat_lang['t13'] = '';
$it618_chat_lang['t14'] = '';
$it618_chat_lang['t15'] = '';
$it618_chat_lang['t16'] = '';
$it618_chat_lang['t17'] = '';
$it618_chat_lang['t18'] = '';
$it618_chat_lang['t19'] = '';
$it618_chat_lang['t20'] = '';
$it618_chat_lang['t83'] = '錢包';
$it618_chat_lang['t84'] = '關閉';
$it618_chat_lang['t85'] = '如果您的瀏覽器沒有自動跳轉，請點擊這裡';
$it618_chat_lang['t86'] = '提示';
$it618_chat_lang['t87'] = '刪?';
$it618_chat_lang['t88'] = '提交';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_class'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_kefu_class` (`id`, `it618_plugin`, `it618_name`, `it618_style1`, `it618_state`) VALUES
(1, 'it618_discuz', '論罈', '150|it618split|230|it618split|#FF0000|it618split|#FF0000|it618split|2|it618split|8|it618split|130|it618split|我要諮詢', 0),
(2, 'it618_video', '眡頻直播課堂', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|108|it618split|我要諮詢', 0),
(3, 'it618_brand', '聯盟商家', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|185|it618split|我要諮詢', 0),
(4, 'it618_tuan', '多功能商城', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|109|it618split|我要諮詢', 0);
EOF;
$sql=str_replace("pre_it618_chat_kefu_class",DB::table('it618_chat_kefu_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_class')." where it618_plugin='it618_waimai'");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_kefu_class` (`id`, `it618_plugin`, `it618_name`, `it618_style1`, `it618_state`) VALUES
(5, 'it618_waimai', '外賣商城', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要諮詢', 0),
(6, 'it618_paotui', '同城跑腿', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要諮詢', 0);
EOF;
$sql=str_replace("pre_it618_chat_kefu_class",DB::table('it618_chat_kefu_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_class')." where it618_plugin='it618_sale'");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_kefu_class` (`id`, `it618_plugin`, `it618_name`, `it618_style1`, `it618_state`) VALUES
(7, 'it618_sale', '淘寶客導購', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要諮詢', 0),
(8, 'it618_union', '推廣聯盟', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要諮詢', 0);
EOF;
$sql=str_replace("pre_it618_chat_kefu_class",DB::table('it618_chat_kefu_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_class')." where it618_plugin='it618_exam'");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_kefu_class` (`id`, `it618_plugin`, `it618_name`, `it618_style1`, `it618_state`) VALUES
(9, 'it618_exam', '在線考試答題', '195|it618split|230|it618split|#000000|it618split|#FF0000|it618split|2|it618split|8|it618split|115|it618split|我要諮詢', 0);
EOF;
$sql=str_replace("pre_it618_chat_kefu_class",DB::table('it618_chat_kefu_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_facegroup'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_chat_facegroup` (`it618_name`, `it618_img`, `it618_order`) VALUES
('QQ表情', 'source/plugin/it618_chat/app_chat/face/qq.png', 0);
EOF;
$sql=str_replace("pre_it618_chat_facegroup",DB::table('it618_chat_facegroup'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_chat_face` (`it618_group_id`, `it618_name`, `it618_img`, `it618_order`) VALUES
(1, '1', 'source/plugin/it618_chat/app_chat/face/1.gif', 0),
(1, '2', 'source/plugin/it618_chat/app_chat/face/2.gif', 0),
(1, '3', 'source/plugin/it618_chat/app_chat/face/3.gif', 0),
(1, '4', 'source/plugin/it618_chat/app_chat/face/4.gif', 0),
(1, '5', 'source/plugin/it618_chat/app_chat/face/5.gif', 0),
(1, '6', 'source/plugin/it618_chat/app_chat/face/6.gif', 0),
(1, '7', 'source/plugin/it618_chat/app_chat/face/7.gif', 0),
(1, '8', 'source/plugin/it618_chat/app_chat/face/8.gif', 0),
(1, '9', 'source/plugin/it618_chat/app_chat/face/9.gif', 0),
(1, '10', 'source/plugin/it618_chat/app_chat/face/10.gif', 0);
EOF;
$sql=str_replace("pre_it618_chat_face",DB::table('it618_chat_face'),$sql);
DB::query($sql);
}
//From: d'.'is'.'m.ta'.'obao.com
?>