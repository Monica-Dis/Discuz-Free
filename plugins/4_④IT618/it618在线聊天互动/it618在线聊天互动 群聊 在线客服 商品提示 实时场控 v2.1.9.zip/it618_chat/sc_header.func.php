<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_chat/sc_default.func.php';

global $_G,$it618_chat;

$it618_chat = $_G['cache']['plugin']['it618_chat'];
$ppp = 9;
$page = max(1, intval($_GET['page']));
if($_GET['findbtn']==1)$page=1;
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

echo'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">
<meta http-equiv="x-ua-compatible" content="ie=7" />
<link href="static/image/admincp/admincp.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="source/plugin/it618_chat/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_chat/kindeditor/kindeditor-min.js"></script>
<style>
td{ text-align:left; }
body{padding-left:5px;padding-right:5px}
.cuspages .pg{line-height:20px;}
.cuspages .pg a,.cuspages .pg strong,.cuspages .pg em{float:left;display:inline;margin-left:4px;padding:0 6px;height:20px;border:1px solid;border-color:#C2D5E3;background-color:#FFF;background-repeat:no-repeat;color:#333;overflow:hidden;text-decoration:none;font-style: normal; line-height:20px}
.cuspages .pg a.nxt{padding:0 5px;}
.cuspages .pg a:hover{border-color:#369;color:#369;}
.cuspages .pg a.nxt{padding-right:25px;background-image:url(source/plugin/it618_chat/images/arw_r.gif);background-position:90% 50%;}
.cuspages .pg a.prev{background-image:url(source/plugin/it618_chat/images/arw_l.gif);background-position:50% 50%;}
.cuspages .pg strong{background-color:#E5EDF2;}
.cuspages .pg .px{border:1px solid;border-color:#848484 #E0E0E0 #E0E0E0 #848484; padding: 0; width: 25px; height: 13px; line-height: 13px; font-size:12px; margin-top:-5px;*margin-top:0px}
.cuspages .pg label{ float: left; display: inline; margin-left: 4px; padding: 0 5px; height: 20px; border: 1px solid; border-color:#C2D5E3;cursor: text;}

.it618btn{border:none; background-color:#F30; color:#fff; padding-left:15px; padding-right:15px; height:26px}

.kd_fahuo #it618_kdid{width:28%;height:28px;vertical-align:middle;}
.kd_fahuo #it618_kddan{width:38%;height:22px;color:green;font-size:15px;font-weight:bold;padding-left:2px;margin-left:3px;vertical-align:middle;}
.kd_fahuo .it618btn{background-color:#390; width:13%; height:30px;cursor:pointer;vertical-align:middle;}
</style>
<script type="text/JavaScript">
var ISFRAME = 0;
</script>

<script src="static/js/common.js" type="text/javascript"></script>
<script src="static/js/admincp.js" type="text/javascript"></script>
<script type="text/javascript" src="source/plugin/it618_chat/js/jquery.js"></script>
</head>
<body>
';

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	echo '<span id="it618_credits"></span>'.it618_credits_getcredits('it618_chat','#it618_credits');
}

function it618_showformheader($actionurl){
	echo '<form name="cpform" method="post" autocomplete="off" action="'.$actionurl.'" id="cpform" ><input type="hidden" name="formhash" value="'.FORMHASH.'" />';
}

function showtableheaders($title = '', $classname = '', $extra = '', $titlespan = 15) {
	global $_G;
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')return;
	$classname = str_replace(array('nobottom', 'notop'), array('nobdb', 'nobdt'), $classname);
	if(isset($_G['showsetting_multi'])) {
		if($_G['showsetting_multi'] == 0) {
			$extra .= ' style="width:'.($_G['showsetting_multicount'] * 270 + 20).'px"';
		} else {
			return;
		}
	}
	echo "\n".'<table class="tb tb2 '.$classname.'"'.($extra ? " $extra" : '').' style="clear: both;margin-top: 5px;width: 100%">';
	if($title) {
		$span = $titlespan ? 'colspan="'.$titlespan.'"' : '';
		echo "\n".'<tr><th '.$span.' class="partition">'.$title.'</th></tr>';
		showmultititle(1);
	}
}

function showmultititle($nofloat = 0) {
	global $_G;
	if(isset($_G['showtableheader_multi']) && $_G['showsetting_multi'] == 0) {
		$i = 0;
		$rows = '';
		foreach($_G['showtableheader_multi'] as $row) {
			$i++;
			$rows .= '<div class="multicol">'.$row.'</div>';
		}
		if($nofloat) {
			echo '<tr><td class="tbm"><div>'.$rows.'</div></td></tr>';
		} else {
			echo '<div id="multititle" class="tbm" style="width:'.($i * 270).'px;display:none">'.$rows.'</div>';
			echo '<script type="text/javascript">floatbottom(\'multititle\');</script>';
		}
	}
}

function showsubtitle($title = array(), $rowclass='header', $tdstyle=array()) {
	if(is_array($title)) {
		$subtitle = "\n<tr class=\"$rowclass\">";
		foreach($title as $k => $v) {
			if($v !== NULL) {
				$subtitle .= '<th'.($tdstyle[$k] ? ' '.$tdstyle[$k] : '').'>'.$v.'</th>';
			}
		}
		$subtitle .= '</tr>';
		echo $subtitle;
	}
}

function showtablerow($trstyle = '', $tdstyle = array(), $tdtext = array(), $return = FALSE) {
	$rowswapclass = '';
	if(!preg_match('/class\s*=\s*[\'"]([^\'"<>]+)[\'"]/i', $trstyle, $matches)) {
		$rowswapclass = is_array($tdtext) && count($tdtext) > 2 ? ' class="hover"' : '';
	} else {
		if(is_array($tdtext) && count($tdtext) > 2) {
			$rowswapclass = " class=\"{$matches[1]} hover\"";
			$trstyle = preg_replace('/class\s*=\s*[\'"]([^\'"<>]+)[\'"]/i', '', $trstyle);
		}
	}
	$cells = "\n".'<tr'.($trstyle ? ' '.$trstyle : '').$rowswapclass.'>';
	if(isset($tdtext)) {
		if(is_array($tdtext)) {
			foreach($tdtext as $key => $td) {
					$cells .= '<td'.(is_array($tdstyle) && !empty($tdstyle[$key]) ? ' '.$tdstyle[$key] : '').'>'.$td.'</td>';
			}
		} else {
			$cells .= '<td'.(!empty($tdstyle) && is_string($tdstyle) ? ' '.$tdstyle : '').'>'.$tdtext.'</td>';
		}
	}
	$cells .= '</tr>';
	if($return) {
		return $cells;
	}
	echo $cells;
}

function showsubmit($name = '', $value = 'submit', $before = '', $after = '', $floatright = '', $entersubmit = true) {
	global $_G;
	if(!empty($_G['showsetting_multi'])) {
		return;
	}
	$str = '<tr>';
	$str .= $name && in_array($before, array('del', 'select_all', 'td')) ? '<td class="td25">'.($before != 'td' ? '<input type="checkbox" name="chkall" id="chkall'.($chkkallid = random(4)).'" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkall'.$chkkallid.'">'.it618_chat_getlang('t87') : '').'</label></td>' : '';
	$str .= '<td colspan="15">';
	$str .= $floatright ? '<div class="cuspages right">'.$floatright.'</div>' : '';
	$str .= '<div class="fixsel">';
	$str .= $before && !in_array($before, array('del', 'select_all', 'td')) ? $before.' &nbsp;' : '';
	$str .= $name ? '<input type="submit" class="btn" name="'.$name.'" value="'.it618_chat_getlang('t88').'" />' : '';
	$str = $after ? $str.(($before && $before != 'del') || $name ? ' &nbsp;' : '').$after : $str;
	$str .= '</div></td>';
	$str .= '</tr>';
	echo $str.($name && $entersubmit ? '<script type="text/JavaScript">_attachEvent(document.documentElement, \'keydown\', function (e) { entersubmit(e, \''.$name.'\'); });</script>' : '');
}

function showtablefooter() {
	global $_G;
	if(!empty($_G['showsetting_multi'])) {
		return;
	}
	echo '</table>'."\n";
}

function it618_cpmsg($message, $url = '', $type = '') {
	global $_G,$it618_chat;

	switch($type) {
		case 'download':
		case 'succeed': $classname = 'infotitle2';break;
		case 'error': $classname = 'infotitle3';break;
		default: $classname = 'marginbot normal';break;
	}

	$message = "<h4 class=\"$classname\">$message</h4>";
	$url .= $url && !empty($_GET['scrolltop']) ? '&scrolltop='.intval($_GET['scrolltop']) : '';

	$message .= $extra.($type == 'loading' ? '<img src="static/image/admincp/ajax_loader.gif" class="marginbot" />' : '');
	if($url) {
		$message .= '<p class="marginbot"><a href="'.$url.'" class="lightlink">'.it618_chat_getlang('t85').'</a></p>';
		$timeout = $type != 'loading' ? 10000 : 0;
		$message .= "<script type=\"text/JavaScript\">setTimeout(\"redirect('$url');\", $timeout);</script>";
	}

	echo '<h3 style="padding-top:3px">'.$it618_chat['union_name'].' '.it618_chat_getlang('t86').'</h3><div class="infobox">'.$message.'</div>';
	exit();
}
//From: d'.'is'.'m.ta'.'obao.com
?>