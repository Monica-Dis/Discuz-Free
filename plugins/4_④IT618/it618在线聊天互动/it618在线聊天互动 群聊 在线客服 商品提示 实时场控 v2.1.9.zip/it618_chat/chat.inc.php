<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_chat;

$it618_chat = $_G['cache']['plugin']['it618_chat'];
require_once DISCUZ_ROOT.'./source/plugin/it618_chat/function.func.php';

$typeid=intval($_GET['typeid']);
if(chat_is_mobile()){
	$wap=1;
}

if($wap==1){
	$chat_longin='<font color=red>'.$it618_chat_lang['s1'].'</font> <a href="javascript:" onclick="parent.location.href=\'member.php?mod=logging&action=login&referer=\'+encodeURIComponent(parent.location.href)">'.$it618_chat_lang['s62'].'</a>';
}else{
	if($_GET['type']=='kefu'){
		$it618_chat_kefu=C::t('#it618_chat#it618_chat_kefu')->fetch_by_id($typeid);
		$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($it618_chat_kefu['it618_cid']);
		
		if($it618_chat_kefu_class['it618_plugin']=='it618_discuz'){
			$tmplongin='<a href="javascript:" onclick="parent.location.href=\'member.php?mod=logging&action=login&referer=\'+encodeURIComponent(parent.location.href);">'.$it618_chat_lang['s62'].'</a>';
		}else{
			if($IsMembers==1){
				$tmplongin='<a href="javascript:" onclick="parent.jQuery(\'.it618_members_login\').click()">'.$it618_chat_lang['s62'].'</a>';
			}else{
				$tmplongin='<a href="javascript:" onclick="parent.location.href=\'member.php?mod=logging&action=login&referer=\'+encodeURIComponent(parent.location.href)">'.$it618_chat_lang['s62'].'</a>';
			}
		}
	}else{
		if($IsMembers==1){
			$tmplongin='<a href="javascript:" onclick="parent.jQuery(\'.it618_members_login\').click()"><font color=#fff>'.$it618_chat_lang['s62'].'</font></a>';
		}else{
			$tmplongin='<a href="javascript:" onclick="parent.location.href=\'member.php?mod=logging&action=login&referer=\'+encodeURIComponent(parent.location.href)"><font color=#fff>'.$it618_chat_lang['s62'].'</font></a>';
		}
	}

	$chat_longin='<font color=red>'.$it618_chat_lang['s1'].'</font> '.$tmplongin;
}

if($_GET['type']=='video'){
	if($it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($typeid)){
		if($it618_video_goods_video['it618_ischat']==0){
			echo '<font color=red>'.$it618_chat_lang['s18'].'</font>';exit;
		}
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		
		$isgoodsprice=0;
		if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
			$isgoodsprice=1;
		}
		
		$it618_isuser=$it618_video_goods_video['it618_isuser'];
		
		if($it618_video_goods_video['it618_liveid']>0){
			$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
			$it618_isuser=$it618_video_live['it618_isuser'];
		}
		
		if($it618_isuser==0){
			if($it618_video_goods['it618_isuser']==0){
				$isok=1;
			}else{
				if($_G['uid']<=0){
					echo $chat_longin;exit;
				}else{
					$isok=1;
				}
			}
		}
		
		if($it618_isuser==2){
			if($_G['uid']>0){
				$isok=1;
			}
		}
		
		if($it618_isuser==1){
			if($isgoodsprice>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
				
				$videopower=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
				if($videopower['state']>0){
					$isok=1;
				}else{
					$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
					if(count($vipgroupids)>0){
						if($_G['uid']>0){
							if(count($vipgroupids)>0){
								$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
								$isvipuser=count($tmpgrouparr[0]);
							}
						}
						if($isvipuser>0){
							$isok=1;
						}
					}
				}
			}else{
				$isok=1;
			}
			
			if($_G['uid']>0){
				if($_G['uid']==$it618_video_shop['it618_uid']){
					$isok=1;
				}
			}
			
		}
		
		if($wap==1){
			$it618_styletmp=C::t('#it618_video#it618_video_wapstyle')->fetch_by_isok_search();
		}else{
			$it618_styletmp=C::t('#it618_video#it618_video_style')->fetch_by_isok();
		}
	}else{
		echo '<font color=red>'.$it618_chat_lang['s20'].'</font>';exit;
	}
	
	if($isok==1){
		$it618_topic=$_GET['type'].'_'.$typeid;
		
		if($it618_video_goods_video['it618_ischat']==2){
			$it618_topic=$_GET['type'].'_l_'.$it618_video_goods_video['it618_lid'];
		}
		
		if($it618_video_goods_video['it618_ischat']==3){
			$it618_topic=$_GET['type'].'_g_'.$it618_video_goods_video['it618_pid'];
		}
		
		$navtitle=$it618_video_goods_video['it618_name'];

		if($it618_video_goods['it618_isip']==1){
			$ip=$_G['clientip'];
		}
		if($it618_video_goods['it618_isaddr']==1){
			$isipaddr=1;
		}
		
		if($it618_video_goods['it618_gtype']==1){
			$isvideo=1;
		}
		
		$it618_adminuids=$it618_video_shop['it618_uid'];
	}else{
		echo '<font color=red>'.$it618_chat_lang['s17'].'</font>';exit;
	}
}

if($_GET['type']=='brandvideo'||$_GET['type']=='tuanvideo'){
	if($_GET['type']=='brandvideo')$tmptable='#it618_brand#it618_brand_live';else $tmptable='#it618_tuan#it618_tuan_live';
	if($it618_api_live=C::t($tmptable)->fetch_by_shopid($typeid)){
		if($it618_api_live['it618_islogin']==1){
			if($_G['uid']>0){
				if($it618_api_live['it618_ischat']==1){
					$isok=1;
				}
			}else{
				echo $chat_longin;exit;
			}
		}else{
			if($it618_api_live['it618_ischat']==1){
				$isok=1;
			}
		}
	}else{
		echo '<font color=red>'.$it618_chat_lang['s21'].'</font>';exit;
	}
	
	if($isok==1){
		$it618_topic=$_GET['type'].'_'.$typeid;
		
		$navtitle=$it618_api_live['it618_name'];
		if($it618_api_live['it618_isip']==1)$ip=$_G['clientip'];
		if($it618_api_live['it618_isaddr']==1){
			$isipaddr=1;
		}
		
		$isvideo=2;
		
		if($_GET['type']=='brandvideo'){
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($typeid);
			$it618_adminuids=$it618_brand_brand['it618_uid'];
		}
		if($_GET['type']=='tuanvideo'){
			$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($typeid);
			$it618_adminuids=$it618_tuan_shop['it618_uid'];
		}
	}else{
		echo '<font color=red>'.$it618_chat_lang['s27'].'</font>';exit;
	}
}

if($_GET['type']=='zhibo'){
	if($it618_zhibo_live=C::t('#it618_zhibo#it618_zhibo_live')->fetch_by_id($typeid)){
		if($it618_zhibo_live['it618_islogin']==1){
			if($_G['uid']>0){
				$isok=1;
			}else{
				echo $chat_longin;exit;
			}
		}else{
			$isok=1;	
		}
	}else{
		echo '<font color=red>'.$it618_chat_lang['s21'].'</font>';exit;
	}
	
	if($isok==1){
		$it618_topic=$_GET['type'].'_'.$typeid;
		
		$navtitle=$it618_zhibo_live['it618_title'];
		if($it618_zhibo_live['it618_isip']==1)$ip=$_G['clientip'];
		if($it618_zhibo_live['it618_isaddr']==1){
			$isipaddr=1;
		}
		
		$isvideo=2;
		
		$it618_adminuids=$it618_zhibo_live['it618_uid'];
	}else{
		echo '<font color=red>'.$it618_chat_lang['s27'].'</font>';exit;
	}
}

if($_GET['type']=='videoshopqun'){
	if($_G['uid']<=0){
		echo $chat_longin;exit;
	}

	if($it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($typeid)){
		if($it618_video_shop['it618_isqunchat']!=1){
			echo $it618_chat_lang['s195'];exit;
		}
		if($it618_video_shop['it618_uid']==$_G['uid']){
			$isok=1;
		}else{
			if($it618_video_shop_subscribe=C::t('#it618_video#it618_video_shop_subscribe')->fetch_by_shopid_uid($typeid,$_G['uid'])){
				if($it618_video_shop['it618_qunchattime']>0){
					if($_G['timestamp']-$it618_video_shop_subscribe['it618_time']>$it618_video_shop['it618_qunchattime']*3600){
						$isok=1;
					}else{
						$tmptime=round(($_G['timestamp']-$it618_video_shop_subscribe['it618_time'])/3600,2);
						echo $it618_chat_lang['s196'].$it618_video_shop['it618_qunchattime'].$it618_chat_lang['s197'].$it618_chat_lang['s198'].$tmptime.$it618_chat_lang['s199'];exit; 
					}
				}else{
					$isok=1;
				}
			}else{
				echo $it618_chat_lang['s194'];exit;
			}
		}
	}else{
		echo $it618_chat_lang['s27'];exit;
	}
	
	if($isok==1){
		$it618_topic=$_GET['type'].'_'.$typeid;
		$it618_adminuids=$it618_video_shop['it618_uid'];
	}else{
		echo '<font color=red>'.$it618_chat_lang['s21'].'</font>';exit;
	}
}

if($_GET['type']=='examshopqun'){
	if($_G['uid']<=0){
		echo $chat_longin;exit;
	}
	
	if($it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($typeid)){
		if($it618_exam_shop['it618_isqunchat']!=1){
			echo $it618_chat_lang['s195'];exit;
		}
		if($it618_exam_shop['it618_uid']==$_G['uid']){
			$isok=1;
		}else{
			if($it618_exam_shop_subscribe=C::t('#it618_exam#it618_exam_shop_subscribe')->fetch_by_shopid_uid($typeid,$_G['uid'])){
				if($it618_exam_shop['it618_qunchattime']>0){
					if($_G['timestamp']-$it618_exam_shop_subscribe['it618_time']>$it618_exam_shop['it618_qunchattime']*3600){
						$isok=1;
					}else{
						$tmptime=round(($_G['timestamp']-$it618_exam_shop_subscribe['it618_time'])/3600,2);
						echo $it618_chat_lang['s196'].$it618_exam_shop['it618_qunchattime'].$it618_chat_lang['s197'].$it618_chat_lang['s198'].$tmptime.$it618_chat_lang['s199'];exit; 
					}
				}else{
					$isok=1;
				}
			}else{
				echo $it618_chat_lang['s194'];exit;
			}
		}
	}else{
		echo $it618_chat_lang['s27'];exit;
	}
	
	if($isok==1){
		$it618_topic=$_GET['type'].'_'.$typeid;
		$it618_adminuids=$it618_exam_shop['it618_uid'];
	}else{
		echo '<font color=red>'.$it618_chat_lang['s21'].'</font>';exit;
	}
}

if($_GET['type']=='examchat'){
	if($_G['uid']<=0){
		echo $chat_longin;exit;
	}
	
	if($it618_exam_test_exam = C::t('#it618_exam#it618_exam_test_exam')->fetch_by_id($typeid)){
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_test_exam['it618_pid']);
		if($it618_exam_goods['it618_ischat']==0){
			echo $it618_chat_lang['s200'];exit;
		}

		if($it618_exam_goods['it618_ischat']==1){
			if($it618_exam_test_exam['it618_state']==3){
				echo $it618_chat_lang['s201'];exit;
			}
		}
		if($it618_exam_goods['it618_ischat']==2){
			if($it618_exam_test_exam['it618_state']!=3){
				echo $it618_chat_lang['s202'];exit;
			}
		}
		if($it618_exam_test_exam['it618_uid']==$_G['uid']){
			$isok=1;
		}else{
			echo $it618_chat_lang['s203'];exit;
		}
	}else{
		echo $it618_chat_lang['s27'];exit;
	}
	
	if($isok==1){
		$it618_topic=$_GET['type'].'_'.$it618_exam_test_exam['it618_pid'];
	}else{
		echo '<font color=red>'.$it618_chat_lang['s21'].'</font>';exit;
	}
}

if($_GET['type']=='onepage'){
	if($it618_chat_onepage=C::t('#it618_chat#it618_chat_onepage')->fetch_by_id($typeid)){
		if($it618_chat_onepage['it618_isuser']==1){
			if($_G['uid']>0){
				if($it618_chat_onepage['it618_state']==1){
					$isok=0;
					
					$uidarr=explode(",",$it618_chat_onepage['it618_uids']);
					if(in_array($_G['uid'],$uidarr)){
						$isok=1;
					}else{
						if(it618_chat_isonepagegroup($it618_chat_onepage)){
							$isok=1;
						}
					}
					
					if($isok==0){
						echo '<font color=red>'.$it618_chat_lang['s78'].'</font>';exit;	
					}
				}
			}else{
				dheader("location:member.php?mod=logging&action=login");
			}
		}else{
			if($it618_chat_onepage['it618_state']==1){
				$isok=1;
			}
		}
	}
	
	if($isok==1){
		$it618_topic=$_GET['type'].'_'.$typeid;
		
		$navtitle=$it618_chat_onepage['it618_name'];
		if($it618_chat_onepage['it618_isip']==1)$ip=$_G['clientip'];
		if($it618_chat_onepage['it618_isaddr']==1){
			$isipaddr=1;	
		}
		
		$it618_adminuids=$it618_chat_onepage['it618_adminuids'];
	}else{
		echo '<font color=red>'.$it618_chat_lang['s21'].'</font>';exit;
	}
}

if($_GET['type']=='kefu'){
	$it618_talkid=intval($_GET['tid']);
	if($it618_talkid>0){
		if($it618_chat_kefu_talk=C::t('#it618_chat#it618_chat_kefu_talk')->fetch_by_id($it618_talkid)){
			if($it618_chat_kefu=C::t('#it618_chat#it618_chat_kefu')->fetch_by_id($it618_chat_kefu_talk['it618_kid'])){
				if($it618_chat_kefu['id']!=$typeid){
					echo '<font color=red>'.$it618_chat_lang['s27'].'</font>';exit;
				}
				
				if($it618_chat_kefu['it618_uid']!=$_G['uid']){
					echo '<font color=red>'.$it618_chat_lang['s128'].'</font>';exit;
				}
				
				$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($it618_chat_kefu['it618_cid']);
				if($it618_chat_kefu_class['it618_state']==0){
					echo '<font color=red>'.$it618_chat_lang['s125'].'</font>';exit;
				}
			}
			
			if($it618_chat_kefu_talk['it618_uid']>0){
				$it618_topic=$_GET['type'].'_'.$typeid.'_'.$it618_chat_kefu_talk['it618_uid'];
				$tmpname=it618_chat_getusername($it618_chat_kefu_talk['it618_uid']);
			}else{
				$it618_topic=$_GET['type'].'_'.$typeid.'_0_'.$it618_talkid;
				$tmpname=$it618_chat_lang['s129'].$it618_chat_kefu_talk['id'];
			}
			
			$u_avatarimg='';
			$username=$it618_chat_kefu['it618_name'];
			$clientid='k_'.$typeid.'_'.$it618_talkid;
			
			$tmpname=$it618_chat_lang['s138'].$tmpname.$it618_chat_lang['s139'];
		}
	}else{
		$istalk=1;
		if($it618_chat_kefu=C::t('#it618_chat#it618_chat_kefu')->fetch_by_id($typeid)){
			if($it618_chat_kefu['it618_uid']==$_G['uid']){
				echo '<font color=red>'.$it618_chat_lang['s127'].'</font>';exit;
			}
					
			$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($it618_chat_kefu['it618_cid']);
			if($it618_chat_kefu_class['it618_state']==0){
				echo '<font color=red>'.$it618_chat_lang['s125'].'</font>';exit;
			}
			
			$chat_kefugroups=(array)unserialize($it618_chat['chat_kefugroups']);
			if(!in_array($_G['groupid'], $chat_kefugroups)&&$chat_kefugroups[0]!=''){
				echo '<font color=red>'.$it618_chat_lang['s165'].'</font>';exit;
			}
			
			if($it618_chat_kefu['it618_isuser']==1){
				if($_G['uid']>0){
					if($it618_chat_kefu['it618_state']==1){
						if($it618_chat_kefu['it618_uids']!=''){
							$uidarr=explode(",",$it618_chat_kefu['it618_uids']);
							if(in_array($_G['uid'],$uidarr)){
								echo '<font color=red>'.$it618_chat_lang['s164'].'</font>';exit;
							}
						}
						
						if($it618_chat_kefu['it618_iswxsubscribe']==1){
							if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($_G['uid'])){
								require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
								require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
								if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
									require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
								}
						
								$openid=$it618_members_wxuser['it618_wxopenid'];
								
								$appid=trim($wxjk_appid);
								$appsecret=trim($wxjk_appsecret);
								
								$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
								if(!is_array($data)){
									echo $data;exit;
								}
								$subscribe=$data['subscribe'];
								$subscribe_time=$data['subscribe_time'];
								
								C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
									'it618_wxok' => $subscribe,
									'it618_wxoktime' => $subscribe_time,
									'it618_checktime' => $_G['timestamp']
								));
								if($subscribe==1){
									$it618_wxok=1;
								}
							}
							if($subscribe!=1){
								$tmpabout=$it618_chat_kefu_class['it618_wxsubscribe_about'];
								if($tmpabout=='')$tmpabout=$it618_chat_lang['s170'];
								echo $tmpabout;exit;
							}
						}
						
						$isok=1;
					}
				}else{
					if(isset($_GET['wxkefu']))dheader("location:member.php?mod=logging&action=login");
					echo $chat_longin;exit;
				}
			}else{
				if($it618_chat_kefu['it618_state']==1){
					$isok=1;
				}
			}
		}
		
		if($isok==1){		
			$isipaddr=1;
			
			if($_G['uid']>0){
				$it618_topic=$_GET['type'].'_'.$typeid.'_'.$_G['uid'];
				
				if(!$it618_chat_kefu_talk=C::t('#it618_chat#it618_chat_kefu_talk')->fetch_by_kid_uid($typeid,$_G['uid'])){
					C::t('#it618_chat#it618_chat_kefu_talk')->insert(array(
						'it618_kid' => $typeid,
						'it618_topic' => $it618_topic,
						'it618_uid' => $_G['uid'],
						'it618_ip' => $_G['clientip'],
						'it618_addr' => $tmpaddr,
						'it618_wap' => $wap,
						'it618_time' => $_G['timestamp']
					), true);
				}
				
				$u_avatarimg=it618_chat_discuz_uc_avatar($_G['uid'],'middle');
				$username=$_G['username'];
				$clientid='u_'.$_G['uid'];
				
				$navtitle=$it618_chat_lang['s123'].$it618_chat_kefu['it618_name'].$it618_chat_lang['s124'];
			}else{
				if(isset($_GET['wxkefu']))dheader("location:member.php?mod=logging&action=login");
				
				$it618_talkid=getcookie('kefu'.$typeid);
				if($it618_talkid!=''){
					if(!$it618_chat_kefu_talk=C::t('#it618_chat#it618_chat_kefu_talk')->fetch_by_id($it618_talkid)){
						$isaddtalk=1;
					}
				}else{
					$isaddtalk=1;
				}
				if($isaddtalk==1){
					$it618_talkid=C::t('#it618_chat#it618_chat_kefu_talk')->insert(array(
						'it618_kid' => $typeid
					), true);
					
					$it618_topic=$_GET['type'].'_'.$typeid.'_0_'.$it618_talkid;
					C::t('#it618_chat#it618_chat_kefu_talk')->update($it618_talkid,array(
						'it618_topic' => $it618_topic,
						'it618_ip' => $_G['clientip'],
						'it618_addr' => $tmpaddr,
						'it618_wap' => $wap,
						'it618_time' => $_G['timestamp']
					));
				}
				dsetcookie('kefu'.$typeid,$it618_talkid,31536000);
				
				$it618_topic=$_GET['type'].'_'.$typeid.'_0_'.$it618_talkid;
				$u_avatarimg='source/plugin/it618_chat/images/user.jpg';
				$username=$it618_chat_lang['s129'].$it618_talkid;
				$clientid='k_0_'.$it618_talkid;
			}
		}else{
			echo '<font color=red>'.$it618_chat_lang['s126'].'</font>';exit;
		}
	}
}else{
	if($_G['uid']>0){
		$u_avatarimg=it618_chat_discuz_uc_avatar($_G['uid'],'middle');
		$username=$_G['username'];
		$clientid='u_'.$_G['uid'];
	}else{
		$u_avatarimg='source/plugin/it618_chat/images/user.jpg';
		
		$it618_chatid=getcookie('it618_chatid');
		if($it618_chatid==''){
			$it618_chatid=$_G['timestamp'];
			dsetcookie('it618_chatid',$it618_chatid,31536000);
		}
		$clientid='c_'.$it618_chatid;
		$username=$it618_chat_lang['t1'].$it618_chatid;
	}
}

if($it618_topic==''){
	echo '<font color=red>'.$it618_chat_lang['s27'].'</font>';exit;
}

if($_GET['type']!='kefu'){
	$adminpower=0;$isalljy=0;$isjy=0;$ischatusers=0;$iscomein=0;
	
	if($_G['uid']>0){
		$chatadminuids=explode(",",$it618_chat['chat_adminuids'].','.$it618_adminuids);
		if(in_array($_G['uid'], $chatadminuids)){
			$adminpower=1;
			$ischatusers=1;
		}
	}
	
	if(!$it618_chat_topic=C::t('#it618_chat#it618_chat_topic')->fetch_by_it618_topic($it618_topic)){
		$topicid=C::t('#it618_chat#it618_chat_topic')->insert(array(
			'it618_topic' => $it618_topic,
			'it618_onlinecount' => 0
		), true);
		$onlinecount=0;
	}else{
		$topicid=$it618_chat_topic['id'];
		$onlinecount=$it618_chat_topic['it618_onlinecount'];
	}
	
	if($it618_chat_topic['it618_ischatusers']==1)$ischatusers=1;
	if($it618_chat_topic['it618_iscomein']==1)$iscomein=1;
	if($it618_chat_topic['it618_isjy']==1&&$adminpower==0)$isalljy=1;
	
	if($it618_chat_user_online=C::t('#it618_chat#it618_chat_user_online')->fetch_by_it618_topicid_clientid($topicid,$clientid)){
		if($it618_chat_user_online['it618_ispb']==1){
			echo '<font color=red>'.$it618_chat_lang['s220'].'</font>';exit;
		}
		if($it618_chat_user_online['it618_isadmin']==1){
			$adminpower=2;
			$ischatusers=1;
		}
		if($it618_chat_user_online['it618_isjy']==1){
			$isjy=1;
		}
	}
}else{
	if($_GET['plugin']=='it618_video'&&$_GET['pid']>0){	
		if(($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($_GET['pid'],1))){
			require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
			$chatgoodsname=str_replace('"','',$it618_video_goods['it618_name']);
			$chatgoodsurl=$_G['siteurl'].it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
		}
	}
	
	if($_GET['plugin']=='it618_exam'&&$_GET['pid']>0){	
		if(($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($_GET['pid'],1))){
			require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
			$chatgoodsname=str_replace('"','',$it618_exam_goods['it618_name']);
			$chatgoodsurl=$_G['siteurl'].it618_exam_getrewrite('exam_wap','product@'.$it618_exam_goods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$it618_exam_goods['id']);
		}
	}
	
	if($_GET['plugin']=='it618_brand'&&$_GET['pid']>0){
		if(($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($_GET['pid']))){
			require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
			$chatgoodsname=str_replace('"','',$it618_brand_goods['it618_name']);
			$chatgoodsurl=$_G['siteurl'].it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
		}
	}
	
	if($_GET['plugin']=='it618_tuan'&&$_GET['pid']>0){
		if(($it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id_state($_GET['pid'],1))){
			require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
			$chatgoodsname=str_replace('"','',$it618_tuan_goods['it618_name']);
			$chatgoodsurl=$_G['siteurl'].it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
		}
	}
}

$it618_color1=$it618_styletmp['it618_color1'];
$it618_color2=$it618_styletmp['it618_color2'];
if($it618_color1==''){
	$it618_color1='#eb2f33';
	$it618_color2='#e61d21';
}

$tmpcode=md5($_G['timestamp'].FORMHASH.rand());

C::t('#it618_chat#it618_chat_topicwork')->insert(array(
	'it618_code' => $tmpcode,
	'it618_tid' => $it618_talkid,
	'it618_topic' => $it618_topic
), true);

$tmparr=explode("https",$_G['siteurl']);
if(count($tmparr)>1){
	$useSSL='true';
}else{
	$useSSL='false';
}

if(isset($_GET['iframe'])){
	$isiframe=1;
}

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MiuiBrowser')!==false)$ismiui=1;

$_G['mobiletpl'][IN_MOBILE]='/'; //DisM �� Taobao �� Com
include template('it618_chat:chat');
?>