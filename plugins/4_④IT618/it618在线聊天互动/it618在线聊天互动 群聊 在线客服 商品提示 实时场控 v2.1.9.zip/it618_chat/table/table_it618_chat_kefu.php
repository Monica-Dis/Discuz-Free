<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_chat_kefu extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_chat_kefu';
		$this->_pk = 'id';
		parent::__construct(); //dis'.'m.t'.'ao'.'bao.com
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_username_by_uid($uid) {
		return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d AND it618_state=1", array($this->_table, $uid));
	}
	
	public function count_all_by_search($it618sql = '', $it618orderby='', $it618key = '', $it618_cid = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618key, $it618_cid);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $it618key = '', $it618_cid = 0, $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618key, $it618_cid);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $it618key = '', $it618_cid = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618key)) {
			$parameter[] = '%'.$it618key.'%';
			$parameter[] = '%'.$it618key.'%';
			$wherearr[] = "(it618_name LIKE %s or it618_tel LIKE %s)";
		}
		
		if(!empty($it618_cid)) {
			$parameter[] = $it618_cid;
			$wherearr[] = 'it618_cid=%d';
		}

		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>