<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_chat_user_online extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_chat_user_online';
		$this->_pk = 'id';
		parent::__construct(); //dis'.'m.t'.'ao'.'bao.com
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_it618_topicid_clientid($it618_topicid,$it618_clientid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_topicid=%d and it618_clientid=%s", array($this->_table, $it618_topicid,$it618_clientid));
	}
	
	public function count_by_it618_topicid_online($it618_topicid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_topicid=%d and it618_isonline=1", array($this->_table, $it618_topicid));
	}
	
	public function isadmin_by_it618_topicid_uid($it618_topicid,$it618_uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_topicid=%d and it618_uid=%s and it618_isadmin=1", array($this->_table, $it618_topicid,$it618_uid));
	}
	
	public function fetch_by_it618_topicid_clientid($it618_topicid,$it618_clientid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_topicid=%d and it618_clientid=%s", array($this->_table, $it618_topicid,$it618_clientid));
	}
	
	public function count_by_it618_topicid($it618_topicid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_topicid=%d", array($this->_table, $it618_topicid));
	}
	
	public function fetch_by_it618_topicid($it618_topicid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_topicid=%d", array($this->_table, $it618_topicid));
	}
	
	public function fetch_all_by_it618_topicid_online($it618_topicid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_topicid=%d and (it618_isonline=1 or it618_ispb=1) ORDER BY it618_isadmin desc,it618_clientid", array($this->_table,$it618_topicid));
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>