<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_chat/sc_header.func.php';

$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($chatcid);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_chat_kefu_diy', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_title'])) {
		foreach($_GET['it618_title'] as $id => $val) {

			C::t('#it618_chat#it618_chat_kefu_diy')->update($id,array(
				'it618_title' => trim($_GET['it618_title'][$id]),
				'it618_content' => trim($_GET['it618_content'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_title_array = !empty($_GET['newit618_title']) ? $_GET['newit618_title'] : array();
	$newit618_content_array = !empty($_GET['newit618_content']) ? $_GET['newit618_content'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_title_array as $key => $value) {
		$newit618_title = addslashes(trim($newit618_title_array[$key]));
		
		if($newit618_title != '') {
			
			C::t('#it618_chat#it618_chat_kefu_diy')->insert(array(
				'it618_cid' => $chatcid,
				'it618_sid' => $ShopId,
				'it618_title' => trim($newit618_title_array[$key]),
				'it618_content' => trim($newit618_content_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	it618_cpmsg($it618_chat_lang['s33'].$ok1.' '.$it618_chat_lang['s34'].$ok2.' '.$it618_chat_lang['s35'].$del.')', "plugin.php?id=it618_chat:sc_kefu_diy&cid=$chatcid$adminsid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_chat:sc_kefu_diy&cid=$chatcid$adminsid");
showtableheaders($it618_chat_lang['s151'],'it618_chat_kefu_diy');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_chat_kefu_diy')." WHERE it618_cid=$chatcid and it618_sid=$ShopId");
	
	echo '<tr><td colspan=10>'.$it618_chat_lang['s101'].$count.'<span style="float:right;color:red">'.$it618_chat_lang['s100'].'</span></td></tr>';
	showsubtitle(array('',$it618_chat_lang['s97'], $it618_chat_lang['s98'],$it618_chat_lang['s99']));

	$query = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu_diy')." WHERE it618_cid=$chatcid and it618_sid=$ShopId ORDER BY it618_order");
	while($it618_chat_kefu_diy = DB::fetch($query)) {
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id$it618_chat[id]\" name=\"delete[]\" value=\"$it618_chat_kefu_diy[id]\" $disabled><label for=\"id$it618_chat_kefu_diy[id]\">$it618_chat_kefu_diy[id]</label>",
			"<input type=\"text\" class=\"txt\" style=\"width:230px\" name=\"it618_title[$it618_chat_kefu_diy[id]]\" value=\"$it618_chat_kefu_diy[it618_title]\">",
			"<textarea class=\"textarea\" style=\"width:480px;height:58px\" name=\"it618_content[$it618_chat_kefu_diy[id]]\">$it618_chat_kefu_diy[it618_content]</textarea>",
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_chat_kefu_diy['id'].']" value="'.$it618_chat_kefu_diy['it618_order'].'">'
		));
	}
	
	global $_G;

	loadcache('plugin');
	$it618_chat = $_G['cache']['plugin']['it618_chat'];

	$it618_chat_lang102=$it618_chat_lang['s102'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_title[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:230px;margin-bottom:3px" name="newit618_title[]"><br><font color=#999>$it618_chat_lang102</font>'],
		[1, '<textarea name="newit618_content[]" style="width:480px;height:58px"></textarea>'],
		[1,'<input class="txt" type="text" style="width:30px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();

	</script>
EOT;
	echo '<tr><td></td><td colspan="15"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_chat_lang['t11'].'</a></div></td></tr>';
    showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
    
require_once DISCUZ_ROOT.'./source/plugin/it618_chat/sc_footer.func.php';
?>