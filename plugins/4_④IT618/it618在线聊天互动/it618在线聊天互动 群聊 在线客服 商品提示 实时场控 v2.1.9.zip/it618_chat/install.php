<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_chat_onepage`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_onepage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(300) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_uids` varchar(3000) NOT NULL,
  `it618_adminuids` varchar(1000) NOT NULL,
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isip` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_onepage_group`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_onepage_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_oid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_kefu_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_kefu_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_plugin` varchar(50) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_wxsubscribe_about` mediumtext NOT NULL,
  `it618_style1` mediumtext NOT NULL,
  `it618_style1_ico` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_style1_wapico` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isshare` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_kefu_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_kefu_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_sid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_title` varchar(300) NOT NULL,
  `it618_content` varchar(8000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_kefu`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_kefu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_sid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_avatarimg` varchar(100) NOT NULL,
  `it618_name` varchar(100) NOT NULL,
  `it618_tel` varchar(15) NOT NULL,
  `it618_uids` varchar(1000) NOT NULL,
  `it618_iswxsubscribe` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_user`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_topic`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_topic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_topic` varchar(255) NOT NULL,
  `it618_ischatusers` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_iscomein` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isjy` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_onlinecount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_topic_del`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_topic_del` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_delid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_user_online`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_user_online` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_topicid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_clientid` varchar(255) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isonline` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isadmin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isjy` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ispb` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_kefu_talk`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_kefu_talk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_kid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_topic` varchar(255) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ip` varchar(50) NOT NULL,
  `it618_addr` varchar(255) NOT NULL,
  `it618_wap` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  `it618_userbz` varchar(1000) NOT NULL,
  `it618_usertime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_topicwork`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_topicwork` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_tid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(32) NOT NULL,
  `it618_topic` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_facegroup`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_facegroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_img` varchar(255) NOT NULL DEFAULT '',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_face`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_face` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_group_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_img` varchar(255) NOT NULL DEFAULT '',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_chat_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_chat_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0LnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0X1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0X1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0X1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvZGlzY3V6X3BsdWdpbl9pdDYxOF9jaGF0X1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvdXBncmFkZS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2NoYXQvaW5zdGFsbC5waHA='));
?>