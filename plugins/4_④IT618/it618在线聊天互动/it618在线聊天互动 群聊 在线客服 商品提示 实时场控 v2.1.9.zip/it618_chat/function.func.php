<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_chat;

$it618_chat = $_G['cache']['plugin']['it618_chat'];
require_once DISCUZ_ROOT.'./source/plugin/it618_chat/lang.func.php';

$cache_file = DISCUZ_ROOT.'./source/plugin/it618_chat/cache.php';
$tmptime=30;

if(($_G['timestamp'] - @filemtime($cache_file)) > $tmptime) {
	
	@$fp = fopen($cache_file,"w");
	fwrite($fp,$_G['timestamp']);
	fclose($fp);
	
	DB::query("delete from ".DB::table('it618_chat_kefu_talk')." where it618_uid=0 and it618_bz='' and it618_time+".(3600*24)."<".$_G['timestamp']);
	DB::query("delete from ".DB::table('it618_chat_kefu_talk')." where it618_uid=0 and it618_bz!='' and it618_time+".(3600*24*7)."<".$_G['timestamp']);
	DB::query("UPDATE ".DB::table('it618_chat_user_online')." set it618_isonline=0 WHERE it618_time<".($_G['timestamp']-3600));
}

function it618_chat_isonepagegroup($it618_chat_onepage){
	$onepagegroupids=it618_chat_getonepagegroupids($it618_chat_onepage);
	if(count($onepagegroupids)>0){
		$tmpgrouparr=it618_chat_getisvipuser($onepagegroupids);
		$isvipuser=count($tmpgrouparr[0]);
	
		if($isvipuser>0){
			return true;
		}
	}
	return false;
}

function it618_chat_getisvipuser($onepagegroupids){
	global $_G,$it618_chat,$it618_chat_lang;

	$okonepagegroupids = array(array(),array());
	
	if(count($onepagegroupids)>0){

		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
	
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$expgrouparray = $expirylist = $termsarray = array();
	
		if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
			$termsarray = $groupterms['ext'];
		}
		if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
			$termsarray[$_G['groupid']] = $groupterms['main']['time'];
		}
		
		foreach($termsarray as $expgroupid => $expiry) {
			if($expiry <= TIMESTAMP) {
				$expgrouparray[] = $expgroupid;
			}
		}
	
		$groupids = array();
		foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
			if(!empty($usergroup['pubtype'])) {
				$groupids[] = $groupid;
			}
		}
		
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
			}
		}
		
		if(!empty($groupterms['main'])) {
			$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
		}
		
		$expiryids = array_keys($expirylist);
		$groupids = array_merge($extgroupids, $expiryids, $groupids);
		
		if($groupids) {
			foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
				$groupid=$group['groupid'];
				
				if(in_array($groupid, $onepagegroupids)){
					
					$isgroupok=1;
					if($group['type']!='system'&&$group['type']!='member'){
						$timestamp=$expirylist[$group['groupid']]['timestamp'];
						$grouptime=$expirylist[$group['groupid']]['time'];
						
						if($timestamp-3600*24*365*60>$_G['timestamp']||$grouptime==''){
						}elseif($timestamp<$_G['timestamp']){
							$isgroupok=0;
						}
					}
					if($isgroupok==1){
						$okonepagegroupids[0][]=$groupid;
					}
				}
			}
		}
		
		if(!in_array($_G['groupid'], $okonepagegroupids[0])){
			if(in_array($_G['groupid'], $onepagegroupids)){
				$okonepagegroupids[0][]=$_G['groupid'];
			}
		}

	}
	
	return $okonepagegroupids;
}

function it618_chat_getonepagegroupids($it618_chat_onepage){
	global $_G,$it618_chat;
	
	$onepagegroupids = array();
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_chat_onepage_group')." WHERE it618_oid=".$it618_chat_onepage['id']." and it618_isok=1");
	while($it618_chat_onepage_group = DB::fetch($query)) {
		if($it618_chat_onepage_group['it618_groupid']>0){
			if(!in_array($it618_chat_onepage_group['it618_groupid'], $onepagegroupids)){
				$onepagegroupids[]=$it618_chat_onepage_group['it618_groupid'];
			}
		}
	}
	
	return $onepagegroupids;
}

function it618_chat_adminuids($topicid){
	if($it618_chat_topic=C::t('#it618_chat#it618_chat_topic')->fetch_by_id($topicid)){
		$tmptopicarr=explode("onepage_",$it618_chat_topic['it618_topic']);
		if($tmptopicarr[1]>0){
			$it618_chat_onepage=C::t('#it618_chat#it618_chat_onepage')->fetch_by_id($tmptopicarr[1]);
			return $it618_chat_onepage['it618_adminuids'];
		}
		
		$tmptopicarr=explode("brandvideo_",$it618_chat_topic['it618_topic']);
		if($tmptopicarr[1]>0){
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($tmptopicarr[1]);
			return $it618_brand_brand['it618_uid'];
		}
		
		$tmptopicarr=explode("tuanvideo_",$it618_chat_topic['it618_topic']);
		if($tmptopicarr[1]>0){
			$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($tmptopicarr[1]);
			return $it618_tuan_shop['it618_uid'];
		}
		
		$tmptopicarr=explode("videoshopqun_",$it618_chat_topic['it618_topic']);
		if($tmptopicarr[1]>0){
			$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($tmptopicarr[1]);
			return $it618_video_shop['it618_uid'];
		}
		
		$tmptopicarr=explode("examshopqun_",$it618_chat_topic['it618_topic']);
		if($tmptopicarr[1]>0){
			$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($tmptopicarr[1]);
			return $it618_exam_shop['it618_uid'];
		}
		
		$tmptopicarr=explode("video_",$it618_chat_topic['it618_topic']);
		if($tmptopicarr[1]>0){
			if($it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($tmptopicarr[1])){
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);
				$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
				return $it618_video_shop['it618_uid'];
			}
		}
	}
}

function mds_api($param){
	global $_G,$it618_chat,$it618_chat_lang;
	
	$method=$param['method'];
	$topic=$param['topic'];
	
	if($method=='history'){
		$tmparr=explode('kefu',$topic);
		if(count($tmparr)>1){
			$num=$it618_chat['chat_kefuhiscount'];
		}else{
			$num=$it618_chat['chat_qunhiscount'];
		}
		if($num>500)$num=500;
		//return mds_api_curl("history","/v1/historys/$topic/0/500");
		return mds_api_curl("history","/v2/historys?skip=0&num=$num&topic=$topic");
	}
	
	if($method=='sendMsg'){
		if(empty($param['content'])){
			return array(
				'Flag'=>101,
				'FlagString'=>$it618_chat_lang['s4']
			);
		}
		
		$tmpreturn = mds_api_curl("sendMsg","/v1/messages/$topic","POST",json_encode(array('body' => $param['content'])));
		if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
//		$s = var_export($tmpreturn,true);
//		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_chat/debug.txt',"a");
//		fwrite($fp,$s);
//		fclose($fp);
//
//		$tmparr=json_decode($tmpreturn['FlagString'],true);
	
		$tmparr=explode('kefu',$topic);
		if(count($tmparr)>1&&$tmpreturn['Flag']==100){
			
			if($it618_chat_kefu_talk=C::t('#it618_chat#it618_chat_kefu_talk')->fetch_by_it618_topic($topic)){
				if($it618_chat_kefu=C::t('#it618_chat#it618_chat_kefu')->fetch_by_id($it618_chat_kefu_talk['it618_kid'])){
					
					$tmparr=json_decode($param['content'],true);
					
					if($it618_chat_kefu['it618_uid']!=$_G['uid']){
						C::t('#it618_chat#it618_chat_kefu_talk')->update($it618_chat_kefu_talk['id'],array(
							'it618_bz' => it618_chat_utftogbk(urldecode($tmparr['body'])),
							'it618_count' => $it618_chat_kefu_talk['it618_count']+1,
							'it618_time' => $_G['timestamp']
						));
						if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
	
						if($it618_chat_user=C::t('#it618_chat#it618_chat_user')->fetch_by_uid($it618_chat_kefu['it618_uid'])){
							if($it618_chat_user['it618_time']+10<$_G['timestamp']){
								it618_chat_sendmessage('kefu_user',$it618_chat_kefu_talk['id']);
							}
						}else{
							it618_chat_sendmessage('kefu_user',$it618_chat_kefu_talk['id']);
						}
					}else{
						C::t('#it618_chat#it618_chat_kefu_talk')->update($it618_chat_kefu_talk['id'],array(
							'it618_userbz' => it618_chat_utftogbk(urldecode($tmparr['body'])),
							'it618_bz' => it618_chat_utftogbk(urldecode($tmparr['body'])),
							'it618_count' => 0,
							'it618_time' => $_G['timestamp']
						));
						if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
						if($it618_chat_kefu_talk['it618_usertime']+10<$_G['timestamp']){
							it618_chat_sendmessage('kefu_userclient',$it618_chat_kefu_talk['id']);
						}
					}
				}
			}
		}
			
		return $tmpreturn;
	}
	
	if($method=='getFaceGroups'){
		$query = DB::query("SELECT * FROM ".DB::table('it618_chat_facegroup')." ORDER BY it618_order");
		while($it618_chat_facegroup = DB::fetch($query)) {
			$it618_img=$it618_chat_facegroup['it618_img'];
			$tmparr=explode('://',$it618_img);
			if(count($tmparr)==1)$it618_img=$_G['siteurl'].$it618_img;
			
			$tmparr=array(
				'id'=>$it618_chat_facegroup['id'],
				'icon'=>$it618_img,
				'index'=>$it618_chat_facegroup['it618_order']
			);
			$facegrouparr[]=$tmparr;
		}
		
		return array(
			'Flag'=>100,
			'list'=>$facegrouparr
		);
	}
	
	if($method=='getFacesByGroup'){
		if(empty($param['groupId'])){
			return array(
				'Flag'=>101,
				'FlagString'=>$it618_chat_lang['s4']
			);
		}
		if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
		$groupId=intval($param['groupId']);
		$query = DB::query("SELECT * FROM ".DB::table('it618_chat_face')." where it618_group_id=$groupId ORDER BY it618_order");
		while($it618_chat_face = DB::fetch($query)) {
			$it618_img=$it618_chat_face['it618_img'];
			$tmparr=explode('://',$it618_img);
			if(count($tmparr)==1)$it618_img=$_G['siteurl'].$it618_img;
			
			$tmparr=array(
				'id'=>$it618_chat_face['id'],
				'groupId'=>$it618_chat_face['it618_group_id'],
				'text'=>'face_'.$it618_chat_face['it618_group_id'].'_'.$it618_chat_face['id'],
				'index'=>$it618_chat_face['it618_order'],
				'url'=>$it618_img
			);
			$facearr[]=$tmparr;
		}
		
		return array(
			'Flag'=>100,
			'list'=>$facearr
		);
	}
}

function mds_api_curl($do,$path,$method="GET",$content="",$expire=3600,$timeout=60){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php')){
		include DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php';
	}
	
	$host = "http://api.dms.aodianyun.com:80";
	
	$ch = curl_init();
	$expire = time() + $expire;
	$query_url = $host.$path;

	curl_setopt($ch,CURLOPT_URL,$query_url);
	curl_setopt($ch,CURLOPT_HEADER,false);
	
	curl_setopt($ch,CURLOPT_AUTOREFERER,true);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true);
	curl_setopt($ch,CURLOPT_FRESH_CONNECT,true);
	curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
	curl_setopt($ch,CURLOPT_TIMEOUT,$timeout);
	//	curl_setopt($ch,CURLOPT_USERAGENT,$useragent);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch,CURLOPT_BINARYTRANSFER,true);
	curl_setopt($ch,CURLOPT_CUSTOMREQUEST,$method);
	   // curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	if($method == 'POST') {
		curl_setopt($ch,CURLOPT_POST,true);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$content);
	} else if($method == 'PUT') {
		curl_setopt ($ch, CURLOPT_CUSTOMREQUEST, "PUT");   
		curl_setopt($ch, CURLOPT_POSTFIELDS,$content);
	}
	$authorization = 'Authorization: dms '.$adyun_dms_s_key;

	$header = array($authorization,'AD-Expire: '.$expire,'Content-Type: application/json');
	curl_setopt($ch,CURLOPT_HTTPHEADER, $header);

	$response = curl_exec($ch);
	$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

	curl_close($ch);
	
	if($response_code == 200 || $response_code == 201 || $response_code == 204) {
		if($do=='history'){
			$tmparr=json_decode(trim($response),true);
			for($i=0;$i<count($tmparr)-1;$i++){
				$tmparr1=explode("it618cmd",$tmparr[$i]['msg']);
				if(count($tmparr1)>1){
					mds_api_curl("","/v1/historys/".$tmparr[$i]['topic']."/uuid/".$tmparr[$i]['uuid'],"DELETE");
					continue;
				}
				$tmparr1=explode("it618clientuser",$tmparr[$i]['msg']);
				if(count($tmparr1)>1){
					mds_api_curl("","/v1/historys/".$tmparr[$i]['topic']."/uuid/".$tmparr[$i]['uuid'],"DELETE");
					continue;
				}
				
				$flag=0;
				$query = DB::query("SELECT * FROM ".DB::table('it618_chat_topic_del'));
				while($it618_chat_topic_del = DB::fetch($query)) {
					$tmparr1=explode('it618chatid'.$it618_chat_topic_del['it618_delid'],$tmparr[$i]['msg']);
					if(count($tmparr1)>1){
						mds_api_curl("","/v1/historys/".$tmparr[$i]['topic']."/uuid/".$tmparr[$i]['uuid'],"DELETE");
						C::t('#it618_chat#it618_chat_topic_del')->delete_by_id($it618_chat_topic_del['id']);
						$flag=1;
						break;
					}
				}
				if($flag==1)continue;

				$tmpmsgarr=json_decode($tmparr[$i]['msg'],true);
				$tmpmsgarr['body']=$tmpmsgarr['body'].'it618delbyuuid'.$tmparr[$i]['uuid'].'';
				$tmparr[$i]['msg']=json_encode($tmpmsgarr);
				$tmparrtmp[]=$tmparr[$i];
			}
			
			$rst = array(
				'Flag'=>100,
				'list'=>$tmparrtmp
			);
		}else{
			$rst = array(
				'Flag'=>100,
				'FlagString'=>trim($response)
			);
		}
	} else {
		$rr = json_decode(trim($response),true);
		if($rr) {
			$rst = $rr;
		} else {
			$rst = array(
				'Flag'=>$response_code,
				'FlagString'=>trim($response)
			);
		}
	}
	return $rst;
}

function it618_chat_getkefu($plugin,$sid,$wap,$pid=0) {
	global $_G,$it618_chat,$it618_chat_lang;

	$it618_chat = $_G['cache']['plugin']['it618_chat'];
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/lang.func.php';
	
	$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_plugin($plugin);
	if($it618_chat_kefu_class['it618_state']==1){
		
		$cid=$it618_chat_kefu_class['id'];
		if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
		if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_chat_kefu')." WHERE it618_cid=$cid and it618_sid=$sid and it618_state=1")==0){
			if($it618_chat_kefu_class['it618_isshare']==1){
				$sid=0;
				//if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_chat_kefu')." WHERE it618_cid=$cid and it618_sid=$sid and it618_state=1")==0)return;	
			}else{
				//return;	
			}
		}
		
		$stylearr=explode("|it618split|",$it618_chat_kefu_class['it618_style1']);
		$style_top=$stylearr[0];
		$style_width=$stylearr[1];
		$style_pccolor=$stylearr[2];
		$style_wapcolor=$stylearr[3];
		$style_wapfloat=$stylearr[4];
		if($style_wapfloat==1)$style_wapfloat='left';else $style_wapfloat='right';
		$style_wapwidth=$stylearr[5];
		$style_wapbottom=$stylearr[6];
		$style_title=$stylearr[7];
		$style_jquery=$stylearr[8];
		
		if($cid==1){
			$flag=0;
			$style_jquery=$style_jquery.'|spacecp&ac=avatar';
			if($style_jquery!=''){
				$tmparr=explode("|",$style_jquery);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode($tmparr[$i],$_SERVER['REQUEST_URI']);
					if(count($tmparr1)>1){
						$flag=1;
						break;
					}
					if($_SERVER['REQUEST_URI']=='/'&&$tmparr[$i]=='@'){
						$flag=1;
						break;
					}
				}
			}
			if($flag==0){
				$it618_members = $_G['cache']['plugin']['it618_members'];
				if($it618_members['']!='members_regloginstyle'){
					$jqueryjs='<SCRIPT src="source/plugin/it618_chat/js/jquery.js" type=text/javascript></'.'SCRIPT><script>jQuery.noConflict();</'.'SCRIPT>';
				}
			}
		}
		if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
		$query = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu_diy')." WHERE it618_cid=$cid and it618_sid=$sid and it618_order<10 and it618_order>0 ORDER BY it618_order");
		while($it618_chat_kefu_diy = DB::fetch($query)) {
			
			$diytopstr.='<h3>'.$it618_chat_kefu_diy['it618_title'].'</h3>
					<ul>
						<li><span>'.$it618_chat_kefu_diy['it618_content'].'</span></li>
					</ul>';
		}
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu')." WHERE it618_cid=$cid and it618_sid=$sid and it618_state=1 ORDER BY it618_order");
		while($it618_chat_kefu = DB::fetch($query)) {
			$kefustr.='<tr onclick="layeriframe(\''.$it618_chat_lang['s123'].$it618_chat_kefu['it618_name'].$it618_chat_lang['s124'].'\','.$it618_chat_kefu['id'].',\''.$plugin.'\','.$pid.')"><td class="avatarimg"><img src="source/plugin/it618_chat/images/anonymous.png"></td><td>'.$it618_chat_kefu['it618_name'].'</td></tr>';
		}
		if($kefustr!=''){
			$diytopstr.='<h3>'.$style_title.'</h3>
					<ul>
						<li><table class="tablekefu">'.$kefustr.'</table></li>
					</ul>';
		}
		if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
		$query = DB::query("SELECT * FROM ".DB::table('it618_chat_kefu_diy')." WHERE it618_cid=$cid and it618_sid=$sid and it618_order>10 ORDER BY it618_order");
		while($it618_chat_kefu_diy = DB::fetch($query)) {
			
			$diytopstr.='<h3>'.$it618_chat_kefu_diy['it618_title'].'</h3>
					<ul>
						<li><span>'.$it618_chat_kefu_diy['it618_content'].'</span></li>
					</ul>';
		}
		
		if(C::t('#it618_chat#it618_chat_kefu')->count_by_uid($_G['uid'])>0){
			$diytopstr.='<ul>
						<li onclick="layerkefuadmin()" class="likefu">'.$it618_chat_lang['s56'].'</li>
					</ul>';
		}
		
		if($wap==1){
			$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
			$_G['mobiletpl'][IN_MOBILE]='/'; //DisM �� Taobao �� Com
			include template('it618_chat:kefu_client');
			$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
		}else{
			include template('it618_chat:kefu_client');
		}
		
		$commoncode=C::t('#it618_chat#it618_chat_set')->getsetvalue_by_setname('commoncode');
		
		return $it618_kefu_block.$commoncode;
	}else{
		return;
	}
}

function it618_chat_getarea($ip = ''){
	$url = "http://ip.taobao.com/service/getIpInfo.php?ip=".$ip;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_TIMEOUT,3); 
	$res = curl_exec($ch);
	
	curl_close( $ch );
	$data = json_decode($res, true);
	
    return it618_chat_utftogbk($data['data']['city']);
}

function it618_chat_getshopname($plugin,$sid){
	if($plugin=='it618_discuz')return;
	if($sid==0)return;
	
	if($plugin=='it618_brand'){
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($sid);
		$shopname=$it618_brand_brand['it618_name'];
	}
	
	if($plugin=='it618_tuan'){
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($sid);
		$shopname=$it618_tuan_shop['it618_name'];
	}
	
	if($plugin=='it618_video'){
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($sid);
		$shopname=$it618_video_shop['it618_name'];
	}
	
	return $shopname;
}

function it618_chat_sendmessage($type,$id,$type1=''){
	global $_G,$it618_chat,$it618_chat_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_chat/config/message.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			
		}
		
		if($type=='kefu_user'&&$it618_body_kefu_user_isok==1){
			$tmpurl='plugin.php?id=it618_chat:kefuwap&tid='.$id;
			
			$it618_chat_kefu_talk = C::t('#it618_chat#it618_chat_kefu_talk')->fetch_by_id($id);
			$it618_chat_kefu=C::t('#it618_chat#it618_chat_kefu')->fetch_by_id($it618_chat_kefu_talk['it618_kid']);
			$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($it618_chat_kefu['it618_cid']);
			if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
			$kefuname=$it618_chat_kefu_class['it618_name'];
			$shopname=it618_chat_getshopname($it618_chat_kefu_class['it618_plugin'],$it618_chat_kefu['it618_sid']);
			if($shopname!='')$shopname='-'.$shopname;
			$kefuname=$kefuname.$shopname;
			
			if($it618_chat_kefu_talk['it618_uid']>0){
				$talkuname=it618_chat_getusername($it618_chat_kefu_talk['it618_uid']);
			}else{
				$talkuname=$it618_chat_lang['s129'].$it618_chat_kefu_talk['id'];
			}
			
			$tmpgoodsname=explode("it618chatgoodsurl",$it618_chat_kefu_talk['it618_bz']);
			$tmpgoodsname=explode("it618chatid",$tmpgoodsname[0]);
			
			$tel=$it618_chat_kefu['it618_tel'];
			$Body=$it618_body_kefu_user;
			if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
			$uid=$it618_chat_kefu['it618_uid'];
			$tplid_wxsms=$it618_body_kefu_user_tplid_wxsms;
			$body_wxsms=$it618_body_kefu_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{kefuname}",$kefuname,$tmpvalue);
					$tmpvalue=str_replace("{kefuuser}",$it618_chat_kefu['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{talkuname}",$talkuname,$tmpvalue);
					$tmpvalue=str_replace("{talk}",cutstr($tmpgoodsname[0],300),$tmpvalue);
					$tmpvalue=str_replace("{user}",it618_chat_getusername($it618_chat_kefu['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_chat_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{kefuname}",$kefuname,$Body);
			$Body=str_replace("{kefuuser}",$it618_chat_kefu['it618_name'],$Body);
			$Body=str_replace("{talkuname}",$talkuname,$Body);
			$Body=str_replace("{talk}",cutstr($tmpgoodsname[0],30),$Body);
			$Body=str_replace("{user}",it618_chat_getusername($it618_chat_kefu['it618_uid']),$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_kefu_user_tplid;
				
				$tmparr=explode("{kefuname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"kefuname":"'.$kefuname.'",';
				
				$tmparr=explode("{kefuuser}",$ALDYBody);
				if(count($tmparr)>1)$param.='"kefuuser":"'.$it618_chat_kefu['it618_name'].'",';
				
				$tmparr=explode("{talkuname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"talkuname":"'.$talkuname.'",';
				
				$tmparr=explode("{talk}",$ALDYBody);
				if(count($tmparr)>1)$param.='"talk":"'.cutstr($it618_chat_kefu_talk['it618_bz'],30).'",';
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_chat_getusername($it618_chat_kefu['it618_uid']).'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='kefu_userclient'&&$it618_body_kefu_userclient_isok==1){
			$it618_chat_kefu_talk = C::t('#it618_chat#it618_chat_kefu_talk')->fetch_by_id($id);
			$tmpurl='plugin.php?id=it618_chat:chat&type=kefu&wxkefu&typeid='.$it618_chat_kefu_talk['it618_kid'];
			$it618_chat_kefu=C::t('#it618_chat#it618_chat_kefu')->fetch_by_id($it618_chat_kefu_talk['it618_kid']);
			$it618_chat_kefu_class=C::t('#it618_chat#it618_chat_kefu_class')->fetch_by_id($it618_chat_kefu['it618_cid']);
			if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
			$kefuname=$it618_chat_kefu_class['it618_name'];
			$shopname=it618_chat_getshopname($it618_chat_kefu_class['it618_plugin'],$it618_chat_kefu['it618_sid']);
			if($shopname!='')$shopname='-'.$shopname;
			$kefuname=$kefuname.$shopname;
			
			$Body=$it618_body_kefu_userclient;
			if(lang('plugin/it618_chat', $it618_chat_lang['it618'])!=$it618_chat_lang['version'])exit;
			$uid=$it618_chat_kefu_talk['it618_uid'];
			$tplid_wxsms=$it618_body_kefu_userclient_tplid_wxsms;
			$body_wxsms=$it618_body_kefu_userclient_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpgoodsname=explode("it618chatgoodsurl",$it618_chat_kefu_talk['it618_userbz']);
					$tmpgoodsname=explode("it618chatid",$tmpgoodsname[0]);
					
					$tmpvalue=str_replace("{kefuname}",$kefuname,$tmpvalue);
					$tmpvalue=str_replace("{kefuuser}",$it618_chat_kefu['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{talk}",cutstr($tmpgoodsname[0],300),$tmpvalue);
					$tmpvalue=str_replace("{user}",it618_chat_getusername($it618_chat_kefu_talk['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_chat_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_chat/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($Body!=''&&$tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);

				if($it618_smsbaosign!='')$it618_smsbaosign=it618_chat_getlang('s890').$it618_smsbaosign.it618_chat_getlang('s891');
				if($it618_type=='smsbao'){
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}

function it618_chat_getrewrite_plugin($plugin,$pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	
	if($_G['cache']['plugin'][$plugin]['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/'.$plugin.'/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/'.$plugin.'/config/rewrite.php';
	
	if($pagetype=='shop_home'){//shop-{sid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$shop_home.$shop_home1;
		
		if(count($tmparr)>1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=$pageurl.'?'.$tmparr[1];
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_page'){//shop_page-{sid}-{oid}.html
		$tmparr=explode("@",$pagevalue);
		
		$pageurl=$shop_page.$shop_page1;
		$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		$pageurl=str_replace("{oid}",$tmparr[1],$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='brand_wap'){//brand_wap-{pagetype}-{sid}-{oid}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$brand_wap.$brand_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{sid}-{oid}-{cid}-{page}","",$pageurl);
		}else{
			$tmparr=explode("@",$pagevalue);
			if(count($tmparr)==2){
				$pageurl=str_replace("-{oid}-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
			}if(count($tmparr)==3){
				$pageurl=str_replace("-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
			}else{
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_lecturer'){//lecturer-{lid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_lecturer.$video_lecturer1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{lid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_wap'){//video_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_wap.$video_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_shop'){//tuan_shop-{sid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_shop.$tuan_shop1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_wap'){//tuan_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_wap.$tuan_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_chat_get_contents($str){
	return dfsockopen($str);
}

function it618_chat_getusername($uid){
	return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
}

function it618_chat_getpluginstate($plugin){
	if($plugin=='it618_discuz')return true;
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/'.$plugin.'/ajax.inc.php')){
		return true;
	}else{
		return false;
	}
}

function it618_chat_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_chat_utftogbk($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_chat_gbktoutf($strcontent);
	}
}

function it618_chat_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function chat_is_mobile(){ 
	global $_GET;
	if(isset($_GET['pc'])) return false;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: d'.'is'.'m.ta'.'obao.com
?>