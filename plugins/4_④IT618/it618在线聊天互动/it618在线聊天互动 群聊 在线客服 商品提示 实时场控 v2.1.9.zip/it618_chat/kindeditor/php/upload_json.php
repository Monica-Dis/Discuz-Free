<?php
 /**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/**
 * KindEditor PHP
 *
 * 本PHP程序是演示程序，建议不要直接在实际项目中使用。
 * 如果您确定直接使用本程序，使用之前请仔细确认相关安全设置。
 *
 */

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', 1);
require '../../../../../source/class/class_core.php';

$DiscuzApp = C::app();
$DiscuzApp->init();

loadcache('plugin');

global $_G;
if($_G['uid']<=0){
	echo 'login';exit;
}

$pluginname='it618_chat';

if(isset($_GET['oss'])){
	$isoss=1;
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/'.$pluginname.'/kindeditor/php/aliyunossconfig.php')){
	require_once DISCUZ_ROOT.'./source/plugin/'.$pluginname.'/kindeditor/php/aliyunossconfig.php';
	if($it618_isok==1){
		$isoss=1;
	}
}

require_once 'JSON.php';
date_default_timezone_set("PRC");

$tmpstr='aliyunosstmp.php';
if($isoss==1){
	$tmpstr='aliyunoss.php';
}
require_once $tmpstr;

$php_path = dirname(__FILE__) . '/';
$php_url = dirname($_SERVER['PHP_SELF']) . '/';

//文件保存目录路径
$save_path = $php_path . '../attached/';
//文件保存目录URL
$save_url = $php_url . '../attached/';

if(isset($_GET['shopid']) && $_GET['shopid']){
	$shopid=intval($_GET['shopid']);
	//文件保存目录路径
	$save_path = $php_path . '../data/shop'.$shopid.'/';
	//文件保存目录URL
	$save_url = $php_url . '../data/shop'.$shopid.'/';
	if (!file_exists($save_path)) {
		mkdir($save_path);
	}
	
	$config_path = $php_path . '../data/shop'.$shopid.'/';
	if(file_exists($config_path.'config.php')){
		require_once $config_path.'config.php';
		$allsize = dirsize($config_path); 
		$allsize = $allsize/1024/1024; 
		
		if($allsize>=$filespace){
			alert("抱歉，您的空间最多只能上传".$filespace."M，您现在空间已用".sprintf("%.2f", $allsize)."M！");
		}
	}
}

if(isset($_GET['uid']) && $_GET['uid']){
	$uid=intval($_GET['uid']);
	
	$save_path = $php_path . '../data/user/';
	if (!file_exists($save_path)) {
		mkdir($save_path);
	}
	//文件保存目录路径
	$save_path = $php_path . '../data/user/u'.$uid.'/';
	//文件保存目录URL
	$save_url = $php_url . '../data/user/u'.$uid.'/';
	if (!file_exists($save_path)) {
		mkdir($save_path);
	}
	
	$save_path1 = $php_path . '../data/user/u'.$uid.'/smallimage/';
	if (!file_exists($save_path1)) {
		mkdir($save_path1);
	}
}
 
function dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
} 

//定义允许上传的文件扩展名
//$media_arr=array('swf', 'flv', 'mp3', 'wav', 'wma', 'wmv', 'mid', 'avi', 'mpg', 'asf', 'rm', 'rmvb');
//$flash_arr=array('swf', 'flv');

$image_arr=explode(",",$it618_image_ext);
if($image_arr[0]==''){
	$image_arr=array('gif', 'jpg', 'jpeg', 'png', 'bmp');
}

$file_arr=explode(",",$it618_file_ext);
if($file_arr[0]==''){
	$file_arr=array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'pdf', 'htm', 'html', 'txt', 'zip', 'rar', 'gz', 'bz2');
}

$ext_arr = array(
	'image' => $image_arr,
	'file' => $file_arr,
);

//最大文件大小
if($it618_image_max_size==0){
	$image_max_size = 100000000;
}else{
	$image_max_size=$it618_image_max_size*1024*1024;
}
if($it618_file_max_size==0){
	$file_max_size = 100000000;
}else{
	$file_max_size=$it618_file_max_size*1024*1024;
}

$save_path = realpath($save_path) . '/';

//PHP上传失败
if (!empty($_FILES['imgFile']['error'])) {
	switch($_FILES['imgFile']['error']){
		case '1':
			$error = '超过php.ini允许的大小！';
			break;
		case '2':
			$error = '超过表单允许的大小！';
			break;
		case '3':
			$error = '图片只有部分被上传！';
			break;
		case '4':
			$error = '请 选 择图片！';
			break;
		case '6':
			$error = '找不到临时目录！';
			break;
		case '7':
			$error = '写文件到硬盘出错！';
			break;
		case '8':
			$error = 'File upload stopped by extension！';
			break;
		case '999':
		default:
			$error = '未知错误！';
	}
	alert($error);
}

//有上传文件时
if (empty($_FILES) === false) {
	//原文件名
	$file_name = $_FILES['imgFile']['name'];
	//服务器上临时文件名
	$tmp_name = $_FILES['imgFile']['tmp_name'];
	//文件大小
	$file_size = $_FILES['imgFile']['size'];
	//检查文件名
	if (!$file_name) {
		alert("请选择文件！");
	}
	//检查目录
	if (@is_dir($save_path) === false) {
		alert("上传目录不存在！");
	}
	//检查目录写权限
	if (@is_writable($save_path) === false) {
		alert("上传目录没有写权限！");
	}
	//检查是否已上传
	if (@is_uploaded_file($tmp_name) === false) {
		alert("上传失败！");
	}
	//检查目录名
	$dir_name = empty($_GET['dir']) ? 'image' : trim($_GET['dir']);
	if (empty($ext_arr[$dir_name])) {
		alert("目录名不正确！");
	}
	//检查文件大小
	if($dir_name=='image'){
		if ($file_size > $image_max_size) {
			alert("上传图片大小超过".($image_max_size/1024/1024)."M限制！");
		}
	}else{
		if ($file_size > $file_max_size) {
			alert("上传文件大小超过".($file_max_size/1024/1024)."M限制！");
		}
	}
	//获得文件扩展名
	$temp_arr = explode(".", $file_name);
	$file_ext = array_pop($temp_arr);
	$file_ext = trim($file_ext);
	$file_ext = strtolower($file_ext);
	//检查扩展名
	if($dir_name!='image'){
		if($isoss!=1&&$_G['groupid']!=1){
			//alert("非图片文件只有管理组会员可以上传到空间，非管理组会员只能上传到远程OSS，请联系管理员设置OSS接口！");
		}
		if($_GET['filetype']=='txt'&&$file_ext!='txt'){
			alert("只能上传txt记事本文件！");
		}
		if($_GET['filetype']=='xls'&&$file_ext!='xls'){
			alert("只能上传扩展名为.xls的excel文件！");
		}
	}
	
	if (in_array($file_ext, $ext_arr[$dir_name]) === false) {
		alert("上传文件扩展名是不允许的扩展名。\n只允许" . implode(",", $ext_arr[$dir_name]) . "格式！");
	}
	
	//创建文件夹
	if ($dir_name !== '') {
		$save_path .= $dir_name . "/";
		$save_url .= $dir_name . "/";
		if (!file_exists($save_path)) {
			mkdir($save_path);
		}
	}
	$ymd = date("Ymd");
	if($isoss==1)$ymd='tmposs';
	$save_path .= $ymd . "/";
	$save_url .= $ymd . "/";
	if (!file_exists($save_path)) {
		mkdir($save_path);
	}
	//新文件名
	if(isset($_GET['safefilename'])){
		$new_file_name = date("YmdHis") . '_' . mt_rand(1000000000, 9999999999) . '.' . $file_ext;
	}else{
		$new_file_name = date("YmdHis") . '_' . mt_rand(10000, 99999) . '.' . $file_ext;
	}
	
	if($dir_name!='image'){
		$file_name=str_replace('.' . $file_ext,"",$file_name);
		$new_file_name=gbktoutf($file_name). '_' . mt_rand(10000, 99999) . '.' . $file_ext;
	}
	//移动文件
	$file_path = $save_path . $new_file_name;
	if (move_uploaded_file($tmp_name, $file_path) === false) {
		alert("上传文件失败！");
	}

	$tmparr=@getimagesize($file_path);
	if($tmparr === FALSE){
		if($file_ext=='gif'||$file_ext=='jpg'||$file_ext=='jpeg'||$file_ext=='png'){
			if(file_exists($file_path)){
				$result=unlink($file_path);
			}
			echo 'err';exit;
		}
	}else{
		$imgwidth=1200;
		if(isset($_GET['imgwidth'])){
			$imgwidth=intval($_GET['imgwidth']);
		}
		imagetosmall($file_path,$imgwidth);
	}
	
	@chmod($file_path, 0644);
	
	if($isoss==1){
		$ymd = date("Ymd");
		$object =  $pluginname."/".$dir_name."/".$ymd."/".$new_file_name;
		$content = $file_path;
		try {
		$ossClient->uploadFile($it618_bucket_name, $object, $content);
		} catch (OssException $e) {
			print $e->getMessage();
		}
		
		if(file_exists($file_path)){
			$result=unlink($file_path);
		}
		
		$file_url = $it618_bucket_url.'/'.$object;
		$file_url=str_replace("//".$pluginname."/","/".$pluginname."/",$file_url);
	}else{
		$file_url = $save_url . $new_file_name;
	}

	header('Content-type: text/html; charset=UTF-8');
	$json = new Services_JSON();
	echo $json->encode(array('error' => 0, 'url' => $file_url));
	exit;
}

function imagetosmall($imagepath,$max){
	$file_ext=strtolower(substr($imagepath,strrpos($imagepath, '.')+1)); 
	
	//因为PHP只能对资源进行操作，所以要对需要进行缩放的图片进行拷贝，创建为新的资源 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($imagepath); 
	if($file_ext=='png'){
		$src=imagecreatefrompng($imagepath); 
		imagesavealpha($src,true);
	}
	if($file_ext=='gif')$src=imagecreatefromgif($imagepath); 
	
	//取得源图片的宽度和高度 
	$size_src=@getimagesize($imagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$max指定缩放出来的最大的宽度（也有可能是高度）
	
	//根据最大值，算出另一个边的长度，得到缩放后的图片宽度和高度 
	if($w > $max){ 
	   $w=$max;
	   $h=$h*($max/$size_src['0']); 
	}
	
	//声明一个$w宽，$h高的真彩图片资源 
	$image=imagecreatetruecolor($w, $h); 
	if($file_ext=='png'){
		imagealphablending($image,false);
		imagesavealpha($image,true);
	}
	 
	//关键函数，参数（目标资源，源，目标资源的开始坐标x,y, 源资源的开始坐标x,y,目标资源的宽高w,h,源资源的宽高w,h） 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if(file_exists($imagepath)){
		$result=unlink($imagepath);
	}
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$imagepath); 
	if($file_ext=='png')imagepng($image,$imagepath); 
	if($file_ext=='gif')imagegif($image,$imagepath); 
	@chmod($imagepath, 0644);
	
	//销毁资源 
	imagedestroy($image);  
}

function gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function alert($msg) {
	header('Content-type: text/html; charset=UTF-8');
	$json = new Services_JSON();
	echo $json->encode(array('error' => 1, 'message' => $msg));
	exit;
}
