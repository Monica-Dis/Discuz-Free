// pages/wxpay/wxpay.js
Page({

  data: {
    request_url: getApp().globalData.siteurl + 'plugin.php?id=it618_wxmini:ajax&aid=' + getApp().globalData.aid
  },

  onLoad: function (options) {
    //console.log(options)
    wx.request({
      url: this.data.request_url,
      data: {
        ac:"wxpay",
        aid: getApp().globalData.aid,
        out_trade_no: options.out_trade_no,
        openid: getApp().globalData.openid
      },
      success: function (result) {
        //console.log(result)
        wx.setNavigationBarTitle({
          title: result.data.body
        })
        var payokurl=''
        wx.requestPayment({
          'timeStamp': result.data.timeStamp,
          'nonceStr': result.data.nonceStr,
          'package': result.data.package,
          'signType': 'MD5',
          'paySign': result.data.paySign,
          'success': function (res) {
            payokurl = encodeURIComponent(result.data.url)
          },
          'fail': function (res) { 
          },
          'complete': function (res) { 
            wx.navigateBack()
            if (payokurl!=''){
              wx.redirectTo({
                url: '/pages/index/index?url=' + payokurl
              })
            }
           }
        })
      }
    })
  }
})