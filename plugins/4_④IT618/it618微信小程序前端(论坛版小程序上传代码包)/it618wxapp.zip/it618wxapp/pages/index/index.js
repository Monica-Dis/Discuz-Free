//index.js
//获取应用实例
Page({

  data: {
    siteurl: getApp().globalData.siteurl,
    aid: getApp().globalData.aid,
    web_src: getApp().globalData.siteurl + 'plugin.php?id=it618_wxmini:index&aid=' + getApp().globalData.aid
  },

  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: getApp().globalData.title
    })

    if (options.url) {
      this.setData({
        web_src: decodeURIComponent(options.url)
      })
    }
  },
  
  onShareAppMessage(shareres) {
    if (shareres.from === 'menu') {
      var url = encodeURIComponent(shareres.webViewUrl);
      return {
        title: '分享此页面给好友',
        path: '/pages/index/index?url=' + url,
        success: function (res) {
          wx.showToast({
            title: "转发成功",
            icon: 'success',
            duration: 2000
          })
        },
        fail: function (res) {
        }
      }
    }
  }
})
