App({
  globalData: {
    siteurl: "https://www.cnit618.com/",//必填 网站域名 如：https://www.cnit618.com/
    aid: 1,//必填 it618微信小程序插件后台应用管理的aid，不是小程序的appid
    title: "IT618",//必填 小程序名称 这个用于小程序跳转时默认显示的标题
    openid: ""//不填
  }
})

wx.login({
  success(res) {
    if (res.code) {
      wx.request({
        url: getApp().globalData.siteurl + 'plugin.php?id=it618_wxmini:login&aid=' + getApp().globalData.aid,
        data: {
          code: res.code
        },
        success: function (result) {
          getApp().globalData.openid = result.data.openid
        }
      })
    } else {
      console.log(res.errMsg)
    }
  }
})