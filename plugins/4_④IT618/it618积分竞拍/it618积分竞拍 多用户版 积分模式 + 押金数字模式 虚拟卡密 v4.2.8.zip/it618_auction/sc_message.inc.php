<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/sc_header.func.php';

if(submitcheck('it618submit')){
	if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_message')." where it618_uid=".$_G['uid'])==0){
		C::t('#it618_auction#it618_auction_message')->insert(array(
			'it618_uid' => $_G['uid'],
			'it618_tel' => $_GET['it618_tel'],
			'it618_isok' => $_GET['it618_isok']
		), true);
	}else{
		$id=DB::result_first("SELECT id FROM ".DB::table('it618_auction_message')." where it618_uid=".$_G['uid']);
		C::t('#it618_auction#it618_auction_message')->update($id,array(
			'it618_tel' => $_GET['it618_tel'],
			'it618_isok' => $_GET['it618_isok']
		));
	}

	it618_cpmsg(it618_auction_getlang('s631'), "plugin.php?id=it618_auction:sc_message$adminsid", 'succeed');
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_auction/config/message.php';
}

if($it618_isok==1){
	$tmpstr='<font color="green">'.it618_auction_getlang('s655').'</font> ';
	if($it618_body_sale_shop_isok==1)$tmpstr.='<img src="source/plugin/it618_auction/images/se.gif">';else $tmpstr.='<img src="source/plugin/it618_auction/images/se0.gif">';
	$tmpstr.='<br><font color="green">'.it618_auction_getlang('s699').'</font> ';
	if($it618_body_sale_shop_isok==1)$tmpstr.='<img src="source/plugin/it618_auction/images/se.gif">';else $tmpstr.='<img src="source/plugin/it618_auction/images/se0.gif">';
	
	if($it618_auction['auction_isrzcheck']==0){
		$tmpstr.='<br><font color="green">'.it618_auction_getlang('s822').'</font> ';
		if($it618_body_rz_shop_isok==1)$tmpstr.='<img src="source/plugin/it618_auction/images/se.gif">';else $tmpstr.='<img src="source/plugin/it618_auction/images/se0.gif">';
	}

	$tmpstr.='<br><br><img src="source/plugin/it618_auction/images/se.gif"> '.it618_auction_getlang('s654');
	
}else{
	$tmpstr=it618_auction_getlang('s653');
}

it618_showformheader("plugin.php?id=it618_auction:sc_message");
showtableheaders(it618_auction_getlang('s632'),'it618_auction_message');

$it618_auction_message=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_message')." where it618_uid=".$_G['uid']);
if($it618_auction_message['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
echo '
<tr><td width=130>'.it618_auction_getlang('s656').'</td><td style="line-height:22px">'.$tmpstr.'</td></tr>
<tr><td colspan=2><strong>'.it618_auction_getlang('s657').'</strong></td></tr>
<tr><td width=110>'.it618_auction_getlang('s658').'</td><td><input type="checkbox" id="it618_isok" name="it618_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.it618_auction_getlang('s659').'</label></td></tr>
<tr><td>'.it618_auction_getlang('s660').'</td><td><input type="text" class="txt" style="width:300px" name="it618_tel" value="'.$it618_auction_message['it618_tel'].'" maxlength="11" onkeyup="value=value.replace(/[^\-?\d.]/g,\'\')"> '.it618_auction_getlang('s661').'</td></tr>
<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_auction_getlang('s662').'" /></div></td></tr>
';

showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/sc_footer.func.php';
?>