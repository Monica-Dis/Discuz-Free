<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_default.func.php';

if(auction_is_mobile()){ 
	$tmpurl=it618_auction_getrewrite('auction_wap','','plugin.php?id=it618_auction:wap');
	dheader("location:$tmpurl");
}

$aid=intval($_GET['aid']);

if(!($it618_auction_article = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_article')." WHERE id=".$aid))){
	ddheader("location:plugin.php?id=it618_auction:auction");
}
DB::query("update ".DB::table('it618_auction_article')." set it618_views=it618_views+1 WHERE id=".$aid);
$it618_classname=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_auction_article_class')." where id=".$it618_auction_article['it618_class_id']);

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_article_class')." where it618_order>0 order by it618_order desc");
while($it618_auction_article_class = DB::fetch($query)) {
	if($it618_auction_article_class['it618_color']!=''){
		$it618_classname='<font color='.$it618_auction_article_class['it618_color'].'>'.$it618_auction_article_class['it618_classname'].'</font>';
	}else{
		$it618_classname=$it618_auction_article_class['it618_classname'];
	}
	$articlelisttmp='<div class="v_mod_article"><div class="hd"><h3 class="f_tx1">'.$it618_classname.'</h3></div><div class="bd"><ul>';
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_article')." where it618_class_id=".$it618_auction_article_class['id']." and it618_order>0 order by it618_order desc");
	while($it618_auction_article1 = DB::fetch($query1)) {
		if($it618_auction_article['it618_color']!=''){
			$it618_name='<font color='.$it618_auction_article1['it618_color'].'>'.$it618_auction_article1['it618_name'].'</font>';
		}else{
			$it618_name=$it618_auction_article1['it618_name'];
		}
		$tmpurl=it618_auction_getrewrite('auction_article',$it618_auction_article1['id'],'plugin.php?id=it618_auction:auction_article&aid='.$it618_auction_article1['id']);
		$articlelisttmp.='<li><a href="'.$tmpurl.'" target="_blank">'.$it618_name.'</a></li>';
	}
	$articlelisttmp.='</ul></div></div>';
	
	$articlelist.=$articlelisttmp;
}

$classid=DB::result_first("SELECT it618_class_id FROM ".DB::table('it618_auction_article')." WHERE id=".$aid);
$classname=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_auction_article_class')." WHERE id=".$classid);

$it618_title='<span>'.$classname.'</span><span class="split">&gt;</span><span>'.$it618_auction_article['it618_name'].'</span>';

$pagetype='article';
$navtitle=$it618_auction_article['it618_name'].' - '.$navtitle;
include template('it618_auction:auction_default');
?>