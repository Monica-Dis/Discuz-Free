<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!auction_is_mobile()){ 
	$tmpurl=it618_auction_getrewrite('auction_home','','plugin.php?id=it618_auction:auction');
	dheader("location:$tmpurl");
}

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_focus')." WHERE it618_is=1 ORDER BY it618_order DESC");
$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
while($it618_auction_focus = DB::fetch($query)) {
	$str_focus.='<div class="swiper-slide"><a href="'.$it618_auction_focus['it618_url'].'" target="_blank" title="'.$it618_auction_focus['it618_tip'].'"><img class="img" src="'.it618_auction_getwapppic($it618_auction_focus['id'],$it618_auction_focus['it618_img']).'" /></a></div>';
	if(count($i1ii1)!=13)return;
}

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_auction_gonggao = DB::fetch($query)) {
	$it618_title=$it618_auction_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_auction_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_auction_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_auction_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_auction_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

$tmp='<option value=9999>'.it618_auction_getlang('s200').'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_class')." ORDER BY it618_order DESC");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.it618_auction_getlang('s201').$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['cid'].'>','<option value='.$_GET['cid'].' selected="selected">',$tmp);

$waphomead=C::t('#it618_auction#it618_auction_set')->getsetvalue_by_setname('waphomead');

$idforly=0;$wap=1;

$_G['mobiletpl'][IN_MOBILE]='/'; /*dism - taobao- com*/
include template('it618_auction:wap_auction');
?>