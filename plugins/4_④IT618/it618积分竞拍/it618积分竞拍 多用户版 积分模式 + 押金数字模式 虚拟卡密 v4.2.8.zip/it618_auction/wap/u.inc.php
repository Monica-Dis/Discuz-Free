<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!auction_is_mobile()){
	dheader("location:$auction_home");
}

$navtitle=it618_auction_getlang('s544');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_auction_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*dism - taobao- com*/
	include template('it618_auction:wap_auction');
	return;
}

$it618_members = $_G['cache']['plugin']['it618_members'];
$menuusername=$_G['username'];
$u_avatarimg=it618_auction_discuz_uc_avatar($_G['uid'],'middle');
$creditname1=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
$creditname2=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];
$creditnum1=DB::result_first("select extcredits".$it618_auction['auction_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
$creditnum2=DB::result_first("select extcredits".$it618_auction['auction_credit_yj']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_buygroup=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$tmpurl_myvip=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$viplogo='source/plugin/it618_credits/images/group.png';
}

if($IsGroup==1){
	$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	$viplogo='source/plugin/it618_group/images/group.png';
}

if($IsUnion==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
}

$ucurl1=it618_auction_getrewrite('auction_wap','myprice@'.$_G['uid'].'@0','plugin.php?id=it618_auction:wap&pagetype=myprice');
$ucurl2=it618_auction_getrewrite('auction_wap','mysale@'.$_G['uid'].'@0','plugin.php?id=it618_auction:wap&pagetype=mysale');

$pricecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_uid=".$_G['uid']);
$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state<>0 and it618_state<>3 and it618_uid=".$_G['uid']);

$wappriceurl=it618_auction_getrewrite('auction_wap','price@'.$_G['uid'].'@0','plugin.php?id=it618_auction:wap&pagetype=price');
$wapsaleurl=it618_auction_getrewrite('auction_wap','sale@'.$_G['uid'].'@0','plugin.php?id=it618_auction:wap&pagetype=sale');

$allpricecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price'));
$allsalecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state<>0 and it618_state<>3");

$_G['mobiletpl'][IN_MOBILE]='/'; /*dism - taobao- com*/
include template('it618_auction:wap_auction');
?>