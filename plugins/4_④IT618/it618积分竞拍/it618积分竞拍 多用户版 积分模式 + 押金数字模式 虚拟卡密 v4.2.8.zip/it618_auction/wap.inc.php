<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_function.func.php';

$metakeywords = $it618_auction['seokeywords'];
$metadescription = $it618_auction['seodescription'];
$sitetitle=$it618_auction['seotitle'];
$navtitle=$sitetitle;

$waphome=it618_auction_getrewrite('auction_wap','','plugin.php?id=it618_auction:wap');
$auction_home=it618_auction_getrewrite('home','','plugin.php?id=it618_auction:auction');

$pid=intval($_GET['cid']);
$product_home=it618_auction_getrewrite('product',$pid,'plugin.php?id=it618_auction:auction_page&pid='.$pid);

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_auction#it618_auction_wapstyle')->count_by_isok_search();
$it618_auction_wapstyle=C::t('#it618_auction#it618_auction_wapstyle')->fetch_by_isok_search();

if(isset($_GET['pagetype'])){
	$pagetype=$_GET['pagetype'];
}else{
	$pagetype='auction';
}

if($_G['uid']>0){
	
	$ucurl1=it618_auction_getrewrite('auction_wap','myprice@'.$_G['uid'].'@0','plugin.php?id=it618_auction:wap&pagetype=myprice');
	$ucurl2=it618_auction_getrewrite('auction_wap','mysale@'.$_G['uid'].'@0','plugin.php?id=it618_auction:wap&pagetype=mysale');
	$uc='<li><a href="javascript:" onclick="showset()" class="react">'.it618_auction_getlang('s1055').'</a></li><li><a class="react" href="'.$ucurl1.'">'.it618_auction_getlang('t122').'</a></li><li><a class="react" href="'.$ucurl2.'">'.it618_auction_getlang('t116').'</a></li>';
	
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_auction_getlang('s669').'</a></li>';
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_auction_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_auction_bottomnav = DB::fetch($query)) {
	$it618_url=$it618_auction_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$tmpurl=it618_auction_getrewrite('auction_wap','','plugin.php?id=it618_auction:wap');
	$it618_url=str_replace("{waphome}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='scoremall'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapprice}",$it618_url);
	$tmpurl=it618_auction_getrewrite('auction_wap','price@'.$_G['uid'].'@0','plugin.php?id=it618_auction:wap&pagetype=price');
	$it618_url=str_replace("{wapprice}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='price'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapsale}",$it618_url);
	$tmpurl=it618_auction_getrewrite('auction_wap','sale@'.$_G['uid'].'@0','plugin.php?id=it618_auction:wap&pagetype=sale');
	$it618_url=str_replace("{wapsale}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='sale'){
			$iscur=1;
		}
	}
	
	if($it618_auction_bottomnav['id']==5)$it618_url=it618_auction_getrewrite('auction_wap','u@'.$_G['uid'].'@0','plugin.php?id=it618_auction:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_auction_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_auction_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_auction_bottomnav['it618_color'].'">'.$it618_auction_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_auction_bottomnav['it618_img'];
		$it618_title=$it618_auction_bottomnav['it618_title'];
	}
	
	if($it618_auction_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_auction_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);


$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')==false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_auction['auction_appid']);
	$wx_secret=trim($it618_auction['auction_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){

	if($pagetype=='product'){
		$pid=intval($_GET['cid']);
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$pid);
		$wxshare_title=$it618_auction_goods['it618_name'];
		$wxshare_imgUrl=$it618_auction_goods['it618_picsmall'];
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		if($it618_auction_goods['it618_type']==1){
			$aboutstr=$it618_auction_lang['s675'];
		}else{
			$aboutstr=$it618_auction_lang['s676'];
		}
		$wxshare_desc=$aboutstr;
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
		
	}else{
		$wxshare_title=$it618_auction['seotitle'];
		if($it618_auction['auction_wxlogo']!=''){
			$wxshare_imgUrl=$it618_auction['auction_wxlogo'];
		}else{
			$wxshare_imgUrl=$it618_auction['auction_auctionlogo'];
			$tmparr=explode('src="',$wxshare_imgUrl);
			$tmparr1=explode('"',$tmparr[1]);
			$wxshare_imgUrl=$tmparr1[0];
		}
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_auction['seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_auction_getrewrite('auction_wap','','plugin.php?id=it618_auction:wap');
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_auction/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
	}
}

$wapbottomsubnav=C::t('#it618_auction#it618_auction_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_auction#it618_auction_set')->getsetvalue_by_setname('wapbottomsubnavdefault');

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_wapad=it618_group_getad($_GET['id'],1);
}

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/wap/'.$pagetype.'.inc.php';
?>