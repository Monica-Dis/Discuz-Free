<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/sc_header.func.php';

if($it618_auction['auction_isrzcheck']==1){
	$isrzcheck=3;
}else{
	$isrzcheck=1;
}

if(submitcheck('it618submitpost1')||submitcheck('it618submitpost2')){
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_identity')." where it618_uid=".$_G['uid']);
	if($count>0){
		$it618_auction_identity = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_identity')." where it618_uid=".$_G['uid']);
		if(submitcheck('it618submitpost1')){
			C::t('#it618_auction#it618_auction_identity')->update($it618_auction_identity['id'],array(
				'it618_name' => dhtmlspecialchars($_GET["it618_name"]),
				'it618_qq' => dhtmlspecialchars($_GET["it618_qq"]),
				'it618_sfzid' => dhtmlspecialchars($_GET["it618_sfzid"]),
				'it618_sfzpic' => dhtmlspecialchars($_GET["it618_sfzpic"]),
				'it618_time1' => $_G['timestamp'],
				'it618_isok1' => $isrzcheck
			));
			if($isrzcheck==3){
				C::t('#it618_auction#it618_auction_identity')->update($it618_auction_identity['id'],array(
					'it618_bl' => $it618_auction['auction_tcbl1'],
					'it618_bl_yj' => $it618_auction['auction_tcbl2'],
					'it618_mode' => $it618_auction['auction_mode'],
					'it618_ischeck' => $it618_auction['auction_isaccheck']
				));
			}else{
				it618_auction_sendmessage("rz_admin",$_G['uid']);
			}
			
			it618_cpmsg(it618_auction_getlang('s392'), "plugin.php?id=it618_auction:sc_identity", 'succeed');
		}else{
			C::t('#it618_auction#it618_auction_identity')->update($it618_auction_identity['id'],array(
				'it618_gsname' => dhtmlspecialchars($_GET["it618_gsname"]),
				'it618_gsqq' => dhtmlspecialchars($_GET["it618_gsqq"]),
				'it618_yyzzid' => dhtmlspecialchars($_GET["it618_yyzzid"]),
				'it618_frsfzpic' => dhtmlspecialchars($_GET["it618_frsfzpic"]),
				'it618_yyzzpic' => dhtmlspecialchars($_GET["it618_yyzzpic"]),
				'it618_time2' => $_G['timestamp'],
				'it618_isok2' => $isrzcheck
			));
			if($isrzcheck==3){
				C::t('#it618_auction#it618_auction_identity')->update($it618_auction_identity['id'],array(
					'it618_bl' => $it618_auction['auction_tcbl1'],
					'it618_bl_yj' => $it618_auction['auction_tcbl2'],
					'it618_mode' => $it618_auction['auction_mode'],
					'it618_ischeck' => $it618_auction['auction_isaccheck']
				));
			}else{
				it618_auction_sendmessage("rz_admin",$_G['uid']);	
			}
			
			it618_cpmsg(it618_auction_getlang('s393'), "plugin.php?id=it618_auction:sc_identity", 'succeed');
		}
	}else{
		 if(submitcheck('it618submitpost1')){
			$id=C::t('#it618_auction#it618_auction_identity')->insert(array(
				'it618_uid' => $_G['uid'],
				'it618_name' => dhtmlspecialchars($_GET["it618_name"]),
				'it618_qq' => dhtmlspecialchars($_GET["it618_qq"]),
				'it618_sfzid' => dhtmlspecialchars($_GET["it618_sfzid"]),
				'it618_sfzpic' => dhtmlspecialchars($_GET["it618_sfzpic"]),
				'it618_time1' => $_G['timestamp'],
				'it618_isok1' => $isrzcheck
			), true);
			if($isrzcheck==3){
				C::t('#it618_auction#it618_auction_identity')->update($id,array(
					'it618_bl' => $it618_auction['auction_tcbl1'],
					'it618_bl_yj' => $it618_auction['auction_tcbl2'],
					'it618_mode' => $it618_auction['auction_mode'],
					'it618_ischeck' => $it618_auction['auction_isaccheck']
				));
				it618_auction_sendmessage("rz1_admin",$_G['uid']);
			}else{
				it618_auction_sendmessage("rz_admin",$_G['uid']);
			}
			
			it618_cpmsg(it618_auction_getlang('s392'), "plugin.php?id=it618_auction:sc_identity", 'succeed');
		}else{
			$id=C::t('#it618_auction#it618_auction_identity')->insert(array(
				'it618_uid' => $_G['uid'],
				'it618_gsname' => dhtmlspecialchars($_GET["it618_gsname"]),
				'it618_gsqq' => dhtmlspecialchars($_GET["it618_gsqq"]),
				'it618_yyzzid' => dhtmlspecialchars($_GET["it618_yyzzid"]),
				'it618_frsfzpic' => dhtmlspecialchars($_GET["it618_frsfzpic"]),
				'it618_yyzzpic' => dhtmlspecialchars($_GET["it618_yyzzpic"]),
				'it618_time2' => $_G['timestamp'],
				'it618_isok2' => $isrzcheck
			), true);
			if($isrzcheck==3){
				C::t('#it618_auction#it618_auction_identity')->update($id,array(
					'it618_bl' => $it618_auction['auction_tcbl1'],
					'it618_bl_yj' => $it618_auction['auction_tcbl2'],
					'it618_mode' => $it618_auction['auction_mode'],
					'it618_ischeck' => $it618_auction['auction_isaccheck']
				));
				it618_auction_sendmessage("rz1_admin",$_G['uid']);
			}else{
				it618_auction_sendmessage("rz_admin",$_G['uid']);
			}
			it618_cpmsg(it618_auction_getlang('s393'), "plugin.php?id=it618_auction:sc_identity", 'succeed');
		}
	}
}

it618_showformheader('plugin.php?id=it618_auction:sc_identity');
showtableheaders(it618_auction_getlang('s363'),'it618_auction_identity');

$it618submitpost1='<tr><td colspan="2"><input type="submit" class="btn" name="it618submitpost1" value="'.it618_auction_getlang('s364').'" onclick="return checkvalue1()" /></td></tr>';
$it618_auction_identity = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_identity')." WHERE it618_uid=".$_G['uid']);
if($it618_auction_identity['it618_isok1']==3){
	$it618_isok1='<img src="source/plugin/it618_auction/images/se.gif" style="vertical-align:middle"> <font color=green><strong>'.it618_auction_getlang('s366').'</strong></font>';
	$confirm1='if(confirm(\''.it618_auction_getlang('s365').'\'))return true;else return false;';
}elseif($it618_auction_identity['it618_isok1']==2){
	$it618_isok1='<font color=blue><strong>'.it618_auction_getlang('s367').'</strong></font>';
}elseif($it618_auction_identity['it618_isok1']==1){
	$it618_isok1='<font color=red><strong>'.it618_auction_getlang('s368').'</strong></font>';
	$it618submitpost1='';
}else{
	$it618_isok1='<font color=blue><strong>'.it618_auction_getlang('s369').'</strong></font>';
}

$it618submitpost2='<tr><td colspan="2"><input type="submit" class="btn" name="it618submitpost2" value="'.it618_auction_getlang('s364').'" onclick="return checkvalue2()" /></td></tr>';
if($it618_auction_identity['it618_isok2']==3){
	$it618_isok2='<img src="source/plugin/it618_auction/images/se.gif" style="vertical-align:middle"> <font color=green><strong>'.it618_auction_getlang('s366').'</strong></font>';
	$confirm2='if(confirm(\''.it618_auction_getlang('s365').'\'))return true;else return false;';
}elseif($it618_auction_identity['it618_isok2']==2){
	$it618_isok2='<font color=blue><strong>'.it618_auction_getlang('s367').'</strong></font>';
}elseif($it618_auction_identity['it618_isok2']==1){
	$it618_isok2='<font color=red><strong>'.it618_auction_getlang('s368').'</strong></font>';
	$it618submitpost2='';
}else{
	$it618_isok2='<font color=blue><strong>'.it618_auction_getlang('s369').'</strong></font>';
}


echo '
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/lang/zh_CN.js"></script>
<script>
	var shopuid=0;
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_auction/kindeditor/php/upload_json.php?uid='.$_G['uid'].'\',
					fileManagerJson : \'source/plugin/it618_auction/kindeditor/php/file_manager_json.php?uid='.$_G['uid'].'\',
					allowFileManager : true
				});
				K(\'#image1\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url1\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url1\').val(url);
								K(\'#img1\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});
				K(\'#image2\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url2\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url2\').val(url);
								K(\'#img2\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});
				K(\'#image3\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url3\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url3\').val(url);
								K(\'#img3\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});
			});
	
	function checkvalue1(){
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_auction_getlang('s370').'");
			return false;
		}
		if(document.getElementById("it618_qq").value==""){
			alert("'.it618_auction_getlang('s371').'");
			return false;
		}
		if(document.getElementById("it618_sfzid").value==""){
			alert("'.it618_auction_getlang('s372').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_auction_getlang('s373').'");
			return false;
		}
		
		'.$confirm1.'
	}
	
	function checkvalue2(){
		if(document.getElementById("it618_gsname").value==""){
			alert("'.it618_auction_getlang('s374').'");
			return false;
		}
		if(document.getElementById("it618_gsqq").value==""){
			alert("'.it618_auction_getlang('s375').'");
			return false;
		}
		if(document.getElementById("it618_yyzzid").value==""){
			alert("'.it618_auction_getlang('s376').'");
			return false;
		}
		if(document.getElementById("url2").value==""){
			alert("'.it618_auction_getlang('s377').'");
			return false;
		}
		if(document.getElementById("url3").value==""){
			alert("'.it618_auction_getlang('s378').'");
			return false;
		}
		
		'.$confirm2.'
	}
	
</script>';

if($isrzcheck==3){
	$tmpstr='<tr><td colspan=2><font color=red>'.$it618_auction_lang['s816'].'</font></td></tr>';
}else{
	$tmpstr='<tr><td colspan=2><font color=red>'.$it618_auction_lang['s817'].'</font></td></tr>';
}

echo '
<tr><td colspan=2>'.it618_auction_getlang('s379').'</td></tr>
'.$tmpstr.'
<tr><td colspan=2><strong>'.it618_auction_getlang('s380').'</strong> '.$it618_isok1.'</td></tr>
<tr><td width="120">'.it618_auction_getlang('s381').'</td><td><input type="text" class="txt" style="width:300px" id="it618_name" name="it618_name" value="'.$it618_auction_identity['it618_name'].'"></td></tr>
<tr><td>'.it618_auction_getlang('s382').'</td><td><input type="text" class="txt" style="width:300px" id="it618_qq" name="it618_qq" value="'.$it618_auction_identity['it618_qq'].'"></td></tr>
<tr><td>'.it618_auction_getlang('s383').'</td><td><input type="text" class="txt" style="width:300px" id="it618_sfzid" name="it618_sfzid" value="'.$it618_auction_identity['it618_sfzid'].'"></td></tr>
<tr><td>'.it618_auction_getlang('s384').'</td><td><img id="img1" src="'.$it618_auction_identity['it618_sfzpic'].'" width="126" height="90" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url1" name="it618_sfzpic" readonly="readonly" value="'.$it618_auction_identity['it618_sfzpic'].'" /> <input type="button" id="image1" value="'.it618_auction_getlang('s385').'" /></td></tr>
'.$it618submitpost1.'
<tr><td colspan=2><strong>'.it618_auction_getlang('s386').'</strong> '.$it618_isok2.'</td></tr>
<tr><td>'.it618_auction_getlang('s387').'</td><td><input type="text" class="txt" style="width:300px" id="it618_gsname" name="it618_gsname" value="'.$it618_auction_identity['it618_gsname'].'"></td></tr>
<tr><td>'.it618_auction_getlang('s388').'</td><td><input type="text" class="txt" style="width:300px" id="it618_gsqq" name="it618_gsqq" value="'.$it618_auction_identity['it618_gsqq'].'"></td></tr>
<tr><td>'.it618_auction_getlang('s389').'</td><td><input type="text" class="txt" style="width:300px" id="it618_yyzzid" name="it618_yyzzid" value="'.$it618_auction_identity['it618_yyzzid'].'"></td></tr>
<tr><td>'.it618_auction_getlang('s390').'</td><td><img id="img2" src="'.$it618_auction_identity['it618_frsfzpic'].'" width="126" height="90" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url2" name="it618_frsfzpic" readonly="readonly" value="'.$it618_auction_identity['it618_frsfzpic'].'" /> <input type="button" id="image2" value="'.it618_auction_getlang('s385').'" /></td></tr>
<tr><td>'.it618_auction_getlang('s391').'</td><td><img id="img3" src="'.$it618_auction_identity['it618_yyzzpic'].'" width="126" height="90" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url3" name="it618_yyzzpic" readonly="readonly" value="'.$it618_auction_identity['it618_yyzzpic'].'" /> <input type="button" id="image3" value="'.it618_auction_getlang('s385').'" /></td></tr>
'.$it618submitpost2.'
';

showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/sc_footer.func.php';
?>