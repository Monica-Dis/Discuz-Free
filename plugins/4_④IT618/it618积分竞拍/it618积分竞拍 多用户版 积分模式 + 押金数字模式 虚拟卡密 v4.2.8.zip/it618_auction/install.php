<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_auction_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_tip` varchar(1000) NOT NULL,
  `it618_is` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_user`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_msgisok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_pl`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_pl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_quoteid` int(10) unsigned NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_kd`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_kd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_identity`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_identity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_qq` varchar(100) NOT NULL,
  `it618_sfzid` varchar(50) NOT NULL,
  `it618_sfzpic` varchar(100) NOT NULL,
  `it618_gsname` varchar(100) NOT NULL,
  `it618_gsqq` varchar(100) NOT NULL,
  `it618_yyzzid` varchar(50) NOT NULL,
  `it618_frsfzpic` varchar(100) NOT NULL,
  `it618_yyzzpic` varchar(100) NOT NULL,
  `it618_ischeck` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mode` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_bl` float(9,2) NOT NULL,
  `it618_bl_yj` float(9,2) NOT NULL,
  `it618_isok1` int(10) unsigned NOT NULL,
  `it618_isok2` int(10) unsigned NOT NULL,
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_tcbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_tcbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_num1` int(10) unsigned NOT NULL,
  `it618_num2` int(10) unsigned NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_article_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_article_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_article`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(1000) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_ishide` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_paytype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(1000) NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_yajin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addprice` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_maxaddprice` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lpprice` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xiangoucount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_picbig` varchar(800) NOT NULL,
  `it618_picsmall` varchar(800) NOT NULL,
  `it618_shouxufei` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chujiafei` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_freecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_flbl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_about` varchar(3000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_message_images` mediumtext NOT NULL,
  `it618_grouppower` varchar(800) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_orderbystate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_orderbytime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isbm` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_checkstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_timetype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_bdate` varchar(20) NOT NULL,
  `it618_edate` varchar(20) NOT NULL,
  `it618_bhour` varchar(20) NOT NULL,
  `it618_ehour` varchar(20) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_goods_km`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_goods_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_postuid` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_kddan` varchar(100) NOT NULL,
  `it618_km` mediumtext NOT NULL,
  `it618_bscore` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  `it618_blscore` int(10) unsigned NOT NULL,
  `it618_addr` varchar(2000) NOT NULL,
  `it618_bz` varchar(8000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_sale_price`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_sale_price` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_yajin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shouxufei` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chujiafei` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_flbl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_fl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addr` varchar(2000) NOT NULL,
  `it618_bz` varchar(8000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_message`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(100) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_sale_pricetmp`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_sale_pricetmp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_auction_salework` (
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

INSERT INTO `pre_it618_auction_wapstyle` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#fd9e2d', '#e8922b', 0),
(2, '#fc4646', '#f43131', 1),
(3, '#5ebe00', '#56aa04', 0),
(4, '#23b8ff', '#12a8ff', 0),
(5, '#fb23cb', '#ea11ba', 0),
(6, '#2dbeae', '#00a795', 0),
(8, '#fe5400', '#d04906', 0),
(7, '#999a9b', '#8d8f90', 0);

EOF;

runquery($sql);

$sql = str_replace("\r\n", "\n", lang('plugin/it618_auction', 'it618_sql'));

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE; /*http://t.cn/Aiux1012*/
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('c291cmNlL3BsdWdpbi9pdDYxOF9hdWN0aW9uL3VwZ3JhZGUucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('c291cmNlL3BsdWdpbi9pdDYxOF9hdWN0aW9uL2luc3RhbGwucGhw'));
?>