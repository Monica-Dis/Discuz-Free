<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_auction = $_G['cache']['plugin']['it618_auction'];
$navtitle = $it618_auction['seotitle'];
$metakeywords = $it618_auction['seokeywords'];
$metadescription = $it618_auction['seodescription'];
$creditname1=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
$creditname2=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_function.func.php';

if($_G['uid']>0){
	$u_username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$_G['uid']);
	$u_avatarimg=it618_auction_discuz_uc_avatar($_G['uid'],'middle');
	$creditnum1=DB::result_first("select extcredits".$it618_auction['auction_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	$creditnum2=DB::result_first("select extcredits".$it618_auction['auction_credit_yj']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
}

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale_price')." order by id desc LIMIT 0, ".$it618_auction['auction_pricecount']);
while($it618_auction_sale_price = DB::fetch($query)) {

	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')return;

	$username=it618_auction_getusername($it618_auction_sale_price['it618_uid']);
	$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale_price['it618_pid']);
	if($it618_auction_goods['it618_isbm']==1){
		$username='***';
	}
	
	if($it618_auction_sale_price['it618_type']==1){
		$creditnametmp=$creditname1;
		$creditname=$creditname1;
	}else{
		$creditnametmp=$it618_auction_lang['s432'];
		$creditname=$creditname2;
	}
	
	$it618_bz='';
	$it618_yajin=$it618_auction_sale_price['it618_yajin'];
	$it618_shouxufei=$it618_auction_sale_price['it618_shouxufei'];
	$it618_chujiafei=$it618_auction_sale_price['it618_chujiafei'];
	
	if($it618_yajin>0)$it618_bz.=$it618_auction_lang['s764'].'<font color=red>'.$it618_yajin.'</font>'.$creditnametmp.' ';
	if($it618_shouxufei>0)$it618_bz.=$it618_auction_lang['s307'].'<font color=red>'.$it618_shouxufei.'</font>'.$creditname.' ';
	if($it618_chujiafei>0)$it618_bz.=$it618_auction_lang['s308'].'<font color=red>'.$it618_chujiafei.'</font>'.$creditname.' ';
	$it618_bz.='@';
	$it618_bz=str_replace(" @","",$it618_bz);
	$it618_bz=str_replace("@","",$it618_bz);
	if($it618_bz!='')$it618_bz='(<font color=#999>'.$it618_bz.'</font>)';
	
	$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_sale_price['it618_pid'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_sale_price['it618_pid']);
	$userpricelist.='<li><font color=red>'.it618_auction_gettime($it618_auction_sale_price['it618_time']).'</font> <font color="#333333">'.$username.'</font> '.it618_auction_getlang('s186').' <font color="#FF0000">'.$it618_auction_sale_price['it618_score'].'</font> '.$creditnametmp.' '.it618_auction_getlang('s187').' [<a href="'.$tmpurl.'" target="_blank">'.$it618_auction_goods['it618_name'].'</a>]'.$it618_bz.'</li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale')." where it618_state<>0 and it618_state<>3 order by id desc LIMIT 0, ".$it618_auction['auction_dealcount']);
while($it618_auction_sale = DB::fetch($query)) {

	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')return;

	$username=it618_auction_getusername($it618_auction_sale['it618_uid']);
	$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
	if($it618_auction_goods['it618_isbm']==1){
		$username='***';
	}
	
	$tmpscore=$it618_auction_sale['it618_score']/$it618_auction_goods['it618_score'];
	if($tmpscore>=intval($tmpscore)){
		$tmpscore=intval($tmpscore);
	}else{
		$tmpscore=intval($tmpscore)-1;
	}
	
	if($it618_auction_sale['it618_type']==1){
		$creditnametmp=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
	}else{
		$creditnametmp=$it618_auction_lang['s432'];
	}
	
	if($tmpscore>1)$tmpscore=it618_auction_getlang('s188').' <font color="red">'.$tmpscore.'</font> '.it618_auction_getlang('s189');else $tmpscore='';
	
	$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_sale['it618_pid'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_sale['it618_pid']);
	$userdeallist.='<li><font color=red>'.it618_auction_gettime($it618_auction_sale['it618_time']).'</font> <font color="#333333">'.$username.'</font> '.$tmpscore.it618_auction_getlang('s190').' <font color="red">'.$it618_auction_sale['it618_score'].'</font> '.$creditnametmp.' '.it618_auction_getlang('s191').' [<a href="'.$tmpurl.'" target="_blank">'.$it618_auction_goods['it618_name'].'</a>]</li>';
}

if($IsCredits==1){
	$tmpuser='<span class="it618set"><a href="javascript:" class="it618_credits"><font color=blue>'.$it618_auction_lang['s746'].'</font></a><font color=#999 style=" padding-left:1px; padding-right:1px">|</font><a href="javascript:" onclick="showset()"><font color=blue>'.$it618_auction_lang['s546'].'</font></a></span>';
}else{
	$tmpuser='<span class="it618set"><a href="javascript:" onclick="showset()"><font color=blue>'.$it618_auction_lang['s546'].'</font></a></span>';
}

if($it618_auction['auction_widthcss']!=''){
	$auction_widthcss='<style>'.$it618_auction['auction_widthcss'].'</style>';
}

$auction_home=it618_auction_getrewrite('auction_home','','plugin.php?id=it618_auction:auction');
if($_G['cache']['plugin']['it618_auction']['rewriteurl']==0){
	$auction_user='plugin.php?id=it618_auction:auction&myauction';
}else{
	$auction_user=it618_auction_getrewrite('auction_home','','plugin.php?id=it618_auction:auction').'?myauction';
}
$auction_sc=it618_auction_getrewrite('auction_sc','','plugin.php?id=it618_auction:sc');

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_ad=it618_group_getad($_GET['id'],2);
}
//From: dis'.'m.tao'.'bao.com
?>