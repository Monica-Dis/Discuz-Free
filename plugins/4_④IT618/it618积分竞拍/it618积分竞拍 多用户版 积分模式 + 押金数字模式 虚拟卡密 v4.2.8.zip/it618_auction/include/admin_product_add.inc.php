<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism-taobao_com*/
if(submitcheck('it618submit')){
	$gp_array = !empty($_GET['gp']) ? $_GET['gp'] : array();
	foreach($gp_array as $key => $value) {
		$gp.=$value.',';
	}
	if($gp!='')$gp=str_replace(",,","",$gp.',');
	
	if($it618_auction['auction_hideclass']==0){
		$it618_class_id=$_GET['it618_class_id'];
	}else{
		$it618_class_id=DB::result_first("SELECT id FROM ".DB::table('it618_auction_class'));
	}
	
	C::t('#it618_auction#it618_auction_goods')->insert(array(
		'it618_class_id' => $it618_class_id,
		'it618_name' => $_GET['it618_name'],
		'it618_type' => $_GET['it618_type'],
		'it618_paytype' => $_GET['it618_paytype'],
		'it618_yajin' => intval($_GET['it618_yajin']),
		'it618_score' => intval($_GET['it618_score']),
		'it618_addprice' => intval($_GET['it618_addprice']),
		'it618_maxaddprice' => intval($_GET['it618_maxaddprice']),
		'it618_lpprice' => intval($_GET['it618_lpprice']),
		'it618_bdate' => $_GET['it618_bdate'],
		'it618_edate' => $_GET['it618_edate'],
		'it618_bhour' => $_GET['it618_bhour'],
		'it618_ehour' => $_GET['it618_ehour'],
		'it618_timetype' => $_GET['it618_timetype'],
		'it618_count' => intval($_GET['it618_count']),
		'it618_xiangoucount' => intval($_GET['it618_xiangoucount']),
		'it618_picbig' => $_GET['it618_picbig'],
		'it618_picsmall' => $_GET['it618_picsmall'],
		'it618_shouxufei' => intval($_GET['it618_shouxufei']),
		'it618_chujiafei' => intval($_GET['it618_chujiafei']),
		'it618_freecount' => intval($_GET['it618_freecount']),
		'it618_about' => $_GET['it618_about'],
		'it618_message_images' => $_GET['it618_message_images'],
		'it618_message' => $_GET['it618_message'],
		'it618_grouppower' => $gp,
		'it618_checkstate' => 3,
		'it618_time' => $_G['timestamp']
	), true);

	cpmsg($it618_auction_lang['s103'], "action=plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do");
showtableheaders($it618_auction_lang['s104'],'it618_auction_goods');

if($it618_auction['auction_hideclass']==0){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_class')." ORDER BY it618_order DESC");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$classstr='<tr><td>'.it618_auction_getlang('s105').'</td><td><select id="it618_class_id" name="it618_class_id"><option value="0">'.it618_auction_getlang('s106').'</option>'.$tmp.'</select></td></tr>';
}

$it618_auction_lang['s763']=str_replace("{creditname1}",$creditname1,$it618_auction_lang['s763']);
$it618_auction_lang['s763']=str_replace("{creditname2}",$creditname2,$it618_auction_lang['s763']);

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('common_usergroup'));
while($common_usergroup = DB::fetch($query)) {
	$gpstr.='<input class="checkbox" type="checkbox" id="chk_gp'.$n.'" name="gp[]" value="'.$common_usergroup['groupid'].'"><label for="chk_gp'.$n.'">'.$common_usergroup['grouptitle'].'</label> ';
	$n=$n+1;
}

$btmptime=date('Y-m-d H:i:s', $_G['timestamp']+24*60*60);
$btimearr=explode(" ",$btmptime);
$btimearr1=explode("-",$btimearr[0]);
$btimearr2=explode(":",$btimearr[1]);
$etmptime=date('Y-m-d H:i:s', $_G['timestamp']+24*60*60*30);
$etimearr=explode(" ",$etmptime);
$etimearr1=explode("-",$etimearr[0]);
$etimearr2=explode(":",$etimearr[1]);
//
$bstrtmp="";$estrtmp="";
for($i=2020;$i<=2030;$i++){
	if($btimearr1[0]==$i){
		$bstrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$bstrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
	if($etimearr1[0]==$i){
		$estrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$estrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$bsel_year='<select id="bsel_year" onclick="returnvalue(1)">'.$bstrtmp.'</select>';
$esel_year='<select id="esel_year" onclick="returnvalue()">'.$estrtmp.'</select>';

//
$bstrtmp="";$estrtmp="";
for($i=1;$i<=12;$i++){
	if($btimearr1[1]==$i){
		$bstrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$bstrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
	if($etimearr1[1]==$i){
		$estrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$estrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$bsel_month='<select id="bsel_month" onclick="returnvalue(1)">'.$bstrtmp.'</select>';
$esel_month='<select id="esel_month" onclick="returnvalue()">'.$estrtmp.'</select>';

//
$bstrtmp="";$estrtmp="";
for($i=1;$i<=31;$i++){
	if($btimearr1[2]==$i){
		$bstrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$bstrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
	if($etimearr1[2]==$i){
		$estrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$estrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$bsel_date='<select id="bsel_date" onclick="returnvalue()">'.$bstrtmp.'</select>';
$esel_date='<select id="esel_date" onclick="returnvalue()">'.$estrtmp.'</select>';

//
$bstrtmp="";$estrtmp="";
$btimearr2[0]=10;$etimearr2[0]=20;
for($i=0;$i<=23;$i++){
	if($btimearr2[0]==$i){
		$bstrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$bstrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
	if($etimearr2[0]==$i){
		$estrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$estrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$bsel_hour='<select id="bsel_hour" onclick="returnvalue()">'.$bstrtmp.'</select>';
$esel_hour='<select id="esel_hour" onclick="returnvalue()">'.$estrtmp.'</select>';

//
$bstrtmp="";$estrtmp="";
$btimearr2[1]=0;$etimearr2[1]=0;
for($i=0;$i<=59;$i++){
	if($btimearr2[1]==$i){
		$bstrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$bstrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
	if($etimearr2[1]==$i){
		$estrtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$estrtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$bsel_minute='<select id="bsel_minute" onclick="returnvalue()">'.$bstrtmp.'</select>';
$esel_minute='<select id="esel_minute" onclick="returnvalue()">'.$estrtmp.'</select>';

function towstr($i){
	if(strlen($i)==1)return "0".$i;else return $i;
}

if($IsCredits==1){
	$tmpjs='document.getElementById("trpaytype").style.display="";';
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/plugins/code/prettify.js"></script>
<script>
	var shopuid=0-1;
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_auction/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_auction/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_auction/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				K(\'#image1\').click(function() {
					editor1.loadPlugin(\'image\', function() {
						editor1.plugin.imageDialog({
							imageUrl : K(\'#url1\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url1\').val(url);
								K(\'#img1\').attr(\'src\',url);
								editor1.hideDialog();
							}
						});
					});
				});
				K(\'#image2\').click(function() {
					editor1.loadPlugin(\'image\', function() {
						editor1.plugin.imageDialog({
							imageUrl : K(\'#url2\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url2\').val(url);
								K(\'#img2\').attr(\'src\',url);
								editor1.hideDialog();
							}
						});
					});
				});
			}
		});
				
		var editor2 = K.create(\'textarea[name="it618_message_images"]\', {
			cssPath : \'source/plugin/it618_auction/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_auction/kindeditor/php/upload_json.php?goodsimages\',
			fileManagerJson : \'source/plugin/it618_auction/kindeditor/php/file_manager_json.php?goodsimages\',
			allowFileManager : true,
			filterMode:false,
			afterBlur: function () { this.sync(); },
			items : [\'multiimage\']
		});
	});

	function checkvalue(){
		returnvalue();
		if(document.getElementById("it618_class_id").value=="0"){
			alert("'.$it618_auction_lang['s91'].'");
			return false;
		}
		if(document.getElementById("it618_name").value==""){
			alert("'.$it618_auction_lang['s92'].'");
			return false;
		}
		if(parseInt(document.getElementById("it618_edate").value.replace(/-/g,""))<parseInt(document.getElementById("it618_bdate").value.replace(/-/g,""))){
			alert("'.$it618_auction_lang['s93'].'");
			return false;
		}
		var flag=0;
		if(document.getElementById("it618_timetype").checked){
			flag=1;
		}else{
			if(parseInt(document.getElementById("it618_edate").value.replace(/-/g,""))==parseInt(document.getElementById("it618_bdate").value.replace(/-/g,""))){
				flag=1;
			}
		}
		if(flag==1&&parseInt(document.getElementById("it618_ehour").value.replace(":",""))<=parseInt(document.getElementById("it618_bhour").value.replace(":",""))){
			alert("'.$it618_auction_lang['s94'].'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.$it618_auction_lang['s95'].'");
			return false;
		}
		if(document.getElementById("url2").value==""){
			alert("'.$it618_auction_lang['s96'].'");
			return false;
		}
	}

	function returnvalue(){
		document.getElementById("it618_bdate").value=document.getElementById("bsel_year").value+"-"+document.getElementById("bsel_month").value+"-"+document.getElementById("bsel_date").value;
		document.getElementById("it618_edate").value=document.getElementById("esel_year").value+"-"+document.getElementById("esel_month").value+"-"+document.getElementById("esel_date").value;
		document.getElementById("it618_bhour").value=document.getElementById("bsel_hour").value+":"+document.getElementById("bsel_minute").value;
		document.getElementById("it618_ehour").value=document.getElementById("esel_hour").value+":"+document.getElementById("esel_minute").value;
	}
	
	function gettype(objvalue){
		if(objvalue==1){
			document.getElementById("tryajin").style.display="none";
			document.getElementById("trpaytype").style.display="none";
		}else{
			document.getElementById("tryajin").style.display="";
			'.$tmpjs.'
		}
	}
	
	function check_all(obj,id)
	{
		for(var i=1;i<'.$n.';i++)
		{
			document.getElementById(id+""+i).checked = obj.checked;
		}
	}
</script>

'.$classstr.'
<tr><td width=68>'.$it618_auction_lang['s107'].'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name" onclick="returnvalue()"></td></tr>
<tr><td>'.$it618_auction_lang['s760'].'</td><td style="line-height:26px"><select id="it618_type" name="it618_type" onchange="gettype(this.value)"><option value="1">'.$it618_auction_lang['s761'].'</option><option value="2">'.$it618_auction_lang['s762'].'</option></select> '.$it618_auction_lang['s763'].'</td></tr>
<tr id="trpaytype" style="display:none"><td>'.$it618_auction_lang['s829'].'</td><td><select name="it618_paytype"><option value="1">'.$it618_auction_lang['s830'].'</option><option value="2">'.$it618_auction_lang['s831'].'</option></select> <font color=#999>'.$it618_auction_lang['s832'].'</font></td></tr>
<tr id="tryajin" style="display:none"><td>'.$it618_auction_lang['s764'].'</td><td><input type="text" class="txt" style="width:80px" name="it618_yajin"> <font color=#999>'.$it618_auction_lang['s765'].'</font></td></tr>
<tr><td>'.$it618_auction_lang['s108'].'</td><td><input type="text" class="txt" style="width:80px" name="it618_score"> '.$it618_auction_lang['s345'].'<input type="text" class="txt" style="width:80px" name="it618_addprice" value="0"> <font color=#999>'.$it618_auction_lang['s346'].'</font></td></tr>
<tr><td>'.$it618_auction_lang['s309'].'</td><td><input type="text" class="txt" style="width:80px" name="it618_shouxufei" value="5"><font color=#999>'.$it618_auction_lang['s310'].'</font> '.$it618_auction_lang['s347'].'<input type="text" class="txt" style="width:80px" name="it618_maxaddprice" value="0"> <font color=#999>'.$it618_auction_lang['s348'].'</font></td></tr>
<tr><td>'.$it618_auction_lang['s311'].'</td><td><input type="text" class="txt" style="width:80px" name="it618_chujiafei" value="1">'.$it618_auction_lang['s312'].'<input type="text" class="txt" style="width:30px" name="it618_freecount" value="1">'.$it618_auction_lang['s313'].'</td></tr>
<tr><td>'.$it618_auction_lang['s358'].'</td><td><input type="text" class="txt" style="width:80px" name="it618_lpprice" value="0">'.$it618_auction_lang['s359'].'</td></tr>
<tr><td>'.$it618_auction_lang['s109'].'</td><td style="line-height:20px">'.$it618_auction_lang['s110'].$bsel_year.$it618_auction_lang['s111'].$bsel_month.$it618_auction_lang['s112'].$bsel_date.$it618_auction_lang['s113'].'<br>'.$it618_auction_lang['s114'].$esel_year.$it618_auction_lang['s111'].$esel_month.$it618_auction_lang['s112'].$esel_date.$it618_auction_lang['s113'].' '.$it618_auction_lang['s100'].$bsel_hour.$it618_auction_lang['s116'].$bsel_minute.$it618_auction_lang['s117'].' '.$esel_hour.$it618_auction_lang['s118'].$esel_minute.$it618_auction_lang['s119'].'<input type="hidden" id="it618_bdate" name="it618_bdate"><input type="hidden" id="it618_edate" name="it618_edate"><input type="hidden" id="it618_bhour" name="it618_bhour"><input type="hidden" id="it618_ehour" name="it618_ehour"><input type="checkbox" id="it618_timetype" name="it618_timetype" value="1" style="vertical-align:middle"/><label for="it618_timetype"><font color=red>'.$it618_auction_lang['s101'].'</font></label><br>'.$it618_auction_lang['s102'].'</td></tr>
<tr><td>'.$it618_auction_lang['s120'].'</td><td><input type="text" class="txt" style="width:80px" name="it618_count"> '.$it618_auction_lang['s121'].'<input type="text" class="txt" style="width:80px" name="it618_xiangoucount" value="0">'.$it618_auction_lang['s122'].'</td></tr>
<tr><td>'.$it618_auction_lang['s123'].'</td><td><img id="img1" width="80" height="58" align="absmiddle"/><input type="text" id="url1" name="it618_picbig" value="" readonly="readonly" /> <input type="button" id="image1" value="'.$it618_auction_lang['s124'].'" />  '.$it618_auction_lang['s125'].'</td></tr>
<tr><td>'.$it618_auction_lang['s126'].'</td><td><img id="img2" width="80" height="58" align="absmiddle"/><input type="text" id="url2" name="it618_picsmall" value="" readonly="readonly" /> <input type="button" id="image2" value="'.$it618_auction_lang['s124'].'" /> '.$it618_auction_lang['s128'].'</td></tr>
<tr><td>'.$it618_auction_lang['s129'].'</td><td><textarea name="it618_about" style="width:696px;height:45px;">'.$it618_auction['auction_about'].'</textarea><br>'.$it618_auction_lang['s130'].'</td></tr>
<tr><td>'.it618_auction_getlang('s806').'</td><td><textarea name="it618_message_images" style="width:700px;height:400px;visibility:hidden;"></textarea><br>'.$it618_auction_lang['s807'].'<br><br></td></tr>
<tr><td>'.$it618_auction_lang['s131'].'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;"></textarea></td></tr>
<tr><td>'.$it618_auction_lang['s132'].'</td><td><div style="width:700px">'.$gpstr.'<br><input class="checkbox" type="checkbox" id="chk_gpall" onclick="check_all(this, \'chk_gp\')"><label for="chk_gpall">'.$it618_auction_lang['s133'].'</label> <font color=red>'.$it618_auction_lang['s134'].'</font><div></td></tr>
<tr><td colspan="2"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.$it618_auction_lang['s11'].'" /></div></td></tr>';

if(count($reabc)!=10)return;
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/

?>