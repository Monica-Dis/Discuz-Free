<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism-taobao_com*/
if(submitcheck('it618submit')){
	
	if($_GET['it618_class_id']=='0'){
		cpmsg($it618_auction_lang['s19'], "action=plugins&identifier=$identifier&cp=admin_article_add&pmod=admin_article&operation=$operation&do=$do&page=$page", 'error');
	}
	
	if($_GET['it618_name']==''){
		cpmsg($it618_auction_lang['s21'], "action=plugins&identifier=$identifier&cp=admin_article_add&pmod=admin_article&operation=$operation&do=$do&page=$page", 'error');
	}

	C::t('#it618_auction#it618_auction_article')->insert(array(
		'it618_class_id' => $_GET['it618_class_id'],
		'it618_name' => $_GET['it618_name'],
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	), true);

	cpmsg($it618_auction_lang['s22'], "action=plugins&identifier=$identifier&cp=admin_article_add&pmod=admin_article&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_article_add&pmod=admin_article&operation=$operation&do=$do");
showtableheaders($it618_auction_lang['s1'],'it618_auction_article');

$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_article_class')." ORDER BY it618_order DESC");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/plugins/code/prettify.js"></script>
<script>
KindEditor.ready(function(K) {
	var editor1 = K.create(\'textarea[name="it618_message"]\', {
		cssPath : \'source/plugin/it618_auction/kindeditor/plugins/code/prettify.css\',
		uploadJson : \'source/plugin/it618_auction/kindeditor/php/upload_json.php\',
		fileManagerJson : \'source/plugin/it618_auction/kindeditor/php/file_manager_json.php\',
		allowFileManager : true,
		filterMode:false
	});
			
	prettyPrint();
});
	
function checkvalue(){
	if(document.getElementById("it618_class_id").value=="0"){
		alert("'.$it618_auction_lang['s19'].'");
		return false;
	}
	if(document.getElementById("it618_name").value==""){
		alert("'.$it618_auction_lang['s21'].'");
		return false;
	}
}
</script>
	
<tr><td width=60>'.$it618_auction_lang['s23'].'</td><td><select id="it618_class_id" name="it618_class_id"><option value="0">'.$it618_auction_lang['s13'].'</option>'.$tmp.'</select></td></tr>
<tr><td>'.$it618_auction_lang['s24'].'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name"></td></tr>
<tr><td>'.$it618_auction_lang['s25'].'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;"></textarea></td></tr>
<tr><td colspan="2"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.$it618_auction_lang['s11'].'" /></div></td></tr>';

if(count($reabc)!=13)return; /*Dism��taobao��com*/
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/

?>