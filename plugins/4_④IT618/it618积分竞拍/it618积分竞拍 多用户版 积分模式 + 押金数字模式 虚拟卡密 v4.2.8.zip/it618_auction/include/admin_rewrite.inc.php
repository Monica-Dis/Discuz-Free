<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism-taobao_com*/

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$auction_home=\''.'auction'."';\n";
		$fileData .= '$auction_product=\''.'auction_product'."';\n";
		$fileData .= '$auction_article=\''.'auction_article'."';\n";
		$fileData .= '$auction_sc=\''.'auction_sc'."';\n";
		$fileData .= '$auction_wap=\''.'auction_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$auction_home1=\''.$urltype."';\n";
		$fileData .= '$auction_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$auction_article1=\'-{aid}'.$urltype."';\n";
		$fileData .= '$auction_sc1=\''.$urltype."';\n";
		$fileData .= '$auction_wap1=\'-{pagetype}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$auction_home=\''.str_replace("-","",$_GET['auction_home'])."';\n";
		$fileData .= '$auction_product=\''.str_replace("-","",$_GET['auction_product'])."';\n";
		$fileData .= '$auction_article=\''.str_replace("-","",$_GET['auction_article'])."';\n";
		$fileData .= '$auction_sc=\''.str_replace("-","",$_GET['auction_sc'])."';\n";
		$fileData .= '$auction_wap=\''.str_replace("-","",$_GET['auction_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$auction_home1=\''.$urltype."';\n";
		$fileData .= '$auction_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$auction_article1=\'-{aid}'.$urltype."';\n";
		$fileData .= '$auction_sc1=\''.$urltype."';\n";
		$fileData .= '$auction_wap1=\'-{pagetype}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_auction_lang['s329'], "action=plugins&identifier=$identifier&cp=admin_rewrite&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_rewrite&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_auction_lang['s330'].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_auction_lang['s331'].'</td></tr>
<tr><td colspan="3">'.$it618_auction_lang['s332'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_auction_lang['s333'].'</th><th>'.$it618_auction_lang['s334'].'</th><th>'.$it618_auction_lang['s335'].'</th></tr>
<tr class="hover">
<td>'.$it618_auction_lang['s336'].'</td><td></td><td class="longtxt"><input name="auction_home" value="'.$auction_home.'"/>'.$auction_home.$auction_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_auction_lang['s337'].'</td><td>{pid}</td><td class="longtxt"><input name="auction_product" value="'.$auction_product.'" />'.$auction_product.$auction_product1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_auction_lang['s338'].'</td><td>{aid}</td><td class="longtxt"><input name="auction_article" value="'.$auction_article.'" />'.$auction_article.$auction_article1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_auction_lang['s490'].'</td><td></td><td class="longtxt"><input name="auction_sc" value="'.$auction_sc.'"/>'.$auction_sc.$auction_sc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_auction_lang['s491'].'</td><td>{pagetype}, {cid}, {page}</td><td class="longtxt"><input name="auction_wap" value="'.$auction_wap.'"/>'.$auction_wap.$auction_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_auction_lang['s339']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_auction_lang['s340'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$auction_home.$urltype.'$ $1/plugin.php?id=it618_auction:auction&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$auction_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_auction:auction_page&pid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$auction_article.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_auction:auction_article&aid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$auction_sc.$urltype.'$ $1/plugin.php?id=it618_auction:sc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$auction_wap.$urltype.'$ $1/plugin.php?id=it618_auction:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$auction_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_auction:wap&pagetype=$2&cid=$3&page=$4&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_auction_lang['s341'].'</h1>
<pre class="colorbox">
'.$it618_auction_lang['s342'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$auction_home.$urltype.'$ plugin.php?id=it618_auction:auction&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$auction_product.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_auction:auction_page&pid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$auction_article.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_auction:auction_article&aid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$auction_sc.$urltype.'$ plugin.php?id=it618_auction:sc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$auction_wap.$urltype.'$ plugin.php?id=it618_auction:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$auction_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_auction:wap&pagetype=$1&cid=$2&page=$3&%1
</pre>

<h1>'.$it618_auction_lang['s343'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$auction_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_auction:auction&$3
RewriteRule ^(.*)/'.$auction_product.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_auction:auction_page&pid=$2&$4
RewriteRule ^(.*)/'.$auction_article.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_auction:auction_article&aid=$2&$4
RewriteRule ^(.*)/'.$auction_sc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_auction:sc&$3
RewriteRule ^(.*)/'.$auction_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_auction:wap&$3
RewriteRule ^(.*)/'.$auction_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_auction:wap&pagetype=$2&cid=$3&page=$4&$6</font>

</pre>

<h1>'.$it618_auction_lang['s344'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="auction_home"&gt;
			&lt;match url="^(.*/)*'.$auction_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_auction:auction&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="auction_product"&gt;
			&lt;match url="^(.*/)*'.$auction_product.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_auction:auction_page&amp;amp;pid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="auction_article"&gt;
			&lt;match url="^(.*/)*'.$auction_article.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_auction:auction_article&amp;amp;aid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="auction_sc"&gt;
			&lt;match url="^(.*/)*'.$auction_sc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_auction:sc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wap"&gt;
			&lt;match url="^(.*/)*'.$auction_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_auction:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wap1"&gt;
			&lt;match url="^(.*/)*'.$auction_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_auction:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;page={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$auction_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_auction:auction&$2
endif
match URL into $ with ^(.*)/'.$auction_product.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_auction:auction_page&pid=$2&$3
endif
match URL into $ with ^(.*)/'.$auction_article.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_auction:auction_article&aid=$2&$3
endif
match URL into $ with ^(.*)/'.$auction_sc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_auction:sc&$2
endif
match URL into $ with ^(.*)/'.$auction_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_auction:wap&$2
endif
match URL into $ with ^(.*)/'.$auction_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_auction:wap&pagetype=$2&cid=$3&page=$4&$5
endif</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$auction_home.$urltype.'$ $1/plugin.php?id=it618_auction:auction&$2 last;
rewrite ^([^\.]*)/'.$auction_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_auction:auction_page&pid=$2&$3 last;
rewrite ^([^\.]*)/'.$auction_article.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_auction:auction_article&aid=$2&$3 last;
rewrite ^([^\.]*)/'.$auction_sc.$urltype.'$ $1/plugin.php?id=it618_auction:sc&$2 last;
rewrite ^([^\.]*)/'.$auction_wap.$urltype.'$ $1/plugin.php?id=it618_auction:wap&$2 last;
rewrite ^([^\.]*)/'.$auction_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_auction:wap&pagetype=$2&cid=$3&page=$4&$5 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=15)return;
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/

?>