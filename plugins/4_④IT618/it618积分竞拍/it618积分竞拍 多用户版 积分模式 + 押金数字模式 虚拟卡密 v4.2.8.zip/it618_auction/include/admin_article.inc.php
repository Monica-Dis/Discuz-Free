<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism-taobao_com*/

if($_GET['key']!=''){
	$extrasql .= " and it618_name like '%".addcslashes($_GET['key'],'%_')."%'";
}

if($_GET['it618_class_id']>0){$extrasql .= " and it618_class_id=".intval($_GET['it618_class_id']);}

$sql='&key='.$_GET['key'].'&it618_class_id='.$_GET['it618_class_id'];

if(submitcheck('it618submit')){
	$del=0;
	$ok=0;
	if($reabc[8]!='c')return; /*dism��taobao��com*/
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_auction_article', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_auction#it618_auction_article')->update($id,array(
				'it618_name' => $_GET['it618_name'][$id],
				'it618_color' => $_GET['it618_color'][$id],
				'it618_order' => intval($_GET['it618_order'][$id]),
			));
			$ok=$ok+1;
		}
	}

	cpmsg($it618_auction_lang['s5'].$ok.' '.$it618_auction_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_article&pmod=admin_article&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}
$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_article_class')." ORDER BY it618_order DESC");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class_id'].'>','<option value='.$_GET['it618_class_id'].' selected="selected">',$tmp);
if(count($reabc)!=13)return; /*Dism��taobao��com*/

showformheader("plugins&identifier=$identifier&cp=admin_article&pmod=admin_article&operation=$operation&do=$do");
showtableheaders($it618_auction_lang['s2'],'it618_auction_sum');
	showsubmit('it618sercsubmit', $it618_auction_lang['s9'], $it618_auction_lang['s10'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.$it618_auction_lang['s12'].' <select name="it618_class_id"><option value="0">'.$it618_auction_lang['s13'].'</option>'.$tmp1.'</select>');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_article')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_article&pmod=admin_article&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=5>'.$it618_auction_lang['s14'].$count.'</td></tr>';
	showsubtitle(array('',$it618_auction_lang['s15'],$it618_auction_lang['s16'],$it618_auction_lang['s17'],$it618_auction_lang['s18'],$it618_auction_lang['s8']));

	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_article')." WHERE 1 $extrasql order by it618_order desc LIMIT $startlimit, $ppp");
	$n=1;
	while($it618_auction_article = DB::fetch($query)) {
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_auction_article[id].'"><input type="hidden" name="id['.$it618_auction_article[id].']" value="'.$it618_auction_article[id].'"><label for="chk_del'.$n.'">'.$it618_auction_article['id'].'</label>',
			it618_auction_classname($it618_auction_article[it618_class_id]),
			'<input type="text" class="txt" style="width:400px" name="it618_name['.$it618_auction_article[id].']" value="'.$it618_auction_article[it618_name].'"><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_article_edit&pmod=admin_article&operation='.$operation.'&do='.$do.'&pid='.$it618_auction_article[id].'">'.$it618_auction_lang['s20'].'</a>',
			"<input id=\"c".$it618_auction_article['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_auction_article[id]]\" value=\"$it618_auction_article[it618_color]\" onchange=\"updatecolorpreview('c".$it618_auction_article['id']."')\"><input id=\"c".$it618_auction_article['id']."\" onclick=\"c".$it618_auction_article['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_auction_article['id']."|c".$it618_auction_article['id']."_v';showMenu({'ctrlid':'c".$it618_auction_article['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_auction_article['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_auction_article['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			$it618_auction_article[it618_views],
			'<input type="text" class="txt" style="width:30px" name="it618_order['.$it618_auction_article[id].']" value="'.$it618_auction_article[it618_order].'">'
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_auction_article['id']."');";
		$n=$n+1;
	}
	
	function it618_auction_classname($aid){
		return DB::result_first("select it618_classname from ".DB::table('it618_auction_article_class')." where id=".$aid);
	}
	
	showsubmit('it618submit', 'submit', 'del', '<script>'.$tmpcolorjs.'</script><input type=hidden value=$page name=page />', $multipage);
	if(count($reabc)!=13)return; /*Dism��taobao��com*/
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
?>