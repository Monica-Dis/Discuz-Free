<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism-taobao_com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_function.func.php';
if($_GET['key']) {
	$extrasql .= " AND g.it618_name LIKE '%".addcslashes($_GET['key'],'%_')."%'";
}

if($_GET['finduid']) {
	$extrasql .= " AND s.it618_uid = ".intval($_GET['finduid']);
}

if($_GET['state']) {
	$state0='';$state1='';$state10='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$extrasql .= " AND s.it618_state = 0";$state1='selected="selected"';}
	if($_GET['state']==10){$extrasql .= " AND s.it618_state = 10";$state10='selected="selected"';}
	if($_GET['state']==2){$extrasql .= " AND s.it618_state = 1";$state2='selected="selected"';}
	if($_GET['state']==3){$extrasql .= " AND s.it618_state = 2";$state3='selected="selected"';}
	if($_GET['state']==4){$extrasql .= " AND s.it618_state = 3";$state4='selected="selected"';}
	if($_GET['state']==5){$extrasql .= " AND s.it618_state = 4";$state4='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&state='.$_GET['state'];

if(submitcheck('it618submit_fukuan')){
	$del=0;
	if($reabc[8]!='c')return; /*dism��taobao��com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." where id=".$delid);

		if($it618_auction_sale['it618_state']==10){
			$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$it618_auction_sale['it618_pid']);
			
			if($it618_auction_goods['it618_paytype']==1){
				
				$it618_auction_sale_price = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_saleid=".$delid." and it618_uid=".$it618_auction_sale['it618_uid']." and it618_yajin>0");
				C::t('common_member_count')->increase($it618_auction_sale_price['it618_uid'], array(
					'extcredits'.$it618_auction['auction_credit_yj'] => $it618_auction_sale_price['it618_yajin'])
				);
				
				$kmcount=DB::result_first("select count(1) from ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$it618_auction_sale['it618_pid']);
			
				 if($kmcount>0){
					  for($km_n=1;$km_n<=1;$km_n++){
						  $it618_auction_goods_km=DB::fetch_first("select * from ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$it618_auction_sale['it618_pid']);
						  $strkm.=$it618_auction_goods_km['it618_code'].",";
						  DB::query("delete from ".DB::table('it618_auction_goods_km')." where id=".$it618_auction_goods_km['id']);
						  
						  $it618_blmoney=intval($it618_auction_sale['it618_bl']*$it618_auction_sale['it618_score']/100);
						  $money=$it618_auction_sale['it618_score']-$it618_blmoney;
						  C::t('common_member_count')->increase($it618_auction_sale['it618_postuid'], array(
							  'extcredits'.$it618_auction['auction_credit_yj'] => $money)
						  );
					  }
					  $it618_state=4;
					  it618_auction_sendmessage("shouhuo_shop",$it618_auction_sale['id']);
				 }else{
					  $strkm='';
					  $it618_state=1;
				 }
				 
				 DB::query("update ".DB::table('it618_auction_goods')." set it618_salecount=it618_salecount+1 where id=".$it618_auction_sale['it618_pid']);
				 DB::query("update ".DB::table('it618_auction_goods')." set it618_count=it618_count-1 where it618_count>0 and id=".$it618_auction_sale['it618_pid']);
				
				C::t('#it618_auction#it618_auction_sale')->update($delid,array(
					'it618_blscore' => $it618_blmoney,
					'it618_km' => $strkm,
					'it618_state' => $it618_state
				 ));
			}
			
			if($it618_auction_goods['it618_paytype']==2){
				$kmcount=DB::result_first("select count(1) from ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$it618_auction_sale['it618_pid']);
				
				 if($kmcount>0){
					  for($km_n=1;$km_n<=1;$km_n++){
						  $it618_auction_goods_km=DB::fetch_first("select * from ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$it618_auction_sale['it618_pid']);
						  $strkm.=$it618_auction_goods_km['it618_code'].",";
						  DB::query("delete from ".DB::table('it618_auction_goods_km')." where id=".$it618_auction_goods_km['id']);
						  
						  $it618_blmoney=intval($it618_auction_sale['it618_bl']*$it618_auction_sale['it618_score']/100);
						  $money=$it618_auction_sale['it618_score']-$it618_blmoney;
						  it618_auction_money('shopmoney',$it618_auction_sale['id'],$it618_auction_sale['it618_postuid'],$money,$it618_auction_lang['s843'],1);
					  }
					  $it618_state=4;
					  it618_auction_sendmessage("shouhuo_shop",$it618_auction_sale['id']);
				 }else{
					  $strkm='';
					  $it618_state=1;
				 }
				 
				 DB::query("update ".DB::table('it618_auction_goods')." set it618_salecount=it618_salecount+1 where id=".$it618_auction_sale['it618_pid']);
				 DB::query("update ".DB::table('it618_auction_goods')." set it618_count=it618_count-1 where it618_count>0 and id=".$it618_auction_sale['it618_pid']);
				
				C::t('#it618_auction#it618_auction_sale')->update($delid,array(
					'it618_blscore' => $it618_blmoney,
					'it618_km' => $strkm,
					'it618_state' => $it618_state
				 ));
				
				$it618_auction_sale_price = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_saleid=".$it618_auction_sale['id']." and it618_uid=".$it618_auction_sale['it618_uid']);
				
				it618_auction_money('tuiyajin3',$it618_auction_sale['id'],$it618_auction_sale_price['it618_uid'],$it618_auction_sale_price['it618_yajin'],$it618_auction_lang['s838'],1);
				
				$flscore=(intval($it618_auction_sale_price['it618_yajin']*$it618_auction_sale_price['it618_flbl']/100));
				if($flscore>0){
					it618_auction_money('yajinjl',$it618_auction_sale['id'],$it618_auction_sale_price['it618_uid'],$flscore,$it618_auction_lang['s839'],1);
				}
				DB::query("update ".DB::table('it618_auction_sale_price')." set it618_fl=".$flscore." where id=".$it618_auction_sale_price['id']);
			}
						
			$del=$del+1;
		}
	}

	cpmsg($it618_auction_lang['s700'].$del.$it618_auction_lang['s149'], "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_yifahuo')){
	$ok=0;
	if($reabc[9]!='t')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." where id=".$delid);
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$it618_auction_sale['it618_pid']);
		
		if($it618_auction_sale['it618_state']==1&&($it618_auction_goods['it618_isaddr']!=1||$it618_auction_sale['it618_addr']!='')){
			DB::query("update ".DB::table('it618_auction_sale')." set it618_state=2 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_auction_lang['s150'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_kd')){
	$ok=0;
	if($reabc[10]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." where id=".$delid);
		
		if($it618_auction_sale['it618_state']==2){
			C::t('#it618_auction#it618_auction_sale')->update($delid,array(
				'it618_kdid' => intval($_GET['it618_kdid'][$delid]),
				'it618_kddan' => $_GET['it618_kddan'][$delid]
			));
			$ok=$ok+1;
		}
	}

	cpmsg($it618_auction_lang['s151'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_ok')){
	$ok=0;
	if($reabc[9]!='t')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." where id=".$delid);
		
		if($it618_auction_sale['it618_state']==2){
			$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$it618_auction_sale['it618_pid']);
			
			DB::query("update ".DB::table('it618_auction_sale')." set it618_state=4 WHERE id=".$delid);
			it618_auction_sendmessage("shouhuo_shop",$it618_auction_sale['id']);
			if($it618_auction_sale['it618_postuid']>0){
				$it618_blmoney=intval($it618_auction_sale['it618_bl']*$it618_auction_sale['it618_score']/100);
				$money=$it618_auction_sale['it618_score']-$it618_blmoney;
				if($it618_auction_sale['it618_type']==1){
					C::t('common_member_count')->increase($it618_auction_sale['it618_postuid'], array(
						'extcredits'.$it618_auction['auction_credit'] => $money)
					);
				}else{
					if($it618_auction_goods['it618_paytype']==2){
						it618_auction_money('shopmoney',$it618_auction_sale['id'],$it618_auction_sale['it618_postuid'],$money,$it618_auction_lang['s843'],1);
					}
				}
				
				C::t('#it618_auction#it618_auction_sale')->update($delid,array(
					'it618_blscore' => $it618_blmoney
				 ));
			}
			$ok=$ok+1;
		}
	}

	cpmsg($it618_auction_lang['s395'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=13)return; /*Dism��taobao��com*/

echo '
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_auction/images/common.css" />
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/kindeditor-min.js"></script>
<script src="source/plugin/it618_auction/js/jquery.js"></script>
';

showformheader("plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do");
showtableheaders($it618_auction_lang['s152'],'it618_auction_sum');
	showsubmit('it618sercsubmit', $it618_auction_lang['s9'], $it618_auction_lang['s153'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.$it618_auction_lang['s154'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_auction_lang['s167'].' <select name="state"><option value=0 '.$state0.'>'.$it618_auction_lang['s155'].'</option><option value=1 '.$state1.'>'.$it618_auction_lang['s156'].'</option><option value=10 '.$state10.'>'.$it618_auction_lang['s698'].'</option><option value=2 '.$state2.'>'.$it618_auction_lang['s157'].'</option><option value=3 '.$state3.'>'.$it618_auction_lang['s158'].'</option><option value=4 '.$state4.'>'.$it618_auction_lang['s353'].'</option><option value=5 '.$state5.'>'.$it618_auction_lang['s397'].'</option></select>');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." s,".DB::table('it618_auction_goods')." g WHERE s.it618_pid=g.id $extrasql");
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=10>'.$it618_auction_lang['s159'].$count.'<span style="float:right;color:red">'.$it618_auction_lang['s396'].'</span></td></tr>';
	showsubtitle(array('', $it618_auction_lang['s161'],$it618_auction_lang['s164'],$it618_auction_lang['s165'].'/'.$it618_auction_lang['s166'],$it618_auction_lang['s167'],$it618_auction_lang['s501'],$it618_auction_lang['s169']));
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_kd')." ORDER BY it618_order DESC");
	$tmp.='<option value="0">'.$it618_auction_lang['s170'].'</option>';
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
	$query = DB::query("SELECT s.* FROM ".DB::table('it618_auction_sale')." s,".DB::table('it618_auction_goods')." g WHERE s.it618_pid=g.id $extrasql order by id desc LIMIT $startlimit, $ppp");
	while($it618_auction_sale = DB::fetch($query)) {
		
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
		$it618_name=$it618_auction_goods['it618_name'];
		$it618_picsmall=$it618_auction_goods['it618_picsmall'];
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_sale['it618_uid']);
		
		$pricecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
		
		if($it618_auction_sale['it618_state']==2&&$it618_auction_sale['it618_km']==''){
			$tmp1=str_replace('<option value='.$it618_auction_sale['it618_kdid'].'>','<option value='.$it618_auction_sale['it618_kdid'].' selected="selected">',$tmp);
			$strkd='<font color=green>'.$it618_auction_lang['s171'].'<select name="it618_kdid['.$it618_auction_sale[id].']">'.$tmp1.'</select><br>'.$it618_auction_lang['s172'].'<input type="text" class="txt" style="width:160px;margin-top:3px" name="it618_kddan['.$it618_auction_sale[id].']" value="'.$it618_auction_sale['it618_kddan'].'"></font>';
		}else{
			if($it618_auction_sale['it618_kdid']!=0&&$it618_auction_sale['it618_kddan']!=''){
				$it618_auction_kd=DB::fetch_first("select * from ".DB::table('it618_auction_kd')." WHERE id=".$it618_auction_sale['it618_kdid']);
				$strkd=it618_auction_getlang('s171').'<a href="'.$it618_auction_kd['it618_url'].'" target="_blank"><font color=green>'.$it618_auction_kd['it618_name'].'</font></a><br>'.it618_auction_getlang('s172').'<font color=green>'.$it618_auction_sale['it618_kddan'].'</font>';
			}else{
				$strkd='';	
			}
		}

		if($it618_auction_sale['it618_state']==0)$it618_state='<font color=blue>'.$it618_auction_lang['s156'].'</font>';
		if($it618_auction_sale['it618_state']==10)$it618_state='<font color=#F0F>'.$it618_auction_lang['s698'].'</font>';
		if($it618_auction_sale['it618_state']==1){
			$it618_state='<font color=red>'.$it618_auction_lang['s157'].'</font>';
		  
			if($it618_auction_sale['it618_addr']==''){
				$it618_state.='<br><font color=blue>'.$it618_auction_lang['s797'].'</font>';
			}else{
				$it618_state.='<br><font color=green>'.$it618_auction_lang['s798'].'</font>';
			}
		}
		if($it618_auction_sale['it618_state']==2){
			$it618_state='<font color=green>'.it618_auction_getlang('s158').'</font>';
			
			if($it618_auction_sale['it618_kddan']==''){
				$it618_state.='<br><font color=blue>'.$it618_auction_lang['s799'].'</font>';
			}
		}
		if($it618_auction_sale['it618_state']==3)$it618_state='<font color=#ccc>'.$it618_auction_lang['s353'].'</font>';
		if($it618_auction_sale['it618_state']==4)$it618_state='<font color=green>'.$it618_auction_lang['s397'].'</font>';
		
		$it618_bz='';
		$it618_fl = DB::result_first("SELECT sum(it618_fl) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
		if($it618_auction_sale['it618_type']==1){
			$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
			$creditnametmp=$creditname;
			$it618_type='<font color=green><b>'.$it618_auction_lang['s761'].'</b></font>';

		}else{
			$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];
			$creditnametmp=$it618_auction_lang['s432'];
			
			if($IsCredits==1){
				if($it618_auction_goods['it618_paytype']==1)$paytype=$it618_auction_lang['s830'];else $paytype=$it618_auction_lang['s831'];
			}
			
			$it618_type='<font color=red><b>'.$paytype.$it618_auction_lang['s762'].'</b></font>';
			
			$it618_yajin = DB::result_first("SELECT sum(it618_yajin) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
			$it618_shouxufei = DB::result_first("SELECT sum(it618_shouxufei) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
			$it618_chujiafei = DB::result_first("SELECT sum(it618_chujiafei) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
			$it618_bz.=$it618_auction_lang['s764'].'<font color=red>'.$it618_yajin.'</font>'.$creditnametmp.' ';
			$it618_bz.=$it618_auction_lang['s307'].'<font color=red>'.$it618_shouxufei.'</font>'.$creditname.' ';
			$it618_bz.=$it618_auction_lang['s308'].'<font color=red>'.$it618_chujiafei.'</font>'.$creditname.' ';
			$it618_bz.=$it618_auction_lang['s671'].'<font color=red>'.$it618_fl.'</font>'.$creditname.' ';
		}
		
		if($it618_auction_sale['it618_postuid']>0){
			$it618_blmoney=intval($it618_auction_sale['it618_bl']*$it618_auction_sale['it618_score']/100);
			$money=0;
			if($it618_auction_sale['it618_state']==0)$it618_blmoney=0;
			if($it618_auction_sale['it618_state']==4){
				$money=$it618_auction_sale['it618_score']-$it618_blmoney;
			}
			if($money>0)$money='<font color=red>'.$money.'</font>';
			$tcstr='<br>'.$it618_auction_lang['s398'].$it618_auction_sale['it618_bl'].'%<br>'.$it618_auction_lang['s399'].'<font color=red>'.$it618_blmoney.'</font>'.$creditname.'<br><a href="'.it618_auction_rewriteurl($it618_auction_sale['it618_postuid']).'" target="_blank">'.it618_auction_getusername($it618_auction_sale['it618_postuid']).'</a>'.$it618_auction_lang['s640'].'<font color=red>'.$money.'</font>'.$creditname;
			
			if($it618_auction_sale['it618_state']==3){
				$tcstr='';
			}
			
			$it618_postuid=$tcstr;
		}else{
			$it618_postuid='';
		}
		
		$it618_addr='';
		if($it618_auction_sale['it618_addr']!=''){
			$it618_addr='<a href="javascript:" onclick="document.getElementById(\'showaddrbtn\').click();document.getElementById(\'saleid\').value=\''.$it618_auction_sale['id'].'\';setTimeout(\'readaddr1();\',100)">'.$it618_auction_lang['s298'].'</a>';
		}
		
		$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_auction_sale[id].'" name="delete[]" value="'.$it618_auction_sale[id].'"><input type="hidden" name="id['.$it618_auction_sale[id].']" value="'.$it618_auction_sale[id].'"><label for="chk_del'.$it618_auction_sale[id].'" title="'.$it618_auction_lang['s173'].'D'.$saleid.'">'.$it618_auction_sale['id'].'</label>',
			'<a href="'.$tmpurl.'" title="'.$it618_auction_lang['s174'].''.$it618_auction_sale['it618_pid'].' '.$it618_auction_lang['s175'].''.it618_auction_classname($it618_auction_goods['it618_class_id']).'" target="_blank" style="float:left"><img style="float:left;margin-right:6px" src="'.$it618_picsmall.'" width="88" height="58" align="absmiddle"/></a><div style="float:left;width:300px;margin-left:3px;line-height:18px"><a href="'.$tmpurl.'" target="_blank">'.$it618_name.'</a><br>'.$it618_type.' '.$it618_auction_lang['s408'].'<font color=red>'.$it618_auction_sale['it618_bscore'].'</font>'.$creditnametmp.' '.$it618_bz.'</div>',
			'<a href="javascript:" onclick="document.getElementById(\'showpricebtn\').click();document.getElementById(\'saleid\').value=\''.$it618_auction_sale['id'].'\';setTimeout(\'readpricelist1();\',100)">'.$it618_auction_lang['s176'].'(<font color=red>'.$pricecount.'</font>)</a><br>'.$it618_auction_lang['s354'].'<a href="'.it618_auction_rewriteurl($it618_auction_sale['it618_uid']).'" target="_blank">'.it618_auction_getusername($it618_auction_sale['it618_uid']).'</a><br>'.$it618_auction_lang['s404'].'<font color=red>'.$it618_auction_sale['it618_score'].'</font>'.$creditnametmp,
			$it618_addr.'<br>'.$strkd,
			$it618_state,
			$it618_postuid,
			'<div style="width:75px">'.date('Y-m-d H:i:s', $it618_auction_sale['it618_time']).'</div>'
		));
	}
	
	function it618_auction_classname($aid){
		return DB::result_first("select it618_classname from ".DB::table('it618_auction_class')." where id=".$aid);
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_auction_lang['s177'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_fukuan" style="color:green;font-weight:bold" value="'.$it618_auction_lang['s178'].'" onclick="return confirm(\''.$it618_auction_lang['s179'].'\')" /> <input type="submit" class="btn" name="it618submit_yifahuo" value="'.$it618_auction_lang['s180'].'" onclick="return confirm(\''.$it618_auction_lang['s181'].'\')"/> '.$it618_auction_lang['s643'].'<input type="submit" class="btn" name="it618submit_kd" value="'.$it618_auction_lang['s182'].'"/> <input type="submit" class="btn" style="color:red" name="it618submit_ok" value="'.$it618_auction_lang['s406'].'" onclick="return confirm(\''.$it618_auction_lang['s407'].'\')"/>  '.$it618_auction_lang['s183'].'  &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return; /*Dism��taobao��com*/
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
echo '<span id="showpricebtn"></span><span id="showaddrbtn"></span><input type="hidden" id="saleid"/>
<script>
KindEditor.ready(function(K) {K(\'#showpricebtn\').click(function() {
	var dialog = K.dialog({
		width :620,
		height:350,
		title : \''.$it618_auction_lang['s184'].'\',
		body : \'<div id="readpricelist" style="margin:10px;"></div>\',
		closeBtn : {
			name : \''.$it618_auction_lang['s185'].'\',
			click : function(e) {
				dialog.remove();
			}
		},
		noBtn : {
			name : \''.$it618_auction_lang['s185'].'\',
			click : function(e) {
				dialog.remove();
			}
		}
	});
});});

function readpricelist1(){
	readpricelist("");
}

function readpricelist(url){
	if(url=="")url="'.$_G['siteurl'].'plugin.php?id=it618_auction:ajax&saleid="+document.getElementById("saleid").value;
	IT618_AUCTION.get(url, {ac:"readpricelist"},function (data, textStatus){
	IT618_AUCTION("#readpricelist").html(data);
	}, "html");	
	window.onerror=function(){return true;}
}

KindEditor.ready(function(K) {K(\'#showaddrbtn\').click(function() {
	var dialog = K.dialog({
		width :480,
		height:280,
		title : \''.$it618_auction_lang['s298'].'\',
		body : \'<div style="margin:10px;"><table class="showset" width="100%" id="readaddr"></table></div>\',
		closeBtn : {
			name : \''.$it618_auction_lang['s185'].'\',
			click : function(e) {
				dialog.remove();
			}
		},
		noBtn : {
			name : \''.$it618_auction_lang['s185'].'\',
			click : function(e) {
				dialog.remove();
			}
		}
	});
});});

function readaddr1(){
	readaddr("");
}

function readaddr(url){
	if(url=="")url="'.$_G['siteurl'].'plugin.php?id=it618_auction:ajax&saleid="+document.getElementById("saleid").value;
	IT618_AUCTION.get(url, {ac:"readaddr"},function (data, textStatus){
	IT618_AUCTION("#readaddr").html(data);
	}, "html");	
	window.onerror=function(){return true;}
}
</script>';
?>