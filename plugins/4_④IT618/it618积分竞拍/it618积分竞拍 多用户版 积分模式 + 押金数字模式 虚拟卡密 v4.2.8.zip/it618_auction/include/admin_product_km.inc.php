<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
$pid=intval($_GET['pid']);
if($reabc[5]!='_')return; /*dism-taobao_com*/
if(submitcheck('it618submit')){
	$ok1=0;
	$del=0;
	
	if($reabc[8]!='c')return; /*dism��taobao��com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_auction_goods_km', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_code'])) {
		foreach($_GET['it618_code'] as $id => $val) {

			C::t('#it618_auction#it618_auction_goods_km')->update($id,array(
				'it618_code' => trim($_GET['it618_code'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$pid);
	DB::query("update ".DB::table('it618_auction_goods')." set it618_count=".$kmcount." where id=".$pid);
	
	cpmsg($it618_auction_lang['s5'].$ok1.' '.$it618_auction_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_product_km&pmod=admin_product&operation=$operation&do=$do&page=$page&pid=".$pid, 'succeed');
}

if(submitcheck('it618submit_adds')){
	$ok1=0;
	
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $_GET['it618_name_adds']);
	$line=explode("@||@",$lines);

	foreach($line as $key =>$li)
	{
		if(trim($li)!=''){
			C::t('#it618_auction#it618_auction_goods_km')->insert(array(
				'it618_pid' => $pid,
				'it618_code' => trim($li)
			), true);
			$ok1=$ok1+1;
		}
	}
	
	$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$pid);
	DB::query("update ".DB::table('it618_auction_goods')." set it618_count=".$kmcount." where id=".$pid);
	
	cpmsg($it618_auction_lang['s135'].$ok1, "action=plugins&identifier=$identifier&cp=admin_product_km&pmod=admin_product&operation=$operation&do=$do&page=$page&pid=".$pid, 'succeed');
}

if(submitcheck('it618submit_dao')){
	$ok1=0;
	$tmparr=explode("source",$_GET['it618_name_dao']);
	$file_path=DISCUZ_ROOT.'./source'.$tmparr[1];
	if (!file_exists($file_path)) {
		cpmsg($it618_auction_lang['s136'], "action=plugins&identifier=$identifier&cp=admin_product_km&pmod=admin_product&operation=$operation&do=$do&page=$page&pid=".$pid, 'error');
	}
	
	$lines = dfsockopen($_G['siteurl'].$file_path);
	ini_set('memory_limit', '-1');
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $lines);
	$line=explode("@||@",$lines);
	$ok1=0;

	foreach($line as $key =>$li)
	{
		if(trim($li)!=''){
			C::t('#it618_auction#it618_auction_goods_km')->insert(array(
				'it618_pid' => $pid,
				'it618_code' => trim($li)
			), true);
			$ok1=$ok1+1;
		}
	}
	@unlink($file_path);
	$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$pid);
	DB::query("update ".DB::table('it618_auction_goods')." set it618_count=".$kmcount." where id=".$pid);
	
	cpmsg($it618_auction_lang['s137'].$ok1, "action=plugins&identifier=$identifier&cp=admin_product_km&pmod=admin_product&operation=$operation&do=$do&page=$page&pid=".$pid, 'succeed');
}

if(submitcheck('it618submit_clear')){
	DB::query("delete from ".DB::table('it618_auction_goods_km')." where it618_pid=".$pid);
	DB::query("update ".DB::table('it618_auction_goods')." set it618_count=0 where id=".$pid);
	
	cpmsg($it618_auction_lang['s138'], "action=plugins&identifier=$identifier&cp=admin_product_km&pmod=admin_product&operation=$operation&do=$do&page=$page&pid=".$pid, 'succeed');
}

if(count($reabc)!=13)return; /*Dism��taobao��com*/

$pname = DB::result_first("select it618_name from ".DB::table('it618_auction_goods')." where id=".$pid);
showformheader("plugins&identifier=$identifier&cp=admin_product_km&pmod=admin_product&operation=$operation&do=$do&page=$page&pid=".$pid);
showtableheaders('<font color=red>'.$pname.'</font> '.$it618_auction_lang['s139'],'it618_auction_goods_km');

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_goods_km')." where it618_pid=".$pid);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_product_km&pmod=admin_product&operation=$operation&do=$do&pid=".$pid);
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/kindeditor-min.js"></script>
<script>
	KindEditor.ready(function(K) {
				var uploadbutton = K.uploadbutton({
					button : K(\'#btn_upfile\')[0],
					fieldName : \'imgFile\',
					url : \'source/plugin/it618_auction/kindeditor/php/upload_json.php?dir=file&filetype=txt\',
					afterUpload : function(data) {
						if (data.error === 0) {
							var url = K.formatUrl(data.url, \'absolute\');
							K(\'#it618_name_dao\').val(url);
						} else {
							alert(data.message);
						}
					},
					afterError : function(str) {
						alert(str);
					}
				});
				uploadbutton.fileBox.change(function(e) {
					uploadbutton.submit();
				});
			});
</script>';

	echo '<tr><td colspan=4>'.$it618_auction_lang['s140'].$count.'</td></tr>';
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_goods_km')." where it618_pid=".$pid);
	while($it618_auction = DB::fetch($query)) {
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_auction[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_auction[id]]\" value=\"$it618_auction[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:400px\" name=\"it618_code[$it618_auction[id]]\" value=\"$it618_auction[it618_code]\">"
		));
	}
	
	
	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	
	showsubmit('it618submit', 'submit', 'del', '<input type="submit" class="btn" name="it618submit_clear" value="'.$it618_auction_lang['s141'].'" onclick="return confirm(\''.$it618_auction_lang['s142'].'\')" /> <input type="botton" class="btn" value="'.$it618_auction_lang['s143'].'" style="width:70px" onclick="location.href=\''.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product&pmod=admin_product&operation='.$operation.'&do='.$do.'&page='.$_GET['page'].'\'"/><input type=hidden value=$page name=page />', $multipage);
	
	echo '<tr><td colspan=2>'.$it618_auction_lang['s144'].'<br><textarea name="it618_name_adds" style="width:400px;height:200px;margin-top:2px;"></textarea><br><input type="submit" class="btn" name="it618submit_adds" value="'.$it618_auction_lang['s145'].'"/></td></tr>
		  <tr><td colspan=2>'.$it618_auction_lang['s146'].'<br><input id="it618_name_dao" name="it618_name_dao" class="txt" style="width:300px"><input type="submit" class="btn" id="btn_upfile" value="'.$it618_auction_lang['s147'].'"/><br><input type="submit" class="btn" name="it618submit_dao" value="'.$it618_auction_lang['s148'].'"/></td></tr>';
	if(count($reabc)!=13)return; /*Dism��taobao��com*/
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
?>