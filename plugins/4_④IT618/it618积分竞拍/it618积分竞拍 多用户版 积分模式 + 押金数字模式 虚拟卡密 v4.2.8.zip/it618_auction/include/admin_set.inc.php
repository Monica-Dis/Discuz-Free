<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism-taobao_com*/

$it618_auction_set=C::t('#it618_auction#it618_auction_set')->fetch_by_setname($setname);

if(submitcheck('it618submit')){
	if(C::t('#it618_auction#it618_auction_set')->count_by_setname($setname)==0){
		C::t('#it618_auction#it618_auction_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $_GET[$setname]
		), true);
	}else{
		C::t('#it618_auction#it618_auction_set')->update($it618_auction_set['id'],array(
			'setvalue' => $_GET[$setname]
		));
	}
	

	cpmsg($it618_auction_lang['s774'], "action=plugins&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

$setvalue=$it618_auction_set['setvalue'];

if($cp1==2&&$setvalue==''){
	$setvalue=$it618_auction_lang['s675'];
}

if($cp1==3&&$setvalue==''){
	$setvalue=$it618_auction_lang['s676'];
}

showformheader("plugins&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($admin_set_title[$cp1].'<span style="font-weight:normal;color:red;margin-left:90px">'.$it618_auction_lang['s1068'].'</span>','it618_auction_set');

echo '
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="'.$setname.'"]\', {
			cssPath : \'source/plugin/it618_auction/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_auction/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_auction/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>

<tr><td width=800><textarea name="'.$setname.'" style="width:800px;height:400px;visibility:hidden;">'.$setvalue.'</textarea></td></tr>
';

showsubmit('it618submit', $it618_auction_lang['s1064']);
if(count($reabc)!=13)return; /*Dism��taobao��com*/
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/

?>