<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism-taobao_com*/

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_function.func.php';

$it618sql='it618_isok1<>0 or it618_isok2<>0';
if($_GET['it618_isok1']) {
	$it618_isok10='';$it618_isok11='';$it618_isok12='';$it618_isok13='';
	if($_GET['it618_isok1']==0){$it618sql=' it618_isok1<>0';$it618_isok10='selected="selected"';}
	if($_GET['it618_isok1']==1){$it618sql=' it618_isok1=1';$it618_isok11='selected="selected"';}
	if($_GET['it618_isok1']==2){$it618sql= 'it618_isok1=2';$it618_isok12='selected="selected"';}
	if($_GET['it618_isok1']==3){$it618sql=' it618_isok1=3';$it618_isok13='selected="selected"';}
}

if($_GET['it618_isok2']) {
	$it618_isok20='';$it618_isok21='';$it618_isok22='';$it618_isok23='';
	if($_GET['it618_isok2']==0){$it618sql.=' or it618_isok2<>0';$it618_isok20='selected="selected"';}
	if($_GET['it618_isok2']==1){$it618sql.=' and it618_isok2=1';$it618_isok21='selected="selected"';}
	if($_GET['it618_isok2']==2){$it618sql.=' and it618_isok2=2';$it618_isok22='selected="selected"';}
	if($_GET['it618_isok2']==3){$it618sql.=' and it618_isok2=3';$it618_isok23='selected="selected"';}
}

$sql='&finduid='.$_GET['finduid'].'&it618_name='.$_GET['it618_name'].'&it618_gsname='.$_GET['it618_gsname'].'&it618_isok1='.$_GET['it618_isok1'].'&it618_isok2='.$_GET['it618_isok2'];

if(submitcheck('it618submit_edit')){
	$ok=0;
	if($reabc[8]!='c')return; /*dism��taobao��com*/
	if(is_array($_GET['id'])) {
		foreach($_GET['id'] as $id => $val) {
	
			C::t('#it618_auction#it618_auction_identity')->update($id,array(
				'it618_bl' => $_GET['it618_bl'][$id],
				'it618_bl_yj' => $_GET['it618_bl_yj'][$id],
				'it618_mode' => $_GET['it618_mode'][$id],
				'it618_ischeck' => $_GET['it618_ischeck'][$id]
			));
			$ok=$ok+1;
		}
	}

	cpmsg($it618_auction_lang['s743'].$ok, "action=plugins&identifier=$identifier&cp=admin_identity&pmod=admin_identity&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass1')){
	$ok=0;
	if($reabc[8]!='c')return; /*dism��taobao��com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_identity=C::t('#it618_auction#it618_auction_identity')->fetch_by_id($delid);
		
		if($it618_auction_identity['it618_isok1']==1){
			C::t('#it618_auction#it618_auction_identity')->update($it618_auction_identity['id'],array(
				'it618_time1' => $_G['timestamp'],
				'it618_isok1' => 3
			));
			$ok=$ok+1;
		}
		it618_auction_sendmessage("rz_shop",$it618_auction_identity['id'],'1');
	}
	
	cpmsg($it618_auction_lang['s409'].$ok, "action=plugins&identifier=$identifier&cp=admin_identity&pmod=admin_identity&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}


if(submitcheck('it618submit_nopass1')){
	$ok=0;
	if($reabc[7]!='u')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_identity=C::t('#it618_auction#it618_auction_identity')->fetch_by_id($delid);
		
		if($it618_auction_identity['it618_isok1']==1){
			C::t('#it618_auction#it618_auction_identity')->update($it618_auction_identity['id'],array(
				'it618_time1' => $_G['timestamp'],
				'it618_isok1' => 2
			));
			$ok=$ok+1;
			it618_auction_sendmessage("rz_shop",$it618_auction_identity['id'],'1');
		}
	}

	cpmsg($it618_auction_lang['s410'].$ok, "action=plugins&identifier=$identifier&cp=admin_identity&pmod=admin_identity&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass2')){
	$ok=0;
	if($reabc[6]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_identity=C::t('#it618_auction#it618_auction_identity')->fetch_by_id($delid);
		
		if($it618_auction_identity['it618_isok2']==1){
			C::t('#it618_auction#it618_auction_identity')->update($it618_auction_identity['id'],array(
				'it618_time2' => $_G['timestamp'],
				'it618_isok2' => 3
			));
			$ok=$ok+1;
			it618_auction_sendmessage("rz_shop",$it618_auction_identity['id'],'2');
		}
	}

	cpmsg($it618_auction_lang['s411'].$ok, "action=plugins&identifier=$identifier&cp=admin_identity&pmod=admin_identity&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}


if(submitcheck('it618submit_nopass2')){
	$ok=0;
	if($reabc[9]!='t')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_identity=C::t('#it618_auction#it618_auction_identity')->fetch_by_id($delid);
		
		if($it618_auction_identity['it618_isok2']==1){
			C::t('#it618_auction#it618_auction_identity')->update($it618_auction_identity['id'],array(
				'it618_time2' => $_G['timestamp'],
				'it618_isok2' => 2
			));
			$ok=$ok+1;
			it618_auction_sendmessage("rz_shop",$it618_auction_identity['id'],'2');
		}
	}

	cpmsg($it618_auction_lang['s412'].$ok, "action=plugins&identifier=$identifier&cp=admin_identity&pmod=admin_identity&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=13)return; /*Dism��taobao��com*/

showformheader("plugins&identifier=$identifier&cp=admin_identity&pmod=admin_identity&operation=$operation&do=$do");
showtableheaders($it618_auction_lang['s413'],'it618_auction_identity');
	showsubmit('it618sercsubmit', $it618_auction_lang['s414'], $it618_auction_lang['s415'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />'.$it618_auction_lang['s416'].' <input name="it618_name" value="'.$_GET['it618_name'].'" class="txt" style="width:80px" />'.$it618_auction_lang['s417'].' <input name="it618_gsname" value="'.$_GET['it618_gsname'].'" class="txt" style="width:180px" />'.$it618_auction_lang['s418'].' <select name="it618_isok1"><option value=0 '.$it618_isok10.'>'.$it618_auction_lang['s419'].'</option><option value=1 '.$it618_isok11.'>'.$it618_auction_lang['s420'].'</option><option value=2 '.$it618_isok12.'>'.$it618_auction_lang['s421'].'</option><option value=3 '.$it618_isok13.'>'.$it618_auction_lang['s422'].'</option></select>  '.$it618_auction_lang['s423'].' <select name="it618_isok2"><option value=0 '.$it618_isok20.'>'.$it618_auction_lang['s419'].'</option><option value=1 '.$it618_isok21.'>'.$it618_auction_lang['s420'].'</option><option value=2 '.$it618_isok22.'>'.$it618_auction_lang['s421'].'</option><option value=3 '.$it618_isok23.'>'.$it618_auction_lang['s422'].'</option></select>');
	
	$count = C::t('#it618_auction#it618_auction_identity')->count_by_search($it618sql,'id DESC',$_GET['it618_name'],$_GET['it618_gsname'],$_GET['finduid']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_identity&pmod=admin_identity&operation=$operation&do=$do".$sql);
	
	$it618_modetmp='<option value="1">'.$it618_auction_lang['s800'].'</option><option value="2">'.$it618_auction_lang['s801'].'</option><option value="3">'.$it618_auction_lang['s802'].'</option>';
	
	echo '<tr><td colspan=14>'.$it618_auction_lang['s424'].$count.'<span style="float:right;color:red">'.$it618_auction_lang['s742'].'</span></td></tr>';
	showsubtitle(array('', $it618_auction_lang['s425'],$it618_auction_lang['s426'],$it618_auction_lang['s427'],$it618_auction_lang['s429'],$it618_auction_lang['s428']));
	
	foreach(C::t('#it618_auction#it618_auction_identity')->fetch_all_by_search(
		$it618sql,'id DESC',$_GET['it618_name'],$_GET['it618_gsname'],$_GET['finduid'],$startlimit,$ppp
	) as $it618_auction_identity) {
		
		if($it618_auction_identity['it618_isok1']==1)$it618_isok1='<font color=red>'.$it618_auction_lang['s420'].'</font>';
		if($it618_auction_identity['it618_isok1']==2)$it618_isok1='<font color=blue>'.$it618_auction_lang['s421'].'</font>';
		if($it618_auction_identity['it618_isok1']==3)$it618_isok1='<font color=green>'.$it618_auction_lang['s422'].'</font>';
		
		if($it618_auction_identity['it618_isok2']==1)$it618_isok2='<font color=red>'.$it618_auction_lang['s420'].'</font>';
		if($it618_auction_identity['it618_isok2']==2)$it618_isok2='<font color=blue>'.$it618_auction_lang['s421'].'</font>';
		if($it618_auction_identity['it618_isok2']==3)$it618_isok2='<font color=green>'.$it618_auction_lang['s422'].'</font>';
		
		$it618_mode=str_replace('<option value="'.$it618_auction_identity['it618_mode'].'"','<option value="'.$it618_auction_identity['it618_mode'].'" selected="selected"',$it618_modetmp);
		
		if($it618_auction_identity['it618_name']!='')$tmpstr1=$it618_auction_identity['it618_name'].'<br>'.$it618_auction_lang['s434'].$it618_auction_identity['it618_sfzid'].'<br>'.$it618_auction_lang['s433'].$it618_auction_identity['it618_qq'].'<br><a href="'.$it618_auction_identity['it618_sfzpic'].'" target="_blank">'.$it618_auction_lang['s435'].'</a><br>'.$it618_isok1.' '.date('Y-m-d', $it618_auction_identity['it618_time1']);
		
		if($it618_auction_identity['it618_gsname']!='')$tmpstr2=$it618_auction_identity['it618_gsname'].'<br>'.$it618_auction_identity['it618_yyzzid'].'<br><a href="'.$it618_auction_identity['it618_frsfzpic'].'" target="_blank">'.$it618_auction_lang['s436'].'</a> <a href="'.$it618_auction_identity['it618_yyzzpic'].'" target="_blank">'.$it618_auction_lang['s437'].'</a><br>'.$it618_isok2.' '.date('Y-m-d', $it618_auction_identity['it618_time2']);
		
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_identity['it618_uid']);
		$creditnum1=DB::result_first("select extcredits".$creditindex1." from ".DB::table('common_member_count')." where uid=".$it618_auction_identity['it618_uid']);
		$creditnum2=DB::result_first("select extcredits".$creditindex2." from ".DB::table('common_member_count')." where uid=".$it618_auction_identity['it618_uid']);
		
		$postcount1=DB::result_first("select count(1) from ".DB::table('it618_auction_goods')." where it618_checkstate=3 and it618_type=1 and it618_uid=".$it618_auction_identity['it618_uid']);
		$postcount2=DB::result_first("select count(1) from ".DB::table('it618_auction_goods')." where it618_checkstate=3 and it618_type=2 and it618_uid=".$it618_auction_identity['it618_uid']);
		$salecount1=DB::result_first("select count(1) from ".DB::table('it618_auction_sale')." where it618_type=1 and it618_postuid=".$it618_auction_identity['it618_uid']);
		$salecount2=DB::result_first("select count(1) from ".DB::table('it618_auction_sale')." where it618_type=2 and it618_postuid=".$it618_auction_identity['it618_uid']);
		
		$salesum1=DB::result_first("select sum(it618_score) from ".DB::table('it618_auction_sale')." where it618_type=1 and it618_state>1 and it618_state!=3 and it618_postuid=".$it618_auction_identity['it618_uid']);
		$salesum2=DB::result_first("select sum(it618_score) from ".DB::table('it618_auction_sale')." where it618_type=2 and it618_state>1 and it618_state!=3 and it618_postuid=".$it618_auction_identity['it618_uid']);
		
		$saletc1=DB::result_first("select sum(it618_blscore) from ".DB::table('it618_auction_sale')." where it618_type=1 and it618_postuid=".$it618_auction_identity['it618_uid']);
		$saletc2=DB::result_first("select sum(it618_blscore) from ".DB::table('it618_auction_sale')." where it618_type=2 and it618_postuid=".$it618_auction_identity['it618_uid']);
		
		if($salesum1=='')$salesum1=0;if($salesum2=='')$salesum2=0;if($saletc1=='')$saletc1=0;if($saletc2=='')$saletc2=0;

		$tcmoney=round(($tcmoney/100),2);
		$ytxmoney=$ytxmoney-$tcmoney;
		
		if($it618_auction_identity['it618_ischeck']==1)$it618_ischeck_checked='checked="checked"';else $it618_ischeck_checked="";
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_auction_identity[id].'" name="delete[]" value="'.$it618_auction_identity[id].'" '.$disabled.'><input type="hidden" name="id['.$it618_auction_identity[id].']" value="'.$it618_auction_identity[id].'"><label for="chk_del'.$it618_auction_identity[id].'">'.$it618_auction_identity['id'].'</label>',
			'<a href="home.php?mod=space&uid='.$it618_auction_identity['it618_uid'].'" target="_blank">'.$username.'</a>',
			$tmpstr1,
			$tmpstr2,
			'<font color=red>'.$creditnum1.'</font>'.$creditname1.' <font color=red>'.$creditnum2.'</font>'.$creditname2.'<br>'.$it618_auction_lang['s788'].'<input type="text" class="txt" style="width:40px;color:blue;margin-right:3px" name="it618_bl['.$it618_auction_identity['id'].']" value="'.$it618_auction_identity['it618_bl'].'">%<br>'.$it618_auction_lang['s789'].'<input type="text" class="txt" style="width:40px;color:blue;margin-right:3px;margin-top:3px" name="it618_bl_yj['.$it618_auction_identity['id'].']" value="'.$it618_auction_identity['it618_bl_yj'].'">%<br><select name="it618_mode['.$it618_auction_identity['id'].']">'.$it618_mode.'</select><input class="checkbox" type="checkbox" id="it618_ischeck'.$it618_auction_identity['id'].'" name="it618_ischeck['.$it618_auction_identity['id'].']" '.$it618_ischeck_checked.' value="1"><label for="it618_ischeck'.$it618_auction_identity['id'].'"><font color=green>'.$it618_auction_lang['s790'].'</font></label>',
			$it618_auction_lang['s791'].$postcount1.'/'.$postcount2.'<br>'.$it618_auction_lang['s792'].$salecount1.'/'.$salecount2.'<br>'.$it618_auction_lang['s793'].$salesum1.$creditname1.'/'.$salesum2.$it618_auction_lang['s794'].'<br>'.$it618_auction_lang['s795'].$saletc1.$creditname1.'/'.$saletc2.$it618_auction_lang['s794']
		));
	}


	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_auction_lang['s438'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_edit" value="'.$it618_auction_lang['s744'].'"/> <input type="submit" class="btn" name="it618submit_pass1" value="'.$it618_auction_lang['s439'].'" onclick="return confirm(\''.$it618_auction_lang['s440'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass1" value="'.$it618_auction_lang['s441'].'" onclick="return confirm(\''.$it618_auction_lang['s442'].'\')"/> <input type="submit" class="btn" name="it618submit_pass2" value="'.$it618_auction_lang['s443'].'" onclick="return confirm(\''.$it618_auction_lang['s444'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass2" value="'.$it618_auction_lang['s445'].'" onclick="return confirm(\''.$it618_auction_lang['s446'].'\')"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return; /*Dism��taobao��com*/
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
?>