<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism-taobao_com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_function.func.php';
if($_GET['key']!=''){
	$extrasql .= " and g.it618_name like '%".addcslashes($_GET['key'],'%_')."%'";
}

if($_GET['it618_class_id']>0){$extrasql .= " and g.it618_class_id=".intval($_GET['it618_class_id']);}

$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';$state7='';$state8='';
if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
if($_GET['state']==1){$extrasql .= " and g.it618_isbm = 1";$state1='selected="selected"';}
if($_GET['state']==2){$extrasql .= " and g.it618_isbm = 0";$state2='selected="selected"';}
if($_GET['state']==3){$extrasql .= " and g.it618_isaddr = 1";$state3='selected="selected"';}
if($_GET['state']==4){$extrasql .= " and g.it618_isaddr = 0";$state4='selected="selected"';}
if($_GET['state']==5){$extrasql .= " and g.it618_ison = 1";$state5='selected="selected"';}
if($_GET['state']==6){$extrasql .= " and g.it618_ison = 0";$state6='selected="selected"';}
if($_GET['state']==7){$extrasql .= " and g.it618_istj = 0";$state6='selected="selected"';}
if($_GET['state']==8){$extrasql .= " and g.it618_istj = 0";$state6='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';$orderby4='';
if($_GET['orderby']==0){$extrasql .= " order by g.it618_order desc,g.id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$extrasql .= " order by g.it618_count desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$extrasql .= " order by g.it618_salecount desc";$orderby2='selected="selected"';}
if($_GET['orderby']==3){$extrasql .= " order by g.it618_views desc";$orderby3='selected="selected"';}
if($_GET['orderby']==4){$extrasql .= " order by g.it618_score desc";$orderby4='selected="selected"';}

$sql='&key='.$_GET['key'].'&it618_class_id='.$_GET['it618_class_id'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='c')return; /*dism��taobao��com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." WHERE it618_pid=".$delid);
		if($salecount<=0){
			$it618_picbig=DB::result_first("SELECT it618_picbig FROM ".DB::table('it618_auction_goods')." WHERE id=".$delid);
			if($it618_picbig!=$_GET['it618_picbig']){
				$tmparr=explode("source",$it618_picbig);
				$tmparr1=explode("://",$it618_picbig);
				$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
				if(file_exists($it618_picbig)){
					$result=unlink($it618_picbig);
				}
			}
			$it618_picsmall=DB::result_first("SELECT it618_picsmall FROM ".DB::table('it618_auction_goods')." WHERE id=".$delid);
			if($it618_picsmall!=$_GET['it618_picsmall']){
				$tmparr=explode("source",$it618_picsmall);
				$tmparr1=explode("://",$it618_picsmall);
				$it618_picsmall=DISCUZ_ROOT.'./source'.$tmparr[1];
				if(file_exists($it618_picsmall)){
					$result=unlink($it618_picsmall);
				}
			}
			
			$it618_message_images=DB::result_first("SELECT it618_message_images FROM ".DB::table('it618_auction_goods')." WHERE id=".$delid);
			preg_match_all("/<img([^>]*)\s*src=('|\")([^'\"]+)('|\")/",$it618_message_images,$matches);
			$new_arr=$matches[0];
			$new_arr=array_unique($new_arr);
			
			foreach($new_arr as $imgsmall){ 
				$imgsmall=str_replace('"',"",$imgsmall);
				$imgsmall=str_replace('<img alt= src=',"",$imgsmall);
				$imgsmall=str_replace('<img src=',"",$imgsmall);
				$imgbig=str_replace("s_","",$imgsmall);
				
				$tmparr=explode("source",$imgsmall);
				$imgsmall1=DISCUZ_ROOT.'./source'.$tmparr[1];
				if(file_exists($imgsmall1)){
					$result=unlink($imgsmall1);
				}
				
				$tmparr=explode("source",$imgbig);
				$imgbig1=DISCUZ_ROOT.'./source'.$tmparr[1];
				if(file_exists($imgbig1)){
					$result=unlink($imgbig1);
				}
			} 
			
			DB::delete('it618_auction_goods', "id=$delid");
			$del=$del+1;
		}
	}

	cpmsg($it618_auction_lang['s260'].$del, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_auction#it618_auction_goods')->update($id,array(
				'it618_name' => $_GET['it618_name'][$id],
				'it618_yajin' => intval($_GET['it618_yajin'][$id]),
				'it618_score' => intval($_GET['it618_score'][$id]),
				'it618_addprice' => intval($_GET['it618_addprice'][$id]),
				'it618_maxaddprice' => intval($_GET['it618_maxaddprice'][$id]),
				'it618_lpprice' => intval($_GET['it618_lpprice'][$id]),
				'it618_shouxufei' => intval($_GET['it618_shouxufei'][$id]),
				'it618_chujiafei' => intval($_GET['it618_chujiafei'][$id]),
				'it618_freecount' => intval($_GET['it618_freecount'][$id]),
				'it618_xiangoucount' => intval($_GET['it618_xiangoucount'][$id]),
				'it618_flbl' => intval($_GET['it618_flbl'][$id]),
				'it618_ison' => $_GET['it618_ison'][$id],
				'it618_isbm' => $_GET['it618_isbm'][$id],
				'it618_istj' => $_GET['it618_istj'][$id],
				'it618_isaddr' => $_GET['it618_isaddr'][$id],
				'it618_order' => intval($_GET['it618_order'][$id]),
			));
			
			if($_GET['it618_count'][$id]!='-1'){
				C::t('#it618_auction#it618_auction_goods')->update($id,array(
					'it618_count' => intval($_GET['it618_count'][$id])
				));
			}
			$ok=$ok+1;
		}
	}

	cpmsg($it618_auction_lang['s5'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='c')return; /*dism��taobao��com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$delid);
		
		if($it618_auction_goods['it618_checkstate']==1){
			DB::query("update ".DB::table('it618_auction_goods')." set it618_checkstate=3,it618_ison=1 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}
	cpmsg($it618_auction_lang['s447'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='c')return; /*dism��taobao��com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$delid);
		
		if($it618_auction_goods['it618_checkstate']==1){
			DB::query("update ".DB::table('it618_auction_goods')." set it618_checkstate=2 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_auction_lang['s448'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}


$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_class')." where it618_ishide=0 ORDER BY it618_order DESC");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class_id'].'>','<option value='.$_GET['it618_class_id'].' selected="selected">',$tmp);
if(count($reabc)!=13)return; /*Dism��taobao��com*/

echo '
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/kindeditor-min.js"></script>
';

showformheader("plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do");
showtableheaders($it618_auction_lang['s48'],'it618_auction_sum');
	showsubmit('it618sercsubmit', $it618_auction_lang['s9'], $it618_auction_lang['s49'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.$it618_auction_lang['s50'].' <select name="it618_class_id"><option value="0">'.$it618_auction_lang['s51'].'</option>'.$tmp1.'</select> '.$it618_auction_lang['s52'].' <select name="state"><option value=0 '.$state0.'>'.$it618_auction_lang['s53'].'</option><option value=1 '.$state1.'>'.$it618_auction_lang['s54'].'</option><option value=2 '.$state2.'>'.$it618_auction_lang['s55'].'</option><option value=3 '.$state3.'>'.$it618_auction_lang['s56'].'</option><option value=4 '.$state4.'>'.$it618_auction_lang['s57'].'</option><option value=5 '.$state5.'>'.$it618_auction_lang['s58'].'</option><option value=6 '.$state6.'>'.$it618_auction_lang['s59'].'</option><option value=7 '.$state7.'>'.$it618_auction_lang['s60'].'</option><option value=8 '.$state8.'>'.$it618_auction_lang['s61'].'</option></select> '.$it618_auction_lang['s62'].' <select name="orderby"><option value=0 '.$orderby0.'>'.$it618_auction_lang['s63'].'</option><option value=1 '.$orderby1.'>'.$it618_auction_lang['s64'].'</option><option value=2 '.$orderby2.'>'.$it618_auction_lang['s65'].'</option><option value=3 '.$orderby3.'>'.$it618_auction_lang['s66'].'</option><option value=4 '.$orderby4.'>'.$it618_auction_lang['s67'].'</option></select>');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_goods')." g, ".DB::table('it618_auction_class')." c WHERE g.it618_class_id=c.id and c.it618_ishide=0 and g.it618_checkstate<>0 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=16>'.$it618_auction_lang['s68'].$count.'<span style="float:right">'.$it618_auction_lang['s317'].'</span></td></tr>';
	showsubtitle(array('',$it618_auction_lang['s69'],$it618_auction_lang['s449'],$it618_auction_lang['s71'],$it618_auction_lang['s72'].'/'.$it618_auction_lang['s73'],$it618_auction_lang['s76'],$it618_auction_lang['s77'],$it618_auction_lang['s58'],$it618_auction_lang['s79'],$it618_auction_lang['s451'],$it618_auction_lang['s80']));

	$query = DB::query("SELECT g.* FROM ".DB::table('it618_auction_goods')." g, ".DB::table('it618_auction_class')." c WHERE g.it618_class_id=c.id and c.it618_ishide=0 and g.it618_checkstate<>0 $extrasql LIMIT $startlimit, $ppp");
	$n=1;
	while($it618_auction_goods = DB::fetch($query)) {
		
		if($it618_auction_goods['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
		if($it618_auction_goods['it618_istj']==1)$it618_istj_checked='checked="checked"';else $it618_istj_checked="";
		if($it618_auction_goods['it618_isaddr']==1)$it618_isaddr_checked='checked="checked"';else $it618_isaddr_checked="";
		if($it618_auction_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		
		$it618_timetype=$it618_auction_goods['it618_timetype'];
		$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
		$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
		$it618_bhour=explode(":",$it618_auction_goods['it618_bhour']);
		$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
		
		$btime=mktime($it618_bhour[0], $it618_bhour[1], 0, $it618_bdate[1], $it618_bdate[2], $it618_bdate[0]);
		$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0]);
		$flag=0;
		
		if($it618_timetype==1){
			if($etime>=$_G['timestamp']){
				if($btime>$_G['timestamp']){
					$flag=1;
				}else{
					$btimecur=mktime($it618_bhour[0], $it618_bhour[1], 0, date('n'), date('j'), date('Y'));
					$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'));
					if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
						$it618_color='green';
						$readonly='readonly="readonly"';
					}else{
						$flag=1;
					}
				}
				if($flag==1){
					$it618_color='blue';
				}
			}else{
				$it618_color='#ccc';
			}
		}else{
			if($etime>=$_G['timestamp']){
				if($btime>$_G['timestamp']){
					$it618_color='blue';
				}else{
					$it618_color='green';
				}
			}else{
				$it618_color='#ccc';
			}
		}
		
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$it618_auction_goods['id']);
		if($kmcount>0){
			$it618_count=$it618_auction_goods[it618_count].'<input type="hidden" name="it618_count['.$it618_auction_goods[id].']" value="-1"> <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product_km&pmod=admin_product&operation='.$operation.'&do='.$do.'&pid='.$it618_auction_goods[id].'&page='.$page.'"><font color=green>'.$it618_auction_lang['s81'].'</font></a>';
			$it618_isaddr_checked="";
		}else{
			$it618_count='<input type="text" class="txt" style="width:40px;margin-right:1px" name="it618_count['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_count].'"> <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product_km&pmod=admin_product&operation='.$operation.'&do='.$do.'&pid='.$it618_auction_goods[id].'&page='.$page.'">'.$it618_auction_lang['s81'].'</a>';
		}
		if($it618_auction_goods['it618_timetype']==0){
			$tmptime='<font color='.$it618_color.'>'.$it618_auction_lang['s83'].$it618_auction_goods[it618_bdate].' '.$it618_auction_goods[it618_bhour].'<br>'.$it618_auction_lang['s84'].$it618_auction_goods[it618_edate].' '.$it618_auction_goods[it618_ehour].'</font>';
		}else{
			$tmptime=$it618_auction_lang['s85'].$it618_auction_goods[it618_bhour].$it618_auction_lang['s86'].$it618_auction_goods[it618_ehour];
			$tmptime='<font color='.$it618_color.'>'.$it618_auction_lang['s83'].$it618_auction_goods[it618_bdate].'<br>'.$it618_auction_lang['s84'].$it618_auction_goods[it618_edate].'
			 <br>'.$tmptime.'</font>';
		}
		
		if($it618_auction_goods['it618_uid']==0){
			$postuser=$it618_auction_lang['s452'];
			$it618_checkstate='';
		}else{
			$postuser='<a href="home.php?mod=space&uid='.$it618_auction_goods['it618_uid'].'" target="_blank">'.it618_auction_getusername($it618_auction_goods['it618_uid']).'</a>';
			if($it618_auction_goods['it618_checkstate']==1)$it618_checkstate='<font color=red>'.$it618_auction_lang['s453'].'</font>';
			if($it618_auction_goods['it618_checkstate']==2)$it618_checkstate='<font color=blue>'.$it618_auction_lang['s454'].'</font>';
			if($it618_auction_goods['it618_checkstate']==3)$it618_checkstate='<font color=green>'.$it618_auction_lang['s455'].'</font>';
		}
		
		if($it618_auction_goods['it618_type']==1){
			$it618_type='<font color=green><b>'.$it618_auction_lang['s761'].'</b></font> '.$it618_auction_lang['s456'].'<input type="text" class="txt" style="width:47px;color:red" name="it618_score['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_score].'">';
			$it618_flblstr=$it618_auction_lang['s673'];
		}else{
			if($IsCredits==1){
				if($it618_auction_goods['it618_paytype']==1)$paytype=$it618_auction_lang['s830'];else $paytype=$it618_auction_lang['s831'];
			}
			
			$it618_type='<font color=red><b>'.$paytype.$it618_auction_lang['s762'].'</b></font> '.$it618_auction_lang['s456'].'<input type="text" class="txt" style="width:47px;color:red" name="it618_score['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_score].'">'.$it618_auction_lang['s764'].'<input type="text" class="txt" style="width:46px;color:blue" name="it618_yajin['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_yajin].'">';
			$it618_flblstr=$it618_auction_lang['s674'];
		}

		$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." WHERE it618_pid=".$it618_auction_goods['id']);
		$salecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." WHERE it618_state=1 and it618_pid=".$it618_auction_goods['id']);
		$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_auction_goods[id].'" '.$disabled.'><input type="hidden" name="id['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[id].'"><label for="chk_del'.$n.'">'.$it618_auction_goods['id'].'</label>',
			'<div style="width:488px"><a href="'.$tmpurl.'" target="_blank" title="'.$it618_auction_lang['s82'].it618_auction_classname($it618_auction_goods['it618_class_id']).'" style="float:left"><img src="'.$it618_auction_goods['it618_picsmall'].'" width="115" height="80" align="absmiddle"/></a><div style="float:left;margin-left:3px;"><input type="text" class="txt" style="width:321px;margin-bottom:3px" name="it618_name['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_name].'"><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product_edit&pmod=admin_product&operation='.$operation.'&do='.$do.'&pid='.$it618_auction_goods[id].'">'.$it618_auction_lang['s20'].'</a><br>'.$it618_type.'<br>'.$it618_auction_lang['s458'].'<input type="text" class="txt" style="width:35px;margin-right:0" name="it618_addprice['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_addprice].'"> '.$it618_auction_lang['s459'].'<input type="text" class="txt" style="width:46px" name="it618_maxaddprice['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_maxaddprice].'">'.$it618_auction_lang['s457'].'<input type="text" class="txt" style="width:46px" name="it618_lpprice['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_lpprice].'"><br>'.$it618_auction_lang['s672'].'<input type="text" class="txt" style="width:35px;margin-right:0" name="it618_flbl['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_flbl].'">% '.$it618_flblstr.'</div></div>',
			'<div style="width:100px">'.$it618_auction_lang['s460'].'<input type="text" class="txt" style="width:35px" name="it618_shouxufei['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_shouxufei].'"><br>'.$it618_auction_lang['s461'].'<input type="text" class="txt" style="width:35px;margin-right:0" name="it618_chujiafei['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_chujiafei].'"><br>'.$it618_auction_lang['s462'].'<input type="text" class="txt" style="width:35px" name="it618_freecount['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_freecount].'"></div>',
			$tmptime,
			$it618_count.'<br><input type="text" class="txt" style="width:40px" name="it618_xiangoucount['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_xiangoucount].'"><br>'.$it618_auction_lang['s74'].$salecount.'/'.$salecountok.'<br>'.$it618_auction_lang['s75'].$it618_auction_goods[it618_views],
			'<input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_auction_goods['id'].']" '.$it618_isbm_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_addr'.$n.'" name="it618_isaddr['.$it618_auction_goods['id'].']" '.$it618_isaddr_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_auction_goods['id'].']" '.$it618_ison_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_istj'.$n.'" name="it618_istj['.$it618_auction_goods['id'].']" '.$it618_istj_checked.' value="1">',
			$postuser.'<br><br>'.$it618_checkstate,
			'<input type="text" class="txt" style="width:20px" name="it618_order['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_order].'">'
		));
		$n=$n+1;
	}
	
	function it618_auction_classname($aid){
		return DB::result_first("select it618_classname from ".DB::table('it618_auction_class')." where id=".$aid);
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkalla5nm" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkalla5nm">'.$it618_auction_lang['s463'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_auction_lang['s464'].'" onclick="return confirm(\''.$it618_auction_lang['s504'].'\')"/><input type="submit" class="btn" name="it618submit" value="'.$it618_auction_lang['s465'].'" /><input type="submit" class="btn" name="it618submit_pass" value="'.$it618_auction_lang['s466'].'" onclick="return confirm(\''.$it618_auction_lang['s467'].'\')" /><input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_auction_lang['s468'].'" onclick="return confirm(\''.$it618_auction_lang['s469'].'\')" /> &nbsp;<input type="checkbox" id="chk_isbm" class="checkbox" onclick="check_all(this, \'chk_isbm\')" /><label for="chk_isbm">'.$it618_auction_lang['s87'].'</label> <input type="checkbox" id="chk_addr" class="checkbox" onclick="check_all(this, \'chk_addr\')" /><label for="chk_addr">'.$it618_auction_lang['s88'].'</label> <input type="checkbox" id="chk_ison" class="checkbox" onclick="check_all(this, \'chk_ison\')" /><label for="chk_ison">'.$it618_auction_lang['s89'].'</label> <input type="checkbox" id="chk_istj" class="checkbox" onclick="check_all(this, \'chk_istj\')" /><label for="chk_istj">'.$it618_auction_lang['s90'].'</label><br>'.$it618_auction_lang['s470'].'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	
	if(count($reabc)!=13)return; /*Dism��taobao��com*/
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
echo '<script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
?>