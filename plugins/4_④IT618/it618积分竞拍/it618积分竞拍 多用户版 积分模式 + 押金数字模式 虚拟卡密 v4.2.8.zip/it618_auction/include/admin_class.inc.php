<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism-taobao_com*/
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='c')return; /*dism��taobao��com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_auction_class', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_auction#it618_auction_class')->update($id,array(
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
				'it618_ishide' => trim($_GET['it618_ishide'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	$newit618_ishide_array = !empty($_GET['newit618_ishide']) ? $_GET['newit618_ishide'] : array();
	
	foreach($newit618_classname_array as $key => $value) {
		$newit618_classname = trim($newit618_classname_array[$key]);
		
		if($newit618_classname != '') {
			
			C::t('#it618_auction#it618_auction_class')->insert(array(
				'it618_classname' => trim($newit618_classname_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
				'it618_ishide' => trim($newit618_ishide_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_auction_lang['s5'].$ok1.' '.$it618_auction_lang['s6'].$ok2.' '.$it618_auction_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=13)return; /*Dism��taobao��com*/

showformheader("plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do");
showtableheaders($it618_auction_lang['s36'],'it618_auction_class');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_class'));
	
	echo '<tr><td colspan=4>'.$it618_auction_lang['s37'].$count.'</td></tr>';
	showsubtitle(array('', $it618_auction_lang['s38'], $it618_auction_lang['s39'],$it618_auction_lang['s356'],$it618_auction_lang['s40']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_class')." ORDER BY it618_order");
	while($it618_auction =	DB::fetch($query)) {

		$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_goods')." WHERE it618_class_id=".$it618_auction['id']);
		$disabled="";
		if($class2count>0)$disabled="disabled=\"disabled\"";
		if($it618_auction['it618_ishide']==1)$it618_ishide_checked='checked="checked"';else $it618_ishide_checked="";
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_auction[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_auction[id]]\" value=\"$it618_auction[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_classname[$it618_auction[id]]\" value=\"$it618_auction[it618_classname]\">",
			'<input class="txt" type="text" name="it618_order['.$it618_auction['id'].']" value="'.$it618_auction['it618_order'].'">',
			'<input class="checkbox" type="checkbox" name="it618_ishide['.$it618_auction['id'].']" '.$it618_ishide_checked.' value="1">',
			$class2count,
			""
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_auction['id']."');";
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_classname[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_classname[]">'], [1, ' <input class="txt" type="text" name="newit618_order[]" value="1">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="4"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=13)return; /*Dism��taobao��com*/
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
?>