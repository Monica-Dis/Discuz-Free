<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return; /* dism - taobao - com */

loadcache('plugin');
$it618_auction = $_G['cache']['plugin']['it618_auction'];
$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/function/it618_auction.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier']; /* DISM _ TAOBAO _ COM */
$urls = '&pmod=admin_brand&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_identity');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_identity' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*Dism_taobao_com*/
?>