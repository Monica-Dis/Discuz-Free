<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsCredits,$it618_auction;

$it618_auction = $_G['cache']['plugin']['it618_auction'];
$creditname1=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
$creditname2=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';

function timeok($pid){
	global $_G,$it618_auction,$it618_auction_lang,$creditname;
	set_time_limit (0);
	ignore_user_abort(true);
	
	usleep(mt_rand(500,5000));
	
	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_auction_salework')." WHERE it618_pid=".$pid)==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			DB::query("delete from ".DB::table('it618_auction_salework')." where it618_pid=".$pid);
		}
	}
	C::t('#it618_auction#it618_auction_salework')->insert(array(
		'it618_pid' => $pid,
		'it618_iswork' => 1
	), true);
		
	$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	
	if($salecount>0){
		$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE it618_pid=".$pid." and it618_state=0");
		if($it618_auction_sale['it618_etime']<$_G['timestamp']){
			 $it618_auction_sale_price = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_pid=".$pid." and it618_state=0");
			 $it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);
			 
			 if($it618_auction_goods['it618_type']==1){
				 if($it618_auction_goods['it618_lpprice']>$it618_auction_sale_price['it618_score']){
					 C::t('common_member_count')->increase($it618_auction_sale_price['it618_uid'], array(
						  'extcredits'.$it618_auction['auction_credit'] => $it618_auction_sale_price['it618_score'])
					  );
					 $it618_state=3;
					 
				 }else{
					 $kmcount=DB::result_first("select count(1) from ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$pid);
		
					 if($kmcount>0){
						  for($km_n=1;$km_n<=1;$km_n++){
							  $it618_auction_goods_km=DB::fetch_first("select * from ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$pid);
							  $strkm.=$it618_auction_goods_km['it618_code'].",";
							  DB::query("delete from ".DB::table('it618_auction_goods_km')." where id=".$it618_auction_goods_km['id']);
							  
							  $it618_blmoney=intval($it618_auction_sale['it618_bl']*$it618_auction_sale['it618_score']/100);
							  if($it618_blmoney<1)$it618_blmoney=$it618_auction['auction_tcxz'];
							  $money=$it618_auction_sale['it618_score']-$it618_blmoney;
							  C::t('common_member_count')->increase($it618_auction_sale['it618_postuid'], array(
								  'extcredits'.$it618_auction['auction_credit'] => $money)
							  );
						  }
						  $it618_state=4;
						  it618_auction_sendmessage("shouhuo_shop",$it618_auction_sale['id']);
					 }else{
						  $strkm='';
						  $it618_state=1;
					 }
					 DB::query("update ".DB::table('it618_auction_goods')." set it618_salecount=it618_salecount+1 where id=".$pid);
			 		 DB::query("update ".DB::table('it618_auction_goods')." set it618_count=it618_count-1 where it618_count>0 and id=".$pid);

				 }
			 }else{
				 $query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_saleid=".$it618_auction_sale['id']." and it618_uid!=".$it618_auction_sale_price['it618_uid']);
				 while($it618_tmp = DB::fetch($query)) {
					 if($it618_auction_goods['it618_paytype']==1){
						  C::t('common_member_count')->increase($it618_tmp['it618_uid'], array(
							  'extcredits'.$it618_auction['auction_credit_yj'] => $it618_tmp['it618_yajin'])
						  );
					  }else{
					  	  it618_auction_money('tuiyajin1',$it618_auction_sale['id'],$it618_tmp['it618_uid'],$it618_tmp['it618_yajin'],$it618_auction_lang['s836'],1);
					  }
					  
					  $flscore=(intval($it618_tmp['it618_yajin']*$it618_tmp['it618_flbl']/100));
					  if($flscore>0){
						  if($it618_auction_goods['it618_paytype']==1){
							  C::t('common_member_count')->increase($it618_tmp['it618_uid'], array(
								  'extcredits'.$it618_auction['auction_credit_yj'] => $flscore)
							  );
						  }else{
							  it618_auction_money('yajinjl',$it618_auction_sale['id'],$it618_tmp['it618_uid'],$flscore,$it618_auction_lang['s839'],1);
						  }
					  }
					  DB::query("update ".DB::table('it618_auction_sale_price')." set it618_fl=".$flscore." where id=".$it618_tmp['id']);
				 }
				 
				 if($it618_auction_goods['it618_lpprice']>$it618_auction_sale_price['it618_score']){
					 $it618_tmp = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_saleid=".$it618_auction_sale['id']." and it618_uid=".$it618_auction_sale_price['it618_uid']);
					  if($it618_auction_goods['it618_paytype']==1){
						  C::t('common_member_count')->increase($it618_tmp['it618_uid'], array(
							  'extcredits'.$it618_auction['auction_credit_yj'] => $it618_tmp['it618_yajin'])
						  );
					  }else{
					  	  it618_auction_money('tuiyajin2',$it618_auction_sale['id'],$it618_auction_sale_price['it618_uid'],$it618_tmp['it618_yajin'],$it618_auction_lang['s837'],1);
					  }
					  
					  $flscore=(intval($it618_tmp['it618_yajin']*$it618_tmp['it618_flbl']/100));
					  if($flscore>0){
						  if($it618_auction_goods['it618_paytype']==1){
							  C::t('common_member_count')->increase($it618_tmp['it618_uid'], array(
								  'extcredits'.$it618_auction['auction_credit_yj'] => $flscore)
							  );
						  }else{
							  it618_auction_money('yajinjl',$it618_auction_sale['id'],$it618_tmp['it618_uid'],$flscore,$it618_auction_lang['s839'],1);
						  }
					  }
					  DB::query("update ".DB::table('it618_auction_sale_price')." set it618_fl=".$flscore." where id=".$it618_tmp['id']);
					  
					 $it618_state=3;
					 
				 }else{
					$it618_state=10;
				 }
			 }
			 
			 C::t('#it618_auction#it618_auction_sale')->update($it618_auction_sale_price['it618_saleid'],array(
				'it618_score' => $it618_auction_sale_price['it618_score'],
				'it618_blscore' => $it618_blmoney,
				'it618_km' => $strkm,
				'it618_uid' => $it618_auction_sale_price['it618_uid'],
				'it618_time' => $it618_auction_sale_price['it618_time'],
				'it618_state' => $it618_state
			 ));
			 DB::query("update ".DB::table('it618_auction_sale_price')." set it618_state=1 where id=".$it618_auction_sale_price['id']);
			 DB::query("delete from ".DB::table('it618_auction_salework')." where it618_pid=".$pid);
			 
			 if($it618_state==1||$it618_state==10){
				  if($it618_auction_goods['it618_uid']>0){
					  it618_auction_sendmessage("sale_shop",$it618_auction_sale['id']);
				  }
				  
				  if($it618_auction_goods['it618_type']==1){
					  it618_auction_sendmessage("sale_user",$it618_auction_sale['id']);
				  }else{
					  it618_auction_sendmessage("sale_user1",$it618_auction_sale['id']);
				  }
				  
				  it618_auction_sendmessage("sale_admin",$it618_auction_sale['id']);
			 }
		}
	}
	DB::query("delete from ".DB::table('it618_auction_salework')." where it618_pid=".$pid);
}

function it618_auction_getcurprice($it618_auction_goods,$type=1){
	if($type==1)$sql='it618_state=0 and ';else $sql='';
	
	if($it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE $sql it618_pid=".$it618_auction_goods['id']." order by id desc")){
		if($it618_auction_sale_price = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_saleid=".$it618_auction_sale['id']." order by id desc")){
			$it618_score = $it618_auction_sale_price['it618_score'];
		}else{
			$it618_score = $it618_auction_goods['it618_score'];
		}
	}else{
		$it618_score = $it618_auction_goods['it618_score'];
	}
	return $it618_score;
}

function it618_auction_pay($type,$title){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		return;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype();
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		$paystr='<tr id="payselect">
			<td>'.$title.'</td>
			<td>
			'.$tmpstr.'
			</td>
			</tr>';
	}else{
		$paystr=$tmpstr.'<span id="payselect"></span>';
	}
    
	return $paystr;
}

function it618_auction_getumoney($uid,$type=0){
	global $_G,$IsCredits;
	if($IsCredits!=1)return 0;
	if($type==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		set_time_limit (0);
		ignore_user_abort(true);
	
		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
			
		$it618_moneytmp=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uid);
		DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_moneytmp." where it618_uid=".$uid);
		
		it618_credits_delmoneywork();
	}else{
		$it618_moneytmp=DB::result_first("select it618_money from ".DB::table('it618_credits_uset')." where it618_uid=".$uid);	
	}
	
	return $it618_moneytmp;
}

function it618_auction_money($type,$id,$uid,$editmoney,$bz,$moneytype){
	global $_G,$it618_auction,$it618_auction_lang;
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	
	$it618_auction_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE id=".$id);
	$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$it618_auction_sale['it618_pid']);
	
	$it618_bz=str_replace("{money}",'<font color=red>'.round($editmoney,2).'</font>',$bz);
	$it618_bz=str_replace("{saleid}",$id,$it618_bz);
	$it618_bz=str_replace("{pname}",$it618_auction_goods['it618_name'],$it618_bz);
	
	if($moneytype==1){
		savemoney(array(
			'it618_uid' => $uid,
			'it618_type' => 'zy',
			'it618_money1' => $editmoney,
			'it618_bz' => $it618_bz,
			'it618_zytype' => $type,
			'it618_zyid' => $id,
			'it618_time' => $_G['timestamp']
		));
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
	
		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_credits_delmoneywork();
			}
		}
		C::t('#it618_credits#it618_credits_moneywork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$id=savemoney(array(
			'it618_uid' => $uid,
			'it618_type' => 'pay',
			'it618_money2' => $editmoney,
			'it618_bz' => $it618_bz,
			'it618_zftype' => $type,
			'it618_zfid' => $id
		));
		it618_credits_delmoneywork();
	}
	
	$it618_moneytmp=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uid);
	DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_moneytmp." where it618_uid=".$uid);
}

function it618_auction_sendmessage($type,$id,$type1='',$id1=0){
	global $_G,$it618_auction,$it618_auction_lang,$creditname1,$creditname2;
	
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_auction/config/message.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	$tmpurl=it618_auction_getrewrite('auction_wap','','plugin.php?id=it618_auction:wap');
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='rz_admin'&&$it618_body_rz_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_rz_admin;
				
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_rz_admin_tplid_wxsms;
				$body_wxsms=$it618_body_rz_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_auction_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rz_admin_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='rz1_admin'&&$it618_body_rz1_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_rz1_admin;
				
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_rz1_admin_tplid_wxsms;
				$body_wxsms=$it618_body_rz1_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_auction_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rz1_admin_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale_admin;
				
				$it618_auction_sale=DB::fetch_first("select * from ".DB::table('it618_auction_sale')." where id=".$id);
				$it618_auction_goods=DB::fetch_first("select * from ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
				$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_sale['it618_uid']);
				
				if($it618_auction_sale['it618_type']==1){
					$creditnametmp=$creditname1;
				}else{
					$creditnametmp=$it618_auction_lang['s432'];
				}
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_auction_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_auction_sale['it618_score'].$creditnametmp,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_auction_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				$Body=str_replace("{pname}",$it618_auction_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$it618_auction_sale['it618_score'].$creditnametmp,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$it618_auction_goods['it618_name'].'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_auction_sale['it618_score'].$creditnametmp.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='rz_shop'&&$it618_body_rz_shop_isok==1){
			$it618_auction_identity=DB::fetch_first("select * from ".DB::table('it618_auction_identity')." where id=".$id);
			$it618_auction_message=DB::fetch_first("select * from ".DB::table('it618_auction_message')." where it618_uid=".$it618_auction_identity['it618_uid']);
			
			if($it618_auction_message['it618_isok']==1){
				$tel=$it618_auction_message['it618_tel'];
				$Body=$it618_body_rz_shop;
				
				if($type1=='1'){
					if($it618_auction_identity['it618_isok1']==3){
						$state=$it618_auction_lang['s826'];
					}else{
						$state=$it618_auction_lang['s827'];
					}
				}else{
					if($it618_auction_identity['it618_isok2']==3){
						$state=$it618_auction_lang['s826'];
					}else{
						$state=$it618_auction_lang['s827'];
					}
				}
				
				$uid=$it618_auction_identity['it618_uid'];
				$tplid_wxsms=$it618_body_rz_shop_tplid_wxsms;
				$body_wxsms=$it618_body_rz_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{state}",$state,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_auction_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{state}",$state,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rz_shop_tplid;
					
					$tmparr=explode("{state}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$state.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_shop'&&$it618_body_sale_shop_isok==1){
			$it618_auction_sale=DB::fetch_first("select * from ".DB::table('it618_auction_sale')." where id=".$id);
			$it618_auction_message=DB::fetch_first("select * from ".DB::table('it618_auction_message')." where it618_uid=".$it618_auction_sale['it618_postuid']);
			
			if($it618_auction_message['it618_isok']==1){
				$tel=$it618_auction_message['it618_tel'];
				$Body=$it618_body_sale_shop;
				
				$it618_auction_goods=DB::fetch_first("select * from ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
				$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_sale['it618_uid']);
				
				if($it618_auction_sale['it618_type']==1){
					$creditnametmp=$creditname1;
				}else{
					$creditnametmp=$it618_auction_lang['s432'];
				}
				
				$uid=$it618_auction_sale['it618_postuid'];
				$tplid_wxsms=$it618_body_sale_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_auction_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_auction_sale['it618_score'].$creditnametmp,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_auction_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				$Body=str_replace("{pname}",$it618_auction_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$it618_auction_sale['it618_score'].$creditnametmp,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_shop_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$it618_auction_goods['it618_name'].'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_auction_sale['it618_score'].$creditnametmp.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='shouhuo_shop'&&$it618_body_shouhuo_shop_isok==1){
			$it618_auction_sale=DB::fetch_first("select * from ".DB::table('it618_auction_sale')." where id=".$id);
			$it618_auction_message=DB::fetch_first("select * from ".DB::table('it618_auction_message')." where it618_uid=".$it618_auction_sale['it618_postuid']);
			
			if($it618_auction_message['it618_isok']==1){
				$tel=$it618_auction_message['it618_tel'];
				$Body=$it618_body_shouhuo_shop;
				
				$it618_auction_goods=DB::fetch_first("select * from ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
				$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_sale['it618_uid']);
				
				if($it618_auction_sale['it618_type']==1){
					$creditnametmp=$creditname1;
				}else{
					$creditnametmp==$creditname2;
				}
				
				$it618_blmoney=intval($it618_auction_sale['it618_bl']*$it618_auction_sale['it618_score']/100);
				$money=$it618_auction_sale['it618_score']-$it618_blmoney;
				
				$uid=$it618_auction_sale['it618_postuid'];
				$tplid_wxsms=$it618_body_shouhuo_shop_tplid_wxsms;
				$body_wxsms=$it618_body_shouhuo_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{saleid}",$it618_auction_sale['id'],$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_auction_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{money}",$money.$creditnametmp,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_auction_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{saleid}",$it618_auction_sale['id'],$Body);
				$Body=str_replace("{pname}",$it618_auction_goods['it618_name'],$Body);
				$Body=str_replace("{money}",$money.$creditnametmp,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_shouhuo_shop_tplid;
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_auction_sale['id'].'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$it618_auction_goods['it618_name'].'",';
					
					$tmparr=explode("{money}",$ALDYBody);
					if(count($tmparr)>1)$param.='"money":"'.$money.$creditnametmp.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_auction_sale=DB::fetch_first("select * from ".DB::table('it618_auction_sale')." where id=".$id);
			
			if($it618_auction_user=DB::fetch_first("select * from ".DB::table('it618_auction_user')." where it618_msgisok=1 and it618_uid=".$it618_auction_sale['it618_uid'])){
				$tel=$it618_auction_user['it618_tel'];
				$Body=$it618_body_sale_user;
				
				$it618_auction_goods=DB::fetch_first("select * from ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
				$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_sale['it618_uid']);
				
				if($it618_auction_sale['it618_type']==1){
					$creditnametmp=$creditname1;
				}else{
					$creditnametmp=$it618_auction_lang['s432'];
				}
				
				$uid=$it618_auction_sale['it618_uid'];
				$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
				$body_wxsms=$it618_body_sale_user_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_auction_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_auction_sale['it618_score'].$creditnametmp,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_auction_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				$Body=str_replace("{pname}",$it618_auction_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$it618_auction_sale['it618_score'].$creditnametmp,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_user_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$it618_auction_goods['it618_name'].'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_auction_sale['it618_score'].$creditnametmp.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_user1'&&$it618_body_sale_user1_isok==1){
			$it618_auction_sale=DB::fetch_first("select * from ".DB::table('it618_auction_sale')." where id=".$id);
			
			if($it618_auction_user=DB::fetch_first("select * from ".DB::table('it618_auction_user')." where it618_msgisok=1 and it618_uid=".$it618_auction_sale['it618_uid'])){
				$tel=$it618_auction_user['it618_tel'];
				$Body=$it618_body_sale_user1;
				
				$it618_auction_goods=DB::fetch_first("select * from ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
				$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_sale['it618_uid']);
				
				if($it618_auction_sale['it618_type']==1){
					$creditnametmp=$creditname1;
				}else{
					$creditnametmp=$it618_auction_lang['s432'];
				}
				
				$uid=$it618_auction_sale['it618_uid'];
				$tplid_wxsms=$it618_body_sale_user1_tplid_wxsms;
				$body_wxsms=$it618_body_sale_user1_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_auction_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_auction_sale['it618_score'].$creditnametmp,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_auction_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				$Body=str_replace("{pname}",$it618_auction_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$it618_auction_sale['it618_score'].$creditnametmp,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_user1_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$it618_auction_goods['it618_name'].'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_auction_sale['it618_score'].$creditnametmp.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='chujia_user'&&$it618_body_chujia_user_isok==1){
			$it618_auction_sale_price=DB::fetch_first("select * from ".DB::table('it618_auction_sale_price')." where id=".$id);
			
			if($it618_auction_user=DB::fetch_first("select * from ".DB::table('it618_auction_user')." where it618_msgisok=1 and it618_uid=".$id1)){
				$tel=$it618_auction_user['it618_tel'];
				$Body=$it618_body_chujia_user;
				
				$it618_auction_goods=DB::fetch_first("select * from ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale_price['it618_pid']);
				$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$id1);
				
				if($it618_auction_sale_price['it618_type']==1){
					$creditnametmp=$creditname1;
				}else{
					$creditnametmp=$it618_auction_lang['s432'];
				}
				
				$uid=$id1;
				$tplid_wxsms=$it618_body_chujia_user_tplid_wxsms;
				$body_wxsms=$it618_body_chujia_user_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_auction_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_auction_sale_price['it618_score'].$creditnametmp,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_auction_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				$Body=str_replace("{pname}",$it618_auction_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$it618_auction_sale_price['it618_score'].$creditnametmp,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_chujia_user_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$it618_auction_goods['it618_name'].'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_auction_sale_price['it618_score'].$creditnametmp.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_auction/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($Body!=''&&$wxsms!='true'&&$tel!=''){
				$Body=str_replace('$','',$Body);
	
				if($it618_smsbaosign!='')$it618_smsbaosign=it618_auction_getlang('s814').$it618_smsbaosign.it618_auction_getlang('s815');
				if($it618_type=='smsbao'){
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}

function it618_auction_multipage($pagevalue,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_auction']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php')){
		return $pagevalue;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';
	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}


function it618_auction_getrewrite($pagetype,$pagevalue,$url){
	global $_G;
	if($_G['cache']['plugin']['it618_auction']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php';
	
	if($pagetype=='auction_wap'){//auction_wap-{pagetype}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$auction_wap.$auction_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid}-{page}","",$pageurl);
		}else{
			$tmparr=explode("@",$pagevalue);
			$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[2],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='auction_home'){
		return $auction_home.$urltype;
	}
	
	if($pagetype=='auction_product'){//auction_product-{pid}.html
	
		$pageurl=$auction_product.$auction_product1;
		$pageurl=str_replace("{pid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='auction_article'){//auction_article-{pid}.html
	
		$pageurl=$auction_article.$auction_article1;
		$pageurl=str_replace("{aid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='auction_sc'){
		return $auction_sc.$urltype;
	}
	
}

function it618_auction_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_auction_gbktoutf($strcontent);
	}
}

function it618_auction_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_auction_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_auction_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_auction_getusername($uid){
	return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
}

function it618_auction_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_auction_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_auction']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_auction_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_auction_getlang('s192');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_auction_getlang('s193');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_auction_getlang('s194');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_auction_getlang('s195');
		}
	}
	
	return $timestr;
}

function it618_auction_getonlinestate($it618_uid){
	if(TIMESTAMP-DB::result_first("select lastactivity from ".DB::table('common_member_status')." where uid=".$it618_uid)<=10800){
		$tmponlineico='<img src="source/plugin/it618_auction/images/online.gif" align="absmiddle" title="'.it618_auction_getlang('s196').'" />';
	}else{
		$tmponlineico='<img src="source/plugin/it618_auction/images/offline.gif" align="absmiddle" title="'.it618_auction_getlang('s197').'" />';
	}
	
	return $tmponlineico;
}

function it618_auction_getwapppic($aid,$get_it618_picbig,$type=1){
	$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
	$it618_smallurl='source/plugin/it618_auction/kindeditor/data/smallimage/wapad'.$aid.'.'.$file_ext;
	
	if($type==1){
		if(!file_exists($it618_smallurl))$flag=1;
	}else{
		$flag=1;
	}
	if($flag==1) {
			
		$smallpath=DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/data/smallimage/';
		if(!file_exists($smallpath)) {
			mkdir($smallpath);
		}
	
		$tmparr1=explode("://",$get_it618_picbig);
		if(count($tmparr1)>1){
			$it618_url=$get_it618_picbig;
		}else{
			$tmparr=explode("source",$get_it618_picbig);
			$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
		}
		
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/data/smallimage/wapad'.$aid.'.'.$file_ext;
		it618_auction_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,308);
	}
	
	return $it618_smallurl;
}

function it618_auction_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height,$type=1){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function auction_is_mobile(){ 
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: Dism_taobao-com
?>