<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if(count($reabc)!=13)return; /*Dism��taobao��com*/

loadcache('plugin');
$it618_auction = $_G['cache']['plugin']['it618_auction'];

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/function/it618_auction.func.php';

if($reabc[9]!='t')return;
$ppp = $it618_auction['pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier']; /* DISM _ TAOBAO _ COM */
$urls = '&pmod=admin_product&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_product_add', 'admin_product', 'admin_product_edit', 'admin_product_km');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_product' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}
if($cp=='admin_product_edit'||$cp=='admin_product_km')$strtmp[1]='class="current"';

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_product_add'.$urls.'"><span>'.$it618_auction_lang['s3'].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_product'.$urls.'"><span>'.$it618_auction_lang['s4'].'</span></a></li>
</ul></div>';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*Dism_taobao_com*/
?>