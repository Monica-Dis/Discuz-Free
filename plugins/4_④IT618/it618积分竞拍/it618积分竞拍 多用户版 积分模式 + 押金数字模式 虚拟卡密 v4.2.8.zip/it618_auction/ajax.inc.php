<?php
session_start();
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_function.func.php';

$uid = $_G['uid'];
if($_GET['formhash']!=FORMHASH){
	if(!($_GET['ac']=="readpricelist"||$_GET['ac']=="readaddr"))exit;
}

if($uid>0){
	if(!$it618_auction_user=DB::fetch_first("select * from ".DB::table('it618_auction_user')." where it618_uid=$uid")){
		$setarr = array(
			'it618_uid' => $_G['uid'],
			'it618_tel' => '',
			'it618_msgisok' => 1,
		);
		$id = C::t('#it618_auction#it618_auction_user')->insert($setarr, true);
	}
}


if($_GET['ac']=="goods_get"){
	$ppp=$it618_auction['auction_homelistcount'];	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if($_GET['key']!=''){
		$extrasql .= " and it618_name like '%".addcslashes($_GET['key'],'%_')."%'";
	}
	if(intval($_GET['cid'])>0){
		if(intval($_GET['cid'])==9999){
			$extrasql .= " and it618_istj=1";
		}else{
			$extrasql .= " and it618_class_id=".intval($_GET['cid']);
		}
	}
	if(intval($_GET['type'])>0){
		$extrasql .= " and it618_type=".intval($_GET['type']);
	}

	$urlsql='&key='.$_GET['key'].'&cid='.$_GET['cid'].'&type='.$_GET['type'];
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	
	$querytmp = DB::query("SELECT * FROM ".DB::table('it618_auction_goods')." where it618_ison=1 and it618_checkstate=3 $extrasql");

	while($it618_tmp =	DB::fetch($querytmp)) {
		getgoodsorderby($it618_tmp['id']);
		timeok($it618_tmp['id']);
	}

	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_goods')." where it618_ison=1 and it618_checkstate=3 $extrasql order by it618_orderbystate desc,it618_orderbytime, it618_order desc LIMIT $startlimit, $ppp");
	
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;

	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_goods')." where it618_ison=1 and it618_checkstate=3 $extrasql");
	
	if($_GET['wap']==1){
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getgoodslist(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s477').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_auction_getlang('s478').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s478').'</a>';
			}
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}else{
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getgoodslist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getgoodslist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getgoodslist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		$multipage=str_replace('<div class="pg">','<div class="pg"><span style="float:left;font-weight:bold">'.it618_auction_getlang('s205').'<font color=red>'.$count.'</font>'.it618_auction_getlang('s206').'</span> ',$multipage);
	}
	
	while($it618_auction_goods = DB::fetch($query)) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_timetype=$it618_auction_goods['it618_timetype'];
		$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
		$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
		$it618_bhour=explode(":",$it618_auction_goods['it618_bhour']);
		$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
		
		$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$it618_auction_goods['id']);
		if($salecount>0){
			$it618_addtime = DB::result_first("SELECT it618_addtime FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$it618_auction_goods['id']);
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$btime=mktime($it618_bhour[0], $it618_bhour[1], 0, $it618_bdate[1], $it618_bdate[2], $it618_bdate[0]);
		$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0])+$it618_addtime;
		$flag=0;
		if($it618_timetype==1){
			if($etime>=$_G['timestamp']){
				if($btime>$_G['timestamp']){
					$flag=1;
					$btimestr=$it618_auction_goods['it618_bdate'];
				}else{
					$btimecur=mktime($it618_bhour[0], $it618_bhour[1], 0, date('n'), date('j'), date('Y'));
					$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'))+$it618_addtime;
					if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
						$it618_score = it618_auction_getcurprice($it618_auction_goods);
						$it618_score_wap=$it618_score;
						
						if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
						$rtime='<span class="lbl_time">'.it618_auction_getlang('s207').date('Y-m-d', $etimecur).'</span>
								<span class="imod_timer"><span class="h">'.$it618_ehour[0].'</span><span class="split">:</span><span class="m">'.$it618_ehour[1].'</span>
								</span>';
						$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods['id']);
						
						$btn_wap='<font color=#390>'.it618_auction_getlang('s480').'</font>';

						$imod_itemflag='<div class="imod_itemflag itemflag_now">
											<div class="bd1">
												'.it618_auction_getlang('s208').'<span class="n_point">'.$it618_score.'</span>
												<a href="'.$tmpurl.'" class="btn_goods1" target="_blank"><span>'.it618_auction_getlang('s209').'</span></a>
											</div>
										</div>';
					}elseif($btimecur>$_G['timestamp']){
						$flag=1;
						$btimestr=date('Y-m-d', mktime(0, 0, 0, date('n'), date('j'), date('Y')));
					}else{
						$flag=1;
						$btimestr=date('Y-m-d', mktime(0, 0, 0, date('n'), date('j'), date('Y'))+24*60*60);
					}
				}
				if($flag==1){
					$rtime='<span class="lbl_time">'.it618_auction_getlang('s210').$btimestr.'</span>
							<span class="imod_timer"><span class="h">'.$it618_bhour[0].'</span><span class="split">:</span><span class="m">'.$it618_bhour[1].'</span>
							</span>';
					$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods['id']);
					
					$it618_score = it618_auction_getcurprice($it618_auction_goods);
					$it618_score_wap=$it618_auction_goods['it618_score'];
					
					$btn_wap='<font color="#FF6600">'.it618_auction_getlang('s212').'</font>';

					$imod_itemflag='<div class="imod_itemflag itemflag_soon">
										<div class="bd1">
											'.it618_auction_getlang('s211').'<span class="n_point">'.$it618_auction_goods['it618_score'].'</span>
											<a href="'.$tmpurl.'" class="btn_goods1" target="_blank"><span>'.it618_auction_getlang('s212').'</span></a>
										</div>
									</div>';	
				}
			}else{
				$rtime='<span class="lbl_time">'.it618_auction_getlang('s207').$it618_auction_goods['it618_edate'].'</span>
						<span class="imod_timer"><span class="h">'.$it618_ehour[0].'</span><span class="split">:</span><span class="m">'.$it618_ehour[1].'</span>
						</span>';
						
				$it618_score = it618_auction_getcurprice($it618_auction_goods,0);
				$it618_score_wap=$it618_score;
				
				$btn_wap=it618_auction_getlang('s214');

				$imod_itemflag='<div class="imod_itemflag itemflag_back">
									<div class="bd1">
										'.it618_auction_getlang('s644').'<span class="n_point">'.$it618_score.'</span>
										<span class="btn_goods0">'.it618_auction_getlang('s214').'</span>
									</div>
								</div>';
			}
		}else{
			if($etime>=$_G['timestamp']){
				if($btime>$_G['timestamp']){
					$rtime='<span class="lbl_time">'.it618_auction_getlang('s210').$it618_auction_goods['it618_bdate'].'</span>
							<span class="imod_timer"><span class="h">'.$it618_bhour[0].'</span><span class="split">:</span><span class="m">'.$it618_bhour[1].'</span>
							</span>';
					$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods['id']);
					$it618_score_wap=$it618_auction_goods['it618_score'];
					$btn_wap='<font color="#FF6600">'.it618_auction_getlang('s212').'</font>';

					$imod_itemflag='<div class="imod_itemflag itemflag_soon">
										<div class="bd1">
											'.it618_auction_getlang('s211').'<span class="n_point">'.$it618_auction_goods['it618_score'].'</span>
											<a href="'.$tmpurl.'" class="btn_goods1" target="_blank"><span>'.it618_auction_getlang('s212').'</span></a>
										</div>
									</div>';
				}else{
					$it618_score = it618_auction_getcurprice($it618_auction_goods);
					$it618_score_wap=$it618_score;
					
					$rtime='<span class="lbl_time">'.it618_auction_getlang('s207').$it618_auction_goods['it618_edate'].'</span>
							<span class="imod_timer"><span class="h">'.$it618_ehour[0].'</span><span class="split">:</span><span class="m">'.$it618_ehour[1].'</span>
							</span>';
					$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods['id']);

					$btn_wap='<font color=#390>'.it618_auction_getlang('s480').'</font>';

					$imod_itemflag='<div class="imod_itemflag itemflag_now">
										<div class="bd1">
											'.it618_auction_getlang('s208').'<span class="n_point">'.$it618_score.'</span>
											<a href="'.$tmpurl.'" class="btn_goods1" target="_blank"><span>'.it618_auction_getlang('s209').'</span></a>
										</div>
									</div>';
				}
			}else{
				$rtime='<span class="lbl_time">'.it618_auction_getlang('s207').$it618_auction_goods['it618_edate'].'</span>
						<span class="imod_timer"><span class="h">'.$it618_ehour[0].'</span><span class="split">:</span><span class="m">'.$it618_ehour[1].'</span>
						</span>';
				
				$it618_score = it618_auction_getcurprice($it618_auction_goods,0);
				$it618_score_wap=$it618_score;
				$btn_wap=it618_auction_getlang('s214');
				if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
				$imod_itemflag='<div class="imod_itemflag itemflag_back">
									<div class="bd1">
										'.it618_auction_getlang('s644').'<span class="n_point">'.$it618_score.'</span>
										<span class="btn_goods0">'.it618_auction_getlang('s214').'</span>
									</div>
								</div>';
			}
		}
		
		if($it618_auction_goods['it618_type']==1){
			$it618_type='<font color=#390>'.$it618_auction_lang['s761'].'</font>';
			$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
			$it618_yajin_wap='';
			$it618_yajin='';
			$it618_flbl='';$it618_flbl_wap='';
			if($it618_auction_goods['it618_flbl']>0){
				$it618_flbl=$it618_auction_lang['s672'].'<font color="#FF3300">'.$it618_auction_goods['it618_flbl'].'</font> % '.$it618_auction_lang['s673'].$it618_auction_lang['s768'];
				$it618_flbl_wap=$it618_auction_lang['s672'].'<font color="#FF3300">'.$it618_auction_goods['it618_flbl'].'</font> %';
			}
		}else{
			if($IsCredits==1){
				if($it618_auction_goods['it618_paytype']==1)$paytype=$it618_auction_lang['s830'];else $paytype=$it618_auction_lang['s831'];
			}
			$it618_type='<font color=red>'.$paytype.$it618_auction_lang['s762'].'</font>';

			if($it618_auction_goods['it618_paytype']==1){
				$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];
			}else{
				$creditname=$it618_auction_lang['s432'];
			}
			
			$it618_yajin='';$it618_yajin_wap='';
			if($it618_auction_goods['it618_yajin']>0){
				$it618_yajin='<span style="float:right">'.$it618_auction_lang['s764'].'<font color=#000>'.$it618_auction_goods['it618_yajin'].'</font></span>';
				$it618_yajin_wap=' '.$it618_auction_lang['s764'].'<font color=red>'.$it618_auction_goods['it618_yajin'].'</font>'.$creditname.'';
			}
			
			$it618_flbl='';$it618_flbl_wap='';
			if($it618_auction_goods['it618_flbl']>0){
				$it618_flbl=$it618_auction_lang['s672'].'<font color="#FF3300">'.$it618_auction_goods['it618_flbl'].'</font> % '.$it618_auction_lang['s674'].$it618_auction_lang['s768'];
				$it618_flbl_wap=$it618_auction_lang['s672'].'<font color="#FF3300">'.$it618_auction_goods['it618_flbl'].'</font> %';
			}
			$creditname=$it618_auction_lang['s432'];
		}
		
		if($_GET['wap']==1){
			$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
			if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
			$goodslist_get.='<dd  style="border-bottom:#e8e8e8 1px solid"><a href="'.$tmpurl.'" class="react">
							<div class="dealcard">
								<div class="dealcard-img" style="margin-top:-2px"><img src="'.$it618_auction_goods['it618_picsmall'].'" style="border-radius:3px;"/></div>
								<div class="dealcard-block-right">
								<div class="dealcard-auction single-line" style="font-size:14px;">'.$it618_auction_goods['it618_name'].'<span></span></div>
								
								<div class="text-block" style="font-size:11px; color:#999">'.$it618_type.' '.$it618_auction_lang['s456'].''.$it618_auction_goods['it618_score'].''.$creditname.' '.strip_tags($it618_yajin_wap).'<br>'.it618_auction_getlang('s481').$it618_auction_goods['it618_count'].it618_auction_getlang('s482').$it618_auction_goods['it618_views'].' '.it618_auction_getlang('s483').$it618_auction_goods['it618_salecount'].it618_auction_getlang('s484').' '.strip_tags($it618_flbl_wap).'<br>'.strip_tags($rtime).'</div>
		
								<div class="price" style="font-size:11px;padding-top:3px">
									<span style="font-size:14px;color:#F30">'.$it618_score_wap.' </span>'.$creditname.'
									<span class="line-right">'.$btn_wap.'</span>
								</div>
								</div>
							</div>
						</a></dd>';
		}else{
			$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods['id']);
			$goodslist_get.='<li>
						  <div class="imod_item">
							  <div class="figure">
								  <a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_auction_goods['it618_picsmall'].'"/></a>
							  </div>
							  <p class="it618title" title="'.$it618_auction_goods['it618_name'].'">'.$it618_auction_goods['it618_name'].'</p>
							  <p class="it618dec"><span style="float:right">'.$it618_auction_lang['s767'].'<font color=#000>'.$creditname.'</font></span>'.$it618_auction_lang['s760'].$it618_type.'<br>'.$it618_auction_lang['s456'].'<font color=#000>'.$it618_auction_goods['it618_score'].'</font>'.$it618_yajin.'<br>'.$it618_flbl.'</p>
							  <div class="rtime">
								  '.$rtime.'
							  </div>
							  <div class="xtra clearfix">
								  <div class="col_l">'.it618_auction_getlang('s215').'<span>'.$it618_auction_goods['it618_count'].'</span>'.it618_auction_getlang('s216').'</div>
								  <div class="col_r">'.it618_auction_getlang('s217').'<span>'.$it618_auction_goods['it618_views'].'</span></div>
							  </div>
						  </div>
						  '.$imod_itemflag.'
					  </li>';
		}
	}
	if($goodslist_get=='')$goodslist_get=it618_auction_getlang('s218');
	
	echo $goodslist_get."it618_split".$multipage;exit;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d"."z-"."x. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/ri'.'ght.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="goodscontent_get"){
	$pid=intval($_GET['pid']);
	$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')exit;
	
	$it618_timetype=$it618_auction_goods['it618_timetype'];
	$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
	$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
	$it618_bhour=explode(":",$it618_auction_goods['it618_bhour']);
	$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
	
	$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	if($salecount>0){
		$it618_addtime = DB::result_first("SELECT it618_addtime FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
		$it618_saleid = DB::result_first("SELECT id FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	}
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$btime=mktime($it618_bhour[0], $it618_bhour[1], 0, $it618_bdate[1], $it618_bdate[2], $it618_bdate[0]);
	$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0])+$it618_addtime;
	$flag=0;
	
	if($it618_auction_goods['it618_addprice']>0){
		$it618_pricestr='<font color=red>'.$it618_auction_goods['it618_addprice'].'</font> '.it618_auction_getlang('s324').'<input type="hidden" id="it618_addprice" value="'.$it618_auction_goods['it618_addprice'].'"/>';
	}else{
		$it618_pricestr=it618_auction_getlang('s325').'<input type="hidden" id="it618_addprice" value="0"/>';
	}
	
	if($it618_auction_goods['it618_type']==1){
		$creditnametmp=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
	}else{
		$creditnametmp=$it618_auction_lang['s432'];
	}
	
	if($_GET['wap']==1){
		$ifraheight='15px';
	}else{
		$ifraheight='16px';
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
		
	}
	if($it618_timetype==1){
		if($etime>=$_G['timestamp']){
			if($btime>$_G['timestamp']){
				$flag=1;
			}else{
				$it618_auction_sale_pricetmp=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_pricetmp')." WHERE it618_pid=".$pid." and it618_uid=".$uid);
				$btimecur=mktime($it618_bhour[0], $it618_bhour[1], 0, date('n'), date('j'), date('Y'));
				$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'))+$it618_addtime;
				if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
					$timebtn='<dd class="auctiontxt">'.it618_auction_getlang('s219').'<input type="text" id="pricetxt" onkeyup="getcurprice()" value="'.$it618_auction_sale_pricetmp['it618_score'].'"> '.$creditnametmp.' '.$it618_pricestr.'<span id="setprice"></span></dd><dd class="btns1"><a class="jp_mod_btn_pai1" href="javascript:" onclick="sale()">'.it618_auction_getlang('s223').'</a></dd>';
							
				}else{
					$flag=1;
				}
			}
			if($flag==1){
				$timebtn='<dd class="auction">'.$it618_auction['auction_btip'].'</dd><dd class="btns"><span class="jp_mod_btn_pai2">'.it618_auction_getlang('s224').'</span></dd>';
			}
			if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
			$rtime='<iframe width="300px" height="'.$ifraheight.'" marginwidth="0" marginheight="0"  frameborder="no" scrolling="no"  src="plugin.php?id=it618_auction:time&wap='.$_GET['wap'].'&pid='.$pid.'&rand='.date('Y-m-d H:i:s').'" allowTransparency="true"></iframe>';
		}else{
			$rtime=''.it618_auction_getlang('s207').date(it618_auction_getlang('s225'), $etime).' '.$it618_auction_goods['it618_ehour'];
			
			$timebtn='<dd class="auction">'.$it618_auction['auction_etip'].'</dd><dd class="btns"><span class="jp_mod_btn_pai3">'.it618_auction_getlang('s214').'</span></dd>';
		}
	}else{
		if($etime>=$_G['timestamp']){
			$rtime='<iframe width="300px" height="'.$ifraheight.'" marginwidth="0" marginheight="0"  frameborder="no" scrolling="no"  src="plugin.php?id=it618_auction:time&wap='.$_GET['wap'].'&pid='.$pid.'&rand='.date('Y-m-d H:i:s').'" allowTransparency="true"></iframe>';
			if($btime>$_G['timestamp']){
				$timebtn='<dd class="auction">'.$it618_auction['auction_btip'].'</dd><dd class="btns"><span class="jp_mod_btn_pai2">'.it618_auction_getlang('s224').'</span></dd>';
			}else{
				$it618_auction_sale_pricetmp=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_pricetmp')." WHERE it618_pid=".$pid." and it618_uid=".$uid);
				$timebtn='<dd class="auctiontxt">'.it618_auction_getlang('s219').'<input type="text" id="pricetxt" onkeyup="getcurprice()"  value="'.$it618_auction_sale_pricetmp['it618_score'].'"> '.$creditnametmp.' '.$it618_pricestr.'<span id="setprice"></span></dd><dd class="btns1"><a class="jp_mod_btn_pai1" href="javascript:" onclick="sale()">'.it618_auction_getlang('s223').'</a></dd>';
			}
		}else{
			$rtime=''.it618_auction_getlang('s207').date(it618_auction_getlang('s225'), $etime).' '.$it618_auction_goods['it618_ehour'];
			
			$timebtn='<dd class="auction">'.$it618_auction['auction_etip'].'</dd><dd class="btns"><span class="jp_mod_btn_pai3">'.it618_auction_getlang('s214').'</span></dd>';
		}
	}
	
	if($_GET['wap']!=1){
		$tmpstr='<dt>'.$it618_auction_goods['it618_name'].'</dt>';
	}
	
	if($it618_auction_goods['it618_uid']>0){
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_goods['it618_uid']);
		if($_GET['wap']!=1){
			$username=it618_auction_getlang('s637').'<a href="'.it618_auction_rewriteurl($it618_auction_goods['it618_uid']).'" target="_blank" c="1"><font color=#390>'.$username.'</font></a>';	
		}else{
			$username=it618_auction_getlang('s637').'<a href="'.it618_auction_rewriteurl($it618_auction_goods['it618_uid']).'" target="_blank" c="1"><font color=#390>'.$username.'</font></a>';	
		}
		
	}else{
		$username=it618_auction_getlang('s637').$it618_auction_lang['s638'];
	}
	$goodscontent_get='<dl>
						'.$tmpstr.'
						<dd class="username">'.$username.'</dd>
						<dd class="rtime">'.$rtime.'</dd>
						<dd id="userprice"></dd>
						'.$timebtn.'
					   </dl>';

	
	echo $goodscontent_get;
}

function getgoodsorderby($pid){
	global $_G,$it618_auction_lang;
	
	$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);

	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')exit;
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$it618_timetype=$it618_auction_goods['it618_timetype'];
	$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
	$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
	$it618_bhour=explode(":",$it618_auction_goods['it618_bhour']);
	$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
	
	$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	if($salecount>0){
		$it618_addtime = DB::result_first("SELECT it618_addtime FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
		$it618_saleid = DB::result_first("SELECT id FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	}
	
	$btime=mktime($it618_bhour[0], $it618_bhour[1], 0, $it618_bdate[1], $it618_bdate[2], $it618_bdate[0]);
	$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0])+$it618_addtime;
	$flag=0;

	if($it618_timetype==1){
		if($etime>=$_G['timestamp']){
			if($btime>$_G['timestamp']){
				$flag=1;
			}else{
				$btimecur=mktime($it618_bhour[0], $it618_bhour[1], 0, date('n'), date('j'), date('Y'));
				$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'))+$it618_addtime;
				if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
				if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
					C::t('#it618_auction#it618_auction_goods')->update($pid,array(
						'it618_orderbystate' => 2,
						'it618_orderbytime' => ($etimecur-$_G['timestamp'])
					));
							
				}else{
					$flag=1;
				}
			}
			if($flag==1){
				C::t('#it618_auction#it618_auction_goods')->update($pid,array(
					'it618_orderbystate' => 1,
					'it618_orderbytime' => ($btimecur-$_G['timestamp'])
				));
			}
		}else{
			C::t('#it618_auction#it618_auction_goods')->update($pid,array(
				'it618_orderbystate' => 0,
				'it618_orderbytime' => ($_G['timestamp']-$etime)
			));
		}
	}else{
		if($etime>=$_G['timestamp']){
			if($btime>$_G['timestamp']){
				C::t('#it618_auction#it618_auction_goods')->update($pid,array(
					'it618_orderbystate' => 1,
					'it618_orderbytime' => ($btime-$_G['timestamp'])
				));
			}else{
				C::t('#it618_auction#it618_auction_goods')->update($pid,array(
					'it618_orderbystate' => 2,
					'it618_orderbytime' => ($etime-$_G['timestamp'])
				));
			}
		}else{
			C::t('#it618_auction#it618_auction_goods')->update($pid,array(
				'it618_orderbystate' => 0,
				'it618_orderbytime' => ($_G['timestamp']-$etime)
			));
		}
	}
}


if($_GET['ac']=="userprice_get"){
	$pid=intval($_GET['pid']);
	$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')exit;
	
	$it618_timetype=$it618_auction_goods['it618_timetype'];
	$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
	$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
	$it618_bhour=explode(":",$it618_auction_goods['it618_bhour']);
	$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
	
	$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	if($salecount>0){
		$it618_addtime = DB::result_first("SELECT it618_addtime FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	}
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$btime=mktime($it618_bhour[0], $it618_bhour[1], 0, $it618_bdate[1], $it618_bdate[2], $it618_bdate[0]);
	$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0])+$it618_addtime;
	$flag=0;
	
	if($_GET['wap']==1){
		$csstmp=' ';
	}else{
		$csstmp='<br>';
	}
	
	if($it618_auction_goods['it618_type']==1){
		$creditnametmp=' '.$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
	}else{
		$creditnametmp=' '.$it618_auction_lang['s432'];
	}
	
	if($it618_timetype==1){
		if($etime>=$_G['timestamp']){
			if($btime>$_G['timestamp']){
				$flag=1;
			}else{
				$btimecur=mktime($it618_bhour[0], $it618_bhour[1], 0, date('n'), date('j'), date('Y'));
				$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'))+$it618_addtime;
				
				if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
					if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
					$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
					if($count>0){
						$it618_auction_sale_price = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_pid=".$pid." order by id desc");
						$username=it618_auction_getusername($it618_auction_sale_price['it618_uid']);
						$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale_price['it618_pid']);
						if($it618_auction_goods['it618_isbm']==1){
							$username='***';
						}
						$userprice_get=it618_auction_getlang('s227').'<span class="price">'.$it618_auction_sale_price['it618_score'].'</span><input type="hidden" id="curprice" value="'.$it618_auction_sale_price['it618_score'].'">'.$creditnametmp.$csstmp.it618_auction_getlang('s228').'<span class="username">'.$username.'</span>';
					}else{
						$flag=2;
					}
							
				}else{
					$flag=1;
				}
			}
			
		}else{
			$flag=1;
		}
	}else{
		if($etime>=$_G['timestamp']){
			if($btime>$_G['timestamp']){
				$flag=1;
			}else{
				$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
				if($count>0){
					$it618_auction_sale_price = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_pid=".$pid." order by id desc");
					$username=it618_auction_getusername($it618_auction_sale_price['it618_uid']);
					$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale_price['it618_pid']);
					if($it618_auction_goods['it618_isbm']==1){
						$username='***';
					}
					if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
					$userprice_get=it618_auction_getlang('s227').'<span class="price">'.$it618_auction_sale_price['it618_score'].'</span><input type="hidden" id="curprice" value="'.$it618_auction_sale_price['it618_score'].'">'.$creditnametmp.$csstmp.it618_auction_getlang('s228').'<span class="username">'.$username.'</span>';
				}else{
					$flag=2;
				}
			}
		}else{
			$flag=1;
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
		
	}
	
	if($flag==1){
		$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_pid=".$pid);
		if($count>0){
			$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE it618_pid=".$pid." order by id desc");
			if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
			if($it618_auction_goods['it618_lpprice']>$it618_auction_sale['it618_score']){
				$userprice_get=it618_auction_getlang('s229').'<span class="price">'.$it618_auction_sale['it618_score'].'</span>'.$creditnametmp.$csstmp.it618_auction_getlang('s354').'<span class="username">'.it618_auction_getusername($it618_auction_sale['it618_uid']).'</span> '.it618_auction_getlang('s353');
			}else{
				$userprice_get=it618_auction_getlang('s229').'<span class="price">'.$it618_auction_sale['it618_score'].'</span>'.$creditnametmp.$csstmp.it618_auction_getlang('s230').'<span class="username">'.it618_auction_getusername($it618_auction_sale['it618_uid']).'</span>';
			}
		}else{
			$flag=2;
		}
	}
	
	if($flag==2){
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);
					
		$userprice_get=it618_auction_getlang('s227').'<span class="price">'.$it618_auction_goods['it618_score'].'</span><input type="hidden" id="curprice" value="'.$it618_auction_goods['it618_score'].'">'.$creditnametmp.$csstmp.it618_auction_getlang('s231');
	}
	
	$creditnum=DB::result_first("select extcredits".$it618_auction['auction_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	if($creditnum=="")$creditnum=0;

	echo $userprice_get.'it618_split'.$creditnum;exit;
}


if($_GET['ac']=="userpricelist_get"){
	$pid=intval($_GET['pid']);
	
	$ppp = 10;	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')exit;
	
	$it618_timetype=$it618_auction_goods['it618_timetype'];
	$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
	$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
	$it618_bhour=explode(":",$it618_auction_goods['it618_bhour']);
	$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
	
	$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	if($salecount>0){
		$it618_addtime = DB::result_first("SELECT it618_addtime FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	}
		
	$btime=mktime($it618_bhour[0], $it618_bhour[1], 0, $it618_bdate[1], $it618_bdate[2], $it618_bdate[0]);
	$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0])+$it618_addtime;
	$flag=0;
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	if($it618_timetype==1){
		if($etime>=$_G['timestamp']){
			if($btime>$_G['timestamp']){
				$flag=1;
			}else{
				$btimecur=mktime($it618_bhour[0], $it618_bhour[1], 0, date('n'), date('j'), date('Y'));
				$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'))+$it618_addtime;
				
				if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
					$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
					if($count>0){
						$saleid = DB::result_first("SELECT it618_saleid FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
					}else{
						$saleid=0;
					}
										
				}else{
					$flag=1;
				}
			}
			
		}else{
			$flag=1;
		}
	}else{
		if($etime>=$_G['timestamp']){
			if($btime>$_G['timestamp']){
				$flag=1;
			}else{
				$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
				if($count>0){
					$saleid = DB::result_first("SELECT it618_saleid FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
				}else{
					$saleid=0;
				}
			}
			
		}else{
			$flag=1;
		}
	}
	if($flag==1){
		$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_pid=".$pid);
		if($count>0){
			$saleid = DB::result_first("SELECT it618_saleid FROM ".DB::table('it618_auction_sale_price')." where it618_pid=".$pid." order by id desc");
		}else{
			$saleid=0;
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
		
	}
	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$saleid." order by id desc LIMIT $startlimit, $ppp");
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$saleid);
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid);
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getuserpricelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getuserpricelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getuserpricelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	$multipage=str_replace('<div class="pg">','<div class="pricepg"><strong style="float:left;color:#666">'.it618_auction_getlang('s205').' <font color=red>'.$count.'</font> '.it618_auction_getlang('s233').'</strong>',$multipage);
	
	while($it618_auction_sale_price = DB::fetch($query)) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$username=it618_auction_getusername($it618_auction_sale_price['it618_uid']);
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale_price['it618_pid']);
		if($it618_auction_goods['it618_isbm']==1){
			$username='***';
		}
		
		if($it618_auction_sale_price['it618_type']==1){
			$creditnametmp=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
		}else{
			$creditnametmp=$it618_auction_lang['s432'];
		}
		
		$auction_uidfordelprice=explode(",",$it618_auction['auction_uidfordelprice']);
		if(in_array($_G['uid'], $auction_uidfordelprice)&&$flag!=1){
			$strtmpdel='<a href="javascript:" onclick="if(confirm(\''.it618_auction_getlang('s234').'\'))deluserpricelist(\''.$it618_auction_sale_price['id'].'\')" class="a1">'.it618_auction_getlang('s235').'</a>';
		}
	
		$userpricelist_get.='<li>'.date('Y-m-d H:i:s', $it618_auction_sale_price['it618_time']).'  <font color="#333333">'.$username.'</font> '.it618_auction_getlang('s186').' <font color="#FF0000">'.$it618_auction_sale_price['it618_score'].'</font> '.$creditnametmp.' '.$strtmpdel.'</li>';
	}
	
	if($count>$ppp){
		$userpricelist_get.='<li class="lipg">'.$multipage.'</li>';
	}
	
	echo $userpricelist_get;exit;
}


if($_GET['ac']=="readpricelist"){
	$saleid=intval($_GET['saleid']);
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$ppp = 10;	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$saleid." order by id desc LIMIT $startlimit, $ppp");
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$saleid);
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_auction:ajax&saleid=".$saleid);
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='readpricelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='readpricelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','readpricelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	$multipage=str_replace('<div class="pg">','<div class="pricepg"><strong style="float:left;color:#666">'.it618_auction_getlang('s205').' <font color=red>'.$count.'</font> '.it618_auction_getlang('s233').'</strong>',$multipage);
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	while($it618_auction_sale_price = DB::fetch($query)) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$username=it618_auction_getusername($it618_auction_sale_price['it618_uid']);
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale_price['it618_pid']);
		if($it618_auction_goods['it618_isbm']==1){
			$username='***';
		}
		
		if($it618_auction_sale_price['it618_type']==1){
			$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
			$creditnametmp=$creditname;
		}else{
			if($it618_auction_goods['it618_paytype']==1){
				$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];
			}else{
				$creditname=$it618_auction_lang['s432'];
			}
			
			$creditnametmp=$it618_auction_lang['s432'];
		}
		
		$it618_bz='';
		$it618_yajin=$it618_auction_sale_price['it618_yajin'];
		$it618_shouxufei=$it618_auction_sale_price['it618_shouxufei'];
		$it618_chujiafei=$it618_auction_sale_price['it618_chujiafei'];
		
		if($it618_yajin>0)$it618_bz.=$it618_auction_lang['s764'].'<font color=red>'.$it618_yajin.'</font>'.$creditname.' ';
		if($it618_shouxufei>0)$it618_bz.=$it618_auction_lang['s307'].'<font color=red>'.$it618_shouxufei.'</font>'.$creditname.' ';
		if($it618_chujiafei>0)$it618_bz.=$it618_auction_lang['s308'].'<font color=red>'.$it618_chujiafei.'</font>'.$creditname.' ';
		
		if($it618_bz!=''){
			$it618_bz.='@';
			$it618_bz=str_replace(" @","",$it618_bz);
			$it618_bz='('.$it618_bz.')';
		}
	
		$readpricelist.='<li><font color=#999>'.date('Y-m-d H:i:s', $it618_auction_sale_price['it618_time']).'</font> <font color="#333333">'.$username.'</font> '.it618_auction_getlang('s186').' <font color="#FF0000">'.$it618_auction_sale_price['it618_score'].'</font> '.$creditnametmp.' <span class="it618_bz">'.$it618_bz.'</span></li>';
	}
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	if($count>$ppp){
		$readpricelist.='<li class="lipg" style="list-style:none">'.$multipage.'</li>';
	}
	
	echo $readpricelist;exit;
}


if($_GET['ac']=="userdeallist_get"){
	$pid=intval($_GET['pid']);
	
	$ppp = 10;	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale')." where it618_state!=0 and it618_state!=3 and it618_pid=".$pid." order by id desc LIMIT $startlimit, $ppp");
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state!=0 and it618_state!=3 and it618_pid=".$pid);
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid);
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getuserdeallist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getuserdeallist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getuserdeallist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	$multipage=str_replace('<div class="pg">','<div class="pricepg"><strong style="float:left;color:#666">'.it618_auction_getlang('s205').' <font color=red>'.$count.'</font> '.it618_auction_getlang('s232').'</strong>',$multipage);
	
	while($it618_auction_sale = DB::fetch($query)) {
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$username=it618_auction_getusername($it618_auction_sale['it618_uid']);
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
		if($it618_auction_goods['it618_isbm']==1){
			$username='***';
		}
		$tmpscore=$it618_auction_sale['it618_score']/$it618_auction_goods['it618_score'];
		if($tmpscore>=intval($tmpscore)){
			$tmpscore=intval($tmpscore);
		}else{
			$tmpscore=intval($tmpscore)-1;
		}
		
		if($it618_auction_sale['it618_type']==1){
			$creditnametmp=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
		}else{
			$creditnametmp=$it618_auction_lang['s432'];
		}
		
		if($tmpscore>1)$tmpscore=it618_auction_getlang('s188').' <font color="red">'.$tmpscore.'</font> '.it618_auction_getlang('s189');else $tmpscore='';
		$userdeallist_get.='<li>'.date('Y-m-d', $it618_auction_sale['it618_time']).'  <font color="#333333">'.$username.'</font> '.$tmpscore.it618_auction_getlang('s190').' <font color="red">'.$it618_auction_sale['it618_score'].'</font> '.$creditnametmp.' '.it618_auction_getlang('s191').' <a href="javascript:" onclick="showWindow(\'it618_showpricelist\',\''.$_G['siteurl'].'plugin.php?id=it618_auction:showpricelist\');setTimeout(\'readpricelist1('.$it618_auction_sale['id'].');\',800);" class="a1" title="'.it618_auction_getlang('s236').'"><font color=blue>'.it618_auction_getlang('s237').'</font></a></li>';
	}
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	if($count>$ppp){
		$userdeallist_get.='<li class="lipg">'.$multipage.'</li>';
	}
	
	echo $userdeallist_get;exit;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d"."z-"."x. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/ri'.'ght.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="userpricelist_del"){
	if($uid<=0){
		echo it618_auction_getlang('s238');
	}else{
		$auction_uidfordelprice=explode(",",$it618_auction['auction_uidfordelprice']);
		if(!in_array($_G['uid'], $auction_uidfordelprice)){
			echo it618_auction_getlang('s239');
		}else{
			$it618_priceid=intval($_GET['it618_priceid']);
			
			if($it618_auction_sale_price=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." where id=".$it618_priceid)){
				if($it618_auction_sale_price['it618_type']==1){
					$creditindex=$it618_auction['auction_credit'];
					$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
				}else{
					$creditindex=$it618_auction['auction_credit_yj'];
					$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];
				}
				if($it618_auction_sale_price['it618_state']==0){
					
					if($it618_auction_sale_price['it618_type']==1){
						C::t('common_member_count')->increase($it618_auction_sale_price['it618_uid'], array(
							'extcredits'.$creditindex => $it618_auction_sale_price['it618_score'])
						);
						
						DB::query("delete from ".DB::table('it618_auction_sale_price')." where id=".$it618_priceid);
						if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
						if($it618_auction_sale_price1=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale_price['it618_saleid']." order by id desc")){
							C::t('common_member_count')->increase($it618_auction_sale_price1['it618_uid'], array(
								'extcredits'.$creditindex => (0-$it618_auction_sale_price1['it618_score']))
							);
							DB::query("update ".DB::table('it618_auction_sale_price')." set it618_state=0 where id=".$it618_auction_sale_price1['id']);
						}
						
						echo 'okit618_split'.it618_auction_getlang('s240').' <font color=red>'.$it618_auction_sale_price['it618_score'].'</font> '.$creditname.it618_auction_getlang('s241').' <font color=red>'.$it618_auction_sale_price1['it618_score'].'</font> '.it618_auction_getlang('s242').''.$creditname.')!';
					}else{
						if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
						if($it618_auction_sale_price1=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale_price['it618_saleid']." order by id desc")){
							DB::query("update ".DB::table('it618_auction_sale_price')." set it618_state=0 where id=".$it618_auction_sale_price1['id']);
						}
						if($it618_auction_sale_price['it618_yajin']>0){
							C::t('common_member_count')->increase($it618_auction_sale_price['it618_uid'], array(
								'extcredits'.$creditindex => $it618_auction_sale_price['it618_yajin'])
							);
						}
						echo 'okit618_split'.it618_auction_getlang('s697');
						DB::query("delete from ".DB::table('it618_auction_sale_price')." where id=".$it618_priceid);
					}
				}else{
					if($it618_auction_sale_price['it618_yajin']>0){
						C::t('common_member_count')->increase($it618_auction_sale_price['it618_uid'], array(
							'extcredits'.$creditindex => $it618_auction_sale_price['it618_yajin'])
						);
					}
					echo 'okit618_split'.it618_auction_getlang('s243');
					DB::query("delete from ".DB::table('it618_auction_sale_price')." where id=".$it618_priceid);
				}
			}
		}
	}
	exit;
}


if($_GET['ac']=="pl_add"){
	if(strtolower($_GET['validatecode']) != strtolower($_SESSION['validatecode'])){
		echo 'errorvalidatecode';
	}else{
		if($uid<=0){
			echo it618_auction_getlang('s238');
		}else{
			if($it618_auction['auction_ispl']!=2){
				echo it618_auction_getlang('s244');
			}else{
				$it618_pid=intval($_GET['it618_pid']);
				$id = C::t('#it618_auction#it618_auction_pl')->insert(array(
					'it618_pid' => $it618_pid,
					'it618_uid' => $uid,
					'it618_quoteid' => $_GET['it618_quoteid'],
					'it618_content' => it618_auction_utftogbk($_GET['it618_content']),
					'it618_time' => $_G['timestamp']
				), true);
				
				if($id>0){
					echo it618_auction_getlang('s245');
				}else{
					echo it618_auction_getlang('s246');
				}
			}
		}
	}
	exit;
}


if($_GET['ac']=="pl_del"){
	if($uid<=0){
		echo it618_auction_getlang('s238');
	}else{
		$auction_uidfordel=explode(",",$it618_auction['auction_uidfordel']);
		if(!in_array($_G['uid'], $auction_uidfordel)){
			echo it618_auction_getlang('s247');
		}else{
			$it618_lid=intval($_GET['it618_lid']);
			DB::query("delete from ".DB::table('it618_auction_pl')." where id=".$it618_lid);
		}
	}
	exit;
}


if($_GET['ac']=="pl_get"){
	$it618_pid=intval($_GET['it618_pid']);
	$ppp = $it618_auction['auction_pageplcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_pl')." where it618_pid=".$it618_pid." order by id desc LIMIT $startlimit, $ppp");
	$n=$startlimit+1;
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_pl')." where it618_pid=".$it618_pid);
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_auction:ajax&it618_pid=".$it618_pid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getpllist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getpllist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getpllist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		$multipage=str_replace('<div class="pg">','<div class="pg"><span style="float:left;font-weight:bold">'.it618_auction_getlang('s205').'<font color=red>'.$count.'</font>'.it618_auction_getlang('s248').'</span> ',$multipage);
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&it618_pid=$it618_pid&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getpllist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s477').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&it618_pid=$it618_pid&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_auction_getlang('s478').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&it618_pid=$it618_pid&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&it618_pid=$it618_pid&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&it618_pid=$it618_pid&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s478').'</a>';
			}
			$multipage=it618_auction_getlang('s205').'<font color=red>'.$count.'</font>'.it618_auction_getlang('s248').$strtmply.' '.$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	while($it618_auction_pl = DB::fetch($query)) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$username=it618_auction_getusername($it618_auction_pl['it618_uid']);
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$auction_uidfordel=explode(",",$it618_auction['auction_uidfordel']);
		if(in_array($_G['uid'], $auction_uidfordel)&&$_G['uid']>0){
			$strtmpdel='<a href="javascript:" onclick="if(confirm(\''.it618_auction_getlang('s249').'\'))delpl(\''.$it618_auction_pl['id'].'\')" class="a1">'.it618_auction_getlang('s235').'</a>';
		}
		
		if($_GET['wap']==0){
			$pllist_get.='<div class="booklist">
								<div class="fl pla1"><a href="'.it618_auction_rewriteurl($it618_auction_pl['it618_uid']).'" target="_blank"><img src="'.it618_auction_discuz_uc_avatar($it618_auction_pl['it618_uid'],'small').'" alt="'.it618_auction_getlang('s250').''.$username.''.it618_auction_getlang('s251').'" width="50" height="50" /></a></div>
								<div class="fl pla2"><div class="plb1"><a href="'.it618_auction_rewriteurl($it618_auction_pl['it618_uid']).'" target="_blank" title="'.it618_auction_getlang('s250').''.$username.''.it618_auction_getlang('s250').'" class="pla1">'.$username.'</a><font color=#999999>('.$it618_auction_pl['it618_uid'].')</font> '.it618_auction_getonlinestate($it618_auction_pl['it618_uid']).' '.$strtmpdel.' <font color=#666666>'.it618_auction_getlang('s252').'</font></div>
								<div class="plb2">'.getquote($it618_auction_pl['it618_quoteid']).str_replace('[br]','<br>',$it618_auction_pl['it618_content']).'</div>
								<div class="plb3"><span class="pla1">'.it618_auction_getlang('s253').($count-$n+1).it618_auction_getlang('s254').' </span><font color="gray">'.date('Y-m-d H:i:s', $it618_auction_pl['it618_time']).'</font>&nbsp; <a href="javascript:" onclick="scroller(book_post,1000);bookquote(\''.($count-$n+1).'\',\''.$it618_auction_pl['id'].'\')" class="pla1">'.it618_auction_getlang('s255').'</a></div>
								</div>
							</div>';
		}else{
			$pllist_get.='<div class="booklist" id="mr'.$it618_auction_pl['id'].'">
							<a href="'.it618_auction_rewriteurl($it618_auction_pl['it618_uid']).'" target="_blank" title="'.it618_auction_getlang('s250').$username.it618_auction_getlang('s250').'" class="a1">'.$username.'</a><font color=#999999>('.$it618_auction_pl['it618_uid'].')</font> '.it618_auction_getonlinestate($it618_auction_pl['it618_uid']).' '.$strtmpdel.' <font color=#666666>'.it618_auction_getlang('s252').'</font><br>
							'.getquote($it618_auction_pl['it618_quoteid']).str_replace('[br]','<br>',$it618_auction_pl['it618_content']).'<br>
							'.it618_auction_getlang('s253').($count-$n+1).it618_auction_getlang('s254').' <font color="gray">'.date('Y-m-d H:i:s', $it618_auction_pl['it618_time']).'</font>&nbsp; <a href="javascript:" onclick="bookquote(\''.($count-$n+1).'\',\''.$it618_auction_pl['id'].'\')" class="a1">'.it618_auction_getlang('s255').'</a>
						</div>';
		}
		$n=$n+1;
	}
	
	echo $pllist_get."it618_split".$multipage;exit;
}

function getquote($quoteid){
	$query = DB::query("select * from ".DB::table('it618_auction_pl')." where id=".$quoteid);
	if($it618_auction_pl = DB::fetch($query)){
		return '<div class="quote"><span>'.it618_auction_getlang('s256').'<a href="'.it618_auction_rewriteurl($it618_auction_pl['it618_uid']).'" target="_blank" class="a1">'.it618_auction_getusername($it618_auction_pl['it618_uid']).'</a> ('.date('Y-m-d H:i:s', $it618_auction_pl['it618_time']).')</span>'.getquote($it618_auction_pl['it618_quoteid']).'<br />'.str_replace('[br]','<br>',$it618_auction_pl['it618_content']).'</div>';
	}
}


if($_GET['ac']=="saleaddr"){
	
	$uid = $_G['uid'];
	$saleid=intval($_GET['saleid']);
	
	$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE id=".$saleid);
	if($it618_auction_sale['it618_uid']!=$uid||$it618_auction_sale['it618_state']!=1){
		echo it618_auction_getlang('s1066');
	}else{
		$it618_addr.=$_GET['it618_name'].'@@@';
		$it618_addr.=$_GET['it618_tel'].'@@@';
		$it618_addr.=$_GET['it618_qq'].'@@@';
		$it618_addr.=$_GET['it618_addr'].'@@@';
		$it618_addr.=$_GET['it618_bz'].'@@@';
		
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$id = C::t('#it618_auction#it618_auction_sale')->update($saleid,array(
			'it618_addr' => it618_auction_utftogbk($it618_addr)
		));
		
		echo it618_auction_getlang('s257');
	}
	exit;
}


if($_GET['ac']=="shouhuo"){
	
	$uid = $_G['uid'];
	$saleid=intval($_GET['saleid']);
	
	$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE id=".$saleid);
	if($it618_auction_sale['it618_uid']!=$uid||$it618_auction_sale['it618_state']!=2){
		echo it618_auction_getlang('s1066');
	}else{
		
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$id = C::t('#it618_auction#it618_auction_sale')->update($saleid,array(
			'it618_state' => 4
		));
		
		it618_auction_sendmessage("shouhuo_shop",$it618_auction_sale['id']);
		
		if($it618_auction_sale['it618_postuid']>0){
			$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$it618_auction_sale['it618_pid']);
			
			$it618_blmoney=intval($it618_auction_sale['it618_bl']*$it618_auction_sale['it618_score']/100);
			if($it618_blmoney<1)$it618_blmoney=$it618_auction['auction_tcxz'];
			$money=$it618_auction_sale['it618_score']-$it618_blmoney;
			if($it618_auction_sale['it618_type']==1){
				C::t('common_member_count')->increase($it618_auction_sale['it618_postuid'], array(
					'extcredits'.$it618_auction['auction_credit'] => $money)
				);
			}else{
				if($it618_auction_goods['it618_paytype']==2){
					it618_auction_money('shopmoney',$it618_auction_sale['id'],$it618_auction_sale['it618_postuid'],$money,$it618_auction_lang['s843'],1);
				}
			}
			
			C::t('#it618_auction#it618_auction_sale')->update($delid,array(
				'it618_blscore' => $it618_blmoney
			 ));
		}
		
		echo it618_auction_getlang('s258');
	}
	exit;
}


if($_GET['ac']=="readaddr"){
	
	$uid = $_G['uid'];
	$saleid=intval($_GET['saleid']);
	$auction_adminuid=explode(",",$it618_auction['auction_adminuid']);
	
	$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE id=".$saleid);
	if($it618_auction_sale['it618_postuid']!=$uid){
		if(!in_array($uid,$auction_adminuid)){
			echo it618_auction_getlang('s1066');exit;
		}
	}
	
	$tmparr=explode("@@@",$it618_auction_sale['it618_addr']);
	if(count($tmparr)==1){
		$it618_bz=$it618_auction_sale['it618_addr'];
	}else{
		$it618_name=$tmparr[0];
		$it618_tel=$tmparr[1];
		$it618_qq=$tmparr[2];
		$it618_addr=$tmparr[3];
		$it618_bz=$tmparr[4];
	}
	
	echo '<tr><td width=68>'.it618_auction_getlang('s271').'</td><td><input type="text" class="txt" style="width:98%;font-size:14px" id="it618_name" value="'.$it618_name.'"></td></tr>
		  <tr><td>'.it618_auction_getlang('s273').'</td><td><input type="text" class="txt" style="width:98%;font-size:14px" id="it618_tel" value="'.$it618_tel.'"></td></tr>
		  <tr><td>'.it618_auction_getlang('s274').'</td><td><input type="text" class="txt" style="width:98%;font-size:14px" id="it618_qq" value="'.$it618_qq.'"></td></tr>
		  <tr><td>'.it618_auction_getlang('s272').'</td><td><input type="text" class="txt" style="width:98%;font-size:12px" id="it618_addr" value="'.$it618_addr.'"></td></tr>
		  <tr><td>'.it618_auction_getlang('s276').'</td><td><textarea class="txt" style="width:99%;height:80px;font-size:13px" id="it618_bz">'.$it618_bz.'</textarea></td></tr>';
		  
	exit;
}


if($_GET['ac']=="sale_add"){
	if($uid<=0){
		echo 'sale1it618_split'.it618_auction_getlang('s279');
	}else{
		if($it618_auction['auction_isbdtel']==1){
			if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_members'")>0){
				$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$uid);
				if($count==0){
					echo 'bdit618_split'.$it618_auction_lang['s1039'];exit;
				}else{
					$it618_tel=DB::result_first("SELECT it618_tel FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$uid);
					if($it618_auction_user=DB::fetch_first("select * from ".DB::table('it618_auction_user')." where it618_uid=$uid")){
						$setarr = array(
							'it618_tel' => $it618_tel,
							'it618_msgisok' => 1,
						);
						$id = C::t('#it618_auction#it618_auction_user')->update($it618_auction_user['id'],$setarr);
					}else{
						$setarr = array(
							'it618_uid' => $uid,
							'it618_tel' => $it618_tel,
							'it618_msgisok' => 1,
						);
						$id = C::t('#it618_auction#it618_auction_user')->insert($setarr, true);
					}
				}
			}
		}
		
		set_time_limit (0);
		ignore_user_abort(true);
		
		$pid=intval($_GET['pid']);
		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_auction_salework')." WHERE it618_pid=".$pid)==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				delsalework($pid);
			}
		}
		C::t('#it618_auction#it618_auction_salework')->insert(array(
			'it618_pid' => $pid,
			'it618_iswork' => 1
		), true);
		
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$it618_price=intval($_GET['it618_price']);
		$curprice=intval($_GET['curprice']);
		$pricetxt=intval($_GET['pricetxt']);
		
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);
		$it618_addprice=$it618_auction_goods['it618_addprice'];
		
		if($it618_auction_goods['it618_type']==1){
			$creditindex=$it618_auction['auction_credit'];
			$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
			if($it618_auction_goods['it618_uid']>0){
				$it618_bl=DB::result_first("select it618_bl from ".DB::table('it618_auction_identity')." where it618_uid=".$it618_auction_goods['it618_uid']);
			}
		}else{
			$creditindex=$it618_auction['auction_credit_yj'];
			$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];
			if($it618_auction_goods['it618_uid']>0){
				$it618_bl=DB::result_first("select it618_bl_yj from ".DB::table('it618_auction_identity')." where it618_uid=".$it618_auction_goods['it618_uid']);
			}
		}
		
		if($it618_auction['auction_usersale']==1){
			if($it618_auction_goods['it618_uid']==$_G['uid']){
				echo 'sale2it618_split'.$it618_auction_lang['s277'];delsalework($pid);exit;
			}
		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
			
		}
		$auction_groups=(array)unserialize($it618_auction['auction_groups']);
		if($it618_auction_goods['it618_auctionpower']!=''){
			$gp_arr=explode(",",$it618_auction_goods['it618_auctionpower']);
			if(!in_array($_G['groupid'], $gp_arr)){
				echo 'sale2it618_split'.it618_auction_getlang('s645');delsalework($pid);exit;
			}
		}else{
			if(!in_array($_G['groupid'], $auction_groups)){
				echo 'sale2it618_split'.it618_auction_getlang('s645');delsalework($pid);exit;
			}
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		if($it618_auction['auction_addprice']==0){
			$it618_auction_sale_price = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_state=0 and it618_pid=".$pid." order by id desc");
			if($it618_auction_sale_price['it618_uid']==$_G['uid']){
				echo 'sale2it618_split'.it618_auction_getlang('s351');delsalework($pid);exit;
			}
		}
		
		if($pricetxt<=0){
			echo 'sale2it618_split'.it618_auction_getlang('s280');delsalework($pid);exit;
		}else{
			if($it618_addprice!=0){
				if($pricetxt%$it618_addprice!=0){
					echo 'sale2it618_split'.it618_auction_getlang('s327').' <font color=red>'.$it618_addprice.'</font> '.it618_auction_getlang('s352');delsalework($pid);exit;
				}
			}
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		if($pricetxt>$it618_auction_goods['it618_maxaddprice']&&$it618_auction_goods['it618_maxaddprice']>0){
			echo 'sale2it618_split'.it618_auction_getlang('s350').' <font color=red>'.$it618_auction_goods['it618_maxaddprice'].'</font> !';delsalework($pid);exit;
		}
		
		$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
	
		if($salecount==0){
			$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);
			
			$it618_timetype=$it618_auction_goods['it618_timetype'];
			$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
			$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
			if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
			if($it618_timetype==1){
				$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'));
				if($etimecur<$_G['timestamp']){
					echo'sale3it618_split'.it618_auction_getlang('s281');delsalework($pid);exit;
				}
			}else{
				$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0]);
				if($etime<$_G['timestamp']){
					echo'sale3it618_split'.it618_auction_getlang('s281');delsalework($pid);exit;
				}
			}
		}

		$it618_auction_sale_price = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_state=0 and it618_pid=".$pid." order by id desc");
		if($it618_auction_sale_price['it618_score']>$curprice){
			echo'sale0it618_split'.it618_auction_getlang('s282').$curprice.it618_auction_getlang('s283');delsalework($pid);exit;
		}
	
		$it618_count=1;
		$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$pid);
		$buycount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_pid=".$pid." and it618_state!=0 and it618_uid=".$uid);
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_auction_goods['it618_count']<$it618_count){
			echo 'sale0it618_split'.it618_auction_getlang('s284');delsalework($pid);exit;
		}elseif($it618_auction_goods['it618_xiangoucount']>0&&$it618_count>$it618_auction_goods['it618_xiangoucount']-$buycount){
			echo 'sale0it618_split'.it618_auction_getlang('s285').$it618_auction_goods['it618_xiangoucount'].it618_auction_getlang('s286').$buycount.it618_auction_getlang('s287');delsalework($pid);exit;
		}else{
			
			$creditnum=DB::result_first("select extcredits".$creditindex." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
			if($creditnum=="")$creditnum=0;
			
			$it618_chujiafei=0;$it618_yajin=0;
			$saleid = DB::result_first("SELECT id FROM ".DB::table('it618_auction_sale')." WHERE it618_pid=".$pid." and it618_state=0");
			if($saleid>0){
				$cjcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." WHERE it618_uid=".$uid." and it618_saleid=".$saleid);
				if($cjcount==0){
					$it618_shouxufei=$it618_auction_goods['it618_shouxufei'];
					$it618_yajin=$it618_auction_goods['it618_yajin'];
				}
				$cjcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." WHERE it618_uid=".$uid." and it618_chujiafei=0 and it618_saleid=".$saleid);
				if($cjcount>=$it618_auction_goods['it618_freecount']){
					$it618_chujiafei=$it618_auction_goods['it618_chujiafei'];
				}
			}else{
				$it618_shouxufei=$it618_auction_goods['it618_shouxufei'];
				if($it618_auction_goods['it618_freecount']==0){
					$it618_chujiafei=$it618_auction_goods['it618_chujiafei'];
				}
				$it618_yajin=$it618_auction_goods['it618_yajin'];
			}
			
			if($it618_auction_goods['it618_type']==1){
				if($creditnum<$it618_count*$it618_price+$it618_shouxufei+$it618_chujiafei){
					$it618_auction_lang294=it618_auction_getlang('s294');
					$it618_auction_lang294=str_replace("{it618_shouxufei}","<font color=red>".$it618_shouxufei."</font> <font color=#390>".$creditname."</font>",$it618_auction_lang294);
					$it618_auction_lang294=str_replace("{it618_chujiafei}","<font color=red>".$it618_chujiafei."</font> <font color=#390>".$creditname."</font>",$it618_auction_lang294);
					echo "sale22it618_split<font color=#000>".it618_auction_getlang('s291')." <font color=#390>".$creditname."</font> ".it618_auction_getlang('s292')." <font color=red>".$creditnum."</font> ".it618_auction_getlang('s293')." <font color=red>".($it618_count*$it618_price)."</font> ".$it618_auction_lang294." <font color=#390>".$creditname."</font> ".it618_auction_getlang('s295')."</font>";delsalework($pid);exit;
				}
			}else{
				if($it618_auction_goods['it618_paytype']==1){
					if($creditnum<$it618_yajin+$it618_shouxufei+$it618_chujiafei){
						$it618_auction_lang694=it618_auction_getlang('s694');
						$it618_auction_lang694=str_replace("{it618_yajin}","<font color=red>".$it618_yajin."</font> <font color=#390>".$creditname."</font>",$it618_auction_lang694);
						$it618_auction_lang694=str_replace("{it618_shouxufei}","<font color=red>".$it618_shouxufei."</font> <font color=#390>".$creditname."</font>",$it618_auction_lang694);
						$it618_auction_lang694=str_replace("{it618_chujiafei}","<font color=red>".$it618_chujiafei."</font> <font color=#390>".$creditname."</font>",$it618_auction_lang694);
						echo "sale22it618_split<font color=#000>".it618_auction_getlang('s691')." <font color=#390>".$creditname."</font> ".it618_auction_getlang('s692')." <font color=red>".$creditnum."</font> ".it618_auction_getlang('s693').$it618_auction_lang694." <font color=#390>".$creditname."</font> ".it618_auction_getlang('s695')."</font>";delsalework($pid);exit;
					}
				}else{
					if($creditnum<$it618_shouxufei+$it618_chujiafei){
						$it618_auction_lang694=it618_auction_getlang('s678');
						$it618_auction_lang694=str_replace("{it618_shouxufei}","<font color=red>".$it618_shouxufei."</font> <font color=#390>".$creditname."</font>",$it618_auction_lang694);
						$it618_auction_lang694=str_replace("{it618_chujiafei}","<font color=red>".$it618_chujiafei."</font> <font color=#390>".$creditname."</font>",$it618_auction_lang694);
						echo "sale22it618_split<font color=#000>".it618_auction_getlang('s691')." <font color=#390>".$creditname."</font> ".it618_auction_getlang('s692')." <font color=red>".$creditnum."</font> ".it618_auction_getlang('s693').$it618_auction_lang694." <font color=#390>".$creditname."</font> ".it618_auction_getlang('s695')."</font>";delsalework($pid);exit;
					}
					
					$umoney=it618_auction_getumoney($uid,1);
					if($it618_yajin>$umoney){
						$tmpstr=it618_auction_getlang('s833');
						$tmpstr=str_replace("{money}",$umoney,$tmpstr);
						$tmpstr=str_replace("{yajin}",$it618_yajin,$tmpstr);
						$tmpstr=str_replace("{czmoney}",($it618_yajin-$umoney),$tmpstr);
						
						echo "saleyajinit618_split".$tmpstr;delsalework($pid);exit;
					}
				}
			}
			
			if($ii1i11i[9]!='t')exit;
			if($salecount==0){
				
				$it618_timetype=$it618_auction_goods['it618_timetype'];
				$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
				$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
				if($it618_timetype==1){
					$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'));
				}else{
					$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0]);
				}
				if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
				$saleid = C::t('#it618_auction#it618_auction_sale')->insert(array(
					'it618_uid' => $uid,
					'it618_postuid' => $it618_auction_goods['it618_uid'],
					'it618_type' => $it618_auction_goods['it618_type'],
					'it618_pid' => intval($_GET['pid']),
					'it618_bscore' => $it618_auction_goods['it618_score'],
					'it618_score' => $it618_price,
					'it618_state' => 0,
					'it618_bl' => $it618_bl,
					'it618_etime' => $etimecur,
					'it618_time' => $_G['timestamp']
				), true);
			}else{
				$saleid = DB::result_first("SELECT id FROM ".DB::table('it618_auction_sale')." WHERE it618_pid=".$pid." and it618_state=0");
				C::t('#it618_auction#it618_auction_sale')->update($saleid,array(
					'it618_uid' => $uid,
					'it618_score' => $it618_price,
					'it618_time' => $_G['timestamp']
				));
			}
			
			$id = C::t('#it618_auction#it618_auction_sale_price')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => intval($_GET['pid']),
				'it618_type' => $it618_auction_goods['it618_type'],
				'it618_saleid' => $saleid,
				'it618_score' => $it618_price,
				'it618_yajin' => $it618_yajin,
				'it618_shouxufei' => $it618_shouxufei,
				'it618_chujiafei' => $it618_chujiafei,
				'it618_flbl' => $it618_auction_goods['it618_flbl'],
				'it618_addr' => '',
				'it618_state' => 0,
				'it618_time' => $_G['timestamp']
			), true);
			if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
			if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_pricetmp')." WHERE it618_pid=".$pid." and it618_uid=".$uid)==0){
				C::t('#it618_auction#it618_auction_sale_pricetmp')->insert(array(
					'it618_uid' => $uid,
					'it618_pid' => $pid,
					'it618_score' => $pricetxt,
					'it618_time' => $_G['timestamp']
				), true);
			}else{
				$tmpid=DB::result_first("SELECT id FROM ".DB::table('it618_auction_sale_pricetmp')." WHERE it618_pid=".$pid." and it618_uid=".$uid);
				C::t('#it618_auction#it618_auction_sale_pricetmp')->update($tmpid,array(
					'it618_score' => $pricetxt,
					'it618_time' => $_G['timestamp']
				));
			}
			if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
			if($id>0){
				if($it618_auction_goods['it618_type']==1){
					C::t('common_member_count')->increase($_G['uid'], array(
						'extcredits'.$creditindex => (0-$it618_count*$it618_price))
					);
					C::t('common_member_count')->increase($_G['uid'], array(
						'extcredits'.$creditindex => (0-($it618_shouxufei+$it618_chujiafei)))
					);
					
					$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
					if($ii1i11i[3]!='1')exit;
					if($it618_auction_sale_price=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." where it618_pid=".$pid." and it618_state=0 and id<>".$id)){
						C::t('common_member_count')->increase($it618_auction_sale_price['it618_uid'], array(
							'extcredits'.$it618_auction['auction_credit'] => $it618_auction_sale_price['it618_score'])
						);
						$flscore=(intval($it618_auction_sale_price['it618_score']*$it618_auction_sale_price['it618_flbl']/100));
						C::t('common_member_count')->increase($it618_auction_sale_price['it618_uid'], array(
							'extcredits'.$it618_auction['auction_credit'] => $flscore)
						);
						DB::query("update ".DB::table('it618_auction_sale_price')." set it618_state=1,it618_fl=".$flscore." where id=".$it618_auction_sale_price['id']);
						
						if($it618_auction_sale_price['it618_uid']!=$_G['uid']){
							it618_auction_sendmessage("chujia_user",$id,'',$it618_auction_sale_price['it618_uid']);
						}
					}
				}else{
					if($it618_yajin>0){
						if($it618_auction_goods['it618_paytype']==1){
							C::t('common_member_count')->increase($_G['uid'], array(
								'extcredits'.$creditindex => (0-($it618_yajin)))
							);
						}else{
							it618_auction_money('payyajin',$saleid,$uid,$it618_yajin,$it618_auction_lang['s835'],2);
						}
					}
					C::t('common_member_count')->increase($_G['uid'], array(
						'extcredits'.$creditindex => (0-($it618_shouxufei+$it618_chujiafei)))
					);
					
					if($it618_auction_sale_price=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." where it618_pid=".$pid." and it618_state=0 and id<>".$id)){
						DB::query("update ".DB::table('it618_auction_sale_price')." set it618_state=1 where id=".$it618_auction_sale_price['id']);
						if($it618_auction_sale_price['it618_uid']!=$_G['uid']){
							it618_auction_sendmessage("chujia_user",$id,'',$it618_auction_sale_price['it618_uid']);
						}
					}
				}
				
				$kmcount=DB::result_first("select count(1) from ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$pid);
				if($kmcount==0){
					if($it618_auction_goods['it618_type']==1){
						echo "okit618_split".it618_auction_getlang('s289');delsalework($pid);
					}else{
						echo "okit618_split".it618_auction_getlang('s431');delsalework($pid);
					}
				}else{
					if($it618_auction_goods['it618_type']==1){
						echo "okit618_split".it618_auction_getlang('s288');delsalework($pid);
					}else{
						echo "okit618_split".it618_auction_getlang('s430');delsalework($pid);
					}
				}
				
				$saleid = DB::result_first("SELECT it618_saleid FROM ".DB::table('it618_auction_sale_price')." WHERE it618_pid=".$pid." and it618_state=0");
				$it618_etime = DB::result_first("SELECT it618_etime FROM ".DB::table('it618_auction_sale')." WHERE id=".$saleid);
				if($it618_etime-$_G['timestamp']<=$it618_auction['auction_addwhytime']&&$it618_auction['auction_addwhytime']>0){
					DB::query("update ".DB::table('it618_auction_sale')." set it618_etime=it618_etime+".$it618_auction['auction_addtime'].",it618_addtime=it618_addtime+".$it618_auction['auction_addtime']." where id=".$saleid);
				}
				
			}else{
				echo 'sale0it618_split'.it618_auction_getlang('s290');delsalework($pid);exit;
			}

		}
	}
	exit;
}

function delsalework($pid){
	DB::query("delete from ".DB::table('it618_auction_salework')." where it618_pid=".$pid);
}


if($_GET['ac']=="timeok"){
	$pid=intval($_GET['pid']);
	timeok($pid);
	exit;
}


if($_GET['ac']=="myprice_get"){
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$allcount=DB::result_first("select count(1) from ".DB::table('it618_auction_sale_price')." WHERE it618_uid=".$_G['uid']);
	
	if($_GET['wap']!=1){
		$ppp = 30;
	}else{
		$ppp = 15;
	}
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_uid=".$_G['uid']);

	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_uid=".$_G['uid']." order by id desc LIMIT $startlimit, $ppp");
	$n=1;
	while($it618_auction_sale_price = DB::fetch($query)) {
		
		$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale_price['it618_pid']);
		$it618_auction_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." where id=".$it618_auction_sale_price['it618_saleid']);
		
		if($it618_auction_sale_price['it618_type']==1){
			$creditnametmp=$creditname1;
			$creditname=$creditname1;
		}else{
			$creditnametmp=$it618_auction_lang['s432'];
			$creditname=$creditname2;
		}
		
		$flstr='';
		if($it618_auction_sale_price['it618_type']==1){
			if($it618_auction_sale_price['it618_fl']>0)$flstr=' <font color=#390>'.it618_auction_getlang('s663').$it618_auction_sale_price['it618_fl'].' '.$creditname.'</font>';
			if($it618_auction_sale['it618_uid']==$_G['uid']&&$it618_auction_sale['it618_state']>0&&$it618_auction_sale['it618_score']==$it618_auction_sale_price['it618_score']){
				if($it618_auction_goods['it618_lpprice']>$it618_auction_sale['it618_score']){
					$saletmpstr=' <font color=blue>'.it618_auction_getlang('s355').'</font>'.it618_auction_getlang('s664').$flstr;
				}else{
					$saletmpstr=' <font color=#390>'.it618_auction_getlang('s646').'</font>';
				}
			}else{
				$saletmpstr=' '.it618_auction_getlang('s664').$flstr;
			}
		}else{
			if($it618_auction_sale_price['it618_fl']>0)$flstr=' '.$it618_auction_lang['s696'].' <font color=#390>'.it618_auction_getlang('s663').$it618_auction_sale_price['it618_fl'].' '.$creditname.'</font>';
			if($it618_auction_sale['it618_uid']==$_G['uid']&&$it618_auction_sale['it618_state']>0&&$it618_auction_sale['it618_score']==$it618_auction_sale_price['it618_score']){
				if($it618_auction_goods['it618_lpprice']>$it618_auction_sale['it618_score']){
					$saletmpstr=' <font color=blue>'.it618_auction_getlang('s355').'</font>'.$flstr;
				}else{
					$saletmpstr=' <font color=#390>'.it618_auction_getlang('s646').'</font>'.$flstr;
				}
			}else{
				$saletmpstr=$flstr;
			}
		}
		
		$it618_bz='';
		$it618_yajin=$it618_auction_sale_price['it618_yajin'];
		$it618_shouxufei=$it618_auction_sale_price['it618_shouxufei'];
		$it618_chujiafei=$it618_auction_sale_price['it618_chujiafei'];
		
		if($it618_yajin>0)$it618_bz.=$it618_auction_lang['s764'].'<font color=red>'.$it618_yajin.'</font>'.$creditnametmp.' ';
		if($it618_shouxufei>0)$it618_bz.=$it618_auction_lang['s307'].'<font color=red>'.$it618_shouxufei.'</font>'.$creditname.' ';
		if($it618_chujiafei>0)$it618_bz.=$it618_auction_lang['s308'].'<font color=red>'.$it618_chujiafei.'</font>'.$creditname.' ';
		if($it618_bz!=''){
			$it618_bz.='@';
			$it618_bz=str_replace(" @","",$it618_bz);
		}
		
		if($_GET['wap']!=1){
			$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_sale_price['it618_pid'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_sale_price['it618_pid']);
			$myprice_get.='<li><span>'.date('Y-m-d H:i:s', $it618_auction_sale_price['it618_time']).'</span> '.it618_auction_getlang('s186').' <font color="#FF0000">'.$it618_auction_sale_price['it618_score'].'</font> '.$creditnametmp.' '.it618_auction_getlang('s187').' <a href="'.$tmpurl.'" title="'.$it618_auction_goods['it618_name'].'" target="_blank">'.cutstr($it618_auction_goods['it618_name'], 50, '...').'</a> <span class="it618_bz">'.$it618_bz.'<font color=red>'.$saletmpstr.'</font></span></li>';
		}else{
			$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_sale_price['it618_pid'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_sale_price['it618_pid']);
			
			$myprice_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;font-size:13px;line-height:15px">
							<a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_auction_goods['it618_picsmall'].'" style="float:left;margin-right:6px;border-radius:3px" width="90" height="63"/></a>
							<div class="dealcard-auction single-line" style="font-size:12px"><a href="'.$tmpurl.'" target="_blank"><font color="#333">'.$it618_auction_goods['it618_name'].'</font></a></div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;font-size:11px"> '.it618_auction_getlang('s186').' <font color="#FF0000">'.$it618_auction_sale_price['it618_score'].'</font> '.$creditnametmp.'<br><span class="it618_bz">'.$it618_bz.'<font color=red>'.$saletmpstr.'</font></span><br><font color=#999>'.date('Y-m-d H:i:s', $it618_auction_sale_price['it618_time']).'</font></div>

						</div>
					</dd>';
		}
		
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	}
	
	$pricecount1 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale_price')." where it618_type=1 and it618_uid=".$_G['uid']);
	$pricecount2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale_price')." where it618_type=2 and it618_uid=".$_G['uid']);
	
	$it618_shouxufei1 = DB::result_first("SELECT sum(it618_shouxufei) FROM ".DB::table('it618_auction_sale_price')." where it618_type=1 and it618_uid=".$_G['uid']);
	$it618_shouxufei2 = DB::result_first("SELECT sum(it618_shouxufei) FROM ".DB::table('it618_auction_sale_price')." where it618_type=2 and it618_uid=".$_G['uid']);
	
	$it618_chujiafei1 = DB::result_first("SELECT sum(it618_chujiafei) FROM ".DB::table('it618_auction_sale_price')." where it618_type=1 and it618_uid=".$_G['uid']);
	$it618_chujiafei2 = DB::result_first("SELECT sum(it618_chujiafei) FROM ".DB::table('it618_auction_sale_price')." where it618_type=2 and it618_uid=".$_G['uid']);
	
	$it618_fl1 = DB::result_first("SELECT sum(it618_fl) FROM ".DB::table('it618_auction_sale_price')." where it618_type=1 and it618_uid=".$_G['uid']);
	$it618_fl2 = DB::result_first("SELECT sum(it618_fl) FROM ".DB::table('it618_auction_sale_price')." where it618_type=2 and it618_uid=".$_G['uid']);
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_auction:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getmyauction(this.name,\"myprice_get\")' name=",$multipage);
		$multipage=str_replace("onclick='getmyauction(this.name,\"myprice_get\")' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getmyauction(',$multipage);
		$multipage=str_replace('; doane(event);',',\"myprice_get\"); doane(event);',$multipage);
		
		$myprice_get='<div class="auctionmenu">
							<a class="it618_menu it618_curmenu" href="javascript:" onclick="getmyauction(\''.$_G['siteurl'].'plugin.php?id=it618_auction:ajax&page=1\',\'myprice_get\');">'.it618_auction_getlang('s296').'</a>
							<a class="it618_menu" href="javascript:" onclick="getmyauction(\''.$_G['siteurl'].'plugin.php?id=it618_auction:ajax&page=1\',\'mydeal_get\');">'.it618_auction_getlang('s297').'</a>
						</div>
						<div class="auctioncon">
						<div style="float:left; margin-top:10px;border:#e8e8e8 1px solid; padding:6px;color:#888">'.it618_auction_getlang('s318').'<font color=red>'.$pricecount1.'</font><font color=#aaa>/</font><font color=red>'.$pricecount2.'</font> '.it618_auction_getlang('s319').'<font color=red>'.$it618_shouxufei1.'</font>'.$creditname1.'<font color=#aaa>/</font><font color=red>'.$it618_shouxufei2.'</font>'.$creditname2.' '.it618_auction_getlang('s320').'<font color=red>'.$it618_chujiafei1.'</font>'.$creditname1.'<font color=#aaa>/</font><font color=red>'.$it618_chujiafei2.'</font>'.$creditname2.' '.it618_auction_getlang('s665').'<font color=red>'.$it618_fl1.'</font>'.$creditname1.'<font color=#aaa>/</font><font color=red>'.$it618_fl2.'</font>'.$creditname2.'<br><div style="background-color:#f9f9f9;color:#888;padding:10px 4px;margin-top:6px">'.it618_auction_getlang('s321').it618_auction_getlang('s666').'</div><ul class="priceul">
						   '.$myprice_get.'
						</ul></div></div>';
		
		if($count>$ppp){
			$myprice_get.='<div style="float:right;margin-top:10px">'.$multipage.'</div>';
		}
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getmyauction(this.value,\'myprice_get\')">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s477').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getmyauction(\''.$tmpurl.'\',\'myprice_get\')">'.it618_auction_getlang('s478').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_auction_getlang('s478').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getmyauction(\''.$tmpurl.'\',\'myprice_get\')">'.it618_auction_getlang('s477').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getmyauction(\''.$tmpurl.'\',\'myprice_get\')">'.it618_auction_getlang('s478').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getmyauction(\''.$tmpurl.'\',\'myprice_get\')">'.it618_auction_getlang('s477').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s478').'</a>';
			}
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		
		$myprice_get='<div class="mysalediv">'.it618_auction_getlang('s318').'<font color=red>'.$pricecount1.'</font><font color=#aaa>/</font><font color=red>'.$pricecount2.'</font> '.it618_auction_getlang('s319').'<font color=red>'.$it618_shouxufei1.'</font>'.$creditname1.'<font color=#aaa>/</font><font color=red>'.$it618_shouxufei2.'</font>'.$creditname2.'<br>'.it618_auction_getlang('s320').'<font color=red>'.$it618_chujiafei1.'</font>'.$creditname1.'<font color=#aaa>/</font><font color=red>'.$it618_chujiafei2.'</font>'.$creditname2.' '.it618_auction_getlang('s665').'<font color=red>'.$it618_fl1.'</font>'.$creditname1.'<font color=#aaa>/</font><font color=red>'.$it618_fl2.'</font>'.$creditname2.'</div><div class="mysaledivabout">'.it618_auction_getlang('s321').it618_auction_getlang('s666').'</div><table class="priceul" width="100%">
						   '.$myprice_get.'<tr><td style="text-align:center;border:none;padding-top:10px">'.$multipage.'</td></tr>
						</table>';
	}
	echo $myprice_get;exit;
}


if($_GET['ac']=="mydeal_get"){
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$allcount1=DB::result_first("select count(1) from ".DB::table('it618_auction_sale')." WHERE it618_state<>0 and it618_state<>3 and it618_uid=".$_G['uid']);
	$allsum1=DB::result_first("select sum(it618_score) from ".DB::table('it618_auction_sale')." WHERE it618_state<>0 and it618_state<>3 and it618_uid=".$_G['uid']);
	
	$ppp = 10;	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state<>0 and it618_state<>3 and it618_uid=".$_G['uid']);

	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE it618_state<>0 and it618_state<>3 and it618_uid=".$_G['uid']." order by id desc LIMIT $startlimit, $ppp");
	$n=1;
	while($it618_auction_sale = DB::fetch($query)) {

		$straddr='<li class="info addr" style="line-height:17px">'.$straddr.'</li>';
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		if($it618_auction_sale['it618_state']==10)$it618_state='<font color=#F0F>'.it618_auction_getlang('s698').'</font>';
		if($it618_auction_sale['it618_state']==1){
			$it618_state='<font color=red>'.$it618_auction_lang['s157'].'</font>';
		  
			if($it618_auction_sale['it618_addr']==''){
				$it618_state.=' <font color=blue>'.$it618_auction_lang['s797'].'</font>';
			}else{
				$it618_state.=' <font color=#390>'.$it618_auction_lang['s798'].'</font>';
			}
		}
		if($it618_auction_sale['it618_state']==2){
			$it618_state='<font color=#390>'.it618_auction_getlang('s158').'</font>';
			
			if($it618_auction_sale['it618_kddan']==''){
				$it618_state.=' <font color=blue>'.$it618_auction_lang['s799'].'</font>';
			}
		}
		if($it618_auction_sale['it618_state']==4)$it618_state='<font color=#390>'.it618_auction_getlang('s397').'</font>';
		
		if($it618_auction_sale['it618_type']==1){
			$creditnametmp=$creditname1;
			$it618_type='<font color=#390>'.$it618_auction_lang['s761'].'</font>';
		}else{
			$creditnametmp=$it618_auction_lang['s432'];
			if($IsCredits==1){
				if($it618_auction_goods['it618_paytype']==1)$paytype=$it618_auction_lang['s830'];else $paytype=$it618_auction_lang['s831'];
			}
			$it618_type='<font color=red>'.$paytype.$it618_auction_lang['s762'].'</font>';
		}
		
		$n=$n+1;
		$ili1ll=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ili1ll[]=substr($_GET['id'],$i,1);}
		$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
		if($ili1ll[5]!='_')exit;
		
		$it618_btn='';
		if($it618_auction_sale['it618_state']==10){
			if($_GET['wap']!=1){
				 if($it618_auction_goods['it618_paytype']==1){
					 $it618_btn='<span style="float:right;"><a href="javascript:" onclick="showWindow(\'it618_showpay\',\''.$_G['siteurl'].'plugin.php?id=it618_auction:showpay\');" class="it618_btn">'.$it618_auction_lang['s770'].'</a></span>';
				 }else{
						$it618_btn='<span style="float:right;"><a href="javascript:" onclick="showWindow(\'it618_showpay\',\''.$_G['siteurl'].'plugin.php?id=it618_auction:showpay&saleid='.$it618_auction_sale['id'].'\');" class="it618_btn">'.$it618_auction_lang['s770'].'</a></span>'; 
				 }
			}else{
				if($it618_auction_goods['it618_paytype']==1){
					$it618_btn='<span style="float:right;"><a href="javascript:" onclick="showpay(0);" class="it618_btn">'.$it618_auction_lang['s770'].'</a></span>';
				}else{
					$it618_btn='<span style="float:right;"><a href="javascript:" onclick="showpay('.$it618_auction_sale['id'].');" class="it618_btn">'.$it618_auction_lang['s770'].'</a></span>';
				}
			}
		}
		
		if($it618_auction_sale['it618_state']==1){
			if($it618_auction_sale['it618_km']==''){
				if($it618_auction_sale['it618_addr']=='')$tmpbtn=it618_auction_getlang('s300');else $tmpbtn=it618_auction_getlang('s299');
			}
			
			
			if($_GET['wap']!=1){
				$it618_btn='<span style="float:right;"><a href="javascript:" onclick="showWindow(\'it618_showaddr\',\''.$_G['siteurl'].'plugin.php?id=it618_auction:showaddr&saleid='.$it618_auction_sale['id'].'\');" class="it618_btn">'.$tmpbtn.'</a></span>';
			}else{
				$it618_btn='<span style="float:right;"><a href="javascript:" onclick="showaddr('.$it618_auction_sale['id'].');" class="it618_btn">'.$tmpbtn.'</a></span>';
			}
		}
		
		if($it618_auction_sale['it618_state']==2){
			if($it618_auction_sale['it618_kddan']!=''){
				$it618_btn='<span style="float:right;"><a href="javascript:" onclick="shouhuo('.$it618_auction_sale['id'].')" class="it618_btn it618_btn1">'.it618_auction_getlang('s488').'</a></span>';
			}
		}
		
		if($_GET['wap']==1&&$it618_btn!=''){
			$it618_btn.='<br>';
		}

		if($it618_auction_sale['it618_kdid']!=0&&$it618_auction_sale['it618_kddan']!=''){
			$it618_auction_kd=DB::fetch_first("select * from ".DB::table('it618_auction_kd')." WHERE id=".$it618_auction_sale['it618_kdid']);
			if($_GET['wap']!=1){
				$it618_btn1='<a href="javascript:" onclick="showWindow(\'it618_showaddr\',\''.$_G['siteurl'].'plugin.php?id=it618_auction:showaddr&saleid='.$it618_auction_sale['id'].'\');">'.it618_auction_getlang('s298').'</a>';
			}else{
				$it618_btn1='<a href="javascript:" onclick="showaddr('.$it618_auction_sale['id'].');">'.it618_auction_getlang('s298').'</a>';
			}
			
			$strkd='<br>'.$it618_btn1.' '.it618_auction_getlang('s171').'<a href="'.$it618_auction_kd['it618_url'].'" target="_blank"><font color=#390>'.$it618_auction_kd['it618_name'].'</font></a> '.it618_auction_getlang('s172').'<font color=#390>'.$it618_auction_sale['it618_kddan'].'</font>';
		}else{
			$strkd='';
		}
		
		if($it618_auction_sale['it618_km']!=''){
			if($_GET['wap']!=1){
				$it618_btn1='<a href="javascript:" style="float:right" onclick="showWindow(\'it618_showkm\',\''.$_G['siteurl'].'plugin.php?id=it618_auction:showkm&saleid='.$it618_auction_sale['id'].'\');">'.it618_auction_getlang('s301').'</a>';
			}else{
				$it618_btn1='<a href="javascript:" onclick="showkm('.$it618_auction_sale['id'].');">'.it618_auction_getlang('s301').'</a>';
			}
			$strkd=' '.$it618_btn1;
		}
		
		if($_GET['wap']==1&&$strkd!=''){
			$strkd.='<br>';
		}
		
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		if($it618_auction_goods['it618_uid']>0){
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_goods['it618_uid']);
			$username=$it618_auction_lang['s637'].'<a href="'.it618_auction_rewriteurl($it618_auction_goods['it618_uid']).'" target="_blank" c="1"><font color=#666>'.$username.'</font></a>';	
		}else{
			$username=$it618_auction_lang['s637'].$it618_auction_lang['s638'];	
		}
		
		if($_GET['wap']!=1){
			$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_sale['it618_pid'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_sale['it618_pid']);
			$mydeal_get.='
					 <ul class="dealul">
					 <li class="img"><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_auction_goods['it618_picsmall'].'" width="100" height="68" /></a></li>
					 <li class="info"><span class="name"><a href="'.$tmpurl.'" title="'.$it618_auction_goods['it618_name'].'" target="_blank">'.$it618_auction_goods['it618_name'].'</a></span></li>
					 <li class="info" style="height:32px;line-height:17px">'.$it618_btn.$it618_type.' '.it618_auction_getlang('s305').'<span class="count">'.$it618_auction_sale['id'].'</span> '.it618_auction_getlang('s303').'<span class="count">'.$it618_auction_sale['it618_score'].'</span>'.$creditnametmp.$strkd.'</li>
					 <li class="info">'.$username.' <font color=#999>'.date('Y-m-d H:i:s', $it618_auction_sale['it618_time']).'</font> <span style="float:right">'.it618_auction_getlang('s306').$it618_state.'</span></li>
					 </ul>';
		}else{
			$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_sale['it618_pid'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_sale['it618_pid']);
			if($strkd=='')$strkd='<br><br>';	
			$mydeal_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;font-size:12px;line-height:14px">
							<a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_auction_goods['it618_picsmall'].'" style="float:left;margin-right:6px;border-radius:3px" width="90" height="63"/></a>
							<div class="dealcard-auction single-line" style="font-size:12px"><a href="'.$tmpurl.'" target="_blank"><font color="#333">'.$it618_auction_goods['it618_name'].'</font></a></div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;font-size:11px">'.$it618_type.' '.it618_auction_getlang('s305').'<span>'.$it618_auction_sale['id'].'</span> '.it618_auction_getlang('s303').'<span>'.$it618_auction_sale['it618_score'].'</span>'.$creditnametmp.'<br>'.$username.'<span style="line-height:18px">'.$strkd.$it618_btn.'<span style="float:right">'.$it618_state.'</span><font color=#999>'.date('Y-m-d H:i:s', $it618_auction_sale['it618_time']).'</font></span></div>

						</div>
					</dd>';
		}
				 
	}
	if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
	$dealcount1 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." where it618_type=1 and it618_state<>0 and it618_state<>3 and it618_uid=".$_G['uid']);
	$dealcount2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." where it618_type=2 and it618_state<>0 and it618_state<>3 and it618_uid=".$_G['uid']);
	$it618_money1 = DB::result_first("SELECT sum(it618_score) FROM ".DB::table('it618_auction_sale')." where it618_type=1 and it618_state<>0 and it618_state<>3 and it618_uid=".$_G['uid']);
	$it618_money2 = DB::result_first("SELECT sum(it618_score) FROM ".DB::table('it618_auction_sale')." where it618_type=2 and it618_state<>0 and it618_state<>10 and it618_state<>3 and it618_uid=".$_G['uid']);
	if($it618_money1=='')$it618_money1=0;if($it618_money2=='')$it618_money2=0;
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
		
	}
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_auction:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getmyauction(this.name,\"mydeal_get\")' name=",$multipage);
		$multipage=str_replace("onclick='getmyauction(this.name,\"mydeal_get\")' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getmyauction(',$multipage);
		$multipage=str_replace('; doane(event);',',\"mydeal_get\"); doane(event);',$multipage);
		
		$mydeal_get='<div class="auctionmenu">
						<a class="it618_menu" href="javascript:" onclick="getmyauction(\''.$_G['siteurl'].'plugin.php?id=it618_auction:ajax&page=1\',\'myprice_get\');">'.it618_auction_getlang('s296').'</a>
						<a class="it618_menu it618_curmenu" href="javascript:" onclick="getmyauction(\''.$_G['siteurl'].'plugin.php?id=it618_auction:ajax&page=1\',\'mydeal_get\');">'.it618_auction_getlang('s297').'</a>
					</div>
					<div class="auctioncon"><div style="float:left; margin-top:10px;border:#e8e8e8 1px solid; padding:6px;color:#888">'.it618_auction_getlang('s322').'<font color=red>'.$dealcount1.'</font><font color=#aaa>/</font><font color=red>'.$dealcount2.'</font> '.it618_auction_getlang('s323').'<font color=red>'.$it618_money1.'</font>'.$creditname1.'<font color=#aaa>/</font><font color=red>'.$it618_money2.'</font>'.$it618_auction_lang['s432'].'<br><div style="background-color:#f9f9f9;color:#888;padding:10px 4px;margin-top:6px">'.it618_auction_getlang('s771').'</div>'.$mydeal_get.'</div></div>';
		
		if($count>$ppp){
			$mydeal_get.='<div style="float:right;margin-top:10px">'.$multipage.'</div>';
		}
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getmyauction(this.value,\'mydeal_get\')">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s477').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getmyauction(\''.$tmpurl.'\',\'mydeal_get\')">'.it618_auction_getlang('s478').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_auction_getlang('s478').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getmyauction(\''.$tmpurl.'\',\'mydeal_get\')">'.it618_auction_getlang('s477').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getmyauction(\''.$tmpurl.'\',\'mydeal_get\')">'.it618_auction_getlang('s478').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax".$urlsql.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getmyauction(\''.$tmpurl.'\',\'mydeal_get\')">'.it618_auction_getlang('s477').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s478').'</a>';
			}
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		
		$mydeal_get='<div class="mysalediv">'.it618_auction_getlang('s322').'<font color=red>'.$dealcount1.'</font><font color=#aaa>/</font><font color=red>'.$dealcount2.'</font> '.it618_auction_getlang('s323').'<font color=red>'.$it618_money1.'</font>'.$creditname1.'<font color=#aaa>/</font><font color=red>'.$it618_money2.'</font>'.$it618_auction_lang['s432'].'</div><div class="mysaledivabout">'.it618_auction_getlang('s771').'</div>'.$mydeal_get.'<div style="text-align:center;border:none;padding-top:10px; padding-bottom:10px">'.$multipage.'</div>';
	}
	echo $mydeal_get;exit;
}


if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo it618_auction_getlang('s808');
	}else{
		
		$saleid=intval($_GET['saleid']);
		
		if(!($it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE id=".$saleid." and it618_state=10"))){
			echo it618_auction_getlang('s842');exit;
		}
		
		$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$it618_auction_sale['it618_pid']);

		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		
		$yfmoney=$it618_auction_sale['it618_score'];
			
		$saletype='1001';
		$out_trade_no = date("YmdHis").$saletype.$saleid;
		
		$body=$it618_auction_goods['it618_name'];
		
		$total_fee=$yfmoney;
		
		if(auction_is_mobile()){ 
			$wap=1;
			$url=$_G['siteurl'].it618_auction_getrewrite('group_wap','product@'.$pid,'plugin.php?id=it618_auction:wap&pagetype=product&cid='.$pid);
		}else{
			$wap=0;
			if($_G['cache']['plugin']['it618_auction']['rewriteurl']==0){
				$url=$_G['siteurl'].it618_auction_getrewrite('auction_wap','mysale@0@0','plugin.php?id=it618_auction:wap&pagetype=mysale');
			}else{
				$url=$_G['siteurl'].it618_auction_getrewrite('auction_home','','plugin.php?id=it618_auction:auction').'?myauction';
			}
		}
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
		$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
		$tmparr=explode("it618_split",$domainurl_paytype);
		$domainurl=$tmparr[0];
		$paytype=$tmparr[1];

		C::t('#it618_credits#it618_credits_salepay')->insert(array(
			'it618_out_trade_no' => $out_trade_no,
			'it618_uid' => $uid,
			'it618_saletype' => $saletype,
			'it618_saleid' => $saleid,
			'it618_paytype' => $paytype,
			'it618_url' => $url,
			'it618_body' => $body,
			'it618_total_fee' => round($total_fee,2),
			'it618_plugin' => 'it618_auction',
			'it618_wap' => $wap,
			'it618_state' => 0,
			'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
			'it618_time' => $_G['timestamp']
		), true);
	
		$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
		
		
		echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;

	}
	exit;
}


if($_GET['ac']=="wappricelist_get"){
	$ppp = 15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$pid=intval($_GET['pid']);
	
	if($pid>0){
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_timetype=$it618_auction_goods['it618_timetype'];
		$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
		$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
		$it618_bhour=explode(":",$it618_auction_goods['it618_bhour']);
		$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
		
		$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
		if($salecount>0){
			$it618_addtime = DB::result_first("SELECT it618_addtime FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
		}
			
		$btime=mktime($it618_bhour[0], $it618_bhour[1], 0, $it618_bdate[1], $it618_bdate[2], $it618_bdate[0]);
		$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0])+$it618_addtime;
		$flag=0;
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
			
		}
		if($it618_timetype==1){
			if($etime>=$_G['timestamp']){
				if($btime>$_G['timestamp']){
					$flag=1;
				}else{
					$btimecur=mktime($it618_bhour[0], $it618_bhour[1], 0, date('n'), date('j'), date('Y'));
					$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'))+$it618_addtime;
					if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
					if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
						$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
						if($count>0){
							$saleid = DB::result_first("SELECT it618_saleid FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
						}else{
							$saleid=0;
						}
											
					}else{
						$flag=1;
					}
				}
				
			}else{
				$flag=1;
			}
		}else{
			if($etime>=$_G['timestamp']){
				if($btime>$_G['timestamp']){
					$flag=1;
				}else{
					$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
					if($count>0){
						$saleid = DB::result_first("SELECT it618_saleid FROM ".DB::table('it618_auction_sale_price')." where it618_state=0 and it618_pid=".$pid);
					}else{
						$saleid=0;
					}
				}
				
			}else{
				$flag=1;
			}
		}
		if($flag==1){
			$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where it618_pid=".$pid);
			if($count>0){
				$saleid = DB::result_first("SELECT it618_saleid FROM ".DB::table('it618_auction_sale_price')." where it618_pid=".$pid." order by id desc");
			}else{
				$saleid=0;
			}
		}
		$pidstr='it618_saleid='.$saleid;
	}else{
		$pidstr='1';
	}

	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale_price')." where 1 and $pidstr order by id desc LIMIT $startlimit, $ppp");
	$n=$startlimit+1;
	while($it618_auction_sale_price = DB::fetch($query)) {
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale_price['it618_pid']);
		
		$buyuser=it618_auction_getusername($it618_auction_sale_price['it618_uid']);
		if($it618_auction_goods['it618_isbm']==1){
			$buyuser='***';
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$it618_zk=$buyuser;

		if($pid==0){

			$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
			$buyuser='<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_auction_goods['it618_name'],10,'...').'</a>';
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		
		if($it618_auction_sale_price['it618_type']==1){
			$creditnametmp=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
		}else{
			$creditnametmp=$it618_auction_lang['s432'];
		}
		
		$pricelist_get.='<tr>
				 <td>'.$buyuser.'</td>
				 <td align="center">'.$it618_auction_sale_price['it618_score'].''.$creditnametmp.'</td>
				 <td align="center"><font color=#999>'.date('Y-m-d H:i:s', $it618_auction_sale_price['it618_time']).'</font></td>
				 </tr>';
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price')." where 1 and $pidstr $uidstr");
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($myprice>0){
		$funnamestr='getmypricelist';
	}else{
		$funnamestr='getpricelist';
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
		
	}
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funnamestr.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s477').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_auction_getlang('s478').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s478').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	echo $pricelist_get."it618_split".$multipage;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d"."z-"."x. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/themes/common/ri'.'ght.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="wappricelist1_get"){
	$ppp = 15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale_price')." order by id desc LIMIT $startlimit, $ppp");
	$n=$startlimit+1;
	while($it618_auction_sale_price = DB::fetch($query)) {
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale_price['it618_pid']);
		
		$buyuser=it618_auction_getusername($it618_auction_sale_price['it618_uid']);
		if($it618_auction_goods['it618_isbm']==1){
			$buyuser='***';
		}
		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		$it618_zk=$buyuser;

		$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
		$it618_name='<a href="'.$tmpurl.'" target="_blank"><font color=#666>'.cutstr($it618_auction_goods['it618_name'],16,'...').'</font></a>';

		if(lang('plugin/it618_auction', $it618_auction_lang['it618'])!=$it618_auction_lang['version'])exit;
		
		if($it618_auction_sale_price['it618_type']==1){
			$creditnametmp=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
		}else{
			$creditnametmp=$it618_auction_lang['s432'];
		}
		
		$pricelist_get.='<tr>
				 <td>'.$it618_name.'</td>
				 <td align="center">'.$it618_auction_sale_price['it618_score'].''.$creditnametmp.'</td>
				 <td>'.$buyuser.'</td>
				 <td align="center"><font color=#999>'.date('Y-m-d H:i:s', $it618_auction_sale_price['it618_time']).'</font></td>
				 </tr>';
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale_price'));
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	$funnamestr='getpricelist';
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funnamestr.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s477').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_auction_getlang('s478').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s478').'</a>';
		}
		$multipage=' '.$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	echo $pricelist_get."it618_split".$multipage;exit;
}
if($_GET['ac']=="wapsalelist_get"){
	$ppp = 15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$pid=intval($_GET['pid']);
	
	if($pid>0)$pidstr='it618_pid='.$pid;else $pidstr='1';
	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_sale')." where it618_state<>0 and it618_state<>3 and $pidstr $uidstr order by id desc LIMIT $startlimit, $ppp");
	$n=$startlimit+1;
	while($it618_auction_sale = DB::fetch($query)) {
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		$it618_auction_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
		$buyuser=it618_auction_getusername($it618_auction_sale['it618_uid']);
		if($it618_auction_goods['it618_isbm']==1){
			$buyuser='***';
		}
		
		$it618_zk=$buyuser;
		if($pid>0){
			if($it618_auction_sale['it618_state']==10)$it618_zk='<font color=#F0F>'.it618_auction_getlang('s698').'</font>';
			if($it618_auction_sale['it618_state']==1)$it618_zk='<font color=red>'.it618_auction_getlang('s486').'</font>';
			if($it618_auction_sale['it618_state']==2)$it618_zk='<font color=#390>'.it618_auction_getlang('s487').'</font>';
			if($it618_auction_sale['it618_state']==4)$it618_zk='<font color=#390>'.it618_auction_getlang('s397').'</font>';
		}
		if($pid==0){

			$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$it618_auction_goods['id'].'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$it618_auction_goods['id']);
			$buyuser='<a href="'.$tmpurl.'" target="_blank"><font color=#666>'.cutstr($it618_auction_goods['it618_name'],16,'...').'</font></a>';
		}
		
		if($it618_auction_sale['it618_type']==1){
			$creditnametmp=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
		}else{
			$creditnametmp=$it618_auction_lang['s432'];
		}
		
		$salelist_get.='<tr>
				 <td>'.$buyuser.'</td>
				 <td align="center">'.$it618_auction_sale['it618_score'].''.$creditnametmp.'</td>
				 <td align="center">'.$it618_zk.'</td>
				 <td align="center"><font color=#999>'.date('Y-m-d H:i:s', $it618_auction_sale['it618_time']).'</font></td>
				 </tr>';
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state<>0 and it618_state<>3 and $pidstr $uidstr");
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	$funnamestr='getsalelist';
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funnamestr.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s477').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_auction_getlang('s478').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s478').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_auction:ajax&pid=".$pid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_auction_getlang('s477').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_auction_getlang('s478').'</a>';
		}
		$multipage=' '.$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	echo $salelist_get."it618_split".$multipage;exit;
}


if($_GET['ac']=="imgdelete"){
	if($uid<=0){
		echo '0';
	}else{
		$shopuid=intval($_GET['shopuid']);
		$auction_adminuid=explode(",",$it618_auction['auction_adminuid']);
		
		if($shopuid>0){
			if(!in_array($_G['uid'],$auction_adminuid)){
				echo '0';exit;
			}
			$imguid=$shopuid;
		}
		
		if($shopuid<0){
			if(!in_array($_G['uid'],$auction_adminuid)){
				echo '0';exit;
			}
			$imguid=0;
		}
		
		if($shopuid==0){
			$imguid=$uid;
		}
		
		if($imguid==0){
			$tmparr=explode('source/plugin/it618_auction/kindeditor/attached/image/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/attached/image/'.$tmparr[1];
			}
		}else{
			$tmparr=explode('source/plugin/it618_auction/kindeditor/data/u'.$imguid.'/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_auction/kindeditor/data/u'.$imguid.'/'.$tmparr[1];
			}
		}
		
		if(file_exists($delpath)) {
			$result=unlink($delpath);
			if(it618_auction_dirsize(dirname($delpath))==0){
				rmdir(dirname($delpath));
			}
			
			echo '1';
		}else{
			echo '0';
		}
	}
	exit;
}


if($_GET['ac']=="saveset"){
	$uid = $_G['uid'];

	$liii1il=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liii1il[]=substr($_GET['id'],$i,1);}
	if($liii1il[2]!='6')exit;
	if($uid>0){
		if($it618_auction_user=DB::fetch_first("select * from ".DB::table('it618_auction_user')." where it618_uid=$uid")){
			$setarr = array(
				'it618_tel' => it618_auction_utftogbk($_GET['it618_tel']),
				'it618_msgisok' => $_GET['it618_msgisok'],
			);
			$id = C::t('#it618_auction#it618_auction_user')->update($it618_auction_user['id'],$setarr);
			echo $it618_auction_lang['s774'];
		}else{
			$setarr = array(
				'it618_uid' => $_G['uid'],
				'it618_tel' => it618_auction_utftogbk($_GET['it618_tel']),
				'it618_msgisok' => $_GET['it618_msgisok'],
			);
			$id = C::t('#it618_auction#it618_auction_user')->insert($setarr, true);
			echo $it618_auction_lang['s774'];
		}
	}
	exit;
}
//From: Dism_taobao-com
?>