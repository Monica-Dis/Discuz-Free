<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_default.func.php';

if(auction_is_mobile()){ 
	$tmpurl=it618_auction_getrewrite('auction_wap','','plugin.php?id=it618_auction:wap');
	dheader("location:$tmpurl");
}

$auction_homewidthheight=explode(",",$it618_auction['auction_homewidthheight']);
$foucswidth=$auction_homewidthheight[0];
$foucsheight=$auction_homewidthheight[1];
$gonggaowidth=$auction_homewidthheight[0]-23;

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_article_class')." where it618_order>0 order by it618_order desc");
while($it618_auction_article_class = DB::fetch($query)) {
	if($it618_auction_article_class['it618_color']!=''){
		$it618_classname='<font color='.$it618_auction_article_class['it618_color'].'>'.$it618_auction_article_class['it618_classname'].'</font>';
	}else{
		$it618_classname=$it618_auction_article_class['it618_classname'];
	}
	$articlelisttmp='<div class="v_mod_article"><div class="it618_hd"><h3 class="f_tx1">'.$it618_classname.'</h3></div><div class="it618_bd"><ul>';
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_article')." where it618_class_id=".$it618_auction_article_class['id']." and it618_order>0 order by it618_order desc");
	while($it618_auction_article = DB::fetch($query1)) {
		if($it618_auction_article['it618_color']!=''){
			$it618_name='<font color='.$it618_auction_article['it618_color'].'>'.$it618_auction_article['it618_name'].'</font>';
		}else{
			$it618_name=$it618_auction_article['it618_name'];
		}
		
		$tmpurl=it618_auction_getrewrite('auction_article',$it618_auction_article['id'],'plugin.php?id=it618_auction:auction_article&aid='.$it618_auction_article['id']);
		$articlelisttmp.='<li><a href="'.$tmpurl.'" target="_blank">'.$it618_name.'</a></li>';
	}
	$articlelisttmp.='</ul></div></div>';
	
	$articlelist.=$articlelisttmp;
}

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_focus')." WHERE it618_is=1 ORDER BY it618_order");
$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
while($it618_auction_focus = DB::fetch($query)) {
	$str_focus.='<div><a href="'.$it618_auction_focus['it618_url'].'" target="_blank"><img src="'.$it618_auction_focus['it618_img'].'" width="'.$foucswidth.'" height="'.$foucsheight.'" title="'.$it618_auction_focus['it618_tip'].'"/></a></div>';
	if(count($i1ii1)!=13)return;
}

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_auction_gonggao = DB::fetch($query)) {
	$it618_title=$it618_auction_gonggao['it618_title'];
	
	if($it618_auction_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_auction_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_auction_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_auction_gonggao['it618_url'].'" target="_blank" title="'.$it618_auction_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_goods')." where it618_ison=1 order by it618_salecount desc LIMIT 0, ".$it618_auction['auction_homehotcount']);
while($it618_auction_goods_hotlist = DB::fetch($query)) {
	$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods_hotlist['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods_hotlist['id']);
	$hotlist.='<li>
				  <a href="'.$tmpurl.'" target="_blank">
					  <img src="'.$it618_auction_goods_hotlist['it618_picsmall'].'"/>
				  </a>
				  <p class="desc"><a href="'.$tmpurl.'" target="_blank">'.$it618_auction_goods_hotlist['it618_name'].'</a></p>
			  </li>';
}

$tmp='<option value=9999>'.it618_auction_getlang('s200').'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_class')." ORDER BY it618_order DESC");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.it618_auction_getlang('s201').$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['cid'].'>','<option value='.$_GET['cid'].' selected="selected">',$tmp);

if(isset($_GET['myauction']))$curtab=1;
$pagetype='home';
include template('it618_auction:auction_default');
?>