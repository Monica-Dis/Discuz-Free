<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_function.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_auction/config/message.php';
}

if($it618_isok==1){
	$tmpstr='<tr><td><font color="green">'.it618_auction_getlang('s824').'</font> ';
	if($it618_body_sale_user_isok==1||$it618_body_sale_user1_isok==1)$tmpstr.='<img src="source/plugin/it618_auction/images/se.gif">';else $tmpstr.='<img src="source/plugin/it618_auction/images/se0.gif">';
	$tmpstr.='</td></tr>';
	
	$tmpstr.='<tr><td><font color="green">'.it618_auction_getlang('s825').'</font> ';
	if($it618_body_chujia_user_isok==1)$tmpstr.='<img src="source/plugin/it618_auction/images/se.gif">';else $tmpstr.='<img src="source/plugin/it618_auction/images/se0.gif">';
	$tmpstr.='</td></tr>';
	
	$tmpstr.='<tr><td><img src="source/plugin/it618_auction/images/se.gif"> '.it618_auction_getlang('s1058');
	$tmpstr.='</td></tr>';
	
}else{
	$tmpstr='<tr><td>'.it618_auction_getlang('s1059').'</td></tr>';
}

$it618_auction_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_user')." where it618_uid=".$_G['uid']);
if($it618_auction_user['it618_msgisok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";

$tmpstr= '
<tr><td>'.it618_auction_getlang('s1056').'</td></tr>
'.$tmpstr.'
<tr><td height=6 style="border:none"></td></tr>
<tr><td><b><font color=#666>'.it618_auction_getlang('s1065').'</font></b></td></tr>
<tr><td>'.it618_auction_getlang('s1060').'<input type="checkbox" id="it618_msgisok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_msgisok">'.it618_auction_getlang('s1061').'</label></td></tr>
<tr><td>'.it618_auction_getlang('s1062').'<input type="text" class="txt" style="width:110px; color:red; font-weight:bold;font-size:14px" id="it618_tel" value="'.$it618_auction_user['it618_tel'].'"> '.it618_auction_getlang('s1063').'</td></tr>
<tr><td style="text-align:center;border:none;padding-top:6px"><input type="button" class="setbtn" value="'.it618_auction_getlang('s1064').'" onclick="saveset()" /></td></tr>';

$_G['mobiletpl'][IN_MOBILE]='/'; /*dism - taobao- com*/
if($_GET['wap']==1){
	include template('it618_auction:showsetwap');
}else{
	include template('it618_auction:showset');
}
//From: Dism_taobao-com
?>