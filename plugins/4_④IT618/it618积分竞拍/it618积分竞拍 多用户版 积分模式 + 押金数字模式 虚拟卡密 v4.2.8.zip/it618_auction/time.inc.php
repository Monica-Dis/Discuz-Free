<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_wike;

$it618_auction = $_G['cache']['plugin']['it618_auction'];

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';

$pid = intval($_GET['pid']);
$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);

$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
if($ii1i11i[3]!='1')return;

$it618_timetype=$it618_auction_goods['it618_timetype'];
$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
$it618_bhour=explode(":",$it618_auction_goods['it618_bhour']);
$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);

$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
if($salecount>0){
	$it618_addtime = DB::result_first("SELECT it618_addtime FROM ".DB::table('it618_auction_sale')." where it618_state=0 and it618_pid=".$pid);
}
	
$btime=mktime($it618_bhour[0], $it618_bhour[1], 0, $it618_bdate[1], $it618_bdate[2], $it618_bdate[0]);
$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0])+$it618_addtime;

if($it618_timetype==1){
	if($etime>=$_G['timestamp']){
		if($btime>$_G['timestamp']){
			$it618_time=date('Y-m-d H:i:s', $btime);
		}else{
			$btimecur=mktime($it618_bhour[0], $it618_bhour[1], 0, date('n'), date('j'), date('Y'));
			$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'))+$it618_addtime;
			if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
				$it618_time=date('Y-m-d H:i:s', $etimecur);
			}elseif($btimecur>$_G['timestamp']){
				$it618_time=date('Y-m-d H:i:s', $btimecur);
			}else{
				$it618_time=date('Y-m-d H:i:s', $btimecur+24*60*60);
			}
		}
	}
}else{
	if($etime>=$_G['timestamp']){
		if($btime>$_G['timestamp']){
			$it618_time=date('Y-m-d H:i:s', $btime);
		}else{
			$it618_time=date('Y-m-d H:i:s', $etime);
		}
	}
}

$endTime=$it618_time;
$serverTime=date('Y-m-d H:i:s', $_G['timestamp']);

$auction_homewidthheight=explode(",",$it618_auction['auction_homewidthheight']);
$foucswidth=$auction_homewidthheight[0];

if($_GET['wap']==1){
	$fontsize=13;
	$fontsize1=$fontsize+2;
}else{
	$fontsize=13;
	$fontsize1=$fontsize;
}

if($_GET['wap']==1)$_G['mobiletpl'][IN_MOBILE]='/'; /*dism - taobao- com*/
include template('it618_auction:time');
?>