<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsMembers,$IsCredits,$IsGroup,$IsUnion,$IsChat,$IsWxMini,$RegName;
$RegName=$_G['setting']['regname'];

$it618_members = $_G['cache']['plugin']['it618_members'];
if($it618_members['members_isok']==1){
	$IsMembers=1;
}

$it618_credits = $_G['cache']['plugin']['it618_credits'];
if($it618_credits['seotitle']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/plugins/autoheight/it618.png')){
	$IsCredits=1;
}

$it618_group = $_G['cache']['plugin']['it618_group'];
if($it618_group['pagecount']!=''){
	$IsGroup=1;
}

$it618_union = $_G['cache']['plugin']['it618_union'];
if($it618_union['seotitle']!=''){
	if($it618_union['seotitle']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/plugins/code/it618.png')){
		$IsUnion=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php')){
	$IsChat=1;
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/lang.func.php';
}

$it618_wxmini = $_G['cache']['plugin']['it618_wxmini'];
if($it618_wxmini['pagecount']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_wxmini/kindeditor/plugins/autoheight/it618.png')){
	$IsWxMini=1;
}

$langpluginname='it618_auction';
if($_SERVER['HTTP_HOST']=='localhost'||strpos($_SERVER['HTTP_HOST'],'localhost'))$language = 'language.php';else$language = 'language.'.currentlang().'.php';
if(!file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language))$language = 'language.php';
require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language;$language_edit = 'language.'.currentlang().'_edit.php';
if(file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit)){
	$lang_version=$it618_auction_lang['version'];$lang_it618=$it618_auction_lang['it618'];require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit;$it618_auction_lang['version']=$lang_version;$it618_auction_lang['it618']=$lang_it618;
}
//From: Dism_taobao-com
?>