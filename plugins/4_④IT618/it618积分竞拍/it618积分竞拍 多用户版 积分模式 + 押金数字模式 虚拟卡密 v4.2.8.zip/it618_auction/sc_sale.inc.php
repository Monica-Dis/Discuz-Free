<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/sc_header.func.php';

if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_identity')." where (it618_isok1=3 or it618_isok2=3) and it618_uid=".$_G['uid'])==0){
	it618_cpmsg(it618_auction_getlang('s489'), "plugin.php?id=it618_auction:sc_identity", 'error');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_function.func.php';
if($_GET['key']) {
	$extrasql .= " AND g.it618_name LIKE '%".addcslashes($_GET['key'],'%_')."%'";
}

if($_GET['state']) {
	$state0='';$state1='';$state10='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$extrasql .= " AND s.it618_state = 0";$state1='selected="selected"';}
	if($_GET['state']==10){$extrasql .= " AND s.it618_state = 10";$state10='selected="selected"';}
	if($_GET['state']==2){$extrasql .= " AND s.it618_state = 1";$state2='selected="selected"';}
	if($_GET['state']==3){$extrasql .= " AND s.it618_state = 2";$state3='selected="selected"';}
	if($_GET['state']==4){$extrasql .= " AND s.it618_state = 3";$state4='selected="selected"';}
	if($_GET['state']==5){$extrasql .= " AND s.it618_state = 4";$state4='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&state='.$_GET['state'];

if(submitcheck('it618submit_yifahuo')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." where id=".$delid);
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$it618_auction_sale['it618_pid']);
		
		if($it618_auction_sale['it618_state']==1&&($it618_auction_goods['it618_isaddr']!=1||$it618_auction_sale['it618_addr']!='')){
			DB::query("update ".DB::table('it618_auction_sale')." set it618_state=2 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}
	
	it618_cpmsg(it618_auction_getlang('s150').$ok, "plugin.php?id=it618_auction:sc_sale&page=$page".$sql, 'succeed');

}

if(submitcheck('it618submit_kd')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." where id=".$delid);
		
		if($it618_auction_sale['it618_state']==2){
			C::t('#it618_auction#it618_auction_sale')->update($delid,array(
				'it618_kdid' => intval($_GET['it618_kdid'][$delid]),
				'it618_kddan' => $_GET['it618_kddan'][$delid]
			));
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_auction_getlang('s151').$ok, "plugin.php?id=it618_auction:sc_sale&page=$page".$sql, 'succeed');
}

echo '
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_auction/images/common.css" />
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/kindeditor-min.js"></script>
<script src="source/plugin/it618_auction/js/jquery.js"></script>
';

it618_showformheader("plugin.php?id=it618_auction:sc_sale&page=$page".$sql);
showtableheaders(it618_auction_getlang('s152'),'it618_auction_sum');

	echo '<tr><td colspan=14>'.it618_auction_getlang('s153').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_auction_getlang('s167').' <select name="state"><option value=0 '.$state0.'>'.it618_auction_getlang('s155').'</option><option value=1 '.$state1.'>'.it618_auction_getlang('s156').'</option><option value=10 '.$state10.'>'.$it618_auction_lang['s698'].'</option><option value=2 '.$state2.'>'.it618_auction_getlang('s157').'</option><option value=3 '.$state3.'>'.it618_auction_getlang('s158').'</option><option value=4 '.$state4.'>'.it618_auction_getlang('s353').'</option><option value=5 '.$state5.'>'.it618_auction_getlang('s397').'</option></select> <input type="submit" class="btn" name="it618sercsubmit" value="'.it618_auction_getlang('s9').'" /></td></tr>';
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." s,".DB::table('it618_auction_goods')." g WHERE s.it618_pid=g.id and s.it618_postuid=".$_G['uid']." $extrasql");
	$moneysum = DB::result_first("SELECT sum(s.it618_score) FROM ".DB::table('it618_auction_sale')." s,".DB::table('it618_auction_goods')." g WHERE s.it618_pid=g.id and s.it618_postuid=".$_G['uid']." $extrasql");
	
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_auction:sc_sale".$sql);
	
	echo '<tr><td colspan=10>'.it618_auction_getlang('s159').$count.'<span style="float:right;color:red">'.it618_auction_getlang('s396').'</span></td></tr>';
	showsubtitle(array('', it618_auction_getlang('s161'),it618_auction_getlang('s164'),it618_auction_getlang('s165').'/'.it618_auction_getlang('s166'),it618_auction_getlang('s167'),it618_auction_getlang('s649'),it618_auction_getlang('s169')));
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_auction_kd')." ORDER BY it618_order DESC");
	$tmp.='<option value="0">'.it618_auction_getlang('s170').'</option>';
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
	$query = DB::query("SELECT s.* FROM ".DB::table('it618_auction_sale')." s,".DB::table('it618_auction_goods')." g WHERE s.it618_pid=g.id and s.it618_postuid=".$_G['uid']." $extrasql order by id desc LIMIT $startlimit, $ppp");
	while($it618_auction_sale = DB::fetch($query)) {
		
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$it618_auction_sale['it618_pid']);
		$it618_name=$it618_auction_goods['it618_name'];
		$it618_picsmall=$it618_auction_goods['it618_picsmall'];
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_auction_sale['it618_uid']);
		
		$pricecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
		$it618_shouxufei = DB::result_first("SELECT sum(it618_shouxufei) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
		$it618_chujiafei = DB::result_first("SELECT sum(it618_chujiafei) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
		
		if($it618_auction_sale['it618_state']==2&&$it618_auction_sale['it618_km']==''){
			$tmp1=str_replace('<option value='.$it618_auction_sale['it618_kdid'].'>','<option value='.$it618_auction_sale['it618_kdid'].' selected="selected">',$tmp);
			$strkd='<font color=green>'.it618_auction_getlang('s171').'<select name="it618_kdid['.$it618_auction_sale[id].']">'.$tmp1.'</select><br>'.it618_auction_getlang('s172').'<input type="text" class="txt" style="width:112px" name="it618_kddan['.$it618_auction_sale[id].']" value="'.$it618_auction_sale['it618_kddan'].'"></font>';
		}else{
			if($it618_auction_sale['it618_kdid']!=0&&$it618_auction_sale['it618_kddan']!=''){
				$it618_auction_kd=DB::fetch_first("select * from ".DB::table('it618_auction_kd')." WHERE id=".$it618_auction_sale['it618_kdid']);
				$strkd=it618_auction_getlang('s171').'<a href="'.$it618_auction_kd['it618_url'].'" target="_blank"><font color=green>'.$it618_auction_kd['it618_name'].'</font></a><br>'.it618_auction_getlang('s172').'<font color=green>'.$it618_auction_sale['it618_kddan'].'</font>';
			}else{
				$strkd='';	
			}
		}
		
		if($it618_auction_sale['it618_state']==0)$it618_state='<font color=blue>'.it618_auction_getlang('s156').'</font>';
		if($it618_auction_sale['it618_state']==10)$it618_state='<font color=#F0F>'.$it618_auction_lang['s698'].'</font>';
		if($it618_auction_sale['it618_state']==1){
			$it618_state='<font color=red>'.$it618_auction_lang['s157'].'</font>';
		  
			if($it618_auction_sale['it618_addr']==''){
				$it618_state.='<br><font color=blue>'.$it618_auction_lang['s797'].'</font>';
			}else{
				$it618_state.='<br><font color=green>'.$it618_auction_lang['s798'].'</font>';
			}
		}
		if($it618_auction_sale['it618_state']==2){
			$it618_state='<font color=green>'.it618_auction_getlang('s158').'</font>';
			
			if($it618_auction_sale['it618_kddan']==''){
				$it618_state.='<br><font color=blue>'.$it618_auction_lang['s799'].'</font>';
			}
		}
		if($it618_auction_sale['it618_state']==3)$it618_state='<font color=#ccc>'.it618_auction_getlang('s353').'</font>';
		if($it618_auction_sale['it618_state']==4)$it618_state='<font color=green>'.it618_auction_getlang('s397').'</font>';
		
		$it618_bz='';
		$it618_fl = DB::result_first("SELECT sum(it618_fl) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
		if($it618_auction_sale['it618_type']==1){
			$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
			$creditnametmp=$creditname;
			$it618_type='<font color=green><b>'.$it618_auction_lang['s761'].'</b></font>';

		}else{
			$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];
			$creditnametmp=$it618_auction_lang['s432'];
			
			if($IsCredits==1){
				if($it618_auction_goods['it618_paytype']==1)$paytype=$it618_auction_lang['s830'];else $paytype=$it618_auction_lang['s831'];
			}
			
			$it618_type='<font color=red><b>'.$paytype.$it618_auction_lang['s762'].'</b></font>';
			
			$it618_yajin = DB::result_first("SELECT sum(it618_yajin) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
			$it618_shouxufei = DB::result_first("SELECT sum(it618_shouxufei) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
			$it618_chujiafei = DB::result_first("SELECT sum(it618_chujiafei) FROM ".DB::table('it618_auction_sale_price')." where it618_saleid=".$it618_auction_sale['id']);
			$it618_bz.=$it618_auction_lang['s764'].'<font color=red>'.$it618_yajin.'</font>'.$creditnametmp.' ';
			$it618_bz.=$it618_auction_lang['s307'].'<font color=red>'.$it618_shouxufei.'</font>'.$creditname.' ';
			$it618_bz.=$it618_auction_lang['s308'].'<font color=red>'.$it618_chujiafei.'</font>'.$creditname.' ';
			$it618_bz.=$it618_auction_lang['s671'].'<font color=red>'.$it618_fl.'</font>'.$creditname.' ';
		}
		
		if($it618_auction_sale['it618_postuid']>0){
			$it618_blmoney=intval($it618_auction_sale['it618_bl']*$it618_auction_sale['it618_score']/100);
			$money=0;
			if($it618_auction_sale['it618_state']==0)$it618_blmoney=0;
			if($it618_auction_sale['it618_state']==4){
				$money=$it618_auction_sale['it618_score']-$it618_blmoney;
			}
			if($money>0)$money='<font color=red>'.$money.'</font>';
			$tcstr='<br>'.it618_auction_getlang('s398').$it618_auction_sale['it618_bl'].'%<br>'.it618_auction_getlang('s399').'<font color=red>'.$it618_blmoney.'</font>'.$creditname.'<br>'.it618_auction_getlang('s400').'<font color=red>'.$money.'</font>'.$creditname;
			
			if($it618_auction_sale['it618_state']==3){
				$tcstr='';
			}
			
			$it618_postuid=$tcstr;
		}else{
			$it618_postuid='';
		}
		
		$it618_addr='';
		if($it618_auction_sale['it618_addr']!=''){
			$it618_addr='<a href="javascript:" onclick="document.getElementById(\'showaddrbtn\').click();document.getElementById(\'saleid\').value=\''.$it618_auction_sale['id'].'\';setTimeout(\'readaddr1();\',100)">'.$it618_auction_lang['s298'].'</a>';
		}
		
		$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_auction_sale[id].'" name="delete[]" value="'.$it618_auction_sale[id].'"><label for="chk_del'.$it618_auction_sale[id].'" title="'.$it618_auction_lang['s173'].'D'.$saleid.'">'.$it618_auction_sale['id'].'</label>',
			'<a href="'.$tmpurl.'" title="'.$it618_auction_lang['s174'].''.$it618_auction_sale['it618_pid'].' '.$it618_auction_lang['s175'].''.it618_auction_classname($it618_auction_goods['it618_class_id']).'" target="_blank" style="float:left"><img style="float:left;" src="'.$it618_picsmall.'" width="80" height="55" align="absmiddle"/></a><div style="float:left;width:300px;margin-left:3px;line-height:18px"><a href="'.$tmpurl.'" target="_blank">'.$it618_name.'</a><br>'.$it618_type.' '.$it618_auction_lang['s408'].'<font color=red>'.$it618_auction_sale['it618_bscore'].'</font>'.$creditnametmp.' '.$it618_bz.'</div>',
			'<a href="javascript:" onclick="document.getElementById(\'showpricebtn\').click();document.getElementById(\'saleid\').value=\''.$it618_auction_sale['id'].'\';setTimeout(\'readpricelist1();\',100)">'.$it618_auction_lang['s176'].'(<font color=red>'.$pricecount.'</font>)</a><br>'.$it618_auction_lang['s354'].'<a href="'.it618_auction_rewriteurl($it618_auction_sale['it618_uid']).'" target="_blank">'.it618_auction_getusername($it618_auction_sale['it618_uid']).'</a><br>'.$it618_auction_lang['s404'].'<font color=red>'.$it618_auction_sale['it618_score'].'</font>'.$creditnametmp,
			$it618_addr.'<br>'.$strkd,
			$it618_state,
			$it618_postuid,
			'<div style="width:75px">'.date('Y-m-d H:i:s', $it618_auction_sale['it618_time']).'</div>'
		));
	}
	
	function it618_auction_classname($aid){
		return DB::result_first("select it618_classname from ".DB::table('it618_auction_class')." where id=".$aid);
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_auction_getlang('s177').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_yifahuo" value="'.it618_auction_getlang('s180').'" onclick="return confirm(\''.it618_auction_getlang('s181').'\')"/> '.it618_auction_getlang('s643').'<input type="submit" class="btn" name="it618submit_kd" value="'.it618_auction_getlang('s182').'"/><br>'.it618_auction_getlang('s769').'</div></td></tr>';


echo '<span id="showpricebtn"></span><span id="showaddrbtn"></span><input type="hidden" id="saleid"/>
<script>
KindEditor.ready(function(K) {K(\'#showpricebtn\').click(function() {
	var dialog = K.dialog({
		width :620,
		height:350,
		title : \''.it618_auction_getlang('s184').'\',
		body : \'<div id="readpricelist" style="margin:10px;"></div>\',
		closeBtn : {
			name : \''.it618_auction_getlang('s185').'\',
			click : function(e) {
				dialog.remove();
			}
		},
		noBtn : {
			name : \''.it618_auction_getlang('s185').'\',
			click : function(e) {
				dialog.remove();
			}
		}
	});
});});

function readpricelist1(){
	readpricelist("");
}

function readpricelist(url){
	if(url=="")url="'.$_G['siteurl'].'plugin.php?id=it618_auction:ajax&saleid="+document.getElementById("saleid").value;
	IT618_AUCTION.get(url, {ac:"readpricelist"},function (data, textStatus){
	IT618_AUCTION("#readpricelist").html(data);
	}, "html");	
	window.onerror=function(){return true;}
}

KindEditor.ready(function(K) {K(\'#showaddrbtn\').click(function() {
	var dialog = K.dialog({
		width :480,
		height:280,
		title : \''.$it618_auction_lang['s298'].'\',
		body : \'<div style="margin:10px;"><table class="showset" width="100%" id="readaddr"></table></div>\',
		closeBtn : {
			name : \''.$it618_auction_lang['s185'].'\',
			click : function(e) {
				dialog.remove();
			}
		},
		noBtn : {
			name : \''.$it618_auction_lang['s185'].'\',
			click : function(e) {
				dialog.remove();
			}
		}
	});
});});

function readaddr1(){
	readaddr("");
}

function readaddr(url){
	if(url=="")url="'.$_G['siteurl'].'plugin.php?id=it618_auction:ajax&saleid="+document.getElementById("saleid").value;
	IT618_AUCTION.get(url, {ac:"readaddr"},function (data, textStatus){
	IT618_AUCTION("#readaddr").html(data);
	}, "html");	
	window.onerror=function(){return true;}
}
</script>';

showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/sc_footer.func.php';
?>