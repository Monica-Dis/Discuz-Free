<?php
  /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_auction = $_G['cache']['plugin']['it618_auction'];

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/lang.func.php';

$uid = $_G['uid'];
$saleid=intval($_GET['saleid']);

$it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE id=".$saleid);
if($it618_auction_sale['it618_uid']!=$uid){
	$tmpstr= '<tr><td style="border:none"><font color=red>'.it618_auction_getlang('s1066').'</font></td></tr>';
	$titlestr=$it618_auction_lang['s735'];
}else{
	if($it618_auction_sale['it618_addr']!=''){
		$it618_addrtmp=$it618_auction_sale['it618_addr'];
	}else{
		if($it618_auction_saletmp = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE it618_uid=".$uid." and it618_addr!='' order by id desc")){
			$it618_addrtmp=$it618_auction_saletmp['it618_addr'];
		}
	}
	
	$tmparr=explode("@@@",$it618_addrtmp);
	if(count($tmparr)==1){
		$it618_bz=$it618_addrtmp;
	}else{
		$it618_name=$tmparr[0];
		$it618_tel=$tmparr[1];
		$it618_qq=$tmparr[2];
		$it618_addr=$tmparr[3];
		$it618_bz=$tmparr[4];
	}
	
	$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE id=".$it618_auction_sale['it618_pid']);
	if($it618_auction_goods['it618_isaddr']==1){
		$flagstr='<font color=red><b>*</b></font> ';
		$tipstr=$it618_auction_lang['s264'].'<input type="hidden" id="isaddr" value="1">';
	}else{
		$tipstr=$it618_auction_lang['s262'].'<input type="hidden" id="isaddr" value="0">';
	}
	
	$tmpstr= '<tr><td width=80>'.$flagstr.it618_auction_getlang('s271').'</td><td><input type="text" class="txt" style="width:98%;font-size:14px" id="it618_name" value="'.$it618_name.'"></td></tr>
			  <tr><td>'.$flagstr.it618_auction_getlang('s273').'</td><td><input type="text" class="txt" style="width:98%;font-size:14px" id="it618_tel" value="'.$it618_tel.'"></td></tr>
			  <tr><td>'.it618_auction_getlang('s274').'</td><td><input type="text" class="txt" style="width:98%;font-size:14px" id="it618_qq" value="'.$it618_qq.'"></td></tr>
			  <tr><td>'.$flagstr.it618_auction_getlang('s272').'</td><td><input type="text" class="txt" style="width:98%;font-size:12px" id="it618_addr" value="'.$it618_addr.'"></td></tr>
			  <tr><td>'.it618_auction_getlang('s276').'</td><td><textarea class="txt" style="width:98%;height:80px;font-size:13px" id="it618_bz">'.$it618_bz.'</textarea></td></tr>';
			  
	if($it618_auction_sale['it618_state']==1){
		if($it618_auction_sale['it618_addr']==''){
			$titlestr=$it618_auction_lang['s300'];
		}else{
			$titlestr=$it618_auction_lang['s299'];
		}
		$tmpstr.='<tr><td colspan="2" style="border:none;text-align:left"><font color=#999>'.$tipstr.'</font></td></tr><tr><td colspan="2" style="text-align:center;border:none;padding-top:6px"><input type="button" class="setbtn" value="'.it618_auction_getlang('s737').'" onclick="savaaddr('.$saleid.')" /></td></tr>';
	}else{
		$titlestr=$it618_auction_lang['s298'];
	}
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*dism - taobao- com*/
if($_GET['wap']==1){
	include template('it618_auction:showaddrwap');
}else{
	include template('it618_auction:showaddr');
}
//From: Dism_taobao-com
?>