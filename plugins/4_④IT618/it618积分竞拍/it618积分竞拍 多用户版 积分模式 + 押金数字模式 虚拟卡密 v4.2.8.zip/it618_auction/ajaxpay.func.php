<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function pay_success($out_trade_no){
	global $_G,$it618_auction_lang;
	
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
		if($it618_salepay['it618_state']==1)return;
	}else{
		return;	
	}
	
	$salepay_saletype=$it618_salepay['it618_saletype'];
	$salepay_saleid=$it618_salepay['it618_saleid'];
	$salepay_paytype=$it618_salepay['it618_paytype'];
	$salepay_payid=$it618_salepay['it618_payid'];
	$salepay_url=$it618_salepay['it618_url'];
	$salepay_wap=$it618_salepay['it618_wap'];

	require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_function.func.php';
	
	if($salepay_saletype=='1001'){
		if($it618_auction_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale')." WHERE id=".$salepay_saleid." and it618_state=10")){
			$kmcount=DB::result_first("select count(1) from ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$it618_auction_sale['it618_pid']);
			
			 if($kmcount>0){
				  for($km_n=1;$km_n<=1;$km_n++){
					  $it618_auction_goods_km=DB::fetch_first("select * from ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$it618_auction_sale['it618_pid']);
					  $strkm.=$it618_auction_goods_km['it618_code'].",";
					  DB::query("delete from ".DB::table('it618_auction_goods_km')." where id=".$it618_auction_goods_km['id']);
					  
					  $it618_blmoney=intval($it618_auction_sale['it618_bl']*$it618_auction_sale['it618_score']/100);
					  $money=$it618_auction_sale['it618_score']-$it618_blmoney;
					  it618_auction_money('shopmoney',$it618_auction_sale['id'],$it618_auction_sale['it618_postuid'],$money,$it618_auction_lang['s843'],1);
				  }
				  $it618_state=4;
				  it618_auction_sendmessage("shouhuo_shop",$it618_auction_sale['id']);
			 }else{
				  $strkm='';
				  $it618_state=1;
			 }
			 
			 DB::query("update ".DB::table('it618_auction_goods')." set it618_salecount=it618_salecount+1 where id=".$it618_auction_sale['it618_pid']);
			 DB::query("update ".DB::table('it618_auction_goods')." set it618_count=it618_count-1 where it618_count>0 and id=".$it618_auction_sale['it618_pid']);
			
			 C::t('#it618_auction#it618_auction_sale')->update($it618_auction_sale['id'],array(
				'it618_blscore' => $it618_blmoney,
				'it618_km' => $strkm,
				'it618_state' => $it618_state
			 ));
			
			$it618_auction_sale_price = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_sale_price')." WHERE it618_saleid=".$it618_auction_sale['id']." and it618_uid=".$it618_auction_sale['it618_uid']);
			
			it618_auction_money('tuiyajin3',$it618_auction_sale['id'],$it618_auction_sale_price['it618_uid'],$it618_auction_sale_price['it618_yajin'],$it618_auction_lang['s838'],1);
			
			$flscore=(intval($it618_auction_sale_price['it618_yajin']*$it618_auction_sale_price['it618_flbl']/100));
			if($flscore>0){
				it618_auction_money('yajinjl',$it618_auction_sale['id'],$it618_auction_sale_price['it618_uid'],$flscore,$it618_auction_lang['s839'],1);
			}
			DB::query("update ".DB::table('it618_auction_sale_price')." set it618_fl=".$flscore." where id=".$it618_auction_sale_price['id']);
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			return 'success';
		}
	
	}

}
//From: Dism_taobao-com
?>