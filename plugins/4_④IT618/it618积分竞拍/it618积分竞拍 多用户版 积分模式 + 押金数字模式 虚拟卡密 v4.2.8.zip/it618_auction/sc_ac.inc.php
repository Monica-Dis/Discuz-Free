<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/sc_header.func.php';

if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_identity')." where (it618_isok1=3 or it618_isok2=3) and it618_uid=".$_G['uid'])==0){
	it618_cpmsg(it618_auction_getlang('s489'), "plugin.php?id=it618_auction:sc_identity", 'error');
}

if($_GET['key']!=''){
	$extrasql .= " and it618_name like '%".addcslashes($_GET['key'],'%_')."%'";
}

$state0='';$state1='';$state2='';$state3='';$state4='';
if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
if($_GET['state']==1){$extrasql .= " and it618_isbm = 1";$state1='selected="selected"';}
if($_GET['state']==2){$extrasql .= " and it618_isbm = 0";$state2='selected="selected"';}
if($_GET['state']==3){$extrasql .= " and it618_isaddr = 1";$state3='selected="selected"';}
if($_GET['state']==4){$extrasql .= " and it618_isaddr = 0";$state4='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';$orderby4='';
if($_GET['orderby']==0){$extrasql .= " order by it618_order desc,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$extrasql .= " order by it618_count desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$extrasql .= " order by it618_salecount desc";$orderby2='selected="selected"';}
if($_GET['orderby']==3){$extrasql .= " order by it618_views desc";$orderby3='selected="selected"';}
if($_GET['orderby']==4){$extrasql .= " order by it618_score desc";$orderby4='selected="selected"';}

$sql='&key='.$_GET['key'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." WHERE it618_pid=".$delid);

		if($salecount==0){
			$it618_picbig=DB::result_first("SELECT it618_picbig FROM ".DB::table('it618_auction_goods')." WHERE id=".$delid);
			if($it618_picbig!=$_GET['it618_picbig']){
				$tmparr=explode("source",$it618_picbig);
				$tmparr1=explode("://",$it618_picbig);
				$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
				if(file_exists($it618_picbig)){
					$result=unlink($it618_picbig);
				}
			}
			$it618_picsmall=DB::result_first("SELECT it618_picsmall FROM ".DB::table('it618_auction_goods')." WHERE id=".$delid);
			if($it618_picsmall!=$_GET['it618_picsmall']){
				$tmparr=explode("source",$it618_picsmall);
				$tmparr1=explode("://",$it618_picsmall);
				$it618_picsmall=DISCUZ_ROOT.'./source'.$tmparr[1];
				if(file_exists($it618_picsmall)){
					$result=unlink($it618_picsmall);
				}
			}
			
			$it618_message_images=DB::result_first("SELECT it618_message_images FROM ".DB::table('it618_auction_goods')." WHERE id=".$delid);
			preg_match_all("/<img([^>]*)\s*src=('|\")([^'\"]+)('|\")/",$it618_message_images,$matches);
			$new_arr=$matches[0];
			$new_arr=array_unique($new_arr);
			
			foreach($new_arr as $imgsmall){ 
				$imgsmall=str_replace('"',"",$imgsmall);
				$imgsmall=str_replace('<img alt= src=',"",$imgsmall);
				$imgsmall=str_replace('<img src=',"",$imgsmall);
				$imgbig=str_replace("s_","",$imgsmall);
				
				$tmparr=explode("source",$imgsmall);
				$imgsmall1=DISCUZ_ROOT.'./source'.$tmparr[1];
				if(file_exists($imgsmall1)){
					$result=unlink($imgsmall1);
				}
				
				$tmparr=explode("source",$imgbig);
				$imgbig1=DISCUZ_ROOT.'./source'.$tmparr[1];
				if(file_exists($imgbig1)){
					$result=unlink($imgbig1);
				}
			} 
			
			DB::delete('it618_auction_goods', "id=$delid");
			$del=$del+1;
		}
	}

	it618_cpmsg(it618_auction_getlang('s7').$del, "plugin.php?id=it618_auction:sc_ac&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_auction#it618_auction_goods')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_yajin' => intval($_GET['it618_yajin'][$id]),
				'it618_score' => intval($_GET['it618_score'][$id]),
				'it618_addprice' => intval($_GET['it618_addprice'][$id]),
				'it618_maxaddprice' => intval($_GET['it618_maxaddprice'][$id]),
				'it618_lpprice' => intval($_GET['it618_lpprice'][$id]),
				'it618_shouxufei' => intval($_GET['it618_shouxufei'][$id]),
				'it618_chujiafei' => intval($_GET['it618_chujiafei'][$id]),
				'it618_freecount' => intval($_GET['it618_freecount'][$id]),
				'it618_xiangoucount' => intval($_GET['it618_xiangoucount'][$id]),
				'it618_isbm' => $_GET['it618_isbm'][$id],
				'it618_isaddr' => $_GET['it618_isaddr'][$id],
				'it618_ison' => $_GET['it618_ison'][$id]
			));
			
			if($_GET['it618_count'][$id]!='-1'){
				C::t('#it618_auction#it618_auction_goods')->update($id,array(
					'it618_count' => intval($_GET['it618_count'][$id])
				));
			}
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_auction_getlang('s5').$ok, "plugin.php?id=it618_auction:sc_ac&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_tj')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." where id=".$delid);

		if($it618_auction_goods['it618_checkstate']==0||$it618_auction_goods['it618_checkstate']==2){
			DB::query("update ".DB::table('it618_auction_goods')." set it618_checkstate=1 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_auction_getlang('s471').$ok, "plugin.php?id=it618_auction:sc_ac&page=$page".$sql, 'succeed');
}

echo '
<link rel="stylesheet" href="source/plugin/it618_auction/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_auction/kindeditor/kindeditor-min.js"></script>
';

it618_showformheader("plugin.php?id=it618_auction:sc_ac&page=$page");
showtableheaders(it618_auction_getlang('s48'),'it618_auction_goods');
	
	echo '<tr><td colspan=14>'.it618_auction_getlang('s49').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_auction_getlang('s52').' <select name="state"><option value=0 '.$state0.'>'.it618_auction_getlang('s53').'</option><option value=1 '.$state1.'>'.it618_auction_getlang('s54').'</option><option value=2 '.$state2.'>'.it618_auction_getlang('s55').'</option><option value=3 '.$state3.'>'.it618_auction_getlang('s56').'</option><option value=4 '.$state4.'>'.it618_auction_getlang('s57').'</option></select> '.it618_auction_getlang('s62').' <select name="orderby"><option value=0 '.$orderby0.'>'.it618_auction_getlang('s63').'</option><option value=1 '.$orderby1.'>'.it618_auction_getlang('s64').'</option><option value=2 '.$orderby2.'>'.it618_auction_getlang('s65').'</option><option value=3 '.$orderby3.'>'.it618_auction_getlang('s66').'</option><option value=4 '.$orderby4.'>'.it618_auction_getlang('s67').'</option></select><input type="submit" class="btn" name="it618sercsubmit" value="'.it618_auction_getlang('s9').'" /></td></tr>';
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_goods')." WHERE it618_uid=".$_G['uid']." $extrasql");
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_auction:sc_ac".$sql);
	
	echo '<tr><td colspan=16>'.it618_auction_getlang('s68').$count.'<span style="float:right;color:red">'.it618_auction_getlang('s472').'</span></td></tr>';
	showsubtitle(array('',it618_auction_getlang('s69'),it618_auction_getlang('s71'),it618_auction_getlang('s72').'/'.it618_auction_getlang('s73'),it618_auction_getlang('s76'),it618_auction_getlang('s77'),$it618_auction_lang['s58'],it618_auction_getlang('s450')));

	$query = DB::query("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE it618_uid=".$_G['uid']." $extrasql LIMIT $startlimit, $ppp");
	$n=1;
	while($it618_auction_goods = DB::fetch($query)) {

		if($it618_auction_goods['it618_isaddr']==1)$it618_isaddr_checked='checked="checked"';else $it618_isaddr_checked="";
		if($it618_auction_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		if($it618_auction_goods['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
		
		$it618_timetype=$it618_auction_goods['it618_timetype'];
		$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
		$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
		$it618_bhour=explode(":",$it618_auction_goods['it618_bhour']);
		$it618_ehour=explode(":",$it618_auction_goods['it618_ehour']);
		
		$btime=mktime($it618_bhour[0], $it618_bhour[1], 0, $it618_bdate[1], $it618_bdate[2], $it618_bdate[0]);
		$etime=mktime($it618_ehour[0], $it618_ehour[1], 0, $it618_edate[1], $it618_edate[2], $it618_edate[0]);
		$flag=0;
		
		if($it618_timetype==1){
			if($etime>=$_G['timestamp']){
				if($btime>$_G['timestamp']){
					$flag=1;
				}else{
					$btimecur=mktime($it618_bhour[0], $it618_bhour[1], 0, date('n'), date('j'), date('Y'));
					$etimecur=mktime($it618_ehour[0], $it618_ehour[1], 0, date('n'), date('j'), date('Y'));
					if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
						$it618_color='green';
						$readonly='readonly="readonly"';
					}else{
						$flag=1;
					}
				}
				if($flag==1){
					$it618_color='blue';
				}
			}else{
				$it618_color='#ccc';
			}
		}else{
			if($etime>=$_G['timestamp']){
				if($btime>$_G['timestamp']){
					$it618_color='blue';
				}else{
					$it618_color='green';
				}
			}else{
				$it618_color='#ccc';
			}
		}
		
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_goods_km')." WHERE it618_pid=".$it618_auction_goods['id']);
		if($kmcount>0){
			$it618_count=$it618_auction_goods[it618_count].'<input type="hidden" name="it618_count['.$it618_auction_goods[id].']" value="-1"><a href="plugin.php?id=it618_auction:sc_km&pid='.$it618_auction_goods[id].'"><font color=green>'.it618_auction_getlang('s81').'</font></a>';
			$it618_isaddr_checked="";
		}else{
			$it618_count='<input type="text" class="txt" style="width:50px;margin-right:1px" name="it618_count['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_count].'"><a href="plugin.php?id=it618_auction:sc_km&pid='.$it618_auction_goods[id].'">'.it618_auction_getlang('s81').'</a>';
		}
		if($it618_auction_goods['it618_timetype']==0){
			$tmptime='<font color='.$it618_color.'>'.it618_auction_getlang('s83').$it618_auction_goods[it618_bdate].' '.$it618_auction_goods[it618_bhour].'<br>'.it618_auction_getlang('s84').$it618_auction_goods[it618_edate].' '.$it618_auction_goods[it618_ehour].'</font>';
		}else{
			$tmptime=it618_auction_getlang('s85').$it618_auction_goods[it618_bhour].it618_auction_getlang('s86').$it618_auction_goods[it618_ehour];
			$tmptime='<font color='.$it618_color.'>'.it618_auction_getlang('s83').$it618_auction_goods[it618_bdate].'<br>'.it618_auction_getlang('s84').$it618_auction_goods[it618_edate].'
			 <br>'.$tmptime.'</font>';
		}
		
		if($it618_auction_goods['it618_checkstate']==0)$it618_checkstate='<font color=red>'.it618_auction_getlang('s473').'</font>';
		if($it618_auction_goods['it618_checkstate']==1)$it618_checkstate='<font color=red>'.it618_auction_getlang('s453').'</font>';
		if($it618_auction_goods['it618_checkstate']==2)$it618_checkstate='<font color=blue>'.it618_auction_getlang('s454').'</font>';
		if($it618_auction_goods['it618_checkstate']==3)$it618_checkstate='<font color=green>'.it618_auction_getlang('s455').'</font>';
		
		if($it618_auction_goods['it618_type']==1){
			$it618_type='<font color=green><b>'.$it618_auction_lang['s761'].'</b></font> '.$it618_auction_lang['s456'].'<input type="text" class="txt" style="width:47px;color:red" name="it618_score['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_score].'">';
			$it618_flblstr=$it618_auction_lang['s673'];
		}else{
			if($IsCredits==1){
				if($it618_auction_goods['it618_paytype']==1)$paytype=$it618_auction_lang['s830'];else $paytype=$it618_auction_lang['s831'];
			}
			
			$it618_type='<font color=red><b>'.$paytype.$it618_auction_lang['s762'].'</b></font> '.$it618_auction_lang['s456'].'<input type="text" class="txt" style="width:47px;color:red" name="it618_score['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_score].'">'.$it618_auction_lang['s764'].'<input type="text" class="txt" style="width:46px;color:blue" name="it618_yajin['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_yajin].'">';
			$it618_flblstr=$it618_auction_lang['s674'];
		}

		$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." WHERE it618_pid=".$it618_auction_goods['id']);
		$salecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_sale')." WHERE it618_state=1 and it618_pid=".$it618_auction_goods['id']);
		$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_auction_goods[id].'" '.$disabled.'><label for="chk_del'.$n.'">'.$it618_auction_goods['id'].'</label>',
			'<div style="width:488px"><a href="'.$tmpurl.'" target="_blank" title="'.$it618_auction_lang['s82'].it618_auction_classname($it618_auction_goods['it618_class_id']).'" style="float:left"><img src="'.$it618_auction_goods['it618_picsmall'].'" width="115" height="80" align="absmiddle"/></a><div style="float:left;margin-left:3px;"><input type="text" class="txt" style="width:321px;margin-bottom:3px" name="it618_name['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_name].'"><a href="plugin.php?id=it618_auction:sc_editac&pid='.$it618_auction_goods[id].'">'.$it618_auction_lang['s20'].'</a><br>'.$it618_type.'<br>'.$it618_auction_lang['s458'].'<input type="text" class="txt" style="width:35px;margin-right:0" name="it618_addprice['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_addprice].'"> '.$it618_auction_lang['s459'].'<input type="text" class="txt" style="width:46px" name="it618_maxaddprice['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_maxaddprice].'">'.$it618_auction_lang['s457'].'<input type="text" class="txt" style="width:46px" name="it618_lpprice['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_lpprice].'"><br>'.$it618_auction_lang['s672'].'<font color=red><b>'.$it618_auction_goods[it618_flbl].'</b></font>% '.$it618_flblstr.'</div></div>',
			$tmptime,
			$it618_count.'<br><input type="text" class="txt" style="width:50px" name="it618_xiangoucount['.$it618_auction_goods[id].']" value="'.$it618_auction_goods[it618_xiangoucount].'"><br>'.$it618_auction_lang['s74'].$salecount.'/'.$salecountok.'<br>'.$it618_auction_lang['s75'].$it618_auction_goods[it618_views],
			'<input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_auction_goods['id'].']" '.$it618_isbm_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_addr'.$n.'" name="it618_isaddr['.$it618_auction_goods['id'].']" '.$it618_isaddr_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_auction_goods['id'].']" '.$it618_ison_checked.' value="1">',
			$it618_checkstate
		));
		$n=$n+1;
	}
	
	function it618_auction_classname($aid){
		return DB::result_first("select it618_classname from ".DB::table('it618_auction_class')." where id=".$aid);
	}
	
	if(DB::result_first("SELECT it618_ischeck FROM ".DB::table('it618_auction_identity')." where (it618_isok1=3 or it618_isok2=3) and it618_uid=".$_G['uid'])==0){
		$it618_ischeck='<input type="submit" class="btn" name="it618submit_tj" value="'.it618_auction_getlang('s474').'" />';
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkalla5nm" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkalla5nm">'.it618_auction_getlang('s463').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_auction_getlang('s464').'" onclick="return confirm(\''.it618_auction_getlang('s504').'\')" /><input type="submit" class="btn" name="it618submit" value="'.it618_auction_getlang('s465').'" />'.$it618_ischeck.' &nbsp;<input type="checkbox" id="chk_isbm" class="checkbox" onclick="check_all(this, \'chk_isbm\')" /><label for="chk_isbm">'.it618_auction_getlang('s87').'</label> <input type="checkbox" id="chk_addr" class="checkbox" onclick="check_all(this, \'chk_addr\')" /><label for="chk_addr">'.it618_auction_getlang('s88').'</label> <input type="checkbox" id="chk_ison" class="checkbox" onclick="check_all(this, \'chk_ison\')" /><label for="chk_ison">'.it618_auction_getlang('s58').'</label><br>'.it618_auction_getlang('s475').' '.$it618_auction_lang['s745'].'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

echo '<script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_auction/sc_footer.func.php';
?>