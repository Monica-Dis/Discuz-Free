<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return; /* dism - taobao - com */

loadcache('plugin');
$it618_auction = $_G['cache']['plugin']['it618_auction'];

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/function/it618_auction.func.php';

if($reabc[8]!='c')return; /*dism��taobao��com*/
$ppp = $it618_auction['pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier']; /* DISM _ TAOBAO _ COM */
$urls = '&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_focus', 'admin_set', 'admin_gonggao', 'admin_kd', 'admin_rewrite', 'admin_message', 'admin_bottomnav');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_focus' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

$cp1=$_GET['cp1'];

$admin_set_title[1]=$it618_auction_lang['s1072'];
$admin_set_title[2]=$it618_auction_lang['s810'];
$admin_set_title[3]=$it618_auction_lang['s811'];
$admin_set_title[4]=$it618_auction_lang['s812'];
$admin_set_title[5]=$it618_auction_lang['s533'];
$admin_set_title[6]=$it618_auction_lang['s811'];
$admin_set_title[7]=$it618_auction_lang['s1072'];

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		if($cp!='admin_set'){
			$strtmp[]='class="current"';
		}else{
			$admin_set[$cp1]='class="current"';
		}
	}else{
		$strtmp[]='';
	}
}

if($IsCredits==1){
	$admin_set_title[3]=$it618_auction_lang['s830'].$admin_set_title[3];
	$admin_set_title[6]=$it618_auction_lang['s831'].$admin_set_title[6];
	$admin_set_title[1]=$it618_auction_lang['s830'].$admin_set_title[1];
	$admin_set_title[7]=$it618_auction_lang['s831'].$admin_set_title[7];
}else{
	$tmpcss=' style="display:none"';
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_focus'.$urls.'"><span>'.$it618_auction_lang['s492'].'</span></a></li>
<li '.$admin_set[1].'><a href="'.$hosturl.'plugins&cp=admin_set'.$urls.'&cp1=1"><span>'.$admin_set_title[1].'</span></a></li>
<li '.$admin_set[7].$tmpcss.'><a href="'.$hosturl.'plugins&cp=admin_set'.$urls.'&cp1=7"><span>'.$admin_set_title[7].'</span></a></li>
<li '.$admin_set[2].'><a href="'.$hosturl.'plugins&cp=admin_set'.$urls.'&cp1=2"><span>'.$admin_set_title[2].'</span></a></li>
<li '.$admin_set[3].'><a href="'.$hosturl.'plugins&cp=admin_set'.$urls.'&cp1=3"><span>'.$admin_set_title[3].'</span></a></li>
<li '.$admin_set[6].$tmpcss.'><a href="'.$hosturl.'plugins&cp=admin_set'.$urls.'&cp1=6"><span>'.$admin_set_title[6].'</span></a></li>
<li '.$admin_set[4].'><a href="'.$hosturl.'plugins&cp=admin_set'.$urls.'&cp1=4"><span>'.$admin_set_title[4].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_gonggao'.$urls.'"><span>'.$it618_auction_lang['s747'].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_kd'.$urls.'"><span>'.$it618_auction_lang['s494'].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_rewrite'.$urls.'"><span>'.$it618_auction_lang['s495'].'</span></a></li>
<li '.$strtmp[5].'><a href="'.$hosturl.'plugins&cp=admin_message'.$urls.'"><span>'.$it618_auction_lang['s496'].'</span></a></li>
<li '.$admin_set[5].'><a href="'.$hosturl.'plugins&cp=admin_set'.$urls.'&cp1=5"><span>'.$admin_set_title[5].'</span></a></li>
<li '.$strtmp[6].'><a href="'.$hosturl.'plugins&cp=admin_bottomnav'.$urls.'"><span>'.$it618_auction_lang['s534'].'</span></a></li>
</ul></div>';

if($cp1==1)$setname='payabout';
if($cp1==2)$setname='jfmodeabout';
if($cp1==3)$setname='yjmodeabout';
if($cp1==6)$setname='xjyjmodeabout';
if($cp1==7)$setname='xjpayabout';
if($cp1==4)$setname='plabout';
if($cp1==5)$setname='waphomead';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*Dism_taobao_com*/
?>