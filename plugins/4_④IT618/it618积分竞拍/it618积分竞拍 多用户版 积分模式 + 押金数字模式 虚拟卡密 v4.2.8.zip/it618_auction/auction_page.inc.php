<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_auction/auction_default.func.php';

$pid=intval($_GET['pid']);

if(!($it618_auction_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_auction_goods')." WHERE it618_ison=1 and id=".$pid))){
	$tmpurl=it618_auction_getrewrite('auction_wap','','plugin.php?id=it618_auction:wap');
	dheader("location:$tmpurl");
}

if(auction_is_mobile()){ 
	$tmpurl=it618_auction_getrewrite('auction_wap','product@'.$pid.'@0','plugin.php?id=it618_auction:wap&pagetype=product&cid='.$pid);
	dheader("location:$tmpurl");
}

timeok($pid);
$it618_classname=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_auction_class')." where id=".$it618_auction_goods['it618_class_id']);
$it618_timetype=$it618_auction_goods['it618_timetype'];
$it618_bdate=explode("-",$it618_auction_goods['it618_bdate']);
$it618_edate=explode("-",$it618_auction_goods['it618_edate']);
if($it618_timetype==1){
	$it618_time=$it618_bdate[0].it618_auction_getlang('s111').$it618_bdate[1].it618_auction_getlang('s112').$it618_bdate[2].it618_auction_getlang('s198').$it618_edate[0].it618_auction_getlang('s111').$it618_edate[1].it618_auction_getlang('s112').$it618_edate[2].it618_auction_getlang('s113').' <font color=red>'.$it618_auction_goods['it618_bhour'].'-'.$it618_auction_goods['it618_ehour'].'</font> '.it618_auction_getlang('s199');
}else{
	$it618_time=$it618_bdate[0].it618_auction_getlang('s111').$it618_bdate[1].it618_auction_getlang('s112').$it618_bdate[2].''.it618_auction_getlang('s113').' <font color=red>'.$it618_auction_goods['it618_bhour'].'</font> '.it618_auction_getlang('s86').' '.$it618_edate[0].it618_auction_getlang('s111').$it618_edate[1].it618_auction_getlang('s112').$it618_edate[2].it618_auction_getlang('s113').' <font color=red>'.$it618_auction_goods['it618_ehour'].'</font> '.it618_auction_getlang('s199');
}

if($it618_auction['auction_addwhytime']>0){
	$it618_auction_lang['s809']=str_replace("{addwhytime}",$it618_auction['auction_addwhytime'],$it618_auction_lang['s809']);
	$it618_auction_lang['s809']=str_replace("{addtime}",$it618_auction['auction_addtime'],$it618_auction_lang['s809']);
	$it618_time.=' '.$it618_auction_lang['s809'];
}

$it618_about=str_replace("{pname}",$it618_auction_goods['it618_name'],$it618_auction_goods['it618_about']);

DB::query("update ".DB::table('it618_auction_goods')." set it618_views=it618_views+1 WHERE id=".$pid);
$plcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_pl')." where it618_pid=".$pid);

$query = DB::query("SELECT * FROM ".DB::table('it618_auction_goods')." where it618_ison=1 order by it618_salecount desc LIMIT 0, ".$it618_auction['auction_pagehotcount']);
while($it618_auction_goods_hotlist = DB::fetch($query)) {
	$tmpurl=it618_auction_getrewrite('auction_product',$it618_auction_goods_hotlist['id'],'plugin.php?id=it618_auction:auction_page&pid='.$it618_auction_goods_hotlist['id']);
	$hotlist.='<li>
				  <a href="'.$tmpurl.'" target="_blank">
					  <img src="'.$it618_auction_goods_hotlist['it618_picsmall'].'"/>
				  </a>
				  <p class="desc"><a href="'.$tmpurl.'" target="_blank">'.$it618_auction_goods_hotlist['it618_name'].'</a></p>
			  </li>';
}

if($it618_auction['auction_hideclass']==0){
	$classid=DB::result_first("SELECT it618_class_id FROM ".DB::table('it618_auction_goods')." WHERE id=".$pid);
	$classname=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_auction_class')." WHERE id=".$classid);
	
	$it618_title='<span>'.$classname.'</span><span class="split">&gt;</span><span>'.$it618_auction_goods['it618_name'].'</span>';
}else{
	$it618_title='<span>'.$it618_auction_goods['it618_name'].'</span>';
}

if($it618_auction_goods['it618_type']==1){
	$it618_type='<font color=green>'.$it618_auction_lang['s761'].'</font>';
	$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
	$it618_flbl='<font color=#999>'.$it618_auction_lang['s672'].'</font><font color="#FF3300"><b>'.$it618_auction_goods['it618_flbl'].'</b></font> % <font color=#666>'.$it618_auction_lang['s673'].'</font>';
	
	$jfmodeabout=C::t('#it618_auction#it618_auction_set')->getsetvalue_by_setname('jfmodeabout');
	if($jfmodeabout==''){
		$aboutstr=$it618_auction_lang['s675'];
	}else{
		$aboutstr=$jfmodeabout;
	}
}else{
	$creditname=$_G['setting']['extcredits'][$it618_auction['auction_credit_yj']]['title'];
	if($IsCredits==1){
		if($it618_auction_goods['it618_paytype']==1){
			$paytype=$it618_auction_lang['s830'];
			$yjmodeabout=C::t('#it618_auction#it618_auction_set')->getsetvalue_by_setname('yjmodeabout');
			if($yjmodeabout==''){
				$aboutstr=$it618_auction_lang['s676'];
			}else{
				$aboutstr=$yjmodeabout;
			}
			$yajinunit=$creditname;
		}else{
			$paytype=$it618_auction_lang['s831'];
			$yjmodeabout=C::t('#it618_auction#it618_auction_set')->getsetvalue_by_setname('xjyjmodeabout');
			if($yjmodeabout==''){
				$aboutstr=$it618_auction_lang['s677'];
			}else{
				$aboutstr=$yjmodeabout;
			}
			$yajinunit=$it618_auction_lang['s432'];
		}
	}
	$it618_type='<font color=red>'.$paytype.$it618_auction_lang['s762'].'</font>';
	
	$it618_flbl='<font color=#999>'.$it618_auction_lang['s672'].'</font><font color="#FF3300"><b>'.$it618_auction_goods['it618_flbl'].'</b></font> % <font color=#666>'.$it618_auction_lang['s674'].'</font>';
}

if($it618_auction_goods['it618_type']==1){
	$creditnametmp=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
}else{
	$creditnametmp=$it618_auction_lang['s432'];
}

if($it618_auction['auction_ispl']!=3)$plabout=C::t('#it618_auction#it618_auction_set')->getsetvalue_by_setname('plabout');

$it618_auction_goods['it618_message']=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="700" height="452" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_auction_goods['it618_message']);

preg_match_all("/<img([^>]*)\s*src=('|\")([^'\"]+)('|\")/",$it618_auction_goods['it618_message_images'],$matches);
$new_arr=$matches[0];
//$new_arr=array_unique($new_arr);

$n=1;
if(count($new_arr)>=6){
	foreach($new_arr as $imgsmall){ 
		if($n>6)break;
		$imgsmall=str_replace('"',"",$imgsmall);
		$imgsmall=str_replace('<img alt= src=',"",$imgsmall);
		$imgsmall=str_replace('<img src=',"",$imgsmall);
		$imgbig=str_replace("s_","",$imgsmall);
		
		$tmparr=explode("source",$imgbig);
		$imgbig1=DISCUZ_ROOT.'./source'.$tmparr[1];

		$imgsize=@getimagesize($imgbig1);
		
		$imagesstr.='<figure itemprop="associatedMedia">
		  <a href="'.$imgbig.'" itemprop="contentUrl" data-size="'.$imgsize[0].'x'.$imgsize[1].'">
			  <img src="'.$imgsmall.'" itemprop="thumbnail" alt="Image description" />
		  </a>                            
		</figure>';
		
		$n=$n+1;
	} 
}

if($it618_auction_goods['it618_type']==1){
	$creditnametmp=$_G['setting']['extcredits'][$it618_auction['auction_credit']]['title'];
}else{
	$creditnametmp=$it618_auction_lang['s432'];
}

$salecount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_auction_sale')." where it618_state!=0 and it618_pid=".$pid);

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$it618_credits_czmoney=it618_credits_getcredits($_GET['id'],'#moneyczbtn','plugin.php?id=it618_credits:do&dotype=moneycz').'<div id="moneyczbtn" style="display:none"></div>';
}

$pagetype='page';
$navtitle=$it618_auction_goods['it618_name'].' - '.$navtitle;
include template('it618_auction:auction_default');
?>