<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_auction/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_auction/rewrite.php',DISCUZ_ROOT.'./source/plugin/it618_auction/config/rewrite.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_auction/message.php',DISCUZ_ROOT.'./source/plugin/it618_auction/config/message.php');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_auction_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_tel` varchar(100) NOT NULL,
  `it618_password` varchar(100) NOT NULL,
  `it618_Body` mediumtext NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_sale_pricetmp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_salework` (
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_tip` varchar(1000) NOT NULL,
  `it618_is` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_identity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_qq` varchar(100) NOT NULL,
  `it618_sfzid` varchar(50) NOT NULL,
  `it618_sfzpic` varchar(100) NOT NULL,
  `it618_gsname` varchar(100) NOT NULL,
  `it618_gsqq` varchar(100) NOT NULL,
  `it618_yyzzid` varchar(50) NOT NULL,
  `it618_frsfzpic` varchar(100) NOT NULL,
  `it618_yyzzpic` varchar(100) NOT NULL,
  `it618_isok1` int(10) unsigned NOT NULL,
  `it618_isok2` int(10) unsigned NOT NULL,
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_tcbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_num1` int(10) unsigned NOT NULL,
  `it618_num2` int(10) unsigned NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_auction_addr`;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_msgisok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_auction_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_auction_class'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_ishide', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_class')." add `it618_ishide` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_auction_identity'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_bl', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_identity')." add `it618_bl` float(9,2) NOT NULL default 0;";
	DB::query($sql); 
}

if(!in_array('it618_bl_yj', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_identity')." add `it618_bl_yj` float(9,2) NOT NULL default 0;";
	DB::query($sql); 
}

if(!in_array('it618_mode', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_identity')." add `it618_mode` int(10) unsigned NOT NULL DEFAULT '1';";
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_auction_goods'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_timetype', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_timetype` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_shouxufei', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_shouxufei` int(10) unsigned NOT NULL default 5;"; 
	DB::query($sql); 
}
if(!in_array('it618_chujiafei', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_chujiafei` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_freecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_freecount` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_addprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_addprice` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_maxaddprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_maxaddprice` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_lpprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_lpprice` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_orderbystate', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_orderbystate` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_orderbytime', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_orderbytime` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_uid', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_uid` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_checkstate', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_checkstate` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
	DB::query("update ".DB::table('it618_auction_goods')." set it618_checkstate=3"); 
}
if(!in_array('it618_flbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_flbl` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql);
}
if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_type` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_paytype', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_paytype` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_yajin', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_yajin` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_message_images', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_goods')." add `it618_message_images` mediumtext NOT NULL;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_auction_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_addtime', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale')." add `it618_addtime` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('it618_bl', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale')." add `it618_bl` float(9,2) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_blscore', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale')." add `it618_blscore` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('it618_postuid', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale')." add `it618_postuid` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale')." add `it618_type` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_auction_sale_price'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_shouxufei', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale_price')." add `it618_shouxufei` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_chujiafei', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale_price')." add `it618_chujiafei` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_flbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale_price')." add `it618_flbl` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql);
}
if(!in_array('it618_fl', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale_price')." add `it618_fl` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql);
}
if(!in_array('it618_yajin', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale_price')." add `it618_yajin` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_sale_price')." add `it618_type` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_auction_message'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_uid', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_message')." add `it618_uid` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_auction_identity'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_ischeck', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_identity')." add `it618_ischeck` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_auction_user'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_msgisok', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_user')." add `it618_msgisok` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

$sql = <<<EOF
INSERT INTO `pre_it618_auction_wapstyle` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#fd9e2d', '#e8922b', 0),
(2, '#fc4646', '#f43131', 1),
(3, '#5ebe00', '#56aa04', 0),
(4, '#23b8ff', '#12a8ff', 0),
(5, '#fb23cb', '#ea11ba', 0),
(6, '#2dbeae', '#00a795', 0),
(8, '#fe5400', '#d04906', 0),
(7, '#999a9b', '#8d8f90', 0);
EOF;

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_auction_wapstyle'))==0){
	runquery($sql);	
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_auction_bottomnav'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_curimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_auction_bottomnav')." add `it618_curimg` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE; /*http://t.cn/Aiux1012*/
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2F1Y3Rpb24vZGlzY3V6X3BsdWdpbl9pdDYxOF9hdWN0aW9uX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('c291cmNlL3BsdWdpbi9pdDYxOF9hdWN0aW9uL2luc3RhbGwucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('c291cmNlL3BsdWdpbi9pdDYxOF9hdWN0aW9uL3VwZ3JhZGUucGhw'));
?>