<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_tuan;

$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$creditname=$_G['setting']['extcredits'][$it618_tuan['tuan_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';

$cache_file = DISCUZ_ROOT.'./source/plugin/it618_tuan/cache.php';
$tmptime=3;

if(($_G['timestamp'] - @filemtime($cache_file)) > $tmptime) {
	
	@$fp = fopen($cache_file,"w");
	fwrite($fp,$_G['timestamp']);
	fclose($fp);
	
	foreach(C::t('#it618_tuan#it618_tuan_shop')->fetch_all_by_search("it618_htstate<>0 and it618_uid>0") as $it618_tuan_shoptmp) {
		$isviptbtime=0;
		if($IsGroup==1){
			if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('tuan',0)){
				if($it618_group_rzmoney['it618_istbtime']==1){
					$isviptbtime=1;
					if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$it618_tuan_shoptmp['it618_uid'])){
						if($_G['timestamp']>=$it618_group_group_user['it618_etime']){
							C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($it618_tuan_shoptmp['id'],2);
						}else{
							C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($it618_tuan_shoptmp['id'],1);
						}
					}else{
						C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($it618_tuan_shoptmp['id'],2);
					}
				}
			}
		}
		
		if($isviptbtime==0){
			if($_G['timestamp']>=$it618_tuan_shoptmp['it618_htetime']){
				C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($it618_tuan_shoptmp['id'],2);
			}else{
				C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($it618_tuan_shoptmp['id'],1);
			}
		}
	}

}

function it618_tuan_getisvipuser($vipgroupids){
	global $_G,$it618_tuan,$it618_tuan_lang;
	
	$okvipgroupids = array(array(),array());
	
	if(count($vipgroupids)>0){

		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
	
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$expgrouparray = $expirylist = $termsarray = array();
	
		if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
			$termsarray = $groupterms['ext'];
		}
		if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
			$termsarray[$_G['groupid']] = $groupterms['main']['time'];
		}
		
		foreach($termsarray as $expgroupid => $expiry) {
			if($expiry <= TIMESTAMP) {
				$expgrouparray[] = $expgroupid;
			}
		}
	
		$groupids = array();
		foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
			if(!empty($usergroup['pubtype'])) {
				$groupids[] = $groupid;
			}
		}
		
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
			}
		}
		
		if(!empty($groupterms['main'])) {
			$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
		}
		
		$expiryids = array_keys($expirylist);
		$groupids = array_merge($extgroupids, $expiryids, $groupids);
		
		if($groupids) {
			foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
				$groupid=$group['groupid'];
				
				if(in_array($groupid, $vipgroupids)){
					
					$isgroupok=1;
					if($group['type']!='system'&&$group['type']!='member'){
						$timestamp=$expirylist[$group['groupid']]['timestamp'];
						$grouptime=$expirylist[$group['groupid']]['time'];
						
						if($timestamp-3600*24*365*60>$_G['timestamp']||$grouptime==''){
							$grouptime=$it618_tuan_lang['s938'];
						}
						
						if($timestamp<$_G['timestamp']){
							$isgroupok=0;
						}
					}else{
						$grouptime='';
					}
					if($isgroupok==1){
						$okvipgroupids[0][]=$groupid;
						$okvipgroupids[1][]=$grouptime;
					}
				}
			}
		}
		
		if(in_array($_G['groupid'], $vipgroupids)){
			$okvipgroupids[0][]=$_G['groupid'];
			$okvipgroupids[1][]='';
		}

	}
	
	return $okvipgroupids;
}

function it618_tuan_getvipzk($pid){
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='tuan' and it618_pid=$pid and it618_zk>0 order by it618_zk");
	while($it618_group_group_zk = DB::fetch($query)) {
		$vipzkgroupids[] = $it618_group_group_zk['it618_groupid'];
		
		$okvipgroupids=it618_tuan_getisvipuser($vipzkgroupids);
		if(in_array($it618_group_group_zk['it618_groupid'], $okvipgroupids[0])){
			return $it618_group_group_zk['it618_zk'];
		}
	}
	return 0;
}

function it618_tuan_groupsalepower($pid){
	$vipgroupids_zk = array();$vipgroupids_sale = array();
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_salepower')." where it618_shoptype='tuan' and it618_pid=$pid and it618_isok=1");
	while($it618_group_group_salepower = DB::fetch($query)) {
		if(!in_array($it618_group_group_salepower['it618_groupid'], $vipgroupids_sale)){
			$vipgroupids_sale[]=$it618_group_group_salepower['it618_groupid'];
		}
	}
	
	if(count($vipgroupids_sale)>0){
		$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='tuan' and it618_pid=$pid and it618_zk>0");
		while($it618_group_group_zk = DB::fetch($query)) {
			if(!in_array($it618_group_group_zk['it618_groupid'], $vipgroupids_zk)){
				$vipgroupids_zk[]=$it618_group_group_zk['it618_groupid'];
			}
		}
		
		$vipgroupids=array_merge($vipgroupids_zk,$vipgroupids_sale);
	
		$okvipgroupids=it618_tuan_getisvipuser($vipgroupids);
		
		if(count($okvipgroupids[0])==0){
			if(count($vipgroupids_zk)>0){
				return 2;
			}else{
				return 1;
			}
		}
	}
}

function it618_tuan_pay($type,$title){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		return;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype();
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		if($type=='pay'){
			$paystr='<span id="payselect">'.$tmpstr.'</span>';
		}
		
		if($type=='paywap'){
			$paystr='<span id="payselect">'.$tmpstr.'</span>';
		}
		
		if($type=='gwc'){
			$paystr='<div class="buy-block" id="payselect" style="display:none">
					<div class="buy-block-title"><h3>'.$title.'</h3></div>
					<div style="padding:10px">'.$tmpstr.'</div>
					</div>';
		}
		
		if($type=='gwcwap'){
			$paystr='<span id="payselect">'.$tmpstr.'</span>';
		}
	}else{
		$paystr=$tmpstr.'<span id="payselect"></span>';
	}
    
	return $paystr;
}

function it618_tuan_getkd($saletype,$saleid,$kdcomid,$kdid){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kd.func.php')){
		return $kdid;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/kd.func.php';
	
	return GetKD($saletype,$saleid,$kdcomid,$kdid);
}

function it618_tuan_setcode($saleid){
	global $it618_tuan;
	$flag=0;
	
	while($flag==0){
		$tmparr=explode(":",date('Y-m-d H:i:s',time()));
		
		$n=3;
		while($n<=$it618_tuan['tuan_codecount']){
			$tmpstr.=rand(0,9);
			$n=$n+1;
		}
		$tmpstr=$tmpstr.$tmparr[2];
		
		if(C::t('#it618_tuan#it618_tuan_sale')->count_by_it618_code($tmpstr)==0){
			C::t('#it618_tuan#it618_tuan_sale')->update_it618_code($saleid,$tmpstr);
			$flag=1;
		}
	}
}

function it618_tuan_get_contents4($str){
	return dfsockopen($str);
}

function it618_tuan_setkm($saleid){
	global $_G,$it618_tuan;
	
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($saleid);
	if($it618_tuan_sale['it618_gtypeid']>0){
		$query1 = DB::query("select * from ".DB::table('it618_tuan_goods_type_km')." WHERE it618_gtypeid=".$it618_tuan_sale['it618_gtypeid']." limit 0,".$it618_tuan_sale['it618_count']);
		while($it618_tuan_goods_type_km = DB::fetch($query1)) {
			$id = C::t('#it618_tuan#it618_tuan_goods_salekm')->insert(array(
				'it618_saleid' => $saleid,
				'it618_code' => $it618_tuan_goods_type_km['it618_code']
			), true);
			if($id>0)DB::query("delete from ".DB::table('it618_tuan_goods_type_km')." where id=".$it618_tuan_goods_type_km['id']);
		}
	}else{
		$query1 = DB::query("select * from ".DB::table('it618_tuan_goods_km')." WHERE it618_pid=".$it618_tuan_sale['it618_pid']." limit 0,".$it618_tuan_sale['it618_count']);
		while($it618_tuan_goods_km = DB::fetch($query1)) {
			$id = C::t('#it618_tuan#it618_tuan_goods_salekm')->insert(array(
				'it618_saleid' => $saleid,
				'it618_code' => $it618_tuan_goods_km['it618_code']
			), true);
			if($id>0)DB::query("delete from ".DB::table('it618_tuan_goods_km')." where id=".$it618_tuan_goods_km['id']);
		}
	}
	
	it618_tuan_qrxf($saleid);
}

function it618_tuan_qrxf($saleid){
	global $_G,$it618_tuan;
	
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($saleid);
	C::t('#it618_tuan#it618_tuan_sale')->update_it618_state($saleid,3);
	C::t('#it618_tuan#it618_tuan_sale')->update_it618_code($saleid,'');
	
	$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_sale['it618_shopid']);
	$ShopTCBL=$it618_tuan_shop['it618_tcbl'];
	
	$allmoney=$it618_tuan_sale['it618_sfmoney'];
	$tcmoney=round((($ShopTCBL*$allmoney)/100), 2);

	$it618_money=$allmoney-$tcmoney;
	
	DB::query("update ".DB::table('it618_tuan_sale')." set it618_tcbl=".$ShopTCBL.",it618_tc=".$tcmoney." where id=".$saleid);
	
	if($it618_money>0)DB::query("update ".DB::table('it618_tuan_shop')." set it618_money=it618_money+".$it618_money." where id=".$it618_tuan_sale['it618_shopid']);
	
	C::t('common_member_count')->increase($it618_tuan_sale['it618_uid'], array(
		'extcredits'.$it618_tuan['tuan_credit'] => $it618_tuan['tuan_salejlcount'])
	);
	DB::query("update ".DB::table('it618_tuan_sale')." set it618_salejl=".$it618_tuan['tuan_salejlcount']." where id=".$saleid);
	
	if($it618_tuan_sale['it618_score']>0){
		$tmpscore=$it618_tuan_sale['it618_sfscore']-intval($ShopTCBL*$it618_tuan_sale['it618_sfscore']/100);
		C::t('common_member_count')->increase($it618_tuan_shop['it618_uid'], array(
			'extcredits'.$it618_tuan_sale['it618_jfid'] => $tmpscore)
		);
	}
	
	if($it618_tuan_sale['it618_yunfeiscore']>0){
		$tmpscore=$it618_tuan_sale['it618_yunfeiscore']-intval($ShopTCBL*$it618_tuan_sale['it618_yunfeiscore']/100);
		C::t('common_member_count')->increase($it618_tuan_shop['it618_uid'], array(
			'extcredits'.$it618_tuan_sale['it618_yunfeijfid'] => $tmpscore)
		);
	}
	
	if($it618_tuan_sale['it618_jfbl']>0){
		$it618_jfbl=intval($it618_tuan_sale['it618_jfbl']*$it618_tuan_sale['it618_sfmoney']/100);
		C::t('common_member_count')->increase($it618_tuan_sale['it618_uid'], array(
			'extcredits'.$it618_tuan['tuan_credit'] => $it618_jfbl)
		);
		C::t('common_member_count')->increase($it618_tuan_shop['it618_uid'], array(
			'extcredits'.$it618_tuan['tuan_credit'] => (0-$it618_jfbl))
		);
	}
	
	if($it618_tuan_sale['it618_tuijid']>0){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
		Union_TuiTC_OK($saleid,$it618_tuan_shop['it618_uid']);
	}

	$tmpmoney=$it618_tuan_sale['it618_sfmoney'];
	
	if($tmpmoney>0){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
		}
		
		if($union_tuan_isok==1&&$tmpmoney>=$union_tuan_money){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			Union_SaleTC('it618_tuan',$tmpmoney,$it618_tuan_sale['id'],$it618_tuan_sale['it618_uid']);
		}
	}
}

function it618_tuan_get_contents5($str){
	return dfsockopen($str);
}

function it618_tuan_getpaystr($it618_paytype,$it618_payid){
	global $_G,$it618_tuan_lang;
	
	if($it618_paytype=='alipay'){
		$it618_payid='<a href="https://lab.alipay.com/consume/queryTradeDetail.htm?tradeNo='.$it618_payid.'" target="_blank">'.$it618_payid.'</a>';
	}
	
	if($it618_paytype=='alipay')$it618_paytype=$it618_tuan_lang['s1947'];
	if($it618_paytype=='wxwap'||$it618_paytype=='wxcode'||$it618_paytype=='wxh5'||$it618_paytype=='Appbyme')$it618_paytype=$it618_tuan_lang['s1948'];
	if($it618_paytype=='MAGAPPX')$it618_paytype=$it618_tuan_lang['s1949'];
	if($it618_paytype=='epay')$it618_paytype=$it618_tuan_lang['s1950'];
	if($it618_paytype=='money')$it618_paytype=$it618_tuan_lang['s1951'];
	
	$paystr=$it618_paytype.$it618_payid;
	
	return $paystr;
}

function it618_tuan_getjftype($jfid=0){
	global $_G,$it618_tuan_lang;
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_jfhl')." where it618_isok=1 ORDER BY it618_order");
	while($it618_tuan_jfhl = DB::fetch($query)) {
		$jfname=$_G['setting']['extcredits'][$it618_tuan_jfhl['it618_jfid']]['title'];
		
		if($jfname!=''){
			if($jfid==$it618_tuan_jfhl['it618_jfid'])$selectedstr='selected="selected"';else $selectedstr='';
			$tmpstr.='<option value="'.$it618_tuan_jfhl['it618_jfid'].'" '.$selectedstr.'>'.$jfname.'</option>';
		}
	}
	
	return '<option value="0">'.$it618_tuan_lang['s17'].'</option>'.$tmpstr;
}

function it618_tuan_getgoodsprice($it618_tuan_goods){
	global $_G,$it618_tuan;
	
	$it618_tuan_goods['it618_saleprice']=floatval($it618_tuan_goods['it618_saleprice']);
	
	if($it618_tuan_goods['it618_saleprice']>0&&$it618_tuan_goods['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_tuan_goods['it618_jfid']]['title'];
		$goodspricestr='<em>&yen;</em>'.$it618_tuan_goods['it618_saleprice'].'+'.$it618_tuan_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
	}else{
		if($it618_tuan_goods['it618_saleprice']>0){
			$goodspricestr='<em>&yen;</em>'.$it618_tuan_goods['it618_saleprice'];
		}
		
		if($it618_tuan_goods['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_tuan_goods['it618_jfid']]['title'];
			$goodspricestr=$it618_tuan_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
		}
	}
	
	return $goodspricestr;
}

function it618_tuan_getsaleprice($it618_tuan_sale){
	global $_G,$it618_tuan,$it618_tuan_lang;
	
	$it618_tuan_sale['it618_price']=floatval($it618_tuan_sale['it618_price']);
	
	if($it618_tuan_sale['it618_price']>0&&$it618_tuan_sale['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
		$goodspricestr=$it618_tuan_sale['it618_price'].$it618_tuan_lang['s125'].'+'.$it618_tuan_sale['it618_score'].$goodsjfname;
	}else{
		if($it618_tuan_sale['it618_price']>0){
			$goodspricestr=$it618_tuan_sale['it618_price'].$it618_tuan_lang['s125'];
		}
		
		if($it618_tuan_sale['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
			$goodspricestr=$it618_tuan_sale['it618_score'].$goodsjfname;
		}
	}
	
	return $goodspricestr;
}

function it618_tuan_getsalemoney($it618_tuan_sale,$tmpstr,$pay=''){
	global $_G,$it618_tuan,$it618_tuan_lang;
	
	$yunfeistr='0';
	if($it618_tuan_sale['it618_yunfei']>0&&$it618_tuan_sale['it618_yunfeiscore']>0){
		$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_yunfeijfid']]['title'];
		$yunfeistr=$it618_tuan_sale['it618_yunfei'].$it618_tuan_lang['s125'].'+'.$it618_tuan_sale['it618_yunfeiscore'].''.$jfname;
		
		$sumscore[$it618_tuan_sale['it618_yunfeijfid']]+=$it618_tuan_sale['it618_yunfeiscore'];
	}else{
		if($it618_tuan_sale['it618_yunfei']>0){
			$yunfeistr=$it618_tuan_sale['it618_yunfei'].$it618_tuan_lang['s125'];
		}
		
		if($it618_tuan_sale['it618_yunfeiscore']>0){
			$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_yunfeijfid']]['title'];
			$yunfeistr=$it618_tuan_sale['it618_yunfeiscore'].''.$jfname;
			
			$sumscore[$it618_tuan_sale['it618_yunfeijfid']]+=$it618_tuan_sale['it618_yunfeiscore'];
		}
	}
	
	if($it618_tuan_sale['it618_price']>0&&$it618_tuan_sale['it618_score']>0){
		$allmoney=$it618_tuan_sale['it618_price']*$it618_tuan_sale['it618_count']+$it618_tuan_sale['it618_yunfei'];
		
		$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
		$moneystr=($it618_tuan_sale['it618_price']*$it618_tuan_sale['it618_count']).$it618_tuan_lang['s125'].'+'.($it618_tuan_sale['it618_score']*$it618_tuan_sale['it618_count']).''.$jfname;
		
		$sumscore[$it618_tuan_sale['it618_jfid']]+=$it618_tuan_sale['it618_score']*$it618_tuan_sale['it618_count'];
	}else{
		if($it618_tuan_sale['it618_price']>0){
			$allmoney=$it618_tuan_sale['it618_price']*$it618_tuan_sale['it618_count']+$it618_tuan_sale['it618_yunfei'];
			
			$moneystr=($it618_tuan_sale['it618_price']*$it618_tuan_sale['it618_count']).$it618_tuan_lang['s125'];
		}
		
		if($it618_tuan_sale['it618_score']>0){
			$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
			$moneystr=($it618_tuan_sale['it618_score']*$it618_tuan_sale['it618_count']).''.$jfname;
			
			$sumscore[$it618_tuan_sale['it618_jfid']]+=$it618_tuan_sale['it618_score']*$it618_tuan_sale['it618_count'];
		}
	}
	
	for($i=1;$i<=8;$i++){
		if($sumscore[$i]>0){
			$jfname=$_G['setting']['extcredits'][$i]['title'];
			
			$scorestr.=$sumscore[$i].$jfname.'+';
		}
	}
	
	if($scorestr!=''){
		$scorestr.='@';
		$scorestr=str_replace('+@',"",$scorestr);
	}
	
	$allmoney=$allmoney-$it618_tuan_sale['it618_quanmoney'];
	
	if($allmoney>0&&$scorestr!=''){
		$allmoneystr='<span style="font-family:arial;">&yen;</span>'.$allmoney.'+'.$scorestr;
		$moneyscore=1;
	}else{
		if($allmoney>0){
			$allmoneystr='<span style="font-family:arial;">&yen;</span>'.$allmoney;
		}
		if($scorestr!=''){
			$allmoneystr=$scorestr;
		}
	}
	
	$alertstr=$it618_tuan_lang['s797'].$moneystr.'\n\n'.$it618_tuan_lang['s798'].$yunfeistr.'\n\n'.$it618_tuan_lang['s795'].$it618_tuan_sale['it618_quanmoney'].$it618_tuan_lang['s125'];
	
	if($pay!=''&&$allmoney>0){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		$paystr=getpaystr($it618_tuan_sale['it618_gwcid'],$it618_tuan_sale['id'],'tuan');
		$paystr='<a href="javascript:" class="saleabtn" onclick="alert(\''.$paystr.'\')">'.$it618_tuan_lang['s821'].'</a>';
	}
	
	return $allmoneystr.$tmpstr.'<a href="javascript:" class="saleabtn" onclick="alert(\''.$alertstr.'\')">'.$it618_tuan_lang['s364'].'</a> '.$paystr;
}

function it618_tuan_get_contents3($str){
	return dfsockopen($str);
}

function it618_tuan_updategoodscount($it618_tuan_sale,$type=''){
	if($it618_tuan_sale['it618_saletype']==3){
		  if($it618_tuan_sale['it618_gtypeid']>0){
			  $salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_gtypeid($it618_tuan_sale['it618_gtypeid']);
			  if($salecount=='')$salecount=0;
			  
			  $it618_count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_type_km')." WHERE it618_gtypeid=".$it618_tuan_sale['it618_gtypeid']);
			  DB::query("update ".DB::table('it618_tuan_goods_type')." set it618_salecount=".$salecount.",it618_count=".$it618_count." where id=".$it618_tuan_sale['it618_gtypeid']);
			  
			  $it618_count=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_count_by_pid($it618_tuan_sale['it618_pid']);
		  }else{
			  $it618_count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_km')." WHERE it618_pid=".$it618_tuan_sale['it618_pid']);
		  }
		  
		  $salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_pid($it618_tuan_sale['it618_pid']);
		  if($salecount=='')$salecount=0;
		  
		  DB::query("update ".DB::table('it618_tuan_goods')." set it618_salecount=".$salecount.",it618_count=".$it618_count." where id=".$it618_tuan_sale['it618_pid']);
	}else{
		  $dotmp='-';
		  if($type=='tui'){
			  $dotmp='+';
		  }
		  if($it618_tuan_sale['it618_gtypeid']>0){
			  $salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_gtypeid($it618_tuan_sale['it618_gtypeid']);
			  if($salecount=='')$salecount=0;
			  
			  DB::query("update ".DB::table('it618_tuan_goods_type')." set it618_salecount=".$salecount.",it618_count=it618_count".$dotmp.$it618_tuan_sale['it618_count']." where id=".$it618_tuan_sale['it618_gtypeid']);
		  }
		  
		  $salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_pid($it618_tuan_sale['it618_pid']);
		  if($salecount=='')$salecount=0;
		  
		  DB::query("update ".DB::table('it618_tuan_goods')." set it618_salecount=".$salecount.",it618_count=it618_count".$dotmp.$it618_tuan_sale['it618_count']." where id=".$it618_tuan_sale['it618_pid']);
	}
}

function it618_tuan_delsalework(){
	DB::query("delete from ".DB::table('it618_tuan_salework'));
}

function it618_tuan_getshopgoods($shopid,$page=1,$wap=0,$type=''){
	global $_G,$it618_tuan,$it618_tuan_lang,$creditname;
	$creditname=$_G['setting']['extcredits'][$it618_tuan['tuan_credit']]['title'];
	if($wap==1){
		$ppp = 12;
		
		if($it618_tuan['tuan_style']>2){
			$tuanstyle=getcookie('tuanstyle');
			if($tuanstyle==''){
				if($it618_tuan['tuan_style']==3)$tuanstyle='1';else $tuanstyle='2';
			}
		}else{
			if($it618_tuan['tuan_style']==1)$tuanstyle='1';else $tuanstyle='2';
		}
	}else{
		$ppp = 12;
	}
	$page = max(1, intval($page));
	$startlimit = ($page - 1) * $ppp;
	
	$orderby='id desc';
	if($type=='views'){
		$startlimit=0;
		$orderby='it618_views desc';
	}
	if($type=='hot'){
		$startlimit=0;
		$orderby='it618_salecount desc';
	}
	
	$tdn=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods')." where it618_state=1 and it618_shopid=".$shopid." ORDER BY $orderby limit $startlimit,$ppp");
	while($it618_tuan_goods = DB::fetch($query)) {
		
		$jfbl='';
		if($it618_tuan_goods['it618_jfbl']>0&&$it618_tuan_goods['it618_saleprice']>0){
			if(C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($it618_tuan_goods['id'])>0){
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').str_replace(".00","",$it618_tuan_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').intval($it618_tuan_goods['it618_saleprice']*$it618_tuan_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		if($wap==1){
	
			$pj=$it618_tuan_goods['it618_pjpfstr'];
		
			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
		
			if($tuanstyle=='1'){
				$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
			
				$strlist.='<tr>
								<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
									<div class="tddes">'.$pj.' '.$views.'</div>
									<ul class="tdprice">
									  <li>
									  <span style="float:right">'.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</span>
									  <strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong>
									  </li>
									</ul>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
			}else{
				if($tdn%2>0){
					$trtmpstr1='<tr class="trimg">';
					$trtmpstr2='<tr class="trabout">';
					$tdstr='class="tdleft"';
				}else{
					$tdstr='class="tdright"';
				}
				
				$trtmpstr1.='<td '.$tdstr.'>'.$jfbl.'<a href="'.$tmpurl.'">
								<img class="lazy" data-original="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/>
							</a></td>';
				
				$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
								<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
								<div class="tddes"><span style="float:right">'.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</span>'.$pj.'</div>
								<div class="tdprice"><strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong></div>
							</a></td>';
							
				if($tdn%2==0){
					$trtmpstr1.='</tr>';
					$trtmpstr2.='</tr>';
					$strlist.=$trtmpstr1.$trtmpstr2;
				}
				
				$tdn=$tdn+1;
			}
		}else{
			if($it618_tuan_goods['it618_meal_id']>0)$merger='<em class="merger iepng"></em>';else $merger='';
			if($it618_tuan_goods['it618_isservice3']==1)$reserve='<em class="reserve iepng"></em>';else $reserve='';
			if($merger!=''||$reserve!='')$goodsmark='<span class="goods-mark">'.$merger.$reserve.'</span>';else $goodsmark='';
			
			$pj=$it618_tuan_goods['it618_pjpfstr'];
			
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			$getshopgoods.='<div class="goods lgoods">
							'.$jfbl.'
							<a class="goods-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" alt="'.$it618_tuan_goods['it618_name'].'" />
							'.$goodsmark.'
							</a>
							<h3>
							<a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_tuan_goods['it618_name'].'">'.$it618_tuan_goods['it618_name'].'</a>
							<div style="font-weight:normal;font-size:12px;"><p style="float:right">'.it618_tuan_getlang('s465').$it618_tuan_goods['it618_salecount'].'</p>'.$pj.'</div>
							</h3>
							<div class="goods-info">
							<span class="price">'.it618_tuan_getgoodsprice($it618_tuan_goods).'</span>
							</div>
							</div>';
		}
	}
	
	if($wap==1){
		if($videostyle=='1'){
			$tmparr=explode('</tr>',$strlist);
			if(count($tmparr)>1){
				$strlist=$strlist.'@@@';
				$strlist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$strlist);
			}
		}else{
			$trtmpstr=$trtmpstr1.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr);
			if(count($tmparr)>1){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$strlist.=$trtmpstr1.$trtmpstr2;
			}
		}
		
		$getshopgoods=$strlist;
	}
	
	if($type!='')return $getshopgoods;
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_goods')." where it618_state=1 and it618_shopid=".$shopid);
	$funname='getshopgoods';
	
	if($wap==1){
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_tuan_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}else{
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].'plugin.php?id=it618_tuan:ajax');
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',''.$funname.'(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
	}
	
	return $getshopgoods.'it618_split'.$multipage;
}

function it618_tuan_sendmessage($type,$id,$type1=''){
	global $_G,$creditname,$it618_tuan_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_tuan/config/message.php';
	
	$tmpurl=it618_tuan_getrewrite('tuan_wap','u@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=u');
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='rz_admin'&&$it618_body_rz_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_rz_admin_tplid_wxsms;
				$body_wxsms=$it618_body_rz_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_shop['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_rz_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_shop['it618_uid']),$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rz_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_shop['it618_uid']).'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='tk_admin'&&$it618_body_tk_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
				$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
				
				$gtypename='';
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$it618_gthdidstr='';
				if($it618_tuan_sale['it618_gthdid']>0){
					$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
					$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
				}
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_tk_admin_tplid_wxsms;
				$body_wxsms=$it618_body_tk_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_tuan_sale['id'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_tk_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
				$Body=str_replace("{saleid}",$it618_tuan_sale['id'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tk_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_shop['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_gthdidstr.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_tuan_sale['id'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='tx_admin'&&$it618_body_tx_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_tuan_tx = C::t('#it618_tuan#it618_tuan_tx')->fetch_by_id($id);
				$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid($it618_tuan_tx['it618_uid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_tx_admin_tplid_wxsms;
				$body_wxsms=$it618_body_tx_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{shopname}",$it618_tuan_shop['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{txmoney}",$it618_tuan_tx['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_tx_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{shopname}",$it618_tuan_shop['it618_name'],$Body);
				$Body=str_replace("{txmoney}",$it618_tuan_tx['it618_price'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_admin_tplid;
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_tuan_shop['it618_name'].'",';
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_tuan_tx['it618_price'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
				$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
				$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
				
				$gtypename='';
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$it618_gthdidstr='';
				if($it618_tuan_sale['it618_gthdid']>0){
					$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
					$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
				}
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
						$tmpvalue=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_sale_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
				$Body=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$Body);
				$Body=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_gthdidstr.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.it618_tuan_getsaleprice($it618_tuan_sale).'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'].'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_tuan_sale['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='gwc_admin'&&$it618_body_gwc_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_gwcid($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_gwc_admin_tplid_wxsms;
				$body_wxsms=$it618_body_gwc_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_gwc_admin;	

				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$Body);
				$Body=str_replace("{gwcid}",$id,$Body);
				$Body=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_gwc_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'",';
					
					$tmparr=explode("{gwcid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_tuan_sale['it618_tel'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
		}
		
		if($type=='tx_shop'&&$it618_body_tx_shop_isok==1){
			$it618_tuan_tx = C::t('#it618_tuan#it618_tuan_tx')->fetch_by_id($id);
			$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_tx['it618_shopid']);
			
			$tel=$it618_tuan_shop['it618_msgtel'];
			
			if($it618_tuan_shop['it618_msgisok']==1){
				
				$uid=$it618_tuan_shop['it618_uid'];
				$tplid_wxsms=$it618_body_tx_shop_tplid_wxsms;
				$body_wxsms=$it618_body_tx_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{txmoney}",$it618_tuan_tx['it618_price'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_tx_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{txmoney}",$it618_tuan_tx['it618_price'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_shop_tplid;
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_tuan_tx['it618_price'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_shop'&&$it618_body_sale_shop_isok==1){
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
			
			$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_sale['it618_shopid']);
			
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			
			$tel=$it618_tuan_shop['it618_msgtel'];
			
			if($it618_tuan_shop['it618_msgisok']==1){
				$gtypename='';
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$it618_gthdidstr='';
				if($it618_tuan_sale['it618_gthdid']>0){
					$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
					$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
				}
				
				$uid=$it618_tuan_shop['it618_uid'];
				$tplid_wxsms=$it618_body_sale_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
						$tmpvalue=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_sale_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
				$Body=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$Body);
				$Body=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_gthdidstr.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.it618_tuan_getsaleprice($it618_tuan_sale).'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'].'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_tuan_sale['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='gwc_shop'&&$it618_body_gwc_shop_isok==1){
			$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($type1);
	
			$tel=$it618_tuan_shop['it618_msgtel'];

			if($it618_tuan_shop['it618_msgisok']==1){
				$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_gwcid_shopid($id,$type1);
				
				$uid=$it618_tuan_shop['it618_uid'];
				$tplid_wxsms=$it618_body_gwc_shop_tplid_wxsms;
				$body_wxsms=$it618_body_gwc_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_gwc_shop;
				$ALDYBody=$Body;
				
				$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$Body);
				$Body=str_replace("{gwcid}",$id,$Body);
				$Body=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_gwc_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'",';
					
					$tmparr=explode("{gwcid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_tuan_sale['it618_tel'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_shop1'&&$it618_body_sale_shop_isok==1){
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
			$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
			
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			
			$tel=$it618_tuan_shop_thd['it618_msgtel'];
			
			if($it618_tuan_shop_thd['it618_msgisok']==1){
				$gtypename='';
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$uid=$it618_tuan_shop_thd['it618_uid'];
				$tplid_wxsms=$it618_body_sale_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename,$tmpvalue);
						$tmpvalue=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_sale_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename,$Body);
				$Body=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$Body);
				$Body=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.it618_tuan_getsaleprice($it618_tuan_sale).'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'].'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_tuan_sale['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale2state_shop'&&$it618_body_sale2state_shop_isok==1){
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
			$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_sale['it618_shopid']);
			
			$tel=$it618_tuan_shop['it618_msgtel'];
			
			if($it618_tuan_shop['it618_msgisok']==1){
				$gtypename='';
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$it618_gthdidstr='';
				if($it618_tuan_sale['it618_gthdid']>0){
					$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
					$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
				}
				
				if($type1=='shouhuo')$dostr=it618_tuan_getlang('s722');
				if($type1=='tuihuo')$dostr=it618_tuan_getlang('s723');
				
				$uid=$it618_tuan_shop['it618_uid'];
				$tplid_wxsms=$it618_body_sale2state_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale2state_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{saleid}",$it618_tuan_sale['id'],$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
						$tmpvalue=str_replace("{do}",$dostr,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$Body=$it618_body_sale2state_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{saleid}",$it618_tuan_sale['id'],$Body);
				$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
				$Body=str_replace("{do}",$dostr,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale2state_shop_tplid;
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_tuan_sale['id'].'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_gthdidstr.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
					
					$tmparr=explode("{do}",$ALDYBody);
					if(count($tmparr)>1)$param.='"do":"'.$dostr.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale2state_shop1'&&$it618_body_sale2state_shop_isok==1){
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
			$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
			
			$tel=$it618_tuan_shop_thd['it618_msgtel'];
			
			if($it618_tuan_shop_thd['it618_msgisok']==1){
				$gtypename='';
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				if($type1=='shouhuo')$dostr=it618_tuan_getlang('s722');
				if($type1=='tuihuo')$dostr=it618_tuan_getlang('s723');
				
				$uid=$it618_tuan_shop_thd['it618_uid'];
				$tplid_wxsms=$it618_body_sale2state_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale2state_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{saleid}",$it618_tuan_sale['id'],$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
						$tmpvalue=str_replace("{do}",$dostr,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$Body=$it618_body_sale2state_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{saleid}",$it618_tuan_sale['id'],$Body);
				$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename,$Body);
				$Body=str_replace("{do}",$dostr,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale2state_shop_tplid;
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_tuan_sale['id'].'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.'",';
					
					$tmparr=explode("{do}",$ALDYBody);
					if(count($tmparr)>1)$param.='"do":"'.$dostr.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='order_shop'&&$it618_body_order_shop_isok==1){
			$it618_tuan_order = C::t('#it618_tuan#it618_tuan_order')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_order['it618_pid']);
			$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_order['it618_shopid']);
			
			$tel=$it618_tuan_shop['it618_msgtel'];
			
			if($it618_tuan_shop['it618_msgisok']==1){
				$gtypename='';
				if($it618_tuan_order['it618_gtypeid']>0){
					$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_order['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$it618_gthdidstr='';
				if($it618_tuan_order['it618_gthdid']>0){
					$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_order['it618_gthdid']);
					$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
				}
				
				$uid=$it618_tuan_shop['it618_uid'];
				$tplid_wxsms=$it618_body_order_shop_tplid_wxsms;
				$body_wxsms=$it618_body_order_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_order['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_tuan_order['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_tuan_order['it618_count'].$it618_tuan_goods['it618_unit'],$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_tuan_order['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_order_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_order['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
				$Body=str_replace("{pprice}",$it618_tuan_order['it618_price'],$Body);
				$Body=str_replace("{pcount}",$it618_tuan_order['it618_count'].$it618_tuan_goods['it618_unit'],$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_tuan_order['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_order_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_gthdidstr.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_tuan_order['it618_price'].'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_tuan_order['it618_count'].$it618_tuan_goods['it618_unit'].'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_tuan_order['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='order_shop1'&&$it618_body_order_shop_isok==1){
			$it618_tuan_order = C::t('#it618_tuan#it618_tuan_order')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_order['it618_pid']);
			$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
			
			$tel=$it618_tuan_shop_thd['it618_msgtel'];
			
			if($it618_tuan_shop_thd['it618_msgisok']==1){
				$gtypename='';
				if($it618_tuan_order['it618_gtypeid']>0){
					$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_order['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$uid=$it618_tuan_shop_thd['it618_uid'];
				$tplid_wxsms=$it618_body_order_shop_tplid_wxsms;
				$body_wxsms=$it618_body_order_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_order['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename,$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_tuan_order['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_tuan_order['it618_count'].$it618_tuan_goods['it618_unit'],$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_tuan_order['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_order_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_order['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename,$Body);
				$Body=str_replace("{pprice}",$it618_tuan_order['it618_price'],$Body);
				$Body=str_replace("{pcount}",$it618_tuan_order['it618_count'].$it618_tuan_goods['it618_unit'],$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_tuan_order['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_order_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_order['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_tuan_order['it618_price'].'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_tuan_order['it618_count'].$it618_tuan_goods['it618_unit'].'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_tuan_order['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='tk_user'&&$it618_body_tk_user_isok==1){
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
			
			$tel=$it618_tuan_sale['it618_tel'];
			$gtypename='';
			if($it618_tuan_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$it618_gthdidstr='';
			if($it618_tuan_sale['it618_gthdid']>0){
				$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
				$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
			}
			
			$uid=$it618_tuan_sale['it618_uid'];
			$tplid_wxsms=$it618_body_tk_user_tplid_wxsms;
			$body_wxsms=$it618_body_tk_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{saleid}",$it618_tuan_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
					if($it618_tuan_sale['it618_state']==4)$tktype=it618_tuan_getlang('s678');else $tktype=it618_tuan_getlang('s679');
					$tmpvalue=str_replace("{tktype}",$tktype,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_tk_user;

			$ALDYBody=$Body;
			$Body=str_replace("{saleid}",$it618_tuan_sale['id'],$Body);
			$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
			if($it618_tuan_sale['it618_state']==4)$tktype=it618_tuan_getlang('s678');else $tktype=it618_tuan_getlang('s679');
			$Body=str_replace("{tktype}",$tktype,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_tk_user_tplid;
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_tuan_sale['id'].'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr.'",';
				
				$tmparr=explode("{tktype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"tktype":"'.$tktype.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
			
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			
			$tel=$it618_tuan_sale['it618_tel'];
			
			$gtypename='';
			if($it618_tuan_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$it618_gthdidstr='';
			if($it618_tuan_sale['it618_gthdid']>0){
				$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
				$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
			}
			
			$uid=$it618_tuan_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
					$tmpvalue=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$tmpvalue);
					$tmpvalue=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$tmpvalue);
					$tmpvalue=str_replace("{code}",$it618_tuan_sale['it618_code'],$tmpvalue);
					$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
				
			$Body=$it618_body_sale_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
			$Body=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$Body);
			$Body=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$Body);
			$Body=str_replace("{code}",$it618_tuan_sale['it618_code'],$Body);
			$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_gthdidstr.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.it618_tuan_getsaleprice($it618_tuan_sale).'",';
				
				$tmparr=explode("{pcount}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pcount":"'.$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'].'",';
				
				$tmparr=explode("{code}",$ALDYBody);
				if(count($tmparr)>1)$param.='"code":"'.$it618_tuan_sale['it618_code'].'",';
				
				$tmparr=explode("{purl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='sale2_user'&&$it618_body_sale2_user_isok==1){
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
			
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			
			$tel=$it618_tuan_sale['it618_tel'];
			
			$gtypename='';
			if($it618_tuan_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$it618_gthdidstr='';
			if($it618_tuan_sale['it618_gthdid']>0){
				$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
				$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
			}
			
			$uid=$it618_tuan_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale2_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale2_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
					$tmpvalue=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$tmpvalue);
					$tmpvalue=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$tmpvalue);
					$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_sale2_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
			$Body=str_replace("{pprice}",it618_tuan_getsaleprice($it618_tuan_sale),$Body);
			$Body=str_replace("{pcount}",$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'],$Body);
			$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale2_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_gthdidstr.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.it618_tuan_getsaleprice($it618_tuan_sale).'",';
				
				$tmparr=explode("{pcount}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pcount":"'.$it618_tuan_sale['it618_count'].$it618_tuan_goods['it618_unit'].'",';
				
				$tmparr=explode("{purl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='gwc_user'&&$it618_body_gwc_user_isok==1){
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_gwcid($id);
			$tel=$it618_tuan_sale['it618_tel'];
			
			$uid=$it618_tuan_sale['it618_uid'];
			$tplid_wxsms=$it618_body_gwc_user_tplid_wxsms;
			$body_wxsms=$it618_body_gwc_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
					$tmpvalue=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_gwc_user;		

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_tuan_getusername($it618_tuan_sale['it618_uid']),$Body);
			$Body=str_replace("{gwcid}",$id,$Body);
			$Body=str_replace("{tel}",$it618_tuan_sale['it618_tel'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_gwc_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'",';
				
				$tmparr=explode("{gwcid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
				
				$tmparr=explode("{tel}",$ALDYBody);
				if(count($tmparr)>1)$param.='"tel":"'.$it618_tuan_sale['it618_tel'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='sale2state_user'&&$it618_body_sale2state_user_isok==1){
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
			
			$tel=$it618_tuan_sale['it618_tel'];
			
			$gtypename='';
			if($it618_tuan_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$it618_gthdidstr='';
			if($it618_tuan_sale['it618_gthdid']>0){
				$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
				$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
			}
			
			if($type1=='fahuo')$dostr=it618_tuan_getlang('s724');
			if($type1=='tongyitui')$dostr=it618_tuan_getlang('s725');
			if($type1=='jujuetui')$dostr=it618_tuan_getlang('s726');
			
			$uid=$it618_tuan_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale2state_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale2state_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{saleid}",$it618_tuan_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
					$tmpvalue=str_replace("{do}",$dostr,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$Body=$it618_body_sale2state_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{saleid}",$it618_tuan_sale['id'],$Body);
			$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
			$Body=str_replace("{do}",$dostr,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale2state_user_tplid;
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_tuan_sale['id'].'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_gthdidstr.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
				
				$tmparr=explode("{do}",$ALDYBody);
				if(count($tmparr)>1)$param.='"do":"'.$dostr.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='order_user'&&$it618_body_order_user_isok==1){
			$it618_tuan_order = C::t('#it618_tuan#it618_tuan_order')->fetch_by_id($id);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_order['it618_pid']);
			
			$tel=$it618_tuan_order['it618_tel'];
			$gtypename='';
			if($it618_tuan_order['it618_gtypeid']>0){
				$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_order['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$it618_gthdidstr='';
			if($it618_tuan_order['it618_gthdid']>0){
				$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_order['it618_gthdid']);
				$it618_gthdidstr=' ['.$it618_tuan_shop_thd['it618_name'].']';
			}
			
			$uid=$it618_tuan_order['it618_uid'];
			$tplid_wxsms=$it618_body_order_user_tplid_wxsms;
			$body_wxsms=$it618_body_order_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{orderid}",$it618_tuan_order['id'],$tmpvalue);
					$tmpvalue=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_tuan_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_order_user;

			$ALDYBody=$Body;
			$Body=str_replace("{orderid}",$it618_tuan_order['id'],$Body);
			$Body=str_replace("{pname}",$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'].$gtypename.$it618_gthdidstr,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_order_user_tplid;
				
				$tmparr=explode("{orderid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"orderid":"'.$it618_tuan_order['id'].'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_tuan_getsmsstr($gtypename.$it618_gthdidstr.$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'],$it618_length).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_tuan_lang['s1860'].$it618_smsbaosign.$it618_tuan_lang['s1861'];
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}

function it618_tuan_getsmsstr($strtmp,$length){
	if($length>0){
		$tmpstr = "";
		$strlen = $length;
		for($i = 0; $i < $strlen; $i++){
			if(ord(substr($strtmp, $i, 1)) > 0xa0) {
				if(CHARSET=='gbk'){
					$tmpstr .= substr($strtmp, $i, 2);
					$i++;
				}else{
					$tmpstr.=substr($str,$i,3);
					$i+=2;
				}
			} else {
				$tmpstr .= substr($strtmp, $i, 1);
			}
			
		}
		return $tmpstr; 
	}
	return $strtmp;
}

function it618_tuan_get_contents($str){
	return dfsockopen($str);
}

function it618_tuan_multipage($pagevalue,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_tuan']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php')){
		return $pagevalue;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';

	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}

function it618_tuan_get_contents1($str){
	return dfsockopen($str);
}

function it618_tuan_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_tuan']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php';
	
	if($pagetype=='tuan_home'){
		return $tuan_home.$urltype;
	}
	
	if($pagetype=='tuan_list'){//tuan_list-{cid1}-{cid2}-{aid1}-{aid2}-{price}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_list.$tuan_list1;

		if(count($tmparr)==1){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("-{cid2}-{aid1}-{aid2}-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==2){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("-{aid1}-{aid2}-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==4){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
			$pageurl=str_replace("-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==6){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{price}",$tmparr[4],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[5],$pageurl);
			$pageurl=str_replace("{page}",'1',$pageurl);
		}
		
		if(count($tmparr)==7){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{price}",$tmparr[4],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[5],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[6],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_search'){//tuan_search-{cid1}-{cid2}-{aid1}-{aid2}-{price}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_search.$tuan_search1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid1}-{cid2}-{aid1}-{aid2}-{price}-{order}-{page}","",$pageurl);
		}else{
			if(count($tmparr)==6){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{price}",$tmparr[4],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[5],$pageurl);
				$pageurl=str_replace("{page}",'1',$pageurl);
			}
			
			if(count($tmparr)==7){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{price}",$tmparr[4],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[5],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[6],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_product'){//tuan_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_product.$tuan_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_map'){//tuan_map-{sid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_map.$tuan_map1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_shop'){//tuan_shop-{sid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_shop.$tuan_shop1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='tuan_gwc'){
		return $tuan_gwc.$urltype;
	}
	
	if($pagetype=='tuan_gwcmysale'){
		return $tuan_gwc.$urltype.'?mysale';
	}
	
	if($pagetype=='tuan_sc'){
		return $tuan_sc.$urltype;
	}
	
	if($pagetype=='tuan_wap'){//tuan_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$tuan_wap.$tuan_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_tuan_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_tuan_gbktoutf($strcontent);
	}
}

function it618_tuan_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_tuan_delfile($dirName){
}

function it618_tuan_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
            }else{
            }
        }
        if($type==1);
    }else{
        return false;
    }
}

function it618_tuan_get_contents2($str){
	return dfsockopen($str);
}

function it618_tuan_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_tuan_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_tuan_getusername($uid){
	return C::t('#it618_tuan#it618_tuan_sale')->fetch_username_by_uid($uid);
}

function it618_tuan_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_tuan_getlang('s449');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_tuan_getlang('s450');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_tuan_getlang('s451');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_tuan_getlang('s452');
		}
	}
	
	return $timestr;
}

function it618_tuan_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_tuan_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_tuan']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_tuan_getonlinestate($it618_uid){
	if(TIMESTAMP-C::t('#it618_tuan#it618_tuan_sale')->fetch_lastactivity_by_uid($it618_uid)<=900){
		$tmponlineico='source/plugin/it618_tuan/images/online.gif';
	}else{
		$tmponlineico='source/plugin/it618_tuan/images/offline.gif';
	}
	
	return $tmponlineico;
}

function it618_tuan_getfileext($filestr){
	$file_ext=strtolower(substr($filestr,strrpos($filestr, '.')+1)); 
	$tmparr=explode("?",$file_ext);
	return $tmparr[0];
}

function it618_tuan_getgoodspic($shopid,$pid,$it618_picbig,$i=0){
	$file_ext=it618_tuan_getfileext($it618_picbig);
	
	return 'source/plugin/it618_tuan/kindeditor/data/shop'.$shopid.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
}

function it618_tuan_getwapppic($shopid,$pid,$get_it618_picbig,$type=1){
	$file_ext=it618_tuan_getfileext($get_it618_picbig);
	
	if($shopid=='wapad'){
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			it618_tuan_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,280,1);
		}
		
		$it618_smallurl='source/plugin/it618_tuan/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
	}else{
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/shop'.$shopid.'/smallimage/goods'.$pid.'_0.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
			
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/shop'.$shopid.'/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/shop'.$shopid.'/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/shop'.$shopid.'/smallimage/goods'.$pid.'_0.'.$file_ext;
			it618_tuan_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);
		}
		
		$it618_smallurl='source/plugin/it618_tuan/kindeditor/data/shop'.$shopid.'/smallimage/goods'.$pid.'_0.'.$file_ext;
	}
	
	return $it618_smallurl.'?'.substr(md5($get_it618_picbig),0,6);
}

function it618_tuan_getpjpic($uid,$pjpicid,$picurl){
	$file_ext=it618_tuan_getfileext($picurl);

	$tmparr1=explode("://",$picurl);
	if(count($tmparr1)>1){
		$it618_url=$picurl;
	}else{
		$tmparr=explode("source",$picurl);
		$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
	}
	
	$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/user/u'.$uid.'/smallimage/pjpic'.$pjpicid.'.'.$file_ext;
	
	it618_tuan_imagetosmall($it618_url,$it618_smallurl,$file_ext,48);

}

function it618_tuan_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height=0,$type=0){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		$max=$width;
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function tuan_qrcode($url){
	include DISCUZ_ROOT.'./source/plugin/it618_tuan/phpqrcode.php';
	
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/it618_tuan/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function tuan_is_mobile(){ 
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: Dism_taobao-com
?>