<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';

if($IsGoods==0){
	echo it618_tuan_getlang('s694');exit;
}

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_tuan_meal', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_tuan#it618_tuan_meal')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_order' => dhtmlspecialchars($_GET['it618_order'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_shopid_array = !empty($_GET['newit618_shopid']) ? $_GET['newit618_shopid'] : array();
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			C::t('#it618_tuan#it618_tuan_meal')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_name' => dhtmlspecialchars($newit618_name_array[$key]),
				'it618_order' => dhtmlspecialchars($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	it618_cpmsg(it618_tuan_getlang('s33').$ok1.' '.it618_tuan_getlang('s34').$ok2.' '.it618_tuan_getlang('s35').$del.')', "plugin.php?id=it618_tuan:sc_product_meal", 'succeed');
}


it618_showformheader("plugin.php?id=it618_tuan:sc_product_meal");
showtableheaders(it618_tuan_getlang('s830'),'it618_tuan_meal');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_meal')." WHERE it618_shopid=$ShopId");
	
	echo '<tr><td colspan=15>'.it618_tuan_getlang('s825').$count.'</td></tr>';
	showsubtitle(array('', it618_tuan_getlang('s826'),it618_tuan_getlang('s827'), it618_tuan_getlang('s828')));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_meal')." WHERE it618_shopid=$ShopId ORDER BY it618_order");
	while($it618_tuan = DB::fetch($query)) {

		$goodscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods')." WHERE it618_meal_id=".$it618_tuan['id']);
		$disabled="";
		if($goodscount>0)$disabled="disabled=\"disabled\"";
		
		$tmp1=str_replace('<option value='.$it618_tuan['it618_shopid'].'>','<option value='.$it618_tuan['it618_shopid'].' selected="selected">',$tmp);
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_tuan[id]\" $disabled>",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_tuan[id]]\" value=\"$it618_tuan[it618_name]\">",
			'<input class="txt" type="text" name="it618_order['.$it618_tuan['id'].']" value="'.$it618_tuan['it618_order'].'">',
			$goodscount
		));
	}
	
	global $_G;

	loadcache('plugin');
	$it618_tuan = $_G['cache']['plugin']['it618_tuan'];

	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:200px" name="newit618_name[]">'],
		[1,'<input class="txt" type="text" name="newit618_order[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.it618_tuan_getlang('s831').'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>