<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_tuan_goods_type extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_tuan_goods_type';
		$this->_pk = 'id';
		parent::__construct(); /*DISM_ TAOBAO _COM*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function count_by_pid_ok_isname1($pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d AND it618_ison=1 AND it618_name1!=''", array($this->_table, $pid));
	}
	
	public function counttype_by_pid_ok($pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d AND it618_ison=1", array($this->_table, $pid));
	}
	
	public function fetch_it618_count_by_pid($pid) {
		$count=DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d AND it618_ison=1 AND it618_name1!=''", array($this->_table, $pid));
		if($count>0){
			$it618_count=DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_pid=%d AND it618_ison=1 AND it618_name1!=''", array($this->_table, $pid));
		}else{
			$it618_count=DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_pid=%d AND it618_ison=1", array($this->_table, $pid));
		}

		return $it618_count;
	}
	
	public function fetch_by_pid_name_name1_ok($pid,$name,$name1) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_pid=%d AND it618_name=%s AND it618_name1=%s AND it618_ison=1", array($this->_table, $pid, $name, $name1));
	}
	
	public function fetch_it618_name_by_id($id) {
		$tmp = DB::fetch_first("SELECT it618_name,it618_name1 FROM %t WHERE id=%d", array($this->_table, $id));
		$namestr=$tmp['it618_name'];
		if($tmp['it618_name1']!='')$namestr.=$tmp['it618_name1'];
		return $namestr;
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_idok($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_ison>0 AND id=%d", array($this->_table, $id));
	}
	
	public function fetch_all_by_search() {
		return DB::fetch_all("SELECT * FROM %t ORDER BY it618_order,it618_name,it618_order1,it618_name1", array($this->_table));
	}
	
	public function fetch_name_by_it618_pid($pid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_pid=%d AND it618_ison>0 GROUP BY it618_name ORDER BY it618_order,it618_name", array($this->_table,$pid));
	}
	
	public function fetch_name_by_it618_pid1($pid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_pid=%d AND it618_ison>0 AND it618_name1!='' GROUP BY it618_name ORDER BY it618_order,it618_name", array($this->_table,$pid));
	}
	
	public function fetch_name1_by_it618_pid_name($pid,$name) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_pid=%d AND it618_name=%s AND it618_ison>0  AND it618_name1!='' GROUP BY it618_name1 ORDER BY it618_order1,it618_name1", array($this->_table,$pid,$name));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_pid($pid) {
		DB::query("DELETE FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>