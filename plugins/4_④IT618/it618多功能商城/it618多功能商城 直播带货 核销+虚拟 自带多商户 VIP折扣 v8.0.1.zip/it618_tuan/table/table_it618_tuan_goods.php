<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_tuan_goods extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_tuan_goods';
		$this->_pk = 'id';
		parent::__construct(); /*DISM_ TAOBAO _COM*/
	}
	
	public function count_by_it618_meal_id($it618_meal_id) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_meal_id=%d", array($this->_table, $it618_meal_id));
	}
	
	public function count_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table, $shopid));
	}
	
	public function count_by_shopid_state($shopid,$state) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d and it618_state=%d", array($this->_table, $shopid, $state));
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_id_state($id,$state) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d AND it618_state=%d", array($this->_table, $id, $state));
	}
	
	public function fetch_it618_shopid_by_id($id) {
		return DB::result_first("SELECT it618_shopid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $shopid = 0, $class1 = 0, $class2 = 0, $area1 = 0, $area2 = 0, $it618_name = '', $price1 = 0, $price2 = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $class1, $class2, $area1, $area2, $it618_name, $price1, $price2);
		return DB::result_first("SELECT COUNT(1) FROM %t g join ".DB::table('it618_tuan_shop')." s on g.it618_shopid=s.id and s.it618_state=2 and s.it618_htstate=1 $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $shopid = 0, $class1 = 0, $class2 = 0, $area1 = 0, $area2 = 0, $it618_name = '', $price1 = 0, $price2 = 0, $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $class1, $class2, $area1, $area2, $it618_name, $price1, $price2);
		$data = array();
		$query = DB::query("SELECT g.* FROM %t g join ".DB::table('it618_tuan_shop')." s on g.it618_shopid=s.id and s.it618_state=2 and s.it618_htstate=1 $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $shopid = 0, $class1 = 0, $class2 = 0, $area1 = 0, $area2 = 0, $it618_name = '', $price1 = 0, $price2 = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($shopid)) {
			$parameter[] = $shopid;
			$wherearr[] = 'g.it618_shopid=%d';
		}
		if(!empty($class1)) {
			$parameter[] = $class1;
			$wherearr[] = 'g.it618_class1_id=%d';
		}
		if(!empty($class2)) {
			$parameter[] = $class2;
			$wherearr[] = 'g.it618_class2_id=%d';
		}
		if(!empty($area1)) {
			$parameter[] = $area1;
			$wherearr[] = 's.it618_area1_id=%d';
		}
		if(!empty($area2)) {
			$parameter[] = $area2;
			$wherearr[] = 's.it618_area2_id=%d';
		}
		if(!empty($it618_name)) {
			$tmparr=explode(" ",$it618_name);
			for($n=0;$n<count($tmparr);$n++){
				$parameter[] = '%'.$tmparr[$n].'%';
				$parameter[] = '%'.$tmparr[$n].'%';
				$parameter[] = '%'.$tmparr[$n].'%';
				$tmpsql.='g.it618_name LIKE %s OR g.it618_mealname LIKE %s OR g.it618_description LIKE %s OR ';
			}
			$tmpsql.='@';
			$tmpsql=str_replace(" OR @","",$tmpsql);
			$wherearr[] = '('.$tmpsql.')';
		}
		if(!empty($price1)) {
			$parameter[] = $price1;
			$wherearr[] = 'g.it618_saleprice>=%d';
		}
		if(!empty($price2)) {
			$parameter[] = $price2;
			$wherearr[] = 'g.it618_saleprice<=%d';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function update_it618_views_by_id($id) {
		DB::query("UPDATE %t SET it618_views=it618_views+1 WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_it618_salecount_by_id($id,$salecount) {
		DB::query("UPDATE %t SET it618_salecount=%d WHERE id=%d", array($this->_table, $salecount, $id));
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>