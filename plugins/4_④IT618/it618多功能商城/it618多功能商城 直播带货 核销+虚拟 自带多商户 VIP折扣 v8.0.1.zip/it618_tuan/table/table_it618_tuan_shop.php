<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_tuan_shop extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_tuan_shop';
		$this->_pk = 'id';
		parent::__construct(); /*DISM_ TAOBAO _COM*/
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_uid($it618_uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d", array($this->_table, $it618_uid));
	}
	
	public function fetch_by_uid_ok($it618_uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_state=2 and it618_htstate=1 and it618_uid=%d", array($this->_table, $it618_uid));
	}
	
	public function fetch_by_search() {
		return DB::fetch_first("SELECT * FROM %t", array($this->_table));
	}
	
	public function fetch_all_by_it618_name($keywords) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_name LIKE %s ORDER BY id desc", array($this->_table,$keywords));
	}
	
	public function count_by_isgoodsnot() {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_state=2 and it618_htstate=1 and it618_uid<>0 and it618_isgoods=0", array($this->_table));
	}
	
	public function fetch_all_by_isgoodsnot() {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_state=2 and it618_htstate=1 and it618_uid<>0 and it618_isgoods=0 ORDER BY it618_name", array($this->_table));
	}
	
	public function fetch_it618_uid_by_id($id) {
		return DB::result_first("SELECT it618_uid FROM %t WHERE id=%d",array($this->_table, $id));
	}
	
	public function fetch_name_by_id($id) {
		return DB::result_first("SELECT it618_name FROM %t WHERE id=%d",array($this->_table, $id));
	}
	
	public function fetch_money_by_id($id) {
		return DB::result_first("SELECT it618_money FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_id_by_it618_uid($it618_uid) {
		return DB::result_first("SELECT id FROM %t WHERE it618_uid=%d",array($this->_table, $it618_uid));
	}
	
	public function fetch_it618_state_by_it618_uid($it618_uid) {
		return DB::result_first("SELECT it618_state FROM %t WHERE it618_uid=%d",array($this->_table, $it618_uid));
	}
	
	public function update_messagecount_by_id($id) {
		DB::query("UPDATE %t SET it618_messagecount=it618_messagecount+1 WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_it618_htstate_by_id($id,$it618_htstate) {
		DB::query("UPDATE %t SET it618_htstate=%d WHERE id=%d", array($this->_table, $it618_htstate, $id));
	}
	
	public function update_it618_state_by_id($id,$it618_state) {
		DB::query("UPDATE %t SET it618_state=%d WHERE id=%d", array($this->_table, $it618_state, $id));
	}
	
	public function update_it618_htetime_by_id($id,$it618_htetime) {
		DB::query("UPDATE %t SET it618_htetime=%d WHERE id=%d", array($this->_table, $it618_htetime, $id));
	}
	
	public function update_pass_by_id($id,$it618_htetime) {
		DB::query("UPDATE %t SET it618_state=2,it618_htstate=1,it618_htetime=%d WHERE id=%d", array($this->_table, $it618_htetime, $id));
	}
	
	public function update_it618_uid_by_id($id,$it618_uid) {
		DB::query("UPDATE %t SET it618_uid=%d WHERE id=%d", array($this->_table, $it618_uid, $id));
	}
	
	public function update_moneysum_by_id($id,$it618_moneysum) {
		DB::query("UPDATE %t SET it618_moneysum=%d WHERE id=%d", array($this->_table, $it618_moneysum, $id));
	}
	
	public function count_by_id($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE id=%d", array($this->_table, $shopid));
	}
	
	public function count_by_it618_uid($it618_uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d", array($this->_table, $it618_uid));
	}
	
	public function count_by_it618_area1_id($it618_area1_id) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_area1_id=%d", array($this->_table, $it618_area1_id));
	}
	
	public function count_by_it618_area2_id($it618_area2_id) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_area2_id=%d", array($this->_table, $it618_area2_id));
	}
	
	public function count_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_area1_id = 0, $it618_area2_id = 0, $it618_uid = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_area1_id, $it618_area2_id, $it618_uid);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_dhshop() {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_uid=0 ORDER BY it618_name", array($this->_table));
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_area1_id = 0, $it618_area2_id = 0, $it618_uid = 0, $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_area1_id, $it618_area2_id, $it618_uid);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby = '', $it618_name = '', $it618_area1_id = 0, $it618_area2_id = 0, $it618_uid = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "it618_name LIKE %s";
		}
		if(!empty($it618_area1_id)) {
			$parameter[] = $it618_area1_id;
			$wherearr[] = 'it618_area1_id=%d';
		}
		if(!empty($it618_area2_id)) {
			$parameter[] = $it618_area2_id;
			$wherearr[] = 'it618_area2_id=%d';
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>