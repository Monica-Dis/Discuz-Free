<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_tuan/rewrite.php',DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_tuan/message.php',DISCUZ_ROOT.'./source/plugin/it618_tuan/config/message.php');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_tuan_gwc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gthdid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_kdid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_tuan_gwcsale_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_paycode` varchar(50) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_tuan_gwcsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gthdid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL default 1,
  `it618_price` float(9,2) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_isservice1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isservice2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isservice3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bsaletime` varchar(20) NOT NULL,
  `it618_esaletime` varchar(20) NOT NULL,
  `it618_name` varchar(20) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_tuan_sale_pjpic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_pjpic` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_tuan_goods_type_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_tuan_live` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islogin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ischat` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isip` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_livetype` varchar(50) NOT NULL,
  `it618_liveid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuanurl` varchar(1000) NOT NULL,
  `it618_tuaniframe` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_tuan_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_tuan_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_tuan_saleaudio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_shop'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field'];
}
if(!in_array('it618_score', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '1000';"; 
	DB::query($sql);  
}
if(!in_array('it618_kefuwx', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop')." add `it618_kefuwx` varchar(200) NOT NULL;"; 
	DB::query($sql);  
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_sale')." where it618_kdid>0 and it618_kddan=''");
	while($it618_tuan_sale = DB::fetch($query)) {
		$it618_tuan_kdyunfei=C::t('#it618_tuan#it618_tuan_kdyunfei')->fetch_by_id($it618_tuan_sale['it618_kdid']);
		$it618_kdid=$it618_tuan_kdyunfei['it618_kdid'];
		DB::query("UPDATE ".DB::table('it618_tuan_sale')." SET it618_kdid=$it618_kdid where id=".$it618_tuan_sale['id']);
	}
}
if(!in_array('it618_kefuwxname', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop')." add `it618_kefuwxname` varchar(200) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_adimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop')." add `it618_adimg` varchar(200) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_adimgurl', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop')." add `it618_adimgurl` varchar(200) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_message', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop')." add `it618_message` mediumtext NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_islive', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop')." add `it618_islive` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_tongji', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop')." add `it618_tongji` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_gwc'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_jfmoneytype', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_jfmoneytype` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_jfmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_jfmoney` float(9,2) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_price', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_price` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_state', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_state` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_money', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_money` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_quanmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_iseditprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_iseditprice` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_gwcsale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_quanmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale')." add `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_gwcsale_main'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_moneybz', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale_main')." add `it618_moneybz` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_gwcid', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_paycode', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_paycode` varchar(50) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_salebz', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_salebz` varchar(2000) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_quanmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_tuijid', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale')." add `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_tuitcbl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_tuitc` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_vipzk', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_vipzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_sfmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale')." add `it618_vipzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale')." add `it618_sfmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale')." add `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_sale'));
	while($it618_tuan_sale = DB::fetch($query)) {
		$it618_sfmoney = $it618_tuan_sale['it618_price']*$it618_tuan_sale['it618_count']+$it618_tuan_sale['it618_yunfei']-$it618_tuan_sale['it618_quanmoney'];
		$it618_sfscore = $it618_tuan_sale['it618_score']*$it618_tuan_sale['it618_count'];
		$sql = "update ".DB::table('it618_tuan_sale')." set it618_sfmoney=$it618_sfmoney,it618_sfscore=$it618_sfscore where id=".$it618_tuan_sale['id']; 
		DB::query($sql);
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_shop_thd'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_kefuqq', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop_thd')." add `it618_kefuqq` varchar(200) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_kefuqqname', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop_thd')." add `it618_kefuqqname` varchar(200) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_yytime', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop_thd')." add `it618_yytime` varchar(200) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_about', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_shop_thd')." add `it618_about` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_goods'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_pjpfstr', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods')." add `it618_pjpfstr` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_ptypename1', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods')." add `it618_ptypename1` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_picbig1', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods')." add `it618_picbig1` varchar(255) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "update ".DB::table('it618_tuan_goods')." set it618_picbig=it618_picbig where it618_type=0;"; 
	DB::query($sql);
}
if(!in_array('it618_picbig2', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods')." add `it618_picbig2` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_picbig3', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods')." add `it618_picbig3` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_picbig4', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods')." add `it618_picbig4` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_jfid', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_goods_type')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_yunfeijfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale')." add `it618_yunfeijfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_kdyunfei')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_score', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_tuan_goods_type')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_gwc')." add `it618_pricescore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_sale')." add `it618_yunfeiscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_gwcsale')." add `it618_yunfeiscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_kdyunfei')." add `it618_firstscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_tuan_kdyunfei')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_issaledisplay', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods')." add `it618_issaledisplay` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_goods_type'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_name1', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods_type')." add `it618_name1` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_salecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods_type')." add `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods_type'));
	while($it618_tuan_goods_type = DB::fetch($query)) {
		$salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_gtypeid($it618_tuan_goods_type['id']);
		if($salecount=='')$salecount=0;
		DB::query("UPDATE ".DB::table('it618_tuan_goods_type')." SET it618_salecount=$salecount where id=".$it618_tuan_goods_type['id']);
	}
}
if(!in_array('it618_order', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods_type')." add `it618_order` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_order1', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_goods_type')." add `it618_order1` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_kd'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_kdcomid', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_kd')." add `it618_kdcomid` varchar(50) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_diy'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_sql', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_diy')." add `it618_sql` varchar(200) NOT NULL;"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_tuan_jfhl')." modify column `it618_hl` float(9,3) NOT NULL;"; 
	DB::query($sql);
	DB::query("update ".DB::table('common_plugin')." set name='".lang('plugin/it618_tuan', 'it618_name')."' where identifier='it618_tuan'");
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_bank'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_wxname', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_bank')." add `it618_wxname` varchar(50) NOT NULL;"; 
	DB::query($sql);
	DB::query("update ".DB::table('it618_tuan_tx')." set it618_type=3 where it618_type=2");
}
if(!in_array('it618_wx', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_bank')." add `it618_wx` varchar(100) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_tuan_bottomnav'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_curimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_tuan_bottomnav')." add `it618_curimg` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

$sql = "update ".DB::table('it618_tuan_shop')." set it618_htstate=1 where it618_uid=0;"; 
DB::query($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan_SC_GBK.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan_SC_UTF8.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan_TC_BIG5.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan_TC_UTF8.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/language.TC_BIG5.php'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/language.TC_UTF8.php'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/install.php'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/upgrade.php'));
?>