<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/tuan_default.func.php';

$class1=intval($_GET['class1']);
$class2=intval($_GET['class2']);
$area1=intval($_GET['area1']);
$area2=intval($_GET['area2']);
$price=intval($_GET['price']);
$order=intval($_GET['order']);

if(tuan_is_mobile()){ 
	if($class2>0){
		$tmpurl=it618_tuan_getrewrite('tuan_wap','search@'.$class1.'@'.$class2,'plugin.php?id=it618_tuan:wap&pagetype=search&cid1='.$class1.'&cid2='.$class2);
	}else{
		$tmpurl=it618_tuan_getrewrite('tuan_wap','search@'.$class1,'plugin.php?id=it618_tuan:wap&pagetype=search&cid='.$class1);
	}
	dheader("location:$tmpurl");
}

$tmpidsarr=explode(',',$hotclassgoods[1]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_tuan_class2=C::t('#it618_tuan#it618_tuan_class2')->fetch_by_id($id);
	$tmpurl=it618_tuan_getrewrite('tuan_list',$it618_tuan_class2['it618_class1_id'].'@'.$id,'plugin.php?id=it618_tuan:list&class1='.$it618_tuan_class2['it618_class1_id'].'&class2='.$id);
	$listhotclass.='<li><a href="'.$tmpurl.'">'.$it618_tuan_class2['it618_classname'].'</a></li>';
}

foreach(C::t('#it618_tuan#it618_tuan_focus')->fetch_all_by_type_order(5) as $it618_tuan_focus) {
	if($it618_tuan_focus['it618_url']!=''){
		$str_focus5.='<li><a href="'.$it618_tuan_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus5.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

if($class1>0){
	$class1name=C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_name_by_id($class1);
	$classtitle.=$class1name.' ';
	$tmpurl=it618_tuan_getrewrite('tuan_list','0@0@'.$area1.'@'.$area2.'@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1=0&class2=0&area1='.$area1.'&area2='.$area2.'&price='.$price.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$class1name.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

if($class2>0){
	$tmpname=C::t('#it618_tuan#it618_tuan_class2')->fetch_it618_name_by_id($class2);
	$classtitle.=$tmpname.' ';
	$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@0@'.$area1.'@'.$area2.'@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2=0&area1='.$area1.'&area2='.$area2.'&price='.$price.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

if($area1>0){
	$tmpname=C::t('#it618_tuan#it618_tuan_area1')->fetch_it618_name_by_id($area1);
	$classtitle.=$tmpname.' ';
	$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@0@0@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1=0&area2=0&price='.$price.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

if($area2>0){
	$tmpname=C::t('#it618_tuan#it618_tuan_area2')->fetch_it618_name_by_id($area2);
	$classtitle.=$tmpname.' ';
	$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@'.$area1.'@0@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2=0&price='.$price.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

$pricename[0]=it618_tuan_getlang('s466');$pricename[1]='50'.it618_tuan_getlang('s468');$pricename[2]='50-100'.it618_tuan_getlang('s125');$pricename[3]='100-200'.it618_tuan_getlang('s125');$pricename[4]='200-300'.it618_tuan_getlang('s125');$pricename[5]='300'.it618_tuan_getlang('s469');
if($price>0){
	$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@0@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&price=0&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$pricename[$price].'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

$listnav.='@';
$listnav=str_replace('<i class="crumb-icon"></i>@','',$listnav);

if($class1==0)$current=' class="current"';else $current='';
$tmpurl=it618_tuan_getrewrite('tuan_list','0@0@'.$area1.'@'.$area2.'@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1=0&class2=0&area1='.$area1.'&area2='.$area2.'&price='.$price.'&order='.$order);
$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_tuan_getlang('s466').'</a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' ORDER BY it618_order");
while($it618_tuan_class1 = DB::fetch($query)) {
	$goodscount=C::t('#it618_tuan#it618_tuan_goods')->count_by_search('g.it618_state=1','',0,$it618_tuan_class1['id'],0,0,0,'',0,0);
	if($class1==$it618_tuan_class1['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_tuan_getrewrite('tuan_list',$it618_tuan_class1['id'].'@0@'.$area1.'@'.$area2.'@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$it618_tuan_class1['id'].'&class2=0&area1='.$area1.'&area2='.$area2.'&price='.$price.'&order='.$order);
	$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_tuan_class1['it618_classname'].'<span>'.$goodscount.'</span></a></li>';
}

if($class1>0){
	if($class2==0)$current=' class="current"';else $current='';
	$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@0@'.$area1.'@'.$area2.'@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2=0&area1='.$area1.'&area2='.$area2.'&price='.$price.'&order='.$order);
	$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_tuan_getlang('s466').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$class1." ORDER BY it618_order");
	while($it618_tuan_class2 = DB::fetch($query)) {
		$goodscount=C::t('#it618_tuan#it618_tuan_goods')->count_by_search('g.it618_state=1','',0,0,$it618_tuan_class2['id'],0,0,'',0,0);
		if($class2==$it618_tuan_class2['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$it618_tuan_class2['id'].'@'.$area1.'@'.$area2.'@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$it618_tuan_class2['id'].'&area1='.$area1.'&area2='.$area2.'&price='.$price.'&order='.$order);
		$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_tuan_class2['it618_classname'].'<span>'.$goodscount.'</span></a></li>';
	}
}

if($area1==0)$current=' class="current"';else $current='';
$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@0@0@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1=0&area2=0&price='.$price.'&order='.$order);
$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_tuan_getlang('s466').'</a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_area1')." ORDER BY it618_order");
while($it618_tuan_area1 = DB::fetch($query)) {
	$goodscount=C::t('#it618_tuan#it618_tuan_goods')->count_by_search('g.it618_state=1','',0,0,0,$it618_tuan_area1['id'],0,'',0,0);
	if($area1==$it618_tuan_area1['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@'.$it618_tuan_area1['id'].'@0@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1='.$it618_tuan_area1['id'].'&area2=0&price='.$price.'&order='.$order);
	$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_tuan_area1['it618_name'].'<span>'.$goodscount.'</span></a></li>';
}

if($area1>0){
	if($area2==0)$current=' class="current"';else $current='';
	$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@'.$area1.'@0@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2=0&price='.$price.'&order='.$order);
	$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_tuan_getlang('s466').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_area2')." where it618_area1_id=".$area1." ORDER BY it618_order");
	while($it618_tuan_area2 = DB::fetch($query)) {
		$goodscount=C::t('#it618_tuan#it618_tuan_goods')->count_by_search('g.it618_state=1','',0,0,0,0,$it618_tuan_area2['id'],'',0,0);
		if($area2==$it618_tuan_area2['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@'.$area1.'@'.$it618_tuan_area2['id'].'@'.$price.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$it618_tuan_area2['id'].'&price='.$price.'&order='.$order);
		$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_tuan_area2['it618_name'].'<span>'.$goodscount.'</span></a></li>';
	}
}

for($i=0;$i<=5;$i++){
	if($i==1){$price1=0;$price2=50;}
	if($i==2){$price1=50;$price2=100;}
	if($i==3){$price1=100;$price2=200;}
	if($i==4){$price1=200;$price2=300;}
	if($i==5){$price1=300;$price2=0;}
	if($price==$i)$current=' class="current"';else $current='';
	if($i>0){
		$goodscount=C::t('#it618_tuan#it618_tuan_goods')->count_by_search('g.it618_state=1','',0,0,0,0,0,'',$price1,$price2);
		$tmpstr='<span>'.$goodscount.'</span>';
	}
	
	$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$i.'@'.$order,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&price='.$i.'&order='.$order);
	$str_price.='<li><a href="'.$tmpurl.'"'.$current.'>'.$pricename[$i].$tmpstr.'</a></li>';
}

$price1=0;$price2=0;
if($price==1){$price1=0;$price2=50;}
if($price==2){$price1=50;$price2=100;}
if($price==3){$price1=100;$price2=200;}
if($price==4){$price1=200;$price2=300;}
if($price==5){$price1=300;$price2=0;}

if($order==0){$current0=' class="left current"';$it618orderby='g.it618_order desc,g.id desc';}else $current0=' class="left"';
if($order==1){$current1=' class="current"';$it618orderby='g.it618_salecount desc';}else $current1='';
if($order==2){$current2=' class="current"';$it618orderby='g.it618_saleprice';}else $current2='';
if($order==3){$current3=' class="current"';$it618orderby='g.it618_saleprice desc';}else $current3='';
if($order==4){$current4=' class="current"';$it618orderby='g.it618_time desc';}else $current4='';

for($i=0;$i<=4;$i++){
	$tmpurl=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$price.'@'.$i,'plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&price='.$price.'&order='.$i);
	$orderurl[$i]=$tmpurl;
}

$ppp=$it618_tuan['tuan_listpagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$it618sql='g.it618_state=1';

$count = C::t('#it618_tuan#it618_tuan_goods')->count_by_search($it618sql,$it618orderby,0,$class1,$class2,$area1,$area2,'',$price1,$price2);
$hrefsql=it618_tuan_getrewrite('tuan_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$price.'@'.$order.'@it618page','plugin.php?id=it618_tuan:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&price='.$price.'&order='.$order);
$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_tuan_multipage($multipage,$uri);

foreach(C::t('#it618_tuan#it618_tuan_goods')->fetch_all_by_search(
	$it618sql,$it618orderby,0,$class1,$class2,$area1,$area2,'',$price1,$price2,$startlimit,$ppp
) as $it618_tuan_goods) {
	$shopaddr = DB::result_first("SELECT it618_addr FROM ".DB::table('it618_tuan_shop')." WHERE id=".$it618_tuan_goods['it618_shopid']);
	if($it618_tuan_goods['it618_meal_id']>0)$merger='<em class="merger iepng"></em>';else $merger='';
	if($it618_tuan_goods['it618_isservice3']==1)$reserve='<em class="reserve iepng"></em>';else $reserve='';
	if($merger!=''||$reserve!='')$goodsmark='<span class="goods-mark">'.$merger.$reserve.'</span>';else $goodsmark='';
	
	$pj=$it618_tuan_goods['it618_pjpfstr'];
	$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
	
	$jfbl='';
	if($it618_tuan_goods['it618_jfbl']>0&&$it618_tuan_goods['it618_saleprice']>0){
		if(C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($it618_tuan_goods['id'])>0){
			$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').str_replace(".00","",$it618_tuan_goods['it618_jfbl']).'%'.$creditname.'</div>';
		}else{
			$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').intval($it618_tuan_goods['it618_saleprice']*$it618_tuan_goods['it618_jfbl']/100).$creditname.'</div>';
		}
	}
	
	$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
	$str_goodslist.='<div class="goods">
				'.$jfbl.'
				<a class="goods-img" href="'.$tmpurl.'" target="_blank">
				<img imgsrc="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" src="source/plugin/it618_tuan/images/a.gif" class="dynload" width="308" height="308" alt="'.$it618_tuan_goods['it618_name'].'" />
				<span class="goods-place">'.$shopaddr.'</span>
				'.$goodsmark.'
				</a>
				<h3>
				<a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_tuan_goods['it618_name'].'">'.$it618_tuan_goods['it618_name'].'</a>
				<div style="font-weight:normal;font-size:12px;"><p style="float:right">'.it618_tuan_getlang('s465').$it618_tuan_goods['it618_salecount'].'</p>'.$pj.' '.$views.'</div>
				</h3>
				<div class="goods-info">
				<span class="price">'.it618_tuan_getgoodsprice($it618_tuan_goods).'</span>
				</div>
				</div>';
}

if($class1==0){
	$sql='';
}else{
	$sql=' and it618_class1_id='.$class1;
}
$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods')." where it618_state=1".$sql." ORDER BY it618_salecount desc limit 0,".$it618_tuan['tuan_listsalecount']);
while($it618_tuan_goods = DB::fetch($query)) {
	$pj=$it618_tuan_goods['it618_pjpfstr'];
	$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
	
	$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
	$str_goodshot.='<div class="small-goods"><a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload" src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" alt="'.$it618_tuan_goods['it618_name'].'"/></a><h4><a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_tuan_goods['it618_name'].'">'.$it618_tuan_goods['it618_name'].'</a><div style="font-weight:normal;font-size:12px;"><p style="float:right">'.it618_tuan_getlang('s465').$it618_tuan_goods['it618_salecount'].'</p>'.$pj.' '.$views.'</div></h4><div class="small-goods-info"><span class="price">'.it618_tuan_getgoodsprice($it618_tuan_goods).'</span></div></div>';
}

$classtitle1=str_replace(' ','',$classtitle);
if($classtitle1=='')$classtitle=it618_tuan_getlang('s100');
$metatitle=$classtitle.' - '.$metatitle;

$pagetype='list';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:tuan_default');
?>