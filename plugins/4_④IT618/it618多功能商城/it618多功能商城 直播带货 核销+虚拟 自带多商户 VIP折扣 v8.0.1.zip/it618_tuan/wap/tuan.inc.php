<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!tuan_is_mobile()){ 
	$tmpurl=it618_tuan_getrewrite('tuan_home','','plugin.php?id=it618_tuan:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_tuan_getlang('t84').' - '.$sitetitle;

foreach(C::t('#it618_tuan#it618_tuan_focus')->fetch_all_by_type_order(24) as $it618_tuan_focus) {
	if($it618_tuan_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_tuan_focus['it618_url'].'" target="_blank"><img class="img" src="'.it618_tuan_getwapppic('wapad',$it618_tuan_focus['id'],$it618_tuan_focus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_tuan_getwapppic('wapad',$it618_tuan_focus['id'],$it618_tuan_focus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_tuan_gonggao = DB::fetch($query)) {
	$it618_title=$it618_tuan_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_tuan_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_tuan_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_tuan_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_tuan_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

if($it618_tuan['waphomeico']=='')$it618_tuan['waphomeico']='2|5|11|#888|6';
$waphomeico=explode("|",$it618_tuan['waphomeico']);
$tmpn=$waphomeico[0];
$pppn=$waphomeico[1];
$tmpsize=$waphomeico[2];
$tmpcolor=$waphomeico[3];
$tmpw=$waphomeico[4];
$pppw=100/$pppn;
$tmpn=$tmpn*$pppn;

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_tuan_iconav = DB::fetch($query)) {
	$it618_title=$it618_tuan_iconav['it618_title'];
	
	if($it618_tuan_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_tuan_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_tuan_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_tuan_iconav['it618_color'].'">'.$it618_title.'</font>';
	}

	$str_iconav.='<td width="'.$pppw.'%"><a href="'.$it618_tuan_iconav['it618_url'].'"'.$it618_target.'><img src="'.$it618_tuan_iconav['it618_img'].'" /><br>'.$it618_title.'</a></td>';
	
	if($n%$pppn==0)$str_iconav.='</tr><tr>';
	if($n%$tmpn==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';

	$n=$n+1;
}

if($n>1)$n=$n-1;

if($n%$pppn>0){
	for($i=1;$i<=($pppn-$n%$pppn);$i++){
		$str_iconav.='<td width="'.$pppw.'%"></td>';
	}
}

$str_iconav.='</tr>';
$str_iconav=str_replace('<tr></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"></table></div>','',$str_iconav);
$str_iconav=str_replace('<tr><td','<tr><td width='.$tmpw.'></td><td',$str_iconav);
$str_iconav=str_replace('</td></tr>','</td><td width='.$tmpw.'></td></tr>',$str_iconav);
$str_iconav.='<style>.swiper-slide .iconav{table-layout:fixed;}.swiper-slide .iconav tr td a{color:'.$tmpcolor.';font-size:'.$tmpsize.'px}</style>';

$isiconav=count(explode('<img src',$str_iconav))-1;

$zjsalegoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('weeksalegoods');
$newgoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('newgoods');
$hotgoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('hotgoods');
$waphomead=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('waphomead');

$tmparr=explode(",",$zjsalegoods);
if(count($tmparr)>2){
	$zjsalegoods_count=$tmparr[1];
	$zjsalegoods_order=$tmparr[2];
}else{
	$zjsalegoods_count=8;
	$zjsalegoods_order=1;
}

$tmparr=explode(",",$weeksalegoods);
if(count($tmparr)>2){
	$weeksalegoods_count=$tmparr[1];
	$weeksalegoods_order=$tmparr[2];
}else{
	$weeksalegoods_count=8;
	$weeksalegoods_order=2;
}

$tmparr=explode(",",$newgoods);
if(count($tmparr)>2){
	$newgoods_count=$tmparr[1];
	$newgoods_order=$tmparr[2];
}else{
	$newgoods_count=8;
	$newgoods_order=3;
}

$tmparr=explode(",",$hotgoods);
if(count($tmparr)>2){
	$hotgoods_count=$tmparr[1];
	$hotgoods_order=$tmparr[2];
}else{
	$hotgoods_count=8;
	$hotgoods_order=4;
}

if(!($zjsalegoods_count==0&&$weeksalegoods_count==0&&$newgoods_count==0&&$hotgoods_count==0)){

	$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newgoods"=>$newgoods_order,"hotgoods"=>$hotgoods_order);
	asort($homegoods_arr);
	
	$n=1;
	foreach($homegoods_arr as $key=>$homegoods){
		if($n==1)$current=' class="current" ';else $current=' ';
		if($home_goods_js=='')$home_goods_js='get_home_goods("'.$key.'");';
		if($key=='zjsalegoods'){
			$tab_goods.='<li'.$current.'onclick="it618_tuan_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_tuan_lang['t91'].'</li>';
		}
		
		if($key=='weeksalegoods'){
			$tab_goods.='<li'.$current.'onclick="it618_tuan_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_tuan_lang['t93'].'</li>';
		}
		
		if($key=='newgoods'){
			$tab_goods.='<li'.$current.'onclick="it618_tuan_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_tuan_lang['s989'].'</li>';
		}
		
		if($key=='hotgoods'){
			$tab_goods.='<li'.$current.'onclick="it618_tuan_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_tuan_lang['s990'].'</li>';
		}
		
		$tmpurl=it618_tuan_getrewrite('tuan_wap','search@0','plugin.php?id=it618_tuan:wap&pagetype=search&cid=0');
		if($n==1)$bdstyle=' ;display:';else $bdstyle=' ;display:none';
		$home_goods.='<dl class="list" id="searchli_bd'.($n-1).'" style="border-top:none; margin:0;'.$bdstyle.'">
						<dd style="background-color:#fff;padding:10px">
							<div style="-webkit-overflow-scrolling:touch;overflow:scroll;">
							<table class="tablelist3" id="home_goods_'.$key.'"></table>
							</div>
						</dd>
					  </dl>';
		
		$n=$n+1;
	}
	
	$homegoods_str='<dl style="margin:0;background-color:#fff;padding:0">
	<style>
	.divsearchli{border-bottom:#f9f9f9 1px solid;background-color:#fff;}
	.divsearchli ul{height:38px;}
	.divsearchli ul li{height:38px;line-height:38px; margin:0 13px;font-size:14px;}
	</style>
	<div class="divsearchli"><ul>'.$tab_goods.'</ul></div></dl>'.$home_goods.'<script>'.$home_goods_js.'</script>';
}


$allproductlist=it618_tuan_getrewrite('tuan_wap','product_list@0','plugin.php?id=it618_tuan:wap&pagetype=product_list&cid=0');

$hotclassgoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('hotclassgoods');
$hotclassgoods=explode('@@@',$hotclassgoods);
$tmpidsarr=explode(',',$hotclassgoods[2]);
$tdn=1;
for($i=1;$i<=count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i-1]);
	$query = DB::query("SELECT g.id as it618_pid FROM ".DB::table('it618_tuan_goods')." g left join ".DB::table('it618_tuan_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and g.id=".$id);
	while($it618_homegoods = DB::fetch($query)) {
		$it618_tuan_goods=C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
		$pj=$it618_tuan_goods['it618_pjpfstr'];
		
		$jfbl='';
		if($it618_tuan_goods['it618_jfbl']>0&&$it618_tuan_goods['it618_saleprice']>0){
			if(C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($it618_tuan_goods['id'])>0){
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').str_replace(".00","",$it618_tuan_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').intval($it618_tuan_goods['it618_saleprice']*$it618_tuan_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
	
		if($tuanstyle=='1'){
			$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
		
			$it618goods_hot.='<tr>
							<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/></a></td>
							<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
								<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
								<div class="tddes">'.$pj.' '.$views.'</div>
								<ul class="tdprice">
								  <li>
								  <span style="float:right">'.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</span>
								  <strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong>
								  </li>
								</ul>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr1='<tr class="trimg">';
				$trtmpstr2='<tr class="trabout">';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr1.='<td '.$tdstr.'>'.$jfbl.'<a href="'.$tmpurl.'">
							<img class="lazy" data-original="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/>
						</a></td>';
			
			$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
							<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
							<div class="tddes"><span style="float:right">'.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</span>'.$pj.'</div>
							<div class="tdprice"><strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong></div>
						</a></td>';
						
			if($tdn%2==0){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$it618goods_hot.=$trtmpstr1.$trtmpstr2;
			}
			
			$tdn=$tdn+1;
		}
	}
}

if($tuanstyle=='1'){
	$tmparr=explode('</tr>',$it618goods_hot);
	if(count($tmparr)>1){
		$it618goods_hot=$it618goods_hot.'@@@';
		$it618goods_hot=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$it618goods_hot);
	}
	$tmpdtheight=23;
}else{
	$trtmpstr=$trtmpstr1.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr);
	if(count($tmparr)>1){
		$trtmpstr1.='</tr>';
		$trtmpstr2.='</tr>';
		$it618goods_hot.=$trtmpstr1.$trtmpstr2;
	}
	$tmpdtheight=13;
}

$tmpurl=it618_tuan_getrewrite('tuan_wap','search@0','plugin.php?id=it618_tuan:wap&pagetype=search&cid=0');
$it618goods_hot='<dl class="list">
					<dd><dl style="padding:0">
						<dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:17px; padding-right:11px;background-color:#f6f6f6;height:'.$tmpdtheight.'px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_tuan_lang['t88'].'<img src="source/plugin/it618_tuan/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p>'.$it618_tuan_lang['t314'].'</dt>
						<dd id="dd_goods_hot">
						<table width="100%" class="tablelist'.$tuanstyle.'">
							'.$it618goods_hot.'
						</table>
						</dd>
					</dl></dd>
				</dl>';

$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' ORDER BY it618_order");
while($it618_tuan_class1 = DB::fetch($query1)) {
	
	if($it618_tuan_class1['it618_goodscount']==0)continue;
	
	$it618goods='';$tdn=1;
	foreach(C::t('#it618_tuan#it618_tuan_goods')->fetch_all_by_search(
		'g.it618_state=1','g.it618_order desc,g.id desc',0,$it618_tuan_class1['id'],0,0,0,'',0,0,$startlimit,$it618_tuan_class1['it618_wapgoodscount']
	) as $it618_tuan_goods) {
	
		$pj=$it618_tuan_goods['it618_pjpfstr'];
		
		$jfbl='';
		if($it618_tuan_goods['it618_jfbl']>0&&$it618_tuan_goods['it618_saleprice']>0){
			if(C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($it618_tuan_goods['id'])>0){
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').str_replace(".00","",$it618_tuan_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').intval($it618_tuan_goods['it618_saleprice']*$it618_tuan_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
		
		if($tuanstyle=='1'){
			$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
		
			$it618goods.='<tr>
							<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/></a></td>
							<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
								<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
								<div class="tddes">'.$pj.' '.$views.'</div>
								<ul class="tdprice">
								  <li>
								  <span style="float:right">'.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</span>
								  <strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong>
								  <del>&yen;'.$it618_tuan_goods['it618_price'].'</del>
								  </li>
								</ul>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr1='<tr class="trimg">';
				$trtmpstr2='<tr class="trabout">';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr1.='<td '.$tdstr.'>'.$jfbl.'<a href="'.$tmpurl.'">
							<img class="lazy" data-original="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/>
						</a></td>';
			
			$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
						<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
						<div class="tddes"><span style="float:right">'.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</span>'.$pj.'</div>
						<div class="tdprice"><strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong></div>
					</a></td>';
						
			if($tdn%2==0){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$it618goods.=$trtmpstr1.$trtmpstr2;
			}
			
			$tdn=$tdn+1;
		}
	}

	if($tuanstyle=='1'){
		$tmparr=explode('</tr>',$it618goods);
		if(count($tmparr)>1){
			$it618goods=$it618goods.'@@@';
			$it618goods=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$it618goods);
		}
		$tmpdtheight=23;
	}else{
		$trtmpstr=$trtmpstr1.'@@@';
		$tmparr=explode('</td>@@@',$trtmpstr);
		if(count($tmparr)>1){
			$trtmpstr1.='</tr>';
			$trtmpstr2.='</tr>';
			$it618goods.=$trtmpstr1.$trtmpstr2;
		}
		$tmpdtheight=13;
	}
		
		$tmpurl=it618_tuan_getrewrite('tuan_wap','search@'.$it618_tuan_class1['id'],'plugin.php?id=it618_tuan:wap&pagetype=search&cid='.$it618_tuan_class1['id']);
		$str_goods.='<dl class="list">
						<dd><dl style="padding:0">
							<dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:17px; padding-right:11px;background-color:#f6f6f6;height:'.$tmpdtheight.'px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_tuan_lang['t88'].'<img src="source/plugin/it618_tuan/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p>'.$it618_tuan_class1['it618_classname'].$it618_tuan_lang['s59'].'</dt>
							<dd id="dd_goods'.$it618_tuan_class1['id'].'">
							<table width="100%" class="tablelist'.$tuanstyle.'">
								'.$it618goods.'
							</table>
							</dd>
						</dl></dd>
					</dl>';

}

$searchurl=it618_tuan_getrewrite('tuan_wap','search@0','plugin.php?id=it618_tuan:wap&pagetype=search&cid=0&findkey=1','?findkey=1');

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:wap_tuan');
?>