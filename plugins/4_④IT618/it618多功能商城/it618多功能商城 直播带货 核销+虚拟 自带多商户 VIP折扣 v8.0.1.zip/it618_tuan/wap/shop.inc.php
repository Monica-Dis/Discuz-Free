<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sid=intval($_GET['cid']);
if(!tuan_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_tuan_getrewrite('tuan_shop',$sid,'plugin.php?id=it618_tuan:shop&sid='.$sid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_tuan_getrewrite('tuan_shop',$sid,'plugin.php?id=it618_tuan:shop&sid='.$sid);
	}

	dheader("location:$tmpurl");
}

if($it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($sid)){	
	$it618_state=$it618_tuan_shop['it618_state'];
	if($it618_state==0){
		$error=1;
		$errormsg=it618_tuan_getlang('s334');
	}elseif($it618_state==1){
		$error=1;
		$errormsg=it618_tuan_getlang('s335');
	}else{
		$it618_htstate=$it618_tuan_shop['it618_htstate'];
		if($it618_htstate==0){
			$error=1;
			$errormsg=it618_tuan_getlang('s336');
		}elseif($it618_htstate==2){
			$error=1;
			$errormsg=it618_tuan_getlang('s337');
		}else{
			$ShopId=$it618_tuan_shop['id'];
		}
	}
}else{
	$error=1;
	$errormsg=it618_tuan_getlang('s338');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
	include template('it618_tuan:wap_tuan');
	return;
}

$navtitle=$it618_tuan_shop['it618_name'].' - '.$sitetitle;

$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
$viewscount=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_tuan_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
$salecount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_sale')." WHERE it618_shopid=$ShopId and it618_state!=0");

if($it618_tuan['tuan_style']>2){
	$tuanstyle=getcookie('tuanstyle');
	if($tuanstyle==''){
		if($it618_tuan['tuan_style']==3)$tuanstyle='1';else $tuanstyle='2';
	}
}else{
	if($it618_tuan['tuan_style']==1)$tuanstyle='1';else $tuanstyle='2';
}

$shopgoodsarr=explode("it618_split",it618_tuan_getshopgoods($ShopId,1,1));

$shopgoods_views=it618_tuan_getshopgoods($ShopId,1,1,"views");
$shopgoods_hot=it618_tuan_getshopgoods($ShopId,1,1,"hot");

$wapfooter.='<div style="display:none">'.$it618_tuan_shop['it618_tongji'].'</div>';

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:wap_tuan');
?>