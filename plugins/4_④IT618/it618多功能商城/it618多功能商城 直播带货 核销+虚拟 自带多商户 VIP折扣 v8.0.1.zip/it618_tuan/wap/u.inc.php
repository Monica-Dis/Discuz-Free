<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!tuan_is_mobile()){
	dheader("location:$tuan_home");
}

$navtitle=it618_tuan_getlang('s832').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_tuan_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
	include template('it618_tuan:wap_tuan');
	return;
}

$menuusername=$_G['username'];
$u_avatarimg=it618_tuan_discuz_uc_avatar($_G['uid'],'middle');
$creditname=$_G['setting']['extcredits'][$it618_tuan['tuan_credit']]['title'];
$creditnum=DB::result_first("select extcredits".$it618_tuan['tuan_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_buygroup=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$tmpurl_myvip=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$viplogo='source/plugin/it618_credits/images/group.png';
}

if($IsGroup==1){
	$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	$viplogo='source/plugin/it618_group/images/group.png';
}

if($IsUnion==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
}

$ucurl=it618_tuan_getrewrite('tuan_wap','uc@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=uc');
$ucorderurl=it618_tuan_getrewrite('tuan_wap','uc_order@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=uc_order');

$uccount=C::t('#it618_tuan#it618_tuan_sale')->count_by_search(0,"s.it618_state!=0 ",'','',$_G['uid']);
$ucmoney=C::t('#it618_tuan#it618_tuan_sale')->sum_money_by_search(0,"s.it618_state!=0 ",'','',$_G['uid']);

$ucordercount=C::t('#it618_tuan#it618_tuan_order')->count_by_search(0,'','','',$_G['uid']);
$ucordermoney=C::t('#it618_tuan#it618_tuan_order')->sum_money_by_search(0,'','','',$_G['uid']);

$shoptmp=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid_ok($_G['uid']);
if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
	$scurl=it618_tuan_getrewrite('tuan_wap','sc@'.$shoptmp['id'],'plugin.php?id=it618_tuan:wap&pagetype=sc&cid='.$shoptmp['id']);
	$scorderurl=it618_tuan_getrewrite('tuan_wap','sc_order@'.$shoptmp['id'],'plugin.php?id=it618_tuan:wap&pagetype=sc_order&cid='.$shoptmp['id']);
	$scgwcurl=it618_tuan_getrewrite('tuan_wap','sc_gwc@'.$shoptmp['id'],'plugin.php?id=it618_tuan:wap&pagetype=sc_gwc&cid='.$shoptmp['id']);
	
	$sccount=C::t('#it618_tuan#it618_tuan_sale')->count_by_search($shoptmp['id'],"s.it618_state!=0 ");
	$scmoney=C::t('#it618_tuan#it618_tuan_sale')->sum_money_by_search($shoptmp['id'],"s.it618_state!=0 ");
	
	$scordercount=C::t('#it618_tuan#it618_tuan_order')->count_by_search($shoptmp['id']);
	$scordermoney=C::t('#it618_tuan#it618_tuan_order')->sum_money_by_search($shoptmp['id']);
	
	$isshop=1;
}

if($it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_uid($_G['uid'])){
	
	$thdurl=it618_tuan_getrewrite('tuan_wap','thd@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=thd');
	
	$thdcount=C::t('#it618_tuan#it618_tuan_sale')->count_by_search(0,"s.it618_tel!='' and s.it618_state!=0 and s.it618_gthdid=".$it618_tuan_shop_thd['id']);
	$thdmoney=C::t('#it618_tuan#it618_tuan_sale')->sum_money_by_search(0,"s.it618_tel!='' and s.it618_state!=0 and s.it618_gthdid=".$it618_tuan_shop_thd['id']);
	$isthd=1;
}
	
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:wap_tuan');
?>