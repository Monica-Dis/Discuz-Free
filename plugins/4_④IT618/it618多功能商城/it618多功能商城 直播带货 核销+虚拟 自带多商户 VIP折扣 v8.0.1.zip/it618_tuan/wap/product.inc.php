<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pid=intval($_GET['cid']);
if(!tuan_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	if(isset($_GET['e'])){
		if($urltmp!='')$urltmp.='&e='.$_GET['e'];else $urltmp.='e='.$_GET['e'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_tuan_getrewrite('tuan_product',$pid,'plugin.php?id=it618_tuan:product&pid='.$pid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_tuan_getrewrite('tuan_product',$pid,'plugin.php?id=it618_tuan:product&pid='.$pid);
	}
	
	dheader("location:$tmpurl");
}

if(!($it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id_state($pid,1))){
	$error=1;
	$errormsg=it618_tuan_getlang('s470');
}else{
	if($it618_tuan_goods['it618_type']==0){
		if($it618_tuan_goods['it618_wapurl']==''){
			$waphomeurl=it618_tuan_getrewrite('tuan_wap','','plugin.php?id=it618_tuan:wap');
			dheader("location:$waphomeurl");
		}else{
			dheader("location:".$it618_tuan_goods['it618_wapurl']);
		}
	}else{
		$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_goods['it618_shopid']);
		if($it618_tuan_shop['it618_state']!=2||$it618_tuan_shop['it618_htstate']!=1){
			$error=1;
			$errormsg=it618_tuan_getlang('s470');
		}
	}
}

$shopuname='<a href="'.it618_tuan_rewriteurl($it618_tuan_shop['it618_uid']).'" target="_blank">'.it618_tuan_getusername($it618_tuan_shop['it618_uid']).'</a> <img src="'.it618_tuan_getonlinestate($it618_tuan_shop['it618_uid']).'" style="margin-top:-3px">';

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
	include template('it618_tuan:wap_tuan');
	return;
}

$navtitle=$it618_tuan_goods['it618_name'].' - '.$sitetitle;

$sd_userpower=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('sd_userpower');

$sd_userpower=explode(",",$sd_userpower);
if(in_array($_G['uid'],$sd_userpower)&&$_G['uid']>0){
	$sdcss='color:red';
	$sdbtn='onclick="salesd()"';
}

for($i=0;$i<=4;$i++){
	if($i==0){$tmpi='';$tmpcss=' class="firstimg curimg"';}else {$tmpi=$i;$tmpcss='';}
	$it618_picbig=$it618_tuan_goods['it618_picbig'.$tmpi];
	if($it618_picbig!=''){
		$goodspicbig.='<div class="swiper-slide"><img class="img" '.$sdbtn.' src="'.it618_tuan_getgoodspic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_picbig,$i).'" /></div>';
	}
}

if($IsGroup==1){
	if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='tuan' and it618_pid=$pid")){
		$isvip=1;
	}
}

C::t('#it618_tuan#it618_tuan_goods')->update_it618_views_by_id($pid);

$tmpcount='<font color=#999>'.$it618_tuan_lang['t114'].' <font style="color:red">'.$it618_tuan_goods['it618_salecount'].'</font> '.$it618_tuan_lang['t197'].' <font style="color:red">'.$it618_tuan_goods['it618_count'].'</font></font>';

$goodspicstr=it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']);

if($it618_tuan_goods['it618_saletype']==1){
	$it618_saletype='<input type="hidden" id="saletype" value="1"><font color=#f60>'.it618_tuan_getlang('s719').'</font>';
}

if($it618_tuan_goods['it618_saletype']==2){
	$it618_saletype='<input type="hidden" id="saletype" value="2"><font color=#f60>'.it618_tuan_getlang('s720').'</font>';
}

if($it618_tuan_goods['it618_saletype']==3){
	$it618_saletype='<input type="hidden" id="saletype" value="3"><font color=#f60>'.it618_tuan_getlang('s836').'</font>';
}

if($it618_tuan_goods['it618_saletype']==4){
	$it618_saletype='<div class="selectdiv1"><a class="current" href="javascript:void(0)" onclick="setselect(\'saletype\',0,1)" name="saletype"><span>'.it618_tuan_getlang('t353').'</span><i></i></a><a href="javascript:void(0)" onclick="setselect(\'saletype\',1,2)" name="saletype"><span>'.it618_tuan_getlang('t354').'</span><i></i></a><input type="hidden" id="saletype" value="1"></div>';
}


$zk=sprintf("%.2f", $it618_tuan_goods['it618_saleprice']/$it618_tuan_goods['it618_price'])*10;
if($it618_tuan_goods['it618_isservice1']==1)$service.=it618_tuan_getlang('s107').' ';
if($it618_tuan_goods['it618_isservice2']==1)$service.=it618_tuan_getlang('s108').' ';
if($it618_tuan_goods['it618_isservice3']==1)$service.=it618_tuan_getlang('s109').' ';

if($it618_tuan_goods['it618_meal_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods')." where it618_shopid=".$it618_tuan_goods['it618_shopid']." and it618_meal_id=".$it618_tuan_goods['it618_meal_id']." ORDER BY it618_mealorder");
	while($it618_meal = DB::fetch($query)) {
		if($it618_meal['id']==$it618_tuan_goods['id']){
			$meal.='<a class="current" href="javascript:void(0)"><span>'.$it618_meal['it618_mealname'].'<em>&yen;</em>'.$it618_meal['it618_saleprice'].'</span><i></i></a>';
		}else{
			$meal.='<a href="plugin.php?id=it618_tuan:product&pid='.$it618_meal['id'].'"><span>'.$it618_meal['it618_mealname'].'<em>&yen;</em>'.$it618_meal['it618_saleprice'].'</span><i></i></a>';
		}
	}
}

$it618_message=$it618_tuan_goods['it618_message'];
$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img class="lazy" data-original="\1"/>',$it618_message);
$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);

$it618_tbts=$it618_tuan_goods['it618_tbts'];
$it618_tbts=explode('
',$it618_tbts);
for($i=0;$i<count($it618_tbts);$i++){
	$it618_tbtsli.='<li>'.$it618_tbts[$i].'</li>';
}

$pjcount=C::t('#it618_tuan#it618_tuan_sale')->countpj_by_pid($it618_tuan_goods['id']);
if($pjcount>0){
	$pjname=C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_pj_by_id($it618_tuan_goods['it618_class1_id']);
	$pjname=explode("_",$pjname);
	
	$pjscore=C::t('#it618_tuan#it618_tuan_sale')->fetch_sumpjscore_by_pid($it618_tuan_goods['id']);
	$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);
	$pjavgscore2=sprintf( "%.1f",$pjscore['score2']/$pjcount);
	$pjavgscore3=sprintf( "%.1f",$pjscore['score3']/$pjcount);
	$pjavgscore4=sprintf( "%.1f",$pjscore['score4']/$pjcount);
	$pjpl1=sprintf( "%.1f",$pjavgscore1/5*100);
	$pjpl2=sprintf( "%.1f",$pjavgscore2/5*100);
	$pjpl3=sprintf( "%.1f",$pjavgscore3/5*100);
	$pjpl4=sprintf( "%.1f",$pjavgscore4/5*100);
	
	$pj1_count1=C::t('#it618_tuan#it618_tuan_sale')->countpj1_by_pid_score($it618_tuan_goods['id'],1);
	$pj1_count2=C::t('#it618_tuan#it618_tuan_sale')->countpj1_by_pid_score($it618_tuan_goods['id'],2);
	$pj1_count3=C::t('#it618_tuan#it618_tuan_sale')->countpj1_by_pid_score($it618_tuan_goods['id'],3);
	$pj1_count4=C::t('#it618_tuan#it618_tuan_sale')->countpj1_by_pid_score($it618_tuan_goods['id'],4);
	$pj1_count5=C::t('#it618_tuan#it618_tuan_sale')->countpj1_by_pid_score($it618_tuan_goods['id'],5);
	
	$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
	
	$pj1_pl1=intval($pj1_count1/$pjcount*100);
	$pj1_pl2=intval($pj1_count2/$pjcount*100);
	$pj1_pl3=intval($pj1_count3/$pjcount*100);
	$pj1_pl4=intval($pj1_count4/$pjcount*100);
	$pj1_pl5=intval($pj1_count5/$pjcount*100);
	
	$pj=$pjcount.' '.it618_tuan_getlang('s482').' '.$pjavgscore1.' '.it618_tuan_getlang('s483').':'.$mydpl.'% ';
	$it618_pjpfstr=$pjcount.' '.it618_tuan_getlang('s482').' '.$pjavgscore1.' '.it618_tuan_getlang('s483').':'.$mydpl.'% ';
}else{
	$pj=it618_tuan_getlang('s484');	
	$it618_pjpfstr=it618_tuan_getlang('s484').' ';	
}

$pjpicjs='<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
			<script src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js?v3.9" charset="utf-8"></script>
			<script src="source/plugin/it618_tuan/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';

DB::query("UPDATE ".DB::table('it618_tuan_goods')." SET it618_pjpfstr='".$it618_pjpfstr."' WHERE id=$pid");

if(($it618_tuan_goods['it618_saletype']==2 || $it618_tuan_goods['it618_saletype']==4) && $it618_tuan_goods['it618_isyunfeifree']==0){
	$isyunfei=1;
	$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_goods['it618_shopid']);
	
	$kdcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_kdyunfei')." where it618_shopid=".$it618_tuan_goods['it618_shopid']);
	$shopid=$it618_tuan_goods['it618_shopid'];
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_kdarea')." ORDER BY it618_order");
	$n1=1;
	$tmp1='';
	while($it618_tmp1 = DB::fetch($query)) {
		if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_kdyunfei')." where it618_shopid=".$shopid." and it618_kdareaid=".$it618_tmp1['id'])>0){
			$kdarea.='<option value='.$it618_tmp1['id'].'>'.$it618_tmp1['it618_name'].'</option>';
			$n2=1;
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_kdyunfei')." where it618_shopid=".$shopid." and it618_order<>0 and it618_kdareaid=".$it618_tmp1['id']." ORDER BY it618_order");

			while($it618_tmp2 =	DB::fetch($query2)) {
				
				$kdname=C::t('#it618_tuan#it618_tuan_kd')->fetch_name_by_id($it618_tmp2['it618_kdid']);
				
				
				if($it618_tmp2['it618_firstprice']>0&&$it618_tmp2['it618_firstscore']>0){
					$goodsjfname=$_G['setting']['extcredits'][$it618_tmp2['it618_jfid']]['title'];
					$goodspricestr1='\u00A5'.$it618_tmp2['it618_firstprice'].' + '.$it618_tmp2['it618_firstscore'].$goodsjfname;
					$goodspricestr2='\u00A5'.$it618_tmp2['it618_price'].' + '.$it618_tmp2['it618_score'].$goodsjfname;
				}else{
					if($it618_tmp2['it618_firstprice']>0){
						$goodspricestr1='\u00A5'.$it618_tmp2['it618_firstprice'];
						$goodspricestr2='\u00A5'.$it618_tmp2['it618_price'];
					}
					
					if($it618_tmp2['it618_firstscore']>0){
						$goodsjfname=$_G['setting']['extcredits'][$it618_tmp2['it618_jfid']]['title'];
						$goodspricestr1=$it618_tmp2['it618_firstscore'].$goodsjfname;
						$goodspricestr2=$it618_tmp2['it618_score'].$goodsjfname;
					}
				}
				
				$tmp1.='select_kd['.$n1.']['.$n2.'] = new Option("'.$kdname.' '.$it618_tmp2['it618_firstcount'].$it618_tuan_goods['it618_unit'].it618_tuan_getlang('s755').' '.$goodspricestr1.' '.it618_tuan_getlang('s756').'1'.$it618_tuan_goods['it618_unit'].' '.it618_tuan_getlang('s757').' '.$goodspricestr1.'", "'.$it618_tmp2['id'].'");';

				$n2=$n2+1;
			}
			$n1=$n1+1;
		}
	}
	
	$kdjs='var arrcount='.$kdcount.';
		var select_kd = new Array(arrcount+1);
		
		for (i=0; i<arrcount+1; i++) 
		{
		 select_kd[i] = new Array();
		}
		
		'.$tmp1.'
		
		function redirec_kd(x)
		{
		 var temp = document.getElementById("it618_kd"); 
		 temp.options.length=1;
		 for (i=1;i<select_kd[x].length;i++)
		 {
		  temp.options[i]=new Option(select_kd[x][i].text,select_kd[x][i].value);
		 }
		 temp.options[0].selected=true;
		
		}';
}

$timeflag=0;$isxgok=0;
if($it618_tuan_goods['it618_xgtype']==0)$isxgok=1;

if($it618_tuan_goods['it618_xgtype']==1){
	$timestr=$it618_tuan_goods['it618_xgtime1'].' - '.$it618_tuan_goods['it618_xgtime2'];
	
	$timetmp1=explode(" ",$it618_tuan_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_tuan_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_tuan_getlang('s952');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_tuan_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_tuan_goods['it618_xgtime1'];
		}else{
			$timetip=it618_tuan_getlang('s954');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_tuan_goods['it618_xgtime2'];
			$isxgok=1;
		}
	}
	
	$isxg=1;
}

if($it618_tuan_goods['it618_xgtype']==2){
	$timetmp1=explode(" ",$it618_tuan_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_tuan_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_tuan_getlang('s955').' '.$timetmp1[1].' - '.$timetmp2[1];
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_tuan_getlang('s952');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_tuan_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_tuan_goods['it618_xgtime1'];
		}else{
			$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
			$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
			$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
			
			if($btimecur>$_G['timestamp']){
				$timetip=it618_tuan_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur);
			}
			
			if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
				$timetip=it618_tuan_getlang('s954');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $etimecur);
				$isxgok=1;
			}
			
			if($etimecur<$_G['timestamp']){
				$timetip=it618_tuan_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur1);
			}
		}
	}
	
	$isxg=1;
}

$goodstypeid=0;
$goodstypename='';
$goodstypename1='';
$n=0;

$count=C::t('#it618_tuan#it618_tuan_goods_type')->count_by_pid_ok_isname1($pid);
if($count>0){
	$it618_tuan_goods_types=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name_by_it618_pid1($pid);
}else{
	$it618_tuan_goods_types=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name_by_it618_pid($pid);
}

foreach($it618_tuan_goods_types as $it618_tuan_goods_type) {
	$tmpstr='';
	if($n==0){
		$tmpstr='class="current"';
		$goodstypename=$it618_tuan_goods_type['it618_name'];
		$goodstypeid=$it618_tuan_goods_type['id'];
		
		$tmpcount='<font color=#999>'.$it618_tuan_lang['t114'].' <font style="color:red">'.$it618_tuan_goods_type['it618_salecount'].'</font> '.$it618_tuan_lang['t197'].' <font style="color:red">'.$it618_tuan_goods_type['it618_count'].'</font></font>';
	}
	$goodstypestr.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype\','.$n.',\''.$it618_tuan_goods_type['it618_name'].'\')" name="goodstype"><span>'.$it618_tuan_goods_type['it618_name'].'</span><i></i></a>';
	$n++;
}

if($goodstypename!=''){
	$n=0;
	foreach(C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name1_by_it618_pid_name($pid,$goodstypename) as $it618_tuan_goods_type) {
		$tmpstr='';
		if($n==0){
			$tmpstr='class="current"';
			$goodstypename1=$it618_tuan_goods_type['it618_name1'];
			$goodstypeid=$it618_tuan_goods_type['id'];
		
			$tmpcount='<font color=#999>'.$it618_tuan_lang['t114'].' <font style="color:red">'.$it618_tuan_goods_type['it618_salecount'].'</font> '.$it618_tuan_lang['t197'].' <font style="color:red">'.$it618_tuan_goods_type['it618_count'].'</font></font>';
		}
		
		$goodstypestr1.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype1\','.$n.',\''.$it618_tuan_goods_type['it618_name1'].'\')" name="goodstype1"><span>'.$it618_tuan_goods_type['it618_name1'].'</span><i></i></a>';
		$n=$n+1;
	}
}
	
if($it618_tuan_goods['it618_saletype']!=3){
	
	$goodsthdid=0;
	if(!($it618_tuan_goods['it618_saletype']==2&&$it618_tuan_goods['it618_isthd']==0)){
		$n=1;
		foreach(C::t('#it618_tuan#it618_tuan_goods_thd')->fetch_allok_by_pid($pid) as $it618_tuan_goods_thd) {
			$tmpstr='';
			$goodsthdstr.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodsthd\','.$n.','.$it618_tuan_goods_thd['id'].')" name="goodsthd"><span>'.$it618_tuan_goods_thd['it618_name'].'</span><i></i></a>';
			$n++;
		}
		$shopname=C::t('#it618_tuan#it618_tuan_shop')->fetch_name_by_id($it618_tuan_goods['it618_shopid']);
		if($goodsthdstr!='')$goodsthdstr='<a class="current" href="javascript:void(0)" onclick="setselect(\'goodsthd\',0,0)" name="goodsthd"><span>'.$shopname.'('.$it618_tuan_lang['s1722'].')</span><i></i></a>'.$goodsthdstr;
	}
}

$it618_kdaddr=$it618_tuan_shop['it618_kdaddr'];
if($it618_tuan_shop['it618_kdaddr']==''){
	$it618_kdaddr=$it618_tuan_lang['s1722'];
}

if($it618_tuan_goods['it618_saleprice']>0&&$it618_tuan_goods['it618_score']>0){
	$goodsjfname=$_G['setting']['extcredits'][$it618_tuan_goods['it618_jfid']]['title'];
	$goodspricestr='<em>&yen;</em>'.$it618_tuan_goods['it618_saleprice'].' + '.$it618_tuan_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
	
	$paytype=$it618_tuan_lang['t305'];
}else{
	if($it618_tuan_goods['it618_saleprice']>0){
		$goodspricestr='<em>&yen;</em>'.$it618_tuan_goods['it618_saleprice'];
		
		$paytype=$it618_tuan_lang['t304'];
	}
	
	if($it618_tuan_goods['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_tuan_goods['it618_jfid']]['title'];
		$goodspricestr=$it618_tuan_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
		
		$paytype=$it618_tuan_lang['t303'];
	}
}

$goodspricestrtype=$goodspricestr;
if($it618_tuan_goods['it618_price']>0){
	$goodspricestrtype=$goodspricestr.' <del style="color:#999;font-size:12px"><em style="font-size:12px">&yen;</em>'.$it618_tuan_goods['it618_price'].'</del>';
}

if($it618_tuan_goods['it618_jfbl']>0&&$it618_tuan_goods['it618_saleprice']>0){
	$jfbl='<font color=#888>'.it618_tuan_getlang('s1049').'<font color=red>'.$it618_tuan_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
}

$payokurl=it618_tuan_getrewrite('tuan_wap','uc@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=uc&payok=saleid','?payok=saleid');

$ucurl=it618_tuan_getrewrite('tuan_wap','uc@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=uc');
$shopurl=it618_tuan_getrewrite('tuan_wap','shop@'.$it618_tuan_goods['it618_shopid'],'plugin.php?id=it618_tuan:wap&pagetype=shop&cid='.$it618_tuan_goods['it618_shopid']);

$bottommenu=C::t('#it618_tuan#it618_tuan_bottomnav')->fetch_by_id(1);

$wapfooter.='<div style="display:none">'.$it618_tuan_shop['it618_tongji'].'</div>';

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:wap_tuan');
?>