<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(isset($_GET['cid2'])){
	$classid1=intval($_GET['cid1']);
}else{
	$classid1=intval($_GET['cid']);
}
$classid2=intval($_GET['cid2']);

if(!tuan_is_mobile()){ 
	$tmpurl=it618_tuan_getrewrite('tuan_list','','plugin.php?id=it618_tuan:list');
	if($classid1>0){
		$tmpurl=it618_tuan_getrewrite('tuan_list',$classid1,'plugin.php?id=it618_tuan:list&class1='.$classid1);
	}
	
	if($classid1>0&&$classid2>0){
		$tmpurl=it618_tuan_getrewrite('tuan_list',$classid1.'@'.$classid2,'plugin.php?id=it618_tuan:list&class1='.$classid1.'&class2='.$classid2);
	}
	dheader("location:$tmpurl");
}

$navtitle=$it618_tuan_lang['t317'].' - '.$sitetitle;

$n=1;
$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productclass1\',0,0)" name="productclass1"><span>'.$it618_tuan_lang['s466'].'</span><i></i></a>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	if($it618_tmp['id']==$classid1){
		$classid_n1=$n;
	}
	$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass1\','.$n.','.$it618_tmp['id'].')" name="productclass1"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
	$n=$n+1;
}

if($classid2>0){
	$n=1;
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." WHERE it618_class1_id=$classid1 ORDER BY it618_order");
	while($it618_tmp = DB::fetch($query1)) {
		if($it618_tmp['id']==$classid2){
			$classid_n2=$n;
		}
		$n=$n+1;
	}
}

$n=1;
$areatmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productarea1\',0,0)" name="productarea1"><span>'.$it618_tuan_lang['s466'].'</span><i></i></a>';
foreach(C::t('#it618_tuan#it618_tuan_area1')->fetch_all_by_search() as $it618_tmp) {
	$areatmp.='<a href="javascript:void(0)" onclick="setselect(\'productarea1\','.$n.','.$it618_tmp['id'].')" name="productarea1"><span>'.$it618_tmp['it618_name'].'</span><i></i></a>';
	$n=$n+1;
}

$n=1;
$tuan_hotsw=explode(',',$it618_tuan['tuan_hotsw']);
for($i=0;$i<count($tuan_hotsw);$i++){
	$hotkey.='<a href="javascript:void(0)" onclick="findbykey(\''.$tuan_hotsw[$i].'\')"><span>'.$tuan_hotsw[$i].'</span><i></i></a>';
	$n=$n+1;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:wap_tuan');
?>