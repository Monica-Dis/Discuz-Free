<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';

if(submitcheck('it618submit')){
	$it618_msgisok=$_GET['it618_msgisok'];
	if($_GET['it618_msgtel']=='')$it618_msgisok=0;
	C::t('#it618_tuan#it618_tuan_shop')->update($ShopId,array(
		'it618_msgtel' => $_GET['it618_msgtel'],
		'it618_msgisok' => $it618_msgisok
	));
	
	it618_cpmsg(it618_tuan_getlang('s682'), "plugin.php?id=it618_tuan:sc_message", 'succeed');
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_tuan/config/message.php';
}

if($it618_isok==1){
	$tmpstr='<font color="green">'.it618_tuan_getlang('s683').'</font> ';
	if($it618_body_tk_user_isok==1)$tmpstr.='<img src="source/plugin/it618_tuan/images/se.gif">';
	
	$tmpstr.='<br><font color="green">'.it618_tuan_getlang('s684').'</font> ';
	if($it618_body_sale_user_isok==1)$tmpstr.='<img src="source/plugin/it618_tuan/images/se.gif">';
	
	$tmpstr.='<br><font color="green">'.it618_tuan_getlang('s766').'</font> ';
	if($it618_body_sale2state_user_isok==1)$tmpstr.='<img src="source/plugin/it618_tuan/images/se.gif">';
	
	$tmpstr.='<br><br><img src="source/plugin/it618_tuan/images/se.gif"> '.it618_tuan_getlang('s685');
	
}else{
	$tmpstr=it618_tuan_getlang('s686');
}

it618_showformheader("plugin.php?id=it618_tuan:sc_message");
showtableheaders(it618_tuan_getlang('s687'),'it618_tuan_shop');

$it618_tuan_shop=DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_shop')." where id=".$ShopId);
if($it618_tuan_shop['it618_msgisok']==1)$it618_msgisok_checked='checked="checked"';else $it618_msgisok_checked="";
echo '
<tr><td width=130>'.it618_tuan_getlang('s688').'</td><td style="line-height:22px">'.$tmpstr.'</td></tr>
<tr><td>'.it618_tuan_getlang('s689').'</td><td><input type="checkbox" id="it618_msgisok" name="it618_msgisok" value="1" style="vertical-align:middle" '.$it618_msgisok_checked.'> <label for="it618_msgisok">'.it618_tuan_getlang('s690').'</label></td></tr>
<tr><td>'.it618_tuan_getlang('s691').'</td><td><input type="text" class="txt" style="width:300px" name="it618_msgtel" value="'.$it618_tuan_shop['it618_msgtel'].'"> '.it618_tuan_getlang('s692').'</td></tr>
<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_tuan_getlang('s693').'" /></div></td></tr>';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>