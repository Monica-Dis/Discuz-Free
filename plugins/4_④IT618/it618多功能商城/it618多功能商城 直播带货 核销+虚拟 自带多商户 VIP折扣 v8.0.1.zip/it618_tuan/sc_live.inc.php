<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';

if($IsGoods==0){
	it618_cpmsg($it618_tuan_lang['s1176'], '', 'error');
}

$it618_video = $_G['cache']['plugin']['it618_video'];
$it618_chat = $_G['cache']['plugin']['it618_chat'];

if($it618_video['seotitle']!=''){
	$it618_type='it618_video';
}

if(submitcheck('it618submit')){
	$it618_videoiframe=str_replace("'",'"',$_GET["it618_videoiframe"]);
	$it618_videoiframe=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder=0 allowfullscreen=1>',$it618_videoiframe);
	
	$tmparr=explode("<iframe",$it618_videoiframe);
	if(count($tmparr)>1){
		$urlarr=explode("https://",$_G['siteurl']);
		if(count($urlarr)>1){
			$it618_videoiframe=str_replace("http://","https://",$it618_videoiframe);
		}
	}
	
	if($it618_tuan_live=C::t('#it618_tuan#it618_tuan_live')->fetch_by_shopid($ShopId)){
		C::t('#it618_tuan#it618_tuan_live')->update($it618_tuan_live['id'],array(
			'it618_name' => $_GET["it618_name"],
			'it618_type' => $_GET["it618_type"],
			'it618_islogin' => intval($_GET["it618_islogin"]),
			'it618_ischat' => intval($_GET["it618_ischat"]),
			'it618_isip' => intval($_GET["it618_isip"]),
			'it618_isaddr' => intval($_GET["it618_isaddr"]),
			'it618_videourl' => $_GET["it618_videourl"],
			'it618_videoiframe' => $it618_videoiframe,
			'it618_liveid' => intval($_GET["it618_liveid"]),
			'it618_message' => $_GET["it618_message"]
		));
	}else{
		C::t('#it618_tuan#it618_tuan_live')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_name' => $_GET["it618_name"],
			'it618_type' => $_GET["it618_type"],
			'it618_islogin' => intval($_GET["it618_islogin"]),
			'it618_ischat' => intval($_GET["it618_ischat"]),
			'it618_isip' => intval($_GET["it618_isip"]),
			'it618_isaddr' => intval($_GET["it618_isaddr"]),
			'it618_videourl' => $_GET["it618_videourl"],
			'it618_videoiframe' => $it618_videoiframe,
			'it618_liveid' => intval($_GET["it618_liveid"]),
			'it618_message' => $_GET["it618_message"]
	    ), true);
	}

	it618_cpmsg(it618_tuan_getlang('s1177'), "plugin.php?id=it618_tuan:sc_live$adminsid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_tuan:sc_live$adminsid");
showtableheaders(it618_tuan_getlang('s1175'),'it618_tuan_brand');

$it618_tuan_live=C::t('#it618_tuan#it618_tuan_live')->fetch_by_shopid($ShopId);
if($it618_tuan_live['it618_name']=='')$it618_name=$it618_tuan_lang['s1153'];else $it618_name=$it618_tuan_live['it618_name'];
$type0='selected="selected"';$type1='';$type2='';$type3='';
$typecss1='none';$typecss2='none';$typecss3='none';
if($it618_tuan_live['it618_type']==1){
	$type1='selected="selected"';
	$typecss1='';$typecss2='none';$typecss3='none';
}
if($it618_tuan_live['it618_type']==2){
	$type2='selected="selected"';
	$typecss1='none';$typecss2='';$typecss3='none';
}
if($it618_tuan_live['it618_type']==3){
	$type3='selected="selected"';
	$typecss1='none';$typecss2='none';$typecss3='';
}

if($it618_tuan_live['it618_islogin']==1)$it618_islogin_checked='checked="checked"';else $it618_islogin_checked="";
if($it618_tuan_live['it618_ischat']==1)$it618_ischat_checked='checked="checked"';else $it618_ischat_checked="";
if($it618_tuan_live['it618_isip']==1)$it618_isip_checked='checked="checked"';else $it618_isip_checked="";
if($it618_tuan_live['it618_isaddr']==1)$it618_isaddr_checked='checked="checked"';else $it618_isaddr_checked="";

$tmptypestr='<option value=1 '.$type1.'>'.$it618_tuan_lang['s1173'].'</option><option value=2 '.$type2.'>'.$it618_tuan_lang['s1174'].'</option>';

if($it618_type=='it618_video'){
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_live')." where it618_chkstate=1 and it618_isok=0");
	while($it618_video_live = DB::fetch($query)) {
		$liveidtmp.='<option value='.$it618_video_live['id'].'>'.date('Y-m-d H:i:s', $it618_video_live['it618_btime']).'-'.date('Y-m-d H:i:s', $it618_video_live['it618_etime']).' '.$it618_video_live['it618_name'].'</option>';
	}
	$liveidtmp=str_replace('<option value='.$it618_tuan_live['it618_liveid'].'>','<option value='.$it618_tuan_live['it618_liveid'].' selected="selected">',$liveidtmp);
}

if($it618_video['seotitle']==''){
	$tmptypestr='';
	if($it618_tuan_live['it618_type']!=3){
		$type0='selected="selected"';$type1='';$type2='';$type3='';
		$typecss1='none';$typecss2='none';$typecss3='none';
	}
}

$chatcss='style="display:none"';
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php')){
	$chatcss='';
}

echo '
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_tuan/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_tuan/kindeditor/php/upload_json.php?shopid='.$ShopId.'\',
			fileManagerJson : \'source/plugin/it618_tuan/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false
		});
	});
	
	function settype(typevalue){
		document.getElementById("trtype1").style.display="none";
		document.getElementById("trtype2").style.display="none";
		document.getElementById("trtype3").style.display="none";
		
		document.getElementById("trtype"+typevalue).style.display="";
	}
	
	function checkvalue(){
		var it618_type=document.getElementById("it618_type").value;
		if(it618_type==1&&document.getElementById("it618_liveid").value=="0"){
			alert("'.it618_tuan_getlang('s1170').'");
			return false;
		}
		if(it618_type==2&&document.getElementById("it618_videourl").value==""){
			alert("'.it618_tuan_getlang('s1171').'");
			document.getElementById("it618_videourl").focus();
			return false;
		}
		if(it618_type==3&&document.getElementById("it618_videoiframe").value==""){
			alert("'.it618_tuan_getlang('s1172').'");
			document.getElementById("it618_videoiframe").focus();
			return false;
		}
	}
</script>

<tr><td width=80>'.$it618_tuan_lang['s1155'].'</td><td><input type="text" name="it618_name" value="'.$it618_name.'" style="width:300px"></td></tr>
<tr><td>'.$it618_tuan_lang['s1156'].'</td><td><select id="it618_type" name="it618_type" onchange="settype(this.value)"><option value=0 '.$type0.'>'.$it618_tuan_lang['s1157'].'</option>'.$tmptypestr.'<option value=3 '.$type3.'>'.$it618_tuan_lang['s1158'].'</option></select> '.$it618_tuan_lang['s1159'].'</td></tr>
<tr id="trtype1" style="display:'.$typecss1.'"><td></td><td><select id="it618_liveid" name="it618_liveid"><option value=0>'.$it618_tuan_lang['s1160'].'</option>'.$liveidtmp.'</select><br><br><font color=green>'.$it618_tuan_lang['s1161'].'</font></td></tr>
<tr id="trtype2" style="display:'.$typecss2.'"><td></td><td><textarea id="it618_videourl" name="it618_videourl" style="width:580px;height:80px">'.$it618_tuan_live['it618_videourl'].'</textarea></td></tr>
<tr id="trtype3" style="display:'.$typecss3.'"><td></td><td><textarea id="it618_videoiframe" name="it618_videoiframe" style="width:580px;height:80px">'.$it618_tuan_live['it618_videoiframe'].'</textarea></td></tr>
<tr><td>'.$it618_tuan_lang['s1162'].'</td><td><input type="checkbox" id="it618_islogin" name="it618_islogin" value="1" style="vertical-align:middle" '.$it618_islogin_checked.'> <label for="it618_islogin">'.it618_tuan_getlang('s1163').'</label></td></tr>
<tr '.$chatcss.'><td>'.$it618_tuan_lang['s1164'].'</td><td><input type="checkbox" id="it618_ischat" name="it618_ischat" value="1" style="vertical-align:middle" '.$it618_ischat_checked.'> <label for="it618_ischat">'.it618_tuan_getlang('s1165').'</label> <input type="checkbox" id="it618_isip" name="it618_isip" value="1" style="vertical-align:middle" '.$it618_isip_checked.'> <label for="it618_isip">'.it618_tuan_getlang('s1166').'</label>  <input type="checkbox" id="it618_isaddr" name="it618_isaddr" value="1" style="vertical-align:middle" '.$it618_isaddr_checked.'> <label for="it618_isaddr">'.it618_tuan_getlang('s1167').'</label></td></tr>
<tr><td>'.$it618_tuan_lang['s1168'].'</td><td><textarea name="it618_message" style="width:670px;height:360px;visibility:hidden;">'.$it618_tuan_live['it618_message'].'</textarea></td></tr>
<tr><td colspan=2><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_tuan_getlang('s1169').'" /></div></td></tr>
';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>