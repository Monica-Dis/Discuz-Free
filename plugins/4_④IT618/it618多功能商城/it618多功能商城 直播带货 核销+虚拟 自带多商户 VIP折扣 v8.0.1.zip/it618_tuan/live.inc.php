<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
$sid=intval($_GET['sid']);

if($it618_tuan_live=C::t('#it618_tuan#it618_tuan_live')->fetch_by_shopid($sid)){
	$videotype=$it618_tuan_live['it618_type'];
	if($videotype>0){
		if($it618_tuan_live['it618_islogin']==1&&$_G['uid']==0){
			echo $it618_tuan_lang['s1178'];exit;
		}
		
		$IsChat=$it618_tuan_live['it618_ischat'];
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
		$player_version=$it618_video_lang['playerversion'];
			
		if($videotype==1){
			$liveid=$it618_tuan_live['it618_liveid'];
			$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($liveid);
			$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($liveid);
			$it618_name=$it618_video_live['it618_name'];
			
			if($it618_video_live['it618_etime']<$_G['timestamp']){
				echo $it618_tuan_lang['s1185'];exit;
			}else{
				if($it618_video_live['it618_btime']>$_G['timestamp']){
					$timeflag=1;
					$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
					$etimestr=date('Y-m-d H:i:s', $it618_video_live['it618_btime']);
					$timetip=$it618_tuan_lang['s1957'].date('Y-m-d H:i:s', $it618_video_live['it618_btime']).' - '.date('Y-m-d H:i:s', $it618_video_live['it618_etime']);
				}
				$it618_url=$it618_video_live['it618_m3u8url'];
				$tmparr=explode("@",$it618_url);
				if(count($tmparr)>1){
					$it618_url=$tmparr[1];
					if($_GET['wap']==0)$it618_url=$tmparr[0];
				}else{
					if($_GET['wap']==0){
						if($it618_video_live['it618_liveset_id']>0)$it618_url=$it618_video_live['it618_flvurl'];
						if($it618_url=='')$it618_url=$it618_video_live['it618_m3u8url'];
					}
				}
			}
		}
		
		if($videotype==2){
			$it618_url=it618_video_cdnkeyurl($it618_tuan_live['it618_videourl']);
		}
		
		if($videotype==3){
			$it618_url=$it618_tuan_live['it618_videoiframe'];
			$urlarr=explode("https://",$_G['siteurl']);
			if(count($urlarr)>1){
				$it618_url=str_replace("http://","https://",$it618_url);
			}
		}
		
	}else{
		echo $it618_tuan_lang['s1179'];exit;
	}
}else{
	echo $it618_tuan_lang['s1179'];exit;
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
if($_GET['wap']==1){
	$stylecount=C::t('#it618_tuan#it618_tuan_wapstyle')->count_by_isok_search();
	$it618_tuan_wapstyle=C::t('#it618_tuan#it618_tuan_wapstyle')->fetch_by_isok_search();
	$tmpurl=it618_tuan_getrewrite('tuan_wap','shop@'.$sid,'plugin.php?id=it618_tuan:wap&pagetype=shop&cid='.$sid);
	include template('it618_tuan:livewap');
}else{
	$tmpurl=it618_tuan_getrewrite('tuan_shop',$sid,'plugin.php?id=it618_tuan:shop&sid='.$sid);
	include template('it618_tuan:live');
}
//From: Dism_taobao-com
?>