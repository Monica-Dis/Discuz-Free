<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

if($it618_tuan['tuan_wap']==1&&(!isset($_GET['iframe']))){
	if(tuan_is_mobile()){ 
		$tmpurl=it618_tuan_getrewrite('tuan_wap','','plugin.php?id=it618_tuan:wap');
		dheader("location:$tmpurl");
	}
}

$bdkey=trim($it618_tuan['tuan_bdkey']);

if(isset($_GET['iframe'])){
	$iframe=1;
}

if(isset($_GET['sid'])){
	$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($_GET['sid']);
}else{
	$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($_GET['tid']);
}

if($it618_tuan_shop['it618_kefuqq']!=''){
	$qqarr=explode(",",$it618_tuan_shop['it618_kefuqq']);
	$qqnamearr=explode(",",$it618_tuan_shop['it618_kefuqqname']);
	for($i=0;$i<count($qqarr);$i++)
	{
		if($qqarr[$i]!='')$shopqq.='<a target=\'_blank\' href=\'https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes\'><img border=\'0\' src=\'source/plugin/it618_tuan/images/qqbtnsmall.gif\' align=\'absmiddle\'/>'.$qqnamearr[$i].'</a> ';
		
	}
	
}

$it618_tuan_shop['it618_about']=str_replace(array("\r\n", "\r", "\n"), '<br>', $it618_tuan_shop['it618_about']);

$metatitle=$it618_tuan_shop['it618_name'].' - '.$metatitle;
$metakeywords=$it618_tuan_goods['it618_seokeywords'];
$metadescription=$it618_tuan_goods['it618_seodescription'];

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:map');
?>