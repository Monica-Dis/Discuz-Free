<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_tuan/js/Calendar.js"></script>
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_tuan/js/jquery.js"></script>

<script>
var dialog_sale,dialog_fahuo,dialog_bz,dialog_tui;
KindEditor.ready(function(K) {K(\'#checkfahuo\').click(function() {
	IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:showfahuo&formhash='.FORMHASH.'", {ac:"it618"},function (data, textStatus){
	dialog_sale = K.dialog({
		width : 550,
		title : \''.it618_tuan_getlang('s758').'\',
		body : \'<div style="padding:5px">\'+data+\'</div>\',
		closeBtn : {
			name : \''.it618_tuan_getlang('s411').'\',
			click : function(e) {
				dialog_sale.remove();
			}
		}
	});
	document.getElementById("code").focus();
	}, "html");	
});});

function read(){
	var code=document.getElementById("code").value;
	if(code==""){
		sendmsg(\'saletips\',"'.it618_tuan_getlang('s412').'");
		return false;
	}
	
	document.getElementById("btn_fahuo").style.display="none";
	document.getElementById("whatsale").innerHTML="";
	
	IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&code="+code+"&formhash='.FORMHASH.'", {ac:"checkcode"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		document.getElementById("whatsale").innerHTML=tmparr[1];
		document.getElementById("btn_fahuo").style.display="";
	}else{
		sendmsg(\'saletips\',tmparr[1]);
	}
	}, "html");

}

var dialog_salekm,salekmid=0;
KindEditor.ready(function(K) {K(\'#salekm\').click(function() {
	getsalekm(K);
});});

function getsalekm(K){
	IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:salekm"+"&saleid="+salekmid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	dialog_salekm = K.dialog({
		width : 620,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.$it618_tuan_lang['t285'].'\',
			click : function(e) {
				dialog_salekm.remove();
				salekmid=0;
			}
		}
	});
	
	}, "html");		
}

function fahuo(){
	var saleid=document.getElementById("saleid").value;
	IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"fahuo"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		document.getElementById("whatsale").innerHTML="";
		sendmsg(\'saletips\',tmparr[1]);
		document.getElementById("btn_fahuo").style.display="none";
		document.getElementById("code").value="";
		document.getElementById("code").focus();
		getsalelist(saleurl);
	}else{
		sendmsg(\'saletips\',tmparr[1]);
	}
	}, "html");

}

function savekd(){
	var saleid=document.getElementById("saleid").value;
	var it618_kdid=document.getElementById("it618_kdid").value;
	var it618_kdid=it618_kdid.replace("selected=selected","");
	var it618_kddan=document.getElementById("it618_kddan").value;
	if(it618_kdid==0){
		sendmsg(\'kdtips\',\''.it618_tuan_getlang('s695').'\');
		return;
	}
	if(it618_kddan==""){
		sendmsg(\'kdtips\',\''.it618_tuan_getlang('s696').'\');
		return;
	}
	
	IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&saleid="+saleid+"&it618_kdid="+it618_kdid+"&it618_kddan="+it618_kddan+"&formhash='.FORMHASH.'", {ac:"savekd"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		alert(tmparr[1]);
		getsalelist(saleurl);
		dialog_fahuo.remove();
	}else{
		sendmsg(\'kdtips\',tmparr[1]);
	}
	}, "html");

}

function tongyitui(saleid){
	if(confirm("'.it618_tuan_getlang('s759').'")){
		IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"tongyitui"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function jujuetui(saleid){
	if(confirm("'.it618_tuan_getlang('s760').'")){
		IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"jujuetui"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function setsalekm(saleid){
	if(salekmid==0){
		salekmid=saleid;
		IT618_TUAN("#salekm").click();
	}
}

var dialog_salebz,salebzid=0;
KindEditor.ready(function(K) {K(\'#salebz\').click(function() {
	getsalebz(K);
});});

function setsalebz(saleid){
	if(salebzid==0){
		salebzid=saleid;
		IT618_TUAN("#salebz").click();
	}
}

function getsalebz(K){
IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:salebz"+"&saleid="+salebzid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	dialog_salebz = K.dialog({
		width : 520,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.$it618_tuan_lang['t285'].'\',
			click : function(e) {
				dialog_salebz.remove();
				salebzid=0;
			}
		}
	});
	
	IT618_TUAN(\'.ns-sub-a\').click(function(){
		
		if(it618_content=document.getElementById("bzvalue").value==\'\'){
			alert("'.$it618_tuan_lang['s1781'].'");
			return;
		}

		IT618_TUAN.post("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax"+"&ac=salebz&saleid="+salebzid+"&formhash='.FORMHASH.'",IT618_TUAN("#it618_salebz").serialize(),function (data, textStatus){
			var tmparr=data.split("it618_split");
		
			if(tmparr[0]=="ok"){
				alert(tmparr[1]);
				dialog_salebz.remove();
				getsalelist(saleurl);
				salebzid=0;
			}else{
				alert(data);
			}
		}, "html");
	})
	
	IT618_TUAN(\'.ns-sub-b\').click(function(){
		dialog_salebz.remove();
		salebzid=0;
	})
	
	}, "html");		
}

function sendmsg(msgid,msgvalue){
	document.getElementById(msgid).innerHTML=msgvalue;
	setTimeout(\'sendmsg1("\'+msgid+\'")\',3000);
}
function sendmsg1(msgid){
	document.getElementById(msgid).innerHTML="";
}
</script>
';

showtableheaders(it618_tuan_getlang('s413'),'it618_tuan_sum');

	$tmpstr='<a href="javascript:" id="checkfahuo" style="float:right;border:none; background-color:#F60; color:#fff; padding-left:23px; padding-right:23px; height:26px;padding-top:8px;font-size:15px;margin-top:11px;">'.it618_tuan_getlang('s1103').'</a><span id="salebz"></span><span id="salekm"></span>';
	echo '<tr><td colspan="15"><div class="fixsel">'.$tmpstr.it618_tuan_getlang('s224').' <input id="pname" class="txt" style="width:231px;margin-right:1px" /> '.it618_tuan_getlang('s761').' <input id="finduid" class="txt" style="width:76px" /><br>'.it618_tuan_getlang('s762').' <select id="state"><option value=0>'.it618_tuan_getlang('s414').'</option><option value=1 style="color:red">'.it618_tuan_getlang('s191').'</option><option value=2 style="color:blue">'.it618_tuan_getlang('s192').'</option><option value=3 style="color:green">'.it618_tuan_getlang('s193').'</option><option value=4 style="color:#F0F">'.it618_tuan_getlang('s194').'</option><option value=5 style="color:purple">'.it618_tuan_getlang('s195').'</option></select>  '.it618_tuan_getlang('t315').' <select id="saletype"><option value=0>'.it618_tuan_getlang('s842').'</option><option value=1>'.it618_tuan_getlang('s719').'</option><option value=2>'.it618_tuan_getlang('s720').'</option><option value=3>'.it618_tuan_getlang('s836').'</option></select>'.it618_tuan_getlang('s228').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_tuan_getlang('s763').'" onclick="findsalelist()" /> <input type="button" class="btn" value="'.it618_tuan_getlang('s1102').'" onclick="dao()" /> </div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>';
	
	showsubtitle(array('', it618_tuan_getlang('s233'),it618_tuan_getlang('s800'),it618_tuan_getlang('s732'),it618_tuan_getlang('s418'),it618_tuan_getlang('s765'),it618_tuan_getlang('s419'),it618_tuan_getlang('s804')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_tuan/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr>';

showtablefooter(); /*dism��taobao��com*/
echo '
<script>
var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax";
var sqlurl="";
function getsalelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_TUAN.post(url+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_TUAN("#tr_salesum").html(tmparr[0]);
	IT618_TUAN("#tr_salelist").html(tmparr[1]);
	IT618_TUAN("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
getsalelist(saleurl);

function findsalelist(){
	var pname = document.getElementById("pname").value;
	var finduid = document.getElementById("finduid").value;
	var state = document.getElementById("state").value;
	var saletype = document.getElementById("saletype").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&pname="+pname+"&finduid="+finduid+"&state="+state+"&saletype="+saletype+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax";
	getsalelist(url);
}

function dao(){
	findsalelist();
	IT618_TUAN.get(saleurl+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_dao"},function (data, textStatus){
	window.open(data);
	}, "html");	
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>