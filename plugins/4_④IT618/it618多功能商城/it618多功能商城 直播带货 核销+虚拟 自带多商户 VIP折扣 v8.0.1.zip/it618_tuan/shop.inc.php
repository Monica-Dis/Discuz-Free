<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/tuan_default.func.php';

$sid=intval($_GET['sid']);
if(tuan_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	if(isset($_GET['quan'])){
		$urltmp='quan';
	}
	if(isset($_GET['tui'])){
		$urltmp='tui';
	}
	
	if($urltmp!=''){
		$tmpurl=it618_tuan_getrewrite('tuan_wap','shop@'.$sid,'plugin.php?id=it618_tuan:wap&pagetype=shop&cid='.$sid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_tuan_getrewrite('tuan_wap','shop@'.$sid,'plugin.php?id=it618_tuan:wap&pagetype=shop&cid='.$sid);
	}

	dheader("location:$tmpurl");
}

$homeurl=it618_tuan_getrewrite('tuan_home','','plugin.php?id=it618_tuan:index');
if($it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($sid)){	
	$it618_state=$it618_tuan_shop['it618_state'];
	if($it618_state==0){
		echo it618_tuan_getlang('s334').' <a href="'.$homeurl.'">'.$it618_tuan_lang['s18'].'</a>';exit;
	}elseif($it618_state==1){
		echo it618_tuan_getlang('s335').' <a href="'.$homeurl.'">'.$it618_tuan_lang['s18'].'</a>';exit;
	}else{
		$it618_htstate=$it618_tuan_shop['it618_htstate'];
		if($it618_htstate==0){
			echo it618_tuan_getlang('s336').' <a href="'.$homeurl.'">'.$it618_tuan_lang['s18'].'</a>';exit;
		}elseif($it618_htstate==2){
			echo it618_tuan_getlang('s337').' <a href="'.$homeurl.'">'.$it618_tuan_lang['s18'].'</a>';exit;
		}else{
			$ShopId=$it618_tuan_shop['id'];
		}
	}
}else{
	echo it618_tuan_getlang('s338').' <a href="'.$homeurl.'">'.$it618_tuan_lang['s18'].'</a>';exit;
}

$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
$viewscount=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_tuan_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
$salecount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_sale')." WHERE it618_shopid=$ShopId and it618_state!=0");

$shopgoodsarr=explode("it618_split",it618_tuan_getshopgoods($ShopId));

$shopgoods_views=it618_tuan_getshopgoods($ShopId,1,0,"views");
$shopgoods_hot=it618_tuan_getshopgoods($ShopId,1,0,"hot");

$metatitle=$it618_tuan_shop['it618_name'].' - '.$metatitle;
$metakeywords=$it618_tuan_goods['it618_name'];
$metadescription=$it618_tuan_goods['it618_about'];

$url_this=$_G['siteurl'].$tmpurl=it618_tuan_getrewrite('tuan_wap','shop@'.$sid,'plugin.php?id=it618_tuan:wap&pagetype=shop&cid='.$sid);
$qrcodesrc='plugin.php?id=it618_tuan:urlcode&url='.urlencode($url_this);

$footer.='<div style="display:none">'.$it618_tuan_shop['it618_tongji'].'</div>';

$pagetype='shop';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:tuan_default');
?>