<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return; /*Dism��taobao��com*/

loadcache('plugin');
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$creditname=$_G['setting']['extcredits'][$it618_tuan['tuan_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function/it618_tuan.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_shop&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=0;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<4;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[0]=$it618_tuan_lang['s562'];
$strtmptitle[1]=$it618_tuan_lang['s563'];
$strtmptitle[2]=$it618_tuan_lang['s1696'];
$strtmptitle[3]=$it618_tuan_lang['s1727'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_shop&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_dhshop&cp1=1'.$urls.'"><span>'.$strtmptitle[1].'</span></a></li>
<li '.$strtmp[2].' '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_shopthd&cp1=2'.$urls.'"><span>'.$strtmptitle[2].'</span></a></li>
</ul></div>';

$cparray = array('admin_shop', 'admin_dhshop', 'admin_shopthd', 'admin_shopthd_edit');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_shop' : $_GET['cp'];

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*Dism_taobao_com*/
?>