<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_tuan_kdarea', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_tuan#it618_tuan_kdarea')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
	
		if($newit618_name_array[$key] != '') {
			
			C::t('#it618_tuan#it618_tuan_kdarea')->insert(array(
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_tuan_lang['s33'].$ok1.' '.$it618_tuan_lang['s34'].$ok2.' '.$it618_tuan_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_kdarea&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

if(count($reabc)!=10)return;
if(submitcheck('it618sercsubmit')) {
	if($_GET['beforeword']) {
		$extrasql = "AND it618_name LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
	}
}
showformheader("plugins&identifier=$identifier&cp=admin_kdarea&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_tuan_kdarea');
	showsubmit('it618sercsubmit', $it618_tuan_lang['s597'], $it618_tuan_lang['s713'].' <input name="beforeword" value="" class="txt" />');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_kdarea')." w WHERE 1 $extrasql");
	
	echo '<tr><td colspan=4>'.$it618_tuan_lang['s714'].$count.'</td></tr>';
	showsubtitle(array('', $it618_tuan_lang['s715'], $it618_tuan_lang['s716']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_kdarea')." WHERE 1 $extrasql ORDER BY it618_order");
	while($it618_tuan = DB::fetch($query)) {
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_tuan[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_tuan[id]]\" value=\"$it618_tuan[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_tuan[id]]\" value=\"$it618_tuan[it618_name]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:50px\" name=\"it618_order[$it618_tuan[id]]\" value=\"$it618_tuan[it618_order]\">"
		));
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		return [
		[[1,''], [1,'<input type="text" class="txt" style="width:200px" name="newit618_name[]">'], [1, ' <input class="txt" style="width:50px" type="text" name="newit618_order[]">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="4"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>