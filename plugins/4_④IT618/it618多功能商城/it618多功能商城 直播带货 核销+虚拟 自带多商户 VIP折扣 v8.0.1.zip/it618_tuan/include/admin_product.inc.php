<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/

$it618sql = "1";
$state0='';$state1='';$state2='';$state3='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and g.it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and g.it618_state = 1";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and g.it618_state = 2";$state3='selected="selected"';}

$saletype0='';$saletype1='';$saletype2='';$saletype3='';
if($_GET['saletype']==0){$saletype0='selected="selected"';}
if($_GET['saletype']==1){$it618sql .= " and g.it618_saletype = 1";$saletype1='selected="selected"';}
if($_GET['saletype']==2){$it618sql .= " and g.it618_saletype = 2";$saletype2='selected="selected"';}
if($_GET['saletype']==3){$it618sql .= " and g.it618_saletype = 3";$saletype3='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';$orderby4='';
if($_GET['orderby']==0){$it618orderby = "it618_order desc,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "it618_salecount desc";$orderby2='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "it618_views desc";$orderby3='selected="selected"';}
if($_GET['orderby']==3){$it618orderby = "it618_saleprice desc";$orderby4='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&price1='.$_GET['price1'].'&price2='.$_GET['price2'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'].'&saletype='.$_GET['saletype'].'&orderby='.$_GET['orderby'];

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_order'])) {
		foreach($_GET['it618_order'] as $id => $val) {
			C::t('#it618_tuan#it618_tuan_goods')->update($id,array(
				'it618_order' => $_GET['it618_order'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s90'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_clock')){
	$ok=0;
	if($reabc[8]!='a')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_goods=C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($delid);
		
		if($it618_tuan_goods['it618_state']==1){
			DB::query("update ".DB::table('it618_tuan_goods')." set it618_state=2 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s92'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_unclock')){
	$ok=0;
	if($reabc[8]!='a')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_goods=C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($delid);
		
		if($it618_tuan_goods['it618_state']==2){
			DB::query("update ".DB::table('it618_tuan_goods')." set it618_state=0 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s94'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return;

$tmp='<option value="0">'.$it618_tuan_lang['s95'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

showformheader("plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1".$urlsql);
showtableheaders($strtmptitle[$cp1],'it618_tuan_goods');
	showsubmit('it618sercsubmit', $it618_tuan_lang['s25'], $it618_tuan_lang['s97'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:150px" /> '.$it618_tuan_lang['s98'].' <input name="price1" value="'.$_GET['price1'].'" class="txt" style="width:50px;margin-right:0" /> - <input name="price2" value="'.$_GET['price2'].'" class="txt" style="width:50px" /> '.$it618_tuan_lang['s99'].' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.$it618_tuan_lang['s100'].'</option></select> '.$it618_tuan_lang['s101'].' <select name="state"><option value=0 '.$state0.'>'.$it618_tuan_lang['s102'].'</option><option value=1 '.$state1.'>'.$it618_tuan_lang['s103'].'</option><option value=2 '.$state2.'>'.$it618_tuan_lang['s104'].'</option><option value=3 '.$state3.'>'.$it618_tuan_lang['s105'].'</option></select> '.$it618_tuan_lang['s718'].' <select name="saletype"><option value=0 '.$saletype0.'>'.$it618_tuan_lang['s842'].'</option><option value=1 '.$saletype1.'>'.$it618_tuan_lang['s719'].'</option><option value=2 '.$saletype2.'>'.$it618_tuan_lang['s720'].'</option><option value=3 '.$saletype3.'>'.$it618_tuan_lang['s836'].'</option></select><select name="orderby"><option value=0 '.$orderby0.'>'.$it618_tuan_lang['s110'].'</option><option value=1 '.$orderby1.'>'.$it618_tuan_lang['s111'].'</option><option value=2 '.$orderby2.'>'.$it618_tuan_lang['s112'].'</option><option value=3 '.$orderby3.'>'.$it618_tuan_lang['s113'].'</option></select>');
	
	$count = C::t('#it618_tuan#it618_tuan_goods')->count_by_search('s.it618_uid>0 and '.$it618sql,'',0,$_GET['it618_class1_id'],$_GET['it618_class2_id'],0,0,$_GET['key'],$_GET['price1'],$_GET['price2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	echo '<tr><td colspan=14>'.$it618_tuan_lang['s114'].$count.'<span style="float:right;color:red"></span></td></tr>';
	showsubtitle(array('',$it618_tuan_lang['s115'],$it618_tuan_lang['s116'],$it618_tuan_lang['s118'],$it618_tuan_lang['s119'],$it618_tuan_lang['s120'],$it618_tuan_lang['s718'],$it618_tuan_lang['s121'],$it618_tuan_lang['s862'],$it618_tuan_lang['s932'],$it618_tuan_lang['s122'],$it618_tuan_lang['s123']));
	
	$n=1;
	foreach(C::t('#it618_tuan#it618_tuan_goods')->fetch_all_by_search(
		's.it618_uid>0 and '.$it618sql,$it618orderby,0,$_GET['it618_class1_id'],$_GET['it618_class2_id'],0,0,$_GET['key'],$_GET['price1'],$_GET['price2'],$startlimit,$ppp
	) as $it618_tuan_goods) {
		
		if($it618_tuan_goods['it618_saletype']==1)$it618_saletype1='selected="selected"';else $it618_saletype1="";
		if($it618_tuan_goods['it618_saletype']==2)$it618_saletype2='selected="selected"';else $it618_saletype2="";
		
		if($it618_tuan_goods['it618_isservice1']==1)$it618_isservice1_checked='checked="checked"';else $it618_isservice1_checked="";
		if($it618_tuan_goods['it618_isservice2']==1)$it618_isservice2_checked='checked="checked"';else $it618_isservice2_checked="";
		if($it618_tuan_goods['it618_isservice3']==1)$it618_isservice3_checked='checked="checked"';else $it618_isservice3_checked="";
		
		if($it618_tuan_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		if($it618_tuan_goods['it618_issaledisplay']==1)$it618_issaledisplay_checked='checked="checked"';else $it618_issaledisplay_checked="";
		
		if($it618_tuan_goods['it618_state']==0)$it618_state='<font color=blue>'.$it618_tuan_lang['s103'].'</font>';
		if($it618_tuan_goods['it618_state']==1)$it618_state='<font color=green>'.$it618_tuan_lang['s104'].'</font>';
		if($it618_tuan_goods['it618_state']==2)$it618_state='<font color=red>'.$it618_tuan_lang['s105'].'</font>';
		
		$salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_pid($it618_tuan_goods['id']);
		$salemoney = C::t('#it618_tuan#it618_tuan_sale')->summoney_by_it618_pid($it618_tuan_goods['id']);
		
		$class1name = C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_name_by_id($it618_tuan_goods['it618_class1_id']);
		$class2name = C::t('#it618_tuan#it618_tuan_class2')->fetch_it618_name_by_id($it618_tuan_goods['it618_class2_id']);
		
		$divcss	= 'display:none';
		$countcss = 'display:';
		if($it618_tuan_goods['it618_saletype']==1){
			$divcss	= 'display:';
			$saletypestr=$it618_tuan_lang['s719'].'<br>';
		}else if($it618_tuan_goods['it618_saletype']==2){
			if($it618_tuan_goods['it618_isyunfeifree']==1)$it618_isyunfeifree_checked='checked="checked"';else $it618_isyunfeifree_checked="";
			$saletypestr=$it618_tuan_lang['s720'].'<br><input class="checkbox" type="checkbox" id="chk_isyunfeifree'.$n.'" name="it618_isyunfeifree['.$it618_tuan_goods['id'].']" '.$it618_isyunfeifree_checked.' value="1"><label for="chk_isyunfeifree'.$n.'"><font color=green>'.$it618_tuan_lang['s721'].'</font></label>';
		}else if($it618_tuan_goods['it618_saletype']==3){
			$preurl="plugin.php?id=it618_tuan:sc_product".$urlsql."&page=$page";
			$preurl=str_replace("&","@",$preurl);
			$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_km')." WHERE it618_pid=".$it618_tuan_goods['id']);
			$saletypestr=$it618_tuan_lang['s836'].'<br>'.$it618_tuan_lang['s847'].'(<font color=red>'.$kmcount.'</font>)';
			$countcss = 'display:none';
		}else{
			$divcss	= 'display:';
			$saletypestr=$it618_tuan_lang['s719'].'<br>';
			if($it618_tuan_goods['it618_isyunfeifree']==1)$it618_isyunfeifree_checked='checked="checked"';else $it618_isyunfeifree_checked="";
			$saletypestr=$it618_tuan_lang['s720'].'<br><input class="checkbox" type="checkbox" id="chk_isyunfeifree'.$n.'" name="it618_isyunfeifree['.$it618_tuan_goods['id'].']" '.$it618_isyunfeifree_checked.' value="1"><label for="chk_isyunfeifree'.$n.'"><font color=green>'.$it618_tuan_lang['s721'].'</font></label>';
		}
		
		$uid = C::t('#it618_tuan#it618_tuan_shop')->fetch_it618_uid_by_id($it618_tuan_goods['it618_shopid']);
		
		$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
		
		$timestr='';
		if($it618_tuan_goods['it618_xgtype']==1)$timestr=$it618_tuan_lang['s945'].' '.$it618_tuan_goods['it618_xgtime1'].' - '.$it618_tuan_goods['it618_xgtime2'];
		if($it618_tuan_goods['it618_xgtype']==2){
			$timetmp1=explode(" ",$it618_tuan_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_tuan_goods['it618_xgtime2']);
			$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_tuan_getlang('s955').' '.$timetmp1[1].' - '.$timetmp2[1];
		}

		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_tuan_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_tuan_goods['id'].'</label>',
			'<div style="width:360px"><a style="float:left;width:76px" href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_tuan_goods['it618_description'].'"><img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="68" height="68" align="absmiddle"/></a><div style="float:left;margin-left:3px;line-height:18px;width:260px"><a href="plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id'].'" target="_blank">'.$it618_tuan_goods['it618_name'].'</a><br>'.$it618_tuan_goods['it618_mealname'].'<br>'.$it618_tuan_lang['s124'].'<a href="'.it618_tuan_rewriteurl($uid).'" target="_blank">'.it618_tuan_getusername($uid).'</a></div></div>',
			'<div style="width:150px"><span style="'.$countcss.'">'.it618_tuan_getlang('s840').' '.$it618_tuan_goods['it618_count'].'</span><br>'.it618_tuan_getgoodsprice($it618_tuan_goods).'<br>'.$it618_tuan_lang['s126'].' '.$it618_tuan_goods['it618_xgtime'].$it618_tuan_lang['s127'].'/'.$it618_tuan_goods['it618_xgcount'].$it618_tuan_lang['s128'].'<br>'.$timestr.'</div>',
			$it618_tuan_goods['it618_views'],
			'<font color=red>'.$salecount.'</font>',
			'<font color=red>'.$salemoney.'</font>',
			$saletypestr,
			'<div style="'.$divcss.'"><input class="checkbox" type="checkbox" '.$it618_isservice1_checked.' value="1"><font color=green>'.$it618_tuan_lang['s107'].'</font></label> <input class="checkbox" type="checkbox"  '.$it618_isservice2_checked.' value="1"><font color=green>'.$it618_tuan_lang['s108'].'</font></label> <input class="checkbox" type="checkbox" '.$it618_isservice3_checked.' value="1"><font color=green>'.$it618_tuan_lang['s109'].'</font></label><br>'.$it618_tuan_goods['it618_bsaletime'].'<br>'.$it618_tuan_goods['it618_esaletime'].'</div>',
			'<input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_tuan_goods['id'].']" '.$it618_isbm_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_issaledisplay'.$n.'" name="it618_issaledisplay['.$it618_tuan_goods['id'].']" '.$it618_issaledisplay_checked.' value="1">',
			$it618_state,
			'<input type="text" class="txt" style="width:40px" name="it618_order['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_order'].'">'
		));
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_class1'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' ORDER BY it618_order");
	$n1=1;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$n2=1;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
	
	echo '
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	</script>';

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_tuan_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_edit" value="'.$it618_tuan_lang['s130'].'"/> <input type="submit" class="btn" name="it618submit_clock" value="'.$it618_tuan_lang['s131'].'" onclick="return confirm(\''.$it618_tuan_lang['s132'].'\')" /> <input type="submit" class="btn" name="it618submit_unclock" value="'.$it618_tuan_lang['s133'].'" onclick="return confirm(\''.$it618_tuan_lang['s134'].'\')" /><br>'.$it618_tuan_lang['s135'].'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
echo '<script>
		'.$jstmp.'

		function setservice(obj){
			if(obj.checked==true){
				document.getElementById("isservice").style.display="none"; 
			}else{
				document.getElementById("isservice").style.display=""; 
			}
		}
		</script>';
?>