<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_tuan_shop_thd', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_tuan#it618_tuan_shop_thd')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_uid' => trim($_GET['it618_uid'][$id]),
				'it618_addr' => trim($_GET['it618_addr'][$id]),
				'it618_dianhua' => trim($_GET['it618_dianhua'][$id]),
				'it618_msgtel' => trim($_GET['it618_msgtel'][$id]),
				'it618_msgisok' => trim($_GET['it618_msgisok'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			C::t('#it618_tuan#it618_tuan_shop_thd')->insert(array(
				'it618_name' => trim($newit618_name_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_tuan_lang['s33'].$ok1.' '.$it618_tuan_lang['s34'].$ok2.' '.$it618_tuan_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_shopthd&cp1=$cp1&pmod=admin_shop&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return;

$preurl="action=plugins&identifier=$identifier&cp=admin_shopthd&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql;
$preurl=str_replace("&","@",$preurl);

showformheader("plugins&identifier=$identifier&cp=admin_shopthd&cp1=$cp1&pmod=admin_shop&operation=$operation&do=$do".$urlsql);
showtableheaders($strtmptitle[$cp1],'it618_tuan_shop_thd');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_shop_thd'));
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shopthd&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	echo '<tr><td colspan=15>'.$it618_tuan_lang['s1697'].$count.'<span style="float:right;color:red">'.$it618_tuan_lang['s1702'].'</span></td></tr>';
	showsubtitle(array('', $it618_tuan_lang['s1698'],$it618_tuan_lang['s1703'], $it618_tuan_lang['s1699'], $it618_tuan_lang['s1700'], $it618_tuan_lang['s1701'], $it618_tuan_lang['s1704'], $it618_tuan_lang['s1690']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_shop_thd')." ORDER BY it618_order desc");
	while($it618_tuan_shop_thd = DB::fetch($query)) {

		$salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_gthdid($it618_tuan_shop_thd['id']);
		$disabled="";
		if($salecount>0)$disabled="disabled=\"disabled\"";
		if($it618_tuan_shop_thd['it618_msgisok']==1)$it618_msgisok_checked='checked="checked"';else $it618_msgisok_checked="";
		
		showtablerow('', array('class="td25"', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_tuan_shop_thd['id'].'" name="delete[]" value="'.$it618_tuan_shop_thd['id'].'" '.$disabled.'><label for="chk_del'.$it618_tuan_shop_thd['id'].'">'.$it618_tuan_shop_thd['id'].'</label>',
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_tuan_shop_thd[id]]\" value=\"$it618_tuan_shop_thd[it618_name]\">".'<a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_shopthd_edit&pmod=admin_shop&operation='.$operation.'&do='.$do.'&cp1=3&tid='.$it618_tuan_shop_thd[id].'&preurl='.$preurl.'">'.it618_tuan_getlang('s351').'</a>',
			"<input type=\"text\" class=\"txt\" style=\"width:50px;color:red\" name=\"it618_uid[$it618_tuan_shop_thd[id]]\" value=\"$it618_tuan_shop_thd[it618_uid]\">".'<a href="'.it618_tuan_rewriteurl($it618_tuan_shop_thd['it618_uid']).'" target="_blank">'.it618_tuan_getusername($it618_tuan_shop_thd['it618_uid']).'</a>',
			"<input type=\"text\" class=\"txt\" style=\"width:300px\" name=\"it618_addr[$it618_tuan_shop_thd[id]]\" value=\"$it618_tuan_shop_thd[it618_addr]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:100px\" name=\"it618_dianhua[$it618_tuan_shop_thd[id]]\" value=\"$it618_tuan_shop_thd[it618_dianhua]\">",
			'<input class="checkbox" type="checkbox" id="chk_msgisok'.$n.'" name="it618_msgisok['.$it618_tuan_shop_thd['id'].']" '.$it618_msgisok_checked.' value="1">'."<input type=\"text\" class=\"txt\" style=\"width:100px\" name=\"it618_msgtel[$it618_tuan_shop_thd[id]]\" value=\"$it618_tuan_shop_thd[it618_msgtel]\">",
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_tuan_shop_thd['id'].']" value="'.$it618_tuan_shop_thd['it618_order'].'">',
			$salecount
		));
	}
	
	global $_G;
if($reabc[4]!='8')return; /*Dism��taobao��com*/

	loadcache('plugin');
	$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
	$it618_tuan_lang1706=$it618_tuan_lang['s1706'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:200px" name="newit618_name[]">'],
		[1,'$it618_tuan_lang1706'],
		[1,''],
		[1,''],
		[1,''],
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', $it618_tuan_lang['s1705']."<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>