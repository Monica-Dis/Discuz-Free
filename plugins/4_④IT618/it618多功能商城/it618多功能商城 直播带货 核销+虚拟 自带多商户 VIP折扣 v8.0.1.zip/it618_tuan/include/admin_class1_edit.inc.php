<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/
$cid=intval($_GET['cid']);
$it618_tuan_class1=C::t('#it618_tuan#it618_tuan_class1')->fetch_by_id($cid);
$it618_tuan_class1['it618_usergroup'] = $it618_tuan_class1['it618_usergroup'] ? explode(",",$it618_tuan_class1['it618_usergroup']) : array();

if(submitcheck('it618submit')){
	C::t('#it618_tuan#it618_tuan_class1')->update($cid,array(
		'it618_classname' => trim($_GET['it618_classname']),
		'it618_usergroup' => $_GET['it618_usergroup'] ? ','.implode(",",$_GET['it618_usergroup']).',' : ''
	), true);

	$preurl=str_replace("@","&",$_GET['preurl']);
	cpmsg(it618_tuan_getlang('s16'), $preurl, 'succeed');
}
showformheader("plugins&identifier=$identifier&cp=admin_class1_edit&pmod=admin_class&operation=$operation&do=$do&cp1=$cp1&cid=$cid&preurl=".$_GET['preurl']);
showtableheaders($it618_tuan_lang['s41'],'it618_tuan_class1');
	
	$groupselect = array();
	$query = C::t('common_usergroup')->range_orderby_credit();
	foreach($query as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $it618_tuan_class1['it618_usergroup']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
	}
	$select = '<select name="it618_usergroup[]" size="10" multiple="multiple" style="width: 256px;"><option value="0"'.(@in_array('0', $it618_tuan_class1['it618_usergroup']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>'.
			'<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
			($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
			($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
			'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
			
echo '
<tr><td width="80">'.$it618_tuan_lang['s45'].'</td><td><input type="text" class="txt" style="width:256px;margin-right:0" id="it618_classname" name="it618_classname" value="'.$it618_tuan_class1['it618_classname'].'"> </td></tr>
<tr><td>'.$it618_tuan_lang['s90001'].'</td><td>'.$select.'</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_tuan_lang['s407'].'" /></div></td></tr>';

if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>