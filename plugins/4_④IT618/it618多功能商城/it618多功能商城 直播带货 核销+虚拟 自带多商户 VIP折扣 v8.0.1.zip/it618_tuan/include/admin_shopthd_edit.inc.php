<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/

$tid=intval($_GET['tid']);

$it618_tuan_shop_thd=C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($tid);
if(submitcheck('it618submit')){
	
	C::t('#it618_tuan#it618_tuan_shop_thd')->update($tid,array(
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_addr' => dhtmlspecialchars($_GET['it618_addr']),
		'it618_dianhua' => dhtmlspecialchars($_GET['it618_dianhua']),
		'it618_yytime' => dhtmlspecialchars($_GET['it618_yytime']),
		'it618_kefuqq' => dhtmlspecialchars($_GET['it618_kefuqq']),
		'it618_kefuqqname' => dhtmlspecialchars($_GET['it618_kefuqqname']),
		'it618_about' => dhtmlspecialchars($_GET['it618_about'])
	));
	
	if($it618_tuan['tuan_bdkey']!=''){
		C::t('#it618_tuan#it618_tuan_shop_thd')->update($tid,array(
			'it618_mappoint' => dhtmlspecialchars($_GET['it618_mappoint'])
		));
	}

	$preurl=str_replace("@","&",$_GET['preurl']);
	cpmsg(it618_tuan_getlang('s1728'), $preurl, 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_shopthd_edit&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&tid=$tid&preurl=".$_GET['preurl']);
showtableheaders($strtmptitle[$cp1],'it618_tuan_shop_thd');
	
echo '
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_tuan/kindeditor/php/upload_json.php\',
			fileManagerJson : \'source/plugin/it618_tuan/kindeditor/php/file_manager_json.php\',
			allowFileManager : true
		});
	});
	
	function checkvalue(){
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_tuan_getlang('s311').'");
			return false;
		}
		if(document.getElementById("it618_addr").value==""){
			alert("'.it618_tuan_getlang('s314').'");
			return false;
		}
	}
</script>

<tr><td width=70>'.it618_tuan_getlang('s320').'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name" value="'.$it618_tuan_shop_thd['it618_name'].'">'.it618_tuan_getlang('s316').' <font color="red">'.it618_tuan_getlang('s321').'</font></td></tr>
<tr><td>'.it618_tuan_getlang('s326').'</td><td><input type="text" class="txt" style="width:400px" id="it618_addr" name="it618_addr" value="'.$it618_tuan_shop_thd['it618_addr'].'">'.it618_tuan_getlang('s316').' <font color="red">'.it618_tuan_getlang('s321').'</font></td></tr>
<tr><td>'.it618_tuan_getlang('s327').'</td><td><input type="text" class="txt" style="width:400px" name="it618_dianhua" value="'.$it618_tuan_shop_thd['it618_dianhua'].'">'.it618_tuan_getlang('s316').'</td></tr>
<tr><td>'.it618_tuan_getlang('s328').'</td><td><input type="text" class="txt" style="width:400px" name="it618_kefuqq" value="'.$it618_tuan_shop_thd['it618_kefuqq'].'">'.it618_tuan_getlang('s316').' <font color="red">'.it618_tuan_getlang('s859').'</font></td></tr>
<tr><td>'.it618_tuan_getlang('s860').'</td><td><input type="text" class="txt" style="width:400px" name="it618_kefuqqname" value="'.$it618_tuan_shop_thd['it618_kefuqqname'].'">'.it618_tuan_getlang('s316').' <font color="red">'.it618_tuan_getlang('s861').'</font></td></tr>
<tr><td>'.it618_tuan_getlang('s329').'</td><td><input type="text" class="txt" style="width:400px" name="it618_yytime" value="'.$it618_tuan_shop_thd['it618_yytime'].'">'.it618_tuan_getlang('s316').'</td></tr>';

if($it618_tuan['tuan_bdkey']!=''){
	echo '<tr><td>'.it618_tuan_getlang('s330').'</td><td><iframe width="100%" height="450px" marginwidth="0" marginheight="0"  frameborder="no" scrolling="no"  src="'.$_G['siteurl'].'plugin.php?id=it618_tuan:getpoint&mappoint='.$it618_tuan_shop_thd['it618_mappoint'].'"></iframe><input type="hidden" id="it618_mappoint" name="it618_mappoint" value="'.$it618_tuan_shop_thd['it618_mappoint'].'"></td></tr>';
}

echo '<tr><td>'.it618_tuan_getlang('s331').'</td><td><textarea class="txt" style="width:400px;height:80px" name="it618_about">'.$it618_tuan_shop_thd['it618_about'].'</textarea>'.it618_tuan_getlang('s316').' '.it618_tuan_getlang('s332').'</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_tuan_getlang('s23').'" /></div></td></tr>';

if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>