<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_tuan_area1', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_tuan#it618_tuan_area1')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			C::t('#it618_tuan#it618_tuan_area1')->insert(array(
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_tuan_lang['s33'].$ok1.' '.$it618_tuan_lang['s34'].$ok2.' '.$it618_tuan_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_area1&pmod=admin_area&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return;
if($_GET['beforeword']) {
	$extrasql = "AND it618_name LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
}

showformheader("plugins&identifier=$identifier&cp=admin_area1&pmod=admin_area&operation=$operation&do=$do");
showtableheaders($it618_tuan_lang['s24'],'it618_tuan_area1');
	showsubmit('it618sercsubmit', $it618_tuan_lang['s25'], $it618_tuan_lang['s26'].' <input name="beforeword" value="'.$_GET['beforeword'].'" class="txt" />');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_area1')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_area1&pmod=admin_area&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10>'.$it618_tuan_lang['s27'].$count.'</td></tr>';
	showsubtitle(array('', $it618_tuan_lang['s28'], $it618_tuan_lang['s29'],$it618_tuan_lang['s30'],$it618_tuan_lang['s31'],$it618_tuan_lang['s32']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_area1')." WHERE 1 $extrasql ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_tuan =	DB::fetch($query)) {
		$area2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_area2')." WHERE it618_area1_id=".$it618_tuan['id']);
		$shopcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_shop')." WHERE it618_area1_id=".$it618_tuan['id']);
		$disabled="";
		if($area2count>0)$disabled="disabled=\"disabled\"";
		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_tuan[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_tuan[id]]\" value=\"$it618_tuan[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_tuan[id]]\" value=\"$it618_tuan[it618_name]\">",
			"<input id=\"c".$it618_tuan['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_tuan[id]]\" value=\"$it618_tuan[it618_color]\" onchange=\"updatecolorpreview('c".$it618_tuan['id']."')\"><input id=\"c".$it618_tuan['id']."\" onclick=\"c".$it618_tuan['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_tuan['id']."|c".$it618_tuan['id']."_v';showMenu({'ctrlid':'c".$it618_tuan['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_tuan['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_tuan['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			'<input class="txt" type="text" name="it618_order['.$it618_tuan['id'].']" value="'.$it618_tuan['it618_order'].'">',
			$area2count,
			$shopcount
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_tuan['id']."');";
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_name[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_name[]">'], [1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1, ' <input class="txt" type="text" name="newit618_order[]">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>