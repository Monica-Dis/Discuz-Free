<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_tuan_shop', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_tuan#it618_tuan_shop')->update($id,array(
				'it618_area1_id' => trim($_GET['it618_area1_id'][$id]),
				'it618_area2_id' => trim($_GET['it618_area2_id'][$id]),
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_addr' => trim($_GET['it618_addr'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_area1_id_array = !empty($_GET['newit618_area1_id']) ? $_GET['newit618_area1_id'] : array();
	$newit618_area2_id_array = !empty($_GET['newit618_area2_id']) ? $_GET['newit618_area2_id'] : array();
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_addr_array = !empty($_GET['newit618_addr']) ? $_GET['newit618_addr'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			if($oldit618_name = DB::fetch_first("SELECT it618_name FROM ".DB::table('it618_tuan_shop')." WHERE it618_name='$newit618_name'")) {
				$same2=$same2+1;
			} else {

				C::t('#it618_tuan#it618_tuan_shop')->insert(array(
					'it618_area1_id' => trim($newit618_area1_id_array[$key]),
					'it618_area2_id' => trim($newit618_area2_id_array[$key]),
					'it618_uid' => 0,
					'it618_state' => 2,
					'it618_htstate' => 1,
					'it618_name' => trim($newit618_name_array[$key]),
					'it618_addr' => trim($newit618_addr_array[$key])
				), true);
				$ok2=$ok2+1;
			}
		}
	}

	cpmsg($it618_tuan_lang['s33'].$ok1.' '.$it618_tuan_lang['s34'].$ok2.' '.$it618_tuan_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_dhshop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page", 'succeed');
}

if(count($reabc)!=10)return;
if(submitcheck('it618sercsubmit')) {
	if($_GET['beforeword']) {
		$extrasql = "AND it618_name LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
	}
}
showformheader("plugins&identifier=$identifier&cp=admin_dhshop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[cp1],'it618_tuan_shop');
	showsubmit('it618sercsubmit', $it618_tuan_lang['s25'], $it618_tuan_lang['s581'].' <input name="beforeword" value="'.$_GET['beforeword'].'" class="txt" />');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_shop')." w WHERE it618_uid=0 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_dhshop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1");
	
	echo '<tr><td colspan=10>'.$it618_tuan_lang['s582'].$count.'<span style="float:right">'.$it618_tuan_lang['s583'].'</span></td></tr>';
	showsubtitle(array('', $it618_tuan_lang['s584'], $it618_tuan_lang['s585'],$it618_tuan_lang['s586'],$it618_tuan_lang['s587']));
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_area1')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
		
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_shop')." WHERE it618_uid=0 $extrasql LIMIT $startlimit, $ppp");
	while($it618_tuan = DB::fetch($query)) {
		C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($it618_tuan['id'],1);
		$goodscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods')." WHERE it618_shopid=".$it618_tuan['id']);
		$disabled="";
		if($goodscount>0)$disabled="disabled=\"disabled\"";
		
		$it618_area1_id = DB::result_first("SELECT it618_area1_id FROM ".DB::table('it618_tuan_area2')." WHERE id=".$it618_tuan['it618_area2_id']);
		$tmp1=str_replace('<option value='.$it618_area1_id.'>','<option value='.$it618_area1_id.' selected="selected">',$tmp);
		
		if($it618_area1_id=='')$it618_area1_id=0;
		$query11 = DB::query("SELECT * FROM ".DB::table('it618_tuan_area2')." where it618_area1_id=".$it618_area1_id." ORDER BY it618_order DESC");
		$indextmp=1;
		$index=0;
		while($it618_tmp =	DB::fetch($query11)) {
			if($it618_tmp['id']==$it618_tuan['it618_area2_id']){
				$index=$indextmp;
			}
			$indextmp+=1;
		}
		$jstmp.='redirec_area(document.getElementById("it618_area1_id'.$it618_tuan['id'].'").options.selectedIndex,'.$it618_tuan['id'].');redirec_area_sel('.$it618_tuan['id'].','.$index.');';
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_tuan[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_tuan[id]]\" value=\"$it618_tuan[id]\">",
			'<select id="it618_area1_id'.$it618_tuan[id].'" name="it618_area1_id['.$it618_tuan[id].']" onchange="redirec_area(this.options.selectedIndex,'.$it618_tuan[id].')"><option value="0">'.$it618_tuan_lang['s588'].'</option>'.$tmp1.'</select><select id="it618_area2_id'.$it618_tuan[id].'" name="it618_area2_id['.$it618_tuan[id].']"><option value="0">'.$it618_tuan_lang['s589'].'</option></select>',
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_tuan[id]]\" value=\"$it618_tuan[it618_name]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:400px\" name=\"it618_addr[$it618_tuan[id]]\" value=\"$it618_tuan[it618_addr]\">",
			$goodscount
		));
		
		$checkjs.='if(document.getElementById("it618_area2_id'.$it618_tuan[id].'").value=="0"){
						alert("'.$it618_tuan_lang['s590'].'");
						document.getElementById("it618_area2_id'.$it618_tuan[id].'").focus();
						return false;
					}'."\n";
	}
	
	global $_G;
if($reabc[4]!='8')return; /*Dism��taobao��com*/

	loadcache('plugin');
	$it618_tuan = $_G['cache']['plugin']['it618_tuan'];

	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_area1'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_area1')." ORDER BY it618_order");
	$n1=1;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$n2=1;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_area2')." where it618_area1_id=".$it618_tmp1['id']." ORDER BY it618_order");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp1.='select_area['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_name'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
	
	echo '
	<script>
	var arrcount='.$count.';
	var select_area = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_area[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_area(x,n)
	{
	 var temp = document.getElementById("it618_area2_id"+n); 
	 temp.options.length=1;
	 for (i=1;i<select_area[x].length;i++)
	 {
	  temp.options[i]=new Option(select_area[x][i].text,select_area[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_area_sel(n,index)
	{
	 var temp = document.getElementById("it618_area2_id"+n); 
	 temp.options[index].selected=true;
	
	}
	
	function redirec_area_add(x,n)
	{
	 var temp = document.getElementById("it618_area2_id_add"+n); 
	 temp.options.length=1;
	 for (i=1;i<select_area[x].length;i++)
	 {
	  temp.options[i]=new Option(select_area[x][i].text,select_area[x][i].value);
	 }
	 temp.options[0].selected=true;
	}
	
	'.$jstmp.'
	
	</script>';

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$it618_tuan_lang1=$it618_tuan_lang['s588'];
	$it618_tuan_lang2=$it618_tuan_lang['s589'];
	$it618_tuan_lang3=$it618_tuan_lang['s590'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_name[]").length;
	
		return [
		[[1,''], 
		[1,'<select name="newit618_area1_id[]" onchange="redirec_area_add(this.options.selectedIndex,'+n+')"><option value="0">$it618_tuan_lang1</option>$tmp</select><select id="it618_area2_id_add'+n+'" name="newit618_area2_id[]"><option value="0">$it618_tuan_lang2</option></select>'], 
		[1,'<input type="text" class="txt" style="width:200px" name="newit618_name[]">'], 
		[1,'<input type="text" class="txt" style="width:400px" name="newit618_addr[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpaddrjs
	function checkvalue(){
		$checkjs
		
		var n=document.getElementsByName("newit618_name[]").length;
		for(i=0;i<n;i++){
			if(document.getElementById("it618_area2_id_add"+i).value=="0"){
				alert("$it618_tuan_lang3");
				document.getElementById("it618_area2_id_add"+i).focus();
				return false;
			}
		}
	}
	
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallv9Ve" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallv9Ve">'.$it618_tuan_lang['s591'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" id="submit_it618submit" name="it618submit" onclick="return checkvalue();" value="'.$it618_tuan_lang['s592'].'" /> &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
    
?>