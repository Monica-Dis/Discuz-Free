<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

$n=1;
foreach(C::t('#it618_tuan#it618_tuan_shop')->fetch_all_by_isgoodsnot() as $it618_tmp) {
	if(isset($_GET['shopid'])){
		if($_GET['shopid']==$it618_tmp['id']){
			$licss='class="current"';
			$shopid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}else{
		if($n==1){
			$licss='class="current"';
			$shopid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}
	
	$shopuid=C::t('#it618_tuan#it618_tuan_shop')->fetch_it618_uid_by_id($it618_tmp['id']);
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_shop_thd')." WHERE it618_uid!=$shopuid");
	
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shopproduct_shopthd&cp1=$cp1&pmod=admin_product&shopid=".$it618_tmp['id']."&operation=$operation&do=$do&page=$page\"><span>".$it618_tmp['it618_name'].'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$n=$n+1;
}
if($n==1){
	cpmsg($it618_tuan_lang['s942'].')', "action=plugins&identifier=$identifier&cp=admin_shopproduct_shopthd&cp1=$cp1&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'error');
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';

$extrasql .= "it618_shopid =".$shopid;
$urlsql='&shopid='.$shopid;

if(submitcheck('it618submit')){
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		if($_GET['it618_isok'][$delid]==1){
			$tmpcount=C::t('#it618_tuan#it618_tuan_goods_thdtmp')->count_by_shopid_thdid($shopid,$delid);
			if($tmpcount==0){
				C::t('#it618_tuan#it618_tuan_goods_thdtmp')->insert(array(
					'it618_shopid' => $shopid,
					'it618_thdid' => $delid
				), true);
			}
		}else{
			C::t('#it618_tuan#it618_tuan_goods_thdtmp')->delete_by_shopid_thdid($shopid,$delid);
		}
	}

	cpmsg($it618_tuan_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_shopproduct_shopthd&cp1=$cp1&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

$shopuid=C::t('#it618_tuan#it618_tuan_shop')->fetch_it618_uid_by_id($shopid);

showformheader("plugins&identifier=$identifier&cp=admin_shopproduct_shopthd&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&pid=$pid".$urlsql);
$preurl=str_replace("@","&",$preurl);
showtableheaders($strtmptitle[$cp1],'admin_shopproduct_shopthd');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_shop_thd')." WHERE it618_uid!=$shopuid");

echo '<tr><td colspan=15>'.$it618_tuan_lang['s1710'].$count.'<span style="float:right;color:red">'.$it618_tuan_lang['s1721'].'</span></td></tr>';

showsubtitle(array($it618_tuan_lang['s56'], $it618_tuan_lang['s1708'], $it618_tuan_lang['s1720']));

$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_shop_thd')." WHERE it618_uid!=$shopuid ORDER BY it618_order desc");
while($it618_tuan_shop_thd = DB::fetch($query)) {
	
	$tmpcount1=C::t('#it618_tuan#it618_tuan_goods_thdtmp')->count_by_shopid_thdid($shopid,$it618_tuan_shop_thd['id']);
	if($tmpcount1>0)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
	
	$tmpcount2=C::t('#it618_tuan#it618_tuan_goods_thd')->count_by_shopid_thdid($shopid,$it618_tuan_shop_thd['id']);
	$disabled="";
	if($tmpcount1>0&&$tmpcount2>0)$disabled="disabled=\"disabled\"";
	
	showtablerow('', array('class="td25"', '', ''), array(
		'<input class="checkbox" type="hidden" name="delete[]" value="'.$it618_tuan_shop_thd['id'].'">'.$it618_tuan_shop_thd['id'],
		$it618_tuan_shop_thd['it618_name'].' <a href="'.it618_tuan_rewriteurl($it618_tuan_shop_thd['it618_uid']).'" target="_blank">'.it618_tuan_getusername($it618_tuan_shop_thd['it618_uid']).'</a> '.$it618_tuan_shop_thd['it618_addr'].' '.$it618_tuan_shop_thd['it618_dianhua'],
		'<input class="checkbox" type="checkbox" id="chk_isok'.$it618_tuan_shop_thd['id'].'" name="it618_isok['.$it618_tuan_shop_thd['id'].']" '.$it618_isok_checked.' '.$disabled.' value="1"><label for="chk_isok'.$it618_tuan_shop_thd['id'].'">'.$it618_tuan_lang['s1712'].'</label>'
	));
}
	
if($reabc[4]!='8')return; /*Dism��taobao��com*/
	
	showsubmit('it618submit', 'submit', '', "<input type=hidden value=$page name=page />");
	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>