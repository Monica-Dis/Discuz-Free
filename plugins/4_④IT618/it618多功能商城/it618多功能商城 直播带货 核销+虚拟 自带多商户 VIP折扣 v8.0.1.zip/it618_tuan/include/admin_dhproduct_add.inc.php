<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/

if(submitcheck('it618submit')){
	$id=C::t('#it618_tuan#it618_tuan_goods')->insert(array(
		'it618_shopid' => $_GET['it618_shopid'],
		'it618_class1_id' => $_GET['it618_class1_id'],
		'it618_class2_id' => $_GET['it618_class2_id'],
		'it618_type' => 0,
		'it618_name' => $_GET['it618_name'],
		'it618_pcurl' => $_GET['it618_pcurl'],
		'it618_wapurl' => $_GET['it618_wapurl'],
		'it618_description' => $_GET['it618_description'],
		'it618_saleprice' => $_GET['it618_saleprice'],
		'it618_picbig' => $_GET['it618_picbig'],
		'it618_time' => $_G['timestamp']
	), true);
	
	it618_tuan_getwapppic($_GET['it618_shopid'],$id,dhtmlspecialchars($_GET['it618_picbig']),0);

	cpmsg($it618_tuan_lang['s359'], "action=plugins&identifier=$identifier&cp=admin_dhproduct_add&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_dhproduct_add&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_tuan_goods');

foreach(C::t('#it618_tuan#it618_tuan_class1')->fetch_all_by_search() as $it618_tmp) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

foreach(C::t('#it618_tuan#it618_tuan_shop')->fetch_all_dhshop() as $it618_tmp) {
	$shoptmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_tuan/kindeditor/php/upload_json.php?imgwidth=640'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_tuan/kindeditor/php/file_manager_json.php\',
			allowFileManager : true
		});
		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
	});
	
	function checkvalue(){
		if(document.getElementById("it618_shopid").value=="0"){
			alert("'.$it618_tuan_lang['s573'].'");
			return false;
		}
		if(document.getElementById("it618_class2_id").value=="0"){
			alert("'.$it618_tuan_lang['s361'].'");
			return false;
		}
		if(document.getElementById("it618_name").value==""){
			alert("'.$it618_tuan_lang['s574'].'");
			return false;
		}
		if(document.getElementById("it618_saleprice").value==""){
			alert("'.$it618_tuan_lang['s364'].'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.$it618_tuan_lang['s372'].'");
			return false;
		}
	}
	
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function setpname(sjname){
		if(document.getElementById("it618_name").value==""){
			document.getElementById("it618_name").value=getSelectedText(sjname);
		}
	}
	
	function getSelectedText(){
	var obj=document.getElementById("it618_shopid");
	for(i=0;i<obj.length;i++){
	   if(obj[i].selected==true){
		return obj[i].innerText;
	   }
	}
	}
</script>

<tr><td width=80>'.$it618_tuan_lang['s575'].'</td><td><select id="it618_shopid" name="it618_shopid" onchange="setpname()"><option value="0">'.$it618_tuan_lang['s576'].'</option>'.$shoptmp.'</select> <font color=red>'.$it618_tuan_lang['s808'].'</font></td></tr>
<tr><td width=80>'.$it618_tuan_lang['s374'].'</td><td><select name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)"><option value="0">'.$it618_tuan_lang['s375'].'</option>'.$classtmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.$it618_tuan_lang['s376'].'</option></select> </td></tr>
<tr><td>'.$it618_tuan_lang['s577'].'</td><td><input type="text" class="txt" style="width:400px;margin-right:0" id="it618_name" name="it618_name"> </td></tr>
<tr><td>'.$it618_tuan_lang['s378'].'</td><td><input type="text" class="txt" style="width:80px;color:red" id="it618_saleprice" name="it618_saleprice" onkeyup="value=value.replace(/[^\-?\d.]/g,\'\')">'.$it618_tuan_lang['s125'].'</td></tr>
<tr><td>'.$it618_tuan_lang['s394'].'</td><td><img id="img1" src="" width="150" height="150" align="absmiddle" style="margin-right:3px"/><input type="text" id="url1" name="it618_picbig" value="" readonly="readonly" /> <input type="button" id="image1" value="'.$it618_tuan_lang['s395'].'" /></td></tr>
<tr><td>'.$it618_tuan_lang['s578'].'</td><td><input type="text" class="txt" style="width:696px;margin-right:0" id="it618_pcurl" name="it618_pcurl"> </td></tr>
<tr><td>'.$it618_tuan_lang['s579'].'</td><td><input type="text" class="txt" style="width:696px;margin-right:0" id="it618_wapurl" name="it618_wapurl"> '.$it618_tuan_lang['s580'].'</td></tr>
<tr><td>'.$it618_tuan_lang['s403'].'</td><td><textarea name="it618_description" style="width:696px;height:60px;"></textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.$it618_tuan_lang['s407'].'" /></div></td></tr>';

if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>