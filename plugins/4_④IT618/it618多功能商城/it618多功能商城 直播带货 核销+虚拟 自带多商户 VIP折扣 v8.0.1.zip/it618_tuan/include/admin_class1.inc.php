<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/
if(submitcheck('it618submit')){
	$ok1=0;
	
	if($reabc[8]!='a')return;

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_tuan#it618_tuan_class1')->update($id,array(
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_classnamenav' => trim($_GET['it618_classnamenav'][$id]),
				'it618_pj' => trim($_GET['it618_pj'][$id]),
				'it618_goodscount' => trim($_GET['it618_goodscount'][$id]),
				'it618_wapgoodscount' => trim($_GET['it618_wapgoodscount'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_url' => trim($_GET['it618_url'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	cpmsg($it618_tuan_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return;
if(submitcheck('it618sercsubmit')) {
	if($_GET['beforeword']) {
		$extrasql = "AND it618_classname LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
	}
}

showformheader("plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do");
showtableheaders($it618_tuan_lang['s41'],'it618_tuan_class1');
	showsubmit('it618sercsubmit', $it618_tuan_lang['s25'], $it618_tuan_lang['s42'].' <input name="beforeword" value="'.$_GET['beforeword'].'" class="txt" />');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_class1')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10>'.$it618_tuan_lang['s43'].$count.'<span style="float:right;color:red">'.$it618_tuan_lang['s44'].'</span></td></tr>';
	showsubtitle(array($it618_tuan_lang['s45'],$it618_tuan_lang['s46'],$it618_tuan_lang['s47'], $it618_tuan_lang['s49'],$it618_tuan_lang['s881'],$it618_tuan_lang['s882'],$it618_tuan_lang['s50'],$it618_tuan_lang['s53'],$it618_tuan_lang['s54']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." WHERE 1 $extrasql ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_tuan =	DB::fetch($query)) {
		$class2count = C::t('#it618_tuan#it618_tuan_class2')->count_by_it618_class1_id($it618_tuan['id']);
		$goodscount=C::t('#it618_tuan#it618_tuan_goods')->count_by_search('','',0,$it618_tuan['id'],0,0,0,'',0,0);
		
		$it618_img='';
		if($it618_tuan['it618_img']!='')$it618_img='src="'.$it618_tuan['it618_img'].'"';
		
		showtablerow('', array('', '', '', '', ''), array(
			"<input type=\"text\" class=\"txt\" style=\"width:80px\" name=\"it618_classname[$it618_tuan[id]]\" value=\"$it618_tuan[it618_classname]\">cid=$it618_tuan[id]",
			"<input type=\"text\" class=\"txt\" style=\"width:40px\" name=\"it618_classnamenav[$it618_tuan[id]]\" value=\"$it618_tuan[it618_classnamenav]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_pj[$it618_tuan[id]]\" value=\"$it618_tuan[it618_pj]\">",
			'<input class="txt" type="text" style="width:65px;margin-right:0" name="it618_goodscount['.$it618_tuan['id'].']" value="'.$it618_tuan['it618_goodscount'].'">/<input class="txt" type="text" style="width:65px" name="it618_wapgoodscount['.$it618_tuan['id'].']" value="'.$it618_tuan['it618_wapgoodscount'].'">',
			'<img '.$it618_img.' id="img'.$it618_tuan['id'].'" width="100" height="25" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url'.$it618_tuan['id'].'" name="it618_img['.$it618_tuan['id'].']" style="width:30px" readonly="readonly" value="'.$it618_tuan['it618_img'].'" /> <input type="button" id="image'.$it618_tuan['id'].'" value="'.$it618_tuan_lang['s883'].'" /><input type="button" value="'.$it618_tuan_lang['s884'].'" onclick="document.getElementById(\'url'.$it618_tuan['id'].'\').value=\'\';document.getElementById(\'img'.$it618_tuan['id'].'\').src=\'\'" />',
			'<input class="txt" type="text" style="width:150px;" name="it618_url['.$it618_tuan['id'].']" value="'.$it618_tuan['it618_url'].'">',
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_tuan['id'].']" value="'.$it618_tuan['it618_order'].'">',
			$class2count,
			$goodscount
		));
		$editorjs.='K(\'#image'.$it618_tuan['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_tuan['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_tuan['id'].'\').val(url);
								K(\'#img'.$it618_tuan['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_tuan/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_tuan/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
	
	echo '<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" id="submit_it618submit" name="it618submit" value="'.$it618_tuan_lang['s885'].'" /> <font color=red>'.$it618_tuan_lang['s886'].'</font></div></td></tr>';
	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>