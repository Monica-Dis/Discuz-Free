<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/tuan_function.func.php';

if($_GET['it618_type']==0)$selected0='selected="selected"';
if($_GET['it618_type']==10)$selected10='selected="selected"';
if($_GET['it618_type']==1)$selected1='selected="selected"';
if($_GET['it618_type']==2)$selected2='selected="selected"';
if($_GET['it618_type']==3)$selected3='selected="selected"';

if($_GET['it618_state']==0)$stateselected0='selected="selected"';
if($_GET['it618_state']==1)$stateselected1='selected="selected"';
if($_GET['it618_state']==2)$stateselected2='selected="selected"';

$sql="&it618_type=".$_GET['it618_type']."&it618_time1=".$_GET['it618_time1']."&it618_time2=".$_GET['it618_time2']."&it618_state=".$_GET['it618_state'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[7]!='u')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_tx = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_tx')." where id=".$delid);

		if($it618_tuan_tx['it618_state']==1){
			DB::delete('it618_tuan_tx', "id=$delid");
			DB::query("update ".DB::table('it618_tuan_shop')." set it618_money=it618_money+".$it618_tuan_tx['it618_price']." where id=".$it618_tuan_tx['it618_shopid']);
			$del=$del+1;
		}
	}

	cpmsg($it618_tuan_lang['s249'].$del, "action=plugins&identifier=$identifier&cp=admin_tx&pmod=admin_tx&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_ok')){
	$ok=0;
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_tx = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_tx')." where id=".$delid);
		
		if($it618_tuan_tx['it618_state']!=2){
			DB::query("update ".DB::table('it618_tuan_tx')." set it618_state=2 WHERE id=".$delid);
			
			it618_tuan_sendmessage('tx_shop',$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s252'].$ok, "action=plugins&identifier=$identifier&cp=admin_tx&pmod=admin_tx&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=10)return;


showformheader("plugins&identifier=$identifier&cp=admin_tx&pmod=admin_tx&operation=$operation&do=$do");
showtableheaders($it618_tuan_lang['s253'],'it618_tuan_sum');
	showsubmit('it618sercsubmit', $it618_tuan_lang['s25'], '<script charset="utf-8" src="source/plugin/it618_tuan/js/Calendar.js"></script>'.$it618_tuan_lang['s254'].' <select name="it618_type"><option value="0" '.$selected0.'>'.it618_tuan_getlang('s255').'</option><option value="10" '.$selected10.'>'.it618_tuan_getlang('s1136').'</option><option value="1" '.$selected1.'>'.it618_tuan_getlang('s257').'</option><option value="2" '.$selected2.'>'.it618_tuan_getlang('s1137').'</option><option value="3" '.$selected3.'>'.it618_tuan_getlang('s256').'</option></select> '.$it618_tuan_lang['s258'].' <input name="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> - <input name="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>'.$it618_tuan_lang['s259'].' <select name="it618_state"><option value="0" '.$stateselected0.'>'.$it618_tuan_lang['s260'].'</option><option value="1" '.$stateselected1.'>'.$it618_tuan_lang['s261'].'</option><option value="2" '.$stateselected2.'>'.$it618_tuan_lang['s262'].'</option></select>');
	
	$count = C::t('#it618_tuan#it618_tuan_tx')->count_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$_GET['it618_uid']);
	$sum = C::t('#it618_tuan#it618_tuan_tx')->sum_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$_GET['it618_uid']);
	if($sum=='')$sum=0;
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_tx&pmod=admin_tx&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=10>'.$it618_tuan_lang['s263'].'<font color=red>'.$count.'</font> '.$it618_tuan_lang['s264'].'<font color=red>'.$sum.'</font> '.$it618_tuan_lang['s125'].'</td></tr>';
	showsubtitle(array('', $it618_tuan_lang['s265'],$it618_tuan_lang['s266'],$it618_tuan_lang['s267'],$it618_tuan_lang['s268'],$it618_tuan_lang['s269'],$it618_tuan_lang['s270'],$it618_tuan_lang['s271'],$it618_tuan_lang['s272'],$it618_tuan_lang['s273']));
	
	foreach(C::t('#it618_tuan#it618_tuan_tx')->fetch_all_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$_GET['it618_uid'], $startlimit,$ppp) as $it618_tuan_tx)    {
		
		$fwf=round(($it618_tuan_tx['it618_price']*$it618_tuan_tx['it618_bl']/100),2);
		$it618_tuan_bank = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_bank')." where it618_shopid=".$it618_tuan_tx['it618_shopid']);
		$shopname = C::t('#it618_tuan#it618_tuan_shop')->fetch_name_by_id($it618_tuan_tx['it618_shopid']);
		
		$it618_type=$it618_tuan_lang['s1144'];
		if($it618_tuan_tx['it618_type']==1){
			$it618_type=$it618_tuan_lang['s274'].$it618_tuan_bank['it618_alipayname'].$it618_tuan_lang['s278'].$it618_tuan_bank['it618_alipay'];
		}
		
		if($it618_tuan_tx['it618_type']==2){
			$it618_type=$it618_tuan_lang['s274'].$it618_tuan_bank['it618_wxname'].$it618_tuan_lang['s1143'].$it618_tuan_bank['it618_wx'];
		}
		
		if($it618_tuan_tx['it618_type']==3){
			$it618_type=$it618_tuan_lang['s274'].$it618_tuan_bank['it618_name'].$it618_tuan_lang['s275'].$it618_tuan_bank['it618_bankname'].'<br>'.$it618_tuan_lang['s276'].$it618_tuan_bank['it618_bankid'].$it618_tuan_lang['s277'].$it618_tuan_bank['it618_bankaddr'];
		}
	
		if($it618_tuan_tx['it618_state']==1)$it618_state='<font color=red>'.$it618_tuan_lang['s261'].'</font>';
		if($it618_tuan_tx['it618_state']==2){$it618_state='<font color=green>'.$it618_tuan_lang['s262'].'</font>';$disabled='disabled="disabled"';}else{$disabled='';}

		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_tuan_tx[id].'" name="delete[]" value="'.$it618_tuan_tx[id].'" '.$disabled.'>',
			'<font color=red>'.$it618_tuan_tx['it618_price'].'</font>',
			$it618_tuan_tx['it618_bl'],
			$fwf,
			'<font color=green>'.($it618_tuan_tx['it618_price']-$fwf).'</font>',
			$it618_tuan_tx['it618_bz'],
			'<div style="width:75px">'.date('Y-m-d H:i:s', $it618_tuan_tx['it618_time']).'</div>',
			$shopname,
			$it618_type,
			$it618_state
		));
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_tuan_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_tuan_lang['s279'].'" onclick="return confirm(\''.$it618_tuan_lang['s280'].'\')" /> <input type="submit" class="btn" name="it618submit_ok" value="'.$it618_tuan_lang['s281'].'" onclick="return confirm(\''.$it618_tuan_lang['s282'].'\')"/> '.$it618_tuan_lang['s283'].' &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>