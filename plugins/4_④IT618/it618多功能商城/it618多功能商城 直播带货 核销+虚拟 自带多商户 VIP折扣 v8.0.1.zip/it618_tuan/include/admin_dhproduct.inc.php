<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/

$state0='';$state1='';$state2='';$state3='';
if($_GET['state']==0){$it618sql = "1";$state0='selected="selected"';}
if($_GET['state']==1){$it618sql = "g.it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql = "g.it618_state = 1";$state2='selected="selected"';}


$urlsql='&key='.$_GET['key'].'&price1='.$_GET['price1'].'&price2='.$_GET['price2'].'&it618_shopid='.$_GET['it618_shopid'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($delid);
		$tmparr=explode("source",$it618_tuan_goods['it618_picbig']);
		$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
		if(file_exists($it618_picbig)){
			$result=unlink($it618_picbig);
		}
		
		$tmparr=explode("source",$it618_tuan_goods['it618_picbig']);
		$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
		if(file_exists($it618_picbig)){
			$result=unlink($it618_picbig);
		}
		
		$file_ext=strtolower(substr($it618_picbig,strrpos($it618_picbig, '.')+1)); 
		$it618_smallurl='source/plugin/it618_tuan/kindeditor/data/shop'.$it618_tuan_goods['it618_shopid'].'/smallimage/goods'.$delid.'.'.$file_ext;
		$tmparr=explode("source",$it618_smallurl);
		$it618_smallurl=DISCUZ_ROOT.'./source'.$tmparr[1];
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		
		C::t('#it618_tuan#it618_tuan_goods')->delete_by_id($delid);
		$del=$del+1;
	}

	cpmsg($it618_tuan_lang['s342'].$del, "action=plugins&identifier=$identifier&cp=admin_dhproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_order'])) {
		foreach($_GET['it618_order'] as $id => $val) {
			C::t('#it618_tuan#it618_tuan_goods')->update($id,array(
				'it618_name' => $_GET['it618_name'][$id],
				'it618_pcurl' => $_GET['it618_pcurl'][$id],
				'it618_wapurl' => $_GET['it618_wapurl'][$id],
				'it618_description' => $_GET['it618_description'][$id],
				'it618_price' => $_GET['it618_price'][$id],
				'it618_saleprice' => $_GET['it618_saleprice'][$id],
				'it618_salecount' => $_GET['it618_salecount'][$id],
				'it618_order' => $_GET['it618_order'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s90'].$ok, "action=plugins&identifier=$identifier&cp=admin_dhproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_on')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($delid);
		if($it618_tuan_goods['it618_state']==0){
			DB::query("update ".DB::table('it618_tuan_goods')." set it618_state=1 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s343'].$ok, "action=plugins&identifier=$identifier&cp=admin_dhproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_down')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($delid);
		if($it618_tuan_goods['it618_state']==1){
			DB::query("update ".DB::table('it618_tuan_goods')." set it618_state=0 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s344'].$ok, "action=plugins&identifier=$identifier&cp=admin_dhproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return;

$shoptmp='<option value="0">'.$it618_tuan_lang['s564'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_shop')." WHERE it618_uid=0 ORDER BY it618_name");
while($it618_tmp =	DB::fetch($query1)) {
	$shoptmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}
$shoptmp1=str_replace('<option value='.$_GET['it618_shopid'].'>','<option value='.$_GET['it618_shopid'].' selected="selected">',$shoptmp);

$tmp='<option value="0">'.$it618_tuan_lang['s95'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

showformheader("plugins&identifier=$identifier&cp=admin_dhproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql);
showtableheaders($strtmptitle[$cp1],'it618_tuan_goods');
	showsubmit('it618sercsubmit', $it618_tuan_lang['s25'], $it618_tuan_lang['s97'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:150px" /> '.$it618_tuan_lang['s98'].' <input name="price1" value="'.$_GET['price1'].'" class="txt" style="width:50px;margin-right:0" /> - <input name="price2" value="'.$_GET['price2'].'" class="txt" style="width:50px" /> '.$it618_tuan_lang['s565'].' <select id="it618_shopid" name="it618_shopid">'.$shoptmp1.'</select> '.$it618_tuan_lang['s99'].' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.$it618_tuan_lang['s100'].'</option></select> '.$it618_tuan_lang['s101'].' <select name="state"><option value=0 '.$state0.'>'.$it618_tuan_lang['s102'].'</option><option value=1 '.$state1.'>'.$it618_tuan_lang['s103'].'</option><option value=2 '.$state2.'>'.$it618_tuan_lang['s104'].'</option></select>');
	
	$count = C::t('#it618_tuan#it618_tuan_goods')->count_by_search('g.it618_type=0 and '.$it618sql,'',$_GET['it618_shopid'],$_GET['it618_class1_id'],$_GET['it618_class2_id'],0,0,$_GET['key'],$_GET['price1'],$_GET['price2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_dhproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	echo '<tr><td colspan=14>'.$it618_tuan_lang['s114'].$count.'<span style="float:right;color:red"></span></td></tr>';
	showsubtitle(array('',$it618_tuan_lang['s566'],$it618_tuan_lang['s567'],$it618_tuan_lang['s568'],$it618_tuan_lang['s569'],$it618_tuan_lang['s570'],$it618_tuan_lang['s571']));
	
	$n=1;
	foreach(C::t('#it618_tuan#it618_tuan_goods')->fetch_all_by_search(
		'g.it618_type!=1 and '.$it618sql,$it618orderby,$_GET['it618_shopid'],$_GET['it618_class1_id'],$_GET['it618_class2_id'],0,0,$_GET['key'],$_GET['price1'],$_GET['price2'],$startlimit,$ppp
	) as $it618_tuan_goods) {
		
		if($it618_tuan_goods['it618_state']==0)$it618_state='<font color=blue>'.$it618_tuan_lang['s103'].'</font>';
		if($it618_tuan_goods['it618_state']==1)$it618_state='<font color=green>'.$it618_tuan_lang['s104'].'</font>';
		
		$shopname = C::t('#it618_tuan#it618_tuan_shop')->fetch_name_by_id($it618_tuan_goods['it618_shopid']);
		$class1name = C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_name_by_id($it618_tuan_goods['it618_class1_id']);
		$class2name = C::t('#it618_tuan#it618_tuan_class2')->fetch_it618_name_by_id($it618_tuan_goods['it618_class2_id']);
		
		$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
		
		$preurl="action=plugins&identifier=$identifier&cp=admin_dhproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql;
		$preurl=str_replace("&","@",$preurl);

		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_tuan_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_tuan_goods['id'].'</label>',
			'<a style="float:left" href="'.$tmpurl.'" target="_blank" title="'.$shopname.' '.$class1name.'-'.$class2name.'"><img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="80" height="80" align="absmiddle"/></a><div style="float:left;margin-left:3px;line-height:18px"><input type="text" class="txt" style="width:200px" name="it618_name['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_name'].'"><br><input type="text" class="txt" style="width:60px;margin-right:3px;color:red" name="it618_saleprice['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_saleprice'].'">'.$it618_tuan_lang['s125'].'/<input type="text" class="txt" style="width:60px;margin-right:3px;" name="it618_price['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_price'].'">'.$it618_tuan_lang['s125'].' <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_dhproduct_edit&pmod=admin_product&operation='.$operation.'&do='.$do.'&cp1=3&pid='.$it618_tuan_goods['id'].'&preurl='.$preurl.'">'.$it618_tuan_lang['s351'].'</a></div>',
			'<input type="text" class="txt" style="width:200px" name="it618_pcurl['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_pcurl'].'"><br><input type="text" class="txt" style="width:200px" name="it618_wapurl['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_wapurl'].'">',
			'<textarea type="text" style="width:400px;height:50px" name="it618_description['.$it618_tuan_goods['id'].']">'.$it618_tuan_goods['it618_description'].'</textarea>',
			'<input type="text" class="txt" style="width:40px" name="it618_salecount['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_salecount'].'">',
			$it618_state,
			'<input type="text" class="txt" style="width:40px" name="it618_order['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_order'].'">'
		));
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_class1'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' ORDER BY it618_order");
	$n1=1;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$n2=1;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
	
	echo '
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	</script>';

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_tuan_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_tuan_lang['s352'].'" onclick="return confirm(\''.$it618_tuan_lang['s353'].'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_tuan_lang['s572'].'"/> <input type="submit" class="btn" name="it618submit_on" value="'.$it618_tuan_lang['s355'].'" onclick="return confirm(\''.$it618_tuan_lang['s356'].'\')" /> <input type="submit" class="btn" name="it618submit_down" value="'.$it618_tuan_lang['s357'].'" onclick="return confirm(\''.$it618_tuan_lang['s358'].'\')" /><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
echo '<script>
		'.$jstmp.'

		function setservice(obj){
			if(obj.checked==true){
				document.getElementById("isservice").style.display="none"; 
			}else{
				document.getElementById("isservice").style.display=""; 
			}
		}
		</script>';
?>