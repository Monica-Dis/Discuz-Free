<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$tuan_home=\''.'tuan'."';\n";
		$fileData .= '$tuan_list=\''.'tuan_list'."';\n";
		$fileData .= '$tuan_search=\''.'tuan_search'."';\n";
		$fileData .= '$tuan_gwc=\''.'tuan_gwc'."';\n";
		$fileData .= '$tuan_product=\''.'tuan_product'."';\n";
		$fileData .= '$tuan_map=\''.'tuan_map'."';\n";
		$fileData .= '$tuan_shop=\''.'tuan_shop'."';\n";
		$fileData .= '$tuan_sc=\''.'tuan_sc'."';\n";
		$fileData .= '$tuan_wap=\''.'tuan_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$tuan_home1=\''.$urltype."';\n";
		$fileData .= '$tuan_list1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$tuan_search1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$tuan_gwc1=\''.$urltype."';\n";
		$fileData .= '$tuan_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$tuan_map1=\'-{sid}'.$urltype."';\n";
		$fileData .= '$tuan_shop1=\'-{sid}'.$urltype."';\n";
		$fileData .= '$tuan_sc1=\''.$urltype."';\n";
		$fileData .= '$tuan_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_tuan/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$tuan_home=\''.str_replace("-","",$_GET['tuan_home'])."';\n";
		$fileData .= '$tuan_list=\''.str_replace("-","",$_GET['tuan_list'])."';\n";
		$fileData .= '$tuan_search=\''.str_replace("-","",$_GET['tuan_search'])."';\n";
		$fileData .= '$tuan_gwc=\''.str_replace("-","",$_GET['tuan_gwc'])."';\n";
		$fileData .= '$tuan_product=\''.str_replace("-","",$_GET['tuan_product'])."';\n";
		$fileData .= '$tuan_map=\''.str_replace("-","",$_GET['tuan_map'])."';\n";
		$fileData .= '$tuan_shop=\''.str_replace("-","",$_GET['tuan_shop'])."';\n";
		$fileData .= '$tuan_sc=\''.str_replace("-","",$_GET['tuan_sc'])."';\n";
		$fileData .= '$tuan_wap=\''.str_replace("-","",$_GET['tuan_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$tuan_home1=\''.$urltype."';\n";
		$fileData .= '$tuan_list1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$tuan_search1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$tuan_gwc1=\''.$urltype."';\n";
		$fileData .= '$tuan_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$tuan_map1=\'-{sid}'.$urltype."';\n";
		$fileData .= '$tuan_shop1=\'-{sid}'.$urltype."';\n";
		$fileData .= '$tuan_sc1=\''.$urltype."';\n";
		$fileData .= '$tuan_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_tuan_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_tuan_lang['s136'].'</font></td></tr>
<tr><td colspan="3">'.$it618_tuan_lang['s137'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_tuan_lang['s138'].'</th><th>'.$it618_tuan_lang['s139'].'</th><th>'.$it618_tuan_lang['s140'].'</th></tr>
<tr class="hover">
<td>'.$it618_tuan_lang['s141'].'</td><td></td><td class="longtxt"><input name="tuan_home" value="'.$tuan_home.'"/>'.$tuan_home.$tuan_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_tuan_lang['s142'].'</td><td>{cid1}, {cid2}, {aid1}, {aid2}, {price}, {order}, {page}</td><td class="longtxt"><input name="tuan_list" value="'.$tuan_list.'" />'.$tuan_list.$tuan_list1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_tuan_lang['s143'].'</td><td>{cid1}, {cid2}, {aid1}, {aid2}, {price}, {order}, {page}</td><td class="longtxt"><input name="tuan_search" value="'.$tuan_search.'" />'.$tuan_search.$tuan_search1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_tuan_lang['s1071'].'</td><td></td><td class="longtxt"><input name="tuan_gwc" value="'.$tuan_gwc.'"/>'.$tuan_gwc.$tuan_gwc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_tuan_lang['s144'].'</td><td>{pid}</td><td class="longtxt"><input name="tuan_product" value="'.$tuan_product.'" />'.$tuan_product.$tuan_product1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_tuan_lang['s145'].'</td><td>{sid}</td><td class="longtxt"><input name="tuan_map" value="'.$tuan_map.'" />'.$tuan_map.$tuan_map1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_tuan_lang['s813'].'</td><td>{sid}</td><td class="longtxt"><input name="tuan_shop" value="'.$tuan_shop.'" />'.$tuan_shop.$tuan_shop1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_tuan_lang['s146'].'</td><td></td><td class="longtxt"><input name="tuan_sc" value="'.$tuan_sc.'"/>'.$tuan_sc.$tuan_sc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_tuan_lang['s147'].'</td><td>{pagetype}, {cid1}, {cid2}</td><td class="longtxt"><input name="tuan_wap" value="'.$tuan_wap.'"/>'.$tuan_wap.$tuan_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_tuan_lang['s23']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_tuan_lang['s148'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_home.$urltype.'$ $1/plugin.php?id=it618_tuan:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:list&class1=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:list&class1=$2&class2=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:list&class1=$2&class2=$3&area1=$4&area2=$5&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:list&class1=$2&class2=$3&area1=$4&area2=$5&price=$6&order=$7&page=$8&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_search.$urltype.'$ $1/plugin.php?id=it618_tuan:search&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:search&class1=$2&class2=$3&area1=$4&area2=$5&price=$6&order=$7&page=$8&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_gwc.$urltype.'$ $1/plugin.php?id=it618_tuan:gwc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:product&pid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_map.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:map&sid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_shop.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:shop&sid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_sc.$urltype.'$ $1/plugin.php?id=it618_tuan:sc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_wap.$urltype.'$ $1/plugin.php?id=it618_tuan:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:wap&pagetype=$2&cid1=$3&cid2=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:wap&pagetype=$2&cid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$tuan_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:wap&pagetype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_tuan_lang['s149'].'</h1>
<pre class="colorbox">
'.$it618_tuan_lang['s150'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_home.$urltype.'$ plugin.php?id=it618_tuan:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_list.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:list&class1=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:list&class1=$1&class2=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:list&class1=$1&class2=$2&area1=$3&area2=$4&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:list&class1=$1&class2=$2&area1=$3&area2=$4&price=$5&order=$6&page=$7&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_search.$urltype.'$ plugin.php?id=it618_tuan:search&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:search&class1=$1&class2=$2&area1=$3&area2=$4&price=$5&order=$6&page=$7&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_gwc.$urltype.'$ plugin.php?id=it618_tuan:gwc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_product.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:product&pid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_map.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:map&sid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_shop.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:shop&sid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_sc.$urltype.'$ plugin.php?id=it618_tuan:sc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_wap.$urltype.'$ plugin.php?id=it618_tuan:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:wap&pagetype=$1&cid1=$2&cid2=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_tuan:wap&pagetype=$1&cid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$tuan_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_tuan:wap&pagetype=$1&%1</font>

</pre>

<h1>'.$it618_tuan_lang['s151'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$tuan_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:index&$3
RewriteRule ^(.*)/'.$tuan_list.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:list&class1=$2&$4
RewriteRule ^(.*)/'.$tuan_list.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:list&class1=$2&class2=$3&$5
RewriteRule ^(.*)/'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:list&class1=$2&class2=$3&area1=$4&area2=$5&$7
RewriteRule ^(.*)/'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:list&class1=$2&class2=$3&area1=$4&area2=$5&price=$6&order=$7&page=$8&$10
RewriteRule ^(.*)/'.$tuan_search.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:search&$3
RewriteRule ^(.*)/'.$tuan_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:search&class1=$2&class2=$3&area1=$4&area2=$5&price=$6&order=$7&page=$8&$10
RewriteRule ^(.*)/'.$tuan_gwc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:gwc&$3
RewriteRule ^(.*)/'.$tuan_product.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:product&pid=$2&$4
RewriteRule ^(.*)/'.$tuan_map.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:map&sid=$2&$4
RewriteRule ^(.*)/'.$tuan_shop.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:shop&sid=$2&$4
RewriteRule ^(.*)/'.$tuan_sc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:sc&$3
RewriteRule ^(.*)/'.$tuan_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:wap&$3
RewriteRule ^(.*)/'.$tuan_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:wap&pagetype=$2&cid1=$3&cid2=$4&$6
RewriteRule ^(.*)/'.$tuan_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:wap&pagetype=$2&cid=$3&$5
RewriteRule ^(.*)/'.$tuan_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_tuan:wap&pagetype=$2&$4</font>

</pre>

<h1>'.$it618_tuan_lang['s152'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="tuan_home"&gt;
			&lt;match url="^(.*/)*'.$tuan_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_list1"&gt;
			&lt;match url="^(.*/)*'.$tuan_list.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:list&amp;amp;class1={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_list2"&gt;
			&lt;match url="^(.*/)*'.$tuan_list.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_list3"&gt;
			&lt;match url="^(.*/)*'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;area1={R:4}&amp;amp;area2={R:5}&amp;amp;{R:6}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_list4"&gt;
			&lt;match url="^(.*/)*'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;area1={R:4}&amp;amp;area2={R:5}&amp;amp;price={R:6}&amp;amp;order={R:7}&amp;amp;page={R:8}&amp;amp;{R:9}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_search"&gt;
			&lt;match url="^(.*/)*'.$tuan_search.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:search&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_search1"&gt;
			&lt;match url="^(.*/)*'.$tuan_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:search&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;area1={R:4}&amp;amp;area2={R:5}&amp;amp;price={R:6}&amp;amp;order={R:7}&amp;amp;page={R:8}&amp;amp;{R:9}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_gwc"&gt;
			&lt;match url="^(.*/)*'.$tuan_gwc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:gwc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_product"&gt;
			&lt;match url="^(.*/)*'.$tuan_product.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:product&amp;amp;pid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_map"&gt;
			&lt;match url="^(.*/)*'.$tuan_map.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:map&amp;amp;sid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_shop"&gt;
			&lt;match url="^(.*/)*'.$tuan_shop.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:shop&amp;amp;sid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_sc"&gt;
			&lt;match url="^(.*/)*'.$tuan_sc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:sc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_wap"&gt;
			&lt;match url="^(.*/)*'.$tuan_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_wap1"&gt;
			&lt;match url="^(.*/)*'.$tuan_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:wap&amp;amp;pagetype={R:2}&amp;amp;cid1={R:3}&amp;amp;cid2={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_wap2"&gt;
			&lt;match url="^(.*/)*'.$tuan_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="tuan_wap3"&gt;
			&lt;match url="^(.*/)*'.$tuan_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_tuan:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$tuan_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:index&$2
endif
match URL into $ with ^(.*)/'.$tuan_list.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:list&class1=$2&$3
endif
match URL into $ with ^(.*)/'.$tuan_list.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:list&class1=$2&class2=$3&$4
endif
match URL into $ with ^(.*)/'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:list&class1=$2&class2=$3&area1=$4&area2=$5&$6
endif
match URL into $ with ^(.*)/'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:list&class1=$2&class2=$3&area1=$4&area2=$5&price=$6&order=$7&page=$8&$9
endif
match URL into $ with ^(.*)/'.$tuan_search.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:search&$2
endif
match URL into $ with ^(.*)/'.$tuan_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:search&class1=$2&class2=$3&area1=$4&area2=$5&price=$6&order=$7&page=$8&$9
endif
match URL into $ with ^(.*)/'.$tuan_gwc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:gwc&$2
endif
match URL into $ with ^(.*)/'.$tuan_product.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:product&pid=$2&$3
endif
match URL into $ with ^(.*)/'.$tuan_map.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:map&sid=$2&$3
endif
match URL into $ with ^(.*)/'.$tuan_shop.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:shop&sid=$2&$3
endif
match URL into $ with ^(.*)/'.$tuan_sc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:sc&$2
endif
match URL into $ with ^(.*)/'.$tuan_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:wap&$2
endif
match URL into $ with ^(.*)/'.$tuan_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:wap&pagetype=$2&cid1=$3&cid2=$4&$5
endif
match URL into $ with ^(.*)/'.$tuan_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:wap&pagetype=$2&cid=$3&$4
endif
match URL into $ with ^(.*)/'.$tuan_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_tuan:wap&pagetype=$2&$3
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$tuan_home.$urltype.'$ $1/plugin.php?id=it618_tuan:index&$2 last;
rewrite ^([^\.]*)/'.$tuan_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:list&class1=$2&$3 last;
rewrite ^([^\.]*)/'.$tuan_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:list&class1=$2&class2=$3&$4 last;
rewrite ^([^\.]*)/'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:list&class1=$2&class2=$3&area1=$4&area2=$5&$6 last;
rewrite ^([^\.]*)/'.$tuan_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:list&class1=$2&class2=$3&area1=$4&area2=$5&price=$6&order=$7&page=$8&$9 last;
rewrite ^([^\.]*)/'.$tuan_search.$urltype.'$ $1/plugin.php?id=it618_tuan:search&$2 last;
rewrite ^([^\.]*)/'.$tuan_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:search&class1=$2&class2=$3&area1=$4&area2=$5&price=$6&order=$7&page=$8&$9 last;
rewrite ^([^\.]*)/'.$tuan_gwc.$urltype.'$ $1/plugin.php?id=it618_tuan:gwc&$2 last;
rewrite ^([^\.]*)/'.$tuan_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:product&pid=$2&$3 last;
rewrite ^([^\.]*)/'.$tuan_map.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:map&sid=$2&$3 last;
rewrite ^([^\.]*)/'.$tuan_shop.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:shop&sid=$2&$3 last;
rewrite ^([^\.]*)/'.$tuan_sc.$urltype.'$ $1/plugin.php?id=it618_tuan:sc&$2 last;
rewrite ^([^\.]*)/'.$tuan_wap.$urltype.'$ $1/plugin.php?id=it618_tuan:wap&$2 last;
rewrite ^([^\.]*)/'.$tuan_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:wap&pagetype=$2&cid1=$3&cid2=$4&$5 last;
rewrite ^([^\.]*)/'.$tuan_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:wap&pagetype=$2&cid=$3&$4 last;
rewrite ^([^\.]*)/'.$tuan_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_tuan:wap&pagetype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/

?>