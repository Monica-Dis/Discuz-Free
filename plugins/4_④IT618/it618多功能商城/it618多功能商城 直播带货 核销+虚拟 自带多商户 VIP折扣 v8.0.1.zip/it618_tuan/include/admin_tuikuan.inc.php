<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/tuan_function.func.php';

$state0='';$state1='';$state2='';
$time=$_G['timestamp']-3600*24*$it618_tuan['tuan_tuidatecount'];
if($_GET['state']==0){$it618sql = "(s.it618_state = 1 and UNIX_TIMESTAMP(s.it618_esaletime)<".$time." and s.it618_esaletime!='' and s.it618_isservice2<>2) or s.it618_state = 2";$state0='selected="selected"';}
if($_GET['state']==1){$it618sql = "(s.it618_state = 1 and UNIX_TIMESTAMP(s.it618_esaletime)<".$time." and s.it618_esaletime!='' and s.it618_isservice2<>2)";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql = "s.it618_state = 2";$state2='selected="selected"';}

$urlsql="&pid=".$_GET['pid']."&finduid=".$_GET['finduid']."&state=".$_GET['state']."&it618_time1=".$_GET['it618_time1']."&it618_time2=".$_GET['it618_time2'];

if(submitcheck('it618submit_tuikuan')){
	$ok=0;
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_sale')." where id=".$delid);
		
		if($it618_tuan_sale['it618_state']==1){
			C::t('#it618_tuan#it618_tuan_sale')->update_it618_state($delid,5);
			C::t('#it618_tuan#it618_tuan_sale')->update_it618_code($delid,'');
			if($it618_tuan_sale['it618_score']>0)
			C::t('common_member_count')->increase($it618_tuan_sale['it618_uid'], array(
				'extcredits'.$it618_tuan_sale['it618_jfid'] => $it618_tuan_sale['it618_score'])
			);
			if($IsUnion==1)DB::query("update ".DB::table('it618_union_tuitc')." set it618_state=1 where it618_saleid=".$delid);
			it618_tuan_sendmessage('tk_user',$delid);
			$ok=$ok+1;
		}else{
			C::t('#it618_tuan#it618_tuan_sale')->update_it618_state($delid,4);
			C::t('#it618_tuan#it618_tuan_sale')->update_it618_code($delid,'');
			if($it618_tuan_sale['it618_score']>0)
			C::t('common_member_count')->increase($it618_tuan_sale['it618_uid'], array(
				'extcredits'.$it618_tuan_sale['it618_jfid'] => $it618_tuan_sale['it618_score'])
			);
			if($IsUnion==1)DB::query("update ".DB::table('it618_union_tuitc')." set it618_state=1 where it618_saleid=".$delid);
			it618_tuan_sendmessage('tk_user',$delid);
			$ok=$ok+1;
		}
		
		it618_tuan_updategoodscount($it618_tuan_sale,'tui');
	}

	cpmsg($it618_tuan_lang['s222'].$ok, "action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_fahuo')){
	$ok=0;
	if($reabc[8]!='a')return;

	$saleid=intval($_GET['saleid']);
	if($it618_tuan_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_sale')." where id=".$saleid)){
		
		if($it618_tuan_sale['it618_state']==1){
			C::t('#it618_tuan#it618_tuan_sale')->update_it618_state($delid,3);
			C::t('#it618_tuan#it618_tuan_sale')->update_it618_code($delid,'');
			cpmsg($it618_tuan_lang['s661'], "action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
		}else{
			cpmsg($it618_tuan_lang['s662'], "action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do&page=$page".$urlsql, 'error');
		}
	}else{
		cpmsg($it618_tuan_lang['s663'], "action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do&page=$page".$urlsql, 'error');
	}
}

if(count($reabc)!=10)return;

showformheader("plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_tuan_lang['s223'],'it618_tuan_sum');
	showsubmit('it618sercsubmit', $it618_tuan_lang['s25'], '<script charset="utf-8" src="source/plugin/it618_tuan/js/Calendar.js"></script>'.$it618_tuan_lang['s224'].' <input name="pname" value="'.$_GET['pname'].'" class="txt" style="width:180px" /> '.$it618_tuan_lang['s225'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_tuan_lang['s226'].' <select name="state"><option value=0 '.$state0.'>'.$it618_tuan_lang['s227'].'</option><option value=1 '.$state1.'>'.$it618_tuan_lang['s191'].'</option><option value=2 '.$state2.'>'.$it618_tuan_lang['s192'].'</option></select> '.$it618_tuan_lang['s228'].' <input name="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input name="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>');
	
	$count = C::t('#it618_tuan#it618_tuan_sale')->count_by_search(0,$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_tuan#it618_tuan_sale')->sum_money_by_search(0,$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=15>'.$it618_tuan_lang['s229'].'<font color=red>'.$count.'</font> '.$it618_tuan_lang['s230'].'<font color=red>'.$summoney.'</font><span style="float:right">'.$it618_tuan_lang['s231'].'<font color=red>'.$it618_tuan['tuan_tuidatecount'].'</font>'.$it618_tuan_lang['s232'].'</span></td></tr>';
	showsubtitle(array('', $it618_tuan_lang['s233'],$it618_tuan_lang['s235'],$it618_tuan_lang['s236'],$it618_tuan_lang['s732'],$it618_tuan_lang['s807'],$it618_tuan_lang['s239'],$it618_tuan_lang['s240'],$it618_tuan_lang['s241']));
	
	if($IsCredits==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	}
			
	foreach(C::t('#it618_tuan#it618_tuan_sale')->fetch_all_by_search(
		0,$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_tuan_sale) {
		
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
		$class1name = C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_name_by_id($it618_tuan_goods['it618_class1_id']);
		$class2name = C::t('#it618_tuan#it618_tuan_class2')->fetch_it618_name_by_id($it618_tuan_goods['it618_class2_id']);
		
		$it618_isservice='';
		if($it618_tuan_sale['it618_isservice1']==1)$it618_isservice.=$it618_tuan_lang['s107'].' ';
		if($it618_tuan_sale['it618_isservice2']==1)$it618_isservice.=$it618_tuan_lang['s108'].' ';
		if($it618_tuan_sale['it618_isservice3']==1)$it618_isservice.=$it618_tuan_lang['s109'].' ';
		
		if($it618_tuan_sale['it618_state']==1)$it618_state='<font color=red>'.$it618_tuan_lang['s191'].'</font>';
		if($it618_tuan_sale['it618_state']==2)$it618_state='<font color=blue>'.$it618_tuan_lang['s192'].'</font>';
		
		$it618_esaletime=strtotime($it618_tuan_sale['it618_esaletime'].':00');
		if($it618_tuan_sale['it618_state']==1&&$it618_tuan_sale['it618_esaletime']!=''){
			$it618_state.='<br>'.$it618_tuan_lang['s242'].' <font color=red>'.intval(($_G['timestamp']-$it618_esaletime)/3600/24).'</font>'.$it618_tuan_lang['s243'];
		}
		
		$it618_tc='';
		if($it618_tuan_sale['it618_tc']>0){
			$it618_tc=$it618_tuan_lang['s244'].$it618_tuan_sale['it618_tcbl'].'%<br>'.$it618_tuan_lang['s245'].'<font color=red>'.$it618_tuan_sale['it618_tc'].'</font>';
		}
		
		if($it618_tuan_sale['it618_saletype']==1){
			$it618_saletype='<br>'.$it618_tuan_lang['s733'];
		}else{
			$it618_isservice='';
			$it618_saletype=$it618_tuan_lang['s734'];
		}
		
		if($IsCredits==1){
			$paystr=getpaystr($it618_tuan_sale['it618_gwcid'],$it618_tuan_sale['id'],'tuan');
		}
		
		if($it618_tuan_sale['it618_price']>0&&$it618_tuan_sale['it618_score']>0){
			$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
			$moneystr=($it618_tuan_sale['it618_sfmoney']).$it618_tuan_lang['s125'].'+'.($it618_tuan_sale['it618_sfscore']).''.$jfname;
		}else{
			if($it618_tuan_sale['it618_price']>0){
				$moneystr=($it618_tuan_sale['it618_sfmoney']).$it618_tuan_lang['s125'];
			}
			
			if($it618_tuan_sale['it618_score']>0){
				$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
				$moneystr=($it618_tuan_sale['it618_sfscore']).''.$jfname;
			}
		}
			
		$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_tuan_sale[id].'" name="delete[]" value="'.$it618_tuan_sale[id].'" '.$disabled.'><label for="chk_del'.$it618_tuan_sale[id].'">'.$it618_tuan_sale['id'].'</label>',
			'<a href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_tuan_goods['it618_description'].'">'.$it618_tuan_goods['it618_name'].'</a><br>'.$it618_tuan_goods['it618_mealname'],
			$it618_tuan_sale['it618_count'],
			$moneystr,
			'<font color=green>'.$it618_isservice.'</font>'.$it618_saletype,
			$paystr,
			$it618_state,
			'<a href="'.it618_tuan_rewriteurl($it618_tuan_sale['it618_uid']).'" target="_blank">'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'</a>',
			'<div style="width:80px">'.date('Y-m-d H:i:s', $it618_tuan_sale['it618_time']).'<div>'
		));
	}

	
	function it618_tuan_classname($aid){
		return C::t('#it618_tuan#it618_tuan_class')->fetch_it618_classname_by_id($aid);
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_tuan_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_tuikuan" value="'.$it618_tuan_lang['s246'].'" onclick="return confirm(\''.$it618_tuan_lang['s247'].'\')"/> '.$it618_tuan_lang['s248'].'<br>'.$it618_tuan_lang['s664'].' <font color="red">'.$it618_tuan_lang['s665'].'</font><input type="text" name="saleid" style="width:80px"> <input type="submit" class="btn" name="it618submit_fahuo" style="color:red" value="'.$it618_tuan_lang['s666'].'" onclick="return confirm(\''.$it618_tuan_lang['s667'].'\')"/> &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>