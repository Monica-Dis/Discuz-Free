<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/

if(C::t('#it618_tuan#it618_tuan_set')->count_by_setname('wapbottomsubnav')==0){
	C::t('#it618_tuan#it618_tuan_set')->insert(array(
		'setname' => 'wapbottomsubnav',
		'setvalue' => ''
	), true);
}
if(C::t('#it618_tuan#it618_tuan_set')->count_by_setname('wapbottomsubnavdefault')==0){
	C::t('#it618_tuan#it618_tuan_set')->insert(array(
		'setname' => 'wapbottomsubnavdefault',
		'setvalue' => ''
	), true);
}

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_tuan#it618_tuan_bottomnav')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_title'])) {
		foreach($_GET['it618_title'] as $id => $val) {

			C::t('#it618_tuan#it618_tuan_bottomnav')->update($id,array(
				'it618_title' => trim($_GET['it618_title'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_curimg' => trim($_GET['it618_curimg'][$id]),
				'it618_url' => trim($_GET['it618_url'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}
	
	$it618_tuan_set=C::t('#it618_tuan#it618_tuan_set')->fetch_by_setname('wapbottomsubnav');
	C::t('#it618_tuan#it618_tuan_set')->update($it618_tuan_set['id'],array(
		'setvalue' => $_GET['wapbottomsubnav']
	));
	
	$it618_tuan_set=C::t('#it618_tuan#it618_tuan_set')->fetch_by_setname('wapbottomsubnavdefault');
	C::t('#it618_tuan#it618_tuan_set')->update($it618_tuan_set['id'],array(
		'setvalue' => $_GET['wapbottomsubnavdefault']
	));

	$newit618_title_array = !empty($_GET['newit618_title']) ? $_GET['newit618_title'] : array();
	$newit618_url_array = !empty($_GET['newit618_url']) ? $_GET['newit618_url'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_title_array as $key => $value) {
		$newit618_title = trim($newit618_title_array[$key]);
		
		if($newit618_title != '') {
			
			C::t('#it618_tuan#it618_tuan_bottomnav')->insert(array(
				'it618_title' => trim($newit618_title_array[$key]),
				'it618_url' => trim($newit618_url_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}
	
	$order=C::t('#it618_tuan#it618_tuan_bottomnav')->fetchorder_by_search();
	$order=$order+1;
	DB::query("update ".DB::table('it618_tuan_bottomnav')." set it618_order=$order WHERE id=5");
	cpmsg($it618_tuan_lang['s33'].$ok1.' '.$it618_tuan_lang['s34'].$ok2.' '.$it618_tuan_lang['s35'].$del.')',"action=plugins&identifier=$identifier&cp=admin_bottomnav&cp1=$cp1&pmod=admin_style&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return;

$wapbottomsubnav=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('wapbottomsubnavdefault');

if($wapbottomsubnavdefault==1)$wapbottomsubnavdefault_checked='checked="checked"';else $wapbottomsubnavdefault_checked="";

showformheader("plugins&identifier=$identifier&cp=admin_bottomnav&cp1=$cp1&pmod=admin_style&operation=$operation&do=$do");
showtableheaders($it618_tuan_lang['s1765'],'it618_tuan_bottomnav');
	$count = C::t('#it618_tuan#it618_tuan_bottomnav')->count_by_search();
	
	echo '<tr><td colspan=8>'.$it618_tuan_lang['s976'].$count.'<span style="float:right;color:red">'.$it618_tuan_lang['s977'].'</span></td></tr>';
	showsubtitle(array('', $it618_tuan_lang['s978'], $it618_tuan_lang['s1959'], $it618_tuan_lang['s979'], $it618_tuan_lang['s980'],$it618_tuan_lang['s1958'],$it618_tuan_lang['s984']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_bottomnav')." ORDER BY it618_order");
	while($it618_tuan_bottomnav = DB::fetch($query)) {
		
		$disabled='';
		$it618_url="<input type=\"text\" class=\"txt\" style=\"width:400px\" name=\"it618_url[$it618_tuan_bottomnav[id]]\" value=\"$it618_tuan_bottomnav[it618_url]\">";
		$it618_order='<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_tuan_bottomnav['id'].']" value="'.$it618_tuan_bottomnav['it618_order'].'">';
		
		if($it618_tuan_bottomnav['id']==1){
			$disabled='disabled="disabled"';
			$it618_url='<input type="hidden" name="it618_url['.$it618_tuan_bottomnav['id'].']" value=""><input class="checkbox" type="checkbox" id="wapbottomsubnavdefault" name="wapbottomsubnavdefault" '.$wapbottomsubnavdefault_checked.' value="1"><label for="wapbottomsubnavdefault">'.$it618_tuan_lang['s654'].'</label><br><textarea name="wapbottomsubnav" style="width:400px;height:80px;margin-bottom:3px">'.$wapbottomsubnav.'</textarea><br>'.$it618_tuan_lang['s816'];
		}
		
		if($it618_tuan_bottomnav['id']==5){
			$disabled='disabled="disabled"';
			$it618_url='<input type="hidden" name="it618_url['.$it618_tuan_bottomnav['id'].']" value="">';
			$it618_order='<input type="hidden" name="it618_order['.$it618_tuan_bottomnav['id'].']" value="'.$it618_tuan_bottomnav['it618_order'].'">'.$it618_tuan_bottomnav['it618_order'];
		}
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_tuan_bottomnav[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_tuan_bottomnav[id]]\" value=\"$it618_tuan_bottomnav[id]\">",
			'<img src="'.$it618_tuan_bottomnav['it618_img'].'" id="img'.$it618_tuan_bottomnav['id'].'" width="42" height="42" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" style="width:50px" id="url'.$it618_tuan_bottomnav['id'].'" name="it618_img['.$it618_tuan_bottomnav['id'].']" readonly="readonly" value="'.$it618_tuan_bottomnav['it618_img'].'" /> <input type="button" id="image'.$it618_tuan_bottomnav['id'].'" value="'.$it618_tuan_lang['s67'].'" />',
			'<img src="'.$it618_tuan_bottomnav['it618_curimg'].'" id="curimg'.$it618_tuan_bottomnav['id'].'" width="42" height="42" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" style="width:50px" id="cururl'.$it618_tuan_bottomnav['id'].'" name="it618_curimg['.$it618_tuan_bottomnav['id'].']" readonly="readonly" value="'.$it618_tuan_bottomnav['it618_curimg'].'" /> <input type="button" id="curimage'.$it618_tuan_bottomnav['id'].'" value="'.$it618_tuan_lang['s67'].'" />',
			"<input type=\"text\" class=\"txt\" style=\"width:60px\" name=\"it618_title[$it618_tuan_bottomnav[id]]\" value=\"$it618_tuan_bottomnav[it618_title]\">",
			$it618_url,
			"<input id=\"c".$it618_tuan_bottomnav['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_tuan_bottomnav[id]]\" value=\"$it618_tuan_bottomnav[it618_color]\" onchange=\"updatecolorpreview('c".$it618_tuan_bottomnav['id']."')\"><input id=\"c".$it618_tuan_bottomnav['id']."\" onclick=\"c".$it618_tuan_bottomnav['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_tuan_bottomnav['id']."|c".$it618_tuan_bottomnav['id']."_v';showMenu({'ctrlid':'c".$it618_tuan_bottomnav['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_tuan_bottomnav['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_tuan_bottomnav['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			$it618_order,
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_tuan_bottomnav['id']."');";
		$editorjs.='K(\'#image'.$it618_tuan_bottomnav['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_tuan_bottomnav['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_tuan_bottomnav['id'].'\').val(url);
								K(\'#img'.$it618_tuan_bottomnav['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});
				K(\'#curimage'.$it618_tuan_bottomnav['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#cururl'.$it618_tuan_bottomnav['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#cururl'.$it618_tuan_bottomnav['id'].'\').val(url);
								K(\'#curimg'.$it618_tuan_bottomnav['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});
				';
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo '
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_tuan/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_tuan/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
	$it618_tuan_lang184=$it618_tuan_lang['s68'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_title[]").length;
	
		return [
		[[1,''], [1, '$it618_tuan_lang184'], [1, '$it618_tuan_lang184'], [1,'<input type="text" class="txt" style=\"width:60px\" name="newit618_title[]">'], [1,'<input type="text" class="txt" style=\"width:400px\" name="newit618_url[]">'], [1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1, ' <input class="txt" type="text" style="width:30px" name="newit618_order[]" value="1">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a><span style="float:right">'.$it618_tuan_lang['s1766'].'</span></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>