<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/

$it618sql='it618_uid>0';
if($_GET['state']) {
	$state0='';$state1='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$it618sql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$it618sql .= " AND it618_state = 0";$state1='selected="selected"';}
	if($_GET['state']==2){$it618sql .= " AND it618_state = 1";$state2='selected="selected"';}
	if($_GET['state']==3){$it618sql .= " AND it618_state = 2";$state3='selected="selected"';}
}

if($_GET['htstate']) {
	$htstate0='';$htstate1='';$htstate2='';$htstate3='';$htstate4='';
	if($_GET['htstate']==0){$it618sql .= "";$htstate0='selected="selected"';}
	if($_GET['htstate']==1){$it618sql .= " AND it618_htstate = 0";$htstate1='selected="selected"';}
	if($_GET['htstate']==2){$it618sql .= " AND it618_htstate = 1";$htstate2='selected="selected"';}
	if($_GET['htstate']==3){$it618sql .= " AND it618_htstate = 2";$htstate3='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&findareaid='.intval($_GET['findareaid']).'&finduid='.$_GET['finduid'].'&state='.$_GET['state'].'&htstate='.$_GET['htstate'];

foreach(C::t('#it618_tuan#it618_tuan_shop')->fetch_all_by_search("it618_htstate<>0 and it618_uid>0") as $it618_tuan_shop) {
	if($_G['timestamp']>=$it618_tuan_shop['it618_htetime']){
		C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($it618_tuan_shop['id'],2);
	}else{
		C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($it618_tuan_shop['id'],1);
	}
}

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[6]!='t')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($delid);
		if($it618_tuan_shop['it618_state']!=2){
			
			C::t('#it618_tuan#it618_tuan_shop')->delete_by_id($delid);
			$del=$del+1;
		}else{
			$flag=1;
		}
	}
	
	if($flag==1)$tmpstr='<br><br>'.$it618_tuan_lang['s1774'];

	cpmsg($it618_tuan_lang['s153'].$del.$tmpstr, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($delid);
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$it618_htetime=mktime(0, 0, 0, $tomonth+$it618_tuan['tuan_httimecount'], $todate, $toyear);
		
		if($it618_tuan_shop['it618_state']==0){
			C::t('#it618_tuan#it618_tuan_shop')->update_pass_by_id($delid,$it618_htetime);
			$ok=$ok+1;
		}
	}
	cpmsg($it618_tuan_lang['s154'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if($reabc[9]!='n')return;
	
	if(is_array($_GET['it618_area1_id'])) {
		foreach($_GET['it618_area1_id'] as $id => $val) {
		
			C::t('#it618_tuan#it618_tuan_shop')->update($id,array(
				'it618_area1_id' => $_GET['it618_area1_id'][$id],
				'it618_area2_id' => $_GET['it618_area2_id'][$id],
				'it618_isgoods' => $_GET['it618_isgoods'][$id],
				'it618_islive' => $_GET['it618_islive'][$id],
				'it618_price' => $_GET['it618_price'][$id],
				'it618_score' => $_GET['it618_score'][$id],
				'it618_tcbl' => $_GET['it618_tcbl'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s155'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_zhuan')){
	$ok=0;
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$zhuanuid=intval($_GET['zhuanuid']);
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$zhuanuid)==0){
			cpmsg($it618_tuan_lang['s156'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'error');
		}else{
			if(DB::result_first("select count(1) from ".DB::table('it618_tuan_shop')." where it618_uid=".$zhuanuid)>0){
				cpmsg($it618_tuan_lang['s157'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'error');
			}
		}
		
		$it618_tuan_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_shop')." where id=".$delid);
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$zhuanuid);
		
		C::t('#it618_tuan#it618_tuan_shop')->update_it618_uid_by_id($delid,$zhuanuid);
		cpmsg($it618_tuan_lang['s158'].$it618_tuan_shop['it618_name'].$it618_tuan_lang['s159'].$username.' '.$it618_tuan_lang['s37'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
		break;
	}
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($delid);
		
		if($it618_tuan_shop['it618_state']==0){
			C::t('#it618_tuan#it618_tuan_shop')->update_it618_state_by_id($delid,1);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s160'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_editht')){
	$ok=0;
	if($reabc[8]!='a')return;
	$time=mktime(0, 0, 0, $_GET['sel_month'], $_GET['sel_date'], $_GET['sel_year']);
	if($_G['timestamp']>=$time){
		cpmsg($it618_tuan_lang['s161'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
	}
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($delid);
		
		if($it618_tuan_shop['it618_state']==2){
			$isviptbtime=0;
			if($IsGroup==1){
				if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('tuan',0)){
					if($it618_group_rzmoney['it618_istbtime']==1){
						$isviptbtime=1;
					}
				}
			}
			if($isviptbtime==0){
				C::t('#it618_tuan#it618_tuan_shop')->update_it618_htetime_by_id($delid,$time);
				if($_G['timestamp']>=$time){
					C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($delid,2);
				}else{
					C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($delid,1);
				}
				$ok=$ok+1;
			}
		}
	}

	cpmsg($it618_tuan_lang['s162'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_clock')){
	$ok=0;
	if($reabc[8]!='a')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($delid);
		
		if($it618_tuan_shop['it618_state']==2){
			C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($delid,0);
			C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s163'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_unclock')){
	$ok=0;
	if($reabc[8]!='a')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($delid);
		
		if($it618_tuan_shop['it618_state']==2){
			C::t('#it618_tuan#it618_tuan_shop')->update_it618_htstate_by_id($delid,1);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_tuan_lang['s164'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(count($reabc)!=10)return;

foreach(C::t('#it618_tuan#it618_tuan_area1')->fetch_all_by_search() as $it618_tmp) {
	$areatmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}
$areatmp=str_replace('<option value='.$_GET['findareaid'].'>','<option value='.$_GET['findareaid'].' selected="selected">',$areatmp1);

echo '
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
';

showformheader("plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1".$sql);
showtableheaders($strtmptitle[$cp1].'<span style="float:right">'.$it618_tuan_lang['s1856'].'</span>','it618_store_renzheng');
	showsubmit('it618sercsubmit', $it618_tuan_lang['s25'], $it618_tuan_lang['s166'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:100px" /> '.$it618_tuan_lang['s167'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_tuan_lang['s168'].' <select name="findareaid"><option value=0>'.$it618_tuan_lang['s169'].'</option>'.$areatmp.'</select> '.$it618_tuan_lang['s170'].' <select name="state"><option value=0 '.$state0.'>'.$it618_tuan_lang['s169'].'</option><option value=1 '.$state1.'>'.$it618_tuan_lang['s171'].'</option><option value=2 '.$state2.'>'.$it618_tuan_lang['s172'].'</option><option value=3 '.$state3.'>'.$it618_tuan_lang['s173'].'</option></select> '.$it618_tuan_lang['s174'].' <select name="htstate"><option value=0 '.$htstate0.'>'.$it618_tuan_lang['s169'].'</option><option value=1 '.$htstate1.'>'.$it618_tuan_lang['s175'].'</option><option value=2 '.$htstate2.'>'.$it618_tuan_lang['s176'].'</option><option value=3 '.$htstate3.'>'.$it618_tuan_lang['s177'].'</option></select>');
	
	$count = C::t('#it618_tuan#it618_tuan_shop')->count_by_search($it618sql,'',$_GET['key'],$_GET['findareaid'],0,$_GET['finduid']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1".$sql);
	
	echo '<tr><td colspan=14>'.$it618_tuan_lang['s178'].$count.'<span style="float:right;color:red">'.$it618_tuan_lang['s809'].'</span></td></tr>';
	showsubtitle(array('', $it618_tuan_lang['s179'],$it618_tuan_lang['s180'],$it618_tuan_lang['s181'],$it618_tuan_lang['s182'],$it618_tuan_lang['s183'],$it618_tuan_lang['s184'],$it618_tuan_lang['s185']));
	
	foreach(C::t('#it618_tuan#it618_tuan_shop')->fetch_all_by_search(
		$it618sql,'id DESC',$_GET['key'],$_GET['findareaid'],0,$_GET['finduid'],$startlimit,$ppp
	) as $it618_tuan_shop) {
		
		$username=C::t('#it618_tuan#it618_tuan_sale')->fetch_username_by_uid($it618_tuan_shop['it618_uid']);
		
		$salecountstr='';$salemoneystr='';
		if($it618_tuan_shop['it618_state']==2){
			$pcount1=C::t('#it618_tuan#it618_tuan_goods')->count_by_shopid_state($it618_tuan_shop['id'],0);
			$pcount2=C::t('#it618_tuan#it618_tuan_goods')->count_by_shopid_state($it618_tuan_shop['id'],1);
			$pcount3=C::t('#it618_tuan#it618_tuan_goods')->count_by_shopid_state($it618_tuan_shop['id'],2);
			$statename[1]=$it618_tuan_lang['s191'];$statename[2]='<br>'.$it618_tuan_lang['s192'];$statename[3]='<br>'.$it618_tuan_lang['s193'];$statename[4]='<br>'.$it618_tuan_lang['s194'];$statename[5]='<br>'.$it618_tuan_lang['s195'];
			for($i=1;$i<=5;$i++){
				$salecount=C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_shopid_state($it618_tuan_shop['id'],$i);
				$salecountstr.=$statename[$i].'(<font color=red>'.$salecount.'</font>)';
				
				$salemoney=C::t('#it618_tuan#it618_tuan_sale')->summoney_by_shopid_state($it618_tuan_shop['id'],$i);
				$salemoneystr.=$statename[$i].'(<font color=red>'.$salemoney.'</font>)';
			}
			
			$tcmoney=C::t('#it618_tuan#it618_tuan_sale')->summoney_by_shopid($it618_tuan_shop['id']);
			$ktxmoney=C::t('#it618_tuan#it618_tuan_shop')->fetch_money_by_id($it618_tuan_shop['id']);
			$sqmoney=C::t('#it618_tuan#it618_tuan_tx')->sumtxmoney_by_shopid_state($it618_tuan_shop['id'],1);
			$txmoney=C::t('#it618_tuan#it618_tuan_tx')->sumtxmoney_by_shopid_state($it618_tuan_shop['id'],2);
			if($sqmoney=='')$sqmoney='0.00';
			if($txmoney=='')$txmoney='0.00';else $txmoney=round($txmoney,2);
			$txtc=C::t('#it618_tuan#it618_tuan_tx')->sumtxtc_by_shopid($it618_tuan_shop['id']);
		}
		
		if($salesum=="")$salesum=0;
		
		if($it618_tuan_shop['it618_state']==0)$it618_state='<font color=red>'.$it618_tuan_lang['s171'].'</font>';
		if($it618_tuan_shop['it618_state']==1)$it618_state='<font color=blue>'.$it618_tuan_lang['s172'].'</font>';
		if($it618_tuan_shop['it618_state']==2)$it618_state='<font color=green>'.$it618_tuan_lang['s173'].'</font>';
		
		if($it618_tuan_shop['it618_state']==2){
			if($it618_tuan_shop['it618_htstate']==0)$it618_htstate='<font color=red>'.$it618_tuan_lang['s175'].'</font>';
			if($it618_tuan_shop['it618_htstate']==1)$it618_htstate='<font color=green>'.$it618_tuan_lang['s176'].'</font>';
			if($it618_tuan_shop['it618_htstate']==2)$it618_htstate='<font color=#ccc>'.$it618_tuan_lang['s177'].'</font>';
			$httime=date('Y-m-d', $it618_tuan_shop['it618_htetime']);
			
			if($IsGroup==1){
				if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('tuan',0)){
					if($it618_group_rzmoney['it618_istbtime']==1){
						if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$it618_tuan_shop['it618_uid'])){
							$httime='VIP:'.date('Y-m-d', $it618_group_group_user['it618_etime']);
						}else{
							$httime='VIP:'.$it618_tuan_lang['s937'];
						}
					}
				}
			}
		}else{
			$it618_htstate='';	
			$httime='';
		}
		
		foreach(C::t('#it618_tuan#it618_tuan_area2')->fetch_all_by_it618_area1_id($it618_tuan_shop['it618_area1_id']) as $it618_tmp) {
			$areatmp2.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
		}
		$areatmp1=str_replace('<option value='.$it618_tuan_shop['it618_area1_id'].'>','<option value='.$it618_tuan_shop['it618_area1_id'].' selected="selected">',$areatmp1);
		$areatmp2=str_replace('<option value='.$it618_tuan_shop['it618_area2_id'].'>','<option value='.$it618_tuan_shop['it618_area2_id'].' selected="selected">',$areatmp2);
		
		if($it618_tuan_shop['it618_isgoods']==1)$it618_isgoods_checked='checked="checked"';else $it618_isgoods_checked="";
		if($it618_tuan_shop['it618_islive']==1)$it618_islive_checked='checked="checked"';else $it618_islive_checked="";
		
		$goodscount = $pcount1+$pcount2+$pcount3;
		
		$creditnum=C::t('#it618_tuan#it618_tuan_sale')->fetch_extcredits_by_uid($it618_tuan['tuan_credit'],$it618_tuan_shop['it618_uid']);
		if($creditnum=="")$creditnum=0;
		
		$it618_logo='';
		if($it618_tuan_shop['it618_logo']!='')$it618_logo='src="'.$it618_tuan_shop['it618_logo'].'"';
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_tuan_shop[id].'" name="delete[]" value="'.$it618_tuan_shop[id].'" '.$disabled.'><input type="hidden" name="id['.$it618_tuan_shop[id].']" value="'.$it618_tuan_shop[id].'"><label for="chk_del'.$it618_tuan_shop[id].'">'.$it618_tuan_shop['id'].'</label>',
			'<img '.$it618_logo.' width=105 height=75 style="float:left;"><div style="float:left;width:430px;margin-left:3px;line-height:17px"><span style="font-size:13px;color:#666"><strong>'.$it618_tuan_shop['it618_name'].'</strong></span> <a href="javascript:" id="liyou'.$it618_tuan_shop[id].'">'.$it618_tuan_lang['s186'].'</a><br>'.'<select onchange="redirec_area(this.options.selectedIndex,'.$it618_tuan_shop[id].')" name="it618_area1_id['.$it618_tuan_shop['id'].']">'.$areatmp1.'</select><select id="it618_area_'.$it618_tuan_shop['id'].'" name="it618_area2_id['.$it618_tuan_shop['id'].']">'.$areatmp2.'</select> '.$it618_state.' '.$it618_tuan_lang['s1083'].'<input class="txt" style="width:50px;margin-right:3px;color:green;font-weight:bold" type="text" name="it618_score['.$it618_tuan_shop['id'].']" value="'.$it618_tuan_shop['it618_score'].'">/<font color=red>'.$creditnum.'</font>'.$creditname.'<br>'.$it618_tuan_lang['s188'].'<a href="home.php?mod=space&uid='.$it618_tuan_shop['it618_uid'].'" target="_blank">'.$username.'</a> '.$it618_tuan_lang['s189'].$httime.' '.$it618_tuan_lang['s190'].$it618_htstate.'<br><span style="display:none">'.$it618_tuan_lang['s940'].'<input class="txt" style="width:80px;margin-right:3px;color:blue;font-weight:bold" type="text" name="it618_price['.$it618_tuan_shop['id'].']" value="'.$it618_tuan_shop['it618_price'].'">'.$it618_tuan_lang['s941'].' </span><input class="checkbox" type="checkbox" id="it618_isgoods['.$it618_tuan_shop['id'].']" name="it618_isgoods['.$it618_tuan_shop['id'].']" '.$it618_isgoods_checked.' value="1"><label for="it618_isgoods['.$it618_tuan_shop['id'].']"><font color="red"><b>'.$it618_tuan_lang['s810'].'</b></font></label> <input class="checkbox" type="checkbox" id="it618_islive['.$it618_tuan_shop['id'].']" name="it618_islive['.$it618_tuan_shop['id'].']" '.$it618_islive_checked.' value="1"><label for="it618_islive['.$it618_tuan_shop['id'].']">'.$it618_tuan_lang['s1153'].'</label></div>',
			$it618_tuan_lang['s103'].'(<font color=red>'.$pcount1.'</font>)<br>'.$it618_tuan_lang['s104'].'(<font color=red>'.$pcount2.'</font>)<br>'.$it618_tuan_lang['s105'].'(<font color=red>'.$pcount3.'</font>)',
			$salecountstr,
			$salemoneystr,
			'<input class="txt" style="width:40px;margin-right:0;color:green;font-weight:bold" type="text" name="it618_tcbl['.$it618_tuan_shop['id'].']" value="'.$it618_tuan_shop['it618_tcbl'].'">%',
			'<font color=red>'.$tcmoney.'</font>',
			$it618_tuan_lang['s196'].'(<font color=red>'.$ktxmoney.'</font>)<br>'.$it618_tuan_lang['s197'].'(<font color=red>'.$sqmoney.'</font>)<br>'.$it618_tuan_lang['s198'].'(<font color=red>'.$txmoney.'</font>)<br>'.$it618_tuan_lang['s199'].'(<font color=red>'.round($txtc,2).'</font>)'
		));
		
		$morecontent=$it618_tuan_lang['s200'];
		$morecontent=str_replace("{name}",$it618_tuan_shop['it618_name'],$morecontent);
		$morecontent=str_replace("{tel}",$it618_tuan_shop['it618_tel'],$morecontent);
		$morecontent=str_replace("{qq}",$it618_tuan_shop['it618_qq'],$morecontent);
		$morecontent=str_replace("{addr}",$it618_tuan_shop['it618_addr'],$morecontent);
		$morecontent=str_replace("{liyou}",$it618_tuan_shop['it618_liyou'],$morecontent);
		$morecontent=str_replace("{time}",date('Y-m-d H:i:s', $it618_tuan_shop['it618_time']),$morecontent);
		
		$morecontent=str_replace("'","\"",$morecontent);
		$morecontent=str_replace(array("\r\n", "\r", "\n"),"",$morecontent);
		$tmpjs.='KindEditor.ready(function(K) {K(\'#liyou'.$it618_tuan_shop[id].'\').click(function() {
			var dialog = K.dialog({
				width : 500,
				height : 300,
				title : \''.$it618_tuan_lang['s288'].'\',
				body : \'<div style="margin:10px;">'.$morecontent.'</div>\',
				closeBtn : {
					name : \''.$it618_tuan_lang['s289'].'\',
					click : function(e) {
						dialog.remove();
					}
				},
				noBtn : {
					name : \''.$it618_tuan_lang['s289'].'\',
					click : function(e) {
						dialog.remove();
					}
				}
			});
		});});';
		
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_area1'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_area1')." ORDER BY it618_order");
	$n1=0;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$n2=0;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_area2')." where it618_area1_id=".$it618_tmp1['id']." ORDER BY it618_order");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp1.='select_area['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_name'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
	
	echo '
	<script>
	var arrcount='.$count.';
	var select_area = new Array(arrcount);
	
	for (i=0; i<arrcount; i++) 
	{
	 select_area[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_area(x,n)
	{
	 var temp = document.getElementById("it618_area_"+n); 
	 temp.options.length=0;
	 for (i=0;i<select_area[x].length;i++)
	 {
	  temp.options[i]=new Option(select_area[x][i].text,select_area[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	</script>';
	
	$tmptime=date('Y-m-d H:i:s', $_G['timestamp']);
	$timearr=explode(" ",$tmptime);
	$timearr1=explode("-",$timearr[0]);
	$timearr2=explode(":",$timearr[1]);
	//
	$strtmp="";
	for($i=2013;$i<=2050;$i++){
		if($timearr1[0]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_year='<select name="sel_year">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=12;$i++){
		if($timearr1[1]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_month='<select name="sel_month">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=31;$i++){
		if($timearr1[2]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_date='<select name="sel_date">'.$strtmp.'</select>';
	
	function towstr($i){
		if(strlen($i)==1)return "0".$i;else return $i;
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_tuan_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_tuan_lang['s201'].'" onclick="return confirm(\''.$it618_tuan_lang['s202'].'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_tuan_lang['s203'].'"/> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_tuan_lang['s204'].'" onclick="return confirm(\''.$it618_tuan_lang['s205'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_tuan_lang['s206'].'" onclick="return confirm(\''.$it618_tuan_lang['s207'].'\')"/> '.$it618_tuan_lang['s208'].' '.$sel_year.$sel_month.$sel_date.'<input type="submit" class="btn" name="it618submit_editht" value="'.$it618_tuan_lang['s209'].'" onclick="return confirm(\''.$it618_tuan_lang['s210'].'\')"/> <input type="submit" class="btn" name="it618submit_clock" value="'.$it618_tuan_lang['s211'].'" onclick="return confirm(\''.$it618_tuan_lang['s212'].'\')"/> <input type="submit" class="btn" name="it618submit_unclock" value="'.$it618_tuan_lang['s213'].'" onclick="return confirm(\''.$it618_tuan_lang['s214'].'\')"/> <font color=red>'.$it618_tuan_lang['s215'].'</font><br>'.$it618_tuan_lang['s216'].'<input type="test" id="zhuanuid" name="zhuanuid" style="width:50px"> <input type="submit" class="btn" name="it618submit_zhuan" value="'.$it618_tuan_lang['s217'].'" onclick="return checkone()"  /><br>'.$it618_tuan_lang['s1154'].' &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
echo '<script>'.$tmpjs.'</script>';
echo  '<script>
		function checkone(){
		var inputs = document.getElementsByName("delete[]");
		var checked_counts = 0;
		for(var i=0;i<inputs.length;i++){
			if(inputs[i].checked){
				checked_counts++;
			}
		}
		if(checked_counts==0){
			alert("'.$it618_tuan_lang['s218'].'");
			return false;
		}
		if(checked_counts>1){
			alert("'.$it618_tuan_lang['s219'].'");
			return false;
		}
		if(document.getElementById("zhuanuid").value==""){
			alert("'.$it618_tuan_lang['s220'].'");
			return false;
		}
		return confirm(\''.$it618_tuan_lang['s221'].'\');
		}
		</script>';
?>