<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/
$n=1;
foreach(C::t('#it618_tuan#it618_tuan_shop')->fetch_all_by_isgoodsnot() as $it618_tmp) {
	if(isset($_GET['shopid'])){
		if($_GET['shopid']==$it618_tmp['id']){
			$licss='class="current"';
			$shopid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}else{
		if($n==1){
			$licss='class="current"';
			$shopid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_meal')." w WHERE it618_shopid=".$it618_tmp['id']);
	
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shopproduct_meal&cp1=$cp1&pmod=admin_product&shopid=".$it618_tmp['id']."&operation=$operation&do=$do&page=$page\"><span>".$it618_tmp['it618_name'].'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$n=$n+1;
}
if($n==1){
	cpmsg($it618_tuan_lang['s942'].')', "action=plugins&identifier=$identifier&cp=admin_shopproduct_meal&cp1=$cp1&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'error');
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';

$extrasql .= "it618_shopid =".$shopid;
$urlsql='&shopid='.$shopid;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_tuan_meal', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_tuan#it618_tuan_meal')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_shopid_array = !empty($_GET['newit618_shopid']) ? $_GET['newit618_shopid'] : array();
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			C::t('#it618_tuan#it618_tuan_meal')->insert(array(
				'it618_shopid' => $_GET['shopid'],
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_tuan_lang['s33'].$ok1.' '.$it618_tuan_lang['s34'].$ok2.' '.$it618_tuan_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_shopproduct_meal&cp1=$cp1&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return;


showformheader("plugins&identifier=$identifier&cp=admin_shopproduct_meal&cp1=$cp1&pmod=admin_product&operation=$operation&do=$do".$urlsql);
showtableheaders($strtmptitle[$cp1],'it618_tuan_meal');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_meal')." WHERE $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shopproduct_meal&cp1=$cp1&pmod=admin_product&operation=$operation&do=$do");
	
	echo '<tr><td colspan=15>'.$it618_tuan_lang['s825'].$count.'</td></tr>';
	showsubtitle(array('', $it618_tuan_lang['s826'],$it618_tuan_lang['s827'], $it618_tuan_lang['s828']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_meal')." WHERE $extrasql ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_tuan = DB::fetch($query)) {

		$goodscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods')." WHERE it618_meal_id=".$it618_tuan['id']);
		$disabled="";
		if($goodscount>0)$disabled="disabled=\"disabled\"";
		
		$tmp1=str_replace('<option value='.$it618_tuan['it618_shopid'].'>','<option value='.$it618_tuan['it618_shopid'].' selected="selected">',$tmp);
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_tuan[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_tuan[id]]\" value=\"$it618_tuan[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_tuan[id]]\" value=\"$it618_tuan[it618_name]\">",
			'<input class="txt" type="text" name="it618_order['.$it618_tuan['id'].']" value="'.$it618_tuan['it618_order'].'">',
			$goodscount
		));
	}
	
	global $_G;
if($reabc[4]!='8')return; /*Dism��taobao��com*/

	loadcache('plugin');
	$it618_tuan = $_G['cache']['plugin']['it618_tuan'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:200px" name="newit618_name[]">'],
		[1,'<input class="txt" type="text" name="newit618_order[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>