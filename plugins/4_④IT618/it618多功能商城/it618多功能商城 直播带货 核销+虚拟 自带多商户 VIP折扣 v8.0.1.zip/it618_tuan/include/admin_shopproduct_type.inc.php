<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$pid=intval($_GET['pid']);
$preurl=$_GET['preurl'];
$preurl1=$_GET['preurl1'];
$urlsql='&pid='.$pid;
$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid);
$it618_price = DB::result_first("SELECT it618_price FROM ".DB::table('it618_tuan_shop')." WHERE id=".$it618_tuan_goods['it618_shopid']);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_tuan_goods_type', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			if(trim($_GET['it618_saleprice'][$id])>$it618_price){
				$it618_saleprice=trim($_GET['it618_saleprice'][$id]);
			}else{
				$it618_saleprice=$it618_price;
			}
			
			$it618_score=$_GET['it618_score'][$id];
			if($_GET['it618_jfid'][$id]==0)$it618_score=0;
			
			$it618_ison=$_GET['it618_ison'][$id];
			if($it618_saleprice==0&&$it618_score==0)$it618_ison=0;

			C::t('#it618_tuan#it618_tuan_goods_type')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_name1' => trim($_GET['it618_name1'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
				'it618_order1' => trim($_GET['it618_order1'][$id]),
				'it618_saleprice' => $it618_saleprice,
				'it618_price' => trim($_GET['it618_price'][$id]),
				'it618_jfid' => trim($_GET['it618_jfid'][$id]),
				'it618_score' => $it618_score,
				'it618_ison' => $it618_ison
			));
			
			if($it618_tuan_goods['it618_saletype']!=3){
				C::t('#it618_tuan#it618_tuan_goods_type')->update($id,array(
					'it618_count' => trim($_GET['it618_count'][$id])
				));
			}
			
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_name1_array = !empty($_GET['newit618_name1']) ? $_GET['newit618_name1'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	$newit618_order1_array = !empty($_GET['newit618_order1']) ? $_GET['newit618_order1'] : array();
	$newit618_count_array = !empty($_GET['newit618_count']) ? $_GET['newit618_count'] : array();
	$newit618_saleprice_array = !empty($_GET['newit618_saleprice']) ? $_GET['newit618_saleprice'] : array();
	$newit618_price_array = !empty($_GET['newit618_price']) ? $_GET['newit618_price'] : array();
	$newit618_jfid_array = !empty($_GET['newit618_jfid']) ? $_GET['newit618_jfid'] : array();
	$newit618_score_array = !empty($_GET['newit618_score']) ? $_GET['newit618_score'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			if(trim($newit618_saleprice_array[$key])>$it618_price){
				$it618_saleprice=trim($newit618_saleprice_array[$key]);
			}else{
				$it618_saleprice=$it618_price;
			}
			                                        
			C::t('#it618_tuan#it618_tuan_goods_type')->insert(array(
				'it618_pid' => $pid,
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_name1' => trim($newit618_name1_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
				'it618_order1' => trim($newit618_order1_array[$key]),
				'it618_count' => trim($newit618_count_array[$key]),
				'it618_saleprice' => $it618_saleprice,
				'it618_price' => trim($newit618_price_array[$key]),
				'it618_jfid' => trim($newit618_jfid_array[$key]),
				'it618_score' => trim($newit618_score_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}
	
	$count=C::t('#it618_tuan#it618_tuan_goods_type')->count_by_pid_ok_isname1($pid);
	if($count>0){
		$it618_tuan_goods_types=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name_by_it618_pid1($pid);
	}else{
		$it618_tuan_goods_types=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name_by_it618_pid($pid);
	}
	
	foreach($it618_tuan_goods_types as $it618_tuan_goods_typetmp) {
		$goodstypename=$it618_tuan_goods_typetmp['it618_name'];
		break;
	}
	
	foreach(C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name1_by_it618_pid_name($pid,$goodstypename) as $it618_tuan_goods_typetmp) {
		$goodstypename1=$it618_tuan_goods_typetmp['it618_name1'];
		break;
	}
	
	$it618_tuan_goods_typetmp=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_pid_name_name1_ok($pid,$goodstypename,$goodstypename1);
	C::t('#it618_tuan#it618_tuan_goods')->update($pid,array(
		'it618_saleprice' => $it618_tuan_goods_typetmp['it618_saleprice'],
		'it618_price' => $it618_tuan_goods_typetmp['it618_price'],
		'it618_jfid' => $it618_tuan_goods_typetmp['it618_jfid'],
		'it618_score' => $it618_tuan_goods_typetmp['it618_score']
	));
	
	$it618_count=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_count_by_pid($pid);       
	C::t('#it618_tuan#it618_tuan_goods')->update($pid,array(
		'it618_ptypename' => $_GET['it618_ptypename'],
		'it618_ptypename1' => $_GET['it618_ptypename1'],
		'it618_count' => $it618_count
	));

	cpmsg($it618_tuan_lang['s33'].$ok1.' '.$it618_tuan_lang['s34'].$ok2.' '.$it618_tuan_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_shopproduct_type&cp1=$cp1&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_shopproduct_type&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&pid=$pid&preurl=$preurl");
$preurltmp=str_replace("@","&",$preurl);
showtableheaders('<a href="'.ADMINSCRIPT.'?'.$preurltmp.'"><font color=red>'.$it618_tuan_goods['it618_name'].'</font></a> '.$strtmptitle[$cp1],'admin_shopproduct_type');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_type')." WHERE it618_pid=".$pid);

echo '<tr><td colspan=15>'.$it618_tuan_lang['s1691'].'<input class="txt" type="text" name="it618_ptypename" style="width:100px" value="'.$it618_tuan_goods['it618_ptypename'].'"> '.$it618_tuan_lang['s987'].'<input class="txt" type="text" name="it618_ptypename1" style="width:100px" value="'.$it618_tuan_goods['it618_ptypename1'].'"> '.$it618_tuan_lang['s1692'].'</td></tr>';
echo '<tr><td colspan=15>'.$it618_tuan_lang['s1686'].$count.'<span style="float:right;color:red">'.$it618_tuan_lang['s1693'].'</span></td></tr>';

showsubtitle(array('', $it618_tuan_lang['s1687'],$it618_tuan_lang['s123'],$it618_tuan_lang['s1786'],$it618_tuan_lang['s123'], $it618_tuan_lang['s1688'], $it618_tuan_lang['s1689'], $it618_tuan_lang['t148'], $it618_tuan_lang['s1694'], $it618_tuan_lang['s1690']));

$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods_type')." WHERE it618_pid=".$pid." ORDER BY it618_order,it618_name,it618_order1,it618_name1");
while($it618_tuan_goods_type = DB::fetch($query)) {

	$salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_gtypeid($it618_tuan_goods_type['id']);
	$disabled="";$readonly="";$bgcolor="";
	if($salecount>0){$disabled="disabled=\"disabled\"";$readonly="readonly";$bgcolor=";background-color:#e8e8e8";}
	if($it618_tuan_goods_type['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
	
	if($it618_tuan_goods['it618_saletype']==3){
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_type_km')." WHERE it618_gtypeid=".$it618_tuan_goods_type['id']);
		
		$preurl1="action=plugins&identifier=$identifier&cp=admin_shopproduct_type&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&pid=".$it618_tuan_goods['id'];
		$preurl1=str_replace("&","@",$preurl1);
		
		$saletypestr='<a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_shopproduct_km&pmod=admin_product&cp1=11&pid='.$it618_tuan_goods[id].'&gtypeid='.$it618_tuan_goods_type[id].'&preurl='.$preurl.'&preurl1='.$preurl1.'">'.it618_tuan_getlang('s837').'(<font color=red>'.$kmcount.'</font>)</a>';
	}else{
		$saletypestr="<input type=\"text\" class=\"txt\" style=\"width:60px\" name=\"it618_count[$it618_tuan_goods_type[id]]\" value=\"$it618_tuan_goods_type[it618_count]\">";
	}
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_tuan_goods_type['id'].'" name="delete[]" value="'.$it618_tuan_goods_type['id'].'" '.$disabled.'><label for="chk_del'.$it618_tuan_goods_type['id'].'">'.$it618_tuan_goods_type['id'].'</label>',
		"<input type=\"text\" class=\"txt\" style=\"width:150px$bgcolor\" name=\"it618_name[$it618_tuan_goods_type[id]]\" value=\"$it618_tuan_goods_type[it618_name]\" $readonly>",
		"<input type=\"text\" class=\"txt\" style=\"width:40px\" name=\"it618_order[$it618_tuan_goods_type[id]]\" value=\"$it618_tuan_goods_type[it618_order]\">",
		"<input type=\"text\" class=\"txt\" style=\"width:150px$bgcolor\" name=\"it618_name1[$it618_tuan_goods_type[id]]\" value=\"$it618_tuan_goods_type[it618_name1]\" $readonly>",
		"<input type=\"text\" class=\"txt\" style=\"width:40px\" name=\"it618_order1[$it618_tuan_goods_type[id]]\" value=\"$it618_tuan_goods_type[it618_order1]\">",
		$saletypestr,
		"<input type=\"text\" class=\"txt\" style=\"width:60px;color:red;margin-right:3px\" name=\"it618_saleprice[$it618_tuan_goods_type[id]]\" value=\"$it618_tuan_goods_type[it618_saleprice]\">".it618_tuan_getlang('s125')." + <input type=\"text\" class=\"txt\" style=\"width:60px;color:red;margin-right:3px\" name=\"it618_score[$it618_tuan_goods_type[id]]\" value=\"$it618_tuan_goods_type[it618_score]\">".'<select name="it618_jfid['.$it618_tuan_goods_type['id'].']">'.it618_tuan_getjftype($it618_tuan_goods_type['it618_jfid']).'</select>',
		"<input type=\"text\" class=\"txt\" style=\"width:60px\" name=\"it618_price[$it618_tuan_goods_type[id]]\" value=\"$it618_tuan_goods_type[it618_price]\">",
		'<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_tuan_goods_type['id'].']" '.$it618_ison_checked.' value="1">',
		$salecount
	));
}
	
	global $_G;
if($reabc[4]!='8')return; /*Dism��taobao��com*/

	loadcache('plugin');
	$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
	$s125=it618_tuan_getlang('s125');
	$tmpjftype='<select name="newit618_jfid[]">'.it618_tuan_getjftype().'</select>';
	
	if($it618_tuan_goods['it618_saletype']==3){
		$tmpstr='';
	}else{
		$tmpstr='<input type="text" class="txt" style="width:60px" name="newit618_count[]">';	
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:150px" name="newit618_name[]">'],
		[1,'<input type="text" class="txt" style="width:40px" name="newit618_order[]">'],
		[1,'<input type="text" class="txt" style="width:150px" name="newit618_name1[]">'],
		[1,'<input type="text" class="txt" style="width:40px" name="newit618_order1[]">'],
		[1,'$tmpstr'],
		[1,'<input type="text" class="txt" style="width:60px;margin-right:3px" name="newit618_saleprice[]">$s125 + <input type="text" class="txt" style="width:60px;color:red;margin-right:3px" name="newit618_score[]">$tmpjftype'],
		[1,'<input type="text" class="txt" style="width:60px" name="newit618_price[]">'],
		[1,''], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
	if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>