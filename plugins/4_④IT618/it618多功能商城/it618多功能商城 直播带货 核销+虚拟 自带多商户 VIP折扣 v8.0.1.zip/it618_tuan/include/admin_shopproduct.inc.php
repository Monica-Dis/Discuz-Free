<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return; /*dism . taobao . com*/

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

$it618sql = "1";

$state0='';$state1='';$state2='';$state3='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and g.it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and g.it618_state = 1";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and g.it618_state = 2";$state3='selected="selected"';}

$saletype0='';$saletype1='';$saletype2='';$saletype3='';
if($_GET['saletype']==0){$saletype0='selected="selected"';}
if($_GET['saletype']==1){$it618sql .= " and g.it618_saletype = 1";$saletype1='selected="selected"';}
if($_GET['saletype']==2){$it618sql .= " and g.it618_saletype = 2";$saletype2='selected="selected"';}
if($_GET['saletype']==3){$it618sql .= " and g.it618_saletype = 3";$saletype3='selected="selected"';}
if($_GET['saletype']==4){$it618sql .= " and g.it618_saletype = 4";$saletype4='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';$orderby4='';
if($_GET['orderby']==0){$it618orderby = "it618_order,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "it618_salecount desc";$orderby2='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "it618_views desc";$orderby3='selected="selected"';}
if($_GET['orderby']==3){$it618orderby = "it618_saleprice desc";$orderby4='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&price1='.$_GET['price1'].'&price2='.$_GET['price2'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'].'&saletype='.$_GET['saletype'].'&orderby='.$_GET['orderby'].'&it618_shopid='.$_GET['it618_shopid'];

foreach(C::t('#it618_tuan#it618_tuan_shop')->fetch_all_by_isgoodsnot() as $it618_tmp) {
	if($_GET['it618_shopid']=='')$_GET['it618_shopid']=$it618_tmp['id'];
	$goodscount=C::t('#it618_tuan#it618_tuan_goods')->count_by_shopid($it618_tmp['id']);
	$shoptmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'('.$goodscount.')</option>';
}
$shoptmp=str_replace('<option value='.$_GET['it618_shopid'].'>','<option value='.$_GET['it618_shopid'].' selected="selected">',$shoptmp);

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_pid($delid);
		if($salecount<=0){
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($delid);
			
			$tmpurl=$_G['siteurl'].it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			$qrcodeurl=md5($tmpurl);
			$qrcodeurl='source/plugin/it618_tuan/qrcode/'.$qrcodeurl.'.png';
			$tmparr=explode("source",$qrcodeurl);
			$qrcodeurl=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($qrcodeurl)){
				$result=unlink($qrcodeurl);
			}
			
			for($i=0;$i<=4;$i++){
				if($i==0)$tmpi='';else $tmpi=$i;
				$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
				
				if($it618_tuan_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
					$tmparr=explode("source",$it618_tuan_goods['it618_picbig'.$tmpi]);
					$tmparr1=explode("://",$it618_tuan_goods['it618_picbig'.$tmpi]);
					$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_picbig)&&count($tmparr1)==1){
						$result=unlink($it618_picbig);
					}
				}
				
				$file_ext=strtolower(substr($it618_tuan_goods['it618_picbig'.$tmpi],strrpos($it618_tuan_goods['it618_picbig'.$tmpi], '.')+1)); 
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
				if(file_exists($it618_smallurl)){
					$result=unlink($it618_smallurl);
				}
			}
			
			C::t('#it618_tuan#it618_tuan_goods')->delete_by_id($delid);
			$del=$del+1;
		}else{
			$flag=1;
		}
	}
	
	if($flag==1)$tmpstr='<br><br>'.$it618_tuan_lang['s1775'];

	cpmsg(it618_tuan_getlang('s342').$del.$tmpstr,  "action=plugins&identifier=$identifier&cp=admin_shopproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_on')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($delid);
		if($it618_tuan_goods['it618_state']==0){
			DB::query("update ".DB::table('it618_tuan_goods')." set it618_state=1 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg(it618_tuan_getlang('s343').$ok,  "action=plugins&identifier=$identifier&cp=admin_shopproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_down')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($delid);
		if($it618_tuan_goods['it618_state']==1){
			DB::query("update ".DB::table('it618_tuan_goods')." set it618_state=0 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg(it618_tuan_getlang('s344').$ok,  "action=plugins&identifier=$identifier&cp=admin_shopproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			if($_GET['it618_saletype'][$id]==1||$_GET['it618_saletype'][$id]==4){
				$it618_isservice1=$_GET['it618_isservice1'][$id];
				$it618_isservice2=$_GET['it618_isservice2'][$id];
				$it618_isservice3=$_GET['it618_isservice3'][$id];
			}else{
				$it618_isservice1=0;
				$it618_isservice2=0;
				$it618_isservice3=0;
			}
			$it618_shopid = DB::result_first("SELECT it618_shopid FROM ".DB::table('it618_tuan_goods')." WHERE id=".$id);
			$it618_price = DB::result_first("SELECT it618_price FROM ".DB::table('it618_tuan_shop')." WHERE id=".$it618_shopid);
			if($_GET['it618_saleprice'][$id]>$it618_price){
				$it618_saleprice=$_GET['it618_saleprice'][$id];
			}else{
				$it618_saleprice=$it618_price;
			}
			
			if($_GET['it618_meal_id'][$id]==0)$it618_mealname='';else $it618_mealname=$_GET['it618_mealname'][$id];
			
			$it618_score=$_GET['it618_score'][$id];
			if($_GET['it618_jfid'][$id]==0)$it618_score=0;
			
			C::t('#it618_tuan#it618_tuan_goods')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_meal_id' => $_GET['it618_meal_id'][$id],
				'it618_mealname' => dhtmlspecialchars($it618_mealname),
				'it618_unit' => dhtmlspecialchars($_GET['it618_unit'][$id]),
				'it618_saletype' => $_GET['it618_saletype'][$id],
				'it618_jfid' => $_GET['it618_jfid'][$id],
				'it618_score' => $it618_score,
				'it618_saleprice' => $it618_saleprice,
				'it618_price' => $_GET['it618_price'][$id],
				'it618_jfbl' => $_GET['it618_jfbl'][$id],
				'it618_bsaletime' => dhtmlspecialchars($_GET['it618_bsaletime'][$id]),
				'it618_esaletime' => dhtmlspecialchars($_GET['it618_esaletime'][$id]),
				'it618_xgtime' => $_GET['it618_xgtime'][$id],
				'it618_xgcount' => $_GET['it618_xgcount'][$id],
				'it618_xgtype' => $_GET['it618_xgtype'][$id],
				'it618_xgtime1' => dhtmlspecialchars($_GET['it618_xgtime1'][$id]),
				'it618_xgtime2' => dhtmlspecialchars($_GET['it618_xgtime2'][$id]),
				'it618_isservice1' => $it618_isservice1,
				'it618_isservice2' => $it618_isservice2,
				'it618_isservice3' => $it618_isservice3,
				'it618_isorderbuy' => $_GET['it618_isorderbuy'][$id],
				'it618_isbm' => $_GET['it618_isbm'][$id],
				'it618_issaledisplay' => $_GET['it618_issaledisplay'][$id],
				'it618_isyunfeifree' => $_GET['it618_isyunfeifree'][$id],
				'it618_mealorder' => $_GET['it618_mealorder'][$id]
			));
			
			if($_GET['it618_saletype'][$id]!=3){
				C::t('#it618_tuan#it618_tuan_goods')->update($id,array(
					'it618_count' => $_GET['it618_count'][$id]
				));
			}
	
			$ok=$ok+1;
		}
	}

	cpmsg(it618_tuan_getlang('s345').$ok,  "action=plugins&identifier=$identifier&cp=admin_shopproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

$tmp='<option value="0">'.it618_tuan_getlang('s346').'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

$tmpmeal='<option value="0">'.it618_tuan_getlang('s347').'</option>';
foreach(C::t('#it618_tuan#it618_tuan_meal')->fetch_all_by_it618_shopid($_GET['it618_shopid']) as $it618_tmp) {
	$tmpmeal.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

if($_GET['it618_shopid']=='')$_GET['it618_shopid']="-1";

showformheader("plugins&identifier=$identifier&cp=admin_shopproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql);
showtableheaders($strtmptitle[$cp1],'it618_tuan_sum');
	echo '<tr><td colspan=14>'.it618_tuan_getlang('s606').' <select id="it618_shopid" name="it618_shopid">'.$shoptmp.'</select> '.it618_tuan_getlang('s98').' <input name="price1" value="'.$_GET['price1'].'" class="txt" style="width:50px;margin-right:0" /> - <input name="price2" value="'.$_GET['price2'].'" class="txt" style="width:50px" /> '.it618_tuan_getlang('s99').' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_tuan_getlang('s100').'</option></select> '.it618_tuan_getlang('s101').' <select name="state"><option value=0 '.$state0.'>'.it618_tuan_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_tuan_getlang('s103').'</option><option value=2 '.$state2.'>'.it618_tuan_getlang('s104').'</option><option value=3 '.$state3.'>'.it618_tuan_getlang('s105').'</option></select> '.it618_tuan_getlang('t315').' <select name="saletype"><option value=0 '.$saletype0.'>'.it618_tuan_getlang('s842').'</option><option value=1 '.$saletype1.'>'.it618_tuan_getlang('s719').'</option><option value=2 '.$saletype2.'>'.it618_tuan_getlang('s720').'</option><option value=3 '.$saletype3.'>'.it618_tuan_getlang('s836').'</option><option value=4 '.$saletype4.'>'.it618_tuan_getlang('s1713').'</option></select> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_tuan_getlang('s110').'</option><option value=1 '.$orderby1.'>'.it618_tuan_getlang('s111').'</option><option value=2 '.$orderby2.'>'.it618_tuan_getlang('s112').'</option><option value=3 '.$orderby3.'>'.it618_tuan_getlang('s113').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_tuan_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_tuan#it618_tuan_goods')->count_by_search($it618sql,'',$_GET['it618_shopid'],$_GET['it618_class1_id'],$_GET['it618_class2_id'],0,0,'',$_GET['price1'],$_GET['price2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shopproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	if(intval($_GET['it618_shopid'])>0){
		$it618_price = DB::result_first("SELECT it618_price FROM ".DB::table('it618_tuan_shop')." WHERE id=".intval($_GET['it618_shopid']));
		$tmptips=str_replace("{price}",$it618_price,it618_tuan_getlang('s887'));
	}
	echo '<tr><td colspan=14>'.it618_tuan_getlang('s114').$count.'<span style="float:right;color:red">'.it618_tuan_getlang('s858').$tmptips.'</span></td></tr>';
	showsubtitle(array('',it618_tuan_getlang('s115').'/'.$it618_tuan_lang['s348'].it618_tuan_getlang('s123'),it618_tuan_getlang('s116'),it618_tuan_getlang('t307'),it618_tuan_getlang('s718'),$it618_tuan_lang['s1047'],it618_tuan_getlang('s998'),it618_tuan_getlang('s862'),it618_tuan_getlang('s122')));
	
	$n=1;
	foreach(C::t('#it618_tuan#it618_tuan_goods')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['it618_shopid'],$_GET['it618_class1_id'],$_GET['it618_class2_id'],0,0,'',$_GET['price1'],$_GET['price2'],$startlimit,$ppp
	) as $it618_tuan_goods) {
		
		if($it618_tuan_goods['it618_saletype']==1)$it618_saletype1='selected="selected"';else $it618_saletype1="";
		if($it618_tuan_goods['it618_saletype']==2)$it618_saletype2='selected="selected"';else $it618_saletype2="";
		if($it618_tuan_goods['it618_saletype']==3)$it618_saletype3='selected="selected"';else $it618_saletype3="";
		if($it618_tuan_goods['it618_saletype']==4)$it618_saletype4='selected="selected"';else $it618_saletype4="";

		if($it618_tuan_goods['it618_isservice1']==1)$it618_isservice1_checked='checked="checked"';else $it618_isservice1_checked="";
		if($it618_tuan_goods['it618_isservice2']==1)$it618_isservice2_checked='checked="checked"';else $it618_isservice2_checked="";
		if($it618_tuan_goods['it618_isservice3']==1)$it618_isservice3_checked='checked="checked"';else $it618_isservice3_checked="";
		
		if($it618_tuan_goods['it618_isorderbuy']==1)$it618_isorderbuy_checked='checked="checked"';else $it618_isorderbuy_checked="";
		if($it618_tuan_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		if($it618_tuan_goods['it618_issaledisplay']==1)$it618_issaledisplay_checked='checked="checked"';else $it618_issaledisplay_checked="";
		
		if($it618_tuan_goods['it618_state']==0)$it618_state='<font color=blue>'.it618_tuan_getlang('s103').'</font>';
		if($it618_tuan_goods['it618_state']==1)$it618_state='<font color=green>'.it618_tuan_getlang('s104').'</font>';
		if($it618_tuan_goods['it618_state']==2)$it618_state='<font color=red>'.it618_tuan_getlang('s105').'</font>';
		
		if($it618_tuan_goods['it618_xgtype']==0)$it618_xgtype0=' selected="selected"';else $it618_xgtype0="";
		if($it618_tuan_goods['it618_xgtype']==1)$it618_xgtype1=' selected="selected"';else $it618_xgtype1="";
		if($it618_tuan_goods['it618_xgtype']==2)$it618_xgtype2=' selected="selected"';else $it618_xgtype2="";
		
		$salecount = C::t('#it618_tuan#it618_tuan_sale')->sumcount_by_it618_pid($it618_tuan_goods['id']);
		$salemoney = C::t('#it618_tuan#it618_tuan_sale')->summoney_by_it618_pid($it618_tuan_goods['id']);
		
		$class1name = C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_name_by_id($it618_tuan_goods['it618_class1_id']);
		$class2name = C::t('#it618_tuan#it618_tuan_class2')->fetch_it618_name_by_id($it618_tuan_goods['it618_class2_id']);
		
		$preurl="action=plugins&identifier=$identifier&cp=admin_shopproduct&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql;
		$preurl=str_replace("&","@",$preurl);
		
		$gtypethdcss = 'display:';
		$divcss	= 'display:none';
		$countcss = 'display:';
		$saletypecss2='display:none';
		$saletypecss3='display:none';
		
		if($it618_tuan_goods['it618_isyunfeifree']==0)$it618_isyunfeifree0=' selected="selected"';else $it618_isyunfeifree0="";
		if($it618_tuan_goods['it618_isyunfeifree']==1)$it618_isyunfeifree1=' selected="selected"';else $it618_isyunfeifree1="";
		if($it618_tuan_goods['it618_isyunfeifree']==2)$it618_isyunfeifree2=' selected="selected"';else $it618_isyunfeifree2="";
		
		$saletypestr2=' <select id="it618_isyunfeifree'.$n.'" style="margin-bottom:3px" name="it618_isyunfeifree['.$it618_tuan_goods[id].']"><option value="0"'.$it618_isyunfeifree0.'>'.it618_tuan_getlang('s995').'</option><option value="1"'.$it618_isyunfeifree1.'>'.it618_tuan_getlang('s996').'</option><option value="2"'.$it618_isyunfeifree2.'>'.it618_tuan_getlang('s997').'</option></select>';
		
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_km')." WHERE it618_pid=".$it618_tuan_goods['id']);
		$saletypestr3='<br><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_shopproduct_km&pmod=admin_product&operation='.$operation.'&do='.$do.'&cp1=8&pid='.$it618_tuan_goods['id'].'&preurl='.$preurl.'">'.it618_tuan_getlang('s837').'(<font color=red>'.$kmcount.'</font>)</a>';
		
		$typecountall = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_type')." WHERE it618_pid=".$it618_tuan_goods['id']);
		$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_tuan_goods['id']);
		$goodstypestr='<br><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_shopproduct_type&pmod=admin_product&operation='.$operation.'&do='.$do.'&cp1=9&pid='.$it618_tuan_goods['id'].'&preurl='.$preurl.'"><font color=#F60>'.$it618_tuan_lang['s1724'].'(<font color=red>'.$typecountok.'</font>/<font color=red>'.$typecountall.'</font>)</font></a>';
		
		$thdcountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_thd')." WHERE it618_pid=".$it618_tuan_goods['id']);
		$goodsthdstr='<br><span style="float:left"><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_shopproduct_thd&pmod=admin_product&operation='.$operation.'&do='.$do.'&cp1=10&pid='.$it618_tuan_goods['id'].'&preurl='.$preurl.'">'.$it618_tuan_lang['s1725'].'(<font color=red>'.$thdcountok.'</font>)</a></span>';
			
		if($it618_tuan_goods['it618_saletype']==1){
			$divcss	= 'display:';
		}else if($it618_tuan_goods['it618_saletype']==2){
			$saletypecss2='display:';
		}else if($it618_tuan_goods['it618_saletype']==4){
			$divcss	= 'display:';
			$saletypecss2='display:';
		}else{
			$saletypecss3='display:';
			$countcss = 'display:none';
			$gtypethdcss = 'display:none';
		}
		
		$goodstypecss='';
		if($typecountok>0){
			$goodstypecss='display:none';
			$saletypecss3='display:none';
		}
		
		$saletypestr='<span id="saletypespan1_'.$it618_tuan_goods['id'].'" style="'.$saletypecss1.'">'.$saletypestr1.'</span><span id="saletypespan2_'.$it618_tuan_goods['id'].'" style="'.$saletypecss2.'">'.$saletypestr2.'</span><span id="saletypespan3_'.$it618_tuan_goods['id'].'" style="'.$saletypecss3.'">'.$saletypestr3.'</span>';
		
		if($it618_tuan_goods['it618_meal_id']==0)$mealnamestyle='display:none"';else $mealnamestyle='';
		
		$tmpmeal1=str_replace('<option value='.$it618_tuan_goods['it618_meal_id'].'>','<option value='.$it618_tuan_goods['it618_meal_id'].' selected="selected">',$tmpmeal);
		
		if($it618_tuan_goods['it618_unit']=='')$it618_unit=it618_tuan_getlang('s608');else $it618_unit=$it618_tuan_goods['it618_unit'];
		$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_tuan_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_tuan_goods['id'].'</label>',
			'<a style="float:left" href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_tuan_goods['it618_description'].'"><img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="90" height="90" align="absmiddle"/></a><div style="float:left;margin-left:3px;line-height:20px"><input type="text" class="txt" style="width:200px;margin-right:3px;margin-bottom:3px" name="it618_name['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_name'].'"><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_shopproduct_edit&pmod=admin_product&operation='.$operation.'&do='.$do.'&cp1=6&pid='.$it618_tuan_goods[id].'&preurl='.$preurl.'">'.it618_tuan_getlang('s351').'</a><br><select name="it618_meal_id['.$it618_tuan_goods['id'].']" style="margin-bottom:3px" onchange="setmeal(this.value,'.$it618_tuan_goods['id'].')">'.$tmpmeal1.'</select><br><input type="text" class="txt" id="mealname'.$it618_tuan_goods['id'].'" style="width:200px;margin-right:1px;'.$mealnamestyle.'" name="it618_mealname['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_mealname'].'"><input type="text" class="txt" style="width:28px; '.$mealnamestyle.'" id="mealorder'.$it618_tuan_goods['id'].'" name="it618_mealorder['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_mealorder'].'"><span id="gtypethdspan'.$it618_tuan_goods['id'].'" style="'.$gtypethdcss.'">'.$goodsthdstr.'</span></div>',
			'<div style="line-height:23px">
			<span style="'.$goodstypecss.'"><input type="text" class="txt" style="width:60px;margin-right:3px;color:red" name="it618_saleprice['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_saleprice'].'">'.it618_tuan_getlang('s125').'+<input type="text" class="txt" style="width:50px;margin-right:3px;;color:red" name="it618_score['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_score'].'"><select name="it618_jfid['.$it618_tuan_goods['id'].']">'.it618_tuan_getjftype($it618_tuan_goods['it618_jfid']).'</select><br>'.$it618_tuan_lang['t148'].':<input type="text" class="txt" style="width:60px;margin-right:3px" name="it618_price['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_price'].'">'.it618_tuan_getlang('s125').'</span>
			<br><span id="countspan'.$it618_tuan_goods['id'].'" style="'.$countcss.'"><span style="'.$goodstypecss.'">'.it618_tuan_getlang('s840').' <input type="text" class="txt" style="width:58px;margin-right:1px;color:green;" name="it618_count['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_count'].'"></span> </span> '.it618_tuan_getlang('s841').' <input type="text" title="'.it618_tuan_getlang('s607').'" class="txt" style="width:40px;margin-right:1px" name="it618_unit['.$it618_tuan_goods['id'].']" value="'.$it618_unit.'">
			'.$goodstypestr.'</div>',
			'<select id="it618_xgtype'.$n.'" name="it618_xgtype['.$it618_tuan_goods[id].']" style="margin-top:3px"><option value="0"'.$it618_xgtype0.'>'.it618_tuan_getlang('s944').'</option><option value="1"'.$it618_xgtype1.'>'.it618_tuan_getlang('s945').'</option><option value="2"'.$it618_xgtype2.'>'.it618_tuan_getlang('s946').'</option></select><br><input type="text" class="txt" style="width:115px;margin-top:3px" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_tuan_goods['id'].']" readonly="readonly" value="'.$it618_tuan_goods['it618_xgtime1'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"><br><input type="text" class="txt" style="width:115px;margin-top:3px" id="it618_xgtime2_'.$n.'" name="it618_xgtime2['.$it618_tuan_goods['id'].']" readonly="readonly" value="'.$it618_tuan_goods['it618_xgtime2'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')">
			<br>'.it618_tuan_getlang('s126').' <input type="text" class="txt" style="width:18px;margin-right:3px;" name="it618_xgtime['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_xgtime'].'">'.it618_tuan_getlang('s127').'/ <input type="text" class="txt" style="width:26px;margin-right:3px" name="it618_xgcount['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_xgcount'].'">'.$it618_unit,
			'<select id="it618_saletype'.$it618_tuan_goods['id'].'" style="margin-bottom:3px" name="it618_saletype['.$it618_tuan_goods['id'].']" onchange="setsaletype('.$it618_tuan_goods['id'].',this.value)"><option value=1 '.$it618_saletype1.'>'.it618_tuan_getlang('s719').'</option><option value=2 '.$it618_saletype2.'>'.it618_tuan_getlang('s720').'</option><option value=3 '.$it618_saletype3.'>'.it618_tuan_getlang('s836').'</option><option value=4 '.$it618_saletype4.'>'.it618_tuan_getlang('s1713').'</option></select>'.$saletypestr.'<div id="servicediv'.$it618_tuan_goods['id'].'" style="'.$divcss.';width:190px"><input class="checkbox" type="checkbox" id="chk_isservice1'.$n.'" name="it618_isservice1['.$it618_tuan_goods['id'].']" '.$it618_isservice1_checked.' value="1"><label for="chk_isservice1'.$n.'"><font color=green>'.it618_tuan_getlang('s107').'</font></label><input class="checkbox" type="checkbox" id="chk_isservice2'.$n.'" name="it618_isservice2['.$it618_tuan_goods['id'].']" '.$it618_isservice2_checked.' value="1"><label for="chk_isservice2'.$n.'"><font color=green>'.it618_tuan_getlang('s108').'</font></label><input class="checkbox" type="checkbox" id="chk_isservice3'.$n.'" name="it618_isservice3['.$it618_tuan_goods['id'].']" '.$it618_isservice3_checked.' value="1"><label for="chk_isservice3'.$n.'"><font color=green>'.it618_tuan_getlang('s109').'</font></label><br><div style="float:left">'.$it618_tuan_lang['s19'].'</div><input type="text" class="txt" style="width:120px;float:right" name="it618_bsaletime['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_bsaletime'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"><br><input type="text" class="txt" style="width:120px;margin-top:3px;float:right" name="it618_esaletime['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_esaletime'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"></div>',
			'<input type="text" class="txt" style="width:50px;margin-right:1px;color:blue" name="it618_jfbl['.$it618_tuan_goods['id'].']" value="'.$it618_tuan_goods['it618_jfbl'].'">%<br><div style="line-height:15px">'.it618_tuan_getlang('s118').'<font color=red>'.$it618_tuan_goods['it618_views'].'</font><br>'.it618_tuan_getlang('s119').'<font color=red>'.$salecount.'</font>'.'<br>'.it618_tuan_getlang('s120').'<font color=red>'.$salemoney.'</font><br><input class="checkbox" type="checkbox" id="chk_issaledisplay'.$n.'" name="it618_issaledisplay['.$it618_tuan_goods['id'].']" '.$it618_issaledisplay_checked.' value="1"><label for="chk_issaledisplay'.$n.'">'.it618_tuan_getlang('s932').'</label></div>',
			'<input class="checkbox" type="checkbox" id="chk_isorderbuy'.$n.'" name="it618_isorderbuy['.$it618_tuan_goods['id'].']" '.$it618_isorderbuy_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_tuan_goods['id'].']" '.$it618_isbm_checked.' value="1">',
			$it618_state
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_tuan_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_tuan_getlang('s352').'" onclick="return confirm(\''.it618_tuan_getlang('s353').'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.it618_tuan_getlang('s354').'"/> <input type="submit" class="btn" name="it618submit_on" value="'.it618_tuan_getlang('s355').'" onclick="return confirm(\''.it618_tuan_getlang('s356').'\')" /> <input type="submit" class="btn" name="it618submit_down" value="'.it618_tuan_getlang('s357').'" onclick="return confirm(\''.it618_tuan_getlang('s358').'\')" /><br><font color=green>'.it618_tuan_getlang('s927').'</font> <br>'.it618_tuan_getlang('s135').'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter(); /*dism��taobao��com*/
$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
echo '
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	</script>';
echo '<script>
		'.$jstmp.'

		function setsaletype(pid,objvalue){
			document.getElementById("saletypespan1_"+pid).style.display="none"; 
			document.getElementById("saletypespan2_"+pid).style.display="none"; 
			document.getElementById("saletypespan3_"+pid).style.display="none"; 
			
			document.getElementById("countspan"+pid).style.display=""; 
			document.getElementById("gtypethdspan"+pid).style.display=""; 
			document.getElementById("servicediv"+pid).style.display="none"; 
			
			if(objvalue==1){
				document.getElementById("saletypespan1_"+pid).style.display=""; 
				document.getElementById("servicediv"+pid).style.display=""; 
			}
			
			if(objvalue==2){
				document.getElementById("saletypespan2_"+pid).style.display=""; 
			}
			
			if(objvalue==3){
				document.getElementById("saletypespan3_"+pid).style.display=""; 
				document.getElementById("countspan"+pid).style.display="none"; 
				document.getElementById("gtypethdspan"+pid).style.display="none"; 
			}
			
			if(objvalue==4){
				document.getElementById("saletypespan1_"+pid).style.display=""; 
				document.getElementById("servicediv"+pid).style.display=""; 
				document.getElementById("saletypespan2_"+pid).style.display=""; 
			}
		}

		function setservice(obj){
			if(obj.checked==true){
				document.getElementById("isservice").style.display="none"; 
			}else{
				document.getElementById("isservice").style.display=""; 
			}
		}
		
		</script>';
echo '<script charset="utf-8" src="source/plugin/it618_tuan/js/Calendar.js"></script>
	  <script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
		
		function setmeal(mealclass,n){
			if(mealclass==0){
				document.getElementById("mealname"+n).style.display="none";
				document.getElementById("mealorder"+n).style.display="none";
			}else{
				document.getElementById("mealname"+n).style.display="";
				document.getElementById("mealorder"+n).style.display="";
			}
		}
	  </script>';
if(count($reabc)!=10)return;
showtablefooter(); /*dism��taobao��com*/
?>