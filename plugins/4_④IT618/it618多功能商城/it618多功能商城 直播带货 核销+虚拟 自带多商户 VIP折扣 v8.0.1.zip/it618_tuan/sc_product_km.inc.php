<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$pid=intval($_GET['pid']);
$gtypeid=intval($_GET['gtypeid']);
$preurl=$_GET['preurl'];
$preurl1=$_GET['preurl1'];
if(submitcheck('it618submit')){
	$ok1=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		if($gtypeid>0){
			DB::delete('it618_tuan_goods_type_km', "id=$delid");
		}else{
			DB::delete('it618_tuan_goods_km', "id=$delid");
		}
		$del=$del+1;
	}

	if(is_array($_GET['it618_code'])) {
		foreach($_GET['it618_code'] as $id => $val) {

			if($gtypeid>0){
				C::t('#it618_tuan#it618_tuan_goods_type_km')->update($id,array(
					'it618_code' => dhtmlspecialchars($_GET['it618_code'][$id])
				));
			}else{
				C::t('#it618_tuan#it618_tuan_goods_km')->update($id,array(
					'it618_code' => dhtmlspecialchars($_GET['it618_code'][$id])
				));
			}
			$ok1=$ok1+1;
		}
	}
	
	it618_cpmsg(it618_tuan_getlang('s33').$ok1.' '.it618_tuan_getlang('s35').$del.')', "plugin.php?id=it618_tuan:sc_product_km$adminsid&pid=$pid&gtypeid=$gtypeid&preurl=$preurl&preurl1=$preurl1", 'succeed');
}

if(submitcheck('it618submit_adds')){
	$ok1=0;
	
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $_GET['it618_name_adds']);
	$line=explode("@||@",$lines);

	foreach($line as $key =>$li)
	{
		if(trim($li)!=''){
			if($gtypeid>0){
				C::t('#it618_tuan#it618_tuan_goods_type_km')->insert(array(
					'it618_pid' => $pid,
					'it618_gtypeid' => $gtypeid,
					'it618_code' => dhtmlspecialchars($li)
				), true);
			}else{
				C::t('#it618_tuan#it618_tuan_goods_km')->insert(array(
					'it618_pid' => $pid,
					'it618_code' => dhtmlspecialchars($li)
				), true);
			}
			$ok1=$ok1+1;
		}
	}
	
	it618_cpmsg(it618_tuan_getlang('s857').$ok1, "plugin.php?id=it618_tuan:sc_product_km$adminsid&pid=$pid&gtypeid=$gtypeid&preurl=$preurl&preurl1=$preurl1", 'succeed');
}

if(submitcheck('it618submit_dao')){
	$ok1=0;
	if (preg_match('/\.\./', $_GET['it618_name_dao'])) {
		it618_cpmsg(it618_tuan_getlang('s843').$file_path, "plugin.php?id=it618_tuan:sc_product_km&pid=$pid&preurl=$preurl", 'error');
	}
	
	$tmparr=explode("source/plugin/it618_tuan/kindeditor",$_GET['it618_name_dao']);
	$file_path='source/plugin/it618_tuan/kindeditor'.$tmparr[1];
	
	if (!file_exists($file_path)) {
		it618_cpmsg(it618_tuan_getlang('s843').$file_path, "plugin.php?id=it618_tuan:sc_product_km&pid=$pid&preurl=$preurl", 'error');
	}
	
	$lines = dfsockopen($_G['siteurl'].$file_path);
	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	ini_set('memory_limit', '-1');
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $lines);
	$line=explode("@||@",$lines);
	$ok1=0;

	foreach($line as $key =>$li)
	{
		if(trim($li)!=''){
			if($gtypeid>0){
				C::t('#it618_tuan#it618_tuan_goods_type_km')->insert(array(
					'it618_pid' => $pid,
					'it618_gtypeid' => $gtypeid,
					'it618_code' => dhtmlspecialchars($li)
				), true);
			}else{
				C::t('#it618_tuan#it618_tuan_goods_km')->insert(array(
					'it618_pid' => $pid,
					'it618_code' => dhtmlspecialchars($li)
				), true);
			}
			$ok1=$ok1+1;
		}
	}
	@unlink($file_path);
	
	it618_cpmsg(it618_tuan_getlang('s844').$ok1, "plugin.php?id=it618_tuan:sc_product_km$adminsid&pid=$pid&gtypeid=$gtypeid&preurl=$preurl&preurl1=$preurl1", 'succeed');
}

if(submitcheck('it618submit_clear')){
	if($gtypeid>0){
		DB::query("delete from ".DB::table('it618_tuan_goods_type_km')." where it618_gtypeid=".$gtypeid);
		DB::query("update ".DB::table('it618_tuan_goods_type')." set it618_count=0 where id=".$gtypeid);
	}else{
		DB::query("delete from ".DB::table('it618_tuan_goods_km')." where it618_pid=".$pid);
		DB::query("update ".DB::table('it618_tuan_goods')." set it618_count=0 where id=".$pid);
	}
	
	it618_cpmsg(it618_tuan_getlang('s845'), "plugin.php?id=it618_tuan:sc_product_km$adminsid&pid=$pid&gtypeid=$gtypeid&preurl=$preurl&preurl1=$preurl1", 'succeed');
}

$pname = DB::result_first("select it618_name from ".DB::table('it618_tuan_goods')." where id=".$pid);
if($gtypeid>0){
	$gtypename = DB::result_first("select it618_name from ".DB::table('it618_tuan_goods_type')." where id=".$gtypeid);
	$gtypename=' - '.$gtypename;
	
	$sql=DB::table('it618_tuan_goods_type_km')." where it618_gtypeid=".$gtypeid;
	
	$preurltmp=str_replace("@","&",$preurl1);
	$preurltmp.="&preurl=$preurl";
}else{
	$sql=DB::table('it618_tuan_goods_km')." where it618_pid=".$pid;
	
	$preurltmp=str_replace("@","&",$preurl);
}

if($gtypeid>0){
	$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_type_km')." WHERE it618_gtypeid=".$gtypeid);
	DB::query("update ".DB::table('it618_tuan_goods_type')." set it618_count=".$kmcount." where id=".$gtypeid);
	
	$it618_count=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_count_by_pid($pid);
	C::t('#it618_tuan#it618_tuan_goods')->update($pid,array(
		'it618_count' => $it618_count
	));
}else{
	$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_km')." WHERE it618_pid=".$pid);
	DB::query("update ".DB::table('it618_tuan_goods')." set it618_count=".$kmcount." where id=".$pid);
}

it618_showformheader("plugin.php?id=it618_tuan:sc_product_km&pid=$pid&gtypeid=$gtypeid&preurl=$preurl&preurl1=$preurl1");

showtableheaders('<a href="'.$preurltmp.'"><<'.$it618_tuan_lang['s1187'].' <font color=red>'.$pname.$gtypename.'</font></a> '.it618_tuan_getlang('s846'),'it618_tuan_goods_km');

	$count = DB::result_first("SELECT COUNT(1) FROM ".$sql);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_tuan:sc_product_km$adminsid&pid=$pid&gtypeid=$gtypeid&preurl=$preurl&preurl1=$preurl1");
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
<script>
	KindEditor.ready(function(K) {
				var uploadbutton = K.uploadbutton({
					button : K(\'#btn_upfile\')[0],
					fieldName : \'imgFile\',
					url : \'source/plugin/it618_tuan/kindeditor/php/upload_json.php?dir=file&filetype=txt\',
					afterUpload : function(data) {
						if (data.error === 0) {
							var url = K.formatUrl(data.url, \'absolute\');
							K(\'#it618_name_dao\').val(url);
						} else {
							alert(data.message);
						}
					},
					afterError : function(str) {
						alert(str);
					}
				});
				uploadbutton.fileBox.change(function(e) {
					uploadbutton.submit();
				});
			});
</script>';

	echo '<tr><td colspan=4>'.it618_tuan_getlang('s847').$count.'<span style="float:right;">'.$it618_tuan_lang['s1035'].'</span></td></tr>';
	
	$query = DB::query("SELECT * FROM $sql LIMIT $startlimit, $ppp");
	while($it618_tuan = DB::fetch($query)) {
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_tuan[id]\" $disabled>",
			"<input type=\"text\" class=\"txt\" style=\"width:800px\" name=\"it618_code[$it618_tuan[id]]\" value=\"".dhtmlspecialchars($it618_tuan[it618_code])."\">"
		));
	}

	showsubmit('it618submit', 'submit', 'del', '<input type="submit" class="btn" name="it618submit_clear" value="'.it618_tuan_getlang('s848').'" onclick="return confirm(\''.it618_tuan_getlang('s849').'\')" /> <input type=hidden value=$page name=page />', $multipage);
	
	echo '<tr><td colspan=2>'.it618_tuan_getlang('s850').'<br><textarea name="it618_name_adds" style="width:400px;height:200px;margin-top:2px;"></textarea><br><input type="submit" class="btn" name="it618submit_adds" value="'.it618_tuan_getlang('s852').'"/></td></tr>
		  <tr><td colspan=2>'.it618_tuan_getlang('s851').'<br><input id="it618_name_dao" name="it618_name_dao" class="txt" style="width:300px"><input type="submit" class="btn" id="btn_upfile" value="'.it618_tuan_getlang('s853').'"/><br><input type="submit" class="btn" name="it618submit_dao" value="'.it618_tuan_getlang('s854').'"/></td></tr>';

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>