<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_tuan/js/Calendar.js"></script>
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_tuan/js/jquery.js"></script>

<script>
var dialog_fahuo,dialog_bz;
KindEditor.ready(function(K){});

function savekd(){
	var orderid=document.getElementById("orderid").value;
	var it618_kdid=document.getElementById("it618_kdid").value;
	var it618_kdid=it618_kdid.replace("selected=selected","");
	var it618_kddan=document.getElementById("it618_kddan").value;
	if(it618_kdid==0){
		sendmsg(\'kdtips\',\''.it618_tuan_getlang('s695').'\');
		return;
	}
	if(it618_kddan==""){
		sendmsg(\'kdtips\',\''.it618_tuan_getlang('s696').'\');
		return;
	}
	
	IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&orderid="+orderid+"&it618_kdid="+it618_kdid+"&it618_kddan="+it618_kddan+"&formhash='.FORMHASH.'", {ac:"ordersavekd"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		alert(tmparr[1]);
		getorderlist(orderurl);
		dialog_fahuo.remove();
	}else{
		sendmsg(\'kdtips\',tmparr[1]);
	}
	}, "html");

}

function okorder(orderid,type){
	if(type==1)var tmpstr="'.it618_tuan_getlang('s1011').'";
	if(type==0)var tmpstr="'.it618_tuan_getlang('s1012').'";
	if(confirm(tmpstr)){
		IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&orderid="+orderid+"&type="+type+"&formhash='.FORMHASH.'", {ac:"okorder"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getorderlist(orderurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function shopdelorder(orderid){
	if(confirm("'.$it618_tuan_lang['s1031'].'")){
		IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&orderid="+orderid+"&formhash='.FORMHASH.'", {ac:"shopdelorder"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getorderlist(orderurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function sendmsg(msgid,msgvalue){
	document.getElementById(msgid).innerHTML=msgvalue;
	setTimeout(\'sendmsg1("\'+msgid+\'")\',3000);
}
function sendmsg1(msgid){
	document.getElementById(msgid).innerHTML="";
}
</script>
';

showtableheaders(it618_tuan_getlang('t324'),'it618_tuan_sum');

	echo '<tr><td colspan="15"><div class="fixsel">'.it618_tuan_getlang('s224').' <input id="pname" class="txt" style="width:120px" /> '.it618_tuan_getlang('s761').' <input id="finduid" class="txt" style="width:50px" /> '.it618_tuan_getlang('s762').' <select id="state"><option value=0>'.it618_tuan_getlang('s414').'</option><option value=1 style="color:red">'.it618_tuan_getlang('t325').'</option><option value=2 style="color:blue">'.it618_tuan_getlang('t326').'</option><option value=3 style="color:green">'.it618_tuan_getlang('t327').'</option><option value=4 style="color:#F0F">'.it618_tuan_getlang('t328').'</option></select> '.it618_tuan_getlang('t323').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_tuan_getlang('t333').'" onclick="findorderlist()" /> </div></td></tr>';
	
	echo '<tr id="tr_ordersum"></tr>';
	
	showsubtitle(array('', it618_tuan_getlang('s233'),it618_tuan_getlang('s811'),it618_tuan_getlang('s418'),it618_tuan_getlang('s765'),it618_tuan_getlang('s1007'),it618_tuan_getlang('s1008')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_tuan/wap/images/loading.gif"></td></tr><tbody id="tr_orderlist"></tbody>';
	
	echo '<tr id="orderpage"></tr>';

showtablefooter(); /*dism��taobao��com*/
echo '
<script>
var orderurl="'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax";
var sqlurl="";
function getorderlist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_orderlist").style.display="none";
	IT618_TUAN.get(url+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"order_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_TUAN("#tr_ordersum").html(tmparr[0]);
	IT618_TUAN("#tr_orderlist").html(tmparr[1]);
	IT618_TUAN("#orderpage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_orderlist").style.display="";
	}, "html");	
	orderurl=url;
}
getorderlist(orderurl);

function findorderlist(){
	var pname = document.getElementById("pname").value;
	var finduid = document.getElementById("finduid").value;
	var state = document.getElementById("state").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&pname="+pname+"&finduid="+finduid+"&state="+state+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax";
	getorderlist(url);
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>