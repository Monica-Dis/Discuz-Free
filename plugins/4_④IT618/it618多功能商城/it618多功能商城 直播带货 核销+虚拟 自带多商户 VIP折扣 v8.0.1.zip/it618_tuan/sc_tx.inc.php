<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';

echo '<script type="text/javascript" src="source/plugin/it618_tuan/js/jquery.js"></script>';

showtableheaders(it618_tuan_getlang('s423').'<span style="float:right;font-weight:normal;"></span>','it618_tuan_money');

$it618_tuan_bank=C::t('#it618_tuan#it618_tuan_bank')->fetch_by_shopid($ShopId);
if($IsCredits==1&&in_array(1,(array)unserialize($it618_tuan['tuan_txtype'])))$tmpstr.='<option value="10">'.it618_tuan_getlang('s1136').'</option>';
if($it618_tuan_bank['it618_alipay']!=''&&in_array(2,(array)unserialize($it618_tuan['tuan_txtype'])))$tmpstr.='<option value="1">'.it618_tuan_getlang('s257').'</option>';
if($it618_tuan_bank['it618_wx']!=''&&in_array(3,(array)unserialize($it618_tuan['tuan_txtype'])))$tmpstr.='<option value="2">'.it618_tuan_getlang('s1137').'</option>';
if($it618_tuan_bank['it618_bankid']!=''&&in_array(4,(array)unserialize($it618_tuan['tuan_txtype'])))$tmpstr.='<option value="3">'.it618_tuan_getlang('s256').'</option>';

if($tmpstr==''){$tmpstr='<a href="plugin.php?id=it618_tuan:sc_bank">'.$it618_tuan_lang['s1138'].'</a>';$tmpcss=';display:none';}else $tmpstr='<select name="it618_type" id="txtype">'.$tmpstr.'</select>';

$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_txbl')." ORDER BY it618_num1");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<font color=red>'.$it618_tmp['it618_bl'].'%</font>('.$it618_tmp['it618_num1'].it618_tuan_getlang('s125').' - '.$it618_tmp['it618_num2'].it618_tuan_getlang('s125').'), ';
}

if($tmp==''){
	echo '<tr><td colspan=4><font color=red>'.it618_tuan_getlang('s425').'</font></td></tr>';
}else{
	$tmp=$tmp.'@';
	$tmp=str_replace(", @","",$tmp);
	echo '<tr><td colspan=4><form id="it618_tx">'.it618_tuan_getlang('s426').$tmpstr.' '.it618_tuan_getlang('s428').'<input id="it618_money" name="it618_money" class="txt" style="width:100px;height:20px;color:green;font-weight:bold;line-height:20px;font-size:20px;"/><input type="button" class="btn" onclick="savetxadd()" style="width:60px;height:25px" value="'.it618_tuan_getlang('s429').'" /> '.it618_tuan_getlang('s430').'<span id="ktxmoney" style="color:red"></span> '.it618_tuan_getlang('s125').'
	<br>'.it618_tuan_getlang('s431').'<input name="it618_bz" class="txt" style="width:700px;height:20px;color:green;font-weight:bold;line-height:20px;font-size:13px;" value="/" /></form>'.it618_tuan_getlang('s432').$tmp.'<div id="txtip" style="color:red;margin-top:5px"></div></td></tr>';
}

	
showtablefooter(); /*dism��taobao��com*/

showtableheaders(it618_tuan_getlang('s433'),'it618_tuan_tx');
echo '<tbody id="txlist"></tbody>';
showtablefooter(); /*dism��taobao��com*/
echo '
<script charset="utf-8" src="source/plugin/it618_tuan/js/Calendar.js"></script>
<script>

var url="'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&page=1";
function gettxlist(url){
	IT618_TUAN.get(url+"&formhash='.FORMHASH.'", {ac:"tx_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_TUAN("#txlist").html(tmparr[1]);
	IT618_TUAN("#ktxmoney").html(tmparr[0]);
	}, "html");	
	
}
gettxlist(url);

function findtx(){
	var it618_time1=document.getElementById("it618_time1").value;
	var it618_type=document.getElementById("it618_type").value;
	var it618_time2=document.getElementById("it618_time2").value;
	var it618_state=document.getElementById("it618_state").value;
	gettxlist("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&it618_type="+it618_type+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2+"&it618_state="+it618_state+"&page=1");
}

function savetxadd(){
	var it618_money=document.getElementById("it618_money").value;
	
	if(it618_money==""){
		sendmsg(\'txtip\',"'.it618_tuan_getlang('s434').'");
		return false;
	}
	
	IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&ac=tx_add&formhash='.FORMHASH.'", IT618_TUAN("#it618_tx").serialize(),function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		gettxlist(url);
		sendmsg(\'txtip\',tmparr[1]);
	}else{
		sendmsg(\'txtip\',data);
	}
	}, "html");	
}

function deltx(txid){
	if(confirm(\''.it618_tuan_getlang('s435').'\'))
	IT618_TUAN.get("'.$_G['siteurl'].'plugin.php?id=it618_tuan:ajax&txid="+txid+"&formhash='.FORMHASH.'", {ac:"tx_del"},function (data, textStatus){
	if(data=="ok"){
		gettxlist(url);
	}else{
		sendmsg(\'txtip\',data);	
	}
	}, "html");	
}

function sendmsg(msgid,msgvalue){
	document.getElementById(msgid).innerHTML=msgvalue;
	setTimeout(\'sendmsg1("\'+msgid+\'")\',8000);
}
function sendmsg1(msgid){
	document.getElementById(msgid).innerHTML="";
}

</script>
';

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>