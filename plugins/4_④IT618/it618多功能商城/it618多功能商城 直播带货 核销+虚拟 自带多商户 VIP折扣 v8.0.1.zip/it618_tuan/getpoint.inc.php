<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G,$it618_tuan;

$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';

$bdkey=trim($it618_tuan['tuan_bdkey']);

$mappoint=$_GET['mappoint'];
if($mappoint==''){
	$mappoint=it618_tuan_getlang('s464');
}

include template('it618_tuan:getpoint');
?>