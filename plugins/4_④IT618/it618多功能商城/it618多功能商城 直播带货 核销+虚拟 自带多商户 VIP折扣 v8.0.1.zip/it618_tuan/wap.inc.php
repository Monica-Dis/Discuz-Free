<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$metakeywords = $it618_tuan['seokeywords'];
$metadescription = $it618_tuan['seodescription'];
$sitetitle=$it618_tuan['seotitle'];

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

$waphome=it618_tuan_getrewrite('tuan_wap','','plugin.php?id=it618_tuan:wap');
$uurl=it618_tuan_getrewrite('tuan_wap','u@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=u');
$wapsearch=it618_tuan_getrewrite('tuan_wap','search@0','plugin.php?id=it618_tuan:wap&pagetype=search&cid=0');

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_tuan#it618_tuan_wapstyle')->count_by_isok_search();
$it618_tuan_wapstyle=C::t('#it618_tuan#it618_tuan_wapstyle')->fetch_by_isok_search();

if(isset($_GET['pagetype'])){
	$pagetypearray = array('tuan', 'shop', 'product', 'sc', 'sc_order', 'sc_gwc', 'thd', 'uc', 'uc_order', 'search', 'gwcsale', 'u');
	$pagetype = !in_array($_GET['pagetype'], $pagetypearray) ? 'tuan' : $_GET['pagetype'];
}else{
	$pagetype='tuan';
	$navtitle=$sitetitle;
}

if($it618_tuan['tuan_style']>2){
	$tuanstyle=getcookie('tuanstyle');
	if($tuanstyle==''){
		if($it618_tuan['tuan_style']==3)$tuanstyle='1';else $tuanstyle='2';
	}

	if($pagetype=='tuan'||$pagetype=='shop'||$pagetype=='search'){
		if($tuanstyle=='1')$tuanstyle1='2';else $tuanstyle1='1';
		$tuanstylestrtmp='<div class="style-btn" onClick="tuanstyle()"><i class="icon-style'.$tuanstyle1.'"></i></div>';
	}
}else{
	if($it618_tuan['tuan_style']==1)$tuanstyle='1';else $tuanstyle='2';
}

$gwcpcount=0;
$gwcurl=it618_tuan_getrewrite('tuan_wap','gwcsale@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=gwcsale');
if($_G['uid']>0){
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_tuan_getlang('s460').'</a></li>';
	$strusr='<a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="btn btn-weak">'.it618_tuan_getlang('s460').'</a> <a href="'.it618_tuan_rewriteurl($_G['uid']).'" target="_blank">'.it618_tuan_getusername($_G['uid']).'</a>';

	$gwcpcount=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid($_G['uid']);
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_tuan_bottomnav = DB::fetch($query)) {
	$it618_url=$it618_tuan_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$tmpurl=it618_tuan_getrewrite('tuan_wap','','plugin.php?id=it618_tuan:wap');
	$it618_url=str_replace("{waphome}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='index'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapsearch}",$it618_url);
	$tmpurl=it618_tuan_getrewrite('tuan_wap','search@0','plugin.php?id=it618_tuan:wap&pagetype=search&cid=0');
	$it618_url=str_replace("{wapsearch}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='search'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapgwc}",$it618_url);
	$tmpurl=it618_tuan_getrewrite('tuan_wap','gwcsale@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=gwcsale');
	$it618_url=str_replace("{wapgwc}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='gwcsale'){
			$iscur=1;
		}
	}
	
	if($it618_tuan_bottomnav['id']==5)$it618_url=it618_tuan_getrewrite('tuan_wap','u@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_tuan_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_tuan_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_tuan_bottomnav['it618_color'].'">'.$it618_tuan_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_tuan_bottomnav['it618_img'];
		$it618_title=$it618_tuan_bottomnav['it618_title'];
	}
	
	if($it618_tuan_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_tuan_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$wap=1;

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_tuan['tuan_appid']);
	$wx_secret=trim($it618_tuan['tuan_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){
	if($pagetype=='product'){
		$pid=intval($_GET['cid']);
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid);
		$wxshare_title=$it618_tuan_goods['it618_name'];
		$wxshare_imgUrl=it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_tuan_goods['it618_description'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
		
	}else{
		$wxshare_title=$it618_tuan['seotitle'];
		
		if($it618_tuan['tuan_wxlogo']!=''){
			$wxshare_imgUrl=$it618_tuan['tuan_wxlogo'];
		}else{
			$wxshare_imgUrl=$it618_tuan['tuan_logo'];
			$tmparr=explode('src="',$wxshare_imgUrl);
			$tmparr1=explode('"',$tmparr[1]);
			$wxshare_imgUrl=$tmparr1[0];
		}
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_tuan['seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_tuan_getrewrite('tuan_wap','','plugin.php?id=it618_tuan:wap');
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
	}
}

$wapbottomsubnav=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('wapbottomsubnavdefault');
$wapfooter=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('wapfooter');

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
	if($appurl=it618_members_apploginok($_GET['token'])){
		dheader("location:$appurl");
	}
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_wapad=it618_group_getad($_GET['id'],1);
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/wap/'.$pagetype.'.inc.php';
?>