<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return; /*Dism��taobao��com*/

loadcache('plugin');
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function/it618_tuan.func.php';

if($reabc[9]!='n')return;
$ppp = $it618_tuan['pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=0;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<=25;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[0]=$it618_tuan_lang['s559'];
$strtmptitle[1]=$it618_tuan_lang['s2'];
$strtmptitle[2]=$it618_tuan_lang['s3'];
$strtmptitle[3]=$it618_tuan_lang['s4'];
$strtmptitle[4]=$it618_tuan_lang['s5'];
$strtmptitle[5]=$it618_tuan_lang['s6'];
$strtmptitle[6]=$it618_tuan_lang['s7'];
$strtmptitle[7]=$it618_tuan_lang['s8'];
$strtmptitle[8]=$it618_tuan_lang['s9'];
$strtmptitle[9]=$it618_tuan_lang['s10'];
$strtmptitle[10]=$it618_tuan_lang['s11'];
$strtmptitle[11]=$it618_tuan_lang['s708'];
$strtmptitle[12]=$it618_tuan_lang['s709'];
$strtmptitle[13]=$it618_tuan_lang['s561'];
$strtmptitle[14]=$it618_tuan_lang['s710'];
$strtmptitle[16]=$it618_tuan_lang['s871'];
$strtmptitle[17]=$it618_tuan_lang['s872'];
$strtmptitle[18]=$it618_tuan_lang['s888'];
$strtmptitle[19]=$it618_tuan_lang['s889'];
$strtmptitle[20]=$it618_tuan_lang['s911'];
$strtmptitle[21]=$it618_tuan_lang['s1057'];
$strtmptitle[22]=$it618_tuan_lang['s1127'];
$strtmptitle[23]=$it618_tuan_lang['s1878'];
$strtmptitle[24]=$it618_tuan_lang['s1014'];
$strtmptitle[25]=$it618_tuan_lang['s817'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_hot&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>
<li '.$strtmp[14].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=14'.$urls.'"><span>'.$strtmptitle[14].'</span></a></li>
<li '.$strtmp[20].'><a href="'.$hosturl.'plugins&cp=admin_nav&cp1=20'.$urls.'"><span>'.$strtmptitle[20].'</span></a></li>
<li '.$strtmp[18].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=18'.$urls.'"><span>'.$strtmptitle[18].'</span></a></li>
<li '.$strtmp[16].'><a href="'.$hosturl.'plugins&cp=admin_gonggao&cp1=16'.$urls.'"><span>'.$strtmptitle[16].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=1'.$urls.'"><span>'.$strtmptitle[1].'</span></a></li>
<li '.$strtmp[25].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=25'.$urls.'"><span>'.$strtmptitle[25].'</span></a></li>
<li '.$strtmp[17].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=17'.$urls.'"><span>'.$strtmptitle[17].'</span></a></li>
<li '.$strtmp[24].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=24'.$urls.'"><span>'.$strtmptitle[24].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=2'.$urls.'"><span>'.$strtmptitle[2].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=3'.$urls.'"><span>'.$strtmptitle[3].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=4'.$urls.'"><span>'.$strtmptitle[4].'</span></a></li>
<li '.$strtmp[5].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=5'.$urls.'"><span>'.$strtmptitle[5].'</span></a></li>
<li '.$strtmp[6].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=6'.$urls.'"><span>'.$strtmptitle[6].'</span></a></li>
<li '.$strtmp[22].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=22'.$urls.'"><span>'.$strtmptitle[22].'</span></a></li>
<li '.$strtmp[7].'><a href="'.$hosturl.'plugins&cp=admin_rewrite&cp1=7'.$urls.'"><span>'.$strtmptitle[7].'</span></a></li>
<li '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_message&cp1=8'.$urls.'"><span>'.$strtmptitle[8].'</span></a></li>
<li '.$strtmp[10].'><a href="'.$hosturl.'plugins&cp=admin_txbl&cp1=10'.$urls.'"><span>'.$strtmptitle[10].'</span></a></li>
<li '.$strtmp[13].'><a href="'.$hosturl.'plugins&cp=admin_jfhl&cp1=13'.$urls.'"><span style="color:red">'.$strtmptitle[13].'</span></a></li>
<li '.$strtmp[11].'><a href="'.$hosturl.'plugins&cp=admin_kd&cp1=11'.$urls.'"><span>'.$strtmptitle[11].'</span></a></li>
<li '.$strtmp[12].'><a href="'.$hosturl.'plugins&cp=admin_kdarea&cp1=12'.$urls.'"><span>'.$strtmptitle[12].'</span></a></li>
<li '.$strtmp[19].'><a href="'.$hosturl.'plugins&cp=admin_diy&cp1=19'.$urls.'"><span>'.$strtmptitle[19].'</span></a></li>
<li '.$strtmp[21].'><a href="'.$hosturl.'plugins&cp=admin_shuadan&cp1=21'.$urls.'"><span>'.$strtmptitle[21].'</span></a></li>
<li '.$strtmp[23].'><a href="'.$hosturl.'plugins&cp=admin_aliyunoss&cp1=23'.$urls.'"><span>'.$strtmptitle[23].'</span></a></li>
</ul></div>';

$cparray = array('admin_hot', 'admin_set', 'admin_nav', 'admin_gonggao', 'admin_focus', 'admin_pay', 'admin_diy', 'admin_rewrite', 'admin_message', 'admin_txbl', 'admin_jfhl', 'admin_kd', 'admin_kdarea', 'admin_shuadan', 'admin_aliyunoss');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_hot' : $_GET['cp'];

if($cp1==0)$setname='hotclassgoods';
if($cp1==1)$setname='footer';
if($cp1==14)$setname='topnav';
if($cp1==18)$setname='rzabout';
if($cp1==22)$setname='waphomead';
if($cp1==25)$setname='wapfooter';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*Dism_taobao_com*/
?>