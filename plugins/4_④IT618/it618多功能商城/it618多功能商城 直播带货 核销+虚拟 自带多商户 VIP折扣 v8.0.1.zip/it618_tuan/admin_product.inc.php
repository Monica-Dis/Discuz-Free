<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return; /*Dism��taobao��com*/

loadcache('plugin');
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$creditname=$_G['setting']['extcredits'][$it618_tuan['tuan_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function/it618_tuan.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_product&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=0;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<12;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[0]=$it618_tuan_lang['s552'];
$strtmptitle[1]=$it618_tuan_lang['s553'];
$strtmptitle[2]=$it618_tuan_lang['s554'];
$strtmptitle[3]=$it618_tuan_lang['s555'];
$strtmptitle[4]=$it618_tuan_lang['s556'];
$strtmptitle[5]=$it618_tuan_lang['s557'];
$strtmptitle[6]=$it618_tuan_lang['s558'];
$strtmptitle[7]=$it618_tuan_lang['s824'];
$strtmptitle[8]=$it618_tuan_lang['s1719'];
$strtmptitle[9]=$it618_tuan_lang['s1685'];
$strtmptitle[10]=$it618_tuan_lang['s1707'];
$strtmptitle[11]=$it618_tuan_lang['s846'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_product&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_dhproduct_add&cp1=1'.$urls.'"><span style="color:blue">'.$strtmptitle[1].'</span></a></li>
<li '.$strtmp[2].' '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_dhproduct&cp1=2'.$urls.'"><span style="color:blue">'.$strtmptitle[2].'</span></a></li>
<li '.$strtmp[7].'><a href="'.$hosturl.'plugins&cp=admin_shopproduct_meal&cp1=7'.$urls.'"><span style="color:red">'.$strtmptitle[7].'</span></a></li>
<li '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_shopproduct_shopthd&cp1=8'.$urls.'"><span style="color:red">'.$strtmptitle[8].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_shopproduct_add&cp1=4'.$urls.'"><span style="color:red">'.$strtmptitle[4].'</span></a></li>
<li '.$strtmp[5].' '.$strtmp[6].' '.$strtmp[9].' '.$strtmp[10].' '.$strtmp[11].'><a href="'.$hosturl.'plugins&cp=admin_shopproduct&cp1=6'.$urls.'"><span style="color:red">'.$strtmptitle[6].'</span></a></li>
</ul></div>';

$cparray = array('admin_product', 'admin_dhproduct_add', 'admin_dhproduct', 'admin_shopproduct_meal', 'admin_shopproduct_add', 'admin_shopproduct', 'admin_dhproduct_edit', 'admin_shopproduct_edit', 'admin_shopproduct_km', 'admin_shopproduct_type', 'admin_shopproduct_shopthd', 'admin_shopproduct_thd');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_product' : $_GET['cp'];

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*Dism_taobao_com*/
?>