<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';

$it618_tuan_bank = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_bank')." where it618_shopid=".$ShopId);
if(submitcheck('it618submit')){
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_bank')." where it618_shopid=".$ShopId);
	if($count>0){
		C::t('#it618_tuan#it618_tuan_bank')->update($it618_tuan_bank['id'],array(
				'it618_name' => dhtmlspecialchars($_GET["it618_name"]),
				'it618_bankname' => dhtmlspecialchars($_GET["it618_bankname"]),
				'it618_bankid' => dhtmlspecialchars($_GET["it618_bankid"]),
				'it618_bankaddr' => dhtmlspecialchars($_GET["it618_bankaddr"]),
				'it618_alipayname' => dhtmlspecialchars($_GET["it618_alipayname"]),
				'it618_alipay' => dhtmlspecialchars($_GET["it618_alipay"]),
				'it618_wxname' => dhtmlspecialchars($_GET["it618_wxname"]),
				'it618_wx' => dhtmlspecialchars($_GET["it618_wx"])
		 ));
	}else{
		 C::t('#it618_tuan#it618_tuan_bank')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_name' => dhtmlspecialchars($_GET["it618_name"]),
				'it618_bankname' => dhtmlspecialchars($_GET["it618_bankname"]),
				'it618_bankid' => dhtmlspecialchars($_GET["it618_bankid"]),
				'it618_bankaddr' => dhtmlspecialchars($_GET["it618_bankaddr"]),
				'it618_alipayname' => dhtmlspecialchars($_GET["it618_alipayname"]),
				'it618_alipay' => dhtmlspecialchars($_GET["it618_alipay"]),
				'it618_wxname' => dhtmlspecialchars($_GET["it618_wxname"]),
				'it618_wx' => dhtmlspecialchars($_GET["it618_wx"])
		  ), true);
	}
	it618_cpmsg(it618_tuan_getlang('s290'), "plugin.php?id=it618_tuan:sc_bank", 'succeed');
}

it618_showformheader('plugin.php?id=it618_tuan:sc_bank');
showtableheaders(it618_tuan_getlang('s291'),'it618_tuan_bank');

if(in_array(2,(array)unserialize($it618_tuan['tuan_txtype'])))$txtype1=$it618_tuan_lang['s1129'];else $txtype1=$it618_tuan_lang['s1130'];
if(in_array(3,(array)unserialize($it618_tuan['tuan_txtype'])))$txtype2=$it618_tuan_lang['s1129'];else $txtype2=$it618_tuan_lang['s1130'];
if(in_array(4,(array)unserialize($it618_tuan['tuan_txtype'])))$txtype3=$it618_tuan_lang['s1129'];else $txtype3=$it618_tuan_lang['s1130'];

echo '
<script>
	function checkvalue(){
		var flag=0;
		if(document.getElementById("it618_alipayname").value!="")flag=flag+1;
		if(document.getElementById("it618_alipay").value!="")flag=flag+1;
		if(flag==1){
			alert("'.it618_tuan_getlang('s1134').'");
			return false;
		}
		
		var flag=0;
		if(document.getElementById("it618_wxname").value!="")flag=flag+1;
		if(document.getElementById("it618_wx").value!="")flag=flag+1;
		if(flag==1){
			alert("'.it618_tuan_getlang('s1135').'");
			return false;
		}
		
		var flag=0;
		if(document.getElementById("it618_name").value!="")flag=flag+1;
		if(document.getElementById("it618_bankname").value!="")flag=flag+1;
		if(document.getElementById("it618_bankid").value!="")flag=flag+1;
		if(document.getElementById("it618_bankaddr").value!="")flag=flag+1;
		if(flag==1){
			alert("'.it618_tuan_getlang('s296').'");
			return false;
		}
	}
</script>';

echo '
<tr><td colspan=2>'.it618_tuan_getlang('s297').'</td></tr>
<tr><td colspan=2><strong>'.it618_tuan_getlang('s305').' '.$txtype1.'</strong></td></tr>
<tr><td>'.it618_tuan_getlang('s306').'</td><td><input type="text" class="txt" style="width:300px" id="it618_alipayname" name="it618_alipayname" value="'.$it618_tuan_bank['it618_alipayname'].'"></td></tr>
<tr><td>'.it618_tuan_getlang('s307').'</td><td><input type="text" class="txt" style="width:300px" id="it618_alipay" name="it618_alipay" value="'.$it618_tuan_bank['it618_alipay'].'"></td></tr>
<tr><td colspan=2><strong>'.it618_tuan_getlang('s1131').' '.$txtype2.'</strong></td></tr>
<tr><td>'.it618_tuan_getlang('s1132').'</td><td><input type="text" class="txt" style="width:300px" id="it618_wxname" name="it618_wxname" value="'.$it618_tuan_bank['it618_wxname'].'"></td></tr>
<tr><td>'.it618_tuan_getlang('s1133').'</td><td><input type="text" class="txt" style="width:300px" id="it618_wx" name="it618_wx" value="'.$it618_tuan_bank['it618_wx'].'"></td></tr>
<tr><td colspan=2><strong>'.it618_tuan_getlang('s298').' '.$txtype3.'</strong></td></tr>
<tr><td width="100">'.it618_tuan_getlang('s299').'</td><td><input type="text" class="txt" style="width:300px" id="it618_name" name="it618_name" value="'.$it618_tuan_bank['it618_name'].'"></td></tr>
<tr><td>'.it618_tuan_getlang('s300').'</td><td><input type="text" class="txt" style="width:300px" id="it618_bankname" name="it618_bankname" value="'.$it618_tuan_bank['it618_bankname'].'"> '.it618_tuan_getlang('s301').'</td></tr>
<tr><td>'.it618_tuan_getlang('s302').'</td><td><input type="text" class="txt" style="width:300px" id="it618_bankid" name="it618_bankid" value="'.$it618_tuan_bank['it618_bankid'].'"></td></tr>
<tr><td>'.it618_tuan_getlang('s303').'</td><td><input type="text" class="txt" style="width:300px" id="it618_bankaddr" name="it618_bankaddr" value="'.$it618_tuan_bank['it618_bankaddr'].'"> '.it618_tuan_getlang('s304').'</td></tr>
<tr><td colspan="2"><input type="submit" class="btn" name="it618submit" value="'.it618_tuan_getlang('s308').'" onclick="return checkvalue()" /></td></tr>
';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>