<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsUnion,$IsCredits,$IsChat,$it618_tuan,$it618_hongbao_lang;

if(tuan_is_mobile())$wap=1;

if($IsUnion==1&&$pagetype=='shop'){
	$sql='it618_ison=1';
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('tuan',$it618_tuan_shop['id'],$sql);
	
	$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('tuan',$it618_tuan_shop['id'],$sql);
}

if($IsUnion==1&&$pagetype=='product'){
	$sql='it618_ison=1 and (it618_pids=\'\' or CONCAT(\',\',it618_pids,\',\') like \'%,'.$pid.',%\')';
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('tuan',$it618_tuan_goods['it618_shopid'],$sql);
	
	if($quancount>0){
		$shopquanurl=it618_tuan_getrewrite('tuan_shop',$it618_tuan_goods['it618_shopid'],'plugin.php?id=it618_tuan:shop&lid='.$it618_tuan_goods['it618_shopid'].'&quan','?quan');
		
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_money_by_shoptype_shopid('tuan',$it618_tuan_goods['it618_shopid'],$sql,'it618_money desc');
		if($union_quanmoney>0){
			$union_quan=$it618_union_lang['s1584'].$union_quanmoney.$it618_union_lang['s1585'];
		}
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_mjmoney_by_shoptype_shopid('tuan',$it618_tuan_goods['it618_shopid'],$sql,'it618_mjmoney2 desc');
		if($union_quanmoney['it618_mjmoney2']>0){
			$union_quan.=' '.$it618_union_lang['s1582'].$union_quanmoney['it618_mjmoney1'].$it618_union_lang['s1585'].$it618_union_lang['s1583'].$union_quanmoney['it618_mjmoney2'].$it618_union_lang['s1585'];
		}
	}
	
	$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('tuan',$it618_tuan_goods['it618_shopid'],$sql);
	if($tuicount>0){
		$union_tuitcbl=C::t('#it618_union#it618_union_tui')->fetch_tc_by_shoptype_shopid('tuan',$it618_tuan_goods['it618_shopid'],$sql,'it618_tcbl desc');
		$union_tuitc=$it618_union_lang['s1580'].str_replace(".00","",$union_tuitcbl).'%'.$it618_union_lang['s1581'];
	}
}

if($IsUnion==1){
	$tuipower=1;
	$tuiuid=intval($_GET['tuiuid']);
	if($tuiuid>0){
		$usercount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$tuiuid);
		if($usercount>0){
			$groupid=DB::result_first("select groupid from ".DB::table('common_member')." where uid=".$tuiuid);
			$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
			if(!in_array($groupid, $union_tuigroup)&&$union_tuigroup[0]!=''){
				$tuipower=0;
			}
		}
	}
	
	if($tuipower==1){
		if($it618_union['union_cookietime']==0)$union_cookietime=3600;else $union_cookietime=$it618_union['union_cookietime']*3600;
		dsetcookie('it618_union_tuiuid',$tuiuid,$union_cookietime);
	}
}

if($IsCredits==1){
	$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
	
	if(in_array(7,(array)unserialize($it618_hongbao['hongbao_power']))){
		$ishongbao=0;
		if($wap==1){
			if($pagetype=='tuan'||$pagetype=='search')$ishongbao=1;
		}else{
			if($pagetype=='index'||$pagetype=='list'||$pagetype=='search')$ishongbao=1;
		}
		
		if($ishongbao==1){
			$it618_hbtype='it618_tuan_admin';
			$tid=0;
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
				$shopadmin=explode(",",$it618_tuan['tuan_shopadmin']);
				if(in_array($_G['uid'],$shopadmin)){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
			include template('it618_hongbao:hongbao');
		}
	}
	
	if(in_array(8,(array)unserialize($it618_hongbao['hongbao_power']))){
		$ishongbao=0;
		if($pagetype=='shop')$ishongbao=1;
		
		if($ishongbao==1){
			$it618_hbtype='it618_tuan_shop';
			$tid=$it618_tuan_shop['id'];
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$shoptmp=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($tid);
				if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
			include template('it618_hongbao:hongbao');
		}
	}
}

if($pagetype=='shop'){
	if($it618_tuan_live=C::t('#it618_tuan#it618_tuan_live')->fetch_by_shopid($ShopId)){
		$videotype=$it618_tuan_live['it618_type'];
		if($it618_tuan_live['it618_name']=='')$videoname=$it618_tuan_lang['s1153'];else $videoname=$it618_tuan_live['it618_name'];
	}
}
if($pagetype=='product'){
	if($it618_tuan_live=C::t('#it618_tuan#it618_tuan_live')->fetch_by_shopid($it618_tuan_goods['it618_shopid'])){
		$ShopId=$it618_tuan_goods['it618_shopid'];
		$videotype=$it618_tuan_live['it618_type'];
		if($it618_tuan_live['it618_name']=='')$videoname=$it618_tuan_lang['s1153'];else $videoname=$it618_tuan_live['it618_name'];
	}
}

if($IsChat==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/function.func.php';
	
	$chatplugin='it618_tuan';
	if($pagetype=='product'){
		$chatsid=$it618_tuan_goods['it618_shopid'];
	}elseif($pagetype=='shop'){
		$chatsid=$ShopId;
	}else{
		$chatsid=0;
	}
	
	$it618_chat_kefu = it618_chat_getkefu($chatplugin,$chatsid,$wap);
}

if(($pagetype=='shop'||$pagetype=='product')&&$it618_chat_kefu==''){
	$tuan_kefu = $it618_tuan['tuan_kefu'];
	$tuan_kefu=explode(",",$tuan_kefu);

	if($it618_tuan_shop['it618_kefuqq']!=''){
		$qqarr=explode(",",$it618_tuan_shop['it618_kefuqq']);
		$qqnamearr=explode(",",$it618_tuan_shop['it618_kefuqqname']);
		for($i=0;$i<count($qqarr);$i++)
		{
			if($qqarr[$i]!='')$shopqq.='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="source/plugin/it618_tuan/images/qqbtnsmall.gif" align="absmiddle"/>'.$qqnamearr[$i].'</a> ';
			
			$shoprightqq.='<h3>'.$qqnamearr[$i].'</h3>
			<ul>
				<li><span>'.$it618_tuan_lang['s1060'].'</span>
				<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="source/plugin/it618_tuan/images/qqbtn.gif" align="absmiddle"/></a>
				</li>
			</ul>';
			
		}
		
	}
}
//From: Dism_taobao-com
?>