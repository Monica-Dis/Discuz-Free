<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';

$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($ShopId);
if(submitcheck('it618submit')){
	
	C::t('#it618_tuan#it618_tuan_shop')->update($ShopId,array(
		'it618_area1_id' => $_GET['it618_area1_id'],
		'it618_area2_id' => $_GET['it618_area2_id'],
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_tel' => dhtmlspecialchars($_GET['it618_tel']),
		'it618_qq' => dhtmlspecialchars($_GET['it618_qq']),
		'it618_addr' => dhtmlspecialchars($_GET['it618_addr']),
		'it618_dianhua' => dhtmlspecialchars($_GET['it618_dianhua']),
		'it618_mappoint' => dhtmlspecialchars($_GET['it618_mappoint']),
		'it618_logo' => dhtmlspecialchars($_GET['it618_logo']),
		'it618_tongji' => $_GET['it618_tongji'],
		'it618_adimg' => dhtmlspecialchars($_GET['it618_adimg']),
		'it618_adimgurl' => dhtmlspecialchars($_GET['it618_adimgurl']),
		'it618_about' => dhtmlspecialchars($_GET['it618_about']),
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	));
	
	if($IsChat!=1){
		C::t('#it618_tuan#it618_tuan_shop')->update($ShopId,array(
			'it618_yytime' => dhtmlspecialchars($_GET['it618_yytime']),
			'it618_kefuqq' => dhtmlspecialchars($_GET['it618_kefuqq']),
			'it618_kefuqqname' => dhtmlspecialchars($_GET['it618_kefuqqname'])
		));
	}

	it618_cpmsg(it618_tuan_getlang('s309'), "plugin.php?id=it618_tuan:sc_basicdata", 'succeed');
}

it618_showformheader("plugin.php?id=it618_tuan:sc_basicdata");
showtableheaders(it618_tuan_getlang('s310'),'it618_tuan_basicdata');

foreach(C::t('#it618_tuan#it618_tuan_area1')->fetch_all_by_search() as $it618_tmp) {
	$areatmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}
foreach(C::t('#it618_tuan#it618_tuan_area2')->fetch_all_by_it618_area1_id($it618_tuan_shop['it618_area1_id']) as $it618_tmp) {
	$areatmp2.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}
$areatmp1=str_replace('<option value='.$it618_tuan_shop['it618_area1_id'].'>','<option value='.$it618_tuan_shop['it618_area1_id'].' selected="selected">',$areatmp1);
$areatmp2=str_replace('<option value='.$it618_tuan_shop['it618_area2_id'].'>','<option value='.$it618_tuan_shop['it618_area2_id'].' selected="selected">',$areatmp2);

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_area1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_area1')." ORDER BY it618_order");
$n1=0;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=0;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_area2')." where it618_area1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_area['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_name'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_tuan/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_tuan/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_tuan/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=150'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_tuan/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true
		});
		KindEditor.ready(function(K) {
			var editor1 = K.create(\'textarea[name="it618_message"]\', {
				cssPath : \'source/plugin/it618_tuan/kindeditor/plugins/code/prettify.css\',
				uploadJson : \'source/plugin/it618_tuan/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=900'.$oss.'\',
				fileManagerJson : \'source/plugin/it618_tuan/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
				allowFileManager : true,
				filterMode:false
			});
		});
		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
		
		var editor1 = K.editor({
			uploadJson : \'source/plugin/it618_tuan/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=800'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_tuan/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true
		});
		K(\'#image2\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url2\').val(url);
						K(\'#img2\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
	});
	var arrcount='.$count.';
	var select_area = new Array(arrcount);
	
	for (i=0; i<arrcount; i++) 
	{
	 select_area[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_area(x)
	{
	 var temp = document.getElementById("it618_area2_id"); 
	 temp.options.length=0;
	 for (i=0;i<select_area[x].length;i++)
	 {
	  temp.options[i]=new Option(select_area[x][i].text,select_area[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	function checkvalue(){
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_tuan_getlang('s311').'");
			return false;
		}
		if(document.getElementById("it618_tel").value==""){
			alert("'.it618_tuan_getlang('s312').'");
			return false;
		}
		if(document.getElementById("it618_qq").value==""){
			alert("'.it618_tuan_getlang('s313').'");
			return false;
		}
		if(document.getElementById("it618_addr").value==""){
			alert("'.it618_tuan_getlang('s314').'");
			return false;
		}
	}
</script>

<tr><td width=90>'.it618_tuan_getlang('s315').'</td><td><select name="it618_area1_id" onchange="redirec_area(this.options.selectedIndex)">'.$areatmp1.'</select><select id="it618_area2_id"  name="it618_area2_id">'.$areatmp2.'</select> '.it618_tuan_getlang('s316').'</td></tr>
<tr><td>'.it618_tuan_getlang('s317').'</td><td><img id="img1" src="'.$it618_tuan_shop['it618_logo'].'" width="150" height="120" align="absmiddle"/> <input type="text" id="url1" name="it618_logo" readonly="readonly" value="'.$it618_tuan_shop['it618_logo'].'"/> <input type="button" id="image1" value="'.it618_tuan_getlang('s318').'" /> '.it618_tuan_getlang('s319').'</td></tr>

<tr><td>'.it618_tuan_getlang('s320').'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name" value="'.$it618_tuan_shop['it618_name'].'">'.it618_tuan_getlang('s316').' <font color="red">'.it618_tuan_getlang('s321').'</font></td></tr>
<tr><td><font color="red">'.it618_tuan_getlang('s322').'</font></td><td><input type="text" class="txt" style="width:252px" id="it618_tel" name="it618_tel" value="'.$it618_tuan_shop['it618_tel'].'"><font color="red">'.it618_tuan_getlang('s324').'</font><input type="text" class="txt" style="width:100px" id="it618_qq" name="it618_qq" value="'.$it618_tuan_shop['it618_qq'].'">'.it618_tuan_getlang('s323').'<font color="red"> '.it618_tuan_getlang('s321').' '.it618_tuan_getlang('s325').'</font></td></tr>
<tr><td>'.it618_tuan_getlang('s326').'</td><td><input type="text" class="txt" style="width:400px" id="it618_addr" name="it618_addr" value="'.$it618_tuan_shop['it618_addr'].'">'.it618_tuan_getlang('s316').' <font color="red">'.it618_tuan_getlang('s321').'</font></td></tr>
<tr><td>'.it618_tuan_getlang('s327').'</td><td><input type="text" class="txt" style="width:400px" name="it618_dianhua" value="'.$it618_tuan_shop['it618_dianhua'].'">'.it618_tuan_getlang('s316').'</td></tr>';

if($IsChat!=1){
echo '<tr><td>'.it618_tuan_getlang('s328').'</td><td><input type="text" class="txt" style="width:400px" name="it618_kefuqq" value="'.$it618_tuan_shop['it618_kefuqq'].'">'.it618_tuan_getlang('s316').' <font color="red">'.it618_tuan_getlang('s859').'</font></td></tr>
<tr><td>'.it618_tuan_getlang('s860').'</td><td><input type="text" class="txt" style="width:400px" name="it618_kefuqqname" value="'.$it618_tuan_shop['it618_kefuqqname'].'">'.it618_tuan_getlang('s316').' <font color="red">'.it618_tuan_getlang('s861').'</font></td></tr>
<tr><td>'.it618_tuan_getlang('s329').'</td><td><input type="text" class="txt" style="width:400px" name="it618_yytime" value="'.$it618_tuan_shop['it618_yytime'].'">'.it618_tuan_getlang('s316').'</td></tr>';
}

if($it618_tuan['tuan_bdkey']!=''){
	echo '<tr><td>'.it618_tuan_getlang('s330').'</td><td><iframe width="100%" height="450px" marginwidth="0" marginheight="0"  frameborder="no" scrolling="no"  src="'.$_G['siteurl'].'plugin.php?id=it618_tuan:getpoint&mappoint='.$it618_tuan_shop['it618_mappoint'].'"></iframe><input type="hidden" id="it618_mappoint" name="it618_mappoint" value="'.$it618_tuan_shop['it618_mappoint'].'"><input type="hidden" name="it618_adimg" value="'.$it618_tuan_shop['it618_adimg'].'"><input type="hidden" name="it618_adimgurl" value="'.$it618_tuan_shop['it618_adimgurl'].'"></td></tr>';
}else{
	echo '<tr><td>'.it618_tuan_getlang('s957').'</td><td><img id="img2" src="'.$it618_tuan_shop['it618_adimg'].'" width="348" height="282" align="absmiddle"/> <input type="text" id="url2" name="it618_adimg" readonly="readonly" value="'.$it618_tuan_shop['it618_adimg'].'"/> <input type="button" id="image2" value="'.it618_tuan_getlang('s318').'" /> '.it618_tuan_getlang('s958').'<input type="hidden" id="it618_mappoint" name="it618_mappoint" value="'.$it618_tuan_shop['it618_mappoint'].'"></td></tr>
		<tr><td>'.it618_tuan_getlang('s959').'</td><td><input type="text" class="txt" style="width:400px" name="it618_adimgurl" value="'.$it618_tuan_shop['it618_adimgurl'].'"></td></tr>
	';
}

echo '
<tr><td>'.it618_tuan_getlang('s820').'</td><td><textarea class="txt" style="width:400px;height:80px" name="it618_tongji">'.$it618_tuan_shop['it618_tongji'].'</textarea>'.it618_tuan_getlang('s819').'</td></tr>
<tr><td>'.it618_tuan_getlang('s331').'</td><td><textarea class="txt" style="width:666px;height:80px" name="it618_about">'.$it618_tuan_shop['it618_about'].'</textarea>'.it618_tuan_getlang('s316').' '.it618_tuan_getlang('s332').'</td></tr>
<tr><td>'.it618_tuan_getlang('t754').'</td><td><textarea name="it618_message" style="width:670px;height:390px;visibility:hidden;">'.$it618_tuan_shop['it618_message'].'</textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_tuan_getlang('s23').'" /></div></td></tr>';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>