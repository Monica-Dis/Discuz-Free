<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$metatitle = $it618_tuan['seotitle'];
$metakeywords = $it618_tuan['seokeywords'];
$metadescription = $it618_tuan['seodescription'];
$creditname=$_G['setting']['extcredits'][$it618_tuan['tuan_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

if($_G['uid']>0){
	C::t('#it618_tuan#it618_tuan_sale')->update_lastactivity_by_uid(TIMESTAMP,$_G['uid']);
	if(C::t('#it618_tuan#it618_tuan_shop')->count_by_it618_uid($_G['uid'])>0){
		$tmprz='<li>
					<a href="javascript:" class="renzheng"><font color=red>'.it618_tuan_getlang('s453').'</font></a> 
				</li>';
		if(C::t('#it618_tuan#it618_tuan_shop')->fetch_it618_state_by_it618_uid($_G['uid'])==2){
			$tmpurl=it618_tuan_getrewrite('tuan_sc','','plugin.php?id=it618_tuan:sc');
			$tmprz='<li>
						<a href="'.$tmpurl.'" target="_blank"><font color=red>'.it618_tuan_getlang('s454').'</font></a> 
					</li>';
		}
	}else{
		if($it618_tuan['tuan_isrzhide']==0){
			$tmprz='<li>
						<a href="javascript:" class="renzheng"><font color=red>'.it618_tuan_getlang('s455').'</font></a> 
					</li>';
		}
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		$it618_members = $_G['cache']['plugin']['it618_members'];
		if($it618_members['members_ishome']==1||$it618_members['members_ishome']==2){
			$tmpmembers='<li>
					<a href="javascript:" class="login-link" id="it618_members" style="color:#666"><img src="source/plugin/it618_members/images/logo.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px;" />'.$it618_members['members_homename'].'</a> 
					</li>';
		}
	}
	
	if($IsCredits==1){
		$tmpcredits='<li>
					<a href="javascript:" class="login-link" id="it618_credits" style="color:#666"><img src="source/plugin/it618_credits/images/ico.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px;" />'.it618_tuan_getlang('s960').'</a> 
					</li>';
	}
	
	if($IsGroup==1){
		$tmpgroup='<li>
					<a href="javascript:" class="login-link" id="it618_group" style="color:#666"><img src="source/plugin/it618_group/images/group.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px;" />'.it618_tuan_getlang('s1946').'</a> 
					</li>';
	}
	
	$count=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid($_G['uid']);
	if($count>0)$count='<font color=red>'.$count.'</font>';
	$gwcurl=it618_tuan_getrewrite('tuan_gwc','','plugin.php?id=it618_tuan:gwc');
	
	$usermenu='<ul class="login cl">
                <li class="login-link">'.$_G['username'].'</li>
				'.$tmpmembers.'
				'.$tmpcredits.'
				'.$tmpgroup.'
				<li style="padding-top:5px;"><a href="'.$gwcurl.'" target="_blank" style="color:#666"><img src="source/plugin/it618_tuan/images/gwc.png" style="vertical-align:middle;height:13px;margin-top:-1px"/> '.it618_tuan_getlang('t187').'(<span id="gwccount">'.$count.'</span>)</a></li>
                <li class="dropdown dropdown-account">
                    <p class="textwarp">
                        <em class="text">'.it618_tuan_getlang('s456').'</em>
                        <i class="triangle"></i>
                        <em class="account-num" style="display:none;"></em>
					</p>
                    <ul class="htul">
						<li>
						<a href="javascript:" id="mysale"><font color=green>'.it618_tuan_getlang('s457').'</font></a> 
				    	</li>
						<li>
						<a href="javascript:" id="myorder"><font color=#F60>'.it618_tuan_getlang('s999').'</font></a> 
				    	</li>
						'.$tmprz.'
                    </ul>
                </li>
                <li><a class="login-link" href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" style="color:#666">['.it618_tuan_getlang('s460').']</a></li>
			   </ul>';
}else{
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if($it618_members['members_isok']==1){
		$usermenu='<ul class="login cl">
                <li><a class="login-link it618_members_login" href="javascript:" style="color:#666">['.it618_tuan_getlang('s461').']</a></li>
                <li><a class="login-link it618_members_reg" href="javascript:" style="color:#666">['.it618_tuan_getlang('s462').']</a></li>    
               </ul>';
	}else{
		$usermenu='<ul class="login cl">
                <li><a class="login-link" href="member.php?mod=logging&action=login" style="color:#666">['.it618_tuan_getlang('s461').']</a></li>
                <li><a class="login-link" href="member.php?mod='.$RegName.'" style="color:#666">['.it618_tuan_getlang('s462').']</a></li>    
               </ul>';
	}
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	if(isset($_GET['reg']))$winapireg='winapireg';
	$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','',$winapireg);
}

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$it618_credits_buygroup=it618_credits_getcredits($_GET['id'],'#vippaybtn','plugin.php?id=it618_credits:do&dotype=buygroup');
	$it618_credits_index=it618_credits_getcredits($_GET['id'],'#it618_credits').$it618_credits_buygroup;
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_uc=it618_group_getgroup($_GET['id'],'#it618_group');
	$it618_group_ad=it618_group_getad($_GET['id'],2);
}
//From: Dism_taobao-com
?>