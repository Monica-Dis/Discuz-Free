<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

if($_G['uid']<=0){
	return;
}else{
	$rzpower=1;
	$tuan_rzpower=(array)unserialize($it618_tuan['tuan_rzpower']);
	$okvipgroupids=it618_tuan_getisvipuser($tuan_rzpower);
	if(count($okvipgroupids[0])==0){
		$rzpower=0;
	}else{
		if($it618_tuan['tuan_iscert']==1){
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
				if(C::t('#it618_members#it618_members_qyrz')->count_by_uid_rzok($_G['uid'])==0){
					$rzpower=2;
				}
			}
		}
	}
	
	foreach(C::t('#it618_tuan#it618_tuan_area1')->fetch_all_by_search() as $it618_tmp) {
		$areatmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
	
	$ispost=1;
	$username=C::t('#it618_tuan#it618_tuan_sale')->fetch_username_by_uid($_G['uid']);
	if(C::t('#it618_tuan#it618_tuan_shop')->count_by_it618_uid($_G['uid'])>0&&$_G['uid']>0){
		$t=it618_tuan_getlang('s472');
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid($_G['uid']);
		$it618_state=$it618_tuan_shop['it618_state'];
		if($it618_state==0){
			$statestr=it618_tuan_getlang('s473');
			$ispost=0;
		}elseif($it618_state==1){
			$statestr=it618_tuan_getlang('s474');
		}
		$tip="$username ".it618_tuan_getlang('s475')." ".date('Y-m-d H:i:s', $it618_tuan_shop['it618_time'])." ".it618_tuan_getlang('s476')."<font color=red>".$statestr."</font>";
		if($it618_state==2){
			$t=it618_tuan_getlang('s477');
			$tuan_sc=it618_tuan_getrewrite('tuan_sc','','plugin.php?id=it618_tuan:sc');
			$tip="$username ".it618_tuan_getlang('s478')."<br><a href='".$tuan_sc."' target='_blank'>".it618_tuan_getlang('s479')."</a>";
			$ispost=0;
		}
		
		$areatmp1=str_replace('<option value='.$it618_tuan_shop['it618_area1_id'].'>','<option value='.$it618_tuan_shop['it618_area1_id'].' selected="selected">',$areatmp1);
		
		foreach(C::t('#it618_tuan#it618_tuan_area2')->fetch_all_by_it618_area1_id($it618_tuan_shop['it618_area1_id']) as $it618_tmp) {
			$areatmp2.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
		}
		$areatmp2=str_replace('<option value='.$it618_tuan_shop['it618_area2_id'].'>','<option value='.$it618_tuan_shop['it618_area2_id'].' selected="selected">',$areatmp2);
		
		$it618_name=$it618_tuan_shop['it618_name'];
		$it618_tel=$it618_tuan_shop['it618_tel'];
		$it618_qq=$it618_tuan_shop['it618_qq'];
		$it618_addr=$it618_tuan_shop['it618_addr'];
		
		$rzpower=1;
		
	}else{
		$t=it618_tuan_getlang('s480');
		$tip="$username ".it618_tuan_getlang('s481');
	}
	
	if($rzpower==0||$rzpower==2){
		$ispost=0;
	}
	
	$btnname=$it618_tuan_lang['t79'];
	$oktip=$it618_tuan_lang['t80'];
	
	$rzabout=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('rzabout');
}

if($_GET['wap']==1){
	$height=$_GET['height']*0.8-36;
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:showrenzheng');
?>