<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

if($_G['uid']>0){
	$it618_gtypeid=intval($_GET['it618_gtypeid']);
	$it618_gthdid=intval($_GET['it618_gthdid']);
	$it618_count=intval($_GET['it618_count']);
	
	$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($_GET['pid']);
	
	if($_GET['saletype']==1){
		$saletypestr=it618_tuan_getlang('s719');
	}
	
	if($_GET['saletype']==2){
		$saletypestr=it618_tuan_getlang('s720');
	}
	
	if($_GET['saletype']==3){
		$saletypestr=it618_tuan_getlang('s836');
	}
	
	$name=C::t('#it618_tuan#it618_tuan_sale')->fetch_name_by_uid($_G['uid']);
	$tel=C::t('#it618_tuan#it618_tuan_sale')->fetch_tel_by_uid($_G['uid']);
	$addr=C::t('#it618_tuan#it618_tuan_sale')->fetch_addr_by_uid($_G['uid']);
	
	if($_GET['it618_kdid']>0){
		$it618_tuan_kdyunfei=C::t('#it618_tuan#it618_tuan_kdyunfei')->fetch_by_id($_GET['it618_kdid']);
		if($it618_count>$it618_tuan_kdyunfei['it618_firstcount']){
			$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice']+$it618_tuan_kdyunfei['it618_price']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
			$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore']+$it618_tuan_kdyunfei['it618_score']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
		}else{
			$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice'];
			$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore'];
		}
		
		if($yunfeiscore>0){
			$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
			$yunfeijfname=$_G['setting']['extcredits'][$it618_tuan_kdyunfei['it618_jfid']]['title'];
			$sumscore[$yunfeijfid]+=$yunfeiscore;
		}
	}
	
	if($it618_gthdid>0){
		$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_gthdid);
		$gthdname=$it618_tuan_shop_thd['it618_name'];
	}
	
	if($it618_gtypeid>0){
		if($it618_tuan_goods_type=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_idok($it618_gtypeid)){
			$goods_price=$it618_tuan_goods_type['it618_saleprice'];
			$goods_jfid=$it618_tuan_goods_type['it618_jfid'];
			$goods_score=$it618_tuan_goods_type['it618_score'];
			$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_gtypeid);
		}
	}else{
		$goods_price=$it618_tuan_goods['it618_saleprice'];
		$goods_jfid=$it618_tuan_goods['it618_jfid'];
		$goods_score=$it618_tuan_goods['it618_score'];
	}
	
	if($IsGroup==1){
		$vipzk=it618_tuan_getvipzk($_GET['pid']);
	}
	
	if($vipzk>0){
		$goods_price=round($goods_price*$vipzk/100,2);
		$goods_score=intval($goods_score*$vipzk/100);
	}
	
	if($vipzk>0){
		$zk=round(($vipzk/10),2);
		$zkstr=$zk.$it618_tuan_lang['s967'];
		
		$zkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:3px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px">'.$zkstr.'</span>';
	}
	
	$yfmoney=$goods_price*$it618_count+$yunfeimoney;
	if($goods_score>0){
		$sumscore[$goods_jfid]+=$goods_score*$it618_count;
	}
	
	if($it618_tuan_goods['it618_jfbl']>0&&$goods_price>0){
		$jfbl='<font color=#888>'.it618_tuan_getlang('s1049').'<font color=red>'.$it618_tuan_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
	}
	
	for($i=1;$i<=8;$i++){
		if($sumscore[$i]>0){
			$jfname=$_G['setting']['extcredits'][$i]['title'];
			
			$scorestr.='<em class="yf">'.$sumscore[$i].'</em> <em class="yf yfjfname" style="font-size:12px">'.$jfname.'</em><em class="yf">+</em>';
			
			$creditnum=C::t('#it618_tuan#it618_tuan_sale')->fetch_extcredits_by_uid($i,$_G['uid']);
			if($creditnum=="")$creditnum=0;
			$jfcounttmp.='<font color="red">'.$creditnum.'</font>'.$jfname;
		}
	}
	
	if($scorestr!=''){
		$scorestr.='@';
		$scorestr=str_replace('<em class="yf">+</em>@',"",$scorestr);
		
		$jfcountstr=$it618_tuan_lang['s532'].' '.$jfcounttmp;
	}
	
	if($yfmoney>0&&$scorestr!=''){
		$yfmoneystr='<em class="yf">&yen;</em> <em class="yf" id="yfmoney">'.$yfmoney.'</em><input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'"><em class="yf">+</em>'.$scorestr;
		$moneyscore=1;
	}else{
		if($yfmoney>0){
			$yfmoneystr='<em class="yf">&yen;</em> <em class="yf" id="yfmoney">'.$yfmoney.'</em><input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'">';
		}
		if($scorestr!=''){
			$yfmoneystr=$scorestr;
		}
	}
	
}

if($yfmoney>0){
	if($_GET['wap']==1){
		$it618paystr=it618_tuan_pay('paywap',$it618_tuan_lang['t357']);
	}else{
		$it618paystr=it618_tuan_pay('pay',$it618_tuan_lang['t357']);
	}
}

if($IsUnion==1){
	if($yfmoney>0){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
		
		$quanstr=it618_union_getquansale('tuan',$it618_tuan_goods['it618_shopid'],$_GET['wap'],$it618_tuan_goods['id'],$yfmoney);
	}else{
		$quanstr='<input type="hidden" id="quanid" value="0">';
	}
}

if($_GET['wap']==1){
	$height=$_GET['height']*0.8-48;
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:showpay');
?>