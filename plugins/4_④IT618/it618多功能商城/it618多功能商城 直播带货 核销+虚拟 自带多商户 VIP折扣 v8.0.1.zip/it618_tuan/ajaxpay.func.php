<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function pay_success($out_trade_no){
	global $_G;
	
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
		if($it618_salepay['it618_state']==1)return;
	}else{
		return;	
	}
	
	$salepay_saletype=$it618_salepay['it618_saletype'];
	$salepay_saleid=$it618_salepay['it618_saleid'];
	$salepay_paytype=$it618_salepay['it618_paytype'];
	$salepay_payid=$it618_salepay['it618_payid'];
	$salepay_url=$it618_salepay['it618_url'];
	$salepay_wap=$it618_salepay['it618_wap'];

	require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_tuan_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_tuan_delsalework();
		}
	}
	C::t('#it618_tuan#it618_tuan_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	
	if($salepay_saletype=='0601'){
		$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($salepay_saleid);
			
		if($it618_tuan_sale['it618_state']!=1){
			C::t('#it618_tuan#it618_tuan_sale')->update($salepay_saleid,array(
				'it618_state' => 1,
			));
			
			if($it618_tuan_sale['it618_tuijid']>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_tuan_sale['it618_tuijid'],$salepay_saleid);
			}
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			if($it618_tuan_sale['it618_saletype']==1)it618_tuan_setcode($it618_tuan_sale['id']);
			if($it618_tuan_sale['it618_saletype']==3)it618_tuan_setkm($it618_tuan_sale['id']);
			
			it618_tuan_updategoodscount($it618_tuan_sale);
			
			it618_tuan_delsalework();
	
			if($it618_tuan_sale['it618_saletype']==1){
				it618_tuan_sendmessage('sale_user',$it618_tuan_sale['id']);
			}else{
				it618_tuan_sendmessage('sale2_user',$it618_tuan_sale['id']);
			}
			if($it618_tuan_sale['it618_gthdid']>0){
				it618_tuan_sendmessage('sale_shop1',$it618_tuan_sale['id']);
			}
			it618_tuan_sendmessage('sale_shop',$it618_tuan_sale['id']);
			it618_tuan_sendmessage('sale_admin',$it618_tuan_sale['id']);
			
			if($it618_tuan_saleaudio=C::t('#it618_tuan#it618_tuan_saleaudio')->fetch_by_it618_shopid($it618_tuan_sale['it618_shopid'])){
				C::t('#it618_tuan#it618_tuan_saleaudio')->update($it618_tuan_saleaudio['id'],array(
					'it618_state' => 1
				));
			}else{
				C::t('#it618_tuan#it618_tuan_saleaudio')->insert(array(
					'it618_shopid' => $it618_tuan_sale['it618_shopid'],
					'it618_state' => 1
				), true);
			}
			
			return 'success';
		}
	
	}
	
	if($salepay_saletype=='0602'){
		$it618_tuan_gwcsale_main=C::t('#it618_tuan#it618_tuan_gwcsale_main')->fetch_by_id($salepay_saleid);
			
		if($it618_tuan_gwcsale_main['it618_state']!=1){
			C::t('#it618_tuan#it618_tuan_gwcsale_main')->update($salepay_saleid,array(
				'it618_state' => 1
			));
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			foreach(C::t('#it618_tuan#it618_tuan_gwcsale')->fetch_all_by_gwcid($salepay_saleid) as $it618_tuan_gwcsale) {
				
				if($IsUnion==1&&$it618_tuan_gwcsale['it618_tuijid']>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					$it618_tuijid=Union_IsTuiJoin('video',$it618_tuan_gwcsale['it618_pid'],$it618_tuan_gwcsale['it618_tuijid']);
				}
				
				$id = C::t('#it618_tuan#it618_tuan_sale')->insert(array(
					'it618_gwcid' => $salepay_saleid,
					'it618_shopid' => $it618_tuan_gwcsale['it618_shopid'],
					'it618_uid' => $it618_tuan_gwcsale['it618_uid'],
					'it618_pid' => $it618_tuan_gwcsale['it618_pid'],
					'it618_gthdid' => $it618_tuan_gwcsale['it618_gthdid'],
					'it618_gtypeid' => $it618_tuan_gwcsale['it618_gtypeid'],
					'it618_tuijid' => $it618_tuijid,
					'it618_saletype' => $it618_tuan_gwcsale['it618_saletype'],
					'it618_price' => $it618_tuan_gwcsale['it618_price'],
					'it618_jfid' => $it618_tuan_gwcsale['it618_jfid'],
					'it618_score' => $it618_tuan_gwcsale['it618_score'],
					'it618_yunfeijfid' => $it618_tuan_gwcsale['it618_yunfeijfid'],
					'it618_yunfeiscore' => $it618_tuan_gwcsale['it618_yunfeiscore'],
					'it618_quanmoney' => $it618_tuan_gwcsale['it618_quanmoney'],
					'it618_vipzk' => $it618_tuan_gwcsale['it618_vipzk'],
					'it618_sfmoney' => $it618_tuan_gwcsale['it618_sfmoney'],
					'it618_sfscore' => $it618_tuan_gwcsale['it618_sfscore'],
					'it618_jfbl' => $it618_tuan_gwcsale['it618_jfbl'],
					'it618_count' => $it618_tuan_gwcsale['it618_count'],
					'it618_yunfei' => $it618_tuan_gwcsale['it618_yunfei'],
					'it618_kdid' => $it618_tuan_gwcsale['it618_kdid'],
					'it618_name' => $it618_tuan_gwcsale['it618_name'],
					'it618_tel' => $it618_tuan_gwcsale['it618_tel'],
					'it618_addr' => $it618_tuan_gwcsale['it618_addr'],
					'it618_bz' => $it618_tuan_gwcsale['it618_bz'],
					'it618_isservice1' => $it618_tuan_gwcsale['it618_isservice1'],
					'it618_isservice2' => $it618_tuan_gwcsale['it618_isservice2'],
					'it618_isservice3' => $it618_tuan_gwcsale['it618_isservice3'],
					'it618_bsaletime' => $it618_tuan_gwcsale['it618_bsaletime'],
					'it618_esaletime' => $it618_tuan_gwcsale['it618_esaletime'],
					'it618_jfid' => $it618_tuan_gwcsale['it618_jfid'],
					'it618_score' => $it618_tuan_gwcsale['it618_score'],
					'it618_state' => 1,
					'it618_time' => $it618_tuan_gwcsale['it618_time']
				), true);
				
				if($it618_tuijid>0){
					Union_TuiTC_Add($it618_tuijid,$id);
				}
				
				$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
				
				if($it618_tuan_sale['it618_saletype']==1)it618_tuan_setcode($it618_tuan_sale['id']);
				if($it618_tuan_sale['it618_saletype']==3)it618_tuan_setkm($it618_tuan_sale['id']);

				it618_tuan_updategoodscount($it618_tuan_sale);
			}
			
			C::t('#it618_tuan#it618_tuan_gwcsale')->delete_by_uid($it618_tuan_gwcsale_main['it618_uid']);
			C::t('#it618_tuan#it618_tuan_gwc')->delete_by_uid($it618_tuan_gwcsale_main['it618_uid']);
			
			it618_tuan_delsalework();

			it618_tuan_sendmessage('gwc_user',$it618_tuan_gwcsale_main['id']);
			foreach(C::t('#it618_tuan#it618_tuan_sale')->fetch_all_shopid_by_gwcid($it618_tuan_gwcsale_main['id']) as $shopids) {
				it618_tuan_sendmessage('gwc_shop',$it618_tuan_gwcsale_main['id'],$shopids['it618_shopid']);
				
				if($it618_tuan_saleaudio=C::t('#it618_tuan#it618_tuan_saleaudio')->fetch_by_it618_shopid($shopids['it618_shopid'])){
					C::t('#it618_tuan#it618_tuan_saleaudio')->update($it618_tuan_saleaudio['id'],array(
						'it618_state' => 1
					));
				}else{
					C::t('#it618_tuan#it618_tuan_saleaudio')->insert(array(
						'it618_shopid' => $shopids['it618_shopid'],
						'it618_state' => 1
					), true);
				}
			}
			it618_tuan_sendmessage('gwc_admin',$it618_tuan_gwcsale_main['id']);
			
			return 'success';

		}
	
	}
	
	it618_tuan_delsalework();

}
//From: Dism_taobao-com
?>