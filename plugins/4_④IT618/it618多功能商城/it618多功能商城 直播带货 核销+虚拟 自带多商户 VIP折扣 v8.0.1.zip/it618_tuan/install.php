<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_tuan_shop`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_area1_id` int(10) unsigned NOT NULL,
  `it618_area2_id` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(200) NOT NULL,
  `it618_tel` varchar(200) NOT NULL,
  `it618_msgtel` varchar(20) NOT NULL,
  `it618_msgisok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_qq` varchar(200) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_kdaddr` varchar(20) NOT NULL,
  `it618_liyou` varchar(2000) NOT NULL,
  `it618_dianhua` varchar(200) NOT NULL,
  `it618_kefuqq` varchar(200) NOT NULL,
  `it618_kefuqqname` varchar(200) NOT NULL,
  `it618_kefuwx` varchar(200) NOT NULL,
  `it618_kefuwxname` varchar(200) NOT NULL,
  `it618_yytime` varchar(200) NOT NULL,
  `it618_mappoint` varchar(50) NOT NULL,
  `it618_logo` varchar(255) NOT NULL,
  `it618_adimg` varchar(255) NOT NULL,
  `it618_adimgurl` varchar(255) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_tongji` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_htstate` int(10) unsigned NOT NULL,
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '1000',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '5',
  `it618_messagecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isgoods` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islive` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_htetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_live`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_live` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islogin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ischat` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isip` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_livetype` varchar(50) NOT NULL,
  `it618_liveid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videourl` varchar(1000) NOT NULL,
  `it618_videoiframe` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_shop_thd`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_shop_thd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(200) NOT NULL,
  `it618_msgtel` varchar(20) NOT NULL,
  `it618_msgisok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addr` varchar(200) NOT NULL,
  `it618_dianhua` varchar(200) NOT NULL,
  `it618_kefuqq` varchar(200) NOT NULL,
  `it618_kefuqqname` varchar(200) NOT NULL,
  `it618_yytime` varchar(200) NOT NULL,
  `it618_mappoint` varchar(50) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_goods_thdtmp`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_goods_thdtmp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_thdid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_goods_thd`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_goods_thd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_thdid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_nav`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_area1`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_area1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_area2`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_area2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_area1_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_class1`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_class1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_classnamenav` varchar(10) NOT NULL,
  `it618_pj` varchar(255) NOT NULL,
  `it618_cssname` varchar(50) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL,
  `it618_wapgoodscount` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL DEFAULT '',
  `it618_url` varchar(255) NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_class2`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_class2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_meal`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_meal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_name` varchar(10) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_meal_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_mealname` varchar(255) NOT NULL,
  `it618_ptypename` varchar(255) NOT NULL,
  `it618_ptypename1` varchar(255) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL default 1,
  `it618_saletype` int(10) unsigned NOT NULL default 1,
  `it618_unit` varchar(10) NOT NULL,
  `it618_pcurl` varchar(255) NOT NULL,
  `it618_wapurl` varchar(255) NOT NULL,
  `it618_description` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_tsdatesygz` varchar(255) NOT NULL,
  `it618_yytx` varchar(255) NOT NULL,
  `it618_tbts` varchar(1000) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_bsaletime` varchar(20) NOT NULL,
  `it618_esaletime` varchar(20) NOT NULL,
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtime1` varchar(20) NOT NULL,
  `it618_xgtime2` varchar(20) NOT NULL,
  `it618_mincount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_maxcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isservice1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isservice2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isservice3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isorderbuy` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isbm` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issaledisplay` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isyunfeifree` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isthd` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_picbig` varchar(255) NOT NULL,
  `it618_picbig1` varchar(255) NOT NULL,
  `it618_picbig2` varchar(255) NOT NULL,
  `it618_picbig3` varchar(255) NOT NULL,
  `it618_picbig4` varchar(255) NOT NULL,
  `it618_picsmall` varchar(255) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_mealorder` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjpfstr` varchar(255) NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_goods_type`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_goods_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_name1` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_goods_km`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_goods_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_goods_type_km`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_goods_type_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_goods_salekm`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_goods_salekm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gthdid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL default 1,
  `it618_price` float(9,2) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_yunfeijfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_yunfeiscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_quanmoney` float(9,2) NOT NULL,
  `it618_vipzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tc` float(9,2) NOT NULL DEFAULT '0',
  `it618_isservice1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isservice2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isservice3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bsaletime` varchar(20) NOT NULL,
  `it618_esaletime` varchar(20) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_state_tuihuo` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ismessage` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(50) NOT NULL,
  `it618_paycode` varchar(50) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salejl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjjl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(20) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_salebz` varchar(2000) NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_hfcontent` varchar(2000) NOT NULL,
  `it618_pjtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuitcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tuitc` float(9,2) NOT NULL DEFAULT '0',
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_kddan` varchar(100) NOT NULL,
  `it618_content_tuihuo` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_saleaudio`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_saleaudio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_sale_pjpic`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_sale_pjpic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_pjpic` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_gwc`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_gwc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gthdid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_price` float(9,2) NOT NULL DEFAULT '0',
  `it618_pricescore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0',
  `it618_iseditprice` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_kdid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_gwcsale_main`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_gwcsale_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_moneybz` varchar(255) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_gwcsale`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_gwcsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gthdid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL default 1,
  `it618_price` float(9,2) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_quanmoney` float(9,2) NOT NULL,
  `it618_vipzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_isservice1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isservice2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isservice3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bsaletime` varchar(20) NOT NULL,
  `it618_esaletime` varchar(20) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_yunfeijfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_yunfeiscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(20) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_order`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gthdid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_jfcount` int(10) unsigned NOT NULL,
  `it618_name` varchar(20) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_kddan` varchar(100) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_bank`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_bankname` varchar(200) NOT NULL,
  `it618_bankid` varchar(50) NOT NULL,
  `it618_bankaddr` varchar(50) NOT NULL,
  `it618_alipayname` varchar(50) NOT NULL,
  `it618_alipay` varchar(100) NOT NULL,
  `it618_wxname` varchar(50) NOT NULL,
  `it618_wx` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_txbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_txbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_num1` int(10) unsigned NOT NULL,
  `it618_num2` int(10) unsigned NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_tx`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_tx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_bz` varchar(1000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_jfhl`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_jfhl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_hl` float(9,3) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_kd`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_kd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_kdcomid` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_kdarea`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_kdarea` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_kdyunfei`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_kdyunfei` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_kdareaid` int(10) unsigned NOT NULL,
  `it618_firstcount` int(10) unsigned NOT NULL,
  `it618_firstprice` float(9,2) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_firstscore` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_style`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_style` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_sql` varchar(200) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_findkey`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_tuan_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_tuan_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan_SC_GBK.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan_SC_UTF8.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan_TC_BIG5.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/discuz_plugin_it618_tuan_TC_UTF8.xml'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/language.TC_BIG5.php'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/language.TC_UTF8.php'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/upgrade.php'));
@unlink(DISCUZ_ROOT . base64_decode('./source/plugin/it618_tuan/install.php'));
?>