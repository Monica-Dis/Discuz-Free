<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/tuan_function.func.php';

if($pagetype=='search'){
	if($_GET['sw']==''||!isset($_GET['sw']))$searchsw=$it618_tuan['tuan_sw'];else $searchsw=dhtmlspecialchars($_GET['sw']);
}
if($searchsw!='')$sw=' style="display:none"';

$homeurl=it618_tuan_getrewrite('tuan_home','','plugin.php?id=it618_tuan:index');
$searchurl=it618_tuan_getrewrite('tuan_search','','plugin.php?id=it618_tuan:search');

$tuan_logo=str_replace("{homeurl}",$homeurl,$it618_tuan['tuan_logo']);

$tuan_hotsw=explode(',',$it618_tuan['tuan_hotsw']);
for($i=0;$i<count($tuan_hotsw);$i++){
	$tmpurl=it618_tuan_getrewrite('tuan_search','','plugin.php?id=it618_tuan:search&sw='.urlencode($tuan_hotsw[$i]),'?sw='.urlencode($tuan_hotsw[$i]));
	$hotsw.='<a href="'.$tmpurl.'">'.$tuan_hotsw[$i].'</a>';
}

$hotclassgoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('hotclassgoods');
$hotclassgoods=explode('@@@',$hotclassgoods);

$stylecount=C::t('#it618_tuan#it618_tuan_style')->count_by_isok();
$it618_tuan_style=C::t('#it618_tuan#it618_tuan_style')->fetch_by_isok();

$footer=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('footer');
$topnav=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('topnav');

foreach(C::t('#it618_tuan#it618_tuan_focus')->fetch_all_by_type_order(2) as $it618_tuan_focus) {
	if($it618_tuan_focus['it618_url']!=''){
		$str_focus2.='<li><a href="'.$it618_tuan_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="1200" height="63" /></a></li>';
	}else{
		$str_focus2.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="1200" height="63" /></li>';
	}
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." ORDER BY it618_order");
while($it618_tuan_class1 = DB::fetch($query1)) {
	if($it618_tuan_class1['it618_img']==''){
		$tmpurl=it618_tuan_getrewrite('tuan_list',$it618_tuan_class1['id'],'plugin.php?id=it618_tuan:list&class1='.$it618_tuan_class1['id']);
		$str_nav.='<a href="'.$tmpurl.'">'.$it618_tuan_class1['it618_classname'].'</a>';
		
		$str_class.='<div class="sort">
						<div class="sort-menu"><em class="sort-icon"></em><i class="'.$it618_tuan_class1['it618_cssname'].'"></i><a class="title '.$it618_tuan_class1['it618_cssname'].'" href="'.$tmpurl.'">'.cutstr($it618_tuan_class1['it618_classname'],18,'...').'</a>
							<p>
								{it618classtj}
							</p>
						  </div>
						  <div class="sort-con '.$it618_tuan_class1['it618_cssname'].'-top">
							<div class="sort-con-left">
								<h4><a href="'.$tmpurl.'">'.$it618_tuan_class1['it618_classname'].'</a></h4>
								<ul class="sort-link02 cl">
									{it618classall}
								</ul>
							</div>
						  </div>
					</div>';
		$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$it618_tuan_class1['id']." ORDER BY it618_order");
		$it618classtj='';$it618classall='';
		while($it618_tuan_class2 = DB::fetch($query2)) {
			if($it618_tuan_class2['it618_color']!="")
			$tmpname='<font color='.$it618_tuan_class2['it618_color'].'>'.$it618_tuan_class2['it618_classname'].'</font>';else $tmpname=$it618_tuan_class2['it618_classname'];
			
			$tmpurl=it618_tuan_getrewrite('tuan_list',$it618_tuan_class1['id'].'@'.$it618_tuan_class2['id'],'plugin.php?id=it618_tuan:list&class1='.$it618_tuan_class1['id'].'&class2='.$it618_tuan_class2['id']);
			if($it618_tuan_class2['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'">'.$tmpname.'</a>';
			$it618classall.='<li><a href="'.$tmpurl.'">'.$tmpname.'</a></li>';
			if($i1ii1[5]!='_')return;
		}
		
		$str_class=str_replace("{it618classtj}",$it618classtj,$str_class);
		$str_class=str_replace("{it618classall}",$it618classall,$str_class);
	}else{
		if($it618_tuan_class1['it618_url']!=''){
			$str_class.='<div class="sort">
						<a href="'.$it618_tuan_class1['it618_url'].'" target="_blank"><img src="'.$it618_tuan_class1['it618_img'].'" width="212" height="56" style="margin-left:2px"></a>
					</div>';
		}else{
			$str_class.='<div class="sort">
						<img src="'.$it618_tuan_class1['it618_img'].'" width="212" height="56" style="margin-left:2px">
					</div>';
		}
	}
}

$str_class.='<div class="sort-lottery">
				<div class="sort-menu" style="height:0;padding:0; margin:0"></div>
			 </div>';
			 
$count = C::t('#it618_tuan#it618_tuan_nav')->count_by_search1();
if($count>0){
	$str_nav='';
	foreach(C::t('#it618_tuan#it618_tuan_nav')->fetch_all_by_search1() as $it618_tuan_nav) {
		if($it618_tuan_nav['it618_color']!="")
		$tmpname='<font color='.$it618_tuan_nav['it618_color'].'>'.$it618_tuan_nav['it618_name'].'</font>';else $tmpname=$it618_tuan_nav['it618_name'];
		
		if($it618_tuan_nav['it618_target']==1)$it618_target=' target="_blank"';else $it618_target='';
		
		$str_nav.='<a href="'.$it618_tuan_nav['it618_url'].'"'.$it618_target.'>'.$tmpname.'</a>';
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>