<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

if($IsGoods==0){
	echo it618_tuan_getlang('s694');exit;
}

$pid=intval($_GET['pid']);
$preurl=$_GET['preurl'];
$urlsql='&pid='.$pid;
$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid);

if(submitcheck('it618submit')){
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		if($_GET['it618_isok'][$delid]==1){
			$tmpcount=C::t('#it618_tuan#it618_tuan_goods_thd')->count_by_pid_thdid($pid,$delid);
			if($tmpcount==0){
				C::t('#it618_tuan#it618_tuan_goods_thd')->insert(array(
					'it618_shopid' => $it618_tuan_goods['it618_shopid'],
					'it618_pid' => $pid,
					'it618_thdid' => $delid
				), true);
			}
		}else{
			C::t('#it618_tuan#it618_tuan_goods_thd')->delete_by_pid_thdid($pid,$delid);
		}
	}
	
	C::t('#it618_tuan#it618_tuan_goods')->update($pid,array(
		'it618_isthd' => $_GET['it618_isthd']
	));

	it618_cpmsg($it618_tuan_lang['s16'], "plugin.php?id=it618_tuan:sc_product_thd&pid=$pid&preurl=$preurl", 'succeed');
}

if($it618_tuan_goods['it618_isthd']==1)$it618_isthd_checked='checked="checked"';else $it618_isthd_checked="";

it618_showformheader("plugin.php?id=it618_tuan:sc_product_thd&pid=$pid&preurl=$preurl");
$preurl=str_replace("@","&",$preurl);
showtableheaders('<a href="'.$preurl.'"><font color=red>'.$it618_tuan_goods['it618_name'].'</font></a> '.$it618_tuan_lang['s1707'],'admin_shopproduct_thd');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_goods_thdtmp')." where it618_shopid=".$it618_tuan_goods['it618_shopid']);

echo '<tr><td colspan=15><font color=green><b>'.$it618_tuan_lang['s1726'].'</b></font><input class="checkbox" type="checkbox" name="it618_isthd" '.$it618_isthd_checked.' value="1"></td></tr>';
echo '<tr><td colspan=15>'.$it618_tuan_lang['s1710'].$count.'<span style="float:right;color:red">'.$it618_tuan_lang['s1711'].'</span></td></tr>';

showsubtitle(array($it618_tuan_lang['s56'], $it618_tuan_lang['s1708'], $it618_tuan_lang['s1709']));

$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods_thdtmp')." where it618_shopid=".$it618_tuan_goods['it618_shopid']);
while($it618_tuan_goods_thdtmp = DB::fetch($query)) {
	$it618_tuan_shop_thd = C::t('#it618_tuan#it618_tuan_shop_thd')->fetch_by_id($it618_tuan_goods_thdtmp['it618_thdid']);
	
	$tmpcount=C::t('#it618_tuan#it618_tuan_goods_thd')->count_by_pid_thdid($pid,$it618_tuan_shop_thd['id']);
	if($tmpcount>0)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";

	showtablerow('', array('class="td25"', '', ''), array(
		'<input class="checkbox" type="hidden" name="delete[]" value="'.$it618_tuan_shop_thd['id'].'">'.$it618_tuan_shop_thd['id'],
		$it618_tuan_shop_thd['it618_name'].' <a href="'.it618_tuan_rewriteurl($it618_tuan_shop_thd['it618_uid']).'" target="_blank">'.it618_tuan_getusername($it618_tuan_shop_thd['it618_uid']).'</a> '.$it618_tuan_shop_thd['it618_addr'].' '.$it618_tuan_shop_thd['it618_dianhua'],
		'<input class="checkbox" type="checkbox" id="chk_isok'.$it618_tuan_shop_thd['id'].'" name="it618_isok['.$it618_tuan_shop_thd['id'].']" '.$it618_isok_checked.' value="1"><label for="chk_isok'.$it618_tuan_shop_thd['id'].'">'.$it618_tuan_lang['s1712'].'</label>'
	));
}
	
	showsubmit('it618submit', 'submit', '', "<font color=red>".$it618_tuan_lang['s1723']."</font>");
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>