<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($_GET['saleid']);
$it618_tuan_goods=C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);

$pname=$it618_tuan_goods['it618_name'].' '.$it618_tuan_goods['it618_mealname'];

if($it618_tuan_sale['it618_uid']==$_G['uid']){
	$isok=1;
}else{
	$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_goods['it618_shopid']);
	if($it618_tuan_shop['it618_uid']==$_G['uid']){
		$isok=1;
	}
}

if($isok==1){
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods_salekm')." WHERE it618_saleid=".intval($_GET['saleid']));
	while($it618_tuan_goods_salekm = DB::fetch($query)) {
		$kmstr.=str_replace("{uid}",$_G['uid'],$it618_tuan_goods_salekm['it618_code'])."\n";
		$n=$n+1;
	}
	$km_str='<span style="font-size:12px">'.it618_tuan_getlang('s847').$n.'</span><br>';
	if($_GET['wap']!=1){
		$km_str.='<textarea style="width:600px; height:400px; margin-top:8px; float:left; padding:3px" readonly="readonly">'.dhtmlspecialchars($kmstr).'</textarea>';
	}else{
		$km_str.='<textarea style="width:97%; height:300px; margin-top:8px " readonly="readonly">'.dhtmlspecialchars($kmstr).'</textarea>';
	}
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:salekm');
?>