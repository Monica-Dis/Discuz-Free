<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

function it618_tuan_getmodecontent($modetype,$modecode,$modecount){
	global $_G;
	$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
	
	$tmparr=explode("[loop]",$modecode);
	$tmparr1=explode("[/loop]",$tmparr[1]);
	
	if($modetype=='product_new'||$modetype=='product_hot'){
		if($modetype=='product_new')$orderby='g.id desc';
		if($modetype=='product_hot')$orderby='g.it618_salecount desc';

		foreach(C::t('#it618_tuan#it618_tuan_goods')->fetch_all_by_search(
			'g.it618_state=1',$orderby,0,0,0,0,0,'',0,0,0,$modecount
		) as $it618_tuan_goods) {
			
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			$tmpstr=str_replace("{pname}",$it618_tuan_goods['it618_name'],$tmparr1[0]);
			$tmpstr=str_replace("{ppicsrc}",it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']),$tmpstr);
			$tmpstr=str_replace("{puprice}",$it618_tuan_goods['it618_saleprice'],$tmpstr);
			$tmpstr=str_replace("{pprice}",$it618_tuan_goods['it618_price'],$tmpstr);
			$tmpstr=str_replace("{pcount}",$it618_tuan_goods['it618_count'],$tmpstr);
			$tmpstr=str_replace("{pviews}",$it618_tuan_goods['it618_views'],$tmpstr);
			$tmpstr=str_replace("{psalecount}",$it618_tuan_goods['it618_salecount'],$tmpstr);
			$tmpstr=str_replace("{purl}",$tmpurl,$tmpstr);
			
			$content.=$tmpstr;
			
		}
	}
	
	if($modetype=='product_zj'||$modetype=='product_weekhot'){
		if($modetype=='product_zj'){	
			$query = DB::query("SELECT max(m.id) as maxid,m.it618_pid FROM ".DB::table('it618_tuan_sale')." m left join ".DB::table('it618_tuan_goods')." g on m.it618_pid=g.id left join ".DB::table('it618_tuan_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and m.it618_pid>0 GROUP BY m.it618_pid ORDER BY maxid desc limit 0,".$modecount);
		}
		
		if($modetype=='product_weekhot'){
			$tomonth = date('n'); 
			$todate = date('j'); 
			$toyear = date('Y');
			$time=mktime(0, 0, 0, $tomonth, $todate-7, $toyear);
			$query = DB::query("SELECT m.it618_pid,count(1) as salecount FROM ".DB::table('it618_tuan_sale')." m left join ".DB::table('it618_tuan_goods')." g on m.it618_pid=g.id left join ".DB::table('it618_tuan_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and m.it618_pid>0 and m.it618_time>=$time GROUP BY m.it618_pid ORDER BY salecount desc limit 0,".$modecount);
		}
		
		while($it618_homegoods = DB::fetch($query)) {
			$it618_tuan_goods=C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
			$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
			$tmpstr=str_replace("{pname}",$it618_tuan_goods['it618_name'],$tmparr1[0]);
			$tmpstr=str_replace("{ppicsrc}",it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']),$tmpstr);
			$tmpstr=str_replace("{puprice}",$it618_tuan_goods['it618_saleprice'],$tmpstr);
			$tmpstr=str_replace("{pprice}",$it618_tuan_goods['it618_price'],$tmpstr);
			$tmpstr=str_replace("{pcount}",$it618_tuan_goods['it618_count'],$tmpstr);
			$tmpstr=str_replace("{pviews}",$it618_tuan_goods['it618_views'],$tmpstr);
			$tmpstr=str_replace("{psalecount}",$it618_tuan_goods['it618_salecount'],$tmpstr);
			$tmpstr=str_replace("{purl}",$tmpurl,$tmpstr);
			
			$content.=$tmpstr;
		}
	}
	
	$content=$tmparr[0].$content.$tmparr1[1];
	$content=str_replace("{siteurl}",$_G['siteurl'],$content);
	
	return $content;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>