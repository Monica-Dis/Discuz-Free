<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/tuan_default.func.php';

if(tuan_is_mobile()){ 
	$tmpurl=it618_tuan_getrewrite('tuan_wap','','plugin.php?id=it618_tuan:wap');
	dheader("location:$tmpurl");
}

$tmpidsarr=explode(',',$hotclassgoods[0]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_tuan_class2=C::t('#it618_tuan#it618_tuan_class2')->fetch_by_id($id);
	$tmpurl=it618_tuan_getrewrite('tuan_list',$it618_tuan_class2['it618_class1_id'].'@'.$id,'plugin.php?id=it618_tuan:list&class1='.$it618_tuan_class2['it618_class1_id'].'&class2='.$id);
	$homehotclass.='<li><a href="'.$tmpurl.'">'.$it618_tuan_class2['it618_classname'].'</a></li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_area1')." ORDER BY it618_order");
while($it618_tuan_area1 = DB::fetch($query)) {
	$tmpurl=it618_tuan_getrewrite('tuan_list','0@0@'.$it618_tuan_area1['id'].'@0','plugin.php?id=it618_tuan:list&class1=0&class2=0&area1='.$it618_tuan_area1['id'].'&area2=0');
	$str_area1.='<li><a href="'.$tmpurl.'">'.$it618_tuan_area1['it618_name'].'</a></li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_tuan_gonggao = DB::fetch($query)) {
	$it618_title=$it618_tuan_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,80,'...');
	
	if($it618_tuan_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_tuan_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_tuan_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_tuan_gonggao['it618_url'].'" target="_blank" title="'.$it618_tuan_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

$tmpidsarr=explode(',',$hotclassgoods[2]);
$n=1;
for($i=1;$i<=count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i-1]);
	$it618_tuan_goods=C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($id);
	if($it618_tuan_goods['it618_state']==1){
		if($it618_tuan_goods['it618_shopid']>0)$shopaddr = DB::result_first("SELECT it618_addr FROM ".DB::table('it618_tuan_shop')." WHERE id=".$it618_tuan_goods['it618_shopid']);
		
		$pj=$it618_tuan_goods['it618_pjpfstr'];
		$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
		
		if($n%2>0){$homehotgoods.='<li>';$tmpfloat='fl';}else{$tmpfloat='fr';}
		$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
		$homehotgoods.='<div class="big-goods '.$tmpfloat.'">
							  <a class="big-goods-img" href="'.$tmpurl.'" target="_blank"><img src="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" alt="'.$it618_tuan_goods['it618_name'].'" width="340" height="276" /><span class="big-goods-place">'.$shopaddr.'</span></a>
							  <div class="big-goods-info">
								  <h3>
									  <span class="ti"><a class="big-goods-name" href="'.$tmpurl.'" target="_blank">'.$it618_tuan_goods['it618_name'].'</a></span>
									  <div style="font-weight:normal;font-size:12px;"><p style="float:right">'.it618_tuan_getlang('s465').$it618_tuan_goods['it618_salecount'].'</p>'.$pj.' '.$views.'</div>
								  </h3>
								  <div class="big-goods-price">
									  <span class="price">'.it618_tuan_getgoodsprice($it618_tuan_goods).'</span>
								  </div>
							  </div>
						  </div>';
		if($n==count($tmpidsarr)||$n%2==0)$homehotgoods.='</li>';
		$n=$n+1;
	}
}

foreach(C::t('#it618_tuan#it618_tuan_focus')->fetch_all_by_type_order(17) as $it618_tuan_focus) {
	if($it618_tuan_focus['it618_url']!=''){
		$str_focus.='<li class="swiper-slide"><a href="'.$it618_tuan_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="705" height="358" /></a></li>';
	}else{
		$str_focus.='<li class="swiper-slide"><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="705" height="358" /></li>';
	}
}

foreach(C::t('#it618_tuan#it618_tuan_focus')->fetch_all_by_type_order(3) as $it618_tuan_focus) {
	if($it618_tuan_focus['it618_url']!=''){
		$str_focus3.='<li class="swiper-slide"><a href="'.$it618_tuan_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="223" height="256" /></a></li>';
	}else{
		$str_focus3.='<li class="swiper-slide"><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="223" height="256" /></li>';
	}
}

foreach(C::t('#it618_tuan#it618_tuan_focus')->fetch_all_by_type_order(4) as $it618_tuan_focus) {
	if($it618_tuan_focus['it618_url']!=''){
		$str_focus4.='<li class="swiper-slide"><a href="'.$it618_tuan_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="223" height="256" /></a></li>';
	}else{
		$str_focus4.='<li class="swiper-slide"><img class="dynload lsSwitchload" src="source/plugin/it618_tuan/images/a.gif" imgsrc="'.$it618_tuan_focus['it618_img'].'" width="223" height="256" /></li>';
	}
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class1')." where it618_img='' and it618_goodscount>0 ORDER BY it618_order");
while($it618_tuan_class1 = DB::fetch($query1)) {
	
	if($it618_tuan_class1['it618_goodscount']==0)continue;
	
	$str_classnav.='<li><a href="javascript:void(0);" class="'.$it618_tuan_class1['it618_cssname'].' newga ga">'.$it618_tuan_class1['it618_classnamenav'].'</a></li>';
	
	$tmpurl=it618_tuan_getrewrite('tuan_list',$it618_tuan_class1['id'],'plugin.php?id=it618_tuan:list&class1='.$it618_tuan_class1['id']);
	$str_goods.='<div class="index-floor">
					<h2 class="index-floor-title">
						<i class="'.$it618_tuan_class1['it618_cssname'].'"></i><a class="'.$it618_tuan_class1['it618_cssname'].'" href="'.$tmpurl.'">'.$it618_tuan_class1['it618_classname'].'</a>
						<div class="fr">
							{it618classtj}
							<a href="'.$tmpurl.'" target="_blank">'.it618_tuan_getlang('s466').'&nbsp;<em>&gt;&gt;</em></a>
						</div>
					</h2>
					<div class="index-goods-list cl">
						{it618goods}
					</div>
					<div class="floor-more"><a href="'.$tmpurl.'">'.it618_tuan_getlang('s467').$it618_tuan_class1['it618_classname'].'&nbsp;&gt;&gt;</a></div>
				</div>';
	$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_class2')." where it618_class1_id=".$it618_tuan_class1['id']." ORDER BY it618_order");
	$it618classtj='';
	while($it618_tuan_class2 = DB::fetch($query2)) {
		if($it618_tuan_class2['it618_color']!="")
		$tmpname='<font color='.$it618_tuan_class2['it618_color'].'>'.$it618_tuan_class2['it618_classname'].'</font>';else $tmpname=$it618_tuan_class2['it618_classname'];
		
		$tmpurl=it618_tuan_getrewrite('tuan_list',$it618_tuan_class1['id'].'@'.$it618_tuan_class2['id'],'plugin.php?id=it618_tuan:list&class1='.$it618_tuan_class1['id'].'&class2='.$it618_tuan_class2['id']);
		if($it618_tuan_class2['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'" target="_blank">'.$tmpname.'</a><span></span>';

		if($i1ii1[5]!='_')return;
	}
	
	$it618goods='';
	foreach(C::t('#it618_tuan#it618_tuan_goods')->fetch_all_by_search(
		'g.it618_state=1','g.it618_order desc,g.id desc',0,$it618_tuan_class1['id'],0,0,0,'',0,0,$startlimit,$it618_tuan_class1['it618_goodscount']
	) as $it618_tuan_goods) {
		if($it618_tuan_goods['it618_meal_id']>0)$merger='<em class="merger iepng"></em>';else $merger='';
		if($it618_tuan_goods['it618_isservice3']==1)$reserve='<em class="reserve iepng"></em>';else $reserve='';
		if($merger!=''||$reserve!='')$goodsmark='<span class="goods-mark">'.$merger.$reserve.'</span>';else $goodsmark='';
		$shopaddr = DB::result_first("SELECT it618_addr FROM ".DB::table('it618_tuan_shop')." WHERE id=".$it618_tuan_goods['it618_shopid']);
		
		$pj=$it618_tuan_goods['it618_pjpfstr'];
		$views=' '.it618_tuan_getlang('s118').''.$it618_tuan_goods['it618_views'];
		
		$jfbl='';
		if($it618_tuan_goods['it618_jfbl']>0&&$it618_tuan_goods['it618_saleprice']>0){
			if(C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($it618_tuan_goods['id'])>0){
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').str_replace(".00","",$it618_tuan_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}else{
				$jfbl='<div class="divjfbl">'.it618_tuan_getlang('s931').intval($it618_tuan_goods['it618_saleprice']*$it618_tuan_goods['it618_jfbl']/100).$creditname.'</div>';
			}
		}
		
		$tmpurl=it618_tuan_getrewrite('tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
		$it618goods.='<div class="index-goods">
							'.$jfbl.'
							<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
								<img class="dynload lsSwitchload" imgsrc="'.it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']).'" src="source/plugin/it618_tuan/images/a.gif" alt="'.$it618_tuan_goods['it618_name'].'"/>
								<span class="index-goods-place">'.$shopaddr.'</span>
								'.$goodsmark.'
							</a>
							<h3>
								<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_tuan_goods['it618_name'].'">'.$it618_tuan_goods['it618_name'].'</a>
								<div style="font-weight:normal;font-size:12px;"><p style="float:right">'.it618_tuan_getlang('s465').$it618_tuan_goods['it618_salecount'].'</p>'.$pj.' '.$views.'</div>
							</h3>
							<div class="index-goods-info">
								<span class="price">'.it618_tuan_getgoodsprice($it618_tuan_goods).'</span>
							</div>
						</div>';
		
		if($i1ii1[6]!='t')return;
	}
	
	$str_goods=str_replace("{it618classtj}",$it618classtj,$str_goods);
	$str_goods=str_replace("{it618goods}",$it618goods,$str_goods);
}

$zjsalegoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('weeksalegoods');
$newgoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('newgoods');
$hotgoods=C::t('#it618_tuan#it618_tuan_set')->getsetvalue_by_setname('hotgoods');

$tmparr=explode(",",$zjsalegoods);
if(count($tmparr)>2){
	$zjsalegoods_count=$tmparr[0];
	$zjsalegoods_order=$tmparr[2];
}else{
	$zjsalegoods_count=15;
	$zjsalegoods_order=1;
}

$tmparr=explode(",",$weeksalegoods);
if(count($tmparr)>2){
	$weeksalegoods_count=$tmparr[0];
	$weeksalegoods_order=$tmparr[2];
}else{
	$weeksalegoods_count=15;
	$weeksalegoods_order=2;
}

$tmparr=explode(",",$newgoods);
if(count($tmparr)>2){
	$newgoods_count=$tmparr[0];
	$newgoods_order=$tmparr[2];
}else{
	$newgoods_count=15;
	$newgoods_order=3;
}

$tmparr=explode(",",$hotgoods);
if(count($tmparr)>2){
	$hotgoods_count=$tmparr[0];
	$hotgoods_order=$tmparr[2];
}else{
	$hotgoods_count=15;
	$hotgoods_order=4;
}

if(!($zjsalegoods_count==0&&$weeksalegoods_count==0&&$newgoods_count==0&&$hotgoods_count==0)){

	$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newgoods"=>$newgoods_order,"hotgoods"=>$hotgoods_order);
	asort($homegoods_arr);
	
	$n=1;
	foreach($homegoods_arr as $key=>$homegoods){
		if($n==1)$current=' class="current" ';else $current=' ';
		if($key=='zjsalegoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-new"),\'rc-new\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-new" onclick="tabCutover(this,\'rc-new\');get_home_goods(\''.$key.'\');" title="'.$it618_tuan_lang['t90'].'">'.$it618_tuan_lang['t91'].'<i></i></span>';
		}
		
		if($key=='weeksalegoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-week"),\'re-week\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-week" onclick="tabCutover(this,\'re-week\');get_home_goods(\''.$key.'\');" title="'.$it618_tuan_lang['t92'].'">'.$it618_tuan_lang['t93'].'<i></i></span>';
		}
		
		if($key=='newgoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-newjf"),\'re-newjf\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-re-newjf" onclick="tabCutover(this,\'re-newjf\');get_home_goods(\''.$key.'\');" title="'.$it618_tuan_lang['t312'].'">'.$it618_tuan_lang['s989'].'<i></i></span>';
		}
		
		if($key=='hotgoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-hotjf"),\'re-hotjf\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-re-hotjf" onclick="tabCutover(this,\'re-hotjf\');get_home_goods(\''.$key.'\');" title="'.$it618_tuan_lang['t313'].'">'.$it618_tuan_lang['s990'].'<i></i></span>';
		}
		$n=$n+1;
	
		if($key=='zjsalegoods'){
			$home_goods.='<div class="rc-new" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='weeksalegoods'){
			$home_goods.='<div class="re-week" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='newgoods'){
			$home_goods.='<div class="re-newjf" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='hotgoods'){
			$home_goods.='<div class="re-hotjf" id="home_goods_'.$key.'"></div>';
		}
	}

	$homegoods_str='<div class="recommend-goods">
			<div class="recommend-title">
				'.$tab_goods.'
			</div>
			<div class="recommend-content">
				'.$home_goods.'
			</div>
			</div>';
}

$pagetype='index';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
include template('it618_tuan:tuan_default');
?>