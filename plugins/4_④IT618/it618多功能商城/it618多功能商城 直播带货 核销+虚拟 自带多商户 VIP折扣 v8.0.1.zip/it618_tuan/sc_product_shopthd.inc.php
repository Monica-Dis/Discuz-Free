<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';

if($IsGoods==0){
	echo it618_tuan_getlang('s694');exit;
}

if(submitcheck('it618submit')){
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		if($_GET['it618_isok'][$delid]==1){
			$tmpcount=C::t('#it618_tuan#it618_tuan_goods_thdtmp')->count_by_shopid_thdid($ShopId,$delid);
			if($tmpcount==0){
				C::t('#it618_tuan#it618_tuan_goods_thdtmp')->insert(array(
					'it618_shopid' => $ShopId,
					'it618_thdid' => $delid
				), true);
			}
		}else{
			C::t('#it618_tuan#it618_tuan_goods_thdtmp')->delete_by_shopid_thdid($ShopId,$delid);
		}
	}

	it618_cpmsg($it618_tuan_lang['s16'], "plugin.php?id=it618_tuan:sc_product_shopthd", 'succeed');
}

it618_showformheader("plugin.php?id=it618_tuan:sc_product_shopthd");
$preurl=str_replace("@","&",$preurl);
showtableheaders($it618_tuan_lang['s1716'],'sc_product_shopthd');

$shopuid=C::t('#it618_tuan#it618_tuan_shop')->fetch_it618_uid_by_id($ShopId);

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_shop_thd')." WHERE it618_uid!=$shopuid");

echo '<tr><td colspan=15>'.$it618_tuan_lang['s1710'].$count.'<span style="float:right;color:red">'.$it618_tuan_lang['s1721'].'</span></td></tr>';

showsubtitle(array($it618_tuan_lang['s56'], $it618_tuan_lang['s1708'], $it618_tuan_lang['s1720']));

$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_shop_thd')." WHERE it618_uid!=$shopuid ORDER BY it618_order desc");
while($it618_tuan_shop_thd = DB::fetch($query)) {
	
	$tmpcount1=C::t('#it618_tuan#it618_tuan_goods_thdtmp')->count_by_shopid_thdid($ShopId,$it618_tuan_shop_thd['id']);
	if($tmpcount1>0)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
	
	$tmpcount2=C::t('#it618_tuan#it618_tuan_goods_thd')->count_by_shopid_thdid($ShopId,$it618_tuan_shop_thd['id']);
	$disabled="";
	if($tmpcount1>0&&$tmpcount2>0)$disabled="disabled=\"disabled\"";
	
	showtablerow('', array('class="td25"', '', ''), array(
		'<input class="checkbox" type="hidden" name="delete[]" value="'.$it618_tuan_shop_thd['id'].'">'.$it618_tuan_shop_thd['id'],
		$it618_tuan_shop_thd['it618_name'].' <a href="'.it618_tuan_rewriteurl($it618_tuan_shop_thd['it618_uid']).'" target="_blank">'.it618_tuan_getusername($it618_tuan_shop_thd['it618_uid']).'</a> '.$it618_tuan_shop_thd['it618_addr'].' '.$it618_tuan_shop_thd['it618_dianhua'],
		'<input class="checkbox" type="checkbox" id="chk_isok'.$it618_tuan_shop_thd['id'].'" name="it618_isok['.$it618_tuan_shop_thd['id'].']" '.$it618_isok_checked.' '.$disabled.' value="1"><label for="chk_isok'.$it618_tuan_shop_thd['id'].'">'.$it618_tuan_lang['s1712'].'</label>'
	));
}
	
	showsubmit('it618submit', 'submit', '');
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>