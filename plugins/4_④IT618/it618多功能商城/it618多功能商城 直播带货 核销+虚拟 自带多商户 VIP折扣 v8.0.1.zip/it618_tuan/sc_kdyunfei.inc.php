<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_header.func.php';

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_kd'))==0){
	it618_cpmsg(it618_tuan_getlang('s609'), "plugin.php?id=it618_tuan:sc_kdyunfei", 'error');
}

$n=1;
$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_kd')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$kdtmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	if(isset($_GET['kdid'])){
		if($_GET['kdid']==$it618_tmp['id']){
			$licss='class="current"';
			$kdid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}else{
		if($n==1){
			$licss='class="current"';
			$kdid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_kdyunfei')." WHERE it618_shopid=".$ShopId." and it618_kdid=".$it618_tmp['id']);
	
	$submenu.='<li '.$licss.'><a href="plugin.php?id=it618_tuan:sc_kdyunfei&kdid='.$it618_tmp['id'].'"><span>'.$it618_tmp['it618_name'].'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$n=$n+1;
}
$kdtmpsel=str_replace('<option value='.$kdid.'>','<option value='.$kdid.' selected="selected">',$kdtmp);
echo '<div class="itemtitle" style="width:100%;margin-bottom:0px;margin-top:10px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';

$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_kdarea')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$kdareatmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

if(submitcheck('it618submit_dao')){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_kdarea')." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_tuan_kdyunfei')." WHERE it618_shopid=".$ShopId." and it618_kdid=".$kdid." and it618_kdareaid=".$it618_tmp['id'])==0){
			C::t('#it618_tuan#it618_tuan_kdyunfei')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_kdid' => $kdid,
				'it618_kdareaid' => $it618_tmp['id'],
				'it618_order' => 0,
			), true);
		}
	}
}

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_tuan_kdyunfei', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_kdid'])) {
		foreach($_GET['it618_kdid'] as $id => $val) {
			
			$it618_firstscore=$_GET['it618_firstscore'][$id];
			$it618_score=$_GET['it618_score'][$id];
			if($_GET['it618_jfid'][$id]==0){$it618_firstscore=0;$it618_score=0;}

			C::t('#it618_tuan#it618_tuan_kdyunfei')->update($id,array(
				'it618_kdid' => trim($_GET['it618_kdid'][$id]),
				'it618_kdareaid' => trim($_GET['it618_kdareaid'][$id]),
				'it618_firstcount' => trim($_GET['it618_firstcount'][$id]),
				'it618_firstprice' => trim($_GET['it618_firstprice'][$id]),
				'it618_price' => trim($_GET['it618_price'][$id]),
				'it618_firstscore' => $it618_firstscore,
				'it618_score' => $it618_score,
				'it618_jfid' => trim($_GET['it618_jfid'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_kdid_array = !empty($_GET['newit618_kdid']) ? $_GET['newit618_kdid'] : array();
	$newit618_kdareaid_array = !empty($_GET['newit618_kdareaid']) ? $_GET['newit618_kdareaid'] : array();
	$newit618_firstcount_array = !empty($_GET['newit618_firstcount']) ? $_GET['newit618_firstcount'] : array();
	$newit618_firstprice_array = !empty($_GET['newit618_firstprice']) ? $_GET['newit618_firstprice'] : array();
	$newit618_price_array = !empty($_GET['newit618_price']) ? $_GET['newit618_price'] : array();
	$newit618_firstscore_array = !empty($_GET['newit618_firstscore']) ? $_GET['newit618_firstscore'] : array();
	$newit618_score_array = !empty($_GET['newit618_score']) ? $_GET['newit618_score'] : array();
	$newit618_jfid_array = !empty($_GET['newit618_jfid']) ? $_GET['newit618_jfid'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_kdid_array as $key => $value) {
	
		if($newit618_kdid_array[$key] != '') {
			
			C::t('#it618_tuan#it618_tuan_kdyunfei')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_kdid' => trim($newit618_kdid_array[$key]),
				'it618_kdareaid' => trim($newit618_kdareaid_array[$key]),
				'it618_firstcount' => trim($newit618_firstcount_array[$key]),
				'it618_firstprice' => trim($newit618_firstprice_array[$key]),
				'it618_price' => trim($newit618_price_array[$key]),
				'it618_firstscore' => trim($newit618_firstscore_array[$key]),
				'it618_score' => trim($newit618_score_array[$key]),
				'it618_jfid' => trim($newit618_jfid_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}
	
	C::t('#it618_tuan#it618_tuan_shop')->update($ShopId,array(
		'it618_kdaddr' => trim($_GET['it618_kdaddr'])
	));

	it618_cpmsg(it618_tuan_getlang('s33').$ok1.' '.it618_tuan_getlang('s34').$ok2.' '.it618_tuan_getlang('s35').$del.')', "plugin.php?id=it618_tuan:sc_kdyunfei&kdid=".$kdid, 'succeed');
}

$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($ShopId);

it618_showformheader("plugin.php?id=it618_tuan:sc_kdyunfei&kdid=".$kdid);
showtableheaders(it618_tuan_getlang('s744'),'it618_tuan_kdyunfei');
	
	echo '<tr><td colspan="6">'.it618_tuan_getlang('s745').'<input type="text" name="it618_kdaddr" value="'.$it618_tuan_shop['it618_kdaddr'].'"> '.it618_tuan_getlang('s746').' '.it618_tuan_getlang('s801').'<input type="submit" class="btn" name="it618submit_dao" value="'.it618_tuan_getlang('s802').'"></td></tr>';
	showsubtitle(array('', it618_tuan_getlang('s747'),it618_tuan_getlang('s748'),it618_tuan_getlang('s749'),it618_tuan_getlang('s750')));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_kdyunfei')." WHERE it618_shopid=".$ShopId." and it618_kdid=$kdid ORDER BY it618_order");
	while($it618_tuan = DB::fetch($query)) {
		
		$kdareatmp1=str_replace('<option value='.$it618_tuan['it618_kdareaid'].'>','<option value='.$it618_tuan['it618_kdareaid'].' selected="selected">',$kdareatmp);
		$kdtmp1=str_replace('<option value='.$it618_tuan['it618_kdid'].'>','<option value='.$it618_tuan['it618_kdid'].' selected="selected">',$kdtmp);
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_tuan[id]\" $disabled>",
			'<select name="it618_kdareaid['.$it618_tuan[id].']">'.$kdareatmp1.'</select>',
			'<select name="it618_kdid['.$it618_tuan[id].']">'.$kdtmp1.'</select>',
			"<input type=\"text\" class=\"txt\" style=\"width:50px\" name=\"it618_firstcount[$it618_tuan[id]]\" value=\"$it618_tuan[it618_firstcount]\">".it618_tuan_getlang('s751')." <input type=\"text\" class=\"txt\" style=\"width:68px;margin-right:3px\" name=\"it618_firstprice[$it618_tuan[id]]\" value=\"$it618_tuan[it618_firstprice]\">".it618_tuan_getlang('s753')." + <input type=\"text\" class=\"txt\" style=\"width:58px;margin-right:3px\" name=\"it618_firstscore[$it618_tuan[id]]\" value=\"$it618_tuan[it618_firstscore]\">JF ".it618_tuan_getlang('s752')." <input type=\"text\" class=\"txt\" style=\"width:68px;margin-right:3px\" name=\"it618_price[$it618_tuan[id]]\" value=\"$it618_tuan[it618_price]\">".it618_tuan_getlang('s753')." + <input type=\"text\" class=\"txt\" style=\"width:58px;margin-right:3px\" name=\"it618_score[$it618_tuan[id]]\" value=\"$it618_tuan[it618_score]\">JF (JF=<select name=\"it618_jfid[$it618_tuan[id]]\">".it618_tuan_getjftype($it618_tuan['it618_jfid'])."</select>)",
			"<input type=\"text\" class=\"txt\" style=\"width:50px\" name=\"it618_order[$it618_tuan[id]]\" value=\"$it618_tuan[it618_order]\">".'<font color=red>'.it618_tuan_getlang('s803').'</font>'
		));
	}
	
	$it618_tuan_lang751=it618_tuan_getlang('s751');
	$it618_tuan_lang752=it618_tuan_getlang('s752');
	$it618_tuan_lang753=it618_tuan_getlang('s753');
	$tmptype=it618_tuan_getjftype();

	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		return [
		[[1,''], [1,'<select name="newit618_kdareaid[]">$kdareatmp</select>'], [1,'<select name="newit618_kdid[]">$kdtmpsel</select>'], [1, '<input class="txt" style="width:50px" type="text" name="newit618_firstcount[]">$it618_tuan_lang751 <input class="txt" style="width:68px;margin-right:3px" type="text" name="newit618_firstprice[]">$it618_tuan_lang753 + <input class="txt" style="width:58px;margin-right:3px" type="text" name="newit618_firstscore[]">JF $it618_tuan_lang752 <input class="txt" style="width:68px;margin-right:3px" type="text" name="newit618_price[]">$it618_tuan_lang753 + <input class="txt" style="width:58px;margin-right:3px" type="text" name="newit618_score[]">JF  (JF=<select name="newit618_jfid[]">$tmptype</select>)'], [1, ' <input class="txt" style="width:50px" type="text" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="4"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.it618_tuan_getlang('s754').'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/sc_footer.func.php';
?>