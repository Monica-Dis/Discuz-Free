<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_wxmini_lang;

function it618_wxmini_getlang($langid){
	global $it618_wxmini_lang;
	return $it618_wxmini_lang[$langid];
}

$it618_wxmini_lang['version']='v1.0.7';
$it618_wxmini_lang['s1'] = '应用管理';
$it618_wxmini_lang['s2'] = '会员管理';
$it618_wxmini_lang['s3'] = '编号';
$it618_wxmini_lang['s4'] = 'AppID(小程序ID)：';
$it618_wxmini_lang['s5'] = 'AppSecret(小程序密钥)：';
$it618_wxmini_lang['s6'] = '微信支付商户号：';
$it618_wxmini_lang['s7'] = 'API密钥(交易签名密钥)：';
$it618_wxmini_lang['s8'] = '小程序名称/说明';
$it618_wxmini_lang['s9'] = '小程序接口(AppID在有会员时是不能修改与删除的)';
$it618_wxmini_lang['s10'] = '会员数';
$it618_wxmini_lang['s11'] = '小程序数：';
$it618_wxmini_lang['s12'] = '链接管理/小程序二维码链接权限';
$it618_wxmini_lang['s13'] = '应用aid：';
$it618_wxmini_lang['s14'] = '打开小程序时默认访问的首页链接：';
$it618_wxmini_lang['s15'] = '用于识别不同的小程序应用，在小程序项目内的app.js设置';
$it618_wxmini_lang['s16'] = '积分名称';
$it618_wxmini_lang['s17'] = '充值汇率';
$it618_wxmini_lang['s18'] = '是否开启充值';
$it618_wxmini_lang['s19'] = '转余汇率(倍数)';
$it618_wxmini_lang['s20'] = '是否开启转余';
$it618_wxmini_lang['s21'] = '积分充值设置';
$it618_wxmini_lang['s22'] = '积分转余设置';
$it618_wxmini_lang['s23'] = '设置数：';
$it618_wxmini_lang['s24'] = '设置数：';
$it618_wxmini_lang['s25'] = '更新成功！';
$it618_wxmini_lang['s26'] = '金额';
$it618_wxmini_lang['s27'] = '最低充值金额：';
$it618_wxmini_lang['s28'] = '元';
$it618_wxmini_lang['s29'] = '更新';
$it618_wxmini_lang['s30'] = '最低转余积分数：';
$it618_wxmini_lang['s31'] = '记录数：';
$it618_wxmini_lang['s32'] = '访客或未登录';
$it618_wxmini_lang['s33'] = '更新成功！(成功修改数:';
$it618_wxmini_lang['s34'] = '成功添加数:';
$it618_wxmini_lang['s35'] = '成功删除数:';
$it618_wxmini_lang['s36'] = '应用登录记录';
$it618_wxmini_lang['s37'] = '应用名称';
$it618_wxmini_lang['s38'] = '会员';
$it618_wxmini_lang['s39'] = '登录时间';
$it618_wxmini_lang['s40'] = '客户端详情';
$it618_wxmini_lang['s41'] = '提示：第一次访问小程序时，会调用小程序登录功能，如果不关闭小程序是不会再登录的，下次重新访问还会再登录，注意小程序登录和会员登录无关';
$it618_wxmini_lang['s42'] = '视频学院';
$it618_wxmini_lang['s43'] = '在线考试';
$it618_wxmini_lang['s44'] = '联盟商家';
$it618_wxmini_lang['s45'] = '多功能商城';
$it618_wxmini_lang['s46'] = '外卖商城';
$it618_wxmini_lang['s47'] = '<font color=#999>选择插件的二维码链接会跳转到此链接：</font><br><font color=blue>域名/plugin.php?id=it618_wxmini:url&aid={aid}</font>&q=<font color=green>urlencode处理的链接</font>';
$it618_wxmini_lang['s48'] = '不搞跳转';
$it618_wxmini_lang['s49'] = '注意：现在微信支持扫普通链接二维码打开小程序，如果设置了插件跳转，那么微信扫插件分享海报的二维码时，会优先小程序打开，不影响二维码正常使用';
$it618_wxmini_lang['s50'] = '注意：请保证小程序应用与需要跳转的插件一对一，如果多个应用对应一个插件，优先支持aid小的，推荐一个插件申请一个小程序';
$it618_wxmini_lang['s51'] = '推广联盟';
$it618_wxmini_lang['s52'] = '淘宝客导购';
$it618_wxmini_lang['s53'] = '';
$it618_wxmini_lang['s54'] = '';
$it618_wxmini_lang['s55'] = '';
$it618_wxmini_lang['s56'] = '';
$it618_wxmini_lang['s57'] = '';
$it618_wxmini_lang['s58'] = '';
$it618_wxmini_lang['s59'] = '';
$it618_wxmini_lang['s60'] = '宽:';
$it618_wxmini_lang['s61'] = '高:';
$it618_wxmini_lang['s62'] = '轮播广告数：';
$it618_wxmini_lang['s63'] = '注意：排序值为0时表示图片不显示，数值越小越在前';
$it618_wxmini_lang['s64'] = '图片';
$it618_wxmini_lang['s65'] = '图片链接(为空时图片不带链接)';
$it618_wxmini_lang['s66'] = '排序';
$it618_wxmini_lang['s67'] = '上传图片';
$it618_wxmini_lang['s68'] = '提交后再上传图片';
$it618_wxmini_lang['it618'] = 'i11ill1lliiiililiiiliilil111ilililil11111ililiiililiiiililililiil1ilililillil111li11111111iliililililili11111l111l11ill1i1illii11';
$it618_wxmini_lang['s69'] = '此轮播同时也会显示在手机版首页，为了手机版首页轮播美观，请一定保持图片的宽高一致';
$it618_wxmini_lang['s72'] = '文字颜色(无突出效果时要为空)';
$it618_wxmini_lang['s73'] = '公告数：';
$it618_wxmini_lang['s74'] = '注意：此公告同时也会显示在手机版首页，排序为0时不显示';
$it618_wxmini_lang['s75'] = '标题';
$it618_wxmini_lang['s76'] = '链接';
$it618_wxmini_lang['s77'] = '文字粗体';
$it618_wxmini_lang['s78'] = '排序';
$it618_wxmini_lang['s79'] = '用户组充值设置';
$it618_wxmini_lang['s80'] = '积分转账设置';
$it618_wxmini_lang['s81'] = '设置';
$it618_wxmini_lang['s82'] = '是否开启转账';
$it618_wxmini_lang['s83'] = '支付宝接口类型：';
$it618_wxmini_lang['s84'] = '卖家支付宝帐户：';
$it618_wxmini_lang['s85'] = '合作身份者id，以2088开头的16位纯数字：';
$it618_wxmini_lang['s86'] = '安全检验码，以数字和字母组成的32位字符：';
$it618_wxmini_lang['s87'] = '支付宝支付接口更新成功！';
$it618_wxmini_lang['s88'] = '微信公众号支付接口更新成功！';
$it618_wxmini_lang['s89'] = '支付宝支付接口';
$it618_wxmini_lang['s90'] = '是否启用接口：';
$it618_wxmini_lang['s91'] = '如果启用就自动支付宝购买';
$it618_wxmini_lang['s92'] = '如果启用就自动微信购买(微信浏览器内直接微信支付，别的电脑或手机浏览器直接微信扫码支付)';
$it618_wxmini_lang['s93'] = 'APPID (公众号身份的唯一标识)：';
$it618_wxmini_lang['s94'] = '微信支付商户号：';
$it618_wxmini_lang['s95'] = 'API密钥 (交易过程生成签名的密钥)：';
$it618_wxmini_lang['s96'] = 'Appsecret (APPID对应的接口密码)：';
$it618_wxmini_lang['s97'] = '注意：看右侧教程设置以上参数，授权目录只需要添加一个，就是带http://或https://的回调域名';
$it618_wxmini_lang['s98'] = '微信公众号支付接口';
$it618_wxmini_lang['s99'] = '企业支付宝 - 电脑网站支付+手机网站支付';
$it618_wxmini_lang['s100'] = '审核通过数：';

?>