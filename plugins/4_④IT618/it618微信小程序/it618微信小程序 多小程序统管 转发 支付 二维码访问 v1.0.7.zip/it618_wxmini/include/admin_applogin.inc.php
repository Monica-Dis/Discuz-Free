<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(count($reabc)!=12)return;

showformheader("plugins&identifier=$identifier&cp=admin_applogin&pmod=admin_app&operation=$operation&do=$do");
showtableheaders($it618_wxmini_lang['s1'],'it618_wxmini_applogin');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wxmini_applogin')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_applogin&pmod=admin_app&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10>'.$it618_wxmini_lang['s31'].$count.'<span style="float:right">'.$it618_wxmini_lang['s41'].'</span></td></tr>';
	showsubtitle(array($it618_wxmini_lang['s37'], $it618_wxmini_lang['s38'],$it618_wxmini_lang['s40'],$it618_wxmini_lang['s39']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_wxmini_applogin')." WHERE 1 $extrasql ORDER BY id desc LIMIT $startlimit, $ppp");
	while($it618_wxmini_applogin = DB::fetch($query)) {
		
		$appname=C::t('#it618_wxmini#it618_wxmini_app')->fetch_it618_name_by_id($it618_wxmini_applogin['it618_aid']);
		
		if($it618_wxmini_applogin['it618_uid']>0){
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_wxmini_applogin['it618_uid']);
			$username='<a href="home.php?mod=space&uid='.$it618_wxmini_applogin['it618_uid'].'" target="_blank">'.$username.'</a>';
		}else{
			$username=$it618_wxmini_lang['s32'];	
		}
		
		showtablerow('', array('', '', '', '', ''), array(
			$appname,
			$username,
			'<div style="width:460px">'.$it618_wxmini_applogin['it618_bz'].'</div>',
			date('Y-m-d H:i:s', $it618_wxmini_applogin['it618_time'])
		));
	}
	
	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div></td></tr>';
	if(count($reabc)!=12)return;
showtablefooter();/*Dism_taobao-com*/
?>