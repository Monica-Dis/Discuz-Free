<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='m')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_wxmini_app', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_appid'])) {
		foreach($_GET['it618_appid'] as $id => $val) {

			C::t('#it618_wxmini#it618_wxmini_app')->update($id,array(
				'it618_appid' => trim($_GET['it618_appid'][$id]),
				'it618_appsecret' => trim($_GET['it618_appsecret'][$id]),
				'it618_wxpaymchid' => trim($_GET['it618_wxpaymchid'][$id]),
				'it618_wxpaykey' => trim($_GET['it618_wxpaykey'][$id]),
				'it618_homeurl' => trim($_GET['it618_homeurl'][$id]),
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_about' => trim($_GET['it618_about'][$id]),
				'it618_pluginid' => trim($_GET['it618_pluginid'][$id])
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_appid_array = !empty($_GET['newit618_appid']) ? $_GET['newit618_appid'] : array();
	$newit618_appsecret_array = !empty($_GET['newit618_appsecret']) ? $_GET['newit618_appsecret'] : array();
	$newit618_wxpaymchid_array = !empty($_GET['newit618_wxpaymchid']) ? $_GET['newit618_wxpaymchid'] : array();
	$newit618_wxpaykey_array = !empty($_GET['newit618_wxpaykey']) ? $_GET['newit618_wxpaykey'] : array();
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	
	foreach($newit618_appid_array as $key => $value) {
		$newit618_appid = addslashes(trim($newit618_appid_array[$key]));
		
		if($newit618_appid != '') {
			
			C::t('#it618_wxmini#it618_wxmini_app')->insert(array(
				'it618_appid' => trim($newit618_appid_array[$key]),
				'it618_appsecret' => trim($newit618_appsecret_array[$key]),
				'it618_wxpaymchid' => trim($newit618_wxpaymchid_array[$key]),
				'it618_wxpaykey' => trim($newit618_wxpaykey_array[$key]),
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_about' => trim($newit618_about_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_wxmini_lang['s33'].$ok1.' '.$it618_wxmini_lang['s34'].$ok2.' '.$it618_wxmini_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_app&pmod=admin_app&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=12)return;

showformheader("plugins&identifier=$identifier&cp=admin_app&pmod=admin_app&operation=$operation&do=$do");
showtableheaders($it618_wxmini_lang['s1'],'it618_wxmini_app');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_wxmini_app')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_app&pmod=admin_app&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10>'.$it618_wxmini_lang['s11'].$count.'<span style="float:right;color:blue">'.$it618_wxmini_lang['s49'].'</span></td></tr>';
	showsubtitle(array($it618_wxmini_lang['s3'], $it618_wxmini_lang['s8'],$it618_wxmini_lang['s9'],$it618_wxmini_lang['s12']));
	
	$stroption='<option value="">'.$it618_wxmini_lang['s48'].'</option>
				<option value="it618_union">'.$it618_wxmini_lang['s51'].'</option>
				<option value="it618_video">'.$it618_wxmini_lang['s42'].'</option>
				<option value="it618_exam">'.$it618_wxmini_lang['s43'].'</option>
				<option value="it618_brand">'.$it618_wxmini_lang['s44'].'</option>
				<option value="it618_tuan">'.$it618_wxmini_lang['s45'].'</option>
				<option value="it618_waimai">'.$it618_wxmini_lang['s46'].'</option>
				<option value="it618_sale">'.$it618_wxmini_lang['s52'].'</option>
				';
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_wxmini_app')." WHERE 1 $extrasql ORDER BY id desc LIMIT $startlimit, $ppp");
	while($it618_wxmini_app = DB::fetch($query)) {
		$disabled="";$readonly="";$appidcss="";
		if($it618_wxmini_app['it618_ok']==1){
			$disabled="disabled=\"disabled\"";
			$readonly="readonly=\"readonly\"";
			$appidcss=";background-color:#ccc";
		}
		
		$stroption1=str_replace('value="'.$it618_wxmini_app['it618_pluginid'].'"','value="'.$it618_wxmini_app['it618_pluginid'].'" selected="selected"',$stroption);
		
		$urlabout=str_replace("{aid}",$it618_wxmini_app['id'],$it618_wxmini_lang['s47']);
		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_wxmini_app[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_wxmini_app[id]]\" value=\"$it618_wxmini_app[id]\">",
			'<input class="txt" type="text" style="width:200px" name="it618_name['.$it618_wxmini_app['id'].']" value="'.$it618_wxmini_app['it618_name'].'"><br>
			<textarea style="width:200px;height:68px;margin-top:3px"  name="it618_about['.$it618_wxmini_app['id'].']">'.$it618_wxmini_app['it618_about'].'</textarea>',
			'<div style="width:430px;line-height:25px">'.$it618_wxmini_lang['s4'].'<input type="text" class="txt" style="width:260px;float:right'.$appidcss.'" name="it618_appid['.$it618_wxmini_app['id'].']" value="'.$it618_wxmini_app['it618_appid'].'" '.$readonly.'><br>'.$it618_wxmini_lang['s5'].'<input type="text" class="txt" style="width:260px;float:right" name="it618_appsecret['.$it618_wxmini_app['id'].']" value="'.$it618_wxmini_app['it618_appsecret'].'"><br>'.$it618_wxmini_lang['s6'].'<input type="text" class="txt" style="width:260px;float:right;" name="it618_wxpaymchid['.$it618_wxmini_app['id'].']" value="'.$it618_wxmini_app['it618_wxpaymchid'].'"><br>'.$it618_wxmini_lang['s7'].'<input type="text" class="txt" style="width:260px;float:right;" name="it618_wxpaykey['.$it618_wxmini_app['id'].']" value="'.$it618_wxmini_app['it618_wxpaykey'].'"></div>',
			'<font color=red>'.$it618_wxmini_lang['s13'].'<b>'.$it618_wxmini_app['id'].'</b></font> <font color=#666>'.$it618_wxmini_lang['s15'].'</font><br><font color=#999>'.$it618_wxmini_lang['s14'].'</font><br><input type="text" class="txt" style="width:430px;margin-top:3px" name="it618_homeurl['.$it618_wxmini_app['id'].']" value="'.$it618_wxmini_app['it618_homeurl'].'"><br><select name="it618_pluginid['.$it618_wxmini_app['id'].']" style="margin-top:3px">'.$stroption1.'</select> '.$urlabout,
		));
	}
	
	$lang_s4=$it618_wxmini_lang['s4'];
	$lang_s5=$it618_wxmini_lang['s5'];
	$lang_s6=$it618_wxmini_lang['s6'];
	$lang_s7=$it618_wxmini_lang['s7'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_appid[]").length;
	
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:230px" name="newit618_name[]"><br><textarea name="newit618_about[]" style="width:230px;height:63px;margin-top:5px;margin-bottom:5px"></textarea>'],
		[1,'<div style="width:430px;line-height:25px">$lang_s4<input type="text" class="txt" style="width:260px;float:right" name="newit618_appid[]"><br>$lang_s5<input type="text" class="txt" style="width:260px;float:right" name="newit618_appsecret[]"><br>$lang_s6</td><td><input type="text" class="txt" style="width:260px;float:right" name="newit618_wxpaymchid[]"><br>$lang_s7<input type="text" class="txt" style="width:260px;float:right" name="newit618_wxpaykey[]"></div>'],
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />".$it618_wxmini_lang['s50'], $multipage);
	if(count($reabc)!=12)return;
showtablefooter();/*Dism_taobao-com*/
?>