<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_wxmini_applogin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_bz` varchar(300) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_wxmini_app'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field'];
}
if(!in_array('it618_ok', $col_field)){
	$sql = "Alter table ".DB::table('it618_wxmini_app')." add `it618_ok` int(10) unsigned NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_pluginid', $col_field)){
	$sql = "Alter table ".DB::table('it618_wxmini_app')." add `it618_pluginid` varchar(50) NOT NULL;"; 
	DB::query($sql);  
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;/*dism_taobao-com*/
?>