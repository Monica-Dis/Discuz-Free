<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_wxmini_lang;
require_once DISCUZ_ROOT.'./source/plugin/it618_wxmini/lang.func.php';


if($_GET['ac']=="wxpay"){
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($_GET['out_trade_no'])){
		if($it618_salepay['it618_state']==1)exit;
	}else{
		exit;
	}
	
	if(!function_exists('curl_init')){
		echo 'please open the curl!';exit;
	}
	
	$out_trade_no=$it618_salepay['it618_out_trade_no'];
	$paytype=$it618_salepay['it618_paytype'];
	$url=$it618_salepay['it618_url'];
	$tmparr=explode("//",$url);
	if(count($tmparr)==1){
		$url=$tmparr[0].'//'.urlencode($tmparr[1]);
	}
	$body=gbktoutf($it618_salepay['it618_body']);
	$total_fee=$it618_salepay['it618_total_fee'];
	$it618_plugin=$it618_salepay['it618_plugin'];
	$it618_wap=$it618_salepay['it618_wap'];
	
	$notify_url = $_G['siteurl'].'source/plugin/it618_credits/pay_wx/notify.php';
	
	if($it618_wxmini_app = C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_id($_GET['aid'])){
		$wx_appid=$it618_wxmini_app['it618_appid'];
		$wx_mch_id=$it618_wxmini_app['it618_wxpaymchid'];
		$wx_key=$it618_wxmini_app['it618_wxpaykey'];
	}

	$openid=$_GET['openid'];
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/function.php';
	
	$input = array(
		'body' => $body,
		'out_trade_no' => $out_trade_no,
		'total_fee' => ($total_fee*100),
		'notify_url' => $notify_url,
	);
	if(lang('plugin/it618_wxmini', $it618_wxmini_lang['it618'])!=$it618_wxmini_lang['version'])exit;
	$input["trade_type"] = 'JSAPI';
	$input["appid"] = $wx_appid;
	$input["mch_id"] = $wx_mch_id; 
	$input["openid"] = $openid;
	$input["nonce_str"] = it618_getrandstr();
	$input["spbill_create_ip"] = $_G['clientip']; 
	$input["sign"] = it618_getwxsign($input,$wx_key);
	if(lang('plugin/it618_wxmini', $it618_wxmini_lang['it618'])!=$it618_wxmini_lang['version'])exit;
	$prepaystr = it618_postxmlcurl(it618_arraytoxml($input),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postobj = it618_xmltoarray($prepaystr);
	$prepayid = $postobj["prepay_id"];
	
	if($postobj["return_code"]=='FAIL'){
		$s = var_export($postobj,true);
		it618debug($s);
	}
	
	C::t('#it618_credits#it618_credits_salepay')->update($it618_salepay['id'],array(
		'it618_paytypeid' => $_GET['aid']
	));
	if(lang('plugin/it618_wxmini', $it618_wxmini_lang['it618'])!=$it618_wxmini_lang['version'])exit;
	$wxpay = array();
	$wxpay["appId"] = $wx_appid;
	$wxpay["timeStamp"] = $_G['timestamp'].'';
	$wxpay["nonceStr"] = it618_getrandstr();
	$wxpay["package"] = "prepay_id=".$prepayid;
	$wxpay['signType'] = "MD5";
	$wxpay["paySign"] = it618_getwxsign($wxpay,$wx_key);
	$wxpay["body"] = $body;
	$wxpay["url"] = $url;
	
	echo json_encode($wxpay);
}

function gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618debug($content){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_wxmini/debug.txt',"a");
	fwrite($fp,$content);
	fclose($fp);
}
//From: dis'.'m.tao'.'bao.com
?>