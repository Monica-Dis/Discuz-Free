<?php
/**
 *	開發團隊：IT618
 *	it618_copyright sn: 插件設計：<a href="http://t.cn/AiuxBMCp" class="" target="_blank" title="專業Discuz!應用及周邊提供商">IT618</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_wxmini_lang;

function it618_wxmini_getlang($langid){
	global $it618_wxmini_lang;
	return $it618_wxmini_lang[$langid];
}

$it618_wxmini_lang['version']='v1.0.7';
$it618_wxmini_lang['s1'] = '應用琯理';
$it618_wxmini_lang['s2'] = '會員琯理';
$it618_wxmini_lang['s3'] = '編號';
$it618_wxmini_lang['s4'] = 'AppID(小程序ID)：';
$it618_wxmini_lang['s5'] = 'AppSecret(小程序密鈅)：';
$it618_wxmini_lang['s6'] = '微信支付商戶號：';
$it618_wxmini_lang['s7'] = 'API密鈅(交易簽名密鈅)：';
$it618_wxmini_lang['s8'] = '小程序名稱/說明';
$it618_wxmini_lang['s9'] = '小程序接口(AppID在有會員時是不能脩改與刪除的)';
$it618_wxmini_lang['s10'] = '會員數';
$it618_wxmini_lang['s11'] = '小程序數：';
$it618_wxmini_lang['s12'] = '鏈接琯理/小程序二維碼鏈接權限';
$it618_wxmini_lang['s13'] = '應用aid：';
$it618_wxmini_lang['s14'] = '打開小程序時默認訪問的首頁鏈接：';
$it618_wxmini_lang['s15'] = '用於識別不同的小程序應用，在小程序項目內的app.js設置';
$it618_wxmini_lang['s16'] = '積分名稱';
$it618_wxmini_lang['s17'] = '充值滙率';
$it618_wxmini_lang['s18'] = '是否開啓充值';
$it618_wxmini_lang['s19'] = '轉餘滙率(倍數)';
$it618_wxmini_lang['s20'] = '是否開啓轉餘';
$it618_wxmini_lang['s21'] = '積分充值設置';
$it618_wxmini_lang['s22'] = '積分轉餘設置';
$it618_wxmini_lang['s23'] = '設置數：';
$it618_wxmini_lang['s24'] = '設置數：';
$it618_wxmini_lang['s25'] = '更新成功！';
$it618_wxmini_lang['s26'] = '金額';
$it618_wxmini_lang['s27'] = '最低充值金額：';
$it618_wxmini_lang['s28'] = '元';
$it618_wxmini_lang['s29'] = '更新';
$it618_wxmini_lang['s30'] = '最低轉餘積分數：';
$it618_wxmini_lang['s31'] = '記錄數：';
$it618_wxmini_lang['s32'] = '訪客或未登錄';
$it618_wxmini_lang['s33'] = '更新成功！(成功脩改數:';
$it618_wxmini_lang['s34'] = '成功添加數:';
$it618_wxmini_lang['s35'] = '成功刪除數:';
$it618_wxmini_lang['s36'] = '應用登錄記錄';
$it618_wxmini_lang['s37'] = '應用名稱';
$it618_wxmini_lang['s38'] = '會員';
$it618_wxmini_lang['s39'] = '登錄時間';
$it618_wxmini_lang['s40'] = '客戶耑詳情';
$it618_wxmini_lang['s41'] = '提示：第一次訪問小程序時，會調用小程序登錄功能，如果不關閉小程序是不會再登錄的，下次重新訪問還會再登錄，注意小程序登錄和會員登錄無關';
$it618_wxmini_lang['s42'] = '眡頻學院';
$it618_wxmini_lang['s43'] = '在線考試';
$it618_wxmini_lang['s44'] = '聯盟商家';
$it618_wxmini_lang['s45'] = '多功能商城';
$it618_wxmini_lang['s46'] = '外賣商城';
$it618_wxmini_lang['s47'] = '<font color=#999>選擇插件的二維碼鏈接會跳轉到此鏈接：</font><br><font color=blue>域名/plugin.php?id=it618_wxmini:url&aid={aid}</font>&q=<font color=green>urlencode処理的鏈接</font>';
$it618_wxmini_lang['s48'] = '不搞跳轉';
$it618_wxmini_lang['s49'] = '注意：現在微信支持掃普通鏈接二維碼打開小程序，如果設置了插件跳轉，那麽微信掃插件分享海報的二維碼時，會優先小程序打開，不影響二維碼正常使用';
$it618_wxmini_lang['s50'] = '注意：請保証小程序應用與需要跳轉的插件一對一，如果多個應用對應一個插件，優先支持aid小的，推薦一個插件申請一個小程序';
$it618_wxmini_lang['s51'] = '推廣聯盟';
$it618_wxmini_lang['s52'] = '淘寶客導購';
$it618_wxmini_lang['s53'] = '';
$it618_wxmini_lang['s54'] = '';
$it618_wxmini_lang['s55'] = '';
$it618_wxmini_lang['s56'] = '';
$it618_wxmini_lang['s57'] = '';
$it618_wxmini_lang['s58'] = '';
$it618_wxmini_lang['s59'] = '';
$it618_wxmini_lang['s60'] = '寬:';
$it618_wxmini_lang['s61'] = '高:';
$it618_wxmini_lang['s62'] = '輪播廣告數：';
$it618_wxmini_lang['s63'] = '注意：排序值爲0時表示圖片不顯示，數值越小越在前';
$it618_wxmini_lang['s64'] = '圖片';
$it618_wxmini_lang['s65'] = '圖片鏈接(爲空時圖片不帶鏈接)';
$it618_wxmini_lang['s66'] = '排序';
$it618_wxmini_lang['s67'] = '上傳圖片';
$it618_wxmini_lang['s68'] = '提交後再上傳圖片';
$it618_wxmini_lang['it618'] = 'i11ill1lliiiililiiiliilil111ilililil11111ililiiililiiiililililiil1ilililillil111li11111111iliililililili11111l111l11ill1i1illii11';
$it618_wxmini_lang['s69'] = '此輪播同時也會顯示在手機版首頁，爲了手機版首頁輪播美觀，請一定保持圖片的寬高一致';
$it618_wxmini_lang['s72'] = '文字顔色(無突出傚果時要爲空)';
$it618_wxmini_lang['s73'] = '公告數：';
$it618_wxmini_lang['s74'] = '注意：此公告同時也會顯示在手機版首頁，排序爲0時不顯示';
$it618_wxmini_lang['s75'] = '標題';
$it618_wxmini_lang['s76'] = '鏈接';
$it618_wxmini_lang['s77'] = '文字粗躰';
$it618_wxmini_lang['s78'] = '排序';
$it618_wxmini_lang['s79'] = '用戶組充值設置';
$it618_wxmini_lang['s80'] = '積分轉賬設置';
$it618_wxmini_lang['s81'] = '設置';
$it618_wxmini_lang['s82'] = '是否開啓轉賬';
$it618_wxmini_lang['s83'] = '支付寶接口類型：';
$it618_wxmini_lang['s84'] = '賣家支付寶帳戶：';
$it618_wxmini_lang['s85'] = '郃作身份者id，以2088開頭的16位純數字：';
$it618_wxmini_lang['s86'] = '安全檢騐碼，以數字和字母組成的32位字符：';
$it618_wxmini_lang['s87'] = '支付寶支付接口更新成功！';
$it618_wxmini_lang['s88'] = '微信公衆號支付接口更新成功！';
$it618_wxmini_lang['s89'] = '支付寶支付接口';
$it618_wxmini_lang['s90'] = '是否啓用接口：';
$it618_wxmini_lang['s91'] = '如果啓用就自動支付寶購買';
$it618_wxmini_lang['s92'] = '如果啓用就自動微信購買(微信瀏覽器內直接微信支付，別的電腦或手機瀏覽器直接微信掃碼支付)';
$it618_wxmini_lang['s93'] = 'APPID (公衆號身份的唯一標識)：';
$it618_wxmini_lang['s94'] = '微信支付商戶號：';
$it618_wxmini_lang['s95'] = 'API密鈅 (交易過程生成簽名的密鈅)：';
$it618_wxmini_lang['s96'] = 'Appsecret (APPID對應的接口密碼)：';
$it618_wxmini_lang['s97'] = '注意：看右側教程設置以上蓡數，授權目錄衹需要添加一個，就是帶http://或https://的廻調域名';
$it618_wxmini_lang['s98'] = '微信公衆號支付接口';
$it618_wxmini_lang['s99'] = '企業支付寶 - 電腦網站支付+手機網站支付';
$it618_wxmini_lang['s100'] = '讅核通過數：';

?>