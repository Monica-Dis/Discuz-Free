<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G,$it618_wxmini,$_SERVER,$it618_wxmini_lang;
$it618_wxmini = $_G['cache']['plugin']['it618_wxmini'];
require_once DISCUZ_ROOT.'./source/plugin/it618_wxmini/lang.func.php';

if($it618_wxmini['wxmini_delldtime']>0){
	$cache_file = DISCUZ_ROOT.'./source/plugin/it618_wxmini/cache_del.php';
	if(($_G['timestamp'] - @filemtime($cache_file)) > 180) {
		
		@$fp = fopen($cache_file,"w");
		fwrite($fp,$_G['timestamp']);
		fclose($fp);
		
		DB::query("delete from ".DB::table('it618_wxmini_applogin')." where it618_time+".(3600*24*$it618_wxmini['wxmini_delldtime'])."<".$_G['timestamp']);
	}
}

if(isset($_GET['code'])){
	if($it618_wxmini_app = C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_id($_GET['aid'])){

		$code=$_GET['code'];
		$appid=$it618_wxmini_app['it618_appid'];
		$appsecret=$it618_wxmini_app['it618_appsecret'];
		
		echo get_wxopenid($_GET['aid'],$appid,$appsecret,$code,DISCUZ_ROOT);
	}
}

function get_wxopenid($aid,$appid,$appsecret,$code,$dzroot=''){
	global $_G,$_SERVER,$it618_wxmini_lang;
	$url = "https://api.weixin.qq.com/sns/jscode2session?appid=".$appid."&secret=".$appsecret."&js_code=".$code."&grant_type=authorization_code";

	$res = dfsockopen($url);

	$data = json_decode($res, true);
	
	$tmparr=explode("errmsg",$res);
	if(count($tmparr)>1){
		@$fp = fopen($dzroot.'./source/plugin/it618_wxmini/debug.txt',"a");
		fwrite($fp,"get_wxopenid\n".$res."\n");
		fclose($fp);
	}else{
		C::t('#it618_wxmini#it618_wxmini_app')->update($aid,array(
			'it618_ok' => 1
		));
		
		C::t('#it618_wxmini#it618_wxmini_applogin')->insert(array(
			  'it618_aid' => $aid,
			  'it618_uid' => $_G['uid'],
			  'it618_bz' => dhtmlspecialchars($_SERVER['HTTP_USER_AGENT']).'<br>'.$_G['clientip'],
			  'it618_time' => $_G['timestamp']
		), true);
	}
	
	return $res;
}
//From: dis'.'m.tao'.'bao.com
?>