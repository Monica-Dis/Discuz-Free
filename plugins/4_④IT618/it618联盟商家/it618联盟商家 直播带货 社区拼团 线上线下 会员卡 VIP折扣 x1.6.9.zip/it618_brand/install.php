<?php

(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_brand_addr`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_addr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(100) NOT NULL,
  `it618_addr` varchar(1000) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_iscur` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_article`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_article_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_article_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_article_ly`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_article_ly` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_aid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_quoteid` int(10) unsigned NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_brand`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_brand` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_area_id` int(10) unsigned NOT NULL,
  `it618_area1_id` int(10) unsigned NOT NULL,
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_logo` varchar(200) NOT NULL,
  `it618_homelogo` varchar(200) NOT NULL,
  `it618_headerimg` varchar(200) NOT NULL,
  `it618_wapheaderstyle` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_wapheaderimg` varchar(200) NOT NULL,
  `it618_wapcolors` varchar(200) NOT NULL,
  `it618_homebg` varchar(200) NOT NULL,
  `it618_homebgmove` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(200) NOT NULL,
  `it618_tel` varchar(200) NOT NULL,
  `it618_qq` varchar(200) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_liyou` varchar(2000) NOT NULL,
  `it618_telsalenav` mediumtext NOT NULL,
  `it618_noticestitle` varchar(1000) NOT NULL,
  `it618_notices` mediumtext NOT NULL,
  `it618_weixincode` varchar(200) NOT NULL,
  `it618_wapcode` varchar(200) NOT NULL,
  `it618_dianhua` varchar(200) NOT NULL,
  `it618_shouji` varchar(200) NOT NULL,
  `it618_kefuqq` varchar(200) NOT NULL,
  `it618_kefuwx` varchar(200) NOT NULL,
  `it618_kefuqqname` varchar(200) NOT NULL,
  `it618_yytime` varchar(200) NOT NULL,
  `it618_fahuo` varchar(1000) NOT NULL,
  `it618_youhui` varchar(1000) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_mappoint` varchar(50) NOT NULL,
  `it618_mapurl` varchar(200) NOT NULL,
  `it618_messagetel` varchar(20) NOT NULL,
  `it618_messageisok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_messagecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tongji` varchar(2000) NOT NULL,
  `it618_seotitle` varchar(100) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_ischeckfahuo` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isbrandnav` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_shopstyle` int(10) unsigned NOT NULL DEFAULT '8',
  `it618_homenavname` varchar(100) NOT NULL,
  `it618_ishomely` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_homelycount` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isproductly` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_productlycount` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isarticlely` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_articlelycount` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_systemcount` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isimagemove` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_imagemovecount` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_imagemovespeed` int(10) unsigned NOT NULL DEFAULT '30',
  `it618_productvisitcount` int(10) unsigned NOT NULL DEFAULT '9',
  `it618_productsalecount` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isgoodsclass` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isyunfeikg` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_alipaybl` float(9,2) NOT NULL DEFAULT '100',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '50',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '5',
  `it618_txtype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_salebl` float(9,2) NOT NULL DEFAULT '100',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uprice` float(9,2) NOT NULL DEFAULT '0',
  `it618_focusheight` int(10) unsigned NOT NULL DEFAULT '200',
  `it618_kdaddr` varchar(20) NOT NULL,
  `it618_money` float(12,2) NOT NULL DEFAULT '0',
  `it618_moneysum` float(12,2) NOT NULL,
  `it618_levelsum` int(10) unsigned NOT NULL,
  `it618_power` int(10) unsigned NOT NULL,
  `it618_isgoodscheck` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isgoodssafe` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_htstate` int(10) unsigned NOT NULL,
  `it618_filespace` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_htetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_brandgroup`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_brandgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupname` varchar(50) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_isgoods` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isouturl` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_goodscount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issaleagain` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issaletype1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issaletype2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issaletype3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issaletype4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issaletype5` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ispaytype1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ispaytype2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isorder` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ispjpic` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_islive` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issaleout` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isuservip` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_iscard` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '1000',
  `it618_bz` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_moneyset`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_moneyset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islogin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_zsbl` float(9,2) NOT NULL,
  `it618_num` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_num1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_zsbl1` float(9,2) NOT NULL,
  `it618_zsbl2` float(9,2) NOT NULL,
  `it618_zsbl3` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_live`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_live` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islogin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ischat` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isip` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_livetype` varchar(50) NOT NULL,
  `it618_liveid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videourl` varchar(1000) NOT NULL,
  `it618_videoiframe` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_style`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_style` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_nav`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_brand_area`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_brand_area` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_brand_area1`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_brand_area1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_area_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_brand_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_brand_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_classnamenav` varchar(10) NOT NULL,
  `it618_cssname` varchar(50) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_brandcount` int(10) unsigned NOT NULL,
  `it618_wapbrandcount` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL DEFAULT '',
  `it618_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_brand_class1`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_brand_class1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_brandclass_id` int(10) unsigned NOT NULL,
  `it618_brandclass1_id` int(10) unsigned NOT NULL,
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_name` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_ptypename` varchar(255) NOT NULL,
  `it618_ptypename1` varchar(255) NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uprice` float(9,2) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_prepaybl` float(9,2) NOT NULL DEFAULT '0',
  `it618_kgbl` float(9,3) NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_punit` varchar(10) NOT NULL,
  `it618_xiangoutime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xiangoucount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjhaocount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjzhongcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjchacount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_picbig` varchar(300) NOT NULL,
  `it618_picbig1` varchar(300) NOT NULL,
  `it618_picbig2` varchar(300) NOT NULL,
  `it618_picbig3` varchar(300) NOT NULL,
  `it618_picbig4` varchar(300) NOT NULL,
  `it618_picsmall` varchar(300) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_mappoint_buy` varchar(50) NOT NULL,
  `it618_message_buy` mediumtext NOT NULL,
  `it618_wapmessage1` mediumtext NOT NULL,
  `it618_wapmessage2` mediumtext NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_brandorder` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isorderbuy` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istelsale` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isbm` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issaledisplay` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isduihuan` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isalipay` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isyunfeifree` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL,
  `it618_xgtime1` varchar(20) NOT NULL,
  `it618_xgtime2` varchar(20) NOT NULL,
  `it618_xgtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_goods_type`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_goods_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_name1` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uprice` float(9,2) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_goods_km`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_goods_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_goods_type_km`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_goods_type_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_goods_salekm`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_goods_salekm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_home_ly`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_home_ly` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_quoteid` int(10) unsigned NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_image`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(1000) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_smallurl` varchar(1000) NOT NULL,
  `it618_fileext` varchar(10) NOT NULL,
  `it618_filesize` float(9,2) NOT NULL,
  `it618_ishomemove` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_image_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_image_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_link`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_onepage`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_onepage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_name` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_waphome` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_product_ly`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_product_ly` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_quoteid` int(10) unsigned NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_money`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_saleuid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saleid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL,
  `it618_money` float(9,2) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_pname` varchar(200) NOT NULL,
  `it618_gtypename` varchar(100) NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_kddan` varchar(100) NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_prepaybl` float(9,2) NOT NULL DEFAULT '0',
  `it618_zk` float(9,2) NOT NULL DEFAULT '100',
  `it618_quanmoney` float(9,2) NOT NULL,
  `it618_vipzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_alipaybl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tc` float(9,2) NOT NULL DEFAULT '0',
  `it618_txtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_txjfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_txjfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_txjfcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL,
  `it618_addr` varchar(2000) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr1` varchar(200) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_salebz` varchar(2000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_state_tuihuo` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content_tuihuo` varchar(1000) NOT NULL,
  `it618_ismessage` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(50) NOT NULL,
  `it618_paycode` varchar(50) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuitcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tuitc` float(9,2) NOT NULL DEFAULT '0',
  `it618_pj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content_pj` varchar(1000) NOT NULL,
  `it618_pjtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pinsaleid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_sale_pjpic`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_sale_pjpic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_pjpic` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_order`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_pname` varchar(200) NOT NULL,
  `it618_gtypename` varchar(100) NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_zk` float(9,2) NOT NULL DEFAULT '100',
  `it618_jfcount` int(10) unsigned NOT NULL,
  `it618_addr` varchar(2000) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr1` varchar(200) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_kddan` varchar(100) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_show`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_show` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_showid` int(10) unsigned NOT NULL,
  `it618_showtype` varchar(100) NOT NULL,
  `it618_name` varchar(100) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_homecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pagecount` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_ishome` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isnav` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isblank` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_homeorder` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_navorder` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_power` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_visit`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_visit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_visitall`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_visitall` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_visitcount`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_visitcount` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_yuangong`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_yuangong` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_smallimg` varchar(255) NOT NULL,
  `it618_name` varchar(100) NOT NULL,
  `it618_zhiwei` varchar(100) NOT NULL,
  `it618_tjly` varchar(2000) NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL,
  `it618_isxssale` int(10) unsigned NOT NULL,
  `it618_isxxsale` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_yuangongsale`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_yuangongsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_bz` varchar(200) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_level`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_level` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_salecount1` int(10) unsigned NOT NULL,
  `it618_salecount2` int(10) unsigned NOT NULL,
  `it618_about` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_kd`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_kd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_kdcomid` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_kdarea`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_kdarea` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_kdyunfei`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_kdyunfei` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_kdareaid` int(10) unsigned NOT NULL,
  `it618_firstcount` int(10) unsigned NOT NULL,
  `it618_firstscore` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_firstprice` float(9,2) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_firstkg` float(9,3) NOT NULL,
  `it618_firstkgscore` int(10) unsigned NOT NULL,
  `it618_kgscore` int(10) unsigned NOT NULL,
  `it618_firstkgprice` float(9,2) NOT NULL,
  `it618_kgprice` float(9,2) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_bank`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_bankname` varchar(200) NOT NULL,
  `it618_bankid` varchar(50) NOT NULL,
  `it618_bankaddr` varchar(50) NOT NULL,
  `it618_alipayname` varchar(50) NOT NULL,
  `it618_alipay` varchar(100) NOT NULL,
  `it618_wxname` varchar(50) NOT NULL,
  `it618_wx` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_txbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_txbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_num1` int(10) unsigned NOT NULL,
  `it618_num2` int(10) unsigned NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_tx`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_tx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_bz` varchar(1000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_card`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_card` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_cardid` varchar(32) NOT NULL,
  `it618_tel` varchar(32) NOT NULL,
  `it618_name` varchar(10) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_cardmoney`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_cardmoney` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_count1` int(10) unsigned NOT NULL,
  `it618_count2` int(10) unsigned NOT NULL,
  `it618_money1` float(9,2) NOT NULL,
  `it618_money2` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_viplevel`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_viplevel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_level` int(10) unsigned NOT NULL,
  `it618_money1` float(9,2) NOT NULL,
  `it618_money2` float(9,2) NOT NULL,
  `it618_zk` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_gwc`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_gwc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0',
  `it618_kdid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_gwcsale_main`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_gwcsale_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_paycode` varchar(50) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_gwcsale`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_gwcsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_pname` varchar(200) NOT NULL,
  `it618_gtypename` varchar(100) NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_prepaybl` float(9,2) NOT NULL DEFAULT '0',
  `it618_zk` float(9,2) NOT NULL DEFAULT '100',
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_alipaybl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tc` float(9,2) NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL,
  `it618_quanmoney` float(9,2) NOT NULL,
  `it618_vipzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addr` varchar(2000) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr1` varchar(200) NOT NULL,
  `it618_bz` varchar(8000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_saleaudio`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_saleaudio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_collect`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_findkey`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_brand_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_brand_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmQueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmRfU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmRfU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmRfVENfQklHNS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmRfVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('c291cmNlL3BsdWdpbi9pdDYxOF9icmFuZC91cGdyYWRlLnBocA=='));
@unlink(DISCUZ_ROOT . base64_decode('c291cmNlL3BsdWdpbi9pdDYxOF9icmFuZC9pbnN0YWxsLnBocA=='));
?>