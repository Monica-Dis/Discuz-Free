<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

if($Shop_isgoods==0){
	echo $it618_brand_lang['s1645'];exit;
}

if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','product_list@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=product_list&sid='.$ShopId);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$it618_brand_show = C::t('#it618_brand#it618_brand_show')->fetch_by_shopid_showid_showtype($ShopId,0,'product_all');
$ppp = $it618_brand_show['it618_pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$sql="";

$subtitle=it618_brand_getlang('s551');
$hrefsql=it618_brand_getrewrite('shop_productlist',$ShopId.'@0@it618page','plugin.php?id=it618_brand:product_list&sid='.$ShopId);

if(isset($_GET['cid']) && $_GET['cid']){
	$subtitle=C::t('#it618_brand#it618_brand_class')->fetch_it618_classname_by_id($_GET['cid']);
	$hrefsql=it618_brand_getrewrite('shop_productlist',$ShopId.'@'.$_GET['cid'].'@it618page','plugin.php?id=it618_brand:product_list&sid='.$ShopId.'&cid='.$_GET['cid']);
}

$uri='?';

$sql='it618_ison=1 and it618_state=1';
$price1='';$price2='';
if($_GET['formhash']==FORMHASH){
	
	if(isset($_GET['sw']) && $_GET['sw']){
		$sw=strip_tags($_GET['sw']);
		$uri.='&sw='.$sw;
	}
	
	if(isset($_GET['price1']) && $_GET['price1']){
		$price1=floatval($_GET['price1']);
		if($price1==0)$price1='';
		$uri.='&price1='.$price1;
	}
	
	if(isset($_GET['price2']) && $_GET['price2']){
		$price2=floatval($_GET['price2']);
		if($price2==0)$price2='';
		$uri.='&price2='.$price2;
	}
	
	if(isset($_GET['it618_paytype']) && $_GET['it618_paytype']){
		$uri.='&it618_paytype='.$_GET['it618_paytype'];
		
		if($_GET['it618_paytype']==1){$sql.=" and it618_isduihuan=1";$it618_paytype_selected1='selected="selected"';}
		if($_GET['it618_paytype']==2){$sql.=" and it618_isalipay=1";$it618_paytype_selected2='selected="selected"';}
	}
	
	if(isset($_GET['it618_saletype']) && $_GET['it618_saletype']){
		$uri.='&it618_saletype='.$_GET['it618_saletype'];
		
		if($_GET['it618_saletype']==1){$sql.=" and (it618_saletype=1 or it618_saletype=4)";$it618_saletype_selected1='selected="selected"';}
		if($_GET['it618_saletype']==2){$sql.=" and (it618_saletype=2 or it618_saletype=4)";$it618_saletype_selected2='selected="selected"';}
		if($_GET['it618_saletype']==3){$sql.=" and it618_saletype=3";$it618_saletype_selected3='selected="selected"';}
		if($_GET['it618_saletype']==4){$sql.=" and it618_saletype=5";$it618_saletype_selected4='selected="selected"';}
	}
	
	if($uri!=''){$subtitle=it618_brand_getlang('s552');$uri=$uri.'&formhash='.FORMHASH;}

}

$uri=str_replace("?&","?",$uri);
if($uri=='?')$uri='';

$pagelistcount = C::t('#it618_brand#it618_brand_goods')->count_by_shopid($ShopId,$sql,'',$_GET['sw'],$_GET['cid'],$price1,$price2);
$multipage = multi($pagelistcount, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_brand_multipage($multipage,$uri);
$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
if($ii1ill[5]!='_')return;

$i=1;
foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_shopid(
	$ShopId,$sql,'it618_order DESC',$_GET['sw'],$_GET['cid'],$price1,$price2,$startlimit,$ppp
) as $it618_brand_goods) {
	$tmpurl=it618_brand_getrewrite('shop_product',$ShopId.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.$it618_brand_goods['id']);
	$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
	
	$jfblstr='';
	if($it618_brand_goods['it618_saletype']==6){
		$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
		$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
	}
	
	if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
		$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
	}
	
	$jfbl='';
	if($jfblstr!=''){
		$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
	}
	
	if($i%4!=0){$noml=' noml';}else{$noml='';}

	$it618_count=$it618_brand_lang['s1652'].' <font color="#FF6600">'.$it618_brand_goods['it618_count'].'</font>';
	
	if($it618_brand_goods['it618_isalipay']==1){
		$pricestr='<div class="now-price"><em>'.$it618_brand_goods['it618_uprice'].' '.it618_brand_getlang('s389').'</em></div>
				  <div class="market-price"><del>'.$it618_brand_goods['it618_price'].' '.it618_brand_getlang('s389').'</del></div>';
	}else{
		$pricestr='<div class="now-price1"><em>'.$it618_brand_goods['it618_score'].' '.$creditname.'</em></div>';
	}
	
	if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
		$jfblstr='<font color=#339900>'.$it618_brand_goods['it618_score'].$creditname.'</font> '.$jfblstr;
	}
	
	$salecount='<span style="float:right;">'.it618_brand_getlang('s1298').''.$salecount.'</span>';
	
	if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
		$pricestr='<div class="now-price1"><em>'.$it618_brand_lang['s761'].'</em></div>';
		$jfblstr=$it618_brand_lang['s1732'].'<br>';
		$salecount='<span style="float:right;">'.it618_brand_getlang('t474').' <font color=#FF7575>'.$it618_brand_goods['it618_views'].'</font></span>';
	}
	
	$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
	$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
	$pjhaobl=intval($pjhaocount/$pjallcount*100);
	$pj=$it618_brand_lang['s1899'];
	if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';
	
	$goodslist.='<li class="product '.$noml.'">'.$jfbl.'
				  <h3>'.$it618_brand_goods['it618_name'].'</h3>
				  <div class="info"">
				  <div class="pic">
				  <a href="'.$tmpurl.'" target="_blank"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" /></a>
				  </div>
				  <div class="name"><a href="'.$tmpurl.'" target="_blank" class="a1" title="'.$it618_brand_goods['it618_name'].'">'.cutstr($it618_brand_goods['it618_name'],26,'...').'</a><br><font color="#999" title="'.$it618_brand_goods['it618_seodescription'].'">'.$it618_brand_goods['it618_seodescription'].'</font></div>
				  <div class="jifena">'.$salecount.$pj.'</div>
				  <div class="price">
				  '.$pricestr.'
				  </div>
				  </div>
				  </li>';
	
	$i=$i+1;
}

if($multipage!='')$multipage='<div class="commonpage" style="margin-top:10px;">'.str_replace(" / ","/",$multipage).'</div>';

if($Shop_isgoodsclass==1){
	if($_GET['cid']=='')$curcss='class="current"';else $curcss='';
	$str_productfindclass='<a href="'.$shop_productlist.'" value="0" '.$curcss.'>'.it618_brand_getlang('s874').'</a>';
	foreach(C::t('#it618_brand#it618_brand_class')->fetch_all_by_shopid($ShopId) as $it618_brand_class) {
		$tmpurl=it618_brand_getrewrite('shop_productlist',$ShopId.'@'.$it618_brand_class['id'].'@1','plugin.php?id=it618_brand:product_list&sid='.$ShopId.'&cid='.$it618_brand_class['id']);
		if($it618_brand_class['id']==$_GET['cid'])$curcss='class="current"';else $curcss='';
		$str_productfindclass.='<a href="'.$tmpurl.'" '.$curcss.'>'.$it618_brand_class['it618_classname'].'</a>';
	}
}


$tmparr=explode(":",$_GET['id']);
$pagetype=$tmparr[1];
$seotitle=$subtitle;
$seokeywords=$Shop_seokeywords;
$seodescription=$Shop_seodescription;
$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo; '.$subtitle;

$idforly=$pid;
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_nav.func.php';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:shop_default');
?>