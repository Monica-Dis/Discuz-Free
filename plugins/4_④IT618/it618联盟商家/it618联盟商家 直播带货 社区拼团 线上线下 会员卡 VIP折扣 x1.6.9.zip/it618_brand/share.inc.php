<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_brand = $_G['cache']['plugin']['it618_brand'];

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if($_GET['sharetype']=='shop'){
	$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['shareid']);
	$it618_name=$it618_brand_brand['it618_name'];
	$share_img=$it618_brand_brand['it618_logo'];
	$tmparr=explode('://',$share_img);
	if(count($tmparr)==1)$share_img=$_G['siteurl'].$share_img;
	$it618_about=$it618_brand_brand['it618_addr'].' '.$it618_brand_brand['it618_dianhua'].' '.$it618_brand_brand['it618_shouji'].' '.$it618_brand_brand['it618_about'];
	
	if($IsUnion==1&&$_G['uid']>0){
		$urltmp='tuiuid='.$_G['uid'];
	}
	
	if($urltmp!=''){
		$tmpurl=$_G['siteurl'].it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id'].'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=$_G['siteurl'].it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
	}
	
	if($IsWxMini==1){
		if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_brand')){
			$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
		}
	}
	
	$qrcodesrc='plugin.php?id=it618_brand:urlcode&url='.urlencode($tmpurl);
	
	if($IsUnion==1){
		$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=4 and it618_isshop=1 and it618_state=1");
		if($sharecodecount>0){
			$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=4&class=shop&dataid='.$it618_brand_brand['id'].'&shareurl='.urlencode($tmpurl);
		}
	}
	
}else{
	$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($_GET['shareid']);
	$pid=$it618_brand_goods['id'];
	$it618_name=$it618_brand_goods['it618_name'];
	$share_img=it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']);
	$tmparr=explode('://',$share_img);
	if(count($tmparr)==1)$share_img=$_G['siteurl'].$share_img;
	$it618_about=$it618_brand_goods['it618_seodescription'];
	$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
	
	$creditname=$_G['setting']['extcredits'][$it618_brand['brand_credit']]['title'];
	
	if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
		$goodspricestr='&yen;'.floatval($it618_brand_goods['it618_uprice']).' <font color=#390>'.$it618_brand_goods['it618_score'].$creditname.'</font>';
	}else{
		if($it618_brand_goods['it618_isalipay']==1){
			$goodspricestr='&yen;'.$it618_brand_goods['it618_uprice'];
		}else{
			$goodspricestr='<font color=#390>'.$it618_brand_goods['it618_score'].$creditname.'</font>';
		}	
	}
	
	$pricestr='<font color=#f30>'.$goodspricestr.'</font>';
	
	if($IsUnion==1&&$_G['uid']>0){
		$urltmp='tuiuid='.$_G['uid'];
	}
	
	if($urltmp!=''){
		$tmpurl=$_G['siteurl'].it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id'].'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=$_G['siteurl'].it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
	}
	
	if($IsWxMini==1){
		if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_brand')){
			$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
		}
	}
	
	$qrcodesrc='plugin.php?id=it618_brand:urlcode&url='.urlencode($tmpurl);
	
	if($IsUnion==1){
		$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=4 and it618_isproduct=1 and it618_state=1");
		if($sharecodecount>0){
			$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=4&class=product&dataid='.$it618_brand_goods['id'].'&shareurl='.urlencode($tmpurl);
		}
	}
	
}

if($IsUnion==1){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
	}
}

$tuicount=intval($_GET['tuicount']);
if($sharecodecount>0||$union_brand_isok>0||$tuicount>0){
	$sharetui=1;
}

if($_GET['wap']==1){
	if($sharetui>0){
		$shoptype='brand';
		$scrolldivheight=$_GET['height']-100;
		
		$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
		$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
		include template('it618_union:unionshare');
		$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
	}
}else{
	if($sharetui>0){
		$shoptype='brand';
		$scrolldivheight=390;
		
		include template('it618_union:unionshare');
	}
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:share');
?>