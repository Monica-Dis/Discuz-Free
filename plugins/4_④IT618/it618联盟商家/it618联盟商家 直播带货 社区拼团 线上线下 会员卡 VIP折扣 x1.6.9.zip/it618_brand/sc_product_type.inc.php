<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if($Shop_isgoods==0){
	it618_cpmsg($it618_brand_lang['s1640'], '', 'error');
}

$pid=intval($_GET['pid']);
$preurl=$_GET['preurl'];
$preurl1=$_GET['preurl1'];
$urlsql='&pid='.$pid;
$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_brand_goods_type', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			if($_GET['it618_score'][$id]>$ShopSCORE){
				$it618_score=$_GET['it618_score'][$id];
			}else{
				$it618_score=$ShopSCORE;
			}
			
			if($_GET['it618_uprice'][$id]>$ShopUPRICE){
				$it618_uprice=$_GET['it618_uprice'][$id];
			}else{
				$it618_uprice=$ShopUPRICE;
			}

			C::t('#it618_brand#it618_brand_goods_type')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_name1' => trim($_GET['it618_name1'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
				'it618_order1' => trim($_GET['it618_order1'][$id]),
				'it618_uprice' => $it618_uprice,
				'it618_price' => trim($_GET['it618_price'][$id]),
				'it618_score' => $it618_score,
				'it618_ison' => trim($_GET['it618_ison'][$id])
			));
			
			if($it618_brand_goods['it618_saletype']!=3){
				C::t('#it618_brand#it618_brand_goods_type')->update($id,array(
					'it618_count' => trim($_GET['it618_count'][$id])
				));
			}
			
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_name1_array = !empty($_GET['newit618_name1']) ? $_GET['newit618_name1'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	$newit618_order1_array = !empty($_GET['newit618_order1']) ? $_GET['newit618_order1'] : array();
	$newit618_count_array = !empty($_GET['newit618_count']) ? $_GET['newit618_count'] : array();
	$newit618_uprice_array = !empty($_GET['newit618_uprice']) ? $_GET['newit618_uprice'] : array();
	$newit618_price_array = !empty($_GET['newit618_price']) ? $_GET['newit618_price'] : array();
	$newit618_score_array = !empty($_GET['newit618_score']) ? $_GET['newit618_score'] : array();

	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			if(trim($newit618_score_array[$key])>$ShopSCORE){
				$it618_score=trim($newit618_score_array[$key]);
			}else{
				$it618_score=$ShopSCORE;
			}
			
			if(trim($newit618_uprice_array[$key])>$ShopUPRICE){
				$it618_uprice=trim($newit618_uprice_array[$key]);
			}else{
				$it618_uprice=$ShopUPRICE;
			}
			                                        
			C::t('#it618_brand#it618_brand_goods_type')->insert(array(
				'it618_pid' => $pid,
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_name1' => trim($newit618_name1_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
				'it618_order1' => trim($newit618_order1_array[$key]),
				'it618_count' => trim($newit618_count_array[$key]),
				'it618_uprice' => $it618_uprice,
				'it618_price' => trim($newit618_price_array[$key]),
				'it618_score' => $it618_score
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}
	
	$count=C::t('#it618_brand#it618_brand_goods_type')->count_by_pid_ok_isname1($pid);
	if($count>0){
		$it618_brand_goods_types=C::t('#it618_brand#it618_brand_goods_type')->fetch_name_by_it618_pid1($pid);
	}else{
		$it618_brand_goods_types=C::t('#it618_brand#it618_brand_goods_type')->fetch_name_by_it618_pid($pid);
	}
	
	foreach($it618_brand_goods_types as $it618_brand_goods_typetmp) {
		$goodstypename=$it618_brand_goods_typetmp['it618_name'];
		break;
	}
	
	foreach(C::t('#it618_brand#it618_brand_goods_type')->fetch_name1_by_it618_pid_name($pid,$goodstypename) as $it618_brand_goods_typetmp) {
		$goodstypename1=$it618_brand_goods_typetmp['it618_name1'];
		break;
	}
	
	$it618_brand_goods_typetmp=C::t('#it618_brand#it618_brand_goods_type')->fetch_by_pid_name_name1_ok($pid,$goodstypename,$goodstypename1);
	C::t('#it618_brand#it618_brand_goods')->update($pid,array(
		'it618_uprice' => $it618_brand_goods_typetmp['it618_uprice'],
		'it618_price' => $it618_brand_goods_typetmp['it618_price'],
		'it618_score' => $it618_brand_goods_typetmp['it618_score']
	));
	
	$it618_count=C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_count_by_pid($pid);
	C::t('#it618_brand#it618_brand_goods')->update($pid,array(
		'it618_ptypename' => $_GET['it618_ptypename'],
		'it618_ptypename1' => $_GET['it618_ptypename1'],
		'it618_count' => $it618_count
	));

	it618_cpmsg($it618_brand_lang['s5'].$ok1.' '.$it618_brand_lang['s6'].$ok2.' '.$it618_brand_lang['s7'].$del.')', "plugin.php?id=it618_brand:sc_product_type$adminsid&pid=$pid&preurl=$preurl", 'succeed');
}

it618_showformheader("plugin.php?id=it618_brand:sc_product_type$adminsid&pid=$pid&preurl=$preurl");
$preurltmp=str_replace("@","&",$preurl);
showtableheaders('<a href="'.$preurltmp.'"><font color=red>'.$it618_brand_goods['it618_name'].'</font></a> '.$it618_brand_lang['s1712'],'admin_shopproduct_type');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type')." WHERE it618_pid=".$pid);

echo '<tr><td colspan=15>'.$it618_brand_lang['s1719'].'<input class="txt" type="text" name="it618_ptypename" style="width:100px" value="'.$it618_brand_goods['it618_ptypename'].'"> '.$it618_brand_lang['s1724'].'<input class="txt" type="text" name="it618_ptypename1" style="width:100px" value="'.$it618_brand_goods['it618_ptypename1'].'">'.$it618_brand_lang['s1725'].' </td></tr>';
echo '<tr><td colspan=15>'.$it618_brand_lang['s1714'].$count.'<span style="float:right;color:red">'.$it618_brand_lang['s1721'].'</span></td></tr>';

$price1=' ';$price2=' ';$price3=' ';
if($Shop_ispaytype2==1){
	$price1=$it618_brand_lang['s1717'];
	$price2=$it618_brand_lang['s1723'];
}

if($Shop_ispaytype1==1){
	$price3=$it618_brand_lang['s1713'];
}

showsubtitle(array('', $it618_brand_lang['s1715'].'/'.$it618_brand_lang['s1626'], $it618_brand_lang['s1847'].'/'.$it618_brand_lang['s1626'], $it618_brand_lang['s1716'], $price1, $price2, $price3, $it618_brand_lang['s1722'], $it618_brand_lang['s1718']));

$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods_type')." WHERE it618_pid=".$pid." ORDER BY it618_order,it618_name,it618_order1,it618_name1");
while($it618_brand_goods_type = DB::fetch($query)) {

	$salecount = C::t('#it618_brand#it618_brand_sale')->sumcount_by_it618_gtypeid($it618_brand_goods_type['id']);
	$disabled="";$readonly="";$bgcolor="";
	if($salecount>0){$disabled="disabled=\"disabled\"";$readonly="readonly";$bgcolor=";background-color:#e8e8e8";}
	if($it618_brand_goods_type['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
	
	if($it618_brand_goods['it618_saletype']==3){
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type_km')." WHERE it618_gtypeid=".$it618_brand_goods_type['id']);
		
		$preurl1="plugin.php?id=it618_brand:sc_product_type&pid=".$it618_brand_goods['id']."$adminsid";
		$preurl1=str_replace("&","@",$preurl1);
		
		$saletypestr='<a href="plugin.php?id=it618_brand:sc_product_km'.$adminsid.'&pid='.$it618_brand_goods[id].'&gtypeid='.$it618_brand_goods_type[id].'&preurl='.$preurl.'&preurl1='.$preurl1.'">'.it618_brand_getlang('s1225').'(<font color=red>'.$kmcount.'</font>)</a>';
	}else{
		$saletypestr="<input type=\"text\" class=\"txt\" style=\"width:50px\" name=\"it618_count[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_count]\">";
	}
	
	if($Shop_ispaytype2==1){
		$price1="<input type=\"text\" class=\"txt\" style=\"width:50px;color:red\" name=\"it618_uprice[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_uprice]\">";
		$price2="<input type=\"text\" class=\"txt\" style=\"width:50px\" name=\"it618_price[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_price]\">";
	}
	
	if($Shop_ispaytype1==1){
		$price3="<input type=\"text\" class=\"txt\" style=\"width:50px;color:blue\" name=\"it618_score[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_score]\">";
	}
	
	if($IsPinEdu==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
		$goodspin=it618_pinedu_getgoodspinstate('brand',$it618_brand_goods_type['id']);
		$goodspinstr=' <a href="javascript:" onclick="showgoodspin('.$goodspin['id'].','.$it618_brand_goods_type['id'].')"><font color=blue>'.$goodspin['name'].'</font>'.$goodspin['count'].'</a>';
	}
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_brand_goods_type['id'].'" name="delete[]" value="'.$it618_brand_goods_type['id'].'" '.$disabled.'><label for="chk_del'.$it618_brand_goods_type['id'].'">'.$it618_brand_goods_type['id'].'</label>',
		"<input type=\"text\" class=\"txt\" style=\"width:115px$bgcolor\" name=\"it618_name[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_name]\" $readonly>
		<input type=\"text\" class=\"txt\" style=\"width:30px\" name=\"it618_order[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_order]\">",
		"<input type=\"text\" class=\"txt\" style=\"width:115px$bgcolor\" name=\"it618_name1[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_name1]\" $readonly>	<input type=\"text\" class=\"txt\" style=\"width:30px\" name=\"it618_order1[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_order1]\">".$goodspinstr,
		$saletypestr,
		$price1,
		$price2,
		$price3,
		'<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_brand_goods_type['id'].']" '.$it618_ison_checked.' value="1">',
		$salecount
	));
}
	
	global $_G;

	loadcache('plugin');
	$it618_brand = $_G['cache']['plugin']['it618_brand'];
	
	if($IsPinEdu==1){
	echo '
	<script>
	function showgoodspin(pinid,typeid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_pinedu_lang['s5'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["930px", "430px"],
			content: "plugin.php?id=it618_pinedu:sc_product&shoptype=brand&pinid="+pinid+"&typeid="+typeid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	</script>
	';
	}
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:115px" name="newit618_name[]"><input type="text" class="txt" style="width:30px" name="newit618_order[]">'],
		[1,'<input type="text" class="txt" style="width:115px" name="newit618_name1[]"><input type="text" class="txt" style="width:30px" name="newit618_order1[]">'],
		[1,'<input type="text" class="txt" style="width:50px" name="newit618_count[]">'],
		[1,'<input type="text" class="txt" style="width:50px;color:red" name="newit618_uprice[]">'],
		[1,'<input type="text" class="txt" style="width:50px" name="newit618_price[]">'],
		[1,'<input type="text" class="txt" style="width:50px;color:blue" name="newit618_score[]">'],
		[1,''], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_brand_lang['s128'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>