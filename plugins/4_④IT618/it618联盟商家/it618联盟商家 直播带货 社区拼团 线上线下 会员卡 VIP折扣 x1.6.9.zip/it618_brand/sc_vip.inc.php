<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if($Shop_isuservip==0){
	it618_cpmsg($it618_brand_lang['s1644'], '', 'error');
}

$tmpuid=0;
if(submitcheck('it618submit')){
	if($_GET['idtype']=='uid'){
		$tmpuid=$_GET['it618_uid'];
		if(!$it618_brand_card=C::t('#it618_brand#it618_brand_card')->fetch_by_uid($tmpuid)){
			it618_cpmsg($it618_brand_lang['s1501'], "plugin.php?id=it618_brand:sc_vip$adminsid&page=$page", 'error');
		}else{
			if($it618_brand_card['it618_state']==0){
				it618_cpmsg($it618_brand_lang['s1502'], "plugin.php?id=it618_brand:sc_vip$adminsid&page=$page", 'error');
			}
		}
	}else if($_GET['idtype']=='cardid'){
		$tmpuid = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_cardid($_GET['it618_uid']);
		if($tmpuid==''){
			it618_cpmsg($it618_brand_lang['s1503'], "plugin.php?id=it618_brand:sc_vip$adminsid&page=$page", 'error');
		}
	}else if($_GET['idtype']=='tel'){
		$tmpuid = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_tel($_GET['it618_uid']);
		if($tmpuid==''){
			it618_cpmsg($it618_brand_lang['s1504'], "plugin.php?id=it618_brand:sc_vip$adminsid&page=$page", 'error');
		}
	}
	
	$count = C::t('#it618_brand#it618_brand_cardmoney')->count_by_search($ShopId,$tmpuid);
	if($count==0){
		it618_cpmsg($it618_brand_lang['s1505'], "plugin.php?id=it618_brand:sc_vip$adminsid&page=$page", 'error');
	}
}

it618_showformheader("plugin.php?id=it618_brand:sc_vip$adminsid&page=$page");
showtableheaders(it618_brand_getlang('s1402'),'it618_brand_viplevel');
	$count = C::t('#it618_brand#it618_brand_cardmoney')->count_by_search($ShopId,$tmpuid);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_brand:sc_vip");
	
	echo '<tr><td colspan=4>'.it618_brand_getlang('s1395').'<select name=idtype><option value="uid">'.it618_brand_getlang('s1396').'</option><option value="cardid">'.it618_brand_getlang('s1393').'</option><option value="tel">'.it618_brand_getlang('s1394').'</option></select><input name="it618_uid" class="txt" style="margin-left:10px;width:238px;height:20px;color:green;font-weight:bold;line-height:20px;font-size:20px;"/><input type="submit" name="it618submit" class="btn" style="width:60px;height:25px" value="'.it618_brand_getlang('s34').'" /></td></tr>';
	
	echo '<tr><td colspan=15>'.it618_brand_getlang('s1421').$count.'<span style="color:red;float:right">'.it618_brand_getlang('s1422').'</span></td></tr>';
	showsubtitle(array(it618_brand_getlang('s1411'), it618_brand_getlang('s1412'), it618_brand_getlang('s1413'),it618_brand_getlang('s1419'), it618_brand_getlang('s1420'),it618_brand_getlang('s1414'),it618_brand_getlang('s1415'),it618_brand_getlang('s1416'),it618_brand_getlang('s1417'),it618_brand_getlang('s1428')));

	foreach(C::t('#it618_brand#it618_brand_cardmoney')->fetch_all_by_search($ShopId,$tmpuid,$startlimit,$ppp) as $it618_brand_cardmoney) {
		
		$it618_brand_card=C::t('#it618_brand#it618_brand_card')->fetch_by_uid($it618_brand_cardmoney['it618_uid']);
		
		$username=C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($it618_brand_card['it618_uid']);
		$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$it618_brand_card['it618_uid']);
		if($creditnum=="")$creditnum=0;
		
		$moneycount=C::t('#it618_brand#it618_brand_money')->count_by_shopid(0,0,0,0,$it618_brand_card['it618_uid']);
		$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(1,$moneycount);
		$tmplevelarr=explode(",",$it618_brand['brand_level']);
		
		$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
		$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($it618_brand_cardmoney['it618_shopid'],$allmoney);
		$viplevel=$fetch_by_money['it618_level'];
		if($viplevel==''){
			$viplevel='<font color=blue>'.it618_brand_getlang('s1423').'</font>';
			$zk='';
		}else{
			$viplevel='<font color=red>VIP'.$viplevel.'</font>';
			$zk='<font color=#f60>'.$fetch_by_money['it618_zk'].'%</font>';
		}
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			'<a href="home.php?mod=space&uid='.$it618_brand_card['it618_uid'].'" target="_blank">'.$username.'(<b>'.$it618_brand_card['it618_uid'].'</b>)',
			$it618_brand_card['it618_cardid'],
			$it618_brand_card['it618_tel'],
			'<a href="'.$it618_brand['brand_levelurl'].'" target="_blank" title="'.$it618_brand_level['it618_name'].' '.$it618_brand['brand_leveltitle'].'"><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'"></a>',
			$creditnum,
			$it618_brand_cardmoney['it618_count1'].'/'.$it618_brand_cardmoney['it618_money1'],
			$it618_brand_cardmoney['it618_count2'].'/'.$it618_brand_cardmoney['it618_money2'],
			'<font color=red>'.$allmoney.'</font>',
			$viplevel,
			$zk
		));
	}
	
echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td></tr>';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>