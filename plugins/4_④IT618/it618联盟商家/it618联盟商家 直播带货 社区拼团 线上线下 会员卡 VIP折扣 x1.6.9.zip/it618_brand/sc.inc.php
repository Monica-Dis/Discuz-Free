<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_default.func.php';

if(isset($_GET['adminsid'])){
	$adminsid='&adminsid='.$_GET['adminsid'];	
}

if($templatename_admin=='sc_proton'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
		$it618_membersstr= '<span id="it618_members"></span>'.it618_members_getmembers($_GET['id'],'#it618_members');
	}
	
	if($IsCredits==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
		$it618_creditsstr= '<span id="it618_credits"></span>'.it618_credits_getcredits($_GET['id'],'#it618_credits');
	}
	
	if($IsGroup==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
		$it618_membersstr.=it618_group_getad($_GET['id'],2);
	}
	
	$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($ShopId);
	$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
	
	$ShopName1=$ShopName;
	if(isset($_GET['adminsid'])){
		$ShopName1=$ShopName.'(<font color=red>'.$it618_brand_lang['s1221'].'</font>)';
	}
	
	$username=$_G['username'];
	$u_avatarimg=it618_brand_discuz_uc_avatar($_G['uid'],'middle');
}else{
	if(isset($_GET['adminsid'])){
		$adminshop='<span style="color:red;font-size:13px">('.it618_brand_getlang('s1221').')</span>';
	}
	
	$pcount=C::t('#it618_brand#it618_brand_goods')->count_by_shopid($ShopId);
	$articlecount=C::t('#it618_brand#it618_brand_article')->count_by_shopid($ShopId);
	$articlecount1=C::t('#it618_brand#it618_brand_onepage')->count_by_shopid($ShopId);
	$articlecount=$articlecount+$articlecount1;
	$imagecount=C::t('#it618_brand#it618_brand_image')->count_by_shopid($ShopId);
	
	$config_path=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/';
	
	$allsize = it618_brand_dirsize($config_path); 
	$allsize = $allsize/1024/1024; 
	
	if($Shop_filespace-$allsize>0){
		$oksize=sprintf("%.2f", ($Shop_filespace-$allsize));
	}else{
		$oksize=0;
	}
	
	if($Shop_isgoods==1){
		$pcountstr=it618_brand_getlang('s1386').'<font color="red"><b>'.$pcount.'</b></font> <font color="#ccc">|</font> ';
	}
	
	it618_brand_getshopmoney($ShopId);
	
	$filespacestr=$pcountstr.it618_brand_getlang('s1387').'<font color="red"><b>'.$articlecount.'</b></font> <font color="#ccc">|</font> '.it618_brand_getlang('s1388').'<font color="red"><b>'.$imagecount.'</b></font> <font color="#ccc">|</font> '.it618_brand_getlang('s1389').'<font color="red"><b>'.$Shop_filespace.'</b></font> M'.it618_brand_getlang('s1390').'<font color="green"><b>'.$oksize.'</b></font> M';
}

$urltmp='member.php?mod=logging&action=logout&formhash='.FORMHASH;

$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:'.$templatename_admin.'/sc_index');
?>