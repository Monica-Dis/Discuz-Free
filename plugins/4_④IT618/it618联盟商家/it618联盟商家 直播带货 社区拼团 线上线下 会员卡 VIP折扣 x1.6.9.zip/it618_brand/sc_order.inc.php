<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_brand/js/Calendar.js"></script>
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/js/jquery.js"></script>

<script>
var dialog_fahuo,dialog_bz;
KindEditor.ready(function(K){});

function savekd(){
	var orderid=document.getElementById("orderid").value;
	var it618_kdid=document.getElementById("it618_kdid").value;
	var it618_kdid=it618_kdid.replace("selected=selected","");
	var it618_kddan=document.getElementById("it618_kddan").value;
	if(it618_kdid==0){
		sendmsg(\'kdtips\',\''.it618_brand_getlang('s1109').'\');
		return;
	}
	if(it618_kddan==""){
		sendmsg(\'kdtips\',\''.it618_brand_getlang('s1110').'\');
		return;
	}
	
	IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax'.$adminsid.'&sid='.$ShopId.'&orderid="+orderid+"&it618_kdid="+it618_kdid+"&it618_kddan="+it618_kddan+"&formhash='.FORMHASH.'", {ac:"ordersavekd"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		alert(tmparr[1]);
		getorderlist(orderurl);
		dialog_fahuo.remove();
	}else{
		sendmsg(\'kdtips\',tmparr[1]);
	}
	}, "html");

}

function okorder(orderid,type){
	if(type==1)var tmpstr="'.it618_brand_getlang('s1542').'";
	if(type==0)var tmpstr="'.it618_brand_getlang('s1543').'";
	if(confirm(tmpstr)){
		IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax'.$adminsid.'&sid='.$ShopId.'&orderid="+orderid+"&type="+type+"&formhash='.FORMHASH.'", {ac:"okorder"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getorderlist(orderurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function delorder(orderid){
	if(confirm("'.it618_brand_getlang('t691').'")){
		IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax'.$adminsid.'&sid='.$ShopId.'&orderid="+orderid+"&formhash='.FORMHASH.'", {ac:"shopdelorder"},function (data, textStatus){
			
			var tmparr=data.split("it618_split");
			if(tmparr[0]=="ok"){
				alert(tmparr[1]);
				getorderlist(orderurl);
			}else{
				alert(data);
			}
		}, "html");	
	}
}

function sendmsg(msgid,msgvalue){
	document.getElementById(msgid).innerHTML=msgvalue;
	setTimeout(\'sendmsg1("\'+msgid+\'")\',3000);
}
function sendmsg1(msgid){
	document.getElementById(msgid).innerHTML="";
}
</script>
';

showtableheaders(it618_brand_getlang('s1535'),'it618_brand_order');

	echo '<tr><td colspan="15"><div class="fixsel">'.it618_brand_getlang('s1114').' <input id="pname" class="txt" style="width:120px" /> '.it618_brand_getlang('s1115').' <input id="finduid" class="txt" style="width:50px" /> '.it618_brand_getlang('s1116').' <select id="state"><option value=0>'.it618_brand_getlang('s1117').'</option><option value=1 style="color:red">'.it618_brand_getlang('s1513').'</option><option value=2 style="color:blue">'.it618_brand_getlang('s1514').'</option><option value=3 style="color:green">'.it618_brand_getlang('s1515').'</option><option value=4 style="color:#F0F">'.it618_brand_getlang('s1516').'</option></select> '.it618_brand_getlang('s1122').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_brand_getlang('t688').'" onclick="findorderlist()" /> </div></td></tr>';
	
	echo '<tr id="tr_ordersum"></tr>';
	
	showsubtitle(array('', it618_brand_getlang('t437'),it618_brand_getlang('t680'),it618_brand_getlang('t681'),it618_brand_getlang('s1130'),it618_brand_getlang('s1548'),it618_brand_getlang('s1549')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_brand/wap/images/loading.gif"></td></tr><tbody id="tr_orderlist"></tbody>';
	
	echo '<tr id="orderpage"></tr>';

showtablefooter(); /*dism��taobao��com*/
echo '
<script>
var orderurl="'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax";
var sqlurl="";
function getorderlist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_orderlist").style.display="none";
	IT618_BRAND.get(url+sqlurl+"'.$adminsid.'&sid='.$ShopId.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"order_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_BRAND("#tr_ordersum").html(tmparr[0]);
	IT618_BRAND("#tr_orderlist").html(tmparr[1]);
	IT618_BRAND("#orderpage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_orderlist").style.display="";
	}, "html");	
	orderurl=url;
}
getorderlist(orderurl);

function findorderlist(){
	var pname = document.getElementById("pname").value;
	var finduid = document.getElementById("finduid").value;
	var state = document.getElementById("state").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&pname="+pname+"&finduid="+finduid+"&state="+state+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax";
	getorderlist(url);
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>