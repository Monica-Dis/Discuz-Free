<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

if(brand_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$ShopId.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$ShopId);
	}

	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$productflag='';
$firstmode=0;
foreach(C::t('#it618_brand#it618_brand_show')->fetch_all_by_shopid_ishome($ShopId) as $it618_brand_show) {
	$modeid=$it618_brand_show['it618_showid'];
	$modetype=$it618_brand_show['it618_showtype'];
	$modename=$it618_brand_show['it618_name'];
	$homecount=$it618_brand_show['it618_homecount'];
	
	if(($modetype=='product_all'||$modetype=='product_tj')&&$productflag==''){
		$homecontent.='<div class="store-search">
          <form action="'.$shop_productlist.'" method="post">
		  <input type="hidden" name="formhash" value="'.FORMHASH.'" />
              <dl class="basic clearfix">
                  <dt><label for="">'.it618_brand_getlang('s885').'</label></dt>
                  <dd><input type="text" id="" name="keywords" class="text-1" value="" maxlength="50"></dd>
                  <dt><label for="">'.it618_brand_getlang('s886').'</label></dt>
                  <dd><input type="text" maxlength="10" id="" name="price1" class="text-2" value=""><span>'.it618_brand_getlang('s887').'</span><input type="text" maxlength="10" id="" name="price2" class="text-2" value=""></dd>
                  <dd><input type="submit" name="submit" class="funbtn" value="'.it618_brand_getlang('s888').'"></dd>
              </dl>
          </form>            
      </div>'.gethomemode($ShopId,$modeid,$modetype,$modename,$homecount);
	 	$productflag=$modetype;
	}
	
	if($productflag!=$modetype){
		$homecontent.=gethomemode($ShopId,$modeid,$modetype,$modename,$homecount);
	}
	
}

function gethomemode($shopid,$modeid,$modetype,$modename,$homecount){
	global $_G,$it618_brand,$it618_brand_lang,$creditname,$firstmode;
	if($modetype=='product_all'||$modetype=='product_tj'){
		if($modetype=='product_all'){
			$sql='it618_ison=1 and it618_state=1';
		}else{
			$sql='it618_ison=1 and it618_state=1 and it618_istj=1';
		}
		$modecontent='<div class="moudle">
						  <div class="moudle-head">
							<h3>'.$modename.'</h3>
						  </div>
						   <div class="goods-list">
								<ul class="product-list biglist">';
		
		$i=1;
		foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_shopid(
				$shopid,$sql,'it618_order desc','',0,0,0,0,$homecount
		) as $it618_brand_goods) {
			$tmpurl=it618_brand_getrewrite('shop_product',$shopid.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$shopid.'&pid='.$it618_brand_goods['id']);
			$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
			
			$jfblstr='';
			if($it618_brand_goods['it618_saletype']==6){
				$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
				$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
				$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
			}
			
			$jfbl='';
			if($jfblstr!=''){
				$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
			}
			
			if($i%4!=0){$noml=' noml';}else{$noml='';}
		
			$it618_count=$it618_brand_lang['s1652'].' <font color="#FF6600">'.$it618_brand_goods['it618_count'].'</font>';
			
			if($it618_brand_goods['it618_isalipay']==1){
				$pricestr='<div class="now-price"><em>'.$it618_brand_goods['it618_uprice'].' '.it618_brand_getlang('s389').'</em></div>
						  <div class="market-price"><del>'.$it618_brand_goods['it618_price'].' '.it618_brand_getlang('s389').'</del></div>';
			}else{
				$pricestr='<div class="now-price1"><em>'.$it618_brand_goods['it618_score'].' '.$creditname.'</em></div>';
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
				$jfblstr='<font color=#339900>'.$it618_brand_goods['it618_score'].$creditname.'</font> '.$jfblstr;
			}
			
			$salecount='<span style="float:right;">'.it618_brand_getlang('s1298').''.$salecount.'</span>';
			
			if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
				$pricestr='<div class="now-price1"><em>'.$it618_brand_lang['s761'].'</em></div>';
				$jfblstr=$it618_brand_lang['s1732'].'<br>';
				$salecount='<span style="float:right;">'.it618_brand_getlang('t474').' <font color=#FF7575>'.$it618_brand_goods['it618_views'].'</font></span>';
			}
			
			$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
			$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
			$pjhaobl=intval($pjhaocount/$pjallcount*100);
			$pj=$it618_brand_lang['s1899'];
			if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';
			
			$modecontent.='<li class="product '.$noml.'">'.$jfbl.'
						  <h3>'.$it618_brand_goods['it618_name'].'</h3>
						  <div class="info"">
						  <div class="pic">
						  <a href="'.$tmpurl.'" target="_blank"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" /></a>
						  </div>
						  <div class="name"><a href="'.$tmpurl.'" target="_blank" class="a1" title="'.$it618_brand_goods['it618_name'].'">'.cutstr($it618_brand_goods['it618_name'],26,'...').'</a><br><font color="#999" title="'.$it618_brand_goods['it618_seodescription'].'">'.$it618_brand_goods['it618_seodescription'].'</font></div>
						  <div class="jifena">'.$salecount.$pj.'</div>
						  <div class="price">
						  '.$pricestr.'
						  </div>
						  </div>
						  </li>';
			$i=$i+1;
		}
		
		$tmpurl=it618_brand_getrewrite('shop_productlist',$shopid,'plugin.php?id=it618_brand:product_list&sid='.$shopid);
		$modecontent.='</ul>
					</div>
					<div class="goods-check-all" style="margin-top:-10px"><a href="'.$tmpurl.'" target="_blank">'.it618_brand_getlang('s889').'&gt;&gt;</a></div>
			   </div>';

	}elseif($modetype=='article'){
		if($firstmode==0){$firstmodecss='firstmode';$firstmode=1;}
		$modecontent='<div class="moudle '.$firstmodecss.'">
					<div class="moudle-head"><h3>'.$modename.'</h3></div>
			<div id="newslist">';
		
		$n=1;
		foreach(C::t('#it618_brand#it618_brand_article')->fetch_all_by_shopid(
				$shopid,'',$modeid,0,$homecount
		) as $it618_brand_article) {
			$it618_message=strip_tags($it618_brand_article['it618_message']);
			$it618_message=str_replace(" ","",$it618_message);
			$it618_message=str_replace("&nbsp;","",$it618_message);
			$it618_message=str_replace("<br>","",$it618_message);
			$it618_message=str_replace("\n","",$it618_message);
			$it618_message=cutstr($it618_message,300,'...');
			
			$lycount = C::t('#it618_brand#it618_brand_article_ly')->count_by_it618_aid($it618_brand_article['id']);
			
			if($it618_brand_article['it618_color']!=''){
				$it618_name='<font color='.$it618_brand_article['it618_color'].'>'.$it618_brand_article['it618_name'].'</font>';
			}else{
				$it618_name=$it618_brand_article['it618_name'];
			}
			
			$tmpurl=it618_brand_getrewrite('shop_article',$shopid.'@'.$it618_brand_article['id'],'plugin.php?id=it618_brand:article&sid='.$shopid.'&aid='.$it618_brand_article['id']);
			$modecontent.='<div class="news_contain">
							<table class="table_GB" cellpadding="0" cellspacing="0"><tr><td class="td_gb1" valign="top"><b>'.$n.'.</b></td><td class="td_gb2"><h3><a href="'.$tmpurl.'" target="_blank" class="a1" title="'.it618_brand_getlang('s396').'">'.$it618_name.'</a></h3><div>'.$it618_message.' &nbsp; <i>'.it618_brand_gettime($it618_brand_article['it618_time']).'&nbsp;&nbsp;'.$lycount.it618_brand_getlang('s397').'</i></div></td></tr></table>
			</div>';
			
			$n=$n+1;
		}
		
		$tmpurl=it618_brand_getrewrite('shop_articlelist',$shopid.'@'.$it618_brand_article['it618_class_id'].'@1','plugin.php?id=it618_brand:article_list&sid='.$shopid.'&cid='.$it618_brand_article['it618_class_id']);
		$modecontent.='<div class="goods-check-all"><a href="'.$tmpurl.'" target="_blank">'.it618_brand_getlang('s890').'&gt;&gt;</a></div></div></div>';

	}elseif($modetype=='thread_new'||$modetype=='thread_hot'){
		
		if($firstmode==0){$firstmodecss='firstmode';$firstmode=1;}
		$modecontent='<div class="moudle '.$firstmodecss.'">
					<div class="moudle-head"><h3>'.$modename.'</h3></div>
			<div id="newslist">';
		$n=1;
		
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($shopid);
		foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_thread_by_uid($it618_brand_brand['it618_uid'],$modetype) as $result) {
			if(!in_array($result['tid'],$tmptid)){
				$it618_message=DB::result_first("select message from ".DB::table('forum_post')." where first=1 and tid=".$result['tid']);
				$it618_message=strip_tags(it618_brand_ubbtotext($it618_message));
				$it618_message=str_replace(" ","",$it618_message);
				$it618_message=str_replace("&nbsp;","",$it618_message);
				$it618_message=str_replace("<br>","",$it618_message);
				$it618_message=str_replace("\n","",$it618_message);
				$it618_message=cutstr($it618_message,300,'...');
				
				$lycount = $result['replies'];
				
				$modecontent.='<div class="news_contain">
								<table class="table_GB" cellpadding="0" cellspacing="0"><tr><td class="td_gb1" valign="top"><b>'.$n.'.</b></td><td class="td_gb2"><h3><a href="forum.php?mod=viewthread&tid='.$result['tid'].'" target="_blank" class="a1" title="'.it618_brand_getlang('s396').'">'.$result['subject'].'</a></h3><div>'.$it618_message.' &nbsp; <i>'.it618_brand_gettime($result['dateline']).'&nbsp;&nbsp;'.$lycount.it618_brand_getlang('s397').'</i></div></td></tr></table>
				</div>';
				
				$n=$n+1;
				$tmptid[]=$result['tid'];
			}
			if($n>$homecount)break;
		}
		
		$modecontent=it618_brand_rewriteurl_thread($modecontent);
		
		$modecontent.='</div></div>';

	}elseif($modetype=='image'){
		if($firstmode==0){$firstmodecss='firstmode';$firstmode=1;}
		$modecontent='<div class="moudle '.$firstmodecss.'">
					<div class="moudle-head"><h3>'.$modename.'</h3></div>
			  <div id="images">
				  <div class="list-content grid">
					  <ul class="image-list">';
		
		$i=1;
		foreach(C::t('#it618_brand#it618_brand_image')->fetch_all_by_shopid(
				$shopid,'',$modeid,0,$homecount
		) as $it618_brand_image) {
			if($i%4!=0){$noml=' noml';}else{$noml='';}

			$tmpurl=it618_brand_getrewrite('shop_image',$shopid.'@'.$it618_brand_image['id'],'plugin.php?id=it618_brand:image&sid='.$shopid.'&iid='.$it618_brand_image['id']);
			$modecontent.='<li class="image '.$noml.'">
							<h3>'.$it618_brand_image['it618_name'].'</h3>
							<div class="info"">
							<div class="pic">
							<div class="pic_subwrap"><div class="pic_content"><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_brand_image['it618_smallurl'].'" /></a></div></div>
							<div class="name"><a href="'.$tmpurl.'" target="_blank" class="a1">'.$it618_brand_image['it618_name'].'</a></div>
							</div>
							
							</li>';
			$i=$i+1;
		}
		
		$tmpurl=it618_brand_getrewrite('shop_imagelist',$shopid.'@'.$it618_brand_image['it618_class_id'].'@1','plugin.php?id=it618_brand:image_list&sid='.$shopid.'&cid='.$it618_brand_image['it618_class_id']);
		$modecontent.='</ul>
					</div>
				</div>
				
				<div class="goods-check-all"><a href="'.$tmpurl.'" target="_blank">'.it618_brand_getlang('s891').'&gt;&gt;</a></div>
			</div>';

	}elseif($modetype=='onepage'){
		$it618_brand_onepage=C::t('#it618_brand#it618_brand_onepage')->fetch_by_id($modeid);
		
		$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="935" height="526" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_brand_onepage['it618_message']);

		$tmparr=explode("{page}",$it618_message);
		if(count($tmparr)>0){
			$it618_message=$tmparr[0];
			$tmpurl=it618_brand_getrewrite('shop_page',$shopid.'@'.$it618_brand_onepage['id'],'plugin.php?id=it618_brand:onepage&sid='.$shopid.'&oid='.$it618_brand_onepage['id']);
			$tmpstr='<div class="goods-check-all"><a href="'.$tmpurl.'" target="_blank">'.it618_brand_getlang('s396').'&gt;&gt;</a></div>';
		}
		if($firstmode==0){$firstmodecss='firstmode';$firstmode=1;}
		$modecontent='
						<div class="shop_onepage">
							'.$it618_message.'
						</div>
						
						'.$tmpstr;

	}elseif($modetype=='money'){
		$tmpurl=it618_brand_getrewrite('shop_money',$shopid,'plugin.php?id=it618_brand:moeny&sid='.$shopid);
		if($firstmode==0){$firstmodecss='firstmode';$firstmode=1;}
		$modecontent='<div class="moudle '.$firstmodecss.'">
					<div class="moudle-head"><h3>'.$modename.'</h3></div>
				<div id="xiaofei">
					<div id="latest_order_list">
					<table cellpadding="0" cellspacing="0">
						<tr>
						<th class="th-8">'.it618_brand_getlang('s402').'</th>
						<th class="th-3">'.it618_brand_getlang('s403').'</th>
						<th>'.it618_brand_getlang('s404').'</th>
						<th class="th-3">'.it618_brand_getlang('s405').'</th>
						<th class="th-3">'.it618_brand_getlang('s406').'</th>
						<th class="th-6">'.it618_brand_getlang('t231').'</th>
						<th class="th-3">'.it618_brand_getlang('s407').'</th>
						</tr>';
						
		foreach(C::t('#it618_brand#it618_brand_money')->fetch_all_by_shopid(
				$shopid,0,0,0,0,'','',0,$homecount
		) as $it618_brand_money) {
		
				$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
				if($ii1i11i[3]!='1')return;
			
				$username=it618_brand_getusername($it618_brand_money['it618_uid']);
				
				if($it618_brand_money['it618_type']!=1){
					
					if($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_money['it618_pid'])){
						$tmpurl=it618_brand_getrewrite('shop_product',$shopid.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$shopid.'&pid='.$it618_brand_goods['id']);
						$it618_bz='<a href="'.$tmpurl.'" target="_blank" class="a1" title="'.$it618_brand_goods['it618_name'].'">'.cutstr($it618_brand_goods['it618_name'],40,'...').'</a>';
					}else{
						$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($it618_brand_money['it618_saleid']);
						$it618_bz=cutstr($it618_brand_sale['it618_pname'],40,'...');
					}
		
					if($it618_brand_goods['it618_isbm']==1){
						$buyuser=cutstr($username, 2, '').'***';
					}else{
						$buyuser='<a href="'.it618_brand_rewriteurl($it618_brand_money['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1">'.$username.'('.$it618_brand_money['it618_uid'].')</a>';
					}
					
					if($it618_brand_money['it618_state']==1){
						$it618_state=it618_brand_getlang('s294');
					}else{
						$it618_state='<img src="source/plugin/it618_brand/images/ok.gif" align="absmiddle"> '.it618_brand_getlang('s295');
					}
					
					if($it618_brand_money['it618_type']==2){
						$it618_score='-'.$it618_brand_money['it618_score'];
						$it618_type=it618_brand_getlang('s592');
						$moneystr='/';
					}else{
						$it618_score='+'.$it618_brand_money['it618_score'];
						$it618_type=it618_brand_getlang('s593');
						$moneystr=$it618_brand_money['it618_money'];
					}
					
				}else{
					
					$buyuser='<a href="'.it618_brand_rewriteurl($it618_brand_money['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1">'.$username.'('.$it618_brand_money['it618_uid'].')</a>';
					
					$it618_bz=$it618_brand_money['it618_bz'];
					
					$it618_state='<img src="source/plugin/it618_brand/images/ok.gif" align="absmiddle">'.it618_brand_getlang('s410');
					
					$it618_score='+'.$it618_brand_money['it618_score'];
					
					$it618_type=it618_brand_getlang('s595');
					
					$moneystr=$it618_brand_money['it618_money'];
					
				}
				
				
			
		$modecontent.='<tr>
						<td class="td-8">'.$buyuser.'</td>
						<td class="td-2"><font color=#999>'.date('Y/m/d', $it618_brand_money['it618_time']).'</font></td>
						<td class="td-3">'.$it618_bz.'</td>
						<td class="td-4" align="center">'.$moneystr.'</td>
						<td class="td-5" align="center">'.$it618_score.'</td>
						<td class="td-6" align="center">'.$it618_type.'</td>
						<td class="td-6" align="center">'.$it618_state.'</td>
						</tr>';
		}

		$tmpurl=it618_brand_getrewrite('shop_money',$shopid,'plugin.php?id=it618_brand:money&sid='.$shopid);
		$modecontent.='</table>
					</div>
				</div>
				<div class="goods-check-all"><a href="'.$tmpurl.'" target="_blank">'.it618_brand_getlang('s892').'&gt;&gt;</a></div>
				</div>';
	}
		
	return $modecontent;
	
}

if($Shop_isimagemove==1){
	foreach(C::t('#it618_brand#it618_brand_image')->fetch_all_by_shopid_ishomemove($ShopId,$Shop_imagemovecount) as $it618_brand_image) {
		$tmpurl=it618_brand_getrewrite('shop_image',$ShopId.'@'.$it618_brand_image['id'],'plugin.php?id=it618_brand:image&sid='.$ShopId.'&iid='.$it618_brand_image['id']);
		$homemovestr.='<li><a href="'.$tmpurl.'" class="a1" target="_blank"><img alt="'.$it618_brand_image['it618_name'].'" src="'.$it618_brand_image['it618_smallurl'].'" width="140" height="100" border=0><br><span>'.$it618_brand_image['it618_name'].'</span></a></li>';
	}
}

foreach(C::t('#it618_brand#it618_brand_link')->fetch_all_by_shopid($ShopId) as $it618_brand_link) {
	if($it618_brand_link['it618_img']!=''){
		$str_link.='<li><a href="'.$it618_brand_link['it618_url'].'"  class="a1" target="_blank"><img src="'.$it618_brand_link['it618_img'].'"/></a></li>';
	}else{
		$str_link.='<li><a href="'.$it618_brand_link['it618_url'].'"  class="a1" target="_blank">'.$it618_brand_link['it618_name'].'</a></li>';
	}
}

$n=0;
foreach(C::t('#it618_brand#it618_brand_yuangong')->fetch_tj_by_shopid($ShopId) as $it618_brand_yuangong) {
	if($str_yuangong==''){
		$str_yuangong='<div style="text-align:center;padding:8px"><img src="'.$it618_brand_yuangong['it618_img'].'" width="160" height="160" style="border:1px solid #cccccc;padding:1px;" /><div style="padding-top:5px;color:#333">&nbsp;'.$it618_brand_yuangong['it618_name'].it618_brand_getlang('s562').$it618_brand_yuangong['it618_zhiwei'].'</div></div>';
		$curid=$it618_brand_yuangong['id'];
	}
	$ids[$n].=$it618_brand_yuangong['id'];
	$n=$n+1;
}

if($n==1){
	$pagepre="<img src='source/plugin/it618_brand/images/icon_pre1.gif'>";
	$pagenext="<img src='source/plugin/it618_brand/images/icon_next1.gif'>";
}else{
	for($i=0;$i<$n;$i++){
		if($ids[$i]==$curid){
			$preid=$i-1;
			$nextid=$i+1;
			
			if($preid<0){
				$pagepre="<img src='source/plugin/it618_brand/images/icon_pre1.gif'>";
			}else{
				$pagepre="<img src='source/plugin/it618_brand/images/icon_pre.gif' onclick='getyuangong(".$ids[$preid].")'>";
			}
			
			if($nextid>$n-1){
				$pagenext="<img src='source/plugin/it618_brand/images/icon_next1.gif'>";
			}else{
				$pagenext="<img src='source/plugin/it618_brand/images/icon_next.gif' onclick='getyuangong(".$ids[$nextid].")'>";
			}

			break;
		}
	}
}
if($str_yuangong!='')$str_yuangong="<ul>$str_yuangong<ul><div style='text-align:center;'>$pagepre&nbsp;&nbsp;$pagenext</div>";

$visitcount = C::t('#it618_brand#it618_brand_visitall')->count_by_shopid_it618_time($ShopId);
$it618_brand_show = C::t('#it618_brand#it618_brand_show')->fetch_by_shopid_showid_showtype($ShopId,0,'visit');
foreach(C::t('#it618_brand#it618_brand_visitall')->fetch_all_by_shopid(
		$ShopId,$it618_brand_show['it618_homecount']
) as $it618_brand_visitall) {

	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')return;

	$username=it618_brand_getusername($it618_brand_visitall['it618_uid']);
	
	$visitlist_get.='<li>
						<div class="a1"><a href="'.it618_brand_rewriteurl($it618_brand_visitall['it618_uid']).'" target="_blank"><img src="'.it618_brand_discuz_uc_avatar($it618_brand_visitall['it618_uid'],'small').'" alt="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" width="50" height="50" /></a></div>
						<ul>
							<li style="padding:5px 0"><a href="'.it618_brand_rewriteurl($it618_brand_visitall['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1">'.$username.'</a>'.it618_brand_getonlinestate($it618_brand_visitall['it618_uid']).'</li>
							<li style="padding-left:6px;"> '.it618_brand_gettime($it618_brand_visitall['it618_time']).it618_brand_getlang('s411').'</li>
						</ul>
					</li>';
}

if(isset($_GET['mr'])){
	$mrstr='scroller("mr'.$_GET['mr'].'",1000)';	
}


$tmparr=explode(":",$_GET['id']);
$pagetype=$tmparr[1];
$seotitle=$ShopName_nav;
$ShopName_nav='';
$seokeywords=$Shop_seokeywords;
$seodescription=$Shop_seodescription;
$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);
$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a>';

$idforly=0;$idfornav=0;
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_nav.func.php';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:shop_default');
?>