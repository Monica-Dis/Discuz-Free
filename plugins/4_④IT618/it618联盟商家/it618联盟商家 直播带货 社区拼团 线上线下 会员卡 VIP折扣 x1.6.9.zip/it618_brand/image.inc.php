<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

$iid=intval($_GET['iid']);
if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','image@'.$ShopId.'@'.$iid.'@0@0','plugin.php?id=it618_brand:wap&pagetype=image&sid='.$ShopId.'&oid='.$iid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if(!($it618_brand_image = C::t('#it618_brand#it618_brand_image')->fetch_by_id($iid))){
	echo it618_brand_getlang('s542');exit;
}

if($ShopId!=C::t('#it618_brand#it618_brand_image')->fetch_it618_shopid_by_id($iid)){
	echo it618_brand_getlang('s542');exit;
}

$n=0;
foreach(C::t('#it618_brand#it618_brand_image')->fetch_all_by_it618_class_id($it618_brand_image['it618_class_id']) as $it618_brand_image_ids) {
	$ids[$n].=$it618_brand_image_ids['id'];
	$n=$n+1;
}

if($n==1){
	$pagepre='<font color="#666666">'.it618_brand_getlang('s543').'</font>';
	$pagenext='<font color="#666666">'.it618_brand_getlang('s544').'</font>';
	$imagenext='<img src="'.$it618_brand_image['it618_url'].'" alt="'.$it618_brand_image['it618_name'].'" />';
}else{
	for($i=0;$i<$n;$i++){
		if($ids[$i]==$iid){
			$preid=$i-1;
			$nextid=$i+1;
			
			if($preid<0){
				$pagepre='<font color="#666666">'.it618_brand_getlang('s543').'</font>';
			}else{
				$tmpurl=it618_brand_getrewrite('shop_image',$ShopId.'@'.$ids[$preid],'plugin.php?id=it618_brand:image&sid='.$ShopId.'&iid='.$ids[$preid]);
				$pagepre='<a href="'.$tmpurl.'" class="nextImage">'.it618_brand_getlang('s543').'</a>';
			}
			
			if($nextid>$n-1){
				$pagenext='<font color="#666666">'.it618_brand_getlang('s544').'</font>';
				$imagenext='<img src="'.$it618_brand_image['it618_url'].'" alt="'.$it618_brand_image['it618_name'].'" />';
			}else{
				$tmpurl=it618_brand_getrewrite('shop_image',$ShopId.'@'.$ids[$nextid],'plugin.php?id=it618_brand:image&sid='.$ShopId.'&iid='.$ids[$nextid]);
				$pagenext='<a href="'.$tmpurl.'" class="nextImage">'.it618_brand_getlang('s544').'</a>';
				$imagenext='<a href="'.$tmpurl.'"><img src="'.$it618_brand_image['it618_url'].'" alt="'.$it618_brand_image['it618_name'].'" /></a>';
			}

			break;
		}
	}
}



$it618_time=date('Y-m-d H:i:s', $it618_brand_image['it618_time']);
C::t('#it618_brand#it618_brand_image')->update_it618_views_by_id($iid);

$tmparr=explode(":",$_GET['id']);
$pagetype=$tmparr[1];
$seotitle=$it618_brand_image['it618_name'];
$seokeywords=$Shop_seokeywords;
$seodescription=$Shop_seodescription;
$tmpurl=it618_brand_getrewrite('shop_imagelist',$ShopId.'@'.$it618_brand_image['it618_class_id'].'@1','plugin.php?id=it618_brand:image_list&sid='.$ShopId.'&cid='.$it618_brand_image['it618_class_id']);
$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo; <a href="'.$tmpurl.'" class="a1">'.C::t('#it618_brand#it618_brand_image_class')->fetch_it618_classname_by_id($it618_brand_image['it618_class_id']).'</a> &raquo; '.$it618_brand_image['it618_name'];

$idforly=$iid;$idfornav=$it618_brand_image['it618_class_id'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_nav.func.php';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:shop_default');
?>