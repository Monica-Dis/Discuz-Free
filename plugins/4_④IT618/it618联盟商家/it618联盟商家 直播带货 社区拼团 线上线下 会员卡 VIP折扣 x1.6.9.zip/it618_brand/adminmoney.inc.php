<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

echo '<script type="text/javascript" src="source/plugin/it618_brand/js/jquery.js"></script>
';

showtableheaders(it618_brand_getlang('s443').'<span style="float:right;font-weight:normal;">'.it618_brand_getlang('s207').'</span>','it618_brand_money');
	
	echo '<tr><td colspan=4>'.it618_brand_getlang('s217').'<input id="it618_uid" class="txt" style="margin-left:10px;width:340px;height:20px;color:green;font-weight:bold;line-height:20px;font-size:20px;" onKeypress="return (/,|\d/.test(String.fromCharCode(event.keyCode)))"/> '.it618_brand_getlang('s444').'<input id="it618_money" class="txt" style="width:100px;height:20px;color:green;font-weight:bold;line-height:20px;font-size:20px;" onKeypress="return (/\d/.test(String.fromCharCode(event.keyCode)))"/> '.it618_brand_getlang('s209').'<input id="it618_score" class="txt" style="width:100px;height:20px;color:green;font-weight:bold;line-height:20px;font-size:20px;" onKeypress="return (/\d/.test(String.fromCharCode(event.keyCode)))"/><input type="button" class="btn" onclick="savemonneyadd()" style="width:60px;height:25px" value="'.it618_brand_getlang('s210').'" /> '.it618_brand_getlang('s211').$creditname.''.it618_brand_getlang('s53').'<span id="creditnum" style="color:red"></span>
	<br> '.it618_brand_getlang('s445').'<input id="it618_bz" class="txt" style="width:700px;height:20px;color:green;font-weight:bold;line-height:20px;font-size:13px;" value="/" /><div id="moneytip" style="color:red;margin-top:5px"></div></td></tr>';
	
	
showtablefooter(); /*dism��taobao��com*/

showtableheaders(it618_brand_getlang('s213'),'it618_brand_money_sum');
showtablefooter(); /*dism��taobao��com*/
echo '
<script>

var url="'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax&sid=0&page=1";
function getmonneyaddlist(url){
	IT618_BRAND.get(url+"&formhash='.FORMHASH.'", {ac:"money_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_BRAND(".it618_brand_money_sum").html(tmparr[1]);
	IT618_BRAND("#creditnum").html(tmparr[0]);
	}, "html");	
}
getmonneyaddlist(url);

function findmoney(){
	var it618_uid_find=document.getElementById("it618_uid_find").value;
	var it618_time1=document.getElementById("it618_time1").value;
	var it618_time2=document.getElementById("it618_time2").value;
	getmonneyaddlist("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax&sid=0&it618_uid_find="+it618_uid_find+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2+"&page=1");
}

function savemonneyadd(){
	var it618_uid=document.getElementById("it618_uid").value;
	var it618_bz=document.getElementById("it618_bz").value;
	var it618_money=document.getElementById("it618_money").value;
	var it618_score=document.getElementById("it618_score").value;
	
	if(it618_uid==""){
		sendmsg(\'moneytip\',"'.it618_brand_getlang('s214').'");
		return false;
	}
	if(it618_money==""){
		sendmsg(\'moneytip\',"'.it618_brand_getlang('s446').'");
		return false;
	}
	if(it618_score==""){
		sendmsg(\'moneytip\',"'.it618_brand_getlang('s216').'");
		return false;
	}
	
	it618_bz=it618_bz.replace(/#/g,"it618_str1");
	it618_bz=it618_bz.replace(/&/g,"it618_str2");
	
	IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax&sid=0&it618_uid="+it618_uid+"&it618_bz="+it618_bz+"&it618_money="+it618_money+"&it618_score="+it618_score+"&formhash='.FORMHASH.'", {ac:"money_add"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	sendmsg(\'moneytip\',tmparr[1]);
	if(tmparr[0]=="ok"){
		getmonneyaddlist(url);
	}
	}, "html");	
}


function sendmsg(msgid,msgvalue){
	document.getElementById(msgid).innerHTML=msgvalue;
	setTimeout(\'sendmsg1("\'+msgid+\'")\',8000);
}
function sendmsg1(msgid){
	document.getElementById(msgid).innerHTML="";
}

</script>
';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>