<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if($Shop_isgoods==0){
	it618_cpmsg($it618_brand_lang['s1640'], '', 'error');
}

$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';$state7='';$state8='';$state9='';$state10='';
if($_GET['state']==0){$it618sql = "1";$state0='selected="selected"';}
if($_GET['state']==1){$it618sql = "it618_isbm = 1";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql = "it618_isbm = 0";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql = "it618_ison = 1";$state3='selected="selected"';}
if($_GET['state']==4){$it618sql = "it618_ison = 0";$state4='selected="selected"';}
if($_GET['state']==5){$it618sql = "it618_istj = 1";$state5='selected="selected"';}
if($_GET['state']==6){$it618sql = "it618_istj = 0";$state6='selected="selected"';}
if($_GET['state']==7){$it618sql = "it618_issaledisplay = 1";$state7='selected="selected"';}
if($_GET['state']==8){$it618sql = "it618_issaledisplay = 0";$state8='selected="selected"';}
if($_GET['state']==9){$it618sql = "it618_isorderbuy = 1";$state9='selected="selected"';}
if($_GET['state']==10){$it618sql = "it618_isorderbuy = 0";$state10='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';$orderby4='';
if($_GET['orderby']==0){$it618orderby = "it618_order desc,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "it618_count desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "it618_salecount desc";$orderby2='selected="selected"';}
if($_GET['orderby']==3){$it618orderby = "it618_views desc";$orderby3='selected="selected"';}
if($_GET['orderby']==4){$it618orderby = "it618_score desc";$orderby4='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&it618_class_id='.$_GET['it618_class_id'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount=0;
		if($Shop_isgoodssafe==1)$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($delid);
		
		if($salecount<=0){
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($delid);
			
			$tmpurl=$_G['siteurl'].it618_brand_getrewrite('shop_product',$ShopId.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.$it618_brand_goods['id']);
			$qrcodeurl=md5($tmpurl);
			$qrcodeurl='source/plugin/it618_brand/qrcode/'.$qrcodeurl.'.png';
			$tmparr=explode("source",$qrcodeurl);
			$qrcodeurl=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($qrcodeurl)){
				$result=unlink($qrcodeurl);
			}
			
			$tmparr=explode("source",$it618_brand_goods['it618_picbig']);
			$tmparr1=explode("://",$it618_brand_goods['it618_picbig']);
			$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_picbig)&&count($tmparr1)==1){
				$result=unlink($it618_picbig);
			}
			
			for($i=0;$i<=4;$i++){
				if($i==0)$tmpi='';else $tmpi=$i;
				$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
				
				if($it618_brand_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
					$tmparr=explode("source",$it618_brand_goods['it618_picbig'.$tmpi]);
					$tmparr1=explode("://",$it618_brand_goods['it618_picbig'.$tmpi]);
					$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_picbig)&&count($tmparr1)==1){
						$result=unlink($it618_picbig);
					}
				}
				
				$file_ext=strtolower(substr($it618_brand_goods['it618_picbig'.$tmpi],strrpos($it618_brand_goods['it618_picbig'.$tmpi], '.')+1)); 
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
				if(file_exists($it618_smallurl)){
					$result=unlink($it618_smallurl);
				}
			}
			
			C::t('#it618_brand#it618_brand_goods_type_km')->delete_by_pid($delid);
			C::t('#it618_brand#it618_brand_goods_km')->delete_by_pid($delid);
			C::t('#it618_brand#it618_brand_goods_type')->delete_by_pid($delid);
			C::t('#it618_brand#it618_brand_goods')->delete_by_id($delid);
			$del=$del+1;
		}
	}

	it618_cpmsg(it618_brand_getlang('s7').$del, "plugin.php?id=it618_brand:sc_product$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			if($_GET['it618_score'][$id]>$ShopSCORE){
				$it618_score=$_GET['it618_score'][$id];
			}else{
				$it618_score=$ShopSCORE;
			}
			
			if($_GET['it618_uprice'][$id]>$ShopUPRICE){
				$it618_uprice=$_GET['it618_uprice'][$id];
			}else{
				$it618_uprice=$ShopUPRICE;
			}
			
			if($_GET['it618_jfbl'][$id]>$ShopJfBl){
				$it618_jfbl=$_GET['it618_jfbl'][$id];
			}else{
				$it618_jfbl=$ShopJfBl;
			}
			
			if($_GET['it618_saletype'][$id]==6){
				$it618_isduihuan=0;
			}else{
				$it618_isduihuan=$_GET['it618_isduihuan'][$id];
			}
		
			C::t('#it618_brand#it618_brand_goods')->update($id,array(
				'it618_saletype' => $_GET['it618_saletype'][$id],
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription'][$id]),
				'it618_score' => $it618_score,
				'it618_uprice' => $it618_uprice,
				'it618_price' => $_GET['it618_price'][$id],
				'it618_prepaybl' => $_GET['it618_prepaybl'][$id],
				'it618_count' => intval($_GET['it618_count'][$id]),
				'it618_punit' => dhtmlspecialchars($_GET['it618_punit'][$id]),
				'it618_xiangoutime' => intval($_GET['it618_xiangoutime'][$id]),
				'it618_xiangoucount' => intval($_GET['it618_xiangoucount'][$id]),
				'it618_ison' => $_GET['it618_ison'][$id],
				'it618_isorderbuy' => $_GET['it618_isorderbuy'][$id],
				'it618_istelsale' => $_GET['it618_istelsale'][$id],
				'it618_isbm' => $_GET['it618_isbm'][$id],
				'it618_issaledisplay' => $_GET['it618_issaledisplay'][$id],
				'it618_istj' => $_GET['it618_istj'][$id],
				'it618_isaddr' => $_GET['it618_isaddr'][$id],
				'it618_isduihuan' => $it618_isduihuan,
				'it618_isalipay' => $_GET['it618_isalipay'][$id],
				'it618_isyunfeifree' => $_GET['it618_isyunfeifree'][$id],
				'it618_kgbl' => $_GET['it618_kgbl'][$id],
				'it618_jfbl' => $it618_jfbl,
				'it618_xgtime1' => $_GET['it618_xgtime1'][$id],
				'it618_xgtime2' => $_GET['it618_xgtime2'][$id],
				'it618_xgtype' => $_GET['it618_xgtype'][$id],
				'it618_order' => intval($_GET['it618_order'][$id])
			));
	
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_brand_getlang('s5').$ok, "plugin.php?id=it618_brand:sc_product$adminsid&page=$page".$urlsql, 'succeed');
}

foreach(C::t('#it618_brand#it618_brand_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class_id'].'>','<option value='.$_GET['it618_class_id'].' selected="selected">',$tmp);

it618_showformheader("plugin.php?id=it618_brand:sc_product$adminsid".$urlsql);
showtableheaders(it618_brand_getlang('s230'),'it618_brand_sum');
	echo '<tr><td colspan=14>'.it618_brand_getlang('s231').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_brand_getlang('s232').' <select name="it618_class_id"><option value="0">'.it618_brand_getlang('s233').'</option>'.$tmp1.'</select> '.it618_brand_getlang('s234').' <select name="state"><option value=0 '.$state0.'>'.it618_brand_getlang('s235').'</option><option value=1 '.$state1.'>'.it618_brand_getlang('s236').'</option><option value=2 '.$state2.'>'.it618_brand_getlang('s237').'</option><option value=3 '.$state3.'>'.it618_brand_getlang('s240').'</option><option value=4 '.$state4.'>'.it618_brand_getlang('s241').'</option><option value=5 '.$state5.'>'.it618_brand_getlang('s242').'</option><option value=6 '.$state6.'>'.it618_brand_getlang('s243').'</option><option value=7 '.$state7.'>'.it618_brand_getlang('s1870').'</option><option value=8 '.$state8.'>'.it618_brand_getlang('s1872').'</option><option value=9 '.$state9.'>'.it618_brand_getlang('s1873').'</option><option value=10 '.$state10.'>'.it618_brand_getlang('s1874').'</option></select> '.it618_brand_getlang('s182').' <select name="orderby"><option value=0 '.$orderby0.'>'.it618_brand_getlang('s245').'</option><option value=1 '.$orderby1.'>'.it618_brand_getlang('s246').'</option><option value=2 '.$orderby2.'>'.it618_brand_getlang('s247').'</option><option value=3 '.$orderby3.'>'.it618_brand_getlang('s248').'</option><option value=4 '.$orderby4.'>'.it618_brand_getlang('s249').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_brand_getlang('s34').'" /></td></tr>';
	
	$count = C::t('#it618_brand#it618_brand_goods')->count_by_shopid($ShopId,$it618sql,'',$_GET['key'],$_GET['it618_class_id'],0,0);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_brand:sc_product$adminsid".$urlsql);
	
	if($Shop_ispaytype2==1)$tmppricetitle.=$it618_brand_lang['s1650'];
	if($Shop_ispaytype1==1){
		if($tmppricetitle!='')$tmppricetitle.='/<font color=blue>'.$it618_brand_lang['s1651'].'</font>';else $tmppricetitle.='<font color=blue>'.$it618_brand_lang['s1651'].'</font>';
	}
	if($Shop_issaletype1==1||$Shop_issaletype2==1){
		if($tmppricetitle!='')$tmppricetitle.='/<font color=green>'.$it618_brand_lang['s1652'].'</font>';else $tmppricetitle.='<font color=green>'.$it618_brand_lang['s1652'].'</font>';
	}
	$tmppricetitle.='/'.$it618_brand_lang['s1653'];
	
	echo '<tr><td colspan=15>'.it618_brand_getlang('s250').$count.'<span style="float:right;">'.it618_brand_getlang('s1093').'</span></td></tr>';
	showsubtitle(array('',it618_brand_getlang('s259'),$tmppricetitle,it618_brand_getlang('s1094').'/'.it618_brand_getlang('s1095'),it618_brand_getlang('s1358')));
	
	$n=1;
	foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_shopid(
		$ShopId,$it618sql,$it618orderby,$_GET['key'],$_GET['it618_class_id'],0,0,$startlimit,$ppp
	) as $it618_brand_goods) {
		
		if($it618_brand_goods['it618_ison']==1){
			$it618_ison_checked='checked="checked"';
			$isoncss='color:green';
		}else{
			$it618_ison_checked="";
			$isoncss='color:red';
		}
		if($it618_brand_goods['it618_istj']==1)$it618_istj_checked='checked="checked"';else $it618_istj_checked="";
		if($it618_brand_goods['it618_isorderbuy']==1)$it618_isorderbuy_checked='checked="checked"';else $it618_isorderbuy_checked="";
		if($it618_brand_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		if($it618_brand_goods['it618_issaledisplay']==1)$it618_issaledisplay_checked='checked="checked"';else $it618_issaledisplay_checked="";
		if($it618_brand_goods['it618_istelsale']==1)$it618_istelsale_checked='checked="checked"';else $it618_istelsale_checked="";
		if($it618_brand_goods['it618_isduihuan']==1)$it618_isduihuan_checked='checked="checked"';else $it618_isduihuan_checked="";
		if($it618_brand_goods['it618_isalipay']==1)$it618_isalipay_checked='checked="checked"';else $it618_isalipay_checked="";
		
		if($it618_brand_goods['it618_saletype']==1)$it618_saletype1=' selected="selected"';else $it618_saletype1="";
		if($it618_brand_goods['it618_saletype']==2)$it618_saletype2=' selected="selected"';else $it618_saletype2="";
		if($it618_brand_goods['it618_saletype']==3)$it618_saletype3=' selected="selected"';else $it618_saletype3="";
		if($it618_brand_goods['it618_saletype']==4)$it618_saletype4=' selected="selected"';else $it618_saletype4="";
		if($it618_brand_goods['it618_saletype']==5)$it618_saletype5=' selected="selected"';else $it618_saletype5="";
		if($it618_brand_goods['it618_saletype']==6)$it618_saletype6=' selected="selected"';else $it618_saletype6="";
		
		if($it618_brand_goods['it618_xgtype']==0)$it618_xgtype0=' selected="selected"';else $it618_xgtype0="";
		if($it618_brand_goods['it618_xgtype']==1)$it618_xgtype1=' selected="selected"';else $it618_xgtype1="";
		if($it618_brand_goods['it618_xgtype']==2)$it618_xgtype2=' selected="selected"';else $it618_xgtype2="";
		
		if($it618_brand_goods['it618_isyunfeifree']==0)$it618_isyunfeifree0=' selected="selected"';else $it618_isyunfeifree0="";
		if($it618_brand_goods['it618_isyunfeifree']==1)$it618_isyunfeifree1=' selected="selected"';else $it618_isyunfeifree1="";
		if($it618_brand_goods['it618_isyunfeifree']==2)$it618_isyunfeifree2=' selected="selected"';else $it618_isyunfeifree2="";
		
		if($it618_brand_goods['it618_state']==0)$it618_state='<font color=red>'.$it618_brand_lang['s1596'].'</font>';
		if($it618_brand_goods['it618_state']==1)$it618_state='<font color=green>'.$it618_brand_lang['s1597'].'</font>';
		if($it618_brand_goods['it618_state']==2)$it618_state='<font color=blue>'.$it618_brand_lang['s1598'].'</font>';
		
		$typecountall = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type')." WHERE it618_pid=".$it618_brand_goods['id']);
		$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_brand_goods['id']);
		
		$ptypecss='';
		if($typecountok>0)$ptypecss='readonly="readonly"';
		
		$preurl="plugin.php?id=it618_brand:sc_product$adminsid".$urlsql."&page=$page";
		$preurl=str_replace("&","@",$preurl);
		
		$pricestr='';
		if($Shop_ispaytype2==1){
			$pricestr.='<span id="pricespan'.$it618_brand_goods[id].'"><input type="text" class="txt" style="width:60px;margin-right:0;margin-bottom:3px;color:red" name="it618_uprice['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_uprice].'" '.$ptypecss.'> '.$it618_brand_lang['s389'].'/<input type="text" class="txt" style="width:60px;margin-right:0;margin-bottom:3px" name="it618_price['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_price].'" '.$ptypecss.'> '.$it618_brand_lang['s389'].'/</span>';
		}else{
			$pricestr.='<span id="pricespan'.$it618_brand_goods[id].'"></span>';
		}

		if($Shop_ispaytype1==1)$pricestr.='<span id="scorespan'.$it618_brand_goods[id].'"><input type="text" class="txt" style="width:40px;margin-right:0;margin-bottom:3px;color:blue" name="it618_score['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_score].'" '.$ptypecss.'> '.$creditname.'</span>';else $pricestr.='<span id="scorespan'.$it618_brand_goods[id].'"></span>';

		$pricestr.='<span id="countspan'.$it618_brand_goods[id].'"> '.$it618_brand_lang['s870'].':<input type="text" class="txt" style="width:40px;margin-right:0;margin-bottom:3px;color:green" name="it618_count['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_count].'" '.$ptypecss.'></span>';
		
		
		$xgcountstr=it618_brand_getlang('s1097').'<input type="text" class="txt" style="margin-right:0;width:35px" name="it618_xiangoutime['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_xiangoutime].'">'.it618_brand_getlang('s1015').'<input type="text" class="txt" style="margin-right:0;width:35px" name="it618_xiangoucount['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_xiangoucount].'">'.it618_brand_getlang('s1105');
		
		
		if($it618_brand_goods[it618_punit]=='')$it618_punit=it618_brand_getlang('s1105');else $it618_punit=$it618_brand_goods[it618_punit];
		
		$saletypestr='';
		if($Shop_issaletype1==1)$saletypestr.='<option value="1"'.$it618_saletype1.'>'.it618_brand_getlang('s1002').'</option>';
		if($Shop_issaletype2==1)$saletypestr.='<option value="2"'.$it618_saletype2.'>'.it618_brand_getlang('s1003').'</option>';
		if($Shop_issaletype1==1&&$Shop_issaletype2==1)$saletypestr.='<option value="4"'.$it618_saletype4.'>'.it618_brand_getlang('s1224').'</option>';
		if($Shop_issaletype3==1)$saletypestr.='<option value="3"'.$it618_saletype3.'>'.it618_brand_getlang('s1223').'</option>';
		if($Shop_issaletype4==1)$saletypestr.='<option value="6"'.$it618_saletype6.'>'.it618_brand_getlang('s855').'</option>';
		if($Shop_issaletype5==1)$saletypestr.='<option value="5"'.$it618_saletype5.'>'.it618_brand_getlang('s1654').'</option>';
		
		if($saletypestr!=''){
			$saletypestr='<select name="it618_saletype['.$it618_brand_goods[id].']" style="margin-bottom:3px" onchange="setsaletype(this.value,'.$it618_brand_goods[id].')">'.$saletypestr.'</select>';
		}else{
			$saletypestr=$it618_brand_lang['s1891'];
			
		}
		
		if($Shop_issaletype2==1){
			if($Shop_isyunfeikg==1){
				$isyunfeikgcss='';
			}else{
				$isyunfeikgcss='display:none';
			}
			
			$saletypestr.='<span id="yunfeispan'.$it618_brand_goods[id].'"><select id="it618_isyunfeifree'.$n.'" style="margin-bottom:3px" name="it618_isyunfeifree['.$it618_brand_goods[id].']" onchange="setyunfei(this.value,'.$it618_brand_goods[id].')"><option value="0"'.$it618_isyunfeifree0.'>'.it618_brand_getlang('s1498').'</option><option value="1"'.$it618_isyunfeifree1.'>'.it618_brand_getlang('s1499').'</option><option value="2"'.$it618_isyunfeifree2.'>'.it618_brand_getlang('s1500').'</option></select><span id="kgblspan'.$it618_brand_goods[id].'"><span style="'.$isyunfeikgcss.'"><br>1'.$it618_punit.'=<input type="text" class="txt" style="width:40px;margin-right:1px;color:red" name="it618_kgbl['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_kgbl].'">'.$it618_brand_lang['s1726'].'</span></span></span>';
		}else{
			$saletypestr.='<span id="yunfeispan'.$it618_brand_goods[id].'"></span>';
		}
		
		if($Shop_issaletype3==1){
			if($typecountall>0){
				$saletypestr.='<span id="kmspan'.$it618_brand_goods[id].'"></span>';
			}else{
				$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_km')." WHERE it618_pid=".$it618_brand_goods['id']);
				$saletypestr.='<span id="kmspan'.$it618_brand_goods[id].'"><a href="plugin.php?id=it618_brand:sc_product_km'.$adminsid.'&pid='.$it618_brand_goods[id].'&preurl='.$preurl.'">'.it618_brand_getlang('s1225').'(<font color=red>'.$kmcount.'</font>)</a></span>';
			}
		}else{
			$saletypestr.='<span id="kmspan'.$it618_brand_goods[id].'"></span>';
		}
		
		if($Shop_issaletype4==1){
			$saletypestr.='<span id="prepayspan'.$it618_brand_goods[id].'"> '.it618_brand_getlang('s856').'<input type="text" class="txt" style="width:40px;margin-right:1px;color:red" name="it618_prepaybl['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_prepaybl].'">%</span>';
		}else{
			$saletypestr.='<span id="prepayspan'.$it618_brand_goods[id].'"></span>';
		}
		
		if($Shop_issaletype5==1){
			$saletypestr.='<span id="contentspan'.$it618_brand_goods[id].'"><a href="plugin.php?id=it618_brand:sc_product_content'.$adminsid.'&pid='.$it618_brand_goods[id].'&preurl='.$preurl.'">'.it618_brand_getlang('s1890').'(<font color=red>'.strlen($it618_brand_goods['it618_message_buy']).'</font>)</a></span>';
		}else{
			$saletypestr.='<span id="contentspan'.$it618_brand_goods[id].'"></span>';
		}
		
		$paytypestr='';
		if($Shop_ispaytype1==1)$paytypestr.='<span id="duihuanspan'.$it618_brand_goods[id].'"><input class="checkbox" type="checkbox" id="chk_isduihuan'.$n.'" name="it618_isduihuan['.$it618_brand_goods['id'].']" '.$it618_isduihuan_checked.' value="1" onclick="setpaytype('.$it618_brand_goods[id].','.$n.')"><label for="chk_isduihuan'.$n.'"><font color=blue>'.it618_brand_getlang('s1101').'</font></label></span>';else $paytypestr.='<span id="duihuanspan'.$it618_brand_goods[id].'"><input class="checkbox" type="checkbox" id="chk_isduihuan'.$n.'" name="it618_isduihuan['.$it618_brand_goods['id'].']" value="1" style="display:none"></span>';
		if($Shop_ispaytype2==1)$paytypestr.='<input class="checkbox" type="checkbox" id="chk_isalipay'.$n.'" name="it618_isalipay['.$it618_brand_goods['id'].']" '.$it618_isalipay_checked.' value="1" onclick="setpaytype('.$it618_brand_goods[id].','.$n.')"><label for="chk_isalipay'.$n.'">'.it618_brand_getlang('s1102').'</label>';else $paytypestr.='<input class="checkbox" type="checkbox" id="chk_isalipay'.$n.'" name="it618_isalipay['.$it618_brand_goods['id'].']" value="1" style="display:none"><span id="payspan'.$it618_brand_goods[id].'"></span>';
		
		if($Shop_ispaytype2==1)$paytypestr.='<span id="payspan'.$it618_brand_goods[id].'"><span id="quanspan'.$it618_brand_goods[id].'"></span><br>'.it618_brand_getlang('s1297').'<input type="text" class="txt" style="width:40px;margin-right:1px;color:green" name="it618_jfbl['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_jfbl].'">%</span>';
		
		$orderstr='';
		if($Shop_isorder==1)$orderstr='<input class="checkbox" type="checkbox" id="chk_isorderbuy'.$n.'" name="it618_isorderbuy['.$it618_brand_goods['id'].']" '.$it618_isorderbuy_checked.' value="1"><label for="chk_isorderbuy'.$n.'">'.it618_brand_getlang('s1507').'</label>';
		
		$saleoutcss='display:none';
		if($Shop_issaleout==1)$saleoutcss='';
		
		$tmpurl=it618_brand_getrewrite('shop_product',$ShopId.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.$it618_brand_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_brand_goods[id].'" '.$disabled.'><label for="chk_del'.$n.'">'.$it618_brand_goods['id'].'</label>',
			'<a style="float:left" href="'.$tmpurl.'" target="_blank" title="'.it618_brand_classname($it618_brand_goods['id']).'"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="80" height="80" align="absmiddle"/></a><div style="float:left;width:320px"><input type="text" class="txt" style="width:280px;margin-left:3px;margin-right:6px" id="it618_name'.$n.'" name="it618_name['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_name].'"><a href="plugin.php?id=it618_brand:sc_product_edit'.$adminsid.'&pid='.$it618_brand_goods[id].'&preurl='.$preurl.'">'.it618_brand_getlang('s109').'</a><br><textarea name="it618_seodescription['.$it618_brand_goods[id].']" style="width:310px;height:36px;margin-left:3px;margin-top:2px">'.$it618_brand_goods[it618_seodescription].'</textarea><span id="ptype'.$it618_brand_goods[id].'"><br><span style="float:right;'.$saleoutcss.'"><input class="checkbox" type="checkbox" id="chk_istelsale'.$n.'" name="it618_istelsale['.$it618_brand_goods['id'].']" '.$it618_istelsale_checked.' value="1"><label for="chk_istelsale'.$n.'">'.$it618_brand_lang['s1092'].'</label></span><a href="plugin.php?id=it618_brand:sc_product_type'.$adminsid.'&pid='.$it618_brand_goods[id].'&preurl='.$preurl.'" style="float:left;margin-left:3px;margin-top:1px"><font color=#F60>'.it618_brand_getlang('s1712').'</font>(<font color=red>'.$typecountok.'</font>/<font color=red>'.$typecountall.'</font>)</a></span></div>',
			'<div style="width:380px">'.$pricestr.'<br>'.$xgcountstr.' '.it618_brand_getlang('s1098').'<input type="text" class="txt" style="width:20px" name="it618_punit['.$it618_brand_goods[id].']" value="'.$it618_punit.'">'.it618_brand_getlang('s1359').$it618_brand_goods['it618_salecount'].'<br><input type="text" class="txt" style="width:115px;margin-right:0" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_brand_goods['id'].']" readonly="readonly" value="'.$it618_brand_goods['it618_xgtime1'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')">-<input type="text" class="txt" style="width:115px;margin-top:3px" id="it618_xgtime2_'.$n.'" name="it618_xgtime2['.$it618_brand_goods['id'].']" readonly="readonly" value="'.$it618_brand_goods['it618_xgtime2'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"><select id="it618_xgtype'.$n.'" name="it618_xgtype['.$it618_brand_goods[id].']" style="margin-top:3px"><option value="0"'.$it618_xgtype0.'>'.it618_brand_getlang('s1361').'</option><option value="1"'.$it618_xgtype1.'>'.it618_brand_getlang('s1362').'</option><option value="2"'.$it618_xgtype2.'>'.it618_brand_getlang('s1363').'</option></select></div>',
			$saletypestr.'<br>'.$paytypestr,
			$it618_brand_lang['s1587'].':'.$it618_state.'<br><input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_brand_goods['id'].']" '.$it618_isbm_checked.' value="1"><label for="chk_isbm'.$n.'">'.it618_brand_getlang('s257').'</label> <input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_brand_goods['id'].']" '.$it618_ison_checked.' value="1"><label for="chk_ison'.$n.'" style="'.$isoncss.'">'.it618_brand_getlang('s240').'</label><br><input class="checkbox" type="checkbox" id="chk_istj'.$n.'" name="it618_istj['.$it618_brand_goods['id'].']" '.$it618_istj_checked.' value="1"><label for="chk_istj'.$n.'">'.it618_brand_getlang('s242').'</label>'.$orderstr.'<br>'.it618_brand_getlang('s182').':<input type="text" class="txt" style="width:23px;margin-right:3px" name="it618_order['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_order].'"><input class="checkbox" style="margin-left:0px" type="checkbox" id="chk_issaledisplay'.$n.'" name="it618_issaledisplay['.$it618_brand_goods['id'].']" '.$it618_issaledisplay_checked.' value="1"><label for="chk_issaledisplay'.$n.'">'.it618_brand_getlang('s1870').'</label>'
		));
		
		$tmpjs.='setsaletype('.$it618_brand_goods['it618_saletype'].','.$it618_brand_goods[id].');';
		$tmpjs.='setyunfei('.$it618_brand_goods['it618_isyunfeifree'].','.$it618_brand_goods[id].');';
		$tmpjs.='setpaytype('.$it618_brand_goods[id].','.$n.');';
				
		$n=$n+1;
	}
	
	function it618_brand_classname($pid){
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);
		$brandclassname=C::t('#it618_brand#it618_brand_brand_class')->fetch_it618_name_by_id($it618_brand_goods['it618_brandclass_id']);
		$brandclassname1=C::t('#it618_brand#it618_brand_brand_class1')->fetch_it618_name_by_id($it618_brand_goods['it618_brandclass1_id']);
		$classname=C::t('#it618_brand#it618_brand_class')->fetch_it618_classname_by_id($it618_brand_goods['it618_class_id']);
		
		$strtmp=it618_brand_getlang('s1581').$brandclassname.' - '.$brandclassname1."\n".it618_brand_getlang('s270').$classname;
		return $strtmp;
	}
	
	if($Shop_isgoodssafe==1){
		$goodssafe=$it618_brand_lang['s1815'];
	}else{
		$goodssafe=$it618_brand_lang['s1816'];
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_brand_getlang('s70').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_brand_getlang('s261').'" onclick="return confirm(\''.$goodssafe.'\n\n'.it618_brand_getlang('s262').'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.it618_brand_getlang('s263').'" onclick="return checkvalue()"/> <input type="checkbox" id="chk_isduihuan" class="checkbox" onclick="check_all(this, \'chk_isduihuan\')" /><label for="chk_isduihuan">'.it618_brand_getlang('s691').'</label> <input type="checkbox" id="chk_isalipay" class="checkbox" onclick="check_all(this, \'chk_isalipay\')" /><label for="chk_isalipay">'.it618_brand_getlang('s1102').'</label> <input type="checkbox" id="chk_isbm" class="checkbox" onclick="check_all(this, \'chk_isbm\')" /><label for="chk_isbm">'.it618_brand_getlang('s257').'</label> <input type="checkbox" id="chk_ison" class="checkbox" onclick="check_all(this, \'chk_ison\')" /><label for="chk_ison">'.it618_brand_getlang('s240').'</label> <input type="checkbox" id="chk_istj" class="checkbox" onclick="check_all(this, \'chk_istj\')" /><label for="chk_istj">'.it618_brand_getlang('s242').'</label> <input type="checkbox" id="chk_isorderbuy" class="checkbox" onclick="check_all(this, \'chk_isorderbuy\')" /><label for="chk_isorderbuy">'.it618_brand_getlang('s1507').'</label> <input type="checkbox" id="chk_issaledisplay" class="checkbox" onclick="check_all(this, \'chk_issaledisplay\')" /><label for="chk_issaledisplay">'.it618_brand_getlang('s1871').'</label><br><font color="blue">'.it618_brand_getlang('s846').'<font color=red>'.$ShopUPRICE.'</font> '.it618_brand_getlang('s847').'<font color=red>'.$ShopSCORE.'</font>)</font> <font color=blue>'.it618_brand_getlang('s1104').'<font color=red>'.$ShopJfBl.'%</font>'.it618_brand_getlang('s1242').'</font><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter(); /*dism��taobao��com*/

echo '
<script charset="utf-8" src="source/plugin/it618_brand/js/Calendar.js"></script><script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
		
		function setsaletype(saletype,id){
			document.getElementById("countspan"+id).style.display="none";
			document.getElementById("yunfeispan"+id).style.display="none";
			document.getElementById("kmspan"+id).style.display="none";
			document.getElementById("contentspan"+id).style.display="none";
			document.getElementById("prepayspan"+id).style.display="none";
			document.getElementById("duihuanspan"+id).style.display="";
			
			if(saletype==2||saletype==4){
				document.getElementById("yunfeispan"+id).style.display="";
			}
			if(saletype==3){
				document.getElementById("kmspan"+id).style.display="";
			}else{
				document.getElementById("countspan"+id).style.display="";
			}
			if(saletype==5){
				document.getElementById("contentspan"+id).style.display="";
			}
			if(saletype==6){
				document.getElementById("prepayspan"+id).style.display="";
				document.getElementById("duihuanspan"+id).style.display="none";
			}
		}
		
		function setyunfei(yunfei,id){
			document.getElementById("kgblspan"+id).style.display="none";
			
			if(yunfei==0||yunfei==2){
				document.getElementById("kgblspan"+id).style.display="";
			}
		}
		
		function setpaytype(id,id1){
			document.getElementById("pricespan"+id).style.display="none";
			document.getElementById("scorespan"+id).style.display="none";
			document.getElementById("payspan"+id).style.display="none";
			
			if(document.getElementById("chk_isalipay"+id1).checked){
				document.getElementById("payspan"+id).style.display="";
				document.getElementById("pricespan"+id).style.display="";
			}
			
			if(document.getElementById("chk_isduihuan"+id1).checked){
				document.getElementById("scorespan"+id).style.display="";
			}
		}
		
		function checkvalue(){
			for(var i=1;i<'.$n.';i++){
				var it618_name = document.getElementById("it618_name"+i).value;
				var it618_xgtype = document.getElementById("it618_xgtype"+i).value;
				var it618_xgtime1 = document.getElementById("it618_xgtime1_"+i).value;
				var it618_xgtime2 = document.getElementById("it618_xgtime2_"+i).value;
				
				var tmparr1=it618_xgtime1.split(" ");
				var tmparr2=it618_xgtime2.split(" ");
				
				if(it618_xgtype>0){
					if(parseInt(tmparr2[0].replace(/-/g,""))<parseInt(tmparr1[0].replace(/-/g,""))){
						alert(it618_name+"'.it618_brand_getlang('s1374').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
					
					var flag=0;
					if(it618_xgtype==2){
						flag=1;
					}else{
						if(parseInt(tmparr2[0].replace(/-/g,""))==parseInt(tmparr1[0].replace(/-/g,""))){
							flag=1;
						}
					}
					if(flag==1&&parseInt(tmparr2[1].replace(":",""))<=parseInt(tmparr1[1].replace(":",""))){
						alert(it618_name+"'.it618_brand_getlang('s1375').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
				}
			}
		}
		
		'.$tmpjs.'
	  </script>';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>