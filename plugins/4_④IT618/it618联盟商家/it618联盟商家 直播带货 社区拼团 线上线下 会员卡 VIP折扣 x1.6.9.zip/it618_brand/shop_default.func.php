<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/brand_function.func.php';

$brandcount = C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1');

$homeurl=it618_brand_getrewrite('brand_home','','plugin.php?id=it618_brand:index');

$brand_brandlogo=str_replace("{homeurl}",$homeurl,$it618_brand['brand_brandlogo']);

$topnav=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('topnav');
$buybottom=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('buybottom');
$lybottom=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('lybottom');
$shopfooter=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('shopfooter');

$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
foreach(C::t('#it618_brand#it618_brand_focus')->fetch_all_by_shopid_order($ShopId) as $it618_brand_focus) {
	if($it618_brand_focus['it618_url']!=''){
		$str_focus.='<li><a href="'.$it618_brand_focus['it618_url'].'" target="_blank"><img src="'.$it618_brand_focus['it618_img'].'" width="1200" height="'.$Shop_focusheight.'"/></a></li>';
	}else{
		$str_focus.='<li><img src="'.$it618_brand_focus['it618_img'].'" width="1200" height="'.$Shop_focusheight.'" /></li>';
	}
	if(count($i1ii1)!=11)return;
}

if($Shop_headerimg!=''){
	$it618_header='<div style="width:1200px;margin:1px auto;margin-bottom:0;padding:0"><img src="'.$Shop_headerimg.'" width="1200"></div>';
}

$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($ShopId);
$username=it618_brand_getusername($ShopUid);

$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
$tmplevelarr=explode(",",$it618_brand['brand_level']);
$tmplevelarr[0]=str_replace(it618_brand_getlang('s1273'),"",$tmplevelarr[0]);

$shopuser='<a href="'.it618_brand_rewriteurl($ShopUid).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1"><font style="font:bold 14px verdana;">'.$username.'</font></a> '.it618_brand_getonlinestate($ShopUid);

$moneyurl=it618_brand_getrewrite('shop_money',$ShopId,'plugin.php?id=it618_brand:money&sid='.$ShopId);
$moneycount = C::t('#it618_brand#it618_brand_money')->count_by_shopid($ShopId);

if($Shop_isgoodsclass==1){
	foreach(C::t('#it618_brand#it618_brand_class')->fetch_all_by_shopid($ShopId) as $it618_brand_class) {
		$tmpurl=it618_brand_getrewrite('shop_productlist',$ShopId.'@'.$it618_brand_class['id'].'@1','plugin.php?id=it618_brand:product_list&sid='.$ShopId.'&cid='.$it618_brand_class['id']);
		$str_productclass.='<dt><a href="'.$tmpurl.'">'.$it618_brand_class['it618_classname'].'</a></dt>';
	}
}

foreach(C::t('#it618_brand#it618_brand_article_class')->fetch_all_by_shopid($ShopId) as $it618_brand_article_class) {
	$tmpurl=it618_brand_getrewrite('shop_articlelist',$ShopId.'@'.$it618_brand_article_class['id'].'@1','plugin.php?id=it618_brand:article_list&sid='.$ShopId.'&cid='.$it618_brand_article_class['id']);
	$str_articleclass.='<dt><a href="'.$tmpurl.'">'.$it618_brand_article_class['it618_classname'].'</a></dt>';
}

foreach(C::t('#it618_brand#it618_brand_image_class')->fetch_all_by_shopid($ShopId) as $it618_brand_image_class) {
	$tmpurl=it618_brand_getrewrite('shop_imagelist',$ShopId.'@'.$it618_brand_image_class['id'].'@1','plugin.php?id=it618_brand:image_list&sid='.$ShopId.'&cid='.$it618_brand_image_class['id']);
	$str_imageclass.='<dt><a href="'.$tmpurl.'">'.$it618_brand_image_class['it618_classname'].'</a></dt>';
}

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods')." where it618_ison=1 and it618_state=1 and it618_shopid=".$ShopId." ORDER BY it618_salecount desc limit 0,10");
while($it618_brand_goods = DB::fetch($query)) {
	$tmpurl=it618_brand_getrewrite('shop_product',$ShopId.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.$it618_brand_goods['id']);
	if($n==1){
		$str_goods_sale.='<li class="first">
						   <em class="n1">'.$n.'</em>
							  <a href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'">'.$it618_brand_goods['it618_name'].'</a>
							   <a href="'.$tmpurl.'" class="pic" target="_blank"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="80" height="80" alt="'.$it618_brand_goods['it618_name'].'"></a>					
						  </li> ';
	}else{
		$str_goods_sale.='<li >
							  <em class="n1">'.$n.'</em>
							  <a href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'">'.$it618_brand_goods['it618_name'].'</a>	
						  </li>';
	}
	$n=$n+1;
}

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods')." where it618_ison=1 and it618_state=1 and it618_shopid=".$ShopId." ORDER BY it618_views desc limit 0,10");
while($it618_brand_goods = DB::fetch($query)) {
	$tmpurl=it618_brand_getrewrite('shop_product',$ShopId.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.$it618_brand_goods['id']);
	if($n==1){
		$str_goods_views.='<li class="first">
						   <em class="n1">'.$n.'</em>
							  <a href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'">'.$it618_brand_goods['it618_name'].'</a>
							   <a href="'.$tmpurl.'" class="pic" target="_blank"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="80" height="80" alt="'.$it618_brand_goods['it618_name'].'"></a>					
						  </li> ';
	}else{
		$str_goods_views.='<li >
							  <em class="n1">'.$n.'</em>
							  <a href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'">'.$it618_brand_goods['it618_name'].'</a>	
						  </li>';
	}
	$n=$n+1;
}


$pid=intval($_GET['pid']);
$uid = $_G['uid'];
if($uid>0){
	if($Shop_isuservip==1){
		if($it618_brand_cardmoney=C::t('#it618_brand#it618_brand_cardmoney')->fetch_by_shopid_uid($ShopId,$uid)){
			$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
			$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($ShopId,$allmoney);
			$viplevel=$fetch_by_money['it618_level'];
		}
		
		if($viplevel!=''){
			$viplevel='<font color=red>VIP'.$viplevel.'</font>';
			$zk='<font color=#f60>'.$fetch_by_money['it618_zk'].'%</font>';
		}
	}
	
	if($pid>0){
		if(C::t('#it618_brand#it618_brand_visit')->count_by_it618_pid_it618_uid($pid,$uid)==0){
			$id = C::t('#it618_brand#it618_brand_visit')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_pid' => $pid,
				'it618_uid' => $uid,
				'it618_time' => $_G['timestamp']
			), true);
		}else{
			C::t('#it618_brand#it618_brand_visit')->update_it618_time_by_it618_pid_it618_uid($_G['timestamp'],$pid,$uid);
		}
	}
	
	if(C::t('#it618_brand#it618_brand_visitall')->count_by_shopid_it618_uid($ShopId,$uid)==0){
		$id = C::t('#it618_brand#it618_brand_visitall')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_uid' => $uid,
			'it618_time' => $_G['timestamp']
		), true);
	}else{
		C::t('#it618_brand#it618_brand_visitall')->update_it618_time_by_shopid_it618_uid($ShopId,$_G['timestamp'],$uid);
	}
	
	$tomonth = date('n'); 
	$todate = date('j'); 
	$toyear = date('Y');
	$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
	if(C::t('#it618_brand#it618_brand_visitcount')->count_by_shopid_it618_uid_it618_time($ShopId,$uid,$time)==0){
		$id = C::t('#it618_brand#it618_brand_visitcount')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_uid' => $uid,
			'it618_time' => $time
		), true);
	}
}

if($it618_brand_live=C::t('#it618_brand#it618_brand_live')->fetch_by_shopid($ShopId)){
	$videotype=$it618_brand_live['it618_type'];
	if($it618_brand_live['it618_name']=='')$videoname=$it618_brand_lang['s1073'];else $videoname=$it618_brand_live['it618_name'];
}

if($str_yuangong!='')$str_yuangong="<ul>$str_yuangong<ul><div style='text-align:center;'>$pagepre&nbsp;&nbsp;$pagenext</div>";

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$goodscount=C::t('#it618_brand#it618_brand_goods')->count_by_shopid($ShopId, 'it618_ison=1 and it618_state=1');
$articlecount=C::t('#it618_brand#it618_brand_article')->count_by_shopid($ShopId);
$articlecount1=C::t('#it618_brand#it618_brand_onepage')->count_by_shopid($ShopId);
$articlecount=$articlecount+$articlecount1;
$imagecount=C::t('#it618_brand#it618_brand_image')->count_by_shopid($ShopId);

$lycount=C::t('#it618_brand#it618_brand_home_ly')->count_by_shopid($ShopId);

$tomonth = date('n'); 
$todate = date('j'); 
$toyear = date('Y');
$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
$visitcountall=C::t('#it618_brand#it618_brand_visitcount')->count_by_shopid_it618_time($ShopId);
$visitcounttoday=C::t('#it618_brand#it618_brand_visitcount')->count_by_shopid_it618_time($ShopId,$time);
$visitcountyesterday=C::t('#it618_brand#it618_brand_visitcount')->count_by_shopid_it618_time($ShopId,($time-60*60*24));

$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);
$brand_home=it618_brand_getrewrite('brand_home',$ShopId,'plugin.php?id=it618_brand:index');
$brand_search=it618_brand_getrewrite('brand_search','','plugin.php?id=it618_brand:search');
$brand_shops=it618_brand_getrewrite('brand_shops',$ShopId,'plugin.php?id=it618_brand:shops');
$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);
$shop_productlist=it618_brand_getrewrite('shop_productlist',$ShopId,'plugin.php?id=it618_brand:product_list&sid='.$ShopId);
$shop_articlelist=it618_brand_getrewrite('shop_articlelist',$ShopId,'plugin.php?id=it618_brand:article_list&sid='.$ShopId);
$shop_imagelist=it618_brand_getrewrite('shop_imagelist',$ShopId,'plugin.php?id=it618_brand:image_list&sid='.$ShopId);
$shop_money=it618_brand_getrewrite('shop_money',$ShopId,'plugin.php?id=it618_brand:money&sid='.$ShopId);
$shop_visit=it618_brand_getrewrite('shop_visit',$ShopId,'plugin.php?id=it618_brand:visit&sid='.$ShopId);

?>