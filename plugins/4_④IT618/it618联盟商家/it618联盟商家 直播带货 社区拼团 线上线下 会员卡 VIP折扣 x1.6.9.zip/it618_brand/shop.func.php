<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_brand = $_G['cache']['plugin']['it618_brand'];

$brand_fwpower=(array)unserialize($it618_brand['brand_fwpower']);
if(!in_array("", $brand_fwpower)&&!in_array($_G['groupid'], $brand_fwpower)){
	echo $it618_brand_lang['s1486'].'<a href="'.$_G['siteurl'].'">'.$it618_brand_lang['s1487'].'</a>';
	exit;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if(isset($_GET['sid'])){
	
	if(isset($_GET['adminsid'])){
		$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$sid=$_GET['adminsid'];
		}else{
			echo it618_brand_getlang('s1220');exit;
		}
	}else{
		$sid=$_GET['sid'];
	}
	
	if(C::t('#it618_brand#it618_brand_brand')->count_by_id($sid)>0){
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($sid);
		$it618_state=$it618_brand_brand['it618_state'];
		if($it618_state==0){
			echo it618_brand_getlang('s380');exit;
		}elseif($it618_state==1){
			echo it618_brand_getlang('s380');exit;
		}else{
			$it618_htstate=$it618_brand_brand['it618_htstate'];
			if($it618_htstate==0){
				$homeurl=it618_brand_getrewrite('brand_home','','plugin.php?id=it618_brand:index');
				dheader("location:$homeurl");
				echo it618_brand_getlang('s381');exit;
			}elseif($it618_htstate==2){
				if($it618_brand_brand['it618_uid']==$_G['uid']){
					if($IsGroup==1){
						if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('brand',$it618_brand_brand['it618_power'])){
							if($it618_group_rzmoney['it618_istbtime']==1){
								if($it618_group_goodstmp = DB::fetch_first("SELECT * FROM ".DB::table('it618_group_goods')." where it618_groupid=".$it618_group_rzmoney['it618_groupid']." and it618_state=1 ORDER BY it618_unit")){
									require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
									$payurl=it618_group_getrewrite('group_product',$it618_group_goodstmp['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goodstmp['id']);
									dheader("location:$payurl");
								}
							}
						}
					}
				}
				echo it618_brand_getlang('s382');exit;
			}else{
				$ShopId=$it618_brand_brand['id'];
				$ShopName=$it618_brand_brand['it618_name'];
				$ShopName_nav=$it618_brand_brand['it618_name'];
				$ShopStyle=$it618_brand_brand['it618_shopstyle'];
				$ShopUid=$it618_brand_brand['it618_uid'];
				$ShopMoney=$it618_brand_brand['it618_money'];
				$ShopJfBl=$it618_brand_brand['it618_jfbl'];
				$ShopSCORE=$it618_brand_brand['it618_score'];
				$ShopUPRICE=$it618_brand_brand['it618_uprice'];
				
				$Shop_area_id=$it618_brand_brand['it618_area_id'];
				
				$Shop_logo=$it618_brand_brand['it618_logo'];
				$Shop_homelogo=$it618_brand_brand['it618_homelogo'];
				$Shop_headerimg=$it618_brand_brand['it618_headerimg'];
				$Shop_homebg=$it618_brand_brand['it618_homebg'];
				$Shop_homebgmove=$it618_brand_brand['it618_homebgmove'];
				$Shop_isimagemove=$it618_brand_brand['it618_isimagemove'];
				$Shop_imagemovecount=$it618_brand_brand['it618_imagemovecount'];
				$Shop_imagemovespeed=$it618_brand_brand['it618_imagemovespeed'];
				
				$Shop_systemcount=$it618_brand_brand['it618_systemcount'];
				$Shop_addr=$it618_brand_brand['it618_addr'];
				$Shop_kdaddr=$it618_brand_brand['it618_kdaddr'];
				$Shop_noticestitle=$it618_brand_brand['it618_noticestitle'];
				$Shop_notices=$it618_brand_brand['it618_notices'];
				$Shop_weixincode=$it618_brand_brand['it618_weixincode'];
				$Shop_wapcode=$it618_brand_brand['it618_wapcode'];
				$Shop_dianhua=$it618_brand_brand['it618_dianhua'];
				$Shop_shouji=$it618_brand_brand['it618_shouji'];
				$Shop_kefuqq=$it618_brand_brand['it618_kefuqq'];
				$Shop_kefuwx=$it618_brand_brand['it618_kefuwx'];
				$Shop_kefuqqname=$it618_brand_brand['it618_kefuqqname'];
				$Shop_yytime=$it618_brand_brand['it618_yytime'];
				$Shop_fahuo=$it618_brand_brand['it618_fahuo'];
				$Shop_youhui=$it618_brand_brand['it618_youhui'];
				$Shop_tongji=$it618_brand_brand['it618_tongji'];
				$Shop_mappoint=$it618_brand_brand['it618_mappoint'];
				
				$Shop_seokeywords=$it618_brand_brand['it618_seokeywords'];
				$Shop_seodescription=$it618_brand_brand['it618_seodescription'];
				
				$Shop_isbrandnav=$it618_brand_brand['it618_isbrandnav'];
				$Shop_homenavname=$it618_brand_brand['it618_homenavname'];
				
				$Shop_ishomely=$it618_brand_brand['it618_ishomely'];
				$Shop_homelycount=$it618_brand_brand['it618_homelycount'];
				$Shop_isproductly=$it618_brand_brand['it618_isproductly'];
				$Shop_isgoodsclass=$it618_brand_brand['it618_isgoodsclass'];
				$Shop_isgoodscheck=$it618_brand_brand['it618_isgoodscheck'];
				$Shop_isgoodssafe=$it618_brand_brand['it618_isgoodssafe'];
				$Shop_txtype=$it618_brand_brand['it618_txtype'];
				$Shop_isyunfeikg=$it618_brand_brand['it618_isyunfeikg'];
				$Shop_productlycount=$it618_brand_brand['it618_productlycount'];
				$Shop_isarticlely=$it618_brand_brand['it618_isarticlely'];
				$Shop_articlelycount=$it618_brand_brand['it618_articlelycount'];
				
				$Shop_productvisitcount=$it618_brand_brand['it618_productvisitcount'];
				$Shop_productsalecount=$it618_brand_brand['it618_productsalecount'];
				
				$Shop_alipaybl=$it618_brand_brand['it618_alipaybl'];
				
				$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
				$ShopPower=$it618_brand_brandgroup['it618_groupname'];
				if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" align="absmiddle" style="margin-top:-1px"/>';
				$Shop_isgoods=$it618_brand_brandgroup['it618_isgoods'];
				$Shop_issaleagain=$it618_brand_brandgroup['it618_issaleagain'];
				$Shop_iscard=$it618_brand_brandgroup['it618_iscard'];
				$Shop_issaletype1=$it618_brand_brandgroup['it618_issaletype1'];
				$Shop_issaletype2=$it618_brand_brandgroup['it618_issaletype2'];
				$Shop_issaletype3=$it618_brand_brandgroup['it618_issaletype3'];
				$Shop_issaletype4=$it618_brand_brandgroup['it618_issaletype4'];
				$Shop_issaletype5=$it618_brand_brandgroup['it618_issaletype5'];
				$Shop_ispaytype1=$it618_brand_brandgroup['it618_ispaytype1'];
				$Shop_ispaytype2=$it618_brand_brandgroup['it618_ispaytype2'];
				$Shop_isorder=$it618_brand_brandgroup['it618_isorder'];
				$Shop_islive=$it618_brand_brandgroup['it618_islive'];
				$Shop_issaleout=$it618_brand_brandgroup['it618_issaleout'];
				$Shop_isuservip=$it618_brand_brandgroup['it618_isuservip'];
				$Shop_score=$it618_brand_brandgroup['it618_score'];
				
				$Shop_focusheight=$it618_brand_brand['it618_focusheight'];
				$Shop_focusheight1=$it618_brand_brand['it618_focusheight']-25;
			}
		}
		
	}else{
		echo it618_brand_getlang('s380');exit;
	}
}else{
	$flag=0;
	if($_GET['ac']=='getbrandarea'||$_GET['ac']=='getbrandclass'||$_GET['ac']=='getshopclass'||$_GET['ac']=='getshoparea'||$_GET['ac']=='getfindkey'||$_GET['ac']=='delfindkey'||$_GET['ac']=='clearfindkey'||$_GET['ac']=='addr_get'||$_GET['ac']=='addr_add'||$_GET['ac']=='addr_edit'||$_GET['ac']=='addr_del'||$_GET['ac']=='addr_default'||$_GET['ac']=='renzheng'||$_GET['ac']=='addmycard'||$_GET['ac']=='editcardname'||$_GET['ac']=='tuikuan'||$_GET['ac']=='delorder'||$_GET['ac']=='saletui'||$_GET['ac']=='salepj'||$_GET['ac']=='getpjpic'||$_GET['ac']=='shouhuo'||$_GET['ac']=='getshopslist'||$_GET['ac']=='getgoodslist'||$_GET['ac']=='getarticlelist'||$_GET['ac']=='getlylist'||$_GET['ac']=='getbrandlist'||$_GET['ac']=='myright'||$_GET['ac']=='alipay_success'||$_GET['ac']=='alipay_fail'||$_GET['ac']=='wx_success'||$_GET['ac']=='wx_fail'||$_GET['ac']=='getmode'||$_GET['ac']=='goodslist_get'||$_GET['ac']=='moneylist_get'||$_GET['ac']=='mysalelist_get'||$_GET['ac']=='orderlist_get'||$_GET['ac']=='collectlist_get'||$_GET['ac']=='gwclist_get'||$_GET['ac']=='delcollect'||$_GET['ac']=='delgwc'||$_GET['ac']=='cleargwc'||$_GET['ac']=='gwcminus'||$_GET['ac']=='gwcplus'||$_GET['ac']=='gwcpay_add'||$_GET['ac']=='getalipaysale'||$_GET['ac']=='delalipaysale'||$_GET['ac']=='mycardmoney_get'||$_GET['ac']=='brandlist_get'||$_GET['ac']=='imgdelete'||$_GET['ac']=='brandmode'||$_GET['ac']=='brandstyle'||$_GET['ac']=='home_goods'||$_GET['ac']=='home_shop'||$_GET['ac']=='payok'||$_GET['ac']=='getsaleaudio'||$_GET['ac']=='getmapapi'){
		$flag=1;
	}
	if($flag==0){
		echo it618_brand_getlang('s383');exit;
	}
}

if($_GET['ac']=='brandlist_get'||$_GET['ac']=='goodslist_get'||$_GET['ac']=='getgoodslist'||$_GET['ac']=='collectlist_get'){
	if($it618_brand['brand_style']>2){
		$brandstyle=getcookie('brandstyle');
		if($brandstyle==''){
			if($it618_brand['brand_style']==3)$brandstyle='1';else $brandstyle='2';
		}
	}else{
		if($it618_brand['brand_style']==1)$brandstyle='1';else $brandstyle='2';
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>