<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$ShopId);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$it618_brand_show = C::t('#it618_brand#it618_brand_show')->fetch_by_shopid_showid_showtype($ShopId,0,'visit');
$ppp = $it618_brand_show['it618_pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$pagelistcount = C::t('#it618_brand#it618_brand_visitall')->count_by_shopid_it618_time($ShopId);
$hrefsql=it618_brand_getrewrite('shop_visit',$ShopId.'@it618page','plugin.php?id=it618_brand:visit&sid='.$ShopId);
$multipage = multi($pagelistcount, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_brand_multipage($multipage,$uri);
$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
if($ii1ill[5]!='_')return;

foreach(C::t('#it618_brand#it618_brand_visitall')->fetch_all_by_shopid1(
	$ShopId,$startlimit,$ppp
) as $it618_brand_visitall) {
	$username=it618_brand_getusername($it618_brand_visitall['it618_uid']);
	
	$i=1;
	$tempstr='';
	foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_thread_by_uid($it618_brand_visitall['it618_uid']) as $result) {
		
		if(!in_array($result['tid'],$tmptid)){
			
			$tempstr .='<li><div style="width:320px; white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><a href="forum.php?mod=viewthread&tid='.$result['tid'].'" title="'.$result['subject'].'" target="_blank">'.$result['subject'].'</a> <span>('.it618_brand_gettime($result['dateline']).')</span></div></li>';
			$i=$i+1;
			$tmptid[]=$result['tid'];
		}
		if($i>3)break;
	}
	
	$str_visit.='<tr class="tr1">
					<td><div class="a1"><a href="'.it618_brand_rewriteurl($it618_brand_visitall['it618_uid']).'" target="_blank"><img src="'.it618_brand_discuz_uc_avatar($it618_brand_visitall['it618_uid'],'small').'" alt="'.it618_brand_getlang('s147').''.$username.''.it618_brand_getlang('s148').'" width="50" height="50" /></a></div></td>
					<td><a href="'.it618_brand_rewriteurl($it618_brand_visitall['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s147').''.$username.''.it618_brand_getlang('s148').'" class="a1">'.$username.'</a><br></td>
					<td>'.it618_brand_getonlinestate($it618_brand_visitall['it618_uid']).'</td>
					<td>'.it618_brand_gettime($it618_brand_visitall['it618_time']).'</td>
					<td><ul>'.$tempstr.'</ul></td>
					</tr>';
}

if($multipage!='')$multipage='<div class="commonpage" style="margin-top:10px">'.str_replace(" / ","/",$multipage).'</div>';

$tmparr=explode(":",$_GET['id']);
$pagetype=$tmparr[1];
$seotitle=$it618_brand_show['it618_name'];
$seokeywords=$Shop_seokeywords;
$seodescription=$Shop_seodescription;
$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo; '.$seotitle;

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_nav.func.php';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:shop_default');
?>