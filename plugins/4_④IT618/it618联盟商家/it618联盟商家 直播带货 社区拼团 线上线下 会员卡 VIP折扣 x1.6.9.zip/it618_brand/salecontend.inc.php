<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_brand = $_G['cache']['plugin']['it618_brand'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($_GET['saleid']);
$it618_brand_goods=C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);

$pname=$it618_brand_goods['it618_name'];

if($_GET['ac']=='shop'){
	$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
	if($it618_brand_brand['it618_uid']==$_G['uid']){
		$isok=1;
	}
}else{
	if($it618_brand_sale['it618_uid']==$_G['uid']){
		$isok=1;
	}
}

if($isok==1){
	$it618_message_buy=$it618_brand_goods['it618_message_buy'];
	
	if($_GET['wap']==1){
		$it618_message_buy=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message_buy);
		$it618_message_buy=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img class="lazy widthimg" data-original="\1"/>',$it618_message_buy);
		$it618_message_buy=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message_buy);
	}else{
		$it618_message_buy=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="763" height="430" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_message_buy);
	}
	
	$goodsbuycontentuser=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('goodsbuycontentuser');
		
	$it618_message_buy=$it618_message_buy.'<br>'.$goodsbuycontentuser;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:salecontend');
?>