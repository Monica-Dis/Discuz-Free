<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/brand_function.func.php';

function it618_brand_getmodecontent($modetype,$modecode,$modecount){
	global $_G;
	$it618_brand = $_G['cache']['plugin']['it618_brand'];
	
	$tmparr=explode("[loop]",$modecode);
	$tmparr1=explode("[/loop]",$tmparr[1]);
	
	if($modetype=='money_new'){

		foreach(C::t('#it618_brand#it618_brand_money')->fetch_all_by_search(0,$modecount) as $it618_brand_money) {
				  
			$username=C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($it618_brand_money['it618_uid']);
			if($_G['cache']['plugin']['it618_brand']['rewriteurl']==1){
				  $userurl = 'space-uid-'.$it618_brand_money['it618_uid'].'.html';
			}else{
				  $userurl = 'home.php?mod=space&uid='.$it618_brand_money['it618_uid'];
			}
	
			if($it618_brand_money['it618_type']!=1){
				
				if($it618_brand_money['it618_type']==2){
					$type=str_substr("[if type=2]", "[/if type]", $tmparr1[0]);
				}else{
					$type=str_substr("[if type=3]", "[/if type]", $tmparr1[0]);
				}
				
				$bmtmp=str_substr("[if isbm=1]", "[/if isbm]", $type);
				$bmtmp=explode("[else]",$bmtmp);
				
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_money['it618_pid']);
				if($it618_brand_goods['it618_isbm']==1){
					$type=str_replace("[else]".$bmtmp[1]."[/if isbm]","",$type);
					$type=str_replace("[if isbm=1]","",$type);
				}else{
					$type=str_replace("[if isbm=1]".$bmtmp[0]."[else]","",$type);
					$type=str_replace("[/if isbm]","",$type);
				}
				
				$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_money['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_money['it618_shopid'].'&pid='.$it618_brand_goods['id']);

				
			}else{
				$type=str_substr("[if type=1]", "[/if type]", $tmparr1[0]);
				$bztmp=str_substr("{bz,", "}", $type);
				$bztmp=explode(",",$bztmp);
			}
			
			$usernametmp=str_substr("{username,", "}", $type);
			$usernametmp=explode(",",$usernametmp);
			$pnametmp=str_substr("{pname,", "}", $type);
			$pnametmp=explode(",",$pnametmp);
			
			
			$tmpurl1=it618_brand_getrewrite('shop_product',$it618_brand_money['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_money['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			$tmpurl2=it618_brand_getrewrite('shop_home',$it618_brand_money['it618_shopid'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_money['it618_shopid']);
			
			$tmpstr=str_replace("{userurl}",$userurl,$type);
			$tmpstr=str_replace("{username}",$username,$tmpstr);
			$tmpstr=str_replace("{username,".$usernametmp[0].",".$usernametmp[1]."}",cutstr($username,$usernametmp[0],str_replace("'","",$usernametmp[1])),$tmpstr);
			$tmpstr=str_replace("{purl}",$tmpurl1,$tmpstr);
			$tmpstr=str_replace("{pname}",$it618_brand_goods['it618_name'],$tmpstr);
			$tmpstr=str_replace("{pname,".$pnametmp[0].",".$pnametmp[1]."}",cutstr($it618_brand_goods['it618_name'],$pnametmp[0],str_replace("'","",$pnametmp[1])),$tmpstr);
			$tmpstr=str_replace("{score}",$it618_brand_money['it618_score'],$tmpstr);
			$tmpstr=str_replace("{bz,".$bztmp[0].",".$bztmp[1]."}",cutstr($it618_brand_money['it618_bz'],$bztmp[0],str_replace("'","",$bztmp[1])),$tmpstr);
			$tmpstr=str_replace("{shopurl}",$tmpurl2,$tmpstr);
			$tmpstr=str_replace("{timeline}",it618_brand_gettime($it618_brand_money['it618_time']),$tmpstr);
			
			$content.=$tmpstr;

		}
	}elseif($modetype=='article_new'){
		foreach(C::t('#it618_brand#it618_brand_article')->fetch_all_by_search(0,$modecount) as $it618_brand_article) {
	
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_article['it618_shopid']);
					
			$titletmp=str_substr("{title,", "}", $tmparr1[0]);
			$titletmp=explode(",",$titletmp);
			$shopnametmp=str_substr("{shopname,", "}", $tmparr1[0]);
			$shopnametmp=explode(",",$shopnametmp);
			
			$title=$it618_brand_article['it618_name'];
			$shopname=$it618_brand_brand['it618_name'];
			
			$tmpurl1=it618_brand_getrewrite('shop_article',$it618_brand_article['it618_shopid'].'@'.$it618_brand_article['id'],'plugin.php?id=it618_brand:article&sid='.$it618_brand_article['it618_shopid'].'&aid='.$it618_brand_article['id']);
			$tmpurl2=it618_brand_getrewrite('shop_home',$it618_brand_article['it618_shopid'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_article['it618_shopid']);
			
			$tmpstr=str_replace("{url}",$tmpurl1,$tmparr1[0]);
			$tmpstr=str_replace("{shopurl}",$tmpurl2,$tmpstr);
			$tmpstr=str_replace("{title}",$title,$tmpstr);
			$tmpstr=str_replace("{title,".$titletmp[0].",".$titletmp[1]."}",cutstr($title,$titletmp[0],str_replace("'","",$titletmp[1])),$tmpstr);
			$tmpstr=str_replace("{shopname}",$shopname,$tmpstr);
			$tmpstr=str_replace("{shopname,".$shopnametmp[0].",".$shopnametmp[1]."}",cutstr($shopname,$shopnametmp[0],str_replace("'","",$shopnametmp[1])),$tmpstr);
			$tmpstr=str_replace("{timeline}",it618_brand_gettime($it618_brand_article['it618_time']),$tmpstr);
			
			$content.=$tmpstr;
			
		}
	}elseif($modetype=='ly_new'){
		foreach(C::t('#it618_brand#it618_brand_home_ly')->fetch_all_by_search(0,$modecount) as $it618_brand_home_ly) {
			
			$contenttmp=str_substr("{content,", "}", $tmparr1[0]);
			$contenttmp=explode(",",$contenttmp);
			
			$it618_content=dhtmlspecialchars($it618_brand_home_ly['it618_content']);
			
			$tmpurl=it618_brand_getrewrite('shop_home',$it618_brand_home_ly['it618_shopid'].'@mr='.$it618_brand_home_ly['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_home_ly['it618_shopid'].'&mr='.$it618_brand_home_ly['id']);
			$tmpstr=str_replace("{url}",$tmpurl,$tmparr1[0]);
			$tmpstr=str_replace("{content}",$it618_content,$tmpstr);
			$tmpstr=str_replace("{content,".$contenttmp[0].",".$contenttmp[1]."}",cutstr($it618_content,$contenttmp[0],str_replace("'","",$contenttmp[1])),$tmpstr);
			$tmpstr=str_replace("{timeline}",it618_brand_gettime($it618_brand_home_ly['it618_time']),$tmpstr);
			
			$content.=$tmpstr;
			
		}
	}elseif($modetype=='thread_new'){

		foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_thread(0,$modecount) as $fetch_all_thread) {
			
			if($_G['cache']['plugin']['it618_brand']['rewriteurl']==1){
				  $userurl = 'space-uid-'.$fetch_all_thread['authorid'].'.html';
			}else{
				  $userurl = 'home.php?mod=space&uid='.$fetch_all_thread['authorid'];
			}
			
			$usernametmp=str_substr("{username,", "}", $tmparr1[0]);
			$usernametmp=explode(",",$usernametmp);
			$titletmp=str_substr("{title,", "}", $tmparr1[0]);
			$titletmp=explode(",",$titletmp);
			
			$username=$fetch_all_thread['author'];
			$title=$fetch_all_thread['subject'];
			
			$tmpstr=str_replace("{userurl}",$userurl,$tmparr1[0]);
			$tmpstr=str_replace("{url}",'forum.php?mod=redirect&goto=findpost&ptid='.$fetch_all_thread['tid'].'&pid='.$fetch_all_thread['pid'].'&fromuid='.$fetch_all_thread['fid'],$tmpstr);
			$tmpstr=str_replace("{username}",$username,$tmpstr);
			$tmpstr=str_replace("{username,".$usernametmp[0].",".$usernametmp[1]."}",cutstr($username,$usernametmp[0],str_replace("'","",$usernametmp[1])),$tmpstr);
			$tmpstr=str_replace("{title}",$title,$tmpstr);
			$tmpstr=str_replace("{title,".$titletmp[0].",".$titletmp[1]."}",cutstr($title,$titletmp[0],str_replace("'","",$titletmp[1])),$tmpstr);
			$tmpstr=str_replace("{timeline}",it618_brand_gettime($fetch_all_thread['dateline']),$tmpstr);
			
			$content.=$tmpstr;
			
		}
	}elseif($modetype=='product_new'||$modetype=='product_hot'){
		if($modetype=='product_new')$orderby='g.id desc';else $orderby='g.it618_salecount desc';
		foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_search(
			'g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1',$orderby,0,0,0,0,'',0,0,$startlimit,$modecount
		) as $it618_brand_goods) {
			
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			$tmpstr=str_replace("{pname}",$it618_brand_goods['it618_name'],$tmparr1[0]);
			$tmpstr=str_replace("{ppicsrc}",it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']),$tmpstr);
			$tmpstr=str_replace("{puprice}",$it618_brand_goods['it618_uprice'],$tmpstr);
			$tmpstr=str_replace("{pprice}",$it618_brand_goods['it618_price'],$tmpstr);
			$tmpstr=str_replace("{pscore}",$it618_brand_goods['it618_score'],$tmpstr);
			$tmpstr=str_replace("{pcount}",$it618_brand_goods['it618_count'],$tmpstr);
			$tmpstr=str_replace("{pviews}",$it618_brand_goods['it618_views'],$tmpstr);
			$tmpstr=str_replace("{psalecount}",$it618_brand_goods['it618_salecount'],$tmpstr);
			$tmpstr=str_replace("{purl}",$tmpurl,$tmpstr);
			
			$content.=$tmpstr;
			
		}
	}elseif($modetype=='product_zj'||$modetype=='product_weekhot'){
		if($modetype=='product_zj'){	
			$query = DB::query("SELECT max(m.id) as maxid,m.it618_pid FROM ".DB::table('it618_brand_money')." m left join ".DB::table('it618_brand_goods')." g on m.it618_pid=g.id left join ".DB::table('it618_brand_brand')." b on g.it618_shopid=b.id where g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and m.it618_pid>0 and g.it618_ison=1 and g.it618_state=1 GROUP BY m.it618_pid ORDER BY maxid desc limit 0,".$modecount);
		}
		
		if($modetype=='product_weekhot'){
			$tomonth = date('n'); 
			$todate = date('j'); 
			$toyear = date('Y');
			$time=mktime(0, 0, 0, $tomonth, $todate-7, $toyear);
			$query = DB::query("SELECT m.it618_pid,count(1) as salecount FROM ".DB::table('it618_brand_money')." m left join ".DB::table('it618_brand_goods')." g on m.it618_pid=g.id left join ".DB::table('it618_brand_brand')." b on g.it618_shopid=b.id where g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and m.it618_pid>0 and m.it618_time>=$time GROUP BY m.it618_pid ORDER BY salecount desc limit 0,".$modecount);
		}
		
		while($it618_homegoods = DB::fetch($query)) {
			$it618_brand_goods=C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			$tmpstr=str_replace("{pname}",$it618_brand_goods['it618_name'],$tmparr1[0]);
			$tmpstr=str_replace("{ppicsrc}",it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']),$tmpstr);
			$tmpstr=str_replace("{puprice}",$it618_brand_goods['it618_uprice'],$tmpstr);
			$tmpstr=str_replace("{pprice}",$it618_brand_goods['it618_price'],$tmpstr);
			$tmpstr=str_replace("{pscore}",$it618_brand_goods['it618_score'],$tmpstr);
			$tmpstr=str_replace("{pcount}",$it618_brand_goods['it618_count'],$tmpstr);
			$tmpstr=str_replace("{pviews}",$it618_brand_goods['it618_views'],$tmpstr);
			$tmpstr=str_replace("{psalecount}",$it618_brand_goods['it618_salecount'],$tmpstr);
			$tmpstr=str_replace("{purl}",$tmpurl,$tmpstr);
			
			$content.=$tmpstr;
		}
	}elseif($modetype=='brand_new'||$modetype=='brand_hot'){
		if($modetype=='brand_new')$orderby='id desc';else $orderby='it618_moneysum desc';
		$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand')." where it618_state=2 and it618_htstate=1 order by $orderby limit 0,".$modecount);
		while($it618_brand_brand = DB::fetch($query)) {
			
			$tmpurl=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
			if($it618_brand_brand['it618_power']==0)$it618_power=it618_brand_getlang('s38');
			if($it618_brand_brand['it618_power']==1)$it618_power=it618_brand_getlang('s39');
		
			$tmpstr=str_replace("{bname}",$it618_brand_brand['it618_name'],$tmparr1[0]);
			$tmpstr=str_replace("{blogosrc}",$it618_brand_brand['it618_logo'],$tmpstr);
			$tmpstr=str_replace("{baddr}",$it618_brand_brand['it618_addr'],$tmpstr);
			$tmpstr=str_replace("{bdianhua}",$it618_brand_brand['it618_dianhua'],$tmpstr);
			$tmpstr=str_replace("{bshouji}",$it618_brand_brand['it618_shouji'],$tmpstr);
			$tmpstr=str_replace("{byouhui}",$it618_brand_brand['it618_youhui'],$tmpstr);
			$tmpstr=str_replace("{bpower}",$it618_power,$tmpstr);
			$tmpstr=str_replace("{burl}",$tmpurl,$tmpstr);
			
			$content.=$tmpstr;
			
		}
	}
	
	$content=$tmparr[0].$content.$tmparr1[1];
	$content=str_replace("{siteurl}",$_G['siteurl'],$content);
	
	return $content;
}

function str_substr($start, $end, $str)
{
    $temp = explode($start, $str, 2);
    $content = explode($end, $temp[1], 2);
    return $content[0];
} 

?>