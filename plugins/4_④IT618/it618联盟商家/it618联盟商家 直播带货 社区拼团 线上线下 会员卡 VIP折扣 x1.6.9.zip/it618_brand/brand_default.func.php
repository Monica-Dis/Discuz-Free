<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/brand_function.func.php';
global $getpaihang_shop,$getpaihang_user,$brandmode;

$brand_fwpower=(array)unserialize($it618_brand['brand_fwpower']);
if(!in_array("", $brand_fwpower)&&!in_array($_G['groupid'], $brand_fwpower)){
	echo $it618_brand_lang['s1486'].'<a href="'.$_G['siteurl'].'">'.$it618_brand_lang['s1487'].'</a>';
	exit;
}

$class1=intval($_GET['class1']);
if($pagetype=='search'){
	if($_GET['sw']==''||!isset($_GET['sw']))$searchsw=$it618_brand['brand_sw'];else $searchsw=dhtmlspecialchars($_GET['sw']);
}
if($searchsw!='')$sw=' style="display:none"';

$homeurl=it618_brand_getrewrite('brand_home','','plugin.php?id=it618_brand:index');
$shopsurl=it618_brand_getrewrite('brand_shops','','plugin.php?id=it618_brand:shops');
$productsurl=it618_brand_getrewrite('brand_products','','plugin.php?id=it618_brand:products');
$searchurl=it618_brand_getrewrite('brand_search','','plugin.php?id=it618_brand:search');

$brand_brandlogo=str_replace("{homeurl}",$homeurl,$it618_brand['brand_brandlogo']);

$brand_hotsw=explode(',',$it618_brand['brand_hotsw']);
for($i=0;$i<count($brand_hotsw);$i++){
	$tmpurl=it618_brand_getrewrite('brand_search','','plugin.php?id=it618_brand:search&sw='.urlencode($brand_hotsw[$i]),'?sw='.urlencode($brand_hotsw[$i]));
	$hotsw.='<a href="'.$tmpurl.'">'.$brand_hotsw[$i].'</a>';
}

$homebrandcount = C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1');

$hotclassbrand=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('hotclassbrand');
$hotclassbrand=explode('@@@',$hotclassbrand);

$topnav=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('topnav');
$brandfooter=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('brandfooter');

foreach(C::t('#it618_brand#it618_brand_focus')->fetch_all_by_type_order(16) as $it618_brand_focus) {
	if($it618_brand_focus['it618_url']!=''){
		$str_focus2.='<li><a href="'.$it618_brand_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="1200" height="63" /></a></li>';
	}else{
		$str_focus2.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="1200" height="63" /></li>';
	}
}

$waphome=it618_brand_getrewrite('brand_wap','','plugin.php?id=it618_brand:wap');

$metatitle=$it618_brand['brand_name'];
?>