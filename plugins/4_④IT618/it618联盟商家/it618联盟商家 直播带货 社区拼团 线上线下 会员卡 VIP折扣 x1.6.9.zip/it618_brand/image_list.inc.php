<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

$cid=intval($_GET['cid']);
if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','image_list@'.$ShopId.'@0@'.$cid.'@0','plugin.php?id=it618_brand:wap&pagetype=image_list&sid='.$ShopId.'&cid='.$cid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$subtitle=it618_brand_getlang('s545');
if(isset($_GET['cid']) && $_GET['cid']){
	$subtitle=C::t('#it618_brand#it618_brand_image_class')->fetch_it618_classname_by_id($_GET['cid']);
	if(!($it618_brand_image_class = C::t('#it618_brand#it618_brand_image_class')->fetch_by_id($cid))){
		echo it618_brand_getlang('s546');exit;
	}
	
	if($ShopId!=C::t('#it618_brand#it618_brand_image_class')->fetch_it618_shopid_by_id($cid)){
		echo it618_brand_getlang('s546');exit;
	}
}

$it618_brand_show = C::t('#it618_brand#it618_brand_show')->fetch_by_shopid_showid_showtype($ShopId,$cid,'image');
$ppp = $it618_brand_show['it618_pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$imagecount = C::t('#it618_brand#it618_brand_image')->count_by_shopid($ShopId, '', $cid);
$hrefsql=it618_brand_getrewrite('shop_imagelist',$ShopId.'@'.$cid.'@it618page','plugin.php?id=it618_brand:image_list&sid='.$ShopId.'&cid='.$cid);
$multipage = multi($imagecount, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_brand_multipage($multipage,$uri);
$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
if($ii1ill[5]!='_')return;

$n=1;
foreach(C::t('#it618_brand#it618_brand_image')->fetch_all_by_shopid(
	$ShopId, '', $cid,$startlimit,$ppp
) as $it618_brand_image) {
	if($n%4!=0){$noml=' noml';}else{$noml='';}
	
	$tmpurl=it618_brand_getrewrite('shop_image',$ShopId.'@'.$it618_brand_image['id'],'plugin.php?id=it618_brand:image&sid='.$ShopId.'&iid='.$it618_brand_image['id']);
	$str_image.='<li class="image'.$noml.'">
				  <h3>'.$it618_brand_image['it618_name'].'</h3>
				  <div class="info"">
				  <div class="pic">
				  <div class="pic_subwrap"><div class="pic_content"><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_brand_image['it618_smallurl'].'" /></a></div></div>
				  <div class="name"><a href="'.$tmpurl.'" target="_blank" class="a1">'.$it618_brand_image['it618_name'].'</a></div>
				  </div>
				  </li>';
	$n=$n+1;
}

if($multipage!='')$multipage='<div class="commonpage" style="margin-top:10px;">'.str_replace(" / ","/",$multipage).'</div>';

$tmparr=explode(":",$_GET['id']);
$pagetype=$tmparr[1];
$seotitle=$subtitle;
$seokeywords=$Shop_seokeywords;
$seodescription=$Shop_seodescription;
$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo; '.$subtitle;

$idforly=$cid;$idfornav=$cid;
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_nav.func.php';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:shop_default');
?>