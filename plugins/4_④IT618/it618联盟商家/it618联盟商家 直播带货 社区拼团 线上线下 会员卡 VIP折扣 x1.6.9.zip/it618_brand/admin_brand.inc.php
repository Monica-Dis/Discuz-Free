<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

if($reabc[4]!='8')return; /*Dism_taobao-com*/

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function/it618_brand.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier']; /*dism- taobao- com*/
$urls = '&pmod=admin_brand&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_brand', 'admin_brandgroup');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_brand' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_brand'.$urls.'"><span>'.$it618_brand_lang['s33'].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_brandgroup'.$urls.'"><span>'.$it618_brand_lang['s1620'].'</span></a></li>
</ul></div>';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism·taobao·com*/
?>