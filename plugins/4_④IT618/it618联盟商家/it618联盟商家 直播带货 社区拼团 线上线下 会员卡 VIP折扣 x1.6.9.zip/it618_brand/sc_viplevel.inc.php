<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if($Shop_isuservip==0){
	it618_cpmsg($it618_brand_lang['s1644'], '', 'error');
}

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_brand#it618_brand_viplevel')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_money1'])) {
		foreach($_GET['it618_money1'] as $id => $val) {
			
			if(floatval($_GET['it618_zk'][$id])>0&&floatval($_GET['it618_zk'][$id])<100){
				C::t('#it618_brand#it618_brand_viplevel')->update($id,array(
					'it618_money1' => $_GET['it618_money1'][$id],
					'it618_money2' => $_GET['it618_money2'][$id],
					'it618_zk' => $_GET['it618_zk'][$id],
				));
				$ok1=$ok1+1;
			}
		}
	}

	$newit618_level_array = !empty($_GET['newit618_level']) ? $_GET['newit618_level'] : array();
	$newit618_money1_array = !empty($_GET['newit618_money1']) ? $_GET['newit618_money1'] : array();
	$newit618_money2_array = !empty($_GET['newit618_money2']) ? $_GET['newit618_money2'] : array();
	$newit618_zk_array = !empty($_GET['newit618_zk']) ? $_GET['newit618_zk'] : array();
	
	foreach($newit618_level_array as $key => $value) {
		$newit618_level = trim($newit618_level_array[$key]);
		
		if($newit618_level != '') {
			$count=C::t('#it618_brand#it618_brand_viplevel')->count_by_shopid_level($ShopId,$newit618_level_array[$key]);
			if($count==0&&floatval($newit618_zk_array[$key])>0&&floatval($newit618_zk_array[$key])<100){
				C::t('#it618_brand#it618_brand_viplevel')->insert(array(
					'it618_shopid' => $ShopId,
					'it618_level' => $newit618_level_array[$key],
					'it618_money1' => $newit618_money1_array[$key],
					'it618_money2' => $newit618_money2_array[$key],
					'it618_zk' => $newit618_zk_array[$key],
				), true);
				$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
			}
		}
	}

	it618_cpmsg(it618_brand_getlang('s5').$ok1.' '.it618_brand_getlang('s6').$ok2.' '.it618_brand_getlang('s7').$del, "plugin.php?id=it618_brand:sc_viplevel$adminsid&page=$page", 'succeed');
}

for($i=1;$i<=8;$i++){
	$levelstr.='<option value="'.$i.'">VIP'.$i.'</option>';
}

it618_showformheader("plugin.php?id=it618_brand:sc_viplevel$adminsid&page=$page");
showtableheaders(it618_brand_getlang('s1402'),'it618_brand_viplevel');
	$count = C::t('#it618_brand#it618_brand_viplevel')->count_by_shopid($ShopId);
	
	echo '<tr><td colspan=6>'.it618_brand_getlang('s1403').$count.'<span style="color:red;float:right">'.it618_brand_getlang('s1409').'</span></td></tr>';
	showsubtitle(array('', it618_brand_getlang('s1404'), it618_brand_getlang('s1405'), it618_brand_getlang('s1406'),it618_brand_getlang('s1407'),it618_brand_getlang('s1408')));

	foreach(C::t('#it618_brand#it618_brand_viplevel')->fetch_all_by_shopid($ShopId) as $it618_brand_viplevel) {
		
		$vipcount=C::t('#it618_brand#it618_brand_cardmoney')->count_by_shopid_money($ShopId,$it618_brand_viplevel['it618_money1'],$it618_brand_viplevel['it618_money2']);
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_brand_viplevel[id]\" $disabled>",
			'<font color=red>VIP'.$it618_brand_viplevel['it618_level'].'</font>',
			'<input class="txt" type="text" style="color:blue;margin-right:3px" name="it618_money1['.$it618_brand_viplevel['id'].']" value="'.$it618_brand_viplevel['it618_money1'].'">'.it618_brand_getlang('s389'),
			'<input class="txt" type="text" style="color:blue;margin-right:3px" name="it618_money2['.$it618_brand_viplevel['id'].']" value="'.$it618_brand_viplevel['it618_money2'].'">'.it618_brand_getlang('s389'),
			'<input class="txt" type="text" style="color:green;font-weight:bold;margin-right:3px" name="it618_zk['.$it618_brand_viplevel['id'].']" value="'.$it618_brand_viplevel['it618_zk'].'">%',
			$vipcount
		));
	}
	
	$s389=it618_brand_getlang('s389');
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_level[]").length;
	
		return [
		[[1,''], [1,'<select name="newit618_level[]">{$levelstr}</select>'], [1, ' <input class="txt" type="text" style="color:blue;margin-right:3px" name="newit618_money1[]">{$s389}'], [1, ' <input class="txt" type="text" style="color:blue;margin-right:3px" name="newit618_money2[]">{$s389}'], [1, ' <input class="txt" type="text" style="color:green;font-weight:bold;margin-right:3px" name="newit618_zk[]">%'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="6"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.it618_brand_getlang('s128').'</a></div></td></tr>';
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_brand_getlang('s129').'</label></td><td colspan="4"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_brand_getlang('s120').'"/> <font color=green>'.it618_brand_getlang('s1410').'</font></div></td></tr>';
showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>