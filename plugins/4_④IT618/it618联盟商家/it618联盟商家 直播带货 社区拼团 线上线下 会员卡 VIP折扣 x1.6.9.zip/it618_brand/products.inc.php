<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/brand_default.func.php';

if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','','plugin.php?id=it618_brand:wap');
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

foreach(C::t('#it618_brand#it618_brand_brand_area')->fetch_all_by_search() as $it618_tmp) {
	$areatmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

foreach(C::t('#it618_brand#it618_brand_brand_class')->fetch_all_by_search() as $it618_tmp) {
	$classtmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

foreach(C::t('#it618_brand#it618_brand_brand_area1')->fetch_all_by_it618_area_id($it618_brand_brand['it618_area_id']) as $it618_tmp) {
	$areatmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

foreach(C::t('#it618_brand#it618_brand_brand_class1')->fetch_all_by_it618_class_id($it618_brand_brand['it618_class_id']) as $it618_tmp) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_brand_area'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_area')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_area1')." where it618_area_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_area['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_name'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

$selectstr='
<script>
var arrcount='.$count.';
var select_area = new Array(arrcount+1);

for (i=0; i<arrcount+1; i++) 
{
 select_area[i] = new Array();
}

'.$tmp1.'

function redirec_area(x)
{
 var temp = document.getElementById("it618_area1"); 
 temp.options.length=1;
 for (i=1;i<select_area[x].length;i++)
 {
  temp.options[i]=new Option(select_area[x][i].text,select_area[x][i].value);
 }
 temp.options[0].selected=true;

}

</script>';

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_brand_class'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

$selectstr.='
<script>
var arrcount='.$count.';
var select_class = new Array(arrcount+1);

for (i=0; i<arrcount; i++) 
{
 select_class[i] = new Array();
}

'.$tmp1.'

function redirec_class(x)
{
 var temp = document.getElementById("it618_class1"); 
 temp.options.length=1;
 for (i=1;i<select_class[x].length;i++)
 {
  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
 }
 temp.options[0].selected=true;

}

</script>';

foreach(C::t('#it618_brand#it618_brand_focus')->fetch_all_by_type_order(19) as $it618_brand_focus) {
	if($it618_brand_focus['it618_url']!=''){
		$str_focus5.='<li><a href="'.$it618_brand_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus5.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

$str_goodslist=getgoodslist();

getpaihang();


$metatitle=it618_brand_getlang('s877').' - '.$metatitle;

$pagetype='products';
$currentnavproducts=' class="current"';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:brand_default');
?>