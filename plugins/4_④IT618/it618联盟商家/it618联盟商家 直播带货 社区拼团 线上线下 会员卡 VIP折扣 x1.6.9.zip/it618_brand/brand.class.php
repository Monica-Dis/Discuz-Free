<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_brand_forum {
	
	function viewthread_sidebottom_output(){
		global $_G,$postlist;
		$it618_brand = $_G['cache']['plugin']['it618_brand'];
		if($it618_brand['brand_islogo']==1){
			$viewthread_sidebottom=array();
			foreach($postlist as $id => $post){
				
				$brand_leftad='';
				if($it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($post['authorid'])){
					if($it618_brand_brand['it618_state']==2&&$it618_brand_brand['it618_htstate']==1){
						
						if($_G['cache']['plugin']['it618_brand']['rewriteurl']==0){
							$tmpurl='plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id'];
						}else{
							$tmpurl='shop-'.$it618_brand_brand['id'].'.html';
						}
		
						$brand_leftad='<a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_brand_brand['it618_logo'].'" style="margin-left:15px;margin-bottom:10px" width="130" /></a>';
					}
				}
	
				$viewthread_sidebottom[]=$brand_leftad;
	
			}
	
			return $viewthread_sidebottom;
		}
	}

}

class plugin_it618_brand{
	
	function common() {

	}
	
	function global_header(){

		foreach(C::t('#it618_brand#it618_brand_diy')->fetch_all_by_search() as $it618_brand_diy) {

			$blockcount=C::t('#it618_brand#it618_brand_sale')->count_by_name($it618_brand_diy["it618_name"]);
			if($blockcount>0){
				if((time()-$it618_brand_diy["it618_time"])<(60*$it618_brand_diy["it618_catchtime"])){
					continue;
				}else{
					C::t('#it618_brand#it618_brand_diy')->update_it618_time_by_id(time(),$it618_brand_diy["id"]);
				}
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_brand/getmode.func.php';
				$content=it618_brand_getmodecontent($it618_brand_diy['it618_type'],$it618_brand_diy['it618_modecode'],$it618_brand_diy['it618_count']);
				C::t('#it618_brand#it618_brand_sale')->update_summary_dateline_by_name($content,time(),$it618_brand_diy["it618_name"]);
			}
		}
		
	}

}
//From: Dism��taobao��com
?>