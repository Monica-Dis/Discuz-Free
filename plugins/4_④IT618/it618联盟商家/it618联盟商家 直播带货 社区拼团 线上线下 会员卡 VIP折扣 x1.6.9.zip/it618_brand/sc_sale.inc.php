<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if($Shop_isgoods==0){
	it618_cpmsg($it618_brand_lang['s1640'], '', 'error');
}

echo '
<script charset="utf-8" src="source/plugin/it618_brand/js/Calendar.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/js/jquery.js"></script>

<script>
var dialog_sale,dialog_kd,dialog_bz,dialog_tui;
KindEditor.ready(function(K) {K(\'#checkfahuo\').click(function() {
	IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:showfahuo'.$adminsid.'&sid='.$ShopId.'&formhash='.FORMHASH.'", {ac:"it618"},function (data, textStatus){
	dialog_sale = K.dialog({
		width : 550,
		title : \''.it618_brand_getlang('s1106').'\',
		body : \'<div style="padding:5px">\'+data+\'</div>\',
		closeBtn : {
			name : \''.it618_brand_getlang('s1107').'\',
			click : function(e) {
				dialog_sale.remove();
			}
		}
	});
	document.getElementById("code").focus();
	}, "html");	
});});

function read(){
	var code=document.getElementById("code").value;
	if(code==""){
		sendmsg(\'saletips\',"'.it618_brand_getlang('s1108').'");
		return false;
	}
	
	document.getElementById("btn_fahuo").style.display="none";
	document.getElementById("whatsale").innerHTML="";
	
	IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax'.$adminsid.'&sid='.$ShopId.'&code="+code+"&formhash='.FORMHASH.'", {ac:"checkcode"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		document.getElementById("whatsale").innerHTML=tmparr[1];
		document.getElementById("btn_fahuo").style.display="";
	}else{
		sendmsg(\'saletips\',tmparr[1]);
	}
	}, "html");

}

function fahuo(){
	var saleid=document.getElementById("saleid").value;
	IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax'.$adminsid.'&sid='.$ShopId.'&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"fahuo"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		document.getElementById("whatsale").innerHTML="";
		sendmsg(\'saletips\',tmparr[1]);
		document.getElementById("btn_fahuo").style.display="none";
		document.getElementById("code").value="";
		document.getElementById("code").focus();
		getsalelist(saleurl);
	}else{
		sendmsg(\'saletips\',tmparr[1]);
	}
	}, "html");

}

function savekd(){
	var saleid=document.getElementById("saleid").value;
	var it618_kdid=document.getElementById("it618_kdid").value;
	var it618_kdid=it618_kdid.replace("selected=selected","");
	var it618_kddan=document.getElementById("it618_kddan").value;
	if(it618_kdid==0){
		sendmsg(\'kdtips\',\''.it618_brand_getlang('s1109').'\');
		return;
	}
	if(it618_kddan==""){
		sendmsg(\'kdtips\',\''.it618_brand_getlang('s1110').'\');
		return;
	}
	
	IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax'.$adminsid.'&sid='.$ShopId.'&saleid="+saleid+"&it618_kdid="+it618_kdid+"&it618_kddan="+it618_kddan+"&formhash='.FORMHASH.'", {ac:"savekd"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		alert(tmparr[1]);
		getsalelist(saleurl);
		dialog_kd.remove();
	}else{
		sendmsg(\'kdtips\',tmparr[1]);
	}
	}, "html");

}

function tongyitui(saleid){
	if(confirm("'.it618_brand_getlang('s1111').'")){
		IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax'.$adminsid.'&sid='.$ShopId.'&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"tongyitui"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function jujuetui(saleid){
	if(confirm("'.it618_brand_getlang('s1112').'")){
		IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax'.$adminsid.'&sid='.$ShopId.'&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"jujuetui"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

var dialog_salekm,salekmid=0;
KindEditor.ready(function(K) {K(\'#salekm\').click(function() {
	getsalekm(K);
});});

function setsalekm(saleid){
	if(salekmid==0){
		salekmid=saleid;
		IT618_BRAND("#salekm").click();
	}
}

function getsalekm(K){
IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:salekm"+"&saleid="+salekmid, {ac:"shop"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	dialog_salekm = K.dialog({
		width : 620,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.$it618_brand_lang['t571'].'\',
			click : function(e) {
				dialog_salekm.remove();
				salekmid=0;
			}
		}
	});
	
	}, "html");		
}

var dialog_salebz,salebzid=0;
KindEditor.ready(function(K) {K(\'#salebz\').click(function() {
	getsalebz(K);
});});

function setsalebz(saleid){
	if(salebzid==0){
		salebzid=saleid;
		IT618_BRAND("#salebz").click();
	}
}

function getsalebz(K){
IT618_BRAND.get("'.$_G['siteurl'].'plugin.php?id=it618_brand:salebz"+"&saleid="+salebzid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	dialog_salebz = K.dialog({
		width : 520,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.$it618_brand_lang['s1107'].'\',
			click : function(e) {
				dialog_salebz.remove();
				salebzid=0;
			}
		}
	});
	
	IT618_BRAND(\'.ns-sub-a\').click(function(){
		
		if(it618_content=document.getElementById("bzvalue").value==\'\'){
			alert("'.$it618_brand_lang['s1838'].'");
			return;
		}

		IT618_BRAND.post("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax'.$adminsid.'&sid='.$ShopId.'"+"&ac=salebz&saleid="+salebzid+"&formhash='.FORMHASH.'",IT618_BRAND("#it618_salebz").serialize(),function (data, textStatus){
			var tmparr=data.split("it618_split");
		
			if(tmparr[0]=="ok"){
				alert(tmparr[1]);
				dialog_salebz.remove();
				getsalelist(saleurl);
				salebzid=0;
			}else{
				alert(data);
			}
		}, "html");
	})
	
	IT618_BRAND(\'.ns-sub-b\').click(function(){
		dialog_salebz.remove();
		salebzid=0;
	})
	
	}, "html");		
}

function sendmsg(msgid,msgvalue){
	document.getElementById(msgid).innerHTML=msgvalue;
	setTimeout(\'sendmsg1("\'+msgid+\'")\',8000);
}
function sendmsg1(msgid){
	document.getElementById(msgid).innerHTML="";
}
</script>
';

showtableheaders(it618_brand_getlang('s1113'),'it618_brand_sum');

	if($Shop_issaletype1==1)$tmpstr='<a href="javascript:" id="checkfahuo" style="float:right;border:none; background-color:#F60; color:#fff; padding-left:23px; padding-right:23px; height:26px;padding-top:8px;font-size:15px;margin-top:11px;">'.it618_brand_getlang('s1034').'</a><span id="salebz"></span><span id="salekm"></span>';
	echo '<tr><td colspan="15"><div class="fixsel">'.$tmpstr.it618_brand_getlang('s1114').' <input id="pname" class="txt" style="width:231px;margin-right:1px" /> '.it618_brand_getlang('s1115').' <input id="finduid" class="txt" style="width:76px" /><br> '.$it618_brand_lang['s598'].' <select id="paytype"><option value=0>'.it618_brand_getlang('s874').'</option><option value=1>'.it618_brand_getlang('s300').'</option><option value=2>'.it618_brand_getlang('t476').'</option></select> '.it618_brand_getlang('s1116').' <select id="state"><option value=0>'.it618_brand_getlang('s1117').'</option><option value=1 style="color:red">'.it618_brand_getlang('s1118').'</option><option value=2 style="color:green">'.it618_brand_getlang('s1119').'</option><option value=3 style="color:blue">'.it618_brand_getlang('s1120').'</option><option value=4 style="color:purple">'.it618_brand_getlang('s1121').'</option></select> '.it618_brand_getlang('s1122').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/><input type="button" class="btn" value="'.it618_brand_getlang('s1123').'" onclick="findsalelist()" /> <input type="button" class="btn" value="'.it618_brand_getlang('s1667').'" onclick="dao()" /></div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>
	<tr><th width=50>'.it618_brand_getlang('s1124').'</th><th>'.it618_brand_getlang('s1125').'</th><th>'.it618_brand_getlang('s1126').'</th><th>'.it618_brand_getlang('s1127').'</th><th>'.it618_brand_getlang('s1128').'</th><th>'.it618_brand_getlang('s1129').'</th><th>'.it618_brand_getlang('s1130').'</th><th>'.it618_brand_getlang('s1131').'</th><th width=80>'.it618_brand_getlang('s1132').'</th></tr>';
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_brand/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr>';

showtablefooter(); /*dism��taobao��com*/
echo '
<script>
var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax";
var sqlurl="";
function getsalelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_BRAND.get(url+sqlurl+"'.$adminsid.'&sid='.$ShopId.'&formhash='.FORMHASH.'", {ac:"sale_get",ac1:"pcsale"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_BRAND("#tr_salesum").html(tmparr[0]);
	IT618_BRAND("#tr_salelist").html(tmparr[1]);
	IT618_BRAND("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
getsalelist(saleurl);

function findsalelist(){
	var pname = document.getElementById("pname").value;
	var finduid = document.getElementById("finduid").value;
	var paytype = document.getElementById("paytype").value;
	var state = document.getElementById("state").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&pname="+pname+"&finduid="+finduid+"&paytype="+paytype+"&state="+state+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax";
	getsalelist(url);
}

function dao(){
	findsalelist();
	IT618_BRAND.get(saleurl+sqlurl+"'.$adminsid.'&sid='.$ShopId.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_dao"},function (data, textStatus){
	window.open(data);
	}, "html");	
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>