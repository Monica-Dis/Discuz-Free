<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_default.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

$it618_members = $_G['cache']['plugin']['it618_members'];

if(isset($_GET['adminsid'])){
	$adminshop='<span style="color:red;font-size:13px">('.it618_brand_getlang('s1221').')</span>';
}

$pcount=C::t('#it618_brand#it618_brand_goods')->count_by_shopid($ShopId);
$articlecount=C::t('#it618_brand#it618_brand_article')->count_by_shopid($ShopId);
$articlecount1=C::t('#it618_brand#it618_brand_onepage')->count_by_shopid($ShopId);
$articlecount=$articlecount+$articlecount1;
$imagecount=C::t('#it618_brand#it618_brand_image')->count_by_shopid($ShopId);

$config_path=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/';

$allsize = it618_brand_dirsize($config_path); 
$allsize = $allsize/1024/1024; 

if($Shop_filespace-$allsize>0){
	$oksize=sprintf("%.2f", ($Shop_filespace-$allsize));
}else{
	$oksize=0;
}

if($Shop_isgoods==1){
	$pcountstr=it618_brand_getlang('s1386').'<font color="red"><b>'.$pcount.'</b></font> <font color="#ccc">|</font> ';
}

it618_brand_getshopmoney($ShopId);

$filespacestr=$pcountstr.it618_brand_getlang('s1387').'<font color="red"><b>'.$articlecount.'</b></font> <font color="#ccc">|</font> '.it618_brand_getlang('s1388').'<font color="red"><b>'.$imagecount.'</b></font> <font color="#ccc">|</font> '.it618_brand_getlang('s1389').'<font color="red"><b>'.$Shop_filespace.'</b></font> M'.it618_brand_getlang('s1390').'<font color="green"><b>'.$oksize.'</b></font> M';

$urltmp='member.php?mod=logging&action=logout&formhash='.FORMHASH;

$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:sc/sc_top');
?>