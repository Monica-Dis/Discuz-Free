<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$oss,$ShopType,$ShopId,$adminsid;

$it618_brand = $_G['cache']['plugin']['it618_brand'];

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/brand_default.func.php';

if($_G['uid']<=0){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		if(!brand_is_mobile()){ 
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
			$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','','winapilogin');
			echo '<script type="text/javascript" src="source/plugin/it618_brand/js/jquery.js"></script>'.$it618_members_index;exit;
		}
	}
	
	dheader("location:member.php?mod=logging&action=login");
}else{
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/php/aliyunossconfig.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/php/aliyunossconfig.php';
		if($it618_isok==1){
			$oss='&oss';
		}
	}
	
	if(isset($_GET['adminsid'])){
		$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$adminsid='&adminsid='.$_GET['adminsid'];
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['adminsid']);
				
			$it618_state=$it618_brand_brand['it618_state'];
			if($it618_state==0){
				echo it618_brand_getlang('s172');exit;
			}elseif($it618_state==1){
				echo it618_brand_getlang('s173');exit;
			}else{
				$it618_htstate=$it618_brand_brand['it618_htstate'];
				if($it618_htstate==0){
					echo it618_brand_getlang('s174');exit;
				}elseif($it618_htstate==2){
					echo it618_brand_getlang('s175');exit;
				}else{
					$ShopId=$it618_brand_brand['id'];
					$ShopUid=$it618_brand_brand['it618_uid'];
					$ShopName=$it618_brand_brand['it618_name'];
					$ShopMoney=$it618_brand_brand['it618_money'];
					$ShopJfBl=$it618_brand_brand['it618_jfbl'];
					$ShopSCORE=$it618_brand_brand['it618_score'];
					$ShopUPRICE=$it618_brand_brand['it618_uprice'];
					$Shop_power=$it618_brand_brand['it618_power'];
					$Shop_isgoodscheck=$it618_brand_brand['it618_isgoodscheck'];
					$Shop_isgoodssafe=$it618_brand_brand['it618_isgoodssafe'];
					$Shop_isgoodsclass=$it618_brand_brand['it618_isgoodsclass'];
					$Shop_txtype=$it618_brand_brand['it618_txtype'];
					$Shop_isyunfeikg=$it618_brand_brand['it618_isyunfeikg'];
					$Shop_filespace=$it618_brand_brand['it618_filespace'];
					
					$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
					$ShopPower=$it618_brand_brandgroup['it618_groupname'];
					if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" align="absmiddle" style="margin-top:-1px"/>';
					
					$Shop_isgoods=$it618_brand_brandgroup['it618_isgoods'];
					$Shop_goodscount=$it618_brand_brandgroup['it618_goodscount'];
					$Shop_issaletype1=$it618_brand_brandgroup['it618_issaletype1'];
					$Shop_issaletype2=$it618_brand_brandgroup['it618_issaletype2'];
					$Shop_issaletype3=$it618_brand_brandgroup['it618_issaletype3'];
					$Shop_issaletype4=$it618_brand_brandgroup['it618_issaletype4'];
					$Shop_issaletype5=$it618_brand_brandgroup['it618_issaletype5'];
					$Shop_ispaytype1=$it618_brand_brandgroup['it618_ispaytype1'];
					$Shop_ispaytype2=$it618_brand_brandgroup['it618_ispaytype2'];
					$Shop_isorder=$it618_brand_brandgroup['it618_isorder'];
					$Shop_islive=$it618_brand_brandgroup['it618_islive'];
					$Shop_issaleout=$it618_brand_brandgroup['it618_issaleout'];
					$Shop_isuservip=$it618_brand_brandgroup['it618_isuservip'];
					
					$Shop_isbrandnav=$it618_brand_brand['it618_isbrandnav'];
					
					$Shop_systemcount=$it618_brand_brand['it618_systemcount'];
				}
			}
		}else{
			echo it618_brand_getlang('s1220');exit;	
		}
	}else{
		$username=C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($_G['uid']);
		if(C::t('#it618_brand#it618_brand_brand')->count_by_it618_uid($_G['uid'])>0){
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($_G['uid']);
				
			$it618_state=$it618_brand_brand['it618_state'];
			if($it618_state==0){
				echo it618_brand_getlang('s172');exit;
			}elseif($it618_state==1){
				echo it618_brand_getlang('s173');exit;
			}else{
				$it618_htstate=$it618_brand_brand['it618_htstate'];
				if($it618_htstate==0){
					echo it618_brand_getlang('s174');exit;
				}elseif($it618_htstate==2){
					echo it618_brand_getlang('s175');exit;
				}else{
					$ShopId=$it618_brand_brand['id'];
					$ShopUid=$it618_brand_brand['it618_uid'];
					$ShopName=$it618_brand_brand['it618_name'];
					$ShopMoney=$it618_brand_brand['it618_money'];
					$ShopJfBl=$it618_brand_brand['it618_jfbl'];
					$ShopSCORE=$it618_brand_brand['it618_score'];
					$ShopUPRICE=$it618_brand_brand['it618_uprice'];
					$Shop_power=$it618_brand_brand['it618_power'];
					$Shop_isgoodscheck=$it618_brand_brand['it618_isgoodscheck'];
					$Shop_isgoodssafe=$it618_brand_brand['it618_isgoodssafe'];
					$Shop_isgoodsclass=$it618_brand_brand['it618_isgoodsclass'];
					$Shop_txtype=$it618_brand_brand['it618_txtype'];
					$Shop_isyunfeikg=$it618_brand_brand['it618_isyunfeikg'];
					$Shop_filespace=$it618_brand_brand['it618_filespace'];
					
					$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
					$ShopPower=$it618_brand_brandgroup['it618_groupname'];
					if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" align="absmiddle" style="margin-top:-1px"/>';
					
					$Shop_isgoods=$it618_brand_brandgroup['it618_isgoods'];
					$Shop_goodscount=$it618_brand_brandgroup['it618_goodscount'];
					$Shop_issaletype1=$it618_brand_brandgroup['it618_issaletype1'];
					$Shop_issaletype2=$it618_brand_brandgroup['it618_issaletype2'];
					$Shop_issaletype3=$it618_brand_brandgroup['it618_issaletype3'];
					$Shop_issaletype4=$it618_brand_brandgroup['it618_issaletype4'];
					$Shop_issaletype5=$it618_brand_brandgroup['it618_issaletype5'];
					$Shop_ispaytype1=$it618_brand_brandgroup['it618_ispaytype1'];
					$Shop_ispaytype2=$it618_brand_brandgroup['it618_ispaytype2'];
					$Shop_isorder=$it618_brand_brandgroup['it618_isorder'];
					$Shop_islive=$it618_brand_brandgroup['it618_islive'];
					$Shop_issaleout=$it618_brand_brandgroup['it618_issaleout'];
					$Shop_isuservip=$it618_brand_brandgroup['it618_isuservip'];
					
					$Shop_isbrandnav=$it618_brand_brand['it618_isbrandnav'];
					
					$Shop_systemcount=$it618_brand_brand['it618_systemcount'];
				}
			}
			
		}
	}
}
//From: Dism��taobao��com
?>