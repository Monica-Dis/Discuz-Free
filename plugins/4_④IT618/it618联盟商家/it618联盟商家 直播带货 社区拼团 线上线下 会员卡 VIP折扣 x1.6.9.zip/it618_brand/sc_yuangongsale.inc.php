<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);

it618_showformheader("plugin.php?id=it618_brand:sc_yuangongsale$adminsid");
showtableheaders(it618_brand_getlang('t756'),'it618_brand_yuangongsale');

	echo '<tr><td colspan=14>'.it618_brand_getlang('s1791').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_brand_getlang('s1786').' <input name="uid" value="'.$_GET['uid'].'" class="txt" style="width:80px" /> '.it618_brand_getlang('s1787').' <input name="saleid" value="'.$_GET['saleid'].'" class="txt" style="width:80px" />&nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_brand_getlang('s34').'" /></td></tr>';
	
	$count = C::t('#it618_brand#it618_brand_yuangongsale')->count_by_shopid($ShopId,'','',$_GET['key'],$_GET['uid'],$_GET['saleid']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_brand:sc_product$adminsid".$urlsql);
	
	echo '<tr><td colspan=10>'.it618_brand_getlang('s1790').$count.'</td></tr>';
	showsubtitle(array('', it618_brand_getlang('s1785'), it618_brand_getlang('s1786'),it618_brand_getlang('s1787'),it618_brand_getlang('s1788'),it618_brand_getlang('s1789')));
	
	foreach(C::t('#it618_brand#it618_brand_yuangongsale')->fetch_all_by_shopid(
		$ShopId,'','id desc',$_GET['key'],$_GET['uid'],$_GET['saleid'],$startlimit,$ppp
	) as $it618_brand_yuangongsale) {
		
		$name=C::t('#it618_brand#it618_brand_yuangong')->fetch_name_by_uid_shopid($it618_brand_yuangongsale['it618_uid'],$ShopId);
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			$it618_brand_yuangongsale['id'],
			$name,
			'<a href="'.it618_brand_rewriteurl($it618_brand_yuangongsale['it618_uid']).'" target="_blank">'.it618_brand_getusername($it618_brand_yuangongsale['it618_uid']).'</a>',
			$it618_brand_yuangongsale['it618_saleid'],
			$it618_brand_yuangongsale['it618_bz'],
			date('Y-m-d H:i:s', $it618_brand_yuangongsale['it618_time'])
		));
	}
	
echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>