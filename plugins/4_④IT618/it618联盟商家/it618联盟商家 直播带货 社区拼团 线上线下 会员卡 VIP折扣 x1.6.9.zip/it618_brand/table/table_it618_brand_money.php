<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_brand_money extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_brand_money';
		$this->_pk = 'id';
		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function count_by_saleid($saleid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_saleid=%d", array($this->_table, $saleid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_saleid($saleid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_saleid=%d", array($this->_table, $saleid));
	}
	
	public function fetch_by_uid_pid($uid, $pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d AND it618_pid=%d", array($this->_table, $uid, $pid));
	}
	
	public function fetch_by_uid_shopid_type1($uid, $shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_type=1 and it618_uid=%d AND it618_shopid=%d", array($this->_table, $uid, $shopid));
	}
	
	public function fetch_all_by_search($start = 0, $limit = 0) {
		return DB::fetch_all("SELECT * FROM %t ORDER BY id DESC".DB::limit($start, $limit), array($this->_table));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_saleid($saleid) {
		DB::query("DELETE FROM %t WHERE it618_saleid=%d", array($this->_table, $saleid));
	}
	
	public function update_it618_state($saleid,$it618_state) {
		DB::query("UPDATE %t SET it618_state=%d WHERE it618_saleid=%d", array($this->_table, $it618_state, $saleid));
	}
	
	public function fetch_paihang_by_cjje($count) {
		return DB::fetch_all("SELECT sum(it618_money) as it618_moneysum,it618_shopid FROM %t WHERE it618_shopid<>0 GROUP BY it618_shopid ORDER BY it618_moneysum DESC".DB::limit(0, $count), array($this->_table));
	}
	
	public function count_by_shopid($it618_shopid = 0, $it618_pid = 0, $it618_type = 0, $it618_state = 0, $it618_uid = 0, $it618_saleuid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618_pid, $it618_type, $it618_state, $it618_uid, $it618_saleuid, $it618_time1, $it618_time2);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function sum_by_shopid($it618_shopid = 0, $it618_pid = 0, $it618_type = 0, $it618_state = 0, $it618_uid = 0, $it618_saleuid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618_pid, $it618_type, $it618_state, $it618_uid, $it618_saleuid, $it618_time1, $it618_time2);
		if($it618_type==2){
			$tmp= DB::result_first("SELECT SUM(it618_score) FROM %t $condition[0]", $condition[1]);
		}else{
			$tmp= DB::result_first("SELECT SUM(it618_money) FROM %t $condition[0]", $condition[1]);
		}
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function sum_it618_score_by_shopid($it618_shopid = 0, $it618_pid = 0, $it618_type = 0, $it618_state = 0, $it618_uid = 0, $it618_saleuid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618_pid, $it618_type, $it618_state, $it618_uid, $it618_saleuid, $it618_time1, $it618_time2);
		$tmp= DB::result_first("SELECT SUM(it618_score) FROM %t $condition[0]", $condition[1]);
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function fetch_all_by_shopid($it618_shopid = 0, $it618_pid = 0, $it618_type = 0, $it618_state = 0, $it618_uid = 0, $it618_saleuid = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618_pid, $it618_type, $it618_state, $it618_uid, $it618_saleuid, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0] ORDER BY id DESC".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shopid = 0, $it618_pid = 0, $it618_type = 0, $it618_state = 0, $it618_uid = 0, $it618_saleuid = 0, $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();

		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($it618_pid)) {
			$parameter[] = $it618_pid;
			$wherearr[] = 'it618_pid=%d';
		}
		if(!empty($it618_type)) {
			$parameter[] = $it618_type;
			$wherearr[] = 'it618_type=%d';
		}
		if(!empty($it618_state)) {
			$parameter[] = $it618_state;
			$wherearr[] = 'it618_state=%d';
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($it618_saleuid)) {
			$parameter[] = $it618_saleuid;
			$wherearr[] = 'it618_saleuid=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 'it618_time>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 'it618_time<=unix_timestamp(%s)';
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}

}
//From: di'.'sm.t'.'aoba'.'o.com
?>