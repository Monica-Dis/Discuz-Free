<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_brand_visitall extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_brand_visitall';
		$this->_pk = 'id';
		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	
	public function count_by_shopid_it618_time($it618_shopid,$it618_time=0) {
		if(!empty($it618_time)) {
			return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d AND it618_time=%d", array($this->_table,$it618_shopid,$it618_time));
		}else{
			return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table,$it618_shopid));
		}
	}
	
	public function count_by_shopid_it618_uid($it618_shopid,$it618_uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d AND it618_uid=%d", array($this->_table,$it618_shopid,$it618_uid));
	}
	
	public function update_it618_time_by_shopid_it618_uid($it618_shopid,$it618_time,$it618_uid) {
		return DB::query("UPDATE %t SET it618_time=%d WHERE it618_shopid=%d AND it618_uid=%d", array($this->_table,$it618_time,$it618_shopid,$it618_uid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_all_by_shopid($it618_shopid,$limit) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_shopid=%d ORDER BY it618_time DESC LIMIT 0, %d", array($this->_table,$it618_shopid,$limit));
	}
	
	public function fetch_all_by_shopid1($it618_shopid,$start = 0, $limit = 0) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_shopid=%d ORDER BY it618_time DESC LIMIT %d, %d", array($this->_table,$it618_shopid,$start,$limit));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>