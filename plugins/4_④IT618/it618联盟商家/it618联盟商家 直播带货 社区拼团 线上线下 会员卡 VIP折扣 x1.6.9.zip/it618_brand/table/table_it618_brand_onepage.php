<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_brand_onepage extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_brand_onepage';
		$this->_pk = 'id';
		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function fetch_it618_shopid_by_id($id) {
		return DB::result_first("SELECT it618_shopid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_search() {
		return DB::fetch_first("SELECT * FROM %t", array($this->_table));
	}
	
	public function fetch_all_by_shopid_wap($it618_shopid = 0) {
		$query = DB::query("SELECT * FROM %t WHERE it618_shopid=%d AND it618_wap=1 ORDER BY it618_order", array($this->_table, $it618_shopid));
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	public function fetch_all_by_shopid_waphome($it618_shopid = 0) {
		$query = DB::query("SELECT * FROM %t WHERE it618_shopid=%d AND it618_waphome=1 ORDER BY it618_order", array($this->_table, $it618_shopid));
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_shopid($it618_shopid = 0, $it618_name = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618_name);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_shopid($it618_shopid = 0, $it618_name = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618_name);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shopid = 0, $it618_name = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "it618_name LIKE %s";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function update_it618_views_by_id($id) {
		DB::query("UPDATE %t SET it618_views=it618_views+1 WHERE id=%d", array($this->_table, $id));
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>