<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_brand_show extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_brand_show';
		$this->_pk = 'id';
		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function count_by_shopid_showtype($it618_shopid,$it618_showtype) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d AND it618_showtype=%s", array($this->_table, $it618_shopid, $it618_showtype));
	}
	
	public function count_by_shopid($it618_shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d AND it618_power=1", array($this->_table,$it618_shopid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_shopid_showid_showtype($it618_shopid,$it618_showid,$it618_showtype) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_shopid=%d AND it618_showid=%d AND it618_showtype=%s", array($this->_table, $it618_shopid,$it618_showid,$it618_showtype));
	}
	
	public function fetch_all_by_shopid_ishome($it618_shopid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_shopid=%d AND it618_power=1 AND it618_ishome=1 ORDER BY it618_homeorder", array($this->_table,$it618_shopid));
	}
	
	public function fetch_all_by_shopid_isnav($it618_shopid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_shopid=%d AND it618_power=1 AND it618_isnav=1 ORDER BY it618_navorder", array($this->_table,$it618_shopid));
	}
	
	public function fetch_all_by_shopid($it618_shopid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_shopid=%d AND it618_power=1 ORDER BY it618_navorder", array($this->_table,$it618_shopid));
	}
	
	public function update_it618_name_by_showid_showtype($it618_showid,$it618_showtype,$it618_name) {
		DB::query("UPDATE %t SET it618_name=%s WHERE it618_showid=%d AND it618_showtype=%s", array($this->_table, $it618_name, $it618_showid, $it618_showtype));
	}
	
	public function update_it618_power_by_shopid($it618_shopid,$it618_power) {
		DB::query("UPDATE %t SET it618_power=%d WHERE it618_shopid=%d AND (it618_showtype='product_all' or it618_showtype='product_tj')", array($this->_table, $it618_power, $it618_shopid));
	}
	
	public function update_it618_power1_by_shopid($it618_shopid,$it618_power) {
		DB::query("UPDATE %t SET it618_power=%d WHERE it618_shopid=%d AND it618_showtype='money'", array($this->_table, $it618_power, $it618_shopid));
	}
	
	public function delete_by_showid_showtype($it618_showid,$it618_showtype) {
		DB::query("DELETE FROM %t WHERE it618_showid=%d AND it618_showtype=%s", array($this->_table, $it618_showid, $it618_showtype));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>