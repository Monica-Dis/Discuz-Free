<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_brand_sale extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_brand_sale';
		$this->_pk = 'id';
		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	
	public function count_by_it618_pid($it618_pid) {
		$tmp = DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_type!=0 AND it618_pid=%d", array($this->_table, $it618_pid));
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function count_by_pid_uid($pid,$uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_type!=0 AND it618_pid=%d AND it618_uid=%d", array($this->_table, $pid, $uid));
	}
	
	public function count_by_it618_pid1($it618_pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_type!=0 AND it618_pid=%d", array($this->_table, $it618_pid));
	}
	
	public function sumcount_by_it618_pid($it618_pid) {
		return DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_pid=%d AND it618_type!=0", array($this->_table, $it618_pid));
	}
	
	public function sumcount_by_it618_gtypeid($gtypeid) {
		return DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_gtypeid=%d AND it618_type!=0", array($this->_table, $gtypeid));
	}
	
	public function count_by_it618_code($it618_code) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_code=%s", array($this->_table, $it618_code));
	}
	
	public function count_by_it618_code_shopid($it618_code,$it618_shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_state=1 AND it618_code=%s AND it618_shopid=%d", array($this->_table, $it618_code, $it618_shopid));
	}
	
	public function count_by_it618_pj_pid($it618_pj,$it618_pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=%d AND it618_pid=%d", array($this->_table, $it618_pj, $it618_pid));
	}
	
	public function count_by_it618_pj_shopid($it618_shopid) {
		$pj1 = DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=1 AND it618_shopid=%d", array($this->_table, $it618_shopid));
		$pj3 = DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=3 AND it618_shopid=%d", array($this->_table, $it618_shopid));
		
		$pj = $pj1-$pj3;
		if($pj>0){
			return $pj;
		}else{
			return 0;
		}
	}
	
	public function count_by_it618_shopid($it618_shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_type!=0 AND it618_shopid=%d", array($this->_table, $it618_shopid));
	}
	
	public function sum_count_by_it618_shopid($it618_shopid) {
		return DB::result_first("SELECT COUNT(it618_count) FROM %t WHERE it618_type!=0 AND it618_shopid=%d", array($this->_table, $it618_shopid));
	}
	
	public function sum_tc_by_type_shopid($type, $shopid) {
		$tmp= DB::result_first("SELECT SUM(it618_tc) FROM %t WHERE it618_state=2 AND it618_type=%d AND it618_shopid=%d", array($this->_table, $type, $shopid));
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function count_message_by_shopid($it618_shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_ismessage=1 AND it618_shopid=%d", array($this->_table, $it618_shopid));
	}
	
	public function count_by_it618_pid_it618_uid($it618_pid,$it618_uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_type!=0 AND it618_state!=5 AND it618_pid=%d AND it618_uid=%d", array($this->_table, $it618_pid, $it618_uid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_it618_code_shopid($it618_code,$it618_shopid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_code=%s AND it618_shopid=%d", array($this->_table, $it618_code, $it618_shopid));
	}
	
	public function fetch_uid_by_id($id) {
		return DB::result_first("SELECT it618_uid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_state_by_id($id) {
		return DB::result_first("SELECT it618_state FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_state_tuihuo_by_id($id) {
		return DB::result_first("SELECT it618_state_tuihuo FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_username_by_uid($uid) {
		return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function fetch_tel_by_uid($uid) {
		return DB::result_first("SELECT it618_tel FROM %t WHERE it618_tel<>'' AND it618_uid=%d ORDER BY id desc", array($this->_table, $uid));
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function count_by_name($name) {
		return DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_block')." WHERE name=%s", array($name));
	}
	
	public function update_summary_dateline_by_name($summary, $dateline, $name) {
		DB::query("update ".DB::table('common_block')." set summary=%s, dateline=%d WHERE name=%s", array($summary, $dateline, $name));
	}
	
	public function fetch_extcredits_by_uid($creditindex,$uid) {
		return DB::result_first("select extcredits%d from ".DB::table('common_member_count')." where uid=%d", array($creditindex,$uid));
	}
	
	public function fetch_lastactivity_by_uid($uid) {
		return DB::result_first("SELECT lastactivity FROM ".DB::table('common_member_status')." WHERE uid=%d", array($uid));
	}
	
	public function fetch_all_thread_by_uid($uid,$type='thread_new') {
		if($type=='thread_new'){
			return DB::fetch_all("SELECT t.tid,t.subject,t.replies,t.dateline FROM ".DB::table('forum_thread')." t, ".DB::table('forum_forum')." f where  f.status<>'3' AND f.fid=t.fid AND t.displayorder not IN(-1,-2) and t.authorid=%d ORDER BY t.dateline DESC", array($uid));
		}else{
			return DB::fetch_all("SELECT t.tid,t.subject,t.replies,t.dateline FROM ".DB::table('forum_thread')." t, ".DB::table('forum_forum')." f where  f.status<>'3' AND f.fid=t.fid AND t.displayorder not IN(-1,-2) and t.authorid=%d ORDER BY t.replies DESC", array($uid));
		}
	}
	
	public function fetch_all_thread($start = 0, $limit = 0) {
		return DB::fetch_all("SELECT p.fid,p.tid,p.pid,f.name,t.subject,p.message,p.dateline,p.authorid, p.author FROM ".DB::table('forum_thread')." t, ".DB::table('forum_forum')." f, ".DB::table('forum_post')." p where  f.status<>'3' AND f.fid=t.fid AND t.tid=p.tid AND t.displayorder not IN(-1,-2) and p.subject='' ORDER BY p.dateline DESC".DB::limit($start, $limit));
	}
	
	public function count_by_shopid($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		return DB::result_first("SELECT count(1) FROM %t s LEFT JOIN ".DB::table('it618_brand_goods')." g ON s.it618_pid=g.id $condition[0]", $condition[1]);
	}

	public function fetch_paihang_by_extcredits($creditindex,$count) {
		return DB::fetch_all("SELECT extcredits%d as jifen,uid FROM ".DB::table('common_member_count')." ORDER BY jifen DESC".DB::limit(0, $count), array($creditindex,$this->_table));
	}
	
	public function sum_it618_count_by_shopid($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$tmp= DB::result_first("SELECT SUM(s.it618_count) FROM %t s LEFT JOIN ".DB::table('it618_brand_goods')." g ON s.it618_pid=g.id $condition[0]", $condition[1]);
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function sum_it618_price_by_shopid($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$tmp= DB::result_first("SELECT SUM(s.it618_sfmoney) FROM %t s LEFT JOIN ".DB::table('it618_brand_goods')." g ON s.it618_pid=g.id $condition[0]", $condition[1]);
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function sum_it618_score_by_shopid($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$tmp= DB::result_first("SELECT SUM(s.it618_sfscore) FROM %t s LEFT JOIN ".DB::table('it618_brand_goods')." g ON s.it618_pid=g.id $condition[0]", $condition[1]);
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function sum_it618_score1_by_shopid($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$tmp= DB::result_first("SELECT SUM(m.it618_score) FROM %t s LEFT JOIN ".DB::table('it618_brand_goods')." g ON s.it618_pid=g.id LEFT JOIN ".DB::table('it618_brand_money')." m ON s.id=m.it618_saleid AND s.it618_state=2 $condition[0]", $condition[1]);
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function fetch_all_by_shopid($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT s.* FROM %t s LEFT JOIN ".DB::table('it618_brand_goods')." g ON s.it618_pid=g.id $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 's.it618_shopid=%d';
		}
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$parameter[] = '%'.$it618_name.'%';
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "(g.it618_name LIKE %s or s.it618_addr LIKE %s or s.it618_tel LIKE %s)";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 's.it618_uid=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 's.it618_time>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 's.it618_time<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function fetch_all_by_it618_pid($it618_pid, $start = 0, $limit = 0) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_type!=0 AND it618_pid=%d ORDER BY id DESC".DB::limit($start, $limit), array($this->_table,$it618_pid));
	}
	
	public function count_pj_by_pid($it618_pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj>0 AND it618_pid=%d", array($this->_table, $it618_pid));
	}
	
	public function count_by_it618_pid_pj($pj, $it618_pid) {
		if($pj==0){
			return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj>0 AND it618_pid=%d", array($this->_table, $it618_pid));
		}else{
			return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=%d AND it618_pid=%d", array($this->_table, $pj, $it618_pid));
		}
	}
	
	public function fetch_all_by_it618_pid_pj($pj, $it618_pid, $start = 0, $limit = 0) {
		if($pj==0){
			return DB::fetch_all("SELECT * FROM %t WHERE it618_pj>0 AND it618_pid=%d ORDER BY id DESC".DB::limit($start, $limit), array($this->_table,$it618_pid));
		}else{
			return DB::fetch_all("SELECT * FROM %t WHERE it618_pj=%d AND it618_pid=%d ORDER BY id DESC".DB::limit($start, $limit), array($this->_table, $pj, $it618_pid));
		}
	}
	
	public function fetch_by_gwcid_shopid($gwcid,$shopid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_gwcid=%d AND it618_shopid=%d", array($this->_table, $gwcid, $shopid));
	}
	
	public function fetch_by_gwcid($gwcid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_gwcid=%d", array($this->_table, $gwcid));
	}
	
	public function fetch_all_shopid_by_gwcid($gwcid) {
		return DB::fetch_all("SELECT it618_shopid FROM %t WHERE it618_gwcid=%d group by it618_shopid", array($this->_table,$gwcid));
	}
	
	public function sum_gwcmoney_by_gwcid_shopid($gwcid,$shopid) {
		$tmp= DB::result_first("SELECT SUM(round((it618_price*it618_prepaybl*it618_count*it618_zk)/10000,2)+it618_yunfei) FROM %t WHERE it618_gwcid=%d AND it618_shopid=%d", array($this->_table, $gwcid, $shopid));
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function sum_gwcmoney_by_gwcid($gwcid) {
		$tmp= DB::result_first("SELECT SUM(round((it618_price*it618_prepaybl*it618_count*it618_zk)/10000,2)+it618_yunfei) FROM %t WHERE it618_gwcid=%d", array($this->_table, $gwcid));
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function update_it618_state($id,$it618_state) {
		DB::query("UPDATE %t SET it618_state=%d WHERE id=%d", array($this->_table, $it618_state, $id));
	}
	
	public function update_it618_code($id,$it618_code) {
		DB::query("UPDATE %t SET it618_code=%s WHERE id=%d", array($this->_table, $it618_code, $id));
	}
	
	public function update_it618_paycode($id,$it618_paycode) {
		DB::query("UPDATE %t SET it618_paycode=%s WHERE id=%d", array($this->_table, $it618_paycode, $id));
	}
	
	public function update_it618_ismessage($id) {
		DB::query("UPDATE %t SET it618_ismessage=1 WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_lastactivity_by_uid($lastactivity,$uid) {
		DB::query("UPDATE ".DB::table('common_member_status')." SET lastactivity=%d WHERE uid=%d", array($lastactivity, $uid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>