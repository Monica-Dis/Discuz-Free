<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_brand_viplevel extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_brand_viplevel';
		$this->_pk = 'id';
		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function count_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table,$shopid));
	}
	
	public function count_by_shopid_level($shopid,$level) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d AND it618_level=%d", array($this->_table,$shopid,$level));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_money($shopid,$money) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_shopid=%d AND it618_money1<=%f AND it618_money2>=%f", array($this->_table, $shopid, $money, $money));
	}
	
	public function fetch_all_by_search() {
		return DB::fetch_all("SELECT * FROM %t ORDER BY it618_order", array($this->_table));
	}
	
	public function fetch_all_by_shopid($shopid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_shopid=%d ORDER BY it618_level", array($this->_table,$shopid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>