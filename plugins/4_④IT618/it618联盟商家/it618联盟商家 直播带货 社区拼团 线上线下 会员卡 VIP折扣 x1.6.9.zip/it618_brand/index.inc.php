<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/brand_default.func.php';

if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','','plugin.php?id=it618_brand:wap');
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$tmpidsarr=explode(',',$hotclassbrand[0]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_brand_brand_class1=C::t('#it618_brand#it618_brand_brand_class1')->fetch_by_id($id);
	$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class1['it618_class_id'].'@'.$id,'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class1['it618_class_id'].'&class2='.$id);
	$homehotclass.='<li><a href="'.$tmpurl.'">'.$it618_brand_brand_class1['it618_classname'].'</a></li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_area')." ORDER BY it618_order");
while($it618_brand_brand_area = DB::fetch($query)) {
	$tmpurl=it618_brand_getrewrite('brand_list','0@0@'.$it618_brand_brand_area['id'].'@0','plugin.php?id=it618_brand:list&class1=0&class2=0&area1='.$it618_brand_brand_area['id'].'&area2=0');
	$str_area1.='<li><a href="'.$tmpurl.'">'.$it618_brand_brand_area['it618_name'].'</a></li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_brand_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_brand_gonggao = DB::fetch($query)) {
	$it618_title=$it618_brand_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,80,'...');
	
	if($it618_brand_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_brand_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_brand_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_brand_gonggao['it618_url'].'" target="_blank" title="'.$it618_brand_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

$tmpidsarr=explode(',',$hotclassbrand[2]);
$n=1;
for($i=1;$i<=count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i-1]);
	$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($id);
	if($it618_brand_brand['it618_state']==2&&$it618_brand_brand['it618_htstate']==1){
		
		$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
		$ShopPowerIco='';
		if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" align="absmiddle" style="margin-top:2px"/>';
			
		if($it618_brand_brand['it618_mappoint']!='')$mapstr=' <a href="javascript:"><img class="brandmap" name="'.$it618_brand_brand['id'].'" src="source/plugin/it618_brand/images/map.png"></a>';
		
		$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($it618_brand_brand[id]);
		$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
		$tmplevelarr=explode(",",$it618_brand['brand_level']);
		
		if($isallclass==1){
			$tmpwidth=463;$tmpheight=258;
		}else{
			$tmpwidth=341;$tmpheight=223;
		}
		
		if($n%2>0){$homehotbrand.='<li>';$tmpfloat='fl';}else{$tmpfloat='fr';}
		$tmpurl=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
		$homehotbrand.='<div class="big-goods '.$tmpfloat.'">
							  <a class="big-goods-img" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_brand_brand['it618_logo'].'" alt="'.$it618_brand_brand['it618_name'].'" width="'.$tmpwidth.'" height="'.$tmpheight.'" /><span class="big-goods-place">'.$it618_brand_brand['it618_youhui'].'</span></a>
							  <div class="big-goods-info">
								  <h3>
									  <a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_brand['it618_name'].'">'.$it618_brand_brand['it618_name'].' '.$ShopPowerIco.'</a>
								  </h3>
								  <div class="big-goods-price">
									 <span title="'.$it618_brand_brand['it618_addr'].'">'.cutstr($it618_brand_brand['it618_addr'],30,'...').$mapstr.'</span><br><span style="float:right"><a href="'.$tmpurl.'" target="_blank">'.$it618_brand_lang['s1639'].'</a></span><font color="#666" style="font-size:13px">'.str_replace(it618_brand_getlang('s1175'),"",$tmplevelarr[0]).':</font><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'">
								  </div>
							  </div>
						  </div>';
		if($n==count($tmpidsarr)||$n%2==0)$homehotbrand.='</li>';
		$n=$n+1;
	}
}

foreach(C::t('#it618_brand#it618_brand_focus')->fetch_all_by_type_order(8) as $it618_brand_focus) {
	if($isallclass==1){
		$tmpwidth=940;$tmpheight=346;
	}else{
		$tmpwidth=705;$tmpheight=300;
	}
	if($it618_brand_focus['it618_url']!=''){
		$str_focus.='<li><a href="'.$it618_brand_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="'.$tmpwidth.'" height="'.$tmpheight.'" /></a></li>';
	}else{
		$str_focus.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="'.$tmpwidth.'" height="'.$tmpheight.'" /></li>';
	}
}

foreach(C::t('#it618_brand#it618_brand_focus')->fetch_all_by_type_order(17) as $it618_brand_focus) {
	if($it618_brand_focus['it618_url']!=''){
		$str_focus3.='<li><a href="'.$it618_brand_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="223" height="228" /></a></li>';
	}else{
		$str_focus3.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="223" height="228" /></li>';
	}
}

foreach(C::t('#it618_brand#it618_brand_focus')->fetch_all_by_type_order(18) as $it618_brand_focus) {
	if($it618_brand_focus['it618_url']!=''){
		$str_focus4.='<li><a href="'.$it618_brand_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="223" height="228" /></a></li>';
	}else{
		$str_focus4.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="223" height="228" /></li>';
	}
}

$zjsalegoods=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('weeksalegoods');
$newjfgoods=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('newjfgoods');
$hotjfgoods=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('hotjfgoods');

$tmparr=explode(",",$zjsalegoods);
if(count($tmparr)>2){
	$zjsalegoods_count=$tmparr[0];
	$zjsalegoods_order=$tmparr[2];
}else{
	$zjsalegoods_count=15;
	$zjsalegoods_order=1;
}

$tmparr=explode(",",$weeksalegoods);
if(count($tmparr)>2){
	$weeksalegoods_count=$tmparr[0];
	$weeksalegoods_order=$tmparr[2];
}else{
	$weeksalegoods_count=15;
	$weeksalegoods_order=2;
}

$tmparr=explode(",",$newjfgoods);
if(count($tmparr)>2){
	$newjfgoods_count=$tmparr[0];
	$newjfgoods_order=$tmparr[2];
}else{
	$newjfgoods_count=15;
	$newjfgoods_order=3;
}

$tmparr=explode(",",$hotjfgoods);
if(count($tmparr)>2){
	$hotjfgoods_count=$tmparr[0];
	$hotjfgoods_order=$tmparr[2];
}else{
	$hotjfgoods_count=15;
	$hotjfgoods_order=4;
}

if(!($zjsalegoods_count==0&&$weeksalegoods_count==0&&$newjfgoods_count==0&&$hotjfgoods_count==0)){

	$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newjfgoods"=>$newjfgoods_order,"hotjfgoods"=>$hotjfgoods_order);
	asort($homegoods_arr);
	
	$n=1;
	foreach($homegoods_arr as $key=>$homegoods){
		if($n==1)$current=' class="current" ';else $current=' ';
		if($key=='zjsalegoods'){
			if($IsPinEdu==1){
				$it618_brand_lang['t344']=$it618_brand_lang['t801'];
				$it618_brand_lang['t667']=$it618_brand_lang['t800'];
			}
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-new"),\'rc-new\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-new" onclick="tabCutover(this,\'rc-new\');get_home_goods(\''.$key.'\');" title="'.$it618_brand_lang['t344'].'">'.$it618_brand_lang['t667'].'<i></i></span>';
		}
		
		if($key=='weeksalegoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-week"),\'re-week\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-week" onclick="tabCutover(this,\'re-week\');get_home_goods(\''.$key.'\');" title="'.$it618_brand_lang['t346'].'">'.$it618_brand_lang['t668'].'<i></i></span>';
		}
		
		if($key=='newjfgoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-newjf"),\'re-newjf\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-re-newjf" onclick="tabCutover(this,\'re-newjf\');get_home_goods(\''.$key.'\');" title="'.$it618_brand_lang['t547'].'">'.$it618_brand_lang['t669'].'<i></i></span>';
		}
		
		if($key=='hotjfgoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-hotjf"),\'re-hotjf\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-re-hotjf" onclick="tabCutover(this,\'re-hotjf\');get_home_goods(\''.$key.'\');" title="'.$it618_brand_lang['t547'].'">'.$it618_brand_lang['t670'].'<i></i></span>';
		}
		$n=$n+1;
	
		if($key=='zjsalegoods'){
			$home_goods.='<div class="rc-new" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='weeksalegoods'){
			$home_goods.='<div class="re-week" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='newjfgoods'){
			$home_goods.='<div class="re-newjf" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='hotjfgoods'){
			$home_goods.='<div class="re-hotjf" id="home_goods_'.$key.'"></div>';
		}
	}
	
	$homegoods_str='<div class="recommend-goods">
			<div class="recommend-title">
				'.$tab_goods.'
			</div>
			<div class="recommend-content">
				'.$home_goods.'
			</div>
			</div>';
}

if($brandmode=='it618brand'){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
while($it618_brand_brand_class = DB::fetch($query1)) {
	if($it618_brand_brand_class['it618_brandcount']!=0){
		$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'],'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id']);
		
		if($isallclass==1){
			$str_brand.='<div class="index-floor">
					<h2 class="index-floor-title">
						<a href="'.$tmpurl.'">'.$it618_brand_brand_class['it618_classname'].'</a>
						<div class="fr">
							{it618classtj}
							<a href="'.$tmpurl.'" target="_blank">'.it618_brand_getlang('s874').'&nbsp;<em>&gt;&gt;</em></a>
						</div>
					</h2>
					<div class="index-goods-list cl">
						{it618brand}
					</div>
					<div class="floor-more"><a href="'.$tmpurl.'">'.it618_brand_getlang('s875').$it618_brand_brand_class['it618_classname'].'&nbsp;&gt;&gt;</a></div>
				</div>';
		}else{
			$str_classnav.='<li><a href="javascript:void(0);" class="'.$it618_brand_brand_class['it618_cssname'].' newga ga">'.$it618_brand_brand_class['it618_classnamenav'].'</a></li>';
		
			$str_brand.='<div class="index-floor">
							<h2 class="index-floor-title">
								<i class="'.$it618_brand_brand_class['it618_cssname'].'"></i><a class="'.$it618_brand_brand_class['it618_cssname'].'" href="'.$tmpurl.'">'.$it618_brand_brand_class['it618_classname'].'</a>
								<div class="fr">
									{it618classtj}
									<a href="'.$tmpurl.'" target="_blank">'.it618_brand_getlang('s874').'&nbsp;<em>&gt;&gt;</em></a>
								</div>
							</h2>
							<div class="index-goods-list cl">
								{it618brand}
							</div>
							<div class="floor-more"><a href="'.$tmpurl.'">'.it618_brand_getlang('s875').$it618_brand_brand_class['it618_classname'].'&nbsp;&gt;&gt;</a></div>
						</div>';
		}
		
		$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$it618_brand_brand_class['id']." ORDER BY it618_order");
		$it618classtj='';
		while($it618_brand_brand_class1 = DB::fetch($query2)) {
			if($it618_brand_brand_class1['it618_color']!="")
			$tmpname='<font color='.$it618_brand_brand_class1['it618_color'].'>'.cutstr($it618_brand_brand_class1['it618_classname'],12,'...').'</font>';else $tmpname=cutstr($it618_brand_brand_class1['it618_classname'],12,'...');
			
			$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'].'@'.$it618_brand_brand_class1['id'],'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id'].'&class2='.$it618_brand_brand_class1['id']);
			if($it618_brand_brand_class1['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_brand_class1['it618_classname'].'">'.$tmpname.'</a><span></span>';
	
			if($i1ii1[5]!='_')return; /*dism _ taobao _ com*/
		}
		
		$it618brand='';
		foreach(C::t('#it618_brand#it618_brand_brand')->fetch_all_by_search(
			'it618_state=2 and it618_htstate=1','it618_order desc','',0,0,$it618_brand_brand_class['id'],0,0,$startlimit,($it618_brand_brand_class['it618_brandcount']*0.8)
		) as $it618_brand_brand) {
			
			$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
			$ShopPowerIco='';
			if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" align="absmiddle" style="margin-top:2px"/>';
				
			if($it618_brand_brand['it618_mappoint']!='')$mapstr=' <a href="javascript:"><img class="brandmap" name="'.$it618_brand_brand['id'].'" src="source/plugin/it618_brand/images/map.png"></a>';
			
			$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($it618_brand_brand[id]);
			$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
			$tmplevelarr=explode(",",$it618_brand['brand_level']);
			
			$tmpurl=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
			$it618brand.='<div class="index-goods">
								<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
									<img class="dynload" imgsrc="'.$it618_brand_brand['it618_logo'].'" src="source/plugin/it618_brand/images/a.gif" alt="'.$it618_brand_brand['it618_name'].'"/>
									<span class="index-goods-place">'.$it618_brand_brand['it618_youhui'].'</span>
								</a>
								<h3>
									<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_brand['it618_name'].'">'.$it618_brand_brand['it618_name'].' '.$ShopPowerIco.'</a>
								</h3>
								<div class="index-goods-info">
									<span title="'.$it618_brand_brand['it618_addr'].'">'.cutstr($it618_brand_brand['it618_addr'],30,'...').$mapstr.'</span><br>'.$it618_brand_brand['it618_dianhua'].' '.$it618_brand_brand['it618_shouji'].'<br><span style="float:right"><a href="'.$tmpurl.'" target="_blank">'.$it618_brand_lang['s1639'].'</a></span><font color="#666" style="font-size:13px">'.str_replace(it618_brand_getlang('s1175'),"",$tmplevelarr[0]).':</font><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'">
								</div>
							</div>';
			
			if($i1ii1[6]!='b')return;
		}
		
		$str_brand=str_replace("{it618classtj}",$it618classtj,$str_brand);
		$str_brand=str_replace("{it618brand}",$it618brand,$str_brand);
	}
}
}else{
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
	while($it618_brand_brand_class = DB::fetch($query1)) {
		if($it618_brand_brand_class['it618_brandcount']!=0){
			$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'],'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id']);
			
			if($isallclass==1){
				$str_brand.='<div class="index-floor">
					<h2 class="index-floor-title">
						<a href="'.$tmpurl.'">'.$it618_brand_brand_class['it618_classname'].'</a>
						<div class="fr">
							{it618classtj}
							<a href="'.$tmpurl.'" target="_blank">'.it618_brand_getlang('s874').'&nbsp;<em>&gt;&gt;</em></a>
						</div>
					</h2>
					<div class="index-goods-list cl">
						{it618goods}
					</div>
					<div class="floor-more"><a href="'.$tmpurl.'">'.it618_brand_getlang('s875').$it618_brand_brand_class['it618_classname'].'&nbsp;&gt;&gt;</a></div>
				</div>';
			}else{
				$str_classnav.='<li><a href="javascript:void(0);" class="'.$it618_brand_brand_class['it618_cssname'].' newga ga">'.$it618_brand_brand_class['it618_classnamenav'].'</a></li>';
			
				$str_brand.='<div class="index-floor">
								<h2 class="index-floor-title">
									<i class="'.$it618_brand_brand_class['it618_cssname'].'"></i><a class="'.$it618_brand_brand_class['it618_cssname'].'" href="'.$tmpurl.'">'.$it618_brand_brand_class['it618_classname'].'</a>
									<div class="fr">
										{it618classtj}
										<a href="'.$tmpurl.'" target="_blank">'.it618_brand_getlang('s874').'&nbsp;<em>&gt;&gt;</em></a>
									</div>
								</h2>
								<div class="goods-list newga ga cl">
									{it618goods}
								</div>
								<div class="floor-more"><a href="'.$tmpurl.'">'.it618_brand_getlang('s875').$it618_brand_brand_class['it618_classname'].'&nbsp;&gt;&gt;</a></div>
							</div>';
			}
			
			$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$it618_brand_brand_class['id']." ORDER BY it618_order");
			$it618classtj='';
			while($it618_brand_brand_class1 = DB::fetch($query2)) {
				if($it618_brand_brand_class1['it618_color']!="")
				$tmpname='<font color='.$it618_brand_brand_class1['it618_color'].'>'.cutstr($it618_brand_brand_class1['it618_classname'],12,'...').'</font>';else $tmpname=cutstr($it618_brand_brand_class1['it618_classname'],12,'...');
				
				$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'].'@'.$it618_brand_brand_class1['id'],'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id'].'&class2='.$it618_brand_brand_class1['id']);
				if($it618_brand_brand_class1['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_brand_class1['it618_classname'].'">'.$tmpname.'</a><span></span>';
		
				if($i1ii1[5]!='_')return; /*dism _ taobao _ com*/
			}
			
			$it618goods='';
			foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_search(
				'g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','g.it618_brandorder desc,g.it618_views desc',0,0,$it618_brand_brand_class['id'],0,'',0,0,$startlimit,$it618_brand_brand_class['it618_brandcount']
			) as $it618_brand_goods) {
				
				$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
				
				$jfblstr='';
				if($it618_brand_goods['it618_saletype']==6){
					$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
					$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
				}
				
				if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
					$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
				}
				
				$jfbl='';
				if($jfblstr!=''){
					$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
				}
			
				$it618_count=$it618_brand_lang['s1652'].' <font color="#FF6600">'.$it618_brand_goods['it618_count'].'</font>';
				
				if($it618_brand_goods['it618_isalipay']==1){
					$pricestr='<span class="price">&yen;'.floatval($it618_brand_goods['it618_uprice']).'</span><del style="font-weight:normal;font-size:16px">&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
				}else{
					$pricestr='<span class="price" style="color:#390">'.$it618_brand_goods['it618_score'].'<span style="font-weight:normal;font-size:15px">'.$creditname.'</span></span>';
				}
				
				if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
					$jfblstr='<span style="float:right"><font color=#339900>'.$it618_brand_goods['it618_score'].$creditname.'</font></span>'.$jfblstr;
				}
				
				$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
				$salecount='<span style="float:right">'.it618_brand_getlang('s872').$salecount.'</span>';
				
				if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
					$pricestr='<span class="price" style="color:green">'.$it618_brand_lang['s761'].'</span>';
					$jfblstr=$it618_brand_lang['s1732'].'<br>';
					$salecount='<span style="float:right;">'.it618_brand_getlang('t474').' <font color=#FF6600>'.$it618_brand_goods['it618_views'].'</font></span>';
				}
				
				$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
				$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
				$pjhaobl=intval($pjhaocount/$pjallcount*100);
				$pj=$it618_brand_lang['s1899'];
				if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';
		
				$it618goods.='<div class="goods goods1 products">
								'.$jfbl.'
									  <a class="goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" alt="'.$it618_brand_goods['it618_name'].'" width="219" height="219" />
									  <span class="goods-place">'.$it618_brand_brand['it618_name'].'<br><span style="font-size:12px;line-height:14px">'.$it618_brand_goods['it618_seodescription'].'</span></span>
									  </a>
									  <h4>
										  <a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'">'.$it618_brand_goods['it618_name'].'</a>
									  </h4>
									  
									  <div class="goods-info">
										  <div class="saletype">'.$salecount.$pj.'</div>
										  '.$pricestr.'
									  </div>
									  
								  </div>';
				
				if($i1ii1[6]!='b')return;
			}
			
			$str_brand=str_replace("{it618classtj}",$it618classtj,$str_brand);
			$str_brand=str_replace("{it618goods}",$it618goods,$str_brand);
		}
	}
}

$pagetype='index';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:brand_default');
?>