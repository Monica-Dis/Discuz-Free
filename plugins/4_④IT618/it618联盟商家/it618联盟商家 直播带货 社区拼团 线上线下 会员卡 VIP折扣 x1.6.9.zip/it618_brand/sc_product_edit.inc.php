<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if($Shop_isgoods==0){
	it618_cpmsg($it618_brand_lang['s1640'], '', 'error');
}

$goodsbuycontentbrand=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('goodsbuycontentbrand');

$pid=intval($_GET['pid']);
if($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid)){
	if($it618_brand_goods['it618_shopid']!=$ShopId){
		it618_cpmsg(it618_brand_getlang('s703'), "", 'error');
	}
}else{
	it618_cpmsg(it618_brand_getlang('s550'), "", 'error');
}

if(submitcheck('it618submit')){	
	
	for($i=0;$i<=4;$i++){
		if($i==0)$tmpi='';else $tmpi=$i;
		$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
		
		if($it618_brand_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
			$tmparr=explode("source",$it618_brand_goods['it618_picbig'.$tmpi]);
			$tmparr1=explode("://",$it618_brand_goods['it618_picbig'.$tmpi]);
			$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_picbig)&&count($tmparr1)==1){
				$result=unlink($it618_picbig);
			}
		}
		
		$file_ext=strtolower(substr($it618_brand_goods['it618_picbig'.$tmpi],strrpos($it618_brand_goods['it618_picbig'.$tmpi], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		
		if($get_it618_picbig!=''){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}
			
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
			it618_brand_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);
		}

	}
	
	if($Shop_isgoodscheck==1){
		if($_GET['it618_message']!=$_GET['it618_message_old']){
			$it618_state=0;
		}else{
			$it618_state=$it618_brand_goods['it618_state'];
		}
	}else{
		$it618_state=1;
	}
	
	C::t('#it618_brand#it618_brand_goods')->update($pid,array(
		'it618_brandclass_id' => $_GET['it618_brandclass_id'],
		'it618_brandclass1_id' => $_GET['it618_brandclass1_id'],
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_seokeywords' => dhtmlspecialchars($_GET['it618_seokeywords']),
		'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription']),
		'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
		'it618_picbig1' => dhtmlspecialchars($_GET['it618_picbig1']),
		'it618_picbig2' => dhtmlspecialchars($_GET['it618_picbig2']),
		'it618_picbig3' => dhtmlspecialchars($_GET['it618_picbig3']),
		'it618_picbig4' => dhtmlspecialchars($_GET['it618_picbig4']),
		'it618_state' => $it618_state,
		'it618_message' => $_GET['it618_message'],
		'it618_updatetime' => $_G['timestamp'],
	));
	
	if($Shop_isgoodsclass==1){
		C::t('#it618_brand#it618_brand_goods')->update($pid,array(
			'it618_class_id' => $_GET['it618_class_id']
		));
	}
	
	$preurl=str_replace("@","&",$_GET['preurl']);
	it618_cpmsg(it618_brand_getlang('s285'), $preurl, 'succeed');
}

if($Shop_isgoodscheck==1)$tmpstr='<tr><td colspan=2>'.$it618_brand_lang['s1619'].'</td></tr>';
it618_showformheader("plugin.php?id=it618_brand:sc_product_edit$adminsid&pid=$pid&preurl=".$_GET['preurl']);
showtableheaders(it618_brand_getlang('s286'),'it618_brand_goods');

if($Shop_isgoodsclass==1){
	foreach(C::t('#it618_brand#it618_brand_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$tmp1=str_replace('<option value='.$it618_brand_goods['it618_class_id'].'>','<option value='.$it618_brand_goods['it618_class_id'].' selected="selected">',$tmp);
	$isgoodsclass='if(document.getElementById("it618_class_id").value=="0"){
			alert("'.it618_brand_getlang('s264').'");
			return false;
		}';
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$classtmp1=str_replace('<option value='.$it618_brand_goods['it618_brandclass_id'].'>','<option value='.$it618_brand_goods['it618_brandclass_id'].' selected="selected">',$classtmp1);

if($it618_brand_goods['it618_picbig']!='')$src='src="'.$it618_brand_goods['it618_picbig'].'"';
if($it618_brand_goods['it618_picbig1']!='')$src1='src="'.$it618_brand_goods['it618_picbig1'].'"';
if($it618_brand_goods['it618_picbig2']!='')$src2='src="'.$it618_brand_goods['it618_picbig2'].'"';
if($it618_brand_goods['it618_picbig3']!='')$src3='src="'.$it618_brand_goods['it618_picbig3'].'"';
if($it618_brand_goods['it618_picbig4']!='')$src4='src="'.$it618_brand_goods['it618_picbig4'].'"';

echo '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_brand/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=930'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image11\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url11\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url11\').val(url);
						K(\'#img11\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image12\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url12\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url12\').val(url);
						K(\'#img12\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image13\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url13\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url13\').val(url);
						K(\'#img13\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image14\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url14\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url14\').val(url);
						K(\'#img14\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	function checkvalue(){
		if(document.getElementById("it618_brandclass_id").value=="0"){
			alert("'.it618_brand_getlang('s1584').'");
			return false;
		}
		if(document.getElementById("it618_brandclass1_id").value=="0"){
			alert("'.it618_brand_getlang('s1585').'");
			return false;
		}
		'.$isgoodsclass.'
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_brand_getlang('s265').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_brand_getlang('s266').'");
			return false;
		}
		'.$tmpjs.'
	}
	
	function delpic(i){
		document.getElementById("url1"+i).value="";
		document.getElementById("img1"+i).src="";
	}
</script>

'.$tmpstr.'
<tr><td width=60>'.it618_brand_getlang('s1581').'</td><td><select id="it618_brandclass_id" name="it618_brandclass_id" onchange="redirec_class(this.options.selectedIndex)"><option value="0">'.it618_brand_getlang('s1582').'</option>'.$classtmp1.'</select><select id="it618_brandclass1_id"  name="it618_brandclass1_id"><option value="0">'.it618_brand_getlang('s1583').'</option></select></td></tr>';

if($Shop_isgoodsclass==1){echo '
<tr><td>'.it618_brand_getlang('s270').'</td><td><select id="it618_class_id" name="it618_class_id"><option value="0">'.it618_brand_getlang('s271').'</option>'.$tmp1.'</select> '.$it618_brand_lang['s1673'].' </td></tr>';}

echo '
<tr><td>'.it618_brand_getlang('s272').'</td><td><input type="text" class="txt" style="width:400px;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_brand_goods['it618_name'].'"> </td></tr>
<tr><td>'.it618_brand_getlang('s279').'</td><td><img id="img1" '.$src.' width="80" height="80" align="absmiddle"/><input type="text" id="url1" name="it618_picbig" readonly="readonly" value="'.$it618_brand_goods['it618_picbig'].'"/> <input type="button" id="image1" value="'.it618_brand_getlang('s280').'" />   '.it618_brand_getlang('s281').'</td></tr>
<tr><td></td><td><img id="img11" '.$src1.' width="80" height="80" align="absmiddle"/><input type="text" id="url11" name="it618_picbig1" readonly="readonly" value="'.$it618_brand_goods['it618_picbig1'].'"/> <input type="button" id="image11" value="'.it618_brand_getlang('s280').'" /> <input type="button" value="'.it618_brand_getlang('s1434').'" onclick="delpic(1)" /> <img id="img12" '.$src2.' width="80" height="80" align="absmiddle"/><input type="text" id="url12" name="it618_picbig2" readonly="readonly" value="'.$it618_brand_goods['it618_picbig2'].'"/> <input type="button" id="image12" value="'.it618_brand_getlang('s280').'" /> <input type="button" value="'.it618_brand_getlang('s1434').'" onclick="delpic(2)" /></td></tr>
<tr><td></td><td><img id="img13" '.$src3.' width="80" height="80" align="absmiddle"/><input type="text" id="url13" name="it618_picbig3" readonly="readonly" value="'.$it618_brand_goods['it618_picbig3'].'"/> <input type="button" id="image13" value="'.it618_brand_getlang('s280').'" /> <input type="button" value="'.it618_brand_getlang('s1434').'" onclick="delpic(3)" />  <img id="img14" '.$src4.' width="80" height="80" align="absmiddle"/><input type="text" id="url14" name="it618_picbig4" readonly="readonly" value="'.$it618_brand_goods['it618_picbig4'].'"/> <input type="button" id="image14" value="'.it618_brand_getlang('s280').'" /> <input type="button" value="'.it618_brand_getlang('s1434').'" onclick="delpic(4)" /></td></tr>
<tr><td><font color=red>'.it618_brand_getlang('s284').'</font></td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_brand_goods['it618_message'].'</textarea><textarea name="it618_message_old" style="width:700px;height:0px;visibility:hidden;">'.$it618_brand_goods['it618_message'].'</textarea></td></tr>
<tr><td>'.it618_brand_getlang('s1270').'</td><td><input type="text" class="txt" style="width:695px;margin-right:0" name="it618_seokeywords" value="'.$it618_brand_goods[it618_seokeywords].'"></td></tr>
<tr><td>'.it618_brand_getlang('s1271').'</td><td><textarea name="it618_seodescription" style="width:695px;height:50px;">'.$it618_brand_goods[it618_seodescription].'</textarea></td></tr>
';

echo '<tr><td colspan=2><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_brand_getlang('s120').'" /> <font color=red>'.it618_brand_getlang('s1435').'</font></div></td></tr>';

$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$it618_brand_goods['it618_brandclass_id']." ORDER BY it618_order");
$indextmp=1;
$index=0;
while($it618_tmp =	DB::fetch($query)) {
	if($it618_tmp['id']==$it618_brand_goods['it618_brandclass1_id']){
		$index=$indextmp;
	}
	$indextmp+=1;
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_brand_class'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

echo '
<script>
var arrcount='.$count.';
var select_class = new Array(arrcount+1);
	
for (i=0; i<arrcount+1; i++) 
{
 select_class[i] = new Array();
}

'.$tmp1.'

function redirec_class(x)
{
	 var temp = document.getElementById("it618_brandclass1_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;

}

function redirec_class_sel(id,index)
{
	var temp = document.getElementById(id); 
	temp.options[index].selected=true;

}

redirec_class(document.getElementById("it618_brandclass_id").options.selectedIndex);redirec_class_sel("it618_brandclass1_id",'.$index.');
</script>';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>