<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_brand,$classmodesql,$isallclass,$creditname;

$it618_brand = $_G['cache']['plugin']['it618_brand'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/lang.func.php';

if($it618_brand['brand_classmode']==1){
	$classmodesql="it618_img='' and id<=8";
	$isallclass=0;
}else{
	$classmodesql="it618_order>0";
	$isallclass=1;
}

$creditname=$_G['setting']['extcredits'][$it618_brand['brand_credit']]['title'];

$cache_file = DISCUZ_ROOT.'./source/plugin/it618_brand/cache.php';
$tmptime=3;

if(($_G['timestamp'] - @filemtime($cache_file)) > $tmptime) {
	
	@$fp = fopen($cache_file,"w");
	fwrite($fp,$_G['timestamp']);
	fclose($fp);
	
	foreach(C::t('#it618_brand#it618_brand_brand')->fetch_all_by_search("it618_htstate<>0") as $it618_brand_brandtmp) {
		$isviptbtime=0;
		if($IsGroup==1){
			if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('brand',$it618_brand_brandtmp['it618_power'])){
				if($it618_group_rzmoney['it618_istbtime']==1){
					$isviptbtime=1;
					if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$it618_brand_brandtmp['it618_uid'])){
						if($_G['timestamp']>=$it618_group_group_user['it618_etime']&&$it618_group_group_user['it618_etime']>0){
							C::t('#it618_brand#it618_brand_brand')->update_it618_htstate_by_id($it618_brand_brandtmp['id'],2);
						}else{
							C::t('#it618_brand#it618_brand_brand')->update_it618_htstate_by_id($it618_brand_brandtmp['id'],1);
						}
					}else{
						C::t('#it618_brand#it618_brand_brand')->update_it618_htstate_by_id($it618_brand_brandtmp['id'],2);
					}
				}
			}
		}
		
		if($isviptbtime==0){
			if($_G['timestamp']>=$it618_brand_brandtmp['it618_htetime']){
				C::t('#it618_brand#it618_brand_brand')->update_it618_htstate_by_id($it618_brand_brandtmp['id'],2);
			}else{
				C::t('#it618_brand#it618_brand_brand')->update_it618_htstate_by_id($it618_brand_brandtmp['id'],1);
			}
		}
	}

}

function it618_brand_getisvipuser($vipgroupids){
	global $_G,$it618_brand,$it618_brand_lang;
	
	$okvipgroupids = array(array(),array());
	
	if(count($vipgroupids)>0){

		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
	
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$expgrouparray = $expirylist = $termsarray = array();
	
		if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
			$termsarray = $groupterms['ext'];
		}
		if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
			$termsarray[$_G['groupid']] = $groupterms['main']['time'];
		}
		
		foreach($termsarray as $expgroupid => $expiry) {
			if($expiry <= TIMESTAMP) {
				$expgrouparray[] = $expgroupid;
			}
		}
	
		$groupids = array();
		foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
			if(!empty($usergroup['pubtype'])) {
				$groupids[] = $groupid;
			}
		}
		
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
			}
		}
		
		if(!empty($groupterms['main'])) {
			$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
		}
		
		$expiryids = array_keys($expirylist);
		$groupids = array_merge($extgroupids, $expiryids, $groupids);
		
		if($groupids) {
			foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
				$groupid=$group['groupid'];
				
				if(in_array($groupid, $vipgroupids)){
					
					$isgroupok=1;
					if($group['type']!='system'&&$group['type']!='member'){
						$timestamp=$expirylist[$group['groupid']]['timestamp'];
						$grouptime=$expirylist[$group['groupid']]['time'];
						
						if($timestamp-3600*24*365*60>$_G['timestamp']||$grouptime==''){
							$grouptime=$it618_brand_lang['t961'];
						}elseif($timestamp<$_G['timestamp']){
							$isgroupok=0;
						}
					}else{
						$grouptime='';
					}
					if($isgroupok==1){
						$okvipgroupids[0][]=$groupid;
						$okvipgroupids[1][]=$grouptime;
					}
				}
			}
		}
		
		if(!in_array($_G['groupid'], $okvipgroupids[0])){
			if(in_array($_G['groupid'], $vipgroupids)){
				$okvipgroupids[0][]=$_G['groupid'];
				$timestamp=$_G['member']['groupexpiry'];
				if($timestamp>0){
					$timestamp= dgmdate($timestamp, 'd');
				}
				$okvipgroupids[1][]=$timestamp;
			}
		}

	}
	
	return $okvipgroupids;
}

function it618_brand_getvipzk($pid){
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='brand' and it618_pid=$pid and it618_zk>0 order by it618_zk");
	while($it618_group_group_zk = DB::fetch($query)) {
		$vipzkgroupids[] = $it618_group_group_zk['it618_groupid'];
		
		$okvipgroupids=it618_brand_getisvipuser($vipzkgroupids);
		if(in_array($it618_group_group_zk['it618_groupid'], $okvipgroupids[0])){
			return $it618_group_group_zk['it618_zk'];
		}
	}
	return 0;
}

function it618_brand_groupsalepower($pid){
	$vipgroupids_zk = array();$vipgroupids_sale = array();
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_salepower')." where it618_shoptype='brand' and it618_pid=$pid and it618_isok=1");
	while($it618_group_group_salepower = DB::fetch($query)) {
		if(!in_array($it618_group_group_salepower['it618_groupid'], $vipgroupids_sale)){
			$vipgroupids_sale[]=$it618_group_group_salepower['it618_groupid'];
		}
	}
	
	if(count($vipgroupids_sale)>0){
		$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='brand' and it618_pid=$pid and it618_zk>0");
		while($it618_group_group_zk = DB::fetch($query)) {
			if(!in_array($it618_group_group_zk['it618_groupid'], $vipgroupids_zk)){
				$vipgroupids_zk[]=$it618_group_group_zk['it618_groupid'];
			}
		}
		
		$vipgroupids=array_merge($vipgroupids_zk,$vipgroupids_sale);
	
		$okvipgroupids=it618_brand_getisvipuser($vipgroupids);
		
		if(count($okvipgroupids[0])==0){
			if(count($vipgroupids_zk)>0){
				return 2;
			}else{
				return 1;
			}
		}
	}
}

function it618_brand_pay($type,$title){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		return;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype();
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		if($type=='pay'){
			$paystr='<span id="payselect">'.$tmpstr.'</span>';
		}
		
		if($type=='paywap'){
			$paystr='<span id="payselect">'.$tmpstr.'</span>';
		}
		
		if($type=='gwc'){
			$paystr='<div class="buy-block" id="payselect">
					<div class="buy-block-title"><h3>'.$title.'</h3></div>
					<div style="padding:10px">'.$tmpstr.'</div>
					</div>';
		}
		
		if($type=='gwcwap'){
			$paystr='<span id="payselect">'.$tmpstr.'</span>';
		}
	}else{
		$paystr=$tmpstr.'<span id="payselect"></span>';
	}
    
	return $paystr;
}

function it618_brand_initshop($it618_shopid,$it618_name){
	global $it618_brand_lang;
	
	C::t('#it618_brand#it618_brand_show')->insert(array(
		'it618_shopid' => $it618_shopid,
		'it618_name' => $it618_brand_lang['s24'],
		'it618_showtype' => 'visit',
		'it618_isnav' => 1,
		'it618_navorder' => 3,
		'it618_homecount' => 20,
		'it618_pagecount' => 20
	), true);

	C::t('#it618_brand#it618_brand_show')->insert(array(
		'it618_shopid' => $it618_shopid,
		'it618_name' => $it618_brand_lang['s25'],
		'it618_showtype' => 'product_all',
		'it618_ishome' => 1,
		'it618_isnav' => 1,
		'it618_homeorder' => 2,
		'it618_navorder' => 1,
		'it618_homecount' => 12,
		'it618_pagecount' => 12
	), true);
	
	C::t('#it618_brand#it618_brand_show')->insert(array(
		'it618_shopid' => $it618_shopid,
		'it618_name' => $it618_brand_lang['s26'],
		'it618_showtype' => 'product_tj',
		'it618_ishome' => 1,
		'it618_homeorder' => 1,
		'it618_homecount' => 12,
		'it618_pagecount' => 12
	), true);
	
	C::t('#it618_brand#it618_brand_show')->insert(array(
		'it618_shopid' => $it618_shopid,
		'it618_name' => $it618_brand_lang['s681'],
		'it618_showtype' => 'thread_new',
		'it618_ishome' => 0,
		'it618_homeorder' => 2,
		'it618_homecount' => 5
	), true);
	
	C::t('#it618_brand#it618_brand_show')->insert(array(
		'it618_shopid' => $it618_shopid,
		'it618_name' => $it618_brand_lang['s683'],
		'it618_showtype' => 'thread_hot',
		'it618_ishome' => 0,
		'it618_homeorder' => 2,
		'it618_homecount' => 5
	), true);
	
	C::t('#it618_brand#it618_brand_show')->insert(array(
		'it618_shopid' => $it618_shopid,
		'it618_name' => $it618_brand_lang['s27'],
		'it618_showtype' => 'money',
		'it618_ishome' => 1,
		'it618_isnav' => 1,
		'it618_homeorder' => 3,
		'it618_navorder' => 2,
		'it618_homecount' => 20,
		'it618_pagecount' => 20
	), true);
	
	C::t('#it618_brand#it618_brand_brand')->update($it618_shopid,array(
	'it618_seotitle' => $it618_name,
	'it618_seokeywords' => $it618_name,
	'it618_seodescription' => $it618_name,
	'it618_homenavname' => $it618_brand_lang['s28']
	));
	
	if($it618_brand['brand_navtype']>2){
		C::t('#it618_brand#it618_brand_brand')->update($it618_shopid,array(
		'it618_isbrandnav' => ($it618_brand['brand_navtype']-2)
		));
	}
}

function it618_brand_setshopsize($shopid){
	$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($shopid);
	
	$shoppath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$shopid.'/';
	if (!file_exists($shoppath)) {
		mkdir($shoppath);
	}
	
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$shopid.'/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$filespace='.$it618_brand_brand['it618_filespace'].";\n";
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}	
}

function it618_brand_getkd($saletype,$saleid,$kdcomid,$kdid){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kd.func.php')){
		return $kdid;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/kd.func.php';
	
	return GetKD($saletype,$saleid,$kdcomid,$kdid);
}

function it618_brand_getquote($pagetype,$quoteid){
	
	if($pagetype=='shop'){
		$tmpstr='it618_brand_home_ly';
	}
	if($pagetype=='product'){
		$tmpstr='it618_brand_product_ly';
	}
	if($pagetype=='article'){
		$tmpstr='it618_brand_article_ly';
	}
	if($it618_brand_ly = C::t('#it618_brand#'.$tmpstr)->fetch_by_id($quoteid)){
		return '<div class="quote"><span>'.it618_brand_getlang('s466').'<a href="'.it618_brand_rewriteurl($it618_brand_ly['it618_uid']).'" target="_blank" class="a1">'.it618_brand_getusername($it618_brand_ly['it618_uid']).'</a> ('.date('Y-m-d H:i:s', $it618_brand_ly['it618_time']).')</span>'.it618_brand_getquote($pagetype,$it618_brand_ly['it618_quoteid']).'<br />'.str_replace('[br]','<br>',dhtmlspecialchars($it618_brand_ly['it618_content'])).'</div>';
	}
}

function it618_brand_yuangongsale($shopid,$uid,$type,$saleid,$bz,$time){
	C::t('#it618_brand#it618_brand_yuangongsale')->insert(array(
		'it618_shopid' => $shopid,
		'it618_uid' => $uid,
		'it618_type' => $type,
		'it618_saleid' => $saleid,
		'it618_bz' => $bz,
		'it618_time' => $time
	), true);
}

function it618_brand_get_contents3($str){
	return dfsockopen($str);
}

function it618_brand_setkm($saleid){
	global $_G,$it618_brand;
	
	$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($saleid);
	if($it618_brand_sale['it618_gtypeid']>0){
		$query1 = DB::query("select * from ".DB::table('it618_brand_goods_type_km')." WHERE it618_gtypeid=".$it618_brand_sale['it618_gtypeid']." limit 0,".$it618_brand_sale['it618_count']);
		while($it618_brand_goods_type_km = DB::fetch($query1)) {
			$id = C::t('#it618_brand#it618_brand_goods_salekm')->insert(array(
				'it618_saleid' => $saleid,
				'it618_code' => $it618_brand_goods_type_km['it618_code']
			), true);
			if($id>0)DB::query("delete from ".DB::table('it618_brand_goods_type_km')." where id=".$it618_brand_goods_type_km['id']);
		}
	}else{
		$query1 = DB::query("select * from ".DB::table('it618_brand_goods_km')." WHERE it618_pid=".$it618_brand_sale['it618_pid']." limit 0,".$it618_brand_sale['it618_count']);
		while($it618_brand_goods_km = DB::fetch($query1)) {
			$id = C::t('#it618_brand#it618_brand_goods_salekm')->insert(array(
				'it618_saleid' => $saleid,
				'it618_code' => $it618_brand_goods_km['it618_code']
			), true);
			if($id>0)DB::query("delete from ".DB::table('it618_brand_goods_km')." where id=".$it618_brand_goods_km['id']);
		}
	}
	
	it618_brand_qrxf($saleid);
}

function it618_brand_setcode($saleid){
	global $it618_brand;
	$flag=0;
	
	while($flag==0){
		$tmparr=explode(":",date('Y-m-d H:i:s',time()));
		
		$n=3;
		while($n<=$it618_brand['brand_codecount']){
			$tmpstr.=rand(0,9);
			$n=$n+1;
		}
		$tmpstr=$tmpstr.$tmparr[2];
		
		if(C::t('#it618_brand#it618_brand_sale')->count_by_it618_code($tmpstr)==0){
			C::t('#it618_brand#it618_brand_sale')->update_it618_code($saleid,$tmpstr);
			$flag=1;
		}
	}
	
}

function it618_brand_qrxf($saleid){
	global $_G,$it618_brand;
	
	$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($saleid);
	$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
	
	C::t('#it618_brand#it618_brand_sale')->update_it618_state($saleid,2);
	C::t('#it618_brand#it618_brand_sale')->update_it618_code($saleid,'');
	C::t('#it618_brand#it618_brand_money')->update_it618_state($saleid,2);
	
	if($it618_brand_sale['it618_type']==1){
		C::t('common_member_count')->increase($it618_brand_brand['it618_uid'], array(
			'extcredits'.$it618_brand['brand_credit'] => ($it618_brand_sale['it618_sfscore']-$it618_brand_sale['it618_tc']))
		);
	}else{
		$it618_cardmoney=$it618_brand_sale['it618_sfmoney'];
		$it618_ktxmoney=$it618_brand_sale['it618_sfmoney']-$it618_brand_sale['it618_tc'];
		
		if($it618_brand_brand['it618_txtype']==1){
			DB::query("UPDATE ".DB::table('it618_brand_sale')." SET it618_txtype=1 WHERE id=".$saleid);
		}else{
			$txjfcount=intval($it618_ktxmoney*$it618_brand['brand_txbl']/100);
			if($txjfcount<0)$txjfcount=0;
			
			DB::query("UPDATE ".DB::table('it618_brand_sale')." SET it618_txtype=2,it618_txjfid=".$it618_brand['brand_txcredit'].",it618_txjfbl=".$it618_brand['brand_txbl'].",it618_txjfcount=".$txjfcount." WHERE id=".$saleid);
			
			C::t('common_member_count')->increase($it618_brand_brand['it618_uid'], array(
				'extcredits'.$it618_brand['brand_txcredit'] => $txjfcount)
			);
		}
		
		
		if($it618_brand_sale['it618_alipaybl']>0){
			C::t('common_member_count')->increase($it618_brand_sale['it618_uid'], array(
				'extcredits'.$it618_brand['brand_credit'] => intval($it618_brand_sale['it618_sfmoney']*$it618_brand_sale['it618_alipaybl']/100))
			);
		}
		
		
		$tmpcount=C::t('#it618_brand#it618_brand_card')->count_by_uid_isok($it618_brand_sale['it618_uid']);
		if($tmpcount>0){
			$tmpcount=C::t('#it618_brand#it618_brand_cardmoney')->count_by_shopid_uid($it618_brand_sale['it618_shopid'],$it618_brand_sale['it618_uid']);
			if($tmpcount==0){
				C::t('#it618_brand#it618_brand_cardmoney')->insert(array(
					'it618_shopid' => $it618_brand_sale['it618_shopid'],
					'it618_uid' => $it618_brand_sale['it618_uid'],
					'it618_count1' => 1,
					'it618_money1' => $it618_cardmoney,
				), true);
			}else{
				DB::query("update ".DB::table('it618_brand_cardmoney')." set it618_count1=it618_count1+1,it618_money1=it618_money1+".$it618_cardmoney." where it618_shopid=".$it618_brand_sale['it618_shopid']." and it618_uid=".$it618_brand_sale['it618_uid']);
			}
		}
		
		$tmpmoney=$it618_brand_sale['it618_sfmoney'];
		if($tmpmoney>0){
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
			}
			
			if($union_brand_isok==1&&$tmpmoney>=$union_brand_money){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_SaleTC('it618_brand',$tmpmoney,$it618_brand_sale['id'],$it618_brand_sale['it618_uid']);
			}
		}
	}
	
	if($it618_brand_sale['it618_tuijid']>0){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
		Union_TuiTC_OK($saleid,$it618_brand_brand['it618_uid']);
	}
}

function it618_brand_getshopmoney($shopid){
	$ktxmoney=DB::result_first("SELECT sum(it618_sfmoney-it618_tc-it618_tuitc) FROM ".DB::table('it618_brand_sale')." WHERE it618_shopid=$shopid and it618_type=2 and it618_txtype=1 and it618_state=2");
	$txmoney=DB::result_first("SELECT sum(it618_price) FROM ".DB::table('it618_brand_tx')." WHERE it618_shopid=$shopid");
	
	$it618_money=round($ktxmoney-$txmoney,2);
	
	DB::query("update ".DB::table('it618_brand_brand')." set it618_money=".$it618_money." where id=".$shopid);
	
	return $it618_money;
}

function it618_brand_getgoodsprice($it618_brand_goods,$tmpgoods){
	global $_G,$creditname;
	
	$tmpgoods['it618_uprice']=floatval($tmpgoods['it618_uprice']);
	$tmpgoods['it618_price']=floatval($tmpgoods['it618_price']);
	
	if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
		$goodspricestr='<em>&yen;</em> '.$tmpgoods['it618_uprice'].' <del style="color:#999">&yen; '.$tmpgoods['it618_price'].'</del> <font color=#390>'.$tmpgoods['it618_score'].' <em>'.$creditname.'</em></font>';
	}else{
		if($it618_brand_goods['it618_isalipay']==1){
			$goodspricestr='<em>&yen;</em> '.$tmpgoods['it618_uprice'].' <del style="color:#999">&yen; '.$tmpgoods['it618_price'].'</del>';
		}
		
		if($it618_brand_goods['it618_isduihuan']==1){
			$goodspricestr='<font color=#390>'.$tmpgoods['it618_score'].' <em>'.$creditname.'</em></font>';
		}
	}	
	
	return $goodspricestr;
}

function it618_brand_updategoodscount($it618_brand_sale,$type=''){
	if($it618_brand_sale['it618_saletype']==3){
		  if($it618_brand_sale['it618_gtypeid']>0){
			  $salecount = C::t('#it618_brand#it618_brand_sale')->sumcount_by_it618_gtypeid($it618_brand_sale['it618_gtypeid']);
			  if($salecount=='')$salecount=0;
			  
			  $it618_count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type_km')." WHERE it618_gtypeid=".$it618_brand_sale['it618_gtypeid']);
			  DB::query("update ".DB::table('it618_brand_goods_type')." set it618_salecount=".$salecount.",it618_count=".$it618_count." where id=".$it618_brand_sale['it618_gtypeid']);
			  
			  $it618_count=C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_count_by_pid($it618_brand_sale['it618_pid']);
		  }else{
			  $it618_count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_km')." WHERE it618_pid=".$it618_brand_sale['it618_pid']);
		  }
		  
		  $salecount = C::t('#it618_brand#it618_brand_sale')->sumcount_by_it618_pid($it618_brand_sale['it618_pid']);
		  if($salecount=='')$salecount=0;
		  
		  DB::query("update ".DB::table('it618_brand_goods')." set it618_salecount=".$salecount.",it618_count=".$it618_count." where id=".$it618_brand_sale['it618_pid']);
	}else{
		  $dotmp='-';
		  if($type=='tui'){
			  $dotmp='+';
		  }
		  if($it618_brand_sale['it618_gtypeid']>0){
			  $salecount = C::t('#it618_brand#it618_brand_sale')->sumcount_by_it618_gtypeid($it618_brand_sale['it618_gtypeid']);
			  if($salecount=='')$salecount=0;
			  
			  DB::query("update ".DB::table('it618_brand_goods_type')." set it618_salecount=".$salecount.",it618_count=it618_count".$dotmp.$it618_brand_sale['it618_count']." where id=".$it618_brand_sale['it618_gtypeid']);
		  }
		  
		  $salecount = C::t('#it618_brand#it618_brand_sale')->sumcount_by_it618_pid($it618_brand_sale['it618_pid']);
		  if($salecount=='')$salecount=0;
		  
		  DB::query("update ".DB::table('it618_brand_goods')." set it618_salecount=".$salecount.",it618_count=it618_count".$dotmp.$it618_brand_sale['it618_count']." where id=".$it618_brand_sale['it618_pid']);
	}
}

function it618_brand_get_contents2($str){
	return dfsockopen($str);
}

function it618_brand_delsalework(){
	DB::query("delete from ".DB::table('it618_brand_salework'));
}

function it618_brand_sendmessage($type,$id,$type1=''){
	global $_G,$creditname,$it618_brand_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_brand/config/message.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='rz_admin'&&$it618_body_rz_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_rz_admin;
				
				$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_rz_admin_tplid_wxsms;
				$body_wxsms=$it618_body_rz_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_brand['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_brand_getusername($it618_brand_brand['it618_uid']),$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rz_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_brand['it618_uid']).'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='tk_admin'&&$it618_body_tk_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_tk_admin;
				
				$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
				
				$gtypename='';
				if($it618_brand_sale['it618_gtypeid']>0){
					$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_tk_admin_tplid_wxsms;
				$body_wxsms=$it618_body_tk_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_brand_sale['id'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
				$Body=str_replace("{saleid}",$it618_brand_sale['id'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tk_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_brand_sale['id'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='tx_admin'&&$it618_body_tx_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_tx_admin;
				$it618_brand_tx = C::t('#it618_brand#it618_brand_tx')->fetch_by_id($id);
				$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($it618_brand_tx['it618_uid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_tx_admin_tplid_wxsms;
				$body_wxsms=$it618_body_tx_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{shopname}",$it618_brand_brand['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{txmoney}",$it618_brand_tx['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{shopname}",$it618_brand_brand['it618_name'],$Body);
				$Body=str_replace("{txmoney}",$it618_brand_tx['it618_price'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_admin_tplid;
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_brand_brand['it618_name'].'",';
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_brand_tx['it618_price'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale_admin;
				
				$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
				$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
				$tmpurl1=it618_brand_getrewrite('shop_product',$it618_brand_sale['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_sale['it618_shopid'].'&pid='.$it618_brand_goods['id']);
				
				if($it618_brand_sale['it618_saletype']==1)$saletype=it618_brand_getlang('s1002');
				if($it618_brand_sale['it618_saletype']==2)$saletype=it618_brand_getlang('s1003');
				if($it618_brand_sale['it618_saletype']==3)$saletype=it618_brand_getlang('s1223');
				if($it618_brand_sale['it618_saletype']==5)$saletype=it618_brand_getlang('s1654');
				if($it618_brand_sale['it618_saletype']==6){$saletype=it618_brand_getlang('s855');}
				
				if($it618_brand_sale['it618_type']==1){
					$pprice=$it618_brand_sale['it618_score'].$creditname;
				}else{
					$pprice=$it618_brand_sale['it618_price'].$it618_brand_lang['s389'];
				}
				
				$gtypename='';
				if($it618_brand_sale['it618_gtypeid']>0&&$it618_brand_sale['it618_saletype']!=5){
					$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{shopname}",$it618_brand_brand['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{saletype}",$saletype,$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$pprice,$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'],$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_brand_sale['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$Body);
				$Body=str_replace("{shopname}",$it618_brand_brand['it618_name'],$Body);
				$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
				$Body=str_replace("{saletype}",$saletype,$Body);
				$Body=str_replace("{pprice}",$pprice,$Body);
				$Body=str_replace("{pcount}",$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'],$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_brand_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_sale['it618_uid']).'",';
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_brand_brand['it618_name'].'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{saletype}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saletype":"'.$saletype.'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$pprice.'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'].'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_brand_sale['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='gwc_admin'&&$it618_body_gwc_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_gwc_admin;		

				$ALDYBody=$Body;
				
				$money = C::t('#it618_brand#it618_brand_sale')->sum_gwcmoney_by_gwcid($id);
				$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_gwcid($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_gwc_admin_tplid_wxsms;
				$body_wxsms=$it618_body_gwc_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{money}",$money,$tmpvalue);
						$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_brand_sale['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$Body);
				$Body=str_replace("{money}",$money,$Body);
				$Body=str_replace("{gwcid}",$id,$Body);
				$Body=str_replace("{tel}",$it618_brand_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_gwc_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_sale['it618_uid']).'",';
					
					$tmparr=explode("{money}",$ALDYBody);
					if(count($tmparr)>1)$param.='"money":"'.$money.'",';
					
					$tmparr=explode("{gwcid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_brand_sale['it618_tel'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
		}
		
		if($type=='tx_shop'&&$it618_body_tx_shop_isok==1){
			$it618_brand_tx = C::t('#it618_brand#it618_brand_tx')->fetch_by_id($id);
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_tx['it618_shopid']);
			
			$tel=$it618_brand_brand['it618_messagetel'];
			$Body=$it618_body_tx_shop;
			
			if($it618_brand_brand['it618_messageisok']==1){
				
				$uid=$it618_brand_brand['it618_uid'];
				$tplid_wxsms=$it618_body_tx_shop_tplid_wxsms;
				$body_wxsms=$it618_body_tx_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{txmoney}",$it618_brand_tx['it618_price'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{txmoney}",$it618_brand_tx['it618_price'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_shop_tplid;
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_brand_tx['it618_price'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_shop'&&$it618_body_sale_shop_isok==1){
			$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
			
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_sale['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_sale['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			
			$tel=$it618_brand_brand['it618_messagetel'];
			$Body=$it618_body_sale_shop;
			
			if($it618_brand_brand['it618_messageisok']==1){
				
				if($it618_brand_sale['it618_saletype']==1)$saletype=it618_brand_getlang('s1002');
				if($it618_brand_sale['it618_saletype']==2)$saletype=it618_brand_getlang('s1003');
				if($it618_brand_sale['it618_saletype']==3)$saletype=it618_brand_getlang('s1223');
				if($it618_brand_sale['it618_saletype']==5)$saletype=it618_brand_getlang('s1654');
				if($it618_brand_sale['it618_saletype']==6)$saletype=it618_brand_getlang('s855');
				
				if($it618_brand_sale['it618_type']==1){
					$pprice=$it618_brand_sale['it618_score'].$creditname;
				}else{
					$pprice=$it618_brand_sale['it618_price'].$it618_brand_lang['s389'];
				}
				
				$gtypename='';
				if($it618_brand_sale['it618_gtypeid']>0){
					$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
					$gtypename=' ['.$gtypename.']';
				}
				
				$uid=$it618_brand_brand['it618_uid'];
				$tplid_wxsms=$it618_body_sale_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{saletype}",$saletype,$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$pprice,$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'],$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_brand_sale['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
				$Body=str_replace("{saletype}",$saletype,$Body);
				$Body=str_replace("{pprice}",$pprice,$Body);
				$Body=str_replace("{pcount}",$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'],$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_brand_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{saletype}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saletype":"'.$saletype.'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$pprice.'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'].'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_brand_sale['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='gwc_shop'&&$it618_body_gwc_shop_isok==1){
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($type1);
	
			$tel=$it618_brand_brand['it618_messagetel'];
			$Body=$it618_body_gwc_shop;
			
			if($it618_brand_brand['it618_messageisok']==1){
				$ALDYBody=$Body;
				
				$money = C::t('#it618_brand#it618_brand_sale')->sum_gwcmoney_by_gwcid_shopid($id,$type1);
				$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_gwcid_shopid($id,$type1);
				
				$uid=$it618_brand_brand['it618_uid'];
				$tplid_wxsms=$it618_body_gwc_shop_tplid_wxsms;
				$body_wxsms=$it618_body_gwc_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{money}",$money,$tmpvalue);
						$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_brand_sale['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$Body);
				$Body=str_replace("{money}",$money,$Body);
				$Body=str_replace("{gwcid}",$id,$Body);
				$Body=str_replace("{tel}",$it618_brand_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_gwc_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_sale['it618_uid']).'",';
					
					$tmparr=explode("{money}",$ALDYBody);
					if(count($tmparr)>1)$param.='"money":"'.$money.'",';
					
					$tmparr=explode("{gwcid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_brand_sale['it618_tel'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale2state_shop'&&$it618_body_sale2state_shop_isok==1){
			$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
			
			$gtypename='';
			if($it618_brand_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$tel=$it618_brand_brand['it618_messagetel'];
			$Body=$it618_body_sale2state_shop;
			
			if($it618_brand_brand['it618_messageisok']==1){
				if($type1=='shouhuo')$dostr=it618_brand_getlang('s1354');
				if($type1=='tuihuo')$dostr=it618_brand_getlang('s1355');
				
				$uid=$it618_brand_brand['it618_uid'];
				$tplid_wxsms=$it618_body_sale2state_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale2state_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{saleid}",$it618_brand_sale['id'],$tmpvalue);
						$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{do}",$dostr,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$ALDYBody=$Body;
				$Body=str_replace("{saleid}",$it618_brand_sale['id'],$Body);
				$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
				$Body=str_replace("{do}",$dostr,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale2state_shop_tplid;
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_brand_sale['id'].'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{do}",$ALDYBody);
					if(count($tmparr)>1)$param.='"do":"'.$dostr.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='order_shop'&&$it618_body_order_shop_isok==1){
			$it618_brand_order = C::t('#it618_brand#it618_brand_order')->fetch_by_id($id);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_order['it618_pid']);
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_order['it618_shopid']);
			
			$gtypename='';
			if($it618_brand_order['it618_gtypeid']>0){
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_order['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$tel=$it618_brand_brand['it618_messagetel'];
			
			if($it618_brand_brand['it618_messageisok']==1){
				$Body=$it618_body_order_shop;
				
				$uid=$it618_brand_brand['it618_uid'];
				$tplid_wxsms=$it618_body_order_shop_tplid_wxsms;
				$body_wxsms=$it618_body_order_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_order['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_brand_order['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_brand_order['it618_count'].$it618_brand_goods['it618_punit'],$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_brand_order['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_brand_getusername($it618_brand_order['it618_uid']),$Body);
				$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$it618_brand_order['it618_price'],$Body);
				$Body=str_replace("{pcount}",$it618_brand_order['it618_count'].$it618_brand_goods['it618_punit'],$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_brand_order['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_order_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_order['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_brand_order['it618_price'].'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_brand_order['it618_count'].$it618_brand_goods['it618_punit'].'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_brand_order['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='tk_user'&&$it618_body_tk_user_isok==1){
			$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
			
			$gtypename='';
			if($it618_brand_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$tel=$it618_brand_sale['it618_tel'];
			$Body=$it618_body_tk_user;
			
			$uid=$it618_brand_sale['it618_uid'];
			$tplid_wxsms=$it618_body_tk_user_tplid_wxsms;
			$body_wxsms=$it618_body_tk_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{saleid}",$it618_brand_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
					if($it618_brand_sale['it618_state_tuihuo']!=2)$tktype=it618_brand_getlang('s1352');else $tktype=it618_brand_getlang('s1353');
					$tmpvalue=str_replace("{tktype}",$tktype,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{saleid}",$it618_brand_sale['id'],$Body);
			$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
			if($it618_brand_sale['it618_state_tuihuo']!=2)$tktype=it618_brand_getlang('s1352');else $tktype=it618_brand_getlang('s1353');
			$Body=str_replace("{tktype}",$tktype,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_tk_user_tplid;
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_brand_sale['id'].'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
				
				$tmparr=explode("{tktype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"tktype":"'.$tktype.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
			
			$gtypename='';
			if($it618_brand_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			
			$tel=$it618_brand_sale['it618_tel'];
			$Body=$it618_body_sale_user;
			
			if($it618_brand_sale['it618_saletype']==1)$saletype=it618_brand_getlang('s1002');
			if($it618_brand_sale['it618_saletype']==2)$saletype=it618_brand_getlang('s1003');
			if($it618_brand_sale['it618_saletype']==3)$saletype=it618_brand_getlang('s1223');
			if($it618_brand_sale['it618_saletype']==5)$saletype=it618_brand_getlang('s1654');
			if($it618_brand_sale['it618_saletype']==6)$saletype=it618_brand_getlang('s855');
			
			if($it618_brand_sale['it618_type']==1){
				$pprice=$it618_brand_sale['it618_score'].$creditname;
			}else{
				$pprice=$it618_brand_sale['it618_price'].$it618_brand_lang['s389'];
			}
			
			$uid=$it618_brand_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$saletype,$tmpvalue);
					$tmpvalue=str_replace("{pprice}",$pprice,$tmpvalue);
					$tmpvalue=str_replace("{pcount}",$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'],$tmpvalue);
					$tmpvalue=str_replace("{code}",$it618_brand_sale['it618_code'],$tmpvalue);
					$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
			$Body=str_replace("{saletype}",$saletype,$Body);
			$Body=str_replace("{pprice}",$pprice,$Body);
			$Body=str_replace("{pcount}",$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'],$Body);
			$Body=str_replace("{code}",$it618_brand_sale['it618_code'],$Body);
			$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$saletype.'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.$pprice.'",';
				
				$tmparr=explode("{pcount}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pcount":"'.$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'].'",';
				
				$tmparr=explode("{code}",$ALDYBody);
				if(count($tmparr)>1)$param.='"code":"'.$it618_brand_sale['it618_code'].'",';
				
				$tmparr=explode("{purl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='gwc_user'&&$it618_body_gwc_user_isok==1){
			$Body=$it618_body_gwc_user;		

			$ALDYBody=$Body;
			
			$money = C::t('#it618_brand#it618_brand_sale')->sum_gwcmoney_by_gwcid($id);
			$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_gwcid($id);
			$tel=$it618_brand_sale['it618_tel'];
			
			$uid=$it618_brand_sale['it618_uid'];
			$tplid_wxsms=$it618_body_gwc_user_tplid_wxsms;
			$body_wxsms=$it618_body_gwc_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{money}",$money,$tmpvalue);
					$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
					$tmpvalue=str_replace("{tel}",$it618_brand_sale['it618_tel'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$Body);
			$Body=str_replace("{money}",$money,$Body);
			$Body=str_replace("{gwcid}",$id,$Body);
			$Body=str_replace("{tel}",$it618_brand_sale['it618_tel'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_gwc_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_sale['it618_uid']).'",';
				
				$tmparr=explode("{money}",$ALDYBody);
				if(count($tmparr)>1)$param.='"money":"'.$money.'",';
				
				$tmparr=explode("{gwcid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
				
				$tmparr=explode("{tel}",$ALDYBody);
				if(count($tmparr)>1)$param.='"tel":"'.$it618_brand_sale['it618_tel'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='sale2_user'&&$it618_body_sale2_user_isok==1){
			$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($it618_brand_sale['it618_shopid']);
			
			$gtypename='';
			if($it618_brand_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_sale['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_sale['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			
			$tel=$it618_brand_sale['it618_tel'];
			$Body=$it618_body_sale2_user;
			
			if($it618_brand_sale['it618_saletype']==1)$saletype=it618_brand_getlang('s1002');
			if($it618_brand_sale['it618_saletype']==2)$saletype=it618_brand_getlang('s1003');
			if($it618_brand_sale['it618_saletype']==3)$saletype=it618_brand_getlang('s1223');
			if($it618_brand_sale['it618_saletype']==5)$saletype=it618_brand_getlang('s1654');
			if($it618_brand_sale['it618_saletype']==6)$saletype=it618_brand_getlang('s855');
			
			if($it618_brand_sale['it618_type']==1){
				$pprice=$it618_brand_sale['it618_score'].$creditname;
			}else{
				$pprice=$it618_brand_sale['it618_price'].$it618_brand_lang['s389'];
			}
			
			$uid=$it618_brand_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale2_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale2_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{shopname}",$it618_brand_brand['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_brand_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_brand_sale['it618_time']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$saletype,$tmpvalue);
					$tmpvalue=str_replace("{pprice}",$pprice,$tmpvalue);
					$tmpvalue=str_replace("{pcount}",$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'],$tmpvalue);
					$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_brand_getusername($it618_brand_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
			$Body=str_replace("{shopname}",$it618_brand_brand['it618_name'],$Body);
			$Body=str_replace("{saleid}",$it618_brand_sale['id'],$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_brand_sale['it618_time']),$Body);
			$Body=str_replace("{saletype}",$saletype,$Body);
			$Body=str_replace("{pprice}",$pprice,$Body);
			$Body=str_replace("{pcount}",$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'],$Body);
			$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale2_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_brand_getusername($it618_brand_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_brand_brand['it618_name'].'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_brand_sale['id'].'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_brand_sale['it618_time']).'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$saletype.'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.$pprice.'",';
				
				$tmparr=explode("{pcount}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pcount":"'.$it618_brand_sale['it618_count'].$it618_brand_goods['it618_punit'].'",';
				
				$tmparr=explode("{purl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='sale2state_user'&&$it618_body_sale2state_user_isok==1){
			$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
			
			$gtypename='';
			if($it618_brand_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$tel=$it618_brand_sale['it618_tel'];
			$Body=$it618_body_sale2state_user;
			
			if($type1=='fahuo')$dostr=it618_brand_getlang('s1349');
			if($type1=='tongyitui')$dostr=it618_brand_getlang('s1350');
			if($type1=='jujuetui')$dostr=it618_brand_getlang('s1351');
			
			$uid=$it618_brand_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale2state_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale2state_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{saleid}",$it618_brand_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{do}",$dostr,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{saleid}",$it618_brand_sale['id'],$Body);
			$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
			$Body=str_replace("{do}",$dostr,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale2state_user_tplid;
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_brand_sale['id'].'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
				
				$tmparr=explode("{do}",$ALDYBody);
				if(count($tmparr)>1)$param.='"do":"'.$dostr.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='order_user'&&$it618_body_order_user_isok==1){
			$it618_brand_order = C::t('#it618_brand#it618_brand_order')->fetch_by_id($id);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_order['it618_pid']);
			
			$gtypename='';
			if($it618_brand_order['it618_gtypeid']>0){
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_order['it618_gtypeid']);
				$gtypename=' ['.$gtypename.']';
			}
			
			$tel=$it618_brand_order['it618_tel'];
			$Body=$it618_body_order_user;
			
			$uid=$it618_brand_order['it618_uid'];
			$tplid_wxsms=$it618_body_order_user_tplid_wxsms;
			$body_wxsms=$it618_body_order_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{orderid}",$it618_brand_order['id'],$tmpvalue);
					$tmpvalue=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_brand_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{orderid}",$it618_brand_order['id'],$Body);
			$Body=str_replace("{pname}",$gtypename.$it618_brand_goods['it618_name'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_order_user_tplid;
				
				$tmparr=explode("{orderid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"orderid":"'.$it618_brand_order['id'].'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_brand_getsmsstr($gtypename.$it618_brand_goods['it618_name'],$it618_length).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_brand/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmpurl=it618_brand_getrewrite('brand_wap','u@0','plugin.php?id=it618_brand:wap&pagetype=u');
				
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($Body!=''&&$tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_brand_lang['s1860'].$it618_smsbaosign.$it618_brand_lang['s1861'];
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}

function it618_brand_getsmsstr($strtmp,$length){
	if($length>0){
		$tmpstr = "";
		$strlen = $length;
		for($i = 0; $i < $strlen; $i++){
			if(ord(substr($strtmp, $i, 1)) > 0xa0) {
				if(CHARSET=='gbk'){
					$tmpstr .= substr($strtmp, $i, 2);
					$i++;
				}else{
					$tmpstr.=substr($str,$i,3);
					$i+=2;
				}
			} else {
				$tmpstr .= substr($strtmp, $i, 1);
			}
			
		}
		return $tmpstr; 
	}
	return $strtmp;
}

function it618_brand_multipage($pagevalue,$uri=''){
	global $_G,$_GET;
	if($_G['cache']['plugin']['it618_brand']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php')){
		return $pagevalue;
	}

	require DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';

	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}


function it618_brand_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G,$_GET;
	if($_G['cache']['plugin']['it618_brand']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php')){
		return $url;
	}

	require DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php';
	
	if($pagetype=='brand_home'){
		return $brand_home.$urltype;
	}
	
	if($pagetype=='brand_list'){//brand_list-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$brand_list.$brand_list1;

		if(count($tmparr)==1){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("-{cid2}-{aid1}-{aid2}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==2){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("-{aid1}-{aid2}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==4){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
			$pageurl=str_replace("-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==5){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[4],$pageurl);
			$pageurl=str_replace("{page}",'1',$pageurl);
		}
		
		if(count($tmparr)==6){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[4],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[5],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='brand_search'){//brand_search-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$brand_search.$brand_search1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}","",$pageurl);
		}else{
			if(count($tmparr)==5){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[4],$pageurl);
				$pageurl=str_replace("{page}",'1',$pageurl);
			}
			
			if(count($tmparr)==6){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[4],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[5],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='brand_gwc'){
		return $brand_gwc.$urltype;
	}
	
	if($pagetype=='brand_gwcmysale'){
		return $brand_gwc.$urltype.'?mysale';
	}
	
	if($pagetype=='brand_shops'){
		return $brand_shops.$urltype;
	}
	
	if($pagetype=='brand_products'){
		return $brand_products.$urltype;
	}
	
	if($pagetype=='brand_wap'){//brand_wap-{pagetype}-{sid}-{oid}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$brand_wap.$brand_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{sid}-{oid}-{cid}-{page}","",$pageurl);
		}else{
			$tmparr=explode("@",$pagevalue);
			if(count($tmparr)==2){
				$pageurl=str_replace("-{oid}-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
			}if(count($tmparr)==3){
				$pageurl=str_replace("-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
			}else{
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_home'){//shop-{sid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$shop_home.$shop_home1;
		
		if(count($tmparr)>1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=$pageurl.'?'.$tmparr[1];
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_productlist'){//shop_productlist-{sid}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$shop_productlist.$shop_productlist1;
		
		if(count($tmparr)>2){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[2],$pageurl);
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
			$pageurl=str_replace("-{cid}","",$pageurl);
			$pageurl=str_replace("-{page}","",$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_product'){//shop_product-{sid}-{pid}.html
		$tmparr=explode("@",$pagevalue);
		
		$pageurl=$shop_product.$shop_product1;
		$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		$pageurl=str_replace("{pid}",$tmparr[1],$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_articlelist'){//shop_articlelist-{sid}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$shop_articlelist.$shop_articlelist1;
		
		if(count($tmparr)>2){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[2],$pageurl);
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
			$pageurl=str_replace("-{cid}","",$pageurl);
			$pageurl=str_replace("-{page}","",$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_article'){//shop_article-{sid}-{aid}.html
		$tmparr=explode("@",$pagevalue);
		
		$pageurl=$shop_article.$shop_article1;
		$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		$pageurl=str_replace("{aid}",$tmparr[1],$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_imagelist'){//shop_imagelist-{sid}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$shop_imagelist.$shop_imagelist1;
		
		if(count($tmparr)>2){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[2],$pageurl);
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
			$pageurl=str_replace("-{cid}","",$pageurl);
			$pageurl=str_replace("-{page}","",$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_image'){//shop_image-{sid}-{iid}.html
		$tmparr=explode("@",$pagevalue);
		
		$pageurl=$shop_image.$shop_image1;
		$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		$pageurl=str_replace("{iid}",$tmparr[1],$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_page'){//shop_page-{sid}-{oid}.html
		$tmparr=explode("@",$pagevalue);
		
		$pageurl=$shop_page.$shop_page1;
		$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
		$pageurl=str_replace("{oid}",$tmparr[1],$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_money'){//shop_money-{sid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$shop_money.$shop_money1;
		
		if(count($tmparr)>1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[1],$pageurl);
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
			$pageurl=str_replace("-{page}","",$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_visit'){//shop_visit-{sid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$shop_visit.$shop_visit1;
		
		if(count($tmparr)>1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[1],$pageurl);
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
			$pageurl=str_replace("-{page}","",$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_sc'){
		if($uri!=''){
			$urltype=$urltype.'?'.$uri;
		}
		return $shop_sc.$urltype;
	}
}

function it618_brand_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_brand']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_brand_get_contents($str){
	return dfsockopen($str);
}

function it618_brand_getusername($uid){
	return C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($uid);
}

function it618_brand_utftogbk($strcontent,$type=1){
	if($type==1)$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_brand_gbktoutf($strcontent);
	}
}

function it618_brand_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_brand_delfile($dirName){
}

function it618_brand_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
            }else{
            }
        }
        if($type==1);
    }else{
        return false;
    }
}

function it618_brand_get_contents1($str){
	return dfsockopen($str);
}

function it618_brand_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_brand_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_brand_getlang('s529');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_brand_getlang('s530');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_brand_getlang('s531');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_brand_getlang('s532');
		}
	}
	
	return $timestr;
}

function it618_brand_getonlinestate($it618_uid){
	if(TIMESTAMP-C::t('#it618_brand#it618_brand_sale')->fetch_lastactivity_by_uid($it618_uid)<=900){
		$tmponlineico='<img src="source/plugin/it618_brand/images/online.gif" align="absmiddle" title="'.it618_brand_getlang('s533').'" />';
	}else{
		$tmponlineico='<img src="source/plugin/it618_brand/images/offline.gif" align="absmiddle" title="'.it618_brand_getlang('s534').'" />';
	}
	
	return $tmponlineico;
}

function it618_brand_get_contents4($str){
	return dfsockopen($str);
}

function it618_brand_ubbtotext($Text) {
	$Text=preg_replace("/\[url=(.+?)\](.+?)\[\/.+?\]/is","",$Text);
	$Text=preg_replace("/\[coverimg\](.+?)\[\/coverimg\]/is","",$Text);
	$Text=preg_replace("/\[img\](.+?)\[\/img\]/is","",$Text);
	$Text=preg_replace("/\[img=(.+?)\](.+?)\[\/img\]/is","",$Text);
	$Text=preg_replace("/\[media=(.+?)\](.+?)\[\/media\]/is","",$Text);
	$Text=preg_replace("/\[attach\](.+?)\[\/attach\]/is","",$Text);
	$Text=preg_replace("/\[audio\](.+?)\[\/audio\]/is","",$Text);
	$Text=preg_replace("/\[hide\](.+?)\[\/hide\]/is","",$Text);
	$Text=preg_replace("/\[(.+?)\]/is","",$Text);
	$Text=preg_replace("/\{:(.+?):\}/is","",$Text);
	
	$Text=str_replace("<br />","",$Text);
	return $Text;
}

function it618_brand_rewriteurl_thread($fl_html){
	global $_G;
	if($_G['cache']['plugin']['it618_brand']['rewriteurl']==1){
		//	forum.php?mod=viewthread&tid=43
		//	thread-43-1-1.html
		$tmparr=explode("forum.php?mod=viewthread",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"tid=")==1){
					$tmp=str_replace("&tid=","thread-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'-1-1.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}

	}
	return $fl_html;
}

function it618_brand_mapbdtotx($lat,$lng){
	$x_pi = 3.14159265358979324 * 3000.0 / 180.0;
	$x = $lng - 0.0065;
	$y = $lat - 0.006;
	$z = sqrt($x * $x + $y * $y) - 0.00002 * sin($y * $x_pi);
	$theta = atan2($y, $x) - 0.000003 * cos($x * $x_pi);
	$lng = $z * cos($theta);
	$lat = $z * sin($theta);
	return array('lng'=>$lng,'lat'=>$lat);
}

function it618_brand_get_contents5($str){
	return dfsockopen($str);
}

//��������֪��γ��֮��ľ���,��λΪm
function it618_brand_getdistance($lng1,$lat1,$lng2,$lat2){
	//���Ƕ�תΪ����
	$radLat1=deg2rad($lat1);//deg2rad()�������Ƕ�ת��Ϊ����
	$radLat2=deg2rad($lat2);
	$radLng1=deg2rad($lng1);
	$radLng2=deg2rad($lng2);
	$a=$radLat1-$radLat2;
	$b=$radLng1-$radLng2;
	$s=2*asin(sqrt(pow(sin($a/2),2)+cos($radLat1)*cos($radLat2)*pow(sin($b/2),2)))*6378.137*1000;
	return $s;
}

function it618_brand_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_brand_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_brand_getfileext($filestr){
	$file_ext=strtolower(substr($filestr,strrpos($filestr, '.')+1)); 
	$tmparr=explode("?",$file_ext);
	return $tmparr[0];
}

function it618_brand_getgoodspic($shopid,$pid,$it618_picbig,$i=0){
	$file_ext=it618_brand_getfileext($it618_picbig);
	
	return 'source/plugin/it618_brand/kindeditor/data/shop'.$shopid.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
}

function it618_brand_getwapppic($shopid,$get_it618_picbig,$type=1){
	$file_ext=it618_brand_getfileext($get_it618_picbig);
	
	$tmpshopid=explode('wapad',$shopid);
	if(count($tmpshopid)>1){
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/smallimage/'.$shopid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			it618_brand_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,280,1);
		}
		
		$it618_smallurl='source/plugin/it618_brand/kindeditor/data/smallimage/'.$shopid.'.'.$file_ext;
	}else{
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$shopid.'/smallimage/shop'.$shopid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
			
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$shopid.'/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$shopid.'/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}

			it618_brand_imagetosmall($it618_url,$it618_smallurl,$file_ext,320,210,1);
		}
		
		$it618_smallurl='source/plugin/it618_brand/kindeditor/data/shop'.$shopid.'/smallimage/shop'.$shopid.'.'.$file_ext;
	}
	
	return $it618_smallurl.'?'.substr(md5($get_it618_picbig),0,6);
}

function it618_brand_getpjpic($uid,$pjpicid,$picurl){
	$file_ext=it618_brand_getfileext($picurl);

	$tmparr1=explode("://",$picurl);
	if(count($tmparr1)>1){
		$it618_url=$picurl;
	}else{
		$tmparr=explode("source",$picurl);
		$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
	}
	
	$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/user/u'.$uid.'/smallimage/pjpic'.$pjpicid.'.'.$file_ext;
	
	it618_brand_imagetosmall($it618_url,$it618_smallurl,$file_ext,48,48);

}

function it618_brand_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height,$type=0){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		$max=$width;
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function brand_qrcode($url){
	include DISCUZ_ROOT.'./source/plugin/it618_brand/phpqrcode.php';
	
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/it618_brand/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function brand_is_mobile(){ 
	global $_GET;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: Dism��taobao��com
?>