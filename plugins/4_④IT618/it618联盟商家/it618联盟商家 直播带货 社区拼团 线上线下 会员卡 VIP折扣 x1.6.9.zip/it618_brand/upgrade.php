<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_brand/rewrite.php',DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_brand/message.php',DISCUZ_ROOT.'./source/plugin/it618_brand/config/message.php');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_brand_goods_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uprice` float(9,2) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_goods_type_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_gwc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_kdid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_gwcsale_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_paycode` varchar(50) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_gwcsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_prepaybl` float(9,2) NOT NULL DEFAULT '0',
  `it618_zk` float(9,2) NOT NULL DEFAULT '100',
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_alipaybl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tc` float(9,2) NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL,
  `it618_addr` varchar(2000) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr1` varchar(200) NOT NULL,
  `it618_bz` varchar(8000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_saleaudio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_yuangongsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_bz` varchar(200) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_sale_pjpic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_pjpic` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_moneyset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_zsbl` float(9,2) NOT NULL,
  `it618_num` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_num1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_zsbl1` float(9,2) NOT NULL,
  `it618_zsbl2` float(9,2) NOT NULL,
  `it618_zsbl3` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_live` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islogin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ischat` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isip` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_livetype` varchar(50) NOT NULL,
  `it618_liveid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videourl` varchar(1000) NOT NULL,
  `it618_videoiframe` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_brand_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

//require_once DISCUZ_ROOT.'./source/function/function_plugin.php';
runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_pjtime', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_pjtime` int(10) unsigned NOT NULL;"; 
	DB::query($sql);  
	$sql = "update ".DB::table('it618_brand_sale')." set it618_pjtime=it618_time;"; 
	DB::query($sql);  
}
if(!in_array('it618_prepaybl', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_prepaybl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_gtypeid', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_gwcid', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_txtype', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_txtype` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "update ".DB::table('it618_brand_sale')." set it618_txtype=1 where it618_type=2 and it618_state=2;"; 
	DB::query($sql); 
}
if(!in_array('it618_txjfid', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_txjfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_txjfbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_txjfbl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_txjfcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_txjfcount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_pname', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_pname` varchar(200) NOT NULL;"; 
	DB::query($sql);
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_sale'));
	while($it618_brand_sale = DB::fetch($query)) {
		$pname = DB::result_first("SELECT it618_name FROM ".DB::table('it618_brand_goods')." WHERE id=".$it618_brand_sale['it618_pid']);
		$sql = "update ".DB::table('it618_brand_sale')." set it618_pname='".$pname."' where id=".$it618_brand_sale['id'].";"; 
		DB::query($sql); 
	}
}
if(!in_array('it618_gtypename', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_gtypename` varchar(100) NOT NULL;"; 
	DB::query($sql);
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_sale'));
	while($it618_brand_sale = DB::fetch($query)) {
		if($it618_brand_sale['it618_gtypeid']>0){
			$gtypename = DB::result_first("SELECT it618_name FROM ".DB::table('it618_brand_goods_type')." WHERE id=".$it618_brand_sale['it618_gtypeid']);
			$sql = "update ".DB::table('it618_brand_sale')." set it618_gtypename='".$gtypename."' where id=".$it618_brand_sale['id'].";"; 
			DB::query($sql); 
		}
	}
}
if(!in_array('it618_salebz', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_salebz` varchar(2000) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_sfmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_sfmoney` float(9,2) NOT NULL;"; 
	DB::query($sql);
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_sale'));
	while($it618_brand_sale = DB::fetch($query)) {
		if($it618_brand_sale['it618_type']==2){
			$sfmoney=round(($it618_brand_sale['it618_price']*$it618_brand_sale['it618_prepaybl']*$it618_brand_sale['it618_count']*$it618_brand_sale['it618_zk'])/10000,2)+$it618_brand_sale['it618_yunfei']-$it618_brand_sale['it618_quanmoney'];
			if($sfmoney<=0)$sfmoney=0;
			$sql = "update ".DB::table('it618_brand_sale')." set it618_sfmoney=".$sfmoney." where id=".$it618_brand_sale['id'].";"; 
			DB::query($sql); 
		}
	}
}
if(!in_array('it618_tuijid', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_gwc')." add `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_brand_gwcsale')." add `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_tuitcbl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_tuitc` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_vipzk', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_vipzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_brand_gwcsale')." add `it618_vipzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_brand_gwcsale')." add `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_sale'));
	while($it618_brand_sale = DB::fetch($query)) {
		$it618_sfscore = $it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']+$it618_brand_sale['it618_yunfei'];
		$sql = "update ".DB::table('it618_brand_sale')." set it618_sfscore=$it618_sfscore where id=".$it618_brand_sale['id']; 
		DB::query($sql);
	}
}
if(!in_array('it618_pinsaleid', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_sale')." add `it618_pinsaleid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_moneyset'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_islogin', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_moneyset')." add `it618_islogin` int(10) unsigned NOT NULL;"; 
	DB::query($sql);   
}
if(!in_array('it618_num1', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_moneyset')." add `it618_num1` int(10) unsigned NOT NULL;"; 
	DB::query($sql);   
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_gwc'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_money', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_gwc')." add `it618_money` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_quanmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_gwc')." add `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_gwcsale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_pname', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_gwcsale')." add `it618_pname` varchar(200) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_gtypename', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_gwcsale')." add `it618_gtypename` varchar(100) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_quanmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_gwcsale')." add `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_order'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_gtypeid', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_order')." add `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_pname', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_order')." add `it618_pname` varchar(200) NOT NULL;"; 
	DB::query($sql);
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_order'));
	while($it618_brand_order = DB::fetch($query)) {
		$pname = DB::result_first("SELECT it618_name FROM ".DB::table('it618_brand_goods')." WHERE id=".$it618_brand_order['it618_pid']);
		$sql = "update ".DB::table('it618_brand_order')." set it618_pname='".$pname."' where id=".$it618_brand_order['id'].";"; 
		DB::query($sql); 
	}
}
if(!in_array('it618_gtypename', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_order')." add `it618_gtypename` varchar(100) NOT NULL;"; 
	DB::query($sql);
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_order'));
	while($it618_brand_order = DB::fetch($query)) {
		if($it618_brand_order['it618_gtypeid']>0){
			$gtypename = DB::result_first("SELECT it618_name FROM ".DB::table('it618_brand_goods_type')." WHERE id=".$it618_brand_order['it618_gtypeid']);
			$sql = "update ".DB::table('it618_brand_order')." set it618_gtypename='".$gtypename."' where id=".$it618_brand_order['id'].";"; 
			DB::query($sql); 
		}
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_show'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_url', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_show')." add `it618_url` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_isblank', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_show')." add `it618_isblank` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_isbold', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_show')." add `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_brand'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_salebl', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_salebl` float(9,2) NOT NULL DEFAULT '100';"; 
	DB::query($sql);
}
if(!in_array('it618_isyunfeikg', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_isyunfeikg` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_isbrandnav', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_isbrandnav` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_txtype', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_txtype` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_kefuwx', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_kefuwx` varchar(200) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_isgoodssafe', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_isgoodssafe` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_mapurl', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_mapurl` varchar(200) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_lbslat', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_lbslat` float(9,6) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_lbslng', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_lbslng` float(9,6) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_telsalenav', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_telsalenav` mediumtext NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_about', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brand')." add `it618_about` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_brandgroup'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_isouturl', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brandgroup')." add `it618_isouturl` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_score', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brandgroup')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '1000';"; 
	DB::query($sql);
}
if(!in_array('it618_ispjpic', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brandgroup')." add `it618_ispjpic` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_issaleagain', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brandgroup')." add `it618_issaleagain` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_iscard', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brandgroup')." add `it618_iscard` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_issaletype4', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brandgroup')." add `it618_issaletype4` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_issaletype5', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brandgroup')." add `it618_issaletype5` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_islive', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_brandgroup')." add `it618_islive` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_bank'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_wxname', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_bank')." add `it618_wxname` varchar(50) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_wx', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_bank')." add `it618_wx` varchar(100) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_goods'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_prepaybl', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods')." add `it618_prepaybl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_kgbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods')." add `it618_kgbl` float(9,3) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_ptypename', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods')." add `it618_ptypename` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_ptypename1', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods')." add `it618_ptypename1` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_issaledisplay', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods')." add `it618_issaledisplay` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_istelsale', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods')." add `it618_istelsale` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_pjhaocount', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods')." add `it618_pjhaocount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_pjzhongcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods')." add `it618_pjzhongcount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_pjchacount', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods')." add `it618_pjchacount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods'));
	while($it618_brand_goods = DB::fetch($query)) {
		$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
		$pjzhongcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(2,$it618_brand_goods['id']);
		$pjchacount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(3,$it618_brand_goods['id']);
	
		DB::query("update ".DB::table('it618_brand_goods')." set it618_pjhaocount=".$pjhaocount.",it618_pjzhongcount=".$pjzhongcount.",it618_pjchacount=".$pjchacount." where id=".$it618_brand_goods['id']);
	}
}

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_money'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_saleuid', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_money')." add `it618_saleuid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_goods_type'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_name1', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods_type')." add `it618_name1` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_salecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods_type')." add `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods_type'));
	while($it618_brand_goods_type = DB::fetch($query)) {
		$salecount = C::t('#it618_brand#it618_brand_sale')->sumcount_by_it618_gtypeid($it618_brand_goods_type['id']);
		if($salecount=='')$salecount=0;
		DB::query("UPDATE ".DB::table('it618_brand_goods_type')." SET it618_salecount=$salecount where id=".$it618_brand_goods_type['id']);
	}
}
if(!in_array('it618_order', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods_type')." add `it618_order` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_order1', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_goods_type')." add `it618_order1` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_kd'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_kdcomid', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_kd')." add `it618_kdcomid` varchar(50) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_kdyunfei'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_firstkg', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_kdyunfei')." add `it618_firstkg` float(9,3) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_firstkgscore', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_kdyunfei')." add `it618_firstkgscore` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_kgscore', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_kdyunfei')." add `it618_kgscore` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_firstkgprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_kdyunfei')." add `it618_firstkgprice` float(9,2) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_kgprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_kdyunfei')." add `it618_kgprice` float(9,2) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_yuangong'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_uid', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_yuangong')." add `it618_uid` int(10) unsigned NOT NULL"; 
	DB::query($sql);  
}
if(!in_array('it618_istj', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_yuangong')." add `it618_istj` int(10) unsigned NOT NULL"; 
	DB::query($sql);  
}
if(!in_array('it618_isxssale', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_yuangong')." add `it618_isxssale` int(10) unsigned NOT NULL"; 
	DB::query($sql);  
}
if(!in_array('it618_isxxsale', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_yuangong')." add `it618_isxxsale` int(10) unsigned NOT NULL"; 
	DB::query($sql);  
}
if(!in_array('it618_state', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_yuangong')." add `it618_state` int(10) unsigned NOT NULL"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_card'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_name', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_card')." add `it618_name` varchar(10) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_bottomnav'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_curimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_brand_bottomnav')." add `it618_curimg` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmQueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmRfU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmRfU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmRfVENfQklHNS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2JyYW5kL2Rpc2N1el9wbHVnaW5faXQ2MThfYnJhbmRfVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('c291cmNlL3BsdWdpbi9pdDYxOF9icmFuZC9pbnN0YWxsLnBocA=='));
@unlink(DISCUZ_ROOT . base64_decode('c291cmNlL3BsdWdpbi9pdDYxOF9icmFuZC91cGdyYWRlLnBocA=='));
?>