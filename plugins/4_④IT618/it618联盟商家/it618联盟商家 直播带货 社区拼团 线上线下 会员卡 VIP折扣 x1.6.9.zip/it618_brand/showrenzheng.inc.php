<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_brand = $_G['cache']['plugin']['it618_brand'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

$uid = $_G['uid'];
if($uid<=0){
	if($_GET['wap']==1){
		return;
	}else{
		echo $it618_brand_lang['s434'].'it618_split'.it618_brand_getlang('s563').'<a href="member.php?mod=logging&action=login">'.it618_brand_getlang('s773').'</a> <a href="member.php?mod='.$RegName.'">'.it618_brand_getlang('s774').'</a>';return;
	}
}else{
	$rzpower=1;
	$brand_rzpower=(array)unserialize($it618_brand['brand_rzpower']);
	$okvipgroupids=it618_brand_getisvipuser($brand_rzpower);
	if(count($okvipgroupids[0])==0){
		$rzpower=0;
	}else{
		if($it618_brand['brand_iscert']==1){
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
				if(C::t('#it618_members#it618_members_qyrz')->count_by_uid_rzok($uid)==0){
					$rzpower=2;
				}
			}
		}
	}
	
	$ispost=1;
	$username=C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($_G['uid']);
	if(C::t('#it618_brand#it618_brand_brand')->count_by_it618_uid($_G['uid'])>0){
		$t=it618_brand_getlang('s426');
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($_G['uid']);
		$it618_state=$it618_brand_brand['it618_state'];
		if($it618_state==0){
			$statestr=it618_brand_getlang('s427');
			$ispost=0;
		}elseif($it618_state==1){
			$statestr=it618_brand_getlang('s428');
		}
		$tip="$username ".it618_brand_getlang('s429')." ".date('Y-m-d H:i:s', $it618_brand_brand['it618_time'])." ".it618_brand_getlang('s430')."<font color=red>".$statestr."</font>";
		if($it618_state==2){
			$t=it618_brand_getlang('s431');
			if($_GET['wap']==1){
				$scurl=it618_brand_getrewrite('brand_wap','sc@'.$it618_brand_brand['id'],'plugin.php?id=it618_brand:wap&pagetype=sc&sid='.$it618_brand_brand['id']);
				$tip="$username ".it618_brand_getlang('s432')."<br><a href='".$scurl."'>".it618_brand_getlang('s433')."</a>";
			}else{
				$shop_sc=it618_brand_getrewrite('shop_sc','','plugin.php?id=it618_brand:sc');
				$tip="$username ".it618_brand_getlang('s432')."<br><a href='".$shop_sc."' target='_blank'>".it618_brand_getlang('s433')."</a>";
			}
			$ispost=0;
		}
		
		$rzpower=1;
		
	}else{
		$t=it618_brand_getlang('s434');
		$tip="$username ".it618_brand_getlang('s435');
	}
	
	if($rzpower==0||$rzpower==2){
		$ispost=0;
	}
	
	foreach(C::t('#it618_brand#it618_brand_brandgroup')->fetch_all_by_search() as $it618_tmp) {
		$powertmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_groupname'].'</option>';
	}
	
	$powertmp=str_replace('<option value='.$it618_brand_brand['it618_power'].'>','<option value='.$it618_brand_brand['it618_power'].' selected="selected">',$powertmp);
	
	foreach(C::t('#it618_brand#it618_brand_brand_area')->fetch_all_by_search() as $it618_tmp) {
		$areatmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
	
	$areatmp=str_replace('<option value='.$it618_brand_brand['it618_area_id'].'>','<option value='.$it618_brand_brand['it618_area_id'].' selected="selected">',$areatmp);
	
	foreach(C::t('#it618_brand#it618_brand_brand_area1')->fetch_all_by_it618_area_id($it618_brand_brand['it618_area_id']) as $it618_tmp) {
		$areatmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
	$areatmp1=str_replace('<option value='.$it618_brand_brand['it618_area1_id'].'>','<option value='.$it618_brand_brand['it618_area1_id'].' selected="selected">',$areatmp1);
	
	if($it618_brand['brand_mode']!=2){
		foreach(C::t('#it618_brand#it618_brand_brand_class')->fetch_all_by_search() as $it618_tmp) {
			if($it618_tmp['it618_img']=='')$classtmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
		}
		$classtmp=str_replace('<option value='.$it618_brand_brand['it618_class_id'].'>','<option value='.$it618_brand_brand['it618_class_id'].' selected="selected">',$classtmp);
		
		foreach(C::t('#it618_brand#it618_brand_brand_class1')->fetch_all_by_it618_class_id($it618_brand_brand['it618_class_id']) as $it618_tmp) {
			$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
		}
		$classtmp1=str_replace('<option value='.$it618_brand_brand['it618_class1_id'].'>','<option value='.$it618_brand_brand['it618_class1_id'].' selected="selected">',$classtmp1);
	}
	
	
	$rzabout=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('rzabout');
}

if($_GET['wap']==1){
	$height=$_GET['height']*0.8-36;
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:showrenzheng');
?>