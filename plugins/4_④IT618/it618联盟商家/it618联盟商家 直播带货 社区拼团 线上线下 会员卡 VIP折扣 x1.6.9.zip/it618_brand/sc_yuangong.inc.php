<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_brand_yuangong=C::t('#it618_brand#it618_brand_yuangong')->fetch_by_id($delid);
		$it618_img=$it618_brand_yuangong['it618_img'];
		if(file_exists($it618_img)){
			$result=unlink($it618_img);
		}
		$it618_smallimg=$it618_brand_yuangong['it618_smallimg'];
		if(file_exists($it618_smallimg)){
			$result=unlink($it618_smallimg);
		}
		C::t('#it618_brand#it618_brand_yuangong')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			$it618_brand_yuangong=C::t('#it618_brand#it618_brand_yuangong')->fetch_by_id($id);
			$uid=dhtmlspecialchars($_GET['it618_uid'][$id]);
			if($it618_brand_yuangong['it618_uid']!=$uid){
				$tmpcount=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('count',$uid,$ShopId);
				if($tmpcount>0)$uid=0;
			}
			
			C::t('#it618_brand#it618_brand_yuangong')->update($id,array(
				'it618_img' => dhtmlspecialchars($_GET['it618_img'][$id]),
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_zhiwei' => dhtmlspecialchars($_GET['it618_zhiwei'][$id]),
				'it618_uid' => $uid,
				'it618_tjly' => dhtmlspecialchars($_GET['it618_tjly'][$id]),
				'it618_istj' => dhtmlspecialchars($_GET['it618_istj'][$id]),
				'it618_isxssale' => dhtmlspecialchars($_GET['it618_isxssale'][$id]),
				'it618_isxxsale' => dhtmlspecialchars($_GET['it618_isxxsale'][$id]),
				'it618_state' => dhtmlspecialchars($_GET['it618_state'][$id]),
				'it618_order' => intval($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_zhiwei_array = !empty($_GET['newit618_zhiwei']) ? $_GET['newit618_zhiwei'] : array();
	
	foreach($newit618_name_array as $key => $value) {

		C::t('#it618_brand#it618_brand_yuangong')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_name' => dhtmlspecialchars($newit618_name_array[$key]),
			'it618_zhiwei' => dhtmlspecialchars($newit618_zhiwei_array[$key])
		), true);
		$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
	}
	
	C::t('#it618_brand#it618_brand_brand')->update($ShopId,array(
		'it618_salebl' => $_GET['it618_salebl']
	));

	it618_cpmsg(it618_brand_getlang('s5').$ok1.' '.it618_brand_getlang('s6').$ok2.' '.it618_brand_getlang('s7').$del, "plugin.php?id=it618_brand:sc_yuangong$adminsid", 'succeed');
}

$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);

it618_showformheader("plugin.php?id=it618_brand:sc_yuangong$adminsid");
showtableheaders(it618_brand_getlang('s366'),'it618_brand_yuangong');
	
	$count = C::t('#it618_brand#it618_brand_yuangong')->count_by_shopid($ShopId);
	if($Shop_issaleout==1){
		echo '<tr><td colspan=10 style="color:green">'.$it618_brand_lang['s1696'].'<input type="text" style="width:60px;color:blue" name="it618_salebl" value="'.$it618_brand_brand['it618_salebl'].'">%'.$it618_brand_lang['s1697'].'</td></tr>';
	}else{
		$salecss='none';
	}
	
	if($Shop_isgoods!=1){
		$salecss1='none';
	}
	
	echo '<tr><td colspan=10>'.it618_brand_getlang('s367').$count.'<span style="float:right">'.it618_brand_getlang('s368').'</span></td></tr>';
	showsubtitle(array('', it618_brand_getlang('s369'), it618_brand_getlang('s370'),it618_brand_getlang('s1691'),it618_brand_getlang('s1775'),it618_brand_getlang('s1688'),it618_brand_getlang('s244')));
	
	foreach(C::t('#it618_brand#it618_brand_yuangong')->fetch_all_by_shopid($ShopId) as $it618_brand_yuangong) {
		
		if($it618_brand_yuangong['it618_istj']==1)$it618_istj_checked='checked="checked"';else $it618_istj_checked="";
		if($it618_brand_yuangong['it618_isxxsale']==1)$it618_isxxsale_checked='checked="checked"';else $it618_isxxsale_checked="";
		if($it618_brand_yuangong['it618_isxssale']==1)$it618_isxssale_checked='checked="checked"';else $it618_isxssale_checked="";
		if($it618_brand_yuangong['it618_state']==1)$it618_state_checked='checked="checked"';else $it618_state_checked="";
		
		$disabled='';$uidcss='';
		$tmpcount=C::t('#it618_brand#it618_brand_yuangongsale')->count_by_shopid_uid($ShopId,$it618_brand_yuangong['it618_uid']);
		if($tmpcount>0){$disabled="disabled=\"disabled\"";$uidcss='readonly="readonly"';}

		showtablerow('', array('class="td25"', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_brand_yuangong[id]\" $disabled>",
			'<img src="'.$it618_brand_yuangong['it618_img'].'" id="img'.$it618_brand_yuangong['id'].'" width="80" height="80" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url'.$it618_brand_yuangong['id'].'" style="width:50px" name="it618_img['.$it618_brand_yuangong['id'].']" readonly="readonly" value="'.$it618_brand_yuangong['it618_img'].'" /> <input type="button" id="image'.$it618_brand_yuangong['id'].'" value="'.it618_brand_getlang('s372').'" />',
			it618_brand_getlang('s371').'<input class="txt" type="text" style="width:100px;margin-bottom:3px" name="it618_name['.$it618_brand_yuangong['id'].']" value="'.$it618_brand_yuangong['it618_name'].'"><br>'.it618_brand_getlang('s1685').'<input class="txt" type="text" style="width:100px;margin-bottom:3px" name="it618_zhiwei['.$it618_brand_yuangong['id'].']" value="'.$it618_brand_yuangong['it618_zhiwei'].'"><br>'.it618_brand_getlang('s1689').'<input class="txt" type="text" style="width:100px;margin-bottom:3px;color:red;font-weight:bold" '.$uidcss.' name="it618_uid['.$it618_brand_yuangong['id'].']" value="'.$it618_brand_yuangong['it618_uid'].'"><br>'.it618_brand_getlang('s1690').'<a href="'.it618_brand_rewriteurl($it618_brand_yuangong['it618_uid']).'" target="_blank">'.it618_brand_getusername($it618_brand_yuangong['it618_uid']).'</a>',
			'<textarea name="it618_tjly['.$it618_brand_yuangong['id'].']" style="width:300px;height:60px">'.$it618_brand_yuangong['it618_tjly'].'</textarea><br><input class="checkbox" type="checkbox" id="it618_istj'.$it618_brand_yuangong['id'].'" name="it618_istj['.$it618_brand_yuangong['id'].']" '.$it618_istj_checked.' value="1"><label for="it618_istj'.$it618_brand_yuangong['id'].'">'.it618_brand_getlang('s1686').'</label>',
			'<span style="display:'.$salecss.'"><input class="checkbox" type="checkbox" id="it618_isxxsale'.$it618_brand_yuangong['id'].'" name="it618_isxxsale['.$it618_brand_yuangong['id'].']" '.$it618_isxxsale_checked.' value="1"><label for="it618_isxxsale'.$it618_brand_yuangong['id'].'">'.it618_brand_getlang('s1687').'</label></span>
			<span style="display:'.$salecss1.'"><br><input class="checkbox" type="checkbox" id="it618_isxssale'.$it618_brand_yuangong['id'].'" name="it618_isxssale['.$it618_brand_yuangong['id'].']" '.$it618_isxssale_checked.' value="1"><label for="it618_isxssale'.$it618_brand_yuangong['id'].'">'.it618_brand_getlang('s1776').'</label></span>',
			'<input class="checkbox" type="checkbox" name="it618_state['.$it618_brand_yuangong['id'].']" '.$it618_state_checked.' value="1">',
			'<input class="txt" type="text" style="width:30px;" name="it618_order['.$it618_brand_yuangong['id'].']" value="'.$it618_brand_yuangong['it618_order'].'">'
		));
		
		$editorjs.='K(\'#image'.$it618_brand_yuangong['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_brand_yuangong['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_brand_yuangong['id'].'\').val(url);
								K(\'#img'.$it618_brand_yuangong['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php?shopid='.$ShopId.'\',
					fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
$it618_brand_lang373=it618_brand_getlang('s373');
$it618_brand_lang371=it618_brand_getlang('s371');
$it618_brand_lang1685=it618_brand_getlang('s1685');
$it618_brand_lang1692=it618_brand_getlang('s1692');
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
	
		return [
				[[1,''], [1, '$it618_brand_lang373'], [1, '$it618_brand_lang371<input class="txt" style="width:100px;margin-bottom:3px" type="text" name="newit618_name[]"><br>$it618_brand_lang1685<input type="text" class="txt" style="width:100px;" name="newit618_zhiwei[]"><br>$it618_brand_lang1692']]
				];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="5"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.it618_brand_getlang('s128').'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>