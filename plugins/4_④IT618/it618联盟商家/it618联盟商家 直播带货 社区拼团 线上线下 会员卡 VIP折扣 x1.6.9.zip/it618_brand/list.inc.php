<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/brand_default.func.php';
$class1=intval($_GET['class1']);
$class2=intval($_GET['class2']);
$area1=intval($_GET['area1']);
$area2=intval($_GET['area2']);
$order=intval($_GET['order']);

if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','search@'.$class1,'plugin.php?id=it618_brand:wap&pagetype=search&sid='.$class1);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$tmpidsarr=explode(',',$hotclassbrand[1]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_brand_brand_class1=C::t('#it618_brand#it618_brand_brand_class1')->fetch_by_id($id);
	$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class1['it618_class_id'].'@'.$id,'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class1['it618_class_id'].'&class2='.$id);
	$listhotclass.='<li><a href="'.$tmpurl.'">'.$it618_brand_brand_class1['it618_classname'].'</a></li>';
}

foreach(C::t('#it618_brand#it618_brand_focus')->fetch_all_by_type_order(19) as $it618_brand_focus) {
	if($it618_brand_focus['it618_url']!=''){
		$str_focus5.='<li><a href="'.$it618_brand_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus5.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.$it618_brand_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

if($brandmode=='it618brand'){
	if($class1>0){
		$class1name=C::t('#it618_brand#it618_brand_brand_class')->fetch_it618_name_by_id($class1);
		$classtitle.=$class1name.' ';
		$tmpurl=it618_brand_getrewrite('brand_list','0@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1=0&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
		$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$class1name.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
	}
	
	if($class2>0){
		$tmpname=C::t('#it618_brand#it618_brand_brand_class1')->fetch_it618_name_by_id($class2);
		$classtitle.=$tmpname.' ';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
		$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
	}
	
	if($area1>0){
		$tmpname=C::t('#it618_brand#it618_brand_brand_area')->fetch_it618_name_by_id($area1);
		$classtitle.=$tmpname.' ';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@0@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1=0&area2=0&order='.$order);
		$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
	}
	
	if($area2>0){
		$tmpname=C::t('#it618_brand#it618_brand_brand_area1')->fetch_it618_name_by_id($area2);
		$classtitle.=$tmpname.' ';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2=0&order='.$order);
		$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
	}
	
	$listnav.='@';
	$listnav=str_replace('<i class="crumb-icon"></i>@','',$listnav);
	
	if($class1==0)$current=' class="current"';else $current='';
	$tmpurl=it618_brand_getrewrite('brand_list','0@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1=0&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
	$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_brand_getlang('s874').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
	while($it618_brand_brand_class = DB::fetch($query)) {
		$brandcount=C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1','','',0,0,$it618_brand_brand_class['id'],0);
		if($class1==$it618_brand_brand_class['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'].'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id'].'&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
		$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_brand_brand_class['it618_classname'].'<span>'.$brandcount.'</span></a></li>';
	}
	
	if($class1>0){
		if($class2==0)$current=' class="current"';else $current='';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
		$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_brand_getlang('s874').'</a></li>';
		$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$class1." ORDER BY it618_order");
		while($it618_brand_brand_class1 = DB::fetch($query)) {
			$brandcount=C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1','','',0,0,0,$it618_brand_brand_class1['id']);
			if($class2==$it618_brand_brand_class1['id'])$current=' class="current"';else $current='';
			
			$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$it618_brand_brand_class1['id'].'@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$it618_brand_brand_class1['id'].'&area1='.$area1.'&area2='.$area2.'&order='.$order);
			$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_brand_brand_class1['it618_classname'].'<span>'.$brandcount.'</span></a></li>';
		}
	}
	
	if($area1==0)$current=' class="current"';else $current='';
	$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@0@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1=0&area2=0&order='.$order);
	$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_brand_getlang('s874').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_area')." ORDER BY it618_order");
	while($it618_brand_brand_area = DB::fetch($query)) {
		$brandcount=C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1','','',$it618_brand_brand_area['id'],0,0,0);
		if($area1==$it618_brand_brand_area['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$it618_brand_brand_area['id'].'@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$it618_brand_brand_area['id'].'&area2=0&order='.$order);
		$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_brand_brand_area['it618_name'].'<span>'.$brandcount.'</span></a></li>';
	}
	
	if($area1>0){
		if($area2==0)$current=' class="current"';else $current='';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2=0&order='.$order);
		$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_brand_getlang('s874').'</a></li>';
		$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_area1')." where it618_area_id=".$area1." ORDER BY it618_order");
		while($it618_brand_brand_area1 = DB::fetch($query)) {
			$brandcount=C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1','','',0,$it618_brand_brand_area1['id'],0,0);
			if($area2==$it618_brand_brand_area1['id'])$current=' class="current"';else $current='';
			
			$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@'.$it618_brand_brand_area1['id'].'@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$it618_brand_brand_area1['id'].'&order='.$order);
			$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_brand_brand_area1['it618_name'].'<span>'.$brandcount.'</span></a></li>';
		}
	}
	
	if($order==0){$current0=' class="left current"';$it618orderby='it618_order desc';}else $current0=' class="left"';
	if($order==1){$current1=' class="current"';$it618orderby='it618_levelsum';}else $current1='';
	if($order==2){$current2=' class="current"';$it618orderby='it618_levelsum desc';}else $current2='';
	if($order==3){$current3=' class="current"';$it618orderby='it618_time desc';}else $current3='';
	
	for($i=0;$i<=3;$i++){
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$i,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&order='.$i);
		$orderurl[$i]=$tmpurl;
	}
	
	$ppp=$it618_brand['brand_listbrandcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$count = C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1',$it618orderby,'',$area1,$area2,$class1,$class2);
	$hrefsql=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$order.'@it618page','plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&order='.$order);
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
	$multipage = it618_brand_multipage($multipage,$uri);
	
	foreach(C::t('#it618_brand#it618_brand_brand')->fetch_all_by_search(
		'it618_state=2 and it618_htstate=1',$it618orderby,'',$area1,$area2,$class1,$class2,0,$startlimit,$ppp
	) as $it618_brand_brand) {
		$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
		$ShopPowerIco='';
		if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" align="absmiddle" style="margin-top:2px"/>';
			
		if($it618_brand_brand['it618_mappoint']!='')$mapstr=' <a href="javascript:"><img class="brandmap" name="'.$it618_brand_brand['id'].'" src="source/plugin/it618_brand/images/map.png"></a>';
		
		$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($it618_brand_brand[id]);
		$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
		$tmplevelarr=explode(",",$it618_brand['brand_level']);
			
		$tmpurl=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
		$it618goods.='<div class="goods">
					<a class="goods-img" href="'.$tmpurl.'" target="_blank">
					<img imgsrc="'.$it618_brand_brand['it618_logo'].'" src="source/plugin/it618_brand/images/a.gif" class="dynload" width="308" height="196" alt="'.$it618_brand_brand['it618_name'].'" />
					<span class="goods-place">'.$it618_brand_brand['it618_youhui'].'</span>
					</a>
					<h3>
					<a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_brand['it618_name'].'">'.$it618_brand_brand['it618_name'].' '.$ShopPowerIco.'</a>
					</h3>
					<div class="goods-info" style="padding-top:3px">
					<span title="'.$it618_brand_brand['it618_addr'].'">'.cutstr($it618_brand_brand['it618_addr'],30,'...').$mapstr.'</span><br>'.$it618_brand_brand['it618_dianhua'].' '.$it618_brand_brand['it618_shouji'].'<br><span style="float:right"><a href="'.$tmpurl.'" target="_blank">'.$it618_brand_lang['s1639'].'</a></span><font color="#666" style="font-size:13px">'.str_replace(it618_brand_getlang('s1175'),"",$tmplevelarr[0]).':</font><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'">
					</div>
					</div>';
	}

}else{
	if($class1>0){
		$class1name=C::t('#it618_brand#it618_brand_brand_class')->fetch_it618_name_by_id($class1);
		$classtitle.=$class1name.' ';
		$tmpurl=it618_brand_getrewrite('brand_list','0@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1=0&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
		$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$class1name.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
	}
	
	if($class2>0){
		$tmpname=C::t('#it618_brand#it618_brand_brand_class1')->fetch_it618_name_by_id($class2);
		$classtitle.=$tmpname.' ';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
		$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
	}
	
	if($area1>0){
		$tmpname=C::t('#it618_brand#it618_brand_brand_area')->fetch_it618_name_by_id($area1);
		$classtitle.=$tmpname.' ';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@0@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1=0&area2=0&order='.$order);
		$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
	}
	
	if($area2>0){
		$tmpname=C::t('#it618_brand#it618_brand_brand_area1')->fetch_it618_name_by_id($area2);
		$classtitle.=$tmpname.' ';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2=0&order='.$order);
		$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
	}
	
	$listnav.='@';
	$listnav=str_replace('<i class="crumb-icon"></i>@','',$listnav);
	
	if($class1==0)$current=' class="current"';else $current='';
	$tmpurl=it618_brand_getrewrite('brand_list','0@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1=0&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
	$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_brand_getlang('s874').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
	while($it618_brand_brand_class = DB::fetch($query)) {
		$goodscount = C::t('#it618_brand#it618_brand_goods')->count_by_search('g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','',0,0,$it618_brand_brand_class['id'],0);
		if($class1==$it618_brand_brand_class['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'].'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id'].'&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
		$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_brand_brand_class['it618_classname'].'<span>'.$goodscount.'</span></a></li>';
	}
	
	if($class1>0){
		if($class2==0)$current=' class="current"';else $current='';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
		$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_brand_getlang('s874').'</a></li>';
		$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$class1." ORDER BY it618_order");
		while($it618_brand_brand_class1 = DB::fetch($query)) {
			$goodscount = C::t('#it618_brand#it618_brand_goods')->count_by_search('g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','',0,0,0,$it618_brand_brand_class1['id']);
			if($class2==$it618_brand_brand_class1['id'])$current=' class="current"';else $current='';
			
			$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$it618_brand_brand_class1['id'].'@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$it618_brand_brand_class1['id'].'&area1='.$area1.'&area2='.$area2.'&order='.$order);
			$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_brand_brand_class1['it618_classname'].'<span>'.$goodscount.'</span></a></li>';
		}
	}
	
	if($area1==0)$current=' class="current"';else $current='';
	$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@0@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1=0&area2=0&order='.$order);
	$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_brand_getlang('s874').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_area')." ORDER BY it618_order");
	while($it618_brand_brand_area = DB::fetch($query)) {
		$goodscount = C::t('#it618_brand#it618_brand_goods')->count_by_search('g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','',$it618_brand_brand_area['id'],0,0,0);
		if($area1==$it618_brand_brand_area['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$it618_brand_brand_area['id'].'@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$it618_brand_brand_area['id'].'&area2=0&order='.$order);
		$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_brand_brand_area['it618_name'].'<span>'.$goodscount.'</span></a></li>';
	}
	
	if($area1>0){
		if($area2==0)$current=' class="current"';else $current='';
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@0@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2=0&order='.$order);
		$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_brand_getlang('s874').'</a></li>';
		$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_area1')." where it618_area_id=".$area1." ORDER BY it618_order");
		while($it618_brand_brand_area1 = DB::fetch($query)) {
			$goodscount = C::t('#it618_brand#it618_brand_goods')->count_by_search('g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','',0,$it618_brand_brand_area1['id'],0,0);
			if($area2==$it618_brand_brand_area1['id'])$current=' class="current"';else $current='';
			
			$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@'.$it618_brand_brand_area1['id'].'@'.$order,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$it618_brand_brand_area1['id'].'&order='.$order);
			$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_brand_brand_area1['it618_name'].'<span>'.$goodscount.'</span></a></li>';
		}
	}
	
	if($order==0){$current0=' class="left current"';$it618orderby='g.it618_brandorder desc,g.id desc';}else $current0=' class="left"';
	if($order==1){$current1=' class="current"';$it618orderby='g.it618_uprice,g.it618_isduihuan desc';}else $current1='';
	if($order==2){$current2=' class="current"';$it618orderby='g.it618_uprice desc,g.it618_isduihuan desc';}else $current2='';
	if($order==3){$current3=' class="current"';$it618orderby='g.it618_salecount desc,g.it618_isduihuan desc';}else $current3='';
	if($order==4){$current4=' class="current"';$it618orderby='g.it618_views desc,g.it618_isduihuan desc';}else $current4='';
	
	for($i=0;$i<=4;$i++){
		$tmpurl=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$i,'plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&order='.$i);
		$orderurl[$i]=$tmpurl;
	}
	
	$ppp=$it618_brand['brand_listgoodscount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$count = C::t('#it618_brand#it618_brand_goods')->count_by_search('g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','',$area1,$area2,$class1,$class2);
	$hrefsql=it618_brand_getrewrite('brand_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$order.'@it618page','plugin.php?id=it618_brand:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&order='.$order);
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
	$multipage = it618_brand_multipage($multipage,$uri);
	
	foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_search(
		'g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1',$it618orderby,$area1,$area2,$class1,$class2,'',0,0,$startlimit,$ppp
	) as $it618_brand_goods) {
		$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
		
		$jfblstr='';
		if($it618_brand_goods['it618_saletype']==6){
			$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
			$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
		}
		
		if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
			$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
		}
		
		$jfbl='';
		if($jfblstr!=''){
			$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
		}
	
		$it618_count=$it618_brand_lang['s1652'].' <font color="#FF6600">'.$it618_brand_goods['it618_count'].'</font>';
		
		if($it618_brand_goods['it618_isalipay']==1){
			$pricestr='<span class="price">&yen;'.floatval($it618_brand_goods['it618_uprice']).'</span><del style="font-weight:normal;font-size:16px">&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
		}else{
			$pricestr='<span class="price" style="color:#390">'.$it618_brand_goods['it618_score'].'<span style="font-weight:normal;font-size:15px">'.$creditname.'</span></span>';
		}
		
		if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
			$jfblstr='<span style="float:right"><font color=#339900>'.$it618_brand_goods['it618_score'].$creditname.'</font></span>'.$jfblstr;
		}
		
		$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
		$salecount='<span style="float:right">'.it618_brand_getlang('s872').$salecount.'</span>';
		
		if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
			$pricestr='<span class="price" style="color:green">'.$it618_brand_lang['s761'].'</span>';
			$jfblstr=$it618_brand_lang['s1732'].'<br>';
			$salecount='<span style="float:right;">'.it618_brand_getlang('t474').' <font color=#FF6600>'.$it618_brand_goods['it618_views'].'</font></span>';
		}
		
		$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
		$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
		$pjhaobl=intval($pjhaocount/$pjallcount*100);
		$pj=$it618_brand_lang['s1899'];
		if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';

		$it618goods.='<div class="goods goods1 products">
						'.$jfbl.'
							  <a class="goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" alt="'.$it618_brand_goods['it618_name'].'" width="219" height="219" />
							  <span class="goods-place">'.$it618_brand_brand['it618_name'].'<br><span style="font-size:12px;line-height:14px">'.$it618_brand_goods['it618_seodescription'].'</span></span>
							  </a>
							  <h4>
								  <a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'">'.$it618_brand_goods['it618_name'].'</a>
							  </h4>
							  
							  <div class="goods-info">
								  <div class="saletype">'.$salecount.$pj.'</div>
								  '.$pricestr.'
							  </div>
							  
						  </div>';
	}
}

getpaihang();

$classtitle1=str_replace(' ','',$classtitle);
if($classtitle1=='')$classtitle=it618_brand_getlang('s876');
$metatitle=$classtitle.' - '.$metatitle;

$pagetype='list';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:brand_default');
?>