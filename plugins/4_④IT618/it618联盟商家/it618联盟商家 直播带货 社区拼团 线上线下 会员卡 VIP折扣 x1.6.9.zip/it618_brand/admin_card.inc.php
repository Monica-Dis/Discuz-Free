<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return; /*Dism_taobao-com*/

loadcache('plugin');
$it618_brand = $_G['cache']['plugin']['it618_brand'];
$creditname=$_G['setting']['extcredits'][$it618_brand['brand_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function/it618_brand.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier']; /*dism- taobao- com*/
$urls = '&pmod=admin_brand&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_card');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_card' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism·taobao·com*/
?>