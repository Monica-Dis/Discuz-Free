<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if($_GET['it618_type']==0){$it618sql='s.it618_state=3';$selected0='selected="selected"';}
if($_GET['it618_type']==1){$it618sql='s.it618_state=3 and s.it618_type=1';$selected1='selected="selected"';}
if($_GET['it618_type']==2){$it618sql='s.it618_state=3 and s.it618_type=2';$selected2='selected="selected"';}

$urlsql="&pname=".$_GET['pname']."&finduid=".$_GET['finduid']."&it618_type=".$_GET['it618_type']."&it618_time1=".$_GET['it618_time1']."&it618_time2=".$_GET['it618_time2'];

if(submitcheck('it618submit_tuikuan')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_brand_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_brand_sale')." where id=".$delid);
		$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
		
		C::t('#it618_brand#it618_brand_sale')->update_it618_state($delid,4);
		DB::query("delete from ".DB::table('it618_brand_money')." where it618_saleid=".$delid);
		
		it618_brand_updategoodscount($it618_brand_sale,'tui');
		
		if($it618_brand_sale['it618_type']==1){
			C::t('common_member_count')->increase($it618_brand_sale['it618_uid'], array(
				'extcredits'.$it618_brand['brand_credit'] => ($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']))
			);
			if($IsUnion==1)DB::query("update ".DB::table('it618_union_tuitc')." set it618_state=1 where it618_saleid=".$delid);
		}else{
			$money1=round(($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']*$it618_brand_sale['it618_zk']/100),2)+$it618_brand_sale['it618_yunfei']-$it618_brand_sale['it618_quanmoney'];
			if($money1<0)$money1=0;
			C::t('common_member_count')->increase($it618_brand_brand['it618_uid'], array(
				'extcredits'.$it618_brand['brand_credit'] => intval($money1*$it618_brand_sale['it618_alipaybl']/100))
			);
			if($IsUnion==1)DB::query("update ".DB::table('it618_union_tuitc')." set it618_state=1 where it618_saleid=".$delid);
		}

		it618_brand_sendmessage('tk_user',$delid);
		$ok=$ok+1;
		
	}

	cpmsg($it618_brand_lang['s910'].$ok, "action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_brand_lang['s911'],'it618_brand_sum');
	showsubmit('it618sercsubmit', $it618_brand_lang['s912'], '<script charset="utf-8" src="source/plugin/it618_brand/js/Calendar.js"></script>'.$it618_brand_lang['s913'].' <input name="pid" value="'.$_GET['pid'].'" class="txt" style="width:200px" /> '.$it618_brand_lang['s914'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_brand_lang['s915'].' <select name="it618_type"><option value="0" '.$selected0.'>'.$it618_brand_lang['s916'].'</option><option value="1" '.$selected1.'>'.$it618_brand_lang['s917'].'</option><option value="2" '.$selected2.'>'.$it618_brand_lang['s918'].'</option></select> '.$it618_brand_lang['s919'].' <input name="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input name="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>');
	
	$count=C::t('#it618_brand#it618_brand_sale')->count_by_shopid(0,$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$money=C::t('#it618_brand#it618_brand_sale')->sum_it618_price_by_shopid(0,'s.it618_state=3 and s.it618_type=2 and '.$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	if($money=='')$money=0;
	$score=C::t('#it618_brand#it618_brand_sale')->sum_it618_score_by_shopid(0,'s.it618_state=3 and s.it618_type=1 and '.$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	if($score=='')$score=0;
	$score=str_replace(".00","",$score);
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=15>'.$it618_brand_lang['s935'].'<font color=red>'.$count.'</font> '.$it618_brand_lang['s936'].'<font color=red>'.$money.'</font> '.$it618_brand_lang['s389'].' '.$it618_brand_lang['s937'].'<font color=red>'.$score.'</font> '.$creditname.'<span style="float:right;color:red">'.$it618_brand_lang['s939'].'</span></td></tr>';
	showsubtitle(array($it618_brand_lang['s940'], $it618_brand_lang['s941'],$it618_brand_lang['s942'],$it618_brand_lang['s944'],$it618_brand_lang['s945'],$it618_brand_lang['s946'],$it618_brand_lang['s947']));
	
	if($IsCredits==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	}
			
	foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_by_shopid(
		0,$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_brand_sale) {
		
		if($it618_brand_sale['it618_saletype']==1)$saletypestr=it618_brand_getlang('s1245');
		if($it618_brand_sale['it618_saletype']==2)$saletypestr=it618_brand_getlang('s1246');
		if($it618_brand_sale['it618_saletype']==3)$saletypestr=it618_brand_getlang('s1247');
		if($it618_brand_sale['it618_saletype']==5)$saletypestr=it618_brand_getlang('s1658');
		if($it618_brand_sale['it618_saletype']==6)$saletypestr=it618_brand_getlang('s857').' <font color=red>'.$it618_brand_sale['it618_prepaybl'].'</font>%';
		
		if($it618_brand_sale['it618_saletype']==6){
			$prepaybl=$it618_brand_sale['it618_prepaybl']/100;
		}else{
			$prepaybl=1;
		}
		
		$gtypename='';
		if($it618_brand_sale['it618_gtypeid']>0){
			$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
			$gtypename='[<font color=red>'.$gtypename.'</font>]';
		}
			
		if($it618_brand_sale['it618_type']==1){
			$it618_type=$it618_brand_lang['s920'];
			$heji=$it618_brand_sale['it618_score']*$it618_brand_sale['it618_count'];
			$paystr=$it618_brand_lang['s923'].'<font color="red"><b>'.$heji.'</b></font> '.$creditname;
			$heji='<font color="#999">'.$it618_brand_lang['s921'].'</font><font color="red">'.($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']).'</font> '.$creditname;
			
		}else{
			if($it618_brand_sale['it618_state']==2)$tmpcss='green';else $tmpcss='#999';
			$it618_brand_money = C::t('#it618_brand#it618_brand_money')->fetch_by_saleid($it618_brand_sale['id']);
			$it618_type=$it618_brand_lang['s924'].' <font color="'.$tmpcss.'">'.$it618_brand_lang['s925'].($it618_brand_money['it618_score']).'</font><br>'.$it618_brand_lang['s926'].'<font color="green" title="'.$it618_brand_lang['s927'].'">'.$it618_brand_sale['it618_alipaybl'].'%</font>';
			$heji=round(($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']*$it618_brand_sale['it618_zk']/100*$prepaybl),2)-$it618_brand_sale['it618_quanmoney'];
			if($heji<0)$heji=0;
			if($it618_brand_sale['it618_zk']!=100){
				$zkstr=' * <font color=green>'.$it618_brand_sale['it618_zk'].'%</font>';
			}else{
				$zkstr='';	
			}
			$paystr=$it618_brand_lang['s929'].'<font color="red"><b>'.$heji.'</b></font> '.$it618_brand_lang['s389'].'<br>';
			$heji='<font color="#999">'.$it618_brand_lang['s921'].'</font><font color="red">'.($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']*$prepaybl).'</font>'.$zkstr.' '.$it618_brand_lang['s389'].' <font color="#999"><br>- '.$it618_brand_lang['s928'].'</font><font color="red">'.$it618_brand_sale['it618_quanmoney'].'</font> '.$it618_brand_lang['s389'].'';
			
			if($IsCredits==1){
				$paystr=getpaystr($it618_brand_sale['it618_gwcid'],$it618_brand_sale['id'],'brand');
			}
		}
		
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
			
		$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);

		$tmpurl1=it618_brand_getrewrite('shop_product',$it618_brand_sale['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_sale['it618_shopid'].'&pid='.$it618_brand_goods['id']);
		$tmpurl2=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
			
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_brand_sale[id].'" name="delete[]" value="'.$it618_brand_sale[id].'" '.$disabled.'><label for="chk_del'.$it618_brand_sale[id].'">'.$it618_brand_sale['id'].'</label>',
			'<a href="'.$tmpurl1.'" target="_blank">'.$it618_brand_goods['it618_name'].'</a> '.$gtypename.' <a href="'.$tmpurl2.'" target="_blank"><font color="#ccc">'.$it618_brand_brand['it618_name'].'</font></a>',
			$it618_brand_sale['it618_count'],
			$saletypestr.'<br>'.$it618_type,
			'<div style="width:230px">'.$paystr.'</div>',
			'<a href="'.it618_brand_rewriteurl($it618_brand_sale['it618_uid']).'" target="_blank">'.it618_brand_getusername($it618_brand_sale['it618_uid']).'</a>',
			'<div style="width:80px">'.date('Y-m-d H:i:s', $it618_brand_sale['it618_time']).'</div>'
		));
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_brand_lang['s70'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_tuikuan" value="'.$it618_brand_lang['s932'].'" onclick="return confirm(\''.$it618_brand_lang['s933'].'\')"/>&nbsp;'.$it618_brand_lang['s934'].'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/
showtablefooter(); /*dism��taobao��com*/
?>