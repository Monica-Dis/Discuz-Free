<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$brand_home=\''.'brand'."';\n";
		$fileData .= '$brand_list=\''.'brand_list'."';\n";
		$fileData .= '$brand_search=\''.'brand_search'."';\n";
		$fileData .= '$brand_gwc=\''.'brand_gwc'."';\n";
		$fileData .= '$brand_shops=\''.'brand_shops'."';\n";
		$fileData .= '$brand_products=\''.'brand_products'."';\n";
		$fileData .= '$shop_home=\''.'shop'."';\n";
		$fileData .= '$shop_productlist=\''.'shop_productlist'."';\n";
		$fileData .= '$shop_product=\''.'shop_product'."';\n";
		$fileData .= '$shop_articlelist=\''.'shop_articlelist'."';\n";
		$fileData .= '$shop_article=\''.'shop_article'."';\n";
		$fileData .= '$shop_imagelist=\''.'shop_imagelist'."';\n";
		$fileData .= '$shop_image=\''.'shop_image'."';\n";
		$fileData .= '$shop_page=\''.'shop_page'."';\n";
		$fileData .= '$shop_money=\''.'shop_money'."';\n";
		$fileData .= '$shop_visit=\''.'shop_visit'."';\n";
		$fileData .= '$shop_sc=\''.'shop_sc'."';\n";
		$fileData .= '$brand_wap=\''.'brand_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$brand_home1=\''.$urltype."';\n";
		$fileData .= '$brand_list1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$brand_search1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$brand_gwc1=\''.$urltype."';\n";
		$fileData .= '$brand_shops1=\''.$urltype."';\n";
		$fileData .= '$brand_products1=\''.$urltype."';\n";
		$fileData .= '$shop_home1=\'-{sid}'.$urltype."';\n";
		$fileData .= '$shop_productlist1=\'-{sid}-{cid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_product1=\'-{sid}-{pid}'.$urltype."';\n";
		$fileData .= '$shop_articlelist1=\'-{sid}-{cid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_article1=\'-{sid}-{aid}'.$urltype."';\n";
		$fileData .= '$shop_imagelist1=\'-{sid}-{cid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_image1=\'-{sid}-{iid}'.$urltype."';\n";
		$fileData .= '$shop_page1=\'-{sid}-{oid}'.$urltype."';\n";
		$fileData .= '$shop_money1=\'-{sid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_visit1=\'-{sid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_sc1=\'-{sid}-{page}'.$urltype."';\n";
		$fileData .= '$brand_wap1=\'-{pagetype}-{sid}-{oid}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$brand_home=\''.str_replace("-","",$_GET['brand_home'])."';\n";
		$fileData .= '$brand_list=\''.str_replace("-","",$_GET['brand_list'])."';\n";
		$fileData .= '$brand_search=\''.str_replace("-","",$_GET['brand_search'])."';\n";
		$fileData .= '$brand_gwc=\''.str_replace("-","",$_GET['brand_gwc'])."';\n";
		$fileData .= '$brand_shops=\''.str_replace("-","",$_GET['brand_shops'])."';\n";
		$fileData .= '$brand_products=\''.str_replace("-","",$_GET['brand_products'])."';\n";
		$fileData .= '$shop_home=\''.str_replace("-","",$_GET['shop_home'])."';\n";
		$fileData .= '$shop_productlist=\''.str_replace("-","",$_GET['shop_productlist'])."';\n";
		$fileData .= '$shop_product=\''.str_replace("-","",$_GET['shop_product'])."';\n";
		$fileData .= '$shop_articlelist=\''.str_replace("-","",$_GET['shop_articlelist'])."';\n";
		$fileData .= '$shop_article=\''.str_replace("-","",$_GET['shop_article'])."';\n";
		$fileData .= '$shop_imagelist=\''.str_replace("-","",$_GET['shop_imagelist'])."';\n";
		$fileData .= '$shop_image=\''.str_replace("-","",$_GET['shop_image'])."';\n";
		$fileData .= '$shop_page=\''.str_replace("-","",$_GET['shop_page'])."';\n";
		$fileData .= '$shop_money=\''.str_replace("-","",$_GET['shop_money'])."';\n";
		$fileData .= '$shop_visit=\''.str_replace("-","",$_GET['shop_visit'])."';\n";
		$fileData .= '$shop_sc=\''.str_replace("-","",$_GET['shop_sc'])."';\n";
		$fileData .= '$brand_wap=\''.str_replace("-","",$_GET['brand_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$brand_home1=\''.$urltype."';\n";
		$fileData .= '$brand_list1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$brand_search1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$brand_gwc1=\''.$urltype."';\n";
		$fileData .= '$brand_shops1=\''.$urltype."';\n";
		$fileData .= '$brand_products1=\''.$urltype."';\n";
		$fileData .= '$shop_home1=\'-{sid}'.$urltype."';\n";
		$fileData .= '$shop_productlist1=\'-{sid}-{cid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_product1=\'-{sid}-{pid}'.$urltype."';\n";
		$fileData .= '$shop_articlelist1=\'-{sid}-{cid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_article1=\'-{sid}-{aid}'.$urltype."';\n";
		$fileData .= '$shop_imagelist1=\'-{sid}-{cid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_image1=\'-{sid}-{iid}'.$urltype."';\n";
		$fileData .= '$shop_page1=\'-{sid}-{oid}'.$urltype."';\n";
		$fileData .= '$shop_money1=\'-{sid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_visit1=\'-{sid}-{page}'.$urltype."';\n";
		$fileData .= '$shop_sc1=\'-{sid}-{page}'.$urltype."';\n";
		$fileData .= '$brand_wap1=\'-{pagetype}-{sid}-{oid}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_brand_lang['s599'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_brand_lang['s600'].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_brand_lang['s601'].'</td></tr>
<tr><td colspan="3">'.$it618_brand_lang['s602'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_brand_lang['s603'].'</th><th>'.$it618_brand_lang['s604'].'</th><th>'.$it618_brand_lang['s605'].'</th></tr>
<tr class="hover">
<td>'.$it618_brand_lang['s606'].'</td><td></td><td class="longtxt"><input name="brand_home" value="'.$brand_home.'"/>'.$brand_home.$brand_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s607'].'</td><td>{cid1}, {cid2}, {aid1}, {aid2}, {order}, {page}</td><td class="longtxt"><input name="brand_list" value="'.$brand_list.'" />'.$brand_list.$brand_list1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s608'].'</td><td>{cid1}, {cid2}, {aid1}, {aid2}, {order}, {page}</td><td class="longtxt"><input name="brand_search" value="'.$brand_search.'" />'.$brand_search.$brand_search1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s1759'].'</td><td></td><td class="longtxt"><input name="brand_gwc" value="'.$brand_gwc.'" />'.$brand_gwc.$brand_gwc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s858'].'</td><td></td><td class="longtxt"><input name="brand_shops" value="'.$brand_shops.'"/>'.$brand_shops.$brand_shops1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s860'].'</td><td></td><td class="longtxt"><input name="brand_products" value="'.$brand_products.'"/>'.$brand_products.$brand_products1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s610'].'</td><td>{sid}</td><td class="longtxt"><input name="shop_home" value="'.$shop_home.'"/>'.$shop_home.$shop_home1.'</td></tr>
<tr class="hover">
<td>'.$it618_brand_lang['s611'].'</td><td>{sid}, {cid}, {page}</td><td class="longtxt"><input name="shop_productlist" value="'.$shop_productlist.'"/>'.$shop_productlist.$shop_productlist1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s612'].'</td><td>{sid}, {pid}</td><td class="longtxt"><input name="shop_product" value="'.$shop_product.'"/>'.$shop_product.$shop_product1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s613'].'</td><td>{sid}, {cid}, {page}</td><td class="longtxt"><input name="shop_articlelist" value="'.$shop_articlelist.'"/>'.$shop_articlelist.$shop_articlelist1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s614'].'</td><td>{sid}, {aid}</td><td class="longtxt"><input name="shop_article" value="'.$shop_article.'"/>'.$shop_article.$shop_article1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s615'].'</td><td>{sid}, {cid}, {page}</td><td class="longtxt"><input name="shop_imagelist" value="'.$shop_imagelist.'"/>'.$shop_imagelist.$shop_imagelist1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s616'].'</td><td>{sid}, {iid}</td><td class="longtxt"><input name="shop_image" value="'.$shop_image.'"/>'.$shop_image.$shop_image1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s617'].'</td><td>{sid}, {oid}</td><td class="longtxt"><input name="shop_page" value="'.$shop_page.'"/>'.$shop_page.$shop_page1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s618'].'</td><td>{sid}, {page}</td><td class="longtxt"><input name="shop_money" value="'.$shop_money.'"/>'.$shop_money.$shop_money1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s619'].'</td><td>{sid}, {page}</td><td class="longtxt"><input name="shop_visit" value="'.$shop_visit.'"/>'.$shop_visit.$shop_visit1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s620'].'</td><td>{sid}, {page}</td><td class="longtxt"><input name="shop_sc" value="'.$shop_sc.'"/>'.$shop_sc.$shop_sc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_brand_lang['s561'].'</td><td>{pagetype}, {sid}, {oid}, {cid}, {page}</td><td class="longtxt"><input name="brand_wap" value="'.$brand_wap.'"/>'.$brand_wap.$brand_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_brand_lang['s621']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_brand_lang['s622'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_home.$urltype.'$ $1/plugin.php?id=it618_brand:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:list&class1=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:list&class1=$2&class2=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:list&class1=$2&class2=$3&area1=$4&area2=$5&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:list&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_search.$urltype.'$ $1/plugin.php?id=it618_brand:search&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:search&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_gwc.$urltype.'$ $1/plugin.php?id=it618_brand:gwc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_shops.$urltype.'$ $1/plugin.php?id=it618_brand:shops&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_products.$urltype.'$ $1/plugin.php?id=it618_brand:products&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_home.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:shop&sid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_productlist.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:product_list&sid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_productlist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:product_list&sid=$2&cid=$3&page=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_product.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:product&sid=$2&pid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_articlelist.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:article_list&sid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_articlelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:article_list&sid=$2&cid=$3&page=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_article.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:article&sid=$2&aid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_imagelist.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:image_list&sid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_imagelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:image_list&sid=$2&cid=$3&page=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_image.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:image&sid=$2&iid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_page.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:onepage&sid=$2&oid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_money.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:money&sid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_money.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:money&sid=$2&page=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_visit.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:visit&sid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_visit.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:visit&sid=$2&page=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$shop_sc.$urltype.'$ $1/plugin.php?id=it618_brand:sc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_wap.$urltype.'$ $1/plugin.php?id=it618_brand:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:wap&pagetype=$2&sid=$3&oid=$4&cid=$5&page=$6&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$brand_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:wap&pagetype=$2&sid=$3&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_brand_lang['s623'].'</h1>
<pre class="colorbox">
'.$it618_brand_lang['s624'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_home.$urltype.'$ plugin.php?id=it618_brand:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_list.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:list&class1=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:list&class1=$1&class2=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:list&class1=$1&class2=$2&area1=$3&area2=$4&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:list&class1=$1&class2=$2&area1=$3&area2=$4&order=$5&page=$6&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_search.$urltype.'$ plugin.php?id=it618_brand:search&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:search&class1=$1&class2=$2&area1=$3&area2=$4&order=$5&page=$6&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_gwc.$urltype.'$ plugin.php?id=it618_brand:gwc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_shops.$urltype.'$ plugin.php?id=it618_brand:shops&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_products.$urltype.'$ plugin.php?id=it618_brand:products&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_home.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:shop&sid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_productlist.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:product_list&sid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_productlist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:product_list&sid=$1&cid=$2&page=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_product.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:product&sid=$1&pid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_articlelist.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:article_list&sid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_articlelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:article_list&sid=$1&cid=$2&page=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_article.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:article&sid=$1&aid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_imagelist.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:image_list&sid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_imagelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:image_list&sid=$1&cid=$2&page=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_image.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:image&sid=$1&iid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_page.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:onepage&sid=$1&oid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_money.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:money&sid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_money.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:money&sid=$1&page=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_visit.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:visit&sid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_visit.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:visit&sid=$1&page=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$shop_sc.$urltype.'$ plugin.php?id=it618_brand:sc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_wap.$urltype.'$ plugin.php?id=it618_brand:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:wap&pagetype=$1&sid=$2&oid=$3&cid=$4&page=$5&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$brand_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_brand:wap&pagetype=$1&sid=$2&%1</font>

</pre>

<h1>'.$it618_brand_lang['s625'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$brand_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:index&$3
RewriteRule ^(.*)/'.$brand_list.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:list&class1=$2&$4
RewriteRule ^(.*)/'.$brand_list.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:list&class1=$2&class2=$3&$5
RewriteRule ^(.*)/'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:list&class1=$2&class2=$3&area1=$4&area2=$5&$7
RewriteRule ^(.*)/'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:list&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$9
RewriteRule ^(.*)/'.$brand_search.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:search&$3
RewriteRule ^(.*)/'.$brand_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:search&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$9
RewriteRule ^(.*)/'.$brand_gwc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:gwc&$3
RewriteRule ^(.*)/'.$brand_shops.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:shops&$3
RewriteRule ^(.*)/'.$brand_products.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:products&$3
RewriteRule ^(.*)/'.$shop_home.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:shop&sid=$2&$4
RewriteRule ^(.*)/'.$shop_productlist.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:product_list&sid=$2&$4
RewriteRule ^(.*)/'.$shop_productlist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:product_list&sid=$2&cid=$3&page=$4&$6
RewriteRule ^(.*)/'.$shop_product.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:product&sid=$2&pid=$3&$5
RewriteRule ^(.*)/'.$shop_articlelist.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:article_list&sid=$2&$4
RewriteRule ^(.*)/'.$shop_articlelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:article_list&sid=$2&cid=$3&page=$4&$6
RewriteRule ^(.*)/'.$shop_article.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:article&sid=$2&aid=$3&$5
RewriteRule ^(.*)/'.$shop_imagelist.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:image_list&sid=$2&$4
RewriteRule ^(.*)/'.$shop_imagelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:image_list&sid=$2&cid=$3&page=$4&$6
RewriteRule ^(.*)/'.$shop_image.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:image&sid=$2&iid=$3&$5
RewriteRule ^(.*)/'.$shop_page.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:onepage&sid=$2&oid=$3&$5
RewriteRule ^(.*)/'.$shop_money.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:money&sid=$2&$4
RewriteRule ^(.*)/'.$shop_money.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:money&sid=$2&page=$3&$5
RewriteRule ^(.*)/'.$shop_visit.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:visit&sid=$2&$4
RewriteRule ^(.*)/'.$shop_visit.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:visit&sid=$2&page=$3&$5
RewriteRule ^(.*)/'.$shop_sc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:sc&$3
RewriteRule ^(.*)/'.$brand_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:wap&$3
RewriteRule ^(.*)/'.$brand_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:wap&pagetype=$2&sid=$3&oid=$4&cid=$5&page=$6&$8
RewriteRule ^(.*)/'.$brand_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_brand:wap&pagetype=$2&sid=$3&$5</font>

</pre>

<h1>'.$it618_brand_lang['s626'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="brand_home"&gt;
			&lt;match url="^(.*/)*'.$brand_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_list1"&gt;
			&lt;match url="^(.*/)*'.$brand_list.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:list&amp;amp;class1={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_list2"&gt;
			&lt;match url="^(.*/)*'.$brand_list.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_list3"&gt;
			&lt;match url="^(.*/)*'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;area1={R:4}&amp;amp;area2={R:5}&amp;amp;{R:6}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_list4"&gt;
			&lt;match url="^(.*/)*'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;area1={R:4}&amp;amp;area2={R:5}&amp;amp;order={R:6}&amp;amp;page={R:7}&amp;amp;{R:8}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_search"&gt;
			&lt;match url="^(.*/)*'.$brand_search.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:search&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_search1"&gt;
			&lt;match url="^(.*/)*'.$brand_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:search&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;area1={R:4}&amp;amp;area2={R:5}&amp;amp;order={R:6}&amp;amp;page={R:7}&amp;amp;{R:8}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_gwc"&gt;
			&lt;match url="^(.*/)*'.$brand_gwc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:gwc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_shops"&gt;
			&lt;match url="^(.*/)*'.$brand_shops.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:shops&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_products"&gt;
			&lt;match url="^(.*/)*'.$brand_products.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:products&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_home"&gt;
			&lt;match url="^(.*/)*'.$shop_home.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:shop&amp;amp;sid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_productlist1"&gt;
			&lt;match url="^(.*/)*'.$shop_productlist.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:product_list&amp;amp;sid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_productlist2"&gt;
			&lt;match url="^(.*/)*'.$shop_productlist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:product_list&amp;amp;sid={R:2}&amp;amp;cid={R:3}&amp;amp;page={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_product"&gt;
			&lt;match url="^(.*/)*'.$shop_product.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:product&amp;amp;sid={R:2}&amp;amp;pid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_articlelist1"&gt;
			&lt;match url="^(.*/)*'.$shop_articlelist.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:article_list&amp;amp;sid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_articlelist2"&gt;
			&lt;match url="^(.*/)*'.$shop_articlelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:article_list&amp;amp;sid={R:2}&amp;amp;cid={R:3}&amp;amp;page={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_article"&gt;
			&lt;match url="^(.*/)*'.$shop_article.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:article&amp;amp;sid={R:2}&amp;amp;aid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_imagelist1"&gt;
			&lt;match url="^(.*/)*'.$shop_imagelist.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:image_list&amp;amp;sid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_imagelist2"&gt;
			&lt;match url="^(.*/)*'.$shop_imagelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:image_list&amp;amp;sid={R:2}&amp;amp;cid={R:3}&amp;amp;page={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_image"&gt;
			&lt;match url="^(.*/)*'.$shop_image.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:image&amp;amp;sid={R:2}&amp;amp;iid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_page"&gt;
			&lt;match url="^(.*/)*'.$shop_page.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:onepage&amp;amp;sid={R:2}&amp;amp;oid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_money1"&gt;
			&lt;match url="^(.*/)*'.$shop_money.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:money&amp;amp;sid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_money2"&gt;
			&lt;match url="^(.*/)*'.$shop_money.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:money&amp;amp;sid={R:2}&amp;amp;page={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_visit1"&gt;
			&lt;match url="^(.*/)*'.$shop_visit.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:visit&amp;amp;sid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_visit2"&gt;
			&lt;match url="^(.*/)*'.$shop_visit.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:visit&amp;amp;sid={R:2}&amp;amp;page={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="shop_sc"&gt;
			&lt;match url="^(.*/)*'.$shop_sc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:sc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_wap"&gt;
			&lt;match url="^(.*/)*'.$brand_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_wap1"&gt;
			&lt;match url="^(.*/)*'.$brand_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:wap&amp;amp;pagetype={R:2}&amp;amp;sid={R:3}&amp;amp;oid={R:4}&amp;amp;cid={R:5}&amp;amp;{R:6}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="brand_wap2"&gt;
			&lt;match url="^(.*/)*'.$brand_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_brand:wap&amp;amp;pagetype={R:2}&amp;amp;sid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$brand_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:index&$2
endif
match URL into $ with ^(.*)/'.$brand_list.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:list&class1=$2&$3
endif
match URL into $ with ^(.*)/'.$brand_list.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:list&class1=$2&class2=$3&$4
endif
match URL into $ with ^(.*)/'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:list&class1=$2&class2=$3&area1=$4&area2=$5&$6
endif
match URL into $ with ^(.*)/'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:list&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$8
endif
match URL into $ with ^(.*)/'.$brand_search.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:search&$2
endif
match URL into $ with ^(.*)/'.$brand_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:search&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$8
endif
match URL into $ with ^(.*)/'.$brand_gwc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:gwc&$2
endif
match URL into $ with ^(.*)/'.$brand_shops.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:shops&$2
endif
match URL into $ with ^(.*)/'.$brand_products.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:products&$2
endif
match URL into $ with ^(.*)/'.$shop_home.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:shop&sid=$2&$3
endif
match URL into $ with ^(.*)/'.$shop_productlist.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:product_list&sid=$2&$3
endif
match URL into $ with ^(.*)/'.$shop_productlist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:product_list&sid=$2&cid=$3&page=$4&$5
endif
match URL into $ with ^(.*)/'.$shop_product.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:product&sid=$2&pid=$3&$4
endif
match URL into $ with ^(.*)/'.$shop_articlelist.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:article_list&sid=$2&$3
endif
match URL into $ with ^(.*)/'.$shop_articlelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:article_list&sid=$2&cid=$3&page=$4&$5
endif
match URL into $ with ^(.*)/'.$shop_article.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:article&sid=$2&aid=$3&$4
endif
match URL into $ with ^(.*)/'.$shop_imagelist.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:image_list&sid=$2&$3
endif
match URL into $ with ^(.*)/'.$shop_imagelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:image_list&sid=$2&cid=$3&page=$4&$5
endif
match URL into $ with ^(.*)/'.$shop_image.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:image&sid=$2&iid=$3&$4
endif
match URL into $ with ^(.*)/'.$shop_page.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:onepage&sid=$2&oid=$3&$4
endif
match URL into $ with ^(.*)/'.$shop_money.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:money&sid=$2&$3
endif
match URL into $ with ^(.*)/'.$shop_money.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:money&sid=$2&page=$3&$4
endif
match URL into $ with ^(.*)/'.$shop_visit.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:visit&sid=$2&$3
endif
match URL into $ with ^(.*)/'.$shop_visit.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:visit&sid=$2&page=$3&$4
endif
match URL into $ with ^(.*)/'.$shop_sc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:sc&$2
endif
match URL into $ with ^(.*)/'.$brand_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:wap&$2
endif
match URL into $ with ^(.*)/'.$brand_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:wap&pagetype=$2&sid=$3&oid=$4&cid=$5&page=$6&$7
endif
match URL into $ with ^(.*)/'.$brand_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_brand:wap&pagetype=$2&sid=$3&$4
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$brand_home.$urltype.'$ $1/plugin.php?id=it618_brand:index&$2 last;
rewrite ^([^\.]*)/'.$brand_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:list&class1=$2&$3 last;
rewrite ^([^\.]*)/'.$brand_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:list&class1=$2&class2=$3&$4 last;
rewrite ^([^\.]*)/'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:list&class1=$2&class2=$3&area1=$4&area2=$5&$6 last;
rewrite ^([^\.]*)/'.$brand_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:list&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$8 last;
rewrite ^([^\.]*)/'.$brand_search.$urltype.'$ $1/plugin.php?id=it618_brand:search&$2 last;
rewrite ^([^\.]*)/'.$brand_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:search&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$8 last;
rewrite ^([^\.]*)/'.$brand_gwc.$urltype.'$ $1/plugin.php?id=it618_brand:gwc&$2 last;
rewrite ^([^\.]*)/'.$brand_shops.$urltype.'$ $1/plugin.php?id=it618_brand:shops&$2 last;
rewrite ^([^\.]*)/'.$brand_products.$urltype.'$ $1/plugin.php?id=it618_brand:products&$2 last;
rewrite ^([^\.]*)/'.$shop_home.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:shop&sid=$2&$3 last;
rewrite ^([^\.]*)/'.$shop_productlist.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:product_list&sid=$2&$3 last;
rewrite ^([^\.]*)/'.$shop_productlist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:product_list&sid=$2&cid=$3&page=$4&$5 last;
rewrite ^([^\.]*)/'.$shop_product.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:product&sid=$2&pid=$3&$4 last;
rewrite ^([^\.]*)/'.$shop_articlelist.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:article_list&sid=$2&$3 last;
rewrite ^([^\.]*)/'.$shop_articlelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:article_list&sid=$2&cid=$3&page=$4&$5 last;
rewrite ^([^\.]*)/'.$shop_article.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:article&sid=$2&aid=$3&$4 last;
rewrite ^([^\.]*)/'.$shop_imagelist.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:image_list&sid=$2&$3 last;
rewrite ^([^\.]*)/'.$shop_imagelist.'-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:image_list&sid=$2&cid=$3&page=$4&$5 last;
rewrite ^([^\.]*)/'.$shop_image.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:image&sid=$2&iid=$3&$4 last;
rewrite ^([^\.]*)/'.$shop_page.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:onepage&sid=$2&oid=$3&$4 last;
rewrite ^([^\.]*)/'.$shop_money.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:money&sid=$2&$4 last;
rewrite ^([^\.]*)/'.$shop_money.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:money&sid=$2&page=$3&$4 last;
rewrite ^([^\.]*)/'.$shop_visit.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:visit&sid=$2&$4 last;
rewrite ^([^\.]*)/'.$shop_visit.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:visit&sid=$2&page=$3&$4 last;
rewrite ^([^\.]*)/'.$shop_sc.$urltype.'$ $1/plugin.php?id=it618_brand:sc&$2 last;
rewrite ^([^\.]*)/'.$brand_wap.$urltype.'$ $1/plugin.php?id=it618_brand:wap&$2 last;
rewrite ^([^\.]*)/'.$brand_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:wap&pagetype=$2&sid=$3&oid=$4&cid=$5&page=$6&$7 last;
rewrite ^([^\.]*)/'.$brand_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_brand:wap&pagetype=$2&sid=$3&$4 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=15)return;
showtablefooter(); /*dism��taobao��com*/

?>