<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
$n=1;
$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	if(isset($_GET['classid'])){
		if($_GET['classid']==$it618_tmp['id']){
			$licss='class="current"';
			$classid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}else{
		if($n==1){
			$licss='class="current"';
			$classid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_brand_class1')." w WHERE it618_class_id=".$it618_tmp['id']);
	
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_brand_class1&pmod=admin_brand_class&classid=".$it618_tmp['id']."&operation=$operation&do=$do&page=$page\"><span>".$it618_tmp['it618_classname'].'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$n=$n+1;
}
$tmp2=str_replace('<option value='.$classid.'>','<option value='.$classid.' selected="selected">',$tmp);
echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';

$extrasql .= "it618_class_id =".$classid;
$urlsql='&classid='.$classid;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_brand_brand_class1', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_brand#it618_brand_brand_class1')->update($id,array(
				'it618_class_id' => trim($_GET['it618_class_id'][$id]),
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
				'it618_istj' => trim($_GET['it618_istj'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_class_id_array = !empty($_GET['newit618_class_id']) ? $_GET['newit618_class_id'] : array();
	$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	$newit618_istj_array = !empty($_GET['newit618_istj']) ? $_GET['newit618_istj'] : array();
	
	foreach($newit618_classname_array as $key => $value) {
		$newit618_classname = addslashes(trim($newit618_classname_array[$key]));
		
		if($newit618_classname != '') {
			
			C::t('#it618_brand#it618_brand_brand_class1')->insert(array(
				'it618_class_id' => trim($newit618_class_id_array[$key]),
				'it618_classname' => trim($newit618_classname_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
				'it618_istj' => trim($newit618_istj_array[$key])
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}

	cpmsg($it618_brand_lang['s5'].$ok1.' '.$it618_brand_lang['s6'].$ok2.' '.$it618_brand_lang['s7'].$del.')', "action=plugins&identifier=$identifier&cp=admin_brand_class1&pmod=admin_brand_class&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/

$brand_mode=$it618_brand['brand_mode'];
if($brand_mode==2)$it618_brand_lang['s14']='';
showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_brand_class1&pmod=admin_brand_class&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_brand_lang['s782'],'it618_brand_brand_class1');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_brand_class1')." w WHERE $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_brand_class1&pmod=admin_brand_class&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=15>'.$it618_brand_lang['s794'].$count.'<span style="float:right">'.$it618_brand_lang['s802'].'</span></td></tr>';
	showsubtitle(array($it618_brand_lang['s803'], $it618_brand_lang['s804'],$it618_brand_lang['s805'], $it618_brand_lang['s792'],$it618_brand_lang['s806'],$it618_brand_lang['s799'],$it618_brand_lang['s14'],$it618_brand_lang['s801']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." WHERE $extrasql ORDER BY it618_istj desc,it618_order LIMIT $startlimit, $ppp");
	while($it618_brand = DB::fetch($query)) {
		
		if($brand_mode!=2){
			$brandcount = C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1','','',0,0,0,$it618_brand['id']);
		}
		$goodscount = C::t('#it618_brand#it618_brand_goods')->count_by_search('g.it618_ison=1 and g.it618_state=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','',0,0,0,$it618_brand['id']);
		$disabled="";
		if($brandcount>0)$disabled="disabled=\"disabled\"";
		
		$tmp1=str_replace('<option value='.$it618_brand['it618_class_id'].'>','<option value='.$it618_brand['it618_class_id'].' selected="selected">',$tmp);
		if($it618_brand['it618_istj']==1)$it618_istj_checked='checked="checked"';else $it618_istj_checked="";
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id$it618_brand[id]\" name=\"delete[]\" value=\"$it618_brand[id]\" $disabled><label for=\"id$it618_brand[id]\">$it618_brand[id]</label>",
			'<select name="it618_class_id['.$it618_brand[id].']">'.$tmp1.'</select>',
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_classname[$it618_brand[id]]\" value=\"$it618_brand[it618_classname]\">",
			"<input id=\"c".$it618_brand['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_brand[id]]\" value=\"$it618_brand[it618_color]\" onchange=\"updatecolorpreview('c".$it618_brand['id']."')\"><input id=\"c".$it618_brand['id']."\" onclick=\"c".$it618_brand['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_brand['id']."|c".$it618_brand['id']."_v';showMenu({'ctrlid':'c".$it618_brand['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_brand['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_brand['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			'<input class="checkbox" type="checkbox" id="chk_istj'.$n.'" name="it618_istj['.$it618_brand['id'].']" '.$it618_istj_checked.' value="1">',
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_brand['id'].']" value="'.$it618_brand['it618_order'].'">',
			$brandcount,
			$goodscount
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_brand['id']."');";
	}
	
	global $_G;
if($reabc[4]!='8')return; /*Dism_taobao-com*/

	loadcache('plugin');
	$it618_brand = $_G['cache']['plugin']['it618_brand'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_classname[]").length;
		
		return [
		[[1,''], 
		[1,'<select name="newit618_class_id[]">$tmp2</select>'], 
		[1,'<input type="text" class="txt" style="width:200px" name="newit618_classname[]">'],
		[1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'],
		[1,''],
		[1,'<input class="txt" style="width:50px" type="text" name="newit618_order[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/
showtablefooter(); /*dism��taobao��com*/
?>