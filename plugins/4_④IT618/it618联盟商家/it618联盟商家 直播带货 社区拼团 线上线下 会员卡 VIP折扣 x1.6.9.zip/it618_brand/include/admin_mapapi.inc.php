<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$mapapi_bdak=\''.trim($_GET['mapapi_bdak'])."';\n";
		
		$fileData .= '$mapapi_lbsmaptype=\''.trim($_GET['mapapi_lbsmaptype'])."';\n";
		$fileData .= '$mapapi_gdlbskey=\''.trim($_GET['mapapi_gdlbskey'])."';\n";
		$fileData .= '$mapapi_txkey=\''.trim($_GET['mapapi_txkey'])."';\n";
		$fileData .= '$mapapi_lbstime=\''.trim($_GET['mapapi_lbstime'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	cpmsg($it618_brand_lang['s90'], "action=plugins&identifier=$identifier&cp=admin_mapapi&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_mapapi&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1],'it618_brand_set');

if($mapapi_lbsmaptype=='gdmap'){
	$lbsmaptype1='selected="selected"';
	$lbstxmapcss='style="display:none"';
}

if($mapapi_lbsmaptype=='bdmap'){
	$lbsmaptype2='selected="selected"';
	$lbsgdmapcss='style="display:none"';
	$lbstxmapcss='style="display:none"';
}

if($mapapi_lbsmaptype=='txmap'){
	$lbsmaptype3='selected="selected"';
	$lbsgdmapcss='style="display:none"';
}

if($mapapi_lbsmaptype==''){
	$lbsmaptype0='selected="selected"';
	$lbsgdmapcss='style="display:none"';
	$lbstxmapcss='style="display:none"';
	$lbstimecss='style="display:none"';
}

echo '
<tr><td width=110>'.it618_brand_getlang('s1930').'</td><td><input type="text" class="txt" style="width:300px;margin-bottom:3px" name="mapapi_bdak" value="'.$mapapi_bdak.'"><font color=#999>'.it618_brand_getlang('s1931').'</font></td></tr>

<tr><td colspan=2></td></tr>

<tr><td>'.it618_brand_getlang('s1932').'</td><td><select name="mapapi_lbsmaptype" onchange="getlbsmaptype(this.value)"><option value="gdmap" '.$lbsmaptype1.'>'.it618_brand_getlang('s1933').'</option><option value="bdmap" '.$lbsmaptype2.'>'.it618_brand_getlang('s1934').'</option><option value="txmap" '.$lbsmaptype3.'>'.it618_brand_getlang('s1935').'</option><option value="" '.$lbsmaptype0.'>'.it618_brand_getlang('s1943').'</option></select> <font color=#999>'.it618_brand_getlang('s1936').'</font></td></tr>
<tr id="trgdmap1" '.$lbsgdmapcss.'><td>'.it618_brand_getlang('s1937').'</td><td><input type="text" class="txt" style="width:300px;margin-bottom:3px" name="mapapi_gdlbskey" value="'.$mapapi_gdlbskey.'"><font color=#999>'.it618_brand_getlang('s1938').'</font></td></tr>
<tr id="trtxmap1" '.$lbstxmapcss.'><td>'.it618_brand_getlang('s1939').'</td><td><input type="text" class="txt" style="width:300px;margin-bottom:3px" name="mapapi_txkey" value="'.$mapapi_txkey.'"><font color=#999>'.it618_brand_getlang('s1940').'</font></td></tr>
<tr id="trlbstime" '.$lbstimecss.'><td>'.it618_brand_getlang('s1941').'</td><td><input type="text" class="txt" style="width:68px;margin-bottom:3px" name="mapapi_lbstime" value="'.$mapapi_lbstime.'"><font color=#999>'.it618_brand_getlang('s1942').'</font></td></tr>

<script>
function getlbsmaptype(objvalue){
	document.getElementById("trgdmap1").style.display="none";
	document.getElementById("trtxmap1").style.display="none";
	document.getElementById("trlbstime").style.display="none";
	if(objvalue=="gdmap"){
		document.getElementById("trgdmap1").style.display="";
	}
	if(objvalue=="txmap"){
		document.getElementById("trtxmap1").style.display="";
	}
	if(objvalue!=""){
		document.getElementById("trlbstime").style.display="";
	}
}
</script>
';

showsubmit('it618submit', $it618_brand_lang['s828']);
if(count($reabc)!=12)return;
showtablefooter(); /*dism��taobao��com*/

?>