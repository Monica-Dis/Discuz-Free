<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql = "b.it618_state=2 and b.it618_htstate=1";
$state0='';$state1='';$state2='';$state3='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and g.it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and g.it618_state = 1";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and g.it618_state = 2";$state3='selected="selected"';}

$saletype0='';$saletype1='';$saletype2='';$saletype3='';$saletype4='';
if($_GET['saletype']==0){$saletype0='selected="selected"';}
if($_GET['saletype']==1){$it618sql .= " and g.it618_saletype = 1";$saletype1='selected="selected"';}
if($_GET['saletype']==2){$it618sql .= " and g.it618_saletype = 2";$saletype2='selected="selected"';}
if($_GET['saletype']==3){$it618sql .= " and g.it618_saletype = 3";$saletype3='selected="selected"';}
if($_GET['saletype']==4){$it618sql .= " and g.it618_saletype = 4";$saletype3='selected="selected"';}

$paytype0='';$paytype1='';$paytype2='';
if($_GET['paytype']==0){$paytype0='selected="selected"';}
if($_GET['paytype']==1){$it618sql .= " and g.it618_isduihuan = 1";$paytype1='selected="selected"';}
if($_GET['paytype']==2){$it618sql .= " and g.it618_isalipay = 1";$paytype2='selected="selected"';}

$order0='';$order1='';$order2='';$order3='';$order4='';
if($_GET['order']==0){$orderby = "g.it618_brandorder desc";$order0='selected="selected"';}
if($_GET['order']==1){$orderby = "g.id desc";$order1='selected="selected"';}
if($_GET['order']==2){$orderby = "g.it618_brandorder desc";$order2='selected="selected"';}
if($_GET['order']==3){$orderby = "g.it618_salecount desc";$order3='selected="selected"';}
if($_GET['order']==4){$orderby = "g.it618_views desc";$order3='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'].'&saletype='.$_GET['saletype'].'&paytype='.$_GET['paytype'].'&order='.$_GET['order'];

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_brandorder'])) {
		foreach($_GET['it618_brandorder'] as $id => $val) {
			C::t('#it618_brand#it618_brand_goods')->update($id,array(
				'it618_ison' => $_GET['it618_ison'][$id],
				'it618_brandorder' => $_GET['it618_brandorder'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_brand_lang['s1599'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_brand_goods=C::t('#it618_brand#it618_brand_goods')->fetch_by_id($delid);
		
		if($it618_brand_goods['it618_state']==0){
			DB::query("update ".DB::table('it618_brand_goods')." set it618_state=1 where id=".$delid);
			$ok=$ok+1;
		}
	}
	cpmsg($it618_brand_lang['s1593'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='a')return; /*Dism_taobao_com*/

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_brand_goods=C::t('#it618_brand#it618_brand_goods')->fetch_by_id($delid);
		
		if($it618_brand_goods['it618_state']==0){
			DB::query("update ".DB::table('it618_brand_goods')." set it618_state=2 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_brand_lang['s1594'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/

$tmp='<option value="0">'.$it618_brand_lang['s1600'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1".$urlsql);
showtableheaders($it618_brand_lang['s230'],'it618_brand_goods');
	showsubmit('it618sercsubmit', $it618_brand_lang['s34'], $it618_brand_lang['s231'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:90px" /> '.$it618_brand_lang['s41'].' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.$it618_brand_lang['s1601'].'</option></select> '.$it618_brand_lang['s1602'].' <select name="saletype"><option value=0 '.$saletype0.'>'.$it618_brand_lang['s1603'].'</option><option value=1 '.$saletype1.'>'.$it618_brand_lang['s1002'].'</option><option value=2 '.$saletype2.'>'.$it618_brand_lang['s1003'].'</option><option value=3 '.$saletype3.'>'.$it618_brand_lang['s1223'].'</option><option value=4 '.$saletype4.'>'.$it618_brand_lang['s1224'].'</option></select> '.$it618_brand_lang['s1604'].' <select name="paytype"><option value=0 '.$paytype0.'>'.$it618_brand_lang['s1605'].'</option><option value=1 '.$paytype1.'>'.$it618_brand_lang['s1606'].'</option><option value=2 '.$paytype2.'>'.$it618_brand_lang['s1607'].'</option></select> '.$it618_brand_lang['s1587'].' <select name="state"><option value=0 '.$state0.'>'.$it618_brand_lang['s956'].'</option><option value=1 '.$state1.'>'.$it618_brand_lang['s1596'].'</option><option value=2 '.$state2.'>'.$it618_brand_lang['s1597'].'</option><option value=3 '.$state3.'>'.$it618_brand_lang['s1598'].'</option></select> '.$it618_brand_lang['s1609'].' <select name="order"><option value=0 '.$order0.'>'.$it618_brand_lang['s147'].'</option><option value=1 '.$order1.'>'.$it618_brand_lang['s1610'].'</option><option value=2 '.$order2.'>'.$it618_brand_lang['s1611'].'</option><option value=3 '.$order3.'>'.$it618_brand_lang['s1612'].'</option><option value=4 '.$order4.'>'.$it618_brand_lang['s1613'].'</option></select>');
	
	$count = C::t('#it618_brand#it618_brand_goods')->count_by_search($it618sql,'',0,0,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['key'],$_GET['price1'],$_GET['price2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	echo '<tr><td colspan=14>'.$it618_brand_lang['s250'].$count.'<span style="float:right;color:red">'.$it618_brand_lang['s1595'].'</span></td></tr>';
	showsubtitle(array('',it618_brand_getlang('s259'),it618_brand_getlang('s1590'),it618_brand_getlang('s1094').'/'.it618_brand_getlang('s1095'),it618_brand_getlang('s1586'),it618_brand_getlang('s1587'),it618_brand_getlang('s1588')));
	
	$n=1;
	foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_search(
			$it618sql,$orderby,0,0,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['key'],0,0,$startlimit,$ppp
		) as $it618_brand_goods) {

		if($it618_brand_goods['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked='';
		if($it618_brand_goods['it618_istj']==1)$it618_istj_checked='checked="checked" disabled="disabled"';else $it618_istj_checked='disabled="disabled"';
		if($it618_brand_goods['it618_isorderbuy']==1)$it618_isorderbuy_checked='checked="checked" disabled="disabled"';else $it618_isorderbuy_checked='disabled="disabled"';
		if($it618_brand_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked" disabled="disabled"';else $it618_isbm_checked='disabled="disabled"';
		
		if($it618_brand_goods['it618_isduihuan']==1)$it618_isduihuan_checked='checked="checked" disabled="disabled"';else $it618_isduihuan_checked='disabled="disabled"';
		if($it618_brand_goods['it618_isalipay']==1)$it618_isalipay_checked='checked="checked" disabled="disabled"';else $it618_isalipay_checked='disabled="disabled"';
		
		if($it618_brand_goods['it618_saletype']==1)$it618_saletype=$it618_brand_lang['s1002'];
		if($it618_brand_goods['it618_saletype']==2)$it618_saletype=$it618_brand_lang['s1003'];
		if($it618_brand_goods['it618_saletype']==3)$it618_saletype=$it618_brand_lang['s1223'];
		if($it618_brand_goods['it618_saletype']==4)$it618_saletype=$it618_brand_lang['s1002'].'+'.$it618_brand_lang['s1003'];
		
		if($it618_brand_goods['it618_xgtype']==0)$it618_xgtype=$it618_brand_lang['s1361'];
		if($it618_brand_goods['it618_xgtype']==1)$it618_xgtype=$it618_brand_lang['s1362'].$it618_brand_lang['s1533'].$it618_brand_goods['it618_xgtime1'].'<br>- '.$it618_brand_goods['it618_xgtime2'];
		if($it618_brand_goods['it618_xgtype']==2)$it618_xgtype=$it618_brand_lang['s1363'].$it618_brand_lang['s1533'].$it618_brand_goods['it618_xgtime1'].'<br>- '.$it618_brand_goods['it618_xgtime2'];
		
		if($it618_brand_goods['it618_isyunfeifree']==0)$it618_isyunfeifree=it618_brand_getlang('s1498');
		if($it618_brand_goods['it618_isyunfeifree']==1)$it618_isyunfeifree=it618_brand_getlang('s1499');
		if($it618_brand_goods['it618_isyunfeifree']==2)$it618_isyunfeifree=it618_brand_getlang('s1500');
		
		if($it618_brand_goods['it618_state']==0)$it618_state='<font color=red>'.$it618_brand_lang['s1596'].'</font>';
		if($it618_brand_goods['it618_state']==1)$it618_state='<font color=green>'.$it618_brand_lang['s1597'].'</font>';
		if($it618_brand_goods['it618_state']==2)$it618_state='<font color=blue>'.$it618_brand_lang['s1598'].'</font>';
		
		$it618_xiangou='';
		if($it618_brand_goods['it618_xiangoutime']!=0){
			$it618_xiangou='<br>'.it618_brand_getlang('s1097').''.$it618_brand_goods[it618_xiangoutime].''.it618_brand_getlang('s1015').''.$it618_brand_goods[it618_xiangoucount].''.it618_brand_getlang('s1105');
		}
		
		$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
		
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_km')." WHERE it618_pid=".$it618_brand_goods['id']);
		
		if($it618_brand_goods[it618_punit]=='')$it618_punit=it618_brand_getlang('s1105');else $it618_punit=$it618_brand_goods[it618_punit];
		
		$preurl="plugin.php?id=it618_brand:sc_product&adminsid=".$it618_brand_goods['it618_shopid'].$urlsql."&page=$page";
		$preurl=str_replace("&","@",$preurl);
		
		$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_brand_goods[id].'"><label for="chk_del'.$n.'">'.$it618_brand_goods['id'].'</label>',
			'<a href="'.$tmpurl.'" target="_blank" title="'.it618_brand_classname($it618_brand_goods['it618_class_id']).'"><div style="width:380px"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="69" height="69" style="float:left"/><div style="float:left;width:300px;margin-left:10px;"><span style="font-size:13px">'.$it618_brand_goods[it618_name].'</span>[<a href="plugin.php?id=it618_brand:sc_product_edit&adminsid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods[id].'" target="_blank"><font color=red>'.$it618_brand_lang['s109'].'</font></a>]<br><font color=#999>'.$it618_brand_goods[it618_seodescription].'</font><br>'.it618_brand_getlang('s1359').'<font color="red">'.$salecount.'</font> '.it618_brand_getlang('s1360').'<font color="red">'.$it618_brand_goods[it618_views].'</font></div></div></a>',
			'<font color=red><b>'.$it618_brand_goods[it618_uprice].'</b></font> '.it618_brand_getlang('s389').'/'.$it618_brand_goods[it618_price].' '.it618_brand_getlang('s389').'/<font color=green><b>'.$it618_brand_goods[it618_score].'</b></font>/'.$it618_brand_goods[it618_count].' '.$it618_punit.$it618_xiangou.'<br>'.$it618_xgtype,
			$it618_saletype.'<br><input class="checkbox" type="checkbox" '.$it618_isduihuan_checked.' value="1"><label><font color=red>'.it618_brand_getlang('s1101').'</font></label><input class="checkbox" type="checkbox" '.$it618_isalipay_checked.' value="1" onclick="setpaytype(this.value)"><label>'.it618_brand_getlang('s1102').'</label><span id="payspan'.$n.'"><br>'.$it618_isyunfeifree.'<br>'.it618_brand_getlang('s1297').'<font color=green><b>'.$it618_brand_goods[it618_jfbl].'</b></font>%</span>',
			'<input class="checkbox" type="checkbox" '.$it618_isbm_checked.' value="1"><label>'.it618_brand_getlang('s257').'</label> <input class="checkbox" type="checkbox" '.$it618_ison_checked.' value="1" id="chk_ison'.$it618_brand_goods['id'].'" name="it618_ison['.$it618_brand_goods['id'].']"><label for="chk_ison'.$it618_brand_goods['id'].'">'.it618_brand_getlang('s240').'</label><br><input class="checkbox" type="checkbox" '.$it618_istj_checked.' value="1"><label>'.it618_brand_getlang('s242').'</label> <input class="checkbox" type="checkbox" '.$it618_isorderbuy_checked.' value="1"><label><font color=blue>'.it618_brand_getlang('s1507').'</font></label>',
			$it618_state,
			'<input type="text" class="txt" style="width:50px" name="it618_brandorder['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_brandorder].'">'
		));
				
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_brand_class'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
	$n1=1;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$n2=1;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$it618_tmp1['id']." ORDER BY it618_order");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
	
	echo '
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	
	'.$jstmp.'
	</script>';
	
	function it618_brand_classname($pid){
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);
		$brandclassname=C::t('#it618_brand#it618_brand_brand_class')->fetch_it618_name_by_id($it618_brand_goods['it618_brandclass_id']);
		$brandclassname1=C::t('#it618_brand#it618_brand_brand_class1')->fetch_it618_name_by_id($it618_brand_goods['it618_brandclass1_id']);
		$classname=C::t('#it618_brand#it618_brand_class')->fetch_it618_classname_by_id($it618_brand_goods['it618_class_id']);
		
		$strtmp=it618_brand_getlang('s1581').$brandclassname.' - '.$brandclassname1."\n".it618_brand_getlang('s270').$classname;
		return $strtmp;
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_brand_lang['s70'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_edit" value="'.$it618_brand_lang['s1589'].'"/> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_brand_lang['s1591'].'"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_brand_lang['s1592'].'" \')" /><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/
showtablefooter(); /*dism��taobao��com*/

?>