<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$ok1=0;
	
	if($reabc[8]!='a')return; /*Dism_taobao_com*/

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_brand#it618_brand_brand_class')->update($id,array(
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_classnamenav' => trim($_GET['it618_classnamenav'][$id]),
				'it618_brandcount' => trim($_GET['it618_brandcount'][$id]),
				'it618_wapbrandcount' => trim($_GET['it618_wapbrandcount'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_url' => trim($_GET['it618_url'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	cpmsg($it618_brand_lang['s90'], "action=plugins&identifier=$identifier&cp=admin_brand_class&pmod=admin_brand_class&operation=$operation&do=$do&page=$page", 'succeed');
}

if(C::t('#it618_brand#it618_brand_set')->count_by_setname('brandclass')==0){
	C::t('#it618_brand#it618_brand_set')->insert(array(
		'setname' => 'brandclass',
		'setvalue' => '1'
	), true);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods'));
	while($it618_brand_goods =	DB::fetch($query)) {
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
		DB::query("update ".DB::table('it618_brand_goods')." set it618_brandclass_id=".$it618_brand_brand['it618_class_id'].",it618_brandclass1_id=".$it618_brand_brand['it618_class1_id']." WHERE id=".$it618_brand_goods['id']);
	}
}

if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/

$brand_mode=$it618_brand['brand_mode'];

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_brand_class&pmod=admin_brand_class&operation=$operation&do=$do");
showtableheaders($it618_brand_lang['s781'],'it618_brand_brand_class');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_brand_class')." w WHERE id<=8 $extrasql");
	
	if($brand_mode==2)$it618_brand_lang['s14']='';
	echo '<tr><td colspan=10>'.$it618_brand_lang['s794'].$count.'<span style="float:right;color:red">'.$it618_brand_lang['s795'].'</span></td></tr>';
	showsubtitle(array($it618_brand_lang['s796'],$it618_brand_lang['s797'],$it618_brand_lang['s798'],$it618_brand_lang['s1372'].'/'.$it618_brand_lang['s1373'],$it618_brand_lang['s799'],$it618_brand_lang['s800'],$it618_brand_lang['s14'],$it618_brand_lang['s801']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." WHERE id<=8 $extrasql ORDER BY it618_order");
	while($it618_brand = DB::fetch($query)) {
		$class2count = C::t('#it618_brand#it618_brand_brand_class1')->count_by_it618_class_id($it618_brand['id']);
		
		if($brand_mode!=2){
			$brandcount = C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1','','',0,0,$it618_brand['id']);
		}
		$goodscount = C::t('#it618_brand#it618_brand_goods')->count_by_search('g.it618_ison=1 and g.it618_state=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','',0,0,$it618_brand['id']);
		
		$it618_img='';
		if($it618_brand['it618_img']!='')$it618_img='src="'.$it618_brand['it618_img'].'"';
		
		showtablerow('', array('', '', '', '', ''), array(
			"<input type=\"text\" class=\"txt\" style=\"width:100px\" name=\"it618_classname[$it618_brand[id]]\" value=\"$it618_brand[it618_classname]\">cid=$it618_brand[id]",
			"<input type=\"text\" class=\"txt\" style=\"width:40px\" name=\"it618_classnamenav[$it618_brand[id]]\" value=\"$it618_brand[it618_classnamenav]\">",
			'<input class="txt" type="text" style="width:68px;margin-right:0" name="it618_brandcount['.$it618_brand['id'].']" value="'.$it618_brand['it618_brandcount'].'">/<input class="txt" type="text" style="width:68px" name="it618_wapbrandcount['.$it618_brand['id'].']" value="'.$it618_brand['it618_wapbrandcount'].'">',
			'<img '.$it618_img.' id="img'.$it618_brand['id'].'" width="100" height="25" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url'.$it618_brand['id'].'" style="width:30px" name="it618_img['.$it618_brand['id'].']" readonly="readonly" value="'.$it618_brand['it618_img'].'" /> <input type="button" id="image'.$it618_brand['id'].'" value="'.$it618_brand_lang['s821'].'" /><input type="button" value="'.$it618_brand_lang['s458'].'" onclick="document.getElementById(\'url'.$it618_brand['id'].'\').value=\'\';document.getElementById(\'img'.$it618_brand['id'].'\').src=\'\'" />/<input class="txt" type="text" style="width:200px;" name="it618_url['.$it618_brand['id'].']" value="'.$it618_brand['it618_url'].'">',
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_brand['id'].']" value="'.$it618_brand['it618_order'].'">',
			$class2count,
			$brandcount,
			$goodscount
		));
		
		$editorjs.='K(\'#image'.$it618_brand['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_brand['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_brand['id'].'\').val(url);
								K(\'#img'.$it618_brand['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
		echo '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	
	echo '<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" id="submit_it618submit" name="it618submit" value="'.$it618_brand_lang['s120'].'" /> <font color=red>'.$it618_brand_lang['s1371'].'</font></div></td></tr>';

	if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/
showtablefooter(); /*dism��taobao��com*/
?>