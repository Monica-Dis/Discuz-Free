<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/templateset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_brand/config/templateset.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/config/templateset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$template_set[\'pcname\']=\''.trim($_GET['template_pcname'])."';\n";
		$fileData .= '$template_set[\'wapname\']=\''.trim($_GET['template_wapname'])."';\n";
		$fileData .= '$template_set[\'adminname\']=\''.trim($_GET['template_adminname'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_brand_lang['s1981'], "action=plugins&identifier=$identifier&cp=admin_template&cp1=$cp1&pmod=admin_style&operation=$operation&do=$do&page=$page", 'succeed');
}

$pcnameoption='<option value="default">'.$it618_brand_lang['s1010'].'</option>';
$pcnameoption=str_replace('<option value="'.$template_set['pcname'].'"','<option value="'.$template_set['pcname'].'" selected="selected"',$pcnameoption);

$wapnameoption='<option value="default_wap">'.$it618_brand_lang['s1010'].'</option>';
$wapnameoption=str_replace('<option value="'.$template_set['wapname'].'"','<option value="'.$template_set['wapname'].'" selected="selected"',$wapnameoption);

$adminnameoption='<option value="sc">'.$it618_brand_lang['s1979'].'</option>';
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/template/sc_proton/sc_index.htm')){
	$adminnameoption.='<option value="sc_proton">'.$it618_brand_lang['s1980'].'</option>';
}
$adminnameoption=str_replace('<option value="'.$template_set['adminname'].'"','<option value="'.$template_set['adminname'].'" selected="selected"',$adminnameoption);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_template&cp1=$cp1&pmod=admin_style&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_brand_lang['s1983'].'</th></tr>
<tr class="header"><th width=180>'.$it618_brand_lang['s1974'].'</th><th>'.$it618_brand_lang['s1974'].'</th><th>'.$it618_brand_lang['s1975'].'</th></tr>

<tr class="hover" style="display:none">
<td>'.$it618_brand_lang['s1008'].'</td><td class="longtxt">
<select name="template_pcname">
	'.$pcnameoption.'
</select></td>
<td>'.$it618_brand_lang['s1012'].'</td>
</tr>

<tr class="hover" style="display:none">
<td>'.$it618_brand_lang['s1009'].'</td><td class="longtxt">
<select name="template_wapname">
	'.$wapnameoption.'
</select></td>
<td>'.$it618_brand_lang['s1012'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_brand_lang['s1977'].'</td><td class="longtxt">
<select name="template_adminname">
	'.$adminnameoption.'
</select></td>
<td>'.$it618_brand_lang['s1978'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_brand_lang['s1982']);

if(count($reabc)!=10)return; /*dis'.'m.tao'.'bao.com*/
showtablefooter(); /*dism��taobao��com*/

?>