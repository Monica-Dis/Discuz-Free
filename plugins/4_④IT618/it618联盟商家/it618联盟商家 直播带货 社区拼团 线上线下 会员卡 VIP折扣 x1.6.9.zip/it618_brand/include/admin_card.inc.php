<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$sql='&key='.$_GET['key'];

if(submitcheck('it618submit_del')){
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_brand_card', "id=$delid");
		$del=$del+1;
	}
	
	cpmsg(it618_brand_getlang('s7').$del, "action=plugins&identifier=$identifier&cp=admin_card&pmod=admin_card&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit')){
	$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_brand_card'));
	while($row = DB::fetch($query)) {
		$col_field[]=$row['Field']; 
	}
	if(!in_array('it618_name', $col_field)){
		$sql = "Alter table ".DB::table('it618_brand_card')." add `it618_name` varchar(10) NOT NULL;"; 
		DB::query($sql);
	}
	
	$ok1=0;

	if(is_array($_GET['it618_cardid'])) {
		foreach($_GET['it618_cardid'] as $id => $val) {

			C::t('#it618_brand#it618_brand_card')->update($id,array(
				'it618_name' => $_GET['it618_name'][$id],
				'it618_cardid' => $_GET['it618_cardid'][$id],
				'it618_tel' => $_GET['it618_tel'][$id]
			));
			$ok1=$ok1+1;
		}
	}
	
	cpmsg(it618_brand_getlang('s5').$ok1, "action=plugins&identifier=$identifier&cp=admin_card&pmod=admin_card&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok1=0;

	foreach($_GET['delete'] as $key => $delid) {
		$it618_brand_card=C::t('#it618_brand#it618_brand_card')->fetch_by_id($delid);
		if($it618_brand_card['it618_state']==0&&$it618_brand_card['it618_cardid']!=''&&$it618_brand_card['it618_tel']!=''){
			C::t('#it618_brand#it618_brand_card')->update($delid,array(
				'it618_state' => 1
			));
			$ok1=$ok1+1;
		}
	}

	cpmsg($it618_brand_lang['s1437'].$ok1, "action=plugins&identifier=$identifier&cp=admin_card&pmod=admin_card&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_dao')){
	$ok1=0;
	if (preg_match('/\.\./', $_GET['it618_name_dao'])) {
		cpmsg(it618_brand_getlang('s1227').$file_path, "action=plugins&identifier=$identifier&cp=admin_card&pmod=admin_card&operation=$operation&do=$do&page=$page".$sql, 'error');
	}
	
	$tmparr=explode("source/plugin/it618_brand/kindeditor",$_GET['it618_name_dao']);
	$file_path='source/plugin/it618_brand/kindeditor'.$tmparr[1];
	
	if (!file_exists($file_path)) {
		cpmsg(it618_brand_getlang('s1227').$file_path, "action=plugins&identifier=$identifier&cp=admin_card&pmod=admin_card&operation=$operation&do=$do&page=$page".$sql, 'error');
	}
	
	$lines = dfsockopen($_G['siteurl'].$file_path);
	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	ini_set('memory_limit', '-1');
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $lines);
	$line=explode("@||@",$lines);
	$ok1=0;

	foreach($line as $key =>$li)
	{
		if(trim($li)!=''){
			$tmpliarr=explode(',',$li);
			if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".intval($tmpliarr[1]))>0){
				$count=C::t('#it618_brand#it618_brand_card')->count_by_uid_cardid_tel($tmpliarr[1],$tmpliarr[2],$tmpliarr[3]);
				if($count==0){
					C::t('#it618_brand#it618_brand_card')->insert(array(
						'it618_name' => $tmpliarr[0],
						'it618_uid' => $tmpliarr[1],
						'it618_cardid' => $tmpliarr[2],
						'it618_tel' => $tmpliarr[3],
						'it618_state' => 1
					), true);
					$ok1=$ok1+1;
				}
			}
		}
	}
	@unlink($file_path);
	
	cpmsg($it618_brand_lang['s1438'].$ok1, "action=plugins&identifier=$identifier&cp=admin_card&pmod=admin_card&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_card&pmod=admin_card&operation=$operation&do=$do");
showtableheaders($it618_brand_lang['s1439'],'it618_brand_card');
showsubmit('it618sercsubmit', $it618_brand_lang['s34'], $it618_brand_lang['s35'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:180px" />');

	$count = C::t('#it618_brand#it618_brand_card')->count_by_search($it618sql,'',$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_card&pmod=admin_card&operation=$operation&do=$do".$sql);
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script>
	KindEditor.ready(function(K) {
				var uploadbutton = K.uploadbutton({
					button : K(\'#btn_upfile\')[0],
					fieldName : \'imgFile\',
					url : \'source/plugin/it618_brand/kindeditor/php/upload_json.php?dir=file&filetype=txt\',
					afterUpload : function(data) {
						if (data.error === 0) {
							var url = K.formatUrl(data.url, \'absolute\');
							K(\'#it618_name_dao\').val(url);
						} else {
							alert(data.message);
						}
					},
					afterError : function(str) {
						alert(str);
					}
				});
				uploadbutton.fileBox.change(function(e) {
					uploadbutton.submit();
				});
			});
</script>';

	echo '<tr><td colspan=14>'.$it618_brand_lang['s1440'].$count.'<span style="float:right;color:red">'.$it618_brand_lang['s1441'].'</span></td></tr>';
	showsubtitle(array('', $it618_brand_lang['s1442'],$it618_brand_lang['s1695'],$it618_brand_lang['s1443'],$it618_brand_lang['s1444'],$it618_brand_lang['s1445'],$it618_brand_lang['s1446'],$it618_brand_lang['s1447'],$it618_brand_lang['s1448'],$it618_brand_lang['s1449'],$it618_brand_lang['s1450']));
	
	foreach(C::t('#it618_brand#it618_brand_card')->fetch_all_by_search(
		$it618sql,'it618_cardid',$_GET['key'],$startlimit,$ppp
	) as $it618_brand_card) {
		
		$username=C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($it618_brand_card['it618_uid']);
		$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$it618_brand_card['it618_uid']);
		if($creditnum=="")$creditnum=0;
		
		$moneycount=C::t('#it618_brand#it618_brand_money')->count_by_shopid(0,0,0,0,$it618_brand_card['it618_uid']);
		$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(1,$moneycount);
		$tmplevelarr=explode(",",$it618_brand['brand_level']);
		
		$fetch_sum_by_uid=C::t('#it618_brand#it618_brand_cardmoney')->fetch_sum_by_uid($it618_brand_card['it618_uid']);
		
		if($it618_brand_card['it618_state']==0)$it618_state='<font color=red>'.$it618_brand_lang['s1451'].'</font>';
		if($it618_brand_card['it618_state']==1)$it618_state='<font color=green>'.$it618_brand_lang['s1452'].'</font>';
		
		$allmoney=$fetch_sum_by_uid['m1']+$fetch_sum_by_uid['m2'];
		if($allmoney>0)$disabled='disabled="disabled"';else $disabled='';
		
		showtablerow('', array('class="td25"', '', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_brand_card[id]\" $disabled>",
			'<a href="home.php?mod=space&uid='.$it618_brand_card['it618_uid'].'" target="_blank">'.$username.'(<b>'.$it618_brand_card['it618_uid'].'</b>)',
			'<input type="text" class="txt" style="width:50px;" name="it618_name['.$it618_brand_card[id].']" value="'.$it618_brand_card['it618_name'].'">',
			'<input type="text" class="txt" style="width:180px;" name="it618_cardid['.$it618_brand_card[id].']" value="'.$it618_brand_card['it618_cardid'].'">',
			'<input type="text" class="txt" style="width:100px;" name="it618_tel['.$it618_brand_card[id].']" value="'.$it618_brand_card['it618_tel'].'">',
			'<a href="'.$it618_brand['brand_levelurl'].'" target="_blank" title="'.$it618_brand_level['it618_name'].' '.$it618_brand['brand_leveltitle'].'"><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'"></a>',
			$creditnum,
			$fetch_sum_by_uid['c1'].'/'.$fetch_sum_by_uid['m1'].' '.it618_brand_getlang('s389'),
			$fetch_sum_by_uid['c2'].'/'.$fetch_sum_by_uid['m2'].' '.it618_brand_getlang('s389'),
			$allmoney.' '.it618_brand_getlang('s389'),
			$it618_state
		));
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallYqAG" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallYqAG">'.$it618_brand_lang['s1453'].'</label></td><td colspan="15"><div class="fixsel"><input type="submit" class="btn" id="submit_it618submit" name="it618submit_del" value="'.$it618_brand_lang['s1454'].'" onclick="return confirm(\''.$it618_brand_lang['s1455'].'\')"/> <input type="submit" class="btn" id="submit_it618submit" name="it618submit" value="'.$it618_brand_lang['s1456'].'" /> <input type="submit" class="btn" id="submit_it618submit" name="it618submit_pass" value="'.$it618_brand_lang['s1457'].'"  onclick="return confirm(\''.$it618_brand_lang['s1458'].'\')"/> '.$it618_brand_lang['s1459'].' &nbsp;<input type=hidden value='.$page.' name=page />'.$multipage.'</div></td></tr>';
	
	echo '<tr><td colspan=14>'.$it618_brand_lang['s1460'].'<br><input id="it618_name_dao" name="it618_name_dao" class="txt" style="width:300px"><input type="submit" class="btn" id="btn_upfile" value="'.$it618_brand_lang['s1461'].'"/> '.$it618_brand_lang['s1462'].'<br><input type="submit" class="btn" name="it618submit_dao" value="'.$it618_brand_lang['s1463'].'"/></td></tr>';

	if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/
showtablefooter(); /*dism��taobao��com*/
?>