<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_video = $_G['cache']['plugin']['it618_video'];

$it618_type=$cp1-6;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_brand#it618_brand_brandgroup')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_groupname'])) {
		foreach($_GET['it618_groupname'] as $id => $val) {
			$it618_isgoods=$_GET['it618_isgoods'][$id];
			if($_GET['it618_issaletype1'][$id]==0&&$_GET['it618_issaletype2'][$id]==0&&$_GET['it618_issaletype3'][$id]==0&&$_GET['it618_issaletype4'][$id]==0&&$_GET['it618_issaletype5'][$id]==0)$it618_isgoods=0;
			
			if($it618_isgoods==1){
				$it618_issaletype1=$_GET['it618_issaletype1'][$id];
				$it618_issaletype2=$_GET['it618_issaletype2'][$id];
				$it618_issaletype3=$_GET['it618_issaletype3'][$id];
				$it618_issaletype4=$_GET['it618_issaletype4'][$id];
				$it618_issaletype5=$_GET['it618_issaletype5'][$id];
				$it618_ispaytype1=$_GET['it618_ispaytype1'][$id];
				$it618_ispaytype2=$_GET['it618_ispaytype2'][$id];
				$it618_isorder=$_GET['it618_isorder'][$id];
				$it618_ispjpic=$_GET['it618_ispjpic'][$id];
			}else{
				$it618_issaletype1=0;
				$it618_issaletype2=0;
				$it618_issaletype3=0;
				$it618_issaletype4=0;
				$it618_issaletype5=0;
				$it618_ispaytype1=0;
				$it618_ispaytype2=0;
				$it618_isorder=0;
				$it618_ispjpic=0;
			}
			
			if($it618_isgoods==0&&$_GET['it618_issaleout'][$id]==0){
				$it618_isuservip=0;
			}else{
				$it618_isuservip=$_GET['it618_isuservip'][$id];
			}
			
			C::t('#it618_brand#it618_brand_brandgroup')->update($id,array(
				'it618_groupname' => trim($_GET['it618_groupname'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_isgoods' => $it618_isgoods,
				'it618_isouturl' => $_GET['it618_isouturl'][$id],
				'it618_goodscount' => $_GET['it618_goodscount'][$id],
				'it618_issaleagain' => $_GET['it618_issaleagain'][$id],
				'it618_issaletype1' => $it618_issaletype1,
				'it618_issaletype2' => $it618_issaletype2,
				'it618_issaletype3' => $it618_issaletype3,
				'it618_issaletype4' => $it618_issaletype4,
				'it618_issaletype5' => $it618_issaletype5,
				'it618_ispaytype1' => $it618_ispaytype1,
				'it618_ispaytype2' => $it618_ispaytype2,
				'it618_isorder' => $it618_isorder,
				'it618_ispjpic' => $it618_ispjpic,
				'it618_islive' => $_GET['it618_islive'][$id],
				'it618_issaleout' => $_GET['it618_issaleout'][$id],
				'it618_isuservip' => $it618_isuservip,
				'it618_score' => $_GET['it618_score'][$id],
				'it618_iscard' => $_GET['it618_iscard'][$id],
				'it618_order' => $_GET['it618_order'][$id],
			));
			
			if($_GET['it618_isgoods'][$id]==1){
				$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand')." WHERE it618_power=".$id);
				while($it618_brand_brand = DB::fetch($query)) {
					C::t('#it618_brand#it618_brand_show')->update_it618_power_by_shopid($it618_brand_brand['id'],1);
				}
			}else{
				$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand')." WHERE it618_power=".$id);
				while($it618_brand_brand = DB::fetch($query)) {
					C::t('#it618_brand#it618_brand_show')->update_it618_power_by_shopid($it618_brand_brand['id'],0);
				}
			}
			
			if($_GET['it618_isgoods'][$id]==0&&$_GET['it618_issaleout'][$id]==0){
				$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand')." WHERE it618_power=".$id);
				while($it618_brand_brand = DB::fetch($query)) {
					C::t('#it618_brand#it618_brand_show')->update_it618_power1_by_shopid($it618_brand_brand['id'],0);
				}
			}else{
				$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand')." WHERE it618_power=".$id);
				while($it618_brand_brand = DB::fetch($query)) {
					C::t('#it618_brand#it618_brand_show')->update_it618_power1_by_shopid($it618_brand_brand['id'],1);
				}
			}
			
			$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand')." WHERE it618_power=".$id);
			while($it618_brand_brand = DB::fetch($query)) {
				$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_goods')." WHERE it618_shopid=".$it618_brand_brand['id']);
				while($it618_brand_goods = DB::fetch($query1)) {
					$it618_saletype=$it618_brand_goods['it618_saletype'];
					$it618_isduihuan=$it618_brand_goods['it618_isduihuan'];
					$it618_isalipay=$it618_brand_goods['it618_isalipay'];
					
					if($it618_issaletype1==0){
						if($it618_saletype==1||$it618_saletype==4){
							DB::query("update ".DB::table('it618_brand_goods')." set it618_ison=0 WHERE id=".$it618_brand_goods['id']);
							continue;
						}
					}
					if($it618_issaletype2==0){
						if($it618_saletype==2||$it618_saletype==4){
							DB::query("update ".DB::table('it618_brand_goods')." set it618_ison=0 WHERE id=".$it618_brand_goods['id']);
							continue;
						}
					}
					if($it618_issaletype3==0){
						if($it618_saletype==3){
							DB::query("update ".DB::table('it618_brand_goods')." set it618_ison=0 WHERE id=".$it618_brand_goods['id']);
							continue;
						}
					}
					if($it618_issaletype4==0){
						if($it618_saletype==6){
							DB::query("update ".DB::table('it618_brand_goods')." set it618_ison=0 WHERE id=".$it618_brand_goods['id']);
							continue;
						}
					}
					if($it618_issaletype5==0){
						if($it618_saletype==5){
							DB::query("update ".DB::table('it618_brand_goods')." set it618_ison=0 WHERE id=".$it618_brand_goods['id']);
							continue;
						}
					}
					if($it618_ispaytype1==0){
						if($it618_isduihuan==1){
							DB::query("update ".DB::table('it618_brand_goods')." set it618_ison=0 WHERE id=".$it618_brand_goods['id']);
							continue;
						}
					}
					if($it618_ispaytype2==0){
						if($it618_isalipay==1){
							DB::query("update ".DB::table('it618_brand_goods')." set it618_ison=0 WHERE id=".$it618_brand_goods['id']);
							continue;
						}
					}
				}
			}
			
			$ok1=$ok1+1;
		}
	}

	$newit618_groupname_array = !empty($_GET['newit618_groupname']) ? $_GET['newit618_groupname'] : array();
	
	foreach($newit618_groupname_array as $key => $value) {
		$newit618_groupname = trim($newit618_groupname_array[$key]);
		
		if($newit618_groupname != '') {
			
			C::t('#it618_brand#it618_brand_brandgroup')->insert(array(
				'it618_groupname' => trim($newit618_groupname_array[$key])
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}

	cpmsg($it618_brand_lang['s5'].$ok1.' '.$it618_brand_lang['s6'].$ok2.' '.$it618_brand_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_brandgroup&pmod=admin_brand&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_brandgroup&pmod=admin_brand&operation=$operation&do=$do");
showtableheaders($it618_brand_lang['s1620'],'it618_brand_brandgroup');
	$count = C::t('#it618_brand#it618_brand_brandgroup')->count_by_search();
	
	echo '<tr><td colspan=11>'.$it618_brand_lang['s1628'].$count.'<span style="float:right;color:red">'.$it618_brand_lang['s1630'].'</span></td></tr>';
	showsubtitle(array('', $it618_brand_lang['s1622'], $it618_brand_lang['s1621'], $it618_brand_lang['s1623'],$it618_brand_lang['s1073'],$it618_brand_lang['s1624'],$it618_brand_lang['s1625'],$it618_brand_lang['s1706'],$it618_brand_lang['s1626'],$it618_brand_lang['s1627']));
	
	$n=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brandgroup')." ORDER BY it618_order");
	while($it618_brand_brandgroup = DB::fetch($query)) {
		
		if($it618_brand_brandgroup['it618_isgoods']==1){
			$it618_isgoods_checked='checked="checked"';
			$divgoodscss='';
		}else{
			$it618_isgoods_checked="";
			$divgoodscss=';display:none';
		}
		if($it618_brand_brandgroup['it618_isouturl']==1)$it618_isouturl_checked='checked="checked"';else $it618_isouturl_checked="";
		if($it618_brand_brandgroup['it618_issaleagain']==1)$it618_issaleagain_checked='checked="checked"';else $it618_issaleagain_checked="";
		if($it618_brand_brandgroup['it618_issaletype1']==1)$it618_issaletype1_checked='checked="checked"';else $it618_issaletype1_checked="";
		if($it618_brand_brandgroup['it618_issaletype2']==1)$it618_issaletype2_checked='checked="checked"';else $it618_issaletype2_checked="";
		if($it618_brand_brandgroup['it618_issaletype3']==1)$it618_issaletype3_checked='checked="checked"';else $it618_issaletype3_checked="";
		if($it618_brand_brandgroup['it618_issaletype4']==1)$it618_issaletype4_checked='checked="checked"';else $it618_issaletype4_checked="";
		if($it618_brand_brandgroup['it618_issaletype5']==1)$it618_issaletype5_checked='checked="checked"';else $it618_issaletype5_checked="";
		if($it618_brand_brandgroup['it618_ispaytype1']==1)$it618_ispaytype1_checked='checked="checked"';else $it618_ispaytype1_checked="";
		if($it618_brand_brandgroup['it618_ispaytype2']==1){
			$it618_ispaytype2_checked='checked="checked"';
		}else{
			$it618_ispaytype2_checked="";
		}
		if($it618_brand_brandgroup['it618_isorder']==1)$it618_isorder_checked='checked="checked"';else $it618_isorder_checked="";
		if($it618_brand_brandgroup['it618_ispjpic']==1)$it618_ispjpic_checked='checked="checked"';else $it618_ispjpic_checked="";
		if($it618_brand_brandgroup['it618_islive']==1)$it618_islive_checked='checked="checked"';else $it618_islive_checked="";
		if($it618_brand_brandgroup['it618_issaleout']==1)$it618_issaleout_checked='checked="checked"';else $it618_issaleout_checked="";
		if($it618_brand_brandgroup['it618_isuservip']==1)$it618_isuservip_checked='checked="checked"';else $it618_isuservip_checked="";
		if($it618_brand_brandgroup['it618_iscard']==1)$it618_iscard_checked='checked="checked"';else $it618_iscard_checked="";
		
		$brandcount=C::t('#it618_brand#it618_brand_brand')->count_by_it618_power($it618_brand_brandgroup['id']);
		if($brandcount>0)$disabled='disabled="disabled"';else $disabled='';
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_brand_brandgroup[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_brand_brandgroup[id]]\" value=\"$it618_brand_brandgroup[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:90px;color:green;font-weight:bold\" name=\"it618_groupname[$it618_brand_brandgroup[id]]\" value=\"$it618_brand_brandgroup[it618_groupname]\">",
			'<img src="'.$it618_brand_brandgroup['it618_img'].'" id="img'.$it618_brand_brandgroup['id'].'" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" style="width:50px" id="url'.$it618_brand_brandgroup['id'].'" name="it618_img['.$it618_brand_brandgroup['id'].']" readonly="readonly" value="'.$it618_brand_brandgroup['it618_img'].'" /> <input type="button" id="image'.$it618_brand_brandgroup['id'].'" value="'.$it618_brand_lang['s1488'].'" />',
			'<div style="width:430px">
			<div style="float:left;">
			<input class="checkbox" type="checkbox" id="it618_isgoods'.$it618_brand_brandgroup['id'].'" name="it618_isgoods['.$it618_brand_brandgroup['id'].']" '.$it618_isgoods_checked.' value="1" onclick="setcheck('.$it618_brand_brandgroup['id'].')"><label for="it618_isgoods'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1637'].'</label> <input class="checkbox" type="checkbox" id="it618_isouturl'.$it618_brand_brandgroup['id'].'" name="it618_isouturl['.$it618_brand_brandgroup['id'].']" '.$it618_isouturl_checked.' value="1"><label for="it618_isouturl'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1900'].'</label> 
			</div>
			<div style="float:left'.$divgoodscss.'" id="divgoods'.$it618_brand_brandgroup['id'].'">
			'.$it618_brand_lang['s1647'].'<input type="text" class="txt" style="width:60px;color:blue;font-weight:bold" name="it618_goodscount['.$it618_brand_brandgroup['id'].']" value="'.$it618_brand_brandgroup[it618_goodscount].'"> '.$it618_brand_lang['s1749'].'<input class="txt" type="text" style="width:60px;color:red;font-weight:bold;margin-right:3px" name="it618_score['.$it618_brand_brandgroup['id'].']" value="'.$it618_brand_brandgroup['it618_score'].'"><font color=#390>'.$creditname.'</font>
			<br>'.$it618_brand_lang['s1633'].'<input class="checkbox" type="checkbox" id="it618_issaletype1'.$it618_brand_brandgroup['id'].'" name="it618_issaletype1['.$it618_brand_brandgroup['id'].']" '.$it618_issaletype1_checked.' value="1"><label for="it618_issaletype1'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1002'].'</label><input class="checkbox" type="checkbox" id="it618_issaletype2'.$it618_brand_brandgroup['id'].'" name="it618_issaletype2['.$it618_brand_brandgroup['id'].']" '.$it618_issaletype2_checked.' value="1"><label for="it618_issaletype2'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1003'].'</label><input class="checkbox" type="checkbox" id="it618_issaletype3'.$it618_brand_brandgroup['id'].'" name="it618_issaletype3['.$it618_brand_brandgroup['id'].']" '.$it618_issaletype3_checked.' value="1"><label for="it618_issaletype3'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1641'].'</label><input class="checkbox" type="checkbox" id="it618_issaletype4'.$it618_brand_brandgroup['id'].'" name="it618_issaletype4['.$it618_brand_brandgroup['id'].']" '.$it618_issaletype4_checked.' value="1"><label for="it618_issaletype4'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s855'].'</label> <input class="checkbox" type="checkbox" id="it618_issaletype5'.$it618_brand_brandgroup['id'].'" name="it618_issaletype5['.$it618_brand_brandgroup['id'].']" '.$it618_issaletype5_checked.' value="1"><label for="it618_issaletype5'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1654'].'</label><br>
			'.$it618_brand_lang['s1634'].'<input class="checkbox" type="checkbox" id="it618_ispaytype1'.$it618_brand_brandgroup['id'].'" name="it618_ispaytype1['.$it618_brand_brandgroup['id'].']" '.$it618_ispaytype1_checked.' value="1"><label for="it618_ispaytype1'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1606'].'</label><input class="checkbox" type="checkbox" id="it618_ispaytype2'.$it618_brand_brandgroup['id'].'" name="it618_ispaytype2['.$it618_brand_brandgroup['id'].']" '.$it618_ispaytype2_checked.' value="1"><label for="it618_ispaytype2'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1607'].'</label><br>
			'.$it618_brand_lang['s1635'].'<input class="checkbox" type="checkbox" id="it618_isorder'.$it618_brand_brandgroup['id'].'" name="it618_isorder['.$it618_brand_brandgroup['id'].']" '.$it618_isorder_checked.' value="1"><label for="it618_isorder'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1631'].'</label><input class="checkbox" type="checkbox" id="it618_ispjpic'.$it618_brand_brandgroup['id'].'" name="it618_ispjpic['.$it618_brand_brandgroup['id'].']" '.$it618_ispjpic_checked.' value="1"><label for="it618_ispjpic'.$it618_brand_brandgroup['id'].'">'.$it618_brand_lang['s1831'].'</label><br><input class="checkbox" type="checkbox" style="margin-left:0" id="it618_issaleagain'.$it618_brand_brandgroup['id'].'" name="it618_issaleagain['.$it618_brand_brandgroup['id'].']" '.$it618_issaleagain_checked.' value="1"><label for="it618_issaleagain'.$it618_brand_brandgroup['id'].'"><font color=green>'.$it618_brand_lang['s1853'].'</font></label>
			</div>
			</div>',
			'<input class="checkbox" type="checkbox" name="it618_islive['.$it618_brand_brandgroup['id'].']" '.$it618_islive_checked.' value="1">',
			'<input class="checkbox" type="checkbox" name="it618_issaleout['.$it618_brand_brandgroup['id'].']" '.$it618_issaleout_checked.' value="1">',
			'<input class="checkbox" type="checkbox" name="it618_isuservip['.$it618_brand_brandgroup['id'].']" '.$it618_isuservip_checked.' value="1">',
			'<input class="checkbox" type="checkbox" name="it618_iscard['.$it618_brand_brandgroup['id'].']" '.$it618_iscard_checked.' value="1">',
			'<input class="txt" type="text" style="width:20px" name="it618_order['.$it618_brand_brandgroup['id'].']" value="'.$it618_brand_brandgroup['it618_order'].'">',
			'<font color=red><b>'.$brandcount.'</b></font>'
		));
		$editorjs.='K(\'#image'.$it618_brand_brandgroup['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_brand_brandgroup['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_brand_brandgroup['id'].'\').val(url);
								K(\'#img'.$it618_brand_brandgroup['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
	
	function setcheck(index){
		if(document.getElementById("it618_isgoods"+index).checked){
			document.getElementById("divgoods"+index).style.display="";
		}else{
			document.getElementById("divgoods"+index).style.display="none";
		}
	}
</script>';
	$it618_brand_lang184=$it618_brand_lang['s1629'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_groupname[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:130px\" name="newit618_groupname[]">'], [1, '$it618_brand_lang184'], [1,''], [1,''], [1,''], [1,''], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="9"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
    echo '<tr><td colspan=8>'.$it618_brand_lang['s1636'].'</td></tr>';
	if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/
showtablefooter(); /*dism��taobao��com*/
?>