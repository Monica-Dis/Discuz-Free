<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='a')return; /*Dism_taobao_com*/
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_brand_diy', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_brand#it618_brand_diy')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_modecode' => trim($_GET['it618_modecode'][$id]),
				'it618_count' => trim($_GET['it618_count'][$id]),
				'it618_catchtime' => trim($_GET['it618_catchtime'][$id]),
				'it618_isjs' => trim($_GET['it618_isjs'][$id])
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_type_array = !empty($_GET['newit618_type']) ? $_GET['newit618_type'] : array();
	$newit618_modecode_array = !empty($_GET['newit618_modecode']) ? $_GET['newit618_modecode'] : array();
	
	foreach($newit618_name_array as $key => $value) {

		C::t('#it618_brand#it618_brand_diy')->insert(array(
			'it618_name' => trim($newit618_name_array[$key]),
			'it618_type' => trim($newit618_type_array[$key]),
			'it618_modecode' => trim($newit618_modecode_array[$key])
		), true);
		$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
	}

	cpmsg($it618_brand_lang['s5'].$ok1.' '.$it618_brand_lang['s6'].$ok2.' '.$it618_brand_lang['s7'].$del.')', "action=plugins&identifier=$identifier&cp=admin_diy&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_diy&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do");
showtableheaders($it618_brand_lang['s568'],'it618_brand_diy');
echo '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/plugins/code/prettify.js"></script>
';

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_diy')." w WHERE 1 $extrasql");
	
	echo '<tr><td colspan=6>'.$it618_brand_lang['s569'].$count.'</td></tr>';
	showtablerow('', array('class="td25"', '', '', '', ''), array('', $it618_brand_lang['s570'],$it618_brand_lang['s571'],$it618_brand_lang['s572'],$it618_brand_lang['s573'],$it618_brand_lang['s575'],$it618_brand_lang['s574']));
	
	foreach(C::t('#it618_brand#it618_brand_diy')->fetch_all_by_search() as $it618_brand_diy) {
		
		if($it618_brand_diy['it618_isjs']==1)$checked='checked="checked"';else $checked="";
		if($it618_brand_diy['it618_type']=='product_zj')$it618_type=$it618_brand_lang['s1843'];
		if($it618_brand_diy['it618_type']=='product_weekhot')$it618_type=$it618_brand_lang['s1844'];
		if($it618_brand_diy['it618_type']=='money_new')$it618_type=$it618_brand_lang['s576'];
		if($it618_brand_diy['it618_type']=='product_new')$it618_type=$it618_brand_lang['s807'];
		if($it618_brand_diy['it618_type']=='product_hot')$it618_type=$it618_brand_lang['s808'];
		if($it618_brand_diy['it618_type']=='brand_new')$it618_type=$it618_brand_lang['s809'];
		if($it618_brand_diy['it618_type']=='brand_hot')$it618_type=$it618_brand_lang['s810'];
		if($it618_brand_diy['it618_type']=='article_new')$it618_type=$it618_brand_lang['s577'];
		if($it618_brand_diy['it618_type']=='ly_new')$it618_type=$it618_brand_lang['s556'];
		if($it618_brand_diy['it618_type']=='thread_new')$it618_type=$it618_brand_lang['s557'];
		if($it618_brand_diy['it618_type']=='diyhtml'){
			$it618_type=$it618_brand_lang['s578'];
		}
		$tmpjs.='<script>
						KindEditor.ready(function(K) {
							var editor1 = K.create(\'textarea[id="it618_modecode'.$it618_brand_diy[id].'"]\', {
								cssPath : \'source/plugin/it618_brand/kindeditor/plugins/code/prettify.css\',
								uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php\',
								fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php\',
								allowFileManager : true,
								filterMode:false
							});
									
							prettyPrint();
						});
					</script>';
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_brand_diy[id]\">",
			'<input class="txt" style="width:100px" type="text" name="it618_name['.$it618_brand_diy['id'].']" value="'.$it618_brand_diy['it618_name'].'">',
			$it618_type,
			"<input type='hidden' id='flag".$it618_brand_diy['id']."' value='0'><input type='button' id='btn".$it618_brand_diy['id']."' value='".$it618_brand_lang['s811']."' title='".$it618_brand_lang['s812']."' class='btn' onclick='setmodedisplay(".$it618_brand_diy['id'].")'><div id='mode".$it618_brand_diy['id']."' style='display:none'><textarea class=\"txt\" style=\"width:670px;height:300px;visibility:hidden;\" id=\"it618_modecode$it618_brand_diy[id]\" name=\"it618_modecode[$it618_brand_diy[id]]\">$it618_brand_diy[it618_modecode]</textarea></div>",
			'<input class="txt" style="width:30px" type="text" name="it618_count['.$it618_brand_diy['id'].']" value="'.$it618_brand_diy['it618_count'].'">',
			'<input class="txt" style="width:30px" type="text" name="it618_catchtime['.$it618_brand_diy['id'].']" value="'.$it618_brand_diy['it618_catchtime'].'">'.$it618_brand_lang['s558'],
			'<input class="checkbox" type="checkbox" name="it618_isjs['.$it618_brand_diy['id'].']" '.$checked.' value="1"><a href="javascript:;" onclick="prompt(\''.$it618_brand_lang['s579'].'\', \'&lt;script type=&quot;text/javascript&quot; src=&quot;'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax&ac=getmode&modeid='.$it618_brand_diy['id'].'&quot;&gt;&lt;/script&gt;\')">'.$it618_brand_lang['s580'].'</a>'
		));
		
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
	
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:100px" name="newit618_name[]">'],
		[1,'<select name="newit618_type[]"><option value="product_zj">{$it618_brand_lang['s1843']}</option><option value="product_weekhot">{$it618_brand_lang['s1844']}</option><option value="money_new">{$it618_brand_lang['s576']}</option><option value="product_new">{$it618_brand_lang['s807']}</option><option value="product_hot">{$it618_brand_lang['s808']}</option><option value="brand_new">{$it618_brand_lang['s809']}</option><option value="brand_hot">{$it618_brand_lang['s810']}</option><option value="article_new">{$it618_brand_lang['s577']}</option><option value="ly_new">{$it618_brand_lang['s556']}</option><option value="thread_new">{$it618_brand_lang['s557']}</option><option value="diyhtml">{$it618_brand_lang['s578']}</option></select>'], 
		[1,'{$it618_brand_lang['s581']}'],
		[1,'{$it618_brand_lang['s582']}'],
		[1,'{$it618_brand_lang['s584']}'],
		[1,'{$it618_brand_lang['s583']}'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	
	function setmodedisplay(diyid){
		if(document.getElementById('flag'+diyid).value==0){
			document.getElementById('flag'+diyid).value=1;
			document.getElementById('btn'+diyid).value='{$it618_brand_lang['s813']}';
			document.getElementById('mode'+diyid).style.display='';
		}else{
			document.getElementById('flag'+diyid).value=0;
			document.getElementById('btn'+diyid).value='{$it618_brand_lang['s811']}';
			document.getElementById('mode'+diyid).style.display='none';
		}
	}
	</script>
EOT;
	echo '<tr><td></td><td colspan="7"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';

	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
    echo '
<tr><td colspan="7" style="line-height:22px">'.$it618_brand_lang['s585'].'
</td></tr>'.$tmpjs;
	if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/
showtablefooter(); /*dism��taobao��com*/
?>