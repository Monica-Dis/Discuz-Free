<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

$count = C::t('#it618_brand#it618_brand_style')->count_by_shopid($ShopId);
if($count==0){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_style')." where it618_shopid=0");
	while($it618_tmp =	DB::fetch($query1)) {
		C::t('#it618_brand#it618_brand_style')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_color1' => $it618_tmp['it618_color1'],
			'it618_color2' => $it618_tmp['it618_color2'],
			'it618_isok' => $it618_tmp['it618_isok']
		), true);
	}
}

if(submitcheck('it618submit')){
	for($i=0;$i<6;$i++){
		$it618_wapcolors.=$_GET['wapcolors'.$i].'@';
	}
	
	C::t('#it618_brand#it618_brand_brand')->update($ShopId,array(
		'it618_wapheaderstyle' => $_GET['it618_wapheaderstyle'],
		'it618_wapheaderimg' => dhtmlspecialchars($_GET['it618_wapheaderimg']),
		'it618_wapcolors' => dhtmlspecialchars($it618_wapcolors)
	));
	
	if(($it618_brand['brand_navtype']>2)&&$Shop_isbrandnav==2){
		$ok1=0;
		$ok2=0;
		$del=0;
		
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			C::t('#it618_brand#it618_brand_style')->delete_by_id($delid);
			$del=$del+1;
		}
	
		if(is_array($_GET['it618_color1'])) {
			foreach($_GET['it618_color1'] as $id => $val) {
				
				if($_GET['it618_isok']==$id)$it618_isok=1;else $it618_isok=0;
				
				C::t('#it618_brand#it618_brand_style')->update($id,array(
					'it618_color1' => dhtmlspecialchars($_GET['it618_color1'][$id]),
					'it618_color2' => dhtmlspecialchars($_GET['it618_color2'][$id]),
					'it618_isok' => $it618_isok,
				));
				$ok1=$ok1+1;
			}
		}
	
		$newit618_color1_array = !empty($_GET['newit618_color1']) ? $_GET['newit618_color1'] : array();
		$newit618_color2_array = !empty($_GET['newit618_color2']) ? $_GET['newit618_color2'] : array();
		
		foreach($newit618_color1_array as $key => $value) {
			$newit618_color1 = trim($newit618_color1_array[$key]);
			
			if($newit618_color1 != '') {
				
				C::t('#it618_brand#it618_brand_style')->insert(array(
					'it618_shopid' => $ShopId,
					'it618_color1' => dhtmlspecialchars($newit618_color1_array[$key]),
					'it618_color2' => dhtmlspecialchars($newit618_color2_array[$key])
				), true);
				$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
			}
		}
	
		it618_cpmsg(it618_brand_getlang('s5').$ok1.' '.it618_brand_getlang('s6').$ok2.' '.it618_brand_getlang('s7').$del, "plugin.php?id=it618_brand:sc_style$adminsid", 'succeed');
	}else{
		it618_cpmsg(it618_brand_getlang('s1774'), "plugin.php?id=it618_brand:sc_style$adminsid", 'succeed');
	}
}

$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);
$it618_wapcolors=$it618_brand_brand['it618_wapcolors'];
if($it618_wapcolors==''){
	$it618_wapcolors='#FFFFFF@#FFFFFF@#DD2727@#FFFFFF@#DD2727@#D0021B';
}
$it618_wapcolors=explode("@",$it618_wapcolors);

if($it618_brand_brand['it618_isimagemove']==1)$it618_isimagemove_checked='checked="checked"';else $it618_isimagemove_checked="";

for($i=0;$i<6;$i++){
	$wapcolors[]="<input id=\"wapcolors".$i."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"wapcolors".$i."\" value=\"".$it618_wapcolors[$i]."\" onchange=\"updatecolorpreview('wapcolors".$i."')\"><input id=\"wapcolors".$i."\" onclick=\"wapcolors".$i."_frame.location='static/image/admincp/getcolor.htm?wapcolors".$i."|wapcolors".$i."_v';showMenu({'ctrlid':'wapcolors".$i."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"wapcolors".$i."_menu\" style=\"display: none\"><iframe name=\"wapcolors".$i."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>";
	$tmpwapcolorsjs.="updatecolorpreview('wapcolors$i');";
}

echo '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php?shopid='.$ShopId.'\',
			fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true
		});

		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
	});
</script>
';

if($it618_brand_brand['it618_wapheaderstyle']==1){
	$it618_wapheaderstyle1=' selected=selected';
	$stmpcss='style="background-color:#f9f9f9"';
}
if($it618_brand_brand['it618_wapheaderstyle']==2)$it618_wapheaderstyle2=' selected=selected';
if($it618_brand_brand['it618_wapheaderstyle']==3)$it618_wapheaderstyle3=' selected=selected';

it618_showformheader("plugin.php?id=it618_brand:sc_style$adminsid");
showtableheaders(it618_brand_getlang('s1491'),'it618_brand_styleset');
echo '<tr><td>'.it618_brand_getlang('s848').'<img id="img1" src="'.$it618_brand_brand['it618_wapheaderimg'].'" width="260" height="50" align="absmiddle"/> <input type="text" id="url1" name="it618_wapheaderimg" readonly="readonly" value="'.$it618_brand_brand['it618_wapheaderimg'].'"/> <input type="button" id="image1" value="'.it618_brand_getlang('s140').'" /> <input type="button" value="'.it618_brand_getlang('s1258').'" onclick="document.getElementById(\'url1\').value=\'\';document.getElementById(\'img1\').src=\'\'" /> '.it618_brand_getlang('s849').'</td></tr>
<tr><td>'.$it618_brand_lang['s1577'].'<select name="it618_wapheaderstyle" onchange="getstyle(this)"><option value="1" '.$it618_wapheaderstyle1.'>'.$it618_brand_lang['s1578'].'</option><option value="2" '.$it618_wapheaderstyle2.'>'.$it618_brand_lang['s1579'].'</option><option value="3" '.$it618_wapheaderstyle3.'>'.$it618_brand_lang['s1580'].'</option></select></td></tr>
<tr id="trstyle1" '.$stmpcss.'><td>
<span style="float:left">'.it618_brand_getlang('s1492').'</span>'.$wapcolors[0].'
<span style="float:left;margin-left:6px">'.it618_brand_getlang('s1493').'</span>'.$wapcolors[1].'
<span style="float:left;margin-left:6px">'.it618_brand_getlang('s1494').'</span>'.$wapcolors[2].'
</td></tr>
<script type="text/JavaScript">'.$tmpwapcolorsjs.'</script>
';

if(($it618_brand['brand_navtype']>2)&&$Shop_isbrandnav==2){

showtableheaders(it618_brand_getlang('s1490'),'it618_brand_style');
	$count = C::t('#it618_brand#it618_brand_style')->count_by_shopid($ShopId);
	
	echo '<tr><td colspan=4>'.it618_brand_getlang('s835').$count.'</td></tr>';
	
	showsubtitle(array('', it618_brand_getlang('s836'), it618_brand_getlang('s837'),it618_brand_getlang('s838')));
	
	foreach(C::t('#it618_brand#it618_brand_style')->fetch_all_by_shopid($ShopId) as $it618_brand_style) {
		
		if($it618_brand_style['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_brand_style[id]\">",
			"<input id=\"c1".$it618_brand_style['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color1[$it618_brand_style[id]]\" value=\"$it618_brand_style[it618_color1]\" onchange=\"updatecolorpreview('c1".$it618_brand_style['id']."')\"><input id=\"c1".$it618_brand_style['id']."\" onclick=\"c1".$it618_brand_style['id']."_frame.location='static/image/admincp/getcolor.htm?c1".$it618_brand_style['id']."|c1".$it618_brand_style['id']."_v';showMenu({'ctrlid':'c1".$it618_brand_style['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c1".$it618_brand_style['id']."_menu\" style=\"display: none\"><iframe name=\"c1".$it618_brand_style['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			"<input id=\"c2".$it618_brand_style['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color2[$it618_brand_style[id]]\" value=\"$it618_brand_style[it618_color2]\" onchange=\"updatecolorpreview('c2".$it618_brand_style['id']."')\"><input id=\"c2".$it618_brand_style['id']."\" onclick=\"c2".$it618_brand_style['id']."_frame.location='static/image/admincp/getcolor.htm?c2".$it618_brand_style['id']."|c2".$it618_brand_style['id']."_v';showMenu({'ctrlid':'c2".$it618_brand_style['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c2".$it618_brand_style['id']."_menu\" style=\"display: none\"><iframe name=\"c2".$it618_brand_style['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			'<input class="radio" type="radio" name="it618_isok" '.$it618_isok_checked.' value="'.$it618_brand_style['id'].'">'
		));
		$tmpcolorjs.="updatecolorpreview('c1".$it618_brand_style['id']."');";
		$tmpcolorjs.="updatecolorpreview('c2".$it618_brand_style['id']."');";
	}

	echo <<<EOT
	<script type="text/JavaScript">
	$tmpcolorjs
	function getstyle(obj){
		if(obj.value==1){
			document.getElementById("trstyle1").style.display="";
			document.getElementById("trstyle2").style.display="";
		}else{
			document.getElementById("trstyle1").style.display="none";
			document.getElementById("trstyle2").style.display="none";
		}	
	}
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_color1[]").length;
	
		return [
		[[1,''], [1,'<input id="c1_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color1[]" onchange="updatecolorpreview(\'c1_add'+n+'\')"><input id="c1_add'+n+'" onclick="c1_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c1_add'+n+'|c1_add'+n+'_v\';showMenu({\'ctrlid\':\'c1_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c1_add'+n+'_menu" style="display: none"><iframe name="c1_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1,'<input id="c2_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color2[]" onchange="updatecolorpreview(\'c2_add'+n+'\')"><input id="c2_add'+n+'" onclick="c2_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c2_add'+n+'|c2_add'+n+'_v\';showMenu({\'ctrlid\':\'c2_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c2_add'+n+'_menu" style="display: none"><iframe name="c2_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1, ''], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.it618_brand_getlang('s128').'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	showtablefooter(); /*dism��taobao��com*/
}else{
	showsubmit('it618submit', 'submit');
    showtablefooter(); /*dism��taobao��com*/
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>