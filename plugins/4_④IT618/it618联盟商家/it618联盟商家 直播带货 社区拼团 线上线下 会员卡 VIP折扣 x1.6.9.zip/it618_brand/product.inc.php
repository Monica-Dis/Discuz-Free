<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

$pid=intval($_GET['pid']);

if(brand_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	if(isset($_GET['e'])){
		if($urltmp!='')$urltmp.='&e='.$_GET['e'];else $urltmp.='e='.$_GET['e'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$ShopId.'@0@'.$pid.'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$ShopId.'&cid='.$pid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$ShopId.'@0@'.$pid.'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$ShopId.'&cid='.$pid);
	}
	
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if(!($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid))){
	echo it618_brand_getlang('s550');exit;
}else{
	if($it618_brand_goods['it618_ison']!=1||$it618_brand_goods['it618_state']!=1){echo it618_brand_getlang('s550');exit;}
	if($Shop_isgoods==0){
		echo $it618_brand_lang['s550'];exit;
	}
}


if($ShopId!=C::t('#it618_brand#it618_brand_goods')->fetch_it618_shopid_by_id($pid)){
	echo it618_brand_getlang('s550');exit;
}

if($_G['uid']>0){
	$count=C::t('#it618_brand#it618_brand_collect')->count_by_uid_pid($_G['uid'],$pid);
	if($count>0){
		$collectname=$it618_brand_lang['s1735'];
	}else{
		$collectname=$it618_brand_lang['s1734'];	
	}
}else{
	$collectname=$it618_brand_lang['s1734'];
}

if($IsGroup==1){
	if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='brand' and it618_pid=$pid")){
		$isvip=1;
	}
}

C::t('#it618_brand#it618_brand_goods')->update_it618_views_by_id($pid);

$tmpcount='<font color=#999>'.$it618_brand_lang['s1298'].' <font style="color:red">'.$it618_brand_goods['it618_salecount'].'</font> '.$it618_brand_lang['s870'].' <font style="color:red">'.$it618_brand_goods['it618_count'].'</font></font>';

for($i=0;$i<=4;$i++){
	if($i==0){$tmpi='';$tmpcss=' class="firstimg curimg"';}else {$tmpi=$i;$tmpcss='';}
	$it618_picbig=$it618_brand_goods['it618_picbig'.$tmpi];
	if($it618_picbig!=''){
		$goodspicbig.='<li'.$tmpcss.'><img width="48" height="48" border="0" src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_picbig,$i).'" rel="'.$it618_picbig.'" ></li>';
	}
}

$purl=it618_brand_getrewrite('shop_product',$ShopId.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.$it618_brand_goods['id']);

if(($it618_brand_goods['it618_saletype']==2 || $it618_brand_goods['it618_saletype']==4) && $it618_brand_goods['it618_isyunfeifree']==0){
	$isyunfei=1;
	
	$kdcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_kdyunfei')." where it618_shopid=".$ShopId);

	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_kdarea')." where it618_shopid=".$ShopId." ORDER BY it618_order");
	$n1=1;
	$tmp1='';
	while($it618_tmp1 = DB::fetch($query)) {
		if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_kdyunfei')." where it618_shopid=".$ShopId." and it618_kdareaid=".$it618_tmp1['id'])>0){
			$kdarea.='<option value='.$it618_tmp1['id'].'>'.$it618_tmp1['it618_name'].'</option>';
			$n2=1;
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_kdyunfei')." where it618_shopid=".$ShopId." and it618_order<>0 and it618_kdareaid=".$it618_tmp1['id']." ORDER BY it618_order");

			while($it618_tmp2 =	DB::fetch($query2)) {
				
				$kdname=C::t('#it618_brand#it618_brand_kd')->fetch_name_by_id($it618_tmp2['it618_kdid']);
				
				if($it618_brand_goods['it618_kgbl']>0&&$Shop_isyunfeikg==1){
					
					if($it618_brand_goods['it618_isduihuan']==1&&$it618_brand_goods['it618_isalipay']==1){
						$pricestr1=$it618_tmp2['it618_firstkgprice'].'('.$it618_tmp2['it618_firstkgscore'].$creditname.') ';
						$pricestr2=$it618_tmp2['it618_kgprice'].'('.$it618_tmp2['it618_kgscore'].$creditname.')';
					}else{
						if($it618_brand_goods['it618_isduihuan']==1){
							$pricestr1=$it618_tmp2['it618_firstkgscore'].$creditname.' ';
							$pricestr2=$it618_tmp2['it618_kgscore'].$creditname;
						}else{
							$pricestr1=$it618_tmp2['it618_firstkgprice'].' ';
							$pricestr2=$it618_tmp2['it618_kgprice'];
						}
					}
					
					$tmp1.='select_kd['.$n1.']['.$n2.'] = new Option("'.$kdname.' '.$it618_tmp2['it618_firstkg'].'kg'.it618_brand_getlang('s1001').' \u00A5'.$pricestr1.it618_brand_getlang('s1730').' \u00A5'.$pricestr2.'", "'.$it618_tmp2['id'].'");';
					
				}else{
					if($it618_brand_goods['it618_isduihuan']==1&&$it618_brand_goods['it618_isalipay']==1){
						$pricestr1=$it618_tmp2['it618_firstprice'].'('.$it618_tmp2['it618_firstscore'].$creditname.') ';
						$pricestr2=$it618_tmp2['it618_price'].'('.$it618_tmp2['it618_score'].$creditname.')';
					}else{
						if($it618_brand_goods['it618_isduihuan']==1){
							$pricestr1=$it618_tmp2['it618_firstscore'].$creditname.' ';
							$pricestr2=$it618_tmp2['it618_firstscore'].$creditname;
						}else{
							$pricestr1=$it618_tmp2['it618_firstprice'].' ';
							$pricestr2=$it618_tmp2['it618_price'];
						}
					}
					
					$tmp1.='select_kd['.$n1.']['.$n2.'] = new Option("'.$kdname.' '.$it618_tmp2['it618_firstcount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1001').' \u00A5'.$pricestr1.it618_brand_getlang('s997').'1'.$it618_brand_goods['it618_punit'].' '.it618_brand_getlang('s998').' \u00A5'.$pricestr2.'", "'.$it618_tmp2['id'].'");';
				}

				$n2=$n2+1;
			}
			$n1=$n1+1;
		}
	}
	
	$kdjs='var arrcount='.$kdcount.';
		var select_kd = new Array(arrcount+1);
		
		for (i=0; i<arrcount+1; i++) 
		{
		 select_kd[i] = new Array();
		}
		
		'.$tmp1.'
		
		function redirec_kd(x)
		{
		 var temp = document.getElementById("it618_kd"); 
		 temp.options.length=1;
		 for (i=1;i<select_kd[x].length;i++)
		 {
		  temp.options[i]=new Option(select_kd[x][i].text,select_kd[x][i].value);
		 }
		 temp.options[0].selected=true;
		
		}';
}


if($it618_brand_goods['it618_saletype']==1){
	$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s1002').'</span><i></i></a><input type="hidden" id="saletype" value="1"></div>';
}

if($it618_brand_goods['it618_saletype']==2){
	$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s1003').'</span><i></i></a><input type="hidden" id="saletype" value="2"></div>';
}

if($it618_brand_goods['it618_saletype']==3){
	$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s1223').'</span><i></i></a><input type="hidden" id="saletype" value="3"></div>';
}

if($it618_brand_goods['it618_saletype']==4){
	$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" onclick="setselect(\'saletype\',0,1)" name="saletype"><span>'.it618_brand_getlang('s1002').'</span><i></i></a><a href="javascript:void(0)" onclick="setselect(\'saletype\',1,2)" name="saletype"><span>'.it618_brand_getlang('s1003').'</span><i></i></a><input type="hidden" id="saletype" value="1"></div>';
}

if($it618_brand_goods['it618_saletype']==5){
	$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s1654').'</span><i></i></a><input type="hidden" id="saletype" value="5"></div>';
}

if($it618_brand_goods['it618_saletype']==6){	
	$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s855').'</span><i></i></a><input type="hidden" id="saletype" value="6"></div>';
}

$pjhaocount=$it618_brand_goods['it618_pjhaocount'];
$pjzhongcount=$it618_brand_goods['it618_pjzhongcount'];
$pjchacount=$it618_brand_goods['it618_pjchacount'];

$pjallcount=$pjhaocount+$pjzhongcount+$pjchacount;

$pjhaobl=intval($pjhaocount/$pjallcount*100);
$pjzhongbl=intval($pjzhongcount/$pjallcount*100);
$pjchabl=intval($pjchacount/$pjallcount*100);

$timeflag=0;$isxgok=0;
if($it618_brand_goods['it618_xgtype']==0)$isxgok=1;

if($it618_brand_goods['it618_xgtype']==1){
	$timestr=$it618_brand_goods['it618_xgtime1'].' - '.$it618_brand_goods['it618_xgtime2'];
	
	$timetmp1=explode(" ",$it618_brand_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_brand_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_brand_getlang('s1376');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_brand_getlang('s1377');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_brand_goods['it618_xgtime1'];
		}else{
			$timetip=it618_brand_getlang('s1378');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_brand_goods['it618_xgtime2'];
			$isxgok=1;
		}
	}
	
	$isxg=1;
}

if($it618_brand_goods['it618_xgtype']==2){
	$timetmp1=explode(" ",$it618_brand_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_brand_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_brand_getlang('s1379').' '.$timetmp1[1].' - '.$timetmp2[1];
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_brand_getlang('s1376');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_brand_getlang('s1377');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_brand_goods['it618_xgtime1'];
		}else{
			$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
			$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
			$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
			
			if($btimecur>$_G['timestamp']){
				$timetip=it618_brand_getlang('s1377');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur);
			}
			
			if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
				$timetip=it618_brand_getlang('s1378');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $etimecur);
				$isxgok=1;
			}
			
			if($etimecur<$_G['timestamp']){
				$timetip=it618_brand_getlang('s1377');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur1);
			}
		}
	}
	
	$isxg=1;
}


$tmparr=explode(":",$_GET['id']);
$pagetype=$tmparr[1];
$seotitle=$it618_brand_goods['it618_name'];
$seokeywords=$it618_brand_goods['it618_seokeywords'];
$seodescription=$it618_brand_goods['it618_seodescription'];

if($it618_brand_goods['it618_jfbl']>0){
	$jfblstr=$it618_brand_lang['s2'].'<font color=red>'.round(($it618_brand_goods['it618_jfbl']/100),2).'</font>'.$it618_brand_lang['s3'];
}else{
	$jfblstr=$it618_brand_lang['s9'];
}

if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
	$isprice=0;
}else{
	$isprice=1;

	$goodstypeid=0;
	$goodstypename='';
	$goodstypename1='';
	$n=0;
	
	$count=C::t('#it618_brand#it618_brand_goods_type')->count_by_pid_ok_isname1($pid);
	if($count>0){
		$it618_brand_goods_types=C::t('#it618_brand#it618_brand_goods_type')->fetch_name_by_it618_pid1($pid);
	}else{
		$it618_brand_goods_types=C::t('#it618_brand#it618_brand_goods_type')->fetch_name_by_it618_pid($pid);
	}
	
	foreach($it618_brand_goods_types as $it618_brand_goods_type) {
		$tmpstr='';
		if($n==0){
			$tmpstr='class="current"';
			$goodstypename=$it618_brand_goods_type['it618_name'];
			$goodstypeid=$it618_brand_goods_type['id'];
			
			$tmpcount='<font color=#999>'.$it618_brand_lang['s1298'].' <font style="color:red">'.$it618_brand_goods_type['it618_salecount'].'</font> '.$it618_brand_lang['s870'].' <font style="color:red">'.$it618_brand_goods_type['it618_count'].'</font></font>';
		}

		$goodstypestr.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype\','.$n.',\''.$it618_brand_goods_type['it618_name'].'\')" name="goodstype"><span>'.$it618_brand_goods_type['it618_name'].'</span><i></i></a>';
		$n++;
	}
	
	if($goodstypename!=''){
		$n=0;
		foreach(C::t('#it618_brand#it618_brand_goods_type')->fetch_name1_by_it618_pid_name($pid,$goodstypename) as $it618_brand_goods_type) {
			$tmpstr='';
			if($n==0){
				$tmpstr='class="current"';
				$goodstypename1=$it618_brand_goods_type['it618_name1'];
				$goodstypeid=$it618_brand_goods_type['id'];
			
				$tmpcount='<font color=#999>'.$it618_brand_lang['s1298'].' <font style="color:red">'.$it618_brand_goods_type['it618_salecount'].'</font> '.$it618_brand_lang['s870'].' <font style="color:red">'.$it618_brand_goods_type['it618_count'].'</font></font>';
			}
			
			$goodstypestr1.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype1\','.$n.',\''.$it618_brand_goods_type['it618_name1'].'\')" name="goodstype1"><span>'.$it618_brand_goods_type['it618_name1'].'</span><i></i></a>';
			$n=$n+1;
		}
	}
}

$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="935" height="526" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_brand_goods['it618_message']);

$it618_message_buy=$it618_brand_goods['it618_message_buy'];

if($it618_message_buy!=''){
	$goodsbuycontentuser=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('goodsbuycontentuser');
	
	if($_G['uid']>0)$buycount=C::t('#it618_brand#it618_brand_sale')->count_by_pid_uid($it618_brand_goods['id'],$_G['uid']);
	if($buycount>0){
		if($it618_brand_goods['it618_saletype']==5&&$Shop_issaleagain==0){
			$isbuyok=1;
		}

		$it618_message_buy=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="935" height="526" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_message_buy);
	}else{
		$it618_message_buy='<font color=red>'.$it618_brand_lang['s1659'].'</font>';
	}
	
	$it618_message_buy=$it618_message_buy.'<br>'.$goodsbuycontentuser;
}

if($Shop_isgoodsclass==1){
	$tmpurl=it618_brand_getrewrite('shop_productlist',$ShopId.'@'.$it618_brand_goods['it618_class_id'].'@1','plugin.php?id=it618_brand:product_list&sid='.$ShopId.'&cid='.$it618_brand_goods['it618_class_id']);
	$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo; <a href="'.$tmpurl.'" class="a1">'.C::t('#it618_brand#it618_brand_class')->fetch_it618_classname_by_id($it618_brand_goods['it618_class_id']).'</a> &raquo; '.$it618_brand_goods['it618_name'];
}else{
	$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo; '.$it618_brand_goods['it618_name'];
}

$payoksaleid=intval($_GET['payok']);
if($payoksaleid>0){
	$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($payoksaleid);
	if($it618_brand_sale['it618_saletype']==3){
		$tmppayok='saleaddkmid='.$payoksaleid.';';
	}
	if($it618_brand_sale['it618_saletype']==5){
		$tmppayok='saleaddconid='.$payoksaleid.';';
	}
	$payokjs='setTimeout("'.$tmppayok.'document.getElementById(\'mysale\').click();",800);';
}

$payokurl=it618_brand_getrewrite('shop_product',$ShopId.'@'.$pid,'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.$pid.'&payok=saleid','?payok=saleid');

$idforly=$pid;$idfornav=$it618_brand_goods['it618_class_id'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_nav.func.php';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:shop_default');
?>