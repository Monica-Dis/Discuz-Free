<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

if($Shop_isgoods==0&&$Shop_issaleout==0){
	echo $it618_brand_lang['s1646'];exit;
}

if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$ShopId);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

$it618_brand_show = C::t('#it618_brand#it618_brand_show')->fetch_by_shopid_showid_showtype($ShopId,0,'money');
$ppp = $it618_brand_show['it618_pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$moneycount = C::t('#it618_brand#it618_brand_money')->count_by_shopid($ShopId);
$hrefsql=it618_brand_getrewrite('shop_money',$ShopId.'@it618page','plugin.php?id=it618_brand:money&sid='.$ShopId);
$multipage = multi($moneycount, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_brand_multipage($multipage,$uri);
$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
if($ii1ill[5]!='_')return;

foreach(C::t('#it618_brand#it618_brand_money')->fetch_all_by_shopid(
		$ShopId,0,0,0,0,'','',$startlimit,$ppp
) as $it618_brand_money) {

	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')return;

	$username=it618_brand_getusername($it618_brand_money['it618_uid']);
	
	if($it618_brand_money['it618_type']!=1){
		
		if($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_money['it618_pid'])){
			$tmpurl=it618_brand_getrewrite('shop_product',$ShopId.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.$it618_brand_goods['id']);
			$it618_bz='<a href="'.$tmpurl.'" target="_blank" class="a1" title="'.$it618_brand_goods['it618_name'].'">'.cutstr($it618_brand_goods['it618_name'],58,'...').'</a>';
		}else{
			$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($it618_brand_money['it618_saleid']);
			$it618_bz=cutstr($it618_brand_sale['it618_pname'],58,'...');
		}
	
		if($it618_brand_goods['it618_isbm']==1){
			$buyuser=cutstr($username, 2, '').'***';
		}else{
			$buyuser='<a href="'.it618_brand_rewriteurl($it618_brand_money['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1">'.$username.'('.$it618_brand_money['it618_uid'].')</a>';
		}
		
		if($it618_brand_money['it618_state']==1){
			$it618_state=it618_brand_getlang('s294');
		}else{
			$it618_state='<img src="source/plugin/it618_brand/images/ok.gif" align="absmiddle"> '.it618_brand_getlang('s295');
		}
		
		if($it618_brand_money['it618_type']==2){
			$it618_score='-'.$it618_brand_money['it618_score'];
			$it618_type=it618_brand_getlang('s592');
			$moneystr='/';
		}else{
			$it618_score='+'.$it618_brand_money['it618_score'];
			$it618_type=it618_brand_getlang('s593');
			$moneystr=$it618_brand_money['it618_money'];
		}
		
	}else{
		
		$buyuser='<a href="'.it618_brand_rewriteurl($it618_brand_money['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1">'.$username.'('.$it618_brand_money['it618_uid'].')</a>';
		
		$it618_bz=$it618_brand_money['it618_bz'];
		
		$it618_state='<img src="source/plugin/it618_brand/images/ok.gif" align="absmiddle"> '.it618_brand_getlang('s410');
		
		$it618_score='+'.$it618_brand_money['it618_score'];
		
		$it618_type=it618_brand_getlang('s595');
		
		$moneystr=$it618_brand_money['it618_money'];
	}
	
	

$str_money.='<tr>
			<td class="td-8">'.$buyuser.'</td>
			<td class="td-2" align="center"><font color=#999>'.date('Y/m/d', $it618_brand_money['it618_time']).'</font></td>
			<td class="td-3">'.$it618_bz.'</td>
			<td class="td-5" align="center">'.$it618_score.'</td>
			<td class="td-6" align="center">'.$it618_type.'</td>
			<td class="td-6" align="center">'.$it618_state.'</td>
			</tr>';
}

if($multipage!='')$multipage='<div class="commonpage" style="margin-top:10px">'.str_replace(" / ","/",$multipage).'</div>';

$tmparr=explode(":",$_GET['id']);
$pagetype=$tmparr[1];
$seotitle=$it618_brand_show['it618_name'];
$seokeywords=$Shop_seokeywords;
$seodescription=$Shop_seodescription;
$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo; '.$seotitle;

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_nav.func.php';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:shop_default');
?>