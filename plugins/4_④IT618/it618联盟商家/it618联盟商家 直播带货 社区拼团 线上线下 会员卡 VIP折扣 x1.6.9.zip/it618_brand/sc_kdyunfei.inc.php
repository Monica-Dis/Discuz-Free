<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_kd')." WHERE it618_shopid=".$ShopId)==0){
	dheader("location:plugin.php?id=it618_brand:sc_kd$adminsid");
}

$n=1;
$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_kd')." WHERE it618_shopid=".$ShopId." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$kdtmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	if(isset($_GET['kdid'])){
		if($_GET['kdid']==$it618_tmp['id']){
			$licss='class="current"';
			$kdid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}else{
		if($n==1){
			$licss='class="current"';
			$kdid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_kdyunfei')." WHERE it618_shopid=".$ShopId." and it618_kdid=".$it618_tmp['id']);
	
	$submenu.='<li '.$licss.'><a href="plugin.php?id=it618_brand:sc_kdyunfei'.$adminsid.'&kdid='.$it618_tmp['id'].'"><span>'.$it618_tmp['it618_name'].'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$n=$n+1;
}
$kdtmpsel=str_replace('<option value='.$kdid.'>','<option value='.$kdid.' selected="selected">',$kdtmp);
echo '<div class="itemtitle" style="width:100%;margin-bottom:0px;margin-top:10px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';

$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_kdarea')." WHERE it618_shopid=".$ShopId." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$kdareatmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

if(submitcheck('it618submit_dao')){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_kdarea')." WHERE it618_shopid=".$ShopId." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_kdyunfei')." WHERE it618_shopid=".$ShopId." and it618_kdid=".$kdid." and it618_kdareaid=".$it618_tmp['id'])==0){
			C::t('#it618_brand#it618_brand_kdyunfei')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_kdid' => $kdid,
				'it618_kdareaid' => $it618_tmp['id'],
				'it618_order' => 0,
			), true);
		}
	}
}

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_brand_kdyunfei', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_kdid'])) {
		foreach($_GET['it618_kdid'] as $id => $val) {
			
			$it618_order=dhtmlspecialchars($_GET['it618_order'][$id]);
			if(intval($_GET['it618_firstcount'][$id])==0)$it618_order=0;
			if($Shop_isyunfeikg==1){
				if(floatval($_GET['it618_firstkg'][$id])==0)$it618_order=0;
			}

			C::t('#it618_brand#it618_brand_kdyunfei')->update($id,array(
				'it618_kdid' => dhtmlspecialchars($_GET['it618_kdid'][$id]),
				'it618_kdareaid' => dhtmlspecialchars($_GET['it618_kdareaid'][$id]),
				'it618_firstcount' => dhtmlspecialchars($_GET['it618_firstcount'][$id]),
				'it618_firstscore' => dhtmlspecialchars($_GET['it618_firstscore'][$id]),
				'it618_score' => dhtmlspecialchars($_GET['it618_score'][$id]),
				'it618_firstprice' => dhtmlspecialchars($_GET['it618_firstprice'][$id]),
				'it618_price' => dhtmlspecialchars($_GET['it618_price'][$id]),
				'it618_firstkg' => dhtmlspecialchars($_GET['it618_firstkg'][$id]),
				'it618_firstkgscore' => dhtmlspecialchars($_GET['it618_firstkgscore'][$id]),
				'it618_kgscore' => dhtmlspecialchars($_GET['it618_kgscore'][$id]),
				'it618_firstkgprice' => dhtmlspecialchars($_GET['it618_firstkgprice'][$id]),
				'it618_kgprice' => dhtmlspecialchars($_GET['it618_kgprice'][$id]),
				'it618_order' => $it618_order,
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_kdid_array = !empty($_GET['newit618_kdid']) ? $_GET['newit618_kdid'] : array();
	$newit618_kdareaid_array = !empty($_GET['newit618_kdareaid']) ? $_GET['newit618_kdareaid'] : array();
	$newit618_firstcount_array = !empty($_GET['newit618_firstcount']) ? $_GET['newit618_firstcount'] : array();
	$newit618_firstscore_array = !empty($_GET['newit618_firstscore']) ? $_GET['newit618_firstscore'] : array();
	$newit618_score_array = !empty($_GET['newit618_score']) ? $_GET['newit618_score'] : array();
	$newit618_firstprice_array = !empty($_GET['newit618_firstprice']) ? $_GET['newit618_firstprice'] : array();
	$newit618_price_array = !empty($_GET['newit618_price']) ? $_GET['newit618_price'] : array();
	$newit618_firstkg_array = !empty($_GET['newit618_firstkg']) ? $_GET['newit618_firstkg'] : array();
	$newit618_firstkgscore_array = !empty($_GET['newit618_firstkgscore']) ? $_GET['newit618_firstkgscore'] : array();
	$newit618_kgscore_array = !empty($_GET['newit618_kgscore']) ? $_GET['newit618_kgscore'] : array();
	$newit618_firstkgprice_array = !empty($_GET['newit618_firstkgprice']) ? $_GET['newit618_firstkgprice'] : array();
	$newit618_kgprice_array = !empty($_GET['newit618_kgprice']) ? $_GET['newit618_kgprice'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	
	
	foreach($newit618_kdid_array as $key => $value) {
	
		if($newit618_kdid_array[$key] != '') {
			
			$it618_order=dhtmlspecialchars($newit618_order_array[$key]);
			if(intval(dhtmlspecialchars($newit618_firstcount_array[$key]))==0)$it618_order=0;
			if($Shop_isyunfeikg==1){
				if(floatval(dhtmlspecialchars($newit618_firstkg_array[$key]))==0)$it618_order=0;
			}
			
			C::t('#it618_brand#it618_brand_kdyunfei')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_kdid' => dhtmlspecialchars($newit618_kdid_array[$key]),
				'it618_kdareaid' => dhtmlspecialchars($newit618_kdareaid_array[$key]),
				'it618_firstcount' => dhtmlspecialchars($newit618_firstcount_array[$key]),
				'it618_firstscore' => dhtmlspecialchars($newit618_firstscore_array[$key]),
				'it618_score' => dhtmlspecialchars($newit618_score_array[$key]),
				'it618_firstprice' => dhtmlspecialchars($newit618_firstprice_array[$key]),
				'it618_price' => dhtmlspecialchars($newit618_price_array[$key]),
				'it618_firstkg' => dhtmlspecialchars($newit618_firstkg_array[$key]),
				'it618_firstkgscore' => dhtmlspecialchars($newit618_firstkgscore_array[$key]),
				'it618_kgscore' => dhtmlspecialchars($newit618_kgscore_array[$key]),
				'it618_firstkgprice' => dhtmlspecialchars($newit618_firstkgprice_array[$key]),
				'it618_kgprice' => dhtmlspecialchars($newit618_kgprice_array[$key]),
				'it618_order' => $it618_order,
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}
	
	C::t('#it618_brand#it618_brand_brand')->update($ShopId,array(
		'it618_kdaddr' => trim($_GET['it618_kdaddr'])
	));

	it618_cpmsg(it618_brand_getlang('s5').$ok1.' '.it618_brand_getlang('s6').$ok2.' '.it618_brand_getlang('s7').$del.')', "plugin.php?id=it618_brand:sc_kdyunfei$adminsid&kdid=".$kdid, 'succeed');
}

$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);

if($Shop_isyunfeikg==1){
	$isyunfeikgcss='';
}else{
	$isyunfeikgcss='display:none';
}

it618_showformheader("plugin.php?id=it618_brand:sc_kdyunfei$adminsid&kdid=".$kdid);
showtableheaders(it618_brand_getlang('s1017'),'it618_brand_kdyunfei');
	
	echo '<style>tr td{line-height:20px}</style><tr><td colspan="6">'.it618_brand_getlang('s1018').'<input type="text" name="it618_kdaddr" value="'.$it618_brand_brand['it618_kdaddr'].'"> '.it618_brand_getlang('s1019').'<input type="submit" class="btn" name="it618submit_dao" value="'.it618_brand_getlang('s1020').'"></td></tr>';
	showsubtitle(array('', it618_brand_getlang('s1021'),it618_brand_getlang('s1022'),it618_brand_getlang('s1023'),it618_brand_getlang('s1024')));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_kdyunfei')." WHERE it618_shopid=".$ShopId." and it618_kdid=$kdid ORDER BY it618_order");
	while($it618_brand = DB::fetch($query)) {
		
		$kdareatmp1=str_replace('<option value='.$it618_brand['it618_kdareaid'].'>','<option value='.$it618_brand['it618_kdareaid'].' selected="selected">',$kdareatmp);
		$kdtmp1=str_replace('<option value='.$it618_brand['it618_kdid'].'>','<option value='.$it618_brand['it618_kdid'].' selected="selected">',$kdtmp);
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_brand[id]\" $disabled>",
			'<select name="it618_kdareaid['.$it618_brand[id].']">'.$kdareatmp1.'</select>',
			'<select name="it618_kdid['.$it618_brand[id].']">'.$kdtmp1.'</select>',
			"<input type=\"text\" class=\"txt\" style=\"width:50px;margin-right:1px;color:red\" name=\"it618_firstcount[$it618_brand[id]]\" value=\"$it618_brand[it618_firstcount]\">".it618_brand_getlang('s1025')." <input type=\"text\" class=\"txt\" style=\"width:60px;margin-right:1px\" name=\"it618_firstscore[$it618_brand[id]]\" value=\"$it618_brand[it618_firstscore]\">".it618_brand_getlang('s1026')."/<input type=\"text\" class=\"txt\" style=\"width:60px;margin-right:1px\" name=\"it618_firstprice[$it618_brand[id]]\" value=\"$it618_brand[it618_firstprice]\">".it618_brand_getlang('s1027')." <input type=\"text\" class=\"txt\" style=\"width:60px;margin-right:1px\" name=\"it618_score[$it618_brand[id]]\" value=\"$it618_brand[it618_score]\">".it618_brand_getlang('s1026')."/<input type=\"text\" class=\"txt\" style=\"width:60px;margin-right:1px\" name=\"it618_price[$it618_brand[id]]\" value=\"$it618_brand[it618_price]\">".it618_brand_getlang('s389')."
			<span style=\"".$isyunfeikgcss."\"><br><input type=\"text\" class=\"txt\" style=\"width:50px;margin-right:1px;color:red\" name=\"it618_firstkg[$it618_brand[id]]\" value=\"$it618_brand[it618_firstkg]\">".it618_brand_getlang('s1727')." <input type=\"text\" class=\"txt\" style=\"width:60px;margin-right:1px\" name=\"it618_firstkgscore[$it618_brand[id]]\" value=\"$it618_brand[it618_firstkgscore]\">".it618_brand_getlang('s1026')."/<input type=\"text\" class=\"txt\" style=\"width:60px;margin-right:1px\" name=\"it618_firstkgprice[$it618_brand[id]]\" value=\"$it618_brand[it618_firstkgprice]\">".it618_brand_getlang('s1728')."<input type=\"text\" class=\"txt\" style=\"width:60px;margin-right:1px\" name=\"it618_kgscore[$it618_brand[id]]\" value=\"$it618_brand[it618_kgscore]\">".it618_brand_getlang('s1026')."/<input type=\"text\" class=\"txt\" style=\"width:60px;margin-right:1px\" name=\"it618_kgprice[$it618_brand[id]]\" value=\"$it618_brand[it618_kgprice]\">".it618_brand_getlang('s389').'</span>',
			"<input type=\"text\" class=\"txt\" style=\"width:50px\" name=\"it618_order[$it618_brand[id]]\" value=\"$it618_brand[it618_order]\">"
		));
	}
	
	$it618_brand_lang751=it618_brand_getlang('s1025');
	$it618_brand_lang752=it618_brand_getlang('s1027');
	$it618_brand_lang753=it618_brand_getlang('s389');
	$it618_brand_lang754=it618_brand_getlang('s1026');
	$it618_brand_lang755=it618_brand_getlang('s1727');
	$it618_brand_lang756=it618_brand_getlang('s1728');

	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		return [
		[[1,''], [1,'<select name="newit618_kdareaid[]">$kdareatmp</select>'], [1,'<select name="newit618_kdid[]">$kdtmpsel</select>'], [1, '<input class="txt" style="width:50px;margin-right:1px" type="text" name="newit618_firstcount[]">$it618_brand_lang751 <input class="txt" style="width:60px;margin-right:1px" type="text" name="newit618_firstscore[]">$it618_brand_lang754/<input class="txt" style="width:60px;margin-right:1px" type="text" name="newit618_firstprice[]">$it618_brand_lang752 <input class="txt" style="width:60px;margin-right:1px" type="text" name="newit618_score[]">$it618_brand_lang754/<input class="txt" style="width:60px;margin-right:1px" type="text" name="newit618_price[]">$it618_brand_lang753<span style="$isyunfeikgcss"><br><input class="txt" style="width:50px;margin-right:1px" type="text" name="newit618_firstkg[]">$it618_brand_lang755 <input class="txt" style="width:60px;margin-right:1px" type="text" name="newit618_firstkgscore[]">$it618_brand_lang754/<input class="txt" style="width:60px;margin-right:1px" type="text" name="newit618_firstkgprice[]">$it618_brand_lang756<input class="txt" style="width:60px;margin-right:1px" type="text" name="newit618_kgscore[]">$it618_brand_lang754/<input class="txt" style="width:60px;margin-right:1px" type="text" name="newit618_kgprice[]">$it618_brand_lang753</span>'], [1, ' <input class="txt" style="width:50px" type="text" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="4"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.it618_brand_getlang('s128').'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<font color=red>".it618_brand_getlang('s1249')."</font><input type=hidden value=$page name=page />", $multipage);

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>