<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_brand = $_G['cache']['plugin']['it618_brand'];
$navtitle = $it618_brand['seotitle'];
$metakeywords = $it618_brand['seokeywords'];
$metadescription = $it618_brand['seodescription'];

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if($it618_brand['brand_mode']>2){
	$brandmode=getcookie('brandmode');
	if($brandmode==''){
		if($it618_brand['brand_mode']==3)$brandmode='it618brand';else $brandmode='it618goods';
	}
	if($brandmode=='it618brand'){
		$brandmodestr='<span style="color:#FFF;"><b>'.$it618_brand_lang['s639'].'</b></span>/<span style="color:#FFF;">'.$it618_brand_lang['s853'].'</span>';
	}else{
		$brandmodestr='<span style="color:#FFF;">'.$it618_brand_lang['s639'].'</span>/<span style="color:#FFF;"><b>'.$it618_brand_lang['s853'].'</b></span>';
	}
}else{
	if($it618_brand['brand_mode']==1)$brandmode='it618brand';else $brandmode='it618goods';
}

if($brandmode=='it618brand'){
	$it618_brand_lang['t340']=str_replace($it618_brand_lang['s853'],$it618_brand_lang['s639'],$it618_brand_lang['t340']);
	$it618_brand_lang['t327']=str_replace($it618_brand_lang['s853'],$it618_brand_lang['s639'],$it618_brand_lang['t327']);	
}else{
	$it618_brand_lang['t351']=str_replace($it618_brand_lang['s853'],$it618_brand_lang['s639'],$it618_brand_lang['t351']);
	$it618_brand_lang['s877']=str_replace($it618_brand_lang['s853'],$it618_brand_lang['s639'],$it618_brand_lang['s877']);	
}

global $oss;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/php/aliyunossconfig.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/php/aliyunossconfig.php';
	if($it618_isok==1){
		$oss='&oss';
	}
}

if(isset($_GET['sid'])){
	if($it618_brand['brand_navtype']==1)$isbrandnav=1;
	
	if(($it618_brand['brand_navtype']>2)&&$Shop_isbrandnav==1)$isbrandnav=1;
}else{
	$isbrandnav=1;
}

if($isbrandnav==1){
	$stylecount=C::t('#it618_brand#it618_brand_style')->count_by_isok_shopid(0);
	$it618_brand_style=C::t('#it618_brand#it618_brand_style')->fetch_by_isok_shopid(0);
	
	if($isallclass==1){
		$n=1;
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
		while($it618_brand_brand_class = DB::fetch($query1)) {
		
			$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'],'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id']);
			
			if($n<=8)$str_nav.='<a href="'.$tmpurl.'">'.$it618_brand_brand_class['it618_classname'].'</a>';
			
			$goodscount = C::t('#it618_brand#it618_brand_goods')->count_by_search('g.it618_ison=1 and g.it618_state=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','',0,0,$it618_brand_brand_class['id']);
			$str_class.='<div class="sort">
							<div class="sort-menu"><em class="sort-icon"></em><a class="title" href="'.$tmpurl.'">'.$it618_brand_brand_class['it618_classname'].'</a><span style="color:#999;line-height:26px">('.$goodscount.')</span></div>
							{it618classall}
						</div>';
			$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$it618_brand_brand_class['id']." ORDER BY it618_order");
			$it618classall='';
			while($it618_brand_brand_class1 = DB::fetch($query2)) {
				if($it618_brand_brand_class1['it618_color']!="")
				$tmpname='<font color='.$it618_brand_brand_class1['it618_color'].'>'.$it618_brand_brand_class1['it618_classname'].'</font>';else $tmpname=$it618_brand_brand_class1['it618_classname'];
				
				$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'].'@'.$it618_brand_brand_class1['id'],'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id'].'&class2='.$it618_brand_brand_class1['id']);
				$it618classall.='<li><a href="'.$tmpurl.'">'.$tmpname.'</a></li>';
				if($i1ii1[5]!='_')return; /*dism _ taobao _ com*/
			}
			
			if($it618classall!=''){
				$str_class=str_replace("{it618classall}",'<div class="sort-con">
								<div class="sort-con-left">
									<h4><a href="'.$tmpurl1.'">'.$it618_brand_brand_class['it618_classname'].'</a></h4>
									<ul class="sort-link02 cl">
										'.$it618classall.'
									</ul>
								</div>
							  </div>',$str_class);
			}else{
				$str_class=str_replace("{it618classall}",'',$str_class);
			}
		
			$n=$n+1;
		}
	}else{
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where id<=8 ORDER BY it618_order");
		while($it618_brand_brand_class = DB::fetch($query1)) {
			if($it618_brand_brand_class['it618_img']==''){
				$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'],'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id']);
				
				$str_nav.='<a href="'.$tmpurl.'">'.$it618_brand_brand_class['it618_classname'].'</a>';
				
				$str_class.='<div class="sort">
								<div class="sort-menu"><em class="sort-icon"></em><i class="'.$it618_brand_brand_class['it618_cssname'].'"></i><a class="title '.$it618_brand_brand_class['it618_cssname'].'" href="'.$tmpurl.'">'.cutstr($it618_brand_brand_class['it618_classname'],18,'...').'</a>
									<p>
										{it618classtj}
									</p>
								  </div>
								  <div class="sort-con '.$it618_brand_brand_class['it618_cssname'].'-top">
									<div class="sort-con-left">
										<h4><a href="'.$tmpurl.'">'.$it618_brand_brand_class['it618_classname'].'</a></h4>
										<ul class="sort-link02 cl">
											{it618classall}
										</ul>
									</div>
								  </div>
							</div>';
				$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
				$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class1')." where it618_class_id=".$it618_brand_brand_class['id']." ORDER BY it618_order");
				$it618classtj='';$it618classall='';
				while($it618_brand_brand_class1 = DB::fetch($query2)) {
					if($it618_brand_brand_class1['it618_color']!="")
					$tmpname='<font color='.$it618_brand_brand_class1['it618_color'].'>'.$it618_brand_brand_class1['it618_classname'].'</font>';else $tmpname=$it618_brand_brand_class1['it618_classname'];
					
					$tmpurl=it618_brand_getrewrite('brand_list',$it618_brand_brand_class['id'].'@'.$it618_brand_brand_class1['id'],'plugin.php?id=it618_brand:list&class1='.$it618_brand_brand_class['id'].'&class2='.$it618_brand_brand_class1['id']);
					if($it618_brand_brand_class1['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'">'.$tmpname.'</a>';
					$it618classall.='<li><a href="'.$tmpurl.'">'.$tmpname.'</a></li>';
					if($i1ii1[5]!='_')return; /*dism _ taobao _ com*/
				}
				
				$str_class=str_replace("{it618classtj}",$it618classtj,$str_class);
				$str_class=str_replace("{it618classall}",$it618classall,$str_class);
			}else{
				if($it618_brand_brand_class['it618_url']!=''){
					$str_class.='<div class="sort">
								<a href="'.$it618_brand_brand_class['it618_url'].'" target="_blank"><img src="'.$it618_brand_brand_class['it618_img'].'" width="212" height="56" style="margin-left:2px"></a>
							</div>';
				}else{
					$str_class.='<div class="sort">
								<img src="'.$it618_brand_brand_class['it618_img'].'" width="212" height="56" style="margin-left:2px">
							</div>';
				}
			}
		}
	}
	
	$str_class.='<div class="sort-lottery">
					<div class="sort-menu" style="height:0;padding:0; margin:0"></div>
				 </div>';
	
	$count = C::t('#it618_brand#it618_brand_nav')->count_by_search();
	if($count>0){
		$str_nav='';
		foreach(C::t('#it618_brand#it618_brand_nav')->fetch_all_by_search() as $it618_brand_nav) {
			if($it618_brand_nav['it618_color']!="")
			$tmpname='<font color='.$it618_brand_nav['it618_color'].'>'.$it618_brand_nav['it618_name'].'</font>';else $tmpname=$it618_brand_nav['it618_name'];
			
			if($it618_brand_nav['it618_target']==1)$it618_target=' target="_blank"';else $it618_target='';
			
			$str_nav.='<a href="'.$it618_brand_nav['it618_url'].'"'.$it618_target.'>'.$tmpname.'</a>';
		}
	}
}else{
	if(isset($_GET['sid'])){
		$shopstylecount=C::t('#it618_brand#it618_brand_style')->count_by_isok_shopid($ShopId);
		$it618_brand_shopstyle=C::t('#it618_brand#it618_brand_style')->fetch_by_isok_shopid($ShopId);
		
		$shopstylecount0=C::t('#it618_brand#it618_brand_style')->count_by_isok_shopid(0);
		$it618_brand_shopstyle0=C::t('#it618_brand#it618_brand_style')->fetch_by_isok_shopid(0);
	}
}

if($_G['uid']>0){
	C::t('#it618_brand#it618_brand_sale')->update_lastactivity_by_uid(TIMESTAMP,$_G['uid']);
	$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
	if(in_array($_G['uid'],$shopadmin)&&$ShopId>0){
		$tmpurl=it618_brand_getrewrite('shop_sc','','plugin.php?id=it618_brand:sc&adminsid='.$ShopId,'adminsid='.$ShopId);
		$shopadminurl='<li>
				<a href="'.$tmpurl.'" target="_blank"><font color=red>'.it618_brand_getlang('s1219').'</font></a> 
			</li>';
	}
	if(C::t('#it618_brand#it618_brand_brand')->count_by_it618_uid($_G['uid'])>0){
		$tmprz='<li>
					<a href="javascript:" class="renzheng"><font color=red>'.it618_brand_getlang('s859').'</font></a> 
				</li>';
		if(C::t('#it618_brand#it618_brand_brand')->fetch_it618_state_by_it618_uid($_G['uid'])==2){
			$tmpurl=it618_brand_getrewrite('shop_sc','','plugin.php?id=it618_brand:sc');
			$tmprz='<li>
						<a href="'.$tmpurl.'" target="_blank"><font color=#FF00FF>'.it618_brand_getlang('s861').'</font></a> 
					</li>
					';
		}
	}else{
		$tmprz='<li>
					<a href="javascript:" class="renzheng"><font color=red>'.it618_brand_getlang('s862').'</font></a> 
				</li>';
	}
	$tmprz.=$shopadminurl;
	
	$moneycount=C::t('#it618_brand#it618_brand_money')->count_by_shopid(0,0,0,0,$_G['uid']);
	$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(1,$moneycount);
	$tmplevelarr=explode(",",$it618_brand['brand_level']);
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		$it618_members = $_G['cache']['plugin']['it618_members'];
		if($it618_members['members_ishome']==1||$it618_members['members_ishome']==2){
			$tmpmembers='<li>
					<a href="javascript:" class="login-link" id="it618_members" style="color:#666"><img src="source/plugin/it618_members/images/logo.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px" />'.$it618_members['members_homename'].'</a> 
					</li>';
		}
	}
	
	if($IsCredits==1){
		$tmpcredits='<li>
					<a href="javascript:" class="login-link" id="it618_credits" style="color:#666"><img src="source/plugin/it618_credits/images/bigico.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px" />'.it618_brand_getlang('s1467').'</a> 
					</li>';
	}
	
	if($IsGroup==1){
		$tmpgroup='<li>
					<a href="javascript:" class="login-link" id="it618_group" style="color:#666"><img src="source/plugin/it618_group/images/group.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px" />'.it618_brand_getlang('s1946').'</a> 
					</li>';
	}
	
	$count=C::t('#it618_brand#it618_brand_gwc')->count_by_uid($_G['uid']);
	if($count>0)$count='<font color=red>'.$count.'</font>';
	$gwcurl=it618_brand_getrewrite('brand_gwc','','plugin.php?id=it618_brand:gwc');
	
	$usermenu='<ul class="login cl">
                <li class="login-link">'.$_G['username'].'</li>
				'.$tmpmembers.'
				'.$tmpcredits.'
				'.$tmpgroup.'
				<li style="padding-top:5px;"><a href="'.$gwcurl.'" target="_blank" style="color:#666"><img src="source/plugin/it618_brand/images/gwc.png" style="vertical-align:middle;height:13px;margin-top:-1px"/> '.$it618_brand_lang['t192'].'(<span id="gwccount">'.$count.'</span>)</a></li>
				<li style="padding-top:5px;">'.$tmplevelarr[1].it618_brand_getlang('s562').'<a href="'.$it618_brand['brand_levelurl'].'" target="_blank" title="'.$it618_brand_level['it618_name'].' '.$it618_brand['brand_leveltitle'].'"><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'"></a></li>
                <li class="dropdown dropdown-account">
                    <p class="textwarp">
                        <em class="text">'.it618_brand_getlang('s863').'</em>
                        <i class="triangle"></i>
                        <em class="account-num" style="display:none;"></em>
					</p>
                    <ul class="htul">
						<li>
						<a href="javascript:" onclick="document.getElementById(\'tmpaddrbtn\').click();"><span id="tmpaddrbtn"></span>'.it618_brand_getlang('s1632').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mycard"><font color=red>'.it618_brand_getlang('s1400').'</font></a> 
				    	</li>
						<li>
						<a href="javascript:" id="mysale"><font color=green>'.it618_brand_getlang('s864').'</font></a> 
				    	</li>
						<li>
						<a href="javascript:" id="mysale1"><font color=#d56c05>'.it618_brand_getlang('s1401').'</font></a> 
				    	</li>
						<li>
						<a href="javascript:" id="myorder">'.it618_brand_getlang('s1512').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mycollect">'.it618_brand_getlang('s1738').'</a> 
				    	</li>
                        '.$it618_brand['brand_topnavmenu'].'
						'.$tmprz.'
                    </ul>
                </li>
                <li><a class="login-link" href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" style="color:#666">['.it618_brand_getlang('s867').']</a></li>
			   </ul>';
}else{
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if($it618_members['members_isok']==1){
		$usermenu='<ul class="login cl">
                <li><a class="login-link it618_members_login" href="javascript:" style="color:#666">['.it618_brand_getlang('s868').']</a></li>
                <li><a class="login-link it618_members_reg" href="javascript:" style="color:#666">['.it618_brand_getlang('s869').']</a></li>
               </ul>';
	}else{
		$usermenu='<ul class="login cl">
                <li><a class="login-link" href="member.php?mod=logging&action=login" style="color:#666">['.it618_brand_getlang('s868').']</a></li>
                <li><a class="login-link" href="member.php?mod='.$RegName.'" style="color:#666">['.it618_brand_getlang('s869').']</a></li>
               </ul>';
	}
}

function getshopslist($getbrandarea=0,$getbrandarea1=0,$getpname='',$getporderby='',$getpage=1){
	global $_G,$it618_brand,$it618_brand_lang,$creditname;
	$ppp = $it618_brand['brand_listbrandcount'];
	$page = max(1, intval($getpage));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='it618_state=2 and it618_htstate=1';
	
	if($getporderby==0)$orderby='it618_order desc';
	if($getporderby==1)$orderby='it618_levelsum';
	if($getporderby==2)$orderby='it618_levelsum desc';
	if($getporderby==3)$orderby='it618_time desc';
	
	$count = C::t('#it618_brand#it618_brand_brand')->count_by_search($sql,'',$getpname,$getbrandarea,$getbrandarea1);
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].'plugin.php?id=it618_brand:ajax');
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getshops(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getshops(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getshops(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	foreach(C::t('#it618_brand#it618_brand_brand')->fetch_all_by_search(
		$sql,$orderby,$getpname,$getbrandarea,$getbrandarea1,0,0,0,$startlimit,$ppp
	) as $it618_brand_brand) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;

		$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
		$ShopPowerIco='';
		if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" align="absmiddle" style="margin-top:2px"/>';
			
		if($it618_brand_brand['it618_mappoint']!='')$mapstr=' <a href="javascript:"><img class="brandmap" name="'.$it618_brand_brand['id'].'" src="source/plugin/it618_brand/images/map.png"></a>';
		
		$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($it618_brand_brand[id]);
		$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
		$tmplevelarr=explode(",",$it618_brand['brand_level']);
		
		$tmpurl=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
		$str_shopslist.='<div class="index-goods">
							<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
								<img src="'.$it618_brand_brand['it618_logo'].'" alt="'.$it618_brand_brand['it618_name'].'"/>
								<span class="index-goods-place">'.$it618_brand_brand['it618_youhui'].'</span>
							</a>
							<h3>
								<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_brand['it618_name'].'">'.$it618_brand_brand['it618_name'].' '.$ShopPowerIco.'</a>
							</h3>
							<div class="index-goods-info">
								<span title="'.$it618_brand_brand['it618_addr'].'">'.cutstr($it618_brand_brand['it618_addr'],30,'...').$mapstr.'</span><br>'.$it618_brand_brand['it618_dianhua'].' '.$it618_brand_brand['it618_shouji'].'<br><span style="float:right"><a href="'.$tmpurl.'" target="_blank">'.$it618_brand_lang['s1639'].'</a></span><font color="#666" style="font-size:13px">'.str_replace(it618_brand_getlang('s1175'),"",$tmplevelarr[0]).':</font><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'">
							</div>
						</div>';
		
	}

	return $str_shopslist.'<script type="text/javascript" src="source/plugin/it618_brand/js/common.js"></script>it618_split'.$multipage;
}

function getgoodslist($getbrandarea=0,$getbrandarea1=0,$getbrandclass=0,$getbrandclass1=0,$getptype=0,$getpname='',$getpprice1=0,$getpprice2=0,$getporderby='',$getpage=1){
	global $_G,$it618_brand,$it618_brand_lang,$creditname;
	$ppp = $it618_brand['brand_listgoodscount'];
	$page = max(1, intval($getpage));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='g.it618_ison=1 and b.it618_state=2 and b.it618_htstate=1';
	if($_GET['it618_paytype']==1)$sql.=" and g.it618_isduihuan=1";
	if($_GET['it618_paytype']==2)$sql.=" and g.it618_isalipay=1";
	
	if($_GET['it618_saletype']==1)$sql.=" and (g.it618_saletype=1 or g.it618_saletype=4)";
	if($_GET['it618_saletype']==2)$sql.=" and (g.it618_saletype=2 or g.it618_saletype=4)";
	if($_GET['it618_saletype']==3)$sql.=" and g.it618_saletype=3";
	if($_GET['it618_saletype']==4)$sql.=" and g.it618_saletype=5";
	
	if($getporderby==0)$orderby='g.it618_isduihuan desc,g.id desc';
	if($getporderby==1)$orderby='g.it618_uprice,g.it618_isduihuan desc';
	if($getporderby==2)$orderby='g.it618_uprice desc,g.it618_isduihuan desc';
	if($getporderby==3)$orderby='g.it618_salecount desc,g.it618_isduihuan desc';
	if($getporderby==4)$orderby='g.it618_views desc,g.it618_isduihuan desc';
	
	$count = C::t('#it618_brand#it618_brand_goods')->count_by_search($sql,'',$getbrandarea,$getbrandarea1,$getbrandclass,$getbrandclass1,$getpname,$getpprice1,$getpprice2);
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].'plugin.php?id=it618_brand:ajax');
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getprouct(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getprouct(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getprouct(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_search(
			$sql,$orderby,$getbrandarea,$getbrandarea1,$getbrandclass,$getbrandclass1,$getpname,$getpprice1,$getpprice2,$startlimit,$ppp
	) as $it618_brand_goods) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;

		$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
		
		$jfblstr='';
		if($it618_brand_goods['it618_saletype']==6){
			$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
			$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
		}
		
		if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
			$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
		}
		
		$jfbl='';
		if($jfblstr!=''){
			$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
		}
	
		$it618_count=$it618_brand_lang['s1652'].' <font color="#FF6600">'.$it618_brand_goods['it618_count'].'</font>';
		
		if($it618_brand_goods['it618_isalipay']==1){
			$pricestr='<span class="price">&yen;'.floatval($it618_brand_goods['it618_uprice']).'</span><del style="font-weight:normal;font-size:16px">&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
		}else{
			$pricestr='<span class="price" style="color:#390">'.$it618_brand_goods['it618_score'].'<span style="font-weight:normal;font-size:15px">'.$creditname.'</span></span>';
		}
		
		if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
			$jfblstr='<span style="float:right"><font color=#339900>'.$it618_brand_goods['it618_score'].$creditname.'</font></span>'.$jfblstr;
		}
		
		$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
		$salecount='<span style="float:right">'.it618_brand_getlang('s872').$salecount.'</span>';
		
		if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
			$pricestr='<span class="price" style="color:green">'.$it618_brand_lang['s761'].'</span>';
			$jfblstr=$it618_brand_lang['s1732'].'<br>';
			$salecount='<span style="float:right;">'.it618_brand_getlang('t474').' <font color=#FF6600>'.$it618_brand_goods['it618_views'].'</font></span>';
		}
		
		$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
		$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
		$pjhaobl=intval($pjhaocount/$pjallcount*100);
		$pj=$it618_brand_lang['s1899'];
		if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';

		$getprouctlist.='<div class="goods goods1 products">
						'.$jfbl.'
							  <a class="goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" alt="'.$it618_brand_goods['it618_name'].'" width="219" height="219" />
							  <span class="goods-place">'.$it618_brand_brand['it618_name'].'<br><span style="font-size:12px;line-height:14px">'.$it618_brand_goods['it618_seodescription'].'</span></span>
							  </a>
							  <h4>
								  <a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'">'.$it618_brand_goods['it618_name'].'</a>
							  </h4>
							  
							  <div class="goods-info">
								  <div class="saletype">'.$salecount.$pj.'</div>
								  '.$pricestr.'
							  </div>
							  
						  </div>';
		
	}

	return '<div class="list-content">
			<div class="goods-list newga ga cl">
			'.$getprouctlist.'
			</div>
			<div class="page">
			'.$multipage.'
			</div>
			</div>';	
}

function getpaihang(){
	global $_G,$it618_brand,$getpaihang_shop,$getpaihang_user;
	$n=1;
	if($it618_brand['brand_phbrandcount']>0){
		foreach(C::t('#it618_brand#it618_brand_brand')->fetch_all_by_search('it618_state=2 and it618_htstate=1','it618_levelsum DESC','',0,0,0,0,0,$it618_brand['brand_phbrandcount']) as $it618_brand_brand) {
	
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[3]!='1')return;
			
			$tmpurl=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
			$getpaihang_shop.='<tr><td style="border-bottom:1px solid #e1e1e1;padding-top:3px;padding-bottom:3px;font-size:12px"><span style="float:right">'.$it618_brand_brand['it618_levelsum'].it618_brand_getlang('s1671').'</span><b>'.$n.'</b>'.it618_brand_getlang('s8').' <a href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_brand['it618_name'].'">'.cutstr($it618_brand_brand['it618_name'],18,'...').'</a></td></tr>';
			
			$n=$n+1;
			
		}
	}
	
	if($it618_brand['brand_phusercount']>0){
		$n=1;
		foreach(C::t('#it618_brand#it618_brand_sale')->fetch_paihang_by_extcredits($it618_brand['brand_credit'],$it618_brand['brand_phusercount']) as $it618_brand_sale) {
	
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[3]!='1')return;
			$username=it618_brand_getusername($it618_brand_sale['uid']);
			$getpaihang_user.='<tr><td style="border-bottom:1px solid #e1e1e1;padding-top:3px;padding-bottom:3px;font-size:12px"><span style="float:right">'.$it618_brand_sale['jifen'].it618_brand_getlang('s540').'</span><b>'.$n.'</b>'.it618_brand_getlang('s8').' <a href="'.it618_brand_rewriteurl($it618_brand_sale['uid']).'" target="_blank" title="'.$username.'">'.$username.'</a></td></tr>';
			
			$n=$n+1;
			
		}
	}
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	if(isset($_GET['reg']))$winapireg='winapireg';
	$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','',$winapireg);
}

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$it618_credits_buygroup=it618_credits_getcredits($_GET['id'],'#vippaybtn','plugin.php?id=it618_credits:do&dotype=buygroup');
	$it618_credits_index=it618_credits_getcredits($_GET['id'],'#it618_credits').$it618_credits_buygroup;
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_uc=it618_group_getgroup($_GET['id'],'#it618_group');
	$it618_group_ad=it618_group_getad($_GET['id'],2);
}
//From: Dism��taobao��com
?>