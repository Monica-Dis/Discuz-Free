<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if(submitcheck('it618submit')){
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_brand#it618_brand_show')->delete_by_id($delid);
		$del=$del+1;
	}
	
	C::t('#it618_brand#it618_brand_brand')->update($ShopId,array(
		'it618_seokeywords' => dhtmlspecialchars($_GET['it618_seokeywords']),
		'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription']),
		'it618_homenavname' => dhtmlspecialchars($_GET['it618_homenavname']),
		'it618_systemcount' => $_GET['it618_systemcount'],
		'it618_ishomely' => $_GET['it618_ishomely'],
		'it618_homelycount' => $_GET['it618_homelycount'],
		'it618_isproductly' => $_GET['it618_isproductly'],
		'it618_isgoodsclass' => $_GET['it618_isgoodsclass'],
		'it618_isyunfeikg' => $_GET['it618_isyunfeikg'],
		'it618_productlycount' => $_GET['it618_productlycount'],
		'it618_isarticlely' => $_GET['it618_isarticlely'],
		'it618_articlelycount' => $_GET['it618_articlelycount'],
		'it618_productvisitcount' => $_GET['it618_productvisitcount'],
		'it618_productsalecount' => $_GET['it618_productsalecount'],
		'it618_telsalenav' => $_GET['it618_telsalenav']
	));
	
	if($it618_brand['brand_navtype']>2){
		C::t('#it618_brand#it618_brand_brand')->update($ShopId,array(
			'it618_isbrandnav' => $_GET['it618_isbrandnav']
		));
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_brand#it618_brand_show')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_ishome' => $_GET['it618_ishome'][$id],
				'it618_isnav' => $_GET['it618_isnav'][$id],
				'it618_isblank' => $_GET['it618_isblank'][$id],
				'it618_isbold' => $_GET['it618_isbold'][$id],
				'it618_color' => $_GET['it618_color'][$id],
				'it618_homecount' => $_GET['it618_homecount'][$id],
				'it618_pagecount' => $_GET['it618_pagecount'][$id],
				'it618_homeorder' => intval($_GET['it618_homeorder'][$id]),
				'it618_navorder' => intval($_GET['it618_navorder'][$id]),
				'it618_url' => $_GET['it618_url'][$id]
			));
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_isnav_array = !empty($_GET['newit618_isnav']) ? $_GET['newit618_isnav'] : array();
	$newit618_isblank_array = !empty($_GET['newit618_isblank']) ? $_GET['newit618_isblank'] : array();
	$newit618_isbold_array = !empty($_GET['newit618_isbold']) ? $_GET['newit618_isbold'] : array();
	$newit618_navorder_array = !empty($_GET['newit618_navorder']) ? $_GET['newit618_navorder'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_url_array = !empty($_GET['newit618_url']) ? $_GET['newit618_url'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = trim($newit618_name_array[$key]);
		
		if($newit618_name != '') {
			
			C::t('#it618_brand#it618_brand_show')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_showtype' => 'diynav',
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_isnav' => trim($newit618_isnav_array[$key]),
				'it618_isblank' => trim($newit618_isblank_array[$key]),
				'it618_isbold' => trim($newit618_isbold_array[$key]),
				'it618_navorder' => trim($newit618_navorder_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_url' => trim($newit618_url_array[$key])
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}

	it618_cpmsg(it618_brand_getlang('s90'), "plugin.php?id=it618_brand:sc_show$adminsid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_brand:sc_show$adminsid");
showtableheaders(it618_brand_getlang('s320'),'it618_brand_show');

$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);

if($it618_brand_brand['it618_ishomely']==1)$it618_ishomely_checked='checked="checked"';else $it618_ishomely_checked="";
if($it618_brand_brand['it618_isproductly']==1)$it618_isproductly_checked='checked="checked"';else $it618_isproductly_checked="";
if($it618_brand_brand['it618_isgoodsclass']==1)$it618_isgoodsclass_checked='checked="checked"';else $it618_isgoodsclass_checked="";
if($it618_brand_brand['it618_isyunfeikg']==1)$it618_isyunfeikg_checked='checked="checked"';else $it618_isyunfeikg_checked="";
if($it618_brand_brand['it618_isarticlely']==1)$it618_isarticlely_checked='checked="checked"';else $it618_isarticlely_checked="";
echo '
<tr><td>'.it618_brand_getlang('s322').'<br><input type="text" style="width:800px;margin-top:3px" name="it618_seokeywords" value="'.$it618_brand_brand[it618_seokeywords].'"/></td></tr>
<tr><td>'.it618_brand_getlang('s323').'<br><textarea style="width:800px;height:50px;vertical-align:middle;margin-top:3px" name="it618_seodescription">'.$it618_brand_brand[it618_seodescription].'</textarea></td></tr>
<tr><td>
'.it618_brand_getlang('s324').'<input type="text" style="width:100px" name="it618_homenavname" value="'.$it618_brand_brand[it618_homenavname].'"/>
'.it618_brand_getlang('s325').'<input type="text" style="width:50px" name="it618_systemcount" value="'.$it618_brand_brand[it618_systemcount].'"/>
'.it618_brand_getlang('s328').'<input class="checkbox" type="checkbox" name="it618_ishomely" '.$it618_ishomely_checked.' value="1">
'.it618_brand_getlang('s329').'<input type="text" style="width:50px" name="it618_homelycount" value="'.$it618_brand_brand[it618_homelycount].'"/>
'.it618_brand_getlang('s326').'<input class="checkbox" type="checkbox" name="it618_isarticlely" '.$it618_isarticlely_checked.' value="1">
'.it618_brand_getlang('s327').'<input type="text" style="width:50px" name="it618_articlelycount" value="'.$it618_brand_brand[it618_articlelycount].'"/>
</td></tr>
';
if($Shop_isgoods==1){echo '
<tr><td>'.it618_brand_getlang('s334').'<input type="text" style="width:50px" name="it618_productvisitcount" value="'.$it618_brand_brand[it618_productvisitcount].'"/>
'.it618_brand_getlang('s335').'<input type="text" style="width:50px" name="it618_productsalecount" value="'.$it618_brand_brand[it618_productsalecount].'"/>
'.it618_brand_getlang('s336').'<input class="checkbox" type="checkbox" name="it618_isproductly" '.$it618_isproductly_checked.' value="1">
'.it618_brand_getlang('s337').'<input type="text" style="width:50px" name="it618_productlycount" value="'.$it618_brand_brand[it618_productlycount].'"/>
<font color=red>'.it618_brand_getlang('s1672').'</font><input class="checkbox" type="checkbox" name="it618_isgoodsclass" '.$it618_isgoodsclass_checked.' value="1">
'.it618_brand_getlang('s1729').'<input class="checkbox" type="checkbox" name="it618_isyunfeikg" '.$it618_isyunfeikg_checked.' value="1">
<tr><td>'.it618_brand_getlang('s1091').'<br><textarea style="width:800px;height:50px;vertical-align:middle;margin-top:3px" name="it618_telsalenav">'.$it618_brand_brand[it618_telsalenav].'</textarea><br>'.$it618_brand_lang['s1090'].'</td></tr>
';

echo '</td></tr>';
}

showtablefooter(); /*dism��taobao��com*/

showtableheaders(it618_brand_getlang('s338'),'it618_brand_show');

	if($it618_brand_brand['it618_isbrandnav']==1)$it618_isbrandnav1='selected="selected"';else $it618_isbrandnav1="";
	if($it618_brand_brand['it618_isbrandnav']==2)$it618_isbrandnav2='selected="selected"';else $it618_isbrandnav2="";
	
	$count = C::t('#it618_brand#it618_brand_show')->count_by_shopid($ShopId);
	if($it618_brand['brand_navtype']>2){
		echo '<tr><td colspan=8><b>'.it618_brand_getlang('s1770').'</b><select name="it618_isbrandnav"><option value=1 '.$it618_isbrandnav1.'>'.it618_brand_getlang('s1771').'</option><option value=2 '.$it618_isbrandnav2.'>'.it618_brand_getlang('s1772').'</option></select> '.it618_brand_getlang('s1773').'</td></tr>';
	}
	echo '<tr><td colspan=8>'.it618_brand_getlang('s339').$count.' <span style="float:right;">'.it618_brand_getlang('s340').'</span></td></tr>';
	showsubtitle(array('',it618_brand_getlang('s341'),it618_brand_getlang('s342'),it618_brand_getlang('s343'),it618_brand_getlang('s344'),it618_brand_getlang('s345'),it618_brand_getlang('s346')));

	$n=1;
	foreach(C::t('#it618_brand#it618_brand_show')->fetch_all_by_shopid($ShopId) as $it618_brand_show) {
		if($it618_brand_show['it618_ishome']==1)$it618_ishome_checked='checked="checked"';else $it618_ishome_checked="";
		if($it618_brand_show['it618_isnav']==1)$it618_isnav_checked='checked="checked"';else $it618_isnav_checked="";
		if($it618_brand_show['it618_isblank']==1)$it618_isblank_checked='checked="checked"';else $it618_isblank_checked="";
		if($it618_brand_show['it618_isbold']==1)$it618_isbold_checked='checked="checked"';else $it618_isbold_checked="";
		
		$homestr='<input class="checkbox" type="checkbox" id="it618_ishome'.$n.'" name="it618_ishome['.$it618_brand_show['id'].']" '.$it618_ishome_checked.' value="1">/<input type="text" class="txt" style="width:30px" name="it618_homeorder['.$it618_brand_show[id].']" value="'.$it618_brand_show[it618_homeorder].'">';
		$navstr='<input class="checkbox" type="checkbox" id="it618_isnav'.$n.'" name="it618_isnav['.$it618_brand_show['id'].']" '.$it618_isnav_checked.' value="1">/<input type="text" class="txt" style="width:30px;margin-right:3px" name="it618_navorder['.$it618_brand_show[id].']" value="'.$it618_brand_show[it618_navorder].'">/<input class="checkbox" type="checkbox" id="it618_isblank'.$n.'" name="it618_isblank['.$it618_brand_show['id'].']" '.$it618_isblank_checked.' value="1">';
		
		$inputtype='hidden';
		$homecount='<input type="text" class="txt" style="width:50px" name="it618_homecount['.$it618_brand_show[id].']" value="'.$it618_brand_show[it618_homecount].'">';
		$pagecount='<input type="text" class="txt" style="width:50px" name="it618_pagecount['.$it618_brand_show[id].']" value="'.$it618_brand_show[it618_pagecount].'">';
		
		
		if($it618_brand_show['it618_showtype']=='onepage'){$it618_showtype=it618_brand_getlang('s347');$it618_count=it618_brand_getlang('s348');}
		if($it618_brand_show['it618_showtype']=='image'){$it618_showtype=it618_brand_getlang('s349');$it618_count=it618_brand_getlang('s350').$homecount.it618_brand_getlang('s351').$pagecount;}
		
		$it618_name=$it618_brand_show[it618_name];
		
		if($it618_brand_show['it618_showtype']=='article'){$it618_showtype=it618_brand_getlang('s352');$it618_count=it618_brand_getlang('s353').$homecount.it618_brand_getlang('s354').$pagecount;}
		if($it618_brand_show['it618_showtype']=='product_all'){$it618_showtype=it618_brand_getlang('s355');$it618_name=it618_brand_getlang('s356');$inputtype='text';$it618_count=it618_brand_getlang('s357').$homecount.it618_brand_getlang('s358').$pagecount;}
		if($it618_brand_show['it618_showtype']=='product_tj'){$it618_showtype=it618_brand_getlang('s355');$it618_name=it618_brand_getlang('s359');$inputtype='text';$it618_count=it618_brand_getlang('s357').$homecount;$navstr='';}
		if($it618_brand_show['it618_showtype']=='visit'){$it618_showtype=it618_brand_getlang('s355');$it618_name=it618_brand_getlang('s360');$inputtype='text';$it618_count=it618_brand_getlang('s361').$homecount.it618_brand_getlang('s362').$pagecount;$homestr='';}
		if($it618_brand_show['it618_showtype']=='money'){$it618_showtype=it618_brand_getlang('s355');$it618_name=it618_brand_getlang('s363');$inputtype='text';$it618_count=it618_brand_getlang('s364').$homecount.it618_brand_getlang('s365').$pagecount;}
		if($it618_brand_show['it618_showtype']=='thread_new'){$it618_showtype=it618_brand_getlang('s355');$it618_name=it618_brand_getlang('s681');$inputtype='text';$it618_count=it618_brand_getlang('s682').$homecount;$navstr='';}
		if($it618_brand_show['it618_showtype']=='thread_hot'){$it618_showtype=it618_brand_getlang('s355');$it618_name=it618_brand_getlang('s683');$inputtype='text';$it618_count=it618_brand_getlang('s682').$homecount;$navstr='';}
		
		$colorstr='';
		if($navstr!='')$colorstr='<span style="float:left;margin-right:3px"><input class="checkbox" type="checkbox" id="it618_isbold'.$n.'" name="it618_isbold['.$it618_brand_show['id'].']" '.$it618_isbold_checked.' value="1">/</span>'."<input id=\"c".$it618_brand_show['id']."_v\" type=\"text\" class=\"txt\" style=\"width:60px;float:left\" name=\"it618_color[$it618_brand_show[id]]\" value=\"$it618_brand_show[it618_color]\" onchange=\"updatecolorpreview('c".$it618_brand_show['id']."')\"><input id=\"c".$it618_brand_show['id']."\" onclick=\"c".$it618_brand_show['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_brand_show['id']."|c".$it618_brand_show['id']."_v';showMenu({'ctrlid':'c".$it618_brand_show['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_brand_show['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_brand_show['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>";
		
		$it618_name1='<font color="'.$it618_brand_show[it618_color].'">'.$it618_name.'</font> <input type="'.$inputtype.'" style="width:80px" name="it618_name['.$it618_brand_show['id'].']" value="'.$it618_brand_show[it618_name].'"/>';
		
		
		$disabled="";
		if($it618_brand_show['it618_showtype']!='diynav'){
			$disabled="disabled=\"disabled\"";
		}else{
			$it618_name1='<input type="text" style="width:132px" name="it618_name['.$it618_brand_show['id'].']" value="'.$it618_brand_show[it618_name].'"/>';
			$it618_showtype=$it618_brand_lang['s1768'];
			$homestr='';
			$it618_count=$it618_brand_lang['s1769'].'<input type="text" style="width:350px" name="it618_url['.$it618_brand_show['id'].']" value="'.$it618_brand_show[it618_url].'"/>';
		}
		
		showtablerow('', array('class="td25"','', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" $disabled value=\"$it618_brand_show[id]\">",
			$it618_name1,
			$it618_showtype,
			$homestr,
			$navstr,
			$colorstr,
			$it618_count
		));
		if($navstr!='')$tmpcolorjs.="updatecolorpreview('c".$it618_brand_show['id']."');";
		$n=$n+1;
	}
	
	$s1768=$it618_brand_lang['s1768'];
	$s1769=$it618_brand_lang['s1769'];
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_color[]").length;
		
		return [
				[[1,''],[1,'<input type="text" class="txt" style="width:132px;" name="newit618_name[]">'],[1,'$s1768'],[1,''], [1, '<input class="checkbox" type="checkbox" name="newit618_isnav[]" value="1">/<input type="text" class="txt" style="width:30px;margin-right:3px" name="newit618_navorder[]" value="0">/<input class="checkbox" type="checkbox" name="newit618_isblank[]" value="1">'],[1,'<span style="float:left;margin-right:3px"><input class="checkbox" type="checkbox" name="newit618_isbold[]" value="1">/</span><input id="c_add'+n+'_v" type="text" class="txt" style=\"width:60px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1, '$s1769<input type="text" class="txt" style="width:350px;" name="newit618_url[]">']]
				];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td colspan="8"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.it618_brand_getlang('s128').'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
showtablefooter(); /*dism��taobao��com*/
echo '<script>'.$tmpcolorjs.'</script>';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>