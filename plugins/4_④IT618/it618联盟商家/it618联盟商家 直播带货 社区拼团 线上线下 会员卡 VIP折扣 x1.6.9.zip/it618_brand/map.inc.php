<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if($it618_brand['brand_wap']==1&&$_GET['nowindow']!=1){
	if(brand_is_mobile()){ 
		$tmpurl=it618_brand_getrewrite('brand_wap','','plugin.php?id=it618_brand:wap');
		dheader("location:$tmpurl"); /*dism - taobao - com*/
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php';
}

$bdkey=$mapapi_bdak;

$it618_mappoint=$_GET['it618_mappoint'];

if(isset($_GET['sid'])){
	$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
	$it618_mappoint=$it618_brand_brand['it618_mappoint'];
	
	$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
	$ShopPower=$it618_brand_brandgroup['it618_groupname'];
	
	if($it618_brand_brand['it618_mapurl']!=''){
		$mapurl="<tr><td colspan='2'><a href='{$it618_brand_brand['it618_mapurl']}' target='_blank' style='cursor:pointer;background-color:#390; padding:3px 13px; font-size:13px; float:right;color:#fff;text-decoration:none;'>".$it618_brand_lang['s1842']."</a><td></tr>";	
	}
}

$metatitle=$it618_brand_brand['it618_name'].' - '.$metatitle;
$metakeywords=$it618_brand_brand['it618_seokeywords'];
$metadescription=$it618_brand_brand['it618_seodescription'];

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:map');
?>