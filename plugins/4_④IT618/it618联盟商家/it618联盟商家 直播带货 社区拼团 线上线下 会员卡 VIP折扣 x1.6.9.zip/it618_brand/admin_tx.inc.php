<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if(count($reabc)!=11)return; /*d'.'is'.'m.tao'.'ba'.'o.com*/

loadcache('plugin');
$it618_brand = $_G['cache']['plugin']['it618_brand'];

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function/it618_brand.func.php';

if($reabc[8]!='a')return; /*Dism_taobao_com*/
$ppp = $it618_brand['pagecount'];
$page = max(1, intval($_GET['page']));
if($_GET['findbtn']==1)$page=1;
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier']; /*dism- taobao- com*/
$urls = '&pmod=admin_tx&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_tx');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_tx' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism��taobao��com*/
?>