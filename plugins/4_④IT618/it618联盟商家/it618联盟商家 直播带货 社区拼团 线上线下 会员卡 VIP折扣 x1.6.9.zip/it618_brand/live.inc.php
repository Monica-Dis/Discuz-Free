<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

if($it618_brand_live=C::t('#it618_brand#it618_brand_live')->fetch_by_shopid($ShopId)){
	$videotype=$it618_brand_live['it618_type'];
	if($videotype>0){
		if($it618_brand_live['it618_islogin']==1&&$_G['uid']==0){
			echo $it618_brand_lang['s1087'];exit;
		}
		
		$IsChat=$it618_brand_live['it618_ischat'];
			
		if($videotype==1){
			$liveid=$it618_brand_live['it618_liveid'];
			$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($liveid);
			$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($liveid);
			$it618_name=$it618_video_live['it618_name'];
			
			if($it618_video_live['it618_etime']<$_G['timestamp']){
				echo $it618_brand_lang['s1085'];exit;
			}else{
				if($it618_video_live['it618_btime']>$_G['timestamp']){
					$timeflag=1;
					$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
					$etimestr=date('Y-m-d H:i:s', $it618_video_live['it618_btime']);
					$timetip=$it618_brand_lang['s1957'].date('Y-m-d H:i:s', $it618_video_live['it618_btime']).' - '.date('Y-m-d H:i:s', $it618_video_live['it618_etime']);
				}
				$it618_url=$it618_video_live['it618_m3u8url'];
				$tmparr=explode("@",$it618_url);
				if(count($tmparr)>1){
					$it618_url=$tmparr[1];
					if($_GET['wap']==0)$it618_url=$tmparr[0];
				}else{
					if($_GET['wap']==0){
						if($it618_video_live['it618_liveset_id']>0)$it618_url=$it618_video_live['it618_flvurl'];
						if($it618_url=='')$it618_url=$it618_video_live['it618_m3u8url'];
					}
				}
			}
		}
		
		if($videotype==2){
			require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
			$it618_url=it618_video_cdnkeyurl($it618_brand_live['it618_videourl']);
		}
		
		if($videotype==3){
			$it618_url=$it618_brand_live['it618_videoiframe'];
			$urlarr=explode("https://",$_G['siteurl']);
			if(count($urlarr)>1){
				$it618_url=str_replace("http://","https://",$it618_url);
			}
		}
		
	}else{
		echo $it618_brand_lang['s1086'];exit;
	}
}else{
	echo $it618_brand_lang['s1086'];exit;
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
if($_GET['wap']==1){
	$stylecount=C::t('#it618_brand#it618_brand_wapstyle')->count_by_isok_search();
	$it618_brand_wapstyle=C::t('#it618_brand#it618_brand_wapstyle')->fetch_by_isok_search();
	$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$ShopId);
	include template('it618_brand:livewap');
}else{
	include template('it618_brand:live');
}
//From: Dism��taobao��com
?>