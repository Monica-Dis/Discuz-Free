<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

$sql='&key='.$_GET['key'];

if(submitcheck('it618submit')){
	$del=0;
	$ok=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_brand#it618_brand_onepage')->delete_by_id($delid);
		C::t('#it618_brand#it618_brand_show')->delete_by_showid_showtype($delid,'onepage');
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_brand#it618_brand_onepage')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_waphome' => dhtmlspecialchars($_GET['it618_waphome'][$id]),
				'it618_order' => dhtmlspecialchars($_GET['it618_order'][$id])
			));
			
			C::t('#it618_brand#it618_brand_show')->update_it618_name_by_showid_showtype($id,'onepage',$_GET['it618_name'][$id]);
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_brand_getlang('s5').$ok.' '.it618_brand_getlang('s7').$del, "plugin.php?id=it618_brand:sc_onepage$adminsid&page=$page".$sql, 'succeed');
}

it618_showformheader("plugin.php?id=it618_brand:sc_onepage$adminsid");
showtableheaders(it618_brand_getlang('s218'),'it618_brand_onepage');

	echo '<tr><td colspan=14>'.it618_brand_getlang('s219').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_brand_getlang('s34').'" /></td></tr>';
	
	$count = C::t('#it618_brand#it618_brand_onepage')->count_by_shopid($ShopId,$_GET['key']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_brand:sc_onepage$adminsid".$sql);
	
	echo '<tr><td colspan=8>'.it618_brand_getlang('s220').$count.'</td></tr>';
	showsubtitle(array('',it618_brand_getlang('s221'),it618_brand_getlang('s108'),it618_brand_getlang('s707')));

	$n=1;
	foreach(C::t('#it618_brand#it618_brand_onepage')->fetch_all_by_shopid(
		$ShopId,$_GET['key'],$startlimit,$ppp
	) as $it618_brand_onepage) {
		if($it618_brand_onepage['it618_waphome']==1)$it618_waphome_checked='checked="checked"';else $it618_waphome_checked="";
		
		$tmpurl=it618_brand_getrewrite('shop_page',$ShopId.'@'.$it618_brand_onepage['id'],'plugin.php?id=it618_brand:onepage&sid='.$ShopId.'&oid='.$it618_brand_onepage['id']);
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_brand_onepage['id'].'"><label for="chk_del'.$n.'">'.$it618_brand_onepage['id'].'</label>',
			'<input type="text" class="txt" style="width:400px" name="it618_name['.$it618_brand_onepage['id'].']" value="'.$it618_brand_onepage['it618_name'].'"><a href="plugin.php?id=it618_brand:sc_onepage_edit'.$adminsid.'&oid='.$it618_brand_onepage['id'].'">'.it618_brand_getlang('s109').'</a> <a href="'.$tmpurl.'" target="_blank">'.$it618_brand_lang['s408'].'</a>',
			$it618_brand_onepage['it618_views'],
			'<input type="text" class="txt" style="width:50px" name="it618_order['.$it618_brand_onepage['id'].']" value="'.$it618_brand_onepage['it618_order'].'">'
		));
		$n=$n+1;
	}
	
	showsubmit('it618submit', 'submit', 'del', '<input type=hidden value='.$page.' name=page />', $multipage);
showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>