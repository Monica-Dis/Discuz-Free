<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_brand = $_G['cache']['plugin']['it618_brand'];
$metakeywords = $it618_brand['seokeywords'];
$metadescription = $it618_brand['seodescription'];
$creditname=$_G['setting']['extcredits'][$it618_brand['brand_credit']]['title'];
$sitetitle=$it618_brand['brand_name'];

$brand_fwpower=(array)unserialize($it618_brand['brand_fwpower']);
if(!in_array("", $brand_fwpower)&&!in_array($_G['groupid'], $brand_fwpower)){
	echo $it618_brand_lang['s1486'].'<a href="'.$_G['siteurl'].'">'.$it618_brand_lang['s1487'].'</a>';
	exit;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if(!brand_is_mobile()){
	$ispc=1;
}

$waphome=it618_brand_getrewrite('brand_wap','','plugin.php?id=it618_brand:wap');
$wapu=it618_brand_getrewrite('brand_wap','u@0','plugin.php?id=it618_brand:wap&pagetype=u');
$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_brand#it618_brand_wapstyle')->count_by_isok_search();
$it618_brand_wapstyle=C::t('#it618_brand#it618_brand_wapstyle')->fetch_by_isok_search();

if(isset($_GET['pagetype'])){
	$pagetypearray = array('brand', 'shop', 'product', 'product_list', 'onepage', 'article', 'article_list', 'image', 'image_list', 'sc', 'sc_tx', 'sc_bank', 'sc_product', 'sc_product_class', 'sc_product_add', 'sc_product_edit', 'sc_product_km', 'sc_product_content', 'sc_product_type_km', 'sc_product_type', 'sc_card', 'uc', 'card', 'collect', 'search', 'salenav', 'salexs', 'salexx', 'gwcsale', 'pin', 'u');
	$pagetype = !in_array($_GET['pagetype'], $pagetypearray) ? 'brand' : $_GET['pagetype'];
}else{
	$pagetype='brand';
	$wapnavtitle=$sitetitle;
}

if($it618_brand['brand_mode']>2){
	$brandmode=getcookie('brandmode');
	if($brandmode==''){
		if($it618_brand['brand_mode']==3)$brandmode='it618brand';else $brandmode='it618goods';
	}
	
	if($brandmode=='it618brand'){
		$brandmodestrtmp='<b>'.$it618_brand_lang['s639'].'</b>/'.$it618_brand_lang['s853'];
	}else{
		$brandmodestrtmp=$it618_brand_lang['s639'].'/<b>'.$it618_brand_lang['s853'].'</b>';
	}
	
	if($pagetype=='brand'){
		$brandmodestr='<li><a href="javascript:" class="react" onclick="brandmode()"><img src="source/plugin/it618_brand/images/mode.png" height="15px" style="margin-top:-4px;margin-right:2px"/>'.$brandmodestrtmp.'</a></li>';
		$brandmodestr1='<li><a href="javascript:" class="react" onclick="brandmode()"><img src="source/plugin/it618_brand/images/mode1.png" height="15px" style="margin-top:-4px;margin-right:2px"/>'.$brandmodestrtmp.'</a></li>';
	}
}else{
	if($it618_brand['brand_mode']==1)$brandmode='it618brand';else $brandmode='it618goods';
}

if($it618_brand['brand_style']>2){
	$brandstyle=getcookie('brandstyle');
	if($brandstyle==''){
		if($it618_brand['brand_style']==3)$brandstyle='1';else $brandstyle='2';
	}

	if($pagetype=='brand'||$pagetype=='search'||$pagetype=='shop'||$pagetype=='product_list'||$pagetype=='collect'){
		if($brandstyle=='1')$brandstyle1='2';else $brandstyle1='1';
		$brandstylestrtmp='<div class="style-btn" onClick="brandstyle()"><i class="icon-style'.$brandstyle1.'"></i></div>';
	}
}else{
	if($it618_brand['brand_style']==1)$brandstyle='1';else $brandstyle='2';
}

if($brandmode=='it618brand'){
	$wapsearch=it618_brand_getrewrite('brand_wap','search@99','plugin.php?id=it618_brand:wap&pagetype=search&sid=99');
}else{
	$wapsearch=it618_brand_getrewrite('brand_wap','search@0','plugin.php?id=it618_brand:wap&pagetype=search&sid=0');
}

$sid=intval($_GET['sid']);

$gwcpcount=0;
$gwcurl=it618_brand_getrewrite('brand_wap','gwcsale@0','plugin.php?id=it618_brand:wap&pagetype=gwcsale');
if($_G['uid']>0){
	$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$_G['uid']);
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_brand_getlang('s704').'</a></li>';
	$strusr='<a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="btn btn-weak">'.it618_brand_getlang('s704').'</a> <a href="'.it618_brand_rewriteurl($_G['uid']).'" target="_blank">'.it618_brand_getusername($_G['uid']).'</a> '.it618_brand_getlang('s705').$creditname.':<font color=red>'.$creditnum.'</font>';
	
	$gwcpcount=C::t('#it618_brand#it618_brand_gwc')->count_by_uid($_G['uid']);
}

$isgoodmenu=1;
$tmparray = array('shop', 'product', 'product_list', 'onepage', 'article', 'article_list', 'image', 'image_list');
if(in_array($pagetype, $tmparray)){
	$brandtmp=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($sid);
	$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($brandtmp['it618_power']);
	
	$Shop_isgoods=$it618_brand_brandgroup['it618_isgoods'];
	$Shop_isouturl=$it618_brand_brandgroup['it618_isouturl'];

	if($Shop_isouturl!=1){
		$waphome=it618_brand_getrewrite('brand_wap','shop@'.$sid,'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$sid);
		$wapsearch=it618_brand_getrewrite('brand_wap','product_list@'.$sid,'plugin.php?id=it618_brand:wap&pagetype=product_list&sid='.$sid);

		if($Shop_isgoods!=1)$isgoodmenu=0;
	}else{
		if($pagetype=='product'){
			$homestr='<li><a class="react" href="'.$waphome.'">'.it618_brand_getlang('s606').'</a></li>';
		}
	}
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_brand_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_brand_bottomnav = DB::fetch($query)) {
	$it618_url=$it618_brand_bottomnav['it618_url'];
	$iscur=0;
	
	if($isgoodmenu==0&&$it618_url=='{wapsearch}')continue;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$it618_url=str_replace("{waphome}",$waphome,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='index'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapsearch}",$it618_url);
	$it618_url=str_replace("{wapsearch}",$wapsearch,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='search'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapgwc}",$it618_url);
	$tmpurl=it618_brand_getrewrite('brand_wap','gwcsale@0','plugin.php?id=it618_brand:wap&pagetype=gwcsale');
	$it618_url=str_replace("{wapgwc}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='gwcsale'){
			$iscur=1;
		}
	}
	
	if($it618_brand_bottomnav['id']==5)$it618_url=it618_brand_getrewrite('brand_wap','u@0','plugin.php?id=it618_brand:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_brand_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_brand_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_brand_bottomnav['it618_color'].'">'.$it618_brand_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_brand_bottomnav['it618_img'];
		$it618_title=$it618_brand_bottomnav['it618_title'];
	}
	
	if($it618_brand_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_brand_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$wap=1;

$getshare="getshare('brand',1)";

$sc_product=explode("sc_product",$pagetype);
if(count($sc_product)>1)$sc_product=1;

$wapfooter=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('wapfooter');

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_brand['brand_appid']);
	$wx_secret=trim($it618_brand['brand_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){

	if($pagetype=='product'){
		$pid=intval($_GET['cid']);
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);
		$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
		$wxshare_title=$it618_brand_goods['it618_name'].' '.$it618_brand_brand['it618_name'].' '.$it618_brand['brand_name'];
		$wxshare_imgUrl=it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_brand_goods['it618_seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
	}else{
		if($sid>0){
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($sid);
			$wxshare_title=$it618_brand['brand_name'].' - '.$it618_brand_brand['it618_name'];
			$wxshare_imgUrl=$it618_brand_brand['it618_logo'];
			$tmparr=explode('://',$wxshare_imgUrl);
			if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
			$wxshare_desc=$it618_brand_brand['it618_addr'].' '.$it618_brand_brand['it618_dianhua'].' '.$it618_brand_brand['it618_shouji'].' '.$it618_brand_brand['it618_about'];
		}else{
			$wxshare_title=$it618_brand['brand_name'];
			if($it618_brand['brand_wxlogo']!=''){
				$wxshare_imgUrl=$it618_brand['brand_wxlogo'];
			}else{
				$wxshare_imgUrl=$it618_brand['brand_brandlogo'];
				$tmparr=explode('src="',$wxshare_imgUrl);
				$tmparr1=explode('"',$tmparr[1]);
				$wxshare_imgUrl=$tmparr1[0];
			}
			$tmparr=explode('://',$wxshare_imgUrl);
			if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
			$wxshare_desc=$it618_brand['seodescription'];
			$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		
		}
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
		
		$wxshare_link=$signPackage["url"];
	}
}

$isappbottom=0;
if($it618_brand['brand_isappbottom']==1&&$it618_brand['brand_appkeys']!=''){
	$tmparr=explode(",",$it618_brand['brand_appkeys']);
	for($i=0;$i<count($tmparr);$i++){
		if(strpos($_SERVER['HTTP_USER_AGENT'],$tmparr[$i])!==false){
			$isappbottom=1;
			break;
		}
	}
}

global $oss;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/php/aliyunossconfig.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/php/aliyunossconfig.php';
	if($it618_isok==1){
		$oss='&oss';
	}
}

$wapbottomsubnav=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('wapbottomsubnavdefault');

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
	if($appurl=it618_members_apploginok($_GET['token'])){
		dheader("location:$appurl");
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php';
}

if($mapapi_lbsmaptype!=''){
	$it618_brand_getmapapi=getcookie('it618_brand_getmapapi');
	$ismaplbs=1;
	
	if($mapapi_lbsmaptype=='gdmap'){
		if(strpos($_SERVER['HTTP_USER_AGENT'],'MQQBrowser')==true)$ismaplbs=0;
	}
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_wapad=it618_group_getad($_GET['id'],1);
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/'.$pagetype.'.inc.php';
?>