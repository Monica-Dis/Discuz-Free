<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

$sql='&key='.$_GET['key'].'&it618_class_id='.$_GET['it618_class_id'];

if(submitcheck('it618submit')){
	$del=0;
	$ok=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_brand#it618_brand_article')->delete_by_id($delid);
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_brand#it618_brand_article')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_color' => dhtmlspecialchars($_GET['it618_color'][$id]),
				'it618_order' => intval($_GET['it618_order'][$id]),
			));
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_brand_getlang('s5').$ok.' '.it618_brand_getlang('s7').$del, "plugin.php?id=it618_brand:sc_article$adminsid&page=$page".$sql, 'succeed');
}

foreach(C::t('#it618_brand#it618_brand_article_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class_id'].'>','<option value='.$_GET['it618_class_id'].' selected="selected">',$tmp);

it618_showformheader("plugin.php?id=it618_brand:sc_article$adminsid");
showtableheaders(it618_brand_getlang('s101'),'it618_brand_article');

	echo '<tr><td colspan=14>'.it618_brand_getlang('s102').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_brand_getlang('s103').' <select name="it618_class_id"><option value="0">'.it618_brand_getlang('s104').'</option>'.$tmp1.'</select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_brand_getlang('s34').'" /></td></tr>';
	
	$count = C::t('#it618_brand#it618_brand_article')->count_by_shopid($ShopId,$_GET['key'],$_GET['it618_class_id']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_brand:sc_article$adminsid".$sql);
	
	echo '<tr><td colspan=5>'.it618_brand_getlang('s105').$count.'</td></tr>';
	showsubtitle(array('',it618_brand_getlang('s103'),it618_brand_getlang('s106'),it618_brand_getlang('s107'),it618_brand_getlang('s196'),it618_brand_getlang('s108')));
	
	$n=1;
	foreach(C::t('#it618_brand#it618_brand_article')->fetch_all_by_shopid(
		$ShopId,$_GET['key'],$_GET['it618_class_id'],$startlimit,$ppp
	) as $it618_brand_article) {
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_brand_article[id].'"><label for="chk_del'.$n.'">'.$it618_brand_article['id'].'</label>',
			it618_brand_classname($it618_brand_article[it618_class_id]),
			'<input type="text" class="txt" style="width:400px" name="it618_name['.$it618_brand_article[id].']" value="'.$it618_brand_article[it618_name].'"><a href="plugin.php?id=it618_brand:sc_article_edit'.$adminsid.'&aid='.$it618_brand_article[id].'">'.it618_brand_getlang('s109').'</a>',
			"<input id=\"c".$it618_brand_article['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_brand_article[id]]\" value=\"$it618_brand_article[it618_color]\" onchange=\"updatecolorpreview('c".$it618_brand_article['id']."')\"><input id=\"c".$it618_brand_article['id']."\" onclick=\"c".$it618_brand_article['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_brand_article['id']."|c".$it618_brand_article['id']."_v';showMenu({'ctrlid':'c".$it618_brand_article['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_brand_article['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_brand_article['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			'<input type="text" class="txt" style="width:50px" name="it618_order['.$it618_brand_article[id].']" value="'.$it618_brand_article[it618_order].'">',
			$it618_brand_article[it618_views]
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_brand_article['id']."');";
		$n=$n+1;
	}
	
	function it618_brand_classname($aid){
		return C::t('#it618_brand#it618_brand_article_class')->fetch_it618_classname_by_id($aid);
	}
	
	showsubmit('it618submit', 'submit', 'del', '<script>'.$tmpcolorjs.'</script><input type=hidden value=$page name=page />', $multipage);
showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>