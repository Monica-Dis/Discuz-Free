<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsUnion,$IsCredits,$IsChat,$it618_brand,$it618_hongbao_lang;
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/brand_function.func.php';

if(brand_is_mobile())$wap=1;

if($IsUnion==1&&$pagetype=='shop'){
	$sql='it618_ison=1';
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('brand',$ShopId,$sql);
	
	$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('brand',$ShopId,$sql);
}

if($IsUnion==1&&$pagetype=='product'){
	$sql='it618_ison=1 and (it618_pids=\'\' or CONCAT(\',\',it618_pids,\',\') like \'%,'.$pid.',%\')';
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('brand',$ShopId,$sql);
	
	if($quancount>0){
		$shopquanurl=it618_brand_getrewrite('brand_wap','onepage@'.$ShopId.'@0@0@0','plugin.php?id=it618_brand:wap&pagetype=onepage&sid='.$ShopId.'&oid=0');
		
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_money_by_shoptype_shopid('brand',$ShopId,$sql,'it618_money desc');
		if($union_quanmoney>0){
			$union_quan=$it618_union_lang['s1584'].$union_quanmoney.$it618_union_lang['s1585'];
		}
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_mjmoney_by_shoptype_shopid('brand',$ShopId,$sql,'it618_mjmoney2 desc');
		if($union_quanmoney['it618_mjmoney2']>0){
			$union_quan.=' '.$it618_union_lang['s1582'].$union_quanmoney['it618_mjmoney1'].$it618_union_lang['s1585'].$it618_union_lang['s1583'].$union_quanmoney['it618_mjmoney2'].$it618_union_lang['s1585'];
		}
	}
	
	$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('brand',$ShopId,$sql);
	if($tuicount>0){
		$union_tuitcbl=C::t('#it618_union#it618_union_tui')->fetch_tc_by_shoptype_shopid('brand',$ShopId,$sql,'it618_tcbl desc');
		$union_tuitc=$it618_union_lang['s1580'].str_replace(".00","",$union_tuitcbl).'%'.$it618_union_lang['s1581'];
	}
}

if($IsUnion==1){
	$tuipower=1;
	$tuiuid=intval($_GET['tuiuid']);
	if($tuiuid>0){
		$usercount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$tuiuid);
		if($usercount>0){
			$groupid=DB::result_first("select groupid from ".DB::table('common_member')." where uid=".$tuiuid);
			$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
			if(!in_array($groupid, $union_tuigroup)&&$union_tuigroup[0]!=''){
				$tuipower=0;
			}
		}
	}
	
	if($tuipower==1){
		if($it618_union['union_cookietime']==0)$union_cookietime=3600;else $union_cookietime=$it618_union['union_cookietime']*3600;
		dsetcookie('it618_union_tuiuid',$tuiuid,$union_cookietime);
	}
}

if($IsPinEdu==1&&$pagetype=='product'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
	$shoptype='brand';
	$pingoods=it618_pinedu_getpingoods($shoptype,$it618_brand_goods['id'],$wap);
	if($pingoods['pinstr']!=''){
		$ispinok=1;
		$jqueryname='IT618_BRAND';
		if($wap==1){
			if($_GET['e']!=''){
				$pinurl=$_G['siteurl'].it618_brand_getrewrite('brand_wap','pin@'.$it618_brand_goods['it618_shopid'].'@tmptypeid@tmpspid@0','plugin.php?id=it618_brand:wap&pagetype=pin&sid='.$it618_brand_goods['it618_shopid'].'&oid=tmptypeid&cid=tmpspid'.'&e='.$_GET['e'],'?e='.$_GET['e']);
			}else{
				$pinurl=$_G['siteurl'].it618_brand_getrewrite('brand_wap','pin@'.$it618_brand_goods['it618_shopid'].'@tmptypeid@tmpspid@0','plugin.php?id=it618_brand:wap&pagetype=pin&sid='.$it618_brand_goods['it618_shopid'].'&oid=tmptypeid&cid=tmpspid');
			}
			
			$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
			$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
			include template('it618_pinedu:pinsale');
			$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
		}else{
			include template('it618_pinedu:pinsale');
		}
	}
}

if($IsCredits==1){
	$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
	
	if(in_array(5,(array)unserialize($it618_hongbao['hongbao_power']))){
		$ishongbao=0;
		if($wap==1){
			if($pagetype=='brand'||$pagetype=='search')$ishongbao=1;
		}else{
			if($pagetype=='index'||$pagetype=='list'||$pagetype=='search'||$pagetype=='shops'||$pagetype=='products')$ishongbao=1;
		}
		
		if($ishongbao==1){
			$it618_hbtype='it618_brand_admin';
			$tid=0;
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$it618_brand = $_G['cache']['plugin']['it618_brand'];
				$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
				if(in_array($_G['uid'],$shopadmin)){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
			include template('it618_hongbao:hongbao');
		}
	}
	
	if(in_array(6,(array)unserialize($it618_hongbao['hongbao_power']))){
		$ishongbao=0;
		if($wap==1){
			if($pagetype=='shop'||$pagetype=='product_list'||$pagetype=='onepage'||$pagetype=='article'||$pagetype=='article_list'||$pagetype=='image'||$pagetype=='image_list'){
				$ishongbao=1;
				$tid=$_GET['sid'];
			}
		}else{
			if($ShopId>0){
				$ishongbao=1;
				$tid=$ShopId;
			}
		}
		
		if($ishongbao==1){
			$it618_hbtype='it618_brand_shop';
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$shoptmp=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($tid);
				if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
			include template('it618_hongbao:hongbao');
		}
	}
}

if($pagetype=='shop'){
	if($it618_brand_live=C::t('#it618_brand#it618_brand_live')->fetch_by_shopid($ShopId)){
		$videotype=$it618_brand_live['it618_type'];
		if($it618_brand_live['it618_name']=='')$videoname=$it618_brand_lang['s1153'];else $videoname=$it618_brand_live['it618_name'];
	}
}
if($pagetype=='product'){
	if($it618_brand_live=C::t('#it618_brand#it618_brand_live')->fetch_by_shopid($it618_brand_goods['it618_shopid'])){
		$ShopId=$it618_brand_goods['it618_shopid'];
		$videotype=$it618_brand_live['it618_type'];
		if($it618_brand_live['it618_name']=='')$videoname=$it618_brand_lang['s1153'];else $videoname=$it618_brand_live['it618_name'];
	}
}

if($IsChat==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/function.func.php';
	
	$chatplugin='it618_brand';
	if($ShopId>0){
		$chatsid=$ShopId;
	}else{
		$chatsid=0;
	}
	
	$it618_chat_kefu = it618_chat_getkefu($chatplugin,$chatsid,$wap);
}

if($ShopId>0&&$it618_chat_kefu==''){
	$brand_kefu = $it618_brand['brand_kefu'];
	$brand_kefu=explode(",",$brand_kefu);

	if($Shop_kefuqq!=''||$Shop_kefuwx!=''||$Shop_kefuqqname!=''){
		$qqarr=explode(",",$Shop_kefuqq);
		$wxarr=explode(",",$Shop_kefuwx);
		$qqnamearr=explode(",",$Shop_kefuqqname);
		for($i=0;$i<count($qqarr);$i++)
		{
			$qqstr='';$wxstr='';
			if($qqnamearr[$i]!=''){
				if($qqarr[$i]!='')$qqstr='<font color=#999>QQ:</font><a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="source/plugin/it618_brand/images/qqbtn.gif" alt="'.it618_brand_getlang('s422').'" align="absmiddle" title="'.it618_brand_getlang('s422').'"/></a>'.$qqarr[$i].' ';
				if($wxarr[$i]!='')$wxstr='<font color=#999>'.$it618_brand_lang['s1808'].':</font>'.$wxarr[$i].'<br>';
				
				$shopstr.=$qqnamearr[$i].$it618_brand_lang['s53'].$qqstr.$wxstr;
							
				$shoprightqq.='<h3>'.$qqnamearr[$i].'</h3>
							  <ul>
								  <li>'.$qqstr.'<br>'.$wxstr.'</li>
							  </ul>';
			}
		}
		
	}
}
//From: Dism��taobao��com
?>