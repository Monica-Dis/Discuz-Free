<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_brand_kdarea', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_brand#it618_brand_kdarea')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_order' => dhtmlspecialchars($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
	
		if($newit618_name_array[$key] != '') {
			
			C::t('#it618_brand#it618_brand_kdarea')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_name' => dhtmlspecialchars($newit618_name_array[$key]),
				'it618_order' => dhtmlspecialchars($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
		}
	}

	it618_cpmsg(it618_brand_getlang('s5').$ok1.' '.it618_brand_getlang('s6').$ok2.' '.it618_brand_getlang('s7').$del, "plugin.php?id=it618_brand:sc_kdarea$adminsid", 'succeed');
}

if(submitcheck('it618submit_dao')){
	if($it618_brand['brand_kddatasid']>0){
		$ok=0;
		foreach(C::t('#it618_brand#it618_brand_kdarea')->fetch_all_by_shopid($it618_brand['brand_kddatasid']) as $it618_brand_kdarea) {
			
			$count = C::t('#it618_brand#it618_brand_kdarea')->count_by_shopid_name($ShopId,$it618_brand_kdarea['it618_name']);
			
			if($count==0){
				C::t('#it618_brand#it618_brand_kdarea')->insert(array(
					'it618_shopid' => $ShopId,
					'it618_name' => $it618_brand_kdarea['it618_name'],
					'it618_order' => $it618_brand_kdarea['it618_order'],
				), true);
				$ok=$ok+1;
			}
		}
		
		it618_cpmsg($it618_brand_lang['s1898'].$ok, "plugin.php?id=it618_brand:sc_kdarea$adminsid", 'succeed');
	}
}

it618_showformheader("plugin.php?id=it618_brand:sc_kdarea$adminsid");
showtableheaders(it618_brand_getlang('s1011'),'it618_brand_kdarea');
	$count = C::t('#it618_brand#it618_brand_kdarea')->count_by_shopid($ShopId);

	echo '<tr><td colspan=4>'.it618_brand_getlang('s1012').$count.'</td></tr>';
	showsubtitle(array('', it618_brand_getlang('s1013'),it618_brand_getlang('s748'),it618_brand_getlang('s1929')));
	
	foreach(C::t('#it618_brand#it618_brand_kdarea')->fetch_all_by_shopid($ShopId) as $it618_brand_kdarea) {
		$yunfeicount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_kdyunfei')." WHERE it618_kdareaid=".$it618_brand_kdarea['id']);
		$disabled="";
		if($yunfeicount>0)$disabled="disabled=\"disabled\"";
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_brand_kdarea[id]\" $disabled>",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_brand_kdarea[id]]\" value=\"$it618_brand_kdarea[it618_name]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:50px\" name=\"it618_order[$it618_brand_kdarea[id]]\" value=\"$it618_brand_kdarea[it618_order]\">",
			$yunfeicount
		));
	}
	
	if($it618_brand['brand_kddatasid']>0){
		$strdaobtn='<input type="submit" class="btn" name="it618submit_dao" value="'.it618_brand_getlang('s1896').'" style="float:right" onclick="return confirm(\''.it618_brand_getlang('s1897').'\')"/>';
	}

	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		return [
		[[1,''], [1,'<input type="text" class="txt" style="width:200px" name="newit618_name[]">'], [1, ' <input class="txt" style="width:50px" type="text" name="newit618_order[]">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="4"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.it618_brand_getlang('s128').'</a></div></td></tr>';
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_brand_getlang('s129').'</label></td><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_brand_getlang('s120').'" /> '.$strdaobtn.'</div></td></tr>';
showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>