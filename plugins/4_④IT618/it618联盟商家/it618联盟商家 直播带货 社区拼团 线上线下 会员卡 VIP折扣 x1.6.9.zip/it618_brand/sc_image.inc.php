<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

$sql='&key='.$_GET['key'].'&it618_class_id='.$_GET['it618_class_id'];

if(submitcheck('it618submit')){
	$del=0;
	$ok=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_brand_image=C::t('#it618_brand#it618_brand_image')->fetch_by_id($delid);

		$tmparr=explode("source",$it618_brand_image['it618_url']);
		$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
		if(file_exists($it618_url)){
			$result=unlink($it618_url);
		}
		
		$tmparr=explode("source",$it618_brand_image['it618_smallurl']);
		$it618_smallurl=DISCUZ_ROOT.'./source'.$tmparr[1];
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}

		C::t('#it618_brand#it618_brand_image')->delete_by_id($delid);
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			$it618_brand_image=C::t('#it618_brand#it618_brand_image')->fetch_by_id($id);
			if($_GET['it618_url'][$id]!=$it618_brand_image['it618_url']){
				$tmparr=explode("source",$it618_brand_image['it618_url']);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
				if(file_exists($it618_url)){
					$result=unlink($it618_url);
				}
				
				$imgsrc=str_replace('php/../','',$_GET['it618_url'][$id]);
				$file_ext=strtolower(substr($imgsrc,strrpos($imgsrc, '.')+1)); 
				
				$tmparr1=explode("://",$imgsrc);
				if(count($tmparr1)>1){
					$it618_url=$imgsrc;
				}else{
					$tmparr=explode("source",$imgsrc);
					$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
				}
				
				$file_size=filesize($it618_url);
				
				$tmparr=explode("/plugin/it618_brand/kindeditor/data/",$imgsrc);
				$smallimgsrc='source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/img'.$id.'.'.$file_ext;
				
				$tmparr=explode("source",$smallimgsrc);
				$it618_smallurl=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				it618_brand_imagetosmall($it618_url,$it618_smallurl,$file_ext,190);
				
				$smallimgsrc.='?'.substr(md5($imgsrc),0,6);
				C::t('#it618_brand#it618_brand_image')->update($id,array(
					'it618_url' => $imgsrc,
					'it618_smallurl' => $smallimgsrc,
					'it618_fileext' => $file_ext,
					'it618_filesize' => ($file_size / 1024),
					'it618_time' => $_G['timestamp']
				));
			}
			
			C::t('#it618_brand#it618_brand_image')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_class_id' => $_GET['class_id'][$id],
				'it618_order' => dhtmlspecialchars($_GET['it618_order'][$id]),
			));
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_brand_getlang('s5').$ok.' '.it618_brand_getlang('s7').$del, "plugin.php?id=it618_brand:sc_image$adminsid&page=$page".$sql, 'succeed');
}

foreach(C::t('#it618_brand#it618_brand_image_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class_id'].'>','<option value='.$_GET['it618_class_id'].' selected="selected">',$tmp);

it618_showformheader("plugin.php?id=it618_brand:sc_image$adminsid");
showtableheaders(it618_brand_getlang('s186'),'it618_brand_image');

	echo '<tr><td colspan=14>'.it618_brand_getlang('s187').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_brand_getlang('s188').' <select name="it618_class_id" id="it618_class_id"><option value="0">'.it618_brand_getlang('s189').'</option>'.$tmp1.'</select> &nbsp;<input type="submit" class="btn" id="it618sercsubmit" name="it618sercsubmit" value="'.it618_brand_getlang('s34').'" /> &nbsp;<a href="javascript:" id="J_selectImage"><strong>'.it618_brand_getlang('s190').'</strong></a> '.it618_brand_getlang('s1382').'</td></tr>';
	
	$count = C::t('#it618_brand#it618_brand_image')->count_by_shopid($ShopId,$_GET['key'],$_GET['it618_class_id']);
	$filesizesum = C::t('#it618_brand#it618_brand_image')->sum_by_shopid($ShopId,$_GET['key'],$_GET['it618_class_id']);
	$filesizesum=round($filesizesum/1024,2);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_brand:sc_image$adminsid".$sql);
	
	echo '<tr><td colspan=5>'.it618_brand_getlang('s191').$count.'</td></tr>';
	showsubtitle(array('',it618_brand_getlang('s180'),it618_brand_getlang('s188'),it618_brand_getlang('s192'),it618_brand_getlang('s196'),it618_brand_getlang('s108'),it618_brand_getlang('s197')));
	
	$n=1;
	foreach(C::t('#it618_brand#it618_brand_image')->fetch_all_by_shopid(
		$ShopId,$_GET['key'],$_GET['it618_class_id'],$startlimit,$ppp
	) as $it618_brand_image) {
		
		if($it618_brand_image['it618_ishomemove']==1)$it618_ishomemove_checked='checked="checked"';else $it618_ishomemove_checked="";
		$tmp1=str_replace('<option value='.$it618_brand_image['it618_class_id'].'>','<option value='.$it618_brand_image['it618_class_id'].' selected="selected">',$tmp);
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_brand_image[id].'"><label for="chk_del'.$n.'">'.$it618_brand_image['id'].'</label>',
			'<a href="'.$it618_brand_image[it618_url].'" target="_blank"><img src="'.$it618_brand_image['it618_smallurl'].'" id="img'.$it618_brand_image['id'].'" width="50" height="50" align="absmiddle" style="margin-right:3px"/></a><input class="txt" type="text" id="url'.$it618_brand_image['id'].'" name="it618_url['.$it618_brand_image['id'].']" readonly="readonly" value="'.$it618_brand_image['it618_url'].'" /> <input type="button" id="image'.$it618_brand_image['id'].'" value="'.it618_brand_getlang('s183').'" />',
			'<select name="class_id['.$it618_brand_image[id].']">'.$tmp1.'</select>',
			'<input type="text" class="txt" style="width:200px" name="it618_name['.$it618_brand_image[id].']" value="'.$it618_brand_image[it618_name].'">',
			'<input type="text" class="txt" style="width:50px" name="it618_order['.$it618_brand_image[id].']" value="'.$it618_brand_image[it618_order].'">',
			$it618_brand_image[it618_views],
			date('Y-m-d H:i:s', $it618_brand_image['it618_time'])
		));
		$n=$n+1;
		
		$editorjs.='K(\'#image'.$it618_brand_image['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K(\'#url'.$it618_brand_image['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_brand_image['id'].'\').val(url);
								K(\'#img'.$it618_brand_image['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/js/jquery.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=930'.$oss.'\',
					fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';

echo '<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=930'.$oss.'\',
					fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
					allowFileManager : true
				});
				K(\'#J_selectImage\').click(function() {
					if(document.getElementById("it618_class_id").value==0){
						alert("'.it618_brand_getlang('s1383').'");	
						return;
					}
					var imgsrcs="";
					editor.loadPlugin(\'multiimage\', function() {
						editor.plugin.multiImageDialog({
							clickFn : function(urlList) {
								var div = K(\'#J_imageView\');
								div.html(\'\');
								K.each(urlList, function(i, data) {
									//div.append(\'<img src="\' + data.url + \'">\');
									imgsrcs=imgsrcs+"@@@"+data.url;
								});
								if(imgsrcs==""){
									alert("'.it618_brand_getlang('s1384').'");	
									return;
								}
								IT618_BRAND.post("'.$_G['siteurl'].'plugin.php?id=it618_brand:ajax&ac=image_add'.$adminsid.'&sid='.$ShopId.'&classid="+document.getElementById("it618_class_id").value+"&formhash='.FORMHASH.'","imgsrcs="+imgsrcs,function (data, textStatus){
								var tmparr=data.split("it618_split");
								if(tmparr[0]=="ok"){
									alert(tmparr[1]);
									document.getElementById("cpform").submit();
								}else{
									alert(tmparr[1]);
								}
								}, "html");
								
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>';
	
	function it618_brand_classname($aid){
		return C::t('#it618_brand#it618_brand_image_class')->fetch_it618_classname_by_id($aid);
	}
	
	showsubmit('it618submit', 'submit', 'del', '<input type=hidden value=$page name=page />', $multipage);
showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>