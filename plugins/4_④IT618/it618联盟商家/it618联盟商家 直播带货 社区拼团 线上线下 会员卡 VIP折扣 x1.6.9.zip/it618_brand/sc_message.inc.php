<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if(submitcheck('it618submit')){
	C::t('#it618_brand#it618_brand_brand')->update($ShopId,array(
		'it618_messagetel' => $_GET['it618_messagetel'],
		'it618_messageisok' => $_GET['it618_messageisok']
	));

	it618_cpmsg(it618_brand_getlang('s631'), "plugin.php?id=it618_brand:sc_message$adminsid", 'succeed');
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_brand/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_brand/config/message.php';
}

if($it618_isok==1){
	$tmpstr='<font color="green">'.it618_brand_getlang('s1343').'</font> ';
	if($it618_body_tk_user_isok==1)$tmpstr.='<img src="source/plugin/it618_brand/images/se.gif">';
	
	$tmpstr.='<br><font color="green">'.it618_brand_getlang('s1344').'</font> ';
	if($it618_body_sale_user_isok==1)$tmpstr.='<img src="source/plugin/it618_brand/images/se.gif">';
	
	$tmpstr.='<br><font color="green">'.it618_brand_getlang('s1345').'</font> ';
	if($it618_body_sale2state_user_isok==1)$tmpstr.='<img src="source/plugin/it618_brand/images/se.gif">';
	
	$tmpstr.='<br><br><img src="source/plugin/it618_brand/images/se.gif"> '.it618_brand_getlang('s1346');
	
}else{
	$tmpstr=it618_brand_getlang('s1347');
}

it618_showformheader("plugin.php?id=it618_brand:sc_message$adminsid");
showtableheaders(it618_brand_getlang('s632'),'it618_brand_brand');

$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);
if($it618_brand_brand['it618_messageisok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
echo '
<tr><td width=130>'.it618_brand_getlang('s1348').'</td><td style="line-height:22px">'.$tmpstr.'</td></tr>
<tr><td colspan=2><strong>'.it618_brand_getlang('s660').'</strong></td></tr>
<tr><td width=110>'.it618_brand_getlang('s633').'</td><td><input type="checkbox" id="it618_isok" name="it618_messageisok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.it618_brand_getlang('s634').'</label></td></tr>
<tr><td>'.it618_brand_getlang('s635').'</td><td><input type="text" class="txt" style="width:300px" name="it618_messagetel" value="'.$it618_brand_brand['it618_messagetel'].'" maxlength="11" onkeyup="value=value.replace(/[^\-?\d.]/g,\'\')"> '.it618_brand_getlang('s636').'</td></tr>
<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_brand_getlang('s637').'" /></div></td></tr>
';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>