<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_brand = $_G['cache']['plugin']['it618_brand'];
$creditname=$_G['setting']['extcredits'][$it618_brand['brand_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/lang.func.php';

$uid = $_G['uid'];
if($uid<=0){
	if($_GET['wap']==1){
		echo 'it618_split'.it618_brand_getlang('s1005');return;
	}else{
		echo it618_brand_getlang('s436').'<a href="member.php?mod=logging&action=login">'.it618_brand_getlang('s773').'</a> <a href="member.php?mod='.$RegName.'">'.it618_brand_getlang('s774').'</a>';return;
	}
}else{
	$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($_GET['pid']);
	
	if($it618_brand_cardmoney=C::t('#it618_brand#it618_brand_cardmoney')->fetch_by_shopid_uid($it618_brand_goods['it618_shopid'],$uid)){
		$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
		$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($it618_brand_goods['it618_shopid'],$allmoney);
		$viplevel=$fetch_by_money['it618_level'];
	}
	
	if($viplevel!=''){
		$viplevel='<font color=red>VIP'.$viplevel.'</font>';
		$it618_zk=$fetch_by_money['it618_zk'];
		$zk='<font color=#f60>'.$fetch_by_money['it618_zk'].'%</font><input type="hidden" name="it618_zk" value="'.$it618_zk.'">';
	}
	
	$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
	$username=C::t('#it618_brand#it618_brand_sale')->fetch_username_by_uid($_G['uid']);
	$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$_G['uid']);

	if(count($liil1i)!=11)return;
	
	if($it618_brand_goods['it618_ison']==0){
		echo it618_brand_getlang('s437');return;
	}
	
	if($liil1i[8]!='a')return;

	$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
	$n=1;
	$iscurcount=C::t('#it618_brand#it618_brand_addr')->count_by_it618_uid($uid);
	foreach(C::t('#it618_brand#it618_brand_addr')->fetch_all_by_it618_uid($uid) as $it618_brand_addr) {
		$it618_name=$it618_brand_addr['it618_name'];
		$it618_addr=$it618_brand_addr['it618_addr'];
		$it618_tel=$it618_brand_addr['it618_tel'];
		
		if($it618_brand_addr['it618_iscur']==0){
			$strtmp='';
		}else{
			$strtmp='checked="checked"';
		}
		if($iscurcount==0&&$n==1)$strtmp='checked="checked"';
		if($n%2==0){
			$strcss='<tr>';
		}else{
			$strcss='<tr class="odd">';
		}

		$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
		if($liil1i[3]!='1')return;
		
		if($_GET['wap']==1){
			$addr_get.=$strcss.'
					 <td><input type="radio" '.$strtmp.' name="it618_addr"/></td>
					 <td>'.cutstr($it618_addr, 20, '...').'</td>
					 <td>'.$it618_tel.'<input type="hidden" id="it618_addrid'.($n-1).'" title="'.$it618_tel.'" value="'.$it618_brand_addr['id'].'"/></td>
					 </tr>';
		}else{
			$addr_get.=$strcss.'
					 <td><input type="radio" '.$strtmp.' name="it618_addr"/></td>
					 <td>'.$it618_name.'</td>
					 <td>'.$it618_addr.'</td>
					 <td>'.$it618_tel.'<input type="hidden" id="it618_addrid'.($n-1).'" title="'.$it618_tel.'" value="'.$it618_brand_addr['id'].'"/></td>
					 </tr>';
		}
		$n=$n+1;
	}
	
	if($addr_get==""){
		$isaddr=1;
	}

}

if($_GET['it618_gtypeid']>0){
	$it618_brand_goods_type = C::t('#it618_brand#it618_brand_goods_type')->fetch_by_id($_GET['it618_gtypeid']);
	$it618_uprice=$it618_brand_goods_type['it618_uprice'];
}else{
	$it618_uprice=$it618_brand_goods['it618_uprice'];
}

$goodsmoney=$it618_uprice*$_GET['buycount'];
if($viplevel!=''){
	$yfmoney=round(($goodsmoney*$it618_zk/100),2);
	$zkstr=' * <font color=green>'.$it618_zk.'%</font>';
}else{
	$yfmoney=$goodsmoney;
}

if($_GET['wap']==1){
	$height=$_GET['height']*0.8-46;
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:showorderbuy');
?>