<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($pagetype=='shop')$curclass=' class="cur"';else $curclass='';

if($ShopName_nav!='')$ShopName_nav='-'.$ShopName_nav;

$str_shopnav='<li'.$curclass.'><a href="'.$shop_home.'">'.$Shop_homenavname.'</a></li>';

if($IsUnion==1){
	$sql='it618_ison=1';
	
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('brand',$ShopId,$sql);
	if($quancount>0){
		$tmpurl=it618_brand_getrewrite('shop_page',$ShopId.'@0','plugin.php?id=it618_brand:onepage&sid='.$ShopId.'&oid=0');
		if($pagetype=='onepage' && $idfornav==0){
			$str_shopnav.='<li class="cur"><a href="'.$tmpurl.'">'.$it618_brand_lang['s145'].'</a></li>';
		}else{
			$str_shopnav.='<li><a href="'.$tmpurl.'">'.$it618_brand_lang['s145'].'</a></li>';
		}
	}
	
	$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('brand',$ShopId,$sql);
	if($tuicount>0){
		$tmpurl=it618_brand_getrewrite('shop_page',$ShopId.'@1','plugin.php?id=it618_brand:onepage&sid='.$ShopId.'&oid=1');
		if($pagetype=='onepage' && $idfornav==1){
			$str_shopnav.='<li class="cur"><a href="'.$tmpurl.'">'.$it618_brand_lang['s148'].'</a></li>';
		}else{
			$str_shopnav.='<li><a href="'.$tmpurl.'">'.$it618_brand_lang['s148'].'</a></li>';
		}
	}
}

$str_productclass1='';
foreach(C::t('#it618_brand#it618_brand_show')->fetch_all_by_shopid_isnav($ShopId) as $it618_brand_show_nav) {
	$modeid=$it618_brand_show_nav['it618_showid'];
	$modetype=$it618_brand_show_nav['it618_showtype'];
	$modename=$it618_brand_show_nav['it618_name'];
	
	if($it618_brand_show_nav['it618_isbold']==1)$modename='<b>'.$modename.'</b>';
	
	if($it618_brand_show_nav['it618_color']!='')$modename='<font color="'.$it618_brand_show_nav['it618_color'].'">'.$modename.'</font>';
	
	if($it618_brand_show_nav['it618_isblank']==1)$isblank=' target="_blank"';else $isblank='';
	
	if($modetype=='product_all'){
		if($pagetype=='product_list' || $pagetype=='product')$curclass=' class="cur goodsclassmain"';else $curclass=' class="goodsclassmain"';
		
		if($Shop_isgoodsclass==1&&$str_productclass1==''){
			foreach(C::t('#it618_brand#it618_brand_class')->fetch_all_by_shopid($ShopId) as $it618_brand_class) {
				$tmpurl=it618_brand_getrewrite('shop_productlist',$ShopId.'@'.$it618_brand_class['id'].'@1','plugin.php?id=it618_brand:product_list&sid='.$ShopId.'&cid='.$it618_brand_class['id']);
				$str_productclass1.='<a href="'.$tmpurl.'">'.$it618_brand_class['it618_classname'].'</a>';
			}
			
			$str_productclass1='<div class="goodsclasssub">'.$str_productclass1.'</div>';
		}
		
		$shop_productlist=it618_brand_getrewrite('shop_productlist',$ShopId,'plugin.php?id=it618_brand:product_list&sid='.$ShopId);
		$str_shopnav.='<li'.$curclass.' style="position:relative">'.$str_productclass1.'<a href="'.$shop_productlist.'"'.$isblank.'>'.$modename.'</a></li>';
	}
	
	if($modetype=='article'){
		if(($pagetype=='article_list' || $pagetype=='article') && $modeid==$idfornav)$curclass=' class="cur"';else $curclass='';
		$tmpurl=it618_brand_getrewrite('shop_articlelist',$ShopId.'@'.$modeid.'@1','plugin.php?id=it618_brand:article_list&sid='.$ShopId.'&cid='.$modeid);
		$str_shopnav.='<li'.$curclass.'><a href="'.$tmpurl.'"'.$isblank.'>'.$modename.'</a></li>';
	}
	
	if($modetype=='image'){
		if(($pagetype=='image_list' || $pagetype=='image') && $modeid==$idfornav)$curclass=' class="cur"';else $curclass='';
		$tmpurl=it618_brand_getrewrite('shop_imagelist',$ShopId.'@'.$modeid.'@1','plugin.php?id=it618_brand:image_list&sid='.$ShopId.'&cid='.$modeid);
		$str_shopnav.='<li'.$curclass.'><a href="'.$tmpurl.'"'.$isblank.'>'.$modename.'</a></li>';
	}

	if($modetype=='onepage'){
		if(($pagetype=='onepage') && $modeid==$idfornav)$curclass=' class="cur"';else $curclass='';
		$tmpurl=it618_brand_getrewrite('shop_page',$ShopId.'@'.$modeid,'plugin.php?id=it618_brand:onepage&sid='.$ShopId.'&oid='.$modeid);
		$str_shopnav.='<li'.$curclass.'><a href="'.$tmpurl.'"'.$isblank.'>'.$modename.'</a></li>';
	}
	
	if($modetype=='money'){
		if(($pagetype=='money'))$curclass=' class="cur"';else $curclass='';
		$str_shopnav.='<li'.$curclass.'><a href="'.$shop_money.'"'.$isblank.'>'.$modename.'</a></li>';
	}
	
	if($modetype=='visit'){
		if(($pagetype=='visit'))$curclass=' class="cur"';else $curclass='';
		$str_shopnav.='<li'.$curclass.'><a href="'.$shop_visit.'"'.$isblank.'>'.$modename.'</a></li>';
	}
	
	if($modetype=='diynav'){
		$str_shopnav.='<li><a href="'.$it618_brand_show_nav['it618_url'].'"'.$isblank.'>'.$modename.'</a></li>';
	}

}
//From: Dism��taobao��com
?>