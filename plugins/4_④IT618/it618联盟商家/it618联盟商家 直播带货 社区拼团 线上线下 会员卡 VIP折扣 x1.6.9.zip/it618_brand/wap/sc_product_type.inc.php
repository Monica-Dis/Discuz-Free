<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_default.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if(!brand_is_mobile()){
	$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);
	dheader("location:$shop_home");
}

$spantitle=it618_brand_getlang('s1222');
$wapnavtitle=it618_brand_getlang('s1222').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_brand_getlang('s1005');
}

if($Shop_isgoods==0){
	$error=1;
	$errormsg=it618_brand_getlang('s1640');
}

$pid=intval($_GET['cid']);
$preurl=$_GET['preurl'];
$it618_brand_goods=C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);

if($it618_brand_goods['it618_shopid']!=$ShopId){
	$error=1;
	$errormsg=it618_brand_getlang('s703');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$scacurl=it618_brand_getrewrite('brand_wap','sc_product_type@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=sc_product_type&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);


if($it618_cpmsg!=''||$error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type')." WHERE it618_pid=".$pid);

$sc_product_str.= '<tr><td colspan=2 style="line-height:30px">'.$it618_brand_lang['s1719'].'<input class="txt" type="text" name="it618_ptypename" style="width:100px" value="'.$it618_brand_goods['it618_ptypename'].'"><br>'.$it618_brand_lang['s1724'].'<input class="txt" type="text" name="it618_ptypename1" style="width:100px" value="'.$it618_brand_goods['it618_ptypename1'].'"> '.$it618_brand_lang['s1725'].' </td></tr>';
$sc_product_str.= '<tr><td colspan=2>'.$it618_brand_lang['s1714'].$count.'<span style="float:right;color:red;font-size:11px">'.$it618_brand_lang['s1721'].'</span></td></tr>';

$sc_product_str.= '<tr><td colspan=2><table cellpadding="0" cellspacing="0" width="100%" class="sc_product" style="table-layout:fixed;">';

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods_type')." WHERE it618_pid=".$pid." ORDER BY it618_order,it618_name,it618_order1,it618_name1");
while($it618_brand_goods_type = DB::fetch($query)) {

	$salecount = C::t('#it618_brand#it618_brand_sale')->sumcount_by_it618_gtypeid($it618_brand_goods_type['id']);
	$disabled="";$readonly="";$bgcolor="";
	if($salecount>0){$disabled="disabled=\"disabled\"";$readonly="readonly";$bgcolor=";background-color:#f3f3f3";}
	if($it618_brand_goods_type['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
	
	if($it618_brand_goods['it618_saletype']==3){
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_type_km')." WHERE it618_gtypeid=".$it618_brand_goods_type['id']);
		
		
		$tmpurl=it618_brand_getrewrite('brand_wap','sc_product_type_km@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods_type['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=sc_product_type_km&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods_type['id']);
		
		$saletypestr='<a href="'.$tmpurl.'">'.it618_brand_getlang('s1225').'(<font color=red>'.$kmcount.'</font>)</a>';
	}else{
		$saletypestr="<input type=\"text\" class=\"txt\" style=\"width:50px;line-height:18px\" name=\"it618_count[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_count]\">";
	}
	
	if($Shop_ispaytype2==1){
		$price1=$it618_brand_lang['s1717'].": <input type=\"text\" class=\"txt\" style=\"width:68px;line-height:18px;color:red\" name=\"it618_uprice[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_uprice]\"> ".
		$it618_brand_lang['s1723'].": <input type=\"text\" class=\"txt\" style=\"width:68px;line-height:18px\" name=\"it618_price[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_price]\">";
	}
	
	if($Shop_ispaytype1==1){
		$price2=$it618_brand_lang['s1713'].": <input type=\"text\" class=\"txt\" style=\"width:68px;line-height:18px;color:blue\" name=\"it618_score[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_score]\">";
	}
	
	$sc_product_str.= '<tr><td width=30 style="padding:0;vertical-align:top; padding-top:9px"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_brand_goods_type['id'].'" '.$disabled.'><label for="chk_del'.$it618_brand_goods_type['id'].'">'.$n.'</label></td>
	<td><div style="line-height:30px">'.
		$it618_brand_lang['s1849'].": <input type=\"text\" class=\"txt\" style=\"width:76px;line-height:18px$bgcolor\" name=\"it618_name[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_name]\" $readonly> <input type=\"text\" class=\"txt\" style=\"width:40px\" name=\"it618_order[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_order]\"> ".
		$it618_brand_lang['s1850'].": <input type=\"text\" class=\"txt\" style=\"width:76px;line-height:18px$bgcolor\" name=\"it618_name1[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_name1]\" $readonly> <input type=\"text\" class=\"txt\" style=\"width:40px\" name=\"it618_order1[$it618_brand_goods_type[id]]\" value=\"$it618_brand_goods_type[it618_order1]\">".
		"<br> <span style=\"float:right\">".
		$it618_brand_lang['s1722'].': <input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_brand_goods_type['id'].']" '.$it618_ison_checked.' value="1">'.'</span>'.
		$it618_brand_lang['s1716'].": ".$saletypestr." ".
		$price2."<br>".
		$price1." <span style=\"float:right\">".
		$it618_brand_lang['s1718'].': <font color=red>'.$salecount."</font></span>".
		'</div></td></tr>';
		
		$n=$n+1;
}

$sc_product_str.= '</table></td></tr>';
	
	global $_G;
	
	if($Shop_ispaytype2==1){
		$price1=$it618_brand_lang['s1717'].": <input type=\"text\" class=\"txt\" style=\"width:68px;line-height:18px;color:red\" name=\"newit618_uprice[]\"> ".
		$it618_brand_lang['s1723'].": <input type=\"text\" class=\"txt\" style=\"width:68px;line-height:18px\" name=\"newit618_price[]\">";
	}
	
	if($Shop_ispaytype1==1){
		$price2=$it618_brand_lang['s1713'].": <input type=\"text\" class=\"txt\" style=\"width:68px;line-height:18px;color:blue\" name=\"newit618_score[]\">";
	}
	

	loadcache('plugin');
	$it618_brand = $_G['cache']['plugin']['it618_brand'];
	$sc_product_str.= <<<EOT
	<style>.addtr{ padding-left:17px; line-height:25px; background:url(static/image/admincp/bg_repno.gif) no-repeat 0 1px; *background:url(static/image/admincp/bg_repno.gif) no-repeat 0 0; color:#F60; }</style>
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,'<div style="width:26px"></div>'],[1,'<div style="line-height:30px">$it618_brand_lang[s1849]: <input type="text" class="txt" style="width:76px;line-height:18px" name="newit618_name[]"> <input type="text" class="txt" style="width:40px" name="newit618_order[]"> $it618_brand_lang[s1850]: <input type="text" class="txt" style="width:76px;line-height:18px" name="newit618_name1[]"> <input type="text" class="txt" style="width:40px" name="newit618_order1[]"><br><span style="float:right">$it618_brand_lang[s1722]: <input class="checkbox" type="checkbox" name="newit618_ison[]" value="1"></span> $it618_brand_lang[s1716]: <input type="text" class="txt" style="width:50px" name="newit618_count[]"> $price2<br>$price1</div>']]
		];
	}
	rowtypedata=rundata();
	
	var addrowdirect = 0;
	var addrowkey = 0;
	function addrow(obj, type) {
		var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
		if(!addrowdirect) {
			var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
		} else {
			var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
		}
		var typedata = rowtypedata[type];
		for(var i = 0; i <= typedata.length - 1; i++) {
			var cell = row.insertCell(i);
			cell.colSpan = typedata[i][0];
			var tmp = typedata[i][1];
			if(typedata[i][2]) {
				cell.className = typedata[i][2];
			}
			tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
			tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return addrow.arguments[parseInt($2) + 1];});
			cell.innerHTML = tmp;
		}
		addrowkey ++;
		addrowdirect = 0;
	}
	</script>
EOT;
	$sc_product_str.= '<tr><td colspan="8"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_brand_lang['s128'].'</a></div></td></tr>';
	
$sc_product_str.= '<tr><td colspan="8"><input type="hidden" id="tmpn" value="'.$n.'"><input type="checkbox" style="vertical-align:middle" name="chkall" id="chk_del'.$n.'" class="checkbox" onclick="check_all(this, \'chk_del\')" /><label for="chk_del'.$n.'">'.it618_brand_getlang('s70').'</label> <input type="button" style="padding-bottom:3px;width:50px; line-height:15px; height:26px" onclick="product_save(\'gtypesave\')" value="'.$it618_brand_lang['s120'].'"/></td></tr>';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>