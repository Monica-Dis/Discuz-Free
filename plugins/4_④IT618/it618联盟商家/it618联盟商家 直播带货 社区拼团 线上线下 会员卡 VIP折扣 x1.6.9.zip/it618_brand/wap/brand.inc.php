<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!brand_is_mobile()){
	$homeurl=it618_brand_getrewrite('brand_home','','plugin.php?id=it618_brand:index');
	dheader("location:$homeurl");
}

foreach(C::t('#it618_brand#it618_brand_focus')->fetch_all_by_type_order(31) as $it618_brand_focus) {
	if($it618_brand_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_brand_focus['it618_url'].'" target="_blank"><img class="img" src="'.it618_brand_getwapppic('wapad'.$it618_brand_focus['id'],$it618_brand_focus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_brand_getwapppic('wapad'.$it618_brand_focus['id'],$it618_brand_focus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_brand_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_brand_gonggao = DB::fetch($query)) {
	$it618_title=$it618_brand_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_brand_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_brand_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_brand_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_brand_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

if($it618_brand['waphomeico']=='')$it618_brand['waphomeico']='2|5|11|#888|6';
$waphomeico=explode("|",$it618_brand['waphomeico']);
$tmpn=$waphomeico[0];
$pppn=$waphomeico[1];
$tmpsize=$waphomeico[2];
$tmpcolor=$waphomeico[3];
$tmpw=$waphomeico[4];
$pppw=100/$pppn;
$tmpn=$tmpn*$pppn;

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_brand_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_brand_iconav = DB::fetch($query)) {
	$it618_title=$it618_brand_iconav['it618_title'];
	
	if($it618_brand_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_brand_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_brand_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_brand_iconav['it618_color'].'">'.$it618_title.'</font>';
	}

	$str_iconav.='<td width="'.$pppw.'%"><a href="'.$it618_brand_iconav['it618_url'].'"'.$it618_target.'><img src="'.$it618_brand_iconav['it618_img'].'" /><br>'.$it618_title.'</a></td>';
	
	if($n%$pppn==0)$str_iconav.='</tr><tr>';
	if($n%$tmpn==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';

	$n=$n+1;
}

if($n>1)$n=$n-1;

if($n%$pppn>0){
	for($i=1;$i<=($pppn-$n%$pppn);$i++){
		$str_iconav.='<td width="'.$pppw.'%"></td>';
	}
}

$str_iconav.='</tr>';
$str_iconav=str_replace('<tr></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"></table></div>','',$str_iconav);
$str_iconav=str_replace('<tr><td','<tr><td width='.$tmpw.'></td><td',$str_iconav);
$str_iconav=str_replace('</td></tr>','</td><td width='.$tmpw.'></td></tr>',$str_iconav);
$str_iconav.='<style>.swiper-slide .iconav{table-layout:fixed;}.swiper-slide .iconav tr td a{color:'.$tmpcolor.';font-size:'.$tmpsize.'px}</style>';

$isiconav=count(explode('<img src',$str_iconav))-1;

$zjsalegoods=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('weeksalegoods');
$newjfgoods=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('newjfgoods');
$hotjfgoods=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('hotjfgoods');
$waphomead=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('waphomead');

$tmparr=explode(",",$zjsalegoods);
if(count($tmparr)>2){
	$zjsalegoods_count=$tmparr[1];
	$zjsalegoods_order=$tmparr[2];
}else{
	$zjsalegoods_count=8;
	$zjsalegoods_order=1;
}

$tmparr=explode(",",$weeksalegoods);
if(count($tmparr)>2){
	$weeksalegoods_count=$tmparr[1];
	$weeksalegoods_order=$tmparr[2];
}else{
	$weeksalegoods_count=8;
	$weeksalegoods_order=2;
}

$tmparr=explode(",",$newjfgoods);
if(count($tmparr)>2){
	$newjfgoods_count=$tmparr[1];
	$newjfgoods_order=$tmparr[2];
}else{
	$newjfgoods_count=8;
	$newjfgoods_order=3;
}

$tmparr=explode(",",$hotjfgoods);
if(count($tmparr)>2){
	$hotjfgoods_count=$tmparr[1];
	$hotjfgoods_order=$tmparr[2];
}else{
	$hotjfgoods_count=8;
	$hotjfgoods_order=4;
}

if(!($zjsalegoods_count==0&&$weeksalegoods_count==0&&$newjfgoods_count==0&&$hotjfgoods_count==0)){

	$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newjfgoods"=>$newjfgoods_order,"hotjfgoods"=>$hotjfgoods_order);
	asort($homegoods_arr);
	
	$n=1;
	foreach($homegoods_arr as $key=>$homegoods){
		if($n==1)$current=' class="current"';else $current=' ';
		if($home_goods_js=='')$home_goods_js='get_home_goods("'.$key.'");';
		if($key=='zjsalegoods'){
			if($IsPinEdu==1){
				$it618_brand_lang['t667']=$it618_brand_lang['t800'];
			}
			$tab_goods.='<li'.$current.'onclick="it618_brand_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_brand_lang['t667'].'</li>';
		}
		
		if($key=='weeksalegoods'){
			$tab_goods.='<li'.$current.'onclick="it618_brand_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_brand_lang['t668'].'</li>';
		}
		
		if($key=='newjfgoods'){
			$tab_goods.='<li'.$current.'onclick="it618_brand_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_brand_lang['t669'].'</li>';
		}
		
		if($key=='hotjfgoods'){
			$tab_goods.='<li'.$current.'onclick="it618_brand_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_brand_lang['t670'].'</li>';
		}
		
		$tmpurl=it618_brand_getrewrite('brand_wap','search@0','plugin.php?id=it618_brand:wap&pagetype=search&sid=0');
		if($n==1)$bdstyle=' ;display:';else $bdstyle=' ;display:none';
		$home_goods.='<dl class="list" id="searchli_bd'.($n-1).'" style="border-top:none; margin:0;'.$bdstyle.'">
						<dd style="background-color:#fff;padding:10px">
							<div style="-webkit-overflow-scrolling:touch;overflow:scroll;">
							<table class="tablelist3" id="home_goods_'.$key.'"></table>
							</div>
						</dd>
					  </dl>';
		
		$n=$n+1;
	}
	
	$homegoods_str='<dl style="margin:0;background-color:#fff;padding:0">
	<style>
	.divsearchli{border-bottom:#f9f9f9 1px solid;background-color:#fff;}
	.divsearchli ul{height:38px;}
	.divsearchli ul li{height:38px;line-height:38px; margin:0 13px;font-size:14px;}
	</style>
	<div class="divsearchli"><ul>'.$tab_goods.'</ul></div></dl>'.$home_goods.'<script>'.$home_goods_js.'</script>';
}

if($brandmode!='it618brand'){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
	while($it618_brand_brand_class = DB::fetch($query1)) {
		if($it618_brand_brand_class['it618_wapbrandcount']!=0){
			$it618goods='';$tdn=1;
			foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_search(
				'g.it618_ison=1 and g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1','g.it618_brandorder desc,g.it618_views desc',0,0,$it618_brand_brand_class['id'],0,'',0,0,$startlimit,$it618_brand_brand_class['it618_wapbrandcount']
			) as $it618_brand_goods) {
				
				$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
				if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
				$plcount=C::t('#it618_brand#it618_brand_product_ly')->count_by_it618_pid($it618_brand_goods['id']);
				$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
				
				$jfblstr='';
				if($it618_brand_goods['it618_saletype']==6){
					$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
					$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
				}
				
				if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
					$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
				}
				
				$jfbl='';
				if($jfblstr!=''){
					$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
				}
			
				$it618_count=$it618_brand_lang['s1652'].' '.$it618_brand_goods['it618_count'].' ';
				
				if($it618_brand_goods['it618_isalipay']==1){
					$pricestr='<strong><span>&yen;</span>'.$it618_brand_goods['it618_uprice'].'</strong>
							  <del>&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
				}else{
					$pricestr='<strong class="jfprice">'.$it618_brand_goods['it618_score'].'<span>'.$creditname.'</span></strong>';
				}
				
				$salecount=' '.it618_brand_getlang('s716').''.$salecount;
				if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
					$pricestr='<strong class="noprice">'.$it618_brand_lang['s761'].'</strong>';
					$jfblstr=$it618_brand_lang['s1732'];
					$salecount='<span class="trfl">'.it618_brand_getlang('t474').''.$it618_brand_goods['it618_views'].'</span>';
				}
					
				if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
				
				$views=' '.it618_brand_getlang('s256').''.$it618_brand_goods['it618_views'];
				
				$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
				$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
				$pjhaobl=intval($pjhaocount/$pjallcount*100);
				$pj=$it618_brand_lang['s1899'];
				if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';
				
				if($brandstyle=='1'){
					$it618goods.='<tr>
									<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/></a></td>
									<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
										<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
										<div class="tddes">'.$it618_count.' '.$pj.' '.$salecount.'</div>
										<div class="tdprice">'.$pricestr.'</div>
									</td>
								  </tr>
								  <tr><td colspan="2" class="tdcolspan"></td></tr>';
				}else{
					if($tdn%2>0){
						$trtmpstr1='<tr class="trimg">';
						$trtmpstr2='<tr class="trabout">';
						$tdstr='class="tdleft"';
					}else{
						$tdstr='class="tdright"';
					}

					$trtmpstr1.='<td '.$tdstr.'>'.$jfbl.'<a href="'.$tmpurl.'">
									<img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/>
								</a></td>';
					
					$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'" class="react">
									<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
									<div class="tddes"><span style="float:right">'.$salecount.'</span>'.$pj.'</div>
									<div class="tdprice">'.$pricestr.'</div>
								</a></td>';
								
					if($tdn%2==0){
						$trtmpstr1.='</tr>';
						$trtmpstr2.='</tr>';
						$it618goods.=$trtmpstr1.$trtmpstr2;
					}
					
					$tdn=$tdn+1;
				}
			}
			
			if($brandstyle=='1'){
				$tmparr=explode('</tr>',$it618goods);
				if(count($tmparr)>1){
					$it618goods=$it618goods.'@@@';
					$it618goods=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$it618goods);
				}
				$tmpdtheight=23;
			}else{
				$trtmpstr=$trtmpstr1.'@@@';
				$tmparr=explode('</td>@@@',$trtmpstr);
				if(count($tmparr)>1){
					$trtmpstr1.='</tr>';
					$trtmpstr2.='</tr>';
					$it618goods.=$trtmpstr1.$trtmpstr2;
				}
				$tmpdtheight=13;
			}
			
			$tmpurl=it618_brand_getrewrite('brand_wap','search@'.$it618_brand_brand_class['id'],'plugin.php?id=it618_brand:wap&pagetype=search&sid='.$it618_brand_brand_class['id']);
			$str_brand.='<dl class="list">
							<dd><dl style="padding:0">
								<dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:17px; padding-right:11px;background-color:#f6f6f6;height:'.$tmpdtheight.'px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_brand_lang['t329'].'<img src="source/plugin/it618_brand/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p>'.$it618_brand_brand_class['it618_classname'].$it618_brand_lang['s640'].'</dt>
								<dd id="dd_brands'.$it618_brand_brand_class['id'].'">
								<table width="100%" class="tablelist'.$brandstyle.'">
								'.$it618goods.'
								</table>
								</dd>
							</dl></dd>
						</dl>';
		}
	
	}
}else{
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
	while($it618_brand_brand_class = DB::fetch($query1)) {
		if($it618_brand_brand_class['it618_wapbrandcount']!=0){
			$str_brandtmp='';
			foreach(C::t('#it618_brand#it618_brand_brand')->fetch_all_by_search(
			'it618_state=2 and it618_htstate=1','it618_order desc','',0,0,$it618_brand_brand_class['id'],0,0,$startlimit,($it618_brand_brand_class['it618_wapbrandcount'])
			) as $it618_brand_brand) {
					
					$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
					$ShopPowerIco='';
					if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" style="margin-top:-1px;height:18px;margin-right:3px"/>';
					
					$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$it618_brand_brand['id'],'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$it618_brand_brand['id']);
					$plcount=C::t('#it618_brand#it618_brand_home_ly')->count_by_shopid($it618_brand_brand['id'])+C::t('#it618_brand#it618_brand_product_ly')->count_by_shopid($it618_brand_brand['id'])+C::t('#it618_brand#it618_brand_article_ly')->count_by_shopid($it618_brand_brand['id']);
					
					$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($it618_brand_brand[id]);
					$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
					$tmplevelarr=explode(",",$it618_brand['brand_level']);
					
					$it618_youhui='<div class="tddes">'.$it618_brand_brand['it618_youhui'].'</div>';
					
					$str_brandtmp.='<tr>
									  <td onclick="location.href=\''.$tmpurl.'\'">
										  <img class="tdimg" src="'.it618_brand_getwapppic($it618_brand_brand['id'],$it618_brand_brand['it618_logo']).'"/>
										  <div class="tdname1">'.$it618_brand_brand['it618_name'].'</div>
										  <div class="tdabout"><span style="float:right">'.$lbsm.'</span>'.$ShopPowerIco.'<img style="margin-top:-3px;" src="'.$it618_brand_level['it618_img'].'"></div>
										  '.$it618_youhui.'
										  <div class="tddes1">'.$it618_brand_brand['it618_addr'].'</div>
									  </td>
									</tr>';
			}
			
			if($str_brandtmp!='')$str_brand.='<dl class="list">
							<dd><dl style="padding:0">
								<dt style="text-align:center;font-weight:bold;padding-left:0; padding-right:0; background:url(source/plugin/it618_brand/wap/images/dtbd.png) no-repeat center">'.$it618_brand_brand_class['it618_classname'].$it618_brand_lang['s640'].'</dt>
								<dd id="dd_brands'.$it618_brand_brand_class['id'].'">
								<table width="100%" class="tablelist0">
								'.$str_brandtmp.'
								</table>
								</dd>
							</dl></dd>
						</dl>';
		}
	}
}

$brandsearchurl=it618_brand_getrewrite('brand_wap','search@99','plugin.php?id=it618_brand:wap&pagetype=search&sid=99&findkey=1','?findkey=1');

if($brandmode=='it618brand'){
	$searchurl=it618_brand_getrewrite('brand_wap','search@99','plugin.php?id=it618_brand:wap&pagetype=search&sid=99&findkey=1','?findkey=1');
}else{
	$searchurl=it618_brand_getrewrite('brand_wap','search@0','plugin.php?id=it618_brand:wap&pagetype=search&sid=0&findkey=1','?findkey=1');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>