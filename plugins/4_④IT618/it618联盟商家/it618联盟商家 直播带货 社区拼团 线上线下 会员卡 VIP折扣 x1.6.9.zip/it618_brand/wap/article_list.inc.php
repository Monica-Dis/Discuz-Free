<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cid=intval($_GET['cid']);
$idfornav=$cid;
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_default.func.php';

if(!brand_is_mobile()){
	$tmpurl=it618_brand_getrewrite('shop_articlelist',$ShopId,'plugin.php?id=it618_brand:article_list&sid='.$ShopId);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$classname=C::t('#it618_brand#it618_brand_article_class')->fetch_it618_classname_by_id($cid);
$wapnavtitle=$classname.' - '.$ShopName.' - '.$sitetitle;

$n=1;
$classtmp='<input type="hidden" id="it618_class" name="it618_class" value="'.$cid.'"><a href="javascript:void(0)" onclick="setselect(\'articleclass\',0,0)" name="articleclass"><span>'.$it618_brand_lang['t598'].'</span><i></i></a>';
foreach(C::t('#it618_brand#it618_brand_article_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	if($cid==$it618_tmp['id'])$tmpstr=' class="current"';else $tmpstr='';
	$classtmp.='<a'.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'articleclass\','.$n.','.$it618_tmp['id'].')" name="articleclass"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
	$n=$n+1;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>