<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sid=intval($_GET['sid']);
if(!brand_is_mobile()){
	if($cid>0){
		$tmpurl=it618_brand_getrewrite('brand_list',$sid,'plugin.php?id=it618_brand:list&class1='.$sid);
	}else{
		$tmpurl=it618_brand_getrewrite('brand_list','','plugin.php?id=it618_brand:list');
	}
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$wapnavtitle=$it618_brand_lang['s1301'].' - '.$sitetitle;

if($sid==99||$brandmode=='it618brand'){
	$tab1='';
	$tab2='class="current" style="margin-left:6px"';
	$bdstyle1=';display:none';
	$bdstyle2='';
	$classid=0;
}else{
	$tab1='class="current" style="margin-left:6px"';
	$tab2='';
	$bdstyle1='';
	$bdstyle2=';display:none';
	$classid=$sid;
}

$n=1;
if($sid>0&&$sid!=99){
	$current='';
}else{
	$current='class="current"';
}
$classtmp='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'shopclass1\',0,0)" name="shopclass1"><span>'.$it618_brand_lang['t598'].'</span><i></i></a>';
$classtmp_p='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'shopclass1_p\',0,0)" name="shopclass1_p"><span>'.$it618_brand_lang['t598'].'</span><i></i></a>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_brand_class')." where $classmodesql ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	if($it618_tmp['id']==$sid){
		$current='class="current"';
		$classjs='setselect(\'shopclass1_p\','.$n.','.$it618_tmp['id'].');';
		if($it618_brand['brand_mode']!=2){
			$classjs.='setselect(\'shopclass1\','.$n.','.$it618_tmp['id'].');';
		}
	}else{
		$current='';
	}
	$classtmp.='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'shopclass1\','.$n.','.$it618_tmp['id'].')" name="shopclass1"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
	$classtmp_p.='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'shopclass1_p\','.$n.','.$it618_tmp['id'].')" name="shopclass1_p"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
	$n=$n+1;
}

$n=1;
$areatmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'shoparea1\',0,0)" name="shoparea1"><span>'.$it618_brand_lang['t598'].'</span><i></i></a>';
$areatmp_p='<a class="current" href="javascript:void(0)" onclick="setselect(\'shoparea1_p\',0,0)" name="shoparea1_p"><span>'.$it618_brand_lang['t598'].'</span><i></i></a>';
foreach(C::t('#it618_brand#it618_brand_brand_area')->fetch_all_by_search() as $it618_tmp) {
	$areatmp.='<a href="javascript:void(0)" onclick="setselect(\'shoparea1\','.$n.','.$it618_tmp['id'].')" name="shoparea1"><span>'.$it618_tmp['it618_name'].'</span><i></i></a>';
	$areatmp_p.='<a href="javascript:void(0)" onclick="setselect(\'shoparea1_p\','.$n.','.$it618_tmp['id'].')" name="shoparea1_p"><span>'.$it618_tmp['it618_name'].'</span><i></i></a>';
	$n=$n+1;
}

$n=1;
$brand_hotsw=explode(',',$it618_brand['brand_hotsw']);
for($i=0;$i<count($brand_hotsw);$i++){
	$hotkey1.='<a href="javascript:void(0)" onclick="findbykey(\''.$brand_hotsw[$i].'\',1)"><span>'.$brand_hotsw[$i].'</span><i></i></a>';
	$hotkey0.='<a href="javascript:void(0)" onclick="findbykey(\''.$brand_hotsw[$i].'\',0)"><span>'.$brand_hotsw[$i].'</span><i></i></a>';
	$n=$n+1;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>