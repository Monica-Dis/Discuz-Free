<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($pagetype=='shop')$curclass=' class="navcur"';else $curclass='';

$tmpurl=it618_brand_getrewrite('brand_wap','shop@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$ShopId);
$shopwapurl=$tmpurl;
$str_nav='<a'.$curclass.' href="'.$tmpurl.'">'.$Shop_homenavname.'</a>';

if($IsUnion==1){
	$sql='it618_ison=1';
	
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('brand',$ShopId,$sql);
	if($quancount>0){
		$tmpurl=it618_brand_getrewrite('brand_wap','onepage@'.$ShopId.'@0@0@0','plugin.php?id=it618_brand:wap&pagetype=onepage&sid='.$ShopId.'&oid=0');
		if($pagetype=='onepage' && $idfornav==0){
			$str_nav.='<a href="'.$tmpurl.'" class="navcur"><font color=#f60>'.$it618_brand_lang['s145'].'</font></a>';
		}else{
			$str_nav.='<a href="'.$tmpurl.'"><font color=#f60>'.$it618_brand_lang['s145'].'</font></a>';
		}
	}
	
	$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('brand',$ShopId,$sql);
	if($tuicount>0){
		$tmpurl=it618_brand_getrewrite('brand_wap','onepage@'.$ShopId.'@1@0@0','plugin.php?id=it618_brand:wap&pagetype=onepage&sid='.$ShopId.'&oid=1');
		if($pagetype=='onepage' && $idfornav==1){
			$str_nav.='<a href="'.$tmpurl.'" class="navcur"><font color=#f60>'.$it618_brand_lang['s148'].'</font></a>';
		}else{
			$str_nav.='<a href="'.$tmpurl.'"><font color=#f60>'.$it618_brand_lang['s148'].'</font></a>';
		}
	}
}

foreach(C::t('#it618_brand#it618_brand_show')->fetch_all_by_shopid_isnav($ShopId) as $it618_brand_show_nav) {
	$modeid=$it618_brand_show_nav['it618_showid'];
	$modetype=$it618_brand_show_nav['it618_showtype'];
	$modename=$it618_brand_show_nav['it618_name'];
	
	if($it618_brand_show_nav['it618_isbold']==1)$modename='<b>'.$modename.'</b>';
	
	if($it618_brand_show_nav['it618_color']!='')$modename='<font color="'.$it618_brand_show_nav['it618_color'].'">'.$modename.'</font>';
	
	if($it618_brand_show_nav['it618_isblank']==1)$isblank=' target="_blank"';else $isblank='';
	
	if($modetype=='product_all'){
		if($pagetype=='product_list' || $pagetype=='product')$curclass=' class="navcur"';else $curclass='';
		$tmpurl=it618_brand_getrewrite('brand_wap','product_list@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=product_list&sid='.$ShopId);
		$str_nav.='<a'.$curclass.' href="'.$tmpurl.'"'.$isblank.'>'.$modename.'</a>';
	}
	
	if($modetype=='article'){
		if(($pagetype=='article_list' || $pagetype=='article') && $modeid==$idfornav)$curclass=' class="navcur"';else $curclass='';
		$tmpurl=it618_brand_getrewrite('brand_wap','article_list@'.$ShopId.'@0@'.$modeid.'@0','plugin.php?id=it618_brand:wap&pagetype=article_list&sid='.$ShopId.'&cid='.$modeid);
		$str_nav.='<a'.$curclass.' href="'.$tmpurl.'"'.$isblank.'>'.$modename.'</a>';
	}
	
	if($modetype=='image'){
		if(($pagetype=='image_list' || $pagetype=='image') && $modeid==$idfornav)$curclass=' class="navcur"';else $curclass='';
		$tmpurl=it618_brand_getrewrite('brand_wap','image_list@'.$ShopId.'@0@'.$modeid.'@0','plugin.php?id=it618_brand:wap&pagetype=image_list&sid='.$ShopId.'&cid='.$modeid);
		$str_nav.='<a'.$curclass.' href="'.$tmpurl.'"'.$isblank.'>'.$modename.'</a>';
	}

	if($modetype=='onepage'){
		if(($pagetype=='onepage') && $modeid==$idfornav)$curclass=' class="navcur"';else $curclass='';
		$tmpurl=it618_brand_getrewrite('brand_wap','onepage@'.$ShopId.'@'.$modeid.'@0@0','plugin.php?id=it618_brand:wap&pagetype=onepage&sid='.$ShopId.'&oid='.$modeid);
		$str_nav.='<a'.$curclass.' href="'.$tmpurl.'"'.$isblank.'>'.$modename.'</a>';
	}
	
	if($modetype=='diynav'){
		$str_nav.='<a href="'.$it618_brand_show_nav['it618_url'].'"'.$isblank.'>'.$modename.'</a>';
	}

}
//From: di'.'sm.t'.'aoba'.'o.com
?>