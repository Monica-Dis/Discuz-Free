<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$oid=intval($_GET['oid']);
$it618_brand_article = C::t('#it618_brand#it618_brand_article')->fetch_by_id($oid);
$idforly=$oid;
$idfornav=$it618_brand_article['it618_class_id'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_default.func.php';

if(!brand_is_mobile()){
	$tmpurl=it618_brand_getrewrite('shop_article',$ShopId.'@'.$oid,'plugin.php?id=it618_brand:article&sid='.$ShopId.'&aid='.$oid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if(!($it618_brand_article = C::t('#it618_brand#it618_brand_article')->fetch_by_id($oid))){
	$error=1;$errormsg=it618_brand_getlang('s516');
}

if($ShopId!=C::t('#it618_brand#it618_brand_article')->fetch_it618_shopid_by_id($oid)){
	$error=1;$errormsg=it618_brand_getlang('s516');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$it618_time=date('Y-m-d H:i:s', $it618_brand_article['it618_time']);
C::t('#it618_brand#it618_brand_article')->update_it618_views_by_id($oid);
$plcount=C::t('#it618_brand#it618_brand_article_ly')->count_by_it618_aid($oid);

$classname=C::t('#it618_brand#it618_brand_article_class')->fetch_it618_classname_by_id($it618_brand_article['it618_class_id']);
$wapnavtitle=$it618_brand_article['it618_name'].' - '.$classname.' - '.$ShopName.' - '.$sitetitle;

$it618_message=$it618_brand_article['it618_message'];
$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img class="lazy" data-original="\1"/>',$it618_message);
$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);


require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>