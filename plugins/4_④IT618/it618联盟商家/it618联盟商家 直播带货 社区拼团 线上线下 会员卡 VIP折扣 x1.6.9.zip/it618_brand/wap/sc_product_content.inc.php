<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_default.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if(!brand_is_mobile()){
	$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);
	dheader("location:$shop_home");
}

$spantitle=it618_brand_getlang('s1892');
$wapnavtitle=it618_brand_getlang('s1892').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_brand_getlang('s1005');
}

if($Shop_isgoods==0){
	$error=1;
	$errormsg=it618_brand_getlang('s1640');
}

$pid=intval($_GET['cid']);
$it618_brand_goods=C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

if($it618_cpmsg!=''||$error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

if($Shop_isgoodscheck==1)$tmpstr='<tr><td colspan=2 style="padding-top:0">'.$it618_brand_lang['s1893'].'</td></tr>';

if(submitcheck('it618submit')){	
	
	if($Shop_isgoodscheck==1){
		if($_GET['it618_message_buy']!=$_GET['it618_message_buy_old']){
			$it618_state=0;
		}else{
			$it618_state=$it618_brand_goods['it618_state'];
		}
	}else{
		$it618_state=1;
	}
	
	C::t('#it618_brand#it618_brand_goods')->update($pid,array(
		'it618_mappoint_buy' => dhtmlspecialchars($_GET['it618_mappoint_buy']),
		'it618_message_buy' => $_GET['it618_message_buy'],
		'it618_state' => $it618_state
	));
	
	$preurl=str_replace("@","&",$_GET['preurl']);
	it618_cpmsg(it618_brand_getlang('s1608'), $preurl, 'succeed');
}

$goodsbuycontentbrand=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('goodsbuycontentbrand');

$sc_product_str= '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		editor2 = K.create(\'textarea[name="it618_message_buy"]\', {
			  cssPath : \'source/plugin/it618_brand/kindeditor/plugins/code/prettify.css\',
			  uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=930'.$oss.'\',
			  fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			  allowFileManager : true,
			  filterMode:false,
			  width : \'99%\',
			  afterBlur: function () { this.sync(); },
			  items : [\'source\',\'|\', \'emoticons\', \'image\', \'|\',\'fontname\', \'fontsize\', \'|\', \'forecolor\', \'hilitecolor\', \'bold\', \'underline\']
		});
		
		if(ispc==0)editor2.clickToolbar("source");
		
	});
	
	function checkvalue(){
		if(document.getElementById("it618_message_buy").value==""){
			alert("'.it618_brand_getlang('s1657').'");
			return false;
		}
		return true;
	}
	
	function getmap(obj){
	if(obj.value=="'.$it618_brand_lang['s1678'].'"){
		document.getElementById("spanmap").style.display="";
		obj.value="'.$it618_brand_lang['s1679'].'";
	}else{
		document.getElementById("spanmap").style.display="none";
		obj.value="'.$it618_brand_lang['s1678'].'";
	}
}
</script>';

$sc_product_str.= $tmpstr.'
<tr><td><b><font color=red>'.it618_brand_getlang('s1664').'</font></b><br><font color=blue>'.$it618_brand_lang['s1617'].'</font><input type="text" readonly="readonly" id="it618_mappoint" name="it618_mappoint_buy" value="'.$it618_brand_goods['it618_mappoint_buy'].'" style="width:170px"> <input type="button" class="inputbtn" onclick="document.getElementById(\'it618_mappoint\').value=\'\';document.getElementById(\'spanmap\').style.display=\'none\';document.getElementById(\'btnmap\').value=\''.$it618_brand_lang['s1678'].'\';" value="'.$it618_brand_lang['s1616'].'"><br><input type="button" id="btnmap" style="color:blue;margin-top:6px" onclick="getmap(this)" value="'.$it618_brand_lang['s1678'].'"><span id="spanmap" style="display:none"><br><iframe width="100%" height="300px" marginwidth="0" marginheight="0"  frameborder="no" scrolling="no"  src="'.$_G['siteurl'].'plugin.php?id=it618_brand:getpoint&wap=1&mappoint='.$it618_brand_goods['it618_mappoint_buy'].'"></iframe><br></span><br><b>'.$it618_brand_lang['s1618'].'</b><textarea id="it618_message_buy" name="it618_message_buy" style="width:100%;height:300px;visibility:hidden;">'.$it618_brand_goods['it618_message_buy'].'</textarea><br>'.$goodsbuycontentbrand.'<textarea name="it618_message_buy_old" style="width:100%;height:0px;visibility:hidden;">'.$it618_brand_goods['it618_message_buy'].'</textarea></td></tr>
<tr><td><input type="button" class="it618btn" style="width:100%;height:40px;font-size:15px" onclick="if(checkvalue()){product_save(\'content\');}" value="'.it618_brand_getlang('s120').'" /></td></tr>';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>