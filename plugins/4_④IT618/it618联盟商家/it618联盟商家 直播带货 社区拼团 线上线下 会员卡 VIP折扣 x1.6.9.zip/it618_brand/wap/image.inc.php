<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$oid=intval($_GET['oid']);
$it618_brand_image = C::t('#it618_brand#it618_brand_image')->fetch_by_id($oid);
$idfornav=$it618_brand_image['it618_class_id'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_default.func.php';

if(!brand_is_mobile()){
	$tmpurl=it618_brand_getrewrite('shop_image',$ShopId.'@'.$oid,'plugin.php?id=it618_brand:image&sid='.$ShopId.'&iid='.$oid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if(!($it618_brand_image = C::t('#it618_brand#it618_brand_image')->fetch_by_id($oid))){
	$error=1;$errormsg=it618_brand_getlang('s542');
}

if($ShopId!=C::t('#it618_brand#it618_brand_image')->fetch_it618_shopid_by_id($oid)){
	$error=1;$errormsg=it618_brand_getlang('s542');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$it618_time=date('Y-m-d H:i:s', $it618_brand_image['it618_time']);
C::t('#it618_brand#it618_brand_image')->update_it618_views_by_id($oid);

$classname=C::t('#it618_brand#it618_brand_image_class')->fetch_it618_classname_by_id($it618_brand_image['it618_class_id']);
$wapnavtitle=$it618_brand_image['it618_name'].' - '.$classname.' - '.$ShopName.' - '.$sitetitle;

$n=0;
foreach(C::t('#it618_brand#it618_brand_image')->fetch_all_by_it618_class_id($it618_brand_image['it618_class_id']) as $it618_brand_image_ids) {
	$ids[$n].=$it618_brand_image_ids['id'];
	$n=$n+1;
}

if($n==1){
	$pagepre='<font color="#666666">'.it618_brand_getlang('s543').'</font>';
	$pagenext='<font color="#666666">'.it618_brand_getlang('s544').'</font>';
	$imagenext='<img src="'.$it618_brand_image['it618_url'].'" alt="'.$it618_brand_image['it618_name'].'" />';
}else{
	for($i=0;$i<$n;$i++){
		if($ids[$i]==$oid){
			$preid=$i-1;
			$nextid=$i+1;
			
			if($preid<0){
				$pagepre='<font color="#666666">'.it618_brand_getlang('s543').'</font>';
			}else{
				$tmpurl=it618_brand_getrewrite('brand_wap','image@'.$ShopId.'@'.$ids[$preid].'@0@0','plugin.php?id=it618_brand:wap&pagetype=image&sid='.$ShopId.'&oid='.$ids[$preid]);
				$pagepre='<a href="'.$tmpurl.'" class="btn btn-weak">'.it618_brand_getlang('s543').'</a>';
			}
			
			if($nextid>$n-1){
				$pagenext='<font color="#666666">'.it618_brand_getlang('s544').'</font>';
				$imagenext='<img src="'.$it618_brand_image['it618_url'].'" alt="'.$it618_brand_image['it618_name'].'" />';
			}else{
				$tmpurl=it618_brand_getrewrite('brand_wap','image@'.$ShopId.'@'.$ids[$nextid].'@0@0','plugin.php?id=it618_brand:wap&pagetype=image&sid='.$ShopId.'&oid='.$ids[$nextid]);
				$pagenext='<a href="'.$tmpurl.'" class="btn btn-weak">'.it618_brand_getlang('s544').'</a>';
				$imagenext='<a href="'.$tmpurl.'"><img src="'.$it618_brand_image['it618_url'].'" alt="'.$it618_brand_image['it618_name'].'" /></a>';
			}

			break;
		}
	}
}


require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>