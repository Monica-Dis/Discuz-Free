<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!brand_is_mobile()){
	dheader("location:$brand_home");
}

$wapnavtitle=it618_brand_getlang('t789').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_brand_getlang('s1005');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$menuusername=$_G['username'];
$u_avatarimg=it618_brand_discuz_uc_avatar($_G['uid'],'middle');
$creditname=$_G['setting']['extcredits'][$it618_brand['brand_credit']]['title'];
$creditnum=DB::result_first("select extcredits".$it618_brand['brand_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_buygroup=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$tmpurl_myvip=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$viplogo='source/plugin/it618_credits/images/group.png';
}

if($IsGroup==1){
	$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	$viplogo='source/plugin/it618_group/images/group.png';
}

if($IsUnion==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
}

$cardurl=it618_brand_getrewrite('brand_wap','card@'.$_G['uid'],'plugin.php?id=it618_brand:wap&pagetype=card');
$ucurl1=it618_brand_getrewrite('brand_wap','uc@1','plugin.php?id=it618_brand:wap&pagetype=uc&sid=1');
$ucurl2=it618_brand_getrewrite('brand_wap','uc@2','plugin.php?id=it618_brand:wap&pagetype=uc&sid=2');
$ucurl3=it618_brand_getrewrite('brand_wap','uc@3','plugin.php?id=it618_brand:wap&pagetype=uc&sid=3');
$collecturl=it618_brand_getrewrite('brand_wap','collect@'.$_G['uid'],'plugin.php?id=it618_brand:wap&pagetype=collect');

if($it618_brand_card=C::t('#it618_brand#it618_brand_card')->fetch_by_uid($_G['uid'])){
	$cardstr=$it618_brand_card['it618_name'].' '.$it618_brand_card['it618_cardid'];
}else{
	$cardstr=$it618_brand_lang['s1864'];
}

$uccount1=C::t('#it618_brand#it618_brand_sale')->count_by_shopid(0,"s.it618_type!=0",'',$_GET['pname'],$_G['uid']);
$ucmoney1=C::t('#it618_brand#it618_brand_sale')->sum_it618_price_by_shopid(0,"s.it618_type=2",'','',$_G['uid']);
if($ucmoney1=='')$ucmoney1=0;

$uccount2=C::t('#it618_brand#it618_brand_money')->count_by_shopid(0, 0, 1, 0, $_G['uid']);
$ucmoney2=C::t('#it618_brand#it618_brand_money')->sum_by_shopid(0, 0, 1, 0, $_G['uid']);
if($ucmoney2=='')$ucmoney2=0;

$uccount3=C::t('#it618_brand#it618_brand_order')->count_by_search(0,'','','',$_G['uid']);
$ucmoney3=C::t('#it618_brand#it618_brand_order')->sum_money_by_search(0,'','','',$_G['uid']);
if($ucmoney3=='')$ucmoney3=0;

$collectcount=C::t('#it618_brand#it618_brand_collect')->count_by_uid($_G['uid']);
	
$ygxscount=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid('it618_isxssale',$_G['uid']);
if($ygxscount>0){
	$ygxsurl=it618_brand_getrewrite('brand_wap','salenav@1','plugin.php?id=it618_brand:wap&pagetype=salenav&sid=1');
	$isygxs=1;
}

$ygxxcount=C::t('#it618_brand#it618_brand_yuangong')->count_by_uid('it618_isxxsale',$_G['uid']);
if($ygxxcount>0){
	$ygxxurl=it618_brand_getrewrite('brand_wap','salenav@2','plugin.php?id=it618_brand:wap&pagetype=salenav&sid=2');
	$isygxx=1;
}

$brandtmp=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($_G['uid']);
if($_G['uid']==$brandtmp['it618_uid']&&$brandtmp['it618_state']==2&&$brandtmp['it618_htstate']==1){
	$scurl1=it618_brand_getrewrite('brand_wap','sc@'.$brandtmp['id'].'@1@0@0','plugin.php?id=it618_brand:wap&pagetype=sc&sid='.$brandtmp['id'].'&oid=1');
	$scurl2=it618_brand_getrewrite('brand_wap','sc@'.$brandtmp['id'].'@2@0@0','plugin.php?id=it618_brand:wap&pagetype=sc&sid='.$brandtmp['id'].'&oid=2');
	$scurl3=it618_brand_getrewrite('brand_wap','sc@'.$brandtmp['id'].'@3@0@0','plugin.php?id=it618_brand:wap&pagetype=sc&sid='.$brandtmp['id'].'&oid=3');
	
	$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($brandtmp['it618_power']);
	
	$Shop_isgoods=$it618_brand_brandgroup['it618_isgoods'];
	$Shop_isorder=$it618_brand_brandgroup['it618_isorder'];
	$Shop_ispaytype2=$it618_brand_brandgroup['it618_ispaytype2'];
	$Shop_iscard=$it618_brand_brandgroup['it618_iscard'];
	
	if($Shop_isgoods==1){
		$Shop_isgoodsclass=$brandtmp['it618_isgoodsclass'];
		$shopgoodsclassurl=it618_brand_getrewrite('brand_wap','sc_product_class@'.$brandtmp['id'],'plugin.php?id=it618_brand:wap&pagetype=sc_product_class&sid='.$brandtmp['id']);
		$goodsclasscount = C::t('#it618_brand#it618_brand_class')->count_by_shopid($brandtmp['id']);
		
		$isshopgoods=1;
		$shopgoodsurl=it618_brand_getrewrite('brand_wap','sc_product@'.$brandtmp['id'],'plugin.php?id=it618_brand:wap&pagetype=sc_product&sid='.$brandtmp['id']);
		
		$goodscount = C::t('#it618_brand#it618_brand_goods')->count_by_shopid($brandtmp['id']);
		
		$sccount1=C::t('#it618_brand#it618_brand_sale')->count_by_shopid($brandtmp['id'],"s.it618_type!=0");
		$scmoney1=C::t('#it618_brand#it618_brand_sale')->sum_it618_price_by_shopid($brandtmp['id'],"s.it618_type=2");
		if($scmoney1=='')$scmoney1=0;
		
		if($Shop_isorder==1){
			$sccount3=C::t('#it618_brand#it618_brand_order')->count_by_search($brandtmp['id']);
			$scmoney3=C::t('#it618_brand#it618_brand_order')->sum_money_by_search($brandtmp['id']);
			if($scmoney3=='')$scmoney3=0;
			$isshoporder=1;
		}
	}
	
	$sccount2=C::t('#it618_brand#it618_brand_money')->count_by_shopid($brandtmp['id'], 0, 1);
	$scmoney2=C::t('#it618_brand#it618_brand_money')->sum_by_shopid($brandtmp['id'], 0, 1);
	if($scmoney2=='')$scmoney2=0;
	
	if($Shop_iscard==1){
		$isshopcard=1;
		$shopcardurl=it618_brand_getrewrite('brand_wap','sc_card@'.$brandtmp['id'],'plugin.php?id=it618_brand:wap&pagetype=sc_card&sid='.$brandtmp['id']);
	}
	
	$isshoptx=0;
	if($brandtmp['it618_money']>0||$Shop_ispaytype2==1){
		$isshoptx=1;
		$shoptxurl=it618_brand_getrewrite('brand_wap','sc_tx@'.$brandtmp['id'],'plugin.php?id=it618_brand:wap&pagetype=sc_tx&sid='.$brandtmp['id']);
		$txmoneystr=it618_brand_getlang('s1552').':<font color="red">'.$brandtmp['it618_money'].'</font>'.it618_brand_getlang('s539');
	}
	
	$isshop=1;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>