<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!brand_is_mobile()){
	dheader("location:$brand_home");
}

$wapnavtitle=it618_brand_getlang('s1007').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_brand_getlang('s1005');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$payoksaleid=intval($_GET['payok']);
if($payoksaleid>0){
	$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($payoksaleid);
	if($it618_brand_sale['it618_saletype']==3){
		$payokjs='if(iskm==0){setsalekm('.$payoksaleid.');iskm=1;}';
	}
	if($it618_brand_sale['it618_saletype']==5){
		$payokjs='if(iskm==0){setsalecontend('.$payoksaleid.');iskm=1;}';
	}
}

$menutype=intval($_GET['sid']);
if($menutype==0)$menutype=1;
if($menutype==1)$current1='class="current"';
if($menutype==2)$current2='class="current"';
if($menutype==3)$current3='class="current"';

$ucurl1=it618_brand_getrewrite('brand_wap','uc@1','plugin.php?id=it618_brand:wap&pagetype=uc&sid=1');
$ucurl2=it618_brand_getrewrite('brand_wap','uc@2','plugin.php?id=it618_brand:wap&pagetype=uc&sid=2');
$ucurl3=it618_brand_getrewrite('brand_wap','uc@3','plugin.php?id=it618_brand:wap&pagetype=uc&sid=3');

$pjpicjs='<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
			<script src="source/plugin/it618_brand/kindeditor/kindeditor-min.js?'.$it618_brand_lang['version'].'" charset="utf-8"></script>
			<script src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>