<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_default.func.php';

if(!brand_is_mobile()){
	$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);
	dheader("location:$shop_home");
}

$spantitle=it618_brand_getlang('s1660');
$wapnavtitle=it618_brand_getlang('s1660').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_brand_getlang('s1005');
}

if($Shop_isgoods==0){
	$error=1;
	$errormsg=it618_brand_getlang('s1640');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

foreach(C::t('#it618_brand#it618_brand_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class_id'].'>','<option value='.$_GET['it618_class_id'].' selected="selected">',$tmp);

$sc_product_str1 = '<tr><td style="padding-bottom:6px;line-height:28px"><input id="pname" class="txt" style="width:76%;height:28px;border:#e8e8e8 1px solid" /> <input type="button" class="it618btn1" style="width:21%;float:right" onclick="searchscproduct()" value="'.it618_brand_getlang('s34').'" /><br><select id="pclassid" style="line-height:12px;width:48%;height:30px;border:#e8e8e8 1px solid;margin-top:3px"><option value="0">'.it618_brand_getlang('s233').'</option>'.$tmp1.'</select><select id="pstate" style="line-height:12px;width:50%;height:30px;border:#e8e8e8 1px solid;margin-top:3px;float:right"><option value=0 '.$state0.'>'.it618_brand_getlang('s235').'</option><option value=1 '.$state1.'>'.it618_brand_getlang('s236').'</option><option value=2 '.$state2.'>'.it618_brand_getlang('s237').'</option><option value=3 '.$state3.'>'.it618_brand_getlang('s240').'</option><option value=4 '.$state4.'>'.it618_brand_getlang('s241').'</option><option value=5 '.$state5.'>'.it618_brand_getlang('s242').'</option><option value=6 '.$state6.'>'.it618_brand_getlang('s243').'</option><option value=7 '.$state7.'>'.it618_brand_getlang('s1870').'</option><option value=8 '.$state8.'>'.it618_brand_getlang('s1872').'</option><option value=9 '.$state9.'>'.it618_brand_getlang('s1873').'</option><option value=10 '.$state10.'>'.it618_brand_getlang('s1874').'</option></select></td></tr>';

if($Shop_isgoodssafe==1){
	$goodssafe=$it618_brand_lang['s1815'];
}else{
	$goodssafe=$it618_brand_lang['s1816'];
}
	
$sc_product_str2 = '<tr><td><input type="checkbox" id="chk_isbm" class="checkbox" onclick="check_all(this, \'chk_isbm\')" /><label for="chk_isbm">'.it618_brand_getlang('s257').'</label> <input type="checkbox" id="chk_ison" class="checkbox" onclick="check_all(this, \'chk_ison\')" /><label for="chk_ison">'.it618_brand_getlang('s240').'</label> <input type="checkbox" id="chk_istj" class="checkbox" onclick="check_all(this, \'chk_istj\')" /><label for="chk_istj">'.it618_brand_getlang('s242').'</label> <input type="checkbox" id="chk_isorderbuy" class="checkbox" onclick="check_all(this, \'chk_isorderbuy\')" /><label for="chk_isorderbuy">'.it618_brand_getlang('s1507').'</label> <input type="checkbox" id="chk_issaledisplay" class="checkbox" onclick="check_all(this, \'chk_issaledisplay\')" /><label for="chk_issaledisplay">'.it618_brand_getlang('s1870').'</label></td></tr>
<tr><td><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="check_all(this, \'chk_del\')" /><label for="chkallDx4b">'.it618_brand_getlang('s70').'</label> <input type="button" class="it618btn1" value="'.it618_brand_getlang('s261').'" onclick="if(confirm(\''.$goodssafe.'\n\n'.it618_brand_getlang('s262').'\'))scproduct_save(\'del\')" /> <input type="button" class="it618btn1" value="'.it618_brand_getlang('s263').'" onclick="scproduct_save(\'edit\')"/><br><font color="blue">'.it618_brand_getlang('s846').'<font color=red>'.$ShopUPRICE.'</font> '.it618_brand_getlang('s847').'<font color=red>'.$ShopSCORE.'</font>)</font> <font color=blue>'.it618_brand_getlang('s1104').'<font color=red>'.$ShopJfBl.'%</font>'.it618_brand_getlang('s1242').'</font></td></tr>';


require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>