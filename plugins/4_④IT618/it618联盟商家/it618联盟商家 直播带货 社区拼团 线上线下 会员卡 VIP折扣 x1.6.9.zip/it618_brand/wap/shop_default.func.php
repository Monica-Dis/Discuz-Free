<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$oss;

$oid=intval($_GET['oid']);
$cid=intval($_GET['cid']);

if(isset($_GET['sid'])){
	if(C::t('#it618_brand#it618_brand_brand')->count_by_id($_GET['sid'])>0){
		$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($_GET['sid']);
		$it618_state=$it618_brand_brand['it618_state'];
		if($it618_state==0){
			$error=1;$errormsg=it618_brand_getlang('s380');
		}elseif($it618_state==1){
			$error=1;$errormsg=it618_brand_getlang('s380');
		}else{
			$it618_htstate=$it618_brand_brand['it618_htstate'];
			if($it618_htstate==0){
				$error=1;$errormsg=it618_brand_getlang('s381');
			}elseif($it618_htstate==2){
				if($it618_brand_brand['it618_uid']==$_G['uid']){
					if($IsGroup==1){
						if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('brand',$it618_brand_brand['it618_power'])){
							if($it618_group_rzmoney['it618_istbtime']==1){
								if($it618_group_goodstmp = DB::fetch_first("SELECT * FROM ".DB::table('it618_group_goods')." where it618_groupid=".$it618_group_rzmoney['it618_groupid']." and it618_state=1 ORDER BY it618_unit")){
									require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
									$payurl=it618_group_getrewrite('group_product',$it618_group_goodstmp['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goodstmp['id']);
									dheader("location:$payurl");
								}
							}
						}
					}
				}
				$error=1;$errormsg=it618_brand_getlang('s382');
			}else{
				$ShopId=$it618_brand_brand['id'];
				$ShopName=$it618_brand_brand['it618_name'];
				$ShopUid=$it618_brand_brand['it618_uid'];
				$Shop_power=$it618_brand_brand['it618_power'];
				$Shop_alipaybl=$it618_brand_brand['it618_alipaybl'];
				$ShopName_nav=$it618_brand_brand['it618_name'];
				$ShopStyle=$it618_brand_brand['it618_shopstyle'];
				$ShopMoney=$it618_brand_brand['it618_money'];
				$ShopJfBl=$it618_brand_brand['it618_jfbl'];
				$ShopSCORE=$it618_brand_brand['it618_score'];
				$ShopUPRICE=$it618_brand_brand['it618_uprice'];
				
				$Shop_homenavname=$it618_brand_brand['it618_homenavname'];
				
				$Shop_addr=$it618_brand_brand['it618_addr'];
				$Shop_yytime=$it618_brand_brand['it618_yytime'];
				$Shop_dianhua=$it618_brand_brand['it618_dianhua'];
				$Shop_shouji=$it618_brand_brand['it618_shouji'];
				$Shop_kefuqq=$it618_brand_brand['it618_kefuqq'];
				$Shop_kefuwx=$it618_brand_brand['it618_kefuwx'];
				$Shop_kefuqqname=$it618_brand_brand['it618_kefuqqname'];
				$Shop_ishomely=$it618_brand_brand['it618_ishomely'];
				$Shop_isproductly=$it618_brand_brand['it618_isproductly'];
				$Shop_tongji=$it618_brand_brand['it618_tongji'];
				$Shop_telsalenav=$it618_brand_brand['it618_telsalenav'];
				
				$Shop_ishomely=$it618_brand_brand['it618_ishomely'];
				$Shop_homelycount=$it618_brand_brand['it618_homelycount'];
				$Shop_isproductly=$it618_brand_brand['it618_isproductly'];
				$Shop_isgoodsclass=$it618_brand_brand['it618_isgoodsclass'];
				$Shop_isyunfeikg=$it618_brand_brand['it618_isyunfeikg'];
				$Shop_productlycount=$it618_brand_brand['it618_productlycount'];
				$Shop_isarticlely=$it618_brand_brand['it618_isarticlely'];
				$Shop_articlelycount=$it618_brand_brand['it618_articlelycount'];
				
				$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
				$ShopPower=$it618_brand_brandgroup['it618_groupname'];
				if($it618_brand_brandgroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_brand_brandgroup['it618_img'].'" align="absmiddle" style="margin-top:-1px"/>';
				$Shop_isgoods=$it618_brand_brandgroup['it618_isgoods'];
				$Shop_issaleagain=$it618_brand_brandgroup['it618_issaleagain'];
				$Shop_iscard=$it618_brand_brandgroup['it618_iscard'];
				$Shop_isgoodscheck=$it618_brand_brand['it618_isgoodscheck'];
				$Shop_isgoodssafe=$it618_brand_brand['it618_isgoodssafe'];
				$Shop_goodscount=$it618_brand_brandgroup['it618_goodscount'];
				$Shop_issaletype1=$it618_brand_brandgroup['it618_issaletype1'];
				$Shop_issaletype2=$it618_brand_brandgroup['it618_issaletype2'];
				$Shop_issaletype3=$it618_brand_brandgroup['it618_issaletype3'];
				$Shop_issaletype4=$it618_brand_brandgroup['it618_issaletype4'];
				$Shop_issaletype5=$it618_brand_brandgroup['it618_issaletype5'];
				$Shop_ispaytype1=$it618_brand_brandgroup['it618_ispaytype1'];
				$Shop_ispaytype2=$it618_brand_brandgroup['it618_ispaytype2'];
				$Shop_isorder=$it618_brand_brandgroup['it618_isorder'];
				$Shop_issaleout=$it618_brand_brandgroup['it618_issaleout'];
				$Shop_isuservip=$it618_brand_brandgroup['it618_isuservip'];
				
				$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($ShopId);
				$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);
				
				$shopstr.='<b>'.$ShopName.'</b><br>';
				$shopstr.=it618_brand_getlang('s1295').$ShopPower.'<br>';
				$shopstr.=it618_brand_getlang('s1296').'<img style="vertical-align:middle;margin-top:-3px" src="'.$it618_brand_level['it618_img'].'"><br>';
				if($Shop_addr!='')$shopstr.=it618_brand_getlang('s418').$Shop_addr.'<br>';
				if($Shop_dianhua!='')$shopstr.=it618_brand_getlang('s419').'<a href="tel://'.$Shop_dianhua.'">'.$Shop_dianhua.'</a><br>';
				if($Shop_shouji!='')$shopstr.=it618_brand_getlang('s420').'<a href="tel://'.$Shop_shouji.'">'.$Shop_shouji.'</a><br>';
				if($Shop_fahuo!='')$shopstr.=$Shop_fahuo;
				
				$shophomeurl=it618_brand_getrewrite('brand_wap','shop@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=shop&sid='.$ShopId);
				$shophome='<li><a class="react" href="'.$shophomeurl.'">'.it618_brand_getlang('s610').'</a></li>';
				
				if($it618_brand_brand['it618_mapurl']!=''){
					$mapurl="<a href='{$it618_brand_brand['it618_mapurl']}' target='_blank' style='cursor:pointer;background-color:#f3f3f3; padding:15px 0px;border-radius:3px;width:100%; font-size:14px; float:left;margin-top:10px;text-align:center;margin-bottom:35px;color:#099fde;text-decoration:none;'>".$it618_brand_lang['s1842']."</a>";	
				}
				
				$scurl1=it618_brand_getrewrite('brand_wap','sc_product@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=sc_product&sid='.$ShopId);
				$scurl2=it618_brand_getrewrite('brand_wap','sc_product_add@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=sc_product_add&sid='.$ShopId);
				$scgoodsclassurl=it618_brand_getrewrite('brand_wap','sc_product_class@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=sc_product_class&sid='.$ShopId);
				$scurl5=it618_brand_getrewrite('brand_wap','sc_bank@'.$ShopId,'plugin.php?id=it618_brand:wap&pagetype=sc_bank&sid='.$ShopId);
			}
		}
		
	}else{
		$error=1;$errormsg=it618_brand_getlang('s380');
	}
}else{
	$error=1;$errormsg=it618_brand_getlang('s383');
}

$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($ShopId);

if($pagetype=='sc_product'||$pagetype=='sc_product_add'||$pagetype=='sc_product_edit'||$pagetype=='sc_product_km'||$pagetype=='sc_product_type_km'||$pagetype=='sc_product_type'){
	if(C::t('#it618_brand#it618_brand_brand')->count_by_it618_uid($_G['uid'])>0){
		$it618_brand_brandtmp=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_brand_brandtmp['it618_uid']){
			$error=1;
			$errormsg=it618_brand_getlang('s703');
		}
	}else{
		$error=1;
		$errormsg=it618_brand_getlang('s703');
	}
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$goodscount=C::t('#it618_brand#it618_brand_goods')->count_by_shopid($ShopId, 'it618_ison=1 and it618_state=1');
$articlecount=C::t('#it618_brand#it618_brand_article')->count_by_shopid($ShopId);
$articlecount1=C::t('#it618_brand#it618_brand_onepage')->count_by_shopid($ShopId);
$articlecount=$articlecount+$articlecount1;
$imagecount=C::t('#it618_brand#it618_brand_image')->count_by_shopid($ShopId);

$it618_wapcolors=$it618_brand_brand['it618_wapcolors'];
$it618_wapcolors=explode("@",$it618_wapcolors);

$uid = $_G['uid'];
if($uid>0){
	if($Shop_isuservip==1){
		if($it618_brand_cardmoney=C::t('#it618_brand#it618_brand_cardmoney')->fetch_by_shopid_uid($ShopId,$uid)){
			$allmoney=$it618_brand_cardmoney['it618_money1']+$it618_brand_cardmoney['it618_money2'];
			$fetch_by_money=C::t('#it618_brand#it618_brand_viplevel')->fetch_by_money($ShopId,$allmoney);
			$viplevel=$fetch_by_money['it618_level'];
		}
		
		if($viplevel!=''){
			$viplevel='<font color=red>VIP'.$viplevel.'</font>';
			$zk='<font color=#f60>'.$fetch_by_money['it618_zk'].'%</font>';
		}
	}
	if($pid>0){
		if(C::t('#it618_brand#it618_brand_visit')->count_by_it618_pid_it618_uid($pid,$uid)==0){
			$id = C::t('#it618_brand#it618_brand_visit')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_pid' => $pid,
				'it618_uid' => $uid,
				'it618_time' => $_G['timestamp']
			), true);
		}else{
			C::t('#it618_brand#it618_brand_visit')->update_it618_time_by_it618_pid_it618_uid($_G['timestamp'],$pid,$uid);
		}
	}
	
	if(C::t('#it618_brand#it618_brand_visitall')->count_by_shopid_it618_uid($ShopId,$uid)==0){
		$id = C::t('#it618_brand#it618_brand_visitall')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_uid' => $uid,
			'it618_time' => $_G['timestamp']
		), true);
	}else{
		C::t('#it618_brand#it618_brand_visitall')->update_it618_time_by_shopid_it618_uid($ShopId,$_G['timestamp'],$uid);
	}
	
	$tomonth = date('n'); 
	$todate = date('j'); 
	$toyear = date('Y');
	$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
	if(C::t('#it618_brand#it618_brand_visitcount')->count_by_shopid_it618_uid_it618_time($ShopId,$uid,$time)==0){
		$id = C::t('#it618_brand#it618_brand_visitcount')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_uid' => $uid,
			'it618_time' => $time
		), true);
	}
}

$lybottom=C::t('#it618_brand#it618_brand_set')->getsetvalue_by_setname('lybottom');
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_nav.func.php';
?>