<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!brand_is_mobile()){
	dheader("location:$brand_home");
}

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_brand_getlang('s1005');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

if($_GET['sid']==1){
	$wapnavtitle=it618_brand_getlang('s1778').' - '.$sitetitle;
	
	foreach(C::t('#it618_brand#it618_brand_yuangong')->fetch_sale_by_uid('it618_isxssale',$_G['uid']) as $it618_brand_yuangong) {
		$saleurl=it618_brand_getrewrite('brand_wap','salexs@'.$it618_brand_yuangong['it618_shopid'],'plugin.php?id=it618_brand:wap&pagetype=salexs&sid='.$it618_brand_yuangong['it618_shopid']);
		$shopname=C::t('#it618_brand#it618_brand_brand')->fetch_name_by_id($it618_brand_yuangong['it618_shopid']);
		$shopstr.='<a href="'.$saleurl.'">'.$shopname.'</a>';
	}
}else{
	$wapnavtitle=it618_brand_getlang('s1694').' - '.$sitetitle;
	
	foreach(C::t('#it618_brand#it618_brand_yuangong')->fetch_sale_by_uid('it618_isxxsale',$_G['uid']) as $it618_brand_yuangong) {
		$saleurl=it618_brand_getrewrite('brand_wap','salexx@'.$it618_brand_yuangong['it618_shopid'],'plugin.php?id=it618_brand:wap&pagetype=salexx&sid='.$it618_brand_yuangong['it618_shopid']);
		$shopname=C::t('#it618_brand#it618_brand_brand')->fetch_name_by_id($it618_brand_yuangong['it618_shopid']);
		$shopstr.='<a href="'.$saleurl.'">'.$shopname.'</a>';
	}
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>