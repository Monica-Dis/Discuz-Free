<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_default.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

if(!brand_is_mobile()){
	$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);
	dheader("location:$shop_home");
}

$spantitle=it618_brand_getlang('s1669');
$wapnavtitle=it618_brand_getlang('s1669').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_brand_getlang('s1005');
}

if($Shop_isgoods==0){
	$error=1;
	$errormsg=it618_brand_getlang('s1640');
}

$pid=intval($_GET['cid']);
$it618_brand_goods=C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);

if($it618_brand_goods['it618_shopid']!=$ShopId){
	$error=1;
	$errormsg=it618_brand_getlang('s703');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$scacurl=it618_brand_getrewrite('brand_wap','sc_product_km@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=sc_product_km&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$pid=intval($_GET['cid']);
if(submitcheck('it618submit')){
	$ok1=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_brand_goods_km', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_code'])) {
		foreach($_GET['it618_code'] as $id => $val) {

			C::t('#it618_brand#it618_brand_goods_km')->update($id,array(
				'it618_code' => dhtmlspecialchars($_GET['it618_code'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$it618_cpmsg='<font color=green><b>'.it618_brand_getlang('s5').$ok1.' '.it618_brand_getlang('s7').$del.')'.'</b></font><br><br><input type="button" class="it618btn" style="width:100%;height:40px;font-size:15px" onclick="location.href=\''.$scacurl.'\'" value="'.it618_brand_getlang('s1670').'" /> <input type="button" class="btn alibtn" onclick="location.href=\''.$scurl1.'\'" value="'.it618_brand_getlang('s1852').'" />';
}

if(submitcheck('it618submit_adds')){
	$ok1=0;
	
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $_GET['it618_name_adds']);
	$line=explode("@||@",$lines);

	foreach($line as $key =>$li)
	{
		if(trim($li)!=''){
			C::t('#it618_brand#it618_brand_goods_km')->insert(array(
				'it618_pid' => $pid,
				'it618_code' => dhtmlspecialchars($li)
			), true);
			$ok1=$ok1+1;
		}
	}
	
	$it618_cpmsg='<font color=green><b>'.it618_brand_getlang('s1226').$ok1.'</b></font><br><br><input type="button" class="it618btn" style="width:100%;height:40px;font-size:15px" onclick="location.href=\''.$scacurl.'\'" value="'.it618_brand_getlang('s1670').'" /> <input type="button" class="btn alibtn" onclick="location.href=\''.$scurl1.'\'" value="'.it618_brand_getlang('s1852').'" />';
}

if(submitcheck('it618submit_dao')){
	$ok1=0;
	if (preg_match('/\.\./', $_GET['it618_name_dao'])) {
		$error=1;
		$errormsg=it618_brand_getlang('s1227');
	}
	
	$tmparr=explode("source/plugin/it618_brand/kindeditor",$_GET['it618_name_dao']);
	$file_path='source/plugin/it618_brand/kindeditor'.$tmparr[1];
	
	if (!file_exists($file_path)) {
		$error=1;
		$errormsg=it618_brand_getlang('s1227');
	}
	
	$lines = dfsockopen($_G['siteurl'].$file_path);
	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	ini_set('memory_limit', '-1');
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $lines);
	$line=explode("@||@",$lines);
	$ok1=0;

	foreach($line as $key =>$li)
	{
		if(trim($li)!=''){
			C::t('#it618_brand#it618_brand_goods_km')->insert(array(
				'it618_pid' => $pid,
				'it618_code' => dhtmlspecialchars($li)
			), true);
			$ok1=$ok1+1;
		}
	}
	@unlink($file_path);
	
	$it618_cpmsg='<font color=green><b>'.it618_brand_getlang('s1228').$ok1.'</b></font><br><br><input type="button" class="it618btn" style="width:100%;height:40px;font-size:15px" onclick="location.href=\''.$scacurl.'\'" value="'.it618_brand_getlang('s1670').'" /> <input type="button" class="btn alibtn" onclick="location.href=\''.$scurl1.'\'" value="'.it618_brand_getlang('s1852').'" />';
}

if(submitcheck('it618submit_clear')){
	DB::query("delete from ".DB::table('it618_brand_goods_km')." where it618_pid=".$pid);
	DB::query("update ".DB::table('it618_brand_goods')." set it618_count=0 where id=".$pid);
	
	$it618_cpmsg='<font color=green><b>'.it618_brand_getlang('s1229').'</b></font><br><br><input type="button" class="it618btn" style="width:100%;height:40px;font-size:15px" onclick="location.href=\''.$scacurl.'\'" value="'.it618_brand_getlang('s1670').'" /> <input type="button" class="btn alibtn" onclick="location.href=\''.$scurl1.'\'" value="'.it618_brand_getlang('s1852').'" />';
}

if($it618_cpmsg!=''||$error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

$pname = DB::result_first("select it618_name from ".DB::table('it618_brand_goods')." where id=".$pid);
$sql=DB::table('it618_brand_goods_km')." where it618_pid=".$pid;

$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_brand_goods_km')." WHERE it618_pid=".$pid);
DB::query("update ".DB::table('it618_brand_goods')." set it618_count=".$kmcount." where id=".$pid);

$count = DB::result_first("SELECT COUNT(1) FROM ".$sql);
	
$sc_product_str= '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script>
	KindEditor.ready(function(K) {
				var uploadbutton = K.uploadbutton({
					button : K(\'#btn_upfile\')[0],
					fieldName : \'imgFile\',
					url : \'source/plugin/it618_brand/kindeditor/php/upload_json.php?dir=file&filetype=txt\',
					afterUpload : function(data) {
						if (data.error === 0) {
							var url = K.formatUrl(data.url, \'absolute\');
							K(\'#it618_name_dao\').val(url);
						} else {
							alert(data.message);
						}
					},
					afterError : function(str) {
						alert(str);
					}
				});
				uploadbutton.fileBox.change(function(e) {
					uploadbutton.submit();
				});
			});
</script>
<tr><td>'.it618_brand_getlang('s1230').$count.'</td></tr>';

$sc_product_str.= '<tr><td style="line-height:26px">';
$n=1;
$query = DB::query("SELECT * FROM $sql LIMIT $startlimit, $ppp");
while($it618_brand = DB::fetch($query)) {
	$sc_product_str.= '<input type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_brand[id].'"> <input type="text" class="txt" style="width:90%" name="it618_code['.$it618_brand[id].']" value="'.dhtmlspecialchars($it618_brand[it618_code]).'"><br>';
	$n=$n+1;
}
$sc_product_str.= '<input type="hidden" id="tmpn" value="'.$n.'"></td></tr>';

if($count<=$ppp){
	$pagecount=1;
}else{
	$pagecount=ceil($count/$ppp);
}

if($pagecount>1){
	$n=1;
	while($n<=$pagecount){
		$tmpurl=it618_brand_getrewrite('brand_wap','sc_product_km@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@'.$n,'plugin.php?id=it618_brand:wap&pagetype=sc_product_km&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id'].'&page='.$n);
		if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
		$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
		$n=$n+1;
	}
	$curpage='<select class="pageselect" onchange="getscproductlist(this.value)">'.$curpage.'</select>';
	
	if($page==1){
		$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s708').'</a>';
		if($pagecount>1){
			$tmpurl=it618_brand_getrewrite('brand_wap','sc_product_km@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@2','plugin.php?id=it618_brand:wap&pagetype=sc_product_km&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id'].'&page=2');
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
		}else{
			$pagenext='<a class="btn btn-weak btn-disabled">'.it618_brand_getlang('s709').'</a>';
		}
	}elseif($page<$pagecount){
		$tmpurl=it618_brand_getrewrite('brand_wap','sc_product_km@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@'.($page-1),'plugin.php?id=it618_brand:wap&pagetype=sc_product_km&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id'].'&page='.($page-1));
		$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
		$tmpurl=it618_brand_getrewrite('brand_wap','sc_product_km@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@'.($page+1),'plugin.php?id=it618_brand:wap&pagetype=sc_product_km&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id'].'&page='.($page+1));
		$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s709').'</a>';
	}else{
		$tmpurl=it618_brand_getrewrite('brand_wap','sc_product_km@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@'.($page-1),'plugin.php?id=it618_brand:wap&pagetype=sc_product_km&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id'].'&page='.($page-1));
		$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_brand_getlang('s708').'</a>';
		$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_brand_getlang('s709').'</a>';
	}
	$multipage='<tr><td align="center" style="border-top:#e8e8e8 1px solid">'.$pagepre.' '.$curpage.' '.$pagenext.'</td></tr>';
}
	
$sc_product_str.= $multipage.'<tr><td><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="check_all(this, \'chk_del\')" /><label for="chkallDx4b">'.it618_brand_getlang('s70').'</label> <input type="button" style="padding-bottom:3px; line-height:15px; height:26px" name="it618submit" value="'.$it618_brand_lang['s120'].'"/> <input type="button" style="padding-bottom:3px; line-height:15px; height:26px" value="'.it618_brand_getlang('s1231').'" onclick="if(confirm(\''.it618_brand_getlang('s1232').'\'))" /></td></tr>
<tr><td>'.it618_brand_getlang('s1234').'<br><textarea name="it618_name_adds" style="width:100%;height:200px;margin-top:2px;"></textarea><br><input type="submit" name="it618submit_adds" value="'.it618_brand_getlang('s1236').'"/></td></tr>
<tr><td>'.it618_brand_getlang('s1235').'<br><input id="it618_name_dao" style="padding-bottom:3px; line-height:15px; height:26px" name="it618_name_dao" class="txt" style="width:210px"> <input type="submit" style="padding-bottom:3px; line-height:15px; height:26px" id="btn_upfile" value="'.it618_brand_getlang('s1237').'"/><br><input style="padding-bottom:3px; line-height:15px; height:26px" type="submit" name="it618submit_dao" value="'.it618_brand_getlang('s1238').'"/></td></tr>';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>