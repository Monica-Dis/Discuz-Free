<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/wap/shop_default.func.php';

if(!brand_is_mobile()){
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	
	if($urltmp!=''){
		$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId.'&'.$urltmp,'?'.$urltmp);
	}else{
		$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId);
	}

	dheader("location:$shop_home");
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
	include template('it618_brand:wap_brand');
	return;
}

foreach(C::t('#it618_brand#it618_brand_focus')->fetch_all_by_shopid_order($ShopId) as $it618_brand_focus) {
	if($it618_brand_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_brand_focus['it618_url'].'" target="_blank"><img class="img" src="'.$it618_brand_focus['it618_img'].'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.$it618_brand_focus['it618_img'].'" /></div>';
	}
}

$firstmode=0;
foreach(C::t('#it618_brand#it618_brand_show')->fetch_all_by_shopid_ishome($ShopId) as $it618_brand_show) {
	$modeid=$it618_brand_show['it618_showid'];
	$modetype=$it618_brand_show['it618_showtype'];
	$modename=$it618_brand_show['it618_name'];
	$homecount=$it618_brand_show['it618_homecount'];
	
	$homecontent.=gethomemode($ShopId,$modeid,$modetype,$modename,$homecount);
	
}

$pjcount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_shopid($it618_brand_brand[id]);
$it618_brand_level=C::t('#it618_brand#it618_brand_level')->fetch_by_type_salecount(0,$pjcount);

$wapnavtitle=$it618_brand_brand['it618_name'].' - '.$sitetitle;

$idforly=0;$wap=1;
if($_G['cache']['plugin']['it618_brand']['rewriteurl']==0)$tmpstr='&';else $tmpstr='?';
$shop_home=it618_brand_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_brand:shop&sid='.$ShopId).$tmpstr.'app';

function gethomemode($shopid,$modeid,$modetype,$modename,$homecount){
	global $_G,$it618_brand,$it618_brand_lang,$creditname,$firstmode,$brandstyle;
	
	if($brandstyle=='1'){
		$tmpdtheight=23;
	}else{
		$tmpdtheight=13;
	}
		
	if($modetype=='product_all'||$modetype=='product_tj'){
		if($modetype=='product_all'){
			$sql='it618_ison=1 and it618_state=1';
		}else{
			$sql='it618_ison=1 and it618_state=1 and it618_istj=1';
		}
		
		$tmpurl=it618_brand_getrewrite('brand_wap','product_list@'.$shopid,'plugin.php?id=it618_brand:wap&pagetype=product_list&sid='.$shopid);
		
		$modecontent='<dl class="list">
    	<dd><dl>
		<dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:17px; padding-right:11px;background-color:#f6f6f6;height:'.$tmpdtheight.'px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_brand_lang['t329'].'<img src="source/plugin/it618_brand/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p>'.$modename.'</dt>
        <dd id="dd_'.$modetype.'">
            <table width="100%" class="tablelist'.$brandstyle.'">
			';
		$tdn=1;
		foreach(C::t('#it618_brand#it618_brand_goods')->fetch_all_by_shopid(
				$shopid,$sql,'it618_order desc','',0,0,0,0,$homecount
		) as $it618_brand_goods) {
			$tmpurl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$it618_brand_goods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$it618_brand_goods['id']);
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
			$plcount=C::t('#it618_brand#it618_brand_product_ly')->count_by_it618_pid($it618_brand_goods['id']);
			$salecount = C::t('#it618_brand#it618_brand_sale')->count_by_it618_pid($it618_brand_goods['id']);
			
			$jfblstr='';
			if($it618_brand_goods['it618_saletype']==6){
				$goodsmoney=round(($it618_brand_goods['it618_uprice']*$it618_brand_goods['it618_prepaybl']/100),2);
				$jfblstr=$it618_brand_lang['s857'].$goodsmoney.$it618_brand_lang['s389'].' ';
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_jfbl']>0){
				$jfblstr.=$it618_brand_lang['s2'].$it618_brand_goods['it618_jfbl'].'%'.$creditname;
			}
			
			$jfbl='';
			if($jfblstr!=''){
				$jfbl='<div class="divjfbl">'.$jfblstr.'</div>';
			}
		
			$it618_count=$it618_brand_lang['s1652'].' '.$it618_brand_goods['it618_count'].' ';
			
			if($it618_brand_goods['it618_isalipay']==1){
				$pricestr='<strong><span>&yen;</span>'.$it618_brand_goods['it618_uprice'].'</strong>
						  <del>&yen;'.floatval($it618_brand_goods['it618_price']).'</del>';
			}else{
				$pricestr='<strong class="jfprice">'.$it618_brand_goods['it618_score'].'<span>'.$creditname.'</span></strong>';
			}
			
			if($it618_brand_goods['it618_isalipay']==1&&$it618_brand_goods['it618_isduihuan']==1){
				$jfblstr='<span style="float:right"><font color=#999>'.$it618_brand_lang['s155'].$it618_brand_goods['it618_score'].$creditname.'</font></span>'.$jfblstr;
			}
			
			$salecount=' '.it618_brand_getlang('s716').''.$salecount;
			if($it618_brand_goods['it618_isalipay']==0&&$it618_brand_goods['it618_isduihuan']==0){
				$pricestr='<strong class="noprice">'.$it618_brand_lang['s761'].'</strong>';
				$jfblstr=$it618_brand_lang['s1732'];
				$salecount='<span class="trfl">'.it618_brand_getlang('t474').''.$it618_brand_goods['it618_views'].'</span>';
			}
				
			if(lang('plugin/it618_brand', $it618_brand_lang['it618'])!=$it618_brand_lang['version'])return;
			
			$views=' '.it618_brand_getlang('s256').''.$it618_brand_goods['it618_views'];
			
			$pjhaocount=C::t('#it618_brand#it618_brand_sale')->count_by_it618_pj_pid(1,$it618_brand_goods['id']);
			$pjallcount=C::t('#it618_brand#it618_brand_sale')->count_pj_by_pid($it618_brand_goods['id']);
			$pjhaobl=intval($pjhaocount/$pjallcount*100);
			$pj=$it618_brand_lang['s1899'];
			if($pjallcount>0)$pj=' '.it618_brand_getlang('s1821').''.$pjallcount.' '.it618_brand_getlang('s1822').''.$pjhaobl.'%';
			
			if($brandstyle=='1'){
				$modecontent.='<tr>
								<td class="tdleft">'.$jfbl.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
									<div class="tddes">'.$it618_count.' '.$pj.' '.$salecount.'</div>
									<div class="tdprice">'.$pricestr.'</div>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
			}else{
				if($tdn%2>0){
					$trtmpstr1='<tr class="trimg">';
					$trtmpstr2='<tr class="trabout">';
					$tdstr='class="tdleft"';
				}else{
					$tdstr='class="tdright"';
				}

				$trtmpstr1.='<td '.$tdstr.'>'.$jfbl.'<a href="'.$tmpurl.'">
								<img class="lazy" data-original="'.it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']).'"/>
							</a></td>';
				
				$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'" class="react">
								<div class="tdname">'.$it618_brand_goods['it618_name'].'</div>
								<div class="tddes"><span style="float:right">'.$salecount.'</span>'.$pj.'</div>
								<div class="tdprice">'.$pricestr.'</div>
							</a></td>';
							
				if($tdn%2==0){
					$trtmpstr1.='</tr>';
					$trtmpstr2.='</tr>';
					$modecontent.=$trtmpstr1.$trtmpstr2;
				}
				
				$tdn=$tdn+1;
			}
		}
		
		if($brandstyle=='1'){
			$tmparr=explode('</tr>',$modecontent);
			if(count($tmparr)>1){
				$modecontent=$modecontent.'@@@';
				$modecontent=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$modecontent);
			}
		}else{
			$trtmpstr=$trtmpstr1.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr);
			if(count($tmparr)>1){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$modecontent.=$trtmpstr1.$trtmpstr2;
			}
		}
		
		$modecontent.='</table>
        </dd>
    </dl></dd>
</dl>';

	}elseif($modetype=='article'){
		if($firstmode==0){$firstmodecss='firstmode';$firstmode=1;}
		$tmpurl=it618_brand_getrewrite('brand_wap','article_list@'.$shopid.'@'.$modeid.'@0@0','plugin.php?id=it618_brand:wap&pagetype=article_list&sid='.$shopid.'&cid='.$modeid);
		$modecontent='<dl class="list">
    	<dd><dl>
		<dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:17px; padding-right:11px;background-color:#f6f6f6;height:23px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_brand_lang['t329'].'<img src="source/plugin/it618_brand/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p>'.$modename.'</dt>
        <dd id="dd_'.$modetype.'">
            <div class="deal-container"><table class="articletable"><tbody id="articlelist">';
		
		$n=1;
		foreach(C::t('#it618_brand#it618_brand_article')->fetch_all_by_shopid(
				$shopid,'',$modeid,0,$homecount
		) as $it618_brand_article) {
			$it618_message=strip_tags($it618_brand_article['it618_message']);
			$it618_message=str_replace(" ","",$it618_message);
			$it618_message=str_replace("&nbsp;","",$it618_message);
			$it618_message=str_replace("<br>","",$it618_message);
			$it618_message=str_replace("\n","",$it618_message);
			$it618_message=cutstr($it618_message,200,'...');
			
			$lycount = C::t('#it618_brand#it618_brand_article_ly')->count_by_it618_aid($it618_brand_article['id']);
			
			if($it618_brand_article['it618_color']!=''){
				$it618_name='<font color='.$it618_brand_article['it618_color'].'>'.$it618_brand_article['it618_name'].'</font>';
			}else{
				$it618_name=$it618_brand_article['it618_name'];
			}
			
			$modecontent.='<tr><td><a href="'.$tmpurl.'" target="_blank">'.$it618_name.'</a><p>'.$it618_message.' &nbsp; <i>'.it618_brand_gettime($it618_brand_article['it618_time']).'&nbsp;&nbsp;'.$lycount.it618_brand_getlang('s397').'</i></p></td></tr>';
			
			$n=$n+1;
		}
		
		$modecontent.='</tbody></table>
		</div>
        </dd>
    </dl></dd>
</dl>';

	}elseif($modetype=='image'){
		if($firstmode==0){$firstmodecss='firstmode';$firstmode=1;}
		$tmpurl=it618_brand_getrewrite('brand_wap','image_list@'.$shopid.'@0@'.$modeid.'@0','plugin.php?id=it618_brand:wap&pagetype=image_list&sid='.$shopid.'&cid='.$modeid);
		$modecontent='<dl class="list">
    	<dd><dl>
        <dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:17px; padding-right:11px;background-color:#f6f6f6;height:23px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_brand_lang['t329'].'<img src="source/plugin/it618_brand/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p>'.$modename.'</dt>
        <dd id="dd_'.$modetype.'">
            <div class="deal-container"><table class="imagetable"><tbody id="imagelist">';
		
		$n=1;
		foreach(C::t('#it618_brand#it618_brand_image')->fetch_all_by_shopid(
				$shopid,'',$modeid,0,$homecount
		) as $it618_brand_image) {

			$tmpurl=it618_brand_getrewrite('shop_image',$shopid.'@'.$it618_brand_image['id'],'plugin.php?id=it618_brand:image&sid='.$shopid.'&iid='.$it618_brand_image['id']);

			if($n%2!=0){$tmptr='<tr>';$tmptr1='';}else{$tmptr='';$tmptr1='</tr>';}
				
			$tmpurl=it618_brand_getrewrite('brand_wap','image@'.$it618_brand_image['it618_shopid'].'@'.$it618_brand_image['id'].'@0@0','plugin.php?id=it618_brand:wap&pagetype=image&sid='.$it618_brand_image['it618_shopid'].'&oid='.$it618_brand_image['id']);
		
			$modecontent.=$tmptr.'<td><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_brand_image['it618_smallurl'].'" /></a><p>'.$it618_brand_image['it618_name'].'</p></td>'.$tmptr1;
			
			$n=$n+1;
		}
		
		$modecontent.='</tbody></table>
		</div>
        </dd>
    </dl></dd>
</dl>';

	}elseif($modetype=='onepage'){
		$it618_brand_onepage=C::t('#it618_brand#it618_brand_onepage')->fetch_by_id($modeid);
		
		$it618_message=$it618_brand_onepage['it618_message'];
		$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
		$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img src="\1"/>',$it618_message);
		$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);
		$tmparr=explode("{page}",$it618_message);
		
		if(count($tmparr)>0){
			$it618_message=$tmparr[0];
			$tmpurl=it618_brand_getrewrite('brand_wap','onepage@'.$shopid.'@'.$it618_brand_onepage['id'].'@0@0','plugin.php?id=it618_brand:wap&pagetype=onepage&sid='.$shopid.'&oid='.$it618_brand_onepage['id']);
			$tmpstr='<div class="wapmore"><a href="'.$tmpurl.'">'.it618_brand_getlang('s396').'&gt;&gt;</a></div>';
		}
		if($firstmode==0){$firstmodecss='firstmode';$firstmode=1;}
		$modecontent='<dl class="list">
    	<dd><dl>
        <dt style="text-align:center;font-weight:bold;padding-left:0; padding-right:0; background:url(source/plugin/it618_brand/wap/images/dtbd.png) no-repeat center">'.$modename.'</dt>
        <dd id="dd_'.$modetype.'" style="padding-left:6px;padding-right:6px">
			<table class="it618message" width="100%"><tr><td>'.$it618_message.'</td></tr></table>
        </dd>
    </dl></dd>
</dl>';

	}
		
	return $modecontent;
	
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:wap_brand');
?>