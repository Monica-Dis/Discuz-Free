<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

$oid=intval($_GET['oid']);
$tmparr=explode(":",$_GET['id']);
$pagetype=$tmparr[1];

if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','onepage@'.$ShopId.'@'.$oid.'@0@0','plugin.php?id=it618_brand:wap&pagetype=onepage&sid='.$ShopId.'&oid='.$oid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if($oid==0){
	if($IsUnion==1){
		$seotitle=$it618_brand_lang['s145'];
		$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo;  '.$it618_brand_lang['s145'];
	}else{
		echo it618_brand_getlang('s549');exit;
	}
}elseif($oid==1){
	if($IsUnion==1){
		$seotitle=$it618_brand_lang['s148'];
		$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo;  '.$it618_brand_lang['s148'];
	}else{
		echo it618_brand_getlang('s549');exit;
	}
}else{
	if(!($it618_brand_onepage = C::t('#it618_brand#it618_brand_onepage')->fetch_by_id($oid))){
		echo it618_brand_getlang('s549');exit;
	}
	
	if($ShopId!=C::t('#it618_brand#it618_brand_onepage')->fetch_it618_shopid_by_id($oid)){
		echo it618_brand_getlang('s549');exit;
	}
	
	
	$it618_time=date('Y-m-d H:i:s', $it618_brand_onepage['it618_time']);
	C::t('#it618_brand#it618_brand_onepage')->update_it618_views_by_id($oid);
	
	$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="935" height="526" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_brand_onepage['it618_message']);
	
	$seotitle=$it618_brand_onepage['it618_name'];
	$seokeywords=$it618_brand_onepage['it618_seokeywords'];
	$seodescription=$it618_brand_onepage['it618_seodescription'];
	$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo;  '.$it618_brand_onepage['it618_name'];
}

$idforly=$oid;$idfornav=$oid;
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_nav.func.php';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:shop_default');
?>