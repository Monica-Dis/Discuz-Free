<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_default.func.php';

$aid=intval($_GET['aid']);
if(brand_is_mobile()){ 
	$tmpurl=it618_brand_getrewrite('brand_wap','article@'.$ShopId.'@'.$aid.'@0@0','plugin.php?id=it618_brand:wap&pagetype=article&sid='.$ShopId.'&oid='.$aid);
	dheader("location:$tmpurl"); /*dism - taobao - com*/
}

if(!($it618_brand_article = C::t('#it618_brand#it618_brand_article')->fetch_by_id($aid))){
	echo it618_brand_getlang('s516');exit;
}

if($ShopId!=C::t('#it618_brand#it618_brand_article')->fetch_it618_shopid_by_id($aid)){
	echo it618_brand_getlang('s516');exit;
}


$it618_time=date('Y-m-d H:i:s', $it618_brand_article['it618_time']);
C::t('#it618_brand#it618_brand_article')->update_it618_views_by_id($aid);
$plcount=C::t('#it618_brand#it618_brand_article_ly')->count_by_it618_aid($aid);

$tmparr=explode(":",$_GET['id']);
$pagetype=$tmparr[1];
$seotitle=$it618_brand_article['it618_name'];
$seokeywords=$it618_brand_article['it618_seokeywords'];
$seodescription=$it618_brand_article['it618_seodescription'];
$tmpurl=it618_brand_getrewrite('shop_articlelist',$ShopId.'@'.$it618_brand_article['it618_class_id'].'@1','plugin.php?id=it618_brand:article_list&sid='.$ShopId.'&cid='.$it618_brand_article['it618_class_id']);
$pagepath='<a href="'.$shop_home.'" class="a1">'.$Shop_homenavname.'</a> &raquo; <a href="'.$tmpurl.'" class="a1">'.C::t('#it618_brand#it618_brand_article_class')->fetch_it618_classname_by_id($it618_brand_article['it618_class_id']).'</a> &raquo; '.$it618_brand_article['it618_name'];

$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="935" height="526" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_brand_article['it618_message']);

$idforly=$aid;$idfornav=$it618_brand_article['it618_class_id'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/shop_nav.func.php';

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:shop_default');
?>