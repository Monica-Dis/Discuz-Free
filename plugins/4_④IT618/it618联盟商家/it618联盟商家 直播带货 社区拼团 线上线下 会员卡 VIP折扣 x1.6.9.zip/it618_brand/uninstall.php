<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$query = DB::query("SELECT * FROM ".DB::table('it618_brand_diy'));
while($it618_brand_diy = DB::fetch($query)) {
	runquery("delete from ".DB::table('common_block')." where name = '".$it618_brand_diy['it618_name']."'");
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_brand_addr`;

DROP TABLE IF EXISTS `pre_it618_brand_article`;

DROP TABLE IF EXISTS `pre_it618_brand_article_class`;

DROP TABLE IF EXISTS `pre_it618_brand_article_ly`;

DROP TABLE IF EXISTS `pre_it618_brand_brand`;

DROP TABLE IF EXISTS `pre_it618_brand_brandgroup`;

DROP TABLE IF EXISTS `pre_it618_brand_moneyset`;

DROP TABLE IF EXISTS `pre_it618_brand_live`;

DROP TABLE IF EXISTS `pre_it618_brand_style`;

DROP TABLE IF EXISTS `pre_it618_brand_nav`;

DROP TABLE IF EXISTS `pre_it618_brand_wapstyle`;

DROP TABLE IF EXISTS `pre_it618_brand_iconav`;

DROP TABLE IF EXISTS `pre_it618_brand_bottomnav`;

DROP TABLE IF EXISTS `pre_it618_brand_brand_area`;

DROP TABLE IF EXISTS `pre_it618_brand_brand_area1`;

DROP TABLE IF EXISTS `pre_it618_brand_brand_class`;

DROP TABLE IF EXISTS `pre_it618_brand_brand_class1`;

DROP TABLE IF EXISTS `pre_it618_brand_class`;

DROP TABLE IF EXISTS `pre_it618_brand_focus`;

DROP TABLE IF EXISTS `pre_it618_brand_gonggao`;

DROP TABLE IF EXISTS `pre_it618_brand_goods`;

DROP TABLE IF EXISTS `pre_it618_brand_goods_type`;

DROP TABLE IF EXISTS `pre_it618_brand_goods_km`;

DROP TABLE IF EXISTS `pre_it618_brand_goods_type_km`;

DROP TABLE IF EXISTS `pre_it618_brand_goods_salekm`;

DROP TABLE IF EXISTS `pre_it618_brand_home_ly`;

DROP TABLE IF EXISTS `pre_it618_brand_image`;

DROP TABLE IF EXISTS `pre_it618_brand_image_class`;

DROP TABLE IF EXISTS `pre_it618_brand_link`;

DROP TABLE IF EXISTS `pre_it618_brand_onepage`;

DROP TABLE IF EXISTS `pre_it618_brand_product_ly`;

DROP TABLE IF EXISTS `pre_it618_brand_money`;

DROP TABLE IF EXISTS `pre_it618_brand_sale`;

DROP TABLE IF EXISTS `pre_it618_brand_sale_pjpic`;

DROP TABLE IF EXISTS `pre_it618_brand_order`;

DROP TABLE IF EXISTS `pre_it618_brand_set`;

DROP TABLE IF EXISTS `pre_it618_brand_show`;

DROP TABLE IF EXISTS `pre_it618_brand_visit`;

DROP TABLE IF EXISTS `pre_it618_brand_visitall`;

DROP TABLE IF EXISTS `pre_it618_brand_visitcount`;

DROP TABLE IF EXISTS `pre_it618_brand_yuangong`;

DROP TABLE IF EXISTS `pre_it618_brand_yuangongsale`;

DROP TABLE IF EXISTS `pre_it618_brand_diy`;

DROP TABLE IF EXISTS `pre_it618_brand_level`;

DROP TABLE IF EXISTS `pre_it618_brand_kd`;

DROP TABLE IF EXISTS `pre_it618_brand_kdarea`;

DROP TABLE IF EXISTS `pre_it618_brand_kdyunfei`;

DROP TABLE IF EXISTS `pre_it618_brand_bank`;

DROP TABLE IF EXISTS `pre_it618_brand_txbl`;

DROP TABLE IF EXISTS `pre_it618_brand_tx`;

DROP TABLE IF EXISTS `pre_it618_brand_card`;

DROP TABLE IF EXISTS `pre_it618_brand_cardmoney`;

DROP TABLE IF EXISTS `pre_it618_brand_viplevel`;

DROP TABLE IF EXISTS `pre_it618_brand_gwc`;

DROP TABLE IF EXISTS `pre_it618_brand_gwcsale_main`;

DROP TABLE IF EXISTS `pre_it618_brand_gwcsale`;

DROP TABLE IF EXISTS `pre_it618_brand_saleaudio`;

DROP TABLE IF EXISTS `pre_it618_brand_collect`;

DROP TABLE IF EXISTS `pre_it618_brand_findkey`;

DROP TABLE IF EXISTS `pre_it618_brand_salework`;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>