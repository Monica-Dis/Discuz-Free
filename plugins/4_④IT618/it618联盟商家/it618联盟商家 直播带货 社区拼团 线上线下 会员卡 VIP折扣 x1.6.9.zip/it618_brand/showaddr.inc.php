<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_brand = $_G['cache']['plugin']['it618_brand'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/lang.func.php';

$uid = $_G['uid'];
if($uid<0){
	echo it618_brand_getlang('s125');
	return;
}

if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_members'")>0){
	if($it618_members_user=DB::fetch_first("SELECT it618_tel FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){					
		$tel=$it618_members_user['it618_tel'];
	}
}

if($_GET['wap']==1){
	$height=$_GET['height']*0.9-26;
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:showaddr');
?>