<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

if($Shop_issaleout==0){
	it618_cpmsg($it618_brand_lang['s1643'], '', 'error');
}

if($IsCredits!=1){
	it618_cpmsg(it618_brand_getlang('s1072'), "plugin.php?id=it618_brand:sc_money$adminsid", 'error');
}else{
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_credits/config/skset.php';
	}
	if($sk_isok!=1){
		it618_cpmsg($it618_brand_lang['s1064'], '', 'error');
	}
}

if(submitcheck('it618submit')){
	if($it618_brand_moneyset=C::t('#it618_brand#it618_brand_moneyset')->fetch_by_shopid($ShopId)){
		C::t('#it618_brand#it618_brand_moneyset')->update($it618_brand_moneyset['id'],array(
			'it618_isok' => intval($_GET["it618_isok"]),
			'it618_islogin' => intval($_GET["it618_islogin"]),
			'it618_zsbl' => floatval($_GET["it618_zsbl"]),
			'it618_num' => intval($_GET["it618_num"]),
			'it618_num1' => intval($_GET["it618_num1"]),
			'it618_zsbl1' => floatval($_GET["it618_zsbl1"]),
			'it618_zsbl2' => floatval($_GET["it618_zsbl2"]),
			'it618_zsbl3' => floatval($_GET["it618_zsbl3"])
		));
	}else{
		C::t('#it618_brand#it618_brand_moneyset')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_isok' => intval($_GET["it618_isok"]),
			'it618_islogin' => intval($_GET["it618_islogin"]),
			'it618_zsbl' => floatval($_GET["it618_zsbl"]),
			'it618_num' => intval($_GET["it618_num"]),
			'it618_num1' => intval($_GET["it618_num1"]),
			'it618_zsbl1' => floatval($_GET["it618_zsbl1"]),
			'it618_zsbl2' => floatval($_GET["it618_zsbl2"]),
			'it618_zsbl3' => floatval($_GET["it618_zsbl3"])
	    ), true);
	}

	it618_cpmsg(it618_brand_getlang('s1069'), "plugin.php?id=it618_brand:sc_moneyset$adminsid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_brand:sc_moneyset$adminsid");
showtableheaders(it618_brand_getlang('s1059'),'it618_brand_brand');

$it618_brand_moneyset=C::t('#it618_brand#it618_brand_moneyset')->fetch_by_shopid($ShopId);
if($it618_brand_moneyset['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
if($it618_brand_moneyset['it618_islogin']==1)$it618_islogin_checked='checked="checked"';else $it618_islogin_checked="";

require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
$tmpurl_sk=$_G['siteurl'].it618_credits_getrewrite('credits_wap','moneysk@'.$ShopUid,'plugin.php?id=it618_credits:wap&dotype=moneysk&ctype='.$ShopUid);
$skurlcode=it618_credits_qrcode($tmpurl_sk);

if($sk_zsbl==0){
	$skjlstr=$it618_credits_lang['t256'];
	$skjlstr=str_replace("{money}",$sk_money,$skjlstr);
	$skjlstr=str_replace("{tc}",$sk_tcbl,$skjlstr);
}else{
	$skjlstr=$it618_credits_lang['t255'];
	$skjlstr=str_replace("{money}",$sk_money,$skjlstr);
	$skjlstr=str_replace("{zsbl}",$sk_zsbl,$skjlstr);
	$jfname=$_G['setting']['extcredits'][$sk_zsjfid]['title'];
	$skjlstr=str_replace("{jfname}",$jfname,$skjlstr);
	$skjlstr=str_replace("{tc}",$sk_tcbl,$skjlstr);
}

$zsblstr=$it618_brand_lang['s1061'];
$it618_zsbl='<input type="text" class="txt" style="width:50px;margin-left:3px;margin-right:3px;color:red" name="it618_zsbl" value="'.$it618_brand_moneyset['it618_zsbl'].'">%';
$it618_num='<input type="text" class="txt" style="width:50px;margin-left:3px;margin-right:3px;color:blue" name="it618_num" value="'.$it618_brand_moneyset['it618_num'].'">';
$it618_num1='<input type="text" class="txt" style="width:50px;margin-left:3px;margin-right:3px;color:blue" name="it618_num1" value="'.$it618_brand_moneyset['it618_num1'].'">';
$it618_zsbl1='<input type="text" class="txt" style="width:50px;margin-left:3px;margin-right:3px;color:blue" name="it618_zsbl1" value="'.$it618_brand_moneyset['it618_zsbl1'].'">%';
$it618_zsbl2='<input type="text" class="txt" style="width:50px;margin-left:3px;margin-right:3px;color:blue" name="it618_zsbl2" value="'.$it618_brand_moneyset['it618_zsbl2'].'">%';
$it618_zsbl3='<input type="text" class="txt" style="width:50px;margin-left:3px;margin-right:3px;color:#FF00FF" name="it618_zsbl3" value="'.$it618_brand_moneyset['it618_zsbl3'].'">%';

$zsblstr=str_replace("{zsbl}",$it618_zsbl,$zsblstr);
$zsblstr=str_replace("{num}",$it618_num,$zsblstr);
$zsblstr=str_replace("{num1}",$it618_num1,$zsblstr);
$zsblstr=str_replace("{zsbl1}",$it618_zsbl1,$zsblstr);
$zsblstr=str_replace("{zsbl2}",$it618_zsbl2,$zsblstr);
$zsblstr=str_replace("{zsbl3}",$it618_zsbl3,$zsblstr);

echo '
<tr><td><input type="checkbox" id="it618_isok" name="it618_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.it618_brand_getlang('s1062').'</label></td></tr>
<tr><td><input type="checkbox" id="it618_islogin" name="it618_islogin" value="1" style="vertical-align:middle" '.$it618_islogin_checked.'> <label for="it618_islogin">'.it618_brand_getlang('s1068').'</label></td></tr>
<tr><td>'.$it618_brand_lang['s1063'].'</td></tr>
<tr><td>
<table width="100%">
<tr><td width=158 style="border:none">
<img src='.$skurlcode.' width=158>
</td>
<td style="vertical-align:top;line-height:23px;border:none;padding-top:39px">
'.$it618_brand_lang['s1065'].'<font color="green">'.$tmpurl_sk.'</font>'.$it618_brand_lang['s1066'].'
'.$it618_brand_lang['s1067'].'
'.$skjlstr.'
</td>
</tr>
</table>
</td></tr>
<tr><td>'.$it618_brand_lang['s1060'].'</td></tr>
<tr><td>'.$zsblstr.'</td></tr>
<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_brand_getlang('s637').'" /></div></td></tr>
';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>