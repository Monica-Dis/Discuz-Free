<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_brand = $_G['cache']['plugin']['it618_brand'];
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';

$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($_GET['saleid']);
$it618_brand_goods=C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);

$pname=$it618_brand_goods['it618_name'];

if($_GET['ac']=='shop'){
	$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_sale['it618_shopid']);
	if($it618_brand_brand['it618_uid']==$_G['uid']){
		$isok=1;
	}
}else{
	if($it618_brand_sale['it618_uid']==$_G['uid']){
		$isok=1;
	}
}

if($isok==1){
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods_salekm')." WHERE it618_saleid=".intval($_GET['saleid']));
	while($it618_brand_goods_salekm = DB::fetch($query)) {
		$kmstr.=str_replace("{uid}",$_G['uid'],$it618_brand_goods_salekm['it618_code'])."\n";
		$n=$n+1;
	}
	if($kmstr!=''){
		$km_str='<span style="font-size:12px">'.it618_brand_getlang('s1248').$n.'</span><br>';
		if($_GET['wap']!=1){
			$km_str.='<textarea style="width:600px; height:400px; margin-top:8px; float:left; padding:3px" readonly="readonly">'.dhtmlspecialchars($kmstr).'</textarea>';
		}else{
			$km_str.='<textarea style="width:99%; height:300px; margin-top:8px " readonly="readonly">'.dhtmlspecialchars($kmstr).'</textarea>';
		}
	}
}

require_once DISCUZ_ROOT.'./source/plugin/it618_brand/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/'; /*d'.'is'.'m.ta'.'obao.com*/
include template('it618_brand:salekm');
?>