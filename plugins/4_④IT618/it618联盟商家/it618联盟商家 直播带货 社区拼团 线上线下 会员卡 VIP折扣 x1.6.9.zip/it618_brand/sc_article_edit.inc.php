<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_header.func.php';

$aid=intval($_GET['aid']);
if($it618_brand_article=C::t('#it618_brand#it618_brand_article')->fetch_by_id($aid)){
	if($it618_brand_article['it618_shopid']!=$ShopId){
		it618_cpmsg(it618_brand_getlang('s1213'), "", 'error');
	}
}else{
	it618_cpmsg(it618_brand_getlang('s549'), "", 'error');
}

if(submitcheck('it618submit')){
	
	if($_GET['it618_class_id']=='0'){
		it618_cpmsg(it618_brand_getlang('s110'), "plugin.php?id=it618_brand:sc_article_edit$adminsid&aid=$aid", 'error');
	}
	
	if($_GET['it618_name']==''){
		it618_cpmsg(it618_brand_getlang('s111'), "plugin.php?id=it618_brand:sc_article_edit$adminsid&aid=$aid", 'error');
	}

	C::t('#it618_brand#it618_brand_article')->update($aid,array(
		'it618_class_id' => $_GET['it618_class_id'],
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_seokeywords' => dhtmlspecialchars($_GET['it618_seokeywords']),
		'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription']),
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	));

	it618_cpmsg(it618_brand_getlang('s121'), "plugin.php?id=it618_brand:sc_article_edit$adminsid&aid=$aid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_brand:sc_article_edit$adminsid&aid=$aid");
showtableheaders(it618_brand_getlang('s122'),'it618_brand_article');

foreach(C::t('#it618_brand#it618_brand_article_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$it618_brand_article['it618_class_id'].'>','<option value='.$it618_brand_article['it618_class_id'].' selected="selected">',$tmp);

echo '
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_brand/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_brand/kindeditor/plugins/code/prettify.js"></script>
<script>
KindEditor.ready(function(K) {
	var editor1 = K.create(\'textarea[name="it618_message"]\', {
		cssPath : \'source/plugin/it618_brand/kindeditor/plugins/code/prettify.css\',
		uploadJson : \'source/plugin/it618_brand/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=930'.$oss.'\',
		fileManagerJson : \'source/plugin/it618_brand/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
		allowFileManager : true,
		filterMode:false
	});
	prettyPrint();
});
	
function checkvalue(){
	if(document.getElementById("it618_class_id").value=="0"){
		alert("'.it618_brand_getlang('s110').'");
		return false;
	}
	if(document.getElementById("it618_name").value==""){
		alert("'.it618_brand_getlang('s111').'");
		return false;
	}
}
</script>
	
<tr><td width=60>'.it618_brand_getlang('s114').'</td><td><select id="it618_class_id" name="it618_class_id"><option value="0">'.it618_brand_getlang('s104').'</option>'.$tmp1.'</select></td></tr>
<tr><td>'.it618_brand_getlang('s116').'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name" value="'.$it618_brand_article['it618_name'].'"></td></tr>
<tr><td>'.it618_brand_getlang('s117').'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_brand_article['it618_message'].'</textarea></td></tr>
<tr><td>'.it618_brand_getlang('s118').'</td><td><input type="text" class="txt" style="width:695px;margin-right:0" name="it618_seokeywords" value="'.$it618_brand_article[it618_seokeywords].'"></td></tr>
<tr><td>'.it618_brand_getlang('s119').'</td><td><textarea name="it618_seodescription" style="width:695px;height:50px;">'.$it618_brand_article[it618_seodescription].'</textarea></td></tr>
<tr><td colspan="2"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_brand_getlang('s120').'" /></div></td></tr>';

showtablefooter(); /*dism��taobao��com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_brand/sc_footer.func.php';
?>