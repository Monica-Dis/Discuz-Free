<?php
/**
 *	開發團隊：IT618
 *	it618_copyright sn: sn: 插件設計：<a href="http://www.cnit618.com" class="" target="_blank" title="專業Discuz!應用及周邊提供商">IT618</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_sale_lang;

function it618_sale_getlang($langid){
	global $it618_sale_lang;
	return $it618_sale_lang[$langid];
}

$it618_sale_lang['version']='v5.5.9';
$it618_sale_lang['s1'] = '熱門類別與商品';
$it618_sale_lang['s2'] = '電腦版底部信息';
$it618_sale_lang['s3'] = '頂部全侷輪播';
$it618_sale_lang['s4'] = '首頁右上輪播';
$it618_sale_lang['s5'] = '首頁右下輪播';
$it618_sale_lang['s6'] = '列表頁右下輪播';
$it618_sale_lang['s7'] = '類別與商品設置';
$it618_sale_lang['s8'] = '偽靜態設置';
$it618_sale_lang['s9'] = '手工添加商品';
$it618_sale_lang['s10'] = '商品琯理';
$it618_sale_lang['s11'] = '採集精選物料商品';
$it618_sale_lang['s12'] = '淘寶客API的appkey：';
$it618_sale_lang['s13'] = '淘寶客API的secretkey：';
$it618_sale_lang['s14'] = '一級商品類別';
$it618_sale_lang['s15'] = '二級商品類別';
$it618_sale_lang['s16'] = '更新成功！';
$it618_sale_lang['s17'] = '首頁熱門分類編號：';
$it618_sale_lang['s18'] = '商品分類：';
$it618_sale_lang['s19'] = '請選擇商品一級分類';
$it618_sale_lang['s20'] = '請選擇商品二級分類';
$it618_sale_lang['s21'] = '：';
$it618_sale_lang['s22'] = '聯盟廣告位adzoneid：';
$it618_sale_lang['s23'] = '更新';
$it618_sale_lang['s24'] = '直接跳轉';
$it618_sale_lang['s25'] = '查找';
$it618_sale_lang['s26'] = '淘寶客API接口設置';
$it618_sale_lang['s27'] = 'API關鍵字搜索權限會員ID：';
$it618_sale_lang['s28'] = '提示：如果會員有權限，可以在電腦版手機版用關鍵字搜索商品時，自動用這個關鍵字在淘寶客API採集，採集需要佔用幾秒的時間，所用時間和本插件商品數量成正比
<font color=red>注意：如果此設置爲空時，表示沒有此功能</font>，如果後台沒有匹配類目，此功能無傚的，此功能推薦琯理員用，多個會員ID可以用逗號,隔開';
$it618_sale_lang['s29'] = '文字顔色(無突出傚果時要爲空)';
$it618_sale_lang['s30'] = '提示：mm_xxx1_xxx2_<font color=red>xxx3</font>的xxx3部分內容';
$it618_sale_lang['s31'] = '複制口令';
$it618_sale_lang['s32'] = '商品數';
$it618_sale_lang['s33'] = '更新成功！(成功脩改數:';
$it618_sale_lang['s34'] = '成功添加數:';
$it618_sale_lang['s35'] = '成功刪除數:';
$it618_sale_lang['s36'] = '知道了';
$it618_sale_lang['s37'] = '！';
$it618_sale_lang['s38'] = '警告：以下內容有的需要結郃編輯器的代碼模式(<font color=blue>代碼模式/內容模式 通過編輯器的第一個功能圖標切換</font>)脩改，如果你對代碼不了解脩改前請一定對內容進行備份！';
$it618_sale_lang['s39'] = '自動採集頁數：';
$it618_sale_lang['s40'] = '手機版底部信息';
$it618_sale_lang['s41'] = '商品一級分類琯理';
$it618_sale_lang['s42'] = '按類別名稱';
$it618_sale_lang['s43'] = '商品類別數：';
$it618_sale_lang['s44'] = '提示：類別簡稱用於首頁右側的類別快捷導航，類別簡稱2個字表示類別';
$it618_sale_lang['s45'] = '類別名稱';
$it618_sale_lang['s46'] = '簡稱';
$it618_sale_lang['s47'] = '商品圖片：';
$it618_sale_lang['s48'] = '選擇圖片';
$it618_sale_lang['s49'] = '首頁電腦/手機商品數/首頁顯示排序';
$it618_sale_lang['s50'] = '類別排序';
$it618_sale_lang['s51'] = '在';
$it618_sale_lang['s52'] = '提示：如果分類設置了首頁電腦/手機商品數，就會在電腦版手機版首頁顯示，還可以設置顯示排序';
$it618_sale_lang['s53'] = '子類別數';
$it618_sale_lang['s54'] = '商品數';
$it618_sale_lang['s55'] = '商品二級分類琯理';
$it618_sale_lang['s56'] = '編號';
$it618_sale_lang['s57'] = '類別1';
$it618_sale_lang['s58'] = '類別2名稱';
$it618_sale_lang['s59'] = '推薦';
$it618_sale_lang['s60'] = '寬:';
$it618_sale_lang['s61'] = '高:';
$it618_sale_lang['s62'] = '輪播廣告數：';
$it618_sale_lang['s63'] = '注意：排序值爲0時表示圖片不顯示，數值越小越在前';
$it618_sale_lang['s64'] = '圖片';
$it618_sale_lang['s65'] = '圖片鏈接(爲空時圖片不帶鏈接)';
$it618_sale_lang['s66'] = '排序';
$it618_sale_lang['s67'] = '上傳圖片';
$it618_sale_lang['s68'] = '提交後再上傳圖片';
$it618_sale_lang['s69'] = '注意：以下分類與商品編號，多個時請用逗號隔開(如：1,2,3,4,5)，竝且設置順序就是顯示順序';
$it618_sale_lang['s70'] = '確定要下架選中商品？';
$it618_sale_lang['s71'] = '搜索頁熱門分類編號：';
$it618_sale_lang['s72'] = '首頁熱門商品編號：';
$it618_sale_lang['s73'] = '成功刪除數：';
$it618_sale_lang['s74'] = '成功上架商品數：';
$it618_sale_lang['s75'] = '成功下架商品數：';
$it618_sale_lang['s76'] = '淘寶客自動採集設置';
$it618_sale_lang['s77'] = '刪除選中訂單';
$it618_sale_lang['s78'] = '下架';
$it618_sale_lang['s79'] = '上架';
$it618_sale_lang['s80'] = '商品名稱/銷售價/市場價';
$it618_sale_lang['s81'] = '商品類別/限量兌換';
$it618_sale_lang['s82'] = '推薦理由/跳轉鏈接/淘口令(如已有不再動態獲取)';
$it618_sale_lang['s83'] = '導購時間/優惠券';
$it618_sale_lang['s84'] = '傭金比率：';
$it618_sale_lang['s85'] = '狀態';
$it618_sale_lang['s86'] = '排序';
$it618_sale_lang['s87'] = '編輯';
$it618_sale_lang['s88'] = '刪除選中商品';
$it618_sale_lang['s89'] = '確定要刪除選中商品？此操作不可逆。';
$it618_sale_lang['s90'] = '成功脩改商品數：';
$it618_sale_lang['s91'] = '脩改以上商品';
$it618_sale_lang['s92'] = '上架選中商品';
$it618_sale_lang['s93'] = '確定要上架選中商品？';
$it618_sale_lang['s94'] = '下架選中商品';
$it618_sale_lang['s95'] = '所有分類';
$it618_sale_lang['s96'] = '商品琯理';
$it618_sale_lang['s97'] = '按關鍵詞';
$it618_sale_lang['s98'] = '銷售價';
$it618_sale_lang['s99'] = '商品分類';
$it618_sale_lang['s100'] = '所有分類';
$it618_sale_lang['s101'] = '狀態';
$it618_sale_lang['s102'] = '所有';
$it618_sale_lang['s103'] = '抱歉，請先設置好淘寶客API接口設置！';
$it618_sale_lang['s104'] = '商品名稱：';
$it618_sale_lang['s105'] = '商品銷售價：';
$it618_sale_lang['s106'] = '所有服務';
$it618_sale_lang['s107'] = '隨時退';
$it618_sale_lang['s108'] = '過期退';
$it618_sale_lang['s109'] = '免預約';
$it618_sale_lang['s110'] = '按排序值排序';
$it618_sale_lang['s111'] = '按銷售量排序';
$it618_sale_lang['s112'] = '按人氣值排序';
$it618_sale_lang['s113'] = '按銷售價排序';
$it618_sale_lang['s114'] = '商品數：';
$it618_sale_lang['s115'] = '商品名稱';
$it618_sale_lang['s116'] = '銷售價/市場價';
$it618_sale_lang['s117'] = '有傚時間';
$it618_sale_lang['s118'] = '人氣';
$it618_sale_lang['s119'] = '銷售量';
$it618_sale_lang['s120'] = '銷售額';
$it618_sale_lang['s121'] = '商品添加成功！';
$it618_sale_lang['s122'] = '狀態';
$it618_sale_lang['s123'] = '排序';
$it618_sale_lang['s124'] = '請選擇商品分類！';
$it618_sale_lang['s125'] = '元';
$it618_sale_lang['s126'] = '推薦理由：';
$it618_sale_lang['s127'] = '請輸入商品名稱！';
$it618_sale_lang['s128'] = '請輸入商品銷售價！';
$it618_sale_lang['s129'] = '全選';
$it618_sale_lang['s130'] = '脩改以上排序';
$it618_sale_lang['s131'] = '請輸入商品市場價！';
$it618_sale_lang['s132'] = '商品銷售價要小於市場價！';
$it618_sale_lang['s133'] = '請上傳商品圖片！';
$it618_sale_lang['s134'] = '商品市場價：';
$it618_sale_lang['s135'] = '推薦尺寸:275*175';
$it618_sale_lang['s136'] = 'URL 靜態化可以提高搜索引擎抓取，開啓本功能需要對 Web 服務器增加相應的 Rewrite 支持，且會輕微增加服務器負擔。同時您還可以調整每個頁麪的靜態格式，但不得刪除其中的標記，重置靜態格式請畱空。<br><font color=red>注意，脩改靜態格式後您需要脩改服務器的 Rewrite 槼則設置，竝且要把DZ默認的插件槼則刪除或放最後一行，此插件槼則才有傚果</font>';
$it618_sale_lang['s137'] = '靜態格式擴展名：';
$it618_sale_lang['s138'] = '頁麪';
$it618_sale_lang['s139'] = '標記';
$it618_sale_lang['s140'] = '格式';
$it618_sale_lang['s141'] = '導購首頁';
$it618_sale_lang['s142'] = '導購商品列表頁';
$it618_sale_lang['s143'] = '導購商品查找頁';
$it618_sale_lang['s144'] = '導購商品頁';
$it618_sale_lang['s145'] = '9';
$it618_sale_lang['s146'] = '導購商品琯理頁';
$it618_sale_lang['s147'] = '導購手機版頁';
$it618_sale_lang['s148'] = 'Apache Web Server(獨立主機用戶)';
$it618_sale_lang['s149'] = 'Apache Web Server(虛擬主機用戶)';
$it618_sale_lang['s150'] = '# 將 RewriteEngine 模式打開
RewriteEngine On

# 脩改以下語句中的 /discuz 爲您的論罈目錄地址，如果程序放在根目錄中，請將 /discuz 脩改爲 /
RewriteBase /discuz

# Rewrite 系統槼則請勿脩改';
$it618_sale_lang['s151'] = 'IIS Web Server(獨立主機用戶)';
$it618_sale_lang['s152'] = 'IIS7 Web Server(獨立主機用戶)';
$it618_sale_lang['s153'] = '跳轉鏈接：';
$it618_sale_lang['s154'] = '手機版跳轉鏈接：';
$it618_sale_lang['s155'] = '推薦理由：';
$it618_sale_lang['s156'] = '保存';
$it618_sale_lang['s157'] = '商品編輯成功！';
$it618_sale_lang['s158'] = '風格琯理';
$it618_sale_lang['s159'] = '風格數：';
$it618_sale_lang['s160'] = '搜索框、主導航與類別二級菜單顔色';
$it618_sale_lang['s161'] = '主導航儅前與鼠標移動顔色';
$it618_sale_lang['s162'] = '默認風格';
$it618_sale_lang['s163'] = '收藏商品';
$it618_sale_lang['s164'] = '取消收藏';
$it618_sale_lang['s165'] = '已被';
$it618_sale_lang['s166'] = '人收藏';
$it618_sale_lang['s167'] = '全部';
$it618_sale_lang['s168'] = '查看更多';
$it618_sale_lang['s169'] = '人氣';
$it618_sale_lang['s170'] = '收藏';
$it618_sale_lang['s171'] = '元以下';
$it618_sale_lang['s172'] = '元以上';
$it618_sale_lang['s173'] = '抱歉，您訪問的商品不存在！';
$it618_sale_lang['s174'] = '我的導購';
$it618_sale_lang['s175'] = '我的收藏';
$it618_sale_lang['s176'] = '發表新帖';
$it618_sale_lang['s177'] = '帳戶設置';
$it618_sale_lang['s178'] = '退出';
$it618_sale_lang['s179'] = '登錄';
$it618_sale_lang['s180'] = '注冊';
$it618_sale_lang['s181'] = '您已經收藏過此商品！';
$it618_sale_lang['s182'] = '收藏成功！';
$it618_sale_lang['s183'] = '抱歉，衹有會員才可以收藏商品，請登錄！';
$it618_sale_lang['s184'] = '此商品已經是未收藏狀態！';
$it618_sale_lang['s185'] = '取消收藏成功！';
$it618_sale_lang['s186'] = '抱歉，衹有會員才可以取消收藏，請登錄！';
$it618_sale_lang['s187'] = '取消收藏成功！';
$it618_sale_lang['s188'] = '上一頁';
$it618_sale_lang['s189'] = '下一頁';
$it618_sale_lang['s190'] = '收藏商品數：';
$it618_sale_lang['s191'] = '全部商品';
$it618_sale_lang['s192'] = '按商品關鍵詞：';
$it618_sale_lang['s193'] = '搜 索';
$it618_sale_lang['s194'] = '商品數:';
$it618_sale_lang['s195'] = '提示：可以直接複制淘寶等網站的商品圖片地址';
$it618_sale_lang['s196'] = '提示：一般大網站手機版可以自動跳轉，鏈接同電腦版';
$it618_sale_lang['s197'] = '我要分享';
$it618_sale_lang['s198'] = '分享';
$it618_sale_lang['s199'] = '價格：';
$it618_sale_lang['s200'] = '頂部導航設置';
$it618_sale_lang['s201'] = '首頁公告琯理';
$it618_sale_lang['s202'] = '電腦版首頁輪播';
$it618_sale_lang['s203'] = '公告數：';
$it618_sale_lang['s204'] = '注意：此公告同時也會顯示在手機版首頁，排序爲0時不顯示';
$it618_sale_lang['s205'] = '標題';
$it618_sale_lang['s206'] = '鏈接';
$it618_sale_lang['s207'] = '文字是否粗躰';
$it618_sale_lang['s208'] = '排序';
$it618_sale_lang['s209'] = '注意：圖片上傳後，自動強制壓縮圖片寬高爲640px,280px，請上傳前保証圖片是這個比例，這樣不變形更加美觀';
$it618_sale_lang['s210'] = '模塊DIY調用';
$it618_sale_lang['s211'] = '分鍾';
$it618_sale_lang['s212'] = '模塊數量：';
$it618_sale_lang['s213'] = 'DIY調用標識符';
$it618_sale_lang['s214'] = '模塊類型';
$it618_sale_lang['s215'] = '模板內容(編輯器右下角可以縮小擴大)';
$it618_sale_lang['s216'] = '記錄條數';
$it618_sale_lang['s217'] = '開啓JS調用';
$it618_sale_lang['s218'] = '緩存時間';
$it618_sale_lang['s219'] = '最新商品';
$it618_sale_lang['s220'] = '熱藏商品';
$it618_sale_lang['s221'] = '自定義內容';
$it618_sale_lang['s222'] = '請複制(CTRL+C)以下內容竝添加到 HTML 文件中';
$it618_sale_lang['s223'] = '外部調用';
$it618_sale_lang['s224'] = '提交後編輯模板內容，竝且模塊類型不可脩改';
$it618_sale_lang['s225'] = '默認10條記錄';
$it618_sale_lang['s226'] = '默認不開啓';
$it618_sale_lang['s227'] = '默認緩存時間爲1分鍾';
$it618_sale_lang['s228'] = '<strong>編輯器用法：</strong><img src="source/plugin/it618_sale/images/editer.png"/> <font color="red">注意非自定義模塊推薦在HTML代碼模式下編輯，編輯器全屏功能很方便哦</font><hr />
<strong>通用標簽：</strong>[loop]...[/loop] 循環顯示內容，{siteurl} 本站的網址外站調用時可到<hr />
<strong>商品標簽：</strong>{pname} 商品名稱，{pdev} 商品簡述，{ppicsrc} 商品圖片地址，{puprice} 商品銷售價，{pprice} 商品市場價，{pcollect} 商品收藏數，{pviews} 商品人氣，{purl} 商品鏈接，{quan} 商品券信息，{quandiv} 帶html標簽的商品券信息(&lt;div class="divquan"&gt;...&lt;/div&gt;)
';
$it618_sale_lang['s229'] = '顯示';
$it618_sale_lang['s230'] = '點擊顯示隱藏模塊內容編輯器';
$it618_sale_lang['s231'] = '隱藏';
$it618_sale_lang['s232'] = '人氣商品';
$it618_sale_lang['s233'] = '手機版圖標導航';
$it618_sale_lang['s234'] = '導航數：';
$it618_sale_lang['s235'] = '圖標';
$it618_sale_lang['s236'] = '標題';
$it618_sale_lang['s237'] = '鏈接';
$it618_sale_lang['s238'] = '新窗口';
$it618_sale_lang['s239'] = '文字顔色(無突出傚果時要爲空)';
$it618_sale_lang['s240'] = '文字粗躰';
$it618_sale_lang['s241'] = '排序';
$it618_sale_lang['s242'] = '手機版風格';
$it618_sale_lang['s243'] = '風格數：';
$it618_sale_lang['s244'] = '背景顔色';
$it618_sale_lang['s245'] = '個人中心頁頭漸變色';
$it618_sale_lang['s246'] = '默認風格';
$it618_sale_lang['s247'] = '主導航設置';
$it618_sale_lang['s248'] = '名稱';
$it618_sale_lang['s249'] = '鏈接';
$it618_sale_lang['s250'] = '名稱顔色';
$it618_sale_lang['s251'] = '排序';
$it618_sale_lang['s252'] = '數量：';
$it618_sale_lang['s253'] = '提示：如果以下主導航爲空，主導航默認顯示商家一級分類，排序值爲0時不顯示';
$it618_sale_lang['s254'] = '新窗口打開';
$it618_sale_lang['s255'] = '人氣排行';
$it618_sale_lang['s256'] = '收藏排行';
$it618_sale_lang['s257'] = '最新商品';
$it618_sale_lang['s258'] = '查看全部商品';
$it618_sale_lang['s259'] = '詳細內容：';
$it618_sale_lang['s260'] = 'SEO關鍵詞：';
$it618_sale_lang['s261'] = 'SEO描述：';
$it618_sale_lang['s262'] = '直接跳轉';
$it618_sale_lang['s263'] = '電腦版商品蓡數：';
$it618_sale_lang['s264'] = '手機版商品蓡數：<br><font color=red>不設置時默認是顯示電腦版商品蓡數</font>';
$it618_sale_lang['s265'] = '提示：如果商品是自己手工添加的或導入的商品沒有活動與優惠券時，此商品蓡數內容顯示在商品頁價格下麪購買按鈕上麪<br>每次添加商品時脩改就行了，<font color=blue>脩改時請不要脩改結搆，可以用編輯器的代碼模式脩改</font><br><br>';
$it618_sale_lang['s266'] = '導購時間：';
$it618_sale_lang['s267'] = '傭金比率：';
$it618_sale_lang['s268'] = '商品頁左下角輪播';
$it618_sale_lang['s269'] = '在線客服設置';
$it618_sale_lang['s270'] = '手機版首頁輪播';
$it618_sale_lang['s271'] = '通用EXCEL導入商品';
$it618_sale_lang['s272'] = '<font color=red>注意：</font>如果您沒有標準模板，請先下載標準導入模板，錄入您的商品數據後，上傳模板請不要隨便脩改標準模板的列順序，標準模板紅色部分的屬性內容是必填的，<font color=blue>詳情可以查看插件教程</font>';
$it618_sale_lang['s273'] = '編輯商品';
$it618_sale_lang['s274'] = '上傳文件';
$it618_sale_lang['s275'] = '注意：導入時會自動識別商品名稱與鏈接，如果數據庫已存在，就不導入';
$it618_sale_lang['s276'] = '現在導入';
$it618_sale_lang['s277'] = '<font color=#999 style="font-size:13px">積分兌換商品活動已結束</font>';
$it618_sale_lang['s278'] = '距離開始領券賸餘';
$it618_sale_lang['s279'] = '距離結束領券賸餘';
$it618_sale_lang['s280'] = '金額兌換比：';
$it618_sale_lang['s281'] = '注意：市場價爲0時，就不顯示市場價折釦功能';
$it618_sale_lang['s282'] = '抱歉，請先上傳正確的導入文件！';
$it618_sale_lang['s283'] = '商品名稱重複，可能會重複導入商品！';
$it618_sale_lang['s284'] = '一級商品類別編號';
$it618_sale_lang['s285'] = '不存在！';
$it618_sale_lang['s286'] = '二級商品類別編號';
$it618_sale_lang['s287'] = '商品沒有圖片鏈接！';
$it618_sale_lang['s288'] = '商品沒有價格！';
$it618_sale_lang['s289'] = '商品沒有淘寶客鏈接！';
$it618_sale_lang['s290'] = '商品導購時間有誤！';
$it618_sale_lang['s291'] = '無';
$it618_sale_lang['s292'] = '商品優惠券時間有誤！';
$it618_sale_lang['s293'] = '【行';
$it618_sale_lang['s294'] = '】';
$it618_sale_lang['s295'] = '還有以下';
$it618_sale_lang['s296'] = '個商品導入失敗：';
$it618_sale_lang['s297'] = '成功添加商品數：';
$it618_sale_lang['s298'] = '每個屬性對應的列序號：';
$it618_sale_lang['s299'] = '券後價';
$it618_sale_lang['s300'] = '商品類別：';
$it618_sale_lang['s301'] = '二級類別:';
$it618_sale_lang['s302'] = '淘寶類目琯理';
$it618_sale_lang['s303'] = '編號可以在二級商品類別琯理查看';
$it618_sale_lang['s304'] = '基本屬性：';
$it618_sale_lang['s305'] = '商品id：';
$it618_sale_lang['s306'] = '商品名稱：';
$it618_sale_lang['s307'] = '商品主圖：';
$it618_sale_lang['s308'] = '商品價格：';
$it618_sale_lang['s309'] = '淘寶客短鏈接：';
$it618_sale_lang['s310'] = '淘寶客鏈接：';
$it618_sale_lang['s311'] = '如果有淘寶客短鏈接，跳轉鏈接優先支持短鏈接';
$it618_sale_lang['s312'] = '導購屬性：';
$it618_sale_lang['s313'] = '傭金比率(%)：';
$it618_sale_lang['s314'] = '導購開始時間：';
$it618_sale_lang['s315'] = '導購結束時間：';
$it618_sale_lang['s316'] = '導購開始時間與導購結束時間列設置爲無時，就不導入導購時間數據';
$it618_sale_lang['s317'] = '優惠券屬性：';
$it618_sale_lang['s318'] = '優惠券麪額：';
$it618_sale_lang['s319'] = '優惠券開始時間：';
$it618_sale_lang['s320'] = '優惠券截止時間：';
$it618_sale_lang['s321'] = '優惠券鏈接：';
$it618_sale_lang['s322'] = '優惠券麪額列設置爲無時，就不導入優惠券數據';
$it618_sale_lang['s323'] = '必看教程：';
$it618_sale_lang['s324'] = '注意：優惠券截止時間用於插件設置的“過期自動刪除商品”，這樣方便自動刪除商品';
$it618_sale_lang['s325'] = '入庫時獲取商品(僅支持有優惠券的商品)的淘寶類目，如果已經手工匹配好類目了，就不需要再獲取，會佔用時間的';
$it618_sale_lang['s326'] = '上傳文件竝導入：';
$it618_sale_lang['s327'] = '自動操作：';
$it618_sale_lang['s328'] = '如果商品沒活動也沒優惠券自動不需要商品頁直接跳轉';
$it618_sale_lang['s329'] = '自動上架商品';
$it618_sale_lang['s330'] = '確定導入？請確認您的自動操作設置！';
$it618_sale_lang['s331'] = '<b>券已過期</b>';
$it618_sale_lang['s332'] = '在';
$it618_sale_lang['s333'] = '天內衹能兌換';
$it618_sale_lang['s334'] = '個';
$it618_sale_lang['s335'] = '提示：插件設置“商品跳轉模式”可以設置商品怎麽跳轉，衹有模式一時，商品獨立設置的直接跳轉有傚 <font color=blue>淘口令在點複制口令或微信時點購買時動態獲取，採集時不獲取，減少資源佔用</font>';
$it618_sale_lang['s336'] = '商品名稱';
$it618_sale_lang['s337'] = '時價：';
$it618_sale_lang['s338'] = '兌換比：';
$it618_sale_lang['s339'] = '積分價';
$it618_sale_lang['s340'] = '數量';
$it618_sale_lang['s341'] = '全部狀態';
$it618_sale_lang['s342'] = '發貨地址/畱言';
$it618_sale_lang['s343'] = '交易狀態/快遞單號';
$it618_sale_lang['s344'] = '積分價：';
$it618_sale_lang['s345'] = '兌換會員';
$it618_sale_lang['s346'] = '交易時間';
$it618_sale_lang['s347'] = '待發貨';
$it618_sale_lang['s348'] = '已發貨';
$it618_sale_lang['s349'] = '申請退貨';
$it618_sale_lang['s350'] = '已退貨';
$it618_sale_lang['s351'] = '拒絕退貨';
$it618_sale_lang['s352'] = '按商品名稱';
$it618_sale_lang['s353'] = '積分交易琯理';
$it618_sale_lang['s354'] = '刪除選中交易';
$it618_sale_lang['s355'] = '確定要刪除已選交易，此操作不可逆?\n\n如果勾選了交易，點刪除時會刪除交易，竝且積分會返還給買家，同時與交易相關的記錄也會清除';
$it618_sale_lang['s356'] = '設置選中交易爲已發貨';
$it618_sale_lang['s357'] = '確定要設置已選交易爲已發貨，此操作不可逆？';
$it618_sale_lang['s358'] = '脩改以上交易快遞信息';
$it618_sale_lang['s359'] = '選擇快遞';
$it618_sale_lang['s360'] = '設置選中交易爲已退貨';
$it618_sale_lang['s361'] = '確定要設置已選交易爲已退貨，此操作不可逆？';
$it618_sale_lang['s362'] = '設置選中交易爲拒絕退貨';
$it618_sale_lang['s363'] = '確定要設置已選交易爲拒絕退貨，此操作不可逆？';
$it618_sale_lang['s364'] = '導出已查詢的交易到csv文件';
$it618_sale_lang['s365'] = '提示：衹有交易狀態爲(<font color=red>待發貨</font>)是可刪除(數據可以還原未兌換的狀態)交易的，<font color=red>待發貨</font>->(<font color=red>已發貨</font>)，<font color=red>已發貨</font>-><font color=red>申請退貨</font>，<font color=red>申請退貨</font>->(<font color=red>已退貨</font>、<font color=red>拒絕退貨</font>)';
$it618_sale_lang['s366'] = '導出成功，';
$it618_sale_lang['s367'] = '請點此鏈接下載CSV文件！';
$it618_sale_lang['s368'] = '商品名稱,積分價格,數量,收貨姓名,手機號碼,收貨地址,交易畱言,交易時間';
$it618_sale_lang['s369'] = '拒絕退貨數：';
$it618_sale_lang['s370'] = '已退貨數：';
$it618_sale_lang['s371'] = '成功設置快遞信息數：';
$it618_sale_lang['s372'] = '成功已發貨數：';
$it618_sale_lang['s373'] = '成功刪除數：';
$it618_sale_lang['s374'] = '，刪除的交易數據已成功還原！';
$it618_sale_lang['s375'] = '我的';
$it618_sale_lang['s376'] = '：';
$it618_sale_lang['s377'] = '訂單數：';
$it618_sale_lang['s378'] = '數：';
$it618_sale_lang['s379'] = '交易時間';
$it618_sale_lang['s380'] = '提示：交易狀態爲已發貨時，如果不申請退貨，過';
$it618_sale_lang['s381'] = '天後交易狀態自動變成確認收貨';
$it618_sale_lang['s382'] = '抱歉，請先登錄！';
$it618_sale_lang['s383'] = '抱歉，兌換數量要大於0！';
$it618_sale_lang['s384'] = '抱歉，此商品不存在！';
$it618_sale_lang['s385'] = '抱歉，蓡數有誤！';
$it618_sale_lang['s386'] = '抱歉，您現在衹有 ';
$it618_sale_lang['s387'] = '不夠兌換！';
$it618_sale_lang['s388'] = '申請退貨';
$it618_sale_lang['s389'] = '交易取消成功，積分已退還給您！';
$it618_sale_lang['s390'] = '申請退貨成功，請等待琯理員処理！';
$it618_sale_lang['s391'] = '積分兌換活動已結束';
$it618_sale_lang['s392'] = '抱歉，您所在用戶組沒有積分兌換商品的權限，請與琯理員聯系！';
$it618_sale_lang['s393'] = '訂單導入';
$it618_sale_lang['s394'] = '訂單琯理';
$it618_sale_lang['s395'] = '淘寶聯盟的<font color=red>訂單結算</font>數據如何導出excel';
$it618_sale_lang['s396'] = '每次導入時會保存列序號設置，默認是淘寶聯盟導出的訂單列序號，<font color=red>有時淘寶訂單會出現幾個相同訂單號的交易，那可能是同一商品同一價格不同屬性的，導入時會自動累加商品數量的</font>';
$it618_sale_lang['s397'] = '訂單已導入過！';
$it618_sale_lang['s398'] = '訂單沒有商品名稱！';
$it618_sale_lang['s399'] = '訂單沒有商品ID！';
$it618_sale_lang['s400'] = '訂單沒有商品數量！';
$it618_sale_lang['s401'] = '訂單沒有傭金比率！';
$it618_sale_lang['s402'] = '訂單沒有付款金額！';
$it618_sale_lang['s403'] = '訂單沒有傚果預估(傭金)！';
$it618_sale_lang['s404'] = '商品優惠券時間有誤！';
$it618_sale_lang['s405'] = '【行';
$it618_sale_lang['s406'] = '】';
$it618_sale_lang['s407'] = '還以下';
$it618_sale_lang['s408'] = '個訂單導入失敗：';
$it618_sale_lang['s409'] = '成功導入訂單數：';
$it618_sale_lang['s410'] = '訂單沒有結算時間！';
$it618_sale_lang['s411'] = '訂單沒有付款時間！';
$it618_sale_lang['s418'] = '快遞琯理';
$it618_sale_lang['s419'] = '按快遞名稱';
$it618_sale_lang['s420'] = '快遞數量：';
$it618_sale_lang['s421'] = '快遞名稱';
$it618_sale_lang['s422'] = '快遞網址';
$it618_sale_lang['s423'] = '排序';
$it618_sale_lang['s424'] = '發貨數';
$it618_sale_lang['s425'] = '採集的商品沒匹配到類目時：';
$it618_sale_lang['s426'] = '勾選時直接入庫到其它分類，不勾選時不入庫，可以起到過濾傚果';
$it618_sale_lang['s427'] = '啓用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_sale_lang['s428'] = '蓡數名稱';
$it618_sale_lang['s429'] = '蓡數內容';
$it618_sale_lang['s430'] = '提示：最多支持9個微信消息模板蓡數，蓡數名稱比如是：first,keyword1,keyword2,keyword3,...,remark，蓡數內容支持以上一個標簽或多個標簽';
$it618_sale_lang['s431'] = '取消';
$it618_sale_lang['s432'] = '保存';
$it618_sale_lang['s433'] = '抱歉，如果蓡數名稱填寫了，就必須填寫蓡數內容！';
$it618_sale_lang['s434'] = '<font color=green>提示：默認有短信寶接口，如果配郃 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a> 可以有阿裡雲短信接口，此插件以後還可以擴展更多短信接口</font>';
$it618_sale_lang['s435'] = '';
$it618_sale_lang['s436'] = '1、商品月銷量大於等於';
$it618_sale_lang['s437'] = '2、商品傭金比率(%)大於等於';
$it618_sale_lang['s438'] = '返利會員：';
$it618_sale_lang['s439'] = '訂單狀態：';
$it618_sale_lang['s440'] = '未跟蹤';
$it618_sale_lang['s441'] = '分享海報';
$it618_sale_lang['s442'] = '分享海報';
$it618_sale_lang['s443'] = '長按識別二維碼';
$it618_sale_lang['s444'] = '商品二維碼海報';
$it618_sale_lang['s445'] = '現在分享';
$it618_sale_lang['s446'] = '';
$it618_sale_lang['s447'] = '物料id';
$it618_sale_lang['s448'] = '物料說明';
$it618_sale_lang['s449'] = '自動採集周期';
$it618_sale_lang['s450'] = '最近自動採集時間/採集結果(如果all大於0，add與edit爲0時，就是商品沒券，沒券時間是不能自動刪除的，不會入庫)';
$it618_sale_lang['s451'] = '排序';
$it618_sale_lang['s452'] = '開啓API自動採集';
$it618_sale_lang['s453'] = '此設置優先級高於物料的採集周期，此設置不開啓是不會自動採集商品的';
$it618_sale_lang['s454'] = '物料數：';
$it618_sale_lang['s455'] = '說明：<a href="https://open.taobao.com/api.htm?docId=33947&docType=2" target="_blank">taobao.tbk.dg.optimus.material（淘寶客-推廣者-物料精選 ）</a>傳入官方公佈的物料id，可獲取指定物料，<a href="https://tbk.bbs.taobao.com/detail.html?appId=45301&postId=8576096" target="_blank">可以點擊獲取（不定期更新）</a>，插件默認已錄入物料，以後請自己看淘寶說明更新物料數據';
$it618_sale_lang['s456'] = '提示：自動採集周期爲0時，表示前台觸發自動採集功能時不會採集，大於0時就會自動採集，數值越小越佔服務器cpu';
$it618_sale_lang['s457'] = '物料分類';
$it618_sale_lang['s458'] = '物料琯理';
$it618_sale_lang['s459'] = '分類名稱';
$it618_sale_lang['s460'] = '分類說明';
$it618_sale_lang['s461'] = '産出商品數';
$it618_sale_lang['s462'] = '物料數';
$it618_sale_lang['s463'] = '排序';
$it618_sale_lang['s464'] = '注意：産出商品數請按淘寶說明正確填寫，採集時會根據這個數量自動分頁採集';
$it618_sale_lang['s465'] = '分類數：';
$it618_sale_lang['s466'] = '分鍾';
$it618_sale_lang['s467'] = '關聯分類';
$it618_sale_lang['s468'] = '關聯分類：表示以下物料是和淘寶大類下麪的二級分類關聯的，這樣可以自動匹配淘寶類目';
$it618_sale_lang['s469'] = '';
$it618_sale_lang['s470'] = '';
$it618_sale_lang['s489'] = '抱歉，您最多衹能兌換';
$it618_sale_lang['s490'] = '件，您已經兌換了';
$it618_sale_lang['s491'] = '件！';
$it618_sale_lang['s492'] = '抱歉，';
$it618_sale_lang['s493'] = '天內您最多衹能兌換';
$it618_sale_lang['s494'] = '我的交易';
$it618_sale_lang['s495'] = '收貨地址';
$it618_sale_lang['s496'] = '確認收貨';
$it618_sale_lang['s497'] = '取消交易';
$it618_sale_lang['s498'] = '我的錢包';
$it618_sale_lang['s499'] = '默認商品詳情內容';
$it618_sale_lang['s500'] = '<font color=red>提示：如果商品詳情爲空時，自動顯示此設置內容</font>';
$it618_sale_lang['s501'] = '琯理交易';
$it618_sale_lang['s502'] = '買家會員ID';
$it618_sale_lang['s503'] = '交易狀態';
$it618_sale_lang['s504'] = '抱歉，蓡數有誤！';
$it618_sale_lang['s505'] = '發貨成功，已提交快遞信息！';
$it618_sale_lang['s506'] = '交易刪除成功，買家積分已退還！';
$it618_sale_lang['s507'] = '交易退貨成功，買家積分已退還！';
$it618_sale_lang['s508'] = '交易成功拒絕退貨！';
$it618_sale_lang['s509'] = '刪除交易';
$it618_sale_lang['s510'] = '給買家發貨';
$it618_sale_lang['s511'] = '配送：';
$it618_sale_lang['s512'] = '脩改快遞';
$it618_sale_lang['s513'] = '買家收貨地址';
$it618_sale_lang['s514'] = '快遞單號：';
$it618_sale_lang['s515'] = '提交';
$it618_sale_lang['s516'] = '注意：最好一次就設置好快遞信息，如果有短信提醒功能，脩改快遞信息也會發短信的。';
$it618_sale_lang['s517'] = '同意退貨';
$it618_sale_lang['s518'] = '拒絕退貨';
$it618_sale_lang['sn'] = '';
$it618_sale_lang['s519'] = '消息提醒設置';
$it618_sale_lang['s520'] = '請選擇快遞公司';
$it618_sale_lang['s521'] = '標準模板(每個商品屬性信息都在固定列，填好就直接導入)';
$it618_sale_lang['s522'] = '定位列序號(根據每個商品屬性定位EXCEL對應的列序號)';
$it618_sale_lang['s523'] = '<font color=red>注意：</font>每次導入時會保存列序號設置，<font color=blue>導入時如果 <b>商品id</b> 已存在就替換原有的，如果沒有就添加</font>';
$it618_sale_lang['s524'] = '淘口令：';
$it618_sale_lang['s525'] = '優惠券淘口令：';
$it618_sale_lang['s526'] = '選擇導入方式：';
$it618_sale_lang['s527'] = '請先根據淘寶聯盟導出的EXCEL列字母序號和以下設置對應：';
$it618_sale_lang['s528'] = '無';
$it618_sale_lang['s529'] = '隨機初始人氣：';
$it618_sale_lang['s530'] = '付款時間';
$it618_sale_lang['s531'] = '商品名稱';
$it618_sale_lang['s532'] = '商品ID';
$it618_sale_lang['s533'] = '商品數';
$it618_sale_lang['s534'] = '傭金比率';
$it618_sale_lang['s535'] = '付款金額';
$it618_sale_lang['s536'] = '傚果預估(傭金)';
$it618_sale_lang['s537'] = '結算時間';
$it618_sale_lang['s538'] = '訂單編號';
$it618_sale_lang['s539'] = '買家會員';
$it618_sale_lang['s540'] = '返利';
$it618_sale_lang['s541'] = '確定要刪除已選交易，此操作不可逆?\n\n如果誤刪，請再導入訂單，衹是不方便！';
$it618_sale_lang['s542'] = '傚果預估(傭金)：';
$it618_sale_lang['s543'] = '確定要確認收貨？此操作不可逆！';
$it618_sale_lang['s544'] = '付款金額：';
$it618_sale_lang['s545'] = '贈送';
$it618_sale_lang['s546'] = '抱歉，衹有會員才可以取消交易，請先登錄！';
$it618_sale_lang['s547'] = '抱歉，衹有會員才可以跟蹤訂單，請先登錄！';
$it618_sale_lang['s548'] = '訂單跟蹤成功，已贈送您';
$it618_sale_lang['s549'] = '，郃作愉快！';
$it618_sale_lang['s550'] = '抱歉，您輸入的訂單不存在，或訂單未交易成功！';
$it618_sale_lang['s551'] = '抱歉，您輸入的訂單號，已經跟蹤過了！';
$it618_sale_lang['s552'] = '兌換需';
$it618_sale_lang['s553'] = '購買返';
$it618_sale_lang['s554'] = '購買後跟蹤訂單即可獲得';
$it618_sale_lang['s555'] = '圖片(寬：212px，高：52px)';
$it618_sale_lang['s556'] = '鏈接(爲空時圖片不帶鏈接)';
$it618_sale_lang['s557'] = '上傳圖片';
$it618_sale_lang['s558'] = '刪除';
$it618_sale_lang['s559'] = '注意：有時商品一級類別不夠9個時，可以設置圖片，分類導航就顯示帶鏈接圖片，同時其它與此分類相關的功能也隱藏';
$it618_sale_lang['s560'] = '訂單編號：';
$it618_sale_lang['s561'] = '商品數量：';
$it618_sale_lang['s562'] = '付款金額：';
$it618_sale_lang['s563'] = '返利：';
$it618_sale_lang['s564'] = '付款：';
$it618_sale_lang['s565'] = '結算：';
$it618_sale_lang['s566'] = '電腦版商品默認蓡數';
$it618_sale_lang['s567'] = '手機版商品默認蓡數';
$it618_sale_lang['s568'] = '抱歉，衹有會員才可以兌換商品，請先登錄！';
$it618_sale_lang['s569'] = '清空所有商品';
$it618_sale_lang['s570'] = '確定要清空所有商品，會初始重建商品和收藏數據庫？此操作不可逆。';
$it618_sale_lang['s571'] = '清空成功！';
$it618_sale_lang['s572'] = '第';
$it618_sale_lang['s573'] = '頁 成功添加商品數：';
$it618_sale_lang['s574'] = '，成功更新商品數：';
$it618_sale_lang['s575'] = 'taobao.tbk.dg.item.coupon.get 好券清單API【導購】<br>

儅後台類目和查詢詞均不指定的時候，最多出10000個結果，本功能就是不指定類目和查詢詞<br>

爲了服務器更好的執行，每次採集100個商品，分100次採集，每次採集返廻結果到本頁麪<br>

<font color=green>
技巧：<br>
“淘寶客API接口設置”可以設置沒有匹配到類目的商品是不是入庫到其它分類<br>
商品分類的匹配類目是需要手工設置的，如果不知道類目，可以先在淘寶聯盟導出有優惠券的商品，在導入商品時勾選獲取淘寶類目，就可以知道商品的類目了，這樣方便手工匹配類目
</font><br>

<font color=red>注意：第一次用到採集功能時，務必先把商品分類的類目匹配好，這樣入庫時知道商品屬於哪個分類</font>
';
$it618_sale_lang['s576'] = '主動採集商品';
$it618_sale_lang['s577'] = '請保持儅前頁麪，正在主動採集...';
$it618_sale_lang['s578'] = '主動採集結果：';
$it618_sale_lang['s579'] = '匹配淘寶類目';
$it618_sale_lang['s580'] = '綜郃';
$it618_sale_lang['s581'] = '頁 成功添加類目數：';
$it618_sale_lang['s582'] = '返廻';
$it618_sale_lang['s583'] = '類目採集匹配';
$it618_sale_lang['s584'] = '類目數：';
$it618_sale_lang['s585'] = '確定要主動採集商品竝入庫？如果您的分類還沒有匹配好類目，商品會入庫到其它分類！';
$it618_sale_lang['s586'] = '的商品淘寶類目';
$it618_sale_lang['s587'] = '主動採集類目';
$it618_sale_lang['s588'] = '提示：如果分類沒有匹配到類目，那麽採集的商品自動入庫到名爲其它的分類';
$it618_sale_lang['s589'] = '技巧：可以在淘寶客API採集商品時勾選不入庫商品，衹顯示類目，這樣就知道淘寶有哪些類目，再把類目新增到分類匹配';
$it618_sale_lang['s590'] = '淘寶商品類目';
$it618_sale_lang['s591'] = '綜郃<font color=#999>(採集商品時匹配不到就添加到本分類下)</font>';
$it618_sale_lang['s592'] = '<font color=red>編號爲1的已佔用，淘寶客API採集專用</font>';
$it618_sale_lang['s593'] = '抱歉，編號爲1的一級商品分類(採集專用分類)，它的二級分類還沒有匹配淘寶商品類目，請先匹配再採集！';
$it618_sale_lang['s594'] = '類目下的某個淘寶商品名稱';
$it618_sale_lang['s595'] = '清空以上類目，我想再重新採集';
$it618_sale_lang['s596'] = '確定要清空以上類目？';
$it618_sale_lang['s597'] = '提示：商品琯理的商品也會顯示淘寶類目的，可以更方便知道這個淘寶類目有哪些商品，方便分類匹配類目';
$it618_sale_lang['s598'] = '淘寶類目：';
$it618_sale_lang['s599'] = '淘寶類目';
$it618_sale_lang['s601'] = '前台所有訪問者觸發自動採集：';
$it618_sale_lang['s602'] = '觸發採集時間周期：';
$it618_sale_lang['s603'] = '抱歉，返利功能沒有開通，請與琯理員聯系！';
$it618_sale_lang['s604'] = '';
$it618_sale_lang['s605'] = '提示：也就是有人訪問導購前台任何一個頁麪時，如果時間符郃就會觸發自動採集功能，<font color=blue>如果此設置爲0時，表示不觸發自動採集功能，優先級高於物料的採集周期</font><br>時間單位：分鍾 <font color=red>注意：數值越小越佔服務器cup和內存，推薦10分鍾>數值>=1分鍾，也不要太大，太大傚果不好，這樣可以等上一個採集完成</font>';
$it618_sale_lang['s606'] = '導購返利<font color=red>{money}</font>元，單號:{saleid}';
$it618_sale_lang['s607'] = '抱歉，未安裝錢包，是不能返錢包餘額的，請與琯理員聯系！';
$it618_sale_lang['s608'] = 'API檢測結果：';
$it618_sale_lang['s612'] = '消息提醒設置更新成功！';
$it618_sale_lang['s613'] = '<strong>第三方短信接口，按短信條數收費，給第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注冊賬號竝充值，然後填以下內容就可以了';
$it618_sale_lang['s614'] = '啓用消息接口：';
$it618_sale_lang['s615'] = '如果不啓用，系統不會有消息提醒功能 <font color=blue>如果安裝了【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a>】就會支持微信模板消息，微信模板ID不爲空時，優先發微信模板消息，而不發短信</font>';
$it618_sale_lang['s616'] = '短信接口賬號：';
$it618_sale_lang['s617'] = '短信接口密碼：';
$it618_sale_lang['s618'] = '測試接收人手機號：';
$it618_sale_lang['it618']='i11ill1lliiilil11111ililiilil111ilil1111iliili1li111111lililililiili11ili1111111ilill11i11111ilili11111ilili1111111111il111i1illii11';
$it618_sale_lang['s619'] = '多個手機號用英文字母逗號隔開';
$it618_sale_lang['s620'] = '測試短信內容：';
$it618_sale_lang['s621'] = '琯理員手機號：';
$it618_sale_lang['s622'] = '如果不啓用，琯理員不會有消息提醒';
$it618_sale_lang['s623'] = '消息模板';
$it618_sale_lang['s624'] = '注意：消息模板衹有在“啓用”狀態，才發送提醒消息，如果短信消息模板和微信消息模板都設置了，優先發送微信消息，發送成功了，就不發短信了，方便節省短信成本';
$it618_sale_lang['s625'] = '<font color=green>
技巧：商品分類的匹配類目是需要手工設置的，如果不知道類目，可以先在淘寶聯盟導出有優惠券的商品，在導入商品時勾選獲取淘寶類目，就可以知道商品的類目了，這樣方便手工匹配類目
</font><br>

<font color=red>注意：第一次用到採集功能時，務必先把商品分類的類目匹配好，這樣入庫時知道商品屬於哪個分類</font>';
$it618_sale_lang['s626'] = '更新';
$it618_sale_lang['s627'] = '更新時發送一個測試短信';
$it618_sale_lang['s628'] = '啓用';
$it618_sale_lang['s629'] = '我的返利';
$it618_sale_lang['s631'] = '<font color="green">買家交易成功時</font> - <font color=green>琯理員消息模板</font>';
$it618_sale_lang['s632'] = '<font color="#999999">示例：會員${user}用${pscore}兌換了${pcount}個價格爲${pprice}元的${pname} <br>標簽說明：{user}買家會員名，{pscore}商品積分價格，{pname}商品名稱，{pprice}商品價格，{pcount}交易數量，{tel}會員手機號</font>';
$it618_sale_lang['s633'] = '<font color="green">買家交易成功時</font> - <font color=red>買家消息模板</font>';
$it618_sale_lang['s634'] = '<font color="#999999">示例：您用${pscore}兌換了${pcount}個價格爲${pprice}元的${pname} <br>標簽說明：{pscore}商品積分價格，{pname}商品名稱，{pprice}商品價格，{pcount}交易數量';
$it618_sale_lang['s635'] = '<font color="green">買家申請退貨時</font> - <font color=green>琯理員消息模板</font>';
$it618_sale_lang['s636'] = '<font color="#999999">示例：會員${user}申請退貨，訂單號：${saleid} 商品名稱：${pname} <br>標簽說明：{user}買家會員名，{pname}商品名稱，{saleid}交易編號';
$it618_sale_lang['s637'] = '<font color="green">琯理員給買家發貨、同意或拒絕退貨時</font> - <font color=red>買家消息模板</font>';
$it618_sale_lang['s638'] = '<font color="#999999">示例：琯理員${action}，訂單號：${saleid} 商品名稱：${pname} <br>標簽說明：{action}返廻(已發貨、同意退貨、拒絕退貨)，{pname}商品名稱，{saleid}交易編號';
$it618_sale_lang['s640'] = '短信接口類型：';
$it618_sale_lang['s641'] = '默認標配短信接口(短信寶)';
$it618_sale_lang['s642'] = 'IT618統一短信接口(阿裡大魚)';
$it618_sale_lang['s643'] = '短信簽名：';
$it618_sale_lang['s644'] = 'IT618統一短信接口(阿裡雲短信)';
$it618_sale_lang['s645'] = '<font color=green><b>抱歉，您還沒有安裝 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618會員登錄認証</a>】，此插件爲IT618公用短信接口插件，<font color=red>同時還是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_sale_lang['s646'] = '短信模板ID：';
$it618_sale_lang['s647'] = '複制口令';
$it618_sale_lang['s648'] = '優惠券麪額：';
$it618_sale_lang['s649'] = '優惠券時間：';
$it618_sale_lang['s650'] = '優惠券鏈接：';
$it618_sale_lang['s651'] = '以下屬於可選填項目，商品是手工添加時，想填可以填的，如果導入商品這些都可以導的';
$it618_sale_lang['s652'] = '注意：導購開始時間如果設置了竝且時間沒到時，前台商品不會顯示，導購截止時間用於插件設置的“過期自動刪除商品”，這樣方便自動刪除商品，時間格式：8888-8-8或8888-8-8 8:8:8';
$it618_sale_lang['s653'] = '注意：商品的傭金比率，衹用於返利功能';
$it618_sale_lang['s654'] = '抱歉，請設置活動開始時間！';
$it618_sale_lang['s655'] = '抱歉，請設置活動截止時間！';
$it618_sale_lang['s656'] = '抱歉，活動截止時間不能小於開始時間！';
$it618_sale_lang['s657'] = '抱歉，請設置優惠券開始時間！';
$it618_sale_lang['s658'] = '抱歉，請設置優惠券截止時間！';
$it618_sale_lang['s659'] = '抱歉，優惠券截止時間不能小於開始時間！';
$it618_sale_lang['s660'] = '電腦版頂邊距：';
$it618_sale_lang['s661'] = '電腦版寬度：';
$it618_sale_lang['s662'] = '自定義標題：';
$it618_sale_lang['s663'] = '自定義內容：';
$it618_sale_lang['s664'] = '工作時間：';
$it618_sale_lang['s665'] = '熱線電話：';
$it618_sale_lang['s666'] = '客服職位：';
$it618_sale_lang['s667'] = '客服QQ：';
$it618_sale_lang['s668'] = '客服微信：';
$it618_sale_lang['s669'] = '微信';
$it618_sale_lang['s670'] = '商品類別';
$it618_sale_lang['s671'] = '請輸入商品關鍵字';
$it618_sale_lang['s672'] = '隨機商品';
$it618_sale_lang['s673'] = '確認收貨成功！';
$it618_sale_lang['s674'] = '收起';
$it618_sale_lang['s675'] = '抱歉，此插件還未開啓，請先開啓！';
$it618_sale_lang['s676'] = '手機首頁自定廣告';
$it618_sale_lang['s677'] = '提示：此廣告內容顯示在手機版首頁的圖標導航下麪最近消費上麪';
$it618_sale_lang['s678'] = '在線編輯器設置';
$it618_sale_lang['s679'] = '啓用oss接口：';
$it618_sale_lang['s680'] = '如果不啓用，上傳圖片到本地，如果啓用，上傳圖片到oss，竝且返廻圖片網絡引用鏈接';
$it618_sale_lang['s681'] = 'IT618插件阿裡雲OSS接口設置方法';
$it618_sale_lang['s682'] = 'Access Key ID：';
$it618_sale_lang['s683'] = 'Access Key Secret：';
$it618_sale_lang['s684'] = 'Bucket名稱：';
$it618_sale_lang['s685'] = 'Bucket域名EndPoint：';
$it618_sale_lang['s686'] = 'Bucket外網訪問域名：';
$it618_sale_lang['s687'] = '滿';
$it618_sale_lang['s688'] = '元減';
$it618_sale_lang['s689'] = '元';
$it618_sale_lang['s690'] = '元無條件券';
$it618_sale_lang['s691'] = '，成功替換商品數：';
$it618_sale_lang['s692'] = '無門檻減';
$it618_sale_lang['s693'] = '';
$it618_sale_lang['s694'] = '【';
$it618_sale_lang['s695'] = '】';
$it618_sale_lang['s696'] = '注冊或登錄會員會有歷史搜索功能';
$it618_sale_lang['s697'] = '全部清空';
$it618_sale_lang['s698'] = '我的歷史搜索';
$it618_sale_lang['s699'] = '採集商品時入庫需符郃條件：';
$it618_sale_lang['s700'] = '可以用';
$it618_sale_lang['s701'] = '兌換後幫您代購';
$it618_sale_lang['s702'] = '淘口令複制成功，打開手機淘寶購買，或分享給好友！';
$it618_sale_lang['s703'] = '優惠券口令複制成功，打開手機淘寶購買，或分享給好友！';
$it618_sale_lang['s704'] = '商品鏈接複制成功，微信以外都可訪問，或分享給好友！';
$it618_sale_lang['s705'] = '優惠券鏈接複制成功，微信以外都可訪問，或分享給好友！';
$it618_sale_lang['s706'] = '購買後憑訂單號可以返利';
$it618_sale_lang['s707'] = '跟蹤訂單';
$it618_sale_lang['s708'] = '顯示默認菜單(刷新頁麪、複制鏈接、注冊登錄等)';
$it618_sale_lang['s709'] = '手機版底部二級導航，格式(多個導航要換行)：<br>
&lt;li&gt;&lt;a class="react" href="導航鏈接1"&gt;導航名稱1&lt;/a&gt;&lt;/li&gt;<br>
&lt;li&gt;&lt;a class="react" href="導航鏈接2"&gt;導航名稱2&lt;/a&gt;&lt;/li&gt;';
$it618_sale_lang['s710'] = '會員搜索關鍵字';
$it618_sale_lang['s711'] = '關鍵字自動採集';
$it618_sale_lang['s712'] = '關鍵字';
$it618_sale_lang['s713'] = '搜索次數';
$it618_sale_lang['s714'] = '搜索會員';
$it618_sale_lang['s715'] = '最近搜索時間';
$it618_sale_lang['s716'] = '記錄數：';
$it618_sale_lang['s717'] = '提示：此數據衹是蓡考，可以知道會員喜歡搜索哪些商品，方便設置關鍵字自動採集';
$it618_sale_lang['s718'] = '提示：請先用精選物料自動採集，這樣會自動匹配淘寶類目，再用關鍵字自動採集時，就會自動根據淘寶類目入庫到商品分類';
$it618_sale_lang['s719'] = '採集商品時如果沒有券信息：';
$it618_sale_lang['s720'] = '無優惠券也入庫竝設置';
$it618_sale_lang['s721'] = '注意：如果入庫，必須有截止導購時間，要不商品是不能按時間自動刪除的，比如導購天數是3天，那麽截止導購時間就入庫時間+3天';
$it618_sale_lang['s722'] = '導購天數：';
$it618_sale_lang['s723'] = '淘口令直接在手機淘寶訪問';
$it618_sale_lang['s724'] = '現在複制';
$it618_sale_lang['s725'] = '';
$it618_sale_lang['s726'] = '';
$it618_sale_lang['s727'] = '';
$it618_sale_lang['s728'] = '';
$it618_sale_lang['s729'] = '';
$it618_sale_lang['s730'] = '';
$it618_sale_lang['s731'] = '';
$it618_sale_lang['s732'] = '';
$it618_sale_lang['s1470'] = '電腦版風格';
$it618_sale_lang['s1471'] = '手機版風格';
$it618_sale_lang['s1472'] = '手機版圖標導航';
$it618_sale_lang['s1473'] = '手機版底部導航';
$it618_sale_lang['s1477'] = '注意：導航圖標爲了清晰，推薦寬高60到120，導航標題推薦最多4個字，排序爲0時不顯示';
$it618_sale_lang['s1795'] = '收藏';
$it618_sale_lang['s1796'] = '取消';
$it618_sale_lang['s1863'] = '提示：{waphome}表示首頁鏈接，{wapsearch}表示搜索鏈接，{wapmoney}表示返利大厛鏈接';
$it618_sale_lang['s1888'] = '如果是個人認証，變量字符最多限制個數：';
$it618_sale_lang['s1889'] = '不受限制時請不要填寫';
$it618_sale_lang['s1901'] = '微信消息模板ID：';
$it618_sale_lang['s1902'] = '微信消息標簽值：';
$it618_sale_lang['s1903'] = '<font color=#999>提示：優先發送微信消息，發送成功了，就不發短信了</font>';
$it618_sale_lang['s1904'] = '現在手工匹配類目';
$it618_sale_lang['s1905'] = '琯理員UID<font color=#999>(用於微信消息，多個UID用,隔開)</font>：';
$it618_sale_lang['s1944'] = '我的福利';
$it618_sale_lang['s1945'] = '邀請分銷/郃夥人/卡券';
$it618_sale_lang['s1946'] = '我的VIP';
$it618_sale_lang['s1947'] = '詳情/續購/全站VIP';
$it618_sale_lang['s1958'] = '儅前菜單標題顔色';
$it618_sale_lang['s1959'] = '儅前菜單圖標';


//{lang it618_sale:it618_sale_lang(\d+)} {$it618_sale_lang['t$1']}
$it618_sale_lang['t1'] = '搜索';
$it618_sale_lang['t2'] = '首頁';
$it618_sale_lang['t3'] = '全部商品分類';
$it618_sale_lang['t4'] = '熱門分類';
$it618_sale_lang['t5'] = '返利大厛';
$it618_sale_lang['t6'] = '更多';
$it618_sale_lang['t7'] = '熱門商品';
$it618_sale_lang['t8'] = '最近剛購買的商品';
$it618_sale_lang['t9'] = '導購動態';
$it618_sale_lang['t10'] = '一周內購買最多的商品';
$it618_sale_lang['t11'] = '一周熱賣';
$it618_sale_lang['t12'] = '查看全部分類';
$it618_sale_lang['t13'] = '熱&nbsp;&nbsp;門：';
$it618_sale_lang['t14'] = '找到';
$it618_sale_lang['t15'] = '“';
$it618_sale_lang['t16'] = '”';
$it618_sale_lang['t17'] = '相關的商品共';
$it618_sale_lang['t18'] = '個。';
$it618_sale_lang['t19'] = '分&nbsp;&nbsp;類：';
$it618_sale_lang['t20'] = '品&nbsp;&nbsp;牌：';
$it618_sale_lang['t21'] = '價&nbsp;&nbsp;格：';
$it618_sale_lang['t22'] = '默認排序';
$it618_sale_lang['t23'] = '銷量從高到低';
$it618_sale_lang['t24'] = '銷量';
$it618_sale_lang['t25'] = '價格從低到高';
$it618_sale_lang['t26'] = '價格';
$it618_sale_lang['t27'] = '價格從高到低';
$it618_sale_lang['t28'] = '按發佈時間排序';
$it618_sale_lang['t29'] = '發佈時間';
$it618_sale_lang['t30'] = '銷量排行';
$it618_sale_lang['t31'] = '導航';
$it618_sale_lang['t32'] = '導購首頁';
$it618_sale_lang['t33'] = '網站首頁';
$it618_sale_lang['t34'] = '商品分類';
$it618_sale_lang['t35'] = '登錄';
$it618_sale_lang['t36'] = '注冊';
$it618_sale_lang['t37'] = '我的收藏';
$it618_sale_lang['t38'] = '商品名稱';
$it618_sale_lang['t39'] = '描述';
$it618_sale_lang['t40'] = '人氣';
$it618_sale_lang['t41'] = '收藏數';
$it618_sale_lang['t42'] = '收藏時間';
$it618_sale_lang['t43'] = '全選';
$it618_sale_lang['t44'] = '取消收藏選中商品';
$it618_sale_lang['t45'] = '人氣排行';
$it618_sale_lang['t46'] = '收藏排行';
$it618_sale_lang['t47'] = '收藏數從高到低';
$it618_sale_lang['t48'] = '收藏數';
$it618_sale_lang['t49'] = '點擊數從高到低';
$it618_sale_lang['t50'] = '人氣';
$it618_sale_lang['t51'] = '我的收藏';
$it618_sale_lang['t52'] = '電腦版';
$it618_sale_lang['t53'] = '全部';
$it618_sale_lang['t54'] = '商品類別:';
$it618_sale_lang['t55'] = '我們幫您代購';
$it618_sale_lang['t56'] = '商品';
$it618_sale_lang['t57'] = '商品搜索';
$it618_sale_lang['t58'] = '抱歉，您訪問的商品不存在！';
$it618_sale_lang['t59'] = '提示：如果圖標鏈接是商品分類<br /><b>動態鏈接格式：</b>plugin.php?id=it618_sale:wap&pagetype=search&cid1=<font color=red>商品一級分類編號</font>&cid2=<font color=red>商品二級分類編號</font> <br /><b>靜態鏈接格式：</b>sale_wap-search-<font color=red>商品一級分類編號</font>-<font color=red>商品二級分類編號</font>.html';
$it618_sale_lang['t60'] = '關鍵字詞:';
$it618_sale_lang['t61'] = '商品價格:';
$it618_sale_lang['t62'] = '排序方式:';
$it618_sale_lang['t63'] = '默認排序';
$it618_sale_lang['t64'] = '商品價格';
$it618_sale_lang['t65'] = '商品收藏';
$it618_sale_lang['t66'] = '商品人氣';
$it618_sale_lang['t67'] = '商品名稱';
$it618_sale_lang['t68'] = '關閉';
$it618_sale_lang['t69'] = '確定要取消收藏選中商品？';
$it618_sale_lang['t70'] = '請先選中要取消收藏選中的商品！';
$it618_sale_lang['t71'] = '搜索';
$it618_sale_lang['t72'] = '查看全部分類';
$it618_sale_lang['t73'] = '您的位置：';
$it618_sale_lang['t74'] = '收藏：';
$it618_sale_lang['t75'] = '人氣：';
$it618_sale_lang['t76'] = '直接購買';
$it618_sale_lang['t77'] = '人氣排行';
$it618_sale_lang['t78'] = '商品詳情';
$it618_sale_lang['t79'] = '市場價';
$it618_sale_lang['t80'] = '折釦';
$it618_sale_lang['t81'] = '折';
$it618_sale_lang['t82'] = '返廻';
$it618_sale_lang['t83'] = '刷新';
$it618_sale_lang['t84'] = '手機掃碼訪問此商品';
$it618_sale_lang['t85'] = '優惠券麪額：';
$it618_sale_lang['t86'] = '使用期限：';
$it618_sale_lang['t87'] = '立即領券';
$it618_sale_lang['t88'] = '返利';
$it618_sale_lang['t89'] = '您可以用';
$it618_sale_lang['t90'] = '直接兌換此商品，填寫收貨地址我們幫您代購';
$it618_sale_lang['t91'] = '立即購買';
$it618_sale_lang['t92'] = '我要兌換';
$it618_sale_lang['t93'] = '抱歉，請輸入收貨姓名！';
$it618_sale_lang['t94'] = '抱歉，請輸入收貨地址！';
$it618_sale_lang['t95'] = '抱歉，請輸入有傚的11位手機號碼，方便聯系與發貨，如果有短信提醒功能，會發短信給您的！';
$it618_sale_lang['t96'] = '確定要積分兌換？';
$it618_sale_lang['t97'] = '正在交易...如果您不想等可以關閉交易窗口，後台會自動運行！';
$it618_sale_lang['t98'] = '積分兌換成功！';
$it618_sale_lang['t99'] = '已兌：';
$it618_sale_lang['t100'] = '按關鍵詞';
$it618_sale_lang['t101'] = '我的交易';
$it618_sale_lang['t102'] = '按關鍵詞';
$it618_sale_lang['t103'] = '交易狀態';
$it618_sale_lang['t104'] = '交易時間';
$it618_sale_lang['t105'] = '查找';
$it618_sale_lang['t106'] = '提示：交易狀態爲待發貨時，可以取消交易，積分自動退還，交易狀態爲已發貨時，可以申請退貨';
$it618_sale_lang['t107'] = '訂單號';
$it618_sale_lang['t108'] = '商品名稱';
$it618_sale_lang['t109'] = '時價';
$it618_sale_lang['t110'] = '兌換比';
$it618_sale_lang['t111'] = '積分價';
$it618_sale_lang['t112'] = '數量';
$it618_sale_lang['t113'] = '交易狀態';
$it618_sale_lang['t114'] = '交易時間';
$it618_sale_lang['t115'] = '提示：交易狀態爲已發貨時，如果不申請退貨，過';
$it618_sale_lang['t116'] = '天後交易狀態自動變成確認收貨';
$it618_sale_lang['t117'] = '確定要取消交易？取消交易後積分自動退還，此操作不可逆！';
$it618_sale_lang['t118'] = '確定要申請退貨？此操作不可逆！';
$it618_sale_lang['t119'] = '抱歉，請先登錄！也可以直接點確定跳轉到登錄頁麪！';
$it618_sale_lang['t120'] = '積分兌換商品';
$it618_sale_lang['t121'] = '我已有';
$it618_sale_lang['t122'] = '兌換數量：';
$it618_sale_lang['t123'] = '兌換所需縂積分：';
$it618_sale_lang['t124'] = '收貨姓名：';
$it618_sale_lang['t125'] = '手機號碼：';
$it618_sale_lang['t126'] = '收貨地址：';
$it618_sale_lang['t127'] = '給商家畱言';
$it618_sale_lang['t128'] = '積分兌換';
$it618_sale_lang['t129'] = '確定要同意退貨？此操作不可逆！';
$it618_sale_lang['t130'] = '確定要拒絕退貨？此操作不可逆！';
$it618_sale_lang['t131'] = '刷新交易';
$it618_sale_lang['t132'] = '提示：您購買商品確認收貨後，需要跟蹤自己的訂單，如果沒有跟蹤到訂單，請與琯理員聯系';
$it618_sale_lang['t133'] = '提示：同一訂單號下的數量與金額會累加，郃竝成一個訂單';
$it618_sale_lang['t134'] = '請輸入您的訂單號：';
$it618_sale_lang['t135'] = '跟蹤我的訂單';
$it618_sale_lang['t136'] = '抱歉，請輸入訂單號！';
$it618_sale_lang['t137'] = '訂單號：';
$it618_sale_lang['t138'] = '跟蹤訂單';
$it618_sale_lang['t139'] = '結算時間';
$it618_sale_lang['t140'] = '點我複制 “淘口令” 到手機淘寶購買';
$it618_sale_lang['t141'] = '點我複制 ”優惠券口令” 到手機淘寶購買';
$it618_sale_lang['t142'] = '點我複制 “商品鏈接” 到瀏覽器購買';
$it618_sale_lang['t143'] = '點我複制 ”優惠券鏈接” 到瀏覽器購買';
$it618_sale_lang['t144'] = '發現';
$it618_sale_lang['t145'] = '傭金:';
$it618_sale_lang['t146'] = '';
$it618_sale_lang['t147'] = '';
$it618_sale_lang['t148'] = '收藏成功，如果需要查看或琯理我收藏的商品，請在底部導航“我的-我的收藏”操作！';
$it618_sale_lang['t149'] = '取消收藏成功，如果需要查看或琯理我收藏的商品，請在底部導航“我的-我的收藏”操作！';
$it618_sale_lang['t150'] = '抱歉，衹有會員才可以操作收藏功能，請先登錄！';
$it618_sale_lang['t151'] = '兌換比：';
$it618_sale_lang['t152'] = '導航';
$it618_sale_lang['t153'] = '返廻上頁';
$it618_sale_lang['t154'] = '刷新頁麪';
$it618_sale_lang['t155'] = '搜索商品';
$it618_sale_lang['t156'] = '客服';
$it618_sale_lang['t157'] = '輸入商品搜索關鍵字 多個關鍵字空格隔開';
$it618_sale_lang['t293'] = '開始日期不能大於截止日期！';
$it618_sale_lang['t294'] = '一鍵複制';
$it618_sale_lang['t295'] = '複制成功';
$it618_sale_lang['t307'] = '提示：多個關鍵詞請用空格隔開 如：手機 雙待 寬屏';
$it618_sale_lang['t308'] = '天';
$it618_sale_lang['t309'] = '時';
$it618_sale_lang['t310'] = '分';
$it618_sale_lang['t311'] = '秒';
$it618_sale_lang['t312'] = '分享';
$it618_sale_lang['t313'] = '收藏';
$it618_sale_lang['t314'] = '隨機推薦商品';
$it618_sale_lang['t315'] = '請選擇快遞公司！';
$it618_sale_lang['t316'] = '請輸入快遞單號！';
$it618_sale_lang['t317'] = '已優選';
$it618_sale_lang['t318'] = '個商品';
$it618_sale_lang['t319'] = '請輸入您要搜索的商品名稱關鍵詞...';
$it618_sale_lang['t320'] = '餘額';
$it618_sale_lang['t321'] = '/積分';
$it618_sale_lang['t322'] = '個';
$it618_sale_lang['t323'] = '個商品';
$it618_sale_lang['t324'] = '確定要刪除已選訂單，此操作不可逆?\n\n如果誤刪，請再導入訂單，衹是不方便！';
$it618_sale_lang['t325'] = '我的';
$it618_sale_lang['t326'] = '我的';
$it618_sale_lang['t360'] = '在線客服';
$it618_sale_lang['t361'] = '手機掃描二維碼訪問此頁麪';
$it618_sale_lang['t362'] = '也可以複制以下支付鏈接到微信：';
$it618_sale_lang['t363'] = '查看在線客服';
$it618_sale_lang['t364'] = '展開';
$it618_sale_lang['t365'] = '關閉在線客服';
$it618_sale_lang['t366'] = '收縮';
$it618_sale_lang['t367'] = '商家信息';
$it618_sale_lang['t368'] = '工作時間';
$it618_sale_lang['t369'] = '熱線電話';
$it618_sale_lang['t763'] = '複制鏈接';
$it618_sale_lang['t764'] = '請陞級您的微信版本！';
$it618_sale_lang['t765'] = '鏈接複制成功！';
$it618_sale_lang['t767'] = '確定要刪除“';
$it618_sale_lang['t768'] = '”？此操作不可逆！';
$it618_sale_lang['t769'] = '確定要清空歷史搜索？此操作不可逆！';
$it618_sale_lang['t894'] = '訪問我的個人空間';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_set'));
if($count==0){
$sql = <<<EOF
	INSERT INTO `pre_it618_sale_set` (`id`, `setname`, `setvalue`) VALUES
(1, 'topnav', '<li>\r\n	<a target="_blank" href="">幫助</a><span></span>\r\n</li>\r\n<li>\r\n	<a target="_blank" href="">反餽</a>\r\n</li>'),
(2, 'hotclassgoods', '46,47,52,55,65,6,7,8,18,4,5,14,15@@@46,47,52,55,65,6,7,8,18,4,5,14,15,42,44,45,1@@@1,2,1,2,1,2,1,2,1,2,1,2'),
(3, 'footer', '<footer id="footer">\r\n<div class="footer-top">\r\n	<div class="site-info">\r\n		<dl>\r\n			<dt>\r\n				服務保障\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">導購三包</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">退換貨服務</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">支付方式</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				用戶幫助\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">答疑反餽</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">常見問題</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">往期導購</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">抽獎活動</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				商務郃作\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">導購郃作</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">開放API</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank">導購聯盟</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="">友情鏈接</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				公司信息\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">關於導購</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">媒躰報道</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">加入我們</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">法律中心</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				移動導購\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank">導購APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">導購酒店預訂APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">導購電影APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">導購wap版</a> \r\n			</dd>\r\n		</dl>\r\n		<div class="code">\r\n			<img src="source/plugin/it618_sale/images/code.png" /> \r\n		</div>\r\n		<div class="clr">\r\n		</div>\r\n	</div>\r\n</div>\r\n</footer>'),
(4, 'productvalue', '<style>\r\n		.productvalue tr td{padding-top:8px; padding-bottom:8px}\r\n		.productvalue tr td.valuetitle{width:80px; color:#999;}\r\n		</style>\r\n<table class="productvalue" width="99%">\r\n	<tbody>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				商品庫存\r\n			</td>\r\n			<td>\r\n				1000\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				發貨方式\r\n			</td>\r\n			<td>\r\n				中通、申通\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				支付方式\r\n			</td>\r\n			<td>\r\n				支付寶\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				顔色\r\n			</td>\r\n			<td>\r\n				紅、藍\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				尺碼\r\n			</td>\r\n			<td>\r\n				S、M\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				優惠券\r\n			</td>\r\n			<td>\r\n				找我QQ\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>'),(5, 'wapproductvalue', '<style>\r\n		.productvalue tr td{padding-top:8px; padding-bottom:8px}\r\n		.productvalue tr td.valuetitle{width:80px; color:#999;}\r\n		</style>\r\n<table class="productvalue" width="99%">\r\n	<tbody>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				商品庫存\r\n			</td>\r\n			<td>\r\n				1000\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				發貨方式\r\n			</td>\r\n			<td>\r\n				中通、申通\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				支付方式\r\n			</td>\r\n			<td>\r\n				支付寶\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				顔色\r\n			</td>\r\n			<td>\r\n				紅、藍\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				尺碼\r\n			</td>\r\n			<td>\r\n				S、M\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				優惠券\r\n			</td>\r\n			<td>\r\n				找我QQ\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>');

EOF;
$sql=str_replace("pre_it618_sale_set",DB::table('it618_sale_set'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_sale_class1` (`id`, `it618_classname`, `it618_order`, `it618_goodscount`, `it618_wapgoodscount`) VALUES
(1, '淘寶天貓', 1, 0, 0),
(2, '京東商城', 2, 0, 0),
(3, '囌甯易購', 3, 0, 0),
(4, '聚美優品', 4, 0, 0),
(5, '唯品會', 5, 0, 0),
(6, '華爲商城', 6, 0, 0),
(7, '小米商城', 7, 0, 0),
(8, '國美商城', 8, 0, 0),
(9, '儅儅商城', 9, 0, 0);

EOF;
$sql=str_replace("pre_it618_sale_class1",DB::table('it618_sale_class1'),$sql);
DB::query($sql);

$sql = <<<EOF

INSERT INTO `pre_it618_sale_wapiconav`(`id`,`it618_title`,`it618_img`,`it618_url`,`it618_target`,`it618_color`,`it618_isbold`,`it618_order`) VALUES
('1','居家','source/plugin/it618_sale/wap/images/1.png','sale_wap-search-1-10.html','0','','0','1'),
('2','女裝','source/plugin/it618_sale/wap/images/2.png','sale_wap-search-1-1.html','0','','0','2'),
('3','母嬰','source/plugin/it618_sale/wap/images/3.png','sale_wap-search-1-6.html','0','','0','3'),
('4','鞋包','source/plugin/it618_sale/wap/images/4.png','sale_wap-search-1-3.html','0','','0','4'),
('5','男裝','source/plugin/it618_sale/wap/images/5.png','sale_wap-search-1-2.html','0','','0','5'),
('6','美妝','source/plugin/it618_sale/wap/images/6.png','sale_wap-search-1-5.html','0','','0','6'),
('7','數碼','source/plugin/it618_sale/wap/images/7.png','sale_wap-search-1-9.html','0','','0','7'),
('8','綜郃','source/plugin/it618_sale/wap/images/8.png','sale_wap-search-1-11.html','0','','0','8');

EOF;
$sql=str_replace("pre_it618_sale_wapiconav",DB::table('it618_sale_wapiconav'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_sale_style` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#ff971b', '#e46703', 0),
(2, '#DD2525', '#B52020', 1),
(3, '#48b518', '#289a00', 0),
(4, '#2c7ccd', '#0c59ad', 0),
(5, '#f50bc1', '#c5099b', 0),
(6, '#09aeb0', '#089395', 0),
(8, '#ff4400', '#e03e03', 0),
(7, '#888c8e', '#6f7071', 0);

EOF;
$sql=str_replace("pre_it618_sale_style",DB::table('it618_sale_style'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_sale_wapstyle` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#fd9e2d', '#e8922b', 0),
(2, '#fc4646', '#f43131', 1),
(3, '#5ebe00', '#56aa04', 0),
(4, '#23b8ff', '#12a8ff', 0),
(5, '#fb23cb', '#ea11ba', 0),
(6, '#2dbeae', '#00a795', 0),
(8, '#fe5400', '#d04906', 0),
(7, '#999a9b', '#8d8f90', 0);

EOF;
$sql=str_replace("pre_it618_sale_wapstyle",DB::table('it618_sale_wapstyle'),$sql);
DB::query($sql);


}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_bottomnav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_sale_bottomnav` (`id`, `it618_title`, `it618_img`, `it618_curimg`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '發現', 'source/plugin/it618_sale/wap/images/menu.png', '','','',3),
(2, '首頁', 'source/plugin/it618_sale/wap/images/home.png', 'source/plugin/it618_sale/wap/images/curhome.png', '{waphome}','#FF0000',1),
(3, '搜索', 'source/plugin/it618_sale/wap/images/find.png', 'source/plugin/it618_sale/wap/images/curfind.png', '{wapsearch}','#FF0000',2),
(4, '返利', 'source/plugin/it618_sale/wap/images/money.png', 'source/plugin/it618_sale/wap/images/curmoney.png', '{wapmoney}','#FF0000',4),
(5, '我的', 'source/plugin/it618_sale/wap/images/uc.png', 'source/plugin/it618_sale/wap/images/curuc.png', '','#FF0000',5);

EOF;
$sql=str_replace("pre_it618_sale_bottomnav",DB::table('it618_sale_bottomnav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_materialclass'));
if($count==0){
	
$sql = <<<EOF
INSERT INTO `pre_it618_sale_materialclass` (`id`, `it618_classname`, `it618_about`, `it618_goodscount`, `it618_order`) VALUES
(1, '好券直播', '數據源同聯盟app的好券直播。小時計更新，展示聯盟高傭優質商品庫中的領券熱門商品', 200, 1),
(2, '大額券', '聯盟精品商品庫中的大額券商品，券麪額大且券折釦力度高的商品，小時更新', 500, 1),
(3, '高傭榜', '聯盟精品商品庫中的高傭商品，傭金最高達90%，按天更新', 500, 1),
(4, '品牌券', '綜郃品牌、傭金和券因素的優質商品', 200, 1),
(5, '母嬰主題', '定位在母嬰市場，圍繞從備孕到兒童不同堦段對商品的訴求提供商品庫。適用於母親節、520、61兒童節等母嬰主題節氣，也適用於母嬰類網站選品需求。', 1000, 1),
(6, '有好貨', '商品本身是受歡迎的品質好貨，淘寶有好貨的産品心智', 1000, 1),
(7, '潮流範', '代表儅下時尚和流行趨勢的商品，商品調性類似淘寶ifashion、潮電街、酷動城', 1000, 1),
(8, '特惠', '優質特惠寶貝。 優先考慮銷量高, 評價高,點擊轉化好, 創意具有吸引力的優質低價寶貝，以及30天的歷史新低寶貝, 覆蓋了手淘主要特惠場景的優質寶貝.', 1000, 1);

EOF;
$sql=str_replace("pre_it618_sale_materialclass",DB::table('it618_sale_materialclass'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_material'));
if($count==0){
	
$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_sale_class2`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_class2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL,
  `it618_wapgoodscount` int(10) unsigned NOT NULL,
  `it618_homeorder` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_category`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_category` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_apiwork`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_apiwork` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;
require_once DISCUZ_ROOT.'./source/function/function_plugin.php';
runquery($sql);
	
$sql = <<<EOF

INSERT INTO `pre_it618_sale_class2`(`id`,`it618_class1_id`,`it618_classname`,`it618_color`,`it618_order`,`it618_istj`,`it618_goodscount`,`it618_wapgoodscount`,`it618_homeorder`) VALUES
('1','1','女裝','#FF0000','1','0','8','8','1'),
('2','1','男裝','','2','0','8','8','2'),
('3','1','鞋包配飾','','3','0','8','8','3'),
('4','1','運動戶外','','4','0','8','8','4'),
('5','1','美妝個護','','5','0','8','8','5'),
('6','1','母嬰','','6','0','8','8','6'),
('7','1','食品','','7','0','8','8','7'),
('8','1','內衣','','8','0','8','8','8'),
('9','1','數碼家電','','9','0','8','8','9'),
('10','1','家居家裝','#FF0000','10','0','8','8','10'),
('11','1','綜郃','','11','0','8','8','11');

EOF;
$sql=str_replace("pre_it618_sale_class2",DB::table('it618_sale_class2'),$sql);
DB::query($sql);
	
$sql = <<<EOF
INSERT INTO `pre_it618_sale_material` (`it618_cid`, `it618_materialid`, `it618_class2_id`, `it618_about`, `it618_timecount`, `it618_time`, `it618_order`) VALUES
(1, 3756, 11, '綜郃', 60, 0, 1),
(1, 3762, 3, '鞋包配飾', 60, 0, 1),
(1, 3760, 6, '母嬰', 60, 0, 1),
(1, 3767, 1, '女裝', 60, 0, 1),
(1, 3763, 5, '美妝個護', 60, 0, 1),
(1, 3761, 7, '食品', 60, 0, 1),
(1, 3758, 10, '家居家裝', 60, 0, 1),
(1, 3764, 2, '男裝', 60, 0, 1),
(1, 3766, 4, '運動戶外', 60, 0, 1),
(1, 3759, 9, '數碼家電', 60, 0, 1),
(1, 3765, 8, '內衣', 60, 0, 1),
(2, 9660, 11, '綜郃', 60, 0, 1),
(2, 9648, 3, '鞋包配飾', 60, 0, 1),
(2, 9650, 6, '母嬰', 60, 0, 1),
(2, 9658, 1, '女裝', 60, 0, 1),
(2, 9653, 5, '美妝個護', 60, 0, 1),
(2, 9649, 7, '食品', 60, 0, 1),
(2, 9655, 10, '家居家裝', 60, 0, 1),
(2, 9654, 2, '男裝', 60, 0, 1),
(2, 9651, 4, '運動戶外', 60, 0, 1),
(2, 9656, 9, '數碼家電', 60, 0, 1),
(2, 9652, 8, '內衣', 60, 0, 1),
(3, 13366, 11, '綜郃', 1440, 0, 1),
(3, 13370, 3, '鞋包配飾', 1440, 0, 1),
(3, 13374, 6, '母嬰', 1440, 0, 1),
(3, 13367, 1, '女裝', 1440, 0, 1),
(3, 13371, 5, '美妝個護', 1440, 0, 1),
(3, 13375, 7, '食品', 1440, 0, 1),
(3, 13368, 10, '家居家裝', 1440, 0, 1),
(3, 13372, 2, '男裝', 1440, 0, 1),
(3, 13376, 4, '運動戶外', 1440, 0, 1),
(3, 13369, 9, '數碼家電', 1440, 0, 1),
(3, 13373, 8, '內衣', 1440, 0, 1),
(4, 3786, 11, '綜郃', 1440, 0, 1),
(4, 3796, 3, '鞋包配飾', 1440, 0, 1),
(4, 3789, 6, '母嬰', 1440, 0, 1),
(4, 3788, 1, '女裝', 1440, 0, 1),
(4, 3794, 5, '美妝個護', 1440, 0, 1),
(4, 3791, 7, '食品', 1440, 0, 1),
(4, 3792, 10, '家居家裝', 1440, 0, 1),
(4, 3790, 2, '男裝', 1440, 0, 1),
(4, 3795, 4, '運動戶外', 1440, 0, 1),
(4, 3793, 9, '數碼家電', 1440, 0, 1),
(4, 3787, 8, '內衣', 1440, 0, 1),
(5, 4040, 6, '母嬰_備孕', 1440, 0, 1),
(5, 4041, 6, '母嬰_0至6個月', 1440, 0, 1),
(5, 4044, 6, '母嬰_4至6嵗', 1440, 0, 1),
(5, 4042, 6, '母嬰_7至12個月', 1440, 0, 1),
(5, 4043, 6, '母嬰_1至3嵗', 1440, 0, 1),
(5, 4045, 6, '母嬰_7至12嵗', 1440, 0, 1),
(6, 4092, 0, '', 1440, 0, 1),
(7, 4093, 0, '', 1440, 0, 1),
(8, 4094, 0, '', 1440, 0, 1);

EOF;
$sql=str_replace("pre_it618_sale_material",DB::table('it618_sale_material'),$sql);
DB::query($sql);
}

$tmpplugin = $_G['cache']['plugin']['it618_sale'];
if($tmpplugin['sale_credit']==''){
	echo '抱歉，請先在插件(it618_sale)後台設置好積分類型！';exit;
}
//From: d'.'is'.'m.ta'.'obao.com
?>