<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/sale_default.func.php';

$pid=intval($_GET['pid']);
if(sale_is_mobile()){ 
	$tmpurl=it618_sale_getrewrite('sale_wap','product@'.$pid,'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$pid);
	dheader("location:$tmpurl");
}

if(!($it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id_state($pid,1))){
	$homeurl=it618_sale_getrewrite('sale_home','','plugin.php?id=it618_sale:index');
	dheader("location:$homeurl");
}else{

	if($it618_sale_goods['it618_pcurl']==''){
		$homeurl=it618_sale_getrewrite('sale_home','','plugin.php?id=it618_sale:index');
		dheader("location:$homeurl");
	}
	
	if($it618_sale_goods['it618_quanurl']!=''){
		$it618_sale_goods['it618_pcurl']=$it618_sale_goods['it618_quanurl'];
	}
	
	if($it618_sale_goods['it618_quancodeurl']!=''){
		$it618_sale_goods['it618_codeurl']=$it618_sale_goods['it618_quancodeurl'];
	}
	
	if($it618_sale['sale_isurl']==3){
		if($it618_sale['sale_isjf']==1){
			$isjfok=1;
			
			if($it618_sale['sale_priceforjf']!=''){
				$tmparr=explode(",",$it618_sale['sale_priceforjf']);
				if(($it618_sale_goods['it618_saleprice']<$tmparr[0]||$it618_sale_goods['it618_saleprice']>$tmparr[1])){
					$isjfok=0;
				}
			}
		}else{
			$isjfok=0;
		}
	}

	if(it618_getgoodsisurl($it618_sale_goods)==1){
		dheader("location:".$it618_sale_goods['it618_pcurl']);
	}
}

foreach(C::t('#it618_sale#it618_sale_focus')->fetch_all_by_type_order(15) as $it618_sale_focus) {
	if($it618_sale_focus['it618_url']!=''){
		$str_focus15.='<li><a href="'.$it618_sale_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus15.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

$class1=$it618_sale_goods['it618_class1_id'];
$class2=$it618_sale_goods['it618_class2_id'];

$class1name=C::t('#it618_sale#it618_sale_class1')->fetch_it618_name_by_id($class1);
$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@0','plugin.php?id=it618_sale:list&class1='.$class1.'&class2=0');
$productnav.='<a href="'.$tmpurl.'">'.$class1name.'</a><i></i>';

$class2name=C::t('#it618_sale#it618_sale_class2')->fetch_it618_name_by_id($class2);
$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@'.$class2,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2='.$class2);
$productnav.='<a href="'.$tmpurl.'">'.$class2name.'</a><i></i>';

$productnav.=$it618_sale_goods['it618_name'];

C::t('#it618_sale#it618_sale_goods')->update_it618_views_by_id($pid);
$collectcount = C::t('#it618_sale#it618_sale_goods')->update_it618_collect_by_id($pid);
$salecount = C::t('#it618_sale#it618_sale_goods')->update_it618_salecount_by_id($pid);

$query = DB::query("SELECT * FROM ".DB::table('it618_sale_goods')." where it618_state=1 and it618_class1_id=".$class1." ORDER BY it618_views desc limit 0,".$it618_sale['sale_pageviewscount']);
while($it618_sale_goodstmp = DB::fetch($query)) {
	
	$it618_price1='<em>&yen;</em>'.$it618_sale_goodstmp['it618_saleprice'];
	if($it618_sale_goodstmp['it618_price']>0)$it618_price2='<span class="money">&yen;<del>'.$it618_sale_goodstmp['it618_price'].'</del></span>';
	
	$it618_quanstr='';
	if($it618_sale_goodstmp['it618_quantime1']!=''){
		$it618_quanstr='<div class="divquan">'.$it618_sale_goodstmp['it618_quanstr'].'</div>';
		$quanstr=$it618_sale_goodstmp['it618_quanstr'];
		
		$it618_price1='<em>&yen;</em>'.it618_getquanprice($it618_sale_goodstmp['it618_saleprice'],$quanstr).' <span style="font-size:12px;font-weight:normal">'.$it618_sale_lang['s299'].'</span>';
		$it618_price2='<span class="money">&yen;<del>'.$it618_sale_goodstmp['it618_saleprice'].'</del></span>';
	}
	
	if($it618_description=='')$it618_description=$it618_sale_goodstmp['it618_description'];
		
	if($it618_sale_goodstmp['it618_price']>0)$it618_price='<span class="money">&yen;<del>'.$it618_sale_goodstmp['it618_price'].'</del></span>';
	$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goodstmp['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goodstmp['id']);
	$str_goodshot.='<div class="small-goods" style="margin-top:10px">
	            '.$it618_quanstr.'
				<a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_goodstmp['it618_pic'].'" alt="'.$it618_sale_goodstmp['it618_name'].'" width="198" height="190"></a>
				<h4>
					<a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_sale_goodstmp['it618_name'].'">'.$it618_sale_goodstmp['it618_name'].'</a>
					<a class="small-goods-text" style="color:#999" href="'.$tmpurl.'" target="_blank" title="'.$it618_sale_goodstmp['it618_description'].'">'.it618_getjfblcount($it618_sale_goodstmp).'</a>
				</h4>
				<div class="small-goods-info">
					<span class="price" style="color:red">'.$it618_price1.'</span>
					'.$it618_price2.'
				</div>
			</div>';
}

if($it618_sale_goods['it618_description']!=''){
	$it618_description=$it618_sale_lang['s126'].$it618_sale_goods['it618_description'];
}

if($it618_sale['sale_productmode']==1||$it618_sale['sale_productmode']==''){
	$isapi=1;
}

if($it618_sale['sale_productmode']==2){
	if($it618_sale_goods['it618_message']!=''){
		$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="910" height="510" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_sale_goods['it618_message']);
	}else{
		$it618_message=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('defalutgoodsmessage');
	}
}

if($it618_sale['sale_productmode']==3){
	if($it618_sale_goods['it618_message']!=''){
		$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="910" height="510" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_sale_goods['it618_message']);
	}else{
		$isapi=1;
	}
}

if($it618_sale['sale_productmode']==4){
	$it618_message=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('defalutgoodsmessage');
	$isapi=1;
}

if($isapi==1){
	if($it618_message==''){
		$it618_message.='<div id="it618_message" style="text-align:center;width:915px;"></div>';
	}else{
		$it618_message.='<div id="it618_message" style="text-align:center;width:915px;margin-top:15px"></div>';
	}
}

if($it618_sale['sale_pagerandcount']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_goods')." where it618_state=1 and it618_class2_id=".$class2." ORDER BY rand() limit 0,".$it618_sale['sale_pagerandcount']);
	while($it618_sale_goodstmp = DB::fetch($query)) {
		
		$it618_price1='<em>&yen;</em>'.$it618_sale_goodstmp['it618_saleprice'];
		if($it618_sale_goodstmp['it618_price']>0)$it618_price2='<span class="money">&yen;<del>'.$it618_sale_goodstmp['it618_price'].'</del></span>';
		
		$it618_quanstr='';
		if($it618_sale_goodstmp['it618_quantime1']!=''){
	
			$it618_quanstr='<div class="divquan">'.$it618_sale_goodstmp['it618_quanstr'].'</div>';
			$quanstr=$it618_sale_goodstmp['it618_quanstr'];
			
			$it618_price1='<em>&yen;</em>'.it618_getquanprice($it618_sale_goodstmp['it618_saleprice'],$quanstr).' <span style="font-size:12px;">'.$it618_sale_lang['s299'].'</span>';
			$it618_price2='<span class="money">&yen;<del>'.$it618_sale_goodstmp['it618_saleprice'].'</del></span>';
	
		}
		
		$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goodstmp['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goodstmp['id']);
		$it618goods.='<div class="index-goods">
							'.$it618_quanstr.'
							<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
								<img class="dynload" imgsrc="'.$it618_sale_goodstmp['it618_pic'].'" src="source/plugin/it618_sale/images/a.gif" alt="'.$it618_sale_goodstmp['it618_name'].'"/>
								<span class="index-goods-place">'.$it618_sale_goodstmp['it618_description'].'</span>
							</a>
							<h3>
								<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_sale_goodstmp['it618_name'].'">'.$it618_sale_goodstmp['it618_name'].'</a>
								<a class="index-goods-text" style="color:#999" href="'.$tmpurl.'" target="_blank" title="'.$it618_sale_goodstmp['it618_description'].'">'.it618_getjfblcount($it618_sale_goodstmp).'</a>
							</h3>
							<div class="index-goods-info" style="padding-top:0">
								<span class="price" style="color:red">'.$it618_price1.'</span>
								'.$it618_price2.'
							</div>
						</div>';
	}
}

$it618_price=$it618_sale_goods['it618_price'];
$it618_saleprice=$it618_sale_goods['it618_saleprice'];

if($it618_sale_goods['it618_quantime1']!=''){
	$btime=strtotime($it618_sale_goods['it618_quantime1']);
	$etime=strtotime($it618_sale_goods['it618_quantime2']);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=$it618_sale_lang['s277'];
	}else{
		if($btime>$_G['timestamp']){
			$timetip=$it618_sale_lang['s278'];
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_sale_goods['it618_quantime1'];
		}else{
			$timetip=$it618_sale_lang['s279'];
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_sale_goods['it618_quantime2'];
		}
	}
	
	$it618_quanstr=$it618_sale_goods['it618_quanstr'];
	$quanstr=$it618_sale_goods['it618_quanstr'];
	
	$it618_price=$it618_sale_goods['it618_saleprice'];
	$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr);
}

if($it618_sale['sale_isjf']==1){
	$isjfok=1;
	
	if($it618_sale['sale_priceforjf']!=''){
		$tmparr=explode(",",$it618_sale['sale_priceforjf']);
		if(($it618_sale_goods['it618_saleprice']<$tmparr[0]||$it618_sale_goods['it618_saleprice']>$tmparr[1])){
			$isjfok=0;
		}
	}
}else{
	$isjfok=0;
}

if($isjfok==1){
	$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$it618_sale_goods['it618_quanstr']);
	$jfcount=round($it618_saleprice*$it618_sale['sale_jfbl']/100);
}

if($it618_sale['sale_isfl']>0){
	if($it618_sale_goods['it618_acsalebl']>0){
		if($it618_sale['sale_isfl']==1){
			$it618_fl=intval($it618_saleprice*$it618_sale_goods['it618_acsalebl']*$it618_sale['sale_moneybl']/10000);
			$it618_fl= $it618_fl.''.$creditname;
		}else{
			$it618_fl=round($it618_saleprice*$it618_sale_goods['it618_acsalebl']*$it618_sale['sale_moneybl']/10000,2);
			$it618_fl= $it618_fl.''.$it618_sale_lang['s125'];
		}
	}
}

if($it618_price>0)$zk=sprintf("%.2f", $it618_saleprice/$it618_price)*10;

if($_G['uid']>0){
	$tmpcount=C::t('#it618_sale#it618_sale_collect')->count_by_uid_pid($_G['uid'],$it618_sale_goods['id']);
	if($tmpcount>0){
		$collectname=$it618_sale_lang['s164'];
	}else{
		$collectname=$it618_sale_lang['s163'];
	}
}else{
	$collectname=$it618_sale_lang['s163'];
}

$metatitle=$it618_sale_goods['it618_name'].' - '.$metatitle;
$metakeywords=$it618_sale_goods['it618_seokeywords'];
$metadescription=$it618_sale_goods['it618_seodescription'];

$sale_saleuids=explode(",",$it618_sale['sale_saleuids']);
if(in_array($_G['uid'], $sale_saleuids)){
	$adminbl=$it618_sale_lang['t145'].'<font color=red>'.$it618_sale_goods['it618_acsalebl'].'%</font>';
}

$pagetype='product';
$_G['mobiletpl'][2]='/';
include template('it618_sale:sale_default');
?>