<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_sale/rewrite.php',DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_sale/message.php',DISCUZ_ROOT.'./source/plugin/it618_sale/config/message.php');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_sale_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_wapiconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_category` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_categorytmp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_category` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_materialclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_material` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cid` int(10) unsigned NOT NULL,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_materialid` int(10) unsigned NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_timecount` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_findkeyapi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_key` varchar(200) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_timecount` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_pname` varchar(200) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_salebl` float(9,2) NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_name` varchar(20) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_kddan` varchar(100) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_daoid` varchar(50) NOT NULL,
  `it618_saleid` varchar(50) NOT NULL,
  `it618_productid` varchar(50) NOT NULL,
  `it618_pname` varchar(200) NOT NULL,
  `it618_money` float(9,2) NOT NULL,
  `it618_salebl` float(9,2) NOT NULL,
  `it618_salemoney` float(9,2) NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_kd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_kf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_top` int(10) unsigned NOT NULL,
  `it618_width` int(10) unsigned NOT NULL,
  `it618_title` varchar(80) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_yytime` varchar(200) NOT NULL,
  `it618_dianhua` varchar(80) NOT NULL,
  `it618_kefuqq` varchar(80) NOT NULL,
  `it618_kefuwx` varchar(200) NOT NULL,
  `it618_kefuqqname` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_sale_apiwork` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_sale_class1'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_wapgoodscount', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_class1')." add `it618_wapgoodscount` int(10) unsigned NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_homeorder', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_class1')." add `it618_homeorder` int(10) unsigned NOT NULL;"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_sale_class2'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_goodscount', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_class2')." add `it618_goodscount` int(10) unsigned NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_wapgoodscount', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_class2')." add `it618_wapgoodscount` int(10) unsigned NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_homeorder', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_class2')." add `it618_homeorder` int(10) unsigned NOT NULL;"; 
	DB::query($sql);  
}

if(DB::result_first("select count(1) from ".DB::table('it618_sale_wapstyle'))==0){
	$sql = str_replace("\r\n", "\n", lang('plugin/it618_sale', 'it618_update1'));
	runquery($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_sale_goods'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_seokeywords', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_seokeywords` varchar(1000) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_seodescription', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_seodescription` varchar(1000) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_isurl', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_isurl` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_category', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_category` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_productid', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_productid` varchar(50) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_acsalebl', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_acsalebl` float(9,2) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_actime1', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_actime1` varchar(50) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_actime2', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_actime2` varchar(50) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_quanstr', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_quanstr` varchar(1000) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_quanurl', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_quanurl` varchar(1000) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_codeurl', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_codeurl` varchar(100) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_quancodeurl', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_quancodeurl` varchar(100) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_codetime', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_codetime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_quancodetime', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_quancodetime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_quantime1', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_quantime1` varchar(50) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_quantime2', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_quantime2` varchar(50) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_message1', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_message1` mediumtext NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_message2', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_message2` mediumtext NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_xgtime', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_xgcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_xgcount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_salecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_goods')." add `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_sale_money'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_fltype', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_money')." add `it618_fltype` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_sale_money')." add `it618_flmoney` float(9,2) NOT NULL;"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_sale_bottomnav'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_curimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_sale_bottomnav')." add `it618_curimg` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvaW5zdGFsbC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvdXBncmFkZS5waHA='));
?>