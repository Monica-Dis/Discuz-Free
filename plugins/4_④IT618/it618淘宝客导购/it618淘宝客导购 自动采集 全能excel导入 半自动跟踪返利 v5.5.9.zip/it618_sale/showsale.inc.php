<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_sale = $_G['cache']['plugin']['it618_sale'];
require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

if($_G['uid']<=0){
	if($_GET['wap']!=1){
		echo $it618_sale_lang['t120'].'it618_split'.it618_sale_getlang('s568').'<a href="member.php?mod=logging&action=login">'.it618_sale_getlang('s179').'</a> <a href="member.php?mod='.$RegName.'">'.it618_sale_getlang('s180').'</a>';return;
	}
}else{
	$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($_GET['pid']);
	
	if($it618_sale_goods['it618_description']!=''){
		$it618_description=$it618_sale_lang['s126'].$it618_sale_goods['it618_description'];
	}
	
	$username=C::t('#it618_sale#it618_sale_sale')->fetch_username_by_uid($_G['uid']);
	$name=C::t('#it618_sale#it618_sale_sale')->fetch_name_by_uid($_G['uid']);
	$tel=C::t('#it618_sale#it618_sale_sale')->fetch_tel_by_uid($_G['uid']);
	$addr=C::t('#it618_sale#it618_sale_sale')->fetch_addr_by_uid($_G['uid']);
	
	if($it618_sale['sale_isjf']==1){
		$isjfok=1;
		
		if($it618_sale['sale_priceforjf']!=''){
			$tmparr=explode(",",$it618_sale['sale_priceforjf']);
			if(($it618_sale_goods['it618_saleprice']<$tmparr[0]||$it618_sale_goods['it618_saleprice']>$tmparr[1])){
				$isjfok=0;
			}
		}
	}else{
		$isjfok=0;
	}
	
	if($isjfok==1){
		$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$it618_sale_goods['it618_quanstr']);
		$jfcount=round($it618_saleprice*$it618_sale['sale_jfbl']/100);
	}

	$creditnum=DB::result_first("select extcredits".$it618_sale['sale_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	if($creditnum=="")$creditnum=0;
}

$_G['mobiletpl'][2]='/';
include template('it618_sale:showsale');
?>