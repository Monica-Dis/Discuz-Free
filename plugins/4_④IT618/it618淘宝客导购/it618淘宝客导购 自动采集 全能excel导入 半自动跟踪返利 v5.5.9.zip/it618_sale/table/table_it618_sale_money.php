<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_sale_money extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_sale_money';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_saleid($saleid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_saleid=%s", array($this->_table, $saleid));
	}
	
	public function fetch_uid_by_id($id) {
		return DB::result_first("SELECT it618_uid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_saleid_daoid($saleid, $daoid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_saleid=%s AND it618_daoid=%s", array($this->_table, $saleid, $daoid));
	}
	
	public function count_by_saleid_daoid1($saleid, $daoid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_saleid=%s AND it618_daoid!=%s", array($this->_table, $saleid, $daoid));
	}
	
	public function update_count_money_by_saleid($count, $money, $salemoney, $saleid) {
		DB::query("update %t set it618_count=it618_count+%d,it618_money=it618_money+%f,it618_salemoney=it618_salemoney+%f WHERE it618_saleid=%s", array($this->_table, $count, $money, $salemoney, $saleid));
	}
	
	public function count_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		return DB::result_first("SELECT count(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function sum_score_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$tmp = DB::result_first("SELECT SUM(it618_score) FROM %t $condition[0]", $condition[1]);
		if($tmp=='')$tmp=0;
		return $tmp;
	}
	
	public function sum_flmoney_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$tmp = DB::result_first("SELECT SUM(it618_flmoney) FROM %t $condition[0]", $condition[1]);
		if($tmp=='')$tmp=0;
		return $tmp;
	}
	
	public function sum_money_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$tmp = DB::result_first("SELECT SUM(it618_money) FROM %t $condition[0]", $condition[1]);
		if($tmp=='')$tmp=0;
		return $tmp;
	}
	
	public function sum_salemoney_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$tmp = DB::result_first("SELECT SUM(it618_salemoney) FROM %t $condition[0]", $condition[1]);
		if($tmp=='')$tmp=0;
		return $tmp;
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$parameter[] = '%'.$it618_name.'%';
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "(it618_pname LIKE %s or it618_saleid LIKE %s or it618_productid LIKE %s)";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 'it618_time2>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 'it618_time2<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}

?>