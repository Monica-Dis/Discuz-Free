<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_sale_goods extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_sale_goods';
		$this->_pk = 'id';
		parent::__construct();
	}
	

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_id_state($id,$state) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d AND it618_state=%d", array($this->_table, $id, $state));
	}
	
	public function fetch_by_productid($productid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_productid=%s", array($this->_table, $productid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_it618_views_by_id($id) {
		DB::query("UPDATE %t SET it618_views=it618_views+1 WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_it618_codeurl_by_id($codeurl,$time,$id) {
		DB::query("UPDATE %t SET it618_codeurl=%s,it618_codetime=%d WHERE id=%d", array($this->_table, $codeurl, $time, $id));
	}
	
	public function update_it618_quancodeurl_by_id($quancodeurl,$time,$id) {
		DB::query("UPDATE %t SET it618_quancodeurl=%s,it618_quancodetime=%d WHERE id=%d", array($this->_table, $quancodeurl, $time, $id));
	}
	
	public function update_it618_collect_by_id($id) {
		$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_sale_collect')." WHERE it618_pid=%d", array($id));
		DB::query("UPDATE %t SET it618_collect=%d WHERE id=%d", array($this->_table, $count, $id));
		return $count;
	}
	
	public function update_it618_salecount_by_id($id) {
		$count=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_sale_sale')." WHERE it618_state!=5 and it618_pid=%d", array($id));
		if($count=='')$count=0;
		DB::query("UPDATE %t SET it618_salecount=%d WHERE id=%d", array($this->_table, $count, $id));
		return $count;
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $class1 = 0, $class2 = 0, $it618_name = '', $price1 = 0, $price2 = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $class1, $class2, $it618_name, $price1, $price2);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $class1 = 0, $class2 = 0, $it618_name = '', $price1 = 0, $price2 = 0, $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $class1, $class2, $it618_name, $price1, $price2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $class1 = 0, $class2 = 0, $it618_name = '', $price1 = 0, $price2 = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($class1)) {
			$parameter[] = $class1;
			$wherearr[] = 'it618_class1_id=%d';
		}
		if(!empty($class2)) {
			$parameter[] = $class2;
			$wherearr[] = 'it618_class2_id=%d';
		}
		if(!empty($it618_name)) {
			$tmparr=explode(" ",$it618_name);
			for($n=0;$n<count($tmparr);$n++){
				$parameter[] = '%'.$tmparr[$n].'%';
				$parameter[] = '%'.$tmparr[$n].'%';
				$tmpsql.='it618_name LIKE %s OR it618_description LIKE %s OR ';
			}
			$tmpsql.='@';
			$tmpsql=str_replace(" OR @","",$tmpsql);
			$wherearr[] = '('.$tmpsql.')';
		}
		if(!empty($price1)) {
			$parameter[] = $price1;
			$wherearr[] = 'it618_saleprice>=%d';
		}
		if(!empty($price2)) {
			$parameter[] = $price2;
			$wherearr[] = 'it618_saleprice<=%d';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}

?>