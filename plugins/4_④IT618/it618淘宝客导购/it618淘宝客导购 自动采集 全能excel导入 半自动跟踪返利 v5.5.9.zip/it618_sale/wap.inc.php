<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_sale = $_G['cache']['plugin']['it618_sale'];
$metakeywords = $it618_sale['seokeywords'];
$metadescription = $it618_sale['seodescription'];
$sitetitle=$it618_sale['seotitle'];
$creditname=$_G['setting']['extcredits'][$it618_sale['sale_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

if(!sale_is_mobile()){
	$ispc=1;
}

$waphome=it618_sale_getrewrite('sale_wap','','plugin.php?id=it618_sale:wap');
$wapsearch=it618_sale_getrewrite('sale_wap','search','plugin.php?id=it618_sale:wap&pagetype=search');
$mysaleurl=it618_sale_getrewrite('sale_wap','mysale','plugin.php?id=it618_sale:wap&pagetype=mysale');
$wapu=it618_sale_getrewrite('sale_wap','u','plugin.php?id=it618_sale:wap&pagetype=u');

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_sale#it618_sale_wapstyle')->count_by_isok_search();
$it618_sale_wapstyle=C::t('#it618_sale#it618_sale_wapstyle')->fetch_by_isok_search();


if(isset($_GET['pagetype'])){
	$pagetype=$_GET['pagetype'];
}else{
	$pagetype='sale';
	$navtitle=$sitetitle;
}

if($it618_sale['sale_style']>2){
	$salestyle=getcookie('salestyle');
	if($salestyle==''){
		if($it618_sale['sale_style']==3)$salestyle='1';else $salestyle='2';
	}

	if($pagetype=='sale'||$pagetype=='search'||$pagetype=='mycollect'){
		if($salestyle=='1')$salestyle1='2';else $salestyle1='1';
		$salestylestrtmp='<div class="style-btn" onClick="salestyle()"><i class="icon-style'.$salestyle1.'"></i></div>';
	}
}else{
	if($it618_sale['sale_style']==1)$salestyle='1';else $salestyle='2';
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_sale_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_sale_bottomnav = DB::fetch($query)) {
	$it618_url=$it618_sale_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$it618_url=str_replace("{waphome}",$waphome,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='sale'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapsearch}",$it618_url);
	$it618_url=str_replace("{wapsearch}",$wapsearch,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='search'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapmoney}",$it618_url);
	$tmpurl=it618_sale_getrewrite('sale_wap','money','plugin.php?id=it618_sale:wap&pagetype=money');
	$it618_url=str_replace("{wapmoney}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='money'){
			$iscur=1;
		}
	}
	
	if($it618_sale['sale_isfl']==0&&$it618_url=="{wapmoney}")continue;
	
	if($it618_sale_bottomnav['id']==5)$it618_url=it618_sale_getrewrite('sale_wap','u','plugin.php?id=it618_sale:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_sale_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_sale_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_sale_bottomnav['it618_color'].'">'.$it618_sale_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_sale_bottomnav['it618_img'];
		$it618_title=$it618_sale_bottomnav['it618_title'];
	}
	
	if($it618_sale_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_sale_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$href='href="'.$it618_url.'"';
		if($_G['uid']<=0&&$it618_sale_bottomnav['id']==5){
			$href='href="javascript:" onclick="userlongin()"';
		}
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a '.$href.'style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$uurl=it618_sale_getrewrite('sale_wap','u','plugin.php?id=it618_sale:wap&pagetype=u');
$uhref='href="'.$uurl.'"';
if($_G['uid']<=0){
	$href='href="javascript:" onclick="userlongin()"';
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

if($_G['uid']>0){
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_sale_getlang('s178').'</a></li>';
	$strusr='<a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="btn btn-weak">'.it618_sale_getlang('s178').'</a> <a href="'.it618_sale_rewriteurl($_G['uid']).'" target="_blank">'.it618_sale_getusername($_G['uid']).'</a></font>';
}


$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_sale['sale_appid']);
	$wx_secret=trim($it618_sale['sale_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
			if($wx_isok!=1)$wx_appid='';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){
	if($pagetype=='product'){
		$pid=intval($_GET['cid']);
		$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($pid);
		$wxshare_title=$it618_sale_goods['it618_name'];
		$wxshare_imgUrl=$it618_sale_goods['it618_picsmall'];
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_sale_goods['it618_description'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
		
	}else{
		$wxshare_title=$it618_sale['seotitle'];
		if($it618_sale['sale_wxlogo']!=''){
			$wxshare_imgUrl=$it618_sale['sale_wxlogo'];
		}else{
			$wxshare_imgUrl=$it618_sale['sale_logo'];
			$tmparr=explode('src="',$wxshare_imgUrl);
			$tmparr1=explode('"',$tmparr[1]);
			$wxshare_imgUrl=$tmparr1[0];
		}
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_sale['seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_sale_getrewrite('sale_wap','','plugin.php?id=it618_sale:wap');
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_sale/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl, DISCUZ_ROOT);
		$signPackage = $wxshare->getSignPackage();
	}
}

$moneyurl=it618_sale_getrewrite('sale_wap','money','plugin.php?id=it618_sale:wap&pagetype=money');
$mymoneyurl=it618_sale_getrewrite('sale_wap','mymoney','plugin.php?id=it618_sale:wap&pagetype=mymoney');

$wapbottomsubnav=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('wapbottomsubnavdefault');
$wapfooter=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('wapfooter');

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
	if($appurl=it618_members_apploginok($_GET['token'])){
		dheader("location:$appurl");
	}
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_wapad=it618_group_getad($_GET['id'],1);
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/it618_api.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_sale/wap/'.$pagetype.'.inc.php';
?>