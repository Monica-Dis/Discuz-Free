<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G,$IsChat;
if($reabc[4]!='8')return;

loadcache('plugin');
$it618_sale = $_G['cache']['plugin']['it618_sale'];

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function/it618_sale.func.php';

if($reabc[9]!='e')return;
$ppp = $it618_sale['pagecount'];
$page = max(1, intval($_GET['page']));
if($_GET['findbtn']==1)$page=1;
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=0;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<=24;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[0]=$it618_sale_lang['s7'];
$strtmptitle[1]=$it618_sale_lang['s2'];
$strtmptitle[2]=$it618_sale_lang['s3'];
$strtmptitle[3]=$it618_sale_lang['s4'];
$strtmptitle[4]=$it618_sale_lang['s5'];
$strtmptitle[5]=$it618_sale_lang['s6'];
$strtmptitle[6]=$it618_sale_lang['s8'];
$strtmptitle[7]=$it618_sale_lang['s200'];
$strtmptitle[8]=$it618_sale_lang['s201'];
$strtmptitle[9]=$it618_sale_lang['s202'];
$strtmptitle[10]=$it618_sale_lang['s210'];
$strtmptitle[11]=$it618_sale_lang['s40'];
$strtmptitle[13]=$it618_sale_lang['s247'];
$strtmptitle[14]=$it618_sale_lang['s418'];
$strtmptitle[15]=$it618_sale_lang['s268'];
$strtmptitle[16]=$it618_sale_lang['s269'];
$strtmptitle[17]=$it618_sale_lang['s499'];
$strtmptitle[18]=$it618_sale_lang['s519'];
$strtmptitle[19]=$it618_sale_lang['s566'];
$strtmptitle[20]=$it618_sale_lang['s567'];
$strtmptitle[21]=$it618_sale_lang['s676'];
$strtmptitle[22]=$it618_sale_lang['s678'];
$strtmptitle[23]=$it618_sale_lang['s26'];
$strtmptitle[24]=$it618_sale_lang['s270'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_hot&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>
<li '.$strtmp[7].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=7'.$urls.'"><span>'.$strtmptitle[7].'</span></a></li>
<li '.$strtmp[13].'><a href="'.$hosturl.'plugins&cp=admin_nav&cp1=13'.$urls.'"><span>'.$strtmptitle[13].'</span></a></li>
<li '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_gonggao&cp1=8'.$urls.'"><span>'.$strtmptitle[8].'</span></a></li>';


if($IsChat!=1)echo '<li '.$strtmp[16].'><a href="'.$hosturl.'plugins&cp=admin_kf&cp1=16'.$urls.'"><span>'.$strtmptitle[16].'</span></a></li>';

echo '<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=1'.$urls.'"><span>'.$strtmptitle[1].'</span></a></li>
<li '.$strtmp[11].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=11'.$urls.'"><span>'.$strtmptitle[11].'</span></a></li>
<li '.$strtmp[19].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=19'.$urls.'"><span>'.$strtmptitle[19].'</span></a></li>
<li '.$strtmp[20].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=20'.$urls.'"><span>'.$strtmptitle[20].'</span></a></li>
<li '.$strtmp[17].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=17'.$urls.'"><span>'.$strtmptitle[17].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=2'.$urls.'"><span>'.$strtmptitle[2].'</span></a></li>
<li '.$strtmp[9].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=9'.$urls.'"><span>'.$strtmptitle[9].'</span></a></li>
<li '.$strtmp[24].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=24'.$urls.'"><span>'.$strtmptitle[24].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=3'.$urls.'"><span>'.$strtmptitle[3].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=4'.$urls.'"><span>'.$strtmptitle[4].'</span></a></li>
<li '.$strtmp[15].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=15'.$urls.'"><span>'.$strtmptitle[15].'</span></a></li>
<li '.$strtmp[14].'><a href="'.$hosturl.'plugins&cp=admin_kd&cp1=14'.$urls.'"><span>'.$strtmptitle[14].'</span></a></li>
<li '.$strtmp[18].'><a href="'.$hosturl.'plugins&cp=admin_message&cp1=18'.$urls.'"><span>'.$strtmptitle[18].'</span></a></li>
<li '.$strtmp[6].'><a href="'.$hosturl.'plugins&cp=admin_rewrite&cp1=6'.$urls.'"><span>'.$strtmptitle[6].'</span></a></li>
<li '.$strtmp[10].'><a href="'.$hosturl.'plugins&cp=admin_diy&cp1=10'.$urls.'"><span>'.$strtmptitle[10].'</span></a></li>
<li '.$strtmp[21].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=21'.$urls.'"><span>'.$strtmptitle[21].'</span></a></li>
<li '.$strtmp[22].'><a href="'.$hosturl.'plugins&cp=admin_aliyunoss&cp1=22'.$urls.'"><span>'.$strtmptitle[22].'</span></a></li>
<li '.$strtmp[23].'><a href="'.$hosturl.'plugins&cp=admin_taobao&cp1=23'.$urls.'"><span>'.$strtmptitle[23].'</span></a></li>
</ul></div>';

$cparray = array('admin_hot', 'admin_set', 'admin_nav', 'admin_gonggao', 'admin_kf', 'admin_focus', 'admin_kd', 'admin_message', 'admin_rewrite', 'admin_diy', 'admin_aliyunoss', 'admin_taobao');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_hot' : $_GET['cp'];

if($cp1==0)$setname='hotclassgoods';
if($cp1==1)$setname='footer';
if($cp1==11)$setname='wapfooter';
if($cp1==7)$setname='topnav';
if($cp1==16)$setname='rightkefu';
if($cp1==17)$setname='defalutgoodsmessage';
if($cp1==19)$setname='productvalue';
if($cp1==20)$setname='wapproductvalue';
if($cp1==21)$setname='waphomead';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); //dism��taobao��com
?>