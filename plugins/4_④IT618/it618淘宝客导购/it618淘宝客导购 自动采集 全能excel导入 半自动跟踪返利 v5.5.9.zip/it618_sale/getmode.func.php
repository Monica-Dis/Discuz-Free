<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

function it618_sale_getmodecontent($modetype,$modecode,$modecount){
	global $_G;
	$it618_sale = $_G['cache']['plugin']['it618_sale'];
	
	$tmparr=explode("[loop]",$modecode);
	$tmparr1=explode("[/loop]",$tmparr[1]);
	
	if($modetype=='product_new'||$modetype=='product_hot'||$modetype=='product_view'||$modetype=='product_rand'){
		if($modetype=='product_new')$orderby='id desc';
		if($modetype=='product_hot')$orderby='it618_collect desc';
		if($modetype=='product_view')$orderby='it618_views desc';
		if($modetype=='product_rand')$orderby='rand()';

		foreach(C::t('#it618_sale#it618_sale_goods')->fetch_all_by_search(
			"it618_state=1 and (it618_actime1='' or (it618_actime1!='' and UNIX_TIMESTAMP(it618_actime1)<=".$_G['timestamp']."))",$orderby,0,0,'',0,0,0,$modecount
		) as $it618_sale_goods) {
			
			$it618_quanstr='';$it618_quandivstr='';
			if($it618_sale_goods['it618_quantime1']!=''){
				$it618_quanstr=$it618_sale_goods['it618_quanstr'];
				$it618_quandivstr='<div class="divquan">'.$it618_sale_goods['it618_quanstr'].'</div>';
			}
			
			$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
			$tmpstr=str_replace("{pname}",$it618_sale_goods['it618_name'],$tmparr1[0]);
			$tmpstr=str_replace("{pdev}",$it618_sale_goods['it618_description'],$tmpstr);
			$tmpstr=str_replace("{ppicsrc}",$it618_sale_goods['it618_pic'],$tmpstr);
			$tmpstr=str_replace("{puprice}",$it618_sale_goods['it618_saleprice'],$tmpstr);
			$tmpstr=str_replace("{pprice}",$it618_sale_goods['it618_price'],$tmpstr);
			$tmpstr=str_replace("{pviews}",$it618_sale_goods['it618_views'],$tmpstr);
			$tmpstr=str_replace("{pcollect}",$it618_sale_goods['it618_collect'],$tmpstr);
			$tmpstr=str_replace("{purl}",$tmpurl,$tmpstr);
			$tmpstr=str_replace("{quan}",$it618_quanstr,$tmpstr);
			$tmpstr=str_replace("{quandiv}",$it618_quandivstr,$tmpstr);
			
			$content.=$tmpstr;
			
		}
	}
	
	$content=$tmparr[0].$content.$tmparr1[1];
	$content=str_replace("{siteurl}",$_G['siteurl'],$content);
	
	return $content;
}

?>