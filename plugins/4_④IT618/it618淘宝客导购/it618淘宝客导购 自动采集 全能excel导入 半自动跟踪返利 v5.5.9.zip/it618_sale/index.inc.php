<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/sale_default.func.php';

if(sale_is_mobile()){ 
	$tmpurl=it618_sale_getrewrite('sale_wap','','plugin.php?id=it618_sale:wap');
	dheader("location:$tmpurl");
}

$tmpidsarr=explode(',',$hotclassgoods[0]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_sale_class2=C::t('#it618_sale#it618_sale_class2')->fetch_by_id($id);
	$tmpurl=it618_sale_getrewrite('sale_list',$it618_sale_class2['it618_class1_id'].'@'.$id,'plugin.php?id=it618_sale:list&class1='.$it618_sale_class2['it618_class1_id'].'&class2='.$id);
	$homehotclass.='<li><a href="'.$tmpurl.'">'.$it618_sale_class2['it618_classname'].'</a></li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_sale_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_sale_gonggao = DB::fetch($query)) {
	$it618_title=$it618_sale_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,80,'...');
	
	if($it618_sale_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_sale_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_sale_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_sale_gonggao['it618_url'].'" target="_blank" title="'.$it618_sale_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

foreach(C::t('#it618_sale#it618_sale_focus')->fetch_all_by_type_order(9) as $it618_sale_focus) {
	if($it618_sale_focus['it618_url']!=''){
		$str_focus.='<li><a href="'.$it618_sale_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="940" height="358" /></a></li>';
	}else{
		$str_focus.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="940" height="358" /></li>';
	}
}

foreach(C::t('#it618_sale#it618_sale_focus')->fetch_all_by_type_order(3) as $it618_sale_focus) {
	if($it618_sale_focus['it618_url']!=''){
		$str_focus3.='<li><a href="'.$it618_sale_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="223" height="231" /></a></li>';
	}else{
		$str_focus3.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="223" height="231" /></li>';
	}
}

foreach(C::t('#it618_sale#it618_sale_focus')->fetch_all_by_type_order(4) as $it618_sale_focus) {
	if($it618_sale_focus['it618_url']!=''){
		$str_focus4.='<li><a href="'.$it618_sale_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="223" height="231" /></a></li>';
	}else{
		$str_focus4.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="223" height="231" /></li>';
	}
}

$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_it618_sale_home.php';
if(($_G['timestamp'] - @filemtime($cache_file)) > $it618_sale['sale_hometime']||$it618_sale['sale_hometime']==0) {

	for($i=1;$i<=2;$i++){
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class'.$i)." WHERE it618_goodscount>0 ORDER BY it618_homeorder");
		while($it618_sale_class = DB::fetch($query1)) {
			$classid1=0;$classid2=0;
			
			if($i==1){
				$classid1=$it618_sale_class['id'];
				$classname=$it618_sale_class['it618_classname'];
			}else{
				$classid1=$it618_sale_class['it618_class1_id'];
				$classid2=$it618_sale_class['id'];
				
				$classname1=C::t('#it618_sale#it618_sale_class1')->fetch_it618_name_by_id($classid1);
	
				$classname=$classname1.' '.$it618_sale_class['it618_classname'];
			}
			
			$tmpurl=it618_sale_getrewrite('sale_list',$classid1.'@'.$classid2,'plugin.php?id=it618_sale:list&class1='.$classid1.'&class2='.$classid2);
			$str_goods.='<div class="index-floor">
							<h2 class="index-floor-title" style="background-color:#f6f6f6;padding-top:10px;padding-bottom:10px">
								<a href="'.$tmpurl.'" style="float:left;margin-left:6px">'.$classname.'</a>
								<div class="fr" style="margin-right:6px">
									{it618classtj}
									<a href="'.$tmpurl.'" target="_blank">'.it618_sale_getlang('s167').'&nbsp;<em>&gt;&gt;</em></a>
								</div>
							</h2>
							<div class="index-goods-list cl">
								{it618goods}
							</div>
							<div class="floor-more"><a href="'.$tmpurl.'">'.it618_sale_getlang('s168').$classname.'&nbsp;&gt;&gt;</a></div>
						</div>';
			
			$it618goods='';
			foreach(C::t('#it618_sale#it618_sale_goods')->fetch_all_by_search(
				"it618_state=1 and (it618_actime1='' or (it618_actime1!='' and UNIX_TIMESTAMP(it618_actime1)<=".$_G['timestamp']."))",'UNIX_TIMESTAMP(it618_quantime2)-'.$_G['timestamp'].',id desc',$classid1,$classid2,'',0,0,$startlimit,$it618_sale_class['it618_goodscount']
			) as $it618_sale_goods) {
		
				$it618_price1='<em>&yen;</em>'.$it618_sale_goods['it618_saleprice'];
				$it618_price2='';
				if($it618_sale_goods['it618_price']>0)$it618_price2='<span class="money">&yen;<del>'.$it618_sale_goods['it618_price'].'</del></span>';
				
				$it618_quanstr='';
				if($it618_sale_goods['it618_quantime1']!=''){
		
					$it618_quanstr='<div class="divquan">'.$it618_sale_goods['it618_quanstr'].'</div>';
					$quanstr=$it618_sale_goods['it618_quanstr'];
					
					$it618_price1='<em>&yen;</em>'.it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr).' <span style="font-size:12px;">'.$it618_sale_lang['s299'].'</span>';
					$it618_price2='<span class="money">&yen;<del>'.$it618_sale_goods['it618_saleprice'].'</del></span>';
		
				}
				
				$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
				$it618goods.='<div class="index-goods">
									'.$it618_quanstr.'
									<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
										<img class="dynload" imgsrc="'.$it618_sale_goods['it618_pic'].'" src="source/plugin/it618_sale/images/a.gif" alt="'.$it618_sale_goods['it618_name'].'"/>
										<span class="index-goods-place">'.$it618_sale_goods['it618_description'].'</span>
									</a>
									<h3>
										<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_sale_goods['it618_name'].'">'.$it618_sale_goods['it618_name'].'</a>
										<a class="index-goods-text" href="'.$tmpurl.'" target="_blank" title="'.$it618_sale_goods['it618_description'].'">'.it618_getjfblcount($it618_sale_goods).'</a>
									</h3>
									<div class="index-goods-info">
										<span class="price" style="color:red">'.$it618_price1.'</span>
										'.$it618_price2.'
									</div>
								</div>';
				
			}
			
			$str_goods=str_replace("{it618classtj}",$it618classtj,$str_goods);
			$str_goods=str_replace("{it618goods}",$it618goods,$str_goods);
		}
	}
    
	if($it618_sale['sale_hometime']>0){
		require_once libfile('function/cache');
		
		$cacheArray .= "\$str_goods=".arrayeval($str_goods).";\n";
		writetocache('it618_sale1', $cacheArray);
	}
}else{
	include_once DISCUZ_ROOT.'./data/sysdata/cache_it618_sale_home.php';
}

$pagetype='index';
$_G['mobiletpl'][2]='/';
include template('it618_sale:sale_default');
?>