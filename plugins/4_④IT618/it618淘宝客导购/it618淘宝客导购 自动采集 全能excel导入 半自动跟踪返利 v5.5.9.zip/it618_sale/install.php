<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_sale_class1`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_class1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL,
  `it618_wapgoodscount` int(10) unsigned NOT NULL,
  `it618_homeorder` int(10) unsigned NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_class2`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_class2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL,
  `it618_wapgoodscount` int(10) unsigned NOT NULL,
  `it618_homeorder` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_category`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_category` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_categorytmp`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_categorytmp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_category` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_materialclass`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_materialclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_material`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_material` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cid` int(10) unsigned NOT NULL,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_materialid` int(10) unsigned NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_timecount` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_findkey`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_findkeyapi`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_findkeyapi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_key` varchar(200) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_timecount` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_style`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_style` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_category` int(10) unsigned NOT NULL,
  `it618_productid` varchar(50) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_acsalebl` float(9,2) NOT NULL,
  `it618_actime1` varchar(50) NOT NULL,
  `it618_actime2` varchar(50) NOT NULL,
  `it618_pcurl` varchar(1000) NOT NULL,
  `it618_wapurl` varchar(1000) NOT NULL,
  `it618_codeurl` varchar(1000) NOT NULL,
  `it618_codetime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_quanstr` varchar(1000) NOT NULL,
  `it618_quanurl` varchar(1000) NOT NULL,
  `it618_quancodeurl` varchar(1000) NOT NULL,
  `it618_quancodetime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_quantime1` varchar(50) NOT NULL,
  `it618_quantime2` varchar(50) NOT NULL,
  `it618_message1` mediumtext NOT NULL,
  `it618_message2` mediumtext NOT NULL,
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_description` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_pic` varchar(255) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_collect` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isurl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_pname` varchar(200) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_salebl` float(9,2) NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_name` varchar(20) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_kddan` varchar(100) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_money`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_daoid` varchar(50) NOT NULL,
  `it618_saleid` varchar(50) NOT NULL,
  `it618_productid` varchar(50) NOT NULL,
  `it618_pname` varchar(200) NOT NULL,
  `it618_money` float(9,2) NOT NULL,
  `it618_salebl` float(9,2) NOT NULL,
  `it618_salemoney` float(9,2) NOT NULL,
  `it618_fltype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_flmoney` float(9,2) NOT NULL,
  `it618_score` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_kd`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_kd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_collect`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_wapiconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_wapiconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_nav`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_kf`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_kf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_isok` int(10) unsigned NOT NULL,
  `it618_top` int(10) unsigned NOT NULL,
  `it618_width` int(10) unsigned NOT NULL,
  `it618_title` varchar(80) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_yytime` varchar(200) NOT NULL,
  `it618_dianhua` varchar(80) NOT NULL,
  `it618_kefuqq` varchar(80) NOT NULL,
  `it618_kefuwx` varchar(200) NOT NULL,
  `it618_kefuqqname` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_apiwork`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_apiwork` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvZGlzY3V6X3BsdWdpbl9pdDYxOF9zYWxlX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvdXBncmFkZS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3NhbGUvaW5zdGFsbC5waHA='));
?>