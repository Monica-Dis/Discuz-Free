<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/sale_function.func.php';

if($pagetype=='search'){
	if($_GET['sw']==''||!isset($_GET['sw']))$searchsw=$it618_sale['sale_sw'];else $searchsw=dhtmlspecialchars($_GET['sw']);
}
if($searchsw!='')$sw=' style="display:none"';

if($searchsw!=''&&$_GET['page']<1){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
	}
	$findapiuids=explode(",",$findapiuids);
	if(in_array($_G['uid'],$findapiuids)){
		require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
		it618_sale_addquangoods(1,$searchsw);
	}
}

$homeurl=it618_sale_getrewrite('sale_home','','plugin.php?id=it618_sale:index');
$searchurl=it618_sale_getrewrite('sale_search','','plugin.php?id=it618_sale:search');

$sale_logo=str_replace("{homeurl}",$homeurl,$it618_sale['sale_logo']);

$sale_hotsw=explode(',',$it618_sale['sale_hotsw']);
for($i=0;$i<count($sale_hotsw);$i++){
	$tmpurl=it618_sale_getrewrite('sale_search','','plugin.php?id=it618_sale:search&sw='.urlencode($sale_hotsw[$i]),'?sw='.urlencode($sale_hotsw[$i]));
	$hotsw.='<a href="'.$tmpurl.'">'.$sale_hotsw[$i].'</a>';
}

$hotclassgoods=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('hotclassgoods');
$topnav=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('topnav');
$hotclassgoods=explode('@@@',$hotclassgoods);

$stylecount=C::t('#it618_sale#it618_sale_style')->count_by_isok();
$it618_sale_style=C::t('#it618_sale#it618_sale_style')->fetch_by_isok();

$topgoodscount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_sale_goods')." WHERE it618_state=1");

$footer=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('footer');

foreach(C::t('#it618_sale#it618_sale_focus')->fetch_all_by_type_order(2) as $it618_sale_focus) {
	if($it618_sale_focus['it618_url']!=''){
		$str_focus2.='<li><a href="'.$it618_sale_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="1200" height="150" /></a></li>';
	}else{
		$str_focus2.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="1200" height="150" /></li>';
	}
}

$n=1;
$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class1')." ORDER BY it618_order");
while($it618_sale_class1 = DB::fetch($query1)) {
	$tmpurl1=it618_sale_getrewrite('sale_list',$it618_sale_class1['id'],'plugin.php?id=it618_sale:list&class1='.$it618_sale_class1['id']);
	
	if($it618_sale_class1['it618_color']!="")
	$tmpname='<font color='.$it618_sale_class1['it618_color'].'>'.$it618_sale_class1['it618_classname'].'</font>';else $tmpname=$it618_sale_class1['it618_classname'];
	
	if($n<=9&&$it618_sale_class1['it618_goodscount']>0)$str_nav.='<a href="'.$tmpurl1.'">'.$tmpname.'</a>';
	
	$goodscount=C::t('#it618_sale#it618_sale_goods')->count_by_search("it618_state=1 and (it618_actime1='' or (it618_actime1!='' and UNIX_TIMESTAMP(it618_actime1)<=".$_G['timestamp']."))",'',$it618_sale_class1['id']);
	$str_class.='<div class="sort">
					<div class="sort-menu"><em class="sort-icon"></em><a class="title" href="'.$tmpurl1.'">'.$tmpname.'</a><span style="color:#999;line-height:26px">('.$goodscount.')</span></div>
					{it618classall}
				</div>';
	$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_sale_class2')." where it618_class1_id=".$it618_sale_class1['id']." ORDER BY it618_order");
	$it618classall='';
	while($it618_sale_class2 = DB::fetch($query2)) {
		if($it618_sale_class2['it618_color']!="")
		$tmpname='<font color='.$it618_sale_class2['it618_color'].'>'.$it618_sale_class2['it618_classname'].'</font>';else $tmpname=$it618_sale_class2['it618_classname'];
		
		$tmpurl2=it618_sale_getrewrite('sale_list',$it618_sale_class1['id'].'@'.$it618_sale_class2['id'],'plugin.php?id=it618_sale:list&class1='.$it618_sale_class1['id'].'&class2='.$it618_sale_class2['id']);
		if($n<=9&&$it618_sale_class2['it618_goodscount']>0)$str_nav.='<a href="'.$tmpurl2.'">'.$it618_sale_class2['it618_classname'].'</a>';
		$it618classall.='<li><a href="'.$tmpurl2.'">'.$tmpname.'</a></li>';
		if($i1ii1[5]!='_')return;
	}
	
	if($it618classall!=''){
		$str_class=str_replace("{it618classall}",'<div class="sort-con">
						<div class="sort-con-left">
							<h4><a href="'.$tmpurl1.'">'.$it618_sale_class1['it618_classname'].'</a></h4>
							<ul class="sort-link02 cl">
								'.$it618classall.'
							</ul>
						</div>
					  </div>',$str_class);
	}else{
		$str_class=str_replace("{it618classall}",'',$str_class);
	}

	$n=$n+1;
}

$str_class.='<div class="sort-lottery">
				<div class="sort-menu" style="height:0;padding:0; margin:0"></div>
			 </div>';

$count = C::t('#it618_sale#it618_sale_nav')->count_by_search1();
if($count>0){
	$str_nav='';
	foreach(C::t('#it618_sale#it618_sale_nav')->fetch_all_by_search1() as $it618_sale_nav) {
		if($it618_sale_nav['it618_color']!="")
		$tmpname='<font color='.$it618_sale_nav['it618_color'].'>'.$it618_sale_nav['it618_name'].'</font>';else $tmpname=$it618_sale_nav['it618_name'];
		
		if($it618_sale_nav['it618_target']==1)$it618_target=' target="_blank"';else $it618_target='';
		
		$str_nav.='<a href="'.$it618_sale_nav['it618_url'].'"'.$it618_target.'>'.$tmpname.'</a>';
	}
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/it618_api.func.php';
?>