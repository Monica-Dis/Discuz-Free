<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/sale_default.func.php';

$class1=intval($_GET['class1']);
$class2=intval($_GET['class2']);
$price=intval($_GET['price']);
$order=intval($_GET['order']);

if(sale_is_mobile()){ 
	if($class2>0){
		$tmpurl=it618_sale_getrewrite('sale_wap','search@'.$class1.'@'.$class2,'plugin.php?id=it618_sale:wap&pagetype=search&cid1='.$class1.'&cid2='.$class2);
	}else{
		$tmpurl=it618_sale_getrewrite('sale_wap','search@'.$class1,'plugin.php?id=it618_sale:wap&pagetype=search&cid1='.$class1);
	}
	dheader("location:$tmpurl");
}

$tmpidsarr=explode(',',$hotclassgoods[1]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_sale_class2=C::t('#it618_sale#it618_sale_class2')->fetch_by_id($id);
	$tmpurl=it618_sale_getrewrite('sale_list',$it618_sale_class2['it618_class1_id'].'@'.$id,'plugin.php?id=it618_sale:list&class1='.$it618_sale_class2['it618_class1_id'].'&class2='.$id);
	$listhotclass.='<li><a href="'.$tmpurl.'">'.$it618_sale_class2['it618_classname'].'</a></li>';
}

foreach(C::t('#it618_sale#it618_sale_focus')->fetch_all_by_type_order(5) as $it618_sale_focus) {
	if($it618_sale_focus['it618_url']!=''){
		$str_focus5.='<li><a href="'.$it618_sale_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus5.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_sale/images/a.gif" imgsrc="'.$it618_sale_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

if($class1>0){
	$class1name=C::t('#it618_sale#it618_sale_class1')->fetch_it618_name_by_id($class1);
	$classtitle.=$class1name.' ';
	$tmpurl=it618_sale_getrewrite('sale_list','0@0@'.$price.'@'.$order,'plugin.php?id=it618_sale:list&class1=0&class2=0&price='.$price.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$class1name.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

if($class2>0){
	$tmpname=C::t('#it618_sale#it618_sale_class2')->fetch_it618_name_by_id($class2);
	$classtitle.=$tmpname.' ';
	$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@0@'.$price.'@'.$order,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2=0&price='.$price.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

$pricename[0]=it618_sale_getlang('s167');$pricename[1]='50'.it618_sale_getlang('s171');$pricename[2]='50-100'.it618_sale_getlang('s125');$pricename[3]='100-200'.it618_sale_getlang('s125');$pricename[4]='200-300'.it618_sale_getlang('s125');$pricename[5]='300'.it618_sale_getlang('s172');
if($price>0){
	$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@'.$class2.'@0@'.$order,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2='.$class2.'&price=0&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$pricename[$price].'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

$listnav.='@';
$listnav=str_replace('<i class="crumb-icon"></i>@','',$listnav);

if($class1==0)$current=' class="current"';else $current='';
$tmpurl=it618_sale_getrewrite('sale_list','0@0@'.$price.'@'.$order,'plugin.php?id=it618_sale:list&class1=0&class2=0&price='.$price.'&order='.$order);
$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_sale_getlang('s167').'</a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_sale_class1')." ORDER BY it618_order");
while($it618_sale_class1 = DB::fetch($query)) {
	if($class1==$it618_sale_class1['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_sale_getrewrite('sale_list',$it618_sale_class1['id'].'@0@'.$price.'@'.$order,'plugin.php?id=it618_sale:list&class1='.$it618_sale_class1['id'].'&class2=0&price='.$price.'&order='.$order);
	$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_sale_class1['it618_classname'].'</a></li>';
}

if($class1>0){
	if($class2==0)$current=' class="current"';else $current='';
	$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@0@'.$price.'@'.$order,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2=0&price='.$price.'&order='.$order);
	$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_sale_getlang('s167').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_class2')." where it618_class1_id=".$class1." ORDER BY it618_order");
	while($it618_sale_class2 = DB::fetch($query)) {
		if($class2==$it618_sale_class2['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@'.$it618_sale_class2['id'].'@'.$price.'@'.$order,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2='.$it618_sale_class2['id'].'&price='.$price.'&order='.$order);
		$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_sale_class2['it618_classname'].'</a></li>';
	}
}

$n=2;$price1=0;$price2=0;
if($price==0){
	$current=' class="current"';
	$price1=0;$price2=0;
}else{
	$current='';
}
$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@'.$class2.'@0@'.$order,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2='.$class2.'&price=0&order='.$order);
$str_price.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_sale_lang['s167'].'</a></li>';

$pricearr=explode("|",str_replace(array("\r\n", "\r", "\n"), '|', $it618_sale['sale_findprice']));
for($i=1;$i<=count($pricearr);$i++){
	$pricearr1=explode(",",$pricearr[$i-1]);
	if($i==1){
		if($price==1){
			$current=' class="current"';
			$price1=0;$price2=$pricearr1[0];
		}else{
			$current='';
		}
		$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@'.$class2.'@1@'.$order,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2='.$class2.'&price=1&order='.$order);
		$str_price.='<li><a href="'.$tmpurl.'"'.$current.'>'.$pricearr1[0].$it618_sale_lang['s171'].'</a></li>';
	}

	if($price==$n){
		$current=' class="current"';
		$price1=$pricearr1[0];$price2=$pricearr1[1];
	}else{
		$current='';
	}
	$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@'.$class2.'@'.$n.'@'.$order,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2='.$class2.'&price='.$n.'&order='.$order);
	$str_price.='<li><a href="'.$tmpurl.'"'.$current.'>'.$pricearr1[0].'-'.$pricearr1[1].$it618_sale_lang['s125'].'</a></li>';
	
	$n=$n+1;
}

if($price==$n){
	$current=' class="current"';
	$price1=$pricearr1[1];$price2=0;
}else{
	$current='';
}
$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@'.$class2.'@'.$n.'@'.$order,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2='.$class2.'&price='.$n.'&order='.$order);
$str_price.='<li><a href="'.$tmpurl.'"'.$current.'>'.$pricearr1[1].$it618_sale_lang['s172'].'</a></li>';

if($order==0){$current0=' class="left current"';$it618orderby='UNIX_TIMESTAMP(it618_quantime2)-'.$_G['timestamp'].',id desc';}else $current0=' class="left"';
if($order==1){$current1=' class="current"';$it618orderby='it618_collect desc';}else $current1='';
if($order==2){$current2=' class="current"';$it618orderby='it618_views desc';}else $current2='';
if($order==3){$current3=' class="current"';$it618orderby='it618_saleprice';}else $current3='';
if($order==4){$current4=' class="current"';$it618orderby='it618_saleprice desc';}else $current4='';
if($order==5){$current5=' class="current"';$it618orderby='it618_time desc';}else $current5='';

for($i=0;$i<=5;$i++){
	$tmpurl=it618_sale_getrewrite('sale_list',$class1.'@'.$class2.'@'.$price.'@'.$i,'plugin.php?id=it618_sale:list&class1='.$class1.'&class2='.$class2.'&price='.$price.'&order='.$i);
	$orderurl[$i]=$tmpurl;
}

$ppp=$it618_sale['sale_listpagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$count = C::t('#it618_sale#it618_sale_goods')->count_by_search("it618_state=1 and (it618_actime1='' or (it618_actime1!='' and UNIX_TIMESTAMP(it618_actime1)<=".$_G['timestamp']."))",$it618orderby,$class1,$class2,'',$price1,$price2);
$hrefsql=it618_sale_getrewrite('sale_list',$class1.'@'.$class2.'@'.$price.'@'.$order.'@it618page','plugin.php?id=it618_sale:list&class1='.$class1.'&class2='.$class2.'&price='.$price.'&order='.$order);
$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_sale_multipage($multipage,$uri);

foreach(C::t('#it618_sale#it618_sale_goods')->fetch_all_by_search(
	"it618_state=1 and (it618_actime1='' or (it618_actime1!='' and UNIX_TIMESTAMP(it618_actime1)<=".$_G['timestamp']."))",$it618orderby,$class1,$class2,'',$price1,$price2,$startlimit,$ppp
) as $it618_sale_goods) {
	
	$it618_price1='<em>&yen;</em>'.$it618_sale_goods['it618_saleprice'];
	$it618_price2='';
	if($it618_sale_goods['it618_price']>0)$it618_price2='<span class="money">&yen;<del>'.$it618_sale_goods['it618_price'].'</del></span>';
	
	$it618_quanstr='';
	if($it618_sale_goods['it618_quantime1']!=''){

		$it618_quanstr='<div class="divquan">'.$it618_sale_goods['it618_quanstr'].'</div>';
		$quanstr=$it618_sale_goods['it618_quanstr'];
		
		$it618_price1='<em>&yen;</em>'.it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr).' <span style="font-size:12px;">'.$it618_sale_lang['s299'].'</span>';
		$it618_price2='<span class="money">&yen;<del>'.$it618_sale_goods['it618_saleprice'].'</del></span>';

	}
	
	$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
	$str_goodslist.='<div class="index-goods">
						'.$it618_quanstr.'
						<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
							<img class="dynload" imgsrc="'.$it618_sale_goods['it618_pic'].'" src="source/plugin/it618_sale/images/a.gif" alt="'.$it618_sale_goods['it618_name'].'"/>
							<span class="index-goods-place">'.$it618_sale_goods['it618_description'].'</span>
						</a>
						<h3>
							<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_sale_goods['it618_name'].'">'.$it618_sale_goods['it618_name'].'</a>
							<a class="index-goods-text" href="'.$tmpurl.'" target="_blank" title="'.$it618_sale_goods['it618_description'].'">'.it618_getjfblcount($it618_sale_goods).'</a>
						</h3>
						<div class="index-goods-info">
							<span class="price" style="color:red">'.$it618_price1.'</span>
							'.$it618_price2.'
						</div>
					</div>';
}

$classtitle1=str_replace(' ','',$classtitle);
if($classtitle1=='')$classtitle=it618_sale_getlang('s100');
$metatitle=$classtitle.' - '.$metatitle;

$pagetype='list';
$_G['mobiletpl'][2]='/';
include template('it618_sale:sale_default');
?>