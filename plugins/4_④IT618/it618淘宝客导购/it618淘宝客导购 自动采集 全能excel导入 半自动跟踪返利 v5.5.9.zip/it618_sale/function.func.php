<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_sale = $_G['cache']['plugin']['it618_sale'];
$metatitle = $it618_sale['seotitle'];
$metakeywords = $it618_sale['seokeywords'];
$metadescription = $it618_sale['seodescription'];
$creditname=$_G['setting']['extcredits'][$it618_sale['sale_credit']]['title'];

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/lang.func.php';

$cache_file = DISCUZ_ROOT.'./source/plugin/it618_sale/cache_del.php';
if(($_G['timestamp'] - @filemtime($cache_file)) > 180) {
	
	@$fp = fopen($cache_file,"w");
	fwrite($fp,$_G['timestamp']);
	fclose($fp);
	
	if($it618_sale['sale_isacdel']==1){
		$query = DB::query("SELECT * FROM ".DB::table('it618_sale_goods')." where it618_actime2!='' and UNIX_TIMESTAMP(it618_actime2)<=".$_G['timestamp']);
	}
	
	if($it618_sale['sale_isacdel']==2){
		$query = DB::query("SELECT * FROM ".DB::table('it618_sale_goods')." where it618_quantime2!='' and UNIX_TIMESTAMP(it618_quantime2)<=".$_G['timestamp']);
	}
	
	if($it618_sale['sale_isacdel']==3){
		$query = DB::query("SELECT * FROM ".DB::table('it618_sale_goods')." where (it618_actime2!='' and UNIX_TIMESTAMP(it618_actime2)<=".$_G['timestamp'].") or (it618_quantime2!='' and UNIX_TIMESTAMP(it618_quantime2)<=".$_G['timestamp'].")");
	}
	
	if($it618_sale['sale_isacdel']==4){
		$query = DB::query("SELECT * FROM ".DB::table('it618_sale_goods')." where it618_actime2!='' and UNIX_TIMESTAMP(it618_actime2)<=".$_G['timestamp']." and it618_quantime2!='' and UNIX_TIMESTAMP(it618_quantime2)<=".$_G['timestamp']);
	}
	
	if($it618_sale['sale_isacdel']>0){
		while($it618_sale_goods = DB::fetch($query)) {
			C::t('#it618_sale#it618_sale_sale')->update_pid_bypid($it618_sale_goods['id']);
			C::t('#it618_sale#it618_sale_goods')->delete_by_id($it618_sale_goods['id']);
			C::t('#it618_sale#it618_sale_collect')->delete_by_pid($it618_sale_goods['id']);
		}
	}
	
	if($it618_sale['sale_shouhuocount']>0){
		DB::query("update ".DB::table('it618_sale_sale')." set it618_state=3 where it618_state=2 and it618_time+".(3600*24*$it618_sale['sale_shouhuocount'])."<".$_G['timestamp']);
	}
}

function it618_getgoodsisurl($it618_sale_goods){
	global $_G,$it618_sale,$it618_sale_lang;
	
	if($it618_sale['sale_isurl']==1){
		if($it618_sale_goods['it618_isurl']==1)$isurl=1;
	}
	
	if($it618_sale['sale_isurl']==2){
		$isurl=1;
	}
	
	if($it618_sale['sale_isurl']==3){
		if($it618_sale['sale_isjf']==1){
			$isjfok=1;
			
			if($it618_sale['sale_priceforjf']!=''){
				$tmparr=explode(",",$it618_sale['sale_priceforjf']);
				if(($it618_sale_goods['it618_saleprice']<$tmparr[0]||$it618_sale_goods['it618_saleprice']>$tmparr[1])){
					$isjfok=0;
				}
			}
		}else{
			$isjfok=0;
		}
		if($isjfok==0)$isurl=1;
	}
	
	return $isurl;
}

function it618_getquanprice($price,$quan){
	global $_G,$it618_sale,$it618_sale_lang;
	
	$tmparr=explode($it618_sale_lang['s688'],$quan);
	if(count($tmparr)>1){
		$tmparr1=explode($it618_sale_lang['s687'],$tmparr[0]);
		$tmparr2=explode($it618_sale_lang['s689'],$tmparr[1]);
		$price1=$tmparr1[1];
		$price2=$tmparr2[0];
		
		$price = $price-$price2;
	}else{
		$tmparr=explode($it618_sale_lang['s690'],$quan);
		if(count($tmparr)>1){
			$price1=$tmparr[0];
		}else{
			$tmparr=explode($it618_sale_lang['s692'],$quan);
			$tmparr1=explode($it618_sale_lang['s689'],$tmparr[1]);
			$price1=$tmparr1[0];
		}
		
		$price = $price-$price1;
	}
	
	return $price;
}

function it618_sale_get_contents($str){
	return dfsockopen($str);
}

function it618_getjfblcount($it618_sale_goods){
	global $_G,$it618_sale,$it618_sale_lang,$creditname;
	
	if($it618_sale['sale_isjf']==1){
		$isjfok=1;
		
		if($it618_sale['sale_priceforjf']!=''){
			$tmparr=explode(",",$it618_sale['sale_priceforjf']);
			if(($it618_sale_goods['it618_saleprice']<$tmparr[0]||$it618_sale_goods['it618_saleprice']>$tmparr[1])){
				$isjfok=0;
			}
		}
	}else{
		$isjfok=0;
	}
	
	if($isjfok==1){
		$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$it618_sale_goods['it618_quanstr']);
		$jfcount=round($it618_saleprice*$it618_sale['sale_jfbl']/100);
		$it618_description.= $it618_sale_lang['s552'].':'.$jfcount.''.$creditname.' ';
	}
	
	if($it618_sale['sale_isfl']>0){
		if($it618_sale_goods['it618_acsalebl']>0){
			$it618_saleprice=$it618_sale_goods['it618_saleprice'];
			if($it618_sale_goods['it618_quantime1']!=''){
				$quanstr=$it618_sale_goods['it618_quanstr'];
				$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr);
			}
			
			if($it618_sale['sale_isfl']==1){
				$it618_fl=intval($it618_saleprice*$it618_sale_goods['it618_acsalebl']*$it618_sale['sale_moneybl']/10000);
				$it618_description.= $it618_sale_lang['s553'].':'.$it618_fl.''.$creditname;
			}else{
				$it618_fl=round($it618_saleprice*$it618_sale_goods['it618_acsalebl']*$it618_sale['sale_moneybl']/10000,2);
				$it618_description.= $it618_sale_lang['s553'].':'.$it618_fl.''.$it618_sale_lang['s125'];
			}
		}
	}
	
	if($it618_description=='')$it618_description=$it618_sale_goods['it618_description'];
	
	return $it618_description;
}

function it618_sale_sendmessage($type,$id,$type1=''){
	global $_G,$it618_sale_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_sale/config/message.php';
	
	$tmpurl=it618_sale_getrewrite('sale_wap','','plugin.php?id=it618_sale:wap');
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale_admin;
				
				$it618_sale_sale = C::t('#it618_sale#it618_sale_sale')->fetch_by_id($id);
				$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($it618_sale_sale['it618_pid']);
				$tmpurl=it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_sale_getusername($it618_sale_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_sale_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pscore}",$it618_sale_sale['it618_score'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_sale_sale['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_sale_sale['it618_count'],$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_sale_sale['it618_tel'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_sale_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_sale_getusername($it618_sale_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_sale_goods['it618_name'],$Body);
				$Body=str_replace("{pscore}",$it618_sale_sale['it618_score'],$Body);
				$Body=str_replace("{pprice}",$it618_sale_sale['it618_price'],$Body);
				$Body=str_replace("{pcount}",$it618_sale_sale['it618_count'],$Body);
				$Body=str_replace("{tel}",$it618_sale_sale['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_sale_getusername($it618_sale_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_sale_getsmsstr($it618_sale_goods['it618_name']).'",';
					
					$tmparr=explode("{pscore}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_sale_sale['it618_score'].'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_sale_sale['it618_price'].'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_sale_sale['it618_count'].'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_sale_sale['it618_tel'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='salestate_admin'&&$it618_body_salestate_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_salestate_admin;
				
				$it618_sale_sale = C::t('#it618_sale#it618_sale_sale')->fetch_by_id($id);
				$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($it618_sale_sale['it618_pid']);
				$tmpurl=it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_salestate_admin_tplid_wxsms;
				$body_wxsms=$it618_body_salestate_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_sale_getusername($it618_sale_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_sale_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_sale_sale['id'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_sale_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_sale_getusername($it618_sale_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_sale_goods['it618_name'],$Body);
				$Body=str_replace("{saleid}",$it618_sale_sale['id'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_salestate_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_sale_getusername($it618_sale_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_sale_getsmsstr($it618_sale_goods['it618_name']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_sale_sale['id'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_sale_sale = C::t('#it618_sale#it618_sale_sale')->fetch_by_id($id);
			$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($it618_sale_sale['it618_pid']);
			
			$tmpurl=it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
			
			$tel=$it618_sale_sale['it618_tel'];	
			$Body=$it618_body_sale_user;
			
			$uid=$it618_sale_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$Body=str_replace("{pname}",$it618_sale_goods['it618_name'],$Body);
					$Body=str_replace("{pscore}",$it618_sale_sale['it618_score'],$Body);
					$Body=str_replace("{pprice}",$it618_sale_sale['it618_price'],$Body);
					$Body=str_replace("{pcount}",$it618_sale_sale['it618_count'],$Body);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_sale_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{pname}",$it618_sale_goods['it618_name'],$Body);
			$Body=str_replace("{pscore}",$it618_sale_sale['it618_score'],$Body);
			$Body=str_replace("{pprice}",$it618_sale_sale['it618_price'],$Body);
			$Body=str_replace("{pcount}",$it618_sale_sale['it618_count'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_sale_getsmsstr($it618_sale_goods['it618_name']).'",';
				
				$tmparr=explode("{pscore}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.$it618_sale_sale['it618_score'].'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.$it618_sale_sale['it618_price'].'",';
				
				$tmparr=explode("{pcount}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pcount":"'.$it618_sale_sale['it618_count'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='salestate_user'&&$it618_body_salestate_user_isok==1){
			$it618_sale_sale = C::t('#it618_sale#it618_sale_sale')->fetch_by_id($id);
			$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($it618_sale_sale['it618_pid']);
			$tmpurl=it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
			
			$tel=$it618_sale_sale['it618_tel'];
			
			$Body=$it618_body_salestate_user;
			
			if($type1=='fahuo')$action=it618_sale_getlang('s348');
			if($type1=='tongyitui')$action=it618_sale_getlang('s517');
			if($type1=='jujuetui')$action=it618_sale_getlang('s518');
			
			$uid=$it618_sale_sale['it618_uid'];
			$tplid_wxsms=$it618_body_salestate_user_tplid_wxsms;
			$body_wxsms=$it618_body_salestate_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$Body=str_replace("{saleid}",$it618_sale_sale['id'],$Body);
					$Body=str_replace("{pname}",$it618_sale_goods['it618_name'],$Body);
					$Body=str_replace("{action}",$action,$Body);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_sale_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{saleid}",$it618_sale_sale['id'],$Body);
			$Body=str_replace("{pname}",$it618_sale_goods['it618_name'],$Body);
			$Body=str_replace("{action}",$action,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salestate_user_tplid;
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_sale_sale['id'].'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_sale_getsmsstr($it618_sale_goods['it618_name']).'",';
				
				$tmparr=explode("{action}",$ALDYBody);
				if(count($tmparr)>1)$param.='"action":"'.$action.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_sale/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_sale_lang['s694'].$it618_smsbaosign.$it618_sale_lang['s695'];
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}

function it618_sale_getsmsstr($strtmp,$length){
	if($length>0){
		$tmpstr = "";
		$strlen = $length;
		for($i = 0; $i < $strlen; $i++){
			if(ord(substr($strtmp, $i, 1)) > 0xa0) {
				if(CHARSET=='gbk'){
					$tmpstr .= substr($strtmp, $i, 2);
					$i++;
				}else{
					$tmpstr.=substr($str,$i,3);
					$i+=2;
				}
			} else {
				$tmpstr .= substr($strtmp, $i, 1);
			}
			
		}
		return $tmpstr; 
	}
	return $strtmp;
}

function it618_sale_multipage($pagevalue,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_sale']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php')){
		return $pagevalue;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';

	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}


function it618_sale_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_sale']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php';
	
	if($pagetype=='sale_home'){
		return $sale_home.$urltype;
	}
	
	if($pagetype=='sale_list'){//sale_list-{cid1}-{cid2}-{price}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$sale_list.$sale_list1;

		if(count($tmparr)==1){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("-{cid2}-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==2){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==4){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{page}",'1',$pageurl);
		}
		
		if(count($tmparr)==5){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='sale_search'){//sale_search-{cid1}-{cid2}-{price}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$sale_search.$sale_search1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid1}-{cid2}-{price}-{order}-{page}","",$pageurl);
		}else{
			if(count($tmparr)==4){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",'1',$pageurl);
			}
			
			if(count($tmparr)==5){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='sale_product'){//sale_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$sale_product.$sale_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='sale_wap'){//sale_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$sale_wap.$sale_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_sale_getusername($uid){
	return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=$uid");
}

function it618_sale_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_sale_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_sale']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_sale_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_sale_gbktoutf($strcontent);
	}
}

function it618_sale_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_sale_gbktoutf1($strcontent){	
	if(CHARSET=='gbk'){
		return iconv('gbk','utf-8',$strcontent);
	}else{
		return $strcontent;
	}
}

function it618_sale_delfile($dirName){
}

function it618_sale_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
            }else{
            }
        }
        if($type==1);
    }else{
        return false;
    }
}

function it618_sale_getwapppic($aid,$get_it618_picbig,$type=1){
	$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
	$it618_smallurl='source/plugin/it618_sale/kindeditor/data/smallimage/wapad'.$aid.'.'.$file_ext;
	
	if($type==1){
		if(!file_exists($it618_smallurl))$flag=1;
	}else{
		$flag=1;
	}
	if($flag==1) {
			
		$smallpath=DISCUZ_ROOT.'./source/plugin/it618_sale/kindeditor/data/smallimage/';
		if(!file_exists($smallpath)) {
			mkdir($smallpath);
		}
	
		$tmparr1=explode("://",$get_it618_picbig);
		if(count($tmparr1)>1){
			$it618_url=$get_it618_picbig;
		}else{
			$tmparr=explode("source",$get_it618_picbig);
			$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
		}
		
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_sale/kindeditor/data/smallimage/wapad'.$aid.'.'.$file_ext;
		it618_sale_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,280);
	}
	
	return $it618_smallurl;
}

function it618_sale_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height,$type=1){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function sale_qrcode($url){
	include DISCUZ_ROOT.'./source/plugin/it618_sale/phpqrcode.php';
	
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/it618_sale/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function sale_is_mobile(){ 
	global $_GET;
	if(isset($_GET['pc'])) return false;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: d'.'is'.'m.ta'.'obao.com
?>