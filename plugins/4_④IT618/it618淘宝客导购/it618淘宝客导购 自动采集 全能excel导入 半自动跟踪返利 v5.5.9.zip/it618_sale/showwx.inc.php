<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_sale = $_G['cache']['plugin']['it618_sale'];
require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($_GET['pid']);

$codestr=$it618_sale_goods['it618_codeurl'];
$quancodestr=$it618_sale_goods['it618_quancodeurl'];
$urlstr=$it618_sale_goods['it618_pcurl'];
$quanurlstr=$it618_sale_goods['it618_quanurl'];

if($urlstr!=''){
	if($codestr==''||$it618_sale_goods['it618_codetime']+3600*30*24<$_G['timestamp']){
		require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
		$codestr=it618_sale_getcodeurl($it618_sale_goods['it618_name'],$urlstr,$it618_sale_goods['it618_pic']);
		
		if($codestr!='')C::t('#it618_sale#it618_sale_goods')->update_it618_codeurl_by_id($codestr,$_G['timestamp'],$_GET['pid']);
	}
}

if($quanurlstr!=''){
	if($quancodestr==''||$it618_sale_goods['it618_quancodetime']+3600*30*24<$_G['timestamp']){
		require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
		$quancodestr=it618_sale_getcodeurl($it618_sale_goods['it618_name'],$quanurlstr,$it618_sale_goods['it618_pic']);
		
		if($quancodestr!='')C::t('#it618_sale#it618_sale_goods')->update_it618_quancodeurl_by_id($quancodestr,$_G['timestamp'],$_GET['pid']);
	}
}

$_G['mobiletpl'][2]='/';
include template('it618_sale:showwx');
?>