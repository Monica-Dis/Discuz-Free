<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_top=195;
$it618_width=150;
if(C::t('#it618_sale#it618_sale_kf')->count_by_search()>0){
	$it618_sale_kf=C::t('#it618_sale#it618_sale_kf')->fetch_by_search();
	$it618_top=$it618_sale_kf['it618_top'];
	$it618_width=$it618_sale_kf['it618_width'];
}

if(submitcheck('it618submit')){
	if(C::t('#it618_sale#it618_sale_kf')->count_by_search()==0){
		C::t('#it618_sale#it618_sale_kf')->insert(array(
			'it618_top' => $_GET['it618_top'],
			'it618_width' => $_GET['it618_width'],
			'it618_title' => $_GET['it618_title'],
			'it618_about' => $_GET['it618_about'],
			'it618_yytime' => $_GET['it618_yytime'],
			'it618_dianhua' => $_GET['it618_dianhua'],
			'it618_kefuqqname' => $_GET['it618_kefuqqname'],
			'it618_kefuqq' => $_GET['it618_kefuqq'],
			'it618_kefuwx' => $_GET['it618_kefuwx']
		), true);
	}else{
		C::t('#it618_sale#it618_sale_kf')->update($it618_sale_kf['id'],array(
			'it618_top' => $_GET['it618_top'],
			'it618_width' => $_GET['it618_width'],
			'it618_title' => $_GET['it618_title'],
			'it618_about' => $_GET['it618_about'],
			'it618_yytime' => $_GET['it618_yytime'],
			'it618_dianhua' => $_GET['it618_dianhua'],
			'it618_kefuqqname' => $_GET['it618_kefuqqname'],
			'it618_kefuqq' => $_GET['it618_kefuqq'],
			'it618_kefuwx' => $_GET['it618_kefuwx']
		));
	}
	

	cpmsg($it618_sale_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_kf&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_kf&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_sale_kf');

echo '
<tr><td width=90>'.$it618_sale_lang['s660'].'</td><td><input type="text" class="txt" style="width:600px" name="it618_top" value="'.$it618_top.'"></td></tr>
<tr><td>'.$it618_sale_lang['s661'].'</td><td><input type="text" class="txt" style="width:600px" name="it618_width" value="'.$it618_width.'"></td></tr>
<tr><td>'.$it618_sale_lang['s662'].'</td><td><input type="text" class="txt" style="width:600px" name="it618_title" value="'.$it618_sale_kf['it618_title'].'"></td></tr>
<tr><td>'.$it618_sale_lang['s663'].'</td><td><textarea name="it618_about" style="width:600px;height:100px;">'.$it618_sale_kf['it618_about'].'</textarea></td></tr>
<tr><td>'.$it618_sale_lang['s664'].'</td><td><input type="text" class="txt" style="width:600px" name="it618_yytime" value="'.$it618_sale_kf['it618_yytime'].'"></td></tr>
<tr><td>'.$it618_sale_lang['s665'].'</td><td><input type="text" class="txt" style="width:600px" name="it618_dianhua" value="'.$it618_sale_kf['it618_dianhua'].'"></td></tr>
<tr><td>'.$it618_sale_lang['s666'].'</td><td><input type="text" class="txt" style="width:600px" name="it618_kefuqqname" value="'.$it618_sale_kf['it618_kefuqqname'].'"></td></tr>
<tr><td>'.$it618_sale_lang['s667'].'</td><td><input type="text" class="txt" style="width:600px" name="it618_kefuqq" value="'.$it618_sale_kf['it618_kefuqq'].'"></td></tr>
<tr><td>'.$it618_sale_lang['s668'].'</td><td><input type="text" class="txt" style="width:600px" name="it618_kefuwx" value="'.$it618_sale_kf['it618_kefuwx'].'"></td></tr>
';

showsubmit('it618submit', $it618_sale_lang['s23']);
if(count($reabc)!=11)return;
showtablefooter(); //dis'.'m.tao'.'bao.com

?>