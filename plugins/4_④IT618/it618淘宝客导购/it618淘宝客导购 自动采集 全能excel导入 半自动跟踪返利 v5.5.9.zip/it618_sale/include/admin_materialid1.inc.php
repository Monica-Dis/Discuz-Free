<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_sale_materialclass', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_sale#it618_sale_materialclass')->update($id,array(
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_about' => trim($_GET['it618_about'][$id]),
				'it618_goodscount' => trim($_GET['it618_goodscount'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	$newit618_goodscount_array = !empty($_GET['newit618_goodscount']) ? $_GET['newit618_goodscount'] : array();
	
	foreach($newit618_classname_array as $key => $value) {
		$newit618_classname = addslashes(trim($newit618_classname_array[$key]));
		
		if($newit618_classname != '') {
			
			C::t('#it618_sale#it618_sale_materialclass')->insert(array(
				'it618_classname' => trim($newit618_classname_array[$key]),
				'it618_about' => trim($newit618_about_array[$key]),
				'it618_goodscount' => trim($newit618_goodscount_array[$key]),
				'it618_order' => 1,
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_sale_lang['s33'].$ok1.' '.$it618_sale_lang['s34'].$ok2.' '.$it618_sale_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_materialid1&pmod=admin_materialid&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_materialid1&pmod=admin_materialid&operation=$operation&do=$do");
showtableheaders($it618_sale_lang['s457'],'it618_sale_materialclass');

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_materialclass')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_materialid1&pmod=admin_materialid&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10 style="color:blue">'.$it618_sale_lang['s455'].'</td></tr>';
	echo '<tr><td colspan=10>'.$it618_sale_lang['s465'].$count.'<span style="float:right;color:red">'.$it618_sale_lang['s464'].'</span></td></tr>';
	showsubtitle(array($it618_sale_lang['s459'], $it618_sale_lang['s460'],$it618_sale_lang['s461'],$it618_sale_lang['s462'],$it618_sale_lang['s463']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_materialclass')." WHERE 1 $extrasql ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_sale =	DB::fetch($query)) {
		$materialcount = C::t('#it618_sale#it618_sale_material')->count_by_cid($it618_sale['id']);
		$disabled="";
		if($materialcount>0)$disabled="disabled=\"disabled\"";
		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			//"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_sale[id]\" $disabled> $it618_sale[id]",
			"<input type=\"text\" class=\"txt\" style=\"width:90px\" name=\"it618_classname[$it618_sale[id]]\" value=\"$it618_sale[it618_classname]\">",
			'<input class="txt" type="text" style="width:660px;margin-right:0" name="it618_about['.$it618_sale['id'].']" value="'.$it618_sale['it618_about'].'">',
			'<input class="txt" type="text" style="width:60px" name="it618_goodscount['.$it618_sale['id'].']" value="'.$it618_sale['it618_goodscount'].'">',
			$materialcount,
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_sale['id'].']" value="'.$it618_sale['it618_order'].'">',
		));
	}


	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_classname[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:90px\" name="newit618_classname[]">'], [1, ' <input class="txt" style=\"width:660px\" type="text" name="newit618_about[]">'], [1,'<input type="text" class="txt" style=\"width:60px\" name="newit618_goodscount[]">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	//echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', '', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>