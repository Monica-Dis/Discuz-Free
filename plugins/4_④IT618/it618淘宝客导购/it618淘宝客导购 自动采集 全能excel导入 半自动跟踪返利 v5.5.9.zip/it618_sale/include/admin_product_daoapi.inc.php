<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
}

if($appkey==''||$secretkey==''||$adzoneid==''){
	cpmsg($it618_sale_lang['s103'], "action=plugins&identifier=$identifier&cp=admin_taobao&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=23", 'error');
}

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_class2')." WHERE it618_class1_id=1 and it618_classname='".$it618_sale_lang['s580']."'");
if($count==0){
	C::t('#it618_sale#it618_sale_class2')->insert(array(
		'it618_class1_id' => 1,
		'it618_classname' => $it618_sale_lang['s580']
	), true);
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_product_daoapi&pmod=admin_product&operation=$operation&do=$do&dw=$dw");
showtableheaders($it618_sale_lang['s11'],'it618_sale_goods');

$code=md5($appkey.$secretkey.$adzoneid);

echo '
<tr><td style="line-height:28px">
'.$it618_sale_lang['s575'].' <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_class2&pmod=admin_class&classid=1&operation='.$operation.'&do='.$do.'">'.$it618_sale_lang['s1904'].'</a><br>

<input style="display:none" type="button" class="btn" onclick="gettaobaocategory()" value="'.$it618_sale_lang['s587'].'"/> <input type="button" class="btn" onclick="gettaobaogoods()" value="'.$it618_sale_lang['s576'].'"/><br>

<div id="taobao" style="color:#999;display:none">
<span id="taobaoimg"><img src="source/plugin/it618_sale/images/loading_r.gif" style="vertical-align:middle"> '.$it618_sale_lang['s577'].'<br></span>

'.$it618_sale_lang['s578'].'<br>
<span id="taobaook" style="font-size:14px"></span>
</div>

<script src="source/plugin/it618_sale/js/jquery.js" type=text/javascript></script>
<script>
var pageindex=1,allpage=100;
var taobaook="";
function getgoods_ajax(page){
	IT618_SALE.get("'.$_G['siteurl'].'plugin.php?id=it618_sale:ajax&page="+page+"&code='.$code.'", {ac:"gettaobaogoods"},function (data, textStatus){	
		taobaook=taobaook+data;
		
		IT618_SALE("#taobaook").html(taobaook);
		pageindex=pageindex+1;
		if(pageindex<=allpage)getgoods_ajax(pageindex);
		
		if(page==allpage){
			IT618_SALE("#taobaoimg").hide();
		}
	}, "html");	
}

function gettaobaogoods(){
	if(confirm("'.$it618_sale_lang['s585'].'")){
		IT618_SALE("#taobao").show();
		taobaook="";
		getgoods_ajax(pageindex);
	}
}

function getcategory_ajax(page){
	IT618_SALE.get("'.$_G['siteurl'].'plugin.php?id=it618_sale:ajax&page="+page+"&code='.$code.'", {ac:"gettaobaocategory"},function (data, textStatus){	
		taobaook=taobaook+data;
		
		IT618_SALE("#taobaook").html(taobaook);
		pageindex=pageindex+1;
		if(pageindex<=allpage)getcategory_ajax(pageindex);
		
		if(page==allpage){
			IT618_SALE("#taobaoimg").hide();
		}
	}, "html");	
}

function gettaobaocategory(){
	IT618_SALE("#taobao").show();
	taobaook="";
	getcategory_ajax(pageindex);
}
</script>
</td></tr>
';

if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>