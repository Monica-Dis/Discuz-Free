<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$classid=intval($_GET['classid']);
$it618_sale_class2=C::t('#it618_sale#it618_sale_class2')->fetch_by_id($classid);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_sale_category', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_category'])) {
		foreach($_GET['it618_category'] as $id => $val) {

			C::t('#it618_sale#it618_sale_category')->update($id,array(
				'it618_category' => trim($_GET['it618_category'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_category_array = !empty($_GET['newit618_category']) ? $_GET['newit618_category'] : array();
	
	foreach($newit618_category_array as $key => $value) {
		$newit618_category = addslashes(trim($newit618_category_array[$key]));
		
		if($newit618_category != '') {
			
			C::t('#it618_sale#it618_sale_category')->insert(array(
				'it618_class2_id' => $classid,
				'it618_category' => trim($newit618_category_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_sale_lang['s33'].$ok1.' '.$it618_sale_lang['s34'].$ok2.' '.$it618_sale_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_category&pmod=admin_class&operation=$operation&do=$do&page=$page&classid=$classid", 'succeed');
}

if(submitcheck('it618submit_add')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
	
	$ok=0;
	foreach(C::t('#it618_sale#it618_sale_goods')->fetch_all_by_search("it618_state=1 and (it618_actime1='' or (it618_actime1!='' and UNIX_TIMESTAMP(it618_actime1)<=".$_G['timestamp']."))",'',0,$classid) as $it618_sale_goods) {
		$category=it618_sale_getcategory($it618_sale_goods['it618_name']);
		if($category>0){
			$count=C::t('#it618_sale#it618_sale_category')->count_by_it618_category($category);
			if($count==0){
				C::t('#it618_sale#it618_sale_category')->insert(array(
					'it618_class2_id' => $classid,
					'it618_category' => $category
				), true);
				$ok=$ok+1;
			}
		}
	}
	
	cpmsg($it618_sale_lang['s581'].$ok, "action=plugins&identifier=$identifier&cp=admin_category&pmod=admin_class&operation=$operation&do=$do&page=$page&classid=$classid", 'succeed');
}

if(count($reabc)!=10)return;


$classstr="<a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_class2&pmod=admin_class&classid=".$it618_sale_class2['it618_class1_id']."&operation=$operation&do=$do&page=$page\">".$it618_sale_lang['s582']."<font color=red>".$it618_sale_class2['it618_classname'].'</font></a> ';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_category&pmod=admin_class&operation=$operation&do=$do&classid=$classid");
showtableheaders($classstr.$it618_sale_lang['s583'],'it618_sale_category');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_category')." WHERE it618_class2_id=$classid");
	
	echo '<tr><td colspan=2><font color=green>'.$it618_sale_lang['s589'].'</font></td></tr>';
	
	echo '<tr><td colspan=2>'.$it618_sale_lang['s584'].$count.'<span style="float:right;color:red">'.$it618_sale_lang['s588'].'</span></td></tr>';
	
	showsubtitle(array('',$it618_sale_lang['s590']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_category')." WHERE it618_class2_id=$classid");
	while($it618_sale =	DB::fetch($query)) {		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_sale[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_category[$it618_sale[id]]\" value=\"$it618_sale[it618_category]\">"
		));
	}
	

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_category[]").length;
	
		return [
		[[1,''],[1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_category[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', '', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>