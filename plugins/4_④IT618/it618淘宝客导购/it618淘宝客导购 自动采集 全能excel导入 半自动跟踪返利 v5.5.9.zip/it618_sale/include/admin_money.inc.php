<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';


$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_sale_money', "id=$delid");
		$del=$del+1;
	}

	cpmsg($it618_sale_lang['s373'].$del, "action=plugins&identifier=$identifier&cp=admin_money&pmod=admin_money&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_data')){
	$strtmp=$it618_sale_lang['s368']."\n";
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_money')." WHERE $extrasql order by it618_pid,it618_time desc");
	while($it618_sale_money = DB::fetch($query)) {
		
		if($it618_sale_money['it618_fltype']==1){
			$it618_fl=$it618_sale_money['it618_score'].$creditname;
		}else{
			$it618_fl=$it618_sale_money['it618_flmoney'].$it618_sale_lang['s125'];
		}
		
		$strtmp.=$it618_sale_money['it618_name'].",".$it618_fl.",".$it618_sale_money['it618_count'].",".$it618_sale_money['it618_name'].",".$it618_sale_money['it618_tel'].",".$it618_sale_money['it618_addr'].",".$it618_sale_money['it618_bz'].",".date('Y-m-d H:i:s', $it618_sale_money['it618_time'])."\n";
		$datacount=$datacount+1;
	}

	$timestr=date("YmdHis") . '_' . $datacount;
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_sale/temp/admin/';
	it618_sale_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	cpmsg($it618_sale_lang['s366'].'<a href="javascript:" onclick="window.open(\''.$_G['siteurl'].'source/plugin/it618_sale/temp/admin/'.$timestr.'.csv\')"><font color=red>'.$it618_sale_lang['s367'].'</font></a>', "action=plugins&identifier=$identifier&cp=admin_money&pmod=admin_money&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=10)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_money&pmod=admin_money&operation=$operation&do=$do");
showtableheaders($it618_sale_lang['s394'],'it618_sale_sum');
	showsubmit('it618sercsubmit', $it618_sale_lang['s25'], $it618_sale_lang['s97'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" />'.$it618_sale_lang['s502'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_sale_lang['t139'].' <input name="it618_time1" class="txt" style="width:80px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time1'].'" /> - <input name="it618_time2" class="txt" style="width:80px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time2'].'"/>');
	
	$it618_sale_moneys=C::t('#it618_sale#it618_sale_money')->fetch_all_by_search($it618sql,'it618_time2 desc',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
	$count=C::t('#it618_sale#it618_sale_money')->count_by_search($it618sql,'',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$money=C::t('#it618_sale#it618_sale_money')->sum_salemoney_by_search($it618sql,'',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_sale#it618_sale_money')->sum_score_by_search($it618sql,'',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$flmoney=C::t('#it618_sale#it618_sale_money')->sum_flmoney_by_search($it618sql,'',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($flmoney>0){
		$flsumstr='<font color=red>'.$flmoney.'</font> '.$it618_sale_lang['s125'].' ';
	}
	if($score>0){
		$flsumstr.='<font color=green>'.$score.'</font> '.$creditname;
	}
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_money&pmod=admin_money&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=18>'.$it618_sale_lang['s377'].'<font color=red>'.$count.'</font> '.$it618_sale_lang['s542'].'<font color=red>'.$money.'</font> '.it618_sale_getlang('s563').''.$flsumstr.'<span style="float:right;"></span></td></tr>';
	showsubtitle(array($it618_sale_lang['s538'],$it618_sale_lang['s531'], $it618_sale_lang['s530'],$it618_sale_lang['s533'],$it618_sale_lang['s534'],$it618_sale_lang['s535'],$it618_sale_lang['s536'],$it618_sale_lang['s537'],$it618_sale_lang['s539'],$it618_sale_lang['s540']));

	foreach($it618_sale_moneys as $it618_sale_money) {
		
		$it618_score='';$it618_user='';$disabled='';
		if($it618_sale_money['it618_uid']>0){
			$it618_user='<a href="home.php?mod=space&uid='.$it618_sale_money['it618_uid'].'" target="_blank">'.it618_sale_getusername($it618_sale_money['it618_uid']).'</a>';
			
			if($it618_sale_money['it618_fltype']==1){
				$it618_fl='<font color=green>'.$it618_sale_money['it618_score'].'</font>'.$creditname;
			}else{
				$it618_fl='<font color=red>'.$it618_sale_money['it618_flmoney'].'</font> '.$it618_sale_lang['s125'];
			}

			$disabled='disabled="disabled"';
		}
		
		$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
		showtablerow('', array('', '', '', '', '', '', '', '', ''), array(
			'<div style="width:168px"><input class="checkbox" type="checkbox" id="chk_del'.$it618_sale_money['id'].'" name="delete[]" '.$disabled.' value="'.$it618_sale_money['id'].'"><input type="hidden" name="id['.$it618_sale_money['id'].']" value="'.$it618_sale_money['id'].'"><label for="chk_del'.$it618_sale_money['id'].'">'.$it618_sale_money['it618_saleid'].'</label></div>',
			'<div style="width:300px;color:#999">'.$it618_sale_money['it618_pname'].' '.$it618_sale_money['it618_productid'].'</div>',
			'<div style="width:80px;color:#999">'.date('Y-m-d H:i:s', $it618_sale_money['it618_time1']).'</div>',
			$it618_sale_money['it618_count'],
			$it618_sale_money['it618_salebl'].'%',
			$it618_sale_money['it618_money'],
			'<font color=red>'.$it618_sale_money['it618_salemoney'].'</font>',
			'<div style="width:80px;color:#999">'.date('Y-m-d H:i:s', $it618_sale_money['it618_time2']).'</div>',
			$it618_user,
			$it618_fl,
		));
	}
	
	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_sale_lang['s129'].'</label> <input type="submit" class="btn" name="it618submit_del" value="'.$it618_sale_lang['s77'].'" onclick="return confirm(\''.$it618_sale_lang['t324'].'\')" />&nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
echo '<script charset="utf-8" src="source/plugin/it618_sale/js/Calendar.js"></script>';
?>