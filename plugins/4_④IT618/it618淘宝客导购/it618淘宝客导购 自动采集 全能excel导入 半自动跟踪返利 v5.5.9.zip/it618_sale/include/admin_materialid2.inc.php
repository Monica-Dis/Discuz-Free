<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
$n=1;
$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_materialclass')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	if(isset($_GET['classid'])){
		if($_GET['classid']==$it618_tmp['id']){
			$licss='class="current"';
			$classid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}else{
		if($n==1){
			$licss='class="current"';
			$classid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_material')." w WHERE it618_cid=".$it618_tmp['id']);
	
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_materialid2&pmod=admin_materialid&classid=".$it618_tmp['id']."&operation=$operation&do=$do&page=$page\"><span>".$it618_tmp['it618_classname'].'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$n=$n+1;
}
$tmp2=str_replace('<option value='.$classid.'>','<option value='.$classid.' selected="selected">',$tmp);
echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';

$extrasql .= "it618_cid =".$classid;
$urlsql='&classid='.$classid;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_sale_material', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_materialid'])) {
		foreach($_GET['it618_materialid'] as $id => $val) {

			C::t('#it618_sale#it618_sale_material')->update($id,array(
				'it618_materialid' => trim($_GET['it618_materialid'][$id]),
				'it618_about' => trim($_GET['it618_about'][$id]),
				'it618_timecount' => trim($_GET['it618_timecount'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_materialid_array = !empty($_GET['newit618_materialid']) ? $_GET['newit618_materialid'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	
	foreach($newit618_materialid_array as $key => $value) {
		$newit618_materialid = addslashes(trim($newit618_materialid_array[$key]));
		
		if($newit618_materialid != '') {
			
			C::t('#it618_sale#it618_sale_material')->insert(array(
				'it618_cid' => $classid,
				'it618_materialid' => trim($newit618_materialid_array[$key]),
				'it618_about' => trim($newit618_about_array[$key]),
				'it618_timecount' => 0,
				'it618_order' => 1,
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_sale_lang['s33'].$ok1.' '.$it618_sale_lang['s34'].$ok2.' '.$it618_sale_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_materialid2&pmod=admin_materialid&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_materialid2&pmod=admin_materialid&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_sale_lang['s458'],'it618_sale_material');

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_material')." w WHERE $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_materialid2&pmod=admin_materialid&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10 style="color:blue">'.$it618_sale_lang['s468'].'</td></tr>';
	echo '<tr><td colspan=10>'.$it618_sale_lang['s454'].$count.'<span style="float:right;color:red">'.$it618_sale_lang['s456'].'</span></td></tr>';
	showsubtitle(array($it618_sale_lang['s447'], $it618_sale_lang['s467'], $it618_sale_lang['s448'],$it618_sale_lang['s449'],$it618_sale_lang['s450'],$it618_sale_lang['s451']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_material')." WHERE $extrasql ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_sale_material = DB::fetch($query)) {
		
		$classname = DB::result_first("SELECT it618_classname FROM ".DB::table('it618_sale_class2')." WHERE id=".$it618_sale_material['it618_class2_id']);
		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			//"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_sale_material[id]\" $disabled> $it618_sale_material[id]",
			"<input type=\"text\" class=\"txt\" style=\"width:80px\" name=\"it618_materialid[$it618_sale_material[id]]\" value=\"$it618_sale_material[it618_materialid]\">",
			$classname,
			'<input class="txt" type="text" style="width:90px;" name="it618_about['.$it618_sale_material['id'].']" value="'.$it618_sale_material['it618_about'].'">',
			'<input class="txt" type="text" style="width:50px;margin-right:3px" name="it618_timecount['.$it618_sale_material['id'].']" value="'.$it618_sale_material['it618_timecount'].'">'.$it618_sale_lang['s466'],
			'<div style="width:630px"><font color=#999>'.date('Y-m-d H:i:s', $it618_sale_material['it618_time']).'</font><br>'.$it618_sale_material['it618_bz'].'</div>',
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_sale_material['id'].']" value="'.$it618_sale_material['it618_order'].'">'
		));
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_materialid[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:80px\" name="newit618_materialid[]">'], [1, ' <input class="txt" style=\"width:90px\" type="text" name="newit618_about[]">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	//echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', '', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>