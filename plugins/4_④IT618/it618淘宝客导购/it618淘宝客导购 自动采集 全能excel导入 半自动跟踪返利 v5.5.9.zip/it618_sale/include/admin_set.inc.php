<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_sale_set=C::t('#it618_sale#it618_sale_set')->fetch_by_setname($setname);

if(submitcheck('it618submit')){
	if(C::t('#it618_sale#it618_sale_set')->count_by_setname($setname)==0){
		C::t('#it618_sale#it618_sale_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $_GET[$setname]
		), true);
	}else{
		C::t('#it618_sale#it618_sale_set')->update($it618_sale_set['id'],array(
			'setvalue' => $_GET[$setname]
		));
	}
	

	cpmsg($it618_sale_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_set&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_set&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1].'<span style="font-weight:normal;color:red;margin-left:90px">'.$it618_sale_lang['s38'].'</span>','it618_sale_set');

$strtmp='';
if($cp1==17){
	$strtmp=$it618_sale_lang['s500'];
}
if($cp1==21){
	$strtmp=$it618_sale_lang['s677'];
}

echo '
<link rel="stylesheet" href="source/plugin/it618_sale/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_sale/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="'.$setname.'"]\', {
			cssPath : \'source/plugin/it618_sale/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_sale/kindeditor/php/upload_json.php?&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_sale/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>

<tr><td width=800><textarea name="'.$setname.'" style="width:800px;height:400px;visibility:hidden;">'.$it618_sale_set['setvalue'].'</textarea><br>'.$strtmp.'</td></tr>
';

showsubmit('it618submit', $it618_sale_lang['s23']);
if(count($reabc)!=11)return;
showtablefooter(); //dis'.'m.tao'.'bao.com

?>