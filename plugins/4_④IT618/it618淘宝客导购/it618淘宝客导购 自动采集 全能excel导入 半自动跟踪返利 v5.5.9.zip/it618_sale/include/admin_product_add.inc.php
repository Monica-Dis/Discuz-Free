<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$pid=C::t('#it618_sale#it618_sale_goods')->insert(array(
		'it618_class1_id' => $_GET['it618_class1_id'],
		'it618_class2_id' => $_GET['it618_class2_id'],
		'it618_name' => $_GET['it618_name'],
		'it618_pcurl' => $_GET['it618_pcurl'],
		'it618_wapurl' => $_GET['it618_pcurl'],
		'it618_description' => $_GET['it618_description'],
		'it618_seokeywords' => $_GET['it618_seokeywords'],
		'it618_seodescription' => $_GET['it618_seodescription'],
		'it618_message' => $_GET['it618_message'],
		'it618_message1' => $_GET['it618_message1'],
		'it618_message2' => $_GET['it618_message2'],
		'it618_price' => $_GET['it618_price'],
		'it618_saleprice' => $_GET['it618_saleprice'],
		'it618_pic' => $_GET['it618_pic'],
		'it618_acsalebl' => $_GET['it618_acsalebl'],
		'it618_quanstr' => $_GET['it618_quanstr'],
		'it618_quanurl' => $_GET['it618_quanurl'],
		'it618_time' => $_G['timestamp']
	), true);
	
	if($_GET['it618_actime1']!=''&&$_GET['it618_actime2']!=''){
		C::t('#it618_sale#it618_sale_goods')->update($pid,array(
			'it618_actime1' => $_GET['it618_actime1'],
			'it618_actime2' => $_GET['it618_actime2']
		), true);
	}
	
	if($_GET['it618_quantime1']!=''&&$_GET['it618_quantime1']!=''){
		C::t('#it618_sale#it618_sale_goods')->update($pid,array(
			'it618_quantime1' => $_GET['it618_quantime1'],
			'it618_quantime2' => $_GET['it618_quantime2']
		), true);
	}

	cpmsg($it618_sale_lang['s121'], "action=plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do");
showtableheaders($it618_sale_lang['s9'],'it618_sale_goods');

$productvalue=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('productvalue');
$wapproductvalue=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('wapproductvalue');

$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class1')." ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$classcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_sale_class2'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class1')." ORDER BY it618_order");
$n1=1;
$classtmp='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_sale_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$classtmp.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_sale/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_sale/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_sale/kindeditor/php/upload_json.php?&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_sale/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false
		});
		
		var editor3 = K.editor({
			uploadJson : \'source/plugin/it618_sale/kindeditor/php/upload_json.php?imgwidth=640'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_sale/kindeditor/php/file_manager_json.php\',
			allowFileManager : true
		});
		
		K(\'#image1\').click(function() {
			editor3.loadPlugin(\'image\', function() {
				editor3.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor3.hideDialog();
					}
				});
			});
		});
		
		var editor1 = K.create(\'textarea[name="it618_message1"]\', {
			cssPath : \'source/plugin/it618_sale/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_sale/kindeditor/php/upload_json.php?&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_sale/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false
		});
		
		var editor2 = K.create(\'textarea[name="it618_message2"]\', {
			cssPath : \'source/plugin/it618_sale/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_sale/kindeditor/php/upload_json.php?&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_sale/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false
		});
				
		prettyPrint();
	});
	
	function checkvalue(){
		if(document.getElementById("it618_class2_id").value=="0"){
			alert("'.$it618_sale_lang['s124'].'");
			return false;
		}
		if(document.getElementById("it618_name").value==""){
			alert("'.$it618_sale_lang['s127'].'");
			return false;
		}
		if(document.getElementById("it618_saleprice").value==""){
			alert("'.$it618_sale_lang['s128'].'");
			return false;
		}
		if(document.getElementById("it618_price").value>0){
			if(parseFloat(document.getElementById("it618_price").value)<=parseFloat(document.getElementById("it618_saleprice").value)){
				alert("'.$it618_sale_lang['s132'].'");
				return false;
			}
		}
		if(document.getElementById("url1").value==""){
			alert("'.$it618_sale_lang['s133'].'");
			return false;
		}
		if(document.getElementById("it618_actime1").value!=""||document.getElementById("it618_actime2").value!=""){
			if(document.getElementById("it618_actime1").value==""){
				alert("'.$it618_sale_lang['s654'].'");
				return false;
			}
			if(document.getElementById("it618_actime2").value==""){
				alert("'.$it618_sale_lang['s655'].'");
				return false;
			}
			if(parseInt(document.getElementById("it618_actime2").value.replace(/-/g,""))<parseInt(document.getElementById("it618_actime1").value.replace(/-/g,""))){
				alert("'.$it618_sale_lang['s656'].'");
				return false;
			}
		}
		
		if(document.getElementById("it618_quantime1").value!=""||document.getElementById("it618_quantime2").value!=""){
			if(document.getElementById("it618_quantime1").value==""){
				alert("'.$it618_sale_lang['s657'].'");
				return false;
			}
			if(document.getElementById("it618_quantime2").value==""){
				alert("'.$it618_sale_lang['s658'].'");
				return false;
			}
			if(parseInt(document.getElementById("it618_quantime2").value.replace(/-/g,""))<parseInt(document.getElementById("it618_quantime1").value.replace(/-/g,""))){
				alert("'.$it618_sale_lang['s659'].'");
				return false;
			}
		}
	}
	
	var arrcount='.$classcount.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$classtmp.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
</script>

<tr><td width=100>'.$it618_sale_lang['s18'].'</td><td><select name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)"><option value="0">'.$it618_sale_lang['s19'].'</option>'.$classtmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.$it618_sale_lang['s20'].'</option></select> </td></tr>
<tr><td>'.$it618_sale_lang['s104'].'</td><td><input type="text" class="txt" style="width:600px;margin-right:0" id="it618_name" name="it618_name"> </td></tr>
<tr><td>'.$it618_sale_lang['s105'].'</td><td><input type="text" class="txt" style="width:80px;color:red" id="it618_saleprice" name="it618_saleprice" onkeyup="value=value.replace(/[^\-?\d.]/g,\'\')">'.$it618_sale_lang['s125'].'  '.$it618_sale_lang['s134'].'<input type="text" class="txt" style="width:80px" id="it618_price" name="it618_price" onkeyup="value=value.replace(/[^\-?\d.]/g,\'\')" value="0">'.$it618_sale_lang['s125'].' <font color=red>'.$it618_sale_lang['s281'].'</font></td></tr>
<tr><td>'.$it618_sale_lang['s47'].'</td><td><img id="img1" src="" width="160" height="160" align="absmiddle" style="margin-right:3px"/><input type="text" id="url1" name="it618_pic" value="" readonly="readonly" /> <input type="button" id="image1" value="'.$it618_sale_lang['s48'].'" />  '.$it618_sale_lang['s195'].'</td></tr>
<tr><td>'.$it618_sale_lang['s153'].'</td><td><input type="text" class="txt" style="width:696px;margin-right:0" id="it618_pcurl" name="it618_pcurl"> </td></tr>
<tr><td>'.$it618_sale_lang['s155'].'</td><td><textarea name="it618_description" style="width:696px;height:60px;"></textarea></td></tr>
<tr bgcolor="#f1f1f1"><td colspan=2>'.$it618_sale_lang['s651'].'</td></tr>
<tr bgcolor="#f6f6f6"><td>'.$it618_sale_lang['s266'].'</td><td><input type="text" class="txt" style="width:100px;margin-right:0" id="it618_actime1" name="it618_actime1" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"> - <input type="text" class="txt" style="width:100px;margin-right:0" id="it618_actime2" name="it618_actime2" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"> <font color=red>'.$it618_sale_lang['s652'].'</font></td></tr>
<tr bgcolor="#f6f6f6"><td>'.$it618_sale_lang['s267'].'</td><td><input type="text" class="txt" style="width:100px;margin-right:0" name="it618_acsalebl"> % <font color=red>'.$it618_sale_lang['s653'].'</font></td></tr>
<tr bgcolor="#f6f6f6"><td>'.$it618_sale_lang['s649'].'</td><td><input type="text" class="txt" style="width:100px;margin-right:0" id="it618_quantime1" name="it618_quantime1" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"> - <input type="text" class="txt" style="width:100px;margin-right:0" id="it618_quantime2" name="it618_quantime2" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"></td></tr>
<tr bgcolor="#f6f6f6"><td>'.$it618_sale_lang['s648'].'</td><td><input type="text" class="txt" style="width:380px;margin-right:0" id="it618_quanstr" name="it618_quanstr"> </td></tr>
<tr bgcolor="#f6f6f6"><td>'.$it618_sale_lang['s650'].'</td><td><input type="text" class="txt" style="width:696px;margin-right:0" id="it618_quanurl" name="it618_quanurl"><br></td></tr>
<tr><td>'.$it618_sale_lang['s263'].'</td><td><textarea name="it618_message1" style="width:700px;height:300px;visibility:hidden;">'.$productvalue.'</textarea></td></tr>
<tr><td>'.$it618_sale_lang['s264'].'</td><td><textarea name="it618_message2" style="width:700px;height:300px;visibility:hidden;">'.$wapproductvalue.'</textarea><br><font color=red>'.$it618_sale_lang['s265'].'</font></td></tr>
<tr><td>'.$it618_sale_lang['s259'].'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;"></textarea></td></tr>
<tr><td>'.$it618_sale_lang['s260'].'</td><td><input type="text" class="txt" style="width:696px;margin-right:0" name="it618_seokeywords"></td></tr>
<tr><td>'.$it618_sale_lang['s261'].'</td><td><textarea name="it618_seodescription" style="width:696px;height:60px;"></textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.$it618_sale_lang['s156'].'" /></div></td></tr>';

if(count($reabc)!=10)return;
echo '<script charset="utf-8" src="source/plugin/it618_sale/js/Calendar.js"></script>';
showtablefooter(); //dis'.'m.tao'.'bao.com
?>