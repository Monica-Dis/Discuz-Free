<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/moneydaoset.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/moneydaoset.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/moneydaoset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		$fileData .= '$dao_time1=\''.'1'."';\n";
		
		$fileData .= '$dao_name=\''.'3'."';\n";
		
		$fileData .= '$dao_productid=\''.'4'."';\n";
		
		$fileData .= '$dao_count=\''.'7'."';\n";
		
		$fileData .= '$dao_salebl=\''.'11'."';\n";
		
		$fileData .= '$dao_money=\''.'13'."';\n";
		
		$fileData .= '$dao_salemoney=\''.'16'."';\n";
		
		$fileData .= '$dao_time2=\''.'17'."';\n";
		
		$fileData .= '$dao_saleid=\''.'25'."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		require_once DISCUZ_ROOT.'./source/plugin/it618_sale/moneydaoset.php';
	}
}

if(submitcheck('it618submit_dao')){
	if (preg_match('/\.\./', $_GET['it618_pname_dao'])||$_GET['it618_pname_dao']=='') {
		cpmsg($it618_sale_lang['s282'], "action=plugins&identifier=$identifier&cp=admin_money_dao&pmod=admin_money&operation=$operation&do=$do", 'error');
	}
	
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/moneydaoset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {

		$fileData .= '$dao_time1=\''.trim($_GET['dao_time1'])."';\n";
		
		$fileData .= '$dao_name=\''.trim($_GET['dao_name'])."';\n";
		
		$fileData .= '$dao_productid=\''.trim($_GET['dao_productid'])."';\n";
		
		$fileData .= '$dao_count=\''.trim($_GET['dao_count'])."';\n";
		
		$fileData .= '$dao_salebl=\''.trim($_GET['dao_salebl'])."';\n";
		
		$fileData .= '$dao_money=\''.trim($_GET['dao_money'])."';\n";
		
		$fileData .= '$dao_salemoney=\''.trim($_GET['dao_salemoney'])."';\n";
		
		$fileData .= '$dao_time2=\''.trim($_GET['dao_time2'])."';\n";
		
		$fileData .= '$dao_saleid=\''.trim($_GET['dao_saleid'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	$tmparr=explode("source/plugin/it618_sale/kindeditor",$_GET['it618_pname_dao']);
	$file_path='source/plugin/it618_sale/kindeditor'.$tmparr[1];
	
	$it618_daoid=$tmparr[1];
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/phpexcel/reader.php';

	$data = new Spreadsheet_Excel_Reader();
	
	$data->setOutputEncoding('GB2312');
	
	$data->read(DISCUZ_ROOT.'./'.$file_path);

	error_reporting(E_ALL ^ E_NOTICE);
	
	$dao_time1= intval($_GET['dao_time1']);
		
	$dao_name= intval($_GET['dao_name']);
	
	$dao_productid = intval($_GET['dao_productid']);
	
	$dao_count = intval($_GET['dao_count']);
	
	$dao_salebl = intval($_GET['dao_salebl']);
	
	$dao_money = intval($_GET['dao_money']);
	
	$dao_salemoney = intval($_GET['dao_salemoney']);
	
	$dao_time2 = intval($_GET['dao_time2']);
	
	$dao_saleid = intval($_GET['dao_saleid']);
	
	$ok=0;$ok1=0;
	for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {
		for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) {
			$msgtmpstr='';
			$it618_saleid=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_saleid]));
			if($it618_saleid==''){$flag=1;break;}
			$count=C::t('#it618_sale#it618_sale_money')->count_by_saleid_daoid1($it618_saleid,$it618_daoid);
			if($count>0){
				$msgtmpstr.=$it618_sale_lang['s397'];
			}
			
			$it618_pname=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_name]));
			if($it618_pname==''){
				$msgtmpstr.=$it618_sale_lang['s398'];
			}
			
			$it618_productid=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_productid]));
			if($it618_productid==''){
				$msgtmpstr.=$it618_sale_lang['s399'];
			}
			
			$it618_count=intval(trim($data->sheets[0]['cells'][$i][$dao_count]));
			if($it618_count==0){
				$msgtmpstr.=$it618_sale_lang['s400'];
			}
			
			$it618_salebl=floatval(trim($data->sheets[0]['cells'][$i][$dao_salebl]));
			if($it618_salebl==0){
				$msgtmpstr.=$it618_sale_lang['s401'];
			}
			
			$it618_money=floatval(trim($data->sheets[0]['cells'][$i][$dao_money]));
			if($it618_money==0){
				$msgtmpstr.=$it618_sale_lang['s402'];
			}
			
			$it618_salemoney=floatval(trim($data->sheets[0]['cells'][$i][$dao_salemoney]));
			if($it618_salemoney==0){
				$msgtmpstr.=$it618_sale_lang['s403'];
			}
			
			$it618_time1=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_time1]));
			if($it618_time1==''){
				$msgtmpstr.=$it618_sale_lang['s411'];
			}
			
			$it618_time2=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_time2]));
			if($it618_time2==''){
				$msgtmpstr.=$it618_sale_lang['s410'];
			}
	
		}
		
		if($flag==1)break;
		
		if($msgtmpstr==''){
			
			$count=C::t('#it618_sale#it618_sale_money')->count_by_saleid_daoid($it618_saleid,$it618_daoid);
			if($count>0){
				C::t('#it618_sale#it618_sale_money')->update_count_money_by_saleid($it618_count,$it618_money,$it618_salemoney,$it618_saleid);
			}else{
				C::t('#it618_sale#it618_sale_money')->insert(array(
					'it618_daoid' => $it618_daoid,
					'it618_saleid' => $it618_saleid,
					'it618_productid' => $it618_productid,
					'it618_pname' => $it618_pname,
					'it618_money' => $it618_money,
					'it618_salebl' => $it618_salebl,
					'it618_salemoney' => $it618_salemoney,
					'it618_count' => $it618_count,
					'it618_time1' => strtotime($it618_time1),
					'it618_time2' => strtotime($it618_time2)
				), true);
				
			}
			
			$ok=$ok+1;
		}else{
			$msgstr.='<br><b>'.$it618_sale_lang['s405'].$i.$it618_sale_lang['s406'].$it618_pname.'</b><br>'.$msgtmpstr.'<br>';
			$ok1=$ok1+1;
		}
	
	}

	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	if($ok1>0){
		$msgstr='<br><div style="color:red;font-weight:normal;text-align:left">'.$it618_sale_lang['s407'].$ok1.$it618_sale_lang['s408'].'<br>'.$msgstr.'</div>';
		cpmsg($it618_sale_lang['s409'].$ok.$msgstr, "", 'succeed');
	}else{
		cpmsg($it618_sale_lang['s409'].$ok, "action=plugins&identifier=$identifier&cp=admin_money&pmod=admin_money&operation=$operation&do=$do", 'succeed');
	}
}

echo '
<link rel="stylesheet" href="source/plugin/it618_sale/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/kindeditor-min.js"></script>
<script>
	KindEditor.ready(function(K) {
				var uploadbutton = K.uploadbutton({
					button : K(\'#btn_upfile\')[0],
					fieldName : \'imgFile\',
					url : \'source/plugin/it618_sale/kindeditor/php/upload_json.php?dir=file&filetype=xls\',
					afterUpload : function(data) {
						if (data.error === 0) {
							var url = K.formatUrl(data.url, \'absolute\');
							K(\'#it618_pname_dao\').val(url);
						} else {
							alert(data.message);
						}
					},
					afterError : function(str) {
						alert(str);
					}
				});
				uploadbutton.fileBox.change(function(e) {
					uploadbutton.submit();
				});
			});
</script>';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_money_dao&pmod=admin_money&operation=$operation&do=$do");
showtableheaders($it618_sale_lang['s393'],'it618_sale_money');

$tmpstr='
<option value="1">A</option><option value="2">B</option><option value="3">C</option><option value="4">D</option><option value="5">E</option>
<option value="6">F</option><option value="7">G</option><option value="8">H</option><option value="9">I</option><option value="10">J</option>
<option value="11">K</option><option value="12">L</option><option value="13">M</option><option value="14">N</option><option value="15">O</option>
<option value="16">P</option><option value="17">Q</option><option value="18">R</option><option value="19">S</option><option value="20">T</option>
<option value="21">U</option><option value="22">V</option><option value="23">W</option><option value="24">X</option><option value="25">Y</option>
<option value="26">Z</option>';

$dao_time1=str_replace('<option value="'.$dao_time1.'">','<option value="'.$dao_time1.'" selected="selected">',$tmpstr);
$dao_name=str_replace('<option value="'.$dao_name.'">','<option value="'.$dao_name.'" selected="selected">',$tmpstr);
$dao_productid=str_replace('<option value="'.$dao_productid.'">','<option value="'.$dao_productid.'" selected="selected">',$tmpstr);
$dao_count=str_replace('<option value="'.$dao_count.'">','<option value="'.$dao_count.'" selected="selected">',$tmpstr);
$dao_salebl=str_replace('<option value="'.$dao_salebl.'">','<option value="'.$dao_salebl.'" selected="selected">',$tmpstr);
$dao_money=str_replace('<option value="'.$dao_money.'">','<option value="'.$dao_money.'" selected="selected">',$tmpstr);
$dao_salemoney=str_replace('<option value="'.$dao_salemoney.'">','<option value="'.$dao_salemoney.'" selected="selected">',$tmpstr);
$dao_time2=str_replace('<option value="'.$dao_time2.'">','<option value="'.$dao_time2.'" selected="selected">',$tmpstr);
$dao_saleid=str_replace('<option value="'.$dao_saleid.'">','<option value="'.$dao_saleid.'" selected="selected">',$tmpstr);

echo '
<style>
.daocss{color:blue;font-weight:bold;margin-right:6px;text-align:center}
.must{color:red}
.money tr td{border:#ccc 1px solid;text-align:center}
.trtitle td{background:#f9f9f9; height:18px}
</style>
<tr><td colspan=14><b>'.$it618_sale_lang['s527'].'</b></td></tr>
<tr><td colspan=14>
<table class="money" width="68%">
<tr class="trtitle"><td>'.$it618_sale_lang['s530'].'</td><td>'.$it618_sale_lang['s531'].'</td><td>'.$it618_sale_lang['s532'].'</td><td>'.$it618_sale_lang['s533'].'</td><td>'.$it618_sale_lang['s534'].'</td><td>'.$it618_sale_lang['s535'].'</td><td>'.$it618_sale_lang['s536'].'</td><td><font color=red>'.$it618_sale_lang['s537'].'</font></td><td>'.$it618_sale_lang['s538'].'</td></tr>
<tr><td><select class="daocss must" name="dao_time1">'.$dao_time1.'</select></td>
<td><select class="daocss must" name="dao_name">'.$dao_name.'</select></td>
<td><select class="daocss must" name="dao_productid">'.$dao_productid.'</select></td>
<td><select class="daocss must" name="dao_count">'.$dao_count.'</select></td>
<td><select class="daocss must" name="dao_salebl">'.$dao_salebl.'</select></td>
<td><select class="daocss must" name="dao_money">'.$dao_money.'</select></td>
<td><select class="daocss must" name="dao_salemoney">'.$dao_salemoney.'</select></td>
<td><select class="daocss must" name="dao_time2">'.$dao_time2.'</select></td>
<td><select class="daocss must" name="dao_saleid">'.$dao_saleid.'</select></td>
</tr>
</table>
</td></tr>
<tr><td colspan=14 style="line-height:26px"><font color=red>'.$it618_sale_lang['s323'].'</font>['.$it618_sale_lang['s395'].']<br>'.$it618_sale_lang['s396'].'</td></tr>
<tr><td colspan=14><input id="it618_pname_dao" name="it618_pname_dao" class="txt" style="width:300px" value=""><input type="submit" class="btn" id="btn_upfile" value="'.$it618_sale_lang['s274'].'"/>
<br><input type="submit" class="btn" name="it618submit_dao" onclick="return checkvalue()" value="'.$it618_sale_lang['s276'].'"/></td></tr>
<script>

function checkvalue(){
	if(confirm(\''.$it618_sale_lang['s330'].'\')){
		if(document.getElementById("it618_pname_dao").value==""){
			alert("'.$it618_sale_lang['s282'].'");
			return false;
		}
	}else{
		return false;
	}
}

</script>
';

if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>