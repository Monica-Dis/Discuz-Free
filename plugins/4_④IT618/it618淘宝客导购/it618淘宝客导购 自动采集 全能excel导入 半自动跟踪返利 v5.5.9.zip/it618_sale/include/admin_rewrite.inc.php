<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$sale_home=\''.'sale'."';\n";
		$fileData .= '$sale_list=\''.'sale_list'."';\n";
		$fileData .= '$sale_search=\''.'sale_search'."';\n";
		$fileData .= '$sale_product=\''.'sale_product'."';\n";
		$fileData .= '$sale_wap=\''.'sale_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$sale_home1=\''.$urltype."';\n";
		$fileData .= '$sale_list1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$sale_search1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$sale_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$sale_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);

		require DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$sale_home=\''.str_replace("-","",$_GET['sale_home'])."';\n";
		$fileData .= '$sale_list=\''.str_replace("-","",$_GET['sale_list'])."';\n";
		$fileData .= '$sale_search=\''.str_replace("-","",$_GET['sale_search'])."';\n";
		$fileData .= '$sale_product=\''.str_replace("-","",$_GET['sale_product'])."';\n";
		$fileData .= '$sale_wap=\''.str_replace("-","",$_GET['sale_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$sale_home1=\''.$urltype."';\n";
		$fileData .= '$sale_list1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$sale_search1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$sale_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$sale_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_sale_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_rewrite&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rewrite&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_sale_lang['s136'].'</font></td></tr>
<tr><td colspan="3">'.$it618_sale_lang['s137'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_sale_lang['s138'].'</th><th>'.$it618_sale_lang['s139'].'</th><th>'.$it618_sale_lang['s140'].'</th></tr>
<tr class="hover">
<td>'.$it618_sale_lang['s141'].'</td><td></td><td class="longtxt"><input name="sale_home" value="'.$sale_home.'"/>'.$sale_home.$sale_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_sale_lang['s142'].'</td><td>{cid1}, {cid2}, {price}, {order}, {page}</td><td class="longtxt"><input name="sale_list" value="'.$sale_list.'" />'.$sale_list.$sale_list1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_sale_lang['s143'].'</td><td>{cid1}, {cid2}, {price}, {order}, {page}</td><td class="longtxt"><input name="sale_search" value="'.$sale_search.'" />'.$sale_search.$sale_search1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_sale_lang['s144'].'</td><td>{pid}</td><td class="longtxt"><input name="sale_product" value="'.$sale_product.'" />'.$sale_product.$sale_product1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_sale_lang['s147'].'</td><td>{pagetype}, {cid1}, {cid2}</td><td class="longtxt"><input name="sale_wap" value="'.$sale_wap.'"/>'.$sale_wap.$sale_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_sale_lang['s23']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_sale_lang['s148'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_home.$urltype.'$ $1/plugin.php?id=it618_sale:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:list&class1=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:list&class1=$2&class2=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_search.$urltype.'$ $1/plugin.php?id=it618_sale:search&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:product&pid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_wap.$urltype.'$ $1/plugin.php?id=it618_sale:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:wap&pagetype=$2&cid1=$3&cid2=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:wap&pagetype=$2&cid1=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$sale_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_sale:wap&pagetype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_sale_lang['s149'].'</h1>
<pre class="colorbox">
'.$it618_sale_lang['s150'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_home.$urltype.'$ plugin.php?id=it618_sale:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_list.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_sale:list&class1=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_sale:list&class1=$1&class2=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_sale:list&class1=$1&class2=$2&price=$3&order=$4&page=$5&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_search.$urltype.'$ plugin.php?id=it618_sale:search&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_sale:search&class1=$1&class2=$2&price=$3&order=$4&page=$5&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_product.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_sale:product&pid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_wap.$urltype.'$ plugin.php?id=it618_sale:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_sale:wap&pagetype=$1&cid1=$2&cid2=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_sale:wap&pagetype=$1&cid1=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$sale_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_sale:wap&pagetype=$1&%1</font>

</pre>

<h1>'.$it618_sale_lang['s151'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$sale_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:index&$3
RewriteRule ^(.*)/'.$sale_list.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:list&class1=$2&$4
RewriteRule ^(.*)/'.$sale_list.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:list&class1=$2&class2=$3&$5
RewriteRule ^(.*)/'.$sale_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&$8
RewriteRule ^(.*)/'.$sale_search.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:search&$3
RewriteRule ^(.*)/'.$sale_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&$8
RewriteRule ^(.*)/'.$sale_product.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:product&pid=$2&$4
RewriteRule ^(.*)/'.$sale_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:wap&$3
RewriteRule ^(.*)/'.$sale_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:wap&pagetype=$2&cid1=$3&cid2=$4&$6
RewriteRule ^(.*)/'.$sale_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:wap&pagetype=$2&cid1=$3&$5
RewriteRule ^(.*)/'.$sale_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_sale:wap&pagetype=$2&$4</font>

</pre>

<h1>'.$it618_sale_lang['s152'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="sale_home"&gt;
			&lt;match url="^(.*/)*'.$sale_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_list1"&gt;
			&lt;match url="^(.*/)*'.$sale_list.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:list&amp;amp;class1={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_list2"&gt;
			&lt;match url="^(.*/)*'.$sale_list.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_list4"&gt;
			&lt;match url="^(.*/)*'.$sale_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;price={R:4}&amp;amp;order={R:5}&amp;amp;page={R:6}&amp;amp;{R:7}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_search"&gt;
			&lt;match url="^(.*/)*'.$sale_search.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:search&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_search1"&gt;
			&lt;match url="^(.*/)*'.$sale_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:search&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;price={R:4}&amp;amp;order={R:5}&amp;amp;page={R:6}&amp;amp;{R:7}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_product"&gt;
			&lt;match url="^(.*/)*'.$sale_product.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:product&amp;amp;pid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_wap"&gt;
			&lt;match url="^(.*/)*'.$sale_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_wap1"&gt;
			&lt;match url="^(.*/)*'.$sale_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:wap&amp;amp;pagetype={R:2}&amp;amp;cid1={R:3}&amp;amp;cid2={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_wap2"&gt;
			&lt;match url="^(.*/)*'.$sale_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:wap&amp;amp;pagetype={R:2}&amp;amp;cid1={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="sale_wap3"&gt;
			&lt;match url="^(.*/)*'.$sale_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_sale:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$sale_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:index&$2
endif
match URL into $ with ^(.*)/'.$sale_list.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:list&class1=$2&$3
endif
match URL into $ with ^(.*)/'.$sale_list.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:list&class1=$2&class2=$3&$4
endif
match URL into $ with ^(.*)/'.$sale_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7
endif
match URL into $ with ^(.*)/'.$sale_search.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:search&$2
endif
match URL into $ with ^(.*)/'.$sale_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7
endif
match URL into $ with ^(.*)/'.$sale_product.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:product&pid=$2&$3
endif
match URL into $ with ^(.*)/'.$sale_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:wap&$2
endif
match URL into $ with ^(.*)/'.$sale_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:wap&pagetype=$2&cid1=$3&cid2=$4&$5
endif
match URL into $ with ^(.*)/'.$sale_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:wap&pagetype=$2&cid1=$3&$4
endif
match URL into $ with ^(.*)/'.$sale_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_sale:wap&pagetype=$2&$3
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$sale_home.$urltype.'$ $1/plugin.php?id=it618_sale:index&$2 last;
rewrite ^([^\.]*)/'.$sale_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:list&class1=$2&$3 last;
rewrite ^([^\.]*)/'.$sale_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:list&class1=$2&class2=$3&$4 last;
rewrite ^([^\.]*)/'.$sale_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7 last;
rewrite ^([^\.]*)/'.$sale_search.$urltype.'$ $1/plugin.php?id=it618_sale:search&$2 last;
rewrite ^([^\.]*)/'.$sale_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7 last;
rewrite ^([^\.]*)/'.$sale_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:product&pid=$2&$3 last;
rewrite ^([^\.]*)/'.$sale_wap.$urltype.'$ $1/plugin.php?id=it618_sale:wap&$2 last;
rewrite ^([^\.]*)/'.$sale_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:wap&pagetype=$2&cid1=$3&cid2=$4&$5 last;
rewrite ^([^\.]*)/'.$sale_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_sale:wap&pagetype=$2&cid1=$3&$4 last;
rewrite ^([^\.]*)/'.$sale_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_sale:wap&pagetype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com

?>