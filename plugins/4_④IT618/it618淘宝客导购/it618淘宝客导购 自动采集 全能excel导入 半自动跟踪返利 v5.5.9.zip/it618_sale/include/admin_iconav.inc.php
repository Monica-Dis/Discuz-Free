<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_sale#it618_sale_wapiconav')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_title'])) {
		foreach($_GET['it618_title'] as $id => $val) {

			C::t('#it618_sale#it618_sale_wapiconav')->update($id,array(
				'it618_title' => trim($_GET['it618_title'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_url' => trim($_GET['it618_url'][$id]),
				'it618_target' => trim($_GET['it618_target'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_isbold' => trim($_GET['it618_isbold'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_title_array = !empty($_GET['newit618_title']) ? $_GET['newit618_title'] : array();
	$newit618_url_array = !empty($_GET['newit618_url']) ? $_GET['newit618_url'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_title_array as $key => $value) {
		$newit618_title = trim($newit618_title_array[$key]);
		
		if($newit618_title != '') {
			
			C::t('#it618_sale#it618_sale_wapiconav')->insert(array(
				'it618_title' => trim($newit618_title_array[$key]),
				'it618_url' => trim($newit618_url_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_sale_lang['s33'].$ok1.' '.$it618_sale_lang['s34'].$ok2.' '.$it618_sale_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_iconav&pmod=admin_style&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_iconav&pmod=admin_style&operation=$operation&do=$do");
showtableheaders($it618_sale_lang['s1472'],'it618_sale_wapiconav');
	$count = C::t('#it618_sale#it618_sale_wapiconav')->count_by_search();
	
	echo '<tr><td colspan=8>'.$it618_sale_lang['s234'].$count.'<span style="float:right;color:red">'.$it618_sale_lang['s1477'].'</span></td></tr>';
	showsubtitle(array('', $it618_sale_lang['s235'], $it618_sale_lang['s236'], $it618_sale_lang['s237'],$it618_sale_lang['s238'],$it618_sale_lang['s239'],$it618_sale_lang['s240'],$it618_sale_lang['s241']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_wapiconav')." ORDER BY it618_order");
	while($it618_sale_wapiconav = DB::fetch($query)) {
		
		if($it618_sale_wapiconav['it618_isbold']==1)$it618_isbold_checked='checked="checked"';else $it618_isbold_checked="";
		if($it618_sale_wapiconav['it618_target']==1)$it618_target_checked='checked="checked"';else $it618_target_checked="";
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_sale_wapiconav[id]\"><input type=\"hidden\" name=\"id[$it618_sale_wapiconav[id]]\" value=\"$it618_sale_wapiconav[id]\">",
			'<img src="'.$it618_sale_wapiconav['it618_img'].'" id="img'.$it618_sale_wapiconav['id'].'" width="40" height="40" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" style="width:50px" id="url'.$it618_sale_wapiconav['id'].'" name="it618_img['.$it618_sale_wapiconav['id'].']" readonly="readonly" value="'.$it618_sale_wapiconav['it618_img'].'" /> <input type="button" id="image'.$it618_sale_wapiconav['id'].'" value="'.$it618_sale_lang['s67'].'" />',
			"<input type=\"text\" class=\"txt\" style=\"width:60px\" name=\"it618_title[$it618_sale_wapiconav[id]]\" value=\"$it618_sale_wapiconav[it618_title]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:400px\" name=\"it618_url[$it618_sale_wapiconav[id]]\" value=\"$it618_sale_wapiconav[it618_url]\">",
			'<input class="checkbox" type="checkbox" name="it618_target['.$it618_sale_wapiconav['id'].']" '.$it618_target_checked.' value="1">',
			"<input id=\"c".$it618_sale_wapiconav['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_sale_wapiconav[id]]\" value=\"$it618_sale_wapiconav[it618_color]\" onchange=\"updatecolorpreview('c".$it618_sale_wapiconav['id']."')\"><input id=\"c".$it618_sale_wapiconav['id']."\" onclick=\"c".$it618_sale_wapiconav['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_sale_wapiconav['id']."|c".$it618_sale_wapiconav['id']."_v';showMenu({'ctrlid':'c".$it618_sale_wapiconav['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_sale_wapiconav['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_sale_wapiconav['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			'<input class="checkbox" type="checkbox" name="it618_isbold['.$it618_sale_wapiconav['id'].']" '.$it618_isbold_checked.' value="1">',
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_sale_wapiconav['id'].']" value="'.$it618_sale_wapiconav['it618_order'].'">',
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_sale_wapiconav['id']."');";
		$editorjs.='K(\'#image'.$it618_sale_wapiconav['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_sale_wapiconav['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_sale_wapiconav['id'].'\').val(url);
								K(\'#img'.$it618_sale_wapiconav['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo '
<link rel="stylesheet" href="source/plugin/it618_sale/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_sale/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_sale/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
	$it618_sale_lang184=$it618_sale_lang['s68'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_title[]").length;
	
		return [
		[[1,''], [1, '$it618_sale_lang184'], [1,'<input type="text" class="txt" style=\"width:60px\" name="newit618_title[]">'], [1,'<input type="text" class="txt" style=\"width:400px\" name="newit618_url[]">'], [1,''], [1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1,''], [1, ' <input class="txt" type="text" style="width:30px" name="newit618_order[]" value="1">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
    echo '<tr><td></td><td colspan="3">'.$it618_sale_lang['t59'].'</td></tr>';
	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>