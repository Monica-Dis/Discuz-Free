<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/daoset.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/daoset.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/daoset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		$fileData .= '$dao_id=\''.'1'."';\n";
		
		$fileData .= '$dao_name=\''.'2'."';\n";
		
		$fileData .= '$dao_pic=\''.'3'."';\n";
		
		$fileData .= '$dao_price=\''.'6'."';\n";
		
		$fileData .= '$dao_smallurl=\''.'16'."';\n";
		
		$fileData .= '$dao_url=\''.'17'."';\n";
		
		$fileData .= '$dao_codeurl=\''.'18'."';\n";
		
		$fileData .= '$dao_acbl=\''.'11'."';\n";
		
		$fileData .= '$dao_actime1=\''.'13'."';\n";
		
		$fileData .= '$dao_actime2=\''.'14'."';\n";
		
		$fileData .= '$dao_quanmoney=\''.'21'."';\n";
		
		$fileData .= '$dao_quantime1=\''.'22'."';\n";
		
		$fileData .= '$dao_quantime2=\''.'23'."';\n";
		
		$fileData .= '$dao_quanurl=\''.'24'."';\n";
		
		$fileData .= '$dao_quancodeurl=\''.'25'."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		require_once DISCUZ_ROOT.'./source/plugin/it618_sale/daoset.php';
	}
}

if(submitcheck('it618submit_dao')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/daoset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {

		$fileData .= '$dao_id=\''.trim($_GET['dao_id'])."';\n";
		
		$fileData .= '$dao_name=\''.trim($_GET['dao_name'])."';\n";
		
		$fileData .= '$dao_pic=\''.trim($_GET['dao_pic'])."';\n";
		
		$fileData .= '$dao_price=\''.trim($_GET['dao_price'])."';\n";
		
		$fileData .= '$dao_smallurl=\''.trim($_GET['dao_smallurl'])."';\n";
		
		$fileData .= '$dao_url=\''.trim($_GET['dao_url'])."';\n";
		
		$fileData .= '$dao_codeurl=\''.trim($_GET['dao_codeurl'])."';\n";
		
		$fileData .= '$dao_acbl=\''.trim($_GET['dao_acbl'])."';\n";
		
		$fileData .= '$dao_actime1=\''.trim($_GET['dao_actime1'])."';\n";
		
		$fileData .= '$dao_actime2=\''.trim($_GET['dao_actime2'])."';\n";
		
		$fileData .= '$dao_quanmoney=\''.trim($_GET['dao_quanmoney'])."';\n";
		
		$fileData .= '$dao_quantime1=\''.trim($_GET['dao_quantime1'])."';\n";
		
		$fileData .= '$dao_quantime2=\''.trim($_GET['dao_quantime2'])."';\n";
		
		$fileData .= '$dao_quanurl=\''.trim($_GET['dao_quanurl'])."';\n";
		
		$fileData .= '$dao_quancodeurl=\''.trim($_GET['dao_quancodeurl'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	if (preg_match('/\.\./', $_GET['it618_name_dao'])||$_GET['it618_name_dao']=='') {
		cpmsg($it618_sale_lang['s282'], "action=plugins&identifier=$identifier&cp=admin_product_dao&pmod=admin_product&operation=$operation&do=$do&dw=$dw", 'error');
	}
	
	if($_GET['getgoodscategory']==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
		$checkstr=it618_sale_addquancheck();
		if($checkstr!='OK'){
			cpmsg($checkstr, "action=plugins&identifier=$identifier&cp=admin_product_dao&pmod=admin_product&operation=$operation&do=$do&dw=$dw", 'error');
		}
	}
	
	$tmparr=explode("source/plugin/it618_sale/kindeditor",$_GET['it618_name_dao']);
	$file_path='source/plugin/it618_sale/kindeditor'.$tmparr[1];
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/phpexcel/reader.php';

	$data = new Spreadsheet_Excel_Reader();
	
	$data->setOutputEncoding('GB2312');
	
	$data->read(DISCUZ_ROOT.'./'.$file_path);

	error_reporting(E_ALL ^ E_NOTICE);
	
	if($_GET['it618_type']=='1'){
		
		$dao_class1= 1;
		
		$dao_class2= 2;
		
		$dao_id= 3;
		
		$dao_name= 4;
		
		$dao_pic = 5;
		
		$dao_price = 6;
		
		$dao_smallurl = 7;
		
		$dao_url = 8;
		
		$dao_codeurl = 9;
		
		$dao_acbl = 10;
		
		$dao_actime1 = 11;
		
		$dao_actime2 = 12;
		
		$dao_quanmoney = 13;
		
		$dao_quantime1 = 14;
		
		$dao_quantime2 = 15;
		
		$dao_quanurl = 16;
		
		$dao_quancodeurl = 17;
	}else{
		$dao_class1= 0;
		
		$dao_class2= 0;
		
		$dao_id= intval($_GET['dao_id']);
		
		$dao_name= intval($_GET['dao_name']);
		
		$dao_pic = intval($_GET['dao_pic']);
		
		$dao_price = intval($_GET['dao_price']);
		
		$dao_smallurl = intval($_GET['dao_smallurl']);
		
		$dao_url = intval($_GET['dao_url']);
		
		$dao_codeurl = intval($_GET['dao_codeurl']);
		
		$dao_acbl = intval($_GET['dao_acbl']);
		
		$dao_actime1 = intval($_GET['dao_actime1']);
		
		$dao_actime2 = intval($_GET['dao_actime2']);
		
		$dao_quanmoney = intval($_GET['dao_quanmoney']);
		
		$dao_quantime1 = intval($_GET['dao_quantime1']);
		
		$dao_quantime2 = intval($_GET['dao_quantime2']);
		
		$dao_quanurl = intval($_GET['dao_quanurl']);
		
		$dao_quancodeurl = intval($_GET['dao_quancodeurl']);
	}
	
	$ok=0;$ok1=0;$ok2=0;
	for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {
		$msgtmpstr='';
		
		$it618_name=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_name]));
		if($it618_name==''){
			if(it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i+1][$dao_name]))==''&&it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i+2][$dao_name]))==''){
				break;
			}else{
				continue;
			}
		}
		
		if($dao_class1>0){
			$it618_class1_id=intval(trim($data->sheets[0]['cells'][$i][$dao_class1]));
		}else{
			$it618_class1_id=intval($_GET['it618_class1_id']);
		}
		
		if($it618_sale_class1=C::t('#it618_sale#it618_sale_class1')->fetch_by_id($it618_class1_id)){
			$it618_class1_id=$it618_sale_class1['id'];
		}else{
			$msgtmpstr.=$it618_sale_lang['s284'].$it618_class1_id.$it618_sale_lang['s285'];
		}
		
		if($dao_class2>0){
			$it618_class2_id=intval(trim($data->sheets[0]['cells'][$i][$dao_class2]));
		}else{
			$it618_class2_id=intval($_GET['it618_class2_id']);
		}
		
		if($it618_sale_class2=C::t('#it618_sale#it618_sale_class2')->fetch_by_id($it618_class2_id)){
			$it618_class2_id=$it618_sale_class2['id'];
		}else{
			$msgtmpstr.=$it618_sale_lang['s286'].$it618_class2_id.$it618_sale_lang['s285'];
		}
		
		$it618_pic=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_pic]));
		if($it618_pic==''){
			$msgtmpstr.=$it618_sale_lang['s287'];
		}
		
		$it618_price=floatval(trim($data->sheets[0]['cells'][$i][$dao_price]));
		if($it618_price==0){
			$msgtmpstr.=$it618_sale_lang['s288'];
		}
		
		$it618_url1=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_smallurl]));
		$it618_url2=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_url]));
		//$it618_codeurl=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_codeurl]));
		$it618_url=$it618_url2;
		if($it618_url1!='')$it618_url=$it618_url1;
		if($it618_url==''){
			$msgtmpstr.=$it618_sale_lang['s289'];
		}
		
		$actimeflag=0;
		$it618_acsalebl=floatval(trim($data->sheets[0]['cells'][$i][$dao_acbl]));
		if($dao_actime1>0&&$dao_actime2>0){
			$it618_actime1=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_actime1]));
			$it618_actime2=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_actime2]));
			if(checktime($it618_actime1)&&checktime($it618_actime2)){
				if(strtotime($it618_actime2)>$_G['timestamp']){
					$actimeflag=1;
				}
			}
		
			if($actimeflag!=1){
				$msgtmpstr.=$it618_sale_lang['s290'];
			}
		}
		
		$quantimeflag=0;
		if($dao_quanmoney>0){
			$it618_quanstr=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_quanmoney]));
			$it618_quantime1=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_quantime1]));
			$it618_quantime2=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_quantime2]));
			$it618_quanurl=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_quanurl]));
			//$it618_quancodeurl=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_quancodeurl]));
			
			if($it618_quantime2!=''){
				$tmpquantime=explode(":",$it618_quantime2);
				if(count($tmpquantime)==1){
					$it618_quantime2=$it618_quantime2.' 23:59:59';
				}
			}
			
			if($it618_quantime1==''&&$it618_quantime2=='')$quantimeflag=1;
			if($it618_quantime1!=''&&$it618_quantime2!=''){
				if(strtotime($it618_quantime2)>$_G['timestamp']){
					$quantimeflag=1;
				}
			}
			if($it618_quanstr==$it618_sale_lang['s291']){
				$quantimeflag=1;
				$it618_quanstr='';
				$it618_quanurl='';
				$it618_quantime1='';
				$it618_quantime2='';
			}else{
				$tmpquantime=explode($it618_sale_lang['s689'],$it618_quanstr);
				if(count($tmpquantime)==1){
					$it618_quanstr=$it618_quanstr.$it618_sale_lang['s690'];
				}
			}
			
			if($quantimeflag!=1){
				$msgtmpstr.=$it618_sale_lang['s292'];
			}
		}
	
		
		if($msgtmpstr==''){
			
			$it618_productid=it618_sale_utftogbk(trim($data->sheets[0]['cells'][$i][$dao_id]));
			
			if($it618_sale_goods=C::t('#it618_sale#it618_sale_goods')->fetch_by_productid($it618_productid)){
				$pid=$it618_sale_goods['id'];
				C::t('#it618_sale#it618_sale_goods')->update($it618_sale_goods['id'],array(
					'it618_class1_id' => $it618_class1_id,
					'it618_class2_id' => $it618_class2_id,
					'it618_productid' => $it618_productid,
					'it618_name' => $it618_name,
					'it618_pcurl' => $it618_url,
					'it618_wapurl' => $it618_url,
					'it618_codeurl' => $it618_codeurl,
					'it618_name' => $it618_name,
					'it618_acsalebl' => $it618_acsalebl,
					'it618_actime1' => $it618_actime1,
					'it618_actime2' => $it618_actime2,
					'it618_quanstr' => $it618_quanstr,
					'it618_quanurl' => $it618_quanurl,
					'it618_quancodeurl' => $it618_quancodeurl,
					'it618_quantime1' => $it618_quantime1,
					'it618_quantime2' => $it618_quantime2,
					'it618_description' => $it618_name,
					'it618_seokeywords' => $it618_name,
					'it618_seodescription' => $it618_name,
					'it618_state' => 1,
					'it618_isurl' => 0,
					'it618_price' => 0,
					'it618_saleprice' => $it618_price,
					'it618_pic' => $it618_pic,
					'it618_time' => $_G['timestamp']
				));
				
				$ok2=$ok2+1;
			}else{
				if($it618_name!='')$pid=C::t('#it618_sale#it618_sale_goods')->insert(array(
					'it618_class1_id' => $it618_class1_id,
					'it618_class2_id' => $it618_class2_id,
					'it618_productid' => $it618_productid,
					'it618_name' => $it618_name,
					'it618_pcurl' => $it618_url,
					'it618_wapurl' => $it618_url,
					'it618_codeurl' => $it618_codeurl,
					'it618_name' => $it618_name,
					'it618_acsalebl' => $it618_acsalebl,
					'it618_actime1' => $it618_actime1,
					'it618_actime2' => $it618_actime2,
					'it618_quanstr' => $it618_quanstr,
					'it618_quanurl' => $it618_quanurl,
					'it618_quancodeurl' => $it618_quancodeurl,
					'it618_quantime1' => $it618_quantime1,
					'it618_quantime2' => $it618_quantime2,
					'it618_description' => $it618_name,
					'it618_seokeywords' => $it618_name,
					'it618_seodescription' => $it618_name,
					'it618_state' => 1,
					'it618_isurl' => 0,
					'it618_price' => 0,
					'it618_saleprice' => $it618_price,
					'it618_pic' => $it618_pic,
					'it618_time' => $_G['timestamp']
				), true);
				
				$ok=$ok+1;
			}
		}else{
			$msgstr.='<br><b>'.$it618_sale_lang['s293'].$i.$it618_sale_lang['s294'].$it618_name.'</b><br>'.$msgtmpstr.'<br>';
			$ok1=$ok1+1;
		}
	
	}

	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	if($ok1>0){
		$msgstr='<br><div style="color:red;font-weight:normal;text-align:left">'.$it618_sale_lang['s295'].$ok1.$it618_sale_lang['s296'].'<br>'.$msgstr.'</div>';
		cpmsg($it618_sale_lang['s297'].$ok.$it618_sale_lang['s691'].$ok2.$msgstr, "", 'succeed');
	}else{
		cpmsg($it618_sale_lang['s297'].$ok.$it618_sale_lang['s691'].$ok2, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&dw=$dw", 'succeed');
	}
}

function checktime($timestr) {
    $tmparr1=explode("-",$timestr);
	$tmparr2=explode(":",$timestr);
	$tmparr3=explode(" ",$timestr);
	
	if(count($tmparr1)==3&&count($tmparr2)==3&&count($tmparr3)==2){
		return true;
	}
	
	return false;
}

echo '
<link rel="stylesheet" href="source/plugin/it618_sale/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/kindeditor-min.js"></script>
<script>
	KindEditor.ready(function(K) {
				var uploadbutton = K.uploadbutton({
					button : K(\'#btn_upfile\')[0],
					fieldName : \'imgFile\',
					url : \'source/plugin/it618_sale/kindeditor/php/upload_json.php?dir=file&filetype=xls\',
					afterUpload : function(data) {
						if (data.error === 0) {
							var url = K.formatUrl(data.url, \'absolute\');
							K(\'#it618_name_dao\').val(url);
						} else {
							alert(data.message);
						}
					},
					afterError : function(str) {
						alert(str);
					}
				});
				uploadbutton.fileBox.change(function(e) {
					uploadbutton.submit();
				});
			});
</script>';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_product_dao&pmod=admin_product&operation=$operation&do=$do&dw=$dw");
showtableheaders($it618_sale_lang['s271'],'it618_sale_goods');

$it618_typestyle1='display:none';$it618_typestyle2='display:none';
if($it618_type=='')$it618_type='2';
if($it618_type=='1'){$it618_type1=' selected=selected';$it618_typestyle1='display:';}
if($it618_type=='2'){$it618_type2=' selected=selected';$it618_typestyle2='display:';}

$tmpstr='
<option value="1">A</option><option value="2">B</option><option value="3">C</option><option value="4">D</option><option value="5">E</option>
<option value="6">F</option><option value="7">G</option><option value="8">H</option><option value="9">I</option><option value="10">J</option>
<option value="11">K</option><option value="12">L</option><option value="13">M</option><option value="14">N</option><option value="15">O</option>
<option value="16">P</option><option value="17">Q</option><option value="18">R</option><option value="19">S</option><option value="20">T</option>
<option value="21">U</option><option value="22">V</option><option value="23">W</option><option value="24">X</option><option value="25">Y</option>
<option value="26">Z</option>';

$dao_id=str_replace('<option value="'.$dao_id.'">','<option value="'.$dao_id.'" selected="selected">',$tmpstr);
$dao_name=str_replace('<option value="'.$dao_name.'">','<option value="'.$dao_name.'" selected="selected">',$tmpstr);
$dao_pic=str_replace('<option value="'.$dao_pic.'">','<option value="'.$dao_pic.'" selected="selected">',$tmpstr);
$dao_price=str_replace('<option value="'.$dao_price.'">','<option value="'.$dao_price.'" selected="selected">',$tmpstr);
$dao_smallurl=str_replace('<option value="'.$dao_smallurl.'">','<option value="'.$dao_smallurl.'" selected="selected">',$tmpstr);
$dao_url=str_replace('<option value="'.$dao_url.'">','<option value="'.$dao_url.'" selected="selected">',$tmpstr);
$dao_codeurl=str_replace('<option value="'.$dao_codeurl.'">','<option value="'.$dao_codeurl.'" selected="selected">',$tmpstr);
$dao_acbl=str_replace('<option value="'.$dao_acbl.'">','<option value="'.$dao_acbl.'" selected="selected">',$tmpstr);
$dao_actime1=str_replace('<option value="'.$dao_actime1.'">','<option value="'.$dao_actime1.'" selected="selected">',$tmpstr);
$dao_actime2=str_replace('<option value="'.$dao_actime2.'">','<option value="'.$dao_actime2.'" selected="selected">',$tmpstr);
$dao_quanmoney=str_replace('<option value="'.$dao_quanmoney.'">','<option value="'.$dao_quanmoney.'" selected="selected">',$tmpstr);
$dao_quantime1=str_replace('<option value="'.$dao_quantime1.'">','<option value="'.$dao_quantime1.'" selected="selected">',$tmpstr);
$dao_quantime2=str_replace('<option value="'.$dao_quantime2.'">','<option value="'.$dao_quantime2.'" selected="selected">',$tmpstr);
$dao_quanurl=str_replace('<option value="'.$dao_quanurl.'">','<option value="'.$dao_quanurl.'" selected="selected">',$tmpstr);
$dao_quancodeurl=str_replace('<option value="'.$dao_quancodeurl.'">','<option value="'.$dao_quancodeurl.'" selected="selected">',$tmpstr);

foreach(C::t('#it618_sale#it618_sale_class1')->fetch_all_by_search() as $it618_tmp) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$classcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_sale_class2'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class1')." ORDER BY it618_order");
$n1=1;
$classtmp='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_sale_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$classtmp.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

echo '
<style>
.daocss{color:blue;font-weight:bold;margin-right:6px;text-align:center}
.must{color:red}
</style>
<tr style="display:none"><td colspan=14>'.$it618_sale_lang['s526'].'<select id="it618_type" name="it618_type" onchange="gettype(this)"><option value="1" '.$it618_type1.'>'.$it618_sale_lang['s521'].'</option><option value="2" '.$it618_type2.'>'.$it618_sale_lang['s522'].'</option></select></td></tr>
<tr name="tr_1" style="background-color:#fff;'.$it618_typestyle1.'"><td colspan=14 style="line-height:26px">'.$it618_sale_lang['s272'].'</td></tr>
<tr name="tr_2" style="background-color:#fff;'.$it618_typestyle2.'"><td colspan=14><b>'.$it618_sale_lang['s527'].'</b></td></tr>
<tr name="tr_2" style="background-color:#fff;'.$it618_typestyle2.'"><td colspan=14>
<font color=#999>'.$it618_sale_lang['s300'].'</font>
<select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)"><option value="0">'.$it618_sale_lang['s19'].'</option>'.$classtmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.$it618_sale_lang['s20'].'</option></select>
</td></tr>
<tr name="tr_2" style="background-color:#fff;'.$it618_typestyle2.'"><td colspan=14>
<font color=#999>'.$it618_sale_lang['s304'].'</font>
'.$it618_sale_lang['s305'].'<select class="daocss must" name="dao_id">'.$dao_id.'</select>
'.$it618_sale_lang['s306'].'<select class="daocss must" name="dao_name">'.$dao_name.'</select>
'.$it618_sale_lang['s307'].'<select class="daocss must" name="dao_pic">'.$dao_pic.'</select>
'.$it618_sale_lang['s308'].'<select class="daocss must" name="dao_price">'.$dao_price.'</select>
'.$it618_sale_lang['s313'].'<select class="daocss must" name="dao_acbl">'.$dao_acbl.'</select>
'.$it618_sale_lang['s310'].'<select class="daocss must" name="dao_url">'.$dao_url.'</select>
'.$it618_sale_lang['s309'].'<select class="daocss" name="dao_smallurl"><option value="0">'.$it618_sale_lang['s528'].'</option>'.$dao_smallurl.'</select>
<span style="display:none">'.$it618_sale_lang['s524'].'<select class="daocss" name="dao_codeurl"><option value="0">'.$it618_sale_lang['s528'].'</option>'.$dao_codeurl.'</select></span>
</td></tr>
<tr name="tr_2" style="background-color:#fff;'.$it618_typestyle2.'"><td colspan=14>
<font color=#999>'.$it618_sale_lang['s312'].'</font>
'.$it618_sale_lang['s314'].'<select class="daocss" name="dao_actime1"><option value="0">'.$it618_sale_lang['s528'].'</option>'.$dao_actime1.'</select>
'.$it618_sale_lang['s315'].'<select class="daocss" name="dao_actime2"><option value="0">'.$it618_sale_lang['s528'].'</option>'.$dao_actime2.'</select>
<br><div style="margin-left:65px;margin-top:3px;line-height:18px"><font color=green>'.$it618_sale_lang['s316'].'<br>'.$it618_sale_lang['s652'].'</font></div>
</td></tr>
<tr name="tr_2" style="background-color:#fff;'.$it618_typestyle2.'"><td colspan=14>
<font color=#999>'.$it618_sale_lang['s317'].'</font>
'.$it618_sale_lang['s318'].'<select class="daocss" name="dao_quanmoney"><option value="0">'.$it618_sale_lang['s528'].'</option>'.$dao_quanmoney.'</select>
'.$it618_sale_lang['s319'].'<select class="daocss" name="dao_quantime1">'.$dao_quantime1.'</select>
'.$it618_sale_lang['s320'].'<select class="daocss" name="dao_quantime2">'.$dao_quantime2.'</select>
'.$it618_sale_lang['s321'].'<select class="daocss" name="dao_quanurl">'.$dao_quanurl.'</select>
<span style="display:none">'.$it618_sale_lang['s525'].'<select class="daocss" name="dao_quancodeurl">'.$dao_quancodeurl.'</select></span>
<br><div style="margin-left:65px;margin-top:3px;line-height:18px"><font color=green>'.$it618_sale_lang['s322'].'<br>'.$it618_sale_lang['s324'].'</font></div>
</td></tr>
<tr name="tr_2" style="background-color:#fff;'.$it618_typestyle2.'"><td colspan=14 style="line-height:26px">'.$it618_sale_lang['s523'].'</td></tr>
<tr><td colspan=14><input id="it618_name_dao" name="it618_name_dao" class="txt" style="width:300px" value=""><input type="submit" class="btn" id="btn_upfile" value="'.$it618_sale_lang['s274'].'"/>
<br><input type="submit" class="btn" name="it618submit_dao" onclick="return checkvalue()" value="'.$it618_sale_lang['s276'].'"/></td></tr>
<script>

function gettype(obj){
	var trobj=document.getElementsByName("tr_1");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}
	
	var trobj=document.getElementsByName("tr_2");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}

	var trobj=document.getElementsByName("tr_"+obj.value);
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="";
	}
}

function checkvalue(){
	if(confirm(\''.$it618_sale_lang['s330'].'\')){
		if(document.getElementById("it618_type").value==1)return true;
		
		if(document.getElementById("it618_class2_id").value=="0"){
			alert("'.$it618_sale_lang['s124'].'");
			return false;
		}
		if(document.getElementById("it618_name_dao").value==""){
			alert("'.$it618_sale_lang['s282'].'");
			return false;
		}
	}else{
		return false;
	}
}

var arrcount='.$classcount.';
var select_class = new Array(arrcount+1);

for (i=0; i<arrcount+1; i++) 
{
 select_class[i] = new Array();
}

'.$classtmp.'

function redirec_class(x)
{
 var temp = document.getElementById("it618_class2_id"); 
 temp.options.length=1;
 for (i=1;i<select_class[x].length;i++)
 {
  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
 }
 temp.options[0].selected=true;

}

document.getElementById("it618_class1_id").options[1].selected=true;
redirec_class(document.getElementById("it618_class1_id").options.selectedIndex);
document.getElementById("it618_class2_id").options[1].selected=true;
</script>
';

if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>