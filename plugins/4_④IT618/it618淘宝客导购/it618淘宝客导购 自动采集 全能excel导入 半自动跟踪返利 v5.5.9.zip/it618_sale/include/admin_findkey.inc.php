<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

if(count($reabc)!=10)return;

$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'];

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_findkey&pmod=admin_findkey&operation=$operation&do=$do".$sql);
showtableheaders($it618_sale_lang['s710'],'it618_sale_findkey');
showsubmit('it618sercsubmit', $it618_sale_lang['s25'], $it618_sale_lang['s352'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" />'.$it618_sale_lang['s502'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />');

	$count=C::t('#it618_sale#it618_sale_findkey')->count_by_search($it618sql,'',$_GET['key'],$_GET['finduid']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_findkey&pmod=admin_findkey&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=10>'.$it618_sale_lang['s716'].$count.'<span style="float:right;color:red">'.$it618_sale_lang['s717'].'</span></td></tr>';
	showsubtitle(array($it618_sale_lang['s712'], $it618_sale_lang['s713'],$it618_sale_lang['s714'],$it618_sale_lang['s715']));
	
	$it618_sale_findkeys=C::t('#it618_sale#it618_sale_findkey')->fetch_all_by_search($it618sql,'it618_count desc',$_GET['key'],$_GET['finduid'],$startlimit,$ppp);
	foreach($it618_sale_findkeys as $it618_sale_findkey) {
		
		showtablerow('', array( '', '', '', '', ''), array(
			$it618_sale_findkey['it618_key'],
			$it618_sale_findkey['it618_count'],
			'<a href="home.php?mod=space&uid='.$it618_sale_findkey['it618_uid'].'" target="_blank">'.it618_sale_getusername($it618_sale_findkey['it618_uid']).'</a>',
			date('Y-m-d H:i:s', $it618_sale_findkey['it618_time']),
		));
	}


	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	
	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>