<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$state0='';$state1='';$state2='';
if($_GET['state']==0){$it618sql = "1";$state0='selected="selected"';}
if($_GET['state']==1){$it618sql = "it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql = "it618_state = 1";$state2='selected="selected"';}

if($_GET['category']>0)$it618sql .= " and it618_category = ".intval($_GET['category']);

$urlsql='&key='.$_GET['key'].'&category='.$_GET['category'].'&class1_id='.$_GET['class1_id'].'&class2_id='.$_GET['class2_id'].'&state='.$_GET['state'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($delid);
		
		$tmpurl=$_G['siteurl'].it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
		$qrcodeurl=md5($tmpurl);
		$qrcodeurl='source/plugin/it618_sale/qrcode/'.$qrcodeurl.'.png';
		$tmparr=explode("source",$qrcodeurl);
		$qrcodeurl=DISCUZ_ROOT.'./source'.$tmparr[1];
		
		if(file_exists($qrcodeurl)){
			$result=unlink($qrcodeurl);
		}
		
		$tmparr=explode("source",$it618_sale_goods['it618_pic']);
		$it618_pic=DISCUZ_ROOT.'./source'.$tmparr[1];
		if(file_exists($it618_pic)){
			$result=unlink($it618_pic);
		}
		
		C::t('#it618_sale#it618_sale_sale')->update_pid_bypid($delid);
		C::t('#it618_sale#it618_sale_goods')->delete_by_id($delid);
		C::t('#it618_sale#it618_sale_collect')->delete_by_pid($delid);
		
		$del=$del+1;
	}
	
	cpmsg($it618_sale_lang['s73'].$del, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

$sql = <<<EOF
	
DROP TABLE IF EXISTS `pre_it618_sale_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_category` int(10) unsigned NOT NULL,
  `it618_productid` varchar(50) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_acsalebl` float(9,2) NOT NULL,
  `it618_actime1` varchar(50) NOT NULL,
  `it618_actime2` varchar(50) NOT NULL,
  `it618_pcurl` varchar(1000) NOT NULL,
  `it618_wapurl` varchar(1000) NOT NULL,
  `it618_codeurl` varchar(1000) NOT NULL,
  `it618_codetime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_quanstr` varchar(1000) NOT NULL,
  `it618_quanurl` varchar(1000) NOT NULL,
  `it618_quancodeurl` varchar(1000) NOT NULL,
  `it618_quancodetime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_quantime1` varchar(50) NOT NULL,
  `it618_quantime2` varchar(50) NOT NULL,
  `it618_message1` mediumtext NOT NULL,
  `it618_message2` mediumtext NOT NULL,
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_description` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_pic` varchar(255) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_collect` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isurl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_collect`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

if(submitcheck('it618submit_clear')){
	runquery($sql);
	
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_sale/qrcode/';
	it618_sale_delfile($datapath);

	C::t('#it618_sale#it618_sale_sale')->update_pid();
	
	cpmsg($it618_sale_lang['s571'], "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_order'])) {
		foreach($_GET['it618_order'] as $id => $val) {
			C::t('#it618_sale#it618_sale_goods')->update($id,array(
				'it618_name' => $_GET['it618_name'][$id],
				'it618_class1_id' => $_GET['it618_class1_id'][$id],
				'it618_class2_id' => $_GET['it618_class2_id'][$id],
				'it618_pcurl' => $_GET['it618_pcurl'][$id],
				'it618_wapurl' => $_GET['it618_pcurl'][$id],
				'it618_codeurl' => $_GET['it618_codeurl'][$id],
				'it618_isurl' => $_GET['it618_isurl'][$id],
				'it618_description' => $_GET['it618_description'][$id],
				'it618_price' => $_GET['it618_price'][$id],
				'it618_saleprice' => $_GET['it618_saleprice'][$id],
				'it618_acsalebl' => $_GET['it618_acsalebl'][$id],
				'it618_xgtime' => $_GET['it618_xgtime'][$id],
				'it618_xgcount' => $_GET['it618_xgcount'][$id],
				'it618_views' => $_GET['it618_views'][$id],
				'it618_order' => $_GET['it618_order'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_sale_lang['s90'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_on')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($delid);
		if($it618_sale_goods['it618_state']==0){
			DB::query("update ".DB::table('it618_sale_goods')." set it618_state=1 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_sale_lang['s74'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_down')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($delid);
		if($it618_sale_goods['it618_state']==1){
			DB::query("update ".DB::table('it618_sale_goods')." set it618_state=0 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_sale_lang['s75'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return;


$classtmp='<option value="0">'.$it618_sale_lang['s95'].'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class1')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$classtmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$classtmp1=str_replace('<option value='.$_GET['class1_id'].'>','<option value='.$_GET['class1_id'].' selected="selected">',$classtmp);

if($_GET['class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_class2')." where it618_class1_id=".$_GET['class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('class1_id').options.selectedIndex,'class2_id');redirec_class_sel('class2_id',".$index.");";
	
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($it618_sale_lang['s10'],'it618_sale_goods');
	showsubmit('it618sercsubmit', $it618_sale_lang['s25'], $it618_sale_lang['s97'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:150px" /> '.$it618_sale_lang['s599'].' <input name="category" value="'.$_GET['category'].'" class="txt" style="width:100px;" /> '.$it618_sale_lang['s99'].' <select id="class1_id" name="class1_id" onchange="redirec_class(this.options.selectedIndex,\'class2_id\')">'.$classtmp1.'</select><select id="class2_id"  name="class2_id"><option value="0">'.$it618_sale_lang['s100'].'</option></select> '.$it618_sale_lang['s101'].' <select name="state"><option value=0 '.$state0.'>'.$it618_sale_lang['s102'].'</option><option value=1 '.$state1.'>'.$it618_sale_lang['s78'].'</option><option value=2 '.$state2.'>'.$it618_sale_lang['s79'].'</option></select>');
	
	$count = C::t('#it618_sale#it618_sale_goods')->count_by_search($it618sql,'',$_GET['class1_id'],$_GET['class2_id'],$_GET['key'],$_GET['price1'],$_GET['price2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=14>'.$it618_sale_lang['s114'].$count.'<span style="float:right;color:red">'.$it618_sale_lang['s335'].'</span></td></tr>';
	showsubtitle(array('',$it618_sale_lang['s80'],$it618_sale_lang['s81'],$it618_sale_lang['s82'],$it618_sale_lang['s83'],$it618_sale_lang['s85'],$it618_sale_lang['s86']));
	
	$n=1;
	foreach(C::t('#it618_sale#it618_sale_goods')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['class1_id'],$_GET['class2_id'],$_GET['key'],$_GET['price1'],$_GET['price2'],$startlimit,$ppp
	) as $it618_sale_goods) {
		
		if($it618_sale_goods['it618_state']==0)$it618_state='<font color=blue>'.$it618_sale_lang['s78'].'</font>';
		if($it618_sale_goods['it618_state']==1)$it618_state='<font color=green>'.$it618_sale_lang['s79'].'</font>';
		
		if($it618_sale_goods['it618_isurl']==1)$it618_isurl_checked='checked="checked"';else $it618_isurl_checked="";
		
		if($it618_sale['sale_isjf']==1){
			$isjfok=1;
			
			if($it618_sale['sale_priceforjf']!=''){
				$tmparr=explode(",",$it618_sale['sale_priceforjf']);
				if(($it618_sale_goods['it618_saleprice']<$tmparr[0]||$it618_sale_goods['it618_saleprice']>$tmparr[1])){
					$isjfok=0;
				}
			}
		}else{
			$isjfok=0;
		}
		
		$jfstr='';
		
		if($isjfok==1){
			$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$it618_sale_goods['it618_quanstr']);
			$jfcount=round($it618_saleprice*$it618_sale['sale_jfbl']/100);
			$jfstr.= $it618_sale_lang['s552'].':'.$jfcount.''.$creditname.' ';
		}
		
		if($it618_sale['sale_isfl']>0){
			if($it618_sale_goods['it618_acsalebl']>0){
				if($it618_sale['sale_isfl']==1){
					$it618_fl=intval($it618_saleprice*$it618_sale_goods['it618_acsalebl']*$it618_sale['sale_moneybl']/10000);
					$jfstr.= $it618_sale_lang['s553'].':'.$it618_fl.''.$creditname;
				}else{
					$it618_fl=round($it618_saleprice*$it618_sale_goods['it618_acsalebl']*$it618_sale['sale_moneybl']/10000,2);
					$jfstr.= $it618_sale_lang['s553'].':'.$it618_fl.''.$it618_sale_lang['s125'];
				}
			}
		}
		
		if($isjfok>0){
			$xgstr='<br>'.$it618_sale_lang['s332'].'<input type="text" class="txt" style="width:35px;margin-right:3px;margin-top:3px;color:blue" name="it618_xgtime['.$it618_sale_goods['id'].']" value="'.$it618_sale_goods['it618_xgtime'].'">'.$it618_sale_lang['s333'].'<input type="text" class="txt" style="width:35px;margin-right:3px;margin-top:3px;color:blue" name="it618_xgcount['.$it618_sale_goods['id'].']" value="'.$it618_sale_goods['it618_xgcount'].'">'.$it618_sale_lang['s334'];
		}else{
			$xgstr='<br>';
		}
		$tmpblstr=$it618_sale_lang['s84'].'<input type="text" class="txt" style="width:48px;margin-right:3px;color:red" name="it618_acsalebl['.$it618_sale_goods['id'].']" value="'.$it618_sale_goods['it618_acsalebl'].'">%';
		
		$classtmp1=str_replace('<option value='.$it618_sale_goods['it618_class1_id'].'>','<option value='.$it618_sale_goods['it618_class1_id'].' selected="selected">',$classtmp);
		
		$category='';
		if($it618_sale_goods['it618_category']>0){
			$category=$it618_sale_lang['s598'].'<font color=red>'.$it618_sale_goods['it618_category'].'</font>';
		}
		
		$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_sale_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_sale_goods['id'].'</label>',
			'<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_sale_goods['it618_pic'].'" width="76" height="76" align="absmiddle"/></a><div style="float:left;margin-left:3px;line-height:18px">
			<textarea type="text" style="width:230px;height:30px;margin-bottom:3px" name="it618_name['.$it618_sale_goods['id'].']">'.$it618_sale_goods['it618_name'].'</textarea><br><input type="text" class="txt" style="width:80px;margin-right:3px;color:red" name="it618_saleprice['.$it618_sale_goods['id'].']" value="'.$it618_sale_goods['it618_saleprice'].'">'.$it618_sale_lang['s125'].'/<input type="text" class="txt" style="width:80px;margin-right:3px;" name="it618_price['.$it618_sale_goods['id'].']" value="'.$it618_sale_goods['it618_price'].'">'.$it618_sale_lang['s125'].' <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product_edit&pmod=admin_product&operation='.$operation.'&do='.$do.'&cp1=3&pid='.$it618_sale_goods['id'].'">'.$it618_sale_lang['s87'].'</a><br>'.$jfstr.'</div>',
			'<select id="it618_class1_id'.$it618_sale_goods['id'].'" name="it618_class1_id['.$it618_sale_goods['id'].']" onchange="redirec_class(this.options.selectedIndex,\'it618_class2_id'.$it618_sale_goods['id'].'\')">'.$classtmp1.'</select><select id="it618_class2_id'.$it618_sale_goods['id'].'"  name="it618_class2_id['.$it618_sale_goods['id'].']"><option value="0">'.$it618_sale_lang['s100'].'</option></select>
			'.$xgstr.'<br><input class="checkbox" type="checkbox" id="chk_isurl'.$n.'" name="it618_isurl['.$it618_sale_goods['id'].']" '.$it618_isurl_checked.' value="1" style="margin-left:0"><label for="chk_isurl'.$n.'" style="color:green">'.$it618_sale_lang['s24'].'</label> '.$it618_sale_lang['s170'].':'.$it618_sale_goods['it618_collect'].'<br>'.$category,
			'<textarea type="text" style="width:268px;height:55px;margin-bottom:3px" name="it618_description['.$it618_sale_goods['id'].']">'.$it618_sale_goods['it618_description'].'</textarea><br><input type="text" class="txt" style="width:145px;margin-right:3px" name="it618_pcurl['.$it618_sale_goods['id'].']" value="'.$it618_sale_goods['it618_pcurl'].'" onclick="this.select()"><input type="text" class="txt" style="width:114px" name="it618_codeurl['.$it618_sale_goods['id'].']" value="'.$it618_sale_goods['it618_codeurl'].'" onclick="this.select()">',
			$tmpblstr.'<br><br>'.str_replace(" 00:00:00","",$it618_sale_goods['it618_actime1']).' '.str_replace(" 23:59:59","",$it618_sale_goods['it618_actime2']).'<br><a href="'.$it618_sale_goods['it618_quanurl'].'" target="_blank">'.$it618_sale_goods['it618_quanstr'].'</a><br>'.str_replace(" 00:00:00","",$it618_sale_goods['it618_quantime1']).' '.str_replace(" 23:59:59","",$it618_sale_goods['it618_quantime2']),
			$it618_state,
			'<input type="text" class="txt" style="width:20px" name="it618_order['.$it618_sale_goods['id'].']" value="'.$it618_sale_goods['it618_order'].'">'
		));
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_sale_class2')." where it618_class1_id=".$it618_sale_goods['it618_class1_id']." ORDER BY it618_order");
		$indextmp=1;
		$index=0;
		while($it618_tmp =	DB::fetch($query)) {
			if($it618_tmp['id']==$it618_sale_goods['it618_class2_id']){
				$index=$indextmp;
			}
			$indextmp+=1;
		}
		
		$jstmp.="redirec_class(document.getElementById('it618_class1_id".$it618_sale_goods['id']."').options.selectedIndex,'it618_class2_id".$it618_sale_goods['id']."');redirec_class_sel('it618_class2_id".$it618_sale_goods['id']."',".$index.");";
		
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_sale_class2'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class1')." ORDER BY it618_order");
	$n1=1;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$n2=1;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_sale_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
	
	echo '
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x,obj)
	{
	 var temp = document.getElementById(obj); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	</script>';
	
	echo '
	<script>
	
	'.$jstmp.'
	
	function check_all(obj,id)
	{
		for(var i=1;i<'.$n.';i++)
		{
			document.getElementById(id+""+i).checked = obj.checked;
		}
	}
	</script>';

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="check_all(this, \'chk_del\')" /><label for="chkallDx4b">'.$it618_sale_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_sale_lang['s88'].'" onclick="return confirm(\''.$it618_sale_lang['s89'].'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_sale_lang['s91'].'"/> <input type="submit" class="btn" name="it618submit_on" value="'.$it618_sale_lang['s92'].'" onclick="return confirm(\''.$it618_sale_lang['s93'].'\')" /> <input type="submit" class="btn" name="it618submit_down" value="'.$it618_sale_lang['s94'].'" onclick="return confirm(\''.$it618_sale_lang['s70'].'\')" /> <input type="submit" class="btn" style="color:red" name="it618submit_clear" value="'.$it618_sale_lang['s569'].'" onclick="return confirm(\''.$it618_sale_lang['s570'].'\')" /> <input type="checkbox" name="chkall" id="chk_isurl" class="checkbox" onclick="check_all(this, \'chk_isurl\')" /><label for="chk_isurl" style="color:green">'.$it618_sale_lang['s262'].'</label><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>