<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$hot1=getids($_GET['hot1'],'SELECT * FROM '.DB::table('it618_sale_class2').' WHERE id=');
	$hot2=getids($_GET['hot2'],'SELECT * FROM '.DB::table('it618_sale_class2').' WHERE id=');
	$hot3=getids($_GET['hot3'],'SELECT * FROM '.DB::table('it618_sale_goods').' WHERE id=');
	
	if(C::t('#it618_sale#it618_sale_set')->count_by_setname($setname)==0){
		C::t('#it618_sale#it618_sale_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $hot1.'@@@'.$hot2.'@@@'.$hot3
		), true);
	}else{
		$it618_sale_set=C::t('#it618_sale#it618_sale_set')->fetch_by_setname($setname);
		C::t('#it618_sale#it618_sale_set')->update($it618_sale_set['id'],array(
			'setvalue' => $hot1.'@@@'.$hot2.'@@@'.$hot3
		));
	}
	

	cpmsg($it618_sale_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_hot&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

function getids($ids,$sql){
	$tmpids=',';
	$tmpidsarr=explode(',',$ids);
	for($i=0;$i<count($tmpidsarr);$i++){
		$id=intval($tmpidsarr[$i]);
		if($id>0){
			if(DB::result_first($sql.$id)>0){
				$tmpids.=','.$id;
			}
		}
	}
	if($tmpids==','){
		$tmpids='';
	}else{
		$tmpids=str_replace(',,','',$tmpids);
	}
	
	return $tmpids;
}

$it618_sale_set=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname($setname);
$value=explode('@@@',$it618_sale_set);

$tmpidsarr=explode(',',$value[0]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);

	if($i==count($tmpidsarr)-1)$tmpstr='';else $tmpstr=' , ';
	$valuename[0].=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_sale_class2')." WHERE id=".$id).$tmpstr;
}

$tmpidsarr=explode(',',$value[1]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);

	if($i==count($tmpidsarr)-1)$tmpstr='';else $tmpstr=' , ';
	$valuename[1].=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_sale_class2')." WHERE id=".$id).$tmpstr;
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_hot&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1].'<span style="font-weight:normal;color:red;margin-left:90px">'.$it618_sale_lang['s69'].'</span>','it618_sale_set');

echo '
<tr><td>'.$it618_sale_lang['s17'].'</td><td><input type="text" name="hot1" style="width:800px;" value="'.$value[0].'"></td></tr>
<tr><td></td><td style="color:green">'.$valuename[0].'</td></tr>
<tr><td>'.$it618_sale_lang['s71'].'</td><td><input type="text" name="hot2" style="width:800px;" value="'.$value[1].'"></td></tr>
<tr><td></td><td style="color:green">'.$valuename[1].'</td></tr>
';

showsubmit('it618submit', $it618_sale_lang['s23']);
if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com

?>