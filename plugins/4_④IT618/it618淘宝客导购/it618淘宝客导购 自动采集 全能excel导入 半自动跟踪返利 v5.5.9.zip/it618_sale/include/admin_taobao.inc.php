<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		$adzoneid=trim($_GET['adzoneid']);
		$tmparr=explode("_",$adzoneid);
		if(count($tmparr)>1){
			$adzoneid=$tmparr[count($tmparr)-1];
		}
		
		$isquan0add=$_GET['isquan0add'];
		$quan0saleetime=floatval($_GET['quan0saleetime']);
		if($quan0saleetime<=0){
			$isquan0add=0;
		}
		
		$fileData = '$appkey=\''.trim($_GET['appkey'])."';\n";
		
		$fileData .= '$secretkey=\''.trim($_GET['secretkey'])."';\n";
		
		$fileData .= '$adzoneid=\''.$adzoneid."';\n";
		
		$fileData .= '$isotheradd=\''.trim($_GET['isotheradd'])."';\n";
		
		$fileData .= '$findvolume=\''.trim($_GET['findvolume'])."';\n";
		
		$fileData .= '$findcommission_rate=\''.trim($_GET['findcommission_rate'])."';\n";
		
		$fileData .= '$quangoodstime=\''.floatval($_GET['quangoodstime'])."';\n";
		
		$fileData .= '$isquan0add=\''.$isquan0add."';\n";
		
		$fileData .= '$quan0saleetime=\''.$quan0saleetime."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
	$checkstr=it618_sale_addquancheck();

	cpmsg($it618_sale_lang['s16'].'<br><br>'.$it618_sale_lang['s608'].$checkstr, "action=plugins&identifier=$identifier&cp=admin_taobao&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_taobao&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_sale_aliyunoss');

if($isotheradd==1)$isotheradd_checked='checked="checked"';else $isotheradd_checked="";
if($isquan0add==1)$isquan0add_checked='checked="checked"';else $isquan0add_checked="";

echo '<style>table tr td{line-height:20px}</style>
<tr><td width=180>'.$it618_sale_lang['s12'].'</td><td><input type="text" name="appkey" style="width:400px" value="'.$appkey.'"></td></tr>
<tr><td>'.$it618_sale_lang['s13'].'</td><td><input type="text" name="secretkey" style="width:400px" value="'.$secretkey.'"></td></tr>
<tr><td>'.$it618_sale_lang['s22'].'</td><td><input type="text" name="adzoneid" style="width:400px" value="'.$adzoneid.'"> '.$it618_sale_lang['s30'].'</td></tr>
<tr><td colspan=2><b>'.$it618_sale_lang['s76'].'</b></td></tr>


<tr style="display:none"><td>'.$it618_sale_lang['s425'].'</td><td><input type="checkbox" class="checkbox" id="chkisotheradd" name="isotheradd" value="1" '.$isotheradd_checked.'><label for="chkisotheradd"><font color=blue>'.$it618_sale_lang['s426'].'</font></label></td></tr>

<tr><td>'.$it618_sale_lang['s601'].'
</td><td>
'.$it618_sale_lang['s602'].' <input type="text" name="quangoodstime" style="width:100px" value="'.$quangoodstime.'"><br><font color=#999>'.$it618_sale_lang['s605'].'</font>
</td></tr>

<tr><td>'.$it618_sale_lang['s699'].'</td><td>'.$it618_sale_lang['s436'].'<input type="text" name="findvolume" style="width:80px" value="'.$findvolume.'"> '.$it618_sale_lang['s437'].'<input type="text" name="findcommission_rate" style="width:80px" value="'.$findcommission_rate.'"></td></tr>

<tr><td>'.$it618_sale_lang['s719'].'</td><td><input type="checkbox" class="checkbox" id="chkisquan0add" name="isquan0add" value="1" '.$isquan0add_checked.'><label for="chkisquan0add">'.$it618_sale_lang['s720'].'</label>  '.$it618_sale_lang['s722'].'<input type="text" name="quan0saleetime" style="width:80px" value="'.$quan0saleetime.'"><br>'.$it618_sale_lang['s721'].'</td></tr>

<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_sale_lang['s626'].'" /></div></td></tr>
';

if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com

?>