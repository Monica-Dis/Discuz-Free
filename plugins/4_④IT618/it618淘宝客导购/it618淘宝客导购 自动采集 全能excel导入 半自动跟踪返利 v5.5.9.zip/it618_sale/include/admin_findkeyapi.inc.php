<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_sale_findkeyapi', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_key'])) {
		foreach($_GET['it618_key'] as $id => $val) {

			C::t('#it618_sale#it618_sale_findkeyapi')->update($id,array(
				'it618_key' => trim($_GET['it618_key'][$id]),
				'it618_timecount' => trim($_GET['it618_timecount'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_key_array = !empty($_GET['newit618_key']) ? $_GET['newit618_key'] : array();
	$newit618_timecount_array = !empty($_GET['newit618_timecount']) ? $_GET['newit618_timecount'] : array();
	
	foreach($newit618_key_array as $key => $value) {
		$newit618_key = addslashes(trim($newit618_key_array[$key]));
		
		if($newit618_key != '') {
			
			C::t('#it618_sale#it618_sale_findkeyapi')->insert(array(
				'it618_key' => trim($newit618_key_array[$key]),
				'it618_timecount' => trim($newit618_timecount_array[$key]),
				'it618_order' => 1,
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_sale_lang['s33'].$ok1.' '.$it618_sale_lang['s34'].$ok2.' '.$it618_sale_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_findkeyapi&pmod=admin_findkey&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=10)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_findkeyapi&pmod=admin_findkey&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_sale_lang['s711'],'it618_sale_findkeyapi');

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_findkeyapi'));
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_findkeyapi&pmod=admin_findkey&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10 style="color:blue">'.$it618_sale_lang['s718'].'</td></tr>';
	echo '<tr><td colspan=10>'.$it618_sale_lang['s716'].$count.'<span style="float:right;color:red">'.$it618_sale_lang['s456'].'</span></td></tr>';
	showsubtitle(array('',$it618_sale_lang['s712'], $it618_sale_lang['s449'],$it618_sale_lang['s450'],$it618_sale_lang['s451']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_findkeyapi')." ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_sale_findkeyapi = DB::fetch($query)) {
		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_sale_findkeyapi[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:150px\" name=\"it618_key[$it618_sale_findkeyapi[id]]\" value=\"$it618_sale_findkeyapi[it618_key]\">",
			'<input class="txt" type="text" style="width:50px;margin-right:3px" name="it618_timecount['.$it618_sale_findkeyapi['id'].']" value="'.$it618_sale_findkeyapi['it618_timecount'].'">'.$it618_sale_lang['s466'],
			'<div style="width:630px"><font color=#999>'.date('Y-m-d H:i:s', $it618_sale_findkeyapi['it618_time']).'</font><br>'.$it618_sale_findkeyapi['it618_bz'].'</div>',
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_sale_findkeyapi['id'].']" value="'.$it618_sale_findkeyapi['it618_order'].'">'
		));
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$s466=$it618_sale_lang['s466'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_key[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:150px\" name="newit618_key[]">'], [1,'<input type="text" class="txt" style=\"width:50px;margin-right:3px\" name="newit618_timecount[]">$s466'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', '', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>