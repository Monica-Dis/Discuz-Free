<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_sale_class1', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_sale#it618_sale_class1')->update($id,array(
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_goodscount' => trim($_GET['it618_goodscount'][$id]),
				'it618_wapgoodscount' => trim($_GET['it618_wapgoodscount'][$id]),
				'it618_homeorder' => trim($_GET['it618_homeorder'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_classname_array as $key => $value) {
		$newit618_classname = addslashes(trim($newit618_classname_array[$key]));
		
		if($newit618_classname != '') {
			
			C::t('#it618_sale#it618_sale_class1')->insert(array(
				'it618_classname' => trim($newit618_classname_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_sale_lang['s33'].$ok1.' '.$it618_sale_lang['s34'].$ok2.' '.$it618_sale_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=10)return;
if(submitcheck('it618sercsubmit')) {
	if($_GET['beforeword']) {
		$extrasql = "AND it618_classname LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
	}
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do");
showtableheaders($it618_sale_lang['s41'],'it618_sale_class1');
	showsubmit('it618sercsubmit', $it618_sale_lang['s25'], $it618_sale_lang['s42'].' <input name="beforeword" value="'.$_GET['beforeword'].'" class="txt" />');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_class1')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10>'.$it618_sale_lang['s43'].$count.'<span style="float:right;color:red">'.$it618_sale_lang['s52'].'</span></td></tr>';
	showsubtitle(array($it618_sale_lang['s56'], $it618_sale_lang['s45'],$it618_sale_lang['s49'],$it618_sale_lang['s50'],$it618_sale_lang['s53'],$it618_sale_lang['s54']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_sale_class1')." WHERE 1 $extrasql ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_sale =	DB::fetch($query)) {
		$class2count = C::t('#it618_sale#it618_sale_class2')->count_by_it618_class1_id($it618_sale['id']);
		$goodscount=C::t('#it618_sale#it618_sale_goods')->count_by_search('','',$it618_sale['id']);
		$disabled="";
		if($class2count>0)$disabled="disabled=\"disabled\"";
		
		$idstr='';
		if($it618_sale[id]==1){
			$disabled="disabled=\"disabled\"";
			$idstr=$it618_sale_lang['s592'];
		}
		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_sale[id]\" $disabled> $it618_sale[id]",
			"<input type=\"text\" class=\"txt\" style=\"width:150px\" name=\"it618_classname[$it618_sale[id]]\" value=\"$it618_sale[it618_classname]\"> $idstr",
			'<input class="txt" type="text" style="width:60px;margin-right:0" name="it618_goodscount['.$it618_sale['id'].']" value="'.$it618_sale['it618_goodscount'].'">/<input class="txt" type="text" style="width:60px;margin-right:0" name="it618_wapgoodscount['.$it618_sale['id'].']" value="'.$it618_sale['it618_wapgoodscount'].'">/<input class="txt" type="text" style="width:60px" name="it618_homeorder['.$it618_sale['id'].']" value="'.$it618_sale['it618_homeorder'].'">',
			'<input class="txt" type="text" style="width:50px" name="it618_order['.$it618_sale['id'].']" value="'.$it618_sale['it618_order'].'">',
			$class2count,
			$goodscount
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_sale['id']."');";
		$editorjs.='K(\'#image'.$it618_sale['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_sale['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_sale['id'].'\').val(url);
								K(\'#img'.$it618_sale['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
		echo '
<link rel="stylesheet" href="source/plugin/it618_sale/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_sale/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_sale/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_sale/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_classname[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:150px\" name="newit618_classname[]">'], [1, ' <input class="txt" style=\"width:50px\" type="text" name="newit618_order[]">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', '', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
?>