<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

if($_GET['state']) {
	$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';
	if($_GET['state']==0){$it618sql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$it618sql .= "s.it618_state = 1";$state1='selected="selected"';}
	if($_GET['state']==2){$it618sql .= "s.it618_state = 2";$state2='selected="selected"';}
	if($_GET['state']==3){$it618sql .= "s.it618_state = 3";$state3='selected="selected"';}
	if($_GET['state']==4){$it618sql .= "s.it618_state = 4";$state4='selected="selected"';}
	if($_GET['state']==5){$it618sql .= "s.it618_state = 5";$state5='selected="selected"';}
	if($_GET['state']==6){$it618sql .= "s.it618_state = 6";$state6='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&state='.$_GET['state'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_sale_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_sale_sale')." where id=".$delid);
		$buyuid=$it618_sale_sale['it618_uid'];
		if($it618_sale_sale['it618_state']==1){
			
			DB::delete('it618_sale_sale', "id=$delid");
			
			C::t('common_member_count')->increase($buyuid, array(
				'extcredits'.$it618_sale['sale_credit'] => ($it618_sale_sale['it618_count']*$it618_sale_sale['it618_score']))
			);
			DB::query("update ".DB::table('it618_sale_goods')." set it618_salecount=it618_salecount-".$it618_sale_sale['it618_count']." where id=".$it618_sale_sale['it618_pid']);
						
			$del=$del+1;
		}
	}

	cpmsg($it618_sale_lang['s373'].$del.$it618_sale_lang['s374'], "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_yifahuo')){
	$ok=0;
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_sale_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_sale_sale')." where id=".$delid);
		
		if($it618_sale_sale['it618_state']==1){
			DB::query("update ".DB::table('it618_sale_sale')." set it618_state=2 WHERE id=".$delid);
			it618_sale_sendmessage('salestate_user',$it618_sale_sale['id'],'fahuo');
			$ok=$ok+1;
		}
	}

	cpmsg($it618_sale_lang['s372'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_kd')){
	$ok=0;
	if($reabc[8]!='l')return;
	foreach($_GET['it618_kddan'] as $delid => $value) {
		$delid=intval($delid);
		$it618_sale_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_sale_sale')." where id=".$delid);
		
		if($it618_sale_sale['it618_state']==2){
			if($_GET['it618_kdid'][$delid]>0&&$_GET['it618_kddan'][$delid]!=''){
				C::t('#it618_sale#it618_sale_sale')->update($delid,array(
					'it618_kdid' => $_GET['it618_kdid'][$delid],
					'it618_kddan' => $_GET['it618_kddan'][$delid]
				));
				$ok=$ok+1;
			}
		}
	}

	cpmsg($it618_sale_lang['s371'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_tongyi')){
	$ok=0;
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_sale_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_sale_sale')." where id=".$delid);
		$buyuid=$it618_sale_sale['it618_uid'];
		if($it618_sale_sale['it618_state']==4){
			DB::query("update ".DB::table('it618_sale_sale')." set it618_state=5 WHERE id=".$delid);
			
			C::t('common_member_count')->increase($buyuid, array(
				'extcredits'.$it618_sale['sale_credit'] => ($it618_sale_sale['it618_count']*$it618_sale_sale['it618_score']))
			);

			DB::query("update ".DB::table('it618_sale_goods')." set it618_salecount=it618_salecount-".$it618_sale_sale['it618_count']." where id=".$it618_sale_sale['it618_pid']);
			
			it618_sale_sendmessage('salestate_user',$it618_sale_sale['id'],'tongyitui');
			$ok=$ok+1;
		}
	}

	cpmsg($it618_sale_lang['s370'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_jujue')){
	$ok=0;
	if($reabc[8]!='l')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_sale_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_sale_sale')." where id=".$delid);
		
		if($it618_sale_sale['it618_state']==4){
			DB::query("update ".DB::table('it618_sale_sale')." set it618_state=6 WHERE id=".$delid);
			it618_sale_sendmessage('salestate_user',$it618_sale_sale['id'],'jujuetui');
			$ok=$ok+1;
		}
	}

	cpmsg($it618_sale_lang['s369'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_data')){
	$strtmp=$it618_sale_lang['s368']."\n";
	$query = DB::query("SELECT s.* FROM ".DB::table('it618_sale_sale')." s,".DB::table('it618_sale_goods')." g WHERE s.it618_pid=g.id $extrasql order by it618_pid,it618_time desc");
	while($it618_sale_sale = DB::fetch($query)) {
		$it618_sale_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_sale_goods')." where id=".$it618_sale_sale['it618_pid']);
		
		$strtmp.=$it618_sale_goods['it618_name'].",".$it618_sale_sale['it618_score'].",".$it618_sale_sale['it618_count'].",".$it618_sale_sale['it618_name'].",".$it618_sale_sale['it618_tel'].",".$it618_sale_sale['it618_addr'].",".$it618_sale_sale['it618_bz'].",".date('Y-m-d H:i:s', $it618_sale_sale['it618_time'])."\n";
		$datacount=$datacount+1;
	}

	$timestr=date("YmdHis") . '_' . $datacount;
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_sale/temp/admin/';
	it618_sale_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	cpmsg($it618_sale_lang['s366'].'<a href="javascript:" onclick="window.open(\''.$_G['siteurl'].'source/plugin/it618_sale/temp/admin/'.$timestr.'.csv\')"><font color=red>'.$it618_sale_lang['s367'].'</font></a>', "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=10)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do");
showtableheaders($it618_sale_lang['s353'],'it618_sale_sum');
	showsubmit('it618sercsubmit', $it618_sale_lang['s25'], $it618_sale_lang['s352'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" />'.$it618_sale_lang['s502'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_sale_lang['s503'].' <select name="state"><option value=0 '.$state0.'>'.$it618_sale_lang['s341'].'</option><option value=1 '.$state1.'>'.$it618_sale_lang['s347'].'</option><option value=2 '.$state2.'>'.$it618_sale_lang['s348'].'</option><option value=3 '.$state3.'>'.$it618_sale_lang['s496'].'</option><option value=4 '.$state4.'>'.$it618_sale_lang['s349'].'</option><option value=5 '.$state5.'>'.$it618_sale_lang['s350'].'</option><option value=6 '.$state6.'>'.$it618_sale_lang['s351'].'</option></select> '.$it618_sale_lang['s379'].' <input name="it618_time1" class="txt" style="width:80px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time1'].'" /> - <input name="it618_time2" class="txt" style="width:80px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time2'].'"/>');
	
	$it618_sale_sales=C::t('#it618_sale#it618_sale_sale')->fetch_all_by_search($it618sql,'s.id desc',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
	$count=C::t('#it618_sale#it618_sale_sale')->count_by_search($it618sql,'',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$money=C::t('#it618_sale#it618_sale_sale')->sum_money_by_search($it618sql,'',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=18>'.$it618_sale_lang['s377'].'<font color=red>'.$count.'</font> '.$creditname.$it618_sale_lang['s378'].'<font color=red>'.$money.'</font><span style="float:right;">'.$it618_sale_lang['s380'].'<font color=red>'.$it618_sale['sale_shouhuocount'].'</font>'.$it618_sale_lang['s381'].'</span></td></tr>';
	showsubtitle(array('', $it618_sale_lang['s336'],$it618_sale_lang['s339'],$it618_sale_lang['s340'],$it618_sale_lang['s342'],$it618_sale_lang['s343'],$it618_sale_lang['s346']));
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_kd')." ORDER BY it618_order DESC");
	$tmp.='<option value="0">'.$it618_sale_lang['s359'].'</option>';
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}

	foreach($it618_sale_sales as $it618_sale_sale) {
		if($it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($it618_sale_sale['it618_pid'])){
			$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
			$pname=$it618_sale_goods['it618_name'];
			$ppic=$it618_sale_goods['it618_pic'];
		}else{
			$tmpurl="javascript:";
			$pname=$it618_sale_sale['it618_pname'];
			$ppic="source/plugin/it618_sale/images/nogoods.png";
		}
		
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_sale_sale['it618_uid']);
		
		if($it618_sale_sale['it618_state']==2){
			$tmp1=str_replace('<option value='.$it618_sale_sale['it618_kdid'].'>','<option value='.$it618_sale_sale['it618_kdid'].' selected="selected">',$tmp);
			$strkd='<font color=green>'.$it618_sale_lang['s413'].'<select name="it618_kdid['.$it618_sale_sale['id'].']">'.$tmp1.'</select><br>'.$it618_sale_lang['s414'].'<input type="text" class="txt" style="width:112px" name="it618_kddan['.$it618_sale_sale['id'].']" value="'.$it618_sale_sale['it618_kddan'].'"></font>';
		}else{
			if($it618_sale_sale['it618_kdid']!=0&&$it618_sale_sale['it618_kddan']!=''){
				$it618_sale_kd=DB::fetch_first("select * from ".DB::table('it618_sale_kd')." WHERE id=".$it618_sale_sale['it618_kdid']);
				$strkd=''.$it618_sale_lang['s413'].'<a href="'.$it618_sale_kd['it618_url'].'" target="_blank">'.$it618_sale_kd['it618_name'].'</a><br>'.$it618_sale_lang['s414'].'<font color=green>'.$it618_sale_sale['it618_kddan'].'</font>';
			}else{
				$strkd='';	
			}
		}
		
		if($it618_sale_sale['it618_state']==1)$it618_state='<font color=red>'.$it618_sale_lang['s347'].'</font>';
		if($it618_sale_sale['it618_state']==2)$it618_state='<font color=green>'.$it618_sale_lang['s348'].'</font>';
		if($it618_sale_sale['it618_state']==3)$it618_state='<font color=green>'.$it618_sale_lang['s496'].'</font>';
		if($it618_sale_sale['it618_state']==4)$it618_state='<font color=red>'.$it618_sale_lang['s349'].'</font>';
		if($it618_sale_sale['it618_state']==5)$it618_state='<font color=#999>'.$it618_sale_lang['s350'].'</font>';
		if($it618_sale_sale['it618_state']==6)$it618_state='<font color=blue>'.$it618_sale_lang['s351'].'</font>';
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_sale_sale['id'].'" name="delete[]" value="'.$it618_sale_sale['id'].'"><input type="hidden" name="id['.$it618_sale_sale['id'].']" value="'.$it618_sale_sale['id'].'"><label for="chk_del'.$it618_sale_sale['id'].'">'.$it618_sale_sale['id'].'</label>',
			'<a href="'.$tmpurl.'" target="_blank"><img style="float:left;" src="'.$ppic.'" width="60" height="60" align="absmiddle"/><div style="float:left;width:260px;margin-left:3px">'.$pname.'<br><br>'.$it618_sale_lang['s337'].'<font color=red>'.$it618_sale_sale['it618_price'].'</font>'.$it618_sale_lang['s125'].' '.$it618_sale_lang['s338'].'<font color=red>'.$it618_sale_sale['it618_salebl'].'%</font></div></a>',
			$it618_sale_sale['it618_score'],
			$it618_sale_sale['it618_count'],
			'<div style="width:350px">'.$it618_sale_sale['it618_name'].' '.$it618_sale_sale['it618_tel'].'<br>'.$it618_sale_sale['it618_addr'].'<br><font color=#999>'.$it618_sale_sale['it618_bz'].'</font></div>',
			$it618_state.'<br>'.$strkd,
			'<div style="width:75px"><a href="home.php?mod=space&uid='.$it618_sale_sale['it618_uid'].'" target="_blank">'.it618_sale_getusername($it618_sale_sale['it618_uid']).'</a><br>'.date('Y-m-d H:i:s', $it618_sale_sale['it618_time']).'</div>'
		));
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_sale_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_sale_lang['s354'].'" onclick="return confirm(\''.$it618_sale_lang['s355'].'\')" /> <input type="submit" class="btn" name="it618submit_yifahuo" value="'.$it618_sale_lang['s356'].'" onclick="return confirm(\''.$it618_sale_lang['s357'].'\')"/> <input type="submit" class="btn" name="it618submit_kd" value="'.$it618_sale_lang['s358'].'"/> <input type="submit" class="btn" name="it618submit_tongyi" value="'.$it618_sale_lang['s360'].'" onclick="return confirm(\''.$it618_sale_lang['s361'].'\')"/> <input type="submit" class="btn" name="it618submit_jujue" value="'.$it618_sale_lang['s362'].'" onclick="return confirm(\''.$it618_sale_lang['s363'].'\')"/> <input type="submit" class="btn" name="it618submit_data" value="'.$it618_sale_lang['s364'].'"/> <br>'.$it618_sale_lang['s365'].' &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=10)return;
showtablefooter(); //dis'.'m.tao'.'bao.com
echo '<script charset="utf-8" src="source/plugin/it618_sale/js/Calendar.js"></script>';
?>