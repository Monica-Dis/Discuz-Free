<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pid=intval($_GET['cid1']);
if(!sale_is_mobile()){ 
	$tmpurl=it618_sale_getrewrite('sale_product',$pid,'plugin.php?id=it618_sale:product&pid='.$pid);
	dheader("location:$tmpurl");
}

if(!($it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id_state($pid,1))){
	$homeurl=it618_sale_getrewrite('sale_wap','','plugin.php?id=it618_sale:wap');
	dheader("location:$homeurl");
}else{

	if($it618_sale_goods['it618_wapurl']==''){
		$homeurl=it618_sale_getrewrite('sale_wap','','plugin.php?id=it618_sale:wap');
		dheader("location:$homeurl");
	}
	
	if($it618_sale_goods['it618_quanurl']!=''){
		$it618_sale_goods['it618_wapurl']=$it618_sale_goods['it618_quanurl'];
	}
	
	if($it618_sale_goods['it618_quancodeurl']!=''){
		$it618_sale_goods['it618_codeurl']=$it618_sale_goods['it618_quancodeurl'];
	}
	
	if($it618_sale['sale_isurl']==3){
		if($it618_sale['sale_isjf']==1){
			$isjfok=1;
			
			if($it618_sale['sale_priceforjf']!=''){
				$tmparr=explode(",",$it618_sale['sale_priceforjf']);
				if(($it618_sale_goods['it618_saleprice']<$tmparr[0]||$it618_sale_goods['it618_saleprice']>$tmparr[1])){
					$isjfok=0;
				}
			}
		}else{
			$isjfok=0;
		}
	}

	if(it618_getgoodsisurl($it618_sale_goods)==1){
		dheader("location:".$it618_sale_goods['it618_wapurl']);
	}
}

$navtitle=$it618_sale_goods['it618_name'].' - '.$sitetitle;

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	$tmparr=explode("taobao.com",$it618_sale_goods['it618_pcurl']);
	$istb=count($tmparr);
}

if($_G['uid']>0){
	$tmpcount=C::t('#it618_sale#it618_sale_collect')->count_by_uid_pid($_G['uid'],$it618_sale_goods['id']);
	if($tmpcount>0){
		$collectname=$it618_sale_lang['s1796'];
	}else{
		$collectname=$it618_sale_lang['s1795'];
	}
}else{
	$collectname=$it618_sale_lang['s1795'];
}

C::t('#it618_sale#it618_sale_goods')->update_it618_views_by_id($pid);
$collectcount = C::t('#it618_sale#it618_sale_goods')->update_it618_collect_by_id($pid);
$salecount = C::t('#it618_sale#it618_sale_goods')->update_it618_salecount_by_id($pid);

if($it618_sale_goods['it618_message2']=='')$it618_sale_goods['it618_message2']=$it618_sale_goods['it618_message1'];

if($it618_sale_goods['it618_description']!=''){
	$it618_description=$it618_sale_lang['s126'].$it618_sale_goods['it618_description'];
}

if($it618_sale['sale_productmode']==1||$it618_sale['sale_productmode']==''){
	$isapi=1;
}

if($it618_sale['sale_productmode']==2){
	if($it618_sale_goods['it618_message']!=''){
		$it618_message=$it618_sale_goods['it618_message'];
		$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
		$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img class="lazy" data-original="\1"/>',$it618_message);
		$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
		$it618_message=preg_replace('/<div.+?>/','<div>',$it618_message);
		$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);
	}else{
		$it618_message=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('defalutgoodsmessage');
	}
}

if($it618_sale['sale_productmode']==3){
	if($it618_sale_goods['it618_message']!=''){
		$it618_message=$it618_sale_goods['it618_message'];
		$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
		$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img class="lazy" data-original="\1"/>',$it618_message);
		$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
		$it618_message=preg_replace('/<div.+?>/','<div>',$it618_message);
		$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);
	}else{
		$isapi=1;
	}
}

if($it618_sale['sale_productmode']==4){
	$it618_message=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('defalutgoodsmessage');
	$isapi=1;
}

if($isapi==1){
	if($it618_message==''){
		$it618_message.='<div id="it618_message"></div>';
	}else{
		$it618_message.='<div id="it618_message" style="margin-top:15px"></div>';
	}
}

$it618_price=$it618_sale_goods['it618_price'];
$it618_saleprice=$it618_sale_goods['it618_saleprice'];

if($it618_sale_goods['it618_quantime1']!=''){
	$btime=strtotime($it618_sale_goods['it618_quantime1']);
	$etime=strtotime($it618_sale_goods['it618_quantime2']);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=$it618_sale_lang['s277'];
	}else{
		if($btime>$_G['timestamp']){
			$timetip=$it618_sale_lang['s278'];
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_sale_goods['it618_quantime1'];
		}else{
			$timetip=$it618_sale_lang['s279'];
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_sale_goods['it618_quantime2'];
		}
	}
	
	$it618_quanstr=$it618_sale_goods['it618_quanstr'];
	$quanstr=$it618_sale_goods['it618_quanstr'];
	
	$it618_price=$it618_sale_goods['it618_saleprice'];
	$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr);
}

if($it618_sale['sale_isjf']==1){
	$isjfok=1;
	
	if($it618_sale['sale_priceforjf']!=''){
		$tmparr=explode(",",$it618_sale['sale_priceforjf']);
		if(($it618_sale_goods['it618_saleprice']<$tmparr[0]||$it618_sale_goods['it618_saleprice']>$tmparr[1])){
			$isjfok=0;
		}
	}
}else{
	$isjfok=0;
}

if($isjfok==1){
	$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$it618_sale_goods['it618_quanstr']);
	$jfcount=round($it618_saleprice*$it618_sale['sale_jfbl']/100);
}

if($it618_sale['sale_isfl']>0){
	if($it618_sale_goods['it618_acsalebl']>0){
		if($it618_sale['sale_isfl']==1){
			$it618_fl=intval($it618_saleprice*$it618_sale_goods['it618_acsalebl']*$it618_sale['sale_moneybl']/10000);
			$it618_fl= $it618_fl.''.$creditname;
		}else{
			$it618_fl=round($it618_saleprice*$it618_sale_goods['it618_acsalebl']*$it618_sale['sale_moneybl']/10000,2);
			$it618_fl= $it618_fl.''.$it618_sale_lang['s125'];
		}
		$flurl=it618_sale_getrewrite('sale_wap','money','plugin.php?id=it618_sale:wap&pagetype=money');
	}
}

if($it618_price>0)$zk=sprintf("%.2f", $it618_saleprice/$it618_price)*10;

if($_G['uid']>0){
	$count=C::t('#it618_sale#it618_sale_collect')->count_by_uid_pid($_G['uid'],$pid);
	if($count>0){
		$collectname=$it618_sale_lang['s1796'];
	}else{
		$collectname=$it618_sale_lang['s1795'];
	}
}else{
	$collectname=$it618_sale_lang['s1795'];
}

$sale_saleuids=explode(",",$it618_sale['sale_saleuids']);
if(in_array($_G['uid'], $sale_saleuids)){
	$adminbl=$it618_sale_lang['t145'].'<font color=red>'.$it618_sale_goods['it618_acsalebl'].'%</font>';
}

$bottommenu=C::t('#it618_sale#it618_sale_bottomnav')->fetch_by_id(1);

$_G['mobiletpl'][2]='/';
include template('it618_sale:wap_sale');
?>