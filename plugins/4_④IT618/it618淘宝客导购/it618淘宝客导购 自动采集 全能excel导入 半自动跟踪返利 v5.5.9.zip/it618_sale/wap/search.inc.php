<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$classid1=intval($_GET['cid1']);
$classid2=intval($_GET['cid2']);

if(!(isset($_GET['cid1'])||isset($_GET['cid1']))){
	$iskeyfind=1;
}

if(!sale_is_mobile()){ 
	$tmpurl=it618_sale_getrewrite('sale_list','','plugin.php?id=it618_sale:list');
	if($classid1>0){
		$tmpurl=it618_sale_getrewrite('sale_list',$classid1,'plugin.php?id=it618_sale:list&class1='.$classid1);
	}
	
	if($classid1>0&&$classid2>0){
		$tmpurl=it618_sale_getrewrite('sale_list',$classid1.'@'.$classid2,'plugin.php?id=it618_sale:list&class1='.$classid1.'&class2='.$classid2);
	}
	dheader("location:$tmpurl");
}

$navtitle=$it618_sale_lang['t57'].' - '.$sitetitle;


$n=1;
$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productclass1\',0,0)" name="productclass1"><span>'.$it618_sale_lang['t53'].'</span><i></i></a>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class1')." ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	if($it618_tmp['id']==$classid1){
		$classid_n1=$n;
	}
	$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass1\','.$n.','.$it618_tmp['id'].')" name="productclass1"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
	$n=$n+1;
}

if($classid2>0){
	$n=1;
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class2')." WHERE it618_class1_id=$classid1 ORDER BY it618_order");
	while($it618_tmp = DB::fetch($query1)) {
		if($it618_tmp['id']==$classid2){
			$classid_n2=$n;
		}
		$n=$n+1;
	}
}

$n=2;
$pricearr=explode("|",str_replace(array("\r\n", "\r", "\n"), '|', $it618_sale['sale_findprice']));
$pricetmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productprice\',0,\'0-0\')" name="productprice"><span>'.$it618_sale_lang['t53'].$it618_sale_lang['t26'].'</span><i></i></a>';
for($i=0;$i<count($pricearr);$i++){
	$pricearr1=explode(",",$pricearr[$i]);
	if($i==0){
		$pricetmp.='<a href="javascript:void(0)" onclick="setselect(\'productprice\',1,\'0-'.$pricearr1[0].'\')" name="productprice"><span>'.$pricearr1[0].$it618_sale_lang['s171'].'</span><i></i></a>';
	}
	$pricetmp.='<a href="javascript:void(0)" onclick="setselect(\'productprice\','.$n.',\''.$pricearr1[0].'-'.$pricearr1[1].'\')" name="productprice"><span>'.$pricearr1[0].'-'.$pricearr1[1].$it618_sale_lang['s125'].'</span><i></i></a>';
	$n=$n+1;
}
$pricetmp.='<a href="javascript:void(0)" onclick="setselect(\'productprice\','.$n.',\''.$pricearr1[1].'-0\')" name="productprice"><span>'.$pricearr1[1].$it618_sale_lang['s172'].'</span><i></i></a>';

$_G['mobiletpl'][2]='/';
include template('it618_sale:wap_sale');
?>