<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!sale_is_mobile()){ 
	$tmpurl=it618_sale_getrewrite('sale_home','','plugin.php?id=it618_sale:index');
	dheader("location:$tmpurl");
}

foreach(C::t('#it618_sale#it618_sale_focus')->fetch_all_by_type_order(24) as $it618_sale_focus) {
	if($it618_sale_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_sale_focus['it618_url'].'" target="_blank"><img class="img" src="'.it618_sale_getwapppic($it618_sale_focus['id'],$it618_sale_focus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_sale_getwapppic($it618_sale_focus['id'],$it618_sale_focus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_sale_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_sale_gonggao = DB::fetch($query)) {
	$it618_title=$it618_sale_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,56,'...');
	
	if($it618_sale_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_sale_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_sale_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_sale_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

if($it618_sale['waphomeico']=='')$it618_sale['waphomeico']='2|5|12|#888|6';
$waphomeico=explode("|",$it618_sale['waphomeico']);
$tmpn=$waphomeico[0];
$pppn=$waphomeico[1];
$tmpsize=$waphomeico[2];
$tmpcolor=$waphomeico[3];
$tmpw=$waphomeico[4];
$pppw=100/$pppn;
$tmpn=$tmpn*$pppn;

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_sale_wapiconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_sale_wapiconav = DB::fetch($query)) {
	$it618_title=$it618_sale_wapiconav['it618_title'];
	
	if($it618_sale_wapiconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_sale_wapiconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_sale_wapiconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_sale_wapiconav['it618_color'].'">'.$it618_title.'</font>';
	}

	$str_iconav.='<td width="'.$pppw.'%"><a href="'.$it618_sale_wapiconav['it618_url'].'"'.$it618_target.'><img src="'.$it618_sale_wapiconav['it618_img'].'" /><br>'.$it618_title.'</a></td>';
	
	if($n%$pppn==0)$str_iconav.='</tr><tr>';
	if($n%$tmpn==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"><tr>';

	$n=$n+1;
}

if($n>1)$n=$n-1;

if($n%$pppn>0){
	for($i=1;$i<=($pppn-$n%$pppn);$i++){
		$str_iconav.='<td width="'.$pppw.'%"></td>';
	}
}

$str_iconav.='</tr>';
$str_iconav=str_replace('<tr></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:11px;background-color:#fff"><table class="iconav"></table></div>','',$str_iconav);
$str_iconav=str_replace('<tr><td','<tr><td width='.$tmpw.'></td><td',$str_iconav);
$str_iconav=str_replace('</td></tr>','</td><td width='.$tmpw.'></td></tr>',$str_iconav);
$str_iconav.='<style>.swiper-slide .iconav{table-layout:fixed;}.swiper-slide .iconav tr td a{color:'.$tmpcolor.';font-size:'.$tmpsize.'px}</style>';

$isiconav=count(explode('<img src',$str_iconav))-1;

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_it618_sale_waphome.php';
if(($_G['timestamp'] - @filemtime($cache_file)) > $it618_sale['sale_hometime']||$it618_sale['sale_hometime']==0) {

	$waphomead=C::t('#it618_sale#it618_sale_set')->getsetvalue_by_setname('waphomead');
	
	for($i=1;$i<=2;$i++){
		
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_sale_class'.$i)." WHERE it618_wapgoodscount>0 ORDER BY it618_homeorder");
		while($it618_sale_class = DB::fetch($query1)) {
			
			$classid1=0;$classid2=0;
			
			if($i==1){
				$classid1=$it618_sale_class['id'];
				$classname=$it618_sale_class['it618_classname'];
			}else{
				$classid1=$it618_sale_class['it618_class1_id'];
				$classid2=$it618_sale_class['id'];
				
				$classname1=C::t('#it618_sale#it618_sale_class1')->fetch_it618_name_by_id($classid1);
	
				$classname=$classname1.' '.$it618_sale_class['it618_classname'];
			}
			
			$it618goods='';$tdn=1;
			foreach(C::t('#it618_sale#it618_sale_goods')->fetch_all_by_search(
				"it618_state=1 and (it618_actime1='' or (it618_actime1!='' and UNIX_TIMESTAMP(it618_actime1)<=".$_G['timestamp']."))",'UNIX_TIMESTAMP(it618_quantime2)-'.$_G['timestamp'].',id desc',$classid1,$classid2,'',0,0,$startlimit,$it618_sale_class['it618_wapgoodscount']
			) as $it618_sale_goods) {
				
				$it618_price1='<span>&yen;'.$it618_sale_goods['it618_saleprice'].'</span>';
				$it618_price2='';
				if($it618_sale_goods['it618_price']>0)$it618_price2='&yen;<del>&yen;'.$it618_sale_goods['it618_price'].'</del>';
				
				$it618_quanstr='';
				if($it618_sale_goods['it618_quantime1']!=''){
					$it618_quanstr='<div class="divquan">'.$it618_sale_goods['it618_quanstr'].'</div>';
					$quanstr=$it618_sale_goods['it618_quanstr'];
					
					$it618_price1='<span>&yen;'.it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr).' <font style="font-weight:normal;font-size:10px">'.$it618_sale_lang['s299'].'</font></span>';
					$it618_price2='<del>&yen;'.$it618_sale_goods['it618_saleprice'].'<del>';
				}
				
				$tmpurl=it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
				$tmparr=explode("taobao.com",$it618_sale_goods['it618_pcurl']);
				if($iswx==1&&count($tmparr)>1&&it618_getgoodsisurl($it618_sale_goods)==1){
					$tmpurl='href="javascript:" onclick="showwx('.$it618_sale_goods['id'].')"';
				}else{
					$tmpurl='href="'.$tmpurl.'"';
				}
				
				if($salestyle=='1'){
					$it618goods.='<tr>
								<td class="tdleft">'.$it618_quanstr.'<a '.$tmpurl.'><img class="lazy" data-original="'.$it618_sale_goods['it618_pic'].'"/></a></td>
								<td class="tdright"><a '.$tmpurl.'>
									<div class="tdname">'.$it618_sale_goods['it618_name'].'</div>
									<div class="tddes">'.it618_getjfblcount($it618_sale_goods).'</div>
									<div class="tdprice">
									  <strong>'.$it618_price1.'</strong>
									  '.$it618_price2.'
									</div></a>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
				}else{
					if($tdn%2>0){
						$trtmpstr1='<tr class="trimg">';
						$trtmpstr2='<tr class="trabout">';
						$tdstr='class="tdleft"';
					}else{
						$tdstr='class="tdright"';
					}
	
					$trtmpstr1.='<td '.$tdstr.'>'.$it618_quanstr.'<a '.$tmpurl.'>
									<img class="lazy" data-original="'.$it618_sale_goods['it618_pic'].'"/>
								</a></td>';
					
					$trtmpstr2.='<td '.$tdstr.'><a '.$tmpurl.'>
								<div class="tdname">'.$it618_sale_goods['it618_name'].'</div>
								<div class="tddes">'.it618_getjfblcount($it618_sale_goods).'</div>
								<div class="tdprice"><strong>'.$it618_price1.' </strong> '.$it618_price2.'</div>
							</a></td>';
								
					if($tdn%2==0){
						$trtmpstr1.='</tr>';
						$trtmpstr2.='</tr>';
						$it618goods.=$trtmpstr1.$trtmpstr2;
					}
					
					$tdn=$tdn+1;
				}
			}
		
			if($salestyle=='1'){
				$tmparr=explode('</tr>',$it618goods);
				if(count($tmparr)>1){
					$it618goods=$it618goods.'@@@';
					$it618goods=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$it618goods);
				}
			}else{
				$trtmpstr=$trtmpstr1.'@@@';
				$tmparr=explode('</td>@@@',$trtmpstr);
				if(count($tmparr)>1){
					$trtmpstr1.='</tr>';
					$trtmpstr2.='</tr>';
					$it618goods.=$trtmpstr1.$trtmpstr2;
				}
			}
			
			if($classid2>0){
				$tmpurl=it618_sale_getrewrite('sale_wap','search@'.$classid1.'@'.$classid2,'plugin.php?id=it618_sale:wap&pagetype=search&cid1='.$classid1.'&cid2='.$classid2);
			}else{
				$tmpurl=it618_sale_getrewrite('sale_wap','search@'.$classid1,'plugin.php?id=it618_sale:wap&pagetype=search&cid1='.$classid1);
			}
			
			$str_goods.='<dl class="list">
						<dd><dl style="padding:0">
							<dt style="text-align:left;font-weight:bold;padding-left:11px;font-weight:normal;font-size:17px; padding-right:11px;background-color:#f6f6f6;height:'.$tmpdtheight.'px"><p style="float:right;font-size:14px;color:#aaa;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_sale_lang['t6'].'<img src="source/plugin/it618_sale/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p>'.$classname.'</dt>
							<dd id="dd_goods'.$it618_sale_class1['id'].'">
							<table width="100%" class="tablelist'.$salestyle.'">
								'.$it618goods.'
							</table>
							</dd>
						</dl></dd>
					</dl>';
		}
	
	}
	
	if($it618_sale['sale_hometime']>0){
		require_once libfile('function/cache');
		
		$cacheArray .= "\$str_goods=".arrayeval($str_goods).";\n";
		
		writetocache('it618_sale1', $cacheArray);
	}
}else{
	include_once DISCUZ_ROOT.'./data/sysdata/cache_it618_sale_waphome.php';
}

$searchurl=it618_sale_getrewrite('sale_wap','search@0','plugin.php?id=it618_sale:wap&pagetype=search&findkey=1','?findkey=1');

if($_G['cache']['plugin']['it618_sale']['rewriteurl']==0)$tmpstr='&';else $tmpstr='?';
$sale_home=it618_sale_getrewrite('sale_home','','plugin.php?id=it618_sale:index').$tmpstr.'pc';
$_G['mobiletpl'][2]='/';
include template('it618_sale:wap_sale');
?>