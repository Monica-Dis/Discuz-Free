<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!sale_is_mobile()){
	dheader("location:$sale_home");
}

$navtitle=it618_sale_getlang('t326').' - '.$sitetitle;

if($_G['uid']<=0){
	$tmpurl=it618_sale_getrewrite('sale_wap','','plugin.php?id=it618_sale:wap');
	dheader("location:$tmpurl");
}

$menuusername=$_G['username'];
$u_avatarimg=it618_sale_discuz_uc_avatar($_G['uid'],'middle');
$creditname=$_G['setting']['extcredits'][$it618_sale['sale_credit']]['title'];
$creditnum=DB::result_first("select extcredits".$it618_sale['sale_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_buygroup=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$tmpurl_myvip=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$viplogo='source/plugin/it618_credits/images/group.png';
}

if($IsGroup==1){
	$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	$viplogo='source/plugin/it618_group/images/group.png';
}

if($IsUnion==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
}

$mysaleurl=it618_sale_getrewrite('sale_wap','mysale','plugin.php?id=it618_sale:wap&pagetype=mysale');
$moneyurl=it618_sale_getrewrite('sale_wap','money','plugin.php?id=it618_sale:wap&pagetype=money');
$mymoneyurl=it618_sale_getrewrite('sale_wap','mymoney','plugin.php?id=it618_sale:wap&pagetype=mymoney');
$mycollecturl=it618_sale_getrewrite('sale_wap','mycollect','plugin.php?id=it618_sale:wap&pagetype=mycollect');

$mysalecount=C::t('#it618_sale#it618_sale_sale')->count_by_search('','','',$_G['uid']);
$mysalemoney=C::t('#it618_sale#it618_sale_sale')->sum_money_by_search('','','',$_G['uid']);
if($mysalemoney=='')$mysalemoney=0;

if($it618_sale['sale_isfl']>0){
	$mymoneycount=C::t('#it618_sale#it618_sale_money')->count_by_search('','','',$_G['uid']);
	$mymoneyscore=C::t('#it618_sale#it618_sale_money')->sum_score_by_search('','','',$_G['uid']);
	$mymoneymoney=C::t('#it618_sale#it618_sale_money')->sum_money_by_search('','','',$_G['uid']);
	if($mymoneymoney=='')$mymoneymoney=0;
	$isfl=1;
}

$mycollectcount=C::t('#it618_sale#it618_sale_collect')->count_by_uid($_G['uid']);

$sale_saleuids=explode(",",$it618_sale['sale_saleuids']);
if(in_array($_G['uid'], $sale_saleuids)){
	$saleadminurl=it618_sale_getrewrite('sale_wap','saleadmin','plugin.php?id=it618_sale:wap&pagetype=saleadmin');
	$isadmin=1;
	
	$adminsalecount=C::t('#it618_sale#it618_sale_sale')->count_by_search();
	$adminsalemoney=C::t('#it618_sale#it618_sale_sale')->sum_money_by_search();
	if($adminsalemoney=='')$adminsalemoney=0;
}

$_G['mobiletpl'][2]='/';
include template('it618_sale:wap_sale');
?>