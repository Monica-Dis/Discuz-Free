<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return;

loadcache('plugin');
$it618_sale = $_G['cache']['plugin']['it618_sale'];

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function/it618_sale.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_product&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

define(TOOLS_ROOT, dirname(__FILE__).'/');

$cparray = array('admin_product', 'admin_product_add', 'admin_product_dao', 'admin_product_daoapi', 'admin_product_edit', 'admin_categorytmp');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_product' : $_GET['cp'];

if($cp=='admin_product_add')$strtmp1='class="current"';
if($cp=='admin_product_dao')$strtmp2='class="current"';
if($cp=='admin_product_daoapi')$strtmp3='class="current"';
if($cp=='admin_product'||$cp=='admin_product_edit')$strtmp4='class="current"';
if($cp=='admin_categorytmp')$strtmp4='class="current"';

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp1.'><a href="'.$hosturl.'plugins&cp=admin_product_add'.$urls.'"><span>'.$it618_sale_lang['s9'].'</span></a></li>
<li '.$strtmp2.'><a href="'.$hosturl.'plugins&cp=admin_product_dao'.$urls.'"><span>'.$it618_sale_lang['s271'].'</span></a></li>
<li '.$strtmp3.' style="display:none"><a href="'.$hosturl.'plugins&cp=admin_product_daoapi'.$urls.'"><span>'.$it618_sale_lang['s11'].'</span></a></li>
<li '.$strtmp4.'><a href="'.$hosturl.'plugins&cp=admin_product'.$urls.'"><span>'.$it618_sale_lang['s10'].'</span></a></li>
</ul></div>';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); //dism��taobao��com
?>