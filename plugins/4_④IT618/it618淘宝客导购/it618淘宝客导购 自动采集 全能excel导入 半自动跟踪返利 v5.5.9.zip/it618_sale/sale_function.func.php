<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

if($_G['uid']>0){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		$it618_members = $_G['cache']['plugin']['it618_members'];
		if($it618_members['members_ishome']==1||$it618_members['members_ishome']==2){
			$tmpmembers='<li>
					<a href="javascript:" class="login-link" id="it618_members" style="color:#666"><img src="source/plugin/it618_members/images/logo.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px;" />'.$it618_members['members_homename'].'</a> 
					</li>';
		}
	}
	
	if($IsCredits==1){
		$tmpcredits='<li>
					<a href="javascript:" class="login-link" id="it618_credits" style="color:#666"><img src="source/plugin/it618_credits/images/ico.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px;" />'.it618_sale_getlang('s498').'</a> 
					</li>';
	}
	
	if($IsGroup==1){
		$tmpgroup='<li>
					<a href="javascript:" class="login-link" id="it618_group" style="color:#666"><img src="source/plugin/it618_group/images/group.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px;" />'.it618_sale_getlang('s1946').'</a> 
					</li>';
	}
	
	if($it618_sale['sale_isfl']>0){
		$strfl='<li>
						<a href="javascript:" id="mymoney"><font color=red>'.it618_sale_getlang('s629').'</font></a> 
				    	</li>';
	}
	
	$usermenu='<ul class="login cl">
                <li><a class="login-link" href="'.it618_sale_rewriteurl($_G['uid']).'">'.it618_sale_getusername($_G['uid']).'</a> </li>
				'.$tmpmembers.'
				'.$tmpcredits.'
				'.$tmpgroup.'
                <li class="dropdown dropdown-account">
                    <p class="textwarp">
                        <em class="text">'.it618_sale_getlang('s174').'</em>
                        <i class="triangle"></i>
                        <em class="account-num" style="display:none;"></em>
					</p>
                    <ul class="htul">
						<li>
						<a href="javascript:" id="mysale"><font color=green>'.it618_sale_getlang('s494').'</font></a> 
				    	</li>
						'.$strfl.'
						<li>
						<a href="javascript:" id="mycollect">'.it618_sale_getlang('s175').'</a> 
				    	</li>
                    </ul>
                </li>
                <li><a class="login-link" href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'">['.it618_sale_getlang('s178').']</a></li>
			   </ul>';
}else{
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if($it618_members['members_isok']==1){
		$usermenu='<ul class="login cl">
                <li><a class="login-link it618_members_login" href="javascript:">['.it618_sale_getlang('s179').']</a></li>
                <li><a class="login-link it618_members_reg" href="javascript:">['.it618_sale_getlang('s180').']</a></li>
               </ul>';
	}else{
		$usermenu='<ul class="login cl">
                <li><a class="login-link" href="member.php?mod=logging&action=login">['.it618_sale_getlang('s179').']</a></li>
                <li><a class="login-link" href="member.php?mod='.$RegName.'">['.it618_sale_getlang('s180').']</a></li>
               </ul>';
	}
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	if(isset($_GET['reg']))$winapireg='winapireg';
	$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','',$winapireg);
}

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$it618_credits_buygroup=it618_credits_getcredits($_GET['id'],'#vippaybtn','plugin.php?id=it618_credits:do&dotype=buygroup');
	$it618_credits_index=it618_credits_getcredits($_GET['id'],'#it618_credits').$it618_credits_buygroup;
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_uc=it618_group_getgroup($_GET['id'],'#it618_group');
	$it618_group_ad=it618_group_getad($_GET['id'],2);
}
//From: d'.'is'.'m.ta'.'obao.com
?>