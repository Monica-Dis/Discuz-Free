function detailTitleHeight() {
	var e = $(".detail-nav li.lishow");
	for (df = [], i = 0; i < e.length; i++) {
		var a = $(e[i]).attr("name");
		if ($("#" + a) && $("#" + a).length > 0) {
			var t = $("#" + a).offset().top;
			df.push([a, t])
		}
	}
}
function detailTitle() {
	var e = $(".detail-nav").offset().top,
		a = ($(window).scrollTop(), $(window).scrollTop() + 55);
	if ($(window).scrollTop() < e - 1 || e < $(".detail-navwarp").offset().top) $(".detail-nav").removeClass("detail-navfloat").css({
		position: "static",
		top: "0"
	});
	else if (jQuery.browser.msie && "6.0" == jQuery.browser.version) {
		var t = $(window).scrollTop() - $(".detail-navwarp").offset().top;
		$(".detail-nav").addClass("detail-navfloat").css({
			position: "absolute",
			left: "0",
			top: t
		})
	} else $(".detail-nav").addClass("detail-navfloat").css({
		top: "0",
		position: "fixed"
	});
	for (j = 0; j < df.length; j++) {
		if (a <= df[j][1]) {
			if (0 == j) break;
			$(".detail-nav li").removeClass("current"), $($(".detail-nav li.lishow").eq(j - 1)).addClass("current");
			break
		}
		if (j == df.length - 1) {
			$(".detail-nav li").removeClass("current"), $($(".detail-nav li.lishow").eq(j)).addClass("current");
			break
		}
	}
}

function get_comment(e) {
	var a = $(e).attr("href");
	if (a) {
		$(".appraise-cen,.page2").remove(), $(".appraise-loading").show();
		var t = $(".appraise-title").offset().top - 50;
		$("html, body").animate({
			scrollTop: t
		}, 0), $.get(a, function(e) {
			1 == e.code && ($(".appraise-loading").hide(), $(".appraise-title").after(e.data), photo_change())
		})
	}
	return !1
}

function init_setnmapallpoint() {
	setnmapallpoint && "function" == typeof setnmapallpoint ? setnmapallpoint(npaged) : setTimeout(function() {
		init_setnmapallpoint()
	}, 500)
}
function gotobuy(e) {
	window.location.href = $(".otherinfo-content input.buyin").length > 0 && $(".otherinfo-content input.buyin").val() > 1 ? $(e).attr("href") + "&num=" + $(".otherinfo-content input.buyin").val() : $(e).attr("href")
}

$(document).ready(function() {
	function t(e) {
		var a = $(e).parents(".slider-warp-updown"),
			t = $("ul li", a),
			i = t.children("div");
		t.css("height", i.length * i.outerHeight()), t.animate({
			top: parseInt(t.css("top")) - parseInt(i.outerHeight())
		}, 500, function() {
			$(e).removeClass("disabled"), (0 - parseInt(t.css("top"))) / i.outerHeight() == i.length - 2 && $(e).addClass("disabled"), $(".slider-prev", a).removeClass("disabled")
		})
	}
	function r(e) {
		var a = $(e).parents(".slider-warp-updown"),
			t = $("ul li", a),
			i = t.children("div");
		t.css("height", i.length * i.outerHeight()), t.animate({
			top: parseInt(t.css("top")) + parseInt(i.outerHeight())
		}, 500, function() {
			$(e).removeClass("disabled"), 0 == parseInt(t.css("top")) && $(e).addClass("disabled"), $(".slider-next", a).removeClass("disabled")
		})
	}
	$(".button-cart-add").live("click", function() {
		var e = $(this).attr("_goodid");
		a(e)
	});
	var s = 0,
		l = [];
	$(".together-buy .tb-button a").live("click", function() {
		var a = $(".together-buy .small-goods input[type=checkbox]:checked");
		for (i = 0; i < a.length; i++) l.push($(a[i]).attr("_goodid"));
		l.push($(this).attr("_goodid")), e()
	}), $(".button-red-mobile").live("click", function() {
	}), $(".slider-warp-updown .slider-next").live("click", function() {
		$(".slider-warp-updown img.dynload").length > 0 && $(".slider-warp-updown img.dynload").each(function() {
			$(this).attr("src", $(this).attr("imgsrc")), $(this).removeClass("dynload"), $(this).removeAttr("imgsrc")
		}), $(this).hasClass("disabled") || ($(this).addClass("disabled"), t($(this)))
	}), $(".slider-warp-updown .slider-prev").live("click", function() {
		$(this).hasClass("disabled") || ($(this).addClass("disabled"), r($(this)))
	})
});
var df = [];
$(document).ready(function() {
	$(".detail-nav") && $(".detail-nav").length > 0 && ($(".detail-nav .detail-navbut").append($(".roduct-button").children("a").clone()), $(".detail-nav li:first").addClass("current"), detailTitleHeight(), detailTitle(), $(window).scroll(function() {
		detailTitleHeight(), detailTitle()
	}), $(".detail-nav li.lishow").live("click", function() {
		var e = $(this).attr("name");
		if ($("#" + e).length > 0) {
			var a = $("#" + e).offset().top - 50;
			$("html, body").animate({
				scrollTop: a
			}, 0)
		}
	})), $(".moreaddress").click(function() {
		$(".detail-nav li:first").trigger("click")
	}), $(".to-comment-detail").click(function() {
		$(".detail-nav li.detail-nav-comment").trigger("click")
	})
}), $(document).ready(function() {
	
	$(".otherinfo-content .plus").click(function() {
		var e = $(this).parent().children(".buyin");
		return parseInt(e.val()) + 1 > parseInt(e.attr("min_per_user")) && $(this).parent().children(".minus").removeClass("disabled"), $(this).hasClass("disabled") && parseInt(e.val()) == parseInt(e.attr("max_per_user")) ? void alert("������๺��" + parseInt(e.attr("max_per_user")) + "��") : void(parseInt(e.val()) < parseInt(e.attr("max_per_user")) ? e.val(parseInt(e.val()) + 1) : (alert("������๺��" + parseInt(e.attr("max_per_user")) + "��"), $(this).addClass("disabled")))
	}), $(".otherinfo-content .minus").click(function() {
		var e = $(this).parent().children(".buyin");
		return parseInt(e.val()) - 1 < parseInt(e.attr("max_per_user")) && $(this).parent().children(".plus").removeClass("disabled"), $(this).hasClass("disabled") && parseInt(e.val()) == parseInt(e.attr("min_per_user")) ? void alert("�������ٹ���" + parseInt(e.attr("min_per_user")) + "��") : void(parseInt(e.val()) > parseInt(e.attr("min_per_user")) ? e.val(parseInt(e.val()) - 1) : (alert("�������ٹ���" + parseInt(e.attr("min_per_user")) + "��"), $(this).addClass("disabled")))
	});
});
var neargoods, npaged = 1;