<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_sale = $_G['cache']['plugin']['it618_sale'];

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($_GET['pid']);

$it618_name=$it618_sale_goods['it618_name'];
$it618_about=$it618_sale_goods['it618_description'];
$it618_saleprice=$it618_sale_goods['it618_saleprice'].$it618_sale_lang['s125'];

if($it618_sale_goods['it618_quantime1']!=''){
	
	$quanstr=$it618_sale_goods['it618_quanstr'];
	
	$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr).$it618_sale_lang['s125'].' <span>'.$it618_sale_lang['s299'].'</span>';
}


$share_img=$it618_sale_goods['it618_pic'];
$tmparr=explode('//',$share_img);
if(count($tmparr)==1)$share_img=$_G['siteurl'].$share_img;

if($_GET['wap']==1){
	$tmpurl=$_G['siteurl'].it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
}else{
	$tmpurl=$_G['siteurl'].it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
}

if($IsWxMini==1){
	if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_sale')){
		$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
	}
}

$qrcodesrc='plugin.php?id=it618_sale:urlcode&url='.urlencode($tmpurl);

if($IsUnion==1){
	$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=7 and it618_isproduct=1 and it618_state=1");
	if($sharecodecount>0){
		$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=7&class=product&dataid='.$it618_sale_goods['id'].'&shareurl='.urlencode($tmpurl);
	}
}

if($it618_sale['sale_bdshare']!=1){
	$bdshare='http://bdimg.share.baidu.com/';
}

$_G['mobiletpl'][2]='/';
include template('it618_sale:share');
?>