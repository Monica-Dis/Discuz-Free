<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';

//��������API
function it618_sale_TbkDgMaterialOptionalRequest($findkey,$page,$pagesize=100){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/TopClient.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/ResultSet.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/RequestCheckUtil.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/TopLogger.php';
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/TbkDgMaterialOptionalRequest.php';
	
	$c = new TopClient;
	$c->appkey = $appkey;
	$c->secretKey = $secretkey;
	
	$req = new TbkDgMaterialOptionalRequest;
	$req->setAdzoneId($adzoneid);
	$req->setMaterialId("2836");
	$findkey=it618_sale_gbktoutf1($findkey);
	$req->setQ($findkey);
	$req->setPageSize($pagesize);
	$req->setPageNo($page);
	
	$resp = $c->execute($req);
	
//	$s = var_export($resp,true);
//	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/debug.txt',"a");
//	fwrite($fp,$s);
//	fclose($fp);
	
	return it618_sale_object_array($resp);
}

//���Ͼ�ѡAPI
function it618_sale_TbkDgOptimusMaterialRequest($materialid,$page=1,$pagesize=100){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/TopClient.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/ResultSet.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/RequestCheckUtil.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/TopLogger.php';
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/TbkDgOptimusMaterialRequest.php';
	
	$c = new TopClient;
	$c->appkey = $appkey;
	$c->secretKey = $secretkey;
	
	$req = new TbkDgOptimusMaterialRequest;
	$req->setAdzoneId($adzoneid);
	$req->setMaterialId($materialid);
	$req->setPageSize($pagesize);
	$req->setPageNo($page);

	$resp = $c->execute($req);
	return it618_sale_object_array($resp);
}

function it618_sale_addquancheck(){
	$materialid=C::t('#it618_sale#it618_sale_material')->getmaterialid();
	$datas=it618_sale_TbkDgOptimusMaterialRequest($materialid);

	if($datas["msg"]!=''){
		return it618_sale_utftogbk($datas["code"].': '.$datas["msg"].', '.$datas["sub_msg"]);
	}
	
	if(count($datas['result_list']['map_data'])==0){
		return 'Invalid AdzoneId';
	}
	
	unset($datas);
	return 'OK';
}

function it618_sale_addquangoods($materialid,$page,$findkey=''){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
	}
	
	global $_G,$it618_sale,$it618_sale_lang;
	
	if($materialid>0){
		$it618_sale_material=C::t('#it618_sale#it618_sale_material')->fetch_by_materialid($materialid);
		$classid2=$it618_sale_material['it618_class2_id'];
		$datas=it618_sale_TbkDgOptimusMaterialRequest($materialid,$page);
		if($datas["msg"]!=''){
			$datas=it618_sale_TbkDgOptimusMaterialRequest($materialid,$page);
		}
	}else{
		$datas=it618_sale_TbkDgMaterialOptionalRequest($findkey,$page);
		if($datas["msg"]!=''){
			$datas=it618_sale_TbkDgMaterialOptionalRequest($findkey,$page);
		}
	}
	
	if($datas["msg"]!=''){
		return it618_sale_utftogbk($datas["code"].': '.$datas["msg"].', '.$datas["sub_msg"]);
	}

	if(count($datas['result_list']['map_data'])==0){
		return 'Invalid AdzoneId';
	}
	
	$classid1=1;
	
	$addcount=0;$editcount=0;
	$classid2tmp = DB::result_first("SELECT id FROM ".DB::table('it618_sale_class2')." WHERE it618_class1_id=1 AND it618_classname='".$it618_sale_lang['s580']."'");
	
	for($i=0;$i<count($datas['result_list']['map_data']);$i++){
		$category=$datas["result_list"]["map_data"][$i]["category_id"];

		if($category=='')$category=$datas["result_list"]["map_data"][$i]["level_one_category_id"];
		if($category=='')continue;
		
		if($classid2==0){
			if($it618_sale_category=C::t('#it618_sale#it618_sale_category')->fetch_by_it618_category($category)){
				$classid2=$it618_sale_category['it618_class2_id'];
			}else{
				$classid2=$classid2tmp;
			}
		}else{
			if(!$it618_sale_category=C::t('#it618_sale#it618_sale_category')->fetch_by_it618_category($category)){
				C::t('#it618_sale#it618_sale_category')->insert(array(
					'it618_class2_id' => $classid2,
					'it618_category' => $category
				), true);
			}
		}
		
		$it618_class1_id=$classid1;
		$it618_class2_id=$classid2;
		$it618_category=$category;
		$it618_productid=$datas["result_list"]["map_data"][$i]["item_id"];
		$it618_name=it618_sale_utftogbk($datas["result_list"]["map_data"][$i]["title"]);
		if($it618_name=='')continue;
		$it618_description=it618_sale_utftogbk($datas["result_list"]["map_data"][$i]["item_description"]);

		$it618_actime2='';$it618_quantime1='';$it618_quantime2='';$it618_quanstr='';
		$coupon_start_time=$datas["result_list"]["map_data"][$i]["coupon_start_time"];
		$coupon_end_time=$datas["result_list"]["map_data"][$i]["coupon_end_time"];
		if($coupon_start_time==''){
			if($isquan0add==1){
				$it618_actime2=date('Y-m-d H:i:s', $_G['timestamp']+3600*24*$quan0saleetime);
				
				if($materialid>0){
					$it618_url=$datas["result_list"]["map_data"][$i]["click_url"];
				}else{
					$it618_url=$datas["result_list"]["map_data"][$i]["url"];
				}
				$tmparr=explode('http',$it618_url);
				if(count($tmparr)==1){
					$it618_url='https:'.$it618_url;
				}
				$it618_quanurl='';
			}else{
				continue;
			}
		}else{
			$it618_url=$datas["result_list"]["map_data"][$i]["coupon_share_url"];
			$tmparr=explode('http',$it618_url);
			if(count($tmparr)==1){
				$it618_url='https:'.$it618_url;
			}
			$it618_quanurl=$it618_url;
			
			$it618_quanstr=it618_sale_utftogbk($datas["result_list"]["map_data"][$i]["coupon_info"]);
			if($it618_quanstr==''){
				$it618_quanstr=$datas["result_list"]["map_data"][$i]["coupon_amount"].$it618_sale_lang['s690'];
			}
			
			if($materialid>0){
				$it618_quantime1=date('Y-m-d H:i:s', $coupon_start_time/1000);
				$it618_quantime1=str_replace("/","-",$it618_quantime1);
				$it618_quantime2=date('Y-m-d H:i:s', $coupon_end_time/1000);
				$it618_quantime2=str_replace("/","-",$it618_quantime2);
			}else{
				$it618_quantime1=$coupon_start_time.' 00:00:00';
				$it618_quantime2=$coupon_end_time.' 23:59:59';
			}
		}
		
		$it618_price=$datas["result_list"]["map_data"][$i]["zk_final_price"];
		$it618_volume=$datas["result_list"]["map_data"][$i]["volume"];
		if($it618_volume<$findvolume)continue;
		
		if($materialid>0){
			$it618_acsalebl=$datas["result_list"]["map_data"][$i]["commission_rate"];
		}else{
			$it618_acsalebl=$datas["result_list"]["map_data"][$i]["commission_rate"]/100;
		}
		if($it618_acsalebl<$findcommission_rate)continue;
		
		$it618_pic=$datas["result_list"]["map_data"][$i]["pict_url"];
		$tmparr=explode('http',$it618_pic);
		if(count($tmparr)==1){
			$it618_pic='https:'.$it618_pic;
		}
		
		if($it618_sale_goods=C::t('#it618_sale#it618_sale_goods')->fetch_by_productid($it618_productid)){
			C::t('#it618_sale#it618_sale_goods')->update($it618_sale_goods['id'],array(
				'it618_class1_id' => $it618_class1_id,
				'it618_class2_id' => $it618_class2_id,
				'it618_category' => $it618_category,
				'it618_productid' => $it618_productid,
				'it618_name' => $it618_name,
				'it618_pcurl' => $it618_url,
				'it618_wapurl' => $it618_url,
				'it618_codeurl' => '',
				'it618_name' => $it618_name,
				'it618_acsalebl' => $it618_acsalebl,
				'it618_quanstr' => $it618_quanstr,
				'it618_quanurl' => $it618_quanurl,
				'it618_quancodeurl' => '',
				'it618_quantime1' => $it618_quantime1,
				'it618_quantime2' => $it618_quantime2,
				'it618_description' => $it618_description,
				'it618_seokeywords' => $it618_name,
				'it618_seodescription' => $it618_name,
				'it618_state' => 1,
				'it618_isurl' => 0,
				'it618_price' => 0,
				'it618_saleprice' => $it618_price,
				'it618_pic' => $it618_pic,
				'it618_time' => $_G['timestamp']
			));
			
			$editcount=$editcount+1;
		}else{
			//$it618_codeurl=it618_sale_getcodeurl($it618_name,$it618_url,$it618_pic);
			
			$id=C::t('#it618_sale#it618_sale_goods')->insert(array(
				'it618_class1_id' => $it618_class1_id,
				'it618_class2_id' => $it618_class2_id,
				'it618_category' => $it618_category,
				'it618_productid' => $it618_productid,
				'it618_name' => $it618_name,
				'it618_pcurl' => $it618_url,
				'it618_wapurl' => $it618_url,
				'it618_codeurl' => $it618_codeurl,
				'it618_name' => $it618_name,
				'it618_acsalebl' => $it618_acsalebl,
				'it618_quanstr' => $it618_quanstr,
				'it618_quanurl' => $it618_url,
				'it618_quancodeurl' => $it618_codeurl,
				'it618_quantime1' => $it618_quantime1,
				'it618_quantime2' => $it618_quantime2,
				'it618_actime2' => $it618_actime2,
				'it618_description' => $it618_description,
				'it618_seokeywords' => $it618_name,
				'it618_seodescription' => $it618_name,
				'it618_state' => 1,
				'it618_isurl' => 0,
				'it618_price' => 0,
				'it618_saleprice' => $it618_price,
				'it618_pic' => $it618_pic,
				'it618_time' => $_G['timestamp']
			), true);
			
			if($id>0)$addcount=$addcount+1;
		}
	}
	
	DB::query("delete from ".DB::table('it618_sale_apiwork'));
	return 'page='.$page.' all='.count($datas['result_list']['map_data']).' add='.$addcount.' edit='.$editcount;
	unset($datas);
}

function it618_sale_getcodeurl($it618_name,$it618_url,$it618_pic){
	
	global $_G,$it618_sale,$it618_sale_lang;
	
	$tmparr=explode('taobao.com',$it618_url);
	if(count($tmparr)==1){
		return;
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
	}
	
	$tmparr=explode('http',$it618_url);
	if(count($tmparr)==1){
		$it618_url='https:'.$it618_url;
	}
	
	$tmparr=explode('http',$it618_pic);
	if(count($tmparr)==1){
		$it618_pic='https:'.$it618_pic;
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/TopClient.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/ResultSet.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/RequestCheckUtil.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/TopLogger.php';
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/TbkTpwdCreateRequest.php';

    $c = new TopClient;
	$c->appkey = $appkey;
	$c->secretKey = $secretkey;
	
	$req = new TbkTpwdCreateRequest;
	$req->setText(it618_sale_gbktoutf1($it618_name));
	$req->setUrl($it618_url);
	$req->setLogo($it618_pic);
	$resp = $c->execute($req);
	
//	$s = var_export($resp,true);
//	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/debug.txt',"a");
//	fwrite($fp,$s);
//	fclose($fp);
	
	$tmparr=it618_sale_object_array($resp);

	$codeurl=it618_sale_utftogbk($tmparr["data"]["password_simple"]);
	
//	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/debug.txt',"a");
//	fwrite($fp,'11111111111111'.$codeurl.'11111111111111');
//	fclose($fp);
	
	unset($tmparr);
	
	return $codeurl;
}

function it618_sale_object_array($array) {  
    if(is_object($array)) {  
        $array = (array)$array;  
     } if(is_array($array)) {  
         foreach($array as $key=>$value) {  
             $array[$key] = it618_sale_object_array($value);  
             }  
     }  
     return $array;  
}
//From: d'.'is'.'m.ta'.'obao.com
?>