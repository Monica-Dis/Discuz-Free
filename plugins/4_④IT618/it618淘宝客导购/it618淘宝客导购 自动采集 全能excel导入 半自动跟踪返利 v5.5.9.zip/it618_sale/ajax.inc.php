<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_sale/function.func.php';
$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

$uid = $_G['uid'];


if($_GET['ac']=="gettaobaocategory"){
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
	}
	$code=md5($appkey.$secretkey.$adzoneid);
	if($_GET['code']==$code){
		set_time_limit (0);
		ignore_user_abort(true);
		echo it618_sale_addquancategory($_GET['page']).'<br>';
	}
	exit;
}


if($_GET['ac']=="gettaobaogoods"){
	require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
	}
	$code=md5($appkey.$secretkey.$adzoneid);
	if($_GET['code']==$code){
		set_time_limit (0);
		ignore_user_abort(true);
		echo it618_sale_addquangoods($_GET['page']).'<br>';
	}
	exit;
}

if($_GET['formhash']!=FORMHASH)exit;


if($_GET['ac']=="gettaobaoapi"){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_sale/taobao/config.php';
	}
	
	if($quangoodstime==0)exit;
	
	$cache_file = DISCUZ_ROOT.'./source/plugin/it618_sale/cache_api.php';
	if(($_G['timestamp'] - @filemtime($cache_file)) > $quangoodstime*60) {
		
		@$fp = fopen($cache_file,"w");
		fwrite($fp,$_G['timestamp']);
		fclose($fp);
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_sale_findkeyapi')." WHERE it618_timecount>0 ORDER BY it618_order");
		while($it618_sale_findkeyapi = DB::fetch($query)) {
			if((time()-$it618_sale_findkeyapi["it618_time"])>(60*$it618_sale_findkeyapi["it618_timecount"])){
				$bzstr='';
				C::t('#it618_sale#it618_sale_findkeyapi')->update($it618_sale_findkeyapi["id"],array(
					'it618_time' => time()
				));
	
				require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
				
				set_time_limit (0);
				ignore_user_abort(true);

				while($flagkm==0){
					if(DB::result_first("select count(1) from ".DB::table('it618_sale_apiwork'))==0){
						$flagkm=1;
					}
					if($flagkm==0){
						sleep(1);
						$times=$times+1;
					}
					if($times>30){
						DB::query("delete from ".DB::table('it618_sale_apiwork'));
					}
				}
				C::t('#it618_sale#it618_sale_apiwork')->insert(array(
					'it618_iswork' => 1
				), true);
				
				$bz=it618_sale_addquangoods(0,1,$it618_sale_findkeyapi["it618_key"]);
				sleep(1);
				
				C::t('#it618_sale#it618_sale_findkeyapi')->update($it618_sale_findkeyapi["id"],array(
					'it618_bz' => $bz
				));
			}
		}
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_sale_material')." WHERE it618_timecount>0 ORDER BY it618_order");
		while($it618_sale_material = DB::fetch($query)) {
			if((time()-$it618_sale_material["it618_time"])>(60*$it618_sale_material["it618_timecount"])){
				$bzstr='';
				C::t('#it618_sale#it618_sale_material')->update($it618_sale_material["id"],array(
					'it618_time' => time()
				));
	
				require_once DISCUZ_ROOT.'./source/plugin/it618_sale/taobao.func.php';
				
				$goodscount=C::t('#it618_sale#it618_sale_materialclass')->fetch_goodscount_by_id($it618_sale_material["it618_cid"]);
				$pagecount=intval($goodscount/100);
				
				set_time_limit (0);
				ignore_user_abort(true);
				for($page=1;$page<=$pagecount;$page++){
					while($flagkm==0){
						if(DB::result_first("select count(1) from ".DB::table('it618_sale_apiwork'))==0){
							$flagkm=1;
						}
						if($flagkm==0){
							sleep(1);
							$times=$times+1;
						}
						if($times>30){
							DB::query("delete from ".DB::table('it618_sale_apiwork'));
						}
					}
					C::t('#it618_sale#it618_sale_apiwork')->insert(array(
						'it618_iswork' => 1
					), true);
					
					$bz=it618_sale_addquangoods($it618_sale_material["it618_materialid"],$page);
					sleep(1);
					$bzstr.=$bz.', ';
					
					$bzarr=explode("page=",$bz);
					if(count($bzarr)==1){
						break;
					}
				}
				
				C::t('#it618_sale#it618_sale_material')->update($it618_sale_material["id"],array(
					'it618_bz' => $bzstr
				));
			}
		}

	}
	exit;
}

if($_GET['ac']=='goodslist_get'||$_GET['ac']=='collectlist_get'){
	if($it618_sale['sale_style']>2){
		$salestyle=getcookie('salestyle');
		if($salestyle==''){
			if($it618_sale['sale_style']==3)$salestyle='1';else $salestyle='2';
		}
	}else{
		if($it618_sale['sale_style']==1)$salestyle='1';else $salestyle='2';
	}
}


if($_GET['ac']=="addcollect"){
	$pid = intval($_GET['pid']);
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	if($uid>0){
		$tmpcount=C::t('#it618_sale#it618_sale_collect')->count_by_uid_pid($uid,$pid);
		if($tmpcount>0){
			echo it618_sale_getlang('s181');
		}else{
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			C::t('#it618_sale#it618_sale_collect')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $pid,
				'it618_time' => $_G['timestamp']
			), true);
			C::t('#it618_sale#it618_sale_goods')->update_it618_collect_by_id($pid);
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			echo it618_sale_getlang('s182');
		}
	}else{
		echo it618_sale_getlang('s183');
	}
	exit;
}


if($_GET['ac']=="getcollect"){
	if($uid>0){
		$count=C::t('#it618_sale#it618_sale_collect')->count_by_uid_pid($uid,$_GET['pid']);
		if($count>0){
			C::t('#it618_sale#it618_sale_collect')->delete_by_uid_pid($uid,$_GET['pid']);
			echo '2';
		}else{
			C::t('#it618_sale#it618_sale_collect')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $_GET['pid'],
				'it618_time' => $_G['timestamp']
			), true);
			C::t('#it618_sale#it618_sale_goods')->update_it618_collect_by_id($pid);
			echo '1';
		}
	}else{
		echo $it618_sale_lang['t150'];
	}
	exit;
}


if($_GET['ac']=="delcollect"){
	$pid = intval($_GET['pid']);
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	if($uid>0){
		$tmpcount=C::t('#it618_sale#it618_sale_collect')->count_by_uid_pid($uid,$pid);
		if($tmpcount==0){
			echo it618_sale_getlang('s184');
		}else{
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			C::t('#it618_sale#it618_sale_collect')->delete_by_uid_pid($uid,$pid);
			C::t('#it618_sale#it618_sale_goods')->update_it618_collect_by_id($pid);
			
			echo it618_sale_getlang('s185');
		}
	}else{
		echo it618_sale_getlang('s186');
	}
	exit;
}


if($_GET['ac']=="delcollects"){
	$tmparr=explode('_',$_GET['cid']);
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	for($i=0;$i<count($tmparr);$i++){
		$tmpid=intval($tmparr[$i]);
		if($tmpid>0){
			$it618_sale_collect=C::t('#it618_sale#it618_sale_collect')->fetch_by_id($tmpid);
			C::t('#it618_sale#it618_sale_collect')->delete_by_id($tmpid);
			C::t('#it618_sale#it618_sale_goods')->update_it618_collect_by_id($it618_sale_collect['it618_pid']);
		}
	}
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	echo it618_sale_getlang('s187');
	exit;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d"."z-"."x. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/kindeditor/themes/common/ri'.'ght.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="collectlist_get"){
	
	if($_GET['ac1']=='pcmycollect'){$ppp = 8;$funname='getmycollectlist';}
	if($_GET['ac1']=='wapmycollect'){$ppp = 15;$funname='getmycollectlist';}
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	$it618_sale_collects=C::t('#it618_sale#it618_sale_collect')->fetch_all_by_uid($uid,$startlimit,$ppp);
	$count=C::t('#it618_sale#it618_sale_collect')->count_by_uid($uid);
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	$n=0;$tdn=1;
	foreach($it618_sale_collects as $it618_sale_collect) {
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		if(!$it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($it618_sale_collect['it618_pid'])){
			DB::query("delete from ".DB::table('it618_sale_collect')." where it618_pid=".$it618_sale_collect['it618_pid']);
			continue;
		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/lang.func.php';
			
		}
		if($_GET['ac1']=='pcmycollect'){
			$class1name = C::t('#it618_sale#it618_sale_class1')->fetch_it618_name_by_id($it618_sale_goods['it618_class1_id']);
			$class2name = C::t('#it618_sale#it618_sale_class2')->fetch_it618_name_by_id($it618_sale_goods['it618_class2_id']);
			
			$it618_price1='<span>&yen;'.$it618_sale_goods['it618_saleprice'].'</span>';
			$it618_price2='';
			if($it618_sale_goods['it618_price']>0)$it618_price2='&yen;<del>&yen;'.$it618_sale_goods['it618_price'].'</del>';
			
			$it618_quanstr='';
			if($it618_sale_goods['it618_quantime1']!=''){
				$it618_quanstr='<div class="divquan">'.$it618_sale_goods['it618_quanstr'].'</div>';
				$quanstr=$it618_sale_goods['it618_quanstr'];
				
				$it618_price1='<span style="color:red">&yen;'.it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr).' <font style="font-weight:normal;font-size:11px">'.$it618_sale_lang['s299'].'</font></span>';
				$it618_price2='<del>&yen;'.$it618_sale_goods['it618_saleprice'].'</del>';
			}
			
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
			$collectlist_get.='<tr class="hover">
						<td><input class="checkbox" type="checkbox" name="chk_sel" value="'.$it618_sale_collect['id'].'"></td>
						<td><a style="float:left" href="'.$tmpurl.'" target="_blank" title="'.$class1name.'-'.$class2name.'"><img src="'.$it618_sale_goods['it618_pic'].'" width="55" height="55" align="absmiddle"/></a><div style="float:left;margin-left:3px;line-height:18px;width:280px"><a href="'.$tmpurl.'" target="_blank">'.$it618_sale_goods['it618_name'].'</a> <br>'.it618_sale_getlang('s199').''.$it618_price1.'  '.$it618_price2.' '.$tmpstr.' <span  class="setshare" style="cursor:pointer" id="mypcit618split'.$it618_sale_goods['id'].'" onclick="return false;"><font color="green">['.it618_sale_getlang('s198').']</font></span></div></td>
						<td><div style="float:left;height:55px;overflow:hidden">'.it618_getjfblcount($it618_sale_goods).'</div></td>
						<td align="center">'.$it618_sale_goods['it618_views'].'</td>
						<td align="center"><font color="red">'.$it618_sale_goods['it618_collect'].'</font></td>
						<td>'.date('Y-m-d H:i:s', $it618_sale_collect['it618_time']).'</td>
						</tr>';
		}
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		if($_GET['ac1']=='wapmycollect'){
			
			$it618_price1='<span>&yen;'.$it618_sale_goods['it618_saleprice'].'</span>';
			$it618_price2='';
			if($it618_sale_goods['it618_price']>0)$it618_price2='&yen;<del>&yen;'.$it618_sale_goods['it618_price'].'</del>';
			
			$it618_quanstr='';
			if($it618_sale_goods['it618_quantime1']!=''){
				$it618_quanstr='<div class="divquan">'.$it618_sale_goods['it618_quanstr'].'</div>';
				$quanstr=$it618_sale_goods['it618_quanstr'];
				
				$it618_price1='<span>&yen;'.it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr).' <font style="font-weight:normal;font-size:11px">'.$it618_sale_lang['s299'].'</font></span>';
				$it618_price2='<del>&yen;'.$it618_sale_goods['it618_saleprice'].'</del>';
			}
			
			$tmpurl=it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
			$tmparr=explode("taobao.com",$it618_sale_goods['it618_pcurl']);
			if($iswx==1&&count($tmparr)>1&&it618_getgoodsisurl($it618_sale_goods)==1){
				$tmpurl='href="javascript:" onclick="showwx('.$it618_sale_goods['id'].')"';
			}else{
				$tmpurl='href="'.$tmpurl.'"';
			}
			
			if($salestyle=='1'){
				$collectlist_get.='<tr>
							<td class="tdleft">'.$it618_quanstr.'<a '.$tmpurl.'><img class="lazy" data-original="'.$it618_sale_goods['it618_pic'].'"/></a></td>
							<td class="tdright"><a '.$tmpurl.'>
								<div class="tdname">'.$it618_sale_goods['it618_name'].'</div>
								<div class="tddes">'.it618_getjfblcount($it618_sale_goods).'</div>
								<div class="tdprice">
								  <strong>'.$it618_price1.'</strong>
								  <del>'.$it618_price2.'</del>
								</div></a>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
			}else{
				if($tdn%2>0){
					$trtmpstr1='<tr class="trimg">';
					$trtmpstr2='<tr class="trabout">';
					$tdstr='class="tdleft"';
				}else{
					$tdstr='class="tdright"';
				}
				
				$trtmpstr1.='<td '.$tdstr.'>'.$it618_quanstr.'<a '.$tmpurl.'>
								<img class="lazy" data-original="'.$it618_sale_goods['it618_pic'].'"/>
							</a></td>';
				
				$trtmpstr2.='<td '.$tdstr.'><a '.$tmpurl.'>
							<div class="tdname">'.$it618_sale_goods['it618_name'].'</div>
							<div class="tddes">'.it618_getjfblcount($it618_sale_goods).'</div>
							<div class="tdprice"><strong>'.$it618_price1.' </strong> '.$it618_price2.'</div>
						</a></td>';
							
				if($tdn%2==0){
					$trtmpstr1.='</tr>';
					$trtmpstr2.='</tr>';
					$collectlist_get.=$trtmpstr1.$trtmpstr2;
				}
				
				$tdn=$tdn+1;
			}
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='wapmycollect'){
		if($salestyle=='1'){
			$tmparr=explode('</tr>',$collectlist_get);
			if(count($tmparr)>1){
				$collectlist_get=$collectlist_get.'@@@';
				$collectlist_get=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$collectlist_get);
			}
		}else{
			$trtmpstr=$trtmpstr1.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr);
			if(count($tmparr)>1){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$collectlist_get.=$trtmpstr1.$trtmpstr2;
			}
		}
	}
	
	if($_GET['ac1']=='pcmycollect'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_sale:ajax".$urlsql);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_sale_getlang('s188').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s189').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_sale_getlang('s189').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s188').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s189').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s188').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_sale_getlang('s189').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext.' '.it618_sale_getlang('s190')."<font color=red>$count</font>";
		}
	}
	
	echo it618_sale_getlang('s190')."<font color=red>$count</font>it618_split".$collectlist_get."it618_split".$multipage;
	exit;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."w.d"."z-"."x. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_sale/kindeditor/themes/common/ri'.'ght.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="sale_add"){
	if($uid<=0){
		echo $it618_sale_lang['s382'];
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_sale_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				delsalework();
			}
		}
		C::t('#it618_sale#it618_sale_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		
		$pid=intval($_GET['pid']);
		$it618_count=intval($_GET['it618_count']);

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_count<=0){
			echo $it618_sale_lang['s383'];delsalework();exit;
		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/lang.func.php';
			
		}
		
		
		if(!($it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id_state($pid,1))){
			echo $it618_sale_lang['s384'];delsalework();exit;
		}
		
		if($it618_sale['sale_isjf']==1){
			$isjfok=1;
			
			$sale_buygrouppower=(array)unserialize($it618_sale['sale_buygrouppower']);
			if(!in_array($_G['groupid'], $sale_buygrouppower)&&$sale_buygrouppower[0]!=''){
				echo $it618_sale_lang['s392'];delsalework();exit;
			}
			
			if($it618_sale['sale_priceforjf']!=''){
				$tmparr=explode(",",$it618_sale['sale_priceforjf']);
				if(($it618_sale_goods['it618_saleprice']<$tmparr[0]||$it618_sale_goods['it618_saleprice']>$tmparr[1])){
					$isjfok=0;
				}
			}
		}else{
			$isjfok=0;
		}
		
		if($isjfok==0){
			echo $it618_sale_lang['s385'];delsalework();exit;
		}
		
		$it618_saleprice=it618_getquanprice($it618_sale_goods['it618_saleprice'],$it618_sale_goods['it618_quanstr']);
		$it618_score=round($it618_saleprice*$it618_sale['sale_jfbl']/100);
		
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		
		$creditnumtmp=DB::result_first("select extcredits".$it618_sale['sale_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
		if(($it618_score*$it618_count)>$creditnumtmp){
			echo $it618_sale_lang['s386'].$creditnumtmp.' '.$creditname.$it618_sale_lang['s387'];delsalework();exit;
		}
		
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($it618_sale_goods['it618_xgcount']>0){
			if($it618_sale_goods['it618_xgtime']==0){
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_sale_sale')." where it618_pid=".$pid." and (it618_state=1 or it618_state=2 or it618_state=3) and it618_uid=".$uid);
			}else{
				$time=$_G['timestamp']-$it618_sale_goods['it618_xgtime']*3600*24;
				
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_sale_sale')." where it618_pid=".$pid." and it618_time>$time and (it618_state=1 or it618_state=2 or it618_state=3) and it618_uid=".$uid);
			}
			
			if($it618_count>$it618_sale_goods['it618_xgcount']-$buycount){
				if($it618_sale_goods['it618_xgtime']==0){
					echo it618_sale_getlang('s489').$it618_sale_goods['it618_xgcount'].it618_sale_getlang('s490').$buycount.it618_sale_getlang('s491');delsalework();exit;
				}else{
					echo it618_sale_getlang('s492').$it618_sale_goods['it618_xgtime'].it618_sale_getlang('s493').$it618_sale_goods['it618_xgcount'].it618_sale_getlang('s490').$buycount.it618_sale_getlang('s491');delsalework();exit;
				}
			}
		}

		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		if($ii1i11i[9]!='e')exit;
		$id = C::t('#it618_sale#it618_sale_sale')->insert(array(
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_pname' => $it618_sale_goods['it618_name'],
			'it618_price' => $it618_sale_goods['it618_saleprice'],
			'it618_score' => $it618_score,
			'it618_salebl' => $it618_acsalebl,
			'it618_count' => $it618_count,
			'it618_name' => it618_sale_utftogbk($_GET["it618_name"]),
			'it618_tel' => it618_sale_utftogbk($_GET["it618_tel"]),
			'it618_addr' => it618_sale_utftogbk($_GET["it618_addr"]),
			'it618_bz' => it618_sale_utftogbk($_GET["it618_bz"]),
			'it618_state' => 1,
			'it618_time' => $_G['timestamp']
		), true);

		if($id>0){
			
			C::t('common_member_count')->increase($uid, array(
				'extcredits'.$it618_sale['sale_credit'] => (0-($it618_score*$it618_count)))
			);
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			
			it618_sale_sendmessage('sale_user',$id);
			it618_sale_sendmessage('sale_admin',$id);
			
			echo 'ok';delsalework();
		}
	}
	exit;
}

function delsalework(){
	DB::query("delete from ".DB::table('it618_sale_salework'));
}


if($_GET['ac']=="delsale"){
	$saleid = intval($_GET['saleid']);
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	if($uid>0){
		$it618_sale_sale=C::t('#it618_sale#it618_sale_sale')->fetch_by_id($saleid);
		if($it618_sale_sale['it618_uid']!=$uid||$it618_sale_sale['it618_state']!=1){
			echo it618_sale_getlang('s385');
		}else{
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			C::t('#it618_sale#it618_sale_sale')->delete_by_id($saleid);
			C::t('common_member_count')->increase($uid, array(
				'extcredits'.$it618_sale['sale_credit'] => ($it618_sale_sale['it618_count']*$it618_sale_sale['it618_score']))
			);
			DB::query("update ".DB::table('it618_sale_goods')." set it618_salecount=it618_salecount-".$it618_sale_sale['it618_count']." where id=".$it618_sale_sale['it618_pid']);
			
			echo 'okit618_split'.it618_sale_getlang('s389');
		}
	}else{
		echo it618_sale_getlang('s546');
	}
	exit;
}


if($_GET['ac']=="tuihuo"){
	$saleid = intval($_GET['saleid']);
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	if($uid>0){
		$it618_sale_sale=C::t('#it618_sale#it618_sale_sale')->fetch_by_id($saleid);
		if($it618_sale_sale['it618_uid']!=$uid||$it618_sale_sale['it618_state']!=2){
			echo it618_sale_getlang('s385');
		}else{
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			
			DB::query("update ".DB::table('it618_sale_sale')." set it618_state=4 where id=".$saleid);
			
			it618_sale_sendmessage('salestate_admin',$it618_sale_sale['id']);
			
			echo 'okit618_split'.it618_sale_getlang('s390');
		}
	}else{
		echo it618_sale_getlang('s186');
	}
	exit;
}


if($_GET['ac']=="shouhuo"){
	$saleid = intval($_GET['saleid']);
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	if($uid>0){
		$it618_sale_sale=C::t('#it618_sale#it618_sale_sale')->fetch_by_id($saleid);
		if($it618_sale_sale['it618_uid']!=$uid||$it618_sale_sale['it618_state']!=2){
			echo it618_sale_getlang('s385');
		}else{
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			
			DB::query("update ".DB::table('it618_sale_sale')." set it618_state=3 where id=".$saleid);
			
			echo 'okit618_split'.it618_sale_getlang('s673');
		}
	}else{
		echo it618_sale_getlang('s186');
	}
	exit;
}


if($_GET['ac']=="salelist_get"){
	if($_GET['ac1']=='pcmysale')$ppp = 15;
	if($_GET['ac1']=='wapmysale')$ppp = 15;
	if($_GET['ac1']=='wapsaleadmin')$ppp = 15;
	
	if($uid==0)$uid=-1;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql .= "s.it618_state = 1";
		if($_GET['state']==2)$it618sql .= "s.it618_state = 2";
		if($_GET['state']==3)$it618sql .= "s.it618_state = 3";
		if($_GET['state']==4)$it618sql .= "s.it618_state = 4";
		if($_GET['state']==5)$it618sql .= "s.it618_state = 5";
		if($_GET['state']==6)$it618sql .= "s.it618_state = 6";
	}
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	
	if($_GET['ac1']=='pcmysale'){		
		$it618_sale_sales=C::t('#it618_sale#it618_sale_sale')->fetch_all_by_search($it618sql,'s.id desc',it618_sale_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_sale#it618_sale_sale')->count_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$money=C::t('#it618_sale#it618_sale_sale')->sum_money_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmysalelist';
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_sale/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_sale/lang.func.php';
		
	}
	if($_GET['ac1']=='wapmysale'){
		$it618_sale_sales=C::t('#it618_sale#it618_sale_sale')->fetch_all_by_search($it618sql,'s.id desc',it618_sale_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_sale#it618_sale_sale')->count_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$money=C::t('#it618_sale#it618_sale_sale')->sum_money_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmysalelist';
	}
	if($_GET['ac1']=='wapsaleadmin'){
		$sale_saleuids=explode(",",$it618_sale['sale_saleuids']);
		if(in_array($uid, $sale_saleuids)){
			$it618_sale_sales=C::t('#it618_sale#it618_sale_sale')->fetch_all_by_search($it618sql,'s.id desc',it618_sale_utftogbk($_GET['pname']),$_GET['finduid'], '', '',$startlimit,$ppp);
			$count=C::t('#it618_sale#it618_sale_sale')->count_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
			$money=C::t('#it618_sale#it618_sale_sale')->sum_money_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
			$funname='getsaleadminlist';
			$tmp.='<option value="0">'.$it618_sale_lang['s520'].'</option>';
			foreach(C::t('#it618_sale#it618_sale_kd')->fetch_all_by_search() as $it618_sale_kd) {
				$tmp.='<option value='.$it618_sale_kd['id'].'>'.$it618_sale_kd['it618_name'].'</option>';
			}
		}
	}
	
	$n=0;
	foreach($it618_sale_sales as $it618_sale_sale) {
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
	
		$username=it618_sale_getusername($it618_sale_sale['it618_uid']);
		
		if($it618_sale_goods = C::t('#it618_sale#it618_sale_goods')->fetch_by_id($it618_sale_sale['it618_pid'])){
			if($_GET['ac1']=='pcmysale'){
				$tmpurl=it618_sale_getrewrite('sale_product',$it618_sale_goods['id'],'plugin.php?id=it618_sale:product&pid='.$it618_sale_goods['id']);
				$pnamestr='<a href="'.$tmpurl.'" target="_blank">'.$it618_sale_goods['it618_name'].'</a>';
			}else{
				$waptmpurl=it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
				$wappname=$it618_sale_goods['it618_name'];
				$wapppic=$it618_sale_goods['it618_pic'];
			}
		}else{
			if($_GET['ac1']=='pcmysale'){
				$pnamestr=$it618_sale_sale['it618_pname'];
			}else{
				$waptmpurl="#";
				$wappname=$it618_sale_sale['it618_pname'];
				$wapppic="source/plugin/it618_sale/images/nogoods.png";
			}
		}
		
		$buyuser='<a href="'.it618_sale_rewriteurl($it618_sale_sale['it618_uid']).'" target="_blank">'.$username.'</a>';
		
		if($it618_sale_sale['it618_state']==1)$it618_state='<font color=red>'.$it618_sale_lang['s347'].'</font>';
		if($it618_sale_sale['it618_state']==2)$it618_state='<font color=green>'.$it618_sale_lang['s348'].'</font>';
		if($it618_sale_sale['it618_state']==3)$it618_state='<font color=green>'.$it618_sale_lang['s496'].'</font>';
		if($it618_sale_sale['it618_state']==4)$it618_state='<font color=red>'.$it618_sale_lang['s349'].'</font>';
		if($it618_sale_sale['it618_state']==5)$it618_state='<font color=#999>'.$it618_sale_lang['s350'].'</font>';
		if($it618_sale_sale['it618_state']==6)$it618_state='<font color=blue>'.$it618_sale_lang['s351'].'</font>';
		
		$strbtn='';$it618_kddan='';
		if($it618_sale_sale['it618_state']==1){
			if($_GET['ac1']=='pcmysale'){
				$strbtn=' [<a href="javascript:" onclick="delsale('.$it618_sale_sale['id'].')">'.$it618_sale_lang['s497'].'</a>]';
			}else{
				$strbtn=' [<span onclick="delsale('.$it618_sale_sale['id'].');return false;">'.$it618_sale_lang['s497'].'</span>]';
			}
		}
		
		if($it618_sale_sale['it618_state']==2){
			if($it618_sale_sale['it618_kddan']!=''){
				$it618_sale_kd=C::t('#it618_sale#it618_sale_kd')->fetch_by_id($it618_sale_sale['it618_kdid']);
				if($_GET['ac1']=='pcmysale'){
					$it618_kddan=' '.it618_sale_getlang('s775').'<span title="'.$it618_sale_sale['it618_bz'].'"><a href="'.$it618_sale_kd['it618_url'].'" target="_blank">'.$it618_sale_kd['it618_name'].'</a> '.$it618_sale_sale['it618_kddan'].' <a href="javascript:" onclick="alert(\''.$it618_sale_sale['it618_addr'].' '.$it618_sale_sale['it618_name'].' '.$it618_sale_sale['it618_tel'].'\')">'.it618_sale_getlang('s495').'</a></span>';
				}else{
					$it618_kddan=' '.it618_sale_getlang('s775').'<span onclik="location.href=\''.$it618_sale_kd['it618_url'].'\';return false;">'.$it618_sale_kd['it618_name'].'</span> '.$it618_sale_sale['it618_kddan'].' <span onclick="alert(\''.$it618_sale_sale['it618_addr'].' '.$it618_sale_sale['it618_name'].' '.$it618_sale_sale['it618_tel'].'\');return false;">'.it618_sale_getlang('s495').'</span>';
				}
			}
			
			if($_GET['ac1']=='pcmysale'){
				$strbtn=' [<a href="javascript:" onclick="tuihuo('.$it618_sale_sale['id'].')">'.$it618_sale_lang['s388'].'</a>][<a href="javascript:" onclick="shouhuo('.$it618_sale_sale['id'].')">'.$it618_sale_lang['s496'].'</a>]';
			}else{
				$strbtn=' [<span onclick="tuihuo('.$it618_sale_sale['id'].');return false;">'.$it618_sale_lang['s388'].'</span>][<span onclick="shouhuo('.$it618_sale_sale['id'].');return false;">'.$it618_sale_lang['s496'].'</span>]';
			}
		}
		
		if($_GET['ac1']=='pcmysale'){
			$salelist_get.='<tr class="hover">
						<td><input class="checkbox" type="checkbox" id="chk'.$it618_sale_sale['id'].'" name="chk_sel" value="'.$it618_sale_sale['id'].'"><label for="chk'.$it618_sale_sale['id'].'">'.$it618_sale_sale['id'].'</label></td>
						<td>'.$pnamestr.'</td>
						<td>'.$it618_sale_sale['it618_price'].'</td>
						<td>'.$it618_sale_sale['it618_score'].'</td>
						<td>'.$it618_sale_sale['it618_count'].'</td>
						<td>'.$it618_state.$strbtn.$it618_kddan.'</a></td>
						<td>'.date('Y-m-d H:i:s', $it618_sale_sale['it618_time']).'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysale'){
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			
			$tmpdivstr='<div style="height:15px">'.$strbtn.'<span class="line-right">'.$it618_state.'</span></div>';
			
			if($it618_sale_sale['it618_state']==3){
				$tmpdivstr='<div style="height:15px"><span class="line-right">'.$it618_state.'</span></div>';
			}
			
			$salelist_get.='<dd><a href="'.$waptmpurl.'" class="react">
							<div class="dealcard">
								<div class="dealcard-img"><img src="'.$wapppic.'"/></div>
								<div class="dealcard-block-right">
								<div class="dealcard-sale single-line" style="padding-top:3px">'.$wappname.'<span></span></div>
								
								<div class="title text-block" style="height:20px">'.$it618_sale_lang['t109'].':<font color=red>'.$it618_sale_sale['it618_price'].'</font> '.$it618_sale_lang['s125'].' '.$it618_sale_lang['t111'].':<font color=red>'.$it618_sale_sale['it618_score'].'</font> '.$it618_sale_lang['t112'].':<font color=red>'.$it618_sale_sale['it618_count'].'</font></div>
								<div class="title1 text-block" style="height:20px">'.$it618_kddan.'</div>
		
								<div class="price">
									'.$tmpdivstr.'
								</div>
								</div>
							</div>
						</a></dd>';
		}
		
		if($_GET['ac1']=='wapsaleadmin'){
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			
			$it618_statebtn='';$strcontent='';
			if($it618_sale_sale['it618_state']<=2){
				if($it618_sale_sale['it618_state']==1)$it618_statebtn='[<span onclick="delsale('.$it618_sale_sale['id'].');return false;">'.$it618_sale_lang['s509'].'</span>]';
				$it618_kddan='';
				if($it618_sale_sale['it618_kddan']==''){
					$it618_statebtn.=' [<span onclick="fahuo'.$it618_sale_sale['id'].'();return false;">'.$it618_sale_lang['s510'].'</span>]';
				}else{
					$it618_sale_kd=C::t('#it618_sale#it618_sale_kd')->fetch_by_id($it618_sale_sale['it618_kdid']);
					$it618_kddan=$it618_sale_lang['s511'].'<span style="color:green">'.$it618_sale_kd['it618_name'].' '.$it618_sale_sale['it618_kddan'].'</span>';
					$it618_statebtn.=' [<span onclick="fahuo'.$it618_sale_sale['id'].'();return false;">'.$it618_sale_lang['s512'].'</span>]';
				}
				
				$tmp1=str_replace("<option value=".$it618_sale_sale['it618_kdid'],"<option value=".$it618_sale_sale['it618_kdid']." selected=selected",$tmp);
				
				$strcontent='<div class="kd_fahuo">'.$it618_sale_sale['it618_name'].' '.$it618_sale_sale['it618_addr'].' '.$it618_sale_sale['it618_tel'].'<br><br>'.$it618_sale_sale['it618_bz'].'<br><br>'.$it618_sale_lang['s514'].'<select id="it618_kdid" style="margin-top:-1px">'.$tmp1.'</select><input type="text" id="it618_kddan" value="'.$it618_sale_sale['it618_kddan'].'"><input type="hidden" id="saleid" value="'.$it618_sale_sale['id'].'"> <input type="button" class="it618btn" value="'.$it618_sale_lang['s515'].'" onclick="savekd()"> <span style="color:red" id="kdtips"></span><br><br><font color=red>'.$it618_sale_lang['s516'].'</font></div>';
			}
			
			if($it618_sale_sale['it618_state']==4){
				$it618_kddan=$it618_sale_lang['s511'].'<span style="color:green">'.$it618_sale_kd['it618_name'].' '.$it618_sale_sale['it618_kddan'].'</span>';
				$it618_statebtn='[<span onclick="tongyitui('.$it618_sale_sale['id'].');return false;">'.$it618_sale_lang['s517'].'</span>] [<span onclick="jujuetui('.$it618_sale_sale['id'].');return false;">'.$it618_sale_lang['s518'].'</span>]';
			}
			
			$tmpdivstr='<div style="height:15px">'.$it618_statebtn.'<span class="line-right">'.$it618_state.'</span></div>';
			if($it618_sale_sale['it618_state']==3){
				$tmpdivstr='<div style="height:15px"><span class="line-right">'.$it618_state.'</span></div>';
			}
			
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_sale_sale['it618_uid']);
			
			if($it618_kddan!='')$it618_kddan='<div class="title1 text-block" style="height:20px">'.$it618_kddan.'</div>';
			
			$salelist_get.='<dd><a href="'.$waptmpurl.'" class="react">
							<div class="dealcard">
								<div class="dealcard-img"><img src="'.$wapppic.'"/></div>
								<div class="dealcard-block-right">
								<div class="dealcard-sale single-line">'.$wappname.'<span></span></div>
								
								<div class="title text-block" style="height:46px">'.$it618_sale_lang['t109'].':<font color=red>'.$it618_sale_sale['it618_price'].'</font> '.$it618_sale_lang['s125'].' '.$it618_sale_lang['t111'].':<font color=red>'.$it618_sale_sale['it618_score'].'</font> '.$it618_sale_lang['t112'].':<font color=red>'.$it618_sale_sale['it618_count'].'</font><br>'.$username.' '.$it618_sale_sale['it618_tel'].'</div>
								'.$it618_kddan.'
								<div class="price">
									'.$tmpdivstr.'
								</div>
								</div>
							</div>
						</a></dd>';
						
			if($it618_sale_sale['it618_state']<=2){
				$tmpjs.='function fahuo'.$it618_sale_sale['id'].'(){
						var layerobj = {
							title:"'.$it618_sale_lang['s510'].'",
							titlebgcolor:"#f9f9f9",
							content:\'<table width="98%"><tr><td>'.$strcontent.'</td></tr></table>\',
							bottom:"",
							bottomheight:0,
							allcontent:""
						};
						
						showlayer("orderfahuo",layerobj);
					}';
			}
		}
		
		$n=$n+1;
	}

	if($_GET['ac1']=='pcmysale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_sale:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_sale_getlang('s188').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s189').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_sale_getlang('s189').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s188').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s189').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s188').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_sale_getlang('s189').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	$creditnum=DB::result_first("select extcredits".$it618_sale['sale_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
	
	echo it618_sale_getlang('s377')."<font color=red>$count</font> ".$creditname.it618_sale_getlang('s378')."<font color=red>$money</font>"."it618_split".$salelist_get."it618_split".$multipage."<script>$tmpjs</script>it618_split".$it618_sale_lang['s375'].$creditname.$it618_sale_lang['s376']."<font color=green>$creditnum</font>";
	exit;
}


if($_GET['ac']=="moneylist_get"){
	$ppp = 15;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	
	if($uid==0)$uid=-1;
	if($_GET['ac1']=='wapmoney'){	
		$finduid=0;
		$funname='getmoneylist';
	}else{
		$finduid=$uid;
		$funname='getmymoneylist';
	}
	
	$it618_sale_moneys=C::t('#it618_sale#it618_sale_money')->fetch_all_by_search($it618sql,'it618_time2 desc',it618_sale_utftogbk($_GET['pname']),$finduid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
	$count=C::t('#it618_sale#it618_sale_money')->count_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$finduid, $_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_sale#it618_sale_money')->sum_score_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$finduid, $_GET['it618_time1'], $_GET['it618_time2']);
	$flmoney=C::t('#it618_sale#it618_sale_money')->sum_flmoney_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$finduid, $_GET['it618_time1'], $_GET['it618_time2']);
	$money=C::t('#it618_sale#it618_sale_money')->sum_money_by_search($it618sql,'',it618_sale_utftogbk($_GET['pname']),$finduid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($flmoney>0){
		$flsumstr='<font color=red>'.$flmoney.'</font> '.$it618_sale_lang['s125'].' ';
	}
	if($score>0){
		$flsumstr.='<font color=green>'.$score.'</font> '.$creditname;
	}
	
	$n=0;
	foreach($it618_sale_moneys as $it618_sale_money) {
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		if($it618_sale_money['it618_fltype']==1){
			$it618_fl='<font color=green>'.$it618_sale_money['it618_score'].'</font>'.$creditname;
		}else{
			$it618_fl='<font color=red>'.$it618_sale_money['it618_flmoney'].'</font> '.$it618_sale_lang['s125'];
		}
		
		if($_GET['ac1']=='pcmymoney'){
			$moneylist_get.='<tr class="hover">
						<td>'.$it618_sale_money['it618_saleid'].'</td>
						<td>'.$it618_sale_money['it618_pname'].'</td>
						<td>'.$it618_sale_money['it618_count'].'</td>
						<td>'.date('Y-m-d H:i:s', $it618_sale_money['it618_time1']).'</td>
						<td><font color=red>'.$it618_sale_money['it618_money'].'</font> '.$it618_sale_lang['s125'].'</td>
						<td>'.date('Y-m-d H:i:s', $it618_sale_money['it618_time2']).'</td>
						<td>'.$it618_fl.'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmoney'){
			if($it618_sale_money['it618_uid']>0){
				$it618_saleid='<font color=#390>'.$it618_sale_money['it618_saleid'].'</font>';
				
				$username=it618_sale_getusername($it618_sale_money['it618_uid']);
				$username=cutstr($username, 2, '').'***';
				$username='<font color=#999>'.$it618_sale_lang['s438'].'</font><font color=#390>'.$username.'</font>';
				
				$it618_score=$it618_fl;
			}else{
				$it618_saleid=$it618_sale_money['it618_saleid'];
				$it618_saleid=substr($it618_saleid, 1, 5).'***'.substr($it618_saleid, 10, strlen($it618_saleid)-10);
				$it618_saleid='<font color=#F60>'.$it618_saleid.'</font>';
				
				$username='';
				
				$it618_score='<font color=#999>'.$it618_sale_lang['s439'].'</font><font color=#F60>'.$it618_sale_lang['s440'].'</font>';
			}

			$moneylist_get.='
						<tr>
						<td colspan="4" class="tdhr"></td>
						</tr>
						<tr>
						<td colspan="4" class="tdname">'.$it618_sale_money['it618_pname'].'</td>
						</tr>
						<tr>
						<td colspan="2" width="50%"><font color=#999>'.$it618_sale_lang['s560'].'</font><font color=#F60>'.$it618_saleid.'</font></td>
						<td colspan="2" width="50%">'.$username.'</td>
						</tr>
						<tr>
						<td colspan="2" width="50%"><font color=#999>'.$it618_sale_lang['s562'].'</font><font color=red>'.$it618_sale_money['it618_money'].'</font> '.$it618_sale_lang['s125'].'</td>
						<td colspan="2" width="50%"><font color=#999>'.$it618_sale_lang['s563'].'</font>'.$it618_score.'</td>
						</tr>
						<tr>
						<td colspan="2" style="padding-bottom:10px"><font color=#999>'.$it618_sale_lang['s564'].date('Y-m-d H:i:s', $it618_sale_money['it618_time1']).'</font></td>
						<td colspan="2" style="padding-bottom:10px"><font color=#999>'.$it618_sale_lang['s565'].date('Y-m-d H:i:s', $it618_sale_money['it618_time2']).'</font></td>
						</tr>
						';
		}
		
		if($_GET['ac1']=='wapmymoney'){			
			$moneylist_get.='
						<tr>
						<td colspan="4" class="tdhr"></td>
						</tr>
						<tr>
						<td colspan="4" class="tdname">'.$it618_sale_money['it618_pname'].'</td>
						</tr>
						<tr>
						<td colspan="2" width="50%"><font color=#999>'.$it618_sale_lang['s560'].'</font><font color=#F60>'.$it618_sale_money['it618_saleid'].'</font></td>
						<td colspan="2" width="50%"><font color=#999>'.$it618_sale_lang['s561'].'</font><font color=red>'.$it618_sale_money['it618_count'].'</font></td>
						</tr>
						<tr>
						<td colspan="2" width="50%"><font color=#999>'.$it618_sale_lang['s562'].'</font><font color=red>'.$it618_sale_money['it618_money'].'</font> '.$it618_sale_lang['s125'].'</td>
						<td colspan="2" width="50%"><font color=#999>'.$it618_sale_lang['s563'].'</font>'.$it618_fl.'</td>
						</tr>
						<tr>
						<td colspan="2" style="padding-bottom:10px"><font color=#999>'.$it618_sale_lang['s564'].date('Y-m-d H:i:s', $it618_sale_money['it618_time1']).'</font></td>
						<td colspan="2" style="padding-bottom:10px"><font color=#999>'.$it618_sale_lang['s565'].date('Y-m-d H:i:s', $it618_sale_money['it618_time2']).'</font></td>
						</tr>
						';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmymoney'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_sale:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_sale_getlang('s188').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s189').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_sale_getlang('s189').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s188').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s189').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_sale_getlang('s188').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_sale_getlang('s189').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_sale_getlang('s377')."<font color=red>$count</font> ".it618_sale_getlang('s544')."<font color=red>$money</font> ".$it618_sale_lang['s125'].' '.it618_sale_getlang('s563')."$flsumstr it618_split".$moneylist_get."it618_split".$multipage;
	exit;
}


if($_GET['ac']=="findmoney"){
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	if($it618_sale['sale_isfl']==0){
		echo $it618_sale_lang['s603'];
	}
	if($uid>0){
		if($it618_sale_money=C::t('#it618_sale#it618_sale_money')->fetch_by_saleid($_GET['saleid'])){
			if($it618_sale_money['it618_uid']>0){
				echo $it618_sale_lang['s551'];exit;
			}else{
				
				if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
				if($it618_sale['sale_isfl']==1){
					$it618_fl=intval($it618_sale_money['it618_salemoney']*$it618_sale['sale_moneybl']/100);
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$it618_sale['sale_credit'] => $it618_fl)
					);
					
					DB::query("update ".DB::table('it618_sale_money')." set it618_fltype=1, it618_uid=".$uid.",it618_score=".$it618_fl." where id=".$it618_sale_money['id']);
					
					echo 'okit618_split'.$it618_sale_lang['s548'].$it618_fl.$creditname.$it618_sale_lang['s549'];exit;
				}else{
					if($IsCredits!=1){
						echo $it618_sale_lang['s607'];exit;
					}
					
					$it618_fl=round($it618_sale_money['it618_salemoney']*$it618_sale['sale_moneybl']/100,2);
					
					$it618_bz=$it618_sale_lang['s606'];
					$it618_bz=str_replace("{money}",$it618_fl,$it618_bz);
					$it618_bz=str_replace("{saleid}",$it618_sale_money['id'],$it618_bz);
					
					require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
					savemoney(array(
						'it618_uid' => $uid,
						'it618_type' => 'zy',
						'it618_money1' => $it618_fl,
						'it618_bz' => $it618_bz,
						'it618_zytype' => 'it618_sale_fl',
						'it618_zyid' => $it618_sale_money['id'],
						'it618_time' => $_G['timestamp']
					));
					
					DB::query("update ".DB::table('it618_sale_money')." set it618_fltype=2, it618_uid=".$uid.",it618_flmoney=".$it618_fl." where id=".$it618_sale_money['id']);
					
					if($it618_fl>0){
						if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
							require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
						}
						
						if($union_sale_isok==1&&$it618_fl>=$union_sale_money){
							require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
							Union_SaleTC('it618_sale_fl',$it618_fl,$it618_sale_money['id'],$uid);
						}
					}
					
					echo 'okit618_split'.$it618_sale_lang['s548'].$it618_fl.$it618_sale_lang['s125'].$it618_sale_lang['s549'];exit;
				}
			}
		}else{
			echo $it618_sale_lang['s550'];
		}
	}else{
		echo $it618_sale_lang['s547'];
	}
	exit;
}


if($_GET['ac']=="delsaleadmin"){
	$it618_sale_sale=C::t('#it618_sale#it618_sale_sale')->fetch_by_id($_GET['saleid']);
	$sale_saleuids=explode(",",$it618_sale['sale_saleuids']);
	if(!in_array($uid, $sale_saleuids)||$it618_sale_sale['it618_state']>1){
		echo 'it618_split'.it618_sale_getlang('s504');exit;
	}
	
	C::t('#it618_sale#it618_sale_sale')->delete_by_id($_GET['saleid']);
	C::t('common_member_count')->increase($it618_sale_sale['it618_uid'], array(
		'extcredits'.$it618_sale['sale_credit'] => ($it618_sale_sale['it618_count']*$it618_sale_sale['it618_score']))
	);
	DB::query("update ".DB::table('it618_sale_goods')." set it618_salecount=it618_salecount-".$it618_sale_sale['it618_count']." where id=".$it618_sale_sale['it618_pid']);
	
	echo 'okit618_split'.it618_sale_getlang('s506');exit;

}


if($_GET['ac']=="tongyitui"){
	$it618_sale_sale=C::t('#it618_sale#it618_sale_sale')->fetch_by_id($_GET['saleid']);
	$sale_saleuids=explode(",",$it618_sale['sale_saleuids']);
	if(!in_array($uid, $sale_saleuids)||$it618_sale_sale['it618_state']!=4){
		echo 'it618_split'.it618_sale_getlang('s504');exit;
	}
	
	C::t('#it618_sale#it618_sale_sale')->update($_GET['saleid'],array(
		'it618_state' => 5
	));
	C::t('common_member_count')->increase($it618_sale_sale['it618_uid'], array(
		'extcredits'.$it618_sale['sale_credit'] => ($it618_sale_sale['it618_count']*$it618_sale_sale['it618_score']))
	);
	DB::query("update ".DB::table('it618_sale_goods')." set it618_salecount=it618_salecount-".$it618_sale_sale['it618_count']." where id=".$it618_sale_sale['it618_pid']);
	
	it618_sale_sendmessage('salestate_user',$it618_sale_sale['id'],'tongyitui');
	
	echo 'okit618_split'.it618_sale_getlang('s507');exit;

}


if($_GET['ac']=="jujuetui"){
	$it618_sale_sale=C::t('#it618_sale#it618_sale_sale')->fetch_by_id($_GET['saleid']);
	$sale_saleuids=explode(",",$it618_sale['sale_saleuids']);
	if(!in_array($uid, $sale_saleuids)||$it618_sale_sale['it618_state']!=4){
		echo 'it618_split'.it618_sale_getlang('s504');exit;
	}
	
	C::t('#it618_sale#it618_sale_sale')->update($_GET['saleid'],array(
		'it618_state' => 6
	));
	
	it618_sale_sendmessage('salestate_user',$it618_sale_sale['id'],'jujuetui');
	
	echo 'okit618_split'.it618_sale_getlang('s508');exit;

}


if($_GET['ac']=="savekd"){
	$it618_sale_sale=C::t('#it618_sale#it618_sale_sale')->fetch_by_id($_GET['saleid']);
	$sale_saleuids=explode(",",$it618_sale['sale_saleuids']);
	if(!in_array($uid, $sale_saleuids)||$it618_sale_sale['it618_state']>2){
		echo 'it618_split'.it618_sale_getlang('s504');exit;
	}
	
	C::t('#it618_sale#it618_sale_sale')->update($_GET['saleid'],array(
		'it618_state' => 2,
		'it618_kdid' => $_GET['it618_kdid'],
		'it618_kddan' => $_GET['it618_kddan']
	));
	
	it618_sale_sendmessage('salestate_user',$it618_sale_sale['id'],'fahuo');
	
	echo 'okit618_split'.it618_sale_getlang('s505');exit;

}


if($_GET['ac']=="goodslist_get"){
	$ppp = $it618_sale['sale_wappcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	
	$orderby='UNIX_TIMESTAMP(it618_quantime2)-'.$_G['timestamp'].',id desc';
	if($_GET['it618_order']==1)$orderby='UNIX_TIMESTAMP(it618_quantime2)-'.$_G['timestamp'].',id desc';
	if($_GET['it618_order']==2)$orderby='it618_saleprice desc';
	if($_GET['it618_order']==3)$orderby='it618_saleprice';
	if($_GET['it618_order']==4)$orderby='it618_collect desc';
	if($_GET['it618_order']==5)$orderby='it618_collect';
	if($_GET['it618_order']==6)$orderby='it618_views desc';
	if($_GET['it618_order']==7)$orderby='it618_views';
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	$listcount = C::t('#it618_sale#it618_sale_goods')->count_by_search("it618_state=1 and (it618_actime1='' or (it618_actime1!='' and UNIX_TIMESTAMP(it618_actime1)<=".$_G['timestamp']."))",'',$_GET['it618_class1'],$_GET['it618_class2'],it618_sale_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2']);
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')exit;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax".$urlsql.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value,\'\')">'.$curpage.'</select>';
		if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_sale_getlang('s188').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax".$urlsql.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_sale_getlang('s189').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_sale_getlang('s189').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_sale_getlang('s188').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax".$urlsql.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_sale_getlang('s189').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_sale:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_sale_getlang('s188').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_sale_getlang('s189').'</a>';
		}
	}
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	$tdn=1;
	foreach(C::t('#it618_sale#it618_sale_goods')->fetch_all_by_search(
		"it618_state=1 and (it618_actime1='' or (it618_actime1!='' and UNIX_TIMESTAMP(it618_actime1)<=".$_G['timestamp']."))",$orderby,$_GET['it618_class1'],$_GET['it618_class2'],it618_sale_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2'],$startlimit,$ppp
	) as $it618_sale_goods) {
		
		$it618_price1='<span>&yen;'.$it618_sale_goods['it618_saleprice'].'</span>';
		$it618_price2='';
		if($it618_sale_goods['it618_price']>0)$it618_price2='&yen;<del>&yen;'.$it618_sale_goods['it618_price'].'</del>';
		
		$it618_quanstr='';
		if($it618_sale_goods['it618_quantime1']!=''){
			$it618_quanstr='<div class="divquan">'.$it618_sale_goods['it618_quanstr'].'</div>';
			$quanstr=$it618_sale_goods['it618_quanstr'];
			
			$it618_price1='<span>&yen;'.it618_getquanprice($it618_sale_goods['it618_saleprice'],$quanstr).' <font style="font-weight:normal;font-size:11px">'.$it618_sale_lang['s299'].'</font></span>';
			$it618_price2='<del>&yen;'.$it618_sale_goods['it618_saleprice'].'</del>';
		}
		
		$tmpurl=it618_sale_getrewrite('sale_wap','product@'.$it618_sale_goods['id'],'plugin.php?id=it618_sale:wap&pagetype=product&cid1='.$it618_sale_goods['id']);
		$tmparr=explode("taobao.com",$it618_sale_goods['it618_pcurl']);
		if($iswx==1&&count($tmparr)>1&&it618_getgoodsisurl($it618_sale_goods)==1){
			$tmpurl='href="javascript:" onclick="showwx('.$it618_sale_goods['id'].')"';
		}else{
			$tmpurl='href="'.$tmpurl.'"';
		}
		
		if($salestyle=='1'){
			$strlist.='<tr>
							<td class="tdleft">'.$it618_quanstr.'<a '.$tmpurl.'><img class="lazy" data-original="'.$it618_sale_goods['it618_pic'].'"/></a></td>
							<td class="tdright"><a '.$tmpurl.'>
								<div class="tdname">'.$it618_sale_goods['it618_name'].'</div>
								<div class="tddes">'.it618_getjfblcount($it618_sale_goods).'</div>
								<div class="tdprice">
								  <strong>'.$it618_price1.'</strong>
								  <del>'.$it618_price2.'</del>
								</div></a>
							</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				$trtmpstr1='<tr class="trimg">';
				$trtmpstr2='<tr class="trabout">';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr1.='<td '.$tdstr.'>'.$it618_quanstr.'<a '.$tmpurl.'>
							<img class="lazy" data-original="'.$it618_sale_goods['it618_pic'].'"/>
						</a></td>';
			
			$trtmpstr2.='<td '.$tdstr.'><a '.$tmpurl.'>
							<div class="tdname">'.$it618_sale_goods['it618_name'].'</div>
							<div class="tddes">'.it618_getjfblcount($it618_sale_goods).'</div>
							<div class="tdprice"><strong>'.$it618_price1.' </strong> '.$it618_price2.'</div>
						</a></td>';
						
			if($tdn%2==0){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$strlist.=$trtmpstr1.$trtmpstr2;
			}
			
			$tdn=$tdn+1;
		}
	}
	
	if($salestyle=='1'){
		$tmparr=explode('</tr>',$strlist);
		if(count($tmparr)>1){
			$strlist=$strlist.'@@@';
			$strlist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$strlist);
		}
	}else{
		$trtmpstr=$trtmpstr1.'@@@';
		$tmparr=explode('</td>@@@',$trtmpstr);
		if(count($tmparr)>1){
			$trtmpstr1.='</tr>';
			$trtmpstr2.='</tr>';
			$strlist.=$trtmpstr1.$trtmpstr2;
		}
	}
	
	$classname=$it618_sale_lang['s670'];
	if($_GET['it618_class1']>0){
		$classname=C::t('#it618_sale#it618_sale_class1')->fetch_it618_name_by_id($_GET['it618_class1']);
	}
	if($_GET['it618_class2']>0){
		$classname=C::t('#it618_sale#it618_sale_class2')->fetch_it618_name_by_id($_GET['it618_class2']);
	}
	
	$ordername=$it618_sale_lang['t63'];
	if($_GET['it618_order']==2)$ordername=$it618_sale_lang['t64'].'<img src="source/plugin/it618_sale/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==3)$ordername=$it618_sale_lang['t64'].'<img src="source/plugin/it618_sale/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==4)$ordername=$it618_sale_lang['t65'].'<img src="source/plugin/it618_sale/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==5)$ordername=$it618_sale_lang['t65'].'<img src="source/plugin/it618_sale/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==6)$ordername=$it618_sale_lang['t66'].'<img src="source/plugin/it618_sale/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==7)$ordername=$it618_sale_lang['t66'].'<img src="source/plugin/it618_sale/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	
	$pricename=$_GET['it618_price1'].'-'.$_GET['it618_price2'].$it618_sale_lang['s125'];
	if($_GET['it618_price1']=='0'&&$_GET['it618_price2']=='0')$pricename=$it618_sale_lang['t53'].$it618_sale_lang['t26'];
	if($_GET['it618_price1']>0&&$_GET['it618_price2']=='0')$pricename=$_GET['it618_price1'].$it618_sale_lang['s172'];
	if($_GET['it618_price1']=='0'&&$_GET['it618_price2']>0)$pricename=$_GET['it618_price2'].$it618_sale_lang['s171'];
	
	if($_GET['it618_name']=='')$it618_name=$it618_sale_lang['s671'];else $it618_name=it618_sale_utftogbk($_GET['it618_name']);
	
	$sqlbq='<tr><td class="bq1" id="td1" onClick="getbq1(this)">'.$classname.'<img src="source/plugin/it618_sale/wap/images/arw_b.gif" style="margin-top:-2px"></td><td class="bq2" id="td2" onClick="getbq2(this)">'.$pricename.'<img src="source/plugin/it618_sale/wap/images/arw_b.gif" style="margin-top:-2px"></td><td class="bq3" id="td3" onClick="getbq3(this)">'.$ordername.'<img src="source/plugin/it618_sale/wap/images/arw_b.gif" style="margin-top:-2px"></td><td class="bq4" id="td4"><input type="text" id="searchli_txt1" value="'.$it618_name.'" readonly onClick="getname()"></td></tr>';
	
	if($uid>0&&isset($_GET['findkey'])&&$_GET['it618_name']!=''){
		if($it618_sale_findkey=C::t('#it618_sale#it618_sale_findkey')->fetch_by_uid_key($uid,it618_sale_utftogbk($_GET['it618_name']))){
			C::t('#it618_sale#it618_sale_findkey')->update($it618_sale_findkey['id'],array(
				'it618_count' => ($it618_sale_findkey['it618_count']+1),
				'it618_time' => $_G['timestamp']
			));
		}else{
			C::t('#it618_sale#it618_sale_findkey')->insert(array(
				'it618_uid' => $uid,
				'it618_key' => it618_sale_utftogbk($_GET['it618_name']),
				'it618_count' => 1,
				'it618_time' => $_G['timestamp']
			), true);
		}
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext.' '.it618_sale_getlang('s194').$listcount."it618_split".$sqlbq;
	exit;
}


if($_GET['ac']=="getfindkey"){
	if($uid>0){
		foreach(C::t('#it618_sale#it618_sale_findkey')->fetch_all_by_uid($uid) as $it618_tmp) {	
			$getfindkey.='<tr><td><a href="javascript:" onClick="delfindkey('.$it618_tmp['id'].',\''.$it618_tmp['it618_key'].'\')" style="float:right">'.$it618_sale_lang['s558'].'</a><span onClick="findbykey(\''.$it618_tmp['it618_key'].'\')">'.$it618_tmp['it618_key'].'</span></td></tr>';
		}
	}else{
		$getfindkey='<tr><td>'.$it618_sale_lang['s696'].'</td></tr>';
	}
	echo $getfindkey;
}


if($_GET['ac']=="delfindkey"){
	if($uid>0){
		C::t('#it618_sale#it618_sale_findkey')->delete_by_uid_id($uid,$_GET['fid']);
	}
}


if($_GET['ac']=="clearfindkey"){
	if($uid>0){
		C::t('#it618_sale#it618_sale_findkey')->delete_by_uid($uid);
	}
}

$n=1;
if($_GET['ac']=="getproductclass"){
	if(lang('plugin/it618_sale', $it618_sale_lang['it618'])!=$it618_sale_lang['version'])exit;
	$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productclass2\',0,0)" name="productclass2"><span>'.$it618_sale_lang['t53'].'</span><i></i></a>';
	foreach(C::t('#it618_sale#it618_sale_class2')->fetch_all_by_it618_class1_id($_GET['cid']) as $it618_tmp) {	
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass2\','.$n.','.$it618_tmp['id'].')" name="productclass2"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $classtmp;
	exit;
}


if($_GET['ac']=="salestyle"){
	$salestyle=getcookie('salestyle');
	if($salestyle==''){
		if($it618_sale['sale_style']==3)$salestyle='1';else $salestyle='2';
	}
	if($salestyle=='1')$salestyle='2';else $salestyle='1';
	dsetcookie('salestyle',$salestyle,31536000);
	echo 'ok';exit;
}
//From: d'.'is'.'m.ta'.'obao.com
?>