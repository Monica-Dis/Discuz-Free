<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_sale_lang;

function it618_sale_getlang($langid){
	global $it618_sale_lang;
	return $it618_sale_lang[$langid];
}

$it618_sale_lang['version']='v5.5.9';
$it618_sale_lang['s1'] = '热门类别与商品';
$it618_sale_lang['s2'] = '电脑版底部信息';
$it618_sale_lang['s3'] = '顶部全局轮播';
$it618_sale_lang['s4'] = '首页右上轮播';
$it618_sale_lang['s5'] = '首页右下轮播';
$it618_sale_lang['s6'] = '列表页右下轮播';
$it618_sale_lang['s7'] = '类别与商品设置';
$it618_sale_lang['s8'] = '伪静态设置';
$it618_sale_lang['s9'] = '手工添加商品';
$it618_sale_lang['s10'] = '商品管理';
$it618_sale_lang['s11'] = '采集精选物料商品';
$it618_sale_lang['s12'] = '淘宝客API的appkey：';
$it618_sale_lang['s13'] = '淘宝客API的secretkey：';
$it618_sale_lang['s14'] = '一级商品类别';
$it618_sale_lang['s15'] = '二级商品类别';
$it618_sale_lang['s16'] = '更新成功！';
$it618_sale_lang['s17'] = '首页热门分类编号：';
$it618_sale_lang['s18'] = '商品分类：';
$it618_sale_lang['s19'] = '请选择商品一级分类';
$it618_sale_lang['s20'] = '请选择商品二级分类';
$it618_sale_lang['s21'] = '：';
$it618_sale_lang['s22'] = '联盟广告位adzoneid：';
$it618_sale_lang['s23'] = '更新';
$it618_sale_lang['s24'] = '直接跳转';
$it618_sale_lang['s25'] = '查找';
$it618_sale_lang['s26'] = '淘宝客API接口设置';
$it618_sale_lang['s27'] = 'API关键字搜索权限会员ID：';
$it618_sale_lang['s28'] = '提示：如果会员有权限，可以在电脑版手机版用关键字搜索商品时，自动用这个关键字在淘宝客API采集，采集需要占用几秒的时间，所用时间和本插件商品数量成正比
<font color=red>注意：如果此设置为空时，表示没有此功能</font>，如果后台没有匹配类目，此功能无效的，此功能推荐管理员用，多个会员ID可以用逗号,隔开';
$it618_sale_lang['s29'] = '文字颜色(无突出效果时要为空)';
$it618_sale_lang['s30'] = '提示：mm_xxx1_xxx2_<font color=red>xxx3</font>的xxx3部分内容';
$it618_sale_lang['s31'] = '复制口令';
$it618_sale_lang['s32'] = '商品数';
$it618_sale_lang['s33'] = '更新成功！(成功修改数:';
$it618_sale_lang['s34'] = '成功添加数:';
$it618_sale_lang['s35'] = '成功删除数:';
$it618_sale_lang['s36'] = '知道了';
$it618_sale_lang['s37'] = '！';
$it618_sale_lang['s38'] = '警告：以下内容有的需要结合编辑器的代码模式(<font color=blue>代码模式/内容模式 通过编辑器的第一个功能图标切换</font>)修改，如果你对代码不了解修改前请一定对内容进行备份！';
$it618_sale_lang['s39'] = '自动采集页数：';
$it618_sale_lang['s40'] = '手机版底部信息';
$it618_sale_lang['s41'] = '商品一级分类管理';
$it618_sale_lang['s42'] = '按类别名称';
$it618_sale_lang['s43'] = '商品类别数：';
$it618_sale_lang['s44'] = '提示：类别简称用于首页右侧的类别快捷导航，类别简称2个字表示类别';
$it618_sale_lang['s45'] = '类别名称';
$it618_sale_lang['s46'] = '简称';
$it618_sale_lang['s47'] = '商品图片：';
$it618_sale_lang['s48'] = '选择图片';
$it618_sale_lang['s49'] = '首页电脑/手机商品数/首页显示排序';
$it618_sale_lang['s50'] = '类别排序';
$it618_sale_lang['s51'] = '在';
$it618_sale_lang['s52'] = '提示：如果分类设置了首页电脑/手机商品数，就会在电脑版手机版首页显示，还可以设置显示排序';
$it618_sale_lang['s53'] = '子类别数';
$it618_sale_lang['s54'] = '商品数';
$it618_sale_lang['s55'] = '商品二级分类管理';
$it618_sale_lang['s56'] = '编号';
$it618_sale_lang['s57'] = '类别1';
$it618_sale_lang['s58'] = '类别2名称';
$it618_sale_lang['s59'] = '推荐';
$it618_sale_lang['s60'] = '宽:';
$it618_sale_lang['s61'] = '高:';
$it618_sale_lang['s62'] = '轮播广告数：';
$it618_sale_lang['s63'] = '注意：排序值为0时表示图片不显示，数值越小越在前';
$it618_sale_lang['s64'] = '图片';
$it618_sale_lang['s65'] = '图片链接(为空时图片不带链接)';
$it618_sale_lang['s66'] = '排序';
$it618_sale_lang['s67'] = '上传图片';
$it618_sale_lang['s68'] = '提交后再上传图片';
$it618_sale_lang['s69'] = '注意：以下分类与商品编号，多个时请用逗号隔开(如：1,2,3,4,5)，并且设置顺序就是显示顺序';
$it618_sale_lang['s70'] = '确定要下架选中商品？';
$it618_sale_lang['s71'] = '搜索页热门分类编号：';
$it618_sale_lang['s72'] = '首页热门商品编号：';
$it618_sale_lang['s73'] = '成功删除数：';
$it618_sale_lang['s74'] = '成功上架商品数：';
$it618_sale_lang['s75'] = '成功下架商品数：';
$it618_sale_lang['s76'] = '淘宝客自动采集设置';
$it618_sale_lang['s77'] = '删除选中订单';
$it618_sale_lang['s78'] = '下架';
$it618_sale_lang['s79'] = '上架';
$it618_sale_lang['s80'] = '商品名称/销售价/市场价';
$it618_sale_lang['s81'] = '商品类别/限量兑换';
$it618_sale_lang['s82'] = '推荐理由/跳转链接/淘口令(如已有不再动态获取)';
$it618_sale_lang['s83'] = '导购时间/优惠券';
$it618_sale_lang['s84'] = '佣金比率：';
$it618_sale_lang['s85'] = '状态';
$it618_sale_lang['s86'] = '排序';
$it618_sale_lang['s87'] = '编辑';
$it618_sale_lang['s88'] = '删除选中商品';
$it618_sale_lang['s89'] = '确定要删除选中商品？此操作不可逆。';
$it618_sale_lang['s90'] = '成功修改商品数：';
$it618_sale_lang['s91'] = '修改以上商品';
$it618_sale_lang['s92'] = '上架选中商品';
$it618_sale_lang['s93'] = '确定要上架选中商品？';
$it618_sale_lang['s94'] = '下架选中商品';
$it618_sale_lang['s95'] = '所有分类';
$it618_sale_lang['s96'] = '商品管理';
$it618_sale_lang['s97'] = '按关键词';
$it618_sale_lang['s98'] = '销售价';
$it618_sale_lang['s99'] = '商品分类';
$it618_sale_lang['s100'] = '所有分类';
$it618_sale_lang['s101'] = '状态';
$it618_sale_lang['s102'] = '所有';
$it618_sale_lang['s103'] = '抱歉，请先设置好淘宝客API接口设置！';
$it618_sale_lang['s104'] = '商品名称：';
$it618_sale_lang['s105'] = '商品销售价：';
$it618_sale_lang['s106'] = '所有服务';
$it618_sale_lang['s107'] = '随时退';
$it618_sale_lang['s108'] = '过期退';
$it618_sale_lang['s109'] = '免预约';
$it618_sale_lang['s110'] = '按排序值排序';
$it618_sale_lang['s111'] = '按销售量排序';
$it618_sale_lang['s112'] = '按人气值排序';
$it618_sale_lang['s113'] = '按销售价排序';
$it618_sale_lang['s114'] = '商品数：';
$it618_sale_lang['s115'] = '商品名称';
$it618_sale_lang['s116'] = '销售价/市场价';
$it618_sale_lang['s117'] = '有效时间';
$it618_sale_lang['s118'] = '人气';
$it618_sale_lang['s119'] = '销售量';
$it618_sale_lang['s120'] = '销售额';
$it618_sale_lang['s121'] = '商品添加成功！';
$it618_sale_lang['s122'] = '状态';
$it618_sale_lang['s123'] = '排序';
$it618_sale_lang['s124'] = '请选择商品分类！';
$it618_sale_lang['s125'] = '元';
$it618_sale_lang['s126'] = '推荐理由：';
$it618_sale_lang['s127'] = '请输入商品名称！';
$it618_sale_lang['s128'] = '请输入商品销售价！';
$it618_sale_lang['s129'] = '全选';
$it618_sale_lang['s130'] = '修改以上排序';
$it618_sale_lang['s131'] = '请输入商品市场价！';
$it618_sale_lang['s132'] = '商品销售价要小于市场价！';
$it618_sale_lang['s133'] = '请上传商品图片！';
$it618_sale_lang['s134'] = '商品市场价：';
$it618_sale_lang['s135'] = '推荐尺寸:275*175';
$it618_sale_lang['s136'] = 'URL 静态化可以提高搜索引擎抓取，开启本功能需要对 Web 服务器增加相应的 Rewrite 支持，且会轻微增加服务器负担。同时您还可以调整每个页面的静态格式，但不得删除其中的标记，重置静态格式请留空。<br><font color=red>注意，修改静态格式后您需要修改服务器的 Rewrite 规则设置，并且要把DZ默认的插件规则删除或放最后一行，此插件规则才有效果</font>';
$it618_sale_lang['s137'] = '静态格式扩展名：';
$it618_sale_lang['s138'] = '页面';
$it618_sale_lang['s139'] = '标记';
$it618_sale_lang['s140'] = '格式';
$it618_sale_lang['s141'] = '导购首页';
$it618_sale_lang['s142'] = '导购商品列表页';
$it618_sale_lang['s143'] = '导购商品查找页';
$it618_sale_lang['s144'] = '导购商品页';
$it618_sale_lang['s145'] = '9';
$it618_sale_lang['s146'] = '导购商品管理页';
$it618_sale_lang['s147'] = '导购手机版页';
$it618_sale_lang['s148'] = 'Apache Web Server(独立主机用户)';
$it618_sale_lang['s149'] = 'Apache Web Server(虚拟主机用户)';
$it618_sale_lang['s150'] = '# 将 RewriteEngine 模式打开
RewriteEngine On

# 修改以下语句中的 /discuz 为您的论坛目录地址，如果程序放在根目录中，请将 /discuz 修改为 /
RewriteBase /discuz

# Rewrite 系统规则请勿修改';
$it618_sale_lang['s151'] = 'IIS Web Server(独立主机用户)';
$it618_sale_lang['s152'] = 'IIS7 Web Server(独立主机用户)';
$it618_sale_lang['s153'] = '跳转链接：';
$it618_sale_lang['s154'] = '手机版跳转链接：';
$it618_sale_lang['s155'] = '推荐理由：';
$it618_sale_lang['s156'] = '保存';
$it618_sale_lang['s157'] = '商品编辑成功！';
$it618_sale_lang['s158'] = '风格管理';
$it618_sale_lang['s159'] = '风格数：';
$it618_sale_lang['s160'] = '搜索框、主导航与类别二级菜单颜色';
$it618_sale_lang['s161'] = '主导航当前与鼠标移动颜色';
$it618_sale_lang['s162'] = '默认风格';
$it618_sale_lang['s163'] = '收藏商品';
$it618_sale_lang['s164'] = '取消收藏';
$it618_sale_lang['s165'] = '已被';
$it618_sale_lang['s166'] = '人收藏';
$it618_sale_lang['s167'] = '全部';
$it618_sale_lang['s168'] = '查看更多';
$it618_sale_lang['s169'] = '人气';
$it618_sale_lang['s170'] = '收藏';
$it618_sale_lang['s171'] = '元以下';
$it618_sale_lang['s172'] = '元以上';
$it618_sale_lang['s173'] = '抱歉，您访问的商品不存在！';
$it618_sale_lang['s174'] = '我的导购';
$it618_sale_lang['s175'] = '我的收藏';
$it618_sale_lang['s176'] = '发表新帖';
$it618_sale_lang['s177'] = '帐户设置';
$it618_sale_lang['s178'] = '退出';
$it618_sale_lang['s179'] = '登录';
$it618_sale_lang['s180'] = '注册';
$it618_sale_lang['s181'] = '您已经收藏过此商品！';
$it618_sale_lang['s182'] = '收藏成功！';
$it618_sale_lang['s183'] = '抱歉，只有会员才可以收藏商品，请登录！';
$it618_sale_lang['s184'] = '此商品已经是未收藏状态！';
$it618_sale_lang['s185'] = '取消收藏成功！';
$it618_sale_lang['s186'] = '抱歉，只有会员才可以取消收藏，请登录！';
$it618_sale_lang['s187'] = '取消收藏成功！';
$it618_sale_lang['s188'] = '上一页';
$it618_sale_lang['s189'] = '下一页';
$it618_sale_lang['s190'] = '收藏商品数：';
$it618_sale_lang['s191'] = '全部商品';
$it618_sale_lang['s192'] = '按商品关键词：';
$it618_sale_lang['s193'] = '搜 索';
$it618_sale_lang['s194'] = '商品数:';
$it618_sale_lang['s195'] = '提示：可以直接复制淘宝等网站的商品图片地址';
$it618_sale_lang['s196'] = '提示：一般大网站手机版可以自动跳转，链接同电脑版';
$it618_sale_lang['s197'] = '我要分享';
$it618_sale_lang['s198'] = '分享';
$it618_sale_lang['s199'] = '价格：';
$it618_sale_lang['s200'] = '顶部导航设置';
$it618_sale_lang['s201'] = '首页公告管理';
$it618_sale_lang['s202'] = '电脑版首页轮播';
$it618_sale_lang['s203'] = '公告数：';
$it618_sale_lang['s204'] = '注意：此公告同时也会显示在手机版首页，排序为0时不显示';
$it618_sale_lang['s205'] = '标题';
$it618_sale_lang['s206'] = '链接';
$it618_sale_lang['s207'] = '文字是否粗体';
$it618_sale_lang['s208'] = '排序';
$it618_sale_lang['s209'] = '注意：图片上传后，自动强制压缩图片宽高为640px,280px，请上传前保证图片是这个比例，这样不变形更加美观';
$it618_sale_lang['s210'] = '模块DIY调用';
$it618_sale_lang['s211'] = '分钟';
$it618_sale_lang['s212'] = '模块数量：';
$it618_sale_lang['s213'] = 'DIY调用标识符';
$it618_sale_lang['s214'] = '模块类型';
$it618_sale_lang['s215'] = '模板内容(编辑器右下角可以缩小扩大)';
$it618_sale_lang['s216'] = '记录条数';
$it618_sale_lang['s217'] = '开启JS调用';
$it618_sale_lang['s218'] = '缓存时间';
$it618_sale_lang['s219'] = '最新商品';
$it618_sale_lang['s220'] = '热藏商品';
$it618_sale_lang['s221'] = '自定义内容';
$it618_sale_lang['s222'] = '请复制(CTRL+C)以下内容并添加到 HTML 文件中';
$it618_sale_lang['s223'] = '外部调用';
$it618_sale_lang['s224'] = '提交后编辑模板内容，并且模块类型不可修改';
$it618_sale_lang['s225'] = '默认10条记录';
$it618_sale_lang['s226'] = '默认不开启';
$it618_sale_lang['s227'] = '默认缓存时间为1分钟';
$it618_sale_lang['s228'] = '<strong>编辑器用法：</strong><img src="source/plugin/it618_sale/images/editer.png"/> <font color="red">注意非自定义模块推荐在HTML代码模式下编辑，编辑器全屏功能很方便哦</font><hr />
<strong>通用标签：</strong>[loop]...[/loop] 循环显示内容，{siteurl} 本站的网址外站调用时可到<hr />
<strong>商品标签：</strong>{pname} 商品名称，{pdev} 商品简述，{ppicsrc} 商品图片地址，{puprice} 商品销售价，{pprice} 商品市场价，{pcollect} 商品收藏数，{pviews} 商品人气，{purl} 商品链接，{quan} 商品券信息，{quandiv} 带html标签的商品券信息(&lt;div class="divquan"&gt;...&lt;/div&gt;)
';
$it618_sale_lang['s229'] = '显示';
$it618_sale_lang['s230'] = '点击显示隐藏模块内容编辑器';
$it618_sale_lang['s231'] = '隐藏';
$it618_sale_lang['s232'] = '人气商品';
$it618_sale_lang['s233'] = '手机版图标导航';
$it618_sale_lang['s234'] = '导航数：';
$it618_sale_lang['s235'] = '图标';
$it618_sale_lang['s236'] = '标题';
$it618_sale_lang['s237'] = '链接';
$it618_sale_lang['s238'] = '新窗口';
$it618_sale_lang['s239'] = '文字颜色(无突出效果时要为空)';
$it618_sale_lang['s240'] = '文字粗体';
$it618_sale_lang['s241'] = '排序';
$it618_sale_lang['s242'] = '手机版风格';
$it618_sale_lang['s243'] = '风格数：';
$it618_sale_lang['s244'] = '背景颜色';
$it618_sale_lang['s245'] = '个人中心页头渐变色';
$it618_sale_lang['s246'] = '默认风格';
$it618_sale_lang['s247'] = '主导航设置';
$it618_sale_lang['s248'] = '名称';
$it618_sale_lang['s249'] = '链接';
$it618_sale_lang['s250'] = '名称颜色';
$it618_sale_lang['s251'] = '排序';
$it618_sale_lang['s252'] = '数量：';
$it618_sale_lang['s253'] = '提示：如果以下主导航为空，主导航默认显示商家一级分类，排序值为0时不显示';
$it618_sale_lang['s254'] = '新窗口打开';
$it618_sale_lang['s255'] = '人气排行';
$it618_sale_lang['s256'] = '收藏排行';
$it618_sale_lang['s257'] = '最新商品';
$it618_sale_lang['s258'] = '查看全部商品';
$it618_sale_lang['s259'] = '详细内容：';
$it618_sale_lang['s260'] = 'SEO关键词：';
$it618_sale_lang['s261'] = 'SEO描述：';
$it618_sale_lang['s262'] = '直接跳转';
$it618_sale_lang['s263'] = '电脑版商品参数：';
$it618_sale_lang['s264'] = '手机版商品参数：<br><font color=red>不设置时默认是显示电脑版商品参数</font>';
$it618_sale_lang['s265'] = '提示：如果商品是自己手工添加的或导入的商品没有活动与优惠券时，此商品参数内容显示在商品页价格下面购买按钮上面<br>每次添加商品时修改就行了，<font color=blue>修改时请不要修改结构，可以用编辑器的代码模式修改</font><br><br>';
$it618_sale_lang['s266'] = '导购时间：';
$it618_sale_lang['s267'] = '佣金比率：';
$it618_sale_lang['s268'] = '商品页左下角轮播';
$it618_sale_lang['s269'] = '在线客服设置';
$it618_sale_lang['s270'] = '手机版首页轮播';
$it618_sale_lang['s271'] = '通用EXCEL导入商品';
$it618_sale_lang['s272'] = '<font color=red>注意：</font>如果您没有标准模板，请先下载标准导入模板，录入您的商品数据后，上传模板请不要随便修改标准模板的列顺序，标准模板红色部分的属性内容是必填的，<font color=blue>详情可以查看插件教程</font>';
$it618_sale_lang['s273'] = '编辑商品';
$it618_sale_lang['s274'] = '上传文件';
$it618_sale_lang['s275'] = '注意：导入时会自动识别商品名称与链接，如果数据库已存在，就不导入';
$it618_sale_lang['s276'] = '现在导入';
$it618_sale_lang['s277'] = '<font color=#999 style="font-size:13px">积分兑换商品活动已结束</font>';
$it618_sale_lang['s278'] = '距离开始领券剩余';
$it618_sale_lang['s279'] = '距离结束领券剩余';
$it618_sale_lang['s280'] = '金额兑换比：';
$it618_sale_lang['s281'] = '注意：市场价为0时，就不显示市场价折扣功能';
$it618_sale_lang['s282'] = '抱歉，请先上传正确的导入文件！';
$it618_sale_lang['s283'] = '商品名称重复，可能会重复导入商品！';
$it618_sale_lang['s284'] = '一级商品类别编号';
$it618_sale_lang['s285'] = '不存在！';
$it618_sale_lang['s286'] = '二级商品类别编号';
$it618_sale_lang['s287'] = '商品没有图片链接！';
$it618_sale_lang['s288'] = '商品没有价格！';
$it618_sale_lang['s289'] = '商品没有淘宝客链接！';
$it618_sale_lang['s290'] = '商品导购时间有误！';
$it618_sale_lang['s291'] = '无';
$it618_sale_lang['s292'] = '商品优惠券时间有误！';
$it618_sale_lang['s293'] = '【行';
$it618_sale_lang['s294'] = '】';
$it618_sale_lang['s295'] = '还有以下';
$it618_sale_lang['s296'] = '个商品导入失败：';
$it618_sale_lang['s297'] = '成功添加商品数：';
$it618_sale_lang['s298'] = '每个属性对应的列序号：';
$it618_sale_lang['s299'] = '券后价';
$it618_sale_lang['s300'] = '商品类别：';
$it618_sale_lang['s301'] = '二级类别:';
$it618_sale_lang['s302'] = '淘宝类目管理';
$it618_sale_lang['s303'] = '编号可以在二级商品类别管理查看';
$it618_sale_lang['s304'] = '基本属性：';
$it618_sale_lang['s305'] = '商品id：';
$it618_sale_lang['s306'] = '商品名称：';
$it618_sale_lang['s307'] = '商品主图：';
$it618_sale_lang['s308'] = '商品价格：';
$it618_sale_lang['s309'] = '淘宝客短链接：';
$it618_sale_lang['s310'] = '淘宝客链接：';
$it618_sale_lang['s311'] = '如果有淘宝客短链接，跳转链接优先支持短链接';
$it618_sale_lang['s312'] = '导购属性：';
$it618_sale_lang['s313'] = '佣金比率(%)：';
$it618_sale_lang['s314'] = '导购开始时间：';
$it618_sale_lang['s315'] = '导购结束时间：';
$it618_sale_lang['s316'] = '导购开始时间与导购结束时间列设置为无时，就不导入导购时间数据';
$it618_sale_lang['s317'] = '优惠券属性：';
$it618_sale_lang['s318'] = '优惠券面额：';
$it618_sale_lang['s319'] = '优惠券开始时间：';
$it618_sale_lang['s320'] = '优惠券截止时间：';
$it618_sale_lang['s321'] = '优惠券链接：';
$it618_sale_lang['s322'] = '优惠券面额列设置为无时，就不导入优惠券数据';
$it618_sale_lang['s323'] = '必看教程：';
$it618_sale_lang['s324'] = '注意：优惠券截止时间用于插件设置的“过期自动删除商品”，这样方便自动删除商品';
$it618_sale_lang['s325'] = '入库时获取商品(仅支持有优惠券的商品)的淘宝类目，如果已经手工匹配好类目了，就不需要再获取，会占用时间的';
$it618_sale_lang['s326'] = '上传文件并导入：';
$it618_sale_lang['s327'] = '自动操作：';
$it618_sale_lang['s328'] = '如果商品没活动也没优惠券自动不需要商品页直接跳转';
$it618_sale_lang['s329'] = '自动上架商品';
$it618_sale_lang['s330'] = '确定导入？请确认您的自动操作设置！';
$it618_sale_lang['s331'] = '<b>券已过期</b>';
$it618_sale_lang['s332'] = '在';
$it618_sale_lang['s333'] = '天内只能兑换';
$it618_sale_lang['s334'] = '个';
$it618_sale_lang['s335'] = '提示：插件设置“商品跳转模式”可以设置商品怎么跳转，只有模式一时，商品独立设置的直接跳转有效 <font color=blue>淘口令在点复制口令或微信时点购买时动态获取，采集时不获取，减少资源占用</font>';
$it618_sale_lang['s336'] = '商品名称';
$it618_sale_lang['s337'] = '时价：';
$it618_sale_lang['s338'] = '兑换比：';
$it618_sale_lang['s339'] = '积分价';
$it618_sale_lang['s340'] = '数量';
$it618_sale_lang['s341'] = '全部状态';
$it618_sale_lang['s342'] = '发货地址/留言';
$it618_sale_lang['s343'] = '交易状态/快递单号';
$it618_sale_lang['s344'] = '积分价：';
$it618_sale_lang['s345'] = '兑换会员';
$it618_sale_lang['s346'] = '交易时间';
$it618_sale_lang['s347'] = '待发货';
$it618_sale_lang['s348'] = '已发货';
$it618_sale_lang['s349'] = '申请退货';
$it618_sale_lang['s350'] = '已退货';
$it618_sale_lang['s351'] = '拒绝退货';
$it618_sale_lang['s352'] = '按商品名称';
$it618_sale_lang['s353'] = '积分交易管理';
$it618_sale_lang['s354'] = '删除选中交易';
$it618_sale_lang['s355'] = '确定要删除已选交易，此操作不可逆?\n\n如果勾选了交易，点删除时会删除交易，并且积分会返还给买家，同时与交易相关的记录也会清除';
$it618_sale_lang['s356'] = '设置选中交易为已发货';
$it618_sale_lang['s357'] = '确定要设置已选交易为已发货，此操作不可逆？';
$it618_sale_lang['s358'] = '修改以上交易快递信息';
$it618_sale_lang['s359'] = '选择快递';
$it618_sale_lang['s360'] = '设置选中交易为已退货';
$it618_sale_lang['s361'] = '确定要设置已选交易为已退货，此操作不可逆？';
$it618_sale_lang['s362'] = '设置选中交易为拒绝退货';
$it618_sale_lang['s363'] = '确定要设置已选交易为拒绝退货，此操作不可逆？';
$it618_sale_lang['s364'] = '导出已查询的交易到csv文件';
$it618_sale_lang['s365'] = '提示：只有交易状态为(<font color=red>待发货</font>)是可删除(数据可以还原未兑换的状态)交易的，<font color=red>待发货</font>->(<font color=red>已发货</font>)，<font color=red>已发货</font>-><font color=red>申请退货</font>，<font color=red>申请退货</font>->(<font color=red>已退货</font>、<font color=red>拒绝退货</font>)';
$it618_sale_lang['s366'] = '导出成功，';
$it618_sale_lang['s367'] = '请点此链接下载CSV文件！';
$it618_sale_lang['s368'] = '商品名称,积分价格,数量,收货姓名,手机号码,收货地址,交易留言,交易时间';
$it618_sale_lang['s369'] = '拒绝退货数：';
$it618_sale_lang['s370'] = '已退货数：';
$it618_sale_lang['s371'] = '成功设置快递信息数：';
$it618_sale_lang['s372'] = '成功已发货数：';
$it618_sale_lang['s373'] = '成功删除数：';
$it618_sale_lang['s374'] = '，删除的交易数据已成功还原！';
$it618_sale_lang['s375'] = '我的';
$it618_sale_lang['s376'] = '：';
$it618_sale_lang['s377'] = '订单数：';
$it618_sale_lang['s378'] = '数：';
$it618_sale_lang['s379'] = '交易时间';
$it618_sale_lang['s380'] = '提示：交易状态为已发货时，如果不申请退货，过';
$it618_sale_lang['s381'] = '天后交易状态自动变成确认收货';
$it618_sale_lang['s382'] = '抱歉，请先登录！';
$it618_sale_lang['s383'] = '抱歉，兑换数量要大于0！';
$it618_sale_lang['s384'] = '抱歉，此商品不存在！';
$it618_sale_lang['s385'] = '抱歉，参数有误！';
$it618_sale_lang['s386'] = '抱歉，您现在只有 ';
$it618_sale_lang['s387'] = '不够兑换！';
$it618_sale_lang['s388'] = '申请退货';
$it618_sale_lang['s389'] = '交易取消成功，积分已退还给您！';
$it618_sale_lang['s390'] = '申请退货成功，请等待管理员处理！';
$it618_sale_lang['s391'] = '积分兑换活动已结束';
$it618_sale_lang['s392'] = '抱歉，您所在用户组没有积分兑换商品的权限，请与管理员联系！';
$it618_sale_lang['s393'] = '订单导入';
$it618_sale_lang['s394'] = '订单管理';
$it618_sale_lang['s395'] = '淘宝联盟的<font color=red>订单结算</font>数据如何导出excel';
$it618_sale_lang['s396'] = '每次导入时会保存列序号设置，默认是淘宝联盟导出的订单列序号，<font color=red>有时淘宝订单会出现几个相同订单号的交易，那可能是同一商品同一价格不同属性的，导入时会自动累加商品数量的</font>';
$it618_sale_lang['s397'] = '订单已导入过！';
$it618_sale_lang['s398'] = '订单没有商品名称！';
$it618_sale_lang['s399'] = '订单没有商品ID！';
$it618_sale_lang['s400'] = '订单没有商品数量！';
$it618_sale_lang['s401'] = '订单没有佣金比率！';
$it618_sale_lang['s402'] = '订单没有付款金额！';
$it618_sale_lang['s403'] = '订单没有效果预估(佣金)！';
$it618_sale_lang['s404'] = '商品优惠券时间有误！';
$it618_sale_lang['s405'] = '【行';
$it618_sale_lang['s406'] = '】';
$it618_sale_lang['s407'] = '还以下';
$it618_sale_lang['s408'] = '个订单导入失败：';
$it618_sale_lang['s409'] = '成功导入订单数：';
$it618_sale_lang['s410'] = '订单没有结算时间！';
$it618_sale_lang['s411'] = '订单没有付款时间！';
$it618_sale_lang['s418'] = '快递管理';
$it618_sale_lang['s419'] = '按快递名称';
$it618_sale_lang['s420'] = '快递数量：';
$it618_sale_lang['s421'] = '快递名称';
$it618_sale_lang['s422'] = '快递网址';
$it618_sale_lang['s423'] = '排序';
$it618_sale_lang['s424'] = '发货数';
$it618_sale_lang['s425'] = '采集的商品没匹配到类目时：';
$it618_sale_lang['s426'] = '勾选时直接入库到其它分类，不勾选时不入库，可以起到过滤效果';
$it618_sale_lang['s427'] = '启用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_sale_lang['s428'] = '参数名称';
$it618_sale_lang['s429'] = '参数内容';
$it618_sale_lang['s430'] = '提示：最多支持9个微信消息模板参数，参数名称比如是：first,keyword1,keyword2,keyword3,...,remark，参数内容支持以上一个标签或多个标签';
$it618_sale_lang['s431'] = '取消';
$it618_sale_lang['s432'] = '保存';
$it618_sale_lang['s433'] = '抱歉，如果参数名称填写了，就必须填写参数内容！';
$it618_sale_lang['s434'] = '<font color=green>提示：默认有短信宝接口，如果配合 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a> 可以有阿里云短信接口，此插件以后还可以扩展更多短信接口</font>';
$it618_sale_lang['s435'] = '';
$it618_sale_lang['s436'] = '1、商品月销量大于等于';
$it618_sale_lang['s437'] = '2、商品佣金比率(%)大于等于';
$it618_sale_lang['s438'] = '返利会员：';
$it618_sale_lang['s439'] = '订单状态：';
$it618_sale_lang['s440'] = '未跟踪';
$it618_sale_lang['s441'] = '分享海报';
$it618_sale_lang['s442'] = '分享海报';
$it618_sale_lang['s443'] = '长按识别二维码';
$it618_sale_lang['s444'] = '商品二维码海报';
$it618_sale_lang['s445'] = '现在分享';
$it618_sale_lang['s446'] = '';
$it618_sale_lang['s447'] = '物料id';
$it618_sale_lang['s448'] = '物料说明';
$it618_sale_lang['s449'] = '自动采集周期';
$it618_sale_lang['s450'] = '最近自动采集时间/采集结果(如果all大于0，add与edit为0时，就是商品没券，没券时间是不能自动删除的，不会入库)';
$it618_sale_lang['s451'] = '排序';
$it618_sale_lang['s452'] = '开启API自动采集';
$it618_sale_lang['s453'] = '此设置优先级高于物料的采集周期，此设置不开启是不会自动采集商品的';
$it618_sale_lang['s454'] = '物料数：';
$it618_sale_lang['s455'] = '说明：<a href="https://open.taobao.com/api.htm?docId=33947&docType=2" target="_blank">taobao.tbk.dg.optimus.material（淘宝客-推广者-物料精选 ）</a>传入官方公布的物料id，可获取指定物料，<a href="https://tbk.bbs.taobao.com/detail.html?appId=45301&postId=8576096" target="_blank">可以点击获取（不定期更新）</a>，插件默认已录入物料，以后请自己看淘宝说明更新物料数据';
$it618_sale_lang['s456'] = '提示：自动采集周期为0时，表示前台触发自动采集功能时不会采集，大于0时就会自动采集，数值越小越占服务器cpu';
$it618_sale_lang['s457'] = '物料分类';
$it618_sale_lang['s458'] = '物料管理';
$it618_sale_lang['s459'] = '分类名称';
$it618_sale_lang['s460'] = '分类说明';
$it618_sale_lang['s461'] = '产出商品数';
$it618_sale_lang['s462'] = '物料数';
$it618_sale_lang['s463'] = '排序';
$it618_sale_lang['s464'] = '注意：产出商品数请按淘宝说明正确填写，采集时会根据这个数量自动分页采集';
$it618_sale_lang['s465'] = '分类数：';
$it618_sale_lang['s466'] = '分钟';
$it618_sale_lang['s467'] = '关联分类';
$it618_sale_lang['s468'] = '关联分类：表示以下物料是和淘宝大类下面的二级分类关联的，这样可以自动匹配淘宝类目';
$it618_sale_lang['s469'] = '';
$it618_sale_lang['s470'] = '';
$it618_sale_lang['s489'] = '抱歉，您最多只能兑换';
$it618_sale_lang['s490'] = '件，您已经兑换了';
$it618_sale_lang['s491'] = '件！';
$it618_sale_lang['s492'] = '抱歉，';
$it618_sale_lang['s493'] = '天内您最多只能兑换';
$it618_sale_lang['s494'] = '我的交易';
$it618_sale_lang['s495'] = '收货地址';
$it618_sale_lang['s496'] = '确认收货';
$it618_sale_lang['s497'] = '取消交易';
$it618_sale_lang['s498'] = '我的钱包';
$it618_sale_lang['s499'] = '默认商品详情内容';
$it618_sale_lang['s500'] = '<font color=red>提示：如果商品详情为空时，自动显示此设置内容</font>';
$it618_sale_lang['s501'] = '管理交易';
$it618_sale_lang['s502'] = '买家会员ID';
$it618_sale_lang['s503'] = '交易状态';
$it618_sale_lang['s504'] = '抱歉，参数有误！';
$it618_sale_lang['s505'] = '发货成功，已提交快递信息！';
$it618_sale_lang['s506'] = '交易删除成功，买家积分已退还！';
$it618_sale_lang['s507'] = '交易退货成功，买家积分已退还！';
$it618_sale_lang['s508'] = '交易成功拒绝退货！';
$it618_sale_lang['s509'] = '删除交易';
$it618_sale_lang['s510'] = '给买家发货';
$it618_sale_lang['s511'] = '配送：';
$it618_sale_lang['s512'] = '修改快递';
$it618_sale_lang['s513'] = '买家收货地址';
$it618_sale_lang['s514'] = '快递单号：';
$it618_sale_lang['s515'] = '提交';
$it618_sale_lang['s516'] = '注意：最好一次就设置好快递信息，如果有短信提醒功能，修改快递信息也会发短信的。';
$it618_sale_lang['s517'] = '同意退货';
$it618_sale_lang['s518'] = '拒绝退货';
$it618_sale_lang['sn'] = '';
$it618_sale_lang['s519'] = '消息提醒设置';
$it618_sale_lang['s520'] = '请选择快递公司';
$it618_sale_lang['s521'] = '标准模板(每个商品属性信息都在固定列，填好就直接导入)';
$it618_sale_lang['s522'] = '定位列序号(根据每个商品属性定位EXCEL对应的列序号)';
$it618_sale_lang['s523'] = '<font color=red>注意：</font>每次导入时会保存列序号设置，<font color=blue>导入时如果 <b>商品id</b> 已存在就替换原有的，如果没有就添加</font>';
$it618_sale_lang['s524'] = '淘口令：';
$it618_sale_lang['s525'] = '优惠券淘口令：';
$it618_sale_lang['s526'] = '选择导入方式：';
$it618_sale_lang['s527'] = '请先根据淘宝联盟导出的EXCEL列字母序号和以下设置对应：';
$it618_sale_lang['s528'] = '无';
$it618_sale_lang['s529'] = '随机初始人气：';
$it618_sale_lang['s530'] = '付款时间';
$it618_sale_lang['s531'] = '商品名称';
$it618_sale_lang['s532'] = '商品ID';
$it618_sale_lang['s533'] = '商品数';
$it618_sale_lang['s534'] = '佣金比率';
$it618_sale_lang['s535'] = '付款金额';
$it618_sale_lang['s536'] = '效果预估(佣金)';
$it618_sale_lang['s537'] = '结算时间';
$it618_sale_lang['s538'] = '订单编号';
$it618_sale_lang['s539'] = '买家会员';
$it618_sale_lang['s540'] = '返利';
$it618_sale_lang['s541'] = '确定要删除已选交易，此操作不可逆?\n\n如果误删，请再导入订单，只是不方便！';
$it618_sale_lang['s542'] = '效果预估(佣金)：';
$it618_sale_lang['s543'] = '确定要确认收货？此操作不可逆！';
$it618_sale_lang['s544'] = '付款金额：';
$it618_sale_lang['s545'] = '赠送';
$it618_sale_lang['s546'] = '抱歉，只有会员才可以取消交易，请先登录！';
$it618_sale_lang['s547'] = '抱歉，只有会员才可以跟踪订单，请先登录！';
$it618_sale_lang['s548'] = '订单跟踪成功，已赠送您';
$it618_sale_lang['s549'] = '，合作愉快！';
$it618_sale_lang['s550'] = '抱歉，您输入的订单不存在，或订单未交易成功！';
$it618_sale_lang['s551'] = '抱歉，您输入的订单号，已经跟踪过了！';
$it618_sale_lang['s552'] = '兑换需';
$it618_sale_lang['s553'] = '购买返';
$it618_sale_lang['s554'] = '购买后跟踪订单即可获得';
$it618_sale_lang['s555'] = '图片(宽：212px，高：52px)';
$it618_sale_lang['s556'] = '链接(为空时图片不带链接)';
$it618_sale_lang['s557'] = '上传图片';
$it618_sale_lang['s558'] = '删除';
$it618_sale_lang['s559'] = '注意：有时商品一级类别不够9个时，可以设置图片，分类导航就显示带链接图片，同时其它与此分类相关的功能也隐藏';
$it618_sale_lang['s560'] = '订单编号：';
$it618_sale_lang['s561'] = '商品数量：';
$it618_sale_lang['s562'] = '付款金额：';
$it618_sale_lang['s563'] = '返利：';
$it618_sale_lang['s564'] = '付款：';
$it618_sale_lang['s565'] = '结算：';
$it618_sale_lang['s566'] = '电脑版商品默认参数';
$it618_sale_lang['s567'] = '手机版商品默认参数';
$it618_sale_lang['s568'] = '抱歉，只有会员才可以兑换商品，请先登录！';
$it618_sale_lang['s569'] = '清空所有商品';
$it618_sale_lang['s570'] = '确定要清空所有商品，会初始重建商品和收藏数据库？此操作不可逆。';
$it618_sale_lang['s571'] = '清空成功！';
$it618_sale_lang['s572'] = '第';
$it618_sale_lang['s573'] = '页 成功添加商品数：';
$it618_sale_lang['s574'] = '，成功更新商品数：';
$it618_sale_lang['s575'] = 'taobao.tbk.dg.item.coupon.get 好券清单API【导购】<br>

当后台类目和查询词均不指定的时候，最多出10000个结果，本功能就是不指定类目和查询词<br>

为了服务器更好的执行，每次采集100个商品，分100次采集，每次采集返回结果到本页面<br>

<font color=green>
技巧：<br>
“淘宝客API接口设置”可以设置没有匹配到类目的商品是不是入库到其它分类<br>
商品分类的匹配类目是需要手工设置的，如果不知道类目，可以先在淘宝联盟导出有优惠券的商品，在导入商品时勾选获取淘宝类目，就可以知道商品的类目了，这样方便手工匹配类目
</font><br>

<font color=red>注意：第一次用到采集功能时，务必先把商品分类的类目匹配好，这样入库时知道商品属于哪个分类</font>
';
$it618_sale_lang['s576'] = '主动采集商品';
$it618_sale_lang['s577'] = '请保持当前页面，正在主动采集...';
$it618_sale_lang['s578'] = '主动采集结果：';
$it618_sale_lang['s579'] = '匹配淘宝类目';
$it618_sale_lang['s580'] = '综合';
$it618_sale_lang['s581'] = '页 成功添加类目数：';
$it618_sale_lang['s582'] = '返回';
$it618_sale_lang['s583'] = '类目采集匹配';
$it618_sale_lang['s584'] = '类目数：';
$it618_sale_lang['s585'] = '确定要主动采集商品并入库？如果您的分类还没有匹配好类目，商品会入库到其它分类！';
$it618_sale_lang['s586'] = '的商品淘宝类目';
$it618_sale_lang['s587'] = '主动采集类目';
$it618_sale_lang['s588'] = '提示：如果分类没有匹配到类目，那么采集的商品自动入库到名为其它的分类';
$it618_sale_lang['s589'] = '技巧：可以在淘宝客API采集商品时勾选不入库商品，只显示类目，这样就知道淘宝有哪些类目，再把类目新增到分类匹配';
$it618_sale_lang['s590'] = '淘宝商品类目';
$it618_sale_lang['s591'] = '综合<font color=#999>(采集商品时匹配不到就添加到本分类下)</font>';
$it618_sale_lang['s592'] = '<font color=red>编号为1的已占用，淘宝客API采集专用</font>';
$it618_sale_lang['s593'] = '抱歉，编号为1的一级商品分类(采集专用分类)，它的二级分类还没有匹配淘宝商品类目，请先匹配再采集！';
$it618_sale_lang['s594'] = '类目下的某个淘宝商品名称';
$it618_sale_lang['s595'] = '清空以上类目，我想再重新采集';
$it618_sale_lang['s596'] = '确定要清空以上类目？';
$it618_sale_lang['s597'] = '提示：商品管理的商品也会显示淘宝类目的，可以更方便知道这个淘宝类目有哪些商品，方便分类匹配类目';
$it618_sale_lang['s598'] = '淘宝类目：';
$it618_sale_lang['s599'] = '淘宝类目';
$it618_sale_lang['s601'] = '前台所有访问者触发自动采集：';
$it618_sale_lang['s602'] = '触发采集时间周期：';
$it618_sale_lang['s603'] = '抱歉，返利功能没有开通，请与管理员联系！';
$it618_sale_lang['s604'] = '';
$it618_sale_lang['s605'] = '提示：也就是有人访问导购前台任何一个页面时，如果时间符合就会触发自动采集功能，<font color=blue>如果此设置为0时，表示不触发自动采集功能，优先级高于物料的采集周期</font><br>时间单位：分钟 <font color=red>注意：数值越小越占服务器cup和内存，推荐10分钟>数值>=1分钟，也不要太大，太大效果不好，这样可以等上一个采集完成</font>';
$it618_sale_lang['s606'] = '导购返利<font color=red>{money}</font>元，单号:{saleid}';
$it618_sale_lang['s607'] = '抱歉，未安装钱包，是不能返钱包余额的，请与管理员联系！';
$it618_sale_lang['s608'] = 'API检测结果：';
$it618_sale_lang['s612'] = '消息提醒设置更新成功！';
$it618_sale_lang['s613'] = '<strong>第三方短信接口，按短信条数收费，给第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注册账号并充值，然后填以下内容就可以了';
$it618_sale_lang['s614'] = '启用消息接口：';
$it618_sale_lang['s615'] = '如果不启用，系统不会有消息提醒功能 <font color=blue>如果安装了【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】就会支持微信模板消息，微信模板ID不为空时，优先发微信模板消息，而不发短信</font>';
$it618_sale_lang['s616'] = '短信接口账号：';
$it618_sale_lang['s617'] = '短信接口密码：';
$it618_sale_lang['s618'] = '测试接收人手机号：';
$it618_sale_lang['it618']='i11ill1lliiilil11111ililiilil111ilil1111iliili1li111111lililililiili11ili1111111ilill11i11111ilili11111ilili1111111111il111i1illii11';
$it618_sale_lang['s619'] = '多个手机号用英文字母逗号隔开';
$it618_sale_lang['s620'] = '测试短信内容：';
$it618_sale_lang['s621'] = '管理员手机号：';
$it618_sale_lang['s622'] = '如果不启用，管理员不会有消息提醒';
$it618_sale_lang['s623'] = '消息模板';
$it618_sale_lang['s624'] = '注意：消息模板只有在“启用”状态，才发送提醒消息，如果短信消息模板和微信消息模板都设置了，优先发送微信消息，发送成功了，就不发短信了，方便节省短信成本';
$it618_sale_lang['s625'] = '<font color=green>
技巧：商品分类的匹配类目是需要手工设置的，如果不知道类目，可以先在淘宝联盟导出有优惠券的商品，在导入商品时勾选获取淘宝类目，就可以知道商品的类目了，这样方便手工匹配类目
</font><br>

<font color=red>注意：第一次用到采集功能时，务必先把商品分类的类目匹配好，这样入库时知道商品属于哪个分类</font>';
$it618_sale_lang['s626'] = '更新';
$it618_sale_lang['s627'] = '更新时发送一个测试短信';
$it618_sale_lang['s628'] = '启用';
$it618_sale_lang['s629'] = '我的返利';
$it618_sale_lang['s631'] = '<font color="green">买家交易成功时</font> - <font color=green>管理员消息模板</font>';
$it618_sale_lang['s632'] = '<font color="#999999">示例：会员${user}用${pscore}兑换了${pcount}个价格为${pprice}元的${pname} <br>标签说明：{user}买家会员名，{pscore}商品积分价格，{pname}商品名称，{pprice}商品价格，{pcount}交易数量，{tel}会员手机号</font>';
$it618_sale_lang['s633'] = '<font color="green">买家交易成功时</font> - <font color=red>买家消息模板</font>';
$it618_sale_lang['s634'] = '<font color="#999999">示例：您用${pscore}兑换了${pcount}个价格为${pprice}元的${pname} <br>标签说明：{pscore}商品积分价格，{pname}商品名称，{pprice}商品价格，{pcount}交易数量';
$it618_sale_lang['s635'] = '<font color="green">买家申请退货时</font> - <font color=green>管理员消息模板</font>';
$it618_sale_lang['s636'] = '<font color="#999999">示例：会员${user}申请退货，订单号：${saleid} 商品名称：${pname} <br>标签说明：{user}买家会员名，{pname}商品名称，{saleid}交易编号';
$it618_sale_lang['s637'] = '<font color="green">管理员给买家发货、同意或拒绝退货时</font> - <font color=red>买家消息模板</font>';
$it618_sale_lang['s638'] = '<font color="#999999">示例：管理员${action}，订单号：${saleid} 商品名称：${pname} <br>标签说明：{action}返回(已发货、同意退货、拒绝退货)，{pname}商品名称，{saleid}交易编号';
$it618_sale_lang['s640'] = '短信接口类型：';
$it618_sale_lang['s641'] = '默认标配短信接口(短信宝)';
$it618_sale_lang['s642'] = 'IT618统一短信接口(阿里大鱼)';
$it618_sale_lang['s643'] = '短信签名：';
$it618_sale_lang['s644'] = 'IT618统一短信接口(阿里云短信)';
$it618_sale_lang['s645'] = '<font color=green><b>抱歉，您还没有安装 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】，此插件为IT618公用短信接口插件，<font color=red>同时还是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_sale_lang['s646'] = '短信模板ID：';
$it618_sale_lang['s647'] = '复制口令';
$it618_sale_lang['s648'] = '优惠券面额：';
$it618_sale_lang['s649'] = '优惠券时间：';
$it618_sale_lang['s650'] = '优惠券链接：';
$it618_sale_lang['s651'] = '以下属于可选填项目，商品是手工添加时，想填可以填的，如果导入商品这些都可以导的';
$it618_sale_lang['s652'] = '注意：导购开始时间如果设置了并且时间没到时，前台商品不会显示，导购截止时间用于插件设置的“过期自动删除商品”，这样方便自动删除商品，时间格式：8888-8-8或8888-8-8 8:8:8';
$it618_sale_lang['s653'] = '注意：商品的佣金比率，只用于返利功能';
$it618_sale_lang['s654'] = '抱歉，请设置活动开始时间！';
$it618_sale_lang['s655'] = '抱歉，请设置活动截止时间！';
$it618_sale_lang['s656'] = '抱歉，活动截止时间不能小于开始时间！';
$it618_sale_lang['s657'] = '抱歉，请设置优惠券开始时间！';
$it618_sale_lang['s658'] = '抱歉，请设置优惠券截止时间！';
$it618_sale_lang['s659'] = '抱歉，优惠券截止时间不能小于开始时间！';
$it618_sale_lang['s660'] = '电脑版顶边距：';
$it618_sale_lang['s661'] = '电脑版宽度：';
$it618_sale_lang['s662'] = '自定义标题：';
$it618_sale_lang['s663'] = '自定义内容：';
$it618_sale_lang['s664'] = '工作时间：';
$it618_sale_lang['s665'] = '热线电话：';
$it618_sale_lang['s666'] = '客服职位：';
$it618_sale_lang['s667'] = '客服QQ：';
$it618_sale_lang['s668'] = '客服微信：';
$it618_sale_lang['s669'] = '微信';
$it618_sale_lang['s670'] = '商品类别';
$it618_sale_lang['s671'] = '请输入商品关键字';
$it618_sale_lang['s672'] = '随机商品';
$it618_sale_lang['s673'] = '确认收货成功！';
$it618_sale_lang['s674'] = '收起';
$it618_sale_lang['s675'] = '抱歉，此插件还未开启，请先开启！';
$it618_sale_lang['s676'] = '手机首页自定广告';
$it618_sale_lang['s677'] = '提示：此广告内容显示在手机版首页的图标导航下面最近消费上面';
$it618_sale_lang['s678'] = '在线编辑器设置';
$it618_sale_lang['s679'] = '启用oss接口：';
$it618_sale_lang['s680'] = '如果不启用，上传图片到本地，如果启用，上传图片到oss，并且返回图片网络引用链接';
$it618_sale_lang['s681'] = 'IT618插件阿里云OSS接口设置方法';
$it618_sale_lang['s682'] = 'Access Key ID：';
$it618_sale_lang['s683'] = 'Access Key Secret：';
$it618_sale_lang['s684'] = 'Bucket名称：';
$it618_sale_lang['s685'] = 'Bucket域名EndPoint：';
$it618_sale_lang['s686'] = 'Bucket外网访问域名：';
$it618_sale_lang['s687'] = '满';
$it618_sale_lang['s688'] = '元减';
$it618_sale_lang['s689'] = '元';
$it618_sale_lang['s690'] = '元无条件券';
$it618_sale_lang['s691'] = '，成功替换商品数：';
$it618_sale_lang['s692'] = '无门槛减';
$it618_sale_lang['s693'] = '';
$it618_sale_lang['s694'] = '【';
$it618_sale_lang['s695'] = '】';
$it618_sale_lang['s696'] = '注册或登录会员会有历史搜索功能';
$it618_sale_lang['s697'] = '全部清空';
$it618_sale_lang['s698'] = '我的历史搜索';
$it618_sale_lang['s699'] = '采集商品时入库需符合条件：';
$it618_sale_lang['s700'] = '可以用';
$it618_sale_lang['s701'] = '兑换后帮您代购';
$it618_sale_lang['s702'] = '淘口令复制成功，打开手机淘宝购买，或分享给好友！';
$it618_sale_lang['s703'] = '优惠券口令复制成功，打开手机淘宝购买，或分享给好友！';
$it618_sale_lang['s704'] = '商品链接复制成功，微信以外都可访问，或分享给好友！';
$it618_sale_lang['s705'] = '优惠券链接复制成功，微信以外都可访问，或分享给好友！';
$it618_sale_lang['s706'] = '购买后凭订单号可以返利';
$it618_sale_lang['s707'] = '跟踪订单';
$it618_sale_lang['s708'] = '显示默认菜单(刷新页面、复制链接、注册登录等)';
$it618_sale_lang['s709'] = '手机版底部二级导航，格式(多个导航要换行)：<br>
&lt;li&gt;&lt;a class="react" href="导航链接1"&gt;导航名称1&lt;/a&gt;&lt;/li&gt;<br>
&lt;li&gt;&lt;a class="react" href="导航链接2"&gt;导航名称2&lt;/a&gt;&lt;/li&gt;';
$it618_sale_lang['s710'] = '会员搜索关键字';
$it618_sale_lang['s711'] = '关键字自动采集';
$it618_sale_lang['s712'] = '关键字';
$it618_sale_lang['s713'] = '搜索次数';
$it618_sale_lang['s714'] = '搜索会员';
$it618_sale_lang['s715'] = '最近搜索时间';
$it618_sale_lang['s716'] = '记录数：';
$it618_sale_lang['s717'] = '提示：此数据只是参考，可以知道会员喜欢搜索哪些商品，方便设置关键字自动采集';
$it618_sale_lang['s718'] = '提示：请先用精选物料自动采集，这样会自动匹配淘宝类目，再用关键字自动采集时，就会自动根据淘宝类目入库到商品分类';
$it618_sale_lang['s719'] = '采集商品时如果没有券信息：';
$it618_sale_lang['s720'] = '无优惠券也入库并设置';
$it618_sale_lang['s721'] = '注意：如果入库，必须有截止导购时间，要不商品是不能按时间自动删除的，比如导购天数是3天，那么截止导购时间就入库时间+3天';
$it618_sale_lang['s722'] = '导购天数：';
$it618_sale_lang['s723'] = '淘口令直接在手机淘宝访问';
$it618_sale_lang['s724'] = '现在复制';
$it618_sale_lang['s725'] = '';
$it618_sale_lang['s726'] = '';
$it618_sale_lang['s727'] = '';
$it618_sale_lang['s728'] = '';
$it618_sale_lang['s729'] = '';
$it618_sale_lang['s730'] = '';
$it618_sale_lang['s731'] = '';
$it618_sale_lang['s732'] = '';
$it618_sale_lang['s1470'] = '电脑版风格';
$it618_sale_lang['s1471'] = '手机版风格';
$it618_sale_lang['s1472'] = '手机版图标导航';
$it618_sale_lang['s1473'] = '手机版底部导航';
$it618_sale_lang['s1477'] = '注意：导航图标为了清晰，推荐宽高60到120，导航标题推荐最多4个字，排序为0时不显示';
$it618_sale_lang['s1795'] = '收藏';
$it618_sale_lang['s1796'] = '取消';
$it618_sale_lang['s1863'] = '提示：{waphome}表示首页链接，{wapsearch}表示搜索链接，{wapmoney}表示返利大厅链接';
$it618_sale_lang['s1888'] = '如果是个人认证，变量字符最多限制个数：';
$it618_sale_lang['s1889'] = '不受限制时请不要填写';
$it618_sale_lang['s1901'] = '微信消息模板ID：';
$it618_sale_lang['s1902'] = '微信消息标签值：';
$it618_sale_lang['s1903'] = '<font color=#999>提示：优先发送微信消息，发送成功了，就不发短信了</font>';
$it618_sale_lang['s1904'] = '现在手工匹配类目';
$it618_sale_lang['s1905'] = '管理员UID<font color=#999>(用于微信消息，多个UID用,隔开)</font>：';
$it618_sale_lang['s1944'] = '我的福利';
$it618_sale_lang['s1945'] = '邀请分销/合伙人/卡券';
$it618_sale_lang['s1946'] = '我的VIP';
$it618_sale_lang['s1947'] = '详情/续购/全站VIP';
$it618_sale_lang['s1958'] = '当前菜单标题颜色';
$it618_sale_lang['s1959'] = '当前菜单图标';


//{lang it618_sale:it618_sale_lang(\d+)} {$it618_sale_lang['t$1']}
$it618_sale_lang['t1'] = '搜索';
$it618_sale_lang['t2'] = '首页';
$it618_sale_lang['t3'] = '全部商品分类';
$it618_sale_lang['t4'] = '热门分类';
$it618_sale_lang['t5'] = '返利大厅';
$it618_sale_lang['t6'] = '更多';
$it618_sale_lang['t7'] = '热门商品';
$it618_sale_lang['t8'] = '最近刚购买的商品';
$it618_sale_lang['t9'] = '导购动态';
$it618_sale_lang['t10'] = '一周内购买最多的商品';
$it618_sale_lang['t11'] = '一周热卖';
$it618_sale_lang['t12'] = '查看全部分类';
$it618_sale_lang['t13'] = '热&nbsp;&nbsp;门：';
$it618_sale_lang['t14'] = '找到';
$it618_sale_lang['t15'] = '“';
$it618_sale_lang['t16'] = '”';
$it618_sale_lang['t17'] = '相关的商品共';
$it618_sale_lang['t18'] = '个。';
$it618_sale_lang['t19'] = '分&nbsp;&nbsp;类：';
$it618_sale_lang['t20'] = '品&nbsp;&nbsp;牌：';
$it618_sale_lang['t21'] = '价&nbsp;&nbsp;格：';
$it618_sale_lang['t22'] = '默认排序';
$it618_sale_lang['t23'] = '销量从高到低';
$it618_sale_lang['t24'] = '销量';
$it618_sale_lang['t25'] = '价格从低到高';
$it618_sale_lang['t26'] = '价格';
$it618_sale_lang['t27'] = '价格从高到低';
$it618_sale_lang['t28'] = '按发布时间排序';
$it618_sale_lang['t29'] = '发布时间';
$it618_sale_lang['t30'] = '销量排行';
$it618_sale_lang['t31'] = '导航';
$it618_sale_lang['t32'] = '导购首页';
$it618_sale_lang['t33'] = '网站首页';
$it618_sale_lang['t34'] = '商品分类';
$it618_sale_lang['t35'] = '登录';
$it618_sale_lang['t36'] = '注册';
$it618_sale_lang['t37'] = '我的收藏';
$it618_sale_lang['t38'] = '商品名称';
$it618_sale_lang['t39'] = '描述';
$it618_sale_lang['t40'] = '人气';
$it618_sale_lang['t41'] = '收藏数';
$it618_sale_lang['t42'] = '收藏时间';
$it618_sale_lang['t43'] = '全选';
$it618_sale_lang['t44'] = '取消收藏选中商品';
$it618_sale_lang['t45'] = '人气排行';
$it618_sale_lang['t46'] = '收藏排行';
$it618_sale_lang['t47'] = '收藏数从高到低';
$it618_sale_lang['t48'] = '收藏数';
$it618_sale_lang['t49'] = '点击数从高到低';
$it618_sale_lang['t50'] = '人气';
$it618_sale_lang['t51'] = '我的收藏';
$it618_sale_lang['t52'] = '电脑版';
$it618_sale_lang['t53'] = '全部';
$it618_sale_lang['t54'] = '商品类别:';
$it618_sale_lang['t55'] = '我们帮您代购';
$it618_sale_lang['t56'] = '商品';
$it618_sale_lang['t57'] = '商品搜索';
$it618_sale_lang['t58'] = '抱歉，您访问的商品不存在！';
$it618_sale_lang['t59'] = '提示：如果图标链接是商品分类<br /><b>动态链接格式：</b>plugin.php?id=it618_sale:wap&pagetype=search&cid1=<font color=red>商品一级分类编号</font>&cid2=<font color=red>商品二级分类编号</font> <br /><b>静态链接格式：</b>sale_wap-search-<font color=red>商品一级分类编号</font>-<font color=red>商品二级分类编号</font>.html';
$it618_sale_lang['t60'] = '关键字词:';
$it618_sale_lang['t61'] = '商品价格:';
$it618_sale_lang['t62'] = '排序方式:';
$it618_sale_lang['t63'] = '默认排序';
$it618_sale_lang['t64'] = '商品价格';
$it618_sale_lang['t65'] = '商品收藏';
$it618_sale_lang['t66'] = '商品人气';
$it618_sale_lang['t67'] = '商品名称';
$it618_sale_lang['t68'] = '关闭';
$it618_sale_lang['t69'] = '确定要取消收藏选中商品？';
$it618_sale_lang['t70'] = '请先选中要取消收藏选中的商品！';
$it618_sale_lang['t71'] = '搜索';
$it618_sale_lang['t72'] = '查看全部分类';
$it618_sale_lang['t73'] = '您的位置：';
$it618_sale_lang['t74'] = '收藏：';
$it618_sale_lang['t75'] = '人气：';
$it618_sale_lang['t76'] = '直接购买';
$it618_sale_lang['t77'] = '人气排行';
$it618_sale_lang['t78'] = '商品详情';
$it618_sale_lang['t79'] = '市场价';
$it618_sale_lang['t80'] = '折扣';
$it618_sale_lang['t81'] = '折';
$it618_sale_lang['t82'] = '返回';
$it618_sale_lang['t83'] = '刷新';
$it618_sale_lang['t84'] = '手机扫码访问此商品';
$it618_sale_lang['t85'] = '优惠券面额：';
$it618_sale_lang['t86'] = '使用期限：';
$it618_sale_lang['t87'] = '立即领券';
$it618_sale_lang['t88'] = '返利';
$it618_sale_lang['t89'] = '您可以用';
$it618_sale_lang['t90'] = '直接兑换此商品，填写收货地址我们帮您代购';
$it618_sale_lang['t91'] = '立即购买';
$it618_sale_lang['t92'] = '我要兑换';
$it618_sale_lang['t93'] = '抱歉，请输入收货姓名！';
$it618_sale_lang['t94'] = '抱歉，请输入收货地址！';
$it618_sale_lang['t95'] = '抱歉，请输入有效的11位手机号码，方便联系与发货，如果有短信提醒功能，会发短信给您的！';
$it618_sale_lang['t96'] = '确定要积分兑换？';
$it618_sale_lang['t97'] = '正在交易...如果您不想等可以关闭交易窗口，后台会自动运行！';
$it618_sale_lang['t98'] = '积分兑换成功！';
$it618_sale_lang['t99'] = '已兑：';
$it618_sale_lang['t100'] = '按关键词';
$it618_sale_lang['t101'] = '我的交易';
$it618_sale_lang['t102'] = '按关键词';
$it618_sale_lang['t103'] = '交易状态';
$it618_sale_lang['t104'] = '交易时间';
$it618_sale_lang['t105'] = '查找';
$it618_sale_lang['t106'] = '提示：交易状态为待发货时，可以取消交易，积分自动退还，交易状态为已发货时，可以申请退货';
$it618_sale_lang['t107'] = '订单号';
$it618_sale_lang['t108'] = '商品名称';
$it618_sale_lang['t109'] = '时价';
$it618_sale_lang['t110'] = '兑换比';
$it618_sale_lang['t111'] = '积分价';
$it618_sale_lang['t112'] = '数量';
$it618_sale_lang['t113'] = '交易状态';
$it618_sale_lang['t114'] = '交易时间';
$it618_sale_lang['t115'] = '提示：交易状态为已发货时，如果不申请退货，过';
$it618_sale_lang['t116'] = '天后交易状态自动变成确认收货';
$it618_sale_lang['t117'] = '确定要取消交易？取消交易后积分自动退还，此操作不可逆！';
$it618_sale_lang['t118'] = '确定要申请退货？此操作不可逆！';
$it618_sale_lang['t119'] = '抱歉，请先登录！也可以直接点确定跳转到登录页面！';
$it618_sale_lang['t120'] = '积分兑换商品';
$it618_sale_lang['t121'] = '我已有';
$it618_sale_lang['t122'] = '兑换数量：';
$it618_sale_lang['t123'] = '兑换所需总积分：';
$it618_sale_lang['t124'] = '收货姓名：';
$it618_sale_lang['t125'] = '手机号码：';
$it618_sale_lang['t126'] = '收货地址：';
$it618_sale_lang['t127'] = '给商家留言';
$it618_sale_lang['t128'] = '积分兑换';
$it618_sale_lang['t129'] = '确定要同意退货？此操作不可逆！';
$it618_sale_lang['t130'] = '确定要拒绝退货？此操作不可逆！';
$it618_sale_lang['t131'] = '刷新交易';
$it618_sale_lang['t132'] = '提示：您购买商品确认收货后，需要跟踪自己的订单，如果没有跟踪到订单，请与管理员联系';
$it618_sale_lang['t133'] = '提示：同一订单号下的数量与金额会累加，合并成一个订单';
$it618_sale_lang['t134'] = '请输入您的订单号：';
$it618_sale_lang['t135'] = '跟踪我的订单';
$it618_sale_lang['t136'] = '抱歉，请输入订单号！';
$it618_sale_lang['t137'] = '订单号：';
$it618_sale_lang['t138'] = '跟踪订单';
$it618_sale_lang['t139'] = '结算时间';
$it618_sale_lang['t140'] = '点我复制 “淘口令” 到手机淘宝购买';
$it618_sale_lang['t141'] = '点我复制 ”优惠券口令” 到手机淘宝购买';
$it618_sale_lang['t142'] = '点我复制 “商品链接” 到浏览器购买';
$it618_sale_lang['t143'] = '点我复制 ”优惠券链接” 到浏览器购买';
$it618_sale_lang['t144'] = '发现';
$it618_sale_lang['t145'] = '佣金:';
$it618_sale_lang['t146'] = '';
$it618_sale_lang['t147'] = '';
$it618_sale_lang['t148'] = '收藏成功，如果需要查看或管理我收藏的商品，请在底部导航“我的-我的收藏”操作！';
$it618_sale_lang['t149'] = '取消收藏成功，如果需要查看或管理我收藏的商品，请在底部导航“我的-我的收藏”操作！';
$it618_sale_lang['t150'] = '抱歉，只有会员才可以操作收藏功能，请先登录！';
$it618_sale_lang['t151'] = '兑换比：';
$it618_sale_lang['t152'] = '导航';
$it618_sale_lang['t153'] = '返回上页';
$it618_sale_lang['t154'] = '刷新页面';
$it618_sale_lang['t155'] = '搜索商品';
$it618_sale_lang['t156'] = '客服';
$it618_sale_lang['t157'] = '输入商品搜索关键字 多个关键字空格隔开';
$it618_sale_lang['t293'] = '开始日期不能大于截止日期！';
$it618_sale_lang['t294'] = '一键复制';
$it618_sale_lang['t295'] = '复制成功';
$it618_sale_lang['t307'] = '提示：多个关键词请用空格隔开 如：手机 双待 宽屏';
$it618_sale_lang['t308'] = '天';
$it618_sale_lang['t309'] = '时';
$it618_sale_lang['t310'] = '分';
$it618_sale_lang['t311'] = '秒';
$it618_sale_lang['t312'] = '分享';
$it618_sale_lang['t313'] = '收藏';
$it618_sale_lang['t314'] = '随机推荐商品';
$it618_sale_lang['t315'] = '请选择快递公司！';
$it618_sale_lang['t316'] = '请输入快递单号！';
$it618_sale_lang['t317'] = '已优选';
$it618_sale_lang['t318'] = '个商品';
$it618_sale_lang['t319'] = '请输入您要搜索的商品名称关键词...';
$it618_sale_lang['t320'] = '余额';
$it618_sale_lang['t321'] = '/积分';
$it618_sale_lang['t322'] = '个';
$it618_sale_lang['t323'] = '个商品';
$it618_sale_lang['t324'] = '确定要删除已选订单，此操作不可逆?\n\n如果误删，请再导入订单，只是不方便！';
$it618_sale_lang['t325'] = '我的';
$it618_sale_lang['t326'] = '我的';
$it618_sale_lang['t360'] = '在线客服';
$it618_sale_lang['t361'] = '手机扫描二维码访问此页面';
$it618_sale_lang['t362'] = '也可以复制以下支付链接到微信：';
$it618_sale_lang['t363'] = '查看在线客服';
$it618_sale_lang['t364'] = '展开';
$it618_sale_lang['t365'] = '关闭在线客服';
$it618_sale_lang['t366'] = '收缩';
$it618_sale_lang['t367'] = '商家信息';
$it618_sale_lang['t368'] = '工作时间';
$it618_sale_lang['t369'] = '热线电话';
$it618_sale_lang['t763'] = '复制链接';
$it618_sale_lang['t764'] = '请升级您的微信版本！';
$it618_sale_lang['t765'] = '链接复制成功！';
$it618_sale_lang['t767'] = '确定要删除“';
$it618_sale_lang['t768'] = '”？此操作不可逆！';
$it618_sale_lang['t769'] = '确定要清空历史搜索？此操作不可逆！';
$it618_sale_lang['t894'] = '访问我的个人空间';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_set'));
if($count==0){
$sql = <<<EOF
	INSERT INTO `pre_it618_sale_set` (`id`, `setname`, `setvalue`) VALUES
(1, 'topnav', '<li>\r\n	<a target="_blank" href="">帮助</a><span></span>\r\n</li>\r\n<li>\r\n	<a target="_blank" href="">反馈</a>\r\n</li>'),
(2, 'hotclassgoods', '46,47,52,55,65,6,7,8,18,4,5,14,15@@@46,47,52,55,65,6,7,8,18,4,5,14,15,42,44,45,1@@@1,2,1,2,1,2,1,2,1,2,1,2'),
(3, 'footer', '<footer id="footer">\r\n<div class="footer-top">\r\n	<div class="site-info">\r\n		<dl>\r\n			<dt>\r\n				服务保障\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">导购三包</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">退换货服务</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">支付方式</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				用户帮助\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">答疑反馈</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">常见问题</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">往期导购</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">抽奖活动</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				商务合作\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">导购合作</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">开放API</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank">导购联盟</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="">友情链接</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				公司信息\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">关于导购</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">媒体报道</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">加入我们</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" rel="nofollow">法律中心</a> \r\n			</dd>\r\n		</dl>\r\n		<dl>\r\n			<dt>\r\n				移动导购\r\n			</dt>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank">导购APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">导购酒店预订APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">导购电影APP</a> \r\n			</dd>\r\n			<dd>\r\n				<i class="site-icon"></i><a href="" target="_blank" rel="nofollow">导购wap版</a> \r\n			</dd>\r\n		</dl>\r\n		<div class="code">\r\n			<img src="source/plugin/it618_sale/images/code.png" /> \r\n		</div>\r\n		<div class="clr">\r\n		</div>\r\n	</div>\r\n</div>\r\n</footer>'),
(4, 'productvalue', '<style>\r\n		.productvalue tr td{padding-top:8px; padding-bottom:8px}\r\n		.productvalue tr td.valuetitle{width:80px; color:#999;}\r\n		</style>\r\n<table class="productvalue" width="99%">\r\n	<tbody>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				商品库存\r\n			</td>\r\n			<td>\r\n				1000\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				发货方式\r\n			</td>\r\n			<td>\r\n				中通、申通\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				支付方式\r\n			</td>\r\n			<td>\r\n				支付宝\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				颜色\r\n			</td>\r\n			<td>\r\n				红、蓝\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				尺码\r\n			</td>\r\n			<td>\r\n				S、M\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				优惠券\r\n			</td>\r\n			<td>\r\n				找我QQ\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>'),(5, 'wapproductvalue', '<style>\r\n		.productvalue tr td{padding-top:8px; padding-bottom:8px}\r\n		.productvalue tr td.valuetitle{width:80px; color:#999;}\r\n		</style>\r\n<table class="productvalue" width="99%">\r\n	<tbody>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				商品库存\r\n			</td>\r\n			<td>\r\n				1000\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				发货方式\r\n			</td>\r\n			<td>\r\n				中通、申通\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				支付方式\r\n			</td>\r\n			<td>\r\n				支付宝\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				颜色\r\n			</td>\r\n			<td>\r\n				红、蓝\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				尺码\r\n			</td>\r\n			<td>\r\n				S、M\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="valuetitle">\r\n				优惠券\r\n			</td>\r\n			<td>\r\n				找我QQ\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>');

EOF;
$sql=str_replace("pre_it618_sale_set",DB::table('it618_sale_set'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_sale_class1` (`id`, `it618_classname`, `it618_order`, `it618_goodscount`, `it618_wapgoodscount`) VALUES
(1, '淘宝天猫', 1, 0, 0),
(2, '京东商城', 2, 0, 0),
(3, '苏宁易购', 3, 0, 0),
(4, '聚美优品', 4, 0, 0),
(5, '唯品会', 5, 0, 0),
(6, '华为商城', 6, 0, 0),
(7, '小米商城', 7, 0, 0),
(8, '国美商城', 8, 0, 0),
(9, '当当商城', 9, 0, 0);

EOF;
$sql=str_replace("pre_it618_sale_class1",DB::table('it618_sale_class1'),$sql);
DB::query($sql);

$sql = <<<EOF

INSERT INTO `pre_it618_sale_wapiconav`(`id`,`it618_title`,`it618_img`,`it618_url`,`it618_target`,`it618_color`,`it618_isbold`,`it618_order`) VALUES
('1','居家','source/plugin/it618_sale/wap/images/1.png','sale_wap-search-1-10.html','0','','0','1'),
('2','女装','source/plugin/it618_sale/wap/images/2.png','sale_wap-search-1-1.html','0','','0','2'),
('3','母婴','source/plugin/it618_sale/wap/images/3.png','sale_wap-search-1-6.html','0','','0','3'),
('4','鞋包','source/plugin/it618_sale/wap/images/4.png','sale_wap-search-1-3.html','0','','0','4'),
('5','男装','source/plugin/it618_sale/wap/images/5.png','sale_wap-search-1-2.html','0','','0','5'),
('6','美妆','source/plugin/it618_sale/wap/images/6.png','sale_wap-search-1-5.html','0','','0','6'),
('7','数码','source/plugin/it618_sale/wap/images/7.png','sale_wap-search-1-9.html','0','','0','7'),
('8','综合','source/plugin/it618_sale/wap/images/8.png','sale_wap-search-1-11.html','0','','0','8');

EOF;
$sql=str_replace("pre_it618_sale_wapiconav",DB::table('it618_sale_wapiconav'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_sale_style` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#ff971b', '#e46703', 0),
(2, '#DD2525', '#B52020', 1),
(3, '#48b518', '#289a00', 0),
(4, '#2c7ccd', '#0c59ad', 0),
(5, '#f50bc1', '#c5099b', 0),
(6, '#09aeb0', '#089395', 0),
(8, '#ff4400', '#e03e03', 0),
(7, '#888c8e', '#6f7071', 0);

EOF;
$sql=str_replace("pre_it618_sale_style",DB::table('it618_sale_style'),$sql);
DB::query($sql);

$sql = <<<EOF
INSERT INTO `pre_it618_sale_wapstyle` (`id`, `it618_color1`, `it618_color2`, `it618_isok`) VALUES
(1, '#fd9e2d', '#e8922b', 0),
(2, '#fc4646', '#f43131', 1),
(3, '#5ebe00', '#56aa04', 0),
(4, '#23b8ff', '#12a8ff', 0),
(5, '#fb23cb', '#ea11ba', 0),
(6, '#2dbeae', '#00a795', 0),
(8, '#fe5400', '#d04906', 0),
(7, '#999a9b', '#8d8f90', 0);

EOF;
$sql=str_replace("pre_it618_sale_wapstyle",DB::table('it618_sale_wapstyle'),$sql);
DB::query($sql);


}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_bottomnav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_sale_bottomnav` (`id`, `it618_title`, `it618_img`, `it618_curimg`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '发现', 'source/plugin/it618_sale/wap/images/menu.png', '','','',3),
(2, '首页', 'source/plugin/it618_sale/wap/images/home.png', 'source/plugin/it618_sale/wap/images/curhome.png', '{waphome}','#FF0000',1),
(3, '搜索', 'source/plugin/it618_sale/wap/images/find.png', 'source/plugin/it618_sale/wap/images/curfind.png', '{wapsearch}','#FF0000',2),
(4, '返利', 'source/plugin/it618_sale/wap/images/money.png', 'source/plugin/it618_sale/wap/images/curmoney.png', '{wapmoney}','#FF0000',4),
(5, '我的', 'source/plugin/it618_sale/wap/images/uc.png', 'source/plugin/it618_sale/wap/images/curuc.png', '','#FF0000',5);

EOF;
$sql=str_replace("pre_it618_sale_bottomnav",DB::table('it618_sale_bottomnav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_materialclass'));
if($count==0){
	
$sql = <<<EOF
INSERT INTO `pre_it618_sale_materialclass` (`id`, `it618_classname`, `it618_about`, `it618_goodscount`, `it618_order`) VALUES
(1, '好券直播', '数据源同联盟app的好券直播。小时计更新，展示联盟高佣优质商品库中的领券热门商品', 200, 1),
(2, '大额券', '联盟精品商品库中的大额券商品，券面额大且券折扣力度高的商品，小时更新', 500, 1),
(3, '高佣榜', '联盟精品商品库中的高佣商品，佣金最高达90%，按天更新', 500, 1),
(4, '品牌券', '综合品牌、佣金和券因素的优质商品', 200, 1),
(5, '母婴主题', '定位在母婴市场，围绕从备孕到儿童不同阶段对商品的诉求提供商品库。适用于母亲节、520、61儿童节等母婴主题节气，也适用于母婴类网站选品需求。', 1000, 1),
(6, '有好货', '商品本身是受欢迎的品质好货，淘宝有好货的产品心智', 1000, 1),
(7, '潮流范', '代表当下时尚和流行趋势的商品，商品调性类似淘宝ifashion、潮电街、酷动城', 1000, 1),
(8, '特惠', '优质特惠宝贝。 优先考虑销量高, 评价高,点击转化好, 创意具有吸引力的优质低价宝贝，以及30天的历史新低宝贝, 覆盖了手淘主要特惠场景的优质宝贝.', 1000, 1);

EOF;
$sql=str_replace("pre_it618_sale_materialclass",DB::table('it618_sale_materialclass'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_sale_material'));
if($count==0){
	
$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_sale_class2`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_class2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL,
  `it618_wapgoodscount` int(10) unsigned NOT NULL,
  `it618_homeorder` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_category`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_category` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_sale_apiwork`;
CREATE TABLE IF NOT EXISTS `pre_it618_sale_apiwork` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;
require_once DISCUZ_ROOT.'./source/function/function_plugin.php';
runquery($sql);
	
$sql = <<<EOF

INSERT INTO `pre_it618_sale_class2`(`id`,`it618_class1_id`,`it618_classname`,`it618_color`,`it618_order`,`it618_istj`,`it618_goodscount`,`it618_wapgoodscount`,`it618_homeorder`) VALUES
('1','1','女装','#FF0000','1','0','8','8','1'),
('2','1','男装','','2','0','8','8','2'),
('3','1','鞋包配饰','','3','0','8','8','3'),
('4','1','运动户外','','4','0','8','8','4'),
('5','1','美妆个护','','5','0','8','8','5'),
('6','1','母婴','','6','0','8','8','6'),
('7','1','食品','','7','0','8','8','7'),
('8','1','内衣','','8','0','8','8','8'),
('9','1','数码家电','','9','0','8','8','9'),
('10','1','家居家装','#FF0000','10','0','8','8','10'),
('11','1','综合','','11','0','8','8','11');

EOF;
$sql=str_replace("pre_it618_sale_class2",DB::table('it618_sale_class2'),$sql);
DB::query($sql);
	
$sql = <<<EOF
INSERT INTO `pre_it618_sale_material` (`it618_cid`, `it618_materialid`, `it618_class2_id`, `it618_about`, `it618_timecount`, `it618_time`, `it618_order`) VALUES
(1, 3756, 11, '综合', 60, 0, 1),
(1, 3762, 3, '鞋包配饰', 60, 0, 1),
(1, 3760, 6, '母婴', 60, 0, 1),
(1, 3767, 1, '女装', 60, 0, 1),
(1, 3763, 5, '美妆个护', 60, 0, 1),
(1, 3761, 7, '食品', 60, 0, 1),
(1, 3758, 10, '家居家装', 60, 0, 1),
(1, 3764, 2, '男装', 60, 0, 1),
(1, 3766, 4, '运动户外', 60, 0, 1),
(1, 3759, 9, '数码家电', 60, 0, 1),
(1, 3765, 8, '内衣', 60, 0, 1),
(2, 9660, 11, '综合', 60, 0, 1),
(2, 9648, 3, '鞋包配饰', 60, 0, 1),
(2, 9650, 6, '母婴', 60, 0, 1),
(2, 9658, 1, '女装', 60, 0, 1),
(2, 9653, 5, '美妆个护', 60, 0, 1),
(2, 9649, 7, '食品', 60, 0, 1),
(2, 9655, 10, '家居家装', 60, 0, 1),
(2, 9654, 2, '男装', 60, 0, 1),
(2, 9651, 4, '运动户外', 60, 0, 1),
(2, 9656, 9, '数码家电', 60, 0, 1),
(2, 9652, 8, '内衣', 60, 0, 1),
(3, 13366, 11, '综合', 1440, 0, 1),
(3, 13370, 3, '鞋包配饰', 1440, 0, 1),
(3, 13374, 6, '母婴', 1440, 0, 1),
(3, 13367, 1, '女装', 1440, 0, 1),
(3, 13371, 5, '美妆个护', 1440, 0, 1),
(3, 13375, 7, '食品', 1440, 0, 1),
(3, 13368, 10, '家居家装', 1440, 0, 1),
(3, 13372, 2, '男装', 1440, 0, 1),
(3, 13376, 4, '运动户外', 1440, 0, 1),
(3, 13369, 9, '数码家电', 1440, 0, 1),
(3, 13373, 8, '内衣', 1440, 0, 1),
(4, 3786, 11, '综合', 1440, 0, 1),
(4, 3796, 3, '鞋包配饰', 1440, 0, 1),
(4, 3789, 6, '母婴', 1440, 0, 1),
(4, 3788, 1, '女装', 1440, 0, 1),
(4, 3794, 5, '美妆个护', 1440, 0, 1),
(4, 3791, 7, '食品', 1440, 0, 1),
(4, 3792, 10, '家居家装', 1440, 0, 1),
(4, 3790, 2, '男装', 1440, 0, 1),
(4, 3795, 4, '运动户外', 1440, 0, 1),
(4, 3793, 9, '数码家电', 1440, 0, 1),
(4, 3787, 8, '内衣', 1440, 0, 1),
(5, 4040, 6, '母婴_备孕', 1440, 0, 1),
(5, 4041, 6, '母婴_0至6个月', 1440, 0, 1),
(5, 4044, 6, '母婴_4至6岁', 1440, 0, 1),
(5, 4042, 6, '母婴_7至12个月', 1440, 0, 1),
(5, 4043, 6, '母婴_1至3岁', 1440, 0, 1),
(5, 4045, 6, '母婴_7至12岁', 1440, 0, 1),
(6, 4092, 0, '', 1440, 0, 1),
(7, 4093, 0, '', 1440, 0, 1),
(8, 4094, 0, '', 1440, 0, 1);

EOF;
$sql=str_replace("pre_it618_sale_material",DB::table('it618_sale_material'),$sql);
DB::query($sql);
}

$tmpplugin = $_G['cache']['plugin']['it618_sale'];
if($tmpplugin['sale_credit']==''){
	echo '抱歉，请先在插件(it618_sale)后台设置好积分类型！';exit;
}
//From: d'.'is'.'m.ta'.'obao.com
?>