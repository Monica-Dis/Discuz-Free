<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';

if(pinedu_is_mobile()){ 
	$wap=1;
}else{
	$wap=0;
}

$typeid=intval($_GET['typeid']);
$spid=intval($_GET['spid']);
$shoptype=$_GET['shoptype'];

if($_GET['pagetype']=='pin'){
	$shoptype=$ShopType;
	if($shoptype!='brand'){
		$typeid=intval($_GET['cid1']);
		$spid=intval($_GET['cid2']);
	}else{
		$typeid=intval($_GET['oid']);
		$spid=intval($_GET['cid']);
	}
}

$statetitle=$it618_pinedu_lang['s82'];
$pricetitle=$it618_pinedu_lang['s72'];

if($spid==0){
	if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_shoptype_typeid($shoptype,$typeid)){
		echo $it618_pinedu_lang['s80'];exit;
	}
	
	if($it618_pinedu_goods['it618_price1']>0||$it618_pinedu_goods['it618_score1']>0){
		$goodspricestr=it618_pinedu_getgoodsprice($it618_pinedu_goods,'1');
		$pricetitle=$it618_pinedu_lang['s81'];
	}else{
		$goodspricestr=it618_pinedu_getgoodsprice($it618_pinedu_goods);	
	}
}else{
	if(!$it618_pinedu_sale_pin=C::t('#it618_pinedu#it618_pinedu_sale_pin')->fetch_by_id($spid)){
		echo $it618_pinedu_lang['s80'];exit;
	}
	
	$statetitle=$it618_pinedu_lang['s93'];
	$it618_pinedu_goods = C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_id($it618_pinedu_sale_pin['it618_pid']);
	$typeid=$it618_pinedu_goods['it618_typeid'];
	$goodspricestr=it618_pinedu_getgoodsprice($it618_pinedu_sale_pin);	
}

if($shoptype=='video'){
	if($_GET['pagetype']!='pin')require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
	
	$typetitle=$it618_pinedu_lang['s68'];
	
	$pid=$it618_pinedu_goods['it618_pid'];
	if($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid)){
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		if($it618_video_shop['it618_state']!=2||$it618_video_shop['it618_htstate']!=1){
			echo $it618_pinedu_lang['s80'];exit;
		}
		if($it618_video_shop['it618_uid']==$_G['uid']){
			$isshop=1;
		}
	}
	
	if($isshop!=1){
		if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
			echo $it618_pinedu_lang['s80'];exit;
		}else{
			if(!it618_video_issecretok($it618_video_goods)){
				echo $it618_pinedu_lang['s80'];exit;
			}
		}
	}
	
	if($it618_video_shop['it618_issale']!=1){
		echo $it618_pinedu_lang['s80'];exit;
	}
	
	$pingoodsname=$it618_video_goods['it618_name'];
	$pingoodsabout=$it618_video_goods['it618_description'];

	$goodspic=it618_video_getgoodspic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig'],0);
	$producturl=it618_video_getrewrite('video_wap','product@'.$pid,'plugin.php?id=it618_video:wap&pagetype=product&cid='.$pid);
	
	$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);
	$it618_price=it618_pinedu_getgoodsprice1($it618_video_goods_type);
	
	$lid=$it618_video_goods_type['it618_lid'];
	$vid=$it618_video_goods_type['it618_vid'];
	$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);
	
	if($it618_video_goods_type['it618_timetype']==1)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s21'];
	if($it618_video_goods_type['it618_timetype']==2)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s22'];
	if($it618_video_goods_type['it618_timetype']==3)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s23'];
	if($it618_video_goods_type['it618_timetype']==4)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s24'];
	if($it618_video_goods_type['it618_timetype']==5)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s25'];
	if($it618_video_goods_type['it618_timetype']==6){$time=$it618_pinedu_lang['s20'];$istype6=1;}
	
	$goodsaboutstr='<font color="red">'.$goodsabout['type'].'*'.$time.'</font> '.$goodsabout['about'];
	
	if($it618_pinedu_goods['it618_xgcount']>1){
		$tmpxgstr=$it618_pinedu_lang['s73'].$it618_pinedu_goods['it618_xgcount'].$it618_pinedu_lang['s74'];
	}else{
		$istype6=1;	
	}
	
	if($_GET['e']!=''){
		$pinurl=$_G['siteurl'].it618_video_getrewrite('video_wap','pin@'.$typeid.'@'.$spid,'plugin.php?id=it618_video:wap&pagetype=pin&cid1='.$typeid.'&cid2='.$spid.'&e='.$_GET['e'],'?e='.$_GET['e']);
	}else{
		$pinurl=$_G['siteurl'].it618_video_getrewrite('video_wap','pin@'.$typeid.'@'.$spid,'plugin.php?id=it618_video:wap&pagetype=pin&cid1='.$typeid.'&cid2='.$spid);
	}
	
	$qrcodesrc='plugin.php?id=it618_video:urlcode&url='.urlencode($pinurl);
	
	if($it618_video['video_saletel']==2&&$wap==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
		$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=sitetelbd&preurl=".urlencode($pinurl),"?ac=sitetelbd&preurl=".urlencode($pinurl));
	}	
	
}

if($shoptype=='exam'){
	if($_GET['pagetype']!='pin')require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
	
	$typetitle=$it618_pinedu_lang['s69'];
	
	$pid=$it618_pinedu_goods['it618_pid'];
	if($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid)){
		$it618_exam_shop = C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
		if($it618_exam_shop['it618_state']!=2||$it618_exam_shop['it618_htstate']!=1){
			echo $it618_pinedu_lang['s80'];exit;
		}
		if($it618_exam_shop['it618_uid']==$_G['uid']){
			$isshop=1;
		}
	}
	
	if($isshop!=1){
		if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
			echo $it618_pinedu_lang['s80'];exit;
		}else{
			if(!it618_exam_issecretok($it618_exam_goods)){
				echo $it618_pinedu_lang['s80'];exit;
			}
		}
	}
	
	$pingoodsname=$it618_exam_goods['it618_name'];
	$pingoodsabout=$it618_exam_goods['it618_description'];

	$goodspic=it618_exam_getgoodspic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig'],0);
	$producturl=it618_exam_getrewrite('exam_wap','product@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$pid);
	
	$it618_exam_goods_type = C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($typeid);
	$it618_price=it618_pinedu_getgoodsprice1($it618_exam_goods_type);
	
	$goodsaboutstr='<font color="red">'.$it618_exam_goods_type['it618_name'].'</font>';
	
	if($it618_pinedu_goods['it618_xgcount']>1){
		$tmpxgstr=$it618_pinedu_lang['s73'].$it618_pinedu_goods['it618_xgcount'].$it618_pinedu_lang['s74'];
	}else{
		$istype6=1;	
	}
	
	if($_GET['e']!=''){
		$pinurl=$_G['siteurl'].it618_exam_getrewrite('exam_wap','pin@'.$typeid.'@'.$spid,'plugin.php?id=it618_exam:wap&pagetype=pin&cid1='.$typeid.'&cid2='.$spid.'&e='.$_GET['e'],'?e='.$_GET['e']);
	}else{
		$pinurl=$_G['siteurl'].it618_exam_getrewrite('exam_wap','pin@'.$typeid.'@'.$spid,'plugin.php?id=it618_exam:wap&pagetype=pin&cid1='.$typeid.'&cid2='.$spid);
	}

	$qrcodesrc='plugin.php?id=it618_exam:urlcode&url='.urlencode($pinurl);
	
	if($it618_exam['exam_saletel']==2&&$wap==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
		$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=sitetelbd&preurl=".urlencode($pinurl),"?ac=sitetelbd&preurl=".urlencode($pinurl));
	}	
	
}

if($shoptype=='group'){
	if($_GET['pagetype']!='pin')require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
	
	$typetitle=$it618_pinedu_lang['s69'];
	$pid=$it618_pinedu_goods['it618_pid'];
	
	$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($pid);
	
	$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
	$it618_unit=it618_group_getgoodsunit($it618_group_goods);
	$pingoodsname=$grouptitle.' '.$it618_unit;
	
	$it618_powers=explode("@@@",str_replace(array("\r\n", "\r", "\n"), '@@@', $it618_group_group['it618_power']));
	foreach($it618_powers as $key => $it618_power){
		if($it618_power!=""){
			$grouppower.='<tr><td><img src="source/plugin/it618_group/template/default/images/vipabout.png">'.$it618_power.'</td></tr>';
		}
	}

	$goodspic=$it618_group_group['it618_ico'];
	$producturl=it618_group_getrewrite('group_wap','product@'.$pid,'plugin.php?id=it618_group:wap&pagetype=product&cid='.$pid);
	
	$it618_price=it618_pinedu_getgoodsprice1($it618_group_goods);
	
	if($it618_pinedu_goods['it618_xgcount']>1){
		$tmpxgstr=$it618_pinedu_lang['s73'].$it618_pinedu_goods['it618_xgcount'].$it618_pinedu_lang['s74'];
	}else{
		$istype6=1;	
	}
	
	if($_GET['e']!=''){
		$pinurl=$_G['siteurl'].it618_group_getrewrite('group_wap','pin@'.$typeid.'@'.$spid,'plugin.php?id=it618_group:wap&pagetype=pin&cid1='.$typeid.'&cid2='.$spid.'&e='.$_GET['e'],'?e='.$_GET['e']);
	}else{
		$pinurl=$_G['siteurl'].it618_group_getrewrite('group_wap','pin@'.$typeid.'@'.$spid,'plugin.php?id=it618_group:wap&pagetype=pin&cid1='.$typeid.'&cid2='.$spid);
	}
	
	$qrcodesrc='plugin.php?id=it618_group:urlcode&url='.urlencode($pinurl);
	
}

if($shoptype=='brand'){
	if($_GET['pagetype']!='pin')require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
	
	$typetitle=$it618_pinedu_lang['s69'];
	
	$pid=$it618_pinedu_goods['it618_pid'];
	if($it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid)){
		$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
		if($it618_brand_brand['it618_state']!=2||$it618_brand_brand['it618_htstate']!=1){
			echo $it618_pinedu_lang['s80'];exit;
		}
		if($it618_brand_brand['it618_uid']==$_G['uid']){
			$isshop=1;
		}
	}
	
	if($isshop!=1){
		if($it618_brand_goods['it618_ison']!=1||$it618_brand_goods['it618_state']!=1){
			echo $it618_pinedu_lang['s80'];exit;
		}
	}
	
	if(($it618_brand_goods['it618_saletype']==2 || $it618_brand_goods['it618_saletype']==4) && $it618_brand_goods['it618_isyunfeifree']==0){

		$isyunfei=1;
		
		$kdcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_kdyunfei')." where it618_shopid=".$it618_brand_goods['it618_shopid']);
	
		$query = DB::query("SELECT * FROM ".DB::table('it618_brand_kdarea')." where it618_shopid=".$it618_brand_goods['it618_shopid']." ORDER BY it618_order");
		$n1=1;
		$tmp1='';
		while($it618_tmp1 = DB::fetch($query)) {
			if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_brand_kdyunfei')." where it618_shopid=".$it618_brand_goods['it618_shopid']." and it618_kdareaid=".$it618_tmp1['id'])>0){
				$kdarea.='<option value='.$it618_tmp1['id'].'>'.$it618_tmp1['it618_name'].'</option>';
				$n2=1;
				$query2 = DB::query("SELECT * FROM ".DB::table('it618_brand_kdyunfei')." where it618_shopid=".$it618_brand_goods['it618_shopid']." and it618_order<>0 and it618_kdareaid=".$it618_tmp1['id']." ORDER BY it618_order");
	
				while($it618_tmp2 =	DB::fetch($query2)) {
					
					$kdname=C::t('#it618_brand#it618_brand_kd')->fetch_name_by_id($it618_tmp2['it618_kdid']);
					
					if($it618_brand_goods['it618_kgbl']>0&&$it618_brand_brand['it618_isyunfeikg']==1){
						
						if($it618_brand_goods['it618_isduihuan']==1&&$it618_brand_goods['it618_isalipay']==1){
							$pricestr1=$it618_tmp2['it618_firstkgprice'].'('.$it618_tmp2['it618_firstkgscore'].$creditname.') ';
							$pricestr2=$it618_tmp2['it618_kgprice'].'('.$it618_tmp2['it618_kgscore'].$creditname.')';
						}else{
							if($it618_brand_goods['it618_isduihuan']==1){
								$pricestr1=$it618_tmp2['it618_firstkgscore'].$creditname.' ';
								$pricestr2=$it618_tmp2['it618_kgscore'].$creditname;
							}else{
								$pricestr1=$it618_tmp2['it618_firstkgprice'].' ';
								$pricestr2=$it618_tmp2['it618_kgprice'];
							}
						}
						
						$tmp1.='select_kd['.$n1.']['.$n2.'] = new Option("'.$kdname.' '.$it618_tmp2['it618_firstkg'].'kg'.it618_brand_getlang('s1001').' \u00A5'.$pricestr1.it618_brand_getlang('s1730').' \u00A5'.$pricestr2.'", "'.$it618_tmp2['id'].'");';
						
					}else{
						if($it618_brand_goods['it618_isduihuan']==1&&$it618_brand_goods['it618_isalipay']==1){
							$pricestr1=$it618_tmp2['it618_firstprice'].'('.$it618_tmp2['it618_firstscore'].$creditname.') ';
							$pricestr2=$it618_tmp2['it618_price'].'('.$it618_tmp2['it618_score'].$creditname.')';
						}else{
							if($it618_brand_goods['it618_isduihuan']==1){
								$pricestr1=$it618_tmp2['it618_firstscore'].$creditname.' ';
								$pricestr2=$it618_tmp2['it618_firstscore'].$creditname;
							}else{
								$pricestr1=$it618_tmp2['it618_firstprice'].' ';
								$pricestr2=$it618_tmp2['it618_price'];
							}
						}
						
						$tmp1.='select_kd['.$n1.']['.$n2.'] = new Option("'.$kdname.' '.$it618_tmp2['it618_firstcount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1001').' \u00A5'.$pricestr1.it618_brand_getlang('s997').'1'.$it618_brand_goods['it618_punit'].' '.it618_brand_getlang('s998').' \u00A5'.$pricestr2.'", "'.$it618_tmp2['id'].'");';
					}
	
					$n2=$n2+1;
				}
				$n1=$n1+1;
			}
		}
		
		$kdjs='var arrcount='.$kdcount.';
			var select_kd = new Array(arrcount+1);
			
			for (i=0; i<arrcount+1; i++) 
			{
			 select_kd[i] = new Array();
			}
			
			'.$tmp1.'
			
			function redirec_kd(x)
			{
			 var temp = document.getElementById("it618_kd"); 
			 temp.options.length=1;
			 for (i=1;i<select_kd[x].length;i++)
			 {
			  temp.options[i]=new Option(select_kd[x][i].text,select_kd[x][i].value);
			 }
			 temp.options[0].selected=true;
			
			}';
	}
	
	
	if($it618_brand_goods['it618_saletype']==1){
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s1002').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="1"></div>';
	}
	
	if($it618_brand_goods['it618_saletype']==2){
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s1003').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="2"></div>';
	}
	
	if($it618_brand_goods['it618_saletype']==3){
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s1223').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="3"></div>';
	}
	
	if($it618_brand_goods['it618_saletype']==4){
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" onclick="setselect(\'saletype\',0,1)" name="saletype"><span>'.it618_brand_getlang('s1002').'</span><i></i></a><a href="javascript:void(0)" onclick="setselect(\'saletype\',1,2)" name="saletype"><span>'.it618_brand_getlang('s1003').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="1"></div>';
	}
	
	if($it618_brand_goods['it618_saletype']==5){
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s1654').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="5"></div>';
	}
	
	if($it618_brand_goods['it618_saletype']==6){	
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_brand_getlang('s855').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="6"></div>';
	}
	
	$pingoodsname=$it618_brand_goods['it618_name'];
	$pingoodsabout=$it618_brand_goods['it618_seodescription'];

	$goodspic=it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig'],0);
	$producturl=it618_brand_getrewrite('brand_wap','product@'.$it618_brand_goods['it618_shopid'].'@0@'.$pid.'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$it618_brand_goods['it618_shopid'].'&cid='.$pid);
	
	$it618_brand_goods_type = C::t('#it618_brand#it618_brand_goods_type')->fetch_by_id($typeid);
	$it618_price='<em>&yen;</em>'.$it618_brand_goods_type['it618_uprice'];
	
	$goodsaboutstr='<font color="red">'.$it618_brand_goods_type['it618_name'].$it618_brand_goods_type['it618_name1'].'</font>';
	
	if($it618_pinedu_goods['it618_xgcount']>1){
		$tmpxgstr=$it618_pinedu_lang['s73'].$it618_pinedu_goods['it618_xgcount'].$it618_pinedu_lang['s74'];
	}else{
		$istype6=1;	
	}
	
	if($_GET['e']!=''){
		$pinurl=$_G['siteurl'].it618_brand_getrewrite('brand_wap','pin@'.$it618_brand_goods['it618_shopid'].'@'.$typeid.'@'.$spid.'@0','plugin.php?id=it618_brand:wap&pagetype=pin&sid='.$it618_brand_goods['it618_shopid'].'&oid='.$typeid.'&cid='.$spid.'&e='.$_GET['e'],'?e='.$_GET['e']);
	}else{
		$pinurl=$_G['siteurl'].it618_brand_getrewrite('brand_wap','pin@'.$it618_brand_goods['it618_shopid'].'@'.$typeid.'@'.$spid.'@0','plugin.php?id=it618_brand:wap&pagetype=pin&sid='.$it618_brand_goods['it618_shopid'].'&oid='.$typeid.'&cid='.$spid);
	}

	$qrcodesrc='plugin.php?id=it618_brand:urlcode&url='.urlencode($pinurl);
	
}

if($shoptype=='tuan'){
	if($_GET['pagetype']!='pin')require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
	
	$typetitle=$it618_pinedu_lang['s69'];
	
	$pid=$it618_pinedu_goods['it618_pid'];
	if($it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid)){
		$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_goods['it618_shopid']);
		if($it618_tuan_shop['it618_state']!=2||$it618_tuan_shop['it618_htstate']!=1){
			echo $it618_pinedu_lang['s80'];exit;
		}
		if($it618_tuan_shop['it618_uid']==$_G['uid']){
			$isshop=1;
		}
	}
	
	if($isshop!=1){
		if($it618_tuan_goods['it618_ison']!=1||$it618_tuan_goods['it618_state']!=1){
			echo $it618_pinedu_lang['s80'];exit;
		}
	}
	
	if(($it618_tuan_goods['it618_saletype']==2 || $it618_tuan_goods['it618_saletype']==4) && $it618_tuan_goods['it618_isyunfeifree']==0){
		$isyunfei=1;
		
		$kdcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_kdyunfei')." where it618_shopid=".$it618_tuan_goods['it618_shopid']);
		$shopid=$it618_tuan_goods['it618_shopid'];
		$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_kdarea')." ORDER BY it618_order");
		$n1=1;
		$tmp1='';
		while($it618_tmp1 = DB::fetch($query)) {
			if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_tuan_kdyunfei')." where it618_shopid=".$shopid." and it618_kdareaid=".$it618_tmp1['id'])>0){
				$kdarea.='<option value='.$it618_tmp1['id'].'>'.$it618_tmp1['it618_name'].'</option>';
				$n2=1;
				$query2 = DB::query("SELECT * FROM ".DB::table('it618_tuan_kdyunfei')." where it618_shopid=".$shopid." and it618_order<>0 and it618_kdareaid=".$it618_tmp1['id']." ORDER BY it618_order");
	
				while($it618_tmp2 =	DB::fetch($query2)) {
					
					$kdname=C::t('#it618_tuan#it618_tuan_kd')->fetch_name_by_id($it618_tmp2['it618_kdid']);
					
					if($it618_tmp2['it618_firstprice']>0&&$it618_tmp2['it618_firstscore']>0){
						$goodsjfname=$_G['setting']['extcredits'][$it618_tmp2['it618_jfid']]['title'];
						$goodspricestr1='\u00A5'.$it618_tmp2['it618_firstprice'].' + '.$it618_tmp2['it618_firstscore'].$goodsjfname;
						$goodspricestr2='\u00A5'.$it618_tmp2['it618_price'].' + '.$it618_tmp2['it618_score'].$goodsjfname;
					}else{
						if($it618_tmp2['it618_firstprice']>0){
							$goodspricestr1='\u00A5'.$it618_tmp2['it618_firstprice'];
							$goodspricestr2='\u00A5'.$it618_tmp2['it618_price'];
						}
						
						if($it618_tmp2['it618_firstscore']>0){
							$goodsjfname=$_G['setting']['extcredits'][$it618_tmp2['it618_jfid']]['title'];
							$goodspricestr1=$it618_tmp2['it618_firstscore'].$goodsjfname;
							$goodspricestr2=$it618_tmp2['it618_score'].$goodsjfname;
						}
					}
					
					$tmp1.='select_kd['.$n1.']['.$n2.'] = new Option("'.$kdname.' '.$it618_tmp2['it618_firstcount'].$it618_tuan_goods['it618_unit'].it618_tuan_getlang('s755').' '.$goodspricestr1.' '.it618_tuan_getlang('s756').'1'.$it618_tuan_goods['it618_unit'].' '.it618_tuan_getlang('s757').' '.$goodspricestr2.'", "'.$it618_tmp2['id'].'");';
	
					$n2=$n2+1;
				}
				$n1=$n1+1;
			}
		}
		
		$kdjs='var arrcount='.$kdcount.';
			var select_kd = new Array(arrcount+1);
			
			for (i=0; i<arrcount+1; i++) 
			{
			 select_kd[i] = new Array();
			}
			
			'.$tmp1.'
			
			function redirec_kd(x)
			{
			 var temp = document.getElementById("it618_kd"); 
			 temp.options.length=1;
			 for (i=1;i<select_kd[x].length;i++)
			 {
			  temp.options[i]=new Option(select_kd[x][i].text,select_kd[x][i].value);
			 }
			 temp.options[0].selected=true;
			
			}';
	}
	
	
	if($it618_tuan_goods['it618_saletype']==1){
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_tuan_getlang('s719').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="1"></div>';
	}
	
	if($it618_tuan_goods['it618_saletype']==2){
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_tuan_getlang('s720').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="2"></div>';
	}
	
	if($it618_tuan_goods['it618_saletype']==3){
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" name="saletype"><span>'.it618_tuan_getlang('s836').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="3"></div>';
	}
	
	if($it618_tuan_goods['it618_saletype']==4){
		$it618_saletype='<div class="selectdiv"><a class="current" href="javascript:void(0)" onclick="setselect(\'saletype\',0,1)" name="saletype"><span>'.it618_tuan_getlang('s719').'</span><i></i></a><a href="javascript:void(0)" onclick="setselect(\'saletype\',1,2)" name="saletype"><span>'.it618_tuan_getlang('s720').'</span><i></i></a><input type="hidden" id="saletype" name="it618_saletype" value="1"></div>';
	}
	
	if($it618_tuan_goods['it618_isservice1']==1)$service.=it618_tuan_getlang('s107').' ';
	if($it618_tuan_goods['it618_isservice2']==1)$service.=it618_tuan_getlang('s108').' ';
	if($it618_tuan_goods['it618_isservice3']==1)$service.=it618_tuan_getlang('s109').' ';
	
	if($it618_tuan_goods['it618_saletype']!=3){
		$goodsthdid=0;
		if(!($it618_tuan_goods['it618_saletype']==2&&$it618_tuan_goods['it618_isthd']==0)){
			$n=1;
			foreach(C::t('#it618_tuan#it618_tuan_goods_thd')->fetch_allok_by_pid($pid) as $it618_tuan_goods_thd) {
				$tmpstr='';
				$goodsthdstr.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodsthd\','.$n.','.$it618_tuan_goods_thd['id'].')" name="goodsthd"><span>'.$it618_tuan_goods_thd['it618_name'].'</span><i></i></a>';
				$n++;
			}
			if($goodsthdstr!='')$goodsthdstr='<a class="current" href="javascript:void(0)" onclick="setselect(\'goodsthd\',0,0)" name="goodsthd"><span>'.$it618_tuan_shop['it618_name'].'('.$it618_tuan_lang['s1722'].')</span><i></i></a>'.$goodsthdstr;
		}
	}
	
	$pingoodsname=$it618_tuan_goods['it618_name'];
	$pingoodsabout=$it618_tuan_goods['it618_description'];

	$goodspic=it618_tuan_getgoodspic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig'],0);
	$producturl=it618_tuan_getrewrite('tuan_wap','product@'.$pid,'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$pid);
	
	$it618_tuan_goods_type = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_id($typeid);
	$it618_price=it618_pinedu_getgoodsprice1($it618_tuan_goods_type);
	
	$goodsaboutstr='<font color="red">'.$it618_tuan_goods_type['it618_name'].$it618_tuan_goods_type['it618_name1'].'</font>';
	
	if($it618_pinedu_goods['it618_xgcount']>1){
		$tmpxgstr=$it618_pinedu_lang['s73'].$it618_pinedu_goods['it618_xgcount'].$it618_pinedu_lang['s74'];
	}else{
		$istype6=1;	
	}
	
	if($_GET['e']!=''){
		$pinurl=$_G['siteurl'].it618_tuan_getrewrite('tuan_wap','pin@'.$typeid.'@'.$spid,'plugin.php?id=it618_brand:wap&pagetype=pin&cid1='.$typeid.'&cid2='.$spid.'&e='.$_GET['e'],'?e='.$_GET['e']);
	}else{
		$pinurl=$_G['siteurl'].it618_tuan_getrewrite('tuan_wap','pin@@'.$typeid.'@'.$spid,'plugin.php?id=it618_brand:wap&pagetype=pin&cid1='.$typeid.'&cid2='.$spid);
	}

	$qrcodesrc='plugin.php?id=it618_tuan:urlcode&url='.urlencode($pinurl);
	
}

$ispay=1;
if($spid==0){
	$mantimecout=$it618_pinedu_lang['s83'];
	$mantimecout=str_replace("{mancount}",$it618_pinedu_goods['it618_mancount'],$mantimecout);
	$mantimecout=str_replace("{timecount}",it618_pinedu_gettime1($it618_pinedu_goods['it618_timecount']*60),$mantimecout);
	$btntitle=$it618_pinedu_lang['s153'];
	$btntitle1=$it618_pinedu_lang['s153'];
	$btnconfirm=$it618_pinedu_lang['s154'];
}else{
	$btntitle=$it618_pinedu_lang['s155'];
	$btntitle1=$it618_pinedu_lang['s155'];
	$btnconfirm=$it618_pinedu_lang['s156'];
	
	if($it618_pinedu_sale_pin['it618_state']==1){
		$mancount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_pinedu_sale')." WHERE it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
		
		$mantimecout=$it618_pinedu_lang['s94'];
		$mantimecout=str_replace("{mancount}",$it618_pinedu_sale_pin['it618_mancount']-$mancount,$mantimecout);
		$mantimecout=str_replace("{timecount}",it618_pinedu_gettime($it618_pinedu_sale_pin['it618_btime']+$it618_pinedu_sale_pin['it618_timecount']*60),$mantimecout);
		
		if(C::t('#it618_pinedu#it618_pinedu_sale')->count_by_spid_uid($it618_pinedu_sale_pin['id'],$_G['uid'])>0){
			$ispay=0;
			if($it618_pinedu_sale_pin['it618_uid']==$_G['uid']){
				$statestr=$it618_pinedu_lang['s113'];
			}else{
				$statestr=$it618_pinedu_lang['s114'];	
			}
		}
	}
	
	if($it618_pinedu_sale_pin['it618_state']==2){
		$mantimecout=$it618_pinedu_lang['s95'];
		$ispay=0;
	}
	
	if($it618_pinedu_sale_pin['it618_state']==3){
		$mancount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_pinedu_sale')." WHERE it618_state=6 and it618_spid=".$it618_pinedu_sale_pin['id']);
		
		$mantimecout=$it618_pinedu_lang['s96'];
		$mantimecout=str_replace("{mancount}",$mancount,$mantimecout);
		$ispay=0;
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale')." where it618_state>0 and it618_spid=".$it618_pinedu_sale_pin['id']);
	while($it618_pinedu_sale = DB::fetch($query)) {
		$u_avatarimg=it618_pinedu_discuz_uc_avatar($it618_pinedu_sale['it618_uid'],'middle');
		$uname=it618_pinedu_getusername($it618_pinedu_sale['it618_uid']);
		if($it618_pinedu_sale['it618_uid']==$it618_pinedu_sale_pin['it618_uid']){
			$aboutstr1=$it618_pinedu_lang['s107'];
			$aboutstr2=$it618_pinedu_lang['s119'];
		}else{
			$aboutstr1='';
			$aboutstr2=$it618_pinedu_lang['s120'];	
		}
		
		if($wap==1){ 
			$pinsalestr.='<tr><td>
			<img src="'.$u_avatarimg.'" class="imguser"/>
			<div>'.$uname.' <span>'.$aboutstr1.'</span><p>'.date('Y-m-d H:i', $it618_pinedu_sale['it618_time']).' '.$aboutstr2.'</p></div>
			</td></tr><tr><td class="tdline"></td></tr>';
		}else{
			$pinsalestr.='<li>
			<img src="'.$u_avatarimg.'" class="imguser"/>
			<div>'.$uname.' <span>'.$aboutstr1.'</span><p>'.date('Y-m-d H:i', $it618_pinedu_sale['it618_time']).' '.$aboutstr2.'</p></div>
			</li>';
		}
	}
	
	$sd_userpower=C::t('#it618_pinedu#it618_pinedu_set')->getsetvalue_by_setname('sd_userpower');
	$sd_userpower=explode(",",$sd_userpower);
	if(in_array($_G['uid'],$sd_userpower)&&$_G['uid']>0){
		$sdbtn='onclick="salesd()"';
	}
}

if($shoptype=='brand'||$shoptype=='tuan'){
	$btntitle1=$it618_pinedu_lang['s232'];
}

$mantimecout1=strip_tags($mantimecout);
$goodspricestr1=strip_tags($goodspricestr);

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_pinedu/config/pinset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_pinedu/config/pinset.php';
}

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	if($shoptype=='video'){
		$wx_appid=trim($it618_video['video_appid']);
		$wx_secret=trim($it618_video['video_appsecret']);
	}
	if($shoptype=='exam'){
		$wx_appid=trim($it618_exam['exam_appid']);
		$wx_secret=trim($it618_exam['exam_appsecret']);
	}
	if($shoptype=='group'){
		$wx_appid=trim($it618_group['group_appid']);
		$wx_secret=trim($it618_group['group_appsecret']);
	}
	if($shoptype=='brand'){
		$wx_appid=trim($it618_brand['brand_appid']);
		$wx_secret=trim($it618_brand['brand_appsecret']);
	}
	if($shoptype=='tuan'){
		$wx_appid=trim($it618_tuan['tuan_appid']);
		$wx_secret=trim($it618_tuan['tuan_appsecret']);
	}
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){
	if($shoptype=='video'){
		$pluginname='it618_video';
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
		$wxshare_title=$goodspricestr1.' '.$mantimecout1.' '.$it618_video_goods['it618_name'];
		$wxshare_imgUrl=it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_video_goods['it618_description'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$pinurl;
	}
	
	if($shoptype=='exam'){
		$pluginname='it618_exam';
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);
		$wxshare_title=$goodspricestr1.' '.$mantimecout1.' '.$it618_exam_goods['it618_name'];
		$wxshare_imgUrl=it618_exam_getwapppic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_exam_goods['it618_description'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$pinurl;
	}
	
	if($shoptype=='group'){
		$pluginname='it618_group';
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($pid);
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);
	
		$wxshare_title=$goodspricestr1.' '.$mantimecout1.' '.$grouptitle.' '.$it618_unit;
		$wxshare_imgUrl=$it618_group_group['it618_ico'];
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_group_group['it618_power'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$pinurl;
	}
	
	if($shoptype=='brand'){
		$pluginname='it618_brand';
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);
		$wxshare_title=$goodspricestr1.' '.$mantimecout1.' '.$it618_brand_goods['it618_name'];
		$wxshare_imgUrl=it618_brand_getwapppic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_brand_goods['it618_description'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$pinurl;
	}
	
	if($shoptype=='tuan'){
		$pluginname='it618_tuan';
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid);
		$wxshare_title=$goodspricestr1.' '.$mantimecout1.' '.$it618_tuan_goods['it618_name'];
		$wxshare_imgUrl=it618_tuan_getwapppic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_tuan_goods['it618_description'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$pinurl;
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/'.$pluginname.'/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
	}
}

$_G['mobiletpl'][IN_MOBILE]='/'; /*dism��taobao��com*/
if($wap==1){ 
	include template('it618_pinedu:pin_wap');
}else{
	include template('it618_pinedu:pin');
}
//From: d'.'is'.'m.ta'.'obao.com
?>