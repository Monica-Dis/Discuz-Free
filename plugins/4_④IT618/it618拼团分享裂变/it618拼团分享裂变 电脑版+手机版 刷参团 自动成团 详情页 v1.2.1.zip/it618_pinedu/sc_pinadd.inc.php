<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/sc_header.func.php';

if($ShopType=='video'){
	$pluginname='it618_video';
	$aboutstr=$it618_pinedu_lang['s210'];
	$btntitle=$it618_pinedu_lang['s211'];
}

if($ShopType=='exam'){
	$pluginname='it618_exam';
	$aboutstr=$it618_pinedu_lang['s212'];
	$btntitle=$it618_pinedu_lang['s213'];
}

if($ShopType=='group'){
	$pluginname='it618_group';
	$aboutstr=$it618_pinedu_lang['s228'];
	$btntitle=$it618_pinedu_lang['s229'];
}

if($ShopType=='brand'){
	$pluginname='it618_brand';
	$aboutstr=$it618_pinedu_lang['s234'];
	$btntitle=$it618_pinedu_lang['s235'];
}

if($ShopType=='tuan'){
	$pluginname='it618_tuan';
	$aboutstr=$it618_pinedu_lang['s234'];
	$btntitle=$it618_pinedu_lang['s235'];
}

echo '<table class="tb tb2" style="clear: both;margin-top: 5px;width:100%;">
<tr><th colspan="15" class="partition">'.$it618_pinedu_lang['s1'].'</th></tr>
<tr><td colspan="15"><div style="font-size:20px;color:#0AF;margin-top:30px">'.$aboutstr.'<br><br><span onclick="location.href=\'plugin.php?id='.$pluginname.':sc_product'.$adminsid.'\'" style="display:block;height:40px;line-height:40px;width:188px;text-align:center;background-color:#0AF;color:#fff;font-size:14px;padding:0 33px;border-radius:3px;cursor:pointer">'.$btntitle.'</span></div></td></tr>
</table>';

require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/sc_footer.func.php';
?>