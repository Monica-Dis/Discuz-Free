<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/sc_header.func.php';

$pinid=intval($_GET['pinid']);
$typeid=intval($_GET['typeid']);
if($pinid>0){
	if($it618_pinedu_goods = C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_id($pinid)){
		if($ShopType=='group'){
			if($it618_pinedu_goods['it618_shoptype']!=$ShopType){
				it618_cpmsg(it618_pinedu_getlang('s10'), "", 'error');
			}
		}else{
			if($it618_pinedu_goods['it618_shoptype']!=$ShopType||$it618_pinedu_goods['it618_shopid']!=$ShopId){
				it618_cpmsg(it618_pinedu_getlang('s10'), "", 'error');
			}
		}
		$it618_xgcount=$it618_pinedu_goods['it618_xgcount'];
		if($it618_pinedu_goods['it618_isautopinok']==1)$it618_isautopinok_checked='checked="checked"';else $it618_isautopinok_checked="";
		$btnname=$it618_pinedu_lang['s44'];
	}else{
		it618_cpmsg(it618_pinedu_getlang('s9'), "", 'error');	
	}
}else{
	$it618_xgcount=1;
	$btnname=$it618_pinedu_lang['s43'];
}

if($ShopType=='video'){
	$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);
	$typeprice=it618_pinedu_getgoodsprice1($it618_video_goods_type);
	$jftypestr=it618_video_getjftype($it618_pinedu_goods['it618_jfid']);
	$it618_pid=$it618_video_goods_type['it618_pid'];
}

if($ShopType=='exam'){
	$it618_exam_goods_type = C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($typeid);
	$typeprice=it618_pinedu_getgoodsprice1($it618_exam_goods_type);
	$jftypestr=it618_exam_getjftype($it618_pinedu_goods['it618_jfid']);
	$it618_pid=$it618_exam_goods_type['it618_pid'];
}

if($ShopType=='group'){
	$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($typeid);
	$typeprice=it618_pinedu_getgoodsprice1($it618_group_goods);
	$jftypestr=it618_group_getjftype($it618_pinedu_goods['it618_jfid']);
	$it618_pid=$it618_group_goods['id'];
}

if($ShopType=='brand'){
	$it618_brand_goods_type = C::t('#it618_brand#it618_brand_goods_type')->fetch_by_id($typeid);
	$typeprice='<em>&yen;</em>'.$it618_brand_goods_type['it618_uprice'];
	$it618_pid=$it618_brand_goods_type['it618_pid'];
}

if($ShopType=='tuan'){
	$it618_tuan_goods_type = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_id($typeid);
	$typeprice=it618_pinedu_getgoodsprice1($it618_tuan_goods_type);
	$jftypestr=it618_tuan_getjftype($it618_pinedu_goods['it618_jfid']);
	$it618_pid=$it618_tuan_goods_type['it618_pid'];
}

if($jftypestr!=''){
	$it618_score='+<input type="text" class="txt" style="width:80px;margin-right:3px;;color:red" id="it618_score" name="it618_score" value="'.$it618_pinedu_goods['it618_score'].'"><select name="it618_jfid">'.$jftypestr.'</select>';
	$it618_score1='+<input type="text" class="txt" style="width:80px;margin-right:3px;;color:#f0f" id="it618_score1" name="it618_score1" value="'.$it618_pinedu_goods['it618_score1'].'"><select name="it618_jfid1">'.$jftypestr.'</select>';
}

if(submitcheck('it618submit')){	
	if($_GET['it618_xgcount']==0)$it618_xgcount=1;else $it618_xgcount=$_GET['it618_xgcount'];
	
	if($_GET['it618_jfid']==0)$it618_score=0;else $it618_score=$_GET['it618_score'];
	if($_GET['it618_jfid1']==0)$it618_score1=0;else $it618_score1=$_GET['it618_score1'];

	if($pinid>0){
		C::t('#it618_pinedu#it618_pinedu_goods')->update($pinid,array(
			'it618_time1' => $_GET['it618_time1'],
			'it618_time2' => $_GET['it618_time2'],
			'it618_price' => $_GET['it618_price'],
			'it618_jfid' => $_GET['it618_jfid'],
			'it618_score' => $it618_score,
			'it618_price1' => $_GET['it618_price1'],
			'it618_jfid1' => $_GET['it618_jfid1'],
			'it618_score1' => $it618_score1,
			'it618_mancount' => $_GET['it618_mancount'],
			'it618_timecount' => $_GET['it618_timecount'],
			'it618_isautopinok' => $_GET['it618_isautopinok'],
			'it618_xgcount' => $it618_xgcount
		), true);
		
		echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
		
	}else{
		$pinid=C::t('#it618_pinedu#it618_pinedu_goods')->insert(array(
			'it618_shoptype' => $ShopType,
			'it618_shopid' => $ShopId,
			'it618_pid' => $it618_pid,
			'it618_typeid' => $typeid,
			'it618_time1' => $_GET['it618_time1'],
			'it618_time2' => $_GET['it618_time2'],
			'it618_price' => $_GET['it618_price'],
			'it618_jfid' => $_GET['it618_jfid'],
			'it618_score' => $it618_score,
			'it618_price1' => $_GET['it618_price1'],
			'it618_jfid1' => $_GET['it618_jfid1'],
			'it618_score1' => $it618_score1,
			'it618_mancount' => $_GET['it618_mancount'],
			'it618_timecount' => $_GET['it618_timecount'],
			'it618_isautopinok' => $_GET['it618_isautopinok'],
			'it618_xgcount' => $it618_xgcount
		), true);
		
		it618_cpmsg(it618_pinedu_getlang('s36'), "plugin.php?id=it618_pinedu:sc_product$adminsid&pinid=$pinid&typeid=$typeid", 'succeed');
	}
}

it618_showformheader("plugin.php?id=it618_pinedu:sc_product$adminsid&pinid=$pinid&typeid=$typeid");
showtableheaders('','it618_pinedu_goods');

echo '
<script charset="utf-8" src="source/plugin/it618_pinedu/js/Calendar.js"></script>
<script>
	function checkvalue(){

		if(document.getElementById("it618_time1").value==""||document.getElementById("it618_time2").value==""){
			alert("'.it618_pinedu_getlang('s31').'");
			return false;
		}
		
		if(document.getElementById("it618_mancount").value==""){
			alert("'.it618_pinedu_getlang('s32').'");
			document.getElementById("it618_mancount").focus();
			return false;
		}
		
		if(document.getElementById("it618_timecount").value==""){
			alert("'.it618_pinedu_getlang('s33').'");
			document.getElementById("it618_timecount").focus();
			return false;
		}
		
		if(document.getElementById("it618_price").value==0&&document.getElementById("it618_score").value==0){
			alert("'.it618_pinedu_getlang('s34').'");
			return false;
		}
	}
</script>

<tr><td width=90>'.it618_pinedu_getlang('s11').'</td><td><font color=blue>'.it618_pinedu_getgoodspinabout($ShopType,$typeid).'</font></td></tr>

<tr><td>'.it618_pinedu_getlang('s12').'</td><td><input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_time1" name="it618_time1" readonly="readonly" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')" value="'.$it618_pinedu_goods['it618_time1'].'">- <input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_time2" name="it618_time2" readonly="readonly" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')" value="'.$it618_pinedu_goods['it618_time2'].'"> <font color=#999>'.$it618_pinedu_lang['s26'].'</font></td></tr>

<tr><td>'.it618_pinedu_getlang('s13').'</td><td><input type="text" class="txt" style="width:80px;margin-right:3px" id="it618_mancount" name="it618_mancount" value="'.$it618_pinedu_goods['it618_mancount'].'">'.$it618_pinedu_lang['s30'].' <font color=#999>'.$it618_pinedu_lang['s27'].'</font></td></tr>

<tr><td>'.it618_pinedu_getlang('s14').'</td><td><input type="text" class="txt" style="width:80px;margin-right:3px" id="it618_timecount" name="it618_timecount" value="'.$it618_pinedu_goods['it618_timecount'].'">'.$it618_pinedu_lang['s21'].' <font color=#999>'.$it618_pinedu_lang['s28'].'</font></td></tr>

<tr><td>'.it618_pinedu_getlang('s63').'</td><td><input type="checkbox" style="vertical-align:middle" id="it618_isautopinok" name="it618_isautopinok" value="1" '.$it618_isautopinok_checked.'> <font color=#999>'.$it618_pinedu_lang['s64'].'</font></td></tr>

<tr><td>'.it618_pinedu_getlang('s15').'</td><td><input type="text" class="txt" style="width:80px;margin-right:3px;color:red;" id="it618_price" name="it618_price" value="'.$it618_pinedu_goods['it618_price'].'">'.$it618_pinedu_lang['s226'].' '.$it618_score.' <font color=#999>'.$it618_pinedu_lang['s45'].'</font> <font color=red>'.$typeprice.'</font></td></tr>

<tr><td>'.it618_pinedu_getlang('s65').'</td><td><input type="text" class="txt" style="width:80px;margin-right:3px;color:#f0f;" id="it618_price1" name="it618_price1" value="'.$it618_pinedu_goods['it618_price1'].'">'.$it618_pinedu_lang['s226'].' '.$it618_score1.' <font color=#999>'.$it618_pinedu_lang['s66'].'</font></td></tr>

<tr><td>'.it618_pinedu_getlang('s16').'</td><td><input type="text" class="txt" style="width:80px;margin-right:0" name="it618_xgcount" value="'.$it618_xgcount.'"> <font color=#999>'.$it618_pinedu_lang['s29'].'</font></td></tr>
';

echo '<tr><td colspan=2><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.$btnname.'" /></div></td></tr>';

showtablefooter(); /*dism _ taobao _ com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/sc_footer.func.php';
?>