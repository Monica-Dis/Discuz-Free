<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_pinedu_base {
	function common_base() {
		global $_G,$it618_pinedu_lang;
		$cache_file = DISCUZ_ROOT.'./source/plugin/it618_pinedu/cache.php';
		$tmptime=10;
		
		if(($_G['timestamp'] - @filemtime($cache_file)) > $tmptime) {
			require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
			
			@$fp = fopen($cache_file,"w");
			fwrite($fp,$_G['timestamp']);
			fclose($fp);

			$query = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale_pin')." where it618_state=1");
			while($it618_pinedu_sale_pin = DB::fetch($query)) {
				
				if($it618_pinedu_sale_pin['it618_btime']+$it618_pinedu_sale_pin['it618_timecount']*60<$_G['timestamp']){
					
					$it618_pinedu_goods = C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_id($it618_pinedu_sale_pin['it618_pid']);
					
					$mancount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_pinedu_sale')." WHERE it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
					$tmpn=$it618_pinedu_sale_pin['it618_mancount']-$mancount;
					
					if($tmpn==0){
						if($it618_pinedu_sale_pin['it618_btime']+$it618_pinedu_sale_pin['it618_timecount']*60+180<$_G['timestamp']){
							$query = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale')." where it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
							while($it618_pinedu_sale = DB::fetch($query)) {
								it618_pinedu_pinok($it618_pinedu_sale,$it618_pinedu_goods['it618_typeid']);
							}
							DB::query("update ".DB::table('it618_pinedu_sale_pin')." set it618_state=3,it618_etime=".$_G['timestamp']." where id=".$it618_pinedu_sale_pin['id']);
						}
					}else{
						
						if($it618_pinedu_goods['it618_isautopinok']==1){
							$sd_saleuser=C::t('#it618_pinedu#it618_pinedu_set')->getsetvalue_by_setname('sd_saleuser');
							$sd_saleuserarr=explode(",",$sd_saleuser);
							
							if($tmpn<count($sd_saleuserarr)){
								
								$it618_time=DB::result_first("SELECT it618_time FROM ".DB::table('it618_pinedu_sale')." WHERE it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']." order by id desc");
								$it618_time1=$it618_pinedu_sale_pin['it618_btime']+$it618_pinedu_sale_pin['it618_timecount']*60-$it618_time;
								$it618_timeadd=intval($it618_time1/$tmpn);
								
								$num = 0; 
								$uidarr = array();  
								$tag = true; 
								while ($tag) { 
									$count = count($sd_saleuserarr); 
									$t = rand(0, 1); 
									if ($t == 1) { 
										 $uidarr[] = $sd_saleuserarr[$num]; 
										 unset($sd_saleuserarr[$num]); 
									} 
									$num ++; 
									if (count($uidarr) == $tmpn) { 
										$tag = false; 
									} 
									if ($num == $count) { 
										$num = 0;
									} 
								} 
								
								for($i=1;$i<$tmpn;$i++){
									$uid=$uidarr[$i];
									
									$id = C::t('#it618_pinedu#it618_pinedu_sale')->insert(array(
										'it618_spid' => $it618_pinedu_sale_pin['id'],
										'it618_pid' => $it618_pinedu_goods['id'],
										'it618_shoptype' => $it618_pinedu_sale_pin['it618_shoptype'],
										'it618_shopid' => $it618_pinedu_goods['it618_shopid'],
										'it618_uid' => $uid,
										'it618_count' => 1,
										'it618_price' => $it618_pinedu_sale_pin['it618_price'],
										'it618_jfid' => $it618_pinedu_sale_pin['it618_jfid'],
										'it618_score' => $it618_pinedu_sale_pin['it618_score'],
										'it618_state' => 1,
										'it618_time' => $it618_time+$it618_timeadd*$i
									), true);
								}
							}
						}
						
						$query = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale')." where it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
						while($it618_pinedu_sale = DB::fetch($query)) {
							
							if($it618_pinedu_goods['it618_isautopinok']==1&&$tmpn<count($sd_saleuserarr)){
								it618_pinedu_pinok($it618_pinedu_sale,$it618_pinedu_goods['it618_typeid']);
							}else{
								if($it618_pinedu_sale['it618_score']>0){
									C::t('common_member_count')->increase($it618_pinedu_sale['it618_uid'], array(
										'extcredits'.$it618_pinedu_sale['it618_jfid'] => $it618_pinedu_sale['it618_score']*$it618_pinedu_sale['it618_count'])
									);
								}
								
								if($it618_pinedu_sale['it618_price']>0){
									$money=$it618_pinedu_sale['it618_price']*$it618_pinedu_sale['it618_count'];
				
									if($it618_pinedu_sale['it618_shoptype']=='video'){
										$it618_bz=$it618_pinedu_lang['s84'];
										$it618_zytype='it618_video_pintk';
									}
									if($it618_pinedu_sale['it618_shoptype']=='exam'){
										$it618_bz=$it618_pinedu_lang['s85'];
										$it618_zytype='it618_exam_pintk';
									}
									if($it618_pinedu_sale['it618_shoptype']=='group'){
										$it618_bz=$it618_pinedu_lang['s158'];
										$it618_zytype='it618_group_pintk';
									}
									if($it618_pinedu_sale['it618_shoptype']=='brand'){
										$it618_bz=$it618_pinedu_lang['s236'];
										$it618_zytype='it618_brand_pintk';
									}
									if($it618_pinedu_sale['it618_shoptype']=='tuan'){
										$it618_bz=$it618_pinedu_lang['s236'];
										$it618_zytype='it618_tuan_pintk';
									}
									
									$it618_bz=str_replace("{money}",$money,$it618_bz);
									$it618_bz=str_replace("{saleid}",$it618_pinedu_sale['id'],$it618_bz);
									
									require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
									savemoney(array(
										'it618_uid' => $it618_pinedu_sale['it618_uid'],
										'it618_type' => 'zy',
										'it618_money1' => $money,
										'it618_bz' => $it618_bz,
										'it618_zytype' => $it618_zytype,
										'it618_zyid' => $it618_pinedu_sale['id'],
										'it618_time' => $_G['timestamp']
									));
								}
								
								DB::query("update ".DB::table('it618_pinedu_sale')." set it618_state=2 where id=".$it618_pinedu_sale['id']);
							}
						}
						
						if($it618_pinedu_goods['it618_isautopinok']==1&&$tmpn<count($sd_saleuserarr)){
							DB::query("update ".DB::table('it618_pinedu_sale_pin')." set it618_state=3,it618_etime=".$_G['timestamp']." where id=".$it618_pinedu_sale_pin['id']);
						}else{
							DB::query("update ".DB::table('it618_pinedu_sale_pin')." set it618_state=2,it618_etime=".$_G['timestamp']." where id=".$it618_pinedu_sale_pin['id']);
						}
					}
					
					it618_pinedu_updatepingoods($it618_pinedu_goods['id']);
					
				}
			}
		}
		
	}
}

class plugin_it618_pinedu extends plugin_it618_pinedu_base{
	function common() {
		$this->common_base();
	}
}

class mobileplugin_it618_pinedu extends plugin_it618_pinedu_base{
	function common() {
		$this->common_base();
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>