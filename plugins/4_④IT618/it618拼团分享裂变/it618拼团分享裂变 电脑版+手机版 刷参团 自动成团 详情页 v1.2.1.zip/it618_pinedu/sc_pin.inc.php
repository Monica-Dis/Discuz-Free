<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/sc_header.func.php';

$it618sql='1=1';
if($_GET['mancount']>0){
	$it618sql.=' and it618_mancount='.intval($_GET['mancount']);	
}
$state0='';$state1='';$state2='';$state3='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and UNIX_TIMESTAMP(it618_time1) >".$_G['timestamp'];$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and UNIX_TIMESTAMP(it618_time1) <".$_G['timestamp']." and UNIX_TIMESTAMP(it618_time2)>".$_G['timestamp'];$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and UNIX_TIMESTAMP(it618_time2) <".$_G['timestamp'];$state3='selected="selected"';}

$type0='';$type1='';$type2='';
if($_GET['type']==0){$type0='selected="selected"';}
if($_GET['type']==1){$it618sql .= " and it618_isautopinok = 1";$type1='selected="selected"';}
if($_GET['type']==2){$it618sql .= " and it618_isautopinok = 0";$type2='selected="selected"';}

$urlsql='&mancount='.$_GET['mancount'].'&type='.$_GET['type'].'&state='.$_GET['state'];

if(submitcheck('it618submit1')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		C::t('#it618_pinedu#it618_pinedu_goods')->update($delid,array(
			'it618_isautopinok' => 1
		));

		$ok=$ok+1;
	}

	it618_cpmsg(it618_pinedu_getlang('s193').$ok, "plugin.php?id=it618_pinedu:sc_pin$adminsid&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit2')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		C::t('#it618_pinedu#it618_pinedu_goods')->update($delid,array(
			'it618_isautopinok' => 0
		));

		$ok=$ok+1;
	}

	it618_cpmsg(it618_pinedu_getlang('s194').$ok, "plugin.php?id=it618_pinedu:sc_pin$adminsid&page=$page".$sql, 'succeed');
}

it618_showformheader("plugin.php?id=it618_pinedu:sc_pin$adminsid");
showtableheaders(it618_pinedu_getlang('s195'),'it618_pinedu_sum');
	echo '<tr><td colspan=14>'.it618_pinedu_getlang('s173').' <input name="mancount" value="'.$_GET['mancount'].'" class="txt" style="width:58px" /> '.it618_pinedu_getlang('s174').' <select name="type"><option value="0" '.$type0.'>'.it618_pinedu_getlang('s196').'</option><option value="1" '.$type1.'>'.it618_pinedu_getlang('s175').'</option><option value="2" '.$type2.'>'.it618_pinedu_getlang('s176').'</option></select> '.it618_pinedu_getlang('s177').' <select name="state"><option value="0">'.it618_pinedu_getlang('s196').'</option><option value=1 '.$state1.'>'.it618_pinedu_getlang('s178').'</option><option value=2 '.$state2.'>'.it618_pinedu_getlang('s179').'</option><option value=3 '.$state3.'>'.it618_pinedu_getlang('s180').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_pinedu_getlang('s181').'" /></td></tr>';
	
	$count = C::t('#it618_pinedu#it618_pinedu_goods')->count_by_shoptype_shopid($ShopType,$ShopId,$it618sql);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_pinedu:sc_pin$adminsid".$urlsql);
	
	echo '<tr><td colspan=15>'.it618_pinedu_getlang('s186').$count.'<span style="float:right;">'.it618_pinedu_getlang('s187').'</span></td></tr>';
	showsubtitle(array('',it618_pinedu_getlang('s183'),it618_pinedu_getlang('s185'),it618_pinedu_getlang('s184')));
	
	$n=1;
	foreach(C::t('#it618_pinedu#it618_pinedu_goods')->fetch_all_by_shoptype_shopid(
		$ShopType,$ShopId,$it618sql,'id desc',$startlimit,$ppp
	) as $it618_pinedu_goods) {
		
		$pid=$it618_pinedu_goods['it618_pid'];
		if($it618_pinedu_goods['it618_shoptype']=='video'){
			require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
			$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
			$goodspic=it618_video_getgoodspic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig'],0);
			$goodsname=$it618_video_goods['it618_name'];
			$typeid=$it618_pinedu_goods['it618_typeid'];
			
			$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);
			$it618_price=it618_pinedu_getgoodsprice1($it618_video_goods_type);
			
			if($it618_video_goods_type['it618_timetype']==1)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s21'];
			if($it618_video_goods_type['it618_timetype']==2)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s22'];
			if($it618_video_goods_type['it618_timetype']==3)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s23'];
			if($it618_video_goods_type['it618_timetype']==4)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s24'];
			if($it618_video_goods_type['it618_timetype']==5)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s25'];
			if($it618_video_goods_type['it618_timetype']==6)$time=$it618_pinedu_lang['s20'];
			
			$lid=$it618_video_goods_type['it618_lid'];
			$vid=$it618_video_goods_type['it618_vid'];
			$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);
			
			$goodsaboutstr='<font color=#999>'.$goodsabout['about'].'</font><br><font color="red">'.$goodsabout['type'].'*'.$time.'</font>';
			
			$tmpurl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);
		}
		
		if($it618_pinedu_goods['it618_shoptype']=='exam'){
			require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
			$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);
			$goodspic=it618_exam_getgoodspic($it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig'],0);
			$goodsname=$it618_exam_goods['it618_name'];
			$typeid=$it618_pinedu_goods['it618_typeid'];
			
			$it618_exam_goods_type = C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($typeid);
			$it618_price=it618_pinedu_getgoodsprice1($it618_exam_goods_type);
			
			$goodsaboutstr='<font color=#999>'.$it618_exam_goods['it618_description'].'</font><br><font color="red">'.$it618_exam_goods_type['it618_name'].'</font>';
			
			$tmpurl=it618_exam_getrewrite('exam_product',$pid,'plugin.php?id=it618_exam:product&pid='.$pid);
		}
		
		if($it618_pinedu_goods['it618_shoptype']=='group'){
			require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
			$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($pid);
			$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
			$it618_unit=it618_group_getgoodsunit($it618_group_goods);

			$goodspic=$it618_group_group['it618_ico'];
			$goodsname=$grouptitle.' '.$it618_unit;
			$typeid=$it618_pinedu_goods['it618_typeid'];
			
			$it618_price=it618_pinedu_getgoodsprice1($it618_group_goods);
			
			$goodsaboutstr='<font color=#999>'.$it618_group_group['it618_power'].'</font>';
			
			$tmpurl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
		}
		
		if($it618_pinedu_goods['it618_shoptype']=='brand'){
			require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);
			$goodspic=it618_brand_getgoodspic($it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig'],0);
			$goodsname=$it618_brand_goods['it618_name'];
			$typeid=$it618_pinedu_goods['it618_typeid'];
			
			$it618_brand_goods_type = C::t('#it618_brand#it618_brand_goods_type')->fetch_by_id($typeid);
			$it618_price='<em>&yen;</em>'.$it618_brand_goods_type['it618_uprice'];
			
			$goodsaboutstr='<font color=#999>'.$it618_brand_goods['it618_seodescription'].'</font><br><font color="red">'.$it618_brand_goods_type['it618_name'].$it618_brand_goods_type['it618_name1'].'</font>';
			
			$tmpurl=it618_brand_getrewrite('shop_product',$it618_brand_goods['it618_shopid'].'@'.$pid,'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$pid);
		}
		
		if($it618_pinedu_goods['it618_shoptype']=='tuan'){
			require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid);
			$goodspic=it618_tuan_getgoodspic($it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig'],0);
			$goodsname=$it618_tuan_goods['it618_name'];
			$typeid=$it618_pinedu_goods['it618_typeid'];
			
			$it618_tuan_goods_type = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_id($typeid);
			$it618_price=it618_pinedu_getgoodsprice1($it618_tuan_goods_type);
			
			$goodsaboutstr='<font color=#999>'.$it618_tuan_goods['it618_description'].'</font><br><font color="red">'.$it618_tuan_goods_type['it618_name'].$it618_tuan_goods_type['it618_name1'].'</font>';
			
			$tmpurl=it618_tuan_getrewrite('tuan_product',$pid,'plugin.php?id=it618_tuan:product&pid='.$pid);
		}
		
		$goodspricestr=it618_pinedu_getgoodsprice($it618_pinedu_goods);	
		$goodspricestr1=it618_pinedu_getgoodsprice($it618_pinedu_goods,'1');
		
		$mantimecout=$it618_pinedu_lang['s83'];
		$mantimecout=str_replace("{mancount}",$it618_pinedu_goods['it618_mancount'],$mantimecout);
		$mantimecout=str_replace("{timecount}",it618_pinedu_gettime1($it618_pinedu_goods['it618_timecount']*60),$mantimecout);
		
		$it618_isautopinok=$it618_pinedu_lang['s176'];
		if($it618_pinedu_goods['it618_isautopinok']==1){
			$it618_isautopinok='<font color="#390">'.$it618_pinedu_lang['s175'].'</font>';
		}
		
		$it618_xgcount=$it618_pinedu_lang['s188'].$it618_pinedu_goods['it618_xgcount'];
		
		$goodspin=it618_pinedu_getgoodspinstate($it618_pinedu_goods['it618_shoptype'],$typeid);
		$goodspinstr=' <a href="javascript:" onclick="showgoodspin('.$goodspin['id'].','.$typeid.')"><font color=blue>'.$goodspin['name'].'</font>'.$goodspin['count'].'</a>';
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_pinedu_goods['id'].'" '.$disabled.'><label for="chk_del'.$n.'">'.$it618_pinedu_goods['id'].'</label>',
			'<div style="width:630px">
			<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$goodspic.'" height="58" style="margin-right:6px" align="absmiddle"/></a>
			<div style="width:498px;float:left;line-height:20px">'.$goodsname.'<br>'.$goodsaboutstr.'
			</div>',
			'<div style="line-height:20px">'.$mantimecout.'<br>'.$it618_isautopinok.' '.$it618_xgcount.'<br>'.$goodspricestr.'/'.$it618_price.'</div>',
			'<div style="line-height:20px">'.$it618_pinedu_goods['it618_time1'].' '.$it618_pinedu_goods['it618_time2'].'<br>'.$goodspinstr.'<br><a href="javascript:" onclick="showpinsale('.$it618_pinedu_goods['id'].')"><font color=#666>'.$it618_pinedu_lang['s209'].'</font></a></div>',
		));
				
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_pinedu_getlang('s238').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit1" value="'.it618_pinedu_getlang('s189').'" onclick="return confirm(\''.it618_pinedu_getlang('s191').'\')" /> <input type="submit" class="btn" name="it618submit2" value="'.it618_pinedu_getlang('s190').'" onclick="return confirm(\''.it618_pinedu_getlang('s192').'\')" /><input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	
echo '
	<script>
	function showgoodspin(pinid,typeid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_pinedu_lang['s5'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["930px", "430px"],
			content: "plugin.php?id=it618_pinedu:sc_product'.$adminsid.'&shoptype='.$ShopType.'&pinid="+pinid+"&typeid="+typeid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	</script>
	';
echo '
	<script>
	function showpinsale(pinid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_pinedu_lang['s171'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_pinedu:sc_pinsale'.$adminsid.'&shoptype='.$ShopType.'&type=win&pinid="+pinid,
			cancel: function(index, layero){ 

			}    
		});
	}
	</script>
	';


showtablefooter(); /*dism _ taobao _ com*/

require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/sc_footer.func.php';
?>