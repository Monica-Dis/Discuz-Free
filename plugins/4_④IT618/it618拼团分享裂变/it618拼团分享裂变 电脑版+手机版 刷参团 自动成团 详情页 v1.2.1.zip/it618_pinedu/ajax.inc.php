<?php
ob_start();
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';

$uid = $_G['uid'];

if($_GET['ac']=="getpinsale"){
	$pid=intval($_GET['pid']);
	$tmpwidth=intval($_GET['width']);
	$shoptype=$_GET['shoptype'];
		
	if($shoptype!='video'&&$shoptype!='exam'&&$shoptype!='group'&&$shoptype!='brand'&&$shoptype!='tuan'){
		echo $it618_pinedu_lang['s80'];exit;
	}
	
	if($tmpwidth>0){
		$tmpwidth=' style="width:'.($tmpwidth-43).'px"';
	}else{
		$tmpwidth='';	
	}

	$query = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale_pin')." where it618_shoptype='$shoptype' and it618_state=1 and it618_pid=$pid order by id");
	while($it618_pinedu_sale_pin = DB::fetch($query)) {
		$u_avatarimg=it618_pinedu_discuz_uc_avatar($it618_pinedu_sale_pin['it618_uid'],'middle');
		$userstr='<img src="'.$u_avatarimg.'" class="userpin"/>';
		
		$mancount=0;$userstr1='';
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale')." where it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
		while($it618_pinedu_sale = DB::fetch($query1)) {
			if($it618_pinedu_sale['it618_uid']!=$it618_pinedu_sale_pin['it618_uid']){
				$u_avatarimg=it618_pinedu_discuz_uc_avatar($it618_pinedu_sale['it618_uid'],'middle');
				$userstr1.='<img src="'.$u_avatarimg.'" class="userpinsale"/>';
			}
			$mancount=$mancount+1;
		}
		
		$userstr1.='<img src="source/plugin/it618_pinedu/images/pinsale.png" class="userpinsale" style="margin-bottom:-3px"/>';
			
		$mantimecout=$it618_pinedu_lang['s94'];
		$mantimecout=str_replace("{mancount}",$it618_pinedu_sale_pin['it618_mancount']-$mancount,$mantimecout);
		$mantimecout=str_replace("{timecount}",it618_pinedu_gettime($it618_pinedu_sale_pin['it618_btime']+$it618_pinedu_sale_pin['it618_timecount']*60),$mantimecout);
			
		$salestr.='<li'.$tmpwidth.'>
					<span class="pinsaleuser">'.$it618_pinedu_lang['s107'].'</span>
					<span class="pinsaleabout">'.$mantimecout.'</span>
					<span class="pinsalemore" onclick="showpin(0,'.$it618_pinedu_sale_pin['id'].')">'.$it618_pinedu_lang['s108'].'</span>
					'.$userstr.'
					<span class="pinusers">'.$userstr1.'</span>
					<a href="javascript:" class="pinsalebtn" onclick="showpin(0,'.$it618_pinedu_sale_pin['id'].')">'.$it618_pinedu_lang['s109'].'</a>
					</li>';
	}
	
	if($salestr!='')$salestr='<ul>'.$salestr.'</ul>';
	
	echo 'it618_split'.$pid.'it618_split'.$salestr;exit;
}

if($_GET['formhash']!=FORMHASH)exit;


if($_GET['ac']=="getpay"){
	if($uid>0){
		$spid=intval($_GET['spid']);
		$typeid=intval($_GET['typeid']);
		$it618_count=intval($_GET['it618_count']);
		$shoptype=$_GET['shoptype'];
		
		if($shoptype!='video'&&$shoptype!='exam'&&$shoptype!='group'&&$shoptype!='brand'&&$shoptype!='tuan'){
			echo $it618_pinedu_lang['s80'];exit;
		}
		
		if($spid==0){
			if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_shoptype_typeid($shoptype,$typeid)){
				echo $it618_pinedu_lang['s80'];exit;
			}
			
			if($it618_pinedu_goods['it618_price1']>0||$it618_pinedu_goods['it618_score1']>0){
				$goods_price=$it618_pinedu_goods['it618_price1'];
				$goods_jfid=$it618_pinedu_goods['it618_jfid1'];
				$goods_score=$it618_pinedu_goods['it618_score1'];
			}else{
				$goods_price=$it618_pinedu_goods['it618_price'];
				$goods_jfid=$it618_pinedu_goods['it618_jfid'];
				$goods_score=$it618_pinedu_goods['it618_score'];
			}
		}else{
			if(!$it618_pinedu_sale_pin=C::t('#it618_pinedu#it618_pinedu_sale_pin')->fetch_by_id($spid)){
				echo $it618_pinedu_lang['s80'];exit;
			}
			
			$goods_price=$it618_pinedu_sale_pin['it618_price'];
			$goods_jfid=$it618_pinedu_sale_pin['it618_jfid'];
			$goods_score=$it618_pinedu_sale_pin['it618_score'];
			
			$it618_pinedu_goods = C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_id($it618_pinedu_sale_pin['it618_pid']);
		}

		if($shoptype=='video'){
			$it618_video = $_G['cache']['plugin']['it618_video'];
			$creditname=$_G['setting']['extcredits'][$it618_video['video_credit']]['title'];
			
			$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_pinedu_goods['it618_pid']);
			
			if($it618_video['video_saletel']==2){
				$isbd='ok';
				if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
					$tel=$it618_members_user['it618_tel'];
				}else{
					echo 'it618_splittelbd';exit;
				}
			}else{
				$tel=C::t('#it618_video#it618_video_sale')->fetch_tel_by_uid($_G['uid']);
			}
			
			if($it618_video_goods['it618_jfbl']>0&&$goods_price>0){
				$jfbl='<font color=#888>'.$it618_pinedu_lang['s70'].'<font color=red>'.$it618_video_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
			}
		}
		
		if($shoptype=='exam'){
			$it618_exam = $_G['cache']['plugin']['it618_exam'];
			$creditname=$_G['setting']['extcredits'][$it618_exam['exam_credit']]['title'];
			
			$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_pinedu_goods['it618_pid']);
			
			if($it618_exam['exam_saletel']==2){
				$isbd='ok';
				if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
					$tel=$it618_members_user['it618_tel'];
				}else{
					echo 'it618_splittelbd';exit;
				}
			}else{
				$tel=C::t('#it618_video#it618_video_sale')->fetch_tel_by_uid($_G['uid']);
			}
			
			if($it618_exam_goods['it618_jfbl']>0&&$goods_price>0){
				$jfbl='<font color=#888>'.$it618_pinedu_lang['s70'].'<font color=red>'.$it618_exam_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
			}
		}
		
		if($shoptype=='group'){
			$it618_group = $_G['cache']['plugin']['it618_group'];
			$creditname=$_G['setting']['extcredits'][$it618_group['group_credit']]['title'];
			
			$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_pinedu_goods['it618_pid']);
			
			if($it618_group_goods['it618_jfbl']>0&&$goods_price>0){
				$jfbl='<font color=#888>'.$it618_pinedu_lang['s70'].'<font color=red>'.$it618_group_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
			}
		}
		
		if($shoptype=='brand'){
			require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
			
			$it618_brand = $_G['cache']['plugin']['it618_brand'];
			$creditname=$_G['setting']['extcredits'][$it618_brand['brand_credit']]['title'];
			
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_pinedu_goods['it618_pid']);
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
			
			if($it618_brand_goods['it618_jfbl']>0){
				$jfbl='<font color=#888>'.$it618_pinedu_lang['s70'].'<font color=red>'.$it618_brand_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
			}
			
			if($_GET['it618_saletype']==2){
				if($_GET['it618_kdid']>0){
					$it618_brand_kdyunfei=C::t('#it618_brand#it618_brand_kdyunfei')->fetch_by_id($_GET['it618_kdid']);
					
					if($it618_brand_goods['it618_isalipay']==1){
						if($it618_brand_goods['it618_kgbl']>0&&$it618_brand_brand['it618_isyunfeikg']==1){
							if($it618_count*$it618_brand_goods['it618_kgbl']>$it618_brand_kdyunfei['it618_firstkg']){
								$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice']+$it618_brand_kdyunfei['it618_kgprice']*($it618_count*$it618_brand_goods['it618_kgbl']-$it618_brand_kdyunfei['it618_firstkg']);
							}else{
								$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice'];
							}
						}else{
							if($it618_count>$it618_brand_kdyunfei['it618_firstcount']){
								$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice']+$it618_brand_kdyunfei['it618_price']*($it618_count-$it618_brand_kdyunfei['it618_firstcount']);
							}else{
								$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice'];
							}
						}
					}
					
				}
				
				$n=1;
				$iscurcount=C::t('#it618_brand#it618_brand_addr')->count_by_it618_uid($uid);
				foreach(C::t('#it618_brand#it618_brand_addr')->fetch_all_by_it618_uid($uid) as $it618_brand_addr) {
					$it618_name=$it618_brand_addr['it618_name'];
					$it618_addr=$it618_brand_addr['it618_addr'];
					$it618_yzbm=$it618_brand_addr['it618_yzbm'];
					$it618_tel=$it618_brand_addr['it618_tel'];
					$it618_qq=$it618_brand_addr['it618_qq'];
					
					if($it618_brand_addr['it618_iscur']==0){
						$strtmp='';
					}else{
						$strtmp='checked="checked"';
					}
					if($iscurcount==0&&$n==1)$strtmp='checked="checked"';
					if($n%2==0){
						$strcss='<tr>';
					}else{
						$strcss='<tr class="odd">';
					}
					
					if($_GET['wap']==1){
					$addr_get.=$strcss.'
								 <td><label class="test-label">
									  <input type="radio" '.$strtmp.' name="it618_addr" class="test-radio" style="vertical-align:middle;"/>
									  <span class="test-radioInput"></span>'.$it618_name.'
									  </lable>
								 </td>
								 <td>'.$it618_addr.'</td>
								 <td>'.$it618_tel.'<input type="hidden" id="it618_addrid'.($n-1).'" title="'.$it618_tel.'" value="'.$it618_brand_addr['id'].'"/></td>
								 </tr>';
					}else{
						$addr_get.=$strcss.'
								 <td><input type="radio" '.$strtmp.' name="it618_addr"/></td>
								 <td style="text-align:center;">'.$it618_name.'</td>
								 <td>'.$it618_addr.'</td>
								 <td>'.$it618_tel.'<input type="hidden" id="it618_addrid'.($n-1).'" title="'.$it618_tel.'" value="'.$it618_brand_addr['id'].'"/></td>
								 </tr>';
					}
								 
					$n=$n+1;
				}
				
				if($addr_get==""){
					$isaddr=1;
				}
			}else{
				$tel=C::t('#it618_brand#it618_brand_sale')->fetch_tel_by_uid($_G['uid']);
				
				if($tel==''){
					if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_members'")>0){
						if($it618_members_user=DB::fetch_first("SELECT it618_tel FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){					
							$tel=$it618_members_user['it618_tel'];
						}
					}
				}
			}
			
			if($_GET['it618_saletype']==2){
				if($_GET['wap']==1){
					$tmpaddrstr='<tr><td style="padding-bottom:0px;padding-top:8px">'.$it618_brand_lang['t215'].'<span style="float:right; font-weight:normal; cursor:pointer; color:#390" onclick="addrset();">'.$it618_brand_lang['t216'].'</span></td></tr>
						<tr><td style="padding:0">
							<table cellspacing="0" cellpadding="0" class="jf_tb">
								 <thead>
								 <tr>
								 <th width="58">'.$it618_brand_lang['t218'].'</th>
								 <th>'.$it618_brand_lang['t219'].'</th>
								 <th width="68">'.$it618_brand_lang['t467'].'</th>
								 </tr>
								 </thead>
								 <tbody>'.$addr_get.'</tbody>
							 </table>
						</td></tr>';
				}else{
					$tmpaddrstr='<tr><td style="padding-bottom:0px">'.$it618_brand_lang['t215'].'<span style="float:right; font-weight:normal; cursor:pointer; color:#390" onclick="parent.document.getElementById(\'tmpaddrbtn\').click();parent.layer.closeAll();">'.$it618_brand_lang['t216'].'</span></td></tr>
						<tr><td>
						<table cellspacing="0" cellpadding="0" class="jf_tb">
							 <thead>
							 <tr>
							 <th width="30">'.$it618_brand_lang['t217'].'</th>
							 <th width="90" style="text-align:center;">'.$it618_brand_lang['t218'].'</th>
							 <th>'.$it618_brand_lang['t219'].'</th>
							 <th width="90">'.$it618_brand_lang['t467'].'</th>
							 </tr>
							 </thead>
							 <tbody>'.$addr_get.'</tbody>
						 </table>
						</td></tr>';
				}
			}else{
				$tmpaddrstr='<tr><td>'.$it618_brand_lang['s635'].'<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:100px" value="'.$tel.'" /></td></tr>';
			}
			
			$tmpaddrstr.='<tr><td style="padding-bottom:0px; padding-top:8px">'.$it618_brand_lang['t222'].'</td></tr>
						<tr><td style="padding-bottom:0px"><textarea id="it618_bz" name="it618_bz" class="txtarea" style="width:99%; border:#e8e8e8 1px solid; height:58px"></textarea></td></tr>';
						
		}
		
		if($shoptype=='tuan'){
			require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
			
			$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
			$creditname=$_G['setting']['extcredits'][$it618_tuan['tuan_credit']]['title'];
			
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_pinedu_goods['it618_pid']);
			$it618_tuan_shop = C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_brand_goods['it618_shopid']);
			
			if($it618_tuan_goods['it618_jfbl']>0){
				$jfbl='<font color=#888>'.$it618_pinedu_lang['s70'].'<font color=red>'.$it618_tuan_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
			}
			
			$name=C::t('#it618_tuan#it618_tuan_sale')->fetch_name_by_uid($_G['uid']);
			$tel=C::t('#it618_tuan#it618_tuan_sale')->fetch_tel_by_uid($_G['uid']);
			$addr=C::t('#it618_tuan#it618_tuan_sale')->fetch_addr_by_uid($_G['uid']);
			
			if($_GET['it618_kdid']>0){
				$it618_tuan_kdyunfei=C::t('#it618_tuan#it618_tuan_kdyunfei')->fetch_by_id($_GET['it618_kdid']);
				if($it618_count>$it618_tuan_kdyunfei['it618_firstcount']){
					$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice']+$it618_tuan_kdyunfei['it618_price']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
					$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore']+$it618_tuan_kdyunfei['it618_score']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
				}else{
					$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice'];
					$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore'];
				}
				
				if($yunfeiscore>0){
					$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
					$sumscore[$yunfeijfid]+=$yunfeiscore;
				}
			}
			
			if($_GET['it618_saletype']==2){
			$tmpaddrstr='<tr><td style="padding:0">
					<table class="adrrtable">
					<tr><th width="80">'.$it618_tuan_lang['t343'].'</th><th>'.$it618_tuan_lang['t205'].'</th><th width="82">'.$it618_tuan_lang['t196'].'</th></tr>
					<tr>
					<td><input type="text" class="txt" style="width:61px" id="it618_name" name="it618_name" value="'.$name.'"/> </td>
					<td><input type="text" class="txt" style="width:93%" id="it618_addr" name="it618_addr" value="'.$addr.'"/></td>
					<td><input type="text" class="txt" style="width:80px" id="it618_tel" name="it618_tel" value="'.$tel.'" /></td>
					</tr>
					</table>';
			}else{
			$tmpaddrstr='<tr><td> '.$it618_tuan_lang['t196'].': <input type="text" class="txt" id="it618_tel" name="it618_tel" maxlength="11"  value="'.$tel.'" /></td></tr>';
			}
			$tmpaddrstr.='<tr><td style="padding-bottom:0px; padding-top:8px">'.$it618_tuan_lang['t206'].'</td></tr>';
			$tmpaddrstr.='<tr><td style="padding-bottom:0px"><textarea id="it618_bz" name="it618_bz" class="txtarea" style="width:99%; border:#e8e8e8 1px solid; height:58px"></textarea></td></tr>';
		}
		
		if($_GET['it618_saletype']==6){
			$prepaybl=$it618_brand_goods['it618_prepaybl']/100;
		}else{
			$prepaybl=1;
		}
		
		$yfmoney=round(($goods_price*$it618_count*$prepaybl),2)+$yunfeimoney;

		if($goods_score>0){
			$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
			$sumscore[$goods_jfid]+=$goods_score*$it618_count;
		}
		
		for($i=1;$i<=8;$i++){
			if($sumscore[$i]>0){
				$jfname=$_G['setting']['extcredits'][$i]['title'];
				
				$scorestr.=$sumscore[$i].$jfname.' + ';
				
				$creditnum=C::t('#it618_pinedu#it618_pinedu_sale')->fetch_extcredits_by_uid($i,$_G['uid']);
				if($creditnum=="")$creditnum=0;
				$jfcounttmp.='<font color="red">'.$creditnum.'</font>'.$jfname;
			}
		}
		
		if($scorestr!=''){
			$scorestr.='@';
			$scorestr=str_replace(' + @',"",$scorestr);
			
			$jfcountstr=$it618_pinedu_lang['s71'].' '.$jfcounttmp;
		}
		
		if($yfmoney>0&&$scorestr!=''){
			$yfmoneystr='<input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'"><em>&yen;</em><span id="yfmoney">'.$yfmoney.'</span>'.' + '.$scorestr;
			$moneyscore=1;
		}else{
			if($yfmoney>=0){
				$yfmoneystr='<input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'"><em>&yen;</em><span id="yfmoney">'.$yfmoney.'</span>';
			}
			if($scorestr!=''){
				$yfmoneystr=$scorestr;
			}
		}
		
		if($yfmoney>0){
			if($_GET['wap']==1){
				$it618paystr=it618_pinedu_pay('paywap',$it618_pinedu_lang['s78']);
			}else{
				$it618paystr=it618_pinedu_pay('pay',$it618_pinedu_lang['s78']);
			}
		}
		
		if($yfmoneystr!=''){
			if($_GET['wap']==1){
				$getpaystr.='
				<tr>
				<td width="80">'.$it618_pinedu_lang['s77'].'</td>
				<td class="tdyfmoney">
				<span class="yfmoney">'.$yfmoneystr.'</span><input type="hidden" id="moneyscore" value="'.$moneyscore.'" />
				<div>'.$jfbl.$jfcountstr.'</div>
				</td>
				</tr>';
			}else{
				$getpaystr.='
				<tr>
				<td width="80">'.$it618_pinedu_lang['s77'].'</td>
				<td class="tdyfmoney">
				<span style="float:right">'.$jfbl.$jfcountstr.'</span><span class="yfmoney">'.$yfmoneystr.'</span><input type="hidden" id="moneyscore" value="'.$moneyscore.'" />
				</td>
				</tr>';
			}
		}
		
		if($shoptype!='group'&&$shoptype!='brand'&&$shoptype!='tuan'){
			if($isbd!='ok'){
				$getpaystr.='
				<tr>
				<td>'.$it618_pinedu_lang['s75'].'</td>
				<td>
				<input type="text" class="txt" id="it618_tel" name="it618_tel" maxlength="11"  value="'.$tel.'" /> '.$it618_pinedu_lang['s76'].'
				</td>
				</tr>';
			}else{
				$getpaystr.='<input type="hidden" class="txt" id="it618_tel" name="it618_tel" maxlength="11"  value="'.$tel.'" />';
			}
		}
		
		echo 'it618_splitokit618_split'.$getpaystr.$it618paystr.'it618_split'.$tmpaddrstr;
	}
	exit;
}


if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo it618_pinedu_getlang('s91');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);

		if(lang('plugin/it618_pinedu', $it618_pinedu_lang['it618'])!=$it618_pinedu_lang['version'])exit;

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_pinedu_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_pinedu_delsalework();
			}
		}
		C::t('#it618_pinedu#it618_pinedu_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$spid=intval($_GET['spid']);
		$typeid=intval($_GET['typeid']);
		$it618_count=intval($_GET['it618_count']);
		$shoptype=$_GET['shoptype'];
		
		if($shoptype!='video'&&$shoptype!='exam'&&$shoptype!='group'&&$shoptype!='brand'&&$shoptype!='tuan'){
			echo $it618_pinedu_lang['s80'];it618_pinedu_delsalework();exit;
		}
		
		if($spid==0){
			if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_shoptype_typeid($shoptype,$typeid)){
				echo $it618_pinedu_lang['s80'];it618_pinedu_delsalework();exit;
			}
			
			$timetmp2=explode(" ",$it618_pinedu_goods['it618_time2']);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			if($_G['timestamp']>$etime){
				echo $it618_pinedu_lang['s160'];it618_pinedu_delsalework();exit;
			}
			
			if($it618_pinedu_goods['it618_price1']>0||$it618_pinedu_goods['it618_score1']>0){
				$goods_price=$it618_pinedu_goods['it618_price1'];
				$goods_jfid=$it618_pinedu_goods['it618_jfid1'];
				$goods_score=$it618_pinedu_goods['it618_score1'];
			}else{
				$goods_price=$it618_pinedu_goods['it618_price'];
				$goods_jfid=$it618_pinedu_goods['it618_jfid'];
				$goods_score=$it618_pinedu_goods['it618_score'];
			}
			
			$goods_price_pin=$it618_pinedu_goods['it618_price'];
			$goods_jfid_pin=$it618_pinedu_goods['it618_jfid'];
			$goods_score_pin=$it618_pinedu_goods['it618_score'];
			
		}else{
			if(!$it618_pinedu_sale_pin=C::t('#it618_pinedu#it618_pinedu_sale_pin')->fetch_by_id($spid)){
				echo $it618_pinedu_lang['s80'];it618_pinedu_delsalework();exit;
			}
			
			if($it618_pinedu_sale_pin['it618_state']==2){
				echo 'it618_splitreloadit618_split'.$it618_pinedu_lang['s110'];it618_pinedu_delsalework();exit;
			}
				
			if($it618_pinedu_sale_pin['it618_state']==3){
				echo 'it618_splitreloadit618_split'.$it618_pinedu_lang['s92'];it618_pinedu_delsalework();exit;
			}
			
			if($it618_pinedu_sale_pin['it618_uid']==$uid){
				echo it618_pinedu_getlang('s111');it618_pinedu_delsalework();exit;
			}
			
			if(C::t('#it618_pinedu#it618_pinedu_sale')->count_by_spid_uid($it618_pinedu_sale_pin['id'],$uid)>0){
				echo it618_pinedu_getlang('s112');it618_pinedu_delsalework();exit;
			}
			
			$goods_price=$it618_pinedu_sale_pin['it618_price'];
			$goods_jfid=$it618_pinedu_sale_pin['it618_jfid'];
			$goods_score=$it618_pinedu_sale_pin['it618_score'];
			
			$it618_pinedu_goods = C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_id($it618_pinedu_sale_pin['it618_pid']);
			$typeid=$it618_pinedu_goods['it618_typeid'];
		}
		
		if($it618_count<=0){
			echo it618_pinedu_getlang('s79');it618_pinedu_delsalework();exit;
		}

		if($shoptype=='video'){
			$it618_video = $_G['cache']['plugin']['it618_video'];
			require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
			
			$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);
			$pid=$it618_video_goods_type['it618_pid'];
			$lid=$it618_video_goods_type['it618_lid'];
			$vid=$it618_video_goods_type['it618_vid'];
			
			$goods_count=$it618_video_goods_type['it618_count'];
			
			if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
				echo it618_video_getlang('s487');it618_pinedu_delsalework();exit;
			}
			
			$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
			if($it618_video_shop['it618_issale']!=1){
				echo it618_video_getlang('s513');it618_pinedu_delsalework();exit;
			}
			
			if(!it618_video_issecretok($it618_video_goods)){
				echo it618_video_getlang('s487');it618_pinedu_delsalework();exit;
			}
			
			if($IsGroup==1){
				$salepower=it618_video_groupsalepower($pid);
				if($salepower==1){
					echo it618_video_getlang('s1554');it618_pinedu_delsalework();exit;
				}
				if($salepower==2){
					echo it618_video_getlang('s1555');it618_pinedu_delsalework();exit;
				}
			}
			
			if($it618_video['video_certtype']==1){
				if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
					echo $it618_video['video_certtip'];it618_pinedu_delsalework();exit;
				}
			}
			
			if($it618_video['video_certtype']==2){
				$tmparr=explode("|",trim($it618_video['video_cert']));
				$tmparr[0]=str_replace('pre_','',$tmparr[0]);
				if(DB::result_first("SELECT count(1) FROM ".DB::table($tmparr[0])." where ".$tmparr[1]."='".$tmparr[2]."' and ".$tmparr[3]."=".$uid)==0){
					echo $it618_video['video_certtip'];it618_pinedu_delsalework();exit;
				}
			}
			
			$videopower_sale=it618_video_getpower_sale($uid,$pid,$lid,$vid);
			if($videopower_sale['state']==1){
				echo $videopower_sale['about'];it618_pinedu_delsalework();exit;
			}
			
			if($it618_video_goods_type['it618_counttype']==1){
				if($it618_count>$goods_count){
					echo it618_video_getlang('s1138');it618_pinedu_delsalework();exit;
				}
				
				if($it618_video_goods_type['it618_xgtime']==0){
					$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_video_sale')." where it618_gtypeid=".$typeid." and it618_state=1 and it618_uid=".$uid);
				}else{
					$time=$_G['timestamp']-$it618_video_goods_type['it618_xgtime']*3600*24;
					
					$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_video_sale')." where it618_gtypeid=".$typeid." and it618_time>$time and it618_state=1 and it618_uid=".$uid);
				}
				if($buycount=='')$buycount=0;
				
				if($it618_video_goods_type['it618_xgcount']>0&&$it618_count>$it618_video_goods_type['it618_xgcount']-$buycount){
					if($it618_video_goods_type['it618_xgtime']==0){
						echo it618_video_getlang('s1139').$it618_video_goods_type['it618_xgcount'].it618_video_getlang('s1140').$buycount.it618_video_getlang('s1141');it618_pinedu_delsalework();exit;
					}else{
						echo it618_video_getlang('s1142').$it618_video_goods_type['it618_xgtime'].it618_video_getlang('s1143').$it618_video_goods_type['it618_xgcount'].it618_video_getlang('s1140').$buycount.it618_video_getlang('s1141');it618_pinedu_delsalework();exit;
					}
				}
			}
			
			$it618_jfbl=$it618_video_goods['it618_jfbl'];
			if($it618_jfbl>0){
				$creditnum=C::t('#it618_pinedu#it618_pinedu_sale')->fetch_extcredits_by_uid($it618_video['video_credit'],$it618_video_shop['it618_uid']);
				if($creditnum=="")$creditnum=0;
		
				if($creditnum<$it618_video_shop['it618_score']){
					$shopname=$it618_video_shop['it618_name'];
					$tmpstr=str_replace("{shopname}",$shopname,it618_video_getlang('s1084'));
					$tmpstr=str_replace("{creditname}",$creditname,$tmpstr);
					echo $tmpstr;it618_pinedu_delsalework();exit;
				}
			}
			
			$yfmoney=$goods_price*$it618_count;
			
			if($goods_score>0){
				$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
				$yfscore=$goods_score*$it618_count;
	
				$creditnum=DB::result_first("select extcredits".$goods_jfid." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				if($creditnum<$yfscore){
					echo it618_video_getlang('s1121').$creditnum.$goodsjfname.it618_video_getlang('s1122');it618_pinedu_delsalework();exit;
				}
			}
		}
		
		if($shoptype=='exam'){
			$it618_exam = $_G['cache']['plugin']['it618_exam'];
			require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
			
			$it618_exam_goods_type = C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($typeid);
			$pid=$it618_exam_goods_type['it618_pid'];
			
			$goods_count=$it618_exam_goods_type['it618_count'];
			if($it618_count>$goods_count){
				echo it618_exam_getlang('s1138');it618_pinedu_delsalework();exit;
			}
			
			if($it618_exam['exam_certtype']==1){
				if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
					echo $it618_exam['exam_certtip'];it618_pinedu_delsalework();exit;
				}
			}
			
			if($it618_exam['exam_certtype']==2){
				$tmparr=explode("|",trim($it618_exam['exam_cert']));
				$tmparr[0]=str_replace('pre_','',$tmparr[0]);
				if(DB::result_first("SELECT count(1) FROM ".DB::table($tmparr[0])." where ".$tmparr[1]."='".$tmparr[2]."' and ".$tmparr[3]."=".$uid)==0){
					echo $it618_exam['exam_certtip'];it618_pinedu_delsalework();exit;
				}
			}
			
			if(!($it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id_state($pid,1))){
				echo it618_exam_getlang('s487');it618_pinedu_delsalework();exit;
			}
			
			if(!it618_exam_issecretok($it618_exam_goods)){
				echo it618_exam_getlang('s487');it618_pinedu_delsalework();exit;
			}
			
			if($IsGroup==1){
				$salepower=it618_exam_groupsalepower($pid);
				if($salepower==1){
					echo it618_exam_getlang('s1554');it618_pinedu_delsalework();exit;
				}
				if($salepower==2){
					echo it618_exam_getlang('s1555');it618_pinedu_delsalework();exit;
				}
			}
			
			$typecount=C::t('#it618_exam#it618_exam_goods_type')->counttype_by_pid_ok($pid);
			if($typecount>0){
				if($typeid==0){
					echo it618_exam_getlang('s1136');it618_pinedu_delsalework();exit;
				}
			}
			
			if($it618_count>$goods_count){
				echo it618_exam_getlang('s1138');it618_pinedu_delsalework();exit;
			}
			
			if($it618_exam_goods_type['it618_xgtime']==0){
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_exam_sale')." where it618_gtypeid=".$typeid." and it618_state=1 and it618_uid=".$uid);
			}else{
				$time=$_G['timestamp']-$it618_exam_goods_type['it618_xgtime']*3600*24;
				
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_exam_sale')." where it618_gtypeid=".$typeid." and it618_time>$time and it618_state=1 and it618_uid=".$uid);
			}
			if($buycount=='')$buycount=0;
			
			if($it618_exam_goods_type['it618_xgcount']>0&&$it618_count>$it618_exam_goods_type['it618_xgcount']-$buycount){
				if($it618_exam_goods_type['it618_xgtime']==0){
					echo it618_exam_getlang('s1139').$it618_exam_goods_type['it618_xgcount'].it618_exam_getlang('s1140').$buycount.it618_exam_getlang('s1141');it618_pinedu_delsalework();exit;
				}else{
					echo it618_exam_getlang('s1142').$it618_exam_goods_type['it618_xgtime'].it618_exam_getlang('s1143').$it618_exam_goods_type['it618_xgcount'].it618_exam_getlang('s1140').$buycount.it618_exam_getlang('s1141');it618_pinedu_delsalework();exit;
				}
			}
			
			$it618_jfbl=$it618_exam_goods['it618_jfbl'];
			if($it618_jfbl>0){
				$it618_exam_shop=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($it618_exam_goods['it618_shopid']);
				$creditnum=C::t('#it618_exam#it618_exam_sale')->fetch_extcredits_by_uid($it618_exam['exam_credit'],$it618_exam_shop['it618_uid']);
				if($creditnum=="")$creditnum=0;
		
				if($creditnum<$it618_exam_shop['it618_score']){
					$shopname=$it618_exam_shop['it618_name'];
					$tmpstr=str_replace("{shopname}",$shopname,it618_exam_getlang('s1084'));
					$tmpstr=str_replace("{creditname}",$creditname,$tmpstr);
					echo $tmpstr;it618_pinedu_delsalework();exit;
				}
			}
			
			$yfmoney=$goods_price*$it618_count;
			
			if($goods_score>0){
				$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
				$yfscore=$goods_score*$it618_count;
	
				$creditnum=DB::result_first("select extcredits".$goods_jfid." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				if($creditnum<$yfscore){
					echo it618_exam_getlang('s1121').$creditnum.$goodsjfname.it618_exam_getlang('s1122');it618_pinedu_delsalework();exit;
				}
			}
		}
		
		if($shoptype=='group'){
			$it618_group = $_G['cache']['plugin']['it618_group'];
			require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
			
			$pid=$typeid;
			
			if($it618_count<=0){
				echo it618_group_getlang('s155');it618_pinedu_delsalework();exit;
			}
			
			if(!($it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id_state($pid,1))){
				echo it618_group_getlang('s141');it618_pinedu_delsalework();exit;
			}
			
			$goods_count=$it618_group_goods['it618_count'];
			
			if($it618_group_goods['it618_counttype']==1){
				if($goods_count<$it618_count){
					echo it618_group_getlang('s328');it618_pinedu_delsalework();exit;
				}
			
				if($it618_group_goods['it618_xgcount']>0){
					$countstr=$it618_group_lang['s216'];
					$countstr=str_replace("{xgcount}",$it618_group_goods['it618_xgcount'],$countstr);
					
					$tomonth = date('n'); 
					$todate = date('j'); 
					$toyear = date('Y');
					$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
					$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_group_sale')." where it618_pid=".$it618_group_goods['id']." and it618_time>$time and it618_state=1");
					
					if($it618_group_goods['it618_xgcount']-$buycount<$it618_count){		
						echo $countstr;it618_pinedu_delsalework();exit;
					}
				}
			}
			
			$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
			
			if($it618_group_group['it618_pbuids']!=''){
				$pbuidsarr=explode(",",$it618_group_group['it618_pbuids']);
				if(in_array($uid,$pbuidsarr)){
					echo $it618_group_lang['s398'];it618_pinedu_delsalework();exit;
				}
			}
			
			$yfmoney=$goods_price*$it618_count;
			
			if($goods_score>0){
				$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
				$yfscore=$goods_score*$it618_count;
	
				$creditnum=DB::result_first("select extcredits".$goods_jfid." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				if($creditnum<$yfscore){
					echo it618_group_getlang('s158').$creditnum.$goodsjfname.it618_group_getlang('s159');it618_pinedu_delsalework();exit;
				}
			}
			
			$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
			$groupterms = dunserialize($memberfieldforum['groupterms']);
			unset($memberfieldforum);
			
			if(!empty($groupterms['ext'])) {
				foreach($groupterms['ext'] as $extgroupid => $time) {
					if($it618_group_goods['it618_groupid']==$extgroupid){
						if($time-3600*24*365*60>$_G['timestamp']){
							echo it618_group_getlang('s181');it618_pinedu_delsalework();exit;
						}
						break;
					}
				}
			}
		}
		
		if($shoptype=='brand'){
			$it618_brand = $_G['cache']['plugin']['it618_brand'];
			require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
			
			$it618_brand_goods_type = C::t('#it618_brand#it618_brand_goods_type')->fetch_by_id($typeid);
			$pid=$it618_brand_goods_type['it618_pid'];
			
			$it618_saletype=intval($_GET['it618_saletype']);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);
			
			if(C::t('#it618_brand#it618_brand_brand')->count_by_id($it618_brand_goods['it618_shopid'])>0){
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
				$it618_state=$it618_brand_brand['it618_state'];
				if($it618_state==0){
					echo it618_brand_getlang('s380');it618_pinedu_delsalework();exit;
				}elseif($it618_state==1){
					echo it618_brand_getlang('s380');it618_pinedu_delsalework();exit;
				}else{
					$it618_htstate=$it618_brand_brand['it618_htstate'];
					if($it618_htstate==0){
						echo it618_brand_getlang('s381');it618_pinedu_delsalework();exit;
					}elseif($it618_htstate==2){
						echo it618_brand_getlang('s382');it618_pinedu_delsalework();exit;
					}else{
						$ShopId=$it618_brand_brand['id'];
						$ShopUid=$it618_brand_brand['it618_uid'];
						
						$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($it618_brand_brand['it618_power']);
						$Shop_score=$it618_brand_brandgroup['it618_score'];
					}
				}
				
			}else{
				echo it618_brand_getlang('s380');it618_pinedu_delsalework();exit;
			}
			
			if($it618_brand['brand_buyself']==0){
				if($ShopUid==$uid){
					echo it618_brand_getlang('s588');it618_pinedu_delsalework();exit;
				}
			}
			
			if($it618_brand['brand_bdtel']==1){
				if($it618_members['members_isok']!=''){
					$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid']);
					if($count==0){					
						echo $it618_brand_lang['s1887'];it618_pinedu_delsalework();exit;
					}
				}
			}
			
			if($it618_brand_goods['it618_saletype']==4){
				if(!($it618_saletype==1||$it618_saletype==2)){
					echo it618_brand_getlang('s1213');it618_pinedu_delsalework();exit;
				}
			}else{
				if($it618_saletype!=$it618_brand_goods['it618_saletype']){
					echo it618_brand_getlang('s1213');it618_pinedu_delsalework();exit;
				}
			}
			
			$typecount=C::t('#it618_brand#it618_brand_goods_type')->counttype_by_pid_ok($pid);
			if($typecount>0){
				if($typeid==0){
					echo it618_brand_getlang('t766');it618_pinedu_delsalework();exit;
				}
			}
			
			if($IsGroup==1){
				$salepower=it618_brand_groupsalepower($pid);
				if($salepower==1){
					echo it618_brand_getlang('s1969');it618_pinedu_delsalework();exit;
				}
				if($salepower==2){
					echo it618_brand_getlang('s1970');it618_pinedu_delsalework();exit;
				}
			}
			
			$it618_jfbl=$it618_brand_goods['it618_jfbl'];
			if($it618_jfbl>0){
				$creditnum=C::t('#it618_brand#it618_brand_sale')->fetch_extcredits_by_uid($it618_brand['brand_credit'],$ShopUid);
				if($creditnum=="")$creditnum=0;
		
				if($creditnum<$Shop_score){
					echo it618_brand_getlang('s1750');it618_pinedu_delsalework();exit;
				}
			}
	
			if($it618_brand_goods['it618_xiangoutime']==0){
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_brand_sale')." where it618_pid=".$pid." and it618_type!=0 AND it618_state!=5 and it618_uid=".$uid);
			}else{
				$time=$_G['timestamp']-$it618_brand_goods['it618_xiangoutime']*3600*24;
				
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_brand_sale')." where it618_pid=".$pid." and it618_time>$time and it618_type!=0 AND it618_state!=5 and it618_uid=".$uid);
			}
			
			if($buycount=='')$buycount=0;
			$goods_count=$it618_brand_goods_type['it618_count'];
			
			if($it618_count<=0){
				echo it618_brand_getlang('s485');it618_pinedu_delsalework();exit;
			}
			if($it618_count>$goods_count){
				echo it618_brand_getlang('s486');it618_pinedu_delsalework();exit;
			}elseif($it618_brand_goods['it618_xiangoucount']>0&&$it618_count>$it618_brand_goods['it618_xiangoucount']-$buycount){
				if($it618_brand_goods['it618_xiangoutime']==0){
					echo it618_brand_getlang('s1134').$it618_brand_goods['it618_xiangoucount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1139').$buycount.$it618_brand_goods['it618_punit'].it618_brand_getlang('s1140');it618_pinedu_delsalework();exit;
				}else{
					echo it618_brand_getlang('s1137').$it618_brand_goods['it618_xiangoutime'].it618_brand_getlang('s1138').$it618_brand_goods['it618_xiangoucount'].$it618_brand_goods['it618_punit'].it618_brand_getlang('s1139').$buycount.$it618_brand_goods['it618_punit'].it618_brand_getlang('s1140');it618_pinedu_delsalework();exit;
				}
			}
			
			$yunfeimoney=0;
			if($it618_saletype==2){
				if($_GET['it618_kdid']>0){
					$it618_brand_kdyunfei=C::t('#it618_brand#it618_brand_kdyunfei')->fetch_by_id($_GET['it618_kdid']);
					$it618_kdid=$it618_brand_kdyunfei['it618_kdid'];
					if($it618_brand_goods['it618_kgbl']>0){
						if($it618_count*$it618_brand_goods['it618_kgbl']>$it618_brand_kdyunfei['it618_firstkg']){
							$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice']+$it618_brand_kdyunfei['it618_kgprice']*($it618_count*$it618_brand_goods['it618_kgbl']-$it618_brand_kdyunfei['it618_firstkg']);
						}else{
							$yunfeimoney=$it618_brand_kdyunfei['it618_firstkgprice'];
						}
					}else{
						if($it618_count>$it618_brand_kdyunfei['it618_firstcount']){
							$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice']+$it618_brand_kdyunfei['it618_price']*($it618_count-$it618_brand_kdyunfei['it618_firstcount']);
						}else{
							$yunfeimoney=$it618_brand_kdyunfei['it618_firstprice'];
						}
					}
				}
			}
	
			$tmptime=$_G['timestamp'];
			if($it618_saletype==2){
				$it618_brand_addr = C::t('#it618_brand#it618_brand_addr')->fetch_by_id($_GET['it618_addrid']);
				$curaddr=it618_brand_getlang('s438').$it618_brand_addr['it618_name']." ".it618_brand_getlang('s439').$it618_brand_addr['it618_addr']." ".it618_brand_getlang('s440').$it618_brand_addr['it618_yzbm']." ".it618_brand_getlang('s441').$it618_brand_addr['it618_tel']." ".it618_brand_getlang('s442').$it618_brand_addr['it618_qq'];
				$it618_addr=$curaddr;
				$it618_addr1=$it618_brand_addr['it618_addr'];
				$it618_tel=$it618_brand_addr['it618_tel'];
			}else{
				$it618_addr='';
				$it618_addr1='';
				$it618_tel=$_GET['it618_tel'];
			}
	
			if($it618_saletype==6){
				$it618_prepaybl=$it618_brand_goods['it618_prepaybl'];
				$prepaybl=$it618_brand_goods['it618_prepaybl']/100;
			}else{
				$it618_prepaybl=100;
				$prepaybl=1;
			}
			
			$yfmoney=round(($goods_price*$it618_count*$prepaybl),2)+$yunfeimoney;
		}
		
		if($shoptype=='tuan'){
			$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
			require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
			
			$it618_tuan_goods_type = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_id($typeid);
			$pid=$it618_tuan_goods_type['it618_pid'];
			
			$it618_saletype=intval($_GET['it618_saletype']);
			$it618_gthdid=intval($_GET['it618_gthdid']);
			
			$goods_count=$it618_brand_goods_type['it618_count'];
			
			if($it618_count<=0){
				echo it618_tuan_getlang('s486');it618_pinedu_delsalework();exit;
			}
			
			if(!($it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id_state($pid,1))){
				echo it618_tuan_getlang('s487');it618_pinedu_delsalework();exit;
			}
			
			$typecount=C::t('#it618_tuan#it618_tuan_goods_type')->counttype_by_pid_ok($pid);
			if($typecount>0){
				if($typeid==0){
					echo it618_tuan_getlang('t766');it618_pinedu_delsalework();exit;
				}
			}
			
			if($goods_score>0){
				if(C::t('#it618_tuan#it618_tuan_jfhl')->count_by_jfid_isok($goods_jfid)==0){
					echo it618_tuan_getlang('s20');it618_pinedu_delsalework();exit;
				}
			}
	
			if($it618_saletype==1){
				if($it618_tuan_goods['it618_esaletime']!=''){
					$it618_esaletime=strtotime($it618_tuan_goods['it618_esaletime'].':00');
					if($_G['timestamp']>$it618_esaletime){
						echo it618_tuan_getlang('s488');it618_pinedu_delsalework();exit;
					}
				}
			}
			
			if($it618_tuan_goods['it618_saletype']==4){
				if(!($it618_saletype==1||$it618_saletype==2)){
					echo it618_tuan_getlang('s1093');it618_pinedu_delsalework();exit;
				}
			}else{
				if($it618_saletype!=$it618_tuan_goods['it618_saletype']){
					echo it618_tuan_getlang('s1093');it618_pinedu_delsalework();exit;
				}
			}
			
			if($it618_tuan_goods['it618_xgtime']==0){
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_tuan_sale')." where it618_pid=".$pid." and (it618_state=1 or it618_state=2 or it618_state=3) and it618_uid=".$uid);
			}else{
				$time=$_G['timestamp']-$it618_tuan_goods['it618_xgtime']*3600*24;
				
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_tuan_sale')." where it618_pid=".$pid." and it618_time>$time and (it618_state=1 or it618_state=2 or it618_state=3) and it618_uid=".$uid);
			}
			if($buycount=='')$buycount=0;
			
			if($it618_tuan_goods['it618_xgcount']>0&&$it618_count>$it618_tuan_goods['it618_xgcount']-$buycount){
				if($it618_tuan_goods['it618_xgtime']==0){
					echo it618_tuan_getlang('s489').$it618_tuan_goods['it618_xgcount'].it618_tuan_getlang('s490').$buycount.it618_tuan_getlang('s491');it618_pinedu_delsalework();exit;
				}else{
					echo it618_tuan_getlang('s492').$it618_tuan_goods['it618_xgtime'].it618_tuan_getlang('s493').$it618_tuan_goods['it618_xgcount'].it618_tuan_getlang('s490').$buycount.it618_tuan_getlang('s491');it618_pinedu_delsalework();exit;
				}
			}
			
			$it618_addr1 = it618_pinedu_utftogbk($_GET["it618_name"]);
			$it618_tel = it618_pinedu_utftogbk($_GET["it618_tel"]);
			$it618_addr = it618_pinedu_utftogbk($_GET["it618_addr"]);
			
			$it618_tuan_shop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($it618_tuan_goods['it618_shopid']);
			
			$creditnum=C::t('#it618_tuan#it618_tuan_sale')->fetch_extcredits_by_uid($it618_tuan['tuan_credit'],$it618_tuan_shop['it618_uid']);
			
	
			if($creditnum<$it618_tuan_shop['it618_score']){
				$shopname=$it618_tuan_shop['it618_name'];
				$tmpstr=str_replace("{shopname}",$shopname,it618_tuan_getlang('s1084'));
				$tmpstr=str_replace("{creditname}",$creditname,$tmpstr);
				echo $tmpstr;it618_pinedu_delsalework();exit;
			}
			
			if($_GET['it618_kdid']>0){
				$it618_tuan_kdyunfei=C::t('#it618_tuan#it618_tuan_kdyunfei')->fetch_by_id($_GET['it618_kdid']);
				if($it618_count>$it618_tuan_kdyunfei['it618_firstcount']){
					$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice']+$it618_tuan_kdyunfei['it618_price']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
					$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore']+$it618_tuan_kdyunfei['it618_score']*($it618_count-$it618_tuan_kdyunfei['it618_firstcount']);
				}else{
					$yunfeimoney=$it618_tuan_kdyunfei['it618_firstprice'];
					$yunfeiscore=$it618_tuan_kdyunfei['it618_firstscore'];
				}
				
				if($yunfeiscore>0){
					if(C::t('#it618_tuan#it618_tuan_jfhl')->count_by_jfid_isok($it618_tuan_kdyunfei['it618_jfid'])==0){
						echo it618_tuan_getlang('s21');it618_pinedu_delsalework();exit;
					}
					$yunfeijfid=$it618_tuan_kdyunfei['it618_jfid'];
					$allsumscore[$yunfeijfid]+=$yunfeiscore;
				}
			}
			
			$yfmoney=$goods_price*$it618_count+$yunfeimoney;
		
			if($goods_score>0){
				$yfscore=$goods_score*$it618_count;
				$allsumscore[$goods_jfid]+=$yfscore;
			}
			
			for($i=1;$i<=8;$i++){
				if($allsumscore[$i]>0){
					$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
					if($creditnum<$allsumscore[$i]){
						echo it618_tuan_getlang('s1111').$creditnum.$_G['setting']['extcredits'][$i]['title'].it618_tuan_getlang('s1122');it618_pinedu_delsalework();exit;
					}
				}
			}
			
		}
		
		if($IsUnion==1&&$_GET['tuijcode']!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			$it618_tuijid=Union_IsTuiJoin($shoptype,$pid,$_GET['tuijcode']);
		}

		if(lang('plugin/it618_pinedu', $it618_pinedu_lang['it618'])!=$it618_pinedu_lang['version'])exit;

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}

		if($yfmoney>0){
			if($_GET['paytype']==""){
				echo it618_pinedu_getlang('s1069');it618_pinedu_delsalework();exit;
			}
			
			$it618_state=0;
		}else{
			$it618_state=1;
		}
		
		if($shoptype=='group'){
			$it618_tel='1';
		}else{
			$it618_tel=it618_pinedu_utftogbk($_GET["it618_tel"]);
		}
		
		if($ii1i11i[9]!='e')exit;
		$tmptime=$_G['timestamp'];
		
		if($spid==0){
			$id = C::t('#it618_pinedu#it618_pinedu_sale_pin')->insert(array(
				'it618_shoptype' => $shoptype,
				'it618_shopid' => $it618_pinedu_goods['it618_shopid'],
				'it618_uid' => $uid,
				'it618_pid' => $it618_pinedu_goods['id'],
				'it618_price' => $goods_price_pin,
				'it618_jfid' => $it618_jfid_pin,
				'it618_score' => $it618_score_pin,
				'it618_mancount' => $it618_pinedu_goods['it618_mancount'],
				'it618_timecount' => $it618_pinedu_goods['it618_timecount'],
				'it618_state' => $it618_state,
				'it618_btime' => $tmptime
			), true);
		}else{
			$id = C::t('#it618_pinedu#it618_pinedu_sale')->insert(array(
				'it618_spid' => $spid,
				'it618_pid' => $it618_pinedu_goods['id'],
				'it618_shoptype' => $shoptype,
				'it618_shopid' => $it618_pinedu_goods['it618_shopid'],
				'it618_uid' => $uid,
				'it618_tuijid' => $it618_tuijid,
				'it618_count' => $it618_count,
				'it618_price' => $goods_price,
				'it618_jfid' => $goods_jfid,
				'it618_score' => $goods_score,
				'it618_jfbl' => $it618_jfbl,
				'it618_state' => $it618_state,
				'it618_time' => $tmptime,
				'it618_saletype' => $it618_saletype,
				'it618_kdid' => $it618_kdid,
				'it618_prepaybl' => $it618_prepaybl,
				'it618_yunfei' => $yunfeimoney,
				'it618_addr' => $it618_addr,
				'it618_addr1' => $it618_addr1,
				'it618_tel' => $it618_tel,
				'it618_gthdid' => $it618_gthdid,
				'it618_yunfeijfid' => $yunfeijfid,
				'it618_yunfeiscore' => $yunfeiscore,
				'it618_bz' => it618_pinedu_utftogbk($_GET['it618_bz'])
			), true);
		}

		if($id>0){
			if($spid==0){
				$tmpspid=$id;
				$id = C::t('#it618_pinedu#it618_pinedu_sale')->insert(array(
					'it618_spid' => $id,
					'it618_pid' => $it618_pinedu_goods['id'],
					'it618_shoptype' => $shoptype,
					'it618_shopid' => $it618_pinedu_goods['it618_shopid'],
					'it618_uid' => $uid,
					'it618_tuijid' => $it618_tuijid,
					'it618_count' => $it618_count,
					'it618_price' => $goods_price,
					'it618_jfid' => $goods_jfid,
					'it618_score' => $goods_score,
					'it618_jfbl' => $it618_jfbl,
					'it618_state' => $it618_state,
					'it618_time' => $tmptime,
					'it618_saletype' => $it618_saletype,
					'it618_kdid' => $it618_kdid,
					'it618_prepaybl' => $it618_prepaybl,
					'it618_yunfei' => $yunfeimoney,
					'it618_addr' => $it618_addr,
					'it618_addr1' => $it618_addr1,
					'it618_tel' => $it618_tel,
					'it618_gthdid' => $it618_gthdid,
					'it618_yunfeijfid' => $yunfeijfid,
					'it618_yunfeiscore' => $yunfeiscore,
					'it618_bz' => it618_pinedu_utftogbk($_GET['it618_bz'])
				), true);
			}else{
				$tmpspid=$spid;	
			}
			
			$it618_pinedu_sale_pin = C::t('#it618_pinedu#it618_pinedu_sale_pin')->fetch_by_id($tmpspid);
			
			if($shoptype!='tuan'){
				if($yfscore>0){
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$goods_jfid => (0-$yfscore))
					);
				}
			}else{
				for($i=1;$i<=8;$i++){
					if($allsumscore[$i]>0){
						C::t('common_member_count')->increase($uid, array(
							'extcredits'.$i => (0-$allsumscore[$i]))
						);
					}
				}
			}
			
			if($yfmoney==0){
				if($spid==0){
					$tmpstr=$it618_pinedu_lang['s86'];
				}else{
					$tmpstr=$it618_pinedu_lang['s87'];
				}
				
				$mancount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_pinedu_sale')." WHERE it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
				
				if($it618_pinedu_sale_pin['it618_mancount']==$mancount){
					$query = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale')." where it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
					while($it618_pinedu_sale = DB::fetch($query)) {
						it618_pinedu_pinok($it618_pinedu_sale,$it618_pinedu_goods['it618_typeid']);
					}
					DB::query("update ".DB::table('it618_pinedu_sale_pin')." set it618_state=3,it618_etime=$tmptime where id=".$it618_pinedu_sale_pin['id']);
				}
				
				it618_pinedu_updatepingoods($it618_pinedu_goods['id']);
				
				$url=$_G['siteurl'].'plugin.php?id=it618_pinedu:pin&shoptype='.$shoptype.'&spid='.$tmpspid;
				
				echo 'it618_splitjfokit618_split'.$tmpstr.'it618_split'.$url;it618_pinedu_delsalework();exit;	
			}
			
			if($shoptype=='video'){
				$saletype='0303';
			}
			
			if($shoptype=='exam'){
				$saletype='0503';
			}
			
			if($shoptype=='group'){
				$saletype='0903';
			}
			
			if($shoptype=='brand'){
				$saletype='0803';
			}
			
			if($shoptype=='tuan'){
				$saletype='0603';
			}
			
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			if($spid==0){
				$tmpstr=$it618_pinedu_lang['s158'];
			}else{
				$tmpstr=$it618_pinedu_lang['s169'];
			}
				
			$body=it618_pinedu_getgoodspinabout($shoptype,$it618_pinedu_goods['it618_typeid'],1);
			
			$total_fee=$yfmoney;
			
			if(pinedu_is_mobile()){ 
				$wap=1;
			}else{
				$wap=0;
			}
			
			$url=$_G['siteurl'].'plugin.php?id=it618_pinedu:pin&shoptype='.$shoptype.'&spid='.$tmpspid;
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];

			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_pinedu',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
		
			$ajaxpay=$_G['siteurl'].'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_pinedu_delsalework();
		}else{
			echo it618_pinedu_getlang('s498');it618_pinedu_delsalework();exit;
		}
	}
	exit;
}


if($_GET['ac']=="salesd_add"){
	if($uid<=0){
		echo it618_pinedu_getlang('s91');
	}else{
		$spid=intval($_GET['spid']);
		$typeid=intval($_GET['typeid']);
		$it618_count=intval($_GET['it618_count']);
		if($it618_count==0)$it618_count=1; 
		$shoptype=$_GET['shoptype'];
		
		$sd_userpower=C::t('#it618_pinedu#it618_pinedu_set')->getsetvalue_by_setname('sd_userpower');
		$sd_saleuser=C::t('#it618_pinedu#it618_pinedu_set')->getsetvalue_by_setname('sd_saleuser');

		$sd_userpowerarr=explode(",",$sd_userpower);
		if(!in_array($uid,$sd_userpowerarr)){
			echo $it618_pinedu_lang['s223'];exit;
		}
		
		if($sd_saleuser==''){
			echo $it618_pinedu_lang['s224'];exit;
		}
		$sd_saleuserarr=explode(",",$sd_saleuser);
		$arrindex=array_rand($sd_saleuserarr);
		$uid=$sd_saleuserarr[$arrindex];
		
		if($shoptype!='video'&&$shoptype!='exam'&&$shoptype!='group'&&$shoptype!='brand'&&$shoptype!='tuan'){
			echo $it618_pinedu_lang['s80'];exit;
		}
		
		if($spid==0){
			echo $it618_pinedu_lang['s225'];exit;
		}else{
			if(!$it618_pinedu_sale_pin=C::t('#it618_pinedu#it618_pinedu_sale_pin')->fetch_by_id($spid)){
				echo $it618_pinedu_lang['s80'];exit;
			}
			
			if($it618_pinedu_sale_pin['it618_state']==2){
				echo $it618_pinedu_lang['s110'];exit;
			}
				
			if($it618_pinedu_sale_pin['it618_state']==3){
				echo $it618_pinedu_lang['s92'];exit;
			}
			
			if($it618_pinedu_sale_pin['it618_uid']==$uid){
				echo it618_pinedu_getlang('s111');exit;
			}
			
			if(C::t('#it618_pinedu#it618_pinedu_sale')->count_by_spid_uid($it618_pinedu_sale_pin['id'],$uid)>0){
				echo it618_pinedu_getlang('s112');exit;
			}
			
			$goods_price=$it618_pinedu_sale_pin['it618_price'];
			$goods_jfid=$it618_pinedu_sale_pin['it618_jfid'];
			$goods_score=$it618_pinedu_sale_pin['it618_score'];
			
			$it618_pinedu_goods = C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_id($it618_pinedu_sale_pin['it618_pid']);
			$typeid=$it618_pinedu_goods['it618_typeid'];
		}
		
		if($it618_count<=0){
			echo it618_pinedu_getlang('s79');exit;
		}
		
		$tmptime=$_G['timestamp'];
		
		$id = C::t('#it618_pinedu#it618_pinedu_sale')->insert(array(
			'it618_spid' => $spid,
			'it618_pid' => $it618_pinedu_goods['id'],
			'it618_shoptype' => $shoptype,
			'it618_shopid' => $it618_pinedu_goods['it618_shopid'],
			'it618_uid' => $uid,
			'it618_count' => $it618_count,
			'it618_price' => $goods_price,
			'it618_jfid' => $goods_jfid,
			'it618_score' => $goods_score,
			'it618_state' => 1,
			'it618_time' => $tmptime
		), true);

		$mancount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_pinedu_sale')." WHERE it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
				
		if($it618_pinedu_sale_pin['it618_mancount']==$mancount){
			$query = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale')." where it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
			while($it618_pinedu_sale = DB::fetch($query)) {
				it618_pinedu_pinok($it618_pinedu_sale,$it618_pinedu_goods['it618_typeid']);
			}
			DB::query("update ".DB::table('it618_pinedu_sale_pin')." set it618_state=3,it618_etime=$tmptime where id=".$it618_pinedu_sale_pin['id']);
		}
		
		it618_pinedu_updatepingoods($it618_pinedu_goods['id']);
		
		echo 'ok';	
	}
	exit;
}


if($_GET['ac']=="payok"){
	
	if($_GET['ac1']=="pay"){
		$it618_spid=DB::result_first("SELECT it618_spid FROM ".DB::table('it618_pinedu_sale')." WHERE it618_state!=0 and id=".intval($_GET['saleid']));
	}
	
	if($it618_spid>0){
		echo 'it618_splitokit618_split'.$it618_spid;exit;
	}
}
//From: dis'.'m.tao'.'bao.com
?>