<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

DB::query("update ".DB::table('common_plugin')." set name='".lang('plugin/it618_pinedu', 'it618_name')."' where identifier='it618_pinedu'");

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_pinedu_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_pinedu_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_pid', $col_field)){
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_pid` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale'));
	while($it618_pinedu_sale = DB::fetch($query)) {
		$it618_pid=DB::result_first("SELECT it618_pid FROM ".DB::table('it618_pinedu_sale_pin')." WHERE id=".$it618_pinedu_sale['it618_spid']);
		$sql = "update ".DB::table('it618_pinedu_sale')." set it618_pid=$it618_pid where id=".$it618_pinedu_sale['id']; 
		DB::query($sql);
	}
}

if(!in_array('it618_saletype', $col_field)){
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_kdid` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_prepaybl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_yunfei` float(9,2) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_addr` varchar(2000) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_addr1` varchar(200) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_bz` varchar(2000) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_gthdid', $col_field)){
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_gthdid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_yunfeijfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_pinedu_sale')." add `it618_yunfeiscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdV9TQ19HQksueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdV9TQ19VVEY4LnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdV9UQ19CSUc1LnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdV9UQ19VVEY4LnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9sYW5ndWFnZS5UQ19CSUc1LnBocA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9sYW5ndWFnZS5UQ19VVEY4LnBocA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9pbnN0YWxsLnBocA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS91cGdyYWRlLnBocA=='));
?>