<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsCredits,$it618_pinedu;

$it618_pinedu = $_G['cache']['plugin']['it618_pinedu'];

require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/lang.func.php';

function it618_pinedu_getgoodspinstate($shoptype,$typeid){
	global $_G,$it618_pinedu_lang;
	
	$goodspin=array();
	
	if($it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_shoptype_typeid($shoptype,$typeid)){
		$goodspin['id']=$it618_pinedu_goods['id'];
		
		$timetmp1=explode(" ",$it618_pinedu_goods['it618_time1']);
		$timetmp2=explode(" ",$it618_pinedu_goods['it618_time2']);
		$timetmp11=explode("-",$timetmp1[0]);
		$timetmp12=explode(":",$timetmp1[1]);
		$timetmp21=explode("-",$timetmp2[0]);
		$timetmp22=explode(":",$timetmp2[1]);
		
		
		$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
		$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
		
		if($_G['timestamp']<$btime){
			$goodspin['name']=$it618_pinedu_lang['s2'];
		}
		if($_G['timestamp']>=$btime&&$_G['timestamp']<=$etime){
			$goodspin['name']=$it618_pinedu_lang['s3'];
		}
		if($_G['timestamp']>$etime){
			$goodspin['name']=$it618_pinedu_lang['s4'];
		}
		
		$goodspin['count']='(<font color=#999>'.$it618_pinedu_lang['s60'].''.$it618_pinedu_goods['it618_salepinallcount'].' '.$it618_pinedu_lang['s61'].'<font color=red>'.$it618_pinedu_goods['it618_salepincount'].'</font> '.$it618_pinedu_lang['s62'].''.$it618_pinedu_goods['it618_salepinokcount'].'</font>)';
	}else{
		$goodspin['id']=0;
		$goodspin['name']=$it618_pinedu_lang['s1'];
	}
	
	return $goodspin;
}

function it618_pinedu_getgoodspinabout($shoptype,$typeid,$ispaytitle=0){
	global $_G,$it618_pinedu_lang;
	
	if($shoptype=='video'){
		$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);
		
		$pid=$it618_video_goods_type['it618_pid'];
		$lid=$it618_video_goods_type['it618_lid'];
		$vid=$it618_video_goods_type['it618_vid'];
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
		$name=$it618_video_goods['it618_name'];
		
		if($lid==0&&$vid==0){
			$type=$it618_pinedu_lang['s17'];
		}
		
		if($lid>0&&$vid==0){
			$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
			$name.=' -> '.$it618_video_goods_lesson['it618_name'];
			if($ispaytitle==1)$name=$it618_video_goods_lesson['it618_name'];
			$type=$it618_pinedu_lang['s18'];
		}
		
		if($lid>0&&$vid>0){
			$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
			$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
			if($it618_video_goods_video['it618_liveid']>0){
				$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
				$videoname=$it618_video_live['it618_name'];
			}else{
				$videoname=$it618_video_goods_video['it618_name'];
			}
			$name.=' -> '.$it618_video_goods_lesson['it618_name'].' -> '.$videoname;
			if($ispaytitle==1)$name=$videoname;
			$type=$it618_pinedu_lang['s19'];
		}
		
		if($it618_video_goods_type['it618_timetype']==1)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s21'];
		if($it618_video_goods_type['it618_timetype']==2)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s22'];
		if($it618_video_goods_type['it618_timetype']==3)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s23'];
		if($it618_video_goods_type['it618_timetype']==4)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s24'];
		if($it618_video_goods_type['it618_timetype']==5)$time=$it618_video_goods_type['it618_time'].$it618_pinedu_lang['s25'];
		if($it618_video_goods_type['it618_timetype']==6)$time=$it618_pinedu_lang['s20'];
		
		return $name.' '.$type.'*'.$time;
	}
	
	if($shoptype=='exam'){
		$it618_exam_goods_type = C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($typeid);
		
		$pid=$it618_exam_goods_type['it618_pid'];
		
		$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);
		$name=$it618_exam_goods['it618_name'];
		
		return $name.' '.$it618_exam_goods_type['it618_name'];
	}
		
	if($shoptype=='group'){
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($typeid);
		
		$name=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);
		
		return $name.' '.$it618_unit;
	}
	
	if($shoptype=='brand'){
		$it618_brand_goods_type = C::t('#it618_brand#it618_brand_goods_type')->fetch_by_id($typeid);
		
		$pid=$it618_brand_goods_type['it618_pid'];
		
		$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);
		$name=$it618_brand_goods['it618_name'];
		
		return $name.' ['.$it618_brand_goods_type['it618_name'].$it618_brand_goods_type['it618_name1'].']';
	}
	
	if($shoptype=='tuan'){
		$it618_tuan_goods_type = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_id($typeid);
		
		$pid=$it618_tuan_goods_type['it618_pid'];
		
		$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid);
		$name=$it618_tuan_goods['it618_name'];
		
		return $name.' ['.$it618_tuan_goods_type['it618_name'].$it618_tuan_goods_type['it618_name1'].']';
	}
}

function it618_pinedu_getgoodsprice($it618_pinedu_goods,$type=''){
	global $_G;
	
	$it618_pinedu_goods['it618_price'.$type]=floatval($it618_pinedu_goods['it618_price'.$type]);
	
	if($it618_pinedu_goods['it618_price'.$type]>0&&$it618_pinedu_goods['it618_score'.$type]>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_pinedu_goods['it618_jfid'.$type]]['title'];
		$goodspricestr='<em>&yen;</em>'.$it618_pinedu_goods['it618_price'.$type].'+'.$it618_pinedu_goods['it618_score'.$type].'<em class="jfname">'.$goodsjfname.'</em>';
	}else{
		if($it618_pinedu_goods['it618_price'.$type]>0){
			$goodspricestr='<em>&yen;</em>'.$it618_pinedu_goods['it618_price'.$type];
		}
		
		if($it618_pinedu_goods['it618_score'.$type]>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_pinedu_goods['it618_jfid'.$type]]['title'];
			$goodspricestr=$it618_pinedu_goods['it618_score'.$type].'<em class="jfname">'.$goodsjfname.'</em>';
		}
	}
	
	return $goodspricestr;
}

function it618_pinedu_getgoodsprice1($it618_goods){
	global $_G;
	
	$it618_goods['it618_saleprice']=floatval($it618_goods['it618_saleprice']);
	
	if($it618_goods['it618_saleprice']>0&&$it618_goods['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_goods['it618_jfid']]['title'];
		$goodspricestr='<em>&yen;</em>'.$it618_goods['it618_saleprice'].'+'.$it618_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
	}else{
		if($it618_goods['it618_saleprice']>0){
			$goodspricestr='<em>&yen;</em>'.$it618_goods['it618_saleprice'];
		}
		
		if($it618_goods['it618_score'.$type]>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_goods['it618_jfid']]['title'];
			$goodspricestr=$it618_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
		}
	}
	
	return $goodspricestr;
}

function it618_pinedu_pay($type,$title){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		return;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype();
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		if($type=='pay'){
			$paystr='<tr id="payselect">
			<td>'.$title.'</td>
			<td>
			'.$tmpstr.'
			</td>
			</tr>';
		}
		
		if($type=='paywap'){
			$paystr='<tr id="payselect"><td colspan=2>'.$tmpstr.'</td></tr>';
		}
		
		if($type=='gwc'){
			$paystr='<div class="buy-block" id="payselect">
					<div class="buy-block-title"><h3>'.$title.'</h3></div>
					<div style="padding:10px">'.$tmpstr.'</div>
					</div>';
		}
		
		if($type=='gwcwap'){
			$paystr='<table width="100%" class="gwctable" bgcolor="#FFFFFF" id="payselect">
					<tr><td><table width="100%">
					<tr class="gwctrtitle">
					<th style="padding-left:3px">'.$title.'</th>
					</tr>
					</table></td></tr><tr><td style="padding:3px">
					'.$tmpstr.'
					</td></tr></table>';
		}
	}else{
		$paystr=$tmpstr.'<span id="payselect"></span>';
	}
    
	return $paystr;
}

function it618_pinedu_updatepingoods($pid){
	$allcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_pinedu_sale_pin')." WHERE it618_state>0 and it618_pid=".$pid);
	$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_pinedu_sale_pin')." WHERE it618_state=1 and it618_pid=".$pid);
	$okcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_pinedu_sale_pin')." WHERE it618_state=3 and it618_pid=".$pid);
	DB::query("update ".DB::table('it618_pinedu_goods')." set it618_salepinallcount=$allcount,it618_salepincount=$count,it618_salepinokcount=$okcount where id=".$pid);
}

function it618_pinedu_pinok($it618_pinedu_sale,$typeid){
	global $_G;
	
	if($it618_pinedu_sale['it618_tel']==''){
		DB::query("update ".DB::table('it618_pinedu_sale')." set it618_state=6 where id=".$it618_pinedu_sale['id']);
	}else{
	
		if($it618_pinedu_sale['it618_shoptype']=='video'){
			$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);
			
			$id = C::t('#it618_video#it618_video_sale')->insert(array(
				'it618_shopid' => $it618_pinedu_sale['it618_shopid'],
				'it618_uid' => $it618_pinedu_sale['it618_uid'],
				'it618_pid' => $it618_video_goods_type['it618_pid'],
				'it618_lid' => $it618_video_goods_type['it618_lid'],
				'it618_vid' => $it618_video_goods_type['it618_vid'],
				'it618_gtypeid' => $typeid,
				'it618_tuijid' => $it618_pinedu_sale['it618_tuijid'],
				'it618_count' => $it618_pinedu_sale['it618_count'],
				'it618_price' => $it618_pinedu_sale['it618_price'],
				'it618_jfid' => $it618_pinedu_sale['it618_jfid'],
				'it618_score' => $it618_pinedu_sale['it618_score'],
				'it618_sfmoney' => $it618_pinedu_sale['it618_price']*$it618_pinedu_sale['it618_count'],
				'it618_sfscore' => $it618_pinedu_sale['it618_score']*$it618_pinedu_sale['it618_count'],
				'it618_jfbl' => $it618_pinedu_sale['it618_jfbl'],
				'it618_tel' => $it618_pinedu_sale['it618_tel'],
				'it618_pinsaleid' => $it618_pinedu_sale['id'],
				'it618_state' => 1,
				'it618_time' => $it618_pinedu_sale['it618_time']
			), true);
			
			$it618_tuijid=$it618_pinedu_sale['it618_tuijid'];
			if($it618_tuijid>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_tuijid,$id);
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
			$it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($id);
			it618_video_updategoodscount($it618_video_sale);
			it618_video_qrxf($id);
			
			DB::query("update ".DB::table('it618_pinedu_sale')." set it618_state=6 where id=".$it618_pinedu_sale['id']);
		}
		
		if($it618_pinedu_sale['it618_shoptype']=='exam'){
			$it618_exam_goods_type = C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($typeid);
			
			$id = C::t('#it618_exam#it618_exam_sale')->insert(array(
				'it618_shopid' => $it618_pinedu_sale['it618_shopid'],
				'it618_uid' => $it618_pinedu_sale['it618_uid'],
				'it618_pid' => $it618_exam_goods_type['it618_pid'],
				'it618_gtypeid' => $typeid,
				'it618_tuijid' => $it618_pinedu_sale['it618_tuijid'],
				'it618_count' => $it618_pinedu_sale['it618_count'],
				'it618_price' => $it618_pinedu_sale['it618_price'],
				'it618_jfid' => $it618_pinedu_sale['it618_jfid'],
				'it618_score' => $it618_pinedu_sale['it618_score'],
				'it618_sfmoney' => $it618_pinedu_sale['it618_price']*$it618_pinedu_sale['it618_count'],
				'it618_sfscore' => $it618_pinedu_sale['it618_score']*$it618_pinedu_sale['it618_count'],
				'it618_jfbl' => $it618_pinedu_sale['it618_jfbl'],
				'it618_tel' => $it618_pinedu_sale['it618_tel'],
				'it618_pinsaleid' => $it618_pinedu_sale['id'],
				'it618_state' => 1,
				'it618_time' => $it618_pinedu_sale['it618_time']
			), true);
			
			$it618_tuijid=$it618_pinedu_sale['it618_tuijid'];
			if($it618_tuijid>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_tuijid,$id);
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
			$it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($id);
			it618_exam_updategoodscount($it618_exam_sale);
			it618_exam_qrxf($id);
			
			DB::query("update ".DB::table('it618_pinedu_sale')." set it618_state=6 where id=".$it618_pinedu_sale['id']);
		}
		
		if($it618_pinedu_sale['it618_shoptype']=='group'){
			$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($typeid);
			
			$id = C::t('#it618_group#it618_group_sale')->insert(array(
				'it618_uid' => $it618_pinedu_sale['it618_uid'],
				'it618_pid' => $it618_group_goods['id'],
				'it618_groupid' => $it618_group_goods['it618_groupid'],
				'it618_unitcount' => $it618_group_goods['it618_unitcount'],
				'it618_unit' => $it618_group_goods['it618_unit'],
				'it618_tuijid' => $it618_pinedu_sale['it618_tuijid'],
				'it618_count' => $it618_pinedu_sale['it618_count'],
				'it618_price' => $it618_pinedu_sale['it618_price'],
				'it618_jfid' => $it618_pinedu_sale['it618_jfid'],
				'it618_score' => $it618_pinedu_sale['it618_score'],
				'it618_jfbl' => $it618_pinedu_sale['it618_jfbl'],
				'it618_sfscore' => $it618_pinedu_sale['it618_score']*$it618_pinedu_sale['it618_count'],
				'it618_sfmoney' => $it618_pinedu_sale['it618_price']*$it618_pinedu_sale['it618_count'],
				'it618_pinsaleid' => $it618_pinedu_sale['id'],
				'it618_state' => 1,
				'it618_time' => $it618_pinedu_sale['it618_time']
			), true);
			
			$it618_tuijid=$it618_pinedu_sale['it618_tuijid'];
			if($it618_tuijid>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_tuijid,$id);
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
			$it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($id);
			it618_group_updategoodscount($it618_group_sale);
			it618_group_qrxf($id);
			
			DB::query("update ".DB::table('it618_pinedu_sale')." set it618_state=6 where id=".$it618_pinedu_sale['id']);
		}
		
		if($it618_pinedu_sale['it618_shoptype']=='brand'){
			$it618_brand_goods_type = C::t('#it618_brand#it618_brand_goods_type')->fetch_by_id($typeid);
			$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_goods_type['it618_pid']);
			$it618_brand_brand = C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_goods['it618_shopid']);
			
			$prepaybl=$it618_pinedu_sale['it618_prepaybl']/100;
			$it618_sfmoney=round(($it618_pinedu_sale['it618_price']*$it618_pinedu_sale['it618_count']*$prepaybl),2)+$it618_pinedu_sale['it618_yunfei'];
			$tc=round(($it618_sfmoney*$it618_brand_brand['it618_tcbl']/100), 2);
			
			$id = C::t('#it618_brand#it618_brand_sale')->insert(array(
				'it618_shopid' => $it618_pinedu_sale['it618_shopid'],
				'it618_uid' => $it618_pinedu_sale['it618_uid'],
				'it618_pid' => $it618_brand_goods['id'],
				'it618_pname' => $it618_brand_goods['it618_name'],
				'it618_gtypename' => $it618_brand_goods_type['it618_name'].$it618_brand_goods_type['it618_name1'],
				'it618_prepaybl' => $it618_pinedu_sale['it618_prepaybl'],
				'it618_saletype' => $it618_pinedu_sale['it618_saletype'],
				'it618_gtypeid' => $typeid,
				'it618_tuijid' => $it618_pinedu_sale['it618_tuijid'],
				'it618_price' => $it618_pinedu_sale['it618_price'],
				'it618_kdid' => $it618_pinedu_sale['it618_kdid'],
				'it618_yunfei' => $it618_pinedu_sale['it618_yunfei'],
				'it618_zk' => 100,
				'it618_sfmoney' => $it618_sfmoney,
				'it618_count' => $it618_pinedu_sale['it618_count'],
				'it618_addr' => $it618_pinedu_sale['it618_addr'],
				'it618_addr1' => $it618_pinedu_sale['it618_addr1'],
				'it618_tel' => $it618_pinedu_sale['it618_tel'],
				'it618_bz' => $it618_pinedu_sale['it618_bz'],
				'it618_type' => 2,
				'it618_state' => 1,
				'it618_alipaybl' => $it618_pinedu_sale['it618_jfbl'],
				'it618_tcbl' => $it618_brand_brand['it618_tcbl'],
				'it618_tc' => $tc,
				'it618_pinsaleid' => $it618_pinedu_sale['id'],
				'it618_time' => $it618_pinedu_sale['it618_time']
			), true);
			
			$it618_tuijid=$it618_pinedu_sale['it618_tuijid'];
			if($it618_tuijid>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_tuijid,$id);
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
			$it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($id);
			
			if($it618_brand_sale['it618_tuijid']>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_brand_sale['it618_tuijid'],$salepay_saleid);
			}
  
			C::t('#it618_brand#it618_brand_money')->insert(array(
				'it618_shopid' => $it618_brand_sale['it618_shopid'],
				'it618_saleid' => $it618_brand_sale['id'],
				'it618_pid' => $it618_brand_sale['it618_pid'],
				'it618_money' => ($it618_brand_sale['it618_price']*$it618_brand_sale['it618_count']+$it618_brand_sale['it618_yunfei']),
				'it618_score' => intval($it618_sfmoney*$it618_brand_sale['it618_alipaybl']/100),
				'it618_uid' => $it618_brand_sale['it618_uid'],
				'it618_state' => 1,
				'it618_type' => 3,
				'it618_time' => time()
			), true);
			
			if($it618_brand_sale['it618_saletype']==1||$it618_brand_sale['it618_saletype']==6)it618_brand_setcode($it618_brand_sale['id']);
			if($it618_brand_sale['it618_saletype']==3)it618_brand_setkm($it618_brand_sale['id']);
			if($it618_brand_sale['it618_saletype']==5)it618_brand_qrxf($it618_brand_sale['id']);
			
			if($it618_sfmoney>0&&$it618_brand_sale['it618_alipaybl']>0){
				C::t('common_member_count')->increase($it618_brand_brand['it618_uid'], array(
					'extcredits'.$it618_brand['brand_credit'] => (0-intval($it618_sfmoney*$it618_brand_sale['it618_alipaybl']/100)))
				);
			}
			
			it618_brand_updategoodscount($it618_brand_sale);
  
			if($it618_brand_sale['it618_saletype']==1){
				it618_brand_sendmessage('sale_user',$it618_brand_sale['id']);
			}else{
				it618_brand_sendmessage('sale2_user',$it618_brand_sale['id']);
			}
			it618_brand_sendmessage('sale_shop',$it618_brand_sale['id']);
			it618_brand_sendmessage('sale_admin',$it618_brand_sale['id']);
			
			if($IsGroup==1){
				require_once DISCUZ_ROOT.'./source/plugin/it618_group/yunprint.func.php';
				YunPrint('brand',$it618_brand_sale['it618_shopid'],$it618_brand_sale['id']);
			}
			
			if($it618_brand_saleaudio=C::t('#it618_brand#it618_brand_saleaudio')->fetch_by_it618_shopid($it618_brand_sale['it618_shopid'])){
				C::t('#it618_brand#it618_brand_saleaudio')->update($it618_brand_saleaudio['id'],array(
					'it618_state' => 1
				));
			}else{
				C::t('#it618_brand#it618_brand_saleaudio')->insert(array(
					'it618_shopid' => $it618_brand_sale['it618_shopid'],
					'it618_state' => 1
				), true);
			}
			
			DB::query("update ".DB::table('it618_pinedu_sale')." set it618_state=6 where id=".$it618_pinedu_sale['id']);
		}
		
		if($it618_pinedu_sale['it618_shoptype']=='tuan'){
			$it618_tuan_goods_type = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_id($typeid);
			$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_goods_type['it618_pid']);
			
			$it618_sfmoney=$it618_pinedu_sale['it618_price']*$it618_pinedu_sale['it618_count']+$it618_pinedu_sale['it618_yunfei'];
			$it618_sfscore=$it618_pinedu_sale['it618_score']*$it618_pinedu_sale['it618_count'];
			
			$id = C::t('#it618_tuan#it618_tuan_sale')->insert(array(
				'it618_shopid' => $it618_pinedu_sale['it618_shopid'],
				'it618_uid' => $it618_pinedu_sale['it618_uid'],
				'it618_pid' => $it618_tuan_goods['id'],
				'it618_gthdid' => $it618_pinedu_sale['it618_gthdid'],
				'it618_gtypeid' => $typeid,
				'it618_tuijid' => $it618_pinedu_sale['it618_tuijid'],
				'it618_saletype' => $it618_pinedu_sale['it618_saletype'],
				'it618_price' => $it618_pinedu_sale['it618_price'],
				'it618_jfid' => $it618_pinedu_sale['it618_jfid'],
				'it618_score' => $it618_pinedu_sale['it618_score'],
				'it618_yunfeijfid' => $it618_pinedu_sale['it618_yunfeijfid'],
				'it618_yunfeiscore' => $it618_pinedu_sale['it618_yunfeiscore'],
				'it618_sfmoney' => $it618_sfmoney,
				'it618_sfscore' => $it618_sfscore,
				'it618_jfbl' => $it618_pinedu_sale['it618_jfbl'],
				'it618_count' => $it618_pinedu_sale['it618_count'],
				'it618_yunfei' => $it618_pinedu_sale['it618_yunfei'],
				'it618_kdid' => $it618_pinedu_sale['it618_kdid'],
				'it618_name' => $it618_pinedu_sale['it618_addr1'],
				'it618_tel' => $it618_pinedu_sale['it618_tel'],
				'it618_addr' => $it618_pinedu_sale['it618_addr'],
				'it618_bz' => $it618_pinedu_sale['it618_tel'],
				'it618_isservice1' => $it618_tuan_goods['it618_isservice1'],
				'it618_isservice2' => $it618_tuan_goods['it618_isservice2'],
				'it618_isservice3' => $it618_tuan_goods['it618_isservice3'],
				'it618_bsaletime' => $it618_tuan_goods['it618_bsaletime'],
				'it618_esaletime' => $it618_tuan_goods['it618_esaletime'],
				'it618_state' => 1,
				'it618_pinsaleid' => $it618_pinedu_sale['id'],
				'it618_time' => $it618_pinedu_sale['it618_time']
			), true);
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
			$it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($id);
			
			if($it618_tuan_sale['it618_tuijid']>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_tuan_sale['it618_tuijid'],$it618_tuan_sale['id']);
			}
			
			if($it618_tuan_sale['it618_saletype']==1)it618_tuan_setcode($it618_tuan_sale['id']);
			if($it618_tuan_sale['it618_saletype']==3)it618_tuan_setkm($it618_tuan_sale['id']);
			
			it618_tuan_updategoodscount($it618_tuan_sale);
	
			if($it618_tuan_sale['it618_saletype']==1){
				it618_tuan_sendmessage('sale_user',$it618_tuan_sale['id']);
			}else{
				it618_tuan_sendmessage('sale2_user',$it618_tuan_sale['id']);
			}
			if($it618_tuan_sale['it618_gthdid']>0){
				it618_tuan_sendmessage('sale_shop1',$it618_tuan_sale['id']);
			}
			it618_tuan_sendmessage('sale_shop',$it618_tuan_sale['id']);
			it618_tuan_sendmessage('sale_admin',$it618_tuan_sale['id']);
			
			if($IsGroup==1){
				require_once DISCUZ_ROOT.'./source/plugin/it618_group/yunprint.func.php';
				YunPrint('tuan',$it618_tuan_sale['it618_shopid'],$it618_tuan_sale['id']);
			}
			
			if($it618_tuan_saleaudio=C::t('#it618_tuan#it618_tuan_saleaudio')->fetch_by_it618_shopid($it618_tuan_sale['it618_shopid'])){
				C::t('#it618_tuan#it618_tuan_saleaudio')->update($it618_tuan_saleaudio['id'],array(
					'it618_state' => 1
				));
			}else{
				C::t('#it618_tuan#it618_tuan_saleaudio')->insert(array(
					'it618_shopid' => $it618_tuan_sale['it618_shopid'],
					'it618_state' => 1
				), true);
			}
			
			DB::query("update ".DB::table('it618_pinedu_sale')." set it618_state=6 where id=".$it618_pinedu_sale['id']);
		}
		
	}
	
}

function it618_pinedu_getpingoods($shoptype,$pid,$wap){
	global $_G,$it618_pinedu_lang;
	
	$pingoods = array();
	
	$pincount=0;
	foreach(C::t('#it618_pinedu#it618_pinedu_goods')->fetch_all_by_shoptype_shopid(
		$shoptype,0,'it618_pid='.$pid,'it618_price,it618_score'
	) as $it618_pinedu_goods) {
		
		$timetmp1=explode(" ",$it618_pinedu_goods['it618_time1']);
		$timetmp2=explode(" ",$it618_pinedu_goods['it618_time2']);
		$timetmp11=explode("-",$timetmp1[0]);
		$timetmp12=explode(":",$timetmp1[1]);
		$timetmp21=explode("-",$timetmp2[0]);
		$timetmp22=explode(":",$timetmp2[1]);
		
		$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
		$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
		
		if($it618_pinedu_goods['it618_salepincount']==0){
			if($_G['timestamp']>$etime){
				continue;
			}
		}
		
		$isok=0;$timeflag=1;
		if($etime<$_G['timestamp']){
			$timeflag=0;
			$timetip=$it618_pinedu_lang['s161'];
		}else{
			if($btime>$_G['timestamp']){
				$timetip=$it618_pinedu_lang['s162'];
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=$it618_pinedu_goods['it618_time1'];
			}else{
				$timetip=$it618_pinedu_lang['s163'];
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=$it618_pinedu_goods['it618_time2'];
				$isok=1;
			}
		}
		
		$typeid=$it618_pinedu_goods['it618_typeid'];
		
		$pinbtnstr='class="pinbtn pinbtnsale" onclick="showpin('.$typeid.',0)"';
		if($isok==0){
			$pinbtnstr='class="pinbtn pinbtnsale0"';
		}
		
		$timestr='';
		if($timeflag==1){
			$timestr='<span>00</span>
					<em>'.$it618_pinedu_lang['s164'].'</em>
					<span>00</span>
					<em>'.$it618_pinedu_lang['s165'].'</em>
					<span>00</span>
					<em>'.$it618_pinedu_lang['s166'].'</em>
					<span>00</span>
					<em>'.$it618_pinedu_lang['s167'].'</em>
					<span>00</span>';
		}
		
		if($shoptype=='video'){
			$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);
			$pid=$it618_video_goods_type['it618_pid'];
			$lid=$it618_video_goods_type['it618_lid'];
			$vid=$it618_video_goods_type['it618_vid'];
			$paybtnstr='showpay('.$pid.','.$lid.','.$vid.','.$typeid.')';
			$it618_price=it618_pinedu_getgoodsprice1($it618_video_goods_type);
		}
		
		if($shoptype=='exam'){
			$it618_exam_goods_type = C::t('#it618_exam#it618_exam_goods_type')->fetch_by_id($typeid);
			$pid=$it618_exam_goods_type['it618_pid'];
			
			$it618_exam_goods_types=C::t('#it618_exam#it618_exam_goods_type')->fetch_name_by_it618_pid($pid);
			
			$n=0;
			foreach($it618_exam_goods_types as $it618_exam_goods_type1) {
				if($it618_exam_goods_type1['id']==$typeid){
					break;
				}
				$n++;
			}
			
			if($wap==1){
				$paybtnstr='IT618_EXAM(\'.it618pay\').click();setTimeout(function(){setselect(\'goodstype\','.$n.',\''.$it618_exam_goods_type['it618_name'].'\');}, 1000);';
			}else{
				$paybtnstr='setselect(\'goodstype\','.$n.',\''.$it618_exam_goods_type['it618_name'].'\',);setTimeout(function(){IT618_EXAM(\'.it618paybtn\').click();}, 1000);';
			}
			$it618_price=it618_pinedu_getgoodsprice1($it618_exam_goods_type);
		}
		
		if($shoptype=='group'){
			$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($typeid);
			$pid=$it618_group_goods['id'];
			$paybtnstr='showpay('.$pid.')';
			$it618_price=it618_pinedu_getgoodsprice1($it618_group_goods);
		}
		
		if($shoptype=='brand'){
			$it618_brand_goods_type = C::t('#it618_brand#it618_brand_goods_type')->fetch_by_id($typeid);
			$pid=$it618_brand_goods_type['it618_pid'];
			
			$count=C::t('#it618_brand#it618_brand_goods_type')->count_by_pid_ok_isname1($pid);
			if($count>0){
				$it618_brand_goods_types=C::t('#it618_brand#it618_brand_goods_type')->fetch_name_by_it618_pid1($pid);
			}else{
				$it618_brand_goods_types=C::t('#it618_brand#it618_brand_goods_type')->fetch_name_by_it618_pid($pid);
			}
	
			$n=0;
			foreach($it618_brand_goods_types as $it618_brand_goods_type1) {
				if($it618_brand_goods_type1['id']==$typeid){
					$goodstypename=$it618_brand_goods_type1['it618_name'];
					$tmpfun1='setselect(\'goodstype\','.$n.',\''.$it618_brand_goods_type1['it618_name'].'\');';
					break;
				}
				$n=$n+1;
			}
			
			if($goodstypename!=''){
				$n=0;
				foreach(C::t('#it618_brand#it618_brand_goods_type')->fetch_name1_by_it618_pid_name($pid,$goodstypename) as $it618_brand_goods_type1) {
					if($it618_brand_goods_type1['id']==$typeid){
						$tmpfun2='setselect(\'goodstype1\','.$n.',\''.$it618_brand_goods_type1['it618_name1'].'\');';
						break;
					}
					$n=$n+1;
				}
			}
			
			if($wap==1){
				$paybtnstr='IT618_BRAND(\'.it618pay\').click();setTimeout(function(){'.$tmpfun1.$tmpfun2.'}, 1000);';
			}else{
				$paybtnstr=''.$tmpfun1.$tmpfun2.'setTimeout(function(){IT618_BRAND(\'.glb_orgbtn_l\').click();}, 1000);';
			}
			$it618_price='<em>&yen;</em>'.$it618_brand_goods_type['it618_uprice'];
		}
		
		if($shoptype=='tuan'){
			$it618_tuan_goods_type = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_by_id($typeid);
			$pid=$it618_tuan_goods_type['it618_pid'];
			
			$count=C::t('#it618_tuan#it618_tuan_goods_type')->count_by_pid_ok_isname1($pid);
			if($count>0){
				$it618_tuan_goods_types=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name_by_it618_pid1($pid);
			}else{
				$it618_tuan_goods_types=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name_by_it618_pid($pid);
			}
	
			$n=0;
			foreach($it618_tuan_goods_types as $it618_tuan_goods_type1) {
				if($it618_tuan_goods_type1['id']==$typeid){
					$goodstypename=$it618_tuan_goods_type1['it618_name'];
					$tmpfun1='setselect(\'goodstype\','.$n.',\''.$it618_tuan_goods_type1['it618_name'].'\');';
					break;
				}
				$n=$n+1;
			}
			
			if($goodstypename!=''){
				$n=0;
				foreach(C::t('#it618_tuan#it618_tuan_goods_type')->fetch_name1_by_it618_pid_name($pid,$goodstypename) as $it618_tuan_goods_type1) {
					if($it618_tuan_goods_type1['id']==$typeid){
						$tmpfun2='setselect(\'goodstype1\','.$n.',\''.$it618_tuan_goods_type1['it618_name1'].'\');';
						break;
					}
					$n=$n+1;
				}
			}
			
			if($wap==1){
				$paybtnstr='IT618_TUAN(\'.it618pay\').click();setTimeout(function(){'.$tmpfun1.$tmpfun2.'}, 1000);';
			}else{
				$paybtnstr=''.$tmpfun1.$tmpfun2.'setTimeout(function(){IT618_TUAN(\'.glb_orgbtn_l\').click();}, 1000);';
			}
			$it618_price=it618_pinedu_getgoodsprice1($it618_tuan_goods_type);
		}
		
		$goodspricestr=it618_pinedu_getgoodsprice($it618_pinedu_goods);	
		
		$mantimecout=$it618_pinedu_lang['s83'];
		$mantimecout=str_replace("{mancount}",$it618_pinedu_goods['it618_mancount'],$mantimecout);
		$mantimecout=str_replace("{timecount}",it618_pinedu_gettime1($it618_pinedu_goods['it618_timecount']*60),$mantimecout);
		
		$trpinsumcss='';
		if($it618_pinedu_goods['it618_salepincount']>0){
			$sumstr=str_replace("{pincount}",$it618_pinedu_goods['it618_salepincount'],$it618_pinedu_lang['s644']);
		}else{
			$sumstr=$it618_pinedu_lang['s645'];
			if($it618_pinedu_goods['it618_salepinokcount']==0){
				$trpinsumcss='display:none"';
			}
		}
		$sumokstr=str_replace("{pinokcount}",$it618_pinedu_goods['it618_salepinokcount'],$it618_pinedu_lang['s643']);

		if($wap==1){
			$pinsaleswiper='';
			if($it618_pinedu_goods['it618_salepincount']>0||$it618_pinedu_goods['it618_salepinokcount']>0){
				$pinsalestr='';
				foreach(C::t('#it618_pinedu#it618_pinedu_sale')->fetch_all_by_shoptype_shopid(
					'',0,'it618_state=6 and it618_pid='.$it618_pinedu_goods['id'],'id desc',0,0,0,30
				) as $it618_pinedu_sale) {
					$u_avatarimg=it618_pinedu_discuz_uc_avatar($it618_pinedu_sale['it618_uid'],'middle');
					$uname=it618_pinedu_getusername($it618_pinedu_sale['it618_uid']);
					$pinsalestr.='<div class="swiper-slide"><img src="'.$u_avatarimg.'" class="imgpinsale"/> '.$uname.' '.it618_pinedu_gettimepin($it618_pinedu_sale['it618_time']).' '.$it618_pinedu_lang['s646'].'</div>';
				}
				
				if($pinsalestr!=''){
					$pinsaleswiper='<tr>
					  <td class="tdpinsaleswiper">
					  <div class="swiper-container" id="pinsaleswiper'.$it618_pinedu_goods['id'].'">
					  <div class="divpinsaleli" id="divpinsaleli'.$it618_pinedu_goods['id'].'"><img src="source/plugin/it618_pinedu/images/li0.png" onclick="getpinsaleli(this,'.$it618_pinedu_goods['id'].')"></div>
					  <div class="swiper-wrapper">
					  '.$pinsalestr.'
					  </div>
					  </div>
					  
					  <script language=javascript>
					  var mySwiper = new Swiper("#pinsaleswiper'.$it618_pinedu_goods['id'].'",{
						 direction: "vertical",
						 loop:true,
						 speed:1000,
						 autoplay:5000
					  });
					  </script>
					  </td>
					  </tr>';
				}
			}
			
			$pinstr.='<table width="100%">
					<tr>
					<td class="tdpingoods" style="border:none;padding-bottom:0">
					<span class="pingoodsname">'.it618_pinedu_getgoodspinabout($shoptype,$typeid).'</span><br /><span>'.$it618_pinedu_lang['s82'].''.$mantimecout.'</span><br><span>'.$it618_pinedu_lang['s106'].''.$it618_pinedu_goods['it618_time1'].' - '.$it618_pinedu_goods['it618_time2'].'</span>
					<div class="pincountdown countdown'.$it618_pinedu_goods['id'].'">
					<font>'.$timetip.'</font>
					'.$timestr.'
					</div>
					</td>
					</tr>
					<tr>
					<td class="tdpingoods">
					<a href="javascript:" class="pinbtn" onclick="'.$paybtnstr.'">'.$it618_pinedu_lang['s101'].'</a>
					<a href="javascript:" '.$pinbtnstr.'>'.$it618_pinedu_lang['s102'].'</a>
					<div style="float:left;">
					<span>'.$it618_pinedu_lang['s103'].'</span><font color="red">'.$goodspricestr.'</font><br /><span>'.$it618_pinedu_lang['s104'].''.$it618_price.'</span>
					</div>
					</td>
					</tr>
					<tr style="'.$trpinsumcss.'">
					<td class="tdpinsum">
					<div><span>'.$sumokstr.'</span>'.$sumstr.'</div>
					</td>
					</tr>
					'.$pinsaleswiper.'
					<tr>
					<td class="tdpinsale" id="tdpinsale'.$it618_pinedu_goods['id'].'">
					</td>
					</tr>
					</table>';
		}else{
			$pinstr.='<table width="100%">
					<tr>
					<td class="tdpingoods" style="position:relative">
					<a href="javascript:" class="pinbtn" onclick="'.$paybtnstr.'">'.$it618_pinedu_lang['s101'].'</a>
					<a href="javascript:" '.$pinbtnstr.'>'.$it618_pinedu_lang['s102'].'</a>
					<div style="float:right; margin-right:10px;">
					<span>'.$it618_pinedu_lang['s103'].'</span><font color="red">'.$goodspricestr.'</font><br /><span>'.$it618_pinedu_lang['s104'].''.$it618_price.'</span>
					</div>
					<span style="position:absolute;left:260px;top:48px;color:#666;'.$trpinsumcss.'"> '.$sumstr.' '.$sumokstr.'</span>
					'.it618_pinedu_getgoodspinabout($shoptype,$typeid).'<br /><span>'.$it618_pinedu_lang['s82'].''.$mantimecout.'</span> <span>'.$it618_pinedu_lang['s106'].''.$it618_pinedu_goods['it618_time1'].' - '.$it618_pinedu_goods['it618_time2'].'</span>
					<div class="pincountdown countdown'.$it618_pinedu_goods['id'].'">
					<font>'.$timetip.'</font>
					'.$timestr.'
					</div>
					</td>
					</tr>
					<tr>
					<td class="tdpinsale" id="tdpinsale'.$it618_pinedu_goods['id'].'">
					</td>
					</tr>
					</table>';
		}
		
		if($timeflag==1)$pinsaletimejs.='var endTime = \''.$etimestr.'\';var serverTime = \''.$btimestr.'\';pintimeCounter(endTime, serverTime, IT618_PINEDU(".countdown'.$it618_pinedu_goods['id'].'"));';
				
		$pinsalejs.='getpinsale('.$it618_pinedu_goods['id'].');';
		$pincount=$pincount+1;
	}
	
	$pingoods['pinstr']=$pinstr;
	$pingoods['pinsaletimejs']=$pinsaletimejs;
	$pingoods['pinsalejs']=$pinsalejs;
	
	if($pincount>1){
		if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_price_by_it618_shoptype_pid($shoptype,$pid)){
			if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_score_by_it618_shoptype_pid($shoptype,$pid)){
			}
		}
		$pingoods['pinprice']=it618_pinedu_getgoodsprice($it618_pinedu_goods).'<em>'.$it618_pinedu_lang['s230'].'</em>';
	}else{
		$pingoods['pinprice']=$goodspricestr;
	}
	
	return $pingoods;
}

function it618_pinedu_gettimepin($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_pinedu_getlang('s342');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_pinedu_getlang('s343');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_pinedu_getlang('s344');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_pinedu_getlang('s345');
		}
	}
	
	return $timestr;
}

function it618_pinedu_gettime($it618_time){
	global $_G;
	$timecount=intval(($it618_time-$_G['timestamp'])/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_pinedu_getlang('s97');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_pinedu_getlang('s98');
	}else{
		$timecount=intval(($it618_time-$_G['timestamp'])/60);
		if($timecount>=1){
			$timestr=$timecount.it618_pinedu_getlang('s99');
		}else{
			$timecount=intval(($it618_time-$_G['timestamp']));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_pinedu_getlang('s100');
		}
	}
	
	return $timestr;
}

function it618_pinedu_gettime1($it618_time){
	$timecount=intval($it618_time/3600);
	
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_pinedu_getlang('s97');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_pinedu_getlang('s98');
	}else{
		$timecount=intval(($it618_time-$_G['timestamp'])/60);
		if($timecount>=1){
			$timestr=$timecount.it618_pinedu_getlang('s99');
		}else{
			$timecount=intval(($it618_time-$_G['timestamp']));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_pinedu_getlang('s100');
		}
	}
	
	return $timestr;
}

function it618_pinedu_delsalework(){
	DB::query("delete from ".DB::table('it618_pinedu_salework'));
}

function it618_pinedu_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);

	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_pinedu_gbktoutf($strcontent);
	}
}

function it618_pinedu_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

/**
 * @param array  ����,����ͼƬ������
 * @param string  $filename ���ɺ����ļ���,�����˲����������ļ�,ֱ�����ͼƬ
 * @return [type] [description]
 */
function it618_pinedu_createPoster($config=array(),$filename=""){
  //���Ҫ����ʲô����������ע�͵����header
  if(empty($filename)) header("content-type: image/png");
  mb_internal_encoding("UTF-8");
  $imageDefault = array(
    'left'=>0,
    'top'=>0,
    'right'=>0,
    'bottom'=>0,
    'width'=>100,
    'height'=>100,
    'opacity'=>100
  );
  $textDefault = array(
    'text'=>'',
    'left'=>0,
    'top'=>0,
    'fontSize'=>32,       //�ֺ�
    'fontColor'=>'255,255,255', //������ɫ
    'angle'=>0,
  );
  $background = $config['background'];//������ײ�ñ���
  //��������
  $backgroundInfo = getimagesize($background);
  $backgroundFun = 'imagecreatefrom'.image_type_to_extension($backgroundInfo[2], false);
  $background = $backgroundFun($background);
  $backgroundWidth = imagesx($background);  //��������
  $backgroundHeight = imagesy($background);  //�����߶�
  $txtbackgroundWidth = 268;  //��������
  $txtbackgroundHeight = 80;  //�����߶�
  $imageRes = imageCreatetruecolor($backgroundWidth,$backgroundHeight);
  $color = imagecolorallocate($imageRes, 0, 0, 0);
  imagefill($imageRes, 0, 0, $color);
  // imageColorTransparent($imageRes, $color);  //��ɫ͸��
  imagecopyresampled($imageRes,$background,0,0,0,0,imagesx($background),imagesy($background),imagesx($background),imagesy($background));
  //������ͼƬ
  if(!empty($config['image'])){
    foreach ($config['image'] as $key => $val) {
      $val = array_merge($imageDefault,$val);
      $info = getimagesize($val['url']);
      $function = 'imagecreatefrom'.image_type_to_extension($info[2], false);
      if($val['stream']){   //����������ַ���ͼ����
        $info = getimagesizefromstring($val['url']);
        $function = 'imagecreatefromstring';
      }
      $res = $function($val['url']);
      $resWidth = $info[0];
      $resHeight = $info[1];
      //�������� ������ͼƬ��ָ���ߴ�
      $canvas=imagecreatetruecolor($val['width'], $val['height']);
      imagefill($canvas, 0, 0, $color);
      //�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h��
      imagecopyresampled($canvas, $res, 0, 0, 0, 0, $val['width'], $val['height'],$resWidth,$resHeight);
      $val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']) - $val['width']:$val['left'];
      $val['top'] = $val['top']<0?$backgroundHeight- abs($val['top']) - $val['height']:$val['top'];
      //����ͼ��
      imagecopymerge($imageRes,$canvas, $val['left'],$val['top'],$val['right'],$val['bottom'],$val['width'],$val['height'],$val['opacity']);//���ϣ��ң��£����ȣ��߶ȣ�͸����
    }
  }
  //��������
  if(!empty($config['text'])){
    foreach ($config['text'] as $key => $val) {
      $val = array_merge($textDefault,$val);
      list($R,$G,$B) = explode(',', $val['fontColor']);
      $fontColor = imagecolorallocate($imageRes, $R, $G, $B);
      $val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']):$val['left'];
      $val['top'] = $val['top']<0?$backgroundHeight- abs($val['top']):$val['top'];
	  
	  unset($letter);$content='';
	  for ($i=0;$i<mb_strlen($val['text']);$i++) {
		  $letter[] = mb_substr($val['text'], $i, 1);
	  }
	  
	  foreach ($letter as $l) {
		  $teststr = $content." ".$l;
		  $fontBox = imagettfbbox($val['fontSize'], 0, $val['fontPath'], $teststr);
		  if (($fontBox[2] > $val['width']) && ($content !== "")) {
			  $content .= "\n";
		  }
		  $content .= $l;
	  }
	  
      imagettftext($imageRes,$val['fontSize'],$val['angle'],$val['left'],$val['top'],$fontColor,$val['fontPath'],$content);
    }
  }
  //����ͼƬ
  if(!empty($filename)){
    $res = imagejpeg ($imageRes,$filename,90); //���浽����
    imagedestroy($imageRes);
    if(!$res) return false;
    return $filename;
  }else{
    imagepng ($imageRes);     //�����������ʾ
    imagedestroy($imageRes);
  }
}

function it618_pinedu_getsmsstr($strtmp,$length){
	if($length>0){
		return cutstr($strtmp,$length,'...');
	}
	return $strtmp;
}

function it618_pinedu_colorhex2rgb($hexColor) {
	$color = str_replace('#', '', $hexColor);
	if (strlen($color) > 3) {
		$rgb = array(
			'r' => hexdec(substr($color, 0, 2)),
			'g' => hexdec(substr($color, 2, 2)),
			'b' => hexdec(substr($color, 4, 2))
		);
	} else {
		$color = $hexColor;
		$r = substr($color, 0, 1) . substr($color, 0, 1);
		$g = substr($color, 1, 1) . substr($color, 1, 1);
		$b = substr($color, 2, 1) . substr($color, 2, 1);
		$rgb = array(
			'r' => hexdec($r),
			'g' => hexdec($g),
			'b' => hexdec($b)
		);
	}

	return $rgb['r'].','.$rgb['g'].','.$rgb['b'];
}

function it618_pinedu_getusername($uid){
	return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".intval($uid));
}

function it618_pinedu_getwapppic($aid,$get_it618_picbig,$type=1){
	$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
	$it618_smallurl='source/plugin/it618_pinedu/kindeditor/data/smallimage/wapad'.$aid.'.'.$file_ext;
	
	if($type==1){
		if(!file_exists($it618_smallurl))$flag=1;
	}else{
		$flag=1;
	}
	if($flag==1) {
			
		$smallpath=DISCUZ_ROOT.'./source/plugin/it618_pinedu/kindeditor/data/smallimage/';
		if(!file_exists($smallpath)) {
			mkdir($smallpath);
		}
	
		$tmparr1=explode("://",$get_it618_picbig);
		if(count($tmparr1)>1){
			$it618_url=$get_it618_picbig;
		}else{
			$tmparr=explode("source",$get_it618_picbig);
			$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
		}
		
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_pinedu/kindeditor/data/smallimage/wapad'.$aid.'.'.$file_ext;
		it618_pinedu_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,280);
	}
	
	return $it618_smallurl;
}

function it618_pinedu_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height,$type=1){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function it618_pinedu_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function pinedu_qrcode($url,$plugin='it618_pinedu'){
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/'.$plugin.'/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		include DISCUZ_ROOT.'./source/plugin/it618_pinedu/phpqrcode.php';
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function pinedu_is_mobile(){ 
	global $_GET;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: d'.'is'.'m.ta'.'obao.com
?>