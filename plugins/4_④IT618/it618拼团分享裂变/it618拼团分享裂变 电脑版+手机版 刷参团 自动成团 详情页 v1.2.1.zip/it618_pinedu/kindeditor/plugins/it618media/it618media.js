KindEditor.plugin('it618media', function(K) {
	var self = this, name = 'it618media';
	self.clickToolbar(name, function() {
		var lang = self.lang(name + '.'),
			html = '<div style="padding:10px 20px;">' +
				'<div style="margin-bottom:10px;">' + lang.title + '</div>' +
				'<textarea class="ke-textarea" style="width:580px;height:230px;padding:3px"></textarea>' +
				'<div style="margin-top:8px;color:#666">' + lang.about + '</div>' +
				'</div>',
			dialog = self.createDialog({
				name : name,
				width : 628,
				title : self.lang(name),
				body : html,
				yesBtn : {
					name : self.lang('yes'),
					click : function(e) {
						var html = textarea.val();
						self.insertHtml(html).hideDialog().focus();
					}
				}
			}),
			textarea = K('textarea', dialog.div);
		textarea[0].focus();
	});
});
