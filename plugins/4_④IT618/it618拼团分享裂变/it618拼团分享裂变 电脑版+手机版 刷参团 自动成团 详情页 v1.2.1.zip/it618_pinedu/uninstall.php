<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_pinedu_goods`;

DROP TABLE IF EXISTS `pre_it618_pinedu_sale_pin`;

DROP TABLE IF EXISTS `pre_it618_pinedu_sale`;

DROP TABLE IF EXISTS `pre_it618_pinedu_set`;

DROP TABLE IF EXISTS `pre_it618_pinedu_salework`;

EOF;

runquery($sql);

$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_it618_pinedu.php';
if(file_exists($cache_file)){
	$result=unlink($cache_file);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>