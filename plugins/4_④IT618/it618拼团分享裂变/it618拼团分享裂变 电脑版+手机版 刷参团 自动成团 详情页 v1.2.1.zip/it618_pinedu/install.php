<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_pinedu_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_pinedu_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price1` float(9,2) NOT NULL,
  `it618_jfid1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mancount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_timecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isautopinok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time1` varchar(20) NOT NULL,
  `it618_time2` varchar(20) NOT NULL,
  `it618_salepinallcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salepincount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salepinokcount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_pinedu_sale_pin`;
CREATE TABLE IF NOT EXISTS `pre_it618_pinedu_sale_pin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mancount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_timecount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_pinedu_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_pinedu_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_spid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL,
  `it618_name` varchar(20) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_prepaybl` float(9,2) NOT NULL DEFAULT '0',
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_addr` varchar(2000) NOT NULL,
  `it618_addr1` varchar(200) NOT NULL,
  `it618_gthdid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_yunfeijfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_yunfeiscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bz` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_pinedu_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_pinedu_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_pinedu_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_pinedu_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdV9TQ19HQksueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdV9TQ19VVEY4LnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdV9UQ19CSUc1LnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9kaXNjdXpfcGx1Z2luX2l0NjE4X3BpbmVkdV9UQ19VVEY4LnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9sYW5ndWFnZS5UQ19CSUc1LnBocA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9sYW5ndWFnZS5UQ19VVEY4LnBocA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS91cGdyYWRlLnBocA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3BpbmVkdS9pbnN0YWxsLnBocA=='));
?>