<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function pay_success($out_trade_no){
	global $_G;
	
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
		if($it618_salepay['it618_state']==1)return;
	}else{
		return;	
	}
	
	$salepay_saletype=$it618_salepay['it618_saletype'];
	$salepay_saleid=$it618_salepay['it618_saleid'];
	$salepay_paytype=$it618_salepay['it618_paytype'];
	$salepay_payid=$it618_salepay['it618_payid'];
	$salepay_url=$it618_salepay['it618_url'];
	$salepay_wap=$it618_salepay['it618_wap'];

	require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_pinedu_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_pinedu_delsalework();
		}
	}
	C::t('#it618_pinedu#it618_pinedu_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	
	if($salepay_saletype=='0303'||$salepay_saletype=='0503'||$salepay_saletype=='0903'||$salepay_saletype=='0803'||$salepay_saletype=='0603'){
		$it618_pinedu_sale=C::t('#it618_pinedu#it618_pinedu_sale')->fetch_by_id($salepay_saleid);
			
		if($it618_pinedu_sale['it618_state']!=1){
			C::t('#it618_pinedu#it618_pinedu_sale')->update($salepay_saleid,array(
				'it618_state' => 1
			));
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			$it618_pinedu_sale_pin=C::t('#it618_pinedu#it618_pinedu_sale_pin')->fetch_by_id($it618_pinedu_sale['it618_spid']);
			if($it618_pinedu_sale_pin['it618_uid']==$it618_pinedu_sale['it618_uid']){
				C::t('#it618_pinedu#it618_pinedu_sale_pin')->update($it618_pinedu_sale['it618_spid'],array(
					'it618_state' => 1,
				));
			}
			
			$it618_pinedu_goods = C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_id($it618_pinedu_sale_pin['it618_pid']);
			$mancount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_pinedu_sale')." WHERE it618_state=1 and it618_spid=".$it618_pinedu_sale['it618_spid']);
			
			if($it618_pinedu_sale_pin['it618_mancount']==$mancount){
				$query = DB::query("SELECT * FROM ".DB::table('it618_pinedu_sale')." where it618_state=1 and it618_spid=".$it618_pinedu_sale_pin['id']);
				while($it618_pinedu_sale = DB::fetch($query)) {
					it618_pinedu_pinok($it618_pinedu_sale,$it618_pinedu_goods['it618_typeid']);
				}
				
				DB::query("update ".DB::table('it618_pinedu_sale_pin')." set it618_state=3,it618_etime=".$_G['timestamp']." where id=".$it618_pinedu_sale_pin['id']);
			}
			
			it618_pinedu_updatepingoods($it618_pinedu_goods['id']);
			
			it618_pinedu_delsalework();
			
			return 'success';
		}
	
	}
	
	it618_pinedu_delsalework();

}
//From: d'.'is'.'m.ta'.'obao.com
?>