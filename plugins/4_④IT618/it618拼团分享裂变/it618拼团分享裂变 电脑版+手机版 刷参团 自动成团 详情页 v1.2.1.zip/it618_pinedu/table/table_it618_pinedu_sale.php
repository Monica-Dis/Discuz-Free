<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_pinedu_sale extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_pinedu_sale';
		$this->_pk = 'id';
		parent::__construct(); /*DISM �� Taobao �� Com*/
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_spid($spid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_spid=%d", array($this->_table, $spid));
	}
	
	public function count_by_spid_uid($spid,$uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_spid=%d and it618_uid=%d and it618_state=1", array($this->_table, $spid,$uid));
	}
	
	public function count_by_shoptype_shopid($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby='', $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618_shoptype, $it618_shopid, $it618sql, $it618orderby, $it618_time1, $it618_time2);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function fetch_username_by_uid($uid) {
		return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function fetch_all_by_shoptype_shopid($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shoptype, $it618_shopid, $it618sql, $it618orderby, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618_shoptype)) {
			$parameter[] = $it618_shoptype;
			$wherearr[] = 'it618_shoptype=%s';
		}
		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 'it618_time>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 'it618_time<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function fetch_extcredits_by_uid($creditindex,$uid) {
		return DB::result_first("select extcredits%d from ".DB::table('common_member_count')." where uid=%d", array($creditindex,$uid));
	}
}
//From: dis'.'m.tao'.'bao.com
?>