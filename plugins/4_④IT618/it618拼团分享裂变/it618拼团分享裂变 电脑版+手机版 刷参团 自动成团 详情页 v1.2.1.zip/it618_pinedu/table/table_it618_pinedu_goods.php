<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_pinedu_goods extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_pinedu_goods';
		$this->_pk = 'id';
		parent::__construct(); /*DISM �� Taobao �� Com*/
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_shoptype_typeid($shoptype, $typeid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_shoptype=%s and it618_typeid=%d", array($this->_table, $shoptype, $typeid));
	}
	
	public function fetch_by_ison_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_ison=1 and id=%d", array($this->_table, $id));
	}
	
	public function fetch_it618_shopid_by_id($id) {
		return DB::result_first("SELECT it618_shopid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_price_by_it618_shoptype_pid($shoptype,$pid) {
		global $_G;
		return DB::fetch_first("SELECT * FROM %t WHERE it618_shoptype=%s AND it618_pid=%d AND it618_price>0 AND UNIX_TIMESTAMP(it618_time2)>".$_G['timestamp']." ORDER BY it618_price", array($this->_table,$shoptype,$pid));
	}
	
	public function fetch_score_by_it618_shoptype_pid($shoptype,$pid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_shoptype=%s AND it618_pid=%d AND it618_score>0 AND UNIX_TIMESTAMP(it618_time2)>".$_G['timestamp']." ORDER BY it618_score", array($this->_table,$shoptype,$pid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_shoptype_shopid($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby='') {
		$condition = $this->make_query_condition($it618_shoptype, $it618_shopid, $it618sql, $it618orderby);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_shoptype_shopid($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shoptype, $it618_shopid, $it618sql, $it618orderby);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shoptype = '', $it618_shopid = 0, $it618sql = '', $it618orderby = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618_shoptype)) {
			$parameter[] = $it618_shoptype;
			$wherearr[] = 'it618_shoptype=%s';
		}
		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}
//From: dis'.'m.tao'.'bao.com
?>