<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(C::t('#it618_pinedu#it618_pinedu_set')->count_by_setname('sd_userpower')==0){
	C::t('#it618_pinedu#it618_pinedu_set')->insert(array(
		'setname' => 'sd_userpower',
		'setvalue' => ''
	), true);
	C::t('#it618_pinedu#it618_pinedu_set')->insert(array(
		'setname' => 'sd_saleuser',
		'setvalue' => ''
	), true);
}

if(submitcheck('it618submit')){
	$tmparr=explode(",",$_GET['sd_userpower']);
	for($i=0;$i<count($tmparr);$i++){
		$count=C::t('#it618_pinedu#it618_pinedu_sale')->count_by_uid($tmparr[$i]);
		if($count>0){
			$tmpstr.=$tmparr[$i].',';
		}
	}
	if($tmpstr!='')$tmpstr.='@';
	$tmpstr=str_replace(',@','',$tmpstr);
	
	$it618_pinedu_set=C::t('#it618_pinedu#it618_pinedu_set')->fetch_by_setname('sd_userpower');
	C::t('#it618_pinedu#it618_pinedu_set')->update($it618_pinedu_set['id'],array(
		'setvalue' => $tmpstr
	));
	
	$tmpstr='';
	$tmparr=explode(",",$_GET['sd_saleuser']);
	for($i=0;$i<count($tmparr);$i++){
		$count=C::t('#it618_pinedu#it618_pinedu_sale')->count_by_uid($tmparr[$i]);
		if($count>0){
			$tmpstr.=$tmparr[$i].',';
		}
	}
	if($tmpstr!='')$tmpstr.='@';
	$tmpstr=str_replace(',@','',$tmpstr);
	
	$it618_pinedu_set=C::t('#it618_pinedu#it618_pinedu_set')->fetch_by_setname('sd_saleuser');
	C::t('#it618_pinedu#it618_pinedu_set')->update($it618_pinedu_set['id'],array(
		'setvalue' => $tmpstr
	));

	cpmsg($it618_pinedu_lang['s220'], "action=plugins&identifier=$identifier&cp=admin_salesd&cp1=$cp1&pmod=admin_salesd&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_salesd&cp1=$cp1&pmod=admin_salesd&operation=$operation&do=$do");
showtableheaders($it618_pinedu_lang['s219'],'it618_pinedu_set');

$sd_userpower=C::t('#it618_pinedu#it618_pinedu_set')->getsetvalue_by_setname('sd_userpower');
$sd_saleuser=C::t('#it618_pinedu#it618_pinedu_set')->getsetvalue_by_setname('sd_saleuser');

$sd_userpowerstr='';
$tmparr=explode(",",$sd_userpower);
for($i=0;$i<count($tmparr);$i++){
	$username=C::t('#it618_pinedu#it618_pinedu_sale')->fetch_username_by_uid($tmparr[$i]);
	$sd_userpowerstr.=$username.' , ';
}
if($sd_userpowerstr!='')$sd_userpowerstr.='@';
$sd_userpowerstr=str_replace(' , @','',$sd_userpowerstr);

$sd_saleuserstr='';
$tmparr=explode(",",$sd_saleuser);
for($i=0;$i<count($tmparr);$i++){
	$username=C::t('#it618_pinedu#it618_pinedu_sale')->fetch_username_by_uid($tmparr[$i]);
	$sd_saleuserstr.=$username.' , ';
}
if($sd_saleuserstr!='')$sd_saleuserstr.='@';
$sd_saleuserstr=str_replace(' , @','',$sd_saleuserstr);

if($sd_isgoodstime==1)$chk_sd_isgoodstime='checked="checked"';else $chk_sd_isgoodstime='';

echo '
<tr><td width=100>'.$it618_pinedu_lang['s214'].'</td><td><input type="text" name="sd_userpower" style="width:900px;" value="'.$sd_userpower.'"><br><font color=#999>'.$it618_pinedu_lang['s215'].'</font></td></tr>
<tr><td></td><td style="color:green">'.$sd_userpowerstr.'</td></tr>
<tr><td>'.$it618_pinedu_lang['s216'].'</td><td><textarea name="sd_saleuser" style="width:900px;height:100px">'.$sd_saleuser.'</textarea><br><font color=#999>'.$it618_pinedu_lang['s217'].'</font></td></tr>
<tr><td></td><td style="color:green">'.$sd_saleuserstr.'</td></tr>
';

showsubmit('it618submit', $it618_pinedu_lang['s218']);
if(count($reabc)!=11)return; /*Dism_taobao-com*/
showtablefooter(); /*dism _ taobao _ com*/

?>