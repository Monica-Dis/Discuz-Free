<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_pinedu/config/pinset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_pinedu/config/pinset.php';
}

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_pinedu/config/pinset.php',"w");
	@$wapfp = fopen(DISCUZ_ROOT.'./source/plugin/it618_pinedu/config/pinset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {		
		$fileData = '$pin_about=\''.$_GET['pin_about']."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_pinedu_lang['s446'], "action=plugins&identifier=$identifier&cp=admin_pinset&pmod=admin_pinset&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_pinset&pmod=admin_pinset&operation=$operation&do=$do");
showtableheaders($it618_pinedu_lang['s122'],'it618_pinedu_set');

echo '
<link rel="stylesheet" href="source/plugin/it618_pinedu/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_pinedu/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_pinedu/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_pinedu/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_pinedu/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="pin_about"]\', {
			cssPath : \'source/plugin/it618_pinedu/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_pinedu/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_pinedu/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>

<tr><td width=800><textarea name="pin_about" style="width:800px;height:400px;visibility:hidden;">'.$pin_about.'</textarea></td></tr>
';

showsubmit('it618submit', $it618_pinedu_lang['s121']);

showtablefooter(); /*dism _ taobao _ com*/

?>