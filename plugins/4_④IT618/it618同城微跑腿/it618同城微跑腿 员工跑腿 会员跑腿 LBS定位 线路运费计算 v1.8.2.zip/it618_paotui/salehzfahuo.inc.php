<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_paotui = $_G['cache']['plugin']['it618_paotui'];
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

$saleid=intval($_GET['saleid']);

if(!($it618_paotui_salehz = C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($saleid))){
	echo 'alertit618_split'.it618_paotui_getlang('s1110');exit;
}

$tmpstr=$it618_paotui_lang['s1164'];
if($it618_paotui_salehz['it618_pmid']!=''){
	$tmpstr=$it618_paotui_lang['s1165'];
}

if($it618_paotui_salehz['it618_state']==1){
	$it618_state='<font color=red>'.$it618_paotui_lang['s1190'].'</font>';
}

if($it618_paotui_salehz['it618_state']==2){
	$it618_state='<font color=blue>'.$it618_paotui_lang['s1192'].'</font>';
}

if($it618_paotui_salehz['it618_state']==21){
	$it618_state='<font color=#F60>'.$it618_paotui_lang['s309'].'</font>';
}

if($it618_paotui_salehz['it618_state']==3){
	$it618_state='<font color=green>'.$it618_paotui_lang['s1193'].'</font>';
}

if($it618_paotui_salehz['it618_state']==4){
	$it618_state='<font color=#FF00FF>'.$it618_paotui_lang['s1197'].'</font>';
}

$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);

$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
$it618_type=$paotui_topname[3];

$salecopystr=$it618_paotui_lang['s1151'].$it618_type.$it618_paotui_lang['s1152']."\n";

$salecopystr.=$it618_paotui_lang['s1151'].$it618_paotui_lang['s1124'].$it618_paotui_lang['s1152'].$it618_paotui_salehz['id']."\n";

$salecopystr.=$it618_paotui_lang['s1151'].$it618_paotui_lang['s187'].$it618_paotui_lang['s1152'].$it618_paotui_shop['it618_hzshopid']."\n";

$salecopystr.=$it618_paotui_lang['s1151'].$it618_paotui_lang['s188'].$it618_paotui_lang['s1152'].$it618_paotui_shop['it618_name']."\n";

$salecopystr.=$it618_paotui_lang['s1151'].$it618_paotui_lang['s191'].$it618_paotui_lang['s1152'].$it618_paotui_shop['it618_addr'].' '.$it618_paotui_shop['it618_tel']."\n";

$salecopystr.=$it618_paotui_lang['s1151'].$it618_paotui_lang['s189'].$it618_paotui_lang['s1152'].$it618_paotui_salehz['it618_addr'].' '.$it618_paotui_salehz['it618_tel']."\n";

$salecopystr.=$it618_paotui_lang['s1151'].$it618_paotui_lang['s194'].$it618_paotui_lang['s1152'].$it618_paotui_shop['it618_bz']."\n";

$salecopystr.=$it618_paotui_lang['s1151'].$it618_paotui_lang['s1127'].$it618_paotui_lang['s1152'].$it618_paotui_salehz['it618_yunfei'];


$query = DB::query("SELECT * FROM ".DB::table('it618_paotui_peiman')." ORDER BY it618_order");
while($it618_paotui_peiman = DB::fetch($query)) {
	$selected='';
	if($it618_paotui_peiman['it618_pmid']==$it618_paotui_salehz['it618_pmid']){
		$selected='selected="selected"';
	}
	$peimenstr.='<option value="'.$it618_paotui_peiman['it618_pmid'].'" '.$selected.'>'.$it618_paotui_peiman['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'].'</option>';
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_paotui:salehzfahuo');
?>