<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_paotui_peiman`;

DROP TABLE IF EXISTS `pre_it618_paotui_rwpeiman`;

DROP TABLE IF EXISTS `pre_it618_paotui_wapstyle`;

DROP TABLE IF EXISTS `pre_it618_paotui_iconav`;

DROP TABLE IF EXISTS `pre_it618_paotui_bottomnav`;

DROP TABLE IF EXISTS `pre_it618_paotui_focus`;

DROP TABLE IF EXISTS `pre_it618_paotui_gonggao`;

DROP TABLE IF EXISTS `pre_it618_paotui_sale`;

DROP TABLE IF EXISTS `pre_it618_paotui_salehz`;

DROP TABLE IF EXISTS `pre_it618_paotui_shop`;

DROP TABLE IF EXISTS `pre_it618_paotui_set`;

DROP TABLE IF EXISTS `pre_it618_paotui_salework`;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>