<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

if(paotui_is_mobile()){ 
	$waphome=it618_paotui_getrewrite('paotui_wap','','plugin.php?id=it618_paotui:wap');
	dheader("location:$waphome");
}

$url_this = $_G['siteurl'].it618_paotui_getrewrite('paotui_wap','','plugin.php?id=it618_paotui:wap');
$qrcodesrc=paotui_qrcode($url_this);

if($it618_paotui['paotui_wxlogo']!=''){
	$logo='<img src="'.$it618_paotui['paotui_wxlogo'].'" width="48" style="position:absolute;top:118px;margin-left:115px;" />';
}

echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset='.CHARSET.'" />
<title>'.$it618_paotui['paotui_name'].'</title>
<style type="text/css">
body{margin:0;padding:0; background-color:#333}
a:link,a:visited{color:#007ab7;text-decoration:none;}
</style>
</head>
<body>
<table width="100%">
<tr>
<td style="text-align:center; padding-top:150px;color:#fff; font-size:13px">
'.$it618_paotui_paotui['it618_name'].'
</td>
</tr>
<tr>
<td style="text-align:center;position:relative">
'.$logo.'
<img src="'.$qrcodesrc.'" width="280" />
</td>
</tr>
<tr>
<td style="text-align:center; color:#39F; font-size:12px">
'.$it618_paotui_lang['s629'].'
</td>
</tr>
</table>
</body>
</html>
';
?>