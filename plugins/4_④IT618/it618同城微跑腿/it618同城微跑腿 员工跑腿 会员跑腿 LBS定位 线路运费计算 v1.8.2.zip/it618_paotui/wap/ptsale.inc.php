<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!($it618_paotui['paotui_homehot']==''&&$it618_paotui['paotui_lbscount']==0)){
	if($_G['uid']<=0){
		$tmpurl_home=it618_paotui_getrewrite('paotui_wap','','plugin.php?id=it618_paotui:wap');
		dheader("location:$tmpurl_home");
	}
}

if(!paotui_is_mobile()){
	dheader("location:$homeurl");
}

$cid=intval($_GET['cid']);
$page=intval($_GET['page']);

if($cid==0)$cid=1;
if($cid==1)$current1='class="current"';
if($cid==2)$current2='class="current"';
if($cid==3)$current3='class="current"';
if($cid==4)$current4='class="current"';

$it618_lbslat2='0';
$it618_lbslng2='0';

if($cid==1&&$page>0){
	$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($page);
	$it618_lbslat2=$it618_paotui_shop['it618_lbslat'];
	$it618_lbslng2=$it618_paotui_shop['it618_lbslng'];
}

$uid = $_G['uid'];

if($uid>0){
	$paybtnstr='<input class="btn btn-strong buy-btn2 btn-large it618pay" type="button" style="width:100%;height:48px;line-height:48px" value="'.$it618_paotui_lang['t35'].'" onclick="pay()" />';
	
	if($cid<=3){
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_uid_maxid($uid);
	}else{
		$it618_paotui_salehz=C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_uid_maxid($uid);
		$shoptmp=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_uid($uid);
		if(!($shoptmp['it618_htstate']==1&&$shoptmp['it618_hzshopid']!='')){
			$paybtnstr='<input class="btn btn-strong buy-btn2 btn-large it618pay" type="button" style="width:100%;font-size:15px;background-color:#ccc;height:48px;line-height:48px" value="'.$it618_paotui_lang['s211'].'" />';
		}
	}
}

if($cid==1||$cid==2){
	$scorebl=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('scorebl');
	
	$yunfei_xiaofei=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_xiaofei');
	if($yunfei_xiaofei==''){
		$xiaofeicss='style="display:none"';
		$xiaofeistr='<input type="hidden" id="xiaofei" name="xiaofei" value="0">';
	}else{
		$n=1;
		$xiaofeistr='<option value="0">---'.$it618_paotui_lang['s3'].'---</option>';
		$xiaofeiarr=explode(",",$yunfei_xiaofei);
		for($i=0;$i<count($xiaofeiarr);$i++){
			if($xiaofeiarr[$i]>0){
				$xiaofeistr.='<option value="'.$xiaofeiarr[$i].'">---'.$it618_paotui_lang['s8'].' '.$xiaofeiarr[$i].' '.$it618_paotui_lang['s1224'].' '.$it618_paotui_lang['s9'].'---</option>';
				$n=$n+1;
			}
		}
		
		$xiaofeistr='<select id="xiaofei" name="xiaofei" onchange="setselect(this)" style="color:#F60">'.$xiaofeistr.'</select>';
		$xiaofeistr='<table width="100%"><tr><td width="76%" style="border:none;padding:0">'.$xiaofeistr.'</td><td style="border:none;padding:0"><font color=#f60  style="font-size:15px;float:right">+ &yen;<span id="xiaofeispan" style="font-size:20px">0</span></font></td></tr></table>';
	}
	
	if($scorebl>0){
		$tmpcss='';
		if($uid>0)$creditnum=C::t('#it618_paotui#it618_paotui_sale')->fetch_extcredits_by_uid($it618_paotui['paotui_credit'],$uid);
		if($creditnum=="")$creditnum=0;
	}else{
		$tmpcss='style="display:none"';
	}
	
	$scorestr='<table width="100%"><tr><td width="76%" style="border:none;padding:0"><input type="checkbox" id="chkscore" name="chkscore" value="1" style="vertical-align:middle" onclick="getsfmoney()"><label for="chkscore" style="vertical-align:middle">'.$it618_paotui_lang['s96'].'<font color=#390><b>'.$creditnum.'</b></font>'.$creditname.$it618_paotui_lang['s98'].$it618_paotui_lang['s97'].'<font color=red><b>'.$scorebl.'</b></font>%'.$it618_paotui_lang['s92'].'<font color=#F60><span id="jfscore"></span></font>'.$creditname.$it618_paotui_lang['s94'].'</td><td style="border:none;padding:0"><font color=#390  style="font-size:15px;float:right">- &yen;<span id="scoremoney" style="font-size:20px">0</span></font><input type="hidden" id="jf" value="'.$creditnum.'"><input type="hidden" id="jfbl" value="'.$it618_paotui['paotui_jfbl'].'"><input type="hidden" id="scorebl" value="'.$scorebl.'"></label></td></tr><tr><td>'.$it618_paotui_lang['s93'].'</td></tr></table>';
	
	$sfmoneystr='<font color=#F60  style="font-size:23px;float:right">&yen;<span id="sfmoney" style="font-size:30px"></span></font>'.$it618_paotui_lang['s88'];
	
	$it618paystr=it618_paotui_pay('ptpaywap',$it618_paotui_lang['s87']);

}

$saletop=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('sale'.$cid.'top');

$navtitle=$paotui_topname[$cid-1].' - '.$sitetitle;

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_paotui:wap_paotui');
?>