<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_G['uid']<=0){
	$tmpurl_home=it618_paotui_getrewrite('paotui_wap','','plugin.php?id=it618_paotui:wap');
	dheader("location:$tmpurl_home");
}

if(!paotui_is_mobile()){
	dheader("location:$homeurl");
}

$navtitle=it618_paotui_getlang('t84').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_paotui_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_paotui:wap_paotui');
	return;
}

$menuusername=$_G['username'];
$u_avatarimg=it618_paotui_discuz_uc_avatar($_G['uid'],'middle');
$creditname=$_G['setting']['extcredits'][$it618_paotui['paotui_credit']]['title'];
$creditnum=DB::result_first("select extcredits".$it618_paotui['paotui_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	if($_G['cache']['plugin']['it618_credits']['rewriteurl']==0){
		$creditsurl='plugin.php?id=it618_credits:wap&dotype=uc';
	}else{
		$creditsurl='credits_wap-uc.html';
	}
}

$ucurl=it618_paotui_getrewrite('paotui_wap','uc','plugin.php?id=it618_paotui:wap&pagetype=uc');
$uccount = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_state>0','',$_G['uid']);
$ucyunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei','it618_state>0','',$_G['uid']);

$ucstr=$paotui_topname[0].$it618_paotui_lang['s186'].$paotui_topname[1].$it618_paotui_lang['s186'].$paotui_topname[2];

$rwpeimantmp=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_uid($_G['uid']);
if($rwpeimantmp['it618_state']==2){
	$rwpmurl=it618_paotui_getrewrite('paotui_wap','rwpm','plugin.php?id=it618_paotui:wap&pagetype=rwpm');
	$rwpmcount = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_rwpmid='.$rwpeimantmp['id']);
	$rwpmyunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei','it618_rwpmid='.$rwpeimantmp['id']);

	$isrwpm=1;
	$rwpmstr=$paotui_topname[0].$it618_paotui_lang['s186'].$paotui_topname[1];
	
	$sumstr=$it618_paotui_lang['s376'];
	$count1 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_state=3 and it618_rwpmid='.$rwpeimantmp['id']);
	$sum1=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei','it618_state=3 and it618_rwpmid='.$rwpeimantmp['id']);

	$sumstr=str_replace("{count1}",$count1,$sumstr);
	$sumstr=str_replace("{sum1}",$sum1,$sumstr);
	
	$pjcount1 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_pj=1 and it618_rwpmid='.$rwpeimantmp['id']);
	$pjcount2 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_pj=2 and it618_rwpmid='.$rwpeimantmp['id']);
	$pjcount3 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_pj=3 and it618_rwpmid='.$rwpeimantmp['id']);
	$allpjcount=$pjcount1+$pjcount2+$pjcount3;
	if($allpjcount==0){
		$pjtmp1=0;$pjtmp2=0;$pjtmp3=0;
	}else{
		$pjtmp1=$pjcount1/$allpjcount*100;
		$pjtmp2=$pjcount2/$allpjcount*100;
		$pjtmp3=$pjcount3/$allpjcount*100;
	}
	
	$sumstr=str_replace("{pj1}",round($pjtmp1,2),$sumstr);
	$sumstr=str_replace("{pj2}",round($pjtmp2,2),$sumstr);
	$sumstr=str_replace("{pj3}",round($pjtmp3,2),$sumstr);
	$sumstr=str_replace("{pjcount}",$allpjcount,$sumstr);
	
	$it618_paotui_rwpmtcbl=C::t('#it618_paotui#it618_paotui_rwpmtcbl')->fetch_by_pj($pjtmp1);
	$sumstr=str_replace("{jdcount}",$it618_paotui_rwpmtcbl['it618_jdcount'],$sumstr);
	$sumstr=str_replace("{tcbl}",$it618_paotui_rwpmtcbl['it618_tcbl'],$sumstr);
}

if($peimantmp=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_uid($_G['uid'])){
	$pmurl=it618_paotui_getrewrite('paotui_wap','pm','plugin.php?id=it618_paotui:wap&pagetype=pm');
	$pmhzurl=it618_paotui_getrewrite('paotui_wap','pmhz','plugin.php?id=it618_paotui:wap&pagetype=pmhz');
	$pmcount = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('','',0,$peimantmp['it618_pmid']);
	$pmyunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei','','',0,$peimantmp['it618_pmid']);
	$pmhzcount = C::t('#it618_paotui#it618_paotui_salehz')->count_by_search('','',0,$peimantmp['it618_pmid']);
	$pmhzyunfei=C::t('#it618_paotui#it618_paotui_salehz')->sum_by_search('it618_yunfei','','',0,$peimantmp['it618_pmid']);

	$ispm=1;
	$pmstr=$paotui_topname[0].$it618_paotui_lang['s186'].$paotui_topname[1];
	$pmhzstr=$paotui_topname[3];
	$pmidstr=$it618_paotui_lang['s208'].$peimantmp['it618_pmid'];
}

$shoptmp=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_uid($_G['uid']);
if($shoptmp['it618_htstate']==1&&$shoptmp['it618_hzshopid']!=''){
	$scurl=it618_paotui_getrewrite('paotui_wap','sc','plugin.php?id=it618_paotui:wap&pagetype=sc');
	$sccount = C::t('#it618_paotui#it618_paotui_salehz')->count_by_search('it618_shopid='.$shoptmp['id']);
	$scyunfei=C::t('#it618_paotui#it618_paotui_salehz')->sum_by_search('it618_yunfei','it618_shopid='.$shoptmp['id']);

	$isshop=1;
	$scstr=$paotui_topname[3];
	$shopidstr=$it618_paotui_lang['s209'].$shoptmp['it618_hzshopid'];
}

$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
if(in_array($_G['uid'],$saleadmin)){
	$adminurl=it618_paotui_getrewrite('paotui_wap','admin','plugin.php?id=it618_paotui:wap&pagetype=admin');
	$adminhzurl=it618_paotui_getrewrite('paotui_wap','adminhz','plugin.php?id=it618_paotui:wap&pagetype=adminhz');
	$admincount = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_state>0');
	$adminyunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei','it618_state>0');
	$adminhzcount = C::t('#it618_paotui#it618_paotui_salehz')->count_by_search();
	$adminhzyunfei=C::t('#it618_paotui#it618_paotui_salehz')->sum_by_search('it618_yunfei');

	$isadmin=1;
	$adminstr=$paotui_topname[0].$it618_paotui_lang['s186'].$paotui_topname[1].$it618_paotui_lang['s186'].$paotui_topname[2];
	$adminhzstr=$paotui_topname[3];
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_paotui:wap_paotui');
?>