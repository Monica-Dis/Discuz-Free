<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!paotui_is_mobile()){
	dheader("location:$homeurl");
}

if($it618_paotui['paotui_homehot']==''&&$it618_paotui['paotui_lbscount']==0&&$_G['uid']>0){
	$tmpurl=it618_paotui_getrewrite('paotui_wap','ptsale@1','plugin.php?id=it618_paotui:wap&pagetype=ptsale&cid=1');
	dheader("location:$tmpurl");
}

foreach(C::t('#it618_paotui#it618_paotui_focus')->fetch_all_by_order() as $it618_paotui_focus) {
	if($it618_paotui_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_paotui_focus['it618_url'].'" target="_blank"><img class="img" src="'.it618_paotui_getwapppic('wapad'.$it618_paotui_focus['id'],$it618_paotui_focus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_paotui_getwapppic('wapad'.$it618_paotui_focus['id'],$it618_paotui_focus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_paotui_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_paotui_gonggao = DB::fetch($query)) {
	$it618_title=$it618_paotui_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,62,'...');
	
	if($it618_paotui_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_paotui_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_paotui_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	$it618_title='<font color="#888">'.$it618_title.'</font>';
	
	$str_gonggao.='<tr><td><a href="'.$it618_paotui_gonggao['it618_url'].'" title="'.$it618_paotui_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_paotui_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_paotui_iconav = DB::fetch($query)) {
	$it618_title=$it618_paotui_iconav['it618_title'];
	
	if($it618_paotui_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_paotui_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_paotui_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_paotui_iconav['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$it618_url=$it618_paotui_iconav['it618_url'];
	
	$str_iconav.='<td width="25%"><a href="'.$it618_url.'"'.$it618_target.'><img src="'.$it618_paotui_iconav['it618_img'].'"/><br>'.$it618_title.'</a></td>';
	
	if($n%8==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav">';
	if($n%4==0)$str_iconav.='</tr><tr>';
	
	$isiconav=1;

	$n=$n+1;
}

for($i=1;$i<=$n%4;$i++){
	$str_iconav.='<td width="25%"></td>';
}
$str_iconav.='</tr>';
$str_iconav=str_replace('<tr><td width="25%"></td></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"></tr></table></div>','',$str_iconav);

$waphomead=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('waphomead');

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_paotui:wap_paotui');
?>