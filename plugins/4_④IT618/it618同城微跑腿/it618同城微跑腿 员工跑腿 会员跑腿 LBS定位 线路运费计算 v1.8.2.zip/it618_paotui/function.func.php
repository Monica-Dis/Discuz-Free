<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_paotui = $_G['cache']['plugin']['it618_paotui'];
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/lang.func.php';

$creditname=$_G['setting']['extcredits'][$it618_paotui['paotui_credit']]['title'];
if($it618_paotui['paotui_levelnames']!=''){
	$paotui_levelnames=$it618_paotui['paotui_levelnames'];
}else{
	$paotui_levelnames=$it618_paotui_lang['t332'];
}
$tmplevelarr=explode(",",$paotui_levelnames);

function it618_paotui_pay($type,$title){
	$paystr=$tmpstr.'<span id="payli"></span>';
	
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		return $paystr;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype();
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		if($type=='ptpaywap'){
			$paystr='<table width="100%" class="gwctable" id="payli" bgcolor="#FFFFFF">
					<tr><td><table width="100%">
					<tr class="gwctrtitle">
					<th style="padding-left:5px">'.$title.'</th>
					</tr>
					</table></td></tr><tr><td style="padding:3px;padding-top:18px;padding-bottom:15px">
					'.$tmpstr.'
					</td></tr></table>';
		}
	}else{
		$paystr=$tmpstr.'<span id="payli"></span>';
	}
    
	return $paystr;
}

function it618_paotui_qrxf($saleid){
	global $_G,$it618_paotui,$it618_paotui_lang;
	
	$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($saleid);
		
	C::t('#it618_paotui#it618_paotui_sale')->update($saleid,array(
		'it618_state' => 4
	));
	
	if($it618_paotui_sale['it618_rwpmid']>0){
		$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($it618_paotui_sale['it618_rwpmid']);
		$money=$it618_paotui_sale['it618_yunfei']+$it618_paotui_sale['it618_xiaofei'];
		$tcmoney=round(($money*$it618_paotui_sale['it618_rwtcbl']/100),2);
		
		$it618_bz=$it618_paotui_lang['s381'];
		$it618_bz=str_replace("{money}",$money,$it618_bz);
		$it618_bz=str_replace("{saleid}",$saleid,$it618_bz);
		$it618_bz=str_replace("{tcmoney}",$tcmoney,$it618_bz);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		savemoney(array(
			'it618_uid' => $it618_paotui_rwpeiman['it618_uid'],
			'it618_type' => 'zy',
			'it618_money1' => $tcmoney,
			'it618_bz' => $it618_bz,
			'it618_zytype' => 'it618_paotui_tc',
			'it618_zyid' => $saleid,
			'it618_time' => $_G['timestamp']
		));
	}
	
	$tmpmoney=$it618_paotui_sale['it618_yunfei']+$it618_paotui_sale['it618_xiaofei'];
		
	if($tmpmoney>0){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
		}
		
		if($union_paotui_isok==1&&$tmpmoney>=$union_paotui_money){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			Union_SaleTC('it618_paotui',$tmpmoney,$it618_paotui_sale['id'],$it618_paotui_sale['it618_uid']);
		}
	}
	
	if($it618_paotui_sale['it618_type']<=2)it618_paotui_sendmessage('saleok_user',$saleid);
}

function it618_paotui_qrxfhz($saleid){
	global $_G,$it618_paotui;
	
	$it618_paotui_salehz=C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($saleid);
		
	C::t('#it618_paotui#it618_paotui_salehz')->update($saleid,array(
		'it618_state' => 3
	));
}

function it618_paotui_getyytime(){
	global $_G,$it618_paotui_lang;
	
	$yytime_isok=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yytime_isok');
	
	$timetmp=date('Y-m-d', $_G['timestamp']);
	
	$isok=0;
	if($yytime_isok==1){

		$yytime_isoktime=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yytime_isoktime');

		if($yytime_isoktime!=""){

			$timearr=explode(',',$yytime_isoktime);
			for($i=0;$i<count($timearr);$i++){
				$timearr1=explode("-",$timearr[$i]);
				
				$timetmp1=$timetmp." ".$timearr1[0].":00";
				$timetmp2=$timetmp." ".$timearr1[1].":59";
				
				if(strtotime($timetmp1)<=$_G['timestamp']&&strtotime($timetmp2)>=$_G['timestamp']){
					$isok=1;
					break;
				}
			}
			
		}else{
			$isok=1;
		}
	}else{
		$yytime_isokbz=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yytime_isokbz');
		$isokbz=$yytime_isokbz;
	}
	
	return $isok."it618_split".$isokbz;
}

function it618_paotui_verify(){
	global $plugin;
	$identifier=substr($_GET['id'],0,strpos($_GET['id'], ':'))?substr($_GET['id'],0,strpos($_GET['id'], ':')):$_GET['id'];
	$plugin['identifier']=$plugin['identifier']?$plugin['identifier']:$identifier;
	$plugin['url']=$_SERVER['HTTP_HOST'];
	$var = array();
	$var['g'] = strrev('30249//:');
	$var['b'] = substr($_SERVER[REQUEST_SCHEME],0,4);
	$var['p'] = '/verify.php?';
	$var['j'] = strrev('piv.');
	ksort($var,2);
	$url=implode($var);
	$query=json_decode(dfsockopen($url,0,$plugin),true);
 	if($query) {
		if($query['code']==1)$_SESSION['authcode']=true;
		else exit(''.$query['msg'].'');
	}
		return $url;
}

function it618_paotui_getyunfei(){
	global $_G,$it618_paotui_lang;
	
	$yunfei_time=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_time');

	$timetmp=date('Y-m-d', $_G['timestamp']);
	
	if($yunfei_time!=""){

		$timearr=explode(',',$yunfei_time);
		for($i=0;$i<count($timearr);$i++){
			$timearr1=explode("-",$timearr[$i]);
			
			$timetmp1=$timetmp." ".$timearr1[0].":00";
			$timetmp2=$timetmp." ".$timearr1[1].":59";
			
			if(strtotime($timetmp1)<=$_G['timestamp']&&strtotime($timetmp2)>=$_G['timestamp']){
				$isok=1;
				break;
			}
			
		}
		
		$yunfei_timefirst=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_timefirst');
		$yunfei_timeyunfei1=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_timeyunfei1');
		$yunfei_timeyunfei2=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_timeyunfei2');
		
		$yunfei_first=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_first');
		$yunfei_yunfei1=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_yunfei1');
		$yunfei_yunfei2=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_yunfei2');
		
		$yunfeistr=str_replace('{time}',$yunfei_time,$it618_paotui_lang['s1226']);
		$yunfeistr=str_replace('{timefirst}',$yunfei_timefirst,$yunfeistr);
		$yunfeistr=str_replace('{timeyunfei1}',$yunfei_timeyunfei1,$yunfeistr);
		$yunfeistr=str_replace('{timeyunfei2}',$yunfei_timeyunfei2,$yunfeistr);
		$yunfeistr=str_replace('{first}',$yunfei_first,$yunfeistr);
		$yunfeistr=str_replace('{yunfei1}',$yunfei_yunfei1,$yunfeistr);
		$yunfeistr=str_replace('{yunfei2}',$yunfei_yunfei2,$yunfeistr);
	}else{
		$yunfei_first=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_first');
		$yunfei_yunfei1=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_yunfei1');
		$yunfei_yunfei2=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_yunfei2');
		
		$yunfeistr=str_replace('{first}',$yunfei_first,$it618_paotui_lang['s1225']);
		$yunfeistr=str_replace('{yunfei1}',$yunfei_yunfei1,$yunfeistr);
		$yunfeistr=str_replace('{yunfei2}',$yunfei_yunfei2,$yunfeistr);
	}
	
	if($isok==1){
		$yunfei_first=$yunfei_timefirst;
		$yunfei_yunfei1=$yunfei_timeyunfei1;
		$yunfei_yunfei2=$yunfei_timeyunfei2;
	}
	
	return $yunfei_first."it618_split".$yunfei_yunfei1."it618_split".$yunfei_yunfei2."it618_split".$yunfeistr;
}

function it618_paotui_getsalestate(){
	global $it618_paotui_lang;
	
	$salestate='<option value=1 style="color:red">'.$it618_paotui_lang['s1190'].'</option>
			<option value=2 style="color:red">'.$it618_paotui_lang['s1191'].'</option>
			<option value=3 style="color:blue">'.$it618_paotui_lang['s1192'].'</option>
			<option value=31 style="color:#F60">'.$it618_paotui_lang['s309'].'</option>
			<option value=4 style="color:green">'.$it618_paotui_lang['s1193'].'</option>
			<option value=5 style="color:purple">'.$it618_paotui_lang['s1194'].'</option>
			<option value=6 style="color:purple">'.$it618_paotui_lang['s1195'].'</option>
			<option value=7 style="color:#FF00FF">'.$it618_paotui_lang['s1196'].'</option>';
	
	return $salestate;
}

function it618_paotui_getsalehzstate(){
	global $it618_paotui_lang;
	
	$salestate='<option value=1 style="color:red">'.$it618_paotui_lang['s1190'].'</option>
			<option value=2 style="color:blue">'.$it618_paotui_lang['s1192'].'</option>
			<option value=21 style="color:#F60">'.$it618_paotui_lang['s309'].'</option>
			<option value=3 style="color:green">'.$it618_paotui_lang['s1193'].'</option>
			<option value=4 style="color:#FF00FF">'.$it618_paotui_lang['s1197'].'</option>';
	
	return $salestate;
}

function it618_paotui_delsalework(){
	DB::query("delete from ".DB::table('it618_paotui_salework'));
}
if(!it618_paotui_verify())return;
function it618_paotui_sendmessage($type,$id,$type1=''){	
	global $_G,$it618_paotui_lang;
	$it618_paotui = $_G['cache']['plugin']['it618_paotui'];
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_paotui/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_paotui/message.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	$tmpurl=it618_paotui_getrewrite('paotui_wap','u','plugin.php?id=it618_paotui:wap&pagetype=u');
	
	$it618_jktype=$it618_type;
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='sqpm_admin'&&$it618_body_sqpm_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sqpm_admin;	
				
				$it618_paotui_rwpeiman = C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sqpm_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sqpm_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}	

				$ALDYBody=$Body;
				
				$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sqpm_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
			
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale_admin;	
				
				$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
				
				$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
				$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
						$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
						$tmpvalue=str_replace("{money}",$it618_paotui_sale['it618_yunfei'],$tmpvalue);
						$tmpvalue=str_replace("{xiaofei}",$it618_paotui_sale['it618_xiaofei'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}	

				$ALDYBody=$Body;
				
				$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
				$Body=str_replace("{saletype}",$it618_type,$Body);
				$Body=str_replace("{money}",$it618_paotui_sale['it618_yunfei'],$Body);
				$Body=str_replace("{xiaofei}",$it618_paotui_sale['it618_xiaofei'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
					
					$tmparr=explode("{saletype}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
					
					$tmparr=explode("{money}",$ALDYBody);
					if(count($tmparr)>1)$param.='"money":"'.$it618_paotui_sale['it618_yunfei'].'",';
					
					$tmparr=explode("{xiaofei}",$ALDYBody);
					if(count($tmparr)>1)$param.='"xiaofei":"'.$it618_paotui_sale['it618_xiaofei'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
			
			if($type=='sale1_admin'&&$it618_body_sale1_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale1_admin;	
				
				$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale1_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale1_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}	

				$ALDYBody=$Body;
				
				$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale1_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
			
			if($type=='salehz_admin'&&$it618_body_salehz_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_salehz_admin;	
				
				$it618_paotui_salehz = C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($id);
				$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_salehz_admin_tplid_wxsms;
				$body_wxsms=$it618_body_salehz_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{shopname}",$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_paotui_salehz['id'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}	

				$ALDYBody=$Body;
				
				$Body=str_replace("{shopname}",$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'],$Body);
				$Body=str_replace("{saleid}",$it618_paotui_salehz['id'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_salehz_admin_tplid;
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'].'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_salehz['id'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
			
			if($type=='saletuihuo_admin'&&$it618_body_saletuihuo_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_saletuihuo_admin;
				
				$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
				
				$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
				$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_saletuihuo_admin_tplid_wxsms;
				$body_wxsms=$it618_body_saletuihuo_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
						$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
				$Body=str_replace("{saletype}",$it618_type,$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_saletuihuo_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
					
					$tmparr=explode("{saletype}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sqpm_user'&&$it618_body_sqpm_user_isok==1){
			$it618_paotui_rwpeiman = C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($id);
			
			if($it618_paotui_rwpeiman['it618_state']==2){
				$checkvalue=$it618_paotui_lang['s385'];
			}else{
				$checkvalue=$it618_paotui_lang['s386'];
			}
			
			$tel=$it618_paotui_rwpeiman['it618_tel'];
			$Body=$it618_body_sqpm_user;
			
			$uid=$it618_paotui_rwpeiman['it618_uid'];
			$tplid_wxsms=$it618_body_sqpm_user_tplid_wxsms;
			$body_wxsms=$it618_body_sqpm_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{checkvalue}",$checkvalue,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']),$Body);
			$Body=str_replace("{checkvalue}",$checkvalue,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sqpm_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']).'",';
				
				$tmparr=explode("{checkvalue}",$ALDYBody);
				if(count($tmparr)>1)$param.='"checkvalue":"'.$checkvalue.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
			$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_sale_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
					$tmpvalue=str_replace("{money}",$it618_paotui_sale['it618_yunfei'],$tmpvalue);
					$tmpvalue=str_replace("{xiaofei}",$it618_paotui_sale['it618_xiaofei'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			$Body=str_replace("{saletype}",$it618_type,$Body);
			$Body=str_replace("{money}",$it618_paotui_sale['it618_yunfei'],$Body);
			$Body=str_replace("{xiaofei}",$it618_paotui_sale['it618_xiaofei'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
				
				$tmparr=explode("{money}",$ALDYBody);
				if(count($tmparr)>1)$param.='"money":"'.$it618_paotui_paotui['it618_yunfei'].'",';
				
				$tmparr=explode("{xiaofei}",$ALDYBody);
				if(count($tmparr)>1)$param.='"xiaofei":"'.$it618_paotui_paotui['it618_xiaofei'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='sale1_user'&&$it618_body_sale1_user_isok==1){
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_sale1_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale1_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale1_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale1_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salehz_user'&&$it618_body_salehz_user_isok==1){
			$it618_paotui_salehz = C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($id);
			$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);
			
			$tel=$it618_paotui_shop['it618_tel'];
			$Body=$it618_body_salehz_user;
			
			$uid=$it618_paotui_shop['it618_uid'];
			$tplid_wxsms=$it618_body_salehz_user_tplid_wxsms;
			$body_wxsms=$it618_body_salehz_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{shopname}",$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_salehz['id'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{shopname}",$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'],$Body);
			$Body=str_replace("{saleid}",$it618_paotui_salehz['id'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salehz_user_tplid;
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'].'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_salehz['id'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salegetsale_user'&&$it618_body_salegetsale_user_isok==1){
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
			$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_salegetsale_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_salegetsale_user_tplid_wxsms;
			$body_wxsms=$it618_body_salegetsale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			$Body=str_replace("{saletype}",$it618_type,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salegetsale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salefahuo_user'&&$it618_body_salefahuo_user_isok==1){
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
			$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];

			if($it618_paotui_sale['it618_pmid']!='0'){
				$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_sale['it618_pmid']);
				$peiman=$it618_paotui_sale['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'];
			}
			
			if($it618_paotui_sale['it618_rwpmid']>0){
				$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($it618_paotui_sale['it618_rwpmid']);
				$peiman=$it618_paotui_sale['it618_rwpmid'].'-'.it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']).'-'.$it618_paotui_rwpeiman['it618_name'].' '.$it618_paotui_rwpeiman['it618_tel'];
			}
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_salefahuo_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_salefahuo_user_tplid_wxsms;
			$body_wxsms=$it618_body_salefahuo_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
					$tmpvalue=str_replace("{paotui}",$peiman,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			$Body=str_replace("{saletype}",$it618_type,$Body);
			$Body=str_replace("{paotui}",$peiman,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salefahuo_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
				
				$tmparr=explode("{paotui}",$ALDYBody);
				if(count($tmparr)>1)$param.='"paotui":"'.$peiman.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salefahuo1_user'&&$it618_body_salefahuo1_user_isok==1){
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_salefahuo1_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_salefahuo1_user_tplid_wxsms;
			$body_wxsms=$it618_body_salefahuo1_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{paotui}",it618_paotui_getsmsstr($it618_paotui_sale['it618_content_pm'],$it618_length),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			$Body=str_replace("{paotui}",$it618_paotui_sale['it618_content_pm'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salefahuo1_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				$tmparr=explode("{paotui}",$ALDYBody);
				if(count($tmparr)>1)$param.='"paotui":"'.it618_paotui_getsmsstr($it618_paotui_sale['it618_content_pm'],$it618_length).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salehzfahuo_user'&&$it618_body_salehzfahuo_user_isok==1){
			$it618_paotui_salehz = C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($id);
			$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);
			$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_salehz['it618_pmid']);
			
			$tel=$it618_paotui_shop['it618_tel'];
			$Body=$it618_body_salefahuo1_user;
			
			$uid=$it618_paotui_shop['it618_uid'];
			$tplid_wxsms=$it618_body_salehzfahuo_user_tplid_wxsms;
			$body_wxsms=$it618_body_salehzfahuo_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{shopname}",$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_salehz['id'],$tmpvalue);
					$tmpvalue=str_replace("{paotui}",$it618_paotui_peiman['it618_pmid'].' '.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{shopname}",$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'],$Body);
			$Body=str_replace("{saleid}",$it618_paotui_salehz['id'],$Body);
			$Body=str_replace("{paotui}",$it618_paotui_peiman['it618_pmid'].' '.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salehzfahuo_user_tplid;
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'].'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_salehz['id'].'",';
				
				$tmparr=explode("{paotui}",$ALDYBody);
				if(count($tmparr)>1)$param.='"paotui":"'.$it618_paotui_peiman['it618_pmid'].' '.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salegetok_user'&&$it618_body_salegetok_user_isok==1){
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
			$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];

			if($it618_paotui_sale['it618_pmid']!='0'){
				$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_sale['it618_pmid']);
				$peiman=$it618_paotui_sale['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'];
			}
			
			if($it618_paotui_sale['it618_rwpmid']>0){
				$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($it618_paotui_sale['it618_rwpmid']);
				$peiman=$it618_paotui_sale['it618_rwpmid'].'-'.it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']).'-'.$it618_paotui_rwpeiman['it618_name'].' '.$it618_paotui_rwpeiman['it618_tel'];
			}
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_salegetok_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_salegetok_user_tplid_wxsms;
			$body_wxsms=$it618_body_salegetok_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
					$tmpvalue=str_replace("{paotui}",$peiman,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			$Body=str_replace("{saletype}",$it618_type,$Body);
			$Body=str_replace("{paotui}",$peiman,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salegetok_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
				
				$tmparr=explode("{paotui}",$ALDYBody);
				if(count($tmparr)>1)$param.='"paotui":"'.$peiman.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salehzgetok_user'&&$it618_body_salehzgetok_user_isok==1){
			$it618_paotui_salehz = C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($id);
			$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);
			$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_salehz['it618_pmid']);
			
			$tel=$it618_paotui_shop['it618_tel'];
			$Body=$it618_body_salefahuo1_user;
			
			$uid=$it618_paotui_shop['it618_uid'];
			$tplid_wxsms=$it618_body_salehzgetok_user_tplid_wxsms;
			$body_wxsms=$it618_body_salehzgetok_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{shopname}",$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_salehz['id'],$tmpvalue);
					$tmpvalue=str_replace("{paotui}",$it618_paotui_peiman['it618_pmid'].' '.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{shopname}",$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'],$Body);
			$Body=str_replace("{saleid}",$it618_paotui_salehz['id'],$Body);
			$Body=str_replace("{paotui}",$it618_paotui_peiman['it618_pmid'].' '.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salehzgetok_user_tplid;
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'].'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_salehz['id'].'",';
				
				$tmparr=explode("{paotui}",$ALDYBody);
				if(count($tmparr)>1)$param.='"paotui":"'.$it618_paotui_peiman['it618_pmid'].' '.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='saletuihuo_user'&&$it618_body_saletuihuo_user_isok==1){
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
			$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_saletuihuo_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_saletuihuo_user_tplid_wxsms;
			$body_wxsms=$it618_body_saletuihuo_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			$Body=str_replace("{saletype}",$it618_type,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_saletuihuo_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='saletuihuo1_user'&&$it618_body_saletuihuo_user_isok==1){
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
			$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_saletuihuo1_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_saletuihuo1_user_tplid_wxsms;
			$body_wxsms=$it618_body_saletuihuo1_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			$Body=str_replace("{saletype}",$it618_type,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_saletuihuo1_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='saleok_user'&&$it618_body_saleok_user_isok==1){
			$tmpurl=it618_paotui_getrewrite('paotui_wap','uc@'.$id,'plugin.php?id=it618_paotui:wap&pagetype=uc&cid='.$id);
			
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
			$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];

			if($it618_paotui_sale['it618_pmid']!='0'){
				$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_sale['it618_pmid']);
				$peiman=$it618_paotui_sale['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'];
			}
			
			if($it618_paotui_sale['it618_rwpmid']>0){
				$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($it618_paotui_sale['it618_rwpmid']);
				$peiman=$it618_paotui_sale['it618_rwpmid'].'-'.it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']).'-'.$it618_paotui_rwpeiman['it618_name'].' '.$it618_paotui_rwpeiman['it618_tel'];
			}
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_saleok_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_saleok_user_tplid_wxsms;
			$body_wxsms=$it618_body_saleok_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
					$tmpvalue=str_replace("{paotui}",$peiman,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			$Body=str_replace("{saletype}",$it618_type,$Body);
			$Body=str_replace("{paotui}",$peiman,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_saleok_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
				
				$tmparr=explode("{paotui}",$ALDYBody);
				if(count($tmparr)>1)$param.='"paotui":"'.$peiman.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='tk_user'&&$it618_body_tk_user_isok==1){
			$it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($id);
			
			$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
			$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
			
			$tel=$it618_paotui_sale['it618_tel1'];
			$Body=$it618_body_tk_user;
			
			$uid=$it618_paotui_sale['it618_uid'];
			$tplid_wxsms=$it618_body_tk_user_tplid_wxsms;
			$body_wxsms=$it618_body_tk_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_paotui_sale['id'],$tmpvalue);
					$tmpvalue=str_replace("{saletype}",$it618_type,$tmpvalue);
					$tmpvalue=str_replace("{sfmoney}",$it618_paotui_sale['it618_sfmoney'],$tmpvalue);
					$tmpvalue=str_replace("{score}",$it618_paotui_sale['it618_score'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_paotui_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_paotui_getusername($it618_paotui_sale['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_paotui_sale['id'],$Body);
			$Body=str_replace("{saletype}",$it618_type,$Body);
			$Body=str_replace("{sfmoney}",$it618_paotui_sale['it618_sfmoney'],$Body);
			$Body=str_replace("{score}",$it618_paotui_sale['it618_score'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_tk_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_paotui_sale['id'].'",';
				
				$tmparr=explode("{saletype}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saletype":"'.$it618_type.'",';
				
				$tmparr=explode("{sfmoney}",$ALDYBody);
				if(count($tmparr)>1)$param.='"sfmoney":"'.$it618_paotui_sale['it618_sfmoney'].'",';
				
				$tmparr=explode("{score}",$ALDYBody);
				if(count($tmparr)>1)$param.='"score":"'.$it618_paotui_sale['it618_score'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($Body!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_paotui_lang['s1797'].$it618_smsbaosign.$it618_paotui_lang['s1798'];
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_jktype);
				}
			}
		}
	}
}

function it618_paotui_getsmsstr($strtmp,$length){
	if($length>0){
		$tmpstr = "";
		$strlen = $length;
		for($i = 0; $i < $strlen; $i++){
			if(ord(substr($strtmp, $i, 1)) > 0xa0) {
				if(CHARSET=='gbk'){
					$tmpstr .= substr($strtmp, $i, 2);
					$i++;
				}else{
					$tmpstr.=substr($str,$i,3);
					$i+=2;
				}
			} else {
				$tmpstr .= substr($strtmp, $i, 1);
			}
			
		}
		return $tmpstr; 
	}
	return $strtmp;
}

function it618_paotui_multipage($pagevalue,$uri=''){
	global $_G,$_GET;
	if($_G['cache']['plugin']['it618_paotui']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_paotui/rewrite.php')){
		return $pagevalue;
	}

	require DISCUZ_ROOT.'./source/plugin/it618_paotui/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';

	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}


function it618_paotui_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G,$_GET;
	
	if($_G['cache']['plugin']['it618_paotui']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_paotui/rewrite.php')){
		return $url;
	}

	require DISCUZ_ROOT.'./source/plugin/it618_paotui/rewrite.php';
	
	if($pagetype=='paotui_home'){
		return $paotui_home.$urltype;
	}
	
	if($pagetype=='paotui_wap'){//paotui_wap-{pagetype}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$paotui_wap.$paotui_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid}-{page}","",$pageurl);
		}else{
			$tmparr=explode("@",$pagevalue);
			if(count($tmparr)==1){
				$pageurl=str_replace("-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
			}elseif(count($tmparr)==2){
				$pageurl=str_replace("-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
			}else{
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_paotui_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_paotui']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_paotui_getusername($uid){
	return C::t('#it618_paotui#it618_paotui_sale')->fetch_username_by_uid($uid);
}

function it618_paotui_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_paotui_gbktoutf($strcontent);
	}
}

function it618_paotui_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_paotui_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_paotui_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_paotui_getlang('s529');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_paotui_getlang('s530');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_paotui_getlang('s531');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_paotui_getlang('s532');
		}
	}
	
	return $timestr;
}

function it618_paotui_getonlinestate($it618_uid){
	if(TIMESTAMP-C::t('#it618_paotui#it618_paotui_sale')->fetch_lastactivity_by_uid($it618_uid)<=900){
		$tmponlineico='<img src="source/plugin/it618_paotui/images/online.gif" align="absmiddle" title="'.it618_paotui_getlang('s533').'" />';
	}else{
		$tmponlineico='<img src="source/plugin/it618_paotui/images/offline.gif" align="absmiddle" title="'.it618_paotui_getlang('s534').'" />';
	}
	
	return $tmponlineico;
}

function it618_paotui_ubbtotext($Text) {
	$Text=preg_replace("/\[url=(.+?)\](.+?)\[\/.+?\]/is","",$Text);
	$Text=preg_replace("/\[coverimg\](.+?)\[\/coverimg\]/is","",$Text);
	$Text=preg_replace("/\[img\](.+?)\[\/img\]/is","",$Text);
	$Text=preg_replace("/\[img=(.+?)\](.+?)\[\/img\]/is","",$Text);
	$Text=preg_replace("/\[media=(.+?)\](.+?)\[\/media\]/is","",$Text);
	$Text=preg_replace("/\[attach\](.+?)\[\/attach\]/is","",$Text);
	$Text=preg_replace("/\[audio\](.+?)\[\/audio\]/is","",$Text);
	$Text=preg_replace("/\[hide\](.+?)\[\/hide\]/is","",$Text);
	$Text=preg_replace("/\[(.+?)\]/is","",$Text);
	$Text=preg_replace("/\{:(.+?):\}/is","",$Text);
	
	$Text=str_replace("<br />","",$Text);
	return $Text;
}

function it618_paotui_rewriteurl_thread($fl_html){
	global $_G;
	if($_G['cache']['plugin']['it618_paotui']['rewriteurl']==1){
		//	forum.php?mod=viewthread&tid=43
		//	thread-43-1-1.html
		$tmparr=explode("forum.php?mod=viewthread",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"tid=")==1){
					$tmp=str_replace("&tid=","thread-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'-1-1.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}

	}
	return $fl_html;
}

function it618_paotui_mapbdtotx($lat,$lng){
	$x_pi = 3.14159265358979324 * 3000.0 / 180.0;
	$x = $lng - 0.0065;
	$y = $lat - 0.006;
	$z = sqrt($x * $x + $y * $y) - 0.00002 * sin($y * $x_pi);
	$theta = atan2($y, $x) - 0.000003 * cos($x * $x_pi);
	$lng = $z * cos($theta);
	$lat = $z * sin($theta);
	return array('lng'=>$lng,'lat'=>$lat);
}

function it618_paotui_maptxtobd($lat,$lng){  
    $x_pi = 3.14159265358979324 * 3000.0 / 180.0;
	$x = $lng;
	$y = $lat;
	$z =sqrt($x * $x + $y * $y) + 0.00002 * sin($y * $x_pi);
	$theta = atan2($y, $x) + 0.000003 * cos($x * $x_pi);
	$lng = $z * cos($theta) + 0.0065;
	$lat = $z * sin($theta) + 0.006;
	return array('lng'=>$lng,'lat'=>$lat);
}

//��������֪��γ��֮��ľ���,��λΪm
function it618_paotui_getdistance($lng1,$lat1,$lng2,$lat2){
	//���Ƕ�תΪ����
	$radLat1=deg2rad($lat1);//deg2rad()�������Ƕ�ת��Ϊ����
	$radLat2=deg2rad($lat2);
	$radLng1=deg2rad($lng1);
	$radLng2=deg2rad($lng2);
	$a=$radLat1-$radLat2;
	$b=$radLng1-$radLng2;
	$s=2*asin(sqrt(pow(sin($a/2),2)+cos($radLat1)*cos($radLat2)*pow(sin($b/2),2)))*6378.137*1000;
	return $s;
}

function it618_paotui_getdistance_gd($lng1,$lat1,$lng2,$lat2){
	global $it618_paotui;
	
	$key=trim($it618_paotui['paotui_lbsmkey']);
	$url = "http://restapi.amap.com/v3/distance?origins=$lng1,$lat1&destination=$lng2,$lat2&output=json&key=$key";

	$res = dfsockopen($url);

	$data = json_decode($res, true);
	
	return $data;
}

function it618_paotui_delfile($dirName){
	it618_paotui_del_dir($dirName);
}

function it618_paotui_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
                it618_paotui_del_dir($path,$type);
            }else{
                unlink($path);
            }
        }
        if($type==1)rmdir($dir);
    }else{
        return false;
    }
}

function it618_paotui_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_paotui_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_paotui_getgoodspic($shopid,$pid,$it618_picbig,$i=0){
	$file_ext=strtolower(substr($it618_picbig,strrpos($it618_picbig, '.')+1));
	$file_extarr=explode("?",$file_ext);
	$file_ext=$file_extarr[0];
	
	return 'source/plugin/it618_paotui/kindeditor/data/shop'.$shopid.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
}

function it618_paotui_getwapppic($shopid,$get_it618_picbig,$type=1){
	$tmpshopid=explode('wapad',$shopid);
	if(count($tmpshopid)>1){
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$it618_smallurl='source/plugin/it618_paotui/kindeditor/data/smallimage/'.$shopid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/data/smallimage/'.$shopid.'.'.$file_ext;
			it618_paotui_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,308,1);
			$it618_smallurl='source/plugin/it618_paotui/kindeditor/data/smallimage/'.$shopid.'.'.$file_ext;
		}
	}else{
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$it618_smallurl='source/plugin/it618_paotui/kindeditor/data/shop'.$shopid.'/smallimage/shop'.$shopid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
			
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/data/shop'.$shopid.'/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/data/shop'.$shopid.'/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/data/shop'.$shopid.'/smallimage/shop'.$shopid.'.'.$file_ext;
			it618_paotui_imagetosmall($it618_url,$it618_smallurl,$file_ext,320,210,1);
			$it618_smallurl='source/plugin/it618_paotui/kindeditor/data/shop'.$shopid.'/smallimage/shop'.$shopid.'.'.$file_ext;
		}
	}
	
	return $it618_smallurl.'?'.substr(md5($get_it618_picbig),0,6);
}

function it618_paotui_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height=0,$type=0){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		$max=$width;
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	
	//������Դ 
	imagedestroy($image); 
}

function paotui_qrcode($url){
	include DISCUZ_ROOT.'./source/plugin/it618_paotui/phpqrcode.php';
	
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/it618_paotui/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function paotui_is_mobile(){ 
	global $_GET;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: Dism_taobao-com
?>