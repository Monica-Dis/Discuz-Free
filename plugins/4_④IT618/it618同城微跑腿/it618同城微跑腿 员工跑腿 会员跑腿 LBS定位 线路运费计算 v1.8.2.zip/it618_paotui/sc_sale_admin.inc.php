<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';
$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
$strtmp='('.$paotui_topname[0].$it618_paotui_lang['s186'].$paotui_topname[1].$it618_paotui_lang['s186'].$paotui_topname[2].')';

$sctitle=it618_paotui_getlang('s1563').$strtmp;
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/sc_header.func.php';

$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
if(!in_array($_G['uid'],$saleadmin)){
	it618_cpmsg($it618_paotui_lang['s28'], '', 'error');
}

$it618_clienid=getcookie('it618_clienid');
if($it618_clienid==''){
	$it618_clienid=md5(time());
	dsetcookie('it618_clienid',$it618_clienid,3600*24*365);
}

echo '
<audio id="bgMusic">
    <source src="'.$it618_paotui['paotui_salemp3src'].'" type="audio/mp3">
</audio>
<span id="tmpalertbtn"></span>

<script charset="utf-8" src="source/plugin/it618_paotui/js/Calendar.js"></script>
<link rel="stylesheet" href="source/plugin/it618_paotui/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_paotui/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_paotui/js/jquery.js"></script>
<script type="text/javascript" src="source/plugin/it618_paotui/js/clipboard.min.js"></script>

<script>
var isok=0;
var audio = document.getElementById("bgMusic");

function getisok(){
	if(isok==1){
		isok=0;
		document.getElementById("isokbtn").style.backgroundColor="#e8e8e8";
		document.getElementById("isokbtn").style.color="green";
		document.getElementById("isokbtn").innerHTML="'.$it618_paotui_lang['s1558'].'";
	}else{
		isok=1;
		document.getElementById("isokbtn").style.backgroundColor="#390";
		document.getElementById("isokbtn").style.color="#fff";
		document.getElementById("isokbtn").innerHTML="'.$it618_paotui_lang['s1559'].'";
	}
}

function getsaleaudio(){
	if(isok==1){
		IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax&typeid=0&clienid='.$it618_clienid.'", {ac:"getsaleaudio"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[1]=="ok"){
			audio.currentTime = 0;
			audio.play();
			getsalelist(saleurl);
		}
		}, "html");	
	}
}

var dialog_sale;

IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax&typeid=0&update&clienid='.$it618_clienid.'", {ac:"getsaleaudio"},function (data, textStatus){
	getisok();
	var tmptime = window.setInterval(getsaleaudio,'.($it618_paotui['paotui_saletime']*1000).');
}, "html");	
</script>
';

$salestate=it618_paotui_getsalestate();

$query = DB::query("SELECT * FROM ".DB::table('it618_paotui_peiman')." ORDER BY it618_order");
while($it618_paotui_peiman = DB::fetch($query)) {
	$selected='';
	if($it618_paotui_peiman['it618_pmid']==$it618_paotui_sale['it618_pmid']){
		$selected='selected="selected"';
	}
	$peimenstr.='<option value="'.$it618_paotui_peiman['it618_pmid'].'" '.$selected.'>'.$it618_paotui_peiman['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'].'</option>';
}

showtableheaders(it618_paotui_getlang('s1563').$strtmp,'it618_paotui_sum');

if($it618_paotui['paotui_pmmodehide']==0){
	$pmmodestr='<th>'.$it618_paotui_lang['s333'].'</th>';
}

	$tmpstr='<span style="float:right"><a href="javascript:" id="isokbtn" onclick="getisok()" style="display:block;background-color:#e8e8e8;color:green;height:20px;padding:3px 15px;padding-top:6px;text-decoration:none;font-weight:bold">'.$it618_paotui_lang['s1558'].'</a></span>';
	
	echo '<tr><td colspan="15"><div class="fixsel">'.$tmpstr.it618_paotui_getlang('s1115').' <input id="finduid" class="txt" style="width:68px" /> '.it618_paotui_getlang('s4').' <select id="peiman"><option value=0>'.it618_paotui_getlang('s1574').'</option>'.$peimenstr.'</select> '.it618_paotui_getlang('s1116').' <select id="state"><option value=0>'.it618_paotui_getlang('s1117').'</option>'.$salestate.'</select> '.it618_paotui_getlang('s1122').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_paotui_getlang('s1123').'" onclick="findsalelist()" /> <input type="button" class="btn" value="'.it618_paotui_getlang('s1119').'" onclick="dao()" /> </div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>
	<tr class="header">
	<th width=58>'.$it618_paotui_lang['s1124'].'</th>
	<th>'.$it618_paotui_lang['s1118'].'</th>
	<th>'.$it618_paotui_lang['s1127'].'</th>
	<th>'.$it618_paotui_lang['s1128'].'</th>
	<th>'.$it618_paotui_lang['s1129'].'</th>
	<th>'.$it618_paotui_lang['s1130'].'</th>
	<th>'.$it618_paotui_lang['s1126'].'</th>
	<th>'.$it618_paotui_lang['s1132'].'</th>
	'.$pmmodestr.'
	<th width=100>'.$it618_paotui_lang['s1134'].'</th>
	<th width=150>'.$it618_paotui_lang['s1135'].'</th>
	</tr>';
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_paotui/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr><div id="salefahuo" style="display:none"></div><div id="salebz" style="display:none"></div><div id="salepj" style="display:none"></div><div id="tmpsalebtn"></div><div id="tmpsalelbsbtn"></div><a class="clipboardbtnsale" id="clipboardbtnsale" data-clipboard-text=""></a>';

showtablefooter();
echo '
<script>
var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax";
var sqlurl="";
function getsalelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_PAOTUI.get(url+sqlurl+"&formhash='.FORMHASH.'", {ac:"sale_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_PAOTUI("#tr_salesum").html(tmparr[0]);
	IT618_PAOTUI("#tr_salelist").html(tmparr[1]);
	IT618_PAOTUI("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}

function findsalelist(){
	var finduid = document.getElementById("finduid").value;
	var peiman = document.getElementById("peiman").value;
	var state = document.getElementById("state").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&finduid="+finduid+"&peiman="+peiman+"&state="+state+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax";
	getsalelist(url);
}

findsalelist();

function dao(){
	findsalelist();
	IT618_PAOTUI.get(saleurl+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_dao"},function (data, textStatus){
	window.open(data);
	}, "html");	
}

function sale_getsale(saleid){
	if(confirm("'.it618_paotui_getlang('s1160').'")){
		IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_getsale"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function sale_getok(saleid){
	if(confirm("'.it618_paotui_getlang('s373').'")){
		IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_getok"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function sale_isrwpmpower(saleid){
	if(confirm("'.it618_paotui_getlang('s352').'")){
		IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_isrwpmpower"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

var dialog_salefahuo,salefahuoid=0;
KindEditor.ready(function(K) {K(\'#salefahuo\').click(function() {
	getsalefahuo(K);
});});

function sale_fahuo(saleid){
	if(salefahuoid==0){
		salefahuoid=saleid;
		IT618_PAOTUI("#salefahuo").click();
	}
}

function getsalefahuo(K){
IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:salefahuo"+"&saleid="+salefahuoid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	IT618_PAOTUI("#clipboardbtnsale").attr("data-clipboard-text",tmparr[1]);
	
	dialog_salefahuo = K.dialog({
		width : 633,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[2]+\'</div>\',
		closeBtn : {
			name : \''.$it618_paotui_lang['t571'].'\',
			click : function(e) {
				dialog_salefahuo.remove();
				salefahuoid=0;
			}
		}
	});
	
	IT618_PAOTUI(\'.ns-sub-a\').click(function(){
		
		if(confirm("'.$it618_paotui_lang['s1166'].'")){
			
			IT618_PAOTUI.post("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax"+"&ac=sale_fahuo"+"&saleid="+salefahuoid+"&formhash='.FORMHASH.'",IT618_PAOTUI("#it618_salefahuo").serialize(),function (data, textStatus){
				var tmparr=data.split("it618_split");
			
				if(tmparr[0]=="ok"){
					alert(tmparr[1]);
					dialog_salefahuo.remove();
					getsalelist(saleurl);
					salefahuoid=0;
				}else{
					alert(tmparr[1]);
				}
			}, "html");
		}
	})
	
	IT618_PAOTUI(\'.ns-sub-b\').click(function(){
		dialog_salefahuo.remove();
		salefahuoid=0;
	})
	
	}, "html");		
}

var dialog_salebz,salebzid=0;
KindEditor.ready(function(K) {K(\'#salebz\').click(function() {
	getsalebz(K);
});});

function sale_bz(saleid){
	if(salebzid==0){
		salebzid=saleid;
		IT618_PAOTUI("#salebz").click();
	}
}

function getsalebz(K){
IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:salebz"+"&saleid="+salebzid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	IT618_PAOTUI("#clipboardbtnsale").attr("data-clipboard-text",tmparr[1]);
	
	dialog_salebz = K.dialog({
		width : 633,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[2]+\'</div>\',
		closeBtn : {
			name : \''.$it618_paotui_lang['t571'].'\',
			click : function(e) {
				dialog_salebz.remove();
				salebzid=0;
			}
		}
	});
	
	IT618_PAOTUI(\'.ns-sub-a\').click(function(){
			
		IT618_PAOTUI.post("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax"+"&ac=sale_bz"+"&saleid="+salebzid+"&formhash='.FORMHASH.'",IT618_PAOTUI("#it618_salebz").serialize(),function (data, textStatus){
			var tmparr=data.split("it618_split");
		
			if(tmparr[0]=="ok"){
				alert(tmparr[1]);
				dialog_salebz.remove();
				getsalelist(saleurl);
				salebzid=0;
			}else{
				alert(tmparr[1]);
			}
		}, "html");
	})
	
	IT618_PAOTUI(\'.ns-sub-b\').click(function(){
		dialog_salebz.remove();
		salebzid=0;
	})
	
	}, "html");		
}

var dialog_salepj,salepjid=0;
KindEditor.ready(function(K) {K(\'#salepj\').click(function() {
	getsalepj(K);
});});

function sale_pj(saleid){
	if(salepjid==0){
		salepjid=saleid;
		IT618_PAOTUI("#salepj").click();
	}
}

function getsalepj(K){
	IT618_PAOTUI(\'.cd-popup\').addClass(\'is-visible\');
	IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:salepj&saleid="+salepjid, {ac:"it618"},function (data, textStatus){
	
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	dialog_salepj = K.dialog({
		width : 633,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.$it618_paotui_lang['t571'].'\',
			click : function(e) {
				dialog_salepj.remove();
				salepjid=0;
			}
		}
	});
	
	setpjcolor1(tmparr[3]);
	
	IT618_PAOTUI(\'.ns-sub-a\').click(function(){

		if(confirm(tmparr[2])){
			
			IT618_PAOTUI.post("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax&ac=sale_pj&saleid="+saleid+"&formhash={FORMHASH}",IT618_PAOTUI("#it618_salepj").serialize(),function (data, textStatus){
				var tmparr=data.split("it618_split");
			
				if(tmparr[0]=="ok"){
					alert(tmparr[1]);
					IT618_PAOTUI(\'.cd-popup\').removeClass(\'is-visible\');
					getsalelist(saleurl);
				}else{
					alert(data);
				}
			}, "html");
		}
	
	})
	IT618_PAOTUI(\'.ns-sub-b\').click(function(){
		dialog_salepj.remove();
		salepjid=0;
	})
	
	}, "html");	
}

function setpjcolor1(id){
	document.getElementById("lab1").style.color="#000";
	document.getElementById("lab2").style.color="#000";
	document.getElementById("lab3").style.color="#000";
	
	document.getElementById("lab"+id).style.color="#FF6600";
}

function sale_jujuetui(saleid){
	if(confirm("'.it618_paotui_getlang('s1212').'")){
		IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_jujuetui"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function sale_tongyitui(saleid){
	if(confirm("'.it618_paotui_getlang('s1215').'")){
		IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_tongyitui"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

var saleid;
function showsale(id){
	saleid=id;
	document.getElementById("tmpsalebtn").click();
}

KindEditor.ready(function(K) {K(\'#tmpsalebtn\').click(function() {
	
	IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:showsale&saleid="+saleid, {ac:"admin"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	IT618_PAOTUI("#clipboardbtnsale").attr("data-clipboard-text",tmparr[0]);
	
	dialog_sale = K.dialog({
		width : 633,
		title : \''.it618_paotui_getlang('s1126').'\',
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.it618_paotui_getlang('s1107').'\',
			click : function(e) {
				dialog_sale.remove();
			}
		}
	});
	
	}, "html");	
});});

var salelbsid;
function showsalelbs(id){
	salelbsid=id;
	document.getElementById("tmpsalelbsbtn").click();
}

KindEditor.ready(function(K) {K(\'#tmpsalelbsbtn\').click(function() {
	
	IT618_PAOTUI.get("'.$_G['siteurl'].'plugin.php?id=it618_paotui:showsalelbs&saleid="+salelbsid, {ac:"admin"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	dialog_salelbs = K.dialog({
		width : 638,
		title : \''.it618_paotui_getlang('s370').'\',
		body : \'<div style="padding:5px;padding-left:3px">\'+data+\'</div>\',
		closeBtn : {
			name : \''.it618_paotui_getlang('s1107').'\',
			click : function(e) {
				dialog_salelbs.remove();
			}
		}
	});
	
	}, "html");	
});});

var clipboardbtnsale = new Clipboard(".clipboardbtnsale");
clipboardbtnsale.on("success", function(e) {
	alert("'.$it618_paotui_lang['s1121'].'");
});
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/sc_footer.func.php';
?>