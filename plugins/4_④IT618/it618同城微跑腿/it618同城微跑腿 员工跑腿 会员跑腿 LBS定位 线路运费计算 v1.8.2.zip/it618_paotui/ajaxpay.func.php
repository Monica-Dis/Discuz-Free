<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function pay_success($out_trade_no){
	global $_G;
	
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
		if($it618_salepay['it618_state']==1)return;
	}else{
		return;	
	}
	
	$salepay_saletype=$it618_salepay['it618_saletype'];
	$salepay_saleid=$it618_salepay['it618_saleid'];
	$salepay_paytype=$it618_salepay['it618_paytype'];
	$salepay_payid=$it618_salepay['it618_payid'];
	$salepay_url=$it618_salepay['it618_url'];
	$salepay_wap=$it618_salepay['it618_wap'];
	
	$siteurl="http://".$_SERVER ['HTTP_HOST']."/";
	require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_paotui_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_paotui_delsalework();
		}
	}
	C::t('#it618_paotui#it618_paotui_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	
	if($salepay_saletype=='0401'){
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($salepay_saleid);
			
		if($it618_paotui_sale['it618_state']!=1){
			C::t('#it618_paotui#it618_paotui_sale')->update($salepay_saleid,array(
				'it618_state' => 1
			));
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			C::t('common_member_count')->increase($it618_paotui_sale['it618_uid'], array(
				'extcredits'.$it618_paotui['paotui_credit'] => (0-$it618_paotui_sale['it618_score']))
			);
			
			it618_paotui_delsalework();

			it618_paotui_sendmessage('sale_user',$it618_paotui_sale['id']);
			it618_paotui_sendmessage('sale_admin',$it618_paotui_sale['id']);
			
			DB::query("update ".DB::table('it618_paotui_saleaudio')." set it618_state=1 WHERE it618_typeid=0");

			return 'success';

		}
	
	}

}
//From: Dism_taobao-com
?>