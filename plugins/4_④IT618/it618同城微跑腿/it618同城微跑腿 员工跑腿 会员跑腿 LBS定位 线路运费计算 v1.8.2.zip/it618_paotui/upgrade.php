<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_paotui_rwpeiman` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_lbsaddr` varchar(200) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_paotui_rwpmtcbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pj1` float(9,2) NOT NULL,
  `it618_pj2` float(9,2) NOT NULL,
  `it618_jdcount` int(10) unsigned NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_paotui_salehz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_pmid` varchar(50) NOT NULL,
  `it618_pmtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content_pm` varchar(1000) NOT NULL,
  `it618_editcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_paotui_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_hzshopid` varchar(50) NOT NULL,
  `it618_logo` varchar(200) NOT NULL,
  `it618_name` varchar(200) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_mappoint` varchar(50) NOT NULL,
  `it618_htstate` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_htetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_paotui_saleaudio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_paotui_saleaudio'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_clienid', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_saleaudio')." add `it618_clienid` varchar(32) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_paotui_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_shopid', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_isrwpmpower', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_isrwpmpower` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_pj', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_pj` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_pjcontent', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_pjcontent` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_pjtime', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_pjtime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_tuihuotype', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_tuihuotype` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_rwpmid', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_rwpmid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_rwpmidedit', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_rwpmidedit` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_pmtime', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_pmtime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	DB::query("truncate table ".DB::table('it618_paotui_bottomnav'));
}

if(!in_array('it618_pmoktime', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_pmoktime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_rwtcbl', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_sale')." add `it618_rwtcbl` float(9,2) NOT NULL;";
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_paotui_salehz'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_pmoktime', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_salehz')." add `it618_pmoktime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_paotui_rwpeiman'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_qq', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_rwpeiman')." add `it618_qq` varchar(50) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_wx', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_rwpeiman')." add `it618_wx` varchar(100) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_addr', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_rwpeiman')." add `it618_addr` varchar(100) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_liyou', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_rwpeiman')." add `it618_liyou` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_lbstime', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_rwpeiman')." add `it618_lbstime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_clockstate', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_rwpeiman')." add `it618_clockstate` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_rztime', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_rwpeiman')." add `it618_rztime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_paotui_peiman'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_uid', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_peiman')." add `it618_uid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_lbslat', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_peiman')." add `it618_lbslat` float(9,6) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_lbslng', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_peiman')." add `it618_lbslng` float(9,6) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_lbsaddr', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_peiman')." add `it618_lbsaddr` varchar(200) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_lbstime', $col_field)){
	$sql = "Alter table ".DB::table('it618_paotui_peiman')." add `it618_lbstime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>