<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G,$it618_paotui;

$it618_paotui = $_G['cache']['plugin']['it618_paotui'];

$bdkey=trim($it618_paotui['paotui_bdkey']);

require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/lang.func.php';

$mappoint=$_GET['mappoint'];
if($mappoint==''){
	$mappoint=it618_paotui_getlang('s873');
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_paotui:getpoint');
?>