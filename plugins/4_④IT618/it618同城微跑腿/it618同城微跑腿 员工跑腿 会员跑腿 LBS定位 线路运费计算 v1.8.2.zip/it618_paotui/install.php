<?php

(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_paotui_peiman`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_peiman` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pmid` varchar(50) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_lbsaddr` varchar(200) NOT NULL,
  `it618_lbstime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_rwpeiman`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_rwpeiman` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_qq` varchar(50) NOT NULL,
  `it618_wx` varchar(100) NOT NULL,
  `it618_addr` varchar(100) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_liyou` varchar(1000) NOT NULL,
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_lbsaddr` varchar(200) NOT NULL,
  `it618_lbstime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_clockstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rztime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_rwpmtcbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_rwpmtcbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pj1` float(9,2) NOT NULL,
  `it618_pj2` float(9,2) NOT NULL,
  `it618_jdcount` int(10) unsigned NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_xiaofei` float(9,2) NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_scoremoney` float(9,2) NOT NULL,
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_name1` varchar(20) NOT NULL,
  `it618_tel1` varchar(20) NOT NULL,
  `it618_lbslat1` float(9,6) NOT NULL,
  `it618_lbslng1` float(9,6) NOT NULL,
  `it618_lbsaddr1` varchar(200) NOT NULL,
  `it618_addr1` varchar(200) NOT NULL,
  `it618_name2` varchar(200) NOT NULL,
  `it618_tel2` varchar(20) NOT NULL,
  `it618_lbslat2` float(9,6) NOT NULL,
  `it618_lbslng2` float(9,6) NOT NULL,
  `it618_lbsaddr2` varchar(200) NOT NULL,
  `it618_addr2` varchar(200) NOT NULL,
  `it618_time2` varchar(20) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_pmid` varchar(50) NOT NULL,
  `it618_rwpmid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rwpmidedit` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pmtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pmoktime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rwtcbl` float(9,2) NOT NULL,
  `it618_content_pm` varchar(1000) NOT NULL,
  `it618_isrwpmpower` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjcontent` varchar(1000) NOT NULL,
  `it618_pjtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state_tuihuo` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content_tuihuo` varchar(1000) NOT NULL,
  `it618_tuihuotype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_paytype` varchar(50) NOT NULL,
  `it618_payid` varchar(100) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_salehz`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_salehz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_pmid` varchar(50) NOT NULL,
  `it618_pmtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pmoktime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content_pm` varchar(1000) NOT NULL,
  `it618_editcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_saleaudio`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_saleaudio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_clienid` varchar(32) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_shop`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_hzshopid` varchar(50) NOT NULL,
  `it618_logo` varchar(200) NOT NULL,
  `it618_name` varchar(200) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_mappoint` varchar(50) NOT NULL,
  `it618_htstate` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_htetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_paotui_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_paotui_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yytime_isok',
	'setvalue' => '1'
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yytime_isokbz',
	'setvalue' => ''
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yytime_isoktime',
	'setvalue' => ''
), true);

C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yunfei_time',
	'setvalue' => ''
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yunfei_timefirst',
	'setvalue' => '3'
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yunfei_timeyunfei1',
	'setvalue' => '6'
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yunfei_timeyunfei2',
	'setvalue' => '2'
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yunfei_first',
	'setvalue' => '3'
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yunfei_yunfei1',
	'setvalue' => '6'
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yunfei_yunfei2',
	'setvalue' => '2'
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'yunfei_xiaofei',
	'setvalue' => ''
), true);
C::t('#it618_paotui#it618_paotui_set')->insert(array(
	'setname' => 'scorebl',
	'setvalue' => '100'
), true);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>