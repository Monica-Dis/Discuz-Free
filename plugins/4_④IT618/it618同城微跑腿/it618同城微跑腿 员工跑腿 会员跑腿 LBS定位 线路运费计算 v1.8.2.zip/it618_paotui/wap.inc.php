<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G,$paotui_topname;

$it618_paotui = $_G['cache']['plugin']['it618_paotui'];
$metakeywords = $it618_paotui['seokeywords'];
$metadescription = $it618_paotui['seodescription'];
$creditname=$_G['setting']['extcredits'][$it618_paotui['paotui_credit']]['title'];
$sitetitle=$it618_paotui['paotui_name'];

require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

$waphome=it618_paotui_getrewrite('paotui_wap','','plugin.php?id=it618_paotui:wap');
$wapu=it618_paotui_getrewrite('paotui_wap','u@0','plugin.php?id=it618_paotui:wap&pagetype=u');

if(!paotui_is_mobile()){ 
	$homeurl=it618_paotui_getrewrite('paotui_home','','plugin.php?id=it618_paotui:index');
	dheader("location:$homeurl");
}

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_paotui#it618_paotui_wapstyle')->count_by_isok_search();
$it618_paotui_wapstyle=C::t('#it618_paotui#it618_paotui_wapstyle')->fetch_by_isok_search();

if(isset($_GET['pagetype'])){
	$pagetypearray = array('paotui', 'ptsale', 'uc', 'sc', 'admin', 'adminhz', 'pm', 'pmhz', 'rwpm', 'rw', 'u');
	$pagetype = !in_array($_GET['pagetype'], $pagetypearray) ? 'ptsale' : $_GET['pagetype'];
}else{
	$pagetype='paotui';
	$navtitle=$sitetitle;
}

$paotui_topname=explode(",",$it618_paotui['paotui_topname']);

$ptsale1=it618_paotui_getrewrite('paotui_wap','ptsale@1','plugin.php?id=it618_paotui:wap&pagetype=ptsale&cid=1');
$ptsale2=it618_paotui_getrewrite('paotui_wap','ptsale@2','plugin.php?id=it618_paotui:wap&pagetype=ptsale&cid=2');
$ptsale3=it618_paotui_getrewrite('paotui_wap','ptsale@3','plugin.php?id=it618_paotui:wap&pagetype=ptsale&cid=3');
$ptsale4=it618_paotui_getrewrite('paotui_wap','ptsale@4','plugin.php?id=it618_paotui:wap&pagetype=ptsale&cid=4');
$ucurl=it618_paotui_getrewrite('paotui_wap','uc','plugin.php?id=it618_paotui:wap&pagetype=uc');
$scurl=it618_paotui_getrewrite('paotui_wap','sc','plugin.php?id=it618_paotui:wap&pagetype=sc');

if($_G['uid']>0){
	$rwpeimantmp=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_uid($_G['uid']);
	if($rwpeimantmp['it618_state']==2){
		$ispmlbs=1;
	}
	
	if($peimantmp=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_uid($_G['uid'])){
		$ispmlbs=1;
	}
	
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_paotui_getlang('s25').'</a></li>';
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_paotui_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_paotui_bottomnav = DB::fetch($query)) {
	$it618_title=$it618_paotui_bottomnav['it618_title'];
	
	if($it618_paotui_bottomnav['it618_color']!=''){
		$it618_title='<font color="'.$it618_paotui_bottomnav['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$it618_url=$it618_paotui_bottomnav['it618_url'];
	
	$tmpurl=it618_paotui_getrewrite('paotui_wap','','plugin.php?id=it618_paotui:wap');
	$it618_url=str_replace("{homeurl}",$tmpurl,$it618_url);
	
	$tmpurl=it618_paotui_getrewrite('paotui_wap','ptsale@1','plugin.php?id=it618_paotui:wap&pagetype=ptsale&cid=1');
	$it618_url=str_replace("{saleurl}",$tmpurl,$it618_url);
	
	$tmpurl=it618_paotui_getrewrite('paotui_wap','rw','plugin.php?id=it618_paotui:wap&pagetype=rw');
	$it618_url=str_replace("{rwurl}",$tmpurl,$it618_url);
	
	if($it618_paotui_bottomnav['id']==5)$it618_url=it618_paotui_getrewrite('paotui_wap','u','plugin.php?id=it618_paotui:wap&pagetype=u');
	
	if($it618_paotui_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_paotui_bottomnav['it618_img'].'" height="20" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_paotui_bottomnav['it618_img'].'" height="20" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;

$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$wap=1;

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')==false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_paotui['paotui_appid']);
	$wx_secret=trim($it618_paotui['paotui_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){

	$wxshare_title=$it618_paotui['paotui_name'];
	if($it618_paotui['paotui_wxlogo']!=''){
		$wxshare_imgUrl=$it618_paotui['paotui_wxlogo'];
	}
	$tmparr=explode('://',$wxshare_imgUrl);
	if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
	$wxshare_desc=$it618_paotui['seodescription'];
	$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
		
		$wxshare_link=$signPackage["url"];
	}
}

$getmapapi=getcookie('getmapapi');

$it618_clienid=getcookie('it618_clienid');
if($it618_clienid==''){
	$it618_clienid=md5(time());
	dsetcookie('it618_clienid',$it618_clienid,3600*24*365);
}

require DISCUZ_ROOT.'./source/plugin/it618_paotui/wap/'.$pagetype.'.inc.php';
?>