<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_paotui = $_G['cache']['plugin']['it618_paotui'];
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

$uid = $_G['uid'];
if($uid<=0){
	echo '1';return;
}else{
	$paotui_rwpmgroup=(array)unserialize($it618_paotui['paotui_rwpmgroup']);
	if(!in_array($_G['groupid'], $paotui_rwpmgroup)){
		echo '2';return;
	}
	
	$ispost=1;
	$username=C::t('#it618_paotui#it618_paotui_sale')->fetch_username_by_uid($_G['uid']);
	if(C::t('#it618_paotui#it618_paotui_rwpeiman')->count_by_it618_uid($_G['uid'])>0){
		$t=it618_paotui_getlang('s1826');
		$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_uid($_G['uid']);
		$it618_state=$it618_paotui_rwpeiman['it618_state'];
		if($it618_state==0){
			$statestr=it618_paotui_getlang('s1827');
			$ispost=0;
		}elseif($it618_state==1){
			$statestr=it618_paotui_getlang('s1828');
		}
		$tip="$username ".it618_paotui_getlang('s1829')." ".date('Y-m-d H:i:s', $it618_paotui_rwpeiman['it618_rztime'])." ".it618_paotui_getlang('s1830')."<font color=red>".$statestr."</font>";
		if($it618_state==2){
			$t=it618_paotui_getlang('s1831');
			$tip="$username ".it618_paotui_getlang('s1832');
			if($it618_paotui_rwpeiman['it618_clockstate']==1)$tip.=' <font color=red>'.$it618_paotui_lang['s319'].'</font>';
			$ispost=0;
		}
		
	}else{
		$t=it618_paotui_getlang('s1834');
		$tip="$username ".it618_paotui_getlang('s1835');
	}
	
	$sqpmabout=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('sqpmabout');
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_paotui:showsqpeiman');
?>