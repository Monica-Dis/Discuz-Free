<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_paotui = $_G['cache']['plugin']['it618_paotui'];
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

$saleid=intval($_GET['saleid']);

if(!($it618_paotui_sale = C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($saleid))){
	echo 'alertit618_split'.it618_paotui_getlang('s1110');exit;
}

$it618_name2=$it618_paotui_sale['it618_name2'];
if($it618_paotui_sale['it618_name2']==''){
	$it618_name2=$it618_paotui_lang['t50'];
}

if($it618_paotui_sale['it618_state']==1){
	$it618_state='<font color=red>'.$it618_paotui_lang['s1190'].'</font>';
}

if($it618_paotui_sale['it618_state']==2){
	$it618_state='<font color=red>'.$it618_paotui_lang['s1191'].'</font>';
}

if($it618_paotui_sale['it618_state']==3){
	$it618_state='<font color=blue>'.$it618_paotui_lang['s1192'].'</font>';
}

if($it618_paotui_sale['it618_state']==31){
	$it618_state='<font color=#F60>'.$it618_paotui_lang['s309'].'</font>';
}

if($it618_paotui_sale['it618_state']==4){
	$it618_state='<font color=green>'.$it618_paotui_lang['s1193'].'</font>';
}

if($it618_paotui_sale['it618_state']==5){
	$it618_state='<font color=purple>'.$it618_paotui_lang['s1194'].'</font>';
}

if($it618_paotui_sale['it618_state']==6){
	$it618_state='<font color=purple>'.$it618_paotui_lang['s1195'].'</font>';
}

if($it618_paotui_sale['it618_state']==7){
	$it618_state='<font color=#FF00FF>'.$it618_paotui_lang['s1196'].'</font>';
}

$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];

if($it618_paotui_sale['it618_pmid']!='0'){
	$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_sale['it618_pmid']);
	if($_GET['wap']==1){
		$peiman=$it618_paotui_sale['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'].' <a href="tel://'.$it618_paotui_peiman['it618_tel'].'">'.$it618_paotui_peiman['it618_tel'].'</a>'.' '.$it618_paotui_sale['it618_content_pm'];
	}else{
		$peiman=$it618_paotui_sale['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'].' '.$it618_paotui_peiman['it618_tel'].' '.$it618_paotui_sale['it618_content_pm'];
	}
}

if($it618_paotui_sale['it618_rwpmid']>0){
	$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($it618_paotui_sale['it618_rwpmid']);
	if($_GET['wap']==1){
		$peiman=$it618_paotui_sale['it618_rwpmid'].'-'.it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']).'-'.$it618_paotui_rwpeiman['it618_name'].' <a href="tel://'.$it618_paotui_rwpeiman['it618_tel'].'">'.$it618_paotui_rwpeiman['it618_tel'].'</a>';
	}else{
		$peiman=$it618_paotui_sale['it618_rwpmid'].'-'.it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']).'-'.$it618_paotui_rwpeiman['it618_name'].' '.$it618_paotui_rwpeiman['it618_tel'];
	}
}

if($it618_paotui_sale['it618_sfmoney']>0){
	$paotui_tuikuan=$it618_paotui['paotui_tuikuan'];
	if($paotui_tuikuan==1){
		$tuikuanstr='<input type="hidden" name="it618_tuihuotype" value="1">';
	}
	if($paotui_tuikuan==2){
		$tuikuanstr='<input type="hidden" name="it618_tuihuotype" value="2">';
	}
}else{
	$tuikuanstr='<input type="hidden" name="it618_tuihuotype" value="3">';
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_paotui:saletui');
?>