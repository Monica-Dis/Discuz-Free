<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

$uid = $_G['uid'];

if($_GET['ac']=="home_shop"){
	
	$lbslat=$_GET['lbslat'];
	$lbslng=$_GET['lbslng'];
	
	if($_GET['ac1']=='hot'){
		$tmpidsarr=explode(',',$it618_paotui['paotui_homehot']);
		
		$it618_homeshops = array();
		for($i=1;$i<=count($tmpidsarr);$i++){
			$id=intval($tmpidsarr[$i-1]);
			$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($id);
			if($it618_paotui_shop['it618_htstate']==1){
				$it618_paotui_shop['it618_shopid']=$id;
				$it618_homeshops[] = $it618_paotui_shop;
			}
		}
	}

	if($_GET['ac1']=='lbs'){
		$it618_homeshops = DB::fetch_all("SELECT id as it618_shopid FROM ".DB::table('it618_paotui_shop')." where it618_htstate=1 and it618_lbslat>0 ORDER BY SQRT(($lbslng -it618_lbslng)*($lbslng -it618_lbslng)+($lbslat -it618_lbslat)*($lbslat -it618_lbslat)) limit 0,".$it618_paotui['paotui_lbscount']);
	}
	

	$home_shoptmp='';
	foreach($it618_homeshops as $it618_homeshop) {
		
		$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_homeshop['it618_shopid']);
		
		$lbsm='';
		if($lbslat>0&&$it618_paotui_shop['it618_lbslat']>0){
			$lbsm=it618_paotui_getdistance($lbslng,$lbslat,$it618_paotui_shop['it618_lbslng'],$it618_paotui_shop['it618_lbslat']);
			if($lbsm<1000)$lbsm=intval($lbsm).'m';
			if($lbsm>=1000)$lbsm=round($lbsm/1000,1).'km';
		}
			
		if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
		
		$username=C::t('#it618_paotui#it618_paotui_sale')->fetch_username_by_uid($it618_paotui_shop['it618_uid']);
		
		$tmpurl=it618_paotui_getrewrite('paotui_wap','ptsale@1@'.$it618_paotui_shop['id'],'plugin.php?id=it618_paotui:wap&pagetype=ptsale&cid=1&page='.$it618_paotui_shop['id']);
					
		$home_shoptmp.='<tr>
						  <td>
							  <img class="tdimg" src="'.it618_paotui_getwapppic($it618_paotui_shop['id'],$it618_paotui_shop['it618_logo']).'"/>
							  <div class="tdname1">'.$it618_paotui_shop['it618_name'].' '.$ShopPowerIco.'</div>
							  <div class="tdabout"><span style="float:right">'.$lbsm.'</span>'.$username.'</div>
							  <div class="tdabout">'.it618_paotui_getlang('s169').':'.$it618_paotui_shop['it618_addr'].'</div>
							  <div class="tddes1" onclick="location.href=\''.$tmpurl.'\'" style="font-size:12px; color:#f60; padding-top:6px">'.it618_paotui_getlang('s170').'</div>
						  </td>
						</tr>';
	}
	
	echo $home_shoptmp;
	exit;
}

if($_GET['ac']=="getsaleaudio"){
	if($it618_paotui_saleaudio=C::t('#it618_paotui#it618_paotui_saleaudio')->fetch_by_it618_typeid_clienid($_GET['typeid'],$_GET['clienid'])){

		if(isset($_GET['update']))$isupdate=1;
		
		if($it618_paotui_saleaudio['it618_state']==1){
			$isupdate=1;
			echo 'it618_splitok';
		}
		
		if($isupdate==1){
			C::t('#it618_paotui#it618_paotui_saleaudio')->update($it618_paotui_saleaudio['id'],array(
				'it618_state' => 0
			));
		}
	}else{
		C::t('#it618_paotui#it618_paotui_saleaudio')->insert(array(
			'it618_typeid' => $_GET['typeid'],
			'it618_clienid' => $_GET['clienid'],
			'it618_state' => 0
		), true);
	}
	
	exit;
}

if($_GET['formhash']!=FORMHASH)exit;

if($_GET['ac']=="getmapapi"){
	dsetcookie('getmapapi',$_GET['lbslat'].'it618_split'.$_GET['lbslng'].'it618_split'.it618_paotui_utftogbk($_GET['lbsaddr']),60*$it618_paotui['paotui_lbstime']);
}

if($_GET['ac']=="payok"){
	if($_GET['ac1']=="pay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_paotui_sale')." WHERE it618_state!=0 and id=".intval($_GET['saleid']));
	}
	if($salecount>0){
		echo 'it618_splitok';exit;
	}
}

if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo it618_paotui_getlang('s484');exit;
	}else{
		it618_paotui_delsalework();
		set_time_limit (0);
		ignore_user_abort(true);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_paotui_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_paotui_delsalework();
			}
		}
		C::t('#it618_paotui#it618_paotui_salework')->insert(array(
			'it618_iswork' => 1
		), true);

		if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
		
		$yytimestr=it618_paotui_getyytime();
		$yytimestrarr=explode("it618_split",$yytimestr);
		
		$cid=$_GET['it618_cid'];
		if($yytimestrarr[0]==0&&$cid<4){
			echo $it618_paotui_lang['s95'].$yytimestrarr[1];it618_paotui_delsalework();exit;
		}
		
		$tmptime=$_G['timestamp'];
		
		if($cid==1||$cid==2){
			$islbs=$_GET['it618_islbs'];
			$lbslat1=$_GET['it618_lbslat1'];
			$lbslng1=$_GET['it618_lbslng1'];
			$lbslat2=$_GET['it618_lbslat2'];
			$lbslng2=$_GET['it618_lbslng2'];
			
			$yunfeiarr=explode("it618_split",it618_paotui_getyunfei());
			$yunfei_first=$yunfeiarr[0];
			$yunfei_yunfei1=$yunfeiarr[1];
			$yunfei_yunfei2=$yunfeiarr[2];
			
			if(($cid==1&&$islbs!=1)||$cid==2){
				if($lbslat1==0||$lbslng1==0){
					echo $it618_paotui_lang['t10'];it618_paotui_delsalework();exit;
				}
				
				if($lbslat2==0||$lbslng2==0){
					if($cid==1)echo $it618_paotui_lang['t11'];it618_paotui_delsalework();exit;
					if($cid==2)echo $it618_paotui_lang['t12'];it618_paotui_delsalework();exit;
				}
				
				$lbsdata=it618_paotui_getdistance_gd($lbslng1,$lbslat1,$lbslng2,$lbslat2);
	
				if($lbsdata['info']=='OK'){
					if($lbsdata['results'][0]['distance']>0){
						$lbsm=$lbsdata['results'][0]['distance'];
						
						$lbsmtmp=round($lbsm/1000,1);
						if($lbsmtmp<=$yunfei_first){
							$yunfei=$yunfei_yunfei1;
						}else{
							$tmpm=$lbsmtmp-$yunfei_first;
							$tmpm1=intval($tmpm);
							if($tmpm1<$tmpm)$tmpm1=$tmpm1+1;
							$yunfei=$yunfei_yunfei1+$tmpm1*$yunfei_yunfei2;
						}
					}else{
						$tmparr=explode("|",$it618_paotui_lang['s82']);
						echo it618_paotui_utftogbk($lbsdata['results'][0]['info']).' '.it618_paotui_utftogbk($tmparr[$lbsdata['results'][0]['code']]);it618_paotui_delsalework();exit;
					}
				}else{
					echo $it618_paotui_lang['s1234'].it618_paotui_utftogbk($lbsdata['info']);it618_paotui_delsalework();exit;
				}
			}
			
			if($cid==1&&$islbs==1){
				$yunfei=$yunfei_yunfei1;
				$lbslat2=0;
				$lbslng2=0;
			}
			
			$chkscore=intval($_GET['chkscore']);
			$xiaofei=floatval($_GET['xiaofei']);
			
			if($chkscore==1){
				$paotui_jfbl=$it618_paotui['paotui_jfbl'];
				
				$it618_scorebl=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('scorebl');
				
				$creditnum=C::t('#it618_paotui#it618_paotui_sale')->fetch_extcredits_by_uid($it618_paotui['paotui_credit'],$uid);
				
				$scoremoney1=round((($xiaofei+$yunfei)*$it618_scorebl/100),2);
				$creditnum1=$scoremoney1*$paotui_jfbl;
				if($creditnum1>$creditnum){
					$scoremoney=round(($creditnum/$paotui_jfbl),2);
					$it618_score=$creditnum;
				}else{
					$scoremoney=$scoremoney1;
					$it618_score=intval($creditnum1);
				}
			}else{
				$scoremoney=0;
			}
			
			$sfmoney=$xiaofei+$yunfei-$scoremoney;
			
			if($sfmoney<=0){
				$ispayok=1;
			}else{
				$ispayok=0;
				if($_GET['paytype']==""){
					echo it618_paotui_getlang('s81');it618_paotui_delsalework();exit;
				}
				
				if($_GET['paytype']=="wxpay"){
					if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
						require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
					}
					if($wx_appid==""){
						echo it618_paotui_getlang('s80');it618_paotui_delsalework();exit;
					}
				}
			}
		}
		
		if($cid==4){
			if($shoptmp=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_uid($uid)){
				if($shoptmp['it618_hzshopid']==''){
					echo it618_paotui_getlang('s179');it618_paotui_delsalework();exit;
				}
				if($shoptmp['it618_htstate']==0){
					echo it618_paotui_getlang('s180');it618_paotui_delsalework();exit;
				}
				if($shoptmp['it618_htstate']==2){
					echo it618_paotui_getlang('s181');it618_paotui_delsalework();exit;
				}
				
				$it618_shopid=$shoptmp['id'];
			}else{
				echo it618_paotui_getlang('s182');it618_paotui_delsalework();exit;
			}
		}

		if($cid<=3){
			$it618_isrwpmpower=0;
			if($it618_paotui['paotui_pmmode']==2){
				$it618_isrwpmpower=1;
			}
			
			$id = C::t('#it618_paotui#it618_paotui_sale')->insert(array(
				'it618_uid' => $uid,
				'it618_type' => $cid,
				'it618_yunfei' => $yunfei,
				'it618_xiaofei' => $xiaofei,
				'it618_score' => $it618_score,
				'it618_scoremoney' => $scoremoney,
				'it618_sfmoney' => $sfmoney,
				'it618_lbslat1' => $lbslat1,
				'it618_lbslng1' => $lbslng1,
				'it618_lbslat2' => $lbslat2,
				'it618_lbslng2' => $lbslng2,
				'it618_lbsaddr1' => it618_paotui_utftogbk($_GET['it618_lbsaddr1']),
				'it618_addr1' => it618_paotui_utftogbk($_GET['it618_addr1']),
				'it618_name1' => it618_paotui_utftogbk($_GET['it618_name1']),
				'it618_tel1' => it618_paotui_utftogbk($_GET['it618_tel1']),
				'it618_lbsaddr2' => it618_paotui_utftogbk($_GET['it618_lbsaddr2']),
				'it618_addr2' => it618_paotui_utftogbk($_GET['it618_addr2']),
				'it618_name2' => it618_paotui_utftogbk($_GET['it618_name2']),
				'it618_tel2' => it618_paotui_utftogbk($_GET['it618_tel2']),
				'it618_time2' => it618_paotui_utftogbk($_GET['it618_time2']),
				'it618_bz' => it618_paotui_utftogbk($_GET['it618_bz']),
				'it618_pmid' => '0',
				'it618_isrwpmpower' => $it618_isrwpmpower,
				'it618_state' => 0,
				'it618_time' => $tmptime
			), true);
		}else{
			$id = C::t('#it618_paotui#it618_paotui_salehz')->insert(array(
				'it618_uid' => $uid,
				'it618_shopid' => $it618_shopid,
				'it618_tel' => it618_paotui_utftogbk($_GET['it618_tel']),
				'it618_addr' => it618_paotui_utftogbk($_GET['it618_addr']),
				'it618_yunfei' => $_GET['it618_yunfei'],
				'it618_bz' => it618_paotui_utftogbk($_GET['it618_bz']),
				'it618_pmid' => '0',
				'it618_state' => 0,
				'it618_time' => $tmptime
			), true);
		}
		
		if($id>0){
			if($cid==3){
				C::t('#it618_paotui#it618_paotui_sale')->update($id,array(
					'it618_state' => 1
				));
				
				it618_paotui_delsalework();

				it618_paotui_sendmessage('sale1_user',$id);
				it618_paotui_sendmessage('sale1_admin',$id);
				
				DB::query("update ".DB::table('it618_paotui_saleaudio')." set it618_state=1 WHERE it618_typeid=0");
				
				echo "it618_splitcidokit618_split".$it618_paotui_lang['s77'];exit;
			}
			
			if($cid==4){
				C::t('#it618_paotui#it618_paotui_salehz')->update($id,array(
					'it618_state' => 1
				));
				
				it618_paotui_delsalework();

				it618_paotui_sendmessage('salehz_user',$id);
				it618_paotui_sendmessage('salehz_admin',$id);
				
				DB::query("update ".DB::table('it618_paotui_saleaudio')." set it618_state=1 WHERE it618_typeid=1");
				
				echo "it618_splitcidokit618_split".$it618_paotui_lang['s77'];exit;
			}
			
			if($ispayok==1){
				
				C::t('#it618_paotui#it618_paotui_sale')->update($id,array(
					'it618_state' => 1
				));
				
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$it618_paotui['paotui_credit'] => (0-$it618_score))
				);
				
				it618_paotui_delsalework();

				it618_paotui_sendmessage('sale_user',$id);
				it618_paotui_sendmessage('sale_admin',$id);
				
				DB::query("update ".DB::table('it618_paotui_saleaudio')." set it618_state=1 WHERE it618_typeid=0");
				
				echo "it618_splitscoreokit618_split".$it618_paotui_lang['s78'];exit;
			}
			
			$saletype='0401';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
			$body=str_replace("{saleid}",$saleid,$it618_paotui_lang['s79']);
			$body=str_replace("{type}",$paotui_topname[$cid-1],$body);
			
			$total_fee=$sfmoney;
			
			if(paotui_is_mobile()){ 
				$wap=1;
			}else{
				$wap=0;
			}
			
			$url=$_G['siteurl'].it618_paotui_getrewrite('paotui_wap','uc@'.$_G['uid'],'plugin.php?id=it618_paotui:wap&pagetype=uc');
			
			if($it618_paotui['paotui_wxgzurl']!=""){
				$it618_members = $_G['cache']['plugin']['it618_members'];
				$appid=trim($it618_members['members_appid']);
				$appsecret=trim($it618_members['members_appsecret']);
	
				if($appid!=""){
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
		
					$openid=C::t('#it618_members#it618_members_wxuser')->fetch_openid_by_uid($uid);
					
					$wxsubscribe=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
				
					$tmparr=explode("@",$wxsubscribe);
					$wxok=$tmparr[0];
				}
				
				if($wxok!=1){
					$url=$it618_paotui['paotui_wxgzurl'];
				}
			}

			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];
	
			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => $total_fee,
				'it618_plugin' => 'it618_paotui',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
		
			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_paotui_delsalework();
		}else{
			echo it618_paotui_getlang('s490');it618_paotui_delsalework();exit;
		}
	}
	exit;
}

if($_GET['ac']=="mysalelist_get"){
	
	$ppp = 10;
	$funname='getsalelist';
	
	$it618sql = "it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==31)$it618sql = "it618_state = 31";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
	}

	$count = C::t('#it618_paotui#it618_paotui_sale')->count_by_search($it618sql,'',$uid,'',$_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_paotui#it618_paotui_sale')->fetch_all_by_search($it618sql,'id desc',$uid,'',$_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_paotui_sale) {
	
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		if($it618_paotui_sale['it618_state']==1){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1190'].'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==2){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1191'].'</font>';
		}
		
		$it618_lbs='';
		if($it618_paotui_sale['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_paotui_lang['s1192'].'</font>';
			$it618_state.='<a href="javascript:" style="float:right;margin-left:6px" onclick="sale_shouhuo('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1207'].'</a>';
			
			$it618_lbs=' <a href="javascript:" onclick="showsalelbs('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s370'].'</a>';
		}
		
		if($it618_paotui_sale['it618_state']==31){
			$it618_state='<font color=#F60>'.$it618_paotui_lang['s309'].'</font>';
			$it618_state.='<a href="javascript:" style="float:right;margin-left:6px" onclick="sale_shouhuo('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1207'].'</a>';
		}
		
		if($it618_paotui_sale['it618_state']==4){
			$it618_state='<font color=green>'.$it618_paotui_lang['s1193'].'</font>';
			if($it618_paotui_sale['it618_pj']>0){
				if($it618_paotui_sale['it618_pj']==1)$it618_pj=$it618_paotui_lang['s362'];
				if($it618_paotui_sale['it618_pj']==2)$it618_pj=$it618_paotui_lang['s363'];
				if($it618_paotui_sale['it618_pj']==3)$it618_pj=$it618_paotui_lang['s364'];
				
				$it618_state.='<span style="float:right;color:red">'.$it618_pj.'</span>';
			}else{
				$it618_state.='<a href="javascript:" style="float:right;" onclick="sale_pj('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s355'].'</a>';
			}
		}
		
		if($it618_paotui_sale['it618_state']==5){
			$it618_state='<font color=purple>'.$it618_paotui_lang['s1194'].'</font>';
			
			if($it618_paotui_sale['it618_state_tuihuo']==1)$it618_statetmp=$it618_paotui_lang['s1190'];
			if($it618_paotui_sale['it618_state_tuihuo']==2)$it618_statetmp=$it618_paotui_lang['s1191'];
			if($it618_paotui_sale['it618_state_tuihuo']==3)$it618_statetmp=$it618_paotui_lang['s1192'];
			$it618_state.=' <font color=#999>'.$it618_paotui_lang['s1171'].$it618_statetmp.'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==6){
			$it618_state='<font color=purple>'.$it618_paotui_lang['s1195'].'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==7){
			$it618_state='<font color=#FF00FF>'.$it618_paotui_lang['s1196'].'</font>';
		}
		
		if($it618_paotui_sale['it618_type']<=2&&$it618_paotui_sale['it618_state']<=3){
			$it618_state.=' <a href="javascript:" style="float:right;" onclick="sale_tuihuo('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1204'].'</a>';
		}
		
		$peiman='';
		if($it618_paotui_sale['it618_pmid']!='0'){
			$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_sale['it618_pmid']);
			$peiman=' '.$it618_paotui_sale['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'];
		}
		if($it618_paotui_sale['it618_rwpmid']>0){
			$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($it618_paotui_sale['it618_rwpmid']);
			$peiman=' '.$it618_paotui_sale['it618_rwpmid'].'-'.it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']).'-'.$it618_paotui_rwpeiman['it618_name'];
		}
		
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/ajax.inc.php';
			$result=unlink($ajaxpath);
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/lang.func.php';
			$result=unlink($ajaxpath);
		}
		
		$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
		$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
		
		$mysalelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
					<div class="dealcard" style="margin:0;padding:0;line-height:15px">
						<div class="dealcard-paotui single-line"><a href="javascript:" style="float:right" onclick="showsale('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1125'].'</a><font color=#999>'.$it618_paotui_lang['s1124'].':</font>'.$it618_paotui_sale['id'].' <font color=#999>'.$it618_paotui_lang['s1127'].':</font>'.$it618_paotui_sale['it618_yunfei'].'</div>
						
						<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px"><font color=#999>'.$it618_paotui_lang['s1128'].':</font>'.$it618_paotui_sale['it618_xiaofei'].' <font color=#999>'.$it618_paotui_lang['s1129'].':</font>'.$it618_paotui_sale['it618_scoremoney'].' <font color=#999>'.$it618_paotui_lang['s1130'].':</font>'.$it618_paotui_sale['it618_score'].'<br>'.$it618_type.':<font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_sale['it618_time']).'</font><br>'.$it618_state.' '.$peiman.$it618_lbs.'</div>
					</div>
				</dd>';
		
		$n=$n+1;
	}

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_paotui_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$yunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei',$it618sql,'',$uid,'',$_GET['it618_time1'], $_GET['it618_time2']);
	$xiaofei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_xiaofei',$it618sql,'',$uid,'',$_GET['it618_time1'], $_GET['it618_time2']);
	$scoremoney=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_scoremoney',$it618sql,'',$uid,'',$_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_score',$it618sql,'',$uid,'',$_GET['it618_time1'], $_GET['it618_time2']);
	
	$salesum= it618_paotui_getlang('s1136').''."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font> ".$it618_paotui_lang['s1144']."<font color=red>$xiaofei</font><br>".$it618_paotui_lang['s1145']."<font color=#390>$scoremoney</font> ".$it618_paotui_lang['s1146']."<font color=#390>$score</font><br><font color=#999 style='font-size:11px'>".$it618_paotui_lang['s1141'].' <font color=red>'.$it618_paotui['paotui_autodatecount'].'</font> '.$it618_paotui_lang['s1142'].'</font>';
	
	echo $salesum."it618_split".$mysalelist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="rwlist_get"){
	
	$rwpeimantmp=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_uid($uid);
	if($rwpeimantmp['it618_state']!=2){
		echo 'it618_split<div style="padding:10px;color:red">'.it618_paotui_getlang('s330').'</div>';exit;
	}
	
	$ppp = 10;
	$funname='getsalelist';
	
	$it618sql = "it618_state=1 and it618_isrwpmpower=1";

	$count = C::t('#it618_paotui#it618_paotui_sale')->count_by_search($it618sql,'',0,'',$_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_paotui#it618_paotui_sale')->fetch_all_by_search($it618sql,'id desc',0,'',$_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_paotui_sale) {
	
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
		$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
		
		if($it618_paotui_sale['it618_type']==1){
			if($it618_paotui_sale['it618_lbslat2']==0){
				$it618_type='<font color=#999>'.$it618_paotui_lang['s324'].':</font>'.$it618_paotui_sale['it618_name2'].' <font color=red>'.$it618_paotui_lang['s325'].'</font>';
			}else{
				$it618_type='<font color=#999>'.$it618_paotui_lang['s324'].':</font>'.$it618_paotui_sale['it618_name2'].' '.$it618_paotui_sale['it618_lbsaddr2'].' '.$it618_paotui_sale['it618_addr2'];
			}
			$it618_type.='<br><font color=#999>'.$it618_paotui_lang['s326'].':</font>'.$it618_paotui_sale['it618_name1'].' '.$it618_paotui_sale['it618_lbsaddr1'].' '.$it618_paotui_sale['it618_addr1'];
		}else{
			$it618_type='<font color=#999>'.$it618_paotui_lang['s327'].':</font>'.$it618_paotui_sale['it618_name2'].' '.$it618_paotui_sale['it618_lbsaddr2'].' '.$it618_paotui_sale['it618_addr2'];
			$it618_type.='<br><font color=#999>'.$it618_paotui_lang['s328'].':</font>'.$it618_paotui_sale['it618_name1'].' '.$it618_paotui_sale['it618_lbsaddr1'].' '.$it618_paotui_sale['it618_addr1'];
		}
		
		$mysalelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
					<div class="dealcard" style="margin:0;padding:0;line-height:15px">
						<div class="dealcard-paotui single-line"><font color=#999>'.$it618_paotui_lang['s1124'].':</font>'.$it618_paotui_sale['id'].' <font color=#999>'.$it618_paotui_lang['s1127'].':</font>'.$it618_paotui_sale['it618_yunfei'].'<span style="float:right">'.$paotui_topname[$it618_paotui_sale['it618_type']-1].'</span></div>
						
						<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px"><font color=#999>'.$it618_paotui_lang['s332'].':</font>'.$it618_paotui_sale['it618_bz'].'<br>'.$it618_type.'<br><font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_sale['it618_time']).'</font><a href="javascript:" style="float:right" onclick="sale_getrw('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s331'].'</a></div>
					</div>
				</dd>';
		
		$n=$n+1;
	}

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_paotui_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$yunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei',$it618sql,'',0,'',$_GET['it618_time1'], $_GET['it618_time2']);
	
	$salesum= it618_paotui_getlang('s1136').''."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font><br><font color=#999 style='font-size:11px'>".$it618_paotui_lang['s1141'].' <font color=red>'.$it618_paotui['paotui_autodatecount'].'</font> '.$it618_paotui_lang['s1142'].'</font>';
	
	echo $salesum."it618_split".$mysalelist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="rwpmsalelist_get"){
	
	$rwpeimantmp=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_uid($uid);
	if($rwpeimantmp['it618_state']!=2){
		echo 'it618_split'.it618_paotui_getlang('s330');exit;
	}
	
	$ppp = 10;
	$funname='getsalelist';
	
	$it618sql = "it618_rwpmid =".$rwpeimantmp['id']." and it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==31)$it618sql = "it618_state = 31";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
	}

	$count = C::t('#it618_paotui#it618_paotui_sale')->count_by_search($it618sql,'',0,'',$_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_paotui#it618_paotui_sale')->fetch_all_by_search($it618sql,'id desc',0,'',$_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_paotui_sale) {
	
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		if($it618_paotui_sale['it618_state']==1){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1190'].'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==2){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1191'].'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_paotui_lang['s1192'].'</font>';
			$it618_state.='<a href="javascript:" style="float:right;" onclick="sale_getok('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s308'].'</a>';
		}
		
		if($it618_paotui_sale['it618_state']==31){
			$it618_state='<font color=#F60>'.$it618_paotui_lang['s309'].'</font> <font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_sale['it618_pmoktime']).'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==4){
			$it618_state='<font color=green>'.$it618_paotui_lang['s1193'].'</font>';
			
			if($it618_paotui_sale['it618_pj']>0){
				if($it618_paotui_sale['it618_pj']==1)$it618_pj=$it618_paotui_lang['s362'];
				if($it618_paotui_sale['it618_pj']==2)$it618_pj=$it618_paotui_lang['s363'];
				if($it618_paotui_sale['it618_pj']==3)$it618_pj=$it618_paotui_lang['s364'];
			}
			
			$money=$it618_paotui_sale['it618_yunfei']+$it618_paotui_sale['it618_xiaofei'];
			$tcmoney=round(($money*$it618_paotui_sale['it618_rwtcbl']/100),2);
			
			$it618_state.=' <font color=#999>'.$it618_paotui_lang['s383'].':</font>'.$tcmoney.'<span style="float:right;color:red">'.$it618_pj.'</span>';
		}
		
		if($it618_paotui_sale['it618_state']==5){
			$it618_state='<font color=purple>'.$it618_paotui_lang['s1194'].'</font>';
			
			if($it618_paotui_sale['it618_state_tuihuo']==1)$it618_statetmp=$it618_paotui_lang['s1190'];
			if($it618_paotui_sale['it618_state_tuihuo']==2)$it618_statetmp=$it618_paotui_lang['s1191'];
			if($it618_paotui_sale['it618_state_tuihuo']==3)$it618_statetmp=$it618_paotui_lang['s1192'];
			$it618_state.=' <font color=#999>'.$it618_paotui_lang['s1171'].$it618_statetmp.'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==6){
			$it618_state='<font color=purple>'.$it618_paotui_lang['s1195'].'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==7){
			$it618_state='<font color=#FF00FF>'.$it618_paotui_lang['s1196'].'</font>';
		}
		
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/ajax.inc.php';
			$result=unlink($ajaxpath);
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/lang.func.php';
			$result=unlink($ajaxpath);
		}
		
		$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
		$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
		
		$mysalelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
					<div class="dealcard" style="margin:0;padding:0;line-height:15px">
						<div class="dealcard-paotui single-line"><a href="javascript:" style="float:right" onclick="showsale('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1125'].'</a><font color=#999>'.$it618_paotui_lang['s1124'].':</font>'.$it618_paotui_sale['id'].' <font color=#999>'.$it618_paotui_lang['s1127'].':</font>'.$it618_paotui_sale['it618_yunfei'].'</div>
						
						<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px"><font color=#999>'.$it618_paotui_lang['s1128'].':</font>'.$it618_paotui_sale['it618_xiaofei'].' <font color=#999>'.$it618_paotui_lang['s1129'].':</font>'.$it618_paotui_sale['it618_scoremoney'].' <font color=#999>'.$it618_paotui_lang['s1130'].':</font>'.$it618_paotui_sale['it618_score'].'<br>'.$it618_type.':<font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_sale['it618_time']).'</font><br>'.$it618_state.'</div>
					</div>
				</dd>';
		
		$n=$n+1;
	}

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_paotui_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$yunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei',$it618sql,'',0,'',$_GET['it618_time1'], $_GET['it618_time2']);
	
	$salesum= it618_paotui_getlang('s1136').''."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font><br><font color=#999 style='font-size:11px'>".$it618_paotui_lang['s1141'].' <font color=red>'.$it618_paotui['paotui_autodatecount'].'</font> '.$it618_paotui_lang['s1142'].'</font>';
	
	echo $salesum."it618_split".$mysalelist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="pmsalelist_get"){
	
	if(!$peimantmp=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_uid($uid)){
		echo 'it618_split'.it618_paotui_getlang('s210');exit;
	}
	
	$ppp = 10;
	$funname='getsalelist';
	
	$it618sql = "it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==31)$it618sql = "it618_state = 31";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
	}

	$count = C::t('#it618_paotui#it618_paotui_sale')->count_by_search($it618sql,'',0,$peimantmp['it618_pmid'],$_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_paotui#it618_paotui_sale')->fetch_all_by_search($it618sql,'id desc',0,$peimantmp['it618_pmid'],$_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_paotui_sale) {
	
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		if($it618_paotui_sale['it618_state']==1){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1190'].'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==2){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1191'].'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_paotui_lang['s1192'].'</font>';
			$it618_state.='<a href="javascript:" style="float:right;" onclick="sale_getok('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s308'].'</a>';
		}
		
		if($it618_paotui_sale['it618_state']==31){
			$it618_state='<font color=#F60>'.$it618_paotui_lang['s309'].'</font> <font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_sale['it618_pmoktime']).'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==4){
			$it618_state='<font color=green>'.$it618_paotui_lang['s1193'].'</font>';
			
			if($it618_paotui_sale['it618_pj']>0){
				if($it618_paotui_sale['it618_pj']==1)$it618_pj=$it618_paotui_lang['s362'];
				if($it618_paotui_sale['it618_pj']==2)$it618_pj=$it618_paotui_lang['s363'];
				if($it618_paotui_sale['it618_pj']==3)$it618_pj=$it618_paotui_lang['s364'];
				
				$it618_state.='<span style="float:right;color:red">'.$it618_pj.'</span>';
			}
		}
		
		if($it618_paotui_sale['it618_state']==5){
			$it618_state='<font color=purple>'.$it618_paotui_lang['s1194'].'</font>';
			
			if($it618_paotui_sale['it618_state_tuihuo']==1)$it618_statetmp=$it618_paotui_lang['s1190'];
			if($it618_paotui_sale['it618_state_tuihuo']==2)$it618_statetmp=$it618_paotui_lang['s1191'];
			if($it618_paotui_sale['it618_state_tuihuo']==3)$it618_statetmp=$it618_paotui_lang['s1192'];
			$it618_state.=' <font color=#999>'.$it618_paotui_lang['s1171'].$it618_statetmp.'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==6){
			$it618_state='<font color=purple>'.$it618_paotui_lang['s1195'].'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==7){
			$it618_state='<font color=#FF00FF>'.$it618_paotui_lang['s1196'].'</font>';
		}
		
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/ajax.inc.php';
			$result=unlink($ajaxpath);
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/lang.func.php';
			$result=unlink($ajaxpath);
		}
		
		$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
		$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
		
		$mysalelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
					<div class="dealcard" style="margin:0;padding:0;line-height:15px">
						<div class="dealcard-paotui single-line"><a href="javascript:" style="float:right" onclick="showsale('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1125'].'</a><font color=#999>'.$it618_paotui_lang['s1124'].':</font>'.$it618_paotui_sale['id'].' <font color=#999>'.$it618_paotui_lang['s1127'].':</font>'.$it618_paotui_sale['it618_yunfei'].'</div>
						
						<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px"><font color=#999>'.$it618_paotui_lang['s1128'].':</font>'.$it618_paotui_sale['it618_xiaofei'].' <font color=#999>'.$it618_paotui_lang['s1129'].':</font>'.$it618_paotui_sale['it618_scoremoney'].' <font color=#999>'.$it618_paotui_lang['s1130'].':</font>'.$it618_paotui_sale['it618_score'].'<br>'.$it618_type.':<font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_sale['it618_time']).'</font><br>'.$it618_state.'</div>
					</div>
				</dd>';
		
		$n=$n+1;
	}

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_paotui_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$yunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei',$it618sql,'',0,$peimantmp['it618_pmid'],$_GET['it618_time1'], $_GET['it618_time2']);
	$xiaofei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_xiaofei',$it618sql,'',0,$peimantmp['it618_pmid'],$_GET['it618_time1'], $_GET['it618_time2']);
	
	$salesum= it618_paotui_getlang('s1136').''."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font> ".$it618_paotui_lang['s1144']."<font color=red>$xiaofei</font><br><font color=#999 style='font-size:11px'>".$it618_paotui_lang['s1141'].' <font color=red>'.$it618_paotui['paotui_autodatecount'].'</font> '.$it618_paotui_lang['s1142'].'</font>';
	
	echo $salesum."it618_split".$mysalelist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="sale_getsale"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($_GET['saleid']);
		if($it618_paotui_sale['it618_state']!=1){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
			'it618_state' => 2
		));

		echo 'okit618_split'.it618_paotui_getlang('s1161');
		it618_paotui_sendmessage('salegetsale_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_getok"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($_GET['saleid']);
		if($it618_paotui_sale['it618_state']!=3){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
			'it618_state' => 31,
			'it618_pmoktime' => $_G['timestamp']
		));

		echo 'okit618_split'.it618_paotui_getlang('s374');
		it618_paotui_sendmessage('salegetok_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_pmgetok"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($_GET['saleid']);
		if($it618_paotui_sale['it618_pmid']!='0'){
			if(!$peimantmp=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_uid($uid)){
				echo 'it618_split'.it618_paotui_getlang('s375');exit;
			}
			if($it618_paotui_sale['it618_pmid']!=$peimantmp['it618_pmid']){
				echo 'it618_split'.it618_paotui_getlang('s1246');exit;
			}
		}
		
		if($it618_paotui_sale['it618_rwpmid']>0){
			if($rwpeimantmp=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_uid($uid)){
				if($rwpeimantmp['it618_state']==1){
					echo 'it618_split'.it618_paotui_getlang('s348');exit;
				}
				if($rwpeimantmp['it618_state']==2){
					if($rwpeimantmp['it618_clockstate']==1){
						echo 'it618_split'.it618_paotui_getlang('s349');exit;
					}
				}
			}else{
				echo 'it618_split'.it618_paotui_getlang('s347');exit;
			}
			
			if($it618_paotui_sale['it618_rwpmid']!=$rwpeimantmp['id']){
				echo 'it618_split'.it618_paotui_getlang('s1246');exit;
			}
		}
		
		if($it618_paotui_sale['it618_state']!=3){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
			'it618_state' => 31,
			'it618_pmoktime' => $_G['timestamp']
		));

		echo 'okit618_split'.it618_paotui_getlang('s374');
		it618_paotui_sendmessage('salegetok_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="salehz_pmgetok"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$it618_paotui_salehz=C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($_GET['saleid']);
		if($it618_paotui_salehz['it618_pmid']!=''){
			if(!$peimantmp=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_uid($uid)){
				echo 'it618_split'.it618_paotui_getlang('s375');exit;
			}
			if($it618_paotui_salehz['it618_pmid']!=$peimantmp['it618_pmid']){
				echo 'it618_split'.it618_paotui_getlang('s1246');exit;
			}
		}
		
		if($it618_paotui_salehz['it618_state']!=2){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_salehz')->update($_GET['saleid'],array(
			'it618_state' => 21,
			'it618_pmoktime' => $_G['timestamp']
		));

		echo 'okit618_split'.it618_paotui_getlang('s374');
		it618_paotui_sendmessage('salehzgetok_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="salehz_getok"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		$it618_paotui_salehz=C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($_GET['saleid']);
		if($it618_paotui_salehz['it618_state']!=2){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_salehz')->update($_GET['saleid'],array(
			'it618_state' => 21,
			'it618_pmoktime' => $_G['timestamp']
		));

		echo 'okit618_split'.it618_paotui_getlang('s374');
		it618_paotui_sendmessage('salehzgetok_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_isrwpmpower"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($_GET['saleid']);
		if($it618_paotui_sale['it618_state']!=1){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
			'it618_isrwpmpower' => 1
		));

		echo 'okit618_split'.it618_paotui_getlang('s353');
		exit;
	}
}

if($_GET['ac']=="sale_getrw"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		if($rwpeimantmp=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_uid($uid)){
			if($rwpeimantmp['it618_state']==1){
				echo 'it618_split'.it618_paotui_getlang('s348');exit;
			}
			if($rwpeimantmp['it618_state']==2){
				if($rwpeimantmp['it618_clockstate']==1){
					echo 'it618_split'.it618_paotui_getlang('s349');exit;
				}
			}
		}else{
			echo 'it618_split'.it618_paotui_getlang('s347');exit;
		}
		
		$count = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('(it618_state=3 or it618_state=31) and it618_rwpmid='.$rwpeimantmp['id']);
		$pjcount1 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_pj=1 and it618_rwpmid='.$rwpeimantmp['id']);
		$allpjcount = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_pj>0 and it618_rwpmid='.$rwpeimantmp['id']);
		if($allpjcount==0){
			$pjtmp1=0;
		}else{
			$pjtmp1=$pjcount1/$allpjcount*100;
		}
		
		if($it618_paotui_rwpmtcbl=C::t('#it618_paotui#it618_paotui_rwpmtcbl')->fetch_by_pj($pjtmp1)){
			if($count>=$it618_paotui_rwpmtcbl['it618_jdcount']){
				echo 'it618_split'.$it618_paotui_lang['s377'].$it618_paotui_rwpmtcbl['it618_jdcount'].$it618_paotui_lang['s378'];exit;
			}
		}else{
			echo 'it618_split'.it618_paotui_getlang('s379');exit;
		}
		
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($_GET['saleid']);
		if($it618_paotui_sale['it618_uid']==$uid){
			echo 'it618_split'.it618_paotui_getlang('s354');exit;
		}
		
		if($it618_paotui_sale['it618_state']!=1){
			echo 'it618_split'.it618_paotui_getlang('s350');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
			'it618_rwpmid' => $rwpeimantmp['id'],
			'it618_state' => 3,
			'it618_rwtcbl' => $it618_paotui_rwpmtcbl['it618_tcbl'],
			'it618_pmtime' => $_G['timestamp']
		));
		
		echo 'okit618_split'.it618_paotui_getlang('s351');
		it618_paotui_sendmessage('salefahuo_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_fahuo"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($_GET['saleid']);
		if(!($it618_paotui_sale['it618_state']==2||$it618_paotui_sale['it618_state']==3)){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		if($it618_paotui_sale['it618_state']==2){
			C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
				'it618_pmid' => $_GET['it618_pmid'],
				'it618_pmtime' => $_G['timestamp'],
				'it618_content_pm' => it618_paotui_utftogbk($_GET['fahuovalue']),
				'it618_state' => 3
			));
			
			echo 'okit618_split'.it618_paotui_getlang('s1167');
			it618_paotui_sendmessage('salefahuo_user',$_GET['saleid']);
			exit;
		}else{
			if($it618_paotui_sale['it618_rwpmid']>0){
				C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
					'it618_rwpmid' => 0,
					'it618_rwpmidedit' => $it618_paotui_sale['it618_rwpmid']
				));
			}
			
			C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
				'it618_pmid' => $_GET['it618_pmid'],
				'it618_pmtime' => $_G['timestamp'],
				'it618_content_pm' => it618_paotui_utftogbk($_GET['fahuovalue'])
			));
			
			echo 'okit618_split'.it618_paotui_getlang('s1167');
			it618_paotui_sendmessage('salefahuo_user',$_GET['saleid']);
			exit;
		}
	}
}

if($_GET['ac']=="salehz_fahuo"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		$it618_paotui_salehz=C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($_GET['saleid']);
		if(!($it618_paotui_salehz['it618_state']==1||$it618_paotui_salehz['it618_state']==2)){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		if($it618_paotui_salehz['it618_state']==1){
			C::t('#it618_paotui#it618_paotui_salehz')->update($_GET['saleid'],array(
				'it618_pmid' => $_GET['it618_pmid'],
				'it618_pmtime' => $_G['timestamp'],
				'it618_content_pm' => it618_paotui_utftogbk($_GET['fahuovalue']),
				'it618_state' => 2
			));
			
			echo 'okit618_split'.it618_paotui_getlang('s1167');
			it618_paotui_sendmessage('salehzfahuo_user',$_GET['saleid']);
			exit;
		}else{
			C::t('#it618_paotui#it618_paotui_salehz')->update($_GET['saleid'],array(
				'it618_pmid' => $_GET['it618_pmid'],
				'it618_pmtime' => $_G['timestamp'],
				'it618_content_pm' => it618_paotui_utftogbk($_GET['fahuovalue'])
			));
			
			echo 'okit618_split'.it618_paotui_getlang('s1167');
			it618_paotui_sendmessage('salehzfahuo_user',$_GET['saleid']);
			exit;
		}
	}
}

if($_GET['ac']=="sale_yunfei"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$it618_paotui_salehz=C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($_GET['saleid']);
		
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_salehz')->update($_GET['saleid'],array(
			'it618_yunfei' => $_GET['yunfei']
		));
		
		echo 'okit618_split'.it618_paotui_getlang('s193');
		exit;
	}
}

if($_GET['ac']=="shopsale_yunfei"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$it618_paotui_salehz=C::t('#it618_paotui#it618_paotui_salehz')->fetch_by_id($_GET['saleid']);
		
		if($it618_paotui_salehz['it618_state']>=3){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}else{
			$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);
			if($it618_paotui_shop['it618_uid']!=$uid){
				echo 'it618_split'.it618_paotui_getlang('s1246');exit;
			}
		}
		
		if($it618_paotui_salehz['it618_editcount']==1){
			echo 'it618_split'.it618_paotui_getlang('s206');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_salehz')->update($_GET['saleid'],array(
			'it618_yunfei' => $_GET['yunfei'],
			'it618_editcount' => 1
		));
		
		echo 'okit618_split'.it618_paotui_getlang('s193');
		exit;
	}
}

if($_GET['ac']=="sale_bz"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($_GET['saleid']);
		if(!($it618_paotui_sale['it618_state']==2)){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		if($it618_paotui_sale['it618_state']==2){
			C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
				'it618_content_pm' => it618_paotui_utftogbk($_GET['bzvalue'])
			));
			
			echo 'okit618_split'.it618_paotui_getlang('s1139');
			it618_paotui_sendmessage('salefahuo1_user',$_GET['saleid']);
			exit;
		}
	}
}

if($_GET['ac']=="sale_jujuetui"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($_GET['saleid']);
		if($it618_paotui_sale['it618_state']!=5){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
			'it618_state' => $it618_paotui_sale['it618_state_tuihuo']
		));
		
		echo 'okit618_split'.it618_paotui_getlang('s1213');
		it618_paotui_sendmessage('saletuihuo1_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_tongyitui"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($_GET['saleid']);
		if($it618_paotui_sale['it618_state']!=5){
			echo 'it618_split'.it618_paotui_getlang('s1246');exit;
		}
		
		$saleid=intval($_GET['saleid']);
		
		if($IsCredits==1&&$it618_paotui['paotui_tktype']==1){
			
			if($it618_paotui_sale['it618_score']>0){
				C::t('common_member_count')->increase($it618_paotui_sale['it618_uid'], array(
					'extcredits'.$it618_paotui['paotui_credit'] => $it618_paotui_sale['it618_score'])
				);
			}
			
			if($it618_paotui_sale['it618_sfmoney']>0){
				$money=$it618_paotui_sale['it618_sfmoney'];
				
				$it618_bz=$it618_paotui_lang['s382'];
				$it618_bz=str_replace("{money}",$money,$it618_bz);
				$it618_bz=str_replace("{saleid}",$saleid,$it618_bz);
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
				savemoney(array(
					'it618_uid' => $it618_paotui_sale['it618_uid'],
					'it618_type' => 'zy',
					'it618_money1' => $money,
					'it618_bz' => $it618_bz,
					'it618_zytype' => 'it618_paotui_tk',
					'it618_zyid' => $saleid,
					'it618_time' => $_G['timestamp']
				));
			}
			
			C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
				'it618_state' => 7
			));
			
			echo 'okit618_split'.it618_paotui_getlang('s1216');
			it618_paotui_sendmessage('tk_user',$_GET['saleid']);
		}else{
			C::t('#it618_paotui#it618_paotui_sale')->update($_GET['saleid'],array(
				'it618_state' => 6
			));
			
			echo 'okit618_split'.it618_paotui_getlang('s1216');
			it618_paotui_sendmessage('saletuihuo_user',$_GET['saleid']);
		}
		exit;
	}
}

if($_GET['ac']=="sale_tuihuo"){
	$saleid=$_GET['saleid'];
	$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($saleid);
	if($uid!=$it618_paotui_sale['it618_uid']){
		echo it618_paotui_getlang('s1246');exit;
	}
	
	$yytimestr=it618_paotui_getyytime();
	$yytimestrarr=explode("it618_split",$yytimestr);
	
	if($yytimestrarr[0]==0){
		echo $it618_paotui_lang['s95'].$yytimestrarr[1];exit;
	}
	
	if($it618_paotui_sale['it618_state']==4||$it618_paotui_sale['it618_state']==5||$it618_paotui_sale['it618_state']==6||$it618_paotui_sale['it618_state']==7){
		echo it618_paotui_getlang('s1246');exit;
	}
	
	C::t('#it618_paotui#it618_paotui_sale')->update($saleid,array(
		'it618_state' => 5,
		'it618_tuihuotype' => $_GET["it618_tuihuotype"],
		'it618_state_tuihuo' => $it618_paotui_sale['it618_state'],
		'it618_content_tuihuo' => it618_paotui_utftogbk($_GET["tuivalue"]),
	));

	echo 'okit618_split'.it618_paotui_getlang('s1206');
	it618_paotui_sendmessage('saletuihuo_admin',$_GET['saleid']);
	exit;
}

if($_GET['ac']=="sale_shouhuo"){
	$saleid=$_GET['saleid'];
	$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($saleid);
	if($uid!=$it618_paotui_sale['it618_uid']){
		echo it618_paotui_getlang('s1246');exit;
	}
	
	if($it618_paotui_sale['it618_type']<=2){
		if(!($it618_paotui_sale['it618_state']==3||$it618_paotui_sale['it618_state']==31)){
			echo it618_paotui_getlang('s1246');exit;
		}
	}else{
		if($it618_paotui_sale['it618_state']!=2){
			echo it618_paotui_getlang('s1246');exit;
		}
	}
	
	it618_paotui_qrxf($saleid);
	
	echo 'okit618_split'.it618_paotui_getlang('s1209');exit;
}

if($_GET['ac']=="sale_pj"){
	$saleid=$_GET['saleid'];
	$it618_paotui_sale=C::t('#it618_paotui#it618_paotui_sale')->fetch_by_id($saleid);
	
	$flag=0;
	if($it618_paotui_sale['it618_pj']>0){
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo it618_paotui_getlang('s1109');exit;
		}
	}else{
		if($uid!=$it618_paotui_sale['it618_uid']){
			echo it618_paotui_getlang('s1246');exit;
		}
		
		if($it618_paotui_sale['it618_state']!=4){
			echo it618_paotui_getlang('s1246');exit;
		}
		$flag=1;
	}
	
	C::t('#it618_paotui#it618_paotui_sale')->update($saleid,array(
		'it618_pjcontent' => it618_paotui_utftogbk($_GET["pjvalue"]),
		'it618_pj' => $_GET["salepj"]
	));
	
	if($flag==1){
		C::t('#it618_paotui#it618_paotui_sale')->update($saleid,array(
			'it618_pjtime' => $_G['timestamp']
		));
		echo 'okit618_split'.it618_paotui_getlang('s367');
	}else{
		echo 'okit618_split'.it618_paotui_getlang('s358').it618_paotui_getlang('s367');
	}
}

if($_GET['ac']=="sale_del"){
	if($uid<=0){
		echo 'it618_split'.it618_paotui_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_paotui_getlang('s1109');exit;
		}
		
		C::t('#it618_paotui#it618_paotui_salehz')->update($_GET['saleid'],array(
			'it618_state' => 4
		));

		echo 'okit618_split'.it618_paotui_getlang('s205');

		exit;
	}
}

if($_GET['ac']=="getsalemaxid"){
	$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
	if(!in_array($_G['uid'],$saleadmin)){
		echo 'it618_split'.it618_paotui_getlang('s1109');exit;
	}
	
	$id = C::t('#it618_paotui#it618_paotui_sale')->fetch_id_by_state();
	
	echo 'it618_split'.$id.'it618_split';exit;
}

if($_GET['ac']=="getsalehzmaxid"){
	$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
	if(!in_array($_G['uid'],$saleadmin)){
		echo 'it618_split'.it618_paotui_getlang('s1109');exit;
	}
	
	$id = C::t('#it618_paotui#it618_paotui_salehz')->fetch_id_by_state();
	
	echo 'it618_split'.$id.'it618_split';exit;
}

if($_GET['ac']=="sale_dao"){
	$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
	if(!in_array($_G['uid'],$saleadmin)){
		echo 'it618_split'.it618_paotui_getlang('s1109');exit;
	}
	
	if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
	
	$it618sql = "it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==31)$it618sql = "it618_state = 31";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
	}
	
	$count = C::t('#it618_paotui#it618_paotui_sale')->count_by_search($it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	$yunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	$xiaofei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_xiaofei',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	$scoremoney=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_scoremoney',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_score',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$strtmp= it618_paotui_getlang('s1136')."$count ".$it618_paotui_lang['s1143']."$yunfei ".$it618_paotui_lang['s1144']."$xiaofei ".$it618_paotui_lang['s1145']."$scoremoney ".$it618_paotui_lang['s1146']."$score"."\n";
	
	$strtmp.=$it618_paotui_lang['s1124'].",";
	$strtmp.=$it618_paotui_lang['s1118'].",";
	$strtmp.=$it618_paotui_lang['s1127'].",";
	$strtmp.=$it618_paotui_lang['s1128'].",";
	$strtmp.=$it618_paotui_lang['s1129'].",";
	$strtmp.=$it618_paotui_lang['s1130'].",";
	$strtmp.=$it618_paotui_lang['s1132'].",";
	$strtmp.=$it618_paotui_lang['s22'].",";
	$strtmp.=$it618_paotui_lang['s359'].",";
	$strtmp.=$it618_paotui_lang['s1134'].",";
	$strtmp.=$it618_paotui_lang['s1603'].",";
	$strtmp.=$it618_paotui_lang['s1135'].",";
	$strtmp.=$it618_paotui_lang['s387'].",";
	$strtmp.=$it618_paotui_lang['s388'].",";
	$strtmp.=$it618_paotui_lang['s389']."\n";
	
	foreach(C::t('#it618_paotui#it618_paotui_sale')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']
	) as $it618_paotui_sale) {
		
		if($it618_paotui_sale['it618_state']==1)$it618_state=$it618_paotui_lang['s1190'];
		if($it618_paotui_sale['it618_state']==2)$it618_state=$it618_paotui_lang['s1191'];
		if($it618_paotui_sale['it618_state']==3)$it618_state=$it618_paotui_lang['s1192'];
		if($it618_paotui_sale['it618_state']==31)$it618_state=$it618_paotui_lang['s309'];
		if($it618_paotui_sale['it618_state']==4)$it618_state=$it618_paotui_lang['s1193'];
		if($it618_paotui_sale['it618_state']==5)$it618_state=$it618_paotui_lang['s1194'];
		if($it618_paotui_sale['it618_state']==6)$it618_state=$it618_paotui_lang['s1195'];
		
		$peiman='';
		if($it618_paotui_sale['it618_pmid']!='0'){
			$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_sale['it618_pmid']);
			$peiman=$it618_paotui_sale['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'];
		}
		
		$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
		$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
		
		$it618_pj='';
		if($it618_paotui_sale['it618_pj']>0){
			if($it618_paotui_sale['it618_pj']==1)$it618_pj=$it618_paotui_lang['s362'];
			if($it618_paotui_sale['it618_pj']==2)$it618_pj=$it618_paotui_lang['s363'];
			if($it618_paotui_sale['it618_pj']==3)$it618_pj=$it618_paotui_lang['s364'];
		}
		
		$it618_pmtime='';$it618_pmoktime='';$timecount='';
		if($it618_paotui_sale['it618_pmtime']>0)$it618_pmtime=date('Y-m-d H:i:s', $it618_paotui_sale['it618_pmtime']);
		if($it618_paotui_sale['it618_pmoktime']>0)$it618_pmoktime=date('Y-m-d H:i:s', $it618_paotui_sale['it618_pmoktime']);
		if($it618_pmtime!=''&&$it618_pmoktime!='')$timecount=intval(($it618_paotui_sale['it618_pmoktime']-$it618_paotui_sale['it618_pmtime'])/60);
		
		$strtmp.=$it618_paotui_sale['id'].",";
		$strtmp.=$it618_type.",";
		$strtmp.=$it618_paotui_sale['it618_yunfei'].",";
		$strtmp.=$it618_paotui_sale['it618_xiaofei'].",";
		$strtmp.=$it618_paotui_sale['it618_scoremoney'].",";
		$strtmp.=$it618_paotui_sale['it618_score'].",";
		$strtmp.=$it618_state.",";
		$strtmp.=$peiman.",";
		$strtmp.=$it618_pj.",";
		$strtmp.=it618_paotui_getusername($it618_paotui_sale['it618_uid']).",";
		$strtmp.=$it618_paotui_sale['it618_tel1'].",";
		$strtmp.=date('Y-m-d H:i:s', $it618_paotui_sale['it618_time']).",";
		$strtmp.=$it618_pmtime.",";
		$strtmp.=$it618_pmoktime.",";
		$strtmp.=$timecount."\n";

		$datacount=$datacount+1;

	}
	
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_paotui_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_paotui/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}

if($_GET['ac']=="sale_get"){
	$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
	if(!in_array($_G['uid'],$saleadmin)){
		echo 'it618_split'.it618_paotui_getlang('s1109');exit;
	}
		
	$time=$_G['timestamp']-3600*$it618_paotui['paotui_autodatecount'];
	foreach(C::t('#it618_paotui#it618_paotui_sale')->fetch_all_by_it618_time($time) as $it618_paotui_sale) {
		it618_paotui_qrxf($it618_paotui_sale['id']);
	}
	
	if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;

	if($_GET['wap']!=1){
		$ppp = 15;
	}else{
		$ppp = 10;
	}
	
	$funname='getsalelist';
	
	$it618sql = "it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==31)$it618sql = "it618_state = 31";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
	}
	
	$count = C::t('#it618_paotui#it618_paotui_sale')->count_by_search($it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	$tmp='<option value="0">'.it618_paotui_getlang('s1188').'</option>';
	
	$atmpstr='';
	if($_GET['wap']==1)$atmpstr='style="float:right"';
	
	foreach(C::t('#it618_paotui#it618_paotui_sale')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_paotui_sale) {
		
		if($it618_paotui_sale['it618_state']==1){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1190'].'</font>';
			
			$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_getsale('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1200'].'</a>';
		}
		
		if($it618_paotui_sale['it618_state']==2){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1191'].'</font>';
			
			if($it618_paotui_sale['it618_type']<=2){
				$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_fahuo('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1203'].'</a>';
			}else{
				$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_bz('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1131'].'(<font color=red>'.strlen($it618_paotui_sale['it618_content_pm']).'</font>)</a>';
			}
		}
		
		$it618_lbs='';
		if($it618_paotui_sale['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_paotui_lang['s1192'].'</font>';
			
			$it618_state.='<a href="javascript:" '.$atmpstr.' onclick="sale_fahuo('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1170'].'</a><a href="javascript:" style="float:right;margin-right:6px" onclick="sale_getok('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s308'].'</a>';
			
			$it618_lbs=' <a href="javascript:" onclick="showsalelbs('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s370'].'</a>';
		}
		
		if($it618_paotui_sale['it618_state']==31){
			$it618_state='<font color=#F60>'.$it618_paotui_lang['s309'].'</font> <font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_sale['it618_pmoktime']).'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==4){
			$it618_state='<font color=green>'.$it618_paotui_lang['s1193'].'</font>';
			
			if($it618_paotui_sale['it618_pj']>0){
				if($it618_paotui_sale['it618_pj']==1)$it618_pj=$it618_paotui_lang['s362'];
				if($it618_paotui_sale['it618_pj']==2)$it618_pj=$it618_paotui_lang['s363'];
				if($it618_paotui_sale['it618_pj']==3)$it618_pj=$it618_paotui_lang['s364'];
				
				$it618_state.='<a href="javascript:" style="float:right;margin-left:6px" onclick="sale_pj('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s369'].'</a><span style="float:right;color:red">'.$it618_pj.'</span>';
			}
		}
		
		if($it618_paotui_sale['it618_state']==5){
			$it618_state='<font color=purple>'.$it618_paotui_lang['s1194'].'</font>';
			
			if($it618_paotui_sale['it618_state_tuihuo']==1)$it618_statetmp=$it618_paotui_lang['s1190'];
			if($it618_paotui_sale['it618_state_tuihuo']==2)$it618_statetmp=$it618_paotui_lang['s1191'];
			if($it618_paotui_sale['it618_state_tuihuo']==3)$it618_statetmp=$it618_paotui_lang['s1192'];
			if($it618_paotui_sale['it618_state_tuihuo']==4)$it618_statetmp=$it618_paotui_lang['s1193'];
			$it618_state.=' <font color=#999>'.$it618_paotui_lang['s1171'].$it618_statetmp.'</font>';
			
			if($_GET['wap']!=1){
				$it618_state.='<br><a href="javascript:" onclick="sale_jujuetui('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1211'].'</a> <a href="javascript:" onclick="sale_tongyitui('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1214'].'</a>';
			}else{
				$it618_state.='<br><span style="float:right"><a href="javascript:" onclick="sale_jujuetui('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1211'].'</a> <a href="javascript:" onclick="sale_tongyitui('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1214'].'</a></span>';
			}
		}
		
		if($it618_paotui_sale['it618_state']==6){
			$it618_state='<font color=purple>'.$it618_paotui_lang['s1195'].'</font>';
		}
		
		if($it618_paotui_sale['it618_state']==7){
			$it618_state='<font color=#FF00FF>'.$it618_paotui_lang['s1196'].'</font>';
		}
		
		$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
		$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];
		
		if($it618_paotui['paotui_pmmodehide']==0){
			$it618_isrwpmpower='';
			if($it618_paotui_sale['it618_state']==1){
				if($it618_paotui_sale['it618_isrwpmpower']==1){
					$it618_isrwpmpower='<font color=green>'.$it618_paotui_lang['s334'].'</font>';
				}else{
					$it618_isrwpmpower='<a href="javascript:" onclick="sale_isrwpmpower('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s335'].'</a>';
					if($it618_paotui['paotui_pmmode']==3){
						$it618_time=$_G['timestamp']-$it618_paotui_sale['it618_time'];
						if($it618_time>=$it618_paotui['paotui_pmmodetime']*60){
							$it618_isrwpmpower='<font color=green>'.$it618_paotui_lang['s334'].'</font>';
							C::t('#it618_paotui#it618_paotui_sale')->update_it618_isrwpmpower_by_id($it618_paotui_sale['id']);
						}else{
							$it618_isrwpmpower='<a href="javascript:" onclick="sale_isrwpmpower('.$it618_paotui_sale['id'].')">'.($it618_paotui['paotui_pmmodetime']*60-$it618_time).''.$it618_paotui_lang['s336'].'</a>';
						}
					}
				}
			}
			$it618_isrwpmpower1='<td>'.$it618_isrwpmpower.'</td>';
		}
		
		$peiman='';
		if($it618_paotui_sale['it618_pmid']!='0'){
			$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_sale['it618_pmid']);
			$peiman=' '.$it618_paotui_sale['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'];
		}
		if($it618_paotui_sale['it618_rwpmid']>0){
			$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($it618_paotui_sale['it618_rwpmid']);
			$peiman=' '.$it618_paotui_sale['it618_rwpmid'].'-'.it618_paotui_getusername($it618_paotui_rwpeiman['it618_uid']).'-'.$it618_paotui_rwpeiman['it618_name'];
		}
		
		if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
		
		if($_GET['wap']!=1){

			if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;

			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/themes/common/right.txt')){
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/ajax.inc.php';
				$result=unlink($ajaxpath);
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/lang.func.php';
				$result=unlink($ajaxpath);
			}

			if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
			
			$sale_get.='<tr class="hover">
			<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_paotui_sale[id].'" name="delete[]" value="'.$it618_paotui_sale[id].'" '.$disabled.'><label for="chk_del'.$it618_paotui_sale[id].'">'.$it618_paotui_sale['id'].'</label></td>
			<td>'.$it618_type.'</td>
			<td><font color="red">'.$it618_paotui_sale['it618_yunfei'].'</font></td>
			<td><font color="red">'.$it618_paotui_sale['it618_xiaofei'].'</font></td>
			<td><font color="#390">'.$it618_paotui_sale['it618_scoremoney'].'</font></td>
			<td><font color="#390">'.$it618_paotui_sale['it618_score'].'</font></td>
			<td><a href="javascript:" onclick="showsale('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1125'].'</a></td>
			<td>'.$it618_state.$peiman.$it618_lbs.'</td>
			'.$it618_isrwpmpower1.'
			<td>'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'</td>
			<td><font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_sale['it618_time']).'</font></td>
			</tr>';

		}else{
			if($peiman!='')$peiman='<br>'.$peiman;
			
			$sale_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;line-height:15px">
							<div class="dealcard-paotui single-line"><a href="javascript:" style="float:right" onclick="showsale('.$it618_paotui_sale['id'].')">'.$it618_paotui_lang['s1125'].'</a><font color=#999>'.$it618_paotui_lang['s1124'].':</font>'.$it618_paotui_sale['id'].' <font color=#999>'.$it618_paotui_lang['s1127'].':</font>'.$it618_paotui_sale['it618_yunfei'].'</div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px"><font color=#999>'.$it618_paotui_lang['s1128'].':</font>'.$it618_paotui_sale['it618_xiaofei'].' <font color=#999>'.$it618_paotui_lang['s1129'].':</font>'.$it618_paotui_sale['it618_scoremoney'].' <font color=#999>'.$it618_paotui_lang['s1130'].':</font>'.$it618_paotui_sale['it618_score'].'<br>'.$it618_type.':<font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_sale['it618_time']).'</font> '.$it618_isrwpmpower.$peiman.$it618_lbs.'<br>'.$it618_state.'</div>
						</div>
					</dd>';
		}

	}
	
	$yunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	$xiaofei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_xiaofei',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	$scoremoney=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_scoremoney',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_score',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_paotui:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value=1 name=page /></td>';
		
		$salesum= '<td colspan=15><span style="float:right;">'.$it618_paotui_lang['s1601'].'</span>'.it618_paotui_getlang('s1136')."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font> ".$it618_paotui_lang['s1144']."<font color=red>$xiaofei</font> ".$it618_paotui_lang['s1145']."<font color=#390>$scoremoney</font> ".$it618_paotui_lang['s1146']."<font color=#390>$score</font></span></td>";
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_paotui_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		$salesum= it618_paotui_getlang('s1136')."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font> ".$it618_paotui_lang['s1144']."<font color=red>$xiaofei</font><br>".$it618_paotui_lang['s1145']."<font color=#390>$scoremoney</font> ".$it618_paotui_lang['s1146']."<font color=#390>$score</font>";
	}
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage.'<script>'.$tmpjs.'</script>';
	exit;
}

if($_GET['ac']=="salehz_dao"){
	$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
	if(!in_array($_G['uid'],$saleadmin)){
		echo 'it618_split'.it618_paotui_getlang('s1109');exit;
	}
	
	if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
	
	$it618sql = "it618_state>0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==21)$it618sql = "it618_state = 21";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
	}
	
	$count = C::t('#it618_paotui#it618_paotui_sale')->count_by_search($it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	$yunfei=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$strtmp= it618_paotui_getlang('s1136')."$count ".$it618_paotui_lang['s1143']."$yunfei"."\n";
	
	$strtmp.=$it618_paotui_lang['s1124'].",";
	$strtmp.=$it618_paotui_lang['s187'].",";
	$strtmp.=$it618_paotui_lang['s188'].",";
	$strtmp.=$it618_paotui_lang['s103'].",";
	$strtmp.=$it618_paotui_lang['s191'].",";
	$strtmp.=$it618_paotui_lang['s1127'].",";
	$strtmp.=$it618_paotui_lang['s192'].",";
	$strtmp.=$it618_paotui_lang['s189'].",";
	$strtmp.=$it618_paotui_lang['s1132'].",";
	$strtmp.=$it618_paotui_lang['s22'].",";
	$strtmp.=$it618_paotui_lang['s1134'].",";
	$strtmp.=$it618_paotui_lang['s1135'].",";
	$strtmp.=$it618_paotui_lang['s387'].",";
	$strtmp.=$it618_paotui_lang['s388'].",";
	$strtmp.=$it618_paotui_lang['s389']."\n";
	
	foreach(C::t('#it618_paotui#it618_paotui_salehz')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']
	) as $it618_paotui_salehz) {
		
		if($it618_paotui_salehz['it618_state']==1)$it618_state=$it618_paotui_lang['s1190'];
		if($it618_paotui_salehz['it618_state']==2)$it618_state=$it618_paotui_lang['s1192'];
		if($it618_paotui_salehz['it618_state']==21)$it618_state=$it618_paotui_lang['s309'];
		if($it618_paotui_salehz['it618_state']==3)$it618_state=$it618_paotui_lang['s1193'];
		if($it618_paotui_salehz['it618_state']==4)$it618_state=$it618_paotui_lang['s1197'];
		
		$peiman='';
		if($it618_paotui_salehz['it618_pmid']!=''){
			$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_salehz['it618_pmid']);
			$peiman=$it618_paotui_salehz['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'];
		}
		
		$it618_pmtime='';$it618_pmoktime='';$timecount='';
		if($it618_paotui_salehz['it618_pmtime']>0)$it618_pmtime=date('Y-m-d H:i:s', $it618_paotui_salehz['it618_pmtime']);
		if($it618_paotui_salehz['it618_pmoktime']>0)$it618_pmoktime=date('Y-m-d H:i:s', $it618_paotui_salehz['it618_pmoktime']);
		if($it618_pmtime!=''&&$it618_pmoktime!='')$timecount=intval(($it618_paotui_salehz['it618_pmoktime']-$it618_paotui_salehz['it618_pmtime'])/60);
		
		$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);
		
		$strtmp.=$it618_paotui_salehz['id'].",";
		$strtmp.=$it618_paotui_shop['it618_hzshopid'].",";
		$strtmp.=$it618_paotui_shop['it618_name'].",";
		$strtmp.=$it618_paotui_shop['it618_tel'].",";
		$strtmp.=$it618_paotui_shop['it618_addr'].",";
		$strtmp.=$it618_paotui_salehz['it618_yunfei'].",";
		$strtmp.=$it618_paotui_salehz['it618_tel'].",";
		$strtmp.=$it618_paotui_salehz['it618_addr'].",";
		$strtmp.=$it618_state.",";
		$strtmp.=$peiman.",";
		$strtmp.=it618_paotui_getusername($it618_paotui_salehz['it618_uid']).",";
		$strtmp.=date('Y-m-d H:i:s', $it618_paotui_salehz['it618_time']).",";
		$strtmp.=$it618_pmtime.",";
		$strtmp.=$it618_pmoktime.",";
		$strtmp.=$timecount."\n";

		$datacount=$datacount+1;

	}
	
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_paotui_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_paotui/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}

if($_GET['ac']=="salehz_get"){
	$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
	if(!in_array($_G['uid'],$saleadmin)){
		echo 'it618_split'.it618_paotui_getlang('s1109');exit;
	}
	
	if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
	
	$time=$_G['timestamp']-3600*$it618_paotui['paotui_autodatecount'];
	foreach(C::t('#it618_paotui#it618_paotui_salehz')->fetch_all_by_it618_time($time) as $it618_paotui_salehz) {
		it618_paotui_qrxfhz($it618_paotui_salehz['id']);
	}

	if($_GET['wap']!=1){
		$ppp = 15;
	}else{
		$ppp = 10;
	}
	$funname='getsalelist';
	
	$it618sql = "it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==21)$it618sql = "it618_state = 21";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
	}
	
	$count = C::t('#it618_paotui#it618_paotui_salehz')->count_by_search($it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	$tmp='<option value="0">'.it618_paotui_getlang('s1188').'</option>';
	
	$atmpstr='';
	if($_GET['wap']==1)$atmpstr='style="float:right;margin-left:10px"';
	
	foreach(C::t('#it618_paotui#it618_paotui_salehz')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_paotui_salehz) {
		
		if($it618_paotui_salehz['it618_state']==1){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1190'].'</font>';
			
			$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_fahuo('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s1203'].'</a>';
		}
		
		$it618_lbs='';
		if($it618_paotui_salehz['it618_state']==2){
			$it618_state='<font color=blue>'.$it618_paotui_lang['s1192'].'</font>';
			
			$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_fahuo('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s1170'].'</a>';
			$it618_state.=' <a href="javascript:" style="float:right;margin-left:10px" onclick="sale_getok('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s308'].'</a>';
			
			$it618_lbs=' <a href="javascript:" onclick="showsalelbs('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s370'].'</a>';
		}
		
		$it618_del=' <a href="javascript:" onclick="sale_del('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s198'].'</a>';
		
		$it618_yunfei=' <a href="javascript:" '.$atmpstr.' onclick="sale_yunfei('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s190'].'</a>';
		
		if($it618_paotui_salehz['it618_state']==21){
			$it618_state='<font color=#F60>'.$it618_paotui_lang['s309'].'</font> <font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_salehz['it618_pmoktime']).'</font>';
			$it618_lbs=' <a href="javascript:" onclick="showsalelbs('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s370'].'</a>';
		}
		
		if($it618_paotui_salehz['it618_state']==3){
			$it618_yunfei='';
			$it618_del='';
			$it618_state='<font color=green>'.$it618_paotui_lang['s1193'].'</font>';
		}
		
		if($it618_paotui_salehz['it618_state']==4){
			$it618_yunfei='';
			$it618_del='';
			$it618_state='<font color=#FF00FF>'.$it618_paotui_lang['s1197'].'</font>';
		}
		
		$peiman='';
		if($it618_paotui_salehz['it618_pmid']!=''){
			$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_salehz['it618_pmid']);
			$peiman=' '.$it618_paotui_salehz['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'].' '.date('H:i:s', $it618_paotui_salehz['it618_pmtime']);
		}
		
		$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);
		
		if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
		
		if($_GET['wap']!=1){

			if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;

			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_paotui/kindeditor/themes/common/right.txt')){
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/ajax.inc.php';
				$result=unlink($ajaxpath);
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_paotui/lang.func.php';
				$result=unlink($ajaxpath);
			}

			if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
			
			$sale_get.='<tr class="hover">
			<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_paotui_salehz[id].'" name="delete[]" value="'.$it618_paotui_salehz[id].'" '.$disabled.'><label for="chk_del'.$it618_paotui_salehz[id].'">'.$it618_paotui_salehz['id'].'</label></td>
			<td>'.$it618_paotui_shop['it618_hzshopid'].' '.$it618_del.'</td>
			<td>'.$it618_paotui_shop['it618_name'].'</td>
			<td><font color="red">'.$it618_paotui_salehz['it618_yunfei'].'</font> '.$it618_yunfei.'</td>
			<td><a href="javascript:" onclick="showsale('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s1125'].'</a></td>
			<td>'.$it618_paotui_salehz['it618_addr'].'</td>
			<td>'.$it618_state.$it618_lbs.$peiman.'</td>
			<td>'.it618_paotui_getusername($it618_paotui_salehz['it618_uid']).'</td>
			<td><font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_salehz['it618_time']).'</font></td>
			</tr>';

		}else{
			if($peiman!='')$peiman='<br>'.$peiman;
			
			$sale_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;line-height:15px">
							<div class="dealcard-paotui single-line"><a href="javascript:" '.$atmpstr.' onclick="showsale('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s1125'].'</a>'.$it618_yunfei.'<font color=#999>'.$it618_paotui_lang['s1124'].':</font>'.$it618_paotui_salehz['id'].' '.$it618_del.'</div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px">'.$it618_paotui_salehz['it618_addr'].' '.$it618_paotui_salehz['it618_tel'].'<br>'.$it618_paotui_shop['it618_hzshopid'].' '.$it618_paotui_shop['it618_name'].'<br><font color=#999>'.$it618_paotui_lang['s1127'].':</font>'.$it618_paotui_salehz['it618_yunfei'].' <font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_salehz['it618_time']).'</font>'.$peiman.$it618_lbs.'<br>'.$it618_state.'</div>
						</div>
					</dd>';
		}

	}
	
	$yunfei=C::t('#it618_paotui#it618_paotui_salehz')->sum_by_search('it618_yunfei',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_paotui:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value=1 name=page /></td>';
		
		$salesum= '<td colspan=15><span style="float:right;">'.$it618_paotui_lang['s1601'].'</span>'.it618_paotui_getlang('s1136')."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font></span></td>";
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_paotui_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		$salesum= it618_paotui_getlang('s1136')."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font>";
	}
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}

if($_GET['ac']=="shopsalehz_get"){
	if($shoptmp=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_uid($uid)){
		if($shoptmp['it618_hzshopid']==''){
			echo it618_paotui_getlang('s179');exit;
		}
		if($shoptmp['it618_htstate']==0){
			echo it618_paotui_getlang('s180');exit;
		}
		if($shoptmp['it618_htstate']==2){
			echo it618_paotui_getlang('s181');exit;
		}
		
		$it618_shopid=$shoptmp['id'];
	}else{
		echo it618_paotui_getlang('s182');exit;
	}
	
	if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
	
	$time=$_G['timestamp']-3600*$it618_paotui['paotui_autodatecount'];
	foreach(C::t('#it618_paotui#it618_paotui_salehz')->fetch_all_by_it618_time($time) as $it618_paotui_salehz) {
		it618_paotui_qrxfhz($it618_paotui_salehz['id']);
	}

	$ppp = 10;
	$funname='getsalelist';
	
	$it618sql = "it618_shopid=$it618_shopid";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==21)$it618sql = "it618_state = 21";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
	}
	
	$count = C::t('#it618_paotui#it618_paotui_salehz')->count_by_search($it618sql,'',0,'', $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;

	$tmp='<option value="0">'.it618_paotui_getlang('s1188').'</option>';
	
	$atmpstr='';
	if($_GET['wap']==1)$atmpstr='style="float:right;margin-left:10px"';
	
	foreach(C::t('#it618_paotui#it618_paotui_salehz')->fetch_all_by_search(
		$it618sql,'id desc',0,'', $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_paotui_salehz) {
		
		if($it618_paotui_salehz['it618_state']==1){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1190'].'</font>';
		}
		
		if($it618_paotui_salehz['it618_state']==2){
			$it618_state='<font color=blue>'.$it618_paotui_lang['s1192'].'</font>';
		}
		
		if($it618_paotui_salehz['it618_state']==21){
			$it618_state='<font color=#F60>'.$it618_paotui_lang['s309'].'</font> <font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_salehz['it618_pmoktime']).'</font>';
		}
		
		$it618_yunfei='';
		if($it618_paotui_salehz['it618_editcount']==0)$it618_yunfei=' <a href="javascript:" '.$atmpstr.' onclick="sale_yunfei('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s190'].'</a>';
		
		if($it618_paotui_salehz['it618_state']==3){
			$it618_yunfei='';
			$it618_state='<font color=green>'.$it618_paotui_lang['s1193'].'</font>';
		}
		
		if($it618_paotui_salehz['it618_state']==4){
			$it618_state='<font color=#FF00FF>'.$it618_paotui_lang['s1197'].'</font>';
		}
		
		$peiman='';
		if($it618_paotui_salehz['it618_pmid']!=''){
			$it618_paotui_peiman=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_pmid($it618_paotui_salehz['it618_pmid']);
			$peiman=' '.$it618_paotui_salehz['it618_pmid'].'-'.$it618_paotui_peiman['it618_name'].' '.date('H:i:s', $it618_paotui_salehz['it618_pmtime']);
		}
		
		$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);
		
		if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
		
		$sale_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;line-height:15px">
							<div class="dealcard-paotui single-line"><a href="javascript:" '.$atmpstr.' onclick="showsale('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s1125'].'</a>'.$it618_yunfei.'<font color=#999>'.$it618_paotui_lang['s1124'].':</font>'.$it618_paotui_salehz['id'].' <font color=#999>'.$it618_paotui_lang['s1127'].':</font>'.$it618_paotui_salehz['it618_yunfei'].'</div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px">'.$it618_paotui_shop['it618_hzshopid'].' <font color=red>'.$it618_paotui_shop['it618_name'].'</font><br>'.$it618_paotui_salehz['it618_addr'].' '.$it618_paotui_salehz['it618_tel'].'<br><font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_salehz['it618_time']).'</font><br>'.$it618_state.$peiman.'</div>
						</div>
					</dd>';

	}
	
	$yunfei=C::t('#it618_paotui#it618_paotui_salehz')->sum_by_search('it618_yunfei',$it618sql,'',$_GET['finduid'],$_GET['peiman'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_paotui_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$salesum= it618_paotui_getlang('s1136')."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font>";
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}

if($_GET['ac']=="pmhzsalelist_get"){
	if(!$peimantmp=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_uid($uid)){
		echo 'it618_split'.it618_paotui_getlang('s210');exit;
	}
	
	if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
	
	$time=$_G['timestamp']-3600*$it618_paotui['paotui_autodatecount'];
	foreach(C::t('#it618_paotui#it618_paotui_salehz')->fetch_all_by_it618_time($time) as $it618_paotui_salehz) {
		it618_paotui_qrxfhz($it618_paotui_salehz['id']);
	}

	$ppp = 10;
	$funname='getsalelist';
	
	$it618sql = "";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==21)$it618sql = "it618_state = 21";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
	}
	
	$count = C::t('#it618_paotui#it618_paotui_salehz')->count_by_search($it618sql,'',0,$peimantmp['it618_pmid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_paotui#it618_paotui_salehz')->fetch_all_by_search(
		$it618sql,'id desc',0,$peimantmp['it618_pmid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_paotui_salehz) {
		
		if($it618_paotui_salehz['it618_state']==1){
			$it618_state='<font color=red>'.$it618_paotui_lang['s1190'].'</font>';
		}
		
		if($it618_paotui_salehz['it618_state']==2){
			$it618_state='<font color=blue>'.$it618_paotui_lang['s1192'].'</font>';
			$it618_state.='<a href="javascript:" style="float:right;" onclick="sale_getok('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s308'].'</a>';
		}
		
		if($it618_paotui_salehz['it618_state']==21){
			$it618_state='<font color=#F60>'.$it618_paotui_lang['s309'].'</font> <font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_salehz['it618_pmoktime']).'</font>';
		}
		
		if($it618_paotui_salehz['it618_state']==3){
			$it618_state='<font color=green>'.$it618_paotui_lang['s1193'].'</font>';
		}
		
		if($it618_paotui_salehz['it618_state']==4){
			$it618_state='<font color=#FF00FF>'.$it618_paotui_lang['s1197'].'</font>';
		}
		
		$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($it618_paotui_salehz['it618_shopid']);
		
		if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])exit;
		
		$sale_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;line-height:15px">
							<div class="dealcard-paotui single-line"><a href="javascript:" style="float:right;" onclick="showsale('.$it618_paotui_salehz['id'].')">'.$it618_paotui_lang['s1125'].'</a>'.$it618_yunfei.'<font color=#999>'.$it618_paotui_lang['s1124'].':</font>'.$it618_paotui_salehz['id'].' <font color=#999>'.$it618_paotui_lang['s1127'].':</font>'.$it618_paotui_salehz['it618_yunfei'].'</div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px">'.$it618_paotui_shop['it618_hzshopid'].' <font color=red>'.$it618_paotui_shop['it618_name'].'</font><br>'.$it618_paotui_salehz['it618_addr'].' '.$it618_paotui_salehz['it618_tel'].'<br><font color=#999>'.date('Y-m-d H:i:s', $it618_paotui_salehz['it618_time']).'</font><br>'.$it618_state.'</div>
						</div>
					</dd>';

	}
	
	$yunfei=C::t('#it618_paotui#it618_paotui_salehz')->sum_by_search('it618_yunfei',$it618sql,'',$_GET['finduid'],$peimantmp['it618_pmid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_paotui_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_paotui:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_paotui_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_paotui_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$salesum= it618_paotui_getlang('s1136')."<font color=red>$count</font> ".$it618_paotui_lang['s1143']."<font color=red>$yunfei</font>";
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}

if($_GET['ac']=="getyunfeimoney"){
	$yunfeiarr=explode("it618_split",it618_paotui_getyunfei());
	$yunfei_first=$yunfeiarr[0];
	$yunfei_yunfei1=$yunfeiarr[1];
	$yunfei_yunfei2=$yunfeiarr[2];
	$yunfeistr=$yunfeiarr[3];
	
	$yytime_isok=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yytime_isok');
	$yytime_isokbz=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yytime_isokbz');
	$yytime_isoktime=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yytime_isoktime');
	
	if($yytime_isok==1){
		if($yytime_isoktime=='')$yytime_isoktime=$it618_paotui_lang['s913'];
		$yytime=$it618_paotui_lang['s1137'].'<font color=green>'.$yytime_isoktime.'</font>';
	}else{
		$yytime=$yytime_isokbz;
	}

	if(isset($_GET['islbs'])){
		echo '<table width="100%">
		<tr><td style="border:none;padding:0">'.$yytime.'<br>'.$yunfeistr.'<br><font color=#f30  style="font-size:15px;float:right;margin-top:-6px">+ &yen;<span id="yunfeimoney" style="font-size:20px">'.$yunfei_yunfei1.'</span></font><input type="hidden" id="yunfeiok" value="1"><font color=#999>'.$it618_paotui_lang['s1235'].'</font><a href="javascript:" onclick="getlbsabout(this)">'.$it618_paotui_lang['s1236'].'</a></td></tr>
		<tr id="lbsabout" style="display:none"><td colspan=2><img src="source/plugin/it618_paotui/images/lbsabout.png" style="max-width:100%"><font color=#999>'.$it618_paotui_lang['s1227'].'</font></td></tr></table>';
		exit;
	}
	
	$lbslat1=$_GET['lbslat1'];
	$lbslng1=$_GET['lbslng1'];
	$lbslat2=$_GET['lbslat2'];
	$lbslng2=$_GET['lbslng2'];

	$lbsdata=it618_paotui_getdistance_gd($lbslng1,$lbslat1,$lbslng2,$lbslat2);
	
	if($lbsdata['info']=='OK'){
		if($lbsdata['results'][0]['distance']>0){
			$lbsm=$lbsdata['results'][0]['distance'];
			//$lbst=$lbsdata['results'][0]['duration'];
			//$lbst=round($lbst/60,1).'<span style="font-size:10px">'.$it618_paotui_lang['s1233'].'</font>';
			
			$lbsmtmp=round($lbsm/1000,1);
			if($lbsmtmp<=$yunfei_first){
				$yunfei=$yunfei_yunfei1;
			}else{
				$tmpm=$lbsmtmp-$yunfei_first;
				$tmpm1=intval($tmpm);
				if($tmpm1<$tmpm)$tmpm1=$tmpm1+1;
				$yunfei=$yunfei_yunfei1+$tmpm1*$yunfei_yunfei2;
			}
			
			if($lbsm<1000)$lbsm=intval($lbsm).'m';
			if($lbsm>=1000)$lbsm=round($lbsm/1000,1).'km';
			
			echo '<table width="100%">
			<tr><td style="border:none;padding:0">'.$it618_paotui_lang['s1138'].'<font color=red><b>'.$lbsm.'</b></font><br>'.$yunfeistr.'<br><font color=#f30  style="font-size:15px;float:right;margin-top:-6px">+ &yen;<span id="yunfeimoney" style="font-size:20px">'.$yunfei.'</span></font><input type="hidden" id="yunfeiok" value="1"><font color=#999>'.$it618_paotui_lang['s1235'].'</font><a href="javascript:" onclick="getlbsabout(this)">'.$it618_paotui_lang['s1236'].'</a></td></tr>
			<tr id="lbsabout" style="display:none"><td colspan=2><img src="source/plugin/it618_paotui/images/lbsabout.png" style="max-width:100%"><font color=#999>'.$it618_paotui_lang['s1227'].'</font></td></tr></table>';
		}else{
			$tmparr=explode("|",$it618_paotui_lang['s82']);
			echo '<table width="100%">
			<tr><td style="border:none;padding:0">'.it618_paotui_utftogbk($lbsdata['results'][0]['info']).'<br>'.it618_paotui_utftogbk($tmparr[$lbsdata['results'][0]['code']]).'</td></tr>
			<tr><td style="border:none;padding:0"><font color=#f30  style="font-size:15px;float:right">+ &yen;<span id="yunfeimoney" style="font-size:20px">0</span></font><input type="hidden" id="yunfeiok" value="0"></td></tr>
			</table>';
		}
	}else{
		echo '<table width="100%">
		<tr><td style="border:none;padding:0">'.$it618_paotui_lang['s1234'].it618_paotui_utftogbk($lbsdata['info']).'</td></tr>
		<tr><td style="border:none;padding:0"><font color=#f30  style="font-size:15px;float:right">+ &yen;<span id="yunfeimoney" style="font-size:20px">0</span></font><input type="hidden" id="yunfeiok" value="0"></td>
		</tr>
		</table>';
	}
	
	exit;
}

if($_GET['ac']=="sqpeiman"){
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	$paotui_rwpmgroup=(array)unserialize($it618_paotui['paotui_rwpmgroup']);
	if($uid<=0){
		echo it618_paotui_getlang('s1389');exit;
	}elseif(!in_array($_G['groupid'], $paotui_rwpmgroup)){
		echo it618_paotui_getlang('s1390');exit;
	}else{
		if($IsCredits!=1){
			echo it618_paotui_getlang('s380');exit;
		}
		
		$count = C::t('#it618_paotui#it618_paotui_rwpeiman')->count_by_it618_uid($_G['uid']);
		if($ii1i11i[3]!='1')return;
		if($count==0){
			$id = C::t('#it618_paotui#it618_paotui_rwpeiman')->insert(array(
				'it618_uid' => $uid,
				'it618_name' => it618_paotui_utftogbk($_GET['it618_name']),
				'it618_tel' => it618_paotui_utftogbk($_GET['it618_tel']),
				'it618_wx' => it618_paotui_utftogbk($_GET['it618_wx']),
				'it618_qq' => it618_paotui_utftogbk($_GET['it618_qq']),
				'it618_addr' => it618_paotui_utftogbk($_GET['it618_addr']),
				'it618_liyou' => it618_paotui_utftogbk($_GET['it618_liyou']),
				'it618_state' => 0,
				'it618_rztime' => $_G['timestamp']
			), true);
			if(lang('plugin/it618_paotui', $it618_paotui_lang['it618'])!=$it618_paotui_lang['version'])return;
			if($id>0){
				it618_paotui_sendmessage('sqpm_admin',$id);
				echo 'ok';
			}else{
				echo it618_paotui_getlang('s498');
			}
		}else{
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[7]!='a')return;
			$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_uid($_G['uid']);
			$id = C::t('#it618_paotui#it618_paotui_rwpeiman')->update($it618_paotui_rwpeiman['id'],array(
				'it618_name' => it618_paotui_utftogbk($_GET['it618_name']),
				'it618_tel' => it618_paotui_utftogbk($_GET['it618_tel']),
				'it618_wx' => it618_paotui_utftogbk($_GET['it618_wx']),
				'it618_qq' => it618_paotui_utftogbk($_GET['it618_qq']),
				'it618_addr' => it618_paotui_utftogbk($_GET['it618_addr']),
				'it618_liyou' => it618_paotui_utftogbk($_GET['it618_liyou']),
				'it618_state' => 0,
				'it618_rztime' => $_G['timestamp']
			));
			if(count($ii1i11i)!=12)return;
			if($id>0){
				it618_paotui_sendmessage('sqpm_admin',$id);
				echo 'ok';
			}else{
				echo it618_paotui_getlang('s499');
			}
		}
	}
	
	exit;
}

if($_GET['ac']=="pmlbs_save"){
	$rwpeimantmp=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_uid($uid);
	if($rwpeimantmp['it618_state']==2){
		$lbsarr=it618_paotui_maptxtobd($_GET['lbslat'],$_GET['lbslng']);
		
		C::t('#it618_paotui#it618_paotui_rwpeiman')->update($rwpeimantmp['id'],array(
			'it618_lbslat' => $lbsarr['lat'],
			'it618_lbslng' => $lbsarr['lng'],
			'it618_lbsaddr' => it618_paotui_utftogbk($_GET['lbsaddr']),
			'it618_lbstime' => $_G['timestamp']
		));
	}
	
	if($peimantmp=C::t('#it618_paotui#it618_paotui_peiman')->fetch_by_uid($uid)){
		$lbsarr=it618_paotui_maptxtobd($_GET['lbslat'],$_GET['lbslng']);
		
		C::t('#it618_paotui#it618_paotui_peiman')->update($peimantmp['id'],array(
			'it618_lbslat' => $lbsarr['lat'],
			'it618_lbslng' => $lbsarr['lng'],
			'it618_lbsaddr' => it618_paotui_utftogbk($_GET['lbsaddr']),
			'it618_lbstime' => $_G['timestamp']
		));
	}
}
//From: Dism_taobao-com
?>