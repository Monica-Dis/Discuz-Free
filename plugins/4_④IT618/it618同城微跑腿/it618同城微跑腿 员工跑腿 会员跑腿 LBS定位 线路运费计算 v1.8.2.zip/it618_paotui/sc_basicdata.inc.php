<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';
$sctitle=it618_paotui_getlang('s147');
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/sc_header.func.php';

$saleadmin=explode(",",$it618_paotui['paotui_saleadmin']);
if(!in_array($_G['uid'],$saleadmin)){
	it618_cpmsg($it618_paotui_lang['s28'], '', 'error');
}

$sid=intval($_GET['sid']);

$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($sid);
if(submitcheck('it618submit')){
	
	$it618_mappoint=dhtmlspecialchars($_GET['it618_mappoint']);
	$tmparr=explode(",",$it618_mappoint);
	
	$lbsarr=it618_paotui_mapbdtotx($tmparr[1],$tmparr[0]);
	$it618_lbslat=$lbsarr['lat'];
	$it618_lbslng=$lbsarr['lng'];
	
	C::t('#it618_paotui#it618_paotui_shop')->update($sid,array(
		'it618_logo' => dhtmlspecialchars($_GET['it618_logo']),
		'it618_hzshopid' => dhtmlspecialchars($_GET['it618_hzshopid']),
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_tel' => dhtmlspecialchars($_GET['it618_tel']),
		'it618_addr' => dhtmlspecialchars($_GET['it618_addr']),
		'it618_bz' => dhtmlspecialchars($_GET['it618_bz']),
		'it618_lbslat' => $it618_lbslat,
		'it618_lbslng' => $it618_lbslng,
		'it618_mappoint' => $it618_mappoint,
		'it618_time' => $_G['timestamp']
	));
	
	it618_paotui_getwapppic($sid,dhtmlspecialchars($_GET['it618_logo']),0);

	it618_cpmsg(it618_paotui_getlang('s165'), "plugin.php?id=it618_paotui:sc_basicdata&sid=$sid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_paotui:sc_basicdata&sid=$sid");
showtableheaders(it618_paotui_getlang('s147'),'it618_paotui_basicdata');

echo '<tr><td width=80>'.it618_paotui_getlang('s148').'</td><td><img id="img1" src="'.$it618_paotui_shop['it618_logo'].'" width="198" height="126" align="absmiddle"/><input type="text" id="url1" name="it618_logo" readonly="readonly" value="'.$it618_paotui_shop['it618_logo'].'"/> <input type="button" id="image1" value="'.it618_paotui_getlang('s149').'" /> <font color=blue>'.it618_paotui_getlang('s156').'</font></td></tr>
<tr><td>'.it618_paotui_getlang('s150').'</td><td><input type="text" class="txt" style="width:400px;color:red;font-weight:bold" id="it618_hzshopid" name="it618_hzshopid" value="'.$it618_paotui_shop['it618_hzshopid'].'"> <font color=red>'.it618_paotui_getlang('s155').'</font></td></tr>
<tr><td>'.it618_paotui_getlang('s151').'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name" value="'.$it618_paotui_shop['it618_name'].'"></td></tr>
<tr><td>'.it618_paotui_getlang('s152').'</td><td><input type="text" class="txt" style="width:400px" id="it618_tel" name="it618_tel" value="'.$it618_paotui_shop['it618_tel'].'"></td></tr>
<tr><td>'.it618_paotui_getlang('s153').'</td><td><input type="text" class="txt" style="width:400px" id="it618_addr" name="it618_addr" value="'.$it618_paotui_shop['it618_addr'].'"></td></tr>
<tr><td>'.it618_paotui_getlang('s154').'</td><td><input type="text" class="txt" style="width:400px" id="it618_bz" name="it618_bz" value="'.$it618_paotui_shop['it618_bz'].'"></td></tr>
';

if($it618_paotui_shop['it618_lbslat']>0){
	$it618_lbs='<br><br>'.$it618_paotui_lang['s882'].'<font color=red>lat:'.$it618_paotui_shop['it618_lbslat'].' lng:'.$it618_paotui_shop['it618_lbslng'].'</font> <font color=#999>'.$it618_paotui_lang['s883'].'</font><br><br>';
}

echo '<tr><td>'.it618_paotui_getlang('s157').'</td><td><iframe width="100%" height="450px" marginwidth="0" marginheight="0"  frameborder="no" scrolling="no"  src="'.$_G['siteurl'].'plugin.php?id=it618_paotui:getpoint&ispc=1&mappoint='.$it618_paotui_shop['it618_mappoint'].'"></iframe><br><font color=red>'.it618_paotui_getlang('s158').'</font><input type="hidden" id="it618_mappoint" name="it618_mappoint" value="'.$it618_paotui_shop['it618_mappoint'].'">
'.$it618_lbs.'
</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_paotui_getlang('s163').'" /></div></td></tr>';

echo '
<link rel="stylesheet" href="source/plugin/it618_paotui/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_paotui/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_paotui/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_paotui/kindeditor/php/upload_json.php?imgwidth=640'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_paotui/kindeditor/php/file_manager_json.php\',
			allowFileManager : true
		});
		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
	});
	
	function checkvalue(){
		if(document.getElementById("it618_logo").value==""){
			alert("'.it618_paotui_getlang('s164').'");
			return false;
		}
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_paotui_getlang('s159').'");
			return false;
		}
		if(document.getElementById("it618_tel").value==""){
			alert("'.it618_paotui_getlang('s160').'");
			return false;
		}
		if(document.getElementById("it618_addr").value==""){
			alert("'.it618_paotui_getlang('s161').'");
			return false;
		}
		if(document.getElementById("it618_mappoint").value==""){
			alert("'.it618_paotui_getlang('s162').'");
			return false;
		}
	}
</script>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/sc_footer.func.php';
?>