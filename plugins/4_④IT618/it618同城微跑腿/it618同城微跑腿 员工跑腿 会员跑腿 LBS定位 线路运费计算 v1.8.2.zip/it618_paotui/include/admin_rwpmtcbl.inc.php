<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_paotui#it618_paotui_rwpmtcbl')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_tcbl'])) {
		foreach($_GET['it618_tcbl'] as $id => $val) {

			C::t('#it618_paotui#it618_paotui_rwpmtcbl')->update($id,array(
				'it618_pj1' => $_GET['it618_pj1'][$id],
				'it618_pj2' => $_GET['it618_pj2'][$id],
				'it618_jdcount' => $_GET['it618_jdcount'][$id],
				'it618_tcbl' => $_GET['it618_tcbl'][$id]
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_pj1_array = !empty($_GET['newit618_pj1']) ? $_GET['newit618_pj1'] : array();
	$newit618_pj2_array = !empty($_GET['newit618_pj2']) ? $_GET['newit618_pj2'] : array();
	$newit618_jdcount_array = !empty($_GET['newit618_jdcount']) ? $_GET['newit618_jdcount'] : array();
	$newit618_tcbl_array = !empty($_GET['newit618_tcbl']) ? $_GET['newit618_tcbl'] : array();
	
	foreach($newit618_pj2_array as $key => $value) {

		C::t('#it618_paotui#it618_paotui_rwpmtcbl')->insert(array(
			'it618_pj1' => $newit618_pj1_array[$key],
			'it618_pj2' => $newit618_pj2_array[$key],
			'it618_jdcount' => $newit618_jdcount_array[$key],
			'it618_tcbl' => $newit618_tcbl_array[$key],
		), true);
		$ok2=$ok2+1;
	}

	cpmsg($it618_paotui_lang['s5'].$ok1.' '.$it618_paotui_lang['s6'].$ok2.' '.$it618_paotui_lang['s7'].$del.')', "action=plugins&identifier=$identifier&cp=admin_rwpmtcbl&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_rwpmtcbl&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_paotui_rwpmtcbl');

	$count = C::t('#it618_paotui#it618_paotui_rwpmtcbl')->count_by_search();
	echo '<tr><td colspan=10>'.$it618_paotui_lang['s342'].$count.'<span style="float:right;color:red">'.$it618_paotui_lang['s343'].'</span></td></tr>';
	
	showsubtitle(array('', $it618_paotui_lang['s339'],$it618_paotui_lang['s338'],$it618_paotui_lang['s340'],$it618_paotui_lang['s341']));
	
	foreach(C::t('#it618_paotui#it618_paotui_rwpmtcbl')->fetch_all_by_search() as $it618_paotui_rwpmtcbl) {

		showtablerow('', array('class="td25"', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_paotui_rwpmtcbl[id]\">",
			'<input class="txt" type="text" style="width:80px;" name="it618_pj1['.$it618_paotui_rwpmtcbl['id'].']" value="'.$it618_paotui_rwpmtcbl['it618_pj1'].'">%',
			'<input class="txt" type="text" style="width:80px;" name="it618_pj2['.$it618_paotui_rwpmtcbl['id'].']" value="'.$it618_paotui_rwpmtcbl['it618_pj2'].'">%',
			'<input class="txt" type="text" style="width:80px;" name="it618_jdcount['.$it618_paotui_rwpmtcbl['id'].']" value="'.$it618_paotui_rwpmtcbl['it618_jdcount'].'">',
			'<input class="txt" type="text" style="width:80px;" name="it618_tcbl['.$it618_paotui_rwpmtcbl['id'].']" value="'.$it618_paotui_rwpmtcbl['it618_tcbl'].'">%'
		));
	}
	
$it618_paotui_lang184=$it618_paotui_lang['s184'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
	
		return [
				[[1,''], [1, ' <input type="text" class="txt" style="width:80px;" name="newit618_pj1[]">%'], [1, ' <input type="text" class="txt" style="width:80px;" name="newit618_pj2[]">%'], [1, ' <input type="text" class="txt" style="width:80px;" name="newit618_jdcount[]">'], [1, ' <input class="txt" style="width:80px" type="text" name="newit618_tcbl[]">%'], [1,'']]
				];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="5"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
    
    echo '<tr><td colspan=10 style="text-align:right;color:green">'.$it618_paotui_lang['s344'].'</span></td></tr>';
    echo '<tr><td colspan=10 style="text-align:right;color:green">'.$it618_paotui_lang['s345'].'</span></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=12)return;
showtablefooter();
?>