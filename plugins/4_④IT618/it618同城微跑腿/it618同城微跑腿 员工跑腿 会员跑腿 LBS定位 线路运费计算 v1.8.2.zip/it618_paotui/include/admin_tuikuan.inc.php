<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

$it618sql='it618_state=6';
$urlsql="&finduid=".$_GET['finduid']."&it618_time1=".$_GET['it618_time1']."&it618_time2=".$_GET['it618_time2'];

if(submitcheck('it618submit_tuikuan')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_paotui_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_paotui_sale')." where id=".$delid);
		
		C::t('#it618_paotui#it618_paotui_sale')->update($delid,array(
			'it618_state' => 7
		));
			
		C::t('common_member_count')->increase($it618_paotui_sale['it618_uid'], array(
			'extcredits'.$it618_paotui['paotui_credit'] => $it618_paotui_sale['it618_score'])
		);
		
		it618_paotui_sendmessage('tk_user',$delid);

		$ok=$ok+1;
	}

	cpmsg($it618_paotui_lang['s910'].$ok, "action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=12)return;

showformheader("plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_paotui_lang['s911'],'it618_paotui_sum');
	showsubmit('it618sercsubmit', $it618_paotui_lang['s912'], '<script charset="utf-8" src="source/plugin/it618_paotui/js/Calendar.js"></script>'.$it618_paotui_lang['s914'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:80px" /> '.$it618_paotui_lang['s919'].' <input name="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input name="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>');
	
	$count = C::t('#it618_paotui#it618_paotui_sale')->count_by_search($it618sql,'',$_GET['finduid'],'', $_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_score',$it618sql,'',$_GET['finduid'],'', $_GET['it618_time1'], $_GET['it618_time2']);
	$sfmoney=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_sfmoney',$it618sql,'',$_GET['finduid'],'', $_GET['it618_time1'], $_GET['it618_time2']);
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=15>'.$it618_paotui_lang['s935'].'<font color=red>'.$count.'</font> '.$it618_paotui_lang['s937'].'<font color=#390>'.$score.'</font> '.$it618_paotui_lang['s936'].'<font color=red>'.$sfmoney.'</font><span style="float:right;color:red">'.$it618_paotui_lang['s939'].'</span></td></tr>';
	
	showsubtitle(array($it618_paotui_lang['s940'],$it618_paotui_lang['s934'],$it618_paotui_lang['s942'],$it618_paotui_lang['s943'],$it618_paotui_lang['s944'],$it618_paotui_lang['s945'],$it618_paotui_lang['s941'],$it618_paotui_lang['s946'],$it618_paotui_lang['s947']));
			
	foreach(C::t('#it618_paotui#it618_paotui_sale')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['finduid'], '',$_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_paotui_sale) {
		
		$paotui_topname=explode(",",$it618_paotui['paotui_topname']);
		$it618_type=$paotui_topname[$it618_paotui_sale['it618_type']-1];

		showtablerow('', array('', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_paotui_sale[id].'" name="delete[]" value="'.$it618_paotui_sale[id].'" '.$disabled.'><label for="chk_del'.$it618_paotui_sale[id].'">'.$it618_paotui_sale['id'].'</label>',
			$it618_type,
			$it618_paotui_sale['it618_yunfei'],
			$it618_paotui_sale['it618_xiaofei'],
			$it618_paotui_sale['it618_scoremoney'],
			'<font color=#390>'.$it618_paotui_sale['it618_score'].'</font>',
			'<font color=red>'.$it618_paotui_sale['it618_sfmoney'].'</font>',
			'<a href="'.it618_paotui_rewriteurl($it618_paotui_sale['it618_uid']).'" target="_blank">'.it618_paotui_getusername($it618_paotui_sale['it618_uid']).'</a>',
			date('Y-m-d H:i:s', $it618_paotui_sale['it618_time'])
		));
	}

	echo '<tr><td width=58><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_paotui_lang['s1133'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_tuikuan" value="'.$it618_paotui_lang['s932'].'" onclick="return confirm(\''.$it618_paotui_lang['s933'].'\')"/><input type=hidden value=1 name=page /></div></td></tr>';

	if(count($reabc)!=12)return;
showtablefooter();
?>