<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

if(submitcheck('it618submit')){
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yytime_isok');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yytime_isok']
	));
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yytime_isokbz');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yytime_isokbz']
	));
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yytime_isoktime');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yytime_isoktime']
	));
	
	
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yunfei_time');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yunfei_time']
	));
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yunfei_timefirst');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yunfei_timefirst']
	));
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yunfei_timeyunfei1');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yunfei_timeyunfei1']
	));
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yunfei_timeyunfei2');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yunfei_timeyunfei2']
	));
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yunfei_first');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yunfei_first']
	));
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yunfei_yunfei1');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yunfei_yunfei1']
	));
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yunfei_yunfei2');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yunfei_yunfei2']
	));
	
	
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('yunfei_xiaofei');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['yunfei_xiaofei']
	));
	
	$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname('scorebl');
	C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
		'setvalue' => $_GET['scorebl']
	));

	cpmsg($it618_paotui_lang['s90'], "action=plugins&identifier=$identifier&cp=admin_yytime&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}


$yytime_isok=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yytime_isok');
if($yytime_isok==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";

$yytime_isokbz=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yytime_isokbz');
$yytime_isoktime=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yytime_isoktime');

$yunfei_time=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_time');
$yunfei_timefirst=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_timefirst');
$yunfei_timeyunfei1=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_timeyunfei1');
$yunfei_timeyunfei2=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_timeyunfei2');
$yunfei_first=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_first');
$yunfei_yunfei1=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_yunfei1');
$yunfei_yunfei2=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_yunfei2');

$yunfei_xiaofei=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('yunfei_xiaofei');

$scorebl=C::t('#it618_paotui#it618_paotui_set')->getsetvalue_by_setname('scorebl');

showformheader("plugins&identifier=$identifier&cp=admin_yytime&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1],'it618_paotui_set');

$homeurl=$_G['siteurl'].it618_paotui_getrewrite('paotui_home','','plugin.php?id=it618_paotui:index');
$saleurl=$_G['siteurl'].'plugin.php?id=it618_paotui:sc_sale_admin';
$salehzurl=$_G['siteurl'].'plugin.php?id=it618_paotui:sc_salehz_admin';
$waphome=$_G['siteurl'].it618_paotui_getrewrite('paotui_wap','','plugin.php?id=it618_paotui:wap');

echo '
<tr><td width=110>'.it618_paotui_getlang('s693').'</td><td><input type="checkbox" id="yytime_isok" name="yytime_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="yytime_isok">'.it618_paotui_getlang('s694').'</label></td></tr>

<tr><td>'.it618_paotui_getlang('s695').'</td><td><input type="text" class="txt" style="width:600px;margin-bottom:3px" name="yytime_isokbz" value="'.$yytime_isokbz.'"><font color=#999>'.it618_paotui_getlang('s696').'</font></td></tr>

<tr><td>'.it618_paotui_getlang('s697').'</td><td><input type="text" class="txt" style="width:300px;margin-bottom:3px;color:blue" name="yytime_isoktime" value="'.$yytime_isoktime.'"><font color=#999>'.it618_paotui_getlang('s698').'</font></td></tr>

<tr><td>'.$it618_paotui_lang['s1221'].'</td><td>
'.$it618_paotui_lang['s29'].'<input type="text" class="txt" style="width:300px;margin-bottom:3px;color:blue" name="yunfei_time" value="'.$yunfei_time.'"><font color=red>'.$it618_paotui_lang['s33'].'</font><br><font color=#999>'.$it618_paotui_lang['s30'].'</font>
<br><br>
'.$it618_paotui_lang['s31'].'
<input type="text" class="txt" style="width:58px;color:blue;margin-right:3px;" name="yunfei_timefirst" value="'.$yunfei_timefirst.'">'.$it618_paotui_lang['s1222'].'<input type="text" class="txt" style="width:58px;color:blue;margin-right:3px;" name="yunfei_timeyunfei1" value="'.$yunfei_timeyunfei1.'">'.$it618_paotui_lang['s1223'].'<input type="text" class="txt" style="width:58px;color:blue;margin-right:3px;" name="yunfei_timeyunfei2" value="'.$yunfei_timeyunfei2.'">'.$it618_paotui_lang['s1224'].'
<br><br>
'.$it618_paotui_lang['s32'].'
<input type="text" class="txt" style="width:58px;color:blue;margin-right:3px;" name="yunfei_first" value="'.$yunfei_first.'">'.$it618_paotui_lang['s1222'].'<input type="text" class="txt" style="width:58px;color:blue;margin-right:3px;" name="yunfei_yunfei1" value="'.$yunfei_yunfei1.'">'.$it618_paotui_lang['s1223'].'<input type="text" class="txt" style="width:58px;color:blue;margin-right:3px;" name="yunfei_yunfei2" value="'.$yunfei_yunfei2.'">'.$it618_paotui_lang['s1224'].'
</td></tr>

<tr><td>'.it618_paotui_getlang('s10').'</td><td><input type="text" class="txt" style="width:300px;margin-bottom:3px;color:blue" name="yunfei_xiaofei" value="'.$yunfei_xiaofei.'"><font color=#999>'.it618_paotui_getlang('s11').'</font></td></tr>

<tr><td>'.$it618_paotui_lang['s100'].'</td><td><input type="text" class="txt" style="width:58px;color:blue;margin-right:3px;" name="scorebl" value="'.$scorebl.'">% <font color=#999>'.$it618_paotui_lang['s99'].'</font></td></tr>
<tr><td>'.$it618_paotui_lang['s641'].'</td><td><a href="'.$homeurl.'" target="_blank">'.$homeurl.'</a> <font color=#999>'.$it618_paotui_lang['s642'].'</font></td></tr>
<tr><td>'.$it618_paotui_lang['s75'].'</td><td><a href="'.$saleurl.'" target="_blank">'.$saleurl.'</a> <font color=#999>'.$it618_paotui_lang['s76'].'</font><br><a href="'.$salehzurl.'" target="_blank">'.$salehzurl.'</a> <font color=#999>'.$it618_paotui_lang['s185'].'</font></td></tr>
<tr><td>'.$it618_paotui_lang['s643'].'</td><td><a href="'.$waphome.'" target="_blank">'.$waphome.'</a></td></tr>
';

showsubmit('it618submit', $it618_paotui_lang['s637']);
if(count($reabc)!=12)return;
showtablefooter();

?>