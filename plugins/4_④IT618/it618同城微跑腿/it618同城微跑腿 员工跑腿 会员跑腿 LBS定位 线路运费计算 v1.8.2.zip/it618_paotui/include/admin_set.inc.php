<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_paotui_set=C::t('#it618_paotui#it618_paotui_set')->fetch_by_setname($setname);

if(submitcheck('it618submit')){
	if(C::t('#it618_paotui#it618_paotui_set')->count_by_setname($setname)==0){
		C::t('#it618_paotui#it618_paotui_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $_GET[$setname]
		), true);
	}else{
		C::t('#it618_paotui#it618_paotui_set')->update($it618_paotui_set['id'],array(
			'setvalue' => $_GET[$setname]
		));
	}

	cpmsg($it618_paotui_lang['s90'], "action=plugins&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1].'<span style="font-weight:normal;color:red;margin-left:90px">'.$it618_paotui_lang['s91'].'</span>','it618_paotui_set');

if($cp1==5){
	$tmpstr='<br>'.$it618_paotui_lang['s628'];
}

echo '
<link rel="stylesheet" href="source/plugin/it618_paotui/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_paotui/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_paotui/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_paotui/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_paotui/kindeditor/plugins/code/prettify.js"></script>

<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="'.$setname.'"]\', {
			cssPath : \'source/plugin/it618_paotui/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_paotui/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_paotui/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>


<tr><td width=800><textarea name="'.$setname.'" style="width:800px;height:400px;visibility:hidden;">'.$it618_paotui_set['setvalue'].'</textarea>'.$tmpstr.'</td><td valign="top"><img src="source/plugin/it618_paotui/images/tip.png"/></td></tr>
';

showsubmit('it618submit', $it618_paotui_lang['s89']);
if(count($reabc)!=12)return;
showtablefooter();

?>