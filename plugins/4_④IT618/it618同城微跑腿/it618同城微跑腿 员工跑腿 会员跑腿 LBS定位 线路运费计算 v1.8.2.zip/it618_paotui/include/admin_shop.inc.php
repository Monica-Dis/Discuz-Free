<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

$it618sql='1';

if($_GET['htstate']) {
	$htstate0='';$htstate1='';$htstate2='';$htstate3='';$htstate4='';
	if($_GET['htstate']==0){$it618sql .= "";$htstate0='selected="selected"';}
	if($_GET['htstate']==1){$it618sql .= " AND it618_htstate = 0";$htstate1='selected="selected"';}
	if($_GET['htstate']==2){$it618sql .= " AND it618_htstate = 1";$htstate2='selected="selected"';}
	if($_GET['htstate']==3){$it618sql .= " AND it618_htstate = 2";$htstate3='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&htstate='.$_GET['htstate'];

foreach(C::t('#it618_paotui#it618_paotui_shop')->fetch_all_by_search("it618_htstate<>0") as $it618_paotui_shop) {
	if($_G['timestamp']>=$it618_paotui_shop['it618_htetime']){
		C::t('#it618_paotui#it618_paotui_shop')->update_it618_htstate_by_id($it618_paotui_shop['id'],2);
	}else{
		C::t('#it618_paotui#it618_paotui_shop')->update_it618_htstate_by_id($it618_paotui_shop['id'],1);
	}
}

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($delid);
		if($it618_paotui_shop['it618_htstate']!=1){
			
			C::t('#it618_paotui#it618_paotui_shop')->delete_by_id($delid);
			$del=$del+1;
		}
	}

	cpmsg($it618_paotui_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if($reabc[8]!='o')return;
	
	if(is_array($_GET['it618_addr'])) {
		foreach($_GET['it618_addr'] as $id => $val) {
		
			C::t('#it618_paotui#it618_paotui_shop')->update($id,array(
				'it618_addr' => $_GET['it618_addr'][$id],
				'it618_bz' => $_GET['it618_bz'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_paotui_lang['s757'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_add')){
	$adduid_arr=explode(",",$_GET['adduids']);
	foreach($adduid_arr as $key => $adduid) {
		$adduid=intval($adduid);
		
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$adduid)==0){
			$msgstr.=$it618_paotui_lang['s139'].$adduid.$it618_paotui_lang['s140'].'<br>';
		}else{
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$adduid);
			
			if(DB::result_first("select count(1) from ".DB::table('it618_paotui_shop')." where it618_uid=".$adduid)>0){
				$msgstr.=$it618_paotui_lang['s139'].$adduid.$it618_paotui_lang['s141'].'('.$username.')'.$it618_paotui_lang['s142'].'<br>';
			}else{
				$id = C::t('#it618_paotui#it618_paotui_shop')->insert(array(
					'it618_uid' => $adduid,
					'it618_htetime' => $_G['timestamp']+($_GET['httime']*3600*30),
					'it618_time' => $_G['timestamp']
				), true);

				if($id>0)$msgstr.=$it618_paotui_lang['s139'].$adduid.$it618_paotui_lang['s141'].'('.$username.')'.$it618_paotui_lang['s143'].'<br>';
			}
		}
	}
	
	cpmsg($msgstr, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_zhuan')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$zhuanuid=intval($_GET['zhuanuid']);
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$zhuanuid)==0){
			cpmsg($it618_paotui_lang['s752'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'error');
		}else{
			if(DB::result_first("select count(1) from ".DB::table('it618_paotui_shop')." where it618_uid=".$zhuanuid)>0){
				cpmsg($it618_paotui_lang['s753'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'error');
			}
		}
		
		$it618_paotui_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_paotui_shop')." where id=".$delid);
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$zhuanuid);
		
		C::t('#it618_paotui#it618_paotui_shop')->update_it618_uid_by_id($delid,$zhuanuid);
		cpmsg($it618_paotui_lang['s754'].$it618_paotui_shop['it618_name'].$it618_paotui_lang['s755'].$username.$it618_paotui_lang['s756'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'succeed');
		break;
	}
}

if(submitcheck('it618submit_editht')){
	$ok=0;
	if($reabc[8]!='o')return;
	$time=mktime(0, 0, 0, $_GET['sel_month'], $_GET['sel_date'], $_GET['sel_year']);
	if($_G['timestamp']>=$time){
		cpmsg($it618_paotui_lang['s367'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'succeed');
	}
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		C::t('#it618_paotui#it618_paotui_shop')->update_it618_htetime_by_id($delid,$time);
		$ok=$ok+1;
	}

	cpmsg($it618_paotui_lang['s310'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_clock')){
	$ok=0;
	if($reabc[8]!='o')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($delid);
		
		if($it618_paotui_shop['it618_htstate']==1){
			C::t('#it618_paotui#it618_paotui_shop')->update_it618_htstate_by_id($delid,0);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_paotui_lang['s311'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_unclock')){
	$ok=0;
	if($reabc[8]!='o')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_paotui_shop=C::t('#it618_paotui#it618_paotui_shop')->fetch_by_id($delid);
		
		if($it618_paotui_shop['it618_htstate']==0){
			C::t('#it618_paotui#it618_paotui_shop')->update_it618_htstate_by_id($delid,1);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_paotui_lang['s312'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=12)return;

showformheader("plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql);
showtableheaders($it618_paotui_lang['s129'].'<span style="float:right"></span>','it618_store_renzheng');
	showsubmit('it618sercsubmit', $it618_paotui_lang['s130'], $it618_paotui_lang['s131'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:100px" /> '.$it618_paotui_lang['s132'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_paotui_lang['s133'].' <select name="htstate"><option value=0 '.$htstate0.'>'.$it618_paotui_lang['s134'].'</option><option value=1 '.$htstate1.'>'.$it618_paotui_lang['s135'].'</option><option value=2 '.$htstate2.'>'.$it618_paotui_lang['s136'].'</option><option value=3 '.$htstate3.'>'.$it618_paotui_lang['s137'].'</option></select>');
	
	$count = C::t('#it618_paotui#it618_paotui_shop')->count_by_search($it618sql,'',$_GET['key'],$_GET['finduid']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql);
	
	echo '<tr><td colspan=18>'.$it618_paotui_lang['s102'].$count.'<span style="float:right;color:red">'.$it618_paotui_lang['s107'].'</span></td></tr>';
	showsubtitle(array('', $it618_paotui_lang['s101'],$it618_paotui_lang['s104']));
	
	foreach(C::t('#it618_paotui#it618_paotui_shop')->fetch_all_by_search(
		$it618sql,'it618_order DESC',$_GET['key'],$_GET['finduid'],$startlimit,$ppp
	) as $it618_paotui_shop) {
		
		$username=C::t('#it618_paotui#it618_paotui_sale')->fetch_username_by_uid($it618_paotui_shop['it618_uid']);
		
		if($it618_paotui_shop['it618_htstate']==0)$it618_htstate='<font color=red>'.$it618_paotui_lang['s135'].'</font>';
		if($it618_paotui_shop['it618_htstate']==1)$it618_htstate='<font color=green>'.$it618_paotui_lang['s136'].'</font>';
		if($it618_paotui_shop['it618_htstate']==2)$it618_htstate='<font color=#ccc>'.$it618_paotui_lang['s137'].'</font>';
		$httime=date('Y-m-d', $it618_paotui_shop['it618_htetime']);
		$shopdatastr='<a href="plugin.php?id=it618_paotui:sc_basicdata&sid='.$it618_paotui_shop[id].'" target="_blank">'.$it618_paotui_lang['s138'].'</a>';
		
		$hzsalestr='';
		if($it618_paotui_shop['it618_hzshopid']!=''){
			$hzsalestr=$it618_paotui_lang['s150'].'<b><font color=red>'.$it618_paotui_shop['it618_hzshopid'].'</font></b> '.$it618_paotui_lang['s108'];
		}
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_paotui_shop[id].'" name="delete[]" value="'.$it618_paotui_shop[id].'" '.$disabled.'><input type="hidden" name="id['.$it618_paotui_shop[id].']" value="'.$it618_paotui_shop[id].'"><label for="chk_del'.$it618_paotui_shop[id].'">'.$it618_paotui_shop['id'].'</label>',
			'<img src="'.$it618_paotui_shop['it618_logo'].'" style="float:left" width="100" height="70"/></a><div style="float:left;width:390px;margin-left:6px;line-height:18px"><b>'.$it618_paotui_shop['it618_name'].'</b><br>'.$hzsalestr.'<br>'.$httime.' / '.$it618_htstate.' / '.$it618_state.' '.$shopdatastr.'<br><a href="home.php?mod=space&uid='.$it618_paotui_shop['it618_uid'].'" target="_blank">'.$username.'(<b>'.$it618_paotui_shop['it618_uid'].'</b>)</a> </span></div>',
			'<input type="text" class="txt" style="width:98px;margin-right:1px;margin-bottom:6px" name="it618_tel['.$it618_paotui_shop[id].']" value="'.$it618_paotui_shop[it618_tel].'">/<input type="text" class="txt" style="width:400px;margin-right:1px;margin-bottom:6px" name="it618_addr['.$it618_paotui_shop[id].']" value="'.$it618_paotui_shop[it618_addr].'"><br><textarea class="txt" style="width:510px;height:35px;" name="it618_bz['.$it618_paotui_shop[id].']">'.$it618_paotui_shop[it618_bz].'</textarea>',
			''
		));
		
	}
	
	$tmptime=date('Y-m-d H:i:s', $_G['timestamp']);
	$timearr=explode(" ",$tmptime);
	$timearr1=explode("-",$timearr[0]);
	$timearr2=explode(":",$timearr[1]);
	//
	$strtmp="";
	for($i=2013;$i<=2050;$i++){
		if($timearr1[0]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_year='<select name="sel_year">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=12;$i++){
		if($timearr1[1]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_month='<select name="sel_month">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=31;$i++){
		if($timearr1[2]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_date='<select name="sel_date">'.$strtmp.'</select>';
	
	function towstr($i){
		if(strlen($i)==1)return "0".$i;else return $i;
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_paotui_lang['s1133'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_paotui_lang['s120'].'" onclick="return confirm(\''.$it618_paotui_lang['s121'].'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_paotui_lang['s122'].'"/> '.$it618_paotui_lang['s112'].' '.$sel_year.$sel_month.$sel_date.'<input type="submit" class="btn" name="it618submit_editht" value="'.$it618_paotui_lang['s113'].'" onclick="return confirm(\''.$it618_paotui_lang['s114'].'\')"/> <input type="submit" class="btn" name="it618submit_clock" value="'.$it618_paotui_lang['s115'].'" onclick="return confirm(\''.$it618_paotui_lang['s116'].'\')"/> <input type="submit" class="btn" name="it618submit_unclock" value="'.$it618_paotui_lang['s117'].'" onclick="return confirm(\''.$it618_paotui_lang['s118'].'\')"/> <font color=red>'.$it618_paotui_lang['s119'].'</font><br>'.$it618_paotui_lang['s146'].' <input type="text" id="adduids" name="adduids" style="width:200px"> '.$it618_paotui_lang['s166'].'<input type="text" id="adduids" name="httime" style="width:30px" value="12"> '.$it618_paotui_lang['s167'].' <input type="submit" class="btn" name="it618submit_add" style="color:green" value="'.$it618_paotui_lang['s109'].'" onclick="return checkadd()"  /> '.$it618_paotui_lang['s110'].' <input type="text" id="zhuanuid" name="zhuanuid" style="width:50px"> <input type="submit" class="btn" name="it618submit_zhuan" value="'.$it618_paotui_lang['s111'].'" onclick="return checkone()"  /> &nbsp;<input type=hidden value=1 name=page /></div></td></tr>';

	if(count($reabc)!=12)return;
showtablefooter();
echo  '<script>
		function checkadd(){
		if(document.getElementById("adduids").value==""){
			alert("'.$it618_paotui_lang['s145'].'");
			document.getElementById("adduids").focus();
			return false;
		}
		return confirm(\''.$it618_paotui_lang['s144'].'\');
		}
		
		function checkone(){
		var inputs = document.getElementsByName("delete[]");
		var checked_counts = 0;
		for(var i=0;i<inputs.length;i++){
			if(inputs[i].checked){
				checked_counts++;
			}
		}
		if(checked_counts==0){
			alert("'.$it618_paotui_lang['s125'].'");
			return false;
		}
		if(checked_counts>1){
			alert("'.$it618_paotui_lang['s126'].'");
			return false;
		}
		if(document.getElementById("zhuanuid").value==""){
			alert("'.$it618_paotui_lang['s127'].'");
			return false;
		}
		return confirm(\''.$it618_paotui_lang['s128'].'\');
		}
		</script>';
echo '<script>'.$tmpjs.'</script>';
?>