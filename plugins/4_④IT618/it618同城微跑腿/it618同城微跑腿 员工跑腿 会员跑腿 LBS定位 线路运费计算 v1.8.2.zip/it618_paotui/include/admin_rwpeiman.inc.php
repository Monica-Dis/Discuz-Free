<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/function.func.php';

$it618sql='1';

if($_GET['state']) {
	$state0='';$state1='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$it618sql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$it618sql .= " AND it618_state = 0";$state1='selected="selected"';}
	if($_GET['state']==2){$it618sql .= " AND it618_state = 1";$state2='selected="selected"';}
	if($_GET['state']==3){$it618sql .= " AND it618_state = 2";$state3='selected="selected"';}
	if($_GET['state']==4){$it618sql .= " AND it618_state = 2 AND it618_clockstate = 1";$state4='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&state='.$_GET['state'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($delid);
		if($it618_paotui_rwpeiman['it618_state']!=2){
			
			C::t('#it618_paotui#it618_paotui_rwpeiman')->delete_by_id($delid);
			$del=$del+1;
		}
	}

	cpmsg($it618_paotui_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($delid);
		
		if($it618_paotui_rwpeiman['it618_state']==0){
			C::t('#it618_paotui#it618_paotui_rwpeiman')->update_it618_state_by_id($delid,2);
			it618_paotui_sendmessage('sqpm_user',$id);
			$ok=$ok+1;
		}
	}
	
	cpmsg($it618_paotui_lang['s322'].$ok, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($delid);
		
		if($it618_paotui_rwpeiman['it618_state']==0){
			C::t('#it618_paotui#it618_paotui_rwpeiman')->update_it618_state_by_id($delid,1);
			it618_paotui_sendmessage('sqpm_user',$id);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_paotui_lang['s323'].$ok, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_clock')){
	$ok=0;
	if($reabc[8]!='o')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($delid);
		
		if($it618_paotui_rwpeiman['it618_state']==2&&$it618_paotui_rwpeiman['it618_clockstate']==0){
			C::t('#it618_paotui#it618_paotui_rwpeiman')->update_it618_clockstate_by_id($delid,1);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_paotui_lang['s311'].$ok, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_unclock')){
	$ok=0;
	if($reabc[8]!='o')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_paotui_rwpeiman=C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_by_id($delid);
		
		if($it618_paotui_rwpeiman['it618_state']==2&&$it618_paotui_rwpeiman['it618_clockstate']==1){
			C::t('#it618_paotui#it618_paotui_rwpeiman')->update_it618_clockstate_by_id($delid,0);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_paotui_lang['s312'].$ok, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=12)return;

echo '
<style>table tr td{line-height:18px}</style>
';

showformheader("plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql);
showtableheaders($it618_paotui_lang['s1613'].'<span style="float:right"></span>','it618_paotui_rwpeiman');
	showsubmit('it618sercsubmit', $it618_paotui_lang['s130'], $it618_paotui_lang['s131'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.$it618_paotui_lang['s132'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_paotui_lang['s313'].' <select name="state"><option value=0 '.$state0.'>'.$it618_paotui_lang['s314'].'</option><option value=1 '.$state1.'>'.$it618_paotui_lang['s315'].'</option><option value=2 '.$state2.'>'.$it618_paotui_lang['s316'].'</option><option value=3 '.$state3.'>'.$it618_paotui_lang['s317'].'</option><option value=4 '.$state4.'>'.$it618_paotui_lang['s318'].'</option></select>');
	
	$count = C::t('#it618_paotui#it618_paotui_rwpeiman')->count_by_search($it618sql,'',$_GET['key'],$_GET['finduid']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql);
	
	echo '<tr><td colspan=18>'.$it618_paotui_lang['s1607'].$count.'<span style="float:right;color:red">'.$it618_paotui_lang['s1634'].'</span></td></tr>';
	showsubtitle(array('', $it618_paotui_lang['s1610'],$creditname,$it618_paotui_lang['s1611'],$it618_paotui_lang['s1616'],$it618_paotui_lang['s1612']));
	
	foreach(C::t('#it618_paotui#it618_paotui_rwpeiman')->fetch_all_by_search(
		$it618sql,'id DESC',$_GET['key'],$_GET['finduid'],$startlimit,$ppp
	) as $it618_paotui_rwpeiman) {
		
		$username=C::t('#it618_paotui#it618_paotui_sale')->fetch_username_by_uid($it618_paotui_rwpeiman['it618_uid']);
		$creditnum=C::t('#it618_paotui#it618_paotui_sale')->fetch_extcredits_by_uid($it618_paotui['paotui_credit'],$it618_paotui_rwpeiman['it618_uid']);
		if($creditnum=="")$creditnum=0;
		
		$sumstr='';
		if($it618_paotui_rwpeiman['it618_state']==2){
			$sumstr=$it618_paotui_lang['s321'];
			$count1 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_state=3 and it618_rwpmid='.$it618_paotui_rwpeiman['id']);
			$sum1=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei','it618_state=3 and it618_rwpmid='.$it618_paotui_rwpeiman['id']);
			$count2 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_state=31 and it618_rwpmid='.$it618_paotui_rwpeiman['id']);
			$sum2=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei','it618_state=31 and it618_rwpmid='.$it618_paotui_rwpeiman['id']);
			$count3 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_state=4 and it618_rwpmid='.$it618_paotui_rwpeiman['id']);
			$sum3=C::t('#it618_paotui#it618_paotui_sale')->sum_by_search('it618_yunfei','it618_state=4 and it618_rwpmid='.$it618_paotui_rwpeiman['id']);
	
			$sumstr=str_replace("{count1}",$count1,$sumstr);
			$sumstr=str_replace("{sum1}",$sum1,$sumstr);
			$sumstr=str_replace("{count2}",$count2,$sumstr);
			$sumstr=str_replace("{sum2}",$sum2,$sumstr);
			$sumstr=str_replace("{count3}",$count3,$sumstr);
			$sumstr=str_replace("{sum3}",$sum3,$sumstr);
			
			$pjcount1 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_pj=1 and it618_rwpmid='.$it618_paotui_rwpeiman['id']);
			$pjcount2 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_pj=2 and it618_rwpmid='.$it618_paotui_rwpeiman['id']);
			$pjcount3 = C::t('#it618_paotui#it618_paotui_sale')->count_by_search('it618_pj=3 and it618_rwpmid='.$it618_paotui_rwpeiman['id']);
			$allpjcount=$pjcount1+$pjcount2+$pjcount3;
			if($allpjcount==0){
				$pjtmp1=0;$pjtmp2=0;$pjtmp3=0;
			}else{
				$pjtmp1=$pjcount1/$allpjcount*100;
				$pjtmp2=$pjcount2/$allpjcount*100;
				$pjtmp3=$pjcount3/$allpjcount*100;
			}
			
			$sumstr=str_replace("{pj1}",round($pjtmp1,2),$sumstr);
			$sumstr=str_replace("{pj2}",round($pjtmp2,2),$sumstr);
			$sumstr=str_replace("{pj3}",round($pjtmp3,2),$sumstr);
			$sumstr=str_replace("{pjcount}",$allpjcount,$sumstr);
			
			$it618_paotui_rwpmtcbl=C::t('#it618_paotui#it618_paotui_rwpmtcbl')->fetch_by_pj($pjtmp1);
			$sumstr=str_replace("{jdcount}",$it618_paotui_rwpmtcbl['it618_jdcount'],$sumstr);
			$sumstr=str_replace("{tcbl}",$it618_paotui_rwpmtcbl['it618_tcbl'],$sumstr);
		}
		
		if($it618_paotui_rwpeiman['it618_state']==0)$it618_state='<font color=red>'.$it618_paotui_lang['s315'].'</font>';
		if($it618_paotui_rwpeiman['it618_state']==1)$it618_state='<font color=blue>'.$it618_paotui_lang['s316'].'</font>';
		if($it618_paotui_rwpeiman['it618_state']==2)$it618_state='<font color=green>'.$it618_paotui_lang['s320'].'</font>';
		if($it618_paotui_rwpeiman['it618_clockstate']==1)$it618_state.='<br><font color=red>'.$it618_paotui_lang['s319'].'</font>';
		
		$it618_liyou=str_replace("'","\"",$it618_paotui_rwpeiman['it618_liyou']);
		$it618_liyou=str_replace(array("\r\n", "\r", "\n"),"",$it618_liyou);
		
		$peimanstr=$it618_paotui_lang['s212'];
		$peimanstr=str_replace("{name}",$it618_paotui_rwpeiman['it618_name'],$peimanstr);
		$peimanstr=str_replace("{tel}",$it618_paotui_rwpeiman['it618_tel'],$peimanstr);
		$peimanstr=str_replace("{wx}",$it618_paotui_rwpeiman['it618_wx'],$peimanstr);
		if($it618_paotui_rwpeiman['it618_qq']!=''){
		$qqstr=' <a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$it618_paotui_rwpeiman['it618_qq'].'&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:'.$it618_paotui_rwpeiman['it618_qq'].':52" align="absmiddle"/></a>';	
	}
		$peimanstr=str_replace("{qq}",$qqstr,$peimanstr);
		$peimanstr=str_replace("{addr}",$it618_paotui_rwpeiman['it618_addr'],$peimanstr);
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_paotui_rwpeiman[id].'" name="delete[]" value="'.$it618_paotui_rwpeiman[id].'" '.$disabled.'><input type="hidden" name="id['.$it618_paotui_rwpeiman[id].']" value="'.$it618_paotui_rwpeiman[id].'"><label for="chk_del'.$it618_paotui_rwpeiman[id].'">'.$it618_paotui_rwpeiman['id'].'</label>',
			'<a href="home.php?mod=space&uid='.$it618_paotui_rwpeiman['it618_uid'].'" target="_blank">'.$username.'(<b>'.$it618_paotui_rwpeiman['it618_uid'].'</b>)</a>',
			'<font color="green"><b>'.$creditnum.'</b></font>',
			$peimanstr.' <a href="javascript:" onclick="alert(\''.$it618_liyou.'\n'.date('Y-m-d H:i:s', $it618_paotui_rwpeiman['it618_rztime']).'\')">'.$it618_paotui_lang['s1615'].'</a>',
			$sumstr,
			$it618_state,
		));
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_paotui_lang['s1133'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_paotui_lang['s1871'].'" onclick="return confirm(\''.$it618_paotui_lang['s1872'].'\')" /> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_paotui_lang['s1873'].'" onclick="return confirm(\''.$it618_paotui_lang['s1874'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_paotui_lang['s1875'].'" onclick="return confirm(\''.$it618_paotui_lang['s1876'].'\')"/> <input type="submit" class="btn" name="it618submit_clock" value="'.$it618_paotui_lang['s1884'].'" onclick="return confirm(\''.$it618_paotui_lang['s1885'].'\')"/> <input type="submit" class="btn" name="it618submit_unclock" value="'.$it618_paotui_lang['s1886'].'" onclick="return confirm(\''.$it618_paotui_lang['s1887'].'\')"/><br>'.$it618_paotui_lang['s1614'].' <font color=red>'.$it618_paotui_lang['s1878'].'</font> &nbsp;<input type=hidden value=1 name=page /></div></td></tr>';

	if(count($reabc)!=12)return;
showtablefooter();
?>