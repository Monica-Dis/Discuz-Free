<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_paotui/rewrite.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_paotui/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$paotui_home=\''.'paotui'."';\n";
		$fileData .= '$paotui_wap=\''.'paotui_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$paotui_home1=\''.$urltype."';\n";
		$fileData .= '$paotui_wap1=\'-{pagetype}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_paotui/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_paotui/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$paotui_home=\''.str_replace("-","",$_GET['paotui_home'])."';\n";
		$fileData .= '$paotui_wap=\''.str_replace("-","",$_GET['paotui_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$paotui_home1=\''.$urltype."';\n";
		$fileData .= '$paotui_wap1=\'-{pagetype}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_paotui_lang['s90'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_paotui_lang['s600'].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_paotui_lang['s601'].'</td></tr>
<tr><td colspan="3">'.$it618_paotui_lang['s602'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_paotui_lang['s603'].'</th><th>'.$it618_paotui_lang['s604'].'</th><th>'.$it618_paotui_lang['s605'].'</th></tr>
<tr class="hover">
<td>'.$it618_paotui_lang['s606'].'</td><td></td><td class="longtxt"><input name="paotui_home" value="'.$paotui_home.'"/>'.$paotui_home.$paotui_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_paotui_lang['s607'].'</td><td>{pagetype}, {cid}, {page}</td><td class="longtxt"><input name="paotui_wap" value="'.$paotui_wap.'"/>'.$paotui_wap.$paotui_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_paotui_lang['s89']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_paotui_lang['s622'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$paotui_home.$urltype.'$ $1/plugin.php?id=it618_paotui:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$paotui_wap.$urltype.'$ $1/plugin.php?id=it618_paotui:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$paotui_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_paotui:wap&pagetype=$2&cid=$3&page=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$paotui_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_paotui:wap&pagetype=$2&cid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$paotui_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_paotui:wap&pagetype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_paotui_lang['s623'].'</h1>
<pre class="colorbox">
'.$it618_paotui_lang['s624'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$paotui_home.$urltype.'$ plugin.php?id=it618_paotui:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$paotui_wap.$urltype.'$ plugin.php?id=it618_paotui:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$paotui_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_paotui:wap&pagetype=$1&cid=$2&page=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$paotui_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_paotui:wap&pagetype=$1&cid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$paotui_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_paotui:wap&pagetype=$1&%1</font>

</pre>

<h1>'.$it618_paotui_lang['s625'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$paotui_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_paotui:index&$3
RewriteRule ^(.*)/'.$paotui_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_paotui:wap&$3
RewriteRule ^(.*)/'.$paotui_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_paotui:wap&pagetype=$2&cid=$3&page=$4&$6
RewriteRule ^(.*)/'.$paotui_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_paotui:wap&pagetype=$2&cid=$3&$5
RewriteRule ^(.*)/'.$paotui_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_paotui:wap&pagetype=$2&$4</font>

</pre>

<h1>'.$it618_paotui_lang['s626'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="paotui_home"&gt;
			&lt;match url="^(.*/)*'.$paotui_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_paotui:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="paotui_wap"&gt;
			&lt;match url="^(.*/)*'.$paotui_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_paotui:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="paotui_wap1"&gt;
			&lt;match url="^(.*/)*'.$paotui_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_paotui:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;page={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="paotui_wap2"&gt;
			&lt;match url="^(.*/)*'.$paotui_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_paotui:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="paotui_wap3"&gt;
			&lt;match url="^(.*/)*'.$paotui_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_paotui:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$paotui_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_paotui:index&$2
endif
match URL into $ with ^(.*)/'.$paotui_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_paotui:wap&$2
endif
match URL into $ with ^(.*)/'.$paotui_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_paotui:wap&pagetype=$2&cid=$3&page=$4&$5
endif
match URL into $ with ^(.*)/'.$paotui_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_paotui:wap&pagetype=$2&cid=$3&$4
endif
match URL into $ with ^(.*)/'.$paotui_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_paotui:wap&pagetype=$2&$3
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$paotui_home.$urltype.'$ $1/plugin.php?id=it618_paotui:index&$2 last;
rewrite ^([^\.]*)/'.$paotui_wap.$urltype.'$ $1/plugin.php?id=it618_paotui:wap&$2 last;
rewrite ^([^\.]*)/'.$paotui_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_paotui:wap&pagetype=$2&cid=$3&page=$4&$5 last;
rewrite ^([^\.]*)/'.$paotui_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_paotui:wap&pagetype=$2&cid=$3&$4 last;
rewrite ^([^\.]*)/'.$paotui_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_paotui:wap&pagetype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=15)return;
showtablefooter();

?>