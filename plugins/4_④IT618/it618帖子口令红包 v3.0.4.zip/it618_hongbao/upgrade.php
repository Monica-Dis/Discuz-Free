<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_hongbao_ph` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_postcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_getcount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_hongbao_main'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_main')." add `it618_type` varchar(50) NOT NULL DEFAULT 'tie';"; 
	DB::query($sql);
}
if(!in_array('it618_codetype', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_main')." add `it618_codetype` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_timecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_main')." add `it618_timecount` int(10) unsigned NOT NULL"; 
	DB::query($sql);  
}
if(!in_array('it618_time', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_main')." add `it618_time` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_views', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_main')." add `it618_views` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_hongbao_main')." modify column `it618_money` float(9,2) NOT NULL;"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_hongbao_item')." modify column `it618_money` float(9,2) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_about', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_main')." add `it618_about` varchar(100) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_islock', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_main')." add `it618_islock` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_istie', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_main')." add `it618_istie` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_hongbao_item'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_item')." add `it618_type` varchar(50) NOT NULL DEFAULT 'tie';"; 
	DB::query($sql);
}
if(!in_array('it618_mid', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_item')." add `it618_mid` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_hongbao_item'));
	while($it618_hongbao_item = DB::fetch($query)) {
		$it618_mid=DB::result_first("SELECT id FROM ".DB::table('it618_hongbao_main')." WHERE it618_type='tie' and it618_tid=".$it618_hongbao_item['it618_tid']);
		$sql = "update ".DB::table('it618_hongbao_item')." set it618_mid=$it618_mid where id=".$it618_hongbao_item['id']; 
		DB::query($sql);
	}
}

if(!in_array('it618_isok', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_item')." add `it618_isok` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_hongbao_main')." where it618_isrand=1");
	while($it618_hongbao_main = DB::fetch($query)) {
		$id=DB::result_first("SELECT id FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']." order by it618_money desc,id desc");
		if($id>0)DB::query("update ".DB::table('it618_hongbao_item')." set it618_isok=1 where id=".$id);
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_hongbao_work'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_hongbao_work')." add `it618_type` varchar(50) NOT NULL DEFAULT 'tie';"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vaW5zdGFsbC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vdXBncmFkZS5waHA='));
?>