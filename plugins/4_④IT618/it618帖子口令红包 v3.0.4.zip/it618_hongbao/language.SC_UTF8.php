<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_hongbao_lang;

function it618_hongbao_getlang($langid){
	global $it618_hongbao_lang;
	return $it618_hongbao_lang[$langid];
}

$it618_hongbao_lang['version']='v3.0.4';
$it618_hongbao_lang['s1'] = '抱歉，请先登录！';
$it618_hongbao_lang['s2'] = '抱歉，参数有误！';
$it618_hongbao_lang['s3'] = '抱歉，我现有的';
$it618_hongbao_lang['s4'] = '数量只有';
$it618_hongbao_lang['s5'] = '，不够用来发红包！';
$it618_hongbao_lang['s6'] = '抱歉，如果是普通红包，金额类型为积分时，红包单价（红包金额/红包个数）必须为整数！';
$it618_hongbao_lang['s7'] = '抱歉，红包单价（红包金额/红包个数）必须是大于';
$it618_hongbao_lang['s8'] = '的数值！';
$it618_hongbao_lang['s9'] = '抱歉，您所在用户组没有领红包权限！';
$it618_hongbao_lang['s10'] = '抱歉，红包已领完！';
$it618_hongbao_lang['s11'] = '抱歉，您已领过一次本期红包了，每期红包每个会员只能领一次！';
$it618_hongbao_lang['s12'] = '抱歉，此红包是回帖口令红包，领红包前，需要您在本帖子回复，并且回复内容必须包含口令内容！';
$it618_hongbao_lang['s13'] = '恭喜您，领到了一个 ';
$it618_hongbao_lang['s14'] = ' 的红包！';
$it618_hongbao_lang['s15'] = '拼手气';
$it618_hongbao_lang['s16'] = '普通';
$it618_hongbao_lang['s17'] = '红包个数：';
$it618_hongbao_lang['s18'] = '红包类型：';
$it618_hongbao_lang['it618'] = 'i11iiiilll1ililllilill1ilililililiililililil1ililiililil11ilililililililiilili111ililili11111111111iiiilil1111111il111lilii111ill';
$it618_hongbao_lang['s19'] = '红包均价：';
$it618_hongbao_lang['s20'] = '红包口令：';
$it618_hongbao_lang['s21'] = '类型：';
$it618_hongbao_lang['s22'] = '领到了一个价值';
$it618_hongbao_lang['s23'] = '的红包';
$it618_hongbao_lang['s24'] = '领到了一个';
$it618_hongbao_lang['s25'] = '记录数：';
$it618_hongbao_lang['s26'] = '上一页';
$it618_hongbao_lang['s27'] = '下一页';
$it618_hongbao_lang['s28'] = '抱歉，这些主题(主题编号：';
$it618_hongbao_lang['s29'] = ')有红包不能删除！可以先在后台删除红包，再删除主题。';
$it618_hongbao_lang['s30'] = '抱歉，此主题有红包不能删除！';
$it618_hongbao_lang['s31'] = '红包';
$it618_hongbao_lang['s32'] = '余额：';
$it618_hongbao_lang['s33'] = '还有';
$it618_hongbao_lang['s34'] = '个';
$it618_hongbao_lang['s35'] = '修改红包';
$it618_hongbao_lang['s36'] = '发红包';
$it618_hongbao_lang['s37'] = '抱歉，您所在的用户组没有发红包的权限！';
$it618_hongbao_lang['s38'] = '抱歉，此帖子已发红包了，请刷新页面修改红包！';
$it618_hongbao_lang['s39'] = '添加金额：';
$it618_hongbao_lang['s40'] = '我现有';
$it618_hongbao_lang['s41'] = '剩余金额：';
$it618_hongbao_lang['s42'] = '剩余个数：';
$it618_hongbao_lang['s43'] = '红包金额：';
$it618_hongbao_lang['s44'] = '红包个数：';
$it618_hongbao_lang['s45'] = '添加个数：';
$it618_hongbao_lang['s46'] = '拼手气';
$it618_hongbao_lang['s47'] = '普通';
$it618_hongbao_lang['s48'] = '提示：如果是拼手气红包金额是随机的';
$it618_hongbao_lang['s49'] = '抱歉，红包金额不能小于';
$it618_hongbao_lang['s50'] = '抱歉，红包金额不能大于';
$it618_hongbao_lang['s51'] = '天前';
$it618_hongbao_lang['s52'] = '小时前';
$it618_hongbao_lang['s53'] = '分钟前';
$it618_hongbao_lang['s54'] = '秒前';
$it618_hongbao_lang['s55'] = '';
$it618_hongbao_lang['s56'] = '删除红包';
$it618_hongbao_lang['s57'] = '抱歉，您没有删除红包的权限！';
$it618_hongbao_lang['s58'] = '红包删除成功！';
$it618_hongbao_lang['s59'] = '抱歉，领红包前，请先输入红包口令！';
$it618_hongbao_lang['s60'] = '口令';
$it618_hongbao_lang['s61'] = '已有';
$it618_hongbao_lang['s62'] = '个会员领到了红包';
$it618_hongbao_lang['s63'] = '抱歉，您的钱包余额不够！';
$it618_hongbao_lang['s64'] = '抱歉，当前版块没有发红包的权限！';
$it618_hongbao_lang['s65'] = '';
$it618_hongbao_lang['s66'] = '抱歉，请在此帖子红包领完或限领时间达到时再发下期红包！';
$it618_hongbao_lang['s67'] = '抱歉，此帖子还没有红包！';
$it618_hongbao_lang['s68'] = '领到一个{money}元红包';
$it618_hongbao_lang['s69'] = '元';
$it618_hongbao_lang['s70'] = '余额';
$it618_hongbao_lang['s71'] = '';
$it618_hongbao_lang['s72'] = '回帖口令';
$it618_hongbao_lang['s73'] = '芝麻口令';
$it618_hongbao_lang['s74'] = '发了一个{money}元红包';
$it618_hongbao_lang['s75'] = '';
$it618_hongbao_lang['s76'] = '不需要口令，直接领红包';
$it618_hongbao_lang['s77'] = '您已经领了本期红包';
$it618_hongbao_lang['s78'] = '点击领红包';
$it618_hongbao_lang['s79'] = '本期红包已领完';
$it618_hongbao_lang['s80'] = '再发下期红包';
$it618_hongbao_lang['s81'] = '红包退还{money}元';
$it618_hongbao_lang['s82'] = '现在是否到钱包充值？';
$it618_hongbao_lang['s83'] = '抱歉，您不是此红包主人！';
$it618_hongbao_lang['s84'] = '抱歉，本期红包已领完，不能再管理了，您可以直接发下期红包！';
$it618_hongbao_lang['s85'] = '还有';
$it618_hongbao_lang['s86'] = '修改红包再添加{money}元';
$it618_hongbao_lang['s87'] = '红包更新成功并解锁！';
$it618_hongbao_lang['s88'] = '抱歉，红包已锁定，红包主人正在修改红包，请稍后再领红包！';
$it618_hongbao_lang['s89'] = '手气王';
$it618_hongbao_lang['s90'] = '红包口令：';
$it618_hongbao_lang['s91'] = '提示：领红包前请确定您的回帖内容包含红包口令';


//it618_hongbao_lang(\d+)} it618_hongbao_lang['t$1']}
$it618_hongbao_lang['t1'] = '红包口令：';
$it618_hongbao_lang['t2'] = '提示：限领时间截止时自动归还剩余红包金额！';
$it618_hongbao_lang['t3'] = '发红包';
$it618_hongbao_lang['t4'] = '塞钱';
$it618_hongbao_lang['t5'] = '抱歉，红包金额必须为整数！';
$it618_hongbao_lang['t6'] = '抱歉，红包个数必须为大于0的整数！';
$it618_hongbao_lang['t7'] = '您的帖子回复内容还没有包含以上口令！';
$it618_hongbao_lang['t8'] = '确定要给红包塞钱？';
$it618_hongbao_lang['t9'] = '钱包';
$it618_hongbao_lang['t10'] = '发红包成功！';
$it618_hongbao_lang['t11'] = '您的帖子回复内容已包含以上口令！';
$it618_hongbao_lang['t12'] = '修改红包';
$it618_hongbao_lang['t13'] = '还有';
$it618_hongbao_lang['t14'] = '抱歉，限领时间必须为大于12的整数！';
$it618_hongbao_lang['t15'] = '限领时间：';
$it618_hongbao_lang['t16'] = '小时';
$it618_hongbao_lang['t17'] = '确定要删除此红包吗，此操作不可逆？删除后自动归还红包剩余金额，同时领红包记录也会删除！';
$it618_hongbao_lang['t18'] = '上次修改时间：';
$it618_hongbao_lang['t19'] = '已有';
$it618_hongbao_lang['t20'] = '现在发帖时发红包';
$it618_hongbao_lang['t21'] = '需要时再在帖子内发红包';
$it618_hongbao_lang['t22'] = '关闭';
$it618_hongbao_lang['t23'] = '抱歉，请发红包后再看红包详情！';
$it618_hongbao_lang['t24'] = '抱歉，红包金额必须大于0！';
$it618_hongbao_lang['t25'] = '说明：红包领完或限领时间截止后，可以发下期红包，<font color=#390>回帖口令：领红包前必须先回帖，帖子的回复需要包含口令内容，芝麻口令：直接在红包界面输入口令再点领红包</font>';
$it618_hongbao_lang['t28'] = '天';
$it618_hongbao_lang['t29'] = '时';
$it618_hongbao_lang['t30'] = '分';
$it618_hongbao_lang['t31'] = '秒';
$it618_hongbao_lang['t32'] = '红包详情';
$it618_hongbao_lang['t33'] = '我发的';
$it618_hongbao_lang['t34'] = '我领的';
$it618_hongbao_lang['t35'] = '全部发';
$it618_hongbao_lang['t36'] = '全部领';
$it618_hongbao_lang['t37'] = '期数';
$it618_hongbao_lang['t38'] = '会员';
$it618_hongbao_lang['t39'] = '金额';
$it618_hongbao_lang['t40'] = '时间';
$it618_hongbao_lang['t41'] = '红包主人:';
$it618_hongbao_lang['t42'] = '第';
$it618_hongbao_lang['t43'] = '期';
$it618_hongbao_lang['t44'] = '红包类型：';
$it618_hongbao_lang['t45'] = '红包个数：';
$it618_hongbao_lang['t46'] = '红包金额：';
$it618_hongbao_lang['t47'] = '剩余时间：';
$it618_hongbao_lang['t48'] = '红包口令：';
$it618_hongbao_lang['t49'] = '红包信息';
$it618_hongbao_lang['t50'] = '发红包时间';
$it618_hongbao_lang['t51'] = '领红包时间';
$it618_hongbao_lang['t52'] = '添加金额：';
$it618_hongbao_lang['t53'] = '添加个数：';
$it618_hongbao_lang['t54'] = '添加时间：';
$it618_hongbao_lang['t55'] = '说明：<font color=blue>在修改红包时会锁定红包的，锁定时不能领红包，更新后会解锁的</font>，数量只能在以前基础上添加，是不能减少的，如果为0表示不修改';
$it618_hongbao_lang['t56'] = '红包说明：';
$it618_hongbao_lang['t57'] = '更新并解锁';
$it618_hongbao_lang['t58'] = '确定要更新红包？更新后红包自动解锁！';
$it618_hongbao_lang['t59'] = '确定要修改红包？点击“确定”会锁定红包的，锁定时不能领红包，更新后会解锁的！';
$it618_hongbao_lang['t60'] = '本期还有';
$it618_hongbao_lang['t61'] = '个红包';
$it618_hongbao_lang['t62'] = '显示：';
$it618_hongbao_lang['t63'] = '帖内+图标';
$it618_hongbao_lang['t64'] = '仅帖内显示';
$it618_hongbao_lang['t65'] = '仅图标显示';

?>