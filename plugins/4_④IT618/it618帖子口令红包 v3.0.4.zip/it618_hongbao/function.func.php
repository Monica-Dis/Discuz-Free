<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_hongbao;

$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';

$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_it618_hongbao.php';
if(($_G['timestamp'] - @filemtime($cache_file)) > 600) {
	require_once libfile('function/cache');
	$contents[]='';
	$cacheArray .= "\$contents=".arrayeval($contents).";\n";
	writetocache('it618_hongbao', $cacheArray);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_hongbao_main')." WHERE it618_state=1");
	while($it618_hongbao_main = DB::fetch($query)) {
		hbtimeout($it618_hongbao_main);
	}
}

function gethbauthorid($type,$tid){
	global $_G;
	
	if($type=='it618_video_admin'){
		$it618_video = $_G['cache']['plugin']['it618_video'];
		$shopadmin=explode(",",$it618_video['video_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_video_shop'){
		$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_id($tid);
		if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_exam_admin'){
		$it618_exam = $_G['cache']['plugin']['it618_exam'];
		$shopadmin=explode(",",$it618_exam['exam_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_exam_shop'){
		$shoptmp=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($tid);
		if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_brand_admin'){
		$it618_brand = $_G['cache']['plugin']['it618_brand'];
		$shopadmin=explode(",",$it618_brand['brand_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_brand_shop'){
		$shoptmp=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($tid);
		if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_tuan_admin'){
		$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
		$shopadmin=explode(",",$it618_tuan['tuan_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_tuan_shop'){
		$shoptmp=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($tid);
		if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_waimai_admin'){
		$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
		$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_waimai_shop'){
		$shoptmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($tid);
		if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
			$authorid=$_G['uid'];
		}
	}
	
	if($type=='it618_credits'){
		$it618_credits = $_G['cache']['plugin']['it618_credits'];
		if($_G['uid']==$it618_credits['credits_wapsalepower']){
			$authorid=$_G['uid'];
		}
	}
	
	return $authorid;
}

function gethbshopname($type,$tid){
	if($type=='it618_video_shop'){
		$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_id($tid);
		$shopname=$shoptmp['it618_name'];
	}
	
	if($type=='it618_exam_shop'){
		$shoptmp=C::t('#it618_exam#it618_exam_shop')->fetch_by_id($tid);
		$shopname=$shoptmp['it618_name'];
	}
	
	if($type=='it618_brand_shop'){
		$shoptmp=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($tid);
		$shopname=$shoptmp['it618_name'];
	}
	
	if($type=='it618_tuan_shop'){
		$shoptmp=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_id($tid);
		$shopname=$shoptmp['it618_name'];
	}
	
	if($type=='it618_waimai_shop'){
		$shoptmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($tid);
		$shopname=$shoptmp['it618_name'];
	}
	
	return $shopname;
}

function hbtimeout($it618_hongbao_main){
	global $_G,$it618_hongbao_lang;
	$timecount=($_G['timestamp']-$it618_hongbao_main['it618_time'])/3600;
	if($timecount>$it618_hongbao_main['it618_timecount']){
		
		$count=$it618_hongbao_main['it618_count'];
		$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$count1=$count-$count2;
		
		$money=$it618_hongbao_main['it618_money'];
		$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$money1=$it618_hongbao_main['it618_money']-$moneytmp;
		
		C::t('#it618_hongbao#it618_hongbao_main')->update($it618_hongbao_main["id"],array(
			'it618_count' => $count2,
			'it618_money' => $moneytmp,
			'it618_state' => 0
		));
		
		if($it618_hongbao_main['it618_jfid']>0){
			C::t('common_member_count')->increase($it618_hongbao_main['it618_uid'], array(
				'extcredits'.$it618_hongbao_main['it618_jfid'] => $money1)
			);
		}else{
			if($money1>0){
				$it618_bz=$it618_hongbao_lang['s81'];
				$it618_bz=str_replace("{money}",$money1,$it618_bz);
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
				savemoney(array(
					'it618_uid' => $it618_hongbao_main['it618_uid'],
					'it618_type' => 'zy',
					'it618_money1' => $money1,
					'it618_bz' => $it618_bz,
					'it618_zytype' => 'it618_hongbao_tk',
					'it618_zyid' => $it618_hongbao_main["id"],
					'it618_time' => $_G['timestamp']
				));
			}
		}
	}	
}

function sethbcount($tmpuid){
	$it618_postcount=DB::result_first("select count(1) from ".DB::table('it618_hongbao_main')." where it618_uid=".$tmpuid);
	$it618_getcount=DB::result_first("select count(1) from ".DB::table('it618_hongbao_item')." where it618_uid=".$tmpuid);
	
	if($it618_hongbao_ph=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_ph')." WHERE it618_uid=".$tmpuid)){
		C::t('#it618_hongbao#it618_hongbao_ph')->update($it618_hongbao_ph["id"],array(
			'it618_postcount' => $it618_postcount,
			'it618_getcount' => $it618_getcount
		));
	}else{
		$id = C::t('#it618_hongbao#it618_hongbao_ph')->insert(array(
			'it618_uid' => $tmpuid,
			'it618_postcount' => $it618_postcount,
			'it618_getcount' => $it618_getcount
		), true);
	}
}

function it618_hongbao_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_hongbao_rewriteurl($fl_html){
	global $_G;
	if($_G['cache']['plugin']['it618_hongbao']['rewriteurl']==1){
		//	home.php?mod=space&uid=5
		//	space-uid-5.html
		$tmparr=explode("home.php?mod=space",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"uid=")==1){
					$tmp=str_replace("&uid=","space-uid-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}

	}
	return $fl_html;
}

function it618_hongbao_getusername($uid){
	return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
}

function it618_hongbao_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_hongbao_gbktoutf($strcontent);
	}
}

function it618_hongbao_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_hongbao_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	
	if($timecount>24*10){
		$timestr=date('Y-m-d', $it618_time);
	}elseif($timecount>24){
		$timecount=intval($timecount/24);
		$timestr='<font color="#999">'.$timecount.''.it618_hongbao_getlang('s51').'</font>';
	}elseif($timecount>=1){
		$timestr='<font color="#999">'.$timecount.''.it618_hongbao_getlang('s52').'</font>';
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr='<font color="#999">'.$timecount.''.it618_hongbao_getlang('s53').'</font>';
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr='<font color="#999">'.$timecount.''.it618_hongbao_getlang('s54').'</font>';
		}
	}
	
	return $timestr;
}

function hongbao_is_mobile(){ 
	global $_GET;
	if(isset($_GET['pc'])) return false;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: Dism��taobao��com
?>