<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_hongbao_base {
	function common_base() {
		global $_G,$it618_hongbao_lang;
		$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
		require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
		
		if($_GET['mod']=="topicadmin"&&$_GET['action']=="moderate"&&$_GET['operation']=="delete"){
			$tids="#";
			foreach($_GET['moderate'] as $key => $tid) {
				$tid=intval($tid);
				if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_hongbao_main')." WHERE it618_type='tie' and it618_tid=".$tid)>0){
					$tids.=",".$tid;
			    }
//				DB::delete('it618_hongbao_item', "it618_tid=$tid");
//				DB::delete('it618_hongbao_main', "it618_tid=$tid");
			}
			$tids=str_replace("#,","",$tids);
			if($tids!="#")showmessage($it618_hongbao_lang['s28'].$tids.$it618_hongbao_lang['s29'], '', array(), array('alert' => 'info'));
		}
		
		if($_GET['mod']=="post"&&$_GET['action']=="edit"&&$_GET['delete']==1){
			$tid=intval($_GET['tid']);
			if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_hongbao_main')." WHERE it618_type='tie' and it618_tid=".$tid)>0){
				showmessage($it618_hongbao_lang['s30'], '', array(), array('alert' => 'info'));
			}
		}
	}
	
}

class plugin_it618_hongbao extends plugin_it618_hongbao_base {
	
	function common() {
		
		$this->common_base();

	}
	
	function global_footer(){
		global $_G,$it618_hongbao_lang;
		$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
		
		if($_G['tid']>0){
			$hongbao_forums = unserialize($it618_hongbao["hongbao_forums"]);
			if(in_array($_G['fid'], $hongbao_forums)){
				$it618_hbtype='tie';
				$tid=$_G['tid'];
				$authorid=DB::result_first("select authorid from ".DB::table('forum_thread')." where tid=".$tid);
				include template('it618_hongbao:hongbao');
				return $it618_hongbao_block;
			}
		}
	}

}

class plugin_it618_hongbao_forum extends plugin_it618_hongbao{
	
	function forumdisplay_thread_subject_output(){
		global $_G,$it618_hongbao_lang;
		require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
		$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
		$hongbao_forums = unserialize($it618_hongbao["hongbao_forums"]);

		if(!in_array($_G[fid], $hongbao_forums)) return array();
		
		$thread_subject=array();
		$threadlist = $_G['forum_threadlist'];
		foreach($threadlist as $id => $thread){
			$tid=$thread[tid];
			if(($it618_hongbao_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_main')." WHERE it618_type='tie' and it618_tid=$tid and it618_state=1 order by id desc"))){
				$hbindex=DB::result_first("select count(1) from ".DB::table('it618_hongbao_main')." where it618_type='tie' and it618_tid=$tid");
				if($it618_hongbao_main['it618_isrand']==1)$tmpname=$it618_hongbao_lang['s15'];else $tmpname=$it618_hongbao_lang['s16'];
				if($it618_hongbao_main['it618_code']!='')$tmpname.=$it618_hongbao_lang['s60'];
				$tmpname.=$it618_hongbao_lang['s31'];
				
				$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
				$count1=$it618_hongbao_main['it618_count']-$count2;
				$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
				$money=$it618_hongbao_main['it618_money']-$moneytmp;
				
				if($it618_hongbao_main['it618_jfid']>0){
					$money=str_replace(".00","",$money);
					$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
				}else{
					$moneyname=$it618_hongbao_lang['s69'];
				}
				
				$hongbao_title=str_replace("{type}",$tmpname,$it618_hongbao["hongbao_title"]);
				$hongbao_title=str_replace("{n}",$hbindex,$hongbao_title);
				$hongbao_title=str_replace("{count1}",$count1,$hongbao_title);
				$hongbao_title=str_replace("{count2}",$count2,$hongbao_title);
				$hongbao_title=str_replace("{money}",$money.$moneyname,$hongbao_title);
	
				$thread_subject[$id]=$hongbao_title;
			}
		}

		return $thread_subject;
	}
	
	function viewthread_postheader_output(){
		global $_G,$it618_hongbao_lang,$postlist;
		
		foreach($postlist as $id => $post) {
			if($postlist[$id]['first']==1){
				if($it618_hongbao_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_main')." where it618_type='tie' and it618_tid=".$_G[tid]." order by id desc")){
					if($it618_hongbao_main['it618_istie']>0){
						$post['message']='<div id="hongbaotie" style="margin-bottom:15px;min-height:460px"></div>'.$post['message'];
	
						$postlist[$id] =$post;
					}
				}
			}
		}
	}
		
}


class mobileplugin_it618_hongbao extends plugin_it618_hongbao_base {
	
	function common() {
		
		$this->common_base();

	}
	
	function global_footer_mobile(){
		global $_G,$it618_hongbao_lang;
		$it618_credits = $_G['cache']['plugin']['it618_credits'];
		$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
		
		if($_G['tid']>0){
			$hongbao_forums = unserialize($it618_hongbao["hongbao_forums"]);
			if(in_array($_G['fid'], $hongbao_forums)){
				$wap=1;
				
				if($it618_credits['seotitle']!=''){
					require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
					$creditsurl=it618_credits_getrewriteapi('credits_wap','','plugin.php?id=it618_credits:wap');
				}
				$it618_hbtype='tie';
				$tid=$_G['tid'];
				$authorid=DB::result_first("select authorid from ".DB::table('forum_thread')." where tid=".$tid);
				$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
				$_G['mobiletpl'][IN_MOBILE]='/';
				include template('it618_hongbao:hongbao');
				$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
				
				return $it618_hongbao_block;
			}
		}
	}

}

class mobileplugin_it618_hongbao_forum extends mobileplugin_it618_hongbao{
	
	function forumdisplay_thread_mobile_output(){
		global $_G,$it618_hongbao_lang;
		require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
		$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
		$hongbao_forums = unserialize($it618_hongbao["hongbao_forums"]);

		if(!in_array($_G[fid], $hongbao_forums)) return array();
		
		$thread_subject=array();
		$threadlist = $_G['forum_threadlist'];
		foreach($threadlist as $id => $thread){
			$tid=$thread[tid];
			if(($it618_hongbao_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_main')." WHERE it618_type='tie' and it618_tid=$tid and it618_state=1 order by id desc"))){
				$hbindex=DB::result_first("select count(1) from ".DB::table('it618_hongbao_main')." where it618_type='tie' and it618_tid=$tid");
				if($it618_hongbao_main['it618_isrand']==1)$tmpname=$it618_hongbao_lang['s15'];else $tmpname=$it618_hongbao_lang['s16'];
				if($it618_hongbao_main['it618_code']!='')$tmpname.=$it618_hongbao_lang['s60'];
				$tmpname.=$it618_hongbao_lang['s31'];
				
				$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
				$count1=$it618_hongbao_main['it618_count']-$count2;
				$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
				$money=$it618_hongbao_main['it618_money']-$moneytmp;
				
				if($it618_hongbao_main['it618_jfid']>0){
					$money=str_replace(".00","",$money);
					$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
				}else{
					$moneyname=$it618_hongbao_lang['s69'];
				}
				
				$hongbao_title=str_replace("{type}",$tmpname,$it618_hongbao["hongbao_waptitle"]);
				$hongbao_title=str_replace(" - "," ",$hongbao_title);
				$hongbao_title=str_replace("{n}",$hbindex,$hongbao_title);
				$hongbao_title=str_replace("{count1}",$count1,$hongbao_title);
				$hongbao_title=str_replace("{count2}",$count2,$hongbao_title);
				$hongbao_title=str_replace("{money}",$money.$moneyname,$hongbao_title);
	
				$thread_subject[$id]=$hongbao_title;
			}
		}

		return $thread_subject;
	}
	
	function viewthread_posttop_mobile_output(){
		global $_G,$it618_hongbao_lang,$postlist;
		
		foreach($postlist as $id => $post) {
			if($postlist[$id]['first']==1){
				if($it618_hongbao_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_main')." where it618_type='tie' and it618_tid=".$_G[tid]." order by id desc")){
					if($it618_hongbao_main['it618_istie']>0){
						$post['message']='<div id="hongbaotie" style="margin-bottom:15px;min-height:380px"></div>'.$post['message'];
	
						$postlist[$id] =$post;
					}
				}
			}
		}
	}
}
//From: Dism��taobao��com
?>