<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';

$tid=intval($_GET['tid']);
$fid=intval($_GET['fid']);
$wap=intval($_GET['wap']);

if($_GET['type']=='tie'){
	$hongbao_groups = unserialize($it618_hongbao["hongbao_groups"]);
	if(!in_array($_G['groupid'], $hongbao_groups)){
		echo 'alertit618_split'.$it618_hongbao_lang['s37'];exit;
	}
}

$t=$it618_hongbao_lang['t3'];
if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid1($_GET['type'],$tid)){
	if($it618_hongbao_main['it618_uid']!=$_G['uid']){
		echo 'alertit618_split'.$it618_hongbao_lang['s83'];exit;
	}
	
	C::t('#it618_hongbao#it618_hongbao_main')->update($it618_hongbao_main["id"],array(
		'it618_islock' => 1
	));
	
	$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
	$count1=$it618_hongbao_main['it618_count']-$count2;
	
	$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
	$money=$it618_hongbao_main['it618_money']-$moneytmp;

	if($it618_hongbao_main['it618_jfid']==0){
		$moneyname=$it618_hongbao_lang['s69'];
		$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
		$moneystr=$it618_hongbao_lang['s85'].'<font color=red>'.$money.'</font>'.$moneyname.' <span style="font-size:12px;">'.$it618_hongbao_lang['s40'].' <font color=#390>'.$it618_money.'</font>'.$moneyname.'</span>';
	}else{
		$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
		$creditnum=DB::result_first("select extcredits".$it618_hongbao_main['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
		
		$moneystr=$it618_hongbao_lang['s85'].'<font color=red>'.$money.'</font>'.$moneyname.' <span style="font-size:12px;">'.$it618_hongbao_lang['s40'].'<font color=#390>'.$creditnum.'</font>'.$moneyname.'</span>';
	}
	
	$countstr=$it618_hongbao_lang['s85'].'<font color=red>'.$count1.'</font>'.$it618_hongbao_lang['s34'];
	
	$hbtime=round(($it618_hongbao_main['it618_timecount']-($_G['timestamp']-$it618_hongbao_main['it618_time'])/3600),2);
	
	if($it618_hongbao_main['it618_isrand']==1)$it618_isrand=$it618_hongbao_lang['s46'];
	if($it618_hongbao_main['it618_isrand']==2)$it618_isrand=$it618_hongbao_lang['s47'];
	
	if($it618_hongbao_main['it618_codetype']==1)$it618_codetype1='selected="selected"';
	if($it618_hongbao_main['it618_codetype']==2)$it618_codetype2='selected="selected"';
	
	if($it618_hongbao_main['it618_istie']==0)$it618_istie0='selected="selected"';
	if($it618_hongbao_main['it618_istie']==1)$it618_istie1='selected="selected"';
	if($it618_hongbao_main['it618_istie']==2)$it618_istie2='selected="selected"';
	
	$t=$it618_hongbao_lang['t12'];
	$isedit=1;
}else{
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php';
	}
	
	if($hongbao_isok==1){
		for($i=1;$i<=8;$i++){
			$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
			
			if($hongbao_credit[$i]!=0&&$_G['setting']['extcredits'][$i]['title']!=''){
				$it618_jfid.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].' ('.$creditnum.')</option>';
			}
		}
		
		if($hongbao_credit[0]!=0){
			$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
			$strmoney='<option value="0">'.$it618_hongbao_lang['s70'].' ('.$it618_money.$it618_hongbao_lang['s69'].')</option>';
		}
		
		$moneystr='<select id="it618_hongbao_jfid" name="it618_jfid" class="do_select" style="margin-top:-2px">'.$strmoney.$it618_jfid.'</select>';
	}else{
		$creditname=$_G['setting']['extcredits'][$it618_hongbao['hongbao_credit']]['title'];
		$creditnum=DB::result_first("select extcredits".$it618_hongbao['hongbao_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
		
		$moneystr='<font color=green>'.$creditname.'</font> '.$it618_hongbao_lang['s40'].'<font color=red>'.$creditnum.'</font><font color=green>'.$creditname.'</font><input type="hidden" value="'.$it618_hongbao['hongbao_credit'].'" name="it618_jfid">';
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_hongbao:showhongbaoadd');
?>