<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_hongbao_main`;
CREATE TABLE IF NOT EXISTS `pre_it618_hongbao_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` varchar(50) NOT NULL,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_isrand` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_views` int(10) unsigned NOT NULL,
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_codetype` int(10) unsigned NOT NULL,
  `it618_islock` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istie` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(100) NOT NULL,
  `it618_about` varchar(100) NOT NULL,
  `it618_timecount` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_hongbao_item`;
CREATE TABLE IF NOT EXISTS `pre_it618_hongbao_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` varchar(50) NOT NULL,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_mid` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_hongbao_ph`;
CREATE TABLE IF NOT EXISTS `pre_it618_hongbao_ph` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_postcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_getcount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_hongbao_work`;
CREATE TABLE IF NOT EXISTS `pre_it618_hongbao_work` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` varchar(50) NOT NULL,
  `it618_tid` int(10) unsigned NOT NULL,
  `it618_iswork` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);


//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vZGlzY3V6X3BsdWdpbl9pdDYxOF9ob25nYmFvX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vbGFuZ3VhZ2UuVENfQklHNS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vbGFuZ3VhZ2UuVENfVVRGOC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vdXBncmFkZS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2hvbmdiYW8vaW5zdGFsbC5waHA='));
?>