<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/function.func.php';

if($_GET['formhash']!=FORMHASH)exit;

$uid=$_G['uid'];


if($_GET['ac']=="gethbabout"){
	$tid=intval($_GET['tid']);
	$fid=intval($_GET['fid']);
	
	if($_GET['type']=='tie'){
		$hongbao_forums = unserialize($it618_hongbao["hongbao_forums"]);
		if(!in_array($fid, $hongbao_forums)){
			exit;
		}
		
		$authorid=DB::result_first("select authorid from ".DB::table('forum_thread')." where tid=$tid");
	}else{
		$authorid=gethbauthorid($_GET['type'],$tid);
	}
	
	if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($_GET['type'],$tid)){
		if($it618_hongbao_main['it618_isrand']==1)$tmpname=$it618_hongbao_lang['s15'];else $tmpname=$it618_hongbao_lang['s16'];
		if($it618_hongbao_main['it618_code']!='')$tmpname.=$it618_hongbao_lang['s60'];
		
		if($_GET['wap']==1)$wap='wap';
		
		$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$count1=$it618_hongbao_main['it618_count']-$count2;
		if($count1==0){
			$hongbaostr=str_replace("{type}",$tmpname,$it618_hongbao["hongbao_".$wap."about2"]);
			$hongbaostr=str_replace("{count}",$it618_hongbao_main['it618_count'],$hongbaostr);
			
			if($it618_hongbao_main['it618_jfid']>0){
				$it618_hongbao_main['it618_money']=str_replace(".00","",$it618_hongbao_main['it618_money']);
				$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
			}else{
				$moneyname=$it618_hongbao_lang['s69'];
			}
			
			$hongbaostr=str_replace("{money}",$it618_hongbao_main['it618_money'].$moneyname,$hongbaostr);
		}else{
			$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
			$money=$it618_hongbao_main['it618_money']-$moneytmp;
			
			if($it618_hongbao_main['it618_jfid']>0){
				$money1=str_replace(".00","",$money1);
				$money=str_replace(".00","",$money);
				$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
			}else{
				$moneyname=$it618_hongbao_lang['s69'];
			}
			
			$hongbaostr=str_replace("{type}",$tmpname,$it618_hongbao["hongbao_".$wap."about1"]);
			$hongbaostr=str_replace("{count1}",$count1,$hongbaostr);
			$hongbaostr=str_replace("{count2}",$count2,$hongbaostr);
			$hongbaostr=str_replace("{money}",$money.$moneyname,$hongbaostr);
			
			if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_uid=".$uid." and it618_mid=".$it618_hongbao_main['id'])>0){
				
			}
		}
	}else{
		if($authorid==$uid&&$uid>0){
			$hongbaostr=$it618_hongbao["hongbao_".$wap."about0"];
		}
	}
	
	if($_GET['wap']==1){
		$hongbaoimg='<img src="'.$it618_hongbao["hongbao_wapimg"].'" width="'.$it618_hongbao["hongbao_wapwidth"].'" style="display:block; float:left; margin-bottom:2px"/>';
	}else{
		$hongbaoimg='<img src="'.$it618_hongbao["hongbao_img"].'" width="'.$it618_hongbao["hongbao_width"].'" style="display:block; float:left; margin-bottom:4px"/>';
	}
	
	if($hongbaostr!='')echo 'it618_splitokit618_split'.$hongbaoimg.'it618_split'.$hongbaostr.'it618_split'.$it618_hongbao_main['it618_istie'];exit;
}


if($_GET['ac']=="gethbac"){
	$tid=intval($_GET['tid']);
	
	if($_GET['type']=='tie'){
		$authorid=DB::result_first("select authorid from ".DB::table('forum_thread')." where tid=$tid");
	}else{
		$authorid=gethbauthorid($_GET['type'],$tid);
	}
				
	if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($_GET['type'],$tid)){
		
		$count=$it618_hongbao_main['it618_count'];
		$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$count1=$count-$count2;
		$countstr='<font color=red>'.$count1.'</font> /'.$count;
		
		$money=$it618_hongbao_main['it618_money'];
		$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
		$money1=$it618_hongbao_main['it618_money']-$moneytmp;
		
		if($it618_hongbao_main['it618_jfid']>0){
			$money1=str_replace(".00","",$money1);
			$money=str_replace(".00","",$money);
			$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
		}else{
			$moneyname=$it618_hongbao_lang['s69'];
		}
		
		$moneystr='<font color=red>'.$money1.'</font> '.$moneyname.'/'.$money.$moneyname;
		
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_uid=".$uid." and it618_mid=".$it618_hongbao_main['id'])>0){
			$btnstr='<a href="javascript:" class="hbbtn0"><font color="#999">'.$it618_hongbao_lang['s77'].'</font></a>';
		}else{
			$btnstr='<a href="javascript:" onclick="gethongbao()" class="hbbtn1"><font color="#fff">'.$it618_hongbao_lang['s78'].'</font></a>';
		}
		
		if($it618_hongbao_main['it618_state']==0){
			$btnstr='<a href="javascript:" class="hbbtn0"><font color="#999">'.$it618_hongbao_lang['s79'].'</font></a>';
			if($authorid==$uid){
				if($_GET['wap']==1){
					$btnstr='<a href="javascript:" onclick="IT618_HONGBAO(\'.hb_cd-popup\').removeClass(\'is-visible\');IT618_HONGBAO(\'#it618_hongbao_btnadd\').click();" class="hbbtn1"><font color="#fff">'.$it618_hongbao_lang['s80'].'</font></a>';
				}else{
					$btnstr='<a href="javascript:" onclick="if(IT618_HONGBAO(\'#hongbaotie\').length == 0)dialog_hb.remove();IT618_HONGBAO(\'#it618_hongbao_btnadd\').click();" class="hbbtn1"><font color="#fff">'.$it618_hongbao_lang['s80'].'</font></a>';
				}
			}
		}else{
			$ok='ok';	
		}
		
		echo "it618_split".$countstr."it618_split".$moneystr."it618_split".$btnstr."it618_split".$ok;exit;
		
	}
}


if($_GET['ac']=="hongbao"){
	if($uid<=0){
		echo $it618_hongbao_lang['s1'];
	}else{
		if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
		$it618_jfid=intval($_GET['it618_jfid']);
		$it618_tid=intval($_GET['tid']);
		$mid=intval($_GET['mid']);
		$it618_count=intval($_GET['it618_count']);
		$it618_timecount=intval($_GET['it618_timecount']);
		$it618_money=floatval($_GET['it618_money']);
		
		if($_GET['type']=='tie'){
			$hongbao_groups = unserialize($it618_hongbao["hongbao_groups"]);
			if(!in_array($_G['groupid'], $hongbao_groups)){
				echo $it618_hongbao_lang['s37'];exit;
			}
			
			$hongbao_forums = unserialize($it618_hongbao["hongbao_forums"]);
			if(!in_array($_GET['fid'], $hongbao_forums)){
				echo $it618_hongbao_lang['s64'];exit;
			}
		}
		
		if($_GET['isedit']==1){
			$it618_hongbao_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_main')." where id=$mid");
			$it618_jfid=$it618_hongbao_main['it618_jfid'];
			
			if($it618_hongbao_main['it618_uid']!=$_G['uid']){
				echo $it618_hongbao_lang['s83'];exit;
			}
			
			if($it618_hongbao_main['it618_state']==0){
				echo $it618_hongbao_lang['s83'];exit;
			}

			if($it618_count<=0){
				$it618_count=0;
			}else{
				if($it618_count!=$_GET['it618_count']){
					echo'it618_countit618_split'. $it618_hongbao_lang['t6'];exit;
				}
			}
			
			if($it618_timecount<=0){
				$it618_timecount=0;
			}
			
			if($it618_money<=0){
				$it618_money=0;
			}else{
				if($it618_jfid>0){
					if(intval($it618_money)!=$_GET['it618_money']){
						echo $it618_hongbao_lang['t5'];exit;
					}
				}
			}
			
			$editcount=$it618_count;
			$editmoney=$it618_money;
			$edittimecount=$it618_timecount;
			
			if($editcount>0||$editmoney>0){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php')){
					require_once DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php';
				}
				
				if($editcount>0)$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
				$it618_count=$it618_hongbao_main['it618_count']-$count2+$editcount;
				
				if($editmoney>0)$moneytmp = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
				$it618_money=$it618_hongbao_main['it618_money']-$moneytmp+$editmoney;
				
				if($hongbao_isok==1){
					if($hongbao_min[$it618_jfid]!=0&&$it618_money<$hongbao_min[$it618_jfid]){
						echo $it618_hongbao_lang['s49'].$hongbao_min[$it618_jfid].$creditname;exit;
					}
					
					if($hongbao_max[$it618_jfid]!=0&&$it618_money>$hongbao_max[$it618_jfid]){
						echo $it618_hongbao_lang['s50'].$hongbao_max[$it618_jfid].$creditname;exit;
					}
				}
				
				if($it618_hongbao_main['it618_isrand']==2&&$it618_jfid>0){
					if(intval($it618_money/$it618_count)!=($it618_money/$it618_count)){
						echo $it618_hongbao_lang['s6'];exit;
					}
				}
				
				if($it618_jfid>0){
					if($hongbao_isok==1){
						$minhbprice=intval($hongbao_credit[$it618_jfid]);
					}else{
						$minhbprice=intval($it618_hongbao['hongbao_price']);
					}
					if($minhbprice<1)$minhbprice=1;
				}else{
					$minhbprice=floatval($hongbao_credit[0]);
				}
				
				if($it618_money/$it618_count<$minhbprice){
					echo $it618_hongbao_lang['s7'].$minhbprice.$it618_hongbao_lang['s8'];exit;
				}
				
				if($it618_jfid>0){
					$creditnum=DB::result_first("select extcredits".$it618_jfid." from ".DB::table('common_member_count')." where uid=".$uid);
					$creditname=$_G['setting']['extcredits'][$it618_jfid]['title'];
					if($creditnum<$editmoney){
						if($IsCredits==1){
							$iscredits='iscreditsit618_split';
							$iscredits1=$it618_hongbao_lang['s82'];
						}
						echo $iscredits.$it618_hongbao_lang['s3'].$creditname.$it618_hongbao_lang['s4'].$creditnum.$it618_hongbao_lang['s5'].$iscredits1;exit;
					}
					
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$it618_jfid => (0-$editmoney))
					);
				}else{
					require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
					set_time_limit (0);
					ignore_user_abort(true);
			
					$flagkm=0;$times=0;
					while($flagkm==0){
						if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
							$flagkm=1;
						}
						if($flagkm==0){
							sleep(1);
							$times=$times+1;
						}
						if($times>60){
							it618_credits_delmoneywork();
						}
					}
					C::t('#it618_credits#it618_credits_moneywork')->insert(array(
						'it618_iswork' => 1
					), true);
					
					$creditname=$it618_hongbao_lang['s69'];
					
					$it618_moneytmp=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uid);
					DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_moneytmp." where it618_uid=".$uid);
					if($editmoney>$it618_moneytmp){
						if($IsCredits==1){
							$iscredits='iscreditsit618_split';
							$iscredits1=$it618_hongbao_lang['s82'];
						}
						echo $iscredits.$it618_hongbao_lang['s63'].$iscredits1;it618_credits_delmoneywork();exit;
					}
					
					$it618_bz=$it618_hongbao_lang['s86'];
					$it618_bz=str_replace("{money}",$editmoney,$it618_bz);
					
					$id=savemoney(array(
						'it618_uid' => $uid,
						'it618_type' => 'pay',
						'it618_money2' => $editmoney,
						'it618_bz' => $it618_bz,
						'it618_zftype' => 'hongbao',
						'it618_zfid' => $id
					));
					it618_credits_delmoneywork();
				}
			}
			
			$it618_count=$it618_hongbao_main['it618_count']+$editcount;
			$it618_money=$it618_hongbao_main['it618_money']+$editmoney;
			$it618_timecount=$it618_hongbao_main['it618_timecount']+$edittimecount;
			
			C::t('#it618_hongbao#it618_hongbao_main')->update($it618_hongbao_main["id"],array(
				'it618_count' => $it618_count,
				'it618_money' => $it618_money,
				'it618_codetype' => $_GET['it618_codetype'],
				'it618_istie' => $_GET['it618_istie'],
				'it618_timecount' => $it618_timecount,
				'it618_time' => $_G['timestamp'],
				'it618_code' => it618_hongbao_utftogbk($_GET["it618_code"]),
				'it618_about' => it618_hongbao_utftogbk($_GET["it618_about"]),
				'it618_islock' => 0
			), true);
			
			echo 'ok';
		}else{
			if($it618_count<=0){
				echo 'it618_countit618_split'.$it618_hongbao_lang['t6'];exit;
			}else{
				if($it618_count!=$_GET['it618_count']){
					echo'it618_countit618_split'. $it618_hongbao_lang['t6'];exit;
				}
			}
			
			if($it618_timecount<=0){
				echo 'it618_timecountit618_split'.$it618_hongbao_lang['t14'];exit;
			}else{
				if($it618_timecount!=$_GET['it618_timecount']){
					echo 'it618_timecountit618_split'.$it618_hongbao_lang['t14'];exit;
				}
				if($it618_timecount<12){
					echo 'it618_timecountit618_split'.$it618_hongbao_lang['t14'];exit;
				}
			}
			
			if($it618_money<=0){
				echo $it618_hongbao_lang['t24'];exit;
			}else{
				if($it618_jfid>0){
					if(intval($it618_money)!=$_GET['it618_money']){
						echo $it618_hongbao_lang['t5'];exit;
					}
				}
			}
				
			if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
			
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php')){
				require_once DISCUZ_ROOT.'./source/plugin/it618_credits/config/hongbaoset.php';
			}
	
			if($hongbao_isok==1){
				if($hongbao_min[$it618_jfid]!=0&&$it618_money<$hongbao_min[$it618_jfid]){
					echo $it618_hongbao_lang['s49'].$hongbao_min[$it618_jfid].$creditname;exit;
				}
				
				if($hongbao_max[$it618_jfid]!=0&&$it618_money>$hongbao_max[$it618_jfid]){
					echo $it618_hongbao_lang['s50'].$hongbao_max[$it618_jfid].$creditname;exit;
				}
			}
			
			if($_GET['it618_isrand']==2&&$it618_jfid>0){
				if(intval($it618_money/$it618_count)!=($it618_money/$it618_count)){
					echo $it618_hongbao_lang['s6'];exit;
				}
			}
			
			if($it618_jfid>0){
				if($hongbao_isok==1){
					$minhbprice=intval($hongbao_credit[$it618_jfid]);
				}else{
					$minhbprice=intval($it618_hongbao['hongbao_price']);
				}
				if($minhbprice<1)$minhbprice=1;
			}else{
				$minhbprice=floatval($hongbao_credit[0]);
			}
			
			if($it618_money/$it618_count<$minhbprice){
				echo $it618_hongbao_lang['s7'].$minhbprice.$it618_hongbao_lang['s8'];exit;
			}
			
			if($it618_jfid>0){
				$creditnum=DB::result_first("select extcredits".$it618_jfid." from ".DB::table('common_member_count')." where uid=".$uid);
				$creditname=$_G['setting']['extcredits'][$it618_jfid]['title'];
				if($creditnum<$it618_money){
					if($IsCredits==1){
						$iscredits='iscreditsit618_split';
						$iscredits1=$it618_hongbao_lang['s82'];
					}
					echo $iscredits.$it618_hongbao_lang['s3'].$jfname.$it618_hongbao_lang['s4'].$creditnum.$it618_hongbao_lang['s5'].$iscredits1;exit;
				}
				
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$it618_jfid => (0-$it618_money))
				);
			}else{
				require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
				set_time_limit (0);
				ignore_user_abort(true);
		
				$flagkm=0;$times=0;
				while($flagkm==0){
					if(DB::result_first("select count(1) from ".DB::table('it618_credits_moneywork'))==0){
						$flagkm=1;
					}
					if($flagkm==0){
						sleep(1);
						$times=$times+1;
					}
					if($times>60){
						it618_credits_delmoneywork();
					}
				}
				C::t('#it618_credits#it618_credits_moneywork')->insert(array(
					'it618_iswork' => 1
				), true);
				
				$creditname=$it618_hongbao_lang['s69'];
				
				$it618_moneytmp=C::t('#it618_credits#it618_credits_money')->summoney_by_uid($uid);
				DB::query("update ".DB::table('it618_credits_uset')." set it618_money=".$it618_moneytmp." where it618_uid=".$uid);
				if($it618_money>$it618_moneytmp){
					if($IsCredits==1){
						$iscredits='iscreditsit618_split';
						$iscredits1=$it618_hongbao_lang['s82'];
					}
					echo $iscredits.$it618_hongbao_lang['s63'].$iscredits1;it618_credits_delmoneywork();exit;
				}
				
				$it618_bz=$it618_hongbao_lang['s74'];
				$it618_bz=str_replace("{money}",$it618_money,$it618_bz);
				
				$id=savemoney(array(
					'it618_uid' => $uid,
					'it618_type' => 'pay',
					'it618_money2' => $it618_money,
					'it618_bz' => $it618_bz,
					'it618_zftype' => 'hongbao',
					'it618_zfid' => $id
				));
				it618_credits_delmoneywork();
			}
			
			$id = C::t('#it618_hongbao#it618_hongbao_main')->insert(array(
				'it618_type' => $_GET['type'],
				'it618_tid' => $it618_tid,
				'it618_uid' => $uid,
				'it618_jfid' => $it618_jfid,
				'it618_isrand' => $_GET['it618_isrand'],
				'it618_count' => $it618_count,
				'it618_money' => $it618_money,
				'it618_codetype' => $_GET['it618_codetype'],
				'it618_istie' => $_GET['it618_istie'],
				'it618_timecount' => $_GET['it618_timecount'],
				'it618_time' => $_G['timestamp'],
				'it618_code' => it618_hongbao_utftogbk($_GET["it618_code"]),
				'it618_about' => it618_hongbao_utftogbk($_GET["it618_about"]),
				'it618_state' => 1
			), true);
			if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
			if($id>0){
				sethbcount($uid);
				echo 'ok';
			}
		}
	}
}


if($_GET['ac']=="gethongbao"){
	if($uid<=0){
		echo $it618_hongbao_lang['s1'];
	}else{
		$it618_tid=intval($_GET['tid']);
		$hongbaocode=it618_hongbao_utftogbk($_GET['hongbaocode']);
		
		if($_GET['type']=='tie'){
			$hongbao_getgroups = unserialize($it618_hongbao["hongbao_getgroups"]);
			if(!in_array($_G['groupid'], $hongbao_getgroups)){
				echo $it618_hongbao_lang['s9'];exit;
			}
		}
		
		if($it618_hongbao['hongbao_isbdtel']==1){
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
				if(!$it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
					echo 'bdtelit618_split'.$it618_hongbao['hongbao_bdtelabout'];exit;
				}
			}
		}
		
		if($it618_hongbao['hongbao_isbdwx']==1){
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
				if(!$it618_members_wxuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_wxuser')." WHERE it618_uid=".$_G['uid'])){
					echo 'gzwxit618_split'.$it618_hongbao['hongbao_bdwxabout'];exit;
				}
			}
		}
		
		if($it618_hongbao['hongbao_isgzwx']==1){
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
				if($it618_members_wxuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_wxuser')." WHERE it618_uid=".$_G['uid'])){
					if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
						require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
					}
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
					
					$openid=$it618_members_wxuser['it618_wxopenid'];
					$appid=trim($wxjk_appid);
					$appsecret=trim($wxjk_appsecret);
					
					$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
					$subscribe=$data['subscribe'];
					
					if($subscribe!=1){
						echo 'gzwxit618_split'.$it618_hongbao['hongbao_gzwxabout'];exit;
					}
				}
			}
		}
		
		if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
		
		if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($_GET['type'],$it618_tid)){
			if($it618_hongbao_main['it618_islock']==1){
				echo $it618_hongbao_lang['s88'];exit;
			}
			
			if($it618_hongbao_main['it618_code']!=''){
				if($it618_hongbao_main['it618_codetype']==1){
					if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('forum_post')." WHERE tid=".$it618_tid." and authorid=".$uid." and first=0 and message LIKE '%".addcslashes(addslashes($it618_hongbao_main['it618_code']),'%_')."%'")==0){
						delwork($_GET['type'],$it618_tid);echo 'code1it618_split'.$it618_hongbao_lang['s12'];exit;
					}
				}else{
					if($hongbaocode!=$it618_hongbao_main['it618_code']){
						delwork($_GET['type'],$it618_tid);echo 'code2it618_split'.$it618_hongbao_lang['s59'];exit;
					}
				}
			}
			
			set_time_limit (0);
			ignore_user_abort(true);
			$flagkm=0;$times=0;
			while($flagkm==0){
				if(C::t('#it618_hongbao#it618_hongbao_work')->count_by_it618_type_tid($_GET['type'],$it618_tid)==0){
					$flagkm=1;
				}
				
				if($flagkm==0){
					sleep(1);
					$times=$times+1;
				}
				if($times>30){
					delwork($_GET['type'],$it618_tid);
				}
			}
			if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
			C::t('#it618_hongbao#it618_hongbao_work')->insert(array(
				'it618_iswork' => 1,
				'it618_type' => $_GET['type'],
				'it618_tid' => $it618_tid
			), true);
			if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
			$hbcount1 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
			$hbmoney1 = DB::result_first("SELECT SUM(it618_money) FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']);
			$hbcount=$it618_hongbao_main['it618_count']-$hbcount1;
			$hbmoney=$it618_hongbao_main['it618_money']-$hbmoney1;
			if($hbcount<=0){
				delwork($_GET['type'],$it618_tid);echo $it618_hongbao_lang['s10'];exit;
			}
			
			if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_hongbao_item')." WHERE it618_uid=".$uid." and it618_mid=".$it618_hongbao_main['id'])>0){
				delwork($_GET['type'],$it618_tid);echo $it618_hongbao_lang['s11'];exit;
			}
			if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
			
			$it618_money=$hbmoney/$hbcount;
			if($it618_hongbao_main['it618_isrand']==1){
				if($it618_hongbao_main['it618_jfid']>0){
					if($it618_money>1){
						$safe_total=($hbmoney-$hbcount)/$hbcount;
						$it618_money=intval(mt_rand($safe_total*80,$safe_total*150)/100);
					}
					if($hbcount==1){
						$it618_money=$hbmoney;
					}
				}else{
					$total=$hbmoney;
					$num=$it618_hongbao_main['it618_count'];
					$min=0.01;
					$index=$hbcount1+1;
					if($index<$num){
						$safe_total=($total-($num-$index)*$min)/($num-$index);
						$it618_money=mt_rand($min*100,$safe_total*100)/100;  
					}else{
						$it618_money=$total;
					}
				}
			}

			if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
			$id = C::t('#it618_hongbao#it618_hongbao_item')->insert(array(
				'it618_type' => $_GET['type'],
				'it618_tid' => $it618_tid,
				'it618_mid' => $it618_hongbao_main["id"],
				'it618_uid' => $uid,
				'it618_money' => $it618_money,
				'it618_time' => $_G['timestamp']
			), true);
			
			if($id>0){
				sethbcount($uid);
				
				if($hbcount==1){
					C::t('#it618_hongbao#it618_hongbao_main')->update($it618_hongbao_main["id"],array(
						'it618_state' => 0
					));
				}
				
				if($it618_hongbao_main['it618_isrand']==1){
					DB::query("update ".DB::table('it618_hongbao_item')." set it618_isok=0 where it618_isok=1 and it618_mid=".$it618_hongbao_main['id']);
					$tmpid=DB::result_first("SELECT id FROM ".DB::table('it618_hongbao_item')." WHERE it618_mid=".$it618_hongbao_main['id']." order by it618_money desc,id desc");
					if($tmpid>0)DB::query("update ".DB::table('it618_hongbao_item')." set it618_isok=1 where id=".$tmpid);
				}
				
				if($it618_hongbao_main['it618_jfid']>0){
					$creditname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
					
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$it618_hongbao_main['it618_jfid'] => $it618_money)
					);
				}else{
					$creditname=$it618_hongbao_lang['s69'];
					$it618_bz=$it618_hongbao_lang['s68'];
					$it618_bz=str_replace("{money}",round($it618_money,2),$it618_bz);
					
					require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
					savemoney(array(
						'it618_uid' => $uid,
						'it618_type' => 'zy',
						'it618_money1' => $it618_money,
						'it618_bz' => $it618_bz,
						'it618_zytype' => 'it618_hongbao',
						'it618_zyid' => $id,
						'it618_time' => $_G['timestamp']
					));
					$it618_money=round($it618_money,2);
				}
				
				delwork($_GET['type'],$it618_tid);echo 'okit618_split'.$it618_hongbao_lang['s13'].$it618_money.' '.$creditname.$it618_hongbao_lang['s14'];exit;
			}
				
		}else{
			echo $it618_hongbao_lang['s2'];exit;
		}
  

	}
}


if($_GET['ac']=="hongbaolist_get"){
	$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
	$it618_tid=intval($_GET['tid']);
		
	if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
	foreach(C::t('#it618_hongbao#it618_hongbao_item')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['type'],$it618_tid,$startlimit,$ppp
	) as $it618_hongbao_item) {
		if($it618_mid!=$it618_hongbao_item['it618_mid']){
			$it618_mid=$it618_hongbao_item['it618_mid'];
			$it618_hongbao_main=DB::fetch_first("SELECT * FROM ".DB::table('it618_hongbao_main')." WHERE id=".$it618_mid);
			$hbindex=C::t('#it618_hongbao#it618_hongbao_main')->gethbindex_by_it618_type_tid_mid($_GET['type'],$it618_tid,$it618_mid);
		}
		
		if($it618_hongbao_main['it618_jfid']>0){
			$it618_money=str_replace(".00","",$it618_hongbao_item['it618_money']);
			$moneyname=$_G['setting']['extcredits'][$it618_hongbao_main['it618_jfid']]['title'];
		}else{
			$it618_money=$it618_hongbao_item['it618_money'];
			$moneyname=$it618_hongbao_lang['s69'];
		}
		  
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_item['it618_uid']);
		if($username=='')$username='test'.mt_rand(1,10000);
		
		$it618_isok='';
		if($it618_hongbao_item['it618_isok']==1){
			$it618_isok=' <font color=red style="font-size:10px">'.$it618_hongbao_lang['s89'].'</font>';
		}
		
		if($_GET['wap']!=1){
			$hongbaolist_get.='<tr>
			<td><a href="'.it618_hongbao_rewriteurl('home.php?mod=space&uid='.$it618_hongbao_item['it618_uid']).'" target="_blank">'.$username.'</a> '.$it618_isok.'</td>
			<td><font color=red>'.$it618_money.'</font> <font color=green>'.$moneyname.'</font></td>
			<td style="color:#aaa">'.$it618_hongbao_lang['t42'].$hbindex.$it618_hongbao_lang['t43'].' '.it618_hongbao_gettime($it618_hongbao_item['it618_time']).'</td>
			</tr>';
		}else{
			$hongbaolist_get.='<tr>
			<td><a href="'.it618_hongbao_rewriteurl('home.php?mod=space&uid='.$it618_hongbao_item['it618_uid']).'" target="_blank">'.$username.'</a> '.$it618_isok.'</td>
			<td><font color=red>'.$it618_money.'</font> <font color=green>'.$moneyname.'</font></td>
			<td style="color:#aaa;font-size:10px" width="105">'.$it618_hongbao_lang['t42'].$hbindex.$it618_hongbao_lang['t43'].' '.it618_hongbao_gettime($it618_hongbao_item['it618_time']).'</td>
			</tr>';
		}
		$funname='hongbaolist_get';
	}
	if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
	$count = C::t('#it618_hongbao#it618_hongbao_item')->count_by_search($it618sql,$it618orderby,$_GET['type'],$it618_tid);
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_hongbao:ajax",0,false,true);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
		echo $hongbaolist_get.'it618_split'.$multipage;
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_hongbao:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_hongbao', $it618_hongbao_lang['it618'])!=$it618_hongbao_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.$it618_hongbao_lang['s26'].'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_hongbao:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_hongbao_lang['s27'].'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.$it618_hongbao_lang['s27'].'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_hongbao:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_hongbao_lang['s26'].'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_hongbao:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_hongbao_lang['s27'].'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_hongbao:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.$it618_hongbao_lang['s26'].'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.$it618_hongbao_lang['s27'].'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		echo $hongbaolist_get.'it618_split<div style="text-align:center;width:100%">'.$multipage.'</div>';
	}
	exit;
}

function delwork($type,$tid){
	DB::query("delete from ".DB::table('it618_hongbao_work')." WHERE it618_type=%s AND it618_tid=%d", array($type, $tid));
}
//From: Dism��taobao��com
?>