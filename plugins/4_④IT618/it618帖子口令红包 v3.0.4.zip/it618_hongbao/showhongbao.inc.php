<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/function.func.php';

$tid=intval($_GET['tid']);
$fid=intval($_GET['fid']);
$wap=intval($_GET['wap']);

if($wap==1){
	$height=intval($_GET['height']);
	$height=$height*0.8;
}

$codewidth=230;

if($_GET['type']=='tie'){
	$hongbao_forums = unserialize($it618_hongbao["hongbao_forums"]);
	if(!in_array($fid, $hongbao_forums)){
		echo 'alertit618_split'.$it618_hongbao_lang['s64'];exit;
	}
}

$authorid=$_GET['authorid'];
if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($_GET['type'],$tid)){
	$menuusername=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$it618_hongbao_main['it618_uid']);
	$u_avatarimg=it618_hongbao_discuz_uc_avatar($it618_hongbao_main['it618_uid'],'middle');
	$uurl=it618_hongbao_rewriteurl('home.php?mod=space&uid='.$it618_hongbao_main['it618_uid']);
	
	$shopname=gethbshopname($_GET['type'],$tid);
	
	$hbindex=C::t('#it618_hongbao#it618_hongbao_main')->gethbindex_by_it618_type_tid($_GET['type'],$tid);
	
	if($it618_hongbao_main['it618_isrand']==1)$tmpname=$it618_hongbao_lang['s15'];else $tmpname=$it618_hongbao_lang['s16'];
	if($it618_hongbao_main['it618_code']!='')$tmpname.=$it618_hongbao_lang['s60'];
	$tmpname.=$it618_hongbao_lang['s31'];
	
	if($it618_hongbao_main['it618_islock']==1)$tmpname.=' <img src="source/plugin/it618_hongbao/images/lock.png" height="19" style="vertical-align:middle;margin-top:-4px">';
	
	if($it618_hongbao_main['it618_code']!=''){
		if($it618_hongbao_main['it618_codetype']==2){
			$hbcodestr=$it618_hongbao_lang['s90'].'<input type="text" id="hongbaocode" style="border:#e8e8e8 1px solid;width:'.$codewidth.'px;height:26px;line-height:26px;color:#390;font-weight:bold;padding-left:3px" />';
		}else{
			$hbcodestr='<font color=#999>'.$it618_hongbao_lang['s91'].'</font><input type="hidden" id="hongbaocode">';
		}
		$hbcodestr='<tr><td>'.$hbcodestr.'</td></tr>';
	}else{
		$hbcodestr='<input type="hidden" id="hongbaocode">';
		$hbcodestr='<tr style="display:none"><td>'.$hbcodestr.'</td></tr>';
	}
	
	if($authorid==$_G['uid']){
		if($it618_hongbao_main['it618_state']==1)$editbtn=1;
	}
	
}else{
	if($authorid==$_G['uid']){
		echo 'postit618_split';exit;
	}else{
		echo 'alertit618_split'.$it618_hongbao_lang['s67'];exit;
	}
}

if($it618_hongbao_main['it618_state']==1){
	$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
	$etimestr=date('Y-m-d H:i:s', $it618_hongbao_main['it618_time']+$it618_hongbao_main['it618_timecount']*3600);
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_hongbao:showhongbao');
?>