<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

function it618_members_sendSMS($tel,$content)
{
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php';
	}
	
	$smsapi='http://www.smsbao.com/';
	$pwd = md5($it618_password);
	
	$sendurl = $smsapi."sms?u=".$it618_user."&p=".$pwd."&m=".$tel."&c=".urlencode(it618_members_gbktoutf($content));
	$smsstr =dfsockopen($sendurl);
	
	if($smsstr==0)$smsstr='true';

	return $smsstr;
}

function sendSMS_ALIAPI($plugin,$it618_tel,$members_bz,$members_sign,$members_tplid,$members_param,$it618_jktype){
	global $_G;

	if($it618_tel=='')return;
	
	if($it618_jktype=='alisms'){
		$smsstr=it618_members_sendsms_ali($it618_tel,$members_sign,$members_tplid,$members_param);
	}else{
		$smsstr=it618_members_sendsms_alidayu($it618_tel,$members_sign,$members_tplid,$members_param);
	}
	
	$id = C::t('#it618_members#it618_members_sms')->insert(array(
		  'it618_tel' => $it618_tel,
		  'it618_jktype' => $it618_jktype,
		  'it618_type' => 4,
		  'it618_bz' => dhtmlspecialchars($members_bz),
		  'it618_time' => $_G['timestamp']
	 ), true);
		 
	if($smsstr=='true'){
		 C::t('#it618_members#it618_members_sms')->update($id,array(
			'it618_isok' => 1,
		 ));
		 return 'ok';
	}else{
		C::t('#it618_members#it618_members_sms')->update($id,array(
			'it618_okbz' => $smsstr,
			'it618_isok' => 0
		 ));
	}
	
	return $smsstr;
}

function sendSMS_WXAPI($plugin,$uid,$members_url,$members_tplid,$members_param){
	global $_G,$it618_members;
	
	if(!$it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid($uid)){
		return;
	}else{
		if($it618_members_wxuser['it618_authcount']==0)return;
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
	}
	$appid=trim($wxjk_appid);
	$appsecret=trim($wxjk_appsecret);
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
	
	$openid=$it618_members_wxuser['it618_wxopenid'];
	
	$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
	$subscribe=$data['subscribe'];
	$subscribe_time=$data['subscribe_time'];
	
	C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
		'it618_wxok' => $subscribe,
		'it618_wxoktime' => $subscribe_time,
		'it618_checktime' => $_G['timestamp']
	));
	
	if($subscribe==0)return;
	
	//$token = get_wxtoken($appid,$appsecret);
	$token = $data['wxtoken'];
	$url="https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=".$token;
	
	$post_data = array(
			"touser"=>$openid,
			"template_id"=>$members_tplid,
			"url"=>$members_url,
			"data"=> $members_param
	);
	
	
	//$s = var_export($members_param,true);
	
	$post_data = json_encode($post_data);

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);

	$resp = curl_exec($ch);
	
	//it618_members_debugSMS($resp);

	curl_close($ch);
	$respstr = json_decode($resp,true);
	
	$smsstr=it618_members_utftogbk($respstr["errmsg"]);
	if($smsstr=='OK'||$smsstr=='ok')$smsstr='true';
	
	return $smsstr;
}

function sendSMS_TXAPI($plugin,$it618_tel,$members_bz,$members_sign,$members_tplid,$members_param){
	global $_G;

	if($it618_tel=='')return;
	
	$smsstr=it618_members_sendsms_tx($it618_tel,$members_sign,$members_tplid,$members_param);
	
	$id = C::t('#it618_members#it618_members_sms')->insert(array(
		  'it618_tel' => $it618_tel,
		  'it618_jktype' => $it618_jktype,
		  'it618_type' => 4,
		  'it618_bz' => dhtmlspecialchars($members_bz),
		  'it618_time' => $_G['timestamp']
	 ), true);
		 
	if($smsstr=='true'){
		 C::t('#it618_members#it618_members_sms')->update($id,array(
			'it618_isok' => 1,
		 ));
		 return 'ok';
	}else{
		C::t('#it618_members#it618_members_sms')->update($id,array(
			'it618_okbz' => $smsstr,
			'it618_isok' => 0
		 ));
	}
	
	return $smsstr;
}

function it618_members_sendsms_tx($it618_tel,$members_sign,$members_tplid,$members_param){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php';
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_tx/SmsSenderUtil.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_tx/SmsSingleSender.php';
	
	$members_param=it618_members_gbktoutf1($members_param);
	$members_sign=it618_members_gbktoutf1($members_sign);
	
	try {
		$ssender = new SmsSingleSender($appid, $appkey);
		$result = $ssender->sendWithParam("86", $it618_tel, $members_tplid, $members_param, $members_sign, "", "");
		$rsp = json_decode($result);
	} catch(\Exception $e) {
		echo var_dump($e);
	}

	$tmparr=object_array($response);
	
//	$s = var_export($tmparr,true);
//  it618_members_debugSMS($s.$it618_tel);
	
	$smsstr=it618_members_utftogbk($tmparr["Message"]);
	if($smsstr=='OK')$smsstr='true';
	return $smsstr;
}

function it618_members_sendsms_ali($it618_tel,$members_sign,$members_tplid,$members_param){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php';
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_ali/AliSms.php';
	
	$members_param=it618_members_gbktoutf1($members_param);
	$members_sign=it618_members_gbktoutf1($members_sign);
	
	$IT618_AliSms = new SmsDemo(
		$it618_accesskeyid,
		$it618_accesskeysecret
	);

	$response = $IT618_AliSms->sendSms(
		$members_sign,
		$members_tplid,
		$it618_tel,
		'{'.$members_param.'}'
	);

	$tmparr=object_array($response);
	
//	$s = var_export($tmparr,true);
//  it618_members_debugSMS($s.$it618_tel);
	
	$smsstr=it618_members_utftogbk($tmparr["Message"]);
	if($smsstr=='OK')$smsstr='true';
	return $smsstr;
}

function it618_members_sendsms_alidayu($it618_tel,$members_sign,$members_tplid,$members_param){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php';
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_alidayu/TopClient.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_alidayu/ResultSet.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_alidayu/RequestCheckUtil.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_alidayu/TopLogger.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_alidayu/AlibabaAliqinFcSmsNumSendRequest.php';
	
	$members_param=it618_members_gbktoutf1($members_param);
	$members_sign=it618_members_gbktoutf1($members_sign);

	$c = new TopClient;
	$c->appkey = $it618_appkey;
	$c->secretKey = $it618_appsecret;
	$req = new AlibabaAliqinFcSmsNumSendRequest;
	$req->setSmsType("normal");
	$req->setSmsFreeSignName($members_sign);
	$req->setSmsParam('{'.$members_param.'}');
	$req->setRecNum($it618_tel);
	$req->setSmsTemplateCode($members_tplid);
	$resp = $c->execute($req);

	$resp = json_decode(json_encode($resp),true);

	if($resp["result"]["success"]=="true"){
		return "true";
	}else{
		return it618_members_utftogbk($resp["msg"].$resp["sub_msg"]);
	}
}

function getsmssign(){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php';
	}
	
	return md5($it618_appkey.$it618_appsecret.$it618_accesskeyid.$it618_accesskeysecret.$it618_body_reg_sign);	
}

function it618_members_debugSMS($content){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/debug.txt',"a");
	fwrite($fp,$content);
	fclose($fp);
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>