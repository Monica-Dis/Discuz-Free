<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function/it618_members.func.php';

loadcache('plugin');
$it618_members = $_G['cache']['plugin']['it618_members'];

$ppp = $it618_members['pagecount'];
$page = max(1, intval($_GET['page']));
if($_GET['findbtn']==1)$page=1;
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=6;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<=9;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[0]=$it618_members_lang['s322'];
$strtmptitle[1]=$it618_members_lang['s661'];
$strtmptitle[2]=$it618_members_lang['s677'];
$strtmptitle[3]=$it618_members_lang['s1878'];
$strtmptitle[4]=$it618_members_lang['s768'];
$strtmptitle[5]=$it618_members_lang['s833'];
$strtmptitle[6]=$it618_members_lang['s844'];
$strtmptitle[7]=$it618_members_lang['s855'];
$strtmptitle[8]=$it618_members_lang['s848'];
$strtmptitle[9]=$it618_members_lang['s871'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_homeico&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_rewrite&cp1=1'.$urls.'"><span>'.$strtmptitle[1].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_membersset&cp1=2'.$urls.'"><span>'.$strtmptitle[2].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_aliyunoss&cp1=3'.$urls.'"><span>'.$strtmptitle[3].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=4'.$urls.'"><span>'.$strtmptitle[4].'</span></a></li>
<li '.$strtmp[5].'><a href="'.$hosturl.'plugins&cp=admin_messageapi&cp1=5'.$urls.'"><span>'.$strtmptitle[5].'</span></a></li>
<li '.$strtmp[6].'><a href="'.$hosturl.'plugins&cp=admin_login&cp1=6'.$urls.'"><span>'.$strtmptitle[6].'</span></a></li>
<li '.$strtmp[7].'><a href="'.$hosturl.'plugins&cp=admin_visitset&cp1=7'.$urls.'"><span>'.$strtmptitle[7].'</span></a></li>
<li '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_visit&cp1=8'.$urls.'"><span>'.$strtmptitle[8].'</span></a></li>
<li '.$strtmp[9].'><a href="'.$hosturl.'plugins&cp=admin_visitcount&cp1=9'.$urls.'"><span>'.$strtmptitle[9].'</span></a></li>
</ul></div>';

if($cp1==4)$setname='agreeabout';

$cparray = array('admin_homeico', 'admin_rewrite', 'admin_membersset', 'admin_aliyunoss', 'admin_set', 'admin_messageapi', 'admin_login', 'admin_visitset', 'admin_visit', 'admin_visitcount');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_login' : $_GET['cp'];

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/
?>