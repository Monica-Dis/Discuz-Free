<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
}

$wap=$_GET['wap'];

if($_G['uid']<=0){
	$showmessage='<a href="member.php?mod=logging&action=login">'.$it618_members_lang['s40'].'</a>';
}else{
	$subscribestr=$it618_members_lang['s537'];
	if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($_G['uid'])){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php';
		}
		
		$openid=$it618_members_wxuser['it618_wxopenid'];
		$appid=trim($wxjk_appid);
		$appsecret=trim($wxjk_appsecret);
		
		$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
		$subscribe=$data['subscribe'];
		if($subscribe==0){
			$subscribestr=$it618_members_lang['s536'];
		}else{
			$subscribestr=$it618_members_lang['s535'];
		}
	}
	
	if($it618_body_post_postuser_isok==1){
		if(C::t('#it618_members#it618_members_user_wxsms')->count_by_type_uid_ok('post_postuser',$_G['uid'])==1){
			$post_postuser_checked='checked="checked"';
		}else{
			$post_postuser_checked='';
		}
	}
	
	if($it618_body_posthf_postuser_isok==1){
		if(C::t('#it618_members#it618_members_user_wxsms')->count_by_type_uid_ok('posthf_postuser',$_G['uid'])==1){
			$posthf_postuser_checked='checked="checked"';
		}else{
			$posthf_postuser_checked='';
		}
	}
	
	if($it618_body_posthf_posthfuser_isok==1){
		if(C::t('#it618_members#it618_members_user_wxsms')->count_by_type_uid_ok('posthf_posthfuser',$_G['uid'])==1){
			$posthf_posthfuser_checked='checked="checked"';
		}else{
			$posthf_posthfuser_checked='';
		}
	}
}

$_G['mobiletpl'][2]='/';

if($wap!=1)include template('common/header');
include template('it618_members:showwxsms');
if($wap!=1)include template('common/footer');
?>