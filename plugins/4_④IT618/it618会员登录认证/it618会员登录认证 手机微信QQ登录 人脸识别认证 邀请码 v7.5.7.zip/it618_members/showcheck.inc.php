<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';

$wap=$_GET['wap'];

$it618_img=$yqcodeset['imgsrc'];
$it618_about=$yqcodeset['about'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
$it618paystr=it618_members_pay('yqcodepay','');

if($IsGroup==1){
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where it618_yqcode_days>0");
	while($it618_group_group =	DB::fetch($query)) {
		$grouptitlestr.='<img src="'.$it618_group_group['it618_ico'].'" style="height:16px;margin-right:3px;vertical-align:middle;margin-top:-3px">'.DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']).' '.$it618_group_group['it618_yqcode_days'].$it618_members_lang['s62'].' ';
	}
	if($grouptitlestr!=''){
		$grouptitlestr=$it618_members_lang['s1001'].$grouptitlestr;
	}
}

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

$_G['mobiletpl'][2]='/';
if($wap!=1)include template('common/header');
include template('it618_members:showcheck');
if($wap!=1)include template('common/footer');
?>