<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php';
}

$navtitle = $it618_members_lang['t36'];

if($it618_members['members_isok']==0){
	dheader("location:member.php?mod=logging&action=login");
}

if($tellogin['ischeck_login']==1){
	$isvcode=1;
}

if($wxjk_mode==1||$wxjk_mode==2){
	$it618wxloginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login&it618wxlogin","?it618wxlogin");
}

$wap=0;
if(members_is_mobile()){
	$wap=1;
	if($it618_members['members_waplogomargin']=='')$it618_members['members_waplogomargin']='46|15';
	$logomarginarr=explode("|",$it618_members['members_waplogomargin']);
	
	$stylearr=explode("|",$it618_members['members_regloginstyle'].'|');
	if($stylearr[5]==''){
		$wapwidth=90;
	}else{
		$wapwidth=$stylearr[5];
	}
	if($wapwidth>95)$wapwidth1=96; else $wapwidth1=$wapwidth;
}else{
	$stylearr=explode("|",$it618_members['members_pcregloginstyle'].'|');	
}

if($tellogin['loginmode']==3){
	$logintype=1;
	$css_litelcode='style="display:none"';
	$css_livcode='style="display:none"';
	$css_lipassword='style="display:"';
	if($tellogin['loginquestion']==0)$css_liquestion='style="display:"';
		
	if($wap==1){
		$logintitle=$it618_members_lang['t66'];
	}else{
		$logintitle=$it618_members_lang['s565'];
	}
}else{
	if($tellogin['loginmode']==1&&!isset($_GET['lsSubmit'])){
		$logintype=2;
		$arraylicss2='class="current"';
		$css_litelcode='style="display:"';
		$css_livcode='style="display:"';
		$css_lipassword='style="display:none"';
		$css_liquestion='style="display:none"';
	}else{
		$logintype=1;
		$arraylicss1='class="current"';
		$css_litelcode='style="display:none"';
		$css_livcode='style="display:none"';
		$css_lipassword='style="display:"';
		if($tellogin['loginquestion']==0)$css_liquestion='style="display:"';
	}
	
	if($wap==1){
		if($tellogin['loginmode']==2){
			$logintitle=$it618_members_lang['t66'];
		}else{
			$logintitle=$it618_members_lang['t61'];
		}
	}else{
		if($tellogin['loginmode']==2){
			$logintitle=$it618_members_lang['s565'];
		}else{
			$logintitle=$it618_members_lang['t52'];
		}	
	}
}

if($tellogin['loginquestion']==1)$css_liquestion='style="display:none"';

$it618_loginpreurl=getcookie('it618_loginpreurl');

if($it618_loginpreurl!=''){
	$tmparr=explode("action=logout",$it618_loginpreurl);
	if(count($tmparr)>1){
		$preurl=$_G['siteurl'];
	}else{
		$preurl=$it618_loginpreurl;	
	}
}else{
	if($it618_members['members_tourl']!=''){
		$tmparr=explode("|",$it618_members['members_tourl']);
		$preurl=$tmparr[$wap];
	}else{
		$preurl=$_SERVER['HTTP_REFERER'];
		if($it618_members['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php')){
			$tmparr1=explode("plugin.php?id=it618_members:login",$preurl);
			$tmparr2=explode("plugin.php?id=it618_members:reg",$preurl);
			if(count($tmparr1)>1||count($tmparr2)>1){
				$preurl=$_G['siteurl'];
			}
		}else{
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php';
			}
			$tmparr1=explode($members_login,$preurl);
			$tmparr2=explode($members_reg,$preurl);
			if(count($tmparr1)>1||count($tmparr2)>1){
				$preurl=$_G['siteurl'];
			}
		}
	}
}

if($preurl=='')$preurl=$_G['siteurl'];

dsetcookie('it618_loginpreurl',$preurl,31536000);

if($_G['uid']>0){
	$tmparr=explode("login",$preurl);
	if(count($tmparr)>1)$preurl=$_G['siteurl'];
	dheader("location:$preurl");
}

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($_GET['winapi']==1){
	$winapi='&winapi=1';
	$regurl=it618_members_getrewrite("members_reg","","plugin.php?id=it618_members:reg&winapi=1","?winapi=1");
	include template('it618_members:layer');
}else{
	$regurl=it618_members_getrewrite("members_reg","","plugin.php?id=it618_members:reg");
}

if(isset($_GET['login_wx'])){
	$it618_openid=getcookie('it618_openid');
	if($it618_openid!=''&&$iswx==1){
		dsetcookie('it618_preurl',$preurl,31536000);
		$it618_wxdata=getcookie('it618_wxdata');
		$wxdataarr=explode("@@@",$it618_wxdata);
		$nickname=$wxdataarr[1];
		$headimgurl=$wxdataarr[2];
		
		$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout3');
		if($it618_members_set['setvalue']!='')$abouttype='wx';
		$abouttitle=$it618_members_lang['s548'];
		
		if($wxjk_wxreglogintip=='')$wxjk_wxreglogintip=$it618_members_lang['s381'];
		$nicknameabout=$wxjk_wxreglogintip;
		
		$regurl=it618_members_getrewrite("members_reg","","plugin.php?id=it618_members:reg&login_wx","?login_wx");
	}
}

if(isset($_GET['login_qq'])){
	
	$it618_qqopenid=getcookie('it618_qqopenid');
	if($it618_qqopenid!=''){
		dsetcookie('it618_preurl',$preurl,31536000);
		$it618_qqdata=getcookie('it618_qqdata');
		$qqdataarr=explode("@@@",$it618_qqdata);
		$nickname=$qqdataarr[1];
		$headimgurl=$qqdataarr[2];
		
		$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('qqjk_qqabout1');
		if($it618_members_set['setvalue']!='')$abouttype='qq';
		$abouttitle=$it618_members_lang['s549'];
		
		if($qqjk_qqreglogintip=='')$qqjk_qqreglogintip=$it618_members_lang['s312'];
		$nicknameabout=$qqjk_qqreglogintip;
		
		$regurl=it618_members_getrewrite("members_reg","","plugin.php?id=it618_members:reg&login_qq$winapi","?login_qq$winapi");
	}
}

$members_logintip=$it618_members['members_logintip'];

if($tellogin['codeoktime']=='')$tellogin['codeoktime']=60;
$members_teltime='var countdown='.$tellogin['codeoktime'].';';

if(isset($_GET['aboutbtn'])){
	$aboutbtn=1;
}

$tmparr=explode("?",$regurl);
if(count($tmparr)>1){
	$regurl_tel=$regurl.'&tel=';
}else{
	$regurl_tel=$regurl.'?tel=';
}

$winapi=intval($_GET['winapi']);
if($winapi==0)$winapi='';

$_G['mobiletpl'][2]='/';
$tmpjs='<SCRIPT src="source/plugin/it618_members/js/jquery.js" type=text/javascript></'.'SCRIPT>';
if($wap==1){
	if($it618_members['members_wapbgimage']!=''){
		$members_wapbgimagearr=explode("@@@",str_replace(array("\r\n", "\r", "\n"), '@@@', $it618_members['members_wapbgimage']));
		$members_wapbgimagetmp=explode("|",$members_wapbgimagearr[mt_rand(0,count($members_wapbgimagearr)-1)]);
		$members_wapbgimage=$members_wapbgimagetmp[0];
		$members_wapbgimagetxt=$members_wapbgimagetmp[1];
	}
	
	if($IsGroup==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
		$it618_group_wapad=it618_group_getad($_GET['id'],1);
	}
	
	include template('it618_members:layer');
	
	include template('it618_members:loginjs');
	
	include template('it618_members:waplogin');
}else{
	if($it618_members['members_jquery']==1){
		$tmpjs='<script>var IT618_MEMBERS=jQuery;</'.'SCRIPT>';
	}
	
	$winname='it618_login';
	
	if(isset($_GET['lsSubmit'])){
		$win=1;
	}
	
	if(isset($_GET['win_wx'])){
		$win=1;
		$win_wx=1;
		$winname='it618_loginwx';
		if(isset($_GET['win_app'])){$win_app=1;$winname='it618_loginwxapp';}
		
		$codeid=C::t('#it618_members#it618_members_wxcodelogin')->insert(array(
			'it618_time' => $_G['timestamp']
		), true);
		
		$url_this=$_G['siteurl'].'plugin.php?id=it618_members:codelogin&codeid='.$codeid;
		$qrcodesrc='plugin.php?id=it618_members:wxcode&url='.urlencode($url_this);
	}
	
	include template('it618_members:loginjs');
	
	include template('it618_members:login');
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>