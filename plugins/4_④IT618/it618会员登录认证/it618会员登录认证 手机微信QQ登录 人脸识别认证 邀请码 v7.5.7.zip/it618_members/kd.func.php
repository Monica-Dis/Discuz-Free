<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

function GetKD($saletype,$saleid,$kdcomid,$kdid){
	global $_G,$it618_members_lang;
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kd.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/kd.php';
	}
	
	if($it618_isok==0)return $kdid;
	
	//�����ĵ���https://www.kuaidi100.com/openapi/api_post.shtml
	
	//���100��Ѱ�
	if($it618_jktype=='kd100ad'){
		if($kdcomid!=''){
			if(members_is_mobile()){
				$getkdstr=$kdid.' <a href="https://m.kuaidi100.com/index_all.html?type='.$kdcomid.'&postid='.$kdid.'&callbackurl='.$_SERVER['HTTP_REFERER'].'" class="saleabtn">'.$it618_members_lang['s648'].'</a>';
			}else{
				$getkdstr=$kdid.' <a href="https://www.kuaidi100.com/chaxun?com='.$kdcomid.'&nu='.$kdid.'" target="_blank" class="saleabtn">'.$it618_members_lang['s648'].'</a>';
			}
		}else{
			$getkdstr=$kdid;
		}
		
		return $getkdstr;
	}
	
	//���100��ҵ��
	if($it618_jktype=='kd100'){
		if($kdcomid!=''){
			
			if(!$it618_members_kdsale=C::t('#it618_members#it618_members_kdsale')->fetch_by_it618_jktype_kdcomid_kdid($it618_jktype,$kdcomid,$kdid)){
				$id = C::t('#it618_members#it618_members_kdsale')->insert(array(
					  'it618_kdcomid' => $kdcomid,
					  'it618_kdid' => $kdid,
					  'it618_saletype' => $saletype,
					  'it618_saleid' => $saleid,
					  'it618_jktype' => $it618_jktype,
					  'it618_count' => 0,
					  'it618_time' => $_G['timestamp']
				 ), true);
			}
			
			$getkdstr=$kdid.' <a href="javascript:" class="saleabtn" onclick="it618_getkd('.$it618_members_kdsale['id'].')">'.$it618_members_lang['s648'].'</a>';
			
		}else{
			$getkdstr=$kdid;
		}
		
		return $getkdstr;
	}
}

function GetKDdata($it618_members_kdsale){
	global $_G,$it618_members_lang;
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kd.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/kd.php';
	}
	
	$kdcomid=$it618_members_kdsale['it618_kdcomid'];
	$kdid=$it618_members_kdsale['it618_kdid'];
	
	$post_data = array();
	$post_data["customer"] = $it618_customer;
	$post_data["param"] = '{"com":"'.$kdcomid.'","num":"'.$kdid.'"}';

	if($it618_istest==0){
		$url='http://poll.kuaidi100.com/poll/query.do';
	}else{
		$url='http://poll.kuaidi100.com/test/poll/query.do';
	}
	
	$post_data["sign"] = md5($post_data["param"].$it618_key.$post_data["customer"]);
	$post_data["sign"] = strtoupper($post_data["sign"]);
	$o="";
	foreach ($post_data as $k=>$v){
		$o.= "$k=".urlencode($v)."&";
	}
	$post_data=substr($o,0,-1);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	$resp = curl_exec($ch);
	
	curl_close($ch);
	$data = str_replace("\"",'"',$resp);
	$data = json_decode($data,true);
	
	if($data['message']=='ok'){
		$tmpcss='class=curenttr';
		foreach ($data['data'] as $k=>$v){
			$tmp.= '<tr '.$tmpcss.'><td class="tdtime">'.$v['ftime'].'</td><td class="tdcont">'.it618_members_utftogbk($v['context']).'</td></tr>';
			if($tmpcss=='class=curenttr')$tmpcss='';
		}
		
		$it618_data=$tmp;
		$it618_state=$data['state'];
	}else{
		return it618_members_utftogbk($resp);
		$it618_data=$it618_members_kdsale['it618_data'];
		$it618_state=$it618_members_kdsale['it618_state'];
	}
	
	C::t('#it618_members#it618_members_kdsale')->update($it618_members_kdsale['id'],array(
		'it618_count' => $it618_members_kdsale['it618_count']+1,
		'it618_message' => it618_members_utftogbk($data['message']),
		'it618_state' => $it618_state,
		'it618_data' => $it618_data,
		'it618_time' => $_G['timestamp']
	));
	
	return $it618_data;
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>