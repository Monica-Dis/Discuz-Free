<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_members_base {
	function common_base() {
		global $_G,$it618_members_lang;
		$it618_members = $_G['cache']['plugin']['it618_members'];

		if($_G['setting']['bbclosed']==1)return;

		require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';

		if($it618_members['members_https']==1){
			$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
			$tmparrhttp=explode("ac=hlskms",$_SERVER['REQUEST_URI']);
			if($http_type=='http://'&&count($tmparrhttp)==1){
				$url_this = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			
				dheader("location:".$url_this);
			}
		}

		$urlarr=explode("https://",$_G['siteurl']);
		if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';		
		$url_this = $httpstr.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		
		if($it618_members['members_sitelogin']==1){
			if($_G['uid']<=0){
				$istmplogin=1;
				
				if($_SERVER['REQUEST_URI']=='/reg.html')$istmplogin=0;
				if($_SERVER['REQUEST_URI']=='/login.html')$istmplogin=0;
				$tmparrtmp=explode('/plugin.php?id=it618_members:',$_SERVER['REQUEST_URI']);
				if(count($tmparrtmp)>1&&$tmparrtmp[0]=='')$istmplogin=0;
				$tmparrtmp=explode('/plugin.php?id=it618_group:showad',$_SERVER['REQUEST_URI']);
				if(count($tmparrtmp)>1&&$tmparrtmp[0]=='')$istmplogin=0;
				$tmparrtmp=explode('/plugin.php?id=it618_credits:ajax',$_SERVER['REQUEST_URI']);
				if(count($tmparrtmp)>1&&$tmparrtmp[0]=='')$istmplogin=0;
				$tmparrtmp=explode('/plugin.php?id=it618_credits:ajaxpay',$_SERVER['REQUEST_URI']);
				if(count($tmparrtmp)>1&&$tmparrtmp[0]=='')$istmplogin=0;
				$tmparrtmp=explode('/plugin.php?id=it618_credits:getqrcode',$_SERVER['REQUEST_URI']);
				if(count($tmparrtmp)>1&&$tmparrtmp[0]=='')$istmplogin=0;
				
				if($istmplogin==1){
					if($_GET['referer']!='')$tmpurl=urldecode($_GET['referer']);
					if($tmpurl=='')$tmpurl=$_G['siteurl'];
					
					dsetcookie('it618_loginpreurl',$tmpurl,31536000);
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
					$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login");
					dheader("location:$loginurl");
				}
			}
		}
		
		$tuiuid=intval($_GET['tuiuid']);
		if($tuiuid>0){
			$tuipower=1;
			$it618_union = $_G['cache']['plugin']['it618_union'];
			
			if($common_member=DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE uid=".$tuiuid)){
				if($it618_union['union_yqpowermode']==1||$it618_union['union_yqpowermode']==3){
					$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
					
					if($union_tuigroup[0]!=''){
						require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
						$tmpgrouparr=it618_union_getisvipuser($union_tuigroup);
						if(count($tmpgrouparr[0])==0){
							$tuipower=0;
						}
					}
				}else{
					if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($tuiuid)==0){
						$tuipower=0;
					}
				}
			}
			if($tuipower==1){
				if($it618_union['union_cookietime']==0)$union_cookietime=3600;else $union_cookietime=$it618_union['union_cookietime']*3600;
				dsetcookie('it618_union_tuiuid',$tuiuid,$union_cookietime);
			}
		}
		
		if($_GET['bdcodeid']>0){
			if($it618_members_wxcodebd=C::t('#it618_members#it618_members_wxcodebd')->fetch_by_id($_GET['bdcodeid'])){
				if($it618_members_wxcodebd['it618_code']==$_GET['code']){
					require_once libfile('function/member');
					$member=getuserbyuid($it618_members_wxcodebd['it618_uid'], 1);
					setloginstatus($member, 1296000);
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
					dsetcookie('bdcodeid',$_GET['bdcodeid'],31536000);
				}
			}
		}
		
		$tmparr1=explode("plugin.php?id=it618_members:wxlogin",$url_this);
		$tmparr2=explode("plugin.php?id=it618_members:codelogin",$url_this);
		$tmparr3=explode("plugin.php?id=it618_wxmini",$url_this);

		if(count($tmparr1)==1&&count($tmparr2)==1&&count($tmparr3)==1){
			
			$iswx=1;
			if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;
			
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')&&$iswx==1){
				require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
				
				$isurlok=1;
				$pluginkeysarr=explode(",",$wxjk_pluginkeys.',:ajax');
				for($i=0;$i<count($pluginkeysarr);$i++){
					if($pluginkeysarr[$i]!=''){
						$tmparrtmp=explode($pluginkeysarr[$i],$_GET['id']);
						if(count($tmparrtmp)>1){
							$isurlok=0;
							break;
						}
					}
				}
			}
			
			if($isurlok==1&&($wxjk_mode==1||($wxjk_mode==2&&$_G['uid']>0)||($wxjk_mode==3&&$_G['uid']>0)||(isset($_GET['it618wxlogin'])&&$_G['uid']<=0))){
				
				$members_domain=trim($wxjk_domain);
				if($members_domain==''){
					$wxdomainurl=$_G['siteurl'];
				}else{
					$urlarr=explode("://",$members_domain);
					if(count($urlarr)==1){
						$wxdomainurl=$httpstr.$members_domain.'/';
					}else{
						$wxdomainurl=$members_domain.'/';
					}
					$wxdomainurl=$wxdomainurl.'@';
					$wxdomainurl=str_replace('/@','/',$wxdomainurl);
					$wxdomainurl=str_replace('//@','/',$wxdomainurl);
				}

				dsetcookie('it618_preurl',$url_this,31536000);
				$tmpurl=$wxdomainurl.'plugin.php?id=it618_members:wxlogin';
				
				$it618_openid=getcookie('it618_openid');
				$it618_openidmd5=getcookie(md5('it618_openid'.$wxjk_appsecret.$it618_openid));
				
				if($it618_openid==''||$it618_openidmd5==''){
					dheader("location:$tmpurl");
				}
				
				if($_G['uid']>0){
					if(!$it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_openid($it618_openid)){
						dheader("location:$tmpurl");
					}else{
						$bdcodeid=getcookie('bdcodeid');
						if($bdcodeid>0){
							C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
								'it618_authcount' => 1,
							));
							C::t('#it618_members#it618_members_wxcodebd')->update($bdcodeid,array(
								'it618_openid' => $it618_openid
							));
							dsetcookie('bdcodeid',0,31536000);
						}
					}
				}else{
					if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_openid($it618_openid)){
						
						$it618_wxdata=getcookie('it618_wxdata');
						$wxdataarr=explode("@@@",$it618_wxdata);
						$nickname=$wxdataarr[1];
						$unionid=$wxdataarr[5];
						$subscribe=$wxdataarr[3];
						
						if($it618_members_wxuser['it618_wxname']==''){
							if($nickname!=''){
								DB::query("UPDATE ".DB::table('it618_members_wxuser')." SET it618_wxname=%s WHERE id=%d", array($nickname, $it618_members_wxuser['id']));
							}
						}
						if($it618_members_wxuser['it618_wxunionid']==''){
							if($unionid!=''){
								C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
									'it618_wxunionid' => $unionid
								));
							}
						}
						
						require_once libfile('function/member');
						$member=getuserbyuid($it618_members_wxuser['it618_uid'], 1);
						
						setloginstatus($member, 1296000);
						require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
						it618_members_getlogin($_G['uid'],'wx');
						
						if($it618_members['members_tourl']!=''){
							$tmparr=explode("|",$it618_members['members_tourl']);
							$preurl=$tmparr[1];
						}
						
						if(isset($_GET['it618wxlogin'])){
							$it618_preurl=getcookie('it618_preurl');
							if($it618_preurl!=''){
								$preurl=$it618_preurl;
							}
							if($preurl=='')$preurl=$_G['siteurl'];
						}
						
						if($subscribe!=1&&$wxjk_subscribe==1){
							dsetcookie('it618_preurl',$preurl,31536000);
							dheader("location:plugin.php?id=it618_members:home&ac=wxsubscribe");
						}

						if($preurl!='')dheader("location:".$preurl);
					}
					
					if(isset($_GET['it618wxlogin'])){
						$url_this=str_replace("it618wxlogin","login_wx",$url_this);
						dheader("location:$url_this");
					}
				}
				
				$it618_subscribe=getcookie('it618_subscribe');
				if($wxjk_subscribe==2&&$it618_subscribe!=1){
					if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($_G['uid'])){
						
						require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
						
						$openid=$it618_members_wxuser['it618_wxopenid'];
						$appid=trim($wxjk_appid);
						$appsecret=trim($wxjk_appsecret);
						
						$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
						$subscribe=$data['subscribe'];
						dsetcookie('it618_subscribe',1,$wxjk_subscribetime*60);
						
						if($subscribe!=1){
							dsetcookie('it618_preurl',$preurl,31536000);
							dheader("location:plugin.php?id=it618_members:home&ac=wxsubscribe");
						}
					}
				}
	
			}

		}
		
		$codeid=getcookie('it618_codeid');
		if($codeid>0&&$_G['uid']>0){
			C::t('#it618_members#it618_members_wxcodelogin')->update($codeid,array(
				'it618_uid' => $_G['uid'],
			));
			dsetcookie('it618_codeid',0);
		}
		
		if($it618_members['members_ishome']==1||$it618_members['members_ishome']==3){
			if($_GET['mod']=='space'&&!($_GET['do']=='thread'||$_GET['do']=='favorite'||$_GET['do']=='pm'||$_GET['do']=='friend'||$_GET['do']=='profile'||$_GET['do']=='blog'||$_GET['do']=='notice')){
				if($_G['uid']==$_GET['uid']||(!($_G['uid']>0&&isset($_GET['uid'])))){
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
					if(members_is_mobile()){
						$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home");
						dheader("location:$uhomeurl");
					}
				}
			}
		}

		if($it618_members['members_isok']==1&&!isset($_GET['mag_mod'])){
			if($_G['uid']<=0){
				$regname=$_G['setting']['regname'];

				if($_GET['mod']==$regname||$_GET['mod']=='connect'){
					$tmpurl=$_SERVER['HTTP_REFERER'];
					if($tmpurl=='')$tmpurl=$_G['siteurl'];
					dsetcookie('it618_loginpreurl',$tmpurl,31536000);
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
					$regurl=it618_members_getrewrite("members_reg","","plugin.php?id=it618_members:reg");
					dheader("location:$regurl");
				}
				if($_GET['mod']=='logging'&&$_GET['action']=='login'){
					
					if(isset($_GET['loginsubmit'])||isset($_GET['viewlostpw'])||$_G['inajax']>0){
					}else{
						if($_GET['kefuid']!=''){
							$tmpurl='plugin.php?id=it618_chat:kefuwap&tid='.intval($_GET['kefuid']);
						}else{
							$tmpurl=$_SERVER['HTTP_REFERER'];
						}
						if($_GET['referer']!='')$tmpurl=urldecode($_GET['referer']);
						if($tmpurl=='')$tmpurl=$_G['siteurl'];
						
						dsetcookie('it618_loginpreurl',$tmpurl,31536000);
						require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
						$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login");
						dheader("location:$loginurl");
					}
				}
				if(($_GET['mod']=='space'||$_GET['mod']=='spacecp')&&($_GET['do']!='profile'||$_GET['do']!='blog')){
//					$tmpurl=$_SERVER['HTTP_REFERER'];
//					if($tmpurl=='')$tmpurl=$_G['siteurl'];
//					dsetcookie('it618_loginpreurl',$tmpurl,31536000);
//					require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
//					$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login");
//					dheader("location:$loginurl");
				}
			}
		}
		
		if($_SERVER['HTTP_HOST']=='localhost'){
			$url_this = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$url_this=str_replace("localhost",$url_this);
			dheader("location:".$url_this);
		}

		if(strpos($_SERVER['HTTP_HOST'],'localhost')){
			if($_G['uid']>0){
				if($_GET['mod']=='space'&&($_GET['do']=='friend'||$_GET['do']=='notice'||$_GET['do']=='pm')){
					dheader("location:".$_G['siteurl']);
				}
				if($_GET['mod']=='spacecp'&&$_GET['ac']=='pm'){
					dheader("location:".$_G['siteurl']);
				}
				if($_GET['mod']=='follow'){
					dheader("location:".$_G['siteurl']);
				}
			}
			if($_GET['mod']=='mobile'){
				dheader("location:https://www.cnit618.com/it618.html");
			}
		}
		
		$wxmessage=getcookie('wxmessage');
		
		if($wxmessage!='1'){
			dsetcookie('wxmessage','1',1000);
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php';
			}
			
			if($it618_isok==1&&($it618_body_post_postuser_isok==1||$it618_body_posthf_postuser_isok==1||$it618_body_posthf_posthfuser_isok==1)){
				$iswxsms=1;
			}
			
			if($iswxsms==1){
				if(C::t('#it618_members#it618_members_user_wxsms')->count_by_type_uid('post_postuser',$_G['uid'])==0){
					$id=C::t('#it618_members#it618_members_user_wxsms')->insert(array(
						'it618_uid' => $_G['uid'],
						'it618_type' => 'post_postuser',
						'it618_isok' => 1
					), true);
					
					$id=C::t('#it618_members#it618_members_user_wxsms')->insert(array(
						'it618_uid' => $_G['uid'],
						'it618_type' => 'posthf_postuser',
						'it618_isok' => 1
					), true);
					
					$id=C::t('#it618_members#it618_members_user_wxsms')->insert(array(
						'it618_uid' => $_G['uid'],
						'it618_type' => 'posthf_posthfuser',
						'it618_isok' => 1
					), true);
				}
			}
		}
		
		if($membersset['avatar_ispbdzavatar']==1){
			if($_G['uid']>0){
				if($_GET['mod']=='spacecp'&&$_GET['ac']=='avatar'){
					dheader("location:".$membersset['avatar_pbdzavatarurl']);
				}
			}
		}
		
		$members_certforums=(array)unserialize($it618_members['members_certforums']);
		if($_G['tid']>0&&in_array($_G['fid'], $members_certforums)){
			$tmpurl = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
			$url=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=rzuser&preurl=".urlencode($tmpurl),"?ac=rzuser&preurl=".urlencode($tmpurl));
			$it618_members['members_certforumstip']=str_replace("{url}",$url,$it618_members['members_certforumstip']);
			$it618_members['members_certforumstip']=str_replace(":","&#58;",$it618_members['members_certforumstip']);
			if($_G['uid']>0){
				if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
					showmessage($it618_members['members_certforumstip'], '', array(), array());
				}
			}else{
				showmessage($it618_members['members_certforumstip'], '', array(), array());
			}
		}
		
		if($_GET['action']=='newthread'){
			$members_certforumspost=(array)unserialize($it618_members['members_certforumspost']);
			if(in_array($_G['fid'], $members_certforumspost)){
				$tmpurl = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
				$url=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=rzuser&preurl=".urlencode($tmpurl),"?ac=rzuser&preurl=".urlencode($tmpurl));
				$it618_members['members_certforumsposttip']=str_replace("{url}",$url,$it618_members['members_certforumsposttip']);
				$it618_members['members_certforumsposttip']=str_replace(":","&#58;",$it618_members['members_certforumsposttip']);
				if($_G['uid']>0){
					if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
						showmessage($it618_members['members_certforumsposttip'], '', array(), array());
					}
				}else{
					showmessage($it618_members['members_certforumsposttip'], '', array(), array());
				}
			}
		}
		
		if($_GET['action']=='reply'){
			$members_certforumshf=(array)unserialize($it618_members['members_certforumshf']);
			if(in_array($_G['fid'], $members_certforumshf)){
				$tmpurl = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
				$url=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=rzuser&preurl=".urlencode($tmpurl),"?ac=rzuser&preurl=".urlencode($tmpurl));
				$it618_members['members_certforumshftip']=str_replace("{url}",$url,$it618_members['members_certforumshftip']);
				$it618_members['members_certforumshftip']=str_replace(":","&#58;",$it618_members['members_certforumshftip']);
				if($_G['uid']>0){
					if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
						showmessage($it618_members['members_certforumshftip'], '', array(), array());
					}
				}else{
					showmessage($it618_members['members_certforumshftip'], '', array(), array());
				}
			}
		}
		
		if($_G['uid']>0){
			if($_GET['mod']=='logging'&&$_GET['action']=='logout'&&(!isset($_GET['handlekey']))){
				if($it618_members['members_islogout']==1){
					clearcookies();
					$_G['groupid'] = $_G['member']['groupid'] = 7;
					$_G['uid'] = $_G['member']['uid'] = 0;
					$_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';
					$_G['setting']['styleid'] = $this->setting['styleid'];
					
					dheader("location:".$_SERVER['HTTP_REFERER']);
				}else{
					$tmpurl=$_SERVER['HTTP_REFERER'];
					if($tmpurl=='')$tmpurl=$_G['siteurl'];
					dsetcookie('it618_loginoutpreurl',$tmpurl,31536000);
				}
			}
			
			$it618_tbtel=getcookie('it618_tbtel');
			if($it618_tbtel!=1){
				dsetcookie('it618_tbtel','1',60);
				if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])==0){
					$mobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=".$_G['uid']);
					if($mobile!=''){
						$id=C::t('#it618_members#it618_members_user')->insert(array(
							'it618_uid' => $_G['uid'],
							'it618_tel' => $mobile,
							'it618_time' => $_G['timestamp']
						), true);
					}
				}
			}
			
			if($it618_members['members_sitetelbd']==1){
				$tmparr1=explode("it618_members",$_GET['id']);
				$tmparr2=explode("it618_wxmini",$_GET['id']);
				$tmparr3=explode(":ajax",$_GET['id']);
				
				if(count($tmparr1)==1&&count($tmparr2)==1&&count($tmparr3)==1){
					$it618_sitetelbd=getcookie('it618_sitetelbd');
					if($it618_sitetelbd!=1){
						dsetcookie('it618_sitetelbd','1',10);
						if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])==0){
							require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
							$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=sitetelbd&preurl=".urlencode($url_this),"?ac=sitetelbd&preurl=".urlencode($url_this));
							dheader("location:$uhomeurl");
						}else{
							dsetcookie('it618_sitetelbd','1',3600*30);
						}
					}
				}
			}
			
			if($_GET['mod']!='patch'&&$_GET['mod']!='ajax'){
				if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/visitset.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_members/config/visitset.php';
				}
				if($visitset['isok']==1){
					$isokuid=0;
					if($visitset['okuids']!=''){
						$tmpvisituids=explode(",",$visitset['okuids']);
						if(in_array($_G['uid'], $tmpvisituids)){
							$isokuid=1;
						}
					}
					
					$isvisit=0;
					if($isokuid==0){
						if($visitset['uids']!=''){
							$tmpvisituids=explode(",",$visitset['uids']);
							if(in_array($_G['uid'], $tmpvisituids)){
								$isvisit=1;
							}
						}else{
							$isvisit=1;	
						}
					}
					
					if($isvisit==1){
						$tmpgetid=$_GET['id'].'@';
						$tmparrvisit1=explode(":ajax@",$tmpgetid);
						$tmparrvisit2=explode(":js@",$tmpgetid);
						if(count($tmparrvisit1)==1&&count($tmparrvisit2)==1){
							require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
							
							if($_GET['mod']=="topicadmin"&&$_GET['action']=="moderate"&&$_GET['operation']=="delete"){
								$tids="#";
								foreach($_GET['moderate'] as $key => $tid) {
									$tid=intval($tid);
									$tids.=",".$tid;
								}
								$tids=str_replace("#,","",$tids);
							}
							
							if($_GET['mod']=="post"&&$_GET['action']=="edit"&&$_GET['delete']==1){
								$tid=intval($_GET['tid']);
							}
							
							$tmptime=it618_members_getvisit($_G['uid'],$visitset,$tid);
							if($tmptime>0){
								$visitset['about']=str_replace("{time}",$tmptime,$visitset['about']);
								echo '
									<html>
									<head>
										<meta http-equiv="content-type" content="text/html;charset='.CHARSET.'"/>
										<meta name="viewport" content="width=device-width, initial-scale=1"/> 
										<title>'.$it618_members_lang['s881'].'</title>
										<style>
										body{background-color:#fff}
										</style>
										<table style="width:100%;"><tr>
										<tr><td align="center" style="font-size:15px;color:red;padding-top:150px">
										'.$visitset['about'].'
										</td></tr>
										</table>
									</head>
									</html>
									';
								exit;
							}
						}
					}
				}
			}
		}
		
		if($it618_members['members_ischeckbd']==1){
			if($it618_members["members_bdtype"]==1&&$_GET['action']=='newthread')$flag=1;
			if($it618_members["members_bdtype"]==2&&$_GET['action']=='reply')$flag=1;
			if($it618_members["members_bdtype"]==3&&($_GET['action']=='newthread'||$_GET['action']=='reply'))$flag=1;
			
			if($_GET['mod']=='post'&&$flag==1&&$_G['uid']>0){
				
				$members_usergroups = unserialize($it618_members["members_usergroups"]);
				$members_forums=unserialize($it618_members['members_forums']);
				
				if(!in_array($_G['groupid'], $members_usergroups)) return;
				if(!in_array($_G['fid'], $members_forums)) return;
				
				$count1=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid']);
				$count2=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_wxuser')." WHERE it618_uid=".$_G['uid']);
				
				if($it618_members['members_bdusertype']==1){
					if($count1>0){
						return;
					}
				}
				
				if($it618_members['members_bdusertype']==2){
					if($count2>0){
						return;
					}
				}
				
				if($it618_members['members_bdusertype']==3){
					if($count1>0||$count2>0){
						return;
					}
				}
				
				if($it618_members['members_bdusertype']==4){
					if($count1>0&&$count2>0){
						return;
					}
				}
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
				$tmpurl = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
				$url=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&preurl=".urlencode($tmpurl),"?preurl=".urlencode($tmpurl));
					
				if(members_is_mobile()){
					if($it618_members['members_iswapbddheader']==1){
						$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=bdabout","?ac=bdabout");
						dheader("location:$uhomeurl");
					}
					$it618_members['members_wapbdabout']=str_replace("{url}",$url,$it618_members['members_wapbdabout']);
					$it618_members['members_wapbdabout']=str_replace(":","&#58;",$it618_members['members_wapbdabout']);
					showmessage($it618_members['members_wapbdabout'], '', array(), array());
				}else{
					$it618_members['members_pcbdabout']=str_replace("{url}",$url,$it618_members['members_pcbdabout']);
					$it618_members['members_pcbdabout']=str_replace(":","&#58;",$it618_members['members_pcbdabout']);
					showmessage($it618_members['members_pcbdabout'], '', array(), array());
				}
				
			}
			
		}
		
	}
	
	function post_message_base($value){
		global $_G,$it618_members_lang;
		
		$type=$value['param'][0];
		$fid=$value['param'][2]['fid'];
		$tid=$value['param'][2]['tid'];
		$pid=$value['param'][2]['pid'];
	
		if($type=='post_edit_succeed'){
			
		}
		
		if($type=='post_newthread_succeed'){
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
			
			it618_members_sendmessage('post_postuser',$tid);
			it618_members_sendmessage('post_admin',$tid);
		}
		
		if($type=='post_reply_succeed'){
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
			it618_members_sendmessage('posthf_postuser',$tid,$pid);
			it618_members_sendmessage('posthf_posthfuser',$tid,$pid);
			it618_members_sendmessage('posthf_admin',$tid,$pid);
		}
	}
}

class plugin_it618_members_home extends plugin_it618_members_base{
	function space_profile_baseinfo_top(){
		global $_G,$it618_members_lang;
		$it618_members = $_G['cache']['plugin']['it618_members'];
			
		if($_GET['uid']>0){
			$members_pcbd='';
			$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".intval($_GET['uid']));
		
			if($count>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
				$members_pcbd.='<img src="source/plugin/it618_members/images/telbd.png" style="vertical-align:middle;margin-top:-3px;height:15px"> <font color="#888">'.$it618_members_lang['s110'].'</font> ';
			}
			
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok(intval($_GET['uid']))>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
				$members_pcbd.='<img src="source/plugin/it618_members/images/rzuser.png" style="vertical-align:middle;margin-top:-3px;height:16px"> <font color="#888">'.$it618_members_lang['s811'].'</font> ';
			}
			
			if(C::t('#it618_members#it618_members_qyrz')->count_by_uid_rzok(intval($_GET['uid']))>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
				$members_pcbd.='<img src="source/plugin/it618_members/images/qyrz.png" style="vertical-align:middle;margin-top:-3px;height:16px"> <font color="#888">'.$it618_members_lang['t130'].'</font> ';
			}
		}
		
		return $members_pcbd;
	}
}

class plugin_it618_members extends plugin_it618_members_base {
	
	function common() {
		$this->common_base();
	}
	
	function post_message($value){
		$this->post_message_base($value);
	}
	
	function global_login_extra(){
		global $_G,$it618_members_lang;
		$it618_members = $_G['cache']['plugin']['it618_members'];
		if($it618_members['members_isok']==1){
			$url_this = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

			require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
			
			$wxurl='href="javascript:" onclick="it618_showsms(\'it618_loginwx\',\'plugin.php?id=it618_members:login&win_wx\');setTimeout(\'getwxuid()\',2000);"';
			$qqurl='href="plugin.php?id=it618_members:qqlogin"';
			
			$members_loginurl=$it618_members['members_loginurls'];
			
			$members_loginurl=str_replace('{wxurl}',$wxurl,$members_loginurl);
			$members_loginurl=str_replace('{qqurl}',$qqurl,$members_loginurl);
			
			return $members_loginurl;

		}
	}
	
	function global_usernav_extra1(){
		global $_G,$it618_members_lang;
		$it618_members = $_G['cache']['plugin']['it618_members'];
		
		if($_G['uid']<=0)return '';
		
		if(!($it618_members['members_ishome']==1||$it618_members['members_ishome']==2))return '';
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
		}
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php';
		}
		
		if($it618_members['members_telbdmode']>0){
			$imgstr='';
			$count1=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid']);
			if($count1==0){
				$imgstr='0';
			}
			$bdstr='<img src="source/plugin/it618_members/images/telbd'.$imgstr.'.png" class="it618_members" style="vertical-align:middle;margin-top:-3px;height:15px;cursor:pointer">';
		}
		
		if($wxjk_mode>0&&$wxjk_mode<=2){
			$imgstr='';
			$count2=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_wxuser')." WHERE it618_uid=".$_G['uid']);
			if($count2==0){
				$imgstr='0';
			}
			$bdstr.='<img src="source/plugin/it618_members/images/wxbd'.$imgstr.'.png" class="it618_members" style="vertical-align:middle;margin-top:-2px;height:17px;cursor:pointer">';
		}
		
		if($qqjk_isok==1){
			$imgstr='';
			if(!$it618_members_qquser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_qquser')." WHERE it618_uid=".$_G['uid'])){
				$imgstr='0';
			}
			$bdstr.='<img src="source/plugin/it618_members/images/qqbd'.$imgstr.'.png" class="it618_members" style="vertical-align:middle;margin-top:-2px;height:16px;cursor:pointer">';
		}
		
		if($bdstr!=''){
			$bdstr=' <span class="pipe">|</span>'.$bdstr.' ';
		}
		
		if($it618_members['members_certtype']>1){
			$imgstr='';
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
				$imgstr='0';
			}
			$rzstr.='<img src="source/plugin/it618_members/images/rzuser'.$imgstr.'.png" class="it618_members" style="vertical-align:middle;margin-top:-2px;height:19px;cursor:pointer">';
			$rzstr=' <span class="pipe">|</span>'.$rzstr.' ';
		}
		
		return '<span class="pipe">|</span><a href="javascript:" class="it618_members"><img src="source/plugin/it618_members/images/logo.png" style="vertical-align:middle;margin-top:-3px;height:16px"> '.$it618_members['members_homename'].'</a>'.$rzstr.$bdstr;
	}
	
	function global_footer() {
		global $_G,$IsCredits;
		$it618_members = $_G['cache']['plugin']['it618_members'];
		
		if($it618_members['members_isok']==1&&$_G['uid']<=0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
			$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login");
						
			$members_isok='<script type="text/javascript">
						IT618_MEMBERS(document).ready(function() {
							IT618_MEMBERS("[onclick*=\'viewlostpw=1\']").each(function (i, o) {
								IT618_MEMBERS(o).attr("onclick","showWindow(\'it618_showsms\',\'plugin.php?id=it618_members:showsms&ac=password\')");
							});
							
							IT618_MEMBERS("[onclick*=\'login\']").each(function (i, o) {
								var tmpstr = IT618_MEMBERS(o).attr("onclick");
								var tmparr1=tmpstr.split("plugin.php");
								var tmparr2=tmpstr.split("618");
								if(tmparr1.length==1&&tmparr2.length==1)IT618_MEMBERS(o).attr("onclick","showWindow(\'it618_login\',\'plugin.php?id=it618_members:login&lsSubmit\');return false;");
							});
							
							IT618_MEMBERS("[onclick*=\'viewlostpw=1\']").each(function (i, o) {
								IT618_MEMBERS(o).attr("onclick","showWindow(\'it618_showsms\',\'plugin.php?id=it618_members:showsms&ac=password\')");
							});
							
							IT618_MEMBERS("[onclick*=\'mod=misc&action=pay\']").each(function (i, o) {
								IT618_MEMBERS(o).attr("onclick","showWindow(\'it618_login\',\'plugin.php?id=it618_members:login&lsSubmit\')");
							});
							
							IT618_MEMBERS("[onclick*=\'reply\']").each(function (i, o) {
								IT618_MEMBERS(o).attr("onclick","showWindow(\'it618_login\',\'plugin.php?id=it618_members:login&lsSubmit\')");
							});
							
							IT618_MEMBERS("[onclick*=\'attachpay\']").each(function (i, o) {
								IT618_MEMBERS(o).attr("onclick","showWindow(\'it618_login\',\'plugin.php?id=it618_members:login&lsSubmit\')");
							});
							
							IT618_MEMBERS("[href*=\'favorite\']").each(function (i, o) {
								IT618_MEMBERS(o).attr("onclick","showWindow(\'it618_login\',\'plugin.php?id=it618_members:login&lsSubmit\')");
							});
							
							IT618_MEMBERS("[href*=\'addfriend\']").each(function (i, o) {
								IT618_MEMBERS(o).attr("onclick","showWindow(\'it618_login\',\'plugin.php?id=it618_members:login&lsSubmit\')");
							});
							
							IT618_MEMBERS("[href*=\'showmsg\']").each(function (i, o) {
								IT618_MEMBERS(o).attr("onclick","showWindow(\'it618_login\',\'plugin.php?id=it618_members:login&lsSubmit\')");
							});
							
							if(IT618_MEMBERS("#messagelogin").length>0){
								IT618_MEMBERS("#messagelogin").hide();
								location.href="'.$loginurl.'";
							}
						});
						
						function lsSubmit(){
							if(IT618_MEMBERS("#it618_login").length==0){
								var btnclick=0;
								if(IT618_MEMBERS("#ls_username").val()!=""&&IT618_MEMBERS("#ls_password").val()!=""){
									btnclick=1;
									setTimeout(\'it618login1()\',800);
								}
								it618_showsms(\'it618_login\',\'plugin.php?id=it618_members:login&lsSubmit=\'+btnclick);
							}else{
								it618login();
							}
							return false;
						}
						
						function it618_showsms(title,url){
							showWindow(title,url)
						}
						</script>';
		}
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
		if($IsCredits==1){
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
			$it618_credits_buygroup=it618_credits_getcredits('it618_discuz','#vippaybtn','plugin.php?id=it618_credits:do&dotype=buygroup');
		}
		
		$it618_members['members_jquerys']=$it618_members['members_jquerys'].'|spacecp&ac=avatar';
		if($it618_members['members_jquerys']!=''){
			$tmparr=explode("|",$it618_members['members_jquerys']);
			for($i=0;$i<count($tmparr);$i++){
				$tmparr1=explode($tmparr[$i],$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
				if(count($tmparr1)>1){
					$tmpjs='<script>var IT618_MEMBERS=jQuery;</'.'SCRIPT>';
					break;
				}
				if($_SERVER['REQUEST_URI']=='/'&&$tmparr[$i]=='@'){
					$tmpjs='<script>var IT618_MEMBERS=jQuery;</'.'SCRIPT>';
					break;
				}
			}
		}
		
		if($tmpjs=='')$tmpjs='<SCRIPT src="source/plugin/it618_members/js/jquery.js" type=text/javascript></'.'SCRIPT>';
		
		return $tmpjs.$members_isok.it618_members_getmembers($_GET['id'],'.it618_members').it618_members_getmembers($_GET['id'],'#it618_members').'<div id="it618_members" style="display:none"></div>'.$it618_credits_buygroup;
	}
	
}

class plugin_it618_members_forum extends plugin_it618_members{
	function viewthread_sidetop_output(){
		global $_G,$it618_members_lang,$postlist;
		$it618_members = $_G['cache']['plugin']['it618_members'];
		
		$viewthread_sidetop=array();
		
		foreach($postlist as $id => $post){
			if($post['authorid']>0){
				$members_pcbd='';
				$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$post['authorid']);
				if($count>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
					$members_pcbd.='<img src="source/plugin/it618_members/images/telbd.png" style="vertical-align:middle;margin-top:-3px;height:15px;"> <font color="#888">'.$it618_members_lang['s110'].'</font><br>';
				}
				
				if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($post['authorid'])>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
					$members_pcbd.='<img src="source/plugin/it618_members/images/rzuser.png" style="vertical-align:middle;margin-top:-3px;height:16px;"> <font color="#888">'.$it618_members_lang['s811'].'</font><br>';
				}
				
				if(C::t('#it618_members#it618_members_qyrz')->count_by_uid_rzok($post['authorid'])>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
					$members_pcbd.='<img src="source/plugin/it618_members/images/qyrz.png" style="vertical-align:middle;margin-top:-3px;height:16px;"> <font color="#888">'.$it618_members_lang['t130'].'</font><br>';
				}
				
				$viewthread_sidetop[]='<div style="margin-top:-3px;margin-bottom:10px;text-align:center;line-height:20px">'.$members_pcbd.'</div>';
			}

		}
		
		return $viewthread_sidetop;
	}
}

class mobileplugin_it618_members extends plugin_it618_members_base {
	function common() {
		$this->common_base();
	}
	
	function post_message($value){
		$this->post_message_base($value);
	}
}

class mobileplugin_it618_members_forum extends mobileplugin_it618_members{
	
}
//From: Dism_taobao-com
?>