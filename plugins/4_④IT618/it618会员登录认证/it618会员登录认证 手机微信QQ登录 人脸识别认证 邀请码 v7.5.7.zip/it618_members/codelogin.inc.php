<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_members;
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

if($it618_members['members_regtourl']!=''){
	$tmparr=explode("|",$it618_members['members_regtourl']);
	$preurl=$tmparr[1];
}else{
	if($it618_members['members_tourl']!=''){
		$tmparr=explode("|",$it618_members['members_tourl']);
		$preurl=$tmparr[1];
	}
}

$codeid=intval($_GET['codeid']);
dsetcookie('it618_codeid',$codeid,31536000);

if($preurl=='')$preurl=$_G['siteurl'];

if($_G['uid']>0){
	dheader("location:$preurl");
}else{
	$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login&it618wxlogin","?it618wxlogin");
	dheader("location:$loginurl");
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>