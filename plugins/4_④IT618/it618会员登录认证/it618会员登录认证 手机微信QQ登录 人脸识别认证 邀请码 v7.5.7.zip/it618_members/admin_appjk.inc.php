<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

if($reabc[4]!='8')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function/it618_members.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_appjk&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_appjk');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_appjk' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/
?>