<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_members_sms`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_username` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_code` varchar(50) NOT NULL,
  `it618_yqcode` varchar(50) NOT NULL,
  `it618_ip` varchar(20) NOT NULL,
  `it618_bz` varchar(255) NOT NULL,
  `it618_okbz` varchar(50) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_jktype` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  `it618_ismmok` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_login`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` varchar(10) NOT NULL,
  `it618_ip` varchar(20) NOT NULL,
  `it618_bz` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_visit`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_visit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_url` varchar(255) NOT NULL,
  `it618_ip` varchar(20) NOT NULL,
  `it618_bz` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_visitcount`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_visitcount` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bzmd5` varchar(32) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_kdsale`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_kdsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_kdcomid` varchar(50) NOT NULL,
  `it618_kdid` varchar(50) NOT NULL,
  `it618_saletype` varchar(50) NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_jktype` varchar(50) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_message` varchar(50) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_data` mediumtext NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_user`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(50) NOT NULL,
  `it618_ischeck` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_province` varchar(50) NOT NULL,
  `it618_catname` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_userlogin`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_userlogin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ip` varchar(20) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_wxuser`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_wxuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wxopenid` varchar(50) NOT NULL,
  `it618_wxunionid` varchar(50) NOT NULL,
  `it618_wxname` varchar(100) NOT NULL,
  `it618_wxok` int(10) unsigned NOT NULL,
  `it618_wxoktime` int(10) unsigned NOT NULL,
  `it618_checktime` int(10) unsigned NOT NULL,
  `it618_isreg` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_authcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tmpwxopenid` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_qquser`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_qquser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_qqopenid` varchar(50) NOT NULL,
  `it618_qqname` varchar(100) NOT NULL,
  `it618_isreg` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_authcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_rzuser`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_rzuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(50) NOT NULL,
  `it618_sex` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_cardid` varchar(50) NOT NULL,
  `it618_cardimg1` varchar(300) NOT NULL,
  `it618_cardimg2` varchar(300) NOT NULL,
  `it618_cardimg3` varchar(300) NOT NULL,
  `it618_rzvideo` varchar(300) NOT NULL,
  `it618_rzmodes` varchar(10) NOT NULL,
  `it618_wx` varchar(50) NOT NULL,
  `it618_qq` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_email` varchar(50) NOT NULL,
  `it618_about` varchar(300) NOT NULL,
  `it618_isedit` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_statebz` varchar(3000) NOT NULL,
  `it618_key` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_apicount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_checkcount` int(10) unsigned NOT NULL,
  `it618_checktime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_rzapisale`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_rzapisale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order_no` varchar(50) NOT NULL,
  `it618_score` float(9,2) NOT NULL,
  `it618_datamsg` varchar(300) NOT NULL,
  `it618_incorrect` varchar(10) NOT NULL,
  `it618_about` varchar(300) NOT NULL,
  `it618_msg` varchar(300) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_vrzapisale`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_vrzapisale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order_no` varchar(50) NOT NULL,
  `it618_is_life` int(10) unsigned NOT NULL,
  `it618_life_score` float(9,2) NOT NULL,
  `it618_hack_score` float(9,2) NOT NULL,
  `it618_face_score` float(9,2) NOT NULL,
  `it618_image_id` varchar(50) NOT NULL,
  `it618_datamsg` varchar(300) NOT NULL,
  `it618_incorrect` varchar(10) NOT NULL,
  `it618_about` varchar(300) NOT NULL,
  `it618_msg` varchar(300) NOT NULL,
  `it618_complexity` int(10) unsigned NOT NULL,
  `it618_motions` varchar(10) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_qyrz`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_qyrz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_qyname` varchar(50) NOT NULL,
  `it618_creditcode` varchar(50) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_cardid` varchar(50) NOT NULL,
  `it618_cardimg1` varchar(300) NOT NULL,
  `it618_cardimg2` varchar(300) NOT NULL,
  `it618_yyzzimg` varchar(300) NOT NULL,
  `it618_sqsimg` varchar(300) NOT NULL,
  `it618_wx` varchar(50) NOT NULL,
  `it618_qq` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_email` varchar(50) NOT NULL,
  `it618_isedit` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_statebz` varchar(3000) NOT NULL,
  `it618_key` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_checktime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_user_wxsms`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_user_wxsms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_wxcodelogin`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_wxcodelogin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_wxcodebd`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_wxcodebd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(32) NOT NULL,
  `it618_openid` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_checks`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_checks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_about` varchar(5000) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_answer` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_messages_tpl`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_messages_tpl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_content` varchar(1000) NOT NULL,
  `it618_jktype` varchar(50) NOT NULL,
  `it618_sign` varchar(255) NOT NULL,
  `it618_tplid` varchar(255) NOT NULL,
  `it618_value` varchar(2000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_messages_tpl_wx`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_messages_tpl_wx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_tplid` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_label` varchar(255) NOT NULL,
  `it618_value` varchar(2000) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_yqcode`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_yqcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_code` varchar(20) NOT NULL,
  `it618_bz` varchar(255) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_yqcode_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_yqcode_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(50) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_code` varchar(20) NOT NULL,
  `it618_bz` varchar(255) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_paycode` varchar(32) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_paytype` varchar(10) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_paytime` int(10) unsigned NOT NULL,
  `it618_usetime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
	
DROP TABLE IF EXISTS `pre_it618_members_smsapi`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_smsapi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_sid` varchar(50) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(10) NOT NULL,
  `it618_type` varchar(255) NOT NULL,
  `it618_sign` varchar(50) NOT NULL,
  `it618_tplid` varchar(100) NOT NULL,
  `it618_param` varchar(255) NOT NULL,
  `it618_bz` int(10) unsigned NOT NULL,
  `it618_plugin` varchar(50) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_about` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_members_editwork`;
CREATE TABLE IF NOT EXISTS `pre_it618_members_editwork` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvdXBncmFkZS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvaW5zdGFsbC5waHA='));
?>