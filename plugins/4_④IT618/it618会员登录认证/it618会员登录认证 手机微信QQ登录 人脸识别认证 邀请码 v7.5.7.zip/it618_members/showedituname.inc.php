<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

$wap=$_GET['wap'];

if($_G['uid']<=0){
	$showmessage='<a href="member.php?mod=logging&action=login">'.$it618_members_lang['s40'].'</a>';
}else{
	if($membersset['uname_isedit']==1){
		$uname_edituids=explode(",",$membersset['uname_edituids']);
		if(in_array($_G['uid'], $uname_edituids)){
			$strtmp=$it618_members_lang['t85'];
			$strtmp=str_replace("{username}",$_G['username'],$strtmp);
		}else{
			if($membersset['uname_editcredits']>0&&$membersset['uname_editcount']>0){
				$strtmp=$it618_members_lang['t84'];
				$strtmp=str_replace("{username}",$_G['username'],$strtmp);
				
				$cname=$_G['setting']['extcredits'][$membersset['uname_editcredits']]['title'];
				$strtmp=str_replace("{count1}",$membersset['uname_editcount'].$cname,$strtmp);
				
				$creditnum=DB::result_first("select extcredits".$membersset['uname_editcredits']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				$strtmp=str_replace("{count2}",$creditnum.$cname,$strtmp);
				
			}else{
				$strtmp=$it618_members_lang['t124'];
				$strtmp=str_replace("{username}",$_G['username'],$strtmp);
			}
		}
	}else{
		$showmessage=$it618_members_lang['t93'];
	}
}

$_G['mobiletpl'][2]='/';

if($wap!=1)include template('common/header');
include template('it618_members:showedituname');
if($wap!=1)include template('common/footer');
?>