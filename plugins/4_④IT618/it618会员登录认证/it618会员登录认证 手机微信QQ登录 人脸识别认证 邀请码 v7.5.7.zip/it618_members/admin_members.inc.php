<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if(count($reabc)!=13)return;

loadcache('plugin');
$it618_members = $_G['cache']['plugin']['it618_members'];

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function/it618_members.func.php';

if($reabc[10]!='e')return;

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_members&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_import', 'admin_members','admin_import_wx',  'admin_members_wx','admin_import_qq', 'admin_members_qq','admin_import_rz','admin_rzapisale','admin_vrzapisale', 'admin_members_rz', 'admin_members_qyrz');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_members' : $_GET['cp'];

if(strpos($_SERVER['HTTP_HOST'],'localhost')){
	$cp = !in_array($_GET['cp'], $cparray) ? 'admin_members_rz' : $_GET['cp'];
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_import'.$urls.'"><span>'.$it618_members_lang['s235'].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_members'.$urls.'"><span>'.$it618_members_lang['s192'].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_import_wx'.$urls.'"><span>'.$it618_members_lang['s303'].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_members_wx'.$urls.'"><span>'.$it618_members_lang['s234'].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_import_qq'.$urls.'"><span>'.$it618_members_lang['s482'].'</span></a></li>
<li '.$strtmp[5].'><a href="'.$hosturl.'plugins&cp=admin_members_qq'.$urls.'"><span>'.$it618_members_lang['s483'].'</span></a></li>
<li '.$strtmp[6].'><a href="'.$hosturl.'plugins&cp=admin_import_rz'.$urls.'"><span>'.$it618_members_lang['s791'].'</span></a></li>
<li '.$strtmp[7].'><a href="'.$hosturl.'plugins&cp=admin_rzapisale'.$urls.'"><span>'.$it618_members_lang['s816'].'</span></a></li>
<li '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_vrzapisale'.$urls.'"><span>'.$it618_members_lang['s890'].'</span></a></li>
<li '.$strtmp[9].'><a href="'.$hosturl.'plugins&cp=admin_members_rz'.$urls.'"><span>'.$it618_members_lang['s459'].'</span></a></li>
<li '.$strtmp[10].'><a href="'.$hosturl.'plugins&cp=admin_members_qyrz'.$urls.'"><span>'.$it618_members_lang['s727'].'</span></a></li>
</ul></div>';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/
?>