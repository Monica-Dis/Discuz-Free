<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function pay_success($out_trade_no){
	global $_G;
	
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
		if($it618_salepay['it618_state']==1)return;
	}else{
		return;	
	}
	
	$salepay_saletype=$it618_salepay['it618_saletype'];
	$salepay_saleid=$it618_salepay['it618_saleid'];
	$salepay_paytype=$it618_salepay['it618_paytype'];
	$salepay_payid=$it618_salepay['it618_payid'];
	$salepay_url=$it618_salepay['it618_url'];
	$salepay_wap=$it618_salepay['it618_wap'];

	require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_members_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_members_delsalework();
		}
	}
	C::t('#it618_members#it618_members_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	
	if($salepay_saletype=='0201'){
		$it618_members_yqcode_sale=C::t('#it618_members#it618_members_yqcode_sale')->fetch_by_id($salepay_saleid);
			
		if($it618_members_yqcode_sale['it618_state']!=1){
					
			$it618_members_yqcode=C::t('#it618_members#it618_members_yqcode')->fetch_by_sale();
			
			C::t('#it618_members#it618_members_yqcode_sale')->update($salepay_saleid,array(
				'it618_type' => 1,
				'it618_code' => $it618_members_yqcode['it618_code'],
				'it618_state' => 1,
				'it618_paytype' => $salepay_paytype,
				'it618_payid' => $salepay_payid,
				'it618_paytime' => $_G['timestamp']
			));

			C::t('#it618_members#it618_members_yqcode')->update_it618_state(1,$it618_members_yqcode['id']);
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);

			sendmessage_yqmsale($it618_members_yqcode_sale['id']);
			
			it618_members_delsalework();return 'success';

		}
	
	}

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>