<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

if($_GET['type']=='wx'){
	$titlestr=$it618_members_lang['s548'];
	$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout3');
	$aboutstr=$it618_members_set['setvalue'];
	
	$regurl=it618_members_getrewrite("members_reg","","plugin.php?id=it618_members:reg&login_wx&aboutbtn","?login_wx&aboutbtn");
	$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login&login_wx&aboutbtn","?login_wx&aboutbtn");
}

if($_GET['type']=='qq'){
	$titlestr=$it618_members_lang['s549'];
	$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('qqjk_qqabout1');
	$aboutstr=$it618_members_set['setvalue'];
	
	$regurl=it618_members_getrewrite("members_reg","","plugin.php?id=it618_members:reg&login_qq&aboutbtn","?login_qq&aboutbtn");
	$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login&login_qq&aboutbtn","?login_qq&aboutbtn");
}


$wap=$_GET['wap'];

$_G['mobiletpl'][2]='/';

if($wap!=1)include template('common/header');
include template('it618_members:showabout');
if($wap!=1)include template('common/footer');
?>