<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

if(members_is_mobile()){
	$wap=1;
}

if($_G['uid']<=0){
	$showmessage='<a href="member.php?mod=logging&action=login">'.$it618_members_lang['s40'].'</a>';
}else{
	if($it618_members['members_qycerttype']>1){
		
		$tmpcharset='charset="utf-8"';
		
		$ispost=1;
		$confirmstr=$it618_members_lang['s700'];
		if($it618_members_qyrz=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_qyrz')." WHERE it618_uid=".$_G['uid'])){
			if($it618_members_qyrz['it618_cardimg1']!='')$src1='src="'.$it618_members_qyrz['it618_cardimg1'].'"';
			if($it618_members_qyrz['it618_cardimg2']!='')$src2='src="'.$it618_members_qyrz['it618_cardimg2'].'"';
			if($it618_members_qyrz['it618_yyzzimg']!='')$src3='src="'.$it618_members_qyrz['it618_yyzzimg'].'"';
			if($it618_members_qyrz['it618_sqsimg']!='')$src4='src="'.$it618_members_qyrz['it618_sqsimg'].'"';
			
			global $oss;
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/php/aliyunossconfig.php')){
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/php/aliyunossconfig.php';
				if($it618_isok==1){
					$oss='&oss';
				}
			}
			
			if($it618_members_qyrz['it618_state']==1){
				if($it618_members['members_qyisedit']==1){
					$qyrztitle='<img src="/source/plugin/it618_members/images/check_right.gif" style="vertical-align:middle;margin-top:-4px"> '.$it618_members_lang['s763'];
					$confirmstr=$it618_members_lang['s701'];
				}else{
					$qyrztitle='<img src="/source/plugin/it618_members/images/check_right.gif" style="vertical-align:middle;margin-top:-4px"> '.$it618_members_lang['s762'];
					$ispost=0;
				}
			}else if($it618_members_qyrz['it618_state']==2){
				$qyrztitle=$it618_members_lang['s764'];
				$qyrztitle=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']),$qyrztitle);
				$ispost=0;
			}else{
				$qyrztitle='<img src="/source/plugin/it618_members/images/check_error.gif" style="vertical-align:middle;margin-top:-4px"> '.$it618_members_lang['s766'];
				$qyrztitle=str_replace("{checktime}",date('Y-m-d H:i:s', $it618_members_qyrz['it618_checktime']),$qyrztitle);
				if($it618_members_rzuser['it618_statebz']!='')$qyrztitle.='<br><font color=blue>'.$it618_members_lang['s706'].$it618_members_qyrz['it618_statebz'].'</font>';
			}
		}else{
			$qyrztitle=$it618_members_lang['s765'];	
		}
		
		if($ispost==1){
			if($it618_members['members_qycerttype']==3){
				if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
					$showmessage=$it618_members_lang['s730'];
				}
			}
		}
	}else{
		$showmessage=$it618_members_lang['s460'];
	}
}

$_G['mobiletpl'][2]='/';

include template('it618_members:showqyrz');
?>