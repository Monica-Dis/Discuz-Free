<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_members_user extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_members_user';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}
	
	public function fetch_id_by_uid($uid) {
		return DB::result_first("SELECT id FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function fetch_tel_by_uid($uid) {
		return DB::result_first("SELECT it618_tel FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function fetch_it618_username_bytel($it618_tel) {
		$uid = DB::result_first("SELECT it618_uid FROM %t WHERE it618_tel=%s", array($this->_table, $it618_tel));
		return DB::result_first("select username from ".DB::table('common_member')." where uid=%d", array($uid));
	}
	
	public function fetch_bytel($it618_tel) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_tel=%s", array($this->_table, $it618_tel));
	}
	
	public function delete_by_tel($it618_tel) {
		DB::query("DELETE FROM %t WHERE it618_tel=%s", array($this->_table, $it618_tel));
	}
	
	public function fetch_uid_byusername($username) {
		return DB::result_first("select uid from ".DB::table('common_member')." where username=%s", array($username));
	}
	
	public function fetch_username_byuid($uid) {
		return DB::result_first("select username from ".DB::table('common_member')." where uid=%d", array($uid));
	}
	
	public function fetch_uid_bytel($tel) {
		return DB::result_first("select it618_uid FROM %t WHERE it618_tel=%s", array($this->_table, $tel));
	}
	
	public function fetch_profile_bytel($tel) {
		return DB::fetch_first("select * from ".DB::table('common_member_profile')." WHERE mobile=%s", array($tel));
	}
	
	public function update_it618_tel_by_uid($tel,$uid) {
		DB::query("UPDATE ".DB::table('it618_brand_card')." SET it618_tel=%s WHERE it618_uid=%d", array($tel, $uid));
	}
	
	public function count_by_tel($it618sql='', $it618tel='') {
		$condition = $this->make_query_condition($it618sql, $it618tel);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_tel($it618sql = '', $it618_tel = '') {
		$condition = $this->make_query_condition($it618sql, $it618_tel);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]", $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql='', $it618tel='', $it618_province = '', $it618_catname = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		
		if(!empty($it618tel)) {
			$parameter[] = $it618tel;
			$wherearr[] = 'it618_tel=%s';
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function count_all_by_search($it618sql = '', $it618orderby='', $it618key = '', $it618_province = '', $it618_catname = '') {
		$condition = $this->make_query_condition1($it618sql, $it618orderby, $it618key, $it618_province, $it618_catname);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $it618key = '', $it618_province = '', $it618_catname = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition1($it618sql, $it618orderby, $it618key, $it618_province, $it618_catname);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition1($it618sql = '', $it618orderby='', $it618key = '', $it618_province = '', $it618_catname = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618key)) {
			$parameter[] = '%'.$it618key.'%';
			$wherearr[] = "it618_tel LIKE %s";
		}
		if(!empty($it618_province)) {
			$parameter[] = $it618_province;
			$wherearr[] = 'it618_province=%s';
		}
		
		if(!empty($it618_catname)) {
			$parameter[] = $it618_catname;
			$wherearr[] = 'it618_catname=%s';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism_taobao-com
?>