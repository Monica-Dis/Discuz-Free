<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_members_yqcode_sale extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_members_yqcode_sale';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_state_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_state=1 AND id=%d", array($this->_table, $id));
	}
	
	public function count_by_code($code) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_code=%s", array($this->_table, $code));
	}
	
	public function count_by_tel($it618sql='', $it618tel='') {
		$condition = $this->make_query_condition($it618sql, $it618tel);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_id_by_tel($it618sql='', $it618tel='') {
		$condition = $this->make_query_condition($it618sql, $it618tel);
		return DB::result_first("SELECT id FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_tel($it618sql = '', $it618_tel = '') {
		$condition = $this->make_query_condition($it618sql, $it618_tel);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]", $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql='', $it618tel='') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		
		if(!empty($it618tel)) {
			$parameter[] = $it618tel;
			$wherearr[] = 'it618_tel=%s';
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function count_all_by_search($it618sql = '', $it618orderby='', $it618key = '') {
		$condition = $this->make_query_condition1($it618sql, $it618orderby, $it618key);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $it618key = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition1($it618sql, $it618orderby, $it618key);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition1($it618sql = '', $it618orderby='', $it618key = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618key)) {
			$parameter[] = '%'.$it618key.'%';
			$wherearr[] = "it618_tel LIKE %s";
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function count_all_by_search_sale($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition_sale($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		return DB::result_first("SELECT count(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function sum_money_by_search_sale($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition_sale($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$tmp = DB::result_first("SELECT SUM(it618_price) FROM %t $condition[0]", $condition[1]);
		if($tmp=='')$tmp=0;
		return $tmp;
	}
	
	public function fetch_all_by_search_sale($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition_sale($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition_sale($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "(it618_tel LIKE %s or it618_code LIKE %s)";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 'it618_paytime>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 'it618_paytime<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function count_all_by_search_sale1($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition_sale1($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		return DB::result_first("SELECT count(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search_sale1($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition_sale1($it618sql, $it618orderby, $it618_name, $it618_uid, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition_sale1($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "it618_tel LIKE %s";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 'it618_usetime>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 'it618_usetime<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_it618_tel($id) {
		DB::query("UPDATE %t SET it618_tel='' WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_it618_code($id,$it618_code) {
		DB::query("UPDATE %t SET it618_code=%s WHERE id=%d", array($this->_table, $it618_code, $id));
	}
	
	public function update_uid_by_code($uid, $type, $usetime, $code) {
		return DB::query("UPDATE %t SET it618_uid=%d,it618_type=%d,it618_usetime=%d,it618_code='' WHERE it618_code=%s", array($this->_table, $uid, $type, $usetime, $code));
	}
	
	public function update_it618_state($id,$it618_state) {
		DB::query("UPDATE %t SET it618_state=%d WHERE id=%d", array($this->_table, $it618_state, $id));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism_taobao-com
?>