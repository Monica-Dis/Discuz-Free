<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_members_wxuser extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_members_wxuser';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}
	
	public function fetch_id_by_uid($uid) {
		return DB::result_first("SELECT id FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function fetch_openid_by_uid($uid) {
		return DB::result_first("SELECT it618_wxopenid FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function fetch_openid_by_uid_id($uid,$id) {
		return DB::result_first("SELECT it618_wxopenid FROM %t WHERE it618_uid=%d and id=%d", array($this->_table, $uid, $id));
	}
	
	public function fetch_by_uid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function fetch_by_uid_auth($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d and it618_authcount>0", array($this->_table, $uid));
	}
	
	public function fetch_by_openid($openid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_wxopenid=%s", array($this->_table, $openid));
	}
	
	public function fetch_by_unionid($unionid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_wxunionid=%s", array($this->_table, $unionid));
	}
	
	public function fetch_by_openid_uid($openid,$uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_wxopenid=%s and it618_uid=%d", array($this->_table, $openid, $uid));
	}
	
	public function count_by_openid_uid($openid,$uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_wxopenid=%s and it618_uid=%d", array($this->_table, $openid, $uid));
	}
	
	public function delete_by_openid_uid($openid,$uid) {
		DB::query("DELETE FROM %t WHERE it618_wxopenid=%s and it618_uid=%d", array($this->_table, $openid, $uid));
	}
	
	public function fetch_uid_byusername($username) {
		return DB::result_first("select uid from ".DB::table('common_member')." where username=%s", array($username));
	}
	
	public function fetch_username_byuid($uid) {
		return DB::result_first("select username from ".DB::table('common_member')." where uid=%d", array($uid));
	}
	
	public function count_by_openid($openid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_wxopenid=%s", array($this->_table, $openid));
	}
	
	public function count_by_uid_auth($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d and it618_authcount>0", array($this->_table, $uid));
	}
	
	public function fetch_all_by_openid($openid) {
		$data = array();
		$query = DB::query("SELECT * FROM %t WHERE it618_wxopenid=%s", array($this->_table, $openid));
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	public function fetch_all_by_uid($uid) {
		$data = array();
		$query = DB::query("SELECT * FROM %t WHERE it618_uid=%d and it618_authcount>0", array($this->_table, $uid));
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	public function count_all_by_search($it618sql = '', $it618orderby='', $it618key = '') {
		$condition = $this->make_query_condition1($it618sql, $it618orderby, $it618key);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $it618key = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition1($it618sql, $it618orderby, $it618key);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition1($it618sql = '', $it618orderby='', $it618key = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618key)) {
			$parameter[] = '%'.$it618key.'%';
			$parameter[] = '%'.$it618key.'%';
			$wherearr[] = "it618_wxname LIKE %s or it618_wxopenid LIKE %s";
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism_taobao-com
?>