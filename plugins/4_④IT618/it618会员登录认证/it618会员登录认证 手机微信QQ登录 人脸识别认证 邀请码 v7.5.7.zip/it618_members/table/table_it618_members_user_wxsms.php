<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_members_user_wxsms extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_members_user_wxsms';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}
	
	public function fetch_id_by_uid($uid) {
		return DB::result_first("SELECT id FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function fetch_by_uid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function count_by_type_uid($type,$uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_type=%s and it618_uid=%d", array($this->_table, $type, $uid));
	}
	
	public function count_by_type_uid_ok($type,$uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_type=%s and it618_uid=%d and it618_isok=1", array($this->_table, $type, $uid));
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}
	
	public function update_isok_by_type_uid($isok,$type,$uid) {
		return DB::query("UPDATE %t SET it618_isok=%d WHERE it618_type=%s and it618_uid=%d", array($this->_table, $isok, $type, $uid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism_taobao-com
?>