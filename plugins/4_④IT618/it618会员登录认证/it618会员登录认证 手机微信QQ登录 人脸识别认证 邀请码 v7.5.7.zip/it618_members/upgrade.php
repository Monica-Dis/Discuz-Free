<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_members/message.php',DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_members_checks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_about` varchar(5000) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_answer` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_messages_tpl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_content` varchar(1000) NOT NULL,
  `it618_sign` varchar(255) NOT NULL,
  `it618_tplid` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_messages_tpl_wx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_tplid` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_label` varchar(255) NOT NULL,
  `it618_value` varchar(2000) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_wxuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wxopenid` varchar(50) NOT NULL,
  `it618_wxname` varchar(100) NOT NULL,
  `it618_wxok` int(10) unsigned NOT NULL,
  `it618_wxoktime` int(10) unsigned NOT NULL,
  `it618_checktime` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_qquser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_qqopenid` varchar(50) NOT NULL,
  `it618_qqname` varchar(100) NOT NULL,
  `it618_isreg` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_rzuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(50) NOT NULL,
  `it618_cardid` varchar(50) NOT NULL,
  `it618_cardimg1` varchar(300) NOT NULL,
  `it618_cardimg2` varchar(300) NOT NULL,
  `it618_wx` varchar(50) NOT NULL,
  `it618_qq` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_email` varchar(50) NOT NULL,
  `it618_about` varchar(300) NOT NULL,
  `it618_isedit` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_statebz` varchar(300) NOT NULL,
  `it618_key` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_checktime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_rzapisale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order_no` varchar(50) NOT NULL,
  `it618_score` float(9,2) NOT NULL,
  `it618_datamsg` varchar(300) NOT NULL,
  `it618_incorrect` varchar(10) NOT NULL,
  `it618_about` varchar(300) NOT NULL,
  `it618_msg` varchar(300) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_vrzapisale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order_no` varchar(50) NOT NULL,
  `it618_is_life` int(10) unsigned NOT NULL,
  `it618_life_score` float(9,2) NOT NULL,
  `it618_hack_score` float(9,2) NOT NULL,
  `it618_face_score` float(9,2) NOT NULL,
  `it618_image_id` varchar(50) NOT NULL,
  `it618_datamsg` varchar(300) NOT NULL,
  `it618_incorrect` varchar(10) NOT NULL,
  `it618_about` varchar(300) NOT NULL,
  `it618_msg` varchar(300) NOT NULL,
  `it618_complexity` int(10) unsigned NOT NULL,
  `it618_motions` varchar(10) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_qyrz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_qyname` varchar(50) NOT NULL,
  `it618_creditcode` varchar(50) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_cardid` varchar(50) NOT NULL,
  `it618_cardimg1` varchar(300) NOT NULL,
  `it618_cardimg2` varchar(300) NOT NULL,
  `it618_yyzzimg` varchar(300) NOT NULL,
  `it618_sqsimg` varchar(300) NOT NULL,
  `it618_wx` varchar(50) NOT NULL,
  `it618_qq` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_email` varchar(50) NOT NULL,
  `it618_isedit` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_statebz` varchar(300) NOT NULL,
  `it618_key` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_checktime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_wxcodelogin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_wxcodebd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(32) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_yqcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_code` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_yqcode_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(50) NOT NULL,
  `it618_code` varchar(20) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_paycode` varchar(32) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_paytype` varchar(10) NOT NULL,
  `it618_payid` varchar(80) NOT NULL,
  `it618_paytime` int(10) unsigned NOT NULL,
  `it618_usetime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_kdsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_kdcomid` varchar(50) NOT NULL,
  `it618_kdid` varchar(50) NOT NULL,
  `it618_saletype` varchar(50) NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_jktype` varchar(50) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_message` varchar(50) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_data` mediumtext NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_about` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_userlogin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ip` varchar(20) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` varchar(10) NOT NULL,
  `it618_ip` varchar(20) NOT NULL,
  `it618_bz` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_visit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_url` varchar(255) NOT NULL,
  `it618_ip` varchar(20) NOT NULL,
  `it618_bz` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_visitcount` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bzmd5` varchar(32) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_user_wxsms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_members_editwork` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_sms'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_jktype', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_sms')." add `it618_jktype` varchar(50) NOT NULL;"; 
	DB::query($sql); 
	$sql = "update ".DB::table('it618_members_sms')." set it618_jktype='alidayu';"; 
	DB::query($sql); 
}

if(!in_array('it618_yqcode', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_sms')." add `it618_yqcode` varchar(50) NOT NULL;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_messages_tpl'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_jktype', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_messages_tpl')." add `it618_jktype` varchar(50) NOT NULL;"; 
	DB::query($sql); 
	$sql = "update ".DB::table('it618_members_messages_tpl')." set it618_jktype='alidayu';"; 
	DB::query($sql); 
}

if(!in_array('it618_value', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_messages_tpl')." add `it618_value` varchar(2000) NOT NULL;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_user'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_province', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_user')." add `it618_province` varchar(50) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_catname', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_user')." add `it618_catname` varchar(50) NOT NULL;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_wxuser'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_time', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_wxuser')." add `it618_time` int(10) unsigned NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_wxok', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_wxuser')." add `it618_wxok` int(10) unsigned NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_wxoktime', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_wxuser')." add `it618_wxoktime` int(10) unsigned NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_isreg', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_wxuser')." add `it618_isreg` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

if(!in_array('it618_authcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_wxuser')." add `it618_authcount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

if(!in_array('it618_checktime', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_wxuser')." add `it618_checktime` int(10) unsigned NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_wxunionid', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_wxuser')." add `it618_wxunionid` varchar(50) NOT NULL;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_qquser'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_authcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_qquser')." add `it618_authcount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_rzuser'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_statebz', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_rzuser')." add `it618_statebz` varchar(50) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_checkcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_rzuser')." add `it618_checkcount` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql); 
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_members_yqcode_sale')." where it618_state=1");
	while($it618_members_yqcode_sale = DB::fetch($query)) {
		DB::query("UPDATE ".DB::table('it618_credits_salepay')." SET it618_state=1,it618_paytime=".$it618_members_yqcode_sale['it618_paytime']." WHERE it618_saletype='0201' and it618_saleid=".$it618_members_yqcode_sale['id']);
	}
}

if(!in_array('it618_sex', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_rzuser')." add `it618_sex` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

if(!in_array('it618_cardimg3', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_rzuser')." add `it618_cardimg3` varchar(300) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_rzvideo', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_rzuser')." add `it618_rzvideo` varchar(300) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_rzmodes', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_rzuser')." add `it618_rzmodes` varchar(10) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_apicount', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_rzuser')." add `it618_apicount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_wxcodebd'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_openid', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_wxcodebd')." add `it618_openid` varchar(50) NOT NULL;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_messages_tpl_wx'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_label', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_messages_tpl_wx')." add `it618_label` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('it618_value', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_messages_tpl_wx')." add `it618_value` varchar(2000) NOT NULL;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_yqcode'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_state', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_yqcode')." add `it618_state` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_yqcode')." add `it618_type` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql); 
}

if(!in_array('it618_bz', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_yqcode')." add `it618_bz` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_members_yqcode_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_yqcode_sale')." add `it618_type` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql); 
}

if(!in_array('it618_bz', $col_field)){
	$sql = "Alter table ".DB::table('it618_members_yqcode_sale')." add `it618_bz` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}

DB::query("update ".DB::table('common_plugin')." set name='".lang('plugin/it618_members', 'it618_name')."' where identifier='it618_members'");

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzX1RDX0JJRzUueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvZGlzY3V6X3BsdWdpbl9pdDYxOF9tZW1iZXJzX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvaW5zdGFsbC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X21lbWJlcnMvdXBncmFkZS5waHA='));
?>