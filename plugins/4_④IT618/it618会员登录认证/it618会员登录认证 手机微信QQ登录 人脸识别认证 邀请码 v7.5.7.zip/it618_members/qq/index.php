<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', 1);
require '../../../../source/class/class_core.php';

$DiscuzApp = C::app();
$DiscuzApp->init();

loadcache('plugin');

$appid='';
$appsecret='';
$redirecturi='http://www.cnit618.com/source/plugin/it618_members/qq';

$it618_preurl=getcookie('it618_preurl');
$it618_preurl=str_replace("it618wxlogin","",$it618_preurl);

if($it618_preurl=='')$it618_preurl=$_G['siteurl'];

if(isset($_GET['code'])&&$_GET['state']==FORMHASH){
	$code=$_GET['code'];
	$redirect_uri=urlencode($redirecturi);
	
	$res=get_qqtoken($appid,$appsecret,$code,$redirect_uri);
	$tmparr=explode('it618_split',$res);
	if($tmparr[0]=='msg'){
		echo $tmparr[1];exit;
	}else{
		$access_token=$res;
	}
	
	$res=get_qqdata($appid,$access_token);
	$tmparr=explode('it618_split',$res);
	if($tmparr[0]=='msg'){
		echo $tmparr[1];exit;
	}else{
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
		$openid=$tmparr[0];
		$qqdata = json_decode($tmparr[1], true);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/wxlogin.func.php';
		$nickname=it618_members_utftogbk(it618_wxclear($qqdata['nickname']));
		$headimgurl=str_replace('\/','/',$qqdata['figureurl_qq_1']);
		
		echo '<img src='.$headimgurl.'>'.$nickname;
	}
}else{
	$redirect_uri=urlencode($redirecturi);
	$scope='get_user_info';
	$state=FORMHASH;

	dheader("location:https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=$appid&redirect_uri=$redirect_uri&scope=$scope&state=$state");
}

function get_qqtoken($appid,$appsecret,$code,$redirect_uri,$dzroot=''){
	$url = "https://graph.qq.com/oauth2.0/token?grant_type=authorization_code&client_id=".$appid."&client_secret=".$appsecret."&code=".$code."&redirect_uri=".$redirect_uri;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);

	curl_close( $ch );
	
	$tmparr=explode("error",$res);
	if(count($tmparr)>1){
		return 'msgit618_split'.$res;
	}
	
	$tmparr=explode("=",$res);
	$tmparr1=explode("&",$tmparr[1]);
	return $tmparr1[0];
}

function get_qqdata($appid,$access_token,$dzroot=''){
	$url = "https://graph.qq.com/oauth2.0/me?access_token=".$access_token;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);

	curl_close( $ch );
	
	$tmparr=explode("error",$res);
	if(count($tmparr)>1){
		return 'msgit618_split'.$res;
	}
	
	$tmparr=explode('":"',$res);
	$tmparr1=explode('"',$tmparr[2]);
	$openid=$tmparr1[0];
	
	$url = "https://graph.qq.com/user/get_user_info?access_token=".$access_token."&oauth_consumer_key=".$appid."&openid=".$openid;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);
	
	curl_close( $ch );
	
	$data = json_decode($res, true);
	if($data['msg']!=''){
		return 'msgit618_split'.$data['msg'];
	}
	
	return $openid.'it618_split'.$res;
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>