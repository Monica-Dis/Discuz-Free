<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if(count($reabc)!=13)return;

loadcache('plugin');
$it618_members = $_G['cache']['plugin']['it618_members'];

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function/it618_members.func.php';

if($reabc[10]!='e')return;

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_yqcode&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_yqcode_set', 'admin_yqcode', 'admin_yqcode_sale', 'admin_yqcode_give');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_yqcode' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_yqcode_set'.$urls.'"><span>'.$it618_members_lang['s570'].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_yqcode'.$urls.'"><span>'.$it618_members_lang['s236'].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_yqcode_sale'.$urls.'"><span>'.$it618_members_lang['s237'].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_yqcode_give'.$urls.'"><span>'.$it618_members_lang['s229'].'</span></a></li>
</ul></div>';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/
?>