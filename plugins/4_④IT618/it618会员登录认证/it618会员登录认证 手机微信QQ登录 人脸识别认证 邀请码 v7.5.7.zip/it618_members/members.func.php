<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_members;
$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';

function it618_members_getmembers($pluginid,$name,$url='',$do=''){
	global $_G,$it618_members,$it618_members_lang;
	
	if($url=='')$url="plugin.php?id=it618_members:home";
	$getmembers='<script type="text/javascript" src="source/plugin/it618_members/js/layer/layer.js"></script>';
	
	if($_G['uid']>0){
		if($it618_members['members_ishome']==1||$it618_members['members_ishome']==2){
			$widthheight='"868px", "588px"';
			if($name=='#it618_members_telbd_credits'||$name=='#it618_members_rzuser_credits'){
				$widthheight='"838px", "518px"';
			}
			$getmembers.= '
				<script>			
				jQuery(document).ready(function() {
					
				jQuery("'.$name.'").click(function() {
					layerindex=layer.open({
					  type: 2,
					  title: "<div style=\'float:left\'><img src=\'source/plugin/it618_members/images/logo.png\' style=\'vertical-align:middle;margin-right:3px; margin-top:-3px; height:18px\'>'.$it618_members_lang['t72'].'</div>",
					  shadeClose: false,
					  scrollbar: false,
					  shade:  [0.5, "#393D49"],
					  maxmin: false,
					  area: ['.$widthheight.'],
					  content: "'.$url.'",
					  cancel: function(index, layero){ 
					  }    
					});
				});
				
				});
				</script>
			';
		}
	}else{
		if($it618_members['members_isok']==1){
			if($do=='winapireg')$dostr='layerindex=layer.open({
					  type: 2,
					  title: "<div style=\'float:left\'><img src=\'source/plugin/it618_members/images/logo.png\' style=\'vertical-align:middle;margin-right:3px; margin-top:-3px; height:18px\'>'.$it618_members_lang['t22'].'</div>",
					  shadeClose: false,
					  scrollbar: false,
					  shade:  [0.5, "#393D49"],
					  maxmin: false,
					  area: ["868px", "558px"],
					  content: "plugin.php?id=it618_members:reg&winapi=1",
					  cancel: function(index, layero){ 
					  }    
					});';
					
			if($do=='winapilogin')$dostr='layerindex=layer.open({
					  type: 2,
					  title: "<div style=\'float:left\'><img src=\'source/plugin/it618_members/images/logo.png\' style=\'vertical-align:middle;margin-right:3px; margin-top:-3px; height:18px\'>'.$it618_members_lang['t36'].'</div>",
					  shadeClose: false,
					  scrollbar: false,
					  shade:  [0.5, "#393D49"],
					  maxmin: false,
					  area: ["868px", "558px"],
					  content: "plugin.php?id=it618_members:login&winapi=1",
					  cancel: function(index, layero){ 
					  }    
					});';
					
			$getmembers.= '
				<script>			
				jQuery(document).ready(function() {
				
				jQuery(".it618_members_login").click(function() {
					layerindex=layer.open({
					  type: 2,
					  title: "<div style=\'float:left\'><img src=\'source/plugin/it618_members/images/logo.png\' style=\'vertical-align:middle;margin-right:3px; margin-top:-3px; height:18px\'>'.$it618_members_lang['t36'].'</div>",
					  shadeClose: false,
					  scrollbar: false,
					  shade:  [0.5, "#393D49"],
					  maxmin: false,
					  area: ["868px", "558px"],
					  content: "plugin.php?id=it618_members:login&winapi=1",
					  cancel: function(index, layero){ 
					  }    
					});
				});
				
				jQuery(".it618_members_reg").click(function() {
					layerindex=layer.open({
					  type: 2,
					  title: "<div style=\'float:left\'><img src=\'source/plugin/it618_members/images/logo.png\' style=\'vertical-align:middle;margin-right:3px; margin-top:-3px; height:18px\'>'.$it618_members_lang['t22'].'</div>",
					  shadeClose: false,
					  scrollbar: false,
					  shade:  [0.5, "#393D49"],
					  maxmin: false,
					  area: ["868px", "558px"],
					  content: "plugin.php?id=it618_members:reg&winapi=1",
					  cancel: function(index, layero){ 
					  }    
					});
				});
				'.$dostr.'
				
				});
				</script>
			';
		}
	}
	
	return $getmembers;
}

function it618_members_getapplogin($pluginid){
	global $_G,$it618_members,$it618_members_lang,$getapplogin;
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/appjk.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/appjk.php';
	}
	
	$getapplogin['appjsscript']='';
	$getapplogin['appjs']='';
	
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MAGAPPX')!==false&&$appjk_mag_isok==1){

		$urlarr=explode("https://",$_G['siteurl']);
		if(count($urlarr)>1){
			$appjssrc='https://static.app1.magcloud.net/public/static/dest/js/libs/magjs-x.js';
		}else{
			$appjssrc='http://app.lxh.magcloud.cc/public/static/dest/js/libs/magjs-x.js';
		}
		
		$urlarr=explode("https://",$_G['siteurl']);
		if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';		
		$url_this = $httpstr.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

		$getapplogin['appjsscript']='<script src="'.$appjssrc.'"></script>';
		$getapplogin['appjs']='
		mag.toLogin(function(rs) {
			var url=location.href;
			var tmparr=url.split("?");
			if(tmparr.length>1){
				url=url+"&token="+rs.token;
			}else{
				url=url+"?token="+rs.token;
			}
			location.href=url;
		});
		return;
		';
	}
	
	return $getapplogin;
}

function it618_members_apploginok($token){
	global $_G;
	if($token=='')return false;

	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/appjk.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/appjk.php';
	}
	
	if($appjk_mag_isok!=1)return false;

	$magapp_url=str_replace("ht"."tps:","ht"."tp:",$appjk_mag_url);
	$res=file_get_contents($magapp_url.'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$appjk_mag_secret);
	
	$data = json_decode($res,true);
	$user_id=$data["data"]["user_id"];
	if($user_id>0){
		require_once libfile('function/member');
		$member=getuserbyuid($user_id, 1);
		
		setloginstatus($member, 12960000);
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
		it618_members_getlogin($_G['uid'],'magapp');
		
		$urlarr=explode("https://",$_G['siteurl']);
		if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';		
		$url_this = $httpstr.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$url_this=str_replace("token","",$url_this);
		
		return $url_this;
	}else{
		return false;
	}
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>