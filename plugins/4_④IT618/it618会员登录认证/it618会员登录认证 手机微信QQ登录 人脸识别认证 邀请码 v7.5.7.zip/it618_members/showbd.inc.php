<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';

$wap=$_GET['wap'];

$typearray = array('wx', 'qq');
$type = !in_array($_GET['type'], $typearray) ? 'wx' : $_GET['type'];

if($_G['uid']<=0){
	$showmessage='<a href="member.php?mod=logging&action=login">'.$it618_members_lang['s40'].'</a>';
}else{
	if($type=='wx'){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
		}
		
		if($wxjk_mode>0&&$wxjk_mode<=2){
			$delbd='none';
			if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($_G['uid'])){
				if($wxjk_isdelbdok==1){
					$delbd='';
				}
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
				
				$openid=$it618_members_wxuser['it618_wxopenid'];
				$appid=trim($wxjk_appid);
				$appsecret=trim($wxjk_appsecret);
				
				$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
				$subscribe=$data['subscribe'];
				$subscribe_time=$data['subscribe_time'];
				
				C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
					'it618_wxok' => $subscribe,
					'it618_wxoktime' => $subscribe_time,
					'it618_checktime' => $_G['timestamp']
				));
				
				if($subscribe==0){
					$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout1');
					$bdstr=$it618_members_set['setvalue'];
					$bdstr=str_replace("{wxname}",$it618_members_wxuser['it618_wxname'],$bdstr);
					$bdstr=str_replace("{bdtime}",date('Y-m-d H:i:s', $it618_members_wxuser['it618_time']),$bdstr);
					if($bdstr=='')$bdstr=$it618_members_lang['s422'];
				}else{
					$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout2');
					$bdstr=$it618_members_set['setvalue'];
					$bdstr=str_replace("{wxname}",$it618_members_wxuser['it618_wxname'],$bdstr);
					$bdstr=str_replace("{bdtime}",date('Y-m-d H:i:s', $it618_members_wxuser['it618_time']),$bdstr);
					$bdstr=str_replace("{wxsubscribetime}",date('Y-m-d H:i:s', $it618_members_wxuser['it618_wxoktime']),$bdstr);
					$bdstr=str_replace("{checktime}",date('Y-m-d H:i:s', $it618_members_wxuser['it618_checktime']),$bdstr);
					if($bdstr=='')$bdstr=$it618_members_lang['s423'];
				}
			}else{
				$bdcodeid=C::t('#it618_members#it618_members_wxcodebd')->insert(array(
					'it618_uid' => $_G['uid'],
					'it618_time' => $_G['timestamp']
				), true);
				
				$code=md5($bdcodeid.$wxjk_appsecret);
				C::t('#it618_members#it618_members_wxcodebd')->update($bdcodeid,array(
					'it618_code' => $code
				));
				
				$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout0');
				$qrcodesrc='plugin.php?id=it618_members:wxcode&url='.urlencode($_G['siteurl'].'plugin.php?id=it618_members:home&bdcodeid='.$bdcodeid.'&code='.$code);
				$wxbdbdstr='<div class="wxbd"><img src="'.$qrcodesrc.'"><br>'.$it618_members_lang['s603'].'</div>';
				$bdstr=$it618_members_set['setvalue'];
			}
		}else{
			$showmessage=$it618_members_lang['s556'];
		}
		
	}
	
	if($type=='qq'){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php';
		}
		
		if($qqjk_isok==1){
			$delbd='none';
			if($it618_members_qquser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_qquser')." WHERE it618_uid=".$_G['uid'])){
				$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('qqjk_qqabout0');
				$bdstr=$it618_members_set['setvalue'];
				$bdstr=str_replace("{qqname}",$it618_members_qquser['it618_qqname'],$bdstr);
				$bdstr=str_replace("{bdtime}",date('Y-m-d H:i:s', $it618_members_qquser['it618_time']),$bdstr);
				if($bdstr=='')$bdstr=$it618_members_lang['s431'];
				
				if($qqjk_isdelbdok==1){
					$delbd='';
				}
			}else{
				$showmessage=$it618_members_lang['s556'];
			}
		}else{
			$showmessage=$it618_members_lang['s556'];
		}
		
	}
}

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

$_G['mobiletpl'][2]='/';

include template('it618_members:showbd');
?>