<?php
function get_wxopenid($appid,$appsecret,$code,$dzroot=''){
	$url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$appid."&secret=".$appsecret."&code=".$code."&grant_type=authorization_code";

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);
//	if( curl_errno($ch) ){
//		var_dump( curl_error($ch) );
//	}
	curl_close( $ch );
	$data = json_decode($res, true);
	
	$tmparr=explode("errmsg",$res);
	if(count($tmparr)>1){
		@$fp = fopen($dzroot.'./source/plugin/it618_members/sms/sms_wx/debug.txt',"a");
		fwrite($fp,"get_wxopenid\n".$res."\n");
		fclose($fp);
		
		return get_html('get_wxopenid'.$res);
	}
	
	return $data['openid'];
}

function get_wxtoken($appid,$appsecret,$dzroot=''){
	$data = json_decode(file_get_contents($dzroot.'./source/plugin/it618_members/sms/sms_wx/access_token.json'));
    if ($data->expire_time < time()) {
		$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$appid."&secret=".$appsecret;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$res = curl_exec($ch);
		
		curl_close( $ch );
		$data = json_decode($res, true);
		
		$tmparr=explode("errmsg",$res);
		if(count($tmparr)>1){
			@$fp = fopen($dzroot.'./source/plugin/it618_members/sms/sms_wx/debug.txt',"a");
			fwrite($fp,"get_wxtoken\n".$res."\n");
			fclose($fp);
			
			return 'it618_splitget_wxtoken'.$res;
		}
		
		$access_token = $data['access_token'];
		
		if ($access_token) {
		  $data->expire_time = time() + 7000;
		  $data->access_token = $access_token;
		  $fp = fopen($dzroot.'./source/plugin/it618_members/sms/sms_wx/access_token.json', "w");
		  fwrite($fp, json_encode($data));
		  fclose($fp);
		}
	}else{
		$access_token = $data->access_token;
	}
	
	return $access_token;
}

function get_wxuserdata($appid,$appsecret,$code,$dzroot=''){
	$url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$appid."&secret=".$appsecret."&code=".$code."&grant_type=authorization_code";

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);
//	if( curl_errno($ch) ){
//		var_dump( curl_error($ch) );
//	}
	curl_close( $ch );
	$data = json_decode($res, true);
	
	$tmparr=explode("errmsg",$res);
	if(count($tmparr)>1){
		@$fp = fopen($dzroot.'./source/plugin/it618_members/sms/sms_wx/debug.txt',"a");
		fwrite($fp,"get_wxopenid\n".$res."\n");
		fclose($fp);
		
		return get_html('get_wxuserdata1'.$res);
	}
	
	$url = "https://api.weixin.qq.com/sns/userinfo?access_token=".$data['access_token']."&openid=".$data['openid']."&lang=zh_CN"; 
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);

//	if( curl_errno($ch) ){
//		var_dump( curl_error($ch) );
//	}
	curl_close( $ch );
	$data = json_decode($res,true);
	
	$tmparr=explode("errmsg",$res);
	if(count($tmparr)>1){
		@$fp = fopen($dzroot.'./source/plugin/it618_members/sms/sms_wx/debug.txt',"a");
		fwrite($fp,"get_wxuserdata\n".$res."\n");
		fclose($fp);
		
		return get_html('get_wxuserdata2'.$res);
	}
	
	return $data;
}

function get_wxsubscribe($appid,$appsecret,$openid,$dzroot=''){
	$access_token = get_wxtoken($appid,$appsecret,$dzroot);
	$tmparr=explode("it618_split",$access_token);
	if(count($tmparr)>1){
		return get_html($tmparr[1]);
	}
	
	$url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=$access_token&openid=$openid";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);

//	if( curl_errno($ch) ){
//		var_dump( curl_error($ch) );
//	}
	curl_close( $ch );
	$data = json_decode($res, true);
	
	$tmparr=explode("errmsg",$res);
	if(count($tmparr)>1){
		@$fp = fopen($dzroot.'./source/plugin/it618_members/sms/sms_wx/debug.txt',"a");
		fwrite($fp,"get_wxsubscribe\n".$res."\n");
		fclose($fp);
		
		return get_html('get_wxsubscribe'.$res);
	}
	
	$data['wxtoken']=$access_token;
	
	return $data;
}

function get_html($data){
	return '
		<!DOCTYPE html>
		<html>
		<head>
		<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'" />
		<meta name="viewport" content="initial-scale=1, width=device-width, maximum-scale=1, user-scalable=no">
		<meta name="viewport" content="initial-scale=1.0,user-scalable=no,maximum-scale=1" media="(device-height: 568px)">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="screen-orientation" content="portrait">
		<meta name="full-screen" content="yes">
		<meta name="browsermode" content="application">
		<meta name="x5-orientation" content="portrait">
		<meta name="x5-fullscreen" content="true">
		<meta name="x5-page-mode" content="app">
		<meta name="apple-touch-fullscreen" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="format-detection" content="telephone=no">
		<meta name="format-detection" content="address=no">
		</head>
		<style>
		body{font-size:12px}
		</style>
		<body>
		'.$data.'
		</body>
		</html>
		';	
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>