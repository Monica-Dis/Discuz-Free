<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql = "1";
$findtype0='';$findtype1='';$findtype10='';$findtype11='';$findtype2='';$findtype3='';$findtype4='';$findtype5='';
if($_GET['findtype']==0){$findtype0='selected="selected"';}
if($_GET['findtype']==1){$it618sql .= " and it618_type = 1";$findtype1='selected="selected"';}
if($_GET['findtype']==10){$it618sql .= " and it618_type = 10";$findtype10='selected="selected"';}
if($_GET['findtype']==11){$it618sql .= " and it618_type = 11";$findtype11='selected="selected"';}
if($_GET['findtype']==2){$it618sql .= " and it618_type = 2";$findtype2='selected="selected"';}
if($_GET['findtype']==3){$it618sql .= " and it618_type = 3";$findtype3='selected="selected"';}
if($_GET['findtype']==4){$it618sql .= " and it618_type = 4";$findtype4='selected="selected"';}
if($_GET['findtype']==5){$it618sql .= " and it618_type = 5";$findtype5='selected="selected"';}
if($_GET['findtype']==6){$it618sql .= " and it618_type = 6";$findtype6='selected="selected"';}

$findstate0='';$findstate1='';$findstate2='';
if($_GET['findstate']==0){$findstate0='selected="selected"';}
if($_GET['findstate']==1){$it618sql .= " and it618_uid <>''";$findstate1='selected="selected"';}
if($_GET['findstate']==2){$it618sql .= " and it618_uid = ''";$findstate2='selected="selected"';}

$it618orderby='id desc';

$urlsql='&key='.$_GET['key'].'&findtype='.$_GET['findtype'].'&findstate='.$_GET['findstate'];

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_message&pmod=admin_dxjk&operation=$operation&do=$do&cp1=$cp1".$urlsql);
showtableheaders($it618_members_lang['s1'],'it618_regsafe_checks');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s3'].' <input name="key" style="width:180px" value="'.$_GET['key'].'" class="txt" /> '.$it618_members_lang['s8'].' <select name="findtype"><option value=0 '.$findtype0.'>'.$it618_members_lang['s9'].'</option><option value=1 '.$findtype1.'>'.$it618_members_lang['s33'].'</option><option value=11 '.$findtype11.'>'.$it618_members_lang['s301'].'</option><option value=10 '.$findtype10.'>'.$it618_members_lang['s100'].'</option><option value=2 '.$findtype2.'>'.$it618_members_lang['s34'].'</option><option value=3 '.$findtype3.'>'.$it618_members_lang['s35'].'</option><option value=6 '.$findtype6.'>'.$it618_members_lang['s196'].'</option><option value=4 '.$findtype4.'>'.$it618_members_lang['s10'].'</option><option value=5 '.$findtype5.'>'.$it618_members_lang['s78'].'</option></select> '.$it618_members_lang['s4'].' <select name="findstate"><option value=0 '.$findstate0.'>'.$it618_members_lang['s5'].'</option><option value=1 '.$findstate1.'>'.$it618_members_lang['s6'].'</option><option value=2 '.$findstate2.'>'.$it618_members_lang['s7'].'</option></select>');
	
	$count = C::t('#it618_members#it618_members_sms')->count_all_by_search($it618sql,$it618orderby,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_message&pmod=admin_dxjk&operation=$operation&do=$do".$urlsql);
	if($reabc[6]!='m')return;
	echo '<tr><td colspan=8>'.$it618_members_lang['s11'].$count.' <span style="float:right">'.$it618_members_lang['s12'].'</span></td></tr>';
	showsubtitle(array($it618_members_lang['s13'], $it618_members_lang['s14'], $it618_members_lang['s153'], $it618_members_lang['s31'],$it618_members_lang['s15'],$it618_members_lang['s16'],$it618_members_lang['s17'],$it618_members_lang['s18']));
	
	foreach(C::t('#it618_members#it618_members_sms')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['key'],$startlimit,$ppp
	) as $it618_members_sms) {
		if($it618_members_sms['it618_isok']==1)$it618_isok='<font color=green>'.$it618_members_lang['s32'].'</font>';else $it618_isok='<font color=red>'.$it618_members_sms['it618_okbz'].'</font>';
		if($it618_members_sms['it618_type']==1){$it618_type=$it618_members_lang['s33'];}
		if($it618_members_sms['it618_type']==10){$it618_type=$it618_members_lang['s100'];}
		if($it618_members_sms['it618_type']==11){$it618_type=$it618_members_lang['s301'];}
		if($it618_members_sms['it618_type']==2){$it618_type=$it618_members_lang['s34'];}
		if($it618_members_sms['it618_type']==3){$it618_type=$it618_members_lang['s35'];}
		if($it618_members_sms['it618_type']==4){$it618_type=$it618_members_lang['s10'];}
		if($it618_members_sms['it618_type']==5){$it618_type=$it618_members_lang['s78'];}
		if($it618_members_sms['it618_type']==6){$it618_type=$it618_members_lang['s196'];}
		
		if($it618_members_sms['it618_jktype']=='smsbao'){$it618_jktype=$it618_members_lang['s136'];}
		if($it618_members_sms['it618_jktype']=='alidayu'){$it618_jktype=$it618_members_lang['s137'];}
		if($it618_members_sms['it618_jktype']=='alisms'){$it618_jktype=$it618_members_lang['s224'];}
		
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_sms['it618_uid']);
		$username='<a href="home.php?mod=space&uid='.$it618_members_sms['it618_uid'].'" target="_blank">'.$username.'</a>';
		if($reabc[8]!='m')return;
		if($it618_members_sms['it618_ip']!='')$it618_ip='<br>IP: '.$it618_members_sms['it618_ip'];else $it618_ip='';
		if($it618_members_sms['it618_yqcode']!='')$it618_yqcode='<br><br>'.$it618_members_lang['s155'].'<font color=green>'.$it618_members_sms['it618_yqcode'].'</font>';else $it618_yqcode='';
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			$it618_members_sms['id'],
			$it618_members_sms['it618_tel'],
			$it618_jktype,
			$it618_type,
			$it618_isok,
			'<div style="width:460px">'.$it618_members_sms['it618_bz'].$it618_ip.'</div>',
			$username,
			date('Y-m-d H:i:s', $it618_members_sms['it618_time']).$it618_yqcode
		));
	}
echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>