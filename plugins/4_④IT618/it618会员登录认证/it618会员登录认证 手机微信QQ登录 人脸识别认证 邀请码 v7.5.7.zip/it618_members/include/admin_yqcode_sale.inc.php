<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

$it618sql='it618_type=1 and it618_state=1';
$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='m')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		$it618_members_yqcode_sale=C::t('#it618_members#it618_members_yqcode_sale')->fetch_by_id($delid);
		if($it618_members_yqcode_sale['it618_tel']!=''){
			C::t('#it618_members#it618_members_yqcode_sale')->delete_it618_tel($delid);
			$del=$del+1;
		}
	}

	cpmsg($it618_members_lang['s216'].$del, "action=plugins&identifier=$identifier&cp=admin_yqcode_sale&pmod=admin_yqcode&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=13)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_yqcode_sale&pmod=admin_yqcode&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s237'],'it618_members_sum');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s204'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" />'.$it618_members_lang['s205'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_members_lang['s206'].' <input name="it618_time1" class="txt" style="width:80px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time1'].'" /> - <input name="it618_time2" class="txt" style="width:80px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time2'].'"/>');
	
	$it618_members_yqcode_sales=C::t('#it618_members#it618_members_yqcode_sale')->fetch_all_by_search_sale($it618sql,'it618_paytime desc',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
	$count=C::t('#it618_members#it618_members_yqcode_sale')->count_all_by_search_sale($it618sql,'',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$money=C::t('#it618_members#it618_members_yqcode_sale')->sum_money_by_search_sale($it618sql,'',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_yqcode_sale&pmod=admin_yqcode&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=18>'.$it618_members_lang['s207'].'<font color=red>'.$count.'</font> '.$it618_members_lang['s208'].'<font color=red>'.$money.'</font><span style="float:right;">'.$it618_members_lang['s215'].'</span></td></tr>';
	showsubtitle(array($it618_members_lang['s986'],$it618_members_lang['s197'],$it618_members_lang['s198'], $it618_members_lang['s199'],$it618_members_lang['s200'],$it618_members_lang['s201'],$it618_members_lang['s202'],$it618_members_lang['s203']));
	
	if($IsCredits==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
	}

	foreach($it618_members_yqcode_sales as $it618_members_yqcode_sale) {
		
		$it618_user='';$it618_usetime='';
		if($it618_members_yqcode_sale['it618_uid']>0){
			$it618_user='<a href="home.php?mod=space&uid='.$it618_members_yqcode_sale['it618_uid'].'" target="_blank">'.it618_members_getusername($it618_members_yqcode_sale['it618_uid']).'</a>';
			$it618_usetime=date('Y-m-d H:i:s', $it618_members_yqcode_sale['it618_usetime']);
		}
		
		if($IsCredits==1){
			$paystr=getpaystr(0,$it618_members_yqcode_sale['id'],'members');
		}
		
		showtablerow('', array('', '', '', '', '', '', '', '', ''), array(
			'<div style="width:50px">'.$it618_members_yqcode_sale['id'].'</div>',
			$it618_members_yqcode_sale['it618_tel'],
			$it618_members_yqcode_sale['it618_code'],
			$it618_members_yqcode_sale['it618_price'],
			$paystr,
			date('Y-m-d H:i:s', $it618_members_yqcode_sale['it618_paytime']),
			$it618_user,
			$it618_usetime,
		));
	}
	
	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
echo '<script charset="utf-8" src="source/plugin/it618_members/js/Calendar.js"></script>';
?>