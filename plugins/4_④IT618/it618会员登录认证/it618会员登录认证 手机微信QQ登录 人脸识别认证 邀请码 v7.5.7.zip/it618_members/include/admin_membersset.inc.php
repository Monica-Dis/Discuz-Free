<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/membersset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/membersset.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/membersset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$membersset[\'uname_isedit\']=\''.trim($_GET['uname_isedit'])."';\n";
		$fileData .= '$membersset[\'uname_editcredits\']=\''.trim($_GET['uname_editcredits'])."';\n";
		$fileData .= '$membersset[\'uname_editcount\']=\''.trim($_GET['uname_editcount'])."';\n";
		$fileData .= '$membersset[\'uname_edituids\']=\''.trim($_GET['uname_edituids'])."';\n";
		$fileData .= '$membersset[\'avatar_isedit\']=\''.trim($_GET['avatar_isedit'])."';\n";
		$fileData .= '$membersset[\'avatar_editcredits\']=\''.trim($_GET['avatar_editcredits'])."';\n";
		$fileData .= '$membersset[\'avatar_editcount\']=\''.trim($_GET['avatar_editcount'])."';\n";
		$fileData .= '$membersset[\'avatar_edituids\']=\''.trim($_GET['avatar_edituids'])."';\n";
		$fileData .= '$membersset[\'avatar_ispbdzavatar\']=\''.trim($_GET['avatar_ispbdzavatar'])."';\n";
		$fileData .= '$membersset[\'avatar_pbdzavatarurl\']=\''.trim($_GET['avatar_pbdzavatarurl'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	cpmsg($it618_members_lang['s571'], "action=plugins&identifier=$identifier&cp=admin_membersset&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$uname_editcredits.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
		$avatar_editcredits.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}

$uname_editcredits=str_replace('<option value="'.$membersset['uname_editcredits'].'"','<option value="'.$membersset['uname_editcredits'].'" selected="selected"',$uname_editcredits);
$avatar_editcredits=str_replace('<option value="'.$membersset['avatar_editcredits'].'"','<option value="'.$membersset['avatar_editcredits'].'" selected="selected"',$avatar_editcredits);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_membersset&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

if($membersset['uname_isedit']==1)$check_uname_isedit='checked="checked"';else $check_uname_isedit='';
if($membersset['avatar_isedit']==1)$check_avatar_isedit='checked="checked"';else $check_avatar_isedit='';
if($membersset['avatar_ispbdzavatar']==1)$check_avatar_ispbdzavatar='checked="checked"';else $check_avatar_ispbdzavatar='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_members_lang['s677'].'</th></tr>
<tr class="header"><th width=180>'.$it618_members_lang['s610'].'</th><th>'.$it618_members_lang['s611'].'</th><th>'.$it618_members_lang['s612'].'</th></tr>

<tr class="hover">
<td><b>'.$it618_members_lang['s688'].'</b></td><td class="longtxt"></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s678'].'</td><td class="longtxt"><input type="checkbox" name="uname_isedit" value=1 '.$check_uname_isedit.'></td>
<td>'.$it618_members_lang['s684'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s679'].'</td><td class="longtxt">
<input name="uname_editcount" value="'.$membersset['uname_editcount'].'" style="width:80px" />
<select name="uname_editcredits">
	'.$uname_editcredits.'
</select></td>
<td>
'.$it618_members_lang['s685'].'
</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s683'].'</td><td class="longtxt"><input name="uname_edituids" value="'.$membersset['uname_edituids'].'" style="width:300px" /></td>
<td>'.$it618_members_lang['s690'].'</td>
</tr>

<tr class="hover">
<td><b>'.$it618_members_lang['s689'].'</b></td><td class="longtxt"></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s681'].'</td><td class="longtxt"><input type="checkbox" name="avatar_isedit" value=1 '.$check_avatar_isedit.'></td>
<td>'.$it618_members_lang['s686'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s682'].'</td><td class="longtxt">
<input name="avatar_editcount" value="'.$membersset['avatar_editcount'].'" style="width:80px" />
<select name="avatar_editcredits">
	'.$avatar_editcredits.'
</select></td>
<td>
'.$it618_members_lang['s687'].'
</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s683'].'</td><td class="longtxt"><input name="avatar_edituids" value="'.$membersset['avatar_edituids'].'" style="width:300px" /></td>
<td>'.$it618_members_lang['s691'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s737'].'</td><td class="longtxt"><input type="checkbox" name="avatar_ispbdzavatar" value=1 '.$check_avatar_ispbdzavatar.'></td>
<td>'.$it618_members_lang['s738'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s739'].'</td><td class="longtxt"><input name="avatar_pbdzavatarurl" value="'.$membersset['avatar_pbdzavatarurl'].'" style="width:300px" /></td>
<td</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_members_lang['s589']);

if(count($reabc)!=14)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>