<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/appjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/appjk.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/appjk.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		$fileData = '$appjk_mag_isok=\''.trim($_GET['appjk_mag_isok'])."';\n";
		$fileData .= '$appjk_mag_url=\''.trim($_GET['appjk_mag_url'])."';\n";
		$fileData .= '$appjk_mag_secret=\''.trim($_GET['appjk_mag_secret'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_members_lang['s699'], "action=plugins&identifier=$identifier&cp=admin_appjk&pmod=admin_appjk&operation=$operation&do=$do", 'succeed');
}

if($appjk_mag_isok==1)$check_mag_isok='checked="checked"';else $check_mag_isok='';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_appjk&pmod=admin_appjk&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_members_lang['s698'].'</th></tr>
<tr class="header"><th width=158>'.$it618_members_lang['s398'].'</th><th width=360>'.$it618_members_lang['s399'].'</th><th>'.$it618_members_lang['s400'].'</th></tr>

<tr class="hover"><td>'.$it618_members_lang['s694'].'</td><td class="tdvalue"><input type="checkbox" name="appjk_mag_isok" value=1 '.$check_mag_isok.'></td>
<td class="tdabout">'.$it618_members_lang['s695'].'</td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s696'].'</td><td class="tdvalue"><input class="tdtxt" name="appjk_mag_url" style="width:260px" value="'.$appjk_mag_url.'" /></td>
<td class="tdabout"></td></tr>

<tr class="hover"><td>'.$it618_members_lang['s697'].'</td><td class="tdvalue"><input class="tdtxt" name="appjk_mag_secret" style="width:260px" value="'.$appjk_mag_secret.'" /></td>
<td class="tdabout"></td>
</tr>

</table>
';

showsubmit('it618submit', $it618_members_lang['s402']);

if(count($reabc)!=11)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>