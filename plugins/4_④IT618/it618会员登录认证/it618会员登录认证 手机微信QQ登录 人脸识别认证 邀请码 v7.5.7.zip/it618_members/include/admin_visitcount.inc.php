<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql = "1";
if($_GET['uid']!=''){$it618sql .= " and it618_uid = ".intval($_GET['uid']);}

$it618orderby='it618_time desc';

$urlsql='&uid='.$_GET['uid'];

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/visitset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/visitset.php';
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_visitcount&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1".$urlsql);
showtableheaders($strtmptitle[$cp1],'it618_regsafe_checks');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s853'].' <input name="uid" style="width:80px;margin-right:0px" value="'.$_GET['uid'].'" class="txt" />');
	
	$count = C::t('#it618_members#it618_members_visitcount')->count_all_by_search($it618sql,$it618orderby,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_visitcount&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do".$urlsql);
	if($reabc[6]!='m')return;
	echo '<tr><td colspan=8>'.$it618_members_lang['s11'].$count.' <span style="float:right">'.$it618_members_lang['s875'].'</span></td></tr>';
	showsubtitle(array($it618_members_lang['s872'], $it618_members_lang['s873'], $it618_members_lang['s874'], $it618_members_lang['s876']));
	
	foreach(C::t('#it618_members#it618_members_visitcount')->fetch_all_by_search(
		$it618sql,$it618orderby,'',$startlimit,$ppp
	) as $it618_members_visitcount) {
		
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_visitcount['it618_uid']);
		$username='<div style="float:left;line-height:20px"><a href="home.php?mod=space&uid='.$it618_members_visitcount['it618_uid'].'" target="_blank">'.$username.'</a><br>'.$it618_members_visitcount['it618_uid'].'</div>';
		$u_avatarimg=it618_members_discuz_uc_avatar($it618_members_visitcount['it618_uid'],'middle');
		
		$state='';
		if($visitset['checktimes']>0&&$visitset['count']>0){
			$it618_count=$it618_members_visitcount['it618_count'];
			if($it618_members_visitcount['it618_count']>$visitset['count']){
				$tmptime=($it618_members_visitcount['it618_time']+$visitset['oktimes']*60)-$_G['timestamp'];
				if($tmptime>0){
					$state='<font color=red>'.$it618_members_lang['s878'].'</font><br>'.$it618_members_lang['s879'].$tmptime.$it618_members_lang['s880'];
				}else{
					C::t('#it618_members#it618_members_visitcount')->update($it618_members_visitcount['id'],array(
						'it618_count' => 0
					));
					$it618_count=0;
					$state='<font color=green>'.$it618_members_lang['s877'].'</font>';
				}
			}else{
				$state='<font color=green>'.$it618_members_lang['s877'].'</font>';
			}
		}
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			'<div style="width:190px"><a href="'.$u_avatarimg.'" target="_blank"><img src="'.$u_avatarimg.'" width=40 style="vertical-align:middle;float:left;margin-right:6px"></a> '.$username.'</div>',
			$it618_count,
			date('Y-m-d H:i:s', $it618_members_visitcount['it618_time']),
			$state
		));
	}
echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>