<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

$it618sql='it618_type=2';
$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='m')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		$it618_members_yqcode_sale=C::t('#it618_members#it618_members_yqcode_sale')->fetch_by_id($delid);
		if($it618_members_yqcode_sale['it618_tel']!=''){
			C::t('#it618_members#it618_members_yqcode_sale')->delete_it618_tel($delid);
			$del=$del+1;
		}
	}

	cpmsg($it618_members_lang['s216'].$del, "action=plugins&identifier=$identifier&cp=admin_yqcode_give&pmod=admin_yqcode&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=13)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_yqcode_give&pmod=admin_yqcode&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s229'],'it618_members_sum');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s366'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" />'.$it618_members_lang['s205'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_members_lang['s203'].' <input name="it618_time1" class="txt" style="width:80px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time1'].'" /> - <input name="it618_time2" class="txt" style="width:80px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" value="'.$_GET['it618_time2'].'"/>');
	
	$it618_members_yqcode_sales=C::t('#it618_members#it618_members_yqcode_sale')->fetch_all_by_search_sale1($it618sql,'it618_paytime desc',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
	$count=C::t('#it618_members#it618_members_yqcode_sale')->count_all_by_search_sale1($it618sql,'',$_GET['key'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_yqcode_give&pmod=admin_yqcode&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=18>'.$it618_members_lang['s362'].'<font color=red>'.$count.'</font><span style="float:right;">'.$it618_members_lang['s364'].'</span></td></tr>';
	showsubtitle(array($it618_members_lang['s202'],$it618_members_lang['s203'],$it618_members_lang['s365']));

	foreach($it618_members_yqcode_sales as $it618_members_yqcode_sale) {
		
		$it618_user='';$it618_usetime='';
		if($it618_members_yqcode_sale['it618_uid']>0){
			$it618_user='<a href="home.php?mod=space&uid='.$it618_members_yqcode_sale['it618_uid'].'" target="_blank">'.it618_members_getusername($it618_members_yqcode_sale['it618_uid']).'</a>';
			$it618_usetime=date('Y-m-d H:i:s', $it618_members_yqcode_sale['it618_usetime']);
		}
		
		showtablerow('', array('', '', '', '', '', '', '', '', ''), array(
			$it618_user,
			$it618_usetime,
			$it618_members_yqcode_sale['it618_bz']
		));
	}
	
	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
echo '<script charset="utf-8" src="source/plugin/it618_members/js/Calendar.js"></script>';
?>