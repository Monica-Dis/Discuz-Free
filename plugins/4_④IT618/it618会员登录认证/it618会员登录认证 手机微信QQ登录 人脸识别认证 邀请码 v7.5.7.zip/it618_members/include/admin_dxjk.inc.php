<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$it618_user=\''.trim($_GET['it618_user'])."';\n";
		
		$fileData .= '$it618_password=\''.trim($_GET['it618_password'])."';\n";
		
		$fileData .= '$it618_testsendto=\''.trim($_GET['it618_testsendto'])."';\n";
		
		$fileData .= '$it618_testbody=\''.trim($_GET['it618_testbody'])."';\n";
		
		$fileData .= '$it618_appkey=\''.trim($_GET['it618_appkey'])."';\n";
		$fileData .= '$it618_appsecret=\''.trim($_GET['it618_appsecret'])."';\n";
		
		$fileData .= '$it618_accesskeyid=\''.trim($_GET['it618_accesskeyid'])."';\n";
		$fileData .= '$it618_accesskeysecret=\''.trim($_GET['it618_accesskeysecret'])."';\n";
		
		$fileData .= '$it618_body_reg=\''.trim($_GET['it618_body_reg'])."';\n";
		$fileData .= '$it618_type_reg=\''.trim($_GET['it618_type_reg'])."';\n";
		$fileData .= '$it618_body_reg_sign=\''.trim($_GET['it618_body_reg_sign'])."';\n";
		$fileData .= '$it618_body_reg_tplid=\''.trim($_GET['it618_body_reg_tplid'])."';\n";
		
		$fileData .= '$it618_body_regok=\''.trim($_GET['it618_body_regok'])."';\n";
		$fileData .= '$it618_type_regok=\''.trim($_GET['it618_type_regok'])."';\n";
		$fileData .= '$it618_body_regok_sign=\''.trim($_GET['it618_body_regok_sign'])."';\n";
		$fileData .= '$it618_body_regok_tplid=\''.trim($_GET['it618_body_regok_tplid'])."';\n";
		
		$fileData .= '$it618_body_login=\''.trim($_GET['it618_body_login'])."';\n";
		$fileData .= '$it618_type_login=\''.trim($_GET['it618_type_login'])."';\n";
		$fileData .= '$it618_body_login_sign=\''.trim($_GET['it618_body_login_sign'])."';\n";
		$fileData .= '$it618_body_login_tplid=\''.trim($_GET['it618_body_login_tplid'])."';\n";
		
		$fileData .= '$it618_body_bd=\''.trim($_GET['it618_body_bd'])."';\n";
		$fileData .= '$it618_type_bd=\''.trim($_GET['it618_type_bd'])."';\n";
		$fileData .= '$it618_body_bd_sign=\''.trim($_GET['it618_body_bd_sign'])."';\n";
		$fileData .= '$it618_body_bd_tplid=\''.trim($_GET['it618_body_bd_tplid'])."';\n";
		
		$fileData .= '$it618_body_mm=\''.trim($_GET['it618_body_mm'])."';\n";
		$fileData .= '$it618_type_mm=\''.trim($_GET['it618_type_mm'])."';\n";
		$fileData .= '$it618_body_mm_sign=\''.trim($_GET['it618_body_mm_sign'])."';\n";
		$fileData .= '$it618_body_mm_tplid=\''.trim($_GET['it618_body_mm_tplid'])."';\n";
		
		$fileData .= '$it618_body_yqmsale=\''.trim($_GET['it618_body_yqmsale'])."';\n";
		$fileData .= '$it618_type_yqmsale=\''.trim($_GET['it618_type_yqmsale'])."';\n";
		$fileData .= '$it618_body_yqmsale_sign=\''.trim($_GET['it618_body_yqmsale_sign'])."';\n";
		$fileData .= '$it618_body_yqmsale_tplid=\''.trim($_GET['it618_body_yqmsale_tplid'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	if($_GET['it618_istest']==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
		$tmpstr=it618_members_sendSMS($_GET['it618_testsendto'],$_GET['it618_testbody']);
		
		
		$tmpaboutstr='<br><br>'.$it618_members_lang['s127'];
	}

	cpmsg($it618_members_lang['s128'].'<br>'.$tmpstr.$tmpaboutstr, "action=plugins&identifier=$identifier&cp=admin_dxjk&pmod=admin_dxjk&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_dxjk&pmod=admin_dxjk&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s129'],'it618_members_message');

$it618_type_regstyle='display:none';
if($it618_type_reg=='')$it618_type_reg='smsbao';
if($it618_type_reg=='smsbao'){$it618_type_reg1=' selected=selected';}
if($it618_type_reg=='alidayu'){$it618_type_reg2=' selected=selected';$it618_type_regstyle='display:';}
if($it618_type_reg=='alisms'){$it618_type_reg3=' selected=selected';$it618_type_regstyle='display:';}

$it618_type_regokstyle='display:none';
if($it618_type_regok=='')$it618_type_reg='smsbao';
if($it618_type_regok=='smsbao'){$it618_type_regok1=' selected=selected';}
if($it618_type_regok=='alidayu'){$it618_type_regok2=' selected=selected';$it618_type_regokstyle='display:';}
if($it618_type_regok=='alisms'){$it618_type_regok3=' selected=selected';$it618_type_regokstyle='display:';}

$it618_type_loginstyle='display:none';
if($it618_type_login=='')$it618_type_login='smsbao';
if($it618_type_login=='smsbao'){$it618_type_login1=' selected=selected';}
if($it618_type_login=='alidayu'){$it618_type_login2=' selected=selected';$it618_type_loginstyle='display:';}
if($it618_type_login=='alisms'){$it618_type_login3=' selected=selected';$it618_type_loginstyle='display:';}

$it618_type_bdstyle='display:none';
if($it618_type_bd=='')$it618_type_bd='smsbao';
if($it618_type_bd=='smsbao'){$it618_type_bd1=' selected=selected';}
if($it618_type_bd=='alidayu'){$it618_type_bd2=' selected=selected';$it618_type_bdstyle='display:';}
if($it618_type_bd=='alisms'){$it618_type_bd3=' selected=selected';$it618_type_bdstyle='display:';}

$it618_type_mmstyle='display:none';
if($it618_type_mm=='')$it618_type_mm='smsbao';
if($it618_type_mm=='smsbao'){$it618_type_mm1=' selected=selected';}
if($it618_type_mm=='alidayu'){$it618_type_mm2=' selected=selected';$it618_type_mmstyle='display:';}
if($it618_type_mm=='alisms'){$it618_type_mm3=' selected=selected';$it618_type_mmstyle='display:';}

$it618_type_yqmsalestyle='display:none';
if($it618_type_yqmsale=='')$it618_type_yqmsale='smsbao';
if($it618_type_yqmsale=='smsbao'){$it618_type_yqmsale1=' selected=selected';}
if($it618_type_yqmsale=='alidayu'){$it618_type_yqmsale2=' selected=selected';$it618_type_yqmsalestyle='display:';}
if($it618_type_yqmsale=='alisms'){$it618_type_yqmsale3=' selected=selected';$it618_type_yqmsalestyle='display:';}

echo '<style>table tr td{line-height:20px}</style>
<tr><td colspan=2><strong>'.$it618_members_lang['s225'].'</strong> <font color=green>'.$it618_members_lang['s226'].'</font> <font color=red>'.$it618_members_lang['s230'].'</font></td></tr>
<tr style="background-color:#f1f1f1;"><td width=110>'.$it618_members_lang['s227'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_accesskeyid" value="'.$it618_accesskeyid.'"></td></tr>
<tr style="background-color:#f1f1f1;"><td>'.$it618_members_lang['s228'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_accesskeysecret" value="'.$it618_accesskeysecret.'"></td></tr>

<tr><td colspan=2><strong>'.$it618_members_lang['s130'].'</strong> '.$it618_members_lang['s120'].'</td></tr>
<tr style="background-color:#f1f1f1;"><td width=110>'.$it618_members_lang['s121'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_user" value="'.$it618_user.'"></td></tr>
<tr style="background-color:#f1f1f1;"><td>'.$it618_members_lang['s122'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_password" value="'.$it618_password.'"></td></tr>
<tr style="background-color:#f1f1f1;"><td>'.$it618_members_lang['s123'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_testsendto" value="'.$it618_testsendto.'"> '.$it618_members_lang['s124'].'</td></tr>
<tr style="background-color:#f1f1f1;"><td>'.$it618_members_lang['s125'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_testbody" value="'.$it618_testbody.'"></td></tr>
<table';

showtableheaders($it618_members_lang['s193'],'it618_members_message_tpl');

echo '<tr><td colspan=2>'.$it618_members_lang['s133'].'</td></tr>

<tr><td colspan=2>'.$it618_members_lang['s134'].'<br><input type="text" class="txt" style="width:600px" name="it618_body_reg" value="'.dhtmlspecialchars($it618_body_reg).'"> '.$it618_members_lang['s135'].'<select name="it618_type_reg" onchange="gettype(this,\'reg\')"><option value="smsbao" '.$it618_type_reg1.'>'.$it618_members_lang['s136'].'</option><option value="alisms" '.$it618_type_reg3.'>'.$it618_members_lang['s224'].'</option></select> '.$it618_members_lang['s138'].'<input type="text" class="txt" style="width:130px" name="it618_body_reg_sign" value="'.$it618_body_reg_sign.'"><span id="tr_alidayu_reg" style="'.$it618_type_regstyle.'"> '.$it618_members_lang['s139'].'<input type="text" class="txt" style="width:130px" name="it618_body_reg_tplid" value="'.$it618_body_reg_tplid.'"></span><br>'.$it618_members_lang['s140'].'</td></tr>

<tr><td colspan=2>'.$it618_members_lang['s998'].'<br><input type="text" class="txt" style="width:600px" name="it618_body_regok" value="'.dhtmlspecialchars($it618_body_regok).'"> '.$it618_members_lang['s135'].'<select name="it618_type_regok" onchange="gettype(this,\'regok\')"><option value="smsbao" '.$it618_type_regok1.'>'.$it618_members_lang['s136'].'</option><option value="alisms" '.$it618_type_regok3.'>'.$it618_members_lang['s224'].'</option></select> '.$it618_members_lang['s138'].'<input type="text" class="txt" style="width:130px" name="it618_body_regok_sign" value="'.$it618_body_regok_sign.'"><span id="tr_alidayu_regok" style="'.$it618_type_regokstyle.'"> '.$it618_members_lang['s139'].'<input type="text" class="txt" style="width:130px" name="it618_body_regok_tplid" value="'.$it618_body_regok_tplid.'"></span><br>'.$it618_members_lang['s999'].'</td></tr>

<tr><td colspan=2>'.$it618_members_lang['s126'].'<br><input type="text" class="txt" style="width:600px" name="it618_body_login" value="'.dhtmlspecialchars($it618_body_login).'"> '.$it618_members_lang['s135'].'<select name="it618_type_login" onchange="gettype(this,\'login\')"><option value="smsbao" '.$it618_type_login1.'>'.$it618_members_lang['s136'].'</option><option value="alisms" '.$it618_type_login3.'>'.$it618_members_lang['s224'].'</option></select> '.$it618_members_lang['s138'].'<input type="text" class="txt" style="width:130px" name="it618_body_login_sign" value="'.$it618_body_login_sign.'"><span id="tr_alidayu_login" style="'.$it618_type_loginstyle.'"> '.$it618_members_lang['s139'].'<input type="text" class="txt" style="width:130px" name="it618_body_login_tplid" value="'.$it618_body_login_tplid.'"></span><br>'.$it618_members_lang['s997'].'</td></tr>

<tr><td colspan=2>'.$it618_members_lang['s141'].'<br><input type="text" class="txt" style="width:600px" name="it618_body_bd" value="'.dhtmlspecialchars($it618_body_bd).'"> '.$it618_members_lang['s135'].'<select name="it618_type_bd" onchange="gettype(this,\'bd\')"><option value="smsbao" '.$it618_type_bd1.'>'.$it618_members_lang['s136'].'</option><option value="alisms" '.$it618_type_bd3.'>'.$it618_members_lang['s224'].'</option></select> '.$it618_members_lang['s138'].'<input type="text" class="txt" style="width:130px" name="it618_body_bd_sign" value="'.$it618_body_bd_sign.'"><span id="tr_alidayu_bd" style="'.$it618_type_bdstyle.'"> '.$it618_members_lang['s139'].'<input type="text" class="txt" style="width:130px" name="it618_body_bd_tplid" value="'.$it618_body_bd_tplid.'"></span><br>'.$it618_members_lang['s142'].'</td></tr>

<tr><td colspan=2>'.$it618_members_lang['s143'].'<br><input type="text" class="txt" style="width:600px" name="it618_body_mm" value="'.dhtmlspecialchars($it618_body_mm).'"> '.$it618_members_lang['s135'].'<select name="it618_type_mm" onchange="gettype(this,\'mm\')"><option value="smsbao" '.$it618_type_mm1.'>'.$it618_members_lang['s136'].'</option><option value="alisms" '.$it618_type_mm3.'>'.$it618_members_lang['s224'].'</option></select> '.$it618_members_lang['s138'].'<input type="text" class="txt" style="width:130px" name="it618_body_mm_sign" value="'.$it618_body_mm_sign.'"><span id="tr_alidayu_mm" style="'.$it618_type_mmstyle.'"> '.$it618_members_lang['s139'].'<input type="text" class="txt" style="width:130px" name="it618_body_mm_tplid" value="'.$it618_body_mm_tplid.'"></span><br>'.$it618_members_lang['s144'].'</td></tr>

<tr><td colspan=2>'.$it618_members_lang['s194'].'<br><input type="text" class="txt" style="width:600px" name="it618_body_yqmsale" value="'.dhtmlspecialchars($it618_body_yqmsale).'"> '.$it618_members_lang['s135'].'<select name="it618_type_yqmsale" onchange="gettype(this,\'yqmsale\')"><option value="smsbao" '.$it618_type_yqmsale1.'>'.$it618_members_lang['s136'].'</option><option value="alisms" '.$it618_type_yqmsale3.'>'.$it618_members_lang['s224'].'</option></select> '.$it618_members_lang['s138'].'<input type="text" class="txt" style="width:130px" name="it618_body_yqmsale_sign" value="'.$it618_body_yqmsale_sign.'"><span id="tr_alidayu_yqmsale" style="'.$it618_type_yqmsalestyle.'"> '.$it618_members_lang['s139'].'<input type="text" class="txt" style="width:130px" name="it618_body_yqmsale_tplid" value="'.$it618_body_yqmsale_tplid.'"></span><br>'.$it618_members_lang['s195'].'</td></tr>

<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_members_lang['s145'].'" /><input type="checkbox" id="it618_istest" name="it618_istest" value="1" style="vertical-align:middle;"><label for="it618_istest" name="tr_smsbao">'.$it618_members_lang['s146'].'</label></div></td></tr>

<script>
function gettype(obj,id){
	if(obj.value=="smsbao"){
		document.getElementById("tr_alidayu_"+id).style.display="none";
	}else{
		document.getElementById("tr_alidayu_"+id).style.display="";
	}
}
</script>
';

if(count($reabc)!=10)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>