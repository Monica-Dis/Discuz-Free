<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618orderby='id desc';

$urlsql='&key='.$_GET['key'].'&incorrect='.$_GET['incorrect'];

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_vrzapisale&pmod=admin_members&operation=$operation&do=$do&cp1=$cp1".$urlsql);
showtableheaders($it618_members_lang['s890'],'it618_regsafe_checks');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s3'].' <input name="key" style="width:280px" value="'.$_GET['key'].'" class="txt" />'.$it618_members_lang['s823'].' <input name="incorrect" style="width:80px;margin-right:3px" value="'.$_GET['incorrect'].'" class="txt" />');
	
	$count = C::t('#it618_members#it618_members_vrzapisale')->count_all_by_search($it618sql,$it618orderby,$_GET['key'],$_GET['incorrect']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_vrzapisale&pmod=admin_members&operation=$operation&do=$do".$urlsql);
	if($reabc[6]!='m')return;
	echo '<tr><td colspan=8>'.$it618_members_lang['s817'].$count.' <span style="float:right">'.$it618_members_lang['s891'].'</span></td></tr>';
	showsubtitle(array($it618_members_lang['s13'], $it618_members_lang['s820'], $it618_members_lang['s821'], $it618_members_lang['s822'],$it618_members_lang['s823'],$it618_members_lang['s824'],$it618_members_lang['s825'],$it618_members_lang['s826']));
	
	foreach(C::t('#it618_members#it618_members_vrzapisale')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['key'],$_GET['incorrect'],$startlimit,$ppp
	) as $it618_members_vrzapisale) {
		
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_vrzapisale['it618_uid']);
		$username='<a href="home.php?mod=space&uid='.$it618_members_vrzapisale['it618_uid'].'" target="_blank">'.$username.'</a>';
		if($reabc[8]!='m')return;
		if($it618_members_vrzapisale['it618_ip']!='')$it618_ip='<br>IP: '.$it618_members_vrzapisale['it618_ip'];else $it618_ip='';
		if($it618_members_vrzapisale['it618_yqcode']!='')$it618_yqcode='<br><br>'.$it618_members_lang['s155'].'<font color=green>'.$it618_members_vrzapisale['it618_yqcode'].'</font>';else $it618_yqcode='';
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			$it618_members_vrzapisale['id'],
			$it618_members_vrzapisale['it618_order_no'],
			$it618_members_vrzapisale['it618_face_score'],
			'<div style="width:460px">'.$it618_members_vrzapisale['it618_datamsg'].'<br>is_life:'.$it618_members_vrzapisale['it618_is_life'].' , life_score:'.$it618_members_vrzapisale['it618_life_score'].' , hack_score:'.$it618_members_vrzapisale['it618_hack_score'].' , face_score:'.$it618_members_vrzapisale['it618_face_score'].' , image_id:'.$it618_members_vrzapisale['it618_image_id'].'<br>'.$it618_members_vrzapisale['it618_about'].'</div>',
			$it618_members_vrzapisale['it618_incorrect'],
			$it618_members_vrzapisale['it618_msg'],
			$username,
			date('Y-m-d H:i:s', $it618_members_vrzapisale['it618_time'])
		));
	}
echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>