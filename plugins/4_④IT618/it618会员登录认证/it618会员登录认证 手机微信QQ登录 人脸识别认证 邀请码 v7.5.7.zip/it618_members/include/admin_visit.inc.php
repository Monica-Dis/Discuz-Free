<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql = "1";
if($_GET['uid']!=''){$it618sql .= " and it618_uid = ".intval($_GET['uid']);}

$it618orderby='id desc';

$urlsql='&key='.$_GET['key'].'&uid='.$_GET['uid'];

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_visit&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1".$urlsql);
showtableheaders($strtmptitle[$cp1],'it618_regsafe_checks');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s3'].' <input name="key" style="width:380px;margin-right:3px" value="'.$_GET['key'].'" class="txt" />'.$it618_members_lang['s853'].' <input name="uid" style="width:80px;margin-right:0px" value="'.$_GET['uid'].'" class="txt" />');
	
	$count = C::t('#it618_members#it618_members_visit')->count_all_by_search($it618sql,$it618orderby,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_visit&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do".$urlsql);
	if($reabc[6]!='m')return;
	echo '<tr><td colspan=8>'.$it618_members_lang['s11'].$count.' <span style="float:right">'.$it618_members_lang['s854'].'</span></td></tr>';
	showsubtitle(array($it618_members_lang['s852'], $it618_members_lang['s846'], $it618_members_lang['s850']));
	
	foreach(C::t('#it618_members#it618_members_visit')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['key'],$startlimit,$ppp
	) as $it618_members_visit) {
		
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_visit['it618_uid']);
		$username='<div style="float:left;line-height:20px"><a href="home.php?mod=space&uid='.$it618_members_visit['it618_uid'].'" target="_blank">'.$username.'</a><br>'.$it618_members_visit['it618_uid'].'</div>';
		$u_avatarimg=it618_members_discuz_uc_avatar($it618_members_visit['it618_uid'],'middle');
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			'<div style="width:190px"><a href="'.$u_avatarimg.'" target="_blank"><img src="'.$u_avatarimg.'" width=40 style="vertical-align:middle;float:left;margin-right:6px"></a> '.$username.'</div>',
			'<div style="width:680px"><a href="'.$it618_members_visit['it618_url'].'" target="_blank">'.$it618_members_visit['it618_url'].'</a><br><font color=#999>'.$it618_members_visit['it618_bz'].'</font></div>',
			$it618_members_visit['it618_type'].'<br>'.$it618_members_visit['it618_ip'].'<br><font color=#999>'.date('Y-m-d H:i:s', $it618_members_visit['it618_time']).'</font>'
		));
	}
echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>