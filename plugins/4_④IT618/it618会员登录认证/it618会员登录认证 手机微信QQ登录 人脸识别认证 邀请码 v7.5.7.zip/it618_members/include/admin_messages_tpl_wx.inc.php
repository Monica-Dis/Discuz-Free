<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_members#it618_members_messages_tpl_wx')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_title'])) {
		foreach($_GET['it618_title'] as $id => $val) {
			
			C::t('#it618_members#it618_members_messages_tpl_wx')->update($id,array(
				'it618_title' => $_GET['it618_title'][$id],
				'it618_tplid' => $_GET['it618_tplid'][$id],
				'it618_label' => $_GET['it618_label'][$id],
				'it618_about' => $_GET['it618_about'][$id],
				'it618_order' => $_GET['it618_order'][$id]
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_title_array = !empty($_GET['newit618_title']) ? $_GET['newit618_title'] : array();
	$newit618_tplid_array = !empty($_GET['newit618_tplid']) ? $_GET['newit618_tplid'] : array();
	$newit618_label_array = !empty($_GET['newit618_label']) ? $_GET['newit618_label'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_title_array as $key => $value) {
		
		$it618_count=$newit618_count_array[$key];
		if($newit618_count_array[$key]<3)$it618_count=3;

		C::t('#it618_members#it618_members_messages_tpl_wx')->insert(array(
			'it618_title' => $newit618_title_array[$key],
			'it618_tplid' => $newit618_tplid_array[$key],
			'it618_label' => $newit618_label_array[$key],
			'it618_about' => $newit618_about_array[$key],
			'it618_order' => $newit618_order_array[$key],
		), true);
		$ok2=$ok2+1;
	}

	cpmsg($it618_members_lang['s65'].$ok1.' '.$it618_members_lang['s66'].$ok2.' '.$it618_members_lang['s67'].$del, "action=plugins&identifier=$identifier&cp=admin_messages_tpl_wx&pmod=admin_sendmessages_wx&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_messages_tpl_wx&pmod=admin_sendmessages_wx&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s249'],'it618_members_messages_tpl_wx');

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_members_messages_tpl_wx'));
	
	echo '<tr><td colspan="6" style="line-height:18px">'.$it618_members_lang['s251'].'</td></tr>';
	echo '<tr><td colspan=6>'.$it618_members_lang['s84'].$count.'<span style="float:right;color:red"></span></td></tr>';
	
	showsubtitle(array($it618_members_lang['s152'], $it618_members_lang['s253'],$it618_members_lang['s81'],$it618_members_lang['s252'],$it618_members_lang['s254'],$it618_members_lang['s82']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_members_messages_tpl_wx')." ORDER BY id ASC LIMIT $startlimit, $ppp");
	while($it618_members_messages_tpl_wx = DB::fetch($query)) {

		showtablerow('', array('class="td25"', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_members_messages_tpl_wx['id']."\">".$it618_members_messages_tpl_wx['id'],
			'<textarea style="width:150px;height:50px" name="it618_title['.$it618_members_messages_tpl_wx['id'].']">'.$it618_members_messages_tpl_wx['it618_title'].'</textarea>',
			'<textarea style="width:200px;height:50px" name="it618_tplid['.$it618_members_messages_tpl_wx['id'].']">'.$it618_members_messages_tpl_wx['it618_tplid'].'</textarea>',
			'<textarea style="width:290px;height:50px" name="it618_label['.$it618_members_messages_tpl_wx['id'].']">'.$it618_members_messages_tpl_wx['it618_label'].'</textarea>',
			'<textarea style="width:380px;height:50px" name="it618_about['.$it618_members_messages_tpl_wx['id'].']">'.$it618_members_messages_tpl_wx['it618_about'].'</textarea>',
			'<input type="text" style="width:30px" name="it618_order['.$it618_members_messages_tpl_wx['id'].']" value="'.$it618_members_messages_tpl_wx['it618_order'].'">'
		));
	}

	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
	
		return [
				[[1,''], [1, ' <textarea style="width:150px;height:50px" name="newit618_title[]"></textarea>'], [1, ' <textarea style="width:200px;height:50px" name="newit618_tplid[]"></textarea>'], [1, ' <textarea style="width:290px;height:50px" name="newit618_label[]"></textarea>'], [1, ' <textarea style="width:380px;height:50px" name="newit618_about[]"></textarea>'], [1, ' <input type="text" style="width:30px" name="newit618_order[]">']]
				];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="6"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism·taobao·com*/
?>