<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql = "1";

if($_GET['uid']>0){
	$it618sql .= " and it618_uid =".intval($_GET['uid']);
}

if($_GET['state']) {
	$it618_state0='';$it618_state1='';$it618_state2='';$it618_state3='';
	if($_GET['state']=='0'){$it618_state0='selected="selected"';}
	if($_GET['state']=='1'){$it618sql.=" and it618_state=1";$it618_state1='selected="selected"';}
	if($_GET['state']=='2'){$it618sql.=" and it618_state=2";$it618_state2='selected="selected"';}
	if($_GET['state']=='3'){$it618sql.= " and it618_state=3";$it618_state3='selected="selected"';}
}

$it618orderby='it618_time desc,id desc';

$urlsql='&key='.$_GET['key'].'&uid='.$_GET['uid'].'&state='.$_GET['state'];
if($reabc[6]!='m')return;

if(submitcheck('it618sercsubmit')){
	$page=1;
}

if(submitcheck('it618submit_pass')){
	$pass=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$it618_members_rzuser=C::t('#it618_members#it618_members_rzuser')->fetch_by_id($delid);
		C::t('#it618_members#it618_members_rzuser')->update($it618_members_rzuser["id"],array(
			'it618_checktime' => $_G['timestamp'],
			'it618_checkcount' => $it618_members_rzuser["it618_checkcount"]+1,
			'it618_state' => 1
		));
		$pass=$pass+1;
	}
	it618_members_sendmessageapi('rzpass_user',$delid);
	cpmsg($it618_members_lang['s644'].$pass, "action=plugins&identifier=$identifier&cp=admin_members_rz&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$pass=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		C::t('#it618_members#it618_members_rzuser')->update($delid,array(
			'it618_checktime' => $_G['timestamp'],
			'it618_statebz' => $_GET['statebz'],
			'it618_apicount' => 0,
			'it618_state' => 3
		));
		$pass=$pass+1;
	}
	it618_members_sendmessageapi('rznopass_user',$delid);
	cpmsg($it618_members_lang['s645'].$pass, "action=plugins&identifier=$identifier&cp=admin_members_rz&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_add')){
	$rzid = C::t('#it618_members#it618_members_rzuser')->insert(array(
		'it618_uid' => $_GET['it618_uid'],
		'it618_name' => $_GET['it618_name'],
		'it618_time' => $_G['timestamp'],
		'it618_checktime' => $_G['timestamp'],
		'it618_state' => 1
	), true);

	cpmsg($it618_members_lang['s843'], "action=plugins&identifier=$identifier&cp=admin_members_rz&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_editrzmode')){
	$ok=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$it618_rzmodes=$_GET['it618_rzmodes'][$delid];
		if($it618_rzmodes!=''){
			$tmparr=explode('|',$it618_rzmodes);
				
			$complexity = $tmparr[0];
			if($complexity<=0)$complexity=0;
			if($complexity>3)$complexity=3;
			
			$motions = $tmparr[1];
			if($motions<=0)$motions=1;
			if($motions>4)$motions=4;
			
			$it618_rzmodes=$complexity.'|'.$motions;
		}
		C::t('#it618_members#it618_members_rzuser')->update($delid,array(
			'it618_rzmodes' => $it618_rzmodes
		));
		$ok=$ok+1;
	}

	cpmsg($it618_members_lang['s895'].$ok, "action=plugins&identifier=$identifier&cp=admin_members_rz&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_del')){
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		DB::delete('it618_members_rzuser', "id=$delid");
		$del=$del+1;
	}

	cpmsg($it618_members_lang['s837'].$del, "action=plugins&identifier=$identifier&cp=admin_members_rz&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if($it618_members['members_rzautocheck']>=2){
	$rzaboutstr='<br><input type="submit" class="btn" name="it618submit_editrzmode" value="'.$it618_members_lang['s892'].'"/> '.$it618_members_lang['s894'];
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_members_rz&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($it618_members_lang['s459'],'it618_members_rzuser');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s629'].' <input name="key" style="width:260px" value="'.$_GET['key'].'" class="txt" /> '.$it618_members_lang['s58'].' <input name="uid" style="width:60px;margin-right:3px" value="'.$_GET['uid'].'" class="txt" /> '.$it618_members_lang['s646'].' <select name="state" style="margin-right:3px"><option value="" '.$it618_state0.'>'.$it618_members_lang['s647'].'</option><option value="1" '.$it618_state1.'>'.$it618_members_lang['s636'].'</option><option value="2" '.$it618_state2.'>'.$it618_members_lang['s637'].'</option><option value="3" '.$it618_state3.'>'.$it618_members_lang['s638'].'</option></select><span style="float:right">'.$it618_members_lang['s839'].'<input name="it618_uid" style="width:60px" class="txt" /> '.$it618_members_lang['s840'].'<input name="it618_name" style="width:60px" class="txt" /><input type="submit" class="btn" name="it618submit_add" value="'.$it618_members_lang['s841'].'" onclick="return confirm(\''.$it618_members_lang['s842'].'\')"/></span>');
	
	if($reabc[8]!='m')return;
	$count = C::t('#it618_members#it618_members_rzuser')->count_all_by_search($it618sql,$it618orderby,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_members_rz&pmod=admin_members&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=8>'.$it618_members_lang['s11'].$count.' <span style="float:right;color:red">'.$it618_members_lang['s641'].'</span></td></tr>';
	
	showsubtitle(array('',$it618_members_lang['s17'], $it618_members_lang['s631'],$it618_members_lang['s632'],$it618_members_lang['s633'].'/'.$it618_members['members_certdiytitle'],$it618_members_lang['s634'],$it618_members_lang['s635']));
	
	foreach(C::t('#it618_members#it618_members_rzuser')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['key'],$startlimit,$ppp
	) as $it618_members_rzuser) {
		
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$it618_members_rzuser['it618_uid'])>0){
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_rzuser['it618_uid']);
			$username='<div style="float:left;line-height:20px"><a href="home.php?mod=space&uid='.$it618_members_rzuser['it618_uid'].'" target="_blank">'.$username.'</a><br>'.$it618_members_rzuser['it618_uid'].'</div>';
		}else{
			C::t('#it618_members#it618_members_rzuser')->delete_by_id($it618_members_rzuser['id']);
			continue;
		}
		
		$cardstr='';
		if($it618_members_rzuser['it618_cardid']!=''||$it618_members_rzuser["it618_cardimg1"]!=''){
			$cardstr=$it618_members_rzuser['it618_cardid'].' <a href="'.$it618_members_rzuser["it618_cardimg3"].'" target="_blank"><img src="'.$it618_members_rzuser["it618_cardimg3"].'" width="35" style="vertical-align:middle" /></a> <a href="'.$it618_members_rzuser["it618_cardimg2"].'" target="_blank"><img src="'.$it618_members_rzuser["it618_cardimg2"].'" width="35" style="vertical-align:middle;margin-left:6px" /></a> <a href="'.$it618_members_rzuser["it618_cardimg1"].'" target="_blank"><img src="'.$it618_members_rzuser["it618_cardimg1"].'" width="35" style="vertical-align:middle;margin-left:6px" /></a>';
			
			if($it618_members_rzuser["it618_rzvideo"]!=''){
				$cardstr.='<a href="'.$it618_members_rzuser["it618_rzvideo"].'" target="_blank"><img src="source/plugin/it618_members/images/rzvideo.png" width="23" style="vertical-align:middle;margin-left:6px" /></a>';
			}
		}
		
		$timestr=date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']).'<br>'.date('Y-m-d H:i:s', $it618_members_rzuser['it618_checktime']);
		if($it618_members_rzuser['it618_state']==1){
			$it618_state='<font color=green>'.$it618_members_lang['s636'].'</font>';
		}
		$rzmodestr='';
		if($it618_members_rzuser['it618_state']==2){
			$it618_state='<font color=red>'.$it618_members_lang['s637'].'</font>';
			$timestr=date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']);
			
			if($it618_members['members_rzautocheck']>=2){
				$rzmodestr='<br>'.$it618_members_lang['s893'].'<input type="text" style="width:80px" name="it618_rzmodes['.$it618_members_rzuser['id'].']" value="'.$it618_members_rzuser['it618_rzmodes'].'"/> <font color=#999>'.$it618_members_lang['s898'].'</font>';
			}
		}
		
		if($cardstr!=''){
			$cardstr.='<br>';
		}
		
		$aboutstr=$it618_members_rzuser['it618_about'];
		if(strpos($_SERVER['HTTP_HOST'],'localhost')&&$aboutstr!=''){
			$aboutstr='';
			$it618_abouts=explode("|",str_replace(array("\r\n", "\r", "\n"), '|', $it618_members_rzuser['it618_about']));
			
			for($i=0;$i<count($it618_abouts);$i++){
				$it618_about=trim($it618_abouts[$i]);
				
				$it618_plugin_users=C::t('#it618_plugin#it618_plugin_users')->fetch_by_siteid($it618_about);
				$siteurlstr=$it618_plugin_users['it618_siteurl'];
				
				$urlstr='';
				if($it618_plugin_users['it618_siteurl']!=$it618_plugin_users['it618_clienturl']){
					$urlstr='<a href="'.$it618_plugin_users['it618_clienturl'].'" target="_blank">'.$it618_members_lang['s731'].'</a>';
				}
				
				$aboutstr.='<a href="'.$siteurlstr.'" target="_blank">'.$siteurlstr.'</a> '.$urlstr.'<br><a href="'.ADMINSCRIPT."?action=plugins&identifier=it618_plugin&cp=admin_users&pmod=admin_users&operation=$operation&do=157&sid=$it618_about".'" target="_blank">'.$it618_about.'</a><br>';
			}
		}

		$it618_statebz='';
		if($it618_members_rzuser['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_members_lang['s638'].'</font>';
			if($it618_members_rzuser['it618_statebz']!='')$it618_statebz='<br><font color=blue>'.$it618_members_lang['s706'].$it618_members_rzuser['it618_statebz'].'</font>';
		}
		
		$it618_sex='';
		if($it618_members_rzuser['it618_sex']==1){
			$it618_sex=$it618_members_lang['s832'];
		}else if($it618_members_rzuser['it618_sex']==2){
			$it618_sex=$it618_members_lang['s838'];
		}
		
		$tel=C::t('#it618_members#it618_members_user')->fetch_tel_by_uid($it618_members_rzuser['it618_uid']);
		if($tel!=$it618_members_rzuser['it618_tel']){
			$telstr= $it618_members_rzuser['it618_tel'].'<br>'.$tel;
		}else{
			$telstr= $tel;
		}
		
		$u_avatarimg=it618_members_discuz_uc_avatar($it618_members_rzuser['it618_uid'],'middle');
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_members_rzuser['id']."\" $disabled>",
				'<a href="'.$u_avatarimg.'" target="_blank"><img src="'.$u_avatarimg.'" width=40 style="vertical-align:middle;float:left;margin-right:6px"></a> '.$username,
				$it618_members_rzuser['it618_name'].'<br>'.$it618_sex.' '.$telstr,
				'<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$it618_members_rzuser['it618_qq'].'&site=qq&menu=yes">'.$it618_members_rzuser['it618_qq'].'</a><br>'.$it618_members_rzuser['it618_wx'],
				$cardstr.$aboutstr.''.$it618_statebz.$rzmodestr,
				$it618_state,
				$timestr
			));
	}

echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_members_lang['s89'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_pass" value="'.$it618_members_lang['s639'].'" onclick="return confirm(\''.$it618_members_lang['s642'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_members_lang['s640'].'" onclick="return confirm(\''.$it618_members_lang['s643'].'\')"/> <input type="submit" class="btn" name="it618submit_del" value="'.$it618_members_lang['s835'].'" onclick="return confirm(\''.$it618_members_lang['s836'].'\')"/><br>'.$it618_members_lang['s706'].'<input name="statebz" style="width:380px;margin-right:3px" class="txt" />'.$rzaboutstr.' &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>