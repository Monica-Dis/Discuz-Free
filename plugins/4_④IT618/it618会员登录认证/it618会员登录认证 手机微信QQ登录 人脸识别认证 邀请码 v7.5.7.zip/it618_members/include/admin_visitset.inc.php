<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/visitset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/visitset.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/visitset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$visitset[\'isok\']=\''.trim($_GET['isok'])."';\n";
		$fileData .= '$visitset[\'deldays\']=\''.intval($_GET['deldays'])."';\n";
		$fileData .= '$visitset[\'okuids\']=\''.trim($_GET['okuids'])."';\n";
		$fileData .= '$visitset[\'uids\']=\''.trim($_GET['uids'])."';\n";
		$fileData .= '$visitset[\'checktimes\']=\''.intval($_GET['checktimes'])."';\n";
		$fileData .= '$visitset[\'count\']=\''.intval($_GET['count'])."';\n";
		$fileData .= '$visitset[\'nocheckuids\']=\''.trim($_GET['nocheckuids'])."';\n";
		$fileData .= '$visitset[\'about\']=\''.trim($_GET['about'])."';\n";
		$fileData .= '$visitset[\'oktimes\']=\''.intval($_GET['oktimes'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	cpmsg($it618_members_lang['s571'], "action=plugins&identifier=$identifier&cp=admin_visitset&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_visitset&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

if($visitset['isok']==1)$check_isok='checked="checked"';else $check_isok='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr class="header"><th width=180>'.$it618_members_lang['s610'].'</th><th>'.$it618_members_lang['s611'].'</th><th>'.$it618_members_lang['s612'].'</th></tr>

<tr class="hover">
<td>'.$it618_members_lang['s865'].'</td><td class="longtxt"><input type="checkbox" name="isok" value=1 '.$check_isok.'></td>
<td>'.$it618_members_lang['s866'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s856'].'</td><td class="longtxt"><input name="deldays" value="'.$visitset['deldays'].'" style="width:300px" /></td>
<td>'.$it618_members_lang['s857'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s869'].'</td><td class="longtxt"><textarea name="okuids" style="width:300px;height:38px" />'.$visitset['okuids'].'</textarea></td>
<td>'.$it618_members_lang['s870'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s858'].'</td><td class="longtxt"><textarea name="uids" style="width:300px;height:38px" />'.$visitset['uids'].'</textarea></td>
<td>'.$it618_members_lang['s859'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s860'].'</td><td class="longtxt"><input name="checktimes" value="'.$visitset['checktimes'].'" style="width:300px" /></td>
<td>'.$it618_members_lang['s861'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s862'].'</td><td class="longtxt"><input name="count" value="'.$visitset['count'].'" style="width:300px" /></td>
<td>'.$it618_members_lang['s863'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s882'].'</td><td class="longtxt"><textarea name="nocheckuids" style="width:300px;height:38px" />'.$visitset['nocheckuids'].'</textarea></td>
<td>'.$it618_members_lang['s883'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s864'].'</td><td class="longtxt"><textarea name="about" style="width:300px;height:38px" />'.$visitset['about'].'</textarea></td>
<td>'.$it618_members_lang['s885'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s867'].'</td><td class="longtxt"><input name="oktimes" value="'.$visitset['oktimes'].'" style="width:300px" /></td>
<td>'.$it618_members_lang['s868'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_members_lang['s589']);

if(count($reabc)!=14)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>