<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
}

$it618_members_set[0]=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout0');
$it618_members_set[1]=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout1');
$it618_members_set[2]=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout2');
$it618_members_set[3]=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout3');

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$wxjk_isdelbdok=trim($_GET['wxjk_isdelbdok']);
		if(trim($_GET['wxjk_iswxregtel'])==0){
			$wxjk_isdelbdok=0;
		}
		
		$wxjk_subscribetime=trim($_GET['wxjk_subscribetime']);
		if(trim($_GET['wxjk_subscribetime'])<1){
			$wxjk_subscribetime=1;
		}
		
		$fileData = '$wxjk_mode=\''.trim($_GET['wxjk_mode'])."';\n";
		$fileData .= '$wxjk_appid=\''.trim($_GET['wxjk_appid'])."';\n";
		$fileData .= '$wxjk_appsecret=\''.trim($_GET['wxjk_appsecret'])."';\n";
		$fileData .= '$wxjk_pluginkeys=\''.trim($_GET['wxjk_pluginkeys'])."';\n";
		$fileData .= '$wxjk_iswxregtel=\''.trim($_GET['wxjk_iswxregtel'])."';\n";
		$fileData .= '$wxjk_wxreglogintip=\''.trim($_GET['wxjk_wxreglogintip'])."';\n";
		$fileData .= '$wxjk_domain=\''.trim($_GET['wxjk_domain'])."';\n";
		$fileData .= '$wxjk_getcodeurl=\''.trim($_GET['wxjk_getcodeurl'])."';\n";
		$fileData .= '$wxjk_subscribe=\''.trim($_GET['wxjk_subscribe'])."';\n";
		$fileData .= '$wxjk_subscribetime=\''.$wxjk_subscribetime."';\n";
		$fileData .= '$wxjk_isdelbdok=\''.$wxjk_isdelbdok."';\n";
		$fileData .= '$wxjk_iswapwxbtn=\''.trim($_GET['wxjk_iswapwxbtn'])."';\n";
		$fileData .= '$wxjk_ispccodebtn=\''.trim($_GET['wxjk_ispccodebtn'])."';\n";

		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		for($i=0;$i<=3;$i++){
			if(C::t('#it618_members#it618_members_set')->count_by_setname('wxjk_wxabout'.$i)==0){
				C::t('#it618_members#it618_members_set')->insert(array(
					'setname' => 'wxjk_wxabout'.$i,
					'setvalue' => $_GET['wxjk_wxabout'.$i]
				), true);
			}else{
				C::t('#it618_members#it618_members_set')->update($it618_members_set[$i]['id'],array(
					'setvalue' => $_GET['wxjk_wxabout'.$i]
				));
			}
		}
	}

	cpmsg($it618_members_lang['s403'], "action=plugins&identifier=$identifier&cp=admin_wxjk&pmod=admin_wxjk&operation=$operation&do=$do", 'succeed');
}

if($wxjk_iswxregtel==1)$check_iswxregtel='checked="checked"';else $check_iswxregtel='';
if($wxjk_isdelbdok==1)$check_isdelbdok='checked="checked"';else $check_isdelbdok='';
if($wxjk_iswapwxbtn==1)$check_iswapwxbtn='checked="checked"';else $check_iswapwxbtn='';
if($wxjk_ispccodebtn==1)$check_ispccodebtn='checked="checked"';else $check_ispccodebtn='';

$wxjk_subscribeoption='<option value="0">'.$it618_members_lang['s788'].'</option>
	<option value="1">'.$it618_members_lang['s786'].'</option>
	<option value="2">'.$it618_members_lang['s787'].'</option>';
$wxjk_subscribeoption=str_replace('<option value="'.$wxjk_subscribe.'"','<option value="'.$wxjk_subscribe.'" selected="selected"',$wxjk_subscribeoption);

if($wxjk_subscribe==2)$subscribecss='style="display:"';else $subscribecss='style="display:none"';
if($wxjk_subscribetime=='')$wxjk_subscribetime=60;

if($wxjk_mode=='')$wxjk_mode=4;
$wxjk_modeoption='<option value="1">'.$it618_members_lang['s561'].'</option>
	<option value="2">'.$it618_members_lang['s562'].'</option>
	<option value="3">'.$it618_members_lang['s563'].'</option>
	<option value="4">'.$it618_members_lang['s412'].'</option>';
$wxjk_modeoption=str_replace('<option value="'.$wxjk_mode.'"','<option value="'.$wxjk_mode.'" selected="selected"',$wxjk_modeoption);

$modecss1='style="display:none"';$modecss2='style="display:none"';
$modecss3='style="display:none"';$modecss4='style="display:none"';
if($wxjk_mode==1)$modecss1='style="display:"';
if($wxjk_mode==2)$modecss2='style="display:"';
if($wxjk_mode==3)$modecss3='style="display:"';
if($wxjk_mode==4)$modecss4='style="display:"';

if($wxjk_wxreglogintip=='')$wxjk_wxreglogintip=$it618_members_lang['s381'];


showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_wxjk&pmod=admin_wxjk&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_members_lang['s490'].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_members_lang['s401'].'</font></td></tr>
<tr class="header"><th width=168>'.$it618_members_lang['s398'].'</th><th width=360>'.$it618_members_lang['s399'].'</th><th>'.$it618_members_lang['s400'].'</th></tr>

<tr class="hover"><td>'.$it618_members_lang['s384'].'</td><td class="tdvalue"><input class="tdtxt" name="wxjk_appid" value="'.$wxjk_appid.'" /></td>
<td class="tdabout">'.$it618_members_lang['s385'].'</td></tr>

<tr class="hover"><td>'.$it618_members_lang['s386'].'</td><td class="tdvalue"><input class="tdtxt" name="wxjk_appsecret" value="'.$wxjk_appsecret.'" /></td>
<td class="tdabout">'.$it618_members_lang['s387'].'</td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s733'].'</td><td class="tdvalue"><input class="tdtxt" name="wxjk_getcodeurl" value="'.$wxjk_getcodeurl.'" /></td>
<td class="tdabout">'.$it618_members_lang['s734'].'</td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s502'].'</td><td class="tdvalue"><input class="tdtxt" name="wxjk_pluginkeys" value="'.$wxjk_pluginkeys.'" /></td>
<td class="tdabout">'.$it618_members_lang['s503'].'</td>
</tr>

<tr class="hover">
<td style="color:red">'.$it618_members_lang['s374'].'</td><td class="tdvalue"><select name="wxjk_mode" onchange="selectmode(this)">'.$wxjk_modeoption.'</select></td>
<td class="tdabout">'.$it618_members_lang['s375'].'</td>
</tr>

<tr class="hover" name="mode1" '.$modecss1.'>
<td>'.$it618_members_lang['s416'].'</td><td colspan=2 style="color:#f30;line-height:20px">'.$it618_members_lang['s413'].'</td>
</tr>

<tr class="hover" name="mode2" '.$modecss2.'>
<td>'.$it618_members_lang['s416'].'</td><td colspan=2 style="color:#f30;line-height:20px">'.$it618_members_lang['s414'].'</td>
</tr>

<tr class="hover" name="mode3" '.$modecss3.'>
<td>'.$it618_members_lang['s416'].'</td><td colspan=2 style="color:#f30;line-height:20px">'.$it618_members_lang['s415'].'</td>
</tr>

<tr class="hover" name="mode2" '.$modecss2.'>
<td>'.$it618_members_lang['s377'].'</td><td class="tdvalue"><input type="checkbox" name="wxjk_iswxregtel" value=1 '.$check_iswxregtel.'></td>
<td class="tdabout">'.$it618_members_lang['s378'].'</td>
</tr>

<tr class="hover" name="mode2" '.$modecss2.'><td>'.$it618_members_lang['s433'].'</td><td class="tdvalue"><input class="tdtxt" name="wxjk_wxreglogintip" value="'.$wxjk_wxreglogintip.'" /></td>
<td class="tdabout">'.$it618_members_lang['s434'].'</td>
</tr>

<tr class="hover" name="mode2" '.$modecss2.'>
<td>'.$it618_members_lang['s427'].'</td><td class="tdvalue"><input type="checkbox" name="wxjk_isdelbdok" value=1 '.$check_isdelbdok.'></td>
<td class="tdabout">'.$it618_members_lang['s428'].'</td>
</tr>

<tr class="hover" style="display:none"><td>'.$it618_members_lang['s382'].'</td><td class="tdvalue"><input class="tdtxt" name="wxjk_domain" value="'.$wxjk_domain.'" /></td>
<td class="tdabout">'.$it618_members_lang['s383'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s1057'].'</td><td class="tdvalue"><input type="checkbox" name="wxjk_iswapwxbtn" value=1 '.$check_iswapwxbtn.'></td>
<td class="tdabout">'.$it618_members_lang['s1059'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s1058'].'</td><td class="tdvalue"><input type="checkbox" name="wxjk_ispccodebtn" value=1 '.$check_ispccodebtn.'></td>
<td class="tdabout">'.$it618_members_lang['s1060'].'</td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s388'].'</td><td class="tdvalue"><select name="wxjk_subscribe" onchange="selectsubscribe(this)">'.$wxjk_subscribeoption.'</select></td>
<td class="tdabout" style="line-height:18px">'.$it618_members_lang['s389'].'</td>
</tr>

<tr class="hover" name="subscribe" '.$subscribecss.'><td>'.$it618_members_lang['s789'].'</td><td class="tdvalue"><input class="tdtxt" name="wxjk_subscribetime" value="'.$wxjk_subscribetime.'" /></td>
<td class="tdabout">'.$it618_members_lang['s790'].'</td>
</tr>

<tr class="hover" name="mode2" '.$modecss2.'><td>'.$it618_members_lang['s544'].'</td><td class="tdvalue" colspan=2><textarea name="wxjk_wxabout3" style="width:800px;height:400px;visibility:hidden;">'.$it618_members_set[3]['setvalue'].'</textarea><div style="margin-top:6px;line-height:18px">'.$it618_members_lang['s546'].'</div></td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s391'].'</td><td class="tdvalue" colspan=2><textarea name="wxjk_wxabout0" style="width:800px;height:400px;visibility:hidden;">'.$it618_members_set[0]['setvalue'].'</textarea></td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s392'].'</td><td class="tdvalue" colspan=2><textarea name="wxjk_wxabout1" style="width:800px;height:400px;visibility:hidden;">'.$it618_members_set[1]['setvalue'].'</textarea><div style="margin-top:6px;line-height:18px">'.$it618_members_lang['s394'].'</div></td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s393'].'</td><td class="tdvalue" colspan=2><textarea name="wxjk_wxabout2" style="width:800px;height:400px;visibility:hidden;">'.$it618_members_set[2]['setvalue'].'</textarea><div style="margin-top:6px;line-height:18px">'.$it618_members_lang['s395'].'</div></td>
</tr>

</tr>

</table>
<style>
.tdabout{color:#999}
.tdvalue .tdtxt{width:300px}
.tdvalue .tdtextarea{width:300px;height:80px}
</style>

<link rel="stylesheet" href="source/plugin/it618_members/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_members/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_members/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_members/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_members/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor0 = K.create(\'textarea[name="wxjk_wxabout0"]\', {
			cssPath : \'source/plugin/it618_members/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_members/kindeditor/php/upload_json.php?imgwidth=900'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_members/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
		
		var editor1 = K.create(\'textarea[name="wxjk_wxabout1"]\', {
			cssPath : \'source/plugin/it618_members/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_members/kindeditor/php/upload_json.php?imgwidth=900'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_members/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
		
		var editor2 = K.create(\'textarea[name="wxjk_wxabout2"]\', {
			cssPath : \'source/plugin/it618_members/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_members/kindeditor/php/upload_json.php?imgwidth=900'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_members/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
		
		var editor3 = K.create(\'textarea[name="wxjk_wxabout3"]\', {
			cssPath : \'source/plugin/it618_members/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_members/kindeditor/php/upload_json.php?imgwidth=900'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_members/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>

<script>
function selectmode(obj){
	var trobj=document.getElementsByName("mode1");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}
	
	var trobj=document.getElementsByName("mode2");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}
	
	var trobj=document.getElementsByName("mode3");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}
	
	var trobj=document.getElementsByName("mode"+obj.value);
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="";
	}
}

function selectsubscribe(obj){
	if(obj.value==2){
		document.getElementsByName("subscribe")[0].style.display="";
	}else{
		document.getElementsByName("subscribe")[0].style.display="none";	
	}
}
</script>
';

showsubmit('it618submit', $it618_members_lang['s402']);

if(count($reabc)!=11)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>