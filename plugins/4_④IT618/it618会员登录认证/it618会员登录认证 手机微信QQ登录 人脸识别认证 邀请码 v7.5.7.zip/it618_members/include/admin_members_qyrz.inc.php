<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql = "1";

if($_GET['uid']>0){
	$it618sql .= " and it618_uid =".intval($_GET['uid']);
}

if($_GET['state']) {
	$it618_state0='';$it618_state1='';$it618_state2='';$it618_state3='';
	if($_GET['state']=='0'){$it618_state0='selected="selected"';}
	if($_GET['state']=='1'){$it618sql.=" and it618_state=1";$it618_state1='selected="selected"';}
	if($_GET['state']=='2'){$it618sql.=" and it618_state=2";$it618_state2='selected="selected"';}
	if($_GET['state']=='3'){$it618sql.= " and it618_state=3";$it618_state3='selected="selected"';}
}

$it618orderby='it618_time desc,id desc';

$urlsql='&key='.$_GET['key'].'&uid='.$_GET['uid'].'&state='.$_GET['state'];
if($reabc[6]!='m')return;

if(submitcheck('it618submit_pass')){
	$pass=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$it618_members_qyrz=C::t('#it618_members#it618_members_qyrz')->fetch_by_id($delid);
		C::t('#it618_members#it618_members_qyrz')->update($it618_members_qyrz["id"],array(
			'it618_checktime' => $_G['timestamp'],
			'it618_state' => 1
		));
		$pass=$pass+1;
	}
	it618_members_sendmessageapi('qyrzpass_user',$delid);
	cpmsg($it618_members_lang['s644'].$pass, "action=plugins&identifier=$identifier&cp=admin_members_qyrz&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$pass=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$it618_members_qyrz=C::t('#it618_members#it618_members_qyrz')->fetch_by_id($delid);
		C::t('#it618_members#it618_members_qyrz')->update($it618_members_qyrz["id"],array(
			'it618_checktime' => $_G['timestamp'],
			'it618_statebz' => $_GET['statebz'],
			'it618_state' => 3
		));
		$pass=$pass+1;
	}
	it618_members_sendmessageapi('qyrznopass_user',$delid);
	cpmsg($it618_members_lang['s645'].$pass, "action=plugins&identifier=$identifier&cp=admin_members_qyrz&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_members_qyrz&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($it618_members_lang['s727'],'it618_members_qyrz');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s629'].' <input name="key" style="width:260px" value="'.$_GET['key'].'" class="txt" /> '.$it618_members_lang['s58'].' <input name="uid" style="width:60px;margin-right:3px" value="'.$_GET['uid'].'" class="txt" /> '.$it618_members_lang['s646'].' <select name="state" style="margin-right:3px"><option value="" '.$it618_state0.'>'.$it618_members_lang['s647'].'</option><option value="1" '.$it618_state1.'>'.$it618_members_lang['s636'].'</option><option value="2" '.$it618_state2.'>'.$it618_members_lang['s637'].'</option><option value="3" '.$it618_state3.'>'.$it618_members_lang['s638'].'</option></select>');
	
	if($reabc[8]!='m')return;
	$count = C::t('#it618_members#it618_members_qyrz')->count_all_by_search($it618sql,$it618orderby,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_members_qyrz&pmod=admin_members&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=8>'.$it618_members_lang['s11'].$count.' <span style="float:right;color:red">'.$it618_members_lang['s641'].'</span></td></tr>';
	
	showsubtitle(array('',$it618_members_lang['s17'], $it618_members_lang['s729'],$it618_members_lang['s728'],$it618_members_lang['s633'],$it618_members_lang['s634'],$it618_members_lang['s635']));
	
	foreach(C::t('#it618_members#it618_members_qyrz')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['key'],$startlimit,$ppp
	) as $it618_members_qyrz) {
		
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$it618_members_qyrz['it618_uid'])>0){
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_qyrz['it618_uid']);
			$username='<div style="float:left;line-height:20px"><a href="home.php?mod=space&uid='.$it618_members_qyrz['it618_uid'].'" target="_blank">'.$username.'</a><br>'.$it618_members_qyrz['it618_uid'].'</div>';
		}else{
			C::t('#it618_members#it618_members_qyrz')->delete_by_id($it618_members_qyrz['id']);
			continue;
		}
		
		$qystr=$it618_members_qyrz['it618_creditcode'].'<br><a href="'.$it618_members_qyrz["it618_yyzzimg"].'" target="_blank"><img src="'.$it618_members_qyrz["it618_yyzzimg"].'" width="23" style="vertical-align:middle" /></a> <a href="'.$it618_members_qyrz["it618_sqsimg"].'" target="_blank"><img src="'.$it618_members_qyrz["it618_sqsimg"].'" width="23" style="vertical-align:middle" /></a>';
		
		$cardstr='';
		if($it618_members_qyrz['it618_cardid']!=''){
			$cardstr=$it618_members_qyrz['it618_cardid'].'<br><a href="'.$it618_members_qyrz["it618_cardimg1"].'" target="_blank"><img src="'.$it618_members_qyrz["it618_cardimg1"].'" width="23" style="vertical-align:middle" /></a> <a href="'.$it618_members_qyrz["it618_cardimg2"].'" target="_blank"><img src="'.$it618_members_qyrz["it618_cardimg2"].'" width="23" style="vertical-align:middle" /></a>';
		}
		
		$timestr=date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']).'<br>'.date('Y-m-d H:i:s', $it618_members_qyrz['it618_checktime']);
		if($it618_members_qyrz['it618_state']==1){
			$it618_state='<font color=green>'.$it618_members_lang['s636'].'</font>';
		}
		if($it618_members_qyrz['it618_state']==2){
			$it618_state='<font color=red>'.$it618_members_lang['s637'].'</font>';
			$timestr=date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']);
		}

		$it618_statebz='';
		if($it618_members_qyrz['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_members_lang['s638'].'</font>';
			if($it618_members_qyrz['it618_statebz']!='')$it618_statebz='<br><font color=blue>'.$it618_members_lang['s706'].$it618_members_qyrz['it618_statebz'].'</font>';
		}
		
		$tel=C::t('#it618_members#it618_members_user')->fetch_tel_by_uid($it618_members_qyrz['it618_uid']);
		if($tel!=$it618_members_qyrz['it618_tel']){
			$telstr= $it618_members_qyrz['it618_tel'].' '.$tel;
		}else{
			$telstr= $tel;
		}
		
		$u_avatarimg=it618_members_discuz_uc_avatar($it618_members_qyrz['it618_uid'],'middle');
		
		showtablerow('', array('class="td25"', '', '', '', ''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_members_qyrz['id']."\" $disabled>",
				'<a href="'.$u_avatarimg.'" target="_blank"><img src="'.$u_avatarimg.'" width=40 style="vertical-align:middle;float:left;margin-right:6px"></a> '.$username,
				$it618_members_qyrz['it618_qyname'].'<br>'.$qystr,
				$it618_members_qyrz['it618_name'].' '.$telstr.'<br><a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$it618_members_qyrz['it618_qq'].'&site=qq&menu=yes">'.$it618_members_qyrz['it618_qq'].'</a><br>'.$it618_members_qyrz['it618_wx'],
				$cardstr.$it618_statebz,
				$it618_state,
				$timestr
			));
	}

echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_members_lang['s89'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_pass" value="'.$it618_members_lang['s639'].'" onclick="return confirm(\''.$it618_members_lang['s642'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_members_lang['s640'].'" onclick="return confirm(\''.$it618_members_lang['s643'].'\')"/> '.$it618_members_lang['s706'].'<input name="statebz" style="width:380px;margin-right:3px" class="txt" /> &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>