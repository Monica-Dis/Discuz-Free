<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if($it618_members['members_iswxsms']==0){
	cpmsg($it618_members_lang['s409'], "action=plugins&identifier=$identifier&cp=admin_wxjk&pmod=admin_wxjk&operation=$operation&do=$do&page=$page", 'error');
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		$fileData = '$it618_isok=\''.trim($_GET['it618_isok'])."';\n";
		$fileData .= '$it618_uid_admin=\''.trim($_GET['it618_uid_admin'])."';\n";
		$fileData .= '$it618_isok_admin=\''.trim($_GET['it618_isok_admin'])."';\n";
		
		$fileData .= '$it618_body_post_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_post_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_post_admin_tplid_wxsms=\''.trim($_GET['it618_body_post_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_post_admin_isok=\''.trim($_GET['it618_body_post_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_posthf_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_posthf_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_posthf_admin_tplid_wxsms=\''.trim($_GET['it618_body_posthf_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_posthf_admin_isok=\''.trim($_GET['it618_body_posthf_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_post_postuser_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_post_postuser_wxsms']))."';\n";
		$fileData .= '$it618_body_post_postuser_tplid_wxsms=\''.trim($_GET['it618_body_post_postuser_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_post_postuser_isok=\''.trim($_GET['it618_body_post_postuser_isok'])."';\n";
		
		$fileData .= '$it618_body_posthf_postuser_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_posthf_postuser_wxsms']))."';\n";
		$fileData .= '$it618_body_posthf_postuser_tplid_wxsms=\''.trim($_GET['it618_body_posthf_postuser_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_posthf_postuser_isok=\''.trim($_GET['it618_body_posthf_postuser_isok'])."';\n";
		
		$fileData .= '$it618_body_posthf_posthfuser_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_posthf_posthfuser_wxsms']))."';\n";
		$fileData .= '$it618_body_posthf_posthfuser_tplid_wxsms=\''.trim($_GET['it618_body_posthf_posthfuser_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_posthf_posthfuser_isok=\''.trim($_GET['it618_body_posthf_posthfuser_isok'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_members_lang['s512'], "action=plugins&identifier=$identifier&cp=admin_wxmessage&pmod=admin_wxjk&operation=$operation&do=$do&page=$page", 'succeed');
}

echo '
<link rel="stylesheet" href="source/plugin/it618_members/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_members/kindeditor/kindeditor-min.js"></script>
';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_wxmessage&pmod=admin_wxjk&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s408'],'it618_members_message');

if($it618_isok==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
if($it618_isok_admin==1)$it618_isok_admin_checked='checked="checked"';else $it618_isok_admin_checked="";
if($it618_body_post_admin_isok==1)$it618_body_post_admin_isok_checked='checked="checked"';else $it618_body_post_admin_isok_checked="";
if($it618_body_posthf_admin_isok==1)$it618_body_posthf_admin_isok_checked='checked="checked"';else $it618_body_posthf_admin_isok_checked="";
if($it618_body_post_postuser_isok==1)$it618_body_post_postuser_isok_checked='checked="checked"';else $it618_body_post_postuser_isok_checked="";
if($it618_body_posthf_postuser_isok==1)$it618_body_posthf_postuser_isok_checked='checked="checked"';else $it618_body_posthf_postuser_isok_checked="";
if($it618_body_posthf_posthfuser_isok==1)$it618_body_posthf_posthfuser_isok_checked='checked="checked"';else $it618_body_posthf_posthfuser_isok_checked="";

echo '<style>table tr td{line-height:20px}</style>
<tr><td width=110>'.$it618_members_lang['s514'].'</td><td><input type="checkbox" id="it618_isok" name="it618_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.$it618_members_lang['s515'].'</label></td></tr>
<tr><td>'.$it618_members_lang['s521'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_uid_admin" value="'.$it618_uid_admin.'"><input type="checkbox" id="it618_isok_admin" name="it618_isok_admin" value="1" style="vertical-align:middle" '.$it618_isok_admin_checked.'> <label for="it618_isok_admin">'.$it618_members_lang['s522'].'</label></td></tr>

<tr><td colspan=2><strong>'.$it618_members_lang['s523'].'</strong> <font color=red>'.$it618_members_lang['s524'].'</font></td></tr>';

$it618_bodyarr=array(
'post_admin','posthf_admin',
'post_postuser','posthf_postuser',
'posthf_posthfuser'
);

$it618lang=explode(",",$it618_members_lang['s511']);

for($i=0;$i<count($it618_bodyarr);$i++){
	$it618_body_name=$it618_bodyarr[$i];
	
	if($it618_body_name=='post_admin'){$it618_body_title=$it618_members_lang['s525'];$it618_body_about=$it618_members_lang['s526'];}
	if($it618_body_name=='posthf_admin'){$it618_body_title=$it618_members_lang['s527'];$it618_body_about=$it618_members_lang['s528'];}
	if($it618_body_name=='post_postuser'){$it618_body_title=$it618_members_lang['s529'];$it618_body_about=$it618_members_lang['s530'];}
	if($it618_body_name=='posthf_postuser'){$it618_body_title=$it618_members_lang['s531'];$it618_body_about=$it618_members_lang['s532'];}
	if($it618_body_name=='posthf_posthfuser'){$it618_body_title=$it618_members_lang['s533'];$it618_body_about=$it618_members_lang['s534'];}
	
	$tmpname='it618_body_'.$it618_body_name.'_isok_checked';
	$it618_body_isok_checked=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name.'_wxsms';
	$it618_body_wxsms=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name.'_tplid_wxsms';
	$it618_body_tplid_wxsms=$$tmpname;
	
	echo '<tr><td colspan=2><input type="checkbox" id="it618_body_'.$it618_body_name.'_isok" name="it618_body_'.$it618_body_name.'_isok" value="1" style="vertical-align:middle" '.$it618_body_isok_checked.'><label for="it618_body_'.$it618_body_name.'_isok">'.$it618lang[0].' <span id="it618_body_'.$it618_body_name.'_title">'.$it618_body_title.'</span></label><br>'.$it618lang[1].'<input type="text" class="txt" style="width:420px;margin-top:3px" id="it618_body_'.$it618_body_name.'_wxsms" name="it618_body_'.$it618_body_name.'_wxsms" readonly="readonly" onclick="getwxsms(\''.$it618_body_name.'\')" value="'.$it618_body_wxsms.'">'.$it618lang[2].'<input type="text" class="txt" style="width:380px" name="it618_body_'.$it618_body_name.'_tplid_wxsms" value="'.$it618_body_tplid_wxsms.'">
	<br><span id="it618_body_'.$it618_body_name.'_about">'.$it618_body_about.'</span>
	</td></tr>';
}

echo '<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_members_lang['s402'].'" /></div></td></tr>

<div id="tmpsmsbtn"></div>
<style>
.wxsmstable tr th{font-weight:bold}
.wxsmstable tr td{padding:1px;padding-top:3px;padding-bottom:3px}
.wxsmstable tr td .tmplabel{width:113px;line-height:22px;text-align:right;color:blue;padding-right:3px;margin-right:2px;background-color:#fff}
.wxsmstable tr td .tmpvalue{width:760px;line-height:22px;padding-left:3px;background-color:#fff}
.wxsmstable tr td .savebtn{background-color:#390;padding:8px 35px;padding-bottom:10px;color:#fff;border:none}
.wxsmstable tr td .savebtn:hover{background-color:#3a0;}
.wxsmstable tr td .savebtn1{background-color:#e3e3e3;padding:8px 35px;padding-bottom:10px;color:#666;border:none}
.wxsmstable tr td .savebtn1:hover{background-color:#e8e8e8;}
</style>
<script>
var dialog_wxsms,tmpname,tmptitle,tmpabout,tmpbody;

KindEditor.ready(function(K) {K(\'#tmpsmsbtn\').click(function() {
	dialog_wxsms = K.dialog({
		width : 915,
		title : tmptitle,
		body : \'<div style="padding:8px;background-color:#fcfcfc;width:910px"><table class="wxsmstable"><tr><th>'.$it618_members_lang['s469'].'</th><th>'.$it618_members_lang['s470'].'</th></tr>\'+tmpbody+\'<tr><td colspan=2>\'+tmpabout+\'</td></tr><tr><td colspan=2><font color=green>'.$it618_members_lang['s471'].'</font></td></tr><tr><td colspan=2 align="center" style="padding-top:10px;padding-bottom:10px"><a class="savebtn" href="javascript:" onclick="savewxsms()">'.$it618_members_lang['s473'].'</a> <a class="savebtn1" href="javascript:" onclick="savewxsms1()">'.$it618_members_lang['s472'].'</a></td></tr></table></div>\',
		closeBtn : {
			name : \''.$it618_members_lang['s410'].'\',
			click : function(e) {
				dialog_wxsms.remove();
			}
		}
	});
	
	}, "html");
});

function getwxsms(it618_body_name){
	tmpname=it618_body_name;
	tmptitle=document.getElementById("it618_body_"+it618_body_name+"_title").innerHTML;
	tmpabout=document.getElementById("it618_body_"+it618_body_name+"_about").innerHTML;
	
	var tmpbody1=document.getElementById("it618_body_"+it618_body_name+"_wxsms").value;
	
	tmpbody="";
	if(tmpbody1=="")tmpbody1="|";
	var tmpbodyarr1=tmpbody1.split("@");
	for(var i=tmpbodyarr1.length;i<9;i++){
		tmpbodyarr1[i]="|";
	}
	
	for(var i=0;i<9;i++){
		var tmpbodyarr2=tmpbodyarr1[i].split("|");
		tmpbody=tmpbody+\'<tr><td><input type="text" class="tmplabel" id="tmplabel\'+i+\'" value="\'+tmpbodyarr2[0]+\'">:</td><td><input type="text" class="tmpvalue" id="tmpvalue\'+i+\'" value="\'+tmpbodyarr2[1]+\'"></td></tr>\';
	}

	document.getElementById("tmpsmsbtn").click();
}

function trimStr(str){return str.replace(/(^\s*)|(\s*$)/g,"");}

function savewxsms(){
	var wxsmsstr="";
	for(var i=0;i<9;i++){
		var tmplabel=trimStr(document.getElementById("tmplabel"+i).value);
		if(tmplabel!=""){
			var tmpvalue=document.getElementById("tmpvalue"+i).value;
			if(tmpvalue!=""){
				wxsmsstr=wxsmsstr+tmplabel+"|"+tmpvalue+"@";
			}else{
				alert("'.$it618_members_lang['s474'].'");
				document.getElementById("tmpvalue"+i).focus();
				return;
			}
		}
	}
	if(wxsmsstr!=""){
		wxsmsstr=wxsmsstr+"@";
		wxsmsstr=wxsmsstr.replace("@@","");
		document.getElementById("it618_body_"+tmpname+"_wxsms").value=wxsmsstr; 
	}
	dialog_wxsms.remove();
}

function savewxsms1(){
	dialog_wxsms.remove();
}

function gettype(obj){
	var trobj=document.getElementsByName("tr_smsbao");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}
	
	var trobj=document.getElementsByName("tr_alidayu");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}

	var jktype=obj.value;
	if(jktype=="alisms")jktype="alidayu";
	
	var trobj=document.getElementsByName("tr_"+jktype);
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="";
	}
	
	if(obj.value=="smsbao"){
		document.getElementById("it618_istest").style.display="";
	}else{
		document.getElementById("it618_istest").style.display="none";
	}
}
</script>
';

if(count($reabc)!=10)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>