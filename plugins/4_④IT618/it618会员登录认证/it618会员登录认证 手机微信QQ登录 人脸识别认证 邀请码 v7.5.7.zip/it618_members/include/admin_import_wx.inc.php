<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit_dao1')){
	if(trim($_GET['tablename'])==''||trim($_GET['uidname'])==''||trim($_GET['openidname'])==''){
		cpmsg($it618_members_lang['s310'], "action=plugins&identifier=$identifier&cp=admin_import_wx&pmod=admin_members&operation=$operation&do=$do&page=$page", 'error');
	}
	
	$ok1=0;
	$query = DB::query("SELECT * FROM ".DB::table(trim($_GET['tablename'])));
	while($wxtabletmp =	DB::fetch($query)){
		$tmpuid=$wxtabletmp[trim($_GET['uidname'])];
		$tmpopenid=$wxtabletmp[trim($_GET['openidname'])];
		
		if(C::t('#it618_members#it618_members_wxuser')->count_by_openid_uid($tmpopenid,$tmpuid)==0){
			$id=C::t('#it618_members#it618_members_wxuser')->insert(array(
				'it618_uid' => $tmpuid,
				'it618_wxopenid' => $tmpopenid,
				'it618_time' => $_G['timestamp']
			), true);
			$ok1=$ok1+1;
		}
	}
	
	cpmsg($it618_members_lang['s55'].$ok1, "action=plugins&identifier=$identifier&cp=admin_import_wx&pmod=admin_members&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_dao2')){
	$lines = $_GET['it618_content'];
	ini_set('memory_limit', '-1');
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $lines);
	$line=explode("@||@",$lines);
	$ok1=0;

	foreach($line as $key =>$li)
	{
		if(trim($li)!=''){
			$tmpliarr=explode(',',$li);
			if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".intval($tmpliarr[0]))>0){

				if(C::t('#it618_members#it618_members_wxuser')->count_by_openid_uid($tmpliarr[1],$tmpliarr[0])==0){
					$id=C::t('#it618_members#it618_members_wxuser')->insert(array(
						'it618_uid' => $tmpliarr[0],
						'it618_wxopenid' => $tmpliarr[1],
						'it618_time' => $_G['timestamp']
					), true);
					$ok1=$ok1+1;
				}

			}
		}
	}
	
	cpmsg($it618_members_lang['s52'].$ok1, "action=plugins&identifier=$identifier&cp=admin_import_wx&pmod=admin_members&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_dao3')){
	$ok1=0;
	if (preg_match('/\.\./', $_GET['it618_name_dao'])) {
		cpmsg($it618_members_lang['s115'], "action=plugins&identifier=$identifier&cp=admin_import_wx&pmod=admin_members&operation=$operation&do=$do&page=$page", 'error');
	}
	
	$tmparr=explode("source/plugin/it618_members/kindeditor",$_GET['it618_name_dao']);
	$file_path='source/plugin/it618_members/kindeditor'.$tmparr[1];
	
	if (!file_exists($file_path)) {
		cpmsg($it618_members_lang['s115'], "action=plugins&identifier=$identifier&cp=admin_import_wx&pmod=admin_members&operation=$operation&do=$do&page=$page", 'error');
	}
	
	$lines = dfsockopen($_G['siteurl'].$file_path);
	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	ini_set('memory_limit', '-1');
	$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $lines);
	$line=explode("@||@",$lines);
	$ok1=0;

	foreach($line as $key =>$li)
	{
		if(trim($li)!=''){
			$tmpliarr=explode(',',$li);
				
			if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".intval($tmpliarr[0]))>0){
				if(C::t('#it618_members#it618_members_wxuser')->count_by_openid_uid($tmpliarr[1],$tmpliarr[0])==0){
					$id=C::t('#it618_members#it618_members_wxuser')->insert(array(
						'it618_uid' => $tmpliarr[0],
						'it618_wxopenid' => $tmpliarr[1],
						'it618_time' => $_G['timestamp']
					), true);
					$ok1=$ok1+1;
				}
			}
		}
	}
	
	cpmsg($it618_members_lang['s52'].$ok1, "action=plugins&identifier=$identifier&cp=admin_import_wx&pmod=admin_members&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_import_wx&pmod=admin_members&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s305'],'it618_members_card');
	
echo '<tr><td colspan=14>'.$it618_members_lang['s304'].'</td></tr>
<tr><td colspan=14>
<font color=red>*</font>'.$it618_members_lang['s306'].'<input type="text" name="tablename" class="txt" style="width:190px">
<font color=red>*</font>'.$it618_members_lang['s307'].'<input type="text" name="uidname" class="txt" style="width:190px">
<font color=red>*</font>'.$it618_members_lang['s308'].'<input type="text" name="openidname" class="txt" style="width:190px">
</td></tr>
<tr><td colspan=14>'.$it618_members_lang['s309'].'</td></tr>
<tr><td colspan=14><input type="submit" class="btn" name="it618submit_dao1" value="'.$it618_members_lang['s48'].'"/></td></tr>';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_import_wx&pmod=admin_members&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s368'],'it618_members_card');

echo '
<link rel="stylesheet" href="source/plugin/it618_members/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_members/kindeditor/kindeditor-min.js"></script>
<script>
	KindEditor.ready(function(K) {
				var uploadbutton = K.uploadbutton({
					button : K(\'#btn_upfile\')[0],
					fieldName : \'imgFile\',
					url : \'source/plugin/it618_members/kindeditor/php/upload_json.php?dir=file&filetype=txt\',
					afterUpload : function(data) {
						if (data.error === 0) {
							var url = K.formatUrl(data.url, \'absolute\');
							K(\'#it618_name_dao\').val(url);
						} else {
							alert(data.message);
						}
					},
					afterError : function(str) {
						alert(str);
					}
				});
				uploadbutton.fileBox.change(function(e) {
					uploadbutton.submit();
				});
			});
</script>';
	
echo '<tr><td colspan=14>'.$it618_members_lang['s369'].'<br><textarea name="it618_content" style="width:680px;height:300px;margin-top:6px;"></textarea><br><input type="submit" class="btn" name="it618submit_dao2" value="'.$it618_members_lang['s49'].'"/> '.$it618_members_lang['s370'].'</td></tr>
<tr><td colspan=14>'.$it618_members_lang['s371'].'<br><input id="it618_name_dao" name="it618_name_dao" class="txt" style="width:300px"><input type="submit" class="btn" id="btn_upfile" value="'.$it618_members_lang['s116'].'"/><br><input type="submit" class="btn" name="it618submit_dao3" value="'.$it618_members_lang['s117'].'"/></td></tr>';

if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>