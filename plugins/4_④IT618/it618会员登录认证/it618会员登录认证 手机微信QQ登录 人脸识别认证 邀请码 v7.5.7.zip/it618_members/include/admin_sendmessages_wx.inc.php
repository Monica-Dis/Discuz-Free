<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

global $ncount,$usercount;

if(submitcheck('it618submit')){
	if($it618_members['members_iswxsms']==1){
		$it618_members_messages_tpl_wx=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_messages_tpl_wx')." WHERE id=".intval($_GET['messages_tpl']));
		
		$gp_array = !empty($_GET['gp']) ? $_GET['gp'] : array();
		foreach($gp_array as $key => $value) {
			$gp.=$value.',';
		}
		if($gp!='')$gp=str_replace(",,","",$gp.',');
		
		$id=$it618_members_messages_tpl_wx['id'];
		
		$tmplabel=explode("@",$it618_members_messages_tpl_wx['it618_label']);
		$it618_count=count($tmplabel);
		
		for($i=0;$i<$it618_count;$i++){
			$tmpvalue=$_GET['messages_'.$id.'_'.$i];
			$members_param.=$members_param.$tmplabel[$i].'@arr2@'.$tmpvalue.'@arr1@';
			
			$it618_value.=$tmpvalue.'@@@';
		}
		
		C::t('#it618_members#it618_members_messages_tpl_wx')->update($id,array(
			'it618_value' => $it618_value
		));
		
		$jsinput=sendSMS_WX($gp,$_GET['uids']);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
		$smssign=getsmssign();
		
		$tmpstr=$_GET['url_'.$id].'it618_split'.$it618_members_messages_tpl_wx['it618_tplid'].'it618_split'.$members_param;
		$tmpstr=str_replace('"',"@@@",$tmpstr);
		
		echo $jsinput.'
		<div>
		<form id="sendmessages_wx">
		<input type="hidden" name="paramstr" value="'.$tmpstr.'">
		<input type="hidden" id="uidsstr" name="uidsstr">
		</form>
		<span id="smsimg" style="color:#999"><img src="source/plugin/it618_members/images/loading_r.gif" style="vertical-align:middle"> '.$it618_members_lang['s274'].'<br></span>
		'.$it618_members_lang['s271'].'<span id="smsokcount" style="font-size:14px"></span> <span id="smsbtn" style="display:none"><br><br><input type="button" class="btn" value="'.$it618_members_lang['s275'].'" onclick="history.back()"></span><span id="smserrstr" style="line-height:18px"></span></div>
		<script src="source/plugin/it618_members/js/jquery.js" type=text/javascript></script>
		<script>
		
		
		var n='.$ncount.';allcount=0,okcount=0,errstr="";
		function sendmessages_ajax(){
			IT618_MEMBERS.post("'.$_G['siteurl'].'plugin.php?id=it618_members:ajax&ac=sendmessages_wx&smssign='.$smssign.'", IT618_MEMBERS("#sendmessages_wx").serialize(),function (data, textStatus){
				var tmparr=data.split("it618_split");
				okcount=okcount+parseInt(tmparr[1]);
				allcount=allcount+parseInt(tmparr[2]);
				if(tmparr[3]!="")errstr=errstr+tmparr[3]+" ";
				
				IT618_MEMBERS("#smsokcount").html("<font color=#390><b>"+okcount+"</b></font>/"+allcount);
				if(errstr!="")IT618_MEMBERS("#smserrstr").html("<br><br>'.$it618_members_lang['s276'].'<br>"+errstr);
				
				if(allcount=='.$usercount.'){
					IT618_MEMBERS("#smsimg").hide();
					IT618_MEMBERS("#smsbtn").show();
				}
			}, "html");	
		}

		for(var i=0;i<n;i++){
			document.getElementById("uidsstr").value=document.getElementById("uids"+i).value;
			sendmessages_ajax();
		}
		</script>
		';
		exit;
		
		cpmsg($it618_members_lang['s256'], "action=plugins&identifier=$identifier&cp=admin_sendmessages_wx&pmod=admin_sendmessages_wx&operation=$operation&do=$do&page=$page", 'succeed');
	}else{
		cpmsg($it618_members_lang['s83'], "action=plugins&identifier=$identifier&cp=admin_sendmessages_wx&pmod=admin_sendmessages_wx&operation=$operation&do=$do&page=$page", 'error');
	}
}

function sendSMS_WX($gp,$uids){
	global $_G,$ncount,$usercount;
	
	$ppp=1;
	$uidstr='';
	$usercount=0;
	$usercount1=0;
	$ncount=0;
	$gparr=explode(",",$gp);
	for($i=0;$i<count($gparr);$i++){
		$query = DB::query("SELECT w.it618_uid FROM ".DB::table('it618_members_wxuser')." w left join ".DB::table('common_member')." m on w.it618_uid=m.uid where m.groupid=".intval($gparr[$i]));
		while($common_member = DB::fetch($query)) {
			
			$uid=$common_member['it618_uid'];
			
			$usercount=$usercount+1;
			$usercount1=$usercount1+1;
			$uidstr.=$uid.',';
			if($usercount1==$ppp){
				$usercount1=0;
				$jsinput.='<input type="hidden" id="uids'.$ncount.'" value="'.$uidstr.'">';
				$ncount=$ncount+1;
				$uidstr='';
			}

		}
	}
	
	$uidarr=explode("@",$uids);
	for($i=0;$i<count($uidarr);$i++){
		$uid=$uidarr[$i];
		$count=C::t('#it618_members#it618_members_wxuser')->count_by_uid_auth($uid);
		if($count>0){
			$usercount=$usercount+1;
			$usercount1=$usercount1+1;
			$uidstr.=$uid.',';
			if($usercount1==$ppp){
				$usercount1=0;
				$jsinput.='<input type="hidden" id="uids'.$ncount.'" value="'.$uidstr.'">';
				$ncount=$ncount+1;
				$uidstr='';
			}
		}
	}
	
	if($uidstr!=''){
		$jsinput.='<input type="hidden" id="uids'.$ncount.'" value="'.$uidstr.'">';
		$ncount=$ncount+1;
	}
	
	return $jsinput;
}


$n=1;
$query = DB::query("SELECT * FROM ".DB::table('common_usergroup'));
while($common_usergroup = DB::fetch($query)) {
	
	$n1 = DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." m left join ".DB::table('it618_members_wxuser')." u on m.uid=u.it618_uid where u.it618_wxopenid!='' and m.groupid=".$common_usergroup['groupid']);

	if($n1>0){
		$gpstr.='<input class="checkbox" type="checkbox" id="chk_gp'.$n.'" name="gp[]" value="'.$common_usergroup['groupid'].'"><label for="chk_gp'.$n.'">'.$common_usergroup['grouptitle'].'(<font color=red>'.$n1.'</font>)</label> ';
		$n=$n+1;
	}
}

if($gpstr=='')$gpstr='<font color=red>'.$it618_members_lang['s257'].'</font>';

$tmpjs='';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_members_messages_tpl_wx')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	
	$tmplabel=explode("@",$it618_tmp['it618_label']);
	$tmpvalue=explode("@@@",$it618_tmp['it618_value']);
	
	$it618_count=count($tmplabel);
	
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_title'].' ('.$it618_members_lang['s255'].$it618_count.')</option>';
	
	$tmptext='';
	for($i=0;$i<$it618_count;$i++){
		$tmptext.='<div style="width:135px;float:left">'.$tmplabel[$i].$it618_members_lang['s106'].'</div><input type="text" style="width:400px;float:left;margin-top:6px" id="messages_'.$it618_tmp['id'].'_'.$i.'" name="messages_'.$it618_tmp['id'].'_'.$i.'" value="'.$tmpvalue[$i].'"><br>';
	}
	
	$it618_url=$it618_tmp['it618_url'];
	if($it618_tmp['it618_url']=="")$it618_url=$_G['siteurl'];

	if($tmptext!='')$tmptr.='
	<tr id="trvalue1'.$it618_tmp['id'].'" name="trvalue1"><td>'.$it618_members_lang['s267'].'</td><td width=800><input type="text" id="url_'.$it618_tmp['id'].'" name="url_'.$it618_tmp['id'].'" style="width:535px" value="'.$it618_url.'"> <font color=#999>'.$it618_members_lang['s268'].'</font></td></tr>
	<tr id="trvalue2'.$it618_tmp['id'].'" name="trvalue2"><td>'.$it618_members_lang['s99'].'</td><td width=800 style="line-height:30px;position:relative">'.$tmptext.'<input type="hidden" id="it618_count'.$it618_tmp['id'].'" value="'.$it618_count.'"><div style="position:absolute;top:0px;left:550px;width:350px;color:#999;line-height:20px;padding-top:6px">'.$it618_members_lang['s266'].'<br>'.$it618_tmp['it618_about'].'</div></td></tr>';
	
	if($tmpjs=='')$tmpjs='settrvalue('.$it618_tmp['id'].')';
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_sendmessages_wx&pmod=admin_sendmessages_wx&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s250'],'it618_members_card');
	
echo '
<tr><td width=100>'.$it618_members_lang['s92'].'</td><td width=800>'.$gpstr.'<br><br><input class="checkbox" type="checkbox" id="chk_gpall" onclick="check_all(this, \'chk_gp\')"><label for="chk_gpall">'.$it618_members_lang['s89'].'</label> <font color=#999>'.$it618_members_lang['s258'].'</font></td><td></td></tr>
<tr><td>'.$it618_members_lang['s263'].'</td><td width=800><textarea id="uids" name="uids" style="width:800px;height:150px"></textarea><br><font color=#999>'.$it618_members_lang['s264'].'</font></td><td></td></tr>
<tr><td>'.$it618_members_lang['s259'].'</td><td width=800><select id="messages_tpl" name="messages_tpl" onchange="settrvalue(this.value)">'.$tmp.'</select> <a href="'.$hosturl.'plugins&cp=admin_messages_tpl_wx'.$urls.'">'.$it618_members_lang['s265'].'</a></td><td></td></tr>
'.$tmptr.'
<tr><td colspan=3><input type="submit" class="btn" name="it618submit" onclick="return checkvalue()" value="'.$it618_members_lang['s88'].'"/></td></tr>

<script>
function checkvalue(){
	var flag=0,n='.$n.';
	for(var i=1;i<'.$n.';i++)
	{
		if(document.getElementById("chk_gp"+i).checked)flag=1;
	}
	if(document.getElementById("uids").value!=""){
		flag=1;
	}
	if(flag==0){
		alert("'.$it618_members_lang['s260'].'");
		return false;
	}
	
	var tmpid=document.getElementById("messages_tpl").value;
	if(tmpid==0){
		alert("'.$it618_members_lang['s261'].'");
		return false;
	}
	
	if(document.getElementById("url_"+tmpid).value==""){
		alert("'.$it618_members_lang['s269'].'");
		document.getElementById("url_"+tmpid).focus();
		return false;
	}
	
	var it618_count = document.getElementById("it618_count"+tmpid).value;
	for(var i=0;i<it618_count;i++){
		if(document.getElementById("messages_"+tmpid+"_"+i).value==""){
			$tmpname="keyword"+i;
			if(i==0)$tmpname="first";
			if(i==it618_count-1)$tmpname="remark";
			alert("'.$it618_members_lang['s107'].'"+$tmpname+"'.$it618_members_lang['s108'].'");
			document.getElementById("messages_"+tmpid+"_"+i).focus();
			return false;
		}
		
	}

	return confirm("'.$it618_members_lang['s262'].'");
}

function check_all(obj,id)
{
	for(var i=1;i<'.$n.';i++)
	{
		document.getElementById(id+""+i).checked = obj.checked;
	}
}

function settrvalue(id){
	var trobj1=document.getElementsByName("trvalue1");
	var trobj2=document.getElementsByName("trvalue2");
	for(var i=0;i<trobj1.length;i++){
		trobj1[i].style.display="none";
		trobj2[i].style.display="none";
	}
	
	if(document.getElementById("trvalue1"+id)!=null)
	document.getElementById("trvalue1"+id).style.display="";
	
	if(document.getElementById("trvalue2"+id)!=null)
	document.getElementById("trvalue2"+id).style.display="";
}

'.$tmpjs.'
</script>
';

if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>