<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
}

$it618sql = "1";

if($_GET['uid']>0){
	$it618sql .= " and it618_uid =".intval($_GET['uid']);
}

if($_GET['wxok']==1){
	$it618sql .= " and it618_wxok =1";
}

if($_GET['wxok']==2){
	$it618sql .= " and it618_wxok =0";
}

$it618orderby='it618_time desc,id desc';

$urlsql='&key='.$_GET['key'].'&uid='.$_GET['uid'].'&wxok='.$_GET['wxok'];
if($reabc[6]!='m')return;

if(submitcheck('it618submit_edit')){
	$ok=0;
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_members_editwork'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_members_deleditwork();
		}
	}
	C::t('#it618_members#it618_members_editwork')->insert(array(
		'it618_iswork' => 1
	), true);
	
	loaducenter();
	
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	$ucname=UC_DBTABLEPRE."members";
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_uname=trim($_GET['it618_uname'][$delid]);
		$it618_uid=trim($_GET['it618_uid'][$delid]);
		
		$user = uc_get_user($it618_uname);
		if(!empty($user)) {
			DB::query("delete from ".DB::table('it618_members_editwork'));
			cpmsg($it618_uname.'<br>'.$it618_members_lang['t91'].'<br>'.$it618_members_lang['s781'].$ok, "action=plugins&identifier=$identifier&cp=admin_members_wx&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'error');
		}
		
		DB::query("UPDATE ".DB::table('common_member')." SET username=%s WHERE uid=%d", array($it618_uname, $it618_uid));
		DB::query("UPDATE ".$ucname." SET username=%s WHERE uid=%d", array($it618_uname, $it618_uid));
		
		$ok=$ok+1;
	}

	cpmsg($it618_members_lang['s781'].$ok, "action=plugins&identifier=$identifier&cp=admin_members_wx&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_del')){
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_members_wxuser', "id=$delid");
		$del=$del+1;
	}

	cpmsg($it618_members_lang['s156'].$del, "action=plugins&identifier=$identifier&cp=admin_members_wx&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

$datapath=md5(DISCUZ_ROOT);
if(submitcheck('it618submit_data')){
	$query = DB::query("SELECT * FROM ".DB::table('it618_members_wxuser')." order by it618_uid");
	while($it618_members_wxuser =	DB::fetch($query)){
		$users .= $it618_members_wxuser['it618_uid'].','.$it618_members_wxuser['it618_wxopenid']."\r\n";
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_members/data/wxusers'.$datapath.'.csv';
	
	@$fp = fopen($datapath,"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$users);
		fclose($fp);
	}

	cpmsg($it618_members_lang['s102'], "action=plugins&identifier=$identifier&cp=admin_members_wx&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_members_wx&pmod=admin_members&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_members_lang['s234'],'it618_members_wxuser');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s240'].' <input name="key" style="width:290px" value="'.$_GET['key'].'" class="txt" /> '.$it618_members_lang['s58'].' <input name="uid" style="width:60px;margin-right:3px" value="'.$_GET['uid'].'" class="txt" />'.$it618_members_lang['s248'].' '.$it618_members_lang['s243'].' <select name="wxok"><option value=0>'.$it618_members_lang['s244'].'</option><option value=1>'.$it618_members_lang['s245'].'</option><option value=2>'.$it618_members_lang['s246'].'</option></select>');

	if($_GET['uid']>0){
		if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($_GET['uid'])){
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
	
			$openid=$it618_members_wxuser['it618_wxopenid'];
			
			$appid=trim($wxjk_appid);
			$appsecret=trim($wxjk_appsecret);
			
			$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
			if(!is_array($data)){
				echo $data;exit;
			}
			$subscribe=$data['subscribe'];
			$subscribe_time=$data['subscribe_time'];
			
			C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
				'it618_wxok' => $subscribe,
				'it618_wxoktime' => $subscribe_time,
				'it618_checktime' => $_G['timestamp']
			));
		}
	}
	
	if($reabc[8]!='m')return;
	$count = C::t('#it618_members#it618_members_wxuser')->count_all_by_search($it618sql,$it618orderby,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_members_wx&pmod=admin_members&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=8>'.$it618_members_lang['s11'].$count.' <span style="float:right;color:red">'.$it618_members_lang['s239'].'</span></td></tr>';
	
	showsubtitle(array('UID',$it618_members_lang['s17'], $it618_members_lang['s231'],$it618_members_lang['s232'],$it618_members_lang['s500'],$it618_members_lang['s247'],$it618_members_lang['s602'],$it618_members_lang['s243']));
	
	foreach(C::t('#it618_members#it618_members_wxuser')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['key'],$startlimit,$ppp
	) as $it618_members_wxuser) {
		
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$it618_members_wxuser['it618_uid'])>0){
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_wxuser['it618_uid']);
		}else{
			C::t('#it618_members#it618_members_wxuser')->delete_by_id($it618_members_wxuser['id']);
			continue;
		}
		
		if($it618_members_wxuser['it618_wxok']==1){
			$it618_wxoktime=date('Y-m-d H:i:s', $it618_members_wxuser['it618_wxoktime']);
			$it618_wxok='<font color=green><b>'.$it618_members_lang['s245'].'</b></font>';
		}else{
			$it618_wxoktime='';
			$it618_wxok=$it618_members_lang['s246'];
		}
		
		$it618_isreg='';
		if($it618_members_wxuser['it618_isreg']==1){
			$it618_isreg=$it618_members_lang['t64'];
		}
		
		$u_avatarimg=it618_members_discuz_uc_avatar($it618_members_wxuser['it618_uid'],'middle');
		
		showtablerow('', array('', '', '', '', ''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" id='uid".$it618_members_wxuser['id']."' value=\"".$it618_members_wxuser['id']."\" $disabled><label for='uid".$it618_members_wxuser['id']."'>".$it618_members_wxuser['it618_uid']."</label>",
				'<a href="home.php?mod=space&uid='.$it618_members_wxuser['it618_uid'].'" target="_blank"><img src="'.$u_avatarimg.'" width=23 style="vertical-align:middle"></a> <input type="text" name="it618_uname['.$it618_members_wxuser['id'].']" value="'.$username.'"/>'."<input type=\"hidden\" class=\"txt\" name=\"it618_uid[".$it618_members_wxuser['id']."]\" value=\"".$it618_members_wxuser['it618_uid']."\">",
				$it618_members_wxuser['it618_wxname'],
				$it618_members_wxuser['it618_wxopenid'],
				$it618_members_wxuser['it618_wxunionid'],
				date('Y-m-d H:i:s', $it618_members_wxuser['it618_time']).' '.$it618_isreg,
				$it618_members_wxuser['it618_authcount'],
				$it618_wxok
			));
	}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/data/wxusers'.$datapath.'.csv')){
	$tmp=fileatime(DISCUZ_ROOT.'./source/plugin/it618_members/data/wxusers'.$datapath.'.csv');
	$datastr='<font color=blue>'.$it618_members_lang['s103'].date("Y-m-d H:i:s",$tmp).' <a href="'.$_G['siteurl'].'source/plugin/it618_members/data/wxusers'.$datapath.'.csv" target="_blank"><b>'.$it618_members_lang['s104'].'</b></a></font>';
}

echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_members_lang['s89'].'</label> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_members_lang['s779'].'" onclick="return confirm(\''.$it618_members_lang['s780'].'\')"/> <input type="submit" class="btn" name="it618submit_del" value="'.$it618_members_lang['s175'].'" onclick="return confirm(\''.$it618_members_lang['s179'].'\')"/> <input type="submit" class="btn" name="it618submit_data" style="color:red" value="'.$it618_members_lang['s367'].'" /> '.$datastr.' &nbsp;<input type=hidden value='.$page.' name=page /></div><br>'.$it618_members_lang['s767'].'</td></tr>';

	if(count($reabc)!=13)return;
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>