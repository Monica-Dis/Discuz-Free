<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/tellogin.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/tellogin.php';
}else{
	$tellogin['regmode']='1';
	$tellogin['isuname']='1';
	$tellogin['iswxqquname']='1';
	$tellogin['loginmode']='2';
	$tellogin['loginquestion']='0';
	$tellogin['codelength']='6';
	$tellogin['codetime']='60';
	$tellogin['codeoktime']='60';
	$tellogin['ischeck_reg']='';
	$tellogin['ischeck_login']='';
	$tellogin['ischeck_password']='1';
	$tellogin['ischeck_bd']='1';
	$tellogin['telcount']='3';
	$tellogin['ipcount']='3';
	$tellogin['usercount']='3';
	
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/tellogin.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$tellogin[\'regmode\']=\''.$tellogin['regmode']."';\n";
		$fileData .= '$tellogin[\'isuname\']=\''.$tellogin['isuname']."';\n";
		$fileData .= '$tellogin[\'iswxqquname\']=\''.$tellogin['iswxqquname']."';\n";
		$fileData .= '$tellogin[\'loginmode\']=\''.$tellogin['loginmode']."';\n";
		$fileData .= '$tellogin[\'loginquestion\']=\''.$tellogin['loginquestion']."';\n";
		$fileData .= '$tellogin[\'codelength\']=\''.$tellogin['codelength']."';\n";
		$fileData .= '$tellogin[\'codetime\']=\''.$tellogin['codetime']."';\n";
		$fileData .= '$tellogin[\'codeoktime\']=\''.$tellogin['codeoktime']."';\n";
		$fileData .= '$tellogin[\'ischeck_reg\']=\''.$tellogin['ischeck_reg']."';\n";
		$fileData .= '$tellogin[\'ischeck_login\']=\''.$tellogin['ischeck_login']."';\n";
		$fileData .= '$tellogin[\'ischeck_password\']=\''.$tellogin['ischeck_password']."';\n";
		$fileData .= '$tellogin[\'ischeck_bd\']=\''.$tellogin['ischeck_bd']."';\n";
		$fileData .= '$tellogin[\'telcount\']=\''.$tellogin['telcount']."';\n";
		$fileData .= '$tellogin[\'ipcount\']=\''.$tellogin['ipcount']."';\n";
		$fileData .= '$tellogin[\'usercount\']=\''.$tellogin['usercount']."';\n";
		$fileData .= '$tellogin[\'telfirsts\']=\''.$tellogin['telfirsts']."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/tellogin.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$tellogin[\'regmode\']=\''.trim($_GET['tel_regmode'])."';\n";
		$fileData .= '$tellogin[\'isuname\']=\''.trim($_GET['tel_isuname'])."';\n";
		$fileData .= '$tellogin[\'iswxqquname\']=\''.trim($_GET['tel_iswxqquname'])."';\n";
		$fileData .= '$tellogin[\'loginmode\']=\''.trim($_GET['tel_loginmode'])."';\n";
		$fileData .= '$tellogin[\'loginquestion\']=\''.trim($_GET['tel_loginquestion'])."';\n";
		$fileData .= '$tellogin[\'codelength\']=\''.trim($_GET['tel_codelength'])."';\n";
		$fileData .= '$tellogin[\'codetime\']=\''.trim($_GET['tel_codetime'])."';\n";
		$fileData .= '$tellogin[\'codeoktime\']=\''.trim($_GET['tel_codeoktime'])."';\n";
		$fileData .= '$tellogin[\'ischeck_reg\']=\''.trim($_GET['tel_ischeck_reg'])."';\n";
		$fileData .= '$tellogin[\'ischeck_login\']=\''.trim($_GET['tel_ischeck_login'])."';\n";
		$fileData .= '$tellogin[\'ischeck_password\']=\''.trim($_GET['tel_ischeck_password'])."';\n";
		$fileData .= '$tellogin[\'ischeck_bd\']=\''.trim($_GET['tel_ischeck_bd'])."';\n";
		$fileData .= '$tellogin[\'telcount\']=\''.trim($_GET['tel_telcount'])."';\n";
		$fileData .= '$tellogin[\'ipcount\']=\''.trim($_GET['tel_ipcount'])."';\n";
		$fileData .= '$tellogin[\'usercount\']=\''.trim($_GET['tel_usercount'])."';\n";
		$fileData .= '$tellogin[\'telfirsts\']=\''.trim($_GET['tel_telfirsts'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	cpmsg($it618_members_lang['s571'], "action=plugins&identifier=$identifier&cp=admin_tellogin&cp1=$cp1&pmod=admin_dxjk&operation=$operation&do=$do&page=$page", 'succeed');
}

$regmode='
<option value="1">'.$it618_members_lang['s606'].'</option>
<option value="2">'.$it618_members_lang['s607'].'</option>
<option value="3">'.$it618_members_lang['s608'].'</option>
<option value="4">'.$it618_members_lang['s542'].'</option>
<option value="5">'.$it618_members_lang['s543'].'</option>
';

$loginmode='
<option value="1">'.$it618_members_lang['s614'].'</option>
<option value="2">'.$it618_members_lang['s615'].'</option>
<option value="3">'.$it618_members_lang['s616'].'</option>
';

$regmode=str_replace('<option value="'.$tellogin['regmode'].'"','<option value="'.$tellogin['regmode'].'" selected="selected"',$regmode);
$loginmode=str_replace('<option value="'.$tellogin['loginmode'].'"','<option value="'.$tellogin['loginmode'].'" selected="selected"',$loginmode);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_tellogin&cp1=$cp1&pmod=admin_dxjk&operation=$operation&do=$do");

if($tellogin['isuname']==1)$check_tel_isuname='checked="checked"';else $check_tel_isuname='';
if($tellogin['iswxqquname']==1)$check_tel_iswxqquname='checked="checked"';else $check_tel_iswxqquname='';
if($tellogin['loginquestion']==1)$check_tel_loginquestion='checked="checked"';else $check_tel_loginquestion='';
if($tellogin['ischeck_reg']==1)$check_tel_ischeck_reg='checked="checked"';else $check_tel_ischeck_reg='';
if($tellogin['ischeck_login']==1)$check_tel_ischeck_login='checked="checked"';else $check_tel_ischeck_login='';
if($tellogin['ischeck_password']==1)$check_tel_ischeck_password='checked="checked"';else $check_tel_ischeck_password='';
if($tellogin['ischeck_bd']==1)$check_tel_ischeck_bd='checked="checked"';else $check_tel_ischeck_bd='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_members_lang['s604'].'</th></tr>
<tr class="header"><th width=180>'.$it618_members_lang['s610'].'</th><th>'.$it618_members_lang['s611'].'</th><th>'.$it618_members_lang['s612'].'</th></tr>

<tr class="hover">
<td>'.$it618_members_lang['s605'].'</td><td class="longtxt">
<select name="tel_regmode">
	'.$regmode.'
</select></td>
<td>
'.$it618_members_lang['s609'].'
</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s568'].'</td><td class="longtxt"><input type="checkbox" name="tel_isuname" value=1 '.$check_tel_isuname.'></td>
<td>'.$it618_members_lang['s569'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s624'].'</td><td class="longtxt"><input type="checkbox" name="tel_iswxqquname" value=1 '.$check_tel_iswxqquname.'></td>
<td>'.$it618_members_lang['s625'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s613'].'</td><td class="longtxt">
<select name="tel_loginmode">
	'.$loginmode.'
</select></td>
<td>
'.$it618_members_lang['s617'].'
</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s896'].'</td><td class="longtxt"><input type="checkbox" name="tel_loginquestion" value=1 '.$check_tel_loginquestion.'></td>
<td>'.$it618_members_lang['s897'].'</td>
</tr>

<tr class="hover">
<td><b>'.$it618_members_lang['s572'].'</b></td><td class="longtxt"></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s573'].'</td><td class="longtxt"><input name="tel_codelength" value="'.$tellogin['codelength'].'" style="width:80px" /></td>
<td>'.$it618_members_lang['s574'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s575'].'</td><td class="longtxt"><input name="tel_codetime" value="'.$tellogin['codetime'].'" style="width:80px" /></td>
<td>'.$it618_members_lang['s576'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s587'].'</td><td class="longtxt"><input name="tel_codeoktime" value="'.$tellogin['codeoktime'].'" style="width:80px" /></td>
<td>'.$it618_members_lang['s588'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s577'].'</td><td class="longtxt">
<input type="checkbox" id="tel_ischeck_reg" name="tel_ischeck_reg" value=1 '.$check_tel_ischeck_reg.' style="vertical-align:middle"><label for="tel_ischeck_reg">'.$it618_members_lang['s578'].'</label>
<input type="checkbox" id="tel_ischeck_login" name="tel_ischeck_login" value=1 '.$check_tel_ischeck_login.' style="vertical-align:middle"><label for="tel_ischeck_login">'.$it618_members_lang['s579'].'</label>
<br>
<input type="checkbox" id="tel_ischeck_password" name="tel_ischeck_password" value=1 '.$check_tel_ischeck_password.' style="vertical-align:middle"><label for="tel_ischeck_password">'.$it618_members_lang['s580'].'</label>
<input type="checkbox" id="tel_ischeck_bd" name="tel_ischeck_bd" value=1 '.$check_tel_ischeck_bd.' style="vertical-align:middle"><label for="tel_ischeck_bd">'.$it618_members_lang['s581'].'</label>
</td>
<td>'.$it618_members_lang['s582'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s583'].'</td><td class="longtxt"><input name="tel_telcount" value="'.$tellogin['telcount'].'" style="width:80px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s584'].'</td><td class="longtxt"><input name="tel_ipcount" value="'.$tellogin['ipcount'].'" style="width:80px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s585'].'</td><td class="longtxt"><input name="tel_usercount" value="'.$tellogin['usercount'].'" style="width:80px" /></td>
<td>'.$it618_members_lang['s586'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s775'].'</td><td class="longtxt"><textarea name="tel_telfirsts" style="width:330px;height:80px">'.$tellogin['telfirsts'].'</textarea></td>
<td>'.$it618_members_lang['s776'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_members_lang['s589']);

if(count($reabc)!=14)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>