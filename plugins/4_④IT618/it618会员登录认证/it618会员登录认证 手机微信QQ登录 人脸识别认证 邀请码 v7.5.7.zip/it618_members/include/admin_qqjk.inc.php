<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php';
}

$it618_members_set[0]=C::t('#it618_members#it618_members_set')->fetch_by_setname('qqjk_qqabout0');
$it618_members_set[1]=C::t('#it618_members#it618_members_set')->fetch_by_setname('qqjk_qqabout1');

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$qqjk_isdelbdok=trim($_GET['qqjk_isdelbdok']);
		if(trim($_GET['qqjk_isqqregtel'])==0){
			$qqjk_isdelbdok=0;
		}
		
		$fileData = '$qqjk_isok=\''.trim($_GET['qqjk_isok'])."';\n";
		$fileData .= '$qqjk_mode=\''.trim($_GET['qqjk_mode'])."';\n";
		$fileData .= '$qqjk_appid=\''.trim($_GET['qqjk_appid'])."';\n";
		$fileData .= '$qqjk_appsecret=\''.trim($_GET['qqjk_appsecret'])."';\n";
		$fileData .= '$qqjk_url=\''.trim($_GET['qqjk_url'])."';\n";
		$fileData .= '$qqjk_isqqregtel=\''.trim($_GET['qqjk_isqqregtel'])."';\n";
		$fileData .= '$qqjk_qqreglogintip=\''.trim($_GET['qqjk_qqreglogintip'])."';\n";
		$fileData .= '$qqjk_isdelbdok=\''.$qqjk_isdelbdok."';\n";
		
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		for($i=0;$i<=1;$i++){
			if(C::t('#it618_members#it618_members_set')->count_by_setname('qqjk_qqabout'.$i)==0){
				C::t('#it618_members#it618_members_set')->insert(array(
					'setname' => 'qqjk_qqabout'.$i,
					'setvalue' => $_GET['qqjk_qqabout'.$i]
				), true);
			}else{
				C::t('#it618_members#it618_members_set')->update($it618_members_set[$i]['id'],array(
					'setvalue' => $_GET['qqjk_qqabout'.$i]
				));
			}
		}
	}

	cpmsg($it618_members_lang['s479'], "action=plugins&identifier=$identifier&cp=admin_qqjk&pmod=admin_qqjk&operation=$operation&do=$do", 'succeed');
}

if($qqjk_isok==1)$check_isok='checked="checked"';else $check_isok='';
if($qqjk_isqqregtel==1)$check_isqqregtel='checked="checked"';else $check_isqqregtel='';
if($qqjk_isdelbdok==1)$check_isdelbdok='checked="checked"';else $check_isdelbdok='';

$it618_members_lang['s481']=str_replace("{url}",$_G['siteurl'].'plugin.php?id=it618_members:qqlogin',$it618_members_lang['s481']);

if($qqjk_qqreglogintip=='')$qqjk_qqreglogintip=$it618_members_lang['s312'];

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_qqjk&pmod=admin_qqjk&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_members_lang['s380'].'</th></tr>
<tr class="header"><th width=158>'.$it618_members_lang['s398'].'</th><th width=360>'.$it618_members_lang['s399'].'</th><th>'.$it618_members_lang['s400'].'</th></tr>

<tr class="hover"><td>'.$it618_members_lang['s491'].'</td><td class="tdvalue"><input type="checkbox" name="qqjk_isok" value=1 '.$check_isok.'></td>
<td class="tdabout">'.$it618_members_lang['s492'].'</td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s475'].'</td><td class="tdvalue"><input class="tdtxt" name="qqjk_appid" value="'.$qqjk_appid.'" /></td>
<td class="tdabout"></td></tr>

<tr class="hover"><td>'.$it618_members_lang['s476'].'</td><td class="tdvalue"><input class="tdtxt" name="qqjk_appsecret" value="'.$qqjk_appsecret.'" /></td>
<td class="tdabout"></td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s480'].'</td><td class="tdvalue" colspan=2><input class="tdtxt" name="qqjk_url" value="'.$qqjk_url.'" />
<div style="margin-top:6px;line-height:20px;margin-bottom:10px">'.$it618_members_lang['s481'].'</div>
</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s477'].'</td><td class="tdvalue"><input type="checkbox" name="qqjk_isqqregtel" value=1 '.$check_isqqregtel.'></td>
<td class="tdabout">'.$it618_members_lang['s478'].'</td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s433'].'</td><td class="tdvalue"><input class="tdtxt" name="qqjk_qqreglogintip" value="'.$qqjk_qqreglogintip.'" /></td>
<td class="tdabout">'.$it618_members_lang['s434'].'</td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s427'].'</td><td class="tdvalue"><input type="checkbox" name="qqjk_isdelbdok" value=1 '.$check_isdelbdok.'></td>
<td class="tdabout">'.$it618_members_lang['s428'].'</td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s545'].'</td><td class="tdvalue" colspan=2><textarea name="qqjk_qqabout1" style="width:800px;height:400px;visibility:hidden;">'.$it618_members_set[1]['setvalue'].'</textarea><div style="margin-top:6px;line-height:18px">'.$it618_members_lang['s547'].'</div></td>
</tr>

<tr class="hover"><td>'.$it618_members_lang['s429'].'</td><td class="tdvalue" colspan=2><textarea name="qqjk_qqabout0" style="width:800px;height:400px;visibility:hidden;">'.$it618_members_set[0]['setvalue'].'</textarea><div style="margin-top:6px;line-height:18px">'.$it618_members_lang['s430'].'</div></td>
</tr>

</table>
<style>
.tdabout{color:#999}
.tdvalue{width:530px}
.tdvalue .tdtxt{width:500px}
.tdvalue .tdtextarea{width:500px;height:80px}
</style>

<link rel="stylesheet" href="source/plugin/it618_members/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_members/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_members/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_members/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_members/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor0 = K.create(\'textarea[name="qqjk_qqabout0"]\', {
			cssPath : \'source/plugin/it618_members/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_members/kindeditor/php/upload_json.php?imgwidth=900'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_members/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
		
		var editor1 = K.create(\'textarea[name="qqjk_qqabout1"]\', {
			cssPath : \'source/plugin/it618_members/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_members/kindeditor/php/upload_json.php?imgwidth=900'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_members/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>
';

showsubmit('it618submit', $it618_members_lang['s402']);

if(count($reabc)!=11)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>