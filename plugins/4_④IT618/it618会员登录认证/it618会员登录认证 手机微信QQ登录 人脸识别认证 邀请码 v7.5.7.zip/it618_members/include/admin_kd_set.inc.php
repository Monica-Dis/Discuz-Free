<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kd.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/kd.php';
}

if(submitcheck('it618submit')){

	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/kd.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		$fileData .= '$it618_isok=\''.trim($_GET['it618_isok'])."';\n";
		
		$fileData .= '$it618_jktype=\''.trim($_GET['it618_jktype'])."';\n";
		
		$fileData .= '$it618_istest=\''.trim($_GET['it618_istest'])."';\n";
		
		$fileData .= '$it618_key=\''.trim($_GET['it618_key'])."';\n";
		
		$fileData .= '$it618_customer=\''.trim($_GET['it618_customer'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_members_lang['s352'], "action=plugins&identifier=$identifier&cp=admin_kd_set&pmod=admin_kd&operation=$operation&do=$do&page=$page", 'succeed');

}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_kd_set&pmod=admin_kd&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s649'],'it618_members_set');

if($it618_jktype=='')$it618_jktype='kd100ad';
if($it618_jktype=='kd100ad'){$it618_jktype1=' selected=selected';$it618_typestyle='display:none';}
if($it618_jktype=='kd100'){$it618_jktype2=' selected=selected';$it618_typestyle='display:';}

if($it618_isok==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
if($it618_istest==1)$it618_istest_checked='checked="checked"';else $it618_istest_checked="";

echo '
<tr><td width="130">'.$it618_members_lang['s347'].'</td><td><input type="checkbox" id="it618_isok" name="it618_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.$it618_members_lang['s348'].'</label></td></tr>
<tr><td>'.$it618_members_lang['s349'].'</td><td>
<select name="it618_jktype" onchange="gettype(this)"><option value="kd100ad" '.$it618_jktype1.'>'.$it618_members_lang['s350'].'</option><option value="kd100" '.$it618_jktype2.'>'.$it618_members_lang['s351'].'</option></select><br><div style="line-height:23px;margin-top:6px">'.$it618_members_lang['s353'].'</div>
</td></tr>
<tr name="tr_kd100" style="'.$it618_typestyle.'"><td>'.$it618_members_lang['s559'].'</td><td><input type="checkbox" id="it618_istest" name="it618_istest" value="1" style="vertical-align:middle" '.$it618_istest_checked.'> <label for="it618_istest">'.$it618_members_lang['s560'].'</label></td></tr>
<tr name="tr_kd100" style="'.$it618_typestyle.'"><td>'.$it618_members_lang['s992'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_key" value="'.$it618_key.'"></td></tr>
<tr name="tr_kd100" style="'.$it618_typestyle.'"><td>'.$it618_members_lang['s993'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_customer" value="'.$it618_customer.'"></td></tr>
</td></tr>
<script>
function gettype(obj){
	var trobj=document.getElementsByName("tr_kd100");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}

	var jktype=obj.value;
	
	var trobj=document.getElementsByName("tr_"+jktype);
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="";
	}
}
</script>
';

showsubmit('it618submit', $it618_members_lang['s145']);

if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>