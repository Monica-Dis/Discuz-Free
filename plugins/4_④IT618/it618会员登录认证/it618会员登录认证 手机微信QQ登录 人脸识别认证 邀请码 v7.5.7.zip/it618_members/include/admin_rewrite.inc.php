<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$members_reg=\''.'reg'."';\n";
		$fileData .= '$members_login=\''.'login'."';\n";
		$fileData .= '$members_uhome=\''.'uhome'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$members_reg1=\''.$urltype."';\n";
		$fileData .= '$members_login1=\''.$urltype."';\n";
		$fileData .= '$members_uhome1=\''.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$members_reg=\''.str_replace("-","",it618_str($_GET['members_reg']))."';\n";
		$fileData .= '$members_login=\''.str_replace("-","",it618_str($_GET['members_login']))."';\n";
		$fileData .= '$members_uhome=\''.str_replace("-","",it618_str($_GET['members_uhome']))."';\n";
		
		$urltype=str_replace("-","",it618_str($_GET['urltype']));
		$urltype=str_replace("?","",it618_str($_GET['urltype']));
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$members_reg1=\''.$urltype."';\n";
		$fileData .= '$members_login1=\''.$urltype."';\n";
		$fileData .= '$members_uhome1=\''.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_members_lang['s676'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_members_lang['s662'].'</font></td></tr>
<tr><td colspan="3">'.$it618_members_lang['s663'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_members_lang['s664'].'</th><th>'.$it618_members_lang['s665'].'</th><th>'.$it618_members_lang['s666'].'</th></tr>
<tr class="hover">
<td>'.$it618_members_lang['s667'].'</td><td></td><td class="longtxt"><input name="members_reg" value="'.$members_reg.'"/>'.$members_reg.$members_reg1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_members_lang['s668'].'</td><td></td><td class="longtxt"><input name="members_login" value="'.$members_login.'"/>'.$members_login.$members_login1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_members_lang['s669'].'</td><td></td><td class="longtxt"><input name="members_uhome" value="'.$members_uhome.'"/>'.$members_uhome.$members_uhome1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_members_lang['s675']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_members_lang['s670'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$members_reg.$urltype.'$ $1/plugin.php?id=it618_members:reg&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$members_login.$urltype.'$ $1/plugin.php?id=it618_members:login&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$members_uhome.$urltype.'$ $1/plugin.php?id=it618_members:home&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_members_lang['s671'].'</h1>
<pre class="colorbox">
'.$it618_members_lang['s672'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$members_reg.$urltype.'$ plugin.php?id=it618_members:reg&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$members_login.$urltype.'$ plugin.php?id=it618_members:login&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$members_uhome.$urltype.'$ plugin.php?id=it618_members:home&%1</font>

</pre>

<h1>'.$it618_members_lang['s673'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$members_reg.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_members:reg&$3
RewriteRule ^(.*)/'.$members_login.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_members:login&$3
RewriteRule ^(.*)/'.$members_uhome.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_members:home&$3</font>

</pre>

<h1>'.$it618_members_lang['s674'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="members_reg"&gt;
			&lt;match url="^(.*/)*'.$members_reg.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_members:reg&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="members_login"&gt;
			&lt;match url="^(.*/)*'.$members_login.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_members:login&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
			&lt;rule name="members_uhome"&gt;
			&lt;match url="^(.*/)*'.$members_uhome.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_members:home&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$members_reg.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_members:reg&$2
endif
match URL into $ with ^(.*)/'.$members_login.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_members:login&$2
endif
match URL into $ with ^(.*)/'.$members_uhome.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_members:home&$2
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$members_reg.$urltype.'$ $1/plugin.php?id=it618_members:reg&$2 last;
rewrite ^([^\.]*)/'.$members_login.$urltype.'$ $1/plugin.php?id=it618_members:login&$2 last;
rewrite ^([^\.]*)/'.$members_uhome.$urltype.'$ $1/plugin.php?id=it618_members:home&$2 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>