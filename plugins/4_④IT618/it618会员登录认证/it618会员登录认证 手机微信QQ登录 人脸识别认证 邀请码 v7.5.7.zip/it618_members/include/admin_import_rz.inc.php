<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit_dao')){
	$ok1=0;
	$query = DB::query("SELECT p.* FROM ".DB::table('common_member_profile')." p join ".DB::table('common_member_verify')." v on p.uid=v.uid WHERE v.verify".intval($_GET['rztype'])."=1");
	while($common_member_profile =	DB::fetch($query)){
		if(DB::result_first("select count(1) from ".DB::table('it618_members_rzuser')." where it618_uid=".$common_member_profile['uid'])==0){
			
			$it618_state=1;
			if($common_member_profile[$_GET['it618_cardid']]!=''){
				if(C::t('#it618_members#it618_members_rzuser')->count_by_name_idcard($common_member_profile['uid'],$common_member_profile['realname'],$common_member_profile[$_GET['it618_cardid']])>0){
					$strtmp.= $it618_members_lang['s827'].$common_member_profile['realname'].' '.$common_member_profile[$_GET['it618_cardid']].'<br>';
					$it618_state=2;
				}
			}
			
			$it618_cardimg1='';$it618_cardimg2='';$it618_cardimg3='';
			if($common_member_profile[$_GET['it618_cardimg1']]!='')$it618_cardimg1='data/attachment/profile/'.$common_member_profile[$_GET['it618_cardimg1']];
			if($common_member_profile[$_GET['it618_cardimg2']]!='')$it618_cardimg2='data/attachment/profile/'.$common_member_profile[$_GET['it618_cardimg2']];
			if($common_member_profile[$_GET['it618_cardimg3']]!='')$it618_cardimg3='data/attachment/profile/'.$common_member_profile[$_GET['it618_cardimg3']];
			
			$id = C::t('#it618_members#it618_members_rzuser')->insert(array(
				'it618_uid' => $common_member_profile['uid'],
				'it618_name' => $common_member_profile['realname'],
				'it618_sex' => $common_member_profile['gender'],
				'it618_cardid' => $common_member_profile[$_GET['it618_cardid']],
				'it618_cardimg1' => $it618_cardimg1,
				'it618_cardimg2' => $it618_cardimg2,
				'it618_cardimg3' => $it618_cardimg3,
				'it618_qq' => $common_member_profile['qq'],
				'it618_tel' => $common_member_profile['mobile'],
				'it618_about' => $common_member_profile[$_GET['it618_about']],
				'it618_time' => $_G['timestamp'],
				'it618_checktime' => $_G['timestamp'],
				'it618_state' => $it618_state
			), true);
			$ok1=$ok1+1;
		}
	}
	
	if($strtmp!='')$strtmp='<br>'.$it618_members_lang['s834'].'<br>'.$strtmp;
	
	cpmsg($it618_members_lang['s55'].$ok1.$strtmp, "action=plugins&identifier=$identifier&cp=admin_import_rz&pmod=admin_members&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_import_rz&pmod=admin_members&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s791'],'it618_members_card');

if($it618_members['members_certdiytitle']!=''){
	$diystr='<tr><td>'.$it618_members['members_certdiytitle'].$it618_members_lang['s803'].'</td><td><input type="text" name="it618_about" value=""> '.$it618_members_lang['s802'].'</td></tr>';
}

for($i=1;$i<=5;$i++){
	$rztypestr.='<option value="'.$i.'">'.$it618_members_lang['s805'].$i.$it618_members_lang['s807'].'</option>';
}
$rztypestr.='<option value="'.$i.'" selected="selected">'.$it618_members_lang['s805'].$i.$it618_members_lang['s807'].'</option>';
	
echo '
<tr><td colspan=14>'.$it618_members_lang['s792'].'</td></tr>
<tr><td>'.$it618_members_lang['s804'].'</td><td><select name="rztype">'.$rztypestr.'</select> '.$it618_members_lang['s806'].'</td></tr>
'.$diystr.'
<tr><td>'.$it618_members_lang['s793'].'</td><td><input type="text" name="it618_cardid" value=""> '.$it618_members_lang['s797'].'</td></tr>
<tr><td>'.$it618_members_lang['s794'].'</td><td><input type="text" name="it618_cardimg1"> '.$it618_members_lang['s798'].'</td></tr>
<tr><td>'.$it618_members_lang['s795'].'</td><td><input type="text" name="it618_cardimg2"> '.$it618_members_lang['s798'].'</td></tr>
<tr><td>'.$it618_members_lang['s796'].'</td><td><input type="text" name="it618_cardimg3"> '.$it618_members_lang['s798'].'</td></tr>
<tr><td colspan=14>'.$it618_members_lang['s799'].'</td></tr>
<tr><td colspan=14><input type="submit" class="btn" name="it618submit_dao" value="'.$it618_members_lang['s791'].'"/></td></tr>';


if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>