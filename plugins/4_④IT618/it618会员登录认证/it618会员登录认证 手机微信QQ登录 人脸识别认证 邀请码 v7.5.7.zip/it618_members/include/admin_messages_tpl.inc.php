<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_members#it618_members_messages_tpl')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_content'])) {
		foreach($_GET['it618_content'] as $id => $val) {

			C::t('#it618_members#it618_members_messages_tpl')->update($id,array(
				'it618_content' => $_GET['it618_content'][$id],
				'it618_jktype' => $_GET['it618_jktype'][$id],
				'it618_sign' => $_GET['it618_sign'][$id],
				'it618_tplid' => $_GET['it618_tplid'][$id],
				'it618_order' => $_GET['it618_order'][$id]
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_content_array = !empty($_GET['newit618_content']) ? $_GET['newit618_content'] : array();
	
	foreach($newit618_content_array as $key => $value) {

		C::t('#it618_members#it618_members_messages_tpl')->insert(array(
			'it618_content' => $newit618_content_array[$key],
		), true);
		$ok2=$ok2+1;
	}

	cpmsg($it618_members_lang['s65'].$ok1.' '.$it618_members_lang['s66'].$ok2.' '.$it618_members_lang['s67'].$del, "action=plugins&identifier=$identifier&cp=admin_messages_tpl&pmod=admin_sendmessages&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_messages_tpl&pmod=admin_sendmessages&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s77'],'it618_members_messages_tpl');

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_members_messages_tpl'));
	
	echo '<tr><td colspan="6" style="line-height:18px"><font color=green>'.$it618_members_lang['s98'].'</font> <font color=red>'.$it618_members_lang['s113'].'</font></td></tr>';
	echo '<tr><td colspan=6>'.$it618_members_lang['s84'].$count.'<span style="float:right;color:red"></span></td></tr>';
	
	showsubtitle(array($it618_members_lang['s152'], $it618_members_lang['s80'],$it618_members_lang['s151'],$it618_members_lang['s85'],$it618_members_lang['s81'],$it618_members_lang['s82']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_members_messages_tpl')." ORDER BY id ASC LIMIT $startlimit, $ppp");
	while($it618_members_messages_tpl = DB::fetch($query)) {
		
		$it618_jktype1='';$it618_jktype2='';$it618_tplidstyle='display:none';
		if($it618_members_messages_tpl['it618_jktype']=='smsbao')$it618_jktype1='selected=selected';
		if($it618_members_messages_tpl['it618_jktype']=='alidayu'){$it618_jktype2='selected=selected';$it618_tplidstyle='';}
		if($it618_members_messages_tpl['it618_jktype']=='alisms'){$it618_jktype3='selected=selected';$it618_tplidstyle='';}

		showtablerow('', array('class="td25"', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_members_messages_tpl['id']."\">".$it618_members_messages_tpl['id'],
			'<textarea style="width:580px;height:50px" name="it618_content['.$it618_members_messages_tpl['id'].']">'.$it618_members_messages_tpl['it618_content'].'</textarea>',
			'<select name="it618_jktype['.$it618_members_messages_tpl['id'].']" onchange="gettype(this,'.$it618_members_messages_tpl['id'].')"><option value="smsbao" '.$it618_jktype1.'>'.$it618_members_lang['s136'].'</option><option value="alidayu" '.$it618_jktype2.'>'.$it618_members_lang['s137'].'</option><option value="alisms" '.$it618_jktype3.'>'.$it618_members_lang['s224'].'</option></select>',
			$it618_members_lang['s86'].'<input type="text" style="width:110px" name="it618_sign['.$it618_members_messages_tpl['id'].']" value="'.$it618_members_messages_tpl['it618_sign'].'">'.$it618_members_lang['s87'],
			'<input type="text" style="width:110px;'.$it618_tplidstyle.'" id="it618_tplid'.$it618_members_messages_tpl['id'].'" name="it618_tplid['.$it618_members_messages_tpl['id'].']" value="'.$it618_members_messages_tpl['it618_tplid'].'">',
			'<input type="text" style="width:30px" name="it618_order['.$it618_members_messages_tpl['id'].']" value="'.$it618_members_messages_tpl['it618_order'].'">'
		));
	}

	echo <<<EOT
	<script type="text/JavaScript">
	function gettype(obj,id){
		if(obj.value=="smsbao"){
			document.getElementById("it618_tplid"+id).style.display="none";
		}else{
			document.getElementById("it618_tplid"+id).style.display="";
		}
	}
	var rowtypedata;
	function rundata(){
	
		return [
				[[1,''], [1, ' <textarea style="width:580px;height:50px" name="newit618_content[]"></textarea>'], [1,''], [1,''], [1,''], [1,'']]
				];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="6"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism·taobao·com*/
?>