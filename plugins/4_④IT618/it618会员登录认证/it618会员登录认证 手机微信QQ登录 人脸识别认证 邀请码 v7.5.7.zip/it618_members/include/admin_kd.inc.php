<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql='';
$sqlurl='&kdcomid='.$_GET['kdcomid'].'&kdid='.$_GET['kdid'];

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_kd&pmod=admin_kd&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_members_lang['s650'],'it618_members_kdsale');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s553'].' <input name="kdcomid" value="'.$_GET['kdcomid'].'" class="txt" style="width:180px" />'.$it618_members_lang['s554'].' <input name="kdid" value="'.$_GET['kdid'].'" class="txt" style="width:180px" />');
	
	$count = C::t('#it618_members#it618_members_kdsale')->count_all_by_search($it618sql,$it618orderby,$_GET['kdcomid'],$_GET['kdid']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_kd&pmod=admin_kd&operation=$operation&do=$do".$sqlurl);
	
	echo '<tr><td colspan=14>'.$it618_members_lang['s651'].'<font color=red>'.$count.'</font><span style="float:right;color:red">'.$it618_members_lang['s558'].'</span></td></tr>';
	showsubtitle(array($it618_members_lang['s555'],$it618_members_lang['s983'],$it618_members_lang['s984'],$it618_members_lang['s985'],$it618_members_lang['s986'],$it618_members_lang['s9873'],$it618_members_lang['s988'],$it618_members_lang['s989'],$it618_members_lang['s990'],$it618_members_lang['s991']));
	
	foreach(C::t('#it618_members#it618_members_kdsale')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['kdcomid'],$_GET['kdid'],$startlimit,$ppp
	) as $it618_members_kdsale) {
			
		showtablerow('', array('', '', ''), array(
			$it618_members_kdsale['id'],
			$it618_members_kdsale['it618_kdcomid'],
			$it618_members_kdsale['it618_kdid'],
			$it618_members_kdsale['it618_saletype'],
			$it618_members_kdsale['it618_saleid'],
			$it618_members_kdsale['it618_message'],
			$it618_members_kdsale['it618_state'],
			$it618_members_kdsale['it618_count'],
			date('Y-m-d H:i:s', $it618_members_kdsale['it618_time'])
		));
	}


	echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>