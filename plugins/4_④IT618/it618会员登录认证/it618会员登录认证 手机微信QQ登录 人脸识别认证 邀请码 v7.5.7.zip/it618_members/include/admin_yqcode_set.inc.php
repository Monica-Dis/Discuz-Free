<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/yqcodeset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/yqcodeset.php';
}else{
	$yqcodeset['isok']='1';
	$yqcodeset['ispay']='1';
	$yqcodeset['iswxqq']='';
	$yqcodeset['imgsrc']='';
	$yqcodeset['price']='0.01';
	$yqcodeset['istel']='';
	$yqcodeset['telbuycount']='1';	
	
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/yqcodeset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$yqcodeset[\'isok\']=\''.$yqcodeset['isok']."';\n";
		$fileData .= '$yqcodeset[\'ispay\']=\''.$yqcodeset['ispay']."';\n";
		$fileData .= '$yqcodeset[\'iswxqq\']=\''.$yqcodeset['iswxqq']."';\n";
		$fileData .= '$yqcodeset[\'imgsrc\']=\''.$yqcodeset['imgsrc']."';\n";
		$fileData .= '$yqcodeset[\'about\']=\''.$yqcodeset['about']."';\n";
		$fileData .= '$yqcodeset[\'price\']=\''.$yqcodeset['price']."';\n";
		$fileData .= '$yqcodeset[\'istel\']=\''.$yqcodeset['istel']."';\n";
		$fileData .= '$yqcodeset[\'telbuycount\']=\''.$yqcodeset['telbuycount']."';\n";
		$fileData .= '$yqcodeset[\'wlcode\']=\''.$yqcodeset['wlcode']."';\n";
		$fileData .= '$yqcodeset[\'wlcodeisabout\']=\''.$yqcodeset['wlcodeisabout']."';\n";
		$fileData .= '$yqcodeset[\'wlcodeabout\']=\''.$yqcodeset['wlcodeabout']."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/config/yqcodeset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$yqcodeset[\'isok\']=\''.trim($_GET['yq_isok'])."';\n";
		$fileData .= '$yqcodeset[\'ispay\']=\''.trim($_GET['yq_ispay'])."';\n";
		$fileData .= '$yqcodeset[\'iswxqq\']=\''.trim($_GET['yq_iswxqq'])."';\n";
		$fileData .= '$yqcodeset[\'imgsrc\']=\''.trim($_GET['yq_imgsrc'])."';\n";
		$fileData .= '$yqcodeset[\'about\']=\''.trim($_GET['yq_about'])."';\n";
		$fileData .= '$yqcodeset[\'price\']=\''.trim($_GET['yq_price'])."';\n";
		$fileData .= '$yqcodeset[\'istel\']=\''.trim($_GET['yq_istel'])."';\n";
		$fileData .= '$yqcodeset[\'telbuycount\']=\''.trim($_GET['yq_telbuycount'])."';\n";
		$fileData .= '$yqcodeset[\'wlcode\']=\''.trim($_GET['yq_wlcode'])."';\n";
		$fileData .= '$yqcodeset[\'wlcodeisabout\']=\''.trim($_GET['yq_wlcodeisabout'])."';\n";
		$fileData .= '$yqcodeset[\'wlcodeabout\']=\''.trim($_GET['yq_wlcodeabout'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_members_lang['s571'], "action=plugins&identifier=$identifier&cp=admin_yqcode_set&cp1=$cp1&pmod=admin_yqcode&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_yqcode_set&cp1=$cp1&pmod=admin_yqcode&operation=$operation&do=$do");

if($yqcodeset['isok']==1)$check_yq_isok='checked="checked"';else $check_yq_isok='';
if($yqcodeset['ispay']==1)$check_yq_ispay='checked="checked"';else $check_yq_ispay='';
if($yqcodeset['iswxqq']==1)$check_yq_iswxqq='checked="checked"';else $check_yq_iswxqq='';
if($yqcodeset['istel']==1)$check_yq_istel='checked="checked"';else $check_yq_istel='';
if($yqcodeset['wlcodeisabout']==1)$check_yq_wlcodeisabout='checked="checked"';else $check_yq_wlcodeisabout='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_members_lang['s570'].'</th></tr>
<tr class="header"><th width=190>'.$it618_members_lang['s610'].'</th><th>'.$it618_members_lang['s611'].'</th><th>'.$it618_members_lang['s612'].'</th></tr>

<tr class="hover">
<td>'.$it618_members_lang['s540'].'</td><td class="longtxt"><input type="checkbox" name="yq_isok" value=1 '.$check_yq_isok.'></td>
<td>'.$it618_members_lang['s541'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s590'].'</td><td class="longtxt"><input type="checkbox" name="yq_ispay" value=1 '.$check_yq_ispay.'></td>
<td>'.$it618_members_lang['s591'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s497'].'</td><td class="longtxt"><input type="checkbox" name="yq_iswxqq" value=1 '.$check_yq_iswxqq.'></td>
<td>'.$it618_members_lang['s498'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s592'].'</td><td class="longtxt"><input name="yq_imgsrc" value="'.$yqcodeset['imgsrc'].'" style="width:300px" /></td>
<td>'.$it618_members_lang['s593'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s594'].'</td><td class="longtxt"><textarea name="yq_about" style="width:300px;height:80px">'.$yqcodeset['about'].'</textarea></td>
<td>'.$it618_members_lang['s595'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s596'].'</td><td class="longtxt"><input name="yq_price" value="'.$yqcodeset['price'].'" style="width:80px" /></td>
<td>'.$it618_members_lang['s597'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s622'].'</td><td class="longtxt"><input type="checkbox" name="yq_istel" value=1 '.$check_yq_istel.'></td>
<td>'.$it618_members_lang['s623'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s598'].'</td><td class="longtxt"><input name="yq_telbuycount" value="'.$yqcodeset['telbuycount'].'" style="width:80px" /></td>
<td>'.$it618_members_lang['s599'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s600'].'</td><td class="longtxt"><input name="yq_wlcode" value="'.$yqcodeset['wlcode'].'" style="width:80px" /></td>
<td>'.$it618_members_lang['s601'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s740'].'</td><td class="longtxt"><input type="checkbox" name="yq_wlcodeisabout" value=1 '.$check_yq_wlcodeisabout.'></td>
<td>'.$it618_members_lang['s741'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_members_lang['s742'].'</td><td class="longtxt"><textarea name="yq_wlcodeabout" style="width:300px;height:80px">'.$yqcodeset['wlcodeabout'].'</textarea></td>
<td>'.$it618_members_lang['s743'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_members_lang['s589']);

if(count($reabc)!=14)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

?>