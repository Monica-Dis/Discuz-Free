<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$del=0;
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_members_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			DB::query("delete from ".DB::table('it618_members_salework'));
		}
	}
	C::t('#it618_members#it618_members_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_members_yqcode', "id=$delid");
		$del=$del+1;
	}
	
	DB::query("delete from ".DB::table('it618_members_salework'));

	cpmsg($it618_members_lang['s156'].$del, "action=plugins&identifier=$identifier&cp=admin_yqcode&pmod=admin_yqcode&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok1=0;
	
	if(is_array($_GET['it618_bz'])) {
		foreach($_GET['it618_bz'] as $id => $val) {

			C::t('#it618_members#it618_members_yqcode')->update($id,array(
				'it618_bz' => str_replace(",","",trim($_GET['it618_bz'][$id]))
			));
			$ok1=$ok1+1;
		}
	}

	cpmsg($it618_members_lang['s361'].$ok1, "action=plugins&identifier=$identifier&cp=admin_yqcode&pmod=admin_yqcode&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_clear')){
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_members_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			DB::query("delete from ".DB::table('it618_members_salework'));
		}
	}
	C::t('#it618_members#it618_members_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	
	DB::query("delete from ".DB::table('it618_members_yqcode')." where it618_state=0");
	DB::query("delete from ".DB::table('it618_members_salework'));
	
	cpmsg($it618_members_lang['s157'], "action=plugins&identifier=$identifier&cp=admin_yqcode&pmod=admin_yqcode&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submitadd')) {
	$it618_count=intval($_GET['it618_count']);
	$it618_length=intval($_GET['it618_length']);
	
	if($it618_count==0||$it618_length==0){
		cpmsg($it618_members_lang['s158'], "action=plugins&identifier=$identifier&cp=admin_yqcode&pmod=admin_yqcode&operation=$operation&do=$do&page=$page", 'error');
	}

	$ok=0;
	for($i=0;$i<$it618_count;$i++){
		$id=C::t('#it618_members#it618_members_yqcode')->insert(array(
			'it618_type' => $_GET['it618_type'],
			'it618_code' => '',
			'it618_bz' => $_GET['it618_bzadd']
		), true);
		setcode($id,$it618_length);
		$ok=$ok+1;
	}
	cpmsg($it618_members_lang['s159'].$ok,"action=plugins&identifier=$identifier&cp=admin_yqcode&pmod=admin_yqcode&operation=$operation&do=$do&page=$page", 'succeed');
}

$datapath=md5(DISCUZ_ROOT);
if(submitcheck('it618submit_dao')){
	foreach(C::t('#it618_members#it618_members_yqcode')->fetch_all_by_search(
		'it618_type=2','id desc',$_GET['it618_findbz'],0,10000000000
	) as $it618_members_yqcode) {
		$users .= $it618_members_yqcode['it618_code'].",".$it618_members_yqcode['it618_bz']."\r\n";
	}
	
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_members/data/yqcode'.$datapath.'.csv';
	
	@$fp = fopen($datapath,"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$users);
		fclose($fp);
	}

	cpmsg($it618_members_lang['s171'], "action=plugins&identifier=$identifier&cp=admin_yqcode&pmod=admin_yqcode&operation=$operation&do=$do&page=$page", 'succeed');
}

function setcode($id,$length){
	$flag=0;
	$n=0;
	
	while($flag==0){
		$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';  
		$tmpstr ='';
		for($i=0;$i<$length;$i++){
			$tmpstr.= substr($chars,mt_rand(0,strlen($chars)-1),1); 
		}
		
		if(C::t('#it618_members#it618_members_yqcode')->count_by_code($tmpstr)==0&&C::t('#it618_members#it618_members_yqcode_sale')->count_by_code($tmpstr)==0){
			C::t('#it618_members#it618_members_yqcode')->update_it618_code($id,$tmpstr);
			$flag=1;
		}
		
		$n=$n+1;
		if($n==10)$length=$length+1;
	}
	
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_yqcode&pmod=admin_yqcode&operation=$operation&do=$do&cp1=$cp1");
showtableheaders(it618_members_getlang('s164'),'it618_members_yqcodeadd');
echo '<tr></tr><tr><td colspan="15"><div class="fixsel">'.$it618_members_lang['s354'].'<select name="it618_type" onchange="settype(this)"><option value="1">'.$it618_members_lang['s358'].'</option><option value="2">'.$it618_members_lang['s359'].'</option></select> '.$it618_members_lang['s160'].'<input id="it618_count" name="it618_count" value="100" class="txt" style="width:50px" /> '.$it618_members_lang['s161'].'<input id="it618_count" name="it618_length" value="6" class="txt" style="width:50px" /><span id="bzspan" style="display:none"> '.$it618_members_lang['s355'].'<input id="it618_count" name="it618_bzadd" class="txt" style="width:300px" /></span><input type="submit" class="btn" name="it618submitadd" value="'.$it618_members_lang['s162'].'" /><br><font color=#999>'.$it618_members_lang['s163'].'</font></div></td></tr>';
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/

$count = C::t('#it618_members#it618_members_yqcode')->count_all_by_search($it618sql,$it618orderby,$_GET['it618_findbz']);
$salecount = C::t('#it618_members#it618_members_yqcode')->count_all_by_search('it618_state=1',$it618orderby,$_GET['it618_findbz']);
$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_yqcode&pmod=admin_yqcode&operation=$operation&do=$do".$urlsql);

showtableheaders(it618_members_getlang('s154'),'it618_members_yqcodeadd');

echo '<tr><td colspan=7><font color=green>'.$it618_members_lang['s190'].'</font></td></tr>';
echo '<tr><td colspan=7><span style="float:right">'.$it618_members_lang['s355'].'<input name="it618_findbz" value="'.$_GET['it618_findbz'].'" class="txt" style="width:400px" /><input type="submit" class="btn" name="it618submitfind" value="'.$it618_members_lang['s2'].'" /></span>'.$it618_members_lang['s160'].$count.' '.$it618_members_lang['s220'].$salecount.'</td></tr>';
showsubtitle(array('', $it618_members_lang['s356'],$it618_members_lang['s166'],$it618_members_lang['s357']));

foreach(C::t('#it618_members#it618_members_yqcode')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['it618_findbz'],$startlimit,$ppp
	) as $it618_members_yqcode) {
	if($it618_members_yqcode["it618_type"]==1&&$it618_members_yqcode["it618_state"]==1){
		$disabled='disabled="disabled"';
		$tmpstr='<font color=green>'.$it618_members_lang['s191'].'</font>';
	}else{
		$disabled='';
		$tmpstr='';
	}
	
	if($it618_members_yqcode["it618_type"]==1){
		$it618_type='<font color=red>'.$it618_members_lang['s358'].'</font>';
		$it618_code="******".$tmpstr;
		$it618_bz="";
	}
	if($it618_members_yqcode["it618_type"]==2){
		$it618_type='<font color=green>'.$it618_members_lang['s359'].'</font>';
		$it618_code="<input type=\"text\" class=\"txt\" style=\"width:150px;color:#888\" name=\"it618_code[".$it618_members_yqcode['id']."]\" value=\"".$it618_members_yqcode['it618_code']."\" onclick=\"this.select()\"> ";
		$it618_bz="<input type=\"text\" class=\"txt\" style=\"width:600px\" name=\"it618_bz[".$it618_members_yqcode['id']."]\" value=\"".$it618_members_yqcode['it618_bz']."\"> ";
	}
	
	showtablerow('', array('class="td25"', '', ''), array(
		"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_members_yqcode['id']."\" $disabled>",
		$it618_type,
		$it618_code,
		$it618_bz
	));

}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/data/yqcode'.$datapath.'.csv')){
	$tmp=fileatime(DISCUZ_ROOT.'./source/plugin/it618_members/data/yqcode'.$datapath.'.csv');
	$datastr='<font color=blue>'.$it618_members_lang['s173'].date("Y-m-d H:i:s",$tmp).' <a href="'.$_G['siteurl'].'source/plugin/it618_members/data/yqcode'.$datapath.'.csv" target="_blank"><b>'.$it618_members_lang['s174'].'</b></a></font>';
}

echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_members_lang['s167'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_members_lang['s168'].'"/> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_members_lang['s360'].'"/> <input type="submit" class="btn" name="it618submit_clear" value="'.$it618_members_lang['s169'].'" onclick="return confirm(\''.$it618_members_lang['s170'].'\')"/> <input type="submit" class="btn" name="it618submit_dao" value="'.$it618_members_lang['s172'].'"/><br>'.$datastr.' <font color=red>'.$it618_members_lang['s189'].'</font><input type=hidden value='.$page.' name=page /></div></td></tr>
<script>
function settype(obj){
	if(obj.value==1){
		document.getElementById("bzspan").style.display="none";
	}else{
		document.getElementById("bzspan").style.display="";
	}
}
</script>
';

	if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>