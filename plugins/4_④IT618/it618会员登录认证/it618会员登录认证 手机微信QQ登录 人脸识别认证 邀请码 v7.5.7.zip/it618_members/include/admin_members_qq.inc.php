<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql = "1";

if($_GET['uid']>0){
	$it618sql .= " and it618_uid =".intval($_GET['uid']);
}

$it618orderby='it618_time desc,id desc';

$urlsql='&key='.$_GET['key'].'&uid='.$_GET['uid'];
if($reabc[6]!='m')return;

if(submitcheck('it618submit_edit')){
	$ok=0;
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_members_editwork'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_members_deleditwork();
		}
	}
	C::t('#it618_members#it618_members_editwork')->insert(array(
		'it618_iswork' => 1
	), true);
	
	loaducenter();
	
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	$ucname=UC_DBTABLEPRE."members";
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_uname=trim($_GET['it618_uname'][$delid]);
		$it618_uid=trim($_GET['it618_uid'][$delid]);
		
		$user = uc_get_user($it618_uname);
		if(!empty($user)) {
			DB::query("delete from ".DB::table('it618_members_editwork'));
			cpmsg($it618_uname.'<br>'.$it618_members_lang['t91'].'<br>'.$it618_members_lang['s781'].$ok, "action=plugins&identifier=$identifier&cp=admin_members_wx&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'error');
		}
		
		DB::query("UPDATE ".DB::table('common_member')." SET username=%s WHERE uid=%d", array($it618_uname, $it618_uid));
		DB::query("UPDATE ".$ucname." SET username=%s WHERE uid=%d", array($it618_uname, $it618_uid));
		
		$ok=$ok+1;
	}

	cpmsg($it618_members_lang['s781'].$ok, "action=plugins&identifier=$identifier&cp=admin_members_wx&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_del')){
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_members_qquser', "id=$delid");
		$del=$del+1;
	}

	cpmsg($it618_members_lang['s156'].$del, "action=plugins&identifier=$identifier&cp=admin_members_qq&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

$datapath=md5(DISCUZ_ROOT);
if(submitcheck('it618submit_data')){
	$query = DB::query("SELECT * FROM ".DB::table('it618_members_qquser')." order by it618_uid");
	while($it618_members_qquser =	DB::fetch($query)){
		$users .= $it618_members_qquser['it618_uid'].','.$it618_members_qquser['it618_qqopenid']."\r\n";
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_members/data/qqusers'.$datapath.'.csv';
	
	@$fp = fopen($datapath,"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$users);
		fclose($fp);
	}

	cpmsg($it618_members_lang['s102'], "action=plugins&identifier=$identifier&cp=admin_members_qq&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_members_qq&pmod=admin_members&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($it618_members_lang['s483'],'it618_members_qquser');
	showsubmit('it618sercsubmit', $it618_members_lang['s2'], $it618_members_lang['s484'].' <input name="key" style="width:150px" value="'.$_GET['key'].'" class="txt" /> '.$it618_members_lang['s58'].' <input name="uid" style="width:60px;margin-right:3px" value="'.$_GET['uid'].'" class="txt" />');
	
	if($reabc[8]!='m')return;
	$count = C::t('#it618_members#it618_members_qquser')->count_all_by_search($it618sql,$it618orderby,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_members_qq&pmod=admin_members&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=8>'.$it618_members_lang['s11'].$count.' <span style="float:right;color:red"></span></td></tr>';
	
	showsubtitle(array('UID',$it618_members_lang['s17'], $it618_members_lang['s485'],$it618_members_lang['s486'],$it618_members_lang['s247'],$it618_members_lang['s602']));
	
	foreach(C::t('#it618_members#it618_members_qquser')->fetch_all_by_search(
		$it618sql,$it618orderby,$_GET['key'],$startlimit,$ppp
	) as $it618_members_qquser) {
		
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$it618_members_qquser['it618_uid'])>0){
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_qquser['it618_uid']);
		}else{
			C::t('#it618_members#it618_members_qquser')->delete_by_id($it618_members_qquser['id']);
			continue;
		}
		
		$it618_isreg='';
		if($it618_members_qquser['it618_isreg']==1){
			$it618_isreg=$it618_members_lang['t64'];
		}
		
		$u_avatarimg=it618_members_discuz_uc_avatar($it618_members_qquser['it618_uid'],'middle');
		
		showtablerow('', array('', '', '', '', ''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" id='uid".$it618_members_qquser['id']."' value=\"".$it618_members_qquser['it618_uid']."\" $disabled><label for='uid".$it618_members_qquser['it618_uid']."'>".$it618_members_qquser['it618_uid']."</label>",
				'<a href="home.php?mod=space&uid='.$it618_members_qquser['it618_uid'].'" target="_blank"><img src="'.$u_avatarimg.'" width=23 style="vertical-align:middle"></a> <input type="text" name="it618_uname['.$it618_members_qquser['id'].']" value="'.$username.'"/>'."<input type=\"hidden\" class=\"txt\" name=\"it618_uid[".$it618_members_qquser['id']."]\" value=\"".$it618_members_qquser['it618_uid']."\">",
				$it618_members_qquser['it618_qqname'],
				$it618_members_qquser['it618_qqopenid'],
				date('Y-m-d H:i:s', $it618_members_qquser['it618_time']).' '.$it618_isreg,
				$it618_members_qquser['it618_authcount'],
			));
	}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/data/qqusers'.$datapath.'.csv')){
	$tmp=fileatime(DISCUZ_ROOT.'./source/plugin/it618_members/data/qqusers'.$datapath.'.csv');
	$datastr='<font color=blue>'.$it618_members_lang['s103'].date("Y-m-d H:i:s",$tmp).' <a href="'.$_G['siteurl'].'source/plugin/it618_members/data/qqusers'.$datapath.'.csv" target="_blank"><b>'.$it618_members_lang['s104'].'</b></a></font>';
}

echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_members_lang['s89'].'</label> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_members_lang['s779'].'" onclick="return confirm(\''.$it618_members_lang['s780'].'\')"/> <input type="submit" class="btn" name="it618submit_del" value="'.$it618_members_lang['s175'].'" onclick="return confirm(\''.$it618_members_lang['s180'].'\')"/> <input type="submit" class="btn" name="it618submit_data" style="color:red" value="'.$it618_members_lang['s487'].'" /> '.$datastr.' &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=13)return;
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>