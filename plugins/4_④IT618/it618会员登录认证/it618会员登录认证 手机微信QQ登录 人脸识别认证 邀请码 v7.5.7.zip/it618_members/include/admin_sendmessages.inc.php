<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

global $ncount,$usercount;

if(submitcheck('it618submit')){
	$it618_members_messages_tpl=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_messages_tpl')." WHERE id=".intval($_GET['messages_tpl']));
	
	$gp_array = !empty($_GET['gp']) ? $_GET['gp'] : array();
	foreach($gp_array as $key => $value) {
		$gp.=$value.',';
	}
	if($gp!='')$gp=str_replace(",,","",$gp.',');
	
	$members_bz=$it618_members_messages_tpl['it618_content'];
	$members_bz=str_replace('${','{',$members_bz);
	$tmparr1=explode("{",$it618_members_messages_tpl['it618_content']);
	
	if(count($tmparr1)>1){
		
		for($i=1;$i<count($tmparr1);$i++){
			$tmparr=explode("}",$tmparr1[$i]);
			$tmplable=$tmparr[0];
			if($tmplable=='username'){
				$tmpvalue='it618username';
			}else{
				$tmpvalue=$_GET['messages_'.$it618_members_messages_tpl['id'].'_'.$tmplable];
			}
			$members_param.='"'.$tmplable.'":"'.$tmpvalue.'",';
			$members_bz=str_replace("{".$tmplable."}",$tmpvalue,$members_bz);
			
			$it618_value.=$tmpvalue.'@@@';
		}
		
		$members_param.='@';
		$members_param=str_replace(",@","",$members_param);
	}
	
	C::t('#it618_members#it618_members_messages_tpl')->update(intval($_GET['messages_tpl']),array(
		'it618_value' => $it618_value
	));
	
	if($it618_members_messages_tpl['it618_jktype']=='smsbao'){
		$members_sign=$it618_members_lang['s149'].$it618_members_messages_tpl['it618_sign'].$it618_members_lang['s150'];
		$members_tplid='';
		$members_param='';
		$jktype=$it618_members_messages_tpl['it618_jktype'];
	}else{
		$members_sign=$it618_members_messages_tpl['it618_sign'];
		$members_tplid=$it618_members_messages_tpl['it618_tplid'];
		$jktype=$it618_members_messages_tpl['it618_jktype'];
	}
	
	$jsinput=sendSMS_SMS($gp,$_GET['tels'],$members_bz);

	require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
	$smssign=getsmssign();
	
	$tmpstr=$members_sign.'it618_split'.$members_bz.'it618_split'.$members_tplid.'it618_split'.$members_param.'it618_split'.$jktype;
	$tmpstr=str_replace('"',"@@@",$tmpstr);
	
	echo $jsinput.'
	<div>
	<form id="sendmessages_tel">
	<input type="hidden" name="paramstr" value="'.$tmpstr.'">
	<input type="hidden" id="telsstr" name="telsstr">
	</form>
	<span id="smsimg" style="color:#999"><img src="source/plugin/it618_members/images/loading_r.gif" style="vertical-align:middle"> '.$it618_members_lang['s270'].'<br></span>
	'.$it618_members_lang['s271'].'<span id="smsokcount" style="font-size:14px"></span> <span id="smsbtn" style="display:none"><br><br><input type="button" class="btn" value="'.$it618_members_lang['s272'].'" onclick="history.back()"></span><span id="smserrstr" style="line-height:18px"></span></div>
	<script src="source/plugin/it618_members/js/jquery.js" type=text/javascript></script>
	<script>
	
	
	var n='.$ncount.';allcount=0,okcount=0,errstr="";
	function sendmessages_ajax(){
		IT618_MEMBERS.post("'.$_G['siteurl'].'plugin.php?id=it618_members:ajax&ac=sendmessages_tel&smssign='.$smssign.'", IT618_MEMBERS("#sendmessages_tel").serialize(),function (data, textStatus){

			var tmparr=data.split("it618_split");
			okcount=okcount+parseInt(tmparr[1]);
			allcount=allcount+parseInt(tmparr[2]);
			if(tmparr[3]!="")errstr=errstr+tmparr[3]+" ";
			
			IT618_MEMBERS("#smsokcount").html("<font color=#390><b>"+okcount+"</b></font>/"+allcount);
			if(errstr!="")IT618_MEMBERS("#smserrstr").html("<br><br>'.$it618_members_lang['s273'].'<br>"+errstr);
			
			if(allcount=='.$usercount.'){
				IT618_MEMBERS("#smsimg").hide();
				IT618_MEMBERS("#smsbtn").show();
			}
		}, "html");	
	}
	
	for(var i=1;i<=n;i++){
		document.getElementById("telsstr").value=document.getElementById("tels"+i).value;
		sendmessages_ajax();
	}
	</script>
	';
	exit;
	
	cpmsg($it618_members_lang['s90'], "action=plugins&identifier=$identifier&cp=admin_sendmessages&pmod=admin_sendmessages&operation=$operation&do=$do&page=$page", 'succeed');
}

function sendSMS_SMS($gp,$tels,$members_bz){
	global $_G,$ncount,$usercount;

	$ppp=1;
	$uidstr='';
	$usercount=0;
	$usercount1=0;
	$ncount=0;
	$gparr=explode(",",$gp);
	for($i=0;$i<count($gparr);$i++){
		$query = DB::query("SELECT w.it618_tel,w.it618_uid FROM ".DB::table('it618_members_user')." w left join ".DB::table('common_member')." m on w.it618_uid=m.uid where m.groupid=".intval($gparr[$i]));
		while($common_member = DB::fetch($query)) {

			$usercount=$usercount+1;
			$usercount1=$usercount1+1;
			$tmparr1=explode("it618username",$members_bz);
			if(count($tmparr1>1)){
				$telsstr.=$common_member['it618_tel'].'|'.$common_member['it618_uid'].',';
			}else{
				$telsstr.=$common_member['it618_tel'].',';
			}
			if($usercount1==$ppp){
				$ncount=$ncount+1;
				$usercount1=0;
				$jsinput.='<input type="hidden" id="tels'.$ncount.'" value="'.$telsstr.'">';
				$telsstr='';
			}
		}
	}
	
	$telarr=explode("@",$tels);
	for($i=0;$i<count($telarr);$i++){
		$it618_tel=$telarr[$i];
		if($it618_tel!=''){
			
			$usercount=$usercount+1;
			$usercount1=$usercount1+1;
			$telsstr.=$it618_tel.',';
			if($usercount1==$ppp){
				$ncount=$ncount+1;
				$usercount1=0;
				$jsinput.='<input type="hidden" id="tels'.$ncount.'" value="'.$telsstr.'">';
				$telsstr='';
			}
		}
	}
	
	if($uidstr!=''){
		$jsinput.='<input type="hidden" id="tels'.$ncount.'" value="'.$telsstr.'">';
		$ncount=$ncount+1;
	}
	
	return $jsinput;
}

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('common_usergroup'));
while($common_usergroup = DB::fetch($query)) {
	
	$n1 = DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." m left join ".DB::table('it618_members_user')." u on m.uid=u.it618_uid where u.it618_tel!='' and m.groupid=".$common_usergroup['groupid']);

	if($n1>0){
		$gpstr.='<input class="checkbox" type="checkbox" id="chk_gp'.$n.'" name="gp[]" value="'.$common_usergroup['groupid'].'"><label for="chk_gp'.$n.'">'.$common_usergroup['grouptitle'].'(<font color=red>'.$n1.'</font>)</label> ';
		$n=$n+1;
	}
}

if($gpstr=='')$gpstr='<font color=red>'.$it618_members_lang['s91'].'</font>';

$tmpjs='';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_members_messages_tpl')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmpvalue=explode("@@@",$it618_tmp['it618_value']);
	
	if($it618_tmp['it618_jktype']=='smsbao')$it618_jktype=$it618_members_lang['s136'];
	if($it618_tmp['it618_jktype']=='alidayu')$it618_jktype=$it618_members_lang['s137'];
	if($it618_tmp['it618_jktype']=='alisms')$it618_jktype=$it618_members_lang['s224'];
	
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_jktype.' '.$it618_members_lang['s86'].$it618_tmp['it618_sign'].$it618_members_lang['s87'].$it618_tmp['it618_content'].'</option>';
	
	$tmparr1=explode("{",$it618_tmp['it618_content']);
	if(count($tmparr1)>1){
		$tmptext='';$tmpvalueid='';
		for($i=1;$i<count($tmparr1);$i++){
			$tmparr=explode("}",$tmparr1[$i]);
			$tmplable=$tmparr[0];
			
			if($tmplable!='username'){
				$tmptext.=$tmplable.$it618_members_lang['s106'].'<input type="text" style="width:300px" id="messages_'.$it618_tmp['id'].'_'.$tmplable.'" name="messages_'.$it618_tmp['id'].'_'.$tmplable.'" value="'.$tmpvalue[$i-1].'"><br>';
				$tmpvalueid.=$tmplable.',';
			}
		}
		
		if($tmpvalueid!=''){$tmpvalueid.='@';$tmpvalueid=str_replace(',@','',$tmpvalueid);}
		if($tmptext!='')$tmptr.='<tr id="trvalue'.$it618_tmp['id'].'" name="trvalue"><td>'.$it618_members_lang['s99'].'</td><td width=800 style="line-height:30px">'.$tmptext.'<input type="hidden" id="valueid'.$it618_tmp['id'].'" value="'.$tmpvalueid.'"></td><td></td></tr>';
	}
	
	if($tmpjs=='')$tmpjs='settrvalue('.$it618_tmp['id'].')';
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_sendmessages&pmod=admin_sendmessages&operation=$operation&do=$do");
showtableheaders($it618_members_lang['s78'],'it618_members_card');
	
echo '
<tr><td width=100>'.$it618_members_lang['s92'].'</td><td width=800>'.$gpstr.'<br><br><input class="checkbox" type="checkbox" id="chk_gpall" onclick="check_all(this, \'chk_gp\')"><label for="chk_gpall">'.$it618_members_lang['s89'].'</label> <font color=#999>'.$it618_members_lang['s93'].'</font></td><td></td></tr>
<tr><td>'.$it618_members_lang['s111'].'</td><td width=800><textarea id="tels" name="tels" style="width:800px;height:180px"></textarea><br><font color=#999>'.$it618_members_lang['s112'].'</font></td><td></td></tr>
<tr><td>'.$it618_members_lang['s94'].'</td><td width=800><select id="messages_tpl" name="messages_tpl" onchange="settrvalue(this.value)">'.$tmp.'</select> <a href="'.$hosturl.'plugins&cp=admin_messages_tpl'.$urls.'">'.$it618_members_lang['s177'].'</a></td><td></td></tr>
'.$tmptr.'
<tr><td colspan=3><input type="submit" class="btn" name="it618submit" onclick="return checkvalue()" value="'.$it618_members_lang['s88'].'"/></td></tr>

<script>
function checkvalue(){
	var flag=0,n='.$n.';
	for(var i=1;i<'.$n.';i++)
	{
		if(document.getElementById("chk_gp"+i).checked)flag=1;
	}
	if(document.getElementById("tels").value!=""){
		flag=1;
	}
	if(flag==0){
		alert("'.$it618_members_lang['s95'].'");
		return false;
	}
	
	var tmpid=document.getElementById("messages_tpl").value;
	if(tmpid==0){
		alert("'.$it618_members_lang['s96'].'");
		return false;
	}else{
		if(document.getElementById("tels").value!=""){
			var item = document.getElementById("messages_tpl"); 
			var text = item.options[item.selectedIndex].text; 
			var tmparr=text.split("{username}");
			if(tmparr.length>1){
				alert("'.$it618_members_lang['s178'].'");
				return false;
			}
		}
	}
	
	if(document.getElementById("valueid"+tmpid)!=null){
		var tmp = document.getElementById("valueid"+tmpid).value;
		var tmparr=tmp.split(",");
		for(var i=0;i<tmparr.length;i++){
			if(document.getElementById("messages_"+tmpid+"_"+tmparr[i]).value==""){
				alert("'.$it618_members_lang['s107'].'"+tmparr[i]+"'.$it618_members_lang['s108'].'");
				document.getElementById("messages_"+tmpid+"_"+tmparr[i]).focus();
				return false;
			}
			
		}
	}

	return confirm("'.$it618_members_lang['s97'].'");
}

function check_all(obj,id)
{
	for(var i=1;i<'.$n.';i++)
	{
		document.getElementById(id+""+i).checked = obj.checked;
	}
}

function settrvalue(id){
	var trobj=document.getElementsByName("trvalue");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}
	
	if(document.getElementById("trvalue"+id)!=null)
	document.getElementById("trvalue"+id).style.display="";
}

'.$tmpjs.'
</script>
';

if(count($reabc)!=13)return;
showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
?>