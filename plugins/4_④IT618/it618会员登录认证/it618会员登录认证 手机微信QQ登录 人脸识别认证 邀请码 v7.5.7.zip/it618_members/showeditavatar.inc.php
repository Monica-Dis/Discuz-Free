<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

$wap=$_GET['wap'];

if($_G['uid']<=0){
	$showmessage='<a href="member.php?mod=logging&action=login">'.$it618_members_lang['s40'].'</a>';
}else{
	if($membersset['avatar_isedit']==1){
		$isedit=1;
		$avatar_edituids=explode(",",$membersset['avatar_edituids']);
		if(in_array($_G['uid'], $avatar_edituids)){
			$strtmp=$it618_members_lang['t185'];
			$strtmp=str_replace("{username}",$_G['username'],$strtmp);
			$isedit=0;
		}else{
			if($membersset['avatar_editcredits']>0&&$membersset['avatar_editcount']>0){
				$strtmp=$it618_members_lang['t184'];
				$strtmp=str_replace("{username}",$_G['username'],$strtmp);
				
				$cname=$_G['setting']['extcredits'][$membersset['avatar_editcredits']]['title'];
				$strtmp=str_replace("{count1}",$membersset['avatar_editcount'].$cname,$strtmp);
				
				$creditnum=DB::result_first("select extcredits".$membersset['avatar_editcredits']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				$strtmp=str_replace("{count2}",$creditnum.$cname,$strtmp);
				
			}else{
				$strtmp=$it618_members_lang['t125'];
				$strtmp=str_replace("{username}",$_G['username'],$strtmp);
			}
		}
	}else{
		$showmessage=$it618_members_lang['t93'];
	}
}

if(submitcheck('submitattachment')&&$showmessage==''){
	if($_FILES['it618_upfile']['error']==0&&$_FILES["it618_upfile"]["name"]!=''){
	
		$tmparr=explode(".", $_FILES["it618_upfile"]["name"]);
		$filetype=strtolower($tmparr[count($tmparr)-1]);
		
		if(!in_array($filetype, array("jpg","jpeg","png","gif"))){
			$showmessage=$it618_members_lang['t120'];
		}
		
		$filesize=$_FILES['it618_upfile']['size']/1024/1024;
		if($filesize>10&&$showmessage==''){ 
			$showmessage=$it618_members_lang['t121'].'10M'.$it618_members_lang['t122'];
		}
		
		if($membersset['avatar_editcredits']>0&&$membersset['avatar_editcount']>0){
			  $strtmp=$it618_members_lang['t90'];
			  $cname=$_G['setting']['extcredits'][$membersset['avatar_editcredits']]['title'];
			  $strtmp=str_replace("{count1}",$membersset['avatar_editcount'].$cname,$strtmp);
			  
			  $creditnum=DB::result_first("select extcredits".$membersset['avatar_editcredits']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
			  
			  if($creditnum<$membersset['avatar_editcount']){
				  $showmessage=str_replace("{count2}",$creditnum.$cname,$strtmp);
			  }
		 }
			
		if($showmessage==''){
			$filepath = "source/plugin/it618_members/temp/";
			$filename=md5(FORMHASH.$_G['timestamp']).".".$filetype;

			if(@copy($_FILES['it618_upfile']['tmp_name'], $filepath.$filename) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['it618_upfile']['tmp_name'], $filepath.$filename))) {
				@unlink($_FILES['it618_upfile']['tmp_name']);
				
				$tmparr=@getimagesize($filepath.$filename);
				if($tmparr === FALSE){
					if(file_exists($filepath.$filename)){
						$result=unlink($filepath.$filename);
					}
					echo 'err';exit;
				}else{
					$imgwidth=3000;
					it618_members_imagetosmall($filepath.$filename,$imgwidth);
				}

				@chmod($file_path, 0644);
				
				$tmparr=explode("source",$filepath.$filename);
				$it618_attachment=DISCUZ_ROOT.'./source'.$tmparr[1];

				loaducenter();
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/wxlogin.func.php';
				$upload_result=it618_wxsyncAvatar($_G['uid'],$it618_attachment,1);
				if($upload_result==true){
					$showmessage=$it618_members_lang['t183'];
					$showmessage=str_replace("{username}",$_G['username'],$showmessage);
				
					C::t('common_member_count')->increase($_G['uid'], array(
						'extcredits'.$membersset['avatar_editcredits'] => (0-$membersset['avatar_editcount']))
					);
				}

			}
		}
	}
}

$_G['mobiletpl'][2]='/';

if($wap!=1)include template('common/header');
include template('it618_members:showeditavatar');
if($wap!=1)include template('common/footer');
?>