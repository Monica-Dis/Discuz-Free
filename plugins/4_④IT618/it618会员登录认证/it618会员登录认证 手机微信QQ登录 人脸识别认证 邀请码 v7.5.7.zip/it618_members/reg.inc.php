<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$navtitle = $it618_members_lang['t64'];

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php';
}

if($it618_members['members_isok']==0){
	$regname=$_G['setting']['regname'];
	dheader("location:member.php?mod=$regname");
}

if($tellogin['ischeck_reg']==1||$tellogin['regmode']==3){
	$isvcode=1;
}

if($wxjk_mode==1||$wxjk_mode==2){
	$it618wxloginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login&it618wxlogin","?it618wxlogin");
}

$wap=0;
if(members_is_mobile()){
	$wap=1;
	if($it618_members['members_waplogomargin']=='')$it618_members['members_waplogomargin']='46|15';
	$logomarginarr=explode("|",$it618_members['members_waplogomargin']);
	
	$stylearr=explode("|",$it618_members['members_regloginstyle'].'|');
	if($stylearr[5]==''){
		$wapwidth=90;
	}else{
		$wapwidth=$stylearr[5];
	}
	if($wapwidth>95)$wapwidth1=96; else $wapwidth1=$wapwidth;
}else{
	$stylearr=explode("|",$it618_members['members_pcregloginstyle'].'|');	
}

if($it618_members['members_regtourl']!=''){
	$tmparr=explode("|",$it618_members['members_regtourl']);
	$preurl=$tmparr[$wap];
}else{
	$it618_loginpreurl=getcookie('it618_loginpreurl');

	if($it618_loginpreurl!=''){
		$tmparr=explode("action=logout",$it618_loginpreurl);
		if(count($tmparr)>1){
			$preurl=$_G['siteurl'];
		}else{
			$preurl=$it618_loginpreurl;	
		}
	}else{
		if($it618_members['members_tourl']!=''){
			$tmparr=explode("|",$it618_members['members_tourl']);
			$preurl=$tmparr[$wap];
		}else{
			$preurl=$_SERVER['HTTP_REFERER'];
			if($it618_members['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php')){
				$tmparr1=explode("plugin.php?id=it618_members:login",$preurl);
				$tmparr2=explode("plugin.php?id=it618_members:reg",$preurl);
				if(count($tmparr1)>1||count($tmparr2)>1){
					$preurl=$_G['siteurl'];
				}
			}else{
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php';
				}
				$tmparr1=explode($members_login,$preurl);
				$tmparr2=explode($members_reg,$preurl);
				if(count($tmparr1)>1||count($tmparr2)>1){
					$preurl=$_G['siteurl'];
				}
			}
		}
	}
}

if($preurl=='')$preurl=$_G['siteurl'];
dsetcookie('it618_loginpreurl',$preurl,31536000);

if($tellogin['regmode']==3){
	$css_liuname='style="display:"';
	$css_lipassword='style="display:"';
	$css_liusertel='style="display:none"';
	$css_liusertelcode='style="display:none"';
}else{
	if($tellogin['regmode']==1||$tellogin['regmode']==4){
		$arraylicss2='class="current"';
		if($tellogin['isuname']==1)$css_liuname='style="display:none"';else$css_liuname='style="display:"';
		$css_lipassword='style="display:none"';
		$css_liusertel='style="display:"';
		$css_liusertelcode='style="display:"';
		
		$n=1;
		$chars = 'abcdefghijklmnopqrstuvwxyz';
		while($n<=8){
			$tmpusername.=substr($chars,mt_rand(0,strlen($chars)-1),1);
			$n=$n+1;
		}
		$n=1;
		$chars = '012345678901234567890123456789';
		while($n<=8){
			$tmppassword.=substr($chars,mt_rand(0,strlen($chars)-1),1);
			$n=$n+1;
		}
	}else{
		$arraylicss1='class="current"';
		$css_liuname='style="display:"';
		$css_lipassword='style="display:"';
		$css_liusertel='style="display:"';
		$css_liusertelcode='style="display:"';
	}
}

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login");

if(isset($_GET['login_wx'])){
	
	$it618_openid=getcookie('it618_openid');
	if($it618_openid!=''&&$iswx==1){
		dsetcookie('it618_preurl',$preurl,31536000);
		$it618_wxdata=getcookie('it618_wxdata');
		$wxdataarr=explode("@@@",$it618_wxdata);
		$nickname=$wxdataarr[1];
		$tmpusername=$nickname;
		$headimgurl=$wxdataarr[2];
		
		$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('wxjk_wxabout3');
		if($it618_members_set['setvalue']!='')$abouttype='wx';
		$abouttitle=$it618_members_lang['s548'];
		
		if($wxjk_wxreglogintip=='')$wxjk_wxreglogintip=$it618_members_lang['s381'];
		$nicknameabout=$wxjk_wxreglogintip;

		$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login&login_wx","?login_wx");
		
		loaducenter();
		$user = uc_get_user($nickname);
		
		if(!empty($user)) {
			$regnickname = $nickname.'_'.random(5);
			$tmpusername=$regnickname;
		}
		
		if($tellogin['iswxqquname']==1)$css_liuname='style="display:none"';
		
		if($wxjk_iswxregtel==0)$iswxregtelnone=1;
	}
}

if(isset($_GET['login_qq'])){
	
	$it618_qqopenid=getcookie('it618_qqopenid');
	if($it618_qqopenid!=''){
		dsetcookie('it618_preurl',$preurl,31536000);
		$it618_qqdata=getcookie('it618_qqdata');
		$qqdataarr=explode("@@@",$it618_qqdata);
		$nickname=$qqdataarr[1];
		$tmpusername=$nickname;
		$headimgurl=$qqdataarr[2];
		
		$it618_members_set=C::t('#it618_members#it618_members_set')->fetch_by_setname('qqjk_qqabout1');
		if($it618_members_set['setvalue']!='')$abouttype='qq';
		$abouttitle=$it618_members_lang['s549'];
		
		if($qqjk_qqreglogintip=='')$qqjk_qqreglogintip=$it618_members_lang['s312'];
		$nicknameabout=$qqjk_qqreglogintip;
		
		$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login&login_qq","?login_qq");
		
		loaducenter();
		$user = uc_get_user($nickname);
		if(!empty($user)) {
			$regnickname = $nickname.'_'.random(5);
			$tmpusername=$regnickname;
		}
		
		if($tellogin['iswxqquname']==1)$css_liuname='style="display:none"';
		
		if($qqjk_isqqregtel==0)$isqqregtelnone=1;
	}
}

if($iswxregtelnone==1||$isqqregtelnone==1){
	$css_liusertel='style="display:none"';
	$css_liusertelcode='style="display:none"';
}

if($_G['uid']>0){
	dheader("location:$preurl");
}

$members_regabout=$it618_members['members_regabout'];

if($yqcodeset['isok']==1){
	$isbuycode=1;
	$codeprice=$yqcodeset['price'].$it618_members_lang['s277'];
	
	if($wap==1)$yqcodeabout=$it618_members_lang['s501'];
	if($yqcodeset['ispay']==1)$yqcodeabout=$it618_members_lang['s499'];
	
	if($_GET['yqcode']!=''){
		$yqcode=$_GET['yqcode'];
		dsetcookie('it618_yqcode',$yqcode,31536000);
	}else{
		$yqcode=getcookie('it618_yqcode');
	}			
}

$members_teltime=$tellogin['codeoktime'];
if($members_teltime==0)$members_teltime=60;

$it618_union = $_G['cache']['plugin']['it618_union'];
if($it618_union['union_istuiuid']==1){
	$tuiuid=getcookie('it618_union_tuiuid');
	
	if($tuiuid>0)$usercount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$tuiuid);
	
	if($usercount>0){
		$groupid=DB::result_first("select groupid from ".DB::table('common_member')." where uid=".$tuiuid);
		$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
		if(!(!in_array($groupid, $union_tuigroup)&&$union_tuigroup[0]!='')){
			$username=it618_members_getusername($tuiuid);
			$userurl=it618_members_rewriteurl($tuiuid);
			$union_tuistr=$it618_union['union_tuistr'];
			$union_tuistr=str_replace("{tuiurluser}",'<a href="'.$userurl.'" target="_blank">'.$username.'</a>',$union_tuistr);
			$union_tuistr=str_replace("{tuiuser}",$username,$union_tuistr);
		}
	}
}

if($wap==1){
	if($it618_union['union_regwapurl']!='')$preurl=$it618_union['union_regwapurl'];
}else{
	if($it618_union['union_regpcurl']!='')$preurl=$it618_union['union_regpcurl'];
}

if(isset($_GET['aboutbtn'])){
	$aboutbtn=1;
}

$winapi=intval($_GET['winapi']);
if($winapi==0)$winapi='';
$tel=$_GET['tel'];

$_G['mobiletpl'][2]='/';

$tmpjs='<SCRIPT src="source/plugin/it618_members/js/jquery.js" type=text/javascript></'.'SCRIPT>';
if($wap==1){
	if($it618_members['members_wapbgimage']!=''){
		$members_wapbgimagearr=explode("@@@",str_replace(array("\r\n", "\r", "\n"), '@@@', $it618_members['members_wapbgimage']));
		$members_wapbgimagetmp=explode("|",$members_wapbgimagearr[mt_rand(0,count($members_wapbgimagearr)-1)]);
		$members_wapbgimage=$members_wapbgimagetmp[0];
		$members_wapbgimagetxt=$members_wapbgimagetmp[1];
	}
	
	if($IsGroup==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
		$it618_group_wapad=it618_group_getad($_GET['id'],1);
	}
	
	$layerstylearr=explode("|",$it618_members['members_regloginstyle'].'|');
	include template('it618_members:layer');
	
	include template('it618_members:regjs');
	
	include template('it618_members:wapreg');
}else{
	if($it618_members['members_jquery']==1){
		$tmpjs='<script>var IT618_MEMBERS=jQuery;</'.'SCRIPT>';
	}
	
	if($winapi==1){
		$layerstylearr=explode("|",'|'.$it618_members['members_pcregloginstyle'].'|');
		include template('it618_members:layer');
	}
	
	$wxurl='href="javascript:" onclick="it618_showsms(\'it618_loginwx\',\'plugin.php?id=it618_members:login&win_wx\');setTimeout(\'getwxuid()\',1500);"';

	$members_loginurl=$it618_members['members_loginurlbottom'];
	$members_loginurl=str_replace('{codeurl}',$wxurl,$members_loginurl);
	
	include template('it618_members:regjs');
	
	include template('it618_members:reg');
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>