<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_members;
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_members/wxlogin.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php';
}

if($qqjk_isok!=1){
	dheader("location:".$_G['siteurl']);
}

if($_GET['preurl']!=''){
	$preurl=$_GET['preurl'];
	dsetcookie('it618_loginpreurl',$preurl,31536000);
}else{
	$it618_loginpreurl=getcookie('it618_loginpreurl');
	if($it618_loginpreurl==''){
		$preurl=$_SERVER['HTTP_REFERER'];
		$qq_HTTP_REFERER=getcookie('qq_HTTP_REFERER');
		if($qq_HTTP_REFERER!=''){
			$tmparr1=explode("reg",$qq_HTTP_REFERER);
			$tmparr2=explode("login",$qq_HTTP_REFERER);
			if(count($tmparr1)==1&&count($tmparr2)==1){
				$preurl=$qq_HTTP_REFERER;
			}
		}
		$tmparr=explode("login",$preurl);
		if(count($tmparr)>1){
			$preurl=$_G['siteurl'];
		}
		if($preurl=='')$preurl=$_G['siteurl'];
	}else{
		$preurl=$it618_loginpreurl;
	}
}

if($_G['uid']>0){
	if($it618_members_qquser=C::t('#it618_members#it618_members_qquser')->fetch_by_uid($_G['uid'])){
		dheader("location:".$preurl);
	}
}

$appid=trim($qqjk_appid);
$appsecret=trim($qqjk_appsecret);
$redirecturi=trim($qqjk_url);

if(isset($_GET['code'])){
	$code=$_GET['code'];
	$redirect_uri=urlencode($redirecturi);
	
	$res=get_qqtoken($appid,$appsecret,$code,$redirect_uri);
	$tmparr=explode('it618_split',$res);
	if($tmparr[0]=='msg'){
		echo $tmparr[1];exit;
	}else{
		$access_token=$res;
	}
	
	$res=get_qqdata($appid,$access_token);
	$tmparr=explode('it618_split',$res);
	if($tmparr[0]=='msg'){
		echo $tmparr[1];exit;
	}else{
		$openid=$tmparr[0];
		dsetcookie('it618_qqopenid',$openid,31536000);
		$qqdata = json_decode($tmparr[1], true);
		
		$nickname=it618_members_utftogbk(it618_wxclear($qqdata['nickname']));
		$headimgurl=str_replace('\/','/',$qqdata['figureurl_qq_1']);
		
		dsetcookie('it618_qqdata',$openid.'@@@'.$nickname.'@@@'.$headimgurl,31536000);
	}
}else{
	if($_GET['preurl']==''){
		$tmpurl=$_SERVER['HTTP_REFERER'];
		dsetcookie('qq_HTTP_REFERER',$tmpurl,31536000);
	}
	
	$redirect_uri=urlencode($redirecturi);
	$scope='get_user_info';
	$state=FORMHASH;

	dheader("location:https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=$appid&redirect_uri=$redirect_uri&scope=$scope&state=$state");
}

if($_G['uid']<=0){
	if($it618_members_qquser=C::t('#it618_members#it618_members_qquser')->fetch_by_openid($openid)){
		$loginuid=$it618_members_qquser['it618_uid'];

		C::t('#it618_members#it618_members_qquser')->update($it618_members_qquser['id'],array(
			'it618_authcount' => $it618_members_qquser['it618_authcount']+1
		));
	}else{
			
		if($qqjk_isqqregtel!=1&&($yqcodeset['isok']==0||$yqcodeset['isok']==1&&$yqcodeset['iswxqq']==0)){
			$newname=it618_qqgetnewname($nickname);

			$n=1;
			$chars = '012345678901234567890123456789';
			while($n<=8){
				$password.=substr($chars,mt_rand(0,strlen($chars)-1),1);
				$n=$n+1;
			}
			
			$tmpstr=it618_qqregister($newname,$password);
			$tmparr=explode("it618_split",$tmpstr);

			if($tmparr[0]=='ok'){
				$reguid=$tmparr[1];
				
				it618_wxsyncAvatar($reguid,$headimgurl);
				
				$id=C::t('#it618_members#it618_members_qquser')->insert(array(
					'it618_uid' => $reguid,
					'it618_qqopenid' => $openid,
					'it618_qqname' => $nickname,
					'it618_authcount' => 1,
					'it618_isreg' => 1,
					'it618_time' => $_G['timestamp']
				), true);
				
				$loginuid=$reguid;

			}
		}else{
			$loginurl=it618_members_getrewrite("members_login","","plugin.php?id=it618_members:login&login_qq","?login_qq");
			dheader("location:$loginurl");
		}
	}
}else{
	if(!$it618_members_qquser=C::t('#it618_members#it618_members_qquser')->fetch_by_uid($_G['uid'])){
		if(!$it618_members_qquser=C::t('#it618_members#it618_members_qquser')->fetch_by_openid($openid)){
			$id=C::t('#it618_members#it618_members_qquser')->insert(array(
				  'it618_uid' => $_G['uid'],
				  'it618_qqopenid' => $openid,
				  'it618_qqname' => $nickname,
				  'it618_authcount' => 1,
				  'it618_time' => $_G['timestamp']
			  ), true);
		}else{
			if($it618_members_qquser=C::t('#it618_members#it618_members_qquser')->fetch_by_openid($openid)){
				if($it618_members_qquser['it618_uid']!=$_G['uid']){
					$username=it618_members_getusername($it618_members_qquser['it618_uid']);
					echo '<script>alert("'.$it618_members_lang['s659'].$username.'('.$it618_members_qquser['it618_uid'].')'.$it618_members_lang['s660'].'");location.href="'.$preurl.'";</script>';exit;
				}
			}
		}
	}else{
		C::t('#it618_members#it618_members_qquser')->update($it618_members_qquser['id'],array(
			'it618_qqopenid' => $openid,
			'it618_qqname' => $nickname,
			'it618_authcount' => $it618_members_qquser['it618_authcount']+1
		));
	}
	
	dheader("location:".$preurl);
}

if($loginuid>0){
	require_once libfile('function/member');
	$member=getuserbyuid($loginuid, 1);
							
	setloginstatus($member, 1296000);
	it618_members_getlogin($_G['uid'],'qq');
}

dheader("location:$preurl");

function get_qqtoken($appid,$appsecret,$code,$redirect_uri,$dzroot=''){
	$url = "https://graph.qq.com/oauth2.0/token?grant_type=authorization_code&client_id=".$appid."&client_secret=".$appsecret."&code=".$code."&redirect_uri=".$redirect_uri;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);

	curl_close( $ch );
	
	$tmparr=explode("error",$res);
	if(count($tmparr)>1){
		return 'msgit618_split'.$res;
	}
	
	$tmparr=explode("=",$res);
	$tmparr1=explode("&",$tmparr[1]);
	return $tmparr1[0];
}

function get_qqdata($appid,$access_token,$dzroot=''){
	$url = "https://graph.qq.com/oauth2.0/me?access_token=".$access_token;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);

	curl_close( $ch );
	
	$tmparr=explode("error",$res);
	if(count($tmparr)>1){
		return 'msgit618_split'.$res;
	}
	
	$tmparr=explode('":"',$res);
	$tmparr1=explode('"',$tmparr[2]);
	$openid=$tmparr1[0];
	
	$url = "https://graph.qq.com/user/get_user_info?access_token=".$access_token."&oauth_consumer_key=".$appid."&openid=".$openid;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);
	
	curl_close( $ch );
	
	$data = json_decode($res, true);
	if($data['msg']!=''){
		return 'msgit618_split'.$data['msg'];
	}
	
	return $openid.'it618_split'.$res;
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>