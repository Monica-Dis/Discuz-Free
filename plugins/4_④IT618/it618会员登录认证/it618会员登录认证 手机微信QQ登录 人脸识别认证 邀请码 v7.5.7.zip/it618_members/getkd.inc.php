<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_members = $_G['cache']['plugin']['it618_members'];

if($it618_members_kdsale=C::t('#it618_members#it618_members_kdsale')->fetch_by_id($_GET['kdid'])){
	$saletype=$it618_members_kdsale['it618_saletype'];
	$saleid=$it618_members_kdsale['it618_saleid'];

	if($saletype=='it618_brand_order'){
		$it618_brand_order=C::t('#it618_brand#it618_brand_order')->fetch_by_id($saleid);
		if($_G['uid']!=$it618_brand_order['it618_uid']){
			$errorstr=$it618_members_lang['s557'];
		}
	}
	
	if($saletype=='it618_brand_sale'){
		$it618_brand_sale=C::t('#it618_brand#it618_brand_sale')->fetch_by_id($saleid);
		if($_G['uid']!=$it618_brand_sale['it618_uid']){
			$errorstr=$it618_members_lang['s557'];
		}
	}
	
	if($saletype=='it618_tuan_order'){
		$it618_tuan_order=C::t('#it618_tuan#it618_tuan_order')->fetch_by_id($saleid);
		if($_G['uid']!=$it618_tuan_order['it618_uid']){
			$errorstr=$it618_members_lang['s557'];
		}
	}
	
	if($saletype=='it618_tuan_sale'){
		$it618_tuan_sale=C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($saleid);
		if($_G['uid']!=$it618_tuan_sale['it618_uid']){
			$errorstr=$it618_members_lang['s557'];
		}
	}

	if($errorstr==''){
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/kd.func.php';
		$it618_data=GetKDdata($it618_members_kdsale);
	}
}else{
	$errorstr=$it618_members_lang['s556'];
}

if($errorstr!=''){
	$it618_data='<tr><td>'.$errorstr.'</td></tr>';
}

if($_GET['wap']==1){
	$height=$_GET['height']*0.8;
}

$_G['mobiletpl'][2]='/';
include template('it618_members:getkd');
?>