<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

if(members_is_mobile()){
	$wap=1;
}

if($_G['uid']<=0){
	$showmessage='<a href="member.php?mod=logging&action=login">'.$it618_members_lang['s40'].'</a>';
}else{
	if(strpos($_SERVER['HTTP_HOST'],'localhost')){
		if($_G['uid']==14||$_G['uid']==4080||$_G['uid']==221||$_G['uid']==222||$_G['uid']==697||$_G['uid']==915){
			$showmessage=$it618_members_lang['s736'];
		}
	}
	
	if($it618_members['members_certtype']>1&&$showmessage==''){
		
		$tmpcharset='charset="utf-8"';
		
		if($it618_members['members_certdiytitle']!=''){
			$diytip=str_replace("{diyname}",$it618_members['members_certdiytitle'],$it618_members_lang['s457']);
		}
		
		$ispost=1;
		$confirmstr=$it618_members_lang['s700'];
		if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$_G['uid'])){
			if($it618_members_rzuser['it618_sex']==0)$it618_sex0='selected="selected"';
			if($it618_members_rzuser['it618_sex']==1)$it618_sex1='selected="selected"';
			if($it618_members_rzuser['it618_sex']==2)$it618_sex2='selected="selected"';
			
			if($it618_members_rzuser['it618_cardimg1']!='')$src1='src="'.$it618_members_rzuser['it618_cardimg1'].'"';
			if($it618_members_rzuser['it618_cardimg2']!='')$src2='src="'.$it618_members_rzuser['it618_cardimg2'].'"';
			if($it618_members_rzuser['it618_cardimg3']!='')$src3='src="'.$it618_members_rzuser['it618_cardimg3'].'"';
			
			global $oss;
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/php/aliyunossconfig.php')){
				require_once DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/php/aliyunossconfig.php';
				if($it618_isok==1){
					$oss='&oss';
				}
			}
			
			if($it618_members_rzuser['it618_state']==1){
				if($it618_members['members_isedit']==1){
					$rztitle='<img src="/source/plugin/it618_members/images/check_right.gif" style="vertical-align:middle;margin-top:-4px"> '.$it618_members_lang['s463'];
					$confirmstr=$it618_members_lang['s701'];
				}else{
					$rztitle='<img src="/source/plugin/it618_members/images/check_right.gif" style="vertical-align:middle;margin-top:-4px"> '.$it618_members_lang['s462'];
					$ispost=0;
				}
			}else if($it618_members_rzuser['it618_state']==2){
				$rztitle=$it618_members_lang['s464'];
				$rztitle=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']),$rztitle);
				$ispost=0;
			}else{
				$rztitle='<img src="/source/plugin/it618_members/images/check_error.gif" style="vertical-align:middle;margin-top:-4px"> '.$it618_members_lang['s466'];
				$rztitle=str_replace("{checktime}",date('Y-m-d H:i:s', $it618_members_rzuser['it618_checktime']),$rztitle);
				if($it618_members_rzuser['it618_statebz']!='')$rztitle.='<br><font color=blue>'.$it618_members_lang['s706'].$it618_members_rzuser['it618_statebz'].'</font>';
			}
		}else{
			$rztitle=$it618_members_lang['s465'];	
		}
		
		if($it618_members['members_certissfz']==1){
			$rzautocheck=$it618_members['members_rzautocheck'];
			
			if($rzautocheck==1){
				$rzautocheckabout=$it618_members['members_rzautocheckabout'];
			}
			if($rzautocheck==2||$rzautocheck==3||$rzautocheck==4||$rzautocheck==5||$rzautocheck==6){
				$rzautocheckabout=$it618_members['members_vrzautocheckabout'];
			}
		}
		
		if($ispost==1){
			if($it618_members['members_certtype']==2){
				if(!$it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
					$showmessage=$it618_members_lang['s702'];
				}
			}
			if($it618_members['members_certtype']==3){
				if(!$it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
					$showmessage=$it618_members_lang['s703'];
				}
				if(!$it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($_G['uid'])){
					$showmessage=$it618_members_lang['s703'];
				}
			}
			if($it618_members['members_certtype']==4){
				if(!$it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
					$showmessage=$it618_members_lang['s704'];
				}
				if(!$it618_members_qquser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_qquser')." WHERE it618_uid=".$_G['uid'])){
					$showmessage=$it618_members_lang['s704'];
				}
			}
			if($it618_members['members_certtype']==5){
				if(!$it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
					$showmessage=$it618_members_lang['s705'];
				}
				if(!$it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($_G['uid'])){
					$showmessage=$it618_members_lang['s705'];
				}
				if(!$it618_members_qquser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_qquser')." WHERE it618_uid=".$_G['uid'])){
					$showmessage=$it618_members_lang['s705'];
				}
			}	
		}
	}else{
		if($showmessage=='')$showmessage=$it618_members_lang['s460'];
	}
}

$it618_tel=$it618_members_user['it618_tel'];
if($it618_tel=='')$it618_tel=$it618_members_rzuser['it618_tel'];

$_G['mobiletpl'][2]='/';

include template('it618_members:showrz');
?>