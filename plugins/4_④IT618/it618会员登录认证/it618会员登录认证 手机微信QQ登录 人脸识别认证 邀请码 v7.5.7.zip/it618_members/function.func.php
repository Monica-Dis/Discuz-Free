<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_members;
$it618_members = $_G['cache']['plugin']['it618_members'];
require_once DISCUZ_ROOT.'./source/plugin/it618_members/lang.func.php';

$cache_file = DISCUZ_ROOT.'./source/plugin/it618_members/cache.php';
$tmptime=30;

if(($_G['timestamp'] - @filemtime($cache_file)) > $tmptime) {
	
	@$fp = fopen($cache_file,"w");
	fwrite($fp,$_G['timestamp']);
	fclose($fp);
	
	DB::query("delete from ".DB::table('it618_members_wxcodelogin')." where it618_time+".(3600*10)."<".$_G['timestamp']);
	DB::query("delete from ".DB::table('it618_members_wxcodebd')." where it618_time+".(3600*10)."<".$_G['timestamp']);
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/visitset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_members/config/visitset.php';
	}
	if($visitset['deldays']>0){
		DB::query("delete from ".DB::table('it618_members_visit')." where it618_time+".(3600*24*$visitset['deldays'])."<".$_G['timestamp']);
	}
}

function it618_members_pay($type,$title){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		return;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype($type);
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		$paystr=$tmpstr;
	}else{
		$paystr=$tmpstr;
	}
    
	return $paystr;
}

function it618_members_bdqq($uid,$type=''){
	global $_G,$it618_members;
	$it618_qqopenid=getcookie('it618_qqopenid');
	if($it618_qqopenid!=''){
		if(!$it618_members_qquser=C::t('#it618_members#it618_members_qquser')->fetch_by_uid($uid)){
			if(C::t('#it618_members#it618_members_qquser')->count_by_openid($it618_qqopenid)==0){
				$it618_qqdata=getcookie('it618_qqdata');
				$qqdataarr=explode("@@@",$it618_qqdata);
				$nickname=$qqdataarr[1];
				$headimgurl=$qqdataarr[2];
				$id=C::t('#it618_members#it618_members_qquser')->insert(array(
					'it618_uid' => $uid,
					'it618_qqopenid' => $it618_qqopenid,
					'it618_qqname' => $nickname,
					'it618_time' => $_G['timestamp']
				), true);
				
				if($_G['member']['avatarstatus']!=1&&$type!='reg')it618_wxsyncAvatar($uid,$headimgurl);
			}
		}
	}
}

function it618_members_faceidcardb($uid,$name,$idcard,$imgsrc){
	global $_G,$it618_members,$it618_members_lang;
	$host = "https://faceidcardb.shumaidata.com";
    $path = "/getfaceidb";
    $method = "POST";
    $appcode = $it618_members['members_rzappcode'];
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    array_push($headers, "Content-Type".":"."application/x-www-form-urlencoded; charset=UTF-8");
    $bodys = "idcard=$idcard&name=".urlencode($name)."&url=$imgsrc";
    $url = $host.$path;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
	
	$res = curl_exec($curl);
	curl_close( $curl );
	$data = json_decode($res, true);
	
//	$s = var_export($data,true);
//	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/debug.txt',"a");
//	fwrite($fp,$s.$bodys);
//	fclose($fp);
	
	$id = C::t('#it618_members#it618_members_rzapisale')->insert(array(
		'it618_uid' => $uid,
		'it618_order_no' => $data['data']['order_no'],
		'it618_score' => $data['data']['score'],
		'it618_datamsg' => it618_members_utftogbk($data['data']['msg']),
		'it618_incorrect' => $data['data']['incorrect'],
		'it618_about' => it618_members_utftogbk($data['data']['sex'].' '.$data['data']['birthday'].' '.$data['data']['address']),
		'it618_msg' => it618_members_utftogbk($data['msg']),
		'it618_time' => $_G['timestamp']
	), true);
	
	$returnarr[0]=0;
	$returnarr[1]=it618_members_utftogbk($data['data']['message']).it618_members_utftogbk($data['msg']);
	
	if($data['success']==true){
		if($data['data']['incorrect']==100){
			if($data['data']['sex']==$it618_members_lang['s832']){
				$returnarr[0]=1;
			}else{
				$returnarr[0]=2;
			}
		}
	}
	
	return $returnarr;
}

function it618_members_lifefacedb($uid,$name,$idcard,$videourl){
	global $_G,$it618_members,$it618_members_lang;
	$host = "https://lifeface.shumaidata.com";
    $path = "/getlifeface";
    $method = "POST";
    $appcode = $it618_members['members_rzappcode'];
	$complexity = $it618_members['members_vrzappcomplexity'];
	$motions = $it618_members['members_vrzappmotions'];
	
	if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$_G['uid'])){
		$it618_rzmodes=$it618_members_rzuser['it618_rzmodes'];
		if($it618_rzmodes!=''){
			$tmparr=explode('|',$it618_rzmodes);
			$complexity = $tmparr[0];
			$motions = $tmparr[1];
		}
	}
	
	if($motions==1)$motions='BLINK';
	if($motions==2)$motions='MOUTH';
	if($motions==3)$motions='NOD';
	if($motions==4)$motions='YAW';
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    array_push($headers, "Content-Type".":"."application/x-www-form-urlencoded; charset=UTF-8");
    $bodys = "complexity=$complexity&motions=$motions&idcard=$idcard&name=".urlencode($name)."&url=$videourl";
    $url = $host.$path;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
	
	$res = curl_exec($curl);
	curl_close( $curl );
	$data = json_decode($res, true);
	
//	$s = var_export($data,true);
//	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_members/debug.txt',"a");
//	fwrite($fp,$s.$bodys);
//	fclose($fp);
	
	$it618_is_life=0;
	if($data['data']['is_life']=='true'){
		$it618_is_life=1;
	}
	
	$id = C::t('#it618_members#it618_members_vrzapisale')->insert(array(
		'it618_uid' => $uid,
		'it618_order_no' => $data['data']['order_no'],
		'it618_is_life' => $it618_is_life,
		'it618_life_score' => $data['data']['life_score'],
		'it618_hack_score' => $data['data']['hack_score'],
		'it618_image_id' => $data['data']['image_id'],
		'it618_face_score' => $data['data']['face_score'],
		'it618_datamsg' => it618_members_utftogbk($data['data']['message']),
		'it618_incorrect' => $data['data']['incorrect'],
		'it618_about' => it618_members_utftogbk($data['data']['sex'].' '.$data['data']['birthday'].' '.$data['data']['address']),
		'it618_msg' => it618_members_utftogbk($data['msg']),
		'it618_complexity' => $complexity,
		'it618_motions' => $motions,
		'it618_time' => $_G['timestamp']
	), true);
	
	$returnarr[0]=0;
	$returnarr[1]=it618_members_utftogbk($data['data']['message']).it618_members_utftogbk($data['msg']);
	
	if($data['success']==true){
		if($data['data']['incorrect']==100&&$data['data']['face_score']>=0.45){
			if($data['data']['sex']==$it618_members_lang['s832']){
				$returnarr[0]=1;
			}else{
				$returnarr[0]=2;
			}
		}
	}
	
	return $returnarr;
}

function it618_members_getlogin($uid,$type){
	global $_G,$it618_members,$it618_members_lang;

	$id = C::t('#it618_members#it618_members_login')->insert(array(
		'it618_uid' => $uid,
		'it618_type' => $type,
		'it618_ip' => $_G['clientip'],
		'it618_bz' => dhtmlspecialchars($_SERVER['HTTP_USER_AGENT']),
		'it618_time' => $_G['timestamp']
	), true);
}

function it618_members_getvisit($uid,$visitset,$tid){
	global $_G,$it618_members,$it618_members_lang;

	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';		
	$url_this = $httpstr.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	
	if($tid!=''){
		$tidarr=explode(",",$tid);
		for($i=0;$i<count($tidarr);$i++){
			$forum_thread=DB::fetch_first("SELECT fid,typeid,subject,authorid,dateline FROM ".DB::table('forum_thread')." WHERE tid=".$tidarr[$i]);
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$forum_thread['authorid']);
			$deltid.='<br><font color=red>'.$it618_members_lang['s884'].$tid.'</font> '.$forum_thread['subject'].' / '.$username.' / '.date('Y-m-d H:i:s', $forum_thread['dateline']);
		}
	}

	$id = C::t('#it618_members#it618_members_visit')->insert(array(
		'it618_uid' => $uid,
		'it618_url' => $url_this,
		'it618_ip' => $_G['clientip'],
		'it618_bz' => dhtmlspecialchars($_SERVER['HTTP_USER_AGENT']).$deltid,
		'it618_time' => $_G['timestamp']
	), true);
	
	if($visitset['checktimes']>0&&$visitset['count']>0){
		if($visitset['nocheckuids']!=''){
			$tmpvisituids=explode(",",$visitset['nocheckuids']);
			if(in_array($uid, $tmpvisituids)){
				return 0;
			}
		}
		
		if($it618_members_visitcount=C::t('#it618_members#it618_members_visitcount')->fetch_by_uid($uid)){
			
			if($_G['timestamp']-$it618_members_visitcount['it618_time']>$visitset['checktimes']){
				$it618_count=0;
			}else{
				if($it618_members_visitcount['it618_bzmd5']!=md5($_SERVER['HTTP_USER_AGENT'])){
					$it618_count=$it618_members_visitcount['it618_count']+1;
				}
			}
		}else{
			$id = C::t('#it618_members#it618_members_visitcount')->insert(array(
				'it618_uid' => $uid,
				'it618_count' => 0,
				'it618_bzmd5' => md5($_SERVER['HTTP_USER_AGENT']),
				'it618_time' => $_G['timestamp']
			), true);
		}
		
		if($it618_members_visitcount['it618_count']>$visitset['count']){
			if($_G['timestamp']-$it618_members_visitcount['it618_time']>$visitset['oktimes']*60){
				$it618_count=0;
			}else{
				return ($it618_members_visitcount['it618_time']+$visitset['oktimes']*60)-$_G['timestamp'];
			}
		}
		
		C::t('#it618_members#it618_members_visitcount')->update($it618_members_visitcount['id'],array(
			'it618_count' => $it618_count,
			'it618_bzmd5' => md5($_SERVER['HTTP_USER_AGENT']),
			'it618_time' => $_G['timestamp']
		));
	}
	
	return 0;
}

function it618_members_sendmessage($type,$id,$type1=''){
	global $_G,$it618_members,$it618_members_lang;
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	$tmpurl=it618_members_gettidurl($id);
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='post_admin'&&$it618_body_post_admin_isok==1){
				
				if(!$forum_thread=DB::fetch_first("SELECT fid,typeid,subject,authorid,dateline FROM ".DB::table('forum_thread')." WHERE tid=".$id)){
					return;
				}
				
				$fid=$forum_thread['fid'];
				$typeid=$forum_thread['typeid'];
				$forumname=DB::result_first("select name from ".DB::table('forum_forum')." where fid=$fid");
				if($typeid>0)$classname=DB::result_first("select name from ".DB::table('forum_threadclass')." where fid=$fid and typeid=$typeid");
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_post_admin_tplid_wxsms;
				$body_wxsms=$it618_body_post_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_members_getusername($forum_thread['authorid']),$tmpvalue);
						$tmpvalue=str_replace("{name}",$forum_thread['subject'],$tmpvalue);
						$tmpvalue=str_replace("{forumname}",$forumname,$tmpvalue);
						$tmpvalue=str_replace("{classname}",$classname,$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $forum_thread['dateline']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
			}
			
			if($type=='posthf_admin'&&$it618_body_posthf_admin_isok==1){
				
				if(!$forum_thread=DB::fetch_first("SELECT fid,typeid,subject,authorid,dateline FROM ".DB::table('forum_thread')." WHERE tid=".$id)){
					return;
				}
				if(!$forum_post=DB::fetch_first("SELECT subject,authorid,dateline FROM ".DB::table('forum_post')." WHERE pid=".$type1)){
					return;
				}
				
				$fid=$forum_thread['fid'];
				$typeid=$forum_thread['typeid'];
				$forumname=DB::result_first("select name from ".DB::table('forum_forum')." where fid=$fid");
				if($typeid>0)$classname=DB::result_first("select name from ".DB::table('forum_threadclass')." where fid=$fid and typeid=$typeid");
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_posthf_admin_tplid_wxsms;
				$body_wxsms=$it618_body_posthf_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_members_getusername($forum_post['authorid']),$tmpvalue);
						$tmpvalue=str_replace("{name}",$forum_thread['subject'],$tmpvalue);
						$tmpvalue=str_replace("{forumname}",$forumname,$tmpvalue);
						$tmpvalue=str_replace("{classname}",$classname,$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $forum_post['dateline']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
			}
		}
		
		if($type=='post_postuser'&&$it618_body_post_postuser_isok==1){
			$uid=$_G['uid'];
			
			$count=C::t('#it618_members#it618_members_user_wxsms')->count_by_type_uid_ok($type,$uid);
			if($count>0){
				if(!$forum_thread=DB::fetch_first("SELECT fid,typeid,subject,authorid,dateline FROM ".DB::table('forum_thread')." WHERE tid=".$id)){
					return;
				}
				
				$fid=$forum_thread['fid'];
				$typeid=$forum_thread['typeid'];
				$forumname=DB::result_first("select name from ".DB::table('forum_forum')." where fid=$fid");
				if($typeid>0)$classname=DB::result_first("select name from ".DB::table('forum_threadclass')." where fid=$fid and typeid=$typeid");
				
				$tplid_wxsms=$it618_body_post_postuser_tplid_wxsms;
				$body_wxsms=$it618_body_post_postuser_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{name}",$forum_thread['subject'],$tmpvalue);
						$tmpvalue=str_replace("{forumname}",$forumname,$tmpvalue);
						$tmpvalue=str_replace("{classname}",$classname,$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $forum_thread['dateline']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
			}
			
		}
		
		if($type=='posthf_postuser'&&$it618_body_posthf_postuser_isok==1){
			if(!$forum_thread=DB::fetch_first("SELECT fid,typeid,subject,authorid,dateline FROM ".DB::table('forum_thread')." WHERE tid=".$id)){
				return;
			}
			if(!$forum_post=DB::fetch_first("SELECT subject,authorid,dateline FROM ".DB::table('forum_post')." WHERE pid=".$type1)){
				return;
			}
			$uid=$forum_thread['authorid'];
			
			$fid=$forum_thread['fid'];
			$typeid=$forum_thread['typeid'];
			$forumname=DB::result_first("select name from ".DB::table('forum_forum')." where fid=$fid");
			if($typeid>0)$classname=DB::result_first("select name from ".DB::table('forum_threadclass')." where fid=$fid and typeid=$typeid");
			
			$count=C::t('#it618_members#it618_members_user_wxsms')->count_by_type_uid_ok($type,$uid);
			if($count>0){
				$tplid_wxsms=$it618_body_posthf_postuser_tplid_wxsms;
				$body_wxsms=$it618_body_posthf_postuser_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_members_getusername($forum_post['authorid']),$tmpvalue);
						$tmpvalue=str_replace("{name}",$forum_thread['subject'],$tmpvalue);
						$tmpvalue=str_replace("{forumname}",$forumname,$tmpvalue);
						$tmpvalue=str_replace("{classname}",$classname,$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $forum_post['dateline']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
			}
			
		}
		
		if($type=='posthf_posthfuser'&&$it618_body_posthf_posthfuser_isok==1){	
			$uid=$_G['uid'];
			
			$count=C::t('#it618_members#it618_members_user_wxsms')->count_by_type_uid_ok($type,$uid);
			if($count>0){
				if(!$forum_thread=DB::fetch_first("SELECT fid,typeid,subject,authorid,dateline FROM ".DB::table('forum_thread')." WHERE tid=".$id)){
					return;
				}
				if(!$forum_post=DB::fetch_first("SELECT subject,authorid,dateline FROM ".DB::table('forum_post')." WHERE pid=".$type1)){
					return;
				}
				
				$fid=$forum_thread['fid'];
				$typeid=$forum_thread['typeid'];
				$forumname=DB::result_first("select name from ".DB::table('forum_forum')." where fid=$fid");
				if($typeid>0)$classname=DB::result_first("select name from ".DB::table('forum_threadclass')." where fid=$fid and typeid=$typeid");
				
				$tplid_wxsms=$it618_body_posthf_posthfuser_tplid_wxsms;
				$body_wxsms=$it618_body_posthf_posthfuser_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{name}",$forum_thread['subject'],$tmpvalue);
						$tmpvalue=str_replace("{forumname}",$forumname,$tmpvalue);
						$tmpvalue=str_replace("{classname}",$classname,$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $forum_post['dateline']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
			}
			
		}

		if(count($param_wxsms)>0&&$uid!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
			$tmparr=explode(",",$uid);
			for($i=0;$i<count($tmparr);$i++){
				sendSMS_WXAPI('it618_members',$tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
			}
		}
	}
}

function it618_members_sendmessageapi($type,$id,$type1=''){
	global $_G,$it618_members,$it618_members_lang;
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/messageapi.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/messageapi.php';
	
	$tmpurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home");
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='rzsq_admin'&&$it618_body_rzsq_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_members_rzuser=C::t('#it618_members#it618_members_rzuser')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_rzsq_admin_tplid_wxsms;
				$body_wxsms=$it618_body_rzsq_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_members_getusername($it618_members_rzuser['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_rzsq_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_members_getusername($it618_members_rzuser['it618_uid']),$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rzsq_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_members_getusername($it618_members_rzuser['it618_uid']).'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='qyrzsq_admin'&&$it618_body_qyrzsq_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_members_qyrz=C::t('#it618_members#it618_members_qyrz')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_qyrzsq_admin_tplid_wxsms;
				$body_wxsms=$it618_body_qyrzsq_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_members_getusername($it618_members_qyrz['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_qyrzsq_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_members_getusername($it618_members_qyrz['it618_uid']),$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_qyrzsq_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_members_getusername($it618_members_qyrz['it618_uid']).'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='rzpass_user'&&$it618_body_rzpass_user_isok==1){
			$it618_members_rzuser=C::t('#it618_members#it618_members_rzuser')->fetch_by_id($id);
			
			$uid=$it618_members_rzuser['it618_uid'];
			$tel=$it618_members_rzuser['it618_tel'];
			
			$tplid_wxsms=$it618_body_rzpass_user_tplid_wxsms;
			$body_wxsms=$it618_body_rzpass_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_members_getusername($it618_members_rzuser['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
				
			$Body=$it618_body_rzpass_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_members_getusername($it618_members_rzuser['it618_uid']),$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_rzpass_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_members_getusername($it618_members_rzuser['it618_uid']).'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='rznopass_user'&&$it618_body_rznopass_user_isok==1){
			$it618_members_rzuser=C::t('#it618_members#it618_members_rzuser')->fetch_by_id($id);
			
			$uid=$it618_members_rzuser['it618_uid'];
			$tel=$it618_members_rzuser['it618_tel'];
			
			$tplid_wxsms=$it618_body_rznopass_user_tplid_wxsms;
			$body_wxsms=$it618_body_rznopass_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_members_getusername($it618_members_rzuser['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
				
			$Body=$it618_body_rznopass_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_members_getusername($it618_members_rzuser['it618_uid']),$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_rznopass_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_members_getusername($it618_members_rzuser['it618_uid']).'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_members_rzuser['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='qyrzpass_user'&&$it618_body_qyrzpass_user_isok==1){
			$it618_members_qyrz=C::t('#it618_members#it618_members_qyrz')->fetch_by_id($id);
			
			$uid=$it618_members_qyrz['it618_uid'];
			$tel=$it618_members_qyrz['it618_tel'];
			
			$tplid_wxsms=$it618_body_qyrzpass_user_tplid_wxsms;
			$body_wxsms=$it618_body_qyrzpass_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_members_getusername($it618_members_qyrz['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
				
			$Body=$it618_body_qyrzpass_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_members_getusername($it618_members_qyrz['it618_uid']),$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_qyrzpass_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_members_getusername($it618_members_qyrz['it618_uid']).'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='qyrznopass_user'&&$it618_body_qyrznopass_user_isok==1){
			$it618_members_qyrz=C::t('#it618_members#it618_members_qyrz')->fetch_by_id($id);
			
			$uid=$it618_members_qyrz['it618_uid'];
			$tel=$it618_members_qyrz['it618_tel'];
			
			$tplid_wxsms=$it618_body_qyrznopass_user_tplid_wxsms;
			$body_wxsms=$it618_body_qyrznopass_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_members_getusername($it618_members_qyrz['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_members_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_qyrznopass_user;		

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_members_getusername($it618_members_qyrz['it618_uid']),$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_qyrznopass_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_members_getusername($it618_members_qyrz['it618_uid']).'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"etime":"'.date('Y-m-d H:i:s', $it618_members_qyrz['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/messageapi.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($wxsms=='true')return 1;
			
			if($tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_members_lang['s1860'].$it618_smsbaosign.$it618_members_lang['s1861'];
					$dxsms=sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					$dxsms=sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
			
			if($dxsms=="0"||$dxsms=="ok")return 2;
			return 0;

		}
	}
}

function it618_members_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_members']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/rewrite.php';
	
	if($pagetype=='members_reg'){
		return $members_reg.$urltype.$uri;
	}
	
	if($pagetype=='members_login'){
		return $members_login.$urltype.$uri;
	}
	
	if($pagetype=='members_uhome'){
		return $members_uhome.$urltype.$uri;
	}
	
}

function it618_members_gettidurl($tid){
	global $_G;
	if($_G['cache']['plugin']['it618_members']['rewriteurl']==1){
		return 'thread-'.$tid.'-1-1.html';
	}else{
		return 'forum.php?mod=viewthread&tid='.$tid;
	}
}

function sendmessage_yqmsale($saleid){
	global $_G,$yqcodeset,$_SERVER,$it618_members,$it618_members_lang;
	if($yqcodeset['istel']!=1)return;
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
	
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/message.php';
	
	$members_sign=$it618_body_yqmsale_sign;
	$members_tplid=$it618_body_yqmsale_tplid;
	$members_body=$it618_body_yqmsale;
	$it618_type=6;
	$it618_jktype=$it618_type_yqmsale;
	
	$it618_members_yqcode_sale=C::t('#it618_members#it618_members_yqcode_sale')->fetch_by_id($saleid);
	
	$it618_tel=$it618_members_yqcode_sale['it618_tel'];
	
	$members_body=str_replace('${','{',$members_body);
	if($it618_jktype=='smsbao'){
		$members_body=str_replace('{tel}',$it618_tel,$members_body);
		$members_body=str_replace('{price}',$it618_members_yqcode_sale['it618_price'],$members_body);
		$members_body=str_replace('{product}',$members_sign,$members_body);
		$members_body=str_replace('{code}',$it618_members_yqcode_sale['it618_code'],$members_body);
		$members_body=str_replace('{time}',date('Y-m-d H:i:s', $_G['timestamp']),$members_body);
		$smsstr=it618_members_sendSMS($it618_tel,$it618_members_lang['s149'].$members_sign.$it618_members_lang['s150'].$members_body);
	}else{
		$tmparr=explode("{tel}",$members_body);
		if(count($tmparr)>1)$param.='"tel":"'.it618_members_gbktoutf1($it618_tel).'",';
		
		$tmparr=explode("{price}",$members_body);
		if(count($tmparr)>1)$param.='"price":"'.$it618_members_yqcode_sale['it618_price'].'",';
		
		$tmparr=explode("{product}",$members_body);
		if(count($tmparr)>1)$param.='"product":"'.it618_members_gbktoutf1($members_sign).'",';
		
		$tmparr=explode("{code}",$members_body);
		if(count($tmparr)>1)$param.='"code":"'.$it618_members_yqcode_sale['it618_code'].'",';
		
		$tmparr=explode("{time}",$members_body);
		if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
		
		if($param!=''){
			$param.='@';
			$param=str_replace(",@","",$param);
		}
		
		if($it618_jktype=='alisms'){
			$smsstr=it618_members_sendsms_ali($it618_tel,$members_sign,$members_tplid,$param);
		}else{
			$smsstr=it618_members_sendsms_alidayu($it618_tel,$members_sign,$members_tplid,$param);
		}
	}
	
	$id = C::t('#it618_members#it618_members_sms')->insert(array(
		  'it618_tel' => $it618_tel,
		  'it618_jktype' => $it618_jktype,
		  'it618_type' => $it618_type,
		  'it618_ip' => $_G['clientip'],
		  'it618_bz' => dhtmlspecialchars($_SERVER['HTTP_USER_AGENT']),
		  'it618_time' => $_G['timestamp']
	 ), true);
		 
	if($smsstr=='true'){
		 C::t('#it618_members#it618_members_sms')->update($id,array(
			'it618_isok' => 1,
		 ));
	}else{
		C::t('#it618_members#it618_members_sms')->update($id,array(
			'it618_okbz' => $smsstr,
			'it618_isok' => 0
		 ));
	}
}

function it618_register($username, $password, $email='', $type='') {
	global $_G,$it618_members,$it618_members_lang;
	
	if($email=='')$email = strtolower(random(10)).'@null.null';
	
	loaducenter();
	$groupid = !$groupid ? $_G['setting']['newusergroupid'] : $groupid;

	$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';
	
	if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
		if($type!=''){
			$tmpusername = $type.'_'.random(5);
			$username=$tmpusername;
		}else{
			return $it618_members_lang['s289'];
		}
	}

	if($type==''){
		$usernamelen = dstrlen($username);
		if($usernamelen < 3) {
			return $it618_members_lang['s287'];
		}
		if($usernamelen > 16) {
			return $it618_members_lang['s288'];
		}
	
		loadcache('ipctrl');
		if($_G['cache']['ipctrl']['ipregctrl']) {
			foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
				if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
					$ctrlip = $ctrlip.'%';
					$_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
					break;
				} else {
					$ctrlip = $_G['clientip'];
				}
			}
		} else {
			$ctrlip = $_G['clientip'];
		}

		if($_G['setting']['regctrl']) {
			if(C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp']-$_G['setting']['regctrl']*3600)) {
				return $it618_members_lang['s290'].$_G['setting']['regctrl'].$it618_members_lang['s291'];
			}
		}

		$setregip = null;
		if($_G['setting']['regfloodctrl']) {
			$regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
			if($regip) {
				if($regip['count'] >= $_G['setting']['regfloodctrl']) {
					return $it618_members_lang['s292'].$_G['setting']['regfloodctrl'].$it618_members_lang['s293'];
				} else {
					$setregip = 1;
				}
			} else {
				$setregip = 2;
			}
		}

		if($setregip !== null) {
			if($setregip == 1) {
				C::t('common_regip')->update_count_by_ip($_G['clientip']);
			} else {
				C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
			}
		}
	}

	$uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
	
	if($type!=''&&$uid<0){
		$tmpusername = $type.'_'.random(5);
		$uid = uc_user_register(addslashes($tmpusername), $password, $email, '', '', $_G['clientip']);
	}
		
	if($uid <= 0) {
		if($uid == -1) {
			return $it618_members_lang['s294'];
		} elseif($uid == -2) {
			return $it618_members_lang['s295'];
		} elseif($uid == -3) {
			return $it618_members_lang['s296'];
		} elseif($uid == -4) {
			return $it618_members_lang['s297'];
		} elseif($uid == -5) {
			return $it618_members_lang['s298'];
		} elseif($uid == -6) {
			return $it618_members_lang['s299'];
		} else {
			return $it618_members_lang['s300'];
		}
	}

	$init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
	C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

	if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
		C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
		if($_G['setting']['regctrl']) {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
		}
	}

	if($_G['setting']['regverify'] == 2) {
		C::t('common_member_validate')->insert(array(
			'uid' => $uid,
			'submitdate' => $_G['timestamp'],
			'moddate' => 0,
			'admin' => '',
			'submittimes' => 1,
			'status' => 0,
			'message' => '',
			'remark' => '',
		), false, true);
		manage_addnotify('verifyuser');
	}

	require_once libfile('function/member');

	setloginstatus(array(
		'uid' => $uid,
		'username' => $username,
		'password' => $password,
		'groupid' => $groupid,
	), 0);
	
	include_once libfile('function/stat');
	updatestat('register');
	
	require_once libfile('cache/userstats', 'function');
	build_cache_userstats();

	return 'okit618_split'.$uid.'it618_split'.$username;
}

function it618_members_delsalework(){
	DB::query("delete from ".DB::table('it618_members_salework'));
}

function it618_members_deleditwork(){
	DB::query("delete from ".DB::table('it618_members_editwork'));
}

function getteldata($id,$tel){
	$tmpstr=dfsockopen('https://tcc.taobao.com/cc/json/mobile_tel_segment.htm?tel='.$tel);
	$tmpstr=it618_members_utftogbk($tmpstr);
	
	$tmparr=explode("',",$tmpstr);
	for($i=0;$i<count($tmparr);$i++){
		$tmparr1=explode("province:'",$tmparr[$i]);
		if(count($tmparr1)>1){
			$it618_province=$tmparr1[1];
		}
		$tmparr1=explode("catName:'",$tmparr[$i]);
		if(count($tmparr1)>1){
			$it618_catname=$tmparr1[1];
		}
	}
	
	C::t('#it618_members#it618_members_user')->update($id,array(
		'it618_province' => $it618_province,
		'it618_catname' => $it618_catname
	));
}

function it618_members_get_contents($str){
	return dfsockopen($str);
}

function members_qrcode($url){
	include DISCUZ_ROOT.'./source/plugin/it618_members/phpqrcode.php';
	
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/it618_members/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function it618_members_imagetosmall($imagepath,$max){
	$file_ext=strtolower(substr($imagepath,strrpos($imagepath, '.')+1)); 
	
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($imagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($imagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($imagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($imagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	//�������ֵ�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
	if($w > $max){ 
	   $w=$max;
	   $h=$h*($max/$size_src['0']); 
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if(file_exists($imagepath)){
		$result=unlink($imagepath);
	}
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$imagepath); 
	if($file_ext=='png')imagepng($image,$imagepath); 
	if($file_ext=='gif')imagegif($image,$imagepath); 
	@chmod($imagepath, 0644);
	
	//������Դ 
	imagedestroy($image);  
}

function it618_members_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_members_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_union']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_members_getusername($uid){
	if($uid=='')return;
	return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=$uid");
}

function it618_members_getsmsstr($strtmp,$length){
	if($length>0){
		$tmpstr = "";
		$strlen = $length;
		for($i = 0; $i < $strlen; $i++){
			if(ord(substr($strtmp, $i, 1)) > 0xa0) {
				if(CHARSET=='gbk'){
					$tmpstr .= substr($strtmp, $i, 2);
					$i++;
				}else{
					$tmpstr.=substr($str,$i,3);
					$i+=2;
				}
			} else {
				$tmpstr .= substr($strtmp, $i, 1);
			}
			
		}
		return $tmpstr; 
	}
	return $strtmp;
}

function it618_members_gbktoutf1($strcontent){	
	if(CHARSET=='gbk'){
		return iconv('gbk','utf-8',$strcontent);
	}else{
		return $strcontent;
	}
}

function it618_members_utftogbk($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_members_gbktoutf($strcontent);
	}
}

function it618_members_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function members_is_mobile(){ 
	global $_GET;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>