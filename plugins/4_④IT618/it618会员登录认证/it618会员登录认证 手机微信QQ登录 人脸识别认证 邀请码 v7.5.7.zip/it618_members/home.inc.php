<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_G['uid']<=0){
	dheader("location:".$_G['siteurl'].'member.php?mod=logging&action=login');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

$navtitle = $it618_members_lang['t64'];

$menuusername=$_G['username'];
$u_avatarimg=it618_members_discuz_uc_avatar($_G['uid'],'middle').'&random='.rand();

$groupid=$_G['groupid'];
if($groupid>0)$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/qqjk.php';
}

$homebgcolors=explode("|",$it618_members['members_homebgcolors']);

$wap=0;
if(members_is_mobile()){
	$wap=1;
	$iswx=1;
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;
	$islogout=1;
	
	if($iswx==1&&$wxjk_mode==1){
		$islogout=0;
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_members_iconav')." where it618_order<>0 ORDER BY it618_order");
	while($it618_members_iconav = DB::fetch($query)) {
		$it618_title=$it618_members_iconav['it618_title'];
		
		if($it618_title!='br'){
			if($it618_members_iconav['it618_color']!=''){
				$it618_title='<font color="'.$it618_members_iconav['it618_color'].'">'.$it618_title.'</font>';
			}
			
			$it618_members_iconav['it618_url']=str_replace("{uid}",$_G['uid'],$it618_members_iconav['it618_url']);
		
			$str_iconav.='<tr class="bodytr" onClick="location.href=\''.$it618_members_iconav['it618_url'].'\'"><td class="tdico"><img src="'.$it618_members_iconav['it618_img'].'" width="26"></td><td class="bodytd">'.$it618_title.'<img src="source/plugin/it618_members/images/uc_right.png"><span>'.$it618_members_iconav['it618_about'].'</span></td></tr>';
		}else{
			$str_iconav.='<tr class="brtr"><td colspan="2"></td></tr>';
		}
	}
	
	if($IsGroup==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
		$it618_group_wapad=it618_group_getad($_GET['id'],1);
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
}else{
	$uhomeurl=$_G['siteurl'].it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home");
	$qrcodesrc='plugin.php?id=it618_members:wxcode&url='.urlencode($uhomeurl);	
}

if($it618_members['members_telbdmode']==1||$it618_members['members_telbdmode']==2){
	$img_tel='0';
	$bdtitle_tel=$it618_members_lang['s318'];
	if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
		$bdtitle_tel=$it618_members_lang['s317'].$it618_members_user['it618_tel'];
		$img_tel='';
	}
}

if($wxjk_mode>0&&$wxjk_mode<=2){
	$img_wx='0';
	$bdtitle_wx=$it618_members_lang['s653'];
	if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid_auth($_G['uid'])){
		$bdtitle_wx=$it618_members_lang['s652'].$it618_members_wxuser['it618_wxname'];
		$img_wx='';
		
		$get_wxsubscribe=getcookie('get_wxsubscribe');
		if($get_wxsubscribe!=1){
			dsetcookie('get_wxsubscribe','1',3600);
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
			
			$openid=$it618_members_wxuser['it618_wxopenid'];
			$appid=trim($wxjk_appid);
			$appsecret=trim($wxjk_appsecret);
			
			$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
			$subscribe=$data['subscribe'];
			$subscribe_time=$data['subscribe_time'];
			
			C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
				'it618_wxok' => $subscribe,
				'it618_wxoktime' => $subscribe_time,
				'it618_checktime' => $_G['timestamp']
			));
		}else{
			$subscribe=$it618_members_wxuser['it618_wxok'];	
		}
	}
}

if($qqjk_isok==1){
	$img_qq='0';
	$bdtitle_qq=$it618_members_lang['s655'];
	if($it618_members_qquser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_qquser')." WHERE it618_uid=".$_G['uid'])){
		$bdtitle_qq=$it618_members_lang['s654'].$it618_members_qquser['it618_qqname'];
		$img_qq='';
		$alertstr=$it618_members_lang['s656'].date('Y-m-d H:i:s', $it618_members_qquser['it618_time']);
		$qqclickstr="qq('alert')";
	}else{
		$qqclickstr="qq('')";
		if(strpos($_SERVER['HTTP_HOST'],'localhost')){
			$qqclickstr="qq('parent')";
		}
	}
}

if($it618_members['members_certtype']>1){
	$isrz=1;
	$img_rz='0';
	$rztitle=$it618_members_lang['s448'];
	if($it618_members_rzuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_rzuser')." WHERE it618_uid=".$_G['uid'])){
		if($it618_members_rzuser['it618_state']==1){
			$rztitle=$it618_members_lang['s449'].$it618_members_rzuser['it618_name'];
			$img_rz='';
		}else if($it618_members_rzuser['it618_state']==2){
			$rztitle=$it618_members_lang['s461'].$it618_members_rzuser['it618_name'];
		}else{
			$rztitle=$it618_members_lang['s630'].$it618_members_rzuser['it618_name'];
		}
	}
}

if($it618_members['members_qycerttype']>1){
	$isqyrz=1;
	$img_qyrz='0';
	$qyrztitle=$it618_members_lang['s710'];
	if($it618_members_qyrz=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_qyrz')." WHERE it618_uid=".$_G['uid'])){
		if($it618_members_qyrz['it618_state']==1){
			$qyrztitle=$it618_members_lang['s449'].$it618_members_qyrz['it618_name'];
			$img_qyrz='';
		}else if($it618_members_qyrz['it618_state']==2){
			$qyrztitle=$it618_members_lang['s461'].$it618_members_qyrz['it618_name'];
		}else{
			$qyrztitle=$it618_members_lang['s630'].$it618_members_qyrz['it618_name'];
		}
	}
}

if($IsChat==1){
	$query = DB::query("SELECT * FROM ".DB::table('it618_chat_onepage')." where it618_state=1 ORDER BY it618_order");
	while($it618_chat_onepage = DB::fetch($query)) {
		$it618_topic='onepage_'.$it618_chat_onepage['id'];
		$chatmancount=0;
		if($it618_chat_topic=C::t('#it618_chat#it618_chat_topic')->fetch_by_it618_topic($it618_topic)){
			$chatmancount=C::t('#it618_chat#it618_chat_user_online')->count_by_it618_topicid_online($it618_chat_topic['id']);
		}
		$str_qunchat.='<tr class="bodytr" onClick="it618_showsms(\''.$it618_chat_onepage['it618_name'].'\',\'plugin.php?id=it618_chat:chat&type=onepage&typeid='.$it618_chat_onepage['id'].'\')"><td class="tdico"><img src="source/plugin/it618_members/images/qunchat.png" width="26"></td><td class="bodytd">'.$it618_chat_onepage['it618_name'].'
<img src="source/plugin/it618_members/images/uc_right.png"><span>'.$chatmancount.$it618_members_lang['s1056'].'</span></td></tr>';
	}
}

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_myvip=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$viplogo='source/plugin/it618_credits/images/group.png';
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
	$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	$viplogo='source/plugin/it618_group/images/group.png';
}

if($IsUnion==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxmessage.php';
}

if($it618_isok==1&&($it618_body_post_postuser_isok==1||$it618_body_posthf_postuser_isok==1||$it618_body_posthf_posthfuser_isok==1)){
	$iswxsms=1;
}

$_G['mobiletpl'][2]='/';

include template('it618_members:layer');
include template('it618_members:home');
?>