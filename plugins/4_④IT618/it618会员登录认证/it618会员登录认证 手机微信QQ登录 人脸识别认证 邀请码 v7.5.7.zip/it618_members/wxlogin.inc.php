<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(isset($_GET['test'])){
	echo 'This url is ok!';
	exit;
}

global $_G,$it618_members;
require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/appjk.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_members/config/appjk.php';
}

$appid=trim($wxjk_appid);
$appsecret=trim($wxjk_appsecret);

$it618_preurl=getcookie('it618_preurl');
if($it618_preurl=='')$it618_preurl=$_G['siteurl'];

if((isset($_GET['code'])&&$_GET['state']==FORMHASH)){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/wxlogin.func.php';
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
	
	$code=$_GET['code'];
	
	$data = get_wxuserdata($appid,$appsecret,$code,DISCUZ_ROOT);
	if(!is_array($data)){
		echo $data;exit;
	}
	
	$openid=$data['openid'];
	dsetcookie('it618_openid',$openid,31536000);
	dsetcookie(md5('it618_openid'.$appsecret.$openid),$openid,31536000);
	
	$nickname=it618_members_utftogbk(it618_wxclear($data['nickname']));
	$headimgurl=str_replace('\/','/',$data['headimgurl']);
	$unionid=$data['unionid'];
	
	$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
	if(!is_array($data)){
		echo $data;exit;
	}
	$subscribe=$data['subscribe'];
	$subscribe_time=$data['subscribe_time'];
	
	dsetcookie('it618_wxdata',$openid.'@@@'.$nickname.'@@@'.$headimgurl.'@@@'.$subscribe.'@@@'.$subscribe_time.'@@@'.$unionid,31536000);
	
	if($unionid!=''){
		if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_unionid($unionid)){
			if($it618_members_wxuser['it618_wxopenid']!=$openid){
				C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
					'it618_wxopenid' => $openid,
					'it618_authcount' => $it618_members_wxuser['it618_authcount']+1,
					'it618_wxname' => $nickname,
					'it618_wxok' => $subscribe,
					'it618_wxoktime' => $subscribe_time,
					'it618_checktime' => $_G['timestamp'],
				));
				
				sleep(1);
			}
			
			if($appjk_mag_isok==1){
				if(!$user_weixin_relations=DB::fetch_first("SELECT * FROM ".DB::table('user_weixin_relations')." WHERE unionid='".$unionid."'")){
					DB::query("insert into ".DB::table('user_weixin_relations')." (unionid,userid,create_time) values ('".$unionid."',".$it618_members_wxuser['it618_uid'].",".$_G['timestamp'].")");
				}
			}
		}else{
			if($appjk_mag_isok==1){
				$user_weixin_relations=DB::fetch_first("SELECT * FROM ".DB::table('user_weixin_relations')." WHERE unionid='".$unionid."'");
				sleep(1);
				
				if($user_weixin_relations['userid']>0){
					$id=C::t('#it618_members#it618_members_wxuser')->insert(array(
						'it618_uid' => $user_weixin_relations['userid'],
						'it618_wxunionid' => $unionid,
						'it618_wxopenid' => $openid,
						'it618_authcount' => 1,
						'it618_wxname' => $nickname,
						'it618_wxok' => $subscribe,
						'it618_wxoktime' => $subscribe_time,
						'it618_checktime' => $_G['timestamp'],
					), true);
					
					sleep(1);
				}
			}
		}
	}

	if($_G['uid']>0){
		if(!$it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_uid($_G['uid'])){
			
			$insertwork=getcookie('insertwork');
			if(!$it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_openid($openid)&&$insertwork!='1'){
				dsetcookie('insertwork','1',10);
				
				$id=C::t('#it618_members#it618_members_wxuser')->insert(array(
					'it618_uid' => $_G['uid'],
					'it618_wxopenid' => $openid,
					'it618_wxunionid' => $unionid,
					'it618_authcount' => 1,
					'it618_wxname' => $nickname,
					'it618_wxok' => $subscribe,
					'it618_wxoktime' => $subscribe_time,
					'it618_checktime' => $_G['timestamp'],
					'it618_time' => $_G['timestamp']
				), true);
				
				if($appjk_mag_isok==1){
					if(!$user_weixin_relations=DB::fetch_first("SELECT * FROM ".DB::table('user_weixin_relations')." WHERE unionid='".$unionid."'")){
						DB::query("insert into ".DB::table('user_weixin_relations')." (unionid,userid,create_time) values ('".$unionid."',".$_G['uid'].",".$_G['timestamp'].")");
					}
				}
				
				dsetcookie('insertwork','0',10);
			}
		}else{
			C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
				'it618_wxopenid' => $openid,
				'it618_authcount' => $it618_members_wxuser['it618_authcount']+1,
				'it618_wxname' => $nickname,
				'it618_wxok' => $subscribe,
				'it618_wxoktime' => $subscribe_time,
				'it618_checktime' => $_G['timestamp'],
			));
			if($it618_members_wxuser['it618_wxunionid']==''&&$unionid!=''){
				C::t('#it618_members#it618_members_wxuser')->update($it618_members_wxuser['id'],array(
					'it618_wxunionid' => $unionid
				));
			}
			
			if($_G['member']['avatarstatus']!=1){
				loaducenter();
				it618_wxsyncAvatar($_G['uid'],$headimgurl);
			}
		}
		
		$uid=$_G['uid'];
	}else{
		if($it618_members_wxuser=C::t('#it618_members#it618_members_wxuser')->fetch_by_openid($openid)){
			
			require_once libfile('function/member');
			$member=getuserbyuid($it618_members_wxuser['it618_uid'], 1);
			
			setloginstatus($member, 1296000);
			it618_members_getlogin($_G['uid'],'wx');
			dheader("location:$it618_preurl");
		}
		
		if($wxjk_mode==1||($wxjk_mode==2&&$wxjk_iswxregtel!=1&&($yqcodeset['isok']==0||($yqcodeset['isok']==1&&$yqcodeset['iswxqq']==0)))){
			
			$insertwork=getcookie('insertwork');
			if($insertwork!='1'){
				if(C::t('#it618_members#it618_members_wxuser')->count_by_openid($openid)==0){
					
					dsetcookie('insertwork','1',10);
					$newname=it618_wxgetnewname($nickname);
					
					$n=1;
					$chars = '012345678901234567890123456789';
					while($n<=8){
						$password.=substr($chars,mt_rand(0,strlen($chars)-1),1);
						$n=$n+1;
					}
					
					$tmpstr=it618_wxregister($newname,$password);
					
					$tmparr=explode("it618_split",$tmpstr);
					if($tmparr[0]=='ok'){
						$reguid=$tmparr[1];
	
						$id=C::t('#it618_members#it618_members_wxuser')->insert(array(
							'it618_uid' => $reguid,
							'it618_wxopenid' => $openid,
							'it618_wxunionid' => $unionid,
							'it618_authcount' => 1,
							'it618_wxname' => $nickname,
							'it618_wxok' => $subscribe,
							'it618_wxoktime' => $subscribe_time,
							'it618_checktime' => $_G['timestamp'],
							'it618_isreg' => 1,
							'it618_time' => $_G['timestamp']
						), true);
						
						if($appjk_mag_isok==1){
							if(!$user_weixin_relations=DB::fetch_first("SELECT * FROM ".DB::table('user_weixin_relations')." WHERE unionid='".$unionid."'")){
								DB::query("insert into ".DB::table('user_weixin_relations')." (unionid,userid,create_time) values ('".$unionid."',".$reguid.",".$_G['timestamp'].")");
							}
						}
						
						dsetcookie('insertwork','0',10);
						
						it618_wxsyncAvatar($reguid,$headimgurl);
						
						$uid=$reguid;
						
						if($it618_members['members_regtourl']!=''){
							$tmparr=explode("|",$it618_members['members_regtourl']);
							$it618_preurl=$tmparr[1];
						}else{
							if($it618_members['members_tourl']!=''){
								$tmparr=explode("|",$it618_members['members_tourl']);
								$it618_preurl=$tmparr[1];
							}
						}
					}
					
				}
			}
		}
	}
	
	if($_G['uid']>0)$it618_preurl=str_replace("it618wxlogin","login_wx",$it618_preurl);
	
	dheader("location:$it618_preurl");
	
}else{
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	
	$redirect_uri=urlencode($url_this);
	$scope='snsapi_userinfo';
	//$scope='snsapi_base';
	$state=FORMHASH;
	
	if($wxjk_getcodeurl!=''){
		dheader("location:$wxjk_getcodeurl/getweixincode.html?appid=$appid&scope=$scope&state=$state&redirect_uri=$redirect_uri");
	}else{
		dheader("location:https://open.weixin.qq.com/connect/oauth2/authorize?appid=$appid&redirect_uri=$redirect_uri&response_type=code&scope=$scope&state=$state#wechat_redirect");
	}
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>