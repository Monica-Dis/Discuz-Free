<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_header.func.php';

$it618_waimai_bank = DB::fetch_first("SELECT * FROM ".DB::table('it618_waimai_bank')." where it618_shopid=".$ShopId);
if(submitcheck('it618submit')){
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_waimai_bank')." where it618_shopid=".$ShopId);
	if($count>0){
		C::t('#it618_waimai#it618_waimai_bank')->update($it618_waimai_bank['id'],array(
				'it618_name' => dhtmlspecialchars($_GET["it618_name"]),
				'it618_bankname' => dhtmlspecialchars($_GET["it618_bankname"]),
				'it618_bankid' => dhtmlspecialchars($_GET["it618_bankid"]),
				'it618_bankaddr' => dhtmlspecialchars($_GET["it618_bankaddr"]),
				'it618_alipayname' => dhtmlspecialchars($_GET["it618_alipayname"]),
				'it618_alipay' => dhtmlspecialchars($_GET["it618_alipay"]),
				'it618_wxname' => dhtmlspecialchars($_GET["it618_wxname"]),
				'it618_wx' => dhtmlspecialchars($_GET["it618_wx"])
		 ));
	}else{
		 C::t('#it618_waimai#it618_waimai_bank')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_name' => dhtmlspecialchars($_GET["it618_name"]),
				'it618_bankname' => dhtmlspecialchars($_GET["it618_bankname"]),
				'it618_bankid' => dhtmlspecialchars($_GET["it618_bankid"]),
				'it618_bankaddr' => dhtmlspecialchars($_GET["it618_bankaddr"]),
				'it618_alipayname' => dhtmlspecialchars($_GET["it618_alipayname"]),
				'it618_alipay' => dhtmlspecialchars($_GET["it618_alipay"]),
				'it618_wxname' => dhtmlspecialchars($_GET["it618_wxname"]),
				'it618_wx' => dhtmlspecialchars($_GET["it618_wx"])
		  ), true);
	}
	it618_cpmsg(it618_waimai_getlang('s1028'), "plugin.php?id=it618_waimai:sc_bank$adminsid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_waimai:sc_bank$adminsid");
showtableheaders(it618_waimai_getlang('s1029'),'it618_waimai_bank');

if(in_array(2,(array)unserialize($it618_waimai['waimai_txtype'])))$txtype1=$it618_waimai_lang['s1154'];else $txtype1=$it618_waimai_lang['s1155'];
if(in_array(3,(array)unserialize($it618_waimai['waimai_txtype'])))$txtype2=$it618_waimai_lang['s1154'];else $txtype2=$it618_waimai_lang['s1155'];
if(in_array(4,(array)unserialize($it618_waimai['waimai_txtype'])))$txtype3=$it618_waimai_lang['s1154'];else $txtype3=$it618_waimai_lang['s1155'];

echo '
<script>
	function checkvalue(){
		var flag=0;
		if(document.getElementById("it618_alipayname").value!="")flag=flag+1;
		if(document.getElementById("it618_alipay").value!="")flag=flag+1;
		if(flag==1){
			alert("'.it618_waimai_getlang('s1153').'");
			return false;
		}
		
		var flag=0;
		if(document.getElementById("it618_wxname").value!="")flag=flag+1;
		if(document.getElementById("it618_wx").value!="")flag=flag+1;
		if(flag==1){
			alert("'.it618_waimai_getlang('s1032').'");
			return false;
		}
		
		var flag=0;
		if(document.getElementById("it618_name").value!="")flag=flag+1;
		if(document.getElementById("it618_bankname").value!="")flag=flag+1;
		if(document.getElementById("it618_bankid").value!="")flag=flag+1;
		if(document.getElementById("it618_bankaddr").value!="")flag=flag+1;
		if(flag==1){
			alert("'.it618_waimai_getlang('s1033').'");
			return false;
		}
	}
	
</script>';

echo '
<tr><td colspan=2>'.it618_waimai_getlang('s1035').'</td></tr>
<tr><td colspan=2><strong>'.it618_waimai_getlang('s1043').' '.$txtype1.'</strong></td></tr>
<tr><td>'.it618_waimai_getlang('s1044').'</td><td><input type="text" class="txt" style="width:300px" id="it618_alipayname" name="it618_alipayname" value="'.$it618_waimai_bank['it618_alipayname'].'"></td></tr>
<tr><td>'.it618_waimai_getlang('s1045').'</td><td><input type="text" class="txt" style="width:300px" id="it618_alipay" name="it618_alipay" value="'.$it618_waimai_bank['it618_alipay'].'"></td></tr>
<tr><td colspan=2><strong>'.it618_waimai_getlang('s1051').' '.$txtype2.'</strong></td></tr>
<tr><td>'.it618_waimai_getlang('s952').'</td><td><input type="text" class="txt" style="width:300px" id="it618_wxname" name="it618_wxname" value="'.$it618_waimai_bank['it618_wxname'].'"></td></tr>
<tr><td>'.it618_waimai_getlang('s953').'</td><td><input type="text" class="txt" style="width:300px" id="it618_wx" name="it618_wx" value="'.$it618_waimai_bank['it618_wx'].'"></td></tr>
<tr><td colspan=2><strong>'.it618_waimai_getlang('s1036').' '.$txtype3.'</strong></td></tr>
<tr><td width="120">'.it618_waimai_getlang('s1037').'</td><td><input type="text" class="txt" style="width:300px" id="it618_name" name="it618_name" value="'.$it618_waimai_bank['it618_name'].'"></td></tr>
<tr><td>'.it618_waimai_getlang('s1038').'</td><td><input type="text" class="txt" style="width:300px" id="it618_bankname" name="it618_bankname" value="'.$it618_waimai_bank['it618_bankname'].'"> '.it618_waimai_getlang('s1039').'</td></tr>
<tr><td>'.it618_waimai_getlang('s1040').'</td><td><input type="text" class="txt" style="width:300px" id="it618_bankid" name="it618_bankid" value="'.$it618_waimai_bank['it618_bankid'].'"></td></tr>
<tr><td>'.it618_waimai_getlang('s1041').'</td><td><input type="text" class="txt" style="width:300px" id="it618_bankaddr" name="it618_bankaddr" value="'.$it618_waimai_bank['it618_bankaddr'].'"> '.it618_waimai_getlang('s1042').'</td></tr>
<tr><td colspan="2"><input type="submit" class="btn" name="it618submit" value="'.it618_waimai_getlang('s1046').'" onclick="return checkvalue()" /></td></tr>
';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_footer.func.php';
?>