<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$state0='';$state1='';$state2='';
if($_GET['state']==0){$it618sql = "1";$state0='selected="selected"';}
if($_GET['state']==1){$it618sql = "it618_ison = 1";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql = "it618_ison = 0";$state2='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&it618_class_id='.$_GET['it618_class_id'].'&state='.$_GET['state'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount = C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pid($delid);
		if($salecount<=0){
			$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($delid);
			
			$tmparr=explode("source",$it618_waimai_goods['it618_picbig']);
			$tmparr1=explode("http://",$it618_waimai_goods['it618_picbig']);
			$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_picbig)&&count($tmparr1)==1){
				$result=unlink($it618_picbig);
			}
			
			$get_it618_picbig=$_GET['it618_picbig'];
			if($it618_waimai_goods['it618_picbig']!=$get_it618_picbig){
				$tmparr=explode("source",$it618_waimai_goods['it618_picbig']);
				$tmparr1=explode("http://",$it618_waimai_goods['it618_picbig']);
				$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_picbig)&&count($tmparr1)==1){
					$result=unlink($it618_picbig);
				}
			}
			
			$file_ext=strtolower(substr($it618_waimai_goods['it618_picbig'],strrpos($it618_waimai_goods['it618_picbig'], '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
			if(file_exists($it618_smallurl)){
				$result=unlink($it618_smallurl);
			}
			
			C::t('#it618_waimai#it618_waimai_goods')->delete_by_id($delid);
			$del=$del+1;
		}
	}

	it618_cpmsg(it618_waimai_getlang('s7').$del, "plugin.php?id=it618_waimai:sc_product$adminsid&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			if($_GET['it618_uprice'][$id]>$ShopUPRICE){
				$it618_uprice=$_GET['it618_uprice'][$id];
			}else{
				$it618_uprice=$ShopUPRICE;
			}
			
			if($_GET['it618_zsscore'][$id]>$ShopZSSCOREB){
				$it618_zsscore=$_GET['it618_zsscore'][$id];
			}else{
				$it618_zsscore=$ShopZSSCOREB;
			}
			
			$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($id);
			
			C::t('#it618_waimai#it618_waimai_goods')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_zsscore' => $it618_zsscore,
				'it618_uprice' => $it618_uprice,
				'it618_ison' => $_GET['it618_ison'][$id],
				'it618_order' => intval($_GET['it618_order'][$id])
			));
	
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_waimai_getlang('s5').$ok, "plugin.php?id=it618_waimai:sc_product$adminsid&page=$page".$sql, 'succeed');
}

foreach(C::t('#it618_waimai#it618_waimai_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class_id'].'>','<option value='.$_GET['it618_class_id'].' selected="selected">',$tmp);

it618_showformheader("plugin.php?id=it618_waimai:sc_product$adminsid");
showtableheaders(it618_waimai_getlang('s230'),'it618_waimai_sum');
	echo '<tr><td colspan=14>'.it618_waimai_getlang('s231').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_waimai_getlang('s232').' <select name="it618_class_id"><option value="0">'.it618_waimai_getlang('s233').'</option>'.$tmp1.'</select> '.it618_waimai_getlang('s234').' <select name="state"><option value=0 '.$state0.'>'.it618_waimai_getlang('s235').'</option><option value=1 '.$state1.'>'.it618_waimai_getlang('s240').'</option><option value=2 '.$state2.'>'.it618_waimai_getlang('s241').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_waimai_getlang('s34').'" /></td></tr>';
	
	$count = C::t('#it618_waimai#it618_waimai_goods')->count_by_shopid($ShopId,$it618sql,'',$_GET['key'],$_GET['it618_class_id'],0,0);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_waimai:sc_product$adminsid".$urlsql);
	
	echo '<tr><td colspan=15>'.it618_waimai_getlang('s250').$count.'<span style="float:right;">'.it618_waimai_getlang('s846').'<font color=red>'.$ShopUPRICE.'</font> '.it618_waimai_getlang('s847').'<font color=red>'.$ShopZSSCORE.'</font>)</font></span></td></tr>';
	showsubtitle(array('',it618_waimai_getlang('s259'),$it618_waimai_lang['s1717'],$it618_waimai_lang['s1713'],$it618_waimai_lang['s251'],it618_waimai_getlang('s240'),it618_waimai_getlang('s1290')));
	
	$n=1;
	foreach(C::t('#it618_waimai#it618_waimai_goods')->fetch_all_by_shopid(
		$ShopId,$it618sql,"id desc",$_GET['key'],$_GET['it618_class_id'],0,0,$startlimit,$ppp
	) as $it618_waimai_goods) {
		
		if($it618_waimai_goods['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
		
		$typecountall = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_waimai_goods_type')." WHERE it618_pid=".$it618_waimai_goods['id']);
		$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_waimai_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_waimai_goods['id']);
		
		$pjhaocount=C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pj_pid(1,$it618_waimai_goods['id']);
		$pjallcount=C::t('#it618_waimai#it618_waimai_sale')->count_pj_by_pid($it618_waimai_goods['id']);
		$pjhaobl=intval($pjhaocount/$pjallcount*100);
		$pj=' '.it618_waimai_getlang('s1301').''.$pjallcount.' '.it618_waimai_getlang('s1302').''.$pjhaobl.'%';
		
		$ptypecss='';
		if($typecountok>0)$ptypecss='readonly="readonly"';
		
		$disabled="";
		if($it618_waimai_goods['salecount']>0)$disabled="disabled=\"disabled\"";

		$preurl="plugin.php?id=it618_waimai:sc_product$adminsid".$urlsql."&page=$page";
		$preurl=str_replace("&","@",$preurl);
		
		$salecount=C::t('#it618_waimai#it618_waimai_sale')->sumcountcount_by_it618_pid($it618_waimai_goods['id']);
		C::t('#it618_waimai#it618_waimai_goods')->update_it618_salecount_by_id($it618_waimai_goods['id'],$salecount);
		
		$salecount1=C::t('#it618_waimai#it618_waimai_sale')->sumcountcount_by_it618_pid1($it618_waimai_goods['id']);
		if($salecount1>0)$disabled='disabled="disabled"';
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_waimai_goods[id].'" '.$disabled.'><label for="chk_del'.$n.'">'.$it618_waimai_goods['id'].'</label>',
			'<img style="float:left" src="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" width="46" height="46" align="absmiddle"/><input type="text" class="txt" style="width:380px;margin-left:3px;margin-right:6px;margin-bottom:6px;margin-top:2px" id="it618_name'.$n.'" name="it618_name['.$it618_waimai_goods[id].']" value="'.$it618_waimai_goods[it618_name].'"><input type="hidden" class="txt" name="it618_name_old['.$it618_waimai_goods[id].']" value="'.$it618_waimai_goods[it618_name].'"><a href="plugin.php?id=it618_waimai:sc_product_edit'.$adminsid.'&pid='.$it618_waimai_goods[id].'&preurl='.$preurl.'">'.it618_waimai_getlang('s109').'</a><br>&nbsp;'.it618_waimai_classname($it618_waimai_goods['id']).' '.it618_waimai_getlang('s1298').$salecount.' '.$pj,
			
			'<input type="text" class="txt" style="width:68px;margin-right:0;color:red" id="it618_uprice'.$n.'" name="it618_uprice['.$it618_waimai_goods[id].']" value="'.$it618_waimai_goods[it618_uprice].'" '.$ptypecss.'>',
			
			'<input type="text" class="txt" style="width:68px;margin-right:0;color:blue" name="it618_zsscore['.$it618_waimai_goods[id].']" value="'.$it618_waimai_goods[it618_zsscore].'" '.$ptypecss.'>',
			
			'<a href="plugin.php?id=it618_waimai:sc_product_type'.$adminsid.'&pid='.$it618_waimai_goods[id].'&preurl='.$preurl.'" style="float:left;margin-left:3px;margin-top:1px">'.it618_waimai_getlang('s1712').'(<font color=red>'.$typecountok.'</font>/<font color=red>'.$typecountall.'</font>)</a>',
			
			'<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_waimai_goods['id'].']" '.$it618_ison_checked.' value="1">',
			
			'<input type="text" class="txt" style="width:40px;margin-top:3px;margin-bottom:3px" name="it618_order['.$it618_waimai_goods[id].']" value="'.$it618_waimai_goods[it618_order].'">'
		));
				
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_waimai_getlang('s70').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_waimai_getlang('s261').'" onclick="return confirm(\''.it618_waimai_getlang('s262').'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.it618_waimai_getlang('s263').'"/> <input type="checkbox" id="chk_ison" class="checkbox" onclick="check_all(this, \'chk_ison\')" /><label for="chk_ison">'.it618_waimai_getlang('s240').'</label><input type=hidden value=1 name=page /></div></td></tr>';

showtablefooter();

echo '<script charset="utf-8" src="source/plugin/it618_waimai/js/Calendar.js"></script><script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_footer.func.php';
?>