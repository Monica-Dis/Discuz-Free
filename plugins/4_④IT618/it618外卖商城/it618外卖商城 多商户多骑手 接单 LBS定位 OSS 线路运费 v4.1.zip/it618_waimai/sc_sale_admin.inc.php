<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';
$sctitle=it618_waimai_getlang('s1641');
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_header.func.php';

$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
if(!in_array($_G['uid'],$saleadmin)){
	it618_cpmsg($it618_waimai_lang['s1109'], '', 'error');
}

$it618_clienid=getcookie('it618_clienid');
if($it618_clienid==''){
	$it618_clienid=md5(time());
	dsetcookie('it618_clienid',$it618_clienid,3600*24*365);
}

echo '
<audio id="bgMusic">
    <source src="'.$it618_waimai['waimai_salemp3src'].'" type="audio/mp3">
</audio>
<span id="tmpalertbtn"></span>

<script charset="utf-8" src="source/plugin/it618_waimai/js/Calendar.js"></script>
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/js/jquery.js"></script>
<script type="text/javascript" src="source/plugin/it618_waimai/js/clipboard.min.js"></script>

<script>
var isok=0;
var audio = document.getElementById("bgMusic");

function getisok(){
	if(isok==1){
		isok=0;
		document.getElementById("isokbtn").style.backgroundColor="#e8e8e8";
		document.getElementById("isokbtn").style.color="green";
		document.getElementById("isokbtn").innerHTML="'.$it618_waimai_lang['s1558'].'";
	}else{
		isok=1;
		document.getElementById("isokbtn").style.backgroundColor="#390";
		document.getElementById("isokbtn").style.color="#fff";
		document.getElementById("isokbtn").innerHTML="'.$it618_waimai_lang['s1559'].'";
	}
}

function getsaleaudio(){
	if(isok==1){
		IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax&shopid=0&clienid='.$it618_clienid.'&formhash='.FORMHASH.'", {ac:"getsaleaudio"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[1]=="ok"){
			audio.currentTime = 0;
			audio.play();
			getsalelist(saleurl);
		}
		}, "html");	
	}
}

var dialog_sale;

IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax&shopid=0&update&clienid='.$it618_clienid.'&formhash='.FORMHASH.'", {ac:"getsaleaudio"},function (data, textStatus){
	getisok();
	var tmptime = window.setInterval(getsaleaudio,'.($it618_waimai['waimai_saletime']*1000).');
}, "html");	
</script>
';

$salestate=it618_waimai_getsalestate();

$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_peiman')." ORDER BY it618_order");
while($it618_waimai_peiman = DB::fetch($query)) {
	$selected='';
	if($it618_waimai_peiman['it618_pmid']==$it618_waimai_sale['it618_pmid']){
		$selected='selected="selected"';
	}
	$peimenstr.='<option value="'.$it618_waimai_peiman['id'].'" '.$selected.'>'.$it618_waimai_peiman['it618_pmid'].'-'.$it618_waimai_peiman['it618_name'].'</option>';
}

showtableheaders(it618_waimai_getlang('s1641'),'it618_waimai_sum');

if($it618_waimai['waimai_pmmodehide']==0){
	$pmmodestr='<th>'.$it618_waimai_lang['s333'].'</th>';
}

	$tmpstr='<span style="float:right"><a href="javascript:" id="isokbtn" onclick="getisok()" style="display:block;background-color:#e8e8e8;color:green;height:20px;padding:3px 15px;padding-top:6px;text-decoration:none;font-weight:bold">'.$it618_waimai_lang['s1558'].'</a></span>';
	
	echo '<tr><td colspan="15"><div class="fixsel">'.$tmpstr.it618_waimai_getlang('s1114').' <input id="findshopid" class="txt" style="width:68px" value="'.$_GET['salesid'].'" /> '.it618_waimai_getlang('s1115').' <input id="finduid" class="txt" style="width:68px" /> '.it618_waimai_getlang('s374').' <select id="peiman"><option value=0>'.it618_waimai_getlang('s373').'</option>'.$peimenstr.'</select>'.it618_waimai_getlang('s1116').' <select id="state"><option value=0>'.it618_waimai_getlang('s1117').'</option>'.$salestate.'</select> '.it618_waimai_getlang('s1122').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_waimai_getlang('s1123').'" onclick="findsalelist()" /> <input type="button" class="btn" value="'.it618_waimai_getlang('s236').'" onclick="dao()" /> </div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>
	<tr class="header">
	<th width=50>'.$it618_waimai_lang['s1124'].'</th>
	<th>'.$it618_waimai_lang['s1125'].'</th>
	<th>'.$it618_waimai_lang['s1127'].'</th>
	<th>'.$it618_waimai_lang['s1105'].'</th>
	<th>'.$it618_waimai_lang['s1128'].'</th>
	<th>'.$it618_waimai_lang['s1129'].'</th>
	<th>'.$it618_waimai_lang['s1126'].'</th>
	<th>'.$it618_waimai_lang['s1132'].'</th>
	'.$pmmodestr.'
	<th>'.$it618_waimai_lang['s1133'].'</th>
	<th width=100>'.$it618_waimai_lang['s1134'].'</th>
	<th width=150>'.$it618_waimai_lang['s1135'].'</th>
	</tr>';
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_waimai/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr><div id="salefahuo" style="display:none"></div><div id="tmpsalebtn"></div><div id="tmpsalelbsbtn"></div><a class="clipboardbtnsale" id="clipboardbtnsale" data-clipboard-text=""></a>';

showtablefooter();
echo '
<script>
var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax";
var sqlurl="";
function getsalelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_WAIMAI.get(url+sqlurl+"&formhash='.FORMHASH.'", {ac:"sale_get",ac1:"admin"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_WAIMAI("#tr_salesum").html(tmparr[0]);
	IT618_WAIMAI("#tr_salelist").html(tmparr[1]);
	IT618_WAIMAI("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}

function findsalelist(){
	var findshopid = document.getElementById("findshopid").value;
	var finduid = document.getElementById("finduid").value;
	var peiman = document.getElementById("peiman").value;
	var state = document.getElementById("state").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&findshopid="+findshopid+"&finduid="+finduid+"&peiman="+peiman+"&state="+state+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax";
	getsalelist(url);
}

findsalelist();

function dao(){
	findsalelist();
	IT618_WAIMAI.get(saleurl+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_dao",ac1:"admin"},function (data, textStatus){
	window.open(data);
	}, "html");	
}

function sale_admingetsale(saleid){
	if(confirm("'.it618_waimai_getlang('s1160').'")){
		IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_admingetsale"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function sale_isrwpmpower(saleid){
	if(confirm("'.it618_waimai_getlang('s352').'")){
		IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_isrwpmpower"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function sale_adminsqfahuo(saleid){
	if(confirm("'.it618_waimai_getlang('s1162').'")){
		IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_adminsqfahuo"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

var dialog_salefahuo,salefahuoid=0;
KindEditor.ready(function(K) {K(\'#salefahuo\').click(function() {
	getsalefahuo(K);
});});

function sale_fahuo(saleid){
	if(salefahuoid==0){
		salefahuoid=saleid;
		IT618_WAIMAI("#salefahuo").click();
	}
}

function getsalefahuo(K){
IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:salefahuo"+"&gwcid="+salefahuoid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	IT618_WAIMAI("#clipboardbtnsale").attr("data-clipboard-text",tmparr[1]);
	
	dialog_salefahuo = K.dialog({
		width : 533,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[2]+\'</div>\',
		closeBtn : {
			name : \''.$it618_waimai_lang['t571'].'\',
			click : function(e) {
				dialog_salefahuo.remove();
				salefahuoid=0;
			}
		}
	});
	
	IT618_WAIMAI(\'.ns-sub-a\').click(function(){
		
		if(confirm("'.$it618_waimai_lang['s1166'].'")){
			
			IT618_WAIMAI.post("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax"+"&ac=sale_fahuo"+"&saleid="+salefahuoid+"&formhash='.FORMHASH.'",IT618_WAIMAI("#it618_salefahuo").serialize(),function (data, textStatus){
				var tmparr=data.split("it618_split");
			
				if(tmparr[0]=="ok"){
					alert(tmparr[1]);
					dialog_salefahuo.remove();
					getsalelist(saleurl);
					salefahuoid=0;
				}else{
					alert(tmparr[1]);
				}
			}, "html");
		}
	})
	
	IT618_WAIMAI(\'.ns-sub-b\').click(function(){
		dialog_salefahuo.remove();
		salefahuoid=0;
	})
	
	}, "html");		
}

function sale_jujuetui(saleid){
	if(confirm("'.it618_waimai_getlang('s1212').'")){
		IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_jujuetui"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function sale_tongyitui(saleid){
	if(confirm("'.it618_waimai_getlang('s1215').'")){
		IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_tongyitui"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

KindEditor.ready(function(K) {K(\'#tmpsalebtn\').click(function() {
	
	IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:showsale&gwcid="+gwcid, {ac:"admin"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	IT618_WAIMAI("#clipboardbtnsale").attr("data-clipboard-text",tmparr[0]);
	
	dialog_sale = K.dialog({
		width : 810,
		title : \''.it618_waimai_getlang('s1118').'\',
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.it618_waimai_getlang('s1107').'\',
			click : function(e) {
				dialog_sale.remove();
			}
		}
	});
	
	}, "html");	
});});

var gwcid;
function showsale(saleid){
	gwcid=saleid;
	document.getElementById("tmpsalebtn").click();
}

var salelbsid;
function showsalelbs(id){
	salelbsid=id;
	document.getElementById("tmpsalelbsbtn").click();
}

KindEditor.ready(function(K) {K(\'#tmpsalelbsbtn\').click(function() {
	
	IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:showsalelbs&saleid="+salelbsid, {ac:"admin"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	dialog_salelbs = K.dialog({
		width : 638,
		title : \''.it618_waimai_getlang('s410').'\',
		body : \'<div style="padding:5px;padding-left:3px">\'+data+\'</div>\',
		closeBtn : {
			name : \''.it618_waimai_getlang('s1107').'\',
			click : function(e) {
				dialog_salelbs.remove();
			}
		}
	});
	
	}, "html");	
});});

var clipboardbtnsale = new Clipboard(".clipboardbtnsale");
clipboardbtnsale.on("success", function(e) {
	alert("'.$it618_waimai_lang['s1121'].'");
});
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_footer.func.php';
?>