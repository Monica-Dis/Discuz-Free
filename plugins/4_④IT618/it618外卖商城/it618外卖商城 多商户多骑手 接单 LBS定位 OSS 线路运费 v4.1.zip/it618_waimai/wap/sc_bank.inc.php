<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!waimai_is_mobile()){
	$tmpurl=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc');
	dheader("location:$tmpurl");
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/shop_default.func.php';

$navtitle=it618_waimai_getlang('s1561').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_waimai_getlang('s1005');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$it618_waimai_bank = DB::fetch_first("SELECT * FROM ".DB::table('it618_waimai_bank')." where it618_shopid=".$ShopId);

if($it618_txmsg!=''){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$sc_bank='
<script>
	function checkvalue(){
		var flag=0;
		if(document.getElementById("it618_alipayname").value!="")flag=flag+1;
		if(document.getElementById("it618_alipay").value!="")flag=flag+1;
		if(flag==1){
			alert("'.it618_waimai_getlang('s1153').'");
			return false;
		}
		
		var flag=0;
		if(document.getElementById("it618_wxname").value!="")flag=flag+1;
		if(document.getElementById("it618_wx").value!="")flag=flag+1;
		if(flag==1){
			alert("'.it618_waimai_getlang('s1032').'");
			return false;
		}
		
		var flag=0;
		if(document.getElementById("it618_name").value!="")flag=flag+1;
		if(document.getElementById("it618_bankname").value!="")flag=flag+1;
		if(document.getElementById("it618_bankid").value!="")flag=flag+1;
		if(document.getElementById("it618_bankaddr").value!="")flag=flag+1;
		if(flag==1){
			alert("'.it618_waimai_getlang('s1033').'");
			return false;
		}
		
		return true;
	}
	
</script>';

if(in_array(2,(array)unserialize($it618_waimai['waimai_txtype'])))$txtype1=$it618_waimai_lang['s1154'];else $txtype1=$it618_waimai_lang['s1155'];
if(in_array(3,(array)unserialize($it618_waimai['waimai_txtype'])))$txtype2=$it618_waimai_lang['s1154'];else $txtype2=$it618_waimai_lang['s1155'];
if(in_array(4,(array)unserialize($it618_waimai['waimai_txtype'])))$txtype3=$it618_waimai_lang['s1154'];else $txtype3=$it618_waimai_lang['s1155'];

$sc_bank.='
<tr><td width=88 style="padding:0;height:0;border:none"></td><td style="padding:0;height:0;border:none"></td></tr>
<tr><td colspan=2 style="padding-top:0">'.it618_waimai_getlang('s1035').'</td></tr>
<tr><td colspan=2 style="background-color:#f3f3f3"><strong>'.it618_waimai_getlang('s1043').' '.$txtype1.'</strong></td></tr>
<tr><td>'.it618_waimai_getlang('s1044').'</td><td><input type="text" class="txt" style="width:100%" id="it618_alipayname" name="it618_alipayname" value="'.$it618_waimai_bank['it618_alipayname'].'"></td></tr>
<tr><td>'.it618_waimai_getlang('s1045').'</td><td><input type="text" class="txt" style="width:100%" id="it618_alipay" name="it618_alipay" value="'.$it618_waimai_bank['it618_alipay'].'"></td></tr>
<tr><td colspan=2 style="background-color:#f3f3f3"><strong>'.it618_waimai_getlang('s1051').' '.$txtype2.'</strong></td></tr>
<tr><td>'.it618_waimai_getlang('s952').'</td><td><input type="text" class="txt" style="width:100%" id="it618_wxname" name="it618_wxname" value="'.$it618_waimai_bank['it618_wxname'].'"></td></tr>
<tr><td>'.it618_waimai_getlang('s953').'</td><td><input type="text" class="txt" style="width:100%" id="it618_wx" name="it618_wx" value="'.$it618_waimai_bank['it618_wx'].'"></td></tr>
<tr><td colspan=2 style="background-color:#f3f3f3"><strong>'.it618_waimai_getlang('s1036').' '.$txtype3.'</strong></td></tr>
<tr><td width="120">'.it618_waimai_getlang('s1037').'</td><td><input type="text" class="txt" style="width:100%" id="it618_name" name="it618_name" value="'.$it618_waimai_bank['it618_name'].'"></td></tr>
<tr><td>'.it618_waimai_getlang('s1038').'</td><td><input type="text" class="txt" style="width:100%" id="it618_bankname" name="it618_bankname" value="'.$it618_waimai_bank['it618_bankname'].'"> <font color=#999>'.it618_waimai_getlang('s1039').'</font></td></tr>
<tr><td>'.it618_waimai_getlang('s1040').'</td><td><input type="text" class="txt" style="width:100%" id="it618_bankid" name="it618_bankid" value="'.$it618_waimai_bank['it618_bankid'].'"></td></tr>
<tr><td>'.it618_waimai_getlang('s1041').'</td><td><input type="text" class="txt" style="width:100%" id="it618_bankaddr" name="it618_bankaddr" value="'.$it618_waimai_bank['it618_bankaddr'].'"> <font color=#999>'.it618_waimai_getlang('s1042').'</font></td></tr>
<tr><td colspan="2"><input type="button" class="it618btn" value="'.it618_waimai_getlang('s1046').'" onclick="if(checkvalue()){bank_save();}" /></td></tr>
';

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>