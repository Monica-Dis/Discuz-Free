<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/shop_default.func.php';

if(!waimai_is_mobile()){
	dheader("location:$homeurl");
}

$uid = $_G['uid'];
if($uid<=0){
	$error=1;
}else{
	$goodscount=C::t('#it618_waimai#it618_waimai_gwc')->count_by_uid($uid);
	
	if($goodscount>0){
		$shopid=C::t('#it618_waimai#it618_waimai_gwc')->fetch_shopid_by_uid($uid);
		$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($shopid);
		$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
		if($it618_waimai_waimaigroup['it618_img']!='')$shopico='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" style="vertical-align:middle"/>';
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_uid_maxid($uid);

		$it618_scorebl=$it618_waimai_waimai['it618_scorebl'];
		
		if($it618_waimai_waimai['it618_moneybz']!=''){
			$mjmoneystr='<table width="100%"><tr><td width="76%" style="border:none;padding:0;color:red">'.$it618_waimai_waimai['it618_moneybz'].'</td><td style="border:none;padding:0"><font color=#390  style="font-size:15px;float:right">- &yen;<span id="mjmoneystr" style="font-size:20px">0</span></font></td></tr></table>';
		}else{
			$mjmoneystr='<span id="mjmoneystr" style="font-size:20px">0</span>';
			$mjmoneycss='style="display:none"';
		}
		
		if($it618_scorebl>0){
			$tmpcss='';
			$creditnum=C::t('#it618_waimai#it618_waimai_sale')->fetch_extcredits_by_uid($it618_waimai['waimai_credit'],$uid);
			if($creditnum=="")$creditnum=0;
			if($creditnum<=0)$tmpcss='style="display:none"';
		}else{
			$tmpcss='style="display:none"';
		}
		
		$scorestr='<table width="100%"><tr><td width="76%" style="border:none;padding:0"><input type="checkbox" id="chkscore" name="chkscore" value="1" style="vertical-align:middle" onclick="getsfmoney()"><label for="chkscore" style="vertical-align:middle">'.$it618_waimai_lang['s1068'].'<font color=#390><b>'.$creditnum.'</b></font>'.$creditname.$it618_waimai_lang['s1079'].$it618_waimai_lang['s1059'].'<font color=red><b>'.$it618_scorebl.'</b></font>%'.$it618_waimai_lang['s1069'].'<font color=#F60><span id="jfscore"></span></font>'.$creditname.$it618_waimai_lang['s1070'].'</td><td style="border:none;padding:0"><font color=#390  style="font-size:15px;float:right">- &yen;<span id="scoremoney" style="font-size:20px">0</span></font><input type="hidden" id="jf" value="'.$creditnum.'"><input type="hidden" id="jfbl" value="'.$it618_waimai['waimai_jfbl'].'"><input type="hidden" id="scorebl" value="'.$it618_scorebl.'"></label></td></tr><tr><td>'.$it618_waimai_lang['t299'].'</td></tr></table>';
		
		$sfmoneystr='<font color=#F60  style="font-size:23px;float:right">&yen;<span id="sfmoney" style="font-size:30px"></span></font>'.$it618_waimai_lang['s1078'];
		
		$yytimestr=it618_waimai_getyytime($it618_waimai_waimai);
		$yytimestrarr=explode("it618_split",$yytimestr);
		
		if($yytimestrarr[0]==2){
			$it618_isokbz=$yytimestrarr[1];
		}
		if($yytimestrarr[0]==31)$it618_isokbz=$it618_waimai_lang['s688']." ".$yytimestrarr[1];
		if($yytimestrarr[0]==32)$it618_isokbz=$it618_waimai_lang['s689']." ".$yytimestrarr[1];
		
		if($it618_waimai_waimai['it618_isok']==1){
			$paybtnstr='<input class="btn btn-strong buy-btn2 btn-large it618pay" type="button" style="width:100%;height:48px" value="'.$it618_waimai_lang['t749'].'" onclick="pay()" />';
		}else{
			$paybtnstr='<div style="font-size:18px;line-height:18px;color:red;font-weight:bold">'.$it618_isokbz.'</div>';
		}
	}else{
		$error=1;
	}
}

$it618paystr=it618_waimai_pay('gwcwap',$it618_waimai_lang['t231']);

$navtitle=it618_waimai_getlang('t192').' - '.$sitetitle;

$ucurl=it618_waimai_getrewrite('waimai_wap','uc@1','plugin.php?id=it618_waimai:wap&pagetype=uc&sid=1');

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>