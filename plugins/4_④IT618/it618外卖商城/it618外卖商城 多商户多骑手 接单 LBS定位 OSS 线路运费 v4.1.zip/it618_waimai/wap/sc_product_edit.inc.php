<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!waimai_is_mobile()){
	$tmpurl=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc');
	dheader("location:$tmpurl");
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/shop_default.func.php';

$spanname=it618_waimai_getlang('s1661');
$navtitle=it618_waimai_getlang('s1661').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_waimai_getlang('s1005');
}

$pid=intval($_GET['cid']);
$it618_waimai_goods=C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$goodsbuycontentwaimai=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('goodsbuycontentwaimai');

$scacurl=it618_waimai_getrewrite('waimai_wap','sc_product_edit@'.$it618_waimai_goods['it618_shopid'].'@0@'.$it618_waimai_goods['id'].'@0','plugin.php?id=it618_waimai:wap&pagetype=sc_product_edit&sid='.$it618_waimai_goods['it618_shopid'].'&cid='.$it618_waimai_goods['id']);

if($it618_cpmsg!=''||$error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

foreach(C::t('#it618_waimai#it618_waimai_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

if($tmp!=''){
	$tmp1=str_replace('<option value='.$it618_waimai_goods['it618_class_id'].'>','<option value='.$it618_waimai_goods['it618_class_id'].' selected="selected">',$tmp);
	$isgoodsclass='if(document.getElementById("it618_class_id").value=="0"){
			alert("'.it618_waimai_getlang('s264').'");
			return false;
		}';
}

$sc_prodect_str= '
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_waimai/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_waimai/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=640'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_waimai/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			width : \'99%\',
			afterBlur: function () { this.sync(); },
			items : [\'source\',\'|\', \'emoticons\', \'image\', \'|\',\'fontname\', \'fontsize\', \'|\', \'forecolor\', \'hilitecolor\', \'bold\', \'underline\']
		});
		
		if(ispc==0)editor1.clickToolbar("source");
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		if(ispc==0)editor2.clickToolbar("source");
	});
	
	function checkvalue(){
		'.$isgoodsclass.'
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_waimai_getlang('s265').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_waimai_getlang('s266').'");
			return false;
		}
		return true;
	}
	
	function delpic(i){
		document.getElementById("url1"+i).value="";
		document.getElementById("img1"+i).src="";
	}
</script>

'.$tmpstr.'
';

if($tmp!=''){$sc_prodect_str.= '
<tr><td><b>'.it618_waimai_getlang('s270').'</b><select id="it618_class_id" name="it618_class_id" style="line-height:12px"><option value="0">'.it618_waimai_getlang('s271').'</option>'.$tmp1.'</select></td></tr>';}

$sc_prodect_str.= '
<tr><td><b>'.it618_waimai_getlang('s272').'</b><br><input type="text" class="txt" style="width:100%;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_waimai_goods['it618_name'].'"> </td></tr>
<tr><td><b>'.it618_waimai_getlang('s279').'</b><br><img id="img1" src="'.$it618_waimai_goods['it618_picbig'].'" width="80" height="80" align="absmiddle"/> <input type="text" id="url1" name="it618_picbig" style="width:150px" readonly="readonly" value="'.$it618_waimai_goods['it618_picbig'].'"/> <input type="button" class="inputbtn" id="image1" value="'.it618_waimai_getlang('s280').'" /></td></tr>
<tr><td><b>'.it618_waimai_getlang('s284').'</b><br><textarea name="it618_message" style="width:100%;height:300px;visibility:hidden;">'.$it618_waimai_goods['it618_message'].'</textarea></td></tr>
<tr><td><input type="button" class="btn jfbtn" onclick="if(checkvalue()){product_save(\'edit\');}" name="it618submit" value="'.it618_waimai_getlang('s120').'" /></td></tr>';

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>