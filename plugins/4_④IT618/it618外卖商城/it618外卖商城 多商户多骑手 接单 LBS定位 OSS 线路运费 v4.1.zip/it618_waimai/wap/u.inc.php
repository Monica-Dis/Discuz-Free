<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($it618_waimai['waimai_computer']==1){
	if(!waimai_is_mobile()){
		dheader("location:$waimai_home");
	}
}

$navtitle=it618_waimai_getlang('t789').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_waimai_getlang('s1005');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$menuusername=$_G['username'];
$u_avatarimg=it618_waimai_discuz_uc_avatar($_G['uid'],'middle');
$creditname=$_G['setting']['extcredits'][$it618_waimai['waimai_credit']]['title'];
$creditnum=DB::result_first("select extcredits".$it618_waimai['waimai_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	if($_G['cache']['plugin']['it618_credits']['rewriteurl']==0){
		$creditsurl='plugin.php?id=it618_credits:wap&dotype=uc';
	}else{
		$creditsurl='credits_wap-uc.html';
	}
}

$ucurl=it618_waimai_getrewrite('waimai_wap','uc@1','plugin.php?id=it618_waimai:wap&pagetype=uc&sid=1');
$collecturl=it618_waimai_getrewrite('waimai_wap','collect@'.$_G['uid'],'plugin.php?id=it618_waimai:wap&pagetype=collect');

$uccount=C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,"it618_state>0",'',$_G['uid']);
$ucmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_money',0,"it618_state>0",'',$_G['uid']);
if($ucmoney=='')$ucmoney=0;

$collectcount=C::t('#it618_waimai#it618_waimai_collect')->count_by_uid($_G['uid']);

$rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($_G['uid']);
if($rwpeimantmp['it618_state']==2){
	$rwpmurl=it618_waimai_getrewrite('waimai_wap','rwpm@0','plugin.php?id=it618_waimai:wap&pagetype=rwpm');
	$rwpmcount = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_rwpmid='.$rwpeimantmp['id']);
	$rwpmyunfei=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei',0,'it618_rwpmid='.$rwpeimantmp['id']);

	$isrwpm=1;
	
	$sumstr=$it618_waimai_lang['s523'];
	$count1 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_state=3 and it618_rwpmid='.$rwpeimantmp['id']);
	$sum1=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei',0,'it618_state=3 and it618_rwpmid='.$rwpeimantmp['id']);

	$sumstr=str_replace("{count1}",$count1,$sumstr);
	$sumstr=str_replace("{sum1}",$sum1,$sumstr);
	
	$pjcount1 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj=1 and it618_rwpmid='.$rwpeimantmp['id']);
	$pjcount2 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj=2 and it618_rwpmid='.$rwpeimantmp['id']);
	$pjcount3 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj=3 and it618_rwpmid='.$rwpeimantmp['id']);
	$allpjcount=$pjcount1+$pjcount2+$pjcount3;
	if($allpjcount==0){
		$pjtmp1=0;$pjtmp2=0;$pjtmp3=0;
	}else{
		$pjtmp1=$pjcount1/$allpjcount*100;
		$pjtmp2=$pjcount2/$allpjcount*100;
		$pjtmp3=$pjcount3/$allpjcount*100;
	}
	
	$sumstr=str_replace("{pj1}",round($pjtmp1,2),$sumstr);
	$sumstr=str_replace("{pj2}",round($pjtmp2,2),$sumstr);
	$sumstr=str_replace("{pj3}",round($pjtmp3,2),$sumstr);
	$sumstr=str_replace("{pjcount}",$allpjcount,$sumstr);
	
	$it618_waimai_rwpmtcbl=C::t('#it618_waimai#it618_waimai_rwpmtcbl')->fetch_by_pj($pjtmp1);
	$sumstr=str_replace("{jdcount}",$it618_waimai_rwpmtcbl['it618_jdcount'],$sumstr);
	$sumstr=str_replace("{tcbl}",$it618_waimai_rwpmtcbl['it618_tcbl'],$sumstr);
}

if($peimantmp=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_uid($_G['uid'])){
	$pmurl=it618_waimai_getrewrite('waimai_wap','pm@0','plugin.php?id=it618_waimai:wap&pagetype=pm');
	$pmcount = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,"it618_pmid='".$peimantmp['it618_pmid']."'");
	$pmyunfei=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei',0,"it618_pmid='".$peimantmp['it618_pmid']."'");

	$ispm=1;
	$pmidstr=$it618_waimai_lang['s208'].$peimantmp['it618_pmid'];
}

$waimaitmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
if($_G['uid']==$waimaitmp['it618_uid']&&$waimaitmp['it618_state']==2&&$waimaitmp['it618_htstate']==1){
	$scurl=it618_waimai_getrewrite('waimai_wap','sc@'.$waimaitmp['id'],'plugin.php?id=it618_waimai:wap&pagetype=sc&sid='.$waimaitmp['id']);
	$scgoodsurl=it618_waimai_getrewrite('waimai_wap','sc_product@'.$waimaitmp['id'],'plugin.php?id=it618_waimai:wap&pagetype=sc_product&sid='.$waimaitmp['id']);
	$sctxurl=it618_waimai_getrewrite('waimai_wap','sc_tx@'.$waimaitmp['id'],'plugin.php?id=it618_waimai:wap&pagetype=sc_tx&sid='.$waimaitmp['id']);
	$scdataurl=it618_waimai_getrewrite('waimai_wap','sc_data@'.$waimaitmp['id'],'plugin.php?id=it618_waimai:wap&pagetype=sc_data&sid='.$waimaitmp['id']);
		
	$goodscount = C::t('#it618_waimai#it618_waimai_goods')->count_by_shopid($waimaitmp['id']);
	
	$sccount=C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid($waimaitmp['id'],"it618_state>0");
	$scmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_money',$waimaitmp['id'],"it618_state>0");
	if($scmoney=='')$scmoney=0;
	
	$txmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_txmoeny_by_shopid($waimaitmp['id'],"it618_state=5");
	$sqtxmoney=C::t('#it618_waimai#it618_waimai_tx')->sumtxmoney_by_shopid($waimaitmp['id']);
	$money=$txmoney-$sqtxmoney;
	
	$txmoneystr=it618_waimai_getlang('t209').':<font color="red">'.$money.'</font>'.it618_waimai_getlang('t208');	
	
	$isshop=1;
}

$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
if(in_array($_G['uid'],$saleadmin)){
	$adminurl=it618_waimai_getrewrite('waimai_wap','admin@'.$_G['uid'],'plugin.php?id=it618_waimai:wap&pagetype=admin');
	$admincount=C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,"it618_state>0");
	$adminmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_money',0,"it618_state>0");
	if($adminmoney=='')$adminmoney=0;
	$isadmin=1;
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>