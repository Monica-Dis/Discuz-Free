<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/shop_default.func.php';

if(!waimai_is_mobile()){
	$tmpurl=it618_waimai_getrewrite('shop_home',$ShopId,'plugin.php?id=it618_waimai:shop&sid='.$ShopId);
	dheader("location:$tmpurl");
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$gwcpayurl=it618_waimai_getrewrite('waimai_wap','gwcsale@'.$ShopId,'plugin.php?id=it618_waimai:wap&pagetype=gwcsale&sid='.$ShopId);

$n=1;
foreach(C::t('#it618_waimai#it618_waimai_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$sql='it618_ison=1';
	$sql.=" and it618_class_id=".$it618_tmp['id'];
	$count = C::t('#it618_waimai#it618_waimai_goods')->count_by_search($sql);
	
	$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass\','.$n.','.$it618_tmp['id'].')" name="productclass">'.$it618_tmp['it618_classname'].' <font color=#999>'.$count.'</font></a>';
	$n=$n+1;
}

$collectbtn='<a href="javascript:" onClick="collectshop()" class="collectbtn">'.$it618_waimai_lang['s1734'].'</a>';
if($_G['uid']>0){
	$count=C::t('#it618_waimai#it618_waimai_collect')->count_by_uid_shopid($_G['uid'],$ShopId);
	if($count>0){
		$collectbtn='<a href="javascript:" onClick="collectshop()" class="collectbtn is-collect">'.$it618_waimai_lang['s1735'].'</a>';
	}else{
		$collectbtn='<a href="javascript:" onClick="collectshop()" class="collectbtn">'.$it618_waimai_lang['s1734'].'</a>';
	}
}

$it618_logo=it618_waimai_getwapppic($it618_waimai_waimai['id'],$it618_waimai_waimai['it618_logo']);

$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
$ShopPowerIco='';
if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" height="14" style="margin-left:3px"/>';


$gwcmoney=0;$gwccount=0;
foreach(C::t('#it618_waimai#it618_waimai_gwc')->fetch_all_by_shopid_uid($ShopId,$uid) as $it618_waimai_gwc) {
	if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	if($ii1i11i[3]!='1')exit;
	
	$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($it618_waimai_gwc['it618_pid']);
	
	$gtypename='';
	if($it618_waimai_gwc['it618_gtypeid']>0){
		$gtypename = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_it618_name_by_id($it618_waimai_gwc['it618_gtypeid']);
		$gtypename = '<font color=red>'.$gtypename.'</font>';
		
		$it618_waimai_goods_type = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_by_id($it618_waimai_gwc['it618_gtypeid']);
		$it618_uprice=$it618_waimai_goods_type['it618_uprice'];
		$it618_zsscore=$it618_waimai_goods_type['it618_zsscore'];
	}else{
		$it618_uprice=$it618_waimai_goods['it618_uprice'];
		$it618_zsscore=$it618_waimai_goods['it618_zsscore'];
	}
	
	$it618_count=$it618_waimai_gwc['it618_count'];
	
	$gwccount=$gwccount+$it618_count;
	$summoney=$it618_uprice*$it618_count;
	$gwcmoney=$gwcmoney+$summoney;
}

$gwcpayclick='onClick="gwcsave(\'gwcpay\')"';
if($gwcmoney>=$it618_waimai_waimai['it618_pmoney']){
	$gwcmoney1=$it618_waimai_lang['s169'];
	$gwcmoneycss="color:#333;background-color:#FC3;";
}else{
	$gwcmoney1=$it618_waimai_lang['s170'].''.($it618_waimai_waimai['it618_pmoney']-$gwcmoney);
	$gwcmoneycss="color:#999;background-color:#333;";
}

$yytimestr=it618_waimai_getyytime($it618_waimai_waimai);
$yytimestrarr=explode("it618_split",$yytimestr);

if($yytimestrarr[0]==2){
	$gwcmoney1=$yytimestrarr[1];
	$gwcpayclick='';
	$gwcmoneycss="color:#fff;background-color:#39F;font-size:14px";
}
if($yytimestrarr[0]>3){
	if($yytimestrarr[0]==31)$gwcmoney1=$it618_waimai_lang['s688'];
	if($yytimestrarr[0]==32)$gwcmoney1=$it618_waimai_lang['s689'];
	$gwcpayclick='';
	$yytime_isokbz=$yytimestrarr[1];
	$gwcmoneycss="color:#fff;background-color:red;";
}

$salecount=C::t('#it618_waimai#it618_waimai_sale')->sumcountcount_by_it618_shopid($it618_waimai_waimai['id']);

$pjhaocount=C::t('#it618_waimai#it618_waimai_sale')->count_by_pj_shopid(1,$it618_waimai_waimai['id']);
$pjzhongcount=C::t('#it618_waimai#it618_waimai_sale')->count_by_pj_shopid(2,$it618_waimai_waimai['id']);
$pjchacount=C::t('#it618_waimai#it618_waimai_sale')->count_by_pj_shopid(3,$it618_waimai_waimai['id']);

$pjallcount=$pjhaocount+$pjzhongcount+$pjchacount;

$pjhaobl=intval($pjhaocount/$pjallcount*100);
$pjzhongbl=intval($pjzhongcount/$pjallcount*100);
$pjchabl=intval($pjchacount/$pjallcount*100);

$pjcount=C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pj_shopid($it618_waimai_waimai['id']);
$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$pjcount);

C::t('#it618_waimai#it618_waimai_waimai')->update($it618_waimai_waimai['id'],array(
	'it618_levelsum' => $pjcount,
	'it618_views' => $it618_waimai_waimai['it618_views']+1,
	'it618_salecount' => $salecount,
	'it618_pjcount' => $pjallcount,
	'it618_haopjbl' => $pjhaobl
));

$navtitle=$it618_waimai_waimai['it618_name'].' - '.$sitetitle;

$wap=1;

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>