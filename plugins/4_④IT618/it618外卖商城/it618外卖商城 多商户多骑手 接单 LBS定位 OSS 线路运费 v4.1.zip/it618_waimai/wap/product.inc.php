<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pid=intval($_GET['pid']);
$wapwidth=intval($_GET['wapwidth']);

$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);

C::t('#it618_waimai#it618_waimai_goods')->update_it618_views_by_id($pid);

$pjhaocount=C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pj_pid(1,$pid);
$pjzhongcount=C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pj_pid(2,$pid);
$pjchacount=C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pj_pid(3,$pid);

$pjallcount=$pjhaocount+$pjzhongcount+$pjchacount;

$pjhaobl=intval($pjhaocount/$pjallcount*100);
$pjzhongbl=intval($pjzhongcount/$pjallcount*100);
$pjchabl=intval($pjchacount/$pjallcount*100);

$it618_message=$it618_waimai_goods['it618_message'];
$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img src="\1"/>',$it618_message);

$it618_message=$it618_waimai_goods['it618_message'];
$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img class="lazy" data-original="\1"/>',$it618_message);
$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="200" frameborder="0" allowfullscreen="1">',$it618_message);

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>