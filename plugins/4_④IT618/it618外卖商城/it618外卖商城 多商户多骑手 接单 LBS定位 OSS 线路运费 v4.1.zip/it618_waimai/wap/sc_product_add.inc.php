<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!waimai_is_mobile()){
	$tmpurl=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc');
	dheader("location:$tmpurl");
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/shop_default.func.php';

$spanname=it618_waimai_getlang('t52');
$navtitle=it618_waimai_getlang('t52').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_waimai_getlang('s1005');
}

$tmpcount=C::t('#it618_waimai#it618_waimai_goods')->count_by_shopid($ShopId);
if($tmpcount>=$Shop_goodscount){
	$error=1;
	$errormsg=$it618_waimai_lang['s1648'].$Shop_goodscount.$it618_waimai_lang['s1649'];
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$waimaigoodscontent=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('waimaigoodscontent');

if($it618_cpmsg!=''){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$goodscontent=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('goodscontent');

foreach(C::t('#it618_waimai#it618_waimai_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
	
if($tmp!=''){
	$isgoodsclass='if(document.getElementById("it618_class_id").value=="0"){
			alert("'.it618_waimai_getlang('s264').'");
			return false;
		}';
}

foreach(C::t('#it618_waimai#it618_waimai_waimai_class')->fetch_all_by_search() as $it618_tmp) {
	$classtmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$sc_prodect_str= '
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_waimai/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_waimai/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=640'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_waimai/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			width : \'99%\',
			afterBlur: function () { this.sync(); },
			items : [\'source\',\'|\', \'emoticons\', \'image\', \'|\',\'fontname\', \'fontsize\', \'|\', \'forecolor\', \'hilitecolor\', \'bold\', \'underline\']
		});
		
		if(ispc==0)editor1.clickToolbar("source");
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		if(ispc==0)editor2.clickToolbar("source");
	});
	
	function checkvalue(){
		'.$isgoodsclass.'
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_waimai_getlang('s265').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_waimai_getlang('s266').'");
			return false;
		}
		return true;
	}
	
	function delpic(i){
		document.getElementById("url1"+i).value="";
		document.getElementById("img1"+i).src="";
	}
</script>

'.$tmpstr.'
';

if($tmp!=''){$sc_prodect_str.= '
<tr><td><b>'.it618_waimai_getlang('s270').'</b><select id="it618_class_id" name="it618_class_id" style="line-height:12px"><option value="0">'.it618_waimai_getlang('s271').'</option>'.$tmp.'</select></td></tr>';}

$sc_prodect_str.= '
<tr><td><b>'.it618_waimai_getlang('s272').'</b><br><input type="text" class="txt" style="width:100%;" id="it618_name" name="it618_name"></td></tr>
<tr><td colspan=2><font color=green><b>'.$it618_waimai_lang['s1656'].'</b></font></td></tr>
<tr><td><b>'.it618_waimai_getlang('s279').'</b><br><img id="img1" width="80" height="80" align="absmiddle"/> <input type="text" id="url1" name="it618_picbig" style="width:150px" readonly="readonly"/> <input type="button" class="inputbtn" id="image1" value="'.it618_waimai_getlang('s280').'" /></td></tr>
<tr><td><b>'.it618_waimai_getlang('s284').'</b><br><textarea name="it618_message" style="width:100%;height:300px;visibility:hidden;">'.$goodscontent.'</textarea></td></tr>
<tr><td style="border:none"><input type="button" class="btn jfbtn" onclick="if(checkvalue()){product_save(\'add\');}" name="it618submit" value="'.it618_waimai_getlang('s120').'" /></td></tr>';

$scacurl=$scurl2;

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>