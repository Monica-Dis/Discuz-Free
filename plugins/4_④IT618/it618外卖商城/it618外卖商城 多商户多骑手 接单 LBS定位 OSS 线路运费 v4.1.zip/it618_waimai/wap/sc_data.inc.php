<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!waimai_is_mobile()){
	$tmpurl=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc');
	//dheader("location:$tmpurl");
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/shop_default.func.php';

$navtitle=it618_waimai_getlang('s4').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_waimai_getlang('s1005');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

if($it618_txmsg!=''){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

if($it618_waimai_waimai['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
if($it618_waimai_waimai['it618_messageisok']==1)$it618_messageisok_checked='checked="checked"';else $it618_messageisok_checked="";

$yytime_isok=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isok');

if($yytime_isok==1){
	$yytime_isoktime=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isoktime');
	if($yytime_isoktime=='')$yytime_isoktime=$it618_waimai_lang['s210'];
	$yytimestr=$it618_waimai_lang['s211'].'<font color=#f80>'.$yytime_isoktime.'</font> '.$it618_waimai_lang['s212'];
}else{
	$yytime_isokbz=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isokbz');
	$yytimestr=$it618_waimai_lang['s213'].'<font color=#f80>'.$yytime_isokbz.'</font> '.$it618_waimai_lang['s214'];
}

$tmp=str_replace("{pmoney}",$it618_waimai_waimai['it618_adminpmoney'],$it618_waimai_lang['s790']);

if($it618_waimai_waimai['it618_peitype']==0){
	$tmparr=explode(",",$it618_waimai_waimai['it618_rwpmids']);
	for($i=0;$i<count($tmparr);$i++){
		$pmuid=intval($tmparr[$i]);
		if($rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($pmuid)){
			$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$pmuid);
			$tmppmname.=$rwpeimantmp['id'].'-'.$rwpeimantmp['it618_name'].'-'.$username.'('.$pmuid.'),';
		}
	}
	
	if($tmppmname!=''){
		$tmppmname.='@';	
		$tmppmname=str_replace(",@","",$tmppmname);
		$tmppmname='<br>'.$tmppmname;
	}
	
	$it618_peitype='<tr><td>'.it618_waimai_getlang('s405').'</td><td><input type="text" class="txt" style="width:600px;color:blue;margin-bottom:3px" name="it618_rwpmids" value="'.$it618_waimai_waimai['it618_rwpmids'].'"> <font color=#999>'.it618_waimai_getlang('s406').'</font>'.$tmppmname.'<br><font color=#999>'.it618_waimai_getlang('s407').'</font></td></tr>';
}

$sc_data.='
<tr><td width=68 style="padding:0;height:0;border:none"></td><td style="padding:0;height:0;border:none"></td></tr>
<tr><td colspan=2><strong>'.it618_waimai_getlang('t42').'</strong></td></tr>
<tr><td width=110>'.it618_waimai_getlang('s684').'</td><td><input type="checkbox" id="it618_isok" name="it618_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.it618_waimai_getlang('s685').'</label></td></tr>
<tr><td>'.it618_waimai_getlang('s686').'</td><td><input type="text" class="txt" style="width:100%;margin-bottom:3px" name="it618_isokbz" value="'.$it618_waimai_waimai['it618_isokbz'].'"><font color=#999>'.it618_waimai_getlang('s687').'</font></td></tr>
<tr><td>'.it618_waimai_getlang('s682').'</td><td><b>'.$yytimestr.'</b><br><br><input type="text" class="txt" style="width:100%;margin-bottom:3px;color:blue" name="it618_isoktime" value="'.$it618_waimai_waimai['it618_isoktime'].'"><font color=#999>'.it618_waimai_getlang('s683').'</font></td></tr>
<tr><td>'.it618_waimai_getlang('s680').'</td><td><input type="text" class="txt" style="width:100%;color:#390" name="it618_pmoney" value="'.$it618_waimai_waimai['it618_pmoney'].'"><font color=#999>'.it618_waimai_getlang('s681').'</font> '.$tmp.'</td></tr>
'.$it618_peitype.'
<tr><td>'.it618_waimai_getlang('s282').'</td><td><input type="text" class="txt" style="width:100%;color:red" name="it618_moneybz" value="'.$it618_waimai_waimai['it618_moneybz'].'"><font color=#999>'.it618_waimai_getlang('s283').'</font></td></tr>

<tr><td colspan=2><strong>'.it618_waimai_getlang('t43').'</strong></td></tr>
<tr><td width=110>'.it618_waimai_getlang('s633').'</td><td><input type="checkbox" id="it618_messageisok" name="it618_messageisok" value="1" style="vertical-align:middle" '.$it618_messageisok_checked.'> <label for="it618_messageisok">'.it618_waimai_getlang('s634').'</label></td></tr>
<tr><td>'.it618_waimai_getlang('s635').'</td><td><input type="text" class="txt" style="width:100%" name="it618_messagetel" value="'.$it618_waimai_waimai['it618_messagetel'].'" maxlength="11"><font color=#999>'.it618_waimai_getlang('s636').'</font></td></tr>
<tr><td>'.it618_waimai_getlang('s325').'</td><td><input type="text" style="width:100%" name="it618_systemcount" value="'.$it618_waimai_waimai['it618_systemcount'].'"/> '.$it618_waimai_lang['s366'].'</td></tr>
<tr><td colspan="2"><input type="button" class="it618btn" style="width:100%;height:40px;font-size:15px" value="'.it618_waimai_getlang('s637').'" onclick="data_save()"/></td></tr>
';

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>