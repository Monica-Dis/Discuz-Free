<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!waimai_is_mobile()){
	$tmpurl=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc');
	dheader("location:$tmpurl");
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/shop_default.func.php';

$spanname=it618_waimai_getlang('s1712');
$navtitle=it618_waimai_getlang('s1712').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_waimai_getlang('s1005');
}

$pid=intval($_GET['cid']);
$preurl=$_GET['preurl'];
$it618_waimai_goods=C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);

if($it618_waimai_goods['it618_shopid']!=$ShopId){
	$error=1;
	$errormsg=it618_waimai_getlang('s703');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$scacurl=it618_waimai_getrewrite('waimai_wap','sc_product_type@'.$it618_waimai_goods['it618_shopid'].'@0@'.$it618_waimai_goods['id'].'@0','plugin.php?id=it618_waimai:wap&pagetype=sc_product_type&sid='.$it618_waimai_goods['it618_shopid'].'&cid='.$it618_waimai_goods['id']);

if($it618_cpmsg!=''||$error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_waimai_goods_type')." WHERE it618_pid=".$pid);

$sc_prodect_str.= '<tr><td colspan=8 style="padding-top:10px;padding-bottom:10px">'.$it618_waimai_lang['s1714'].$count.'</td></tr>
<tr><th></th><th style="text-align:left">'.$it618_waimai_lang['s1287'].'/'.$it618_waimai_lang['s1722'].'/'.$it618_waimai_lang['s1718'].'</th><th>'.$it618_waimai_lang['s1717'].'</th><th>'.$it618_waimai_lang['s1713'].'</th></tr>
';

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_goods_type')." WHERE it618_pid=".$pid." ORDER BY it618_name");
while($it618_waimai_goods_type = DB::fetch($query)) {

	$salecount = C::t('#it618_waimai#it618_waimai_sale')->sumcount_by_it618_gtypeid($it618_waimai_goods_type['id']);
	$disabled="";
	if($salecount>0)$disabled="disabled=\"disabled\"";
	if($it618_waimai_goods_type['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
	
	$sc_prodect_str.= '<tr>
		<td width="15"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_waimai_goods_type['id'].'" '.$disabled.'></td>
		<td>
		<input type="text" class="txt" style="width:63%;padding-left:3px" name="it618_name['.$it618_waimai_goods_type['id'].']" value="'.$it618_waimai_goods_type['it618_name'].'">
		<input class="checkbox" type="checkbox" name="it618_ison['.$it618_waimai_goods_type['id'].']" '.$it618_ison_checked.' value="1"></span>
		<font color=red>'.$salecount.'</font></span>
		</td>
		<td width="80"><input type="text" class="txt" style="width:90%;color:red;padding-left:3px" name="it618_uprice['.$it618_waimai_goods_type['id'].']" value="'.$it618_waimai_goods_type['it618_uprice'].'"></td>
		<td width="80">
		<input type="text" class="txt" style="width:90%;color:blue;padding-left:3px" name="it618_zsscore['.$it618_waimai_goods_type['id'].']" value="'.$it618_waimai_goods_type['it618_zsscore'].'">
		</td>
		</tr>';
		
	$n=$n+1;
}
	
	global $_G;

	loadcache('plugin');
	$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
	$sc_prodect_str.= <<<EOT
	<style>.addtr{ padding-left:17px; line-height:25px; background:url(static/image/admincp/bg_repno.gif) no-repeat 0 1px; *background:url(static/image/admincp/bg_repno.gif) no-repeat 0 0; color:#F60; }</style>
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:63%;padding-left:3px" name="newit618_name[]"> <input class="checkbox" type="checkbox" name="newit618_ison[]" checked="checked" value="1">'],
		[1,'<input type="text" class="txt" style="width:90%;color:red;padding-left:3px" name="newit618_uprice[]">'],
		[1,'<input type="text" class="txt" style="width:90%;color:blue;padding-left:3px" name="newit618_zsscore[]">'],
		[1,'']]
		];
	}
	rowtypedata=rundata();
	
	var addrowdirect = 0;
	var addrowkey = 0;
	function addrow(obj, type) {
		var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
		if(!addrowdirect) {
			var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
		} else {
			var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
		}
		var typedata = rowtypedata[type];
		for(var i = 0; i <= typedata.length - 1; i++) {
			var cell = row.insertCell(i);
			cell.colSpan = typedata[i][0];
			var tmp = typedata[i][1];
			if(typedata[i][2]) {
				cell.className = typedata[i][2];
			}
			tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
			tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return addrow.arguments[parseInt($2) + 1];});
			cell.innerHTML = tmp;
		}
		addrowkey ++;
		addrowdirect = 0;
	}
	</script>
EOT;
	$sc_prodect_str.= '<tr><td colspan=8><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_waimai_lang['s128'].'</a></div></td></tr>';
	
$sc_prodect_str.= '<tr><td colspan=8><input type="hidden" id="tmpn" value="'.$n.'"><input type="checkbox" style="vertical-align:middle" name="chkall" id="chk_del'.$n.'" class="checkbox" onclick="check_all(this, \'chk_del\')" /><label for="chk_del'.$n.'">'.it618_waimai_getlang('s70').'</label> <input type="button" class="it618btn1" value=" '.$it618_waimai_lang['s120'].' " onclick="product_type_save()"/></td></tr>';

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>