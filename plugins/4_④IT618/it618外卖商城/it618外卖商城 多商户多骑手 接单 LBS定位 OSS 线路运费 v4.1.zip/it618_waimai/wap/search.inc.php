<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cid=intval($_GET['sid']);
if(!waimai_is_mobile()){
	if($cid>0){
		$tmpurl=it618_waimai_getrewrite('waimai_list',$cid,'plugin.php?id=it618_waimai:list&class1='.$cid);
	}else{
		$tmpurl=it618_waimai_getrewrite('waimai_list','','plugin.php?id=it618_waimai:list');
	}
	dheader("location:$tmpurl");
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$navtitle=$it618_waimai_lang['s1307'].' - '.$sitetitle;

$n=1;
if($cid>0){
	$current='';
}else{
	$current='class="current"';
}
$classtmp='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'shopclass1\',0,0)" name="shopclass1"><span>'.$it618_waimai_lang['t298'].'</span><i></i></a>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class')." where it618_img='' ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	if($it618_tmp['id']==$cid){
		$current='class="current"';
		$classjs='setselect(\'productclass1\','.$n.','.$it618_tmp['id'].');';
	}else{
		$current='';
	}
	$classtmp.='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'shopclass1\','.$n.','.$it618_tmp['id'].')" name="shopclass1"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
	$n=$n+1;
}

$n=1;
$areatmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'shoparea1\',0,0)" name="shoparea1"><span>'.$it618_waimai_lang['t298'].'</span><i></i></a>';
foreach(C::t('#it618_waimai#it618_waimai_waimai_area')->fetch_all_by_search() as $it618_tmp) {
	$areatmp.='<a href="javascript:void(0)" onclick="setselect(\'shoparea1\','.$n.','.$it618_tmp['id'].')" name="shoparea1"><span>'.$it618_tmp['it618_name'].'</span><i></i></a>';
	$n=$n+1;
}

$n=1;
$waimai_hotsw=explode(',',$it618_waimai['waimai_hotsw']);
for($i=0;$i<count($waimai_hotsw);$i++){
	$hotkey.='<a href="javascript:void(0)" onclick="findbykey(\''.$waimai_hotsw[$i].'\')"><span>'.$waimai_hotsw[$i].'</span><i></i></a>';
	$n=$n+1;
}

if($_G['cache']['plugin']['it618_waimai']['rewriteurl']==0)$tmpstr='&';else $tmpstr='?';
$waimai_home=it618_waimai_getrewrite('waimai_home',$ShopId,'plugin.php?id=it618_waimai:index').$tmpstr.'app';

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>