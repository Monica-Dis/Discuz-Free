<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!waimai_is_mobile()){
	$tmpurl=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc');
	dheader("location:$tmpurl");
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/shop_default.func.php';

$navtitle=it618_waimai_getlang('s1561').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_waimai_getlang('s1005');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$it618_waimai_bank=C::t('#it618_waimai#it618_waimai_bank')->fetch_by_shopid($ShopId);
if($IsCredits==1&&in_array(1,(array)unserialize($it618_waimai['waimai_txtype'])))$tmpstr.='<option value="10">'.it618_waimai_getlang('s1918').'</option>';
if($it618_waimai_bank['it618_alipay']!=''&&in_array(2,(array)unserialize($it618_waimai['waimai_txtype'])))$tmpstr.='<option value="1">'.it618_waimai_getlang('s1919').'</option>';
if($it618_waimai_bank['it618_wx']!=''&&in_array(3,(array)unserialize($it618_waimai['waimai_txtype'])))$tmpstr.='<option value="2">'.it618_waimai_getlang('s1920').'</option>';
if($it618_waimai_bank['it618_bankid']!=''&&in_array(4,(array)unserialize($it618_waimai['waimai_txtype'])))$tmpstr.='<option value="3">'.it618_waimai_getlang('s1921').'</option>';

if($tmpstr=='')$tmpstr='<a href="'.$scurl5.'">'.$it618_waimai_lang['s905'].'</a>';else $tmpstr='<select name="it618_type">'.$tmpstr.'</select>';

$query1 = DB::query("SELECT * FROM ".DB::table('it618_waimai_txbl')." ORDER BY it618_num1");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<font color=red>'.$it618_tmp['it618_bl'].'%</font>('.$it618_tmp['it618_num1'].it618_waimai_getlang('s389').' - '.$it618_tmp['it618_num2'].it618_waimai_getlang('s389').'), ';
}

if($tmp==''){
	$sc_txstr='<tr><td colspan=4><font color=red>'.it618_waimai_getlang('s1049').'</font></td></tr>';
}else{
	$tmp=$tmp.'@';
	$tmp=str_replace(", @","",$tmp);
	$sc_txstr='<tr><td colspan=4><form id="it618_tx" style="line-height:33px">'.it618_waimai_getlang('s1050').$tmpstr.' '.it618_waimai_getlang('s1004').'<span id="ktxmoney" style="color:red;font-weight:bold"></span> '.it618_waimai_getlang('s389').'<br>'.it618_waimai_getlang('s1052').'<input id="it618_money" name="it618_money" class="txt" style="width:100px;height:23px;color:green;font-weight:bold;line-height:23px;font-size:18px;"/> <input type="button" class="it618btn" onclick="savetxadd()" style="width:60px;height:25px" value="'.it618_waimai_getlang('s1053').'" /><br>'.it618_waimai_getlang('s1054').'<input name="it618_bz" class="txt" style="width:80%;height:23px;color:green;font-weight:bold;line-height:23px;font-size:13px;" value="/" /></form><span style="color:#999;line-height:18px">'.it618_waimai_getlang('s1055').$tmp.'</span><br><div id="txtip" style="color:red;margin-top:5px"></div></td></tr>';
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>