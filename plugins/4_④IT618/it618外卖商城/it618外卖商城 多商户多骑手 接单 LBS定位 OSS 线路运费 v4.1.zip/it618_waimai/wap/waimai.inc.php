<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!waimai_is_mobile()){
	dheader("location:$homeurl");
}

foreach(C::t('#it618_waimai#it618_waimai_focus')->fetch_all_by_type_order(30) as $it618_waimai_focus) {
	if($it618_waimai_focus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_waimai_focus['it618_url'].'" target="_blank"><img class="img" src="'.it618_waimai_getwapppic('wapad'.$it618_waimai_focus['id'],$it618_waimai_focus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_waimai_getwapppic('wapad'.$it618_waimai_focus['id'],$it618_waimai_focus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_waimai_gonggao = DB::fetch($query)) {
	$it618_title=$it618_waimai_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,62,'...');
	
	if($it618_waimai_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_waimai_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_waimai_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_waimai_gonggao['it618_url'].'" title="'.$it618_waimai_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_waimai_iconav = DB::fetch($query)) {
	$it618_title=$it618_waimai_iconav['it618_title'];
	
	if($it618_waimai_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_waimai_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_waimai_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_waimai_iconav['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$it618_url=$it618_waimai_iconav['it618_url'];
	
	$str_iconav.='<td width="20%"><a href="'.$it618_url.'"'.$it618_target.'><img src="'.$it618_waimai_iconav['it618_img'].'"/><br>'.$it618_title.'</a></td>';
	
	if($n%10==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav">';
	if($n%5==0)$str_iconav.='</tr><tr>';
	
	$isiconav=1;

	$n=$n+1;
}

for($i=1;$i<=$n%5;$i++){
	$str_iconav.='<td width="20%"></td>';
}
$str_iconav.='</tr>';
$str_iconav=str_replace('<tr><td width="20%"></td></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"></tr></table></div>','',$str_iconav);

$tmpurl=it618_waimai_getrewrite('waimai_wap','search@0','plugin.php?id=it618_waimai:wap&pagetype=search');
$wapmore='<div class="wapmore"><a href="'.$tmpurl.'">'.it618_waimai_getlang('s638').it618_waimai_getlang('s639').'&gt;&gt;</a></div>';

$zjsaleshop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('zjsaleshop');
$weeksaleshop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('weeksaleshop');
$hotshop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('hotshop');
$waphomead=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('waphomead');

$tmparr=explode(",",$zjsaleshop);
if(count($tmparr)>2){
	$zjsaleshop_count=$tmparr[1];
	$zjsaleshop_order=$tmparr[2];
}else{
	$zjsaleshop_count=8;
	$zjsaleshop_order=1;
}

$tmparr=explode(",",$weeksaleshop);
if(count($tmparr)>2){
	$weeksaleshop_count=$tmparr[1];
	$weeksaleshop_order=$tmparr[2];
}else{
	$weeksaleshop_count=8;
	$weeksaleshop_order=2;
}

$tmparr=explode(",",$hotshop);
if(count($tmparr)>2){
	$hotshop_count=$tmparr[1];
	$hotshop_order=$tmparr[2];
}else{
	$hotshop_count=8;
	$hotshop_order=4;
}

if($zjsaleshop_count!=0||$weeksaleshop_count!=0||$hotshop_count!=0){

	$homegoods_arr=array("zjsaleshop"=>$zjsaleshop_order,"weeksaleshop"=>$weeksaleshop_order,"hotshop"=>$hotshop_order);
	asort($homegoods_arr);
	
	$n=1;
	foreach($homegoods_arr as $key=>$homegoods){
		if($n==1)$current=' class="current"';else $current=' ';
		if($home_shop_js=='')$home_shop_js='get_home_shop("'.$key.'");';
		
		if($key=='zjsaleshop'){
			$tab_goods.='<li'.$current.'onclick="it618_waimai_tabChange(this,\'searchli_bd\');get_home_shop(\''.$key.'\');">'.$it618_waimai_lang['t345'].'</li>';
		}
		
		if($key=='weeksaleshop'){
			$tab_goods.='<li'.$current.'onclick="it618_waimai_tabChange(this,\'searchli_bd\');get_home_shop(\''.$key.'\');">'.$it618_waimai_lang['t347'].'</li>';
		}
		
		if($key=='hotshop'){
			$tab_goods.='<li'.$current.'onclick="it618_waimai_tabChange(this,\'searchli_bd\');get_home_shop(\''.$key.'\');">'.$it618_waimai_lang['t548'].'</li>';
		}
		
		if($n==1)$bdstyle=' ;display:';else $bdstyle=' ;display:none';
		$home_shop.='<dl class="list" id="searchli_bd'.($n-1).'" style="border-top:none; margin:0;'.$bdstyle.'">
						<dd><dl style="padding:0;padding-bottom:10px">
							<dd>
							<div style="-webkit-overflow-scrolling:touch;overflow:scroll;">
							<table class="tablelist3" id="home_shop_'.$key.'">
							<tr><td><font color=#999>'.$it618_waimai_lang['s1306'].'</font></td></tr>
							</table>
							</div>
							</dd>
						</dl></dd>
					  </dl>';
		
		$n=$n+1;
	}
	
	$homegoods_str='<ul class="searchli1">'.$tab_goods.'</ul><div id="home_shop">'.$home_shop.'</div>';
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>