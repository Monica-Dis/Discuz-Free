<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$oid=intval($_GET['oid']);
$cid=intval($_GET['cid']);

if(isset($_GET['sid'])){
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_id($_GET['sid'])>0){
		$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
		$it618_state=$it618_waimai_waimai['it618_state'];
		if($it618_state==0){
			$error=1;$errormsg=it618_waimai_getlang('s380');
		}elseif($it618_state==1){
			$error=1;$errormsg=it618_waimai_getlang('s380');
		}else{
			$it618_htstate=$it618_waimai_waimai['it618_htstate'];
			if($it618_htstate==0){
				$error=1;$errormsg=it618_waimai_getlang('s381');
			}elseif($it618_htstate==2){
				$error=1;$errormsg=it618_waimai_getlang('s382');
			}else{
				$ShopId=$it618_waimai_waimai['id'];
				$ShopUid=$it618_waimai_waimai['it618_uid'];
				$ShopName=$it618_waimai_waimai['it618_name'];
				$ShopZSSCORE=$it618_waimai_waimai['it618_zsscore'];
				$ShopSCOREBL=$it618_waimai_waimai['it618_scorebl'];
				$ShopUPRICE=$it618_waimai_waimai['it618_uprice'];
				$Shop_power=$it618_waimai_waimai['it618_power'];
				
				$Shop_addr=$it618_waimai_waimai['it618_addr'];
				$Shop_yytime=$it618_waimai_waimai['it618_isoktime'];
				$Shop_dianhua=$it618_waimai_waimai['it618_dianhua'];
				$Shop_shouji=$it618_waimai_waimai['it618_shouji'];
				$Shop_about=$it618_waimai_waimai['it618_about'];
				$Shop_kefuqq=$it618_waimai_waimai['it618_kefuqq'];
				$Shop_kefuwx=$it618_waimai_waimai['it618_kefuwx'];
				$Shop_kefuqqname=$it618_waimai_waimai['it618_kefuqqname'];
				
				$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
				$ShopPower=$it618_waimai_waimaigroup['it618_groupname'];
				if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" align="absmiddle" style="margin-top:-1px"/>';
				$Shop_goodscount=$it618_waimai_waimaigroup['it618_goodscount'];
				
				$pjcount=C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pj_shopid($ShopId);
				$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$pjcount);
				
				$shopstr.='<b>'.$ShopName.'</b><br>';
				$shopstr.='<font color=#999>'.it618_waimai_getlang('s1295').'</font>'.$ShopPower.'<br>';
				$shopstr.='<font color=#999>'.it618_waimai_getlang('s1296').'</font>'.'<img style="vertical-align:middle;margin-top:-3px" src="'.$it618_waimai_level['it618_img'].'"><br>';
				if($Shop_addr!='')$shopstr.='<font color=#999>'.it618_waimai_getlang('s418').'</font>'.$Shop_addr.'<br>';
				if($Shop_dianhua!='')$shopstr.='<font color=#999>'.it618_waimai_getlang('s419').'</font>'.'<a href="tel://'.$Shop_dianhua.'">'.$Shop_dianhua.'</a><br>';
				if($Shop_shouji!='')$shopstr.='<font color=#999>'.it618_waimai_getlang('s420').'</font>'.'<a href="tel://'.$Shop_shouji.'">'.$Shop_shouji.'</a><br>';
				if($Shop_about!='')$shopstr.='<font color=#999>'.it618_waimai_getlang('s1303').'</font>'.$Shop_about.'<br>';
				$yytime_isoktime=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isoktime');
				if($Shop_yytime!='')$shopstr.='<font color=#999>'.it618_waimai_getlang('s1540').'</font>'.$it618_waimai_lang['s682'].$Shop_yytime.' '.$it618_waimai_lang['s211'].$yytime_isoktime.'<br>';
				if($Shop_kefuqq!=''){
					$qqarr=explode(",",$Shop_kefuqq);
					$wxarr=explode(",",$Shop_kefuwx);
					$qqnamearr=explode(",",$Shop_kefuqqname);
					for($i=0;$i<count($qqarr);$i++)
					{
						$qqstr='';$wxstr='';
						if($qqnamearr[$i]!=''){
							if($qqarr[$i]!='')$qqstr='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:'.$qqarr[$i].':52" alt="'.it618_waimai_getlang('s422').'" align="absmiddle" title="'.it618_waimai_getlang('s422').'"/></a>'.$qqarr[$i].' ';
							if($wxarr[$i]!='')$wxstr='<font color=#999>'.$it618_waimai_lang['s1051'].':</font>'.$wxarr[$i].'<br>';
							
							$shopstr.='<font color=#999>'.$qqnamearr[$i].$it618_waimai_lang['s53'].'</font>'.$qqstr.$wxstr;
						}
					}
					
				}
				if($Shop_fahuo!='')$shopstr.=$Shop_fahuo;
				
				$shophomeurl=it618_waimai_getrewrite('waimai_wap','shop@'.$ShopId,'plugin.php?id=it618_waimai:wap&pagetype=shop&sid='.$ShopId);
				$shophome='<li><a class="react" href="'.$shophomeurl.'">'.it618_waimai_getlang('s610').'</a></li>';
				
				if($it618_waimai_waimai['it618_mapurl']!=''){
					$mapurl="<a href='{$it618_waimai_waimai['it618_mapurl']}' target='_blank' style='cursor:pointer;background-color:#390; padding:3px 13px; font-size:13px; float:left;margin-top:10px;color:#fff;text-decoration:none;'>".$it618_waimai_lang['s1842']."</a>";	
				}
			}
		}
		
		if($it618_waimai_waimai['it618_lbslat']==0){
			$error=1;$errormsg=it618_waimai_getlang('s881');
		}
		
	}else{
		$error=1;$errormsg=it618_waimai_getlang('s380');
	}
}else{
	$error=1;$errormsg=it618_waimai_getlang('s383');
}

if($pagetype=='sc_product'||$pagetype=='sc_product_add'||$pagetype=='sc_product_edit'||$pagetype=='sc_product_type'){
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid'])>0){
		$it618_waimai_waimaitmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_waimai_waimaitmp['it618_uid']){
			$error=1;
			$errormsg=it618_waimai_getlang('s703');
		}
	}else{
		$error=1;
		$errormsg=it618_waimai_getlang('s703');
	}
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

$scurl1=it618_waimai_getrewrite('waimai_wap','sc_product@'.$ShopId,'plugin.php?id=it618_waimai:wap&pagetype=sc_product&sid='.$ShopId);
$scurl2=it618_waimai_getrewrite('waimai_wap','sc_product_add@'.$ShopId,'plugin.php?id=it618_waimai:wap&pagetype=sc_product_add&sid='.$ShopId);
$scurl4=it618_waimai_getrewrite('waimai_wap','sc_tx@'.$ShopId,'plugin.php?id=it618_waimai:wap&pagetype=sc_tx&sid='.$ShopId);
$scurl5=it618_waimai_getrewrite('waimai_wap','sc_bank@'.$ShopId,'plugin.php?id=it618_waimai:wap&pagetype=sc_bank&sid='.$ShopId);

$pid=intval($_GET['pid']);
$uid = $_G['uid'];
?>