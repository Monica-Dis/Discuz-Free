<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!waimai_is_mobile()){
	$tmpurl=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc');
	dheader("location:$tmpurl");
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/shop_default.func.php';

$spanname=it618_waimai_getlang('s1660');
$navtitle=it618_waimai_getlang('s1660').' - '.$sitetitle;

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_waimai_getlang('s1005');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_waimai:wap_waimai');
	return;
}

foreach(C::t('#it618_waimai#it618_waimai_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class_id'].'>','<option value='.$_GET['it618_class_id'].' selected="selected">',$tmp);

$sc_prodect_str1 = '<tr><td style="padding-bottom:6px;line-height:28px"><input id="pname" class="txt" style="width:80%;height:23px;border:#e8e8e8 1px solid" /> <input type="button" class="it618btn1" style="width:18%" onclick="searchscproduct()" value="'.it618_waimai_getlang('s34').'" /><br><select id="pclassid" style="line-height:12px;width:50%;height:26px;border:#e8e8e8 1px solid"><option value="0">'.it618_waimai_getlang('s233').'</option>'.$tmp1.'</select><select id="pstate" style="line-height:12px;width:50%;height:26px;border:#e8e8e8 1px solid;border-left:none"><option value=0 '.$state0.'>'.it618_waimai_getlang('s235').'</option><option value=1 '.$state1.'>'.it618_waimai_getlang('s240').'</option><option value=2 '.$state2.'>'.it618_waimai_getlang('s241').'</option></select></td></tr>';

	
$sc_prodect_str2 = '
<tr><td><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="check_all(this, \'chk_del\')" /><label for="chkallDx4b">'.it618_waimai_getlang('s70').'</label> <input type="button" class="it618btn1" value="'.it618_waimai_getlang('s261').'" onclick="if(confirm(\''.it618_waimai_getlang('s262').'\'))scproduct_save(\'del\')" /> <input type="button" class="it618btn1" value="'.it618_waimai_getlang('s263').'" onclick="scproduct_save(\'edit\')"/> <input type="checkbox" id="chk_ison" class="checkbox" onclick="check_all(this, \'chk_ison\')" /><label for="chk_ison">'.it618_waimai_getlang('s240').'</label><br><br><font color="blue">'.it618_waimai_getlang('s846').'<font color=red>'.$ShopUPRICE.'</font> '.it618_waimai_getlang('s847').'<font color=red>'.$ShopZSSCORE.'</font>)</font> '.it618_waimai_getlang('s1242').'</font></td></tr>';


$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:wap_waimai');
?>