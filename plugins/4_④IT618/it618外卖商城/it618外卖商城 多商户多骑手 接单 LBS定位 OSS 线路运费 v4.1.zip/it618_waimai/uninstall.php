<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_diy'));
while($it618_waimai_diy = DB::fetch($query)) {
	runquery("delete from ".DB::table('common_block')." where name = '".$it618_waimai_diy['it618_name']."'");
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_waimai_waimai`;

DROP TABLE IF EXISTS `pre_it618_waimai_waimaigroup`;

DROP TABLE IF EXISTS `pre_it618_waimai_peiman`;

DROP TABLE IF EXISTS `pre_it618_waimai_style`;

DROP TABLE IF EXISTS `pre_it618_waimai_nav`;

DROP TABLE IF EXISTS `pre_it618_waimai_wapstyle`;

DROP TABLE IF EXISTS `pre_it618_waimai_iconav`;

DROP TABLE IF EXISTS `pre_it618_waimai_waimai_area`;

DROP TABLE IF EXISTS `pre_it618_waimai_waimai_area1`;

DROP TABLE IF EXISTS `pre_it618_waimai_waimai_class`;

DROP TABLE IF EXISTS `pre_it618_waimai_waimai_class1`;

DROP TABLE IF EXISTS `pre_it618_waimai_class`;

DROP TABLE IF EXISTS `pre_it618_waimai_focus`;

DROP TABLE IF EXISTS `pre_it618_waimai_gonggao`;

DROP TABLE IF EXISTS `pre_it618_waimai_goods`;

DROP TABLE IF EXISTS `pre_it618_waimai_goods_type`;

DROP TABLE IF EXISTS `pre_it618_waimai_gwc`;

DROP TABLE IF EXISTS `pre_it618_waimai_gwcsale_main`;

DROP TABLE IF EXISTS `pre_it618_waimai_gwcsale`;

DROP TABLE IF EXISTS `pre_it618_waimai_sale`;

DROP TABLE IF EXISTS `pre_it618_waimai_set`;

DROP TABLE IF EXISTS `pre_it618_waimai_diy`;

DROP TABLE IF EXISTS `pre_it618_waimai_bank`;

DROP TABLE IF EXISTS `pre_it618_waimai_txbl`;

DROP TABLE IF EXISTS `pre_it618_waimai_tx`;

DROP TABLE IF EXISTS `pre_it618_waimai_collect`;

DROP TABLE IF EXISTS `pre_it618_waimai_salework`;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>