<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

if($reabc[4]!='8')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function/it618_waimai.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_waimai&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_waimai', 'admin_waimaiyunfei', 'admin_waimaigroup');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_waimai' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].''.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_waimai'.$urls.'"><span>'.$it618_waimai_lang['s33'].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_waimaigroup'.$urls.'"><span>'.$it618_waimai_lang['s1620'].'</span></a></li>
</ul></div>';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();/*Dism_taobao-com*/
?>