<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/waimai_function.func.php';

function it618_waimai_getmodecontent($modetype,$modecode,$modecount){
	global $_G;
	$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
	
	$tmparr=explode("[loop]",$modecode);
	$tmparr1=explode("[/loop]",$tmparr[1]);
	
	if($modetype=='waimai_new'||$modetype=='waimai_hot'){
		if($modetype=='waimai_new')$orderby='id desc';else $orderby='it618_moneysum desc';
		$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai')." where it618_state=2 and it618_htstate=1 order by $orderby limit 0,".$modecount);
		while($it618_waimai_waimai = DB::fetch($query)) {
			
			$tmpurl=it618_waimai_getrewrite('shop_home',$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:shop&sid='.$it618_waimai_waimai['id']);
			if($it618_waimai_waimai['it618_power']==0)$it618_power=it618_waimai_getlang('s38');
			if($it618_waimai_waimai['it618_power']==1)$it618_power=it618_waimai_getlang('s39');
		
			$tmpstr=str_replace("{bname}",$it618_waimai_waimai['it618_name'],$tmparr1[0]);
			$tmpstr=str_replace("{blogosrc}",$it618_waimai_waimai['it618_logo'],$tmpstr);
			$tmpstr=str_replace("{baddr}",$it618_waimai_waimai['it618_addr'],$tmpstr);
			$tmpstr=str_replace("{bdianhua}",$it618_waimai_waimai['it618_dianhua'],$tmpstr);
			$tmpstr=str_replace("{bshouji}",$it618_waimai_waimai['it618_shouji'],$tmpstr);
			$tmpstr=str_replace("{bpower}",$it618_power,$tmpstr);
			$tmpstr=str_replace("{burl}",$tmpurl,$tmpstr);
			
			$content.=$tmpstr;
			
		}
	}
	
	$content=$tmparr[0].$content.$tmparr1[1];
	$content=str_replace("{siteurl}",$_G['siteurl'],$content);
	
	return $content;
}

function str_substr($start, $end, $str)
{
    $temp = explode($start, $str, 2);
    $content = explode($end, $temp[1], 2);
    return $content[0];
} 

?>