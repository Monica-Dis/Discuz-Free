<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/lang.func.php';

if(isset($_GET['sid'])){
	if($_GET['sid']==0){
		return;
	}
	
	if(isset($_GET['adminsid'])){
		$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$sid=$_GET['adminsid'];
		}else{
			echo it618_waimai_getlang('s1220');exit;
		}
	}else{
		$sid=$_GET['sid'];
	}
	
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_id($sid)>0){
		$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($sid);
		$it618_state=$it618_waimai_waimai['it618_state'];
		if($it618_state==0){
			echo it618_waimai_getlang('s380');exit;
		}elseif($it618_state==1){
			echo it618_waimai_getlang('s380');exit;
		}else{
			$it618_htstate=$it618_waimai_waimai['it618_htstate'];
			if($it618_htstate==0){
				echo it618_waimai_getlang('s381');exit;
			}elseif($it618_htstate==2){
				echo it618_waimai_getlang('s382');exit;
			}else{
				$ShopId=$it618_waimai_waimai['id'];
				$ShopName=$it618_waimai_waimai['it618_name'];
				$ShopUid=$it618_waimai_waimai['it618_uid'];
				
				$Shop_area_id=$it618_waimai_waimai['it618_area_id'];
				$Shop_logo=$it618_waimai_waimai['it618_logo'];
				
				$Shop_systemcount=$it618_waimai_waimai['it618_systemcount'];
				$Shop_addr=$it618_waimai_waimai['it618_addr'];
				$Shop_kdaddr=$it618_waimai_waimai['it618_kdaddr'];
				$Shop_dianhua=$it618_waimai_waimai['it618_dianhua'];
				$Shop_shouji=$it618_waimai_waimai['it618_shouji'];
				$Shop_kefuqq=$it618_waimai_waimai['it618_kefuqq'];
				$Shop_kefuwx=$it618_waimai_waimai['it618_kefuwx'];
				$Shop_kefuqqname=$it618_waimai_waimai['it618_kefuqqname'];
				$Shop_yytime=$it618_waimai_waimai['it618_yytime'];
				$Shop_mappoint=$it618_waimai_waimai['it618_mappoint'];
				
				$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
				$ShopPower=$it618_waimai_waimaigroup['it618_groupname'];
				if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" align="absmiddle" style="margin-top:-1px"/>';
			}
		}
		
	}else{
		echo it618_waimai_getlang('s380');exit;
	}
}else{
	$flag=0;
	if($_GET['ac']=='getwaimaiarea'||$_GET['ac']=='getwaimaiclass'||$_GET['ac']=='getshopclass'||$_GET['ac']=='getshoparea'||$_GET['ac']=='getfindkey'||$_GET['ac']=='delfindkey'||$_GET['ac']=='clearfindkey'||$_GET['ac']=='renzheng'||$_GET['ac']=='sqpeiman'||$_GET['ac']=='pmlbs_save'||$_GET['ac']=='sale_admingetsale'||$_GET['ac']=='sale_adminsqfahuo'||$_GET['ac']=='sale_fahuo'||$_GET['ac']=='sale_shopfahuo'||$_GET['ac']=='sale_isrwpmpower'||$_GET['ac']=='sale_getrw'||$_GET['ac']=='sale_pmgetok'||$_GET['ac']=='rwlist_get'||$_GET['ac']=='sale_jujuetui'||$_GET['ac']=='sale_tongyitui'||$_GET['ac']=='sale_tuihuo'||$_GET['ac']=='sale_salepj'||$_GET['ac']=='sale_pmpj'||$_GET['ac']=='sale_showsale'||$_GET['ac']=='sale_shouhuo'||$_GET['ac']=='getwaimailist'||$_GET['ac']=='myright'||$_GET['ac']=='home_shop'||$_GET['ac']=='goodslist_get'||$_GET['ac']=='mysalelist_get'||$_GET['ac']=='myrwpmlist_get'||$_GET['ac']=='mypmlist_get'||$_GET['ac']=='getsalemaxid'||$_GET['ac']=='sale_dao'||$_GET['ac']=='sale_get'||$_GET['ac']=='pj_get'||$_GET['ac']=='collectlist_get'||$_GET['ac']=='gwclist_get'||$_GET['ac']=='delcollect'||$_GET['ac']=='delgwc'||$_GET['ac']=='cleargwc'||$_GET['ac']=='gwcminus'||$_GET['ac']=='gwcplus'||$_GET['ac']=='gwcpay_add'||$_GET['ac']=='waimailist_get'||$_GET['ac']=='imgdelete'||$_GET['ac']=='getgwcshopid'||$_GET['ac']=='payok'||$_GET['ac']=='getsaleaudio'||$_GET['ac']=='it618_waimai_getmapapi'){
		$flag=1;
	}
	if($flag==0){
		echo it618_waimai_getlang('s383');exit;
	}
}
//From: Dism��taobao��com
?>