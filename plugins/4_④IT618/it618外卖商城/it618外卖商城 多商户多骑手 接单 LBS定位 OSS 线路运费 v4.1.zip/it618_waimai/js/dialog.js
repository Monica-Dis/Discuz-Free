var dialog_sale;
KindEditor.ready(function(K) {K('.glb_orgbtn_l').click(function() {
	IT618_WAIMAI.get("{$_G['siteurl']}plugin.php?id=it618_waimai:showsale&pid={$it618_waimai_goods['id']}&formhash={FORMHASH}", {ac:"visit_get"},function (data, textStatus){
	dialog_sale = K.dialog({
		width : 625,
		title : '�һ���Ʒ',
		body : '<div style="padding:5px">'+data+'</div>',
		closeBtn : {
			name : '�ر�',
			click : function(e) {
				dialog_sale.remove();
			}
		},
	});
	}, "html");	
});});

var dialog_addr;
KindEditor.ready(function(K) {K('#tmpaddrbtn').click(function() {
	IT618_WAIMAI.get("{$_G['siteurl']}plugin.php?id=it618_waimai:showaddr&formhash={FORMHASH}", {ac:"add"},function (data, textStatus){
	IT618_WAIMAI.get("{$_G['siteurl']}plugin.php?id=it618_waimai:ajax&formhash={FORMHASH}", {ac:"addr_get"},function (data1, textStatus){
	dialog_addr = K.dialog({
		width : 900,
		height: 420,
		title : '�ջ���ַ����',
		body : '<div style="padding:5px"><div id="addrlist">'+data1+'</div>'+data+'</div>',
		closeBtn : {
			name : '�ر�',
			click : function(e) {
				dialog_addr.remove();
			}
		},
	});
	}, "html");	}, "html");	
});});