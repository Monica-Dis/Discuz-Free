<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
$metakeywords = $it618_waimai['seokeywords'];
$metadescription = $it618_waimai['seodescription'];
$creditname=$_G['setting']['extcredits'][$it618_waimai['waimai_credit']]['title'];
$sitetitle=$it618_waimai['waimai_name'];

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$homeurl=it618_waimai_getrewrite('waimai_home','','plugin.php?id=it618_waimai:index');
$waphome=it618_waimai_getrewrite('waimai_wap','','plugin.php?id=it618_waimai:wap');
$wapu=it618_waimai_getrewrite('waimai_wap','u@0','plugin.php?id=it618_waimai:wap&pagetype=u');

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_waimai#it618_waimai_wapstyle')->count_by_isok_search();
$it618_waimai_wapstyle=C::t('#it618_waimai#it618_waimai_wapstyle')->fetch_by_isok_search();

if(isset($_GET['pagetype'])){
	$pagetypearray = array('waimai', 'shop', 'product', 'sc', 'sc_data', 'admin', 'sc_tx', 'sc_bank',  'sc_product', 'sc_product_add', 'sc_product_edit', 'sc_product_type', 'uc', 'collect', 'search', 'sale', 'gwcsale', 'rw', 'rwpm', 'pm', 'u');
	$pagetype = !in_array($_GET['pagetype'], $pagetypearray) ? 'waimai' : $_GET['pagetype'];
}else{
	$pagetype='waimai';
	$navtitle=$sitetitle;
}

$wapsearch=it618_waimai_getrewrite('waimai_wap','search@0','plugin.php?id=it618_waimai:wap&pagetype=search');

$gwccount=0;
if($_G['uid']>0){
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_waimai_getlang('s704').'</a></li>';
	$strusr='<a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="btn btn-weak">'.it618_waimai_getlang('s704').'</a> <a href="'.it618_waimai_rewriteurl($_G['uid']).'" target="_blank">'.it618_waimai_getusername($_G['uid']).'</a> '.it618_waimai_getlang('s705').$creditname.':<font color=red>'.$creditnum.'</font>';
	
	$gwccount=C::t('#it618_waimai#it618_waimai_gwc')->count_by_uid($_G['uid']);
	
	$rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($_G['uid']);
	if($rwpeimantmp['it618_state']==2){
		$ispmlbs=1;
	}
	
	if($peimantmp=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_uid($_G['uid'])){
		$ispmlbs=1;
	}
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_waimai_bottomnav = DB::fetch($query)) {
	$it618_title=$it618_waimai_bottomnav['it618_title'];
	
	if($it618_waimai_bottomnav['it618_color']!=''){
		$it618_title='<font color="'.$it618_waimai_bottomnav['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$it618_url=$it618_waimai_bottomnav['it618_url'];
	
	$it618_url=str_replace("{waphome}",$waphome,$it618_url);
	
	$it618_url=str_replace("{wapsearch}",$wapsearch,$it618_url);
	
	$tmpurl=it618_waimai_getrewrite('waimai_wap','rw@0','plugin.php?id=it618_waimai:wap&pagetype=rw');
	$it618_url=str_replace("{waprw}",$tmpurl,$it618_url);
	
	if($it618_waimai_bottomnav['id']==5)$it618_url=it618_waimai_getrewrite('waimai_wap','u@0','plugin.php?id=it618_waimai:wap&pagetype=u');
	
	if($it618_waimai_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-right:#f1f1f1 1px solid;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_waimai_bottomnav['it618_img'].'" height="20" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-right:#f1f1f1 1px solid;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_waimai_bottomnav['it618_img'].'" height="20" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$wap=1;

$waimai_wapnavs=(array)unserialize($it618_waimai['waimai_wapnavs']);
if(in_array(1, $waimai_wapnavs))$istopnav=1;
if(in_array(2, $waimai_wapnavs))$isbottomnav=1;

$sc_product=explode("sc_product",$pagetype);
if(count($sc_product)>1)$sc_product=1;

$wapfooter=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('wapfooter');

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')==false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_waimai['waimai_appid']);
	$wx_secret=trim($it618_waimai['waimai_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){

	$sid=intval($_GET['sid']);
	if($sid>0){
		$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($sid);
		$wxshare_title=$it618_waimai_waimai['it618_name'];
		$wxshare_imgUrl=$it618_waimai_waimai['it618_logo'];
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_waimai_waimai['it618_addr'].' '.$it618_waimai_waimai['it618_dianhua'].' '.$it618_waimai_waimai['it618_shouji'].' '.$it618_waimai_waimai['it618_about'];
		
	}else{
		$wxshare_title=$it618_waimai['waimai_name'];
		if($it618_waimai['waimai_wxlogo']!=''){
			$wxshare_imgUrl=$it618_waimai['waimai_wxlogo'];
		}else{
			$wxshare_imgUrl=$it618_waimai['waimai_waimailogo'];
			$tmparr=explode('src="',$wxshare_imgUrl);
			$tmparr1=explode('"',$tmparr[1]);
			$wxshare_imgUrl=$tmparr1[0];
		}
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_waimai['seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
		
		$wxshare_link=$signPackage["url"];
	}
}

global $oss;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/php/aliyunossconfig.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/php/aliyunossconfig.php';
	if($it618_isok==1){
		$oss='&oss';
	}
}

$it618_waimai_getmapapi=getcookie('it618_waimai_getmapapi');

global $_G,$it618_hongbao_lang;
$it618_credits = $_G['cache']['plugin']['it618_credits'];

if($it618_credits['seotitle']!=''){
	$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
	
	if(in_array(3,(array)unserialize($it618_hongbao['hongbao_power']))){
		if($pagetype=='waimai'||$pagetype=='search'){
			$it618_hbtype='it618_waimai_admin';
			$tid=0;
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
				if(in_array($_G['uid'],$shopadmin)){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][IN_MOBILE]='/';
			include template('it618_hongbao:hongbao');
		}
	}
	
	if(in_array(4,(array)unserialize($it618_hongbao['hongbao_power']))){
		if($pagetype=='shop'){
			$it618_hbtype='it618_waimai_shop';
			$tid=$_GET['sid'];
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$waimaitmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
				if($_G['uid']==$waimaitmp['it618_uid']&&$waimaitmp['it618_state']==2&&$waimaitmp['it618_htstate']==1){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][IN_MOBILE]='/';
			include template('it618_hongbao:hongbao');
		}
	}
}

$it618_clienid=getcookie('it618_clienid');
if($it618_clienid==''){
	$it618_clienid=md5(time());
	dsetcookie('it618_clienid',$it618_clienid,3600*24*365);
}

require DISCUZ_ROOT.'./source/plugin/it618_waimai/wap/'.$pagetype.'.inc.php';
?>