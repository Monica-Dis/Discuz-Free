<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G,$it618_waimai;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

$bdkey=trim($it618_waimai['waimai_bdkey']);

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/lang.func.php';

$mappoint=$_GET['mappoint'];
if($mappoint==''){
	$mappoint=it618_waimai_getlang('s873');
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:getpoint');
?>