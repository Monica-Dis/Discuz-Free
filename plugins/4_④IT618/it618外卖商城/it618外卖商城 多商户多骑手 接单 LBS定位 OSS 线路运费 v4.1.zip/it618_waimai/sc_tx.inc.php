<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_header.func.php';

echo '<script type="text/javascript" src="source/plugin/it618_waimai/js/jquery.js"></script>';

showtableheaders(it618_waimai_getlang('s1047').'<span style="float:right;font-weight:normal;"></span>','it618_waimai_tx');

$it618_waimai_bank=C::t('#it618_waimai#it618_waimai_bank')->fetch_by_shopid($ShopId);
if($IsCredits==1&&in_array(1,(array)unserialize($it618_waimai['waimai_txtype'])))$tmpstr.='<option value="10">'.it618_waimai_getlang('s1918').'</option>';
if($it618_waimai_bank['it618_alipay']!=''&&in_array(2,(array)unserialize($it618_waimai['waimai_txtype'])))$tmpstr.='<option value="1">'.it618_waimai_getlang('s1919').'</option>';
if($it618_waimai_bank['it618_wx']!=''&&in_array(3,(array)unserialize($it618_waimai['waimai_txtype'])))$tmpstr.='<option value="2">'.it618_waimai_getlang('s1920').'</option>';
if($it618_waimai_bank['it618_bankid']!=''&&in_array(4,(array)unserialize($it618_waimai['waimai_txtype'])))$tmpstr.='<option value="3">'.it618_waimai_getlang('s1921').'</option>';

if($tmpstr==''){
	$tmpstr='<a href="plugin.php?id=it618_waimai:sc_bank">'.$it618_waimai_lang['s905'].'</a>';
	$txbtncss='display:none';
}else{
	$tmpstr='<select name="it618_type">'.$tmpstr.'</select>';
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_waimai_txbl')." ORDER BY it618_num1");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<font color=red>'.$it618_tmp['it618_bl'].'%</font>('.$it618_tmp['it618_num1'].it618_waimai_getlang('s389').' - '.$it618_tmp['it618_num2'].it618_waimai_getlang('s389').'), ';
}

if($tmp==''){
	echo '<tr><td colspan=4><font color=red>'.it618_waimai_getlang('s1049').'</font></td></tr>';
}else{
	$tmp=$tmp.'@';
	$tmp=str_replace(", @","",$tmp);
	echo '<tr><td colspan=4 style="line-height:23px"><form id="it618_tx">'.it618_waimai_getlang('s1050').$tmpstr.' '.it618_waimai_getlang('s1052').'<input id="it618_money" name="it618_money" class="txt" style="width:100px;height:18px;color:green;font-weight:bold;line-height:18px;font-size:20px;"/><input type="button" class="btn" onclick="savetxadd()" style="width:60px;height:25px;'.$txbtncss.'" value="'.it618_waimai_getlang('s1053').'" /> '.it618_waimai_getlang('s1004').'<span id="ktxmoney" style="color:red;font-weight:bold"></span> '.it618_waimai_getlang('s389').'
	<br>'.it618_waimai_getlang('s1054').'<input name="it618_bz" class="txt" style="width:700px;height:18px;color:green;font-weight:bold;line-height:18px;font-size:13px;" value="/" /></form>'.it618_waimai_getlang('s1055').$tmp.'<div id="txtip" style="color:red;margin-top:5px"></div></td></tr>';
}

	
showtablefooter();

showtableheaders(it618_waimai_getlang('s1056'),'it618_waimai_tx');
echo '
<tr><td colspan=10 style="line-height:30px">'.it618_waimai_getlang('s950').' <select id="it618_type"><option value="0">'.it618_waimai_getlang('s951').'</option><option value="10">'.it618_waimai_getlang('s1918').'</option><option value="1">'.it618_waimai_getlang('s1919').'</option><option value="2">'.it618_waimai_getlang('s1920').'</option><option value="3">'.it618_waimai_getlang('s1921').'</option></select> '.it618_waimai_getlang('s955').' <select id="it618_state"><option value="0">'.it618_waimai_getlang('s956').'</option><option value="1">'.it618_waimai_getlang('s957').'</option><option value="2">'.it618_waimai_getlang('s958').'</option></select> '.it618_waimai_getlang('s954').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> - <input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> <input type="button" class="btn" style="width:60px;height:25px" onclick="findtx()" value="'.it618_waimai_getlang('s912').'" /></td></tr>
<tr><td colspan=10 style="line-height:30px" id="txsum"></td></tr>
<tr class="header"><th>'.it618_waimai_getlang('s961').'</th><th>'.it618_waimai_getlang('s962').'</th><th>'.it618_waimai_getlang('s963').'</th><th>'.it618_waimai_getlang('s964').'</th><th>'.it618_waimai_getlang('s965').'</th><th>'.it618_waimai_getlang('s966').'</th><th>'.it618_waimai_getlang('s968').'</th><th>'.it618_waimai_getlang('s969').'</th></tr>
<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_waimai/wap/images/loading.gif"></td></tr><tbody id="txlist"></tbody>';
showtablefooter();
echo '
<script charset="utf-8" src="source/plugin/it618_waimai/js/Calendar.js"></script>
<script>

var url="'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax&page=1";
function gettxlist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("txlist").style.display="none";
	IT618_WAIMAI.get(url+"'.$adminsid.'&sid='.$ShopId.'&formhash='.FORMHASH.'", {ac:"tx_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_WAIMAI("#txsum").html(tmparr[1]);
	IT618_WAIMAI("#txlist").html(tmparr[2]);
	IT618_WAIMAI("#ktxmoney").html(tmparr[0]);
	self.parent.frames["topFrame"].getsc_top();
	document.getElementById("img_loading").style.display="none";
	document.getElementById("txlist").style.display="";
	}, "html");	
	
}
gettxlist(url);

function findtx(){
	var it618_time1=document.getElementById("it618_time1").value;
	var it618_type=document.getElementById("it618_type").value;
	var it618_time2=document.getElementById("it618_time2").value;
	var it618_state=document.getElementById("it618_state").value;
	gettxlist("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax'.$adminsid.'&sid='.$ShopId.'&it618_type="+it618_type+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2+"&it618_state="+it618_state+"&page=1");
}

function savetxadd(){
	var it618_money=document.getElementById("it618_money").value;
	
	if(it618_money==""){
		sendmsg(\'txtip\',"'.it618_waimai_getlang('s1057').'");
		return false;
	}
	
	IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax'.$adminsid.'&sid='.$ShopId.'&ac=tx_add&formhash='.FORMHASH.'", IT618_WAIMAI("#it618_tx").serialize(),function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="ok"){
		gettxlist(url);
		sendmsg(\'txtip\',tmparr[1]);
	}else{
		sendmsg(\'txtip\',data);
	}
	}, "html");	
}

function deltx(txid){
	if(confirm(\''.it618_waimai_getlang('s1058').'\'))
	IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax'.$adminsid.'&sid='.$ShopId.'&txid="+txid+"&formhash='.FORMHASH.'", {ac:"tx_del"},function (data, textStatus){
	if(data=="ok"){
		gettxlist(url);
	}else{
		sendmsg(\'txtip\',data);	
	}
	}, "html");	
}

function sendmsg(msgid,msgvalue){
	document.getElementById(msgid).innerHTML=msgvalue;
	setTimeout(\'sendmsg1("\'+msgid+\'")\',8000);
}
function sendmsg1(msgid){
	document.getElementById(msgid).innerHTML="";
}

</script>
';

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_footer.func.php';
?>