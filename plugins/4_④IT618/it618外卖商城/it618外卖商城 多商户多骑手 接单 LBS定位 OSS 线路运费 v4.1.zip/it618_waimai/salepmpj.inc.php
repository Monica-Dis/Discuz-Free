<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$saleid=intval($_GET['saleid']);

if(!($it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($saleid))){
	echo 'alertit618_split'.it618_waimai_getlang('s1110');exit;
}

$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);

$tmpstr1=$it618_waimai_lang['s356'];
if($it618_waimai_gwcsale_main['it618_pj']>0){
	$tmpstr=$it618_waimai_lang['s358'];
	$tmpstr1=$it618_waimai_lang['s357'];
}

if($it618_waimai_gwcsale_main['it618_pj']==1)$it618_pj1='checked="checked"';
if($it618_waimai_gwcsale_main['it618_pj']==2)$it618_pj2='checked="checked"';
if($it618_waimai_gwcsale_main['it618_pj']==3)$it618_pj3='checked="checked"';

if($it618_waimai_gwcsale_main['it618_pmid']!='0'){
	$it618_waimai_peiman=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_pmid($it618_waimai_gwcsale_main['it618_pmid']);
	if($_GET['wap']==1){
		$peiman=$it618_waimai_gwcsale_main['it618_pmid'].'-'.$it618_waimai_peiman['it618_name'].' <a href="tel://'.$it618_waimai_peiman['it618_tel'].'">'.$it618_waimai_peiman['it618_tel'].'</a> <font color=#999>'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_pmtime']).'</font>';
	}else{
		$peiman=$it618_waimai_gwcsale_main['it618_pmid'].'-'.$it618_waimai_peiman['it618_name'].' '.$it618_waimai_peiman['it618_tel'].' <font color=#999>'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_pmtime']).'</font>';
	}
}

if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
	$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($it618_waimai_gwcsale_main['it618_rwpmid']);
	if($_GET['wap']==1){
		$peiman=$it618_waimai_gwcsale_main['it618_rwpmid'].'-'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'-'.$it618_waimai_rwpeiman['it618_name'].' <a href="tel://'.$it618_waimai_rwpeiman['it618_tel'].'">'.$it618_waimai_rwpeiman['it618_tel'].'</a> <font color=#999>'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_pmtime']).'</font>';
	}else{
		$peiman=$it618_waimai_gwcsale_main['it618_rwpmid'].'-'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'-'.$it618_waimai_rwpeiman['it618_name'].' '.$it618_waimai_rwpeiman['it618_tel'].' <font color=#999>'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_pmtime']).'</font>';
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:salepmpj');
?>