<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_header.func.php';

$pid=intval($_GET['pid']);
$preurl=$_GET['preurl'];
$urlsql='&pid='.$pid;
$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_waimai_goods_type', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			if($_GET['it618_zsscore'][$id]>$ShopZSSCORE){
				$it618_zsscore=$_GET['it618_zsscore'][$id];
			}else{
				$it618_zsscore=$ShopZSSCORE;
			}
			
			if($_GET['it618_uprice'][$id]>$ShopUPRICE){
				$it618_uprice=$_GET['it618_uprice'][$id];
			}else{
				$it618_uprice=$ShopUPRICE;
			}

			C::t('#it618_waimai#it618_waimai_goods_type')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_uprice' => $it618_uprice,
				'it618_zsscore' => $it618_zsscore,
				'it618_ison' => trim($_GET['it618_ison'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_uprice_array = !empty($_GET['newit618_uprice']) ? $_GET['newit618_uprice'] : array();
	$newit618_zsscore_array = !empty($_GET['newit618_zsscore']) ? $_GET['newit618_zsscore'] : array();
	$newit618_ison_array = !empty($_GET['newit618_ison']) ? $_GET['newit618_ison'] : array();

	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			if(trim($newit618_zsscore_array[$key])>$ShopZSSCORE){
				$it618_zsscore=trim($newit618_zsscore_array[$key]);
			}else{
				$it618_zsscore=$ShopZSSCORE;
			}
			
			if(trim($newit618_uprice_array[$key])>$ShopUPRICE){
				$it618_uprice=trim($newit618_uprice_array[$key]);
			}else{
				$it618_uprice=$ShopUPRICE;
			}
			                                        
			C::t('#it618_waimai#it618_waimai_goods_type')->insert(array(
				'it618_pid' => $pid,
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_uprice' => $it618_uprice,
				'it618_zsscore' => $it618_zsscore,
				'it618_ison' => trim($newit618_ison_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}
	
	foreach(C::t('#it618_waimai#it618_waimai_goods_type')->fetch_ok_by_it618_pid($pid) as $it618_waimai_goods_typetmp) {
		C::t('#it618_waimai#it618_waimai_goods')->update($pid,array(
			'it618_uprice' => $it618_waimai_goods_typetmp['it618_uprice'],
			'it618_zsscore' => $it618_waimai_goods_typetmp['it618_zsscore']
		));
		break;
	}

	it618_cpmsg($it618_waimai_lang['s5'].$ok1.' '.$it618_waimai_lang['s6'].$ok2.' '.$it618_waimai_lang['s7'].$del.')', "plugin.php?id=it618_waimai:sc_product_type$adminsid&pid=$pid&preurl=$preurl", 'succeed');
}

it618_showformheader("plugin.php?id=it618_waimai:sc_product_type$adminsid&pid=$pid&preurl=$preurl");
$preurl=str_replace("@","&",$preurl);
showtableheaders('<a href="'.$preurl.'"><font color=red>'.$it618_waimai_goods['it618_name'].'</font></a> '.$it618_waimai_lang['s1712'],'admin_shopproduct_type');

$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_waimai_goods_type')." WHERE it618_pid=".$pid);

echo '<tr><td colspan=15>'.$it618_waimai_lang['s1714'].$count.'<span style="float:right;color:red">'.$it618_waimai_lang['s1721'].'</span></td></tr>';

showsubtitle(array('', $it618_waimai_lang['s1715'], $it618_waimai_lang['s1717'], $it618_waimai_lang['s1713'], $it618_waimai_lang['s1722'], $it618_waimai_lang['s1718']));

$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_goods_type')." WHERE it618_pid=".$pid." ORDER BY it618_name");
while($it618_waimai_goods_type = DB::fetch($query)) {

	$salecount = C::t('#it618_waimai#it618_waimai_sale')->sumcount_by_it618_gtypeid($it618_waimai_goods_type['id']);
	$disabled="";
	if($salecount>0)$disabled="disabled=\"disabled\"";
	if($it618_waimai_goods_type['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_waimai_goods_type['id'].'" name="delete[]" value="'.$it618_waimai_goods_type['id'].'" '.$disabled.'><label for="chk_del'.$it618_waimai_goods_type['id'].'">'.$it618_waimai_goods_type['id'].'</label>',
		"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_waimai_goods_type[id]]\" value=\"$it618_waimai_goods_type[it618_name]\">",
		"<input type=\"text\" class=\"txt\" style=\"width:100px;color:red\" name=\"it618_uprice[$it618_waimai_goods_type[id]]\" value=\"$it618_waimai_goods_type[it618_uprice]\">",
		"<input type=\"text\" class=\"txt\" style=\"width:100px;color:blue\" name=\"it618_zsscore[$it618_waimai_goods_type[id]]\" value=\"$it618_waimai_goods_type[it618_zsscore]\">",
		'<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_waimai_goods_type['id'].']" '.$it618_ison_checked.' value="1">',
		$salecount
	));
}
	
	global $_G;

	loadcache('plugin');
	$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:200px" name="newit618_name[]">'],
		[1,'<input type="text" class="txt" style="width:100px;color:red" name="newit618_uprice[]">'],
		[1,'<input type="text" class="txt" style="width:100px;color:blue" name="newit618_zsscore[]">'],
		[1,'<input class="checkbox" type="checkbox" name="newit618_ison[]" checked="checked" value="1">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_waimai_lang['s128'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_footer.func.php';
?>