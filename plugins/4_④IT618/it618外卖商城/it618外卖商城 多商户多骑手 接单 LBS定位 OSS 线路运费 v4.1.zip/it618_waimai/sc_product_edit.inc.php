<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_header.func.php';

$goodsbuycontentwaimai=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('goodsbuycontentwaimai');

$pid=intval($_GET['pid']);
if($it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid)){
	if($it618_waimai_goods['it618_shopid']!=$ShopId){
		it618_cpmsg(it618_waimai_getlang('s703'), "", 'error');
	}
}else{
	it618_cpmsg(it618_waimai_getlang('s550'), "", 'error');
}

if(submitcheck('it618submit')){	

	$get_it618_picbig=$_GET['it618_picbig'];
		
	if($it618_waimai_goods['it618_picbig']!=$get_it618_picbig){
		$tmparr=explode("source",$it618_waimai_goods['it618_picbig']);
		$tmparr1=explode("://",$it618_waimai_goods['it618_picbig']);
		$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
		
		if(file_exists($it618_picbig)&&count($tmparr1)==1){
			$result=unlink($it618_picbig);
		}
	}
	
	$file_ext=strtolower(substr($it618_waimai_goods['it618_picbig'],strrpos($it618_waimai_goods['it618_picbig'], '.')+1)); 
	$file_extarr=explode("?",$file_ext);
	$file_ext=$file_extarr[0];
	$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_0.'.$file_ext;
	if(file_exists($it618_smallurl)){
		$result=unlink($it618_smallurl);
	}
	
	if($get_it618_picbig!=''){
		$smallpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/';
		if (!file_exists($smallpath)) {
			mkdir($smallpath);
		}

		$tmparr1=explode("://",$get_it618_picbig);
		if(count($tmparr1)>1){
			$it618_url=$get_it618_picbig;
		}else{
			$tmparr=explode("source",$get_it618_picbig);
			$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
		}
		
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_0.'.$file_ext;
		it618_waimai_imagetosmall($it618_url,$it618_smallurl,$file_ext,160,160,1);
	}

	
	C::t('#it618_waimai#it618_waimai_goods')->update($pid,array(
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
		'it618_message' => $_GET['it618_message']
	));
	
	if($_GET['it618_class_id']!=''){
		C::t('#it618_waimai#it618_waimai_goods')->update($pid,array(
			'it618_class_id' => $_GET['it618_class_id']
		));
	}
	
	$preurl=str_replace("@","&",$_GET['preurl']);
	it618_cpmsg(it618_waimai_getlang('s285'), $preurl, 'succeed');
}

it618_showformheader("plugin.php?id=it618_waimai:sc_product_edit$adminsid&pid=$pid&preurl=".$_GET['preurl']);
showtableheaders(it618_waimai_getlang('s286'),'it618_waimai_goods');

$it618_waimai_goods=C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);

foreach(C::t('#it618_waimai#it618_waimai_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

if($tmp!=''){
	$tmp1=str_replace('<option value='.$it618_waimai_goods['it618_class_id'].'>','<option value='.$it618_waimai_goods['it618_class_id'].' selected="selected">',$tmp);
	$isgoodsclass='if(document.getElementById("it618_class_id").value=="0"){
			alert("'.it618_waimai_getlang('s264').'");
			return false;
		}';
}

echo '
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_waimai/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_waimai/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=640'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_waimai/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	function checkvalue(){
		if(document.getElementById("it618_waimaiclass_id").value=="0"){
			alert("'.it618_waimai_getlang('s1584').'");
			return false;
		}
		if(document.getElementById("it618_waimaiclass1_id").value=="0"){
			alert("'.it618_waimai_getlang('s1585').'");
			return false;
		}
		'.$isgoodsclass.'
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_waimai_getlang('s265').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_waimai_getlang('s266').'");
			return false;
		}
		'.$tmpjs.'
	}
	
	function delpic(i){
		document.getElementById("url1"+i).value="";
		document.getElementById("img1"+i).src="";
	}
</script>

';

if($tmp!=''){echo '
<tr><td>'.it618_waimai_getlang('s270').'</td><td><select id="it618_class_id" name="it618_class_id"><option value="0">'.it618_waimai_getlang('s271').'</option>'.$tmp1.'</select></td></tr>';}

echo '
<tr><td><font color=red>'.it618_waimai_getlang('s272').'</font></td><td><input type="text" class="txt" style="width:600px;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_waimai_goods['it618_name'].'"><input type="hidden" class="txt" name="it618_name_ode" value="'.$it618_waimai_goods['it618_name'].'"> </td></tr>
<tr><td>'.it618_waimai_getlang('s279').'</td><td><img id="img1" src="'.$it618_waimai_goods['it618_picbig'].'" width="80" height="80" align="absmiddle"/> <input type="text" id="url1" name="it618_picbig" style="width:300px" readonly="readonly" value="'.$it618_waimai_goods['it618_picbig'].'"/> <input type="button" id="image1" value="'.it618_waimai_getlang('s280').'" />   '.it618_waimai_getlang('s281').'</td></tr>
<tr><td><font color=red>'.it618_waimai_getlang('s284').'</font></td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_waimai_goods['it618_message'].'</textarea><textarea name="it618_message_old" style="width:700px;height:0px;visibility:hidden;">'.$it618_waimai_goods['it618_message'].'</textarea></td></tr>
'.$tmpstr.'
';

echo '<tr><td colspan=2><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_waimai_getlang('s120').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_footer.func.php';
?>