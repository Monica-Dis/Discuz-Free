<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$uid = $_G['uid'];
if($uid<=0){
	if($_GET['wap']==1){
		return;
	}else{
		echo $it618_waimai_lang['s434'].'it618_split'.it618_waimai_getlang('s563').'<a href="member.php?mod=logging&action=login">'.it618_waimai_getlang('s773').'</a> <a href="member.php?mod='.$RegName.'">'.it618_waimai_getlang('s774').'</a>';return;
	}
}else{
	$rzpower=1;
	$waimai_rzpower=(array)unserialize($it618_waimai['waimai_rzpower']);
	if(!in_array($_G['groupid'], $waimai_rzpower)){
		$rzpower=0;
	}
	
	$ispost=1;
	$username=C::t('#it618_waimai#it618_waimai_sale')->fetch_username_by_uid($_G['uid']);
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid'])>0){
		$t=it618_waimai_getlang('s426');
		$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
		$it618_state=$it618_waimai_waimai['it618_state'];
		if($it618_state==0){
			$statestr=it618_waimai_getlang('s427');
			$ispost=0;
		}elseif($it618_state==1){
			$statestr=it618_waimai_getlang('s428');
		}
		$tip="$username ".it618_waimai_getlang('s429')." ".date('Y-m-d H:i:s', $it618_waimai_waimai['it618_time'])." ".it618_waimai_getlang('s430')."<font color=red>".$statestr."</font>";
		if($it618_state==2){
			$t=it618_waimai_getlang('s431');
			if($_GET['wap']==1){
				$scurl=it618_waimai_getrewrite('waimai_wap','sc@'.$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:wap&pagetype=sc&sid='.$it618_waimai_waimai['id']);
				$tip="$username ".it618_waimai_getlang('s432')."<br><a href='".$scurl."'>".it618_waimai_getlang('s433')."</a>";
			}else{
				$shop_sc=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc');
				$tip="$username ".it618_waimai_getlang('s432')."<br><a href='".$shop_sc."' target='_blank'>".it618_waimai_getlang('s433')."</a>";
			}
			$ispost=0;
		}
		
	}else{
		$t=it618_waimai_getlang('s434');
		$tip="$username ".it618_waimai_getlang('s435');
	}
	
	foreach(C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_all_by_search() as $it618_tmp) {
		$powertmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_groupname'].'</option>';
	}
	
	$powertmp=str_replace('<option value='.$it618_waimai_waimai['it618_power'].'>','<option value='.$it618_waimai_waimai['it618_power'].' selected="selected">',$powertmp);
	
	foreach(C::t('#it618_waimai#it618_waimai_waimai_area')->fetch_all_by_search() as $it618_tmp) {
		$areatmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
	
	$areatmp=str_replace('<option value='.$it618_waimai_waimai['it618_area_id'].'>','<option value='.$it618_waimai_waimai['it618_area_id'].' selected="selected">',$areatmp);
	
	foreach(C::t('#it618_waimai#it618_waimai_waimai_area1')->fetch_all_by_it618_area_id($it618_waimai_waimai['it618_area_id']) as $it618_tmp) {
		$areatmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
	$areatmp1=str_replace('<option value='.$it618_waimai_waimai['it618_area1_id'].'>','<option value='.$it618_waimai_waimai['it618_area1_id'].' selected="selected">',$areatmp1);
	
	foreach(C::t('#it618_waimai#it618_waimai_waimai_class')->fetch_all_by_search() as $it618_tmp) {
		$classtmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$classtmp=str_replace('<option value='.$it618_waimai_waimai['it618_class_id'].'>','<option value='.$it618_waimai_waimai['it618_class_id'].' selected="selected">',$classtmp);
	
	foreach(C::t('#it618_waimai#it618_waimai_waimai_class1')->fetch_all_by_it618_class_id($it618_waimai_waimai['it618_class_id']) as $it618_tmp) {
		$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	$classtmp1=str_replace('<option value='.$it618_waimai_waimai['it618_class1_id'].'>','<option value='.$it618_waimai_waimai['it618_class1_id'].' selected="selected">',$classtmp1);
	
	$rzabout=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('rzabout');
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:showrenzheng');
?>