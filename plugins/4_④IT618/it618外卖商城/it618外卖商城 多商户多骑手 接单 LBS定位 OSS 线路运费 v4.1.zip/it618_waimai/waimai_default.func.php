<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/waimai_function.func.php';

$class1=intval($_GET['class1']);
if($pagetype=='search'){
	if($_GET['sw']==''||!isset($_GET['sw']))$searchsw=$it618_waimai['waimai_sw'];else $searchsw=$_GET['sw'];
}
if($searchsw!='')$sw=' style="display:none"';

$homeurl=it618_waimai_getrewrite('waimai_home','','plugin.php?id=it618_waimai:index');
$searchurl=it618_waimai_getrewrite('waimai_search','','plugin.php?id=it618_waimai:search');

$waimai_waimailogo=str_replace("{homeurl}",$homeurl,$it618_waimai['waimai_waimailogo']);

$waimai_hotsw=explode(',',$it618_waimai['waimai_hotsw']);
for($i=0;$i<count($waimai_hotsw);$i++){
	$tmpurl=it618_waimai_getrewrite('waimai_search','','plugin.php?id=it618_waimai:search&sw='.urlencode($waimai_hotsw[$i]),'?sw='.urlencode($waimai_hotsw[$i]));
	$hotsw.='<a href="'.$tmpurl.'">'.$waimai_hotsw[$i].'</a>';
}

$homewaimaicount = C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1');

$hotclasswaimai=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('hotclasswaimai');
$hotclasswaimai=explode('@@@',$hotclasswaimai);

$topnav=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('topnav');
$waimaifooter=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('waimaifooter');

foreach(C::t('#it618_waimai#it618_waimai_focus')->fetch_all_by_type_order(16) as $it618_waimai_focus) {
	if($it618_waimai_focus['it618_url']!=''){
		$str_focus2.='<li><a href="'.$it618_waimai_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="1200" height="63" /></a></li>';
	}else{
		$str_focus2.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="1200" height="63" /></li>';
	}
}

$waphome=it618_waimai_getrewrite('waimai_wap','','plugin.php?id=it618_waimai:wap');

$metatitle=$it618_waimai['waimai_name'];
?>