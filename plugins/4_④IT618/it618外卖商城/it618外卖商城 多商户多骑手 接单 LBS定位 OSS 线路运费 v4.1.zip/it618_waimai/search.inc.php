<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$pagetype='search';
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/waimai_default.func.php';
$class1=intval($_GET['class1']);
$class2=intval($_GET['class2']);
$area1=intval($_GET['area1']);
$area2=intval($_GET['area2']);
$order=intval($_GET['order']);

if(waimai_is_mobile()){ 
	$tmpurl=it618_waimai_getrewrite('waimai_wap','search@'.$class1,'plugin.php?id=it618_waimai:wap&pagetype=search&sid='.$class1);
	dheader("location:$tmpurl");
}

foreach(C::t('#it618_waimai#it618_waimai_focus')->fetch_all_by_type_order(19) as $it618_waimai_focus) {
	if($it618_waimai_focus['it618_url']!=''){
		$str_focus5.='<li><a href="'.$it618_waimai_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus5.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

$allcount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1','',$searchsw);

if($class1==0)$current=' class="current"';else $current='';
$tmpurl=it618_waimai_getrewrite('waimai_search','0@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:list&class1=0&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order,'?sw='.urlencode($searchsw));
$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_waimai_getlang('s874').'</a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class')." where it618_img='' ORDER BY it618_order");
while($it618_waimai_waimai_class = DB::fetch($query)) {
	$waimaicount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1','',$searchsw,0,0,$it618_waimai_waimai_class['id'],0);
	if($class1==$it618_waimai_waimai_class['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_waimai_getrewrite('waimai_search',$it618_waimai_waimai_class['id'].'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:search&class1='.$it618_waimai_waimai_class['id'].'&class2=0&area1='.$area1.'&area2='.$area2.'&sw='.urlencode($searchsw).'&order='.$order,'?sw='.urlencode($searchsw));
	$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_waimai_waimai_class['it618_classname'].'<span>'.$waimaicount.'</span></a></li>';
}

if($class1>0){
	if($class2==0)$current=' class="current"';else $current='';
	$tmpurl=it618_waimai_getrewrite('waimai_search',$class1.'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:search&class1='.$class1.'&class2=0&area1='.$area1.'&area2='.$area2.'&sw='.urlencode($searchsw).'&order='.$order,'?sw='.urlencode($searchsw));
	$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_waimai_getlang('s874').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class1')." where it618_class_id=".$class1." ORDER BY it618_order");
	while($it618_waimai_waimai_class1 = DB::fetch($query)) {
		$waimaicount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1','',$searchsw,0,0,0,$it618_waimai_waimai_class1['id']);
		if($class2==$it618_waimai_waimai_class1['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_waimai_getrewrite('waimai_search',$class1.'@'.$it618_waimai_waimai_class1['id'].'@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:search&class1='.$class1.'&class2='.$it618_waimai_waimai_class1['id'].'&area1='.$area1.'&area2='.$area2.'&sw='.urlencode($searchsw).'&order='.$order,'?sw='.urlencode($searchsw));
		$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_waimai_waimai_class1['it618_classname'].'<span>'.$waimaicount.'</span></a></li>';
	}
}

if($area1==0)$current=' class="current"';else $current='';
$tmpurl=it618_waimai_getrewrite('waimai_search',$class1.'@'.$class2.'@0@0@'.$order,'plugin.php?id=it618_waimai:search&class1='.$class1.'&class2='.$class2.'&area1=0&area2=0&sw='.urlencode($searchsw).'&order='.$order,'?sw='.urlencode($searchsw));
$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_waimai_getlang('s874').'</a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_area')." ORDER BY it618_order");
while($it618_waimai_waimai_area = DB::fetch($query)) {
	$waimaicount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1','',$searchsw,$it618_waimai_waimai_area['id'],0,0,0);
	if($area1==$it618_waimai_waimai_area['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_waimai_getrewrite('waimai_search',$class1.'@'.$class2.'@'.$it618_waimai_waimai_area['id'].'@0@'.$order,'plugin.php?id=it618_waimai:search&class1='.$class1.'&class2='.$class2.'&area1='.$it618_waimai_waimai_area['id'].'&area2=0&sw='.urlencode($searchsw).'&order='.$order,'?sw='.urlencode($searchsw));
	$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_waimai_waimai_area['it618_name'].'<span>'.$waimaicount.'</span></a></li>';
}

if($area1>0){
	if($area2==0)$current=' class="current"';else $current='';
	$tmpurl=it618_waimai_getrewrite('waimai_search',$class1.'@'.$class2.'@'.$area1.'@0@'.$order,'plugin.php?id=it618_waimai:search&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2=0&sw='.urlencode($searchsw).'&order='.$order,'?sw='.urlencode($searchsw));
	$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_waimai_getlang('s874').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_area1')." where it618_area_id=".$area1." ORDER BY it618_order");
	while($it618_waimai_waimai_area1 = DB::fetch($query)) {
		$waimaicount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1','',$searchsw,0,$it618_waimai_waimai_area1['id'],0,0);
		if($area2==$it618_waimai_waimai_area1['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_waimai_getrewrite('waimai_search',$class1.'@'.$class2.'@'.$area1.'@'.$it618_waimai_waimai_area1['id'].'@'.$order,'plugin.php?id=it618_waimai:search&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$it618_waimai_waimai_area1['id'].'&sw='.urlencode($searchsw).'&order='.$order,'?sw='.urlencode($searchsw));
		$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_waimai_waimai_area1['it618_name'].'<span>'.$waimaicount.'</span></a></li>';
	}
}

if($order==0){$current0=' class="left current"';$it618orderby='it618_order desc';}else $current0=' class="left"';
if($order==1){$current1=' class="current"';$it618orderby='it618_levelsum desc';}else $current1='';
if($order==2){$current2=' class="current"';$it618orderby='it618_salecount desc';}else $current2='';
if($order==3){$current3=' class="current"';$it618orderby='it618_views desc';}else $current3='';
if($order==4){$current4=' class="current"';$it618orderby='it618_pmoney';}else $current4='';
if($order==5){$current5=' class="current"';$it618orderby='it618_yunfei1+it618_yunfei2';}else $current5='';
if($order==6){$current6=' class="current"';$it618orderby='it618_time desc';}else $current6='';

for($i=0;$i<=6;$i++){
	$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$i,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&order='.$i);
	$orderurl[$i]=$tmpurl;
}

$ppp=$it618_waimai['waimai_listwaimaicount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$count = C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1',$it618orderby,$searchsw,$class1,$class2,$area1,$area2);
$hrefsql=it618_waimai_getrewrite('waimai_search',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$order.'@it618page','plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&sw='.urlencode($searchsw).'&order='.$order);
$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_waimai_multipage($multipage,'?sw='.urlencode($searchsw));

foreach(C::t('#it618_waimai#it618_waimai_waimai')->fetch_all_by_search(
	'it618_state=2 and it618_htstate=1',$it618orderby,$searchsw,$area1,$area2,$class1,$class2,0,$startlimit,$ppp
) as $it618_waimai_waimai) {
	$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
	$ShopPowerIco='';
	if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" align="absmiddle" style="margin-top:3px"/>';
		
	if($it618_waimai_waimai['it618_mappoint']!='')$mapstr=' <a href="javascript:"><img class="waimaimap" name="'.$it618_waimai_waimai['id'].'" src="source/plugin/it618_waimai/images/map.png"></a>';
	
	$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$it618_waimai_waimai['it618_levelsum']);
	
	$tmpurl=it618_waimai_getrewrite('shop_home',$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:shop&sid='.$it618_waimai_waimai['id']);
	$it618shops.='<div class="goods">
				<a class="goods-img" href="'.$tmpurl.'" target="_blank">
				<img imgsrc="'.$it618_waimai_waimai['it618_logo'].'" src="source/plugin/it618_waimai/images/a.gif" class="dynload" width="308" height="196" alt="'.$it618_waimai_waimai['it618_name'].'" />
				</a>
				<h3>
				<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_waimai_waimai['it618_name'].'">'.$it618_waimai_waimai['it618_name'].' '.$ShopPowerIco.'</a>
				</h3>
				<div class="goods-info" style="padding-top:3px">
				<span title="'.$it618_waimai_waimai['it618_addr'].'">'.cutstr($it618_waimai_waimai['it618_addr'],30,'...').$mapstr.'</span><br>'.it618_waimai_getlang('s1300').':'.$it618_waimai_waimai['it618_views'].' '.it618_waimai_getlang('s1298').':'.$it618_waimai_waimai['it618_salecount'].' '.it618_waimai_getlang('s1301').':'.$it618_waimai_waimai['it618_pjcount'].' '.it618_waimai_getlang('s1302').':'.$it618_waimai_waimai['it618_haopjbl'].'%<br><span style="float:right"><a href="'.$tmpurl.'" target="_blank">'.$it618_waimai_lang['s1639'].'</a></span><font color="#666" style="font-size:13px">'.str_replace(it618_waimai_getlang('s1175'),"",$tmplevelarr[0]).':</font><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_waimai_level['it618_img'].'">
				</div>
				</div>';
}


$metatitle=$searchsw.' - '.$metatitle;
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/hongbao.func.php';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:waimai_default');
?>