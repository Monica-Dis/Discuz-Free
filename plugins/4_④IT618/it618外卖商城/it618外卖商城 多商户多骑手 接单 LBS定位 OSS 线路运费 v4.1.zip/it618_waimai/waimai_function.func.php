<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
$navtitle = $it618_waimai['seotitle'];
$metakeywords = $it618_waimai['seokeywords'];
$metadescription = $it618_waimai['seodescription'];

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$stylecount=C::t('#it618_waimai#it618_waimai_style')->count_by_isok_shopid();
$it618_waimai_style=C::t('#it618_waimai#it618_waimai_style')->fetch_by_isok_shopid();

$query1 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class')." ORDER BY it618_order");
while($it618_waimai_waimai_class = DB::fetch($query1)) {
	if($it618_waimai_waimai_class['it618_img']==''){
		$tmpurl=it618_waimai_getrewrite('waimai_list',$it618_waimai_waimai_class['id'],'plugin.php?id=it618_waimai:list&class1='.$it618_waimai_waimai_class['id']);
		
		$str_nav.='<a href="'.$tmpurl.'">'.$it618_waimai_waimai_class['it618_classname'].'</a>';
		
		$str_class.='<div class="sort">
						<div class="sort-menu"><em class="sort-icon"></em><i class="'.$it618_waimai_waimai_class['it618_cssname'].'"></i><a class="title '.$it618_waimai_waimai_class['it618_cssname'].'" href="'.$tmpurl.'">'.$it618_waimai_waimai_class['it618_classname'].'</a>
							<p>
								{it618classtj}
							</p>
						  </div>
						  <div class="sort-con '.$it618_waimai_waimai_class['it618_cssname'].'-top">
							<div class="sort-con-left">
								<h4><a href="'.$tmpurl.'">'.$it618_waimai_waimai_class['it618_classname'].'</a></h4>
								<ul class="sort-link02 cl">
									{it618classall}
								</ul>
							</div>
						  </div>
					</div>';
		$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class1')." where it618_class_id=".$it618_waimai_waimai_class['id']." ORDER BY it618_order");
		$it618classtj='';$it618classall='';
		while($it618_waimai_waimai_class1 = DB::fetch($query2)) {
			if($it618_waimai_waimai_class1['it618_color']!="")
			$tmpname='<font color='.$it618_waimai_waimai_class1['it618_color'].'>'.$it618_waimai_waimai_class1['it618_classname'].'</font>';else $tmpname=$it618_waimai_waimai_class1['it618_classname'];
			
			$tmpurl=it618_waimai_getrewrite('waimai_list',$it618_waimai_waimai_class['id'].'@'.$it618_waimai_waimai_class1['id'],'plugin.php?id=it618_waimai:list&class1='.$it618_waimai_waimai_class['id'].'&class2='.$it618_waimai_waimai_class1['id']);
			if($it618_waimai_waimai_class1['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'">'.$tmpname.'</a>';
			$it618classall.='<li><a href="'.$tmpurl.'">'.$tmpname.'</a></li>';
			if($i1ii1[5]!='_')return;
		}
		
		$str_class=str_replace("{it618classtj}",$it618classtj,$str_class);
		$str_class=str_replace("{it618classall}",$it618classall,$str_class);
	}else{
		if($it618_waimai_waimai_class['it618_url']!=''){
			$str_class.='<div class="sort">
						<a href="'.$it618_waimai_waimai_class['it618_url'].'" target="_blank"><img src="'.$it618_waimai_waimai_class['it618_img'].'" width="212" height="56" style="margin-left:2px"></a>
					</div>';
		}else{
			$str_class.='<div class="sort">
						<img src="'.$it618_waimai_waimai_class['it618_img'].'" width="212" height="56" style="margin-left:2px">
					</div>';
		}
	}
}

$str_class.='<div class="sort-lottery">
				<div class="sort-menu" style="height:0;padding:0; margin:0"></div>
			 </div>';

$count = C::t('#it618_waimai#it618_waimai_nav')->count_by_search();
if($count>0){
	$str_nav='';
	foreach(C::t('#it618_waimai#it618_waimai_nav')->fetch_all_by_search() as $it618_waimai_nav) {
		if($it618_waimai_nav['it618_color']!="")
		$tmpname='<font color='.$it618_waimai_nav['it618_color'].'>'.$it618_waimai_nav['it618_name'].'</font>';else $tmpname=$it618_waimai_nav['it618_name'];
		
		if($it618_waimai_nav['it618_target']==1)$it618_target=' target="_blank"';else $it618_target='';
		
		$str_nav.='<a href="'.$it618_waimai_nav['it618_url'].'"'.$it618_target.'>'.$tmpname.'</a>';
	}
}


if($_G['uid']>0){
	C::t('#it618_waimai#it618_waimai_sale')->update_lastactivity_by_uid(TIMESTAMP,$_G['uid']);
	$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
	$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
	
	if(in_array($_G['uid'],$saleadmin)){
		$shopadminurl='<li>
						<a href="plugin.php?id=it618_waimai:sc_sale_admin" target="_blank"><font color=red>'.it618_waimai_getlang('s1080').'</font></a>
					</li>';
	}
	
	if(in_array($_G['uid'],$shopadmin)){
		if($ShopId>0){
			$tmpurl=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc&adminsid='.$ShopId,'adminsid='.$ShopId);
			$shopadminurl.='<li>
					<a href="'.$tmpurl.'" target="_blank"><font color=red>'.it618_waimai_getlang('s1219').'</font></a>
				</li>';
		}
	}
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid'])>0){
		$tmprz='<li>
					<a href="javascript:" class="renzheng"><font color=red>'.it618_waimai_getlang('s859').'</font></a> 
				</li>';
		if(C::t('#it618_waimai#it618_waimai_waimai')->fetch_it618_state_by_it618_uid($_G['uid'])==2){
			$tmpurl=it618_waimai_getrewrite('shop_sc','','plugin.php?id=it618_waimai:sc');
			$tmprz='<li>
						<a href="'.$tmpurl.'" target="_blank"><font color=#FF00FF>'.it618_waimai_getlang('s861').'</font></a> 
					</li>
					';
		}
	}else{
		$tmprz='<li>
					<a href="javascript:" class="renzheng"><font color=red>'.it618_waimai_getlang('s862').'</font></a> 
				</li>';
	}
	$tmprz.=$shopadminurl;
	
	$salecount=C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_it618_uid($it618_waimai_sale['it618_gwcid']);
	$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(1,$salecount);
	
	if($IsCredits==1){
		$tmpcredits='<li>
					<a href="javascript:" id="it618_credits"><font color=green>'.it618_waimai_getlang('s1467').'</font></a> 
					</li>';
	}
	
	$usermenu='<ul class="login cl">
                <li><a class="login-link" href="'.it618_waimai_rewriteurl($_G['uid']).'">'.it618_waimai_getusername($_G['uid']).'</a> </li>
				<li style="padding-top:5px;">'.$tmplevelarr[1].it618_waimai_getlang('s562').'<img style="vertical-align:middle;margin-top:-3px" src="'.$it618_waimai_level['it618_img'].'"></li>
                <li class="dropdown dropdown-account">
                    <p class="textwarp">
                        <em class="text">'.it618_waimai_getlang('s863').'</em>
                        <i class="triangle"></i>
                        <em class="account-num" style="display:none;"></em>
					</p>
                    <ul class="htul">
						'.$tmpcredits.'
						
                        '.$it618_waimai['waimai_topnavmenu'].'
						'.$tmprz.'
                    </ul>
                </li>
                <li><a class="login-link" href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'">['.it618_waimai_getlang('s867').']</a></li>
			   </ul>';
}else{
	$usermenu='<ul class="login cl">
                <li><a class="login-link" href="member.php?mod=logging&action=login">['.it618_waimai_getlang('s868').']</a></li>
                <li><a class="login-link" href="member.php?mod='.$RegName.'">['.it618_waimai_getlang('s869').']</a></li>
               </ul>';
}
//From: Dism_taobao-com
?>