<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/waimai_default.func.php';
$class1=intval($_GET['class1']);
$class2=intval($_GET['class2']);
$area1=intval($_GET['area1']);
$area2=intval($_GET['area2']);
$order=intval($_GET['order']);

if(waimai_is_mobile()){ 
	$tmpurl=it618_waimai_getrewrite('waimai_wap','search@'.$class1,'plugin.php?id=it618_waimai:wap&pagetype=search&sid='.$class1);
	dheader("location:$tmpurl");
}

$tmpidsarr=explode(',',$hotclasswaimai[1]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_waimai_waimai_class1=C::t('#it618_waimai#it618_waimai_waimai_class1')->fetch_by_id($id);
	$tmpurl=it618_waimai_getrewrite('waimai_list',$it618_waimai_waimai_class1['it618_class_id'].'@'.$id,'plugin.php?id=it618_waimai:list&class1='.$it618_waimai_waimai_class1['it618_class_id'].'&class2='.$id);
	$listhotclass.='<li><a href="'.$tmpurl.'">'.$it618_waimai_waimai_class1['it618_classname'].'</a></li>';
}

foreach(C::t('#it618_waimai#it618_waimai_focus')->fetch_all_by_type_order(19) as $it618_waimai_focus) {
	if($it618_waimai_focus['it618_url']!=''){
		$str_focus5.='<li><a href="'.$it618_waimai_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="223" height="180" /></a></li>';
	}else{
		$str_focus5.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="223" height="180" /></li>';
	}
}

if($class1>0){
	$class1name=C::t('#it618_waimai#it618_waimai_waimai_class')->fetch_it618_name_by_id($class1);
	$classtitle.=$class1name.' ';
	$tmpurl=it618_waimai_getrewrite('waimai_list','0@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:list&class1=0&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$class1name.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

if($class2>0){
	$tmpname=C::t('#it618_waimai#it618_waimai_waimai_class1')->fetch_it618_name_by_id($class2);
	$classtitle.=$tmpname.' ';
	$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

if($area1>0){
	$tmpname=C::t('#it618_waimai#it618_waimai_waimai_area')->fetch_it618_name_by_id($area1);
	$classtitle.=$tmpname.' ';
	$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@'.$class2.'@0@0@'.$order,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1=0&area2=0&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

if($area2>0){
	$tmpname=C::t('#it618_waimai#it618_waimai_waimai_area1')->fetch_it618_name_by_id($area2);
	$classtitle.=$tmpname.' ';
	$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@'.$class2.'@'.$area1.'@0@'.$order,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2=0&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

$listnav.='@';
$listnav=str_replace('<i class="crumb-icon"></i>@','',$listnav);

if($class1==0)$current=' class="current"';else $current='';
$tmpurl=it618_waimai_getrewrite('waimai_list','0@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:list&class1=0&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_waimai_getlang('s874').'</a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class')." where it618_img='' ORDER BY it618_order");
while($it618_waimai_waimai_class = DB::fetch($query)) {
	$waimaicount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1','','',0,0,$it618_waimai_waimai_class['id'],0);
	if($class1==$it618_waimai_waimai_class['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_waimai_getrewrite('waimai_list',$it618_waimai_waimai_class['id'].'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:list&class1='.$it618_waimai_waimai_class['id'].'&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
	$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_waimai_waimai_class['it618_classname'].'<span>'.$waimaicount.'</span></a></li>';
}

if($class1>0){
	if($class2==0)$current=' class="current"';else $current='';
	$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@0@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2=0&area1='.$area1.'&area2='.$area2.'&order='.$order);
	$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_waimai_getlang('s874').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class1')." where it618_class_id=".$class1." ORDER BY it618_order");
	while($it618_waimai_waimai_class1 = DB::fetch($query)) {
		$waimaicount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1','','',0,0,0,$it618_waimai_waimai_class1['id']);
		if($class2==$it618_waimai_waimai_class1['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@'.$it618_waimai_waimai_class1['id'].'@'.$area1.'@'.$area2.'@'.$order,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$it618_waimai_waimai_class1['id'].'&area1='.$area1.'&area2='.$area2.'&order='.$order);
		$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_waimai_waimai_class1['it618_classname'].'<span>'.$waimaicount.'</span></a></li>';
	}
}

if($area1==0)$current=' class="current"';else $current='';
$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@'.$class2.'@0@0@'.$order,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1=0&area2=0&order='.$order);
$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_waimai_getlang('s874').'</a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_area')." ORDER BY it618_order");
while($it618_waimai_waimai_area = DB::fetch($query)) {
	$waimaicount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1','','',$it618_waimai_waimai_area['id'],0,0,0);
	if($area1==$it618_waimai_waimai_area['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@'.$class2.'@'.$it618_waimai_waimai_area['id'].'@0@'.$order,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1='.$it618_waimai_waimai_area['id'].'&area2=0&order='.$order);
	$str_area1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_waimai_waimai_area['it618_name'].'<span>'.$waimaicount.'</span></a></li>';
}

if($area1>0){
	if($area2==0)$current=' class="current"';else $current='';
	$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@'.$class2.'@'.$area1.'@0@'.$order,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2=0&order='.$order);
	$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_waimai_getlang('s874').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_area1')." where it618_area_id=".$area1." ORDER BY it618_order");
	while($it618_waimai_waimai_area1 = DB::fetch($query)) {
		$waimaicount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1','','',0,$it618_waimai_waimai_area1['id'],0,0);
		if($area2==$it618_waimai_waimai_area1['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@'.$class2.'@'.$area1.'@'.$it618_waimai_waimai_area1['id'].'@'.$order,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$it618_waimai_waimai_area1['id'].'&order='.$order);
		$str_area2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_waimai_waimai_area1['it618_name'].'<span>'.$waimaicount.'</span></a></li>';
	}
}

if($order==0){$current0=' class="left current"';$it618orderby='it618_order desc';}else $current0=' class="left"';
if($order==1){$current1=' class="current"';$it618orderby='it618_levelsum desc';}else $current1='';
if($order==2){$current2=' class="current"';$it618orderby='it618_salecount desc';}else $current2='';
if($order==3){$current3=' class="current"';$it618orderby='it618_views desc';}else $current3='';
if($order==4){$current4=' class="current"';$it618orderby='it618_pmoney';}else $current4='';
if($order==5){$current5=' class="current"';$it618orderby='it618_yunfei1+it618_yunfei2';}else $current5='';
if($order==6){$current6=' class="current"';$it618orderby='it618_time desc';}else $current6='';

for($i=0;$i<=6;$i++){
	$tmpurl=it618_waimai_getrewrite('waimai_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$i,'plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&order='.$i);
	$orderurl[$i]=$tmpurl;
}

$ppp=$it618_waimai['waimai_listwaimaicount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$count = C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1',$it618orderby,'',$area1,$area2,$class1,$class2);
$hrefsql=it618_waimai_getrewrite('waimai_list',$class1.'@'.$class2.'@'.$area1.'@'.$area2.'@'.$order.'@it618page','plugin.php?id=it618_waimai:list&class1='.$class1.'&class2='.$class2.'&area1='.$area1.'&area2='.$area2.'&order='.$order);
$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_waimai_multipage($multipage,$uri);

foreach(C::t('#it618_waimai#it618_waimai_waimai')->fetch_all_by_search(
	'it618_state=2 and it618_htstate=1',$it618orderby,'',$area1,$area2,$class1,$class2,0,$startlimit,$ppp
) as $it618_waimai_waimai) {
	$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
	$ShopPowerIco='';
	if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" align="absmiddle" style="margin-top:3px"/>';
		
	if($it618_waimai_waimai['it618_mappoint']!='')$mapstr=' <a href="javascript:"><img class="waimaimap" name="'.$it618_waimai_waimai['id'].'" src="source/plugin/it618_waimai/images/map.png"></a>';
	
	$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$it618_waimai_waimai['it618_levelsum']);
		
	$tmpurl=it618_waimai_getrewrite('shop_home',$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:shop&sid='.$it618_waimai_waimai['id']);
	$it618shops.='<div class="index-goods">
					<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
						<img class="dynload" imgsrc="'.$it618_waimai_waimai['it618_logo'].'" src="source/plugin/it618_waimai/images/a.gif" alt="'.$it618_waimai_waimai['it618_name'].'"/>
					</a>
					<h3>
						<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_waimai_waimai['it618_name'].'">'.$it618_waimai_waimai['it618_name'].' '.$ShopPowerIco.'</a>
					</h3>
					<div class="index-goods-info">
						<span title="'.$it618_waimai_waimai['it618_addr'].'">'.cutstr($it618_waimai_waimai['it618_addr'],30,'...').$mapstr.'</span><br>'.it618_waimai_getlang('s1300').':'.$it618_waimai_waimai['it618_views'].' '.it618_waimai_getlang('s1298').':'.$it618_waimai_waimai['it618_salecount'].' '.it618_waimai_getlang('s1301').':'.$it618_waimai_waimai['it618_pjcount'].' '.it618_waimai_getlang('s1302').':'.$it618_waimai_waimai['it618_haopjbl'].'%<br><span style="float:right"><a href="'.$tmpurl.'" target="_blank">'.$it618_waimai_lang['s1639'].'</a></span><font color="#666" style="font-size:13px">'.str_replace(it618_waimai_getlang('s1175'),"",$tmplevelarr[0]).':</font><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_waimai_level['it618_img'].'">
					</div>
				</div>';
}


$classtitle1=str_replace(' ','',$classtitle);
if($classtitle1=='')$classtitle=it618_waimai_getlang('s876');
$metatitle=$classtitle.' - '.$metatitle;

$pagetype='list';
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/hongbao.func.php';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:waimai_default');
?>