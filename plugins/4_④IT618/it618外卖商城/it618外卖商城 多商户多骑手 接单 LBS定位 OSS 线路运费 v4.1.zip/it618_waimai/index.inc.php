<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/waimai_default.func.php';

if(waimai_is_mobile()){ 
	$tmpurl=it618_waimai_getrewrite('waimai_wap','','plugin.php?id=it618_waimai:wap');
	dheader("location:$tmpurl");
}

$tmpidsarr=explode(',',$hotclasswaimai[0]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_waimai_waimai_class1=C::t('#it618_waimai#it618_waimai_waimai_class1')->fetch_by_id($id);
	$tmpurl=it618_waimai_getrewrite('waimai_list',$it618_waimai_waimai_class1['it618_class_id'].'@'.$id,'plugin.php?id=it618_waimai:list&class1='.$it618_waimai_waimai_class1['it618_class_id'].'&class2='.$id);
	$homehotclass.='<li><a href="'.$tmpurl.'">'.$it618_waimai_waimai_class1['it618_classname'].'</a></li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_area')." ORDER BY it618_order");
while($it618_waimai_waimai_area = DB::fetch($query)) {
	$tmpurl=it618_waimai_getrewrite('waimai_list','0@0@'.$it618_waimai_waimai_area['id'].'@0','plugin.php?id=it618_waimai:list&class1=0&class2=0&area1='.$it618_waimai_waimai_area['id'].'&area2=0');
	$str_area1.='<li><a href="'.$tmpurl.'">'.$it618_waimai_waimai_area['it618_name'].'</a></li>';
}

$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_waimai_gonggao = DB::fetch($query)) {
	$it618_title=$it618_waimai_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,80,'...');
	
	if($it618_waimai_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_waimai_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_waimai_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<tr><td><a href="'.$it618_waimai_gonggao['it618_url'].'" target="_blank" title="'.$it618_waimai_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
}

$tmpidsarr=explode(',',$hotclasswaimai[2]);
$n=1;
for($i=1;$i<=count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i-1]);
	$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($id);
	if($it618_waimai_waimai['it618_state']==2&&$it618_waimai_waimai['it618_htstate']==1){
		
		$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
		$ShopPowerIco='';
		if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" align="absmiddle" style="margin-top:3px"/>';
			
		if($it618_waimai_waimai['it618_mappoint']!='')$mapstr=' <a href="javascript:"><img class="waimaimap" name="'.$it618_waimai_waimai['id'].'" src="source/plugin/it618_waimai/images/map.png"></a>';
		
		$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$it618_waimai_waimai['it618_levelsum']);
		
		if($n%2>0){$homehotwaimai.='<li>';$tmpfloat='fl';}else{$tmpfloat='fr';}
		$tmpurl=it618_waimai_getrewrite('shop_home',$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:shop&sid='.$it618_waimai_waimai['id']);
		$homehotwaimai.='<div class="big-goods '.$tmpfloat.'">
							  <a class="big-goods-img" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_waimai_waimai['it618_logo'].'" alt="'.$it618_waimai_waimai['it618_name'].'" width="341" height="223" /></a>
							  <div class="big-goods-info">
								  <h3>
									  <a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_waimai_waimai['it618_name'].'">'.$it618_waimai_waimai['it618_name'].' '.$ShopPowerIco.'</a>
								  </h3>
								  <div class="big-goods-price">
									 <span title="'.$it618_waimai_waimai['it618_addr'].'">'.cutstr($it618_waimai_waimai['it618_addr'],40,'...').$mapstr.'</span><br><span style="float:right"><a href="'.$tmpurl.'" target="_blank">'.$it618_waimai_lang['s1639'].'</a></span><font color="#666" style="font-size:13px">'.str_replace(it618_waimai_getlang('s1175'),"",$tmplevelarr[0]).':</font><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_waimai_level['it618_img'].'">
								  </div>
							  </div>
						  </div>';
		if($n==count($tmpidsarr)||$n%2==0)$homehotwaimai.='</li>';
		$n=$n+1;
	}
}

foreach(C::t('#it618_waimai#it618_waimai_focus')->fetch_all_by_type_order(8) as $it618_waimai_focus) {
	if($it618_waimai_focus['it618_url']!=''){
		$str_focus.='<li><a href="'.$it618_waimai_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="705" height="300" /></a></li>';
	}else{
		$str_focus.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="705" height="300" /></li>';
	}
}

foreach(C::t('#it618_waimai#it618_waimai_focus')->fetch_all_by_type_order(17) as $it618_waimai_focus) {
	if($it618_waimai_focus['it618_url']!=''){
		$str_focus3.='<li><a href="'.$it618_waimai_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="223" height="228" /></a></li>';
	}else{
		$str_focus3.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="223" height="228" /></li>';
	}
}

foreach(C::t('#it618_waimai#it618_waimai_focus')->fetch_all_by_type_order(18) as $it618_waimai_focus) {
	if($it618_waimai_focus['it618_url']!=''){
		$str_focus4.='<li><a href="'.$it618_waimai_focus['it618_url'].'" target="_blank"><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="223" height="228" /></a></li>';
	}else{
		$str_focus4.='<li><img class="dynload lsSwitchload" src="source/plugin/it618_waimai/images/a.gif" imgsrc="'.$it618_waimai_focus['it618_img'].'" width="223" height="228" /></li>';
	}
}

$zjsaleshop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('zjsaleshop');
$weeksaleshop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('weeksaleshop');
$hotshop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('hotshop');

$tmparr=explode(",",$zjsaleshop);
if(count($tmparr)>2){
	$zjsaleshop_count=$tmparr[0];
	$zjsaleshop_order=$tmparr[2];
}else{
	$zjsaleshop_count=15;
	$zjsaleshop_order=1;
}

$tmparr=explode(",",$weeksaleshop);
if(count($tmparr)>2){
	$weeksaleshop_count=$tmparr[0];
	$weeksaleshop_order=$tmparr[2];
}else{
	$weeksaleshop_count=15;
	$weeksaleshop_order=2;
}

$tmparr=explode(",",$hotshop);
if(count($tmparr)>2){
	$hotshop_count=$tmparr[0];
	$hotshop_order=$tmparr[2];
}else{
	$hotshop_count=15;
	$hotshop_order=4;
}

if($zjsaleshop_count!=0||$weeksaleshop_count!=0||$hotshop_count!=0){
		
	$homegoods_arr=array("zjsaleshop"=>$zjsaleshop_order,"weeksaleshop"=>$weeksaleshop_order,"hotshop"=>$hotshop_order);
	asort($homegoods_arr);
	
	$n=1;
	foreach($homegoods_arr as $key=>$homegoods){
		if($n==1)$current=' class="current" ';else $current=' ';
		if($key=='zjsaleshop'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-new"),\'rc-new\');get_home_shop(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-new" onclick="tabCutover(this,\'rc-new\');get_home_shop(\''.$key.'\');" title="'.$it618_waimai_lang['t344'].'">'.$it618_waimai_lang['t345'].'<i></i></span>';
		}
		
		if($key=='weeksaleshop'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-week"),\'re-week\');get_home_shop(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-week" onclick="tabCutover(this,\'re-week\');get_home_shop(\''.$key.'\');" title="'.$it618_waimai_lang['t346'].'">'.$it618_waimai_lang['t347'].'<i></i></span>';
		}
		
		if($key=='hotshop'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-hotjf"),\'re-hotjf\');get_home_shop(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-re-hotjf" onclick="tabCutover(this,\'re-hotjf\');get_home_shop(\''.$key.'\');">'.$it618_waimai_lang['t548'].'<i></i></span>';
		}
		$n=$n+1;
	
		if($key=='zjsaleshop'){
			$home_shop.='<div class="rc-new" id="home_shop_'.$key.'"></div>';
		}
		
		if($key=='weeksaleshop'){
			$home_shop.='<div class="re-week" id="home_shop_'.$key.'"></div>';
		}
		
		if($key=='hotshop'){
			$home_shop.='<div class="re-hotjf" id="home_shop_'.$key.'"></div>';
		}
	}
	
	$homegoods_str='<div class="recommend-goods">
			<div class="recommend-title">
				'.$tab_goods.'
			</div>
			<div class="recommend-content">
				'.$home_shop.'
			</div>
			</div>';
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class')." where it618_img='' ORDER BY it618_order");
while($it618_waimai_waimai_class = DB::fetch($query1)) {
	if($it618_waimai_waimai_class['it618_waimaicount']!=0){
		$str_classnav.='<li><a href="javascript:void(0);" class="'.$it618_waimai_waimai_class['it618_cssname'].' newga ga">'.$it618_waimai_waimai_class['it618_classnamenav'].'</a></li>';
		
		$tmpurl=it618_waimai_getrewrite('waimai_list',$it618_waimai_waimai_class['id'],'plugin.php?id=it618_waimai:list&class1='.$it618_waimai_waimai_class['id']);
		$str_waimai.='<div class="index-floor">
						<h2 class="index-floor-title">
							<a class="'.$it618_waimai_waimai_class['it618_cssname'].'" href="'.$tmpurl.'">'.$it618_waimai_waimai_class['it618_classname'].'</a>
							<div class="fr">
								{it618classtj}
								<a href="'.$tmpurl.'" target="_blank">'.it618_waimai_getlang('s874').'&nbsp;<em>&gt;&gt;</em></a>
							</div>
						</h2>
						<div class="index-goods-list cl">
							{it618waimai}
						</div>
						<div class="floor-more"><a href="'.$tmpurl.'">'.it618_waimai_getlang('s875').$it618_waimai_waimai_class['it618_classname'].'&nbsp;&gt;&gt;</a></div>
					</div>';
		$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class1')." where it618_class_id=".$it618_waimai_waimai_class['id']." ORDER BY it618_order");
		$it618classtj='';
		while($it618_waimai_waimai_class1 = DB::fetch($query2)) {
			if($it618_waimai_waimai_class1['it618_color']!="")
			$tmpname='<font color='.$it618_waimai_waimai_class1['it618_color'].'>'.$it618_waimai_waimai_class1['it618_classname'].'</font>';else $tmpname=$it618_waimai_waimai_class1['it618_classname'];
			
			$tmpurl=it618_waimai_getrewrite('waimai_list',$it618_waimai_waimai_class['id'].'@'.$it618_waimai_waimai_class1['id'],'plugin.php?id=it618_waimai:list&class1='.$it618_waimai_waimai_class['id'].'&class2='.$it618_waimai_waimai_class1['id']);
			if($it618_waimai_waimai_class1['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'" target="_blank">'.$tmpname.'</a><span></span>';
	
			if($i1ii1[5]!='_')return;
		}
		
		$it618waimai='';
		foreach(C::t('#it618_waimai#it618_waimai_waimai')->fetch_all_by_search(
			'it618_state=2 and it618_htstate=1','it618_order desc','',0,0,$it618_waimai_waimai_class['id'],0,0,$startlimit,($it618_waimai_waimai_class['it618_waimaicount'])
		) as $it618_waimai_waimai) {
			
			$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
			$ShopPowerIco='';
			if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" align="absmiddle" style="margin-top:3px;"/>';
				
			if($it618_waimai_waimai['it618_mappoint']!='')$mapstr=' <a href="javascript:"><img class="waimaimap" name="'.$it618_waimai_waimai['id'].'" src="source/plugin/it618_waimai/images/map.png"></a>';
			
			$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$it618_waimai_waimai['it618_levelsum']);
			
			$tmpurl=it618_waimai_getrewrite('shop_home',$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:shop&sid='.$it618_waimai_waimai['id']);
			$it618waimai.='<div class="index-goods">
								<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
									<img class="dynload" imgsrc="'.$it618_waimai_waimai['it618_logo'].'" src="source/plugin/it618_waimai/images/a.gif" alt="'.$it618_waimai_waimai['it618_name'].'"/>
								</a>
								<h3>
									<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_waimai_waimai['it618_name'].'">'.$it618_waimai_waimai['it618_name'].' '.$ShopPowerIco.'</a>
								</h3>
								<div class="index-goods-info">
									<span title="'.$it618_waimai_waimai['it618_addr'].'">'.cutstr($it618_waimai_waimai['it618_addr'],30,'...').$mapstr.'</span><br>'.it618_waimai_getlang('s1300').':'.$it618_waimai_waimai['it618_views'].' '.it618_waimai_getlang('s1298').':'.$it618_waimai_waimai['it618_salecount'].' '.it618_waimai_getlang('s1301').':'.$it618_waimai_waimai['it618_pjcount'].' '.it618_waimai_getlang('s1302').':'.$it618_waimai_waimai['it618_haopjbl'].'%<br><span style="float:right"><a href="'.$tmpurl.'" target="_blank">'.$it618_waimai_lang['s1639'].'</a></span><font color="#666" style="font-size:13px">'.str_replace(it618_waimai_getlang('s1175'),"",$tmplevelarr[0]).':</font><img style="vertical-align:middle;margin-top:-3px" src="'.$it618_waimai_level['it618_img'].'">
								</div>
							</div>';
			
			if($i1ii1[6]!='w')return;
		}
		
		$str_waimai=str_replace("{it618classtj}",$it618classtj,$str_waimai);
		$str_waimai=str_replace("{it618waimai}",$it618waimai,$str_waimai);
	}
}

$pagetype='index';
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/hongbao.func.php';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:waimai_default');
?>