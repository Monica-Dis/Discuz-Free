<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$gwcid=intval($_GET['gwcid']);
$saleid=intval($_GET['saleid']);

if(!($it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($gwcid))){
	echo 'alertit618_split'.it618_waimai_getlang('s1110');exit;
}

if(!($it618_waimai_sale = C::t('#it618_waimai#it618_waimai_sale')->fetch_by_id($saleid))){
	echo 'alertit618_split'.it618_waimai_getlang('s1110');exit;
}

$tmpstr=$it618_waimai_lang['s1254'];
if($it618_waimai_sale['it618_pj']>0){
	$tmpstr=$it618_waimai_lang['s1250'];
	
	$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
	if(!in_array($_G['uid'],$saleadmin)){
		echo 'alertit618_split'.it618_waimai_getlang('s1109');exit;
	}
}

$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);

$it618_waimai_goods=C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($it618_waimai_sale['it618_pid']);

if($it618_waimai_sale['it618_pj']==1)$it618_pj1='checked="checked"';
if($it618_waimai_sale['it618_pj']==2)$it618_pj2='checked="checked"';
if($it618_waimai_sale['it618_pj']==3)$it618_pj3='checked="checked"';

$it618_waimai_sale['it618_content_pj']=str_replace("[br]","\n",$it618_waimai_sale['it618_content_pj']);

$pname=$it618_waimai_goods['it618_name'];
$pimg=it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']);

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:salepj');
?>