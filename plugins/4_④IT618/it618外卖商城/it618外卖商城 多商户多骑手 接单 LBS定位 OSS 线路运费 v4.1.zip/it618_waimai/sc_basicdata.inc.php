<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_header.func.php';

$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($ShopId);
if(submitcheck('it618submit')){
	if($_GET['it618_name']==''){
		it618_cpmsg(it618_waimai_getlang('s130'), "plugin.php?id=it618_waimai:sc_basicdata$adminsid", 'error');
	}
	if($_GET['it618_tel']==''){
		it618_cpmsg(it618_waimai_getlang('s131'), "plugin.php?id=it618_waimai:sc_basicdata$adminsid", 'error');
	}
	if($_GET['it618_qq']==''){
		it618_cpmsg(it618_waimai_getlang('s132'), "plugin.php?id=it618_waimai:sc_basicdata$adminsid", 'error');
	}
	if($_GET['it618_addr']==''){
		it618_cpmsg(it618_waimai_getlang('s133'), "plugin.php?id=it618_waimai:sc_basicdata$adminsid", 'error');
	}
	
	if($it618_waimai['waimai_isedit']==1||isset($_GET['adminsid'])){
		
		$it618_mappoint=dhtmlspecialchars($_GET['it618_mappoint']);
		$tmparr=explode(",",$it618_mappoint);
		
		$lbsarr=it618_waimai_mapbdtotx($tmparr[1],$tmparr[0]);
		$it618_lbslat=$lbsarr['lat'];
		$it618_lbslng=$lbsarr['lng'];
		
		C::t('#it618_waimai#it618_waimai_waimai')->update($ShopId,array(
			'it618_class_id' => $_GET['it618_class'],
			'it618_class1_id' => $_GET['it618_class1'],
			'it618_area_id' => $_GET['it618_area'],
			'it618_area1_id' => $_GET['it618_area1'],
			'it618_lbslat' => $it618_lbslat,
			'it618_lbslng' => $it618_lbslng,
			'it618_mappoint' => $it618_mappoint,
			'it618_mapurl' => dhtmlspecialchars($_GET['it618_mapurl']),
		));
	}
	
	C::t('#it618_waimai#it618_waimai_waimai')->update($ShopId,array(
		'it618_logo' => dhtmlspecialchars($_GET['it618_logo']),
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_tel' => dhtmlspecialchars($_GET['it618_tel']),
		'it618_qq' => dhtmlspecialchars($_GET['it618_qq']),
		'it618_addr' => dhtmlspecialchars($_GET['it618_addr']),
		'it618_dianhua' => dhtmlspecialchars($_GET['it618_dianhua']),
		'it618_shouji' => dhtmlspecialchars($_GET['it618_shouji']),
		'it618_kefuqq' => dhtmlspecialchars($_GET['it618_kefuqq']),
		'it618_kefuwx' => dhtmlspecialchars($_GET['it618_kefuwx']),
		'it618_kefuqqname' => dhtmlspecialchars($_GET['it618_kefuqqname']),
		'it618_about' => dhtmlspecialchars($_GET['it618_about']),
		'it618_time' => $_G['timestamp']
	));
	
	it618_waimai_getwapppic($ShopId,dhtmlspecialchars($_GET['it618_logo']),0);

	it618_cpmsg(it618_waimai_getlang('s134'), "plugin.php?id=it618_waimai:sc_basicdata$adminsid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_waimai:sc_basicdata$adminsid");
showtableheaders(it618_waimai_getlang('s135'),'it618_waimai_basicdata');

foreach(C::t('#it618_waimai#it618_waimai_waimai_area')->fetch_all_by_search() as $it618_tmp) {
	$areatmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

$areatmp=str_replace('<option value='.$it618_waimai_waimai['it618_area_id'].'>','<option value='.$it618_waimai_waimai['it618_area_id'].' selected="selected">',$areatmp);
foreach(C::t('#it618_waimai#it618_waimai_waimai_area1')->fetch_all_by_it618_area_id($it618_waimai_waimai['it618_area_id']) as $it618_tmp) {
	$areatmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}
$areatmp1=str_replace('<option value='.$it618_waimai_waimai['it618_area1_id'].'>','<option value='.$it618_waimai_waimai['it618_area1_id'].' selected="selected">',$areatmp1);

foreach(C::t('#it618_waimai#it618_waimai_waimai_class')->fetch_all_by_search() as $it618_tmp) {
	$classtmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$classtmp=str_replace('<option value='.$it618_waimai_waimai['it618_class_id'].'>','<option value='.$it618_waimai_waimai['it618_class_id'].' selected="selected">',$classtmp);
foreach(C::t('#it618_waimai#it618_waimai_waimai_class1')->fetch_all_by_it618_class_id($it618_waimai_waimai['it618_class_id']) as $it618_tmp) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$classtmp1=str_replace('<option value='.$it618_waimai_waimai['it618_class1_id'].'>','<option value='.$it618_waimai_waimai['it618_class1_id'].' selected="selected">',$classtmp1);

echo '<tr><td width=80>'.it618_waimai_getlang('s136').'</td><td>'.$ShopPower.'</td></tr>';

if($it618_waimai['waimai_isedit']==1||isset($_GET['adminsid'])){
echo '<tr><td>'.it618_waimai_getlang('s137').'</td><td><select name="it618_area" onchange="redirec_area(this.options.selectedIndex)">'.$areatmp.'</select><select id="it618_area" name="it618_area1">'.$areatmp1.'</select></td></tr>';

echo '<tr><td>'.it618_waimai_getlang('s878').'</td><td><select name="it618_class" onchange="redirec_class(this.options.selectedIndex)" style="margin-top:3px">'.$classtmp.'</select><select id="it618_class" name="it618_class1" style="margin-top:3px">'.$classtmp1.'</select></td></tr>';

$mapjsstr='if(document.getElementById("it618_mappoint").value==""){
			alert("'.it618_waimai_getlang('s902').'");
			return false;
		}';

}

echo '<tr><td>'.it618_waimai_getlang('s139').'</td><td><img id="img1" src="'.$it618_waimai_waimai['it618_logo'].'" width="198" height="126" align="absmiddle"/><input type="text" id="url1" name="it618_logo" readonly="readonly" value="'.$it618_waimai_waimai['it618_logo'].'"/> <input type="button" id="image1" value="'.it618_waimai_getlang('s140').'" /> '.it618_waimai_getlang('s138').' '.it618_waimai_getlang('s879').':341px*223px</td></tr>
<tr><td>'.it618_waimai_getlang('s158').'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name" value="'.$it618_waimai_waimai['it618_name'].'">'.it618_waimai_getlang('s138').' <font color="red">'.it618_waimai_getlang('s115').'</font></td></tr>
<tr><td>'.it618_waimai_getlang('s162').'</td><td><input type="text" class="txt" style="width:400px" id="it618_addr" name="it618_addr" value="'.$it618_waimai_waimai['it618_addr'].'">'.it618_waimai_getlang('s138').' <font color="red">'.it618_waimai_getlang('s115').'</font></td></tr>
<tr><td><font color="red">'.it618_waimai_getlang('s159').'</font></td><td><input type="text" class="txt" style="width:252px" id="it618_tel" name="it618_tel" value="'.$it618_waimai_waimai['it618_tel'].'"><font color="red">QQ'.$it618_waimai_lang['s53'].'</font><input type="text" class="txt" style="width:100px" id="it618_qq" name="it618_qq" value="'.$it618_waimai_waimai['it618_qq'].'">'.it618_waimai_getlang('s160').'<font color="red"> '.it618_waimai_getlang('s115').' '.it618_waimai_getlang('s161').'</font></td></tr>
<tr><td style="background-color:#e8e8e8">'.it618_waimai_getlang('s163').'</td><td style="background-color:#e8e8e8"><input type="text" class="txt" style="width:400px" id="it618_dianhua" name="it618_dianhua" value="'.$it618_waimai_waimai['it618_dianhua'].'">'.it618_waimai_getlang('s138').'</td></tr>
<tr><td style="background-color:#e8e8e8">'.it618_waimai_getlang('s164').'</td><td style="background-color:#e8e8e8"><input type="text" class="txt" style="width:400px" id="it618_shouji" name="it618_shouji" value="'.$it618_waimai_waimai['it618_shouji'].'">'.it618_waimai_getlang('s138').'</td></tr>
<tr><td style="background-color:#e8e8e8">'.it618_waimai_getlang('s165').'</td><td style="background-color:#e8e8e8"><input type="text" class="txt" style="width:400px" id="it618_kefuqq" name="it618_kefuqq" value="'.$it618_waimai_waimai['it618_kefuqq'].'">'.it618_waimai_getlang('s138').' '.it618_waimai_getlang('s166').'</td></tr>
<tr><td style="background-color:#e8e8e8">'.it618_waimai_getlang('s208').'</td><td style="background-color:#e8e8e8"><input type="text" class="txt" style="width:400px" id="it618_kefuwx" name="it618_kefuwx" value="'.$it618_waimai_waimai['it618_kefuwx'].'">'.it618_waimai_getlang('s138').' '.it618_waimai_getlang('s209').'</td></tr>
<tr><td style="background-color:#e8e8e8">'.it618_waimai_getlang('s893').'</td><td style="background-color:#e8e8e8"><input type="text" class="txt" style="width:400px" id="it618_kefuqqname" name="it618_kefuqqname" value="'.$it618_waimai_waimai['it618_kefuqqname'].'">'.it618_waimai_getlang('s138').' '.it618_waimai_getlang('s894').'</td></tr>
<tr><td style="background-color:#e8e8e8">'.it618_waimai_getlang('s895').'</td><td style="background-color:#e8e8e8"><textarea class="txt" style="width:400px;height:60px" name="it618_about">'.$it618_waimai_waimai['it618_about'].'</textarea> '.it618_waimai_getlang('s138').'</td></tr>';

if($it618_waimai['waimai_isedit']==1||isset($_GET['adminsid'])){
	if($it618_waimai_waimai['it618_lbslat']>0){
		$it618_lbs='<br><br>'.$it618_waimai_lang['s882'].'<font color=red>lat:'.$it618_waimai_waimai['it618_lbslat'].' lng:'.$it618_waimai_waimai['it618_lbslng'].'</font> <font color=#999>'.$it618_waimai_lang['s883'].'</font><br><br>';
	}
	
	echo '<tr><td>'.it618_waimai_getlang('s880').'</td><td><iframe width="100%" height="450px" marginwidth="0" marginheight="0"  frameborder="no" scrolling="no"  src="'.$_G['siteurl'].'plugin.php?id=it618_waimai:getpoint&ispc=1&mappoint='.$it618_waimai_waimai['it618_mappoint'].'"></iframe><input type="hidden" id="it618_mappoint" name="it618_mappoint" value="'.$it618_waimai_waimai['it618_mappoint'].'"><br><br>
	<font color=red><b>'.$it618_waimai_lang['s1840'].'</b></font><input type="text" class="txt" style="width:400px" id="it618_mapurl" name="it618_mapurl" value="'.$it618_waimai_waimai['it618_mapurl'].'"> '.$it618_waimai_lang['s1841'].'
	'.$it618_lbs.'
	</td></tr>
	';
}

if($it618_waimai['waimai_isedit']==1||isset($_GET['adminsid'])){
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_waimai_waimai_area'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_area')." ORDER BY it618_order");
	$n1=0;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$n2=0;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_area1')." where it618_area_id=".$it618_tmp1['id']." ORDER BY it618_order");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp1.='select_area['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_name'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
	
	echo '
	<script>
	var arrcount='.$count.';
	var select_area = new Array(arrcount);
	
	for (i=0; i<arrcount; i++) 
	{
	 select_area[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_area(x)
	{
	 var temp = document.getElementById("it618_area"); 
	 temp.options.length=0;
	 for (i=0;i<select_area[x].length;i++)
	 {
	  temp.options[i]=new Option(select_area[x][i].text,select_area[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	</script>';
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_waimai_waimai_class'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class')." where it618_img='' ORDER BY it618_order");
	$n1=0;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$n2=0;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class1')." where it618_class_id=".$it618_tmp1['id']." ORDER BY it618_order");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
	
	echo '
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount);
	
	for (i=0; i<arrcount; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class"); 
	 temp.options.length=0;
	 for (i=0;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	</script>';
}

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_waimai_getlang('s120').'" /></div></td></tr>';

echo '
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor = K.editor({
			uploadJson : \'source/plugin/it618_waimai/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=640'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_waimai/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true
		});
		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
	});
	
	function checkvalue(){
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_waimai_getlang('s130').'");
			return false;
		}
		if(document.getElementById("it618_tel").value==""){
			alert("'.it618_waimai_getlang('s131').'");
			return false;
		}
		if(document.getElementById("it618_qq").value==""){
			alert("'.it618_waimai_getlang('s132').'");
			return false;
		}
		if(document.getElementById("it618_addr").value==""){
			alert("'.it618_waimai_getlang('s133').'");
			return false;
		}
		if(document.getElementById("it618_kefuqq").value!=""){
			if(document.getElementById("it618_kefuqqname").value==""){
				alert("'.it618_waimai_getlang('s1264').'");
				return false;
			}
		}
		'.$mapjsstr.'
	}
</script>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_footer.func.php';
?>