<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_waimai/js/Calendar.js"></script>
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/js/jquery.js"></script>
';

$salestate=it618_waimai_getsalestate();

showtableheaders(it618_waimai_getlang('s1113'),'it618_waimai_sum');
	
	echo '<tr><td colspan="15"><div class="fixsel">'.it618_waimai_getlang('s1115').' <input id="finduid" class="txt" style="width:68px" /> '.it618_waimai_getlang('s1116').' <select id="state"><option value=0>'.it618_waimai_getlang('s1117').'</option>'.$salestate.'</select> '.it618_waimai_getlang('s1122').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_waimai_getlang('s1123').'" onclick="findsalelist()" /> <input type="button" class="btn" value="'.it618_waimai_getlang('s236').'" onclick="dao()" /></div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>
	<tr class="header">
	<th width=50>'.$it618_waimai_lang['s1124'].'</th>
	<th>'.$it618_waimai_lang['s1127'].'</th>
	<th>'.$it618_waimai_lang['s1105'].'</th>
	<th>'.$it618_waimai_lang['s1126'].'</th>
	<th>'.$it618_waimai_lang['s1132'].'</th>
	<th>'.$it618_waimai_lang['s1133'].'</th>
	<th>'.$it618_waimai_lang['s1131'].'</th>
	<th width=100>'.$it618_waimai_lang['s1134'].'</th>
	<th width=150>'.$it618_waimai_lang['s1135'].'</th>
	</tr>';
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_waimai/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr><div id="tmpsalebtn"></div><div id="saleshopfahuo"></div>';

showtablefooter();
echo '
<script>
var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax";
var sqlurl="";
function getsalelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_WAIMAI.get(url+sqlurl+"'.$adminsid.'&sid='.$ShopId.'&formhash='.FORMHASH.'", {ac:"sale_get",ac1:"shop"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_WAIMAI("#tr_salesum").html(tmparr[0]);
	IT618_WAIMAI("#tr_salelist").html(tmparr[1]);
	IT618_WAIMAI("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
getsalelist(saleurl);

function findsalelist(){
	var finduid = document.getElementById("finduid").value;
	var state = document.getElementById("state").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&finduid="+finduid+"&state="+state+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax";
	getsalelist(url);
}

function dao(){
	findsalelist();
	IT618_WAIMAI.get(saleurl+sqlurl+"'.$adminsid.'&sid='.$ShopId.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_dao",ac1:"shop"},function (data, textStatus){
	window.open(data);
	}, "html");	
}

function sale_getsale(saleid){
	if(confirm("'.it618_waimai_getlang('s1160').'")){
		IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax'.$adminsid.'&sid='.$ShopId.'&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_getsale"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

function sale_sqfahuo(saleid){
	if(confirm("'.it618_waimai_getlang('s1162').'")){
		IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax'.$adminsid.'&sid='.$ShopId.'&saleid="+saleid+"&formhash='.FORMHASH.'", {ac:"sale_sqfahuo"},function (data, textStatus){
		var tmparr=data.split("it618_split");
		if(tmparr[0]=="ok"){
			alert(tmparr[1]);
			getsalelist(saleurl);
		}else{
			alert(tmparr[1]);
		}
		}, "html");
	}
}

var dialog_saleshopfahuo,salefahuoid=0;
KindEditor.ready(function(K) {K(\'#saleshopfahuo\').click(function() {
	getsaleshopfahuo(K);
});});

function sale_shopfahuo(saleid){
	if(salefahuoid==0){
		salefahuoid=saleid;
		IT618_WAIMAI("#saleshopfahuo").click();
	}
}

function getsaleshopfahuo(K){
IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:saleshopfahuo"+"&gwcid="+salefahuoid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	IT618_WAIMAI("#clipboardbtnsale").attr("data-clipboard-text",tmparr[1]);
	
	dialog_saleshopfahuo = K.dialog({
		width : 533,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[2]+\'</div>\',
		closeBtn : {
			name : \''.$it618_waimai_lang['t571'].'\',
			click : function(e) {
				dialog_saleshopfahuo.remove();
				salefahuoid=0;
			}
		}
	});
	
	IT618_WAIMAI(\'.ns-sub-a\').click(function(){
		
		if(confirm("'.$it618_waimai_lang['s1166'].'")){
			
			IT618_WAIMAI.post("'.$_G['siteurl'].'plugin.php?id=it618_waimai:ajax"+"&ac=sale_shopfahuo"+"&saleid="+salefahuoid+"&formhash='.FORMHASH.'",IT618_WAIMAI("#it618_salefahuo").serialize(),function (data, textStatus){
				var tmparr=data.split("it618_split");
			
				if(tmparr[0]=="ok"){
					alert(tmparr[1]);
					dialog_saleshopfahuo.remove();
					getsalelist(saleurl);
					salefahuoid=0;
				}else{
					alert(tmparr[1]);
				}
			}, "html");
		}
	})
	
	IT618_WAIMAI(\'.ns-sub-b\').click(function(){
		dialog_saleshopfahuo.remove();
		salefahuoid=0;
	})
	
	}, "html");		
}

KindEditor.ready(function(K) {K(\'#tmpsalebtn\').click(function() {
	
	IT618_WAIMAI.get("'.$_G['siteurl'].'plugin.php?id=it618_waimai:showsale&gwcid="+gwcid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	if(tmparr[0]=="alert"){
		alert(tmparr[1]);
		return;
	}
	
	dialog_sale = K.dialog({
		width : 810,
		title : \''.it618_waimai_getlang('s1118').'\',
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.it618_waimai_getlang('s1107').'\',
			click : function(e) {
				dialog_sale.remove();
			}
		}
	});
	
	}, "html");	
});});

var gwcid;
function showsale(saleid){
	gwcid=saleid;
	document.getElementById("tmpsalebtn").click();
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_footer.func.php';
?>