<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/php/aliyunossconfig.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/php/aliyunossconfig.php';
}

if(submitcheck('it618submit')){
	$it618_bucket_url=trim($_GET['it618_bucket_url']);
	$urlarrtmp=explode("://",$it618_bucket_url);
	if(count($urlarrtmp)==1){
		$urlarr=explode("https://",$_G['siteurl']);
		if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
		$it618_bucket_url=$httpstr.$it618_bucket_url;
	}
	
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/php/aliyunossconfig.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {

		$fileData = '$it618_isok=\''.trim($_GET['it618_isok'])."';\n";
		
		$fileData .= '$it618_access_key_id=\''.trim($_GET['it618_access_key_id'])."';\n";
		
		$fileData .= '$it618_access_key_secret=\''.trim($_GET['it618_access_key_secret'])."';\n";
		
		$fileData .= '$it618_bucket_name=\''.trim($_GET['it618_bucket_name'])."';\n";
		
		$fileData .= '$it618_bucket_endpoint=\''.trim($_GET['it618_bucket_endpoint'])."';\n";
		
		$fileData .= '$it618_bucket_url=\''.$it618_bucket_url."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/php/aliyunoss.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		
		$fileData = 'require_once \'aliyun-oss-php-sdk-2.0.1.phar'."';\n";
		
		$fileData .= 'const OSS_ACCESS_ID = \''.trim($_GET['it618_access_key_id'])."';\n";

		$fileData .= 'const OSS_ACCESS_KEY = \''.trim($_GET['it618_access_key_secret'])."';\n";
		
		$fileData .= 'const OSS_ENDPOINT = \''.trim($_GET['it618_bucket_endpoint'])."';\n";
		
		$fileData .= '$it618_bucket_url=\''.$it618_bucket_url."';\n";
		
		$fileData .= '$it618_bucket_name=\''.trim($_GET['it618_bucket_name'])."';\n";
		
		$fileData .= '$ossClient=new OSS\OssClient(OSS_ACCESS_ID, OSS_ACCESS_KEY, OSS_ENDPOINT, false)'.";\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_waimai_lang['s90'], "action=plugins&identifier=$identifier&cp=admin_aliyunoss&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_aliyunoss&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_waimai_aliyunoss');


if($it618_isok==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";

echo '<style>table tr td{line-height:20px}</style>
<tr><td width=150>'.$it618_waimai_lang['s1979'].'</td><td><input type="checkbox" id="it618_isok" name="it618_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.$it618_waimai_lang['s1980'].'</label></td></tr>
<tr><td>'.$it618_waimai_lang['s1982'].'</td><td><input type="text" name="it618_access_key_id" style="width:600px" value="'.$it618_access_key_id.'"></td></tr>
<tr><td>'.$it618_waimai_lang['s1983'].'</td><td><input type="text" name="it618_access_key_secret" style="width:600px" value="'.$it618_access_key_secret.'"></td></tr>
<tr><td>'.$it618_waimai_lang['s1984'].'</td><td><input type="text" name="it618_bucket_name" style="width:600px" value="'.$it618_bucket_name.'"></td></tr>
<tr><td>'.$it618_waimai_lang['s1985'].'</td><td><input type="text" name="it618_bucket_endpoint" style="width:600px" value="'.$it618_bucket_endpoint.'"></td></tr>
<tr><td>'.$it618_waimai_lang['s1986'].'</td><td><input type="text" name="it618_bucket_url" style="width:600px" value="'.$it618_bucket_url.'"></td></tr>


<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_waimai_lang['s89'].'" /></div></td></tr>
';

showtablefooter();

?>