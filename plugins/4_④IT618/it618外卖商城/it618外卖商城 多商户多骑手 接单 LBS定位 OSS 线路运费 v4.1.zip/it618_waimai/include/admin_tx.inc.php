<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

if($_GET['it618_type']==0)$selected0='selected="selected"';
if($_GET['it618_type']==10)$selected10='selected="selected"';
if($_GET['it618_type']==1)$selected1='selected="selected"';
if($_GET['it618_type']==2)$selected2='selected="selected"';
if($_GET['it618_type']==3)$selected3='selected="selected"';

if($_GET['it618_state']==0)$stateselected0='selected="selected"';
if($_GET['it618_state']==1)$stateselected1='selected="selected"';
if($_GET['it618_state']==2)$stateselected2='selected="selected"';

$sql="&it618_type=".$_GET['it618_type']."&it618_time1=".$_GET['it618_time1']."&it618_time2=".$_GET['it618_time2']."&it618_state=".$_GET['it618_state'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[7]!='a')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_waimai_tx = DB::fetch_first("SELECT * FROM ".DB::table('it618_waimai_tx')." where id=".$delid);

		if($it618_waimai_tx['it618_state']==1){
			DB::delete('it618_waimai_tx', "id=$delid");

			$del=$del+1;
		}
	}

	cpmsg($it618_waimai_lang['s938'].$del, "action=plugins&identifier=$identifier&cp=admin_tx&pmod=admin_tx&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_ok')){
	$ok=0;
	if($reabc[8]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_waimai_tx = DB::fetch_first("SELECT * FROM ".DB::table('it618_waimai_tx')." where id=".$delid);
		
		if($it618_waimai_tx['it618_state']!=2){
			DB::query("update ".DB::table('it618_waimai_tx')." set it618_state=2 WHERE id=".$delid);
			
			it618_waimai_sendmessage('tx_shop',$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_waimai_lang['s948'].$ok, "action=plugins&identifier=$identifier&cp=admin_tx&pmod=admin_tx&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=12)return;


showformheader("plugins&identifier=$identifier&cp=admin_tx&pmod=admin_tx&operation=$operation&do=$do");
showtableheaders($it618_waimai_lang['s949'],'it618_waimai_sum');
	showsubmit('it618sercsubmit', $it618_waimai_lang['s912'], '<script charset="utf-8" src="source/plugin/it618_waimai/js/Calendar.js"></script>'.$it618_waimai_lang['s950'].' <select name="it618_type"><option value="0" '.$selected0.'>'.$it618_waimai_lang['s951'].'</option><option value="10" '.$selected10.'>'.$it618_waimai_lang['s1918'].'</option><option value="1" '.$selected1.'>'.$it618_waimai_lang['s1919'].'</option><option value="2" '.$selected2.'>'.$it618_waimai_lang['s1920'].'</option><option value="3" '.$selected3.'>'.$it618_waimai_lang['s1921'].'</option></select> '.$it618_waimai_lang['s955'].' <select name="it618_state"><option value="0" '.$stateselected0.'>'.$it618_waimai_lang['s956'].'</option><option value="1" '.$stateselected1.'>'.$it618_waimai_lang['s957'].'</option><option value="2" '.$stateselected2.'>'.$it618_waimai_lang['s958'].'</option></select> '.$it618_waimai_lang['s954'].' <input name="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> - <input name="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>');
	
	$count = C::t('#it618_waimai#it618_waimai_tx')->count_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$_GET['it618_uid']);
	$sum = C::t('#it618_waimai#it618_waimai_tx')->sum_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$_GET['it618_uid']);
	if($sum=='')$sum=0;
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_tx&pmod=admin_tx&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=10>'.$it618_waimai_lang['s959'].'<font color=red>'.$count.'</font> '.$it618_waimai_lang['s960'].'<font color=red>'.$sum.'</font></td></tr>';
	showsubtitle(array('', $it618_waimai_lang['s961'],$it618_waimai_lang['s962'],$it618_waimai_lang['s963'],$it618_waimai_lang['s964'],$it618_waimai_lang['s965'],$it618_waimai_lang['s966'],$it618_waimai_lang['s967'],$it618_waimai_lang['s968'],$it618_waimai_lang['s969']));
	
	foreach(C::t('#it618_waimai#it618_waimai_tx')->fetch_all_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$_GET['it618_uid'], $startlimit,$ppp) as $it618_waimai_tx)    {
		
		$fwf=round(($it618_waimai_tx['it618_price']*$it618_waimai_tx['it618_bl']/100),2);
		$it618_waimai_bank = DB::fetch_first("SELECT * FROM ".DB::table('it618_waimai_bank')." where it618_shopid=".$it618_waimai_tx['it618_shopid']);
		$shopname = C::t('#it618_waimai#it618_waimai_waimai')->fetch_name_by_id($it618_waimai_tx['it618_shopid']);
		
		if($it618_waimai_tx['it618_type']==10){
			$it618_type=$it618_waimai_lang['s1918'];
		}
		if($it618_waimai_tx['it618_type']==1){
			$it618_type=$it618_waimai_lang['s970'];
			$it618_type=str_replace("{alipayname}",$it618_waimai_bank['it618_alipayname'],$it618_type);
			$it618_type=str_replace("{alipay}",$it618_waimai_bank['it618_alipay'],$it618_type);
		}
		if($it618_waimai_tx['it618_type']==2){
			$it618_type=$it618_waimai_lang['s971'];
			$it618_type=str_replace("{wxname}",$it618_waimai_bank['it618_wxname'],$it618_type);
			$it618_type=str_replace("{wx}",$it618_waimai_bank['it618_wx'],$it618_type);
		}
		if($it618_waimai_tx['it618_type']==3){
			$it618_type=$it618_waimai_lang['s972'];
			$it618_type=str_replace("{name}",$it618_waimai_bank['it618_name'],$it618_type);
			$it618_type=str_replace("{bankname}",$it618_waimai_bank['it618_bankname'],$it618_type);
			$it618_type=str_replace("{bankid}",$it618_waimai_bank['it618_bankid'],$it618_type);
			$it618_type=str_replace("{bankaddr}",$it618_waimai_bank['it618_bankaddr'],$it618_type);
		}

		if($it618_waimai_tx['it618_state']==1)$it618_state='<font color=red>'.$it618_waimai_lang['s957'].'</font>';
		if($it618_waimai_tx['it618_state']==2)$it618_state='<font color=green>'.$it618_waimai_lang['s958'].'</font>';
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_waimai_tx[id].'" name="delete[]" value="'.$it618_waimai_tx[id].'">',
			'<font color=red>'.$it618_waimai_tx['it618_price'].'</font>',
			$it618_waimai_tx['it618_bl'],
			$fwf,
			'<font color=green>'.($it618_waimai_tx['it618_price']-$fwf).'</font>',
			$it618_waimai_tx['it618_bz'],
			'<div style="width:75px">'.date('Y-m-d H:i:s', $it618_waimai_tx['it618_time']).'</div>',
			$shopname,
			$it618_type,
			$it618_state
		));
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_waimai_lang['s70'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_waimai_lang['s975'].'" onclick="return confirm(\''.$it618_waimai_lang['s976'].'\')" /> <input type="submit" class="btn" name="it618submit_ok" value="'.$it618_waimai_lang['s994'].'" onclick="return confirm(\''.$it618_waimai_lang['s977'].'\')"/> '.$it618_waimai_lang['s978'].' &nbsp;<input type=hidden value=1 name=page /></div></td></tr>';

	if(count($reabc)!=12)return;
showtablefooter();
?>