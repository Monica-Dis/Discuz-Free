<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
$leveltype=$cp1-13;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_waimai#it618_waimai_level')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_waimai#it618_waimai_level')->update($id,array(
				'it618_img' => $_GET['it618_img'][$id],
				'it618_name' => $_GET['it618_name'][$id],
				'it618_salecount1' => $_GET['it618_salecount1'][$id],
				'it618_salecount2' => $_GET['it618_salecount2'][$id]
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_img_array = !empty($_GET['newit618_img']) ? $_GET['newit618_img'] : array();
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_salecount1_array = !empty($_GET['newit618_salecount1']) ? $_GET['newit618_salecount1'] : array();
	$newit618_salecount2_array = !empty($_GET['newit618_salecount2']) ? $_GET['newit618_salecount2'] : array();
	
	foreach($newit618_name_array as $key => $value) {

		C::t('#it618_waimai#it618_waimai_level')->insert(array(
			'it618_type' => $leveltype,
			'it618_img' => $newit618_img_array[$key],
			'it618_name' => $newit618_name_array[$key],
			'it618_salecount1' => $newit618_salecount1_array[$key],
			'it618_salecount2' => $newit618_salecount2_array[$key],
		), true);
		$ok2=$ok2+1;
	}

	cpmsg($it618_waimai_lang['s5'].$ok1.' '.$it618_waimai_lang['s6'].$ok2.' '.$it618_waimai_lang['s7'].$del.')', "action=plugins&identifier=$identifier&cp=admin_level&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_level&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_waimai_level');

	if($leveltype==0){
		$tmpstr=$it618_waimai_lang['s1270'];
	}else{
		$tmpstr=$it618_waimai_lang['s1271'];
	}

	$count = C::t('#it618_waimai#it618_waimai_level')->count_by_type($leveltype);
	echo '<tr><td colspan=10>'.$it618_waimai_lang['s829'].$count.'<span style="float:right;color:red">'.$tmpstr.'</font></td></tr>';
	
	if($leveltype==0){
		showsubtitle(array('', $it618_waimai_lang['s830'],$it618_waimai_lang['s831'],$it618_waimai_lang['s1252'],$it618_waimai_lang['s1253']));
	}else{
		showsubtitle(array('', $it618_waimai_lang['s830'],$it618_waimai_lang['s831'],$it618_waimai_lang['s832'],$it618_waimai_lang['s833']));
	}
	
	foreach(C::t('#it618_waimai#it618_waimai_level')->fetch_all_by_type($leveltype) as $it618_waimai_level) {

		showtablerow('', array('class="td25"', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_waimai_level[id]\">",
			'<img src="'.$it618_waimai_level['it618_img'].'" id="img'.$it618_waimai_level['id'].'" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url'.$it618_waimai_level['id'].'" name="it618_img['.$it618_waimai_level['id'].']" readonly="readonly" value="'.$it618_waimai_level['it618_img'].'" /> <input type="button" id="image'.$it618_waimai_level['id'].'" value="'.$it618_waimai_lang['s821'].'" />',
			'<input class="txt" type="text" style="width:100px;" name="it618_name['.$it618_waimai_level['id'].']" value="'.$it618_waimai_level['it618_name'].'">',
			'<input class="txt" type="text" style="width:110px;" name="it618_salecount1['.$it618_waimai_level['id'].']" value="'.$it618_waimai_level['it618_salecount1'].'">',
			'<input class="txt" type="text" style="width:110px;" name="it618_salecount2['.$it618_waimai_level['id'].']" value="'.$it618_waimai_level['it618_salecount2'].'">'
		));
		
		$editorjs.='K(\'#image'.$it618_waimai_level['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_waimai_level['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_waimai_level['id'].'\').val(url);
								K(\'#img'.$it618_waimai_level['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_waimai/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_waimai/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
$it618_waimai_lang184=$it618_waimai_lang['s184'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
	
		return [
				[[1,''], [1, '$it618_waimai_lang184'], [1, ' <input type="text" class="txt" style="width:100px;" name="newit618_name[]">'], [1, ' <input type="text" class="txt" style="width:100px;" name="newit618_salecount1[]">'], [1, ' <input class="txt" style="width:100px" type="text" name="newit618_salecount2[]">'], [1,'']]
				];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="5"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=12)return;
showtablefooter();
?>