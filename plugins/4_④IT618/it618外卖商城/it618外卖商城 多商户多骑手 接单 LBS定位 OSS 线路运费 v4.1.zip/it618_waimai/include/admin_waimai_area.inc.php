<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_waimai#it618_waimai_waimai_area')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_waimai#it618_waimai_waimai_area')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = trim($newit618_name_array[$key]);
		
		if($newit618_name != '') {
			
			C::t('#it618_waimai#it618_waimai_waimai_area')->insert(array(
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_waimai_lang['s5'].$ok1.' '.$it618_waimai_lang['s6'].$ok2.' '.$it618_waimai_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_waimai_area&pmod=admin_waimai_area&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=12)return;

showformheader("plugins&identifier=$identifier&cp=admin_waimai_area&pmod=admin_waimai_area&operation=$operation&do=$do");
showtableheaders($it618_waimai_lang['s779'],'it618_waimai_waimai_area');
	$count = C::t('#it618_waimai#it618_waimai_waimai_area')->count_by_search();
	
	echo '<tr><td colspan=4>'.$it618_waimai_lang['s11'].$count.'</td></tr>';
	showsubtitle(array('', $it618_waimai_lang['s12'], $it618_waimai_lang['s792'],$it618_waimai_lang['s13'],$it618_waimai_lang['s793'],$it618_waimai_lang['s14']));
	
	foreach(C::t('#it618_waimai#it618_waimai_waimai_area')->fetch_all_by_search() as $it618_waimai_waimai_area) {	
		
		$area1count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_waimai_waimai_area1')." WHERE it618_area_id=".$it618_waimai_waimai_area['id']);
		$waimaicount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_waimai_waimai')." WHERE it618_area_id=".$it618_waimai_waimai_area['id']);
		$disabled="";
		if($area1count>0)$disabled="disabled=\"disabled\"";
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_waimai_waimai_area[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_waimai_waimai_area[id]]\" value=\"$it618_waimai_waimai_area[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_name[$it618_waimai_waimai_area[id]]\" value=\"$it618_waimai_waimai_area[it618_name]\">",
			"<input id=\"c".$it618_waimai_waimai_area['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_waimai_waimai_area[id]]\" value=\"$it618_waimai_waimai_area[it618_color]\" onchange=\"updatecolorpreview('c".$it618_waimai_waimai_area['id']."')\"><input id=\"c".$it618_waimai_waimai_area['id']."\" onclick=\"c".$it618_waimai_waimai_area['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_waimai_waimai_area['id']."|c".$it618_waimai_waimai_area['id']."_v';showMenu({'ctrlid':'c".$it618_waimai_waimai_area['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_waimai_waimai_area['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_waimai_waimai_area['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			'<input class="txt" type="text" name="it618_order['.$it618_waimai_waimai_area['id'].']" value="'.$it618_waimai_waimai_area['it618_order'].'">',
			$area1count,
			$waimaicount,
			""
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_waimai_waimai_area['id']."');";
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_name[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_name[]">'], [1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1, ' <input class="txt" type="text" name="newit618_order[]" value="1">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=12)return;
showtablefooter();
?>