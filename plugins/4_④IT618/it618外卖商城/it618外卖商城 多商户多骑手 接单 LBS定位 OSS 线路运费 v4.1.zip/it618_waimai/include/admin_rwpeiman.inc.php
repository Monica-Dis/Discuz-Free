<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$it618sql='1';

if($_GET['state']) {
	$state0='';$state1='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$it618sql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$it618sql .= " AND it618_state = 0";$state1='selected="selected"';}
	if($_GET['state']==2){$it618sql .= " AND it618_state = 1";$state2='selected="selected"';}
	if($_GET['state']==3){$it618sql .= " AND it618_state = 2";$state3='selected="selected"';}
	if($_GET['state']==4){$it618sql .= " AND it618_state = 2 AND it618_clockstate = 1";$state4='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&state='.$_GET['state'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($delid);
		if($it618_waimai_rwpeiman['it618_state']!=2){
			
			C::t('#it618_waimai#it618_waimai_rwpeiman')->delete_by_id($delid);
			$del=$del+1;
		}
	}

	cpmsg($it618_waimai_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($delid);
		
		if($it618_waimai_rwpeiman['it618_state']==0){
			C::t('#it618_waimai#it618_waimai_rwpeiman')->update_it618_state_by_id($delid,2);
			it618_waimai_sendmessage('sqpm_user',$id);
			$ok=$ok+1;
		}
	}
	
	cpmsg($it618_waimai_lang['s323'].$ok, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($delid);
		
		if($it618_waimai_rwpeiman['it618_state']==0){
			C::t('#it618_waimai#it618_waimai_rwpeiman')->update_it618_state_by_id($delid,1);
			it618_waimai_sendmessage('sqpm_user',$id);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_waimai_lang['s324'].$ok, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_clock')){
	$ok=0;
	if($reabc[8]!='i')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($delid);
		
		if($it618_waimai_rwpeiman['it618_state']==2&&$it618_waimai_rwpeiman['it618_clockstate']==0){
			C::t('#it618_waimai#it618_waimai_rwpeiman')->update_it618_clockstate_by_id($delid,1);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_waimai_lang['s511'].$ok, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_unclock')){
	$ok=0;
	if($reabc[8]!='i')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($delid);
		
		if($it618_waimai_rwpeiman['it618_state']==2&&$it618_waimai_rwpeiman['it618_clockstate']==1){
			C::t('#it618_waimai#it618_waimai_rwpeiman')->update_it618_clockstate_by_id($delid,0);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_waimai_lang['s512'].$ok, "action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=12)return;

echo '
<style>table tr td{line-height:18px}</style>
';

showformheader("plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql);
showtableheaders($it618_waimai_lang['s1613'].'<span style="float:right"></span>','it618_waimai_rwpeiman');
	showsubmit('it618sercsubmit', $it618_waimai_lang['s330'], $it618_waimai_lang['s331'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.$it618_waimai_lang['s332'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_waimai_lang['s513'].' <select name="state"><option value=0 '.$state0.'>'.$it618_waimai_lang['s514'].'</option><option value=1 '.$state1.'>'.$it618_waimai_lang['s515'].'</option><option value=2 '.$state2.'>'.$it618_waimai_lang['s516'].'</option><option value=3 '.$state3.'>'.$it618_waimai_lang['s517'].'</option><option value=4 '.$state4.'>'.$it618_waimai_lang['s518'].'</option></select>');
	
	$count = C::t('#it618_waimai#it618_waimai_rwpeiman')->count_by_search($it618sql,'',$_GET['key'],$_GET['finduid']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_rwpeiman&pmod=admin_rwpeiman&operation=$operation&do=$do&page=$page".$sql);
	
	echo '<tr><td colspan=18>'.$it618_waimai_lang['s1607'].$count.'<span style="float:right;color:red">'.$it618_waimai_lang['s1634'].'</span></td></tr>';
	showsubtitle(array('', $it618_waimai_lang['s1610'],$creditname,$it618_waimai_lang['s1611'],$it618_waimai_lang['s1616'],$it618_waimai_lang['s1612']));
	
	foreach(C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_all_by_search(
		$it618sql,'id DESC',$_GET['key'],$_GET['finduid'],$startlimit,$ppp
	) as $it618_waimai_rwpeiman) {
		
		$username=C::t('#it618_waimai#it618_waimai_sale')->fetch_username_by_uid($it618_waimai_rwpeiman['it618_uid']);
		$creditnum=C::t('#it618_waimai#it618_waimai_sale')->fetch_extcredits_by_uid($it618_waimai['waimai_credit'],$it618_waimai_rwpeiman['it618_uid']);
		if($creditnum=="")$creditnum=0;
		
		$sumstr='';
		if($it618_waimai_rwpeiman['it618_state']==2){
			$sumstr=$it618_waimai_lang['s521'];
			$count1 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_state=3 and it618_rwpmid='.$it618_waimai_rwpeiman['id']);
			$sum1=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei','it618_state=3 and it618_rwpmid='.$it618_waimai_rwpeiman['id']);
			$count2 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_state=31 and it618_rwpmid='.$it618_waimai_rwpeiman['id']);
			$sum2=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei','it618_state=31 and it618_rwpmid='.$it618_waimai_rwpeiman['id']);
			$count3 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_state=4 and it618_rwpmid='.$it618_waimai_rwpeiman['id']);
			$sum3=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei','it618_state=4 and it618_rwpmid='.$it618_waimai_rwpeiman['id']);
	
			$sumstr=str_replace("{count1}",$count1,$sumstr);
			$sumstr=str_replace("{sum1}",$sum1,$sumstr);
			$sumstr=str_replace("{count2}",$count2,$sumstr);
			$sumstr=str_replace("{sum2}",$sum2,$sumstr);
			$sumstr=str_replace("{count3}",$count3,$sumstr);
			$sumstr=str_replace("{sum3}",$sum3,$sumstr);
			
			$pjcount1 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj=1 and it618_rwpmid='.$it618_waimai_rwpeiman['id']);
			$pjcount2 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj=2 and it618_rwpmid='.$it618_waimai_rwpeiman['id']);
			$pjcount3 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj=3 and it618_rwpmid='.$it618_waimai_rwpeiman['id']);
			$allpjcount=$pjcount1+$pjcount2+$pjcount3;
			if($allpjcount==0){
				$pjtmp1=0;$pjtmp2=0;$pjtmp3=0;
			}else{
				$pjtmp1=$pjcount1/$allpjcount*100;
				$pjtmp2=$pjcount2/$allpjcount*100;
				$pjtmp3=$pjcount3/$allpjcount*100;
			}
			
			$sumstr=str_replace("{pj1}",round($pjtmp1,2),$sumstr);
			$sumstr=str_replace("{pj2}",round($pjtmp2,2),$sumstr);
			$sumstr=str_replace("{pj3}",round($pjtmp3,2),$sumstr);
			$sumstr=str_replace("{pjcount}",$allpjcount,$sumstr);
			
			$it618_waimai_rwpmtcbl=C::t('#it618_waimai#it618_waimai_rwpmtcbl')->fetch_by_pj($pjtmp1);
			$sumstr=str_replace("{jdcount}",$it618_waimai_rwpmtcbl['it618_jdcount'],$sumstr);
			$sumstr=str_replace("{tcbl}",$it618_waimai_rwpmtcbl['it618_tcbl'],$sumstr);
		}
		
		if($it618_waimai_rwpeiman['it618_state']==0)$it618_state='<font color=red>'.$it618_waimai_lang['s515'].'</font>';
		if($it618_waimai_rwpeiman['it618_state']==1)$it618_state='<font color=blue>'.$it618_waimai_lang['s516'].'</font>';
		if($it618_waimai_rwpeiman['it618_state']==2)$it618_state='<font color=green>'.$it618_waimai_lang['s520'].'</font>';
		if($it618_waimai_rwpeiman['it618_clockstate']==1)$it618_state.='<br><font color=red>'.$it618_waimai_lang['s519'].'</font>';
		
		$it618_liyou=str_replace("'","\"",$it618_waimai_rwpeiman['it618_liyou']);
		$it618_liyou=str_replace(array("\r\n", "\r", "\n"),"",$it618_liyou);
		
		$peimanstr=$it618_waimai_lang['s522'];
		$peimanstr=str_replace("{name}",$it618_waimai_rwpeiman['it618_name'],$peimanstr);
		$peimanstr=str_replace("{tel}",$it618_waimai_rwpeiman['it618_tel'],$peimanstr);
		$peimanstr=str_replace("{wx}",$it618_waimai_rwpeiman['it618_wx'],$peimanstr);
		if($it618_waimai_rwpeiman['it618_qq']!=''){
		$qqstr=' <a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$it618_waimai_rwpeiman['it618_qq'].'&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:'.$it618_waimai_rwpeiman['it618_qq'].':52" align="absmiddle"/></a>';	
	}
		$peimanstr=str_replace("{qq}",$qqstr,$peimanstr);
		$peimanstr=str_replace("{addr}",$it618_waimai_rwpeiman['it618_addr'],$peimanstr);
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_waimai_rwpeiman[id].'" name="delete[]" value="'.$it618_waimai_rwpeiman[id].'" '.$disabled.'><input type="hidden" name="id['.$it618_waimai_rwpeiman[id].']" value="'.$it618_waimai_rwpeiman[id].'"><label for="chk_del'.$it618_waimai_rwpeiman[id].'">'.$it618_waimai_rwpeiman['id'].'</label>',
			'<a href="home.php?mod=space&uid='.$it618_waimai_rwpeiman['it618_uid'].'" target="_blank">'.$username.'(<b>'.$it618_waimai_rwpeiman['it618_uid'].'</b>)</a>',
			'<font color="green"><b>'.$creditnum.'</b></font>',
			$peimanstr.' <a href="javascript:" onclick="alert(\''.$it618_liyou.'\n'.date('Y-m-d H:i:s', $it618_waimai_rwpeiman['it618_rztime']).'\')">'.$it618_waimai_lang['s1615'].'</a>',
			$sumstr,
			$it618_state,
		));
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_waimai_lang['s1095'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_waimai_lang['s1083'].'" onclick="return confirm(\''.$it618_waimai_lang['s1084'].'\')" /> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_waimai_lang['s1085'].'" onclick="return confirm(\''.$it618_waimai_lang['s1086'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_waimai_lang['s1087'].'" onclick="return confirm(\''.$it618_waimai_lang['s1088'].'\')"/> <input type="submit" class="btn" name="it618submit_clock" value="'.$it618_waimai_lang['s1091'].'" onclick="return confirm(\''.$it618_waimai_lang['s1092'].'\')"/> <input type="submit" class="btn" name="it618submit_unclock" value="'.$it618_waimai_lang['s1093'].'" onclick="return confirm(\''.$it618_waimai_lang['s1094'].'\')"/><br>'.$it618_waimai_lang['s1089'].' <font color=red>'.$it618_waimai_lang['s1090'].'</font> &nbsp;<input type=hidden value=1 name=page /></div></td></tr>';

	if(count($reabc)!=12)return;
showtablefooter();
?>