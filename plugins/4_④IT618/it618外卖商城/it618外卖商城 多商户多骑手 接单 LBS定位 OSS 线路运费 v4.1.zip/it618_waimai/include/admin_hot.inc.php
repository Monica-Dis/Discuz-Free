<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(C::t('#it618_waimai#it618_waimai_set')->count_by_setname('zjsaleshop')==0){
	C::t('#it618_waimai#it618_waimai_set')->insert(array(
		'setname' => 'zjsaleshop',
		'setvalue' => '15,8,1'
	), true);
	C::t('#it618_waimai#it618_waimai_set')->insert(array(
		'setname' => 'weeksaleshop',
		'setvalue' => '15,8,2'
	), true);
	C::t('#it618_waimai#it618_waimai_set')->insert(array(
		'setname' => 'hotshop',
		'setvalue' => '15,8,3'
	), true);
}

if(submitcheck('it618submit')){
	$hot1=getids($_GET['hot1'],'SELECT * FROM '.DB::table('it618_waimai_waimai_class1').' WHERE id=');
	$hot2=getids($_GET['hot2'],'SELECT * FROM '.DB::table('it618_waimai_waimai_class1').' WHERE id=');
	$hot3=getids($_GET['hot3'],'SELECT * FROM '.DB::table('it618_waimai_waimai').' WHERE id=');
	
	if(C::t('#it618_waimai#it618_waimai_set')->count_by_setname($setname)==0){
		C::t('#it618_waimai#it618_waimai_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $hot1.'@@@'.$hot2.'@@@'.$hot3
		), true);
	}else{
		$it618_waimai_set=C::t('#it618_waimai#it618_waimai_set')->fetch_by_setname($setname);
		C::t('#it618_waimai#it618_waimai_set')->update($it618_waimai_set['id'],array(
			'setvalue' => $hot1.'@@@'.$hot2.'@@@'.$hot3
		));
	}
	
	$it618_waimai_set=C::t('#it618_waimai#it618_waimai_set')->fetch_by_setname('zjsaleshop');
	C::t('#it618_waimai#it618_waimai_set')->update($it618_waimai_set['id'],array(
		'setvalue' => $_GET['zjsaleshop']
	));
	
	$it618_waimai_set=C::t('#it618_waimai#it618_waimai_set')->fetch_by_setname('monthsaleshop');
	C::t('#it618_waimai#it618_waimai_set')->update($it618_waimai_set['id'],array(
		'setvalue' => $_GET['monthsaleshop']
	));
	
	$it618_waimai_set=C::t('#it618_waimai#it618_waimai_set')->fetch_by_setname('hotshop');
	C::t('#it618_waimai#it618_waimai_set')->update($it618_waimai_set['id'],array(
		'setvalue' => $_GET['hotshop']
	));

	cpmsg($it618_waimai_lang['s823'], "action=plugins&identifier=$identifier&cp=admin_hot&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

function getids($ids,$sql){
	$tmpids=',';
	$tmpidsarr=explode(',',$ids);
	for($i=0;$i<count($tmpidsarr);$i++){
		$id=intval($tmpidsarr[$i]);
		if($id>0){
			if(DB::result_first($sql.$id)>0){
				$tmpids.=','.$id;
			}
		}
	}
	if($tmpids==','){
		$tmpids='';
	}else{
		$tmpids=str_replace(',,','',$tmpids);
	}
	
	return $tmpids;
}

$it618_waimai_set=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname($setname);
$value=explode('@@@',$it618_waimai_set);

$zjsaleshop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('zjsaleshop');
$weeksaleshop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('weeksaleshop');
$hotshop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('hotshop');

$tmpidsarr=explode(',',$value[0]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);

	if($i==count($tmpidsarr)-1)$tmpstr='';else $tmpstr=' , ';
	$valuename[0].=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_waimai_waimai_class1')." WHERE id=".$id).$tmpstr;
}

$tmpidsarr=explode(',',$value[1]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);

	if($i==count($tmpidsarr)-1)$tmpstr='';else $tmpstr=' , ';
	$valuename[1].=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_waimai_waimai_class1')." WHERE id=".$id).$tmpstr;
}

$tmpidsarr=explode(',',$value[2]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	
	$valuename[2].='<option>'.DB::result_first("SELECT it618_name FROM ".DB::table('it618_waimai_waimai')." WHERE id=".$id).'</option>';
}

showformheader("plugins&identifier=$identifier&cp=admin_hot&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1].'<span style="font-weight:normal;color:red;margin-left:440px">'.$it618_waimai_lang['s824'].'</span>','it618_waimai_set');

echo '
<tr><td>'.$it618_waimai_lang['s825'].'</td><td><input type="text" name="hot1" style="width:800px;" value="'.$value[0].'"></td></tr>
<tr><td></td><td style="color:green">'.$valuename[0].'</td></tr>
<tr><td>'.$it618_waimai_lang['s826'].'</td><td><input type="text" name="hot2" style="width:800px;" value="'.$value[1].'"></td></tr>
<tr><td></td><td style="color:green">'.$valuename[1].'</td></tr>
<tr><td>'.$it618_waimai_lang['s827'].'</td><td><input type="text" name="hot3" style="width:800px;" value="'.$value[2].'"></td></tr>
<tr><td></td><td><select style="color:green;">'.$valuename[2].'</select></td></tr>
<tr><td>'.$it618_waimai_lang['t345'].'</td><td>'.$it618_waimai_lang['s1468'].'<input type="text" name="zjsaleshop" style="width:80px;" value="'.$zjsaleshop.'">  '.$it618_waimai_lang['s1469'].'<font color=red>15</font>,<font color=blue>8</font>,1</td></tr>
<tr><td>'.$it618_waimai_lang['t347'].'</td><td>'.$it618_waimai_lang['s1468'].'<input type="text" name="weeksaleshop" style="width:80px;" value="'.$weeksaleshop.'"> '.$it618_waimai_lang['s1469'].'<font color=red>15</font>,<font color=blue>8</font>,2</td></tr>
<tr><td>'.$it618_waimai_lang['t548'].'</td><td>'.$it618_waimai_lang['s1468'].'<input type="text" name="hotshop" style="width:80px;" value="'.$hotshop.'"> '.$it618_waimai_lang['s1469'].'<font color=red>15</font>,<font color=blue>8</font>,3<br><br><font color=red>'.$it618_waimai_lang['s1391'].'</font></td></tr>
';

showsubmit('it618submit', $it618_waimai_lang['s828']);
if(count($reabc)!=12)return;
showtablefooter();

?>