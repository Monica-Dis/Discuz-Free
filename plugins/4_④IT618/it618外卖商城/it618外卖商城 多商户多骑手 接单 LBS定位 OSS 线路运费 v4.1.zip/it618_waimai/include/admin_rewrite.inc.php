<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/rewrite.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_waimai/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$waimai_home=\''.'waimai'."';\n";
		$fileData .= '$waimai_list=\''.'waimai_list'."';\n";
		$fileData .= '$waimai_search=\''.'waimai_search'."';\n";
		$fileData .= '$wshop_home=\''.'wshop'."';\n";
		$fileData .= '$wshop_sc=\''.'wshop_sc'."';\n";
		$fileData .= '$waimai_wap=\''.'waimai_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$waimai_home1=\''.$urltype."';\n";
		$fileData .= '$waimai_list1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$waimai_search1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$wshop_home1=\'-{sid}'.$urltype."';\n";
		$fileData .= '$wshop_sc1=\''.$urltype."';\n";
		$fileData .= '$waimai_wap1=\'-{pagetype}-{sid}-{oid}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_waimai/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$waimai_home=\''.str_replace("-","",$_GET['waimai_home'])."';\n";
		$fileData .= '$waimai_list=\''.str_replace("-","",$_GET['waimai_list'])."';\n";
		$fileData .= '$waimai_search=\''.str_replace("-","",$_GET['waimai_search'])."';\n";
		$fileData .= '$wshop_home=\''.str_replace("-","",$_GET['wshop_home'])."';\n";
		$fileData .= '$wshop_sc=\''.str_replace("-","",$_GET['wshop_sc'])."';\n";
		$fileData .= '$waimai_wap=\''.str_replace("-","",$_GET['waimai_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$waimai_home1=\''.$urltype."';\n";
		$fileData .= '$waimai_list1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$waimai_search1=\'-{cid1}-{cid2}-{aid1}-{aid2}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$wshop_home1=\'-{sid}'.$urltype."';\n";
		$fileData .= '$wshop_sc1=\''.$urltype."';\n";
		$fileData .= '$waimai_wap1=\'-{pagetype}-{sid}-{oid}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_waimai_lang['s599'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_waimai_lang['s600'].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_waimai_lang['s601'].'</td></tr>
<tr><td colspan="3">'.$it618_waimai_lang['s602'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_waimai_lang['s603'].'</th><th>'.$it618_waimai_lang['s604'].'</th><th>'.$it618_waimai_lang['s605'].'</th></tr>
<tr class="hover">
<td>'.$it618_waimai_lang['s606'].'</td><td></td><td class="longtxt"><input name="waimai_home" value="'.$waimai_home.'"/>'.$waimai_home.$waimai_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_waimai_lang['s607'].'</td><td>{cid1}, {cid2}, {aid1}, {aid2}, {order}, {page}</td><td class="longtxt"><input name="waimai_list" value="'.$waimai_list.'" />'.$waimai_list.$waimai_list1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_waimai_lang['s608'].'</td><td>{cid1}, {cid2}, {aid1}, {aid2}, {order}, {page}</td><td class="longtxt"><input name="waimai_search" value="'.$waimai_search.'" />'.$waimai_search.$waimai_search1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_waimai_lang['s619'].'</td><td>{sid}</td><td class="longtxt"><input name="wshop_home" value="'.$wshop_home.'"/>'.$wshop_home.$wshop_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_waimai_lang['s620'].'</td><td></td><td class="longtxt"><input name="wshop_sc" value="'.$wshop_sc.'"/>'.$wshop_sc.$wshop_sc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_waimai_lang['s561'].'</td><td>{pagetype}, {sid}, {oid}, {cid}, {page}</td><td class="longtxt"><input name="waimai_wap" value="'.$waimai_wap.'"/>'.$waimai_wap.$waimai_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_waimai_lang['s621']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_waimai_lang['s622'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_home.$urltype.'$ $1/plugin.php?id=it618_waimai:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:list&class1=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:list&class1=$2&class2=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:list&class1=$2&class2=$3&area1=$4&area2=$5&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:list&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_search.$urltype.'$ $1/plugin.php?id=it618_waimai:search&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:search&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$wshop_home.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:shop&sid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$wshop_sc.$urltype.'$ $1/plugin.php?id=it618_waimai:sc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_wap.$urltype.'$ $1/plugin.php?id=it618_waimai:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:wap&pagetype=$2&sid=$3&oid=$4&cid=$5&page=$6&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$waimai_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:wap&pagetype=$2&sid=$3&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_waimai_lang['s623'].'</h1>
<pre class="colorbox">
'.$it618_waimai_lang['s624'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_home.$urltype.'$ plugin.php?id=it618_waimai:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_list.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_waimai:list&class1=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_waimai:list&class1=$1&class2=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_waimai:list&class1=$1&class2=$2&area1=$3&area2=$4&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_waimai:list&class1=$1&class2=$2&area1=$3&area2=$4&order=$5&page=$6&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_search.$urltype.'$ plugin.php?id=it618_waimai:search&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_waimai:search&class1=$1&class2=$2&area1=$3&area2=$4&order=$5&page=$6&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$wshop_home.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_waimai:shop&sid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$wshop_sc.$urltype.'$ plugin.php?id=it618_waimai:sc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_wap.$urltype.'$ plugin.php?id=it618_waimai:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_waimai:wap&pagetype=$1&sid=$2&oid=$3&cid=$4&page=$5&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$waimai_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_waimai:wap&pagetype=$1&sid=$2&%1</font>

</pre>

<h1>'.$it618_waimai_lang['s625'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$waimai_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:index&$3
RewriteRule ^(.*)/'.$waimai_list.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:list&class1=$2&$4
RewriteRule ^(.*)/'.$waimai_list.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:list&class1=$2&class2=$3&$5
RewriteRule ^(.*)/'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:list&class1=$2&class2=$3&area1=$4&area2=$5&$7
RewriteRule ^(.*)/'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:list&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$9
RewriteRule ^(.*)/'.$waimai_search.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:search&$3
RewriteRule ^(.*)/'.$waimai_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:search&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$9
RewriteRule ^(.*)/'.$wshop_home.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:shop&sid=$2&$4
RewriteRule ^(.*)/'.$wshop_sc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:sc&$3
RewriteRule ^(.*)/'.$waimai_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:wap&$3
RewriteRule ^(.*)/'.$waimai_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:wap&pagetype=$2&sid=$3&oid=$4&cid=$5&page=$6&$8
RewriteRule ^(.*)/'.$waimai_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_waimai:wap&pagetype=$2&sid=$3&$5</font>

</pre>

<h1>'.$it618_waimai_lang['s626'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="waimai_home"&gt;
			&lt;match url="^(.*/)*'.$waimai_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="waimai_list1"&gt;
			&lt;match url="^(.*/)*'.$waimai_list.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:list&amp;amp;class1={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="waimai_list2"&gt;
			&lt;match url="^(.*/)*'.$waimai_list.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="waimai_list3"&gt;
			&lt;match url="^(.*/)*'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;area1={R:4}&amp;amp;area2={R:5}&amp;amp;{R:6}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="waimai_list4"&gt;
			&lt;match url="^(.*/)*'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;area1={R:4}&amp;amp;area2={R:5}&amp;amp;order={R:6}&amp;amp;page={R:7}&amp;amp;{R:8}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="waimai_search"&gt;
			&lt;match url="^(.*/)*'.$waimai_search.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:search&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="waimai_search1"&gt;
			&lt;match url="^(.*/)*'.$waimai_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:search&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;area1={R:4}&amp;amp;area2={R:5}&amp;amp;order={R:6}&amp;amp;page={R:7}&amp;amp;{R:8}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wshop_home"&gt;
			&lt;match url="^(.*/)*'.$wshop_home.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:shop&amp;amp;sid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wshop_sc"&gt;
			&lt;match url="^(.*/)*'.$wshop_sc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:sc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="waimai_wap"&gt;
			&lt;match url="^(.*/)*'.$waimai_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="waimai_wap1"&gt;
			&lt;match url="^(.*/)*'.$waimai_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:wap&amp;amp;pagetype={R:2}&amp;amp;sid={R:3}&amp;amp;oid={R:4}&amp;amp;cid={R:5}&amp;amp;{R:6}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="waimai_wap2"&gt;
			&lt;match url="^(.*/)*'.$waimai_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_waimai:wap&amp;amp;pagetype={R:2}&amp;amp;sid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$waimai_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:index&$2
endif
match URL into $ with ^(.*)/'.$waimai_list.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:list&class1=$2&$3
endif
match URL into $ with ^(.*)/'.$waimai_list.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:list&class1=$2&class2=$3&$4
endif
match URL into $ with ^(.*)/'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:list&class1=$2&class2=$3&area1=$4&area2=$5&$6
endif
match URL into $ with ^(.*)/'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:list&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$8
endif
match URL into $ with ^(.*)/'.$waimai_search.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:search&$2
endif
match URL into $ with ^(.*)/'.$waimai_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:search&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$8
endif
match URL into $ with ^(.*)/'.$wshop_home.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:shop&sid=$2&$3
endif
match URL into $ with ^(.*)/'.$wshop_sc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:sc&$2
endif
match URL into $ with ^(.*)/'.$waimai_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:wap&$2
endif
match URL into $ with ^(.*)/'.$waimai_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:wap&pagetype=$2&sid=$3&oid=$4&cid=$5&page=$6&$7
endif
match URL into $ with ^(.*)/'.$waimai_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_waimai:wap&pagetype=$2&sid=$3&$4
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$waimai_home.$urltype.'$ $1/plugin.php?id=it618_waimai:index&$2 last;
rewrite ^([^\.]*)/'.$waimai_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:list&class1=$2&$3 last;
rewrite ^([^\.]*)/'.$waimai_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:list&class1=$2&class2=$3&$4 last;
rewrite ^([^\.]*)/'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:list&class1=$2&class2=$3&area1=$4&area2=$5&$6 last;
rewrite ^([^\.]*)/'.$waimai_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:list&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$8 last;
rewrite ^([^\.]*)/'.$waimai_search.$urltype.'$ $1/plugin.php?id=it618_waimai:search&$2 last;
rewrite ^([^\.]*)/'.$waimai_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:search&class1=$2&class2=$3&area1=$4&area2=$5&order=$6&page=$7&$8 last;
rewrite ^([^\.]*)/'.$wshop_home.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:shop&sid=$2&$3 last;
rewrite ^([^\.]*)/'.$wshop_sc.$urltype.'$ $1/plugin.php?id=it618_waimai:sc&$2 last;
rewrite ^([^\.]*)/'.$waimai_wap.$urltype.'$ $1/plugin.php?id=it618_waimai:wap&$2 last;
rewrite ^([^\.]*)/'.$waimai_wap.'-(.+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:wap&pagetype=$2&sid=$3&oid=$4&cid=$5&page=$6&$7 last;
rewrite ^([^\.]*)/'.$waimai_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_waimai:wap&pagetype=$2&sid=$3&$4 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=15)return;
showtablefooter();

?>