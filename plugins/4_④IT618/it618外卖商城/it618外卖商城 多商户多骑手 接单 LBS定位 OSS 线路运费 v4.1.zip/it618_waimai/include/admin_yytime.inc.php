<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	
	if(C::t('#it618_waimai#it618_waimai_set')->count_by_setname('yytime_isok')==0){
		C::t('#it618_waimai#it618_waimai_set')->insert(array(
			'setname' => 'yytime_isok',
			'setvalue' => '1'
		), true);
		C::t('#it618_waimai#it618_waimai_set')->insert(array(
			'setname' => 'yytime_isokbz',
			'setvalue' => ''
		), true);
		C::t('#it618_waimai#it618_waimai_set')->insert(array(
			'setname' => 'yytime_isoktime',
			'setvalue' => ''
		), true);
	}
	
	$it618_waimai_set=C::t('#it618_waimai#it618_waimai_set')->fetch_by_setname('yytime_isok');
	C::t('#it618_waimai#it618_waimai_set')->update($it618_waimai_set['id'],array(
		'setvalue' => $_GET['yytime_isok']
	));
	
	$it618_waimai_set=C::t('#it618_waimai#it618_waimai_set')->fetch_by_setname('yytime_isokbz');
	C::t('#it618_waimai#it618_waimai_set')->update($it618_waimai_set['id'],array(
		'setvalue' => $_GET['yytime_isokbz']
	));
	
	$it618_waimai_set=C::t('#it618_waimai#it618_waimai_set')->fetch_by_setname('yytime_isoktime');
	C::t('#it618_waimai#it618_waimai_set')->update($it618_waimai_set['id'],array(
		'setvalue' => $_GET['yytime_isoktime']
	));

	cpmsg($it618_waimai_lang['s823'], "action=plugins&identifier=$identifier&cp=admin_yytime&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}


$yytime_isok=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isok');
if($yytime_isok==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";

$yytime_isokbz=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isokbz');
$yytime_isoktime=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('yytime_isoktime');


showformheader("plugins&identifier=$identifier&cp=admin_yytime&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1],'it618_waimai_set');

echo '
<tr><td colspan=2>'.it618_waimai_getlang('s699').'</td></tr>
<tr><td width=110>'.it618_waimai_getlang('s693').'</td><td><input type="checkbox" id="yytime_isok" name="yytime_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="yytime_isok">'.it618_waimai_getlang('s694').'</label></td></tr>
<tr><td>'.it618_waimai_getlang('s695').'</td><td><input type="text" class="txt" style="width:600px;margin-bottom:3px" name="yytime_isokbz" value="'.$yytime_isokbz.'"><font color=#999>'.it618_waimai_getlang('s696').'</font></td></tr>
<tr><td>'.it618_waimai_getlang('s697').'</td><td><input type="text" class="txt" style="width:300px;margin-bottom:3px;color:blue" name="yytime_isoktime" value="'.$yytime_isoktime.'"><font color=#999>'.it618_waimai_getlang('s698').'</font></td></tr>
';

showsubmit('it618submit', $it618_waimai_lang['s828']);
if(count($reabc)!=12)return;
showtablefooter();

?>