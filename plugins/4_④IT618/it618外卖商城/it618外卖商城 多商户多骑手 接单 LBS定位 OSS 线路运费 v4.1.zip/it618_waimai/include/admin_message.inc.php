<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/message.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/message.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_waimai/message.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$it618_tel=\''.trim($_GET['it618_tel'])."';\n";
		
		$fileData .= '$it618_password=\''.trim($_GET['it618_password'])."';\n";
		
		$fileData .= '$it618_smsbaosign=\''.trim($_GET['it618_smsbaosign'])."';\n";
		
		$fileData .= '$it618_isok=\''.trim($_GET['it618_isok'])."';\n";
		
		$fileData .= '$it618_type=\''.trim($_GET['it618_type'])."';\n";
		
		$fileData .= '$it618_sign=\''.trim($_GET['it618_sign'])."';\n";
		
		$fileData .= '$it618_testsendto=\''.trim($_GET['it618_testsendto'])."';\n";
		
		$fileData .= '$it618_testbody=\''.trim($_GET['it618_testbody'])."';\n";
		
		$fileData .= '$it618_tel_admin=\''.trim($_GET['it618_tel_admin'])."';\n";
		
		$fileData .= '$it618_uid_admin=\''.trim($_GET['it618_uid_admin'])."';\n";
		
		$fileData .= '$it618_isok_admin=\''.trim($_GET['it618_isok_admin'])."';\n";
		
		$fileData .= '$it618_body_rz_admin=\''.trim($_GET['it618_body_rz_admin'])."';\n";
		$fileData .= '$it618_body_rz_admin_tplid=\''.trim($_GET['it618_body_rz_admin_tplid'])."';\n";
		$fileData .= '$it618_body_rz_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_rz_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_rz_admin_tplid_wxsms=\''.trim($_GET['it618_body_rz_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_rz_admin_isok=\''.trim($_GET['it618_body_rz_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_sqpm_admin=\''.trim($_GET['it618_body_sqpm_admin'])."';\n";
		$fileData .= '$it618_body_sqpm_admin_tplid=\''.trim($_GET['it618_body_sqpm_admin_tplid'])."';\n";
		$fileData .= '$it618_body_sqpm_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_sqpm_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_sqpm_admin_tplid_wxsms=\''.trim($_GET['it618_body_sqpm_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_sqpm_admin_isok=\''.trim($_GET['it618_body_sqpm_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_tx_admin=\''.trim($_GET['it618_body_tx_admin'])."';\n";
		$fileData .= '$it618_body_tx_admin_tplid=\''.trim($_GET['it618_body_tx_admin_tplid'])."';\n";
		$fileData .= '$it618_body_tx_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_tx_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_tx_admin_tplid_wxsms=\''.trim($_GET['it618_body_tx_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_tx_admin_isok=\''.trim($_GET['it618_body_tx_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_sale_admin=\''.trim($_GET['it618_body_sale_admin'])."';\n";
		$fileData .= '$it618_body_sale_admin_tplid=\''.trim($_GET['it618_body_sale_admin_tplid'])."';\n";
		$fileData .= '$it618_body_sale_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_sale_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_sale_admin_tplid_wxsms=\''.trim($_GET['it618_body_sale_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_sale_admin_isok=\''.trim($_GET['it618_body_sale_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_salesqfahuo_admin=\''.trim($_GET['it618_body_salesqfahuo_admin'])."';\n";
		$fileData .= '$it618_body_salesqfahuo_admin_tplid=\''.trim($_GET['it618_body_salesqfahuo_admin_tplid'])."';\n";
		$fileData .= '$it618_body_salesqfahuo_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_salesqfahuo_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_salesqfahuo_admin_tplid_wxsms=\''.trim($_GET['it618_body_salesqfahuo_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_salesqfahuo_admin_isok=\''.trim($_GET['it618_body_salesqfahuo_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_saletuihuo_admin=\''.trim($_GET['it618_body_saletuihuo_admin'])."';\n";
		$fileData .= '$it618_body_saletuihuo_admin_tplid=\''.trim($_GET['it618_body_saletuihuo_admin_tplid'])."';\n";
		$fileData .= '$it618_body_saletuihuo_admin_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_saletuihuo_admin_wxsms']))."';\n";
		$fileData .= '$it618_body_saletuihuo_admin_tplid_wxsms=\''.trim($_GET['it618_body_saletuihuo_admin_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_saletuihuo_admin_isok=\''.trim($_GET['it618_body_saletuihuo_admin_isok'])."';\n";
		
		$fileData .= '$it618_body_tx_shop=\''.trim($_GET['it618_body_tx_shop'])."';\n";
		$fileData .= '$it618_body_tx_shop_tplid=\''.trim($_GET['it618_body_tx_shop_tplid'])."';\n";
		$fileData .= '$it618_body_tx_shop_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_tx_shop_wxsms']))."';\n";
		$fileData .= '$it618_body_tx_shop_tplid_wxsms=\''.trim($_GET['it618_body_tx_shop_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_tx_shop_isok=\''.trim($_GET['it618_body_tx_shop_isok'])."';\n";
		
		$fileData .= '$it618_body_sale_shop=\''.trim($_GET['it618_body_sale_shop'])."';\n";
		$fileData .= '$it618_body_sale_shop_tplid=\''.trim($_GET['it618_body_sale_shop_tplid'])."';\n";
		$fileData .= '$it618_body_sale_shop_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_sale_shop_wxsms']))."';\n";
		$fileData .= '$it618_body_sale_shop_tplid_wxsms=\''.trim($_GET['it618_body_sale_shop_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_sale_shop_isok=\''.trim($_GET['it618_body_sale_shop_isok'])."';\n";
		
		$fileData .= '$it618_body_salefahuo_shop=\''.trim($_GET['it618_body_salefahuo_shop'])."';\n";
		$fileData .= '$it618_body_salefahuo_shop_tplid=\''.trim($_GET['it618_body_salefahuo_shop_tplid'])."';\n";
		$fileData .= '$it618_body_salefahuo_shop_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_salefahuo_shop_wxsms']))."';\n";
		$fileData .= '$it618_body_salefahuo_shop_tplid_wxsms=\''.trim($_GET['it618_body_salefahuo_shop_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_salefahuo_shop_isok=\''.trim($_GET['it618_body_salefahuo_shop_isok'])."';\n";
		
		$fileData .= '$it618_body_saletuihuo_shop=\''.trim($_GET['it618_body_saletuihuo_shop'])."';\n";
		$fileData .= '$it618_body_saletuihuo_shop_tplid=\''.trim($_GET['it618_body_saletuihuo_shop_tplid'])."';\n";
		$fileData .= '$it618_body_saletuihuo_shop_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_saletuihuo_shop_wxsms']))."';\n";
		$fileData .= '$it618_body_saletuihuo_shop_tplid_wxsms=\''.trim($_GET['it618_body_saletuihuo_shop_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_saletuihuo_shop_isok=\''.trim($_GET['it618_body_saletuihuo_shop_isok'])."';\n";
		
		$fileData .= '$it618_body_sqpm_user=\''.trim($_GET['it618_body_sqpm_user'])."';\n";
		$fileData .= '$it618_body_sqpm_user_tplid=\''.trim($_GET['it618_body_sqpm_user_tplid'])."';\n";
		$fileData .= '$it618_body_sqpm_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_sqpm_user_wxsms']))."';\n";
		$fileData .= '$it618_body_sqpm_user_tplid_wxsms=\''.trim($_GET['it618_body_sqpm_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_sqpm_user_isok=\''.trim($_GET['it618_body_sqpm_user_isok'])."';\n";

		$fileData .= '$it618_body_sale_user=\''.trim($_GET['it618_body_sale_user'])."';\n";
		$fileData .= '$it618_body_sale_user_tplid=\''.trim($_GET['it618_body_sale_user_tplid'])."';\n";
		$fileData .= '$it618_body_sale_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_sale_user_wxsms']))."';\n";
		$fileData .= '$it618_body_sale_user_tplid_wxsms=\''.trim($_GET['it618_body_sale_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_sale_user_isok=\''.trim($_GET['it618_body_sale_user_isok'])."';\n";
		
		$fileData .= '$it618_body_salegetsale_user=\''.trim($_GET['it618_body_salegetsale_user'])."';\n";
		$fileData .= '$it618_body_salegetsale_user_tplid=\''.trim($_GET['it618_body_salegetsale_user_tplid'])."';\n";
		$fileData .= '$it618_body_salegetsale_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_salegetsale_user_wxsms']))."';\n";
		$fileData .= '$it618_body_salegetsale_user_tplid_wxsms=\''.trim($_GET['it618_body_salegetsale_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_salegetsale_user_isok=\''.trim($_GET['it618_body_salegetsale_user_isok'])."';\n";
		
		$fileData .= '$it618_body_salesqfahuo_user=\''.trim($_GET['it618_body_salesqfahuo_user'])."';\n";
		$fileData .= '$it618_body_salesqfahuo_user_tplid=\''.trim($_GET['it618_body_salesqfahuo_user_tplid'])."';\n";
		$fileData .= '$it618_body_salesqfahuo_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_salesqfahuo_user_wxsms']))."';\n";
		$fileData .= '$it618_body_salesqfahuo_user_tplid_wxsms=\''.trim($_GET['it618_body_salesqfahuo_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_salesqfahuo_user_isok=\''.trim($_GET['it618_body_salesqfahuo_user_isok'])."';\n";
		
		$fileData .= '$it618_body_salefahuo_user=\''.trim($_GET['it618_body_salefahuo_user'])."';\n";
		$fileData .= '$it618_body_salefahuo_user_tplid=\''.trim($_GET['it618_body_salefahuo_user_tplid'])."';\n";
		$fileData .= '$it618_body_salefahuo_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_salefahuo_user_wxsms']))."';\n";
		$fileData .= '$it618_body_salefahuo_user_tplid_wxsms=\''.trim($_GET['it618_body_salefahuo_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_salefahuo_user_isok=\''.trim($_GET['it618_body_salefahuo_user_isok'])."';\n";
		
		$fileData .= '$it618_body_salefahuo1_user=\''.trim($_GET['it618_body_salefahuo1_user'])."';\n";
		$fileData .= '$it618_body_salefahuo1_user_tplid=\''.trim($_GET['it618_body_salefahuo1_user_tplid'])."';\n";
		$fileData .= '$it618_body_salefahuo1_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_salefahuo1_user_wxsms']))."';\n";
		$fileData .= '$it618_body_salefahuo1_user_tplid_wxsms=\''.trim($_GET['it618_body_salefahuo1_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_salefahuo1_user_isok=\''.trim($_GET['it618_body_salefahuo1_user_isok'])."';\n";
		
		$fileData .= '$it618_body_salegetok_user=\''.trim($_GET['it618_body_salegetok_user'])."';\n";
		$fileData .= '$it618_body_salegetok_user_tplid=\''.trim($_GET['it618_body_salegetok_user_tplid'])."';\n";
		$fileData .= '$it618_body_salegetok_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_salegetok_user_wxsms']))."';\n";
		$fileData .= '$it618_body_salegetok_user_tplid_wxsms=\''.trim($_GET['it618_body_salegetok_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_salegetok_user_isok=\''.trim($_GET['it618_body_salegetok_user_isok'])."';\n";
		
		$fileData .= '$it618_body_saletuihuo_user=\''.trim($_GET['it618_body_saletuihuo_user'])."';\n";
		$fileData .= '$it618_body_saletuihuo_user_tplid=\''.trim($_GET['it618_body_saletuihuo_user_tplid'])."';\n";
		$fileData .= '$it618_body_saletuihuo_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_saletuihuo_user_wxsms']))."';\n";
		$fileData .= '$it618_body_saletuihuo_user_tplid_wxsms=\''.trim($_GET['it618_body_saletuihuo_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_saletuihuo_user_isok=\''.trim($_GET['it618_body_saletuihuo_user_isok'])."';\n";
		
		$fileData .= '$it618_body_saletuihuo1_user=\''.trim($_GET['it618_body_saletuihuo1_user'])."';\n";
		$fileData .= '$it618_body_saletuihuo1_user_tplid=\''.trim($_GET['it618_body_saletuihuo1_user_tplid'])."';\n";
		$fileData .= '$it618_body_saletuihuo1_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_saletuihuo1_user_wxsms']))."';\n";
		$fileData .= '$it618_body_saletuihuo1_user_tplid_wxsms=\''.trim($_GET['it618_body_saletuihuo1_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_saletuihuo1_user_isok=\''.trim($_GET['it618_body_saletuihuo1_user_isok'])."';\n";
		
		$fileData .= '$it618_body_saleok_user=\''.trim($_GET['it618_body_saleok_user'])."';\n";
		$fileData .= '$it618_body_saleok_user_tplid=\''.trim($_GET['it618_body_saleok_user_tplid'])."';\n";
		$fileData .= '$it618_body_saleok_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_saleok_user_wxsms']))."';\n";
		$fileData .= '$it618_body_saleok_user_tplid_wxsms=\''.trim($_GET['it618_body_saleok_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_saleok_user_isok=\''.trim($_GET['it618_body_saleok_user_isok'])."';\n";
		
		$fileData .= '$it618_body_tk_user=\''.trim($_GET['it618_body_tk_user'])."';\n";
		$fileData .= '$it618_body_tk_user_tplid=\''.trim($_GET['it618_body_tk_user_tplid'])."';\n";
		$fileData .= '$it618_body_tk_user_wxsms=\''.str_replace('${','{',trim($_GET['it618_body_tk_user_wxsms']))."';\n";
		$fileData .= '$it618_body_tk_user_tplid_wxsms=\''.trim($_GET['it618_body_tk_user_tplid_wxsms'])."';\n";
		$fileData .= '$it618_body_tk_user_isok=\''.trim($_GET['it618_body_tk_user_isok'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}
	
	if($_GET['it618_istest']==1&&$_GET['it618_type']=='smsbao'){
		require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/message.func.php';
		if(trim($_GET['it618_smsbaosign'])!='')$it618_smsbaosign=$it618_waimai_lang['s1797'].trim($_GET['it618_smsbaosign']).$it618_waimai_lang['s1798'];
		$tmpstr=sendSMS(trim($_GET['it618_tel']),trim($_GET['it618_password']),trim($_GET['it618_testsendto']),$it618_smsbaosign.trim($_GET['it618_testbody']));
		$tmpaboutstr='<br><br>'.$it618_waimai_lang['s1399'];
	}

	cpmsg($it618_waimai_lang['s1312'].'<br>'.$tmpstr.$tmpaboutstr, "action=plugins&identifier=$identifier&cp=admin_message&pmod=admin_set&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

echo '
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/js/jquery.js"></script>
';

showformheader("plugins&identifier=$identifier&cp=admin_message&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_waimai_message');

$it618_typestyle1='display:none';$it618_typestyle2='display:none';
if($it618_type=='')$it618_type='smsbao';
if($it618_type=='smsbao'){$it618_type1=' selected=selected';$it618_typestyle1='display:';}
if($it618_type=='alidayu'){$it618_type2=' selected=selected';$it618_typestyle2='display:';}
if($it618_type=='alisms'){$it618_type3=' selected=selected';$it618_typestyle2='display:';}

if($it618_isok==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
if($it618_isok_admin==1)$it618_isok_admin_checked='checked="checked"';else $it618_isok_admin_checked="";

if($it618_body_rz_admin_isok==1)$it618_body_rz_admin_isok_checked='checked="checked"';else $it618_body_rz_admin_isok_checked="";
if($it618_body_sqpm_admin_isok==1)$it618_body_sqpm_admin_isok_checked='checked="checked"';else $it618_body_sqpm_admin_isok_checked="";
if($it618_body_tx_admin_isok==1)$it618_body_tx_admin_isok_checked='checked="checked"';else $it618_body_tx_admin_isok_checked="";
if($it618_body_sale_admin_isok==1)$it618_body_sale_admin_isok_checked='checked="checked"';else $it618_body_sale_admin_isok_checked="";
if($it618_body_salesqfahuo_admin_isok==1)$it618_body_salesqfahuo_admin_isok_checked='checked="checked"';else $it618_body_salesqfahuo_admin_isok_checked="";
if($it618_body_saletuihuo_admin_isok==1)$it618_body_saletuihuo_admin_isok_checked='checked="checked"';else $it618_body_saletuihuo_admin_isok_checked="";

if($it618_body_tx_shop_isok==1)$it618_body_tx_shop_isok_checked='checked="checked"';else $it618_body_tx_shop_isok_checked="";
if($it618_body_sale_shop_isok==1)$it618_body_sale_shop_isok_checked='checked="checked"';else $it618_body_sale_shop_isok_checked="";
if($it618_body_salefahuo_shop_isok==1)$it618_body_salefahuo_shop_isok_checked='checked="checked"';else $it618_body_salefahuo_shop_isok_checked="";
if($it618_body_saletuihuo_shop_isok==1)$it618_body_saletuihuo_shop_isok_checked='checked="checked"';else $it618_body_saletuihuo_shop_isok_checked="";

if($it618_body_sqpm_user_isok==1)$it618_body_sqpm_user_isok_checked='checked="checked"';else $it618_body_sqpm_user_isok_checked="";
if($it618_body_sale_user_isok==1)$it618_body_sale_user_isok_checked='checked="checked"';else $it618_body_sale_user_isok_checked="";
if($it618_body_salegetsale_user_isok==1)$it618_body_salegetsale_user_isok_checked='checked="checked"';else $it618_body_salegetsale_user_isok_checked="";
if($it618_body_salesqfahuo_user_isok==1)$it618_body_salesqfahuo_user_isok_checked='checked="checked"';else $it618_body_salesqfahuo_user_isok_checked="";
if($it618_body_salefahuo_user_isok==1)$it618_body_salefahuo_user_isok_checked='checked="checked"';else $it618_body_salefahuo_user_isok_checked="";
if($it618_body_salefahuo1_user_isok==1)$it618_body_salefahuo1_user_isok_checked='checked="checked"';else $it618_body_salefahuo1_user_isok_checked="";
if($it618_body_salegetok_user_isok==1)$it618_body_salegetok_user_isok_checked='checked="checked"';else $it618_body_salegetok_user_isok_checked="";
if($it618_body_saletuihuo_user_isok==1)$it618_body_saletuihuo_user_isok_checked='checked="checked"';else $it618_body_saletuihuo_user_isok_checked="";
if($it618_body_saletuihuo1_user_isok==1)$it618_body_saletuihuo1_user_isok_checked='checked="checked"';else $it618_body_saletuihuo1_user_isok_checked="";
if($it618_body_saleok_user_isok==1)$it618_body_saleok_user_isok_checked='checked="checked"';else $it618_body_saleok_user_isok_checked="";
if($it618_body_tk_user_isok==1)$it618_body_tk_user_isok_checked='checked="checked"';else $it618_body_tk_user_isok_checked="";

$wxsmscss='display:none';
if(DB::result_first("select count(1) from ".DB::table('common_plugin')." where identifier='it618_members'")!=0){
	$it618_membersstr= '<tr name="tr_alidayu" style="background-color:#e8e8e8;'.$it618_typestyle2.'"><td>'.$it618_waimai_lang['s1573'].'</td><td><input type="text" class="txt" style="width:150px" name="it618_sign" value="'.$it618_sign.'"> '.$it618_waimai_lang['s1888'].'<input type="text" class="txt" style="width:30px;margin-right:3px" name="it618_length" value="'.$it618_length.'">'.$it618_waimai_lang['s1889'].'</td></tr>';
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if($it618_members['members_iswxsms']==1){
		$wxsmscss='';
		$adminuidstr=$it618_waimai_lang['s141'].'<input type="text" class="txt" style="width:300px" name="it618_uid_admin" value="'.$it618_uid_admin.'">';
	}
}else{
	$it618_membersstr= '<tr name="tr_alidayu" style="background-color:#e8e8e8;'.$it618_typestyle2.'"><td colspan=2>'.$it618_waimai_lang['s1575'].'</td></tr>';
}

echo '<style>table tr td{line-height:20px}</style>
<tr><td width=110>'.$it618_waimai_lang['s1314'].'</td><td><input type="checkbox" id="it618_isok" name="it618_isok" value="1" style="vertical-align:middle" '.$it618_isok_checked.'> <label for="it618_isok">'.$it618_waimai_lang['s1315'].'</label></td></tr>
<tr><td>'.$it618_waimai_lang['s1321'].'</td><td><input type="text" class="txt" style="width:115px" name="it618_tel_admin" value="'.$it618_tel_admin.'">'.$adminuidstr.'<input type="checkbox" id="it618_isok_admin" name="it618_isok_admin" value="1" style="vertical-align:middle" '.$it618_isok_admin_checked.'> <label for="it618_isok_admin">'.$it618_waimai_lang['s1322'].'</label></td></tr>
<tr><td width=110>'.$it618_waimai_lang['s1570'].'</td><td><select name="it618_type" onchange="gettype(this)"><option value="smsbao" '.$it618_type1.'>'.$it618_waimai_lang['s1571'].'</option><option value="alidayu" '.$it618_type2.'>'.$it618_waimai_lang['s1572'].'</option><option value="alisms" '.$it618_type3.'>'.$it618_waimai_lang['s1667'].'</option></select> '.$it618_waimai_lang['s1308'].'</td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td colspan=2>'.$it618_waimai_lang['s1313'].'</td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_waimai_lang['s1316'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_tel" value="'.$it618_tel.'"></td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_waimai_lang['s1317'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_password" value="'.$it618_password.'"></td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_waimai_lang['s1573'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_smsbaosign" value="'.$it618_smsbaosign.'"></td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_waimai_lang['s1318'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_testsendto" value="'.$it618_testsendto.'"> '.$it618_waimai_lang['s1319'].'</td></tr>
<tr name="tr_smsbao" style="background-color:#e8e8e8;'.$it618_typestyle1.'"><td>'.$it618_waimai_lang['s1320'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_testbody" value="'.$it618_testbody.'"></td></tr>

'.$it618_membersstr.'

<tr><td colspan=2><strong>'.$it618_waimai_lang['s1323'].'</strong> <font color=red>'.$it618_waimai_lang['s1324'].'</font></td></tr>';

$it618_bodyarr=array(
'rz_admin','sqpm_admin','tx_admin','sale_admin','salesqfahuo_admin','saletuihuo_admin',
'tx_shop','sale_shop','saletuihuo_shop',
'sqpm_user','sale_user','salegetsale_user','salesqfahuo_user','salefahuo_user','salefahuo1_user','salegetok_user','saletuihuo_user','saletuihuo1_user','saleok_user','tk_user'
);

$it618lang=explode(",",$it618_waimai_lang['s1900']);

for($i=0;$i<count($it618_bodyarr);$i++){
	$it618_body_name=$it618_bodyarr[$i];
	
	if($it618_body_name=='rz_admin'){$it618_body_title=$it618_waimai_lang['s1325'];$it618_body_about=$it618_waimai_lang['s1326'];}
	if($it618_body_name=='sqpm_admin'){$it618_body_title=$it618_waimai_lang['s1335'];$it618_body_about=$it618_waimai_lang['s1336'];}
	if($it618_body_name=='tx_admin'){$it618_body_title=$it618_waimai_lang['s1327'];$it618_body_about=$it618_waimai_lang['s1328'];}
	if($it618_body_name=='sale_admin'){$it618_body_title=$it618_waimai_lang['s1329'];$it618_body_about=$it618_waimai_lang['s1330'];}
	if($it618_body_name=='salesqfahuo_admin'){$it618_body_title=$it618_waimai_lang['s1331'];$it618_body_about=$it618_waimai_lang['s1332'];}
	if($it618_body_name=='saletuihuo_admin'){$it618_body_title=$it618_waimai_lang['s1333'];$it618_body_about=$it618_waimai_lang['s1334'];}
	
	if($it618_body_name=='tx_shop'){$it618_body_title=$it618_waimai_lang['s1339'];$it618_body_about=$it618_waimai_lang['s1340'];}
	if($it618_body_name=='sale_shop'){$it618_body_title=$it618_waimai_lang['s1341'];$it618_body_about=$it618_waimai_lang['s1342'];}
	if($it618_body_name=='salefahuo_shop'){$it618_body_title=$it618_waimai_lang['s1343'];$it618_body_about=$it618_waimai_lang['s1344'];}
	if($it618_body_name=='saletuihuo_shop'){$it618_body_title=$it618_waimai_lang['s1345'];$it618_body_about=$it618_waimai_lang['s1346'];}
	
	if($it618_body_name=='sqpm_user'){$it618_body_title=$it618_waimai_lang['s1337'];$it618_body_about=$it618_waimai_lang['s1338'];}
	if($it618_body_name=='sale_user'){$it618_body_title=$it618_waimai_lang['s1349'];$it618_body_about=$it618_waimai_lang['s1350'];}
	if($it618_body_name=='salegetsale_user'){$it618_body_title=$it618_waimai_lang['s1351'];$it618_body_about=$it618_waimai_lang['s1352'];}
	if($it618_body_name=='salesqfahuo_user'){$it618_body_title=$it618_waimai_lang['s1353'];$it618_body_about=$it618_waimai_lang['s1354'];}
	if($it618_body_name=='salefahuo_user'){$it618_body_title=$it618_waimai_lang['s1355'];$it618_body_about=$it618_waimai_lang['s1356'];}
	if($it618_body_name=='salefahuo1_user'){$it618_body_title=$it618_waimai_lang['s1357'];$it618_body_about=$it618_waimai_lang['s1358'];}
	if($it618_body_name=='salegetok_user'){$it618_body_title=$it618_waimai_lang['s1365'];$it618_body_about=$it618_waimai_lang['s1366'];}
	if($it618_body_name=='saletuihuo_user'){$it618_body_title=$it618_waimai_lang['s1359'];$it618_body_about=$it618_waimai_lang['s1360'];}
	if($it618_body_name=='saletuihuo1_user'){$it618_body_title=$it618_waimai_lang['s1361'];$it618_body_about=$it618_waimai_lang['s1362'];}
	if($it618_body_name=='saleok_user'){$it618_body_title=$it618_waimai_lang['s1367'];$it618_body_about=$it618_waimai_lang['s1368'];}
	if($it618_body_name=='tk_user'){$it618_body_title=$it618_waimai_lang['s1363'];$it618_body_about=$it618_waimai_lang['s1364'];}
	
	$tmpname='it618_body_'.$it618_body_name.'_isok_checked';
	$it618_body_isok_checked=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name;
	$it618_body=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name.'_tplid';
	$it618_body_tplid=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name.'_wxsms';
	$it618_body_wxsms=$$tmpname;
	
	$tmpname='it618_body_'.$it618_body_name.'_tplid_wxsms';
	$it618_body_tplid_wxsms=$$tmpname;
	
	echo '<tr><td colspan=2><input type="checkbox" id="it618_body_'.$it618_body_name.'_isok" name="it618_body_'.$it618_body_name.'_isok" value="1" style="vertical-align:middle" '.$it618_body_isok_checked.'><label for="it618_body_'.$it618_body_name.'_isok">'.$it618lang[0].' <span id="it618_body_'.$it618_body_name.'_title">'.$it618_body_title.'</span></label><br>'.$it618lang[1].'<input type="text" class="txt" style="width:670px" name="it618_body_'.$it618_body_name.'" value="'.$it618_body.'"><span name="tr_alidayu" style="'.$it618_typestyle2.'">'.$it618lang[2].'<input type="text" class="txt" style="width:130px" name="it618_body_'.$it618_body_name.'_tplid" value="'.$it618_body_tplid.'"></span>
	<span style="'.$wxsmscss.'">
	<br>'.$it618lang[3].'<input type="text" class="txt" style="width:420px;margin-top:3px" id="it618_body_'.$it618_body_name.'_wxsms" name="it618_body_'.$it618_body_name.'_wxsms" readonly="readonly" onclick="getwxsms(\''.$it618_body_name.'\')" value="'.$it618_body_wxsms.'">'.$it618lang[4].'<input type="text" class="txt" style="width:380px" name="it618_body_'.$it618_body_name.'_tplid_wxsms" value="'.$it618_body_tplid_wxsms.'">
	</span>
	<br><span id="it618_body_'.$it618_body_name.'_about">'.$it618_body_about.'</span>
	</td></tr>';
}

echo '<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_waimai_lang['s1387'].'" /><input type="checkbox" id="it618_istest" name="it618_istest" value="1" style="vertical-align:middle;'.$it618_typestyle1.'"><label for="it618_istest" name="tr_smsbao" style="'.$it618_typestyle1.'">'.$it618_waimai_lang['s1388'].'</label></div></td></tr>

<div id="tmpsmsbtn"></div>
<style>
.wxsmstable tr th{font-weight:bold}
.wxsmstable tr td{padding:1px;padding-top:3px;padding-bottom:3px}
.wxsmstable tr td .tmplabel{width:113px;line-height:22px;text-align:right;color:blue;padding-right:3px;margin-right:2px;background-color:#fff}
.wxsmstable tr td .tmpvalue{width:760px;line-height:22px;padding-left:3px;background-color:#fff}
.wxsmstable tr td .savebtn{background-color:#390;padding:8px 35px;padding-bottom:10px;color:#fff;border:none}
.wxsmstable tr td .savebtn:hover{background-color:#3a0;}
.wxsmstable tr td .savebtn1{background-color:#e3e3e3;padding:8px 35px;padding-bottom:10px;color:#666;border:none}
.wxsmstable tr td .savebtn1:hover{background-color:#e8e8e8;}
</style>
<script>
var dialog_wxsms,tmpname,tmptitle,tmpabout,tmpbody;

KindEditor.ready(function(K) {K(\'#tmpsmsbtn\').click(function() {
	dialog_wxsms = K.dialog({
		width : 915,
		title : tmptitle,
		body : \'<div style="padding:8px;background-color:#fcfcfc;width:910px"><table class="wxsmstable"><tr><th>'.$it618_waimai_lang['s395'].'</th><th>'.$it618_waimai_lang['s396'].'</th></tr>\'+tmpbody+\'<tr><td colspan=2>\'+tmpabout+\'</td></tr><tr><td colspan=2><font color=green>'.$it618_waimai_lang['s397'].'</font></td></tr><tr><td colspan=2 align="center" style="padding-top:10px;padding-bottom:10px"><a class="savebtn" href="javascript:" onclick="savewxsms()">'.$it618_waimai_lang['s399'].'</a> <a class="savebtn1" href="javascript:" onclick="savewxsms1()">'.$it618_waimai_lang['s398'].'</a></td></tr></table></div>\',
		closeBtn : {
			name : \''.it618_waimai_getlang('s1107').'\',
			click : function(e) {
				dialog_wxsms.remove();
			}
		}
	});
	
	}, "html");
});

function getwxsms(it618_body_name){
	tmpname=it618_body_name;
	tmptitle=document.getElementById("it618_body_"+it618_body_name+"_title").innerHTML;
	tmpabout=document.getElementById("it618_body_"+it618_body_name+"_about").innerHTML;
	
	var tmpbody1=document.getElementById("it618_body_"+it618_body_name+"_wxsms").value;
	
	tmpbody="";
	if(tmpbody1=="")tmpbody1="|";
	var tmpbodyarr1=tmpbody1.split("@");
	for(var i=tmpbodyarr1.length;i<9;i++){
		tmpbodyarr1[i]="|";
	}
	
	for(var i=0;i<9;i++){
		var tmpbodyarr2=tmpbodyarr1[i].split("|");
		tmpbody=tmpbody+\'<tr><td><input type="text" class="tmplabel" id="tmplabel\'+i+\'" value="\'+tmpbodyarr2[0]+\'">:</td><td><input type="text" class="tmpvalue" id="tmpvalue\'+i+\'" value="\'+tmpbodyarr2[1]+\'"></td></tr>\';
	}

	document.getElementById("tmpsmsbtn").click();
}

function savewxsms(){
	var wxsmsstr="";
	for(var i=0;i<9;i++){
		var tmplabel=document.getElementById("tmplabel"+i).value;
		if(tmplabel!=""){
			var tmpvalue=document.getElementById("tmpvalue"+i).value;
			if(tmpvalue!=""){
				wxsmsstr=wxsmsstr+tmplabel+"|"+tmpvalue+"@";
			}else{
				alert("'.$it618_waimai_lang['s400'].'");
				document.getElementById("tmpvalue"+i).focus();
				return;
			}
		}
	}
	if(wxsmsstr!=""){
		wxsmsstr=wxsmsstr+"@";
		wxsmsstr=wxsmsstr.replace("@@","");
		document.getElementById("it618_body_"+tmpname+"_wxsms").value=wxsmsstr; 
	}
	dialog_wxsms.remove();
}

function savewxsms1(){
	dialog_wxsms.remove();
}

function gettype(obj){
	var trobj=document.getElementsByName("tr_smsbao");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}
	
	var trobj=document.getElementsByName("tr_alidayu");
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="none";
	}
	
	var jktype=obj.value;
	if(jktype=="alisms")jktype="alidayu";
	
	var trobj=document.getElementsByName("tr_"+jktype);
	for(var i=0;i<trobj.length;i++){
		trobj[i].style.display="";
	}
	
	if(obj.value=="smsbao"){
		document.getElementById("it618_istest").style.display="";
	}else{
		document.getElementById("it618_istest").style.display="none";
	}
}
</script>
';

if(count($reabc)!=10)return;
showtablefooter();

?>