<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_waimai#it618_waimai_peiman')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_waimai#it618_waimai_peiman')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_uid' => trim($_GET['it618_uid'][$id]),
				'it618_tel' => trim($_GET['it618_tel'][$id]),
				'it618_bz' => trim($_GET['it618_bz'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_pmid_array = !empty($_GET['newit618_pmid']) ? $_GET['newit618_pmid'] : array();
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_tel_array = !empty($_GET['newit618_tel']) ? $_GET['newit618_tel'] : array();
	$newit618_bz_array = !empty($_GET['newit618_bz']) ? $_GET['newit618_bz'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = trim($newit618_name_array[$key]);
		
		if($newit618_name != '') {
			
			C::t('#it618_waimai#it618_waimai_peiman')->insert(array(
				'it618_pmid' => trim($newit618_pmid_array[$key]),
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_tel' => trim($newit618_tel_array[$key]),
				'it618_bz' => trim($newit618_bz_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_waimai_lang['s5'].$ok1.' '.$it618_waimai_lang['s6'].$ok2.' '.$it618_waimai_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_peiman&pmod=admin_peiman&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=12)return;

showformheader("plugins&identifier=$identifier&cp=admin_peiman&pmod=admin_peiman&operation=$operation&do=$do");
showtableheaders($it618_waimai_lang['s1633'],'it618_waimai_peiman');
	$count = C::t('#it618_waimai#it618_waimai_peiman')->count_by_search();
	
	echo '<tr><td colspan=15>'.$it618_waimai_lang['s1607'].$count.'<span style="float:right;color:red">'.$it618_waimai_lang['s1608'].'</span></td></tr>';
	showsubtitle(array('', $it618_waimai_lang['s1606'], $it618_waimai_lang['s1602'], $it618_waimai_lang['s195'], $it618_waimai_lang['s1603'],$it618_waimai_lang['s1604'],$it618_waimai_lang['s1605'],$it618_waimai_lang['s1609']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_peiman')." ORDER BY it618_order");
	while($it618_waimai_peiman = DB::fetch($query)) {
		$disabled='';
		$salecount=C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_pmid($it618_waimai_peiman['it618_pmid']);
		if($salecount>0)$disabled='disabled="disabled"';
		
		$username='';
		if($it618_waimai_peiman['it618_uid']>0)$username=it618_waimai_getusername($it618_waimai_peiman['it618_uid']);
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_waimai_peiman[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_waimai_peiman[id]]\" value=\"$it618_waimai_peiman[id]\">",
			$it618_waimai_peiman['it618_pmid'],
			"<input type=\"text\" class=\"txt\" style=\"width:90px\" name=\"it618_name[$it618_waimai_peiman[id]]\" value=\"$it618_waimai_peiman[it618_name]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:50px\" name=\"it618_uid[$it618_waimai_peiman[id]]\" value=\"$it618_waimai_peiman[it618_uid]\">".$username,
			"<input type=\"text\" class=\"txt\" style=\"width:130px\" name=\"it618_tel[$it618_waimai_peiman[id]]\" value=\"$it618_waimai_peiman[it618_tel]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:410px\" name=\"it618_bz[$it618_waimai_peiman[id]]\" value=\"$it618_waimai_peiman[it618_bz]\">",
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_waimai_peiman['id'].']" value="'.$it618_waimai_peiman['it618_order'].'">',
			$salecount
		));
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_name[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:80px\" name="newit618_pmid[]">'], [1,'<input type="text" class="txt" style=\"width:90px\" name="newit618_name[]">'], [1,''], [1,'<input type="text" class="txt" style=\"width:130px\" name="newit618_tel[]">'], [1,'<input type="text" class="txt" style=\"width:410px\" name="newit618_bz[]">'], [1,'<input type="text" class="txt" style=\"width:30px\" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=12)return;
showtablefooter();
?>