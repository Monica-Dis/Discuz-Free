<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$it618sql='it618_state=7';
$urlsql="&findshopid=".$_GET['findshopid']."&finduid=".$_GET['finduid']."&it618_time1=".$_GET['it618_time1']."&it618_time2=".$_GET['it618_time2'];

if(submitcheck('it618submit_tuikuan')){
	$ok=0;
	if($reabc[8]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_waimai_gwcsale_main = DB::fetch_first("SELECT * FROM ".DB::table('it618_waimai_gwcsale_main')." where id=".$delid);
		$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
		
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($delid,array(
			'it618_state' => 8
		));
			
		C::t('common_member_count')->increase($it618_waimai_gwcsale_main['it618_uid'], array(
			'extcredits'.$it618_waimai['waimai_credit'] => $it618_waimai_gwcsale_main['it618_score'])
		);
		
		C::t('common_member_count')->increase($it618_waimai_waimai['it618_uid'], array(
			'extcredits'.$it618_waimai['waimai_credit'] => $it618_waimai_gwcsale_main['it618_zsscore'])
		);
		
		it618_waimai_sendmessage('tk_user',$delid);

		$ok=$ok+1;
	}

	cpmsg($it618_waimai_lang['s910'].$ok, "action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=12)return;

showformheader("plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_waimai_lang['s911'],'it618_waimai_sum');
	showsubmit('it618sercsubmit', $it618_waimai_lang['s912'], '<script charset="utf-8" src="source/plugin/it618_waimai/js/Calendar.js"></script>'.$it618_waimai_lang['s913'].' <input name="findshopid" value="'.$_GET['findshopid'].'" class="txt" style="width:80px" /> '.$it618_waimai_lang['s914'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:80px" /> '.$it618_waimai_lang['s919'].' <input name="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input name="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/>');
	
	$count = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid($_GET['findshopid'],$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_score',$_GET['findshopid'],$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$sfmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_sfmoney',$_GET['findshopid'],$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_tuikuan&pmod=admin_tuikuan&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=15>'.$it618_waimai_lang['s935'].'<font color=red>'.$count.'</font> '.$it618_waimai_lang['s937'].'<font color=#390>'.$score.'</font> '.$it618_waimai_lang['s936'].'<font color=red>'.$sfmoney.'</font><span style="float:right;color:red">'.$it618_waimai_lang['s939'].'</span></td></tr>';
	
	showsubtitle(array($it618_waimai_lang['s940'], $it618_waimai_lang['s941'],$it618_waimai_lang['s942'],$it618_waimai_lang['s943'],$it618_waimai_lang['s944'],$it618_waimai_lang['s945'],$it618_waimai_lang['s931'],$it618_waimai_lang['s930'],$it618_waimai_lang['s946'],$it618_waimai_lang['s947']));
			
	foreach(C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_all_by_shopid(
		$_GET['findshopid'],$it618sql,'id desc',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_waimai_gwcsale_main) {
			
		$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);

		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_waimai_gwcsale_main[id].'" name="delete[]" value="'.$it618_waimai_gwcsale_main[id].'" '.$disabled.'><label for="chk_del'.$it618_waimai_gwcsale_main[id].'">'.$it618_waimai_gwcsale_main['id'].'</label>',
			$it618_waimai_waimai['it618_name'],
			$it618_waimai_gwcsale_main['it618_money'],
			$it618_waimai_gwcsale_main['it618_yunfei'],
			$it618_waimai_gwcsale_main['it618_scoremoney'],
			'<font color=#390>'.$it618_waimai_gwcsale_main['it618_score'].'</font>',
			'<font color=red>'.$it618_waimai_gwcsale_main['it618_sfmoney'].'</font>',
			'<font color=#390>'.$it618_waimai_gwcsale_main['it618_zsscore'].'</font>',
			'<a href="'.it618_waimai_rewriteurl($it618_waimai_gwcsale_main['it618_uid']).'" target="_blank">'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'</a>',
			date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time'])
		));
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_waimai_lang['s70'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_tuikuan" value="'.$it618_waimai_lang['s932'].'" onclick="return confirm(\''.$it618_waimai_lang['s933'].'\')"/>&nbsp;'.$it618_waimai_lang['s934'].'<input type=hidden value=1 name=page /></div></td></tr>';

	if(count($reabc)!=12)return;
showtablefooter();
?>