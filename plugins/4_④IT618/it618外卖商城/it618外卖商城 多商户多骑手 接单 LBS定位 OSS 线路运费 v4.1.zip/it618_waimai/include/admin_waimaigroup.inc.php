<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_type=$cp1-6;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='i')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_waimai#it618_waimai_waimaigroup')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_groupname'])) {
		foreach($_GET['it618_groupname'] as $id => $val) {
			
			C::t('#it618_waimai#it618_waimai_waimaigroup')->update($id,array(
				'it618_groupname' => trim($_GET['it618_groupname'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_goodscount' => $_GET['it618_goodscount'][$id],
				'it618_score' => $_GET['it618_score'][$id],
				'it618_order' => $_GET['it618_order'][$id],
			));
			
			$ok1=$ok1+1;
		}
	}

	$newit618_groupname_array = !empty($_GET['newit618_groupname']) ? $_GET['newit618_groupname'] : array();
	
	foreach($newit618_groupname_array as $key => $value) {
		$newit618_groupname = trim($newit618_groupname_array[$key]);
		
		if($newit618_groupname != '') {
			
			C::t('#it618_waimai#it618_waimai_waimaigroup')->insert(array(
				'it618_groupname' => trim($newit618_groupname_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_waimai_lang['s5'].$ok1.' '.$it618_waimai_lang['s6'].$ok2.' '.$it618_waimai_lang['s7'].$del, "action=plugins&identifier=$identifier&cp=admin_waimaigroup&pmod=admin_waimai&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=12)return;

showformheader("plugins&identifier=$identifier&cp=admin_waimaigroup&pmod=admin_waimai&operation=$operation&do=$do");
showtableheaders($it618_waimai_lang['s1620'],'it618_waimai_waimaigroup');
	$count = C::t('#it618_waimai#it618_waimai_waimaigroup')->count_by_search();
	
	echo '<tr><td colspan=10>'.$it618_waimai_lang['s1628'].$count.'<span style="float:right;color:red"></span></td></tr>';
	showsubtitle(array('', $it618_waimai_lang['s1622'], $it618_waimai_lang['s1621'], $it618_waimai_lang['s1623'],$it618_waimai_lang['s1749'],$it618_waimai_lang['s1626'],$it618_waimai_lang['s1627']));
	
	$n=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimaigroup')." ORDER BY it618_order");
	while($it618_waimai_waimaigroup = DB::fetch($query)) {
		
		$waimaicount=C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_power($it618_waimai_waimaigroup['id']);
		if($waimaicount>0)$disabled='disabled="disabled"';else $disabled='';
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_waimai_waimaigroup[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_waimai_waimaigroup[id]]\" value=\"$it618_waimai_waimaigroup[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:130px;color:green;font-weight:bold\" name=\"it618_groupname[$it618_waimai_waimaigroup[id]]\" value=\"$it618_waimai_waimaigroup[it618_groupname]\">",
			'<img src="'.$it618_waimai_waimaigroup['it618_img'].'" id="img'.$it618_waimai_waimaigroup['id'].'" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" style="width:50px" id="url'.$it618_waimai_waimaigroup['id'].'" name="it618_img['.$it618_waimai_waimaigroup['id'].']" readonly="readonly" value="'.$it618_waimai_waimaigroup['it618_img'].'" /> <input type="button" id="image'.$it618_waimai_waimaigroup['id'].'" value="'.$it618_waimai_lang['s1488'].'" />',
			$it618_waimai_lang['s1647'].'<input type="text" class="txt" style="width:60px;color:blue;font-weight:bold" name="it618_goodscount['.$it618_waimai_waimaigroup['id'].']" value="'.$it618_waimai_waimaigroup[it618_goodscount].'">',
			'<input class="txt" type="text" style="width:60px" name="it618_score['.$it618_waimai_waimaigroup['id'].']" value="'.$it618_waimai_waimaigroup['it618_score'].'">',
			'<input class="txt" type="text" style="width:20px" name="it618_order['.$it618_waimai_waimaigroup['id'].']" value="'.$it618_waimai_waimaigroup['it618_order'].'">',
			'<font color=red><b>'.$waimaicount.'</b></font>'
		));
		$editorjs.='K(\'#image'.$it618_waimai_waimaigroup['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_waimai_waimaigroup['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_waimai_waimaigroup['id'].'\').val(url);
								K(\'#img'.$it618_waimai_waimaigroup['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo '
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_waimai/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_waimai/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
			
	function setcheck(objname1,objname2,id){
		if(document.getElementById(objname1+id).checked){
			document.getElementById(objname2+id).style.display="";
		}else{
			document.getElementById(objname2+id).style.display="none";
		}
	}
</script>';
	$it618_waimai_lang184=$it618_waimai_lang['s1629'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_groupname[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:130px\" name="newit618_groupname[]">'], [1, '$it618_waimai_lang184'], [1,''], [1,''], [1,''], [1,''], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="8"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
    echo '<tr><td colspan=8>'.$it618_waimai_lang['s1636'].'</td></tr>';
	if(count($reabc)!=12)return;
showtablefooter();
?>