<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_header.func.php';

$tmpcount=C::t('#it618_waimai#it618_waimai_goods')->count_by_shopid($ShopId);
if($tmpcount>=$Shop_goodscount){
	it618_cpmsg($it618_waimai_lang['s1648'].$Shop_goodscount.$it618_waimai_lang['s1649'], '', 'error');
}

if(submitcheck('it618submit')){

	$pid=C::t('#it618_waimai#it618_waimai_goods')->insert(array(
		'it618_shopid' => $ShopId,
		'it618_class_id' => $_GET['it618_class_id'],
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
		'it618_message' => $_GET['it618_message']
	), true);
	
	$get_it618_picbig=$_GET['it618_picbig'];
	
	if($get_it618_picbig!=''){
		$smallpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/';
		if (!file_exists($smallpath)) {
			mkdir($smallpath);
		}

		$tmparr1=explode("://",$get_it618_picbig);
		if(count($tmparr1)>1){
			$it618_url=$get_it618_picbig;
		}else{
			$tmparr=explode("source",$get_it618_picbig);
			$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
		}
		
		$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_0.'.$file_ext;
		it618_waimai_imagetosmall($it618_url,$it618_smallurl,$file_ext,160,160,1);

	}

	it618_cpmsg(it618_waimai_getlang('s268'), "plugin.php?id=it618_waimai:sc_product_add$adminsid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_waimai:sc_product_add$adminsid");
showtableheaders(it618_waimai_getlang('s269'),'it618_waimai_goods');

$goodscontent=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('goodscontent');

foreach(C::t('#it618_waimai#it618_waimai_class')->fetch_all_by_shopid($ShopId) as $it618_tmp) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
	
if($tmp!=''){
	$isgoodsclass='if(document.getElementById("it618_class_id").value=="0"){
			alert("'.it618_waimai_getlang('s264').'");
			return false;
		}';
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai_class')." where it618_img='' ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	$classtmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

echo '
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_waimai/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_waimai/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_waimai/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_waimai/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=640'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_waimai/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	function checkvalue(){
		'.$isgoodsclass.'
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_waimai_getlang('s265').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_waimai_getlang('s266').'");
			return false;
		}
		'.$tmpjs.'
	}
	
	function delpic(i){
		document.getElementById("url1"+i).value="";
		document.getElementById("img1"+i).src="";
	}
</script>

';

if($tmp!=''){echo '
<tr><td>'.it618_waimai_getlang('s270').'</td><td><select id="it618_class_id" name="it618_class_id"><option value="0">'.it618_waimai_getlang('s271').'</option>'.$tmp.'</select></td></tr>';}

echo '
<tr><td width=80>'.it618_waimai_getlang('s272').'</td><td><input type="text" class="txt" style="width:600px;margin-right:0" id="it618_name" name="it618_name"></td></tr>
<tr><td colspan=2><font color=green><b>'.$it618_waimai_lang['s1656'].'</b></font></td></tr>
<tr><td>'.it618_waimai_getlang('s279').'</td><td><img id="img1" width="80" height="80" align="absmiddle"/> <input type="text" id="url1" style="width:300px" name="it618_picbig" readonly="readonly"/> <input type="button" id="image1" value="'.it618_waimai_getlang('s280').'" /></td></tr>
<tr><td>'.it618_waimai_getlang('s284').'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$goodscontent.'</textarea></td></tr>
'.$tmpstr.'
';

echo '<tr><td colspan=2><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_waimai_getlang('s120').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/sc_footer.func.php';
?>