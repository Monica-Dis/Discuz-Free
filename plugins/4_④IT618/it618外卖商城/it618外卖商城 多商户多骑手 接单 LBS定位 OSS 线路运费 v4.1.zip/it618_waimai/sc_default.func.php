<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$oss;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/waimai_default.func.php';

if($_G['uid']<=0){
	$homeurl=it618_waimai_getrewrite('waimai_home','','plugin.php?id=it618_waimai:index');
	dheader("location:$homeurl");
}else{
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/php/aliyunossconfig.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/php/aliyunossconfig.php';
		if($it618_isok==1){
			$oss='&oss';
		}
	}
	
	if(isset($_GET['adminsid'])){
		$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$adminsid='&adminsid='.$_GET['adminsid'];
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['adminsid']);
				
			$it618_state=$it618_waimai_waimai['it618_state'];
			if($it618_state==0){
				echo it618_waimai_getlang('s172');exit;
			}elseif($it618_state==1){
				echo it618_waimai_getlang('s173');exit;
			}else{
				$it618_htstate=$it618_waimai_waimai['it618_htstate'];
				if($it618_htstate==0){
					echo it618_waimai_getlang('s174');exit;
				}elseif($it618_htstate==2){
					echo it618_waimai_getlang('s175');exit;
				}else{
					$ShopId=$it618_waimai_waimai['id'];
					$ShopUid=$it618_waimai_waimai['it618_uid'];
					$ShopName=$it618_waimai_waimai['it618_name'];
					$ShopZSSCORE=$it618_waimai_waimai['it618_zsscore'];
					$ShopSCOREBL=$it618_waimai_waimai['it618_scorebl'];
					$ShopUPRICE=$it618_waimai_waimai['it618_uprice'];
					$Shop_power=$it618_waimai_waimai['it618_power'];
					$Shop_isok=$it618_waimai_waimai['it618_isok'];
					
					$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
					$ShopPower=$it618_waimai_waimaigroup['it618_groupname'];
					if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" align="absmiddle" style="margin-top:-1px"/>';
					
					$Shop_goodscount=$it618_waimai_waimaigroup['it618_goodscount'];
					
					$Shop_systemcount=$it618_waimai_waimai['it618_systemcount'];
				}
			}
		}else{
			echo it618_waimai_getlang('s1220');exit;	
		}
	}else{
		$username=C::t('#it618_waimai#it618_waimai_sale')->fetch_username_by_uid($_G['uid']);
		if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid'])>0){
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
				
			$it618_state=$it618_waimai_waimai['it618_state'];
			if($it618_state==0){
				echo it618_waimai_getlang('s172');exit;
			}elseif($it618_state==1){
				echo it618_waimai_getlang('s173');exit;
			}else{
				$it618_htstate=$it618_waimai_waimai['it618_htstate'];
				if($it618_htstate==0){
					echo it618_waimai_getlang('s174');exit;
				}elseif($it618_htstate==2){
					echo it618_waimai_getlang('s175');exit;
				}else{
					$ShopId=$it618_waimai_waimai['id'];
					$ShopUid=$it618_waimai_waimai['it618_uid'];
					$ShopName=$it618_waimai_waimai['it618_name'];
					$ShopZSSCORE=$it618_waimai_waimai['it618_zsscore'];
					$ShopSCOREBL=$it618_waimai_waimai['it618_scorebl'];
					$ShopUPRICE=$it618_waimai_waimai['it618_uprice'];
					$Shop_power=$it618_waimai_waimai['it618_power'];
					$Shop_isok=$it618_waimai_waimai['it618_isok'];
					
					$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
					$ShopPower=$it618_waimai_waimaigroup['it618_groupname'];
					if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" align="absmiddle" style="margin-top:-1px"/>';
					
					$Shop_goodscount=$it618_waimai_waimaigroup['it618_goodscount'];
					
					$Shop_systemcount=$it618_waimai_waimai['it618_systemcount'];
				}
			}
			
		}else{
			$tmparr=explode(":",$_GET['id']);
			$pagetype=$tmparr[1];
			echo it618_waimai_getlang('s176');exit;
		}
	}
}
//From: Dism_taobao-com
?>