<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/shop.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$uid = $_G['uid'];
$it618_pid=intval($_GET['it618_pid']);

if($_GET['ac']=="getmode"){
	$modeid=intval($_GET['modeid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/getmode.func.php';

	if($it618_waimai_diy=C::t('#it618_waimai#it618_waimai_diy')->fetch_by_id($modeid)){
		if($it618_waimai_diy['it618_isjs']==1){
			if((time()-$it618_waimai_diy["it618_time"])<(60*$it618_waimai_diy["it618_catchtime"])){
				exit;
			}else{
				C::t('#it618_waimai#it618_waimai_diy')->update_it618_time_by_id(time(),$it618_waimai_diy["id"]);
			}
			
			$tmpstr = it618_waimai_getmodecontent($it618_waimai_diy['it618_type'],$it618_waimai_diy['it618_modecode'],$it618_waimai_diy['it618_count']);
			$tmpstr=str_replace(array("\r\n", "\r", "\n"),"",$tmpstr);
			$tmpstr=str_replace("'",'"',$tmpstr);
			
			echo "document.write('".$tmpstr."')";
		}
	}
	exit;
}

if($_GET['ac']=="home_shop"){
	$home_shop=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname($_GET['ac1']);
	
	$tmparr=explode(",",$home_shop);
	if($_GET['wap']!=1){
		if(count($tmparr)>2){
			$goods_count=$tmparr[0];
		}else{
			$goods_count=15;
		}
	}else{
		if(count($tmparr)>2){
			$goods_count=$tmparr[1];
		}else{
			$goods_count=8;
		}
		
		$lbslat=$_GET['lbslat'];
		$lbslng=$_GET['lbslng'];
	}
	
	if($_GET['ac1']=='zjsaleshop'){	
		$it618_homeshops=DB::fetch_all("SELECT max(id) as maxid,it618_shopid FROM ".DB::table('it618_waimai_gwcsale_main')." where it618_state>0 GROUP BY it618_shopid ORDER BY maxid desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='weeksaleshop'){
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate-7, $toyear);
		$it618_homeshops = DB::fetch_all("SELECT it618_shopid,count(1) as salecount FROM ".DB::table('it618_waimai_gwcsale_main')." where it618_time>=$time GROUP BY it618_shopid ORDER BY salecount desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='monthsaleshop'){
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate-24*30, $toyear);
		$it618_homeshops = DB::fetch_all("SELECT it618_shopid,count(1) as salecount FROM ".DB::table('it618_waimai_gwcsale_main')." where it618_time>=$time GROUP BY it618_shopid ORDER BY salecount desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='hotshop'){
		$it618_homeshops = DB::fetch_all("SELECT id as it618_shopid FROM ".DB::table('it618_waimai_waimai')." where it618_state=2 and it618_htstate=1 ORDER BY it618_views desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='hot'){
		$hotclasswaimai=C::t('#it618_waimai#it618_waimai_set')->getsetvalue_by_setname('hotclasswaimai');
		$hotclasswaimai=explode('@@@',$hotclasswaimai);
		$tmpidsarr=explode(',',$hotclasswaimai[2]);
		
		$it618_homeshops = array();
		for($i=1;$i<=count($tmpidsarr);$i++){
			$id=intval($tmpidsarr[$i-1]);
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($id);
			if($it618_waimai_waimai['it618_state']==2&&$it618_waimai_waimai['it618_htstate']==1){
				$it618_waimai_waimai['it618_shopid']=$id;
				$it618_homeshops[] = $it618_waimai_waimai;
			}
		}
	}

	if($_GET['ac1']=='lbs'){
		$it618_homeshops = DB::fetch_all("SELECT id as it618_shopid FROM ".DB::table('it618_waimai_waimai')." where it618_state=2 and it618_htstate=1 and it618_lbslat>0 ORDER BY SQRT(($lbslng -it618_lbslng)*($lbslng -it618_lbslng)+($lbslat -it618_lbslat)*($lbslat -it618_lbslat)) limit 0,".$it618_waimai['waimai_lbscount']);
	}
	
	if($_GET['wap']!=1){
		$i=1;
		$home_shoptmp='';
		foreach($it618_homeshops as $it618_homeshop) {
					
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_homeshop['it618_shopid']);
			
			if(!($it618_waimai_waimai['it618_state']==2&&$it618_waimai_waimai['it618_htstate']==1))continue;
		
			if($i%5==1){$home_shoptmp.='<li>';$noml=' noml';}else{$noml='';}
			
			$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
			$ShopPowerIco='';
			if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" align="absmiddle" style="margin-top:1px;"/>';
			
			if($it618_waimai_waimai['it618_mappoint']!='')$mapstr=' <a href="javascript:"><img onclick="getwaimaimapbtn('.$it618_waimai_waimai['id'].')" src="source/plugin/it618_waimai/images/map.png"></a>';
			
			$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$it618_waimai_waimai['it618_levelsum']);
			
			$tmpurl=it618_waimai_getrewrite('shop_home',$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:shop&sid='.$it618_waimai_waimai['id']);
			$home_shoptmp.='<div class="small-goods small-goods1'.$noml.'">
								<a class="small-goods-img" href="'.$tmpurl.'" target="_blank">
									<img class="dynload lsSwitchload" src="'.$it618_waimai_waimai['it618_logo'].'" alt="'.$it618_waimai_waimai['it618_name'].'" width="198" height="128" />
								</a>
								<h3>
									<a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_waimai_waimai['it618_name'].'">'.$it618_waimai_waimai['it618_name'].' '.$ShopPowerIco.'</a>
								</h3>
								<div class="small-goods-info">
									<span title="'.$it618_waimai_waimai['it618_addr'].'">'.cutstr($it618_waimai_waimai['it618_addr'],26,'...').$mapstr.'</span><br>'.it618_waimai_getlang('s1300').':'.$it618_waimai_waimai['it618_views'].' '.it618_waimai_getlang('s1298').':'.$it618_waimai_waimai['it618_salecount'].' '.it618_waimai_getlang('s1301').':'.$it618_waimai_waimai['it618_pjcount'].' '.it618_waimai_getlang('s1302').':'.$it618_waimai_waimai['it618_haopjbl'].'%<br><span style="float:right"><a href="'.$tmpurl.'" target="_blank">'.$it618_waimai_lang['s1639'].'</a></span><img style="vertical-align:middle;margin-top:2px" src="'.$it618_waimai_level['it618_img'].'">
								</div>
							</div>';
			
			if($i%5==0)$home_shoptmp.='</li>';
			$i=$i+1;
		}
		if(($i-1)%5>0)$home_shoptmp.='</li>';
		
		$home_shoptmp='<div id="'.$_GET['ac1'].'" class="slider-warp lazy_start" options="'.$_GET['ac1'].'|left|0|5000|1000|1|1|0|1">
							<div class="slider-ulwarp">
								<ul class="slider-ul">'.$home_shoptmp.'</ul>	
							</div>
						</div>';
	}else{
		$width=intval($_GET['width']/3-4);
		$home_shoptmp='';
		foreach($it618_homeshops as $it618_homeshop) {
			
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_homeshop['it618_shopid']);
			
			if(!($it618_waimai_waimai['it618_state']==2&&$it618_waimai_waimai['it618_htstate']==1))continue;
			
			$yytimestr=it618_waimai_getyytime($it618_waimai_waimai);
			$yytimestrarr=explode("it618_split",$yytimestr);
			
			$yytimestr="";
			if($yytimestrarr[0]==2){
				$yytimestr='<font color=#39F style="font-size:10px">'.$yytimestrarr[1].'</font>';
			}
			if($yytimestrarr[0]>3){
				$yytimestr='<font color=red style="font-size:10px">'.$it618_waimai_lang['s692'].'</font>';
			}
			
			$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
			$ShopPowerIco='';
			if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" height="15" style="margin-top:-3px"/>';
			
			$tmpurl=it618_waimai_getrewrite('waimai_wap','shop@'.$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:wap&pagetype=shop&sid='.$it618_waimai_waimai['id']);
			
			$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$it618_waimai_waimai['it618_levelsum']);
			
			$lbsm='';
			if($lbslat>0&&$it618_waimai_waimai['it618_lbslat']>0){
				$lbsm=it618_waimai_getdistance($lbslng,$lbslat,$it618_waimai_waimai['it618_lbslng'],$it618_waimai_waimai['it618_lbslat']);
				if($lbsm<1000)$lbsm=intval($lbsm).'m';
				if($lbsm>=1000)$lbsm=round($lbsm/1000,1).'km';
			}
				
			if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
			
			$it618_moneybz='';
			if($it618_waimai_waimai['it618_moneybz']!=''){
				$it618_moneybz='<div class="tddes1"><span class="moneybz">'.it618_waimai_getlang('s369').'</span> '.$it618_waimai_waimai['it618_moneybz'].'</div>';
			}
			
			$it618_peitype='';
			if($it618_waimai_waimai['it618_peitype']==1){
				$it618_peitype='<p style="float:right;margin-top:-1px;padding:2px 3px;height:11px;border-radius: 4px 0px 4px 0px;font-size:10px;color:#000;background-color:#fed23d;">'.$it618_waimai['waimai_peititle'].'</p>';
			}
						
			if($_GET['ac1']=='hot'||$_GET['ac1']=='lbs'){
				$home_shoptmp.='<tr>
								  <td onclick="location.href=\''.$tmpurl.'\'"> 
									  <img class="tdimg" src="'.it618_waimai_getwapppic($it618_waimai_waimai['id'],$it618_waimai_waimai['it618_logo']).'"/>
									  <div class="tdname1">'.$it618_waimai_waimai['it618_name'].' '.$ShopPowerIco.'</div>
									  <div class="tdabout"><span style="float:right">'.$lbsm.'</span><img style="margin-top:-3px;" src="'.$it618_waimai_level['it618_img'].'"> '.$it618_waimai_lang['s690'].':'.$it618_waimai_waimai['it618_pmoney'].' '.$yytimestr.' '.it618_waimai_getlang('s1300').':'.$it618_waimai_waimai['it618_views'].'</div>
									  <div class="tdabout">'.$it618_peitype.it618_waimai_getlang('s1298').':'.$it618_waimai_waimai['it618_salecount'].' '.it618_waimai_getlang('s1301').':'.$it618_waimai_waimai['it618_pjcount'].' '.it618_waimai_getlang('s1302').':'.$it618_waimai_waimai['it618_haopjbl'].'%</div>
									  <div class="tddes1">'.it618_waimai_getlang('s719').':'.$it618_waimai_waimai['it618_addr'].'</div>
									  '.$it618_moneybz.'
								  </td>
								</tr>';
			}else{
				$home_shoptmp.='<td width="'.$width.'" onclick="location.href=\''.$tmpurl.'\'">
									<img width="'.$width.'" src="'.it618_waimai_getwapppic($it618_waimai_waimai['id'],$it618_waimai_waimai['it618_logo']).'"/>
									<div class="tdname">'.$it618_waimai_waimai['it618_name'].'</div>
									<div class="tddes">'.$lbsm.'</div>
								</td>';
			}
		}
	}
	
	if($_GET['ac1']=='hot'||$_GET['ac1']=='lbs'){
		echo $home_shoptmp;
	}else{
		if($_GET['wap']==1){
			echo '<tr>'.$home_shoptmp.'</tr>';
		}else{
			echo $home_shoptmp;
		}
	}
	exit;
}

if($_GET['ac']=="getsaleaudio"){
	if($it618_waimai_saleaudio=C::t('#it618_waimai#it618_waimai_saleaudio')->fetch_by_it618_shopid_clienid($_GET['shopid'],$_GET['clienid'])){

		if(isset($_GET['update']))$isupdate=1;
		
		if($it618_waimai_saleaudio['it618_state']==1){
			$isupdate=1;
			echo 'it618_splitok';
		}
		
		if($isupdate==1){
			C::t('#it618_waimai#it618_waimai_saleaudio')->update($it618_waimai_saleaudio['id'],array(
				'it618_state' => 0
			));
		}
	}else{
		C::t('#it618_waimai#it618_waimai_saleaudio')->insert(array(
			'it618_shopid' => $_GET['shopid'],
			'it618_clienid' => $_GET['clienid'],
			'it618_state' => 0
		), true);
	}
	
	exit;
}

if($_GET['formhash']!=FORMHASH)exit;

if($_GET['ac']=="it618_waimai_getmapapi"){
	dsetcookie('it618_waimai_getmapapi',$_GET['lbslat'].'it618_split'.$_GET['lbslng'].'it618_split'.it618_waimai_utftogbk($_GET['lbsaddr']),60*$it618_waimai['waimai_maptimecout']);
}

if($_GET['ac']=="payok"){
	if($_GET['ac1']=="pay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_waimai_gwcsale_main')." WHERE it618_state!=0 and id=".intval($_GET['saleid']));
	}
	if($salecount>0){
		echo 'it618_splitok';exit;
	}
}

if($_GET['ac']=="imgdelete"){
	if($uid<=0){
		echo '0';
	}else{
		$shopid=intval($_GET['shopid']);
		
		if($shopid==0){
			$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo '0';exit;
			}
		}else{
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($shopid);
			if($it618_waimai_waimai['it618_uid']!=$uid){
				echo '0';exit;
			}
		}
		
		if($shopid==0){
			$tmparr=explode('source/plugin/it618_waimai/kindeditor/attached/image/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/attached/image/'.$tmparr[1];
			}
			$tmparr=explode('source/plugin/it618_waimai/kindeditor/data/shop',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$tmparr[1];
			}
		}else{
			$tmparr=explode('source/plugin/it618_waimai/kindeditor/data/shop'.$shopid.'/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$shopid.'/'.$tmparr[1];
			}
		}
		
		if (file_exists($delpath)) {
			$result=unlink($delpath);
			if(it618_waimai_dirsize(dirname($delpath))==0){
				rmdir(dirname($delpath));
			}
			
			echo '1';
		}else{
			echo '0';
		}
	}
	exit;
}

if($_GET['ac']=="shoppj_get"){
	$page = max(1, intval($_GET['page']));
	
	$ppp = 15;
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	$count = C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_shopid_pj($_GET['pj'],$_GET['sid']);
	
	foreach(C::t('#it618_waimai#it618_waimai_sale')->fetch_all_by_it618_shopid_pj($_GET['pj'],$_GET['sid'],$startlimit,$ppp) as $it618_waimai_sale) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$username=it618_waimai_getusername($it618_waimai_sale['it618_uid']);
		
		if($it618_waimai_sale['it618_pj']==1)$it618_pj='<font color=red>'.$it618_waimai_lang['s1266'].'</font>';
		if($it618_waimai_sale['it618_pj']==2)$it618_pj='<font color=red>'.$it618_waimai_lang['s1267'].'</font>';
		if($it618_waimai_sale['it618_pj']==3)$it618_pj='<font color=red>'.$it618_waimai_lang['s1268'].'</font>';
		
		$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($it618_waimai_sale['it618_pid']);
		
		$gtypename='';
		if($it618_waimai_sale['it618_gtypeid']>0){
			$gtypename = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_it618_name_by_id($it618_waimai_sale['it618_gtypeid']);
			$gtypename = '<font color=#999>'.$gtypename.'</font> ';
		}
		
		$salecount=C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_it618_uid($it618_waimai_sale['it618_gwcid']);
		$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(1,$salecount);
		
		$pjlist_get.='<tr><td width=50><img src="'.it618_waimai_discuz_uc_avatar($it618_waimai_sale['it618_uid'],'small').'" class="pjuserimg" /></td><td>
		<div class="pjuser"><span class="pjtime">'.date('Y-m-d', $it618_waimai_sale['it618_pjtime']).'</span><span style="display:inline-block">'.$username.'</span> <img style="vertical-align:middle;display:inline-block" src="'.$it618_waimai_level['it618_img'].'"></div>
		<div class="pjpj"><img src="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" width="30" onclick="showgoods('.$it618_waimai_goods['id'].')"/><div>'.$it618_waimai_goods['it618_name'].'<br>'.$gtypename.$it618_pj.'</div></div>
		<div class="pjcontent">'.str_replace('[br]','<br>',dhtmlspecialchars($it618_waimai_sale['it618_content_pj'])).'</div>
		</td></tr>';
		
		$n=$n+1;
	}
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopI&it618_pid=".$_GET['it618_pid']."&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getpjlist(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	echo $pjlist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="goodspj_get"){
	$page = max(1, intval($_GET['page']));
	
	$ppp = 15;
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	$count = C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pid_pj($_GET['pj'],$_GET['it618_pid']);
	
	foreach(C::t('#it618_waimai#it618_waimai_sale')->fetch_all_by_it618_pid_pj($_GET['pj'],$_GET['it618_pid'],$startlimit,$ppp) as $it618_waimai_sale) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$username=it618_waimai_getusername($it618_waimai_sale['it618_uid']);
		
		if($it618_waimai_sale['it618_pj']==1)$it618_pj='<font color=red>'.$it618_waimai_lang['s1266'].'</font>';
		if($it618_waimai_sale['it618_pj']==2)$it618_pj='<font color=red>'.$it618_waimai_lang['s1267'].'</font>';
		if($it618_waimai_sale['it618_pj']==3)$it618_pj='<font color=red>'.$it618_waimai_lang['s1268'].'</font>';
		
		$gtypename='';
		if($it618_waimai_sale['it618_gtypeid']>0){
			$gtypename = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_it618_name_by_id($it618_waimai_sale['it618_gtypeid']);
			$gtypename = '<font color=#999>'.$gtypename.'</font> ';
		}
		
		$salecount=C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_it618_uid($it618_waimai_sale['it618_gwcid']);
		$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(1,$salecount);
		
		$pjlist_get.='<tr><td width=50><img src="'.it618_waimai_discuz_uc_avatar($it618_waimai_sale['it618_uid'],'small').'" class="pjuserimg" /></td><td>
		<div class="pjuser"><span class="pjtime">'.date('Y-m-d', $it618_waimai_sale['it618_pjtime']).'</span><span style="display:inline-block">'.$username.'</span> <img style="vertical-align:middle;display:inline-block" src="'.$it618_waimai_level['it618_img'].'"></div>
		<div class="pjpj">'.$gtypename.$it618_pj.'</div>
		<div class="pjcontent">'.str_replace('[br]','<br>',dhtmlspecialchars($it618_waimai_sale['it618_content_pj'])).'</div>
		</td></tr>';
		
		$n=$n+1;
	}
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopI&it618_pid=".$_GET['it618_pid']."&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getpjlist(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&it618_pid=".$_GET['it618_pid']."&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	echo $pjlist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="gwcpay_add"){
	if($uid<=0){
		echo it618_waimai_getlang('s484');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_waimai_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_waimai_delsalework();
			}
		}
		C::t('#it618_waimai#it618_waimai_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		
		$count=C::t('#it618_waimai#it618_waimai_gwc')->count_by_uid($uid);
		if($count==0){
			echo it618_waimai_getlang('s1757');it618_waimai_delsalework();exit;
		}
		
		$shopid=C::t('#it618_waimai#it618_waimai_gwc')->fetch_shopid_by_uid($uid);
		$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($shopid);
		
		$shopname=$it618_waimai_waimai['it618_name'];
		$shopnamestr=str_replace("shopname",$shopname,it618_waimai_getlang('s1753'));
		$it618_state=$it618_waimai_waimai['it618_state'];
		
		if($it618_state==0){
			echo str_replace(it618_waimai_getlang('s1752'),$shopnamestr,it618_waimai_getlang('s380'));it618_waimai_delsalework();exit;
		}elseif($it618_state==1){
			echo str_replace(it618_waimai_getlang('s1752'),$shopnamestr,it618_waimai_getlang('s380'));it618_waimai_delsalework();exit;
		}else{
			$it618_htstate=$it618_waimai_waimai['it618_htstate'];
			if($it618_htstate==0){
				echo str_replace(it618_waimai_getlang('s1752'),$shopnamestr,it618_waimai_getlang('s381'));it618_waimai_delsalework();exit;
			}elseif($it618_htstate==2){
				echo str_replace(it618_waimai_getlang('s1752'),$shopnamestr,it618_waimai_getlang('s382'));it618_waimai_delsalework();exit;
			}else{
				$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
			}
		}
		
		$yytimestr=it618_waimai_getyytime($it618_waimai_waimai);
		$yytimestrarr=explode("it618_split",$yytimestr);
		
		if($yytimestrarr[0]==2){
			echo $it618_waimai_lang['s94'].$yytimestrarr[1].$it618_waimai_lang['s97'];it618_waimai_delsalework();exit;
		}
		if($yytimestrarr[0]==31){
			echo $it618_waimai_lang['s95'].$yytimestrarr[1];it618_waimai_delsalework();exit;
		}
		if($yytimestrarr[0]==32){
			echo $it618_waimai_lang['s96'].$yytimestrarr[1];it618_waimai_delsalework();exit;
		}

		C::t('#it618_waimai#it618_waimai_gwcsale')->delete_by_uid($uid);
		$tmptime=$_G['timestamp'];
		foreach(C::t('#it618_waimai#it618_waimai_gwc')->fetch_all_by_uid($uid) as $it618_waimai_gwc) {
			if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[3]!='1')exit;
			
			$it618_gtypeid=intval($it618_waimai_gwc['it618_gtypeid']);
			$it618_count=intval($it618_waimai_gwc['it618_count']);
			
			if(!($it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($it618_waimai_gwc['it618_pid']))){
				echo 'it618_splitgidit618_split'.$it618_waimai_gwc['id'].'it618_split'.it618_waimai_getlang('s1754');it618_waimai_delsalework();exit;
			}else{
				if($it618_waimai_goods['it618_ison']!=1){
					echo 'it618_splitgidit618_split'.$it618_waimai_gwc['id'].'it618_split'.it618_waimai_getlang('s1754');it618_waimai_delsalework();exit;	
				}
			}
			
			if($it618_gtypeid>0){
				if($it618_waimai_goods_type=C::t('#it618_waimai#it618_waimai_goods_type')->fetch_by_idok($it618_gtypeid)){
					$goods_count=$it618_waimai_goods_type['it618_count'];
					$goods_price=$it618_waimai_goods_type['it618_uprice'];
					$goods_zsscore=$it618_waimai_goods_type['it618_zsscore'];
				}else{
					echo 'it618_splitgidit618_split'.$it618_waimai_gwc['id'].'it618_split'.it618_waimai_getlang('s1748');it618_waimai_delsalework();exit;
				}
			}else{
				$goods_count=$it618_waimai_goods['it618_count'];
				$goods_price=$it618_waimai_goods['it618_uprice'];
				$goods_zsscore=$it618_waimai_goods['it618_zsscore'];
			}
			
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($it618_count<=0){
				echo 'it618_splitgidit618_split'.$it618_waimai_gwc['id'].'it618_split'.it618_waimai_getlang('s485');it618_waimai_delsalework();exit;
			}

			$id = C::t('#it618_waimai#it618_waimai_gwcsale')->insert(array(
				'it618_shopid' => $shopid,
				'it618_uid' => $uid,
				'it618_pid' => $it618_waimai_gwc['it618_pid'],
				'it618_gtypeid' => $it618_gtypeid,
				'it618_zsscore' => $goods_zsscore,
				'it618_price' => $goods_price,
				'it618_count' => $it618_count
			), true);
			
			$allcount=$allcount+$it618_count;
			$allproductmoney=$allproductmoney+$goods_price*$it618_count;
			$allzsscore=$allzsscore+$goods_zsscore*$it618_count;
		}
		
		if($allzsscore>0){
			$creditnum=C::t('#it618_waimai#it618_waimai_sale')->fetch_extcredits_by_uid($it618_waimai['waimai_credit'],$it618_waimai_waimai['it618_uid']);
			if($creditnum=="")$creditnum=0;
		
			if($creditnum<=$it618_waimai_waimaigroup['it618_score']){
				echo str_replace("shopname",$shopname,it618_waimai_getlang('s1751'));it618_waimai_delsalework();exit;
			}
		}
		
		if($allproductmoney<$it618_waimai_waimai['it618_pmoney']){
			echo $it618_waimai_lang['t667'];it618_waimai_delsalework();exit;
		}
		
		$mjmoney=0;
		$it618_moneybz=$it618_waimai_waimai['it618_moneybz'];
		if($it618_moneybz!=''){
			$tmparr=explode(",",$it618_moneybz);
			for($i=0;$i<count($tmparr);$i++){
				$tmparr1=explode($it618_waimai_lang['s393'],$tmparr[$i]);
				$tmpmoney=str_replace($it618_waimai_lang['s392'],"",$tmparr1[0]);
				if($allproductmoney>=$tmpmoney){
					$moneyarr["i".$i]=$allproductmoney-$tmpmoney;
					$itmp="i".$i;
					$$itmp=$tmparr1[1];
				}
			}
			if(count($moneyarr)>0){
				asort($moneyarr);
				$okmoneyarr=array_keys($moneyarr);
				$okmoney=$okmoneyarr[0];
				
				$mjmoney=$_GET['mjmoney'];
				if($$okmoney!=$mjmoney){
					echo "it618_splitmjmoneyit618_split".$it618_waimai_lang['s394'];it618_waimai_delsalework();exit;
				}
			}
		}
		
		$lbslat=$_GET['it618_lbslat'];
		$lbslng=$_GET['it618_lbslng'];
		if($lbslat>0){
			$lbsdata=it618_waimai_getdistance_gd($lbslng,$lbslat,$it618_waimai_waimai['it618_lbslng'],$it618_waimai_waimai['it618_lbslat']);
	
			if($lbsdata['info']=='OK'){
				if($lbsdata['results'][0]['distance']>0){
					$lbsm=$lbsdata['results'][0]['distance'];
					
					$lbsmtmp=round($lbsm/1000,1);
					if($lbsmtmp<=$it618_waimai_waimai['it618_first']){
						$yunfei=$it618_waimai_waimai['it618_yunfei1'];
					}else{
						$tmpm=$lbsmtmp-$it618_waimai_waimai['it618_first'];
						$tmpm1=intval($tmpm);
						if($tmpm1<$tmpm)$tmpm1=$tmpm1+1;
						$yunfei=$it618_waimai_waimai['it618_yunfei1']+$tmpm1*$it618_waimai_waimai['it618_yunfei2'];
					}
				}else{
					$tmparr=explode("|",$it618_waimai_lang['s367']);
					echo it618_waimai_utftogbk($lbsdata['results'][0]['info']).'  '.it618_waimai_utftogbk($tmparr[$lbsdata['results'][0]['code']]);it618_waimai_delsalework();exit;
				}
			}else{
				echo $it618_waimai_lang['s1234'].it618_waimai_utftogbk($lbsdata['info']);it618_waimai_delsalework();exit;
			}
		}else{
			echo $it618_waimai_lang['s923'];it618_waimai_delsalework();exit;
		}
		
		$chkscore=intval($_GET['chkscore']);
		
		if($chkscore==1){
			$waimai_jfbl=$it618_waimai['waimai_jfbl'];
			
			$it618_scorebl=$it618_waimai_waimai['it618_scorebl'];
			
			$creditnum=C::t('#it618_waimai#it618_waimai_sale')->fetch_extcredits_by_uid($it618_waimai['waimai_credit'],$uid);
			
			$scoremoney1=round((($allproductmoney+$yunfei)*$it618_scorebl/100),2);
			$creditnum1=$scoremoney1*$waimai_jfbl;
			if($creditnum1>$creditnum){
				$scoremoney=round(($creditnum/$waimai_jfbl),2);
				$it618_score=$creditnum;
			}else{
				$scoremoney=$scoremoney1;
				$it618_score=intval($creditnum1);
			}
		}else{
			$scoremoney=0;
		}
		
		$sfmoney=$allproductmoney-$mjmoney+$yunfei-$scoremoney;
	
		if($sfmoney<=0){
			$ispayok=1;
		}else{
			$ispayok=0;
			if($_GET['paytype']==""){
				echo it618_waimai_getlang('s1793');it618_waimai_delsalework();exit;
			}
			
			if($_GET['paytype']=="wxpay"){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
				}
				if($wx_appid==""){
					echo it618_waimai_getlang('s1148');it618_waimai_delsalework();exit;
				}
			}
		}
		
		$tc=round((($allproductmoney-$mjmoney)*$it618_waimai_waimai['it618_tcbl']/100), 2);
		$ktx=round(($allproductmoney-$mjmoney-$tc), 2);
		
		$it618_isrwpmpower=0;
		if($it618_waimai_waimai['it618_peitype']==1&&$it618_waimai['waimai_pmmode']==2){
			$it618_isrwpmpower=1;
		}

		$id = C::t('#it618_waimai#it618_waimai_gwcsale_main')->insert(array(
			'it618_uid' => $uid,
			'it618_shopid' => $shopid,
			'it618_count' => $allcount,
			'it618_money' => $allproductmoney,
			'it618_mjmoney' => $mjmoney,
			'it618_yunfei' => $yunfei,
			'it618_score' => $it618_score,
			'it618_scoremoney' => $scoremoney,
			'it618_sfmoney' => $sfmoney,
			'it618_zsscore' => $allzsscore,
			'it618_lbslat' => $lbslat,
			'it618_lbslng' => $lbslng,
			'it618_lbsaddr' => it618_waimai_utftogbk($_GET['it618_lbsaddr']),
			'it618_addr' => it618_waimai_utftogbk($_GET['it618_addr']),
			'it618_name' => it618_waimai_utftogbk($_GET['it618_name']),
			'it618_tel' => it618_waimai_utftogbk($_GET['it618_tel']),
			'it618_bz' => it618_waimai_utftogbk($_GET['it618_bz']),
			'it618_tcbl' => $it618_waimai_waimai['it618_tcbl'],
			'it618_tc' => $tc,
			'it618_ktx' => $ktx,
			'it618_pmid' => '0',
			'it618_isrwpmpower' => $it618_isrwpmpower,
			'it618_state' => 0,
			'it618_time' => $tmptime
		), true);
		
		if($id>0){
			
			C::t('#it618_waimai#it618_waimai_gwcsale')->update_gwcid_by_uid($id,$uid);
			
			if($ispayok==1){
				
				C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($id,array(
					'it618_state' => 1
				));
				
				foreach(C::t('#it618_waimai#it618_waimai_gwcsale')->fetch_all_by_gwcid($id) as $it618_waimai_gwcsale) {
					
					C::t('#it618_waimai#it618_waimai_sale')->insert(array(
						'it618_gwcid' => $id,
						'it618_shopid' => $it618_waimai_gwcsale['it618_shopid'],
						'it618_uid' => $it618_waimai_gwcsale['it618_uid'],
						'it618_pid' => $it618_waimai_gwcsale['it618_pid'],
						'it618_gtypeid' => $it618_waimai_gwcsale['it618_gtypeid'],
						'it618_zsscore' => $it618_waimai_gwcsale['it618_zsscore'],
						'it618_price' => $it618_waimai_gwcsale['it618_price'],
						'it618_count' => $it618_waimai_gwcsale['it618_count']
					), true);
					
				}
				
				C::t('common_member_count')->increase($it618_waimai_waimai['it618_uid'], array(
					'extcredits'.$it618_waimai['waimai_credit'] => (0-$allzsscore))
				);
				
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$it618_waimai['waimai_credit'] => (0-$it618_score))
				);
				
				C::t('#it618_waimai#it618_waimai_gwcsale')->delete_by_gwcid($id);
				C::t('#it618_waimai#it618_waimai_gwc')->delete_by_uid($uid);
				
				it618_waimai_delsalework();

				it618_waimai_sendmessage('sale_user',$id);
				it618_waimai_sendmessage('sale_shop',$id);
				it618_waimai_sendmessage('sale_admin',$id);
				
				DB::query("update ".DB::table('it618_waimai_saleaudio')." set it618_state=1 WHERE it618_shopid=0 or it618_shopid=".$it618_waimai_waimai['id']);
				
				echo "it618_splitscoreokit618_split".$it618_waimai_lang['s1065'];exit;
			}
			
			$saletype='0701';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$body=str_replace("{saleid}",$saleid,$it618_waimai_lang['s1756']);
			$body=str_replace("{shopname}",$it618_waimai_waimai['it618_name'],$body);
			
			$total_fee=$sfmoney;
			
			if(waimai_is_mobile()){ 
				$wap=1;
			}else{
				$wap=0;
			}
			
			$url=$_G['siteurl'].it618_waimai_getrewrite('waimai_wap','uc@'.$_G['uid'],'plugin.php?id=it618_waimai:wap&pagetype=uc');
			
			if($it618_waimai['waimai_wxgzurl']!=""){
				$it618_members = $_G['cache']['plugin']['it618_members'];
				$appid=trim($it618_members['members_appid']);
				$appsecret=trim($it618_members['members_appsecret']);
	
				if($appid!=""){
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
		
					$openid=C::t('#it618_members#it618_members_wxuser')->fetch_openid_by_uid($uid);
					
					$wxsubscribe=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
				
					$tmparr=explode("@",$wxsubscribe);
					$wxok=$tmparr[0];
				}
				
				if($wxok!=1){
					$url=$it618_waimai['waimai_wxgzurl'];
				}
			}

			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];
	
			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => $total_fee,
				'it618_plugin' => 'it618_waimai',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
		
			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_waimai_delsalework();
		}else{
			echo it618_waimai_getlang('s490');it618_waimai_delsalework();exit;
		}
	}
	exit;
}

if($_GET['ac']=="collectlist_get"){
	$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	$lbslat=$_GET['lbslat'];
	$lbslng=$_GET['lbslng'];
	
	if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
	
	$count=C::t('#it618_waimai#it618_waimai_collect')->count_by_uid($uid);
	$funname='getmycollectlist';
	
	$n=0;
	foreach(C::t('#it618_waimai#it618_waimai_collect')->fetch_all_by_uid($uid,$startlimit,$ppp) as $it618_waimai_collect) {
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_collect['it618_shopid']);
		
		$yytimestr=it618_waimai_getyytime($it618_waimai_waimai);
		$yytimestrarr=explode("it618_split",$yytimestr);
		
		$yytimestr="";
		if($yytimestrarr[0]==2){
			$yytimestr='<font color=#39F style="font-size:10px">'.$yytimestrarr[1].'</font>';
		}
		if($yytimestrarr[0]>3){
			$yytimestr='<font color=red style="font-size:10px">'.$it618_waimai_lang['s692'].'</font>';
		}
		
		$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
		$ShopPowerIco='';
		if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" height="15" style="margin-top:-3px"/>';
		
		$tmpurl=it618_waimai_getrewrite('waimai_wap','shop@'.$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:wap&pagetype=shop&sid='.$it618_waimai_waimai['id']);
		
		$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$it618_waimai_waimai['it618_levelsum']);
		
		$lbsm='';
		if($lbslat>0&&$it618_waimai_waimai['it618_lbslat']>0){
			$lbsm=it618_waimai_getdistance($lbslng,$lbslat,$it618_waimai_waimai['it618_lbslng'],$it618_waimai_waimai['it618_lbslat']);
			if($lbsm<1000)$lbsm=intval($lbsm).'m';
			if($lbsm>=1000)$lbsm=round($lbsm/1000,1).'km';
		}
		
		$it618_moneybz='';
		if($it618_waimai_waimai['it618_moneybz']!=''){
			$it618_moneybz='<div class="tddes1"><span class="moneybz">'.it618_waimai_getlang('s369').'</span> '.$it618_waimai_waimai['it618_moneybz'].'</div>';
		}
		
		$collectlist_get.='<tr>
						<td>
							  <input style="position:absolute;top:88px;left:6px" class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_waimai_collect[id].'">
							  <label for="chk_del'.$n.'"><img class="tdimg" src="'.it618_waimai_getwapppic($it618_waimai_waimai['id'],$it618_waimai_waimai['it618_logo']).'"/></label>
							  <div class="tdname1" onclick="location.href=\''.$tmpurl.'\'">'.$it618_waimai_waimai['it618_name'].' '.$ShopPowerIco.'</div>
							  <div class="tdabout" onclick="location.href=\''.$tmpurl.'\'"><span style="float:right">'.$lbsm.'</span><img style="margin-top:-3px;" src="'.$it618_waimai_level['it618_img'].'"> '.$it618_waimai_lang['s690'].':'.$it618_waimai_waimai['it618_pmoney'].' '.$yytimestr.'</div>
							  <div class="tdabout" onclick="location.href=\''.$tmpurl.'\'">'.it618_waimai_getlang('s1300').':'.$it618_waimai_waimai['it618_views'].' '.it618_waimai_getlang('s1298').':'.$it618_waimai_waimai['it618_salecount'].' '.it618_waimai_getlang('s1301').':'.$it618_waimai_waimai['it618_pjcount'].' '.it618_waimai_getlang('s1302').':'.$it618_waimai_waimai['it618_haopjbl'].'%</div>
							  <div class="tddes1" onclick="location.href=\''.$tmpurl.'\'">'.it618_waimai_getlang('s719').':'.$it618_waimai_waimai['it618_addr'].'</div>
							  '.$it618_moneybz.'
						 </td>
					  </tr>';
		$n=$n+1;
	}
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	echo it618_waimai_getlang('s1740')."<font color=red>$count</font>it618_split".$collectlist_get."it618_split".$multipage.'<div style="float:left"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="check_all(this, \'chk_del\','.$n.')" /> <label for="chkallDx4b">'.$it618_waimai_lang['s70'].'</label> <input type="button" style="height:26px;background-color:#390;border:none;color:#fff;padding-left:10px;padding-right:10px" name="it618submit_del" value="'.$it618_waimai_lang['s1741'].'" onclick="if(confirm(\''.$it618_waimai_lang['s1742'].'\'))delcollect();" /></div>';
	exit;
}
if($_GET['ac']=="myright"){
	$it='ok';
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/ajax.inc.php';
		$result=unlink($ajaxpath);
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/lang.func.php';
		$result=unlink($ajaxpath);
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}

if($_GET['ac']=="mysalelist_get"){
	
	$ppp = 10;
	$funname='getmysalelist';
	
	$it618sql = "it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==41)$it618sql = "it618_state = 41";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
		if($_GET['state']==8)$it618sql = "it618_state = 8";
	}

	$count = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_all_by_shopid(0,$it618sql,'id desc',$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_waimai_gwcsale_main) {
	
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		if($it618_waimai_gwcsale_main['it618_state']==1){
			$it618_state='<font color=red>'.$it618_waimai_lang['s1190'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==2){
			$it618_state='<font color=red>'.$it618_waimai_lang['s1191'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_waimai_lang['s1192'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==4||$it618_waimai_gwcsale_main['it618_state']==41){
			$peiman='';
			if($it618_waimai_gwcsale_main['it618_pmid']!='0'){
				$it618_waimai_peiman=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_pmid($it618_waimai_gwcsale_main['it618_pmid']);
				$peiman=' '.$it618_waimai_gwcsale_main['it618_pmid'].'-'.$it618_waimai_peiman['it618_name'];
			}
			if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
				$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($it618_waimai_gwcsale_main['it618_rwpmid']);
				$peiman=' '.$it618_waimai_gwcsale_main['it618_rwpmid'].'-'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'-'.$it618_waimai_rwpeiman['it618_name'];
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==4){
			$it618_state='<font color=blue>'.$it618_waimai_lang['s1193'].'</font>';
			
			$it618_state.=$peiman;
			
			$it618_state.='<a href="javascript:" style="float:right;margin-left:6px" onclick="showsalelbs('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s372'].'</a>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==41){
			$it618_state='<font color=green>'.$it618_waimai_lang['s1198'].'</font>';
			
			$it618_state.=$peiman;
			
			$it618_state.='<a href="javascript:" style="float:right;margin-left:6px" onclick="sale_shouhuo('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1207'].'</a>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==5){
			$it618_state='<font color=green>'.$it618_waimai_lang['s1194'].'</font>';
			
			if($it618_waimai_gwcsale_main['it618_pj']>0){
				if($it618_waimai_gwcsale_main['it618_pj']==1)$it618_pj=$it618_waimai_lang['s362'];
				if($it618_waimai_gwcsale_main['it618_pj']==2)$it618_pj=$it618_waimai_lang['s363'];
				if($it618_waimai_gwcsale_main['it618_pj']==3)$it618_pj=$it618_waimai_lang['s364'];
				
				$it618_state.='<span style="float:right;color:red"><font color=#999>'.$it618_waimai_lang['s359'].': </font>'.$it618_pj.'</span>';
			}else{
				$it618_state.='<a href="javascript:" style="float:right;" onclick="sale_pmpj('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s355'].'</a>';
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==6){
			$it618_state='<font color=purple>'.$it618_waimai_lang['s1195'].'</font>';
			
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==1)$it618_statetmp=$it618_waimai_lang['s1190'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==2)$it618_statetmp=$it618_waimai_lang['s1191'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==3)$it618_statetmp=$it618_waimai_lang['s1192'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==4)$it618_statetmp=$it618_waimai_lang['s1193'];
			$it618_state.=' <font color=#999>'.$it618_waimai_lang['s1171'].$it618_statetmp.'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==7){
			$it618_state='<font color=purple>'.$it618_waimai_lang['s1196'].'</font>';
			
			$it618_state.=' <a href="javascript:" style="float:right" onclick="sale_jieshou('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1179'].'</a>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==8){
			$it618_state='<font color=#FF00FF>'.$it618_waimai_lang['s1197'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']<=4){
			$it618_state.='<a href="javascript:" style="float:right" onclick="sale_tuihuo('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1204'].'</a>';
		}
		
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/ajax.inc.php';
			$result=unlink($ajaxpath);
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/lang.func.php';
			$result=unlink($ajaxpath);
		}
		
		$pid=C::t('#it618_waimai#it618_waimai_sale')->fetch_pid_by_gwcid_goods($it618_waimai_gwcsale_main['id']);
		$it618_waimai_goods=C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);
		
		$it618_mjmoney="";
		if($it618_waimai_gwcsale_main['it618_mjmoney']>0){
			$it618_mjmoney="-".$it618_waimai_gwcsale_main['it618_mjmoney'];
		}
		
		$mysalelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
					<div class="dealcard" style="margin:0;padding:0;line-height:15px">
						<img class="lazy" data-original="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" style="float:left;margin-right:3px" width="63" height="63"/>
						<div class="dealcard-waimai single-line"><a href="javascript:" style="float:right" onclick="showsale('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1202'].'(<font color=red>'.$it618_waimai_gwcsale_main['it618_count'].'</font>)</a><font color=#999>'.$it618_waimai_lang['s1124'].':</font>'.$it618_waimai_gwcsale_main['id'].' <font color=#999>'.$it618_waimai_lang['s1127'].':</font>'.$it618_waimai_gwcsale_main['it618_money'].$it618_mjmoney.'</div>
						
						<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px"><font color=#999>'.$it618_waimai_lang['s1128'].':</font>'.$it618_waimai_gwcsale_main['it618_yunfei'].' <font color=#999>'.$it618_waimai_lang['s1129'].':</font>'.$it618_waimai_gwcsale_main['it618_scoremoney'].' <font color=#999>'.$it618_waimai_lang['s1130'].':</font>'.$it618_waimai_gwcsale_main['it618_score'].'<br><font color=#999>'.$it618_waimai_lang['s1131'].':</font>'.$it618_waimai_gwcsale_main['it618_zsscore'].' <font color=#999>'.$it618_waimai_lang['s1122'].':'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time']).'</font><br>'.$it618_state.'</div>
					</div>
				</dd>';
		
		$n=$n+1;
	}

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$money=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_money',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$mjmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_mjmoney',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$zsscore=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_zsscore',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$yunfei=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$scoremoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_scoremoney',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_score',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$salesum= it618_waimai_getlang('s1136').''."<font color=red>$count</font> ".$it618_waimai_lang['s1137']."<font color=red>$money</font> ".$it618_waimai_lang['s1104']."<font color=#390>$mjmoney</font> ".$it618_waimai_lang['s1144']."<font color=red>$yunfei</font> ".$it618_waimai_lang['s1145']."<font color=#390>$scoremoney</font> ".$it618_waimai_lang['s1146']."<font color=#390>$score</font> ".it618_waimai_getlang('s1139')."<font color=#390>$zsscore</font><br><font color=#999 style='font-size:11px'>".$it618_waimai_lang['t525'].' <font color=red>'.$it618_waimai['waimai_autodatecount'].'</font> '.$it618_waimai_lang['t526'].'</font>';
	
	echo $salesum."it618_split".$mysalelist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="myrwpmlist_get"){
	
	$ppp = 10;
	$funname='getmysalelist';
	
	$rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($uid);
	if($rwpeimantmp['it618_state']!=2){
		echo 'it618_split'.it618_waimai_getlang('s375');exit;
	}
	
	$it618sql = "it618_rwpmid =".$rwpeimantmp['id']." and it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==41)$it618sql = "it618_state = 41";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
		if($_GET['state']==8)$it618sql = "it618_state = 8";
	}

	$count = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,$it618sql,'',0, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_all_by_shopid(0,$it618sql,'id desc',0, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_waimai_gwcsale_main) {
	
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		if($it618_waimai_gwcsale_main['it618_state']==1){
			$it618_state='<font color=red>'.$it618_waimai_lang['s1190'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==2){
			$it618_state='<font color=red>'.$it618_waimai_lang['s1191'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_waimai_lang['s1192'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==4){
			$it618_state='<font color=blue>'.$it618_waimai_lang['s1193'].'</font>';
			
			$it618_state.='<a href="javascript:" style="float:right;" onclick="sale_getok('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s321'].'</a>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==41){
			$it618_state='<font color=green>'.$it618_waimai_lang['s1198'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==5){
			$it618_state='<font color=green>'.$it618_waimai_lang['s1194'].'</font>';
			
			if($it618_waimai_gwcsale_main['it618_pj']>0){
				if($it618_waimai_gwcsale_main['it618_pj']==1)$it618_pj=$it618_waimai_lang['s362'];
				if($it618_waimai_gwcsale_main['it618_pj']==2)$it618_pj=$it618_waimai_lang['s363'];
				if($it618_waimai_gwcsale_main['it618_pj']==3)$it618_pj=$it618_waimai_lang['s364'];
				$pjstr='<font color=#999>'.$it618_waimai_lang['s359'].': </font>'.$it618_pj;
			}else{
				$pjstr='<font color=#999>'.$it618_waimai_lang['s1173'].'</font>';
			}
			
			$money=$it618_waimai_gwcsale_main['it618_yunfei'];
			$tcmoney=round(($money*$it618_waimai_gwcsale_main['it618_rwtcbl']/100),2);
			
			$it618_state.=' <font color=#999>'.$it618_waimai_lang['s322'].':</font>'.$tcmoney.'<span style="float:right;color:red">'.$pjstr.'</span>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==6){
			$it618_state='<font color=purple>'.$it618_waimai_lang['s1195'].'</font>';
			
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==1)$it618_statetmp=$it618_waimai_lang['s1190'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==2)$it618_statetmp=$it618_waimai_lang['s1191'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==3)$it618_statetmp=$it618_waimai_lang['s1192'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==4)$it618_statetmp=$it618_waimai_lang['s1193'];
			$it618_state.=' <font color=#999>'.$it618_waimai_lang['s1171'].$it618_statetmp.'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==7){
			$it618_state='<font color=purple>'.$it618_waimai_lang['s1196'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==8){
			$it618_state='<font color=#FF00FF>'.$it618_waimai_lang['s1197'].'</font>';
		}
		
		$pid=C::t('#it618_waimai#it618_waimai_sale')->fetch_pid_by_gwcid_goods($it618_waimai_gwcsale_main['id']);
		$it618_waimai_goods=C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);
		
		$it618_mjmoney="";
		if($it618_waimai_gwcsale_main['it618_mjmoney']>0){
			$it618_mjmoney="-".$it618_waimai_gwcsale_main['it618_mjmoney'];
		}
		
		$mysalelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
					<div class="dealcard" style="margin:0;padding:0;line-height:15px">
						<img class="lazy" data-original="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" style="float:left;margin-right:3px" width="63" height="63"/>
						<div class="dealcard-waimai single-line"><a href="javascript:" style="float:right" onclick="showsale('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1202'].'(<font color=red>'.$it618_waimai_gwcsale_main['it618_count'].'</font>)</a><font color=#999>'.$it618_waimai_lang['s1124'].':</font>'.$it618_waimai_gwcsale_main['id'].' <font color=#999>'.$it618_waimai_lang['s1127'].':</font>'.$it618_waimai_gwcsale_main['it618_money'].$it618_mjmoney.'</div>
						
						<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px"><font color=#999>'.$it618_waimai_lang['s1128'].':</font>'.$it618_waimai_gwcsale_main['it618_yunfei'].' <font color=#999>'.$it618_waimai_lang['s1129'].':</font>'.$it618_waimai_gwcsale_main['it618_scoremoney'].' <font color=#999>'.$it618_waimai_lang['s1130'].':</font>'.$it618_waimai_gwcsale_main['it618_score'].'<br><font color=#999>'.$it618_waimai_lang['s1131'].':</font>'.$it618_waimai_gwcsale_main['it618_zsscore'].' <font color=#999>'.$it618_waimai_lang['s1122'].':'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time']).'</font><br>'.$it618_state.'</div>
					</div>
				</dd>';
		
		$n=$n+1;
	}

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$money=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_money',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$mjmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_mjmoney',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$zsscore=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_zsscore',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$yunfei=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$scoremoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_scoremoney',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_score',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$salesum= it618_waimai_getlang('s1136').''."<font color=red>$count</font> ".$it618_waimai_lang['s1137']."<font color=red>$money</font> ".$it618_waimai_lang['s1104']."<font color=#390>$mjmoney</font> ".$it618_waimai_lang['s1144']."<font color=red>$yunfei</font> ".$it618_waimai_lang['s1145']."<font color=#390>$scoremoney</font> ".$it618_waimai_lang['s1146']."<font color=#390>$score</font> ".it618_waimai_getlang('s1139')."<font color=#390>$zsscore</font><br><font color=#999 style='font-size:11px'>".$it618_waimai_lang['t525'].' <font color=red>'.$it618_waimai['waimai_autodatecount'].'</font> '.$it618_waimai_lang['t526'].'</font>';
	
	echo $salesum."it618_split".$mysalelist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="mypmlist_get"){
	
	$ppp = 10;
	$funname='getmysalelist';
	
	if(!$peimantmp=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_uid($uid)){
		echo 'it618_split'.it618_waimai_getlang('s215');exit;
	}
	
	$it618sql = "it618_pmid ='".$peimantmp['it618_pmid']."' and it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==41)$it618sql = "it618_state = 41";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
		if($_GET['state']==8)$it618sql = "it618_state = 8";
	}

	$count = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,$it618sql,'',0, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_all_by_shopid(0,$it618sql,'id desc',0, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_waimai_gwcsale_main) {
	
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		if($it618_waimai_gwcsale_main['it618_state']==1){
			$it618_state='<font color=red>'.$it618_waimai_lang['s1190'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==2){
			$it618_state='<font color=red>'.$it618_waimai_lang['s1191'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_waimai_lang['s1192'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==4){
			$it618_state='<font color=blue>'.$it618_waimai_lang['s1193'].'</font>';
			
			$it618_state.='<a href="javascript:" style="float:right;" onclick="sale_getok('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s321'].'</a>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==41){
			$it618_state='<font color=green>'.$it618_waimai_lang['s1198'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==5){
			$it618_state='<font color=green>'.$it618_waimai_lang['s1194'].'</font>';
			
			if($it618_waimai_gwcsale_main['it618_pj']>0){
				if($it618_waimai_gwcsale_main['it618_pj']==1)$it618_pj=$it618_waimai_lang['s362'];
				if($it618_waimai_gwcsale_main['it618_pj']==2)$it618_pj=$it618_waimai_lang['s363'];
				if($it618_waimai_gwcsale_main['it618_pj']==3)$it618_pj=$it618_waimai_lang['s364'];
				$pjstr='<font color=#999>'.$it618_waimai_lang['s359'].': </font>'.$it618_pj;
			}else{
				$pjstr='<font color=#999>'.$it618_waimai_lang['s1173'].'</font>';
			}
			
			$money=$it618_waimai_gwcsale_main['it618_yunfei'];
			$tcmoney=round(($money*$it618_waimai_gwcsale_main['it618_rwtcbl']/100),2);
			
			$it618_state.=' <font color=#999>'.$it618_waimai_lang['s322'].':</font>'.$tcmoney.'<span style="float:right;color:red">'.$pjstr.'</span>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==6){
			$it618_state='<font color=purple>'.$it618_waimai_lang['s1195'].'</font>';
			
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==1)$it618_statetmp=$it618_waimai_lang['s1190'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==2)$it618_statetmp=$it618_waimai_lang['s1191'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==3)$it618_statetmp=$it618_waimai_lang['s1192'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==4)$it618_statetmp=$it618_waimai_lang['s1193'];
			$it618_state.=' <font color=#999>'.$it618_waimai_lang['s1171'].$it618_statetmp.'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==7){
			$it618_state='<font color=purple>'.$it618_waimai_lang['s1196'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==8){
			$it618_state='<font color=#FF00FF>'.$it618_waimai_lang['s1197'].'</font>';
		}
		
		$pid=C::t('#it618_waimai#it618_waimai_sale')->fetch_pid_by_gwcid_goods($it618_waimai_gwcsale_main['id']);
		$it618_waimai_goods=C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);
		
		$it618_mjmoney="";
		if($it618_waimai_gwcsale_main['it618_mjmoney']>0){
			$it618_mjmoney="-".$it618_waimai_gwcsale_main['it618_mjmoney'];
		}
		
		$mysalelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
					<div class="dealcard" style="margin:0;padding:0;line-height:15px">
						<img class="lazy" data-original="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" style="float:left;margin-right:3px" width="63" height="63"/>
						<div class="dealcard-waimai single-line"><a href="javascript:" style="float:right" onclick="showsale('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1202'].'(<font color=red>'.$it618_waimai_gwcsale_main['it618_count'].'</font>)</a><font color=#999>'.$it618_waimai_lang['s1124'].':</font>'.$it618_waimai_gwcsale_main['id'].' <font color=#999>'.$it618_waimai_lang['s1127'].':</font>'.$it618_waimai_gwcsale_main['it618_money'].$it618_mjmoney.'</div>
						
						<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px"><font color=#999>'.$it618_waimai_lang['s1128'].':</font>'.$it618_waimai_gwcsale_main['it618_yunfei'].' <font color=#999>'.$it618_waimai_lang['s1129'].':</font>'.$it618_waimai_gwcsale_main['it618_scoremoney'].' <font color=#999>'.$it618_waimai_lang['s1130'].':</font>'.$it618_waimai_gwcsale_main['it618_score'].'<br><font color=#999>'.$it618_waimai_lang['s1131'].':</font>'.$it618_waimai_gwcsale_main['it618_zsscore'].' <font color=#999>'.$it618_waimai_lang['s1122'].':'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time']).'</font><br>'.$it618_state.'</div>
					</div>
				</dd>';
		
		$n=$n+1;
	}

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$money=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_money',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$mjmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_mjmoney',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$zsscore=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_zsscore',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$yunfei=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$scoremoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_scoremoney',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$score=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_score',0,$it618sql,'',$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$salesum= it618_waimai_getlang('s1136').''."<font color=red>$count</font> ".$it618_waimai_lang['s1137']."<font color=red>$money</font> ".$it618_waimai_lang['s1104']."<font color=#390>$mjmoney</font> ".$it618_waimai_lang['s1144']."<font color=red>$yunfei</font> ".$it618_waimai_lang['s1145']."<font color=#390>$scoremoney</font> ".$it618_waimai_lang['s1146']."<font color=#390>$score</font> ".it618_waimai_getlang('s1139')."<font color=#390>$zsscore</font><br><font color=#999 style='font-size:11px'>".$it618_waimai_lang['t525'].' <font color=red>'.$it618_waimai['waimai_autodatecount'].'</font> '.$it618_waimai_lang['t526'].'</font>';
	
	echo $salesum."it618_split".$mysalelist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="rwlist_get"){
	
	$rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($uid);
	if($rwpeimantmp['it618_state']!=2){
		echo 'it618_split<div style="padding:10px;color:red">'.it618_waimai_getlang('s375').'</div>';exit;
	}
	
	$ppp = 10;
	$funname='getsalelist';
	
	$it618sql = "it618_state=3 and it618_isrwpmpower=1";

	$count = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,$it618sql,'id desc',0, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	foreach(C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_all_by_shopid(0,$it618sql,'id desc',0, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp) as $it618_waimai_gwcsale_main) {
		
		$pid=C::t('#it618_waimai#it618_waimai_sale')->fetch_pid_by_gwcid_goods($it618_waimai_gwcsale_main['id']);
		$it618_waimai_goods=C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);
		
		$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_goods['it618_shopid']);
		
		$mysalelist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
					<div class="dealcard" style="margin:0;padding:0;line-height:15px">
						<img class="lazy" data-original="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" style="float:left;margin-right:3px" width="63" height="63"/>
						<div class="dealcard-waimai single-line"><a href="javascript:" style="float:right" onclick="showsale('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1202'].'(<font color=red>'.$it618_waimai_gwcsale_main['it618_count'].'</font>)</a><font color=#999>'.$it618_waimai_lang['s1124'].':</font>'.$it618_waimai_gwcsale_main['id'].' <font color=#999>'.$it618_waimai_lang['s1128'].':</font><font color=red>'.$it618_waimai_gwcsale_main['it618_yunfei'].'</font></div>
						
						<div class="titlemysalebtn text-block" style="text-align:left;line-height:16px"> <font color=#999>'.$it618_waimai_lang['s672'].':</font>'.$it618_waimai_waimai['it618_name'].'<br><font color=#999>'.$it618_waimai_lang['s673'].':</font>'.$it618_waimai_gwcsale_main['it618_lbsaddr'].' '.$it618_waimai_gwcsale_main['it618_addr'].'<br><font color=#999>'.$it618_waimai_lang['s1122'].':'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time']).'</font><a href="javascript:" style="float:right" onclick="sale_getrw('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s674'].'</a></div>
					</div>
				</dd>';
		
		$n=$n+1;
	}

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	$yunfei=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei',0,$it618sql,'',0, $_GET['it618_time1'], $_GET['it618_time2']);
	
	$salesum= it618_waimai_getlang('s1102').''."<font color=red>$count</font> ".$it618_waimai_lang['s1103']."<font color=red>$yunfei</font><br><font color=#999 style='font-size:11px'>".$it618_waimai_lang['s1100'].' <font color=red>'.$it618_waimai['waimai_autodatecount'].'</font> '.$it618_waimai_lang['s1101'].'</font>';
	
	echo $salesum."it618_split".$mysalelist_get."it618_split".$multipage;
	exit;
}
if($_GET['ac']=="myright"){
	$it='ok';
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/ajax.inc.php';
		$result=unlink($ajaxpath);
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/lang.func.php';
		$result=unlink($ajaxpath);
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="waimailist_get"){
	$ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$lbslat=$_GET['it618_lbslat'];
	$lbslng=$_GET['it618_lbslng'];
	
	if($_GET['it618_order']==1)$orderby='it618_order desc';
	if($_GET['it618_order']==2)$orderby='it618_levelsum desc';
	if($_GET['it618_order']==3)$orderby='it618_salecount desc';
	if($_GET['it618_order']==4)$orderby='it618_views desc';
	if($_GET['it618_order']==5)$orderby='it618_pmoney';
	if($_GET['it618_order']==6)$orderby='it618_yunfei1+it618_yunfei2';
	if($_GET['it618_order']==7)$orderby='it618_time desc';
	if($_GET['it618_order']==8)$orderby="SQRT(($lbslng -it618_lbslng)*($lbslng -it618_lbslng)+($lbslat -it618_lbslat)*($lbslat -it618_lbslat))";

	$listcount = C::t('#it618_waimai#it618_waimai_waimai')->count_by_search('it618_state=2 and it618_htstate=1',$it618orderby,it618_waimai_utftogbk($_GET['it618_name']),$_GET['it618_area1'],$_GET['it618_area2'],$_GET['it618_class1'],$_GET['it618_class2']);
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')exit;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}

	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&cid=".$cid.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getshoplist(this.value,\'\')">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&cid=".$cid.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getshoplist(\''.$tmpurl.'\',\'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getshoplist(\''.$tmpurl.'\',\'\')">'.it618_waimai_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&cid=".$cid.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getshoplist(\''.$tmpurl.'\',\'\')">'.it618_waimai_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&cid=".$cid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getshoplist(\''.$tmpurl.'\',\'\')">'.it618_waimai_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
		}
	}
	
	foreach(C::t('#it618_waimai#it618_waimai_waimai')->fetch_all_by_search(
	'it618_state=2 and it618_htstate=1',$orderby,it618_waimai_utftogbk($_GET['it618_name']),$_GET['it618_area1'],$_GET['it618_area2'],$_GET['it618_class1'],$_GET['it618_class2'],0,$startlimit,$ppp
	) as $it618_waimai_waimai) {
		
		$yytimestr=it618_waimai_getyytime($it618_waimai_waimai);
		$yytimestrarr=explode("it618_split",$yytimestr);
		
		$yytimestr="";
		if($yytimestrarr[0]==2){
			$yytimestr='<font color=#39F style="font-size:10px">'.$yytimestrarr[1].'</font>';
		}
		if($yytimestrarr[0]>3){
			$yytimestr='<font color=red style="font-size:10px">'.$it618_waimai_lang['s692'].'</font>';
		}
	
		$it618_waimai_waimaigroup = C::t('#it618_waimai#it618_waimai_waimaigroup')->fetch_by_id($it618_waimai_waimai['it618_power']);
		$ShopPowerIco='';
		if($it618_waimai_waimaigroup['it618_img']!='')$ShopPowerIco='<img src="'.$it618_waimai_waimaigroup['it618_img'].'" height="15" style="margin-top:-3px"/>';
		
		$tmpurl=it618_waimai_getrewrite('waimai_wap','shop@'.$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:wap&pagetype=shop&sid='.$it618_waimai_waimai['id']);
		
		$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$it618_waimai_waimai['it618_levelsum']);
		
		$lbsm='';
		if($lbslat>0&&$it618_waimai_waimai['it618_lbslat']>0){
			$lbsm=it618_waimai_getdistance($lbslng,$lbslat,$it618_waimai_waimai['it618_lbslng'],$it618_waimai_waimai['it618_lbslat']);
			if($lbsm<1000)$lbsm=intval($lbsm).'m';
			if($lbsm>=1000)$lbsm=round($lbsm/1000,1).'km';
		}
		
		$it618_moneybz='';
		if($it618_waimai_waimai['it618_moneybz']!=''){
			$it618_moneybz='<div class="tddes1"><span class="moneybz">'.it618_waimai_getlang('s369').'</span> '.$it618_waimai_waimai['it618_moneybz'].'</div>';
		}
		
		$it618_peitype='';
		if($it618_waimai_waimai['it618_peitype']==1){
			$it618_peitype='<p style="float:right;margin-top:-1px;padding:2px 3px;height:11px;border-radius: 4px 0px 4px 0px;font-size:10px;color:#000;background-color:#fed23d;">'.$it618_waimai['waimai_peititle'].'</p>';
		}
		
		$strlist.='<tr>
					  <td onclick="location.href=\''.$tmpurl.'\'">
						  <img class="tdimg" src="'.it618_waimai_getwapppic($it618_waimai_waimai['id'],$it618_waimai_waimai['it618_logo']).'"/>
						  <div class="tdname1">'.$it618_waimai_waimai['it618_name'].' '.$ShopPowerIco.'</div>
						  <div class="tdabout"><span style="float:right">'.$lbsm.'</span><img style="margin-top:-3px;" src="'.$it618_waimai_level['it618_img'].'"> '.$it618_waimai_lang['s690'].':'.$it618_waimai_waimai['it618_pmoney'].' '.$yytimestr.' '.it618_waimai_getlang('s1300').':'.$it618_waimai_waimai['it618_views'].'</div>
						  <div class="tdabout">'.$it618_peitype.it618_waimai_getlang('s1298').':'.$it618_waimai_waimai['it618_salecount'].' '.it618_waimai_getlang('s1301').':'.$it618_waimai_waimai['it618_pjcount'].' '.it618_waimai_getlang('s1302').':'.$it618_waimai_waimai['it618_haopjbl'].'%</div>
						  <div class="tddes1">'.it618_waimai_getlang('s719').':'.$it618_waimai_waimai['it618_addr'].'</div>
						  '.$it618_moneybz.'
					  </td>
					</tr>';
	}
	
	$classname=$it618_waimai_lang['t293'];
	if($_GET['it618_class1']>0){
		$classname=C::t('#it618_waimai#it618_waimai_waimai_class')->fetch_it618_name_by_id($_GET['it618_class1']);
	}
	if($_GET['it618_class2']>0){
		$classname=C::t('#it618_waimai#it618_waimai_waimai_class1')->fetch_it618_name_by_id($_GET['it618_class2']);
	}
	
	$areaname=$it618_waimai_lang['t294'];
	if($_GET['it618_area1']>0){
		$areaname=C::t('#it618_waimai#it618_waimai_waimai_area')->fetch_it618_name_by_id($_GET['it618_area1']);
	}
	if($_GET['it618_area2']>0){
		$areaname=C::t('#it618_waimai#it618_waimai_waimai_area1')->fetch_it618_name_by_id($_GET['it618_area2']);
	}
	
	if($_GET['it618_order']==1)$ordername=$it618_waimai_lang['t295'];
	if($_GET['it618_order']==2)$ordername=$tmplevelarr[0].$it618_waimai_lang['t333'];
	if($_GET['it618_order']==3)$ordername=$it618_waimai_lang['t334'];
	if($_GET['it618_order']==4)$ordername=$it618_waimai_lang['t335'];
	if($_GET['it618_order']==5)$ordername=$it618_waimai_lang['t336'];
	if($_GET['it618_order']==6)$ordername=$it618_waimai_lang['t337'];
	if($_GET['it618_order']==7)$ordername=$it618_waimai_lang['t338'];
	if($_GET['it618_order']==8)$ordername=$it618_waimai_lang['t339'];
	
	if($_GET['it618_name']=='')$it618_name=$it618_waimai_lang['t296'];else $it618_name=it618_waimai_utftogbk($_GET['it618_name']);

	$sqlbq='<tr><td class="bq1" id="td1" onClick="getbq1(this)">'.$classname.'<img src="source/plugin/it618_waimai/wap/images/arw_b.gif"></td><td class="bq2" id="td2" onClick="getbq2(this)">'.$areaname.'<img src="source/plugin/it618_waimai/wap/images/arw_b.gif"></td><td class="bq3" id="td3" onClick="getbq3(this)">'.$ordername.'<img src="source/plugin/it618_waimai/wap/images/arw_b.gif"></td><td class="bq4" id="td4"><input type="text" id="searchli_txt1" value="'.$it618_name.'" readonly onClick="getname()"></td></tr>';
	
	if($uid>0&&isset($_GET['findkey'])&&$_GET['it618_name']!=''){
		if($it618_waimai_findkey=C::t('#it618_waimai#it618_waimai_findkey')->fetch_by_uid_key($uid,it618_waimai_utftogbk($_GET['it618_name']))){
			C::t('#it618_waimai#it618_waimai_findkey')->update($it618_waimai_findkey['id'],array(
				'it618_count' => ($it618_waimai_findkey['it618_count']+1),
				'it618_time' => $_G['timestamp']
			));
		}else{
			C::t('#it618_waimai#it618_waimai_findkey')->insert(array(
				'it618_uid' => $uid,
				'it618_key' => it618_waimai_utftogbk($_GET['it618_name']),
				'it618_count' => 1,
				'it618_time' => $_G['timestamp']
			), true);
		}
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext."it618_split".$sqlbq;
	exit;
}

if($_GET['ac']=="goodslist_get"){
	
	$sql="it618_ison=1 and it618_shopid=".intval($_GET['it618_shopid']);
	$order='it618_salecount desc,it618_order,id desc';

	if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;

	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	
	if($ii1ill[5]!='_')exit;
	
	if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;

	foreach(C::t('#it618_waimai#it618_waimai_goods')->fetch_all_by_search($sql, $order) as $it618_waimai_goods) {
		
		if($it618_waimai_goods['it618_zsscore']>0){
			$zsscorestr=$it618_waimai_lang['s3'].'<font color=red>'.$it618_waimai_goods['it618_zsscore'].'</font>'.$creditname;
		}else{
			$zsscorestr=$it618_waimai_lang['s9'];
		}
		
		$salecount=C::t('#it618_waimai#it618_waimai_sale')->sumcountcount_by_it618_pid($it618_waimai_goods['id']);
		C::t('#it618_waimai#it618_waimai_goods')->update_it618_salecount_by_id($it618_waimai_goods['id'],$salecount);
		$salecount=it618_waimai_getlang('s1298').''.$salecount;
			
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;

		$pjhaocount=C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pj_pid(1,$it618_waimai_goods['id']);
		$pjallcount=C::t('#it618_waimai#it618_waimai_sale')->count_pj_by_pid($it618_waimai_goods['id']);
		$pjhaobl=intval($pjhaocount/$pjallcount*100);

		$pj=' '.it618_waimai_getlang('s1301').''.$pjallcount.' '.it618_waimai_getlang('s1302').''.$pjhaobl.'%';
		
		$lipricestr='';

		foreach(C::t('#it618_waimai#it618_waimai_goods_type')->fetch_ok_by_it618_pid($it618_waimai_goods['id']) as $it618_waimai_goods_type) {

			$count=C::t('#it618_waimai#it618_waimai_gwc')->sum_by_uid_pid_gtypeid($uid,$it618_waimai_goods['id'],$it618_waimai_goods_type['id']);
			
			$display='';$gwcjs='onclick="addgwc(\'minus\','.$it618_waimai_goods['id'].','.$it618_waimai_goods_type['id'].')"';
			if($count==0){
				$display='style="display:none"';
			}

			$lipricestr.='<li style="position:relative;width:100%;float:left;padding-top:6px;padding-bottom:6px">
						  <div class="quantity-number" style="position:absolute; right:-6px; top:1px">
							<span name="minusspan" id="span_'.$it618_waimai_goods['id'].'_'.$it618_waimai_goods_type['id'].'" class="minus" '.$display.' '.$gwcjs.'><i class="minus-icon"></i></span>
							<input type="text" class="count" id="count_'.$it618_waimai_goods['id'].'_'.$it618_waimai_goods_type['id'].'" name="count_'.$it618_waimai_goods['id'].'_'.$it618_waimai_goods_type['id'].'" value="'.$count.'" readonly="readonly" '.$display.' /><input type="hidden" id="price_'.$it618_waimai_goods['id'].'_'.$it618_waimai_goods_type['id'].'" value="'.$it618_waimai_goods_type['it618_uprice'].'">
							<span class="plus" onclick="addgwc(\'plus\','.$it618_waimai_goods['id'].','.$it618_waimai_goods_type['id'].')"><i class="plus-icon"></i></span>
						  </div>
						  <span style="float:left;"><strong><span>&yen;</span>'.$it618_waimai_goods_type['it618_uprice'].'</strong> <font color=#333>'.$it618_waimai_goods_type['it618_name'].'</font></span>
						  </li>';
		}
		
		if($lipricestr==''){
			$count=C::t('#it618_waimai#it618_waimai_gwc')->sum_by_uid_pid_gtypeid($uid,$it618_waimai_goods['id'],0);

			$display='';$gwcjs='onclick="addgwc(\'minus\','.$it618_waimai_goods['id'].',0);"';
			if($count==0){
				$display='style="display:none"';
			}
			
			$lipricestr='<li style="position:relative">
						  <div class="quantity-number">
							<span name="minusspan" id="span_'.$it618_waimai_goods['id'].'_0" class="minus" '.$display.' '.$gwcjs.'><i class="minus-icon"></i></span>
							<input type="text" class="count" id="count_'.$it618_waimai_goods['id'].'_0" name="count_'.$it618_waimai_goods['id'].'_0" value="'.$count.'" readonly="readonly" '.$display.' /><input type="hidden" id="price_'.$it618_waimai_goods['id'].'_0" value="'.$it618_waimai_goods['it618_uprice'].'">
							<span class="plus" onclick="addgwc(\'plus\','.$it618_waimai_goods['id'].',0);"><i class="plus-icon"></i></span>
						  </div>
						  <span style="float:left;"><strong><span>&yen;</span>'.$it618_waimai_goods['it618_uprice'].'</strong></span>
						  </li>';
		}
		
		$strlist.='<tr name="class'.$it618_waimai_goods['it618_class_id'].'">
					  <td '.$hrefjs.'>
					  	  <img class="tdimg" src="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" onclick="showgoods('.$it618_waimai_goods['id'].')"/>
						  <div class="tdname" onclick="showgoods('.$it618_waimai_goods['id'].')">'.$it618_waimai_goods['it618_name'].'</div>
						  <div class="tddes">'.$zsscorestr.'</div>
						  <div class="tddes">'.$salecount.' '.$pj.'</div>
						  <ul class="tdprice">'.$lipricestr.'</ul>
					  </td>
					</tr>';
	}
	
	echo $strlist;
	exit;
}

if($_GET['ac']=="gwcsave"){
	if($uid>0){
		$sql="it618_ison=1 and it618_shopid=".$ShopId;
	
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
	
		$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
		
		if($ii1ill[5]!='_')exit;
		
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		
		C::t('#it618_waimai#it618_waimai_gwc')->delete_by_uid($uid);
	
		foreach(C::t('#it618_waimai#it618_waimai_goods')->fetch_all_by_search($sql) as $it618_waimai_goods) {
			$pid=$it618_waimai_goods['id'];
			$gtypeid=0;

			foreach(C::t('#it618_waimai#it618_waimai_goods_type')->fetch_ok_by_it618_pid($it618_waimai_goods['id']) as $it618_waimai_goods_type) {
				$gtypeid=$it618_waimai_goods_type['id'];
				$count=$_GET['count_'.$pid.'_'.$gtypeid];
				
				if($count>0){
					C::t('#it618_waimai#it618_waimai_gwc')->insert(array(
						'it618_uid' => $uid,
						'it618_pid' => $pid,
						'it618_shopid' => $ShopId,
						'it618_gtypeid' => $gtypeid,
						'it618_count' => $count
					), true);
				}
			}
			
			if($gtypeid==0){
				$count=$_GET['count_'.$pid.'_'.$gtypeid];
				
				if($count>0){
					C::t('#it618_waimai#it618_waimai_gwc')->insert(array(
						'it618_uid' => $uid,
						'it618_pid' => $pid,
						'it618_shopid' => $ShopId,
						'it618_gtypeid' => $gtypeid,
						'it618_count' => $count
					), true);
				}
			}
		}
		
		echo 'ok';
	}else{
		echo $it618_waimai_lang['s1730'];
	}
}

if($_GET['ac']=="gwclist_get"){
	$allsummoney=0;
	foreach(C::t('#it618_waimai#it618_waimai_gwc')->fetch_all_by_uid($uid) as $it618_waimai_gwc) {
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($it618_waimai_gwc['it618_pid']);
		
		$isaddr=1;
		
		$gtypename='';
		if($it618_waimai_gwc['it618_gtypeid']>0){
			$gtypename = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_it618_name_by_id($it618_waimai_gwc['it618_gtypeid']);
			$gtypename = '<font color=red>'.$gtypename.'</font>';
			
			$it618_waimai_goods_type = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_by_id($it618_waimai_gwc['it618_gtypeid']);
			$it618_uprice=$it618_waimai_goods_type['it618_uprice'];
			$it618_zsscore=$it618_waimai_goods_type['it618_zsscore'];
		}else{
			$it618_uprice=$it618_waimai_goods['it618_uprice'];
			$it618_zsscore=$it618_waimai_goods['it618_zsscore'];
		}
		
		$shopid=$it618_waimai_gwc['it618_shopid'];
		
		$it618_count=$it618_waimai_gwc['it618_count'];
		
		$zsscore='';
		if($it618_zsscore>0){
			$zsscore='<font color="#999">'.$it618_waimai_lang['t459'].'<font color=red>'.($it618_zsscore*$it618_count).'</font>'.$creditname.'</font>';
		}else{
			$zsscore='<font color="#999">'.$it618_waimai_lang['s9'].'</font>';
		}

		$allzsscore=$allzsscore+$it618_zsscore*$it618_count;
		
		$summoney=$it618_uprice*$it618_count;
		$allsummoney=$allsummoney+$summoney;
		
		$gwcjs='onclick="gwcminus('.$it618_waimai_gwc['id'].')"';
		if($it618_count==1){
			$gwcjs='onclick="delgwc('.$it618_waimai_gwc['id'].')"';
		}
		
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		
		$goodslist.='<tr id="gwcpid'.$it618_waimai_gwc['id'].'" class="cart-list cl"><td style="padding-top:5px;padding-bottom:5px"><table width="100%">
						<tr class="gwclisttr1">
						<td style="padding-left:3px; padding-right:6px; width:50px" onclick="showgoods('.$it618_waimai_goods['id'].')">
						<img src="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" width="50"/>
						</td>
						
						<td style="position:relative">
						<div class="gwctrdiv" onclick="showgoods('.$it618_waimai_goods['id'].')"><b style="color:#444">'.$it618_waimai_goods['it618_name'].'</b></div>
						<div class="gwctrdiv" onclick="showgoods('.$it618_waimai_goods['id'].')">'.$gtypename.' &yen;'.$it618_uprice.' x '.$it618_count.'</div>
						<div class="gwctrdiv">'.$zsscore.'</div>
						</td>
						
						<td align="center" width="68" style="vertical-align:middle">
						<font color="#f60" style="font-size:13px">&yen;'.$summoney.'</font>
						</td>
						</tr>
					</table></td></tr>';
		
	}
	
	$mjmoney=0;
	if($shopid>0){
		$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($shopid);
		$it618_moneybz=$it618_waimai_waimai['it618_moneybz'];
		if($it618_moneybz!=''){
			$tmparr=explode(",",$it618_moneybz);
			for($i=0;$i<count($tmparr);$i++){
				$tmparr1=explode($it618_waimai_lang['s393'],$tmparr[$i]);
				$tmpmoney=str_replace($it618_waimai_lang['s392'],"",$tmparr1[0]);
				if($allsummoney>=$tmpmoney){
					$moneyarr["i".$i]=$allsummoney-$tmpmoney;
					$itmp="i".$i;
					$$itmp=$tmparr1[1];
				}
			}
			if(count($moneyarr)>0){
				asort($moneyarr);
				$okmoneyarr=array_keys($moneyarr);
				$okmoney=$okmoneyarr[0];
				$mjmoney=$$okmoney;
			}
		}
	}
	
	$inputstr='<input type="hidden" id="productmoney" value="'.$allsummoney.'"><input type="hidden" id="mjmoney" name="mjmoney" value="'.$mjmoney.'"><input type="hidden" id="allzsscore" value="'.$allzsscore.'">';
	
	echo $goodslist.'<td align="right" style="padding:18px 6px;color:#666"><span style="float:left">'.$it618_waimai_lang['s1061'].'<font color=red style="font-size:15px">'.$allzsscore.'</font>'.$creditname.'</span><span style="float:right;color:#333;margin-top:-3px">'.$it618_waimai_lang['s651'].' <b><font color="#FF6600" style="font-size:18px">&yen;'.$allsummoney.'</font></b></span></td></tr>'.$inputstr;
	exit;
}

if($_GET['ac']=="myright"){
	$it='ok';
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/ajax.inc.php';
		$result=unlink($ajaxpath);
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/lang.func.php';
		$result=unlink($ajaxpath);
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="getwaimaiarea"){
	$optstr='<option value="0">'.it618_waimai_getlang('s843').'</option>';
	foreach(C::t('#it618_waimai#it618_waimai_waimai_area1')->fetch_all_by_it618_area_id($_GET['it618_area_id']) as $it618_tmp) {	
		$optstr.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
		
	}
	echo $optstr;
	exit;
}

if($_GET['ac']=="getwaimaiclass"){
	$optstr='<option value="0">'.it618_waimai_getlang('s844').'</option>';
	foreach(C::t('#it618_waimai#it618_waimai_waimai_class1')->fetch_all_by_it618_class_id($_GET['it618_class_id']) as $it618_tmp) {	
		$optstr.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
		
	}
	echo $optstr;
	exit;
}

$n=1;
if($_GET['ac']=="getshopclass"){
	$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'shopclass2'.$strtmp.'\',0,0)" name="shopclass2'.$strtmp.'"><span>'.$it618_waimai_lang['t298'].'</span><i></i></a>';
	foreach(C::t('#it618_waimai#it618_waimai_waimai_class1')->fetch_all_by_it618_class_id($_GET['cid']) as $it618_tmp) {	
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'shopclass2'.$strtmp.'\','.$n.','.$it618_tmp['id'].')" name="shopclass2'.$strtmp.'"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $classtmp;
	exit;
}

$n=1;
if($_GET['ac']=="getshoparea"){
	$areatmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'shoparea2'.$strtmp.'\',0,0)" name="shoparea2'.$strtmp.'"><span>'.$it618_waimai_lang['t298'].'</span><i></i></a>';
	foreach(C::t('#it618_waimai#it618_waimai_waimai_area1')->fetch_all_by_it618_area_id($_GET['aid']) as $it618_tmp) {	
		$areatmp.='<a href="javascript:void(0)" onclick="setselect(\'shoparea2'.$strtmp.'\','.$n.','.$it618_tmp['id'].')" name="shoparea2'.$strtmp.'"><span>'.$it618_tmp['it618_name'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $areatmp;
	exit;
}

if($_GET['ac']=="renzheng"){
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	$waimai_rzpower=(array)unserialize($it618_waimai['waimai_rzpower']);
	if($uid<=0){
		echo it618_waimai_getlang('s171');
	}elseif(!in_array($_G['groupid'], $waimai_rzpower)){
		echo it618_waimai_getlang('s497');
	}else{
		$yytimestr=it618_waimai_getyytime("");
		$yytimestrarr=explode("it618_split",$yytimestr);
		
		if($yytimestrarr[0]==2){
			echo $it618_waimai_lang['s94'].$yytimestrarr[1].$it618_waimai_lang['s97'];exit;
		}
		if($yytimestrarr[0]==31){
			echo $it618_waimai_lang['s95'].$yytimestrarr[1];exit;
		}
		
		$count = C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid']);
		if($ii1i11i[3]!='1')exit;
		if($count==0){
			$id = C::t('#it618_waimai#it618_waimai_waimai')->insert(array(
				'it618_uid' => $uid,
				'it618_area_id' => $_GET['it618_area_id'],
				'it618_area1_id' => $_GET['it618_area_id1'],
				'it618_class_id' => $_GET['it618_class_id'],
				'it618_class1_id' => $_GET['it618_class_id1'],
				'it618_power' => $_GET['it618_power'],
				'it618_logo' => $it618_waimai['waimai_shoplogo'],
				'it618_name' => it618_waimai_utftogbk($_GET['it618_name']),
				'it618_tel' => it618_waimai_utftogbk($_GET['it618_tel']),
				'it618_qq' => it618_waimai_utftogbk($_GET['it618_qq']),
				'it618_addr' => it618_waimai_utftogbk($_GET['it618_addr']),
				'it618_liyou' => it618_waimai_utftogbk($_GET['it618_liyou']),
				'it618_state' => 0,
				'it618_time' => $_G['timestamp']
			), true);
			if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
			if($id>0){
				echo 'ok';
				it618_waimai_sendmessage('rz_admin',$id);
			}else{
				echo it618_waimai_getlang('s498');
			}
		}else{
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[7]!='a')exit;
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
			$id = C::t('#it618_waimai#it618_waimai_waimai')->update($it618_waimai_waimai['id'],array(
				'it618_area_id' => $_GET['it618_area_id'],
				'it618_area1_id' => $_GET['it618_area_id1'],
				'it618_class_id' => $_GET['it618_class_id'],
				'it618_class1_id' => $_GET['it618_class_id1'],
				'it618_power' => $_GET['it618_power'],
				'it618_name' => it618_waimai_utftogbk($_GET['it618_name']),
				'it618_tel' => it618_waimai_utftogbk($_GET['it618_tel']),
				'it618_qq' => it618_waimai_utftogbk($_GET['it618_qq']),
				'it618_addr' => it618_waimai_utftogbk($_GET['it618_addr']),
				'it618_liyou' => it618_waimai_utftogbk($_GET['it618_liyou']),
				'it618_state' => 0,
				'it618_time' => $_G['timestamp']
			));
			if(count($ii1i11i)!=12)exit;
			if($id>0){
				echo 'ok';
				it618_waimai_sendmessage('rz_admin',$id);
			}else{
				echo it618_waimai_getlang('s499');
			}
		}
	}
	exit;
}

if($_GET['ac']=="sale_getsale"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_waimai_getlang('s1220');exit;
			}
		}else{
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
			if($it618_waimai_waimai['it618_uid']!=$uid){
				echo 'it618_split'.it618_waimai_getlang('s671');exit;
			}
			
			$yytimestr=it618_waimai_getyytime("");
			$yytimestrarr=explode("it618_split",$yytimestr);
			
			if($yytimestrarr[0]==2){
				echo $it618_waimai_lang['s94'].$yytimestrarr[1].$it618_waimai_lang['s97'];exit;
			}
			if($yytimestrarr[0]==31){
				echo $it618_waimai_lang['s95'].$yytimestrarr[1];exit;
			}
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if($it618_waimai_gwcsale_main['it618_state']!=1){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
			'it618_state' => 2
		));
		
		if($it618_waimai_waimai['it618_peitype']==1){
			echo 'okit618_split'.it618_waimai_getlang('s1159');
		}else{
			echo 'okit618_split'.it618_waimai_getlang('s1161');
		}
		
		it618_waimai_sendmessage('salegetsale_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_sqfahuo"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_waimai_getlang('s1220');exit;
			}
		}else{
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
			if($it618_waimai_waimai['it618_uid']!=$uid){
				echo 'it618_split'.it618_waimai_getlang('s671');exit;
			}
			
			$yytimestr=it618_waimai_getyytime("");
			$yytimestrarr=explode("it618_split",$yytimestr);
			
			if($yytimestrarr[0]==2){
				echo $it618_waimai_lang['s94'].$yytimestrarr[1].$it618_waimai_lang['s97'];exit;
			}
			if($yytimestrarr[0]==31){
				echo $it618_waimai_lang['s95'].$yytimestrarr[1];exit;
			}
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if($it618_waimai_gwcsale_main['it618_state']!=2){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		$it618_isrwpmpower=0;
		if($it618_waimai['waimai_pmmode']==2){
			$it618_isrwpmpower=1;
		}
		
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
			'it618_state' => 3,
			'it618_sqfahuotime' => $_G['timestamp'],
			'it618_isrwpmpower' => $it618_isrwpmpower
		));
		
		echo 'okit618_split'.it618_waimai_getlang('s1163');
		it618_waimai_sendmessage('salesqfahuo_user',$_GET['saleid']);
		it618_waimai_sendmessage('salesqfahuo_admin',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_admingetsale"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_waimai_getlang('s1109');exit;
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if($it618_waimai_gwcsale_main['it618_state']!=1){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
			'it618_state' => 2
		));

		echo 'okit618_split'.it618_waimai_getlang('s1161');
		it618_waimai_sendmessage('salegetsale_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_adminsqfahuo"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_waimai_getlang('s1109');exit;
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if($it618_waimai_gwcsale_main['it618_state']!=2){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
			'it618_state' => 3,
			'it618_sqfahuotime' => $_G['timestamp']
		));
		
		echo 'okit618_split'.it618_waimai_getlang('s1163');
		it618_waimai_sendmessage('salesqfahuo_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_isrwpmpower"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_waimai_getlang('s1109');exit;
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if($it618_waimai_gwcsale_main['it618_state']!=3){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
			'it618_isrwpmpower' => 1
		));

		echo 'okit618_split'.it618_waimai_getlang('s353');
		exit;
	}
}

if($_GET['ac']=="sale_getrw"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		if($rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($uid)){
			if($rwpeimantmp['it618_state']==1){
				echo 'it618_split'.it618_waimai_getlang('s348');exit;
			}
			if($rwpeimantmp['it618_state']==2){
				if($rwpeimantmp['it618_clockstate']==1){
					echo 'it618_split'.it618_waimai_getlang('s349');exit;
				}
			}
		}else{
			echo 'it618_split'.it618_waimai_getlang('s347');exit;
		}
		
		$count = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'(it618_state=4 or it618_state=41) and it618_rwpmid='.$rwpeimantmp['id']);
		$pjcount1 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj=1 and it618_rwpmid='.$rwpeimantmp['id']);
		$allpjcount = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj>0 and it618_rwpmid='.$rwpeimantmp['id']);
		if($allpjcount==0){
			$pjtmp1=0;
		}else{
			$pjtmp1=$pjcount1/$allpjcount*100;
		}
		
		if($it618_waimai_rwpmtcbl=C::t('#it618_waimai#it618_waimai_rwpmtcbl')->fetch_by_pj($pjtmp1)){
			if($count>=$it618_waimai_rwpmtcbl['it618_jdcount']){
				echo 'it618_split'.$it618_waimai_lang['s675'].$it618_waimai_rwpmtcbl['it618_jdcount'].$it618_waimai_lang['s676'];exit;
			}
		}else{
			echo 'it618_split'.it618_waimai_getlang('s677');exit;
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		
		if($it618_waimai_gwcsale_main['it618_state']!=3){
			echo 'it618_split'.it618_waimai_getlang('s350');exit;
		}
		
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
			'it618_rwpmid' => $rwpeimantmp['id'],
			'it618_state' => 4,
			'it618_rwtcbl' => $it618_waimai_rwpmtcbl['it618_tcbl'],
			'it618_pmtime' => $_G['timestamp']
		));
		
		echo 'okit618_split'.it618_waimai_getlang('s351');
		it618_waimai_sendmessage('salefahuo_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_pmgetok"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if($it618_waimai_gwcsale_main['it618_pmid']!='0'){
			if(!$peimantmp=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_uid($uid)){
				echo 'it618_split'.it618_waimai_getlang('s375');exit;
			}
			if($it618_waimai_gwcsale_main['it618_pmid']!=$peimantmp['it618_pmid']){
				echo 'it618_split'.it618_waimai_getlang('s1246');exit;
			}
		}else{
			if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
				if($rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($uid)){
					if($rwpeimantmp['it618_state']==1){
						echo 'it618_split'.it618_waimai_getlang('s348');exit;
					}
					if($rwpeimantmp['it618_state']==2){
						if($rwpeimantmp['it618_clockstate']==1){
							echo 'it618_split'.it618_waimai_getlang('s349');exit;
						}
					}
				}else{
					echo 'it618_split'.it618_waimai_getlang('s347');exit;
				}
				
				if($it618_waimai_gwcsale_main['it618_rwpmid']!=$rwpeimantmp['id']){
					echo 'it618_split'.it618_waimai_getlang('s1246');exit;
				}
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']!=4){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
			'it618_state' => 41,
			'it618_pmoktime' => $_G['timestamp']
		));

		echo 'okit618_split'.it618_waimai_getlang('s402');
		it618_waimai_sendmessage('salegetok_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_fahuo"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_waimai_getlang('s1109');exit;
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if(!($it618_waimai_gwcsale_main['it618_state']==3||$it618_waimai_gwcsale_main['it618_state']==4)){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==3){
			C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
				'it618_pmid' => $_GET['it618_pmid'],
				'it618_state' => 4,
				'it618_pmtime' => $_G['timestamp']
			));
			
			echo 'okit618_split'.it618_waimai_getlang('s1167');
			it618_waimai_sendmessage('salefahuo_user',$_GET['saleid']);
			exit;
		}else{
			C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
				'it618_pmid' => $_GET['it618_pmid'],
				'it618_rwpmid' => 0,
				'it618_pmtime' => $_G['timestamp']
			));
			
			echo 'okit618_split'.it618_waimai_getlang('s1167');
			it618_waimai_sendmessage('salefahuo1_user',$_GET['saleid']);
			exit;
		}
	}
}

if($_GET['ac']=="sale_shopfahuo"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		if($rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($_GET['it618_rwpmid'])){
			if($rwpeimantmp['it618_state']==1){
				echo 'it618_split'.it618_waimai_getlang('s348');exit;
			}
			if($rwpeimantmp['it618_state']==2){
				if($rwpeimantmp['it618_clockstate']==1){
					echo 'it618_split'.it618_waimai_getlang('s349');exit;
				}
			}
		}else{
			echo 'it618_split'.it618_waimai_getlang('s347');exit;
		}
		
		$count = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'(it618_state=4 or it618_state=41) and it618_rwpmid='.$rwpeimantmp['id']);
		$pjcount1 = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj=1 and it618_rwpmid='.$rwpeimantmp['id']);
		$allpjcount = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid(0,'it618_pj>0 and it618_rwpmid='.$rwpeimantmp['id']);
		if($allpjcount==0){
			$pjtmp1=0;
		}else{
			$pjtmp1=$pjcount1/$allpjcount*100;
		}
		
		if($it618_waimai_rwpmtcbl=C::t('#it618_waimai#it618_waimai_rwpmtcbl')->fetch_by_pj($pjtmp1)){
			if($count>=$it618_waimai_rwpmtcbl['it618_jdcount']){
				echo 'it618_split'.$it618_waimai_lang['s675'].$it618_waimai_rwpmtcbl['it618_jdcount'].$it618_waimai_lang['s676'];exit;
			}
		}else{
			echo 'it618_split'.it618_waimai_getlang('s677');exit;
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if(!($it618_waimai_gwcsale_main['it618_state']==2||$it618_waimai_gwcsale_main['it618_state']==4)){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
		
		if($it618_waimai_waimai['it618_peitype']==1){
			echo 'it618_split'.it618_waimai_getlang('s409');exit;
		}
		
		if($it618_waimai_waimai['it618_uid']!=$uid){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==2){
			C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
				'it618_rwpmid' => $_GET['it618_rwpmid'],
				'it618_state' => 4,
				'it618_rwtcbl' => $it618_waimai_rwpmtcbl['it618_tcbl'],
				'it618_pmtime' => $_G['timestamp']
			));
			
			echo 'okit618_split'.it618_waimai_getlang('s1167');
			it618_waimai_sendmessage('salefahuo_user',$_GET['saleid']);
			exit;
		}else{
			C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
				'it618_pmid' => $_GET['it618_rwpmid'],
				'it618_rwpmid' => 0,
				'it618_pmtime' => $_G['timestamp']
			));
			
			echo 'okit618_split'.it618_waimai_getlang('s1167');
			it618_waimai_sendmessage('salefahuo1_user',$_GET['saleid']);
			exit;
		}
	}
}

if($_GET['ac']=="sale_jujuetui"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_waimai_getlang('s1109');exit;
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if($it618_waimai_gwcsale_main['it618_state']!=6){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
			'it618_state' => $it618_waimai_gwcsale_main['it618_state_tuihuo']
		));
		
		echo 'okit618_split'.it618_waimai_getlang('s1213');
		it618_waimai_sendmessage('saletuihuo_user',$_GET['saleid']);
		exit;
	}
}

if($_GET['ac']=="sale_tongyitui"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_waimai_getlang('s1109');exit;
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
		if($it618_waimai_gwcsale_main['it618_state']!=6){
			echo 'it618_split'.it618_waimai_getlang('s1246');exit;
		}
		
		$saleid=intval($_GET['saleid']);
		
		if($IsCredits==1&&$it618_waimai['waimai_tktype']==1){
			
			if($it618_waimai_gwcsale_main['it618_score']>0){
				C::t('common_member_count')->increase($it618_waimai_gwcsale_main['it618_uid'], array(
					'extcredits'.$it618_waimai['waimai_credit'] => $it618_waimai_gwcsale_main['it618_score'])
				);
			}
			
			if($it618_waimai_gwcsale_main['it618_zsscore']>0){
				C::t('common_member_count')->increase($it618_waimai_waimai['it618_uid'], array(
					'extcredits'.$it618_waimai['waimai_credit'] => $it618_waimai_gwcsale_main['it618_zsscore'])
				);
			}
			
			if($it618_waimai_gwcsale_main['it618_sfmoney']>0){
				$money=$it618_waimai_gwcsale_main['it618_sfmoney'];
				
				$it618_bz=$it618_waimai_lang['s1924'];
				$it618_bz=str_replace("{money}",$money,$it618_bz);
				$it618_bz=str_replace("{saleid}",$saleid,$it618_bz);
				
				require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
				savemoney(array(
					'it618_uid' => $it618_waimai_gwcsale_main['it618_uid'],
					'it618_type' => 'zy',
					'it618_money1' => $money,
					'it618_bz' => $it618_bz,
					'it618_zytype' => 'it618_waimai_tk',
					'it618_zyid' => $saleid,
					'it618_time' => $_G['timestamp']
				));
			}
			
			C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
				'it618_state' => 8
			));
			
			echo 'okit618_split'.it618_waimai_getlang('s1216');
			it618_waimai_sendmessage('tk_user',$_GET['saleid']);
		}else{
			C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($_GET['saleid'],array(
				'it618_state' => 7
			));
	
			echo 'okit618_split'.it618_waimai_getlang('s1216');
			it618_waimai_sendmessage('saletuihuo1_user',$_GET['saleid']);
		}
		exit;
	}
}

if($_GET['ac']=="sale_tuihuo"){
	$saleid=intval($_GET['saleid']);
	$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($saleid);
	if($uid!=$it618_waimai_gwcsale_main['it618_uid']){
		echo it618_waimai_getlang('s1246');exit;
	}
	
	$yytimestr=it618_waimai_getyytime("");
	$yytimestrarr=explode("it618_split",$yytimestr);
	
	if($yytimestrarr[0]==2){
		echo $it618_waimai_lang['s94'].$yytimestrarr[1].$it618_waimai_lang['s97'];exit;
	}
	if($yytimestrarr[0]==31){
		echo $it618_waimai_lang['s95'].$yytimestrarr[1];exit;
	}
	
	$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
	
	if($it618_waimai_gwcsale_main['it618_state']==5||$it618_waimai_gwcsale_main['it618_state']==6||$it618_waimai_gwcsale_main['it618_state']==7||$it618_waimai_gwcsale_main['it618_state']==8){
		echo it618_waimai_getlang('s1246');exit;
	}
	
	C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($saleid,array(
		'it618_state' => 6,
		'it618_state_tuihuo' => $it618_waimai_gwcsale_main['it618_state'],
		'it618_content_tuihuo' => it618_waimai_utftogbk($_GET["tuivalue"]),
	));

	echo 'okit618_split'.it618_waimai_getlang('s1206');
	it618_waimai_sendmessage('saletuihuo_shop',$_GET['saleid']);
	it618_waimai_sendmessage('saletuihuo_admin',$_GET['saleid']);
	exit;
}

if($_GET['ac']=="sale_shouhuo"){
	$saleid=intval($_GET['saleid']);
	$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($saleid);
	if($uid!=$it618_waimai_gwcsale_main['it618_uid']){
		echo it618_waimai_getlang('s1246');exit;
	}
	
	$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($_GET['saleid']);
	
	if($it618_waimai_gwcsale_main['it618_state']!=41){
		echo it618_waimai_getlang('s1246');exit;
	}
	
	it618_waimai_qrxf($saleid);
	
	echo 'okit618_split'.it618_waimai_getlang('s1209');exit;
}

if($_GET['ac']=="sale_salepj"){
	$saleid=intval($_GET['saleid']);
	$it618_waimai_sale=C::t('#it618_waimai#it618_waimai_sale')->fetch_by_id($saleid);
	$flag=0;
	if($it618_waimai_sale['it618_pj']>0){
		$waimai_saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'], $waimai_saleadmin)){
			echo it618_waimai_getlang('s1246');exit;
		}
	}else{
		if($uid!=$it618_waimai_sale['it618_uid']){
			echo it618_waimai_getlang('s1246');exit;
		}
		
		$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($it618_waimai_sale['it618_gwcid']);
		
		if($it618_waimai_gwcsale_main['it618_state']!=5){
			echo it618_waimai_getlang('s1246');exit;
		}
		$flag=1;
	}

	
	C::t('#it618_waimai#it618_waimai_sale')->update($saleid,array(
		'it618_content_pj' => dhtmlspecialchars(it618_waimai_utftogbk($_GET["pjvalue"])),
		'it618_pj' => $_GET["goodspj"]
	));

	if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
	
	if($flag==1){
		C::t('#it618_waimai#it618_waimai_sale')->update($saleid,array(
			'it618_pjtime' => $_G['timestamp']
		));
		echo 'okit618_split'.it618_waimai_getlang('s1269');
	}else{
		echo 'editokit618_split'.$it618_waimai_lang['s473'].it618_waimai_getlang('s1269');
	}
	exit;
}

if($_GET['ac']=="sale_pmpj"){
	$saleid=intval($_GET['saleid']);
	$it618_waimai_gwcsale_main=C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($saleid);
	
	$flag=0;
	if($it618_waimai_gwcsale_main['it618_pj']>0){
		$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo it618_waimai_getlang('s1109');exit;
		}
	}else{
		if($uid!=$it618_waimai_gwcsale_main['it618_uid']){
			echo it618_waimai_getlang('s1246');exit;
		}
		
		if($it618_waimai_gwcsale_main['it618_state']!=5){
			echo it618_waimai_getlang('s1246');exit;
		}
		$flag=1;
	}
	
	C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($saleid,array(
		'it618_pjcontent' => it618_waimai_utftogbk($_GET["pjvalue"]),
		'it618_pj' => $_GET["salepj"]
	));
	
	if($flag==1){
		C::t('#it618_waimai#it618_waimai_gwcsale_main')->update($saleid,array(
			'it618_pjtime' => $_G['timestamp']
		));
		echo 'okit618_split'.it618_waimai_getlang('s403');
	}else{
		echo 'okit618_split'.it618_waimai_getlang('s358').it618_waimai_getlang('s403');
	}
}

if($_GET['ac']=="sale_showsale"){
	$gwcid=intval($_GET['gwcid']);
	$it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($gwcid);
	
	$tdn=1;
	foreach(C::t('#it618_waimai#it618_waimai_sale')->fetch_all_by_it618_gwcid($gwcid) as $it618_waimai_sale) {
		$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($it618_waimai_sale['it618_pid']);
		
		$gtypename='';
		if($it618_waimai_sale['it618_gtypeid']>0){
			$gtypename1 = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_it618_name_by_id($it618_waimai_sale['it618_gtypeid']);
			$gtypename = '<font color=red>'.$gtypename1.'</font> ';
			
			$it618_waimai_goods_type = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_by_id($it618_waimai_sale['it618_gtypeid']);
			$it618_uprice=$it618_waimai_goods_type['it618_uprice'];
			$it618_zsscore=$it618_waimai_goods_type['it618_zsscore'];
		}else{
			$it618_uprice=$it618_waimai_goods['it618_uprice'];
			$it618_zsscore=$it618_waimai_goods['it618_zsscore'];
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==5){
			$it618_pj='<font color=#aaa>'.$it618_waimai_lang['s1248'].'</font>';
		}
		
		if($it618_waimai_sale['it618_pj']>0){
			if($it618_waimai_sale['it618_pj']==1)$it618_pj='<font color=red>'.$it618_waimai_lang['s1266'].'</font>';
			if($it618_waimai_sale['it618_pj']==2)$it618_pj='<font color=red>'.$it618_waimai_lang['s1267'].'</font>';
			if($it618_waimai_sale['it618_pj']==3)$it618_pj='<font color=red>'.$it618_waimai_lang['s1268'].'</font>';
			
			$it618_pj.=' <a href="javascript:" onclick="alert(\''.$it618_waimai_sale['it618_content_pj'].'\')">'.$it618_waimai_lang['s1251'].'</a>';
		}else{
			if($it618_waimai_gwcsale_main['it618_state']==5){
				$it618_pj.=' <a href="javascript:" onclick="sale_salepj('.$it618_waimai_gwcsale_main['id'].','.$it618_waimai_sale['id'].')">'.$it618_waimai_lang['s1254'].'</a>';
			}
		}
		
		if($tdn%2>0){
			$trtmpstrtmp='<tr>';
		}
		
		$trtmpstrtmp.='<td width="15%">
					<img src="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" width="95%"/>
					</td>
					<td width="35%">
					<font style="color:#666">'.$it618_waimai_goods['it618_name'].'</font><br>
					'.$gtypename.' '.$it618_uprice.'*<font color=red>'.$it618_waimai_sale['it618_count'].'</font><br>
					<font color=#999>'.$it618_waimai_lang['s1131'].':</font>'.$it618_zsscore.'<br>
					'.$it618_pj.'
					</td>';
					
		if($tdn%2==0){
			$trtmpstrtmp.='</tr>';
			$salestr.=$trtmpstrtmp;
		}
		
		$tdn=$tdn+1;
	}
	
	$trtmpstr=$trtmpstrtmp.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr);
	if(count($tmparr)>1){
		$trtmpstrtmp.='</tr>';
		$salestr.=$trtmpstrtmp;
	}
	
	echo $salestr;
	exit;
}

if($_GET['ac']=="tx_add"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo it618_waimai_getlang('s1220');exit;
			}
		}else{
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
			if($it618_waimai_waimai['it618_uid']!=$uid){
				echo it618_waimai_getlang('s671');exit;
			}
		}
		
		if($_GET['it618_type']==10){
			$it618_state=2;
		}else{
			$it618_state=1;
		}
		
		$it618_money=$_GET['it618_money'];
		if(!$it618_waimai_txbl=DB::fetch_first("SELECT * FROM ".DB::table('it618_waimai_txbl')." where it618_num1<=".$it618_money." and it618_num2>=".$it618_money)){
			echo it618_waimai_getlang('s1182');exit;
		}else{
			$txmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_txmoeny_by_shopid($ShopId,"it618_state=5");
			$sqtxmoney=C::t('#it618_waimai#it618_waimai_tx')->sumtxmoney_by_shopid($ShopId);

			if($it618_money>round(($txmoney-$sqtxmoney),2)){
				echo it618_waimai_getlang('s1183');exit;
			}
		}
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		$id=C::t('#it618_waimai#it618_waimai_tx')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_price' => $it618_money,
			'it618_bl' => $it618_waimai_txbl['it618_bl'],
			'it618_type' => $_GET['it618_type'],
			'it618_bz' => it618_waimai_utftogbk($_GET['it618_bz']),
			'it618_state' => $it618_state,
			'it618_time' => $_G['timestamp']
		), true);
		
		if($_GET['it618_type']==10){
			$money=$it618_money;
			$fwf=round(($it618_money*$it618_waimai_txbl['it618_bl']/100),2);
			$money1=$money-$fwf;
			
			$it618_bz=$it618_waimai_lang['s1922'];
			$it618_bz=str_replace("{money}",$money,$it618_bz);
			$it618_bz=str_replace("{money1}",$money1,$it618_bz);
			$it618_bz=str_replace("{saleid}",$id,$it618_bz);
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
			savemoney(array(
				'it618_uid' => $ShopUid,
				'it618_type' => 'zy',
				'it618_money1' => $money1,
				'it618_bz' => $it618_bz,
				'it618_zytype' => 'it618_waimai_tx',
				'it618_zyid' => $id,
				'it618_time' => $_G['timestamp']
			));
		}
		
		if($_GET['it618_type']!=10){
			echo 'okit618_split'.it618_waimai_getlang('s1184');
			
			it618_waimai_sendmessage('tx_admin',$id);
		}else{
			echo 'okit618_split'.it618_waimai_getlang('s1923');
		}
	}
	exit;
}

if($_GET['ac']=="tx_del"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_waimai_getlang('s1220');exit;
			}
		}else{
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
			if($it618_waimai_waimai['it618_uid']!=$uid){
				echo 'it618_split'.it618_waimai_getlang('s671');exit;
			}
		}
		$txid=$_GET['txid'];
		$it618_waimai_tx = DB::fetch_first("SELECT * FROM ".DB::table('it618_waimai_tx')." where id=".$txid);
		if($it618_waimai_tx['it618_state']==1){
			DB::delete('it618_waimai_tx', "id=$txid");
	
			echo 'ok';
		}
	}
	exit;
}

if($_GET['ac']=="tx_get"){
	if($uid<=0){
		echo 'it618_split'.it618_waimai_getlang('s671');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_waimai_getlang('s1220');exit;
			}
		}else{
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
			if($it618_waimai_waimai['it618_uid']!=$uid){
				echo 'it618_split'.it618_waimai_getlang('s671');exit;
			}
		}
		$ppp = 10;
		
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		$count = C::t('#it618_waimai#it618_waimai_tx')->count_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
		$sum = C::t('#it618_waimai#it618_waimai_tx')->sum_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
		if($sum=='')$sum=0;
		
		foreach(C::t('#it618_waimai#it618_waimai_tx')->fetch_all_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId, $startlimit,$ppp) as $it618_waimai_tx)    {
			$fwf=round(($it618_waimai_tx['it618_price']*$it618_waimai_tx['it618_bl']/100),2);
			if($it618_waimai_tx['it618_type']==10)$it618_type=it618_waimai_getlang('s1918');
			if($it618_waimai_tx['it618_type']==1)$it618_type=it618_waimai_getlang('s1919');
			if($it618_waimai_tx['it618_type']==2)$it618_type=it618_waimai_getlang('s1920');
			if($it618_waimai_tx['it618_type']==3)$it618_type=it618_waimai_getlang('s1921');
			
			if($_GET['wap']==1){
				$delbtn='';
				if($it618_waimai_tx['it618_state']==1){$it618_state='<font color=red>'.it618_waimai_getlang('s957').'</font>';$delbtn=' <a href="javascript:" onclick="deltx('.$it618_waimai_tx['id'].')">'.it618_waimai_getlang('s1185').'</a>';}
				if($it618_waimai_tx['it618_state']==2)$it618_state='<font color=green>'.it618_waimai_getlang('s958').'</font>';
				
				$it618_bz='';
				if($it618_waimai_tx['it618_bz']!='/'){
					$it618_bz='<br>'.$it618_waimai_tx['it618_bz'];
				}
				
				$tx_get.='<tr class="hover"><td style="color:#999">'.it618_waimai_getlang('s961').':<font color=red>'.$it618_waimai_tx['it618_price'].'</font>'.it618_waimai_getlang('s389').' '.it618_waimai_getlang('s962').':'.$it618_waimai_tx['it618_bl'].'%<br>'.it618_waimai_getlang('s963').':'.$fwf.''.it618_waimai_getlang('s389').' '.it618_waimai_getlang('s964').':<font color=green>'.($it618_waimai_tx['it618_price']-$fwf).'</font>'.it618_waimai_getlang('s389').$it618_bz.'<br><font color=green>'.$it618_type.'</font> '.date('Y-m-d H:i:s', $it618_waimai_tx['it618_time']).'<span style="float:right">'.$it618_state.$delbtn.'</span></td></tr>';
			}else{
				$delbtn='';
				if($it618_waimai_tx['it618_state']==1){$it618_state='<font color=red>'.it618_waimai_getlang('s957').'</font>';$delbtn=' <input type="button" class="btn" style="width:40px;" onclick="deltx('.$it618_waimai_tx['id'].')" value="'.it618_waimai_getlang('s1185').'" />';}
				if($it618_waimai_tx['it618_state']==2)$it618_state='<font color=green>'.it618_waimai_getlang('s958').'</font>';
				
				$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
				if($ii1i11i[3]!='1')exit;
				$tx_get.='<tr><td><font color=red>'.$it618_waimai_tx['it618_price'].'</font></td><td>'.$it618_waimai_tx['it618_bl'].'%</td><td>'.$fwf.'</td><td><font color=green>'.($it618_waimai_tx['it618_price']-$fwf).'</font></td><td>'.$it618_waimai_tx['it618_bz'].'</td><td>'.date('Y-m-d H:i:s', $it618_waimai_tx['it618_time']).'</td><td>'.$it618_type.'</td><td>'.$it618_state.$delbtn.'</td></tr>';
			}
			
		}
		
		if($_GET['wap']!=1){
			$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_waimai:ajax");
			$multipage=str_replace("href=","name=",$multipage);
			$multipage=str_replace("name=","href='javascript:' onclick='gettxlist(this.name)' name=",$multipage);
			$multipage=str_replace("onclick='gettxlist(this.name)' ".'name="custompage"','',$multipage);
			$multipage=str_replace('window.location=','gettxlist(',$multipage);
			$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
			if($multipage!='')$multipage='<tr><td colspan=10><div class="cuspages right">'.$multipage.'</div></td></tr>';
			if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		}else{
			$funname='gettxlist';
			if($count<=$ppp){
				$pagecount=1;
			}else{
				$pagecount=ceil($count/$ppp);
			}
			
			if($pagecount>1){
				$n=1;
				while($n<=$pagecount){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".$n;
					if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
					$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
					$n=$n+1;
				}
				$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
				
				if($page==1){
					$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
					if($pagecount>1){
						$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=2";
						$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
					}else{
						$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
					}
				}elseif($page<$pagecount){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
					$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page+1);
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
				}else{
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
					$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
					$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
				}
				$multipage=$pagepre.' '.$curpage.' '.$pagenext;
			}
		}
		
		$txmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_txmoeny_by_shopid($ShopId,"it618_state=5");
		$sqtxmoney=C::t('#it618_waimai#it618_waimai_tx')->sumtxmoney_by_shopid($ShopId);
		
		echo round(($txmoney-$sqtxmoney),2).'it618_split'.it618_waimai_getlang('s959').'<font color=red>'.$count.'</font> '.it618_waimai_getlang('s960').'<font color=red>'.$sum.'</font> '.it618_waimai_getlang('s389').'it618_split'.$tx_get.$multipage;
	}
	exit;
}

if($_GET['ac']=="sc_top"){
	$username=C::t('#it618_waimai#it618_waimai_sale')->fetch_username_by_uid($ShopUid);
	$creditnum=C::t('#it618_waimai#it618_waimai_sale')->fetch_extcredits_by_uid($it618_waimai['waimai_credit'],$ShopUid);
	
	$pjcount=C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pj_shopid($ShopId);
	$it618_waimai_level=C::t('#it618_waimai#it618_waimai_level')->fetch_by_type_salecount(0,$pjcount);
	
	$txmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_txmoeny_by_shopid($ShopId,"it618_state=5");
	$sqtxmoney=C::t('#it618_waimai#it618_waimai_tx')->sumtxmoney_by_shopid($ShopId);
	
	$pcountstr=it618_waimai_getlang('s1386').'<font color="red"><b>'.$pcount.'</b></font> <font color="#ccc">|</font> ';
	$txmoneystr=' '.it618_waimai_getlang('s1004').'<font color="#3F0"><b>'.($txmoney-$sqtxmoney).'</b></font> '.it618_waimai_getlang('s539');
	
	echo $ShopPower.it618_waimai_getlang('s562').'<font color="#FFFF00"><b>'.$username.'</b></font> '.$tmplevelarr[0].it618_waimai_getlang('s562').'<img style="vertical-align:middle;margin-top:-3px" src="'.$it618_waimai_level['it618_img'].'"> '.it618_waimai_getlang('s68').'<font color="#FF9900"><strong>'.$creditnum.'</strong></font>'.$txmoneystr;
	exit;
}

if($_GET['ac']=="getsalemaxid"){
	$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
	if(!in_array($_G['uid'],$saleadmin)){
		echo 'it618_split'.it618_waimai_getlang('s1109');exit;
	}
	
	$id = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_id_by_state();
	
	echo 'it618_split'.$id.'it618_split';exit;
}

if($_GET['ac']=="sale_dao"){
	if($_GET['ac1']=='shop'){
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_waimai_getlang('s1220');exit;
			}
		}else{
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
			if($it618_waimai_waimai['it618_uid']!=$uid){
				echo 'it618_split'.it618_waimai_getlang('s671');exit;
			}
			$shopid=$it618_waimai_waimai['id'];
		}
	}else{
		$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_waimai_getlang('s1109');exit;
		}
	}
	
	if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
	
	$it618sql = "it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==41)$it618sql = "it618_state = 41";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
		if($_GET['state']==8)$it618sql = "it618_state = 8";
	}
	
	if($_GET['ac1']=='shop'){
		$findshopid=$shopid;
	}else{
		$findshopid=$_GET['findshopid'];
	}
	
	$count = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid($findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$money=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_money',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$mjmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_mjmoney',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$zsscore=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_zsscore',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$tc=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_tc',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($_GET['ac1']=='admin'){
		$yunfei=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
		$scoremoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_scoremoney',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
		$score=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_score',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
		
		$strtmp= it618_waimai_getlang('s1136').''."$count ".$it618_waimai_lang['s1137']."$money ".$it618_waimai_lang['s1104']."$mjmoney ".$it618_waimai_lang['s1144']."$yunfei ".$it618_waimai_lang['s1145']."$scoremoney".$it618_waimai_lang['s1146']."$score ".$it618_waimai_lang['s1138']."$tc ".it618_waimai_getlang('s1139')."$zsscore"."\n";
	}else{
		$strtmp= it618_waimai_getlang('s1136').''."$count ".$it618_waimai_lang['s1137']."$money ".$it618_waimai_lang['s1104']."$mjmoney ".$it618_waimai_lang['s1138']."$tc ".it618_waimai_getlang('s1139')."$zsscore"."\n";
	}
	
	if($_GET['ac1']=='shop'){
		$strtmp.=$it618_waimai_lang['s1124'].",";
		$strtmp.=$it618_waimai_lang['s1125'].",";
		$strtmp.=$it618_waimai_lang['s1141'].",";
		$strtmp.=$it618_waimai_lang['s1127'].",";
		$strtmp.=$it618_waimai_lang['s1130'].",";
		$strtmp.=$it618_waimai_lang['s1132'].",";
		$strtmp.=$it618_waimai_lang['s1133'].",";
		$strtmp.=$it618_waimai_lang['s1131'].",";
		$strtmp.=$it618_waimai_lang['s1134'].",";
		$strtmp.=$it618_waimai_lang['s1390'].",";
		$strtmp.=$it618_waimai_lang['s1135']."\n";
	}else{
		$strtmp.=$it618_waimai_lang['s1124'].",";
		$strtmp.=$it618_waimai_lang['s779'].",";
		$strtmp.=$it618_waimai_lang['s780'].",";
		$strtmp.=$it618_waimai_lang['s1125'].",";
		$strtmp.=$it618_waimai_lang['s1141'].",";
		$strtmp.=$it618_waimai_lang['s1127'].",";
		$strtmp.=$it618_waimai_lang['s1105'].",";
		$strtmp.=$it618_waimai_lang['s1128'].",";
		$strtmp.=$it618_waimai_lang['s1129'].",";
		$strtmp.=$it618_waimai_lang['s1130'].",";
		$strtmp.=$it618_waimai_lang['s1132'].",";
		$strtmp.=$it618_waimai_lang['s1133'].",";
		$strtmp.=$it618_waimai_lang['s1131'].",";
		$strtmp.=$it618_waimai_lang['s1134'].",";
		$strtmp.=$it618_waimai_lang['s1390'].",";
		$strtmp.=$it618_waimai_lang['s1135']."\n";
	}

			
	foreach(C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_all_by_shopid(
		$findshopid,$it618sql,'id desc',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']
	) as $it618_waimai_gwcsale_main) {
		
		if($it618_waimai_gwcsale_main['it618_state']==1)$it618_state=$it618_waimai_lang['s1190'];
		if($it618_waimai_gwcsale_main['it618_state']==2)$it618_state=$it618_waimai_lang['s1191'];
		if($it618_waimai_gwcsale_main['it618_state']==3)$it618_state=$it618_waimai_lang['s1192'];
		if($it618_waimai_gwcsale_main['it618_state']==4)$it618_state=$it618_waimai_lang['s1193'];
		if($it618_waimai_gwcsale_main['it618_state']==41)$it618_state=$it618_waimai_lang['s1198'];
		if($it618_waimai_gwcsale_main['it618_state']==5)$it618_state=$it618_waimai_lang['s1194'];
		if($it618_waimai_gwcsale_main['it618_state']==6)$it618_state=$it618_waimai_lang['s1195'];
		if($it618_waimai_gwcsale_main['it618_state']==7)$it618_state=$it618_waimai_lang['s1196'];
		if($it618_waimai_gwcsale_main['it618_state']==8)$it618_state=$it618_waimai_lang['s1197'];
		
		$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
		
		if($_GET['ac1']=='shop'){
			$strtmp.=$it618_waimai_gwcsale_main['id'].",";
			$strtmp.=$it618_waimai_waimai['it618_name'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_count'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_money'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_mjmoney'].",";
			$strtmp.=$it618_state.",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_tc'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_zsscore'].",";
			$strtmp.=it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_tel'].",";
			$strtmp.=date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time'])."\n";
		}else{
			$classname1=C::t('#it618_waimai#it618_waimai_waimai_area')->fetch_it618_name_by_id($it618_waimai_waimai['it618_area_id']);
			$classname2=C::t('#it618_waimai#it618_waimai_waimai_area1')->fetch_it618_name_by_id($it618_waimai_waimai['it618_area1_id']);
			
			$strtmp.=$it618_waimai_gwcsale_main['id'].",";
			$strtmp.=$classname1.",";
			$strtmp.=$classname2.",";
			$strtmp.=$it618_waimai_waimai['it618_name'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_count'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_money'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_mjmoney'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_yunfei'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_scoremoney'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_score'].",";
			$strtmp.=$it618_state.",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_tc'].",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_zsscore'].",";
			$strtmp.=it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).",";
			$strtmp.=$it618_waimai_gwcsale_main['it618_tel'].",";
			$strtmp.=date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time'])."\n";
		}

		$datacount=$datacount+1;

	}
	
	if($_GET['ac1']=='shop'){
		$shopstr='/shop'.$shopid;
	}else{
		$shopstr='';
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data'.$shopstr.'/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data'.$shopstr.'/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_waimai_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_waimai/kindeditor/data'.$shopstr.'/dao/'.$timestr.'.csv';
	exit;
}

if($_GET['ac']=="sale_get"){
	if($_GET['ac1']=='shop'){
		$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
		
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_waimai['waimai_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo 'it618_split'.it618_waimai_getlang('s1220');exit;
			}
		}else{
			if($it618_waimai_waimai['it618_uid']!=$uid){
				echo 'it618_split'.it618_waimai_getlang('s671');exit;
			}
		}
		
		$shopid=$it618_waimai_waimai['id'];
	}else{
		$saleadmin=explode(",",$it618_waimai['waimai_saleadmin']);
		if(!in_array($_G['uid'],$saleadmin)){
			echo 'it618_split'.it618_waimai_getlang('s1109');exit;
		}
	}
		
	$time=$_G['timestamp']-3600*$it618_waimai['waimai_autodatecount'];
	foreach(C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_all_by_it618_time($time) as $it618_waimai_gwcsale_main) {
		it618_waimai_qrxf($it618_waimai_gwcsale_main['id']);
	}
	
	if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;

	if($_GET['wap']!=1){
		$ppp = 15;
		if($_GET['ac1']=='shop')$ppp = 13;
		$funname='getsalelist';
	}else{
		$ppp = 10;
		$funname='getsalelist';
	}
	
	$it618sql = "it618_state >0";
	if($_GET['state']) {
		if($_GET['state']==1)$it618sql = "it618_state = 1";
		if($_GET['state']==2)$it618sql = "it618_state = 2";
		if($_GET['state']==3)$it618sql = "it618_state = 3";
		if($_GET['state']==4)$it618sql = "it618_state = 4";
		if($_GET['state']==41)$it618sql = "it618_state = 41";
		if($_GET['state']==5)$it618sql = "it618_state = 5";
		if($_GET['state']==6)$it618sql = "it618_state = 6";
		if($_GET['state']==7)$it618sql = "it618_state = 7";
		if($_GET['state']==8)$it618sql = "it618_state = 8";
	}
	
	if($_GET['ac1']=='shop'){
		$findshopid=$shopid;
	}else{
		$findshopid=$_GET['findshopid'];
		if($_GET['peiman']) {
			$peimantmp=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_id($_GET['peiman']);
			$it618sql .= " and it618_pmid = '".$peimantmp['it618_pmid']."'";
		}
	}
	
	$count = C::t('#it618_waimai#it618_waimai_gwcsale_main')->count_by_shopid($findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$atmpstr='';
	if($_GET['wap']==1)$atmpstr='style="float:right;margin-left:6px"';
			
	foreach(C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_all_by_shopid(
		$findshopid,$it618sql,'id desc',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_waimai_gwcsale_main) {
		
		if($it618_waimai_gwcsale_main['it618_state']==1){
			$it618_state='<font color=red>'.$it618_waimai_lang['s1190'].'</font>';
			
			if($_GET['ac1']=='shop'){
				$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_getsale('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1200'].'</a>';
			}else{
				$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_admingetsale('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1200'].'</a>';
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==2){
			$it618_state='<font color=red>'.$it618_waimai_lang['s1191'].'</font>';
			
			if($_GET['ac1']=='shop'){
				if($it618_waimai_waimai['it618_peitype']==0){
					$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_shopfahuo('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s404'].'</a>';
				}
				$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_sqfahuo('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1201'].'</a>';
			}else{
				$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_adminsqfahuo('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1201'].'</a>';
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==3){
			$it618_state='<font color=blue>'.$it618_waimai_lang['s1192'].'</font>';
			
			if($_GET['ac1']=='admin'){
				$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_fahuo('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1203'].'</a>';
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==4||$it618_waimai_gwcsale_main['it618_state']==41){
			$peiman='';
			if($it618_waimai_gwcsale_main['it618_pmid']!='0'){
				$it618_waimai_peiman=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_pmid($it618_waimai_gwcsale_main['it618_pmid']);
				$peiman=' '.$it618_waimai_gwcsale_main['it618_pmid'].'-'.$it618_waimai_peiman['it618_name'];
			}
			if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
				$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_id($it618_waimai_gwcsale_main['it618_rwpmid']);
				$peiman=' '.$it618_waimai_gwcsale_main['it618_rwpmid'].'-'.it618_waimai_getusername($it618_waimai_rwpeiman['it618_uid']).'-'.$it618_waimai_rwpeiman['it618_name'];
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==4){
			$it618_state='<font color=blue>'.$it618_waimai_lang['s1193'].'</font>';
			
			if($_GET['ac1']=='admin'){
				$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_fahuo('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1170'].'</a> '.$peiman;
				$it618_state.='<a href="javascript:" style="float:right;margin-left:6px" onclick="showsalelbs('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s372'].'</a>';
			}else{
				if($it618_waimai_waimai['it618_peitype']==0&&$it618_waimai_gwcsale_main['it618_rwpmid']>0){
					$it618_state.=' <a href="javascript:" '.$atmpstr.' onclick="sale_shopfahuo('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s408'].'</a> '.$peiman;
				}else{
					$it618_state.=$peiman;
				}
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==41){
			$it618_state='<font color=green>'.$it618_waimai_lang['s1198'].'</font>';
			
			$it618_state.=$peiman;
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==5){
			$it618_state='<font color=green>'.$it618_waimai_lang['s1194'].'</font>';
			
			if($it618_waimai_gwcsale_main['it618_pj']>0){
				if($it618_waimai_gwcsale_main['it618_pj']==1)$it618_pj=$it618_waimai_lang['s362'];
				if($it618_waimai_gwcsale_main['it618_pj']==2)$it618_pj=$it618_waimai_lang['s363'];
				if($it618_waimai_gwcsale_main['it618_pj']==3)$it618_pj=$it618_waimai_lang['s364'];
				
				$it618_state.=' <span '.$atmpstr.'><font color=#999>'.$it618_waimai_lang['s359'].': </font><font color=red>'.$it618_pj.'</font></span>';
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==6){
			$it618_state='<font color=purple>'.$it618_waimai_lang['s1195'].'</font>';
			
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==1)$it618_statetmp=$it618_waimai_lang['s1190'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==2)$it618_statetmp=$it618_waimai_lang['s1191'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==3)$it618_statetmp=$it618_waimai_lang['s1192'];
			if($it618_waimai_gwcsale_main['it618_state_tuihuo']==4)$it618_statetmp=$it618_waimai_lang['s1193'];
			$it618_state.=' <font color=#999>'.$it618_waimai_lang['s1171'].$it618_statetmp.'</font>';
			
			if($_GET['ac1']=='admin'){
				if($_GET['wap']!=1){
					$it618_state.='<br><a href="javascript:" onclick="sale_jujuetui('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1211'].'</a> <a href="javascript:" onclick="sale_tongyitui('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1214'].'</a>';
				}else{
					$it618_state.='<br><span style="float:right"><a href="javascript:" onclick="sale_jujuetui('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1211'].'</a> <a href="javascript:" onclick="sale_tongyitui('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1214'].'</a></span>';
				}
			}
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==7){
			$it618_state='<font color=purple>'.$it618_waimai_lang['s1196'].'</font>';
		}
		
		if($it618_waimai_gwcsale_main['it618_state']==8){
			$it618_state='<font color=#FF00FF>'.$it618_waimai_lang['s1197'].'</font>';
		}
		
		if($_GET['ac1']=='admin'){
			if($it618_waimai['waimai_pmmodehide']==0){
				$it618_isrwpmpower='';
				if($it618_waimai_gwcsale_main['it618_state']==3){
					if($it618_waimai_gwcsale_main['it618_isrwpmpower']==1){
						$it618_isrwpmpower='<font color=green>'.$it618_waimai_lang['s334'].'</font>';
					}else{
						$it618_isrwpmpower='<a href="javascript:" onclick="sale_isrwpmpower('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s335'].'</a>';
						if($it618_waimai['waimai_pmmode']==3){
							$it618_time=$_G['timestamp']-$it618_waimai_gwcsale_main['it618_sqfahuotime'];
							if($it618_time>=$it618_waimai['waimai_pmmodetime']*60){
								$it618_isrwpmpower='<font color=green>'.$it618_waimai_lang['s334'].'</font>';
								C::t('#it618_waimai#it618_waimai_gwcsale_main')->update_it618_isrwpmpower_by_id($it618_waimai_gwcsale_main['id']);
							}else{
								$it618_isrwpmpower='<a href="javascript:" onclick="sale_isrwpmpower('.$it618_waimai_gwcsale_main['id'].')">'.($it618_waimai['waimai_pmmodetime']*60-$it618_time).''.$it618_waimai_lang['s336'].'</a>';
							}
						}
					}
				}
				$it618_isrwpmpower1='<td>'.$it618_isrwpmpower.'</td>';
			}
		}
		
		if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
		
		if($_GET['wap']!=1){

			if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;

			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/themes/common/right.txt')){
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/ajax.inc.php';
				$result=unlink($ajaxpath);
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/lang.func.php';
				$result=unlink($ajaxpath);
			}

			if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])exit;
			
			if($_GET['ac1']=='shop'){
				$sale_get.='<tr class="hover">
				<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_waimai_gwcsale_main[id].'" name="delete[]" value="'.$it618_waimai_gwcsale_main[id].'" '.$disabled.'><label for="chk_del'.$it618_waimai_gwcsale_main[id].'">'.$it618_waimai_gwcsale_main['id'].'</label></td>
				<td><font color="red">'.$it618_waimai_gwcsale_main['it618_money'].'</font></td>
				<td><font color="#390">'.$it618_waimai_gwcsale_main['it618_mjmoney'].'</font></td>
				<td><a href="javascript:" onclick="showsale('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1202'].'(<font color=red>'.$it618_waimai_gwcsale_main['it618_count'].'</font>)</a></td>
				<td>'.$it618_state.'</td>
				<td><font color="red">'.$it618_waimai_gwcsale_main['it618_tc'].'</font></td>
				<td><font color="#390">'.$it618_waimai_gwcsale_main['it618_zsscore'].'</font></td>
				<td>'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'</td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time']).'</font></td>
				</tr>';
			}else{
				$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
				
				$classname=C::t('#it618_waimai#it618_waimai_waimai_area1')->fetch_it618_name_by_id($it618_waimai_waimai['it618_area1_id']);
				
				$sale_get.='<tr class="hover">
				<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_waimai_gwcsale_main[id].'" name="delete[]" value="'.$it618_waimai_gwcsale_main[id].'" '.$disabled.'><label for="chk_del'.$it618_waimai_gwcsale_main[id].'">'.$it618_waimai_gwcsale_main['id'].'</label></td>
				<td>['.$classname.'] '.$it618_waimai_waimai['it618_name'].'</td>
				<td><font color="red">'.$it618_waimai_gwcsale_main['it618_money'].'</font></td>
				<td><font color="#390">'.$it618_waimai_gwcsale_main['it618_mjmoney'].'</font></td>
				<td><font color="red">'.$it618_waimai_gwcsale_main['it618_yunfei'].'</font></td>
				<td><font color="#390">'.$it618_waimai_gwcsale_main['it618_scoremoney'].'</font></td>
				<td><a href="javascript:" onclick="showsale('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1202'].'(<font color=red>'.$it618_waimai_gwcsale_main['it618_count'].'</font>)</a></td>
				<td>'.$it618_state.'</td>
				'.$it618_isrwpmpower1.'
				<td><font color="red">'.$it618_waimai_gwcsale_main['it618_tc'].'</font></td>
				<td>'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).'</td>
				<td><font color=#999>'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time']).'</font></td>
				</tr>';
			}
		}else{
			$pid=C::t('#it618_waimai#it618_waimai_sale')->fetch_pid_by_gwcid_goods($it618_waimai_gwcsale_main['id']);
			$it618_waimai_goods=C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);
			
			$it618_mjmoney="";
			if($it618_waimai_gwcsale_main['it618_mjmoney']>0){
				$it618_mjmoney="-".$it618_waimai_gwcsale_main['it618_mjmoney'];
			}
			
			$sale_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;font-size:12px;line-height:15px">
							<img class="lazy" data-original="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" style="float:left;margin-right:6px" width="68" height="68"/>
							<div class="dealcard-waimai single-line" style="font-size:12px"><a href="javascript:" style="float:right" onclick="showsale('.$it618_waimai_gwcsale_main['id'].')">'.$it618_waimai_lang['s1202'].'(<font color=red>'.$it618_waimai_gwcsale_main['it618_count'].'</font>)</a><font color=#999>'.$it618_waimai_lang['s1124'].':</font>'.$it618_waimai_gwcsale_main['id'].' <font color=#999>'.$it618_waimai_lang['s1127'].':</font>'.$it618_waimai_gwcsale_main['it618_money'].$it618_mjmoney.'</div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;font-size:12px;line-height:16px"><font color=#999>'.$it618_waimai_lang['s1133'].':</font>'.$it618_waimai_gwcsale_main['it618_tc'].' <font color=#999>'.$it618_waimai_lang['s1131'].':</font>'.$it618_waimai_gwcsale_main['it618_zsscore'].'<br><font color=#999>'.$it618_waimai_lang['s1134'].':</font>'.it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']).' <font color=#999>'.date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time']).'</font><br>'.$it618_state.$it618_isrwpmpower.'</div>
					</dd>';
		}

	}
	
	$money=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_money',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$mjmoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_mjmoney',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$zsscore=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_zsscore',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$tc=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_tc',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	if($_GET['ac1']=='admin'){
		$yunfei=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_yunfei',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
		$scoremoney=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_scoremoney',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
		$score=C::t('#it618_waimai#it618_waimai_gwcsale_main')->sum_by_shopid('it618_score',$findshopid,$it618sql,'',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	}
	
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_waimai:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value=1 name=page /></td>';
		
		if($_GET['ac1']=='shop'){
			$salesum= '<td colspan=15>'.it618_waimai_getlang('s1136').''."<font color=red>$count</font> ".$it618_waimai_lang['s1137']."<font color=red>$money</font> ".$it618_waimai_lang['s1104']."<font color=#390>$mjmoney</font> ".$it618_waimai_lang['s1138']."<font color=red>$tc</font> ".it618_waimai_getlang('s1139')."<font color=#390>$zsscore</font><span style='float:right'>".it618_waimai_getlang('s1249').'</span></td>';
		}else{
			$salesum= '<td colspan=15>'.it618_waimai_getlang('s1136').''."<font color=red>$count</font> ".$it618_waimai_lang['s1137']."<font color=red>$money</font> ".$it618_waimai_lang['s1104']."<font color=#390>$mjmoney</font> ".$it618_waimai_lang['s1144']."<font color=red>$yunfei</font> ".$it618_waimai_lang['s1145']."<font color=#390>$scoremoney</font> ".$it618_waimai_lang['s1146']."<font color=#390>$score</font> ".$it618_waimai_lang['s1138']."<font color=red>$tc</font> ".it618_waimai_getlang('s1139')."<font color=#390>$zsscore</font><span style='float:right'>".it618_waimai_getlang('s1249').'</span></td>';
		}
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
		
		if($_GET['ac1']=='shop'){
			$salesum= it618_waimai_getlang('s1136').''."<font color=red>$count</font> ".$it618_waimai_lang['s1137']."<font color=red>$money</font> ".$it618_waimai_lang['s1104']."<font color=#390>$mjmoney</font> ".$it618_waimai_lang['s1138']."<font color=red>$tc</font> ".it618_waimai_getlang('s1139')."<font color=#390>$zsscore</font>";
		}else{
			$salesum= it618_waimai_getlang('s1136').''."<font color=red>$count</font> ".$it618_waimai_lang['s1137']."<font color=red>$money</font> ".$it618_waimai_lang['s1104']."<font color=#390>$mjmoney</font> ".$it618_waimai_lang['s1144']."<font color=red>$yunfei</font> ".$it618_waimai_lang['s1145']."<font color=#390>$scoremoney</font> ".$it618_waimai_lang['s1146']."<font color=#390>$score</font> ".$it618_waimai_lang['s1138']."<font color=red>$tc</font> ".it618_waimai_getlang('s1139')."<font color=#390>$zsscore</font>";
		}
	}
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage.'<script>'.$tmpjs.'</script>';
	exit;
}

if($_GET['ac']=="scproduct"){
	
	$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$state0='';$state1='';$state2='';
	if($_GET['state']==0){$it618sql = "1";$state0='selected="selected"';}
	if($_GET['state']==1){$it618sql = "it618_ison = 1";$state1='selected="selected"';}
	if($_GET['state']==2){$it618sql = "it618_ison = 0";$state2='selected="selected"';}
	
	$count = C::t('#it618_waimai#it618_waimai_goods')->count_by_shopid($ShopId,$it618sql,'',$_GET['pname'],$_GET['pclassid'],0,0);

	$sc_prodect_str='<tr><td style="padding-top:6px;">'.it618_waimai_getlang('s250').'<font color=red>'.$count.'</font><br>'.it618_waimai_getlang('s1093').'</td></tr>';
	
	$n=1;
	foreach(C::t('#it618_waimai#it618_waimai_goods')->fetch_all_by_shopid(
		$ShopId,$it618sql,'id desc',$_GET['pname'],$_GET['pclassid'],0,0,$startlimit,$ppp
	) as $it618_waimai_goods) {
		
		if($it618_waimai_goods['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
		
		$typecountall = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_waimai_goods_type')." WHERE it618_pid=".$it618_waimai_goods['id']);
		$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_waimai_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_waimai_goods['id']);
		
		$ptypecss='';
		if($typecountok>0)$ptypecss='readonly="readonly"';
		
		$disabled="";
		if($it618_waimai_goods['it618_salecount']>0)$disabled="disabled=\"disabled\"";
		
		$pjhaocount=C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pj_pid(1,$it618_waimai_goods['id']);
		$pjallcount=C::t('#it618_waimai#it618_waimai_sale')->count_pj_by_pid($it618_waimai_goods['id']);
		$pjhaobl=intval($pjhaocount/$pjallcount*100);
		$pj=' '.it618_waimai_getlang('s1301').''.$pjallcount.' '.it618_waimai_getlang('s1302').''.$pjhaobl.'%';

		$preurl="plugin.php?id=it618_waimai:sc_product$adminsid".$urlsql."&page=$page";
		$preurl=str_replace("&","@",$preurl);
		
		$scurl3=it618_waimai_getrewrite('waimai_wap','sc_product_edit@'.$it618_waimai_goods['it618_shopid'].'@0@'.$it618_waimai_goods['id'].'@0','plugin.php?id=it618_waimai:wap&pagetype=sc_product_edit&sid='.$it618_waimai_goods['it618_shopid'].'&cid='.$it618_waimai_goods['id']);
		
		$scurl4=it618_waimai_getrewrite('waimai_wap','sc_product_type@'.$it618_waimai_goods['it618_shopid'].'@0@'.$it618_waimai_goods['id'].'@0','plugin.php?id=it618_waimai:wap&pagetype=sc_product_type&sid='.$it618_waimai_goods['it618_shopid'].'&cid='.$it618_waimai_goods['id']);
		
		$tmpurl=it618_waimai_getrewrite('waimai_wap','product@'.$it618_waimai_goods['it618_shopid'].'@0@'.$it618_waimai_goods['id'].'@0','plugin.php?id=it618_waimai:wap&pagetype=product&sid='.$it618_waimai_goods['it618_shopid'].'&cid='.$it618_waimai_goods['id']);
		
		$salecount=C::t('#it618_waimai#it618_waimai_sale')->sumcountcount_by_it618_pid($it618_waimai_goods['id']);
		C::t('#it618_waimai#it618_waimai_goods')->update_it618_salecount_by_id($it618_waimai_goods['id'],$salecount);
		
		$salecount1=C::t('#it618_waimai#it618_waimai_sale')->sumcountcount_by_it618_pid1($it618_waimai_goods['id']);
		if($salecount1>0)$disabled='disabled="disabled"';
		
		$sc_prodect_str .= '
		<tr><td class="scimage"><table width=100%><tr><td width=63>
		<input type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_waimai_goods[id].'" '.$disabled.' style="vertical-align:middle">
		<label for="chk_del'.$n.'">'.$it618_waimai_goods[id].' <img src="'.it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']).'" width="58" height="58" align="absmiddle"/></label><input type="hidden" id="flag'.$it618_waimai_goods[id].'" value="0">
		</td>
		<td style="line-height:18px;vertical-align:top;padding-top:3px"><input type="text" class="txt" style="width:100%;margin-bottom:6px;line-height:15px;height:15px;font-size:12px" id="it618_name'.$n.'" name="it618_name['.$it618_waimai_goods[id].']" value="'.$it618_waimai_goods[it618_name].'"><br><a href="'.$scurl3.'" style="float:right;">'.it618_waimai_getlang('s109').'</a>'.$it618_waimai_lang['s390'].'<input type="text" class="txt" style="width:60px;margin-right:0;margin-bottom:3px;color:red;line-height:15px;height:15px;font-size:12px" id="it618_uprice'.$n.'" name="it618_uprice['.$it618_waimai_goods[id].']" value="'.$it618_waimai_goods[it618_uprice].'" '.$ptypecss.'> '.$it618_waimai_lang['s389'].' '.$it618_waimai_lang['s1230'].'<input type="text" class="txt" style="width:56px;margin-right:0;margin-bottom:3px;color:blue;line-height:15px;height:15px;font-size:12px" name="it618_zsscore['.$it618_waimai_goods[id].']" value="'.$it618_waimai_goods[it618_zsscore].'" '.$ptypecss.'><br><font color=#999>'.it618_waimai_classname($it618_waimai_goods['id']).' '.it618_waimai_getlang('s1298').$salecount.' '.$pj.'</font><br><span id="ptype'.$it618_waimai_goods[id].'"><a href="'.$scurl4.'" style="float:left;margin-right:8px">'.it618_waimai_getlang('s1712').'(<font color=red>'.$typecountok.'</font>/<font color=red>'.$typecountall.'</font>)</a></span><span style="float:right;margin-top:-2px"><input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_waimai_goods['id'].']" '.$it618_ison_checked.' value="1"><label for="chk_ison'.$n.'" style="color:#999">'.it618_waimai_getlang('s240').'</label></span></td></tr></table></td></tr>';
				
		$n=$n+1;
	}
	
	$sc_prodect_str .= '<input type="hidden" id="tmpn" value="'.$n.'"><script type="text/javascript">'.$sctmpjs.'</script>';
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopI&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getscproductlist(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s708').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_waimai_getlang('s709').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s709').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_waimai:ajax&sid=$ShopId&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getscproductlist(\''.$tmpurl.'\')">'.it618_waimai_getlang('s708').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_waimai_getlang('s709').'</a>';
		}
		$multipage='<tr><td></td></tr><tr><td align="center" style="border-top:#e8e8e8 1px solid">'.$pagepre.' '.$curpage.' '.$pagenext.'</td></tr>';
	}
	  
	echo $sc_prodect_str.$multipage;
}

if($_GET['ac']=="data_save"){
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid'])>0){
		$it618_waimai_waimaitmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_waimai_waimaitmp['it618_uid']){
			exit;
		}
	}else{
		exit;
	}
	
	if($_GET['it618_pmoney']<$it618_waimai_waimai['it618_adminpmoney']){
		$it618_pmoney=$it618_waimai_waimai['it618_adminpmoney'];
	}else{
		$it618_pmoney=$_GET['it618_pmoney'];
	}
	
	C::t('#it618_waimai#it618_waimai_waimai')->update($ShopId,array(
		'it618_isok' => $_GET['it618_isok'],
		'it618_isokbz' => it618_waimai_utftogbk($_GET['it618_isokbz']),
		'it618_isoktime' => it618_waimai_utftogbk($_GET['it618_isoktime']),
		'it618_pmoney' => $_GET['it618_pmoney'],
		'it618_moneybz' => it618_waimai_utftogbk($_GET['it618_moneybz']),
		'it618_messagetel' => it618_waimai_utftogbk($_GET['it618_messagetel']),
		'it618_messageisok' => $_GET['it618_messageisok'],
		'it618_systemcount' => $_GET['it618_systemcount'],
	));
	
	if($it618_waimai_waimai['it618_peitype']==0){
		$tmparr=explode(",",$_GET['it618_rwpmids']);
		for($i=0;$i<count($tmparr);$i++){
			$pmuid=intval($tmparr[$i]);
			if($rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($pmuid)){
				if($rwpeimantmp['it618_state']==2){
					$tmppmuid.=$pmuid.',';
				}
			}
		}
		
		if($tmppmuid!=''){
			$tmppmuid.='@';	
			$tmppmuid=str_replace(",@","",$tmppmuid);
		}
		
		C::t('#it618_waimai#it618_waimai_waimai')->update($ShopId,array(
			'it618_rwpmids' => $tmppmuid
		));
	}
	
	exit;
}

if($_GET['ac']=="bank_save"){
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid'])>0){
		$it618_waimai_waimaitmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_waimai_waimaitmp['it618_uid']){
			exit;
		}
	}else{
		exit;
	}
	
	if($it618_waimai_bank = DB::fetch_first("SELECT * FROM ".DB::table('it618_waimai_bank')." where it618_shopid=".$ShopId)){
		C::t('#it618_waimai#it618_waimai_bank')->update($it618_waimai_bank['id'],array(
				'it618_name' => it618_waimai_utftogbk($_GET["it618_name"]),
				'it618_bankname' => it618_waimai_utftogbk($_GET["it618_bankname"]),
				'it618_bankid' => it618_waimai_utftogbk($_GET["it618_bankid"]),
				'it618_bankaddr' => it618_waimai_utftogbk($_GET["it618_bankaddr"]),
				'it618_alipayname' => it618_waimai_utftogbk($_GET["it618_alipayname"]),
				'it618_alipay' => it618_waimai_utftogbk($_GET["it618_alipay"]),
				'it618_wxname' => it618_waimai_utftogbk($_GET["it618_wxname"]),
				'it618_wx' => it618_waimai_utftogbk($_GET["it618_wx"])
		 ));
	}else{
		 C::t('#it618_waimai#it618_waimai_bank')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_name' => it618_waimai_utftogbk($_GET["it618_name"]),
				'it618_bankname' => it618_waimai_utftogbk($_GET["it618_bankname"]),
				'it618_bankid' => it618_waimai_utftogbk($_GET["it618_bankid"]),
				'it618_bankaddr' => it618_waimai_utftogbk($_GET["it618_bankaddr"]),
				'it618_alipayname' => it618_waimai_utftogbk($_GET["it618_alipayname"]),
				'it618_alipay' => it618_waimai_utftogbk($_GET["it618_alipay"]),
				'it618_wxname' => it618_waimai_utftogbk($_GET["it618_wxname"]),
				'it618_wx' => it618_waimai_utftogbk($_GET["it618_wx"])
		  ), true);
	}
	
	exit;
}

if($_GET['ac']=="product_type_save"){
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid'])>0){
		$it618_waimai_waimaitmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_waimai_waimaitmp['it618_uid']){
			exit;
		}
	}else{
		exit;
	}
	
	$ok1=0;
	$ok2=0;
	$del=0;
	
	$pid=intval($_GET['pid']);
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_waimai_goods_type', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			if($_GET['it618_zsscore'][$id]>$ShopSCORE){
				$it618_zsscore=$_GET['it618_zsscore'][$id];
			}else{
				$it618_zsscore=$ShopSCORE;
			}
			
			if($_GET['it618_uprice'][$id]>$ShopUPRICE){
				$it618_uprice=$_GET['it618_uprice'][$id];
			}else{
				$it618_uprice=$ShopUPRICE;
			}

			C::t('#it618_waimai#it618_waimai_goods_type')->update($id,array(
				'it618_name' => it618_waimai_utftogbk($_GET['it618_name'][$id]),
				'it618_uprice' => $it618_uprice,
				'it618_zsscore' => $it618_zsscore,
				'it618_ison' => $_GET['it618_ison'][$id]
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_uprice_array = !empty($_GET['newit618_uprice']) ? $_GET['newit618_uprice'] : array();
	$newit618_zsscore_array = !empty($_GET['newit618_zsscore']) ? $_GET['newit618_zsscore'] : array();
	$newit618_ison_array = !empty($_GET['newit618_ison']) ? $_GET['newit618_ison'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			if(trim($newit618_zsscore_array[$key])>$ShopSCORE){
				$it618_zsscore=trim($newit618_zsscore_array[$key]);
			}else{
				$it618_zsscore=$ShopSCORE;
			}
			
			if(trim($newit618_uprice_array[$key])>$ShopUPRICE){
				$it618_uprice=trim($newit618_uprice_array[$key]);
			}else{
				$it618_uprice=$ShopUPRICE;
			}
			                                        
			C::t('#it618_waimai#it618_waimai_goods_type')->insert(array(
				'it618_pid' => $pid,
				'it618_name' => it618_waimai_utftogbk($newit618_name_array[$key]),
				'it618_uprice' => $it618_uprice,
				'it618_zsscore' => $it618_zsscore,
				'it618_ison' => $it618_ison
			), true);
			$ok2=$ok2+1;
		}
	}
	
	foreach(C::t('#it618_waimai#it618_waimai_goods_type')->fetch_ok_by_it618_pid($pid) as $it618_waimai_goods_typetmp) {
		C::t('#it618_waimai#it618_waimai_goods')->update($pid,array(
			'it618_uprice' => $it618_waimai_goods_typetmp['it618_uprice'],
			'it618_zsscore' => $it618_waimai_goods_typetmp['it618_zsscore']
		));
		break;
	}

	echo it618_waimai_getlang('s5').$ok1.' '.$it618_waimai_lang['s6'].$ok2.' '.it618_waimai_getlang('s7').$del;
	
	exit;
}

if($_GET['ac']=="product_save"){
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid'])>0){
		$it618_waimai_waimaitmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_waimai_waimaitmp['it618_uid']){
			exit;
		}
	}else{
		exit;
	}
	
	if($_GET['ac1']=="edit"){
		$pid=intval($_GET['pid']);
		$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($pid);
		
		$get_it618_picbig=$_GET['it618_picbig'];
			
		if($it618_waimai_goods['it618_picbig']!=$get_it618_picbig){
			$tmparr=explode("source",$it618_waimai_goods['it618_picbig']);
			$tmparr1=explode("http://",$it618_waimai_goods['it618_picbig']);
			$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_picbig)&&count($tmparr1)==1){
				$result=unlink($it618_picbig);
			}
		}
		
		$file_ext=strtolower(substr($it618_waimai_goods['it618_picbig'],strrpos($it618_waimai_goods['it618_picbig'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_0.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		
		if($get_it618_picbig!=''){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("http://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_0.'.$file_ext;
			it618_waimai_imagetosmall($it618_url,$it618_smallurl,$file_ext,160,160,1);
		}
	
		if(it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig'])!=$_GET['it618_picsmall']){
			$tmparr=explode("source",it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']));
			$tmparr1=explode("http://",it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']));
			$it618_picsmall=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_picsmall)&&count($tmparr1)==1){
				$result=unlink($it618_picsmall);
			}
		}
		
		C::t('#it618_waimai#it618_waimai_goods')->update($pid,array(
			'it618_name' => it618_waimai_utftogbk($_GET['it618_name']),
			'it618_picbig' => it618_waimai_utftogbk($_GET['it618_picbig']),
			'it618_message' => it618_waimai_utftogbk($_GET['it618_message'],0)
		));
		
		if($_GET['it618_class_id']!=''){
			C::t('#it618_waimai#it618_waimai_goods')->update($pid,array(
				'it618_class_id' => $_GET['it618_class_id']
			));
		}
	}else{
		$pid=C::t('#it618_waimai#it618_waimai_goods')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_class_id' => $_GET['it618_class_id'],
			'it618_name' => it618_waimai_utftogbk($_GET['it618_name']),
			'it618_picbig' => it618_waimai_utftogbk($_GET['it618_picbig']),
			'it618_message' => it618_waimai_utftogbk($_GET['it618_message'],0)
		), true);
		

		$get_it618_picbig=$_GET['it618_picbig'];
		
		if($get_it618_picbig!=''){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("http://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_0.'.$file_ext;
			it618_waimai_imagetosmall($it618_url,$it618_smallurl,$file_ext,160,160,1);

		}
	}
	exit;
}

if($_GET['ac']=="scproduct_save"){
	if(C::t('#it618_waimai#it618_waimai_waimai')->count_by_it618_uid($_G['uid'])>0){
		$it618_waimai_waimaitmp=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid']);
			
		if($ShopUid!=$it618_waimai_waimaitmp['it618_uid']){
			exit;
		}
	}else{
		exit;
	}
	
	if($_GET['ac1']=="del"){
		$del=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$salecount = C::t('#it618_waimai#it618_waimai_sale')->count_by_it618_pid($delid);
			if($salecount<=0){
				$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($delid);
				$tmparr=explode("source",$it618_waimai_goods['it618_picbig']);
				$tmparr1=explode("http://",$it618_waimai_goods['it618_picbig']);
				$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_picbig)&&count($tmparr1)==1){
					$result=unlink($it618_picbig);
				}
				
				$get_it618_picbig=$_GET['it618_picbig'];
				
				if($it618_waimai_goods['it618_picbig']!=$get_it618_picbig){
					$tmparr=explode("source",$it618_waimai_goods['it618_picbig']);
					$tmparr1=explode("http://",$it618_waimai_goods['it618_picbig']);
					$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_picbig)&&count($tmparr1)==1){
						$result=unlink($it618_picbig);
					}
				}
				
				$file_ext=strtolower(substr($it618_waimai_goods['it618_picbig'],strrpos($it618_waimai_goods['it618_picbig'], '.')+1)); 
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_waimai/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
				if(file_exists($it618_smallurl)){
					$result=unlink($it618_smallurl);
				}
				
				C::t('#it618_waimai#it618_waimai_goods')->delete_by_id($delid);
				$del=$del+1;
			}
		}
	
		echo it618_waimai_getlang('s7').$del;
	}

	if($_GET['ac1']=="edit"){
		$ok=0;
		if(is_array($_GET['it618_name'])) {
			foreach($_GET['it618_name'] as $id => $val) {
				
				if($_GET['it618_uprice'][$id]>$ShopUPRICE){
					$it618_uprice=$_GET['it618_uprice'][$id];
				}else{
					$it618_uprice=$ShopUPRICE;
				}
				
				if($_GET['it618_zsscore'][$id]>$ShopZSSCOREB){
					$it618_zsscore=$_GET['it618_zsscore'][$id];
				}else{
					$it618_zsscore=$ShopZSSCOREB;
				}
				
				C::t('#it618_waimai#it618_waimai_goods')->update($id,array(
					'it618_name' => it618_waimai_utftogbk($_GET['it618_name'][$id]),
					'it618_zsscore' => $it618_zsscore,
					'it618_uprice' => $it618_uprice,
					'it618_ison' => $_GET['it618_ison'][$id],
					'it618_order' => intval($_GET['it618_order'][$id])
				));
		
				$ok=$ok+1;
			}
		}
		
		echo it618_waimai_getlang('s5').$ok;
	}
	exit;
}

if($_GET['ac']=="collectshop"){
	if($uid>0){
		$count=C::t('#it618_waimai#it618_waimai_collect')->count_by_uid_shopid($uid,$_GET['sid']);
		if($count>0){
			C::t('#it618_waimai#it618_waimai_collect')->delete_by_uid_shopid($uid,$_GET['sid']);
			echo 'delit618_split';
		}else{
			C::t('#it618_waimai#it618_waimai_collect')->insert(array(
				'it618_uid' => $uid,
				'it618_shopid' => $_GET['sid'],
				'it618_time' => $_G['timestamp']
			), true);
			echo 'addit618_split';
		}
	}else{
		echo $it618_waimai_lang['s1733'];
	}
	exit;
}

if($_GET['ac']=="delcollect"){
	if($uid>0){
		$del=0;
		foreach($_GET['delete'] as $key => $delid) {
			C::t('#it618_waimai#it618_waimai_collect')->delete_by_id($delid);
			$del=$del+1;
		}
		echo 'okit618_split'.$it618_waimai_lang['s1743'].$del;
	}else{
		echo $it618_waimai_lang['s1733'];
	}
	exit;
}

if($_GET['ac']=="getgwcshopid"){
	if($uid>0){
		$shopid=C::t('#it618_waimai#it618_waimai_gwc')->fetch_shopid_by_uid($uid);
		if($shopid>0){
			$shophomeurl=it618_waimai_getrewrite('waimai_wap','shop@'.$shopid,'plugin.php?id=it618_waimai:wap&pagetype=shop&sid='.$shopid);
			echo 'okit618_split'.$shophomeurl;
		}else{
			echo $it618_waimai_lang['t514'];
		}
	}else{
		echo 'login';
	}
	exit;
}

if($_GET['ac']=="getyunfeimoney"){
	$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['sid']);
	$lbslat=$_GET['lbslat'];
	$lbslng=$_GET['lbslng'];
	
	$yunfeistr=$it618_waimai_lang['s1225'];
	$yunfeistr=str_replace("{first}",$it618_waimai_waimai['it618_first'],$yunfeistr);
	$yunfeistr=str_replace("{yunfei1}",$it618_waimai_waimai['it618_yunfei1'],$yunfeistr);
	$yunfeistr=str_replace("{yunfei2}",$it618_waimai_waimai['it618_yunfei2'],$yunfeistr);
	
	$lbsdata=it618_waimai_getdistance_gd($lbslng,$lbslat,$it618_waimai_waimai['it618_lbslng'],$it618_waimai_waimai['it618_lbslat']);
	
	if($lbsdata['info']=='OK'){
		if($lbsdata['results'][0]['distance']>0){
			$lbsm=$lbsdata['results'][0]['distance'];
			//$lbst=$lbsdata['results'][0]['duration'];
			//$lbst=round($lbst/60,1).'<span style="font-size:10px">'.$it618_waimai_lang['s1233'].'</font>';
			
			$lbsmtmp=round($lbsm/1000,1);
			if($lbsmtmp<=$it618_waimai_waimai['it618_first']){
				$yunfei=$it618_waimai_waimai['it618_yunfei1'];
			}else{
				$tmpm=$lbsmtmp-$it618_waimai_waimai['it618_first'];
				$tmpm1=intval($tmpm);
				if($tmpm1<$tmpm)$tmpm1=$tmpm1+1;
				$yunfei=$it618_waimai_waimai['it618_yunfei1']+$tmpm1*$it618_waimai_waimai['it618_yunfei2'];
			}
			
			if($lbsm<1000)$lbsm=intval($lbsm).'m';
			if($lbsm>=1000)$lbsm=round($lbsm/1000,1).'km';
			
			echo '<table width="100%"><tr><td width="76%" style="border:none;padding:0">'.$it618_waimai_lang['s1226'].'<font color=red><b>'.$lbsm.'</b></font><br>'.$yunfeistr.'<br><font color=#999>'.$it618_waimai_lang['s1235'].'</font><a href="javascript:" onclick="getlbsabout(this)">'.$it618_waimai_lang['s1236'].'</a></td><td style="border:none;padding:0"><font color=#f30  style="font-size:15px;float:right">+ &yen;<span id="yunfeimoney" style="font-size:20px">'.$yunfei.'</span></font><input type="hidden" id="yunfeiok" value="1"></td></tr><tr id="lbsabout" style="display:none"><td colspan=2><img src="source/plugin/it618_waimai/images/lbsabout.png" style="max-width:100%"><font color=#999>'.$it618_waimai_lang['s1227'].'</font></td></tr></table>';
		}else{
			$tmparr=explode("|",$it618_waimai_lang['s367']);
			echo '<table width="100%"><tr><td width="76%" style="border:none;padding:0">'.it618_waimai_utftogbk($lbsdata['results'][0]['info']).'<br>'.it618_waimai_utftogbk($tmparr[$lbsdata['results'][0]['code']]).'</td><td style="border:none;padding:0"><font color=#f30  style="font-size:15px;float:right">+ &yen;<span id="yunfeimoney" style="font-size:20px">0</span></font><input type="hidden" id="yunfeiok" value="0"></td></tr></table>';
		}
	}else{
		echo '<table width="100%"><tr><td width="76%" style="border:none;padding:0">'.$it618_waimai_lang['s1234'].it618_waimai_utftogbk($lbsdata['info']).'</td><td style="border:none;padding:0"><font color=#f30  style="font-size:15px;float:right">+ &yen;<span id="yunfeimoney" style="font-size:20px">0</span></font><input type="hidden" id="yunfeiok" value="0"></td></tr></table>';
	}
}

if($_GET['ac']=="sqpeiman"){
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	$waimai_rwpmgroup=(array)unserialize($it618_waimai['waimai_rwpmgroup']);
	if($uid<=0){
		echo it618_waimai_getlang('s1380');exit;
	}elseif(!in_array($_G['groupid'], $waimai_rwpmgroup)){
		echo it618_waimai_getlang('s1381');exit;
	}else{
		if($IsCredits!=1){
			echo it618_waimai_getlang('s1382');exit;
		}
		
		$count = C::t('#it618_waimai#it618_waimai_rwpeiman')->count_by_it618_uid($_G['uid']);
		if($ii1i11i[3]!='1')return;
		if($count==0){
			$id = C::t('#it618_waimai#it618_waimai_rwpeiman')->insert(array(
				'it618_uid' => $uid,
				'it618_name' => it618_waimai_utftogbk($_GET['it618_name']),
				'it618_tel' => it618_waimai_utftogbk($_GET['it618_tel']),
				'it618_wx' => it618_waimai_utftogbk($_GET['it618_wx']),
				'it618_qq' => it618_waimai_utftogbk($_GET['it618_qq']),
				'it618_addr' => it618_waimai_utftogbk($_GET['it618_addr']),
				'it618_liyou' => it618_waimai_utftogbk($_GET['it618_liyou']),
				'it618_state' => 0,
				'it618_rztime' => $_G['timestamp']
			), true);
			if(lang('plugin/it618_waimai', $it618_waimai_lang['it618'])!=$it618_waimai_lang['version'])return;
			if($id>0){
				it618_waimai_sendmessage('sqpm_admin',$id);
				echo 'ok';
			}else{
				echo it618_waimai_getlang('s498');
			}
		}else{
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[7]!='a')return;
			$it618_waimai_rwpeiman=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($_G['uid']);
			$id = C::t('#it618_waimai#it618_waimai_rwpeiman')->update($it618_waimai_rwpeiman['id'],array(
				'it618_name' => it618_waimai_utftogbk($_GET['it618_name']),
				'it618_tel' => it618_waimai_utftogbk($_GET['it618_tel']),
				'it618_wx' => it618_waimai_utftogbk($_GET['it618_wx']),
				'it618_qq' => it618_waimai_utftogbk($_GET['it618_qq']),
				'it618_addr' => it618_waimai_utftogbk($_GET['it618_addr']),
				'it618_liyou' => it618_waimai_utftogbk($_GET['it618_liyou']),
				'it618_state' => 0,
				'it618_rztime' => $_G['timestamp']
			));
			if(count($ii1i11i)!=12)return;
			if($id>0){
				it618_waimai_sendmessage('sqpm_admin',$id);
				echo 'ok';
			}else{
				echo it618_waimai_getlang('s499');
			}
		}
	}
	
	exit;
}

if($_GET['ac']=="pmlbs_save"){
	$rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($uid);
	if($rwpeimantmp['it618_state']==2){
		$lbsarr=it618_waimai_maptxtobd($_GET['lbslat'],$_GET['lbslng']);
		
		C::t('#it618_waimai#it618_waimai_rwpeiman')->update($rwpeimantmp['id'],array(
			'it618_lbslat' => $lbsarr['lat'],
			'it618_lbslng' => $lbsarr['lng'],
			'it618_lbsaddr' => it618_waimai_utftogbk($_GET['lbsaddr']),
			'it618_lbstime' => $_G['timestamp']
		));
	}
	
	if($peimantmp=C::t('#it618_waimai#it618_waimai_peiman')->fetch_by_uid($uid)){
		$lbsarr=it618_waimai_maptxtobd($_GET['lbslat'],$_GET['lbslng']);
		
		C::t('#it618_waimai#it618_waimai_peiman')->update($peimantmp['id'],array(
			'it618_lbslat' => $lbsarr['lat'],
			'it618_lbslng' => $lbsarr['lng'],
			'it618_lbsaddr' => it618_waimai_utftogbk($_GET['lbsaddr']),
			'it618_lbstime' => $_G['timestamp']
		));
	}
}
//From: Dism_taobao-com
?>