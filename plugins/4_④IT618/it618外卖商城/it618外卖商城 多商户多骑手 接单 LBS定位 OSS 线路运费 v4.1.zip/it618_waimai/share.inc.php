<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

if($_GET['type']=='shop'){
	$it618_waimai_waimai = C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($_GET['shareid']);
	$it618_name=$it618_waimai_waimai['it618_name'];
	$it618_img=$it618_waimai_waimai['it618_logo'];
	$tmparr=explode('://',$it618_img);
	if(count($tmparr)==1)$it618_img=$_G['siteurl'].$it618_img;
	$it618_about=$it618_waimai_waimai['it618_addr'].' '.$it618_waimai_waimai['it618_dianhua'].' '.$it618_waimai_waimai['it618_shouji'];
	
	if($_GET['wap']==1){
		$tmpurl=it618_waimai_getrewrite('waimai_wap','shop@'.$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:wap&pagetype=shop&sid='.$it618_waimai_waimai['id']);
	}else{
		$tmpurl=it618_waimai_getrewrite('shop_home',$it618_waimai_waimai['id'],'plugin.php?id=it618_waimai:shop&sid='.$it618_waimai_waimai['id']);
	}
}else if($_GET['type']=='product'){
	$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($_GET['shareid']);
	$it618_name=$it618_waimai_goods['it618_name'];
	$it618_img=it618_waimai_getgoodspic($it618_waimai_goods['it618_shopid'],$it618_waimai_goods['id'],$it618_waimai_goods['it618_picbig']);
	$tmparr=explode('://',$it618_img);
	if(count($tmparr)==1)$it618_img=$_G['siteurl'].$it618_img;
	$it618_about=$it618_waimai_goods['it618_seodescription'];
	$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
	
	if($_GET['wap']==1){
		$tmpurl=it618_waimai_getrewrite('waimai_wap','product@'.$it618_waimai_goods['it618_shopid'].'@0@'.$it618_waimai_goods['id'].'@0','plugin.php?id=it618_waimai:wap&pagetype=product&sid='.$it618_waimai_goods['it618_shopid'].'&cid='.$it618_waimai_goods['id']);
	}else{
		$tmpurl=it618_waimai_getrewrite('shop_product',$it618_waimai_goods['it618_shopid'].'@'.$it618_waimai_goods['id'],'plugin.php?id=it618_waimai:product&sid='.$it618_waimai_goods['it618_shopid'].'&pid='.$it618_waimai_goods['id']);
	}
	
}else if($_GET['type']=='waimai'){
	$it618_name=$it618_waimai['waimai_name'];
	$it618_img=$it618_waimai['waimai_waimailogo'];
	$tmparr=explode('src="',$it618_img);
	$tmparr1=explode('"',$tmparr[1]);
	$it618_img=$tmparr1[0];
	$tmparr=explode('://',$it618_img);
	if(count($tmparr)==1)$it618_img=$_G['siteurl'].$it618_img;
	$it618_about=$it618_waimai['seodescription'];
	$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
	
	if($_GET['wap']==1){
		$tmpurl=it618_waimai_getrewrite('waimai_wap','','plugin.php?id=it618_waimai:wap');
	}else{
		$tmpurl=it618_waimai_getrewrite('waimai_home','','plugin.php?id=it618_waimai:index');
	}

}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:share');
?>