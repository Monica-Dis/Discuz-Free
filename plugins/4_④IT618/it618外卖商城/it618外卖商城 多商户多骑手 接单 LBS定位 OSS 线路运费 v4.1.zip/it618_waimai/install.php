<?php

(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_waimai_waimai`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_waimai` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_area_id` int(10) unsigned NOT NULL,
  `it618_area1_id` int(10) unsigned NOT NULL,
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_logo` varchar(200) NOT NULL,
  `it618_name` varchar(200) NOT NULL,
  `it618_tel` varchar(200) NOT NULL,
  `it618_qq` varchar(200) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_liyou` varchar(2000) NOT NULL,
  `it618_dianhua` varchar(200) NOT NULL,
  `it618_shouji` varchar(200) NOT NULL,
  `it618_kefuqq` varchar(200) NOT NULL,
  `it618_kefuwx` varchar(200) NOT NULL,
  `it618_kefuqqname` varchar(200) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_mappoint` varchar(50) NOT NULL,
  `it618_mapurl` varchar(200) NOT NULL,
  `it618_messagetel` varchar(20) NOT NULL,
  `it618_messageisok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tongji` varchar(2000) NOT NULL,
  `it618_systemcount` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isokbz` varchar(200) NOT NULL,
  `it618_isoktime` varchar(200) NOT NULL DEFAULT '',
  `it618_isokorder` int(10) unsigned NOT NULL,
  `it618_pmoney` float(9,2) NOT NULL DEFAULT '20.00',
  `it618_adminpmoney` float(9,2) NOT NULL DEFAULT '20.00',
  `it618_moneybz` varchar(200) NOT NULL,
  `it618_rwpmids` varchar(200) NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '5.00',
  `it618_scorebl` float(9,2) NOT NULL DEFAULT '50.00',
  `it618_zsscore` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_uprice` float(9,2) NOT NULL DEFAULT '1.00',
  `it618_peitype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_first` float(9,2) NOT NULL,
  `it618_yunfei1` float(9,2) NOT NULL,
  `it618_yunfei2` float(9,2) NOT NULL,
  `it618_moneysum` float(12,2) NOT NULL,
  `it618_levelsum` int(10) unsigned NOT NULL,
  `it618_power` int(10) unsigned NOT NULL,
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_haopjbl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_htstate` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_htetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_waimaigroup`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_waimaigroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupname` varchar(50) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '1000',
  `it618_bz` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_peiman`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_peiman` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pmid` varchar(50) NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_lbsaddr` varchar(200) NOT NULL,
  `it618_lbstime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_rwpeiman`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_rwpeiman` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_tel` varchar(50) NOT NULL,
  `it618_qq` varchar(50) NOT NULL,
  `it618_wx` varchar(100) NOT NULL,
  `it618_addr` varchar(100) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_liyou` varchar(1000) NOT NULL,
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_lbsaddr` varchar(200) NOT NULL,
  `it618_lbstime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_clockstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rztime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_rwpmtcbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_rwpmtcbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pj1` float(9,2) NOT NULL,
  `it618_pj2` float(9,2) NOT NULL,
  `it618_jdcount` int(10) unsigned NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_style`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_style` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_nav`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_level`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_level` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_salecount1` int(10) unsigned NOT NULL,
  `it618_salecount2` int(10) unsigned NOT NULL,
  `it618_about` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_waimai_area`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_waimai_area` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_waimai_area1`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_waimai_area1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_area_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_waimai_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_waimai_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_classnamenav` varchar(10) NOT NULL,
  `it618_cssname` varchar(50) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_waimaicount` int(10) unsigned NOT NULL,
  `it618_wapwaimaicount` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL DEFAULT '',
  `it618_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_waimai_class1`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_waimai_class1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(1000) NOT NULL,
  `it618_uprice` float(9,2) NOT NULL,
  `it618_zsscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_picbig` varchar(300) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_goods_type`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_goods_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_uprice` float(9,2) NOT NULL,
  `it618_zsscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_gwc`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_gwc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_gwcsale_main`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_gwcsale_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pmid` varchar(50) NOT NULL,
  `it618_rwpmid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rwpmidedit` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pmtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pmoktime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rwtcbl` float(9,2) NOT NULL,
  `it618_sqfahuotime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_money` float(9,2) NOT NULL,
  `it618_yunfei` float(9,2) NOT NULL,
  `it618_mjmoney` float(9,2) NOT NULL DEFAULT '0.00',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_scoremoney` float(9,2) NOT NULL,
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_zsscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lbslat` float(9,6) NOT NULL,
  `it618_lbslng` float(9,6) NOT NULL,
  `it618_lbsaddr` varchar(200) NOT NULL,
  `it618_addr` varchar(200) NOT NULL,
  `it618_name` varchar(20) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_isrwpmpower` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjcontent` varchar(1000) NOT NULL,
  `it618_pjtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content_pm` varchar(1000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state_tuihuo` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content_tuihuo` varchar(1000) NOT NULL,
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0.00',
  `it618_tc` float(9,2) NOT NULL DEFAULT '0.00',
  `it618_ktx` float(9,2) NOT NULL DEFAULT '0.00',
  `it618_paytype` varchar(50) NOT NULL,
  `it618_payid` varchar(100) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_zsscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content_pj` varchar(1000) NOT NULL,
  `it618_pjtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_gwcsale`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_gwcsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_zsscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_bank`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_bankname` varchar(200) NOT NULL,
  `it618_bankid` varchar(50) NOT NULL,
  `it618_bankaddr` varchar(50) NOT NULL,
  `it618_alipayname` varchar(50) NOT NULL,
  `it618_alipay` varchar(100) NOT NULL,
  `it618_wxname` varchar(50) NOT NULL,
  `it618_wx` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_txbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_txbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_num1` int(10) unsigned NOT NULL,
  `it618_num2` int(10) unsigned NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_tx`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_tx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_bz` varchar(1000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_collect`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_findkey`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_waimai_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_waimai_saleaudio`;
CREATE TABLE `pre_it618_waimai_saleaudio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_clienid` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>