<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_waimai_goods extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_waimai_goods';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_it618_class_id($it618_class_id) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_class_id=%d", array($this->_table, $it618_class_id));
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_it618_shopid_by_id($id) {
		return DB::result_first("SELECT it618_shopid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_shopid($it618_shopid = 0, $it618sql = '', $it618orderby='', $it618_name = '', $it618_class_id = 0, $price1 = 0, $price2 = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_class_id, $price1, $price2);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_shopid($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_class_id = 0, $price1 = 0, $price2 = 0, $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_class_id, $price1, $price2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_class_id = 0, $price1 = 0, $price2 = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$tmparr=explode(" ",$it618_name);
			for($n=0;$n<count($tmparr);$n++){
				$parameter[] = '%'.$tmparr[$n].'%';
				$tmpsql.='(it618_name LIKE %s) and';
			}
			$tmpsql.='@';
			$tmpsql=str_replace(" and@","",$tmpsql);
			$wherearr[] = $tmpsql;
		}
		if(!empty($it618_class_id)) {
			$parameter[] = $it618_class_id;
			$wherearr[] = 'it618_class_id=%d';
		}
		if(!empty($price1)) {
			$parameter[] = $price1;
			$wherearr[] = 'it618_uprice>=%d';
		}
		if(!empty($price2)) {
			$parameter[] = $price2;
			$wherearr[] = 'it618_uprice<=%d';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $it618_name = '', $price1 = 0, $price2 = 0) {
		$condition = $this->make_query_condition1($it618sql, $it618orderby, $it618_name, $price1, $price2);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $price1 = 0, $price2 = 0) {
		$condition = $this->make_query_condition1($it618sql, $it618orderby, $it618_name, $price1, $price2);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]", $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition1($it618sql = '', $it618orderby = '', $it618_name = '', $price1 = 0, $price2 = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$tmparr=explode(" ",$it618_name);
			for($n=0;$n<count($tmparr);$n++){
				$parameter[] = '%'.$tmparr[$n].'%';
				$tmpsql.='(g.it618_name LIKE %s) and';
			}
			$tmpsql.='@';
			$tmpsql=str_replace(" and@","",$tmpsql);
			$wherearr[] = $tmpsql;
		}
		if(!empty($price1)) {
			$parameter[] = $price1;
			$wherearr[] = 'g.it618_uprice>=%f';
		}
		if(!empty($price2)) {
			$parameter[] = $price2;
			$wherearr[] = 'g.it618_uprice<=%f';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function update_it618_views_by_id($id) {
		DB::query("UPDATE %t SET it618_views=it618_views+1 WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_it618_salecount_by_id($id,$it618_count) {
		DB::query("UPDATE %t SET it618_salecount=%d WHERE id=%d", array($this->_table, $it618_count, $id));
	}
}
//From: Dism��taobao��com
?>