<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_waimai_sale extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_waimai_sale';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_it618_pid($it618_pid) {
		$tmp = DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_pid=%d", array($this->_table, $it618_pid));
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function sumcountcount_by_it618_pid($it618_pid) {
		$tmp = DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_pid=%d AND it618_state=1", array($this->_table, $it618_pid));
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function sumcountcount_by_it618_pid1($it618_pid) {
		$tmp = DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_pid=%d", array($this->_table, $it618_pid));
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function sumcountcount_by_it618_shopid($it618_shopid) {
		$tmp = DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_shopid=%d AND it618_state=1", array($this->_table, $it618_shopid));
		if($tmp=='')return 0; else return $tmp;
	}
	
	public function update_it618_state_by_gwcid($gwcid) {
		DB::query("UPDATE %t SET it618_state=1 WHERE it618_gwcid=%d", array($this->_table, $gwcid));
	}
	
	public function sumcount_by_it618_gtypeid($gtypeid) {
		return DB::result_first("SELECT SUM(it618_count) FROM %t WHERE it618_gtypeid=%d", array($this->_table, $gtypeid));
	}
	
	public function count_by_it618_pj_pid($it618_pj,$it618_pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=%d AND it618_pid=%d", array($this->_table, $it618_pj, $it618_pid));
	}
	
	public function count_pj_by_pid($it618_pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj>0 AND it618_pid=%d", array($this->_table, $it618_pid));
	}
	
	public function count_by_pj_shopid($it618_pj,$it618_shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=%d AND it618_shopid=%d", array($this->_table, $it618_pj, $it618_shopid));
	}
	
	public function count_by_it618_pj_shopid($it618_shopid) {
		$pj1 = DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=1 AND it618_shopid=%d", array($this->_table, $it618_shopid));
		$pj3 = DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=3 AND it618_shopid=%d", array($this->_table, $it618_shopid));
		
		$pj = $pj1-$pj3;
		if($pj>0){
			return $pj;
		}else{
			return 0;
		}
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_pid_by_gwcid_goods($gwcid) {
		return DB::result_first("SELECT it618_pid FROM %t WHERE it618_gwcid=%d ORDER BY it618_price DESC", array($this->_table, $gwcid));
	}
	
	public function fetch_uid_by_id($id) {
		return DB::result_first("SELECT it618_uid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_username_by_uid($uid) {
		return DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_member')." WHERE uid=%d", array($uid));
	}
	
	public function count_by_name($name) {
		return DB::result_first("SELECT COUNT(1) FROM ".DB::table('common_block')." WHERE name=%s", array($name));
	}
	
	public function update_summary_dateline_by_name($summary, $dateline, $name) {
		DB::query("update ".DB::table('common_block')." set summary=%s, dateline=%d WHERE name=%s", array($summary, $dateline, $name));
	}
	
	public function fetch_all_by_search($start = 0, $limit = 0) {
		return DB::fetch_all("SELECT * FROM %t ORDER BY id DESC".DB::limit($start, $limit), array($this->_table));
	}
	
	public function fetch_all_by_it618_gwcid($gwcid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_gwcid=%d ORDER BY id DESC", array($this->_table,$gwcid));
	}
	
	public function count_by_it618_shopid_pj($pj, $it618_shopid) {
		if($pj==0){
			return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj>0 AND it618_shopid=%d", array($this->_table, $it618_shopid));
		}else{
			return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=%d AND it618_shopid=%d", array($this->_table, $pj, $it618_shopid));
		}
	}
	
	public function fetch_all_by_it618_shopid_pj($pj, $it618_shopid, $start = 0, $limit = 0) {
		if($pj==0){
			return DB::fetch_all("SELECT * FROM %t WHERE it618_pj>0 AND it618_shopid=%d ORDER BY id DESC".DB::limit($start, $limit), array($this->_table,$it618_shopid));
		}else{
			return DB::fetch_all("SELECT * FROM %t WHERE it618_pj=%d AND it618_shopid=%d ORDER BY id DESC".DB::limit($start, $limit), array($this->_table, $pj, $it618_shopid));
		}
	}
	
	public function count_by_it618_pid_pj($pj, $it618_pid) {
		if($pj==0){
			return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj>0 AND it618_pid=%d", array($this->_table, $it618_pid));
		}else{
			return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pj=%d AND it618_pid=%d", array($this->_table, $pj, $it618_pid));
		}
	}
	
	public function fetch_all_by_it618_pid_pj($pj, $it618_pid, $start = 0, $limit = 0) {
		if($pj==0){
			return DB::fetch_all("SELECT * FROM %t WHERE it618_pj>0 AND it618_pid=%d ORDER BY id DESC".DB::limit($start, $limit), array($this->_table,$it618_pid));
		}else{
			return DB::fetch_all("SELECT * FROM %t WHERE it618_pj=%d AND it618_pid=%d ORDER BY id DESC".DB::limit($start, $limit), array($this->_table, $pj, $it618_pid));
		}
	}
	
	public function fetch_extcredits_by_uid($creditindex,$uid) {
		return DB::result_first("select extcredits%d from ".DB::table('common_member_count')." where uid=%d", array($creditindex,$uid));
	}
	
	public function fetch_lastactivity_by_uid($uid) {
		return DB::result_first("SELECT lastactivity FROM ".DB::table('common_member_status')." WHERE uid=%d", array($uid));
	}
	
	public function update_lastactivity_by_uid($lastactivity,$uid) {
		DB::query("UPDATE ".DB::table('common_member_status')." SET lastactivity=%d WHERE uid=%d", array($lastactivity, $uid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism��taobao��com
?>