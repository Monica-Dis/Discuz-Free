<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_waimai_collect extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_waimai_collect';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d", array($this->_table,$uid));
	}
	
	public function count_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table,$shopid));
	}
	
	public function count_by_uid_shopid($uid,$shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d AND it618_shopid=%d", array($this->_table,$uid,$shopid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_all_by_search() {
		return DB::fetch_all("SELECT * FROM %t", array($this->_table));
	}
	
	public function fetch_all_by_uid($uid, $start = 0, $limit = 0) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_uid=%d ".DB::limit($start, $limit), array($this->_table,$uid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_uid_shopid($uid,$shopid) {
		DB::query("DELETE FROM %t WHERE it618_uid=%d AND it618_shopid=%d", array($this->_table,$uid,$shopid));
	}
}
//From: Dism��taobao��com
?>