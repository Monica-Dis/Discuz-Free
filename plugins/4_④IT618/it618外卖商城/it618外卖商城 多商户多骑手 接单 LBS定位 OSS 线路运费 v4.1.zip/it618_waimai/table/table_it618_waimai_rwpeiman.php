<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_waimai_rwpeiman extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_waimai_rwpeiman';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_uid($it618_uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d", array($this->_table, $it618_uid));
	}
	
	public function fetch_by_search() {
		return DB::fetch_first("SELECT * FROM %t", array($this->_table));
	}
	
	public function fetch_name_by_id($id) {
		return DB::result_first("SELECT it618_name FROM %t WHERE id=%d",array($this->_table, $id));
	}
	
	public function fetch_it618_state_by_it618_uid($it618_uid) {
		return DB::result_first("SELECT it618_state FROM %t WHERE it618_uid=%d",array($this->_table, $it618_uid));
	}
	
	public function update_it618_state_by_id($id,$it618_state) {
		DB::query("UPDATE %t SET it618_state=%d WHERE id=%d", array($this->_table, $it618_state, $id));
	}
	
	public function update_it618_clockstate_by_id($id,$it618_clockstate) {
		DB::query("UPDATE %t SET it618_clockstate=%d WHERE id=%d", array($this->_table, $it618_clockstate, $id));
	}
	
	public function update_it618_uid_by_id($id,$it618_uid) {
		DB::query("UPDATE %t SET it618_uid=%d WHERE id=%d", array($this->_table, $it618_uid, $id));
	}
	
	public function count_by_it618_uid_ok($it618_uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_clockstate=0 AND it618_uid=%d", array($this->_table, $it618_uid));
	}
	
	public function count_by_it618_uid($it618_uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d", array($this->_table, $it618_uid));
	}
	
	public function count_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $it618_name, $it618_uid);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "(it618_name LIKE %s OR it618_addr LIKE %s)";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}
//From: Dism��taobao��com
?>