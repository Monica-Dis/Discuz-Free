<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return;

loadcache('plugin');
$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function/it618_waimai.func.php';

if($reabc[9]!='m')return;
$ppp = $it618_waimai['pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=15;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<=30;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[0]=$it618_waimai_lang['s92'];
$strtmptitle[1]=$it618_waimai_lang['s93'];
$strtmptitle[2]=$it618_waimai_lang['s77'];
$strtmptitle[3]=$it618_waimai_lang['s1841'];
$strtmptitle[4]=$it618_waimai_lang['t514'];
$strtmptitle[6]=$it618_waimai_lang['s1286'];
$strtmptitle[7]=$it618_waimai_lang['s1374'];
$strtmptitle[8]=$it618_waimai_lang['s100'];
$strtmptitle[10]=$it618_waimai_lang['s560'];
$strtmptitle[11]=$it618_waimai_lang['s600'];
$strtmptitle[12]=$it618_waimai_lang['s632'];
$strtmptitle[13]=$tmplevelarr[0].$it618_waimai_lang['s783'];
$strtmptitle[14]=$tmplevelarr[1].$it618_waimai_lang['s783'];
$strtmptitle[15]=$it618_waimai_lang['s784'];
$strtmptitle[16]=$it618_waimai_lang['s785'];
$strtmptitle[17]=$it618_waimai_lang['s786'];
$strtmptitle[18]=$it618_waimai_lang['s787'];
$strtmptitle[19]=$it618_waimai_lang['s788'];
$strtmptitle[20]=$it618_waimai_lang['s789'];
$strtmptitle[23]=$it618_waimai_lang['s896'];
$strtmptitle[24]=$it618_waimai_lang['s1792'];
$strtmptitle[26]=$it618_waimai_lang['s1082'];
$strtmptitle[28]=$it618_waimai_lang['s1845'];
$strtmptitle[29]=$it618_waimai_lang['s1978'];
$strtmptitle[30]=$it618_waimai_lang['s198'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[15].'><a href="'.$hosturl.'plugins&cp=admin_hot&cp1=15'.$urls.'"><span>'.$strtmptitle[15].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_yytime&cp1=2'.$urls.'"><span>'.$strtmptitle[2].'</span></a></li>
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=1'.$urls.'"><span>'.$strtmptitle[1].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=3'.$urls.'"><span>'.$strtmptitle[3].'</span></a></li>
<li '.$strtmp[6].'><a href="'.$hosturl.'plugins&cp=admin_nav&cp1=6'.$urls.'"><span>'.$strtmptitle[6].'</span></a></li>
<li '.$strtmp[7].'><a href="'.$hosturl.'plugins&cp=admin_gonggao&cp1=7'.$urls.'"><span>'.$strtmptitle[7].'</span></a></li>
<li '.$strtmp[20].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=20'.$urls.'"><span>'.$strtmptitle[20].'</span></a></li>
<li '.$strtmp[24].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=24'.$urls.'"><span>'.$strtmptitle[24].'</span></a></li>
<li '.$strtmp[26].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=26'.$urls.'"><span>'.$strtmptitle[26].'</span></a></li>
<li '.$strtmp[16].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=16'.$urls.'"><span>'.$strtmptitle[16].'</span></a></li>
<li '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=8'.$urls.'"><span>'.$strtmptitle[8].'</span></a></li>
<li '.$strtmp[30].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=30'.$urls.'"><span>'.$strtmptitle[30].'</span></a></li>
<li '.$strtmp[17].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=17'.$urls.'"><span>'.$strtmptitle[17].'</span></a></li>
<li '.$strtmp[18].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=18'.$urls.'"><span>'.$strtmptitle[18].'</span></a></li>
<li '.$strtmp[19].'><a href="'.$hosturl.'plugins&cp=admin_focus&cp1=19'.$urls.'"><span>'.$strtmptitle[19].'</span></a></li>
<li '.$strtmp[10].'><a href="'.$hosturl.'plugins&cp=admin_diy&cp1=10'.$urls.'"><span>'.$strtmptitle[10].'</span></a></li>
<li '.$strtmp[11].'><a href="'.$hosturl.'plugins&cp=admin_rewrite&cp1=11'.$urls.'"><span>'.$strtmptitle[11].'</span></a></li>
<li '.$strtmp[12].'><a href="'.$hosturl.'plugins&cp=admin_message&cp1=12'.$urls.'"><span>'.$strtmptitle[12].'</span></a></li>
<li '.$strtmp[13].'><a href="'.$hosturl.'plugins&cp=admin_level&cp1=13'.$urls.'"><span>'.$strtmptitle[13].'</span></a></li>
<li '.$strtmp[14].'><a href="'.$hosturl.'plugins&cp=admin_level&cp1=14'.$urls.'"><span>'.$strtmptitle[14].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_rwpmtcbl&cp1=4'.$urls.'"><span style="color:red">'.$strtmptitle[4].'</span></a></li>
<li '.$strtmp[23].'><a href="'.$hosturl.'plugins&cp=admin_txbl&cp1=23'.$urls.'"><span>'.$strtmptitle[23].'</span></a></li>
<li '.$strtmp[28].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=28'.$urls.'"><span>'.$strtmptitle[28].'</span></a></li>
<li '.$strtmp[29].'><a href="'.$hosturl.'plugins&cp=admin_aliyunoss&cp1=29'.$urls.'"><span>'.$strtmptitle[29].'</span></a></li>
</ul></div>';

$cparray = array('admin_hot','admin_yytime', 'admin_set', 'admin_nav', 'admin_gonggao', 'admin_focus', 'admin_pay', 'admin_diy', 'admin_rewrite', 'admin_message', 'admin_level', 'admin_rwpmtcbl', 'admin_kdarea', 'admin_txbl', 'admin_aliyunoss');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_hot' : $_GET['cp'];

if($cp1==0)$setname='topnav';
if($cp1==1)$setname='rzabout';
if($cp1==3)$setname='sqpmabout';
if($cp1==15)$setname='hotclasswaimai';
if($cp1==20)$setname='waimaifooter';
if($cp1==24)$setname='wapfooter';
if($cp1==26)$setname='goodscontent';
if($cp1==28)$setname='waphomead';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();/*Dism_taobao-com*/
?>