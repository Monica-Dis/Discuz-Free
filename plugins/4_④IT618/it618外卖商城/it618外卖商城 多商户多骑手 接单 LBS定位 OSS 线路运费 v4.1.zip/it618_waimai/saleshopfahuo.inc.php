<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';

$gwcid=intval($_GET['gwcid']);

if(!($it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($gwcid))){
	echo 'alertit618_split'.it618_waimai_getlang('s1110');exit;
}

$tmpstr=$it618_waimai_lang['s1164'];
if($it618_waimai_gwcsale_main['it618_rwpmid']>0){
	$tmpstr=$it618_waimai_lang['s1165'];
}

$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
$username=it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']);

$salecopystr=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1124'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['id']."\n";
	
$salecopystr.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1125'].$it618_waimai_lang['s1152'].$it618_waimai_waimai['it618_name']."\n";

$salecopystr.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1134'].$it618_waimai_lang['s1152'].$username.' '.$it618_waimai_gwcsale_main['it618_tel'].' '.$it618_waimai_gwcsale_main['it618_name']."\n";

$salecopystr.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1119'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_lbsaddr'].' '.$it618_waimai_gwcsale_main['it618_addr']."\n";

if($it618_waimai_gwcsale_main['it618_bz']!='')$salecopystr.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1108'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_bz']."\n";

$salecopystr.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1135'].$it618_waimai_lang['s1152'].date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time'])."\n";

$salecopystr.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1127'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_money']."\n";

if($it618_waimai_gwcsale_main['it618_money']>0)$salecopystr.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1105'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_money']."\n";

$salecopystr.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1128'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_yunfei']."\n";

$salecopystr.="---------------------------------------------------\n";

foreach(C::t('#it618_waimai#it618_waimai_sale')->fetch_all_by_it618_gwcid($gwcid) as $it618_waimai_sale) {
	$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($it618_waimai_sale['it618_pid']);
	
	$gtypename='';
	if($it618_waimai_sale['it618_gtypeid']>0){
		$gtypename1 = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_it618_name_by_id($it618_waimai_sale['it618_gtypeid']);
		$gtypename = '<font color=red>'.$gtypename1.'</font> ';
		
		$it618_waimai_goods_type = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_by_id($it618_waimai_sale['it618_gtypeid']);
		$it618_uprice=$it618_waimai_goods_type['it618_uprice'];
		$it618_zsscore=$it618_waimai_goods_type['it618_zsscore'];
	}else{
		$it618_uprice=$it618_waimai_goods['it618_uprice'];
		$it618_zsscore=$it618_waimai_goods['it618_zsscore'];
	}
	
	$salecopystr.=$it618_waimai_lang['s1151'].$it618_waimai_goods['it618_name'].' '.$gtypename1.$it618_waimai_lang['s1152'].' '.$it618_waimai_lang['s1142'].$it618_waimai_sale['it618_count'].' '.$it618_waimai_lang['s1143'].$it618_uprice."\n";
}

$tmparr=explode(",",$it618_waimai_waimai['it618_rwpmids']);
for($i=0;$i<count($tmparr);$i++){
	$pmuid=intval($tmparr[$i]);
	if($rwpeimantmp=C::t('#it618_waimai#it618_waimai_rwpeiman')->fetch_by_uid($pmuid)){
		$selected='';
		if($rwpeimantmp['it618_pmid']==$it618_waimai_gwcsale_main['it618_rwpmid']){
			$selected='selected="selected"';
		}
		$usernametmp=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$pmuid);
		$peimenstr.='<option value="'.$rwpeimantmp['id'].'" '.$selected.'>'.$rwpeimantmp['id'].'-'.$rwpeimantmp['it618_name'].'-'.$usernametmp.'('.$pmuid.')</option>';
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_waimai:saleshopfahuo');
?>