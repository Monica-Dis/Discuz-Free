<?php


/* --------------------[Dism.Taobao.Com Addon]--------------------

  @ Copyright - Dism.Taobao.Com
  @ 
  @ The application developed by Dism.Taobao.Com, please do not in the case of not authorized to modify changes including the content, the offenders.
  @ 
  @ Url - Dism.Taobao.com  *  dism.taobao.com  *  Email - Dism.taobao.com

 ----------------------[Dism.Taobao.Com Addon]--------------------*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_bg_setting`;
CREATE TABLE `cdb_bg_setting` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `fid` int(6) NOT NULL,
  `imgurl` varchar(255) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `xrepeat` smallint(1) NOT NULL DEFAULT '0',
  `yrepeat` smallint(1) NOT NULL DEFAULT '0',
  `xcenter` smallint(1) NOT NULL DEFAULT '0',
  `posts` smallint(1) NOT NULL DEFAULT '0',
  `fixed` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `cdb_gbg_setting`;
CREATE TABLE `cdb_gbg_setting` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `fid` int(6) NOT NULL,
  `imgurl` varchar(255) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `xrepeat` smallint(1) NOT NULL DEFAULT '0',
  `yrepeat` smallint(1) NOT NULL DEFAULT '0',
  `xcenter` smallint(1) NOT NULL DEFAULT '0',
  `posts` smallint(1) NOT NULL DEFAULT '0',
  `fixed` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;
runquery($sql);

$identifier = 'qzom_bg';

$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
@unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');


$finish = TRUE;
?>