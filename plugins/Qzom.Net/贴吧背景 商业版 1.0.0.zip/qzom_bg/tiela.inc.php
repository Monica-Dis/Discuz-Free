<?php


/* --------------------[Dism.Taobao.Com Addon]--------------------

  @ Copyright - Dism.Taobao.Com
  @ 
  @ The application developed by Dism.Taobao.Com, please do not in the case of not authorized to modify changes including the content, the offenders.
  @ 
  @ Url - Dism.Taobao.com  *  dism.taobao.com  *  Email - Dism.taobao.com

 ----------------------[Dism.Taobao.Com Addon]--------------------*/


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
 echo '
<iframe width="98%" height="700"  scrolling="yes"  frameborder=no src="http://t.cn/Aiux1Qh0" ></iframe>
 ';
?>