﻿<?php


/* --------------------[Dism.Taobao.Com Addon]--------------------

  @ Copyright - Dism.Taobao.Com
  @ 
  @ The application developed by Dism.Taobao.Com, please do not in the case of not authorized to modify changes including the content, the offenders.
  @ 
  @ Url - Dism.Taobao.com  *  dism.taobao.com  *  Email - Dism.taobao.com

 ----------------------[Dism.Taobao.Com Addon]--------------------*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `cdb_bg_setting`;
DROP TABLE IF EXISTS `cdb_gbg_setting`;
EOF;

runquery($sql);

if(!function_exists('cloudaddons_deltree')) require libfile('function/cloudaddons');
cloudaddons_deltree($DISCUZ_ROOT .'./source/plugin/qzom_bg/');

$finish = TRUE;
?>