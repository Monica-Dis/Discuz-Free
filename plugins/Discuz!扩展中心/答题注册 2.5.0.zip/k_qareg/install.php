<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_plugin_k_qareg`;
CREATE TABLE IF NOT EXISTS `pre_plugin_k_qareg` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `q` varchar(254) NOT NULL COMMENT '题目',
  `answer` varchar(254) NOT NULL COMMENT '答案',
  `a1` varchar(254) NOT NULL COMMENT '选项',
  `a2` varchar(254) NOT NULL,
  `a3` varchar(254) NOT NULL,
  `a4` varchar(254) NOT NULL,
  `a5` varchar(254) NOT NULL,
  `answers` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM
EOF;

runquery($sql);
$finish = TRUE;