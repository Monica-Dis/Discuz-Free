<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$op = in_array($_GET['op'], array('list', 'edit', 'add')) ? $_GET['op'] : 'list';

if($op == 'list'){
	if(!submitcheck('adminsubmit')) {
		$perpage = 20;
		$page = intval ( $_GET ['page'] );
		$start = ($page - 1) * $perpage;
		if (empty ($page)){
			$page = 1;
		}
		if ($start < 0){
			$start = 0;
		}
		$multi = '';
		$count =  0;
		$count = C::t("#k_qareg#plugin_k_qareg")->count();
		
		$qs = C::t("#k_qareg#plugin_k_qareg")->fetch_all($start, $perpage);
		
		foreach($qs as $key => $value){
			$qlist .= showtablerow('', array('', 'class="td29"', 'class="td25"', 'class="td25"'), array(
					"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[$value[id]]\" value=\"$value[id]\">",
					$value['q'],
					count(unserialize($value['answer'])) > 1 ? lang('plugin/k_qareg', 'type_multi') : lang('plugin/k_qareg', 'type_radio'),
					'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=k_qareg&pmod=cp_ask&op=edit&id='.$value['id'].'">'.$lang['detail'].'</a>', 
				), TRUE);
		}
		
		$multi = multi($count, $perpage, $page, "?action=plugins&operation=config&do=".$do."&identifier=k_qareg&pmod=cp_ask" );
	
		showformheader('plugins&operation=config&do='.$do.'&identifier=k_qareg&pmod=cp_ask');
		showtableheader(lang('plugin/k_qareg', 'askku'), 'fixpadding', 'id="int"');
		showsubtitle(array('', lang('plugin/k_qareg', 'ask'), lang('plugin/k_qareg', 'type')));
		echo $qlist;
		echo '<tr><td>&nbsp;</td><td colspan="8"><div><a href="?action=plugins&operation=config&do='.$do.'&identifier=k_qareg&pmod=cp_ask&op=add" class="addtr">'.lang('plugin/k_qareg', 'addnew').'</a></div></td></tr>';
		showsubmit('adminsubmit', 'submit', 'del', '', $multi);
		showtablefooter(); //Dism��taobao��com
		showformfooter(); //Dism_taobao_com
	} else {
		if(is_array($_GET['delete'])) {
			foreach($_GET['delete'] as $id) {
				C::t('#k_qareg#plugin_k_qareg')->delete(intval($id));
			}
		}
		cpmsg(lang('plugin/k_qareg', 'success'), "action=plugins&operation=config&do=".$do."&identifier=k_qareg&pmod=cp_ask", 'succeed');
	}
}elseif($op == 'add'){
	if(!submitcheck('addsubmit')) {
		showformheader('plugins&operation=config&do='.$do.'&identifier=k_qareg&pmod=cp_ask&op=add');
		showtips(lang('plugin/k_qareg', 'addtip'));
		showtableheader(lang('plugin/k_qareg', 'addnew'), 'fixpadding', 'id="int"');
		showsetting(lang('plugin/k_qareg', 'ask'), '', '', "<input type=\"text\" class=\"txt\" value=\"".$q['q']."\" name=\"q\" style=\"width:500px;\"/>", 0, '', '', '', '', true);
		echo '</tbody><tbody id="answers">';
		for($i=1;$i<11;$i++){
			$a = "<input type=\"checkbox\" name=\"answer[$i]\"  value=\"$i\" class=\"checkbox\"/>";
			$a .= "<input type=\"text\" class=\"txt\" name=\"answers[$i]\"/>";
			showsetting('', '', '', "$a", 0, '', '', '', '', true);
		}
		echo '</tbody><tbody>';
		showsubmit('addsubmit', 'submit');
		showtablefooter(); //Dism��taobao��com
		showformfooter(); //Dism_taobao_com
		echo '<style type="text/css">#answers tr {display:none;}#answers tr.noborder {display:table-row;}</style>';
	}else{
		$_GET['answers'] = array_filter($_GET['answers']);
		$_GET['answer'] = array_filter($_GET['answer']);
		foreach($_GET['answer'] as $i => $v){
			if(!$_GET['answers'][$i])unset($_GET['answer'][$i]);
		}
		$insertdata =array(
			'q' => addslashes($_GET['q']),
			'answers' => serialize($_GET['answers']),
			'answer' => serialize($_GET['answer']),
		);
		C::t("#k_qareg#plugin_k_qareg")->insert($insertdata);
		cpmsg(lang('plugin/k_qareg', 'success'), "action=plugins&operation=config&do=".$do."&identifier=k_qareg&pmod=cp_ask", 'succeed');
	}
}elseif($op == 'edit'){
	$id = intval($_GET['id']);
	$q = C::t("#k_qareg#plugin_k_qareg")->fetch($id);
	if(!$q){
		cpmsg(lang('plugin/k_qareg', 'error_q_noexist'), "action=plugins&operation=config&do=".$do."&identifier=k_qareg&pmod=cp_ask", 'error');
	}
	if(!submitcheck('editsubmit')) {
		$q['answer'] = unserialize($q['answer']);
		$q['answers'] = unserialize($q['answers']);
		showformheader('plugins&operation=config&do='.$do.'&identifier=k_qareg&pmod=cp_ask&op=edit&id='.$id);
		showtips(lang('plugin/k_qareg', 'addtip'));
		showtableheader(lang('plugin/k_qareg', 'edit'), 'fixpadding', 'id="int"');
		showsetting(lang('plugin/k_qareg', 'ask'), '', '', "<input type=\"text\" class=\"txt\" value=\"".$q['q']."\" name=\"q\" style=\"width:500px;\"/>", 0, '', '', '', '', true);
		echo '</tbody><tbody id="answers">';
		for($i=1;$i<11;$i++){
			$a = "<input type=\"checkbox\" name=\"answer[$i]\"  value=\"$i\" class=\"checkbox\" ".($q['answer'][$i] ? 'checked="checked"' : '')."/>";
			$a .= "<input type=\"text\" class=\"txt\" name=\"answers[$i]\" value=\"".$q['answers'][$i]."\"/>";
			showsetting('', '', '', "$a", 0, '', '', '', '', true);
		}
		echo '</tbody><tbody>';
		showsubmit('editsubmit', 'submit');
		showtablefooter(); //Dism��taobao��com
		showformfooter(); //Dism_taobao_com
		echo '<style type="text/css">#answers tr {display:none;}#answers tr.noborder {display:table-row;}</style>';
	}else{
		$_GET['answers'] = array_filter($_GET['answers']);
		$_GET['answer'] = array_filter($_GET['answer']);
		foreach($_GET['answer'] as $i => $v){
			if(!$_GET['answers'][$i])unset($_GET['answer'][$i]);
		}
		$insertdata =array(
			'q' => addslashes($_GET['q']),
			'answers' => serialize($_GET['answers']),
			'answer' => serialize($_GET['answer']),
		);
		C::t("#k_qareg#plugin_k_qareg")->update($id, $insertdata);
		cpmsg(lang('plugin/k_qareg', 'success'), "action=plugins&operation=config&do=".$do."&identifier=k_qareg&pmod=cp_ask", 'succeed');
	}
}