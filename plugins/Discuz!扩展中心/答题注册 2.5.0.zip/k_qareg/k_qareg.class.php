<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_k_qareg {
}

class plugin_k_qareg_member extends plugin_k_qareg {
	function register_bottom() {
		global $_G;
		
		$qareg = $_G['cache']['plugin']['k_qareg'];
		require_once libfile('function/discuzcode');
		$qareg['cantregtips'] = discuzcode($qareg['cantregtips'],0 ,0 ,0);
		if(submitcheck('regsubmit')){
			
		}elseif(!submitcheck('qaregsubmit')){
			dheader('Location:plugin.php?id=k_qareg:k_qareg');
		}else{
			$rightn = $wrongn = 0;
			foreach($_GET['question'] as $qid => $q){
				$qids[] = $qid;
			}
			$qs = DB::fetch_all("SELECT * FROM %t WHERE id IN (%n)", array('plugin_k_qareg', $qids), 'id');
			foreach($_GET['question'] as $qid => $q){
				$qs[$qid]['answer'] = array_keys(unserialize($qs[$qid]['answer']));
				$qs[$qid]['answernum'] = count($qs[$qid]['answer']);
				$qr = array_keys($q);
				if($q == $qs[$qid]['answer']){
					$rightn++;
				}else{
					$wrongn++;
				}
			}
			if($rightn >= $qareg['canregnum']){
				
			}else{
				showmessage($qareg['cantregtips']);
			}
		}
		return '';
	}
}

class mobileplugin_k_qareg {
}

class mobileplugin_k_qareg_member extends mobileplugin_k_qareg {
	function register_qareg() {
		global $_G;
		
		$qareg = $_G['cache']['plugin']['k_qareg'];
		if(!$qareg['mobilestatus'])return '';
		require_once libfile('function/discuzcode');
		$qareg['cantregtips'] = discuzcode($qareg['cantregtips'],0 ,0 ,0);
		
		if(submitcheck('regsubmit')){
			
		}elseif(!submitcheck('qaregsubmit')){
			dheader('Location:plugin.php?id=k_qareg:k_qareg');
		}else{
			$rightn = $wrongn = 0;
			foreach($_GET['question'] as $qid => $q){
				$qids[] = $qid;
			}
			$qs = DB::fetch_all("SELECT * FROM %t WHERE id IN (%n)", array('plugin_k_qareg', $qids), 'id');
			foreach($_GET['question'] as $qid => $q){
				$qs[$qid]['answer'] = array_keys(unserialize($qs[$qid]['answer']));
				$qs[$qid]['answernum'] = count($qs[$qid]['answer']);
				$qr = array_keys($q);
				if($q == $qs[$qid]['answer']){
					$rightn++;
				}else{
					$wrongn++;
				}
			}
			if($rightn >= $qareg['canregnum']){
				
			}else{
				showmessage($qareg['cantregtips']);
			}
		}
		return '';
	}
}