<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_ADMINCP')) exit('Access Denied');

$sql = <<<EOF
DROP TABLE IF EXISTS pre_plugin_bus_line;
CREATE TABLE IF NOT EXISTS pre_plugin_bus_line (
  lineid int(11) NOT NULL AUTO_INCREMENT,
  relatedlineid int(11) NOT NULL,
  linename varchar(255) NOT NULL,
  linetype varchar(1) NOT NULL,
  price decimal(10,2) NOT NULL,
  highestprice decimal(10,2) NOT NULL,
  airprice decimal(10,2) NOT NULL,
  cardzhe decimal(10,1) NOT NULL,
  starttime time NOT NULL,
  endtime time NOT NULL,
  startstation int(11) NOT NULL,
  startstationname varchar(255) NOT NULL,
  endstation int(11) NOT NULL,
  endstationname varchar(255) NOT NULL,
  spacing int(11) NOT NULL,
  message text NOT NULL,
  updatetime int(11) NOT NULL,
  PRIMARY KEY (lineid),
  KEY relatedlineid (relatedlineid),
  KEY linename (linename),
  KEY linetype (linetype),
  KEY startstation (startstation,endstation)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS pre_plugin_bus_ls;
CREATE TABLE IF NOT EXISTS pre_plugin_bus_ls (
  lsid int(11) NOT NULL AUTO_INCREMENT,
  lineid int(11) NOT NULL,
  stationid int(11) NOT NULL,
  stationname varchar(255) NOT NULL,
  displayorder tinyint(3) NOT NULL,
  PRIMARY KEY (lsid),
  KEY lineid (lineid,stationid)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS pre_plugin_bus_station;
CREATE TABLE IF NOT EXISTS pre_plugin_bus_station (
  stationid int(11) NOT NULL AUTO_INCREMENT,
  stationname varchar(255) NOT NULL,
  zimu varchar(1) NOT NULL,
  lng VARCHAR(20) NOT NULL,
  lat VARCHAR(20) NOT NULL,
  mapzoom SMALLINT(2) NOT NULL,
  PRIMARY KEY (stationid),
  KEY zimu (zimu)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS pre_plugin_bus_announcement;
CREATE TABLE IF NOT EXISTS `pre_plugin_bus_announcement` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL,
  `title` varchar(255) CHARACTER SET gbk NOT NULL,
  `message` text CHARACTER SET gbk NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`aid`),
  KEY `dateline` (`dateline`),
  KEY `type` (`type`)
) ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = TRUE;
?>