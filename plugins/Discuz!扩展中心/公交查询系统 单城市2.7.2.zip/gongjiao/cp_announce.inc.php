<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$op = $_GET['op'];

loadcache('plugin');
$bussetting = $_G['cache']['plugin']['gongjiao'];
require_once libfile('function/core', 'plugin/gongjiao');


if(empty($op)) {
	if(!submitcheck('announcesubmit')) {
		showformheader('plugins&operation=config&do='.$do.'&identifier=gongjiao&pmod=cp_announce');
		showtableheader();
		showsubtitle(array('del', 'subject', 'message', 'announce_type', 'time', ''));
		$announce_type = array(0=>$lang['announce_words'], 1=>$lang['announce_url']);
		$annlist = C::t("#gongjiao#plugin_bus_announcement")->fetch_all();
		foreach ($annlist as $announce) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$announce[aid]\">",
				$announce['title'],
				$announce['type'] ? $announce['message'] : cutstr(strip_tags($announce['message']), 20),
				$announce['type'] ? $announce_type[1] : $announce_type[0],
				dgmdate($announce['dateline'], 'Y-n-j H:i'),
				"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do=".$do."&identifier=gongjiao&pmod=cp_announce&op=edit&aid=$announce[aid]\" $disabled>$lang[edit]</a>"
			));
		}
		echo '<tr><td>&nbsp;</td><td colspan="8"><div><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=gongjiao&pmod=cp_announce&op=add" class="addtr">'.lang('plugin/gongjiao', 'bus_addnewannounce').'</a></div></td></tr>';
		showsubmit('announcesubmit', 'submit', 'select_all');
		showtablefooter();
		showformfooter();/*Dism_taobao-com*/
	} else {

		if(is_array($_GET['delete'])) {
			C::t("#gongjiao#plugin_bus_announcement")->delete($_GET['delete']);
		}
		cpmsg('update_success', "action=plugins&operation=config&do=".$do."&identifier=gongjiao&pmod=cp_announce", 'succeed');

	}
} elseif($op == 'add') {
	if(!submitcheck('addsubmit')) {
		
		showformheader('plugins&operation=config&do='.$do.'&identifier=gongjiao&pmod=cp_announce&op=add');
		showtableheader(lang('plugin/gongjiao', 'bus_addnewannounce'));
		showsetting($lang['subject'], 'newtitle', '', 'htmltext');
		showsetting('announce_type', array('newtype', array(
			array(0, $lang['announce_words']),
			array(1, $lang['announce_url']))), 0, 'mradio');
		showsetting('announce_message', 'newmessage', '', 'textarea');
		showsubmit('addsubmit');
		showtablefooter();
		showformfooter();/*Dism_taobao-com*/

	} else {
		$newtitle = trim($_GET['newtitle']);
		$newmessage = trim($_GET['newmessage']);
		if(!$newtitle || !$newmessage) {
			cpmsg('announce_invalid', '', 'error');
		} else {
			$newmessage = $_GET['newtype'] == 1 ? explode("\n", $_GET['newmessage']) : array(0 => $_GET['newmessage']);
			$data = array(
				'type' => $_GET['newtype'],
				'title' => strip_tags($newtitle, '<u><i><b><font>'),
				'message' => $newmessage[0],
				'dateline' => TIMESTAMP,
			);
			C::t("#gongjiao#plugin_bus_announcement")->insert($data);
			cpmsg('announce_succeed', 'action=plugins&operation=config&do='.$do.'&identifier=gongjiao&pmod=cp_announce', 'succeed');
		}

	}
} elseif($op == 'edit' && $_GET['aid']) {
	$aid = intval($_GET['aid']);
	$announce = C::t("#gongjiao#plugin_bus_announcement")->fetch_by_aid($aid);
	if(!$announce) {
		cpmsg('announce_nonexistence', '', 'error');
	}

	if(!submitcheck('editsubmit')) {
		$b = $i = $u = $colorselect = $colorcheck = '';
		if(preg_match('/<b>(.*?)<\/b>/i', $announce['title'])) {
			$b = 'class="a"';
		}
		if(preg_match('/<i>(.*?)<\/i>/i', $announce['title'])) {
			$i = 'class="a"';
		}
		if(preg_match('/<u>(.*?)<\/u>/i', $announce['title'])) {
			$u = 'class="a"';
		}
		$colorselect = preg_replace('/<font color=(.*?)>(.*?)<\/font>/i', '$1', $announce['title']);
		$colorselect = strip_tags($colorselect);
		$_G['forum_colorarray'] = array(1=>'#EE1B2E', 2=>'#EE5023', 3=>'#996600', 4=>'#3C9D40', 5=>'#2897C5', 6=>'#2B65B7', 7=>'#8F2A90', 8=>'#EC1282');
		if(in_array($colorselect, $_G['forum_colorarray'])) {
			$colorcheck = "style=\"background: $colorselect\"";
		}

		showformheader('plugins&operation=config&do='.$do.'&identifier=gongjiao&pmod=cp_announce&op=edit&aid='.$aid);
		showtableheader();
		showtitle('announce_edit');
		showsetting($lang['subject'], 'newtitle', $announce['title'], 'htmltext');
		showsetting('announce_type', array('typenew', array(
			array(0, $lang['announce_words']),
			array(1, $lang['announce_url'])
		)), $announce['type'], 'mradio');
		showsetting('announce_message', 'messagenew', $announce['message'], 'textarea');
		showsubmit('editsubmit');
		showtablefooter();
		showformfooter();/*Dism_taobao-com*/

	} else {
		$titlenew = trim($_GET['newtitle']);
		$messagenew = trim($_GET['messagenew']);
		if(!$titlenew || !$messagenew) {
			cpmsg('announce_invalid', '', 'error');
		} else {
			$messagenew = $_GET['typenew'] == 1 ? explode("\n", $messagenew) : array(0 => $messagenew);
			C::t("#gongjiao#plugin_bus_announcement")->update($aid, array(
				'title' => strip_tags($titlenew, '<u><i><b><font>'),
				'type' => $_GET['typenew'],
				'message' => $messagenew[0],
				'dateline' => TIMESTAMP,
			));

			cpmsg('announce_succeed', 'action=plugins&operation=config&do='.$do.'&identifier=gongjiao&pmod=cp_announce', 'succeed');
		}
	}
}
//From: dis'.'m.tao'.'bao.com
?>