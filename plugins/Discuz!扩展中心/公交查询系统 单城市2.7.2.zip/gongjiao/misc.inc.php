<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$busseting = $_G['cache']['plugin']['gongjiao'];
$busseting['adminuid'] = explode(',', $busseting['cpuid']);
require_once libfile('function/core', 'plugin/gongjiao');

$op = $_GET['op'];
if($op == 'zimulist'){
	$zimuoptions = '';
	$zimuarray = array('0','A','B','C','D','E','F','G','H','J','K','L','M','N','O','P','Q','R','S','T','W','X','Y','Z');
	$zimu = in_array($_GET['zimu'],$zimuarray) ? $_GET['zimu'] : 0;
	
	foreach($zimuarray as $value){
		$zimuoptions .= "<a href=\"javascript:;\" onclick=\"ajaxget('plugin.php?id=gongjiao:misc&op=stationlist&zimu=".$value."', 'stationlist', 'stationlist', 'Loading...')\">".($value == '0' ? "ALL" : $value)."</a> &nbsp; ";
	}
	
	include template('common/header');
	echo $zimuoptions;
	include template('common/footer');
	exit;
}elseif($op == 'stationlist') {
	$zimu = $_GET['zimu'];
	$stationlist = '';
	$stations = C::t("#gongjiao#plugin_bus_station")->fetch_all($zimu);
	$stationlist = "<ul>";
	foreach($stations as $station) {
		$stationlist .= "<li><input class=\"radio\" type=\"radio\" name=\"stationid\" id=\"stationid_$station[stationid]\" value=\"$station[stationid]\" /><label for=\"stationid_$station[stationid]\">".dhtmlspecialchars($station['stationname'])."</label></li>";
	}
	$stationlist .= "</ul>";
	include template('common/header');
	echo $stationlist;
	include template('common/footer');
	exit;
}elseif($op == 'addlinestation'){
	if(!$_G['uid'] || !in_array($_G['uid'], $busseting['adminuid'])){
		showmessage(lang('plugin/gongjiao', 'bus_msg_meiquanxian'));
	}
	$lineid = intval($_GET['lineid']);
	if(submitcheck('addlinestationsubmit')){
		$stationid = intval($_GET['stationid']);
		$station = C::t("#gongjiao#plugin_bus_station")->fetch_by_stationid($stationid);
		$stationsnumber = C::t("#gongjiao#plugin_bus_ls")->count_by_lineid($lineid);
		$data = array('lineid' => $lineid, 'stationid' => $stationid, 'stationname' => $station['stationname'], 'displayorder' => $stationsnumber+1);
		C::t("#gongjiao#plugin_bus_ls")->insert($data);
		showmessage('gongjiao:success', "plugin.php?id=gongjiao:editline&lineid=".$lineid, array(), array('showdialog' => true, 'locationtime' => true));
	}else{
		include template('gongjiao_addlinestation', '', 'source/plugin/gongjiao/template/'.$bussetting['styles']['pc']);
		exit();
	}
}elseif($op == 'dellinestation'){
	if(!$_G['uid'] || !in_array($_G['uid'], $busseting['adminuid'])){
		showmessage(lang('plugin/gongjiao', 'bus_msg_meiquanxian'));
	}
	$lineid = intval($_GET['lineid']);
	$stationid = intval($_GET['stationid']);
	$lsid = intval($_GET['lsid']);
	$result = C::t("#gongjiao#plugin_bus_ls")->delete($lsid, true);
	include template('common/header_ajax');
	echo $result;
	include template('common/footer_ajax');
	exit;
}elseif($op == 'ajaxstationlist'){
	$do = in_array($_GET['do'], array('insert', 'select')) ? $_GET['do'] : 'select';
	if($do == 'insert'){
		$insertid = addslashes($_GET['insertid']);
	}
	$keyword = addslashes($_GET['keyword']);
	$stationlist = '';
	$stations = C::t("#gongjiao#plugin_bus_station")->fetch_all_by_keyword($keyword);
	$stationlist = "<ul>";
	if(empty($stations)){
		$stationlist .= '<li>'.lang('plugin/gongjiao', 'bus_nodata_fuhe').'</li>';
	}else{
		foreach($stations as $station) {
			$station['stationnameshow'] = str_replace($keyword, "<strong class=\"xi1\">".$keyword."</strong>", dhtmlspecialchars($station['stationname']));
			if($do == 'insert'){
				$stationlist .= "<a href=\"javascript:;\" onclick=\"insertstationtoinput('".$insertid."', '".$station['stationname']."', '".$station['stationid']."')\"><li>".$station['stationnameshow']."</li></a>";
			}elseif($do == 'select'){
				$stationlist .= "<a href=\"plugin.php?id=gongjiao:view&stationid=".$station['stationid']."\"><li>".$station['stationnameshow']."</li></a>";
			}
		}
	}
	$stationlist .= "</ul>";
	include template('common/header_ajax');
	echo $stationlist;
	include template('common/footer_ajax');
	exit;
}elseif($op == 'ajaxlinelist'){
	$keyword = addslashes($_GET['keyword']);
	$stationlist = '';
	$lines = C::t("#gongjiao#plugin_bus_line")->fetch_all_by_keyword($keyword);
	$linelist = "<ul>";
	if(empty($lines)){
		$linelist .= '<li>'.lang('plugin/gongjiao', 'bus_nodata_fuhe').'</li>';
	}else{
		foreach($lines as $line) {
			$line['linename'] = str_replace($keyword, "<strong class=\"xi1\">".$keyword."</strong>", dhtmlspecialchars($line['linename']));
			$linelist .= "<a href=\"plugin.php?id=gongjiao:view&lineid=".$line['lineid']."\"><li>".$line['linename']."</li></a>";
		}
	}
	$linelist .= "</ul>";
	include template('common/header_ajax');
	echo $linelist;
	include template('common/footer_ajax');
	exit;
}elseif($op == 'selectcsstation'){
	$do = in_array($_GET['do'], array('start', 'end')) ? $_GET['do'] : 'start';
	$keyword = addslashes($_GET['keyword']);
	if(defined('IN_MOBILE')){
		$width = 'width:100%;';
	}else{
		$width = 'width:33%;';
	}
	$stationlist = '';
	$stations = C::t("#gongjiao#plugin_bus_station")->fetch_all_by_keyword($keyword);
	$stationlist = "<ul class=\"cl\">";
	if(empty($stations)){
		$stationlist .= '<li>'.lang('plugin/gongjiao', 'bus_nodata_fuhe').'</li>';
	}else{
		foreach($stations as $station) {
			$station['stationnameshow'] = str_replace($keyword, "<strong class=\"xi1\">".$keyword."</strong>", dhtmlspecialchars($station['stationname']));
			if($do == 'start'){
				$stationlist .= "<label for=\"stationid_".$station['stationid']."\"><li class=\"z\" style=\"".$width."\"><input class=\"radio\" type=\"radio\" name=\"startid\" id=\"stationid_".$station['stationid']."\" value=\"".$station['stationid']."\">".$station['stationnameshow']."</li></label>";
			}elseif($do == 'end'){
				$stationlist .= "<label for=\"stationid_".$station['stationid']."\"><li class=\"z\" style=\"".$width."\"><input class=\"radio\" type=\"radio\" name=\"endid\" id=\"stationid_".$station['stationid']."\" value=\"".$station['stationid']."\">".$station['stationnameshow']."</li></label>";
			}
		}
	}
	$stationlist .= "</ul>";
	if(defined('IN_MOBILE')){
		include template('gongjiao_misc_selectcsstation', '', 'source/plugin/gongjiao/template/'.$bussetting['styles']['mobile']);
	}else{
		include template('gongjiao_misc_selectcsstation', '', 'source/plugin/gongjiao/template/'.$bussetting['styles']['pc']);
	}
	exit;
}elseif($op == 'announcement') {
	$aid = intval($_GET['aid']);
	$announce = C::t("#gongjiao#plugin_bus_announcement")->fetch_by_aid($aid);
	if(!$announce) {
		showmessage(lang('plugin/gongjiao', 'bus_msg_meiquanxian'));
	}
	$announce['stitle'] = strip_tags($announce['title']);
	$announce['dateline'] = dgmdate($announce['dateline']);
	
	$navtitle = $announce['stitle'];
	if(defined('IN_MOBILE')){
		include template('gongjiao_misc_announcement', '', 'source/plugin/gongjiao/template/'.$bussetting['styles']['mobile']);
	}else{
		include template('gongjiao_misc_announcement', '', 'source/plugin/gongjiao/template/'.$bussetting['styles']['pc']);
	}
}

$navtitle = $miscnavtitle ? $miscnavtitle : $busseting['title'];
?>