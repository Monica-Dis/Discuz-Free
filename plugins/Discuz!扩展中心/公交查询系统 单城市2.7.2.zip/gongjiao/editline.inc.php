<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$busseting = $_G['cache']['plugin']['gongjiao'];
$busseting['adminuid'] = explode(',', $busseting['cpuid']);
require_once libfile('function/core', 'plugin/gongjiao');

if(!$_G['uid'] || !in_array($_G['uid'], $busseting['adminuid'])){
	showmessage(lang('plugin/gongjiao', 'bus_msg_meiquanxian'));
}
$lineid = intval($_GET['lineid']);
if(submitcheck('editsubmit')){
	if(is_array($_GET['displayorder'])) {
		foreach($_GET['displayorder'] as $lsid => $value) {
			$data = array('displayorder'=>intval($value));
			C::t("#gongjiao#plugin_bus_ls")->update(intval($lsid),$data);
		}
	}
	showmessage('gongjiao:success', "plugin.php?id=gongjiao:editline&lineid=".$lineid, array(), array('showdialog' => true, 'locationtime' => true));
}elseif(submitcheck('editupdatesesubmit')){
	$ls = C::t("#gongjiao#plugin_bus_ls")->fetch_all_by_lineid($lineid);
	$start=current($ls);
	$end=end($ls);
	$data = array('startstation' => $start['stationid'],'startstationname' => $start['stationname'],'endstation' => $end['stationid'],'endstationname' => $end['stationname']);
	C::t("#gongjiao#plugin_bus_line")->update($lineid,$data);
	showmessage('gongjiao:success', "plugin.php?id=gongjiao:editline&lineid=".$lineid, array(), array('showdialog' => true, 'locationtime' => true));
}elseif(submitcheck('edit_copyfrom_submit') || submitcheck('edit_copyfroms_submit')){
	$copyfromlineid = intval($_GET['copyfrom']);
	if(!$copyfromlineid){
		showmessage(lang('plugin/gongjiao', 'bus_msg_plzsccf'));
	}
	$copyfromls = C::t("#gongjiao#plugin_bus_ls")->fetch_all_by_lineid($copyfromlineid);
	if(submitcheck('edit_copyfrom_submit')){
		arsort($copyfromls);
	}
	C::t("#gongjiao#plugin_bus_ls")->delete_by_lineid($lineid);
	$i = 1;
	foreach($copyfromls as $value) {
		C::t("#gongjiao#plugin_bus_ls")->insert(array('lineid' => $lineid, 'stationid' => $value['stationid'], 'stationname' => $value['stationname'], 'displayorder' =>$i ));
		$i++;
	}
	showmessage('gongjiao:success', "plugin.php?id=gongjiao:editline&lineid=".$lineid, array(), array('showdialog' => true, 'locationtime' => true));
}elseif(submitcheck('relatedsubmit')){
	$relatedlineid = intval($_GET['relatedlineid']);
	if(!$relatedlineid){
		showmessage(lang('plugin/gongjiao', 'bus_msg_plzscrl'));
	}
	C::t("#gongjiao#plugin_bus_line")->update($lineid, array('relatedlineid' =>$relatedlineid));
	C::t("#gongjiao#plugin_bus_line")->update($relatedlineid, array('relatedlineid' =>$lineid));
	showmessage('gongjiao:success', "plugin.php?id=gongjiao:editline&lineid=".$lineid, array(), array('showdialog' => true, 'locationtime' => true));
}else{
	$lines = C::t("#gongjiao#plugin_bus_line")->fetch_all();
	$line = C::t("#gongjiao#plugin_bus_line")->fetch_by_lineid($lineid);
	if(!$line){
		showmessage(lang('plugin/gongjiao', 'bus_msg_linenotexit'));
	}
	$ls = C::t("#gongjiao#plugin_bus_ls")->fetch_all_by_lineid($lineid);
	$stationsnum = count($ls);
	$start=current($ls);
	$end=end($ls);
}
$navtitle .= lang('plugin/gongjiao', 'bus_editline')." - ".$line['linename']."[".lang('plugin/gongjiao', 'bus_line_type_'.$line['linetype'])."] - ".$busseting['title'];

if(defined('IN_MOBILE')){
	include template('gongjiao_editline', '', 'source/plugin/gongjiao/template/'.$bussetting['styles']['mobile']);
}else{
	include template('diy:gongjiao_editline', '', 'source/plugin/gongjiao/template/'.$bussetting['styles']['pc']);
}
//From: dis'.'m.tao'.'bao.com
?>