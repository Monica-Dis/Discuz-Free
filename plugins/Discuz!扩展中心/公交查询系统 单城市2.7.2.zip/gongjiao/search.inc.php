<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$busseting = $_G['cache']['plugin']['gongjiao'];
$busseting['adminuid'] = explode(',', $busseting['cpuid']);
require_once libfile('function/core', 'plugin/gongjiao');

$type = in_array($_GET['type'], array('station','line','change')) ? $_GET['type'] : 'station';
if($type == 'station'){
	$keyword = addslashes(stripsearchkey($_GET['C']));
	$stationid = intval($_GET['stationid']);
	$stationlist = array();
	$stationlist = C::t("#gongjiao#plugin_bus_station")->fetch_all_by_keyword($keyword, 0, 999);
	$numbers = count($stationlist);
}elseif($type == 'line'){
	$keyword = addslashes(stripsearchkey($_GET['C']));
	$lineid = intval($_GET['lineid']);
	$linelist = array();
	$lines = C::t("#gongjiao#plugin_bus_line")->fetch_all_by_keyword($keyword, 0, 999);
	$numbers = count($lines);
	foreach($lines as $line){
		$linelist[$line['lineid']] = (array)$line;
		$lsarray[] = $line['lineid'];
	}
	$ls2 = C::t("#gongjiao#plugin_bus_ls")->fetch_all_by_lineid($lsarray);
	foreach($ls2 as $value){
		$linelist[$value['lineid']]['stations'][$value['displayorder']] = (array)$value;
	}
}elseif($type == 'change'){
	$startid = intval($_GET['startid']);
	$endid = intval($_GET['endid']);
	if($startid){
		$startstationname = C::t("#gongjiao#plugin_bus_station")->fetch_by_stationid($startid);
	}
	if($endid){
		$endstationname = C::t("#gongjiao#plugin_bus_station")->fetch_by_stationid($endid);
	}
	if(!$startid || !$endid){
		if(!$startid){
			$startstationname['temp'] = addslashes($_GET['C1']);
			$startstationname['temp2'] = urlencode($startstationname['temp']);
		}
		if(!$endid){
			$endstationname['temp'] = addslashes($_GET['C2']);
			$endstationname['temp2'] = urlencode($endstationname['temp']);
		}
	}
	$startlines = C::t("#gongjiao#plugin_bus_ls")->fetch_all_by_stationid($startid);
	$endlines = C::t("#gongjiao#plugin_bus_ls")->fetch_all_by_stationid($endid);
	foreach($startlines as $startline){
		$zhidatemp = C::t("#gongjiao#plugin_bus_ls")->fetch_all_by_lid_sid_displayorder($startline['lineid'], $endid, $startline['displayorder']);
		if($zhidatemp){
			$zhida[] = $zhidatemp[0]['lineid'];
		}
		$startlinelist[$startline['lineid']] = $startline;
		$startlsarray[] = $startline['lineid'];
	}
	foreach($endlines as $endline){
		$endlinelist[$endline['lineid']] = $endline;
		$endlsarray[] = $endline['lineid'];
	}
	$startls = C::t("#gongjiao#plugin_bus_ls")->fetch_all_by_lineid($startlsarray);
	foreach($startls as $value){
		$startlinelist[$value['lineid']]['stations'][$value['displayorder']] = $value['stationid'];
		$startlinelist[$value['lineid']]['dstations'][$value['stationid']] = $value['displayorder'];
		$startlinelist[$value['lineid']]['stationsname'][$value['displayorder']] = $value['stationname'];
	}
	$endls = C::t("#gongjiao#plugin_bus_ls")->fetch_all_by_lineid($endlsarray);
	foreach($endls as $value){
		$endlinelist[$value['lineid']]['stations'][$value['displayorder']] = $value['stationid'];
		$endlinelist[$value['lineid']]['dstations'][$value['stationid']] = $value['displayorder'];
		$endlinelist[$value['lineid']]['stationsname'][$value['displayorder']] = $value['stationname'];
	}
	foreach($startlinelist as $startvalue){
		foreach($endlinelist as $endvalue){
			$zzz = array_intersect($startvalue['stations'], $endvalue['stations']);
			if($zzz){
				$zzzkey = array_keys($zzz);
				foreach($zzzkey as $zk => $zv){
					$result[] = array(
						'startstationname' => $startvalue['stationname'],
						'endstationname' => $endvalue['stationname'],
						'zzz' => array_intersect($startvalue['stations'], $endvalue['stations']),
						'zzzstationname' => $startlinelist[$startvalue['lineid']]['stationsname'][$zv],
						'startlineid' => $startvalue['lineid'],
						'endlineid' => $endvalue['lineid'],
						'zzzid' => $zzz[$zv],
					);
				}
				$lineidarray[] = $startvalue['lineid'];
				$lineidarray[] = $endvalue['lineid'];
			}
		}
	}
	$lineidarray = array_unique($lineidarray);
	if($lineidarray){
		$lines = C::t("#gongjiao#plugin_bus_line")->fetch_all_by_lineids($lineidarray);
		foreach($lines as $linevalue){
			$linelist[$linevalue['lineid']] = $linevalue;
		}
		foreach($result as $key => $value){
			if(($startlinelist[$value['startlineid']]['dstations'][$startid]/*起点站的排序*/ < $startlinelist[$value['startlineid']]['dstations'][$value['zzzid']]) && ($endlinelist[$value['endlineid']]['dstations'][$endid]/*起点站的排序*/ > $endlinelist[$value['endlineid']]['dstations'][$value['zzzid']])){
				$resultlist[$key] = $value;
			}
		}
	}
	
	shuffle($resultlist);
	
	//不需要换乘的方案
	if($zhida){
		$zhidalines = C::t("#gongjiao#plugin_bus_line")->fetch_all_by_lineids($zhida);
	}
	shuffle($zhidalines);
	$numbers = count($resultlist) + count($zhidalines);
	if($startstationname['stationname'] && $endstationname['stationname']){
		$navtitle .= $startstationname['stationname'].lang('plugin/gongjiao', 'bus_search_change_tip1').$endstationname['stationname'].'&nbsp;'.lang('plugin/gongjiao', 'bus_search_change').' - ';
	}
}

$navtitle .= $busseting['title'];

if(defined('IN_MOBILE')){
	include template('gongjiao_search', '', 'source/plugin/gongjiao/template/'.$bussetting['styles']['mobile']);
}else{
	include template('diy:gongjiao_search', '', 'source/plugin/gongjiao/template/'.$bussetting['styles']['pc']);
}
//From: dis'.'m.tao'.'bao.com
?>