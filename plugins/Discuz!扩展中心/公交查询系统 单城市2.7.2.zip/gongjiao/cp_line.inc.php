<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$busseting = $_G['cache']['plugin']['gongjiao'];
$busseting['adminuid'] = explode(',', $busseting['cpuid']);
require_once libfile('function/core', 'plugin/gongjiao');

$op = in_array($_GET['op'], array('line', 'addline', 'editline')) ? $_GET['op'] : 'line';

if($op == 'line'){
	$perpage = 10;
	$page = intval($_GET['page']);
	$start = ($page-1) * $perpage;
	if(empty($page)){
		$page = 1;
	}
	if($start < 0){
		$start = 0;
	}
	$multi = '';
	$count = 0;
	$count = C::t("#gongjiao#plugin_bus_line")->count();
	$multi = multi($count, $perpage, $page, '?action=plugins&operation=config&do='.$pluginid.'&identifier=gongjiao&pmod=cp_line&op=line');
	
	$linearray = C::t("#gongjiao#plugin_bus_line")->fetch_all($start, $perpage);
	$linetypearray = array('S' => lang('plugin/gongjiao', 'bus_line_type_S'), 'X' => lang('plugin/gongjiao', 'bus_line_type_X'), 'H' => lang('plugin/gongjiao', 'bus_line_type_H'));
	foreach($linearray as $value) {
		$lines .= showtablerow('', array('class="td25"', 'class="td30"', 'class="td25"', 'class="td25"', 'class="td30"', 'class="td30"', 'class="td30"', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[".$value['lineid']."]\" value=\"".$value['lineid']."\">",
			"<input class=\"txt\" type=\"text\" name=\"linenamenew[".$value['lineid']."]\" value=\"".$value['linename']."\">",
			$linetypearray[$value['linetype']],
			"<input class=\"txt\" type=\"text\" name=\"pricenew[".$value['lineid']."]\" value=\"".$value['price']."\">",
			"<input class=\"txt\" type=\"text\" name=\"starttimenew[".$value['lineid']."]\" value=\"".$value['starttime']."\">",
			"<input class=\"txt\" type=\"text\" name=\"endtimenew[".$value['lineid']."]\" value=\"".$value['endtime']."\">",
			"<input class=\"txt\" type=\"text\" name=\"spacingnew[".$value['lineid']."]\" value=\"".$value['spacing']."\">",
			'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=gongjiao&pmod=cp_line&op=editline&lineid='.$value['lineid'].'" class="act">'.lang('plugin/gongjiao', 'set').'</a>&nbsp;<a href="plugin.php?id=gongjiao:view&lineid='.$value['lineid'].'" class="act" target="_blank">'.lang('plugin/gongjiao', 'view').'</a>',
		), TRUE);
	}
	if(!submitcheck('toolsteditsubmit')) {
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=gongjiao&pmod=cp_line&op=line', 'enctype');
		showtableheader(lang('plugin/gongjiao', 'bus_lineset'), 'fixpadding', '');
		showsubtitle(array('', lang('plugin/gongjiao', 'bus_line_name'), lang('plugin/gongjiao', 'bus_line_type'), lang('plugin/gongjiao', 'bus_line_price'), lang('plugin/gongjiao', 'bus_line_starttime'), lang('plugin/gongjiao', 'bus_line_endtime'), lang('plugin/gongjiao', 'bus_line_spacing'), ''));
		echo $lines;
		echo '<tr><td>&nbsp;</td><td colspan="3"><div><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=gongjiao&pmod=cp_line&op=addline" class="addtr">'.lang('plugin/gongjiao', 'bus_addnewline').'</a></div></td></tr>';
		showsubmit('toolsteditsubmit', 'submit', 'del', '', $multi);
		showtablefooter();
		showformfooter();/*Dism_taobao-com*/
	}else{
		if(is_array($_GET['delete'])) {
			foreach($_GET['delete'] as $lineid) {
				C::t("#gongjiao#plugin_bus_line")->delete(intval($lineid));
				C::t("#gongjiao#plugin_bus_ls")->delete_by_lineid(intval($lineid));
			}
		}
		if(is_array($_GET['linenamenew'])) {
			foreach($_GET['linenamenew'] as $lineid => $value) {
				$data = array('price'=>addslashes($_GET['pricenew'][$lineid]),'linename'=>addslashes($value),'starttime'=>addslashes($_GET['starttimenew'][$lineid]),'endtime'=>addslashes($_GET['endtimenew'][$lineid]),'spacing'=>intval($_GET['spacingnew'][$lineid]));
				C::t("#gongjiao#plugin_bus_line")->update(intval($lineid),$data);
			}
		}
		cpmsg('gongjiao:success', "action=plugins&operation=config&do=".$do."&identifier=gongjiao&pmod=cp_line&op=line", 'succeed');
	}
}elseif($op == 'addline'){
	if(!submitcheck('addlinesubmit')) {
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=gongjiao&pmod=cp_line&op=addline', 'enctype');
		showtableheader(lang('plugin/gongjiao', 'bus_addnewline'), 'fixpadding', '');
		showsetting(lang('plugin/gongjiao', 'bus_line_name'), 'namenew', $line['linename'], 'text');
		$type = array('typenew', array(), 'isfloat');
		$type[1][0] = array('S', lang('plugin/gongjiao', 'bus_line_type_S'));
		$type[1][1] = array('X', lang('plugin/gongjiao', 'bus_line_type_X'));
		$type[1][2] = array('H', lang('plugin/gongjiao', 'bus_line_type_H'));
		showsetting(lang('plugin/gongjiao', 'bus_line_type'), $type, $line['linetype'], 'select');
		showsetting(lang('plugin/gongjiao', 'bus_line_price'), 'pricenew', $line['price'], 'text', '', '', lang('plugin/gongjiao', 'bus_rmb_unit'));
		showsetting(lang('plugin/gongjiao', 'bus_line_price_jieti'), 'jietinew', 0, 'radio', '', '1', lang('plugin/gongjiao', 'bus_line_price_jieti_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_price_highest'), 'highestpricenew', $line['highestprice'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_price_highest_tips'));
		showtablefooter();
		showtableheader('', 'fixpadding', '');
		showsetting(lang('plugin/gongjiao', 'bus_line_price_airnew'), 'airnew', 0, 'radio', '', '1', lang('plugin/gongjiao', 'bus_line_price_airnew_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_price_air'), 'airpricenew', $line['airprice'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_price_air_tips'));
		showtablefooter();
		showtableheader('', 'fixpadding', '');
		showsetting(lang('plugin/gongjiao', 'bus_line_price_card'), 'cardnew', $busseting['defaultcard'], 'radio', '', '1', lang('plugin/gongjiao', 'bus_line_price_card_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_price_cardzhe'), 'cardzhenew', $busseting['defaultcardzhe'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_price_cardzhe_tips'));
		showtablefooter();
		showtableheader('', 'fixpadding', '');
		showsetting(lang('plugin/gongjiao', 'bus_line_starttime'), 'starttimenew', $line['starttime'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_starttime_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_endtime'), 'endtimenew', $line['endtime'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_endtime_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_spacing'), 'spacingnew', $line['spacing'], 'number', '', '', lang('plugin/gongjiao', 'bus_line_spacing_unit'));
		showsetting(lang('plugin/gongjiao', 'bus_line_message'), 'messagenew', $line['message'], 'textarea');
		showsubmit('addlinesubmit', 'submit');
		showtablefooter();
		showformfooter();/*Dism_taobao-com*/
	}else{
		$data = array('linetype' => addslashes($_GET['typenew']),'price'=>addslashes($_GET['pricenew']),'linename'=>addslashes($_GET['namenew']),'starttime'=>addslashes($_GET['starttimenew']),'endtime'=>addslashes($_GET['endtimenew']),'spacing'=>intval($_GET['spacingnew']), 'message' => addslashes($_GET['messagenew']), 'updatetime' => $_G['timestamp']);
		if($_GET['jietinew'] == 1){
			$data['highestprice'] = addslashes($_GET['highestpricenew']);
		}else{
			unset($data['highestprice']);
		}
		if($_GET['airnew'] == 1){
			$data['airprice'] = addslashes($_GET['airpricenew']);
		}else{
			unset($data['airprice']);
		}
		if($_GET['cardnew'] == 1){
			$data['cardzhe'] = addslashes($_GET['cardzhenew']);
		}else{
			unset($data['cardzhe']);
		}
		C::t("#gongjiao#plugin_bus_line")->insert($data);
		cpmsg('gongjiao:success', "action=plugins&operation=config&do=".$do."&identifier=gongjiao&pmod=cp_line&op=line", 'succeed');
	}
}elseif($op == 'editline'){
	$lineid = intval($_GET['lineid']);
	$line = C::t("#gongjiao#plugin_bus_line")->fetch_by_lineid($lineid);
	if(!submitcheck('editlinesubmit')) {
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=gongjiao&pmod=cp_line&op=editline&lineid='.$lineid, 'enctype');
		showtableheader(lang('plugin/gongjiao', 'bus_editline'), 'fixpadding', '');
		showsetting(lang('plugin/gongjiao', 'bus_line_name'), 'namenew', $line['linename'], 'text');
		$type = array('typenew', array(), 'isfloat');
		$type[1][0] = array('S', lang('plugin/gongjiao', 'bus_line_type_S'));
		$type[1][1] = array('X', lang('plugin/gongjiao', 'bus_line_type_X'));
		$type[1][2] = array('H', lang('plugin/gongjiao', 'bus_line_type_H'));
		showsetting(lang('plugin/gongjiao', 'bus_line_type'), $type, $line['linetype'], 'select');
		showsetting(lang('plugin/gongjiao', 'bus_line_price'), 'pricenew', $line['price'], 'text', '', '', lang('plugin/gongjiao', 'bus_rmb_unit'));
		showsetting(lang('plugin/gongjiao', 'bus_line_price_jieti'), 'jietinew', ($line['highestprice'] != '0.00' ? 1 : 0), 'radio', '', '1', lang('plugin/gongjiao', 'bus_line_price_jieti_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_price_highest'), 'highestpricenew', $line['highestprice'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_price_highest_tips'));
		showtablefooter();
		showtableheader('', 'fixpadding', '');
		showsetting(lang('plugin/gongjiao', 'bus_line_price_airnew'), 'airnew', ($line['airprice'] != '0.00' ? 1 : 0), 'radio', '', '1', lang('plugin/gongjiao', 'bus_line_price_airnew_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_price_air'), 'airpricenew', $line['airprice'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_price_air_tips'));
		showtablefooter();
		showtableheader('', 'fixpadding', '');
		showsetting(lang('plugin/gongjiao', 'bus_line_price_card'), 'cardnew', ($line['cardzhe'] != '0.0' ? 1 : 0), 'radio', '', '1', lang('plugin/gongjiao', 'bus_line_price_card_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_price_cardzhe'), 'cardzhenew', $line['cardzhe'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_price_cardzhe_tips'));
		showtablefooter();
		showtableheader('', 'fixpadding', '');
		showsetting(lang('plugin/gongjiao', 'bus_line_starttime'), 'starttimenew', $line['starttime'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_starttime_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_endtime'), 'endtimenew', $line['endtime'], 'text', '', '', lang('plugin/gongjiao', 'bus_line_endtime_tips'));
		showsetting(lang('plugin/gongjiao', 'bus_line_spacing'), 'spacingnew', $line['spacing'], 'number', '', '', lang('plugin/gongjiao', 'bus_line_spacing_unit'));
		showsetting(lang('plugin/gongjiao', 'bus_line_message'), 'messagenew', $line['message'], 'textarea');
		showsubmit('editlinesubmit', 'submit');
		showtablefooter();
		showformfooter();/*Dism_taobao-com*/
	}else{
		$data = array('linetype' => addslashes($_GET['typenew']),'price'=>addslashes($_GET['pricenew']),'linename'=>addslashes($_GET['namenew']),'starttime'=>addslashes($_GET['starttimenew']),'endtime'=>addslashes($_GET['endtimenew']),'spacing'=>intval($_GET['spacingnew']), 'message' => addslashes($_GET['messagenew']), 'updatetime' => $_G['timestamp']);
		if($_GET['jietinew'] == 1){
			$data['highestprice'] = addslashes($_GET['highestpricenew']);
		}else{
			$data['highestprice'] = '0.00';
		}
		if($_GET['airnew'] == 1){
			$data['airprice'] = addslashes($_GET['airpricenew']);
		}else{
			$data['airprice'] = '0.00';
		}
		if($_GET['cardnew'] == 1){
			$data['cardzhe'] = addslashes($_GET['cardzhenew']);
		}else{
			$data['cardzhe'] = '0.0';
		}
		C::t("#gongjiao#plugin_bus_line")->update($lineid,$data);
		cpmsg('gongjiao:success', "action=plugins&operation=config&do=".$do."&identifier=gongjiao&pmod=cp_line&op=line", 'succeed');
	}
}
//From: Dism��taobao��com
?>