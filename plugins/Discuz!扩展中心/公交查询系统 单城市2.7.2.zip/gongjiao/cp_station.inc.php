<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$busseting = $_G['cache']['plugin']['gongjiao'];
$busseting['adminuid'] = explode(',', $busseting['cpuid']);
require_once libfile('function/core', 'plugin/gongjiao');

$zimuarray = array('0','A','B','C','D','E','F','G','H','J','K','L','M','N','O','P','Q','R','S','T','W','X','Y','Z');
$zimu = in_array($_GET['zimu'],$zimuarray) ? $_GET['zimu'] : 0;
foreach($zimuarray as $value){
	$zimuoptions .= '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=gongjiao&pmod=cp_station&zimu='.$value.'" class="act">'.($value == '0' ? "ALL" : $value).'</a> &nbsp; ';
}
showtips('<li>'.$zimuoptions.'</li>');
?>
<script type="text/JavaScript">
var rowtypedata = [
	[
		[1, '', 'td25'],
		[1, '<input type="text" class="txt" name="newzimu[]" size="1">', 'td25'],
		[1, '<input type="text" class="txt" name="newstationname[]" size="30" value="">'],
	],
];
</script>
<?php
$perpage = 20;
$page = intval($_GET['page']);
$start = ($page-1) * $perpage;
if(empty($page)){
	$page = 1;
}
if($start < 0){
	$start = 0;
}
$multi = '';
$count = 0;
if($zimu){
	$count = C::t("#gongjiao#plugin_bus_station")->count_by_zimu($zimu);
	$multi = multi($count, $perpage, $page, '?action=plugins&operation=config&do='.$pluginid.'&identifier=gongjiao&pmod=cp_station&zimu='.$zimu);
}else{
	$count = C::t("#gongjiao#plugin_bus_station")->count();
	$multi = multi($count, $perpage, $page, '?action=plugins&operation=config&do='.$pluginid.'&identifier=gongjiao&pmod=cp_station');
}
$stationarray = C::t("#gongjiao#plugin_bus_station")->fetch_all($zimu, $start, $perpage);
foreach($stationarray as $value) {
	$stations .= showtablerow('', array('class="td25"', 'class="td25"', 'class="td29"', 'class="td29"'), array(
		"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[".$value['stationid']."]\" value=\"".$value['stationid']."\">",
		"<input class=\"txt\" type=\"text\" name=\"zimunew[".$value['stationid']."]\" value=\"".$value['zimu']."\">",
		"<input class=\"txt\" type=\"text\" name=\"stationnamenew[".$value['stationid']."]\" value=\"".$value['stationname']."\">",
	), TRUE);
}
if(!submitcheck('toolsteditsubmit')) {
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=gongjiao&pmod=cp_station', 'enctype');
	showtableheader(lang('plugin/gongjiao', 'bus_stationset'), 'fixpadding', '');
	showsubtitle(array('', lang('plugin/gongjiao','bus_fzimu'), lang('plugin/gongjiao', 'bus_stationname')));
	echo $stations;
	echo '<tr><td>&nbsp;</td><td colspan="3"><div><a href="javascript:;" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/gongjiao', 'bus_addnewstation').'</a></div></td></tr>';
	showsubmit('toolsteditsubmit', 'submit', 'del', '', $multi);
	showtablefooter();
	showformfooter();/*Dism_taobao-com*/
}else{
	$ig = 0;
	if(is_array($_GET['delete'])) {
		foreach($_GET['delete'] as $stationid) {
			C::t("#gongjiao#plugin_bus_station")->delete(intval($stationid));
		}
	}
	if(is_array($_GET['stationnamenew'])) {
		foreach($_GET['stationnamenew'] as $stationid => $value) {
			if($value){
				$data = array('zimu'=>addslashes($_GET['zimunew'][$stationid]),'stationname'=>addslashes($value));
				$estation = C::t("#gongjiao#plugin_bus_station")->fetch_by_stationname($value);
				if(!$estation){
					C::t("#gongjiao#plugin_bus_station")->update(intval($stationid),$data);
					C::t("#gongjiao#plugin_bus_ls")->update_by_stationid(intval($stationid),$data['stationname']);
				}else{
					$ig++;
				}
			}
		}
	}
	if(is_array($_GET['newstationname'])) {
		foreach($_GET['newstationname'] as $id => $value) {
			$newdata = array('zimu'=>addslashes($_GET['newzimu'][$id]),'stationname'=>daddslashes($value));
			if(empty($newdata['zimu'])){
				$newdata['zimu'] = chineseFirst($newdata['stationname'], $_G['charset']);
			}
			$estation = C::t("#gongjiao#plugin_bus_station")->fetch_by_stationname($value);
			if(!$estation){
				C::t("#gongjiao#plugin_bus_station")->insert($newdata);
			}else{
				$ig++;
			}
		}
	}
	cpmsg(lang('plugin/gongjiao', 'bus_msg_station_upsuccess', array('i' => $ig)), "action=plugins&operation=config&do=".$do."&identifier=gongjiao&pmod=cp_station", 'succeed');
}
//From: Dism��taobao��com
?>