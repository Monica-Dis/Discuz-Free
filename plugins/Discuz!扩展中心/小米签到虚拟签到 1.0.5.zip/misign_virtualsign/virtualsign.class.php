<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_misign_virtualsign {
	function global_footer(){
		global $_G;
		
		$misign_vs = $_G['cache']['plugin']['misign_virtualsign'];
		$misign_setting = $_G['cache']['plugin']['k_misign'];
		
		$tdtime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$misign_setting['tos']),dgmdate($_G['timestamp'], 'j',$misign_setting['tos']),dgmdate($_G['timestamp'], 'Y',$misign_setting['tos'])) - $misign_setting['tos']*3600;
		$njlmain =str_replace(array("\r\n", "\n", "\r"), '/hhf/', $misign_setting['jlmain']);
		$extreward = explode("/hhf/", $njlmain);
		$extreward_num = count($extreward);
		
		$random = mt_rand(1, 100);
		if($misign_vs['status'] && $random <= $misign_vs['percent']){
			$maxtime = DB::fetch_first("SELECT * FROM %t ORDER BY time DESC LIMIT 1", array('plugin_k_misign'));
			if($maxtime['time'] < $tdtime)return '';
			if($misign_vs['jiange'] && $maxtime['time']+$misign_vs['jiange'] >= $_G['timestamp'])return '';
			$vsuser = C::t("#misign_virtualsign#plugin_misign_virtualsign")->fetch_by_todo();
			if(!$vsuser)return '';
			$vsuser2 = getuserbyuid($vsuser['uid']);
			$vsuser['username'] = $vsuser2['username'];
			$qiandaodb = C::t("#k_misign#plugin_k_misign")->fetch_by_uid($vsuser['uid']);
			$num = C::t("#k_misign#plugin_k_misign")->count_by_time($tdtime);
			$stats = C::t("#k_misign#plugin_k_misignset")->fetch(1);
			if(!$qiandaodb['uid']) {
				C::t("#k_misign#plugin_k_misign")->insert(array('uid' => $vsuser['uid'], 'time' => $_G['timestamp']), false, false, true);
			}

			$row = $num + 1;
			$ajaxcreditshow['normal']['type'] = $misign_setting['nrcredit'];
			$ajaxcreditshow['normal']['number'] = mt_rand($misign_setting['mincredit'],$misign_setting['maxcredit']);
			
			if(($tdtime - $qiandaodb['time']) < 86400)$islasted = 1;
			if(!$islasted){//补签记录
				$bqlasttime = gmmktime(0,0,0,dgmdate($qiandaodb['time'], 'n'),dgmdate($qiandaodb['time'], 'j'),dgmdate($qiandaodb['time'], 'Y'));
				if($bqlasttime)C::t("#k_misign#plugin_k_misign_bq")->insert(array('uid' => $vsuser['uid'], 'lasttime'=> $bqlasttime, 'thistime' => $tdtime, 'bqdays' => $qiandaodb['lasted']));
			}
			
			if($misign_vs['creditstatus'])updatemembercount($vsuser['uid'], array($misign_setting['nrcredit'] => $ajaxcreditshow['normal']['number']));
			require_once libfile('function/post');
			require_once libfile('function/forum');
			if($row <= $extreward_num && $misign_vs['extcreditstatus']) {
				list($exacr,$exacz) = explode("|", $extreward[$num]);
				if($exacr && $exacz){
					updatemembercount($vsuser['uid'], array($exacr => $exacz));
					$ajaxcreditshow['ext']['type'] = $exacr;
					$ajaxcreditshow['ext']['number'] = $exacz;
					if($ajaxcreditshow['ext']['type'] == $ajaxcreditshow['normal']['type']){
						$ajaxcreditshow['normal']['number'] = $ajaxcreditshow['ext']['number'] + $ajaxcreditshow['normal']['number'];
					}
				}
			}
			$hft = dgmdate($_G['timestamp'], 'Y-m-d H:i',$misign_setting['tos']);
			
			if(memory('check')) memory('set', 'k_misign_'.$vsuser['uid'], $_G['timestamp'], 86400);
			C::t("#k_misign#plugin_k_misignset")->increase_todayq();

			if($misign_setting['prizestatus'] && $misign_vs['prizestatus']){
				$prizelist = C::t("#k_misign#plugin_k_misign_prize")->fetch_all_by_status();
				$prizenumber = count($prizelist);
				$lucky_range = $made_num = 0;
				if($misign_setting['prizetype'] == 1){//难度升级模式
					$maxpercent = $prizenumber * 1000;
					$luck_num = mt_rand(0, $maxpercent);
					foreach($prizelist as $prize){
						$prob = intval($prize['percent']);
						if($luck_num >=  $made_num && $luck_num < $made_num+$prob){
							$myprize = $prize;
							break;
						}
						$made_num = $made_num + 1000;
					}
				}else{
					foreach($prizelist as $prize){
						$luck_num = mt_rand(0, 1000);
						$prob = intval($prize['percent']);
						if($luck_num >=  0 && $luck_num < $prob){
							$myprize = $prize;
							break;
						}
					}
				}
				if($myprize){
					if($myprize['prizetype'] == 2){//积分奖品处理流程
						updatemembercount($vsuser['uid'], array($myprize['prizecredittype'] => $myprize['prizecreditnum']));
					}elseif($myprize['prizetype'] == 3){//卡密奖品处理流程
						$kami = C::t("#k_misign#plugin_k_misign_prize_kami")->fetch_by_prizeid($myprize['prizeid']);
						notification_add($vsuser['uid'], 'k_misign', lang('plugin/k_misign', 'prize_kami_notice').$myprize['prizename'].'(&nbsp;'.$kami['message'].'&nbsp;)');
						C::t("#k_misign#plugin_k_misign_prize_kami")->update($kami['kid'], array('uid' => $vsuser['uid'], 'username' => $vsuser['username'], 'usetime' => $_G['timestamp']));
					}else{
						notification_add($vsuser['uid'], 'k_misign', lang('plugin/k_misign', 'prize_kami_notice').$myprize['prizename']);
					}
					C::t("#k_misign#plugin_k_misign_prize_log")->insert(array('uid' => $vsuser['uid'], 'username' => $vsuser['username'], 'prizeid' => $myprize['prizeid'], 'prizename' => $myprize['prizename'], 'dateline' => $_G['timestamp']));
					C::t("#k_misign#plugin_k_misign_prize")->update_by_todaylast($myprize['prizeid'], $myprize['todaylast']-1);
				}
			}
			if($islasted){
				$lastnum = $qiandaodb['lasted']+1;
			}
			
			$credit = $ajaxcreditshow['normal']['number'];
			if($misign_setting['qdtype'] == '2') {
				$thread = C::t('forum_thread')->fetch($misign_setting['tidnumber']);
				if($num >= 0 && ($row <= $extreward_num) && $exacr && $exacz) {
					$message = lang('plugin/k_misign', 'tsn_extrac', array('time' => $hft, 'row' => $row, 'extrac' => $_G['setting']['extcredits'][$misign_setting['nrcredit']]['title'].' '.$credit.' '.$_G['setting']['extcredits'][$misign_setting['nrcredit']]['unit'], 'extrac2' => $_G['setting']['extcredits'][$exacr]['title'].$exacz.$_G['setting']['extcredits'][$exacr]['unit']));
				} else {
					$message = lang('plugin/k_misign', 'tsn_noextrac', array('time' => $hft, 'extrac' => $_G['setting']['extcredits'][$misign_setting['nrcredit']]['title'].' '.$credit.' '.$_G['setting']['extcredits'][$misign_setting['nrcredit']]['unit']));
				}
				$pid = insertpost(array('fid' => $thread['fid'],'tid' => $misign_setting['tidnumber'],'first' => '0','author' => $vsuser['username'],'authorid' => $vsuser['uid'],'subject' => '','dateline' => $_G['timestamp'],'message' => $message,'useip' => $_G['clientip'],'invisible' => '0','anonymous' => '0','usesig' => '0','htmlon' => '0','bbcodeoff' => '0','smileyoff' => '0','parseurloff' => '0','attachment' => '0',));
				C::t('forum_thread')->update($misign_setting['tidnumber'], array('lastposter'=>$vsuser['username'],'lastpost'=>$_G['timestamp']));
				C::t('forum_thread')->increase($misign_setting['tidnumber'], array('replies'=>1));
				updatepostcredits('+', $vsuser['uid'], 'reply', $thread['fid']);
				$lastpost = $thread['tid']."\t".addslashes($thread['subject'])."\t".$_G['timestamp']."\t".$vsuser['username'];
				C::t('forum_forum')->update($thread['fid'], array('lastpost' => $lastpost));
				C::t('forum_forum')->update_forum_counter($thread['fid'], 0, 1, 1);
				$tidnumber = $misign_setting['tidnumber'];
			}elseif($misign_setting['qdtype'] == '3') {
				if($isfirst || $stats['qdtidnumber'] == '0') {
					$subject = str_replace(array('{m}','{d}','{y}','{bbname}'), array(dgmdate($_G['timestamp'], 'n',$misign_setting['tos']),dgmdate($_G['timestamp'], 'j',$misign_setting['tos']),dgmdate($_G['timestamp'], 'Y',$misign_setting['tos']),$_G['setting']['bbname']), $misign_setting['title_thread']);
					if($exacr && $exacz) {
						$message = lang('plugin/k_misign', 'tsn_thread').lang('plugin/k_misign', 'tsn_extrac', array('time' => $hft, 'row' => $row, 'extrac' => $_G['setting']['extcredits'][$misign_setting['nrcredit']]['title'].' '.$credit.' '.$_G['setting']['extcredits'][$misign_setting['nrcredit']]['unit'], 'extrac2' => $_G['setting']['extcredits'][$exacr]['title'].$exacz.$_G['setting']['extcredits'][$exacr]['unit']));
					} else {
						$message = lang('plugin/k_misign', 'tsn_thread').lang('plugin/k_misign', 'tsn_noextrac', array('time' => $hft, 'extrac' => $_G['setting']['extcredits'][$misign_setting['nrcredit']]['title'].' '.$credit.' '.$_G['setting']['extcredits'][$misign_setting['nrcredit']]['unit']));
					}
					$thread_param = array(
						'isgroup' => '0',
						'status' => '0',
						'closed' => '1',
						'highlight' => '1',
						'moderated' => '1',
						'attachment' => '0',
						'special' => '0',
						'digest' => '0',
						'displayorder' => '0',
						'lastposter' => $vsuser['username'],
						'lastpost' => $_G['timestamp'],
						'dateline' => $_G['timestamp'],
						'subject' => $subject,
						'authorid' => $vsuser['uid'],
						'author' => $vsuser['username'],
						'sortid' => '0',
						'typeid' => $misign_setting['qdtypeid'],
						'price' => '0',
						'readperm' => '0',
						'posttableid' => '0',
						'fid' => $misign_setting['fidnumber']
					);
					$tid = C::t("forum_thread")->insert($thread_param, true);
					C::t("#k_misign#plugin_k_misignset")->update('1', array('qdtidnumber'=>$tid));
					$pid = insertpost(array('fid' => $misign_setting['fidnumber'],'tid' => $tid,'first' => '1','author' => $vsuser['username'],'authorid' => $vsuser['uid'],'subject' => $subject,'dateline' => $_G['timestamp'],'message' => $message,'useip' => $_G['clientip'],'invisible' => '0','anonymous' => '0','usesig' => '0','htmlon' => '0','bbcodeoff' => '0','smileyoff' => '0','parseurloff' => '0','attachment' => '0',));
					$expiration = $_G['timestamp'] + 86400;
					$threadmod_param1 = array(
						'tid' => $tid,
						'uid' => $vsuser['uid'],
						'username' => $vsuser['username'],
						'dateline' => $_G['timestamp'],
						'action' => 'EHL',
						'expiration' => $expiration,
						'status' => '1'
					);
					$threadmod_param2 = array(
						'tid' => $tid,
						'uid' => $vsuser['uid'],
						'username' => $vsuser['username'],
						'dateline' => $_G['timestamp'],
						'action' => 'CLS',
						'expiration' => '0',
						'status' => '1'
					);
					C::t('forum_threadmod')->insert($threadmod_param1);
					C::t('forum_threadmod')->insert($threadmod_param2);
					updatepostcredits('+', $vsuser['uid'], 'post', $misign_setting['fidnumber']);
					$lastpost = $tid."\t".addslashes($subject)."\t".$_G['timestamp']."\t.".$vsuser['username'];
					C::t('forum_forum')->update($misign_setting['fidnumber'], array('lastpost' => $lastpost));
					C::t('forum_forum')->update_forum_counter($misign_setting['fidnumber'], 1, 1, 1);
					$tidnumber = $tid;
				} else {
					$tidnumber = $stats['qdtidnumber'];
					$thread = C::t('forum_thread')->fetch($tidnumber);
					if($num >=1 && ($row <= $extreward_num) && $exacr && $exacz) {
						$message = lang('plugin/k_misign', 'tsn_extrac', array('time' => $hft, 'row' => $row, 'extrac' => $_G['setting']['extcredits'][$misign_setting['nrcredit']]['title'].' '.$credit.' '.$_G['setting']['extcredits'][$misign_setting['nrcredit']]['unit'], 'extrac2' => $_G['setting']['extcredits'][$exacr]['title'].$exacz.$_G['setting']['extcredits'][$exacr]['unit']));
					} else {
						$message = lang('plugin/k_misign', 'tsn_noextrac', array('time' => $hft, 'extrac' => $_G['setting']['extcredits'][$misign_setting['nrcredit']]['title'].' '.$credit.' '.$_G['setting']['extcredits'][$misign_setting['nrcredit']]['unit']));
					}
					$pid = insertpost(array('fid' => $misign_setting['fidnumber'],'tid' => $tidnumber,'first' => '0','author' => $vsuser['username'],'authorid' => $vsuser['uid'],'subject' => '','dateline' => $_G['timestamp'],'message' => $message,'useip' => $_G['clientip'],'invisible' => '0','anonymous' => '0','usesig' => '0','htmlon' => '0','bbcodeoff' => '0','smileyoff' => '0','parseurloff' => '0','attachment' => '0',));
					C::t('forum_thread')->update($tidnumber, array('lastposter'=>$vsuser['username'],'lastpost'=>$_G['timestamp']));
					C::t('forum_thread')->increase($tidnumber, array('replies'=>1));
					updatepostcredits('+', $vsuser['uid'], 'reply', $misign_setting['fidnumber']);
					$lastpost = $tidnumber."\t".addslashes($thread['subject'])."\t".$_G['timestamp']."\t.".$vsuser['username'];
					C::t('forum_forum')->update($misign_setting['fidnumber'], array('lastpost' => $lastpost));
					C::t('forum_forum')->update_forum_counter($misign_setting['fidnumber'], 0, 1, 1);
				}
			}
			
			if($qiandaodb['mdays'] < dgmdate($_G['timestamp'], 'j', $misign_setting['tos'])){
				C::t("#k_misign#plugin_k_misign")->update_signdata($vsuser['uid'], $credit, $row, $islasted);
			}else{
				C::t("#k_misign#plugin_k_misign")->update_signdata_outmonth($vsuser['uid'], $credit, $row, $islasted);
			}
			if($misign_setting['lockopen']) discuz_process::unlock('k_misign');
			if($misign_setting['memorystatus']) C::memory()->clear();
			
			C::t("#misign_virtualsign#plugin_misign_virtualsign")->update($vsuser['uid'], array('today' => 1));
		}
		return '';
	}
}

class plugin_misign_virtualsign_forum extends plugin_misign_virtualsign {
}
//From: Dism·taobao·com
?>