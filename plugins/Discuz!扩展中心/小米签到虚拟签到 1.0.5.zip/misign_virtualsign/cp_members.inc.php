<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];

if($act == 'add'){
	if(!submitcheck('addsubmit')){
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=misign_virtualsign&pmod=cp_members&act=add');
		showtableheader('', 'fixpadding', '');
		showsetting(lang('plugin/misign_virtualsign', 'adduid'), 'uidsnew', '', 'text', '', '', lang('plugin/misign_virtualsign', 'adduid_tip'));
		showsubmit('addsubmit', $lang['submit']);
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
	}else{
		list($fromuid, $touid) = explode("|", $_GET['uidsnew']);
		$newuidarr = array();
		if(is_numeric($fromuid) && is_numeric($touid)){
			for($i = $fromuid; $i <= $touid; $i++){
				$newuidarr[] = $i;
			}
		}else{
			$newuidarr = explode(",", $_GET['uidsnew']);
		}
		foreach($newuidarr as $v){
			C::t("#misign_virtualsign#plugin_misign_virtualsign")->insert(array('uid' => $v), false, true);
		}
		cpmsg(lang('plugin/misign_virtualsign', 'success'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=misign_virtualsign&pmod=cp_members', 'succeed');
	}
}else{
	if(!submitcheck('membersubmit')) {
		$perpage = 30;
		$page = intval($_GET['page']);
		$start = ($page-1) * $perpage;
		if(empty($page)){
			$page = 1;
		}
		if($start < 0){
			$start = 0;
		}
		$where = '';
		$multi = '';
		$members = C::t("#misign_virtualsign#plugin_misign_virtualsign")->fetch_all($start, $perpage);
		foreach($members as $member){
			$memberlist .= showtablerow('', array('', 'class="td24"', 'class="td24"', ''), array(
				'<input class="checkbox" type="checkbox" name="delete['.$member['uid'].']" value="'.$member['uid'].'">',
				$member['username'],
				$member['today'],
				'',
			), TRUE);
		}
		$count =  0;
		$count = C::t("#misign_virtualsign#plugin_misign_virtualsign")->count();
		$multi = multi($count, $perpage, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=misign_virtualsign&pmod=cp_members');
	
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=misign_virtualsign&pmod=cp_members');
		showtableheader('', 'fixpadding', '');
		showsubtitle(array('', lang('plugin/misign_virtualsign', 'username'), lang('plugin/misign_virtualsign', 'today')));
		echo $memberlist;
		echo '<tr><td>&nbsp;</td><td colspan="3"><div><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=misign_virtualsign&pmod=cp_members&act=add" class="addtr">'.lang('plugin/misign_virtualsign', 'add').'</a></div></td></tr>';
		showsubmit('membersubmit', $lang['submit'], 'del', '', $multi);
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
	}else{
		if(is_array($_GET['delete'])) {
			foreach($_GET['delete'] as $id) {
				C::t("#misign_virtualsign#plugin_misign_virtualsign")->delete($id);
			}
		}
		cpmsg(lang('plugin/misign_virtualsign', 'success'), "action=plugins&operation=config&do=".$do."&identifier=misign_virtualsign&pmod=cp_members", 'succeed');
	}
}
//From: dis'.'m.tao'.'bao.com
?>