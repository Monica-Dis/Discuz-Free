<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$kp_setting = $_G['cache']['plugin']['k_promotion'];
require_once libfile('function/misc');
$uid = intval($_GET['uid']) ? intval($_GET['uid']) : 0;

if(!submitcheck('logsubmit')) {
	$perpage = 30;
	$page = intval($_GET['page']);
	$start = ($page-1) * $perpage;
	if(empty($page)){
		$page = 1;
	}
	if($start < 0){
		$start = 0;
	}
	$multi = '';
	
	if($uid){
		$list = C::t("#k_promotion#plugin_k_promotion")->fetch_all_by_uid($uid);
		$user[$uid] = getuserbyuid($uid);
	}else{
		$list = C::t("#k_promotion#plugin_k_promotion")->fetch_all($start, $perpage);
	}
	foreach($list as $lists){
		if(!$uid)$user[$lists['uid']] = getuserbyuid($lists['uid']);
		$lists['location'] = trim(convertip($lists['ip'], "./"));
		$companylist .= showtablerow('', array('', '', 'class="td32"', 'class="td32"', 'class="td32"'), array(
			'<input class="checkbox" type="checkbox" name="delete['.$lists['id'].']" value="'.$lists['id'].'">',
			'<a href="home.php?mod=space&uid='.$lists['uid'].'" target="_blank">'.dhtmlspecialchars($user[$lists['uid']]['username']).'</a>',
			$lists['ip'],
			$lists['location'],
			dgmdate($lists['dateline'], 'u'),
		), TRUE);
	}
	$count =  0;
	if(!$uid){
		$count = C::t("#k_promotion#plugin_k_promotion")->count();
		$multi = multi($count, $perpage, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=k_promotion&pmod=cp_log');
	}
	showtableheader(); /*dis'.'m.tao'.'bao.com*/
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=k_promotion&pmod=cp_log', 'searchsubmit');
	showsubmit('searchsubmit', lang('plugin/k_promotion', 'searchuser'), $lang['uid'].': <input name="uid" value="'.($uid ? $uid : '').'" class="txt" />', $searchtext);
	showformfooter(); /*DISM-TAOBAO-COM*/
	showtablefooter(); /*dism��taobao��com*/
	
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=k_promotion&pmod=cp_log');
	showtableheader('', 'fixpadding', '');
	showsubtitle(
		array(
			'', 
			$lang['username'], 
			lang('plugin/k_promotion', 'promotionip'), 
			lang('plugin/k_promotion', 'promotionarea'), 
			lang('plugin/k_promotion', 'dateline'), 
		)
	);
	echo $companylist;
	showsubmit('logsubmit', $lang['submit'], 'del', '', $multi);
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*DISM-TAOBAO-COM*/
}else{
	if(is_array($_GET['delete'])) {
		foreach($_GET['delete'] as $id) {
			C::t("#k_promotion#plugin_k_promotion")->delete($id);
		}
	}
	cpmsg('update_success', "action=plugins&operation=config&do=".$do."&identifier=k_promotion&pmod=cp_log", 'succeed');
}
//From: Dism��taobao��com
?>