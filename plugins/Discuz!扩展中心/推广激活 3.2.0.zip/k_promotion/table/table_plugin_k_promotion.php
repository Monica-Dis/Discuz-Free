<?php

/**
 *      [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_myrepeats.php 29364 2012-04-09 02:51:41Z monkey $
 */

class table_plugin_k_promotion extends discuz_table
{
	public function __construct() {

		$this->_table = 'plugin_k_promotion';
		$this->_pk    = 'id';

		parent::__construct(); /*dism �� taoabo �� com*/
	}

	public function fetch_all($start = 0, $limit = 9999) {
		return DB::fetch_all("SELECT * FROM %t ORDER BY dateline DESC ".DB::limit($start, $limit), array($this->_table));
	}

	public function fetch_all_by_uid($uid) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
	}

	public function fetch_by_ip($ip, $uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE ip=%s AND uid=%d", array($this->_table, $ip, $uid));
	}

	public function delete_by_uid($uid) {
		return DB::query("DELETE FROM %t WHERE uid=%d", array($this->_table, $uid));
	}

}
//From: Dism��taobao��com
?>