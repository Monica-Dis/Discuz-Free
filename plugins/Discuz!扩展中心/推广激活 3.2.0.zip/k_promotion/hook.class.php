<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
!defined('IN_DISCUZ') && exit('Access Denied');

class plugin_k_promotion{
	function global_footer() {
		global $_G;
		
		$kp_setting = $_G['cache']['plugin']['k_promotion'];
		$kp_setting['from_usergroup'] = (array)unserialize($kp_setting['from_usergroup']);
		//print_r($kp_setting['jiangli_unit']);

		if($_GET['x']){
			$member = array();
			$member = C::t('common_member')->fetch(intval($_GET['x']), false, 1);
			$exit = C::t('#k_promotion#plugin_k_promotion')->fetch_by_ip($_G['clientip'], $member['uid']);
			if(!$exit && in_array($member['groupid'], $kp_setting['from_usergroup'])){
				C::t('#k_promotion#plugin_k_promotion')->insert(array(
					'uid' => $member['uid'],
					'ip' => $_G['clientip'],
					'dateline' => $_G['timestamp'],
				));
				$now = count(C::t('#k_promotion#plugin_k_promotion')->fetch_all_by_uid($member['uid']));
				if($now == $kp_setting['limit']){
					$tableext = '';
					if($member['adminid'] != 1 && $kp_setting['to_usergroup']){
						if($kp_setting['exp']){
							$beginToday = mktime(0,0,0,date('m'),date('d'),date('Y'));
							$expdate = $beginToday + (86400*$kp_setting['exp']);
							$groupterms['main'] = array('time' => $expdate);
							$groupterms['ext'][$kp_setting['to_usergroup']] = $expdate;
							$grouptermsnew = serialize($groupterms);
						}else{
							$expdate = 0;
						}
						$tableext = isset($member['_inarchive']) ? '_archive' : '';
						C::t('common_member'.$tableext)->update($member['uid'], array('groupid'=>$kp_setting['to_usergroup'], 'groupexpiry' => $expdate));
						if($kp_setting['exp']){
							if(C::t('common_member_field_forum'.$tableext)->fetch($member['uid'])) {
								C::t('common_member_field_forum'.$tableext)->update($member['uid'], array('groupterms' => $grouptermsnew));
							} else {
								C::t('common_member_field_forum'.$tableext)->insert(array('uid' => $member['uid'], 'groupterms' => $grouptermsnew));
							}
						}
						if($kp_setting['jiangli_unit'] && ($kp_setting['jiangli'] || $kp_setting['smartjiangli'])){
							//smartjiangli
							if($_G['cache']['usergroups'][$kp_setting['to_usergroup']]['type'] == 'member' && $kp_setting['smartjiangli']){
								if(strstr($_G['setting']['creditsformula'], 'extcredits'.$kp_setting['jiangli_unit']) && $kp_setting['jiangli_unit']){
									if($kp_setting['jiangli_unit'] == 1){
										$kp_setting['jiangli_unittext'] = "member['extcredits1']";
									}elseif($kp_setting['jiangli_unit'] == 2){
										$kp_setting['jiangli_unittext'] = "member['extcredits2']";
									}elseif($kp_setting['jiangli_unit'] == 3){
										$kp_setting['jiangli_unittext'] = "member['extcredits3']";
									}elseif($kp_setting['jiangli_unit'] == 4){
										$kp_setting['jiangli_unittext'] = "member['extcredits4']";
									}elseif($kp_setting['jiangli_unit'] == 5){
										$kp_setting['jiangli_unittext'] = "member['extcredits5']";
									}elseif($kp_setting['jiangli_unit'] == 6){
										$kp_setting['jiangli_unittext'] = "member['extcredits6']";
									}elseif($kp_setting['jiangli_unit'] == 7){
										$kp_setting['jiangli_unittext'] = "member['extcredits7']";
									}elseif($kp_setting['jiangli_unit'] == 8){
										$kp_setting['jiangli_unittext'] = "member['extcredits8']";
									}
								}
								$formulaarr = explode($kp_setting['jiangli_unittext'], $_G['setting']['creditsformula']);
								$glue = substr($formulaarr[1],0,1);
								$gluenum = substr($formulaarr[1],1,1);
								$needac = $_G['cache']['usergroups'][$kp_setting['to_usergroup']]['creditshigher']-$member['credits'];
								if($needac > 0){
									if($glue == '*'){
										$needc = ($_G['cache']['usergroups'][$kp_setting['to_usergroup']]['creditshigher']-$member['credits']) / $gluenum;
									}elseif($glue == '/'){
										$needc = ($_G['cache']['usergroups'][$kp_setting['to_usergroup']]['creditshigher']-$member['credits']) * $gluenum;
									}
								}
								$needc2 = ceil($needc) + 1;
								if($needc)updatemembercount($member['uid'], array('extcredits'.$kp_setting['jiangli_unit'] => $needc2));
							}else{
								updatemembercount($member['uid'], array('extcredits'.$kp_setting['jiangli_unit'] => $kp_setting['jiangli']));
							}
							//smartjiangli
						}
						if($kp_setting['delete_status']){
							C::t('#k_promotion#plugin_k_promotion')->delete_by_uid($member['uid']);
						}
					}
				}
			}
		}
		return ;
	}
}

class plugin_k_promotion_forum extends plugin_k_promotion {
	
	function  forumdisplay_bottom(){
		global $_G;
		
		$kp_setting = $_G['cache']['plugin']['k_promotion'];
		$kp_setting['limit_fid'] = (array)unserialize($kp_setting['limit_fid']);
		$kp_setting['from_usergroup'] = (array)unserialize($kp_setting['from_usergroup']);
		
		if($kp_setting['limitthreadonly']){
			return null;
		}
		
		if($_G['uid'] && in_array($_G['member']['groupid'], $kp_setting['from_usergroup']) && in_array($_G['fid'], $kp_setting['limit_fid'])){
			$now = count(C::t('#k_promotion#plugin_k_promotion')->fetch_all_by_uid($_G['uid']));
			if($now < $kp_setting['limit']){
				if(strstr($kp_setting['page'], '?')){
					$pf = '&';
				}else{
					$pf = '?';
				}
				$kp_setting['tips'] = str_replace(array('{mubiao}', '{url}', '{now}'), array($kp_setting['limit'], $_G['siteurl'].$kp_setting['page'].$pf."x=".$_G['uid'], $now), $kp_setting['tips']);
				$kp_setting['area_tips'] = str_replace(array('{mubiao}', '{url}', '{now}'), array($kp_setting['limit'], $_G['siteurl'].$kp_setting['page'].$pf."x=".$_G['uid'], $now), $kp_setting['area_tips']);
				$kp_setting['tips'] = str_replace(':', '&#58;', $kp_setting['tips']);
				$kp_setting['area_tips'] = str_replace(':', '&#58;', $kp_setting['area_tips']);
				showmessage($kp_setting['tips'].'<p><textarea cols="60" rows="5">'.$kp_setting['area_tips'].'</textarea></p>');
			}
			return ;
		}elseif(!$_G['uid'] && in_array($_G['fid'], $kp_setting['limit_fid']) && !IS_ROBOT){
			showmessage('to_login', '', array(), array('login' => true));
		}else{
			return null;
		}
	}

	function  viewthread_top(){
		global $_G;
		
		$kp_setting = $_G['cache']['plugin']['k_promotion'];
		$kp_setting['limit_fid'] = (array)unserialize($kp_setting['limit_fid']);
		$kp_setting['from_usergroup'] = (array)unserialize($kp_setting['from_usergroup']);
		if($_G['uid'] && in_array($_G['member']['groupid'], $kp_setting['from_usergroup']) && in_array($_G['thread']['fid'], $kp_setting['limit_fid'])){
			$now = count(C::t('#k_promotion#plugin_k_promotion')->fetch_all_by_uid($_G['uid']));
			if($now < $kp_setting['limit'] && (!$kp_setting['authoredit'] || ($kp_setting['authoredit'] &&  $_G['uid'] != $_G['thread']['authorid']))){
				if(strstr($kp_setting['page'], '?')){
					$pf = '&';
				}else{
					$pf = '?';
				}
				$kp_setting['tips'] = str_replace(array('{mubiao}', '{url}', '{now}'), array($kp_setting['limit'], $_G['siteurl'].$kp_setting['page'].$pf."x=".$_G['uid'], $now), $kp_setting['tips']);
				$kp_setting['area_tips'] = str_replace(array('{mubiao}', '{url}', '{now}'), array($kp_setting['limit'], $_G['siteurl'].$kp_setting['page'].$pf."x=".$_G['uid'], $now), $kp_setting['area_tips']);
				$kp_setting['tips'] = str_replace(':', '&#58;', $kp_setting['tips']);
				$kp_setting['area_tips'] = str_replace(':', '&#58;', $kp_setting['area_tips']);
				showmessage($kp_setting['tips'].'<p><textarea cols="60" rows="5">'.$kp_setting['area_tips'].'</textarea></p>');
			}
			return ;
		}elseif(!$_G['uid'] && in_array($_G['fid'], $kp_setting['limit_fid']) && !IS_ROBOT){
			showmessage('to_login', '', array(), array('login' => true));
		}else{
			return null;
		}
	}
}

class plugin_k_promotion_group extends plugin_k_promotion {
	function  forumdisplay_bottom(){
		global $_G;
		
		$kp_setting = $_G['cache']['plugin']['k_promotion'];
		$kp_setting['limit_fid'] = (array)unserialize($kp_setting['limit_fid']);
		$kp_setting['from_usergroup'] = (array)unserialize($kp_setting['from_usergroup']);
		
		if($kp_setting['limitthreadonly']){
			return null;
		}
		
		if($_G['uid'] && in_array($_G['member']['groupid'], $kp_setting['from_usergroup']) && in_array($_G['fid'], $kp_setting['limit_fid'])){
			$now = count(C::t('#k_promotion#plugin_k_promotion')->fetch_all_by_uid($_G['uid']));
			if($now < $kp_setting['limit']){
				if(strstr($kp_setting['page'], '?')){
					$pf = '&';
				}else{
					$pf = '?';
				}
				$kp_setting['tips'] = str_replace(array('{mubiao}', '{url}', '{now}'), array($kp_setting['limit'], $_G['siteurl'].$kp_setting['page'].$pf."x=".$_G['uid'], $now), $kp_setting['tips']);
				$kp_setting['area_tips'] = str_replace(array('{mubiao}', '{url}', '{now}'), array($kp_setting['limit'], $_G['siteurl'].$kp_setting['page'].$pf."x=".$_G['uid'], $now), $kp_setting['area_tips']);
				$kp_setting['tips'] = str_replace(':', '&#58;', $kp_setting['tips']);
				$kp_setting['area_tips'] = str_replace(':', '&#58;', $kp_setting['area_tips']);
				showmessage($kp_setting['tips'].'<p><textarea cols="60" rows="5">'.$kp_setting['area_tips'].'</textarea></p>');
			}
			return ;
		}elseif(!$_G['uid'] && in_array($_G['fid'], $kp_setting['limit_fid']) && !IS_ROBOT){
			showmessage('to_login', '', array(), array('login' => true));
		}else{
			return null;
		}
	}

	function  viewthread_top(){
		global $_G;
		
		$kp_setting = $_G['cache']['plugin']['k_promotion'];
		$kp_setting['limit_fid'] = (array)unserialize($kp_setting['limit_fid']);
		$kp_setting['from_usergroup'] = (array)unserialize($kp_setting['from_usergroup']);
		if($_G['uid'] && in_array($_G['member']['groupid'], $kp_setting['from_usergroup']) && in_array($_G['thread']['fid'], $kp_setting['limit_fid'])){
			$now = count(C::t('#k_promotion#plugin_k_promotion')->fetch_all_by_uid($_G['uid']));
			if($now < $kp_setting['limit']){
				if(strstr($kp_setting['page'], '?')){
					$pf = '&';
				}else{
					$pf = '?';
				}
				$kp_setting['tips'] = str_replace(array('{mubiao}', '{url}', '{now}'), array($kp_setting['limit'], $_G['siteurl'].$kp_setting['page'].$pf."x=".$_G['uid'], $now), $kp_setting['tips']);
				$kp_setting['area_tips'] = str_replace(array('{mubiao}', '{url}', '{now}'), array($kp_setting['limit'], $_G['siteurl'].$kp_setting['page'].$pf."x=".$_G['uid'], $now), $kp_setting['area_tips']);
				$kp_setting['tips'] = str_replace(':', '&#58;', $kp_setting['tips']);
				$kp_setting['area_tips'] = str_replace(':', '&#58;', $kp_setting['area_tips']);
				showmessage($kp_setting['tips'].'<p><textarea cols="60" rows="5">'.$kp_setting['area_tips'].'</textarea></p>');
			}
			return ;
		}elseif(!$_G['uid'] && in_array($_G['fid'], $kp_setting['limit_fid']) && !IS_ROBOT){
			showmessage('to_login', '', array(), array('login' => true));
		}else{
			return null;
		}
	}	
}
//From: Dism��taobao��com
?>