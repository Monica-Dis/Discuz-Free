<?php

$extendlang = array(
	'title' => '威兔手機模板',
);

?>