<?php

$extendlang = array(
	'title' => '任天际百变百搭',
);

?>