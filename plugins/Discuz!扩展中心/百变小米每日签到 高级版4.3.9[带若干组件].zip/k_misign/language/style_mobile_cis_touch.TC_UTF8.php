<?php

$extendlang = array(
	'title' => '[CIS]Touch手機版',
);