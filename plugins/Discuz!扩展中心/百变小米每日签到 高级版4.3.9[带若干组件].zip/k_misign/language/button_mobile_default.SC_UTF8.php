<?php

$extendlang = array(
	'title' => '手机默认风格',
	'buttoncolor' => '按钮颜色',
	'navcolor' => '经验条颜色',
	'nav2color' => '经验条高亮色',
);

?>