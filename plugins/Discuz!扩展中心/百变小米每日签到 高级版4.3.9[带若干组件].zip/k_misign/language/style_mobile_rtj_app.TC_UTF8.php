<?php

$extendlang = array(
	'title' => '任天際百變百搭',
);

?>