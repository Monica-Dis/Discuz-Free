<?php

$extendlang = array(
	'title' => 'N5APP手机版',
);

?>