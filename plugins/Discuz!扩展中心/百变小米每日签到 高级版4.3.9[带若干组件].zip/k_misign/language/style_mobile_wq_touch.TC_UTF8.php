<?php

$extendlang = array(
	'title' => '維清微信手機版 ',
);

?>