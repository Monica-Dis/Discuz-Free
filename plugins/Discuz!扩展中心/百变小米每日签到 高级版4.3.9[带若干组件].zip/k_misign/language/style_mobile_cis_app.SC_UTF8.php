<?php

$extendlang = array(
	'title' => 'APP!手机模板',
);

?>