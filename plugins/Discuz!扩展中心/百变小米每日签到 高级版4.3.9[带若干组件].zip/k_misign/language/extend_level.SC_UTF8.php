<?php

$extendlang = array(
	'extend_level' => '签到等级自定义',
	'status' => '启用规则',
	'status_1' => '启用',
	'status_2' => '停用',
	'extendstatus_1' => '已停用，点击启用',
	'extendstatus_2' => '已启用，点击停用',
	'plzwait' => '请稍等',
	'add' => '添加新等级',
	'import' => '导入原先设置',
	'leveldays' => '等级起步天数',
	'levelname' => '等级名称',
	'levelnum' => '等级数阶',
	'tips' => '<li>导入原先设置为从设置中导入用户等级，导入操作将会清空当前本页的用户等级数据，请谨慎；</li><li>等级起步天数为累计签到天数大于此值时用户归属此等级</li>',
);

?>