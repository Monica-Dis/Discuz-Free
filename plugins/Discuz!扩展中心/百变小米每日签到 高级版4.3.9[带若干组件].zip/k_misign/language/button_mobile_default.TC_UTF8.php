<?php

$extendlang = array(
	'title' => '手機默認風格',
	'buttoncolor' => '按鈕顔色',
	'navcolor' => '經騐條顔色',
	'nav2color' => '經騐條高亮色',
);

?>