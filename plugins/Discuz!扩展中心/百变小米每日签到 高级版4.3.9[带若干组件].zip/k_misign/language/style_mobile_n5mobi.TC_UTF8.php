<?php

$extendlang = array(
	'title' => 'NVBING5手機版',
);

?>