<?php

$extendlang = array(
	'tips' => '<li>数据导入功能会导致您现在的小米签到中的签到数据清空，请确认需要如此操作</li><li>请勿重复导入操作，以免不必要的损失</li><li>操作之前请务必备份数据库，以免数据损失</li>',
	'imported' => '已导入过数据，如要再次导入，请先删除锁定文件./data/k_misign_import.lock',
	'selectver' => '请选择您目前数据库中存在的签到表版本',
);

?>