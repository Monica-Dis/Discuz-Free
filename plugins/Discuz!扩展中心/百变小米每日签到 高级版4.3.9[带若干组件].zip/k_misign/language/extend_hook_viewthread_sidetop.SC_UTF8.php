<?php

$extendlang = array(
	'ljqd' => '累计签到',
	'lxqd' => '连续签到',
	'noqd' => '尚未签到',
);

?>