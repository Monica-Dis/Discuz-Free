<?php

$extendlang = array(
	'title' => '威兔手機風格',
	'buttoncolor' => '簽到按鈕顔色',
	'buttoncolor2' => '已簽到按鈕顔色',
);

?>