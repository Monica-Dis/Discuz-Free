<?php

$extendlang = array(
	'tips' => '<li>數據導入功能會導致您現在的小米簽到中的簽到數據清空，請確認需要如此操作</li><li>請勿重複導入操作，以免不必要的損失</li><li>操作之前請務必備份數據庫，以免數據損失</li>',
	'imported' => '已導入過數據，如要再次導入，請先刪除鎖定文件./data/k_misign_import.lock',
	'selectver' => '請選擇您目前數據庫中存在的簽到表版本',
);

?>