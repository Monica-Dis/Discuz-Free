<?php

$extendlang = array(
	'title' => '威兔手机模板',
);

?>