<?php

$extendlang = array(
	'title' => 'NVBING5手机版',
);

?>