<?php

$extendlang = array(
	'title' => '2015年默認風格',
);

?>