<?php

$extendlang = array(
	'title' => '2015年默认风格',
);

?>