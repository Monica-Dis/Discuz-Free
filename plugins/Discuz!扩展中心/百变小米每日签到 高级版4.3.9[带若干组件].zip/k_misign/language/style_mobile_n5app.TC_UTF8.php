<?php

$extendlang = array(
	'title' => 'N5APP手機版',
);

?>