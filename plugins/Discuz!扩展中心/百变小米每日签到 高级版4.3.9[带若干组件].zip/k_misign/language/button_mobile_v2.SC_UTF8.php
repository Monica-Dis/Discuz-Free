<?php

$extendlang = array(
	'title' => '威兔手机风格',
	'buttoncolor' => '签到按钮颜色',
	'buttoncolor2' => '已签到按钮颜色',
);

?>