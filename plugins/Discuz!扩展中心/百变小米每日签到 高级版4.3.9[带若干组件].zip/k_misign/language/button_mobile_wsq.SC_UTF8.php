<?php

$extendlang = array(
	'title' => '[全局]微社区手机风格',
	'buttoncolor' => '签到按钮颜色',
	'buttoncolor2' => '已签到按钮颜色',
	'displayinplugin' => '插件内显示',
);

?>