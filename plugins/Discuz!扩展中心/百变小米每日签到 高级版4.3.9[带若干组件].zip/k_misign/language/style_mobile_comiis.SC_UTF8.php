<?php

$extendlang = array(
	'title' => '克米设计-手机版',
);

?>