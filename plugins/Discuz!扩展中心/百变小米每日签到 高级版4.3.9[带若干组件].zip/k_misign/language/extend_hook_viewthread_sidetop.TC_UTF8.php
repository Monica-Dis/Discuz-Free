<?php

$extendlang = array(
	'ljqd' => '累計簽到',
	'lxqd' => '連續簽到',
	'noqd' => '尚未簽到',
);

?>