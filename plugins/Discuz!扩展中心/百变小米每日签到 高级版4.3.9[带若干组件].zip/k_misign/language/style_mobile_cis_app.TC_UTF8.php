<?php

$extendlang = array(
	'title' => 'APP!手機模板',
);

?>