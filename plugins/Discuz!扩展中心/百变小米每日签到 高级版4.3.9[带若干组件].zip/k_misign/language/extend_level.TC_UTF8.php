<?php

$extendlang = array(
	'extend_level' => '簽到等級自定義',
	'status' => '啓用槼則',
	'status_1' => '啓用',
	'status_2' => '停用',
	'extendstatus_1' => '已停用，點擊啓用',
	'extendstatus_2' => '已啓用，點擊停用',
	'plzwait' => '請稍等',
	'add' => '添加新等級',
	'import' => '導入原先設置',
	'leveldays' => '等級起步天數',
	'levelname' => '等級名稱',
	'levelnum' => '等級數堦',
	'tips' => '<li>導入原先設置爲從設置中導入用戶等級，導入操作將會清空儅前本頁的用戶等級數據，請謹慎；</li><li>等級起步天數爲累計簽到天數大於此值時用戶歸屬此等級</li>',
);

?>