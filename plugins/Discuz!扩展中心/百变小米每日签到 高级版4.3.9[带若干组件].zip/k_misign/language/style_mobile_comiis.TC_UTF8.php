<?php

$extendlang = array(
	'title' => '尅米設計-手機版',
);

?>