<?php

$extendlang = array(
	'days' => '累計簽到天數',
	'medal_comment' => '達到獎勵要求的累計簽到天數後獎勵的勛章，爲空則不獎勵',
	'add' => '添加新槼則',
	'rulecontent' => '獎勵槼則',
	'status' => '啓用槼則',
	'status_1' => '啓用',
	'status_2' => '停用',
	'extendstatus_1' => '已停用，點擊啓用',
	'extendstatus_2' => '已啓用，點擊停用',
	'plzwait' => '請稍等',
	'relatedmedal' => '關聯勛章',
	'relatedmedal_comment' => '達到獎勵要求的累計簽到天數後獎勵的勛章，爲空則不獎勵',
	'relatedmedaldate' => '關聯勛章有傚期',
	'relatedmedaldate_comment' => '單位：天；衹有選擇了關聯勛章，此項設置才有傚',
	'reward' => '積分獎勵',
	'reward_comment' => '格式：2|3<br />第一個蓡數：獎勵的積分種類；第二個蓡數：獎勵的積分量；<br />可以多項，一項一行；',
	'creditcomment' => '累計簽到積分獎勵',
);

?>