<?php

$extendlang = array(
	'title' => 'APP!Im Dream',
);

?>