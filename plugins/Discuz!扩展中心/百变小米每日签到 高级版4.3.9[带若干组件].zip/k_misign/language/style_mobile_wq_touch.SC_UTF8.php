<?php

$extendlang = array(
	'title' => '维清微信手机版 ',
);

?>