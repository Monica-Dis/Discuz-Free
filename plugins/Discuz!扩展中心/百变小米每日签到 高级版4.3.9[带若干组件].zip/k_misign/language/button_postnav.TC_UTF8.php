<?php

$extendlang = array(
	'title' => '發帖按鈕風格',
	'send_posts' => '發布帖子',
	'bgcolor' => '背景色',
	'width' => '按鈕寬度',
	'week' => '周',
	'week1' => '一',
	'week2' => '二',
	'week3' => '三',
	'week4' => '四',
	'week5' => '五',
	'week6' => '六',
	'week0' => '日',
	'month' => '月',
);

?>