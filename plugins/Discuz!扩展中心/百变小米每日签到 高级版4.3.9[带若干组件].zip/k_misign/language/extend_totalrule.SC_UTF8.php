<?php

$extendlang = array(
	'days' => '累计签到天数',
	'medal_comment' => '达到奖励要求的累计签到天数后奖励的勋章，为空则不奖励',
	'add' => '添加新规则',
	'rulecontent' => '奖励规则',
	'status' => '启用规则',
	'status_1' => '启用',
	'status_2' => '停用',
	'extendstatus_1' => '已停用，点击启用',
	'extendstatus_2' => '已启用，点击停用',
	'plzwait' => '请稍等',
	'relatedmedal' => '关联勋章',
	'relatedmedal_comment' => '达到奖励要求的累计签到天数后奖励的勋章，为空则不奖励',
	'relatedmedaldate' => '关联勋章有效期',
	'relatedmedaldate_comment' => '单位：天；只有选择了关联勋章，此项设置才有效',
	'reward' => '积分奖励',
	'reward_comment' => '格式：2|3<br />第一个参数：奖励的积分种类；第二个参数：奖励的积分量；<br />可以多项，一项一行；',
	'creditcomment' => '累计签到积分奖励',
);

?>