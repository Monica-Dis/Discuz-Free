<?php

$extendlang = array(
	'title' => '[全侷]微社區手機風格',
	'buttoncolor' => '簽到按鈕顔色',
	'buttoncolor2' => '已簽到按鈕顔色',
	'displayinplugin' => '插件內顯示',
);

?>