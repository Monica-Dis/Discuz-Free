<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$url ='http://dism.taobao.com/?ac=developer&id=11&page='.intval($_GET['page']);
$content = dfsockopen($url, 0, $post, '', FALSE, '', 120);
if ($content) {
	$content = iconv('gbk', CHARSET, $content);
	$content = str_replace('resource/devgroup.gif', 'http://dism.taobao.com/resource/devgroup.gif', $content);
	$content = str_replace('resource/developer', 'http://dism.taobao.com/resource/developer', $content);
	$content = str_replace('resource/event', 'http://dism.taobao.com/resource/event', $content);
	$content = str_replace('resource/plugin', 'http://dism.taobao.com/resource/plugin', $content);
	$content = str_replace('resource/template', 'http://dism.taobao.com/resource/template', $content);
	$content = str_replace('resource/pack', 'http://dism.taobao.com/resource/pack', $content);
	$content = str_replace('image/scrolltop.png', 'http://dism.taobao.com/image/scrolltop.png', $content);
	$content = str_replace('?ac=developer&id=', '?action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=addon&did=', $content);
	
	$content = preg_replace('/<div class="itemtitle" id="header">.*<div class="a_wp cl">/s', '<div class="a_wp cl">', $content);
	$content = preg_replace('/<div class="a_wp mbm cl">.*<div class="a_wp cl">/s', '<div class="a_wp cl">', $content);
	$content = preg_replace('/<ul class="a_tb cl">.*<div id="appdiv">/s', '<div id="appdiv">', $content);
	$content = preg_replace('/<div class="mtm type">.*<div id="appdiv">/s', '<div id="appdiv">', $content);
	$content = preg_replace('/<div id="footer">.*<\/div>/s', '', $content);
	echo $content;
}
