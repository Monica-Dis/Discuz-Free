<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$misign = $_G['cache']['plugin']['k_misign'];
require_once libfile('function/core', 'plugin/k_misign');

$act = $_GET['act'];
$formhash = isset($_GET['formhash']) ? trim($_GET['formhash']) : '';
if($act){
	require_once libfile('extend/'.$act, 'plugin/k_misign');
}else{
	//����ϵͳ
	showtableheader(lang('plugin/k_misign', 'extend'), 'psetting');
	//��С��ÿ�ո��Ե���
	showtablerow('class="hover"', array('valign="top" style="width:45px"', 'valign="top"', 'align="right" valign="bottom" style="width:160px"'), array(
					'<img src="https://dism.taobao.com/resource/plugin/k_migeyan.png" onerror="this.src=\'static/image/admincp/plugin_logo.png\';this.onerror=null" width="40" height="40" align="left" />',
					'<span '.($extend['k_migeyan'] ? 'class="bold"' : 'class="bold light"').'>'.lang('plugin/k_misign', 'extend_k_migeyan').'</span>'.
					'<p><span class="bold light">'.($extend['k_migeyan'] ? lang('plugin/k_misign', 'extend_installed') : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_migeyan.plugin">'.lang('plugin/k_misign', 'extend_toinstall').'</a>').'</span></p>'
	) );
	showtablefooter(); /*dism _ taobao _ com*/
	
	//��ֵ���
	showtableheader(lang('plugin/k_misign', 'extend'));
		//���ݵ���
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'extend_dataimport'),($extend['dataimport'] ? lang('plugin/k_misign', 'extend_installed') : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.49727">'.lang('plugin/k_misign', 'extend_toinstall').'</a>'),($extend['dataimport'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=dataimport">'.$lang['config'].'</a> - <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=dataimport&op=uninstall">'.lang('plugin/k_misign', 'extend_uninstall').'</a>' : ''), ($extend['dataimport'] ? '' : '')));
		//���ݵ���
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'extend_dataexport'),($extend['dataexport'] ? lang('plugin/k_misign', 'extend_installed') : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.50175">'.lang('plugin/k_misign', 'extend_toinstall').'</a>'),($extend['dataexport'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=dataexport">'.$lang['config'].'</a> - <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=dataexport&op=uninstall">'.lang('plugin/k_misign', 'extend_uninstall').'</a>' : '')));
		//����ǩ������
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'extend_lastrule'),($extend['lastrule'] ? lang('plugin/k_misign', 'extend_installed') : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.55676">'.lang('plugin/k_misign', 'extend_toinstall').'</a>'),($extend['lastrule'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=lastrule">'.$lang['config'].'</a> - <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=lastrule&op=uninstall">'.lang('plugin/k_misign', 'extend_uninstall').'</a>' : '')));
		//����ǩ��ά��
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'extend_lastdefend'),($extend['lastdefend'] ? lang('plugin/k_misign', 'extend_installed') : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.49732">'.lang('plugin/k_misign', 'extend_toinstall').'</a>'),($extend['lastdefend'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=lastdefend">'.$lang['config'].'</a> - <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=lastdefend&op=uninstall">'.lang('plugin/k_misign', 'extend_uninstall').'</a>' : '')));
		//�ۼ�ǩ������
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'extend_totalrule'),($extend['totalrule'] ? lang('plugin/k_misign', 'extend_installed') : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.55677">'.lang('plugin/k_misign', 'extend_toinstall').'</a>'),($extend['totalrule'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=totalrule">'.$lang['config'].'</a> - <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=totalrule&op=uninstall">'.lang('plugin/k_misign', 'extend_uninstall').'</a>' : '')));
		//�ȼ�������ַ����
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'extend_level'),($extend['level'] ? lang('plugin/k_misign', 'extend_installed') : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.57909">'.lang('plugin/k_misign', 'extend_toinstall').'</a>'),($extend['level'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=level">'.$lang['config'].'</a> - <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=level&op=uninstall">'.lang('plugin/k_misign', 'extend_uninstall').'</a>' : '')));
		//��ǩ��������
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'extend_fixbq'),($extend['fixbq'] ? lang('plugin/k_misign', 'extend_installed') : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.58949">'.lang('plugin/k_misign', 'extend_toinstall').'</a>'),($extend['fixbq'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=fixbq">'.$lang['config'].'</a> - <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=fixbq&op=uninstall">'.lang('plugin/k_misign', 'extend_uninstall').'</a>' : '')));
	showtablefooter(); /*dism _ taobao _ com*/
	
	//������չ
	showtableheader(lang('plugin/k_misign', 'extend_magics'));
		//��ǩ��
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'magic_bq'),($extend['magic']['bq'] ? lang('plugin/k_misign', 'extend_installed') : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.49922">'.lang('plugin/k_misign', 'extend_toinstall').'</a>'), ''));
	showtablefooter(); /*dism _ taobao _ com*/

	//Ƕ���
	showtableheader(lang('plugin/k_misign', 'extend_hooks'));
		//global_usernav_extra3
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'hook_global_usernav_extra3'), '',($hook['global_usernav_extra3'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=hook_global_usernav_extra3&op=uninstall">'.lang('plugin/k_misign', 'extend_uninstall').'</a>' : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.57770">'.lang('plugin/k_misign', 'extend_toinstall').'</a>')));
		//viewthread_sidetop
		showtablerow('', array('class="td24 lineheight"','class="td24 lineheight smallfont"','class="lineheight smallfont"'), array(lang('plugin/k_misign', 'hook_viewthread_sidetop'), '',($hook['viewthread_sidetop'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=k_misign&pmod=cp_extend&act=hook_viewthread_sidetop&op=uninstall">'.lang('plugin/k_misign', 'extend_uninstall').'</a>' : '<a href="'.ADMINSCRIPT.'?action=cloudaddons&id=k_misign.plugin.57771">'.lang('plugin/k_misign', 'extend_toinstall').'</a>')));
	showtablefooter(); /*dism _ taobao _ com*/
}
//From: Dism_taobao-com
?>