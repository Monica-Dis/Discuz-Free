﻿<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['formhash'] != FORMHASH) {
	showmessage('undefined_action', NULL);
}

if(!$_G['uid']){
	include template('common/header_ajax');
	echo lang('plugin/k_misign', 'groupontallow');
	include template('common/footer_ajax');
	exit();
}

if(!in_array($_G['groupid'], $misign['groups'])){
	include template('common/header_ajax');
	echo lang('plugin/k_misign', 'groupontallow');
	include template('common/footer_ajax');
	exit();
}
if($_G['uid'] && in_array($_G['uid'],$misign['ban'])){
	include template('common/header_ajax');
	echo lang('plugin/k_misign', 'uidinblack');
	include template('common/footer_ajax');
	exit();
}
if($qiandaodb['time'] > $tdtime){
	include template('common/header_ajax');
	echo lang('plugin/k_misign', 'tdyq');
	include template('common/footer_ajax');
	exit();
}

if($misign['lockopen']){
	while(discuz_process::islocked('k_misign', 5)) usleep(100000);
}

if(!$qiandaodb['uid']) {
	C::t("#k_misign#plugin_k_misign")->insert(array('uid' => $_G['uid'], 'time' => $_G['timestamp']));
}
$num = intval($num);
$row = $num + 1;
if($num == 0){
	$isfirst = true;
	C::t("#k_misign#plugin_k_misign_prize")->update_everyday();
}

$ajaxcreditshow['normal']['type'] = $misign['nrcredit'];
$ajaxcreditshow['normal']['number'] = mt_rand($misign['mincredit'],$misign['maxcredit']);

if(($tdtime - $qiandaodb['time']) < 86400)$islasted = true;
if(!$islasted){//补签记录
	$bqlasttime = gmmktime(0,0,0,dgmdate($qiandaodb['time'], 'n'),dgmdate($qiandaodb['time'], 'j'),dgmdate($qiandaodb['time'], 'Y'));
	if($bqlasttime)C::t("#k_misign#plugin_k_misign_bq")->insert(array('uid' => $_G['uid'], 'lasttime'=> $bqlasttime, 'thistime' => $tdtime, 'bqdays' => $qiandaodb['lasted']));
}else{
	$lastnum = $qiandaodb['lasted']+1;
}


if($row <= $extreward_num) {
	list($exacr,$exacz) = explode("|", $extreward[$num]);
	if($exacr && $exacz){
		if($exacr == $ajaxcreditshow['normal']['type']){
			$ajaxcreditshow['normal']['number'] = $exacz + $ajaxcreditshow['normal']['number'];
		}else{
			$ajaxcreditshow['ext']['type'] = $exacr;
			$ajaxcreditshow['ext']['number'] = $exacz;
		}
	}
}
$hft = dgmdate($_G['timestamp'], 'Y-m-d H:i',$misign['tos']);

if(memory('check') && $misign['memorystatus']) memory('set', 'k_misign_'.$_G['uid'], $_G['timestamp'], 86400);
if($isfirst) {
	$firstsetdata = array('yesterdayq' => $stats['todayq'], 'todayq' => 1);
	if($stats['todayq'] > $stats['highestq']){
		$firstsetdata['highestq'] = $stats['todayq'];
	}
	C::t("#k_misign#plugin_k_misignset")->update(1, $firstsetdata);
} else {
	C::t("#k_misign#plugin_k_misignset")->increase_todayq();
}

if($misign['prizestatus']){
	$prizelist = C::t("#k_misign#plugin_k_misign_prize")->fetch_all_by_status();
	$prizenumber = count($prizelist);
	$lucky_range = $made_num = 0;
	if($misign['prizetype'] == 1){//难度升级模式
		$maxpercent = $prizenumber * 1000;
		$luck_num = mt_rand(0, $maxpercent);
		foreach($prizelist as $prize){
			$prob = intval($prize['percent']);
			if($luck_num >=  $made_num && $luck_num < $made_num+$prob){
				$myprize = $prize;
				break;
			}
			$made_num = $made_num + 1000;
		}
	}else{
		foreach($prizelist as $prize){
			$luck_num = mt_rand(0, 1000);
			$prob = intval($prize['percent']);
			if($luck_num >=  0 && $luck_num < $prob){
				$myprize = $prize;
				break;
			}
		}
	}
	if($myprize){
		if($myprize['prizetype'] == 2){//积分奖品处理流程
			updatemembercount($_G['uid'], array($myprize['prizecredittype'] => $myprize['prizecreditnum']), true, '', 0, '', $misign['title'], lang('plugin/k_misign', 'prize_type_2'));
		}elseif($myprize['prizetype'] == 3){//卡密奖品处理流程
			$kami = C::t("#k_misign#plugin_k_misign_prize_kami")->fetch_by_prizeid($myprize['prizeid']);
			notification_add($_G['uid'], 'k_misign', lang('plugin/k_misign', 'prize_kami_notice').$myprize['prizename'].'(&nbsp;'.$kami['message'].'&nbsp;)');
			C::t("#k_misign#plugin_k_misign_prize_kami")->update($kami['kid'], array('uid' => $_G['uid'], 'username' => $_G['username'], 'usetime' => $_G['timestamp']));
		}else{
			notification_add($_G['uid'], 'k_misign', lang('plugin/k_misign', 'prize_kami_notice').$myprize['prizename']);
		}
		C::t("#k_misign#plugin_k_misign_prize_log")->insert(array('uid' => $_G['uid'], 'username' => $_G['username'], 'prizeid' => $myprize['prizeid'], 'prizename' => $myprize['prizename'], 'dateline' => $_G['timestamp']));
		C::t("#k_misign#plugin_k_misign_prize")->update_by_todaylast($myprize['prizeid'], $myprize['todaylast']-1);
	}
}

if($misign['extends']['lastrule'] && $islasted){
	@require_once DISCUZ_ROOT.'./source/plugin/k_misign/language/extend_lastrule.'.currentlang().'.php';
	$exlang['lastrule'] = $extendlang;
	unset($extendlang);
	$lastreward = C::t("#k_misign#plugin_k_misign_lastrule")->fetch_by_lastday($lastnum);
	$lastreward2 = C::t("#k_misign#plugin_k_misign_lastrule")->fetch_by_lastday($lastnum, true);
	if($lastreward){
		$lastedrewardmsg = lang('plugin/k_misign', 'reward_lasted', array('lasted' => $lastnum));
		$lastreward['reward'] =str_replace(array("\r\n", "\n", "\r"), '/hhf/', $lastreward['reward']);
		$lastreward['rewards'] = explode("/hhf/", $lastreward['reward']);
		unset($lastreward['reward']);
		$lastedrewardcredits = null;
		foreach($lastreward['rewards'] as $k => $v){
			if($k){
				$lastedrewardcredits .= ',&nbsp;';
			}
			list($lastreward['reward'][$k]['type'],$lastreward['reward'][$k]['number']) = explode("|", $v);
			$lastedrewardcredits .= $lastreward['reward'][$k]['number'].'&nbsp;'.$_G['setting']['extcredits'][$lastreward['reward'][$k]['type']]['unit'].$_G['setting']['extcredits'][$lastreward['reward'][$k]['type']]['title'];
			updatemembercount($_G['uid'], array($lastreward['reward'][$k]['type'] => $lastreward['reward'][$k]['number']), true, '', 0, '', $misign['title'], $exlang['lastrule']['creditcomment']);
		}
		if($lastreward['rewards']){
			$lastedrewardmsg .= lang('plugin/k_misign', 'reward_lasted_credit', array('credit' => $lastedrewardcredits));
		}
		if($lastreward['relatedmedal']){
			$medallist = C::t("forum_medal")->fetch_all_name_by_available(1);
			$mymedal = C::t("common_member_field_forum")->fetch($_G['uid']);
			$mymedals = explode("\t", $mymedal['medals']);
			foreach($mymedals as $key => $mymedalv){
				if(strpos($mymedalv, '|')){
					$mymedalvarr = explode("|", $mymedalv);
					$mymedalv2 = $mymedalvarr[0];
				}else{
					$mymedalv2 = $mymedalv;
				}
				$mymedallist[$key] = $mymedalv2;
			}
			if(!in_array($lastreward['relatedmedal'],$mymedallist)){
				if($lastreward['relatedmedaldate']){
					$medalarray = array_insert($mymedals,$lastreward['relatedmedal'].'|'.(TIMESTAMP + $lastreward['relatedmedaldate']*86400),0);
				}else{
					$medalarray = array_insert($mymedals,$lastreward['relatedmedal'],0);
				}
				$medalnew = implode("\t", $medalarray);
				C::t("common_member_field_forum")->update($_G['uid'], array('medals' => $medalnew));
				C::t("forum_medallog")->insert(array('uid' =>$_G['uid'], 'medalid' => $lastreward['relatedmedal'], 'dateline' => TIMESTAMP, 'expiration' => (TIMESTAMP + $lastreward['relatedmedaldate']*86400), 'status' => ($lastreward['relatedmedaldate'] ? 1 : 0)));
				$lastedrewardmsg .= lang('plugin/k_misign', 'reward_lasted_medal', array('medal' => $medallist[$lastreward['relatedmedal']]['name']));
			}
		}
		notification_add($_G['uid'], 'system', $lastedrewardmsg, array(), 1);
	}elseif($lastreward2){
		$lastedreward2msg = lang('plugin/k_misign', 'reward_lasted', array('lasted' => $lastnum));
		$lastreward2['reward'] =str_replace(array("\r\n", "\n", "\r"), '/hhf/', $lastreward2['reward']);
		$lastreward2['rewards'] = explode("/hhf/", $lastreward2['reward']);
		unset($lastreward2['reward']);
		$lastedreward2credits = null;
		foreach($lastreward2['rewards'] as $k => $v){
			if($k){
				$lastedreward2credits .= ',&nbsp;';
			}
			list($lastreward2['reward'][$k]['type'],$lastreward2['reward'][$k]['number']) = explode("|", $v);
			$lastedreward2credits .= $lastreward2['reward'][$k]['number'].'&nbsp;'.$_G['setting']['extcredits'][$lastreward2['reward'][$k]['type']]['unit'].$_G['setting']['extcredits'][$lastreward2['reward'][$k]['type']]['title'];
			updatemembercount($_G['uid'], array($lastreward2['reward'][$k]['type'] => $lastreward2['reward'][$k]['number']), true, '', 0, '', $misign['title'], $exlang['lastrule']['creditcomment']);
		}
		if($lastreward2['rewards']){
			$lastedreward2msg .= lang('plugin/k_misign', 'reward_lasted_credit', array('credit' => $lastedreward2credits));
		}
		notification_add($_G['uid'], 'system', $lastedreward2msg, array(), 1);
	}
}

if($misign['extends']['totalrule']){
	@require_once DISCUZ_ROOT.'./source/plugin/k_misign/language/extend_totalrule.'.currentlang().'.php';
	$exlang['totalrule'] = $extendlang;
	unset($extendlang);
	$totalreward = C::t("#k_misign#plugin_k_misign_totalrule")->fetch_by_lastday($qiandaodb['days']+1);
	if($totalreward){
			$totalrewardmsg = lang('plugin/k_misign', 'yljqddays', array('days' => $qiandaodb['days']+1));
			$totalreward['reward'] =str_replace(array("\r\n", "\n", "\r"), '/hhf/', $totalreward['reward']);
			$totalreward['rewards'] = explode("/hhf/", $totalreward['reward']);
			unset($totalreward['reward']);
			$totalrewardcredits = null;
			foreach($totalreward['rewards'] as $k => $v){
				if($k){
					$totalrewardcredits .= ',&nbsp;';
				}
				list($totalreward['reward'][$k]['type'],$totalreward['reward'][$k]['number']) = explode("|", $v);
				$totalrewardcredits .= $totalreward['reward'][$k]['number'].'&nbsp;'.$_G['setting']['extcredits'][$totalreward['reward'][$k]['type']]['unit'].$_G['setting']['extcredits'][$totalreward['reward'][$k]['type']]['title'];
				updatemembercount($_G['uid'], array($totalreward['reward'][$k]['type'] => $totalreward['reward'][$k]['number']), true, '', 0, '', $misign['title'], $exlang['totalrule']['creditcomment']);
			}
			if($totalreward['rewards']){
				$totalrewardmsg .= lang('plugin/k_misign', 'reward_lasted_credit', array('credit' => $totalrewardcredits));
			}
			if($totalreward['relatedmedal']){
				$medallist = C::t("forum_medal")->fetch_all_name_by_available(1);
				$mymedal = C::t("common_member_field_forum")->fetch($_G['uid']);
				$mymedals = explode("\t", $mymedal['medals']);
				foreach($mymedals as $key => $mymedalv){
					if(strpos($mymedalv, '|')){
						$mymedalvarr = explode("|", $mymedalv);
						$mymedalv2 = $mymedalvarr[0];
					}else{
						$mymedalv2 = $mymedalv;
					}
					$mymedallist[$key] = $mymedalv2;
				}
				if(!in_array($totalreward['relatedmedal'],$mymedallist)){
					if($totalreward['relatedmedaldate']){
						$medalarray = array_insert($mymedals,$totalreward['relatedmedal'].'|'.(TIMESTAMP + $totalreward['relatedmedaldate']*86400),0);
					}else{
						$medalarray = array_insert($mymedals,$totalreward['relatedmedal'],0);
					}
					$medalnew = implode("\t", $medalarray);
					C::t("common_member_field_forum")->update($_G['uid'], array('medals' => $medalnew));
					C::t("forum_medallog")->insert(array('uid' =>$_G['uid'], 'medalid' => $totalreward['relatedmedal'], 'dateline' => TIMESTAMP, 'expiration' => (TIMESTAMP + $totalreward['relatedmedaldate']*86400), 'status' => ($totalreward['relatedmedaldate'] ? 1 : 0)));
					$totalrewardmsg .= lang('plugin/k_misign', 'reward_lasted_medal', array('medal' => $medallist[$totalreward['relatedmedal']]['name']));
				}
			}
			notification_add($_G['uid'], 'system', $totalrewardmsg, array(), 1);
	}
}

require_once libfile('function/post');
require_once libfile('function/forum');
if($misign['qdtype'] == '2') {
	$thread = C::t('forum_thread')->fetch($misign['tidnumber']);
	if($num >= 0 && ($row <= $extreward_num) && $ajaxcreditshow['ext']['type'] && $ajaxcreditshow['ext']['number']) {
		$message = lang('plugin/k_misign', 'tsn_extrac', array('time' => $hft, 'row' => $row, 'extrac' => $_G['setting']['extcredits'][$misign['nrcredit']]['title'].' '.$ajaxcreditshow['normal']['number'].' '.$_G['setting']['extcredits'][$misign['nrcredit']]['unit'], 'extrac2' => $_G['setting']['extcredits'][$ajaxcreditshow['ext']['type']]['title'].$ajaxcreditshow['ext']['number'].$_G['setting']['extcredits'][$ajaxcreditshow['ext']['type']]['unit']));
	} else {
		$message = lang('plugin/k_misign', 'tsn_noextrac', array('time' => $hft, 'extrac' => $_G['setting']['extcredits'][$misign['nrcredit']]['title'].' '.$ajaxcreditshow['normal']['number'].' '.$_G['setting']['extcredits'][$misign['nrcredit']]['unit']));
	}
	$pid = insertpost(array('fid' => $thread['fid'],'tid' => $misign['tidnumber'],'first' => '0','author' => $_G['username'],'authorid' => $_G['uid'],'subject' => '','dateline' => $_G['timestamp'],'message' => $message,'useip' => $_G['clientip'],'invisible' => '0','anonymous' => '0','usesig' => '0','htmlon' => '0','bbcodeoff' => '0','smileyoff' => '0','parseurloff' => '0','attachment' => '0',));
	C::t('forum_thread')->update($misign['tidnumber'], array('lastposter'=>$_G['username'],'lastpost'=>$_G['timestamp']));
	C::t('forum_thread')->increase($misign['tidnumber'], array('replies'=>1));
	updatepostcredits('+', $_G['uid'], 'reply', $thread['fid']);
	$lastpost = $thread['tid']."\t".addslashes($thread['subject'])."\t".$_G['timestamp']."\t".$_G['username'];
	C::t('forum_forum')->update($thread['fid'], array('lastpost' => $lastpost));
	C::t('forum_forum')->update_forum_counter($thread['fid'], 0, 1, 1);
	$tidnumber = $misign['tidnumber'];
}elseif($misign['qdtype'] == '3') {
	if($isfirst || $stats['qdtidnumber'] == '0') {
		$subject = str_replace(array('{m}','{d}','{y}','{bbname}'), array(dgmdate($_G['timestamp'], 'n',$misign['tos']),dgmdate($_G['timestamp'], 'j',$misign['tos']),dgmdate($_G['timestamp'], 'Y',$misign['tos']),$_G['setting']['bbname']), $misign['title_thread']);
		if($ajaxcreditshow['ext']['type'] && $ajaxcreditshow['ext']['number']) {
			$message = lang('plugin/k_misign', 'tsn_thread').lang('plugin/k_misign', 'tsn_extrac', array('time' => $hft, 'row' => $row, 'extrac' => $_G['setting']['extcredits'][$misign['nrcredit']]['title'].' '.$ajaxcreditshow['normal']['number'].' '.$_G['setting']['extcredits'][$misign['nrcredit']]['unit'], 'extrac2' => $_G['setting']['extcredits'][$ajaxcreditshow['ext']['type']]['title'].$ajaxcreditshow['ext']['number'].$_G['setting']['extcredits'][$ajaxcreditshow['ext']['type']]['unit']));
		} else {
			$message = lang('plugin/k_misign', 'tsn_thread').lang('plugin/k_misign', 'tsn_noextrac', array('time' => $hft, 'extrac' => $_G['setting']['extcredits'][$misign['nrcredit']]['title'].' '.$ajaxcreditshow['normal']['number'].' '.$_G['setting']['extcredits'][$misign['nrcredit']]['unit']));
		}
        $thread_param = array(
			'isgroup' => '0',
			'status' => '0',
			'closed' => '1',
			'highlight' => '1',
			'moderated' => '1',
			'attachment' => '0',
			'special' => '0',
			'digest' => '0',
			'displayorder' => '0',
			'lastposter' => $_G['username'],
			'lastpost' => $_G['timestamp'],
			'dateline' => $_G['timestamp'],
			'subject' => $subject,
			'authorid' => $_G['uid'],
			'author' => $_G['username'],
			'sortid' => '0',
			'typeid' => $misign['qdtypeid'],
			'price' => '0',
			'readperm' => '0',
			'posttableid' => '0',
			'fid' => $misign['fidnumber']
		);
		$tid = C::t("forum_thread")->insert($thread_param, true);
		C::t("#k_misign#plugin_k_misignset")->update('1', array('qdtidnumber'=>$tid));
		$pid = insertpost(array('fid' => $misign['fidnumber'],'tid' => $tid,'first' => '1','author' => $_G['username'],'authorid' => $_G['uid'],'subject' => $subject,'dateline' => $_G['timestamp'],'message' => $message,'useip' => $_G['clientip'],'invisible' => '0','anonymous' => '0','usesig' => '0','htmlon' => '0','bbcodeoff' => '0','smileyoff' => '0','parseurloff' => '0','attachment' => '0',));
		$expiration = $_G['timestamp'] + 86400;
		$threadmod_param1 = array(
			'tid' => $tid,
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'dateline' => $_G['timestamp'],
			'action' => 'EHL',
			'expiration' => $expiration,
			'status' => '1'
		);
		$threadmod_param2 = array(
			'tid' => $tid,
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'dateline' => $_G['timestamp'],
			'action' => 'CLS',
			'expiration' => '0',
			'status' => '1'
		);
		C::t('forum_threadmod')->insert($threadmod_param1);
		C::t('forum_threadmod')->insert($threadmod_param2);
		updatepostcredits('+', $_G['uid'], 'post', $misign['fidnumber']);
		$lastpost = $tid."\t".addslashes($subject)."\t".$_G['timestamp']."\t.".$_G['username'];
        C::t('forum_forum')->update($misign['fidnumber'], array('lastpost' => $lastpost));
        C::t('forum_forum')->update_forum_counter($misign['fidnumber'], 1, 1, 1);
		$tidnumber = $tid;
	} else {
		$tidnumber = $stats['qdtidnumber'];
		$thread = C::t('forum_thread')->fetch($tidnumber);
		if($num >=1 && ($row <= $extreward_num) && $ajaxcreditshow['ext']['type'] && $ajaxcreditshow['ext']['number']) {
			$message = lang('plugin/k_misign', 'tsn_extrac', array('time' => $hft, 'row' => $row, 'extrac' => $_G['setting']['extcredits'][$misign['nrcredit']]['title'].' '.$ajaxcreditshow['normal']['number'].' '.$_G['setting']['extcredits'][$misign['nrcredit']]['unit'], 'extrac2' => $_G['setting']['extcredits'][$ajaxcreditshow['ext']['type']]['title'].$ajaxcreditshow['ext']['number'].$_G['setting']['extcredits'][$ajaxcreditshow['ext']['type']]['unit']));
		} else {
			$message = lang('plugin/k_misign', 'tsn_noextrac', array('time' => $hft, 'extrac' => $_G['setting']['extcredits'][$misign['nrcredit']]['title'].' '.$ajaxcreditshow['normal']['number'].' '.$_G['setting']['extcredits'][$misign['nrcredit']]['unit']));
		}
		$pid = insertpost(array('fid' => $misign['fidnumber'],'tid' => $tidnumber,'first' => '0','author' => $_G['username'],'authorid' => $_G['uid'],'subject' => '','dateline' => $_G['timestamp'],'message' => $message,'useip' => $_G['clientip'],'invisible' => '0','anonymous' => '0','usesig' => '0','htmlon' => '0','bbcodeoff' => '0','smileyoff' => '0','parseurloff' => '0','attachment' => '0',));
		C::t('forum_thread')->update($tidnumber, array('lastposter'=>$_G['username'],'lastpost'=>$_G['timestamp']));
		C::t('forum_thread')->increase($tidnumber, array('replies'=>1));
		updatepostcredits('+', $_G['uid'], 'reply', $misign['fidnumber']);
		$lastpost = $tidnumber."\t".addslashes($thread['subject'])."\t".$_G['timestamp']."\t.".$_G['username'];
		C::t('forum_forum')->update($misign['fidnumber'], array('lastpost' => $lastpost));
		C::t('forum_forum')->update_forum_counter($misign['fidnumber'], 0, 1, 1);
	}
}

updatemembercount($_G['uid'], array($ajaxcreditshow['normal']['type'] => $ajaxcreditshow['normal']['number']), true, '', 0, '', $misign['title'], '');
if($ajaxcreditshow['ext']['type'] && $ajaxcreditshow['ext']['number']){
	updatemembercount($_G['uid'], array($ajaxcreditshow['ext']['type'] => $ajaxcreditshow['ext']['number']), true, '', 0, '', $misign['title'], '');
}

if($qiandaodb['mdays'] < dgmdate($_G['timestamp'], 'j', $misign['tos'])){
	C::t("#k_misign#plugin_k_misign")->update_signdata($_G['uid'], $ajaxcreditshow['normal']['number'], $row, $islasted);
}else{
	C::t("#k_misign#plugin_k_misign")->update_signdata_outmonth($_G['uid'], $ajaxcreditshow['normal']['number'], $row, $islasted);
}
if($misign['lockopen']) discuz_process::unlock('k_misign');
if($misign['memorystatus']) C::memory()->clear();

if($inwsq){
	if(defined('IN_MOBILE')){
		include template('diy:k_misign_index', '', 'source/plugin/k_misign/template/'.($misign['styles']['mobile'] ? $misign['styles']['mobile'] : 'mobile_default'));
	}else{
		include template('diy:k_misign_index', '', 'source/plugin/k_misign/template/'.($misign['styles']['pc'] ? $misign['styles']['pc'] : 'default'));
	}
	exit();
}else{
	if($_GET['format'] == 'json'){
		
	}elseif($_GET['format'] == 'global_usernav_extra'){
		include template('common/header_ajax');
		echo '<a href="'.$misign['pluginurl'].'sign" id="k_misign_topb"><img id="fx_checkin_b" src="source/plugin/k_misign/static/mini2.gif" alt="'.lang('plugin/k_misign', 'tdyq').'" style="position:relative;top:5px;height:18px;"></a>';
		include template('common/footer_ajax');
	}elseif($_GET['format'] == 'empty'){
		include template('common/header_ajax');
		echo '';
		include template('common/footer_ajax');
	}elseif($_GET['format'] == 'text'){
		include template('common/header_ajax');
		echo lang('plugin/k_misign', 'signed');
		include template('common/footer_ajax');
	}elseif($_GET['format'] == 'button'){
		$_GET['op'] = 'buttonreturn';
		if(defined('IN_MOBILE')){
			include_once libfile('button/'.$misign['extendb']['mobile_default'], 'plugin/k_misign');
		}else{
			include_once libfile('button/'.$misign['extendb']['default'], 'plugin/k_misign');
		}
	}
}