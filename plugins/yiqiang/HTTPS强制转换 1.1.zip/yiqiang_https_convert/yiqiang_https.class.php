<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_yiqiang_https_convert
{
    function global_yiqiang_https_convert()
    {
        global $_G;
        $request_scheme = $_SERVER['REQUEST_SCHEME'];
        $state = $_G['cache']['plugin']['yiqiang_https_convert']['state'];
        $force = $_G['cache']['plugin']['yiqiang_https_convert']['force'];
        if ($request_scheme == 'http' && $force) {
            $url = "https://{$_SERVER['HTTP_HOST']}";
            header("location: {$url}");
        }
        if ($request_scheme == 'https' && $state == 1) {
            $_G['isHTTPS'] = true;
            $_SERVER['HTTPS'] = 'on';
            $server_name = $_SERVER['SERVER_NAME'];
            $site_url = $_G['setting']['siteurl'];
            $style_default = $_G['cache']['style_default'];
            $img_dir = $_G['cache']['imgdir'];
            $u_center_url = $_G['setting']['ucenterurl'];
            $_G['siteurl'] = str_replace("http://", "https://", $_G['siteurl']);
            $_G['setting']['output']['str']['search'][] = 'http://' . $server_name;
            $_G['setting']['output']['str']['replace'][] = 'https://' . $server_name;
            $_G['setting']['siteurl'] = str_replace("http://", "https://", $site_url);
            $_G['cache']['style_default'] = 'https://' . $server_name . '/' . $style_default;
            $_G['cache']['imgdir'] = 'https://' . $server_name . '/' . $img_dir;
            $_G['setting']['ucenterurl'] = str_replace("http://", "https://", $u_center_url);
            $_G['setting']['discuzurl'] = str_replace("http://", "https://", $_G['setting']['discuzurl']);
            $_G['setting']['ucenterurl'] = str_replace("http://", "https://", $_G['setting']['ucenterurl']);
        }
    }
}
//From: Dism-taobao��com
?>