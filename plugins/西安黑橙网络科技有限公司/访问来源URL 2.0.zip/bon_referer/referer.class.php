<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * Version: 2.0
 * Date: 2019-7-7
 * From: Dism_taobao-com
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_bon_referer extends logic_bon_referer {
    function common() {
        $this->_run();
    }
}
class mobileplugin_bon_referer extends logic_bon_referer {
    function common() {
        $this->_run();
    }
}
class logic_bon_referer {
    private $_global;
    private $_server;
    private $_uid;
    private $_username;
    private $_fid;
    private $_mod;
    private $_tid;
    private $_url;
    private $_referer = null;
    private $_set;
    public function __construct() {
        global $_G;
        $this->_global   = $_G;
        $this->_server   = daddslashes($_SERVER);
        $this->_uid      = $_G['uid'];
        $this->_username = $_G['username'];
        $this->_fid      = $_G['fid'];
        $this->_mod      = $_G['mod'];
        $this->_tid      = $_G['tid'];
        $this->_url      = $_G['siteurl'];
        $this->_referer  = $this->_server['HTTP_REFERER'];
        $this->_set      = $_G['cache']['plugin']['bon_referer'];
    }
    public function _run() {
        if ($this->_set['switch'] && $this->_referer) {
            if ($this->_set['guest_switch']) {
                $this->_add();
            } elseif ($this->_uid) {
                $this->_add();
            }
        }
    }
    private function _add() {
        if ($this->_location()) {
            if (!$this->_logic()) {
                $data = array(
                    'referer'  => $this->_referer,
                    'url'      => $this->_url(),
                    'uid'      => $this->_uid,
                    'time'     => time()
                );
                C::t('#bon_referer#referer')->increase($data);
            }
        }
    }
    private function _location() {
        if ($this->_set['global_switch']) {
            return true;
        } else {
            $plate = unserialize($this->_set['section_switch']);
            if ($this->_set['portal_switch'] && CURSCRIPT == 'portal') {
                return true;
            } elseif ($this->_set['forum_switch'] && CURSCRIPT == 'forum' && empty($this->_mod)) {
                return true;
            } elseif ($plate[0] && $this->_fid) {
                foreach ($plate as $key => $val) {
                    if ($val == $this->_fid) {
                        if ($this->_mod == 'forumdisplay' && $this->_fid) {
                            return true;
                        } elseif ($this->_set['thread_switch'] && $this->_mod == 'viewthread' && $this->_tid) {
                            return true;
                        }
                    }
                }
            }
        }
    }
    private function _logic() {
        $scheme = array('http://', 'https://', 'ftp://');
        if (preg_match("#^$this->_url#i", $this->_referer)) {
            return true;
        } else {
            $exclude_domain = explode(PHP_EOL, $this->_set['exclude_domain']);
            if ($this->_set['exclude_domain']) {
                foreach ($exclude_domain as $val) {
                    if (substr($val, 0, 1) == '*') {
                        $regularly = preg_replace('#\*#', '([0-9a-zA-Z-.]+)', $val, 1);
                    } else {
                        $regularly = $val;
                    }
                    if (preg_match("#^$regularly#i", $this->_referer)) {
                        return true;
                    } else {
                        if (preg_match("#^$regularly#i", str_replace($scheme, null, $this->_referer))) {
                            return true;
                        }
                    }
                }
            }
        }
    }
    private function _url() {
        $scheme = $this->_global['scheme'] == 'http' ? 'http://' : 'https://';
        $file   = $this->_server['PHP_SELF'] ? $this->_server['PHP_SELF'] : $this->_server['SCRIPT_NAME'];
        $path   = isset($this->_server['PATH_INFO']) ? $this->_server['PATH_INFO'] : null;
        $url    = isset($this->_server['REQUEST_URI']) ? $this->_server['REQUEST_URI'] : $file . (isset($this->_server['QUERY_STRING']) ? '?' . $this->_server['QUERY_STRING'] : $path);
        $res    = $scheme . (isset($this->_server['HTTP_HOST']) ? $this->_server['HTTP_HOST'] : null) . $url;
        return $res;
    }
}