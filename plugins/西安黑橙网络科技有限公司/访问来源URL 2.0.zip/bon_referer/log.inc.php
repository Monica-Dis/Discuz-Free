<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * Version: 2.0
 * Date: 2019-7-7
 * From: Dism_taobao-com
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
$_get       = daddslashes($_GET);
$act        = trim($_get['act']);
$id         = trim($_get['id']);
$optype     = $_get['optype'];
$domain     = $_get['domain'];
$starttimes = $_get['starttimes'];
$endtimes   = $_get['endtimes'];
$starttimed = $_get['starttimed'];
$endtimed   = $_get['endtimed'];
$formhash   = $_get['formhash'];
$language   = lang('plugin/bon_referer');
if (empty($starttimes)) $starttimes = dgmdate(TIMESTAMP - 86400 * 7, 'Y-n-j');
if (empty($endtimes)) $endtimes = dgmdate(TIMESTAMP, 'Y-n-j');
if (empty($starttimed)) $starttimed = dgmdate(TIMESTAMP - 86400 * 7, 'Y-n-j');
if (empty($endtimed)) $endtimed = dgmdate(TIMESTAMP, 'Y-n-j');
$page     = max(1, intval($_get['page']));
$pagesize = 15;
$datalist = array();
$count    = C::t('#bon_referer#referer')->count();
$datalist = C::t('#bon_referer#referer')->fetch_all($page, $pagesize);
if (FORMHASH == $formhash && $act == 'del') {
    if ($id) {
        $result = C::t('#bon_referer#referer')->delete($id);
        if ($result) {
            cpmsg($language['delete_success'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=bon_referer&pmod=log', 'succeed');
        } else {
            cpmsg($language['delete_fail'], '', 'error');
        }
    } else {
        cpmsg($language['select_delete_data'], '', 'error');
    }
} elseif (FORMHASH == $formhash && $act == 'delete') {
    $_post = daddslashes($_POST);
    if ($_post['delete']) {
        C::t('#bon_referer#referer')->delete($_post['delete']);
        cpmsg($language['delete_success'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=bon_referer&pmod=log', 'succeed');
    } else {
        cpmsg($language['select_delete_data'], '', 'error');
    }
} elseif (FORMHASH == $formhash && $act == 'operating') {
    if ($optype == 'domainsearch') {
        if (preg_match('/^^((https|http|ftp)?:\/\/)[^\s]+$/', $domain)) {
            $where = "referer LIKE '$domain%'";
        } else {
            $where = "referer LIKE '%$domain%'";
        }
        $datalist = C::t('#bon_referer#referer')->fetch_all_search($page, $pagesize, $where);
        $count    = C::t('#bon_referer#referer')->count_search($where);
        $pages    = '&act=operating&optype=domainsearch&domain=' . $domain . '&formhash=' . FORMHASH;
    } elseif ($optype == 'datesearch') {
        $start    = strtotime($starttimes);
        $end      = strtotime($endtimes) + 86400;
        $where    = "time >= $start AND time <= $end";
        $datalist = C::t('#bon_referer#referer')->fetch_all_search($page, $pagesize, $where);
        $count    = C::t('#bon_referer#referer')->count_search($where);
        $pages    = '&act=operating&optype=datesearch&starttimes=' . $starttimes . '&endtimes=' . $endtimes . '&formhash=' . FORMHASH;
    } elseif ($optype == 'datedel') {
        $start  = strtotime($starttimed);
        $end    = strtotime($endtimed) + 86400;
        $where  = "time >= $start AND time <= $end";
        $result = C::t('#bon_referer#referer')->match_delete($where);
        if ($result) {
            cpmsg($language['delete_success'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=bon_referer&pmod=log', 'succeed');
        } else {
            cpmsg($language['select_delete_data'], '', 'error');
        }
    } elseif ($optype == 'emptied') {
        cpmsg($language['tips_empty_confirm'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=bon_referer&pmod=log&act=emptied', 'form');
    } else {
        cpmsg($language['tips_operation_method'], '', 'error');
    }
} elseif (FORMHASH == $formhash && $act == 'emptied') {
    C::t('#bon_referer#referer')->truncate();
    if ($count < 1) {
        cpmsg($language['empty_success'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=bon_referer&pmod=log', 'succeed');
    } else {
        cpmsg($language['tips_empty_loading'], '', 'loadingform');
    }
}
showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=bon_referer&pmod=log&act=delete');
showtableheader($language['referer_log']);
showsubtitle(array(
    '',
    $language['referer_url'],
    $language['visit_user'],
    $language['visit_time'],
    $language['delete']
));
foreach ($datalist as $key => $row) {
    if ($row['uid'] > 0) {
        if ($row['username']) {
            $username = '<a href="home.php?mod=space&uid=' . $row['uid'] . '" target="_blank">' . $row['username'] . '</a>';
        } else {
            $username = $language['user_nonexistence'];
        }
    } else {
        $username = $language['guest'];
    }
    showtablerow(null, array('width="35"', 'style="word-break:break-all;"', 'width="130"', 'width="150"', 'width="80"'), array(
        '<input type="checkbox" class="checkbox" name="delete[]" value="' . $row['id'] . '">',
        '<p>' . $row['referer'] . '</p><p><a href="' . $row['url'] . '" target="_blank">' . $row['url'] . '</a></p>',
        $username,
        date('Y-m-d H:i:s', $row['time']),
        '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&identifier=bon_referer&pmod=log&act=del&id=' . $row['id'] . '&formhash=' . FORMHASH . '">' . $language['delete'] . '</a>',
    ));
}
showsubmit('linksubmit', 'submit', 'del');
showtablefooter();
showformfooter();
echo multi($count, $pagesize, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=bon_referer&pmod=log$pages");
showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=bon_referer&pmod=log&act=operating');
showtableheader('operation');
showsubtitle(array('', $language['operation_method'], 'option'));
showtablerow(null, array('width="35"', 'width="100"', 'width="260"', 'class="vtop tips2"'), array(
    '<input type="radio" class="radio" name="optype" id="domainsearch" value="domainsearch" onclick="this.form.modsubmit.disabled=false;">',
    $language['search_by_domain'],
    '<input name="domain" value="' . $domain . '" type="text" class="txt" style="width:242px" onclick="$(\'domainsearch\').checked=\'checked\'">',
    $language['domain_format']
));
showtablerow(null, array(null, null, null, 'class="vtop tips2"'), array(
    '<input type="radio" class="radio" name="optype" id="datesearch" value="datesearch" onclick="this.form.modsubmit.disabled=false;">',
    $language['search_by_date'],
    '<input type="text" name="starttimes" value="' . $starttimes . '" class="txt" style="width:108px;margin-right:5px;" onclick="showcalendar(event, this);$(\'datesearch\').checked=\'checked\'"> -- <input type="text" name="endtimes" value="' . $endtimes . '" class="txt" style="width:100px;margin-left:5px;" onclick="showcalendar(event, this);$(\'datesearch\').checked=\'checked\'">',
    $language['date_format']
));
showtablerow(null, array(null, null, null, 'class="vtop tips2"'), array(
    '<input type="radio" class="radio" name="optype" id="datedel" value="datedel">',
    $language['batch_delete_by_date'],
    '<input type="text" name="starttimed" value="' . $starttimed . '" class="txt" style="width:108px;margin-right:5px;" onclick="showcalendar(event, this);$(\'datedel\').checked=\'checked\'"> -- <input type="text" name="endtimed" value="' . $endtimed . '" class="txt" style="width:100px;margin-left:5px;" onclick="showcalendar(event, this);$(\'datedel\').checked=\'checked\'">',
    $language['date_format']
));
showtablerow(null, null, array(
    '<input type="radio" class="radio" name="optype" value="emptied">',
    $language['empty_all_log'],
    '',
    ''
));
showsubmit('linksubmit', 'submit');