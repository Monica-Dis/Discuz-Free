<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * Version: 2.0
 * Date: 2019-7-7
 * From: Dism_taobao-com
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
dheader('location:https://DisM.taobao.com/?@80591.developer');