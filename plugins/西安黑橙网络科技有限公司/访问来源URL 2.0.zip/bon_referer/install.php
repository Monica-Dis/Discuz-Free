<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * Version: 2.0
 * Date: 2019-7-7
 * From: Dism_taobao-com
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS cdb_bon_referer (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `referer` mediumtext NOT NULL DEFAULT '',
  `url` mediumtext NOT NULL DEFAULT '',
  `uid` int(10) NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;
runquery($sql);
$finish = TRUE;