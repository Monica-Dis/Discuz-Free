<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * Version: 2.0
 * Date: 2019-7-7
 * From: Dism_taobao-com
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class table_referer extends discuz_table {
    public function __construct() {
        $this->_table = 'bon_referer';
        $this->_pk    = 'id';
        parent::__construct();
    }
    public function increase($data) {
        return DB::insert($this->_table, $data);
    }
    public function fetch_all($page, $limit = 10) {
        $sql = 'SELECT r.*,m.username FROM %t r LEFT JOIN %t m ON m.uid=r.uid ORDER BY %i' . DB::limit($page - 1, $limit);
        return DB::fetch_all($sql, array($this->_table, 'common_member', DB::order('time', 'DESC')));
    }
    public function fetch_all_search($page, $limit, $keyword = null) {
        $where = $keyword ? ' WHERE ' . $keyword : null;
        $sql = 'SELECT r.*,m.username FROM %t r LEFT JOIN %t m ON m.uid=r.uid %i ORDER BY %i' . DB::limit($page - 1, $limit);
        return DB::fetch_all($sql, array($this->_table, 'common_member', $where, DB::order('time', 'DESC')));
    }
    public function count_search($where) {
        return DB::result_first('SELECT COUNT(*) FROM %t WHERE %i', array($this->_table, $where));
    }
    public function match_delete($where) {
        return DB::delete($this->_table, $where);
    }
}