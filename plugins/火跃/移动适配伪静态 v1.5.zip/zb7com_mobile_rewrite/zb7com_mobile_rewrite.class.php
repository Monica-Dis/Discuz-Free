<?php
/**
 *      [lingjing.com!] (C)2001-2099 Comsenz Inc.
 *
 *      This is NOT a freeware, use is subject to xmowang.com
 *
 *      $Id: zb7com_mobile_rewrite.class.php  2016-10-25 14:37:28 huoyue $
 */


if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class mobileplugin_zb7com_mobile_rewrite {
	function mobileplugin_zb7com_mobile_rewrite() {	}

	public function common(){
		global $_G,$_ENV;
		require_once DISCUZ_ROOT.'./source/plugin/zb7com_mobile_rewrite/fun.inc.php';
		if(!empty($_ENV['curapp'])&& CURSCRIPT == 'forum'){
			if(!empty($_G['cache']['plugin']['zb7com_mobile_rewrite']['site_index'])){
				$url=$_G['cache']['plugin']['zb7com_mobile_rewrite']['site_index'];
//				dheader('Location:'.$_G['cache']['plugin']['huoyue_mobile_rewrite']['site_index']);
			}else if( CURSCRIPT =='forum' && $_G['setting']['mobile']['mobilehotthread'] && CURMODULE == 'index' && $_GET['forumlist'] != 1){
				$url='forum.php?mod=guide&view=hot';
			}
			if($url){
				$urls=parse_url($url);
				$queryParts = explode('&', $urls['query']);
			    $params = array();
			    foreach ($queryParts as $param) {
			        $item = explode('=', $param);
			        $_GET[$item[0]] = $item[1];
			    }
				unset($_ENV);
				if($urls['path']=='forum.php'){
					$mod = $_GET['mod'];
					if($_GET['fid']>0 || $_GET['tid']>0){
						loadforum();
					}
					if($_GET['mod']=='forumdisplay'){
						$cachelist = array('smilies', 'announcements_forum', 'globalstick', 'forums','onlinelist', 'forumstick', 'threadtable_info', 'threadtableids', 'stamps', 'diytemplatenameforum');
						loadcache($cachelist);
					}
					require DISCUZ_ROOT.'./source/module/forum/forum_'.$mod.'.php';
				}elseif($urls['path']=='portal.php'){
					$cachelist = array('userapp', 'portalcategory', 'diytemplatenameportal');
					loadcache($cachelist);
					if(empty($_GET['mod']) || !in_array($_GET['mod'], array('list', 'view', 'comment', 'portalcp', 'topic', 'attachment', 'rss', 'block'))) $_GET['mod'] = 'index';
					$mod = $_GET['mod'];
					$_G['basescript'] = 'portal';
					require DISCUZ_ROOT.'./source/function/function_home.php';
					require DISCUZ_ROOT.'./source/function/function_portal.php';
					require DISCUZ_ROOT.'./source/module/portal/portal_'.$mod.'.php';
				}else{
					header("HTTP/1.1 301 Moved Permanently");
					header('Location:'.$_G['cache']['plugin']['zb7com_mobile_rewrite']['site_index']);
				}
				huoyue_mobile_rewrite();
				exit;
			}
		}
	}	
	function global_footer_mobile(){
		global $_G,$multipage;
		if($multipage){
			preg_match ('/href="(.*?)"/' , $multipage, $matches);
			$pages=explode('{page}', $_G['lang']['core']['page']);
$html=<<<EOT
<script type="text/javascript">
$(document).ready(function() {
	if($('#dumppage').length > 0) {
		$('#dumppage').unbind('change').change(function() {
			var href = '$matches[1]'.replace(/amp;/g,'');
			window.location.href = href.replace(/page=\d+/, 'page=' + $(this).val());
		});
	}
});
</script>
EOT;
			return $html;
		}
	}
}

//DISM.Taobao.COM
?>