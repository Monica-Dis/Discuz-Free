<?php
/*
*      [Huoyue.org!] (C)2014-2099 Huoyue.org Email:4767960@qq.com QQ:4767960.
*
*      This is NOT a freeware, Authorized by huoyue.org to use
*
*      $File:huoyue_a1166.class.php 2014-08-29 10:36:44 Huoyue $


*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function huoyue_rewritedata($alldata = 1) {
	global $_G;
	$data = array();
	if(!$alldata) {
		if(in_array('portal_topic', $_G['setting']['rewritestatus'])) {
			$data['search']['portal_topic'] = "/".$_G['domain']['pregxprw']['portal']."\?mod\=topic&(amp;)?topic\=([^#]+?)?\"([^\>]*)\>/e";
			$data['replace']['portal_topic'] = "rewriteoutput('portal_topic', 0, '\\1', '\\3', '\\4')";
		}

		if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
			$data['search']['portal_article'] = "/".$_G['domain']['pregxprw']['portal']."\?mod\=view&(amp;)?aid\=(\d+)(&amp;page\=(\d+))?\"([^\>]*)\>/e";
			$data['replace']['portal_article'] = "rewriteoutput('portal_article', 0, '\\1', '\\3', '\\5', '\\6')";
		}

		if(in_array('forum_forumdisplay', $_G['setting']['rewritestatus'])) {
			$data['search']['forum_forumdisplay'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&amp;page\=(\d+))?\"([^\>]*)\>/e";
			$data['replace']['forum_forumdisplay'] = "rewriteoutput('forum_forumdisplay', 0, '\\1', '\\3', '\\5', '\\6')";
		}

		if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$data['search']['forum_viewthread'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)(&amp;extra\=(page\%3D(\d+))?)?(&amp;page\=(\d+))?\"([^\>]*)\>/e";
			$data['replace']['forum_viewthread'] = "rewriteoutput('forum_viewthread', 0, '\\1', '\\3', '\\8', '\\6', '\\9')";
		}

		if(in_array('group_group', $_G['setting']['rewritestatus'])) {
			$data['search']['group_group'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=group&(amp;)?fid\=(\d+)(&amp;page\=(\d+))?\"([^\>]*)\>/e";
			$data['replace']['group_group'] = "rewriteoutput('group_group', 0, '\\1', '\\3', '\\5', '\\6')";
		}

		if(in_array('home_space', $_G['setting']['rewritestatus'])) {
			$data['search']['home_space'] = "/".$_G['domain']['pregxprw']['home']."\?mod=space&(amp;)?(uid\=(\d+)|username\=([^&]+?))\"([^\>]*)\>/e";
			$data['replace']['home_space'] = "rewriteoutput('home_space', 0, '\\1', '\\4', '\\5', '\\6')";
		}

		if(in_array('home_blog', $_G['setting']['rewritestatus'])) {
			$data['search']['home_blog'] = "/".$_G['domain']['pregxprw']['home']."\?mod=space&(amp;)?uid\=(\d+)&(amp;)?do=blog&(amp;)?id=(\d+)\"([^\>]*)\>/e";
			$data['replace']['home_blog'] = "rewriteoutput('home_blog', 0, '\\1', '\\3', '\\6', '\\7')";
		}

		if(in_array('forum_archiver', $_G['setting']['rewritestatus'])) {
			$data['search']['forum_archiver'] = "/<a href\=\"\?(fid|tid)\-(\d+)\.html(&page\=(\d+))?\"([^\>]*)\>/e";
			$data['replace']['forum_archiver'] = "rewriteoutput('forum_archiver', 0, '\\1', '\\2', '\\4', '\\5')";
		}

		if(in_array('plugin', $_G['setting']['rewritestatus'])) {
			$data['search']['plugin'] = "/<a href\=\"plugin\.php\?id=([a-z]+[a-z0-9_]*):([a-z0-9_\-]+)(&amp;|&)?(.*?)?\"([^\>]*)\>/e";
			$data['replace']['plugin'] = "rewriteoutput('plugin', 0, '\\1', '\\2', '\\3', '\\4', '\\5')";
		}
	} else {
		$data['rulesearch']['portal_topic'] = 'topic-{name}.html';
		$data['rulereplace']['portal_topic'] = 'portal.php?mod=topic&topic={name}';
		$data['rulevars']['portal_topic']['{name}'] = '(.+)';

		$data['rulesearch']['portal_article'] = 'article-{id}-{page}.html';
		$data['rulereplace']['portal_article'] = 'portal.php?mod=view&aid={id}&page={page}';
		$data['rulevars']['portal_article']['{id}'] = '([0-9]+)';
		$data['rulevars']['portal_article']['{page}'] = '([0-9]+)';

		$data['rulesearch']['forum_forumdisplay'] = 'forum-{fid}-{page}.html';
		$data['rulereplace']['forum_forumdisplay'] = 'forum.php?mod=forumdisplay&fid={fid}&page={page}';
		$data['rulevars']['forum_forumdisplay']['{fid}'] = '(\w+)';
		$data['rulevars']['forum_forumdisplay']['{page}'] = '([0-9]+)';

		$data['rulesearch']['forum_viewthread'] = 'thread-{fid}-{tid}-{page}-{prevpage}.html';
		$data['rulereplace']['forum_viewthread'] = 'forum.php?mod=viewthread&tid={tid}&extra=page\%3D{prevpage}&page={page}';
		$data['rulevars']['forum_viewthread']['{fid}'] = '([0-9]+)';
		$data['rulevars']['forum_viewthread']['{tid}'] = '([0-9]+)';
		$data['rulevars']['forum_viewthread']['{page}'] = '([0-9]+)';
		$data['rulevars']['forum_viewthread']['{prevpage}'] = '([0-9]+)';

		$data['rulesearch']['group_group'] = 'group-{fid}-{page}.html';
		$data['rulereplace']['group_group'] = 'forum.php?mod=group&fid={fid}&page={page}';
		$data['rulevars']['group_group']['{fid}'] = '([0-9]+)';
		$data['rulevars']['group_group']['{page}'] = '([0-9]+)';

		$data['rulesearch']['home_space'] = 'space-{user}-{value}.html';
		$data['rulereplace']['home_space'] = 'home.php?mod=space&{user}={value}';
		$data['rulevars']['home_space']['{user}'] = '(username|uid)';
		$data['rulevars']['home_space']['{value}'] = '(.+)';

		$data['rulesearch']['home_blog'] = 'blog-{uid}-{blogid}.html';
		$data['rulereplace']['home_blog'] = 'home.php?mod=space&uid={uid}&do=blog&id={blogid}';
		$data['rulevars']['home_blog']['{uid}'] = '([0-9]+)';
		$data['rulevars']['home_blog']['{blogid}'] = '([0-9]+)';

		$data['rulesearch']['forum_archiver'] = '{action}-{value}.html';
		$data['rulereplace']['forum_archiver'] = 'index.php?action={action}&value={value}';
		$data['rulevars']['forum_archiver']['{action}'] = '(fid|tid)';
		$data['rulevars']['forum_archiver']['{value}'] = '([0-9]+)';

		$data['rulesearch']['plugin'] = '{pluginid}-{module}.html';
		$data['rulereplace']['plugin'] = 'plugin.php?id={pluginid}:{module}';
		$data['rulevars']['plugin']['{pluginid}'] = '([a-z]+[a-z0-9_]*)';
		$data['rulevars']['plugin']['{module}'] = '([a-z0-9_\-]+)';
	}
	return $data;
}
function huoyue_rewriteoutput($pre, $host,$curscript,$query, $extra) {
	global $_G;
	$data = huoyue_rewritedata();
	$rewritestatus=$_G['cache']['plugin']['zb7com_mobile_rewrite'];
	$fextra = '';
	$querys=str_replace('&amp;','&',$query);
	list($querys,$anchor)=explode('#',$querys);
	$anchor=$anchor ? '#'.$anchor : ''; 
	parse_str($querys,$urlarr);
	$mod=$urlarr['mod'];
	$page=$urlarr['page'] ? intval($urlarr['page']) : 1;
	if(empty($urlarr['mobile'])||$urlarr['mobile']==2){
		if($curscript == 'forum') {
			if($mod == 'forumdisplay'&&empty($urlarr['filter'])) {
				$type = 'forum_forumdisplay';
				$fid=intval($urlarr['fid']);
				$r = array(
					'{fid}' => empty($_G['setting']['forumkeys'][$fid]) ? $fid : $_G['setting']['forumkeys'][$fid],
					'{page}' => $page,
				);
				if($page==1&&$rewritestatus['forum_forumdisplay_index']){
					$type = 'forum_forumdisplay_index';
				}
			} elseif($mod == 'viewthread'&&empty($urlarr['from'])&&empty($urlarr['authorid'])) {
				$type = 'forum_viewthread';
				$r = array(
					'{tid}' => intval($urlarr['tid']),
					'{page}' => $page,
					'{prevpage}' => $urlarr['extra']&&!IS_ROBOT && substr($urlarr['extra'],0,7)=='page%3D' ? intval(substr($urlarr['extra'],7)) : 1
				);
				if($page==1&&$rewritestatus['forum_viewthread_index']){
					$type = 'forum_viewthread_index';
					unset($r['{prevpage}']);
				}
			}elseif($mod == 'group'&&$urlarr['fid']>0) {
				$type = 'group_group';
				$r = array(
					'{fid}' => intval($urlarr['fid']),
					'{page}' => $page,
				);
			}
		}elseif($curscript == 'home') {
			if($mod == 'space'&&empty($urlarr['mycenter'])&&(empty($urlarr['do'])||$urlarr['do']=='profile')) {
				$type = 'home_space';
				$uid=intval($urlarr['uid']);
				$username=$urlarr['username'];
				$_G['setting']['rewritecompatible'] && $username = rawurlencode($username);
				$r = array(
					'{user}' => $uid ? 'uid' : 'username',
					'{value}' => $uid ? $uid : $username,
				);
			}
		}elseif($curscript == 'portal') {
			if($mod == 'topic') {
				$type = 'portal_topic';
				$r = array(
					'{name}' => $urlarr['username'],
				);
			} elseif($mod == 'view') {
				$type = 'portal_article';
				$r = array(
					'{id}' => intval($urlarr['aid']),
					'{page}' => $page,
				);
			}
		}
	}
	$href = $rewritestatus[$type] && $r ? str_replace(array_keys($r), $r, $rewritestatus[$type]) : $curscript.'.php?'.$query;
	if(!$returntype) {
		if($type == 'forum_viewthread' && strpos($rewritestatus[$type],"{fid}")!==false){
			$_G['huoyue_fids'][intval($urlarr['tid'])]='href="'.$host.$href.$anchor.'"';
		}
		return '<a  href="'.$host.$href.$anchor.'" '.(!empty($pre) ? stripslashes($pre) : '').' '.(!empty($extra) ? stripslashes($extra) : '').' >';
	} else {
		return $host.$href;
	}
}
function huoyue_rewriteoutput_callback($matches) {
	return huoyue_rewriteoutput($matches[1], $matches[2], $matches[3], $matches[4], $matches[5]);
}
function huoyue_mobile_rewrite(){
	global $_G;
	$content = ob_get_contents();
	$content = preg_replace_callback('/<a ([^\>]*?)href\=[\'"]([^"\'\>]*?)(forum|portal|group|home)\.php\?([^"\'\>]*?)[\'"](\s+[^\>]*?)?\>/', "huoyue_rewriteoutput_callback", $content);
	if(!empty($_G['huoyue_fids'])){
		$fids=DB::fetch_all('SELECT fid,tid FROM %t WHERE tid IN(%n)', array('forum_thread', array_keys($_G['huoyue_fids'])),'tid');
		foreach ($_G['huoyue_fids'] as $tid=>$value) {
			$fid=$fids[$tid]['fid'];
			$searchs[$tid]=$value;
			$replaces[$tid]=str_replace('{fid}',  empty($_G['setting']['forumkeys'][$fid]) ? $fid : $_G['setting']['forumkeys'][$fid], $value);
		} 
		$content = str_replace($searchs,$replaces,$content);
	}
	ob_end_clean();
	$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
	echo $content;
}
?>