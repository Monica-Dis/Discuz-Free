<?php

/* 
*
*      �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧��
*
*      $File: zb7com_milists.inc.php 2016-12-10 23:43:32 Huoyue $
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!function_exists('procthread')){
	require_once libfile('function/misc');
}
loadcache(array('forums','stamps'));
$settings = $_G['cache']['plugin']['zb7com_milists'];
$inforum=array_filter(dunserialize($settings['available_forum']));
$page=intval($_GET['page']);
$perpage = $settings['pagenums'];
$page=$page>0 ? $page : 1;
$perpage=$perpage>0 ? $perpage : 5;
$start=($page-1)*$perpage;
$sql = "  readperm='0' AND isgroup='0' AND displayorder>='0'";
if($inforum){
	$sql = DB::field('fid',$inforum)."  AND ".$sql;
}
$types=array('hot','digest','reply','newthread');
$type=in_array($_GET['type'],$types) ? $_GET['type'] : $settings['defaultshow'] ;
$orderby	= 'tid';
switch ($type) {
	case 'hot' :
	$sql = "  heats>=".$_G['setting']['heatthread']['guidelimit']."  AND ".$sql;
	break;
	case 'digest' :
	$sql = " digest>0  AND ".$sql;
	break;
	case 'reply' :
	$orderby = 'lastpost';
	break;
}
$count = DB::result_first("SELECT COUNT(*) FROM `".DB::table('forum_thread')."`  WHERE  $sql ORDER BY tid DESC");
if($page<=$settings['cachepages']){
	$cache = $_G['cache']['zb7com_milists'][$type.'_'.$page];
}
if($cache && (TIMESTAMP - $cache['cachetime']) < $settings['cachetimes']) {
	$tids = $cache['data'];
	$updatecache = false;
	$lists = DB::fetch_all("SELECT * FROM `".DB::table('forum_thread')."`   WHERE ".DB::field('tid',$tids)." ORDER BY $orderby DESC LIMIT $start,$perpage");
}else{
	$updatecache = true;
	$lists = DB::fetch_all("SELECT * FROM `".DB::table('forum_thread')."`   WHERE  $sql ORDER BY $orderby DESC LIMIT $start,$perpage");
}
if($count>0){
	foreach($lists as $key=>$row){
		$lists[$key] = procthread($row);
		$threadids[$value['tid']]=$value['tid'];
	}	
}
$multipage = multi($count, $perpage, $_G['page'], 'plugin.php?id=zb7com_milists&type='.$type, $_G['setting']['threadmaxpages']);
$types_lang=lang('plugin/zb7com_milists','types');
if($updatecache && $page<=$settings['cachepages']) {
	$threadcount = count($threadids);
	$data = array('cachetime' => TIMESTAMP, 'data' => $threadids);
	$_G['cache']['zb7com_milists'][$type.'_'.$page] = $data;
	savecache('zb7com_milists', $_G['cache']['mobile_index']);
}

$navtitle = helper_seo::get_title_page($settings['navtitle'], $_G['page']);
$metakeywords = $settings['metakeywords'];
$metadescription = $settings['metadescription'];
include template('diy:list', null, 'source/plugin/zb7com_milists/template');
?>