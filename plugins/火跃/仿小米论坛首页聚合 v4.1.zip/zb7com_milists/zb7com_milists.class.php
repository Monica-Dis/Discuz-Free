<?php
/* 
*
*      �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧��
*
*      $File: zb7com_milists.class.php 2016-12-10 23:43:15 Huoyue $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_zb7com_milists {
	
	public function common(){
		global $_G;
		$settings = $_G['cache']['plugin']['zb7com_milists'];		
		if($_G['setting']['rewritestatus']&&$_G['cache']['plugin']['zb7com_milists']['rewriteurl']) {
			require_once DISCUZ_ROOT.'./source/discuz_version.php';
			if(DISCUZ_VERSION>='X3.4'){
				$_G['setting']['output']['preg']['search']['zb7com_milists'] = '/<a ([^"\'>]*?)href\="([^"\']*?)plugin\.php\?id\=zb7com_milists(&[^"\'>]*?)?"(\s+[^\>]*)?\>/i';
				$_G['setting']['output']['preg']['replace']['zb7com_milists'] = 'zb7com_milists_rewriteoutput($matches[1],$matches[2],$matches[3],$matches[4])';			
			}else{
				$_G['setting']['output']['preg']['search']['zb7com_milists'] = '/<a ([^"\'>]*?)href\="([^"\']*?)plugin\.php\?id\=zb7com_milists(&[^"\'>]*?)?"(\s+[^\>]*)?\>/ei';
				$_G['setting']['output']['preg']['replace']['zb7com_milists'] = "zb7com_milists_rewriteoutput('\\1', '\\2', '\\3', '\\4')";
			}
		}
	}
}

class plugin_zb7com_milists_portal extends plugin_zb7com_milists {
	function index_list(){
		global $_G;
		if($_G['cache']['plugin']['zb7com_milists']['index']==2){
			$_G['basescript']='plugin';
			$theurl='portal.php';
			require_once DISCUZ_ROOT.'./source/plugin/zb7com_milists/zb7com_milists.inc.php';
			exit;
		}
	}
}
class plugin_zb7com_milists_forum extends plugin_zb7com_milists {
	function index_list(){
		global $_G;
		if($_G['cache']['plugin']['zb7com_milists']['index']==1){
			$_G['basescript']='plugin';
			$theurl='forum.php';
			require_once DISCUZ_ROOT.'./source/plugin/zb7com_milists/zb7com_milists.inc.php';
			exit;
		}
	}
}
function zb7com_milists_rewriteoutput($pre, $host,$query, $extra) {
	global $_G;
	$nohref = 0;
	$fextra = '';
	$querys=str_replace('&amp;','&',$query);
	parse_str($querys,$urlarr);
	$page=$urlarr['page'] ? intval($urlarr['page']) : 1;
	$types=array('hot','digest','reply','newthread');
	$type=in_array($urlarr['type'],$types) ? $urlarr['type'] : $_G['cache']['plugin']['zb7com_milists']['defaultshow'] ;
	$r = array(
	'{type}' => $type,
	'{page}' => $page,
	);
	$href =str_replace(array_keys($r), $r, $_G['cache']['plugin']['zb7com_milists']['rewriteurl']);
	return '<a  href="'.$host.$href.'" '.(!empty($pre) ? stripslashes($pre) : '').' '.(!empty($extra) ? stripslashes($extra) : '').' >';
}
//From: Dism��taobao��com
?>