<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$uid = $_G['uid'];
$tid = intval($_GET['tid']);
$payurl = $_G['cache']['plugin']['mine_video']['mine_video_payurl'];

if($tid<=0||$uid<=0){
    echo'error';exit;
}
//��Ƶ�۸�
$videoprice = DB::result_first("select message from " . DB::table('forum_post') ." where tid=$tid and first=1");
preg_match('/\[mine_video.*\]\[\/mine_video\]/is', $videoprice, $vps);$vps=$vps[0];

preg_match('/score=&quot;([^&]*)/is', $vps, $score);$videoprice = $score[1];
if(!$score){preg_match('/score="([^"]*)/is', $vps, $score);$videoprice = $score[1];}
preg_match('/scoretp=&quot;([^&]*)/is', $vps, $scoretp);$scoretype = $scoretp[1];
if(!$scoretype){preg_match('/scoretp="([^"]*)/is', $vps, $scoretp);$scoretype = $scoretp[1];}
if(!$scoretype)$scoretype = $_G['cache']['plugin']['mine_video']['mine_video_scoretype'];
$scoretypename = $_G["setting"]["extcredits"][$scoretype]['title'];
if(!$score)$videoprice = 0;
//�û����
//if(isset($_GET['action'])&&$_GET['action']=='buy'){
    if(!$uid){
        header('location:'.$_G['siteroot'].'/member.php?mod=logging&action=login&mobile=2');exit;
    }
    else{
        $buyrec = DB::result_first("select id from " . DB::table('mine_video_buyrecord') ." where uid=$uid and tid=$tid");
        
		$usermoney = DB::result_first("select extcredits".$scoretype." from " . DB::table('common_member_count') ." where uid=$uid");
        if($buyrec){
            header('location:'.$_G['siteroot'].'forum.php?mod=viewthread&tid='.$tid.'&mobile=2');
        }
		elseif(intval($videoprice)>intval($usermoney)){
			showmessage($scoretypename.lang('plugin/mine_video', 'buzu').'<br /><a href="'.$_G['cache']['plugin']['mine_video']['mine_video_payurl'].'">'.lang('plugin/mine_video', 'mine_jfcz').'</a>', array(), array(), array('alert' => 'error'));
		}
        else{
			$buyrec = array('uid'=>$uid,'tid'=>$tid,'money'=>$videoprice,'CreateTime'=>time());
			updatemembercount($uid, array($scoretype=>-$videoprice), true, '', $tid, '', '��Ƶ����', '��Ƶ��������id��'.$tid);
			DB::insert('mine_video_buyrecord',$buyrec, false, false);
			echo'<script>alert("'.lang('plugin/mine_video','buysuccess').'");location.href="'.$_G['siteroot'].'forum.php?mod=viewthread&tid='.$tid.'&mobile=2";</script>';
        }
    }
//}



//include template('mine_video:pay');
//TODO - Insert your code here
?>