<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

global $_G;

loadcache('plugin');
loadcache('pluginlanguage_template');
loadcache('pluginlanguage_script');

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$operation = $_GET['operation'];
$do = $_GET['do'];


if(submitcheck('minesubmit')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		//DB::delete('mine_video', "id=$delid");
		DB::delete('mine_video_buyrecord', "id=$delid");
		$del=$del+1;
	}
	cpmsg(lang('plugin/mine_video', 'deletetips').$del,"action=plugins&operation=config&do=$do&identifier=$identifier&pmod=buyrecord&do=$do&page=$page", 'succeed');
}

showformheader('plugins&operation='.$operation.'&do=' . $do . '&identifier='.$identifier.'&pmod=buyrecord', 'submit');
showtableheaders(lang('plugin/mine_video', 'mvadmintips1'));

	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('mine_video_buyrecord')." WHERE 1 ");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$do&identifier=$identifier&pmod=admin");
	
	showtableheader(); /*dis'.'m.tao'.'bao.com*/
	showtablerow('', array('class="td25"', '', '', 'class="td25"', 'class="td28"'), array('', lang('plugin/mine_video', 'mvtitle'),lang('plugin/mine_video', 'buyprice'),lang('plugin/mine_video', 'mvauthor'),lang('plugin/mine_video', 'mvbuyer'),lang('plugin/mine_video', 'mvbuytime')));

	$query = DB::query("SELECT * FROM ".DB::table('mine_video_buyrecord')." WHERE 1 LIMIT $startlimit, $ppp");
	while($mine_video_t = DB::fetch($query)) {		
			$mine_video_td2='<a href="forum.php?mod=viewthread&tid='.$mine_video_t['tid'].'" target="_blank">'.mine_video_subject($mine_video_t['tid']).'</a>';
			$mine_video_td3='<a href="home.php?mod=space&uid='.mine_video_buysaleid($mine_video_t['tid']).'" target="_blank">'.mine_video_getusername(mine_video_buysaleid($mine_video_t['tid'])).'</a>';
			$mine_video_td5='<a href="home.php?mod=space&uid='.$mine_video_t['uid'].'" target="_blank">'.mine_video_getusername($mine_video_t['uid']).'</a>';
		showtablerow('', array('class="td25"', '', '', '',  'class="td25"', 'class="td28"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$mine_video_t['Id']."\"><input type=\"hidden\" name=\"id".$mine_video_t['Id']."\" value=\"".$mine_video_t['Id']."\">",
			$mine_video_td2,
			$mine_video_t['money'],
			$mine_video_td3,
			$mine_video_td5,
			date('Y-m-d H:i:s', $mine_video_t['CreateTime']),
		));
	}
	
	function mine_video_subject($tid){
	   if($reject=DB::result_first("select subject from ".DB::table('forum_thread')." where tid=".$tid)){
	       return $reject;
        }else{
             return lang('plugin/mine_video', 'admin8');
        }
	}
	
	function mine_video_buysaleid($tid){
	   if(!$tid){
	        return lang('plugin/mine_video', 'admin9');
	   }else{
		return DB::result_first("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid=".$tid);
        }
		
	}
	
	function mine_video_getusername($uid){
	   if(!$uid){
	        return lang('plugin/mine_video', 'admin9');
	   }else{
		return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
        }
	}
	
	function showtableheaders($title = '', $classname = '', $extra = '', $titlespan = 15) {
	global $_G;
	$classname = str_replace(array('nobottom', 'notop'), array('nobdb', 'nobdt'), $classname);
	if(isset($_G['showsetting_multi'])) {
		if($_G['showsetting_multi'] == 0) {
			$extra .= ' style="width:'.($_G['showsetting_multicount'] * 270 + 20).'px"';
		} else {
			return;
		}
	}
	echo "\n".'<table class="tb tb2 '.$classname.'"'.($extra ? " $extra" : '').' style="clear: both;margin-top: 5px;width: 100%">';
	if($title) {
		$span = $titlespan ? 'colspan="'.$titlespan.'"' : '';
		echo "\n".'<tr><th '.$span.' class="partition">'.cplang($title).'</th></tr>';
		showmultititle(1);
	}
}
	
	showsubmit('minesubmit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*DISM-TAOBAO-COM*/
?>