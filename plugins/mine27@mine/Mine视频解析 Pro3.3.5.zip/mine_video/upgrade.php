<?php
/**
 *      [Mine��Ȩϵͳ] by mine27.
 *		QQ 995525477
 *      
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_mine_video_uploadrecord` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) DEFAULT NULL,
  `localpath` varchar(255) DEFAULT NULL,
  `aliyunvideoid` varchar(255) DEFAULT NULL,
  `createtime` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM;


EOF;
if(version_compare($fromversion, 'Pro3.2.9', '<'))runquery($sql);

$finish = TRUE;
?>