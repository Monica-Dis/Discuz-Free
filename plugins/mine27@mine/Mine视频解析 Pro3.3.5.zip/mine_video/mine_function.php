<?php
/**
 *	Ӧ�ø���֧�֣�https://dism.taobao.com
 *	���²����http://t.cn/Aiux1Jx1
 *	Date: 2016/8/22 ����һ
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function MineGetPlayers($players){
	$players = explode("\n", $players);
	$arr = array();
	foreach($players as $p){
		if($p){
			$tmp = explode('==', $p);
			if(count($tmp)>=2){
				$arr[$tmp[0]] = str_replace(array("\r", "\n"), "", $tmp[1]);
				$arr[$tmp[0].'_api'] = isset($tmp[2])?str_replace(array("\r", "\n"), "", $tmp[2]):'';
			}
		}
	}
	return $arr;
}
function gstr($str, $charset='UTF-8'){
	$encode = mb_detect_encoding( $str, array('ASCII','UTF-8','GB2312','GBK'));
	if ( $encode != $charset ){
		$str = iconv($encode,$charset.'//IGNORE',$str);
	}
	return $str;
}
function MineGetVid($vid){
	preg_match('/<a href="([^"]+?)"/is', $vid, $v);
	if($v)return $v[1];
	return $vid;
}
function mine_video_getmessage($tid){
	if(!$tid){
		return '';
	}else{
		return DB::result_first("SELECT message FROM ".DB::table('forum_post')." WHERE tid=".$tid);
	}
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>