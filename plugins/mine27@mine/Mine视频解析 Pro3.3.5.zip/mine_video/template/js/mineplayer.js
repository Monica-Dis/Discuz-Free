function MinePlayer(pid){
	this.Num = 0;
	this.pid = pid;
	this.Videos=eval('minevideo_vids_'+pid);
	for(var vg in this.Videos){
		this.vtype=vg;break;
	}
}
MinePlayer.prototype.GoPreUrl = function(){
	if (this.Num - 1 >= 0) {
		this.Go(this.Num - 1);
	}
};
MinePlayer.prototype.GoNextUrl = function(){
	if (this.Num + 1 < this.Videos[this.vtype].length) {
		this.Go(this.Num + 1);
	}
};
MinePlayer.prototype.Go = function(n,t){
	document.getElementById('adv_'+this.pid).style.display='none';
	document.getElementById('adbg_'+this.pid).style.display='none';
	if(!t){
		t=this.vtype;
	}else{
		this.vtype = t;
	}
	var pstr = document.getElementById('mine_ifr_'+t+'_'+this.pid).value;
	var cur = eval('this.Videos.'+t)[n];
	
	document.getElementById("topdes_"+this.pid).innerHTML = '' + eval('mine_playing_'+this.pid) + cur.pre + '';
	pstr = pstr.replace('{type}', t);
	pstr = pstr.replace('{vid}', cur.video);
	document.getElementById('playleft_'+this.pid).innerHTML = pstr;
	this.Num = n;
	var bottoma = document.getElementById('MineBottomList_'+t+'_'+this.pid).getElementsByTagName('a');
	for(var i = 0; i<bottoma.length; i++){
		if(i==parseInt(n)) bottoma[i].className = bottoma[i].className.replace('list_on', '') + ' list_on';
		else bottoma[i].className = bottoma[i].className.replace('list_on', '');
	}
	document.getElementById("adbg_"+this.pid).style.display="none";
	document.getElementById("adbg_"+this.pid).style.background="none";
	if(parseInt(n)>=eval('freenum_'+this.pid)&&eval('score_'+this.pid)>0&&eval('!freegroup_'+this.pid)&&eval('!hasbuyed_'+this.pid))eval('mine_skvip_'+this.pid+'()');
	if(bottoma.length==1&&eval('score_'+this.pid)>0&&eval('!freegroup_'+this.pid)&&eval('!hasbuyed_'+this.pid))eval('mine_skvip_'+this.pid+'()');
};
