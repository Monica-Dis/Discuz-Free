<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_mine_video_buyrecord extends discuz_table
{
	public function __construct() {
		$this->_table = 'mine_video_buyrecord';
		$this->_pk = 'id';
		parent::__construct(); /*dism · taoabo · com*/
	}
}
//From: DisM. taobao. Com
?>