<?php
/**
 *	Ӧ�ø���֧�֣�https://dism.taobao.com
 *	���²����http://t.cn/Aiux1Jx1
 *	Date: 2016/8/22 ����һ
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$aliyun = json_decode($_G['cache']['plugin']['mine_video']['mine_video_aliyunkeysecret'], true);
$aliyunUserId = $aliyun['UserId'];
$from = 'forum';
if(isset($_GET['from']))$from = $_GET['from'];
$players = $_G['cache']['plugin']['mine_video']['mine_video_player'];
$players = explode("\n", $players);
$players_str = '';
foreach($players as $p){
	if($p){
		$tmp = explode('==', $p);
		if(count($tmp)>=2){
			$players_str .= '<option value="'.$tmp[0].'">'.$tmp[1].'</option>';
		}
	}
}
$players_str = str_replace(["\r","\n"],["",""],$players_str);
$scoreType_str='';
foreach($_G["setting"]["extcredits"] as $id=>$credit){
	$scoreType_str .= '<option value="'.$id.'">'.$credit['title'].'</option>';
}

$picUploadStatus = false;
if(in_array($_G['fid'], unserialize($_G['cache']['plugin']['mine_video']['mine_video_picbankuai']))){
	$picUploadStatus = true;
}
include template('mine_video:iwin');

?>