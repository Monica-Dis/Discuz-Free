<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/mine_video/mine_function.php';

class mobileplugin_mine_video{
	protected $default_width,$default_width_wap,$default_height,$default_height_wap,$default_autoplay,$jxapi,$listposition,$mine_canuse,$mine_vfree,$dz_uid,$dz_tid,$buyed,$charset,$sktime,$topshow,$freenum,$payurl,$players,$parseurloff,$buyviptips,$buyvipurl;
	function __construct(){
		global $_G;
		
		$default_option = $_G['cache']['plugin']['mine_video'];
		//��̨���õĲ���ֵ
		$this->jxapi = $default_option['mine_video_jxapi'];
		$this->listposition = $default_option['mine_video_playlist_position']?$default_option['mine_video_playlist_position']:'left';
		$this->default_width = $default_option['mine_video_player_width']?$default_option['mine_video_player_width']:'';
		$this->default_width_wap = $default_option['mine_video_player_width_m']?$default_option['mine_video_player_width_m']:'';
		$this->default_height = $default_option['mine_video_player_height']?$default_option['mine_video_player_height']:'500';
		$this->default_height_wap = $default_option['mine_video_player_height_m']?$default_option['mine_video_player_height_m']:'300';
		//$this->default_autoplay = $default_option['mine_video_autoplay'];
		$this->mine_canuse = in_array($_G['groupid'], unserialize($default_option['mine_video_group'])) && in_array($_G['fid'], unserialize($default_option['mine_video_bankuai']));
		$this->mine_vfree = in_array($_G['groupid'], unserialize($default_option['mine_video_vgroup']));
		$this->dz_uid = $_G['uid'];
		$this->charset = $_G['charset'];
		$this->sktime = $default_option['mine_video_player_trytime']?$default_option['mine_video_player_trytime']:'11';//�Կ�ʱ��
		$this->topshow = $default_option['mine_video_topshow'];
		$this->freenum = $default_option['mine_video_freenum'];
		$this->payurl = $default_option['mine_video_payurl'];
		$this->players = $default_option['mine_video_player'];
		$this->parseurloff = $default_option['mine_video_parseurloff'];
		$this->buyviptips = $default_option['mine_video_buyviptips'];
		$this->buyvipurl = $default_option['mine_video_buyvipurl'];
	}
	//��ǰ�û��Ƿ����
	function isbuyed($tid){
		if(!$tid)return false;
        $buyrec = DB::result_first("select id from " . DB::table('mine_video_buyrecord') ." where uid=$this->dz_uid and tid=$tid");
		return $buyrec;
	}
	function GetVideoScore($message){
		$mine_video = preg_replace('/<[^>]*>/is', '', $message);
		$mine_video = trim($mine_video);
		preg_match('/score=&quot;([^&]*)/is', $mine_video, $score);$score = $score[1];
		if(!$score){preg_match('/score="([^"]*)/is', $mine_video, $score);$score = $score[1];}
		return $score;
	}
	function GetTvList($type, $url){
		if(!$type || !$url || !strstr($url,"http://"))return;
		$url = "http://data.sxl.me/cj.php?t=$type&url=$url";
		$tvlist = file_get_contents($url);
		$tvlist = gstr($tvlist, $this->charset);
		if($tvlist)return$tvlist;
		return;
	}
	function ShortCodeToHtml($message){
		global $_G;
		//$mine_video = preg_replace('/<[^>]*>/is', '', $message[0]);
		$mine_video = $message[0];
		preg_match('/type=&quot;([^&]*)/is', $mine_video, $type);$type = $type[1];
		if(!$type){preg_match('/type="([^"]*)/is', $mine_video, $type);$type = $type[1];}
		preg_match('/vid=&quot;(.*?)&quot;/is', $mine_video, $vid);$url = $vid = $vid[1];
		if(!$vid){preg_match('/vid="(.+?)"/is', $mine_video, $vid);$url = $vid = $vid[1];}
		preg_match('/height=&quot;([^&]*)/is', $mine_video, $height);$height = $height[1];
		if(!$height){preg_match('/height="([^"]*)/is', $mine_video, $height);$height = $height[1];}
		preg_match('/height_wap=&quot;([^&]*)/is', $mine_video, $height_wap);$height_wap = $height_wap[1];
		if(!$height_wap){preg_match('/height_wap="([^"]*)/is', $mine_video, $height_wap);$height_wap = $height_wap[1];}
		preg_match('/sfreenum=&quot;([^&]*)/is', $mine_video, $sfreenum);$sfreenum = $sfreenum[1];
		if(!$sfreenum){preg_match('/sfreenum="([^"]*)/is', $mine_video, $sfreenum);$sfreenum = $sfreenum[1];}
		if(isset($sfreenum))$this->freenum = $sfreenum;
		preg_match('/sktime=&quot;([^&]*)/is', $mine_video, $sktime1);$sktime1 = $sktime1[1];
		if(!$sktime1){preg_match('/sktime="([^"]*)/is', $mine_video, $sktime1);$sktime1 = $sktime1[1];}
		if(isset($sktime1))$this->sktime = $sktime1;
		//preg_match('/auto=&quot;([^&]*)/is', $mine_video, $auto);$autoplay = $auto[1];
		//if(!$autoplay){preg_match('/auto="([^"]*)/is', $mine_video, $auto);$autoplay = $auto[1];}
		preg_match('/tvurl=&quot;([^&]*)/is', $mine_video, $tvurl);$tvurl = $tvurl[1];
		if(!$tvurl){preg_match('/tvurl="([^"]*)/is', $mine_video, $tvurl);$tvurl = $tvurl[1];}
		preg_match('/mvdt=&quot;([^&]*)/is', $mine_video, $mvdt);$mvdt = $mvdt[1];
		if(!$mvdt){preg_match('/mvdt="([^"]*)/is', $mine_video, $mvdt);$mvdt = $mvdt[1];}
		preg_match('/score=&quot;([^&]*)/is', $mine_video, $score);$score = $score[1];
		if(!$score){preg_match('/score="([^"]*)/is', $mine_video, $score);$score = $score[1];}
		preg_match('/scoretp=&quot;([^&]*)/is', $mine_video, $scoretp);$scoretp = $scoretp[1];
		if(!$scoretp){preg_match('/scoretp="([^"]*)/is', $mine_video, $scoretp);$scoretp = $scoretp[1];}
		$scoretypename = $_G["setting"]["extcredits"][$scoretp]['title'];
		$aheight = 26;
		if(!$this->topshow){
			$styletopshow = ' style="display:none;"';
			$aheight = 0;
		}
		$score = ($score?$score:0);
		//���Զ����������ֵĬ�ϲ���
		if(!$height)$height = $this->default_height;
		if(!$height_wap)$height_wap = $this->default_height_wap;
		$height = $height_wap;
		if($this->default_width)$mwidth = ' style="width:'.$this->default_width.'px;" ';
		
		if($this->default_width&&$this->default_width!='0')$width = $this->default_width.'px';
		else $width = '100%';

		$parr = MineGetPlayers($this->players);
		$typearr = explode('^', $type);
		$type = $typearr[0];
		$typestr = '';
		$urlarr = explode('^', $url);
		$vlistarr = array();
		$vliststr = '';
		$jxapistr = '';
		
		$r = rand(1000,99999);
		$typelen = count($typearr);
		$vgshoworhide = '';
		for($ti=0;$ti<$typelen;$ti++){
			if($ti == 0){
				$typestr .= '<li class="layui-this">'.$parr[$typearr[$ti]].'</li>';
				$vliststr .= '<div class="layui-tab-item layui-show"><div id="MineBottomList_'.$typearr[$ti].'_'.$r.'" class="MineBottomList"><ul class="result_album" id="result_album_'.$typearr[$ti].'_'.$r.'">';
			}else{
				$typestr .= '<li>'.$parr[$typearr[$ti]].'</li>';
				$vliststr .= '<div class="layui-tab-item"><div id="MineBottomList_'.$typearr[$ti].'_'.$r.'" class="MineBottomList"><ul class="result_album" id="result_album_'.$typearr[$ti].'_'.$r.'">';
			}
			$vidgroup = explode(',', $urlarr[$ti]);
			$vidlen = count($vidgroup);
			if($typelen == 1 && $vidlen == 1) $vgshoworhide = 'display:none;';
			$jxapi_cur = $parr[$typearr[$ti].'_api']?$parr[$typearr[$ti].'_api']:$this->jxapi;
			$jxapi_cur = str_replace('{formhash}', FORMHASH, $jxapi_cur);
			if($jxapi_cur == 'self'){
				$jxapi_cur = '{vid}';
			}
			for($vi=0;$vi<$vidlen;$vi++){
				$vidtemp = explode('$', $vidgroup[$vi]);
				if(!$vidtemp[1]){
					$vidtemp[1]=$vidtemp[0];
					$vidtemp[0]=lang('plugin/mine_video','di').( intval($vi+0)<9?'0':'') . ($vi+1).lang('plugin/mine_video','ji');
				}
				$videoval = MineGetVid($vidtemp[1]);
				if($this->sktime == 0 && $score > 0 && !$this->mine_vfree && !$this->buyed && (is_numeric($this->freenum) && intval($this->freenum)<=$vi))$videoval = time();
				$vlistarr[$typearr[$ti]][] = array('id'=>$vi, 'pre'=>iconv($_G['charset'],"UTF-8//IGNORE",$vidtemp[0]),'video'=>$videoval);
				if(($this->freenum && intval($this->freenum)>$i) || $score == 0)
					$vliststr .= '<li><a href="javascript:void(0)" onclick="MP_'.$r.'.Go('.$vi.', \''.$typearr[$ti].'\');return false;">'.$vidtemp[0].'</a></li>';
				else
					$vliststr .= '<li><a href="javascript:void(0)" onclick="MP_'.$r.'.Go('.$vi.', \''.$typearr[$ti].'\');return false;">'.$vidtemp[0].'<i class="mark_v"><img src="source/plugin/mine_video/template/images/vip.png" alt="vip"></i></a></li>';
			}
			$vliststr .= '</ul></div></div>';
			$jxapistr .= '<input type="hidden" id="mine_ifr_'.$typearr[$ti].'_'.$r.'" value=\'<i'.'fr'.'ame border="0" src="'.$jxapi_cur.'" width="100%" height="'.$height.'" marginwidth="0" framespacing="0" marginheight="0" frameborder="0" scrolling="no" vspale="0" noresize="" allowfullscreen="true" id="minewindow_'.$typearr[$ti].'_'.$r.'"></'.'if'.'rame>\'/>';
		}
		
		$style = '<link rel="stylesheet" id="mine_video-css" href="source/plugin/mine_video/template/css/minevideo.css" type="text/css" media="all" /><style type="text/css">.mine_player{position:relative;height:'.(intval($height)+$aheight).'px;background:#000000;position:relative;z-index:120;padding: 0 !important;}.play{width:100%;height:'.(intval($height)+$aheight).'px;overflow:hidden;position:relative;padding: 0 !important;}.adv{z-index:99999;position:absolute;width:100%;color:#FFF;font-size:20px;margin:0 auto;overflow:hidden;text-align: center;display:none;top:25%;font-family:"Microsoft YaHei","΢���ź�","Microsoft JhengHei",MingLiu,Verdana, Arial, Helvetica, sans-serif;}.mine_player .adbg{width:100%;height:'.(intval($height)+$aheight).'px;position:absolute;left:0;top:0;color:#fff;text-align:right;font-size:16px;}.mine_player .adbg span{position:absolute;z-index:99998;right:18px;}.a1{width:100%; height:100%;position: absolute;z-index:99997;}.mine_player,.MineBottomList{width:'.$width.';}div.adv p { padding:0; margin:0; }div.adv p.info{ color: #CCC; font-size: 24px; text-indent: 0.5em; display: block; text-align: center; }div.adv p.title {display: block;font-size: 16px;padding: 15px 0px 0px;color: #C2C1C1;text-align: center;}div.adv p.pay {color: #f39800;display: block;font-size: 18px;padding: 5px 0px 0px;text-align: center; }div.adv p.paybtn { text-align:center; padding-top:20px;}div.adv p.paybtn a,div.adv p.paybtn a:link,div.adv p.paybtn a:visited { background-color: #327b10;border: 1px solid #235c09;border-radius: 5px;color: #FFF;cursor: pointer;display: inline-block;font-size: 18px;height: 48px;line-height: 48px;width: 170px; }div.adv p.paybtn a.btn1,div.adv p.paybtn a.btn1:link,div.adv p.paybtn a.btn1:visited { background-color: #327b10;border: 1px solid #235c09;border-radius: 5px;color: #FFF;cursor: pointer;display: inline-block;font-size: 18px;height: 48px;line-height: 48px;width: 170px; text-decoration: none;}div.adv p.paybtn a.btn2,div.adv p.paybtn a.btn2:link,div.adv p.paybtn a.btn2:visited { background-color: transparent;border: 1px solid #666;color: #999;height: 48px;margin-left: 20px;width: 170px; text-decoration:none; }</style>';
		$script = '<script type="text/javascript">var mine_di_'.$r.'="'.lang('plugin/mine_video', 'di').'",mine_ji_'.$r.'="'.lang('plugin/mine_video', 'ji').'",mine_playing_'.$r.'="'.lang('plugin/mine_video', 'playing').'";var ismvedit=false,freegroup_'.$r.'='.($this->mine_vfree?'true':'false').',freenum_'.$r.'='.$this->freenum.',hasbuyed_'.$r.'='.($this->buyed?'true':'false').',score_'.$r.'='.$score.';</script><script type="text/javascript" src="source/plugin/mine_video/template/js/mineplayer.js?v='.lang('plugin/mine_video','jsversion').'"></script><script>var minevideo_type_'.$r.'="'.$type.'";var minevideo_vids_'.$r.'='.json_encode($vlistarr).';var MP_'.$r.' = new MinePlayer('.$r.');var second_'.$r.' = '.$this->sktime.';var timer_'.$r.';function mine_skvip_'.$r.'(){document.getElementById("adbg_'.$r.'").style.display="block";timer_'.$r.' = setTimeout("change_'.$r.'()", 1000);}function change_'.$r.'() {second_'.$r.'--;if (second_'.$r.' > 0) {document.getElementById("adbg_'.$r.'").innerHTML=\'<br/><span>'.lang('plugin/mine_video', 'sksy').'  <font color="red">\' + second_'.$r.' + \'</font> '.lang('plugin/mine_video', 'dwm').'</span> &nbsp;&nbsp;\';timer = setTimeout("change_'.$r.'()", 1000);}else {document.getElementById("adbg_'.$r.'").innerHTML=\'<br/><span>'.lang('plugin/mine_video', 'skjs').' &nbsp;&nbsp;</span> \';document.getElementById("adv_'.$r.'").style.display="block";document.getElementById("adbg_'.$r.'").style.background="#000000";document.getElementById("playleft_'.$r.'").innerHTML="";clearTimeout(timer_'.$r.');second_'.$r.' = '.$this->sktime.';}}MP_'.$r.'.Go(0);</script><script src="https://www.layuicdn.com/layui/layui.js"></script><script>layui.use(\'element\', function(){var $ = layui.jquery,element = layui.element;});</script>';
        if($this->dz_uid){
            $login = '<a href="'.$this->buyvipurl.'" class="btn1" target="_blank">'.lang('plugin/mine_video', 'vipfreebtn').'</a><a class="btn2" href="plugin.php?id=mine_video:paym&tid='.$this->dz_tid.'">'.$scoretypename.lang('plugin/mine_video', 'buy').'</a>';
        }
        else{
            $login = '<a class="btn1" href="member.php?mod=logging&action=login&referer=">'.lang('plugin/mine_video', 'vipnologintips').'</a>';
        }
		$player = '
<div class="mine_player" id="mine_player"><div class="play" class="b"><div id="adbg_'.$r.'" class="adbg"></div><div class="a1"><div id="MinePlayer_'.$r.'" class="MinePlayer"'.$mwidth.'><table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr'.$styletopshow.'><td height="26"><table border="0" cellpadding="0" cellspacing="0" id="playtop_'.$r.'" class="playtop"><tbody><tr><td class="topleft" width="30%"><a target="_self" href="javascript:void(0)" onclick="MP_'.$r.'.GoPreUrl();return false;">'.lang('plugin/mine_video', 'prepost').'</a> <a target="_self" href="javascript:void(0)" onclick="MP_'.$r.'.GoNextUrl();return false;">'.lang('plugin/mine_video', 'nextpost').'</a></td><td class="topcc"><div id="topdes_'.$r.'" class="topdes">'.lang('plugin/mine_video', 'playing').$vin1.'</div></td></tr></tbody></table></td></tr><tr><td><table border="0" cellpadding="0" cellspacing="0"><tbody><tr><td id="playleft_'.$r.'" class="playleft" valign="top"></td><td id="playright_'.$r.'" class="playright" valign="top"></td></tr></tbody></table></td></tr></tbody></table></div></div></div><div id="adv_'.$r.'" class="adv" style=""><p class=info>'.lang('plugin/mine_video', 'mvscoretips').'</p><p class=title>'.$this->buyviptips.'</p><p class=pay>'.lang('plugin/mine_video', 'needtopay').$scoretypename.': '.$score.'</p><p class=paybtn>'.$login.'</p></div></div>'.$jxapistr.'<link rel="stylesheet" type="text/css" href="https://www.layuicdn.com/layui/css/layui.css" /><div class="layui-tab layui-tab-brief" lay-filter="videoGroup" style="margin:10px auto;'.$vgshoworhide.'"><ul class="layui-tab-title">'.$typestr.'</ul><div class="layui-tab-content" style="height: auto;padding-left:0;">'.$vliststr.'</div></div>';
		return $style.$player.$script;
	}
}
include_once(DISCUZ_ROOT.'./source/plugin/mine_video/extend/forum_mobile.php'); 
if(file_exists(DISCUZ_ROOT.'./source/plugin/mine_video/extend/protal_mobile.php')){ 
	include_once(DISCUZ_ROOT.'./source/plugin/mine_video/extend/protal_mobile.php'); 
}
if(file_exists(DISCUZ_ROOT.'./source/plugin/mine_video/extend/home_mobile.php')){ 
	include_once(DISCUZ_ROOT.'./source/plugin/mine_video/extend/home_mobile.php'); 
}
if(file_exists(DISCUZ_ROOT.'./source/plugin/mine_video/extend/group_mobile.php')){ 
	include_once(DISCUZ_ROOT.'./source/plugin/mine_video/extend/group_mobile.php'); 
}
//From: Dism��taobao��com
?>