<?php
/**
 *      [Mine��Ƶ����רҵ��] by mine27.
 *		QQ 995525477
 *      
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF

DROP TABLE `pre_mine_video_buyrecord`;
DROP TABLE `pre_mine_video_uploadrecord`;

EOF;

runquery($sql);
$finish = TRUE;
?>