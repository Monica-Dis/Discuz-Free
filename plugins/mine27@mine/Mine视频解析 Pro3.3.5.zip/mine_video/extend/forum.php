<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_mine_video_forum extends plugin_mine_video{
    public function post_editorctrl_left(){
		if($this->mine_canuse){
			$load_url = 'plugin.php?id=mine_video:win';
			$str = '<style>#a_mg_minevideo{background: transparent url(source/plugin/mine_video/template/images/mine_video_logo_30.png) no-repeat 0 0;}.b2r #a_mg_minevideo{background: transparent url(source/plugin/mine_video/template/images/mine_video_logo_20.png) no-repeat 0 0;}</style><a id="a_mg_minevideo" title="'.lang('plugin/mine_video','minename').'" href="javascript:;" onClick="showWindow(\'winbox\', \'' . $load_url . '\')">'.lang('plugin/mine_video','jiexi').'</a>';
			return $str;	
		}
    }
	public function post_attribute_extra_body(){
		$extrajs = '';
		if($this->parseurloff)
			$extrajs .= '<script>document.getElementById("parseurloff").checked=true;</script>';
		return $extrajs;
	}
    public function viewthread_posttop_output(){
		global $postlist, $post,$threadsortshow;
        $this->dz_tid = $post['tid'];
		$this->buyed = $this->isbuyed($this->dz_tid);
        if($this->mine_vfree){
            //����û���
			$threadsortshow['typetemplate'] = preg_replace_callback('/\[mine_video.*?\]\[\/mine_video\]/is', array($this,'ShortCodeToHtml'), ($threadsortshow['typetemplate']));
			foreach ($postlist as $id => $post) {
				$player = preg_replace_callback('/\[mine_video.*?\]\[\/mine_video\]/is', array($this,'ShortCodeToHtml'), ($post['message']));
				$post['message'] = $player;
				$postlist[$id] = $post;
			}
        }
        else{
			//����ۿ�
			foreach ($postlist as $id => $post) {
				$threadsortshow['typetemplate'] = preg_replace_callback('/\[mine_video.*?\]\[\/mine_video\]/is', array($this,'ShortCodeToHtml'), ($threadsortshow['typetemplate']));
				$player = preg_replace_callback('/\[mine_video.*?\]\[\/mine_video\]/is', array($this,'ShortCodeToHtml'), ($post['message']));
				$post['message'] = $player;
				$postlist[$id] = $post;
			}
        }
    }
	function forumdisplay_threadlist_bottom_output(){
		global $_G;
		if(in_array($_G['fid'], unserialize($_G['cache']['plugin']['mine_video']['mine_video_picbankuai']))){
        if(file_exists(DISCUZ_ROOT.'./source/plugin/mine_video/extend/forumdisplay_thread_subject.php')){
			require_once DISCUZ_ROOT.'./source/plugin/mine_video/extend/forumdisplay_thread_subject.php';
			$tsub = new mine_video_forumdisplay_pc();
			return $tsub->style;
		}
		}
    }
	function forumdisplay_thread_subject_output(){
		global $_G;
		if(in_array($_G['fid'], unserialize($_G['cache']['plugin']['mine_video']['mine_video_picbankuai']))){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/mine_video/extend/forumdisplay_thread_subject.php')){
			require_once DISCUZ_ROOT.'./source/plugin/mine_video/extend/forumdisplay_thread_subject.php';
			$tsub = new mine_video_forumdisplay_pc();
			return $tsub->forumdisplay_thread_subject_output();
		}
		}
    }
	function UpdPost($tvlist){
		global $post;
		$message = DB::result_first("select message from " . DB::table('forum_post') ." where tid=".$post["tid"]." and first=1");
		$post['message'] = str_replace("&nbsp;", " ", $message);
		$post['message'] = str_replace("&quot;", "\"", $post['message']);
		$post['message'] = str_replace("&lt;", "<", $post['message']);
		$post['message'] = str_replace("&gt;", ">", $post['message']);
		$post['message'] = str_replace("<br />", "", $post['message']);
		$post['message'] = preg_replace('/mvdt=&quot;[^&]*&quot;/is', '', $post['message']);
		$post['message'] = preg_replace('/mvdt="[^"]*"/is', '', $post['message']);
		preg_match('/vid=&quot;[^&]*&quot;/is', $post['message'], $vid);$vid = $vid[0];
		if(!$vid){preg_match('/vid="[^"]*"/is', $post['message'], $vid);$vid = $vid[0];$isquot=true;}
		$tvlists = 'vid="'.$tvlist.'" mvdt="'.time().'"';
		$message = str_replace("'", "''", str_replace($vid, $tvlists, $post['message']));
		DB::query("update ".DB::table('forum_post')." set message='$message' where tid=".$post['tid']);
	}
}
//From: Dism_taobao_com
?>