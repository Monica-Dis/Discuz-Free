<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_mine_video_forum extends mobileplugin_mine_video{
	function viewthread_posttop_output()
    {
		global $postlist, $post,$threadsortshow;
        $this->dz_tid = $post['tid'];
		$this->buyed = $this->isbuyed($this->dz_tid);
        if($this->mine_vfree){
            //����û���
			$threadsortshow['typetemplate'] = preg_replace_callback('/\[mine_video.*?\]\[\/mine_video\]/is', array($this,'ShortCodeToHtml'), ($threadsortshow['typetemplate']));
			foreach ($postlist as $id => $post) {
				$player = preg_replace_callback('/\[mine_video.*?\]\[\/mine_video\]/is', array($this,'ShortCodeToHtml'), ($post['message']));
				$post['message'] = $player;
				$postlist[$id] = $post;
			}
        }
        else{
            //����ۿ�
			foreach ($postlist as $id => $post) {
				$threadsortshow['typetemplate'] = preg_replace_callback('/\[mine_video.*?\]\[\/mine_video\]/is', array($this,'ShortCodeToHtml'), ($threadsortshow['typetemplate']));
				$player = preg_replace_callback('/\[mine_video.*?\]\[\/mine_video\]/is', array($this,'ShortCodeToHtml'), ($post['message']));
				$post['message'] = $player;
				$postlist[$id] = $post;
			}
        }
    }
	function UpdPost($tvlist){
		global $post;
		$post['message'] = str_replace("&nbsp;", " ", $post['message']);
		$post['message'] = str_replace("&quot;", "\"", $post['message']);
		$post['message'] = str_replace("&lt;", "<", $post['message']);
		$post['message'] = str_replace("&gt;", ">", $post['message']);
		$post['message'] = preg_replace('/mvdt=&quot;[^&]*&quot;/is', '', $post['message']);
		$post['message'] = preg_replace('/mvdt="[^"]*"/is', '', $post['message']);
		preg_match('/vid=&quot;[^&]*&quot;/is', $post['message'], $vid);$vid = $vid[0];
		if(!$vid){preg_match('/vid="[^"]*"/is', $post['message'], $vid);$vid = $vid[0];$isquot=true;}
		$tvlists = 'vid="'.$tvlist.'" mvdt="'.time().'"';
		$message = str_replace("'", "''", str_replace($vid, $tvlists, $post['message']));
		DB::query("update ".DB::table('forum_post')." set message='$message' where tid=".$post['tid']);
	}
	
    function post_bottom_mobile_output(){
        global $_G;
        if($this->mine_canuse){
            return '<button href="plugin.php?id=mine_video:win" class="dialog" style="display: inline-block;height: 38px;line-height: 38px;padding: 0 18px;background-color: #009688;color: #fff;white-space: nowrap;text-align: center;font-size: 14px;border: none;border-radius: 2px;cursor: pointer;">'.lang('plugin/mine_video', 'insertvideo').'</button>';
        }
        return '';
    }
	
	function forumdisplay_threadlist_bottom_output(){
		global $_G;
		if(in_array($_G['fid'], unserialize($_G['cache']['plugin']['mine_video']['mine_video_picbankuai']))){
        if(file_exists(DISCUZ_ROOT.'./source/plugin/mine_video/extend/forumdisplay_thread_subject.php')){
			require_once DISCUZ_ROOT.'./source/plugin/mine_video/extend/forumdisplay_thread_subject.php';
			$tsub = new mine_video_forumdisplay_pc();
			return $tsub->style;
		}
		}
    }
	function forumdisplay_thread_subject_output(){
		global $_G;
		if(in_array($_G['fid'], unserialize($_G['cache']['plugin']['mine_video']['mine_video_picbankuai']))){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/mine_video/extend/forumdisplay_thread_subject.php')){
			require_once DISCUZ_ROOT.'./source/plugin/mine_video/extend/forumdisplay_thread_subject.php';
			$tsub = new mine_video_forumdisplay_pc();
			return $tsub->forumdisplay_thread_subject_output();
		}
		}
    }
}
//From: Dism_taobao_com
?>