<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *      ���²����http://t.cn/Aiux1Jx1 $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}



class smsAutoloader{
  
  /**
     * ����Զ����أ�д��·����ȷ�������������ļ���
     * @param string $class ��������
     * @return void
     */
    public static function autoload($class) {
        $name = $class;
        if(false !== strpos($name,'\\')){
          $name = strstr($class, '\\', true);
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_sms/include'."/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_sms/include'."/top/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_sms/include'."/top/request/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_sms/include'."/top/domain/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_sms/include'."/aliyun/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_sms/include'."/aliyun/request/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_sms/include'."/aliyun/domain/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }         
    }
}


if (version_compare(phpversion(),'5.3.0','>=')) {
    spl_autoload_register('smsAutoloader::autoload',false,true);
}else{
    smsAutoloader::autoload("zhanmishu_sms");
    smsAutoloader::autoload("zhanmishu_mobileverify");
    smsAutoloader::autoload("zhanmishu_notice");
    smsAutoloader::autoload("zhanmishu_template");
    smsAutoloader::autoload("zhanmishu_transfer");
    smsAutoloader::autoload("TopClient");
    smsAutoloader::autoload("TopLogger");
    smsAutoloader::autoload("SendSms");
    smsAutoloader::autoload("AlibabaAliqinFcSmsNumSendRequest");
    smsAutoloader::autoload("ResultSet");
    smsAutoloader::autoload("AliyunClient");
    smsAutoloader::autoload("HttpdnsGetRequest");
    smsAutoloader::autoload("RequestCheckUtil");
    smsAutoloader::autoload("DefaultProfile");
    smsAutoloader::autoload("qcloud_sms");
}

//From: Dism_taobao_com
?>