<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *      ���²����http://t.cn/Aiux1Jx1 $
 */

include_once DISCUZ_ROOT.'source/plugin/zhanmishu_sms/include/zhanmishu_getpassword.php';
class sendSms {
    public function __construct(){
        
    }
    public function sendCode($mobile='', $code='', $act = ''){
        $re = array();
        switch ($act) {
            case 'register':
                $sendsms = new zhanmishu_sms();
                $re = $sendsms->sendsms($mobile, '999999', $code);
                break;
             case 'getpwd':
                $sendsms = new zhanmishu_getpassword();
                $re = $sendsms->sendsms('',$mobile,'999999',$code,true);
                break;           
            default:
                $re = array('code'=>'-5','msg'=>'nomsg');
                break;
        }

        $return = array();
        $return['rs'] = $re['code'] > 0 ? '1' : '0';
        $return['msg'] = diconv($re['msg'],'UTF-8',CHARSET);
        return $return;
    }

}

//From: Dism_taobao_com
?>