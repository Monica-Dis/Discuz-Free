<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM. && alibaba
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
/**
 * 返回的默认类
 * 
 * @author auto create
 * @since 1.0, 2015-01-20
 */
class ResultSet
{
	
	/** 
	 * 返回的错误码
	 **/
	public $code;
	
	/** 
	 * 返回的错误信息
	 **/
	public $msg;
	
}
