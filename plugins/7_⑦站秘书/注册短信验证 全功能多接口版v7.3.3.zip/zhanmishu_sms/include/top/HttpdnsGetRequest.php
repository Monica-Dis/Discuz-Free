<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM. && alibaba
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class HttpdnsGetRequest
{
	private $apiParas = array();
	
	public function getApiMethodName()
	{
		return "taobao.httpdns.get";
	}
	
	public function getApiParas()
	{
		return $this->apiParas;
	}
	
	public function check(){}
	
	public function putOtherTextParam($key, $value) {
		$this->apiParas[$key] = $value;
		$this->$key = $value;
	}
}
