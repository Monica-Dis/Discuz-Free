<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */	

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


function getconfig(){
	global $_G;
	include DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/zmssmsconfig.php';

	loadcache('plugin');	
	$config = $_G['cache']['plugin']['zhanmishu_sms'];
	$config['waittime'] = $config['waittime']>0?$config['waittime']:60;
	$config['no_tip_group'] = unserialize($config['no_tip_group']);
	$config['no_limit'] = unserialize($config['no_limit']);
	$config['limit_forums'] = unserialize($config['limit_forums']);
	$config['emailnoticeforum'] = unserialize($config['emailnoticeforum']);
	$config['smsnoticegroups'] = unserialize($config['smsnoticegroups']);
	$config['emailnoticegroups'] = unserialize($config['emailnoticegroups']);
	$config['reply_limit_forums'] = unserialize($config['reply_limit_forums']);
	$config['reply_nolimit_group'] = unserialize($config['reply_nolimit_group']);
	$config['smsnoticeforum'] = unserialize($config['smsnoticeforum']);
	$config['mobile_save_type'] = unserialize($config['mobile_save_type']);
	$config['mobilerule'] = $config['mobilerule'] ? $config['mobilerule'] : "/^0?(13[0-9]|15[0-9]|17[0678]|18[0-9]|14[57])[0-9]{8}$/";
	$config['tip_times'] = $config['tip_times'] ? intval($config['tip_times']) * 60 + 1000 : 1200;
	if (!function_exists('seccheck')) {
		list($config['seccodecheck'], $config['secqaacheck']) = check_seccode('register');
	}else{
		list($config['seccodecheck'], $config['secqaacheck']) = seccheck('register');
	}
	$config['smsconfig'] = $smsconfig;

	return $config;
}


function check_verify($verify){
	foreach ($verify as $key => $value) {
		if (is_array($value['field']) && isset($value['field']['mobile']) && isset($value['field']['mobile'])) {
			if ($verify[$key]['available'] == '1') {
				return true;
			}
		}
	}

	return false;
}

function get_verify($verify){
	foreach ($verify as $key => $value) {
		if (is_array($value['field']) && count($value['field'] = 1) && isset($value['field']['mobile']) && $value['field']['mobile']=='mobile') {
			$verify_id = $key;
			break;
		}
	}
	if (!isset($verify_id)) {
		foreach ($verify as $key => $value) {
			if (!$value['title'] && !$value['available'] && !$value['icon'] && $key > 0) {
				$verify_id = $key;
				break;
			}
		}
	}

	if (!$verify_id) {
		return false;
	}

	$verify['enabled'] = true;
	$verify[$verify_id]['available'] = '1';
	$verify[$verify_id]['title'] = lang('plugin/zhanmishu_sms', 'mobileverify');
	$verify[$verify_id]['field'] = array('mobile'=>'mobile');
	$verify[$verify_id]['groupid'] = get_groupids();
	return $verify;
}

function get_groupids(){
	$groupids = DB::fetch_all('select groupid from %t',array('common_usergroup'),'groupid');
	return array_keys($groupids);
}




?>