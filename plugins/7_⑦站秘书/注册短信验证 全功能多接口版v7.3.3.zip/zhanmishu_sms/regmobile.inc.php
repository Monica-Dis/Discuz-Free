<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!$_G['uid']) {
	exit('Denied');
}
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/function.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/zhanmishu_mobileverify.php';
$config=getconfig();
$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();

$verify = new zhanmishu_mobileverify();

$v = $verify->get_member_verify_info();
$isverify = $verify->check_user_isverify();


?>