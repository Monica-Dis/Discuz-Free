<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if (!$_G['uid'] && 
	$_GET['method'] != 'verify' && 
	$_GET['method'] != 'login' && 
	$_GET['method'] != 'loginsend'
	) {

	showmessage('please_login', '', array(), array('login' => true));
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/Autoloader.php';

$sendsms = new zhanmishu_mobileverify();
$config = $sendsms->config;


$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();
		
$data = array();
$data['phone'] = preg_replace("/\s/",'',daddslashes($_GET['mobile'] ? $_GET['mobile'] : $_GET['phone']));
$data['code'] = intval($_GET['code']);
$data['nationcode'] = $_GET['nationcode'] ? $_GET['nationcode'] : $sendsms->get_nationcode($data['mobile']);
if ($data['nationcode']) {
	$data['phone'] = str_replace('+'.$data['nationcode'],'',$data['phone']);
}
$data['mobile'] = $data['phone'];

if ($_GET['sms_verify'] || $_GET['verify'] || $_GET['verifycode']) {
	$data['verify'] = intval($_GET['sms_verify'] ? $_GET['sms_verify'] : $_GET['verify']);
	$data['verify'] = $data['verify'] ? $data['verify'] :  $_GET['verifycode'];
}
if ($_GET['username']) {
	$data['username'] = daddslashes($_GET['username']);
	$data['passwd'] = daddslashes($_GET['passwd']);
}



if (submitcheck('no_submit') && $_GET['method']=='send') {

	$return =  $sendsms->sendsms($data['phone'],$data['code'],true,false,false,$data['nationcode']);
	echo json_encode($return);
	exit();

}else if (submitcheck('no_submit') && $_GET['method']=='loginsend') { 
	// is verify code?
	if ($config['regsmssec']) {
		submitcheck('no_submit',false,true);
	}

	$uid = $sendsms->getuidbymobile($data['phone']);
	if (!$uid) {
		$return = array('code'=>'-16','msg'=>'user is not exists');
		echo json_encode($return);
		exit;
	}
	$return =  $sendsms->sendsms($data['phone'],$data['code'],false,false,false);
	echo json_encode($return);

}else if (submitcheck('loginsubmit') && $_GET['method']=='login' && ($config['issmslogin'] || true)) {


	$login = new zhanmishu_mobileverify(null,$data['code'],$data['verify']);
	
	$return = $login->logbymobile($data['mobile']);

	echo json_encode($return);
}else if (submitcheck('no_submit') && $_GET['method']=='verify') {


	$verify = new zhanmishu_mobileverify(null,$data['code'],$data['verify']);
	$return = $verify->verify();
	echo json_encode($return);
	exit();
}else if (submitcheck('send_verify_Button') && $_GET['method']=='submit') {

	$verify = new zhanmishu_mobileverify(null,$data['code'],$data['verify']);
	$return = $verify->mobile_verify();
	if (defined('IN_MOBILE') && $_GET['isnew']) {
		echo json_encode($return);
		exit;
	}
	$return['msg'] =diconv(strval($return['msg']),'UTF-8', CHARSET );
	if ($return['code'] == '1') {
		if (defined('IN_MOBILE') || $_GET['from'] =='mobileverify') {
			showmessage($result['msg'], $referer, array(),'success');
		}
		showmessage('', $referer, array(),array('showid' => '','extrajs' => '<script type="text/javascript">'.'hideWindow("mobileverify");showDialog("'.$return['msg'].'","right");top.location.href="'.$referer.'";</script>'.$ucsynlogin,'showdialog' => false));
	}else{
		showmessage($return['msg'], $referer, array(),array('showid' => '','striptags' => false,'showdialog' => true));
	}
	exit();
}else if (submitcheck('no_submit') && $_GET['method']=='editsend') {

	$sendsms = new zhanmishu_mobileverify();
	//$return = $sendsms->sendpost('15528055356',array('aproduct'=>'AAA','name'=>'ali'),'7');
	$return =  $sendsms->sendsms($data['phone'],$data['code'],false,true,false,$data['nationcode']);
	echo json_encode($return);
	exit();

}else if (submitcheck('no_submit') && $_GET['method']=='new_send') {

	$data['phone'] = preg_replace("/\s/",'',daddslashes($_GET['phone'] ? $_GET['phone'] : $_GET['new_mobile']));
	$data['code'] = daddslashes($_GET['new_code'] ? $_GET['new_code'] : $_GET['code']);
	$data['verify'] = intval($_GET['verify'] ? $_GET['verify'] : $_GET['verifycode']);
	$data['oldcode'] = intval($_GET['oldcode'] ? $_GET['oldcode'] : $_GET['code']);
	$sendsms = new zhanmishu_mobileverify(null,$data['oldcode'],$data['verify']);
	$nationcode = daddslashes($data['nationcode'] ? $data['nationcode'] : $sendsms->get_nationcode($data['phone']));
	if ($nationcode) {
		$data['phone'] = str_replace('+'.$nationcode,'',$data['phone']);
	}

	$return = $sendsms->new_send($data['phone'],$data['code'],1,false,false,$data['nationcode']);
	echo json_encode($return);
	exit();

}else if (submitcheck('no_submit') && $_GET['method']=='new_verify') {
	$data['oldmobile'] = preg_replace("/\s/",'',daddslashes($_GET['oldmobile']));
	$data['mobile'] = preg_replace("/\s/",'',daddslashes($_GET['new_mobile'] ? $_GET['new_mobile'] : $_GET['mobile']));
	$data['oldverify'] = intval($_GET['oldverify']);
	$data['verify'] = intval($_GET['verify']);
	$data['oldcode'] = intval($_GET['oldcode']);
	$data['code'] = intval($_GET['new_code'] ? $_GET['new_code'] : $_GET['code']);
	
	$verify = new zhanmishu_mobileverify(null,$data['code'],$data['verify']);
	$nationcode = $verify->get_nationcode($data['mobile']);
	if ($nationcode) {
		$data['phone'] = str_replace('+'.$nationcode,'',$data['phone']);
	}
	
	$return = $verify->new_verify($data);
	echo json_encode($return);
	exit();
}else if (submitcheck('send_verify_Button') && $_GET['method']=='edit') {

	$data['oldmobile'] = preg_replace("/\s/",'',daddslashes($_GET['new_mobile'] ? $_GET['mobile'] : $_GET['oldmobile']));
	$data['mobile'] = preg_replace("/\s/",'',daddslashes($_GET['new_mobile'] ? $_GET['new_mobile'] : $_GET['mobile']));
	$data['oldverify'] = intval($_GET['verifycode'] ? $_GET['verifycode'] : $_GET['oldverify']);
	$data['verify'] = intval($_GET['new_verifycode'] ? $_GET['new_verifycode'] : $_GET['verify']);
	$data['oldcode'] = intval($_GET['new_code'] ? $_GET['code'] : $_GET['oldcode']);
	$data['code'] = intval($_GET['new_code'] ? $_GET['new_code'] : $_GET['code']);

	$verify = new zhanmishu_mobileverify(null,$data['code'],$data['verify']);

	$nationcode = $verify->get_nationcode($data['mobile']);
	if (!$nationcode) {
		$nationcode = $verify->get_nationcode($data['oldmobile']);
	}
	if ($nationcode) {
		$data['oldmobile'] = str_replace('+'.$nationcode,'',$data['oldmobile']);
		$data['mobile'] = str_replace('+'.$nationcode,'',$data['mobile']);
	}

	$result = $verify->change_mobile($data);

	if (defined('IN_MOBILE') && $_GET['isnew']) {
		echo json_encode($result);
		exit;
	}
	$msg =diconv(strval($result['msg']),'UTF-8', CHARSET );
	if ($result['code'] == '1') {
		if (defined('IN_MOBILE') || $_GET['from'] =='mobileverify') {
			showmessage($msg, $referer, array(),'success');
		}
		showmessage($msg, $referer, array(),array('showid' => '','extrajs' => '<script type="text/javascript">'.'hideWindow("mobileverify");showDialog("'.$msg.'","right");top.location.href="'.$referer.'";</script>'.$ucsynlogin,'showdialog' => false));
		
	}else{
		showmessage($msg, $referer, array(),array('showid' => '','striptags' => false,'showdialog' => true));
	}

	exit();
}else{

	// if (!$_GET['act']) {
	// 	$verify = new zhanmishu_mobileverify();
	//  	$isverify = $verify->check_user_isverify($_G['uid']);
	// 	if ($isverify) {
	// 		showmessage(lang('plugin/zhanmishu_sms','haven_verify_thissuer'), $referer);
	// 		exit;
	// 	}
	// }
	$verifyHander = new zhanmishu_mobileverify();
	$mobile = $verifyHander->verify_mobile_number($_GET['mobile']) ? $_GET['mobile'] : $verifyHander->get_usermobile();

	if (defined('IN_MOBILE') && !$mobile) {
		dheader("location:plugin.php?id=zhanmishu_sms:register#/verify");
		exit;
	}else if (defined('IN_MOBILE')){
		dheader("location:plugin.php?id=zhanmishu_sms:register#/verifyedit");
		exit;		
	}

	include template("zhanmishu_sms:verify");
}



?>