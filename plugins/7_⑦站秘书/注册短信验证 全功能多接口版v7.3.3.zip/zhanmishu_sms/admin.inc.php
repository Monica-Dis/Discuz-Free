<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *      ���²����http://t.cn/Aiux1Jx1 $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
cpheader();
showtips(lang('plugin/zhanmishu_sms', 'servicetips'),'',true,lang('plugin/zhanmishu_sms', 'servicetiptitle'));




?>