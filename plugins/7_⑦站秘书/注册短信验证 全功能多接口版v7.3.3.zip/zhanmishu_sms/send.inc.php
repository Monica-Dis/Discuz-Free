<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/function.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/Autoloader.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/zhanmishu_mobileverify.php';

$sendsms = new zhanmishu_sms();
$config = $sendsms->config;

if ($_G['uid']) {
	$return = array('code'=>'-912','msg'=>zhanmishu_sms::auto_charset_change(lang('plugin/zhanmishu_sms','you_have_login_and_not_need_register')));
	echo json_encode($return);
	exit;
}

$data = array();
$data['phone'] = preg_replace("/\s/",'',daddslashes($_GET['mobile'] ? $_GET['mobile'] : $_GET['phone']));
$data['code'] = intval($_GET['code']);
$data['nationcode'] = $_GET['nationcode'] ? $_GET['nationcode'] : $sendsms->get_nationcode($data['mobile']);
if ($data['nationcode']) {
	$data['phone'] = str_replace('+'.$data['nationcode'],'',$data['phone']);
}
$data['mobile'] = $data['phone'];
if($_GET['email']){
	$data['email'] = daddslashes($_GET['email']);
}

if ($_GET['sms_verify'] || $_GET['verify']) {
	$data['verify'] = intval($_GET['sms_verify'] ? $_GET['sms_verify'] : $_GET['verify']);
}
if ($_GET['username']) {
	$data['username'] = daddslashes($_GET['username']);
	$data['passwd'] = daddslashes($_GET['passwd']);
}

if (submitcheck('no_submit') && $_GET['method']=='send') { 
	// is verify code?
	if ($config['regsmssec']) {
		if(!check_seccode($_GET['seccodeverify'], $_GET['seccodehash'], 1, $_GET['seccodemodid'])){
			$return = array('code'=>'-92','msg'=>zhanmishu_sms::auto_charset_change(lang('plugin/zhanmishu_sms','check_seccode_error')));
			echo json_encode($return);
			exit;
		}
	}
	$return =  $sendsms->sendsms($data['phone'],$data['code'],'',$data['nationcode']);
	echo json_encode($return);

}else if (submitcheck('no_submit') && $_GET['method']=='verify') {
	$verify = new zhanmishu_sms($config,$data['code'],$data['verify']);
	$return = $verify->verify();
	echo json_encode($return);

}else if (submitcheck('registersubmit') && $_GET['method']=='register' && $config['ismobileregister']) {

	// $data['username']  = diconv(strval($data['username']),'UTF-8', CHARSET );
	// $data['passwd']  = diconv(strval($data['passwd']),'UTF-8', CHARSET );
	$register = new zhanmishu_sms($config,$data['code'],$data['verify']);
	$return = $register->mobile_register($data);

	if ($return['code'] == '1') {
		$return['msg'] = dreferer();
			$verify = new zhanmishu_mobileverify($config);
			$ismobileverify = $verify -> ismobile_verify($data['mobile']);
			if (!$ismobileverify && $_G['uid'] && $config['auto_verify']) {
				$verify->set_verify($_G['uid'],false,$data['mobile'],'1','',$_G['username'],true);
			}
	}
	echo json_encode($return);
}
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
?>