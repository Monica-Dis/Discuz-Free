<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_zhanmishu_sms {
	function smsHander() {
		$smsHander = new zhanmishu_sms();
		return $smsHander;
	}
	function is_weixin() {
		global $_G;
		$config = $this->smsHander()->config;
		if (!$config['iswechat'] || $_G['uid']) {
			return false;
		}
	    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) { 
	        return true; 
	    } return false; 
	}
	function common(){
		if(defined('IN_MAGMOBILE_API')) {
			return;
		}
		global $_G;
		$config = $this->smsHander()->config;
    	if ($config['mobilelogin'] && CURSCRIPT == 'member' && $_GET['mod'] =='logging' && isset($_GET["loginsubmit"]) && $_GET['action']=='login') {
    		$username = addslashes($_GET['username']);
    		$ismobile = $this->smsHander()->verify_mobile_number($username);
    		if ($ismobile) {
    			$isuser = $this->smsHander()->checkusernameexists($username);
    			if ($isuser) {
    				return ;
    			}
				$uid = $this->smsHander()->getuidbymobile($username);
	    		if ($uid) {
	    			loaducenter();
	    			$user = uc_get_user($uid,true);
	    			$_GET['username'] = $user[1];
	    			$_POST['username'] = $user[1];
	    		}
    		}
    	}
	}

	function global_footer_mobile(){
		if(defined('IN_MAGMOBILE_API') || $this->is_weixin()) {
			return;
		}
		global $_G;
		$config = $this->smsHander()->config;
    	if ($config['iseasy_verisy'] && (CURSCRIPT == 'portal' || CURSCRIPT == 'forum') && $_G['uid'] && !defined('IN_ADMINCP')  && $_GET['id'] !=='zhanmishu_sms:verify') {
			$ispostcheck = $this->smsHander()->ispost_check();
			$mobile = $this->smsHander()->get_usermobile();
    		if ($ispostcheck) {
    			header('location:'.$_G['siteurl'].'plugin.php?id=zhanmishu_sms:verify&mobile='.$mobile);
    			exit;
    		}
		}
		if ($_G['uid'] || !$this->issmsopen()) {
			$isreply_check = $this->smsHander()->isreply_check(1,1);
			if ($isreply_check && $_G['uid']) {
				$mobile = $this->smsHander()->get_usermobile();
				return '<script>(function(){$("#fastpostmessage").on("focus", function() {popup.open("'.lang('plugin/zhanmishu_sms','verify_before_post').'", "confirm", "plugin.php?id=zhanmishu_sms:verify&mobile='.$mobile.'");});$("#needmessage").on("focus", function() {popup.open("'.lang('plugin/zhanmishu_sms','verify_before_post').'", "confirm", "plugin.php?id=zhanmishu_sms:verify&mobile='.$mobile.'");})})();</script>';
			}
			return;
		}
		if (CURSCRIPT == 'member') {
			if ($config['register_gotospa'] && $_GET['mod'] == $_G['setting']['regname'] && $_G['setting']['regstatus']) {
				$url = $_G['siteurl'].'plugin.php?id=zhanmishu_sms:register#/';
				dheader("location:".$url);
				exit;
			}else if ($config['login_gotospa'] && ($_GET['mod'] == 'login' || $_GET['action'] == 'login') && !strpos(dreferer(), 'zhanmishu_sms:register')) {
				$url = 'plugin.php?id=zhanmishu_sms:register#/login';
				dheader("location:".$url);
				exit;
			}
		}

		// include template("zhanmishu_sms:register");
		// return $register;
	}
	function  call_function($function,$args=array()){
		include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/function.php';
		$return =  call_user_func_array($function,$args);
	
		return $return;
	}
	function issmsopen(){
		$config = $this->smsHander()->config;
		return $config['ismobileopen'];
	}

}

class mobileplugin_zhanmishu_sms_member extends  mobileplugin_zhanmishu_sms{
	function logging_bottom_mobile(){
		return '<p><a href="plugin.php?id=zhanmishu_sms:getpassword&mod=mobilegetpasswd">'.lang('plugin/zhanmishu_sms', 'fogetpwd_getpasswd_bymobile').'</a></p>';
	}

	function register_input_message(){
		if (!$this->issmsopen()) {
			return ;
		}
		global $_G;
		$config = $this->smsHander()->config;
		if ($_G['uid'] && !empty($_POST) &&  $_GET['regsubmit']='yes' && $_GET['mobile']) {
			$verify = $this->get_verify();
			$sid = $verify->get_sid();
			$data = daddslashes($_GET);
			if ($sid) {
				C::t('#zhanmishu_sms#zhanmishu_sms')->update($sid,array('uid'=>$_G['uid'],'isregsuccess'=>'1'));
				if ($config['isauto']) {
					C::t('common_member_profile')->update($_G['uid'],array('mobile'=>$data['mobile']));
				}
			}
			$verify->clear_send_coolie();
		}
		if ($_G['uid'] && !empty($_POST) && $config['auto_verify']) {
			$data = daddslashes($_GET);
			$fields = array();
			$fields['uid'] = $_G['uid'];
			$fields['mobile'] = $data['mobile'];
			$fields['type'] = '1';
			$fields['issuccess'] = '1';
			$fields['dateline'] = TIMESTAMP;
			$user = C::t("#zhanmishu_sms#zhanmishu_sms")->fetch_by_fields($fields);
			$verify = new zhanmishu_mobileverify($config);
			$verify->checkApp_updateMobile($fields['mobile'],$fields['uid']);

			$ismobileverify = $verify->isSyncVerifyMobile($data['mobile']);
			if (empty($user) && !$ismobileverify) {
				$verify->set_verify($_G['uid'],0,$fields['mobile'],'1','',$_G['username']);
			}
		}
	}
	function register_code(){
		if (!$this->issmsopen()) {
			return ;
		}
		global $_G;
		$username = trim($_GET[''.$_G['setting']['reginput']['username']]);
		$password = $_GET[''.$_G['setting']['reginput']['password']];

        if ($username && $password) {
        	$verify = $this->get_verify();
			$return = $verify->verify();

			if ($return['code'] < 0) {
				showmessage(lang('plugin/zhanmishu_sms','please_input_right_info'));
			}
        }


        return;
    }
    function get_verify(){
    	global $_G;
        if (!empty($_POST)) {
        	$config = $this->smsHander()->config;
			$data = daddslashes($_GET);
			$data['code'] = strval($data['code']);
			$data['sms_verify'] = strval($data['sms_verify']);
			
			$verify = new zhanmishu_mobileverify($config,$data['code'],$data['sms_verify']);
			return $verify;
		}
		return false;
    }
}
class mobileplugin_zhanmishu_sms_forum extends  mobileplugin_zhanmishu_sms{
	function post_recode($params) {
		global $_G;
		if (!$_G['uid']) {
			return ;
		}
		$verifytype =  $this->smsHander()->get_verify_id();

		if (!$verifytype) {
			return;
		}
		$info = $this->smsHander()->get_member_verify_info($_G['uid'],$verifytype);
		$config = $this->smsHander()->config;
		$isvid = $this->smsHander()->check_user_isverify($_G['uid']);
		$mobile = $info['field']['mobile'] ? $info['field']['mobile'] : $this->smsHander()->get_usermobile();
		if ($_GET['action'] != 'reply') {
			$ispostcheck = $this->smsHander()->ispost_check();
			if ($ispostcheck) {
				showmessage(lang('plugin/zhanmishu_sms', 'please_verify_before_post'), 'plugin.php?id=zhanmishu_sms:verify&mobile='.$mobile, array());
			}
		}else{
			//check is_replay_verify
			$isreply_check = $this->smsHander()->isreply_check();
			if ($isreply_check) {
				# code...
				showmessage(lang('plugin/zhanmishu_sms','verify_before_post'), 'plugin.php?id=zhanmishu_sms:verify&mobile='.$mobile, array());
			}
		}	
		return;
	}
	function post_zhanmishu_sms_message($params) {

		global $_G;
		if ($params['param']['0'] == 'post_reply_succeed') {
			$tid = $params['param']['2']['tid'];
			$pid = $params['param']['2']['pid'];
			$fid = $params['param']['2']['fid'];

			$notice = new zhanmishu_notice();
			$notice ->notice($tid,$pid,$fid,$tiduser,$_G['uid']);

		}else if ($params['param']['0'] == 'post_newthread_succeed') {
			$tsetting = array();
			if ($_GET['issmsnotice']) {$tsetting['issmsnotice'] = '1';}
			if ($_GET['isemailnotice']) {$tsetting['isemailnotice'] = '1';}
			$tsetting['tid'] = $params['param']['2']['tid'];
			$tsetting['uid'] = $_G['uid'];
			$tsetting['dateline'] = TIMESTAMP;
			C::t("#zhanmishu_sms#zhanmishu_tsetting")->insert($tsetting,false,true);
		}
		
	}
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/Autoloader.php';
?>