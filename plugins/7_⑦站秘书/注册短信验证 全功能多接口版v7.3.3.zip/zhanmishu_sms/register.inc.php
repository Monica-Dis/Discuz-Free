<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/function.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_sms/include/Autoloader.php';

$sms = new zhanmishu_sms();
$config = $sms->config;

if ($_GET['action'] == 'common') {

    $return['formhash'] = FORMHASH;
    $return['uid'] = $_G['uid'];
    if ($_G['uid']) {
      $return['mobile'] = $sms->get_usermobile();
      if ($return['mobile']) {
        $return['nationcode'] = '';
      }
    }
    $sechash = !isset($sechash) ? 'S'.($_G['inajax'] ? 'A' : '').$_G['sid'] : $sechash.random(3);
    $return['sechash'] = $sechash;
    $return['groupid'] = $_G['groupid'];
    $return['username'] = $_G['username'];
    $return['bbrulestxt'] = nl2br($_G['setting']['bbrulestxt']);
    $return['loginhash'] = 'L'.random(4);
    $return['config']['regsmssec'] = $config['regsmssec'];
    $return['mobilebuttoncolor'] = $config['mobilebuttoncolor'];
    $return['isShowEmail'] = $config['isShowEmail'];
    $return['login_html'] = str_replace('{referer}', urlencode(dreferer()), $config['login_html']);
    $return['isquestion'] = $config['isquestion'];
    $return = array_merge($_G['setting']['reginput'],$return,$_G['setting']['seccodedata']);
 

    echo json_encode($sms->auto_to_utf8($return));
    exit;
}else if ($_GET['action'] == 'sendapi') {
  define('NO_CHECK_MOBILE', 1);

  $_GET['mobile'] = trim($_GET['mobile']);
  if ($_GET['key'] !== $config['sendsafekey']) {
    exit('Access Denied');
  }
  $mobile = $_GET['mobile'];
  
  if (strlen($_GET['mobile']) == 11 && strpos($_GET['mobile'], '+') === false && substr($_GET['mobile'], 0,1) == '1') {
    $nationcode = '86';
  }

  $verify = $verify ? $verify : rand(100000,999999);
  $verify = diconv(strval($verify),CHARSET , 'UTF-8');

  $resp = $sms->sendsms(daddslashes($mobile),$verify,$verify);

  if ($resp['code'] == '1') {
    $return = array('success'=>true);
    $return['code'] = $verify;

    $sendData = array();
    if (isset($resp['result']['err_code']) && $resp['result']['err_code'] == '0') {
        $sendData['model'] = $sms->diconv_back($resp['result']['model']);
        $sendData['issuccess'] = 1;
    }else{
        $sendData['code'] = $sms->diconv_back($resp['code']);
        $sendData['issuccess'] = 0;
        $sendData['msg'] = $sms->diconv_back($resp['msg']);
        $sendData['sub_code'] = $sms->diconv_back($resp['sub_code']);
        $sendData['sub_msg'] = $sms->diconv_back($resp['sub_msg']);
    }
        $sendData['issend'] = 1;
        $sendData['mobile'] = $mobile;
        $sendData['type'] = $sms->type;
        $sendData['verify'] = $verify;
        $sendData['dateline'] = TIMESTAMP;
        if ($_G['uid']) {
            $sendData['uid'] = $_G['uid'];
        }


    C::t("#zhanmishu_sms#zhanmishu_sms")->insert($sendData,false);

    echo json_encode($return);
    exit;
  }else{
    $return = array('success'=>false);
    $return['msg'] = $resp['msg'];
    echo json_encode($return);
    exit;
  }
}

// if (!defined('IN_MOBILE')) {
//   dheader("location:member.php?mod=logging&action=login");
//   exit;
// }

ob_end_clean();
$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
dheader('Content-type:text/html;charset=utf-8');

include template("zhanmishu_sms:user");