<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From: Dism_taobao_com $
 *		���²����http://t.cn/Aiux1Jx1 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_zhanmishu_tsetting extends discuz_table {

	public function __construct() {
		$this->_table = 'zhanmishu_tsetting';
		$this->_pk = 'tid';

		parent::__construct();
	}


}