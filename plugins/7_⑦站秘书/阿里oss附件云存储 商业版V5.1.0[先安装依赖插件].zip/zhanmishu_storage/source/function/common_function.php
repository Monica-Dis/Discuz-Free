<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */	

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function gmt_iso8601($time) {
    date_default_timezone_set('PRC');
    $dtStr = date("c", $time);
    $mydatetime = new DateTime($dtStr);
    $expiration = $mydatetime->format(DateTime::ISO8601);
    $pos = strpos($expiration, '+');
    $expiration = substr($expiration, 0, $pos);
    return $expiration."Z";
}


function zms_storage_pic_save($FILE, $albumid, $title, $iswatermark = true, $catid = 0) {
    global $_G;
    $title = getstr($title, 200);
    $title = censor($title);
    if(censormod($title) || $_G['group']['allowuploadmod']) {
        $pic_status = 1;
    } else {
        $pic_status = 0;
    }
    $FILE['key'] = str_replace('album/', '', $FILE['key']);
    $setarr = array(
        'albumid' => $albumid,
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'dateline' => $_G['timestamp'],
        'filename' => addslashes($FILE['Filename']),
        'postip' => $_G['clientip'],
        'port' => $_G['remoteport'],
        'title' => $title,
        'type' => substr(addslashes($FILE['filetype']), 1),
        'size' => $FILE['filesize'],
        'filepath' => $FILE['key'],
        'thumb' => $FILE['key'],
        'remote' => '1',
        'status' => $pic_status,
    );
    $setarr['picid'] = C::t('home_pic')->insert($setarr, 1);

    C::t('common_member_count')->increase($_G['uid'], array('attachsize' => $FILE['filesize']));

    include_once libfile('function/stat');
    if($pic_status) {
        updatemoderate('picid', $setarr['picid']);
    }
    updatestat('pic');

    return $setarr;
}
//From: d'.'is'.'m.ta'.'obao.com
?>