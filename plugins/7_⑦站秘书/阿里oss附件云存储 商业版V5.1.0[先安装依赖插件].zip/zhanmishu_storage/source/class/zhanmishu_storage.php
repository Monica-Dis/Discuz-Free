<?php
/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      应用更新支持：https://dism.taobao.com
 *    	最新插件：http://t.cn/Aiux1Jx1
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';


class zhanmishu_storage extends zhanmishu_base{
	
	public $config=array();
    public static function cacheKey(){
        return 'zhanmishu_storage';
    }
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }
    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    public function afterCreate(){
        global $_G;
        loadcache('plugin');
        $config = $_G['cache']['plugin']['zhanmishu_storage'];
        $config['apiselect'] = $config['apiselect'] ? $config['apiselect'] : '1';

        if ($config['apiselect'] == '1') {
            $config['host'] = $config['host'];
        }else if ($config['apiselect'] == '2') {
            $config['host'] = $config['upyun_host'].'/'.$config['upyun_bucket'];
        }

        $config['compress_width'] =  $config['compress_width'] ? $config['compress_width'] : 1600;
        $config['compress_height'] =  $config['compress_height'] ? $config['compress_height'] : 1600;
        $config['compress_quality'] =  $config['compress_quality'] ? $config['compress_quality'] : 100;

        $this->config = $config;
        $this->config['upyun_white_ext'] = self::strToArray($config['upyun_white_ext']);
    }


    static function strToArray($str){
        $str = str_replace(array("\r\n", "\r", "\n"), array('$#','$#','$#'), $str);
        $arr = explode('$#', $str);

        $arr = array_filter($arr);
        return $arr;
    }

    public static function base64Json($params)
    {
        return base64_encode(json_encode($params, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }
    /**
     * 获取表单 API 需要的签名，依据 body 签名规则计算
     * @param Config $serviceConfig
     * @param $method 请求方法
     * @param $uri 请求路径
     * @param $date 请求时间
     * @param $policy
     * @param $contentMd5 请求 body 的 md5
     *
     * @return array
     */
    public static function getBodySignature($operatorName, $key, $method, $uri, $date = null, $policy = null, $contentMd5 = null)
    {
        $data = array(
            $method,
            $uri
        );
        if ($date) {
            $data[] = $date;
        }

        if ($policy) {
            $data[] = $policy;
        }

        if ($contentMd5) {
            $data[] = $contentMd5;
        }

        $signature = base64_encode(hash_hmac('sha1', implode('&', $data), $key, true));


        
        return 'UPYUN ' . $operatorName . ':' . $signature;
    }
	public function get_target_dir($type, $extid = '', $check_exists = true) {

		$subdir = $subdir1 = $subdir2 = '';
		if($type == 'album' || $type == 'forum' || $type == 'portal' || $type == 'category' || $type == 'profile') {
			$subdir1 = date('Ym');
			$subdir2 = date('d');
			$subdir = $subdir1.'/'.$subdir2.'/';
		} elseif($type == 'group' || $type == 'common') {
			$subdir = $subdir1 = substr(md5($extid), 0, 2).'/';
		}

		$check_exists && $this->check_dir_exists($type, $subdir1, $subdir2);

		return $subdir;
	}
	public function check_dir_exists($type = '', $sub1 = '', $sub2 = '') {

		$type = $this->check_dir_type($type);

		$basedir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT.'./data/attachment') : getglobal('setting/attachdir');

		$typedir = $type ? ($basedir.'/'.$type) : '';
		$subdir1  = $type && $sub1 !== '' ?  ($typedir.'/'.$sub1) : '';
		$subdir2  = $sub1 && $sub2 !== '' ?  ($subdir1.'/'.$sub2) : '';

		$res = $subdir2 ? is_dir($subdir2) : ($subdir1 ? is_dir($subdir1) : is_dir($typedir));
		if(!$res) {
			$res = $typedir && $this->make_dir($typedir);
			$res && $subdir1 && ($res = $this->make_dir($subdir1));
			$res && $subdir1 && $subdir2 && ($res = $this->make_dir($subdir2));
		}

		return $res;
	}

	function make_dir($dir, $index = true) {
		$res = true;
		if(!is_dir($dir)) {
			$res = @mkdir($dir, 0777);
			$index && @touch($dir.'/index.html');
		}
		return $res;
	}
	public	function check_dir_type($type) {
		return !in_array($type, array('forum', 'group', 'album', 'portal', 'common', 'temp', 'category', 'profile')) ? 'temp' : $type;
	}
	public function get_target_filename($type, $extid = 0, $forcename = '') {
		if($type == 'group' || ($type == 'common' && $forcename != '')) {
			$filename = $type.'_'.intval($extid).($forcename != '' ? "_$forcename" : '');
		} else {
			$filename = date('His').strtolower(random(8));
		}
		return $this->config['oss_filename_head'].$filename;
	}


    private function stringToSignSorted($string_to_sign)
    {
        $queryStringSorted = '';
        $explodeResult = explode('?', $string_to_sign);
        $index = count($explodeResult);
        if ($index === 1)
            return $string_to_sign;

        $queryStringParams = explode('&', $explodeResult[$index - 1]);
        sort($queryStringParams);

        foreach($queryStringParams as $params)
        {
             $queryStringSorted .= $params . '&';    
        }

        $queryStringSorted = substr($queryStringSorted, 0, -1);

        return $explodeResult[0] . '?' . $queryStringSorted;
    }
   	public static function Curl($url,$isJsonDecode=false){
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //不验证证书
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //不验证证书
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30); 
		$resultj = curl_exec($ch);
        if(curl_exec($ch) === false){
            // echo 'Curl error: ' . curl_error($ch);
        }
		curl_close($ch); 

		if ($isJsonDecode) {
			return json_decode(diconv($resultj,'GBK','UTF-8'),true);
		}else{
			return $resultj;
		}
		
	}

	public function Oss_Signatureurl($filename){



		$expire=TIMESTAMP + 1800;
		$bucketname=$this->config['bucketname'];
		
		$StringToSign="GET\n\n\n$expire\n/$bucketname$filename";
		$Sign=base64_encode(hash_hmac("sha1",$StringToSign,$this->config['AccessKeySecret'],true));

		return $filename."?OSSAccessKeyId=".rawurlencode($this->config['OSSAccessKeyId'])."&Expires=".$expire."&Signature=".rawurlencode($Sign);

	}

	public $files_list = array();

	public function get_all_files($prefix='',$nextMarker=''){
		$list = $this->get_file_lists($prefix,$nextMarker);
		$nextMarker = $list['nextMarker'];
		for ($i=0; $i < 10; $i++) { 
		}
		$this->files_list = array($this->files_list,$list);
		return $this->files_list;
	}


    public function get_type_file_num($tablename,$field=array()){
        if (!empty($field) && is_array($field)) {
            $where = ' where ';
            $tmp = array();
            foreach ($field as $key => $value) {
                if (is_string($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if($value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }

        $count = DB::fetch_first('SELECT count(*) as num FROM %t '.$where,array($tablename));
        return $count['num'];
    }

    public function get_type_file($tablename,$start=0, $limit=20, $sort = '',$field=array()) {

        if (is_array($sort)) {
            $tmp = array();
            foreach ($sort as $key => $value) {
                $tmp[] = DB::order($key, $value);
            }
            $tmp = implode(' , ', $tmp);

            $order = ' ORDER BY '.$tmp;
        }else{
            $order = $sort ? ' ORDER BY '.DB::order('aid', $sort) : '';
        }

        if (!empty($field)) {
            $where = ' where ';

            $tmp = array();
            foreach ($field as $key => $value) {
                if (is_string($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if($value['relation']){

                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }
        return  DB::fetch_all('SELECT * FROM %t '.$where.$order.DB::limit($start, $limit), array($tablename));

    }
    public function get_type_attachment_num($tableid,$field=array()){
        if (!empty($field) && is_array($field)) {
            $where = ' where ';
            $tmp = array();
            foreach ($field as $key => $value) {
                if (is_string($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if($value['relation']){
                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }

        $count = DB::fetch_first('SELECT count(*) as num FROM %t '.$where,array('forum_attachment_'.$tableid));
        return $count['num'];
    }
    public function get_type_attachment($tableid,$start=0, $limit=20, $sort = '',$type = '',$field=array()) {

        if (is_array($sort)) {
            $tmp = array();
            foreach ($sort as $key => $value) {
                $tmp[] = DB::order($key, $value);
            }
            $tmp = implode(' , ', $tmp);

            $order = ' ORDER BY '.$tmp;
        }else{
            $order = $sort ? ' ORDER BY '.DB::order('aid', $sort) : '';
        }

        if (!empty($field)) {
            $where = ' where ';

            $tmp = array();
            foreach ($field as $key => $value) {
                if (is_string($value)) {
                    $tmp[] = ' '.$key.' = \''.$value.'\' ';
                }else if($value['relation']){

                    switch (trim(strtolower($value['relation']))) {
                        case 'like':
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \'%'.$value['value'].'%\' ';
                            break;
                        case 'sql':
                            $tmp[] = $value['sql'];
                            break;
                        default:
                            $tmp[] = ' '.$value['key'].' '.$value['relation'].' \''.$value['value'].'\' ';
                            break;
                    }
                }
            }
            $where .= implode(' and ', $tmp);

        }else{
            $where = '';
        }
        return  DB::fetch_all('SELECT * FROM %t '.$where.$order.DB::limit($start, $limit), array('forum_attachment_'.$tableid));

    }

    public function upload_oss_local_file($attach){
        global $thisTable,$_G;
        if (!$attach['attachment']) {
            
        }
        if (strpos($thisTable,'forum') !== false) {
            $current = 'forum';
        }elseif (strpos($thisTable,'portal') !== false) {
            $current = 'portal';
        }elseif (strpos($thisTable,'home') !== false) {
            if ($attach['albumid']) {
                $current = 'album';
            }else{
                $current = 'album';
            }
            
        }else{
            return '';
        }

        if ($current == 'portal' && $_G['setting']['ftp']['attachdir'] != '.') {
            if(substr($_G['setting']['ftp']['attachdir'], 0 ,1) == '/'){
                $_G['setting']['ftp']['attachdir'] = substr($_G['setting']['ftp']['attachdir'], 1);
            }
            if(substr($_G['setting']['ftp']['attachdir'], -1 ,1) == '/'){
                $_G['setting']['ftp']['attachdir'] = substr($_G['setting']['ftp']['attachdir'], 0, strlen($_G['setting']['ftp']['attachdir']) - 1);
            }
            $remoteFilePath = $_G['setting']['ftp']['attachdir'].'/'.$attach['attachment'];
        }else if ($current == 'portal' && $_G['setting']['ftp']['attachdir'] == '.') {
            $remoteFilePath = $attach['attachment'];
        }else if (!$_G['setting']['ftp']['attachdir'] || $_G['setting']['ftp']['attachdir'] == '.') {
            $remoteFilePath = $current.'/'.$attach['attachment'];
        }else{
            $remoteFilePath = $_G['setting']['ftp']['attachdir'].'/'.$current.'/'.$attach['attachment'];
        }


        if ($thisTable == 'portal_article_title') {
            $localFilePath = $_G['setting']['attachdir'].$attach['attachment'];
        }else{
            $localFilePath = $_G['setting']['attachdir'].'/'.$current.'/'.$attach['attachment'];
        }

        if (!is_file($localFilePath)) {
            return -1;
        }
        $key = $remoteFilePath;
        $oss_config = $this->config;
        if ($oss_config['use_intranet']) {
            $endpoint = $oss_config['intranet_EndPoint'];
        }else{
            $endpoint = substr($oss_config['host'], strpos($oss_config['host'],'.')+1);
        }
        $OssClient  = new OssClient($oss_config['OSSAccessKeyId'],$oss_config['AccessKeySecret'],$endpoint);

        try {
            //return $OssClient->putObjectAcl($oss_config['bucketname'], $key, 'public-read');

            $options = array();
            $options[OssClient::OSS_HEADERS]['Content-Disposition'] = 'attachment; filename="'.diconv($attach['filename'],CHARSET,'UTF-8').'"';
            if ($attach['isimage'] || $thisTable == 'portal_article_title') {
                $options[OssClient::OSS_HEADERS][OssClient::OSS_OBJECT_ACL] = 'public-read';
            }
            $r = $OssClient->uploadFile($oss_config['bucketname'], $key, $localFilePath, $options);


            if (is_file($localFilePath.'.thumb.jpg')) {
                $options = array();
                $options[OssClient::OSS_HEADERS]['Content-Disposition'] = 'attachment; filename="'.diconv($attach['filename'],CHARSET,'UTF-8').'"';
                if ($attach['isimage'] || $thisTable == 'portal_article_title' || $thisTable == 'home_pic') {
                    $options[OssClient::OSS_HEADERS][OssClient::OSS_OBJECT_ACL] = 'public-read';
                }
                $r = $OssClient->uploadFile($oss_config['bucketname'], $key.'.thumb.jpg', $localFilePath.'.thumb.jpg', $options);
            }

            if ($r['oss-request-url']) {
                if($this->config['deleteOriginFile']) {
                    @link($localFilePath);
                    if (is_file($localFilePath.'.thumb.jpg')) {
                        @link($localFilePath.'.thumb.jpg');
                    }
                }
                return true;
            }
            return false;
        } catch (Exception $e) {
            echo $e->getMessage();
            return false;
        }
    }
    public function update_acl($attach){
        global $thisTable,$_G;
        if (!$attach['attachment']) {
            
        }
        if (strpos($thisTable,'forum') !== false) {
            $current = 'forum';
        }elseif (strpos($thisTable,'portal') !== false) {
            $current = 'portal';
        }elseif (strpos($thisTable,'home') !== false) {
            if ($attach['albumid']) {
                $current = 'album';
            }else{
                $current = 'album';
            }
            
        }else{
            return '';
        }

        if (!$_G['setting']['ftp']['attachdir'] || $_G['setting']['ftp']['attachdir'] == '.') {
            $remoteFilePath = $current.'/'.$attach['attachment'];
        }else{
            $remoteFilePath = $_G['setting']['ftp']['attachdir'].'/'.$current.'/'.$attach['attachment'];
        }

        return $this->set_remote_file_acl($remoteFilePath);

    }
    public function set_remote_file_acl($key=''){
        if (!$key) {
            return;
        }
        $oss_config = $this->config;
        if ($oss_config['use_intranet']) {
            $endpoint = $oss_config['intranet_EndPoint'];
        }else{
            $endpoint = substr($oss_config['host'], strpos($oss_config['host'],'.')+1);
        }
        $OssClient  = new OssClient($oss_config['OSSAccessKeyId'],$oss_config['AccessKeySecret'],$endpoint);

        try {
            return $OssClient->putObjectAcl($oss_config['bucketname'], $key, 'public-read');
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    public function set_remote_filename($key,$filename=''){
        if (!$key || !$filename) {
            return;
        }
        $oss_config = $this->config;
        if ($oss_config['use_intranet']) {
            $endpoint = $oss_config['intranet_EndPoint'];
        }else{
            $endpoint = substr($oss_config['host'], strpos($oss_config['host'],'.')+1);
        }
        $OssClient  = new OssClient($oss_config['OSSAccessKeyId'],$oss_config['AccessKeySecret'],$endpoint);

        $options = array();
        $options[OssClient::OSS_HEADERS]['Content-Disposition'] = 'attachment; filename="'.diconv($filename,CHARSET,'UTF-8').'"';
        try {
            return $OssClient->copyObject($oss_config['bucketname'], $key, $oss_config['bucketname'], $key, $options);
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function OSS_CDN_sign($url){
        $config = $this->config;
        $expire=TIMESTAMP + 1800;

        if (!$config['file_cdn_url'] || !$config['file_cdn_url_key']) {
            return false;
        }
        $signKey = $config['file_cdn_url_key'];

        // /video/standard/1K.html-1444435200-0-0-aliyuncdnexp1234"
        $str = '/'.$url.'-'.$expire.'-0-0-'.$signKey;
        $HashValue = md5($str);
        return $url.'?auth_key='.$expire.'-0-0-'.$HashValue;
    }
    public function get_oss_sign_url($filename){
        $oss_config = $this->config;
        if ($oss_config['apiselect'] != '1') {
            return $filename;
        }
        
        if (substr($filename,0,1) == '/') {
            $filename = substr($filename,1);
        }

        if ($oss_config['file_cdn_url'] && $oss_config['file_cdn_url_key']) {
            return $this->OSS_CDN_sign($filename);
        }       

		$oss_config = $this->config;
		$endpoint = substr($oss_config['host'], strpos($oss_config['host'],'.')+1);

		$OssClient  = new OssClient($oss_config['OSSAccessKeyId'],$oss_config['AccessKeySecret'],$endpoint);
        $url = $OssClient->signUrl($oss_config['bucketname'], $filename, $timeout = 600,'GET');
        return substr($url,strpos($url,$filename));
	}


	public function get_file_lists($prefix='',$marker=''){
		global $_G;

		$oss_config = $this->config;
		$OssClient  = new OssClient($oss_config['OSSAccessKeyId'],$oss_config['AccessKeySecret'],substr($oss_config['host'], strpos($oss_config['host'],'.')+1));

		$listObjectInfo = $OssClient->listObjects($oss_config['bucketname'],array('max-keys'=>'3','prefix'=>$prefix,'marker'=>$marker));

		$nextMarker = $listObjectInfo->getNextMarker();
		$listObject = $listObjectInfo->getObjectList();
		$listPrefix = $listObjectInfo->getPrefixList();

		$list = array();
		$list['nextMarker'] = $nextMarker;
		foreach($listObject as $info){
		    $list['file'][] = array(
		            'name' => $info->getKey(),
		            'lastModified' => $info->getLastModified()
		        );
		}
		foreach($listPrefix as $info){
		    $list['dir'][] = array('name' => $info->getPrefix());
		}
		
		return $list;
	}

}