<?php
/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      应用更新支持：https://dism.taobao.com
 *      最新插件：http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}


class log_
{
	// 打印log
	function  log_result($file,$word) 
	{
	    $fp = fopen($file,"a");
	    flock($fp, LOCK_EX) ;
	    fwrite($fp,"time is :".strftime("%Y-%m-%d-%H：%M：%S",time())."\n".$word."\n\n");
	    flock($fp, LOCK_UN);
	    fclose($fp);
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>