<?php
/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Ӧ�ø���֧�֣�https://dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!class_exists('table_zhanmishu_base',false)) {
    C::import('table_zhanmishu_base','plugin/zhanmishu_app/table');
}

class table_zhanmishu_storage_log extends table_zhanmishu_base {

    public function __construct() {
        $this->_table = 'zhanmishu_storage_log';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }
}