<?php
/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      应用更新支持：https://dism.taobao.com
 *      最新插件：http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/zhanmishu_storage/source/Autoloader.php';


$zhanmishu_storage = zhanmishu_storage::getInstance();
$oss_config = $zhanmishu_storage->config;
$url = 'plugins&operation=config&do=198&identifier=zhanmishu_storage&pmod=sync_admin';

if ($oss_config['apiselect'] == '2') {
    cpmsg(lang('plugin/zhanmishu_storage','auto_sync_upyun_error'),'');
}

$tablesConfig = array(
    'forum_attachment_0'=>'forum_attachment_0',
    'forum_attachment_1'=>'forum_attachment_1',
    'forum_attachment_2'=>'forum_attachment_2',
    'forum_attachment_3'=>'forum_attachment_3',
    'forum_attachment_4'=>'forum_attachment_4',
    'forum_attachment_5'=>'forum_attachment_5',
    'forum_attachment_6'=>'forum_attachment_6',
    'forum_attachment_7'=>'forum_attachment_7',
    'forum_attachment_8'=>'forum_attachment_8',
    'forum_attachment_9'=>'forum_attachment_9',
    'portal_article_title'=>'portal_article_title',
    'portal_attachment'=>'portal_attachment',
    'portal_topic_pic'=>'portal_topic_pic',
    'home_pic'=>'home_pic',
);
$tables = array();
foreach ($tablesConfig as $key => $value) {
    $tables[] = array($key,$value);
}
if (submitcheck('sync_oss_submit') || ($_GET['sync'] == 'yes'  &&   $_GET['formhash'] == formhash())) {

    set_time_limit(0);
    //cpmsg(lang('plugin/zhanmishu_storage','sync_oss_ing'),'action=plugins&'.$url.'&formhash='.$_GET['formhash'].'&table_keys='.$table_keys.'&sync=yes');

    $tables = $_GET['tables'] ?  $_GET['tables'] : explode(',', $_GET['table_keys']);
    $tables = array_filter($tables);
    if (empty($tables)) {
        cpmsg(lang('plugin/zhanmishu_storage','please_check_tables'),'');
    }
    $table_keys = $_GET['$table_keys'] ? $_G['$table_keys'] : implode(',', array_values($tables));

    $thisTable = $_GET['thisTable'] ? daddslashes($_GET['thisTable']) : '';
    $thisPage = $_GET['thisPage'] ? $_GET['thisPage'] : '1';
    $thisTotal = $_GET['thisTotal'] + 0;

    if (!$thisTable) {
        ksort($tables);
        $thisTable = current($tables);
    }

    $field = array();
    
    if ($thisTable == 'home_pic') {
        $field[] = array('relation'=>'sql','sql'=>' remote in (0,2)');
    }else{
        $field[] = array('relation'=>'=','key'=>'remote','value'=>'0');
    }

    if ($thisTable == 'portal_article_title') {
        $field[] = array('relation'=>'!=','key'=>'pic','value'=>'');
    }

    if ($thisPage == '1' || $thisTotal < 1) {
        $thisTotal = $zhanmishu_storage->get_type_file_num($thisTable,$field);
    }



    $perpage=$oss_config['acl_perpage'] ? $oss_config['acl_perpage'] :  10;
    $start = $thisTotal - ($thisTotal - $perpage*$thisPage+$perpage);
    $pages= ceil($thisTotal / $perpage);

    $thisFiles = $zhanmishu_storage->get_type_file($thisTable,$start, $perpage, '',$field);


    foreach ($thisFiles as $key => $value) {

        if ($thisTable == 'portal_article_title') {
            if (!$value['pic']) {
                continue;
            }
            $value['attachment'] = $value['pic'];
        }elseif ($thisTable == 'home_pic') {
            if (!$value['filepath']) {
                continue;
            }
            $value['attachment'] = $value['filepath'];
        }
        $upload_responce = $zhanmishu_storage->upload_oss_local_file($value);

        if ($upload_responce == -1) {
            $upload_responce = true;
        }

        if ($upload_responce && in_array($thisTable,array('forum_attachment_0','forum_attachment_1','forum_attachment_2','forum_attachment_3','forum_attachment_4','forum_attachment_5','forum_attachment_6','forum_attachment_7','forum_attachment_8','forum_attachment_9'))) {
            $tableid = str_replace('forum_attachment_', '', $thisTable);
            C::t('forum_attachment_n')->update($tableid,$value['aid'],array('remote'=>'1'));
        }elseif ($upload_responce && $thisTable == 'portal_attachment'){
            C::t($thisTable)->update($value['attachid'],array('remote'=>'1'));
        }elseif ($upload_responce && $thisTable == 'portal_topic_pic'){
            C::t($thisTable)->update($value['picid'],array('remote'=>'1'));
        }elseif ($upload_responce && $thisTable == 'home_pic'){
            C::t($thisTable)->update($value['picid'],array('remote'=> ($value['remote']+ 1)));
        }elseif ($upload_responce && $thisTable == 'portal_article_title'){
             C::t($thisTable)->update($value['aid'],array('remote'=>'1'));

            if ($_G['setting']['ftp']['attachurl'] && $_G['setting']['attachurl']) {
                $remoteFilePath = '"'.$_G['setting']['ftp']['attachurl'].$value['attachment'].'"';

                $localFilePath = '"'.$_G['setting']['attachurl'].$value['attachment'].'"';
                // 对文章进行替换
                $sql = 'UPDATE '.DB::table('portal_article_content').' SET content = REPLACE(content, \''.$localFilePath.'\', \''.$remoteFilePath.'\')';
                DB::query($sql);
            }

            
        }
    }

    if ($thisPage < $pages) {
        ++$thisPage;
        cpmsg(lang('plugin/zhanmishu_storage','next_page',array('thisTable'=>$thisTable,'thisPage'=>$thisPage,'thisTotal'=>$thisTotal,'table_keys'=>$table_keys)),'action=plugins&'.$url.'&formhash='.$_GET['formhash'].'&table_keys='.$table_keys.'&sync=yes&thisPage='.$thisPage.'&thisTotal='.$thisTotal.'&thisTable='.$thisTable);
    }else{
        $thisPage = 1;
        $thiskey = array_search($thisTable,$tables);
        $thisTable = $tables[$thiskey + 1];
        $thisTotal = 0;

        if (!$thisTable) {
            cpmsg(lang('plugin/zhanmishu_storage','finish_oss_sync'),'action=plugins&'.$url);
        }

        cpmsg(lang('plugin/zhanmishu_storage','next_page',array('thisTable'=>$thisTable,'thisPage'=>$thisPage,'thisTotal'=>$thisTotal,'table_keys'=>$table_keys)),'action=plugins&'.$url.'&formhash='.$_GET['formhash'].'&table_keys='.$table_keys.'&sync=yes&thisPage='.$thisPage.'&thisTable='.$thisTable);
    }

}


showformheader($url.'&act=sync','enctype="multipart/form-data"');
showtableheader(); /*dism·taobao·com*/

showsetting(lang('plugin/zhanmishu_storage', 'tables'), array('tables[]',$tables), '', 'mselect','','',lang('plugin/zhanmishu_storage', 'table_desc'),'size="10"');

showsubmit('sync_oss_submit',lang('plugin/zhanmishu_storage','sync_oss_submit'));
showtablefooter(); /*dism·taobao·com*/
showformfooter(); /*dis'.'m.tao'.'bao.com*/
?>