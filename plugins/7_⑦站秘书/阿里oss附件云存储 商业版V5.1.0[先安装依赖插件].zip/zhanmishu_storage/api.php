<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: api.php 33591 2013-07-12 06:39:49Z andyzheng $
 */

// header("Access-Control-Allow-Origin: *");

define('IN_MOBILE_API', 1);
define('IN_MOBILE', 1);
define('IN_QIWEI_API', true);
define('DISABLEXSSCHECK', true);

$_GET['version'] = isset($_GET['version']) ? $_GET['version'] : (isset($_POST['version']) ? $_POST['version'] : '1');
$_GET['mod'] = isset($_GET['mod']) ?  $_GET['mod'] : (isset($_POST['mod']) ? $_POST['mod'] : 'upyun');



$dir = '../../../';
chdir($dir);

if (in_array($_GET['mod'],array(''))) {
    
    $apifile = './source/plugin/zhanmishu_storage/api/'.$_GET['version'].'/'.$_GET['mod'].'.php';
    if(file_exists($apifile)) {
        require_once $apifile;
    } else {
        if($_GET['version'] > 1) {
            for($i = $_GET['version']; $i >= 1; $i--) {
                $apifile = './source/plugin/zhanmishu_storage/api/'.$i.'/'.$_GET['mod'].'.php';
                if(file_exists($apifile)) {
                    $_GET['version'] = $i;
                    require_once $apifile;
                    break;
                } elseif($i==1 && !file_exists($apifile)) {
                    json_encode(array('msg' => 'module_not_exists','code'=>'-9999'));
                }
            }
        } else {
            json_encode(array('msg' => 'module_not_exists','code'=>'-9999'));
        }
    }

}else{
    $_GET['id'] = 'zhanmishu_storage:api';
    include 'plugin.php';
}
