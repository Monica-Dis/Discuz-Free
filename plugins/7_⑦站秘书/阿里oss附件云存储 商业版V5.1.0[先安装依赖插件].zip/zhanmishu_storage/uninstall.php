<?php
/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Ӧ�ø���֧�֣�https://dism.taobao.com
 *    ���²����http://t.cn/Aiux1Jx1
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zhanmishu_storage_log;
EOF;
runquery($sql);


@unlink(DISCUZ_ROOT."/data/alyun.log");
@unlink(DISCUZ_ROOT."/data/upyun.log");

$finish = true;

?>