<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: misc_swfupload.php 35377 2015-07-07 05:20:23Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!function_exists('zms_storage_getconfig')) {
    include DISCUZ_ROOT.'./source/plugin/zhanmishu_storage/source/function/common_function.php';
}
include_once DISCUZ_ROOT.'source/plugin/zhanmishu_storage/source/Autoloader.php';
loadcache('plugin');
$oss_config = $_G['cache']['plugin']['zhanmishu_storage'];

if ($oss_config['intranet_host'] && $oss_config['use_intranet'] && $oss_config['intranet_host']) {
	$oss_config['host'] = $oss_config['intranet_host'];
	$oss_config['cdn_url'] = $oss_config['intranet_host'];
}

if ($oss_config['apiselect'] == '1') {
	$OssClient  = new OssClient($oss_config['OSSAccessKeyId'],$oss_config['AccessKeySecret'],substr($oss_config['host'], strpos($oss_config['host'],'.')+1));
}

$_G['uid'] = intval($_POST['uid']);

if((empty($_G['uid']) && $_GET['operation'] != 'upload') || $_POST['hash'] != md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])) {
	exit();
} else {
	if($_G['uid']) {
		$_G['member'] = getuserbyuid($_G['uid']);
	}
	$_G['groupid'] = $_G['member']['groupid'];
	loadcache('usergroup_'.$_G['member']['groupid']);
	$_G['group'] = $_G['cache']['usergroup_'.$_G['member']['groupid']];
}

$_GET['current'] = $_GET['current'] ? $_GET['current'] : 'forum';

if($_GET['operation'] == 'upload' && $_GET['current'] == 'forum') {

	$forumattachextensions = '';
	$fid = intval($_GET['fid']);
	if($fid) {
		$forum = $fid != $_G['fid'] ? C::t('forum_forum')->fetch_info_by_fid($fid) : $_G['forum'];
		if($forum['status'] == 3 && $forum['level']) {
			$levelinfo = C::t('forum_grouplevel')->fetch($forum['level']);
			if($postpolicy = $levelinfo['postpolicy']) {
				$postpolicy = dunserialize($postpolicy);
				$forumattachextensions = $postpolicy['attachextensions'];
			}
		} else {
			$forumattachextensions = $forum['attachextensions'];
		}
		if($forumattachextensions) {
			$_G['group']['attachextensions'] = $forumattachextensions;
		}
	}



	if ($_GET['type'] == 'image' && $oss_config['apiselect'] == '1') {

		if (!$_G['setting']['ftp']['attachdir'] || $_G['setting']['ftp']['attachdir'] == '.') {
		    $filehost = $oss_config['cdn_url'];
		}else{
		    $filehost = str_replace($_G['setting']['ftp']['attachdir'].'/','',$oss_config['cdn_url'].'/');
		}

		$rs = $OssClient->putObjectAcl($oss_config['bucketname'], $_GET['key'], 'public-read');

		$url = $filehost.'/'.$_GET['key'].'?x-oss-process=image/info';

		//get image info
		$imageInfo =zhanmishu_storage::Curl($url,true);

		$imageWidth = $imageInfo['ImageWidth']['value'];

		
	}else if ($_GET['type'] == 'image' && $oss_config['apiselect'] == '2') {
		$imageWidth = $_GET['image-width'] > 0 ? $_GET['image-width'] : 300;
	}

	$aid = getattachnewaid($_G['uid']);

	if ($_G['setting']['ftp']['attachdir'] == '.' || !$_G['setting']['ftp']['attachdir']) {
		$path_replace = 'forum/';
	}else{
		$path_replace = $_G['setting']['ftp']['attachdir'].'/'.'forum/';
	}



	$insert = array(
		'aid' => $aid,
		'dateline' => $_G['timestamp'],
		'filename' => dhtmlspecialchars(censor(diconv($_GET['filename'],'UTF-8',CHARSET))),
		'filesize' => intval($_GET['filesize']),
		'attachment' => str_replace($path_replace, '', $_GET['key']),
		'isimage' => $_GET['type'] == 'image' ?  '1' : '0',
		'uid' => $_G['uid'],
		'thumb' => '0',
		'remote' => '1',
		'width' => $imageWidth ? $imageWidth + 0 : 300,
	);

	C::t('forum_attachment_unused')->insert($insert);

	if($_GET['isimage'] && $_G['setting']['showexif']) {
		C::t('forum_attachment_exif')->insert($aid, daddcslashes($_GET['filetype']));
	}

	echo $aid;
			
	exit;


}else if($_GET['operation'] == 'upload' && $_GET['current'] == 'home') {

	if ($_GET['type'] == 'image' && $oss_config['apiselect'] == '1') {
		if (!$_G['setting']['ftp']['attachdir'] || $_G['setting']['ftp']['attachdir'] == '.') {
		    $filehost = $oss_config['cdn_url'];
		}else{
		    $filehost = str_replace($_G['setting']['ftp']['attachdir'].'/','',$oss_config['cdn_url'].'/');
		}
		$OssClient->putObjectAcl($oss_config['bucketname'], $_GET['key'], 'public-read');
		
		$url =  $filehost.'/'.$_GET['key'].'?x-oss-process=image/info';
		//get image info
		$imageInfo =zhanmishu_storage::Curl($url,true);
		$imageWidth = $imageInfo['ImageWidth']['value'];
		
	}
	
	$aid = getattachnewaid($_G['uid']);

	$insert = array(
		'aid' => $aid,
		'dateline' => $_G['timestamp'],
		'filename' => dhtmlspecialchars(censor(diconv($_GET['filename'],'UTF-8',CHARSET))),
		'filesize' => intval($_GET['filesize']),
		'attachment' => str_replace('home/', '', $_GET['key']),
		'isimage' => $_GET['type'] == 'image' ?  '1' : '0',
		'uid' => $_G['uid'],
		'thumb' => '0',
		'remote' => '1',
		'width' => $imageWidth ? $imageWidth + 0 : 300,
	);

	C::t('forum_attachment_unused')->insert($insert);
	if($_GET['isimage'] && $_G['setting']['showexif']) {
		C::t('forum_attachment_exif')->insert($aid, daddcslashes($_GET['filetype']));
	}

	echo $aid;
			
	exit;


}elseif($_GET['current'] == 'album') {
	$showerror = true;
	if(helper_access::check_module('album')) {
		require_once libfile('function/spacecp');
		require_once libfile('function/home');
		$file_info = $_GET;
		$file_info['Filename'] = addslashes(diconv(urldecode($file_info['Filename']), 'UTF-8'));
		$file = zms_storage_pic_save($file_info, 0, '', true, 0);
		$OssClient->putObjectAcl($oss_config['bucketname'], $_GET['key'], 'public-read');

		if(!empty($file) && is_array($file)) {
			$url = pic_get($file['filepath'], 'album', $file['thumb'], $file['remote'],0);
			$bigimg = pic_get($file['filepath'], 'album', 0, $file['remote']);
			echo "{\"picid\":\"$file[picid]\", \"url\":\"$url\", \"bigimg\":\"$bigimg\"}";
			$showerror = false;
		}
	}
	if($showerror) {
		echo "{\"picid\":\"0\", \"url\":\"0\", \"bigimg\":\"0\"}";
	}


}

?>