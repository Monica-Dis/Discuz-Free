<?php
/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      应用更新支持：https://dism.taobao.com
 *      最新插件：http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/zhanmishu_storage/source/Autoloader.php';
if (!function_exists('zms_storage_getconfig')) {
    include DISCUZ_ROOT.'./source/plugin/zhanmishu_storage/source/function/common_function.php';
}
$zms_storage = zhanmishu_storage::getInstance();

$oss_config = $zms_storage->config;
// $oss_config['OSSAccessKeyId'] ='piFRdJVTShugHat8';
// $oss_config['AccessKeySecret'] ='zlCrKEvHFVDQN09zSo3qAqPbZpdH66';
// $oss_config['host'] ='http://zhanmishu.oss-cn-shenzhen.aliyuncs.com';

$current = $_GET['current'] ? daddslashes($_GET['current']) : 'forum';
$expiretime = TIMESTAMP + 360;

if (!$_G['setting']['ftp']['attachdir'] || $_G['setting']['ftp']['attachdir'] == '.') {
    $filepath = $current.'/'.$zms_storage->get_target_dir($current,0);
}else{
    $filepath = $_G['setting']['ftp']['attachdir'].'/'.$current.'/'.$zms_storage->get_target_dir($current,0);
}

if ($oss_config['apiselect'] == '1') {
    $policy_data = array();

    $policy_data['expiration'] = gmt_iso8601($expiretime);
    $policy_data['conditions'][] = array(0=>'content-length-range', 1=>0, 2=>1048576000 * 5);
    // $policy_data['conditions'][] = array(0=>'Content-Disposition',1=>'attachment;filename='.$_GET['filename']);
    // $policy_data['conditions'][] = array(0=>'starts-with', 1=>'$key', 2=>$filepath);


    $data = array();
    $data['OSSAccessKeyId'] = $oss_config['OSSAccessKeyId'];
    $data['policy'] = base64_encode(json_encode($policy_data));
    $data['expire'] = $expiretime;
    $data['filepath'] = $filepath;
    $data['target_filename'] = $zms_storage->get_target_filename($current,0,'');
    $data['host'] = $oss_config['host'];
    $data['key'] =$data['filepath'].$data['target_filename'].'.'.daddslashes($_GET['ext']);

    $data['signature'] = base64_encode(hash_hmac('sha1', $data['policy'], $oss_config['AccessKeySecret'] , true));//生成认证签名

    $data['apiselect'] = $oss_config['apiselect'];
    echo json_encode($data);
}else if ($oss_config['apiselect'] == '2') {


    $data = array();
    $data['filepath'] = $filepath;
    $data['target_filename'] = $zms_storage->get_target_filename($current,0,'');
    $data['filepath'] = $filepath;
    $data['bucket'] = $oss_config['upyun_bucket'];
    $data['target_filename'] = $zms_storage->get_target_filename($current,0,'');
    $data['host'] = $oss_config['host'];
    $data['save-key'] ='/'.$data['filepath'].$data['target_filename'].'.'.daddslashes($_GET['ext']);
    $data['key'] = substr($data['save-key'],1);
    $data['size'] = $_GET['size'];

    $policyArr = array();
    $policyArr['bucket'] = $oss_config['upyun_bucket'];
    $policyArr['expiration'] = TIMESTAMP + 720;
    $policyArr['save-key'] = $data['save-key'];
    // $policyArr['id'] = 'WU_FILE_0';
    // $policyArr['name'] = $_GET['filename'];
    // $policyArr['type'] = 'image/jpeg';
    // $policyArr['lastModifiedDate'] = 'Tue Sep 27 2016 19:06:07 GMT+0800 (CST)';
    $policyArr['content-length'] = $_GET['size'];

   
    $data['policy'] = $zms_storage->base64Json($policyArr);
    $data['authorization'] = $zms_storage->getBodySignature($oss_config['upyun_operator'], md5($oss_config['upyun_accesskey']), 'POST', '/'.$oss_config['upyun_bucket'], null, $data['policy'], null);


    $data['apiselect'] = $oss_config['apiselect'];

    echo json_encode($data);   


}
