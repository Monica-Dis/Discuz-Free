<?php
/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      应用更新支持：https://dism.taobao.com
 *      最新插件：http://t.cn/Aiux1Jx1
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/zhanmishu_storage/source/Autoloader.php';

$storageConfig = zhanmishu_storage::getInstance()->config;


$log_ = new log_();
$log_name=DISCUZ_ROOT."/data/alyun.log";//log文件路径
$_GET = daddslashes($_GET);
$log_->log_result($log_name,"[GET]:\n".var_export($_GET,true)."\n");


$clientIP = $_GET['remote_addr'];
if(!$clientIP) {
	http_response_code(403);
	exit($clientIP);
}

$user = DB::fetch_first('select * from %t where lastip = %s' , array('common_member_status', $clientIP));

if (!empty($user)) {
	http_response_code(200);
	exit($clientIP);
}

http_response_code(403);
exit($clientIP);
