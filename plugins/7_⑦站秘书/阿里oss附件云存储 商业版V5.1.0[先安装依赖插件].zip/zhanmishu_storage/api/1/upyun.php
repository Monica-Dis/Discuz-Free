<?php
/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      应用更新支持：https://dism.taobao.com
 *      最新插件：http://t.cn/Aiux1Jx1
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/zhanmishu_storage/source/Autoloader.php';

$storageConfig = zhanmishu_storage::getInstance()->config;


$log_ = new log_();
$log_name=DISCUZ_ROOT."/data/upyun.log";//log文件路径
$_GET = daddslashes($_GET);
$log_->log_result($log_name,"[GET]:\n".var_export($_GET,true)."\n");

$log = C::t("#zhanmishu_storage#zhanmishu_storage_log")->fetch($_GET['upyunId'] + 0);
$log_->log_result($log_name,"[GET]:\n".var_export($log,true)."\n");

if(in_array(fileext($log['data']), $storageConfig['upyun_white_ext'])) {
    $log_->log_result($log_name,"[log]:upyun_white_ext\n");
    echo 1;
    exit;
}
if(!$_GET['upyunId']) {
    http_response_code(401);
    $log_->log_result('upyunId error', "[error]:\n");
    exit('upyunId');
}

if($storageConfig['upyun_download_number'] > 0 && $log['status'] >= $storageConfig['upyun_download_number']) {
    http_response_code(401);
    $log_->log_result('upyun_download_number', "[upyun_download_number]:\n");
    exit('upyun_download_number');
}

if(empty($log)) {
    http_response_code(401);
    $log_->log_result('empty error', "[error]:\n");
    exit('empty');
}

$log_->log_result($log_name,"[GET]:\n".var_export($log,true)."\n");
// 验证key
$signData = array(
    'upyunUid' => $_GET['upyunUid'],
    'upyunOp' => $_GET['upyunOp'],
    'upyunHash' => $_GET['upyunHash'],
    'upyunTime' => intval($_GET['upyunTime']),
    'upyunId' => intval($_GET['upyunId'])
);

if($_GET['userIp'] && $_GET['userIp'] != $_GET['upyunOp']) {
    http_response_code(401);
    exit();
}


$key = $storageConfig['upyun_accesskey'];
$log_->log_result($log_name, json_encode($signData).$key."\n");
$key = md5(json_encode($signData).$key);
$log_->log_result($log_name, $key."\n");

if($key != $_GET['upyunKey']) {
    http_response_code(401);
    $log_->log_result($log_name,"error\n");
    exit();
}

$rs = C::t("#zhanmishu_storag e#zhanmishu_storage_log")->update($log['id'], array('status' => intval($log['status']) + 1));

$log_->log_result($log_name, $rs.'--'.$log['id']."success\n");

echo 1;