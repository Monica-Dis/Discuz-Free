<?php
/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Ӧ�ø���֧�֣�https://dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
  exit('Access Denied');
}

 $sql = <<<EOF
CREATE TABLE IF NOT EXISTS pre_zhanmishu_storage_log(
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `data` varchar(1000) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (id),
  KEY 
  dateline (dateline)
);
EOF;
runquery($sql);

$finish = TRUE;


?>