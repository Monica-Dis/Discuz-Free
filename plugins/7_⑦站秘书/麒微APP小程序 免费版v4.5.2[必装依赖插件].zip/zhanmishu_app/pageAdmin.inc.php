<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';
$appHander = zhanmishu_app::getInstance();

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin';
$imageNo = 'source/plugin/zhanmishu_app/template/images/noimg.jpg';

$placeholderNo = lang('plugin/zhanmishu_app','image_placeholder');
$urlTypeNo = '<br>'.lang('plugin/zhanmishu_app','urlType').'<select name="urlType[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'URL').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'appPage').'</option></select>';
$urlTypeNo .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'public').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'H5').'</option><option value ="2">'.lang('plugin/zhanmishu_app', 'minapp').'</option><option value ="3">'.lang('plugin/zhanmishu_app', 'app').'</option></select>';

$_GET['method'] = $_GET['method'] ? $_GET['method'] : 'index';
$pageAdminItem = array(
    'normal'=>array(
        'menu'=> array(
            array(
                'title'=>lang('plugin/zhanmishu_app','index'),
                'link'=>$mpurl.'&method=index',
                'selected'=> $_GET['method'] == 'index' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_app','myCenter'),
                'link'=>ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_app&pmod=uCenterAdmin'.'&method=mySetting',
                'selected'=> $_GET['method'] == 'mySetting' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_app','aboutUs'),
                'link'=>$mpurl.'&method=aboutUs',
                'selected'=> $_GET['method'] == 'aboutUs' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_app','tabBar'),
                'link'=>$mpurl.'&method=tabBar',
                'selected'=> $_GET['method'] == 'tabBar' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_app','tabBarNav'),
                'link'=>$mpurl.'&method=tabBarNav',
                'selected'=> $_GET['method'] == 'tabBarNav' ? 'selected' : ''
            )
        ),
    )
);
zhanmishu_app_admin::importPureCss();
zhanmishu_app_admin::importJquery();
zhanmishu_app_admin::menuHorizontal($pageAdminItem['normal']['title'],$pageAdminItem['normal']['menu']);
if ($_GET['method'] == 'index') {
    if (submitcheck('indexItems')) {
        $images = zhanmishu_app::uploadimg();
        $items = array();
        foreach ($_GET['item_name'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $items[] = array(
                'order'=>$_GET['order'][$key],
                'item_name'=>$_GET['item_name'][$key],
                'item_id'=>$_GET['item_id'][$key],
            );
        }

        $appHander->writeToCache('pageitem',$items);
        cpmsg(lang('plugin/zhanmishu_app', 'update_items_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin','success');

    }else{
            $items = $appHander->GetFromCache('pageitem');
            showformheader($formurl.'&method=index','enctype="multipart/form-data"');

            showtableheader(lang('plugin/zhanmishu_app','index_item_intro'));
            showsubtitle(array(
                lang('plugin/zhanmishu_app', 'delete'),
                lang('plugin/zhanmishu_app', 'order'),
                lang('plugin/zhanmishu_app', 'items_name'),
                lang('plugin/zhanmishu_app', 'item_id'),
                lang('plugin/zhanmishu_app', 'act')
            ));

            foreach ($items as $key => $value) {
                $value['id'] = $key;

                $itemselect = array(
                    $value['item_id'] == '0' ? ' selected' : '',
                    $value['item_id'] == '1' ? ' selected' : '',
                    $value['item_id'] == '2' ? ' selected' : '',
                    $value['item_id'] == '3' ? ' selected' : '',
                    $value['item_id'] == '4' ? ' selected' : '',
                    $value['item_id'] == '5' ? ' selected' : '',
                    $value['item_id'] == '6' ? ' selected' : '',
                );

                $image = $value['item_icon'] ? $value['item_icon'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
                $item = 
                '<select name="item_id[]">'.
                    '<option value ="0" '.$itemselect[0].'>'.lang('plugin/zhanmishu_app', 'item_search').'</option>'.
                    '<option value ="1" '.$itemselect[1].'>'.lang('plugin/zhanmishu_app', 'item_swiper').'</option>'.
                    '<option value ="2" '.$itemselect[2].'>'.lang('plugin/zhanmishu_app', 'item_nav').'</option>'.
                    '<option value ="3" '.$itemselect[3].'>'.lang('plugin/zhanmishu_app', 'item_notice').'</option>'.
                '</select>';

                if ($value['item_id'] == '1') {
                    $dataAdminUrl = '<a href="'.$mpurl.'&method=swiperAdmin&item_id='.$value['item_id'].'">'.lang('plugin/zhanmishu_app','dataAdmin').'</a>';
                }else if ($value['item_id'] == '2') {
                    $dataAdminUrl = '<a href="'.$mpurl.'&method=navAdmin&item_id='.$value['item_id'].'">'.lang('plugin/zhanmishu_app','dataAdmin').'</a>';
                }else{
                    $dataAdminUrl = '_';
                }

                    $appHanderarr = array(
                    '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                    '<input type="text" required class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                    '<input type="text" required class="txt" name="item_name['.$value['id'].']" value="'.$value['item_name'].'" />',
                    $item,
                    '<a href="'.$mpurl.'&method=styleAdmin&item_id='.$value['item_id'].'">'.lang('plugin/zhanmishu_app','styleAdmin').'</a>&nbsp;&nbsp;&nbsp;'.
                    $dataAdminUrl
                );
                showtablerow('',array('class="td25"', 'class="td25"', 'class="td22"', 'class="td22"', 'class="td22"', 'class="td22"'), $appHanderarr);

            }
            echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'additems').'</a></div></tr>';

            showsubmit('indexItems',lang('plugin/zhanmishu_app', 'submit'));

            showtablefooter(); /*dis'.'m.tao'.'bao.com*/
            showformfooter(); /*dism·taobao·com*/
            $itemNo = 
            '<select name="item_id[]">'.
                '<option value ="0" '.$itemselect[0].'>'.lang('plugin/zhanmishu_app', 'item_search').'</option>'.
                '<option value ="1" '.$itemselect[1].'>'.lang('plugin/zhanmishu_app', 'item_swiper').'</option>'.
                '<option value ="2" '.$itemselect[2].'>'.lang('plugin/zhanmishu_app', 'item_nav').'</option>'.
                '<option value ="3" '.$itemselect[3].'>'.lang('plugin/zhanmishu_app', 'item_notice').'</option>'.
            '</select>'; 
        echo <<<EOT
        <script type="text/JavaScript">
            var rowtypedata = [
                [
                    [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="order[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="item_name[]" value="">', 'td22'],
                    [1,'{$itemNo}', 'td22'],
                    [1,'', 'td22'],

                ]
                
            ];
        </script>
EOT;

    }
}else if ($_GET['method'] == 'styleAdmin') {
    if (submitcheck('styleAdmin')) {
        
        $items = $appHander->GetFromCache('IndexStyle');
        foreach ($_GET['margin'] as $key => $value) {
            $items[$_GET['item_id']]['margin'] = array(
                'field'=>'margin',
                'value'=> $_GET['margin'],
                'name'=>lang('plugin/zhanmishu_app','margin')
            );
            $items[$_GET['item_id']]['padding'] = array(
                'field'=>'padding',
                'value'=> $_GET['padding'],
                'name'=>lang('plugin/zhanmishu_app','padding')
            );
            $items[$_GET['item_id']]['border'] = array(
                'field'=>'border',
                'value'=> $_GET['border'],
                'name'=>lang('plugin/zhanmishu_app','border')
            );
        }
        $appHander->writeToCache('IndexStyle',$items);
        cpmsg(lang('plugin/zhanmishu_app', 'update_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin','success');

    }else{
        $items = $appHander->GetFromCache('IndexStyle');

        showtableheader(lang('plugin/zhanmishu_app','styleAdminIntro'));
        showformheader($formurl.'&method=styleAdmin&item_id='.$_GET['item_id'],'enctype="multipart/form-data"');
        if ($items[$_GET['item_id']]) {
            $styleFields = $items[$_GET['item_id']];
        }else{
            $styleFields = array(
                'margin' => array(
                    'field'=>'margin',
                    'value'=>array(0,0,0,0),
                    'name'=>lang('plugin/zhanmishu_app','margin')
                ),
                'padding' => array(
                    'field'=>'padding',
                    'value'=>array(0,0,0,0),
                    'name'=>lang('plugin/zhanmishu_app','padding')
                ),
                'border' => array(
                    'field'=>'border', 
                    'value'=>array(0,0,0,0),
                    'name'=>lang('plugin/zhanmishu_app','border')
                )
            );
        }
        
        foreach ($styleFields as $key => $value) {
            $appHanderarr = array(
            $value['name'].'：',
            lang('plugin/zhanmishu_app','top').'：<input type="text" required class="txt" name="'.$value['field'].'[0]" value="'.$value['value'][0].'" />',
            lang('plugin/zhanmishu_app','right').'：<input type="text" required class="txt" name="'.$value['field'].'[1]" value="'.$value['value'][1].'" />',
            lang('plugin/zhanmishu_app','bottom').'：<input type="text" required class="txt" name="'.$value['field'].'[2]" value="'.$value['value'][2].'" />',
            lang('plugin/zhanmishu_app','left').'：<input type="text" required class="txt" name="'.$value['field'].'[3]" value="'.$value['value'][3].'" />',
            );
            showtablerow('',array('class="td25"', 'class="td25"', 'class="td25"', 'class="td25"', 'class="td25"', 'class="td25"'), $appHanderarr);
        }


        showsubmit('styleAdmin',lang('plugin/zhanmishu_app', 'submit'));

        showtablefooter(); /*dis'.'m.tao'.'bao.com*/
        showformfooter(); /*dism·taobao·com*/
    }

}else if ($_GET['method'] == 'dataAdmin') {

}else if ($_GET['method'] == 'navAdmin') {
    if (submitcheck('indexNav')) {
        $images = zhanmishu_app::uploadimg();
        $items = array();
        foreach ($_GET['nav_name'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $items[] = array(
                'order'=>$_GET['order'][$key],
                'nav_name'=>$_GET['nav_name'][$key],
                'nav_icon'=>$images[$key] ? $images[$key] : $_GET['nav_icon'][$key],
                'nav_id'=>$_GET['nav_id'][$key],
                'url'=>$_GET['url'][$key],
                'urlType'=>$_GET['urlType'][$key],
                'platform'=>$_GET['platform'][$key],
            );
        }

        $appHander->writeToCache('indexNav',$items);
        cpmsg(lang('plugin/zhanmishu_app', 'update_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin&method=navAdmin','success');

    }else{
            $items = $appHander->GetFromCache('indexNav');
            showformheader($formurl.'&method=navAdmin','enctype="multipart/form-data"');
            showtableheader(lang('plugin/zhanmishu_app','nav_list'));
            showsubtitle(array(
                lang('plugin/zhanmishu_app', 'delete'),
                lang('plugin/zhanmishu_app', 'order'),
                lang('plugin/zhanmishu_app', 'nav_list_name'),
                lang('plugin/zhanmishu_app', 'imgurl'),
                lang('plugin/zhanmishu_app', 'url')
            ));


            foreach ($items as $key => $value) {
                $value['id'] = $key;
                $linkTypeSelect = array(
                    $value['urlType'] == '0' ? ' selected' : '',
                    $value['urlType'] == '1' ? ' selected' : '',
                );
                // 选中状态
                $recommendType = array(
                    $value['platform'] == '0' ? ' selected' : '',
                    $value['platform'] == '1' ? ' selected' : '',
                    $value['platform'] == '2' ? ' selected' : '',
                    $value['platform'] == '3' ? ' selected' : '',
                );

                $image = $value['nav_icon'] ? $value['nav_icon'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
                $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
                <select name="urlType[]">
                    <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                    <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
                </select>';
                $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]">
                        <option value ="0" '.$recommendType[0].'>'.lang('plugin/zhanmishu_app', 'public').'</option>
                        <option value ="1" '.$recommendType[1].'>'.lang('plugin/zhanmishu_app', 'H5').'</option>
                        <option value ="2" '.$recommendType[2].'>'.lang('plugin/zhanmishu_app', 'minapp').'</option>
                        <option value ="3" '.$recommendType[3].'>'.lang('plugin/zhanmishu_app', 'app').'</option>
                    </select>';


                    $appHanderarr = array(
                    '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                    '<input type="text" required class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                    '<input type="text" required class="txt" name="nav_name['.$value['id'].']" value="'.$value['nav_name'].'" />',
                    '<img src="'.$image.'" width="40px" height="40px"><input type="text"  class="txt" style="width:100px;" name="nav_icon['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['nav_icon'].'" />
                    <input style="width:140px" type="file"  name="image_file['.$value['id'].']" value="" />',
                    '<input type="text" required  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType
                );
                showtablerow('',array('class="td25"', 'class="td25"', 'class="td22"', 'class="td22"', 'class="td22"', 'class="td22"'), $appHanderarr);

            }
            echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'addnav_list').'</a></div></tr>';

            showsubmit('indexNav',lang('plugin/zhanmishu_app', 'submit'));

            showtablefooter(); /*dis'.'m.tao'.'bao.com*/
            showformfooter(); /*dism·taobao·com*/   
        echo <<<EOT
        <script type="text/JavaScript">
            var rowtypedata = [
                [
                    [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="order[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="nav_name[]" value="">', 'td22'],
                    [1,'<img src="{$imageNo}" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" name="nav_icon[]" placeholder="{$placeholderNo}" value="" /><input style="width:140px" type="file"  name="image_file[]" value="" />', 'td22'],
                    [1,'<input type="text" required class="" name="url[]" value="">{$urlTypeNo}', 'td22']

                ]
                
            ];
        </script>
EOT;

    }
}else if ($_GET['method'] == 'swiperAdmin') {
    if (submitcheck('swiperAdmin')) {
        $images = zhanmishu_app::uploadimg();
        $items = array();
        foreach ($_GET['swiper_name'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $items[] = array(
                'order'=>$_GET['order'][$key],
                'swiper_name'=>$_GET['swiper_name'][$key],
                'swiper_icon'=>$images[$key] ? $images[$key] : $_GET['swiper_icon'][$key],
                'swiper_id'=>$_GET['swiper_id'][$key],
                'url'=>$_GET['url'][$key],
                'urlType'=>$_GET['urlType'][$key],
                'platform'=>$_GET['platform'][$key],
            );
        }

        $appHander->writeToCache('indexSwiper',$items);
        cpmsg(lang('plugin/zhanmishu_app', 'update_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin&method=swiperAdmin','success');

    }else{
            $items = $appHander->GetFromCache('indexSwiper');
            showformheader($formurl.'&method=swiperAdmin','enctype="multipart/form-data"');
            showtableheader(lang('plugin/zhanmishu_app','swiper_list'));
            showsubtitle(array(
                lang('plugin/zhanmishu_app', 'delete'),
                lang('plugin/zhanmishu_app', 'order'),
                lang('plugin/zhanmishu_app', 'swiper_name'),
                lang('plugin/zhanmishu_app', 'imgurl'),
                lang('plugin/zhanmishu_app', 'url')
            ));


            foreach ($items as $key => $value) {
                $value['id'] = $key;
                $linkTypeSelect = array(
                    $value['urlType'] == '0' ? ' selected' : '',
                    $value['urlType'] == '1' ? ' selected' : '',
                );
                // 选中状态
                $recommendType = array(
                    $value['platform'] == '0' ? ' selected' : '',
                    $value['platform'] == '1' ? ' selected' : '',
                    $value['platform'] == '2' ? ' selected' : '',
                    $value['platform'] == '3' ? ' selected' : '',
                );

                $image = $value['swiper_icon'] ? $value['swiper_icon'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
                $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
                <select name="urlType[]">
                    <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                    <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
                </select>';
                $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]">
                        <option value ="0" '.$recommendType[0].'>'.lang('plugin/zhanmishu_app', 'public').'</option>
                        <option value ="1" '.$recommendType[1].'>'.lang('plugin/zhanmishu_app', 'H5').'</option>
                        <option value ="2" '.$recommendType[2].'>'.lang('plugin/zhanmishu_app', 'minapp').'</option>
                        <option value ="3" '.$recommendType[3].'>'.lang('plugin/zhanmishu_app', 'app').'</option>
                    </select>';


                    $appHanderarr = array(
                    '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                    '<input type="text" required class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                    '<input type="text" required class="txt" name="swiper_name['.$value['id'].']" value="'.$value['swiper_name'].'" />',
                    '<img src="'.$image.'" width="40px" height="40px"><input type="text"  class="txt" style="width:100px;" name="swiper_icon['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['swiper_icon'].'" />
                    <input style="width:140px" type="file"  name="image_file['.$value['id'].']" value="" />',
                    '<input type="text" required  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType
                );
                showtablerow('',array('class="td25"', 'class="td25"', 'class="td22"', 'class="td22"', 'class="td22"', 'class="td22"'), $appHanderarr);

            }
            echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'addswiper').'</a></div></tr>';

            showsubmit('swiperAdmin',lang('plugin/zhanmishu_app', 'submit'));

            showtablefooter(); /*dis'.'m.tao'.'bao.com*/
            showformfooter(); /*dism·taobao·com*/   
        echo <<<EOT
        <script type="text/JavaScript">
            var rowtypedata = [
                [
                    [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="order[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="swiper_name[]" value="">', 'td22'],
                    [1,'<img src="{$imageNo}" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" name="swiper_icon[]" placeholder="{$placeholderNo}" value="" /><input style="width:140px" type="file"  name="image_file[]" value="" />', 'td22'],
                    [1,'<input type="text" required class="" name="url[]" value="">{$urlTypeNo}', 'td22']

                ]
                
            ];
        </script>
EOT;

    }
}else if ($_GET['method'] == 'aboutUs') {
    if (submitcheck('aboutUs')) {
        $images = zhanmishu_app::uploadimg();
        $items = array();
        foreach ($_GET['aboutus_name'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $items['list'][] = array(
                'order'=>$_GET['order'][$key],
                'aboutus_name'=>$_GET['aboutus_name'][$key],
                'url'=>$_GET['url'][$key],
                'urlType'=>$_GET['urlType'][$key],
                'platform'=>$_GET['platform'][$key],
            );
        }
        $items['company_name'] = daddslashes($_GET['company_name']);
        $items['company_appname'] = daddslashes($_GET['company_appname']);
        $items['company_logo'] = $images['image_file'] ? daddslashes($images['image_file']) : daddslashes($_GET['company_logo']);

        $appHander->writeToCache('aboutUs',$items);
        cpmsg(lang('plugin/zhanmishu_app', 'update_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin&method=aboutUs','success');

    }else{
            $items = $appHander->GetFromCache('aboutUs');
            showformheader($formurl.'&method=aboutUs','enctype="multipart/form-data" class="txt pure-form pure-form-stacked" ');
            showtableheader(lang('plugin/zhanmishu_app','aboutus_icon_intro'));
            showtablefooter(); /*dis'.'m.tao'.'bao.com*/
            $appHanderarr = array(
                lang('plugin/zhanmishu_app','company_logo').':<br>'.
                '<img src="'.($items['company_logo'] ? $items['company_logo'] : $imageNo).'" width="100px" height="100px"><br><input type="text"  class="txt" style="width:100px;" name="company_logo" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$items['company_logo'].'" /><br><input style="width:140px" type="file"  name="image_file" value="" />'.'<br><br>',
                lang('plugin/zhanmishu_app','company_name').':<br>'.
                '<input type="text" required class="txt pure-input-1-3" name="company_name" value="'.$items['company_name'].'" />'.'<br>',
                lang('plugin/zhanmishu_app','company_appname').':<br>'.
                '<input type="text" required class="txt pure-input-1-3" name="company_appname" value="'.$items['company_appname'].'" />'
            );
            showtablerow('',array('class="td25"'), $appHanderarr);

            showtableheader(lang('plugin/zhanmishu_app','aboutus_list'));
            showsubtitle(array(
                lang('plugin/zhanmishu_app', 'delete'),
                lang('plugin/zhanmishu_app', 'order'),
                lang('plugin/zhanmishu_app', 'aboutus_name'),
                lang('plugin/zhanmishu_app', 'url')
            ));


            foreach ($items['list'] as $key => $value) {
                $value['id'] = $key;
                $linkTypeSelect = array(
                    $value['urlType'] == '0' ? ' selected' : '',
                    $value['urlType'] == '1' ? ' selected' : '',
                );
                // 选中状态
                $recommendType = array(
                    $value['platform'] == '0' ? ' selected' : '',
                    $value['platform'] == '1' ? ' selected' : '',
                    $value['platform'] == '2' ? ' selected' : '',
                    $value['platform'] == '3' ? ' selected' : '',
                );

                $image = $value['aboutus_icon'] ? $value['aboutus_icon'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
                $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
                <select name="urlType[]">
                    <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                    <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
                </select>';
                $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]">
                        <option value ="0" '.$recommendType[0].'>'.lang('plugin/zhanmishu_app', 'public').'</option>
                        <option value ="1" '.$recommendType[1].'>'.lang('plugin/zhanmishu_app', 'H5').'</option>
                        <option value ="2" '.$recommendType[2].'>'.lang('plugin/zhanmishu_app', 'minapp').'</option>
                        <option value ="3" '.$recommendType[3].'>'.lang('plugin/zhanmishu_app', 'app').'</option>
                    </select>';


                    $appHanderarr = array(
                    '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                    '<input type="text" required class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                    '<input type="text" required class="txt" name="aboutus_name['.$value['id'].']" value="'.$value['aboutus_name'].'" />',
                    '<input type="text" required  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType
                );
                showtablerow('',array('class="td25"', 'class="td25"', 'class="td22"', 'class="td22"', 'class="td22"'), $appHanderarr);

            }
            echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'addswiper').'</a></div></tr>';

            showsubmit('aboutUs',lang('plugin/zhanmishu_app', 'submit'));

            showtablefooter(); /*dis'.'m.tao'.'bao.com*/
            showformfooter(); /*dism·taobao·com*/   
        echo <<<EOT
        <script type="text/JavaScript">
            var rowtypedata = [
                [
                    [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="order[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="aboutus_name[]" value="">', 'td22'],
                    [1,'<input type="text" required class="" name="url[]" value="">{$urlTypeNo}', 'td22']

                ]
                
            ];
        </script>
EOT;

    }
}else if ($_GET['method'] == 'tabBar') {

    $iconPath = lang('plugin/zhanmishu_app','iconPath');
    $isBigAt = lang('plugin/zhanmishu_app','isBigAt');
    $isShowTextAt = lang('plugin/zhanmishu_app','isShowTextAt');
    $isJuttingAt = lang('plugin/zhanmishu_app','isJuttingAt');
    $yes = lang('plugin/zhanmishu_app','yes');
    $not = lang('plugin/zhanmishu_app','not');

    $selectedIconPath = lang('plugin/zhanmishu_app','selectedIconPath');
    if (submitcheck('tabBar')) {
        $items = array();

        $items['isMagappHideTabBar'] = $_GET['isMagappHideTabBar'] + 0;
        $items['isH5DiyTabbar'] = $_GET['isH5DiyTabbar'] + 0;
        $items['isWechatDiyTabbar'] = $_GET['isWechatDiyTabbar'] + 0;
        $items['isBaiDuDiyTabbar'] = $_GET['isBaiDuDiyTabbar'] + 0;
        $items['isTouTiaoDiyTabbar'] = $_GET['isTouTiaoDiyTabbar'] + 0;
        $items['isAppTabbar'] = $_GET['isAppTabbar'] + 0;

        // 禁止两个大图标
        if (array_sum($_GET['isBig']) >= 2) {
            cpmsg(lang('plugin/zhanmishu_app', 'bigImageLimitOne'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin&method=tabBar','error');
        }

        foreach ($_GET['text'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $items['list'][] = array(
                'order'=>$_GET['order'][$key],
                'text'=>$_GET['text'][$key],
                'iconPath'=> $_GET['iconPath'][$key],
                'selectedIconPath'=>$_GET['selectedIconPath'][$key],
                'url'=>$_GET['url'][$key],
                'urlType'=>$_GET['urlType'][$key],
                'platform'=>$_GET['platform'][$key],
                'isBig'=>$_GET['isBig'][$key],
                'isShowText'=>$_GET['isShowText'][$key],
                'isJutting'=>$_GET['isJutting'][$key],
            );
        }

        $appHander->writeToCache('tabBar',$items);
        cpmsg(lang('plugin/zhanmishu_app', 'update_success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin&method=tabBar','success');

    }else{
            $items = $appHander->GetFromCache('tabBar');
            showformheader($formurl.'&method=tabBar','enctype="multipart/form-data" ');
            
            showtableheader();
            showsetting(lang('plugin/zhanmishu_app','isMagappHideTabBar'), 'isMagappHideTabBar', $items['isMagappHideTabBar'], 'radio');
            showsetting(lang('plugin/zhanmishu_app','isH5DiyTabbar'), 'isH5DiyTabbar', $items['isH5DiyTabbar'], 'radio');
            showsetting(lang('plugin/zhanmishu_app','isWechatDiyTabbar'), 'isWechatDiyTabbar', $items['isWechatDiyTabbar'], 'radio');
            showsetting(lang('plugin/zhanmishu_app','isBaiDuDiyTabbar'), 'isBaiDuDiyTabbar', $items['isBaiDuDiyTabbar'], 'radio');
            showsetting(lang('plugin/zhanmishu_app','isTouTiaoDiyTabbar'), 'isTouTiaoDiyTabbar', $items['isTouTiaoDiyTabbar'], 'radio');
            showsetting(lang('plugin/zhanmishu_app','isAppTabbar'), 'isAppTabbar', $items['isAppTabbar'], 'radio');
            showtablefooter(); /*dis'.'m.tao'.'bao.com*/

            showtableheader(lang('plugin/zhanmishu_app','barlist'));
            showsubtitle(array(
                lang('plugin/zhanmishu_app', 'delete'),
                lang('plugin/zhanmishu_app', 'order'),
                lang('plugin/zhanmishu_app', 'barlist_name'),
                lang('plugin/zhanmishu_app', 'imgurl'),
                lang('plugin/zhanmishu_app', 'url')
            ));

            //以单选形式输出表单(显示授权信息链接 radio)：

            foreach ($items['list'] as $key => $value) {
                $value['id'] = $key;
                $linkTypeSelect = array(
                    $value['urlType'] == '0' ? ' selected' : '',
                    $value['urlType'] == '1' ? ' selected' : '',
                );
                $isBigCheck = array(
                    $value['isBig'] == '0' ? ' checked' : '',
                    $value['isBig'] == '1' ? ' checked' : '',
                );
                $isShowTextCheck = array(
                    $value['isShowText'] == '0' ? ' checked' : '',
                    $value['isShowText'] == '1' ? ' checked' : '',
                );
                $isJuttingCheck = array(
                    $value['isJutting'] == '0' ? ' checked' : '',
                    $value['isJutting'] == '1' ? ' checked' : '',
                );
                // 选中状态
                $recommendType = array(
                    $value['platform'] == '0' ? ' selected' : '',
                    $value['platform'] == '1' ? ' selected' : '',
                    $value['platform'] == '2' ? ' selected' : '',
                    $value['platform'] == '3' ? ' selected' : '',
                );

                $image = $value['iconPath'] ? $value['iconPath'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
                $imageSelect = $value['selectedIconPath'] ? $value['selectedIconPath'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
                $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
                <select name="urlType[]">
                    <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                    <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
                </select>';
                $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]">
                        <option value ="0" '.$recommendType[0].'>'.lang('plugin/zhanmishu_app', 'public').'</option>
                        <option value ="1" '.$recommendType[1].'>'.lang('plugin/zhanmishu_app', 'H5').'</option>
                        <option value ="2" '.$recommendType[2].'>'.lang('plugin/zhanmishu_app', 'minapp').'</option>
                        <option value ="3" '.$recommendType[3].'>'.lang('plugin/zhanmishu_app', 'app').'</option>
                    </select>';


                    $appHanderarr = array(
                    '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                    '<input type="text" required class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                    '<input type="text" required class="txt" name="text['.$value['id'].']" value="'.$value['text'].'" />',
                    $iconPath.':<br><img src="'.$image.'" width="40px" height="40px"><input type="text"  class="txt" style="width:100px;" name="iconPath['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['iconPath'].'" />
                    <input style="width:140px" type="file" onchange="uploadIcon(this)" name="image_file[iconPath]['.$value['id'].']" value="" /><br>'.$selectedIconPath.':<br>
                    <img src="'.$imageSelect.'" width="40px" height="40px"><input type="text"  class="txt" style="width:100px;" name="selectedIconPath['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['selectedIconPath'].'" />
                    <input style="width:140px" onchange="uploadIcon(this)" type="file"  name="image_file[selectedIconPath]['.$value['id'].']" value="" /><br>
                    '.lang('plugin/zhanmishu_app', 'isBigAt').'
                    '.lang('plugin/zhanmishu_app', 'yes').'<input type="radio" '.$isBigCheck[1].' name="isBig['.$value['id'].']" value="1">
                    '.lang('plugin/zhanmishu_app', 'not').'<input type="radio" '.$isBigCheck[0].'  name="isBig['.$value['id'].']" value="0"><br>
                    '.lang('plugin/zhanmishu_app', 'isShowTextAt').'
                    '.lang('plugin/zhanmishu_app', 'yes').'<input type="radio" '.$isShowTextCheck[1].'  name="isShowText['.$value['id'].']" value="1">
                    '.lang('plugin/zhanmishu_app', 'not').'<input type="radio" '.$isShowTextCheck[0].'  name="isShowText['.$value['id'].']" value="0"><br>
                    '.lang('plugin/zhanmishu_app', 'isJuttingAt').'
                    '.lang('plugin/zhanmishu_app', 'yes').'<input type="radio" '.$isJuttingCheck[1].'  name="isJutting['.$value['id'].']" value="1">
                    '.lang('plugin/zhanmishu_app', 'not').'<input type="radio" '.$isJuttingCheck[0].'  name="isJutting['.$value['id'].']" value="0">
                    ',
                    '<input type="text" required  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType
                );
                showtablerow('',array('class="td25"', 'class="td25"', 'class="td22"', 'class="td22"', 'class="td22"', 'class="td22"'), $appHanderarr);

            }
            echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'addbarlist').'</a></div></tr>';

            showsubmit('tabBar',lang('plugin/zhanmishu_app', 'submit'));

            showtablefooter(); /*dis'.'m.tao'.'bao.com*/
            showformfooter(); /*dism·taobao·com*/   
        echo <<<EOT
        <script type="text/JavaScript">
            ;(function($){
                $('.fastUpload').on('click', function () {
                    uploadIcon($(this));
                });
            })(jQuery);

            var rowtypedata = [
                [
                    [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="order[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="text[]" value="">', 'td22'],
                    [1,'{$iconPath}:<br><img src="{$imageNo}" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" name="iconPath[]" placeholder="{$placeholderNo}" value="" /><input style="width:140px" type="file" class="fastUpload" onchange="uploadIcon(this)" name="iconPath[image_file][]" value="" /><br>{$selectedIconPath}:<br><img src="{$imageNo}" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" name="selectedIconPath[]" placeholder="{$placeholderNo}" value="" /><input style="width:140px" type="file" class="fastUpload" onchange="uploadIcon(this)"  name="selectedIconPath[image_file][]" value="" /><br>{$isBigAt}{$yes}<input type="radio" name="isBig[]" value="1">{$not}<input type="radio" checked name="isBig[]" value="0"><br>{$isShowTextAt}{$yes}<input type="radio" checked name="isShowText[]" value="1">{$not}<input type="radio" name="isShowText[]" value="0"><br>{$isJuttingAt}{$yes}<input type="radio" name="isJutting[]" value="1">{$not}<input type="radio" checked name="isJutting[]" value="0">', 'td22'],
                    [1,'<input type="text" required class="" name="url[]" value="">{$urlTypeNo}', 'td22']

                ]
                
            ];
        </script>
EOT;

    }
}else if ($_GET['method'] == 'tabBarNav') {
    if (submitcheck('tabBarNavSubmit')) {
        $images = zhanmishu_app::uploadimg();

        $tabbarNavList = array();
        foreach ($_GET['title'] as $key => $value) {
            if (!$value || in_array($key, $_GET['delete'])) {
                continue;
            }
            $tabbarNavList[] = array(
                'order'=>$_GET['order'][$key],
                'title'=>$_GET['title'][$key],
                'image'=>$images[$key] ? $images[$key] : $_GET['image'][$key] ,
                'url'=>$_GET['url'][$key],
                'urlType'=>$_GET['urlType'][$key],
                'platform'=>$_GET['platform'][$key],
                'description'=>$_GET['description'][$key]
            );
        }

        $appHander->writeToCache('tabbarNav',$tabbarNavList);
        cpmsg(lang('plugin/zhanmishu_app', 'success'),'action=plugins&operation=config&identifier=zhanmishu_app&pmod=pageAdmin&method=tabBarNav','success');

    }else{
        $tabbarNavList = $appHander->GetFromCache('tabbarNav');
        if (empty($tabbarNavList)) {
            $appHander->importInitUcenter();
        }
        showformheader($formurl.'&method=tabBarNav','enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_app','tabbarNavDesc'));
        showsubtitle(array(
            lang('plugin/zhanmishu_app', 'delete'),
            lang('plugin/zhanmishu_app', 'order'),
            lang('plugin/zhanmishu_app', 'title'),
            lang('plugin/zhanmishu_app', 'icon'),
            lang('plugin/zhanmishu_app', 'url'),
            lang('plugin/zhanmishu_app', 'description')
        ));

        foreach ($tabbarNavList as $key => $value) {
            $value['id'] = $key;
            $linkTypeSelect = array(
                $value['urlType'] == '0' ? ' selected' : '',
                $value['urlType'] == '1' ? ' selected' : '',
            );
            $recommendType = array(
                $value['platform'] == '0' ? ' selected' : '',
                $value['platform'] == '1' ? ' selected' : '',
                $value['platform'] == '2' ? ' selected' : '',
                $value['platform'] == '3' ? ' selected' : '',
            );



            $image = $value['image'] ? $value['image'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
            $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
            <select name="urlType[]">
                <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
            </select>';
            $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]">
                    <option value ="0" '.$recommendType[0].'>'.lang('plugin/zhanmishu_app', 'public').'</option>
                    <option value ="1" '.$recommendType[1].'>'.lang('plugin/zhanmishu_app', 'H5').'</option>
                    <option value ="2" '.$recommendType[2].'>'.lang('plugin/zhanmishu_app', 'minapp').'</option>
                    <option value ="3" '.$recommendType[3].'>'.lang('plugin/zhanmishu_app', 'app').'</option>
                </select>';

                $appHanderarr = array(
                '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                '<input type="text" class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                '<input type="text" class="txt" name="title['.$value['id'].']" value="'.$value['title'].'" />',
                '<img src="'.$image.'" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" name="image['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['image'].'" />
                <input style="width:140px" type="file"  name="image_file['.$value['id'].']" value="" />',
                '<input type="text"  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType,
                '<textarea  name="description['.$value['id'].']" value="'.$value['description'].'" >'.$value['description'].'</textarea>',
            );
            showtablerow('',
                array(
                    'class="td25"', 
                    'class="td25"', 
                    'class="td25"', 
                    'class="td25"',
                    'class="td22"',
                    'class="td22"'
                ),
                $appHanderarr
            );

        }
        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_app', 'adduCenterItem').'</a></div></tr>';

        showsubmit('tabBarNavSubmit');
        showformfooter(); /*dism·taobao·com*/

        $placeholder = lang('plugin/zhanmishu_app','image_placeholder');
        $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'<select name="urlType[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'URL').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'appPage').'</option></select>';
        $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'public').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'H5').'</option><option value ="2">'.lang('plugin/zhanmishu_app', 'minapp').'</option><option value ="3">'.lang('plugin/zhanmishu_app', 'app').'</option></select>';

        echo <<<EOT
        <script type="text/JavaScript">
            var rowtypedata = [
                [
                    [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                    [1,'<input type="text" class="txt" name="order[]" value="">', 'td25'],
                    [1,'<input type="text" required class="txt" name="title[]" value="">', 'td22'],
                    [1,'<img src="source/plugin/zhanmishu_app/template/images/noimg.jpg" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" placeholder="{$placeholder}" name="image[]" value="" /><input type="file" class="" name="image_file[]" style="width:140px;" value="">', 'td25'],
                    [1,'<input type="text" required class="" name="url[]" value="">{$urlType}', 'td22'],
                    [1,'<textarea required class="" name="description[]" value=""></textarea>', 'td22'],
                ]
            ];
        </script>
EOT;

    }
}