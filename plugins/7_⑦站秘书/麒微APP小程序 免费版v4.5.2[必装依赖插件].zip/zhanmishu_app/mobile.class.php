<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: discuzcode.func.php 36284 2016-12-12 00:47:50Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';

class zhanmishu_app_base {
    function common(){
        global $_G;
        if(!defined('IN_MOBILE_API') || defined('IN_MAGMOBILE_API')) {
            return;
        }
        $_G['siteurl'] = str_replace('source/plugin/zhanmishu_app/','',$_G['siteurl']);
        $_G['pluginrunlist'] = array('zhanmishu_app','mobile', 'qqconnect', 'wechat');

        if (is_dir(DISCUZ_ROOT.'source/plugin/magmobileapi')) {
            $_G['pluginrunlist'][] = 'magmobileapi';
        }
        
        $_SERVER['HTTP_REFERER'] = '';
        //防止云验证码
        $_G['setting']['seccodedata']['cloudip'] = 0;
        $_G['setting']['seccodedata']['type'] = 0;
        $_G['setting']['secqaa'] = array();
        //关闭云漫游功能
        $_G['setting']['cloud_status'] = 0;
        //兼容头像路径
        $_G['setting']['avatarmethod'] = 0;
        //绕过防灌水设置
        $_G['setting']['need_email'] = 0;//关闭邮箱认证
        $_G['setting']['need_avatar'] = 0;//关闭头像认证
        //关闭验证码
        $_G['setting']['seccodedata']['rule'] = array();
        //关闭防采集
        $_G['setting']['antitheft']['allow'] = 0;

        //登录注册后可看大图
        $_G['setting']['guestviewthumb']['flag'] = 0;

        if(!$_G['uid']) {
            $token = $_GET['token'];
            if (!is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_wechat/source/class/zhanmishu_wechat_member.php')) {
                return;
            }
            if (!class_exists('zhanmishu_wechat_member',false)) {
                C::import('zhanmishu_wechat_member','plugin/zhanmishu_wechat/source/class');
            }
            if (!$token) {
                $headers = zhanmishu_wechat_member::getallheaders();
                $token = $headers['Authorization'];
            }

            if ($token) {
                zhanmishu_wechat_member::login_by_token($token);
                if ($_G['uid'] && !defined('DISABLEXSSCHECK')) {
                    define('DISABLEXSSCHECK', true);
                }
            }
        }
        if(class_exists('zhanmishu_app_origin_api', false) && method_exists('zhanmishu_app_origin_api', 'common')) {
            zhanmishu_app_origin_api::common();
        }

        $_G['setting']['msgforward'] = '';
        $_G['setting']['cacheindexlife'] = $_G['setting']['cachethreadlife'] = false;
        
        $_GET['formhash'] = $_POST['formhash'] = formhash(); //formhash过滤
        if ($_GET['mod'] != 'forumUpload' && $_GET['mod'] != 'swfupload') {
            unset($_GET['hash']);
            unset($_POST['hash']);
        }
        if ($_GET['mod'] == 'post' || $_GET['mod'] == 'misc') {
            $_GET['hash'] = $_GET['formhash'];
        }

        
    }



}


class plugin_zhanmishu_app extends zhanmishu_app_base{

    function global_header() {
        if(!defined('IN_MOBILE_API')) {
            return;
        }
        if(class_exists('zhanmishu_app_origin_api', false) && method_exists('zhanmishu_app_origin_api', 'output')) {
            zhanmishu_app_origin_api::output();
        }
    }
    function global_footer() {
        if(!defined('IN_MOBILE_API')) {
            return;
        }
        if(class_exists('zhanmishu_app_origin_api', false) && method_exists('zhanmishu_app_origin_api', 'output')) {
            zhanmishu_app_origin_api::output();
        }
    }
}
class mobileplugin_zhanmishu_app extends zhanmishu_app_base{
    function global_header_mobile() {
        if(!defined('IN_MOBILE_API')) {
            return;
        }
        if(class_exists('zhanmishu_app_origin_api', false) && method_exists('zhanmishu_app_origin_api', 'output')) {
            zhanmishu_app_origin_api::output();
        }
    }
    function global_footer_mobile() {
        if(!defined('IN_MOBILE_API')) {
            return;
        }
        if(class_exists('zhanmishu_app_origin_api', false) && method_exists('zhanmishu_app_origin_api', 'output')) {
            zhanmishu_app_origin_api::output();
        }
    }}
//From: Dism·taobao·com
?>