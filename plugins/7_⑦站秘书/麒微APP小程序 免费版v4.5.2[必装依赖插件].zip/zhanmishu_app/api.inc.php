<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';

$mod = $_GET['mod'] ?  $_GET['mod'] : 'index';

if (!in_array($mod, array('userapi' ,'user','sms','share','goTo','app','chat','qrcode','admin'))) {
    $return = array(
        'msg'=>'module_error',
        'code'=>'-9999'
    );
    echo zhanmishu_app_api::encode($return);
    exit;
}

$apifile = DISCUZ_ROOT.'./source/plugin/zhanmishu_app/api/'.$_GET['version'].'/'.$mod.'.php';

if(file_exists($apifile)) {
    require_once $apifile;
} else {
    if($_GET['version'] > 1) {
        for($i = $_GET['version']; $i >= 1; $i--) {
            $apifile = DISCUZ_ROOT.'./source/plugin/zhanmishu_app/api/'.$i.'/'.$mod.'.php';
            if(file_exists($apifile)) {
                $_GET['version'] = $i;
                require_once $apifile;
                break;
            } elseif($i==1 && !file_exists($apifile)) {
                zhanmishu_app_api::encode(array('msg' => 'module_not_exists','code'=>'-9999'));
            }
        }
    } else {
        zhanmishu_app_api::encode(array('msg' => 'module_not_exists','code'=>'-9999'));
    }
}
//From: dis'.'m.tao'.'bao.com
?>