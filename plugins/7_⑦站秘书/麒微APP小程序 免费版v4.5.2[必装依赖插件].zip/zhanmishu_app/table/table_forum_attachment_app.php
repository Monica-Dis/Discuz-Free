<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_forum_attachment.php 36278 2016-12-09 07:52:35Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_forum_attachment_app extends table_forum_attachment
{
    private $_tableids = array();

    public function __construct() {

        $this->_table = 'forum_attachment';
        $this->_pk    = 'aid';
        $this->_pre_cache_key = 'forum_attachment_';
        $this->_cache_ttl = 0;

        parent::__construct(); /*d'.'is'.'m.ta'.'obao.com*/
    }


    public function fetch_all_for_manage($tableid, $inforum = '', $authorid = 0, $filename = '', $keyword = '', $sizeless = 0, $sizemore = 0, $dlcountless = 0, $dlcountmore = 0, $daysold = 0, $count = 0, $start = 0, $limit = 0, $fileExt = '') {
        $sql = "1";
        if(!is_numeric($tableid) || $tableid < 0 || $tableid > 9) {
            return;
        }
        if($inforum) {
            $sql .= is_numeric($inforum) ? " AND t.fid=".DB::quote($inforum) : '';
            $sql .= $inforum == 'isgroup' ? ' AND t.isgroup=\'1\'' : ' AND t.isgroup=\'0\'';
        }
        if($authorid) {
            $sql .= " AND a.uid=".DB::quote($authorid);
        }
        if($fileExt) {
            $sql .= " AND a.filename LIKE ".DB::quote('%.'.$fileExt);
        }
        if($filename) {
            $sql .= " AND a.filename LIKE ".DB::quote('%'.$filename.'%');
        }
        if($keyword) {
            $sqlkeywords = $or = '';
            foreach(explode(',', str_replace(' ', '', $keyword)) as $keyword) {
                $sqlkeywords .= " $or a.description LIKE ".DB::quote('%'.$keyword.'%');
                $or = 'OR';
            }
            $sql .= " AND ($sqlkeywords)";
        }
        $sql .= $sizeless ? " AND a.filesize>'$sizeless'" : '';
        $sql .= $sizemore ? " AND a.filesize<'$sizemore' " : '';
        $sql .= $dlcountless ? " AND ai.downloads<'$dlcountless'" : '';
        $sql .= $dlcountmore ? " AND ai.downloads>'$dlcountmore'" : '';
        $sql .= $daysold ? " AND a.dateline<'".(TIMESTAMP - intval($daysold) * 86400)."'" : '';
        if($count) {
            return DB::result_first("SELECT COUNT(*)
                FROM ". DB::table('forum_attachment_'.$tableid)." a
                INNER JOIN ".DB::table('forum_attachment')." ai USING(aid)
                INNER JOIN ".DB::table('forum_thread')." t
                INNER JOIN ".DB::table('forum_forum')." f
                WHERE t.tid=a.tid AND f.fid=t.fid AND t.displayorder>='0' AND $sql");
        }
        return DB::fetch_all("SELECT a.*, ai.downloads, t.fid, t.tid, t.subject, f.name AS fname
                FROM ". DB::table('forum_attachment_'.$tableid)." a
                INNER JOIN ".DB::table('forum_attachment')." ai USING(aid)
                INNER JOIN ".DB::table('forum_thread')." t
                INNER JOIN ".DB::table('forum_forum')." f
                WHERE t.tid=a.tid AND f.fid=t.fid AND t.displayorder>='0' AND $sql ORDER BY a.aid DESC ".DB::limit($start, $limit));
    }

}
//From: dis'.'m.tao'.'bao.com
?>