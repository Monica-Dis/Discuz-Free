<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_common_member_verify_info.php 31799 2012-10-11 02:36:34Z zhengqingpeng $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_common_member_verify_info_app extends table_common_member_verify_info
{
    public function __construct() {

        $this->_table = 'common_member_verify_info';
        $this->_pk    = 'vid';

        parent::__construct(); /*d'.'is'.'m.ta'.'obao.com*/
    }

    public function delete_by_uid($uid, $verifytype = null) {
        if($uid) {
            $addsql = '';
            if($verifytype !== null) {
                $verifytype = dintval($verifytype, is_array($verifytype) ? true : false);
                $addsql = ' AND '.DB::field('verifytype', $verifytype);
            }
            return DB::query('DELETE FROM %t WHERE '.(is_array($uid) ? 'uid IN(%n)' : 'uid=%d').$addsql, array($this->_table, $uid));
        }
        return false;
    }



}
//From: dis'.'m.tao'.'bao.com
?>