function i18n(){
	return {
	  locale: 'zh-CN',
	  messages: {
		'en-US': {
		  index: {
		  },
		  course: {
			 search: 'search',
		  }
		},
		'zh-CN': {
		  index: {
		  },
		  course: {
			  search: '搜索', 
			  recommendCourse: '精选课程',
			  newCourse: '最新课程',
			  free: '免费',
			  livingItem: '正在直播',
			  living: '直播中',
			  record: '回放',
			  notStart: '未开始',
			  livingItem: '正在直播',
			  views: '阅读',
			  seens: '观看',
			  moneyUnit: '元',
			  loadingMore: '加载更多',
			  noMore: '没有更多数据',
			  loading: '加载中',
			  noCourseContent: '暂无详情',
			  noCourse: '暂无课程',
			  scanQrcode: '识别二维码',
			  teacherWechat: '教师微信',
			  closed: '关闭',
			  teacher: '课程',
			  teacherScore: '评价',
			  courseCentent: '课程详情',
			  replies: '评论',
			  viewAll: '查看全部',
			  vipTips: '以下会员可免费观看',
			  buyVip: '开通VIP',
			  cancel: '取消',
			  confirm: '确认',
			  chapterHead: '第',
			  share: '分享',
			  chapterFooter: '章',
			  collect: '收藏',
			  collected: '已收藏',
			  sought: '咨询',
			  entere: '去报名',
			  learn: '去学习',
			  gobuy: '去购买',
			  noact: '暂不可用',
			  shareTo: '分享到',
			  cancelShare: '取消分享',
			  sendMsg: '发送',
			  creditNum: '积分余额',
			  chargeNum: '充值数量',
			  moneyUnitMark: '¥',
			  confirmPay: '确认支付',
			  otherPayNum: '其他金额',
			  changeCreditsAt: '兑换积分：',
			  chargePlaceholder: '请输入1~999：',
			  numAt: '数量:：',
			  changeCreditsAt: '数量:',
			  nowHaveAt: '当前拥有：',
			  present: '赠送：',
			  rewardTo: '红包打赏给：',
			  courseIntro: '简介',
			  teacherAt: '授课老师：',
		  }
		}
	  }
	}
}
module.exports = {
	i18n
}