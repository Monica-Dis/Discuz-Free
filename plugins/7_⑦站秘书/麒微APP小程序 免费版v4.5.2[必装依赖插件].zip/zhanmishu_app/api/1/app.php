<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$appHander = zhanmishu_app::getInstance();

$appController = new zhanmishu_app_app_controller($appHander);

if (substr($_GET['action'],0,1) != '_' &&  method_exists($appController, $_GET['action'])) {
    $action = $_GET['action'] ? $_GET['action'] : 'index';
    $appController->$action($_GET);
}
