<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$_G['siteurl'] = str_replace('source/plugin/zhanmishu_app/','',$_G['siteurl']);
$appHander = zhanmishu_app::getInstance();

$goTo = urldecode($_GET['url']);
ob_clean();
if ($appHander->check_url($goTo) == 'url') {
    header('location:'.$goTo);
}else if ($goTo) {
    header('location:'.$_G['siteurl'].$goTo);
}else{
    header('location:'.$_G['siteurl']);
}
exit;