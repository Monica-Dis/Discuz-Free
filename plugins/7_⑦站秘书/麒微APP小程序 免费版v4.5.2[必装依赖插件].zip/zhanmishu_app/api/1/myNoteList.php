<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */ 

if(!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}

$_GET['mod'] = 'space';
$_GET['do'] = 'notice';
include_once 'home.php';

class zhanmishu_app_origin_api {
    function common() {
    }

    function output() {
        global $_G;

        require_once libfile('function/home');
        $perpage = 30;
        $perpage = mob_perpage($perpage);

        $page = empty($_GET['page'])?0:intval($_GET['page']);
        if($page<1) $page = 1;
        $start = ($page-1)*$perpage;

        ckstart($start, $perpage);

        $noticelang = lang('notification', 'reppost_noticeauthor');
        $noticepreg = '/^'.str_replace(array('\{actor\}', '\{subject\}', '\{tid\}', '\{pid\}'), array('(.+?)', '(.+?)', '(\d+)', '(\d+)'), preg_quote($noticelang, '/')).'$/';
        $actorlang = '<a href="home.php?mod=space&uid={actoruid}">{actorusername}</a>';
        $actorpreg = '/^'.str_replace(array('\{actoruid\}', '\{actorusername\}'), array('(\d+)', '(.+?)'), preg_quote($actorlang, '/')).'$/';

        $new = -1;
        $count = C::t('home_notification')->count_by_uid($_G['uid'], $new);
        if($count) {
            if($new == 1 && $perpage == 30) {
                $perpage = 200;
            }
            foreach(C::t('home_notification')->fetch_all_by_uid($_G['uid'], $new,'', $start, $perpage) as $value) {
                if($value['new']) {
                    $newnotify = true;
                    $value['style'] = 'color:#000;font-weight:bold;';
                } else {
                    $value['style'] = '';
                }
                $value['rowid'] = '';
                if(in_array($value['type'], array('friend', 'poke'))) {
                    $value['rowid'] = ' id="'.($value['type'] == 'friend' ? 'pendingFriend_' : 'pokeQuery_').$value['authorid'].'" ';
                }
                if($value['from_num'] > 0) $value['from_num'] = $value['from_num'] - 1;
                $list[$value['id']] = $value;
            }
        }
        foreach($list as $_k => $_v) {
            if(preg_match($noticepreg, $_v['note'], $_r)) {
                list(, $actor, $tid, $pid, $subject) = $_r;
                if(preg_match($actorpreg, $actor, $_r)) {
                    list(, $actoruid, $actorusername) = $_r;
                }
                $list[$_k]['notevar'] = array(
                    'tid' => $tid,
                    'pid' => $pid,
                    'subject' => $subject,
                    'actoruid' => $actoruid,
                    'actorusername' => $actorusername,
                );
            }
        }
        $appHanderChat = new zhanmishu_app_chat_controller(new zhanmishu_app());
        $chatList = $appHanderChat->_chatingList();
        $resultData = array(
            'list' => zhanmishu_app_api::getvalues(array_values($list), array('/^\d+$/'), array('id', 'uid', 'type', 'new', 'authorid', 'author', 'note', 'dateline', 'from_id', 'from_idtype', 'from_num', 'style', 'rowid', 'notevar')),
            'count' => $count,
            'chatList' => $chatList,
            'perpage' => $perpage,
            'page' => $page,
        );

        echo zhanmishu_app_api::resultToJson($resultData);
        exit;
    }
}
?>