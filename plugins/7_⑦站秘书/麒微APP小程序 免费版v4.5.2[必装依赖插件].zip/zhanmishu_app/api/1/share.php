<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (is_dir(DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat')) {
    include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat/source/Autoloader.php';
    $zhanmishu_wechat = zhanmishu_wechat::getInstance();


    $JsParams = $zhanmishu_wechat->wechatHander()->getJsSign(urldecode($_GET['url']));

    echo json_encode($JsParams);
}

