<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: forumdisplay.php 35213 2015-02-26 06:15:12Z DISM.TAOBAO.COM $
 */
if (!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}


$_GET['mod'] = 'spacecp';
$_GET['ac'] = 'credit';
$_GET['op'] = 'log';
include_once 'home.php';

class zhanmishu_app_origin_api {

    function common() {
        global $_G;
        $_G['siteurl'] = str_replace('source/plugin/zhanmishu_app/','',$_G['siteurl']);
    }

    function output() {
        global $_G, $loglist, $optypes, $count, $perpage, $page;
        
        $optypesOut = array();
        foreach ($optypes as $key => $value) {
            $optypesOut[] = array(
                'id'=> $value,
                'name'=> lang('spacecp', 'logs_credit_update_'.$value)
            );
        }

        $extcredits = array();
        foreach ($_G['setting']['extcredits'] as $key => $value) {
            $value['exttype'] = $key;
            $extcredits[] = $value;
        }

        foreach ($loglist as $key => $value) {
            $credits = array();
            for ($i=0; $i < 8; $i++) { 
                if ($value['extcredits'.($i+1)] != '0') {
                    $credits[] = array(
                        'exttype'=> $i + 1,
                        'number'=> $value['extcredits'.($i+1)],
                        'title'=> $_G['setting']['extcredits'][$i+1]['title'],
                        'unit'=> $_G['setting']['extcredits'][$i+1]['unit'],
                    );
                }
            }


            if ($value['operation']) {
                $loglist[$key]['optype'] = lang('spacecp', 'logs_credit_update_'.$value['operation']);
            }else{
                $loglist[$key]['optype'] = '';
            }
            $loglist[$key]['credits'] = $credits;
            $loglist[$key]['icons'] = $_G['siteurl'] . 'source/plugin/zhanmishu_app/template/images/credits.png';
        }

        $resultData = array();
        $resultData['loglist'] = $loglist ? $loglist : array();
        $resultData['count'] = $count;
        $resultData['perpage'] = $perpage;
        $resultData['curpage'] = $page;
        $resultData['optypes'] = $optypesOut;
        $resultData['extcredits'] = $extcredits;

        echo zhanmishu_app_api::resultToJson($resultData);
        exit;
    }

}
//From: dis'.'m.tao'.'bao.com
?>