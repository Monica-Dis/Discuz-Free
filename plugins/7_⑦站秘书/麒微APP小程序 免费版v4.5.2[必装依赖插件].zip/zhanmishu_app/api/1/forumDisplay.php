<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: forumdisplay.php 35213 2015-02-26 06:15:12Z DISM.TAOBAO.COM $
 */
if (!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}


$_GET['mod'] = 'forumdisplay';
include_once 'forum.php';

class zhanmishu_app_origin_api {

    function common() {
        global $_G;
        if (!empty($_GET['pw'])) {
            $_GET['action'] = 'pwverify';
        }
        $_G['forum']['allowglobalstick'] = true;
        if($_G['forum']['redirect']) {
            $resultData = array(
                'forum' => array(
                    'fid' => $_G['fid'],
                    'redirect' => $_G['forum']['redirect']
                )
            );
        }
    }

    function output() {
        global $_G;
        $_G['siteurl'] = str_replace('source/plugin/zhanmishu_app/','',$_G['siteurl']);
        include_once DISCUZ_ROOT.'source/plugin/zhanmishu_app/api/1/inc_threadlist.php';
        
        echo zhanmishu_app_api::resultToJson($resultData);
        exit;
    }

}
//From: dis'.'m.tao'.'bao.com
?>