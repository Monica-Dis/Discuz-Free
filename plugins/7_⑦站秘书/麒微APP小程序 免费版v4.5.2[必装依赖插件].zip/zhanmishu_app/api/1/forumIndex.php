<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */ 

if(!defined('IN_MOBILE_API')) {
    exit('Access Denied');
}


$_GET['mod'] = 'index';
include_once 'forum.php';

class zhanmishu_app_origin_api {

    function common() {
    }

    function output() {
        global $_G;
        $_G['siteurl'] = str_replace('source/plugin/zhanmishu_app/','',$_G['siteurl']);
        $forums = $GLOBALS['forums'] ? $GLOBALS['forums'] : C::t('forum_forum')->fetch_all_by_status(1);
        foreach ($forums as $forum) {
            if ($forum['fup'] && $GLOBALS['forumlist'][$forum['fup']]) {
                $GLOBALS['forumlist'][$forum['fup']]['sublist'][] = zhanmishu_app_api::getvalues($forum, array('fid', 'name', 'threads', 'posts', 'redirect', 'todayposts', 'description'));
            }
            if ($GLOBALS['forumlist'][$forum['fid']]['icon']) {
                $icon = preg_match('/src="(.+?)"/', $GLOBALS['forumlist'][$forum['fid']]['icon'], $r) ? $r[1] : '';
                if (!preg_match('/^https:\//', $icon)) {
                    $icon = $_G['siteurl'] . $icon;
                }
                $GLOBALS['forumlist'][$forum['fid']]['icon'] = $icon;
            }
        }
        if ($_GET['checknotice']) {
            $resultData = array();
        } else {
            $favoriteInfo = array();
            if ($_G['uid']) {
                 //板块收藏
                $favoriteInfo = C::t("home_favorite")->fetch_all_by_uid_idtype($_G['uid'],'fid');

                $favforumIds = array();
                foreach ($favoriteInfo as $key => $value) {
                    $favforumIds[] = $value['id'];
                }


                $favforumlist = C::t('forum_forum')->fetch_all($favforumIds);
                $favforumlist = array_values(zhanmishu_app_api::getvalues($favforumlist, array('/^\d+$/'), array('fid', 'name', 'threads', 'posts', 'redirect', 'todayposts', 'description', 'sublist', 'icon','favtimes','sharetimes','disablethumb','fup','type', 'threads')));

                foreach ($favforumlist as $kk => $vv) {
                    if (!$vv['icon']) {
                        $favforumlist[$kk]['icon'] = $_G['siteurl'].'source/plugin/zhanmishu_app/template/images/default.png';
                    }
                    $favforumlist[$kk]['isfavorite'] = '1';
                }
                
            }


            $forumlist = array_values(zhanmishu_app_api::getvalues($GLOBALS['forumlist'], array('/^\d+$/'), array('fid', 'name', 'threads', 'posts', 'redirect', 'todayposts', 'description', 'sublist', 'icon','favtimes','sharetimes','disablethumb','fup','type', 'threads')));
            foreach ($forumlist as $key => $value) {
                if (!$value['icon']) {
                    $forumlist[$key]['icon'] = $_G['siteurl'].'source/plugin/zhanmishu_app/template/images/default.png';
                }
                $forumlist[$key]['isfavorite'] = '0';
                if ($_G['uid'] && in_array($value['fid'], $favforumIds)) {
                    $forumlist[$key]['isfavorite'] = '1';
                }
            }

            $appHander = zhanmishu_app::getInstance();
            $topic = $appHander->GetFromCache('recmmend');

            foreach ($topic as $key => $value) {
                $topic[$key]['image'] = $appHander->auto_to_url($value['image']);
                if ($value['urlType'] == '0') {
                    $topic[$key]['url'] = $appHander->auto_to_url($value['url']);
                }
            }
            $resultData = array(
                'member_email' => $_G['member']['email'],
                'member_credits' => $_G['member']['credits'],
                'setting_bbclosed' => $_G['setting']['bbclosed'],
                'topic' => $topic,
                'group' => zhanmishu_app_api::getvalues($_G['group'], array('groupid', 'grouptitle', '/^allow.+?$/')),
                'catlist' => array_values(zhanmishu_app_api::getvalues($GLOBALS['catlist'], array('/^\d+$/'), array('fid', 'name', 'forums'))),
                'forumlist' => $forumlist,
                'favforumlist' => $favforumlist,
            );
        }

        //test
        $resultData['topic'] = zhanmishu_app_api::auto_charset_change($resultData['topic'],'UTF-8',CHARSET);
        echo zhanmishu_app_api::resultToJson($resultData);
        exit;
    }

}
//From: dis'.'m.tao'.'bao.com
?>