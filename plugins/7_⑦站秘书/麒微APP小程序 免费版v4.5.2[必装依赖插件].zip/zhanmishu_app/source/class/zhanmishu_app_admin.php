<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


class zhanmishu_app_admin extends zhanmishu_app
{
    static public function importJquery(){
        echo '<script src="
source/plugin/zhanmishu_app/template/js/jquery.min.js" type="text/javascript"></script>';
    echo <<<EOT
<script type="text/JavaScript">
var uploadIcon = function(thisElement){
    var formData = new FormData();
    var file = thisElement.files[0];
    if (!file) {
        return;
    }
    formData.append('file', file);
    console.log(formData);
    jQuery.ajax({
        url: '{$_G['siteurl']}source/plugin/zhanmishu_app/api.php?mod=admin&action=uploadimg',
        type: 'POST',
        data: formData,
        // 告诉jQuery不要去处理发送的数据
        processData: false,
        // 告诉jQuery不要去设置Content-Type请求头
        dataType: "json", 
        contentType: false,
        beforeSend: function () {
            // console.log("正在进行，请稍候");
        },
        success: function (data) {
            if (data.result.images.file) {
                jQuery(thisElement).prev().val(data.result.images.file);
                jQuery(thisElement).prev().prev().attr('src', data.result.images.file);
                jQuery(thisElement).val("");
                jQuery(thisElement).files = {};

            }else{
                alert('upload_error');
            }
        },
        error: function (data) {
            console.log(data);
        }
    }); 
}
</script>
EOT;
            

    }
    static public function importPureCss(){
        echo '<link rel="stylesheet" href="source/plugin/zhanmishu_app/template/css/pure-min.css?3">';
    }

    /**
     * @Author    Lanya
     * @DateTime  2019-05-17
     * @QQ        87883395
     * @copyright [HereEdu!] (C)2001-2099 hereEdu       Inc
     * @param     array      $title       [array('title','link','selected')]
     * @param     array      $menu        [[array('title','link','selected'),[]...]]
     * @return    [type]                  [description]
     */
    static public function menuHorizontal($title = array(),$menu = array()){

        $title['link'] = $title['link'] ?  $title['link'] : 'javascript:;';
        $menuString = '';
        foreach ($menu as $key => $value) {
            $value['link'] = $value['link'] ? $value['link'] : '';
            $selected = $value['selected'] ? ' pure-menu-selected' : '';
            $menuString .= '<li class="pure-menu-item'.$selected.'"><a href="'.$value['link'].'" class="pure-menu-link">'.$value['title'].'</a></li>';
        }
        $selected = $title['selected'] ? ' pure-menu-selected' : '';
        $titleString = !empty($title) && $title['title'] ? '<a href="'.$title['link'].'" class="pure-menu-heading pure-menu-link">'.$title['title'].'</a>' : '';

        $menuString = '<div class="pure-menu pure-menu-horizontal">'.$titleString.'<ul class="pure-menu-list">
                '.$menuString.'
            </ul>
        </div>';
        echo $menuString;
    }  
}