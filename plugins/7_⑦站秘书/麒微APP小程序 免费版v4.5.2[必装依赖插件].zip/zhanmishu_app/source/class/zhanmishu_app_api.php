<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */
if(!defined('IN_MOBILE_API') && !defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class zhanmishu_app_api{
    public static function encode($data = array() ,$isChangeCharset = true, $isJSON_NUMERIC_CHECK = true){
        if(!$isJSON_NUMERIC_CHECK){
            if ($isChangeCharset) {
                return json_encode(self::auto_charset_change($data), JSON_ERROR_UTF8);
            }
            return json_encode($data);
        }
        if ($isChangeCharset) {
            return json_encode(self::auto_charset_change($data),JSON_NUMERIC_CHECK + JSON_ERROR_UTF8);
        }
        return json_encode($data,JSON_NUMERIC_CHECK);
    }

    public static function result($result) {
        global $_G;
        ob_end_clean();
        function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
        header("Content-type: application/json");
        self::make_cors($_SERVER['REQUEST_METHOD'], REQUEST_METHOD_DOMAIN);
        $result = self::json(self::format($result));
        if(defined('FORMHASH')) {
            echo empty($_GET['jsoncallback_'.FORMHASH]) ? $result : $_GET['jsoncallback_'.FORMHASH].'('.$result.')';
        } else {
            echo $result;
        }
        exit;
    }

    public static function format($result) {
        switch (gettype($result)) {
            case 'array':
                foreach($result as $_k => $_v) {
                    $result[$_k] = self::format($_v);
                }
                break;
            case 'boolean':
            case 'integer':
            case 'double':
            case 'float':
                $result = (string)$result;
                break;
        }
        return $result;
    }

    public static function getvalues($variables, $keys, $subkeys = array()) {
        $return = array();
        foreach($variables as $key => $value) {
            foreach($keys as $k) {
                if($k{0} == '/' && preg_match($k, $key) || $key == $k) {
                    if($subkeys) {
                        $return[$key] = self::getvalues($value, $subkeys);
                    } else {
                        if(!empty($value) || !empty($_GET['debug']) || (is_numeric($value) && intval($value) === 0 )) {
                            $return[$key] = is_array($value) ? self::arraystring($value) : (string)$value;
                        }
                    }
                }
            }
        }
        return $return;
    }

    static function arraystring($array) {
        foreach($array as $k => $v) {
            $array[$k] = is_array($v) ? self::arraystring($v) : (string)$v;
        }
        return $array;
    }
    public static function resultToJson($data = array(),$code = '0',$msg = 'success' ,$isChangeCharset = true, $isJSON_NUMERIC_CHECK = true) {
        $outapi = array();
        $outapi['code'] = $data['code'] ? $data['code'] : $code;
        $outapi['msg'] = $data['msg'] ? $data['msg'] : $msg;

        global $_G;

        if(!empty($_G['messageparam'])) {
            $message_result = lang('plugin/mobile', $_G['messageparam'][0], $_G['messageparam'][2]);
            if($message_result == $_G['messageparam'][0]) {
                $vars = explode(':', $_G['messageparam'][0]);
                if (count($vars) == 2) {
                    $message_result = lang('plugin/' . $vars[0], $vars[1], $_G['messageparam'][2]);
                    $_G['messageparam'][0] = $vars[1];
                } else {
                    $message_result = lang('message', $_G['messageparam'][0], $_G['messageparam'][2]);
                }
            }
            $message_result = strip_tags($message_result);

            if($_G['messageparam'][4]) {
                $_G['messageparam'][0] = "custom";
            }
            if ($_G['messageparam'][3]['login'] && !$_G['uid']) {
                $_G['messageparam'][0] .= '//' . $_G['messageparam'][3]['login'];
            }
            $data['message'] = array("messageval" => $_G['messageparam'][0], "messagestr" => $message_result);
            
        }
        $outapi['result'] = $data;

        return self::encode($outapi ,$isChangeCharset, $isJSON_NUMERIC_CHECK);
    }

    public static function auto_charset_change($data,$charset='',$toCharset='UTF-8'){
        $charset = $charset ? $charset : CHARSET;
        if (!is_array($data)) {
            return diconv($data,$charset,$toCharset);
        }else{
            $tmp = array();
            foreach ($data as $key => $value) {
                $nkey = diconv($key,$charset,$toCharset);
                $nvalue = self::auto_charset_change($value,$charset,$toCharset);
                $tmp[$nkey] = $nvalue;
            }
            return $tmp;
        }
        return false;
    }

    public static function usergroupIconId($groupid) {
        global $_G;
        if($_G['cache']['usergroupIconId']) {
            return $_G['cache']['usergroupIconId']['variable'][$groupid];
        }
        loadcache('usergroupIconId');
        if(!$_G['cache']['usergroupIconId'] || TIMESTAMP - $_G['cache']['usergroupIconId']['expiration'] > 3600) {
            loadcache('usergroups');
            $memberi = 0;
            $return = array();
            foreach($_G['cache']['usergroups'] as $groupid => $data) {
                if($data['type'] == 'member') {
                    if(!$memberi && $groupid == $_G['setting']['newusergroupid']) {
                        $memberi = 1;
                    }
                    if($memberi > 0) {
                        $return[$groupid] = $memberi++;
                    }
                } elseif($data['type'] == 'system' && $groupid < 4) {
                    $return[$groupid] = 'admin';
                } elseif($data['type'] == 'special') {
                    $return[$groupid] = 'special';
                }
            }
            savecache('usergroupIconId', array('variable' => $return, 'expiration' => TIMESTAMP));
            return $return[$groupid];
        } else {
            return $_G['cache']['usergroupIconId']['variable'][$groupid];
        }
    }

    public static function make_cors($request_method, $origin = '') {

        $origin = $origin ? $origin : REQUEST_METHOD_DOMAIN;

        if ($request_method === 'OPTIONS') {
            header('Access-Control-Allow-Origin:'.$origin);

            header('Access-Control-Allow-Credentials:true');
            header('Access-Control-Allow-Methods:GET, POST, OPTIONS');


            header('Access-Control-Max-Age:1728000');
            header('Content-Type:text/plain charset=UTF-8');
            header("status: 204");
            header('HTTP/1.0 204 No Content');
            header('Content-Length: 0',true);
            flush();
        }

        if ($request_method === 'POST') {

            header('Access-Control-Allow-Origin:'.$origin);
            header('Access-Control-Allow-Credentials:true');
            header('Access-Control-Allow-Methods:GET, POST, OPTIONS');
        }

        if ($request_method === 'GET') {

            header('Access-Control-Allow-Origin:'.$origin);
            header('Access-Control-Allow-Credentials:true');
            header('Access-Control-Allow-Methods:GET, POST, OPTIONS');
        }

    }
}
