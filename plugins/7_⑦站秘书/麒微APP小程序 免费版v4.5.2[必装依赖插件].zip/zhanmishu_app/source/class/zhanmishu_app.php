<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * 
 */
class zhanmishu_app extends zhanmishu_base
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }
    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }
    // public static function imageThumbSrc($file, $aid, $w = 140, $h = 140, $type = ''){
    //     if (!$file && !$aid) {
    //         return false;
    //     }
    //     $daid = intval($aid);
    //     $type = $type ? $type : 'fixwr';
    //     $dw = intval($w);
    //     $dh = intval($h);
    //     if ($file) {
    //         return self::getImageThumb($file, $dw, $dh, $type);
    //     }else if ($aid) {
    //         return self::getforumimg($daid, $dw, $dh, $type);
    //     }
    // }

    // /**
    //  * @Author      Lanya      87883395@qq.com zhanmishu.com
    //  * @Description 此方法会绕过dsign
    //  * @DateTime    2019-09-06
    //  * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
    //  * @param       [type]     $daid           [description]
    //  * @param       integer    $dw             [description]
    //  * @param       integer    $dh             [description]
    //  * @param       string     $type           [description]
    //  * @return      [type]                     [description]
    //  */
    // public static function getforumimg($daid, $dw = 140, $dh = 140, $type = ''){
    //     global $_G;

    //     $thumbfile = 'image/'.helper_attach::makethumbpath($daid, $dw, $dh);
    //     $attachurl = helper_attach::attachpreurl();

    //     define('NOROBOT', TRUE);
    //     if($attach = C::t('forum_attachment_n')->fetch('aid:'.$daid, $daid, array(1, -1))) {
    //         if(!$dw && !$dh && $attach['tid'] != $id) {
    //                dheader('location: '.$_G['siteurl'].'static/image/common/none.gif');
    //         }
    //         dheader('Expires: '.gmdate('D, d M Y H:i:s', TIMESTAMP + 3600).' GMT');
    //         if($attach['remote']) {
    //             $filename = $_G['setting']['ftp']['attachurl'].'forum/'.$attach['attachment'];
    //         } else {
    //             $filename = $_G['setting']['attachdir'].'forum/'.$attach['attachment'];
    //         }
    //         require_once libfile('class/image');
    //         $img = new image;
    //         if($img->Thumb($filename, $thumbfile, $w, $h, $type)) {
    //             dheader('location: '.$attachurl.$thumbfile);
    //         } else {
    //             dheader('Content-Type: image');
    //             @readfile($filename);
    //         }
    //     }
    // }

    // public static function getThumbImage($file, $dw = 140, $dh = 140, $type = ''){
    //     global $_G;
    //     if (!is_file(DISCUZ_ROOT.$file)) {
    //         return false;
    //     }
    //     $fileext = fileext($file);
    //     $thumbfile = $file.'thumb.'.$fileext;

    //     if (!is_file(DISCUZ_ROOT.$thumbfile)) {
    //         require_once libfile('class/image');
    //         $img = new image;
    //         $rs = $img->Thumb(DISCUZ_ROOT.$file, DISCUZ_ROOT.$thumbfile, $w, $h, $type);
    //         if(!$rs) {
    //             dheader('Content-Type: image');
    //             @readfile(DISCUZ_ROOT.$file);
    //             exit;
    //         }

    //     }
    //     dheader('Content-Type: image');
    //     @readfile(DISCUZ_ROOT.$thumbfile);
    //     exit;
    // }

    /**
    * @Author      Lanya      87883395@qq.com zhanmishu.com
    * @Description 由于api中，cookie可能丢失无状态，因此根据header中的token防止跨站攻击
    * @DateTime    2019-07-10
    * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
    * @return      [type]     [验证方法，首先验证formhash，如果有效则直接成功。如果无效，则验证token是否与请求的浏览器参数对应，如一致则OK即可]
    */   
    public static function csfr(){
        global $_G;
        //兼容老版本formhash
        if ($_GET['formhash'] == formhash() || $_GET['hash'] == formhash()) {
           return true;
        }else if ($_GET['hash'] == md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])) {
            // 补齐formhash 让discuz内部其他submitcheck可以返回正确参数
            return true;
        }
        exit('csfr');
    }

    public  function cacheKey(){
        return 'zhanmishu_app';
    }

    // 获取用户认证状态
    public function userVerify($uid = ''){
        global $_G;
        $uid = $uid ? $uid : $_G['uid'];
        if(!$uid){
            return array();
        }
        return C::t("common_member_verify")->fetch($uid);
    }
    // 获取用户认证信息
    public function userVerifyInfo($uid = '', $verifyType){
        global $_G;
        $uid = $uid ? $uid : $_G['uid'];

        if(!$uid ||  !$verifyType){
            return array();
        }
        return C::t("common_member_verify_info")->fetch_by_uid_verifytype($uid, $verifyType);
    }

    public function verifySetting(){
        global $_G;
        $profilesetting = C::t('common_member_profile_setting')->range();

        // 企业认证项目
        $companyVerifyId = $this->config['verify_company'];
        $personVerifyId = $this->config['verify_person'];

        $companyVerify = $_G['setting']['verify'][$companyVerifyId];
        $personVerify = $_G['setting']['verify'][$personVerifyId];

        $verifySetting = array();
        foreach ($companyVerify['field'] as $key => $value) {
            $companyVerify['field'][$key] = $profilesetting[$value];
        }
        foreach ($personVerify['field'] as $key => $value) {
            $personVerify['field'][$key] = $profilesetting[$value];
        }

        $verifySetting['company'] = $companyVerify;
        $verifySetting['company']['id'] = $companyVerifyId;
        $verifySetting['person'] = $personVerify;
        $verifySetting['person']['id'] = $personVerifyId;

        $verifySetting['company']['field'] = array_values($verifySetting['company']['field']);
        $verifySetting['person']['field'] = array_values($verifySetting['person']['field']);


        // 当前用户认证信息
        if ($_G['uid']) {
            $space = getuserbyuid($_G['uid']);
            space_merge($space, 'field_home');
            space_merge($space, 'profile');
            $verifySetting['user'] = $space;
        }else{
            $verifySetting['user'] = array();
        }

        // 认证信息设置
        $verifySetting['setting']['change'] = 0; // 0、认证后不允许变更 1、认证后个人认证可以升级企业认证
        $verifySetting['setting']['personUpdate'] = true; // 0、认证后不允许变更 

        return $verifySetting;
    }

    public function zmsCheck(){
        return false;
    }
    public function importInitData(){
        $this->importInitUcenter();
        $this->importInitEmoji();
        $this->importInitGuide();
    }

    public function importInitGuide(){
        $guideImg = $this->GetFromCache('guideImg');
        if (empty($guideImg)) {
            $guideImg[] = array(
                'order'=>'0',
                'title'=>lang('plugin/zhanmishu_app','title'),
                'image'=>'source/plugin/zhanmishu_app/template/images/guide1.png',
                'url'=>'../oder/oder',
                'urlType'=>'1',
                'description'=>lang('plugin/zhanmishu_app','description'),
            );
            $guideImg[] = array(
                'order'=>'0',
                'title'=>lang('plugin/zhanmishu_app','title'),
                'image'=>'source/plugin/zhanmishu_app/template/images/guide2.png',
                'url'=>'../oder/oder?nid=1',
                'urlType'=>'1',
                'description'=>lang('plugin/zhanmishu_app','description'),
            );
            $guideImg[] = array(
                'order'=>'0',
                'title'=>lang('plugin/zhanmishu_app','title'),
                'image'=>'source/plugin/zhanmishu_app/template/images/guide3.png',
                'url'=>'../oder/oder?nid=2',
                'urlType'=>'1',
                'description'=>lang('plugin/zhanmishu_app','description'),
            );

             $this->writeToCache('guideImg',$guideImg);
        }        
    }

    public function importInitUcenter(){
        // 导入初始化数据
        $uCenter_list = $this->GetFromCache('uCenterAdminMy');
        if (empty($uCenter_list)) {
            $uCenter_list[] = array(
                'order'=>'0',
                'title'=>lang('plugin/zhanmishu_app','allOrder'),
                'groupid'=>'0',
                'url'=>'../oder/oder',
                'urlType'=>'1',
                'description'=>lang('plugin/zhanmishu_app','description'),
            );
            $uCenter_list[] = array(
                'order'=>'0',
                'title'=>lang('plugin/zhanmishu_app','notPay'),
                'groupid'=>'0',
                'url'=>'../oder/oder?nid=1',
                'urlType'=>'1',
                'description'=>lang('plugin/zhanmishu_app','description'),
            );
            $uCenter_list[] = array(
                'order'=>'0',
                'title'=>lang('plugin/zhanmishu_app','payed'),
                'groupid'=>'0',
                'url'=>'../oder/oder?nid=2',
                'urlType'=>'1',
                'description'=>lang('plugin/zhanmishu_app','description'),
            );
            $uCenter_list[] = array(
                'order'=>'0',
                'title'=>lang('plugin/zhanmishu_app','teacherCenter'),
                'groupid'=>'1',
                'url'=>'../liveBack/liveBack',
                'urlType'=>'1',
                'description'=>lang('plugin/zhanmishu_app','description'),
            );
            $uCenter_list[] = array(
                'order'=>'0',
                'title'=>lang('plugin/zhanmishu_app','logOut'),
                'groupid'=>'1',
                'url'=>'logout',
                'urlType'=>'1',
                'description'=>lang('plugin/zhanmishu_app','description'),
            );
            $uCenter_list[] = array(
                'order'=>'0',
                'title'=>lang('plugin/zhanmishu_app','AboutMe'),
                'groupid'=>'2',
                'url'=>'../AboutMe/AboutMe',
                'urlType'=>'1',
                'description'=>lang('plugin/zhanmishu_app','description'),
            );

            $this->writeToCache('uCenterAdminMy',$uCenter_list);

        }

    }
    public function importInitEmoji(){

        $emoji_list = $this->GetFromCache('emoji');
        if (!$emoji_list || empty($emoji_list)) {
            $json  = '[[{"url":"100.gif","alt":"[\u5FAE\u7B11]"},{"url":"101.gif","alt":"[\u4F24\u5FC3]"},{"url":"102.gif","alt":"[\u7F8E\u5973]"},{"url":"103.gif","alt":"[\u53D1\u5446]"},{"url":"104.gif","alt":"[\u58A8\u955C]"},{"url":"105.gif","alt":"[\u54ED]"},{"url":"106.gif","alt":"[\u7F9E]"},{"url":"107.gif","alt":"[\u54D1]"},{"url":"108.gif","alt":"[\u7761]"},{"url":"109.gif","alt":"[\u54ED]"},{"url":"110.gif","alt":"[\u56E7]"},{"url":"111.gif","alt":"[\u6012]"},{"url":"112.gif","alt":"[\u8C03\u76AE]"},{"url":"113.gif","alt":"[\u7B11]"},{"url":"114.gif","alt":"[\u60CA\u8BB6]"},{"url":"115.gif","alt":"[\u96BE\u8FC7]"},{"url":"116.gif","alt":"[\u9177]"},{"url":"117.gif","alt":"[\u6C57]"},{"url":"118.gif","alt":"[\u6293\u72C2]"},{"url":"119.gif","alt":"[\u5410]"},{"url":"120.gif","alt":"[\u7B11]"},{"url":"121.gif","alt":"[\u5FEB\u4E50]"},{"url":"122.gif","alt":"[\u5947]"},{"url":"123.gif","alt":"[\u50B2]"}],[{"url":"124.gif","alt":"[\u997F]"},{"url":"125.gif","alt":"[\u7D2F]"},{"url":"126.gif","alt":"[\u5413]"},{"url":"127.gif","alt":"[\u6C57]"},{"url":"128.gif","alt":"[\u9AD8\u5174]"},{"url":"129.gif","alt":"[\u95F2]"},{"url":"130.gif","alt":"[\u52AA\u529B]"},{"url":"131.gif","alt":"[\u9A82]"},{"url":"132.gif","alt":"[\u7591\u95EE]"},{"url":"133.gif","alt":"[\u79D8\u5BC6]"},{"url":"134.gif","alt":"[\u4E71]"},{"url":"135.gif","alt":"[\u75AF]"},{"url":"136.gif","alt":"[\u54C0]"},{"url":"137.gif","alt":"[\u9B3C]"},{"url":"138.gif","alt":"[\u6253\u51FB]"},{"url":"139.gif","alt":"[bye]"},{"url":"140.gif","alt":"[\u6C57]"},{"url":"141.gif","alt":"[\u62A0]"},{"url":"142.gif","alt":"[\u9F13\u638C]"},{"url":"143.gif","alt":"[\u7CDF\u7CD5]"},{"url":"144.gif","alt":"[\u6076\u641E]"},{"url":"145.gif","alt":"[\u4EC0\u4E48]"},{"url":"146.gif","alt":"[\u4EC0\u4E48]"},{"url":"147.gif","alt":"[\u7D2F]"}],[{"url":"148.gif","alt":"[\u770B]"},{"url":"149.gif","alt":"[\u96BE\u8FC7]"},{"url":"150.gif","alt":"[\u96BE\u8FC7]"},{"url":"151.gif","alt":"[\u574F]"},{"url":"152.gif","alt":"[\u4EB2]"},{"url":"153.gif","alt":"[\u5413]"},{"url":"154.gif","alt":"[\u53EF\u601C]"},{"url":"155.gif","alt":"[\u5200]"},{"url":"156.gif","alt":"[\u6C34\u679C]"},{"url":"157.gif","alt":"[\u9152]"},{"url":"158.gif","alt":"[\u7BEE\u7403]"},{"url":"159.gif","alt":"[\u4E52\u4E53]"},{"url":"160.gif","alt":"[\u5496\u5561]"},{"url":"161.gif","alt":"[\u7F8E\u98DF]"},{"url":"162.gif","alt":"[\u52A8\u7269]"},{"url":"163.gif","alt":"[\u9C9C\u82B1]"},{"url":"164.gif","alt":"[\u67AF]"},{"url":"165.gif","alt":"[\u5507]"},{"url":"166.gif","alt":"[\u7231]"},{"url":"167.gif","alt":"[\u5206\u624B]"},{"url":"168.gif","alt":"[\u751F\u65E5]"},{"url":"169.gif","alt":"[\u7535]"},{"url":"170.gif","alt":"[\u70B8\u5F39]"},{"url":"171.gif","alt":"[\u5200\u5B50]"}],[{"url":"172.gif","alt":"[\u8DB3\u7403]"},{"url":"173.gif","alt":"[\u74E2\u866B]"},{"url":"174.gif","alt":"[\u7FD4]"},{"url":"175.gif","alt":"[\u6708\u4EAE]"},{"url":"176.gif","alt":"[\u592A\u9633]"},{"url":"177.gif","alt":"[\u793C\u7269]"},{"url":"178.gif","alt":"[\u62B1\u62B1]"},{"url":"179.gif","alt":"[\u62C7\u6307]"},{"url":"180.gif","alt":"[\u8D2C\u4F4E]"},{"url":"181.gif","alt":"[\u63E1\u624B]"},{"url":"182.gif","alt":"[\u526A\u5200\u624B]"},{"url":"183.gif","alt":"[\u62B1\u62F3]"},{"url":"184.gif","alt":"[\u52FE\u5F15]"},{"url":"185.gif","alt":"[\u62F3\u5934]"},{"url":"186.gif","alt":"[\u5C0F\u62C7\u6307]"},{"url":"187.gif","alt":"[\u62C7\u6307\u516B]"},{"url":"188.gif","alt":"[\u98DF\u6307]"},{"url":"189.gif","alt":"[ok]"},{"url":"190.gif","alt":"[\u60C5\u4FA3]"},{"url":"191.gif","alt":"[\u7231\u5FC3]"},{"url":"192.gif","alt":"[\u8E66\u54D2]"},{"url":"193.gif","alt":"[\u98A4\u6296]"},{"url":"194.gif","alt":"[\u6004\u6C14]"},{"url":"195.gif","alt":"[\u8DF3\u821E]"}],[{"url":"196.gif","alt":"[\u53D1\u5446]"},{"url":"197.gif","alt":"[\u80CC\u7740]"},{"url":"198.gif","alt":"[\u4F38\u624B]"},{"url":"199.gif","alt":"[\u800D\u5E05]"},{"url":"200.png","alt":"[\u5FAE\u7B11]"},{"url":"201.png","alt":"[\u751F\u75C5]"},{"url":"202.png","alt":"[\u54ED\u6CE3]"},{"url":"203.png","alt":"[\u5410\u820C]"},{"url":"204.png","alt":"[\u8FF7\u7CCA]"},{"url":"205.png","alt":"[\u77AA\u773C]"},{"url":"206.png","alt":"[\u6050\u6016]"},{"url":"207.png","alt":"[\u5FE7\u6101]"},{"url":"208.png","alt":"[\u7728\u7709]"},{"url":"209.png","alt":"[\u95ED\u773C]"},{"url":"210.png","alt":"[\u9119\u89C6]"},{"url":"211.png","alt":"[\u9634\u6697]"},{"url":"212.png","alt":"[\u5C0F\u9B3C]"},{"url":"213.png","alt":"[\u793C\u7269]"},{"url":"214.png","alt":"[\u62DC\u4F5B]"},{"url":"215.png","alt":"[\u529B\u91CF]"},{"url":"216.png","alt":"[\u91D1\u94B1]"},{"url":"217.png","alt":"[\u86CB\u7CD5]"},{"url":"218.png","alt":"[\u5F69\u5E26]"},{"url":"219.png","alt":"[\u793C\u7269]"}]]';
            
            $array = json_decode($json,true);
            $origin = array();
            foreach ($array as $key => $value) {
                $origin = array_merge($origin,$value);
            }
            $origin = zhanmishu_app_api::auto_charset_change($origin,'UTF-8',CHARSET);
            foreach ($origin as $key => $value) {
                $emoji_list[] =array(
                    'order' => $key,
                    'alt' => $value['alt'],
                    'icon' => $value['url'],
                );
            }
            $this->writeToCache('emoji',$emoji_list);
        }
    }
    public function getThreadInfo($tid = '') {
        global $_G;
        $_G['siteurl'] = str_replace('source/plugin/'.self::cacheKey().'/','',$_G['siteurl']);
        require_once libfile('function/post');
        require_once libfile('function/attachment');
        $thread = C::t("forum_thread")->fetch($tid);
        $thread['post'] = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
        $thread['preview'] = messagecutstr($thread['post']['message'], 200);
        $attachments = C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid']);
        $attachs = $imgattachs = array();
        $thread['is_video'] = 0;
        foreach(C::t('forum_attachment')->fetch_all_by_id('pid', $thread['post']['pid'], 'aid') as $attach) {
                $attach = array_merge($attach, $attachments[$attach['aid']]);
                $attach['filenametitle'] = $attach['filename'];
                $attach['ext'] = fileext($attach['filename']);
                getattach_row($attach, $attachs, $imgattachs);
                foreach ($attachs['used'] as $attach) {
                    if ($attach['ext'] == 'mp4') {
                        $thread['is_video'] = 1;
                    }
                    if (!$attach['price'] && !$attach['readperm'] && $thread['is_video']) {
                        // $thread['video'] = $attach;
                        $thread['video']['aid'] = $attach['aid'];
                        $thread['video']['video_url'] = $_G['siteurl'].'forum.php?mod=attachment&aid='.packaids($attach);
                    }else{
                        $thread['video'] = array();
                    }
                }
        }
        foreach ($imgattachs['used'] as $imageKey => $imageValue) {
            if ($imageValue['remote'] < 1) {
                $imgattachs['used'][$imageKey]['attachment'] = getforumimg($imageValue['aid'], 0, 360, 261);
                $imgattachs['used'][$imageKey]['url'] = $_G['siteurl'];
            }else{
                $imgattachs['used'][$imageKey]['attachment'] .= $this->config['remoteImageAdd'];
                
            }
        }

        if (count($imgattachs['used']) > 3) {
            $imgattachs['used'] = array_slice($imgattachs['used'], 0,3);
            $thread['attachments'] = array_values($imgattachs['used']);
        }else if (count($imgattachs['used'])) {
            $thread['attachments'] = array_values($imgattachs['used']);
        }else{
            $thread['attachments'] = array();
        }
        unset($thread['post']['message']);
        // 显示样式
        
        switch (count($imgattachs['used'])) {
            case 0:
                if (mb_strlen($thread['preview']) < 15) {
                    $thread['list_style'] = '7';
                }else{
                    $thread['list_style'] = '6';
                }
                break;
            case 1:
                if (mb_strlen($thread['preview']) < 15) {
                    $thread['list_style'] = '1';
                }else{
                    $thread['list_style'] = '2';
                }
                break;
            case 2:
                if (mb_strlen($thread['preview']) < 15) {
                    $thread['list_style'] = '1';
                }else{
                    $thread['list_style'] = '2';
                }
                break;
            default:
                $thread['list_style'] = '3';
                break;
        }
        return $thread;
        
    }
    public static function authcode($string = '', $operation = 'ENCODE', $expiry = 0) {
        global $_G;
        return authcode($string , $operation, $_G['config']['security']['authkey'], $expiry);
    }
    public static function token_encode($uid = '',$openid = '',$unionid = '',$version = '1',$expire_in='7200'){
        global $_G;
        $uid = $uid ? $uid : $_G['uid'];
        // if (!$uid) {
        //  return '';
        // }
        
        $data = array();
        $data['uid'] = $uid;
        if ($openid) {
            $data['openid'] = $openid;
        }
        if ($unionid) {
            $data['unionid'] = $unionid;
        }
        $data['version'] = $version;
        return self::authcode(json_encode($data), 'ENCODE' , $expire_in);
    }
    public static function token_decode($token = ''){
        if (!$token) {
            return false;
        }
        global $_G;
        $jsonToken = self::authcode($token,'DECODE');
        return json_decode($jsonToken,true);
    }

}