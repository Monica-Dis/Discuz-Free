<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class zhanmishu_base
{
	public $config = array();
	public static $cacheKey = '';
	public function writeToCache($key, $data)
	{
		if (!$key) {
			return NULL;
		}
		global $_G;
		$cacheData = $this->GetFromCache();
		$cacheData[$key] = $data;
		save_syscache($this->cacheKey(), $cacheData);
	}
	public function GetFromCache($key = '')
	{
		global $_G;
		loadcache($this->cacheKey());
		if ($key) {
			return $_G['cache'][$this->cacheKey()][$key];
		}
		return $_G['cache'][$this->cacheKey()];
	}
	public function clearCache($key = '')
	{
		if ($key) {
			$this->writeToCache($key, '');
		} else {
			C::t('common_syscache')->delete($this->cacheKey());
		}
	}
	public function zmsCheck()
	{
		return false;
	}
	public function __construct()
	{
		if ($this->cacheKey()) {
			global $_G;
			loadcache('plugin');
			$config = $_G['cache']['plugin'][$this->cacheKey()];
			$this->config = $config;
		}
		$this->afterCreate();
	}
	public function afterCreate()
	{
	}
	public static function is_weixin()
	{
		if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
			return true;
		}
		return false;
	}
	public static function auto_charset_change($data, $charset = '', $toCharset = 'UTF-8')
	{
		$charset = $charset ? $charset : CHARSET;
		if (!is_array($data)) {
			return diconv($data, $charset, $toCharset);
		}
		$tmp = array();
		foreach ($data as $key => $value) {
			$nkey = diconv($key, $charset, $toCharset);
			$nvalue = self::auto_charset_change($value, $charset, $toCharset);
			$tmp[$nkey] = $nvalue;
		}
		return $tmp;
	}
	public static function upload($uploadFile = array(), $savedir = '', $thumb = false, $width = '220', $height = '220', $iskeybili = '1')
	{
		$savedir = $savedir ? $savedir : 'zhanmishu/';
		$filename = $uploadFile['name'];
		$ext = fileext($filename);
		if (in_array($ext, array('php', 'exe', 'sh', 'bash'))) {
			exit('upload_ext_limit');
		}
		require_once 'source/class/discuz/discuz_upload.php';
		$upload = new discuz_upload();
		if ($r1 = $upload->init($uploadFile, 'common') && ($r2 = $upload->save(1))) {
			$pic = $_G['setting']['attachurl'] . 'common/' . $upload->attach['attachment'];
		}
		$ext = addslashes(strtolower(substr(strrchr($uploadFile['name'], '.'), 1, 10)));
		$img_path = $savedir . substr(str_shuffle('abcdefghijklmnopqrstuvwxyz'), 0, 8) . rand(10000, 99999) . '.' . $ext;
		if (!is_dir(getglobal('setting/attachdir') . $savedir)) {
			@mkdir(getglobal('setting/attachdir') . $savedir, 511);
			@touch(getglobal('setting/attachdir') . $savedir . '/index.html');
		}
		if ($thumb) {
			require_once 'source/class/class_image.php';
			$thumb = new image();
			$thumb->THumb($upload->attach['target'], $img_path, $width, $height, $iskeybili);
		} else {
			@copy(getglobal('setting/attachdir') . $pic, getglobal('setting/attachdir') . $img_path);
		}
		@unlink(getglobal('setting/attachdir') . $upload->attach['attachment']);
		return $img_path;
	}
	public static function darray_column($array = array(), $column_key = '', $index_key = null)
	{
		if (function_exists('array_column')) {
			return array_column($array, $column_key, $index_key);
		}
		$result = array();
		foreach ($array as $arr) {
			if (is_array($arr)) {
				if (is_null($column_key)) {
					$value = $arr;
				} else {
					$value = $arr[$column_key];
				}
				if (!is_null($index_key)) {
					$key = $arr[$index_key];
					$result[$key] = $value;
				} else {
					$result[] = $value;
				}
			}
		}
		return $result;
	}
	public static function uploadimg($savedir = '', $thumb = false, $width = '220', $height = '220', $iskeybili = '1')
	{
		$savedir = $savedir ? $savedir : 'zhanmishu/';
		$images = array();
		foreach ($_FILES as $upfile_name => $value) {
			if (is_array($_FILES[$upfile_name]['error'])) {
				foreach ($_FILES[$upfile_name]['error'] as $kk => $errorCode) {
					if ($errorCode == 0) {
						$fileUpload = array();
						$fileUpload['name'] = $_FILES[$upfile_name]['name'][$kk];
						$fileUpload['type'] = $_FILES[$upfile_name]['type'][$kk];
						$fileUpload['tmp_name'] = $_FILES[$upfile_name]['tmp_name'][$kk];
						$fileUpload['error'] = $_FILES[$upfile_name]['error'][$kk];
						$fileUpload['size'] = $_FILES[$upfile_name]['size'][$kk];
						$img_path = self::upload($fileUpload, $savedir, $thumb, $width, $height, $iskeybili);
						$images[$kk] = 'data/attachment/' . $img_path;
					}
				}
			}
			if ($_FILES[$upfile_name]['error'] == 0) {
				$img_path = self::upload($_FILES[$upfile_name], $savedir, $thumb, $width, $height, $iskeybili);
				$images[$upfile_name] = 'data/attachment/' . $img_path;
			}
		}
		return $images;
	}
	public function get_rand_str($n = 8)
	{
		$strs = 'QWERTYUIOPASDFGHJKLZXCVBNM1234567890qwertyuiopasdfghjklzxcvbnm';
		return substr(str_shuffle($strs), 0, $n);
	}
	public static function encode($data = array())
	{
		return json_encode(self::auto_charset_change($data), JSON_ERROR_UTF8);
	}
	public static function resultToJson($data, $code = '0', $msg = 'success')
	{
		$outapi = array();
		$outapi['code'] = $code;
		$outapi['msg'] = $msg;
		$outapi['data'] = $data;
		return self::encode($outapi);
	}
	public function auto_to_url($str = '')
	{
		if (!$str) {
			return '';
		}
		global $_G;
		if ($this->check_url($str) != 'url' && defined('IN_MOBILE_API')) {
			return str_replace('source/plugin/' . $this->cacheKey() . '/', '', $_G['siteurl']) . $str;
		}
		if ($this->check_url($str) != 'url' && !defined('IN_MOBILE_API')) {
			return $_G['siteurl'] . $str;
		}
		return $str;
	}
	public function check_url($str)
	{
		if (preg_match('#(http|https)://(.*\\.)?.*\\..*#i', $str)) {
			return 'url';
		}
		if (strlen($str) >= 1) {
			return 'str';
		}
		return false;
	}
	public function deleteInstallFile()
	{
		global $_G;
		if ($_G['siteurl'] == 'http://plugin/') {
			return NULL;
		}
		$pluginId = $this->cacheKey();
		@unlink(DISCUZ_ROOT . 'source/plugin/' . $pluginId . '/discuz_plugin_' . $pluginId . '.xml');
		@unlink(DISCUZ_ROOT . 'source/plugin/' . $pluginId . '/discuz_plugin_' . $pluginId . '_SC_GBK.xml');
		@unlink(DISCUZ_ROOT . 'source/plugin/' . $pluginId . '/discuz_plugin_' . $pluginId . '_SC_UTF8.xml');
		@unlink(DISCUZ_ROOT . 'source/plugin/' . $pluginId . '/discuz_plugin_' . $pluginId . '_TC_BIG5.xml');
		@unlink(DISCUZ_ROOT . 'source/plugin/' . $pluginId . '/discuz_plugin_' . $pluginId . '_TC_UTF8.xml');
	}
	public function install()
	{
	}
	public function upgrade()
	{
	}
	public function check()
	{
	}
	public function disable()
	{
	}
	public function enable()
	{
	}
}