<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
} 
/**
 * 
 */
class zhanmishu_app_admin_controller extends zhanmishu_app_controller
{
    public function uploadimg(){
        $images = zhanmishu_app::uploadimg();
        $return = array();
        if (empty($images)) {
           
            $return['code'] = '-1';
            $return['msg'] = 'upload_file_error';
            self::resultToJsonOutPut($return);
        }
        $return['code'] = '1';
        $return['msg'] = 'success';
        $return['images'] = $images;
        self::resultToJsonOutPut($return);
    }
}