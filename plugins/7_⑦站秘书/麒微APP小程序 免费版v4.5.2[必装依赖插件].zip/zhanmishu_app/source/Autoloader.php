<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      (C) dism-Taobao-com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class zhanmishu_app_Autoloader{
  
  /**
     * 类库自动加载，写死路径，确保不加载其他文件。
     * @param string $class 对象类名
     * @return void
     */
    public static function autoload($class) {
        $name = $class;
        if(false !== strpos($name,'\\')){
          $name = strstr($class, '\\', true);
        }

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_app/source/class/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_app/source/model/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
    }
}

if (version_compare(phpversion(),'5.3.0','>=')) {
    spl_autoload_register('zhanmishu_app_Autoloader::autoload',false,true);
}else{
    zhanmishu_app_Autoloader::autoload("zhanmishu_app");
    zhanmishu_app_Autoloader::autoload("zhanmishu_app_api");
  
}




?>