const LazyLoadImage = () => {
  const loadImg = (it) => {
    const testImage = document.createElement('img')
    testImage.src = it.getAttribute('data-src')
    testImage.addEventListener('load', () => {
      it.src = testImage.src
      it.style.backgroundImage = 'none'
      it.style.backgroundColor = 'transparent'
    })
    it.removeAttribute('data-src')
  }

  if (!('IntersectionObserver' in window)) {
    document.querySelectorAll('img').forEach((data) => {
      if (data.getAttribute('data-src')) {
        loadImg(data)
      }
    })
    return false
  }

  if (window.imageIntersectionObserver) {
    window.imageIntersectionObserver.disconnect()
    document.querySelectorAll('img').forEach(function (data) {
      window.imageIntersectionObserver.observe(data)
    })
  } else {
    window.imageIntersectionObserver = new IntersectionObserver((entries) => {
      entries.forEach((entrie) => {
        if ((typeof entrie.isIntersecting === 'undefined'
          ? entrie.intersectionRatio !== 0
          : entrie.isIntersecting) && entrie.target.getAttribute('data-src')) {
          loadImg(entrie.target)
        }
      })
    })
    document.querySelectorAll('img').forEach(function (data) {
      window.imageIntersectionObserver.observe(data)
    })
  }
}

var vditorImages = '';

const vditor = new Vditor('vditor', {
  cache: false,
  counter: 100,
  after: initVditor,
  height: 490,
  sanitize: true,
  cache: false,
  outline: uploadOutline,
  mode: uploadViewType,
  editorName: 'vditor',
  tab: '  ',
  input: function(){
      if (document.getElementById('markdownEditorBox').style.display != 'block') {
        return;
      }
      var theform = document.getElementById('postform');
      //在这里运行代码
      var mdContent = vditor.getValue();
      if(mdContent.length < 2){
        document.getElementById('postform').message.value = '';
        return
      }

      theform.message.value = mdContent;
      theform.wysiwyg.value = false;
      wysiwyg = false;
      editorTextarea = '[md]' + mdContent + '[/md]'

  },
  placeholder: '本编辑器是Markdown编辑器，说用方法可以点击右侧查看说明，也可以点击下方切换到老富文本编辑器使用更多功能。',
  upload: {
    accept: 'image/*,.pdf',
    token: 'test',
    url: '/api/upload/editor',
    linkToImgUrl: '/api/upload/fetch',
    filename (name) {
      // ? \ / : | < > * [ ] white to -
      return name.replace(/\?|\\|\/|:|\||<|>|\*|\[|\]|\s+/g, '-')
    },
    handler (files) {
      if(vditor.getCursorPosition().left < 0 && vditor.getCursorPosition().top < 0){
        vditor.focus()
      }
      for (var i = files.length - 1; i >= 0; i--) {
        var file = files[files.length - i - 1];
          var formData = new FormData();
          console.log(file)
          //接口接收参数 键值形式 添加到formData中
          // formData.append("mod","forumUpload");
          // formData.append("Filedata",'file');
          formData.append("Filedata",file);
          formData.append("type",'image');
          formData.append("simple",'2');
          formData.append("hash",uploadHash);
          formData.append("uid",uploadUid);
          jQuery.ajax({
              url:'misc.php?mod=swfupload&action=swfupload&operation=upload',//url地址
              type:'post',
              data: formData,
              contentType: false,
              processData: false,
              success:function(res){
                console.log(file)
                  var image = res.split("|");
                  var imageName = image[6].replace(/(\(|\)|\[|\]|\"|\'|\{|\}|\s)/g, "")
                  console.log(imageName, 'imageName')
                  vditorImages = vditorImages + '|'+image[3]
                  if(!attachurl) {
                    vditor.insertValue('!['+imageName+'](data/attachment/forum/' +image[5]+ '?imageMogr2/auto-orient/strip%7CimageView2/2/w/300 "'+image[6]+'")')
                  }else {
                    vditor.insertValue('!['+imageName+']('+attachurl+'/forum/' +image[5]+ '?imageMogr2/auto-orient/strip%7CimageView2/2/w/300 "'+image[6]+'")')
                  }
                  
                  ajaxget('forum.php?mod=ajax&action=imagelist&aids='+ vditorImages + '&fid='+markFid+'&inajax=1&ajaxtarget=imgattachlist', 'imgattachlist', '')

              }
          })
        //return 'handler'
      }
      
    },
  },
  preview: {
    hljs:{
      style:'rrt'
    },
    show: true,
    sanitize: true,
    markdown: {
      sanitize: true
    },
    math: {
        inlineDigit: true,
        macros:{
          actuarialangle: ['{\\mkern1mu\\overline\{#1\\,\}\\kern-3mu\\lower-1mu\\small|}',1],
          angl: ['{\\actuarialangle\{#1\\mkern1mu\}}',1],
          angln: '{\\angl n}',
          anglk: '{\\angl k}',
          anglr: '{\\angl r}',
          term: ['{\\overset\{1\}\{#1\}:\\angl\{#2\}}',2],
          termxn: '{\\term\{x\}\{n\}}',
          pureendow: ['{#1:\\overset\{1\}\{\\angl\{#2\}\}}',2],
          pureendowxn: '{\\pureendow\{x\}\{n\}}',
          endow: ['{#1:\\angl\{#2\}}',2],
          endowxn: '{\\endow\{x\}\{n\}}',
          joint: ['{\\overline\{#1\}}',1],
          actsymb: ['{\\sideset\{_\{#1\\mkern3mu\}^\{#2\\mkern3mu\}\}\{^\{#4\}_\{#5\}}\{#3\}}',5],
          Ax: ['{\\actsymb\{#1\}\{#2\}\{A\}\{#3\}\{#4\}}',4],
          Axz: ['{\\actsymb\{#1\}\{#2\}\{\\bar\{A\}\}\{#3\}\{#4\}}',4],
          Axzz: ['{\\actsymb\{#1\}\{#2\}\{\\ddot\{A\}\}\{#3\}\{#4\}}',4],
          ax: ['{\\actsymb\{#1\}\{#2\}\{a\}\{#3\}\{#4\}}',4],
          axz: ['{\\actsymb\{#1\}\{#2\}\{\\bar\{a\}\}\{#3\}\{#4\}}',4],
          axzz: ['{\\actsymb\{#1\}\{#2\}\{\\ddot\{a\}\}\{#3\}\{#4\}}',4],
          Ex: ['{\\actsymb\{#1\}\{\}\{E\}\{\}\{#2\}}',2],
          px: ['{\\actsymb\{#1\}\{\}\{p\}\{\}\{#2\}}',2],
          qx: ['{\\actsymb\{#1\}\{\}\{q\}\{\}\{#2\}}',2],
          sx: ['{\\actsymb\{\}\{\}\{s\}\{\}\{#1\}}',1],
          sxz: ['{\\actsymb\{\}\{\}\{\\bar\{s\}\}\{\}\{#1\}}',1],
          sxzz: ['{\\actsymb\{\}\{\}\{\\ddot\{s\}\}\{\}\{#1\}}',1],
          Vx: ['{\\actsymb\{#1\}\{\}\{V\}\{\}\{#2\}}',2],
        },
      engine: 'MathJax'
    },
    parse: () => {
      LazyLoadImage()
    },
  },
})