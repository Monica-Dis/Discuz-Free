/// <reference types="./types" />
export declare const i18n: II18n;
