/// <reference types="./types" />
export declare const getElement: (vditor: IVditor) => HTMLPreElement;
