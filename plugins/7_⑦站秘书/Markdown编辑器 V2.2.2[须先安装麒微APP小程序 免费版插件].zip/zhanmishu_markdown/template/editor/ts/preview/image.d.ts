/// <reference types="./types" />
export declare const previewImage: (oldImgElement: HTMLImageElement, lang?: keyof II18n, theme?: string) => void;
