export declare class Br {
    element: HTMLElement;
    constructor();
}
