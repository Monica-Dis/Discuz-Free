/// <reference types="./types" />
import { MenuItem } from "./MenuItem";
export declare class Redo extends MenuItem {
    constructor(vditor: IVditor, menuItem: IMenuItem);
}
