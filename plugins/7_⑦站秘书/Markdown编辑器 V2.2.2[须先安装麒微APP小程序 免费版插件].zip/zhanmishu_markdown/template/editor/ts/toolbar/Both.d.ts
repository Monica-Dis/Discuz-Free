/// <reference types="./types" />
import { MenuItem } from "./MenuItem";
export declare class Both extends MenuItem {
    constructor(vditor: IVditor, menuItem: IMenuItem);
}
