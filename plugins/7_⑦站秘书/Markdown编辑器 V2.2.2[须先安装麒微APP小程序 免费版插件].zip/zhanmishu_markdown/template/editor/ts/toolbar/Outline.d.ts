/// <reference types="./types" />
import { MenuItem } from "./MenuItem";
export declare class Outline extends MenuItem {
    constructor(vditor: IVditor, menuItem: IMenuItem);
}
