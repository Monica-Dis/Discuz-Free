/// <reference types="./types" />
export declare const expandMarker: (range: Range, vditor: IVditor) => void;
