/// <reference types="./types" />
export declare const processKeydown: (vditor: IVditor, event: KeyboardEvent) => boolean;
