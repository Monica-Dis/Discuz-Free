/// <reference types="./types" />
export declare class DevTools {
    element: HTMLDivElement;
    private ASTChart;
    constructor();
    renderEchart(vditor: IVditor): void;
}
