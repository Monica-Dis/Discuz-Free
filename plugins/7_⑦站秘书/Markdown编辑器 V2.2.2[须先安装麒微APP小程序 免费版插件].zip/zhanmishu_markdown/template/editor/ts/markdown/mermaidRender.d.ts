export declare const mermaidRender: (element: HTMLElement, cdn: string, theme: string) => void;
