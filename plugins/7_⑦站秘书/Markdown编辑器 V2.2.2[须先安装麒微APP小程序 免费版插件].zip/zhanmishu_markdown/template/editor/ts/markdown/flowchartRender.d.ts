export declare const flowchartRender: (element: HTMLElement, cdn?: string) => void;
