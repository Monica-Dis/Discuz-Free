/// <reference types="./types" />
export declare const setLute: (options: ILuteOptions) => Lute;
