/// <reference types="./types" />
export declare const highlightRender: (hljsOption?: IHljs, element?: HTMLElement | Document, cdn?: string) => void;
