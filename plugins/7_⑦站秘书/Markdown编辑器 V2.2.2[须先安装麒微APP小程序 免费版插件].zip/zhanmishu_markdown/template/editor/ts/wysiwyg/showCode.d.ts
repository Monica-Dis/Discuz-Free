/// <reference types="./types" />
export declare const showCode: (previewElement: HTMLElement, vditor: IVditor, first?: boolean) => void;
