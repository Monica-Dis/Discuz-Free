/// <reference types="./types" />
export declare const input: (vditor: IVditor, range: Range, event?: InputEvent) => void;
