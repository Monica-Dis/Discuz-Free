export declare const addStyle: (url: string, id: string) => void;
