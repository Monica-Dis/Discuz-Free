export declare const getSelectText: (editor: HTMLElement, range?: Range) => string;
