export declare const log: (method: string, content: string, type: string, print: boolean) => void;
