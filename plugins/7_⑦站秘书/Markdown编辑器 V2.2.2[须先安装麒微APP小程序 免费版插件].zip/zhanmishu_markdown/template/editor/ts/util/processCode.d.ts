/// <reference types="./types" />
export declare const processPasteCode: (html: string, text: string, type?: string) => string | false;
export declare const processCodeRender: (previewPanel: HTMLElement, vditor: IVditor) => void;
