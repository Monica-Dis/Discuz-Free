export declare const setCodeTheme: (codeTheme: string, cdn?: string) => void;
