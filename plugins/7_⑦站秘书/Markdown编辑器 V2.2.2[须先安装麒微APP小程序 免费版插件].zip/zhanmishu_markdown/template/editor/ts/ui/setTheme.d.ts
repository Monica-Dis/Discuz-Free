/// <reference types="./types" />
export declare const setTheme: (vditor: IVditor) => void;
