<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!class_exists('zhanmishu_markdown_controller',false)) {
    C::import('zhanmishu_markdown_controller','plugin/zhanmishu_markdown/source/controller');
}
// if (!class_exists('XssHtml',false)) {
//     C::import('XssHtml','plugin/zhanmishu_markdown/source/class');
// }



/**
 * 本程序功能基类
 * 
 */
class plugin_zhanmishu_markdown_base
{
    public function parseHander(){
        return new zhanmishu_markdown_controller();
    }
    public static function isIE() {
        $isIE = strpos($_SERVER['HTTP_USER_AGENT'],"Triden");
        return $isIE;  
    }

    public function cleanXss($html = '') {
        if(!function_exists('html2bbcode')) {
            require_once libfile('function/editor');
        }
        $html = zhanmishu_app::auto_charset_change($html, 'utf-8', CHARSET);

        return dhtmlspecialchars($html);
    }
 
    public function parse_markdown($string = '', $isCleanXss = true) {
        if(!$isCleanXss) {
            return $string = preg_replace("/\[md\](.*?)\[\/md\]/is",
                '$1',
            $string);
        }
        return $string = preg_replace("/\[md\](.*?)\[\/md\]/is",
            '$1',
        $string, -1);
    }
}

/**
 * PC版本嵌入点
 */
class plugin_zhanmishu_markdown extends plugin_zhanmishu_markdown_base {

}

/**
 * PC版本嵌入点
 */
class plugin_zhanmishu_markdown_forum extends plugin_zhanmishu_markdown {
    // function post_attribute_extra(){
    //     return '<label id="extra_filebuy_b" onclick="showExtra(\'extra_filebuy\')"><span id="extra_filebuy_chk">'.lang('plugin/zhanmishu_markdown','pay_buy').'</span></label>';
    // }
    


    function viewthread_postbottom_output(){
        global $postlist;
        global $_G;

        include libfile('function/editor');

        foreach($postlist as $k=>$post){
            // echo $post['message'];die;
            $pattern= "/\[md\](.*)\[\/md\]/is";
            $isMd = preg_match($pattern, $post['message'] , $MarkdownReturn);
            if ($isMd) {
                $message = C::t('forum_post')->fetch('tid:'.$post['tid'], $post['pid'], true);
                    
                $mdMessage = self::parse_markdown($message['message']);

                // 对引用的支持
                $mdMessage = preg_replace("/\[i=s\](.*?)\[\/i\]/is",
                        '$1'. "\r\n",
                    $mdMessage);
                
                

                $mdMessage = preg_replace("/\[audio.*?\](.*?)\[\/audio\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[url.*?\](.*?)\[\/url\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[video.*?\](.*?)\[\/video\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[flash.*?\](.*?)\[\/flash\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[media.*?\](.*?)\[\/media\]/", "$1", $mdMessage);

                if (IS_ROBOT || self::isIE() || $this->parseHander()->config['markParse'] == '1') {
                    $replace = '<div class="vditor-reset">'.zhanmishu_markdown_controller::markdownParse($mdMessage).'<div>';
                }else{
                    $replace = '<textarea style="display:none;" class="markdownContent vditor-reset" cols="30" rows="10">'.$mdMessage.'</textarea>';
                }
                $post['message'] = $replace;
                $remoteHost = $_G['setting']['ftp']['attachurl'];
                if(substr($remoteHost, -1) == '/'){
                    $remoteHost = substr($remoteHost, 0, -1);
                }
                if (!empty($post['attachments'])) {
                    foreach ($post['attachments'] as $attach) {
                        if (strpos($post['message'], $attach['attachment'])) {
                            
                            if($attach['remote'] == '1'){
                                $post['message'] = str_replace(
                                    'data/attachment/forum/'.$attach['attachment'],
                                    $remoteHost.'/forum/'.$attach['attachment'],
                                    $post['message']
                                );
                                
                                // echo $_G['setting']['attachdir'].'<br>';
                                // echo $_G['setting']['attachurl'].'<br>';
                                // echo $_G['setting']['ftp']['attachurl'].'<br>';
                                // echo $attach['attachment'].'<br>';
                            }
                            unset($post['attachments'][$attach['aid']]);
                        }
                    }
                }

                $postlist[$k] = $post;
            }
            
        }
        return;
    }
    function viewthread_bottom(){
        include template('zhanmishu_markdown:markdown');
        return $markdown;
    }
    function post_attribute_extra_body(){
        
    }
    function post_middle() {
        if ($_GET['editorTypeChecked']) {
            $pattern= "/\[md\](.*)\[\/md\]/is";
            $isMd = preg_match($pattern, $_GET['message'] , $MarkdownReturn);
            if(!$isMd) {
                $_GET['message'] = '[md]' . $_GET['message'] .'[/md]';
            }
        }
        

    }
    function post_middle_output(){
        global $_G, $postinfo, $editorid, $editor;
        if (!in_array($_G['groupid'], $this->parseHander()->config['avaiable_groups']) || !in_array($_GET['fid'], $this->parseHander()->config['avaiable_forums'])) {
            return;
        }
        $hash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
        


        $pattern= "/\[md\](.*)\[\/md\]/is";
        $isMd = preg_match($pattern, $postinfo['message'] , $MarkdownReturn);
        $isMarkdown = 0;
        if ((!$postinfo['message'] && $this->parseHander()->config['defaultEditor']) || $isMd) {
            $isMarkdown = 1;
            $message = C::t('forum_post')->fetch('tid:'.$postinfo['tid'], $postinfo['pid'], true);
                
            
            $mdMessage = self::parse_markdown($message['message'], false);
            $mdMessage = preg_replace("/\[i=s\](.*?)\[\/i\]/is",
                        '> '.'$1'. "\r\n",
                    $mdMessage);

            $mdMessage = preg_replace("/\[audio.*?\](.*?)\[\/audio\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[url.*?\](.*?)\[\/url\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[video.*?\](.*?)\[\/video\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[flash.*?\](.*?)\[\/flash\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[media.*?\](.*?)\[\/media\]/", "$1", $mdMessage);

            $postinfo['message'] = $mdMessage;
        }
        if($_G['setting']['ftp']['on'] == '1') {
            $attachurl = $_G['setting']['ftp']['attachurl'];
        }else {
            $attachurl = '';
        }
        include template('zhanmishu_markdown:post_add');
        return $post_add;
    }
}

class plugin_zhanmishu_markdown_group extends plugin_zhanmishu_markdown_forum {
    function post_middle_output(){
        global $_G, $postinfo, $editorid, $editor;

        $hash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
        


        $pattern= "/\[md\](.*)\[\/md\]/is";
        $isMd = preg_match($pattern, $postinfo['message'] , $MarkdownReturn);
        $isMarkdown = 0;
        if ((!$postinfo['message'] && $this->parseHander()->config['defaultEditor']) || $isMd) {
            $isMarkdown = 1;
            $message = C::t('forum_post')->fetch('tid:'.$postinfo['tid'], $postinfo['pid'], true);
                
            
            $mdMessage = self::parse_markdown($message['message'], false);
            $mdMessage = preg_replace("/\[i=s\](.*?)\[\/i\]/is",
                        '> '.'$1'. "\r\n",
                    $mdMessage);

            $mdMessage = preg_replace("/\[audio.*?\](.*?)\[\/audio\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[url.*?\](.*?)\[\/url\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[video.*?\](.*?)\[\/video\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[flash.*?\](.*?)\[\/flash\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[media.*?\](.*?)\[\/media\]/", "$1", $mdMessage);

            $postinfo['message'] = $mdMessage;
        }

        // print_r($_G['setting']['ftp']);
        // die;
        if($_G['setting']['ftp']['on'] == '1') {
            $attachurl = $_G['setting']['ftp']['attachurl'];
        }else {
            $attachurl = '';
        }


        include template('zhanmishu_markdown:post_add');
        return $post_add;
    }
}

/**
 * 手机版本嵌入点
 */
class mobileplugin_zhanmishu_markdown extends plugin_zhanmishu_markdown_base {

}

/**
 * 手机版本嵌入点
 */
class mobileplugin_zhanmishu_markdown_forum extends mobileplugin_zhanmishu_markdown {
    function viewthread_bottom_mobile() {
        include template('zhanmishu_markdown:markdown');
        return $markdown;
    }
    function viewthread_top_mobile(){
        return '<link rel="stylesheet" href="source/plugin/zhanmishu_markdown/template/editor/index.css?20200224">';
    }

    function viewthread_bottom_mobile_output() {
        global $postlist;
        global $_G;
        include libfile('function/editor');
        foreach($postlist as $k=>$post){
            $pattern= "/\[md\](.*)\[\/md\]/is";
            $isMd = preg_match($pattern, $post['message'] , $MarkdownReturn);
            if ($isMd) {
                $message = C::t('forum_post')->fetch('tid:'.$post['tid'], $post['pid'], true);

                $mdMessage = self::parse_markdown($message['message']);
                $mdMessage = preg_replace("/\[i=s\](.*?)\[\/i\]/is",
                        '$1'. "\r\n",
                    $mdMessage);

                $mdMessage = preg_replace("/\[audio.*?\](.*?)\[\/audio\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[url.*?\](.*?)\[\/url\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[video.*?\](.*?)\[\/video\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[flash.*?\](.*?)\[\/flash\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[media.*?\](.*?)\[\/media\]/", "$1", $mdMessage);

                if (IS_ROBOT || self::isIE() || $this->parseHander()->config['markParse'] == '1') {
                    
                    $replace = '<div class="vditor-reset">'.zhanmishu_markdown_controller::markdownParse($mdMessage).'<div>';
                }else{
                    $replace = '<textarea style="display:none;" class="markdownContent vditor-reset" cols="30" rows="10">'.$mdMessage.'</textarea>';
                }
                $post['message'] = $replace;
                $remoteHost = $_G['setting']['ftp']['attachurl'];
                if(substr($remoteHost, -1) == '/'){
                    $remoteHost = substr($remoteHost, 0, -1);
                }
                if (!empty($post['attachments'])) {
                    foreach ($post['attachments'] as $attach) {
                        if (strpos($post['message'], $attach['attachment'])) {
                            
                            if($attach['remote'] == '1'){
                                $post['message'] = str_replace(
                                    'data/attachment/forum/'.$attach['attachment'],
                                    $remoteHost.'/forum/'.$attach['attachment'],
                                    $post['message']
                                );
                            }
                            unset($post['attachments'][$attach['aid']]);
                        }
                    }
                }
                $postlist[$k] = $post;
            }
        }
        return;
    }
}
//From: dis'.'m.tao'.'bao.com
?>