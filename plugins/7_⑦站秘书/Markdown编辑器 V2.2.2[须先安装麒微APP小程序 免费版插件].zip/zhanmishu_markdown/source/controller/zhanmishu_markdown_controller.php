<?php
/**
 *      [HereEdu!] (C)2001-2099 hereEdu Inc
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Author: zhanmishu.com $
 *      qq:87883395 $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!class_exists('zhanmishu_base',false)) {
    C::import('zhanmishu_base','plugin/zhanmishu_app/source/class');
}
if (!class_exists('zhanmishu_app_api',false)) {
    C::import('zhanmishu_app_api','plugin/zhanmishu_app/source/class');
}
if (!class_exists('ParsedownExtra',false)) {
    C::import('ParsedownExtra','plugin/zhanmishu_markdown/source/class');
}
/**
 * 
 */
class zhanmishu_markdown_controller extends zhanmishu_base
{
    public function afterCreate(){
        $this->config['avaiable_groups'] = unserialize($this->config['avaiable_groups']);
        $this->config['avaiable_forums'] = unserialize($this->config['avaiable_forums']);
    }
    public static function markdownParse($text = ''){
        if (!$text) {
            return '';
        }
        $text = self::ParsedownExtra()->text(self::auto_charset_change($text, CHARSET, 'utf-8'));

        return self::auto_charset_change($text, 'utf-8', CHARSET);

    }
    public static function ParsedownExtra(){
        $parse = new ParsedownExtra();
        $parse->setMarkupEscaped(true);
        return $parse ;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description 由于api中，cookie可能丢失无状态，因此根据header中的token防止跨站攻击
     * @DateTime    2019-07-10
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @return      [type]     [验证方法，首先验证formhash，如果有效则直接成功。如果无效，则验证token是否与请求的浏览器参数对应，如一致则OK即可]
     */
    public function _csfr(){
        global $_G;

        // var_dump($_G['uid']);
        // var_dump($_G['config']['security']['authkey']);
        // die;
        //兼容老版本formhash
        if ($_GET['formhash'] == formhash()) {
           return true;
        }else if ($_GET['hash'] == md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])) {
            return true;
        }
        $outapi = array(
            'msg'=>'hash_error',
            'code'=>'-10001',
        );
        self::resultToJsonOutPut($outapi);
    }

    public  function cacheKey(){
        return 'zhanmishu_markdown';
    }

    public function zmsCheck(){
        return false;
    }
    public static function resultToJsonOutPut($data = array(), $msg = '', $code = '' ,$isChangeCharset = true){
        if (!$data['msg'] && $msg) {
            $data['msg'] = $msg;
        }
        if (!$data['code'] && $code) {
            $data['code'] = $code;
        }
        echo zhanmishu_app_api::resultToJson($data,'','',$isChangeCharset);
        exit;
    }
    public static function showMessage($message = '' , $code = '' , $url='') {
        if (defined('IN_MOBILE_API')) {
           return self::resultToJsonOutPut(array(), $message, $code);
        }
        if (defined('IN_ADMINCP')) {
            if ($code > 0) {
                $type = 'success';
            }else{
                $type = 'error';
            }
            cpmsg($message,$url,$type);
        }
        if ($code > 0) {
            $type = 'right';
        }else{
            $type = 'error';
        }
        showmessage($message,$url,array('alert'=>$type));
    }
}