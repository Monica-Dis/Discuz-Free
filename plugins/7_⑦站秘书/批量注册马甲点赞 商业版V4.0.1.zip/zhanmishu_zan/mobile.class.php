<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Support: DisM!Ӧ������ $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
C::import('zhanmishu_register','plugin/zhanmishu_zan/source/class');

class mobileplugin_zhanmishu_zan {
    function common(){
    	global $_G;
    	if (CURSCRIPT == 'forum' &&$_GET['mod'] =='viewthread' && $_GET['tid'] && empty($_POST)) {
			$zan = new zhanmishu_register();
			$zan->zan_fan_views($_GET['tid']);
    	}
    }

}
class mobileplugin_zhanmishu_zan_forum extends mobileplugin_zhanmishu_zan {
    function viewthread_posttop_mobile(){
        global $_G;
        $zan = new zhanmishu_register();
        $zan->zan_fan_views();
    }

}

class mobileplugin_zhanmishu_zan_group extends mobileplugin_zhanmishu_zan {
	function viewthread_posttop_mobile(){
    	global $_G;
		$zan = new zhanmishu_register();
		$zan->zan_fan_views();
   	}

}


?>