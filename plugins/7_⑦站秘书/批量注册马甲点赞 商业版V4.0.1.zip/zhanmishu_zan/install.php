<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Support: DisM!Ӧ������ $
 *      ���²����http://t.cn/Aiux1Jx1 $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
  exit('Access Denied');
}

 $sql = <<<EOF
CREATE TABLE IF NOT EXISTS pre_zhanmishu_zan (
  `zid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (zid),
  KEY uid (uid)
);
EOF;
runquery($sql);

$username = DB::fetch_all("SHOW COLUMNS FROM %t", array('forum_memberrecommend'));
$usernamearray = mysqltoarray($username);
if (!in_array('username', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_forum_memberrecommend` ADD COLUMN `username` varchar(32) NOT NULL DEFAULT '1';
EOF;
    runquery($sql1);
}

$finish = TRUE;


function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
//From: Dism_taobao-com
?>