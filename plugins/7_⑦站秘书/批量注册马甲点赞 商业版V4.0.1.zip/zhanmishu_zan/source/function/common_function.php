<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Support: DisM!Ӧ������ $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */	

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function zms_zan_getconfig(){
	global $_G;
	loadcache('plugin');
	$config = $_G['cache']['plugin']['zhanmishu_zan'];
	$config['tids'] = zms_zanstrtoarray($config['tids']);

	return $config;
}
function zms_zanstrtoarray($str){
	$patterns = "/\d+/";
	preg_match_all($patterns,$str,$arr);
	return $arr[0];
}
//From: Dism_taobao-com
?>