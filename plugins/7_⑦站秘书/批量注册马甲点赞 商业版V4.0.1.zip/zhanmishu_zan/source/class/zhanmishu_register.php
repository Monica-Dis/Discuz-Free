<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Support: DisM!Ӧ������ $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



class zhanmishu_register{
	
	public $config=array();
    private $uurl = 'https://api.douban.com/v2/user/';
	private $murl = 'http://m.maoyan.com/mmdb/comments/movie/';

	public function __construct($config=array(),$code='',$verify='',$cookiehead = '')
	{
		global $_G;
		if (empty($config)) {
			if (!function_exists('zms_zan_getconfig')) {
				include DISCUZ_ROOT.'./source/plugin/zhanmishu_zan/source/function/common_function.php';
			}
			$config = zms_zan_getconfig();
		}
		$this->config = $config;
	}

	public function randapiuid(){
		$id = 5000000;
		return $id + rand(0,150000090);
	}

	public function get_zanlist($start = 0, $limit = 0, $sort = '',$type = '',$field){
		return C::t("#zhanmishu_zan#zhanmishu_zan")->get_zanlist($start, $limit, $sort,$type ,$field);
	}
	public function get_zanlist_fmt($start = 0, $limit = 0, $sort = '',$type = '',$field){
		global $url;
		$zanlist = $this->get_zanlist($start, $limit, $sort,$type ,$field);
		if (empty($zanlist)) {
			return false;
		}
		$url = ADMINSCRIPT.'?action='.$url;
		foreach ($zanlist as $key => $value) {

			$zanlist[$key]['username'] = $this->getusernamebyuid($value['uid']);
			$zanlist[$key]['avatar'] = avatar($value['uid'],'small');
			$zanlist[$key]['act'] = '<a href="'.$url.'&act=zandel&zid='.$value['zid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_zan','delete').'</a>';
		}

		return $zanlist;
	}

	public function getusernamebyuid($uid){
		if (!$uid) {
			# code...
			return false;
		}
		$user = getuserbyuid($uid);
		return $user['username'];
	}

	public function delete_zan($zid){
		if (!$zid) {
			return false;
		}
		$r = C::t("#zhanmishu_zan#zhanmishu_zan")->delete($zid);
		return $r;
	}
	public function cleanuser(){
		C::t("#zhanmishu_zan#zhanmishu_zan")->truncate();
	}

	public function get_zanlist_num($field){
		return C::t("#zhanmishu_zan#zhanmishu_zan")->get_zanlist_num($field);
	}

    public function getdouban_userinfo($uid=0){
        $uid = $uid ? $uid : $this->randapiuid();
        $proxy = $this->config['proxy'] ? trim($this->config['proxy']) : false;

        return self::Curl($this->uurl.$uid.'?apikey=0df993c66c0c636e29ecbb5344252a4a',true,$proxy);
    }

    public function getmaoyan_movie(){
        $url = 'http://m.maoyan.com/ajax/movieOnInfoList?token=';
        $result =  self::Curl($url,true);
        $movieId = array_rand($result['movieIds']);
        return $movieId;
    }

	public  function getmaoyan_userinfo($time = 0){
		$offset = 1;
        $movieId = $this->getmaoyan_movie();
        $url = $this->murl.$movieId.'.json?_v_=yes&offset='.$offset;
        $result =  self::Curl($url,true);
        
        if ($time > 20) {
            return false;
        }
        if ($result['total']) {
            return $result;
        }else {
            return $this->getmaoyan_userinfo(++$time);
        }
	}
	
	public function get_rand_email(){
		$email = 'a'.$this->get_rand_str().date('ymd',TIMESTAMP).$this->config['randemail'];
		return $email;
	}

	public function get_rand_str($n = 8){
		$str = "0123456789abcdefghijklmnopqrstuvwxyz";
		$len = strlen($str)-1;
	    for($i=0 ; $i<$n; $i++){
	        $s .= $str[rand(0,$len)];
	    }
		return $s;		
	}

	public function is_username($username='') {
        loaducenter();
        
        $isAllowRegister = uc_user_checkname($username);
        if($isAllowRegister == 1){
            return true;
        }
        return false;
	}
 
    function dstrlen($str) {
        if(strtolower(CHARSET) != 'utf-8') {
            return strlen($str);
        }
        $count = 0;
        for($i = 0; $i < strlen($str); $i++){
            $value = ord($str[$i]);
            if($value > 127) {
                $count++;
                if($value >= 192 && $value <= 223) $i++;
                elseif($value >= 224 && $value <= 239) $i = $i + 2;
                elseif($value >= 240 && $value <= 247) $i = $i + 3;
                }
                $count++;
        }
        return $count;
    }

    public function format_userinfo($userInfo = array(),$api = 'douban') {
        
        $user = array();
        if ($api == 'douban' || true) {
            if ($userInfo['code'] == '112') {
                exit(lang('plugin/zhanmishu_zan','ip_limit'));
            }
            echo strpos($userInfo['large_avatar'],'user_large');
            if ($this->config['isavatar'] && strpos($userInfo['large_avatar'],'user_large')) {
                echo lang('plugin/zhanmishu_zan','no_avatar_go_next').'<br>';
                return false;
            }
            
            $user['username'] = diconv(daddslashes($userInfo['name']),'UTF-8',CHARSET) ;
            if (!$this->is_username($userInfo['name'] )) {
                echo lang('plugin/zhanmishu_zan','name_error_go_next').'<br>';
                return false;
            }
            $user['email'] = $this->get_rand_email();
            $user['password'] = $this->config['defaultpassword'] ? $this->config['defaultpassword'] : $this->get_rand_str();
            $user['avatar'] = $userInfo['large_avatar'];
        }else if ($api == 'maoyan') {
            $user['username'] = diconv(daddslashes($userInfo['nick']),'UTF-8',CHARSET) ;;
            $user['password'] = $this->config['defaultpassword'] ? $this->config['defaultpassword'] : $this->get_rand_str();
            $user['email'] = $this->get_rand_email();
            $user['avatar'] = $userInfo['avatarurl'];
            
        }

        return $user;
    }

	public function register($regnum = 1){

        if ($this->config['api'] == '1') {
            $user = $this->format_userinfo($this->getdouban_userinfo(),'douban');
            return $this->register_one($user);
        }else if ($this->config['api'] == '2') {
            $users = self::getmaoyan_userinfo();

            $allUsers  = array();
            $allUsers = array_merge($users['cmts'],$users['hcmts']);

            $num = 0;
            foreach ($allUsers as $key => $value) {
                $user = $this->format_userinfo($value,'maoyan');
                if ($num < $regnum) {
                    $regStatus = $this->register_one($user);
                    if ($regStatus) {
                        ++$num;
                    }
                }else{
                    break;
                }
            }
            return $num;
        } 
	}

    public function register_one($user = array()){
        global $_G;
        if (!$user) {
            return false;
        }
        loaducenter();
        $uid = uc_user_register($user['username'], $user['password'], $user['email']);
        if ($uid > 0) {
            $ip=$_G['clientip'];
            $groupid = isset($this->$config['groupid']) && $this->$config['groupid'] ? $this->$config['groupid'] : 10;
            C::t('common_member')->insert($uid, $user['username'], md5(random(10)), $user['email'], $ip, $groupid, null);
            if ($user['avatar']) {
                $this->create_avatar($uid, $user['avatar']);
            }
            C::t("#zhanmishu_zan#zhanmishu_zan")->insert(array('uid'=>$uid));
            return 1;
        }

        return false;
    }

    public function create_avatar($uid, $image) {
        global $_G;
        $uid = abs(intval($uid));
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        $avatar_dir = DISCUZ_ROOT.'./'.$this->config['uc_server'].'/data/avatar/' . $dir1 . '/' . $dir2 . '/' . $dir3 . '/';
        dmkdir($avatar_dir);
        $avatar_size = array('big' => 200, 'middle' => 120, 'small' => 48);
        require_once('source/class/class_image.php');
        $thumb = new image;
        $avatar = array();
        foreach ($avatar_size as $size => $width) {
        	$filename = substr($uid, -2) . "_avatar_$size.jpg";
        	$file  = $avatar_dir.$filename;
        	$tmfile = 'temp/'.$filename;

        	if ($this->config['downtype'] =='2') {
        		$data = file_get_contents($image);
				$source = tempnam($_G['setting']['attachdir'].'./temp/', 'tmpimg_');
				file_put_contents($source, $data);
        	}

			$r = $thumb->THumb($source ? $source : $image,$tmfile,$width,$width,1);
			$avatar[$width] = file_get_contents($_G['setting']['attachdir'].'/'.$tmfile);
			if ($r) {
				@copy($_G['setting']['attachdir'].'/'.$tmfile, $file);
    			@unlink($_G['setting']['attachdir'].'/'.$tmfile);
			}
        }

		$res = $this->_saveAvatarByUcenter($uid, 
	        $this->flashdata_encode($avatar[200]),
	        $this->flashdata_encode($avatar[120]),
	        $this->flashdata_encode($avatar[48])
    	);

    }

    private function flashdata_encode($s) {
        // return bin2hex($s);
        $r = '';
        $l = strlen($s);
        for ($i=0; $i < $l; $i++) { 
            $temp = ord($s[$i]);
            $k1 = $temp >> 4;
            $k2 = $temp - ($k1 << 4);
            $k1 += $k1 > 9 ? 7 : 0;
            $k1 = chr($k1 + 48);
            $k2 += $k2 > 9 ? 7 : 0;
            $k2 = chr($k2 + 48);
            $r .= $k1 . $k2;
        }
        return $r;
    }
    public function _saveAvatarByUcenter($uid, $avatarBig, $avatarMid, $avatarSmall) {
        loaducenter();
        $uc_avatarflash = uc_avatar($uid, 'virtual', 0);

        if (!empty($uc_avatarflash[7])) {
            $parse = parse_url($uc_avatarflash[7]);
            if (!empty($parse['query'])) {
                $url = sprintf('%s/index.php?m=user&a=rectavatar&%s', UC_API, $parse['query']);


                $saveRes = dfsockopen($url, 0,sprintf('avatar1=%s&avatar2=%s&avatar3=%s', $avatarBig, $avatarMid, $avatarSmall), '', FALSE, '', 15);
                $saveRes = self::parseXmlToArray($saveRes);
                if (!empty($saveRes['face']['@attributes']['success']) && 
                    $saveRes['face']['@attributes']['success'] == 1) {
                    return true;
                }
            }
        }
        return false;
    }
    private static function _transSimpleXMLElementToArray($element) {
        if ($element instanceof SimpleXMLElement) {
            $arr = (array) $element;
            foreach ($arr as $key => $value) {
                $arr[$key] = self::_transSimpleXMLElementToArray($value);
            }
            return $arr;
        } else {
            return $element;
        }
    }
    public static function parseXmlToArray($xmlString) {
        $res = array();
        if (($xml = simplexml_load_string($xmlString)) !== false) {
            $res = self::_transSimpleXMLElementToArray($xml);
        }
        return $res;
    }

    public function get_randuid($num){
    	$uidarr =  C::t("#zhanmishu_zan#zhanmishu_zan")->get_randuid($num);
    	//check uid
    	foreach ($uidarr as $key => $value) {
	    	$username = $this->getusernamebyuid($value['uid']);
	    	if (!$username) {
	    		unset($uidarr[$key]);
	    	}
    	}
    	return $uidarr;
    }

    public function get_zanfan_num($per){
    	return intval(($per+rand(0,99))/100);
    }

    public function zan_fan_views($tid='',$uid=false){
    	global $_G;
    	$config = $this->config;

    	$tid = $tid ? $tid : $_G['forum_thread']['tid'];

    	$zanper = $config['zanpercent'];
    	$fanper = $config['fanpercent'];
    	$maxzan = $config['maxzan'];
    	$maxfan = $config['maxfan'];
    	if (in_array($tid, $config['tids'])) {
	    	$zanper = $config['tidzanpercent'];
	    	$fanper = $config['tidfanpercent'];
	    	$maxzan = $config['tidmaxzan'];
	    	$maxfan = $config['tidmaxfan'];
    	}
    	$zannum = $this->get_zanfan_num($zanper);
    	$fannum = $this->get_zanfan_num($fanper);
    	update_threadpartake($tid);

    	if ($_G['forum_thread']['recommend_add'] < $maxzan && $zannum >=1) {
	    	$zannum = $this->add_zan_user($tid,$act='add',$zannum);

	    	$zanfield = $this->zan($tid,$act='add',$zannum);
	    	C::t('forum_thread')->increase($tid, $zanfield);

    	}

    	if ($_G['forum_thread']['recommend_sub'] < $maxfan && $fannum >=1) {
	    	$fannum = $this->add_zan_user($tid,$act='add',$fannum);

	    	$fanfield = $this->zan($tid,$act='sub',$fannum);
	    	C::t('forum_thread')->increase($tid, $fanfield);
   		}
   		
    	//C::t("forum_threadaddviews")->increase($tid,array('addviews'=>$config['addviews']));
    	//C::t('forum_memberrecommend')->insert(array('tid'=>$config['addviews'], 'recommenduid'=>$uid, 'dateline'=>$_G['timestamp']));
    	if ($config['addviews']) {
            $this->viewthread_updateviews($tid,$config['addviews']);
        }
   		if ($config['isupdate_lastpost'] && ($zannum || $fannum)) {
   			C::t('forum_thread')->update($tid, array('lastpost' => TIMESTAMP));
   		}

    }

    public function viewthread_updateviews($tid,$num='1') {
		global $_G;
		if($_G['setting']['optimizeviews']) {
			if($_G['forum_thread']['addviews']) {
				if($_G['forum_thread']['addviews'] < 100) {
					DB::query('UPDATE '.DB::table('forum_threadaddviews').' SET `addviews`=`addviews`+'.$num.' WHERE tid=%d', array($tid));
				} else {
					if(!discuz_process::islocked('update_thread_view')) {
						$row = C::t('forum_threadaddviews')->fetch($tid);
						C::t('forum_threadaddviews')->update($tid, array('addviews' => 0));
						C::t('forum_thread')->increase($tid, array('views' => $row['addviews']+$num), true);
						discuz_process::unlock('update_thread_view');
					}
				}
			} else {
				C::t('forum_threadaddviews')->insert(array('tid' =>$tid, 'addviews' => $num), false, true);
			}
		} else {
			C::t('forum_thread')->increase($tid, array('views' => $num), true);
		}
		
	}

    public function add_zan_user($tid,$act='add',$num){
      	global $_G;
    	$uidarr = $this->get_randuid($num);
    	$tid = $tid ? $tid : $_G['forum_thread']['tid'];
    	
		foreach ($uidarr as $key => $value) {
			if(!$this->config['allow_repeat_zan'] && C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($value['uid'], $tid)) {
				unset($uidarr[$key]);
			}else{
				$uidarr[$key]['username'] = $this->getusernamebyuid($value['uid']);
			}
		}
    	if (empty($uidarr)) {
    		return false;
    	}

    	C::t("#zhanmishu_zan#zhanmishu_zan")->add_zan_user($tid,$act='add',$uidarr);
    	return count($uidarr);

    }

	public function playzhanverify(){
		global $_G;
		require_once libfile('function/cloudaddons');
		$data=array();
		if (!$_G['setting']['my_siteid']) {
			return false;
		}
		$data['siteid'] = $_G['setting']['my_siteid'];
		$data['pluginid'] = 'zhanmishu_zan.plugin';
		$data['versionid'] = '67933';

		$param = http_build_query($data);
		$url = $this->playzhanverifyurl.$param;
		$apidata = self::Curl($url);
		if ($apidata['code'] == '1') {
			return true;
		}else{
			return false;
		}
	}	
    public static function Curl($url,$isJsonDecode=false,$proxy=false){
        $resultj = dfsockopen($url);
        if ($isJsonDecode) {
            return json_decode($resultj,true);
        }else{
            return $resultj;
        }
    }
    public function zan($tid,$act='add',$num){
    	global $_G;
    	$tid = $tid ? $tid : $_G['forum_thread']['tid'];
  

		if(!$this->config['allow_repeat_zan'] && C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($uid, $tid)) {
			return false;
		}

		$_G['group']['allowrecommend'] = intval($act == 'add' ? $_G['group']['allowrecommend'] : -$_G['group']['allowrecommend']);
		$fieldarr = array();
		if($act == 'add') {
			$heatadd = 'recommend_add=recommend_add+1';
			$fieldarr['recommend_add'] = $num;
		} else {
			$heatadd = 'recommend_sub=recommend_sub+1';
			$fieldarr['recommend_sub'] = $num;
		}

		update_threadpartake($tid);
		$fieldarr['heats'] = 0;
		$fieldarr['recommends'] = $_G['group']['allowrecommend'];
		// C::t('forum_thread')->increase($tid, $fieldarr);
		// C::t('forum_thread')->update($tid, array('lastpost' => TIMESTAMP));
		// C::t('forum_memberrecommend')->insert(array('tid'=>$tid, 'recommenduid'=>$uid, 'dateline'=>$_G['timestamp']));
		return $fieldarr; 
    }
}
//From: Dism_taobao-com
?>