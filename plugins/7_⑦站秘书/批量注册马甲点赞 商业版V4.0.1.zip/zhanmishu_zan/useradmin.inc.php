<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Support: DisM!Ӧ������ $
 *    ���²����http://t.cn/Aiux1Jx1 $
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

C::import('zhanmishu_register','plugin/zhanmishu_zan/source/class');

cpheader();

$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
$pages= ceil($num / $perpage);
$start = $num - ($num - $perpage*$curpage+$perpage);
$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&do=159&identifier=zhanmishu_zan&pmod=useradmin';
$url = 'plugins&operation=config&identifier=zhanmishu_zan&pmod=useradmin';

$zan = new zhanmishu_register();

if ($_GET['act'] =='zandel' &&  FORMHASH == $_GET['formhash'] && $_GET['zid']) {
	
	$zan->delete_zan($_GET['zid']);
	cpmsg(lang('plugin/zhanmishu_zan', 'delete_zid_success'),dreferer(),'success');
}else if ($_GET['act'] =='cleanuser' &&  FORMHASH == $_GET['formhash']) {
	
	$zan->cleanuser();
	cpmsg(lang('plugin/zhanmishu_zan', 'delete_zid_success'),dreferer(),'success');
}


$zanlist = $zan->get_zanlist_fmt($start,$perpage,'desc','',array());
$num = $zan->get_zanlist_num(array());

	echo lang('plugin/zhanmishu_zan','clearzanuserurl',array('url'=>$mpurl.'&act=cleanuser&formhash='.FORMHASH));

showtableheader();
	showsubtitle(array(lang('plugin/zhanmishu_zan', 'zid'),lang('plugin/zhanmishu_zan', 'uid'),lang('plugin/zhanmishu_zan', 'username'),lang('plugin/zhanmishu_zan', 'avatar'),lang('plugin/zhanmishu_zan', 'act')));
	foreach ($zanlist as $key => $value) {
		showtablerow('class="partition"',array('class="td15"', 'class="td28"'),$value);
	}
showtablefooter();
$multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
echo $multi;




?>