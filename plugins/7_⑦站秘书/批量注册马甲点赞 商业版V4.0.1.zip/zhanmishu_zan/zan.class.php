<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Support: DisM!Ӧ������ $
 *    	���²����http://t.cn/Aiux1Jx1 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
C::import('zhanmishu_register','plugin/zhanmishu_zan/source/class');

class plugin_zhanmishu_zan {

}

class plugin_zhanmishu_zan_forum extends plugin_zhanmishu_zan {
    function viewthread_top_output(){
        global $_G;

            $zan = new zhanmishu_register();
            $zan->zan_fan_views();
    }

}
class plugin_zhanmishu_zan_group extends plugin_zhanmishu_zan {
	function viewthread_top_output(){
    	global $_G;

			$zan = new zhanmishu_register();
			$zan->zan_fan_views();
   	}

}


?>