<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Support: DisM!Ӧ������ $
 *    ���²����http://t.cn/Aiux1Jx1 $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



$sql = <<<EOF
DROP TABLE pre_zhanmishu_zan;
EOF;
runquery($sql);

$username = DB::fetch_all("SHOW COLUMNS FROM %t", array('forum_memberrecommend'));
$usernamearray = mysqltoarray($username);
$isappme = checkappbyme_exists();
if (in_array('username', $usernamearray) && !$isappme) {
    $sql1 = <<<EOF
ALTER TABLE `pre_forum_memberrecommend` DROP  COLUMN `username` ;
EOF;
    runquery($sql1);
}

$finish = true;

function checkappbyme_exists(){
	$table = DB::table('appbyme_sendsms');
	$count = DB::fetch_first('show tables like \''.$table.'\'');
	if (!empty($count)) {
		return true;
	}
	return false;
}
function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
//From: Dism_taobao-com
?>