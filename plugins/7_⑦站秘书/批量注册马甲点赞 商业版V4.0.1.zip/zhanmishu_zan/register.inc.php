<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Support: DisM!Ӧ������ $
 *    ���²����http://t.cn/Aiux1Jx1 $
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_zan/source/class/zhanmishu_register.php';
if ($_GET['register_addsubmit'] && $_GET['formhash'] == formhash()) {
	$register = new zhanmishu_register();
	$num = 1;

	$page = $_GET['page'] ? $_GET['page'] : '1';
	$perpage = '10';
	$start = $page * $perpage - $perpage + 1;
	$num = $_GET['register_num'];
	$pages = ceil($num/$perpage);
	
	if ($start + $perpage - 1 <= $num) {
		 $regnum = $perpage;
	}else if ($start + $perpage -1 > $num) {
		 $regnum = $num - $start + 1;
	}

	$i = 1;
	set_time_limit(0);
	while ($i <= $regnum) {
		$success_num = $register->register($regnum); 
		if ($success_num > 0) {
			$i += $success_num;;
		}
	}

	if ($pages <= $page) {
		cpmsg(lang('plugin/zhanmishu_zan', 'register_success'),'action=plugins&operation=config&do=159&identifier=zhanmishu_zan&pmod=register');
	}

	cpmsg(lang('plugin/zhanmishu_zan', 'register_step',array('page'=>$page,'nextpage'=>$page+1,'pages'=>$pages)),'action=plugins&operation=config&do=159&identifier=zhanmishu_zan&pmod=register&register_addsubmit=yes&formhash='.FORMHASH.'&page='.($page+1).'&register_num='.$num);
}

//$uid = $register->register();
		showformheader('plugins&operation=config&do=159&identifier=zhanmishu_zan&pmod=register','enctype="multipart/form-data"');
		showtableheader();
		showsetting(lang('plugin/zhanmishu_zan', 'register_num'), 'register_num', '', 'text','','',lang('plugin/zhanmishu_zan', 'register_num_desc'),'size="10"');
		
		showsubmit('register_addsubmit');
		showtablefooter();
		showformfooter();/*Dism��taobao��com*/

?>