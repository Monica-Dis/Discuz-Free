<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Support: DisM!Ӧ������ $
 *		���²����http://t.cn/Aiux1Jx1 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_zhanmishu_zan extends discuz_table {

	public function __construct() {
		$this->_table = 'zhanmishu_zan';
		$this->_pk = 'zid';

		parent::__construct();
	}

	public function get_randuid($num){
		$num = $num ? $num :  '1';
		$zanu = DB::fetch_all('select uid from %t order by rand() limit '.$num,array($this->_table));
		return $zanu;
	}
	public function get_count_by_field($data,$extsql){
		if (!is_array($data) || empty($data)) {
			return $this->count();
		}
		$where = ' where ';
		$i = 1;
		foreach ($data as $key => $value) {
			if ($i == count($data)) {
				$where = $where.' '.$key.' = '.$value.' ';
			}else{
				$where = $where.' '.$key.' = '.$value.' and ';
			}

			++$i;
		}

		$count = DB::fetch_first('select count(*) as num from %t '.$where,array($this->_table));
		return $count['num'];
	}
	public function get_zanlist($start = 0, $limit = 0, $sort = '',$type = '',$field) {
		if($sort) {
			$this->checkpk();
		}

		if (!empty($field) && $where) {
			$where = $where.' and ';
		}elseif (!empty($field)) {
			$where = ' where ';
		}else{
			$where = '';
		}

		$i = 1;
		foreach ($field as $key => $value) {
			if ($i == count($field)) {
				$where = $where.' '.$key.' = '.$value.' ';
			}else{
				$where = $where.' '.$key.' = '.$value.' and ';
			}

			++$i;
		}
		return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	public function get_zanlist_num($field=array()){
		if (!empty($field)) {
			$where = ' where ';
		}else{
			$where = '';
		}

		$i = 1;
		foreach ($field as $key => $value) {
			if ($i == count($field)) {
				$where = $where.' '.$key.' = '.$value.' ';
			}else{
				$where = $where.' '.$key.' = '.$value.' and ';
			}

			++$i;
		}
		$count = DB::fetch_first('SELECT count(*) as num FROM '.DB::table($this->_table).$where);
		return $count['num'];
	}

	public function add_zan_user($tid,$act='add',$uidarr){
		if (empty($uidarr)) {
			return false;
		}
		$recom = array();
		$recom['dateline'] = TIMESTAMP;
		$recom['tid'] = $tid;

		$tmp = array();
		$usql = array();
		foreach ($uidarr as $key => $value) {
			$tmp['tid'] = DB::quote($tid);
			$tmp['recommenduid'] = DB::quote($value['uid']);
			$tmp['dateline'] = DB::quote(TIMESTAMP);
			$tmp['username'] =DB::quote($value['username']);
		
			$usql['sql'][$value['uid']] = ' ('.implode(',', $tmp).') ';
		}
		$str = 'insert into '.DB::table('forum_memberrecommend').' ('.DB::quote_field('tid').','.DB::quote_field('recommenduid').','.DB::quote_field('dateline').','.DB::quote_field('username').') values ';
		
		$str .= implode(',',$usql['sql']);
		DB::query($str);
	}
}
//From: Dism_taobao_com
?>