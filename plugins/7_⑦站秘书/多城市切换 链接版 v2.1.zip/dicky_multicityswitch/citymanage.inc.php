<?php
/*
	Name: 【Dicky】多城市切换(MultiCitySwitch)链接版
	Author: Dicky
	应用更新支持：https://dism.taobao.com
	本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
	我们致力于为站长提供正版Discuz!应用而努力
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include dirname(__FILE__) . '/./common.func.php';
$jsPath = 'source/plugin/dicky_multicityswitch/js/';
loadcache('plugin');
$var = $_G['cache']['plugin']['dicky_multicityswitch'];
cpheader();
shownav('global', 'district');
$values = array(intval($_GET['pid']), intval($_GET['cid']), intval($_GET['did']));
$adminurl = "admin.php?action=plugins&operation=config&do=" . $_GET['do'] . "&identifier=" . $_GET['identifier'] . "&pmod=" . $_GET['pmod'];
$action = "plugins&operation=config&do=$_GET[do]&identifier={$_GET[identifier]}&pmod={$_GET[pmod]}&pid={$values[0]}&cid={$values[1]}&did={$values[2]}";
$elems = array($_GET['province'], $_GET['city'], $_GET['district']);
$level = 1;
$upids = array(0);
$theid = 0;
for ($i = 0; $i < 3; $i++) {
    if (!empty($values[$i])) {
        $theid = intval($values[$i]);
        $upids[] = $theid;
        $level++;
    } else {
        for ($j = $i; $j < 3; $j++) {
            $values[$j] = '';
        }
        break;
    }
}
if (submitcheck('editsubmit')) {
    $delids = array();
    foreach (C::t('common_district')->fetch_all_by_upid($theid) as $value) {
        $fids = implode(',', $_POST['fids'][$value['id']]);
        if (!isset($_POST['district'][$value['id']])) {
            $delids[] = $value['id'];
        } elseif ($_POST['district'][$value['id']] != $value['name'] || $_POST['displayorder'][$value['id']] != $value['displayorder'] || $_POST['ename'][$value['id']] != $value['ename'] || $_POST['available'][$value['id']] != $value['available'] || $_POST['url'][$value['id']] != $value['url'] || $_POST['seotitle'][$value['id']] != $value['seotitle'] || $_POST['seokeywords'][$value['id']] != $value['seokeywords'] || $_POST['seodescription'][$value['id']] != $value['seodescription']) {
            $ename = strtolower(trim($_POST['ename'][$value['id']]));
            $name = trim($_POST['district'][$value['id']]);
            $displayorder = intval($_POST['displayorder'][$value['id']]);
            $url = trim($_POST['url'][$value['id']]);
            $seotitle = trim($_POST['seotitle'][$value['id']]);
            $seokeywords = trim($_POST['seokeywords'][$value['id']]);
            $seodescription = trim($_POST['seodescription'][$value['id']]);
            $available = intval($_POST['available'][$value['id']]);
            if ($_G['config']['defaultregion']['allsite'] && $ename == $_G['config']['defaultregion']['allsite']) cpmsg($_G['config']['defaultregion']['allsite'] . pl('allisuse'));
            if (!$var['allowwww'] && strtolower($ename) == 'www') {
                cpmsg('www' . pl('wwwisuse'));
            }
            $tmp = fetch_all_by_ename($ename, $value['id']);
            if (!empty($tmp)) cpmsg($ename . pl('exists'));
            C::t('common_district')->update($value['id'], array('name' => $name, 'displayorder' => $displayorder, 'available' => $available, 'ename' => $ename, 'url' => $url, 'seotitle' => $seotitle, 'seokeywords' => $seokeywords, 'seodescription' => $seodescription));
        }
    }
    if ($delids) {
        $ids = $delids;
        for ($i = $level; $i < 4; $i++) {
            $ids = array();
            foreach (C::t('common_district')->fetch_all_by_upid($delids) as $value) {
                $value['id'] = intval($value['id']);
                $delids[] = $value['id'];
                $ids[] = $value['id'];
            }
            if (empty($ids)) {
                break;
            }
        }
        C::t('common_district')->delete($delids);
    }
    if (!empty($_POST['districtnew'])) {
        $inserts = array();
        $displayorder = '';
        foreach ($_POST['districtnew'] as $key => $value) {
            $displayorder = intval($_POST['districtnew_order'][$key]);
            $value = trim($value);
            $ename = strtolower(trim($_POST['enamenew'][$key]));
            $url = trim($_POST['urlnew'][$key]);
            $seotitle = trim($_POST['seotitlenew'][$key]);
            $seokeywords = trim($_POST['seokeywordsnew'][$key]);
            $seodescription = trim($_POST['seodescriptionnew'][$key]);
            $available = intval($_POST['availablenew'][$key]);
            if ($_G['config']['defaultregion']['allsite'] && $ename == $_G['config']['defaultregion']['allsite']) cpmsg($_G['config']['defaultregion']['allsite'] . pl('allisuse'));
            if (!$var['allowwww'] && strtolower($ename) == 'www') {
                cpmsg('www' . pl('wwwisuse'));
            }
            $tmp = fetch_all_by_ename($ename, 0);
            if (!empty($tmp)) cpmsg($ename . pl('exists'));
            if (!empty($value)) {
                C::t('common_district')->insert(array('name' => $value, 'level' => $level, 'upid' => $theid, 'displayorder' => $displayorder, 'ename' => $ename, 'available' => $available, 'url' => $url, 'seotitle' => $seotitle, 'seokeywords' => $seokeywords, 'seodescription' => $seodescription));
            }
        }
    }
    if (isset($_POST['allenable'])) {
        $available = intval($_POST['allenable']);
        $sql = "UPDATE " . DB::table('common_district') . " SET available = '$available'";
        $query = DB::query($sql);
    }
    cpmsg('setting_district_edit_success', "action={$action}", 'succeed');
} else {
    showsubmenu('district');
    $msg = '<a href="' . $adminurl . '&pid=' . $values[0] . '&cid=' . $values[1] . '&did=' . $values[2] . '&op=createjs">' . pl('generatejs') . '</a><span style="color:red">' . str_replace('{jspath}', $jsPath, pl('generatejstip')) . '</span>';
    showsubmenu($msg);
    if ($_GET['op'] == 'createjs') {
        $jscode = "var provArray = [";
        $i = 0;
        $sql = "SELECT * FROM " . DB::table('common_district') . " WHERE level < 4 AND available = '1' ORDER BY upid, displayorder";
        $query = DB::query($sql);
        while ($row = DB::fetch($query)) {
            if ($i == 0)
                $jscode .= "['$row[name]','$row[upid]','$row[id]','$row[ename]']";
            else
                $jscode .= ",['$row[name]','$row[upid]','$row[id]','$row[ename]']";
            $i++;
        }
        $jscode .= "];";
        fputs(fopen("{$jsPath}provinceandcity.js", 'w'), mb_convert_encoding($jscode, 'utf-8', CHARSET));
        cpmsg(pl('generatejsok'), "action={$action}", 'succeed');
    }
    showtips('district_tips');
    showformheader($action);
    showtableheader();
    $options = array(1 => array(), 2 => array(), 3 => array());
    $thevalues = array();
    foreach (C::t('common_district')->fetch_all_by_upid($upids) as $value) {
        $options[$value['level']][] = array($value['id'], $value['name']);
        if ($value['upid'] == $theid) {
            $thevalues[] = array($value['id'], $value['name'], $value['displayorder'], $value['available'], $value['ename'], $value['url'], $value['seotitle'], $value['seokeywords'], $value['seodescription']);
        }
    }
    $names = array('province', 'city', 'district');
    for ($i = 0; $i < 3; $i++) {
        $elems[$i] = !empty($elems[$i]) ? $elems[$i] : $names[$i];
    }
    $html = '';
    for ($i = 0; $i < 3; $i++) {
        $l = $i + 1;
        $jscall = ($i == 0 ? 'this.form.city.value=\'\';this.form.district.value=\'\';' : '') . "refreshdistrict('$elems[0]', '$elems[1]', '$elems[2]')";
        $html .= '<select name="' . $elems[$i] . '" id="' . $elems[$i] . '" onchange="' . $jscall . '">';
        $html .= '<option value="">' . lang('spacecp', 'district_level_' . $l) . '</option>';
        foreach ($options[$l] as $option) {
            $selected = $option[0] == $values[$i] ? ' selected="selected"' : '';
            $html .= '<option value="' . $option[0] . '"' . $selected . '>' . $option[1] . '</option>';
        }
        $html .= '</select>&nbsp;&nbsp;';
    }
    echo cplang('district_choose') . ' &nbsp; ' . $html;
    showsubtitle(array('', 'display_order', 'ID', 'name', pl('domain'), pl('url'), pl('seotitle'), pl('seokeywords'), pl('seodescription'), pl('district_available'), 'operation'));
	$navs = array();
	foreach(C::t('common_nav')->fetch_all_by_navtype_type(0, 5) as $nav) {
		$navs[] = $nav['identifier'];
	}
	$forumcount = C::t('forum_forum')->fetch_forum_num();
	$fidsList = C::t('forum_forum')->fetch_all_forum_for_sub_order();
	$groups = $forums = $subs = array();
	foreach($fidsList as $forum) {
		if($forum['type'] == 'group') {
			$groups[$forum['fid']] = $forum;
		} elseif($forum['type'] == 'sub') {
			$subs[$forum['fup']][] = $forum;
		} else {
			$forums[$forum['fup']][] = $forum;
		}
	}
	$styleList = C::t('common_style')->fetch_all_data();
    foreach ($thevalues as $value) {
        $valarr = array();
        $valarr[] = '';
        $valarr[] = '<input type="text" id="displayorder_' . $value[0] . '" class="txt" name="displayorder[' . $value[0] . ']" value="' . $value[2] . '" />';
        $valarr[] = $value[0];
        $valarr[] = '<p id="p_' . $value[0] . '"><input type="text" id="input_' . $value[0] . '" class="txt" name="district[' . $value[0] . ']" value="' . $value[1] . '" maxlength="255" /></p>';
        $valarr[] = '<input type="text" id="ename_' . $value[0] . '" class="txt" name="ename[' . $value[0] . ']" value="' . $value[4] . '" maxlength="255" />';
        $valarr[] = '<input type="text" id="url_' . $value[0] . '" class="txt" name="url[' . $value[0] . ']" maxlength="255" value="' . $value[5] . '" style="width:98%;min-width:100px;_width:100px;" />';
        $valarr[] = '<input type="text" id="seotitle_' . $value[0] . '" class="txt" name="seotitle[' . $value[0] . ']" value="' . $value[6] . '" />';
        $valarr[] = '<input type="text" id="seokeywords_' . $value[0] . '" class="txt" name="seokeywords[' . $value[0] . ']" value="' . $value[7] . '" />';
        $valarr[] = '<input type="text" id="seodescription_' . $value[0] . '" class="txt" name="seodescription[' . $value[0] . ']" value="' . $value[8] . '" />';
        $valarr[] = '<input type="checkbox" name="available[' . $value[0] . ']" value="1" class="checkbox"' . ($value[3] ? ' checked="checked" ' : '') . ' />';
        $valarr[] = '<a href="javascript:;" onclick="deletedistrict(' . $value[0] . ');return false;">' . cplang('delete') . '</a>';
        showtablerow('id="td_' . $value[0] . '"', array('', 'class="td25"', '', '', '', ''), $valarr);
    }
    $allavailable = '<div><label for="allenable"><input type="radio" id="allenable" name="allenable" value="1" />' . pl('enableall') . '</label><label for="alldisable"><input type="radio" id="alldisable" name="allenable" value="0" />' . pl('disableall') . '</label></div>';
    showtablerow('', array('colspan=11'), array(
        '<div><a href="javascript:;" onclick="addrow(this, 0, 1);return false;" class="addtr">' . cplang('add') . '</a></div>' . $allavailable
    ));
    showsubmit('editsubmit', 'submit');
    echo <<<SCRIPT
<script type="text/javascript">
var rowtypedata = [
    [[1,'', ''],[1,'<input type="text" class="txt" name="districtnew_order[]" value="0" />', 'td25'], [1,'', ''],[1,'<input type="text" class="txt" name="districtnew[]" maxlength="255" />', ''],[1,'<input type="text" class="txt" name="enamenew[]" maxlength="255" />', ''],[1,'<input type="text" class="txt" name="urlnew[]" style="width:98%;min-width:100px;_width:100px;" />', ''],[1,'<input type="text" class="txt" name="seotitlenew[]" />', ''],[1,'<input type="text" class="txt" name="seokeywordsnew[]" />', ''],[1,'<input type="text" class="txt" name="seodescriptionnew[]" />', ''],[1,'<input type="checkbox" class="checkbox" name="availablenew[]" value="1" checked="checked" />', ''],[1,'', '']],];
function refreshdistrict(province, city, district) {
    location.href = "$adminurl"
        + "&province="+province+"&city="+city+"&district="+district
        +"&pid="+$(province).value + "&cid="+$(city).value+"&did="+$(district).value;
}
function editdistrict(did) {
    $('input_' + did).style.display = "block";
    $('span_' + did).style.display = "none";
}
function deletedistrict(did) {
    var elem = $('p_' + did);
    elem.parentNode.removeChild(elem);
    var elem = $('td_' + did);
    elem.parentNode.removeChild(elem);
}
</script>
SCRIPT;
    showtablefooter();/*Dism·taobao·com*/
    showformfooter();/*Dism-taobao_com*/
}
function fetch_all_by_ename($name, $id) {
    if (!empty($name)) {
        return DB::fetch_all('SELECT * FROM %t WHERE ' . DB::field('id', $id, '<>') . ' AND ' . DB::field('ename', $name), array('common_district'));
    }
    return array();
}

?>