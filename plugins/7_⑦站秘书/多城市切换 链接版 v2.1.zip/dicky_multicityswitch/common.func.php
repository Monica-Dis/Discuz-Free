<?php
/*
	Name: 【Dicky】多城市切换(MultiCitySwitch)链接版
	Author: Dicky
	应用更新支持：https://dism.taobao.com
	本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
	我们致力于为站长提供正版Discuz!应用而努力
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
function pl($str) {
    return lang('plugin/dicky_multicityswitch', $str);
}
function detect_encoding($file) {
    $list = array('GBK', 'UTF-8');
    $str = file_get_contents($file);
    foreach ($list as $item) {
        $tmp = mb_convert_encoding($str, $item, $item);
        if (md5($tmp) == md5($str)) {
            return $item;
        }
    }
    return null;
}
//From: Dism_taobao_com
?>