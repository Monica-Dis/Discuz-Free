<?php
/*
	Name: 【Dicky】多城市切换(MultiCitySwitch)链接版
	Author: Dicky
	应用更新支持：https://dism.taobao.com
	本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
	我们致力于为站长提供正版Discuz!应用而努力
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
include dirname(__FILE__) . '/./common.func.php';
$var = $_G['cache']['plugin']['dicky_multicityswitch'];
//if ($var && ($var['citystyle'] || $_GET['mobile']) && !isset($_GET['switchregion'])) {
	define('CSSDIR', 'source/plugin/dicky_multicityswitch/css');
	define('INDEXURL', 'plugin.php?id=dicky_multicityswitch:index');
	$sql = "SELECT C.*, P.id provinceid, P.name provincename, P.ename province from " . DB::table('common_district') . " C INNER JOIN " . DB::table('common_district') . " P ON C.upid = P.id WHERE C.available = '1' AND P.available = '1' AND C.level = 2 ORDER BY P.displayorder, P.id, C.displayorder, C.id";
	$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, C.ename city, C.id cityid, C.name cityname, D.ename district, D.id districtid, D.name districtname FROM " . DB::table('common_district') . " D LEFT JOIN " . DB::table('common_district') . " C ON D.upid = C.id LEFT JOIN " . DB::table('common_district') . " P ON C.upid = P.id WHERE D.level <= '3' AND D.available = '1' ORDER BY P.displayorder, P.id, C.displayorder, C.id, D.displayorder, D.id";
	//echo $sql;
	$query = DB::query($sql);
	$regionList = array();
	while ($row = DB::fetch($query)) {
		if(!$row['provinceid'] && !$row['cityid']){
			$regionList[$row['districtid']]['province'] = $row['district'];
			$regionList[$row['districtid']]['provincename'] = $row['districtname'];
		}
		elseif(!$row['provinceid'] && $row['cityid']){
			$regionList[$row['cityid']]['citylist'][$row['districtid']] = array(
				'city' => $row['district'],
				'cityname' => $row['districtname']
			);
		}
		else {
			$regionList[$row['provinceid']]['citylist'][$row['cityid']]['districtlist'][$row['districtid']] = $row;
		}
	}
//}
if ($_GET['switchregion']) { 
	showmessage(pl('loading'), 'index.php');
}
include template('dicky_multicityswitch:index');
?>