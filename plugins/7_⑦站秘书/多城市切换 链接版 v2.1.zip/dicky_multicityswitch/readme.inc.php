<?php
/*
	Name: 【Dicky】多城市切换(MultiCitySwitch)链接版
	Author: Dicky
	应用更新支持：https://dism.taobao.com
	本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
	我们致力于为站长提供正版Discuz!应用而努力
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
include dirname(__FILE__) . '/./common.func.php';
echo pl('readme');
?>