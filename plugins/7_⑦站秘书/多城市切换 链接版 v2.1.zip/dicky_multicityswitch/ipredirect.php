<?php
/*
	Name: ��Dicky��������л�(MultiCitySwitch)���Ӱ�
	Author: Dicky
	Ӧ�ø���֧�֣�https://dism.taobao.com
	�����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
	����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
*/
header('Cache-Control:no-cache,must-revalidate');
header('Pragma:no-cache');
header("Expires:0");
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$configFile = DISCUZ_ROOT.'./config/config_global.php';
@include_once $configFile;
include_once dirname(__FILE__) . '/./common.func.php';
$_config = $_G['config'];
if (empty($_config['cookie']['cookiedomain'])) showmessage(pl('cookiedomaintip'));
if (empty($_config['defaultregion'])) showmessage(pl('defaultregiontip'));
$configEncoding = detect_encoding($configFile);
if($configEncoding != strtoupper(CHARSET)) {
	foreach ($_config['defaultregion'] as $key => $value) {
		$_config['defaultregion'][$key] = iconv($configEncoding, CHARSET, $value);
	}
}
if ($var['usewww']) {
	$_G['config']['defaultregion']['allsite'] = $_config['defaultregion']['allsite'] = 'www';
}
$_RegionInfo = array(
	'province' => getcookie('province'),
	'provinceid' => floatval(getcookie('provinceid')),
	'provincename' => getcookie('provincename'),
	'city' => getcookie('city'),
	'cityid' => floatval(getcookie('cityid')),
	'cityname' => getcookie('cityname'),
	'district' => getcookie('district'),
	'districtid' => floatval(getcookie('districtid')),
	'districtname' => getcookie('districtname'),
	'region' => getcookie('region'),
	'regionid' => floatval(getcookie('regionid')),
	'regionname' => getcookie('regionname'),
	'regionlevel' => intval(getcookie('regionlevel'))
);
$_CookieTime = 60 * 60 * 24 * 30;
$HTTP_HOST = $_SERVER['HTTP_HOST'] ? $_SERVER['HTTP_HOST'] : $HTTP_SERVER_VARS['HTTP_HOST'];
$HTTP_HOST = strtolower($HTTP_HOST);
$CUR_URI = $_SERVER['REQUEST_URI'] ? $_SERVER['REQUEST_URI'] : $HTTP_SERVER_VARS['REQUEST_URI'];
$CUR_URI = strtolower($CUR_URI);
if ($cityMode == 1) {
    $CUR_SCRIPT_NAME = $_SERVER['SCRIPT_NAME'];
    $dotStr = '.';
    if (stristr($HTTP_HOST, $_config['cookie']['cookiedomain'])) $_SwitchRegion = strtolower(str_ireplace($_config['cookie']['cookiedomain'], '', $HTTP_HOST));
    if (!$var['usewww'] && $_SwitchRegion == 'www' && !$_RegionInfo['region']) $_SwitchRegion = '';
}
else {
    $CUR_SCRIPT_NAME = '/forum.php';
    $dotStr = '';
    $_SwitchRegion = strtolower(trim($_GET['switchregion']));
}
if ($_RegionInfo['region'] || $_SwitchRegion) {
    $_RegionInfo['region'] = strtolower($_RegionInfo['region']);
	if (($dotStr . $HTTP_HOST == $_config['cookie']['cookiedomain'] || (!$var['usewww'] && $HTTP_HOST == 'www' . $_config['cookie']['cookiedomain'])) && $_RegionInfo['region'] && $CUR_URI == $CUR_SCRIPT_NAME && $cityMode == 1) {
        $url = 'http://' . $_RegionInfo['region'] . $_config['cookie']['cookiedomain'];
    }
	elseif ($_SwitchRegion != '' && $_SwitchRegion != $_RegionInfo['region']) {
		if (!$var['allowwww'] && $_SwitchRegion == $_config['defaultregion']['allsite']) {
			$_RegionInfo = array(
				'url' => trim($_config['defaultregion']['url']),
				'province' => '',
				'provinceid' => 0,
				'provincename' => '',
				'city' => '',
				'cityid' => 0,
				'cityname' => '',
				'district' => '',
				'districtid' => 0,
				'districtname' => '',
				'region' => trim($_config['defaultregion']['allsite']),
				'regionid' => 0,
				'regionname' => pl('allsite'),
				'regionlevel' => 0
			);
		}
		else {
			$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, C.ename city, C.id cityid, C.name cityname, D.ename district, D.id districtid, D.name districtname, 3 regionlevel, D.ename region, D.id regionid, D.name regionname, D.* FROM " . DB::table('common_district') . " D INNER JOIN " . DB::table('common_district') . " C ON D.upid = C.id INNER JOIN " . DB::table('common_district') . " P ON C.upid = P.id WHERE D.level = '3' AND D.available = '1' AND D.ename = '$_SwitchRegion' ORDER BY D.id LIMIT 1";
			$_RegionInfo = DB::fetch_first($sql);
			if (!$_RegionInfo) {
				$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, C.ename city, C.id cityid, C.name cityname, '' district, 0 districtid, '' districtname, 2 regionlevel, C.ename region, C.id regionid, C.name regionname, C.* FROM " . DB::table('common_district') . " C INNER JOIN " . DB::table('common_district') . " P ON C.upid = P.id WHERE C.level = '2' AND C.available = '1' AND C.ename = '$_SwitchRegion' ORDER BY C.id LIMIT 1";
				$_RegionInfo = DB::fetch_first($sql);
				if (!$_RegionInfo) {
					$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, '' city, 0 cityid, '' cityname, '' district, 0 districtid, '' districtname, 1 regionlevel, P.ename region, P.id regionid, P.name regionname, P.* FROM " . DB::table('common_district') . " P WHERE P.level = '1' AND P.available = '1' AND P.ename = '$_SwitchRegion' ORDER BY P.id LIMIT 1";
					$_RegionInfo = DB::fetch_first($sql);
					if (!$_RegionInfo) {
						$_RegionInfo = array(
							'url' => trim($_config['defaultregion']['url']),
							'province' => trim($_config['defaultregion']['province']),
							'provinceid' => floatval($_config['defaultregion']['provinceid']),
							'provincename' => trim($_config['defaultregion']['provincename']),
							'city' => strtolower($_config['defaultregion']['city']),
							'cityid' => floatval($_config['defaultregion']['cityid']),
							'cityname' => trim($_config['defaultregion']['cityname']),
							'district' => trim($_config['defaultregion']['district']),
							'districtid' => floatval($_config['defaultregion']['districtid']),
							'districtname' => trim($_config['defaultregion']['districtname']),
							'region' => trim($_config['defaultregion']['region']),
							'regionid' => floatval($_config['defaultregion']['regionid']),
							'regionname' => trim($_config['defaultregion']['regionname']),
							'regionlevel' => intval($_config['defaultregion']['regionlevel'])
						);
					}
				}
			}
		}
		if ($cityMode == 1 && $_RegionInfo['region'] && $CUR_URI == $CUR_SCRIPT_NAME) {
			$url = 'http://' . $_RegionInfo['region'] . $_config['cookie']['cookiedomain'];
		}
        elseif ($cityMode == 0) {
			$referer = $_SERVER['HTTP_REFERER'];
            $url = 'index.php';
			if (intval($var['citystyle']) === 1) {
				if ($referer && stristr($referer, 'http://' . $HTTP_HOST) && !stristr($_SERVER['QUERY_STRING'], 'id=dicky_multicityswitch:index')) $url = $referer;
			}
			else {
				if ($referer && stristr($referer, 'http://' . $HTTP_HOST)) $url = $referer;
			}
			if($_GET['mobile']) $url = 'index.php';
        }
	}
}
elseif (!IS_ROBOT) {
    include_once dirname(__FILE__) . '/./iplocation.class.php';
    $iplocation = new IpLocation();
    $ip = $iplocation->getIP();
    $ipApi = (int)$var['ip_api'];
    $_SwitchRegion = '';
    if ($ipApi === 0) {
        $address = $iplocation->getaddress($ip);
        $_SwitchRegion = $address['area1'];
        $city = pl('city');
        $areaArr = explode($city, $address['area1']);
        if (count($areaArr) > 1 && $areaArr[1]) {
            $_SwitchRegion = $areaArr[1];
        } else {
            $_SwitchRegion = $areaArr[0];
        }
        if (empty($_SwitchRegion)) {
            $_SwitchRegion = 'empty region';
        }
        $whereArea = "INSTR('$_SwitchRegion', D.name)";
    } elseif ($ipApi === 2) {
        $apiUrl = 'http://ip.ws.126.net/ipquery?ip=' . $ip;
        $result = file_get_contents($apiUrl);
		if (CHARSET === 'utf-8') {
			$result = diconv($result, 'gbk', 'utf-8');
		}
        $reTag = '/city:"(.*)", province:"(.*)"/i';
        if (preg_match_all($reTag, $result, $matchResult)) {
            if (count($matchResult) > 1) {
                $jsonResult = array(
                    'city' => $matchResult[1][0],
                    'provice' => $matchResult[2][0]
                );
            }
        }
        $_SwitchRegion = 'empty region';
        $whereArea = "INSTR('$_SwitchRegion', D.name)";
    } elseif ($ipApi === 3) {
        $apiUrl = 'http://ip.taobao.com/service/getIpInfo.php?ip=' . $ip;
        $result = file_get_contents($apiUrl);
        $jsonResult = json_decode($result, true);
        if ($jsonResult['code'] === 0) {
            $_SwitchRegion = diconv($jsonResult['data']['county'], 'utf-8', CHARSET);
        }
        $whereArea = "INSTR(D.name, '$_SwitchRegion')";
    } elseif ($ipApi === 4) {
        $apiUrl = 'http://whois.pconline.com.cn/ipJson.jsp?json=true&ip=' . $ip;
        $result = trim(file_get_contents($apiUrl));
        if (CHARSET === 'gbk') {
            $result = diconv($result, CHARSET, 'utf-8');
        } else {
            $result = diconv($result, 'gbk', CHARSET);
        }
        $jsonResult = json_decode($result, true);
        $_SwitchRegion = diconv($jsonResult['region'], 'utf-8', CHARSET);
        $whereArea = "INSTR('$_SwitchRegion', D.name)";
    }
	$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, C.ename city, C.id cityid, C.name cityname, D.ename district, D.id districtid, D.name districtname, 3 regionlevel, D.ename region, D.id regionid, D.name regionname, D.* FROM " . DB::table('common_district') . " D INNER JOIN " . DB::table('common_district') . " C ON D.upid = C.id INNER JOIN " . DB::table('common_district') . " P ON C.upid = P.id WHERE D.level = '3' AND D.available = '1' AND $whereArea > 0 ORDER BY D.id LIMIT 1";
	$_RegionInfo = DB::fetch_first($sql);
	if (!$_RegionInfo) {
	    if ($ipApi === 0) {
            $province = pl('province');
            $areaArr = explode($province, $address['area1']);
            if (count($areaArr) > 1 && $areaArr[1]) {
                $_SwitchRegion = $areaArr[1];
            } else {
                $_SwitchRegion = $areaArr[0];
            }
            $whereArea = "INSTR('$_SwitchRegion', C.name)";
        } elseif ($ipApi === 2) {
            if ($jsonResult) {
                $_SwitchRegion = $jsonResult['city'];
            }
            if (empty($_SwitchRegion)) {
                $_SwitchRegion = 'empty region';
            }
            $whereArea = "INSTR('$_SwitchRegion', C.name)";
        } elseif ($ipApi === 3) {
            if ($jsonResult['code'] === 0) {
                $_SwitchRegion = diconv($jsonResult['data']['city'], 'utf-8', CHARSET);
            }
            $whereArea = "INSTR(C.name, '$_SwitchRegion')";
        } elseif ($ipApi === 4) {
            $_SwitchRegion = diconv($jsonResult['city'], 'utf-8', CHARSET);
            $whereArea = "INSTR('$_SwitchRegion', C.name)";
        }
		$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, C.ename city, C.id cityid, C.name cityname, '' district, 0 districtid, '' districtname, 2 regionlevel, C.ename region, C.id regionid, C.name regionname, C.* FROM " . DB::table('common_district') . " C INNER JOIN " . DB::table('common_district') . " P ON C.upid = P.id WHERE C.level = '2' AND C.available = '1' AND $whereArea > 0 ORDER BY C.id LIMIT 1";
		$_RegionInfo = DB::fetch_first($sql);
		if (!$_RegionInfo) {
            if ($ipApi === 0) {
                $_SwitchRegion = $address['area1'];
                $whereArea = "INSTR('$_SwitchRegion', P.name)";
            } elseif ($ipApi === 2) {
                if ($jsonResult) {
                    $_SwitchRegion = $jsonResult['province'];
                }
                if (empty($_SwitchRegion)) {
                    $_SwitchRegion = 'empty region';
                }
                $whereArea = "INSTR('$_SwitchRegion', P.name)";
            } elseif ($ipApi === 3) {
                if ($jsonResult['code'] === 0) {
                    $_SwitchRegion = diconv($jsonResult['data']['region'], 'utf-8', CHARSET);
                }
                $whereArea = "INSTR(P.name, '$_SwitchRegion')";
            } elseif ($ipApi === 4) {
                $_SwitchRegion = diconv($jsonResult['pro'], 'utf-8', CHARSET);
                $whereArea = "INSTR('$_SwitchRegion', P.name)";
            }
			$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, '' city, 0 cityid, '' cityname, '' district, 0 districtid, '' districtname, 1 regionlevel, P.ename region, P.id regionid, P.name regionname, P.* FROM " . DB::table('common_district') . " P WHERE P.level = '1' AND P.available = '1' AND $whereArea > 0 ORDER BY P.id LIMIT 1";
			$_RegionInfo = DB::fetch_first($sql);
			if (!$_RegionInfo) {
				$_RegionInfo = array(
					'url' => trim($_config['defaultregion']['url']),
					'province' => trim($_config['defaultregion']['province']),
					'provinceid' => floatval($_config['defaultregion']['provinceid']),
					'provincename' => trim($_config['defaultregion']['provincename']),
					'city' => strtolower($_config['defaultregion']['city']),
					'cityid' => floatval($_config['defaultregion']['cityid']),
					'cityname' => trim($_config['defaultregion']['cityname']),
					'district' => trim($_config['defaultregion']['district']),
					'districtid' => floatval($_config['defaultregion']['districtid']),
					'districtname' => trim($_config['defaultregion']['districtname']),
					'region' => trim($_config['defaultregion']['region']),
					'regionid' => floatval($_config['defaultregion']['regionid']),
					'regionname' => trim($_config['defaultregion']['regionname']),
					'regionlevel' => intval($_config['defaultregion']['regionlevel'])
				);
			}
		}
	}
    if ($cityMode == 1 && $HTTP_HOST != $_RegionInfo['region'] . $_config['cookie']['cookiedomain'] && $CUR_URI == $CUR_SCRIPT_NAME) {
        $url = 'http://' . $_RegionInfo['region'] . $_config['cookie']['cookiedomain'];
    }
	elseif ($cityMode == 0) {
        $url = $_RegionInfo['url'];
    }
}
if ($_RegionInfo) {
	dsetcookie('province', $_RegionInfo['province'], $_CookieTime);
	dsetcookie('provinceid', $_RegionInfo['provinceid'], $_CookieTime);
	dsetcookie('provincename', $_RegionInfo['provincename'], $_CookieTime);
	dsetcookie('city', $_RegionInfo['city'], $_CookieTime);
	dsetcookie('cityid', $_RegionInfo['cityid'], $_CookieTime);
	dsetcookie('cityname', $_RegionInfo['cityname'], $_CookieTime);
	dsetcookie('district', $_RegionInfo['district'], $_CookieTime);
	dsetcookie('districtid', $_RegionInfo['districtid'], $_CookieTime);
	dsetcookie('districtname', $_RegionInfo['districtname'], $_CookieTime);
	dsetcookie('regionlevel', $_RegionInfo['regionlevel'], $_CookieTime);
	dsetcookie('region', $_RegionInfo['region'], $_CookieTime);
	dsetcookie('regionid', $_RegionInfo['regionid'], $_CookieTime);
	dsetcookie('regionname', $_RegionInfo['regionname'], $_CookieTime);
}
if ($_RegionInfo['url']) $url = $_RegionInfo['url'];
if(stristr($url, 'mobile=')) $url = 'index.php';
if ($url) {
    header("HTTP/1.1 301 Moved Permanently");
    header("location: $url");
	exit;
}
$_G['setting']['bbname'] = $seonav . $_G['setting']['bbname'];
$_G['setting']['navs']['2']['navname'] = $seonav . $_G['setting']['navs']['2']['navname'];
if (!empty($navtitle)) $navtitle = $_RegionInfo['regionname'] . $navtitle;
else $navtitle = $_RegionInfo['regionname'];
$cityLogo = "static/image/logo/{$_RegionInfo['region']}.png";
if (file_exists(DISCUZ_ROOT . '/' . $cityLogo)) $_G['style']['boardlogo'] = '<img src="' . $cityLogo . '" alt="' . $_G['setting']['bbname'] . '" />';
if ($_RegionInfo['regionid']) {
	if (!isset($_RegionInfo['seotitle'])) {
		$_RegionLevel = getcookie('regionlevel');
		if($_RegionLevel == 3)
			$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, C.ename city, C.id cityid, C.name cityname, D.ename district, D.id districtid, D.name districtname, 3 regionlevel, D.ename region, D.id regionid, D.name regionname, D.* FROM " . DB::table('common_district') . " D INNER JOIN " . DB::table('common_district') . " C ON D.upid = C.id INNER JOIN " . DB::table('common_district') . " P ON C.upid = P.id WHERE D.level = '3' AND D.available = '1' AND D.id = '$_RegionInfo[regionid]' ORDER BY D.id LIMIT 1"; 
		elseif($_RegionLevel == 2) 
			$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, C.ename city, C.id cityid, C.name cityname, '' district, 0 districtid, '' districtname, 2 regionlevel, C.ename region, C.id regionid, C.name regionname, C.* FROM " . DB::table('common_district') . " C INNER JOIN " . DB::table('common_district') . " P ON C.upid = P.id WHERE C.level = '2' AND C.available = '1' AND C.id = '$_RegionInfo[regionid]' ORDER BY C.id LIMIT 1";
		else
			$sql = "SELECT P.ename province, P.id provinceid, P.name provincename, '' city, 0 cityid, '' cityname, '' district, 0 districtid, '' districtname, 1 regionlevel, P.ename region, P.id regionid, P.name regionname, P.* FROM " . DB::table('common_district') . " P WHERE P.level = '1' AND P.available = '1' AND P.id = '$_RegionInfo[regionid]' ORDER BY P.id LIMIT 1";
		$_RegionInfo = DB::fetch_first($sql);
	}
	if ($_RegionInfo) {
		$navtitle .= $_RegionInfo['seotitle'];
		$metakeywords .= $_RegionInfo['seokeywords'];
		$metadescription .= $_RegionInfo['seodescription'];
	}
}
$_RegionInfo['usewww'] = intval($var['usewww']);
?>