if (typeof(__RegionInfo) == 'object' && typeof(__RegionInfo.cookiedomain) == 'string') {
    if (__RegionInfo.cookiedomain.substr(0, 1) == '.') {
	    __RegionInfo.cookiedomain = __RegionInfo.cookiedomain.substr(1);
    }
    if (__RegionInfo.region != null && __RegionInfo.region != '') {
        __RegionInfo.region = __RegionInfo.region.toLowerCase();
        if ((location.host == __RegionInfo.cookiedomain || (__RegionInfo.usewww == '0' && location.host == 'www.' + __RegionInfo.cookiedomain)) && __RegionInfo.citymode == '1') {
            location.href = 'http://' + __RegionInfo.region + '.' + __RegionInfo.cookiedomain;
        }
    }
}
function $G(id) {
	return document.getElementById(id);
}
function $$(id) {
	return document.getElementById(id);
}
function StopPropagation(e) {  
    e = e || window.event;  
    if(e.stopPropagation) {
        e.stopPropagation();  
    } else {  
        e.cancelBubble = true;
    }  
} 
function ShowProvinceList() {
    if ($G('changecity_menu') && typeof(provArray) == 'object' && typeof(__RegionInfo.cookiedomain) == 'string'){
        var province = provinceList = '';
        provinceList += '<div id="J_HeaderCityList" class="wrap">';
        provinceList += '   <div class="J_SeatProvince">';
        provinceList += '       <ul class="province-list">';
		if (__RegionInfo.allowwww == '0' && typeof(__RegionInfo.allsite) == 'string' && __RegionInfo.allsite.length > 0){
			if (__RegionInfo.citymode == '1')
				provinceList += '           <li' + (0 == __RegionInfo.provinceid ? ' class="tb-selected"' : '') + '><a href="http://' + __RegionInfo.allsite + '.' + __RegionInfo.cookiedomain + '">总站</a></li>';
			else
				provinceList += '           <li' + (0 == __RegionInfo.provinceid ? ' class="tb-selected"' : '') + '><a href="plugin.php?id=dicky_multicityswitch:index&switchregion=' + __RegionInfo.allsite + '&r=' + Math.random() + '">总站</a></li>';
		}
        for(var i = 0;i < provArray.length;i++) {
            if(provArray[i][1] == 0) {
                province = provArray[i][0];
				if (__RegionInfo.citymode == '1')
					provinceList += '           <li' + (provArray[i][2] == __RegionInfo.provinceid ? ' class="tb-selected"' : '') + '><a href="' + (provArray[i][3].length > 0 ? 'http://' + provArray[i][3].toLowerCase() + '.' + __RegionInfo.cookiedomain : 'javascript:') + '" onmouseover="ShowCityListByProvinceId(this, ' + provArray[i][2] + ')" onmouseout="' + (provArray[i][2] == __RegionInfo.provinceid ? '' : 'this.parentNode.className = \'\';') + '">' + province + '</a></li>';
				else
					provinceList += '           <li' + (provArray[i][2] == __RegionInfo.provinceid ? ' class="tb-selected"' : '') + '><a href="' + (provArray[i][3].length > 0 ? 'plugin.php?id=dicky_multicityswitch:index&switchregion=' + provArray[i][3].toLowerCase() + '&r=' + Math.random() : 'javascript:') + '" onmouseover="ShowCityListByProvinceId(this, ' + provArray[i][2] + ')" onmouseout="' + (provArray[i][2] == __RegionInfo.provinceid ? '' : 'this.parentNode.className = \'\';') + '">' + province + '</a></li>';
            }
        }
        provinceList += '       </ul>';
        provinceList += '   </div>';
        provinceList += '   <div id="hd-city-list" class="J_SeatCity hidden" style="position: absolute; z-index: 10001; top: 156px; left: 93px; "><ul class="city-list"></ul></div>';
		provinceList += '   <div id="hd-district-list" class="J_SeatCity hidden" style="position: absolute; z-index: 10001; top: 156px; left: 93px; "><ul class="city-list"></ul></div></div>';
        $G('changecity_menu').innerHTML = provinceList;
    }
}
function ShowCityListByProvinceId(provinceObj, provinceId) {
    if ($G('hd-city-list') && provinceObj && typeof(provArray) == 'object'){
        var city = cityList = '';
		if ($G('hd-district-list')) $G('hd-district-list').style.display = 'none';
	    for(var j = 0;j < provArray.length;j++) {
		    if(provArray[j][1] == provinceId) {
			    city = provArray[j][0];
                if (__RegionInfo.citymode == '1') {
			        cityList += '   <li><a' + (provArray[j][2] == __RegionInfo.cityid ? ' class="a-hover"' : '') + ' href="' + (provArray[j][3].length > 0 ? 'http://' + provArray[j][3].toLowerCase() + '.' + __RegionInfo.cookiedomain : 'javascript:ShowAlert();') + '" onmouseover="ShowDistrictListByCityId(this, ' + provArray[j][2] + ')" onmouseout="' + (provArray[j][2] == __RegionInfo.cityid ? '' : 'this.parentNode.className = \'\';') + '">' + city + '</a></li>';
                }
                else {
			        cityList += '   <li><a' + (provArray[j][2] == __RegionInfo.cityid ? ' class="a-hover"' : '') + ' href="' + (provArray[j][3].length > 0 ? 'plugin.php?id=dicky_multicityswitch:index&switchregion=' + provArray[j][3].toLowerCase() + '&r=' + Math.random() : 'javascript:ShowAlert();') + '" onmouseover="ShowDistrictListByCityId(this, ' + provArray[j][2] + ')" onmouseout="' + (provArray[j][2] == __RegionInfo.cityid ? '' : 'this.parentNode.className = \'\';') + '">' + city + '</a></li>';
                }
		    }
	    }
        if(cityList.length > 0) {
            $G('hd-city-list').style.display = '';
            cityList = '<ul class="city-list" style="background-position: -83px -16px;">' + cityList + '</ul>';
        }
		else $G('hd-city-list').style.display = 'none';
	    provinceObj.parentNode.className = 'tb-hover';
        $G('hd-city-list').innerHTML = cityList;
	    $G('hd-city-list').onmouseover = function() {this.className = 'J_SeatCity';provinceObj.parentNode.className = 'tb-hover';};
	    $G('hd-city-list').onmouseout = function() {this.className = 'J_SeatCity';if (provinceId != __RegionInfo.provinceid) {provinceObj.parentNode.className = '';}};
        $G('hd-city-list').className = 'J_SeatCity';
		var top = provinceObj.offsetTop + provinceObj.offsetHeight - provinceObj.parentNode.offsetHeight + 10 + 'px';
		var left = provinceObj.offsetLeft + provinceObj.parentNode.offsetWidth + 8 + 'px';
		if (provinceObj.offsetTop == 0) {
			top = parseInt(fetchOffset(provinceObj, 1)['top']) + provinceObj.offsetHeight - provinceObj.parentNode.offsetHeight - 25 + 'px';
			left = parseInt(fetchOffset(provinceObj, 1)['left']) + provinceObj.parentNode.offsetWidth - 10 + 'px';
		}
        $G('hd-city-list').style.top = top;
        $G('hd-city-list').style.left = left;
    }
}
function ShowDistrictListByCityId(cityObj, cityId) {
    if ($G('hd-district-list') && cityObj && typeof(provArray) == 'object'){
        var city = cityList = '';
	    for(var j = 0;j < provArray.length;j++) {
		    if(provArray[j][1] == cityId) {
			    city = provArray[j][0];
                if (__RegionInfo.citymode == '1') {
			        cityList += '   <li><a' + (provArray[j][2] == __RegionInfo.districtid ? ' class="a-hover"' : '') + ' href="' + (provArray[j][3].length > 0 ? 'http://' + provArray[j][3].toLowerCase() + '.' + __RegionInfo.cookiedomain : 'javascript:ShowAlert();') + '">' + city + '</a></li>';
                }
                else {
			        cityList += '   <li><a' + (provArray[j][2] == __RegionInfo.districtid ? ' class="a-hover"' : '') + ' href="' + (provArray[j][3].length > 0 ? 'plugin.php?id=dicky_multicityswitch:index&switchregion=' + provArray[j][3].toLowerCase() + '&r=' + Math.random() : 'javascript:ShowAlert();') + '">' + city + '</a></li>';
                }
		    }
	    }
        if(cityList.length > 0) {
            $G('hd-district-list').style.display = '';
            cityList = '<ul class="city-list" style="background-position: -83px -16px;">' + cityList + '</ul>';
        }
		else $G('hd-district-list').style.display = 'none';
	    cityObj.parentNode.className = 'tb-hover';
        $G('hd-district-list').innerHTML = cityList;
	    $G('hd-district-list').onmouseover = function() {this.className = 'J_SeatCity';/*cityObj.parentNode.className = 'tb-hover';*/};
	    $G('hd-district-list').onmouseout = function() {this.className = 'J_SeatCity hidden';if (cityId != __RegionInfo.cityid) {cityObj.parentNode.className = '';}};
        $G('hd-district-list').className = 'J_SeatCity';
		var top = cityObj.offsetTop + cityObj.offsetHeight - cityObj.parentNode.offsetHeight + 10 + 'px';
		var left = cityObj.offsetLeft + cityObj.parentNode.offsetWidth + 8 + 'px';
		top = parseInt(fetchOffset(cityObj, 1)['top']) + cityObj.offsetHeight - cityObj.parentNode.offsetHeight - 25 + 'px';
		left = parseInt(fetchOffset(cityObj, 1)['left']) + cityObj.parentNode.offsetWidth - 10 + 'px';
        $G('hd-district-list').style.top = top;
        $G('hd-district-list').style.left = left;
    }
}
ShowProvinceList();
function changeProvince(selProvince, selCity, selDistrict, str, needAllsite){
    if ($G('city_id' + str) && typeof(provArray) == 'object'){
        $G('city_id' + str).length = 0;
        var city = '';
        var newOption = new Option('选择市', '');
        $G('city_id' + str).add(newOption);
		if (needAllsite == 1 && selProvince.toString().length > 0 && selProvince == 0 && typeof(__RegionInfo.allsite) == 'string' &&  __RegionInfo.allsite.length > 0) {
			if (__RegionInfo.allowwww == '0') newOption = new Option('总站', 0);
			if (selProvince == 0) newOption.selected = true;
			$G('city_id' + str).add(newOption);
		}
        for(var j = 0;j < provArray.length;j++) {
            if(selProvince > 0 && provArray[j][1] == selProvince) {
                city = provArray[j][0];
                newOption = new Option(city, provArray[j][2]);
                if (selCity == provArray[j][2]) newOption.selected = true;
                $G('city_id' + str).add(newOption);
            }
        }
        changeCity(selProvince, selCity, selDistrict, str, needAllsite);
    }
}
function changeCity(selProvince, selCity, selDistrict, str, needAllsite){
    if ($G('district_id' + str) && typeof(provArray) == 'object'){
        $G('district_id' + str).length = 0;
        var district = '';
        var newOption = new Option('不限', '');
        $G('district_id' + str).add(newOption);
        for(var j = 0;j < provArray.length;j++) {
            if(selCity > 0 && provArray[j][1] == selCity) {
                district = provArray[j][0];
                newOption = new Option(district, provArray[j][2]);
                if (selDistrict == provArray[j][2]) newOption.selected = true;
                $G('district_id' + str).add(newOption);
            }
        }
    }
}
function selectProvince(selProvince, selCity, selDistrict, str, needAllsite) {
    if ($G('province_id' + str) && typeof(provArray) == 'object'){
		$G('province_id' + str).length = 1;
        var province = '';
        var newOption = null;
		if (needAllsite == 1 && typeof(__RegionInfo.allsite) == 'string' &&  __RegionInfo.allsite.length > 0) {
			if (__RegionInfo.allowwww == '0') newOption = new Option('总站', 0);
			if (selProvince == 0) newOption.selected = true;
			$G('province_id' + str).add(newOption);
		}
        for(var j = 0;j < provArray.length;j++) {
            if(provArray[j][1] == 0) {
                province = provArray[j][0];
                newOption = new Option(province, provArray[j][2]);
                if (selProvince == provArray[j][2]) newOption.selected = true;
                $G('province_id' + str).add(newOption);
            }
        }
        changeProvince(selProvince, selCity, selDistrict, str, needAllsite);
    }
}
function selectCity(str) {
	if ($G('province_id' + str) && typeof(provArray) == 'object'){
		if ($G('province_id' + str).value.length == 0) {
			alert('请选择省！');
			$G('province_id' + str).focus();
			return false;
		}
	}
	if ($G('city_id' + str) && typeof(provArray) == 'object' && typeof(__RegionInfo.cookiedomain) == 'string'){
		var selCityId = $G('city_id' + str).value;
		var selCity = '';
		if(selCityId.length == 0) selCityId = $G('province_id' + str).value;
		if (selCityId != null && selCityId > 0) {
			for(var i = 0;i < provArray.length;i++) {
				if(provArray[i][2] == selCityId) {
					selCity = provArray[i][3];
					break;
				}
			}
		}
		var selDistrictId = $G('district_id' + str).value;
		var selDistric = '';
		if (selDistrictId != null && selDistrictId > 0) {
			for(var i = 0;i < provArray.length;i++) {
				if(provArray[i][2] == selDistrictId) {
					selCity = provArray[i][3];
					break;
				}
			}
		}
		if (selCityId.length > 0 && selCityId == 0 && typeof(__RegionInfo.allsite) == 'string' && __RegionInfo.allsite.length > 0) selCity = __RegionInfo.allsite;
		if (selCity.length == 0) {
			ShowAlert();
			return false;
		}
		if (__RegionInfo.citymode == '1')
			location.href = 'http://' + selCity + '.' + __RegionInfo.cookiedomain;
		else
			location.href = 'plugin.php?id=dicky_multicityswitch:index&switchregion=' + selCity + '&r=' + Math.random();
	}
}
function PostToAll(flag) {
    if ($G('spanDistrict')) {
        if (flag) $G('spanDistrict').style.display = 'none';
        else {
			if (__RegionInfo.regionlevel == '3') $G('spanDistrict').style.display = 'none';
			else $G('spanDistrict').style.display = '';
		}
    }
}
function ShowAlert() {
	alert('请在后台本插件地区设置中设置该地区的英文名称！');
	return false;
}