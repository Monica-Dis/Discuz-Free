<?php
/*
	Name: 【Dicky】多城市切换(MultiCitySwitch)链接版
	Author: Dicky
	应用更新支持：https://dism.taobao.com
	本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
	我们致力于为站长提供正版Discuz!应用而努力
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_dicky_multicityswitch {
	function global_header_mobile() {
        global $_G, $cityMode, $_RegionInfo, $catlist, $forumlist, $forum_favlist, $favforumlist, $seonav, $navtitle, $metakeywords, $metadescription;
        if ($_GET['inajax']) return;
        loadcache('plugin');
        $var = $_G['cache']['plugin']['dicky_multicityswitch'];
        $jsPath = 'source/plugin/dicky_multicityswitch/js/';
        $cssPath = 'source/plugin/dicky_multicityswitch/css/';
        $cityMode = $var['citymode'];
        include_once dirname(__FILE__) . '/./ipredirect.php';
        include template('dicky_multicityswitch:multicityswitch');
        return $return;
    }
}
//From: Dism_taobao_com
?>