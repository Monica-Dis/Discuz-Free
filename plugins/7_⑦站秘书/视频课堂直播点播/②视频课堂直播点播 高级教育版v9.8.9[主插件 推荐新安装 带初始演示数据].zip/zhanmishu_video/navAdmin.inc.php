<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/function/common_function.php';
$videoHander = zhanmishu_video::getInstance();

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_video&pmod=navAdmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_video&pmod=navAdmin';
echo '<br>';
echo '<br>';

if (submitcheck('nav_listAdmin')) {
    $images = zhanmishu_video::uploadimg('zhanmishu_video/', true, '100', '100', '1');
    $nav_list = array();
    foreach ($_GET['cat_name'] as $key => $value) {
        if (!$value || in_array($key, $_GET['delete'])) {
            continue;
        }
        $nav_list[] = array(
            'order'=>$_GET['order'][$key],
            'cat_name'=>$_GET['cat_name'][$key],
            'cat_icon'=>$images[$key] ? $images[$key] : $_GET['cat_icon'][$key],
            'cat_id'=>$_GET['cat_id'][$key],
            'url'=>$_GET['url'][$key],
            'urlType'=>$_GET['urlType'][$key],
            'platform'=>$_GET['platform'][$key],
        );
    }

    $videoHander->update_nav_listcache_init($nav_list);
    cpmsg(lang('plugin/zhanmishu_video', 'update_nav_list_success'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=navAdmin','success');

}else{
        $nav_list = $videoHander->get_nav_list(true);
        showformheader($formurl.'&act=editcat','enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_video','nav_list'));
        showsubtitle(array(
            lang('plugin/zhanmishu_video', 'delete'),
            lang('plugin/zhanmishu_video', 'order'),
            lang('plugin/zhanmishu_video', 'nav_list_name'),
            lang('plugin/zhanmishu_video', 'imgurl'),
            lang('plugin/zhanmishu_video', 'url')
        ));


        foreach ($nav_list as $key => $value) {
            $value['id'] = $key;
            $linkTypeSelect = array(
                $value['urlType'] == '0' ? ' selected' : '',
                $value['urlType'] == '1' ? ' selected' : '',
            );
            // 选中状态
            $recommendType = array(
                $value['platform'] == '0' ? ' selected' : '',
                $value['platform'] == '1' ? ' selected' : '',
                $value['platform'] == '2' ? ' selected' : '',
                $value['platform'] == '3' ? ' selected' : '',
            );

            $image = $value['cat_icon'] ? $value['cat_icon'] : 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
            $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'
            <select name="urlType[]">
                <option value ="0" '.$linkTypeSelect[0].'>'.lang('plugin/zhanmishu_app', 'URL').'</option>
                <option value ="1" '.$linkTypeSelect[1].'>'.lang('plugin/zhanmishu_app', 'appPage').'</option>
            </select>';
            $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]">
                    <option value ="0" '.$recommendType[0].'>'.lang('plugin/zhanmishu_app', 'public').'</option>
                    <option value ="1" '.$recommendType[1].'>'.lang('plugin/zhanmishu_app', 'H5').'</option>
                    <option value ="2" '.$recommendType[2].'>'.lang('plugin/zhanmishu_app', 'minapp').'</option>
                    <option value ="3" '.$recommendType[3].'>'.lang('plugin/zhanmishu_app', 'app').'</option>
                </select>';


            showformheader($formurl.'&act=editcat','enctype="multipart/form-data"');
                $videoHanderarr = array(
                '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                '<input type="text" required class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                '<input type="text" required class="txt" name="cat_name['.$value['id'].']" value="'.$value['cat_name'].'" />',
                '<img src="'.$image.'" width="40px" height="40px"><input type="text" required class="txt" style="width:100px;" name="cat_icon['.$value['id'].']" placeholder="'.lang('plugin/zhanmishu_app','image_placeholder').'" value="'.$value['cat_icon'].'" />
                <input style="width:140px" type="file"  name="image_file['.$value['id'].']" value="" />',
                '<input type="text" required  name="url['.$value['id'].']" value="'.$value['url'].'" />'.$urlType
            );
            showtablerow('',array('class="td25"', 'class="td25"', 'class="td22"', 'class="td22"', 'class="td22"', 'class="td22"'), $videoHanderarr);

        }
        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_video', 'addnav_list').'</a></div></tr>';

        showsubmit('nav_listAdmin',lang('plugin/zhanmishu_video', 'submit'));

        showtablefooter(); /*Dism_taobao-com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/   

        $image = 'source/plugin/zhanmishu_app/template/images/noimg.jpg';
        $placeholder = lang('plugin/zhanmishu_app','image_placeholder');
        $urlType = '<br>'.lang('plugin/zhanmishu_app','urlType').'<select name="urlType[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'URL').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'appPage').'</option></select>';
        $urlType .= '<br>'.lang('plugin/zhanmishu_app','platform').'<select name="platform[]"><option value ="0">'.lang('plugin/zhanmishu_app', 'public').'</option><option value ="1">'.lang('plugin/zhanmishu_app', 'H5').'</option><option value ="2">'.lang('plugin/zhanmishu_app', 'minapp').'</option><option value ="3">'.lang('plugin/zhanmishu_app', 'app').'</option></select>';
    echo <<<EOT
    <script type="text/JavaScript">
        var rowtypedata = [
            [
                [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                [1,'<input type="text" required class="txt" name="order[]" value="">', 'td25'],
                [1,'<input type="text" required class="txt" name="cat_name[]" value="">', 'td22'],
                [1,'<img src="{$image}" width="40px" height="40px"><input type="text" class="txt" style="width:100px;" name="cat_icon[]" placeholder="{$placeholder}" value="" /><input style="width:140px" type="file"  name="image_file[]" value="" />', 'td22'],
                [1,'<input type="text" required class="" name="url[]" value="">{$urlType}', 'td22']

            ]
            
        ];
    </script>
EOT;

    



}
//From: Dism·taobao·com
?>