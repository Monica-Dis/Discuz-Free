<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
$videoHander = zhanmishu_video::getInstance();

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_video&pmod=teacherAdmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_video&pmod=teacherAdmin';

$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;


$appHander = zhanmishu_app::getInstance();
$appHander->verifySetting();

$_GET['method'] = $_GET['method'] ? $_GET['method'] : 'teacherAdmin';
$pageAdminItem = array(
    'normal'=>array(
        'menu'=> array(
            array(
                'title'=>lang('plugin/zhanmishu_video','teacherEdit'),
                'link'=>$mpurl.'&method=teacherEdit',
                'selected'=> $_GET['method'] == 'teacherEdit' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_video','teacherAdmin'),
                'link'=>$mpurl.'&method=teacherAdmin',
                'selected'=> $_GET['method'] == 'teacherAdmin' ? 'selected' : ''
            )
        ),
    )
);
zhanmishu_app_admin::importPureCss();
zhanmishu_app_admin::importJquery();
zhanmishu_app_admin::menuHorizontal($pageAdminItem['normal']['title'],$pageAdminItem['normal']['menu']);

if ($_GET['method'] == 'teacherAdmin') {
    $field = array();
    if ($_GET['cid'] > 0) {
        $field['cid'] = $_GET['cid'] + 0;
    }
    if ($_GET['useUid']) {
        $field['useUid'] = $_GET['useUid'] + 0;
    }
    if ($_GET['isUsed'] > 0) {
        $field['isUsed'] = $_GET['isUsed'] == 2 ? 1 : 0;
    }
    if ($_GET['teacher_code']) {
        $field['teacher_code'] = daddslashes($_GET['teacher_code']);
    }

    $num = zhanmishu_video_model_teacher::fetch_num($field);
    $pages= ceil($num / $perpage);
    $start = $num - ($num - $perpage*$curpage+$perpage);
    $teachers = zhanmishu_video_model_teacher::fetch_all_admin_format($start, $perpage, 'desc', $field);

    if (submitcheck('outputsubmit')) {
        ob_end_clean();
        set_time_limit(0);
        $fileName = 'teacher-'.TIMESTAMP;
        header('Content-Encoding: none');
        header('Content-Type: application/vnd.ms-excel');   //header设置
        header("Content-Disposition: attachment;filename=".$fileName.".csv");
        header('Cache-Control: max-age=0');

        $fp = fopen('php://output','a');    //打开php文件句柄，php://output表示直接输出到PHP缓存,a表示将输出的内容追加到文件末尾
        
        for ($i=0; $i < $pages; $i++) {
            if ($i == 0) {
                foreach ($teachers as $key => $value) {
                    if (is_array($value)) {
                         fputcsv($fp, zhanmishu_video::auto_charset_change(zhanmishu_video_model_teacher::outputFormat($value), CHARSET, 'gbk'));
                    }
                }
            }else{
                $starti = $num - ($num - $perpage*($i + 1)+$perpage);
                $teachersi = zhanmishu_video_model_teacher::fetch_all_admin_format($starti, $perpage, 'desc', $field);
                foreach ($teachersi as $key => $value) {
                    if (is_array($value)) {
                         fputcsv($fp, zhanmishu_video::auto_charset_change(zhanmishu_video_model_teacher::outputFormat($value), CHARSET, 'gbk'));
                    }
                }
            }
        }
        exit();
    }

    showtips(lang('plugin/zhanmishu_video', 'teacherTips'),'',true,lang('plugin/zhanmishu_video', 'teacherTipsTitle'));

    showtableheader(); /*dism·taobao·com*/

    showformheader('plugins&operation=config&identifier=zhanmishu_video&pmod=teacherAdmin&method=teacherAdmin');
    $_G['showsetting_multirow'] = 1;
    $_G['showsetting_multirow_n'] = 0;
    showsetting(lang('plugin/zhanmishu_video', 'teacher_name'), 'teacher_name', $_GET['teacher_name'], 'text');
    showsubmit('searchsubmit', lang('plugin/zhanmishu_video', 'searchsubmit'));
    showtablefooter(); /*Dism_taobao-com*/

    showformheader($formurl.'&method=teacherAdmin','enctype="multipart/form-data"');
    showtableheader(lang('plugin/zhanmishu_video','index_item_intro'));
    showsubtitle(array(
        lang('plugin/zhanmishu_video', 'uid'),
        lang('plugin/zhanmishu_video', 'teacher_name'),
        lang('plugin/zhanmishu_video', 'teacher_img'),
        // lang('plugin/zhanmishu_video', 'teacher_intro'),
        // lang('plugin/zhanmishu_video', 'teacher_content'),
        lang('plugin/zhanmishu_video', 'teacher_helper_ids'),
        lang('plugin/zhanmishu_video', 'score'),
        lang('plugin/zhanmishu_video', 'replies'),
        lang('plugin/zhanmishu_video', 'course_num'),
        lang('plugin/zhanmishu_video', 'videos_num'),
        lang('plugin/zhanmishu_video', 'teacher_per'),
        lang('plugin/zhanmishu_video', 'dateline'),
        lang('plugin/zhanmishu_video', 'act')
    ));
    foreach ($teachers as $key => $value) {
        showtablerow('class="partition"',array('class="td25"', 'class="td25"', 'class="td28"', 'class="td25"', 'class="td25"'),$value);
    }

    $multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
    showtablefooter(); /*Dism_taobao-com*/
    echo $multi;
    showformfooter(); /*dis'.'m.tao'.'bao.com*/  
}else if ($_GET['method'] == 'teacherDelete') {
    if ($_GET['formhash'] == formhash()) {
        $teacher = zhanmishu_video_model_teacher::delete($_GET['teacherid'] + 0);
        cpmsg(lang('plugin/zhanmishu_video', 'success'),dreferer(),'success');
    }
}else if ($_GET['method'] == 'teacherEdit') {
      // `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `teacher_name` varchar(127) NOT NULL DEFAULT '',
      // `teacher_img` varchar(1000) NOT NULL DEFAULT '',
      // `teacher_helper_ids` varchar(1000) NOT NULL DEFAULT '',
      // `teacher_per` float(7,3) unsigned NOT NULL DEFAULT '0.00',
      // `teacher_intro` varchar(1000) NOT NULL DEFAULT '',
      // `teacher_content` mediumtext NOT NULL,
      // `score` smallint(3) NOT NULL DEFAULT '0',
      // `replies` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `scores` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `course_num` smallint(3) NOT NULL DEFAULT '0',
      // `videos_num` smallint(3) NOT NULL DEFAULT '0',
      // `dateline` int(10) unsigned NOT NULL DEFAULT '0',
      // PRIMARY KEY (uid),
      // KEY teacher_name (teacher_name),
      // KEY dateline (dateline)


    if (submitcheck('editteacherSubmit')) {    
        if ($_GET['uid']) {
            $teacher['uid'] = $_GET['uid'] + 0;
            $teacher = zhanmishu_video_model_teacher::fetch($_GET['uid'] + 0);
        }else{
            $teacher = array();
        }
        $images = zhanmishu_video::uploadimg();
        $teacher['teacher_img'] = $images['teacher_img'] ? $images['teacher_img'] : $_GET['teacher_img'];

        $teacher['teacher_name'] = daddslashes($_GET['teacher_name']);
        $teacher['teacher_per'] = number_format($_GET['teacher_per'], 3);
        $teacher['teacher_helper_ids'] =  zhanmishu_course::settingNumberFormat($_GET['teacher_helper_ids'], 'string');
        $teacher['teacher_intro'] = strip_tags(trim($_GET['teacher_intro']));
        $teacher['teacher_content'] = zhanmishu_course::contentFormat($_GET['teacher_content'], 'ENCODE');
        $teacher['dateline'] = TIMESTAMP;

        zhanmishu_video_model_teacher::insert($teacher);

    
        cpmsg(lang('plugin/zhanmishu_video', 'success'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=teacherAdmin&method=teacherAdmin','success');
    }


    if ($_GET['uid']) {
        $teacher = zhanmishu_video_model_teacher::fetch($_GET['uid'] + 0, true);
    }
    showformheader($formurl.'&method=teacherEdit','enctype="multipart/form-data"');
    showtableheader(); /*dism·taobao·com*/
    if ($teacher['uid']) {
        showsetting(lang('plugin/zhanmishu_video', 'uid'), 'uid', $teacher['uid'], 'text','','',lang('plugin/zhanmishu_video', 'uid_desc'),'size="10"');
    }
    showsetting(lang('plugin/zhanmishu_video', 'teacher_name'), 'teacher_name', $teacher['teacher_name'], 'text','','',lang('plugin/zhanmishu_video', 'teacher_name_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'teacher_img'), 'teacher_img', $teacher['teacher_img'], 'filetext','','',lang('plugin/zhanmishu_video', 'teacher_img_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'teacher_helper_ids'), 'teacher_helper_ids', $teacher['teacher_helper_ids'], 'text','','',lang('plugin/zhanmishu_video', 'teacher_helper_ids_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'teacher_per'), 'teacher_per', $teacher['teacher_per'], 'text','','',lang('plugin/zhanmishu_video', 'teacher_per_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'teacher_intro'), 'teacher_intro', $teacher['teacher_intro'], 'textarea','','',lang('plugin/zhanmishu_video', 'teacher_intro_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'teacher_content'), 'teacher_content', $teacher['teacher_content'], 'textarea','','',lang('plugin/zhanmishu_video', 'teacher_content_desc'),'size="10"');
    showsubmit('editteacherSubmit');
    showtablefooter(); /*Dism_taobao-com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/

}
