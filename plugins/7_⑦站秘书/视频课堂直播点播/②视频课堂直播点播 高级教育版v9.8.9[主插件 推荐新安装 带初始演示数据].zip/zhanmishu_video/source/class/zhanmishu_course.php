<?php
/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc && plugin by zhanmishu.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *    	应用更新支持：https://dism.taobao.com $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';

class zhanmishu_course extends zhanmishu_base{
	public $cachefile = 'zhanmishu_video';
    public function cacheKey(){
        return 'zhanmishu_video';
    }	
    public function updatecache(){
    	require_once libfile('function/cache');
    	loadcache(self::cacheKey(), true);
    }
	public function get_cache_file(){
		return DISCUZ_ROOT.'./data/sysdata/cache_'.$this->cachefile.'.php';
	}
 
	public function Curl($url){
		global $_G;
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //不验证证书
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //不验证证书
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt ($ch, CURLOPT_REFERER, $_G['siteurl']);
		$resultj = curl_exec($ch);
		curl_close($ch); 

		return json_decode($resultj,true);
	}

	public function afterCreate()
	{
		global $_G;
		loadcache('plugin');
		$config = $_G['cache']['plugin']['zhanmishu_video'];
		$config['realname'] = $config['realname'] ? $config['realname'] : 'realname';
		$config['idcard'] = $config['idcard'] ? $config['idcard'] : 'idcard';
	    $config['vipgroup'] = self::video_vipgroups($config['vipgroup']);
		$config['rightclick'] = json_encode(self::auto_charset_change(self::video_vipgroups($config['rightclick'])));
		$config['groupselect'] = unserialize($config['groupselect']);
		$config['teachergroup'] = unserialize($config['teachergroup']);

		if (!$config['OssEncryptionUrl']) {
			$config['OssEncryption'] = false;
		}
		if ($config['isH5Spa'] && !is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_app/source/class/zhanmishu_app_user_controller.php')) {
			$config['isH5Spa'] = false;
		}

		$this->config = $config;
		$this->config['isMagapp'] = '0';
		//magapp
		$userAgent = $_SERVER['HTTP_USER_AGENT'];
		$info = strstr($userAgent, "MAGAPPX");
		if ($info) {
			$this->config['isMagapp'] = '1';
			$info = explode("|",$info);
		}

		if (!$_G['uid'] && $info && !empty($info)) {
			$agent= array(
				"version"=>$info[1],//客户端版本信息 4.0.0
                "client"=>$info[2],//客户端信息可以获取区分android或ios 可以获取具体机型
                "site"=>$info[3],  //站点名称  如lxh
                "device"=>$info[4],//设备号    客户端唯一设备号
                "sign"=>$info[5],  //签名     可以验证请求是否伪造 签名算法见下面详细说明
                "signCloud"=>$info[6],//云端签名 这个签名马甲内部使用
                "token"=>$info[7]
            );
            $this->config['agent'] = $agent;

			if ($config['magapp_host'] && $config['magapp_secret'] && $agent['token']) {
				$this->get_magapp_user_info();
			}else if ($config['magapp_host'] && $config['magapp_secret'] && $config['magapp_login']) {
				$_G['magapp_login'] = 1;
			}
		}

	}
	static function strToArray($str){
		$str = str_replace(array("\r\n", "\r", "\n"), array('$#','$#','$#'), $str);
		$arr = explode('$#', $str);

		$arr = array_filter($arr);
		return $arr;
	}
	static function video_vipgroups($str){
		$arr = self::strToArray($str);
		if (empty($arr)) {
			return false;
		}
		$return = array();
		foreach ($arr as $key => $value) {
			$tmp  = explode('=', $value);
			$return[$tmp[0]] = $tmp[1];
		}

		return $return;
	}
	// $params  = array(
	// 	'out_trade_no'=>$out_trade_no,
	// 	'total_fee'=>strval($o['course_price'] / 100),
	// 	'intro'=>remove_nopromissword($o['course_intro']),
	// 	'name'=>remove_nopromissword($o['course_name']),
	// 	'bank_type'=> daddslashes($_GET['bank_type']),
	// 	'num'=>'1',
	// 	'price'=>strval($o['course_price'] / 100),
	// 	'return_url'=>$return_url,
	// 	);
	public function magappPay($params = array()){
		global $_G;
		if (!empty($params)) {
			return false;
		}
		$data = array();
		$data['trade_no'] = $params['out_trade_no'];
		$data['callback'] = $params['return_url'];
		$data['amount'] = $params['total_fee'];
		$data['title'] = $params['name'];
		$data['intro'] = $params['intro'];
		$data['des'] = $params['intro'];
		$data['remark'] = $params['intro'];
		$data['secret'] = $this->config['magapp_secret'];

		$result  = dfsockopen($this->config['magapp_host'].'/core/pay/pay/unifiedOrder', 0, $data);
		return json_decode($result, true);
	}
	public function get_magapp_user_info(){
		global $_G;
		$url =  $this->config['magapp_host'].'/mag/cloud/cloud/getUserInfo?token='.$this->config['agent']['token'].'&secret='.$this->config['magapp_secret'];
		$userInfo = $this->Curl(trim($url));

		if ($userInfo['data']['user_id']) {
			
			loaducenter();
			$member = getuserbyuid($userInfo['data']['user_id'], 1);
			require_once libfile('function/member');
			$cookietime = 1296000;
			setloginstatus($member, $cookietime);
			dsetcookie('lip', $_G['member']['lastip'].','.$_G['member']['lastvisit']);
			C::t('common_member_status')->update($_G['uid'], array('lastip' => $_G['clientip'], 'lastvisit' =>TIMESTAMP, 'lastactivity' => TIMESTAMP));
		}

	}
	public function ZmsIsWepayExists(){
		return is_dir(DISCUZ_ROOT.'./source/plugin/zhanmishu_wepay');
	}

	public function get_one_course_byfield($field){
		return C::t("#zhanmishu_video#zhanmishu_video_course")->get_one_course_byfield($field);
	}
	public function delete_course($cid, $isRealDel = true){
		if (!$isRealDel) {
			return C::t("#zhanmishu_video#zhanmishu_video_course")->update($cid,array('isdel'=>'1'));
		}
		return C::t("#zhanmishu_video#zhanmishu_video_course")->delete($cid);
	}
	public function auto_to_utf8($data){
		return self::auto_charset_change($data);
	}


	public function get_type_course_num($field=array()){
		return C::t("#zhanmishu_video#zhanmishu_video_course")->get_type_course_num($field);
	}
	public function add_courseselltimes($cid,$num='1'){
		$course = $this->get_course_bycid($cid);
		return C::t("#zhanmishu_video#zhanmishu_video_course")->update($cid,array('selltimes'=>$course['selltimes'] + $num));
	}

	public function get_rand_trade_no($cid='',$hid='',$oid=''){
		return 'k'.$cid.'h'.$hid.'o'.$oid.'t'.TIMESTAMP.substr(str_shuffle('abcdefghijklmnopqrstuvwxyz1234567890'), 0, 6);
	}
	public function randCouponCode($length = 12){
		return substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890'), 0, 12);
	}

	public function get_type_course_fmt($start = 0, $limit = 0, $sort = '',$type = '',$field){
		global $url,$zhanmishu_videoconf;
		$url = ADMINSCRIPT.'?action='.$url;
		$courses = $this->get_type_course($start, $limit, $sort,$type,$field);
		$courses_fmt = array();
		
		foreach ($courses as $key => $value) {
			$this->update_course_info($value['cid']);
			$courses_fmt[$key]['cid'] = $value['cid'];
			$courses_fmt[$key]['username'] = $this->get_usernamebyuid($value['uid']);
			$courses_fmt[$key]['course_name'] = '<a href="plugin.php?id=zhanmishu_video:video&mod=video&cid='.$value['cid'].'" target="_blank">'.$value['course_name'].'</a>';
			$courses_fmt[$key]['issell'] = $value['issell'] ? lang('plugin/zhanmishu_video', 'haveonsellk') : lang('plugin/zhanmishu_video', 'haveoutsellk');
			$courses_fmt[$key]['selltimes'] = $value['selltimes'];
			$courses_fmt[$key]['course_price'] = intval($value['course_price']) / 100;
			$courses_fmt[$key]['diff'] = $zhanmishu_videoconf['diff'][$value['diff']];
			$courses_fmt[$key]['progress'] = $zhanmishu_videoconf['progress'][$value['progress']];
			$courses_fmt[$key]['course_img'] = '<a href="'.$value['course_img'].'" target="_blank"><img src="'.$value['course_img'].'" width="40px" height="40px"></a>';
			$courses_fmt[$key]['course_intro'] = $value['course_intro'];
			$courses_fmt[$key]['dateline'] = date('Y-m-d H:i:s',$value['dateline']);
			$sellact = $value['issell'] ? lang('plugin/zhanmishu_video', 'outsellk') : lang('plugin/zhanmishu_video', 'onsellk');
			$courses_fmt[$key]['act'] = '<a href="'.$url.'&act=adminvideo&m=add&cid='.$value['cid'].'">'.lang('plugin/zhanmishu_video', 'add_video').'</a>&nbsp;&nbsp;&nbsp;<a href="'.$url.'&act=adminvideo&m=admin&cid='.$value['cid'].'">'.lang('plugin/zhanmishu_video', 'admin_course').'</a>&nbsp;&nbsp;&nbsp;<a href="'.$url.'&act=editk&editk=yes&cid='.$value['cid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video', 'edit').'</a>&nbsp;&nbsp;&nbsp;<a href="'.$url.'&act=outsellk&outsellk=yes&cid='.$value['cid'].'&formhash='.FORMHASH.'">'.$sellact.'</a>&nbsp;&nbsp;&nbsp;<a href="'.$url.'&act=delk&delk=yes&cid='.$value['cid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video', 'delete').'</a>';
		}

		return $courses_fmt;
	}



	public function get_usernamebyuid($uid){
		if (!$uid) {
			return '';
		}
		$user = getuserbyuid($uid);
		return $user['username'];
	}

	public function update_course_reply_num($cid){
		if (!$cid) {
			return false;
		}
		$course = $this->get_course_bycid($cid);
		$num = C::t("#zhanmishu_video#zhanmishu_video_reply")->get_type_reply_num(array('cid'=>$cid,'isdel'=>'0','islive'=>'0'));
		if ($num && $num != $course['replies']) {
			C::t("#zhanmishu_video#zhanmishu_video_course")->update($cid,array('replies'=>$num));
		}
	}

	public function get_course_bycid($cid, $isaddview=false, $isupdateorder=false){
		if (!$cid) {
			return false;
		}
		$c = C::t("#zhanmishu_video#zhanmishu_video_course")->fetch($cid);

		$up = array();
		if ($isaddview) {
			$up['views'] = $c['views'] + 1;
		}
		if ($isupdateorder) {
			$num = C::t("#zhanmishu_video#zhanmishu_video_order")->get_orders_num(array('cid'=>$c['cid'],'ispayed'=>'1'));
			$up['learns'] = $num + $c['learns_add'];
		}
		// 对课程数量进行更新
		// if ($c['videos'] == 0) {
		// 	// 统计课程数量
		// 	$this->update_course_info($cid);
		// }


		if (!empty($up)) {
			C::t("#zhanmishu_video#zhanmishu_video_course")->update($cid,$up);	
		}

		return $c;
	}


	public function  delete_k($cid){
		if (!$cid) {
			# code...
			return false;
		}
		return C::t("#zhanmishu_video#zhanmishu_video_course")->update($cid,array('isdel'=>'1','issell'=>'0'));
	}
	public function  set_course_upatesale($cid){
		if (!$cid) {
			# code...
			return false;
		}
		$k = $this->get_course_bycid($cid);
		if (empty($k)) {
			return false;
		}
		$issell = $k['issell'] ? '0' : '1';

		return C::t("#zhanmishu_video#zhanmishu_video_course")->update($cid,array('issell'=>$issell));
	}

	public function get_type_course($start = 0, $limit = 0, $sort = '',$type = '',$field){

		return C::t("#zhanmishu_video#zhanmishu_video_course")->get_type_course($start, $limit, $sort,$type,$field);

	}

	public function get_recommend_course($cid){
		return $this->get_type_course(0, 3, '','',array('isdel'=>'0', 'issell'=>'1'));
	}

	public function cat_tree_to_sample($cat = array()){
		if (empty($cat)) {
			$cat = C::t("#zhanmishu_video#zhanmishu_video_cat")->get_type_video_cat('','');

		}
		if (empty($cat)) {
			return false;
		}
		$sample_tree = array();
		foreach ($cat as $key => $value) {
			$sample_tree[$value['cat_id']] = $value['cat_name'];

			if (!empty($value['son'])) {
				foreach ($value['son'] as $k => $v) {
					$sample_tree[$v['cat_id']] = $v['cat_name'];
				}
			}
		}
		return $sample_tree;
	}

	public function get_cat_tree($pid='0',$isdel='0',$isfromcache=true){
		if ($isfromcache) {
			if (is_array($tree = $this->get_cat_tree_formcache())) {
				if ($pid == '0') {
					return $tree;
				}
				foreach ($tree as $key => $value) {
					if ($value['cat_id'] == $pid) {
						$return =  $value;
						break;
					}
				}
				return $return;
			}			
		}
		$field = array();
		if (strlen($pid) > 0) {
			$field['parent_id'] = intval($pid);
		}
		$field['isdel'] = $isdel;

		$cat = C::t("#zhanmishu_video#zhanmishu_video_cat")->get_type_video_cat('','','sort','',$field);
		if (empty($cat)) {
			return array();
		}

		if (!empty($cat)) {
			foreach ($cat as $key => $value) {
				if ($value['cat_id']) {
					$cat[$key]['son'] = $this->get_cat_tree($value['cat_id'],'0',false);
				}
				
			}
			$cat[$key]['son'] = $this->multisort($cat[$key]['son']);
		}
		$cat = $this->multisort($cat);

		return $cat;
	}

	public function update_catecache(){

		$catetreevar = $this->get_cat_tree('0','0',false,false);

		$this->ZmswriteToCache('cat',$catetreevar);
		// require_once libfile('function/cache');
		// $datacache = "\$catetreevar=".arrayeval($catetreevar).";\n";
		// writetocache('zhanmishu_videocate', $datacache);
	}

	public function get_cat_tree_formcache(){
		return $this->ZmsGetFromCache('cat');
	}

	public function ZmsGetFromCache($key){
		$cacheData = $this->GetFromCache($key);
		if (!empty($cacheData)) {
			return $cacheData;
		}
		if(file_exists($cachefile = $this->get_cache_file())) {
			@include $cachefile;
			
			return $zhanmishu_video_cache[$key];
		}
		return false;		
	}


	public function ZmswriteToCache($key,$data){
		$this->writetocache($key, $data);
	}

	public 	function multisort($arrays,$sort_key='sort',$sort_order=SORT_ASC,$sort_type=SORT_NUMERIC ){
		$keySort = array();
		foreach ($arrays as $key => $value) {
			if (!empty($value)) {
				$keySort[$key] = $value['sort'];
			}
		}
		array_multisort($keySort, $sort_order, $sort_type, $arrays);
		return $arrays; 
	}

	public function get_cat_select(){
		$cat = $this->get_cat_tree('0','0',false);
		$return = array();
		foreach ($cat as $key => $value) {
			$return[] = array($value['cat_id'],$value['cat_name']);
			if (is_array($value['son']) && !empty($value['son'])) {
				foreach ($value['son'] as $k => $v) {
					$return[] = array($v['cat_id'],'&nbsp;&nbsp;&nbsp;&nbsp;--'.$v['cat_name']);
				}
			}
		}

		return $return;
	}


	public function get_pidbycat_id($cat_id){
		if (!$cat_id) {
			return '0';
		}

		$cat = C::t("#zhanmishu_video#zhanmishu_video_cat")->fetch($cat_id);
		if (empty($cat)) {
			return '0';
		}
		return isset($cat['parent_id']) ? $cat['parent_id'] : $cat_id;
	}

	public function check_liveorvideo($str){
		if (preg_match("#(http|https)://(.*\.)?.*\..*#i", $str)){    
			return 'url';
		}else if (strlen($str)  >= 1) {
			return 'str';
		}
		return false;
	}


	public function checklowerlimit($action, $uid = 0, $coef = 1, $fid = 0, $returnonly = 0){
		global $_G;
		$uid = $uid ? $uid : $_G['uid'];
		$config = &$this->config;
		$action = array('extcredits'.$config['paytype_extcredits']=>$action);
		return checklowerlimit($action, $uid, '1', '0', '1');
	}
	public function updatemembercount($uid,$num,$title='',$intro=''){
		global $_G;
		$uid = $uid ? $uid : $_G['uid'];
		if (strlen($num) < 1 || !$uid) {
			return false;
		}
		$config = &$this->config;
		updatemembercount($uid,array('extcredits'.$config['paytype_extcredits']=>$num),false,'','','',$title,$intro);
		return true;
	}
	public function gift_checklowerlimit($action, $uid = 0, $coef = 1, $fid = 0, $returnonly = 0){
		global $_G;
		$uid = $uid ? $uid : $_G['uid'];
		$config = &$this->config;
		$action = array('extcredits'.$config['gift_credits_type']=>$action);
		return checklowerlimit($action, $uid, '1', '0', '1');
	}
	public function gift_updatemembercount($uid,$num,$title='',$intro=''){
		global $_G;
		$uid = $uid ? $uid : $_G['uid'];
		if (strlen($num) < 1 || !$uid) {
			return false;
		}
		$config = &$this->config;
		updatemembercount($uid,array('extcredits'.$config['gift_credits_type']=>$num),false,'','','',$title,$intro);
		return true;
	}

	public function course_group_toarray($course_group){
		return array_filter(explode(',', trim($course_group)));
	}

	public function get_group_icons(){
		return DB::fetch_all('select groupid,icon,grouptitle,color from %t',array('common_usergroup'),'groupid');
	}
	public function update_course_info($cid = '',$newcourse = array()) {
		if (!$cid) {
			return false;
		}
		
		if ($newcourse['cid'] && ($newcourse['cid'] != $cid)) {
			return false;
		}
		$course = $this->get_course_bycid($cid);
		if (empty($course)) {
			return false;
		}

		if (!empty($newcourse)) {
			$course = array_merge($course,$newcourse);
		}

		$islive = $course['islive'];
		$videos  = $this->get_video_bycid($course['cid']);
		if ($islive != '1') {
			foreach ($videos as $key => $value) {
				if ($value['islive'] == '1') {
					$course['islive'] = '1';
				}
			}
		}

		$course['videos'] = count($videos);
		if (!empty($videos)) {
			$course['course_length'] = array_sum(self::darray_column($videos, 'video_length'));
		}
		C::t("#zhanmishu_video#zhanmishu_video_course")->update($course['cid'],$course);

	}
	/** 
	* $str  教师名称过滤
	**/ 
	public function name_filter($str) {      
	        if($str){ 
	            $name = $str; 
	            $name = preg_replace('/\xEE[\x80-\xBF][\x80-\xBF]|\xEF[\x81-\x83][\x80-\xBF]/', '', $name); 
	            $name = preg_replace('/xE0[x80-x9F][x80-xBF]‘.‘|xED[xA0-xBF][x80-xBF]/S','?', $name); 
	            $return = json_decode(preg_replace("#(\\\ud[0-9a-f]{3})#ie","",json_encode($name))); 
	            if(!$return){ 
	                return $name;
	            } 
	        }else{ 
	            $return = ''; 
	        }     
	        return $return; 
	 
	}

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-07-31
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       [type]     $html_content   [description]
     * @param       [type]     $host           [description]
     * @return      [type]                     [description]
     */
    public static function richTextAbsoluteUrl($html_content, $host = '') {
    	if (!$host) {
    		global $_G;
    		$host = $_G['siteurl'];
    	}
        if (preg_match_all("/(<img[^>]+src=\"([^\"]+)\"[^>]*>)|(<a[^>]+href=\"([^\"]+)\"[^>]*>)|(<img[^>]+src='([^']+)'[^>]*>)|(<a[^>]+href='([^']+)'[^>]*>)/i", $html_content, $regs)) {
            foreach ($regs [0] as $num => $url) {
                $html_content = str_replace($url, self::lIIIIl($url, $host), $html_content);
            }
        }
        return $html_content;
    }

    public static function lIIIIl($l1, $l2) {
        if (preg_match("/(.*)(href|src)\=(.+?)( |\/\>|\>).*/i", $l1, $regs)) {
            $I2 = $regs [3];
        }
        if (strlen($I2) > 0) {
            $I1 = str_replace(chr(34), "", $I2);
            $I1 = str_replace(chr(39), "", $I1);
        } else {
            return $l1;
        }
        $url_parsed = parse_url($l2);
        $scheme = isset($url_parsed['scheme']) ? $url_parsed ["scheme"] : '';
        if ($scheme != "") {
            $scheme = $scheme . "://";
        }
        $host = isset($url_parsed ["host"]) ? $url_parsed['host'] : '';
        $l3 = $scheme . $host;
        if (strlen($l3) == 0) {
            return $l1;
        }
        $path = isset($url_parsed ["path"]) ? dirname($url_parsed ["path"]) : '' ;
        if(!empty($path)){
            if ($path [0] == "\\") {
                $path = "";
            }
        }
        $pos = strpos($I1, "#");
        if ($pos > 0)
            $I1 = substr($I1, 0, $pos);

        //判断类型
        if (preg_match("/^(http|https|ftp):(\/\/|\\\\)(([\w\/\\\+\-~`@:%])+\.)+([\w\/\\\.\=\?\+\-~`@\':!%#]|(&amp;)|&)+/i", $I1)) {
            return $l1;
        } //http开头的url类型要跳过
        elseif ($I1 [0] == "/") {
            $I1 = $l3 . $I1;
        } //绝对路径
        elseif (substr($I1, 0, 3) == "../") { //相对路径
            while (substr($I1, 0, 3) == "../") {
                $I1 = substr($I1, strlen($I1) - (strlen($I1) - 3), strlen($I1) - 3);
                if (strlen($path) > 0) {
                    $path = dirname($path);
                }
            }
            $I1 = $l3 . $path . "/" . $I1;
        } elseif (substr($I1, 0, 2) == "./") {
            $I1 = $l3 . $path . substr($I1, strlen($I1) - (strlen($I1) - 1), strlen($I1) - 1);
        } elseif (strtolower(substr($I1, 0, 7)) == "mailto:" || strtolower(substr($I1, 0, 11)) == "javascript:") {
            return $l1;
        } else {
            $I1 = $l3 . $path . "/" . $I1;
        }
        return str_replace($I2, "\"$I1\"", $l1);
    }

    // 富文本处理，对富文本编码和解码
    public function contentFormat($content, $format = 'DECODE'){
    	global $_G;
    	$format == 'DECODE' ? 'DECODE' : 'ENCODE';

    	if ($format == 'DECODE') {
    		return self::richTextAbsoluteUrl(dstripslashes(htmlspecialchars_decode($content), $_G['siteurl']));
    	}else{
    		return dhtmlspecialchars(self::richTextRelativeUrl($content, $_G['siteurl']));
    	}

    }
    /**
     * 对选项内容进行处理
     * 如为字符串，则分割为数组
     * 如为数组，则保持数组，去重
     *
     * 最后对数组元素进行数字检测，只允许数字
     */
    public function settingNumberFormat($content = '', $format = 'string', $isNumberCheck = true){
    	if (!is_array($content)) {
    		$content = explode(',', $content);
    	}
    	if (empty($content)) {
    		return $format == 'string' ? '' : array();
    	}
    	foreach ($content as $key => $value) {
    		if(!$value || ($isNumberCheck && !is_numeric($value))){
    			unset($content[$key]);
    		}
    	}

    	$content =  array_filter($content);
    	return $format == 'string' ?  implode(',', $content) : $content;
    }
	/**
	 * 是否是safari浏览器
	 */
	public static function checkIsSafari()
	{
	    if (empty($_SERVER['HTTP_USER_AGENT'])){
	        return false;
	    }
	  
	    $agent = strtolower($_SERVER['HTTP_USER_AGENT']);

	    if (strpos($agent, 'chrome') !== false){
	        return false;
	    }
	    if (strpos($agent, 'edge') !== false){
	        return false;
	    }
	    if (strpos($agent, 'msie') !== false){
	        return false;
	    }
	    if (strpos($agent, 'applewebkit') !== false){
	        return true;
	    }
	    if (strpos($agent, 'mobile') !== false){
	        return true;
	    }

	    return false;
	}
	public static function getOS(){
	    $agent = strtolower($_SERVER['HTTP_USER_AGENT']);

	    if(strpos($agent, 'windows nt')) {
	    $platform = 'windows';
	    } elseif(strpos($agent, 'macintosh')) {
	    $platform = 'mac';
	    } elseif(strpos($agent, 'ipod')) {
	    $platform = 'ipod';
	    } elseif(strpos($agent, 'ipad')) {
	    $platform = 'ipad';
	    } elseif(strpos($agent, 'iphone')) {
	    $platform = 'iphone';
	    } elseif (strpos($agent, 'android')) {
	    $platform = 'android';
	    } elseif(strpos($agent, 'unix')) {
	    $platform = 'unix';
	    } elseif(strpos($agent, 'linux')) {
	    $platform = 'linux';
	    } else {
	    $platform = 'other';
	    }

	    return $platform;
	}

    public function check_url($str){
        if (preg_match("#(http|https)://(.*\.)?.*\..*#i", $str)){    
            return 'url';
        }else if (strlen($str)  >= 1) {
            return 'str';
        }
        return false;
    }
    /**
     *  富文本绝对路径替换成相对路径
     * @param $html_content
     * @param $host
     * @return mixed
     */
    public static function richTextRelativeUrl($html_content, $host='') {
    	if (!$host) {
    		global $_G;
    		$host = $_G['siteurl'];
    	}
        return str_replace($host, '', $html_content);
    }
}
//From: Dism·taobao·com
?>