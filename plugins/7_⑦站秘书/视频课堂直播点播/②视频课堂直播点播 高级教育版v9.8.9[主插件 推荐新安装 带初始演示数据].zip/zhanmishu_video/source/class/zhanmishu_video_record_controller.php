<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
} 


/**
 * 
 */
class zhanmishu_video_record_controller extends zhanmishu_video_controller
{
    public function  add($params) {
        if (!$this->_checkFormhash($params['formhash'])) {
            self::showMessage('request_error','-111');
        }
        global $_G;
        if (!$_G['uid']) {
            $this->resultToJsonOutPut(array(),'please_login','-10001'); 
        }
        if (!$params['duration']) {
            $this->resultToJsonOutPut(array(),'duration_is_required','-10013'); 
        }
        if (empty($params['cid']) || empty($params['vid'])) {
            $this->resultToJsonOutPut(array(),'cid_is_required','-10014'); 
        }

        $field = array();
        $field['uid'] = $_G['uid'];
        $field['cid'] = $_G['cid'];
        $field['vid'] = $_G['vid'];

        $record = C::t("#zhanmishu_video#zhanmishu_video_record")->get_one_record_byfield($field,'desc');
        if (empty($record)) {
            $record['uid'] = $_G['uid'];
            $record['cid'] = $params['cid'] + 0;
            $record['vid'] = $params['vid'] + 0;
            $record['duration'] = $params['duration'] + 0;
            $record['seek'] = $params['seek'] + 0;
            $record['dateline'] = TIMESTAMP;

            C::t("#zhanmishu_video#zhanmishu_video_record")->insert($record);
        }else{
            //只允许5s内插入一次
            if (($record['dateline']) + 5 > TIMESTAMP) {
                return;
            }
            $record['seek'] = $params['seek'];
            $record['dateline'] = TIMESTAMP;
            unset($record['record_id']);
            C::t("#zhanmishu_video#zhanmishu_video_record")->insert($record);
        }
        $return = array(
            'msg' => 'success',
            'code' => '1'
        );
        $this->resultToJsonOutPut($return); 
    }

    public function seekTime($params = array()) {
        if (!$this->_checkFormhash($params['formhash'])) {
            //self::showMessage('request_error','-111');
        }
        global $_G;
        if (!$_G['uid']) {
            $this->resultToJsonOutPut(array(),'please_login','-10001'); 
        }
        $field = array();
        $field['uid'] = $_G['uid'];
        $field['cid'] = $params['cid'] + 0;
        $field['vid'] = $params['vid'] + 0;
        $record = C::t("#zhanmishu_video#zhanmishu_video_record")->get_one_record_byfield($field,'desc');
        $seek = array();
        if (!empty($record)) {
            $seek['seek'] = $record['seek'];
            $seek['duration'] = $record['duration'];
        }else{
            $seek['seek'] = 0;
            $seek['duration'] = 0;
        }
        $this->resultToJsonOutPut($seek); 

    }

}