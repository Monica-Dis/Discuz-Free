<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *    	应用更新支持：https://dism.taobao.com $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 


if (!class_exists('zhanmishu_course',false)) {
	C::import('zhanmishu_course','plugin/zhanmishu_video/source/class');
}

class zhanmishu_video extends zhanmishu_course{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }
    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }
	public function get_type_video($start = 0, $limit = 0, $sort = '',$type = '',$field=array()){
		return C::t("#zhanmishu_video#zhanmishu_video")->get_type_video($start, $limit, $sort,$type,$field);
	}

	public function get_type_video_num($field){
		return C::t("#zhanmishu_video#zhanmishu_video")->get_type_video_num($field);
	}
	public function checkuser_ispay_course($cid,$uid){
		if(!$uid){
			return false;
		}
		$o = array();
		$o['cid'] = $cid;
		$o['buyer_uid'] = $uid;
		$o['ispayed'] = '1';
		$payorder = $this->get_one_order_byfield($o);
		if (empty($payorder)) {
			return false;
		}
		return $payorder['oid'];
	}
	/**
	 * @Author      Lanya      87883395@qq.com zhanmishu.com
	 * @Description
	 * @DateTime    2019-07-11
	 * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
	 * @param       [type]     $columnid       [专栏ID]
	 * @param       [type]     $uid            [用户UID]
	 * @return      [type]                     [如已支付，返回订单oid，反之返回false]
	 */
	public function checkuser_ispay_column($columnid, $uid){
		$o = array();
		$o['columnid'] = $columnid;
		$o['buyer_uid'] = $uid;
		$o['ispayed'] = '1';
		
		$payorder = $this->get_one_order_byfield($o);
		if (empty($payorder)) {
			return false;
		}
		return $payorder['oid'];
	}
	public function checkuser_isfinish_course($cid,$uid,$isconfirm=true,$issuccess=true){
		$o = array();
		$o['cid'] = $cid;
		$o['buyer_uid'] = $uid;
		$o['ispayed'] = '1';
		if ($isconfirm) {
			$o['isconfirm'] = '1';
		}
		if ($issuccess) {
			$o['issuccess'] = '1';
		}
		
		$payorder = $this->get_one_order_byfield($o);

		if (empty($payorder)) {
			return false;
		}
		return $payorder['oid'];
	}

	public function get_one_order_byfield($field=array()){
		return C::t("#zhanmishu_video#zhanmishu_video_order")->get_one_order_byfield($field);
	}

	public function issueorderbyuid($uid=false){
		global $_G;
		$uid = $uid ? $uid : $_G['uid'];

		$o = C::t("#zhanmishu_video#zhanmishu_video_order")->get_type_order(0,0,'','',array('buyer_uid'=>$uid,'ispayed'=>'0'));
		foreach ($o as $key => $value) {
			$this->check_ispay_byout_trade_no($value['out_trade_no']);
		}
	}

	public function check_ispay_byout_trade_no($out_trade_no){
		if (!$this->ZmsIsWepayExists()) {
			return false;
		}
		if (!function_exists('zhanmishu_wepay_check_api')) {
			include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_wepay/source/function/api_function.php';
		}

		$o = $this->get_order_by_out_trade_no($out_trade_no);
		$rs = zhanmishu_wepay_check_api($out_trade_no,$o['total_fee']);
		if ($rs['code'] == '1' && $o['oid']) {
			$this->selledsuccess($o['oid']);
		}

		return $rs;
	}
	public function check_reward_ispay_byout_trade_no($out_trade_no){
		if (!$this->ZmsIsWepayExists()) {
			return false;
		}
		if (!function_exists('zhanmishu_wepay_check_api')) {
			include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_wepay/source/function/api_function.php';
		}
		$order = C::t('#zhanmishu_video#zhanmishu_video_reward')->get_one_reward_byfield(array('out_trade_no'=>$out_trade_no));

		if ($order['ispayed'] == '1' && $order['issuccess'] == '1') {
			return  array('code'=>'1', 'msg'=>'success');
		}else if ($order['ispayed'] == '1' && $order['issuccess'] == '2') {
			return  array('code'=>'-2', 'msg'=>'have_refund');
		}
			
		$rs = zhanmishu_wepay_check_api($out_trade_no,$order['total_fee']);

		if ($rs['code'] == '1' && $order['rid']) {
			$data = array();
			$data['ispayed'] = '1';
			$data['issuccess'] = '1';
			$rewardStatus = $this->reward_to_teacher($order);
			if ($rewardStatus) {
				C::t("#zhanmishu_video#zhanmishu_video_reward")->update($order['rid'],$data);
			}
		}

		return $rs;
	}

	public function reward_to_teacher($order = array()) {
		if (empty($order)) {
			return false;
		}
        $c = array();
        $c['rid']=$order['rid'];
        $c['cid']=$order['cid'];
        $c['vid']=$order['vid'];
        $c['video_name']=$order['video_name'];
        $c['time']=date('Y-m-d H:i:s',$order['dateline']);

        $c['present_username'] = $order['present_username'];

        if ($this->config['teacher_per']) {
            $this->gift_updatemembercount($order['uid'],ceil($moneyNum * $this->config['teacher_per']),lang('plugin/zhanmishu_video','reward_paytype_extcredits_percentage'),lang('plugin/zhanmishu_video','reward_paytype_extcredits_percentage_intro',$c));
        }
        return true;
	}

	public function get_orders_num($field=array()){
		return zhanmishu_video_model_order::fetch_num($field);
	}

	public function get_video_bycid($cid ,$isdel = null, $includeChapter = false){
		if (is_null($isdel)) {
			$field=array('cid'=>$cid,'isdel'=>'0');
		}else{
			$field=array('cid'=>$cid,'isdel'=>$isdel);
		}
		if (!$includeChapter) {
			$field['is_chapter'] = '0';
		}
		$videoList = $this->get_type_video(0, 0,'asc','',$field);
		if (!$includeChapter) {
			return $videoList;
		}
		return $this->getChapterList($videoList);
	}

	public function check_mobile($str){
		$config = $this->config;
		$preg = $config['mobile_rules'] ? $config['mobile_rules'] : "/^(13[0-9]|15[0-9]|17[0678]|18[0-9]|14[57])[0-9]{8}$/";
		if (!preg_match($preg, $str)) {
			return false;
		}
		return true;
	}

	public function check_email($str){
		$config = $this->config;
		$preg = $config['email_rules'] ? $config['email_rules'] : "/([a-z0-9]*[-_.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[.][a-z]{2,3}([.][a-z]{2})?/i";
		if (!preg_match($preg, $str)) {
			return false;
		}
		return true;		
	}


	public function delete_video($vid, $isRealDel = true){
		if (!$isRealDel) {
			return C::t("#zhanmishu_video#zhanmishu_video")->update($vid,array('isdel'=>'1'));
		}
		return C::t("#zhanmishu_video#zhanmishu_video")->delete($vid);
	}


	public function get_order_byoid($oid){
		if (!$oid) {
			return false;
		}

		return C::t("#zhanmishu_video#zhanmishu_video_order")->fetch($oid);
	}

	public function order_video($oid,$buyer_uid){
		if (!$oid) {
			return array('code'=>'-5','msg'=>'oid_isnot_exixts');
		}
	  $o = C::t("#zhanmishu_video#zhanmishu_video_order")->fetch($oid);
	  if (empty($o)) {
	  	return array('code'=>'-5','msg'=>'cid_isnot_exixts');
	  }

	  return C::t("#zhanmishu_video#zhanmishu_video")->order_video($oid,$o['cid'],$buyer_uid);

	}

	public function get_order_by_out_trade_no($out_trade_no){
		return C::t("#zhanmishu_video#zhanmishu_video_order")->get_order_by_out_trade_no($out_trade_no);
	}

	public function get_teacher_info_byuid($uid = ''){
		return $this->getTeacherInfo($uid);
	}

	/**
	 * @Author      Lanya      87883395@qq.com zhanmishu.com
	 * @Description
	 * @DateTime    2019-07-11
	 * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
	 * @param       array      $order          [通过订单创建授权]
	 * @param       array      $courseids      [更新课程信息后，更新收取]
	 * @return      [type]                     [description]
	 */
	public function updateColumnAcl($order = array(),$courseids = array()){
		/**
		 * 获取当前专栏下面的课程，将课程加入到可播放权限内
		 * 如，未来修改专栏，增加专栏内课程，那么可播放的课程同步增加
		 * 如，未来修改专栏，减少了可播放课程，有权限播放的课程不同步减少
		 */
		$column = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch($order['columnid']);
		if (empty($column)) {
			return ;
		}
		$courseids = !empty($courseids) ? $courseids : array_filter(explode(',', $column['courseids']));
		$data = array();
		$data['columnid'] = $order['columnid'];
		$data['uid'] = $order['buyer_uid'];
		$data['authority_type'] = 1; // 表示专栏购买后授权
		foreach ($courseids as $key => $value) {
			if ($value) {
				$data['cid'] = $value + 0;

				$auth = C::t("#zhanmishu_video#zhanmishu_video_autho")->get_one_autho_byfield($data);
				// 补授权
				if (empty($auth)) {
					$data['dateline'] = TIMESTAMP;
					C::t("#zhanmishu_video#zhanmishu_video_autho")->insert($data);
				}
			}
		}
	}

	public function selledsuccess($oid){
		$o = $this->get_order_byoid($oid);
		$config = $this->config;
		if ($config['teacher_per']) {
			$moneyNum = $config['moneyper'] * $o['course_price'] / 100;
			
			$c = array();
			$c['oid']=$o['oid'];
			if ($o['columnid']) {
				$c['cid']=$o['columnid'];
				$c['course_name']=$o['course_column_name'];
			}else{
				$c['cid']=$o['cid'];
				$c['course_name']=$o['course_name'];
			}
			

			$c['time']=date('Y-m-d H:i:s',$o['dateline']);
			global $_G;
			$c['buyer_username'] = $_G['username'];	
			 //teacher pay 
			$this->updatemembercount($o['uid'],ceil($moneyNum * $config['teacher_per']),lang('plugin/zhanmishu_video','paytype_extcredits_percentage'),lang('plugin/zhanmishu_video','paytype_extcredits_percentage_intro',$c));
		}


		$oupdate = array(
		'ispayed'=>'1',
		'isselled'=>'1',
		'checknum'=>'1',
		'out_trade_no'=>$o['out_trade_no'],
			);
		C::t("#zhanmishu_video#zhanmishu_video_order")->update($o['oid'],$oupdate);

		if ($o['columnid']) {
			$this->updateColumnAcl($o);
		}
	}

	public function  setsuccess($oid){
		if (!$oid) {
			return false;
		}

		 $oupdate = array(
			'ispayed'=>'1',
			'isselled'=>'1',
			'checknum'=>'1',
		 	);

		return  C::t("#zhanmishu_video#zhanmishu_video_order")->update($oid,$oupdate);
	}

	public function get_orders($start = 0, $limit = 0, $sort = '',$type = '',$field=array()){
		return C::t("#zhanmishu_video#zhanmishu_video_order")->get_type_order($start, $limit, $sort,$type,$field);
	}
	public function get_orders_fmt($start = 0, $limit = 0, $sort = '', $field=array()){
		global $zhanmishu_videoconf,$url;
		$url = ADMINSCRIPT.'?action='.$url;
		$orders = $this->get_orders($start, $limit, $sort,$type,$field);
		$return = array();

		foreach ($orders as $key => $value) { 
			$return[$key]['oid'] = $value['oid'];
			$return[$key]['cid'] = $value['cid'] > 0 ? $value['cid'] : '';
			$return[$key]['cname'] = '<a href="plugin.php?id=zhanmishu_video:video&mod=video&cid='.$value['cid'].'" target="_blank">'.$value['course_name'].'</a>';
			$return[$key]['vid'] = $value['vid'] > 0 ? $value['vid'] : '';
			$return[$key]['ispayed'] = $value['ispayed']? lang('plugin/zhanmishu_video', 'payed_success') : lang('plugin/zhanmishu_video', 'payed_unsuccess');
			$return[$key]['course_price'] = intval($value['course_price']) / 100;
			$return[$key]['buyer_uid'] =  '<a href="home.php?mod=space&uid='.$value['buyer_uid'].'" target="_blank">'.$this->get_usernamebyuid($value['buyer_uid']).'</a>';
			$return[$key]['out_trade_no'] = $value['out_trade_no'];
			$return[$key]['dateline'] = date('Y-m-d',$value['dateline']);
			$return[$key]['pay_time'] = $value['pay_time'] ? date('Y-m-d H:i:s',$value['pay_time']) : $value['pay_time'];
			$return[$key]['orderstatus'] = $zhanmishu_videoconf['orderstatus'][$value['status']];
			$acturl = '';
			if ($value['ispayed'] =='0') {
				$acturl .= '<a style="color:green;" href="'.$url.'&act=order&m=setpay&paystatus=1&oid='.$value['oid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','pay_confirm').'</a>&nbsp;&nbsp;';
			}else{
				$acturl .= '<a style="color:red;" href="'.$url.'&act=order&m=setpay&paystatus=0&oid='.$value['oid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','pay_cancel').'</a>&nbsp;&nbsp;';
			}
			if ($value['issign'] =='1' && $value['isconfirm'] =='0') {
				$acturl .= '<a style="color:green;" href="'.$url.'&act=order&m=setcontract&contractstatus=1&oid='.$value['oid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','contract_confirm').'</a>&nbsp;&nbsp;';
			}else{
				$acturl .= '<a style="color:#cdcdcd;" >'.lang('plugin/zhanmishu_video','contract_confirm').'</a>&nbsp;&nbsp;';
			}

			if ($value['issign'] =='1') {
				$acturl .= '<a style="color:red;" href="'.$url.'&act=order&m=setcontract&contractstatus=0&oid='.$value['oid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','contract_cancel').'</a>&nbsp;&nbsp;';
			}else{
				$acturl .= '<a style="color:#cdcdcd;" >'.lang('plugin/zhanmishu_video','contract_cancel').'</a>&nbsp;&nbsp;';
			}

			if ($value['issuccess'] =='0' && $value['isconfirm'] =='1') {
				$acturl .= '<a style="color:green;" href="'.$url.'&act=order&m=setmail&mailstatus=1&oid='.$value['oid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','mail_confirm').'</a>&nbsp;&nbsp;';

			}else{
				$acturl .= '<a style="color:#cdcdcd;" >'.lang('plugin/zhanmishu_video','mail_confirm').'</a>&nbsp;&nbsp;';
			}
			if ($value['ismail'] =='1') {
				$acturl .= '<a style="color:red;" href="'.$url.'&act=order&m=setmail&mailstatus=0&oid='.$value['oid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','mail_cancel').'</a>&nbsp;&nbsp;';
			}else{
				$acturl .= '<a style="color:#cdcdcd;" >'.lang('plugin/zhanmishu_video','mail_cancel').'</a>&nbsp;&nbsp;';
			}
			if ($value['order_type'] =='1') {
				$acturl .= '<a style="color:red;" href="'.$url.'&act=order&m=cleanplaycount&oid='.$value['oid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','cleanplaycount').'</a>&nbsp;&nbsp;';
			}else{
				$acturl .= '<a style="color:#cdcdcd;" >'.lang('plugin/zhanmishu_video','cleanplaycount').'</a>&nbsp;&nbsp;';
			}

			$acturl .= '<a href="'.$url.'&act=order&m=checkorder&oid='.$value['oid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','checkorder_info').'</a>&nbsp;&nbsp;';

			$return[$key]['act'] = $acturl;
		}
		return $return;
	}

	public function cleanplaycount($oid){
		if (!$oid) {
			return false;
		}
		$o = $this->get_order_byoid($oid);
		if (empty($o)) {
			return false;
		}
		C::t("#zhanmishu_video#zhanmishu_video_order")->update($o['oid'],array('playcount'=>'0'));
		return array('code'=>'1','msg'=>'succeed');
	}

	public function order_setmail($oid,$status='1'){
		if (!$oid) {
			return false;
		}
		$o = $this->get_order_byoid($oid);
		if (empty($o)) {
			return false;
		}		
		if ($status =='1') {
			if ($o['ispayed'] =='0') {
				return array('code'=>'-2','msg'=>'this_order_is_not_payed_yet');
			}else if ($o['isclosed'] =='1') {
				return array('code'=>'-3','msg'=>'this_order_is_closed_before');
			}else if ($o['isconfirm'] =='0') {
				return array('code'=>'-3','msg'=>'this_order_isnot_isconfirm_yet');
			}else if ($o['issuccess'] =='1') {
				return array('code'=>'-3','msg'=>'this_order_is_issuccess_before');
			}

			C::t("#zhanmishu_video#zhanmishu_video_order")->update($oid,array('isconfirm'=>'1','ismail'=>$status,'issuccess'=>$status,'success_time'=>TIMESTAMP));
			$this->update_order_status_byoid($oid);
			return array('code'=>'1','msg'=>'succeed');
		}else if ($status =='0') {
			if ($o['ispayed'] =='0') {
				return array('code'=>'-2','msg'=>'this_order_is_not_payed_yet');
			}else if ($o['issign'] =='0') {
				return array('code'=>'-3','msg'=>'this_order_isnot_issign_yet');
			}else if ($o['isconfirm'] =='0') {
				return array('code'=>'-3','msg'=>'this_order_isnot_isconfirm_yet');
			}
			C::t("#zhanmishu_video#zhanmishu_video_order")->update($oid,array('ismail'=>$status,'issuccess'=>$status,'success_time'=>TIMESTAMP));
			$this->update_order_status_byoid($oid);
			return array('code'=>'1','msg'=>'succeed');
		}

		return array('code'=>'-1','msg'=>'none');
	}
	public function order_setcontract($oid,$status='1'){
		$config = $this->config;
		if (!$oid) {
			return false;
		}
		$o = $this->get_order_byoid($oid);
		if (empty($o)) {
			return false;
		}		
		if ($status =='1') {
			if ($o['ispayed'] =='0') {
				return array('code'=>'-2','msg'=>'this_order_is_not_payed_yet');
			}else if ($o['isclosed'] =='1') {
				return array('code'=>'-3','msg'=>'this_order_is_closed_before');
			}else if ($o['issign'] =='0') {
				return array('code'=>'-3','msg'=>'this_order_isnot_issign_yet');
			}else if ($o['isconfirm'] =='1') {
				return array('code'=>'-3','msg'=>'this_order_is_isconfirm_before');
			}

			//检查是否完成了实名认证
			if (!$this->check_user_isverify($o['buyer_uid']) && $config['isverify']) {
				return array('code'=>'-3','msg'=>'this_user_isnot_finish_verify');
			}

			C::t("#zhanmishu_video#zhanmishu_video_order")->update($oid,array('issign'=>$status,'isconfirm'=>$status,'confirm_time'=>TIMESTAMP));
			$this->update_order_status_byoid($oid);
			return array('code'=>'1','msg'=>'succeed');
		}else if ($status =='0') {
			if ($o['ispayed'] =='0') {
				return array('code'=>'-2','msg'=>'this_order_is_not_payed_yet');
			}
			C::t("#zhanmishu_video#zhanmishu_video_order")->update($oid,array('ismail'=>'0','issuccess'=>'0','issign'=>$status,'isconfirm'=>$status,'confirm_time'=>TIMESTAMP));
			$this->update_order_status_byoid($oid);
			return array('code'=>'1','msg'=>'succeed');
		}

		return array('code'=>'-1','msg'=>'none');
	}
	public function order_setpay($oid,$status='1'){
		if (!$oid) {
			return false;
		}
		$o = $this->get_order_byoid($oid);
		if (empty($o)) {
			return false;
		}
		if ($status =='1') {
			if ($o['ispayed'] =='1') {
				return array('code'=>'-2','msg'=>'this_order_is_payed_before');
			}
			if ($o['isclosed'] =='1') {
				return array('code'=>'-3','msg'=>'this_order_is_closed_before');
			}

			C::t("#zhanmishu_video#zhanmishu_video_order")->update($oid,array('ispayed'=>$status,'pay_time'=>TIMESTAMP));
			$this->update_order_status_byoid($oid);
			return array('code'=>'1','msg'=>'succeed');
		}else if ($status =='0') {
			if ($o['ispayed'] =='0') {
				return array('code'=>'-2','msg'=>'this_order_is_not_payed_yet');
			}
			C::t("#zhanmishu_video#zhanmishu_video_order")->update($oid,array('ispayed'=>$status,'checknum'=>'1','pay_time'=>TIMESTAMP));
			$this->update_order_status_byoid($oid);
			return array('code'=>'1','msg'=>'succeed');
		}

		return array('code'=>'-1','msg'=>'none');
	}

	public function get_video_by_vid($vid){
		return C::t("#zhanmishu_video#zhanmishu_video")->fetch($vid);
	}

	public function set_selled($vid,$data=array()){
		if (!$vid) {
			return false;
		}
		$data = array(
		 	'isselled'=>'1',
		 	'buyer_uid'=>$data['buyer_uid'],
		 	'buyer_mobile'=>$data['buyer_mobile'],
		 	'buyer_email'=>$data['buyer_email'],
		 	);
		$rs = C::t("#zhanmishu_video#zhanmishu_video")->update($vid,$data);

		if ($rs) {
			$video = $this->get_video_by_vid($vid);
			
			$this->update_store_num($video['cid']);
			$this->add_kaselltimes($video['cid']);
		}
		
		return true;
	}



	public function sendemail($oid){
		include libfile('function/mail');
		$o = $this->get_order_byoid($oid);
		if ($o['buyer_uid']) {
			$username = $this->get_usernamebyuid($o['buyer_uid']);
		}
		$content = $this->config['emailnoticetemplate'];
		$content = str_replace('{email}', $o['buyer_email'], $content);
		$content = str_replace('{mobile}', $o['buyer_mobile'], $content);
		$content = str_replace('{video_sec}', '[[['.$o['video_sec'].']]]', $content);
		$content = str_replace('{uid}', $o['buyer_uid'], $content);
		if ($username) {
			$content = str_replace('{username}', $username, $content);
		}

		$succeed = sendmail($o['buyer_email'], $content , $_G['setting']['bbname']."\n\n\n$message");
		if ($succeed) {
			C::t("#zhanmishu_video#zhanmishu_video_order")->update($oid,array('issend'=>'1'));
		}
	}


	public function get_type_video_fmt($start = 0, $limit = 0, $sort = '',$type = '',$field){
		global $url,$zhanmishu_videoconf;
		$url = ADMINSCRIPT.'?action='.$url;
		$videos = $this->get_type_video($start, $limit, $sort,$type,$field);
		$videos_fmt = array();
		foreach ($videos as $key => $value) {
			$videos_fmt[$key]['vid'] = $value['vid'];
			$videos_fmt[$key]['video_name'] = $value['video_name'];
			$videos_fmt[$key]['video_price'] = $value['video_price'] / 100;
			$videos_fmt[$key]['isfree'] = $value['isfree'];
			$videos_fmt[$key]['video_url'] = $value['video_url'];
			$videos_fmt[$key]['video_urltype'] = $zhanmishu_videoconf['video_url_type'][$value['video_urltype']];
			
			$videos_fmt[$key]['video_length'] = $value['video_length'];
			$videos_fmt[$key]['selltimes'] = $value['selltimes'];
			$videos_fmt[$key]['video_img'] = $value['video_img'] ? '<a href="'.$value['video_img'].'" target="_blank"><img src="'.$value['video_img'].'" width="40px" height="40px"></a>' : '';
			$videos_fmt[$key]['dateline'] = date('Y-m-d H:i',$value['dateline']);
			$videos_fmt[$key]['act'] = '<a href="'.$url.'&act=adminvideo&m=edit&vid='.$value['vid'].'&set_selled=yes&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video', 'edit').'</a>&nbsp;&nbsp;<a href="'.$url.'&act=adminvideo&m=delete&vid='.$value['vid'].'&delete=yes&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video', 'delete').'</a>';
			$videos_fmt[$key]['video_urltype_orign'] = $value['video_urltype'];
			$videos_fmt[$key]['uid'] = $value['uid'];
			$videos_fmt[$key]['cid'] = $value['cid'];
		}

		return $videos_fmt;
	}
	public function get_type_video_api_fmt($start = 0, $limit = 0, $sort = '',$type = '',$field){
		global $url,$zhanmishu_videoconf;
		$url = ADMINSCRIPT.'?action='.$url;
		$videos = $this->get_type_video($start, $limit, $sort,$type,$field);
		$videos_fmt = array();
		foreach ($videos as $key => $value) {
			$videos_fmt[$key] = $value;
			$videos_fmt[$key]['video_price'] = $value['video_price'] / 100;
			$videos_fmt[$key]['video_length'] = $value['video_length'];
			$videos_fmt[$key]['dateline'] = dgmdate($value['dateline'],'Y-m-d H:i');
			if ($this->config['isrewrite']) {
				if (!function_exists('zms_video_rewriteoutput')) {
					include_once DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/function/common_function.php';
				}
				$videos_fmt[$key]['url'] = zms_video_rewriteoutput('course_videopage',1,'',$value['cid'],$value['vid']);
			}else{
				$videos_fmt[$key]['url'] = 'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$value['cid'].'&vid='.$value['vid'];
			}


			if ($value['islive']) {
				global $_G;
				if ($_G['groupid'] == '1' || $_G['uid'] == $value['uid']) {
					$videos_fmt[$key]['video_url'] = $this->get_private_videourl($value['vid']);
				}
			}
			$videos_fmt[$key]['video_urltype'] = $zhanmishu_videoconf['video_url_type'][$value['video_urltype']];
			$videos_fmt[$key]['video_urltype_orign'] = $value['video_urltype'];


		}

		return $videos_fmt;
	}

	public function check_user_isverify($uid = ''){
		global $_G;

		$verify_id = $this->get_verify_id();
		$uid = $uid ? $uid : $_G['uid'];
		if ($uid) {
			$verify = C::t('common_member_verify')->fetch($uid);
			if (!empty($verify)) {
				return intval($verify['verify'.$verify_id]);
			}
		}
		return false;
	}

	public function check_verify_issubmit($uid=''){
		$info = $this->get_member_verify_info($uid);
		if (is_array($info) && !empty($info) && $info['flag'] !=='-1'){
			return true;
		}
		return false;
	}

	public function get_member_verify_info($uid='',$verifytype='',$issuccess=false){
		global $_G;
		if ($issuccess !== false) {
			$flag = ' and flag = '.$issuccess.' ';
		}else{
			$flag = '';
		}
		$uid = $uid ? $uid : $_G['uid'];
		$verifytype = $verifytype ? $verifytype : $this->get_verify_id();

		$info = DB::fetch_first('select * from %t where verifytype = '.$verifytype.$flag.' and uid ='.$uid,array('common_member_verify_info'));
		$info['field'] = unserialize($info['field']);
		return $info;
	}

	public function get_realname_idcardinfo($uid){
		global $_G;
		$uid = $uid ? $uid : $_G['uid'];
		$config = $this->config;
		if (!$uid) {
			return false;
		}
		$info = $this->get_member_verify_info($uid);

		if (!$info['field'][$config['realname']] || !$info['field'][$config['idcard']]) {
			$userprofile = C::t("common_member_profile")->fetch($uid);
		}

		$realname = $userprofile[$config['realname']] ? $userprofile[$config['realname']] : $userprofile[$config['realname']];
		$idcard = $userprofile[$config['idcard']] ? $userprofile[$config['idcard']] : $userprofile[$config['idcard']];

		return $realname.' '.$idcard;
	}

	public function get_verify_id(){
		$verifyid = $this->config['verify'];
		return $verifyid ? $verifyid : '6';
	}

	public function get_vid_byverifyid($uid,$verifytype){
		global $_G;
		$uid = $uid ? $uid : $_G['uid'];
		$verifytype = $verifytype ? $verifytype : $this->get_verify_id();
		$v = $this->get_member_verify_info($uid,$verifytype);
		if (empty($v)) {
			return false;
		}
		return $v['vid'];
	}

	public function get_type_order($start = 0, $limit = 0, $sort = '',$type = '',$field=array()){
		return C::t("#zhanmishu_video#zhanmishu_video_order")->get_type_order($start, $limit, $sort,$type,$field);
	}

	public function update_order_status_byoid($oid){
		if (!$oid) {
			return false;
		}
		$o = $this->get_order_byoid($oid);
		if (empty($o)) {
			return '-1';
		}


		if ($o['isclosed'] =='1') {
			$status='7';
		}else if ($o['ispayed'] == '1' && $o['order_type'] == '0') {
			$status='1';
		}else if ($o['ispayed'] == '1' && $o['issign'] == '1' && $o['isconfirm'] == '1' && $o['ismail'] == '1' && $o['issuccess'] == '1' && $o['isclosed'] == '0') {
			$status='1';
		}else if ($o['ispayed'] == '1' && $o['issign'] == '1' && $o['isconfirm'] == '1' && $o['ismail'] == '1' && $o['issuccess'] == '0' && $o['isclosed'] == '0' && $o['order_type'] == '1') {
			$status='6';
		}else if ($o['ispayed'] == '1' && $o['issign'] == '1' && $o['isconfirm'] == '1' && $o['ismail'] == '0' && $o['issuccess'] == '0' && $o['isclosed'] == '0' && $o['order_type'] == '1') {
			$status='5';
		}else if ($o['ispayed'] == '1' && $o['issign'] == '1' && $o['isconfirm'] == '0' && $o['ismail'] == '0' && $o['issuccess'] == '0' && $o['isclosed'] == '0' && $o['order_type'] == '1') {
			$status='4';
		}else if ($o['ispayed'] == '1' && $o['issign'] == '0' && $o['isconfirm'] == '0' && $o['ismail'] == '0' && $o['issuccess'] == '0' && $o['isclosed'] == '0' && $o['order_type'] == '1') {
			$status='3';
		}else if ($o['ispayed'] == '0' && $o['issign'] == '0' && $o['isconfirm'] == '0' && $o['ismail'] == '0' && $o['issuccess'] == '0' && $o['isclosed'] == '0') {
			$status='2';
		}else if ($o['ispayed'] == '1' && !$o['isclosed']) {
			$status='1';
		}else if ($o['ispayed'] == '2') {
			$status='7';
		}

		if ($status) {
			C::t("#zhanmishu_video#zhanmishu_video_order")->update($o['oid'],array('status'=>$status));
			$config = $this->config;
			if (!$config['issign'] && $status >= 3 && $status != 7) {
				$status = '1';
			}else if (!$config['isemail'] && $status > '5' && $status != 7) {
				$status = '1';
			}

			if ($status == '7') {
				return '-2';
			}

			return $status;
		}
		return '2';
	}

	public function get_order_byoid_fmt($oid){
		global $zhanmishu_videoconf;
		$o = $this->get_order_byoid($oid);
		if (empty($o)) {
			return false;
		}
		if ($o['buyer_uid']) {
			$o['buyer_username'] = '<a href="home.php?mod=space&uid='.$o['buyer_uid'].'" target="_blank">'.$this->get_usernamebyuid($o['buyer_uid']).'</a>';

		}

		$o['course_name'] = '<a href="plugin.php?id=zhanmishu_video:video&mod=video&cid='.$o['cid'].'" target="_blank">'.$o['course_name'].'</a>';
		$o['course_img'] = '<a href="'.$o['course_img'].'" target="_blank">'.'<img src="'.$o['course_img'].'" width="40px" height="40px"></a>';
		$o['sign_img1'] = '<a href="'.$o['sign_img1'].'" target="_blank">'.'<img src="'.$o['sign_img1'].'" width="40px" height="40px"></a>';
		$o['sign_img2'] = '<a href="'.$o['sign_img2'].'" target="_blank">'.'<img src="'.$o['sign_img2'].'" width="40px" height="40px"></a>';
		$o['sign_img3'] = '<a href="'.$o['sign_img3'].'" target="_blank">'.'<img src="'.$o['sign_img3'].'" width="40px" height="40px"></a>';
		$o['vid'] = $o['vid'] ? $o['vid'] : '';
		$o['cid'] = $o['cid'] ? $o['cid'] : '';
		$o['video_price'] = lang('plugin/zhanmishu_video','moneyunit_code').($o['video_price'] / 100 ).lang('plugin/zhanmishu_video','moneyunit');
		$o['course_price'] = lang('plugin/zhanmishu_video','moneyunit_code').($o['course_price'] / 100 ).lang('plugin/zhanmishu_video','moneyunit');
		$o['total_fee'] = lang('plugin/zhanmishu_video','moneyunit_code').($o['total_fee'] / 100 ).lang('plugin/zhanmishu_video','moneyunit');
		$o['dateline'] = $o['dateline'] ? date("Y-m-d H:i:s",$o['dateline']) : '' ;
		$o['sign_time'] = $o['sign_time'] ? date("Y-m-d H:i:s",$o['sign_time']) : '' ;
		$o['pay_time'] = $o['pay_time'] ? date("Y-m-d H:i:s",$o['pay_time']) : '' ;
		$o['confirm_time'] = $o['confirm_time'] ? date("Y-m-d H:i:s",$o['confirm_time']) : '' ;
		$o['success_time'] = $o['success_time'] ? date("Y-m-d H:i:s",$o['success_time']) : '' ;
		$o['ispayed'] = $o['ispayed'] ? lang('plugin/zhanmishu_video','payed_success') : lang('plugin/zhanmishu_video','payed_unsuccess');
		$o['isselled'] = $o['isselled'] ? lang('plugin/zhanmishu_video','learn_success') : lang('plugin/zhanmishu_video','learn_unsuccess');
		$o['checknum'] = $o['checknum'] ? lang('plugin/zhanmishu_video','checknum_success') : lang('plugin/zhanmishu_video','checknum_unsuccess');
		$o['issign'] = $o['issign'] ? lang('plugin/zhanmishu_video','issign_success') : lang('plugin/zhanmishu_video','issign_unsuccess');
		$o['isconfirm'] = $o['isconfirm'] ? lang('plugin/zhanmishu_video','isconfirm_success') : lang('plugin/zhanmishu_video','isconfirm_unsuccess');
		$o['ismail'] = $o['ismail'] ? lang('plugin/zhanmishu_video','ismail_success') : lang('plugin/zhanmishu_video','ismail_unsuccess');
		$o['isclosed'] = $o['isclosed'] ? lang('plugin/zhanmishu_video','isclosed_success') : lang('plugin/zhanmishu_video','isclosed_unsuccess');
		$o['issuccess'] = $o['issuccess'] ? lang('plugin/zhanmishu_video','issuccess_success') : lang('plugin/zhanmishu_video','issuccess_unsuccess');
		$o['status'] = $zhanmishu_videoconf['orderstatus'][$o['status']];
		return $o;
	}

	public function get_oss_video_duration($v){

		$config = $this->config;
	    $accessKeyId = $config['OSSAccessKeyId'];
	    $accessKeySecret = $config['OssAccessKeySecret'];

	    $profile = DefaultProfile::getProfile($config['OSS_region'], $accessKeyId,$accessKeySecret);
	    $client = new DefaultAcsClient($profile);


	    $request = new SubmitMediaInfoJobRequest();
	    $request->setAcceptFormat('JSON');

	    $input = array();
	    $input['Bucket'] = $config['OSSbucket'];
	    $input['Location'] = 'oss-'.$config['OSS_region'];
	    $input['Object'] = $v['video_url'];
	    $input = json_encode($input);
	    $request->setInput($input);

	    $response = $client->getAcsResponse($request);

	    return ceil($response->MediaInfoJob->Properties->Streams->VideoStreamList->VideoStream[0]->Duration);

	}

	public function update_video_length($vid){
		$config = $this->config;
		if (!$vid) {
			return false;
		}
		$v = $this->get_video_by_vid($vid);
		if ($v['video_length']) {
			return;
		}
		if (empty($v)) {
			return false;
		}
		if ($v['video_urltype'] == '10') {
			$length = $this->get_oss_video_duration($v);
		    if ($length) {
		    	C::t("#zhanmishu_video#zhanmishu_video")->update($v['vid'],array('video_length'=>ceil($length)));
		    }

		}
		if ($v['video_urltype'] !== '1') {
			return;
		}
		//需要填写你的 Access Key 和 Secret Key
	    $accessKey = $config['qiniuaccessKey'];
	    $secretKey = $config['qiniusecretKey'];

	    // 构建鉴权对象
	    $auth = new Qiniu_Auth($accessKey, $secretKey);
	    $f = $this->getfileexten(trim($v['video_url']));
	    //baseUrl构造成私有空间的域名/key的形式
	    $baseUrl = $config['qiniuencdoeurl'].rawurlencode($this->auto_to_utf8($f['0'])).$f['1'].'?avinfo';
	    $authUrl = $auth->privateDownloadUrl($baseUrl);
	    $length = $this->get_duration_video($authUrl);
	    if ($length) {
	    	C::t("#zhanmishu_video#zhanmishu_video")->update($v['vid'],array('video_length'=>ceil($length)));
	    }
	}


	public function DescribeLiveStreamRecordContent($vid, $start_time = ''){
		if (!$vid) {
			return false;
		}
		date_default_timezone_set('Asia/Shanghai');
		$v = $this->get_video_by_vid($vid);

		$config = $this->config;
		$StreamName = 'course-live'.$v['vid'];
	    $accessKeyId = $config['OSSAccessKeyId'];
	    $accessKeySecret = $config['OssAccessKeySecret'];

	    $profile = DefaultProfile::getProfile($config['live_region'], $accessKeyId,$accessKeySecret);
	    $client = new DefaultAcsClient($profile);


	    $request = new DescribeLiveStreamRecordContentRequest();

	    $request->setAcceptFormat('JSON');
	    $request->setAppName($config['aliyun_live_AppName']);
	    $request->setDomainName($config['aliyun_live_host']);
	    $start_time = $start_time ? $start_time : $v['start_time'];
	    if(!$start_time){
	    	$start_time = TIMESTAMP - 3600 * 24 * 3;
	    }
	    $request->setStartTime($this->gmt_iso8601($start_time - 3600 * 24));
	    $request->setEndTime($this->gmt_iso8601($start_time + 3600*24*3));
	    $request->setStreamName($StreamName);

	    $response = $client->getAcsResponse($request);

	    return json_decode(json_encode($response->RecordContentInfoList->RecordContentInfo),true);

	}

	public function check_live_isrecord($vid ,$checkTime = true){

		$v = $this->get_video_by_vid($vid);
		if (empty($v) || $v['video_urltype'] != '11') {
			//不需要拉取录制信息
			return true;
		}

		if (!$checkTime || ($v['start_time'] + 4 * 3600) < TIMESTAMP ) {
			return false;
		}
		return true;

	}

	public function CreateLiveStreamRecordIndexFiles($vid, $bucketName = '', $start_time = ''){
		date_default_timezone_set('Asia/Shanghai');
		global $_G;
		if (!$vid) {
			return false;
		}

		$v = $this->get_video_by_vid($vid);

		$config = $this->config;
		$StreamName = 'course-live'.$v['vid'];
	    $accessKeyId = $config['OSSAccessKeyId'];
	    $accessKeySecret = $config['OssAccessKeySecret'];

	    $profile = DefaultProfile::getProfile($config['live_region'], $accessKeyId,$accessKeySecret);
	    $client = new DefaultAcsClient($profile);


	    $request = new CreateLiveStreamRecordIndexFilesRequest();

	    $request->setAcceptFormat('JSON');
	    $request->setOssEndpoint('oss-'.$config['live_region'].'.aliyuncs.com');
	    $request->setOssBucket($bucketName);
	    $request->setOssObject('record/'.$config['aliyun_live_AppName'].'/course-live'.$vid.'/'.'record.m3u8');
	    $request->setAppName($config['aliyun_live_AppName']);
	    $request->setDomainName($config['aliyun_live_host']);

	    $start_time = $start_time ? $start_time : $v['start_time'];
	    if(!$start_time){
	    	$v['start_time'] = TIMESTAMP - 3600 * 24 * 3;
	    }
	    $request->setStartTime($this->gmt_iso8601($start_time - 3600 * 24));
	    $request->setEndTime($this->gmt_iso8601($start_time + 3600*24 * 3));
	    $request->setStreamName($StreamName);

		try {
    		$response = $client->getAcsResponse($request);
	    } catch (Exception $e) {
	    	// echo dgmdate($start_time);
	    	return false;
	    }
	    
	    return json_decode(json_encode($response->RecordInfo),true);		
	}

	public function auto_publish_live_record($vid ,$checkTime = true, $start_time = ''){
		global $_G;
		if($_GET['start_time']){
			$start_time = $start_time ? $start_time : strtotime($_GET['start_time']) + 0;
		}
		
		if (!$this->config['aliyun_live_record']) {
			return;
		}
		if ($checkTime && $this->check_live_isrecord($vid, $checkTime)) {
			return;
		}
		if ($this->config['live_record_bucket']) {
			$record = $this->CreateLiveStreamRecordIndexFiles($vid,$this->config['live_record_bucket'], $start_time);

		}

		if (empty($record)) {
			$liveRecoreds = $this->DescribeLiveStreamRecordContent($vid, $start_time);
			if (!empty($liveRecoreds)) {
				$ossInfo = end($liveRecoreds);
				if ($ossInfo['OssBucket']) {
					$record = $this->CreateLiveStreamRecordIndexFiles($vid, $ossInfo['OssBucket'], $start_time);
				}
			}
		}


		if ($record['OssObject']) {
			$video_data = array();
			$video_data['video_urltype'] = '12';
			$video_data['video_length'] = ceil($record['Duration']);
			$video_data['video_url'] = $record['OssObject'];
			$video_data['livestatus'] = 2;
			$video_data['isrecord'] = 1;
			C::t("#zhanmishu_video#zhanmishu_video")->update($vid,$video_data);
			// 切换直播状态
			
			return true;
		}
		return false;

		if (!$liveRecoreds || empty($liveRecoreds)) {
			return;
		}
		$v = $this->get_video_by_vid($vid);

		foreach ($liveRecoreds as $key => $value) {
			if (!$value['Duration']) {
				continue;
			}
			$video_data = array();
			$video_data['start_time'] = strtotime($value['StartTime']);
			$video_data['video_length'] = ceil($value['Duration']);
			if ($key  < 1) {
				$video_data['video_url'] = 'record/'.$this->config['aliyun_live_AppName'].'/course-live'.$vid.'.m3u8';
			}else{
				$video_data['video_url'] = 'record/'.$this->config['aliyun_live_AppName'].'/course-live'.$vid.'_'.$key.'.m3u8';
			}
			
			$video_data['cid'] = $v['cid'];
			$video_data['uid'] = $v['uid'];
			$video_data['cat_id'] = $v['cat_id'];
			$video_data['islive'] = '1';
			$video_data['isrecord'] = '1';
			$video_data['video_name'] = $v['video_name'];
			$video_data['video_intro'] = $v['video_intro'];
			$video_data['record_liveid'] = $vid;
			

			$video_data['video_urltype'] = '12';

			$video_data['video_length'] = $_GET['video_length'] + 0;
			$video_data['isfree'] = $v['isfree'];
			$video_data['video_price'] = $v['video_price'];
			$video_data['dateline'] = TIMESTAMP;

			C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,false,false,true);

		}

	}

	public function SetLiveStreamsNotifyUrl(){
		$_G;
		$config = $this->config;

	    $region = $config['live_region'];
	    $accessKeyId = $config['OSSAccessKeyId'];
	    $accessKeySecret = $config['OssAccessKeySecret'];

	    $profile = DefaultProfile::getProfile($region, $accessKeyId,$accessKeySecret);
	    $client = new DefaultAcsClient($profile);
	    

	    $request = new SetLiveStreamsNotifyUrlConfigRequest();
	    $request->setAcceptFormat('JSON');
	    $request->setDomainName($config['aliyun_live_host']);
	    $request->setNotifyUrl($_G['siteurl'].'source/plugin/zhanmishu_video/notify.php');
	    

	    $response = $client->getAcsResponse($request);

	    return $response->RequestId;
	}

	public function oss_transcoding($video_url){
		$config = $this->config;
		if ($config['OssEncryption']) {
			return;
		}
	    $accessKeyId = $config['OSSAccessKeyId'];
	    $accessKeySecret = $config['OssAccessKeySecret'];
	    $pipelineId = $config['OSS_pipelineId'];
	    #oss-cn-hangzhou、oss-cn-shanghai、oss-us-west-1等;与region对应
	    $ossLocation= 'oss-'.$config['OSS_region'];
	    $inputObject=$video_url;
	    $inputBucket= $config['OSSbucket'];
	    $outputObject='hlsvideo/'.$video_url;
	    $outputBucket= $config['OSSbucket'];
	    $transcodeTemplateId=$config['OSS_TemplateId'];

	    $profile = DefaultProfile::getProfile($config['OSS_region'], $accessKeyId,$accessKeySecret);

	    $client = new DefaultAcsClient($profile);

	    $inputFile = array(
	        'Location' => $ossLocation,
	        'Bucket' => $inputBucket,
	        'Object' => urlencode($inputObject));
	    $outputs = array();
	    $outputs[] = array(
	        'OutputObject'=> urlencode($outputObject),
	        'TemplateId' => $transcodeTemplateId,
	    );
	    $request = new SubmitJobsRequest();
	    $request->setAcceptFormat('JSON');
	    // $request->setRegionId($config['OSS_region']);
	    $request->setInput(json_encode($inputFile));
	    $request->setOutputBucket($outputBucket);
	    $request->setOutputLocation($ossLocation);
	    $request->setOUtputs(json_encode($outputs));
	    $request->setPipelineId($pipelineId);

	    $response = $client->getAcsResponse($request);

	    return $response->JobResultList->JobResult[0]->Job->JobId;
	}
	public function ossDecrypt($params = array()){
		$config = $this->config;

	    $region = $config['OSS_region'];
	    $accessKeyId = $config['OSSAccessKeyId'];
	    $accessKeySecret = $config['OssAccessKeySecret'];

	    $profile = DefaultProfile::getProfile($region, $accessKeyId,$accessKeySecret);
	    $client = new DefaultAcsClient($profile);

	    $request = new DecryptRequest();
	    $request->setAcceptFormat('JSON');
	    $request->setProtocol('HTTPS');
	    // $request->setRegionId('kms.cn-hangzhou.aliyuncs.com');
	    $request->setCiphertextBlob($params['Ciphertext']);

	    $response = $client->getAcsResponse($request);


	    return base64_decode($response->Plaintext);  
	}

	public function qiniu_transcoding($video_url){

		if ($this->config['upload_type'] == '1') {
			return $this->oss_transcoding($video_url);
		}else {
			//需要填写你的 Access Key 和 Secret Key
			$accessKey = $this->config['qiniuaccessKey'];
			$secretKey = $this->config['qiniusecretKey'];

			// 构建鉴权对象
			$auth = new Qiniu_Auth($accessKey, $secretKey);

			$f = $this->getfileexten(trim($video_url));


			//进行数据持久化转码
			$PersistentFop = new PersistentFop($auth,$this->config['Bucket_Name'],$this->config['playzhanvideo']);
			$newkey = Qiniu_common_function::base64_urlSafeEncode($this->config['Bucket_Name'].':'.$f[0].'.m3u8');


			//$r = $PersistentFop->execute($video_url,'avthumb/m3u8/segtime/10/ab/128k/ar/44100/acodec/libfaac/r/30/vb/640k/vcodec/libx264/stripmeta/0/noDomain/1|saveas/'.$newkey);
			//$r = $PersistentFop->execute($video_url,'avthumb/m3u8/segtime/10/ab/128k/ar/44100/acodec/libfaac/r/30/vb/1000k/vcodec/libx264/stripmeta/0|saveas/'.$newkey);
			//avthumb/m3u8/segtime/10/ab/128k/ar/44100/acodec/libfaac/r/30/vb/640k/vcodec/libx264/stripmeta/0/noDomain/1|saveas/
			
			//
			if ($this->config['qiniu_hlsKeyUrl']) {
				global $_G;
				$hlsKeyUrl = $_G['siteurl'].$this->config['qiniu_hlsKeyUrl'];
				$hlsKeyUrl = Qiniu_common_function::base64_urlSafeEncode($hlsKeyUrl);

			}
			if ($this->config['qiniu_hlsKey']) {
				$this->config['qiniu_transtype'] = str_replace('|saveas/', '/hlsKey/'.$this->config['qiniu_hlsKey'].'/hlsKeyType/'.$this->config['qiniu_hlsKeyType'].'/hlsKeyUrl/'.$hlsKeyUrl.'|saveas/',$this->config['qiniu_transtype']);
			}


			$r = $PersistentFop->execute($video_url,$this->config['qiniu_transtype'].$newkey);

			if ($r['0']) {
				return $r['0'];
			}else{
				exit('qiniu_transcod error: '.$r[1]->message());
			}			
		}
	}

	public function qiniu_check_transcoding_status($id){
		//需要填写你的 Access Key 和 Secret Key
		$accessKey = $this->config['qiniuaccessKey'];
		$secretKey = $this->config['qiniusecretKey'];

		// 构建鉴权对象
		$auth = new Qiniu_Auth($accessKey, $secretKey);
		//进行数据持久化转码
		$PersistentFop = new PersistentFop($auth,$this->config['Bucket_Name'],$this->config['playzhanvideo']);
		$status = $PersistentFop->status($id);

		return $status;
	}

	public function qiniu_get_m3u8_pravite_url($video_url='',$expertime=0){
		//需要填写你的 Access Key 和 Secret Key
		$accessKey = $this->config['qiniuaccessKey'];
		$secretKey = $this->config['qiniusecretKey'];

		$f = $this->getfileexten(trim($video_url));

		// 构建鉴权对象
		$auth = new Qiniu_Auth($accessKey, $secretKey);
		//$expires = TIMESTAMP + $expertime;

		$baseUrl = $this->config['qiniuencdoeurl'].rawurlencode($this->auto_to_utf8($f['0'])).'.m3u8?pm3u8/0';
		$authUrl = $auth->privateDownloadUrl($baseUrl);


	    if ($this->config['qiniuencdoeurl'] != $this->config['qiniuurl']) {
	    	$authUrl = str_replace($this->config['qiniuencdoeurl'], $this->config['qiniuurl'], $authUrl);
	    }

		return $authUrl;
	}


	public function get_device_type(){
		$agent = strtolower($_SERVER['HTTP_USER_AGENT']);
		$type = 'other';
		if(strpos($agent, 'iphone') || strpos($agent, 'ipad')){
			$type = 'ios';
		}else if(strpos($agent, 'android')){
			$type = 'android';
		}else if(strpos($agent, 'chrome')){
			$type = 'chrome';
		}else if(strpos($agent, 'safari')){
			$type = 'safari';
		}
		return $type;
	}

	public function QueryJobList($JobId){
		$config = $this->config;

	    $region = $config['OSS_region'];
	    $accessKeyId = $config['OSSAccessKeyId'];
	    $accessKeySecret = $config['OssAccessKeySecret'];
	    #jobId split by ',' ,at most ten jobId
	    $jobIds=$JobId;
	    $profile = DefaultProfile::getProfile($region, $accessKeyId, $accessKeySecret);
	    $client = new DefaultAcsClient($profile);
	    $request = new QueryJobListRequest();
	    $request->setAcceptFormat('JSON');
	    $request->setJobIds($jobIds);
	    $response = $client->getAcsResponse($request);
	    $jobs = $response->JobList->Job;

		if($jobs[0]->State == 'TranscodeSuccess'){
			return 1;
		}
		return false;
	}

	public function get_private_videourl_oss(array $v){
		if ($v['is_rsa'] && $this->config['OssEncryptionUrl'] && $this->config['OssEncryption']) {
			// /zhanmishu_video/201903/210932m72k34jjc2d893ce.mp4
			// $file = '{ObjectPrefix}{FileName}/{FileName}';
			$f = $this->getfileexten($v['video_url']);

			$videoUrlArray = explode('/',$v['video_url']);
			$videoFileName = end($videoUrlArray);

			$hlsVideoUrl = $f[0].'/'.$videoFileName;
			$f = $this->getfileexten($hlsVideoUrl);
			$hlsVideoUrl = $f[0].'.m3u8';
			return $this->config['OssEncryptionUrl'].'/'.$this->OSS_CDN_sign($hlsVideoUrl);
		}
		
		if ($v['ismusic'] && defined('IN_MOBILE_API')) {
			return $this->config['oss_url'].'/'.$this->OSS_CDN_sign($v['video_url']);
		}
		if ($v['istranscoding'] == '1' && $v['transcodingid']) {
			$status = $this->QueryJobList($v['transcodingid']);
			if ($status) {
				C::t("#zhanmishu_video#zhanmishu_video")->update($v['vid'],array('istranscoding'=>'2'));
			}
		}
		return $this->config['oss_url'].'/'.$this->oss_get_m3u8_pravite_url($v['video_url']);

	}
	public function get_private_videourl_aliyun_live_record($v){

		return $this->config['live_record_host'].'/'.$this->OSS_CDN_sign($v['video_url'],$this->config['live_record_cdnkey']);;

	}

	public function oss_get_m3u8_pravite_url($video_url){
		return $this->OSS_CDN_sign('hlsvideo/'.$video_url.'.m3u8');
	}

	function OSS_CDN_sign($url,$signKey=''){
		$config = $this->config;
		if (!$signKey) {
			 $signKey = $config['cdn_akey'];
		}
		$expire=TIMESTAMP + 18000;

		// /video/standard/1K.html-1444435200-0-0-aliyuncdnexp1234"
		$str = '/'.$url.'-'.$expire.'-0-0-'.$signKey;
		$HashValue = md5($str);
		return $url.'?auth_key='.$expire.'-0-0-'.$HashValue;
	}

	function Oss_Signatureurl($filename){
		$config = $this->config;

		$expire=TIMESTAMP + 200;
		$bucketname=$config['OSSbucket'];
		
		$StringToSign="GET\n\n\n$expire\n/$bucketname/$filename";
		$Sign=base64_encode(hash_hmac("sha1",$StringToSign,$config['OssAccessKeySecret'],true));
		return $filename."?OSSAccessKeyId=".rawurlencode($config['OSSAccessKeyId'])."&Expires=".$expire."&Signature=".rawurlencode($Sign);
	}

	public function get_private_videourl_aliyun_live($v){
		if (empty($v)) {
			return '';
		}
		global $_G;
		$AppName = $this->config['aliyun_live_AppName'];
		$StreamName = 'course-live'.$v['vid'];
		$host = $this->config['aliyun_live_host'];
		$time = TIMESTAMP + $this->config['aliyun_live_timeout'];
		$key = $this->config['aliyun_live_key'];
		$strpush = "/$AppName/$StreamName-$time-0-0-$key";
		if ($v['uid'] == $_G['uid'] || $_G['groupid'] == '1') {
			if ($this->config['aliyun_live_publicurl'] == 'rtmp://video-center-bj.alivecdn.com/' || $this->config['aliyun_live_publicurl'] == 'rtmp://video-center.alivecdn.com/') {
				/*
				里面的直播推流中心服务器域名、vhost域名可根据自身实际情况进行设置
				*/
				$pushurl = array(
					'url'=> $this->config['aliyun_live_publicurl']."$AppName",
					'password'=>"$StreamName?vhost=$host&auth_key=$time-0-0-".md5($strpush)
				);
			}else{
				if (preg_match('/rtmp:\/\/.*\//',$this->config['aliyun_live_publicurl'])) {
					$pushurl = array(
						'url'=> $this->config['aliyun_live_publicurl']."$AppName",
						'password'=>"$StreamName?auth_key=$time-0-0-".md5($strpush)
					);
				}else{
					$pushurl = array(
						'url'=> 'rtmp://'.$this->config['aliyun_live_publicurl'].'/'."$AppName",
						'password'=>"$StreamName?auth_key=$time-0-0-".md5($strpush)
					);
				}
				
			}

		}else{
			$pushurl = '';
		}

		$strviewrtmp = "/$AppName/$StreamName-$time-0-0-$key";
		$strviewflv = "/$AppName/$StreamName.flv-$time-0-0-$key";
		$strviewm3u8 = "/$AppName/$StreamName.m3u8-$time-0-0-$key";

		$http = $_G['isHTTPS'] ? 'https' : 'http';

		$rtmpurl = "rtmp://$host/$AppName/$StreamName?auth_key=$time-0-0-".md5($strviewrtmp);
		$flvurl = "$http://$host/$AppName/$StreamName.flv?auth_key=$time-0-0-".md5($strviewflv);
		$m3u8url = "$http://$host/$AppName/$StreamName.m3u8?auth_key=$time-0-0-".md5($strviewm3u8);

		$return = array();
		$return['pushurl'] = $pushurl;
		$return['video_url']['rtmpurl'] = $rtmpurl;
		$return['video_url']['flvurl'] = $flvurl;
		$return['video_url']['m3u8url'] = $m3u8url;

		return $return;
	}

	public function sha256_hex($string_to_sign, $siging_key) {
	    return hash_hmac('sha256', $string_to_sign, $siging_key);
	}
	public function get_private_videourl_baidu_live($v){
		if (empty($v)) {
			return '';
		}
		global $_G;
		$AppName = $this->config['baidu_live_appname'];
		$StreamName = 'course-live'.$v['vid'];
		$host = $this->config['baidu_live_url'];

		$time = TIMESTAMP + $this->config['baidu_live_timeout'];
		$key = $this->config['baidu_live_token'];
		/*
		里面的直播推流中心服务器域名、vhost域名可根据自身实际情况进行设置
		*/
		if ($v['uid'] == $_G['uid'] || $_G['groupid'] == '1') {
			//$strpush = "/$AppName/$StreamName-$time-0-0-$key";
			$strpush = "/$AppName/$StreamName";

			$sign_str = 'rtmp://'.$this->config['baidu_live_publicurl'].'/'.$AppName.'/'.$StreamName.';'.$this->gmt_iso8601($time);
			$pushurl = array(
				//rtmp://<push.your-domain.com>/<your-app>/<your-stream>?token=计算出来的token值&expire=2016-10-10T00:00:00Z
				'url'=> 'rtmp://'.$this->config['baidu_live_publicurl']."/$AppName",
				'password'=>$StreamName.'?token='.$this->sha256_hex($sign_str,$key).'&expire='.$this->gmt_iso8601($time)
			);
		}else{
			$pushurl = '';
		}

		//http://<play.your-domain.com>/<your-app>/<your-stream>.flv
		//rtmp://<play.your-domain.com>/<your-app>/<your-stream>
		//http://<play.your-domain.com>/<your-app>/<your-stream>.m3u8

		$strviewrtmp = "/$AppName/$StreamName";
		$strviewflv = "/$AppName/$StreamName.flv";
		$strviewm3u8 = "/$AppName/$StreamName.m3u8";

		$http = $_G['isHTTPS'] ? 'https' : 'http';

		//http://{playdomain}/{app}/{stream}.flv?timestamp=149055612&secret=3b927f3f31dd31613a537fad7a640a76
		//md5(111/play.domain.com/live/ghs149055612)=3b927f3f31dd31613a537fad7a640a76

		$sign_str = $key.'/'.$host.'/'.$AppName.'/'.$StreamName.$time;
		$secret = md5($sign_str);


		$rtmpurl = "rtmp://$host/$AppName/$StreamName?timestamp=".$time.'&secret='.$secret;
		$flvurl = "$http://$host/$AppName/$StreamName.flv?timestamp=".$time.'&secret='.$secret;
		$m3u8url = "$http://$host/$AppName/$StreamName.m3u8?timestamp=".$time.'&secret='.$secret;

		$return = array();
		$return['pushurl'] = $pushurl;
		$return['video_url']['rtmpurl'] = $rtmpurl;
		$return['video_url']['flvurl'] = $flvurl;
		$return['video_url']['m3u8url'] = $m3u8url;

		return $return;
	}
	public function get_private_videourl($vid){
		$config = $this->config;

		if (!$vid) {
			return '';
		}
		$v = $this->get_video_by_vid($vid);

		if (empty($v)) {
			return '';
		}
		if ($v['video_urltype'] == '9') {
			$v['video_url'] = self::strToArray($v['video_url']);

			if ($this->get_device_type() == 'ios' ||$this->get_device_type() == 'android' || $this->get_device_type() == 'safari') {
				return $v['video_url']['1'];
			}else{
				return $v['video_url']['0'];
			}
		}
		// oss filetype
		if ($v['video_urltype'] == '10') {
			return $this->get_private_videourl_oss($v);
		}
		if ($v['video_urltype'] == '11') {
			return $this->get_private_videourl_aliyun_live($v);
		}
		if ($v['video_urltype'] == '13') {
			return $this->get_private_videourl_baidu_live($v);
		}
		if ($v['video_urltype'] == '12') {
			return $this->get_private_videourl_aliyun_live_record($v);
		}
		if ($v['video_urltype'] == '3') {
			return $this->auto_to_url($v['video_url']);
		}
		if ($v['video_urltype'] !== '1') {
			return $v['video_url'];
		}
		
		$f = $this->getfileexten(trim($v['video_url']));
		if (strtolower($f[1] !== 'm3u8' && $v['istranscoding'] == '0')) {
			$id = $this->qiniu_transcoding($v['video_url']);
			C::t("#zhanmishu_video#zhanmishu_video")->update($v['vid'],array('istranscoding'=>'1','transcodingid'=>$id));
			$v['transcodingid'] = $id;
		}
		
		if ($v['istranscoding'] == '1' && $v['transcodingid']) {
			$status = $this->qiniu_check_transcoding_status($v['transcodingid']);
			if ($status[0]['code'] == '0') {
				$data = array('istranscoding'=>'2');
				if ($this->config['qiniu_hlsKeyUrl']) {
					$data['is_rsa'] = '1';
				}

				C::t("#zhanmishu_video#zhanmishu_video")->update($v['vid'],$data);
			}
		}

		if ($v['istranscoding'] !== '2') {
			//showmessage('transcoding_please_waiting','',array('alert'=>'right'));
		}

		if ($v['istranscoding'] == '1' || $v['istranscoding'] == '2' || $status[0]['code'] == '1' || strtolower($f['1']) == '.m3u8') {
			return $this->qiniu_get_m3u8_pravite_url($v['video_url']);
		}


		//需要填写你的 Access Key 和 Secret Key
	    $accessKey = $config['qiniuaccessKey'];
	    $secretKey = $config['qiniusecretKey'];

	    // 构建鉴权对象
	    $auth = new Qiniu_Auth($accessKey, $secretKey);
	    $f = $this->getfileexten(trim($v['video_url']));


	    //baseUrl构造成私有空间的域名/key的形式
	    $baseUrl = $config['qiniuencdoeurl'].rawurlencode($this->auto_to_utf8($f['0'])).$f['1'];
	    $authUrl = $auth->privateDownloadUrl($baseUrl);

	    if ($config['qiniuencdoeurl'] != $config['qiniuurl']) {
	    	$authUrl = str_replace($config['qiniuencdoeurl'], $config['qiniuurl'], $authUrl);
	    }

	    return $authUrl;
	}

	public function getfileexten($file){
		$tmp = explode('.',$file);
		if (empty($tmp) && count($tmp) < 2) {
			return false;
		}
		$ext = '.'.end($tmp);
		array_pop($tmp);
		$filename = implode('.', $tmp);
		return array($filename,$ext);
	}

	public function get_duration_video($url){
		$vinfo = $this->Curl($url);
		return $vinfo['streams']['0']['duration'];
	}


	public function get_cat_by_cat_id($cat_id){
		if (!$cat_id) {
			return false;
		}
		return C::t("#zhanmishu_video#zhanmishu_video_cat")->fetch($cat_id);
	}

	public function get_cat_by_level($level='0',$order){
		return C::t("#zhanmishu_video#zhanmishu_video_cat")->get_cat_by_level($level,$order);
	}

	public function get_touch_swiper($updateCache=false){

		return $this->ZmsGetFromCache('touch_swiper');

	}
	public function get_touch_best(){
		return $this->ZmsGetFromCache('touch_best');
	}
	public function update_touch_bestcache_init($touch_best=array()){
		if (!empty($touch_best)) {
			foreach ($touch_best as $key => $value) {
				$c = $this->get_course_bycid($value['cid']);
				if ($c['cat_id']) {
					$cat = $this->get_cat_by_cat_id($c['cat_id']);
				}
				$user = getuserbyuid($c['uid']);
				unset($user['password']);

				if (!empty($cat)) {
					$touch_best[$key] = array_merge($user,$value,$cat,$c);
				}else{
					$touch_best[$key] = array_merge($user,$value,$c);
				}
			}


		}
		$this->ZmswriteToCache('touch_best',$touch_best);
	}
	public function update_touch_swipercache_init($swiper){
		global $zhanmishu_videoconf;
		if (is_array($swiper) && !empty($swiper)) {
			$touch_swiper = $swiper;
		}else{
			$touch_swiper = array();
		}
		
		$this->ZmswriteToCache('touch_swiper',$touch_swiper);

	}

	public function get_app_swiper($updateCache=false){
		$swiper = $this->ZmsGetFromCache('app_swiper');
		foreach ($swiper as $key => $value) {
			// 兼容老数据
			if (!$value['url'] && $value['cid']) {
				$swiper[$key]['platform'] = '0';
                $swiper[$key]['urlType'] = '1';
                $swiper[$key]['url'] = '/pages/CourseDetails/CourseDetails?cid=' . $value['cid'];
			}else if ($swiper[$key]['urlType'] == '0') {
				$swiper[$key]['url'] = $this->auto_to_url($value['url']);
			}

			$swiper[$key]['image'] = $this->auto_to_url($value['image']);
		}
		return $swiper;
	}
	public function get_app_best(){
		$best = $this->ZmsGetFromCache('app_best');

		foreach ($best as $key => $value) {
            // 兼容老数据
            if ($value['cid'] && !$value['url']) {
                $best[$key]['platform'] = '0';
                $best[$key]['urlType'] = '1';
                $best[$key]['url'] = '/pages/CourseDetails/CourseDetails?cid=' . $value['cid'];
            }else if ($nav_list[$key]['urlType'] == '0') {
				$best[$key]['url'] = $this->auto_to_url($value['url']);
			}
			$best[$key]['course_img'] = $this->auto_to_url($value['course_img']);
			$best[$key]['course_intro'] = cutstr($best[$key]['course_intro'], 80);
			$best[$key]['image'] = $this->auto_to_url($value['image']);
		}
		return $best;
	}
	public function update_app_swipercache_init($swiper){
		global $zhanmishu_videoconf;
		if (is_array($swiper) && !empty($swiper)) {
			$touch_swiper = $swiper;
		}else{
			$touch_swiper = array();
		}
		
		$this->ZmswriteToCache('app_swiper',$touch_swiper);

	}
	public function update_app_bestcache_init($touch_best=array()){
		if (!empty($touch_best)) {
			foreach ($touch_best as $key => $value) {
				$c = $this->get_course_bycid($value['cid']);
				if ($c['cat_id']) {
					$cat = $this->get_cat_by_cat_id($c['cat_id']);
				}
				$user = getuserbyuid($c['uid']);
				unset($user['password']);

				if (!empty($cat)) {
					$touch_best[$key] = array_merge($user,$value,$cat,$c);
				}else{
					$touch_best[$key] = array_merge($user,$value,$c);
				}
			}


		}
		$this->ZmswriteToCache('app_best',$touch_best);
	}


	public function get_nav_list($updateCache=false){
		global $_G;
		$nav_list = $this->ZmsGetFromCache('nav_list');

		if (empty($nav_list)) {
			$cat = $this->get_cat_tree();

			foreach ($cat as $key => $value) {
				$nav_list[] = array(
					'cat_id'=>$value['cat_id'],
					'cat_name'=>$value['cat_name'],
					'cat_icon'=>$value['cat_icon'],
					'url'=>''
				);
			}
		}
		foreach ($nav_list as $key => $value) {
			if (!$value['cat_icon']) {
				$value['cat_icon'] = 'source/plugin/zhanmishu_video/template/img/nav-2.png';;
			}
            // 兼容老数据
            if ($value['cat_id'] && !$value['url']) {
                $nav_list[$key]['platform'] = '0';
                $nav_list[$key]['urlType'] = '1';
                $nav_list[$key]['url'] = '/pages/courselist/courselist?cat_id=' . $value['cat_id'];
            }else if ($nav_list[$key]['urlType'] == '0') {
				$nav_list[$key]['url'] = $this->auto_to_url($value['url']);
			}

			$nav_list[$key]['cat_icon'] = $this->auto_to_url($value['cat_icon']);
			
		}
		return $nav_list;
	}

	public function auto_to_url($str=''){
		if (!$str) {
			return '';
		}
		global $_G;
		if ($this->check_liveorvideo($str) != 'url' && defined('IN_MOBILE_API')) {
			return str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']).$str;
		}else if ($this->check_liveorvideo($str) != 'url' && !defined('IN_MOBILE_API')) {
			
			return $_G['siteurl'].$str;
		}
		return $str;
	}

	public function update_nav_listcache_init($nav_list){
		$nav_list = $this->multisort($nav_list,'order');
		if (is_array($nav_list) && !empty($nav_list)) {
			$touch_swiper = $nav_list;
		}else{
			$touch_swiper = array();
		}
		
		$this->ZmswriteToCache('nav_list',$touch_swiper);

	}
	public function get_item_list($updateCache=false){
		global $_G;
		$item_list = $this->ZmsGetFromCache('item_list');

		foreach ($item_list as $key => $value) {
			$item_list[$key]['url'] = $this->auto_to_url($value['url']);
			if (!$value['item_icon']) {
				$value['item_icon'] = 'source/plugin/zhanmishu_video/template/img/nav-2.png';
			}
			$item_list[$key]['item_icon'] = $this->auto_to_url($value['item_icon']);
		}

		return $item_list;
	}
	public function update_item_listcache_init($item_list){
		global $zhanmishu_videoconf;
		$item_list = $this->multisort($item_list,'order');
		if (is_array($item_list) && !empty($item_list)) {
			$touch_swiper = $item_list;
		}else{
			$touch_swiper = array();
		}
		
		$this->ZmswriteToCache('item_list',$touch_swiper);

	}
	public function get_gift_list($updateCache=false){
		global $_G;
		$gift_list = $this->ZmsGetFromCache('gift_list');

		foreach ($gift_list as $key => $value) {
			$gift_list[$key]['gift_id'] = $key;
			$gift_list[$key]['url'] = $this->auto_to_url($value['url']);
			

			if (!$value['gift_icon']) {
				$value['gift_icon'] = 'source/plugin/zhanmishu_video/template/img/nav-2.png';
			}
			$gift_list[$key]['gift_icon'] = $this->auto_to_url($value['gift_icon']);
			
		}

		return $gift_list;
	}
	public function update_gift_listcache_init($gift_list){
		$gift_list = $this->multisort($gift_list,'order');
		if (is_array($gift_list) && !empty($gift_list)) {
			$touch_swiper = $gift_list;
		}else{
			$touch_swiper = array();
		}
		
		$this->ZmswriteToCache('gift_list',$touch_swiper);

	}

    public function get_reward_list($updateCache=false){
        global $_G;
        $reward_list = $this->ZmsGetFromCache('reward_list');

        foreach ($reward_list as $key => $value) {
            $reward_list[$key]['reward_id'] = $key;
        }
        // 给默认值
        if (empty($reward_list)) {
        	$reward_list =   array (
			    0 => array (
			      'order' => '',
			      'reward_score' => '1',
			    ),
			    1 => array (
			      'order' => '',
			      'reward_score' => '3',
			    ),
			    2 => array (
			      'order' => '',
			      'reward_score' => '10',
			    ),
			    3 => array (
			      'order' => '',
			      'reward_score' => '20',
			    ),
			    4 => array (
			      'order' => '',
			      'reward_score' => '50',
			    ),
			    5 => array (
			      'order' => '1',
			      'reward_score' => '2',
			    ),
			  );
        }
        return $reward_list;
    }
    public function update_reward_listcache_init($reward_list){
        $reward_list = $this->multisort($reward_list,'order');
        if (is_array($reward_list) && !empty($reward_list)) {
            $touch_swiper = $reward_list;
        }else{
            $touch_swiper = array();
        }
        
        $this->ZmswriteToCache('reward_list',$touch_swiper);

    }


	public function get_pc_swiper($updateCache=false){

		return $this->ZmsGetFromCache('pc_swiper');

	}
	public function get_pc_best(){
		return $this->ZmsGetFromCache('pc_best');
	}
	public function update_pc_bestcache_init($pc_best=array()){
		if (is_array($pc_best) && !empty($pc_best)) {
			$pc_best = $pc_best;
		}
		$this->ZmswriteToCache('pc_best',$pc_best);
	}
	public function update_pc_swipercache_init($swiper){
		global $zhanmishu_videoconf;
		if (is_array($swiper) && !empty($swiper)) {
			$touch_swiper = $swiper;
		}else{
			$touch_swiper = array();
		}
		
		$this->ZmswriteToCache('pc_swiper',$touch_swiper);

	}

	public function get_target_dir($type, $extid = '', $check_exists = true) {

		$subdir = $subdir1 = $subdir2 = '';
		if($type == 'album' || $type == 'zhanmishu_video' || $type == 'portal' || $type == 'category' || $type == 'profile') {
			$subdir1 = date('Ym');
			// $subdir2 = date('d');
			$subdir = $subdir1.'/';
		} elseif($type == 'group' || $type == 'common') {
			$subdir = $subdir1 = substr(md5($extid), 0, 2).'/';
		}

		$check_exists && $this->check_dir_exists($type, $subdir1, $subdir2);

		return $subdir;
	}
	function gmt_iso8601($time) {

	    $dtStr = date("c", $time);
	    $mydatetime = new DateTime($dtStr);
	    $expiration = $mydatetime->format(DateTime::ISO8601);
	    $pos = strpos($expiration, '+');
	    $expiration = substr($expiration, 0, $pos);
	    return $expiration."Z";
	}
	public function get_target_filename($type, $extid = 0, $forcename = '') {
		if($type == 'group' || ($type == 'common' && $forcename != '')) {
			$filename = $type.'_'.intval($extid).($forcename != '' ? "_$forcename" : '');
		} else {
			$filename = date('His').strtolower(random(8));
		}
		$this->config['oss_filename_head'] = isset($this->config['oss_filename_head']) ? $this->config['oss_filename_head'] : '';
		return $this->config['oss_filename_head'].$filename;
	}
	public function check_dir_exists($type = '', $sub1 = '', $sub2 = '') {

		$type = $this->check_dir_type($type);

		$basedir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT.'./data/attachment') : getglobal('setting/attachdir');

		$typedir = $type ? ($basedir.'/'.$type) : '';
		$subdir1  = $type && $sub1 !== '' ?  ($typedir.'/'.$sub1) : '';
		$subdir2  = $sub1 && $sub2 !== '' ?  ($subdir1.'/'.$sub2) : '';

		$res = $subdir2 ? is_dir($subdir2) : ($subdir1 ? is_dir($subdir1) : is_dir($typedir));
		if(!$res) {
			$res = $typedir && $this->make_dir($typedir);
			$res && $subdir1 && ($res = $this->make_dir($subdir1));
			$res && $subdir1 && $subdir2 && ($res = $this->make_dir($subdir2));
		}

		return $res;
	}
	public function get_token($current='zhanmishu_video'){
		$oss_config = $this->config;

		$expiretime = TIMESTAMP + 360;
		$policy_data = array();
		$filepath = $current.'/'.$this->get_target_dir($current,0);

		$policy_data['expiration'] = $this->gmt_iso8601($expiretime);
		$policy_data['conditions'][] = array(0=>'content-length-range', 1=>0, 2=> 1024 * 1024 * $this->config['upload_max_size']);
		//$policy_data['conditions'][] = array(0=>'Disposition',1=>$_GET['filename']);
		// $policy_data['conditions'][] = array(0=>'starts-with', 1=>'$key', 2=>$filepath);

		$data = array();
		$data['OSSAccessKeyId'] = $oss_config['OSSAccessKeyId'];
		$data['policy'] = base64_encode(json_encode($policy_data));
		$data['expire'] = $expiretime;
		$data['filepath'] = $filepath;
		$data['target_filename'] = $this->get_target_filename($current,0,'');
		$data['host'] = $oss_config['oss_upload_url'];
		$data['signature'] = base64_encode(hash_hmac('sha1', $data['policy'], $oss_config['OssAccessKeySecret'] , true));//生成认证签名
		return $data;

	}
	function make_dir($dir, $index = true) {
		$res = true;
		if(!is_dir($dir)) {
			$res = @mkdir($dir, 0777);
			$index && @touch($dir.'/index.html');
		}
		return $res;
	}

	public	function check_dir_type($type) {
		return !in_array($type, array('forum', 'group', 'album', 'portal', 'common', 'temp', 'category', 'profile','zhanmishu_video')) ? 'temp' : $type;
	}

	public function get_type_reply($start = 0, $limit = 0, $sort = '',$field = array()){
		$replies = C::t("#zhanmishu_video#zhanmishu_video_reply")->get_type_reply($start, $limit, $sort,$field);

		global $_G;
		foreach ($replies as $key => $value) {
			$user = getuserbyuid($value['uid']);
			$replies[$key]['username'] = $user['username'];
			$replies[$key]['create_time'] = dgmdate($value['dateline'],'Y-m-d');
			$replies[$key]['avatar'] = avatar($value['uid'], 'middle', true);
			$replies[$key]['score'] = intval($replies[$key]['score']);

			if ($value['reply_uid']) {
				$replyUser = getuserbyuid($value['reply_uid']);
				$replies[$key]['reply_user'] = $replyUser['username'];
				$replies[$key]['reply_avatar'] = avatar($value['reply_uid'], 'middle', true);
			}
			if ($_G['uid']) {
				$replies[$key]['ispraise'] = '0';
			}else{
				$replies[$key]['ispraise'] = '';
			}
		}

		return $replies;
	}

	public function get_course_tags_bycid($cid='' , $vid= ''){
		if (!$cid && !$vid) {
			return '';
		}

		// $c = $this->get_course_bycid($cid);
		
		$field = array();
		$field['cid'] = $cid;
		$field['islive'] = '1';
		$field['isdel'] = '0';

		$tags = array();
		if (!$vid) {
			// 优先查询正在直播的
			$livingField = $field;
			$livingField['start_time'] = array(
				'key' => 'start_time', 
				'relation' => '<=',
				'value' => TIMESTAMP
			);
			$livingField['isrecord'] = '0';
			$video = C::t("#zhanmishu_video#zhanmishu_video")->get_one_video_byfield($livingField,'desc');

			if (empty($video)) {
				// 查询是否有未开始的
				$notStartField = $field;
				$notStartField['start_time'] = array(
					'key' => 'start_time', 
					'relation' => '>',
					'value' => TIMESTAMP
				);
				$notStartField['isrecord'] = '0';
				$video = C::t("#zhanmishu_video#zhanmishu_video")->get_one_video_byfield($notStartField,'desc');
			}
			if (empty($video)) {
				$video = C::t("#zhanmishu_video#zhanmishu_video")->get_one_video_byfield($field,'desc');
			}
		}else{

			$video = C::t("#zhanmishu_video#zhanmishu_video")->fetch($vid);
			if ($video['islive'] == '0' && $video['isrecord'] == '0') {
				return '';
			}
		}
		if (!empty($video)) {
			$tmp = array();
			$tmp['islive']  = '1';
			$tmp['dstart_time']  = $video['start_time'];
			$tmp['start_time']  = $video['start_time'];
			$tmp['livestatus']  = $video['livestatus'];

			//livestatus   0  live_is_not arrived; 1 liveing; 2 live_end
			if ($video['isrecord'] == '1') {
				$tmp['start_time'] = dgmdate($tmp['start_time'],'dt');
				$tmp['livestatus'] = '2';
			}else if ($tmp['start_time'] > TIMESTAMP) {
				$tmp['livestatus'] = '0';
				if (dgmdate($tmp['start_time'],'d') == dgmdate(TIMESTAMP,'d')) {
					$tmp['start_time'] = lang('plugin/zhanmishu_video','todaytime').dgmdate($tmp['start_time'],'t');
				}else if (dgmdate($tmp['start_time'],'d') == dgmdate(TIMESTAMP + 3600 * 24,'d')) {
					$tmp['start_time'] = lang('plugin/zhanmishu_video','tomorrow').dgmdate($tmp['start_time'],'t');
				}else if (dgmdate($tmp['start_time'],'d') == dgmdate(TIMESTAMP + 3600 * 48,'d')) {
					$tmp['start_time'] = lang('plugin/zhanmishu_video','tomorrow_after').dgmdate($tmp['start_time'],'t');
				}else{
					$tmp['start_time'] = dgmdate($tmp['start_time'], 'm-d H:i');
				}
				$tmp['livestatus'] = '0';

			}else {
				$tmp['start_time'] = dgmdate($tmp['start_time'], 'm-d H:i');
				$tmp['livestatus'] = '1';
			}

			$tags['liveInfo'] = $tmp;
			return $tags;
		}

		return '';
	}

	public function get_reply_tree($start = 0,$limit = 20 ,$sort = '' ,$field = array()) {
		global $_G;
		if ($field['parent_id']) {
			$limit = 0;
			$start = 0;
		}
		if (empty($field) || $field['parent_id'] < 1) {
			$field['parent_id'] = 0 ;
		}

		$replies = $this->get_type_reply($start, $limit, $sort,$field);

		if (empty($replies)) {
			return $replies;
		}
		if (!empty($replies)) {
			foreach ($replies as $key => $value) {
				if ($value['reply_id']) {
					$replyField = $field;
					$replyField['parent_id'] = $value['reply_id'];
					$replies[$key]['son'] = $this->get_reply_tree(0,0,'',$replyField);
				}
			}
		}

		return $replies;
	}

	public function get_videos_group_by_cid($start=0, $limit=0, $sort = '',$field=array()) {
		return C::t("#zhanmishu_video#zhanmishu_video")->get_videos_group_by_cid($start, $limit, $sort,$field);

	}

	public function update_islive_by_video_urltype($video_urltype = array(),$limit = 200){
		return C::t('#zhanmishu_video#zhanmishu_video')->update_islive_by_video_urltype($video_urltype,$limit);
	}

	public function getShareText($type = '', $data = null){
		if ($type == 'index' && is_null($data)) {
			return $this->config['indexShareText'];
		}else if ($type == 'index' && !is_null($data)) {
			$shareText = $this->config['listShareText'];
			return str_replace('{cat_name}',$data['cat_name'],$shareText);
		}else if ($type == 'video' && !is_null($data)) {
			$shareText = $this->config['videoShareText'];
			$shareText = str_replace('{course_name}',$data['course_name'],$shareText);
			return str_replace('{video_name}',$data['current']['video_name'],$shareText);
		}

		return '';
	}

	public function checkIsTeacher($uid = '') {
		global $_G;
		$config = $this->config;
		$uid = $uid ? $uid : $_G['uid'];
		//检查是否是老师
		if ($uid && $uid == $_G['uid']) {
			$extgroups = explode("\t", $_G['member']['extgroupids']);
			$extgroups[] = $_G['groupid'];
		}else if ($uid) {
			$member = getuserbyuid($uid);
			$extgroups = explode("\t", $member['extgroupids']);
			$extgroups[] = $member['groupid'];		
		}
		$course_groupin = array_intersect($extgroups, $config['teachergroup']);
		if (empty($course_groupin)) {
			return false;
		}
		return true;
	}

	public function getTeacherInfo($uid = '' , $isCourseInfo = false , $isUpdateCourseInfo = false, $replaceUrl =false){
		global $_G;
		if (!$uid) {
			return array();
		}
		$teacher = C::t("#zhanmishu_video#zhanmishu_teacher_info")->fetch($uid);
		$teacher['teacher_name'] = dstripslashes($teacher['teacher_name']);
		$teacher['teacher_img'] = $teacher['teacher_img'] ? $this->auto_to_url($teacher['teacher_img']) : '';
		$teacher['teacher_intro'] = self::contentFormat($teacher['teacher_intro'], 'DECODE');
		$teacher['teacher_content'] = self::contentFormat($teacher['teacher_content'], 'DECODE');

		if (!$teacher['teacher_name']) {
			$user = getuserbyuid($uid);
			$teacher['teacher_name'] = $user['username'];
		}

        $teacher['isfollow'] = 0;
        if ($teacher['uid'] != $_G['uid']) {
            $flag = C::t('home_follow')->fetch_status_by_uid_followuid($_G['uid'], $teacher['uid']);
            if (!empty($flag)) {
                $teacher['isfollow'] = 1;
            }
        }
		// 获取教师个人信息
		$count = C::t("common_member_count")->fetch($uid);
		$teacher['follower'] = $count['follower'];
		$teacher['following'] = $count['following'];

		if ($isCourseInfo) {
			$field = array();
			$field['uid'] = $teacher['uid'];
			$field['isdel'] = '0';
			$course = $this->get_type_course(0, 20, '','',$field);
			$teacher['course'] = $course;
		}

		if ($isUpdateCourseInfo || !$teacher['course_num']) {
			$field = array();
			$field['uid'] = $teacher['uid'];
			$field['isdel'] = '0';
			$course_num = $this->get_type_course_num($field);
			$videos_num = $this->get_type_video_num($field);

			if ($teacher['course_num'] != $course_num || $teacher['videos_num'] != $videos_num) {
				$newTeacher = array();
				$newTeacher['course_num'] = $course_num;
				$newTeacher['videos_num'] = $videos_num;

				C::t("#zhanmishu_video#zhanmishu_teacher_info")->update($teacher['uid'],$newTeacher);
			}

		}

		return $teacher;	
	}
	public function get_type_course_filter_format($start = 0,$perpage = '20',$sort ='',$field= array()){
		$list = $this->get_type_course($start,$perpage,$sort,'',$field);
		return $this->course_list_filter_format($list);
	}
	public function thumbImage(){
		require_once('source/class/class_image.php');
        //随机名称
        $thumb = new image;
        return $thumb;
	}

	public function getImageThumb($imagePath = '', $width='', $height= '', $isbili = false){
		if (!$imagePath || !is_file(DISCUZ_ROOT.$imagePath)) {
			return false;
		}
		// 只裁剪jpg、png图
		if (!in_array(strtolower(fileext($imagePath)), array('jpg','png'))) {
			return $imagePath;
		}
		
		$thumb = self::thumbImage();
        $attachurl = getglobal('setting/attachurl');
        $thumbFile = str_replace($attachurl, '', $imagePath.'_thumb_'.$width.'_'.$height.'.jpg');

        if (is_file(DISCUZ_ROOT.$attachurl.$thumbFile)) {
        	return $attachurl.$thumbFile;
        }
		// $rs = $thumb->Thumb($imagePath, $thumbFile, $width, $height,true);
		if ($rs) {
			return $attachurl.$thumbFile;
		}

		return $imagePath;
	}

	public function course_list_filter_format(& $list = array()){
		$list_column = array('cat_id','cid','course_content','course_group','course_img','course_intro','course_length','course_name','course_price','course_thumbimg','course_type','course_weight','dateline','diff','isdel','issell','learns','progress','replies','selltimes','uid','username','videos','views','cat_name','tags','islive', 'course_price_type');
		

		$sample_cat_list =  $this->cat_tree_to_sample();
		foreach ($list as $key => $value) {
			if ($value['uid']) {
				$user = getuserbyuid($value['uid']);
				$list[$key]['username'] = $user['username'];
			}
			$list[$key]['tags'] = $this->get_course_tags_bycid($value['cid']);
			$list[$key]['cat_name'] = $sample_cat_list[$value['cat_id']];
			if ($list[$key]['course_img']) {
				$list[$key]['course_img'] = self::getImageThumb($list[$key]['course_img'], 375, 150 ,true);
			}else{
				$list[$key]['course_img'] = 'source/plugin/zhanmishu_video/template/img/noimg.jpg';
			}

			
			$list[$key]['course_img'] = $this->auto_to_url($list[$key]['course_img']);

			foreach ($value as $k => $value) {
				if (!in_array($k,$list_column)) {
					unset($list[$key][$k]);
				}
			}
		}
		
		return $list;
	}

	public function check() {
	}

	/**
	 * @Author    Lanya
	 * @DateTime  2019-04-23
	 * @QQ        87883395
	 * @copyright [HereEdu!] (C)2001-2099 hereEdu       Inc
	 * @param     array      $videoList   [description]
	 * @return    [array]                  [description]
	 */
	public function getChapterList(&$videoList, $parent_vid = '0'){
		if (empty($videoList)) {
			return array();
		}
		$chapterList = array();
		$chapterList = $this->multisort($chapterList);

		foreach ($videoList as $key => $value) {
			if ($parent_vid == $value['parent_vid']) {
				$chapterList[$key]  = $value;
				$chapterList[$key]['name']  = $value['video_name'];
				$chapterList[$key]['id']  = $value['vid'];
				unset($videoList[$key]);
				$chapterList[$key]['children'] = $this->getChapterList($videoList,$value['vid']);
				$chapterList[$key]['chindren'] = & $chapterList[$key]['children'];
			}
		}
		
		return array_values($chapterList);
	}

	public function isfavorite($cid = '', $uid = ''){
		$favorite = C::t("home_favorite")->fetch_by_id_idtype($cid, 'cid', $uid);
		if (!empty($favorite)) {
			return 1;
		}
		return 0;
	}

	public function favoriteCourse($uid = '', $cid, $action = 'add') {
		global $_G;
		$uid = $uid ? $uid : $_G['uid'];
		if (!$uid) {
			return array(
				'code'=>'-6001',
				'msg'=>'please_login',
			);
		}
		if (!$cid) {
			return array(
				'code'=>'-6002',
				'msg'=>'cid_is_required',
			);
		}

		$course = $this->get_course_bycid($cid);
		if (empty($course)) {
			return array(
				'code'=>'-6003',
				'msg'=>'course_isnot_exixts',
			);
		}

		$favorite = array();
		$favorite['uid'] = $uid;
		$favorite['id'] = $cid;
		$favorite['idtype'] = 'cid';
		// 检测是否已经关注过
		$oldFavorite = C::t("home_favorite")->fetch_by_id_idtype($cid, 'cid', $uid);
	
		if ($action == 'del') {
			if (empty($oldFavorite)) {
				return array(
				'code'=>'-6005',
				'msg'=>'you_have_not_favorite_this_course',
				);
			}
			$rs = C::t("home_favorite")->delete($oldFavorite['favid']);
			return array(
				'code'=>'1',
				'msg'=>'delete_success'
			);

		}

		if (!empty($oldFavorite)) {
			return array(
				'code'=>'-6005',
				'msg'=>'have_favorited_and_can_not_favorite_again',
			);
		}

		$favorite['spaceuid'] = $uid;
		$favorite['title'] = $course['course_name'];
		$favorite['description'] = $course['course_intro'];
		$favorite['dateline'] = TIMESTAMP;

		$favid = C::t("home_favorite")->insert($favorite,true,false);
		return array(
			'code'=>'1',
			'msg'=>'success',
			'favid'=>$favid,
		);

	}
	public function noticeSetting(){
        $noticeSetting = $this->GetFromCache('noticeSetting');
        if (!empty($noticeSetting)) {
            $noticeSetting['wechatParams'] = self::strToArray($noticeSetting['wechatContent']);
            $noticeSetting['noticeContent'] = dstripslashes($noticeSetting['noticeContent']);
            $noticeSetting['emailContent'] = dstripslashes($noticeSetting['emailContent']);
            return $noticeSetting;
        }
        return array(
            'wechatTemplate' => '',
            'isWechat' => 1,
            'wechatDayLimit' => 1,
            'isNotice' => 1,
            'noticeDayLimit' => 0
        );
    }
}
//From: Dism·taobao·com
?>