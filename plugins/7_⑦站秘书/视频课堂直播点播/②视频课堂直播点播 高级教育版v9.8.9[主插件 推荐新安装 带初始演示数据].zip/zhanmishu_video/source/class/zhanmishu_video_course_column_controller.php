<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
} 


/**
 * 
 */
class zhanmishu_video_course_column_controller extends zhanmishu_video_controller
{
    public function index(){
        global $_G;
        if ($_GET['columnid'] < 1) {
            $return = array('msg'=>'columnid_error','code'=>'-13011');
            self::showMessage($return); 
        }
        $columnid = $_GET['columnid'] + 0;
        $column = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch($columnid);
        if (empty($column) || $column['isdel'] == '1') {
            $return = array('msg'=>lang('plugin/zhanmishu_video','column_isnot_exists_or_deleteed'),'code'=>'-13012');
            self::showMessage($return); 
        }
        $column = $this->_courseColumnFormat($column);
        $column['courseids'] = array_values(array_unique(array_filter($column['courseids'])));
        foreach ($column['courseids'] as $key => $value) {
            $column['courseids'][$key] = intval($value);
        }
        if (!empty($column['courseids'])) {
            $field = array(
                'isdel'=> '0',
                // 'issell'=> '1',
                'cid'=> array(
                        'key'=>'cid',
                        'relation'=>'in',
                        'value'=>'('.implode(',',$column['courseids']).')',
                    )
                );
            $courses = $this->videoHander->get_type_course_filter_format(0,50,'desc', $field);
        }else{
            $courses = array();
        }

        $ispay = $this->videoHander->checkuser_ispay_column($column['columnid'], $_G['uid']) > 0 ? 1 : 0;

        // 更新column信息
        $this->_updateColumnBuyerNumbers($column);

        $column['course_column_content'] = zhanmishu_course::richTextAbsoluteUrl(htmlspecialchars_decode(dstripslashes($column['course_column_content'])), str_replace('/source/plugin/zhanmishu_video','',$_G['siteurl']));

        
        $return = array();
        $return['column'] = $column;
        $return['column']['ispay'] = $ispay;
        $return['column']['courses'] = array_values($courses);
        $this->resultToJsonOutPut($return);

    }

    public function _updateColumnCourseNumbers($column = array()){
        if (!$column['columnid']) {
            return;
        }

    }
    public function _updateColumnBuyerNumbers($column = array()){
        if (!$column['columnid']) {
            return;
        }
        $field = array();
        $field['columnid'] = $column['columnid'];
        $field['ispayed'] = 1;

        $number = C::t("#zhanmishu_video#zhanmishu_video_order")->fetch_num($field);
        $data = array();
        $data['views'] = $column['views'] + 1;
        if ($number != $column['selltimes']) {
            $data['selltimes'] = $number;
            $data['dateline'] = TIMESTAMP;
        }
        C::t("#zhanmishu_video#zhanmishu_video_course_column")->update($column['columnid'], $data);
        return;
    }

    public function _checkUserIsPay($uid = '', $columnid = ''){
        global $_G;
        $uid = $uid ? $uid : $_G['uid'];

        if (!$uid || !$columnid) {
            return 0;
        }

        $field = array();
        $field['uid'] = $uid;
        $field['columnid'] = $columnid;

        $auth = C::t("#zhanmishu_video#zhanmishu_video_autho")->get_one_autho_byfield($field);
        if (empty($auth)) {
            return 0;
        }

        return 1;
    }

    public function buy(){
        global $_G;
        $this->_csfr();
        if (!$_G['uid']) {
            $return = array('msg'=>lang('plugin/zhanmishu_video','please_login'),'code'=>'-10001');
            self::showMessage($return); 
        }else if ($_GET['columnid'] < 1) {
            $return = array('msg'=>lang('plugin/zhanmishu_video','columnid_error'),'code'=>'-13011');
            self::showMessage($return); 
        }
        $columnid = $_GET['columnid'] + 0;
        $column = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch($columnid);
        if (empty($column) || $column['isdel'] == '1') {
            $return = array('msg'=>lang('plugin/zhanmishu_video','column_isnot_exists_or_deleteed'),'code'=>'-13012');
            self::showMessage($return); 
        }

        // 检测是否是购买
        $ispay = $this->videoHander->checkuser_ispay_column($columnid,$_G['uid']);
        if ($ispay > 0) {
            $return = array('msg'=>lang('plugin/zhanmishu_video','have_payed'),'code'=>'-13013');
            self::showMessage($return); 
        }
        // 指定oid进行支付
        $order = array();
        if ($_GET['oid']) {
            $order = C::t("#zhanmishu_video#zhanmishu_video_order")->fetch($_GET['oid']+0);
            if ($order['ispayed'] == '1') {
                $return = array('msg'=>lang('plugin/zhanmishu_video', 'order_is_payed'),'code'=>'-13014');
                self::showMessage($return); 
            }
        }else{
            $out_trade_no = $this->videoHander->get_rand_trade_no();
            $order['uid'] = $column['uid'];
            $order['course_name'] = $column['course_column_name'];
            $order['course_column_name'] = $column['course_column_name'];
            $order['course_column_price'] = $column['course_column_price'];
            $order['course_price'] = $column['course_column_price'];
            $order['total_fee'] = $column['course_column_price'];
            $order['course_column_intro'] = $column['course_column_intro'];
            $order['course_column_img'] = $column['course_column_img'];
            $order['columnid'] = $column['columnid'];
            $order['buyer_uid'] = $_G['uid'];
            $order['out_trade_no'] = $out_trade_no;
            $order['dateline'] = TIMESTAMP;
            C::t("#zhanmishu_video#zhanmishu_video_order")->insert($order,false,true);      
        }

        $data = array();
        $data['out_trade_no'] = $order['out_trade_no'];
        $data['buyer_uid'] = $order['buyer_uid'];
        $data['uid'] = $order['uid'];
        $data['course_column_name'] = $order['course_column_name'];
        $data['course_column_price'] = $order['course_column_price'] / 100;
        $data['course_column_img'] = $order['course_column_img'];
        $data['course_column_intro'] = $order['course_column_intro'];
        $data['columnid'] = $order['columnid'];

        // 生成支付信息
        $return = array();
        $return['code'] = '1';
        $return['msg'] = 'success';
        $return['data'] = $data;
        $zmsPayExists =  $this->videoHander->ZmsIsWepayExists();
        if ($zmsPayExists) {
            include_once DISCUZ_ROOT.'source/plugin/zhanmishu_wepay/source/function/api_function.php';
            $orderInfo = array();
            $orderInfo['out_trade_no'] = $order['out_trade_no'];
            $orderInfo['subject'] = $order['course_column_name'];
            $orderInfo['body'] = $order['course_column_intro'];
            $orderInfo['total_fee'] = $order['course_column_price'] / 100;
            $orderInfo['openId'] = $_GET['openid'];

            if ($_GET['platform'] == 'minapp') {
                $payType = 'wechat_app';
            }else if ($_GET['platform'] == 'app') {
                $payType = 'app';
            }else{
                $payType = '';
                // 修正openid， 如没有openid，从cookie获取
                if (defined('IN_MOBILE') && is_dir(DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat')) {
                    include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat/source/Autoloader.php';
                    $orderInfo['openId'] = $orderInfo['openId'] ? $orderInfo['openId'] : zhanmishu_wechat::base64_urlSafeDecode(getcookie(zhanmishu_wechat::$openidCookie));
                }

            }
            if (!$orderInfo['openId']) {
                if (!is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_wechat/source/class/zhanmishu_wechat_member.php')) {
                    $return = array('msg'=>lang('plugin/zhanmishu_video', 'zhanmishu_wechat_plugin_is_need'),'code'=>'-13015');
                    self::showMessage($return); 
                }
                if (!class_exists('zhanmishu_wechat_member',false)) {
                    C::import('zhanmishu_wechat_member','plugin/zhanmishu_wechat/source/class');
                }
                $orderInfo['openId'] = zhanmishu_wechat_member::get_openid_by_uid($_G['uid'],$_GET['platform']);
            }

            $payInfo = zhanmishu_pay_api($orderInfo,'1',$payType);
            $return['data']['payInfo'] = $payInfo;
        }
        $this->resultToJsonOutPut($return);

    }

    public function checkPay(){
        $out_trade_no = daddslashes($_GET['out_trade_no']);
        $return = $this->videoHander->check_ispay_byout_trade_no($out_trade_no);
        self::showMessage($return);
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description 
     * @DateTime    2019-07-10
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     */
    public function add(){
        $this->_csfr();
        $_GET = zhanmishu_course::auto_charset_change($_GET,'UTF-8',CHARSET);
        $this->_checkIsTeacher();
        global $_G;

        $data = array();
        $data['uid'] = $_G['uid'];
        $data['issell'] = 1;
        $data['course_column_price'] = ceil($_GET['course_column_price'] * 100);
        $data['course_column_name'] = daddslashes($_GET['course_column_name']);
        $data['course_column_img'] = daddslashes($_GET['course_column_img']);
        if (!$_GET['course_column_intro']) {
            $_GET['course_column_intro'] = strip_tags($_GET['course_column_content']);
        }
        if (!$_GET['course_column_intro']) {
            $_GET['course_column_intro'] = $_GET['course_column_name'];
        }

        $data['course_column_intro'] = daddslashes(cutstr($_GET['course_column_intro'], 80));

        $data['course_column_content'] = daddslashes(zhanmishu_course::richTextRelativeUrl($_GET['course_column_content'], $_G['siteurl']));
        
        $data['courseids'] = daddslashes(implode(',', array_filter(explode(',', $_GET['courseids']))));
        if (!$data['course_column_name']) {
            $return = array('msg'=>lang('plugin/zhanmishu_video','course_column_name_error'),'code'=>'-13002');
            self::showMessage($return); 
        }else if (!$data['course_column_img']) {
            $return = array('msg'=>lang('plugin/zhanmishu_video','course_column_img_error'),'code'=>'-13003');
            self::showMessage($return); 
        }else if (!$data['course_column_intro']) {
            $return = array('msg'=>lang('plugin/zhanmishu_video','course_column_intro_error'),'code'=>'-13004');
            self::showMessage($return); 
        }

        if ($_GET['columnid']) {
            $data['columnid'] = $_GET['columnid'] + 0;
            $isreplace = true;
        }else{
            $data['dateline'] = TIMESTAMP;
            $isreplace = false;
        }
        $columnid = C::t("#zhanmishu_video#zhanmishu_video_course_column")->insert($data,true,$isreplace);
        if ($isreplace) {
            $columnid = $data['columnid'];
            // 如果是修改专栏，那么则需要同步修改专栏的授权
        }
        $return = array(
            'columnid'=>$columnid,
            'msg'=>'success',
            'code'=>'1'
        );
        self::showMessage($return);         
    }
    public function deleteColunm(){
        $this->_csfr();
        $this->_checkIsTeacher();
        global $_G;

        $columnid = $_GET['columnid'] + 0;
        $column = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch($columnid);
        if (empty($column)) {
            $return = array('msg'=>lang('plugin/zhanmishu_video','course_column_not_exists'),'code'=>'-13005');
            self::showMessage($return); 
        }else if ($column['uid'] != $_G['uid'] && $_G['groupid'] != 1) {
            $return = array('msg'=>'acl_error','code'=>'-13006');
            self::showMessage($return);
        }

        $data = array();
        $data['isdel'] = '1';
        $data['issell'] = '0';
        C::t("#zhanmishu_video#zhanmishu_video_course_column")->update($columnid,$data);

        $return = array('msg'=>'success','code'=>'1');
        self::showMessage($return);
    }

    public function cloumnList(){
        $field = array();
        $field['isdel'] = '0';
        if ($_GET['uid']) {
            $field['uid'] = $_GET['uid'] + 0;
        }
        $perpage = $_GET['perpage'] ? $_GET['perpage'] + 0 : 10;
        if ($perpage > 100) {
            $perpage = 100;
        }
        $curpage = $_GET['page'] > 0 ? $_GET['page'] + 0 : 1;
        $num = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch_num_by_field($field);
        $pages= ceil($num / $perpage);
        $start = $num - ($num - $perpage*$curpage+$perpage);

        $colunms = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch_by_field($start, $perpage, 'desc', $field);

        foreach ($colunms as $key => $value) {
            $colunms[$key] = $this->_courseColumnFormat($value);
        }

        $return = array();
        $return['list'] = array_values($colunms);
        $return['count'] = $num;
        $return['curpage'] = $curpage;
        $return['pages'] = $pages;
        $return['perpage'] = $perpage;
        $this->resultToJsonOutPut($return);
    }

    public function _courseColumnFormat($column = array()){
        global $_G;
        if (empty($column)) {
            return array();
        }
        $keys = array('columnid','uid','selltimes','courseids','courses','videos','views','views','learns','replies','course_column_name','course_column_img','course_column_intro','course_column_content','course_column_price','course_column_length','dateline');

        $return = array();
        $column['courseids'] = explode(',',$column['courseids']);
        foreach ($column as $key => $value) {
            if (in_array($key, $keys)) {
                $return[$key] = $value;
            }
        }
        $return['course_column_intro'] = htmlspecialchars_decode(dstripslashes($return['course_column_intro']));
        $return['course_column_content'] = htmlspecialchars_decode(dstripslashes($return['course_column_content']));

        if ($_GET['platform'] && $_GET['platform'] != 'h5') {
            $return['course_column_intro'] = zhanmishu_course::richTextAbsoluteUrl($return['course_column_intro'], $_G['siteurl']);
            $return['course_column_content'] = zhanmishu_course::richTextAbsoluteUrl($return['course_column_content'], $_G['siteurl']);
        }
        $return['course_column_img'] = $this->videoHander->auto_to_url($return['course_column_img']);
        
        return $return;
    }

    public function _checkAuth(){
        global $_G;
        if (!$_G['uid']) {
            $return = array('msg'=>lang('plugin/zhanmishu_video','please_login'),'code'=>'-10001');
            self::showMessage($return); 
        }
    }

    public function _checkIsTeacher(){
        global $_G;
        $this->_checkAuth();

        $config = $this->videoHander->config;
        //检查是否是老师
        $extgroups = explode("\t", $_G['member']['extgroupids']);
        $extgroups[] = $_G['groupid'];
        $course_groupin = array_intersect($extgroups, $config['teachergroup']);
        if (empty($course_groupin)) {
            $msg = lang('plugin/zhanmishu_video', 'you_should_be_teacher');
            $outapi = array(
                'msg'=>$msg,
                'code'=>'-10011',
            );
            $this->resultToJsonOutPut($outapi);
        }       
    }
}