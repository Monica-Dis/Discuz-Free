<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
} 


class zhanmishu_video_controller
{
    public $videoHander;
    function __construct(zhanmishu_video $videoHander) {
        $this->videoHander = $videoHander;
    }
    public function _checkFormhash($formhash = ''){
        return $formhash == formhash();
    }
    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description 由于api中，cookie可能丢失无状态，因此根据header中的token防止跨站攻击
     * @DateTime    2019-07-10
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @return      [type]     [验证方法，首先验证formhash，如果有效则直接成功。如果无效，则验证token是否与请求的浏览器参数对应，如一致则OK即可]
     */
    public function _csfr(){
        global $_G;

        // var_dump($_G['uid']);
        // var_dump($_G['config']['security']['authkey']);
        // die;
        //兼容老版本formhash
        if ($_GET['formhash'] == formhash()) {
           return true;
        }else if ($_GET['hash'] == md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])) {
            return true;
        }
        $outapi = array(
            'msg'=>'hash_error',
            'code'=>'-10001',
        );
        self::resultToJsonOutPut($outapi);
    }

    public static function resultToJsonOutPut($data = array(), $msg = '', $code = ''){
        if (!$data['msg'] && $msg) {
            $data['msg'] = $msg;
        }
        if (!$data['code'] && $code) {
            $data['code'] = $code;
        }
        echo zhanmishu_api::resultToJson($data);
        exit;
    }

    /**
     * @Author    Lanya
     * @DateTime  2019-06-20
     * @QQ        87883395
     * @copyright [HereEdu!] (C)2001-2099 hereEdu       Inc
     * @param     mix     $data        [description]
     * @param     string     $url         [description]
     * @return    [type]                  [description]
     */
    public static function showMessage($data = '' , $url='') {
        if (defined('IN_MOBILE_API')) {
           return self::resultToJsonOutPut($data);
        }
        if (is_array($data)) {
            $data = $data['msg'];
        }
        if (defined('IN_ADMINCP')) {
            if ($code > 0) {
                $type = 'success';
            }else{
                $type = 'error';
            }
            cpmsg($data,$url,$type);
        }
        if ($code > 0) {
            $type = 'right';
        }else{
            $type = 'error';
        }
        showmessage($data,$url,array('alert'=>$type));
    }

    public static function submitcheck($var, $allowget = 0, $seccodecheck = 0, $secqaacheck = 0){
        if (defined('IN_MOBILE_API')) {
            if(!getgpc($var)) {
                return FALSE;
            } else {
                global $_G;
                if($allowget || ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_GET['formhash']) && $_GET['formhash'] == formhash() && empty($_SERVER['HTTP_X_FLASH_VERSION']) && (empty($_SERVER['HTTP_REFERER']) ||
                    strncmp($_SERVER['HTTP_REFERER'], 'http://wsq.discuz.com/', 22) === 0 || preg_replace("/https?:\/\/([^\:\/]+).*/i", "\\1", $_SERVER['HTTP_REFERER']) == preg_replace("/([^\:]+).*/", "\\1", $_SERVER['HTTP_HOST']))) || true) {
                    if(checkperm('seccode')) {
                        if($secqaacheck && !check_secqaa($_GET['secanswer'], $_GET['secqaahash'])) {
                            $outapi = array(
                                'msg'=>'submit_secqaa_invalid',
                                'code'=>'-11',
                            );
                            sefl::resultToJsonOutPut($outapi);
                            
                        }
                        if($seccodecheck && !check_seccode($_GET['seccodeverify'],$_GET['seccodehash'], 0, $_GET['seccodemodid'])) {
                            $outapi = array(
                                'msg'=>'submit_seccode_invalid',
                                'code'=>'-12',
                            );
                            sefl::resultToJsonOutPut($outapi);
                        }
                    }
                    return TRUE;
                } else {
                    $outapi = array(
                        'msg'=>'submit_invalid',
                        'code'=>'-13',
                    );
                    sefl::resultToJsonOutPut($outapi);
                }
            }          
        }
        return submitcheck($var, $allowget = 0, $seccodecheck = 0, $secqaacheck = 0);
    }
    
}