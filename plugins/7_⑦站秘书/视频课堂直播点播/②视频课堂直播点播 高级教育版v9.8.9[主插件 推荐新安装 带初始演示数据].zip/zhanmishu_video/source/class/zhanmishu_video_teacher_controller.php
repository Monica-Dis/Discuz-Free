<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
} 


/**
 * 
 */
class zhanmishu_video_teacher_controller extends zhanmishu_video_controller
{
    public function index(){
        
    }

    public function teacherShare(){
        global $_G;
        $vid = $_GET['vid'] + 0;
        $cid = $_GET['cid'] + 0;
        // $this->_checkAuth($cid, $vid);

        if ($this->videoHander->config['isrewrite'] && $vid) {
            $url = zms_video_rewriteoutput('course_videopage',1, '', $cid, $vid);
        }else if ($this->videoHander->config['isrewrite']) {
            $url = zms_video_rewriteoutput('coursepage',1, '', $cid,'');
        }else{
            $url = 'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$cid.'&vid='.$vid;
        }

        if(!$url){
            $return = array('msg'=>'url_error','code'=>'-40050');
            self::showMessage($return); 
        }
        $url = $_G['siteurl'].$url;
        if ($_GET['expire_time'] && strpos($url, '?') !== false) {
            $url = $url.'&expire_time='. (TIMESTAMP + intval($_GET['expire_time']) * 24 * 3600).'&shareToken=';
        }else if ($_GET['expire_time'] && strpos($url, '?') === false) {
            $url = $url.'?expire_time='. (TIMESTAMP + intval($_GET['expire_time']) * 24 * 3600).'&shareToken=';
        }else if (!$_GET['expire_time'] && strpos($url, '?') !== false) {
            $url = $url.'&shareToken=';
        }else if (!$_GET['expire_time'] && strpos($url, '?') === false) {
            $url = $url.'?shareToken=';
        }

        // 播放授权
        $key = md5($_G['config']['security']['authkey'].$url);
        
        $return = array(
            'msg'=>'success',
            'code'=>'1',
            'shareToken' => $key,
            'url' => $url.$key
        );
        self::showMessage($return); 
    }

    /** 
     * 发送推送信息
     * 老师可以推送，关注自己的、或购买自己当前课程的消息
     * 管理员可推送所有用户
     */
    public function sendNotice($cid='', $vid = '', $uid = ''){
        global $_G;
        $cid = $cid ? $cid : $_GET['cid'];
        $vid = $vid ? $vid : $_GET['vid'];
        $uid = $uid ? $uid : $_G['uid'];
        if(!$cid && !$vid){
            return false;
        }

        if ($cid) {
            $course = zhanmishu_video_model_course::fetch($cid);
        }else if($vid){
            $video = zhanmishu_video_model_video::fetch($vid);
            $cid = $video['cid'];
            $course = zhanmishu_video_model_course::fetch($video['cid']);
        }
        if (empty($course)) {
            return false;
        }
        $this->_checkAuth($cid, $vid);

        // order表查询购买信息、 关注表查询关注信息
        $uids = C::t("#zhanmishu_video#zhanmishu_video_order")->fetch_uids($cid);
        // 获取关注用户
        $followUids = C::t("home_follow")->fetch_all_follower_by_uid($course['uid']);

        $uids = array_filter(array_merge(zhanmishu_course::darray_column($uids, 'buyer_uid'), zhanmishu_course::darray_column($followUids, 'uid')));
     
      // 写入队列
        foreach ($uids as $key => $value) {
            // 验证是否推送过
            $data = array();
            $data['inviteuid'] = $uid;
            $data['inviteduid'] = $value;
            $data['isWechat'] = 1;
            $data['isNotice'] = 1;
            $data['cid'] = $cid;
            $data['vid'] = $vid;
            $data['dateline'] = TIMESTAMP;
            $data['isdel'] = 0;

            if ($this->videoHander->config['isrewrite'] && $vid) {
                $url = zms_video_rewriteoutput('course_videopage',1, '', $cid, $vid);
            }else if ($this->videoHander->config['isrewrite']) {
                $url = zms_video_rewriteoutput('coursepage',1, '', $cid,'');
            }else{
                $url = 'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$cid.'&vid='.$vid;
            }
            if (strpos($url, '?') === false) {
                $url = $_G['siteurl'].$url.'?fromuid='.$uid.'&notice=1';
            }else{
                $url = $_G['siteurl'].$url.'&fromuid='.$uid.'&notice=1';
            }


            $params = array();
            $params['title'] = $course['course_name'];
            $invitedUser = getuserbyuid($value);
            $params['invitedUsername'] = $invitedUser['username'];
            $inviteUser = getuserbyuid($uid);
            $params['inviteUsername'] = $inviteUser['username'];
            $params['currentTime'] = dgmdate(TIMESTAMP);
            $params['time'] = $video['dateline'] ? dgmdate($video['dateline']) : dgmdate($course['dateline']) ;
            $params['start_time'] = $video['start_time'] ? dgmdate($video['start_time']) : '';
            $params['url'] = $url;
            $data['params'] = serialize($params);

            zhanmishu_video_model_notice::addSendJob($data);
        }
    }

    // 删除视频
    public function deleteVideo(){
        $vid = $_GET['vid'] + 0 ;
        $this->_checkAuth('',$vid);

        // 逻辑删除
        $field = array();
        $field['isdel'] = '1';

        C::t("#zhanmishu_video#zhanmishu_video")->update($vid,$field);
        $return = array('msg'=>'success','code'=>'1');
        $this->resultToJsonOutPut($return); 
    }
    // 删除课程
    public function deleteCourse(){
        $cid = $_GET['cid'] + 0;
        $this->_checkAuth($cid,'');

        $this->videoHander->delete_k($cid);
        $return = array('msg'=>'success','code'=>'1');
        $this->resultToJsonOutPut($return); 
    }
    public function setLiveStatus(){
        global $_G;
        //检测权限是否正确
        $this->_checkAuth('', $_GET['vid']);
        $v = $this->videoHander->get_video_by_vid($_GET['vid']+0);
        if (empty($v) || ($v['uid'] != $_G['uid']) && $_G['groupid'] != '1') {
            $outapi = array(
                'msg'=>'no_acl',
                'code'=>'-10031',
            );
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }
        $publishStatus = $this->videoHander->auto_publish_live_record($v['vid'], false);
        if ($publishStatus) {
            $outapi = array(
                'msg'=>'success',
                'code'=>'1',
            );
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }else{

            $outapi = array(
                'msg'=>'wait_to_try',
                'code'=>'-10062',
            );
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }
    }

    public function addlive(){
        global $_G;
        //检测权限是否正确
        $v = $this->videoHander->get_video_by_vid($_GET['vid']+0);
        if (empty($v) || $v['uid'] != $_G['uid']) {
            $outapi = array(
                'msg'=>'no_acl',
                'code'=>'-10031',
            );
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }
        $v['start_time_str'] = dgmdate($v['start_time'],'Y-m-d H:i:s');
    }

    public function _checkAuth($cid = '',$vid = ''){
        global $_G;
        if (!$_G['uid']) {
            $return = array('msg'=>'please_login','code'=>'-10001');
            self::showMessage($return); 
        }
        // 如果是管理员  跳过
        if ($_G['groupid'] == 1) {
            return;
        }
        //检测课程是否是自己的
        if ($cid) {
            $course = C::t("#zhanmishu_video#zhanmishu_video_course")->fetch($cid);
            if (empty($course)) {
                $return = array('msg'=>'course_is_not_exists','code'=>'-400030');
                self::showMessage($return); 
            }else if ($course['uid'] != $_G['uid'] && $_G['groupid'] != '1') {
                $return = array('msg'=>'no_acl','code'=>'-40031');
                self::showMessage($return); 
            }
        }
        if ($vid) {
            $video = C::t("#zhanmishu_video#zhanmishu_video")->fetch($vid);
            if (empty($video)) {
                $return = array('msg'=>'video_is_not_exists','code'=>'-40033');
                self::showMessage($return); 
            }else if ($video['uid'] != $_G['uid'] && $_G['groupid'] != '1') {
                $return = array('msg'=>'no_acl','code'=>'-40034');
                self::showMessage($return); 
            }
        }
    }

    // 获取老师所有的课程
    public function course(){
        global $_G;
        $uid = $_GET['uid'] ? $_GET['uid'] + 0 : $_G['uid'];
        $teacher = $this->videoHander->getTeacherInfo($uid);
        $teacher['uid'] = $uid;

        $field = array();
        $field['uid'] = $teacher['uid'];
        $field['isdel'] = '0';
        $num = $this->videoHander->get_type_course_num($field);
        
        
        
        $perpage = 10;
        $curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
        $pages= ceil($num / $perpage);
        $start = $num - ($num - $perpage*$curpage+$perpage);

        $course = $this->videoHander->get_type_course_filter_format($start, $perpage, 'desc',$field);
        $teacher['course'] = array_values($course);

        $this->resultToJsonOutPut($teacher); 
    }
    public function getCourseInfo() {
        global $_G;
        //检测cid是否是改用户的课程
        $course = $this->videoHander->get_course_bycid($_GET['cid'] + 0);
        if($course['course_content']){
            $course['course_content'] = zhanmishu_course::contentFormat($course['course_content'], 'DECODE');
            $course['course_password_content'] = zhanmishu_course::contentFormat($course['course_password_content'], 'DECODE');
            $course['course_notice'] = zhanmishu_course::contentFormat($course['course_notice'], 'DECODE');
        }
        if (empty($course)) {
            $outapi = array();
            $outapi['msg'] = 'course_is_not_exists';
            $outapi['code'] = '-10008';
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }else if ($course['uid'] != $_G['uid'] && $_G['uid'] != '1') {
            $outapi = array(
                'msg'=>'success',
                'code'=>'1',
            );
            $outapi['msg'] = 'course_is_not_of_you';
            $outapi['code'] = '-10009';
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }
        if ($_GET['vid']) {
            $current = $this->videoHander->get_video_by_vid($_GET['vid']+0);
            $course['current'] = $current;
        }

        $outapi = array(
            'msg'=>'success',
            'code'=>'1',
        );
        $outapi['course'] = $course;
        $this->resultToJsonOutPut($outapi);
    }
    public function videolist(){
        global $_G;
        $limit = $_GET['perpage'] ? $_GET['perpage'] + 0 : '20';
        $curpage = $_GET['page'] ? $_GET['page'] : '1';
        $num = $this->videoHander->get_type_video_num(array('cid'=>$_GET['cid'] + 0,'isdel'=>'0'));
        $start = $num - ($num - $limit*$curpage + $limit);
        $videos = $this->videoHander->get_type_video_api_fmt($start,$limit,'desc','',array('cid'=>$_GET['cid'] + 0,'isdel'=>'0'));
        $course = $this->videoHander->get_course_bycid($_GET['cid'] + 0);
        foreach ($videos as $key => $value) {
            $videos[$key]['video_img'] = $videos[$key]['video_img'] ? zhanmishu_api::auto_to_url($videos[$key]['video_img']) : zhanmishu_api::auto_to_url($course['course_img']);
        }
        
        $this->videoHander->update_course_info($course['cid']);

        $course['course_intro'] = zhanmishu_course::contentFormat($course['course_intro'], 'DECODE');
        $course['course_content'] = zhanmishu_course::contentFormat($course['course_content'], 'DECODE');
        $course['course_img'] = zhanmishu_api::auto_to_url($course['course_img']);
        $outapi['code'] = 0;
        $outapi['msg'] = 'success';
        $outapi['count'] = $num;
        $outapi['course'] = $course;
        $outapi['list'] = array_values($videos);
        $outapi['perpage'] = $perpage;
        $outapi['page'] = $curpage;
        echo zhanmishu_api::resultToJson($outapi);
    }
    public function getCourseList() {
        global $_G;
        $limit = $_GET['perpage'] ? $_GET['perpage'] + 0 : '20';
        $curpage = $_GET['page'] ? $_GET['page'] : '1';
        $field=array('isdel'=>'0','uid'=>$_G['uid']);

        $num = $this->videoHander->get_type_course_num($field);
        $start = $num - ($num - $limit*$curpage+$limit);

        $courses = $this->videoHander->get_type_course($start, $limit, 'desc','',$field);

        foreach ($courses as $key => $value) {
            if ($this->videoHander->config['isrewrite']) {
                $courses[$key]['url'] = zms_video_rewriteoutput('coursepage',1,'',$value['cid'],'');
            }else{
                $courses[$key]['url'] = 'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$value['cid'].'&vid='.$value['vid'];
            }

            $courses[$key]['tags'] = $this->videoHander->get_course_tags_bycid($value['cid']);
            $courses[$key]['course_content'] = zhanmishu_course::contentFormat($courses[$key]['course_content'], 'DECODE');
                $courses[$key]['course_intro'] = zhanmishu_course::contentFormat($courses[$key]['course_intro'], 'DECODE');
                $courses[$key]['course_password_content'] = zhanmishu_course::contentFormat($courses[$key]['course_password_content'], 'DECODE');
                $courses[$key]['course_notice'] = zhanmishu_course::contentFormat($courses[$key]['course_notice'], 'DECODE');
            
            $courses[$key]['course_img'] = zhanmishu_api::auto_to_url($value['course_img']);
        }

        $isTeacher = $this->videoHander->checkIsTeacher($_G['uid']);
        $teacherInfo = array();
        if($isTeacher){
            $teacherInfo = $this->videoHander->getTeacherInfo($_G['uid'], false, true, true);
        }

        // 获取实名认证设置信息
        $appHander = zhanmishu_app::getInstance();

        $outapi = array(
            'msg'=>'success',
            'code'=>'1',
        );
        $outapi['count'] = $num;
        $outapi['isTeacher'] = $isTeacher;
        $outapi['verifySetting'] = $appHander->verifySetting();
        $outapi['teacherInfo'] = $teacherInfo;
        $outapi['list'] = array_values($courses);
        $outapi['perpage'] = $limit;
        $outapi['page'] = $curpage;
        $this->resultToJsonOutPut($outapi);
    }
    public function config(){
        global $_G, $zhanmishu_videoconf;
        $cat = $this->videoHander->get_cat_tree();
        $outapi = array(
        );

        // $diffValues = array_values($zhanmishu_videoconf['diff']);
        // $diffKeys = array_keys($zhanmishu_videoconf['diff']);
        $diff = array();
        foreach ($zhanmishu_videoconf['diff'] as $key => $value) {
            $diff[] = array('id'=>$key,'label'=>$value);
        }
        $progress = array();
        foreach ($zhanmishu_videoconf['progress'] as $key => $value) {
            $progress[] = array('id'=>$key,'label'=>$value);
        }  

        $outapi = array(
            'msg'=>'success',
            'code'=>'1',
        );
        loadcache('usergroups');


        $outapi['config']['uid'] = $_G['uid'];
        $outapi['config']['formhash'] = FORMHASH;
        $outapi['config']['diff'] = $diff;
        $outapi['config']['progress'] = $progress;
        $outapi['config']['cat'] = $cat;
        $outapi['config']['usergroups'] = $_G['cache']['usergroups'];
        $this->resultToJsonOutPut($outapi);

    }
    public function add(){
        global $_G;
        $this->_checkAuth();
        if(!$this->videoHander->checkIsTeacher($_G['uid'])){
            $return = array('msg'=>'you_should_be_teacher','code'=>'-10011');
            self::showMessage($return); 
        }

        $_GET = zhanmishu_course::auto_charset_change($_GET,'UTF-8',CHARSET);
        if (submitcheck('course_add_submit',1) || submitcheck('course_live_submit',1) || submitcheck('course_video_submit',1) || submitcheck('course_music_submit',1)) {

            if ($_GET['cid']) {
                $course['cid'] = $_GET['cid'] + 0;
                $course = C::t("#zhanmishu_video#zhanmishu_video_course")->fetch($course['cid']);
            }else{
                $course = array();
            }
            $images = zms_uploadimg();
            $course['course_img'] = daddslashes($images['course_img'] ? $images['course_img'] : ($_GET['course_img'] ? $_GET['course_img'] : $_GET['course_img_old']));
            $course['course_img'] = zhanmishu_course::richTextRelativeUrl($course['course_img'], $_G['siteurl']);

            $course['site_sign_img1'] = daddslashes($images['site_sign_img1'] ? $images['site_sign_img1'] : $_GET['site_sign_img1']);
            $course['site_sign_img2'] = daddslashes($images['site_sign_img2'] ? $images['site_sign_img2'] : $_GET['site_sign_img2']);

            $course['issell'] = $course['issell'] ? $course['issell'] : '0';
            $course['uid'] = $_G['uid'];
            $course['course_type'] = '0';
            $course['course_weight'] = $course['course_weight'] ? $course['course_weight'] : 0;
            $course['dateline'] = $course['dateline'] ? $course['dateline'] : TIMESTAMP;

            $course['course_group'] = zhanmishu_video::settingNumberFormat($_GET['course_group']);
            $course['visiable_group'] = zhanmishu_video::settingNumberFormat($_GET['visiable_group']);
            $course['course_password'] = daddslashes($_GET['course_password']);


            $course['course_name'] = daddslashes($_GET['course_name']);
            $course['course_intro'] = dhtmlspecialchars(cutstr(strip_tags($_GET['course_intro']), 80));
            if (!$course['course_intro']) {
                 $course['course_intro'] = daddslashes(cutstr(strip_tags($_GET['course_content']), 80));
            }
            if (!$course['course_intro']) {
                $course['course_intro'] = $_GET['course_name'];
            }
            $course['course_price_type'] = $_GET['course_price_type'] + 0;
            $course['course_content'] = zhanmishu_course::contentFormat($_GET['course_content'], 'ENCODE');
            $course['course_password_content'] = zhanmishu_course::contentFormat($_GET['course_password_content'], 'ENCODE');
            $course['course_notice'] = zhanmishu_course::contentFormat($_GET['course_notice'], 'ENCODE');

            $course['course_price'] = strval(intval($_GET['course_price'] * 100));
            $course['diff'] = $_GET['diff'] + 0;
            $course['progress'] = $_GET['progress'] + 0;

            if (!$course['course_name'] || !$course['course_intro']) {
                $msg = lang('plugin/zhanmishu_video', 'must_finish_info');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10012',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }
            if ($video_data['video_img'] && !check_IsImage($video_data['video_img'])) {
                $msg = lang('plugin/zhanmishu_video', 'image_error');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10013',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }

            if ($_GET['cat_id']) {
                $course['cat_id'] = $_GET['cat_id'] + 0;
            }
            $isreplace = $course['cid'] ? true : false;

            $course['issell'] = '1';

            $cid = C::t("#zhanmishu_video#zhanmishu_video_course")->insert($course,true,$isreplace);
            if(!$isreplace){
                $course = zhanmishu_video_model_course::fetch($cid);
            }
            // 如果是创建专栏内课程
            if ($cid && $_GET['columnid']) {
                $columnid = $_GET['columnid'] + 0;
                $column = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch($columnid);
                if ($column['uid'] != $_G['uid']) {
                    $msg = lang('plugin/zhanmishu_video', 'acl_error');
                    $outapi = array(
                        'msg'=>$msg,
                        'code'=>'-10013',
                    );
                    echo zhanmishu_api::resultToJson($outapi);
                    exit;
                }
                $column['courseids'] = explode(',', $column['courseids']);
                $column['courseids'][] = $cid;
                $column['courseids'] = implode(',', array_unique($column['courseids']));

                C::t("#zhanmishu_video#zhanmishu_video_course_column")->update($columnid, array('courseids'=>$column['courseids']));
            }

            if (submitcheck('course_live_submit',1) && $cid) {
                $course['cid'] = $cid;
                $video_data['video_img'] = $course['course_img'];
                $video_data['uid'] = $_G['uid'];
                $video_data['video_name'] = $course['course_name'];
                $video_data['video_intro'] = $course['course_intro'];
                $video_data['video_url'] = '';

                if ($this->videoHander->config['live_apis'] == '1') {
                    $video_data['video_urltype'] = '11';
                }else if ($this->videoHander->config['live_apis'] == '2') {
                    $video_data['video_urltype'] = '13';
                }
                $video_data['video_length'] = 0;
                $video_data['isfree'] = $_GET['isfree'] + 0;
                $video_data['video_price'] = $course['course_price'];
                $video_data['dateline'] = TIMESTAMP;
                $video_data['cid'] = $cid;
                $video_data['islive'] = '1';

                $video_data['start_time'] = strtotime($_GET['start_time']);
                $video_data['layout'] = $_GET['layout'] + 0;

                if ($_GET['vid']) {
                    $video_data['vid'] = $_GET['vid'] + 0;
                }

                $isreplace = $video_data['vid'] ? true : false;
                $vid = C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,true,$isreplace);
                $this->videoHander->update_course_info($course['cid'],$course);
            }else if ((submitcheck('course_video_submit',1) || submitcheck('course_music_submit',1)) && $cid) {
                $course['cid'] = $cid;
                $video_data['video_img'] = $_GET['video_img'] ? daddslashes($_GET['video_img']) : $course['course_img'];
                $video_data['uid'] = $_G['uid'];
                $video_data['video_intro'] = $course['course_intro'];

                
                $video_data['video_length'] = 0;
                $video_data['isfree'] = $_GET['isfree'] + 0;
                $video_data['video_price'] = $course['course_price'];
                $video_data['dateline'] = TIMESTAMP;
                $video_data['cid'] = $cid;
                $video_data['islive'] = '0';
                if($_GET['course_video_submit']){
                    $video_data['ismusic'] = '0';
                }else if ($_GET['course_music_submit']){
                    $video_data['ismusic'] = '1';
                }
                 $video_data['video_urltype'] = '10';
                $video_data['start_time'] = strtotime($_GET['start_time']);
                $video_data['layout'] = $_GET['layout'] + 0;

                if ($_GET['vid']) {
                    $video_data['vid'] = $_GET['vid'] + 0;
                }

                $video_names = zhanmishu_course::settingNumberFormat($_GET['video_name'], 'array', false);
                $video_urls = zhanmishu_course::settingNumberFormat($_GET['video_url'], 'array', false);

                foreach ($video_urls as $key => $value) {
                    if(!$value){
                        continue;
                    }
                    if ($this->videoHander->config['OssEncryption']) {
                        $video_data['is_rsa'] = '1';
                    }
                    $video_data['video_url'] = $value;
                    $video_name = $video_names[$key] ? $video_names[$key] : $course['course_name'] .'_'. ($key  +1);

                    $video_data['video_name'] =  $video_name;
                    $vid = C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,true, false);
                }

                
                $this->videoHander->update_course_info($course['cid'],$course);
            }

            if ($_GET['cid']) {
                $msg = lang('plugin/zhanmishu_video','edit_course_success');
            }else{
                $msg = lang('plugin/zhanmishu_video','add_course_success');
            }
            $outapi = array(
                'msg'=>$msg,
                'code'=>'1',
                'cid'=>$cid,
                'vid'=>$vid
            );
            echo zhanmishu_api::resultToJson($outapi);
            exit;   
        }else if (submitcheck('video_add_submit',1)) {

            //检测cid是否是改用户的课程
            $course = $this->videoHander->get_course_bycid($_GET['cid'] + 0);
            if($_GET['vid']){
                $video_data = zhanmishu_video_model_video::fetch($_GET['vid'] + 0);
            }else{
                $video_data = array();
            }
            if ($course['uid'] && $course['uid'] != $_G['uid']) {
                exit('data error');
            }
            
            $images = zms_uploadimg();

            
            $video_data['video_img'] = daddslashes($images['video_img'] ? $images['video_img'] : $_GET['video_img']);
            $video_data['video_img'] = zhanmishu_course::richTextRelativeUrl($video_data['video_img'], $_G['siteurl']);

            $video_data['uid'] = $_G['uid'];
            $video_data['video_name'] = daddslashes($_GET['video_name']);
            $video_data['video_intro'] = daddslashes($_GET['video_intro']);
            if ($video_data['video_url'] != $_GET['video_url'] && $this->videoHander->config['OssEncryption']) {
                $video_data['is_rsa'] = '1';
            }
            $video_data['video_url'] = daddslashes($_GET['video_url']);
            if ($this->videoHander->config['upload_type'] == '1') {
                $video_data['video_urltype'] = '10';
            }else{
                $video_data['video_urltype'] = '1';
            }
            $video_data['video_length'] = $_GET['video_length'] + 0;
            $video_data['isfree'] = $_GET['isfree'] + 0;
            $video_data['video_price'] = strval(intval($_GET['video_price'] * 100));
            $video_data['dateline'] = TIMESTAMP;
            $video_data['cid'] = $_GET['cid'] + 0;

            if (!$video_data['video_name']) {
                $msg = lang('plugin/zhanmishu_video', 'must_finish_videoname');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10021',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }
            if ($_GET['vid']) {
                $video_data['vid'] = $_GET['vid'] + 0;
            }
            if (!$video_data['video_url']) {
                $msg = lang('plugin/zhanmishu_video', 'must_finish_videourl');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10022',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }
            if ($video_data['video_img'] && !check_IsImage($video_data['video_img'])) {
                $msg = lang('plugin/zhanmishu_video', 'image_error');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10023',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }

            $isreplace = $video_data['vid'] ? true : false;

            $vid = C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,true,$isreplace);

            
            if ($video_data['video_url'] && $video_data['ismusic'] == 0 && !$isreplace) {
                $this->videoHander->update_course_info($course['cid'],$course);
                $rid = $this->videoHander->qiniu_transcoding($video_data['video_url']);
                C::t("#zhanmishu_video#zhanmishu_video")->update($vid,array('istranscoding'=>'1','transcodingid'=>$rid));
            }

            $msg = lang('plugin/zhanmishu_video', 'success');
            $outapi = array(
                'msg'=>$msg,
                'code'=>'1',
            );
            echo zhanmishu_api::resultToJson($outapi);
            exit;

        }else if (submitcheck('music_add_submit',1)) {

            //检测cid是否是改用户的课程
            $course = $this->videoHander->get_course_bycid($_GET['cid'] + 0);
            if($_GET['vid']){
                $video_data = zhanmishu_video_model_video::fetch($_GET['vid'] + 0);
            }else{
                $video_data = array();
            }
            if ($course['uid'] && $course['uid'] != $_G['uid']) {
                exit('data error');
            }
            
            $images = zms_uploadimg();
            $video_data['video_img'] = daddslashes($images['video_img'] ? $images['video_img'] : $_GET['video_img']);
            $video_data['video_img'] = zhanmishu_course::richTextRelativeUrl($video_data['video_img'], $_G['siteurl']);

            $video_data['uid'] = $_G['uid'];
            $video_data['video_name'] = daddslashes($_GET['video_name']);
            $video_data['video_intro'] = daddslashes($_GET['video_intro']);
            if ($video_data['video_url'] != $_GET['video_url'] && $this->videoHander->config['OssEncryption']) {
                $video_data['is_rsa'] = '1';
            }
            $video_data['video_url'] = daddslashes($_GET['video_url']);
            $video_data['ismusic'] = '1';
            if ($this->videoHander->config['upload_type'] == '1') {
                $video_data['video_urltype'] = '10';
            }else{
                $video_data['video_urltype'] = '1';
            }
            

            $video_data['video_length'] = $_GET['video_length'] + 0;
            $video_data['isfree'] = $_GET['isfree'] + 0;
            $video_data['video_price'] = strval(intval($_GET['video_price'] * 100));
            $video_data['dateline'] = TIMESTAMP;
            $video_data['cid'] = $_GET['cid'] + 0;

            if (!$video_data['video_name']) {
                $msg = lang('plugin/zhanmishu_video', 'must_finish_videoname');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10021',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }
            if ($_GET['vid']) {
                $video_data['vid'] = $_GET['vid'] + 0;
            }
            if (!$video_data['video_url']) {
                $msg = lang('plugin/zhanmishu_video', 'must_finish_videourl');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10022',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }
            if ($video_data['video_img'] && !check_IsImage($video_data['video_img'])) {
                $msg = lang('plugin/zhanmishu_video', 'image_error');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10023',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }


            $isreplace = $video_data['vid'] ? true : false;

            $vid = C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,true,$isreplace);
            
            if ($video_data['video_url'] && $video_data['ismusic'] == 0 && !$isreplace) {
                $this->videoHander->update_course_info($course['cid'],$course);
                $rid = $this->videoHander->qiniu_transcoding($video_data['video_url']);
                C::t("#zhanmishu_video#zhanmishu_video")->update($vid,array('istranscoding'=>'1','transcodingid'=>$rid));
            }


            $msg = lang('plugin/zhanmishu_video', 'add_video_success');
            $outapi = array(
                'msg'=>$msg,
                'code'=>'1',
            );
            echo zhanmishu_api::resultToJson($outapi);
            exit;

        }else if (submitcheck('live_add_submit',1)) {
            //检测cid是否是改用户的课程
            $course = $this->videoHander->get_course_bycid($_GET['cid'] + 0);

            if ($course['uid'] && $course['uid'] != $_G['uid']) {
                exit('data error');
            }
            $images = zms_uploadimg();
            $video_data = array();
            $video_data['video_img'] = daddslashes($images['video_img'] ? $images['video_img'] : $_GET['video_img']);
            $video_data['video_img'] = zhanmishu_course::richTextRelativeUrl($video_data['video_img'], $_G['siteurl']);

            $video_data['uid'] = $_G['uid'];
            $video_data['video_name'] = daddslashes($_GET['video_name']);
            $video_data['video_intro'] = daddslashes($_GET['video_intro']);
            $video_data['video_url'] = daddslashes($_GET['video_url']);

            if ($this->videoHander->config['live_apis'] == '1') {
                $video_data['video_urltype'] = '11';
            }else if ($this->videoHander->config['live_apis'] == '2') {
                $video_data['video_urltype'] = '13';
            }
            
            $video_data['video_length'] = $_GET['video_length'] + 0;
            $video_data['isfree'] = $_GET['isfree'] + 0;
            $video_data['video_price'] = strval(intval($_GET['video_price'] * 100));
            $video_data['dateline'] = TIMESTAMP;
            $video_data['start_time'] = strtotime($_GET['start_time']);
            $video_data['cid'] = $_GET['cid'] + 0;
            $video_data['islive'] = '1';

            if (!$video_data['video_name']) {
                $msg = lang('plugin/zhanmishu_video', 'must_finish_videoname');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10021',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }
            if ($_GET['vid']) {
                $video_data['vid'] = $_GET['vid'] + 0;
            }
            // if (!$video_data['video_url']) {
            //  $msg = lang('plugin/zhanmishu_video', 'must_finish_videourl');
            //  $outapi = array(
            //      'msg'=>$msg,
            //      'code'=>'-10022',
            //  );
            //  echo zhanmishu_api::resultToJson($outapi);
            //  exit;
            // }
            if ($video_data['video_img'] && !check_IsImage($video_data['video_img'])) {
                $msg = lang('plugin/zhanmishu_video', 'image_error');
                $outapi = array(
                    'msg'=>$msg,
                    'code'=>'-10023',
                );
                echo zhanmishu_api::resultToJson($outapi);
                exit;
            }

            $isreplace = $video_data['vid'] ? true : false;
            $vid = C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,true,$isreplace);

            $this->videoHander->update_course_info($course['cid'],$course);
            $msg = lang('plugin/zhanmishu_video', 'add_live_success');
            $outapi = array(
                'msg'=>$msg,
                'code'=>'1',
            );
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }
    }
    public function editInfo(){
        global $_G;
        $teacher = $this->videoHander->getTeacherInfo($_G['uid'], false, true);
        
        if (submitcheck('teacherInfoEditSubmit',1)) {
            $_GET = zhanmishu_course::auto_charset_change($_GET,'UTF-8',CHARSET);
            $teacherInfo  =  array();
            $images = zms_uploadimg();
            $teacherInfo['uid'] = $_G['uid'];
            if ($_GET['teacher_helper_ids']) {
                $teacherInfo['teacher_helper_ids'] = zhanmishu_course::settingNumberFormat($_GET['teacher_helper_ids'], 'string');
            }else{
                $teacherInfo['teacher_helper_ids'] = '';
            }
            $teacherInfo['teacher_img'] = daddslashes($images['teacher_img'] ? $images['teacher_img'] : $_GET['teacher_img']);

            $teacherInfo['teacher_name'] = daddslashes($this->videoHander->name_filter($_GET['teacher_name']));

            $teacherInfo['teacher_intro'] =strip_tags(trim($_GET['teacher_intro']));
            $teacherInfo['teacher_content'] = zhanmishu_course::contentFormat($_GET['teacher_content'], 'ENCODE');

            C::t("#zhanmishu_video#zhanmishu_teacher_info")->insert($teacherInfo,false,true);
            
            $teacher = $this->videoHander->getTeacherInfo($_G['uid']);

        }
        $isTeacher = $this->videoHander->checkIsTeacher($_G['uid']);

        // 教师用户的认证信息
        $appHander = zhanmishu_app::getInstance();
        $teacher['verifySetting'] = $appHander->verifySetting();
        if ($_G['uid']) {
            $teacher['verify'] = $appHander->userVerify();
        }
        // 配置
        $teacher['verifySetting']['teacherVerifyStep'] = $this->videoHander->config['teacherVerifyStep'];
        $teacher['isTeacher'] = $isTeacher;

        $this->resultToJsonOutPut($teacher); 
    }
    public function setSellStatus(){
        global $_G;
        //检测cid是否是改用户的课程
        $course = $this->videoHander->get_course_bycid($_GET['cid'] + 0);
        if (empty($course)) {
            $outapi = array(
                'msg'=>'success',
                'code'=>'1',
            );
            $outapi['result']['msg'] = 'course_is_not_exists';
            $outapi['result']['code'] = '-10008';
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }else if ($course['uid'] != $_G['uid'] && $_G['uid'] != '1') {
            $outapi = array(
                'msg'=>'success',
                'code'=>'1',
            );
            $outapi['result']['msg'] = 'course_is_not_of_you';
            $outapi['result']['code'] = '-10009';
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }else if ($course['issell'] ==  $_GET['issell']) {
            $outapi = array(
                'msg'=>'success',
                'code'=>'1',
            );
            $outapi['result']['msg'] = 'course_issell_is_not_change';
            $outapi['result']['code'] = '-10051';
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }
        if ($_GET['formhash'] != formhash()) {
            $outapi = array(
                'msg'=>'formhash_error',
                'code'=>'-9990',
            );
            echo zhanmishu_api::resultToJson($outapi);
            exit;
        }

        C::t("#zhanmishu_video#zhanmishu_video_course")->update($course['cid'],array('issell'=>$_GET['issell'] + 0));

        $outapi = array(
            'msg'=>'success',
            'code'=>'1',
        );
        echo zhanmishu_api::resultToJson($outapi);
        exit;
    }
    public function order(){
       $orders = $this->_order(true);
       $this->resultToJsonOutPut($orders); 
    }
    public function _order($isReturnOrder = false){
        global $_G, $navtitle, $metakeywords, $metadescription;
        $this->_checkAuth();
        $field = array();
        $field['uid'] = $_G['uid'];

        if ($_GET['buy_username']) {
            loaducenter();
            if($data = uc_get_user(daddslashes($_GET['buy_username']))) {
                list($uid, $username, $email) = $data;
                $field['buyer_uid'] = $uid;
            }
        }
        if ($_GET['buyer_mobile']) {
            $field['buyer_mobile'] = daddslashes($_GET['buyer_mobile']);
        }
        if ($_GET['out_trade_no']) {
            $field['out_trade_no'] = daddslashes($_GET['out_trade_no']);
        }
        if ($_GET['type']) {
            $field['type'] = daddslashes($_GET['pay_type']);
        }
        if ($_GET['ispayed']) {
            $field['ispayed'] = daddslashes($_GET['ispayed']);
        }

        if ($_GET['course_name']) {
            $field['course_name'] = array(
                'key'=>'course_name',
                'relation'=>'like',
                'value'=>daddslashes($_GET['course_name'])
            );
        }
        if ($_GET['start_time']) {
            $field['dateline'] = array(
                'key'=>'dateline',
                'relation'=>'>=',
                'value'=>daddslashes($_GET['start_time'])
            );
        }
        if ($_GET['end_time']) {
            $field['dateline'] = array(
                'key'=>'dateline',
                'relation'=>'<=',
                'value'=>daddslashes($_GET['end_time'])
            );
        }
        $limit = $_GET['perpage'] ? $_GET['perpage'] + 0 : '5';
        $curpage = $_GET['page'] ? $_GET['page'] : '1';
        $num = $this->videoHander->get_orders_num($field);
        $start = $num - ($num - $limit*$curpage+$limit);
        $orders = $this->videoHander->get_type_order($start,$limit,'desc','',$field);
        $pages = ceil($num / $limit);
        foreach ($orders as $key => $value) {
            if ($value['buyer_uid']) {
                $user = getuserbyuid($value['buyer_uid']);
                $orders[$key]['buy_username'] = $user['username'];
            }
            $orders[$key]['pay_status'] = $value['ispayed'];
            $orders[$key]['dateline_fmt'] = $value['dateline'] ? dgmdate($value['dateline']) : '-';
            $orders[$key]['pay_time_fmt'] = $value['pay_time'] ? dgmdate($value['pay_time']) : '-';
        }
        if ($isReturnOrder) {
            $return = array();
            $return['perpage'] = $limit;
            $return['orders'] = $orders;
            $return['pages'] = $pages;
            $return['curpage'] = $curpage;
            $return['order_count'] = $num;
            return $return;
        }
        include template('zhanmishu_video:teacher/order');
        exit;
    }
    public function _sumIncome($uid = '',$field = array()){
        global $_G;
        $uid = $uid ? $uid : $_G['uid'];

        $field['uid'] = $uid;
        $field['ispayed'] = '1';
        $field['isselled'] = '1';

        $sum = C::t("#zhanmishu_video#zhanmishu_video_order")->sum($field);
        $teacher_per = $this->videoHander->config['teacher_per'];
        return $sum['sum'] * $teacher_per / 100;
    }

    public function _income(){
        global $_G, $navtitle, $metakeywords, $metadescription;
        $this->_checkAuth();

        $paytype_extcredits = $this->videoHander->config['paytype_extcredits'];
        $moneyper = $this->videoHander->config['moneyper'];
        
        $credits = C::t("common_member_count")->fetch($_G['uid']);
        $credit  = $credits['extcredits'.$paytype_extcredits];

        // 可提现金额 积分之前已经分成过，直接转换为人民币即可
        $nowIncome = $credit / $moneyper;
        // 总收入
        $allIncome = $this->_sumIncome();

        //最近一周的收入
        $recentIncome = $this->_recentIncome();
        // 今天的收入
        $todayIncome = current($recentIncome);
        $recentIncomeKey = json_encode(array_keys($recentIncome));
        $recentIncomeValue = json_encode(array_values($recentIncome));
        $avatar =  avatar($_G['uid'],'small',true);
        include template('zhanmishu_video:teacher/income');
        exit;
    }

    public function _recentIncome(){
        global $_G;
        // 最近一周收入
        // 今天
        $timetoday = strtotime(date("Y-m-d",TIMESTAMP));
        $field = array();
        $field[] = array(
            'key'=>'pay_time',
            'value'=>$timetoday,
            'relation'=>'>='
        );
        $todayIncome = $this->_sumIncome($_G['uid'],$field);
        $return = array();
        $return[date('m-d',$timetoday)] = $todayIncome;

        for ($i=0; $i < 6; $i++) {
            $timeMax = $timetoday - 3600*24*$i;
            $timeMin = $timetoday - 3600*24*($i+1);

            $field = array();
            $field[] = array(
                'key'=>'pay_time',
                'value'=>$timeMin,
                'relation'=>'>='
            );
            $field[] = array(
                'key'=>'pay_time',
                'value'=>$timeMax,
                'relation'=>'<'
            );
            $thisDayIncome = $this->_sumIncome($_G['uid'],$field);
            $return[date('m-d',$timeMin)] = $thisDayIncome;          
        }
        return $return;

    }
    public function upload(){
        $path = $_GET['path'] ? $_GET['path'] : 'zhanmishu_video';
        $images = zms_uploadimg($path);

        $outapi = array();
        $outapi['msg'] = 'success';
        $outapi['code'] = '0';
        $outapi['files'] = $images;
        $this->resultToJsonOutPut($outapi);
    }
    public function remoteUploadToken(){
        $tokeninfo = $this->videoHander->get_token();

        if ($this->videoHander->config['upload_type'] == '1') {
            $host = $this->videoHander->config['oss_upload_url'];
            $tokeninfo = $this->videoHander->get_token();
        }

        $outapi = array(
            'msg'=>'success',
            'code'=>'1',
        );
        $outapi['msg'] = 'success';
        $outapi['code'] = '0';
        $outapi['host'] = $host;
        $outapi['tokeninfo'] = $tokeninfo;
        $this->resultToJsonOutPut($outapi);
    }
    public function _students(){
        global $_G;
        $this->_checkAuth();

        include template('zhanmishu_video:teacher/students');
        exit;
    }

    public function _index(){
        global $_G, $navtitle, $metakeywords, $metadescription;
        if (defined("IN_MOBILE") && !is_dir(DISCUZ_ROOT.'source/plugin/zhanmishu_app')) {
            showmessage(lang('plugin/zhanmishu_video','buy_new_app'),'https://dism.taobao.com/?@zhanmishu_app.plugin');
        }else if (defined("IN_MOBILE")) {
            include template('zhanmishu_video:indexNew');
            exit;
        }
        include template('zhanmishu_video:teacher/teacher_index');
    }  
}