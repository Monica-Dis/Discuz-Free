<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *    	应用更新支持：https://dism.taobao.com $
 */	

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if ($_GET['dtype'] && !defined('IN_MOBILE_API')) {
	define('IN_MOBILE_API', true);
}

$video = zhanmishu_video::getInstance();


$videoconfig = $video->config;
$config = &$videoconfig;
if (!defined('IN_MOBILE')) {
	if (isset($_GET['cat_id']) ||
		  isset($_GET['page']) ||
		  isset($_GET['diff']) ||
		  isset($_GET['progress']) || 
		  isset($_GET['order']) || 
		  isset($_GET['search_key']) ||
		  isset($_GET['groupselect'])
		) {
		$mod = 'list';
	}
}

$cat = $video->get_cat_tree();
$sample_cat_list =  $video->cat_tree_to_sample();
$catpid = $_GET['cat_id'] ? $video->get_pidbycat_id($_GET['cat_id'] + 0) : '0';
$catson =  $video->get_cat_tree($catpid ? $catpid : $_GET['cat_id'] + 0);

if ($mod == 'index' || $mod == 'list') {
	$rewrite_cat = $_GET['cat_id'] ? $_GET['cat_id'] : '0';
	$rewrite_vip = $_GET['groupselect'] ? $_GET['groupselect'] : '0';
	$rewrite_diff = $_GET['diff'] ? $_GET['diff'] : '0';
	$rewrite_order = $_GET['order'] ? $_GET['order'] : '0';
}

$videoBaseUrl = 'plugin.php?id=zhanmishu_video:video';
$pdata = $_GET;
unset($pdata['page']);
$mpurl = 'plugin.php?'.urldecode(http_build_query($pdata));
$cdata = $_GET;
unset($cdata['cat_id']);
unset($cdata['page']);

$caturl = 'plugin.php?'.urldecode(http_build_query($cdata));
$ddata = $_GET;
unset($ddata['diff']);
$durl = 'plugin.php?'.urldecode(http_build_query($ddata));
$odata = $_GET;
unset($odata['order']);
$ourl = 'plugin.php?'.urldecode(http_build_query($odata));
$gdata = $_GET;
unset($gdata['groupselect']);
unset($gdata['page']);
$gurl = 'plugin.php?'.urldecode(http_build_query($gdata));


$field = array();
$field['isdel'] = '0';
$field['issell'] = '1';

$field['videos'] = array(
	'key'=>'videos',
	'value'=>0,
	'relation'=>'>'
);

if ($_GET['search_key']) {
	if (defined('IN_MOBILE_API')) {
		$_GET['search_key'] = zhanmishu_course::auto_charset_change($_GET['search_key'],'UTF-8',CHARSET);
	}
	$field['course_name'] = array(
		'key'=>'course_name',
		'value'=>'%'.daddslashes($_GET['search_key']).'%',
		'relation'=>'like'
	);
}

// 是否可见属性进行筛选，管理员不限制
if($_G['groupid'] != '1'){
	// 获取用户的扩展用户组
	$extgroups = explode("\t", $_G['member']['extgroupids']);
	// 用户主用户组混入扩展用户组
	$extgroups[] = $_G['groupid'];

	$tempSql = array();
	$tempSql[] = ' visiable_group = \'\'';
	if ($_G['uid'] > 0) {
		foreach ($extgroups as $key => $value) {
			$tempSql[] = ' CONCAT(\',\',visiable_group,\',\') LIKE \'%,'.$value.',%\' ';
		}
	}
	
	$tempSql = implode(' or ', $tempSql);
	$field['visiable_group'] = array(
		'key'=>'visiable_group',
		'sql'=>' ( '.$tempSql.' ) ',
		'relation'=>'sql'
	);

}


if ($_GET['cat_id']) {
	$this_cat_son = $video->get_cat_tree($_GET['cat_id'] + 0);
	if (empty($this_cat_son['son'])) {
		$field['cat_id'] = $_GET['cat_id'] + 0;
	}else{
		$cat_ids = array();
		$cat_ids[$_GET['cat_id'] + 0] = $_GET['cat_id'] + 0;
		foreach ($this_cat_son['son'] as $key => $value) {
			$cat_ids[$value['cat_id']] = $value['cat_id'];
		}
		$ids .= ' ('.implode(',', $cat_ids).') ';

		$field['cat_id'] = array('key'=>'cat_id','relation'=>'in', 'value'=> $ids);
	}
	
	$catinfo = $video->get_cat_by_cat_id($_GET['cat_id'] + 0);
}
if ($_GET['diff']) {
	$field['diff'] = $_GET['diff'] + 0;
}
if ($_GET['groupselect']) {
    $field['course_group'] = array(
        'relation'=> 'sql',
        'sql'=> 'CONCAT(\',\',course_group,\',\') LIKE \'%'.daddslashes($_GET['groupselect']).'%\''
    );
}

$num = $video->get_type_course_num($field); 

if ($videoconfig['clumnnums'] == 3) {
	$perpage = 12;
}else if ($videoconfig['clumnnums'] == 4){
	$perpage = 16;
}else if ($videoconfig['clumnnums'] == 5){
	$perpage = 20;
}
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
$pages= ceil($num / $perpage);
$start = $num - ($num - $perpage*$curpage+$perpage);


if ($_GET['order'] == 'new') {
	$sort = array('dateline'=>'desc');
}else if($_GET['order'] == 'hot'){
	$sort = array('views'=>'desc');
}else if($_GET['order'] == 'low_price'){
	$sort = array('course_price'=>'asc');
}else if($_GET['order'] == 'views'){
	$sort = array('views'=>'desc');
}else if($_GET['order'] == 'high_price'){
	$sort = array('course_price'=>'desc');
}else if($_GET['order'] == 'learns'){
	$sort = array('learns'=>'desc');
}else if($_GET['order'] == 'replies'){
	$sort = array('replies'=>'desc');
}else {
	$sort = array('course_weight'=>'desc','cid'=>'desc');
}


$list = $video->get_type_course($start,$perpage,$sort,'',$field);

foreach ($list as $key => $value) {
	if ($value['uid']) {
		$user = getuserbyuid($value['uid']);
		$list[$key]['username'] = $user['username'];
	}
	$list[$key]['tags'] = $video->get_course_tags_bycid($value['cid']);
	$list[$key]['cat_name'] = $sample_cat_list[$value['cat_id']];
	$list[$key]['course_img'] = $list[$key]['course_img'] ? $list[$key]['course_img'] : 'source/plugin/zhanmishu_video/template/img/noimg.jpg';
}

if (defined('IN_MOBILE_API')) {
	$liveList = array();
}else{
	$liveList = $video->get_videos_group_by_cid(0,5,array('start_time'=>'desc'),array('isdel'=>'0','islive'=>'1'));
}

$navList = $video->get_nav_list();
foreach ($liveList as $key => $value) {
	$liveList[$key]['video_url'] = '';

	$liveCourse = $video->get_course_bycid($value['cid']);
	$liveList[$key] = array_merge($liveCourse,$value);
	$liveList[$key]['tags'] = $video->get_course_tags_bycid($value['cid']);
}

if (defined('IN_MOBILE_API')) {
	$cate = array_chunk($video->get_cat_by_level('1',array('cat_touchorder'=>'asc')),8);
	$swiper = $video-> get_app_swiper();
	$best = $video->get_app_best();
}elseif (defined('IN_MOBILE')) {
	$cate = array_chunk($video->get_cat_by_level('1',array('cat_touchorder'=>'asc')),8);
	$swiper = $video-> get_touch_swiper();
	$best = $video->get_touch_best();
}else{
	$swiper = $video-> get_pc_swiper();
	$best = $video->get_pc_best();
	$multi = multi($num, $perpage, $curpage, $mpurl, '0');
}
$groupicons = $video->get_group_icons();

$navtitle = $catinfo['cat_name'] ? $catinfo['cat_name'].' - '.$videoconfig['index_title'] : $videoconfig['index_title'];
$metakeywords = $catinfo['cat_name'] ? $catinfo['cat_name'].','.$videoconfig['metakeywords']:$videoconfig['metakeywords'];
$metadescription = $catinfo['cat_name'] ? $catinfo['cat_name'].','.$videoconfig['metadescription']:$videoconfig['metadescription'];

if ($_GET['dtype']) {
	$list_column = array('cat_id','cid','course_content','course_group','course_img','course_intro','course_length','course_name','course_price','course_thumbimg','course_type','course_weight','dateline','diff','isdel','issell','learns
','progress','replies','selltimes','uid','username','views','cat_name','tags');

foreach ($list as $key => $value) {
	foreach ($value as $k => $value) {
		if (!in_array($k,$list_column)) {
			unset($list[$key][$k]);
		}
	}
}
	$outapi = array(
		'msg'=>'success',
		'code'=>'0',
		'data'=>array(),
	);
	$outapi['data']['meta']['description'] = $metadescription;
	$outapi['data']['meta']['title'] = $navtitle;
	$outapi['data']['meta']['keywords'] = $metakeywords;
	$outapi['data']['cat'] = $cat;

	if ($_GET['filter'] == 'list') {
		$outapi['data']['list']['data'] = array_values($list);
		$outapi['data']['list']['count'] = $num;
	}else{
		$outapi['data']['swiper'] = $swiper;
		$outapi['data']['best'] = $best;
		$outapi['data']['list']['data'] = array_values($list);
		$outapi['data']['live']['data'] = array_values($liveList);
		$outapi['data']['navList']['data'] = array_values($navList);
		$outapi['data']['list']['count'] = $num;
		$outapi['data']['catinfo'] = $catinfo;
		$outapi['data']['groupicons'] = $groupicons;
	}
	echo json_encode($video->auto_to_utf8($outapi));
	exit;
}else{
	foreach ($list as $key => $value) {
		if ($value['islive']) {
			$list[$key]['tags'] = $video->get_course_tags_bycid($value['cid']);
		}
	}
}

if ($videoconfig['isH5Spa'] && defined('IN_MOBILE')) {

	$navtitle = $video->auto_charset_change($navtitle);
	$metakeywords = $video->auto_charset_change($metakeywords);
	$metadescription = $video->auto_charset_change($metadescription);
	if (strtolower(CHARSET) != 'utf-8') {
		ob_clean();
	    dheader('Content-type:text/html;charset=utf-8');
	}
	if (is_dir(DISCUZ_ROOT.'source/plugin/zhanmishu_app')) {
		if (!class_exists('zhanmishu_app',false)) {
			include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_app/source/Autoloader.php';
		}
		$appHander = zhanmishu_app::getInstance();
		$userController = new zhanmishu_app_user_controller($appHander);
		$userInfo = $userController->_userInfo('', true);
	}
	
	include template('zhanmishu_video:indexNew');
	exit;
	
}else if (defined('IN_MOBILE')) {

	if (defined('IN_MOBILE') && is_dir(DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat')) {
		include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat/source/Autoloader.php';

		$wechatMemberHander = zhanmishu_wechat_member::getInstance();

		if($wechatMemberHander->is_weixin()){
			$http = $_G['isHTTPS'] ? 'https://' : 'http://';
			$current_url = $http.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$JsParams = $wechatMemberHander->wechatHander()->getJsSign($current_url);
		}
		
	}

	include template('zhanmishu_video:'.$mod);
}else{
	include template("diy:".$mod,0,'source/plugin/zhanmishu_video/template/');
}


?>