<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *    	应用更新支持：https://dism.taobao.com $
 */	

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$video = zhanmishu_video::getInstance();
$config = $video->config;
if (!$_G['uid']) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}


$act = $_GET['act'] ? $_GET['act'] : 'list';

$tokeninfo = $video->get_token();


//检查是否是老师
$extgroups = explode("\t", $_G['member']['extgroupids']);
$extgroups[] = $_G['groupid'];
$course_groupin = array_intersect($extgroups, $config['teachergroup']);
if (empty($course_groupin)) {
	showmessage(lang('plugin/zhanmishu_video','you_should_be_teacher'), '', array(), array('showmsg' => true));
}

dheader('X-XSS-Protection: 0');
if ($act == 'add') {
	
	if (submitcheck('course_add_submit')) {

		if ($_GET['cid']) {
			$course['cid'] = $_GET['cid'] + 0;
			$course = C::t("#zhanmishu_video#zhanmishu_video_course")->fetch($course['cid']);
		}else{
			$course = array();
		}
		$images = zms_uploadimg();
		$course['course_img'] = daddslashes($images['course_img'] ? $images['course_img'] : $_GET['course_img_old']);
		$course['site_sign_img1'] = daddslashes($images['site_sign_img1'] ? $images['site_sign_img1'] : $_GET['site_sign_img1']);
		$course['site_sign_img2'] = daddslashes($images['site_sign_img2'] ? $images['site_sign_img2'] : $_GET['site_sign_img2']);

		$course['issell'] = $course['issell'] ? $course['issell'] : '1';
		$course['uid'] = $_G['uid'];
		$course['course_type'] = '0';
		$course['course_weight'] = $course['course_weight'] ? $course['course_weight'] : 0;
		$course['dateline'] = $course['dateline'] ? $course['dateline'] : TIMESTAMP;

		$course['course_name'] = daddslashes($_GET['course_name']);
		$course['course_intro'] = $_GET['course_intro'];
		$course['course_content'] = daddslashes($_GET['course_content']);
		$course['course_price'] = strval(intval($_GET['course_price'] * 100));
		$course['diff'] = $_GET['diff'] + 0;
		$course['progress'] = $_GET['progress'] + 0;

		if (!$course['course_name'] || !$course['course_intro']) {
			showmessage(lang('plugin/zhanmishu_video', 'must_finish_info'),'','error');
		}
		if ($video_data['video_img'] && !check_IsImage($video_data['video_img'])) {
			showmessage(lang('plugin/zhanmishu_video', 'image_error'),'',array('alert'=>'error'));
		}

		if ($_GET['cat_id']) {
			$course['cat_id'] = $_GET['cat_id'] + 0;
		}
		$isreplace = $course['cid'] ? true : false;

		$cid = C::t("#zhanmishu_video#zhanmishu_video_course")->insert($course,true,$isreplace);

		if ($_GET['cid']) {
			showmessage(lang('plugin/zhanmishu_video','add_course_success'),'plugin.php?id=zhanmishu_video:video&mod=teacher',array('alert'=>'right'));
		}else{
			showmessage(lang('plugin/zhanmishu_video','add_course_success'),'plugin.php?id=zhanmishu_video:video&mod=teacher&act=videolist&cid='.$cid,array('alert'=>'right'));
		}
		
	}else if (submitcheck('video_add_submit')) {

		//检测cid是否是改用户的课程
		$course = $video->get_course_bycid($_GET['cid'] + 0);
		if ($course['uid'] && $course['uid'] !== $_G['uid']) {
			exit('data error');
		}
		$images = zms_uploadimg();

		$video_data = array();
		$video_data['video_img'] = daddslashes($images['video_img'] ? $images['video_img'] : $_GET['video_img']);
		$video_data['uid'] = $_G['uid'];
		$video_data['video_name'] = daddslashes($_GET['video_name']);
		$video_data['video_intro'] = daddslashes($_GET['video_intro']);
		$video_data['video_url'] = daddslashes($_GET['video_url']);
		if ($config['upload_type'] == '1') {
			$video_data['video_urltype'] = '10';
		}else{
			$video_data['video_urltype'] = '1';
		}
		
		$video_data['video_length'] = $_GET['video_length'] + 0;
		$video_data['isfree'] = $_GET['isfree'] + 0;
		$video_data['video_price'] = strval(intval($_GET['video_price'] * 100));
		$video_data['dateline'] = TIMESTAMP;
		$video_data['cid'] = $_GET['cid'] + 0;

		if (!$video_data['video_name']) {
			showmessage(lang('plugin/zhanmishu_video', 'must_finish_videoname'),'',array('alert'=>'error'));
		}
		if ($_GET['vid']) {
			$video_data['vid'] = $_GET['vid'] + 0;
		}
		if (!$video_data['video_url']) {
			showmessage(lang('plugin/zhanmishu_video', 'must_finish_videourl'),'',array('alert'=>'error'));
		}
		if ($video_data['video_img'] && !check_IsImage($video_data['video_img'])) {
			showmessage(lang('plugin/zhanmishu_video', 'image_error'),'',array('alert'=>'error'));
		}
		$isreplace = $video_data['vid'] ? true : false;
		if (!$isreplace && $config['OssEncryption']) {
			$video_data['is_rsa'] = '1';
		}

		$vid = C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,true,$isreplace);

		$video->update_course_info($course['cid'],$course);
		if ($video_data['video_url']) {
			$rid = $video->qiniu_transcoding($video_data['video_url']);
			C::t("#zhanmishu_video#zhanmishu_video")->update($vid,array('istranscoding'=>'1','transcodingid'=>$rid));
		}

		showmessage(lang('plugin/zhanmishu_video', 'add_video_success'),'plugin.php?id=zhanmishu_video:video&mod=teacher&act=videolist&cid='.$_GET['cid'],array('alert'=>'right'));
		exit;

	}else if (submitcheck('music_add_submit')) {

		//检测cid是否是改用户的课程
		$course = $video->get_course_bycid($_GET['cid'] + 0);

		if ($course['uid'] && $course['uid'] !== $_G['uid']) {
			exit('data error');
		}
		

		$images = zms_uploadimg();

		$video_data = array();
		$video_data['video_img'] = daddslashes($images['video_img'] ? $images['video_img'] : $_GET['video_img']);
		$video_data['uid'] = $_G['uid'];
		$video_data['video_name'] = daddslashes($_GET['video_name']);
		$video_data['video_intro'] = daddslashes($_GET['video_intro']);
		$video_data['video_url'] = daddslashes($_GET['video_url']);
		$video_data['ismusic'] = '1';
		if ($config['upload_type'] == '1') {
			$video_data['video_urltype'] = '10';
		}else{
			$video_data['video_urltype'] = '1';
		}
		

		$video_data['video_length'] = $_GET['video_length'] + 0;
		$video_data['isfree'] = $_GET['isfree'] + 0;
		$video_data['video_price'] = strval(intval($_GET['video_price'] * 100));
		$video_data['dateline'] = TIMESTAMP;
		$video_data['cid'] = $_GET['cid'] + 0;

		if (!$video_data['video_name']) {
			showmessage(lang('plugin/zhanmishu_video', 'must_finish_videoname'),'',array('alert'=>'error'));
		}
		if ($_GET['vid']) {
			$video_data['vid'] = $_GET['vid'] + 0;
		}
		if (!$video_data['video_url']) {
			showmessage(lang('plugin/zhanmishu_video', 'must_finish_videourl'),'',array('alert'=>'error'));
		}
		if ($video_data['video_img'] && !check_IsImage($video_data['video_img'])) {
			showmessage(lang('plugin/zhanmishu_video', 'image_error'),'',array('alert'=>'error'));
		}


		$isreplace = $video_data['vid'] ? true : false;
		if (!$isreplace && $config['OssEncryption']) {
			$video_data['is_rsa'] = '1';
		}
		$vid = C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,true,$isreplace);
		$video->update_course_info($course['cid'],$course);
		if ($video_data['video_url']) {
			$rid = $video->qiniu_transcoding($video_data['video_url']);
			C::t("#zhanmishu_video#zhanmishu_video")->update($vid,array('istranscoding'=>'1','transcodingid'=>$rid));
		}


		showmessage(lang('plugin/zhanmishu_video', 'add_video_success'),'plugin.php?id=zhanmishu_video:video&mod=teacher&act=videolist&cid='.$_GET['cid'],array('alert'=>'right'));
		exit;

	}else if (submitcheck('live_add_submit')) {
		//检测cid是否是改用户的课程
		$course = $video->get_course_bycid($_GET['cid'] + 0);
		if ($course['uid'] && $course['uid'] !== $_G['uid']) {
			exit('data error');
		}
		$images = zms_uploadimg();
		$video_data = array();
		$video_data['video_img'] = daddslashes($images['video_img'] ? $images['video_img'] : $_GET['video_img']);
		$video_data['uid'] = $_G['uid'];
		$video_data['video_name'] = daddslashes($_GET['video_name']);
		$video_data['video_intro'] = daddslashes($_GET['video_intro']);
		$video_data['video_url'] = daddslashes($_GET['video_url']);

		if ($config['live_apis'] == '1') {
			$video_data['video_urltype'] = '11';
		}else if ($config['live_apis'] == '2') {
			$video_data['video_urltype'] = '13';
		}
		
		$video_data['video_length'] = $_GET['video_length'] + 0;
		$video_data['isfree'] = $_GET['isfree'] + 0;
		$video_data['video_price'] = strval(intval($_GET['video_price'] * 100));
		$video_data['dateline'] = TIMESTAMP;
		$video_data['start_time'] = strtotime($_GET['start_time']);
		$video_data['cid'] = $_GET['cid'] + 0;
		$video_data['islive'] = '1';

		if (!$video_data['video_name']) {
			showmessage(lang('plugin/zhanmishu_video', 'must_finish_livename'),'',array('alert'=>'error'));
		}
		if ($_GET['vid']) {
			$video_data['vid'] = $_GET['vid'] + 0;
		}
		if ($video_data['video_img'] && !check_IsImage($video_data['video_img'])) {
			showmessage(lang('plugin/zhanmishu_video', 'image_error'),'',array('alert'=>'error'));
		}

		if ($video_data['start_time'] <= TIMESTAMP) {
			showmessage(lang('plugin/zhanmishu_video', 'live_time_error'),'',array('alert'=>'error'));
		}

		$isreplace = $video_data['vid'] ? true : false;
		$vid = C::t("#zhanmishu_video#zhanmishu_video")->insert($video_data,true,$isreplace);

		$video->update_course_info($course['cid'],$course);
		showmessage(lang('plugin/zhanmishu_video', 'add_live_success'),'plugin.php?id=zhanmishu_video:video&mod=teacher&act=videolist&cid='.$_GET['cid'],array('alert'=>'right'));
	}
	if ($_GET['cid']) {
		$course = dstripslashes($video->get_course_bycid($_GET['cid'] + 0,false,false));
		$course['course_price'] = $course['course_price'] / 100;
	}
	$cats = $video->get_cat_select();


}else if ($_GET['act'] == 'editInfo') {

	$teacher = C::t("#zhanmishu_video#zhanmishu_teacher_info")->fetch($_G['uid']);
	$teacher['teacher_name'] = dstripslashes($teacher['teacher_name']);
	$teacher['teacher_intro'] = htmlspecialchars_decode($teacher['teacher_intro']);

	if ($teacher['teacher_helper_ids']) {
		$teacher['teacher_helper_ids'] = substr($teacher['teacher_helper_ids'],1,-1);
	}
	
	if (submitcheck('teacherInfoEditSubmit')) {
		$teacherInfo  =  array();
		$images = zms_uploadimg();
		$teacherInfo['uid'] = $_G['uid'];
		if ($_GET['teacher_helper_ids']) {

			$helper_ids = array_unique(array_filter(explode(',',$_GET['teacher_helper_ids'])));

			foreach ($helper_ids as $key => $value) {
				if ($value && $value == intval($value)) {
					continue;
				}else{
					unset($helper_ids[$key]);
				}
			}

			$teacherInfo['teacher_helper_ids'] = ','.implode(',',$helper_ids).',';
		}else{
			$teacherInfo['teacher_helper_ids'] = '';
		}
		$teacherInfo['teacher_img'] = daddslashes($images['teacher_img'] ? $images['teacher_img'] : $_GET['teacher_img']);

		$teacherInfo['teacher_img'] = $teacherInfo['teacher_img'] ? $teacherInfo['teacher_img'] : $teacher['teacher_img'];

		$teacherInfo['teacher_name'] = daddslashes($video->name_filter($_GET['teacher_name']));
		$teacherInfo['teacher_intro'] = dhtmlspecialchars(strip_tags(trim($_GET['teacher_intro']),'<p><br><span><h1><h2><h3><h4><a><style><ul><ol><li><tr><td><img>'));

		C::t("#zhanmishu_video#zhanmishu_teacher_info")->insert($teacherInfo,false,true);
		
		showmessage(lang('plugin/zhanmishu_video', 'edit_teacher_success'),dreferer(),array('alert'=>'right'));
	}



}else if ($_GET['act'] =='deletevideo' &&  FORMHASH == $_GET['formhash'] && $_GET['vid']) {
	//检测权限是否正确

	$v = $video->get_video_by_vid($_GET['vid']+0);
	if (empty($v) || $v['uid'] !== $_G['uid']) {
		showmessage(lang('plugin/zhanmishu_video', 'autho_error'),dreferer(),array('alert'=>'error'));
	}
	
	$video->delete_video($_GET['vid'] + 0);
	showmessage(lang('plugin/zhanmishu_video', 'delete_video_success'),dreferer(),array('alert'=>'right'));
}else if ($_GET['act'] =='addlive' && $_GET['vid']) {
	//检测权限是否正确
	$v = $video->get_video_by_vid($_GET['vid']+0);
	if (empty($v) || $v['uid'] !== $_G['uid']) {
		showmessage(lang('plugin/zhanmishu_video', 'autho_error'),dreferer(),array('alert'=>'error'));
	}
	$v['start_time_str'] = dgmdate($v['start_time'],'Y-m-d H:i:s');
}else if ($act == 'videolist') {
	$perpage = '50';
	$num = $video->get_type_video_num(array('cid'=>$_GET['cid'] + 0));
	$videoes = $video->get_type_video_fmt($start,$perpage,'desc','',array('cid'=>$_GET['cid'] + 0,'isdel'=>'0'));
	$course = $video->get_course_bycid($_GET['cid'] + 0);
	$video->update_course_info($course['cid']);

}else if ($act == 'uploadImg') {
	$images = zms_uploadimg();
	if (!empty($images)) {
		$return = array();
		$return['errno'] = 0;
		$return['data'] = array_values($images);
		echo json_encode($return);
		exit;
	}
	$return = array();
	$return['errno'] = '1';
	$return['message'] = 'no image upload';
	echo json_encode($return);
	exit;
}else if ($act == 'contract') {
	$field = array();
	$field['uid'] = $_G['uid'];

	$limit = '20';
	$curpage = $_GET['page'] ? $_GET['page'] : '1';
	$num = $video->get_orders_num($field);
	$start = $num - ($num - $limit*$curpage+$limit);
	$orders = $video->get_type_order($start,$limit,'','',$field);

	foreach ($orders as $key => $value) {
		$user = getuserbyuid($value['uid']);
		$orders[$key]['teacher'] = $user['username'];
		$user = getuserbyuid($value['buyer_uid']);
		$orders[$key]['buyer_username'] = $user['username'];
		$orders[$key]['pay_status'] = $value['ispayed'] ? lang('plugin/zhanmishu_video','payed_success') : lang('plugin/zhanmishu_video','payed_unsuccess');
		$orders[$key]['dateline_fmt'] = $value['dateline'] ? dgmdate($value['dateline']) : '-';
		$orders[$key]['pay_time_fmt'] = $value['pay_time'] ? dgmdate($value['pay_time']) : '-';
	}

	$multi = multi($num, $limit, $curpage, 'plugin.php?id=zhanmishu_video:video&mod=teacher&act=contract', '0', '10');

}else{

	if ($config['upload_type'] == '2') {
			# code...
		
		//删除老订单
		// C::t("#zhanmishu_video#zhanmishu_video_order")->set_pay_overdue(30);

		//需要填写你的 Access Key 和 Secret Key
		$accessKey = $config['qiniuaccessKey'];
		$secretKey = $config['qiniusecretKey'];

		// 构建鉴权对象
		$auth = new Qiniu_Auth($accessKey, $secretKey);
		//baseUrl构造成私有空间的域名/key的形式
		$uploadToken = $auth->uploadToken($config['Bucket_Name']);
	}
	$limit = '20';
	$curpage = $_GET['page'] ? $_GET['page'] : '1';
	$field=array('isdel'=>'0','uid'=>$_G['uid']);

	$num = $video->get_type_course_num($field);
	$start = $num - ($num - $limit*$curpage+$limit);

	$courses = $video->get_type_course($start, $limit, 'desc','',$field);
	$multi = multi($num, $limit, $curpage, 'plugin.php?id=zhanmishu_video:video&mod=teacher', '0', '10');
}

$navtitle = lang('plugin/zhanmishu_video','teacher_center');
$metakeywords = $config['metakeywords'];
$metadescription = $config['metakeywords'];

include template('zhanmishu_video:'.$mod);
?>