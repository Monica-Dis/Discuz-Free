<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/conf/conf.php';
define('ENABLE_HTTP_PROXY', false);
define('HTTP_PROXY_IP', '127.0.0.1');
define('HTTP_PROXY_PORT', '8888');
class Zms_video_Autoloader{
  
  /**
     * ����Զ����أ�д��·����ȷ�������������ļ���
     * @param string $class ��������
     * @return void
     */
    public static function autoload($class) {


        $name = $class;
        if(false !== strpos($name,'\\')){
          $name = strstr($class, '\\', true);
        }
        if ($name == 'soapclient2' && !class_exists('SoapClient',false)) {
          exit('your server is not support soapclient');
          return ;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/class/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/model/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/sdk/Qiniu/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        global $_G;
        loadcache('plugin');
        $config = $_G['cache']['plugin']['zhanmishu_video'];

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/mts/aliyun-php-sdk-core/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/mts/aliyun-php-sdk-core/Auth/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/mts/aliyun-php-sdk-core/Exception/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/mts/aliyun-php-sdk-core/Http/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/mts/aliyun-php-sdk-core/Profile/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/mts/aliyun-php-sdk-core/Regions/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/mts/aliyun-php-sdk-live/live/Request/V20161101/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }


        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/mts/aliyun-php-sdk-mts/Mts/Request/V20140618/'.$name.'.php';
       
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/osssdk/Kms/Request/V20160120/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
        
        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/sdk/Qiniu/Processing/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }   
        

        $filename = DISCUZ_ROOT.'source/plugin/zhanmishu_video/source/sdk/Qiniu/Http/'.$name.'.php';
        if(is_file($filename)) {
            include $filename;
            return;
        }
    }
}

if (version_compare(phpversion(),'5.3.0','>=')) {
    spl_autoload_register('Zms_video_Autoloader::autoload',false,true);
}else{
    Zms_video_Autoloader::autoload("zhanmishu_video_base");
    Zms_video_Autoloader::autoload("zhanmishu_course");
    Zms_video_Autoloader::autoload("zhanmishu_video");
    Zms_video_Autoloader::autoload("zhanmishu_api");
    Zms_video_Autoloader::autoload("Qiniu_Auth");
    Zms_video_Autoloader::autoload("Qiniu_Config");
    Zms_video_Autoloader::autoload("PersistentFop");
    Zms_video_Autoloader::autoload("Qiniu_common_function");


    Zms_video_Autoloader::autoload("Request");
    Zms_video_Autoloader::autoload("Response");
    Zms_video_Autoloader::autoload("Client");
    Zms_video_Autoloader::autoload("QiNiu_Error");
 

    // Zms_video_Autoloader::autoload("OssClient");
    // Zms_video_Autoloader::autoload("MimeTypes");
    // Zms_video_Autoloader::autoload("OssException");
    // Zms_video_Autoloader::autoload("OssUtil");
    // Zms_video_Autoloader::autoload("Result");
    // Zms_video_Autoloader::autoload("PutSetDeleteResult");
    // Zms_video_Autoloader::autoload("RequestCore");
    // Zms_video_Autoloader::autoload("RequestCore_Exception");
    // Zms_video_Autoloader::autoload("ResponseCore"); 


    // Zms_video_Autoloader::autoload("HLSEncryptionWorkflow");   

    // Zms_video_Autoloader::autoload("Qiniu_Etag");
    // Zms_video_Autoloader::autoload("Qiniu_Zone");

    if (class_exists('SoapClient',false)) {
      Zms_video_Autoloader::autoload("soapclient2");
    }
}




?>