<?php
/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc && plugin by zhanmishu.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function remove_nopromissword($str){
	static $check = array('/\"/', '/\>/', '/\</', '/\'/', '/\(/', '/\)/');
	return preg_replace($check,"",$str);
}

function zms_go_header($url)  {  
	echo '<html><head><meta http-equiv="Content-Language" content="zh-CN"><meta http-equiv="refresh"  
	content="0;url='.$url.'"><title>loading ... </title></head><body><div style="display:none"></div><script>window.location="'.$url.'";</script></body></html>';  
	exit();  
}  
function PutMovie($file) {
    header("Content-type: video/mp4");
    header("Accept-Ranges: bytes");
     
    $size = filesize($file);
    if(isset($_SERVER['HTTP_RANGE'])){
        header("HTTP/1.1 206 Partial Content");
        list($name, $range) = explode("=", $_SERVER['HTTP_RANGE']);
        list($begin, $end) =explode("-", $range);
        if($end == 0) $end = $size - 1;
    }
    else {
        $begin = 0; $end = $size - 1;
    }
    header("Content-Length: " . ($end - $begin + 1));
    header("Content-Disposition: filename=".basename($file));
    header("Content-Range: bytes ".$begin."-".$end."/".$size);
 
    $fp = fopen($file, 'rb');
    fseek($fp, $begin);
    while(!feof($fp)) {
        $p = min(1024, $end - $begin + 1);
        $begin += $p;
        echo fread($fp, $p);
    }
    fclose($fp);
}
function zms_showtitle($name,$array=array()){
	if (empty($array)) {
		return '';
	}

	$str = '<div class="itemtitle"><h3>'.$name.'</h3><ul class="tab1">';
	foreach ($array as $key => $value) {
		$class=$value[2] =='1'?' class="current"':'';
		$str .= '<li'.$class.'><a href='.'"'.ADMINSCRIPT.'?action='.$value[1].'"><span>'.$value[0].'</span></a></li>';
	}
	$str .='</ul></div>';
	echo $str;
}


function zms_uploadimg($savedir='zhanmishu_video/',$thumb=false,$width='220',$height='220',$iskeybili='1'){ 

	//上传图片
	$images = array();
	foreach ($_FILES as $upfile_name => $value) {
		if ($_FILES[$upfile_name]['error'] == 0) {
	        require_once('source/class/discuz/discuz_upload.php');
	        $upload = new discuz_upload();
	        if($r1=$upload->init($_FILES[$upfile_name], 'common') && $r2=$upload->save(1)) {
	                $pic = $_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];

	        }
			$ext = addslashes(strtolower(substr(strrchr($_FILES[$upfile_name]['name'], '.'), 1, 10)));
			$img_path = $savedir.substr(str_shuffle('abcdefghijklmnopqrstuvwxyz'), 0, 8).rand(10000,99999).'.'.$ext;

			if (!is_dir(getglobal('setting/attachdir').$savedir)) {
				@mkdir(getglobal('setting/attachdir').$savedir, 0777);
				@touch(getglobal('setting/attachdir').$savedir.'/index.html');
			}
			if ($thumb) {
				//缩略图
				require_once('source/class/class_image.php');
				//随机名称
				$thumb = new image;
				$thumb->THumb($upload->attach['target'],$img_path,$width,$height,$iskeybili);
			}

			@copy(getglobal('setting/attachdir').$pic, getglobal('setting/attachdir').$img_path);
			@unlink(getglobal('setting/attachdir').$upload->attach['attachment']);
			$images[$upfile_name] = 'data/attachment/'.$img_path;
		}
	}
	return $images;
}


function zms_diconv($str,$in_charset,$out_charset){
	if (is_string($str)) {
		return diconv($str,$in_charset,$out_charset);
	}else if (is_array($str)) {
		foreach ($str as $key => $value) {
			$str[$key] = zms_diconv($value,$in_charset,$out_charset);
		}

		return $str;
	}
	return $str;
}


function zms_video_rewriteoutput($type, $returntype=true, $host) {
	$rewrite = zhanmishu_video::getInstance();
	$rule = $rewrite->ZmsGetFromCache('rewriteRule');
	$fextra = '';
	if($type == 'videoindex') {
		$r = array(
		);
	} elseif($type == 'videolist') {
		list(,,, $cat, $diff, $vip,$order) = func_get_args();
		$r = array(
			'{cat}' => $cat,
			'{diff}' => $diff,
			'{vip}' => $vip,
			'{order}' => $order
		);
	} elseif($type == 'coursepage') {
		list(,,, $cid) = func_get_args();
		$r = array(
			'{cid}' => $cid,
		);
	} elseif($type == 'course_videopage') {
		list(,,, $cid, $vid) = func_get_args();
		$r = array(
			'{cid}' => $cid,
			'{vid}' => $vid,
		);
	}


	$href = str_replace(array_keys($r), $r, $rule[$type]).$fextra;
	if(!$returntype) {
		return '<a href="'.$host.$href.'"'.(!empty($extra) ? stripslashes($extra) : '').'>';
	} else {
		return $host.$href;
	}
}
function check_IsImage($filename){
    $types = '.gif|.jpeg|.png|.bmp';//定义检查的图片类型
    if(file_exists($filename)){
        $info = getimagesize($filename);
        $ext = image_type_to_extension($info['2']);
        return stripos($types,$ext);
    }else{
        return false;
    }
}



?>