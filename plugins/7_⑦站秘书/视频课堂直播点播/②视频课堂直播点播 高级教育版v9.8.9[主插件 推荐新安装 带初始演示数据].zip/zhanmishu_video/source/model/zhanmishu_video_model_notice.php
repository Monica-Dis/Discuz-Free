<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_notice extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }

    private function __construct(){
    }

    private function __clone(){}

    public function doNotice(){
    
        $field = array();
        $field['sql'] = array(
            'relation' => 'sql',
            'sql' => '  (wechatStatus = 0 and isWechat = 1) or (noticeStatus = 0 and isNotice = 1) '
        );

        $notices = self::fetch_all(0, 20, 'desc', $field);
        set_time_limit(200);
        foreach ($notices as $key => $value) {

            // if ($value['isSms'] && $value['smsStatus'] == '0') {
            //     self::sendSms($value);
            // }
            if ($value['isWechat'] && $value['wechatStatus'] == '0') {
                self::sendWechat($value);
            }
            // if ($value['isEmail'] && $value['emailStatus'] == '0') {
            //     self::sendEmail($value);
            // }
            if ($value['isNotice'] && $value['noticeStatus'] == '0') {
                self::sendNotice($value);
            }

        }

        echo 'success';
    }

    public static function smsHander(){
        include_once DISCUZ_ROOT.'source/plugin/zhanmishu_sms/include/top/zhanmishu_sms.php';
        return new zhanmishu_sms();
    }

    public static function noticeSetting(){
        $zhihuHander = zhanmishu_video::getInstance();
        return $zhihuHander->noticeSetting();
    }

    public function sendSms($notice){
        $noticeSetting = self::noticeSetting();

        $mobile = self::smsHander()->getmobilebyuid($notice['inviteduid']);
        if (!$mobile) {
            self::update($notice['id'], array('smsStatus'=> '2')); // 未处理
            return;
        }
        self::smsHander()->sendpost($mobile, 
            $resp = zhanmishu_video::auto_charset_change(unserialize($notice['params']))
        );

        if (isset($resp['result']['err_code']) && $resp['result']['err_code'] == '0') {
            self::update($notice['id'], array('smsStatus'=> '1')); // 成功
        }else{
            self::update($notice['id'], array('smsStatus'=> '3')); // 发送失败
        }
        
    }
    public function addSendJob($data = array()){
        $noticeSetting = self::noticeSetting();
        // $noticeSetting['wechatDayLimit']
        $field = array();
        $field['inviteduid'] = $data['inviteduid'];
        $field['isWechat'] = $data['isWechat'];
        $field['cid'] = $data['cid'];
        $field['dateline'] = array(
            'key'=>'dateline',
            'relation'=>'<',
            'value'=> $data['dateline'] + 3600 * 24,
        );

        $num = zhanmishu_video_model_notice::fetch_num($field);
        if($num < $noticeSetting['wechatDayLimit']){
            self::insert($data);
        }
       
    }
    public function sendNotice($notice){
      $noticeSetting = self::noticeSetting();
      // $noticeContent = self::templateParams($noticeSetting['noticeContent'], unserialize($notice['params']));

      // print_r($noticeSetting);
      // print_r();
      // die;
      notification_add($notice['inviteduid'],'system',$noticeSetting['noticeContent'], unserialize($notice['params']));
      self::update($notice['id'], array('noticeStatus'=> '1')); // 成功

    }
    public function sendEmail($notice){
      global $_G;
      $noticeSetting = self::noticeSetting();
      $emailTitle = self::templateParams($noticeSetting['emailTitle'], unserialize($notice['params']));
      $emailContent = self::templateParams($noticeSetting['emailContent'], unserialize($notice['params']));

      include_once libfile('function/mail');



      $user = getuserbyuid($notice['inviteduid']);
      $succeed = sendmail("$user[username] <$user[email]>", $emailTitle , $emailContent);
      if ($succeed) {
        return self::update($notice['id'], array('emailStatus'=> '1')); // 成功
      }
      return self::update($notice['id'], array('emailStatus'=> '3')); // 成功
    }
    public function sendWechat($notice){
      $noticeSetting = self::noticeSetting();
      $notice['params'] = unserialize($notice['params']);
      
      $memberHander = zhanmishu_wechat_member::getInstance();

      // 公众号
      $type = '';
      $openid = $memberHander->get_openid_by_uid($notice['inviteduid'], $type);

      // 看小程序是否有
      // if(!$openid){
      //   $type = 'minapp';
      //   $openid = $memberHander->get_openid_by_uid($notice['inviteduid'], $type);
      // }
      // // app
      // if(!$openid){
      //   $type = 'app';
      //   $openid = $memberHander->get_openid_by_uid($notice['inviteduid'], $type);
      // }

      if (!$openid) {
          self::update($notice['id'], array('wechatStatus'=> '2')); // 未处理
          return false;
      }
      if (empty($noticeSetting['wechatParams'])) {
          self::update($notice['id'], array('wechatStatus'=> '2'));
          return false;
      }
      
      // 变量处理，返回需要的模板
      $wechatParams = array();
      foreach ($noticeSetting['wechatParams'] as $key => $value) {
          $wechatParams[] = self::templateParams($value, $notice['params']);
      }

      // 获取微信模板内容
      $field = array();
      $field['template'] = $noticeSetting['wechatTemplate'];
      $wechatTemplate = zhanmishu_wechat_model_template::fetch_one($field);

      $wechatTemplateParams = unserialize($wechatTemplate['params']);
      $wechatTemplateParamsData  = array();
      foreach ($wechatTemplateParams as $key => $value) {
          $wechatTemplateParamsData[$value['name']] = array(
              "value"=> $wechatParams[$key],
              "color"=>"#173177"
          );
      }
      
      $data = array(
          "touser" => $openid,
          "template_id" => $noticeSetting['wechatTemplate'],
          "url" => $notice['params']['url'],
          "topcolor" => "#FF0000",
          "data" => $wechatTemplateParamsData
      );

      // 发送模板消息
      $rs = $memberHander->wechatHander()->sendTemplateMessage(zhanmishu_video::auto_charset_change($data));

      if (!$rs) {
          self::update($notice['id'], array('wechatStatus'=> '3')); // 发送错误
          return false;
      }
      self::update($notice['id'], array('wechatStatus'=> '1'));
      return $rs;
    }


    public function templateParams($template = '', $params = array()){
        if (!$template) {
            return '';
        }
        if (empty($params)) {
            return $template;
        }

        foreach ($params as $key => $value) {
            $template = str_replace('{'.$key.'}', $value, $template);
        }
        return $template;
    }

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    public function fetch_all($start = 0, $limit = 100, $order = '',$field = array()) {
        $tags = C::t("#zhanmishu_video#zhanmishu_video_notice")->fetch_all($start, $limit, $order, $field);

        return $tags;
    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_video_notice")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_notice")->insert($data, true, true);
    }
    public function update($uid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_notice")->update($uid, $data);
    }
    public static function fetch($tagid = ''){
        if (!$tagid) {
            return false;
        }
        $tag = C::t("#zhanmishu_video#zhanmishu_video_notice")->fetch($tagid);
        if (empty($tag)) {
            return $tag;
        }
        return $tag;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $order          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $order = ''){
        return C::t("#zhanmishu_video#zhanmishu_video_notice")->fetch_one($field, $order);
    }

    public function fetch_all_admin_format($start = 0, $limit = 100, $order = '',$field = array()){

      // `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
      // `inviteuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `inviteduid` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `isSms` tinyint(1) unsigned NOT NULL DEFAULT '0',
      // `isEmail` tinyint(1) unsigned NOT NULL DEFAULT '0',
      // `isWechat` tinyint(1) unsigned NOT NULL DEFAULT '0',
      // `isNotice` tinyint(1) unsigned NOT NULL DEFAULT '0',
      // `tid` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `params` varchar(2000) NOT NULL DEFAULT '',
      // `smsStatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
      // `wechatStatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
      // `emailStatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
      // `noticeStatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
      // `dateline` int(10) unsigned NOT NULL DEFAULT '0',
      // `isdel` tinyint(1) unsigned NOT NULL DEFAULT '0',
        global $mpurl;
        $notices = self::fetch_all($start, $limit, $order, $field);
        $invitesFormat = array();
        foreach ($notices as $key => $value) {
            $noticesFormat[$key]['id'] = $value['id'];
            // $noticesFormat[$key]['inviteuid'] = $value['inviteuid'];
            // $noticesFormat[$key]['inviteduid'] = $value['inviteduid'];
            $user = getuserbyuid($value['inviteuid']);
            $noticesFormat[$key]['inviteUsername'] = $user['username'];
            $user = getuserbyuid($value['inviteduid']);
            $noticesFormat[$key]['invitedUsername'] = $user['username'];
            $noticesFormat[$key]['isNotice'] = $value['isNotice'] ? lang('plugin/zhanmishu_video', 'isOpen1') : lang('plugin/zhanmishu_video', 'isOpen0');
            $noticesFormat[$key]['isWechat'] = $value['isWechat'] ? lang('plugin/zhanmishu_video', 'isOpen1') : lang('plugin/zhanmishu_video', 'isOpen0');
            $noticesFormat[$key]['params'] = implode('<br>', unserialize($value['params']));
            $noticesFormat[$key]['wechatStatus'] = lang('plugin/zhanmishu_video', 'status'.$value['wechatStatus']);
            $noticesFormat[$key]['noticeStatus'] = lang('plugin/zhanmishu_video', 'status'.$value['noticeStatus']);
            $noticesFormat[$key]['dateline'] = dgmdate($value['dateline']);
            // $noticesFormat[$key]['act'] = '<a href="'.$mpurl.'&method=addinvite&inviteid='.$value['inviteid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','edit').'</a>';
            $noticesFormat[$key]['act'] = '';
        }
        return $noticesFormat;
    }
}