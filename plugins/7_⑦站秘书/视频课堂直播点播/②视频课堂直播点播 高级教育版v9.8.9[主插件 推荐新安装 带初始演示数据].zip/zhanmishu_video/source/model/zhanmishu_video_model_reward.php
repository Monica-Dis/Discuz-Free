<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_reward extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }

    private function __construct(){
    }

    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    public function fetch_all($start = 0, $limit = 100, $order = '',$field = array()) {
        $rewards = C::t("#zhanmishu_video#zhanmishu_video_reward")->fetch_all($start, $limit, $order, $field);

        return $rewards;
    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_video_reward")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_reward")->insert($data, true, true);
    }
    public function delete($oid = '') {
        if (!$oid) {
            return false;
        }
        return C::t("#zhanmishu_video#zhanmishu_video_reward")->delete($oid);
    }
    public static function fetch($oid = '', $isFormat = false){
        if (!$oid) {
            return array();
        }
        $order = C::t("#zhanmishu_video#zhanmishu_video_reward")->fetch($oid);
        if ($isFormat) {
        }
        return $order;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $order          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $order = ''){
        return C::t("#zhanmishu_video#zhanmishu_video_reward")->fetch_one($field, $order);
    }
    public function update($oid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_reward")->update($oid, $data);
    }
    public function try_finish($unPayeds = array()){
        global $_G;
        $url = $_G['siteurl'].'source/plugin/zhanmishu_video/api.php?mod=reward&action=check&out_trade_no='. implode(',', $unPayeds);
        echo '<img src="'.$url.'" style="display:none;" alt="">';
    }
    public function fetch_all_admin_format($start = 0, $limit = 100, $order = '',$field = array()){
        global $mpurl;
        // lang('plugin/zhanmishu_video', 'rid'),
        // lang('plugin/zhanmishu_video', 'cid'),
        // lang('plugin/zhanmishu_video', 'vid'),
        // lang('plugin/zhanmishu_video', 'teacher_name'),
        // lang('plugin/zhanmishu_video', 'present_username'),
        // lang('plugin/zhanmishu_video', 'reward_total_fee'),
        // lang('plugin/zhanmishu_video', 'ispayed'),
        // lang('plugin/zhanmishu_video', 'out_trade_no'),
        // lang('plugin/zhanmishu_video', 'dateline'),
        $rewards = self::fetch_all($start, $limit, $order, $field);
        $rewardsFormat = array();
        $unPayeds = array();
        foreach ($rewards as $key => $value) {
            if ($value['ispayed'] == '0') {
                $unPayeds[] = $value['out_trade_no'];
            }
            $rewardsFormat[$key]['rid'] = $value['rid'];
            // $course = zhanmishu_video_model_course::fetch($value['cid']);
            $rewardsFormat[$key]['cid'] = $value['cid'];
            $rewardsFormat[$key]['vid'] = $value['vid'];
            $user = getuserbyuid($value['uid']);
            $rewardsFormat[$key]['teacher_name'] = $user['username'];
            $user = getuserbyuid($value['present_uid']);
            $rewardsFormat[$key]['present_username'] = $user['username'];
            $rewardsFormat[$key]['total_fee'] = $value['total_fee'] / 100;
            $rewardsFormat[$key]['ispayed'] = $value['ispayed'] ? lang('plugin/zhanmishu_video','payed_success') : lang('plugin/zhanmishu_video','payed_unsuccess');
            $rewardsFormat[$key]['out_trade_no'] = $value['out_trade_no'];
            $rewardsFormat[$key]['dateline'] = $value['dateline'] ? dgmdate($value['dateline']) : '';
        }
        self::try_finish($unPayeds);
        return $rewardsFormat;
    }
}