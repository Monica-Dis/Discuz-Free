<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_course extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }

    private function __construct(){
    }

    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    /**
     * 获取越权分享token
     */
    public function shareToken(){
        global $_G;
        

    }

    public function shareTokenVerify($url=''){
        global $_G;
        // 移除url中的shareToken,也就是去掉&shareToken=后字符串
        // 'shareToken=';
        $urls = explode('shareToken=', $url);
        $shareToken = end($urls);
        $url = str_replace($shareToken, '', $url);
        // echo $shareToken.'<br>';
        // echo $_G['config']['security']['authkey'].$url.'<br>';
        // echo md5($_G['config']['security']['authkey'].$url).'<br>';
        if($shareToken == md5($_G['config']['security']['authkey'].$url)){
            return true;
        }

        return false;
    }

    public function fetch_all($start = 0, $limit = 100, $course = '',$field = array()) {
        $courses = C::t("#zhanmishu_video#zhanmishu_video_course")->fetch_all($start, $limit, $course, $field);

        return $courses;
    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_video_course")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_course")->insert($data, true, true);
    }
    public function delete($cid = '') {
        if (!$cid) {
            return false;
        }
        return C::t("#zhanmishu_video#zhanmishu_video_course")->delete($cid);
    }
    public static function fetch($cid, $isaddview=false, $isupdateorder=false){
        if (!$cid) {
            return false;
        }
        $c = C::t("#zhanmishu_video#zhanmishu_video_course")->fetch($cid);

        $up = array();
        if ($isaddview) {
            $up['views'] = $c['views'] + 1;
        }
        if ($isupdateorder) {
            $num = C::t("#zhanmishu_video#zhanmishu_video_order")->get_orders_num(array('cid'=>$c['cid'],'ispayed'=>'1'));
            $up['learns'] = $num + $c['learns_add'];
        }
        if (!empty($up)) {
            C::t("#zhanmishu_video#zhanmishu_video_course")->update($cid,$up);  
        }

        return $c;
    }
    /**
     * 课程用户组校验
     * 对比传入的课程用户组， 然后和当前用户的扩展用户组、主用户组进行校验
     * 如果有交集，则返回成功
     */
    public static function checkGroup($groups = '', $uid = ''){
        if(!is_array($groups)){
            $groups = explode(',', $groups);
        }

        if (empty($groups)) {
            return false;
        }

        global $_G;
        if(!$_G['uid']){
            return false;
        }
        // 教师本人，管理员，直接通过
        if($_G['groupid'] == '1' || ($_G['uid'] == $uid && $uid > 0)){
            return true;
        }
        // 用户拥有的扩展组和普通组
        $extgroups = explode("\t", $_G['member']['extgroupids']);
        $extgroups[] = $_G['groupid'];


        $aclGroups = array_intersect($extgroups, $groups);
        $aclGroups = is_array($aclGroups) ? $aclGroups : array();
        if (!empty($aclGroups)) {
            return true;
        }
        return false;

    }

    /**
     * 使用播放密码
     */
    public function useCoursePassword($course_password = '', $cid = '', $columnid = ''){
        if (!$course_password) {
            return array(
                'code' => '-1',
                'msg'=> lang('plugin/zhanmishu_video', 'password_is_required')
            ); // code error
        }
        global $_G;

        if ($cid) {
            $course = zhanmishu_video_model_course::fetch($cid);
            if (empty($course)) {
                return array(
                    'code' => '-6',
                    'msg'=> lang('plugin/zhanmishu_video', 'course_isnot_exists')
                );
            }else if (!$course['course_password']) {
                return array(
                    'code' => '-7',
                    'msg'=> lang('plugin/zhanmishu_video', 'course_isnot_passowrd_course')
                ); 
            }else if ($course['course_password'] != $course_password) {
                return array(
                    'code' => '-8',
                    'msg'=> lang('plugin/zhanmishu_video', 'password_is_incorrect')
                );
            }
            // 验证是否支付购买过
            $videoHander = zhanmishu_video::getInstance();
            $ispay = $videoHander->checkuser_ispay_course($cid,$_G['uid']) ? 1 : 0;
            if ($ispay > 0) {
                return array(
                    'code' => '2',
                    'msg'=> lang('plugin/zhanmishu_video', 'password_is_used')
                );
            }

            $order = array();
            $order['cid'] = $cid;
            $order['uid'] = $course['uid'];
            $order['ispayed'] = '1';
            $order['isselled'] = '1';
            $order['order_type'] = '6'; // order coupon
            $order['pay_type'] = '6'; // pay coupon
            $order['course_name'] = $course['course_name'];
            $order['course_img'] = $course['course_img'];
            $order['course_intro'] = $course['course_intro'];
            $order['course_price'] = $course['course_price'];
            $order['total_fee'] = '0';
            $order['trade_no'] = $password;
            $order['out_trade_no'] = md5($password);
            $order['buyer_uid'] = $_G['uid'];
            $order['dateline'] = TIMESTAMP;
            $order['pay_time'] = TIMESTAMP;
            $order['success_time'] = TIMESTAMP;
            $order['status'] = '1';
            $order['issuccess'] = '1';

            $oid = zhanmishu_video_model_order::insert($order);
            if (!$oid) {
               return array(
                    'code' => '-9',
                    'msg'=> lang('plugin/zhanmishu_video', 'order_fail')
                );
            }
            $data = array();
            $data['useUid'] = $_G['uid'];
            $data['cid'] = $cid;
            $data['isLock'] = '1';
            $data['isUsed'] = '1';
            $data['use_time'] = TIMESTAMP;
            self::update($coupon['couponid'], $data);
            return array(
                'code' => '1',
                'msg'=> lang('plugin/zhanmishu_video', 'pay_success')
            );
        }
    }
    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $course          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $course = ''){
        return C::t("#zhanmishu_video#zhanmishu_video_course")->fetch_one($field, $course);
    }
    public function update($cid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_course")->update($cid, $data);
    }
    public function fetch_all_admin_format($start = 0, $limit = 100, $order = '',$field = array()){
        global $mpurl;

        $courses = self::fetch_all($start, $limit, $order, $field);
        $coursesFormat = array();
        foreach ($courses as $key => $value) {
            
        }
        return $coursesFormat;
    }
}