<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_record extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }

    private function __construct(){
    }

    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    public function fetch_all($start = 0, $limit = 100, $record = '',$field = array()) {
        $records = C::t("#zhanmishu_video#zhanmishu_video_record")->fetch_all($start, $limit, $record, $field);

        return $records;
    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_video_record")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_record")->insert($data, true, true);
    }
    public function userecordCode($record_code = '', $cid = '', $columnid = ''){
        if (!$record_code) {
            return -1; // code error
        }
        global $_G;
        $field = array();
        $field['record_code'] = $record_code;
        $record = C::t("#zhanmishu_video#zhanmishu_video_record")->fetch_one($field);
        if (empty($record)) {
            return -2; // code not exists
        }else if ($record['isLock'] && $record['useUid'] != $_G['uid']) {
            return -3; // acl error
        }else if ($record['expire_time'] > 0 && $record['expire_time'] < TIMESTAMP) {
            return -4; // expire_time
        }else if ($record['isUsed']) {
            return -5; // isUsed
        }

        if ($cid) {
            $course = zhanmishu_video_model_course::fetch($cid);
            if (empty($course)) {
                return -6; // isUsed
            }
            // 验证是否支付购买过
            $videoHander = zhanmishu_video::getInstance();
            $ispay = $videoHander->checkuser_ispay_course($cid,$_G['uid']) ? 1 : 0;
            if ($ispay > 0) {
                return 2;
            }
            if ($record['record_price'] >= $course['course_price']) {


                $order = array();
                $order['cid'] = $cid;
                $order['uid'] = $course['uid'];
                $order['ispayed'] = '1';
                $order['isselled'] = '1';
                $order['order_type'] = '5'; // order record
                $order['pay_type'] = '5'; // pay record
                $order['course_name'] = $course['course_name'];
                $order['course_img'] = $course['course_img'];
                $order['course_intro'] = $course['course_intro'];
                $order['course_price'] = $course['course_price'];
                $order['total_fee'] = '0';
                $order['trade_no'] = $record['record_code'];
                $order['out_trade_no'] = $videoHander->get_rand_trade_no();
                $order['buyer_uid'] = $_G['uid'];
                $order['dateline'] = TIMESTAMP;
                $order['pay_time'] = TIMESTAMP;
                $order['success_time'] = TIMESTAMP;
                $order['status'] = '1';
                $order['issuccess'] = '1';

                $oid = zhanmishu_video_model_order::insert($order);
                if (!$oid) {
                    return -7;
                }
                $data = array();
                $data['useUid'] = $_G['uid'];
                $data['cid'] = $cid;
                $data['isLock'] = '1';
                $data['isUsed'] = '1';
                $data['use_time'] = TIMESTAMP;
                self::update($record['recordid'], $data);
                  // `recordid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
                  // `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
                  // `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
                  // `record_name` varchar(256) NOT NULL DEFAULT '',
                  // `record_code` varchar(256) NOT NULL DEFAULT '',
                  // `record_price` mediumint(8) unsigned NOT NULL DEFAULT '0',
                  // `record_number` mediumint(8) unsigned NOT NULL DEFAULT '0',
                  // `record_price_limit` mediumint(8) unsigned NOT NULL DEFAULT '0',
                  // `useUid` mediumint(8) unsigned NOT NULL DEFAULT '0',
                  // `isLock` tinyint(1) unsigned NOT NULL DEFAULT '0',
                  // `isUsed` tinyint(1) unsigned NOT NULL DEFAULT '0',
                  // `dateline` int(10) unsigned NOT NULL DEFAULT '0',
                  // `use_time` int(10) unsigned NOT NULL DEFAULT '0',
                  // `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
                return 1;
            }
            // 兑换券不足与全额抵扣，只能以优惠价格方式
            return 3;
        }



    }

    public function delete($recordid = '') {
        if (!$recordid) {
            return false;
        }
        return C::t("#zhanmishu_video#zhanmishu_video_record")->delete($recordid);
    }
    public static function fetch($recordid = '', $isFormat = false){
        if (!$recordid) {
            return array();
        }
        $record = C::t("#zhanmishu_video#zhanmishu_video_record")->fetch($recordid);
        if ($isFormat) {
            if ($record['expire_time']) {
                $record['expire_time'] = ceil(($record['expire_time'] - TIMESTAMP) / (3600 * 24));
                $record['expire_time'] = $record['expire_time'] > 0 ? $record['expire_time'] : '0';
            }
            $record['record_price'] = $record['record_price'] / 100;
            $record['record_price_limit'] = $record['record_price_limit'] / 100;
        }
        return $record;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $record          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $record = ''){
        return C::t("#zhanmishu_video#zhanmishu_video_record")->fetch_one($field, $record);
    }
    public function update($recordid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_record")->update($recordid, $data);
    }
    public function fetch_all_admin_format($start = 0, $limit = 100, $order = '',$field = array()){
        global $mpurl;
      // `record_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
      // `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `duration` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `seek` mediumint(8) unsigned NOT NULL DEFAULT '0',
      // `dateline` int(10) unsigned NOT NULL DEFAULT '0',
        $records = self::fetch_all($start, $limit, $order, $field);
        $recordsFormat = array();
        foreach ($records as $key => $value) {
            $recordsFormat[$key]['record_id'] = $value['record_id'];
            $user = getuserbyuid($value['uid']);
            $recordsFormat[$key]['username'] = $user['username'];
            $recordsFormat[$key]['cid'] = $value['cid'];
            $recordsFormat[$key]['vid'] = $value['vid'];
            // $recordsFormat[$key]['uid'] = $value['uid'];
            $recordsFormat[$key]['duration'] = $value['duration'];
            $recordsFormat[$key]['seek'] = $value['seek'];
            $recordsFormat[$key]['dateline'] = $value['dateline'] ? dgmdate($value['dateline'], 'y-m-d H:i:s') : '';

            $recordsFormat[$key]['act'] = '<a href="'.$mpurl.'&method=recordEdit&recordid='.$value['recordid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','edit').'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$mpurl.'&method=recordDelete&recordid='.$value['recordid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','delete').'</a>';
        }
        return $recordsFormat;
    }

    public function outputFormat($data = array()){
        global $_G;
        if (!is_array($data)) {
            return array();
        }

        $return = array();
        if ($data['cid']) {
            $return['record_code'] = $_G['siteurl'].'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$data['cid'].'&record='.$data['record_code'];
        }else{
            $return['record_code'] = $data['record_code'];
        }

        return $return;
    }
}