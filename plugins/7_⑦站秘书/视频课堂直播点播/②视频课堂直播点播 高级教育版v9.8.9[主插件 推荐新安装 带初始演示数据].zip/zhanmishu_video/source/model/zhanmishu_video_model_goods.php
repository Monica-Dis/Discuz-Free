<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_goods extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }

    private function __construct(){
    }

    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    public function fetch_all($start = 0, $limit = 100, $order = '',$field = array()) {
        $tags = C::t("#zhanmishu_video#zhanmishu_video_goods")->fetch_all($start, $limit, $order, $field);

        return $tags;
    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_video_goods")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_goods")->insert($data, true, true);
    }
    public function update($uid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_goods")->update($uid, $data);
    }
    public static function fetch($tagid = ''){
        if (!$tagid) {
            return false;
        }
        $tag = C::t("#zhanmishu_video#zhanmishu_video_goods")->fetch($tagid);
        if (empty($tag)) {
            return $tag;
        }
        return $tag;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $order          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $order = ''){
        return C::t("#zhanmishu_video#zhanmishu_video_goods")->fetch_one($field, $order);
    }

    public function fetch_all_admin_format($start = 0, $limit = 100, $order = '',$field = array()){
        global $mpurl;
        $goodss = self::fetch_all($start, $limit, $order, $field);
        $invitesFormat = array();
        foreach ($goodss as $key => $value) {
            $goodssFormat[$key]['id'] = $value['id'];
            // $goodssFormat[$key]['inviteuid'] = $value['inviteuid'];
            // $goodssFormat[$key]['inviteduid'] = $value['inviteduid'];
            $user = getuserbyuid($value['inviteuid']);
            $goodssFormat[$key]['inviteUsername'] = $user['username'];
            $user = getuserbyuid($value['inviteduid']);
            $goodssFormat[$key]['invitedUsername'] = $user['username'];
            $goodssFormat[$key]['isgoods'] = $value['isgoods'] ? lang('plugin/zhanmishu_video', 'isOpen1') : lang('plugin/zhanmishu_video', 'isOpen0');
            $goodssFormat[$key]['isWechat'] = $value['isWechat'] ? lang('plugin/zhanmishu_video', 'isOpen1') : lang('plugin/zhanmishu_video', 'isOpen0');
            $goodssFormat[$key]['params'] = implode('<br>', unserialize($value['params']));
            $goodssFormat[$key]['wechatStatus'] = lang('plugin/zhanmishu_video', 'status'.$value['wechatStatus']);
            $goodssFormat[$key]['goodsStatus'] = lang('plugin/zhanmishu_video', 'status'.$value['goodsStatus']);
            $goodssFormat[$key]['dateline'] = dgmdate($value['dateline']);
            // $goodssFormat[$key]['act'] = '<a href="'.$mpurl.'&method=addinvite&inviteid='.$value['inviteid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','edit').'</a>';
            $goodssFormat[$key]['act'] = '';
        }
        return $goodssFormat;
    }
}