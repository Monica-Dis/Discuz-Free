<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_order extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }

    private function __construct(){
    }

    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    public function fetch_all($start = 0, $limit = 100, $order = '',$field = array()) {
        $orders = C::t("#zhanmishu_video#zhanmishu_video_order")->fetch_all($start, $limit, $order, $field);

        return $orders;
    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_video_order")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_order")->insert($data, true, true);
    }
    public function delete($oid = '') {
        if (!$oid) {
            return false;
        }
        return C::t("#zhanmishu_video#zhanmishu_video_order")->delete($oid);
    }
    public static function fetch($oid = '', $isFormat = false){
        if (!$oid) {
            return array();
        }
        $order = C::t("#zhanmishu_video#zhanmishu_video_order")->fetch($oid);
        if ($isFormat) {
        }
        return $order;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $order          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $order = ''){
        return C::t("#zhanmishu_video#zhanmishu_video_order")->fetch_one($field, $order);
    }
    public function update($oid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_order")->update($oid, $data);
    }
    public function fetch_all_admin_format($start = 0, $limit = 100, $order = '',$field = array()){
        global $mpurl;

        $orders = self::fetch_all($start, $limit, $order, $field);
        $ordersFormat = array();
        foreach ($orders as $key => $value) {
            
        }
        return $ordersFormat;
    }


}