<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_video extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }

    private function __construct(){
    }

    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    // public function videoChapterList($list = array()){
    //     $chapterList = array();
    //     foreach ($list as $key => $value) {
            
    //     }
    // }

    public function fetch_all($start = 0, $limit = 100, $order = '',$field = array()) {
        $videos = C::t("#zhanmishu_video#zhanmishu_video")->fetch_all($start, $limit, $order, $field);

        return $videos;
    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_video")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video")->insert($data, true, true);
    }
    public function delete($vid = '') {
        if (!$vid) {
            return false;
        }
        return C::t("#zhanmishu_video#zhanmishu_video")->delete($vid);
    }
    public static function fetch($vid = '', $isFormat = false){
        if (!$vid) {
            return array();
        }
        $video = C::t("#zhanmishu_video#zhanmishu_video")->fetch($vid);
        if ($isFormat) {
        }
        return $video;
    }

    public function isLive($video_urltype = ''){
        if (in_array($currentVideo['video_urltype'],array('5','6','7','8','9','11','12','13'))) {
            return '1';
        }
        return '0';
    }
    public function liveUrlType($video_urltype = ''){
        if (in_array($video_urltype, array('5','4'))) {
            return 'str';
        }else if (in_array($video_urltype, array('11','13'))) {
            return 'live';
        }
        return 'url';
    }

    public function videoFormat($video = array(), & $course=array()){
        if (empty($video)) {
            return array();
        }

        if($video['isrecord'] == '1'){
            $video['typeName'] = lang('plugin/zhanmishu_video','live_play_history');
        }else if ($video['islive'] == '1') {
            $video['typeName'] = lang('plugin/zhanmishu_video','live');
        }else if ($video['ismusic'] == '1') {
            $video['typeName'] = lang('plugin/zhanmishu_video','music');
        }else if ($video['isppt'] == '1') {
            $video['typeName'] = lang('plugin/zhanmishu_video','ppt');
        }else if ($video['imagetext'] == '1') {
            $video['typeName'] = lang('plugin/zhanmishu_video','imagetext');
        }else {
            $video['typeName'] = lang('plugin/zhanmishu_video','video');
        }

        $videoHander = zhanmishu_video::getInstance();
        $videoconfig = $videoHander->config;
        if($video['isfree'] || ($videoconfig['noprice_video_isfree'] && $video['video_price'] == '0')){
            $video['tryName'] = lang('plugin/zhanmishu_video','tryVideo');
        }

        $video['video_length'] = self::timeFormat($video['video_length'], true, true);
        $video['create_time'] = dgmdate($video['dateline'],'Y-m-d');
        $video['video_img'] = $video['video_img'] ? $video['video_img'] : $course['course_img'];
        return $video;

    }
    public function timeFormat($remain_time = '', $is_hour = true, $is_minutes = true){
        if(empty($remain_time)) {
            return '';
        }else if ($remain_time < 60) {
            return $remain_time.lang('plugin/zhanmishu_video','second');
        }

        $day = floor($remain_time / (3600*24));
        $day = $day > 0 ? $day.lang('plugin/zhanmishu_video','day') : '';
        $hour = floor(($remain_time % (3600*24)) / 3600);
        $hour = $hour > 0 ? $hour.lang('plugin/zhanmishu_video','hour') : '';
        if($is_hour && $is_minutes) {
            $minutes = floor((($remain_time % (3600*24)) % 3600) / 60);
            $minutes = $minutes > 0 ? $minutes.lang('plugin/zhanmishu_video','min') : '';
            return $day.$hour.$minutes;
        }

        if($hour) {
            return $day.$hour;
        }
        return $day;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $order          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $order = ''){
        return C::t("#zhanmishu_video#zhanmishu_video")->fetch_one($field, $order);
    }
    public function update($vid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video")->update($vid, $data);
    }
    public function fetch_all_admin_format($start = 0, $limit = 100, $order = '',$field = array()){
        global $mpurl;

        $videos = self::fetch_all($start, $limit, $order, $field);
        $videosFormat = array();
        foreach ($videos as $key => $value) {
            
        }
        return $videosFormat;
    }
}