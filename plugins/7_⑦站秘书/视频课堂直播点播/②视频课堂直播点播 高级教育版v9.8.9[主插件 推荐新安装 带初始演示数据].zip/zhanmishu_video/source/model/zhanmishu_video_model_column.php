<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_column extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }
    

    private function __construct(){
    }

    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2020-02-01
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       [type]     $cid            [description]
     * @return      [type]     专栏的数组            [array]
     */
    public function fetchColumnsByCid($cid = ''){
        return C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetchColumnsByCid($cid);
    }

    public function fetchCourseColumnsPayStatus($cid = '', $uid = ''){
        // 查询当前课程在哪个专栏内？
        if (!$cid || !$uid) {
            return 0;
        }

        $columns = self::fetchColumnsByCid($cid);
        if (empty($columns)) {
            return 0;
        }

        // 循环专栏，只要某一个专栏支付了，即跳出循环，返回支付成功状态
        foreach ($columns as $key => $value) {
            if (self::checkuser_ispay_column($value['columnid'], $uid)) {
                return 1;
            }
        }

        return 0;
    }

    public function checkuser_ispay_column($columnid, $uid){
        $videoHander = zhanmishu_video::getInstance();
        return $videoHander->checkuser_ispay_column($columnid, $uid) > 0 ? 1 : 0;
    }

    public function fetch_all($start = 0, $limit = 100, $column = '',$field = array()) {
        $columns = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch_all($start, $limit, $column, $field);

        return $columns;
    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_course_column")->insert($data, true, true);
    }
    public function delete($oid = '') {
        if (!$oid) {
            return false;
        }
        return C::t("#zhanmishu_video#zhanmishu_video_course_column")->delete($oid);
    }
    public static function fetch($oid = '', $isFormat = false){
        if (!$oid) {
            return array();
        }
        $column = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch($oid);
        if ($isFormat) {
        }
        return $column;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $column          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $column = ''){
        return C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch_one($field, $column);
    }
    public function update($oid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_course_column")->update($oid, $data);
    }
    public function fetch_all_admin_format($start = 0, $limit = 100, $column = '',$field = array()){
        global $mpurl;
            // lang('plugin/zhanmishu_video', 'columnid'),
            // lang('plugin/zhanmishu_video', 'sellner'),
            // lang('plugin/zhanmishu_video', 'course_column_name'),
            // lang('plugin/zhanmishu_video', 'issell'),
            // lang('plugin/zhanmishu_video', 'sellnum'),
            // lang('plugin/zhanmishu_video', 'price'),
            // lang('plugin/zhanmishu_video', 'img'),
            // lang('plugin/zhanmishu_video', 'datetime'),
            // lang('plugin/zhanmishu_video', 'act')));
        $columns = self::fetch_all($start, $limit, $column, $field);
        $columnsFormat = array();
        foreach ($columns as $key => $value) {
            $columnsFormat[$key]['columnid'] = $value['columnid'];
            $columnsFormat[$key]['sellner'] = $value['uid'];
            $columnsFormat[$key]['title'] = '<a href="plugin.php?id=zhanmishu_video:video&mod=column&columnid='.$value['columnid'].'" target="_blank">'.$value['course_column_name'].'<br><img src="'.$value['course_column_img'].'" width="40px" height="40px"></a>';
            $columnsFormat[$key]['issell'] = $value['issell'];
            $columnsFormat[$key]['sellnum'] = $value['sellnum'];
            $columnsFormat[$key]['price'] = $value['course_column_price'];
            $columnsFormat[$key]['dateline'] = $value['dateline'] ? dgmdate($value['dateline']) : '';
            $columnsFormat[$key]['act'] = '<a href="'.$mpurl.'&act=course_column_admin&method=delete&columnid='.$value['columnid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','delete').'</a>';
        }
        return $columnsFormat;
    }
}