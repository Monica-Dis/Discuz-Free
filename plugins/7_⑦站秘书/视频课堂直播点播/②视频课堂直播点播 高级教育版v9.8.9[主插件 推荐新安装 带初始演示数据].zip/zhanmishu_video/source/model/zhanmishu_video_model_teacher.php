<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_teacher extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }

    private function __construct(){
    }

    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    public function fetch_all($start = 0, $limit = 100, $teacher = '',$field = array()) {
        $teachers = C::t("#zhanmishu_video#zhanmishu_teacher_info")->fetch_all($start, $limit, $teacher, $field);

        return $teachers;
    }

    public function teacherName($uid = ''){
        if (!$uid) {
            return '';
        }

        $teacher = self::fetch($uid);
        if (!empty($teacher)) {
            return $teacher['teacher_name'];
        }
        $teacher = getuserbyuid($uid);
        return $teacher['username'];

    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_teacher_info")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_teacher_info")->insert($data, true, true);
    }
    public function useteacherCode($teacher_code = '', $cid = '', $columnid = ''){
        if (!$teacher_code) {
            return -1; // code error
        }
        global $_G;
        if (!$_G['uid']) {
            return -11; // code error
        }
        $field = array();
        $field['teacher_code'] = $teacher_code;
        $teacher = C::t("#zhanmishu_video#zhanmishu_teacher_info")->fetch_one($field);
        if (empty($teacher)) {
            return -2; // code not exists
        }else if ($teacher['isLock'] && $teacher['useUid'] != $_G['uid']) {
            return -3; // acl error
        }else if ($teacher['expire_time'] > 0 && $teacher['expire_time'] < TIMESTAMP) {
            return -4; // expire_time
        }else if ($teacher['isUsed']) {
            return -5; // isUsed
        }

        if ($cid) {
            $course = zhanmishu_video_model_course::fetch($cid);
            if (empty($course)) {
                return -6; // isUsed
            }
            // 验证是否支付购买过
            $videoHander = zhanmishu_video::getInstance();
            $ispay = $videoHander->checkuser_ispay_course($cid,$_G['uid']) ? 1 : 0;
            if ($ispay > 0) {
                return 2;
            }
            if ($teacher['teacher_price'] >= $course['course_price']) {


                $order = array();
                $order['cid'] = $cid;
                $order['uid'] = $course['uid'];
                $order['ispayed'] = '1';
                $order['isselled'] = '1';
                $order['order_type'] = '5'; // order teacher
                $order['pay_type'] = '5'; // pay teacher
                $order['course_name'] = $course['course_name'];
                $order['course_img'] = $course['course_img'];
                $order['course_intro'] = $course['course_intro'];
                $order['course_price'] = $course['course_price'];
                $order['total_fee'] = '0';
                $order['trade_no'] = $teacher['teacher_code'];
                $order['out_trade_no'] = $videoHander->get_rand_trade_no();
                $order['buyer_uid'] = $_G['uid'];
                $order['dateline'] = TIMESTAMP;
                $order['pay_time'] = TIMESTAMP;
                $order['success_time'] = TIMESTAMP;
                $order['status'] = '1';
                $order['issuccess'] = '1';

                $oid = zhanmishu_video_model_order::insert($order);
                if (!$oid) {
                    return -7;
                }
                $data = array();
                $data['useUid'] = $_G['uid'];
                $data['cid'] = $cid;
                $data['isLock'] = '1';
                $data['isUsed'] = '1';
                $data['use_time'] = TIMESTAMP;
                self::update($teacher['teacherid'], $data);
                return 1;
            }
            // 兑换券不足与全额抵扣，只能以优惠价格方式
            return 3;
        }
    }

    public function delete($teacherid = '') {
        if (!$teacherid) {
            return false;
        }
        return C::t("#zhanmishu_video#zhanmishu_teacher_info")->delete($teacherid);
    }
    public static function fetch($teacherid = '', $isFormat = false){
        if (!$teacherid) {
            return array();
        }
        $teacher = C::t("#zhanmishu_video#zhanmishu_teacher_info")->fetch($teacherid);
        if ($isFormat) {
            if ($teacher['expire_time']) {
                $teacher['expire_time'] = ceil(($teacher['expire_time'] - TIMESTAMP) / (3600 * 24));
                $teacher['expire_time'] = $teacher['expire_time'] > 0 ? $teacher['expire_time'] : '0';
            }
            $teacher['teacher_price'] = $teacher['teacher_price'] / 100;
            $teacher['teacher_price_limit'] = $teacher['teacher_price_limit'] / 100;
        }
        return $teacher;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $teacher          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $teacher = ''){
        return C::t("#zhanmishu_video#zhanmishu_teacher_info")->fetch_one($field, $teacher);
    }
    public function update($teacherid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_teacher_info")->update($teacherid, $data);
    }
    public function fetch_all_admin_format($start = 0, $limit = 100, $order = '',$field = array()){
        global $mpurl;
        $teachers = self::fetch_all($start, $limit, $order, $field);
        $teachersFormat = array();
        foreach ($teachers as $key => $value) {
            // $user = getuserbyuid($value['teacheruid']);

            $teachersFormat[$key]['uid'] = $value['uid'];
            $teachersFormat[$key]['teacher_name'] = $value['teacher_name'];
            $teachersFormat[$key]['teacher_img'] = '<img src="'.$value['teacher_img'].'" height="80px" style="text-align:center;">';
            // $teachersFormat[$key]['teacher_intro'] = strip_tags($value['teacher_intro']);
            // $teachersFormat[$key]['teacher_content'] = zhanmishu_course::contentFormat($value['teacher_content'], 'DECODE');
            $teachersFormat[$key]['teacher_helper_ids'] = $value['teacher_helper_ids'];
            $teachersFormat[$key]['score'] = $value['score'];
            $teachersFormat[$key]['replies'] = $value['replies'];
            $teachersFormat[$key]['course_num'] = $value['course_num'];
            $teachersFormat[$key]['videos_num'] = $value['videos_num'];
            $teachersFormat[$key]['teacher_per'] = $value['teacher_per'] ? $value['teacher_per'] : '';
            $teachersFormat[$key]['dateline'] = $value['dateline'] ? dgmdate($value['dateline']) : '';
            $teachersFormat[$key]['act'] = '<a href="'.$mpurl.'&method=teacherEdit&uid='.$value['uid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','edit').'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$mpurl.'&method=teacherDelete&uid='.$value['uid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','delete').'</a>';
        }
        return $teachersFormat;
    }

    public function outputFormat($data = array()){
        global $_G;
        if (!is_array($data)) {
            return array();
        }

        $return = array();
        if ($data['cid']) {
            $return['teacher_code'] = $_G['siteurl'].'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$data['cid'].'&teacher='.$data['teacher_code'];
        }else{
            $return['teacher_code'] = $data['teacher_code'];
        }

        return $return;
    }
}