<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * 
 */
final class zhanmishu_video_model_coupon extends zhanmishu_video_model
{
    private static $instance = null;

    static function &instance() {
        static $object;
        if(empty($object)) {
            $object = new self();
        }
        return $object;
    }

    private function __construct(){
    }

    private function __clone(){}

    public static function getInstance(){
        //检测当前类属性$instance是否已经保存了当前类的实例
        if (self::$instance == null) {
            //如果没有,则创建当前类的实例
            self::$instance = new self();
        }
        //如果已经有了当前类实例,就直接返回,不要重复创建类实例
        return self::$instance;
    }

    public function fetch_all($start = 0, $limit = 100, $coupon = '',$field = array()) {
        $coupons = C::t("#zhanmishu_video#zhanmishu_video_coupon")->fetch_all($start, $limit, $coupon, $field);

        return $coupons;
    }

    public function fetch_num($field = array()){
        return C::t("#zhanmishu_video#zhanmishu_video_coupon")->fetch_num($field);
    }
    public function insert($data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_coupon")->insert($data, true, true);
    }
    public function useCouponCode($coupon_code = '', $cid = '', $columnid = ''){
        if (!$coupon_code) {
            return -1; // code error
        }
        global $_G;
        if (!$_G['uid']) {
            return -11; // code error
        }
        $field = array();
        $field['coupon_code'] = $coupon_code;
        $coupon = C::t("#zhanmishu_video#zhanmishu_video_coupon")->fetch_one($field);
        if (empty($coupon)) {
            return -2; // code not exists
        }else if ($coupon['isLock'] && $coupon['useUid'] != $_G['uid']) {
            return -3; // acl error
        }else if ($coupon['expire_time'] > 0 && $coupon['expire_time'] < TIMESTAMP) {
            return -4; // expire_time
        }else if ($coupon['isUsed']) {
            return -5; // isUsed
        }

        if ($cid) {
            $course = zhanmishu_video_model_course::fetch($cid);
            if (empty($course)) {
                return -6; // isUsed
            }
            // 验证是否支付购买过
            $videoHander = zhanmishu_video::getInstance();
            $ispay = $videoHander->checkuser_ispay_course($cid,$_G['uid']) ? 1 : 0;
            if ($ispay > 0) {
                return 2;
            }
            if ($coupon['coupon_price'] >= $course['course_price']) {


                $order = array();
                $order['cid'] = $cid;
                $order['uid'] = $course['uid'];
                $order['ispayed'] = '1';
                $order['isselled'] = '1';
                $order['order_type'] = '5'; // order coupon
                $order['pay_type'] = '5'; // pay coupon
                $order['course_name'] = $course['course_name'];
                $order['course_img'] = $course['course_img'];
                $order['course_intro'] = $course['course_intro'];
                $order['course_price'] = $course['course_price'];
                $order['total_fee'] = '0';
                $order['trade_no'] = $coupon['coupon_code'];
                $order['out_trade_no'] = $videoHander->get_rand_trade_no();
                $order['buyer_uid'] = $_G['uid'];
                $order['dateline'] = TIMESTAMP;
                $order['pay_time'] = TIMESTAMP;
                $order['success_time'] = TIMESTAMP;
                $order['status'] = '1';
                $order['issuccess'] = '1';

                $oid = zhanmishu_video_model_order::insert($order);
                if (!$oid) {
                    return -7;
                }
                $data = array();
                $data['useUid'] = $_G['uid'];
                $data['cid'] = $cid;
                $data['isLock'] = '1';
                $data['isUsed'] = '1';
                $data['use_time'] = TIMESTAMP;
                self::update($coupon['couponid'], $data);
                return 1;
            }
            // 兑换券不足与全额抵扣，只能以优惠价格方式
            return 3;
        }
    }

    public function delete($couponid = '') {
        if (!$couponid) {
            return false;
        }
        return C::t("#zhanmishu_video#zhanmishu_video_coupon")->delete($couponid);
    }
    public static function fetch($couponid = '', $isFormat = false){
        if (!$couponid) {
            return array();
        }
        $coupon = C::t("#zhanmishu_video#zhanmishu_video_coupon")->fetch($couponid);
        if ($isFormat) {
            if ($coupon['expire_time']) {
                $coupon['expire_time'] = ceil(($coupon['expire_time'] - TIMESTAMP) / (3600 * 24));
                $coupon['expire_time'] = $coupon['expire_time'] > 0 ? $coupon['expire_time'] : '0';
            }
            $coupon['coupon_price'] = $coupon['coupon_price'] / 100;
            $coupon['coupon_price_limit'] = $coupon['coupon_price_limit'] / 100;
        }
        return $coupon;
    }

    /**
     * @Author      Lanya      87883395@qq.com zhanmishu.com
     * @Description
     * @DateTime    2019-08-18
     * @copyright   [HereEdu!] (C)2001-2099    hereEdu       Inc
     * @param       array      $field          [搜索条件]
     * @param       string     $coupon          [搜索时排序]
     * @return      [type]                     [mix]
     */
    public function fetch_one($field = array(), $coupon = ''){
        return C::t("#zhanmishu_video#zhanmishu_video_coupon")->fetch_one($field, $coupon);
    }
    public function update($couponid= '',$data = array()) {
        return C::t("#zhanmishu_video#zhanmishu_video_coupon")->update($couponid, $data);
    }
    public function fetch_all_admin_format($start = 0, $limit = 100, $order = '',$field = array()){
        global $mpurl;
          // `couponid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
          // `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
          // `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
          // `coupon_name` varchar(256) NOT NULL DEFAULT '',
          // `coupon_price` mediumint(8) unsigned NOT NULL DEFAULT '0',
          // `coupon_price_limit` mediumint(8) unsigned NOT NULL DEFAULT '0',
          // `useUid` mediumint(8) unsigned NOT NULL DEFAULT '0',
          // `isLock` tinyint(1) unsigned NOT NULL DEFAULT '0',
          // `isUsed` tinyint(1) unsigned NOT NULL DEFAULT '0',
          // `dateline` int(10) unsigned NOT NULL DEFAULT '0',
          // `use_time` int(10) unsigned NOT NULL DEFAULT '0',
          // `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
        $coupons = self::fetch_all($start, $limit, $order, $field);
        $couponsFormat = array();
        foreach ($coupons as $key => $value) {
            $couponsFormat[$key]['couponid'] = $value['couponid'];
            // $user = getuserbyuid($value['couponuid']);
            // $couponsFormat[$key]['couponUsername'] = $user['username'];

            $couponsFormat[$key]['cid'] = $value['cid'];
            $couponsFormat[$key]['uid'] = $value['uid'];
            $couponsFormat[$key]['coupon_name'] = $value['coupon_name'];
            $couponsFormat[$key]['coupon_code'] = $value['coupon_code'];
            $couponsFormat[$key]['coupon_price'] = $value['coupon_price'] / 100;
            $couponsFormat[$key]['coupon_price_limit'] = $value['coupon_price_limit'] ? $value['coupon_price_limit'] / 100 : '';
            $couponsFormat[$key]['useUid'] = $value['useUid'];
            $couponsFormat[$key]['isLock'] = $value['isLock'];
            $couponsFormat[$key]['isUsed'] = $value['isUsed'];
            $couponsFormat[$key]['dateline'] = $value['dateline'] ? dgmdate($value['dateline']) : '';
            $couponsFormat[$key]['use_time'] = $value['use_time'] ? dgmdate($value['use_time']) : '';
            $couponsFormat[$key]['expire_time'] = $value['expire_time'] ? dgmdate($value['expire_time']) : '';

            $couponsFormat[$key]['act'] = '<a href="'.$mpurl.'&method=couponEdit&couponid='.$value['couponid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','edit').'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$mpurl.'&method=couponDelete&couponid='.$value['couponid'].'&formhash='.FORMHASH.'">'.lang('plugin/zhanmishu_video','delete').'</a>';
        }
        return $couponsFormat;
    }

    public function outputFormat($data = array()){
        global $_G;
        if (!is_array($data)) {
            return array();
        }

        $return = array();
        if ($data['cid']) {
            $return['coupon_code'] = $_G['siteurl'].'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$data['cid'].'&coupon='.$data['coupon_code'];
        }else{
            $return['coupon_code'] = $data['coupon_code'];
        }

        return $return;
    }
}