<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
$videoHander = zhanmishu_video::getInstance();

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_video&pmod=sendLogAdmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_video&pmod=sendLogAdmin';

$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
echo '<br>';
echo '<br>';


$_GET['method'] = $_GET['method'] ? $_GET['method'] : 'tagAdmin';
$pageAdminItem = array(
    'normal'=>array(
        'menu'=> array(
        ),
    )
);
zhanmishu_app_admin::importPureCss();
zhanmishu_app_admin::importJquery();
zhanmishu_app_admin::menuHorizontal($pageAdminItem['normal']['title'],$pageAdminItem['normal']['menu']);


$num = zhanmishu_video_model_notice::fetch_num();
$pages= ceil($num / $perpage);
$start = $num - ($num - $perpage*$curpage+$perpage);
$logs = zhanmishu_video_model_notice::fetch_all_admin_format($start, $perpage, 'desc', array());
showtips(lang('plugin/zhanmishu_video', 'sendLogAdmin'),'',true,lang('plugin/zhanmishu_video', ''));
showformheader($formurl.'&method=tagAdmin','enctype="multipart/form-data"');
showtableheader(); /*dism��taobao��com*/

showsubtitle(array(
    lang('plugin/zhanmishu_video', 'id'),
    lang('plugin/zhanmishu_video', 'inviteUsername'),
    lang('plugin/zhanmishu_video', 'invitedUsername'),
    lang('plugin/zhanmishu_video', 'isNotice'),
    lang('plugin/zhanmishu_video', 'isWechat'),
    lang('plugin/zhanmishu_video', 'params'),
    lang('plugin/zhanmishu_video', 'wechatStatus'),
    lang('plugin/zhanmishu_video', 'noticeStatus'),
    lang('plugin/zhanmishu_video', 'dateline'),
    lang('plugin/zhanmishu_video', 'act')
));
foreach ($logs as $key => $value) {
    showtablerow('class="partition"',array('class="td25"', 'class="td25"', 'class="td28"'),$value);
}

$multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
showtablefooter(); /*Dism_taobao-com*/
echo $multi;
showformfooter(); /*dis'.'m.tao'.'bao.com*/  