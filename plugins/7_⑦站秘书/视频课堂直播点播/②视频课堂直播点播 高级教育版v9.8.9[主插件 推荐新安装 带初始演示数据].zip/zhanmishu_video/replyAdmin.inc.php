<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

echo '<br>';
echo '<br>';
echo '<br>';
$action = $_GET['act'] ? daddslashes($_GET['act']) : 'admin';
$url = 'plugins&operation=config&identifier=zhanmishu_video&pmod=replyAdmin';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';

$mpurl=ADMINSCRIPT.'?action='.$url;
$perpage = 10;
$curpage = $_GET['page'] ? $_GET['page'] + 0 : 1;


$num = C::t("#zhanmishu_video#zhanmishu_video_reply")->fetch_num();
$pages= ceil($num / $perpage);
$start = $num - ($num - $perpage*$curpage+$perpage);
$field = array();

$replyList = C::t("#zhanmishu_video#zhanmishu_video_reply")->fetch_all($start, $perpage, 'desc', $field);

if (submitcheck('delsubmit')) {
    if (!empty($_GET['replyList'])) {
        foreach ($_GET['replyList'] as $key => $value) {
            C::t("#zhanmishu_video#zhanmishu_video_reply")->delete($value + 0);
        }

        cpmsg(lang('plugin/zhanmishu_video', 'deleteSuccess'), dreferer());
    }
}
if($replyList) {
    showformheader($url);
    showtableheader(lang('plugin/zhanmishu_video', 'replyAdmin'));
    showsubtitle(
        array(
            '', 
            lang('plugin/zhanmishu_video', 'replyAdmin'),
            lang('plugin/zhanmishu_video', 'course_name'),
            lang('plugin/zhanmishu_video', 'username'),
            lang('plugin/zhanmishu_video', 'dateline')
        )
    );

    foreach($replyList as $tid => $reply) {

        if ($reply['vid']) {
            $course = zhanmishu_video_model_video::fetch($reply['vid']);
            $reply['course_info'] = $course['video_name'];
            $reply['course_url'] = 'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$course['cid'].'&vid='.$course['vid'];
        }else if ($reply['cid']) {
            $course = zhanmishu_video_model_video::fetch($reply['cid']);
            $reply['course_info'] = $course['course_name'];
            $reply['course_url'] = 'plugin.php?id=zhanmishu_video:video&mod=video&cid='.$course['cid'];
        }

        if ($reply['uid']) {
            $user = getuserbyuid($reply['uid']);
            $reply['user_url'] = 'home.php?mod=space&uid='.$reply['uid'];
            $reply['username'] = $user['username'];
        }
        
        showtablerow('', array('class="td25"', '', '', 'class="td28"', 'class="td28"'), array(
            "<input type=\"checkbox\" class=\"checkbox\" name=\"replyList[]\" value=\"$reply[reply_id]\">",
            '<p>'.$reply['reply_comment'].'</p>',
            '<a href="'.$reply['course_url'].'" target="_blank">'.$reply['course_info'].'</a>',
            '<a href="'.$reply['user_url'].'" target="_blank">'.$reply['username'].'</a>',
            '<a href="home.php?mod=space&uid='.$reply['uid'].'" target="_blank">'.$reply['author'].'</a><br /><em style="font-size:9px;color:#999999;">'.dgmdate($reply['dateline'], 'd').'</em>'
        ));
    }
    
       
    $multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
    showsubmit('', '', '', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'replyList\')" /><label for="chkall">'.cplang('select_all').'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="delsubmit" value="'.cplang('recyclebin_delete').'" />&nbsp;', $multi);
    showtablefooter(); /*Dism_taobao-com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
}

