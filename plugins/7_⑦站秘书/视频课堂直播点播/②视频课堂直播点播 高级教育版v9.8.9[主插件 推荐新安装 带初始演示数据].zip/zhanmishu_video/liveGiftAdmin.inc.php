<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/function/common_function.php';
$videoHander = zhanmishu_video::getInstance();
$url = 'plugins&operation=config&identifier=zhanmishu_video&pmod=liveGiftAdmin';
$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_video&pmod=liveGiftAdmin';
$action = $_GET['act'] ? daddslashes($_GET['act']) : 'rewardLog';

$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
$pages= ceil($num / $perpage);
$start = $num - ($num - $perpage*$curpage+$perpage);
echo '<br>';
echo '<br>';

$formurl = 'plugins&operation=config&identifier=zhanmishu_video&pmod=liveGiftAdmin';
zms_showtitle(lang('plugin/zhanmishu_video', 'course_admin'),array(
    $addarray,
    array(lang('plugin/zhanmishu_video', 'giftSetting'),$url.'&act=giftSetting',$status = $action =='giftSetting'?'1':'0'),
    array(lang('plugin/zhanmishu_video', 'rewardSetting'),$url.'&act=rewardSetting',$status = $action =='rewardSetting'?'1':'0'),
    array(lang('plugin/zhanmishu_video', 'rewardLog'),$url.'&act=rewardLog',$status = $action =='rewardLog'?'1':'0')
));

if (submitcheck('gift_listAdmin')) {
    $videoHander->writetocache('isGift', $_GET['isGift'] + 0);
    $gift_list = array();
    foreach ($_GET['gift_name'] as $key => $value) {
        if (!$value || in_array($key, $_GET['delete'])) {
            continue;
        }
        $gift_list[] = array(
            'order'=>$_GET['order'][$key],
            'gift_name'=>$_GET['gift_name'][$key],
            'gift_icon'=>$_GET['gift_icon'][$key],
            'gift_score'=>$_GET['gift_score'][$key]
        );
    }
    $videoHander->updatecache();
    $videoHander->update_gift_listcache_init($gift_list);


    cpmsg(lang('plugin/zhanmishu_video', 'update_gift_list_success'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=liveGiftAdmin&act=giftSetting','success');


}else if (submitcheck('reward_listAdmin')) {
    $videoHander->writetocache('isReward', $_GET['isReward'] + 0);
    $videoHander->updatecache();
    $reward_list = array();
    foreach ($_GET['reward_score'] as $key => $value) {
        if (!$value || in_array($key, $_GET['reward_delete'])) {
            continue;
        }
        $reward_list[] = array(
            'order'=>$_GET['reward_order'][$key],
            'reward_score'=>$_GET['reward_score'][$key]
        );
    }
    $videoHander->update_reward_listcache_init($reward_list);
    
    cpmsg(lang('plugin/zhanmishu_video', 'update_gift_list_success'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=liveGiftAdmin&act=rewardSetting','success');

}else if ($action == 'rewardLog') {
    $mpurl=ADMINSCRIPT.'?action='.$url.'&act='.$action;
    $field = array();
    $query = array();
    $query['out_trade_no'] = $_GET['out_trade_no'];
    $query['orderstatus'] = $_GET['orderstatus'];
    $query['course_column_name'] = $_GET['course_column_name'];
    $query['course_name'] = $_GET['course_name'];

    $mpurl .= '&'.http_build_query($query);

    if ($_GET['out_trade_no']) {
        $field['out_trade_no'] = daddslashes($_GET['out_trade_no']);
    }
    if ($_GET['orderstatus'] == '1') {
        $field['ispayed'] = '0';
    }else if ($_GET['orderstatus'] == '2') {
        $field['ispayed'] =  '1';
    }

    if ($_GET['cid']) {
        $field['cid'] = $_GET['cid'] + 0;
    }
    if ($_GET['course_teacher']) {
        if (is_numeric($_GET['course_teacher'])) {
            $field['uid'] = $_GET['course_teacher'] + 0;
        }else{
            $course_teacher = daddslashes($_GET['course_teacher']);
            loaducenter();
            if($data = uc_get_user($course_teacher)) {
                list($uid, $username, $email) = $data;
            } else {
                cpmsg(lang('plugin/zhanmishu_video', 'course_teacher_isnot_exists'),'','error');
            }
            $field['uid'] = $uid;
        }
    }
    if ($_GET['present_username']) {
        if (is_numeric($_GET['present_username'])) {
            $field['present_uid'] = $_GET['present_username'] + 0;
        }else{
            $present_username = daddslashes($_GET['present_username']);
            loaducenter();
            if($data = uc_get_user($present_username)) {
                list($present_uid, $username, $email) = $data;
            } else {
                cpmsg(lang('plugin/zhanmishu_video', 'present_username_isnot_exists'),'','error');
            }
            $field['present_uid'] = $present_uid;
        }
    }

    $num = zhanmishu_video_model_reward::fetch_num($field);
    $rewards = zhanmishu_video_model_reward::fetch_all_admin_format($start,$perpage,'desc', $field);
    
    $total_fee = C::t("#zhanmishu_video#zhanmishu_video_reward")->fetch_sum('total_fee', $field);

    showtableheader(); /*dism��taobao��com*/
    showformheader('plugins&operation=config&identifier=zhanmishu_video&pmod=liveGiftAdmin&act='.$action);
    $_G['showsetting_multirow'] = 1;
    $_G['showsetting_multirow_n'] = 0;
    showsetting(
        lang('plugin/zhanmishu_video','orderstatus'), 
        array('orderstatus', array(
            array('', lang('plugin/zhanmishu_video', 'all')),
            array(1, lang('plugin/zhanmishu_video', 'none_pay')),
            array(2, lang('plugin/zhanmishu_video', 'success'))
            )
        ), intval($_GET['orderstatus']), 'select');
    showsetting(lang('plugin/zhanmishu_video', 'out_trade_no'), 'out_trade_no', $_GET['out_trade_no'], 'text');
    showsetting(lang('plugin/zhanmishu_video', 'cid'), 'cid', $_GET['cid'], 'text');
    showsetting(lang('plugin/zhanmishu_video', 'reward_course_teacher'), 'course_teacher', $_GET['course_teacher'], 'text');
    showsetting(lang('plugin/zhanmishu_video', 'present_username'), 'present_username', $_GET['present_username'], 'text');

    showsubmit('searchsubmit', lang('plugin/zhanmishu_video', 'searchsubmit'));
    showtablefooter(); /*Dism_taobao-com*/

    showtableheader(lang('plugin/zhanmishu_video', 'total_fee_sum', array('total_fee'=>$total_fee / 100)));
    showsubtitle(array(
        lang('plugin/zhanmishu_video', 'rid'),
        lang('plugin/zhanmishu_video', 'cid'),
        lang('plugin/zhanmishu_video', 'vid'),
        lang('plugin/zhanmishu_video', 'teacher_name'),
        lang('plugin/zhanmishu_video', 'present_username'),
        lang('plugin/zhanmishu_video', 'reward_total_fee'),
        lang('plugin/zhanmishu_video', 'ispayed'),
        lang('plugin/zhanmishu_video', 'out_trade_no'),
        lang('plugin/zhanmishu_video', 'dateline'),
        ));
        foreach ($rewards as $key => $value) {
            showtablerow('class="partition"',array('class="td15"', 'class="td28"'),$value);
        }
    showtablefooter(); /*Dism_taobao-com*/

    $multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
    echo $multi;
    showtableheader(); /*dism��taobao��com*/
    showtablefooter(); /*Dism_taobao-com*/
}else if ($action == 'giftSetting'){

        $gift_list = $videoHander->get_gift_list();
        $isGift = $videoHander->GetFromCache('isGift');
        showformheader($formurl,'enctype="multipart/form-data"');
        showtableheader(lang('plugin/zhanmishu_video','giftSetting'));
        showsetting(
            lang('plugin/zhanmishu_video','isGift'), 
            array('isGift', array(
                array(0, lang('plugin/zhanmishu_video', 'close')),
                array(1, lang('plugin/zhanmishu_video', 'open')),
                )
            ), $isGift, 'mradio','','', lang('plugin/zhanmishu_video', 'isGiftTips'));
        showtablefooter(); /*Dism_taobao-com*/

        showtableheader(lang('plugin/zhanmishu_video','gift_list'));
        showsubtitle(array(
            lang('plugin/zhanmishu_video', 'delete'),
            lang('plugin/zhanmishu_video', 'order'),
            lang('plugin/zhanmishu_video', 'gift_list_name'),
            lang('plugin/zhanmishu_video', 'gift_icon'),
            lang('plugin/zhanmishu_video', 'gift_score')
        ));

        foreach ($gift_list as $key => $value) {
            $value['id'] = $key;
                $videoHanderarr = array(
                '<input type="checkbox" class="txt" name="delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                '<input type="text" class="txt" name="order['.$value['id'].']" value="'.$value['order'].'" />',
                '<input type="text" class="txt" name="gift_name['.$value['id'].']" value="'.$value['gift_name'].'" />',
                '<input type="text"  name="gift_icon['.$value['id'].']" value="'.$value['gift_icon'].'" />',
                '<input type="text"  name="gift_score['.$value['id'].']" value="'.$value['gift_score'].'" />',
            );
            showtablerow('',array('class="td25"', 'class="td25"', 'class="td22"', 'class="td22"', 'class="td22"'), $videoHanderarr);

        }
        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 0);" class=" addtr">'.lang('plugin/zhanmishu_video', 'addgift_list').'</a></div></tr>';


        showsubmit('gift_listAdmin',lang('plugin/zhanmishu_video', 'submit'));

        showtablefooter(); /*Dism_taobao-com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/   

    $moneyunit = ' '.lang('plugin/zhanmishu_video','moneyunit');
    echo <<<EOT
    <script type="text/JavaScript">
        var rowtypedata = [
            [
                [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                [1,'<input type="text" class="txt" name="order[]" value="">', 'td25'],
                [1,'<input type="text" class="txt" name="gift_name[]" value="">', 'td22'],
                [1,'<input type="text" class="" name="gift_icon[]" value="">', 'td22'],
                [1,'<input type="text" class="" name="gift_score[]" value="">', 'td22'],

            ],
            [
                [1,'<input type="checkbox" class="txt" name="reward_deldete[]" value="">', 'td25'],
                [1,'<input type="text" class="txt" name="reward_order[]" value="">', 'td25'],
                [1,'<input type="text" class="" name="reward_score[]" value="">{$moneyunit}', 'td25'],

            ]
            
        ];
    </script>
EOT;


}else if ($action == 'rewardSetting'){
        $reward_list = $videoHander->get_reward_list();
        $isReward = $videoHander->GetFromCache('isReward');
        showformheader($formurl,'enctype="multipart/form-data"');

        showtableheader(lang('plugin/zhanmishu_video','rewardSetting'));
        showsetting(
            lang('plugin/zhanmishu_video','isReward'), 
            array('isReward', array(
                array(0, lang('plugin/zhanmishu_video', 'close')),
                array(1, lang('plugin/zhanmishu_video', 'open')),
                )
            ), $isReward, 'mradio','','', lang('plugin/zhanmishu_video', 'isRewardTips'));
        showtablefooter(); /*Dism_taobao-com*/

        showtableheader(lang('plugin/zhanmishu_video','reward_list'));

        showsubtitle(array(
            lang('plugin/zhanmishu_video', 'delete'),
            lang('plugin/zhanmishu_video', 'order'),
            lang('plugin/zhanmishu_video', 'reward_score')
        ));
        foreach ($reward_list as $key => $value) {
            $value['id'] = $key;
                $videoHanderarr = array(
                '<input type="checkbox" class="txt" name="reward_delete['.$value['id'].']" value="'.$value['id'].'" '.$protected.' />',
                '<input type="text" class="txt" name="reward_order['.$value['id'].']" value="'.$value['order'].'" />',
                '<input type="text"  name="reward_score['.$value['id'].']" value="'.$value['reward_score'].'" /> '.lang('plugin/zhanmishu_video','moneyunit'),
            );
            showtablerow('',array('class="td25"', 'class="td25"', 'class="td25"'), $videoHanderarr);

        }
        echo '<tr><td colspan="2"><div class="lastboard"><a href="###" onclick="addrow(this, 1);" class=" addtr">'.lang('plugin/zhanmishu_video', 'addreward_list').'</a></div></tr>';

        showsubmit('reward_listAdmin',lang('plugin/zhanmishu_video', 'submit'));

        showtablefooter(); /*Dism_taobao-com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/   

    $moneyunit = ' '.lang('plugin/zhanmishu_video','moneyunit');
    echo <<<EOT
    <script type="text/JavaScript">
        var rowtypedata = [
            [
                [1,'<input type="checkbox" class="txt" name="deldete[]" value="">', 'td25'],
                [1,'<input type="text" class="txt" name="order[]" value="">', 'td25'],
                [1,'<input type="text" class="txt" name="gift_name[]" value="">', 'td22'],
                [1,'<input type="text" class="" name="gift_icon[]" value="">', 'td22'],
                [1,'<input type="text" class="" name="gift_score[]" value="">', 'td22'],

            ],
            [
                [1,'<input type="checkbox" class="txt" name="reward_deldete[]" value="">', 'td25'],
                [1,'<input type="text" class="txt" name="reward_order[]" value="">', 'td25'],
                [1,'<input type="text" class="" name="reward_score[]" value="">{$moneyunit}', 'td25'],

            ]
            
        ];
    </script>
EOT;

    



}
//dis'.'m.tao'.'bao.com
?>