<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
  exit('Access Denied');
}

/**
 * course_price_type  表示价格类型 0表示普通  1表示密码播放，2、表示内部课程
 */

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_course (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cat_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `diff` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ProfileID` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `yourproductid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `progress` tinyint(1) NOT NULL DEFAULT '1',
  `issell` tinyint(1) NOT NULL DEFAULT '1',
  `drmnums` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `islive` tinyint(1) NOT NULL DEFAULT '0',
  `isdel` tinyint(1) NOT NULL DEFAULT '0',
  `isGift` tinyint(1) NOT NULL DEFAULT '1',
  `isReward` tinyint(1) NOT NULL DEFAULT '1',
  `course_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `course_price_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `course_password`  varchar(100) NOT NULL DEFAULT '',
  `course_password_content` varchar(3000) NOT NULL DEFAULT '',
  `course_notice` varchar(3000) NOT NULL DEFAULT '',
  `selltimes` smallint(3) NOT NULL DEFAULT '0',
  `videos` smallint(3) NOT NULL DEFAULT '0',
  `course_weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `views` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `score` smallint(3) NOT NULL DEFAULT '0',
  `views_add` mediumint(8)  NOT NULL DEFAULT '0',
  `learns` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `replies` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `learns_add` mediumint(8)  NOT NULL DEFAULT '0',
  `course_name` varchar(156) NOT NULL DEFAULT '',
  `course_img` varchar(100) NOT NULL DEFAULT '',
  `course_thumbimg` varchar(100) NOT NULL DEFAULT '',
  `course_intro` varchar(255) NOT NULL DEFAULT '',
  `course_content` mediumtext NOT NULL,
  `course_group` varchar(255) NOT NULL DEFAULT '',
  `visiable_group` varchar(255) NOT NULL DEFAULT '',
  `live_url` varchar(1000) NOT NULL DEFAULT '',
  `course_price` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `course_length` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `site_sign_img1` varchar(100) NOT NULL DEFAULT '',
  `site_sign_img2` varchar(100) NOT NULL DEFAULT '',
  `fileurl` varchar(1000) NOT NULL DEFAULT '',
  `baiduurl` varchar(1000) NOT NULL DEFAULT '',
  `baiduurlpwd` varchar(20) NOT NULL DEFAULT '',
  `360url` varchar(100) NOT NULL DEFAULT '',
  `360urlpwd` varchar(100) NOT NULL DEFAULT '',
  `rarpwd` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (cid),
  KEY dateline (dateline),
  KEY uid (uid),
  KEY views (views),
  KEY selltimes (selltimes),
  KEY cat_id (cat_id),
  KEY learns (learns),
  KEY course_name (course_name),
  KEY course_group (course_group),
  KEY visiable_group (visiable_group),
  KEY ProfileID (ProfileID),
  KEY course_price (course_price)
);
CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_course_column (
  `columnid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `issell` tinyint(1) NOT NULL DEFAULT '1',
  `isdel` tinyint(1) NOT NULL DEFAULT '0',
  `selltimes` smallint(3) NOT NULL DEFAULT '0',
  `courseids` varchar(1000) NOT NULL DEFAULT '',
  `courses` smallint(3) NOT NULL DEFAULT '0',
  `videos` smallint(3) NOT NULL DEFAULT '0',
  `course_column_weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `views` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `views_add` mediumint(8)  NOT NULL DEFAULT '0',
  `learns` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `learns_add` mediumint(8)  NOT NULL DEFAULT '0',
  `replies` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `course_column_name` varchar(156) NOT NULL DEFAULT '',
  `course_column_img` varchar(100) NOT NULL DEFAULT '',
  `course_column_thumbimg` varchar(100) NOT NULL DEFAULT '',
  `course_column_intro` varchar(255) NOT NULL DEFAULT '',
  `course_column_content` mediumtext NOT NULL,
  `course_column_group` varchar(255) NOT NULL DEFAULT '',
  `course_column_price` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `course_column_length` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (columnid),
  KEY dateline (dateline),
  KEY uid (uid),
  KEY views (views),
  KEY selltimes (selltimes),
  KEY learns (learns),
  KEY course_column_name (course_column_name),
  KEY course_column_group (course_column_group),
  KEY course_column_price (course_column_price)
);
CREATE TABLE IF NOT EXISTS pre_zhanmishu_video (
  `vid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cat_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `video_length` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `isfree` tinyint(1) NOT NULL DEFAULT '1',
  `isdel` tinyint(1) NOT NULL DEFAULT '0',
  `islive` tinyint(1) NOT NULL DEFAULT '0',
  `is_rsa` tinyint(1) NOT NULL DEFAULT '0',
  `layout` tinyint(1) NOT NULL DEFAULT '0',
  `is_chapter` tinyint(1) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `parent_vid` mediumint(8) unsigned NOT NULL,
  `sort` smallint(3) NOT NULL DEFAULT '0',
  `isrecord` tinyint(1) NOT NULL DEFAULT '0',
  `record_liveid` mediumint(8) unsigned NOT NULL,
  `ismusic` tinyint(1) NOT NULL DEFAULT '0',
  `istranscoding` tinyint(1) NOT NULL DEFAULT '0',
  `selltimes` smallint(3) NOT NULL DEFAULT '0',
  `video_name` varchar(156) NOT NULL DEFAULT '',
  `transcodingid` varchar(56) NOT NULL DEFAULT '',
  `video_img` varchar(100) NOT NULL DEFAULT '',
  `video_url`  varchar(1000) NOT NULL DEFAULT '',
  `video_urltype` tinyint(1) NOT NULL DEFAULT '0',
  `livestatus` tinyint(1) NOT NULL DEFAULT '0',
  `video_intro` mediumtext NOT NULL,
  `video_price` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `start_time` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (vid),
  KEY dateline (dateline),
  KEY uid (uid),
  KEY cid (cid),
  KEY video_name (video_name),
  KEY start_time (start_time),
  KEY video_price (video_price)
);
CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_order (
  `oid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `columnid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ispayed` tinyint(1) NOT NULL DEFAULT '0',
  `isselled` tinyint(1) NOT NULL DEFAULT '0',
  `order_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pay_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` smallint(3) NOT NULL DEFAULT '0',
  `course_name` varchar(156) NOT NULL DEFAULT '',
  `course_img` varchar(100) NOT NULL DEFAULT '',
  `course_intro` varchar(255) NOT NULL DEFAULT '',
  `course_price` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `course_column_name` varchar(156) NOT NULL DEFAULT '',
  `course_column_price` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `course_column_intro` varchar(156) NOT NULL DEFAULT '',
  `course_column_img` varchar(156) NOT NULL DEFAULT '',
  `total_fee` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `video_name` varchar(156) NOT NULL DEFAULT '',
  `video_img` varchar(100) NOT NULL DEFAULT '',
  `video_intro` varchar(255) NOT NULL DEFAULT '',
  `video_price` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `buyer_email` varchar(20) NOT NULL DEFAULT '',
  `trade_no` varchar(40) NOT NULL DEFAULT '',
  `out_trade_no` varchar(40) NOT NULL DEFAULT '',
  `buyer_mobile` varchar(12) NOT NULL DEFAULT '',
  `buyer_uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `playcount` smallint(3) unsigned NOT NULL DEFAULT '0',
  `pay_time` int(10) unsigned NOT NULL DEFAULT '0',
  `sign_time` int(10) unsigned NOT NULL DEFAULT '0',
  `confirm_time` int(10) unsigned NOT NULL DEFAULT '0',
  `success_time` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issign` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isconfirm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ismail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issuccess` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isclosed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sign_img1` varchar(100) NOT NULL DEFAULT '',
  `sign_img2` varchar(100) NOT NULL DEFAULT '',
  `sign_img3` varchar(100) NOT NULL DEFAULT '',
  `device` varchar(1000) NOT NULL DEFAULT '',
  PRIMARY KEY (oid),
  KEY cid (cid),
  KEY uid (uid),
  KEY vid (vid),
  KEY buyer_uid (buyer_uid),
  KEY total_fee (total_fee),
  KEY out_trade_no (out_trade_no),
  KEY trade_no (trade_no)
);
CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_cat (
  `cat_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `cat_icon` varchar(1000) NOT NULL DEFAULT '',
  `cat_touchorder`  smallint(3) unsigned NOT NULL DEFAULT '0',
  `isdel` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cat_name` varchar(156) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (cat_id),
  KEY dateline (dateline),
  KEY cat_touchorder (cat_touchorder),
  KEY sortselect (sort),
  KEY cat_name (cat_name)
);
CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_autho (
  `aid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `columnid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `oid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `device` varchar(80) NOT NULL DEFAULT '',
  `isautho` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `nums` varchar(156) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `ip1` smallint(3) NOT NULL default '0',
  `ip2` smallint(3) NOT NULL default '0',
  `ip3` smallint(3) NOT NULL default '0',
  `ip4` smallint(3) NOT NULL default '0',
  `authority_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (aid),
  KEY dateline (dateline),
  KEY columnid (columnid),
  KEY cid (cid),
  KEY device (device)
);

CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_reply (
  `reply_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `islive` tinyint(1) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `isdel` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `score` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isforbid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reply_comment` varchar(2000) NOT NULL DEFAULT '',
  `views` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `praises` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (reply_id),
  KEY dateline (dateline),
  KEY parent_id (parent_id),
  KEY cid (cid),
  KEY vid (vid),
  KEY uid (uid),
  KEY reply_uid (reply_uid)
);
CREATE TABLE IF NOT EXISTS pre_zhanmishu_teacher_info (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `teacher_name` varchar(127) NOT NULL DEFAULT '',
  `teacher_img` varchar(1000) NOT NULL DEFAULT '',
  `teacher_helper_ids` varchar(1000) NOT NULL DEFAULT '',
  `teacher_per` float(7,3) unsigned NOT NULL DEFAULT '0.00',
  `teacher_intro` varchar(1000) NOT NULL DEFAULT '',
  `teacher_content` mediumtext NOT NULL,
  `score` smallint(3) NOT NULL DEFAULT '0',
  `replies` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `scores` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `course_num` smallint(3) NOT NULL DEFAULT '0',
  `videos_num` smallint(3) NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (uid),
  KEY teacher_name (teacher_name),
  KEY dateline (dateline)
);
CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_gift (
  `gid` mediumint(8)  unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `present_uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `present_username` varchar(127) NOT NULL DEFAULT '',
  `teacher_name` varchar(127) NOT NULL DEFAULT '',
  `gift_name` varchar(127) NOT NULL DEFAULT '',
  `gift_icon` varchar(127) NOT NULL DEFAULT '',
  `gift_score` smallint(3) NOT NULL DEFAULT '0',
  `credits_type` smallint(3) NOT NULL DEFAULT '0',
  `num` smallint(3) NOT NULL DEFAULT '0',
  `total_score` smallint(3) NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (gid),
  KEY uid (uid),
  KEY present_uid (present_uid),
  KEY present_username (present_username),
  KEY teacher_name (teacher_name),
  KEY dateline (dateline)
);
CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_reward (
  `rid` mediumint(8)  unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `present_uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `present_username` varchar(127) NOT NULL DEFAULT '',
  `teacher_name` varchar(127) NOT NULL DEFAULT '',
  `total_fee` smallint(3) NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `out_trade_no` varchar(40) NOT NULL DEFAULT '',
  `ispayed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issuccess` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (rid),
  KEY uid (uid),
  KEY present_uid (present_uid),
  KEY present_username (present_username),
  KEY teacher_name (teacher_name),
  KEY out_trade_no (out_trade_no),
  KEY dateline (dateline)
);

CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_record (
  `record_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `duration` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seek` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (record_id),
  KEY dateline (dateline),
  KEY cid (cid),
  KEY vid (vid),
  KEY uid (uid)
);

CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_coupon (
  `couponid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `coupon_name` varchar(256) NOT NULL DEFAULT '',
  `coupon_code` varchar(256) NOT NULL DEFAULT '',
  `coupon_price` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `coupon_number` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `coupon_price_limit` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `useUid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `isLock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isUsed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `use_time` int(10) unsigned NOT NULL DEFAULT '0',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (couponid),
  KEY coupon_code (coupon_code),
  KEY dateline (dateline),
  KEY use_time (use_time),
  KEY expire_time (expire_time),
  KEY cid (cid),
  KEY uid (uid),
  KEY useUid (useUid)
);

CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_notice (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `inviteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `inviteuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `inviteduid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `isSms` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isEmail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isWechat` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isNotice` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `params` varchar(2000) NOT NULL DEFAULT '',
  `smsStatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `wechatStatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `emailStatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `noticeStatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `isdel` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (id),
  KEY inviteid (inviteid),
  KEY inviteuid (inviteuid),
  KEY inviteduid (inviteduid),
  KEY cid (cid),
  KEY vid (vid),
  KEY tid (tid),
  KEY dateline (dateline)
);

CREATE TABLE IF NOT EXISTS pre_zhanmishu_video_goods (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `onsell` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `goods_name` varchar(1000) NOT NULL DEFAULT '',
  `goods_img` varchar(1000) NOT NULL DEFAULT '',
  `path` varchar(1000) NOT NULL DEFAULT '',
  `url` varchar(1000) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (id),
  KEY cid (cid),
  KEY vid (vid),
  KEY uid (uid),
  KEY dateline (dateline)
);
INSERT INTO pre_zhanmishu_teacher_info VALUES ('1',0x61646d696e,'',0x32,'70.000',0xbdcccaa6bcf2bde9,0xcfeacfb8bde9c9dc,'0','0','0','1','1','1624350575');
INSERT INTO pre_zhanmishu_video VALUES ('1','1','1','0','3600','1','0','0','0','0','0','0','0','32767','0','16777215','127','4','0',0xcad3c6b5c3fbb3c6,'0',0x68747470733a2f2f7777772e7a68616e6d697368752e636f6d2f646174612f6174746163686d656e742f7a68616e6d697368755f766964656f2f69757a766e6f657033323130342e6a7067,0x3c696672616d65206865696768743d313030252077696474683d31303025207372633d5c27687474703a2f2f706c617965722e796f756b752e636f6d2f656d6265642f584e4441794d7a59304d5455344f413d3d5c27206672616d65626f726465723d30205c27616c6c6f7766756c6c73637265656e5c273e3c2f696672616d653e,'4','0',0xb1bebddacad3c6b5cfeacfb8bde9c9dc,'0','0','1624350105');
INSERT INTO pre_zhanmishu_video_cat VALUES ('1','0','0','0','','0','0',0x4954a1a4bba5c1aacdf8,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('2','0','0','0','','0','0',0xc9e8bcc6a1a4b4b4d7f7,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('3','0','0','0','','0','0',0xb5e7c9cca1a4d3aacffa,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('4','0','0','0','','0','0',0xd6b0d2b5a1a4bfbcd6a4,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('5','1','0','1','','0','0',0xc7b0b6cbbfaab7a2,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('6','1','0','1','','0','0',0x4a617661,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('7','2','0','1','','0','0',0xc6bdc3e6c9e8bcc6,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('8','2','0','1','','0','0',0xcad0c4dac9e8bcc6,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('9','3','0','1','','0','0',0xb5e7c9ccc6bdcca8,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('10','3','0','1','','0','0',0xc9e7bdbbb5e7c9cc,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('11','4','0','1','','0','0',0xb9abcef1d4b1,'1624344395');
INSERT INTO pre_zhanmishu_video_cat VALUES ('12','4','0','1','','0','0',0xbda8d6feb9a4b3cc,'1624344395');
INSERT INTO pre_zhanmishu_video_course VALUES ('1','1','1','1','0','0','4','1','0','0','0','0','0','0','9',0x3433,'0','0','0','1','1','1022','32767','-8388608','0','1','-8388485',0xbfceb3ccc3fbb3c6,0x68747470733a2f2f7777772e7a68616e6d697368752e636f6d2f646174612f6174746163686d656e742f7a68616e6d697368755f766964656f7564776f7972697136383034332e706e67,0x33363030,0xcfeacfb8c3e8caf6,0xd5e2c0efcac7bfceb3ccbde9c9dc,0x31302c31312c31322c31332c31342c31352c31362c31372c31382c31392c312c322c33,0x68747470733a2f2f7777772e7a68616e6d697368752e636f6d2f646f632f,'','10','3600','1624350486',0x68747470733a2f2f7777772e7a68616e6d697368752e636f6d2f646174612f6174746163686d656e742f7a68616e6d697368755f766964656f7564776f7972697136383034332e706e67,0x68747470733a2f2f7777772e7a68616e6d697368752e636f6d2f646174612f6174746163686d656e742f7a68616e6d697368755f766964656f7564776f7972697136383034332e706e67,0x68747470733a2f2f7777772e7a68616e6d697368752e636f6d2f646f632f,0x68747470733a2f2f7777772e7a68616e6d697368752e636f6d2f646f632f,0x313233,'','0',0x31);
INSERT INTO pre_zhanmishu_video_reply VALUES ('1','0','1','0','1','0','0','0','0','0','0',0xb2e2cad4c6c0c2db,'0','0','1624349857');
EOF;

runquery($sql);

$pluginId = 'zhanmishu_video';
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'.xml');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/install.php');
$finish = TRUE;
?>