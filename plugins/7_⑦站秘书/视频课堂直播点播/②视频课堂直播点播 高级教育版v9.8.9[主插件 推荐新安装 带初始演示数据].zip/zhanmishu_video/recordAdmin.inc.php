<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_video/source/Autoloader.php';
$videoHander = zhanmishu_video::getInstance();

$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=zhanmishu_video&pmod=recordAdmin';
$formurl = 'plugins&operation=config&identifier=zhanmishu_video&pmod=recordAdmin';

$perpage=20;
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
echo '<br>';
echo '<br>';


$_GET['method'] = $_GET['method'] ? $_GET['method'] : 'recordAdmin';
$pageAdminItem = array(
    'normal'=>array(
        'menu'=> array(
            array(
                'title'=>lang('plugin/zhanmishu_video','recordAdminEdit'),
                'link'=>$mpurl.'&method=recordAdminEdit',
                'selected'=> $_GET['method'] == 'recordAdminEdit' ? 'selected' : ''
            ),
            array(
                'title'=>lang('plugin/zhanmishu_video','recordAdmin'),
                'link'=>$mpurl.'&method=recordAdmin',
                'selected'=> $_GET['method'] == 'recordAdmin' ? 'selected' : ''
            )
        ),
    )
);
zhanmishu_app_admin::importPureCss();
zhanmishu_app_admin::importJquery();
zhanmishu_app_admin::menuHorizontal($pageAdminItem['normal']['title'],$pageAdminItem['normal']['menu']);

if ($_GET['method'] == 'recordAdmin') {

    $field = array();
    if ($_GET['cid'] > 0) {
        $field['cid'] = $_GET['cid'] + 0;
    }
    if ($_GET['useUid']) {
        $field['useUid'] = $_GET['useUid'] + 0;
    }
    if ($_GET['isUsed'] > 0) {
        $field['isUsed'] = $_GET['isUsed'] == 2 ? 1 : 0;
    }
    if ($_GET['recordAdmin_code']) {
        $field['recordAdmin_code'] = daddslashes($_GET['recordAdmin_code']);
    }

    $num = zhanmishu_video_model_record::fetch_num($field);
    $pages= ceil($num / $perpage);
    $start = $num - ($num - $perpage*$curpage+$perpage);
    $recordAdmins = zhanmishu_video_model_record::fetch_all_admin_format($start, $perpage, 'desc', $field);

    if (submitcheck('outputsubmit')) {
        ob_end_clean();
        set_time_limit(0);
        $fileName = 'recordAdmin-'.TIMESTAMP;
        header('Content-Encoding: none');
        header('Content-Type: application/vnd.ms-excel');   //header设置
        header("Content-Disposition: attachment;filename=".$fileName.".csv");
        header('Cache-Control: max-age=0');

        $fp = fopen('php://output','a');    //打开php文件句柄，php://output表示直接输出到PHP缓存,a表示将输出的内容追加到文件末尾
        
        for ($i=0; $i < $pages; $i++) {
            if ($i == 0) {
                foreach ($recordAdmins as $key => $value) {
                    if (is_array($value)) {
                         fputcsv($fp, zhanmishu_video::auto_charset_change(zhanmishu_video_model_record::outputFormat($value), CHARSET, 'gbk'));
                    }
                }
            }else{
                $starti = $num - ($num - $perpage*($i + 1)+$perpage);
                $recordAdminsi = zhanmishu_video_model_record::fetch_all_admin_format($starti, $perpage, 'desc', $field);
                foreach ($recordAdminsi as $key => $value) {
                    if (is_array($value)) {
                         fputcsv($fp, zhanmishu_video::auto_charset_change(zhanmishu_video_model_record::outputFormat($value), CHARSET, 'gbk'));
                    }
                }
            }
        }
        exit();
    }

    showtips(lang('plugin/zhanmishu_video', 'recordAdminTips'),'',true,lang('plugin/zhanmishu_video', 'recordAdminTipsTitle'));

    showtableheader(); /*dism·taobao·com*/

    showformheader('plugins&operation=config&identifier=zhanmishu_video&pmod=recordAdmin&method=recordAdmin');
    $_G['showsetting_multirow'] = 1;
    $_G['showsetting_multirow_n'] = 0;
    showsetting(
        lang('plugin/zhanmishu_video','isUsed'), 
        array('isUsed', array(
            array(0, lang('plugin/zhanmishu_video', 'all')),
            array(1, lang('plugin/zhanmishu_video', 'isUsed_0')),
            array(2, lang('plugin/zhanmishu_video', 'isUsed_1'))
            )
        ), $_GET['isUsed'], 'select');
    showsetting(lang('plugin/zhanmishu_video', 'cid_limit'), 'cid', $_GET['cid'], 'text');
    showsetting(lang('plugin/zhanmishu_video', 'useUid_limit'), 'useUid', $_GET['useUid'], 'text');
    showsubmit('searchsubmit', lang('plugin/zhanmishu_video', 'searchsubmit'));
    showtablefooter(); /*Dism_taobao-com*/


    showformheader($formurl.'&method=recordAdmin','enctype="multipart/form-data"');
    showtableheader(lang('plugin/zhanmishu_video','index_item_intro'));
    showsubtitle(array(
        lang('plugin/zhanmishu_video', 'record_id'),
        lang('plugin/zhanmishu_video', 'username'),
        lang('plugin/zhanmishu_video', 'cid'),
        lang('plugin/zhanmishu_video', 'vid'),
        lang('plugin/zhanmishu_video', 'duration'),
        lang('plugin/zhanmishu_video', 'seek'),
        lang('plugin/zhanmishu_video', 'dateline'),
        lang('plugin/zhanmishu_video', 'act')
    ));
    foreach ($recordAdmins as $key => $value) {
        showtablerow('class="partition"',array('class="td25"', 'class="td25"', 'class="td28"'),$value);
    }

    $multi = multi($num, $perpage, $curpage, $mpurl, '0', '10');
    showtablefooter(); /*Dism_taobao-com*/
    echo $multi;
    showsubmit('outputsubmit', lang('plugin/zhanmishu_video', 'output', array('number'=>$num)));
    showformfooter(); /*dis'.'m.tao'.'bao.com*/  
}else if ($_GET['method'] == 'recordDelete') {
    if ($_GET['formhash'] == formhash()) {
        $recordAdmin = zhanmishu_video_model_record::delete($_GET['record_id'] + 0);
        cpmsg(lang('plugin/zhanmishu_video', 'success'),dreferer(),'success');
    }
}else if ($_GET['method'] == 'recordEdit') {
    if (submitcheck('editrecordAdminSubmit')) {    

    
        cpmsg(lang('plugin/zhanmishu_video', 'success'),'action=plugins&operation=config&identifier=zhanmishu_video&pmod=recordAdmin&method=recordAdmin','success');
    }

    if ($_GET['record_id']) {
        $recordAdmin = zhanmishu_video_model_record::fetch($_GET['record_id'] + 0, true);
    }
    showformheader($formurl.'&method=recordAdminEdit','enctype="multipart/form-data"');
    showtableheader(); /*dism·taobao·com*/
    if ($recordAdmin['record_id']) {
        showsetting(lang('plugin/zhanmishu_video', 'record_id'), 'record_id', $recordAdmin['record_id'], 'text','','',lang('plugin/zhanmishu_video', 'record_id_desc'),'size="10"');
    }
    showsetting(lang('plugin/zhanmishu_video', 'recordAdmin_price'), 'recordAdmin_price', $recordAdmin['recordAdmin_price'], 'text','','',lang('plugin/zhanmishu_video', 'recordAdmin_price_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'recordAdmin_price_limit'), 'recordAdmin_price_limit', $recordAdmin['recordAdmin_price_limit'], 'text','','',lang('plugin/zhanmishu_video', 'recordAdmin_price_limit_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'recordAdmin_number'), 'recordAdmin_number', $recordAdmin['recordAdmin_number'], 'text','','',lang('plugin/zhanmishu_video', 'recordAdmin_number_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'cid'), 'cid', $recordAdmin['cid'], 'text','','',lang('plugin/zhanmishu_video', 'recordAdmin_cid_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'useUid'), 'useUid', $recordAdmin['useUid'], 'text','','',lang('plugin/zhanmishu_video', 'useUid_desc'),'size="10"');
    showsetting(lang('plugin/zhanmishu_video', 'expire_time'), 'expire_time', $recordAdmin['expire_time'], 'text','','',lang('plugin/zhanmishu_video', 'expire_time_desc'),'size="10"');
    // showsetting(lang('plugin/zhanmishu_video', 'tagids'), 'tagids', $recordAdmin['tagids'], 'text', '','',lang('plugin/zhanmishu_video', 'tid_desc'),'size="10"');
    // showsetting(lang('plugin/zhanmishu_video', 'invitedes'), 'invitedes', $recordAdmin['invitedes'], 'text', '','',lang('plugin/zhanmishu_video', 'invitedes_desc'),'size="10"');
    // showsetting(lang('plugin/zhanmishu_video', 'invites'), 'invites', $recordAdmin['invites'], 'text','','',lang('plugin/zhanmishu_video', 'invites_desc'),'size="10"');
    showsubmit('editrecordAdminSubmit');
    showtablefooter(); /*Dism_taobao-com*/
    showformfooter(); /*dis'.'m.tao'.'bao.com*/

}
