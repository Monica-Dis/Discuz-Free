<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *    	应用更新支持：https://dism.taobao.com $
 */	

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!$_GET['vid'] && !$_GET['type']) {
	$_GET['type'] = 'index';
}
$_G['siteurl'] = str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']);

$videoHander = zhanmishu_video::getInstance();
$videoconfig = $videoHander->config;

if ($_GET['sign'] || $_GET['ispay']) {
	$out_trade_no = daddslashes($_GET['out_trade_no']);
	$payStatus = $videoHander->check_ispay_byout_trade_no($out_trade_no);

	if (defined('IN_MOBILE_API') && $_GET['dtype']) {
		$outapi = array(
			'msg'=>'success',
			'code'=>'0',
			'data'=>$payStatus,
		);
		echo zhanmishu_api::encode($outapi);
		exit;
	}
}
$videoHander->issueorderbyuid(); 
$cid = $_GET['cid'] + 0;
if (!$cid) {
	showmessage(lang('plugin/zhanmishu_video', 'data_error'));
}

$videoadconfig = array();
$videoadconfig['startadimgurl'] = $videoconfig['startadimgurl'];
$videoadconfig['startadurl'] = $videoconfig['startadurl'];
$videoadconfig['startadtime'] = $videoconfig['startadtime'];
$videoadconfig['stopadimgurl'] = $videoconfig['stopadimgurl'];
$videoadconfig['stopadurl'] = $videoconfig['stopadurl'];
$videoadconfig['endurl'] = $videoconfig['endurl'];
$videoadconfig['endadimgurl'] = $videoconfig['endadimgurl'];

$videoconfig['adjson'] = json_encode($videoadconfig);

$course = $videoHander->get_course_bycid($cid,true,true);
if (empty($course)) {
	showmessage(lang('plugin/zhanmishu_video', 'cid_isnot_exists'),dreferer());
}

if (isset($_GET['platform'])) {
	$course['course_content'] = zhanmishu_course::richTextAbsoluteUrl(htmlspecialchars_decode(dstripslashes($course['course_content'])), $_G['siteurl']);
}else{
	$course['course_content'] = htmlspecialchars_decode(dstripslashes($course['course_content']));
}

$user = getuserbyuid($course['uid']);
$course['username'] = $user['username'];
$course['avatar'] = avatar($course['uid'], 'middle', true);
$course['video'] = $videoHander->get_video_bycid($cid,'0',true);
$course['coursetype'] = $videoHander->check_liveorvideo($course['live_url']);
$course['recommend'] = $videoHander->get_recommend_course($cid);
$course['ispay'] = $videoHander->checkuser_ispay_course($cid,$_G['uid']) ? 1 : 0;
$course['reward'] = $videoHander->get_reward_list();
$course['isfavorite'] = $videoHander->isfavorite($_GET['cid'] + 0,$_G['uid']);
$course['cat'] = $videoHander->get_cat_by_cat_id($course['cat_id']);
$course['create_time'] = dgmdate($course['dateline'],'Y-m-d');
$course['course_img'] =  str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']).$course['course_img'];
$course['teacher_info'] = $videoHander->get_teacher_info_byuid($course['uid']);
$course['teacher_info']['teacher_intro'] = htmlspecialchars_decode(dstripslashes($course['teacher_info']['teacher_intro']));

$course['teacher_info']['teacher_content'] = htmlspecialchars_decode(dstripslashes($course['teacher_info']['teacher_content']));

$course['teacher_info']['username'] = $course['username'];
$course['teacher_info']['avatar'] = avatar($course['uid'], 'middle', true);

$course['teacher_info']['teacher_img'] = str_replace($_G['siteurl'],'',$course['teacher_info']['teacher_img']);
$course['teacher_info']['teacher_img'] = $course['teacher_info']['teacher_img'] ? str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']).$course['teacher_info']['teacher_img'] : avatar($course['uid'], 'middle', true);

unset($course['teacher_info']['teacher_helper_ids']);
$course['teacher_info']['teacher_contact'] = $course['teacher_info']['teacher_intro'];

$extgroups = explode("\t", $_G['member']['extgroupids']);
$course_group = $videoHander->course_group_toarray($course['course_group']);
$extgroups[] = $_G['groupid'];

foreach ($videoconfig['vipgroup'] as $key => $value) {
	if (($course['course_price'] / 100) > $videoconfig['vipgroup'][$value]) {
		// 移除无权限观看的全局VIP
		unset($videoconfig['vipgroup'][$value]);
	}
	
}

// 当前用户处于的全局VIP组
$vgroup = array_intersect($extgroups, array_keys($videoconfig['vipgroup']));
$vgroup = is_array($vgroup) ? $vgroup : array();
// 当前用户处于的课程VIP组
$course_groupin = array_intersect($extgroups, $course_group);
$course_groupin = is_array($course_groupin) ? $course_groupin : array();

// 获取当前用户的VIP用户组
$course_groupin = array_merge($vgroup,$course_groupin);

// 获取购买的VIP用户组(所有可以观看的VIP用户组)
$allVipgroups = array_merge(array_keys($videoconfig['vipgroup']), $course_group);


if (!empty($course_groupin) || $_G['uid'] == $course['uid']) {
	$course['ispay'] = '1';
}
// 如果没支付购买，查询下专栏
if (!$course['ispay']) {
	$course['ispay'] = zhanmishu_video_model_column::fetchCourseColumnsPayStatus($cid, $_G['uid']);
}

$vipBuyGroups = array();
$groupicons = $videoHander->get_group_icons();

foreach ($allVipgroups as $key => $value) {
	// 移除自定义用户组
	if ($value < 10) {
		unset($course_groupin[$key]);
		continue;
	}

	if ($groupicons[$value]['grouptitle']) {
		$vipBuyGroups[] = array(
			'groupid'=>$value,
			'grouptitle'=>$groupicons[$value]['grouptitle'],
			'icon'=> $groupicons[$value]['icon'] ? zhanmishu_api::auto_to_url('data/attachment/common/'.$groupicons[$value]['icon']) : '',
			'color'=>$groupicons[$value]['color']
		);
	}
}


if (!empty($course['video'])) {
	$vid = $_GET['vid'] ? $_GET['vid'] + 0:  0;
	if (!$vid) {
		$currentVideo = $course['video'][0];
		if ($currentVideo['is_chapter'] == '1') {
			$currentVideo = $currentVideo['chindren'][0];
		}
	}
	$vid = $vid ? $vid : $currentVideo['vid'];
	foreach ($course['video'] as $key => $value) {
		if ($value['is_chapter'] == '1') {
			foreach ($value['chindren'] as $k => $v) {
				if ($vid && empty($currentVideo)) {
					if ($vid == $v['vid']) {
						$currentVideo = $v;
					}
				}
				$course['video'][$key]['chindren'][$k]['video_img'] = $v['video_img'] ?  $v['video_img'] : $course['course_img'];
				$course['video'][$key]['chindren'][$k]['create_time'] = dgmdate($v['dateline'],'Y-m-d');
			}
		}else{
			if ($vid && empty($currentVideo)) {
				if ($vid == $value['vid']) {
					$currentVideo = $value;
				}
			}
			$course['video'][$key]['video_img'] = $value['video_img'] ?  $value['video_img'] : $course['course_img'];
			$course['video'][$key]['create_time'] = dgmdate($value['dateline'],'Y-m-d');
		}
		$course['video'][$key]['ismusic'] = $course['video'][$key]['ismusic'] ? $course['video'][$key]['ismusic'] : '0';
	}
	if (!defined('IN_MOBILE_API') && !$_G['uid'] && $videoconfig['should_login'] && $_GET['vid'] && !defined('NOROBOT')) {
		showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
	}
	if (in_array($currentVideo['video_urltype'],array('5','6','7','8','9','11','12','13'))) {
		$currentVideo['islive'] = 1;

		$video_url['pushurl'] = '';
		$video_url['video_url']['rtmpurl'] = '';
		$video_url['video_url']['flvurl'] = '';
		$video_url['video_url']['m3u8url'] = '';
		$currentVideo['video_url'] = $video_url;

	}else{
		$currentVideo['islive'] = 0;
		$currentVideo['video_url'] = '';
	}
	//$liveinfo = $videoHander->auto_publish_live_record($vid);

 	if($course['ispay'] > 0 || $course['course_price'] == '0' || $currentVideo['isfree'] == '1' || ($currentVideo['video_price'] == '0') && $videoconfig['noprice_video_isfree']){
 		$course['ispay'] = 1;
 		$currentVideo['video_url'] = $videoHander->get_private_videourl($vid);
		if (in_array($currentVideo['video_urltype'],array('4', '5'))) {
 			$currentVideo['video_url'] = stripcslashes($currentVideo['video_url']);
 		}
 	}else if ($currentVideo['isrecord'] == '1') {
 		// 没有支付，且为录播
 		$currentVideo['video_url'] = '';
 	}
	$currentVideo['video_usernameutf8'] = $_G['username'];
	$videoHander->update_video_length($vid);
}
if(empty($currentVideo)) {
	$currentVideo = array(
		'cat_id'=> $course['cat_id'],
		'chindren'=> '',
		'cid'=> $course['cid'],
		'dateline'=> '',
		'is_chapter'=> 0,
		'is_rsa'=> 0,
		'isdel'=> 0,
		'isfree'=> 0,
		'ismusic'=> '',
		'islive'=> 0,
		'isrecord'=> 0,
		'istranscoding'=> 0,
		'level'=> 0,
		'livestatus'=> 0,
		'parent_vid'=> 0,
		'record_liveid'=> 0,
		'selltimes'=> 0,
		'sort'=> 0,
		'start_time'=> '',
		'transcodingid'=> "",
		'uid'=> '',
		'vid'=> 7,
		'video_img'=> "",
		'video_intro'=> "",
		'video_length'=> 0,
		'video_name'=> $course['course_name'],
		'video_price'=> 0,
		'video_url'=> '',
		'video_urltype'=> '',
		'video_usernameutf8'=> ""
	);
}


if (is_dir(DISCUZ_ROOT.'source/plugin/zhanmishu_app')) {
	$appHander = zhanmishu_app::getInstance();
	if ($videoconfig['isrewrite']) {
		$currentVideo['shareUrl'] = $videoHander->auto_to_url(zms_video_rewriteoutput('course_videopage',1,'',$currentVideo['cid'],$currentVideo['vid']));
	}else{
		$currentVideo['shareUrl'] = $videoHander->auto_to_url('plugin.php?id=zhanmishu_video:video&mod=video&cid='.$currentVideo['cid'].'&vid='.$currentVideo['vid']);
	}
	
	if ($appHander->config['shareUrl']) {
		$currentVideo['shareQrcodeUrl'] = $appHander->config['shareUrl'].'source/plugin/zhanmishu_app/api.php?mod=qrcode&url='.$currentVideo['shareUrl'];
	}else{
		$currentVideo['shareQrcodeUrl'] = $videoHander->auto_to_url('source/plugin/zhanmishu_app/api.php?mod=qrcode&url='.urlencode($currentVideo['shareUrl']));
	}

	$tags = $videoHander->get_course_tags_bycid($course['cid'], $currentVideo['vid']);
	if ($tags['liveInfo']['livestatus'] == '2') {
		$currentVideo['shareText'] = lang('plugin/zhanmishu_video','shareTextRecord',array('username'=> $_G['username']));
		// record
	}else if ($tags['liveInfo']['livestatus'] == '1') {
		$currentVideo['shareText'] = lang('plugin/zhanmishu_video','shareTextLiving', array('username'=> $_G['username']));
		// record
	}else if ($tags['liveInfo']['livestatus'] == '0') {
		// record
		$currentVideo['shareText'] = lang('plugin/zhanmishu_video','shareTextUnliving',array('username'=> $_G['username'], 'start_time'=> $tags['liveInfo']['start_time']));
	}else{
		$currentVideo['shareText'] = $currentVideo['course_name'] ? $currentVideo['course_name'] : $course['course_intro'];
	}
}

$course['current'] = $currentVideo;

$course['ismusic'] = $current['ismusic'] ? $current['ismusic'] : '0';
$course['islive'] = $course['islive'] ? $course['islive'] : '0';
$replyField = array();
if ($_GET['cid']) {
	$replyField['cid'] = $_GET['cid'];
	$replyField['islive'] = '0';

	if ($_GET['vid']) {
		$replyField['vid'] = $_GET['vid'] + 0;
	}
	
	$perpage = 20;
	$replies = $videoHander->get_reply_tree(0,$perpage,'',$replyField);


	//$replyField['parent_id'] = '0';
	$replyNum = C::t("#zhanmishu_video#zhanmishu_video_reply")->get_type_reply_num($replyField);


	$pages= ceil($replyNum / $perpage);

}

if ($_GET['dtype']) {
	$outapi = array(
		'msg'=>'success',
		'code'=>'0',
		'data'=>array(),
	);
	$outapi['data']['course'] = $course;
	$outapi['data']['course']['video'] = $course['video'];
	$outapi['data']['course']['vipBuyGroups'] = $vipBuyGroups;
	$outapi['data']['groupicons'] = $groupicons;
	$outapi['data']['replies']['list'] = array_values($replies);
	$outapi['data']['replies']['count'] = $replyNum;
	$outapi['data']['replies']['perpage'] = $perpage;
	$outapi['data']['replies']['pages'] = $pages;
	$outapi['data']['shareText'] = $videoHander->getShareText('video',$course);

	echo zhanmishu_api::encode($outapi);
	exit;
}

if (!$_GET['vid']) {
	$navtitle = $course['course_name'].' - '.$_G['setting']['bbname'];
	$metakeywords = $course['cat']['cat_name'].','.$videoconfig['metakeywords'];
	$metadescription = $course['course_intro'];
}else{
	$navtitle = $currentVideo['video_name'].' - '.$course['course_name'].' - '.$_G['setting']['bbname'];
	$metakeywords = $course['cat']['cat_name'].','.$videoconfig['metakeywords'];
	$metadescription = $course['course_intro'];
}

if (defined('IN_MOBILE') && is_dir(DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat')) {
	include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat/source/Autoloader.php';
	$zhanmishu_wechat = zhanmishu_wechat::getInstance();
	$weObj = $zhanmishu_wechat->wechatHander();

	$http = $_G['isHTTPS'] ? 'https://' : 'http://';
	$current_url = $http.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	$JsParams = $weObj->getJsSign($current_url);
}


include template('zhanmishu_video:'.$mod);