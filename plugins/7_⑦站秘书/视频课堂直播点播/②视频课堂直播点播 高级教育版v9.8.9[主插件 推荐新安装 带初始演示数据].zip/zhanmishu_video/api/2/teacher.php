<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_GET['action'] && $_GET['act']){
    $_GET['action'] = $_GET['act'];
}

$videoHander = zhanmishu_video::getInstance();
$teacherHander = new zhanmishu_video_teacher_controller($videoHander);

if (substr($_GET['action'],0,1) != '_' &&  method_exists($teacherHander, $_GET['action'])) {
    $action = $_GET['action'] ? $_GET['action'] : 'index';
    $teacherHander->$action();
}