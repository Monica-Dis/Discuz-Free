<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$video = zhanmishu_video::getInstance();

$videoconfig = $video->config;

$cat = $video->get_cat_tree();
$sample_cat_list =  $video->cat_tree_to_sample();
$catpid = $_GET['cat_id'] ? $video->get_pidbycat_id($_GET['cat_id'] + 0) : '0';
$catson =  $video->get_cat_tree($catpid ? $catpid : $_GET['cat_id'] + 0);

if ($mod == 'index') {
    $rewrite_cat = $_GET['cat_id'] ? $_GET['cat_id'] : '0';
    $rewrite_vip = $_GET['groupselect'] ? $_GET['groupselect'] : '0';
    $rewrite_diff = $_GET['diff'] ? $_GET['diff'] : '0';
    $rewrite_order = $_GET['order'] ? $_GET['order'] : '0';
}

$videoBaseUrl = 'plugin.php?id=zhanmishu_video:video';
$pdata = $_GET;
unset($pdata['page']);
$mpurl = 'plugin.php?'.urldecode(http_build_query($pdata));
$cdata = $_GET;
unset($cdata['cat_id']);
unset($cdata['page']);

$caturl = 'plugin.php?'.urldecode(http_build_query($cdata));
$ddata = $_GET;
unset($ddata['diff']);
$durl = 'plugin.php?'.urldecode(http_build_query($ddata));
$odata = $_GET;
unset($odata['order']);
$ourl = 'plugin.php?'.urldecode(http_build_query($odata));
$gdata = $_GET;
unset($gdata['groupselect']);
unset($gdata['page']);
$gurl = 'plugin.php?'.urldecode(http_build_query($gdata));

$field = array();
if ($_GET['search_key']) {
    if (defined('IN_MOBILE_API')) {
        $_GET['search_key'] = zhanmishu_course::auto_charset_change($_GET['search_key'],'UTF-8',CHARSET);
    }
    $field['course_name'] = array(
        'key'=>'course_name',
        'value'=>'%'.daddslashes($_GET['search_key']).'%',
        'relation'=>'like'
    );
}

if ($_GET['cat_id']) {
    $this_cat_son = $video->get_cat_tree($_GET['cat_id'] + 0);
    if (empty($this_cat_son['son'])) {
        $field['cat_id'] = $_GET['cat_id'] + 0;
    }else{
        $cat_ids = array();
        $cat_ids[$_GET['cat_id'] + 0] = $_GET['cat_id'] + 0;
        foreach ($this_cat_son['son'] as $key => $value) {
            $cat_ids[$value['cat_id']] = $value['cat_id'];
        }
        $ids .= ' ('.implode(',', $cat_ids).') ';

        $field['cat_id'] = array('key'=>'cat_id','relation'=>'in', 'value'=> $ids);
    }
    $catinfo = $video->get_cat_by_cat_id($_GET['cat_id'] + 0);
}else{
    $catinfo = null;
}
if ($_GET['diff']) {
    $field['diff'] = $_GET['diff'] + 0;
}
if ($_GET['groupselect']) {
    $field['course_group'] = array(
        'relation'=> 'sql',
        'sql'=> 'CONCAT(\',\',course_group,\',\') LIKE \'%'.daddslashes($_GET['groupselect']).'%\''
    );
}
if (!empty($field)) {
    $_GET['filter'] = 'list';
}
// 是否可见属性进行筛选，管理员不限制
if($_G['groupid'] != '1'){
    // 获取用户的扩展用户组
    $extgroups = explode("\t", $_G['member']['extgroupids']);
    // 用户主用户组混入扩展用户组
    $extgroups[] = $_G['groupid'];

    $tempSql = array();
    $tempSql[] = ' visiable_group = \'\'';
    if ($_G['uid'] > 0) {
        foreach ($extgroups as $key => $value) {
            $tempSql[] = ' CONCAT(\',\',visiable_group,\',\') LIKE \'%,'.$value.',%\' ';
        }
    }
    
    $tempSql = implode(' or ', $tempSql);
    $field['visiable_group'] = array(
        'key'=>'visiable_group',
        'sql'=>' ( '.$tempSql.' ) ',
        'relation'=>'sql'
    );

}
$field['videos'] = array(
    'key'=>'videos',
    'value'=>0,
    'relation'=>'>'
);
$field['isdel'] = '0';
$field['issell'] = '1';

$isShowLive = true;
// 小程序，审核版本进行处理
if ($_GET['platform'] == 'minapp' && $_GET['clientVersion'] && $_GET['clientVersion'] == $_GET['minappVerifyVersion']) {
    $field['islive'] = '0';
    $isShowLive = false;
}

$num = $video->get_type_course_num($field);

if ($videoconfig['clumnnums'] == 3) {
    $perpage = 8;
}else{
    $perpage = 8;
}
$curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
$pages= ceil($num / $perpage);
$start = $num - ($num - $perpage*$curpage+$perpage);


if ($_GET['order'] == 'new') {
    $sort = array('dateline'=>'desc');
}else if($_GET['order'] == 'hot'){
    $sort = array('views'=>'desc');
}else if($_GET['order'] == 'low_price'){
    $sort = array('course_price'=>'asc');
}else if($_GET['order'] == 'views'){
    $sort = array('views'=>'desc');
}else if($_GET['order'] == 'high_price'){
    $sort = array('course_price'=>'desc');
}else if($_GET['order'] == 'learns'){
    $sort = array('learns'=>'desc');
}else if($_GET['order'] == 'replies'){
    $sort = array('replies'=>'desc');
}else {
    $sort = array('course_weight'=>'desc','cid'=>'desc');
}

$list = $video->get_type_course_filter_format($start,$perpage,$sort,$field);
foreach ($list as $key => $value) {
    if ($value['islive']) {
        $list[$key]['tags'] = $video->get_course_tags_bycid($value['cid']);
    }
}

if ($isShowLive) {
    $liveList = $video->get_videos_group_by_cid(0, 6,array('start_time'=>'desc'),array('isdel'=>'0','islive'=>'1'));
    foreach ($liveList as $key => $value) {
        $liveList[$key]['video_url'] = '';
        $liveCourse = $video->get_course_bycid($value['cid']);
        if (empty($liveCourse) || $liveCourse['isdel'] == '1' || $liveCourse['issell'] == '0' ) {
            unset($liveList[$key]);
            continue;
        }
        $liveList[$key] = array_merge($liveCourse,$value);
        $liveList[$key]['tags'] = $video->get_course_tags_bycid($value['cid']);
        if ($liveList[$key]['course_img']) {
            $liveList[$key]['course_img'] = zhanmishu_video::getImageThumb($liveList[$key]['course_img'], 375, 150 ,true);
        }else{
            $liveList[$key]['course_img'] = 'source/plugin/zhanmishu_video/template/img/noimg.jpg';
        }
        $liveList[$key]['course_img'] = str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']).$liveList[$key]['course_img'];

        if ($value['uid']) {
            $user = getuserbyuid($value['uid']);
            $liveList[$key]['username'] = $user['username'];
        }
    }
}else{
    $liveList = array();
}



if(count($liveList) % 2 == 1){
    array_pop($liveList);
}

$navList = $video->get_nav_list();

$columnsField = array();
$columnsField[] = array(
    'relation'=>'sql', 
    'sql'=>' isdel = 0 '
);
$columns = C::t("#zhanmishu_video#zhanmishu_video_course_column")->fetch_all(0, 4, 'desc', $columnsField);

foreach ($columns as $key => $value) {
    $columns[$key]['course_column_img'] = zhanmishu_video::getImageThumb($value['course_column_img'], 375, 150 ,true);
    $columns[$key]['course_column_img'] = str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']).$columns[$key]['course_column_img'];

    if ($value['uid']) {
        $user = getuserbyuid($value['uid']);
        $columns[$key]['username'] = $user['username'];
    }
}


if ($_GET['filter'] != 'list') {
    $cate = array_chunk($video->get_cat_by_level('1',array('cat_touchorder'=>'asc')),8);
    $swiper = $video->get_app_swiper();
    $best = $video->get_app_best();

    foreach ($swiper as $key => $value) {
        if (zhanmishu_video::check_url($swiper[$key]['image']) == 'url') {
            $filePath = str_replace($_G['siteurl'], '', $swiper[$key]['image']);

            $swiper[$key]['image'] = $_G['siteurl'].zhanmishu_video::getImageThumb($filePath, 750, 300 ,true);
        }
    }
}


$groupicons = $video->get_group_icons();

$navtitle = $catinfo['cat_name'] ? $catinfo['cat_name'].' - '.$videoconfig['index_title'] : $videoconfig['index_title'];
$metakeywords = $catinfo['cat_name'] ? $catinfo['cat_name'].','.$videoconfig['metakeywords']:$videoconfig['metakeywords'];
$metadescription = $catinfo['cat_name'] ? $catinfo['cat_name'].','.$videoconfig['metadescription']:$videoconfig['metadescription'];


if ($_GET['dtype']) {
    $outapi = array(
        'msg'=>'success',
        'code'=>'0',
        'data'=>array(),
    );
    $outapi['data']['meta']['description'] = $metadescription;
    $outapi['data']['meta']['title'] = $navtitle;
    $outapi['data']['meta']['keywords'] = $metakeywords;
    $outapi['data']['cat'] = $cat;
    $outapi['data']['shareText'] = $video->getShareText('index',$catinfo);

    $result = array();
    if (!empty($swiper) && $_GET['filter'] != 'list') {
        $result[] = array(
            'listContentType'=>'',
            'itemType'=>'swiper',
            'list'=> $swiper
        );
    }
    if ($_GET['platform'] == 'minapp') {
        $minappAd = $video->GetFromCache('minappAd');
        $result[] = array(
            'listContentType'=>'invisible',
            'itemType'=>'ad',
            'name'=> '',
            'unit-id'=> $minappAd['wechatListAd']
        );
    }
    
    if (!empty($navList) && $_GET['filter'] != 'list') {
        $navListFormat = array();
        foreach ($navList as $key => $value) {
            $navListFormat[]  = array(
                'name'=> $value['cat_name'],
                'image'=> $value['cat_icon'],
                'urlType'=> $value['urlType'],
                'url'=> $value['url'],
                'platform'=> $value['platform']
            );
        }
        $result[] = array(
            'listContentType'=>'',
            'itemType'=>'classification',
            'list'=> $navListFormat
        );
    }

    /**
     * listContentType  三种属性  
     * invisible 无  
     * box 背景白色padding15px 
     * scroll X轴滚动
     */

    /**
     * itemType
     * lecturer 推荐讲师模板 建议搭配listContentType 为 scroll
     * miniCard 小卡片 建议搭配listContentType 为 scroll
     * 
     * liveSingle 直播模板，小单图 + 直播详情 建议配合box
     * discountSingle 小单图，折扣单独模板，显示折扣信息 建议配合box
     * defaultSingle 默认单独， 小单图 建议配合box
     * defaultCard 默认双图， 建议搭配listContentType 为 invisible
     * large 单图大图， 可搭配listContentType box 或者invisible
     * ADview 单图大图广告模块 可搭配listContentType box 或者invisible
     * classification 导航菜单图标，建议横排4个 配合invisible
     * swiper 轮播图  配合invisible
     * 
     */
    
    if (!empty($best) && $_GET['filter'] != 'list') {
        $bestFormat = array();
        foreach ($best as $key => $value) {
            $bestFormat[]  = array(
                'name'=> $value['course_name'],
                'image'=> $value['image'],
                'avatar'=> avatar($value['uid'], 'small', true),
                'author'=> zhanmishu_video_model_teacher::teacherName($value['uid']),
                'playCount'=> $value['views'],
                'videos'=> $value['videos'],
                'price'=> $value['course_price'] / 100,
                'presentPrice'=> $value['course_price'] / 100,
                'originalPrice'=> $value['course_price'] / 100,
                'offerPrice'=> ($value['originalPrice'] * 100 - $value['presentPrice'] * 100) / 100,
                'course_price_type'=> $value['course_price_type'],
                'urlType'=> $value['urlType'],
                'url'=> $value['url'],
                'platform'=> $value['platform']
            );
        }
        $result[] = array(
            'listContentType'=>'invisible',
            'itemType'=>'defaultCard',

            'name'=> lang('plugin/zhanmishu_video','recommon_course'),
            'list'=> $bestFormat
        );
    }  

    if ($_GET['platform'] == 'minapp') {
        $minappAd = $video->GetFromCache('minappAd');
        $result[] = array(
            'listContentType'=>'invisible',
            'itemType'=>'ad',
            'name'=> '',
            'unit-id'=> $minappAd['wechatListAd']
        );
    }

    
    if (!empty($liveList) && $_GET['filter'] != 'list') {
        $liveListFormat = array();
        foreach ($liveList as $key => $value) {
            $liveListFormat[]  = array(
                'name'=> $value['course_name'],
                'image'=> $value['course_img'],
                'author'=> zhanmishu_video_model_teacher::teacherName($value['uid']),
                'avatar'=> avatar($value['uid'], 'small', true),
                'tags'=> $value['tags'],
                'views'=> $value['views'],
                'videos'=> $value['videos'],
                'playCount'=> $value['views'],
                'price'=> $value['course_price'] / 100,
                'course_price_type'=> $value['course_price_type'],
                'presentPrice'=> $value['course_price'] / 100,
                'originalPrice'=> $value['course_price'] / 100,
                'offerPrice'=> ($value['originalPrice'] * 100 - $value['presentPrice'] * 100) / 100,
                'urlType'=> '1',
                'url'=> '/pages/CourseDetails/CourseDetails?cid='.$value['cid'],
                'platform'=> 0
            );
        }
        $result[] = array(
            'listContentType'=>'invisible',
            'itemType'=>'defaultCard',
            'urlType'=> '1',
            'icon'=> '',
            'url'=> '/pages/courselist/courselist',
            'name'=> lang('plugin/zhanmishu_video','living'),
            'list'=> $liveListFormat
        );
    }


    if (!empty($columns) && $_GET['filter'] != 'list') {
        $columnsFormat = array();
        foreach ($columns as $key => $value) {
            $columnsFormat[]  = array(
                'name'=> $value['course_column_name'],
                'image'=> $value['course_column_img'],
                'author'=> zhanmishu_video_model_teacher::teacherName($value['uid']),
                'avatar'=> avatar($value['uid'], 'small', true),
                'playCount'=> $value['views'],
                'price'=> $value['course_column_price'] / 100,
                'presentPrice'=> $value['course_column_price'] / 100,
                'originalPrice'=> $value['course_column_price'] / 100,
                'offerPrice'=> ($value['originalPrice'] * 100 - $value['presentPrice'] * 100) / 100,
                'urlType'=> '1',
                'url'=> '/pages/column/column?columnid='.$value['columnid'],
                'platform'=> '0'
            );
        }
        $result[] = array(
            'listContentType'=>'invisible',
            'itemType'=>'defaultCard',
            'name'=> lang('plugin/zhanmishu_video','recommon_column'),
            'urlType'=> '1',
            'icon'=> '',
            'url'=> '/pages/search/search?srchmod=22',
            'list'=> $columnsFormat
        );
    }

    if (!empty($list)) {
        $listFormat = array();
        foreach ($list as $key => $value) {
            $listFormat[]  = array(
                'name'=> $value['course_name'],
                'image'=> $value['course_img'],
                'playCount'=> $value['views'],
                'hot'=> $value['views'],
                'progress'=> $value['videos'],
                'videos'=> $value['videos'],
                'author'=> zhanmishu_video_model_teacher::teacherName($value['uid']),
                'avatar'=> avatar($value['uid'], 'small', true),
                'price'=> $value['course_price'] / 100,
                'presentPrice'=> $value['course_price'] / 100,
                'originalPrice'=> $value['course_price'] / 100,
                'offerPrice'=> ($value['originalPrice'] * 100 - $value['presentPrice'] * 100) / 100,
                'tags'=> $value['tags'],
                'course_price_type'=> $value['course_price_type'],
                'urlType'=> '1',
                'url'=> '/pages/CourseDetails/CourseDetails?cid='.$value['cid'],
                'platform'=> 0
            );
        }
        $result[] = array(
            'listContentType'=>'invisible',
            'itemType'=>'defaultCard',
            'name'=> lang('plugin/zhanmishu_video','new_course'),
            'urlType'=> '1',
            'icon'=> '',
            'url'=> '/pages/courselist/courselist',
            'list'=> $listFormat,
            'count'=> $num
        );
    }



    if ($_GET['filter'] == 'list') {
        $outapi['data']['result'] = $result;
    }else{
        $navBar = array();
        $navBar[] = array(
            'id'=>'0',
            'name'=> lang('plugin/zhanmishu_video','home_page'),
            'data'=> array(),
            'refreshing'=> false,
            'refreshFlag'=> false,
            'refreshText'=> '',
            'loadingText'=> lang('plugin/zhanmishu_video','loading'),
            'requestParams'=> array(
                'page'=>'1',
                'search_key'=>'',
                'cat_id'=>'',
                'order'=>'',
            )
        );
        foreach ($cat as $key => $value) {
            $navBar[] = array(
                'id'=> $key + 1,
                'name'=> $value['cat_name'],
                'data'=> array(),
                'refreshing'=> false,
                'refreshFlag'=> false,
                'refreshText'=> '',
                'loadingText'=> lang('plugin/zhanmishu_video','loading'),
                'requestParams'=> array(
                    'page'=>'1',
                    'search_key'=>'',
                    'cat_id'=>$value['cat_id'],
                    'order'=>'',
                )
            );
        }


        $outapi['data']['result'] = $result;
        $outapi['data']['navBar'] = $navBar;
        $outapi['data']['catinfo'] = $catinfo;
        $outapi['data']['groupicons'] = $groupicons;
    }

    echo json_encode($video->auto_to_utf8($outapi));
    exit;
}

include template('zhanmishu_video:'.$mod);


?>