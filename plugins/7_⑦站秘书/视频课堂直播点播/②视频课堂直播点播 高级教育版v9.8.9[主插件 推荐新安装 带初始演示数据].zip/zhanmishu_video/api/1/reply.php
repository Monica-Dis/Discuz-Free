<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *      应用更新支持：https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$videoHander = zhanmishu_video::getInstance();
$config = $videoHander->config;


if ((defined('IN_MOBILE_API') && $_GET['replySubmit'] && $_G['uid']) || submitcheck('replySubmit',1)) {

    if (!$_G['uid']) {
        showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
    }
    $reply = array();
    $reply['cid'] = $_GET['cid'] + 0;
    $reply['islive'] = $_GET['islive'] + 0;
    $reply['score'] = $_GET['score'] + 0;
    $reply['uid'] = $_G['uid'];
    $reply['dateline'] = TIMESTAMP;
    $reply['reply_comment'] = daddslashes(strip_tags($_GET['reply_comment']));

    if ($_GET['vid']) {
        $reply['vid'] = $_GET['vid'] + 0;
    }
    if ($_GET['parent_id']) {
        $reply['parent_id'] = $_GET['parent_id'];
    }
    $parentReply = C::t("#zhanmishu_video#zhanmishu_video_reply")->get_one_reply_byfield(array('reply_id'=>$reply['parent_id']));
    if (!empty($parentReply)) {
        $reply['reply_uid'] = $parentReply['uid'];
    }

    if (!$config['is_reply_open']) {
        $return = array();
        $return['code'] = -99;
        $return['message'] = 'reply_isnot_open';
    }if (!$reply['cid']) {
        $return = array();
        $return['code'] = -1;
        $return['message'] = 'cid_is_not_exists';
    }else if (!$reply['uid']) {
        $return = array();
        $return['code'] = -2;
        $return['message'] = 'please_login_in';
    }else if (!$reply['reply_comment']) {
        $return = array();
        $return['code'] = -3;
        $return['message'] = 'reply_content_cannot_be_empty';
    }


    if (isset($return) && $return['code'] < 0) {
        $return['message'] = lang('plugin/zhanmishu_video',$return['message']);
    }else{
        $reply_id = C::t("#zhanmishu_video#zhanmishu_video_reply")->insert($reply,true,false);
        $return['code'] = 1;
        $return['message'] = 'reply_success';
        $return['reply_id'] = $reply_id;
        $return['message'] = lang('plugin/zhanmishu_video',$return['message']);
    }
    $videoHander->update_course_reply_num($reply['cid']);
    echo json_encode($videoHander->auto_to_utf8($return));
    exit;
}elseif ((defined('IN_MOBILE_API') && $_GET['praseSubmit'] && $_G['uid'])) {

    if (!$_G['uid']) {
        showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
    }

    


    exit;
}else if (submitcheck('deleteLiveCommentSubmit',1)) {
    $reply_id = $_GET['reply_id'];
    if (!$reply_id) {
        echo json_encode(array('code'=>'-1','msg'=>'reply_id is empty'));
        exit;
    }

    $reply = C::t("#zhanmishu_video#zhanmishu_video_reply")->fetch($reply_id);
    if (empty($reply) || $reply['isdel']) {
        echo json_encode(array('code'=>'-2','msg'=>'reply is empty'));
        exit;
    }

    $cid = $reply['cid'];
    $course = $videoHander->get_course_bycid($cid);
    if (empty($course)) {
        echo json_encode(array('code'=>'-3','msg'=>'course is empty'));
        exit;
    }

    $is_helper = false;
    if ($_G['groupid'] == '1' || $_G['uid'] == $course['uid']) {
        $is_helper = true;   
    }else{
        $teacher = C::t("#zhanmishu_video#zhanmishu_teacher_info")->fetch($course['uid']);
        $teacher_helper = array_filter(explode(',',$teacher['teacher_helper_ids']));

        if (in_array($_G['uid'], $teacher_helper)) {
            $is_helper = true;
        }
    }

    $reply_user = getuserbyuid($reply['uid']);
    // 当前不是管理员登录，但是是管理员回复内容，不允许删除
    if ($_G['groupid'] != '1' && $reply_user['groupid'] == '1') {
        $is_helper = false;
    }

    //当前不是老师登陆，也不是管理员登录，但是是老师回复的，不允许删除
    if ($_G['groupid'] != '1' && $_G['uid'] != $course['uid'] && $reply_user['uid'] == $course['uid']) {
        $is_helper = false;
    }

    if (!$is_helper) {
        echo json_encode(array('code'=>'-4','msg'=>'auth error'));
        exit;
    }



    if ($_GET['uid']) {
        $r = C::t("#zhanmishu_video#zhanmishu_video_reply")->delete_reply_byuid($_GET['uid']+0,$course['cid']);
    }else{
        $r = $reply_id = C::t("#zhanmishu_video#zhanmishu_video_reply")->delete($reply_id);
    }

    $return = array();
    $return['code'] = 1;
    $return['uid'] = $_GET['uid'] + 0;
    $return['cid'] = $course['cid'];
    $return['reply_id'] = $_GET['reply_id'] + 0;
    $return['message'] = 'success';
    $return['date'] = $r;


    echo json_encode($return);
    exit;
}else if ($_GET['act'] == 'getReplyList') {

    $replyField['cid'] = $_GET['cid'];

    if ($_GET['vid']) {
        $replyField['vid'] = $_GET['vid'] + 0;
    }

    if (!$_GET['islive']) {
        $replyField['islive'] = '0';
    }

    $perpage = 20;
    $curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
    $replyFieldNum = $replyField;
    $replyFieldNum['parent_id'] = '0';
    $replyNum = C::t("#zhanmishu_video#zhanmishu_video_reply")->get_type_reply_num($replyFieldNum);
    $start = $replyNum - ($replyNum - $perpage*$curpage+$perpage);
    $pages= ceil($replyNum / $perpage);

    $replies = $videoHander->get_reply_tree($start,$perpage,'',$replyField);

    include template('zhanmishu_video:inc_reply_list');
}else if ($_GET['act'] == 'getReplyListJson') {

    $replyField['cid'] = $_GET['cid'];
    $replyField['isdel'] = '0';
    if (!$_GET['islive']) {
        $replyField['islive'] = '0';
    }
    if ($_GET['vid']) {
        $replyField['vid'] = $_GET['vid'] + 0;
    }
    if ($_GET['reply_id']) {
        $replyField['reply_id'] = array('key'=>'reply_id','value'=>$_GET['reply_id'] + 0,'relation'=>'<=');
    }
    $perpage = 20;
    $curpage = ($_GET['page'] + 0) > 0 ? ($_GET['page'] + 0) : 1;
    $replyFieldNum = $replyField;


    $replyNum = C::t("#zhanmishu_video#zhanmishu_video_reply")->get_type_reply_num($replyFieldNum);
    $start = $replyNum - ($replyNum - $perpage*$curpage+$perpage);
    $pages= ceil($replyNum / $perpage);

    $replies = $videoHander->get_type_reply($start,$perpage,'desc',$replyField);

    $return = array();
    $return['pages'] = $pages;
    $return['page'] = $curpage;
    $return['perpage'] = $perpage;
    $return['count'] = $replyNum;
    $return['code'] = 1;
    $return['reply'] = array_values(array_filter($replies));

    echo json_encode(zhanmishu_course::auto_charset_change($return),JSON_NUMERIC_CHECK);
    exit;
    
}else if ($_GET['act'] == 'delete' && submitcheck('replyDeleteSubmit',1)) {
    $reply_id = $_GET['reply_id'] + 0;

    if (!$reply_id) {
        $return = array();
        $return['code'] = -1;
        $return['message'] = 'reply_id_is_not_exists';
    }else if (!$_G['uid']) {
        $return = array();
        $return['code'] = -2;
        $return['message'] = 'please_login_in';
    }else if ($_G['groupid'] != '1') {
        $return = array();
        $return['code'] = -3;
        $return['message'] = 'you_have_no_promise';
    }
       
    if (isset($return) && $return['code'] < 0) {
        $return['message'] = lang('plugin/zhanmishu_video',$return['message']);
    }else{
        $reply_id = C::t("#zhanmishu_video#zhanmishu_video_reply")->delete($reply_id);
        $return['code'] = 1;
        $return['message'] = 'reply_delete_success';
        $return['message'] = lang('plugin/zhanmishu_video',$return['message']);
    }
    
    echo json_encode(zhanmishu_course::auto_charset_change($return));
    exit;
    
}else if ($_GET['act'] == 'getReply' && $_GET['reply_id'] && ( (defined('IN_MOBILE_API') && $_GET['getReplySubmit']) || submitcheck('getReplySubmit',1))) {
    $reply_id = $_GET['reply_id'] + 0;

    if (!$reply_id) {
        $return = array();
        $return['code'] = -1;
        $return['message'] = 'reply_id_is_not_exists';
    }
       
    if (isset($return) && $return['code'] < 0) {
        $return['message'] = lang('plugin/zhanmishu_video',$return['message']);
    }else{
        $reply = C::t("#zhanmishu_video#zhanmishu_video_reply")->fetch($reply_id);

        if (!empty($reply)) {
            $reply['reply_comment'] = zhanmishu_course::auto_charset_change(dstripslashes($reply['reply_comment'],CHARSET,'UTF-8'));
            $user = getuserbyuid($reply['uid']);
            $reply['username'] = zhanmishu_course::auto_charset_change($user['username'],CHARSET,'UTF-8');
            $reply['create_time'] = dgmdate($reply['dateline'],'Y-m-d');;
            $reply['avatar'] = avatar($reply['uid'], 'middle', true);
        }
        $return['code'] = 1;
        $return['reply'] = $reply;
        $return['message'] = 'success';
        $return['message'] = zhanmishu_course::auto_charset_change(lang('plugin/zhanmishu_video',$return['message']),CHARSET,'UTF-8');
    }
    
    echo json_encode($return);
    exit;
    
}



