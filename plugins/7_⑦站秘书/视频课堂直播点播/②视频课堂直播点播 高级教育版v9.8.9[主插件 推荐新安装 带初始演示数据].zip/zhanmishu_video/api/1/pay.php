<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *    	Ӧ�ø���֧�֣�https://dism.taobao.com $
 */	

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$video = zhanmishu_video::getInstance();
$config = $video->config;
include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_wepay/source/function/api_function.php';


if (!$_G['uid']) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$out_trade_no = $video->get_rand_trade_no();
 $data  = array(
	        'out_trade_no'=>$out_trade_no,
	        'total_fee'=>99,
	        'intro'=>'ddd',
	        'name'=>'ddd',
	        'bank_type'=>$_GET['bank_type'],
	        'num'=>'1',
	        'price'=>99,
	        'return_url'=>'http://xxx.com/success.html',
	);
	$url=$_G['siteurl'].'plugin.php?id=zhanmishu_wepay:pay&mod=pay&'.http_build_query($data);

	showmessage('', $url, array(),array('showid' => '','extrajs' => '<script type="text/javascript">'.'top.location.href="'.$url.'";</script>'.$ucsynlogin,'showdialog' => false));

?>