<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$cid = $_GET['cid'] + 0;

$videoHander = zhanmishu_video::getInstance();

if ($_GET['MediaId']) {
    $key = $videoHander->ossDecrypt($_GET);
}else{
    $key = $videoHander->config['qiniu_true_hlsKey'];

}

$filename = 'key.key';
ob_clean();
ob_start();
// header('Access-Control-Allow-Origin:'.substr($_G['siteurl'], 0,strlen($_G['siteurl']) -1));
header('Access-Control-Allow-Origin:*');
header('Content-Type: application/octet-stream');
if (preg_match("/MSIE/", $_SERVER['HTTP_USER_AGENT']) ) {  
    header('Content-Disposition:  attachment; filename="' . $filename . '"');  
} elseif (preg_match("/Firefox/", $_SERVER['HTTP_USER_AGENT'])) {  
    header('Content-Disposition: attachment; filename*="utf8' .  $filename . '"');  
} else {  
    header('Content-Disposition: attachment; filename="' .  $filename . '"');  
}

echo $key;
ob_end_flush();
exit;
