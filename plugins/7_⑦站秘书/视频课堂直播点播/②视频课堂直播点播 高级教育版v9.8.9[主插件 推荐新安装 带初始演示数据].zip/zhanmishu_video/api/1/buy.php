<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *    	应用更新支持：https://dism.taobao.com $
 */	

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$cid = $_GET['cid'] + 0;

$video = zhanmishu_video::getInstance();
$videoconfig = $video->config;

if (!$_G['uid'] && defined('IN_MOBILE_API')) {
	$return = array();
	$return['code'] = '-1001';
	$return['msg'] = 'please_login';
	echo json_encode($return);
	exit;

}elseif (!$_G['uid'] && !defined('IN_MOBILE_API')) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1,'msgtype'=>1));
}

$course = $video->get_course_bycid($cid,false,true);

if (!$cid || empty($course) || $course['isdel'] == '1') {
	showmessage(lang('plugin/zhanmishu_video', 'data_error'));
}else if ($_GET['formhash']==formhash() || defined('IN_MOBILE_API')) {
	if ($videoconfig['isverify']) {
		$isverify = $video->check_user_isverify();
		$isverifysubmit = $video->check_verify_issubmit();
		$isverifysubmitcheck = $isverifysubmit && $_GET['isverifysubmit'];

		$verifytips = $isverifysubmit ? lang('plugin/zhanmishu_video','verifytips_check') : lang('plugin/zhanmishu_video','verifytips') ;

		if (!$isverify && !$isverifysubmitcheck && $course['course_type'] =='1') {
			showmessage($verifytips, 'home.php?mod=spacecp&ac=profile&op=verify&vid='.$video->get_verify_id().'&return_url='.urlencode(dreferer()), array(), array('msgtype' => 1,'showmsg'=>true));
		}
	}

	// 密码类课程订单
	
	if($_GET['course_password']){

		$return = array();
		$return['code'] = '1';
		$return['msg'] = 'success';
		$return['data'] = zhanmishu_video_model_course::useCoursePassword($_GET['course_password'], $_GET['cid'] + 0);

		echo json_encode(zhanmishu_course::auto_charset_change($return));
		exit;
	}

	$out_trade_no = $video->get_rand_trade_no();
	$o = array();
	$o['uid'] = $course['uid'];
	$o['course_name'] = $course['course_name'];
	$o['total_fee'] = $course['course_price'];
	$o['course_intro'] = $course['course_intro'];
	$o['course_img'] = $course['course_img'];
	$o['course_price'] = $course['course_price'];
	$o['order_type'] = $course['course_type'];
	$o['cid'] = $course['cid'];
	$o['buyer_uid'] = $_G['uid'];
	$o['out_trade_no'] = $out_trade_no;
	$o['dateline'] = TIMESTAMP;

	if ($_GET['oid']) {
		$checko['oid'] = $_GET['oid'] + 0;
		$checkorder = $video->get_order_byoid($checko['oid']);
	}else{
		//check order
		$checko = array();
		$checko['cid'] = $o['cid'];
		$checko['buyer_uid'] = $_G['uid'];
		$checko['ispayed'] = '0';
		$checko['isclosed'] = '0';
		$checkorder = $video->get_one_order_byfield($checko);
	}
	

	if (empty($checkorder) && $_GET['oid']) {
		showmessage(lang('plugin/zhanmishu_video', 'order_error'));
	}else if ($checkorder['ispayed'] == '1') {
		showmessage(lang('plugin/zhanmishu_video', 'order_is_payed'));
	}

	if ($checkorder['oid']) {
		$o['oid'] = $checkorder['oid'];
	}

	$return_url = $_GET['return_url'] ? urldecode($_GET['return_url']) : dreferer();

	$data  = array(
			'out_trade_no'=>$out_trade_no,
			'total_fee'=>strval($o['course_price'] / 100),
			'intro'=>remove_nopromissword($o['course_intro']),
			'name'=>remove_nopromissword($o['course_name']),
			'bank_type'=> daddslashes($_GET['bank_type']),
			'num'=>'1',
			'price'=>strval($o['course_price'] / 100),
			'return_url'=>$return_url,
			);
	C::t("#zhanmishu_video#zhanmishu_video_order")->insert($o,false,true);

	//if pay not is  no't support zhanmishu_wepay
	$config = $video->config;
	$zmsPayExists =  $video->ZmsIsWepayExists();
	if($course['course_price_type' == 1]){
		// 加密直播，即只验证密钥
		

	}else if ($course['course_price'] == '0' && defined('IN_MOBILE_API')) {
		$video->setsuccess($o['oid']);
		$return = array();
		$return['code'] = '1';
		$return['msg'] = 'success';
		$return['data'] = array(
			'cid'=>$course['cid'],
			'out_trade_no'=>$data['out_trade_no'],
			'return_url'=>$data['return_url'],
			'message'=>'buy_free_course_success',
			'total_fee'=>'0'
		);

		echo json_encode(zhanmishu_course::auto_charset_change($return));
		exit;
	}else if (defined('IN_MOBILE_API')) {
		//$video->setsuccess($o['oid']);
		$return = array();
		$return['code'] = '1';
		$return['msg'] = 'success';
		$return['data'] = $data;
		$return['data']['cid'] = $course['cid'];


		if ($_GET['MagAPP'] == 'yes') {
			// 马甲app的支付
			
			
		}


		if ($zmsPayExists) {
			include_once DISCUZ_ROOT.'source/plugin/zhanmishu_wepay/source/function/api_function.php';
			$orderInfo = array();
			$orderInfo['out_trade_no'] = $data['out_trade_no'];
			$orderInfo['subject'] = $course['course_name'];
			$orderInfo['body'] = $course['course_intro'];
			$orderInfo['total_fee'] = $course['course_price'] / 100;
			$orderInfo['openId'] = $_GET['openid'];

			if ($_GET['platform'] == 'minapp') {
				$payType = 'wechat_app';
			}else if ($_GET['platform'] == 'app') {
				$payType = 'app';
			}else{
				$payType = '';
				// 修正openid， 如没有openid，从cookie获取
				if (defined('IN_MOBILE') && is_dir(DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat')) {
					include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat/source/Autoloader.php';
					$orderInfo['openId'] = $orderInfo['openId'] ? $orderInfo['openId'] : zhanmishu_wechat::base64_urlSafeDecode(getcookie(zhanmishu_wechat::$openidCookie));
				}

			}
			if (!$orderInfo['openId']) {
	            if (is_file(DISCUZ_ROOT.'source/plugin/zhanmishu_wechat/source/class/zhanmishu_wechat_member.php')) {
	            	if (!class_exists('zhanmishu_wechat_member',false)) {
	                    C::import('zhanmishu_wechat_member','plugin/zhanmishu_wechat/source/class');
	                }
		            $orderInfo['openId'] = zhanmishu_wechat_member::get_openid_by_uid($_G['uid'],$_GET['platform']);
	            }
                
			}

			$payInfo = zhanmishu_pay_api($orderInfo,'1',$payType);
			$return['data']['payInfo'] = $payInfo;
		}
		echo json_encode(zhanmishu_course::auto_charset_change($return));
		exit;
	}

	if (($config['paytype'] == '1' || !$zmsPayExists) && $config['paytype_extcredits']) {
		$moneyNum = $config['moneyper'] * $o['course_price'] / 100;
		if ($_GET['act'] == 'do') {
			if ($_GET['total_fee'] !== $o['course_price']) {
				showmessage(lang('plugin/zhanmishu_video','price_is_updated'));
			}
			//检测是否已经支付
			if ($o['ispayed'] == '1') {
				showmessage(lang('plugin/zhanmishu_video','you_have_payed'));
			}

			if ($video->checklowerlimit('-'.$moneyNum) !== true) {
				showmessage(lang('plugin/zhanmishu_video','cr_isnot_enough_please_pay_times'));
				exit;
			}else{
 
				$c = array();
				$c['oid']=$o['oid'];
				$c['cid']=$o['cid'];
				$c['course_name']=$o['course_name'];
				$c['time']=date('Y-m-d H:i:s',$o['dateline']);

				$video->updatemembercount($_G['uid'],'-'.$moneyNum,lang('plugin/zhanmishu_video','paytype_extcredits'),lang('plugin/zhanmishu_video','paytype_extcredits_intro',$c));
				$c['buyer_username'] = $_G['username'];

				if ($config['teacher_per']) {
					$video->updatemembercount($o['uid'],ceil($moneyNum * $config['teacher_per']),lang('plugin/zhanmishu_video','paytype_extcredits_percentage'),lang('plugin/zhanmishu_video','paytype_extcredits_percentage_intro',$c));
				}

			}

			$video->setsuccess($o['oid']);
			$js = '<script type="text/javascript">showDialog(\''.lang('plugin/zhanmishu_video','pay_success').'\',\'confirm\',\'\',function(){top.location.href="'.$return_url.'";},0,function(){location.reload();});</script>';
	
			if (defined('IN_MOBILE')) {
				zms_go_header($return_url);
			}
			showmessage(lang('plugin/zhanmishu_video','buytips'), '', array(), array('msgtype' => 3,'showmsg'=>false,'extrajs'=>$js));
			
		}else{
			$url = $_SERVER["REQUEST_URI"].'&act=do&total_fee='.$o['course_price'].'&formhash='.FORMHASH.'&return_url='.urlencode($return_url);
			$js = '<script type="text/javascript">showDialog(\''.lang('plugin/zhanmishu_video','buy_course_extcredits',array('moneyNum'=>$moneyNum)).'\',\'confirm\',\'\',function(){showWindow("buyvideoact", "'.$url.'")},0,function(){location.reload();});</script>';
			showmessage(lang('plugin/zhanmishu_video','buytips'), '', array(), array('msgtype' => 3,'showmsg'=>false,'extrajs'=>$js));		
		}
		exit;
	}
	$url=$_G['siteurl'].'plugin.php?id=zhanmishu_wepay:pay&mod=pay&'.http_build_query($data);

	if (defined('IN_MOBILE')) {
		zms_go_header($url);
		exit;
	}
	$js = '<script type="text/javascript">top.location.href="'.$url.'";</script>';
	showmessage(lang('plugin/zhanmishu_video','buytips'), dreferer(), array(), array('msgtype' => 3,'showmsg'=>false,'extrajs'=>$js));

}
//From: d'.'is'.'m.ta'.'obao.com
?>