<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      最新插件：http://t.cn/Aiux1Jx1 $
 *    	应用更新支持：https://dism.taobao.com $
 */	




if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!$_GET['vid'] && !$_GET['type']) {
	$_GET['type'] = 'index';
}


$videoHander = zhanmishu_video::getInstance();
$videoconfig = $videoHander->config;

if ($_GET['sign'] || $_GET['ispay']) {
	$out_trade_no = daddslashes($_GET['out_trade_no']);
	$payStatus = $videoHander->check_ispay_byout_trade_no($out_trade_no);

	if (defined('IN_MOBILE_API') && $_GET['dtype']) {
		$outapi = array(
			'msg'=>'success',
			'code'=>'0',
			'data'=>$payStatus,
		);
		echo zhanmishu_api::encode($outapi);
		exit;
	}
}
$videoHander->issueorderbyuid(); 
$cid = $_GET['cid'] + 0;
if (!$cid) {
	showmessage(lang('plugin/zhanmishu_video', 'data_error'));
}

$videoadconfig = array();
$videoadconfig['startadimgurl'] = $videoconfig['startadimgurl'];
$videoadconfig['startadurl'] = $videoconfig['startadurl'];
$videoadconfig['startadtime'] = $videoconfig['startadtime'];
$videoadconfig['stopadimgurl'] = $videoconfig['stopadimgurl'];
$videoadconfig['stopadurl'] = $videoconfig['stopadurl'];
$videoadconfig['endurl'] = $videoconfig['endurl'];
$videoadconfig['endadimgurl'] = $videoconfig['endadimgurl'];

$videoconfig['adjson'] = json_encode($videoadconfig);

$course = $videoHander->get_course_bycid($cid,true,true);
if (empty($course)) {
	showmessage(lang('plugin/zhanmishu_video', 'cid_isnot_exists'),dreferer());
}
// 校验可见属性
if ($course['visiable_group']) {
    $visiable = zhanmishu_video_model_course::checkGroup($course['visiable_group'], $course['uid']);
    if (!$visiable) {
        showmessage(lang('plugin/zhanmishu_video', 'visiable_group_acl'),dreferer());

    }
}
$course['course_content'] = zhanmishu_course::richTextAbsoluteUrl(htmlspecialchars_decode(dstripslashes($course['course_content'])), str_replace('/source/plugin/zhanmishu_video','',$_G['siteurl']));

$user = getuserbyuid($course['uid']);
$course['username'] = $user['username'];
$course['avatar'] = avatar($course['uid'], 'middle', true);
$course['video'] = array_filter($videoHander->get_video_bycid($cid,'0'));
$course['videonums'] = count($course['video']);
$course['coursetype'] = $videoHander->check_liveorvideo($course['live_url']);
$course['recommend'] = $videoHander->get_recommend_course($cid);
$course['ispay'] = $videoHander->checkuser_ispay_course($cid,$_G['uid']) ? 1 : 0;
$course['cat'] = $videoHander->get_cat_by_cat_id($course['cat_id']);
$course['create_time'] = dgmdate($course['dateline'],'Y-m-d');
$course['course_img'] =  str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']).$course['course_img'];
$course['teacher_info'] = $videoHander->get_teacher_info_byuid($course['uid']);
$course['teacher_info']['teacher_intro'] = htmlspecialchars_decode(dstripslashes($course['teacher_info']['teacher_intro']));
$course['teacher_info']['teacher_contact'] = $course['teacher_info']['teacher_intro'];

$course['teacher_info']['teacher_content'] = htmlspecialchars_decode(dstripslashes($course['teacher_info']['teacher_content']));

$course['teacher_info']['username'] = $course['username'];
$course['teacher_info']['avatar'] = avatar($course['uid'], 'middle', true);
$course['teacher_info']['teacher_img'] = $course['teacher_info']['teacher_img'] ? str_replace('source/plugin/zhanmishu_video/','',$_G['siteurl']).$course['teacher_info']['teacher_img'] : avatar($course['uid'], 'middle', true);
unset($course['teacher_info']['teacher_helper_ids']);

$extgroups = explode("\t", $_G['member']['extgroupids']);
$course_group = array_filter(explode(',', trim($course['course_group'])));
$extgroups[] = $_G['groupid'];
$vgroup = array_intersect($extgroups, array_keys($videoconfig['vipgroup']));

$course_groupin = array_intersect($extgroups, $course_group);


if (!empty($course_groupin) || $_G['uid'] == $course['uid']) {
	$course['ispay'] = '1';
}else{
	foreach ($vgroup as $value) {
		if (($course['course_price'] / 100) <= $videoconfig['vipgroup'][$value]) {
			$course['ispay'] = '1';
			break;
		}
	}

}
// 如果没支付购买，查询下专栏
if (!$course['ispay']) {
	$course['ispay'] = zhanmishu_video_model_column::fetchCourseColumnsPayStatus($cid, $_G['uid']);
}
$groupicons = $videoHander->get_group_icons();

if (!empty($course['video'])) {
	$showvideo = current($course['video']);
	foreach ($course['video'] as $key => $value) {
		$course['video'][$key]['video_img'] = $value['video_img'] ?  $value['video_img'] : $course['course_img'];
		$course['video'][$key]['create_time'] = dgmdate($value['dateline'],'Y-m-d');
	}
	$vid = $_GET['vid'] ? $_GET['vid'] + 0:  $showvideo['vid'];
	if (!defined('IN_MOBILE_API') && !$_G['uid'] && $videoconfig['should_login'] && $_GET['vid'] && !defined('NOROBOT')) {
		showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
	}
	if (in_array($course['video'][$vid]['video_urltype'],array('5','6','7','8','9','11','12','13'))) {
		$course['video'][$vid]['islive'] = 1;
	}else{
		$course['video'][$vid]['islive'] = 0;
	}


	//$liveinfo = $videoHander->auto_publish_live_record($vid);

 	if($course['ispay'] > 0 || $course['course_price'] == '0' || $course['video'][$vid]['isfree'] == '1' || ($course['video'][$vid]['video_price'] == '0') && $videoconfig['noprice_video_isfree']){
 		$course['video'][$vid]['video_url'] = $videoHander->get_private_videourl($vid);
 	}else{
 		$course['video'][$vid]['video_url'] = '';
 	}
 	$course['current'] = $course['video'][$vid];

	$course['video'][$vid]['video_usernameutf8'] = $_G['username'];
	$videoHander->update_video_length($vid);

}
$replyField = array();
if ($_GET['cid']) {
	$replyField['cid'] = $_GET['cid'];
	$replyField['islive'] = '0';

	if ($_GET['vid']) {
		$replyField['vid'] = $_GET['vid'] + 0;
	}
	
	$perpage = 20;
	$replies = $videoHander->get_reply_tree(0,$perpage,'',$replyField);


	//$replyField['parent_id'] = '0';
	$replyNum = C::t("#zhanmishu_video#zhanmishu_video_reply")->get_type_reply_num($replyField);


	$pages= ceil($replyNum / $perpage);

}

if ($_GET['dtype']) {
	$outapi = array(
		'msg'=>'success',
		'code'=>'0',
		'data'=>array(),
	);
	$outapi['data']['course'] = $course;
	$outapi['data']['course']['video'] = array_values($course['video']);
	$outapi['data']['groupicons'] = $groupicons;
	$outapi['data']['replies']['list'] = array_values($replies);
	$outapi['data']['replies']['count'] = $replyNum;
	$outapi['data']['replies']['perpage'] = $perpage;
	$outapi['data']['replies']['pages'] = $pages;
	$outapi['data']['shareText'] = $videoHander->getShareText('video',$course);
	echo zhanmishu_api::encode($outapi);
	exit;
}

if (!$_GET['vid']) {
	$navtitle = $course['course_name'].' - '.$_G['setting']['bbname'];
	$metakeywords = $course['cat']['cat_name'].','.$videoconfig['metakeywords'];
	$metadescription = $course['course_intro'];
}else{
	$navtitle = $course['video'][$vid]['video_name'].' - '.$course['course_name'].' - '.$_G['setting']['bbname'];
	$metakeywords = $course['cat']['cat_name'].','.$videoconfig['metakeywords'];
	$metadescription = $course['course_intro'];
}

if (defined('IN_MOBILE') && is_dir(DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat')) {
	include_once DISCUZ_ROOT.'./source/plugin/zhanmishu_wechat/source/Autoloader.php';
	$zhanmishu_wechat = zhanmishu_wechat::getInstance();
	$weObj = $zhanmishu_wechat->wechatHander();

	$http = $_G['isHTTPS'] ? 'https://' : 'http://';
	$current_url = $http.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	$JsParams = $weObj->getJsSign($current_url);
}


include template('zhanmishu_video:'.$mod);