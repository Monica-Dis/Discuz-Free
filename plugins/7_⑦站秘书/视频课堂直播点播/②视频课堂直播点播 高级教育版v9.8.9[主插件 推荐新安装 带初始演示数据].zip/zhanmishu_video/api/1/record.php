<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */ 

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$videoHander = zhanmishu_video::getInstance();


if ($_GET['action'] == 'record') {

    if (!$_G['uid']) {
        $return =array(
            'code' => '-10001',
            'msg' => 'please_login'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }else if (!$_GET['vid']) {
        $return =array(
            'code' => '-70001',
            'msg' => 'vid_is_required'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }

    $live = $videoHander->get_video_by_vid($_GET['vid'] + 0);
    if (empty($live)) {
        $return =array(
            'code' => '-70020',
            'msg' => 'live_is_not_exists'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }else if ($live['video_urltype'] != '11') {
        $return =array(
            'code' => '-70021',
            'msg' => 'this_is_video_not_live'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;
    }else if ($live['uid'] != $_G['uid'] && $_G['groupid'] != '1') {
         $return =array(
            'code' => '-70022',
            'msg' => 'acl_error'
        );
        echo zhanmishu_api::resultToJson($return);
        exit;       
    }

    $isRecord = $videoHander->auto_publish_live_record($live['vid'],false);
    if ($isRecord) {
        $return =array(
            'code' => '1',
            'msg' => 'success'
        );
        echo zhanmishu_api::resultToJson($return);
        exit; 
    }
    $return =array(
        'code' => '0',
        'msg' => 'not_check_record'
    );
    echo zhanmishu_api::resultToJson($return);
    exit; 

}
