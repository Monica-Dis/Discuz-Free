<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      ���²����http://t.cn/Aiux1Jx1 $
 *      Ӧ�ø���֧�֣�https://dism.taobao.com $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$video = zhanmishu_video::getInstance();
$videoconfig = $video->config;

if (!$_G['uid']) {
    showmessage('to_login', $_G['siteurl'].'member.php?mod=logging&action=login', array(), array('showmsg' => true, 'login' => 1));
}




include template('zhanmishu_video:'.$mod);
